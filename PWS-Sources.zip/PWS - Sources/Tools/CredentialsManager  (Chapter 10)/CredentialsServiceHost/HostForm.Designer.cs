// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace CredentialsServiceHost
{
   partial class HostForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.SuspendLayout();
         // 
         // HostForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(292,273);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "HostForm";
         this.Text = "Credentials Service Host";
         this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
         this.ResumeLayout(false);

      }

      #endregion
   }
}

