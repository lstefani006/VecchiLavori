using System;
using System.Windows.Forms;

namespace ServiceModelEx
{
   public partial class NodeViewControl : UserControl
   {
      public NodeViewControl()
      {
         InitializeComponent();
         Visible = false;
      }
   }
}
