﻿namespace LogbookService {


   partial class WCFLogbookDataSet
   {

      partial class EntriesDataTable
      {
      }
   }
}
