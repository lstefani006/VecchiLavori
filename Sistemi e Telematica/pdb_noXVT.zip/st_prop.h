#ifndef __ST_PROP_H__
#define __ST_PROP_H__

template <class H, class T>
class Property
{
public:
	Property() {}
	Property(const Property<H, T> &r) { v = r.v; }
	~Property() {}

	Property<H, T> operator = (const Property<H, T> &r) { v = r.v; return *this; }

	T operator () () const { return v; }
	T & operator () (const T &a) { return v = a; }

protected:
	friend class H;
	T v;
};

#endif
