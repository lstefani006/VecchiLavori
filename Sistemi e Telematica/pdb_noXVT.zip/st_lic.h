#ifndef __ST_LIC_H__

#include <time.h>

/*
 * Verifica la scadenza della licenza del programma:
 * pFileName e` il file che contiene i dati di licenza ed e` strutturato
 * cosi`
 *           time_t DataScadenzaLicenza
 *           time_t DataUltimoControllo
 *     i campi sono scritti in ASCII con %010ld, sono separati da \n
 *     e criptati secondo il seguente algoritmo
 *         0123456789 --> 9173546280
 *     ossia si scambiano le cifre di posizione 0-9 2-7 4-5 di ogni
 *     numero %010ld
 *
 * (1) Se il file non esiste la licenza e` considerata scaduta
 * (2) Se DataUltimoControllo e` > della data di sistema la licenza e` scaduta
 * (3) Se DataScadenzaLicenza e` > della data di sistema la licenza e` scaduta
 *
 * Il caso (1) protegge da una scorretta installazione o cancellazione del
 * file.
 * Il caso (2) protegge se l'amministratore del sistema mette la data di
 * sistema indietro per protrarre la licenza
 * Il caso (3) verifica la data di scadenza vera e propria
 *
 * Ritorna 1 se la licenza e` Ok 0 se la licenza e` scaduta
 */
int Licenza(const char *pFileName);

/*
 * Genera il file Necessario alla funzione precedente.
 * La DataUltimoControllo e` la data di sistema
 * DataScadenza ha il formato YYYYMMDD
 * Ritorna 1 se il file e` stato generato, 0 altrimenti
 */
int GeneraFileLicenza(const char *pFileName, const char *DataScadenza);


#endif
