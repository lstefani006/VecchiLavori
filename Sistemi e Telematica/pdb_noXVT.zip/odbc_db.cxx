#ifdef ST_LIBDB_ODBC

#include <st_dbnew.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <strstream.h>

#include <st_err.h>
#include <st_dbdat.h>
#include <st_db.h>

#include "prtbl_d2.h"
#include "odbc_db.h"


#ifdef NO_TEMPLATES
	implement(STTVect, P_TIMESTAMP_STRUCT);
	implement(STTVect, P_SQLINTEGER);
	implement(STTVect, P_SDWORD);
#endif

static int S_NumConnections = 0;
      
STDbError Login(const char *pcUser, const char *pcPasswd, const char *pcHost,
		HENV &henv,
		HDBC &hdbc)
{
	STDbError DbError;
	do
	{
		RETCODE retcode;

		if (S_NumConnections == 0)
		{
			retcode = ::SQLAllocEnv(&henv);
			if (!(retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO))
			{
				DbError = ST_DB_NOT_AVAILABLE;
				henv = SQL_NULL_HENV;
				break;
			}
		}

		S_NumConnections += 1;

		retcode = ::SQLAllocConnect(henv, &hdbc);
		if (!(retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO))
		{
			DbError = ST_DB_NOT_AVAILABLE;
			break;
		}

		RWCString User = pcUser;
		RWCString Pwd  = pcPasswd;

		//@@RWCRegexp r("@.+");
		//@@RWCSubString rUser = User(r);
		//@@RWCSubString rPwd  = Pwd (r);

		RWCString rUser, rPwd;

		if (strchr(User, '@'))
			rUser = strchr(User, '@');
		if (strchr(Pwd, '@'))
			rPwd = strchr(Pwd, '@');

		RWCString DataSource;

		if (!rUser.isNull())
		{
			DataSource = &(rUser[1]);
			rUser = "";
		}
		if (!rPwd.isNull())
		{
			DataSource = &(rPwd[1]);
			rPwd = "";
		}

		const char *USER = User;
		const char *PWD  = Pwd;
		const char *DTS  = NULL;

		if (pcHost != NULL && pcHost[0] != '\0')
			DTS = pcHost;
		else
			DTS = DataSource;

		retcode = ::SQLConnect(hdbc,
				(UCHAR *)DTS,
				SQL_NTS,
				(UCHAR *)USER,
				SQL_NTS,
				(UCHAR *)PWD,
				SQL_NTS);
		if (!(retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO))
		{
			DbError = ST_DB_LOGIN_FAIL;
			break;
		}

		DbError = ST_DB_OK;
		break;
	}
	while (0);

	return DbError;
}

static STDbError Logout(HENV &henv, HDBC &hdbc)
{
	RETCODE r;

	r = ::SQLDisconnect(hdbc);
	if (!(r == SQL_SUCCESS || r == SQL_SUCCESS_WITH_INFO))
		return ST_DB_ERROR;

	r = ::SQLFreeConnect(hdbc);
	if (!(r == SQL_SUCCESS || r == SQL_SUCCESS_WITH_INFO))
		return ST_DB_ERROR;

	hdbc = SQL_NULL_HDBC;

	S_NumConnections -= 1;
	if (S_NumConnections <= 0)
	{
		r = ::SQLFreeEnv(henv);
		if (!(r == SQL_SUCCESS || r == SQL_SUCCESS_WITH_INFO))
			return ST_DB_ERROR;

		S_NumConnections = 0;
		henv = SQL_NULL_HENV;
	}

	return ST_DB_OK;
}


/*
 * ritorna l'errore SQL e in ErrorMessage iun testo che spiega l'errore
 * ErrorMessage deve essere lunga almeno SQL_MAX_MESSAGFE_LENGTH
 *
 */
static RWCString GetError(HENV henv, HDBC hdbc, HSTMT hstmt, RWCString &ErrorMessage)
{
	UCHAR  SqlState[20];
	SDWORD NativeError;
	SWORD  cbErrorMsg;
	UCHAR  szErrorMessage[SQL_MAX_MESSAGE_LENGTH];

	RETCODE r = SQLError(
			henv,
			hdbc,
			hstmt,
			SqlState,
			&NativeError,
			szErrorMessage,
			SQL_MAX_MESSAGE_LENGTH - 1,
			&cbErrorMsg);

	if (r == SQL_NO_DATA_FOUND)
	{
		// non c'e' stato nessun errore
		ErrorMessage = (const char *)szErrorMessage;
		return "";
	}
	else
	if (r == SQL_ERROR)
	{
		// c'e' un errore nella gestione di SQLError
		ErrorMessage = "SQLError ritorna error";
		return "ST001";
	}
	else
	{
		// errore correttamente ritornato
		ErrorMessage = (const char *)szErrorMessage;
		return RWCString((const char *)SqlState);
	}
}
static RWCString GetError(RWCString &ErrorMessage)                       { return GetError(SQL_NULL_HENV, SQL_NULL_HDBC, SQL_NULL_HSTMT, ErrorMessage); }
static RWCString GetError(HENV henv, RWCString &ErrorMessage)            { return GetError(henv,          SQL_NULL_HDBC, SQL_NULL_HSTMT, ErrorMessage); }
static RWCString GetError(HENV henv, HDBC hdbc, RWCString &ErrorMessage) { return GetError(henv,          hdbc,          SQL_NULL_HSTMT, ErrorMessage); }

////////////////////////////////////////////////////////////////////////////////

HENV DbConnectionOdbc::m_henv = SQL_NULL_HENV;


DbConnectionOdbc::DbConnectionOdbc()
{
	m_DbError = ST_DB_OK;
}

STDbError DbConnectionOdbc::Login(const char *pcUser, const char *pcPasswd, const char *pcHost)
{
	do
	{
		HDBC hdbc;

		m_DbError = ::Login(pcUser, pcPasswd, pcHost, m_henv, hdbc);
		if (m_DbError != ST_DB_OK)
			break;

		::Logout(m_henv, hdbc);

		m_DbError = ST_DB_OK;
		break;
	}
	while (0);

	if (m_DbError < 0)
		ST_Throw(STDbException(m_DbError, "Login"));

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_LOGIN_FAIL, "DbConnectionOdbc::Login() - internal error");
	return m_DbError;
}

STDbError DbConnectionOdbc::Logout()
{
	ST_COND_APPL(m_DbError == ST_DB_OK, "DbConnectionOdbc::Logout() - called with Login failed");
	return m_DbError;
}

DbConnectionOdbc::~DbConnectionOdbc()
{
}

RWCString DbConnectionOdbc::GetParameterMarker(int /* i */) const
{
	return "?";
}

RWCString DbConnectionOdbc::DbPrint(const DbVal *pDbVal) const
{
	if (pDbVal->IsNull())
		return RWCString("NULL");

	if (DynamicCast(DbString *, pDbVal))
	{
		DbString *pDbString = DynamicCast(DbString *, pDbVal);

		RWCString r("'");
		const char *p = *pDbString;

		while (*p)
		{
			if (*p == '\'')
				r.append(*p);
			r.append(*p);
			p++;
		}
		r.append("'");
		return r;
	}
	else if (DynamicCast(DbInt *, pDbVal))
	{
		DbInt *pDbInt = DynamicCast(DbInt *, pDbVal);
		char b[20];
		ostrstream s(b, sizeof(b));
		s << Int32(*pDbInt) << ends;
		return RWCString(b);
	}
	else if (DynamicCast(DbShort *, pDbVal))
	{
		DbShort *pDbShort = DynamicCast(DbShort *, pDbVal);
		char b[20];
		ostrstream s(b, sizeof(b));
		s << Int16(*pDbShort) << ends;
		return RWCString(b);
	}
	else if (DynamicCast(DbChar *, pDbVal))
	{
		DbChar *pDbChar = DynamicCast(DbChar *, pDbVal);
		const char c = *pDbChar;
		char b[20];
		ostrstream s(b, sizeof(b));
		s << "CHR(" << int(c) << ")" << ends;
		return RWCString(b);
	}
	else if (DynamicCast(DbDouble *, pDbVal))
	{
		DbDouble *pDbDouble = DynamicCast(DbDouble *, pDbVal);
		const double dd = *pDbDouble;
		char b[20];
		sprintf(b, "%.*f", pDbDouble->Sz2(), dd);
		return RWCString(b);
	}
	else if (DynamicCast(DbTS *, pDbVal))
	{
		DbTS *pDbTS = DynamicCast(DbTS *, pDbVal);

		char b[80];

		sprintf(b,
				"{ts '%04d-%02d-%02d %02d:%02d:%02d'}",
				pDbTS->year(),
				pDbTS->month(), 
				pDbTS->dayOfMonth(), 
				pDbTS->hour(), 
				pDbTS->minute(), 
				pDbTS->sec());
		return RWCString(b);
	}
	else if (DynamicCast(DbRaw *, pDbVal))
	{
		DbRaw *pDbRaw = DynamicCast(DbRaw *, pDbVal);

		unsigned char *pBuff = pDbRaw->GetBuff();

		RWCString r("'");
		for (int i = 0; i < pDbRaw->GetSize(); i++)
		{
			char b[3];
			sprintf(b, "%02x", int(pBuff[i]));
			r.append(b);
		}
		r.append("'");
		return r;
	}
	else
	{
		STError("DbConnectionOracle::DbPrint : unknown type");
		return RWCString("");
	}
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

DbTransactionOdbc::DbTransactionOdbc(DbConnectionOdbc &cn, const char *pcUser, const char *pcPasswd, const char *pcHost)
	: STDbTransactionData(cn),
	  m_DbError(ST_DB_OK),
	  m_bBegin(0)
{
	do
	{
		m_DbError = ::Login(pcUser, pcPasswd, pcHost, DbConnectionOdbc::m_henv, m_hdbc);
		break;
	}
	while (0);

	if (m_DbError == ST_DB_ERROR)
		ST_Throw(STDbException(m_DbError, "DbTransactionOdbc::DbTransactionOdbc()"));

	RWCString Error, Msg;
	{
		RETCODE retcode = ::SQLSetConnectOption(m_hdbc, SQL_AUTOCOMMIT, SQL_AUTOCOMMIT_OFF);
		Error = GetError(
				DbConnectionOdbc::m_henv,
				m_hdbc,
				Msg);

		switch (retcode)
		{
			case SQL_SUCCESS:
			case SQL_SUCCESS_WITH_INFO:
				m_DbError = ST_DB_OK;
				break;

			default:
				m_DbError = ST_DB_ERROR;
				break;
		}
	}
	if (m_DbError == ST_DB_ERROR)
		ST_Throw(STDbException(m_DbError, Error + " - " + Msg));

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_BEGINTRANSACTION_FAIL, "DbTransactionOdbc::BeginTransaction() - internal error");
}

STDbError DbTransactionOdbc::BeginTransaction()
{
	if (m_DbError == ST_DB_OK)
		m_bBegin = 1;

	return m_DbError;
}

STDbError DbTransactionOdbc::EndTransaction(STEndTransactionType cr)
{
	ST_COND_APPL(m_bBegin  == 1,        "DbTransactionOdbc::EndTransaction() - called before BeginTransaction");
	ST_COND_APPL(m_DbError == ST_DB_OK, "DbTransactionOdbc::EndTransaction() - called with previous error");

	m_bBegin = 0;

	RETCODE retcode;

	if (cr == STCommit)
		retcode = ::SQLTransact(DbConnectionOdbc::m_henv, m_hdbc, SQL_COMMIT);
	else
		retcode = ::SQLTransact(DbConnectionOdbc::m_henv, m_hdbc, SQL_ROLLBACK);

	RWCString Error, Msg;
	Error = GetError(
		DbConnectionOdbc::m_henv,
		m_hdbc,
		Msg);

	switch (retcode)
	{
	case SQL_SUCCESS:
	case SQL_SUCCESS_WITH_INFO:
		m_DbError = ST_DB_OK;
		break;

	default:
		m_DbError = ST_DB_ERROR;
		break;
	}

	/*
	     if (r && m_lda.rc == 1)    m_DbError = ST_DB_DUPL_KEY;
	else if (r && m_lda.rc == 1400) m_DbError = ST_DB_NULL_KEY;
	else if (r && m_lda.rc == 2292) m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_lda.rc == 2291) m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_lda.rc == 2290) m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_lda.rc == 60)   m_DbError = ST_DB_LOCK;
	else if (r && m_lda.rc == 4020) m_DbError = ST_DB_LOCK;
	else if (r && m_lda.rc == 104)  m_DbError = ST_DB_LOCK;
	else if (r)                     m_DbError = ST_DB_ERROR;
	else                            m_DbError = ST_DB_OK;
	*/

	if (m_DbError < 0)
		ST_Throw(STDbException(m_DbError, Error + " - " + Msg));

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_DUPL_KEY || m_DbError == ST_DB_LOCK, "DbTransactionOdbc::EndTransaction() - internal error");
	return m_DbError;
}

DbTransactionOdbc::~DbTransactionOdbc()
{
	if (m_bBegin)
		EndTransaction(STRollback);

	Logout(DbConnectionOdbc::m_henv, m_hdbc);
}

////////////////////////////////////////////////////////////////////////////////

DbStmtOdbc::DbStmtOdbc(DbTransactionOdbc &tro)
	: STDbStmtData(tro),
	  m_nDescribePos(1),
	  m_nBindPos(1),
	  m_DbError(ST_DB_OK),
	  m_bCursorOpen(0),
	  m_DbStack(10),
	  m_bNeedReset(0)
{
	ST_COND_APPL(&tro != 0, "DbStmtOdbc::DbStmtOdbc() - called with null DbTranctionOdbc");

	m_pDbTransactionOdbc = &tro;

	RETCODE retcode = ::SQLAllocStmt(m_pDbTransactionOdbc->m_hdbc, &m_hstmt);
	if (retcode != SQL_SUCCESS)
		m_DbError = ST_DB_ERROR;
	else
		m_DbError = ST_DB_OK;

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, "DbStmtOdbc"));

	m_bCursorOpen = 1;
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::DbStmtOdbc() - internal error");
}

STDbError DbStmtOdbc::Parse(const char *pcStmt)
{
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Parse() - internal error");
	ST_COND_LIBR(m_bCursorOpen == 1,    "DbStmtOdbc::Parse() - internal error");
	ST_COND_APPL(pcStmt    != 0,        "DbStmtOdbc::Parse() - null pcStmt");

	if (getenv("ST_DB_DEBUG"))
		STDebug("%s", pcStmt);

	m_nDescribePos = 1;
	m_nBindPos     = 1;
	m_DbStack.Reset();
	ClearStacks();

	RETCODE retcode = ::SQLPrepare(m_hstmt, (UCHAR *)pcStmt, SQL_NTS);

	RWCString Error, Msg;
	Error = GetError(
		DbConnectionOdbc::m_henv,
		m_pDbTransactionOdbc->m_hdbc,
		m_hstmt,
		Msg);

	switch (retcode)
	{
	case SQL_SUCCESS:
	case SQL_SUCCESS_WITH_INFO:
		m_DbError = ST_DB_OK;
		break;

	default:
		m_DbError = ST_DB_ERROR;
		break;
	}

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, Error + " - " + Msg));

	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Parse() - internal error");
	return m_DbError;
}



#ifndef NO_TEMPLATES
STDbError DbStmtOdbc::Parse(const char *pcStmt, const STTVect<DbVal *> &s)
#else
STDbError DbStmtOdbc::Parse(const char *pcStmt, const STTVect(P_DbVal) &s)
#endif
{
	STDbError e = Parse(pcStmt);

	if (e != ST_DB_OK)
		return e;

	for (int i = 0; i < s.Size(); i++)
	{
		DbVal *pDbVal = s[i];

		if (getenv("ST_DB_DEBUG"))
		{
			ostrstream s;
			RWCString r = DbPrint(pDbVal);
			s << "Valore \":" << i + 1 << "\" = \"" << r << "\"" << ends;
			STDebug("%s", s.str());
			s.rdbuf()->freeze(0);
		}

		SWORD       fParamType = SQL_PARAM_INPUT;
		SWORD       fCType;
		SWORD       fSqlType;
		UDWORD      cbColDef;
		SWORD       ibScale;
		PTR         rgbValue;
		SWORD       cbValueMax;
		SQLINTEGER *pcbValue = STNew SQLINTEGER;

		m_DbStack_cbValue.Append(pcbValue);
		

		if (DynamicCast(DbString *, pDbVal))
		{
			DbString *p = DynamicCast(DbString *, pDbVal);
			fCType     = SQL_C_CHAR;
			fSqlType   = SQL_VARCHAR;
			cbColDef   = pDbVal->GetDbSize();
			ibScale    = 0;
			rgbValue   = (PTR)pDbVal->GetDbAddress();
			cbValueMax = 0;
			*pcbValue  = SQL_NTS;
		}
		else
		if (DynamicCast(DbInt    *, pDbVal))
		{
			fCType     = SQL_C_LONG;
			fSqlType   = SQL_INTEGER;
			cbColDef   = 0;
			ibScale    = 0;
			rgbValue   = (PTR)pDbVal->GetDbAddress();
			cbValueMax = 0;
			*pcbValue  = sizeof(Int32);
		}
		else
		if (DynamicCast(DbShort  *, pDbVal)) 
		{
			fCType     = SQL_C_SHORT;    
			fSqlType   = SQL_SMALLINT;
			cbColDef   = 0;
			ibScale    = 0;
			rgbValue   = (PTR)pDbVal->GetDbAddress();
			cbValueMax = 0;
			*pcbValue  = sizeof(Int16);
		}
		else
		if (DynamicCast(DbChar   *, pDbVal)) 
		{ 
			fCType     = SQL_C_CHAR;    
			fSqlType   = SQL_CHAR;
			cbColDef   = 1;
			ibScale    = 0;
			rgbValue   = (PTR)pDbVal->GetDbAddress();
			cbValueMax = 0;
			*pcbValue  = sizeof(char);
		}
		else
		if (DynamicCast(DbDouble *, pDbVal)) 
		{ 
			fCType     = SQL_C_DOUBLE;    
			fSqlType   = SQL_DOUBLE;
			cbColDef   = 0;
			ibScale    = 0;
			rgbValue   = (PTR)pDbVal->GetDbAddress();
			cbValueMax = 0;
			*pcbValue  = sizeof(double);
		}
		else
		if (DynamicCast(DbTS     *, pDbVal)) 
		{ 
			DbTS *p = DynamicCast(DbTS *, pDbVal);

			TIMESTAMP_STRUCT *ts = STNew TIMESTAMP_STRUCT;
			ts->year     = p->year();     
			ts->month    = p->month();    
			ts->day      = p->dayOfMonth();
			ts->hour     = p->hour();       
			ts->minute   = p->minute();     
			ts->second   = p->sec();           
			ts->fraction = 0;

			m_DbStack_Where_TS.Append(ts);

			fCType     = SQL_C_TIMESTAMP;    
			fSqlType   = SQL_TIMESTAMP;
			cbColDef   = 23;
			ibScale    = 0;
			rgbValue   = (PTR) ts;
			cbValueMax = 0;
			*pcbValue   = sizeof(TIMESTAMP_STRUCT);
		}
		else
		if (DynamicCast(DbRaw *, pDbVal)) 
		{ 
			fCType     = SQL_C_BINARY;    
			fSqlType   = SQL_LONGVARBINARY;
			cbColDef   = pDbVal->GetDbSize();
			ibScale    = 0;
			rgbValue   = (PTR) pDbVal->GetDbAddress();
			cbValueMax = pDbVal->GetDbSize();
			*pcbValue  = pDbVal->GetDbSize();
		}
		else
		{
			m_DbError = ST_DB_ERROR;
			ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Parse() - DataType derived variable unknown");
		}


		if (pDbVal->IsNull())
			*pcbValue = SQL_NULL_DATA;


		RETCODE retcode = ::SQLBindParameter(
				m_hstmt,
				i + 1,
				fParamType,
				fCType,
				fSqlType,
				cbColDef,
				ibScale,
				rgbValue,
				cbValueMax,
				pcbValue);

		RWCString Error, Msg;
		Error = GetError(
				DbConnectionOdbc::m_henv,
				m_pDbTransactionOdbc->m_hdbc,
				m_hstmt,
				Msg);
		switch (retcode)
		{
			case SQL_SUCCESS:
			case SQL_SUCCESS_WITH_INFO:
				m_DbError = ST_DB_OK;
				break;

			default:
				m_DbError = ST_DB_ERROR;
				break;
		}

		if (m_DbError < 0)
			ST_Throw (STDbException(m_DbError, Error + " - " + Msg));

		ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Parse() - internal error");
	}

	return ST_DB_OK;
}


STDbError DbStmtOdbc::Bind(DbVal *pDbVal)
{
	ST_COND_LIBR(m_bCursorOpen == 1,    "DbStmtOdbc::Bind() - internal error");
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Bind() - internal error");


	if (m_bNeedReset)
	{
		m_bNeedReset = 0;

		int i;
		for (i = 0; i < m_DbStack_TS.Size(); i++)
			STDelete m_DbStack_TS[i];

		for (i = 0; i < m_DbStack_NULL.Size(); i++)
			STDelete m_DbStack_NULL[i];

		m_DbStack_TS.Reset();
		m_DbStack_NULL.Reset();
		m_DbStack.Reset();
	}

	SWORD       fCType;
	PTR         rgbValue;
	SWORD       cbValueMax;
	SQLINTEGER *pcbValue;

	if (DynamicCast(DbString *, pDbVal))
	{
		fCType     = SQL_C_CHAR;
		rgbValue   = (PTR)pDbVal->GetDbAddress();
		cbValueMax = pDbVal->GetDbSize();
	}
	else
	if (DynamicCast(DbInt    *, pDbVal))
	{
		fCType     = SQL_C_LONG;
		rgbValue   = (PTR)pDbVal->GetDbAddress();
		cbValueMax = 0;
	}
	else
	if (DynamicCast(DbShort  *, pDbVal)) 
	{
		fCType     = SQL_C_SHORT;    
		rgbValue   = (PTR)pDbVal->GetDbAddress();
		cbValueMax = 0;
	}
	else
	if (DynamicCast(DbChar   *, pDbVal)) 
	{ 
		fCType     = SQL_C_CHAR;    
		rgbValue   = (PTR)pDbVal->GetDbAddress();
		cbValueMax = sizeof(char) + sizeof(char);
	}
	else
	if (DynamicCast(DbDouble *, pDbVal)) 
	{ 
		fCType = SQL_C_DOUBLE;    
		rgbValue   = (PTR)pDbVal->GetDbAddress();
		cbValueMax = 0;
	}
	else
	if (DynamicCast(DbTS     *, pDbVal)) 
	{ 
		TIMESTAMP_STRUCT *ts = STNew TIMESTAMP_STRUCT;
		memset(ts, '\0', sizeof(*ts));
		m_DbStack_TS.Append(ts);

		fCType     = SQL_C_TIMESTAMP;    
		rgbValue   = (PTR) ts;
		cbValueMax = sizeof(TIMESTAMP_STRUCT);
	}
	else
	if (DynamicCast(DbRaw *, pDbVal)) 
	{ 
		fCType     = SQL_C_BINARY;    
		rgbValue   = (PTR) pDbVal->GetDbAddress();
		cbValueMax = pDbVal->GetDbSize();
	}
	else
	{
		m_DbError = ST_DB_ERROR;
		ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Bind() - DataType derived variable unknown");
	}

	pcbValue = STNew SDWORD;
	m_DbStack_NULL.Append(pcbValue);

	m_DbStack.Append(pDbVal);


	RETCODE retcode = ::SQLBindCol(
			m_hstmt,
			m_nBindPos++,
			fCType,
			rgbValue,
			cbValueMax,
			pcbValue);

	RWCString Error, Msg;
	Error = GetError(
			DbConnectionOdbc::m_henv,
			m_pDbTransactionOdbc->m_hdbc,
			m_hstmt,
			Msg);
	switch (retcode)
	{
	case SQL_SUCCESS:
	case SQL_SUCCESS_WITH_INFO:
		m_DbError = ST_DB_OK;
		break;

	default:
		m_DbError = ST_DB_ERROR;
		break;
	}

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, Error + " - " + Msg));

	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Bind() - internal error");
	return m_DbError;
}

STDbError DbStmtOdbc::Exec(long &nNumOfProcessedRows)
{
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Exec() - internal error");

	RETCODE retcode = ::SQLExecute(m_hstmt);

	RWCString Error, Msg;
	Error = GetError(
			DbConnectionOdbc::m_henv,
			m_pDbTransactionOdbc->m_hdbc,
			m_hstmt,
			Msg);
	switch (retcode)
	{
		case SQL_SUCCESS:
		case SQL_SUCCESS_WITH_INFO:
			m_DbError = ST_DB_OK;
			break;

		default:
			m_DbError = ST_DB_ERROR;
			break;
	}

	if (Error == "23000") m_DbError = ST_DB_DUPL_KEY;
	if (Error == "S1000")
	{
		if (strstr(Msg, "Access") && 
				strstr(Msg, "Duplicate value in index"))
			m_DbError = ST_DB_DUPL_KEY;

		if (strstr(Msg, "Unique constraint"))
			m_DbError = ST_DB_DUPL_KEY;
	}




	/*

	     if (r && m_Cursor.rc == 1)                            m_DbError = ST_DB_DUPL_KEY;
	else if (r && m_Cursor.rc == 1400)                         m_DbError = ST_DB_NULL_KEY;
	else if (r && m_Cursor.rc == 2292)                         m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_Cursor.rc == 2291)                         m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_Cursor.rc == 2290)                         m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_Cursor.rc == 60)                           m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 4020)                         m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 104)                          m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 54)                           m_DbError = ST_DB_LOCK; // lock table nowait o select for update nowait
	else if (r)                                                m_DbError = ST_DB_ERROR;
	else if (r == 0 && m_Cursor.fc == 9 && m_Cursor.rpc == 0)  m_DbError = ST_DB_NOT_FOUND;  // delete
	else if (r == 0 && m_Cursor.fc == 5 && m_Cursor.rpc == 0)  m_DbError = ST_DB_NOT_FOUND;  // update
	else                                                       m_DbError = ST_DB_OK;

	*/

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, Error + " - " + Msg));

	SDWORD n;
	::SQLRowCount(m_hstmt, &n);

	nNumOfProcessedRows = n;

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_DUPL_KEY || m_DbError == ST_DB_NOT_FOUND || m_DbError == ST_DB_LOCK, "DbStmtOdbc::Exec() - internal error");
	return m_DbError;
}


STDbError DbStmtOdbc::Fetch()
{
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Fetch() - internal error");

	RETCODE retcode = ::SQLFetch(m_hstmt);

	RWCString Error, Msg;
	Error = GetError(
			DbConnectionOdbc::m_henv,
			m_pDbTransactionOdbc->m_hdbc,
			m_hstmt,
			Msg);
	switch (retcode)
	{
	case SQL_NO_DATA_FOUND:
		m_DbError = ST_DB_NOT_FOUND;
		break;

	case SQL_SUCCESS:
	case SQL_SUCCESS_WITH_INFO:
		m_DbError = ST_DB_OK;
		break;

	default:
		m_DbError = ST_DB_ERROR;
		break;
	}

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, Error + " - " + Msg));

	/*
	int r = ofetch(&m_Cursor);

	     if (r && m_Cursor.rc == NO_DATA_FOUND) m_DbError = ST_DB_NOT_FOUND;
	else if (r && m_Cursor.rc == 60)            m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 4020)          m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 104)           m_DbError = ST_DB_LOCK;
	else if (r)                                 m_DbError = ST_DB_ERROR; 
	else                                        m_DbError = ST_DB_OK; 

	*/

	if (m_DbError == ST_DB_OK)
	{
		int nTS = 0; // contatori di TS nel m_DbStack_TS

		for (int i = 0; i < m_DbStack.Size(); i++)
		{
			DbVal *pDbVal = m_DbStack[i];
			SDWORD *pcbValue = m_DbStack_NULL[i];

			if (*pcbValue == SQL_NULL_DATA)
			{
				pDbVal->PostFetchNull(1);

				if (DynamicCast(DbTS *, pDbVal)) 
					nTS++;

				continue;
			}
			else
				pDbVal->PostFetchNull(0);


			if (DynamicCast(DbString *, pDbVal))
			{
				DbString *p = DynamicCast(DbString *, pDbVal);
				p->KillLastBlanks();

				if (*p == "")
					p->PostFetchNull(1);
			}
			else
			if (DynamicCast(DbInt *, pDbVal))
			{
			}
			else
			if (DynamicCast(DbShort *, pDbVal)) 
			{
			}
			else
			if (DynamicCast(DbChar *, pDbVal)) 
			{ 
			}
			else
			if (DynamicCast(DbDouble *, pDbVal)) 
			{ 
			}
			else
			if (DynamicCast(DbTS *, pDbVal)) 
			{ 
				DbTS *p = DynamicCast(DbTS *, pDbVal);

				TIMESTAMP_STRUCT *ts = m_DbStack_TS[nTS++];
				DbTS aa(
						ts->year,
						ts->month,
						ts->day,
						ts->hour,
						ts->minute,
						ts->second);
				*p = aa;
			}
			else
			if (DynamicCast(DbRaw *, pDbVal)) 
			{
			}
			else
			{
				m_DbError = ST_DB_ERROR;
				ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Fetch() - DataType derived variable unknown");
			}
		}	
	}

	m_nBindPos = 1;

	m_bNeedReset = 1; // se poi si fa un'altra Bind bisogna resettare il m_DbStack

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_NOT_FOUND || m_DbError == ST_DB_LOCK, "DbStmtOdbc::Fetch() - internal error");
	return m_DbError;
}


STDbError DbStmtOdbc::Describe(RWCString &strColName, DbVal *&rpDbVal)
{
	/*
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOdbc::Describe() - internal error");

	sword pos = m_nDescribePos;

	sb4 dbsize;
	sb2 dbtype;
	sb1 cbuf[256];
	sb4 cbufl = sizeof(cbuf);
	sb4 dsize;
	sb2 prec;
	sb2 scale;
	sb2 nullok;

	int r = odescr(&m_Cursor,
	               pos,
	               &dbsize,
	               &dbtype,
	               cbuf,
	               &cbufl,
	               &dsize,
	               &prec,
	               &scale,
	               &nullok);

	     if (r && m_Cursor.rc == VAR_NOT_IN_LIST) m_DbError = ST_DB_NOT_FOUND;
	else if (r)                                   m_DbError = ST_DB_ERROR;
	else                                          m_DbError = ST_DB_OK;


	if (m_DbError == ST_DB_OK)
	{
		cbuf[cbufl] = '\0';

		// cerr << cbuf << ":\n";
		// cerr << "dbsize:" << dbsize << "\n";
		// cerr << "dbtype:" << dbtype << "\n";
		// cerr << "dsize :" << dsize  << "\n";
		// cerr << "prec  :" << prec   << "\n";
		// cerr << "scale :" << scale  << "\n";
		// cerr << "nullok:" << nullok << "\n";

		int nInternalOdbcType = dbtype;

		switch (nInternalOdbcType)
		{
		case SQLT_CHR: //  1 (VARCHAR2)
		case SQLT_AFC: // 96 (CHAR)
			rpDbVal = STNew DbString(dbsize);
			break;

		case SQLT_BIN: // 23 (RAW)
			rpDbVal = STNew DbRaw(dbsize);
			break;

		case SQLT_NUM: //  2 (NUMBER)
			     if (prec < 5  && scale == 0) rpDbVal = STNew DbShort(prec);
			else if (prec < 10 && scale == 0) rpDbVal = STNew DbInt(prec);
			else                              rpDbVal = STNew DbDouble(prec, scale);
			break;
	
		case SQLT_DAT: // 12 (DATE)
			rpDbVal = STNew DbTS;
			break;

		default:
			ST_COND_LIBR(0, "DbStmtOdbc::Descride() - oracle dbtype variable unknown");
		}

		strColName = (char *)cbuf;

		m_nDescribePos += 1;

		m_DbError = ST_DB_OK;
	}

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, err_report(this)));

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_NOT_FOUND, "DbStmtOdbc::Describe() - internal error");
	*/
	return m_DbError;
}

DbStmtOdbc::~DbStmtOdbc()
{
	ClearStacks();

	if (m_bCursorOpen)
	{
		m_bCursorOpen = 0;

		RETCODE retcode = ::SQLFreeStmt(m_hstmt, SQL_DROP);

		RWCString Error, Msg;
		Error = GetError(
				DbConnectionOdbc::m_henv,
				m_pDbTransactionOdbc->m_hdbc,
				m_hstmt,
				Msg);
		switch (retcode)
		{
		case SQL_SUCCESS:
		case SQL_SUCCESS_WITH_INFO:
			m_DbError = ST_DB_OK;
			break;

		default:
			m_DbError = ST_DB_ERROR;
			break;
		}

		if (m_DbError < 0)
			ST_Throw (STDbException(m_DbError, Error + " - " + Msg));
	}
}

void DbStmtOdbc::ClearStacks()
{
	int i;

	for (i = 0; i < m_DbStack_Where_TS.Size(); i++)
		STDelete m_DbStack_Where_TS[i];

	for (i = 0; i < m_DbStack_TS.Size(); i++)
		STDelete m_DbStack_TS[i];

	for (i = 0; i < m_DbStack_cbValue.Size(); i++)
		STDelete m_DbStack_cbValue[i];

	for (i = 0; i < m_DbStack_NULL.Size(); i++)
		STDelete m_DbStack_NULL[i];

	m_DbStack_Where_TS.Reset();
	m_DbStack_TS.Reset();
	m_DbStack_cbValue.Reset();
	m_DbStack_NULL.Reset();
}


#endif // ST_LIBDB_ODBC
