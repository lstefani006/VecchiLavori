#ifndef __ST_DIZ_H__
#define __ST_DIZ_H__

//@@#include <rw/cstring.h>
//@@#include <rw/hashdict.h>

#include <string.h>
#include <st_tvect.h>

#include <libdb_it.lnh>


class RWCString
{
public:
	RWCString() { m_pt = strdup(""); }
	RWCString(const char *p) { m_pt = strdup(p); }
	RWCString(const char *p, int len) {
		m_pt = (char *) malloc(len + 1);
		strncpy(m_pt, p, len);
		m_pt[len] = 0;
	}

	RWCString(const RWCString &r) { m_pt = strdup(r.m_pt); }
	~RWCString() { free(m_pt); }
	void operator = (const RWCString &r) {
		free(m_pt);
		m_pt = strdup(r.m_pt); }
	void operator = (const char *p) {
		free(m_pt);
		m_pt = strdup(p); }
	
	operator const char * () const { return m_pt; }
	const char * data() const { return m_pt; }

	bool isNull() const { return strlen(m_pt) == 0; }
	int length() const  { return strlen(m_pt); }
	void append(const char *p) {
		char *n = (char *)malloc(strlen(m_pt) + strlen(p) + 1);
		strcpy(n, m_pt);
		strcat(n, p);
	}

	void append(char c)
	{
		char b[2];
		b[0] = c; b[1] = 0;
		append(b);
	}

	void toLower() { strlwr(m_pt); }
	void toUpper() { strupr(m_pt); }

#define RW_NPOS (-1)
	int index(const char *p, int pos = 0) {
		char *np = strstr(m_pt + pos, p);
		if (np)
			return np - p;
		else
			return RW_NPOS;
	}

	void remove(int pos, int len = 1)
	{
		RWCString r(*this);
		strcpy(m_pt + pos, r.m_pt + pos + len);
	}

	void operator += (const char *p) { append(p); }

	char & operator () (int i) { return m_pt[i]; }
	const char & operator [] (int i) const { return m_pt[i]; }

	void insert(int pos, const char *str)
	{
		RWCString r(m_pt, pos);
		r.append(str);
		r.append(m_pt + pos);
		*this = r;
	}

	void insert(int pos, char c)
	{
		char b[2];
		b[0] = c; b[1] = 0;
		insert(pos, b);
	}
protected:
	char *m_pt;
};

inline RWCString operator + (const RWCString &a, const RWCString &b) {
	RWCString r(a);
	r.append(b);
	return r;
}

class RWTime
{
public:
	RWTime() { m_YYYY = m_MM = m_DD = m_hh = m_mm = m_ss = 0; }
	RWTime(int YYYY, int MM, int DD, int hh, int mm, int ss) {
		m_YYYY = YYYY;
		m_MM   = MM;
		m_DD   = DD;
		m_hh   = hh;
		m_mm   = mm;
		m_ss   = ss; }
	RWTime(const RWTime &r) {
		m_YYYY = r.m_YYYY;
		m_MM   = r.m_MM;
		m_DD   = r.m_DD;
		m_hh   = r.m_hh;
		m_mm   = r.m_mm;
		m_ss   = r.m_ss; }
	void operator = (const RWTime &r) {
		m_YYYY = r.m_YYYY;
		m_MM   = r.m_MM;
		m_DD   = r.m_DD;
		m_hh   = r.m_hh;
		m_mm   = r.m_mm;
		m_ss   = r.m_ss; }
	int year()  const { return m_YYYY; }
	int month() const { return m_MM; }
	int dayOfMonth() const { return m_DD; }
	int hour() const { return m_hh; }
	int minute() const { return m_mm; }
	int sec() const { return m_ss; }

	int Compare (const RWTime &) const;

protected:
	int m_YYYY;
	int m_MM;
	int m_DD;
	int m_hh;
	int m_mm;
	int m_ss;
};


inline int RWTime::Compare(const RWTime &b) const
{
	if (m_YYYY > b.m_YYYY) return 1;
	if (m_YYYY < b.m_YYYY) return -1;

	if (m_MM   > b.m_MM)   return 1;
	if (m_MM   < b.m_MM)   return -1;

	if (m_DD   > b.m_DD)   return 1;
	if (m_DD   < b.m_DD)   return -1;

	if (m_hh   > b.m_hh)   return 1;
	if (m_hh   < b.m_hh)   return -1;

	if (m_mm   > b.m_mm)   return 1;
	if (m_mm   < b.m_mm)   return -1;

	if (m_ss   > b.m_ss)   return 1;
	if (m_ss   < b.m_ss)   return -1;

	return 0;
}

inline bool operator == (const RWTime &a, const RWTime &b)
{
	return a.Compare(b) == 0;
}

inline bool operator != (const RWTime &a, const RWTime &b)
{
	return a.Compare(b) != 0;
}

inline bool operator > (const RWTime &a, const RWTime &b)
{
	return a.Compare(b) > 0;
}

inline bool operator < (const RWTime &a, const RWTime &b)
{
	return a.Compare(b) < 0;
}


#ifdef NO_TEMPLATES
	#ifndef D_STTVectRWCString
		#define D_STTVectRWCString
		declare(STTVect, RWCString);
	#endif
#endif

extern class STDizionario *G_Diz;

class STDizWordKey
{
public:
	explicit STDizWordKey() { e = MSG_LIBDB_NULL; }
	explicit STDizWordKey(int v) { e = v; }
	explicit STDizWordKey(const STDizWordKey &r) { e = r.e; }
	void operator = (const STDizWordKey &r) { e = r.e; }
	bool IsOk() const { return e == MSG_LIBDB_NULL; }
private:
	int e;

};


class STDizionario
{
public:
	STDizionario();
	~STDizionario();

	bool Load(const RWCString &theDictionaryFile);

	bool GetWord(const STDizWordKey &aKey) const;
	RWCString GetLanguage(void) const;
};

// definizioni per mantenere la compatibilita' nella versione precedente
typedef STDizionario Dizionario;
#define WordKey STDizWordKey 

#endif
