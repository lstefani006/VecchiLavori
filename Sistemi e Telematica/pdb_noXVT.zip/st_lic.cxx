#include <stdio.h>
#include <string.h>

#include <st_lic.h>

/*
 * LEO in questo file ci sono delle cablature sui tipi a causa dei
 * %d %ld ecc.
 * L'uso di questo file per Win3.1 a 16 bit necessita una revisione
 */


static void Crypt(char *p)
{
	for (int i = 0; i <= 4; i += 2)
	{
		char c = p[i];
		p[i] = p[9 - i];
		p[9 - i] = c;
	}
}

static int TuttiNumeri(const char *p)
{
	while (*p)
	{
		if (*p < '0' || *p > '9')
			return 0;
		p++;
	}
	return 1;
}

int GeneraFileLicenza(const char *pFileName, const char *strDataDiScadenza)
{
	FILE *f = fopen(pFileName, "w");
	if (f == NULL)
		return 0;

	int yyyy, mm, dd;
	int r = sscanf(strDataDiScadenza, "%4d%2d%2d", &yyyy, &mm, &dd);
	if (r != 3)
		return 0;

	struct tm t;
	t.tm_sec   = 0;
	t.tm_min   = 0;
	t.tm_hour  = 0;
	t.tm_mday  = dd;
	t.tm_mon   = mm - 1;
	t.tm_year  = yyyy - 1900;
	t.tm_wday  = 0;
	t.tm_yday  = 0;
	t.tm_isdst = 0;
	time_t DataDiScadenza = mktime(&t);
	if (DataDiScadenza == (time_t) -1)
		return 0;

	char b[12];
	sprintf(b, "%010d", DataDiScadenza);
	Crypt(b);
	fprintf(f, "%s\n", b);

	sprintf(b, "%010d", time(NULL));
	Crypt(b);
	fprintf(f, "%s\n", b);

	fclose(f);
	return 1;
}

int Licenza(const char *pFileName)
{
	if (pFileName == NULL)
		return 0;

	FILE *f = fopen(pFileName, "r");
	if (f == NULL)
		return 0;

	char DataScadenzaLicenza[12];
	char DataUltimoControllo[12];

	int r = fscanf(f, "%11s %11s", DataScadenzaLicenza, DataUltimoControllo);
	if (r != 2)
		return 0;

	fclose(f);

	if (strlen(DataScadenzaLicenza) != 10)
		return 0;

	if (strlen(DataUltimoControllo) != 10)
		return 0;

	r = TuttiNumeri(DataScadenzaLicenza);
	if (r == 0)
		return 0;

	r = TuttiNumeri(DataUltimoControllo);
	if (r == 0)
		return 0;

	Crypt(DataScadenzaLicenza);
	Crypt(DataUltimoControllo);

	time_t dataScadenzaLicenza;
	time_t dataUltimoControllo;

#ifndef A_OSF
	const char *pMask = "%ld";
#else
	const char *pMask = "%d";   /* Sotto OSF gli %ld sono interi a 64 bit */
#endif

	r = sscanf(DataScadenzaLicenza, pMask, &dataScadenzaLicenza);
	if (r != 1)
		return 0;

	r = sscanf(DataUltimoControllo, pMask, &dataUltimoControllo);
	if (r != 1)
		return 0;

	if (time(NULL) < dataUltimoControllo)
		return 0;

	if (time(NULL) > dataScadenzaLicenza)
		return 0;

	struct tm t = *localtime(&dataScadenzaLicenza);
	char b[20];
	sprintf(b, "%04d%02d%02d", t.tm_year + 1900,
			t.tm_mon + 1,
			t.tm_mday);

	r = GeneraFileLicenza(pFileName, b);
	return r;
}


#if 0


#include <time.h>
#include <stdlib.h>

#include <st_dbnew.h>
#include <st_dbxx.h>
#include "st_lic.h"

static int EseguiSQL(const char *pLogin, const char *pPwd, const char *pStmt)
{
	STDbError e;

	STDbConnection cn;

	e = cn.Login(pLogin, pPwd);
	if (e == ST_DB_LOGIN_FAIL)
		return 0;

	STDbTransaction tr(cn);
	tr.BeginTransaction();

	STDbStmt st(tr);
	st.Parse(pStmt);
	st.Exec();
	
	tr.EndTransaction(STCommit);

	return 1;
}
void main()
{
	GeneraFileLicenza("q.lic", "19961026");
	int r = Licenza("q.lic");

	if (r == 0)
	{
		EseguiSQL( getenv("ST_SETSHIP_LOGIN"), getenv("ST_SETSHIP_PWD"),
			"rename viaggio to tviaggio");
		EseguiSQL( getenv("ST_SETSHIP_LOGIN"), getenv("ST_SETSHIP_PWD"),
			"rename cliente to tcliente");
		EseguiSQL( getenv("ST_SETSHIP_LOGIN"), getenv("ST_SETSHIP_PWD"),
			"rename cargo to tcargo");
		EseguiSQL( "plansaqr", "plansaqr",
			"rename p_viaggio to tp_viaggio");
		EseguiSQL( "plansaqr", "plansaqr",
			"rename p_navi to tp_navi");
	}
}

#endif
