#include <st_dbnew.h>
#include "st_err.h"
#include "st_slist.h"

inline STSlist::STSlink::STSlink(STRoot *p)
{
	m_pSTRoot = p;
	m_pNext   = 0;
}

STSlist::STSlink::~STSlink()
{
}

//////////////////////////////////////////////////////////////////

STImplementClassInfo1(STSlist, STRoot)
STImplementAssignClone(STSlist)

STSlist::STSlist()
	: m_pLast(0)
{                                 
}

STSlist::STSlist(const STSlist &s)
	: m_pLast(0)
{
	STSlistIterator it(s);
	
	STRoot *p;
	while ((p = it()) != 0)
		AddTail(p->STClone());
}



STSlist::~STSlist()
{
	Clear();
}

void STSlist::Clear()
{
	if (m_pLast == 0)
		return;
		
	STSlink *pSlink = m_pLast;
	do
	{
		STDelete pSlink->m_pSTRoot;         // cancello il dato puntato
		STSlink *ll = pSlink;             // memorizzo questo link
		pSlink = pSlink->m_pNext;         // vado al prossimo
		STDelete ll;                        // cancello il link
	}
	while (pSlink != m_pLast);
	
	m_pLast = 0;
}

void STSlist::AddHead(STRoot *a)
{
	STSlink *t = STNew STSlink(a);

	if (m_pLast)
	{      
		t->m_pNext = m_pLast->m_pNext; 
		m_pLast->m_pNext = t;       // la lista esiste gia'    
	}
	else
	{
		m_pLast = t;
		m_pLast->m_pNext = m_pLast;
	}
}


void STSlist::AddTail(STRoot *a)
{
	STSlink *t = STNew STSlink(a);

	if (m_pLast)
	{
		t->m_pNext = m_pLast->m_pNext; // put a at head of list
		m_pLast = m_pLast->m_pNext = t;// then move tail pointer
	}
	else
	{
		m_pLast = t;       // New first item
		m_pLast->m_pNext = m_pLast;
	}
}

STRoot * STSlist::GetHead()
{
	if (m_pLast == 0)
		return 0;

	STSlink *f = m_pLast->m_pNext;
	STRoot  *p = f->m_pSTRoot;

	if (f == m_pLast)
		m_pLast = 0;
	else
		m_pLast->m_pNext = f->m_pNext;

	STDelete f;

	return p;
}

STRoot * STSlist::Remove(STRoot *p)
{
	if (m_pLast == 0)
		return 0;

	if (m_pLast->m_pNext == m_pLast)
	{
		// un solo elemento nella lista
		if (m_pLast->m_pSTRoot == p)
		{
			STDelete m_pLast;
			m_pLast = 0;

			return p;
		}
		else
			return p;
	}

	STSlink *pt = m_pLast;
	do
	{
		if (pt->m_pNext->m_pSTRoot == p)
		{
			STSlink *s = pt->m_pNext;
			pt->m_pNext = pt->m_pNext->m_pNext;

			if (m_pLast == s)
				m_pLast = pt;

			STDelete s;
			
			return p;
		}
		pt = pt->m_pNext;

	}
	while (pt != m_pLast);

	return 0;
}


STRoot * STSlist::Search(STRoot *p) const
{
	STSlistIterator it(*this);
	STRoot *l;
	while ((l = it()) != 0)
		if (l == p)
			return p;
	return 0;
}

int STSlist::nOfItems() const
{
	int n = 0;
	STSlistIterator it(*this);

	while (it() != 0)
		++n;
	return n;
}

void STSlist::operator = (const STSlist &s)
{
	if (this == &s)
		return;

	Clear();
	
	STSlistIterator it(s);
	STRoot *p;

	while ((p = it()) != 0)
		AddTail(p->STClone());
}

/////////////////////////////////////////////////////////////

int STSlist::STIsEqual(const STRoot *p) const
{
	const STSlist *pSTSlist = DynamicCast(STSlist *, p);
	if (pSTSlist == 0)
		return 0;
	
	STSlistIterator ita(*pSTSlist);
	STSlistIterator itb(*this);

	for (;;)
	{
		STRoot * a = ita();
		STRoot * b = itb();

		if (a == 0 && b == 0)
			return 1;

		if (a == 0 || b == 0)
			return 0;

		if (a->STIsEqual(b) == 0)
			return 0;
	}
}

/////////////////////////////////////////////////////////////////

void static inline Swap(STRoot *&a, STRoot *&b)
{
	STRoot *t = a;
	a = b;
	b = t;
}

static int Rearr(STRoot **pTable, int lb, int ub, int (*Compare)(const STRoot *a, const STRoot *b))
{
	do
	{
		while (ub > lb && Compare(pTable[ub], pTable[lb]) > 0)
			ub--;

		if (ub != lb)
		{
			Swap(pTable[ub], pTable[lb]);
			while (lb < ub && Compare(pTable[lb], pTable[ub]) <= 0)
				lb++;
			if (lb != ub)
				Swap(pTable[lb], pTable[ub]);
		}
	}
	while (lb != ub);

	return lb;
}

static void Sort(STRoot **pTable, int lb, int ub, int (*Compare)(const STRoot *a, const STRoot *b))
{
	if (lb < ub)
	{
		int j = Rearr(pTable, lb, ub, Compare);
		if (j)
			Sort(pTable, lb, j - 1, Compare);
		Sort(pTable, j + 1, ub, Compare);
	}
}

void STSlist::Sort(int (*Compare)(const STRoot *a, const STRoot *b))
{
	int n = nOfItems();
	STRoot **pTable = STNew STRoot * [n];

	STRoot *p;
	int i = 0;
	while (p = GetHead())
		pTable[i++] = p;
	
	::Sort(pTable, 0, n - 1, Compare);

	for (i = 0; i < n; i++)
		AddTail(pTable[i]);

	STDelete [] pTable;
}

//////////////////////////////////////////////////////////////////


STSlistIterator::STSlistIterator(const STSlist &s)
{
	cs = &s;
	ce = 0;
}

STRoot * STSlistIterator::operator ()()
{
	if (cs->m_pLast == 0)
		return 0;
	else	
	if (ce == 0)
	{
		ce = cs->m_pLast->m_pNext;
		return ce->m_pSTRoot;
	}
	else	
	if (ce == cs->m_pLast)
	{
		ce = 0;
		return 0;
	}
	else
	{
		ce = ce->m_pNext;
		return ce->m_pSTRoot;
	}
}
