#include <st_dbnew.h>
/*********************************************************************
 *
   Copyright (c) 1995

   File Name:		STDizionario.cxx

   Author:              Marco Cresta
   Date:                2/3/95

   Class:               STDizionario

								     *
 *********************************************************************/

#include "st_diz.h"
#include "st_err.h"

#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>


STDizionario *G_Diz = NULL;



