#include <st_dbnew.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>

#include "st_root.h"
#include "st_err.h"

#if defined(__DECCXX) && !defined(NO_TEMPLATES)
	#pragma define_template STTVect<const STTypeInfo *>
#endif       

#ifdef NO_TEMPLATES
	const STRoot *__tmpDC__;
	implement(STTVect, PC_STTypeInfo)
#endif

#ifdef NO_EXCEPTIONS
	void (*G_pfThrow)(const char *) = NULL;

	void ST_Throw(const char *pcMsg)
	{
		if (G_pfThrow)
			G_pfThrow(pcMsg);
		else
			STError(pcMsg);
	}
#endif

STImplementClassInfo0(STRoot)

STRoot::~STRoot()
{
}

int STRoot::STIsEqual(const STRoot *p) const
{
	return this == p;
}

int STRoot::STCompareTo(const STRoot *p) const
{
	return this == p;
}

STRoot * STRoot::STClone() const
{
	return 0;
}

void STRoot::STAssign(const STRoot *)
{
	STError("STRoot::STAssign() - called");
}

ostream & STRoot::STDebug(ostream &s) const
{
	return s << "STRoot::STDebug() - " << GetRTTI()->GetClassName() << endl;
}
												  
///////////////////////////////////////////////////////////////////////////////

const STTypeInfo ** STTypeInfo::s_ppSTTypeInfo = 0;
int                 STTypeInfo::s_nTop         = 0;
int                 STTypeInfo::s_nMax         = 0;

void STTypeInfo::Register(const STTypeInfo *p)
{
	if (s_ppSTTypeInfo == 0)
	{
		s_nMax = 100;
		s_nTop = 0;
		s_ppSTTypeInfo = STNew const STTypeInfo * [s_nMax];
	}

	// cerr << "Register class " << p->GetClassName() << " id " << p->GetClassId() << "\n";

	for (int i = 0; i < s_nTop; i++)
	{
		if (s_ppSTTypeInfo[i]->GetClassId() == p->GetClassId())
		{
			// cerr << "STTypeInfo: ClassId duplicated on class \"" << p->GetClassName() << "\"\n";
			STDebug("STTypeInfo: ClassId duplicated on class \"%s\"\n", (const char *)p->GetClassName());
			exit(-1);
		}
	}

	if (s_nTop >= s_nMax)
	{
		const STTypeInfo **p = STNew const STTypeInfo * [s_nMax * 2];
		for (int i = 0; i < s_nTop; i++)
			p[i] = s_ppSTTypeInfo[i];

		STDelete [] ((STTypeInfo **) s_ppSTTypeInfo);
		s_ppSTTypeInfo = p;
		s_nMax *= 2;
	}

	s_ppSTTypeInfo[s_nTop++] = p;
}



STTypeInfo::STTypeInfo(const char *pcName, const STTypeInfo *theClassBases[])
	: m_pcClassName(pcName),
	  m_ppSTTypeInfoBases(theClassBases)
{
	Register(this);
}


STTypeInfo::~STTypeInfo()
{
}
                  
                  
                 
#ifndef NO_TEMPLATES
STTVect<const STTypeInfo *> STTypeInfo::GetDirectBaseClasses() const 
#else
STTVect(PC_STTypeInfo) STTypeInfo::GetDirectBaseClasses() const 
#endif
{

#ifndef NO_TEMPLATES
	STTVect<const STTypeInfo *> r;
#else
	STTVect(PC_STTypeInfo) r;
#endif

	for (int n = 0; m_ppSTTypeInfoBases[n]; n++)
		r.Append((STTypeInfo *)m_ppSTTypeInfoBases[n]);
    return r;
}


int STTypeInfo::IsDerivedFrom(const STTypeInfo *p) const
{
	int i = 0;

	const STTypeInfo *a;

	while ((a = m_ppSTTypeInfoBases[i++]) != 0)
	{
		if (a == p)
			return 1;
		
		if (a->IsDerivedFrom(p))
			return 1;
	}
	return 0;
}


const STTypeInfo * STTypeInfo::GetTypeInfo(ClassIdType ClassId)
{
	for (int i = 0; i < s_nTop; i++)
		if (s_ppSTTypeInfo[i]->m_pcClassName == ClassId ||
		    strcmp(s_ppSTTypeInfo[i]->m_pcClassName, ClassId) == 0)
			return s_ppSTTypeInfo[i];
	return 0;
}

                        
#ifndef NO_TEMPLATES                      
STTVect<const STTypeInfo *> STTypeInfo::GetDirectDerivedClasses() const
#else
STTVect(PC_STTypeInfo) STTypeInfo::GetDirectDerivedClasses() const
#endif
{

#ifndef NO_TEMPLATES
	STTVect<const STTypeInfo *> r;
#else
	STTVect(PC_STTypeInfo) r;
#endif

	for (int i = 0; i < s_nTop; i++)
	{
		const STTypeInfo *aTI = s_ppSTTypeInfo[i];

#ifndef NO_TEMPLATES
		STTVect<const STTypeInfo *>theBases = aTI->GetDirectBaseClasses();
#else
		STTVect(PC_STTypeInfo) theBases = aTI->GetDirectBaseClasses();
#endif

		for (int n = 0; n < theBases.Size(); n++)
		{
			if (theBases[n] == this)
			{
				if (r.Find((STTypeInfo *)aTI) == 0)
					r.Append((STTypeInfo *)aTI);
			}
		}
	}
	return r;
}


#ifndef NO_TEMPLATES
STTVect<const STTypeInfo *> STTypeInfo::GetDerivedClasses() const
#else
STTVect(PC_STTypeInfo) STTypeInfo::GetDerivedClasses() const
#endif
{

#ifndef NO_TEMPLATES
	STTVect<const STTypeInfo *> r(GetDirectDerivedClasses());
#else
	STTVect(PC_STTypeInfo) r(GetDirectDerivedClasses());
#endif

	for (int i = 0; i < r.Size(); i++)
	{                          
#ifndef NO_TEMPLATES
		STTVect<const STTypeInfo *> d(r[i]->GetDirectDerivedClasses());
#else
		STTVect(PC_STTypeInfo) d(r[i]->GetDirectDerivedClasses());
#endif

		/* devo inserire gli elementi non duplicati di d in r */

		for (int di = 0; di < d.Size(); di++)
			if (r.Find(d[di]) == 0)
				r.Append(d[di]);
	}

	return r;
}
