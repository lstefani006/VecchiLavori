#ifndef __ST_SELIT_H__
#define __ST_SELIT_H__

#include "st_dbxx.h"
#include "st_dblst.h"

class STDbase;
struct STDbClassInfo;
class STDbWhereLogical;

class STDbSelectIterator
{
public:
	STDbSelectIterator(STDbTransaction &, const char *ClassName, const STDbWhereLogical &, STSelectType = STSelectNoLock);
	~STDbSelectIterator();

	/* returns an head allocated record with Level 3 capabilities */
	STDbBase * operator () (STDbBase *);
	STDbBase * operator () () { return STDbSelectIterator::operator()(NULL); }
	STDbError  Error() const { return m_DbError; }

protected:
	STDbTransaction        *m_pDbTransaction;
	STDbStmt               *m_pDbStmt;
	int                     m_bFirst;
	const char             *m_ClassName;
	STSelectType            m_SelectType;

	const char             *m_pStrWhere;
#ifdef NO_TEMPLATES
	STTVect(P_DbVal)        m_ValWhere;
#else
	STTVect<DbVal *>        m_ValWhere;
#endif
	STDbError               m_DbError;

private:
	STDbSelectIterator(const STDbSelectIterator &); // not implemented
	void operator = (const STDbSelectIterator &); // not implemented
};

//////////////////////////////////////////////////////////////////////////////////////

#ifndef NO_TEMPLATES
template <class T>
class STTDbSelectIterator : public STDbSelectIterator 
{
public:
	STTDbSelectIterator(STDbTransaction &tr, const STDbWhereLogical &w = STDbWhereLogicalTrue, STSelectType st = STSelectNoLock)
		: STDbSelectIterator(tr, (T (0))->CI.ClassName, w, st) {}

	T operator () ();
};

template <class T>
T STTDbSelectIterator<T>::operator () ()
{
	STDbBase *p = STDbSelectIterator::operator () ();
	return DynamicCast(T, p);
}
                    
#else // NO_TEMPLATES                    

#define STTDbSelectIterator(T) STTDbSelectIterator##T

#define STTDbSelectIteratordeclare(T)                              \
class STTDbSelectIterator(T) : public STDbSelectIterator           \
{                                                                  \
public:                                                            \
	STTDbSelectIterator(T)(                                        \
			STDbTransaction &tr,                                   \
			const STDbWhereLogical &w = STDbWhereLogicalTrue,      \
			STSelectType st = STSelectNoLock)                      \
		: STDbSelectIterator(tr, (T (0))->CI.ClassName, w, st) {}  \
                                                                   \
	T operator () ();                                              \
};                                                                 \
                                                                   \
inline T STTDbSelectIterator(T)::operator () ()                    \
{                                                                  \
	STDbBase *p = STDbSelectIterator::operator () ();              \
	return DynamicCast(T, p);                                      \
}
                    
#endif // NO_TEMPLATES                    
#endif
