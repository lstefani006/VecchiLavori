#include <stdlib.h>
#include <stdio.h>

#include <st_dbnew.h>
#include <st_itdb.h>

// #include <LeoDB.h>


main()
{
	STDbG::DbMain();

	STDbError e;

	STDbConnection cn(ST_DB_ODBC);
	

	// e = cn.Login("setship", "setship", "aix_net");
	// e = cn.Login("setstat", "setstat", "alpha0_net");


	// e = cn.Login("setpdm", "setpdm", "setpdm");
	e = cn.Login("", "", "prova");
	if (e == ST_DB_LOGIN_FAIL)
		return 0;

	STDbTransaction tr(cn);
	tr.BeginTransaction();

	{
		STDbStmt st(tr);
		DbInt n(8);
		DbString str(30);

		e = st.Parse("select n, str from prova for update of n, str");
		e = st.Exec();
		e = st.Bind(&n);
		e = st.Bind(&str);

		while ((e = st.Fetch()) == ST_DB_OK)
		{
			cerr << n << "\n";
			cerr << str << endl;

			st.Bind(&n);
			st.Bind(&str);
		}


	}

	/*
	STTVect(P_DbVal) outList;

	DbTS dt;
	outList.Append(&dt);
	STDbSelStmt st(tr, "select data_trasm from testata where numintmsg=350",outList);
	
	while (st() == ST_DB_OK)
	{
		cerr << dt << endl;
	}
	*/

/*
	{
		STDbStmt st(tr);
		STTVect<DbVal *> in;
		DbDouble ww(5, 3, 3.54);
		in.Append(&ww);

		st.Parse("insert into tabella1 values(#4/1/1997#, 2, 3, 4, ? , 6, 'cio', 'cia')", in);
		st.Exec();
	}
	*/

	/*
	{

		STDbStmt st(tr);

		DbDouble ts(10, 2);

		cn.DbPrint(&ts);

		e = st.Parse("select PrecisioneDoppia from tabella1");

		e = st.Exec();

		e = st.Bind(ts);

		while ((e = st.Fetch()) == ST_DB_OK)
		{
			cerr << ts << "\n";

			st.Bind(ts);
		}


	}
	*/


	/*
	DbTS ss = DbTS::Now();

	{
		STTVect(P_DbVal) aDbStack;
		aDbStack.Append(&ss);

		cerr << ss << endl;

		STDbStmt st(tr);
		st.Parse("insert into tabella1 values( ? , 2, 3,4, 5, 6, 'cio', 'cia')", aDbStack);
		st.Exec();
	}
	{
		STTVect(P_DbVal) aDbStack;
		aDbStack.Append(&ss);

		cerr << ss << endl;

		STDbStmt st(tr);
		st.Parse("delete from tabella1 where data = ?", aDbStack);
		st.Exec();
	}

  */




/*
	for (char i = 'a'; i < 'd'; i++)
	{
		LeoDB q;
		q.f_char1 = i;
		q.Delete(tr);


		LeoDB r;
		r.f_char1 = i;
		r.f_char2 = 'a' ;

		r.f_date1 = DbTS(1964, 6, 24, 4, 1, 6);
		r.f_date2 = DbTS(1964, 6, 25, 3, 2, 7);
		r.f_date3 = DbTS(1964, 6, 26, 2, 3, 8);

		r.f_number6    = 123456;
		r.f_number2    = 99;
		r.f_varchar4   = "";
		r.f_number11_9 = 3.14;

		r.f_raw.SetNull(0);
		r.f_raw.GetBuff()[0] = 0;
		r.f_raw.GetBuff()[1] = 1;
		r.f_raw.GetBuff()[2] = 2;
		r.f_raw.GetBuff()[3] = 3;

		STDbError e = r.Insert(tr);

		if (e == ST_DB_OK)
			cerr << "Inserito " << i << endl;
		else
			cerr << "Non ho inserito " << i << endl;
	}

#ifndef NO_TEMPLATES
	STTDbSelectIterator<LeoDB *> it(tr, 
		CM(LeoDB, f_char1) >= 'a' &&
		CM(LeoDB, f_char1) <= 'z');
#else
	STTDbSelectIterator(P_LeoDB) it(tr, 
		CM(LeoDB, f_char1) >= 'a' &&
		CM(LeoDB, f_char1) <= 'z');
#endif

	LeoDB *p;
	while (p = it())
	{
		p->STDebug(cout);

		STDelete p;
	}

*/

getchar();
	tr.EndTransaction(STCommit);

	return 0;
}
