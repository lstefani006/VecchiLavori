#include <math.h>
#include <assert.h>

#include "st_math.h"


static void Swap(double &x, double &y)
{
	double t = y;
	y = x;
	x = t;
}

double Metodo_Dicotomico(double (*f)(double, void *), double y,
                         double x1, double x2,
                         double dx, double dy,
                         void *p)
{
	if (x1 > x2)
		Swap(x1, x2);

	double y1 = f(x1, p) - y;
	double y2 = f(x2, p) - y;

	assert(y1 * y2 <= 0);    // esigo una soluzione tra x1 e x2

	if (fabs(x2 - x1) <= dx)
		return (x2 + x1) / 2.;

	double xm;
	for (;;)
	{
		xm = (x1 + x2) / 2.;
		if (fabs(x2 - x1) <= dx) return xm;

		double ym = f(xm, p) - y;
		if (fabs(ym) <= dy) return xm;

		if (y1 * ym < 0)
			x2 = xm, y2 = ym;
		else
			x1 = xm, y1 = ym;
	}
}


double Metodo_Tangenti(double (*f)(double, void *), double y,
                       double x1, double x2,
                       double dx, double dy,
                       void *p)
{
	if (x1 > x2)
		Swap(x1, x2);

	double y1 = f(x1, p) - y;
	double y2 = f(x2, p) - y;

	assert(y1 * y2 <= 0);    // esigo una soluzione tra x1 e x2

	if (fabs(x2 - x1) <= dx)
		return (x2 + x1) / 2.;

	double xm;
	for (;;)
	{
		xm = x1 - y1 * (x2 - x1) / (y2 - y1);
		if (fabs(x2 - x1) <= dx) return xm;

		double ym = f(xm, p) - y;
		if (fabs(ym) <= dy) return xm;

		if (y1 * ym < 0)
			x2 = xm, y2 = ym;
		else
			x1 = xm, y1 = ym;
	}
}
