#include <st_dbnew.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
//#include <rw/cstring.h>
//#include <rw/regexp.h>

#include <st_map.h>
#include <st_dbxx.h>
#include <st_err.h>

////////////////////////////////////////////////////////////////////////////////


int operator == (const STDbColMap &a, const STDbColMap &b)
{
	if (strcmp(a.m_pcTable, b.m_pcTable) == 0 &&
	    strcmp(a.m_pcCol  , b.m_pcCol  ) == 0)
			return 1;
	return 0;
}

STDbColMap::STDbColMap()
{
	m_nOffset = 0;
	m_pcTable = 0;
	m_pcCol   = 0;
	m_bKey    = 0;
}

void STDbColMap::Debug() const
{
	fprintf(stderr, "%-5d %-10s %-10s %d\n", m_nOffset, m_pcTable, m_pcCol, m_bKey);
}

STDbColMap::STDbColMap(int nOffset, const char *pcTable, const char *pcCol, int bKey)
{
	m_nOffset = nOffset;
	m_pcTable = pcTable;
	m_pcCol   = pcCol;
	m_bKey    = bKey;
}

STDbColMap::STDbColMap(const STDbColMap &r)
{
	m_nOffset = r.m_nOffset;
	m_pcTable = r.m_pcTable;
	m_pcCol   = r.m_pcCol;
	m_bKey    = r.m_bKey;
}


////////////////////////////////////////////////////////////////////////////////


STDbMap::STDbMap(const char *pcTable)
	: m_pcTable(pcTable)
{
	m_nSize       = 20;
	m_pDbColMap   = STNew STDbColMap[m_nSize];
	m_nTop        = 0;
}

STDbMap::STDbMap()
	: m_pcTable(0)
{
	m_nSize       = 5;
	m_pDbColMap   = STNew STDbColMap[m_nSize];
	m_nTop        = 0;
}

STDbMap::~STDbMap()
{
	STDelete [] m_pDbColMap;
}


void STDbMap::Debug() const
{
	fprintf(stderr, "\ntabella \"%s\"\n", m_pcTable);

	for (int i = 0; i < m_nTop; i++)
		m_pDbColMap[i].Debug();
}


void STDbMap::Put(const STDbColMap &rDbColMap)
{
	if (m_nTop >= m_nSize)
	{
		STDbColMap *p = STNew STDbColMap[m_nSize * 2];
		for (int i = 0; i < m_nSize; i++)
			p[i] = m_pDbColMap[i];
		
		STDelete [] m_pDbColMap;
		m_pDbColMap = p;
		m_nSize *= 2;
	}

	m_pDbColMap[m_nTop++] = rDbColMap;
}

void STDbMap::Put(int nOffsetCol, const char *pcCol, STDbKey bKey)
{
	if (ExistCol(pcCol))
		STError("STDbMap: \"%s\": colonna duplicata \"%s\"", m_pcTable, pcCol);

	const STDbColMap aColMap(nOffsetCol, m_pcTable, pcCol, bKey);
	Put(aColMap);
}

int STDbMap::ExistCol(const char *pcCol) const
{
		for (int i = 0; i < m_nTop; i++)
			if (strcmp(m_pDbColMap[i].Col(), pcCol) == 0)
				return 1;
		return 0;
}

const STDbColMap & STDbMap::Get(int nOffset) const
{
	for (int i = 0; i < m_nTop; i++)
		if (m_pDbColMap[i].Offset() == nOffset)
			return m_pDbColMap[i];

	STError("offset non trovato");
	return m_pDbColMap[0];
}

const STDbColMap & STDbMap::Get(const char *pcCol) const
{
	for (int i = 0; i < m_nTop; i++)
		if (strcmp(m_pDbColMap[i].Col(), pcCol) == 0)
			return m_pDbColMap[i];

	STError("colonna non trovata");
	return m_pDbColMap[0];
}
