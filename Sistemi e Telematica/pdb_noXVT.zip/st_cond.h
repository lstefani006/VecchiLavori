#ifndef __ST_COND_H__
#define __ST_COND_H__


void ST__DbgCondFail(const char *pcFile, int nLine,
	  			     const char *pcCondition,
				     const char *pcComment,
				     int nType);

#ifndef ST_COND_NDEBUG

#	define ST_FAIL_LIBR  0
#	define ST_FAIL_APPL  1

#	define ST_COND_LIBR(a, b) \
	((a) ? (void)0 : ST__DbgCondFail(__FILE__, __LINE__, #a, b, ST_FAIL_LIBR))

#	define ST_COND_APPL(a, b) \
	((a) ? (void)0 : ST__DbgCondFail(__FILE__, __LINE__, #a, b, ST_FAIL_APPL))

#else

#	define ST_COND_APPL(a, b) ((void)0)
#	define ST_COND_LIBR(a, b) ((void)0)

#endif

#endif
