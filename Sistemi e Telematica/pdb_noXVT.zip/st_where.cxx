#include <st_dbnew.h>

#include <strstream.h>
#include <stdio.h>
//#include <rw/regexp.h>

#include <st_err.h>
#include <st_where.h>
#include <st_dbxx.h>

#ifdef NO_TEMPLATES
	implement(STTVect, P_STDbClassInfo);
	implement(STTVect, int);
#endif

#if defined(__DECCXX) && !defined(NO_TEMPLATES)
	#pragma define_template STTVect<STDbClassInfo *>
#endif

const STDbWhereLogical STDbWhereLogicalTrue(STDbWhereData(1) == STDbWhereData(1));



STDbWhereData::STDbWhereData(const RWCString &str)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = STNew DbString(strlen(str) + 1, str);
}

STDbWhereData::STDbWhereData(const char *pc)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = STNew DbString(strlen(pc) + 1, pc);
}

STDbWhereData::STDbWhereData(char *pc)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = STNew DbString(strlen(pc) + 1, pc);
}

STDbWhereData::STDbWhereData(const STDbClassInfo *pCI, int nOffset)
	: m_pCI(pCI), m_nOffset(nOffset), m_pDbVal(NULL)
{
	const STDbColMap &theDbColMap = (pCI->Map().Get(nOffset));
	m_String = theDbColMap.Col();
}

STDbWhereData::STDbWhereData(int n)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = STNew DbInt(30, n);
}

STDbWhereData::STDbWhereData(float n)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = STNew DbDouble(50, 30, n);
}

STDbWhereData::STDbWhereData(double n)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = STNew DbDouble(50, 30, n);
}

STDbWhereData::STDbWhereData(char n)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = STNew DbChar(n);
}

STDbWhereData::STDbWhereData(const RWTime &a)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = STNew DbTS(a);
}


STDbWhereData::STDbWhereData(const DbVal &a)
	: m_pCI(NULL), m_nOffset(0)
{
	m_String = ":###";
	m_pDbVal = DynamicCast(DbVal *, a.STClone());
}


STDbWhereData::STDbWhereData(const STDbWhereData &r)
	: m_pCI(r.m_pCI), m_nOffset(r.m_nOffset), m_String(r.m_String)
{
	if (r.m_pDbVal)
		m_pDbVal = DynamicCast(DbVal *, r.m_pDbVal->STClone());
	else
		m_pDbVal = NULL;
}

void STDbWhereData::operator = (const STDbWhereData &r)
{
	if (this == &r)
		return;

	m_pCI     = r.m_pCI;
	m_nOffset = r.m_nOffset;
	m_String  = r.m_String;
	STDelete m_pDbVal;
	if (r.m_pDbVal)
		m_pDbVal = DynamicCast(DbVal *, r.m_pDbVal->STClone());
	else
		m_pDbVal = NULL;
}

///////////////////////////////////////////////////////////////////////////////

void STDbWhereLogical::AppendDbVal(const DbVal *pDbVal)
{
	if (pDbVal)
		m_DbVal.Append(DynamicCast(DbVal *, pDbVal->STClone()));
}

void STDbWhereData::Set(const STDbWhereData &w)
{
	m_pCI = w.m_pCI;
	m_nOffset = w.m_nOffset;
	m_String = w.m_String;

	if (m_pDbVal)
		STDelete m_pDbVal;
		
	if (w.m_pDbVal)
		m_pDbVal = DynamicCast(DbVal *, w.m_pDbVal->STClone());
	else
		m_pDbVal = NULL;
}


///////////////////////////////////////////////////////////////////////////


STDbWhereLogical::STDbWhereLogical(const STDbWhereData &a, const STDbWhereData &b, const RWCString &str)
	: m_String(str)
{
	if (a.GetCI())
	{
		m_CI.Append((STDbClassInfo *)a.GetCI());
		m_Offset.Append(a.GetOffset());
	}
	if (b.GetCI())
	{
		m_CI.Append((STDbClassInfo *)b.GetCI());
		m_Offset.Append(b.GetOffset());
	}
	AppendDbVal(a.GetDbVal());
	AppendDbVal(b.GetDbVal());
}


STDbWhereLogical::STDbWhereLogical(const STDbWhereData &a, const RWCString &str)
	: m_String(str)
{
	if (a.GetCI())
	{
		m_CI.Append((STDbClassInfo *)a.GetCI());
		m_Offset.Append(a.GetOffset());
	}
	AppendDbVal(a.GetDbVal());
}


STDbWhereLogical::STDbWhereLogical(const STDbWhereLogical &w)
	: m_String(w.m_String)
{
	m_CI.Append(w.m_CI);
	m_Offset.Append(w.m_Offset);

	for (int i = 0; i < w.m_DbVal.Size(); i++)
		AppendDbVal(w.m_DbVal[i]);
}

STDbWhereLogical::STDbWhereLogical(const STDbWhereLogical &a, const STDbWhereLogical &b, const RWCString &s)
	: m_String(s)
{
	m_CI.Append(a.m_CI);
	m_Offset.Append(a.m_Offset);

	m_CI.Append(b.m_CI);
	m_Offset.Append(b.m_Offset);

	for (int i = 0; i < a.m_DbVal.Size(); i++)
		AppendDbVal(a.m_DbVal[i]);

	for (i = 0; i < b.m_DbVal.Size(); i++)
		AppendDbVal(b.m_DbVal[i]);
}

STDbWhereLogical::~STDbWhereLogical()
{
	for (int i = 0; i < m_DbVal.Size(); i++)
		STDelete m_DbVal[i];
}

void STDbWhereLogical::operator = (const STDbWhereLogical &w)
{
	for (int i = 0; i < m_DbVal.Size(); i++)
		STDelete m_DbVal[i];

	m_CI.Reset();
	m_Offset.Reset();
	m_DbVal.Reset();

	m_String = w.m_String;
	m_CI     = w.m_CI;
	m_Offset = w.m_Offset;

	for (i = 0; i < w.m_DbVal.Size(); i++)
		AppendDbVal(w.m_DbVal[i]);
}


const STDbClassInfo * STDbWhereLogical::GetUniqueCI() const
{
	if (m_CI.Size() == 0)
		return 0;

	const STDbClassInfo *p = m_CI[0];

	for (int i = 1; i < m_CI.Size(); i++)
		if (m_CI[i] != p)
			return 0;
	
	return p;
}

RWCString STDbWhereLogical::StrWhere(STDbTransaction &tr) const
{
	RWCString r = m_String;

	//@@RWCRegexp re(":###");

	int i = 0;

	for (;;)
	{
		//@@RWCSubString ss = r(re);
		//@@if (ss.length() == 0)
		//@@	break;
		//@@ss = tr.GetParameterMarker(i++);

		char *p;
		if ((p = strstr(r, ":###")) == NULL)
			break;

		RWCString ss(r, p - r);

		ss += tr.GetParameterMarker(i++);
		ss += p + 4;

		r = ss;
	}

	return r;
}


////////////////////////////////////////////////////////////////////////////////////

STDbWhereLogical operator && (const STDbWhereLogical &a, const STDbWhereLogical &b)
{
	return STDbWhereLogical(a, b, a.Str() + " and " + b.Str());
}

STDbWhereLogical operator || (const STDbWhereLogical &a, const STDbWhereLogical &b)
{
	return STDbWhereLogical(a, b, "(" + a.Str() + " or " + b.Str() + ")");
}

////////////////////////////////////////////////////////////////////////////////////

STDbWhereLogical operator == (const STDbWhereData &a, const STDbWhereData &b)
{
	if (b.GetDbVal() && b.GetDbVal()->IsNull())
		return IsNull(a);

	return STDbWhereLogical(a, b, a.Str() + " = " + b.Str());
}

STDbWhereLogical operator != (const STDbWhereData &a, const STDbWhereData &b)
{
	if (b.GetDbVal() && b.GetDbVal()->IsNull())
		return IsNotNull(a);

	return STDbWhereLogical(a, b, a.Str() + " <> " + b.Str());
}

STDbWhereLogical operator >  (const STDbWhereData &a, const STDbWhereData &b)
{
	return STDbWhereLogical(a, b, a.Str() + " > " + b.Str());
}

STDbWhereLogical operator >= (const STDbWhereData &a, const STDbWhereData &b)
{
	return STDbWhereLogical(a, b, a.Str() + " >= " + b.Str());
}

STDbWhereLogical operator < (const STDbWhereData &a, const STDbWhereData &b)
{
	return STDbWhereLogical(a, b, a.Str() + " < " + b.Str());
}

STDbWhereLogical operator <= (const STDbWhereData &a, const STDbWhereData &b)
{
	return STDbWhereLogical(a, b, a.Str() + " <= " + b.Str());
}

////////////////////////////////////////////////////////////////////////////////////

STDbWhereLogical operator == (const STDbWhereData &a, const DbVal &b)
{
	if (b.IsNull())
		return IsNull(a);

	STDbWhereData wd(b);
	return STDbWhereLogical(a, wd, a.Str() + " = " + wd.Str());
}

STDbWhereLogical operator != (const STDbWhereData &a, const DbVal &b)
{
	if (b.IsNull())
		return IsNotNull(a);

	STDbWhereData wd(b);
	return STDbWhereLogical(a, wd, a.Str() + " <> " + wd.Str());
}

STDbWhereLogical operator >  (const STDbWhereData &a, const DbVal &b)
{
	STDbWhereData wd(b);
	return STDbWhereLogical(a, wd, a.Str() + " > " + wd.Str());
}

STDbWhereLogical operator >= (const STDbWhereData &a, const DbVal &b)
{
	STDbWhereData wd(b);
	return STDbWhereLogical(a, wd, a.Str() + " >= " + wd.Str());
}

STDbWhereLogical operator < (const STDbWhereData &a, const DbVal &b)
{
	STDbWhereData wd(b);
	return STDbWhereLogical(a, wd, a.Str() + " < " + wd.Str());
}

STDbWhereLogical operator <= (const STDbWhereData &a, const DbVal &b)
{
	STDbWhereData wd(b);
	return STDbWhereLogical(a, wd, a.Str() + " <= " + wd.Str());
}


STDbWhereLogical Like(const STDbWhereData &a, const char *p)
{
	STDbWhereData b(p);
	return STDbWhereLogical(a, b, a.Str() + " like " + b.Str());
}

STDbWhereLogical IsNull(const STDbWhereData &a)
{
	return STDbWhereLogical(a, a.Str() + " is null ");
}

STDbWhereLogical IsNotNull(const STDbWhereData &a)
{
	return STDbWhereLogical(a, a.Str() + " is not null ");
}
