#ifndef __ODBC_DB_H__
#define __ODBC_DB_H__

#include <windows.h>
#include <sqltypes.h>
#include <sql.h>
#include <sqlext.h>

#include <stdlib.h>
#include <iostream.h>
#include <st_db.h>
#include <st_tvect.h>

#ifdef NO_TEMPLATES
	#ifndef D_STTVectP_P_TIMESTAMP_STRUCT
		#define D_STTVectP_P_TIMESTAMP_STRUCT
		typedef TIMESTAMP_STRUCT *P_TIMESTAMP_STRUCT;
		declare(STTVect, P_TIMESTAMP_STRUCT);
	#endif
	#ifndef D_STTVectP_P_SQLINTEGER
		#define D_STTVectP_P_SQLINTEGER
		typedef SQLINTEGER *P_SQLINTEGER;
		declare(STTVect, P_SQLINTEGER);
	#endif
	#ifndef D_STTVectP_P_SDWORD
		#define D_STTVectP_P_SDWORD
		typedef SDWORD *P_SDWORD;
		declare(STTVect, P_SDWORD);
	#endif
#endif

////////////////////////////////////////////////////////////////////////////////

class DbConnectionOdbc : public STDbConnectionData
{
public:
	DbConnectionOdbc();
	~DbConnectionOdbc();

	STDbError Login(const char *pcUser, const char *pcPasswd, const char *pcHost);
	STDbError Logout();
	STDbError Error() const { return m_DbError; }
	RWCString GetParameterMarker(int) const;
	RWCString DbPrint(const DbVal *) const;

	STDbError m_DbError;

	static HENV m_henv;
};


////////////////////////////////////////////////////////////////////////////////


class DbTransactionOdbc : public STDbTransactionData
{
public:
	DbTransactionOdbc(DbConnectionOdbc &cn, const char *pcUser, const char *pcPasswd, const char *pcHost);
	~DbTransactionOdbc();

	STDbError BeginTransaction();
	STDbError EndTransaction(STEndTransactionType);
	STDbError Error() const { return m_DbError; }

	STDbConnectionData * GetDbConnectionData();

	/* in Odbc ogni transazione ha la sua connessione */
	int                   m_bUsed;
	STDbError             m_DbError;
	int                   m_bBegin;
	
	HDBC m_hdbc;
};


////////////////////////////////////////////////////////////////////////////////

class DbStmtOdbc : public STDbStmtData
{
public:
	DbStmtOdbc(DbTransactionOdbc &);
	~DbStmtOdbc();

	STDbError Parse(const char *pcStmt);
#ifndef NO_TEMPLATES
	STDbError Parse(const char *pcStmt, const STTVect<DbVal *> &);
#else
	STDbError Parse(const char *pcStmt, const STTVect(P_DbVal) &);
#endif

	STDbError Bind(DbVal *);
	STDbError Exec(long &nNumOfProcessedRows);
	STDbError Fetch();
	STDbError Describe(RWCString &strColName, DbVal *&rpDbVal);

	STDbError Error() const { return m_DbError; }

	
	void ClearStacks();   // fa delete dei puntatori allocati in m_DbStack*

	DbTransactionOdbc *m_pDbTransactionOdbc;
	STDbError          m_DbError;
	int                m_nDescribePos;

	/*
	 * intero usato per contare il numero di Bind (si comincia da 1)
	 */
	int                m_nBindPos;

	/*
	 * flag che indica se m_hstmt e' allocato
	 */
	int                m_bCursorOpen;

	/*
	 * flag per indicara alla Bind se deve fare Reset della m_DbStack
	 * La Bind deve fare Reset se e' eseguita dopo una Fetch
	 */
	int                m_bNeedReset;

	HSTMT              m_hstmt;
      
	/*
	 * Lista di strutture che sono usate pre tenere le date in formato
	 * odbc uate nella where condition
	 * Viene riempita nella Parse
	 */
#ifndef NO_TEMPLATES
	STTVect<TIMESTAMP_STRUCT *> m_DbStack_Where_TS;      // DbTS
#else 
	STTVect(P_TIMESTAMP_STRUCT) m_DbStack_Where_TS;      // DbTS
#endif


	/*
	 * lista per memorizzare i puntatori a DbVal usati nella Bind
	 * La lista viene scandita nella Fetch per assegnare alle 
	 * variabili in uscita i valori del db.
	 * Non bisogna deallocare i puntatori!!!
	 */
#ifndef NO_TEMPLATES
	STTVect<DbVal *>     m_DbStack;
#else 
	STTVect(P_DbVal)     m_DbStack;
#endif



	/*
	 * Lista di strutture che saranno utilizzate da odbc per tornare le date
	 * Viene riempita
	 * La lista deve essere esplorata durante la Fetch per convertire
	 * le date in formato odbc nel nostro formato
	 */
#ifndef NO_TEMPLATES
	STTVect<TIMESTAMP_STRUCT *> m_DbStack_TS;      // DbTS
#else 
	STTVect(P_TIMESTAMP_STRUCT) m_DbStack_TS;      // DbTS
#endif



	/*
	 * Lista riempita nella Parse per informare odbc se i dati pDbVal
	 * sono NULL. Odbc usera' i dati puntati dalla lista nella SQLExecute
	 * nella DbStmtOdbc::Exec
	 */
#ifndef NO_TEMPLATES
	STTVect<SQLINTEGER *> m_DbStack_cbValue;
#else 
	STTVect(P_SQLINTEGER) m_DbStack_cbValue;
#endif



	/*
	 * Lista che odbc utilizzera' per segnare ad ogni fetch se il campo
	 * dal db e' null o not null
	 * E' necessario deallocare i puntati nel distruttore
	 */
#ifndef NO_TEMPLATES
	STTVect<SDWORD *> m_DbStack_NULL;
#else 
	STTVect(P_SDWORD) m_DbStack_NULL;
#endif

};


#endif
