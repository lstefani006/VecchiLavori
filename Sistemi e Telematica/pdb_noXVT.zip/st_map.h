#ifndef __ST_MAP_H__
#define __ST_MAP_H__

//#include <rw/cstring.h>
#include <st_diz.h>

class STDbColMap
{
public:
	STDbColMap();
	STDbColMap(const STDbColMap &);
	STDbColMap(int nOffset, const char *pcTable, const char *pcCol, int bKey);

	int          isKey()  const { return m_bKey; }
	RWCString    Col()    const { return RWCString(m_pcCol); }
	RWCString    Table()  const { return RWCString(m_pcTable); }

	int          Offset() const { return m_nOffset; }

	void         Debug()  const;

	friend int operator == (const STDbColMap &, const STDbColMap &);

protected:
	int          m_nOffset;
	const char  *m_pcTable;
	const char  *m_pcCol;
	int          m_bKey;
};


////////////////////////////////////////////////////////////////////

enum STDbKey { STNotKey, STPrimaryKey };

class STDbMap
{
public:
	STDbMap(const char *pcTable);
	~STDbMap();

	void Put(int nOffsetCol, const char *pcCol, STDbKey bKey);
	int  Size() const { return m_nTop; }
	void CreateSqlCommamds() const;
	void Debug() const;
	
	const STDbColMap & operator [] (int i) const { return m_pDbColMap[i]; }
	const STDbColMap & Get(int nOffset) const;
	const STDbColMap & Get(const char *pcCol) const;

	int                ExistCol(const char *pcCol) const;

	const char *       Table() const { return m_pcTable; }

private:
	STDbMap();
	friend class STDbBase;

	void Put(const STDbColMap &);

	const char    * const m_pcTable;
	STDbColMap    *       m_pDbColMap;
	int                   m_nTop;
	int                   m_nSize;

	void operator = (const STDbColMap &);    // not implemented
};

#endif
