#ifndef __ST_DB_H__
#define __ST_DB_H__


////////////////////////////////////////////////////////////////////////////////

#include <st_cond.h>
#include <st_tvect.h>

////////////////////////////////////////////////////////////////////////////////

class DbVal;

#ifdef NO_TEMPLATES
	#ifndef D_STTVectP_DbVal
		#define D_STTVectP_DbVal
		typedef class DbVal *P_DbVal;
		declare(STTVect, P_DbVal);
	#endif
#endif // NO_TEMPLATES

////////////////////////////////////////////////////////////////////////////////

enum STDbType
{
	ST_DB_ORACLE           = 1,
	ST_DB_ODBC             = 2
};

#if !defined(ST_LIBDB_ORACLE) && !defined(ST_LIBDB_ODBC)
	#error definire almeno uno tra ST_LIBDB_ORACLE ST_LIBDB_ODBC o entrambi
#endif

////////////////////////////////////////////////////////////////////////////////

enum STDbError
{
	/* data base errors returned from "DbXXX::XXX" functions */
	ST_DB_OK                    =   0,
	ST_DB_LOGIN_FAIL            =   1,
	ST_DB_BEGINTRANSACTION_FAIL =   2,
	ST_DB_NOT_FOUND             =   3,
	ST_DB_DUPL_KEY              =   4,
	ST_DB_LOCK                  =   5,

	/* data base errors that cause exceptions "DbException" */
	ST_DB_ERROR                 =  -100,
	ST_DB_PROT                  =  -101,
	ST_DB_REFERENTIAL_INTEGRITY =  -102,
	ST_DB_NOT_UNIQUE            =  -103,  /* exception thrown in DbBase::Select() */
	ST_DB_NOT_AVAILABLE         =  -104,
	ST_DB_NULL_KEY              =  -105
};

const char * STGetDbErrorString(STDbError theDbError);

inline ostream & operator << (ostream &s, STDbError e)
{
	return s << STGetDbErrorString(e);
}

////////////////////////////////////////////////////////////////////////////////

/* Dichiarazioni delle classi dipendenti dal tipo data base impiegato */
class STDbConnectionData;
class STDbTransactionData;
class STDbStmtData;

////////////////////////////////////////////////////////////////////////////////

extern void (*G_pfEnterIdle)();
extern void (*G_pfLeaveIdle)();

class STDbConnection
{
public:
	STDbConnection(STDbType theDbType = ST_DB_ODBC);
	virtual ~STDbConnection();

	STDbError Login(const char *pcUser, const char *pcPasswd, const char *host = NULL);
	STDbError Logout();

	STDbType  GetDbType() const { return m_DbType; }
	STDbError Error() const { return m_DbError; }
	int       Connected() const { return m_bConnected; }

	void         SetProcCode(const char *);
	const char * GetProcCode() const { return "set_default"; }

	RWCString GetParameterMarker(int i /* da 0 in poi */) const;

	RWCString DbPrint(const DbVal *) const;

public:
	STDbType            m_DbType;
	STDbError           m_DbError;              // last error code

	char                m_acUser[40];
	char                m_acPasswd[40];
	char                m_acHost[40];

	STDbConnectionData *m_pDbConnectionData;
	int                 m_bConnected;

private:
	STDbConnection(const STDbConnection &);
	void operator = (const STDbConnection &);
};

extern STDbConnection G_DbConnection;

////////////////////////////////////////////////////////////////////////////////

enum STEndTransactionType { STCommit, STRollback };

class STDbTransaction
{
public:
	STDbTransaction(STDbConnection &);
	virtual ~STDbTransaction();

	virtual STDbError BeginTransaction();
	virtual STDbError EndTransaction(STEndTransactionType);
	int               OnTransaction() const { return m_bBegin; }

	STDbType GetDbType() const { return m_pDbConnection->GetDbType(); }
	STDbError Error() const { return m_DbError; }

	const char * GetProcCode() const { return "set_default"; }

	RWCString GetParameterMarker(int i /* da 0 in poi */) const;

public:
	int                  m_bBegin;
	STDbError            m_DbError;
	STDbTransactionData *m_pDbTransactionData;

protected:
	STDbConnection      *m_pDbConnection;
};

////////////////////////////////////////////////////////////////////////////////

class STDbStmt
{
public:
	static long        m_lDummy;

	STDbStmt(STDbTransaction &);
	~STDbStmt();

	virtual STDbError Parse(const char *pcStmt);
#ifndef NO_TEMPLATES
	virtual STDbError Parse(const char *pcStmt, const STTVect<DbVal *> &);
#else
	virtual STDbError Parse(const char *pcStmt, const STTVect(P_DbVal) &);
#endif


	virtual STDbError Bind(DbVal *pDbVal);
	virtual STDbError Bind(DbVal &rDbVal);

	virtual STDbError Exec(long &nNumOfProcessedRows = STDbStmt::m_lDummy);

	virtual STDbError Fetch();
	virtual STDbError Describe(RWCString &strColName, DbVal *&rpDbVal);

	STDbError         Error() { return m_DbError; }

public:
	STDbError          m_DbError;
	int                m_nState;
	STDbTransaction   *m_pDbTransaction;
	STDbStmtData      *m_pDbStmtData;

	RWCString          m_strStmt;

};

////////////////////////////////////////////////////////////////////////////////

/* eccezione STDbException: quando e` segnalata
   si e` verificato un errore nel data base
   Questo tipo di eccezione riporta un errore del data base e puo` essere
   gestito anche dall'applicativo con una catch (ad esempio per riportare
   all'utente l'errore del db) 
*/
class STDbException
{
public:
	STDbException(STDbError e, const char *pc);
	void operator = (const STDbException &);

	const char * Msg() const       { return m_aMsg; }
	STDbError    ErrorCode() const { return m_DbError; }

protected:
	char        m_aMsg[2048];
	STDbError   m_DbError;
};

#ifdef NO_EXCEPTIONS
	void ST_Throw(const STDbException &);
#endif // NO_EXCEPTIONS


#endif
