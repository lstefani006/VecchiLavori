#ifndef __ST_SLIST_H__
#define __ST_SLIST_H__

#include "st_root.h"

class STSlist : public virtual STRoot
{
public:
	STDefineClassInfo
    STDeclareAssignClone(STSlist)

	STSlist();
	STSlist(const STSlist &);
	~STSlist();
	void operator = (const STSlist &);

	virtual void      Clear();

	virtual void      AddHead(STRoot *);          // add at head of list
	virtual void      AddTail(STRoot *);          // add at tail of list

	virtual STRoot *  GetHead();              // return and remove head of list
	virtual STRoot *  Remove(STRoot *);

	virtual STRoot *  Search(STRoot *) const; // search for Obj
	virtual int       nOfItems() const;

	virtual void      Sort(int (*pfCompare)(const STRoot *, const STRoot *));

protected:
	class STSlink
	{
		friend class STSlist;          // Members must be accessible to STSlist
		friend class STSlistIterator;  // and to the iterator
		STSlink *m_pNext;
		STRoot  *m_pSTRoot;
		STSlink(STRoot * a);
		~STSlink();
	};

	friend class STSlistIterator;
	STSlink *m_pLast;           // last->next is head of list
};

///////////////////////////////////////////////////////////////////////////////

class STSlistIterator
{
public:
	STSlistIterator(const STSlist &);

	STRoot * operator () ();
	
private:
    void operator = (const STSlist &);
	
	STSlist::STSlink *ce;
	const STSlist    *cs;
};


///////////////////////////////////////////////////////////////////////////////


class ExSlist
{
public:
	ExSlist(int nError, const char *pcMsg)
		: m_pcMsg(pcMsg), m_nError(nError) {}

protected:
	const char * const m_pcMsg;
	const int          m_nError;

	void operator = (const ExSlist &);    // not implemented
};


/////////////////////////////////////////////////////////////////////

#ifndef NO_TEMPLATES

template <class T>
class STTSlist : public STSlist
{
public:
	STDefineClassInfo
    STDeclareAssignClone(STTSlist<T>)

	STTSlist() {}
	STTSlist(const STTSlist<T> &s) : STSlist(s) {}
	void operator = (const STTSlist<T> &s) { STSlist::operator = (s); }

	virtual void          AddHead(STRoot *);      // add at head of list
	virtual void          AddTail(STRoot *);      // add at tail of list

	/* Le funzioni ridefinite devono tornare esattamente lo stesso tipo
#ifndef __DECCXX
	virtual T             GetHead();              // return and remove head of list
	virtual T             Remove(STRoot *);       // remove the element
	virtual T             Search(STRoot *) const; // search for Obj
#endif
	*/
};

template <class T>
int STTSlist<T>::STIsEqual(const STRoot *p) const
{
	return STSlist::STIsEqual(p);
}

template <class T>
STRoot * STTSlist<T>::STClone() const
{
	return STNew STTSlist<T>(*this);
}

template <class T>
STRoot * STTSlist<T>::STCreate() const
{
	return STNew STTSlist<T>(*this);
}

template <class T>
void STTSlist<T>::STAssign(const STRoot *p)
{
	STTSlist<T> *ps = DynamicCast(STTSlist<T> *, p);
	if (ps == 0)
		STError("STTSlist<T>:STAssign() - invalid obejct");
	*this = *ps;
}


template <class T>
void STTSlist<T>::AddHead(STRoot *p)
{
	if (DynamicCast(T, p) == 0)
		STError("STTSlist<T>::AddHead - invalid object");
	STSlist::AddHead(p);
}

template <class T>
void STTSlist<T>::AddTail(STRoot *p)
{
	if (DynamicCast(T, p) == 0)
		STError("STTSlist<T>::AddTail - invalid object");
	STSlist::AddTail(p);
}

/*
#ifndef __DECCXX
template <class T>
T STTSlist<T>::GetHead()
{
	STRoot *p = STSlist::GetHead();
	T t = DynamicCast(T, p);
	return t;
}

template <class T>
T STTSlist<T>::Remove(STRoot *t)
{
	STRoot *p = STSlist::Remove(t);
	return DynamicCast(T, p);
}

template <class T>
T STTSlist<T>::Search(STRoot *t) const
{
	STRoot *p = STSlist::Search(t);
	return DynamicCast(T, p);
}                  


#endif
 */

///////////////////////////////////////////////////////////////////////////////


template <class T>
class STTSlistIterator : public STSlistIterator
{
public:
	STTSlistIterator(const STTSlist<T> &s) : STSlistIterator(s) {}
	virtual T operator () ();
};

template <class T>
T STTSlistIterator<T>::operator() ()
{
	STRoot *p = STSlistIterator::operator() ();
	return DynamicCast(T, p);
}


#else // NO_TEMPLATES

#define STTSlist(T)         STTSlist##T
#define STTSlistIterator(T) STTSlistIterator##T

#define STTSlistdeclare(T)                                              \
class STTSlist(T) : public STSlist										\
{																		\
public:																	\
	STDefineClassInfo													\
    STDeclareAssignClone(STTSlist(T))									\
																		\
	STTSlist(T)() {}													\
	STTSlist(T)(const STTSlist(T) &s) : STSlist(s) {}					\
	void operator = (const STTSlist(T) &s) { STSlist::operator = (s); }	\
																		\
	virtual void          AddHead(STRoot *);      						\
	virtual void          AddTail(STRoot *);      						\
}

#define STTSlistimplement(T)                                            \
int STTSlist(T)::STIsEqual(const STRoot *p) const                       \
{																		\
	return STSlist::STIsEqual(p);										\
}																		\
																		\
STRoot * STTSlist(T)::STClone() const									\
{																		\
	return STNew STTSlist(T)(*this);										\
}																		\
																		\
STRoot * STTSlist(T)::STCreate() const									\
{																		\
	return STNew STTSlist(T)(*this);										\
}																		\
																		\
void STTSlist(T)::STAssign(const STRoot *p)								\
{																		\
	STTSlist(T) *ps = DynamicCast(STTSlist(T) *, p);					\
	if (ps == 0)														\
		STError("STTSlist<T>:STAssign() - invalid obejct");             \
	*this = *ps;														\
}																		\
																		\
void STTSlist(T)::AddHead(STRoot *p)									\
{																		\
	if (DynamicCast(T, p) == 0)											\
		STError("STTSlist<T>::AddHead - invalid object"); 	            \
	STSlist::AddHead(p);												\
}																		\
																		\
void STTSlist(T)::AddTail(STRoot *p)									\
{																		\
	if (DynamicCast(T, p) == 0)											\
		STError("STTSlist<T>::AddTail - invalid object");	            \
	STSlist::AddTail(p);												\
}																		\
																		

#define STTSlistIteratordeclare(T)                                      \
class STTSlistIterator(T) : public STSlistIterator						\
{																		\
public:																	\
	STTSlistIterator(T)(const STTSlist(T) &s) : STSlistIterator(s) {}	\
	virtual T operator () ();											\
}

#define STTSlistIteratorimplement(T)                                    \
T STTSlistIterator(T)::operator() ()									\
{																		\
	STRoot *p = STSlistIterator::operator() ();							\
	return DynamicCast(T, p);											\
}

#endif	// NO_TEMPLATES

#endif
