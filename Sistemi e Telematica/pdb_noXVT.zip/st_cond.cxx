#include <st_dbnew.h>
#include <stdio.h>
#include <stdlib.h>

#include "st_err.h"

static char *Type[] = { "library", "application" };

void ST__DbgCondFail(const char *pcFile, int nLine, const char *pcCond, const char *pcMsg, int nType)
{
	const char *p;
	char b[10];

	if (nType == 0 || nType == 1)
		p = Type[nType];
	else
	{
		p = b;
		sprintf(b, "%d", nType);
	}

	STError("%s(%d): assertion failed \"%s\" on %s --> %s\n",
			pcFile,
			nLine,
			pcCond,
			p,
			pcMsg);
}
