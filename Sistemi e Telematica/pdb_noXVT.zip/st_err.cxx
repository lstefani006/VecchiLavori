#include <st_dbnew.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include <iostream.h>
#include <fstream.h>

#include "st_err.h"

static char *G_Buff = NULL;

static void GetFile();

struct __Start
{
	__Start() { GetFile(); }
};

static __Start __StartGetFile;
static const char env[] = "ST_DEBUG";

static void GetFile()
{
	if (G_Buff == NULL)
		G_Buff = STNew char [16384];
	
	static int bFirst = 1;
	if (bFirst == 1)
	{
		bFirst = 0;

		const char *fn = getenv(env);
		if (fn == NULL)
#ifndef MSDOS
			fn = "/dev/null";
#else
			fn = "debug.log";
#endif

		// uso il cerr ?
		if (strcmp(fn , "") == 0)
			return;

		ofstream *s = STNew ofstream(fn);

		if (!s->fail())
		{
			s->setbuf(NULL, 0);
			cerr = *s;
		}
	}
}


void (*G_pfError)(const char *) = NULL;

void STError(const char *s, ...)
{
	va_list ag;
	va_start(ag, s);

	GetFile();

	vsprintf(G_Buff, s, ag);
	cerr << G_Buff << endl << flush;

	if (G_pfError)
		G_pfError(G_Buff);
		
	abort();
}

void STDebug(const char *s, ...)
{
	const char *fn = getenv(env);
	if (fn == NULL)
		return;

	va_list ag;
	va_start(ag, s);

	GetFile();

	vsprintf(G_Buff, s, ag);
	cerr << G_Buff << endl << flush;
}

//////////////////////////////////////////////////////////

int          __STDebugStack::nTop = 0;
const char * __STDebugStack::aFile[STDebugStack_SIZE];
const char * __STDebugStack::aMsg [STDebugStack_SIZE];
int          __STDebugStack::aLine[STDebugStack_SIZE];

__STDebugStack::__STDebugStack(const char *pcMsg, const char *pcFile, int nLine)
{
	if (nTop >= STDebugStack_SIZE)
		STError("STDebugStack overflow");

	aMsg[nTop] = pcMsg;
	aLine[nTop] = nLine;
	aFile[nTop] = pcFile;
	nTop += 1;
}


void __STDebugStack::Trace()
{
	STDebug("Stack trace");
	for (int i = 0; i < nTop; i++)
		STDebug("Msg = \"%s\", File = \"%s\", Line = %d",
			(aMsg[i] ? aMsg[i] : 0),
			aFile[i],
			aLine[i]);
}
