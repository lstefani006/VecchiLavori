#ifndef __VALIDATORS_H_
#define __VALIDATORS_H_

/**************************************************************************

   Copyright (c) 1995

   Nome File:           STValidators.h
   Autore:              Marco Cresta / Vittorio Regestro
   Data:                21/6/95

   Class:               STValidator e derivate
   Eredita':


**************************************************************************/

#include <st_root.h>
#include "st_diz.h"

/*
 * CLASSE STValidator
 */
class STValidator : public virtual STRoot
{
 public:

	STDefineClassInfo

	STValidator() {}
	STValidator(const STValidator & r);
	void operator = (const STValidator & r);
	 ~STValidator();

	virtual STRoot * STCreate()                const = 0;
	virtual STRoot * STClone()                 const = 0;
	virtual void     STAssign(const STRoot *)        = 0;
	virtual int      STIsEqual(const STRoot *) const = 0;

	virtual STDizWordKey RunValidator(RWCString &) = 0;
};

/*
 * CLASSE STValString
 */
#define STVALSTRING_MAX_LEN 10000

class STValString : public STValidator
{
public:
	STDefineClassInfo
	STDeclareAssignClone(STValString)

#undef Case
#undef None
#undef Upper
#undef Lower
	enum Case { None, Upper, Lower };

	STValString(Case , int theMinLen, int theMaxLen = STVALSTRING_MAX_LEN);
	STValString(       int theMinLen, int theMaxLen = STVALSTRING_MAX_LEN);
private:
	STValString();
public:
	STValString(const STValString & r);
	void operator = (const STValString & r);

	virtual STDizWordKey RunValidator(RWCString &);

protected:
	int    itsMinLen;
	int    itsMaxLen;
	Case   itsCase;
};

/*
 * CLASSE STValNum
 */
class STValNum : public STValidator
{
public:
	STDefineClassInfo
	STDeclareAssignClone(STValNum)

	enum Op { GT, GE, LT, LE, EQ, NE };

	STValNum(Op , double);

private:
	STValNum();

public:
	STValNum(const STValNum & r);
	void operator = (const STValNum & r);

	virtual STDizWordKey RunValidator(RWCString &);

protected:
	Op     itsOp;
	double itsValue;
};


/*
 * CLASSE STValCodFisc
 */
class STValCodFisc : public STValidator
{
public:
	STDefineClassInfo
	STDeclareAssignClone(STValCodFisc)

	STValCodFisc();
	STValCodFisc(const STValCodFisc & r);
	void operator = (const STValCodFisc & r);

	virtual STDizWordKey RunValidator(RWCString &);
};

/*
 * CLASSE STValPartIva
 */
class STValPartIva : public STValidator
{
public:

	STDefineClassInfo
	STDeclareAssignClone(STValPartIva)

	STValPartIva();
	STValPartIva(const STValPartIva & r);
	void operator = (const STValPartIva & r);
	~STValPartIva() {}

	virtual STDizWordKey RunValidator(RWCString &);
};

/*
 * CLASSE STValFlag
 */
class STValFlag : public STValidator
{
public:

	STDefineClassInfo
	STDeclareAssignClone(STValFlag)

	enum Case { None, Upper, Lower };

	STValFlag();
	STValFlag(Case, const RWCString & theRange);
	STValFlag(const RWCString & theRange);
	STValFlag(const STValFlag & r);
	void operator = (const STValFlag & r);

	virtual STDizWordKey RunValidator(RWCString &);

protected:
	RWCString itsRange;
	Case      itsCase;
};


/*
 * CLASSE STValTS
 * 
 * validatori disponibili:
 *   y/Y anno a 2/4 cifre
 *   m   mese 
 *   d   giorno
 *   H   ora (0-23)
 *   M   minuti
 *   S   secondi
 */
class STValTS : public STValidator
{
public:

	STDefineClassInfo
	STDeclareAssignClone(STValTS)

	STValTS();
	STValTS(const RWCString &strFmt);
	STValTS(const STValTS & r);
	void operator = (const STValTS & r);

	virtual STDizWordKey RunValidator(RWCString &);

protected:
	friend class DbTS;
	RWCString m_strFmt;
};




class STValAnd : public STValidator
{
public:

	STDefineClassInfo
	STDeclareAssignClone(STValAnd)

	STValAnd();
	STValAnd(STValidator *a, STValidator *b);
	STValAnd(const STValAnd & r);
	~STValAnd();
	void operator = (const STValAnd & r);

	virtual STDizWordKey RunValidator(RWCString &);

protected:
	STValidator *m_pValA;
	STValidator *m_pValB;
};


class STValOr : public STValidator
{
public:

	STDefineClassInfo
	STDeclareAssignClone(STValOr)

	STValOr();
	STValOr(STValidator *a, STValidator *b);
	STValOr(const STValOr & r);
	~STValOr();
	void operator = (const STValOr & r);

	virtual STDizWordKey RunValidator(RWCString &);

protected:
	STValidator *m_pValA;
	STValidator *m_pValB;
};

#endif
