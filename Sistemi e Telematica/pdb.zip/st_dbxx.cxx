#include <st_dbnew.h>

#include <stdio.h>
#include <stdlib.h>
#include <rw/gslist.h>
#include <iostream.h>
#include <iomanip.h>
#include <strstream.h>


#include <st_err.h>
#include <st_map.h>
#include <st_dbxx.h>
#include <st_cond.h>
#include <st_selit.h>



#if defined(__DECCXX) && !defined(NO_TEMPLATES)
#pragma define_template STTVect<DbVal *>
#pragma define_template STTVect<const DbVal *>
#endif

#ifdef NO_TEMPLATES
	typedef DbVal       *P_DbVal;
	typedef /* const (baco cl) */ DbVal *PC_DbVal;


	// declare(STTVect, P_DbVal)
	declare(STTVect, PC_DbVal);

	implement(STTVect, P_DbVal)
	implement(STTVect, PC_DbVal)
#endif

////////////////////////////////////////////////////////////////////////////


#define DBREG_MAX 400
int                 STDbG::m_DbRegTop = 0;
const STDbClassInfo * STDbG::m_DbReg[DBREG_MAX];


STDbG::STDbG(const STDbClassInfo *pDbClassInfo)
{
	if (m_DbRegTop == DBREG_MAX)
		STError("STDbG table full");

	for (int i = 0; i < m_DbRegTop; i++)
		if (strcmp(m_DbReg[i]->ClassName, pDbClassInfo->ClassName) == 0)
			STError("ClassName duplicato");
			
	m_DbReg[m_DbRegTop++] = pDbClassInfo;
}

void STDbG::DbInfo()
{
}

void STDbG::DbMain()
{
	/*
		Questa inizializzazione e' necessaria in quanto
		una data RWTime non e' inizializzata correttamente
		quando e' statica o globale
	*/
	NullDate = RWTime(RWDate(1, 1, 1901), 0, 0);
	NullDate.SetNull(1);

	for (int i = 0; i < m_DbRegTop; i++)
		DbCreateMapping(i);
}

void STDbG::DbCreateMapping(int n)
{
	if (&(m_DbReg[n]->Map()))
		return;  /* questa classe ha gia` il mapping */

	/* creo il mapping di questa classe */
	m_DbReg[n]->m_pCreateMap();
}

const STDbClassInfo & STDbG::DbGetClassInfo(const char *theClassName)
{
	for (int i = 0; i < m_DbRegTop; i++)
		if (strcmp(m_DbReg[i]->ClassName, theClassName) == 0)
			return *(m_DbReg[i]);
	STError("ClassName non trovata");
	return *(m_DbReg[0]);
}

STDbBase * STDbG::DbCreateObject(const char *theClassName)
{
	for (int i = 0; i < m_DbRegTop; i++)
		if (strcmp(m_DbReg[i]->ClassName, theClassName) == 0)
			return m_DbReg[i]->m_pGetClassInstance();

	STError("identificatore di classe non sconosciuto (pgm/db non allieati)");
	return 0;
}

//////////////////////////////////////////////////////////////////////////////


STRegisterDbBase()


//////////////////////////////////////////////////////////////////////////////
STDbBase::STDbBase(int Dummy)
	: m_bOnLevel3(0), m_bErased(0), m_pBack(NULL)
{
}

STDbBase::STDbBase(const STDbBase &r)
	: m_bOnLevel3(r.m_bOnLevel3), m_bErased(r.m_bErased), m_pBack(NULL)
{
	if (r.m_pBack)
		m_pBack = DynamicCast(STDbBase *, r.m_pBack->STClone());
}

void STDbBase::operator = (const STDbBase &r)
{
	ResetBack();
	m_bOnLevel3 = r.m_bOnLevel3;
	m_bErased = r.m_bErased;
	if (r.m_pBack)
		m_pBack = DynamicCast(STDbBase *, r.m_pBack->STClone());
}

STDbBase::~STDbBase()
{
	STDelete m_pBack;
}

void STDbBase::SetBack()
{
	STDelete m_pBack;
	m_pBack = NULL;
	m_bErased = 0;
	m_pBack = DynamicCast(STDbBase *, STClone());
}

void STDbBase::ResetBack()
{
	STDelete m_pBack;
	m_pBack = NULL;
	m_bErased = 0;
}

/*
 * Questa funzione serve anche per tutte le classi derivate
 * da STDbBase in quanto usa il mapping. Ne consegue che le
 * classi derivate da STDbBase non devono ridefinire STIsEqual
 */
int STDbBase::STIsEqual(const STRoot *p) const
{
	STDbBase *pDbBase = DynamicCast(STDbBase *, p);
	if (pDbBase == NULL)
		return 0;

	if (pDbBase->GetCI() != this->GetCI())
		return 0;


	ST_COND_LIBR(pDbBase, "STDbBase::STIsEqual");
		
	const STDbMap &theThisMap = (GetCI()->Map());
	const STDbMap &thePMap    = (pDbBase->GetCI()->Map());

	ST_COND_LIBR(&theThisMap == &thePMap, "STDbBase::STIsEqual");

	for (int i = 0; i < theThisMap.Size(); i++)
	{
		int thisOffset = theThisMap[i].Offset();
		int POffset    = thePMap   [i].Offset();
		ST_COND_LIBR(thisOffset == POffset, "STDbBase::STIsEqual");

		const DbVal *a = this   ->GetDbCol(thisOffset);
		const DbVal *b = pDbBase->GetDbCol(POffset);

		if (a->STIsEqual(b) == 0)
		{
			cerr << "STDbBase::STIsEqual fallito al passaggio " << i << " " << theThisMap[i].Col() << "\n";
			return 0;
		}
	}
	return 1;
}

int STDbBase::STCompareTo(const STRoot *p) const
{
	STDbBase *pDbBase = DynamicCast(STDbBase *, p);
	if (pDbBase == 0)
		return 0;

	if (pDbBase->GetCI() != this->GetCI())
		return 0;


	ST_COND_LIBR(pDbBase, "STDbBase::STIsEqual");
		
	const STDbMap &theThisMap = (this   ->GetCI()->Map());
	const STDbMap &thePMap    = (pDbBase->GetCI()->Map());

	ST_COND_LIBR(&theThisMap == &thePMap, "STDbBase::STIsEqual");

	for (int i = 0; i < theThisMap.Size(); i++)
	{
		int thisOffset = theThisMap[i].Offset();
		int POffset    = thePMap   [i].Offset();
		ST_COND_LIBR(thisOffset == POffset, "STDbBase::STIsEqual");

		const DbVal *a = this   ->GetDbCol(thisOffset);
		const DbVal *b = pDbBase->GetDbCol(POffset);

		int r = a->STCompareTo(b);
		if (r)
			return r;
	}
	return 0;
}


//////////////////////////////////////////////////////////////////////

void STDbBase::CreateSql() const
{
	const STDbMap &theMap = GetCI()->Map();


	fprintf(stderr, "CREATE TABLE %s\n", theMap[0].Table());
	fprintf(stderr, "(\n");

	for (int i = 0; i < theMap.Size(); i++)
	{
		fprintf(stderr, "\t%-20s ", theMap[i].Col());

		const DbVal *pCol = GetDbCol(theMap[i].Offset());
		fprintf(stderr, "%-14s", (const char *)pCol->GetDbType());

		if (theMap[i].isKey())
			fprintf(stderr, " PRIMARY KEY");

		if (i + 1 != theMap.Size())
			fprintf(stderr, ",");

		fprintf(stderr, "\n");
	}
	fprintf(stderr, ");\n\n");
}

void STDbG::DbCreateSql(int &ac, char **&av)
{
	if (ac >= 2 && strcmp(av[1], "-d") == 0)
	{
		ac--;
		av++;
	}
	else
		return;

	for (int i = 0; i < m_DbRegTop; i++)
	{
		if (m_DbReg[i] == &STDbBase::CI)
			continue;

		STDbBase *p = m_DbReg[i]->m_pGetClassInstance();
		p->CreateSql();
		STDelete p;
	}
	exit(0);
}


//////////////////////////////////////////////////////////////////////////////


const DbVal * STDbBase::GetDbCol(const STDbWhereData &w) const
{
	if (w.GetCI() == 0)
		STError("non posso convertire in DbVal un STDbWhereData senza CI");
		
	if (w.GetCI() == GetCI())
		return GetDbCol(w.GetOffset());
		

	STError("condizione STDbWhereData non allieata con la classe");
	return NULL;
}

//////////////////////////////////////////////////////////////////////////////

/*
 * member function
 * insert di un record
 */
STDbError STDbBase::Insert(STDbTransaction &tr) const
{
	STDbError e = ST_DB_OK;

	const STDbMap &theMap = (GetCI()->Map());

	RWCString str(RWSize_T(2048));
	
#ifndef NO_TEMPLATES
	STTVect<DbVal *> aDbStack;
#else
	STTVect(P_DbVal) aDbStack;
#endif

	const STDbColMap &theDbColMap = theMap[0];
	str  = "insert into ";
	str += theDbColMap.Table();
	str += " (";

	for (int i = 0; i < theMap.Size(); i++)
	{
		const STDbColMap &theDbColMap = theMap[i];

		aDbStack.Append((DbVal *)GetDbCol(theDbColMap.Offset()));

		if (i)
			str += ", ";
		str += theDbColMap.Col();
	}


	str += ") values (";

	for (i = 0; i < theMap.Size(); i++)
	{
		if (i > 0)
			str += ", ";

		str += tr.GetParameterMarker(i);
	}
	str += ")";


	STDbStmt cmd(tr);
	e = cmd.Parse(str, aDbStack);
	if (e == ST_DB_OK)
		e = cmd.Exec();


	if (e == ST_DB_OK)
		((STDbBase *)this)->SetBack();

	ST_COND_LIBR(e == ST_DB_OK || e == ST_DB_DUPL_KEY || e == ST_DB_LOCK, "STDbBase::Insert() - internal error");
	return e;
}

/*
 * member function
 * update di un record
 */
STDbError STDbBase::Update(STDbTransaction &tr) const
{
	STDbError e = ST_DB_OK;

	RWCString str     (RWSize_T(2048));

	const STDbMap &theMap = (GetCI()->Map());

#ifndef NO_TEMPLATES
	STTVect<DbVal *> aDbStack;
#else
	STTVect(P_DbVal) aDbStack;
#endif


	int nVar = 0;

	str  = "update ";
	str += theMap.Table();
	str += " set ";


	for (int i = 0; i < theMap.Size(); i++)
	{
		const STDbColMap &theDbColMap = (theMap[i]);

		if (i > 0)
			str += ", ";

		str += theDbColMap.Col() + " = " + tr.GetParameterMarker(nVar++);

		aDbStack.Append((DbVal *)GetDbCol(theDbColMap.Offset()));
	}


	int bKey = 0;
	for (i = 0; i < theMap.Size(); i++)
	{
		const STDbColMap &theDbColMap = (theMap[i]);
		if (theDbColMap.isKey())
		{
			if (bKey == 0)
				str += " where ";
			else
				str += " and ";

			str += theDbColMap.Col() + " = " + tr.GetParameterMarker(nVar++);

			if (m_pBack != NULL && m_bOnLevel3)
				aDbStack.Append((DbVal *)m_pBack->GetDbCol(theDbColMap.Offset()));
			else
				aDbStack.Append((DbVal *)GetDbCol(theDbColMap.Offset()));

			bKey = 1;
		}
	}

	STDbStmt cmd(tr);
	e = cmd.Parse(str, aDbStack);
	if (e == ST_DB_OK)
		e = cmd.Exec();

	if (e == ST_DB_OK)
		((STDbBase *)this)->SetBack();

	ST_COND_LIBR(e == ST_DB_OK || e == ST_DB_NOT_FOUND || e == ST_DB_LOCK || e == ST_DB_DUPL_KEY, "STDbBase::Update() - internal error");
	return e;
}


/*
 * member function
 * delete di un record
 */
STDbError STDbBase::Delete(STDbTransaction &tr) const
{
	STDbError e = ST_DB_OK;

	RWCString str(RWSize_T(2048));

	const STDbMap &theMap = (GetCI()->Map());

#ifndef NO_TEMPLATES
	STTVect<DbVal *> aDbStack;
#else
	STTVect(P_DbVal) aDbStack;
#endif


	str  = "delete from ";
	str += theMap.Table();
	str += " where ";

	int nVar = 0;
	int nColInTable = 0;

	for (int i = 0; i < theMap.Size(); i++)
	{
		STDbColMap theDbColMap(theMap[i]);

		if (theDbColMap.isKey())
		{
			if (nColInTable > 0)
				str += " and ";

			str += RWCString(theDbColMap.Col()) + " = " + tr.GetParameterMarker(nVar++);

			if (m_pBack != NULL && m_bOnLevel3)
				aDbStack.Append((DbVal *)m_pBack->GetDbCol(theDbColMap.Offset()));
			else
				aDbStack.Append((DbVal *)GetDbCol(theDbColMap.Offset()));

			nColInTable++;
		}
	}

	STDbStmt cmd(tr);
	e = cmd.Parse(str, aDbStack);
	if (e == ST_DB_OK)
		e = cmd.Exec();

	if (e == ST_DB_OK)
	{
		((STDbBase *)this)->ResetBack();
		((STDbBase *)this)->Erase();
	}

	ST_COND_LIBR(e == ST_DB_OK || e == ST_DB_NOT_FOUND || e == ST_DB_LOCK, "STDbBase::Delete() - internal error");
	return e;
}


/*
 * member function
 * select di un record gia` allocato
 */
STDbError STDbBase::Select(STDbTransaction &tr, STDbWhereLogical theDbWhere, STSelectType st)
{
	const STDbClassInfo *DbWhereCI = theDbWhere.GetUniqueCI();
	if (DbWhereCI == NULL)
		STError("STDbBase::Select() invocato con una where condition inappropriata");

	if (DbWhereCI != GetCI())
		STError("STDbBase::Select() invocato con una where condition di un'altra classe");

	STDbSelectIterator it(tr, GetCI()->ClassName, theDbWhere, st);

	STDbError e;

	STDbBase *p1 = it(this);
	e = it.Error();
	if (e == ST_DB_OK)
	{
		STDbBase *p2 = it();
		STDelete p2;

		e = it.Error();
		if (e == ST_DB_OK)
			ST_Throw (STDbException(ST_DB_NOT_UNIQUE, "virtual STDbBase::Select() - where condition matches more objects"));
		e = ST_DB_OK;
	}

	if (e == ST_DB_OK)
		e = (p1 != NULL) ? ST_DB_OK : ST_DB_NOT_FOUND;


	ST_COND_LIBR(e == ST_DB_OK || e == ST_DB_NOT_FOUND || e == ST_DB_LOCK, "virtual STDbBase::Select() - internal error");

	return e;
}

/*
 * funzione statica
 * crea e valorizza i record di tipo theClassName o derivati nella lista
 * non ha condizione di where
 */
STDbError STDbBase::Select(STDbTransaction &tr, const char *theClassName, STDbSlist &listOut, STSelectType st)
{
	return Select(tr, theClassName, STDbWhereLogicalTrue, listOut, st);
}

STDbError STDbBase::Select(STDbTransaction &tr, const char *theClassName, const STDbWhereLogical &w, STDbSlist &listOut, STSelectType st)
{
	STDbSelectIterator it(tr, theClassName, w, st);

	STDbBase *p = NULL;

	while(p = it())
		listOut.AddTail(p);

	if (it.Error() == ST_DB_LOCK)
		return ST_DB_LOCK;

	return listOut.nOfItems() == 0 ? ST_DB_NOT_FOUND : ST_DB_OK;
}

////////////////////////////////////////////////////

ostream & STDbBase::STDebug(ostream & s) const
{
	s << "ClassName \"" << GetCI()->ClassName << "\"\n";

	const STDbMap &theThisMap = (GetCI()->Map());

	for (int i = 0; i < theThisMap.Size(); i++)
	{
		const DbVal *a = this->GetDbCol(theThisMap[i].Offset());
		s << " " << setiosflags(ios::left) << setw(20) << theThisMap[i].Col() << resetiosflags(ios::left)
		  << "(" << setw(4) << theThisMap[i].Offset() << ") --> ";
		s << a->DbPrint(ST_DB_ORACLE) << "\n";
	}

	if (m_bErased)
		s << "\tErased\n";
	if (m_pBack)
	{
		s << "\tRECORD OMBRA\n";
		m_pBack->STDebug(s);
	}
   return s;
}


STDbWhereLogical STDbBase::GetWhereCondition() const
{
	STDbWhereLogical w;

	const STDbMap &theMap = (GetCI()->Map());
	int bFirst = 1;
	for (int k = 0; k < theMap.Size(); k++)
	{
		if (theMap[k].isKey())
		{
			/* ho una colonna chiave */
			STDbWhereData dbWhereCond(GetCI(), theMap[k].Offset());
			const DbVal *pDbVal;
			
			if (m_pBack != NULL && m_bOnLevel3)
				pDbVal = m_pBack->GetDbCol(theMap[k].Offset());
			else
				pDbVal = GetDbCol(theMap[k].Offset());

			if (bFirst == 1)
			{
				bFirst = 0;
				w = STDbWhereLogical(dbWhereCond == *pDbVal);
			}
			else
				w = w && dbWhereCond == *pDbVal;
		}
	}

	return w;
}

int STDbBase::AreKeyFieldsChanged() const
{
	if (m_pBack == 0)
		return 0;

	const STDbMap &theMap = (GetCI()->Map());

	for (int k = 0; k < theMap.Size(); k++)
	{
		if (theMap[k].isKey())
		{
			/* ho una colonna chiave */
			const DbVal *pDbValNew = this   ->GetDbCol(theMap[k].Offset());
			const DbVal *pDbValOld = m_pBack->GetDbCol(theMap[k].Offset());

			if (pDbValNew->STIsEqual(pDbValOld) == 0)
				return 1;
		}
	}

	return 0;
}

////////////////////////////////////////////////////

long STDbBase::Count(STDbTransaction &tr, const STDbWhereLogical &w)
{
	const STDbClassInfo *DbWhereCI = w.GetUniqueCI();
	if (DbWhereCI == 0)
		STError("STDbBase::Count() invocato con una where condition inappropriata");

	RWCString str(RWSize_T(2048));

	str  = "select count(*) from ";
	str += DbWhereCI->Map().Table();

	str += " where " + w.StrWhere(tr);

#ifdef NO_TEMPLATES
	STTVect(P_DbVal) v = w.ValWhere();
#else
	STTVect<DbVal *> v = w.ValWhere();
#endif

	/* ho composto il mio statment sql */
	STDbStmt cmd(tr);
	STDbError e = cmd.Parse(str, v);
	DbInt r(12);

	if (e == ST_DB_OK)
		e = cmd.Bind(r);
	if (e == ST_DB_OK)
		e = cmd.Exec();
	if (e == ST_DB_OK)
		e = cmd.Fetch();
	
	ST_COND_LIBR(e == ST_DB_OK || e == ST_DB_NOT_FOUND, "STDbBase::Count() - internal error");
	return r;
}

STDbError STDbBase::LockTable(STDbTransaction &tr, const STDbClassInfo &rDbClassInfo)
{
	RWCString str(RWSize_T(2048));

	str  = "lock table ";
	str += rDbClassInfo.Map().Table();
	str += " in exclusive mode";

	/* ho composto il mio statment sql */
	STDbStmt cmd(tr);
	STDbError e = cmd.Parse(str);
	if (e == ST_DB_ERROR)
		e = cmd.Exec();
	
	ST_COND_LIBR(e == ST_DB_OK || e == ST_DB_LOCK, "STDbBase::LockTable() - internal error");
	return e;
}


////////////////////////////////////////////////////////////////////////////////////


STDbError STDbBase::Load(STDbTransaction &tr, const STDbWhereLogical &w, STSelectType st)
{
	// LEO ResetBack();

	STDbError e = Select(tr, w, st);
	
	// LEO if (e == ST_DB_OK)
	// LEO 	SetBack();
	
	return e;
}

void STDbBase::Erase()
{
	m_bErased  = 1;
}

int STDbBase::Check(STDbTransaction &tr) const
{
	if (m_pBack == 0)
		return 1;
	
	STDbBase *pT = DynamicCast(STDbBase *, STCreate());

	STDbError e;
	e = pT->Select(tr, m_pBack->GetWhereCondition(), STSelectForUpdate);

	int r = 0;

	if (e == ST_DB_OK && pT->STIsEqual(m_pBack))
		r = 1;

	if (r == 0)
	{
		cerr << "STDbBase::Check - confronto fallito\n";
		m_pBack->STDebug(cerr);
		pT->STDebug(cerr);
		cerr << "END STDbBase::Check - confronto fallito\n";
	}
	
	STDelete pT;
	return r;
}


class Level3SetFlag
{
public:
	Level3SetFlag(int *p) { m_p = p; *m_p = 1; }
	~Level3SetFlag()      {          *m_p = 0; }
private:
	int *m_p;
};

STDbError STDbBase::Save(STDbTransaction &tr, SaveType sv) const
{
	// Serve solo per settare a 1 il flag m_bOnLevel3
	// E' necessario fare cosi` in quanto su eccezione e` obbligatorio
	// resettare il flag
	Level3SetFlag OnLevel3(&(((STDbBase *)this)->m_bOnLevel3));
	
	STDbError e = ST_DB_OK;

	if (m_pBack == 0 && m_bErased == 0)
	{
		// record nuovo e non cancellato
		if (sv & InsertOnly)
		{
			e = Insert(tr);
			// LEO if (e == ST_DB_OK)
			// LEO 	((STDbBase *)this)->SetBack();
		}
		return e;
	}

	if (m_pBack != 0 && m_bErased == 1)
	{
		// record caricato da cancellare
		if (sv & DeleteOnly)
		{
			e = m_pBack->Delete(tr);
			// LEO if (e == ST_DB_OK)
			// LEO {
			// LEO 	((STDbBase *)this)->ResetBack();
			// LEO 	((STDbBase *)this)->Erase();
			// LEO }
		}
		return e;
	}

	if (m_pBack != 0 &&                     // record caricato non cancellato
	    m_pBack->STIsEqual(this) == 0)      // e modificato
	{
		if (sv & UpdateOnly)
		{
			e = Update(tr);
			// LEO if (e == ST_DB_OK)
			// LEO 	((STDbBase *)this)->SetBack();
		}
		return e;
	}

	return ST_DB_OK;
}




int STDbBase::IsRecordChanged() const
{
	if (m_pBack == 0 && m_bErased == 0)
		return 1;

	if (m_pBack == 0 && m_bErased == 1)
		return 0;

	if (m_bErased)
		return 1;
	
	if (STIsEqual(m_pBack) == 0)
		return 1;
	
	return 0;
}

STDbBase::SaveType STDbBase::GetSaveType() const
{
	if (m_pBack == 0 && m_bErased == 0)
	{
		// record nuovo e non cancellato
		return InsertOnly;
	}

	if (m_pBack != 0 && m_bErased == 1)
	{
		// record caricato da cancellare
		return DeleteOnly;
	}

	if (m_pBack != 0 &&                     // record caricato non cancellato
	    m_pBack->STIsEqual(this) == 0)      // e modificato
	{
		return UpdateOnly;
	}

	return None;
}


////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////


STImplementClassInfo1(STDbEl, STRoot)
