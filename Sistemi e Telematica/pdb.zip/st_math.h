#ifndef __ST_MATH_H__
#define __ST_MATH_H__

/*
 * costante pi greco
 */ 
#define G_PI 3.14159265358979323846264338327950288



/*
 * Funzioni per la ricerca di soluzioni in una funzione f(x) - y = 0
 *  x1...x2 intervallo di ricerca; deve essere (f(x1) - y) * (f(x2) - y) <= 0
 *
 *  l'algoritmo esce quando una delle seguenti condizioni e' verificata
 *    fabs(x2 - x1) <= dx 
 *    fabs(f(xSol) - y) <= dy
 *
 *  p e' un parametro di appoggio per dati necessari alla funzione f
 */

double Metodo_Dicotomico(double (*f)(double, void *), double y,
                         double x1, double x2,
                         double dx, double dy,
                         void *p);


double Metodo_Tangenti(double (*f)(double, void *), double y,
                       double x1, double x2,
                       double dx, double dy,
                       void *p);

#endif
