#ifndef __ST_TVECT_H__
#define __ST_TVECT_H__

#include <stdlib.h>

const INITIAL_DIMENSION = 4;


#ifndef NO_TEMPLATES

template <class T>
class STTVect
{
public:
	STTVect(int sz = INITIAL_DIMENSION);
	STTVect(const STTVect<T> &);
	~STTVect() { STDelete [] m_pT; }
	void operator = (const STTVect<T> &);

	void Reset() { m_nTop = 0; }
	void Append(T a);
	void Append(const STTVect<T> &s);

	void Resize(int sz);
	int  Find(T a) const;
	int  Size() const { return m_nTop; }

	T& operator [] (int i);
	const T&  operator [] (int i) const;

	T& Last();
	const T& Last() const;

	int Remove(int i);

	void SetCanResize(int i) { m_bCanResize = i; }

protected:
	int m_bCanResize;
	int m_nTop;
	int m_nMaxSize;
	T  *m_pT;
};


template <class T>
STTVect<T>::STTVect(int sz)
{
	m_bCanResize = 1;
	m_nMaxSize = sz;
	m_nTop     = 0;
	m_pT       = STNew T[m_nMaxSize];
}

template <class T>
STTVect<T>::STTVect(const STTVect<T> &v)
{
	m_bCanResize = v.m_bCanResize;
	m_nMaxSize = v.m_nMaxSize;
	m_nTop     = v.m_nTop;
	m_pT       = STNew T[m_nMaxSize];
	for (int i = 0; i < m_nTop; i++)
		m_pT[i] = v.m_pT[i];
}

template <class T>
void STTVect<T>::operator = (const STTVect<T> &v)
{
	STDelete [] m_pT;
	m_bCanResize = v.m_bCanResize;
	m_nMaxSize   = v.m_nMaxSize;
	m_nTop       = v.m_nTop;
	m_pT         = STNew T[m_nMaxSize];
	for (int i = 0; i < m_nTop; i++)
		m_pT[i] = v.m_pT[i];
}

template <class T>
void STTVect<T>::Append(T a)
{
	if (m_nTop >= m_nMaxSize)
		Resize(m_nMaxSize * 2);

	m_pT[m_nTop++] = a;
}

template <class T>
void STTVect<T>::Resize(int sz)
{
	if (sz > m_nMaxSize)
	{
		if (!m_bCanResize)
			abort();

		T *p = STNew T [sz];
		for (int i = 0; i < m_nTop; i++)
			p[i] = m_pT[i];

		STDelete [] m_pT;
		m_pT = p;
		m_nMaxSize = sz;
	}
}

template <class T>
void STTVect<T>::Append(const STTVect<T> &s)
{
	for (int i = 0; i < s.m_nTop; i++)
		Append(s.m_pT[i]);
}

template <class T>
T & STTVect<T>::operator [] (int i)
{
	if (i < 0 || i >= m_nTop)
		abort();
	
	return m_pT[i];
}

template <class T>
const T & STTVect<T>::operator [] (int i) const
{
	if (i < 0 || i >= m_nTop)
		abort();
	
	return m_pT[i];
}

template <class T>
T & STTVect<T>::Last()
{
	if (m_nTop == 0)
		abort();
	
	return m_pT[m_nTop - 1];
}

template <class T>
const T & STTVect<T>::Last() const
{
	if (m_nTop == 0)
		abort();
	
	return m_pT[m_nTop - 1];
}

template <class T>
int STTVect<T>::Find(T a) const
{
	for (int i = 0; i < m_nTop; i++)
		if (m_pT[i] == a)
			return 1;
	return 0;
}

template <class T>
int STTVect<T>::Remove(int i)
{
	if (i >= 0 && i < m_nTop)
	{
		for (int j = i + 1; j < m_nTop; j++)
			m_pT[j - 1] = m_pT[j];
		m_nTop--;
		return 1;
	}
	return 0;
}

#else // NO_TEMPLATES


#include <rw/generic.h>

#define STTVect(T) STTVect##T

#define STTVectdeclare(T)                                         \
class STTVect(T)												  \
{																  \
public:															  \
	STTVect(T)(int sz = INITIAL_DIMENSION);						  \
	STTVect(T)(const STTVect(T) &);								  \
	~STTVect(T)();												  \
	void operator = (const STTVect(T) &);						  \
																  \
	void Reset() { m_nTop = 0; }								  \
	void Append(T a);											  \
	void Append(const STTVect(T) &s);							  \
																  \
	void Resize(int sz);										  \
	int  Find(T a) const;										  \
	int  Size() const { return m_nTop; }						  \
																  \
	T& operator [] (int i) { return m_pT[i]; }					  \
	const T &  operator [] (int i) const { return m_pT[i]; }	  \
	                                                              \
	T& Last();                                                    \
	const T& Last() const;                                        \
																  \
	int Remove(int i);											  \
	void SetCanResize(int i) { m_bCanResize = i ; }               \
																  \
protected:														  \
	int m_bCanResize;                                             \
	int m_nTop;													  \
	int m_nMaxSize;												  \
	T  *m_pT;													  \
}


#define STTVectimplement(T)                                       \
STTVect(T)::STTVect(T)(int sz)									  \
{																  \
	m_bCanResize = 1;                                             \
	m_nMaxSize   = sz;											  \
	m_nTop       = 0;											  \
	m_pT         = STNew T[m_nMaxSize];							  \
}																  \
																  \
STTVect(T)::STTVect(T)(const STTVect(T) &v)						  \
{																  \
	m_bCanResize = v.m_bCanResize;								  \
	m_nMaxSize   = v.m_nMaxSize;								  \
	m_nTop       = v.m_nTop;									  \
	m_pT         = STNew T[m_nMaxSize];							  \
	for (int i = 0; i < m_nTop; i++)							  \
		m_pT[i] = v.m_pT[i];									  \
}                                                                 \
																  \
STTVect(T)::~STTVect(T)() { STDelete [] m_pT; }					  \
																  \
void STTVect(T)::operator = (const STTVect(T) &v)				  \
{																  \
	STDelete [] m_pT;											  \
	m_bCanResize = v.m_bCanResize;								  \
	m_nMaxSize = v.m_nMaxSize;									  \
	m_nTop     = v.m_nTop;										  \
	m_pT       = STNew T[m_nMaxSize];							  \
	for (int i = 0; i < m_nTop; i++)							  \
		m_pT[i] = v.m_pT[i];									  \
}																  \
																  \
void STTVect(T)::Append(T a)									  \
{																  \
	if (m_nTop >= m_nMaxSize)									  \
		Resize(m_nMaxSize * 2);									  \
																  \
	m_pT[m_nTop++] = a;											  \
}																  \
																  \
void STTVect(T)::Resize(int sz)									  \
{																  \
	if (sz > m_nMaxSize)										  \
	{															  \
		if (!m_bCanResize)                                        \
			abort();                                              \
		T *p = STNew T [sz];									  \
		for (int i = 0; i < m_nTop; i++)						  \
			p[i] = m_pT[i];										  \
																  \
		STDelete [] m_pT;										  \
		m_pT = p;												  \
		m_nMaxSize = sz;										  \
	}															  \
}																  \
																  \
void STTVect(T)::Append(const STTVect(T) &s)					  \
{																  \
	for (int i = 0; i < s.m_nTop; i++)							  \
		Append(s.m_pT[i]);										  \
}																  \
																  \
int STTVect(T)::Find(T a) const									  \
{																  \
	for (int i = 0; i < m_nTop; i++)							  \
		if (m_pT[i] == a)										  \
			return 1;											  \
	return 0;													  \
}																  \
																  \
int STTVect(T)::Remove(int i)									  \
{																  \
	if (i >= 0 && i < m_nTop)									  \
	{															  \
		for (int j = i + 1; j < m_nTop; j++)					  \
			m_pT[j - 1] = m_pT[j];								  \
		m_nTop--;												  \
		return 1;												  \
	}															  \
	return 0;													  \
}																  \
                                                                  \
T & STTVect(T)::Last()                                            \
{                                                                 \
	if (m_nTop == 0)                                              \
		abort();                                                  \
	                                                              \
	return m_pT[m_nTop - 1];                                      \
}                                                                 \
                                                                  \
const T & STTVect(T)::Last() const                                \
{                                                                 \
	if (m_nTop == 0)                                              \
		abort();                                                  \
	                                                              \
	return m_pT[m_nTop - 1];                                      \
}
																  

#endif // NO_TEMPLATES

#endif
