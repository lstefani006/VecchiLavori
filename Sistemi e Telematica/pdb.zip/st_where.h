#ifndef __ST_WHERE_H__
#define __ST_WHERE_H__

#include <rw/cstring.h>
#include <rw/rwtime.h>
#include <rw/rwdate.h>

#include <st_dbdat.h>
#include <st_tvect.h>

struct STDbClassInfo;

////////////////////////////////////////////////////////////////////////

#ifdef NO_TEMPLATES
	#ifndef D_STTVectP_DbVal  
		#define D_STTVectP_DbVal   
		typedef class DbVal *P_DbVal;
		declare(STTVect, P_DbVal);
	#endif

	#ifndef D_STTVectP_STDbClassInfo
		#define D_STTVectP_STDbClassInfo
		typedef /* baco cl const */ STDbClassInfo *P_STDbClassInfo;
		declare(STTVect, P_STDbClassInfo);
	#endif

	#ifndef D_STTVectint
		#define D_STTVectint
		declare(STTVect, int);
	#endif

#endif // NO_TEMPLATES


class STDbWhereData
{
public:
	STDbWhereData(const STDbClassInfo *pCI, int nOffset);

	STDbWhereData(const RWCString &);
	STDbWhereData(const char *);
	STDbWhereData(char *);

	STDbWhereData(int n);
	STDbWhereData(float n);
	STDbWhereData(double n);
	STDbWhereData(char n);
	STDbWhereData(const RWTime &);
	
	STDbWhereData(const DbVal &a);
	STDbWhereData(const STDbWhereData &r);

	void operator = (const STDbWhereData &);

	~STDbWhereData() { STDelete m_pDbVal; }

	const RWCString &       Str()       const { return m_String; }
	const STDbClassInfo *   GetCI()     const { return m_pCI; }
	int                     GetOffset() const { return m_nOffset; }

	DbVal *                 GetDbVal() const { return m_pDbVal; }


protected:

	STDbWhereData() : m_pCI(NULL), m_nOffset(0), m_pDbVal(NULL) {}

	void Set(const STDbWhereData &w);

	RWCString                m_String;
	const STDbClassInfo     *m_pCI;
	int                      m_nOffset;
	DbVal                   *m_pDbVal;
};

////////////////////////////////////////////////////////////////////////

class STDbWhereLogical
{
public:
	STDbWhereLogical(const STDbWhereData &,    const STDbWhereData &,    const RWCString &);
	STDbWhereLogical(const STDbWhereLogical &, const STDbWhereLogical &, const RWCString &);
	STDbWhereLogical(const STDbWhereData &,    const RWCString &);
	STDbWhereLogical(const STDbWhereLogical &);
	void operator = (const STDbWhereLogical &);
	~STDbWhereLogical();

	const RWCString &         Str()            const { return m_String; }
	int                       GetFirstOffset() const { return m_Offset[0]; }

	const STDbClassInfo *     GetUniqueCI()    const;

	void                      AppendDbVal(const DbVal *);

	RWCString                 StrWhere(class STDbTransaction &) const;

#ifndef NO_TEMPLATES
	STTVect<DbVal *>          ValWhere() const { return m_DbVal; }
#else
	STTVect(P_DbVal)          ValWhere() const { return m_DbVal; }    
#endif

protected:
	friend class STDbBase;

	STDbWhereLogical() {}

	RWCString                      m_String;

#ifndef NO_TEMPLATES
	STTVect<DbVal *>               m_DbVal;
	STTVect<STDbClassInfo *>       m_CI;
	STTVect<int>                   m_Offset;
#else
	STTVect(P_DbVal)               m_DbVal;
	STTVect(P_STDbClassInfo)       m_CI;
	STTVect(int)                   m_Offset;
#endif
};

STDbWhereLogical Like(const STDbWhereData &a, const char *);
STDbWhereLogical IsNull(const STDbWhereData &a);
STDbWhereLogical IsNotNull(const STDbWhereData &a);

extern const STDbWhereLogical STDbWhereLogicalTrue;

STDbWhereLogical operator && (const STDbWhereLogical &a, const STDbWhereLogical &b);
STDbWhereLogical operator || (const STDbWhereLogical &a, const STDbWhereLogical &b);

STDbWhereLogical operator == (const STDbWhereData &a,    const STDbWhereData &b);
STDbWhereLogical operator != (const STDbWhereData &a,    const STDbWhereData &b);   
STDbWhereLogical operator >  (const STDbWhereData &a,    const STDbWhereData &b);
STDbWhereLogical operator >= (const STDbWhereData &a,    const STDbWhereData &b);
STDbWhereLogical operator <  (const STDbWhereData &a,    const STDbWhereData &b);
STDbWhereLogical operator <= (const STDbWhereData &a,    const STDbWhereData &b);

STDbWhereLogical operator == (const STDbWhereData &a,    const DbVal &b);
STDbWhereLogical operator != (const STDbWhereData &a,    const DbVal &b);   
STDbWhereLogical operator >  (const STDbWhereData &a,    const DbVal &b);
STDbWhereLogical operator >= (const STDbWhereData &a,    const DbVal &b);
STDbWhereLogical operator <  (const STDbWhereData &a,    const DbVal &b);
STDbWhereLogical operator <= (const STDbWhereData &a,    const DbVal &b);

#endif
