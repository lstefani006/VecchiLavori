#ifndef __ST_DBLST_H__
#define __ST_DBLST_H__

#include <st_slist.h>
#include <st_dbxx.h>

class STDbSlist : public STSlist, public STDbEl
{
public:
	STDefineClassInfo
	STDeclareAssignClone(STDbSlist)

	STDbSlist() {}
	STDbSlist(const STDbSlist &s) : STSlist(s) {}
	void operator = (const STDbSlist &);

	virtual void      AddHead(STRoot *);      // add at head of list
	virtual void      AddTail(STRoot *);      // add at tail of list
	virtual STRoot *  GetHead();              // return and remove head of list
	virtual STRoot *  Remove(STRoot *);       // remove the element
	virtual STRoot *  Search(STRoot *) const; // search for Obj

	STDbError   Select(STDbTransaction &, const char *theClassName, const STDbWhereLogical &, STSelectType = STSelectNoLock);
	STDbError   Select(STDbTransaction &, const char *theClassName,                           STSelectType = STSelectNoLock);

	STDbError Load(STDbTransaction &, const char *theClassName, const STDbWhereLogical &, STSelectType = STSelectNoLock);

	virtual void      Erase();
	virtual void      Add(STDbBase *);
	virtual int       Check(STDbTransaction &) const;
	virtual STDbError Save(STDbTransaction &, SaveType = All) const;

	void              SetBack();
	void              ResetBack();

	virtual ostream & STDebug(ostream &) const;
};

///////////////////////////////////////////////////////////////////////////////

class STDbSlistIterator : public STSlistIterator
{
public:
	STDbSlistIterator(const STDbSlist &s) : STSlistIterator(s) {}

	STDbBase * operator () ();
};

///////////////////////////////////////////////////////////////////////////////
             
#ifndef NO_TEMPLATES

template <class T>
class STTDbSlist : public STDbSlist
{
public:
	STDefineClassInfo
	STDeclareAssignClone(STTDbSlist<T>)

	STTDbSlist() {}
	STTDbSlist(const STTDbSlist<T> &s) : STDbSlist(s) {}
	void operator = (const STTDbSlist<T> &s) { STDbSlist::operator = (s); }

	virtual void        AddHead(STRoot *);      // add at head of list
	virtual void        AddTail(STRoot *);      // add at tail of list

	/*
#ifndef __DECCXX
	virtual T           GetHead();              // return and remove head of list
	virtual T           Remove(STRoot *);       // remove the element
	virtual T           Search(STRoot *) const; // search for Obj
#endif
	*/

	STDbError Select(STDbTransaction &, const STDbWhereLogical &, STSelectType = STSelectNoLock);
	STDbError Select(STDbTransaction &,                           STSelectType = STSelectNoLock);


	STDbError Load(STDbTransaction &,                                                       STSelectType = STSelectNoLock);
	STDbError Load(STDbTransaction &,                             const STDbWhereLogical &, STSelectType = STSelectNoLock);

	/* ereditate
	virtual void      Erase();
	virtual int       Check(STDbTransaction &) const;
	virtual STDbError Save(STDbTransaction &, SaveType = All) const;
	*/
};

template <class T>
class STTDbSlistIterator : public STDbSlistIterator
{
public:
	STTDbSlistIterator(const STTDbSlist<T> &s) : STDbSlistIterator(s) {}
	virtual T operator () ();
};

///////////////////////////////////////////////////////////////////////////////

template <class T>
int STTDbSlist<T>::STIsEqual(const STRoot *p) const
{
	return STDbSlist::STIsEqual(p);
}

template <class T>
STRoot * STTDbSlist<T>::STCreate() const
{
	return STNew STTDbSlist<T>;
}

template <class T>
STRoot * STTDbSlist<T>::STClone() const
{
	return STNew STTDbSlist<T>(*this);
}

template <class T>
void STTDbSlist<T>::STAssign(const STRoot *p)
{
	STTDbSlist<T> *ps = DynamicCast(STTDbSlist<T> *, p);
	if (ps == 0)
		STError("STTDbSlist<T>::STAssign() - invalid object");
}

template <class T>
void STTDbSlist<T>::AddHead(STRoot *p)
{
	if (DynamicCast(T, p) == 0)
		STError("STTDbSlist<T>::AddHead - invalid object");
	STSlist::AddHead(p);
}

template <class T>
void STTDbSlist<T>::AddTail(STRoot *p)
{
	if (DynamicCast(T, p) == 0)
		STError("STTDbSlist<T>::AddTail - invalid object");
	STSlist::AddTail(p);
}

/*
#ifndef __DECCXX
template <class T>
T STTDbSlist<T>::GetHead()
{
	STRoot *p = STSlist::GetHead();
	T t = DynamicCast(T, p);
	return t;
}

template <class T>
T STTDbSlist<T>::Remove(STRoot *t)
{
	STRoot *p = STSlist::Remove(t);
	return DynamicCast(T, p);
}

template <class T>
T STTDbSlist<T>::Search(STRoot *t) const
{
	STRoot *p = STSlist::Search(t);
	return DynamicCast(T, p);
}
#endif // __DECCXX
*/

template <class T>
STDbError STTDbSlist<T>::Select(STDbTransaction &tr, STSelectType st)
{
	return STDbBase::Select(tr, ((T)0)->CI.ClassName, *this, st);
}

template <class T>
STDbError STTDbSlist<T>::Select(STDbTransaction &tr, const STDbWhereLogical &w, STSelectType st)
{
	return STDbBase::Select(tr, ((T)0)->CI.ClassName, w, *this, st);
}

template <class T>
STDbError STTDbSlist<T>::Load(STDbTransaction &tr, const STDbWhereLogical &w, STSelectType st)
{
	return STDbSlist::Load(tr, ((T)0)->CI.ClassName, w, st);
}

template <class T>
STDbError STTDbSlist<T>::Load(STDbTransaction &tr, STSelectType st)
{
	return STDbSlist::Load(tr, ((T)0)->CI.ClassName, STDbWhereLogicalTrue, st);
}

///////////////////////////////////////////////////////////////////////////////

template <class T>
T STTDbSlistIterator<T>::operator() ()
{
	STDbBase *p = STDbSlistIterator::operator() ();
	return DynamicCast(T, p);
}

#else // NO_TEMPLATES

#define STTDbSlist(T) STTDbSlist##T
#define STTDbSlistIterator(T) STTDbSlistIterator##T

#define STTDbSlistdeclare(T)                                                                                                 \
class STTDbSlist(T) : public STDbSlist																						 \
{																															 \
public:																														 \
	STDefineClassInfo																										 \
	STDeclareAssignClone(STTDbSlist(T))																						 \
																															 \
	STTDbSlist(T)() {}																										 \
	STTDbSlist(T)(const STTDbSlist(T) &s) : STDbSlist(s) {}																	 \
	void operator = (const STTDbSlist(T) &s) { STDbSlist::operator = (s); }													 \
																															 \
	virtual void        AddHead(STRoot *);        														                     \
	virtual void        AddTail(STRoot *);      														                     \
																															 \
	STDbError Select(STDbTransaction &, const STDbWhereLogical &, STSelectType = STSelectNoLock);							 \
	STDbError Select(STDbTransaction &,                           STSelectType = STSelectNoLock);							 \
																															 \
																															 \
	STDbError Load(STDbTransaction &,                                                       STSelectType = STSelectNoLock);	 \
	STDbError Load(STDbTransaction &,                             const STDbWhereLogical &, STSelectType = STSelectNoLock);	 \
}
																															 
#define STTDbSlistIteratordeclare(T)																						 \
class STTDbSlistIterator(T) : public STDbSlistIterator																		 \
{																															 \
public:																														 \
	STTDbSlistIterator(T)(const STTDbSlist(T) &s) : STDbSlistIterator(s) {}													 \
	virtual T operator () ();																								 \
}
																															
///////////////////////////////////////////////////////////////////////////////

#define STTDbSlistimplement(T)                                                       \
int STTDbSlist(T)::STIsEqual(const STRoot *p) const						 			 \
{																		 			 \
	return STDbSlist::STIsEqual(p);										 			 \
}																		 			 \
																		 			 \
STRoot * STTDbSlist(T)::STCreate() const								 			 \
{																		 			 \
	return STNew STTDbSlist(T);											 			 \
}																		 			 \
																		 			 \
STRoot * STTDbSlist(T)::STClone() const									 			 \
{																		 			 \
	return STNew STTDbSlist(T)(*this);									 			 \
}																		 			 \
																		 			 \
void STTDbSlist(T)::STAssign(const STRoot *p)							 			 \
{																		 			 \
	STTDbSlist(T) *ps = DynamicCast(STTDbSlist(T) *, p);				 			 \
	if (ps == 0)																	 \
		STError("STTDbSlist<T>::STAssign() - invalid object"); \
}																					 \
																					 \
void STTDbSlist(T)::AddHead(STRoot *p)												 \
{																					 \
	if (DynamicCast(T, p) == 0)														 \
		STError("STTDbSlist<T>::AddHead - invalid object");			 \
	STSlist::AddHead(p);															 \
}																					 \
																					 \
void STTDbSlist(T)::AddTail(STRoot *p)												 \
{																					 \
	if (DynamicCast(T, p) == 0)														 \
		STError("STTDbSlist<T>::AddTail - invalid object");			 \
	STSlist::AddTail(p);															 \
}																					 \
																					 \
STDbError STTDbSlist(T)::Select(STDbTransaction &tr, STSelectType st)				 \
{																					 \
	return STDbBase::Select(tr, ((T)0)->CI.ClassName, *this, st);						 \
}																					 \
																					 \
STDbError STTDbSlist(T)::Select(STDbTransaction &tr, const STDbWhereLogical &w, STSelectType st) \
{																					 \
	return STDbBase::Select(tr, ((T)0)->CI.ClassName, w, *this, st);					 \
}																					 \
																					 \
STDbError STTDbSlist(T)::Load(STDbTransaction &tr, const STDbWhereLogical &w, STSelectType st) \
{																					 \
	return STDbSlist::Load(tr, ((T)0)->CI.ClassName, w, st);							 \
}																					 \
																					 \
STDbError STTDbSlist(T)::Load(STDbTransaction &tr, STSelectType st)					 \
{																					 \
	return STDbSlist::Load(tr, ((T)0)->CI.ClassName, STDbWhereLogicalTrue, st);		 \
}

#define STTDbSlistIteratorimplement(T)                                               \
T STTDbSlistIterator(T)::operator() ()												 \
{																					 \
	STDbBase *p = STDbSlistIterator::operator() ();									 \
	return DynamicCast(T, p);														 \
}																					 
																					 


#endif // NO_TEMPLATES                   

#endif
