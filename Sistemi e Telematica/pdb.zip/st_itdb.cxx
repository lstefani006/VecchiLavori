#include <st_dbnew.h>
#include <st_itdb.h>



#ifndef NO_TEMPLATES
STDbSelStmt::STDbSelStmt(STDbTransaction &tr, const char *pcStmt, STTVect<DbVal *> &outList)
#else
STDbSelStmt::STDbSelStmt(STDbTransaction &tr, const char *pcStmt, STTVect(P_DbVal) &outList)
#endif
	: m_outList(outList),
	  m_pStmt(NULL)
{
	m_pStmt = STNew STDbStmt(tr);

	m_e = m_pStmt->Parse(pcStmt);

	if (m_e == ST_DB_OK)
		m_e = m_pStmt->Exec();
}

STDbSelStmt::~STDbSelStmt()
{
	STDelete m_pStmt;
}

STDbError STDbSelStmt::operator ()()
{
	for (int i = 0; m_e == ST_DB_OK && i < m_outList.Size(); i++)
		m_e = m_pStmt->Bind(m_outList[i]);

	if (m_e == ST_DB_OK)
		m_e = m_pStmt->Fetch();

	return m_e;
}


