#ifndef __STStrutture_h__
#define __STStrutture_h__

#include <st_root.h>
#include <st_slist.h>
#include <st_dbdat.h>


//////////////////////////////////////////////////////////////////////////////
//                        CLASSE STChiave
//////////////////////////////////////////////////////////////////////////////

#ifdef NO_TEMPLATES
	typedef DbVal *P_DbVal;
	#ifndef D_STTSlistP_DbVal  
		#define D_STTSlistP_DbVal   
		declare(STTSlist, P_DbVal);
	#endif
	#ifndef D_STTSlistIteratorP_DbVal  
		#define D_STTSlistIteratorP_DbVal   
		declare(STTSlistIterator, P_DbVal);
	#endif
	#ifndef D_STTSlistP_STElemento
		#define D_STTSlistP_STElemento
		class STElemento;
		typedef STElemento *P_STElemento;
		declare(STTSlist, P_STElemento);
	#endif
	#ifndef D_STTSlistIteratorP_STElemento
		#define D_STTSlistIteratorP_STElemento
		class STElemento;
		typedef STElemento *P_STElemento;
		declare(STTSlistIterator, P_STElemento);
	#endif
	#ifndef D_STTVectSTDizWordKey
		#define D_STTVectSTDizWordKey
		declare(STTVect, STDizWordKey);
	#endif
	#ifndef D_STTVectRWCString
		#define D_STTVectRWCString
		declare(STTVect, RWCString);
	#endif
#endif

class STChiave : public virtual STRoot
{
public:

STDefineClassInfo
STDeclareAssignClone(STChiave)

	STChiave() {}
	STChiave(const STChiave &r);
	void operator = (const STChiave &r);
	~STChiave() {}

	void AddCampo(const DbVal *nuovoCampo);
	const DbVal* GetCampo(int idx) const;
	int NumCampi() const { return m_ListaCampi.nOfItems(); }

protected:

#ifndef NO_TEMPLATES
	STTSlist<DbVal *> m_ListaCampi;
#else 
	STTSlist(P_DbVal) m_ListaCampi;
#endif
};



//////////////////////////////////////////////////////////////////////////////
//                        CLASSE STElemento
//////////////////////////////////////////////////////////////////////////////
class STElemento : public virtual STRoot
{
   public:

      STDefineClassInfo
      STDeclareAssignClone(STElemento)

      STElemento();
      STElemento(const STElemento &r);
      STElemento(const STChiave& Chiave, const DbString *pDescrizione);
      void operator = (const STElemento &r);
      ~STElemento();

      STChiave GetChiave() const { return m_Chiave; } 
      const DbString* GetDescrizione() const { return m_pDescrizione; }

      static int SortCompare( const STRoot *elemento1,
                              const STRoot *elemento2 );

      static int RicercaChiaveEtCreaDescrizione( 
      #ifndef NO_TEMPLATES
                                     const STTSlist<STElemento*> &listaElementi,
      #else
                                     const STTSlist(P_STElemento) &listaElementi,
      #endif
                                     const STChiave &chiave,
                                     DbString* &descrizione); 

	 static int RicercaDescrizioneEtCreaChiave(
      #ifndef NO_TEMPLATES
                                     const STTSlist<STElemento*> &listaElementi,
      #else
                                     const STTSlist(P_STElemento) &listaElementi,
      #endif
			  const DbString* descrizione,
			   STChiave &chiave);


   protected:

      STChiave   m_Chiave;
      DbString *m_pDescrizione;
};

//////////////////////////////////////////////////////////////////////////////
//                        CLASSE STIndirizzo
//////////////////////////////////////////////////////////////////////////////
#define VIA_LEN 35
#define CAP_LEN 5
#define CITTA_LEN 35
#define PROV_LEN 2

class STIndirizzo : public virtual STRoot
{
   public:

      STDefineClassInfo
      STDeclareAssignClone(STIndirizzo)

      STIndirizzo();
      STIndirizzo(const STIndirizzo &r);
      void operator = (const STIndirizzo &r);
      ~STIndirizzo() {}

      void SetVia(const DbString& via) { m_Via = via; }
      void SetCAP(const DbString& cap) { m_CAP = cap; }
      void SetCitta(const DbString& citta) { m_Citta = citta; }
      void SetProvincia(const DbString& prov) { m_Provincia = prov; }

      DbString* GetVia() { return &m_Via; }
      DbString* GetCAP() { return &m_CAP; }
      DbString* GetCitta() { return &m_Citta; }
      DbString* GetProvincia() { return &m_Provincia; }

   protected:

      DbString m_Via;
      DbString m_CAP;
      DbString m_Citta;
      DbString m_Provincia;
};


//////////////////////////////////////////////////////////////////////////

class STWordKeyList : 
#ifndef NO_TEMPLATES
	public STTVect<WordKey>
#else
	public STTVect(STDizWordKey)
#endif
{
public:
	STWordKeyList();

	void InsertKey( WordKey theKey);
	void InsertKeyPosition( WordKey theKey, int thePosition);
	void InsertKeyHead( WordKey theKey) { InsertKeyPosition( theKey, 0); }

	WordKey GetKeyFromString(Dizionario *theDiz,RWCString theString) const;
	WordKey GetKeyFromString(Dizionario *theDiz,const char *p) const
	{
		return GetKeyFromString(theDiz,RWCString(p));
	}
};


/////////////////////////////////////////////////////////////////////////

class STFlagValues
{
public:

   STFlagValues();

   void operator = ( const STFlagValues &r);

   void InsertFlag( RWCString theDbFormat, WordKey theKeyFormat);

   RWCString GetDbFormat( WordKey theKeyFormat) const;
   WordKey   GetKeyFormat( RWCString theDbFormat) const; 

   // ritorna la stringa per l'utente corrispondente al codice 
   RWCString GetUsrValue(Dizionario *, const DbVal *pCdice);

   // partendo da cio` che vede l'utente ritorna il valore del DB
   RWCString GetDbValue(Dizionario *, const RWCString &);

   STWordKeyList GetFlagKeys(void) const;

protected:
#ifndef NO_TEMPLATES
   STTVect<RWCString> itsDbFormats;
   STTVect<WordKey>   itsKeyFormats;
#else
   STTVect(RWCString)     itsDbFormats;
   STTVect(STDizWordKey)  itsKeyFormats;
#endif
};



#endif  // __STStrutture_h__
