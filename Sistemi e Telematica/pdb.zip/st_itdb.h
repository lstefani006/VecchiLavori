#ifndef __ST_ITDB_H__
#define __ST_ITDB_H__

#include <st_dbxx.h>

class STDbSelStmt
{
public:

#ifndef NO_TEMPLATES
	STDbSelStmt(STDbTransaction &tr, const char *pcStmt, STTVect<DbVal *> &outList);
#else
	STDbSelStmt(STDbTransaction &tr, const char *pcStmt, STTVect(P_DbVal) &outList);
#endif

	~STDbSelStmt();

	STDbError operator ()();

	STDbError Error() const { return m_e; }

protected:
	STDbStmt *m_pStmt;

#ifndef NO_TEMPLATES
	STTVect<DbVal *> &m_outList;
#else
	STTVect(P_DbVal) &m_outList;
#endif

	STDbError m_e;
};


#endif
