#include <st_dbnew.h>
/*****************************************************************************

	Copyright (c) 1995

	File Name:       st_dbdat.cxx

****************************************************************************/

#include <stdio.h>
#include <iostream.h>
#include <strstream.h>
#include <ctype.h>

#include <rw/regexp.h>

#include "st_dbdat.h"
#include "st_cond.h"
#include "st_err.h"


#include "libdb_it.lnh"

#ifndef ST_NULLSTRING
	#define ST_NULLSTRING "?"
#endif // ST_NULLSTRING


////////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(DbVal,    STRoot)

STImplementClassInfo1(DbString, DbVal)
STImplementClassInfo1(DbInt,    DbVal)
STImplementClassInfo1(DbShort,  DbVal)
STImplementClassInfo1(DbChar,   DbVal)
STImplementClassInfo1(DbDouble, DbVal)
STImplementClassInfo1(DbTS,     DbVal)
STImplementClassInfo1(DbRaw,    DbVal)

STImplementAssignClone(DbString)
STImplementAssignClone(DbInt)
STImplementAssignClone(DbShort)
STImplementAssignClone(DbChar)
STImplementAssignClone(DbDouble)
STImplementAssignClone(DbTS)
STImplementAssignClone(DbRaw)

#define PDB_TOCHAR(x) StrToChar(G_Diz->GetWord(x))

////////////////////////////////////////////////////////////////////////////////

#ifdef DOS
STRoot * DbVal::STCreate()                  const { return NULL; }
STRoot * DbVal::STClone()                   const { return NULL; }
void     DbVal::STAssign(const STRoot *)          {}
int      DbVal::STCompareTo(const STRoot *) const { return 0; }
#endif

////////////////////////////////////////////////////////////////////////////////

DbVal::DbVal()
{
	m_bCanBeNull = 0;
	m_bNull = 0;
	m_pSTValidator = NULL;
}

DbVal::DbVal(DbVal::NullValues n)
{
	m_bCanBeNull = (n == Null);
	m_bNull = 0;
	m_pSTValidator = NULL;
}

DbVal::DbVal(const DbVal &r)
	: m_strMask(r.m_strMask)
{		
	if (!r.m_bCanBeNull && r.m_bNull)
		STError("DbVal::DbVal(const DbVal &r) :- r value inconsistent");

	m_bCanBeNull   = r.m_bCanBeNull;
	m_bNull        = r.m_bNull;
	m_pSTValidator = NULL;

	if (r.m_pSTValidator)
		m_pSTValidator = DynamicCast(STValidator *, r.m_pSTValidator->STClone());

}

DbVal::~DbVal()
{
	STDelete m_pSTValidator;
}

void DbVal::operator = (const DbVal &r)
{
	/*
	m_bCanBeNull = r.m_bCanBeNull;
	m_bNull      = r.m_bNull;
	*/
	if (!r.m_bCanBeNull && r.m_bNull)
		STError("DbVal::operator = (const DbVal &r) :- r value inconsistent");

	if (!m_bCanBeNull && r.m_bNull)
		STError("DbVal::operator = (const DbVal &r): assign this NOT NULL with NULL"); 

	m_bNull = r.m_bNull;
	
	/*
	la copia NON copia i validatori
	STDelete m_pSTValidator;
	m_pSTValidator = NULL;
	if (r.m_pSTValidator)
		m_pSTValidator = DynamicCast(STValidator *, r.m_pSTValidator->STClone());
	*/
}

int DbVal::STIsEqual(const STRoot *p) const
{
	DbVal *ps = DynamicCast(DbVal *, p);
	if (ps == NULL)
		return 0;
	return m_bNull == ps->m_bNull;
}

int DbVal::UsrMaxLength() const
{
	return DEFAULT_MAX_LENGTH;
}

void DbVal::SetValidator(STValidator *p)
{
	STDelete m_pSTValidator;
	m_pSTValidator = p;
}

void DbVal::ResetValidator()
{
	STDelete m_pSTValidator;
	m_pSTValidator = NULL;
}

STValidator * DbVal::GetValidator() const
{
	return m_pSTValidator;
}

void DbVal::SetNull(int bNull)
{
	if (!m_bCanBeNull && m_bNull)
		STError("DbVal::SetNull(int bNull) :- object NOT NULL inconsistent");

	if (CanBeNull())
		m_bNull = (bNull != 0);
	else
	if (bNull)
		STError("SetNull called with SET NOT NULL attribute");
}                   

int DbVal::IsNull() const
{
	if (!m_bCanBeNull && m_bNull)
		STError("DbVal::IsNull() :- object NOT NULL inconsistent");

	return m_bCanBeNull && m_bNull;
} 

void DbVal::Reset(DbVal::NullValues n)
{
	if (n == Null && !CanBeNull())
		STError("DbVal::Reset() :- Reset(Null) called with a NOT NULL field");
}


void DbVal::SetMask(const char *p)
{
	m_strMask = p;
}

const char * DbVal::GetMask() const
{
	return (const char *)m_strMask;
}


void DbVal::PostFetchNull(int bNull)
{
	m_bNull = bNull != 0;

	// se il campo e` NOT NULL e nel db e` stato tirato su un campo NULL
	if (!m_bCanBeNull && m_bNull)
	{
		m_bNull = 0;
		Reset(NotNull);
	}

	if (m_bNull)
		Reset(Null);
}

////////////////////////////////////////////////////////////////////////////////

void DbString::Reset(DbVal::NullValues n)
{
	DbVal::Reset(n);
	
	if (n == Null)
		m_p[0] = '\0';
	else
		*this = ST_NULLSTRING;
}

DbString::DbString()      /* costruttore necessario per RW */
	: DbVal(DbVal::Null), m_nMaxLen(1)
{
	m_p = STNew char [1];
	m_p[0] = '\0';
	SetNull(1);  // DbString::DbString() di lunghezza nulla
}

DbString::DbString(int nMaxLen, const char *pcStr)
	: DbVal(DbVal::Null), m_nMaxLen(nMaxLen)
{
	if (pcStr == NULL)
		pcStr = "";

	m_p = STNew char [nMaxLen + 1];

	int l = strlen(pcStr);
	for (int i = 0; i < m_nMaxLen; i++)
		m_p[i] = (i < l) ? pcStr[i] : '\0';
	m_p[i] = 0;
	
	SetNull(int(m_p[0] == '\0'));		// DbString::DbString(int n, const char *)
}

DbString::DbString(DbVal::NullValues n, int nMaxLen, const char *pcStr)
	: DbVal(n), m_nMaxLen(nMaxLen)
{
	if (pcStr == NULL)
	{
		if (n == NotNull)
			pcStr = ST_NULLSTRING;
		else
			pcStr = "";
	}
	
	if (n == NotNull && strlen(pcStr) == 0)
		STError("DbString::DbString() - NOT NULL string assigned with a NULL string");

	m_p = STNew char [nMaxLen + 1];

	int l = strlen(pcStr);
	for (int i = 0; i < m_nMaxLen; i++)
		m_p[i] = (i < l) ? pcStr[i] : '\0';
	m_p[i] = 0;
	
	SetNull(int(m_p[0] == '\0'));		// DbString::DbString(int n, const char *)
}

DbString::DbString(const DbString &r)
	: DbVal(r)
{
	m_nMaxLen = r.m_nMaxLen;

	m_p = STNew char [m_nMaxLen + 1];
	strcpy(m_p, r.m_p);
}

DbString::~DbString()
{
	STDelete [] m_p;
}

void DbString::operator = (const char *pcStr)
{
	ST_COND_APPL(pcStr, "DbString::DbString() - null pointer");
	
	int l = strlen(pcStr);
	for (int i = 0; i < m_nMaxLen; i++)
		m_p[i] = (i < l) ? pcStr[i] : '\0';
	m_p[i] = 0;
	
	SetNull(l == 0);
}

void DbString::operator = (const DbString &r)
{
	DbVal::operator = (r);
	DbString::operator = (r.data());
}

int DbString::IsNull() const
{
	((DbString *)this)->SetNull(strlen(m_p) == 0);
	return DbVal::IsNull();
}

void DbString::SetNull(int bNull)
{
	DbVal::SetNull(bNull);

	if (bNull)
		m_p[0] = '\0';
	else
	if (m_p[0] == '\0')
		operator = (ST_NULLSTRING);
}

int G_PDB_TOGLI_SPAZI_TESTA = 0;

STDizWordKey DbString::UsrValidate(RWCString &strToValidate) const
{
	static RWCRegexp re_old("[ \t]*");
	static RWCRegexp re_new("[ \t]*$");

	if (G_PDB_TOGLI_SPAZI_TESTA)
		strToValidate(re_old) = "";
	else
		strToValidate(re_new) = "";


	if (strToValidate == "" && !CanBeNull())
		return MSG_LIBDB_STRTOOSHORT;

	if ((int)strToValidate.length() > m_nMaxLen)
		return MSG_LIBDB_STRTOOLONG;

	if (m_pSTValidator)
		return m_pSTValidator->RunValidator(strToValidate);

	return MSG_LIBDB_NULL;
}

RWCString DbString::UsrPrint() const
{   
	if (IsNull())		// DbString::UsrPrint
		return RWCString("");
	else
	{
		if (RWCString(ST_NULLSTRING) == data())
			return RWCString("");
		else
			return RWCString(data());
	}
}


void DbString::UsrSet(const RWCString &strToSet)
{
	int l = strToSet.length();
	for (int i = 0; i < m_nMaxLen; i++)
		m_p[i] = (i < l) ? ((const char *)strToSet)[i] : '\0';
	m_p[i] = 0;

	KillLastBlanks();		// leo attenzione a tagliare i caratteri bianchi in fondo alla $

	if (CanBeNull())
		SetNull(int(m_p[0] == '\0'));   // DbString::UsrSet
	else
	if (m_p[0] == '\0')
		strcpy(m_p, ST_NULLSTRING);
}

int DbString::UsrMaxLength() const
{
	return m_nMaxLen;  
}

int DbString::STIsEqual(const STRoot *p) const
{
	DbString *ps = DynamicCast(DbString *, p);
	if (ps == 0) return	0;
	
	if (DbVal::STIsEqual(p) == 0)
		return 0;

	if (IsNull() && ps->IsNull())
		return 1;

//	return strcmp(m_p, ps->m_p) == 0;

	static RWCRegexp f(" +$");
	RWCString a = m_p;
	RWCString b = ps->m_p;

	a(f) = "";
	b(f) = "";

	return a == b;
}

int DbString::STCompareTo(const STRoot *p) const
{
	DbString *ps = DynamicCast(DbString *, p);
	if (ps == 0)
		return 1;
	return strcmp(m_p, ps->m_p);
}

void DbString::KillLastBlanks()
{
	int n = length();

	for (int i = n - 1; i >= 0; i--)
		if (m_p[i] == ' ')
			m_p[i] = 0;
		else
			break;
}

ostream & DbString::STDebug(ostream &s) const
{
	s << "DbString(" << (CanBeNull() ? "NULL" : "NOT NULL") << ", " << m_nMaxLen << ") = ";
	s << (IsNull() ? "NULL" : "NOT NULL") << " value \"" << m_p << "\"" << endl;
	return s;
}

int operator == (const DbString &a, const RWCString &c) { return strcmp(a, c) == 0; }
int operator != (const DbString &a, const RWCString &c) { return strcmp(a, c) != 0; }
int operator >  (const DbString &a, const RWCString &c) { return strcmp(a, c) >  0; }
int operator >= (const DbString &a, const RWCString &c) { return strcmp(a, c) >= 0; }
int operator <  (const DbString &a, const RWCString &c) { return strcmp(a, c) <  0; }
int operator <= (const DbString &a, const RWCString &c) { return strcmp(a, c) <= 0; }

int operator == (const DbString &a, const DbString &c) { return strcmp(a, c) == 0; }
int operator != (const DbString &a, const DbString &c) { return strcmp(a, c) != 0; }
int operator >  (const DbString &a, const DbString &c) { return strcmp(a, c) >  0; }
int operator >= (const DbString &a, const DbString &c) { return strcmp(a, c) >= 0; }
int operator <  (const DbString &a, const DbString &c) { return strcmp(a, c) <  0; }
int operator <= (const DbString &a, const DbString &c) { return strcmp(a, c) <= 0; }

int operator == (const DbString &a, const char *c) { return strcmp(a, c) == 0; }
int operator != (const DbString &a, const char *c) { return strcmp(a, c) != 0; }
int operator >  (const DbString &a, const char *c) { return strcmp(a, c) >  0; }
int operator >= (const DbString &a, const char *c) { return strcmp(a, c) >= 0; }
int operator <  (const DbString &a, const char *c) { return strcmp(a, c) <  0; }
int operator <= (const DbString &a, const char *c) { return strcmp(a, c) <= 0; }

///////////////////////////////////////////////////////////////////////////////

void DbInt::Reset(DbVal::NullValues n)
{
	DbVal::Reset(n);
	m_nValue = 0;
}


DbInt::DbInt()
	: DbVal(DbVal::NotNull),
	  m_nDigits(0),
	  m_nValue(0)
{
}

DbInt::DbInt(DbVal::NullValues n, int nOfDigits, Int32 nValue)
	: DbVal(n),
	  m_nDigits(nOfDigits),
	  m_nValue(nValue)
{              
	SetNull(0);		// DbInt::DbInt(int, Int32)
}

DbInt::DbInt(int nOfDigits, Int32 nValue)
	: DbVal(DbVal::NotNull),
	  m_nDigits(nOfDigits),
	  m_nValue(nValue)
{              
	SetNull(0);		// DbInt::DbInt(int, Int32)
}

DbInt::DbInt(const DbInt &d)
	: DbVal(d),
	  m_nDigits(d.m_nDigits),
	  m_nValue(d.m_nValue)
{
}


void DbInt::operator = (Int32 n)
{
	m_nValue = n;
	SetNull(0);  // DbInt::operator(int32)
}

void DbInt::operator = (const DbInt &r)
{
	DbVal::operator = (r);

	m_nValue  = r.m_nValue;
	m_nDigits = r.m_nDigits;
}

STDizWordKey DbInt::UsrValidate(RWCString &strToValidate) const
{
	const char *p = strToValidate;

	while (*p == ' ' || *p == '\t')
		p++;
		
	strToValidate = RWCString(p);
	p = strToValidate;

	if (*p == 0 && !CanBeNull())
		return MSG_LIBDB_INTNOTVALID;
	
	if (*p)
	{
		const char *pcStartNum;
		const char *pcEndNum;

		pcStartNum = p;
		if (*p == '+' || *p == '-')
			p++;
		if (*p < '0' || *p > '9')
			return MSG_LIBDB_INTNOTVALID;
		while (*p >= '0' && *p <= '9')
			p++;
		pcEndNum = p;
		while (*p == ' ' || *p == '\t')
			p++;
		if (*p)
			return MSG_LIBDB_INTNOTVALID;

		if (pcEndNum - pcStartNum > m_nDigits)
			return MSG_LIBDB_INTNOTVALID;
	}

	if (m_pSTValidator)
		return m_pSTValidator->RunValidator(strToValidate);

	return MSG_LIBDB_NULL;
}


RWCString DbInt::UsrPrint() const
{   
	char b[20];
	if (IsNull())		// DbInt::UsrPrint()
		b[0] = 0;
	else
	{
		ostrstream s(b, sizeof(b));
		s << m_nValue << ends;
	}
	return RWCString(b);
}


void DbInt::UsrSet(const RWCString &strToSet)
{
	RWPRECONDITION(UsrValidate(strToSet).isError() == FALSE);
             
    m_nValue = 0;
    if (strToSet != "")
    {
		/*
		istrstream s((char *)strToSet.data());
		s >> m_nValue;
		*/

		int nnn;
		sscanf(strToSet, "%d", &nnn);
		m_nValue = nnn;

		SetNull(0);		// DbInt::UsrSet()
	}              
	else
		SetNull(1);		// DbInt::UsrSet()
}

int DbInt::UsrMaxLength() const
{
	return m_nDigits;
}

int DbInt::STIsEqual(const STRoot *p) const
{
	DbInt *ps = DynamicCast(DbInt *, p);
	if (ps == 0)
		return 0;              
	if (DbVal::STIsEqual(p) == 0) // DbInt::STIsEqual
		return 0;
		
	if (IsNull() && ps->IsNull())
		return 1;

	return m_nValue == ps->m_nValue;
}


int DbInt::STCompareTo(const STRoot *p) const
{
	DbInt *ps = DynamicCast(DbInt *, p);
	if (ps == 0)
		return 1;
	if (m_nValue == ps->m_nValue) return 0;
	if (m_nValue >  ps->m_nValue) return 1;
	return -1;
}

ostream & DbInt::STDebug(ostream &s) const
{
	s << "DbInt(" << (CanBeNull() ? "NULL" : "NOT NULL") << ", " << m_nDigits << ") = ";
	s << (IsNull() ? "NULL" : "NOT NULL") << " value \"" << m_nValue << "\"" << endl;
	return s;
}

///////////////////////////////////////////////////////////////////////////////

void DbShort::Reset(DbVal::NullValues n)
{
	DbVal::Reset(n);
	m_nValue = 0;
}


DbShort::DbShort()
	: DbVal(DbVal::NotNull),
	  m_nDigits(0),
	  m_nValue(0)
{
}

DbShort::DbShort(DbVal::NullValues n, int nOfDigits, Int16 nValue)
	: DbVal(n),
	  m_nDigits(nOfDigits),
	  m_nValue(nValue)
{                                        
	SetNull(0);		// DbShort(int nOfDigits, Int16 nValue)
}

DbShort::DbShort(int nOfDigits, Int16 nValue)
	: DbVal(DbVal::NotNull),
	  m_nDigits(nOfDigits),
	  m_nValue(nValue)
{                                        
	SetNull(0);		// DbShort(int nOfDigits, Int16 nValue)
}

DbShort::DbShort(const DbShort &d)
	: DbVal(d),
	  m_nDigits(d.m_nDigits),
	  m_nValue(d.m_nValue)
{
}


void DbShort::operator = (Int16 n)
{
	m_nValue = n;
	SetNull(0);		// DbShort::operator(Int16)
}

void DbShort::operator = (const DbShort & r)
{
	DbVal::operator = (r);

	m_nValue  = r.m_nValue;
	m_nDigits = r.m_nDigits;
}

STDizWordKey DbShort::UsrValidate(RWCString &strToValidate) const
{
	const char *p = strToValidate;

	while (*p == ' ' || *p == '\t') p++;
	
	strToValidate = RWCString(p);
	p = strToValidate;

	if (*p == 0 && !CanBeNull())
		return MSG_LIBDB_INTNOTVALID;
	
	if (*p)
	{
		const char *pcStartNum;
		const char *pcEndNum;

		pcStartNum = p;
		if (*p == '+' || *p == '-') p++;
		if (*p < '0' || *p > '9') return MSG_LIBDB_INTNOTVALID;
		while (*p >= '0' && *p <= '9') p++;
		pcEndNum = p;
		while (*p == ' ') p++;
		if (*p)
			return MSG_LIBDB_INTNOTVALID;

		if (pcEndNum - pcStartNum > m_nDigits)
			return MSG_LIBDB_INTNOTVALID;
	}

	if (m_pSTValidator)
		return m_pSTValidator->RunValidator(strToValidate);

	return MSG_LIBDB_NULL;
}


RWCString DbShort::UsrPrint() const
{
	char b[20];
	if (IsNull())		// DbShort::UsrPrint
		b[0] = 0;
	else
	{
		ostrstream s(b, sizeof(b));
		s << m_nValue << ends;
	}
	return RWCString(b);
}


void DbShort::UsrSet(const RWCString &strToSet)
{
	RWPRECONDITION(UsrValidate(strToSet).isError() == FALSE);
        
    m_nValue = 0;
	if (strToSet != "")
	{
		istrstream s((char *)strToSet.data());
		s >> m_nValue;
		SetNull(0);		// DbShort::UsrSet();
	}
	else
		SetNull(1);			// DbShort::UsrSet()
}

int DbShort::UsrMaxLength() const
{
	return m_nDigits;
}

int DbShort::STIsEqual(const STRoot *p) const
{
	DbShort *ps = DynamicCast(DbShort *, p);
	if (ps == 0) return 0;
	if (DbVal::STIsEqual(p) == 0)		// DbShort::STIsEqual()
		return 0;
	
	if (IsNull() && ps->IsNull())
		return 1;

	return m_nValue == ps->m_nValue;
}

int DbShort::STCompareTo(const STRoot *p) const
{
	DbShort *ps = DynamicCast(DbShort *, p);
	if (ps == 0) return 1;
	if (m_nValue == ps->m_nValue) return 0;
	if (m_nValue >  ps->m_nValue) return 1;
	return -1;
}

ostream & DbShort::STDebug(ostream &s) const
{
	s << "DbShort(" << (CanBeNull() ? "NULL" : "NOT NULL") << ", " << m_nDigits << ") = ";
	s << (IsNull() ? "NULL" : "NOT NULL") << " value \"" << m_nValue << "\"" << endl;
	return s;
}
///////////////////////////////////////////////////////////////////////////////

void DbChar::Reset(DbVal::NullValues n)
{
	DbVal::Reset(n);
	m_cValue[0] = '\0';
}

DbChar::DbChar(char cValue)
	: DbVal(DbVal::Null)
{
	m_cValue[0] = cValue;
	m_cValue[1] = 0;
	SetNull(0);     	// DbChar::DbChar(char)
}

DbChar::DbChar(DbVal::NullValues n, char cValue)
	: DbVal(n)
{
	m_cValue[0] = cValue;
	m_cValue[1] = 0;
	SetNull(0);     	// DbChar::DbChar(char)
}

DbChar::DbChar(const DbChar &r)
	: DbVal(r)
{
	m_cValue[0] = r.m_cValue[0];
	m_cValue[1] = 0;
}

void DbChar::operator = (const DbChar &r)
{
	DbVal::operator = (r);
	m_cValue[0] = r.m_cValue[0];
}

void DbChar::operator = (char c)
{
	m_cValue[0] = c;
	SetNull(0);		// DbChar::operator = (char)
}

STDizWordKey DbChar::UsrValidate(RWCString &strToValidate) const
{
	if (strToValidate.length() > 1)
		return MSG_LIBDB_CHARNOTVALID;

	if (strToValidate == "" && !CanBeNull())
		return MSG_LIBDB_CHARNOTVALID;

	if (m_pSTValidator)
		return m_pSTValidator->RunValidator(strToValidate);

	return MSG_LIBDB_NULL;
}


RWCString DbChar::UsrPrint() const
{
	char b[2];
	if (IsNull())			// DbChar::UsrPrint
		b[0] = 0;
	else
	{
		ostrstream s(b, sizeof(b));
		s << m_cValue[0] << ends;
	}
	return RWCString(b);
}


void DbChar::UsrSet(const RWCString &strToSet)
{
	RWPRECONDITION(UsrValidate(strToSet).isError() == FALSE);
             
    m_cValue[0] = 0;
    m_cValue[1] = 0;

    if (strToSet != "")
    {
		// milleri 12/7/1996
		// istrstream s((char *)strToSet.data());
		// s >> m_cValue[0];

		const char *c = strToSet.data();
		m_cValue[0] = c[0];
		
		SetNull(0);		// DbChar::UsrSet()
	}
	else
		SetNull(1);			// DbChar::UsrSet()
}

int DbChar::STIsEqual(const STRoot *p) const
{
	DbChar *ps = DynamicCast(DbChar *, p);
	if (ps == 0) return 0;

	if (IsNull() || ps->IsNull())
	{
		if (m_cValue[0] == '\0' && ps->m_cValue[0] == '\0')
			return 1;
	}
	
	if (DbVal::STIsEqual(p) == 0)		// DbChar::STIsEqual()
		return 0;
	
	if (IsNull() && ps->IsNull())
		return 1;

	return m_cValue[0] == ps->m_cValue[0];
}

int DbChar::STCompareTo(const STRoot *p) const
{
	DbChar *ps = DynamicCast(DbChar *, p);
	if (ps == 0) return 1;
	if (m_cValue[0] == ps->m_cValue[0]) return 0;
	if (m_cValue[0] >  ps->m_cValue[0]) return 1;
	return -1;
}

int DbChar::UsrMaxLength() const
{
	return 1;
}

ostream & DbChar::STDebug(ostream &s) const
{
	s << "DbChar(" << (CanBeNull() ? "NULL" : "NOT NULL") << ") = ";
	s << (IsNull() ? "NULL" : "NOT NULL") << " value \"" << m_cValue[0] << "\"" << endl;
	return s;
}

///////////////////////////////////////////////////////////////////////////////

static int isValidDouble(RWCString &theStr, int *pNumCifreDec);
static int isValidMask(RWCString &theStr, int *pNumCifreDec, int *bPunto, int *bDecimal);
static char StrToChar(RWCString str);

void DbDouble::Reset(DbVal::NullValues n)
{
	DbVal::Reset(n);
	m_dValue = 0.0;
}

DbDouble::DbDouble()
	: DbVal(DbVal::NotNull),
	  m_dValue(0.0),
	  m_nSize1(0),
	  m_nSize2(0)
{
	SetNull(0);		// DbDouble::DbDouble()
}

DbDouble::DbDouble(int sz1, int sz2, double dValue)
	: DbVal(DbVal::NotNull),
	  m_dValue(dValue),
	  m_nSize1(sz1),
	  m_nSize2(sz2)
{     
	SetNull(0);		// DbDouble::DbDouble(int,....)
}

DbDouble::DbDouble(DbVal::NullValues n, int sz1, int sz2, double dValue)
	: DbVal(n),
	  m_dValue(dValue),
	  m_nSize1(sz1),
	  m_nSize2(sz2)
{     
	SetNull(0);		// DbDouble::DbDouble(int,....)
}

DbDouble::DbDouble(const DbDouble &d)
	 : DbVal(d),
	   m_dValue(d.m_dValue),
	   m_nSize1(d.m_nSize1),
	   m_nSize2(d.m_nSize2)
{
}

void DbDouble::operator = (const DbDouble &r)
{
	DbVal::operator = (r);

	m_dValue = r.m_dValue;
	m_nSize1 = r.m_nSize1;
	m_nSize2 = r.m_nSize2;
}

void DbDouble::operator = (double d)
{
	m_dValue = d;
	SetNull(0);		// DbDouble::operator(double)
}

STDizWordKey DbDouble::UsrValidate(RWCString &strToValidate) const
{
	const char *pc = strToValidate;

	while (*pc == ' ' || *pc == '\t')
		pc++;             
		
	strToValidate = RWCString(pc);
	pc = strToValidate;

	if (*pc == 0 && !CanBeNull())
		return MSG_LIBDB_REALNOTVALID;

	if (*pc)
	{
		if (*pc == '-' || *pc == '+')
			pc++;

		RWCString theStr(pc);
		int dummy;
		if (!isValidDouble(theStr, &dummy))
			return MSG_LIBDB_REALNOTVALID;

		int bSinPunto = 0;
		int bDesPunto = 0;

		while (isdigit(*pc) || *pc == PDB_TOCHAR(STR_LIBDB_DOUBLE_PUNTO))
		{
			if (*pc != PDB_TOCHAR(STR_LIBDB_DOUBLE_PUNTO))
				bSinPunto += 1;
			pc++;
		}
	
		if (*pc == PDB_TOCHAR(STR_LIBDB_DOUBLE_VIRGOLA))
		{
			pc++;
			while (isdigit(*pc))
			{
				bDesPunto += 1;
				pc++;
			}
		}

		if (bSinPunto == 0 && bDesPunto == 0)
			return MSG_LIBDB_REALNOTVALID;

		if (bDesPunto + bSinPunto > m_nSize1)
			return MSG_LIBDB_REALNOTVALID;
	
		// cifre dopo la virgola 
		if (bDesPunto > m_nSize2)
			return MSG_LIBDB_REALNOTVALID;

		// cifre prima della virgola (GM) 
		if (bSinPunto > m_nSize1 - m_nSize2)
			return MSG_LIBDB_REALNOTVALID;

		while (*pc == ' ' || *pc == '\t')
			pc++;

		if (*pc != 0)
			return MSG_LIBDB_REALNOTVALID;
	}

	if (m_pSTValidator)
		return m_pSTValidator->RunValidator(strToValidate);

	return MSG_LIBDB_NULL;
}


RWCString DbDouble::UsrPrint() const
{
	if (GetMask() == RWCString(""))
	{
		char b[20];
		RWCString str;

		if (IsNull())
		{
			b[0] = 0;
			str = b;
		}
		else
		{
			if (m_nSize2 == 0 || m_dValue == int(m_dValue))
			{
				sprintf(b, "%f", m_dValue);
				str = b;
				int pos = str.index(".");
				if (pos != RW_NPOS)
					str.remove(pos);
			}
			else
			{
				sprintf(b, "%.*f", m_nSize2, m_dValue);
				str = b;
			}
		}

		int pos = str.index(".");	// Ci vuole il valore cablato "."
		if (pos != RW_NPOS)
			str(pos) = PDB_TOCHAR(STR_LIBDB_DOUBLE_VIRGOLA);

		return str;
	}
	else
	{
		const char *p = GetMask();
		RWCString theMask(p);
		int NumCifreDec;
		int bPunto;
		int bDecimal;
		if (!isValidMask(theMask, &NumCifreDec, &bPunto, &bDecimal))
			STError("Mask del DbDouble non correttamente formattata");
		
		if (NumCifreDec > m_nSize2)
			NumCifreDec = m_nSize2;

		int pos;
		char b[30];
		RWCString DoubleFormat;
		if (!bDecimal && (NumCifreDec == 0 || m_dValue == int(m_dValue))) 
		{
			sprintf(b, "%f", m_dValue);
			DoubleFormat = b;
			pos = DoubleFormat.index("."); // Ci vuole il valore cablato "."
			if (pos != RW_NPOS)
				DoubleFormat.remove(pos);
		}
		else
		{
			sprintf(b, "%.*f", NumCifreDec, m_dValue);
			DoubleFormat = b;
		}

		pos = DoubleFormat.index(".");	// Ci vuole il valore cablato "."
		if (pos == RW_NPOS || NumCifreDec == 0)
			pos = DoubleFormat.length();
		else 
			DoubleFormat(pos) = PDB_TOCHAR(STR_LIBDB_DOUBLE_VIRGOLA);

		if (bPunto)
		{
			int first_digit_pos = 0;
			if (DoubleFormat(0) == '-' || DoubleFormat(0) == '+')
				first_digit_pos = 1;
			for (pos -= 3; pos > first_digit_pos; pos -= 3)
				DoubleFormat.insert(pos, PDB_TOCHAR(STR_LIBDB_DOUBLE_PUNTO));
		}

		return DoubleFormat;
	}
}


void DbDouble::UsrSet(const RWCString &strToSet)
{
	RWPRECONDITION(UsrValidate(strToSet).isError() == FALSE);

	RWCString str = strToSet;
	STDizWordKey w = UsrValidate(str);
	if (w != MSG_LIBDB_NULL)
		cerr << "DbDouble::UsrSet:	Stringa in formato errato" << endl;

	m_dValue = 0;
	
	if (strToSet != "")
	{
		RWCString str = strToSet;
		for (int i = 0; i < (int)str.length(); i++)
		{
			if (str(i) == PDB_TOCHAR(STR_LIBDB_DOUBLE_PUNTO))
				str.remove(i, 1);
			else if (str(i) == PDB_TOCHAR(STR_LIBDB_DOUBLE_VIRGOLA))
				((char *)str.data())[i] = '.';		// Ci vuole il valore cablato "."
		}

		istrstream s((char *)str.data());
		s >> m_dValue;
		SetNull(0);	// DbDouble::UsrSet()
	}
	else
		SetNull(1);		// DbDouble::UsrSet()
}

int DbDouble::UsrMaxLength() const
{
	// numero cifre intere + num. cifre dec. + punto + separatori migliaia
	int cifre_intere = m_nSize1 - m_nSize2;
	int num_separatori = (cifre_intere -1) / 3;
	return m_nSize1 + num_separatori + 1;
/*
	// numero cifre intere + num. cifre decimali + un punto
	return m_nSize1 + 1;
*/
}

int DbDouble::STIsEqual(const STRoot *p) const
{
	DbDouble *ps = DynamicCast(DbDouble *, p);
	if (ps == 0)
		return 0;
	if (DbVal::STIsEqual(p) == 0)		// DbDouble::STIsEqual()
		return 0;
	
	if (IsNull() && ps->IsNull())
		return 1;

	return m_dValue == ps->m_dValue;
}

int DbDouble::STCompareTo(const STRoot *p) const
{
	DbDouble *ps = DynamicCast(DbDouble *, p);
	if (ps == 0) return 1;
	if (m_dValue == ps->m_dValue) return 0;
	if (m_dValue >  ps->m_dValue) return 1;
	return -1;
}

ostream & DbDouble::STDebug(ostream &s) const
{
	s << "DbDouble(" << (CanBeNull() ? "NULL" : "NOT NULL") << ", " << m_nSize1 << ", " << m_nSize2 << ") = ";
	s << (IsNull() ? "NULL" : "NOT NULL") << " value \"" << m_dValue << "\"" << endl;
	return s;
}

static char StrToChar(RWCString str)
{
	return ((char *)str.data())[0];
}

static int isValidDouble(RWCString &theStr, int *pCifreDec)
{
	for (int i = 0; i < (int)theStr.length(); i++)
	{
		if (theStr(i) != PDB_TOCHAR(STR_LIBDB_DOUBLE_PUNTO) && 
						theStr(i) != PDB_TOCHAR(STR_LIBDB_DOUBLE_VIRGOLA) && 
						!isdigit(theStr(i)))
			return 0;
	}
			
	int bVirgola = 1;
	int bPunto = 1;
	*pCifreDec = 0;

	int pos = theStr.index(G_Diz->GetWord(STR_LIBDB_DOUBLE_VIRGOLA));
	if (pos == RW_NPOS)
		bVirgola = 0;
	else 	// verifico che non vi sia piu' di una virgola
	{ 
		int new_pos = theStr.index(G_Diz->GetWord(STR_LIBDB_DOUBLE_VIRGOLA), pos + 1);
		if (new_pos != RW_NPOS)
			return 0;
	}

	pos = theStr.index(G_Diz->GetWord(STR_LIBDB_DOUBLE_PUNTO));
	if (pos == RW_NPOS)
		bPunto = 0;

	if (bPunto)
	{
		if (pos == 0 || pos > 3) // errore se non ho cifre prima del punto, oppure piu' di tre
			return 0;

		int new_pos;
		while (pos != RW_NPOS) 
		{
			new_pos = theStr.index(G_Diz->GetWord(STR_LIBDB_DOUBLE_PUNTO), pos + 1);

			if (new_pos == RW_NPOS)
				break;

			if (new_pos - pos != 4) // controllo la distanza tra i punti (deve essere 4)
				return 0;

			pos = new_pos;
		}
		if (bVirgola)
		{
			// devo controllare la distanza tra l'ultimo punto e la virgola
			new_pos = theStr.index(G_Diz->GetWord(STR_LIBDB_DOUBLE_VIRGOLA));
			if (new_pos - pos != 4)
					return 0;
		}
		else	// se non c'� la virgola, , ci devono essere 3 cifre dopo l'ultimo punto
		{
			if (theStr.length() - pos - 1 != 3)
				return 0;
		}
	}
	if (bVirgola)
	{
		pos = theStr.index(G_Diz->GetWord(STR_LIBDB_DOUBLE_VIRGOLA));
		*pCifreDec = theStr.length() - pos - 1;
	}
	return 1;
}


static int isValidMask(RWCString &theStr, int *pCifreDec, int *bPunto, int *bDecimal)
{
	for (int i = 0; i < (int)theStr.length(); i++)
	{
		if (theStr(i) != 'P' && theStr(i) != 'V' && !isdigit(theStr(i)))
		{
			if (theStr(i) != 'Z')
				return 0;
		}
	}
			
	int bVirgola = 1;
	*bPunto = 1;
	*pCifreDec = 0;

	int pos = theStr.index("V");
	if (pos == RW_NPOS)
		bVirgola = 0;
	else 	// verifico che non vi sia piu' di una virgola
	{ 
		int new_pos = theStr.index("V", pos + 1);
		if (new_pos != RW_NPOS)
			return 0;
	}

	pos = theStr.index("P");
	if (pos == RW_NPOS)
		*bPunto = 0;

	if (*bPunto)
	{
		if (pos == 0 || pos > 3) // errore se non ho cifre prima del punto, oppure piu' di tre
			return 0;

		int new_pos;
		while (pos != RW_NPOS) 
		{
			new_pos = theStr.index("P", pos + 1);

			if (new_pos == RW_NPOS)
				break;

			if (new_pos - pos != 4) // controllo la distanza tra i punti (deve essere 4)
				return 0;

			pos = new_pos;
		}
		if (bVirgola)
		{
			// devo controllare la distanza tra l'ultimo punto e la virgola
			new_pos = theStr.index("V");
			if (new_pos - pos != 4)
					return 0;
		}
		else	// se non c'� la virgola, , ci devono essere 3 cifre dopo l'ultimo punto
		{
			if (theStr.length() - pos - 1 != 3)
				return 0;
		}
	}
	if (bVirgola)
	{
		pos = theStr.index("V");
		*pCifreDec = theStr.length() - pos - 1;
		*bDecimal = 0;
		if (theStr(pos +1) == 'Z')
			*bDecimal = 1;
	}
	return 1;
}


///////////////////////////////////////////////////////////////////////////////

struct DataTS
{
	int YYYY;
	int MM;
	int DD;
	int hh;
	int mm;
	int ss;

	// modifica del 13/07/1996 di P.M.
 	RWCString MON;
	int	NNN;
	char A;
	// fine modifica
};

static RWCString PrintTS(const char *pcFmt, const DataTS *pDataTS);
static int GetTS(const char *pcStr, const char *pcFmt, DataTS *pDataTS);


DbTS NullDate(DbVal::Null);

static char DefaultMask[] = "%d/%m/%y";


void DbTS::Reset(DbVal::NullValues n)
{
	DbVal::Reset(n);

	if (n == Null)
		*this = NullDate;
	else
		*this = RWDate(1, 1, 1901);
}


void DbTS::SetNull(int bNull)
{
	DbVal::SetNull(bNull);

	if (bNull)
		*this = NullDate;
}


DbTS::DbTS()
	: DbVal(DbVal::Null),
	  RWTime(RWDate(1, 1, 1901))
{   
	SetMask(DefaultMask);
	SetNull(1);			// DbTS::DbTS()
}

DbTS::DbTS(DbVal::NullValues n)
	: DbVal(n),
	  RWTime(RWDate(1, 1, 1901))
{   
	SetMask(DefaultMask);
	SetNull(n == Null);
}

DbTS::DbTS(const RWTime &r)
	: DbVal(DbVal::Null),
	  RWTime(r)
{
	SetMask(DefaultMask);
	SetNull(0);
}

DbTS::DbTS(int Y, int M, int D, int h, int m, int s)
	: DbVal(DbVal::Null),
	  RWTime(RWDate(D, M, Y), h, m ,s)
{
	SetMask(DefaultMask);
	SetNull(0);				// DbTS::DbTS(int Y,....)
}

DbTS::DbTS(unsigned long seconds)
	: DbVal(DbVal::Null),
	  RWTime(seconds)
{   
	SetMask(DefaultMask);
	SetNull(0);				// DbTS::DbTS(unsigned long seconds)
}

DbTS::DbTS(unsigned hour, unsigned minute, unsigned seconds,
				   const RWZone& zone)
	: DbVal(DbVal::Null),
	  RWTime(hour, minute, seconds, zone)
{
	SetMask(DefaultMask);
	SetNull(0);				// DbTS::DbTS(unsigned hour,....)
}

DbTS::DbTS(const RWDate &dt,
				   unsigned hour, unsigned minute, unsigned seconds,
				   const RWZone& zone)
	: DbVal(DbVal::Null),
	  RWTime(dt, hour, minute, seconds, zone)
{
	SetMask(DefaultMask);
	SetNull(0);				// DbTS::DbTS(const RWDate &, unsigned hour,....)
}

DbTS::DbTS(const RWDate &dt, const RWCString& strTime,
				   const RWZone& zone,
				   const RWLocale& locale)
	: DbVal(DbVal::Null),
	  RWTime(dt, strTime, zone, locale)
{
	SetMask(DefaultMask);
	SetNull(0);				// DbTS::DbTS(const RWDate &,....)
}

DbTS::DbTS(const struct tm *t, const RWZone &zone)
	: DbVal(DbVal::Null),
	  RWTime(t, zone)
{
	SetMask(DefaultMask);
	SetNull(0);				// DbTS::DbTS(const struct tm*,....)
}

DbTS::DbTS(const DbTS &t)
	: DbVal(t),
	  RWTime(t)
{
}

void DbTS::operator = (const DbTS &dt)
{
	DbVal::operator = (dt);
	RWTime::operator = (dt);
}

void DbTS::operator = (const RWTime &dt)
{
	RWTime::operator = (dt);
	SetNull(0);			// DbTS::operator = (const RWTime &)
}

STDizWordKey DbTS::UsrValidate(RWCString &strToValidate) const
{
	const char *p = strToValidate;
	while (*p == ' ' || *p == '\t')
		p++;
	strToValidate = RWCString(p);
	p = strToValidate;
	
	if (strToValidate == "" && !CanBeNull())
		return MSG_LIBDB_DATETIMENOTVALID;

	if (strToValidate == "")
	{
		if (m_pSTValidator)
			return m_pSTValidator->RunValidator(strToValidate);
		else
			return MSG_LIBDB_NULL;
	}
	
	DataTS ts;

	if (GetTS(strToValidate, GetMask(), &ts) == 0)
		return MSG_LIBDB_DATETIMENOTVALID;

	DbTS a;
	a.SetMask(GetMask());
	a.UsrSet(strToValidate);
	strToValidate = a.UsrPrint();

	if (m_pSTValidator)
		return m_pSTValidator->RunValidator(strToValidate);

	return MSG_LIBDB_NULL;
}


RWCString DbTS::UsrPrint() const
{
	if (IsNull())
		return RWCString("");

	/* LEO 1/4/1996 la data nulla non e` piu` 1-1-1901
	if (RWDate(*this) == RWDate(1, 1, 1901))
		return RWCString("");
	*/


	RWDate d(*this);
	RWCString s(asString('S'));
	int sec;
	sscanf(s, "%d", &sec);

	DataTS ts;
	ts.YYYY = d.year();
	ts.MM   = d.month();
	ts.DD   = d.dayOfMonth();
	ts.hh   = hour();
	ts.mm   = minute();
	ts.ss   = sec;

	// modifica del 13/7/96 di P.M.
 	ts.MON = d.nameOfMonth(d.month());
 	ts.NNN = d.day();
 	ts.A = isDST(RWZone::local());
	// fine modifica

	if (ts.YYYY == 1901 &&
	    ts.MM   ==    1 &&
	    ts.DD   ==    1 &&
		ts.hh   ==    0 &&
		ts.mm   ==    0 &&
		ts.ss   ==    0)
		return RWCString("");

	return PrintTS(GetMask(), &ts);
}


void DbTS::UsrSet(const RWCString &strToSet)
{
	if (strToSet == "")
	{
		*this = NullDate;
		SetNull(1);		// DbTS::UsrSet()
		return;
	}

	DataTS ts;

	int r = GetTS(strToSet, GetMask(), &ts);
	RWPRECONDITION(r == 1);

	/* uso RWTime e non DbTS per non perdere il validatore associato a this */
	RWTime aa(RWDate(ts.DD, ts.MM, ts.YYYY), ts.hh, ts.mm ,ts.ss);

	*this = aa;
	SetNull(0);			// DbTS::UsrSet()
}

int DbTS::STIsEqual(const STRoot *p) const
{
	DbTS *ps = DynamicCast(DbTS *, p);
	if (ps == 0)
		return 0;
	if (DbVal::STIsEqual(p) == 0)
		return 0;
	
	if (IsNull() && ps->IsNull())
		return 1;

	return *this == *ps;
}

int DbTS::STCompareTo(const STRoot *p) const
{
	DbTS *ps = DynamicCast(DbTS *, p);
	if (ps == 0) return 1;
	if (*this == *ps) return 0;
	if (*this >  *ps) return 1;
	return -1;
}

ostream & DbTS::STDebug(ostream &s) const
{
	s << "DbTS(" << (CanBeNull() ? "NULL" : "NOT NULL") << ") = ";
	s << (IsNull() ? "NULL" : "NOT NULL") << " value \"" << UsrPrint() << "\"" << endl;
	return s;
}

///////////////////////////////////////////////////////////////////////////////

void DbRaw::Reset(DbVal::NullValues n)
{
	DbVal::Reset(n);

	if (m_pBuff)
		memset(m_pBuff, 0, m_nSize);
}


DbRaw::DbRaw()
	: DbVal(DbVal::Null)
{
	m_nSize = 0;
	m_pBuff = NULL;
	SetNull(1);		//DbRaw::DbRaw()
}

DbRaw::DbRaw(int sz)
	: DbVal(DbVal::NotNull)
{
	m_nSize = sz;
	m_pBuff = STNew unsigned char [m_nSize];
	memset(m_pBuff, 0, m_nSize);
	
	SetNull(0);		// DbRaw::DbRaw(int)
}

DbRaw::DbRaw(DbVal::NullValues n, int sz)
	: DbVal(n)
{
	m_nSize = sz;
	m_pBuff = STNew unsigned char [m_nSize];
	memset(m_pBuff, 0, m_nSize);
	
	SetNull(n == Null);		// DbRaw::DbRaw(int)
}

DbRaw::DbRaw(const DbRaw &r)
	: DbVal(r)
{
	m_nSize = r.m_nSize;
	m_pBuff = STNew unsigned char [m_nSize];
	memcpy(m_pBuff, r.m_pBuff, m_nSize);
}

DbRaw::~DbRaw()
{
	STDelete [] m_pBuff;
}

void DbRaw::operator = (const DbRaw &r)
{
	DbVal::operator = (r);

	STDelete [] m_pBuff;
	m_nSize = r.m_nSize;
	m_pBuff = STNew unsigned char [m_nSize];
	memcpy(m_pBuff, r.m_pBuff, m_nSize);
}

void DbRaw::SetBit(int i, int nValue)
{
	int nByte = i / 8;
	int nBit = i % 8;

	if (nValue)
		m_pBuff[nByte] |= 1 << nBit;
	else
		m_pBuff[nByte] &= ~(1u << nBit);
		
	SetNull(0);		// DbRaw::SetBit
}

int DbRaw::GetBit(int i) const
{
	int nByte = i / 8;
	int nBit = i % 8;

	return m_pBuff[nByte] & (1 << nBit) ? 1 : 0;
}

STDizWordKey DbRaw::UsrValidate(RWCString &strToValidate) const
{
	if (m_pSTValidator)
		return m_pSTValidator->RunValidator(strToValidate);
	return MSG_LIBDB_NULL;
}

RWCString DbRaw::UsrPrint() const
{
	return RWCString("");
}


void DbRaw::UsrSet(const RWCString &)
{
}

int DbRaw::STIsEqual(const STRoot *p) const
{
	DbRaw *ps = DynamicCast(DbRaw *, p);
	if (ps == 0)
		return 0;
	if (DbVal::STIsEqual(p) == 0)
		return 0;
	
	if (IsNull() && ps->IsNull())
		return 1;

	int r =  memcmp(ps->m_pBuff, m_pBuff, m_nSize);
	return r == 0 ? 1 : 0;
}

int DbRaw::STCompareTo(const STRoot *p) const
{
	DbRaw *ps = DynamicCast(DbRaw *, p);
	if (ps == 0) return 1;
	return memcmp(ps->m_pBuff, m_pBuff, m_nSize < ps->m_nSize ? m_nSize : ps->m_nSize);
}

ostream & DbRaw::STDebug(ostream &s) const
{
	s << "DbRaw(" << (CanBeNull() ? "NULL" : "NOT NULL") << ", " << m_nSize << ") = ";
	s << (IsNull() ? "NULL" : "NOT NULL") << " value \"" << DbPrint(ST_DB_ORACLE) << "\"" << endl;
	return s;
}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////

/* queste funzioni servono per far funzionare DbTS */

static int GetNum(const char *&pcStr, int &nOut, int nMaxCifre = 0)
{
	/* salto gli spazi bianchi */
	while (*pcStr == ' ' || *pcStr == '\t' || *pcStr == '\n')
		pcStr++;
		
	/* deve iniziare con un numero */
	if (*pcStr < '0' || *pcStr > '9')
		return 0;

	nOut = 0;
	while (*pcStr >= '0' && *pcStr <= '9')
	{
		nOut = nOut * 10 + *pcStr++ - '0';
		nMaxCifre -= 1;

		if (nMaxCifre == 0)
			break;
	}
		
	return 1;
}


static RWCString PrintTS(const char *pcFmt, const DataTS *pDataTS)
{
	RWCString r;
	char b[20];
	
	while (*pcFmt)
	{
		switch (*pcFmt++)
		{
		default:
			r.append(pcFmt[-1]);
			break;
				
		case '%':
			switch (*pcFmt++)
			{
			case '%':
				r.append(pcFmt[-1]);
				break;

			case 'l':
				sprintf(b, "%02d%02d%02d", pDataTS->DD,
				                           pDataTS->MM,
				                           pDataTS->YYYY % 100);
				r.append(b);
				break;

			case 'L':
				sprintf(b, "%02d%02d%04d", pDataTS->DD,
				                           pDataTS->MM,
				                           pDataTS->YYYY);
				r.append(b);
				break;

			case 'y':  // anno a 2 cifre
				sprintf(b, "%02d", pDataTS->YYYY % 100);
				r.append(b);
				break;
				
			case 'Y':  // anno a 4 cifre
				sprintf(b, "%d", pDataTS->YYYY);
				r.append(b);
				break;

			case 'm':  // mese a 2 cifre
				sprintf(b, "%02d", pDataTS->MM);
				r.append(b);
				break;

			case 'd':  // giorno a 2 cifre
				sprintf(b, "%02d", pDataTS->DD);
				r.append(b);
				break;

			case 'H':  // ora a 2 cifre (0-23)
				sprintf(b, "%02d", pDataTS->hh);
				r.append(b);
				break;

			case 'M':  // minuti a 2 cifre
				sprintf(b, "%02d", pDataTS->mm);
				r.append(b);
				break;

			case 'S':  // secondi a 2 cifre
				sprintf(b, "%02d", pDataTS->ss);
				r.append(b);
				break;

			// modifica del 13/7/96 di P.M.
			case 'O':  // prime 3 lettere del mese
				r.append(pDataTS->MON,3);
				break;

			case 'N': // giorno dell'anno in formato NNN
				sprintf(b, "%d", pDataTS->NNN);
				r.append(b);
				break;

			case 'A': // A se ora solare, B per ora legale
				sprintf(b, "%c", ( pDataTS->A ? ORA_LEGALE : ORA_SOLARE));
				r.append(b);
				break;
			// fine modifica

			default:
				STError("stringa di formattazione della DbTS errata");
			}
			break;
		}
	}
	return r;
}

static int GetTS(const char *pcStr, const char *pcFmt, DataTS *pDataTS)
{
	int r;

	/* la data/ora e' resettata alle 00:00 del 1 gen 1901 */
	pDataTS->YYYY = 1901;
	pDataTS->MM   = 1;
	pDataTS->DD   = 1;
	pDataTS->hh   = 0;
	pDataTS->mm   = 0;
	pDataTS->ss   = 0;

	if (strcmp(pcFmt, "%d/%m/%y") == 0 ||
	    strcmp(pcFmt, "%d/%m/%Y") == 0)
	{
		/* accetto anche una data di formato 020299 o 02031999 */

		int g, m, y;
		const char *str = pcStr;
		r  = 0;
		r += GetNum(str, g, 2);
		r += GetNum(str, m, 2);
		if (strchr(pcFmt, 'Y'))
		{
			r += GetNum(str, y, 4);
			if (r == 3)
				if (y < 1900 || y > 2100)
					r = 2;	/* data non valida */
		}
		else
			r += GetNum(str, y, 2);
		
		/* salto gli eventuali spazi bianchi */
		while (*str == ' ')
			str++;

		if (*str == 0 && r == 3)
		{
			static char b[20];
			if (strchr(pcFmt, 'Y'))
				sprintf(b, "%02d/%02d/%04d", g, m, y);
			else
				sprintf(b, "%02d/%02d/%02d", g, m, y % 100);
			pcStr = b;
		}
	}

	if (strcmp(pcFmt, "%d/%m/%Y %H:%M") == 0 ||
	    strcmp(pcFmt, "%d/%m/%Y %H:%M:%S") == 0)
	{
		/* accetto anche una data di formato 020219991200 o 02021995120040 */

		int g, m, y, H, M, S = 0;
		const char *str = pcStr;
		r  = 0;

		r += GetNum(str, g, 2);
		r += GetNum(str, m, 2);
		r += GetNum(str, y, 4);
		r += GetNum(str, H, 2);
		r += GetNum(str, M, 2);
		if (strstr(pcFmt, "%S"))
			r += GetNum(str, S, 2);
		else
			r += 1;
		
		/* salto gli eventuali spazi bianchi */
		while (*str == ' ')
			str++;

		if (*str == 0 && r == 6)
		{
			static char b[40];
			if (strstr(pcFmt, "%S") == 0)
				sprintf(b, "%02d/%02d/%04d %02d:%02d", g, m, y, H, M);
			else
				sprintf(b, "%02d/%02d/%04d %02d:%02d:%02d", g, m, y, H, M, S);
			pcStr = b;
		}
	}
	
	while (*pcFmt)
	{
		switch (*pcFmt++)
		{
		case '%':
			switch (*pcFmt++)
			{
			case '%':
				if (*pcStr++ != *pcFmt)
					return 0;
				break;

			case 'y':  // anno a 2 cifre
				r = GetNum(pcStr, pDataTS->YYYY, 2);
				if (r == 0)
					return 0;
				
				if (pDataTS->YYYY > 50)
					pDataTS->YYYY += 1900;
				else
					pDataTS->YYYY += 2000;
				break;

			case 'Y':  // anno a 4 cifre
				r = GetNum(pcStr, pDataTS->YYYY, 4);
				if (r == 0 || pDataTS->YYYY < 1901 || pDataTS->YYYY > 2100)
					return 0;
				break;

			case 'm':  // mese a 2 cifre
				r = GetNum(pcStr, pDataTS->MM, 2);
				if (r == 0 || pDataTS->MM < 1 || pDataTS->MM > 12)
					return	0;
				break;

			case 'd':  // giorno a 2 cifre
				r = GetNum(pcStr, pDataTS->DD, 2);
				if (r == 0 || pDataTS->DD < 1 || pDataTS->DD > 31)
					return	0;
				break;

			case 'H':  // ora a 2 cifre (0-23)
				r = GetNum(pcStr, pDataTS->hh, 2);
				if (r == 0 || pDataTS->hh < 0 || pDataTS->hh > 23)
					return	0;
				break;

			case 'M':  // minuti a 2 cifre
				r = GetNum(pcStr, pDataTS->mm, 2);
				if (r == 0 || pDataTS->mm < 0 || pDataTS->mm > 59)
					return	0;
				break;

			case 'S':  // secondi a 2 cifre
				r = GetNum(pcStr, pDataTS->ss, 2);
				if (r == 0 || pDataTS->ss < 0 || pDataTS->ss > 59)
					return	0;
				break;

			case 'l':
				r = GetNum(pcStr, pDataTS->DD, 2);
				if (r == 0 || pDataTS->DD < 1 || pDataTS->DD > 31)
					return	0;
				r = GetNum(pcStr, pDataTS->MM, 2);
				if (r == 0 || pDataTS->MM < 1 || pDataTS->MM > 12)
					return	0;
				r = GetNum(pcStr, pDataTS->YYYY, 2);
				if (r == 0)
					return 0;
				
				if (pDataTS->YYYY > 50)
					pDataTS->YYYY += 1900;
				else
					pDataTS->YYYY += 2000;
				break;

			case 'L':
				r = GetNum(pcStr, pDataTS->DD, 2);
				if (r == 0 || pDataTS->DD < 1 || pDataTS->DD > 31)
					return	0;
				r = GetNum(pcStr, pDataTS->MM, 2);
				if (r == 0 || pDataTS->MM < 1 || pDataTS->MM > 12)
					return	0;
				r = GetNum(pcStr, pDataTS->YYYY, 4);
				if (r == 0 || pDataTS->YYYY < 1901 || pDataTS->YYYY > 2100)
					return 0;
				break;

			default:
				STError("stringa di formattazione della DbTS errata");
			}
			break;

		case ' ':
			while (*pcStr == ' ' || *pcStr == '\t')
				pcStr++;
			break;
			
		default:
			if (*pcStr++ != pcFmt[-1])
				return 0;
		}
	}

	/* controllo che la stringa sia finita */
	while (*pcStr == ' ' || *pcStr == '\t')
		pcStr++;

	if (*pcStr)
		return 0;

	/* controllo la correttezza della data */
	RWDate d(pDataTS->DD, pDataTS->MM, pDataTS->YYYY);
	return d.isValid();
}


////////////////////////////////////////////////////////////////////////////////

int DbString::GetDbSize() const
{
	return m_nMaxLen + 1;
}

int DbInt::GetDbSize() const
{
	return sizeof(m_nValue);
}

int DbShort::GetDbSize() const
{
	return sizeof(Int16);
}

int DbChar::GetDbSize() const
{
	return /* sizeof(m_cValue) */ 2;
}

int DbDouble::GetDbSize() const
{
	return sizeof(m_dValue);
}

int DbTS::GetDbSize() const
{
	ST_COND_APPL(0, "non bisogna chiamare questo metodo");
	return 0;
}

int DbRaw::GetDbSize() const
{
	return m_nSize;
}




const void * DbString::GetDbAddress() const
{
	return m_p;
}

const void * DbInt::GetDbAddress() const
{
	return &m_nValue;
}

const void * DbShort::GetDbAddress() const
{
	return &m_nValue;
}

const void * DbChar::GetDbAddress() const
{
	return &m_cValue[0];
}

const void * DbDouble::GetDbAddress() const
{
	return &m_dValue;
}

const void * DbTS::GetDbAddress() const
{
	ST_COND_APPL(0, "non bisogna chiamare questo metodo");
	return NULL;
}

const void * DbRaw::GetDbAddress() const
{
	return m_pBuff;
}


RWCString DbString::DbPrint(STDbType /* ty */) const
{                                
	if (IsNull() == 0)
	{
		RWCString r("'");
		const char *p = *this;

		while (*p)
		{
			if (*p == '\'')
				r.append(*p);
			r.append(*p);
			p++;
		}
		r.append("'");
		return r;
	}
	else
		return RWCString("NULL");
}

RWCString DbInt::DbPrint(STDbType /* ty */) const
{       
	if (IsNull() == 0)
	{
		char b[20];
		ostrstream s(b, sizeof(b));
		s << m_nValue << ends;
		return RWCString(b);
	}
	else
		return RWCString("NULL");
}

RWCString DbShort::DbPrint(STDbType /* ty */) const
{       
	if (IsNull() == 0)
	{
		char b[20];
		ostrstream s(b, sizeof(b));
		s << m_nValue << ends;
		return RWCString(b);
	}
	else
		return RWCString("NULL");
}

RWCString DbChar::DbPrint(STDbType /* ty */) const
{
    if (IsNull() == 0)
    {
		char b[20];
		ostrstream s(b, sizeof(b));
		s << "CHR(" << int(m_cValue[0]) << ")" << ends;
		return RWCString(b);
	}
	else
		return RWCString("NULL");
}

RWCString DbDouble::DbPrint(STDbType /* ty */) const
{           
	if (IsNull() == 0)
	{
		char b[20];
		sprintf(b, "%.*f", m_nSize2, m_dValue);
		return RWCString(b);
	}
	else
		return RWCString("NULL");
}

RWCString DbTS::DbPrint(STDbType ty) const
{       
	if (IsNull() == 0)
	{
		char b[80];
		RWDate d(*this);

		RWCString s(asString('S'));
		if (s.length() == 1)
			s = "0" + s;
		int nSec = atoi(s);

		switch (ty)
		{
			case ST_DB_ORACLE:
				sprintf(b,
						"TO_DATE('%04d %02d %02d %02d %02d %02d', 'YYYY MM DD HH24 MI SS')",
						d.year(),
						d.month(),
						d.dayOfMonth(),
						hour(),
						minute(),
						nSec);
				break;

			case ST_DB_ODBC:
				sprintf(b,
						"{ts '%04d-%02d-%02d %02d:%02d:%02d'}",
						d.year(),
						d.month(), 
						d.dayOfMonth(), 
						hour(), 
						minute(), 
						nSec);
				break;

			default:
				STError("Tipo DB non valido");
				break;
		}


		return RWCString(b);
	}
	else
		return RWCString("NULL");
}

RWCString DbRaw::DbPrint(STDbType /* ty */) const
{
	if (IsNull() == 0)
	{
		RWCString r("'");
		for (int i = 0; i < m_nSize; i++)
		{
			char b[3];
			sprintf(b, "%02x", m_pBuff[i]);
			r.append(b);
		}
		r.append("'");
		return r;
	}
	else
		return RWCString("NULL");
}



RWCString DbString::GetDbType() const
{
	char b[40];
	ostrstream s(b, sizeof(b));
	s << "CHAR(" << m_nMaxLen << ")" << (CanBeNull() ? " NULL" : " NOT NULL") << ends;
	return RWCString(b);
}

RWCString DbInt::GetDbType() const
{
	char b[40];
	ostrstream s(b, sizeof(b));
	s << "NUMBER(" << m_nDigits << ")" << (CanBeNull() ? " NULL" : " NOT NULL") << ends;
	return RWCString(b);
}

RWCString DbShort::GetDbType() const
{
	char b[40];
	ostrstream s(b, sizeof(b));
	s << "NUMBER(" << m_nDigits << ")" << (CanBeNull() ? " NULL" : " NOT NULL") << ends;
	return RWCString(b);
}

RWCString DbChar::GetDbType() const
{
	char b[40];
	ostrstream s(b, sizeof(b));
	s << "CHAR(1)" << (CanBeNull() ? " NULL" : " NOT NULL") << ends;
	return RWCString(b);
}

RWCString DbDouble::GetDbType() const
{
	char b[40];
	ostrstream s(b, sizeof(b));
	s << "NUMBER(" << m_nSize1 << ", " << m_nSize2 << ")" << (CanBeNull() ? " NULL" : " NOT NULL") << ends;
	return RWCString(b);
}

RWCString DbTS::GetDbType() const
{
	char b[40];
	ostrstream s(b, sizeof(b));
	s << "DATE" << (CanBeNull() ? " NULL" : " NOT NULL") << ends;
	return RWCString(b);
}

RWCString DbRaw::GetDbType() const
{
	char b[40];
	ostrstream s(b, sizeof(b));
	s << "RAW(" << m_nSize << ")" << (CanBeNull() ? " NULL" : " NOT NULL") << ends;
	return RWCString(b);
}

