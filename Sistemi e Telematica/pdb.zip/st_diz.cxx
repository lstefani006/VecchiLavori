#include <st_dbnew.h>
/*********************************************************************
 *
   Copyright (c) 1995

   File Name:		STDizionario.cxx

   Author:              Marco Cresta
   Date:                2/3/95

   Class:               STDizionario

								     *
 *********************************************************************/

#include "st_diz.h"
#include "st_err.h"

#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <rw/cstring.h>
#include <rw/regexp.h>
#include <rw/hashdict.h>
#include <rw/collstr.h>
#include <rw/collint.h>


STDizionario *G_Diz = NULL;

#define  LUNG_STR_BUFFER 1000


RWBoolean
LeggiStringaDaFileSTDictionary(FILE * file_dizionario,
							   char str[],
							   char &ch);
// ----------------------------------------------------------------------
// Scandisce il file a partire dal carattere corrente, il cui
// valore e' in 'ch', alla ricerca di una stringa racchiusa tra " ",
// all'interno della stringa '"' viene rappresentato come \" mentre '\'
// come \\ . Se riconosciuta stringa corretta: posta in str, ch contiene
// il prossimo carattere del file, restituito 1,  altrimenti 0.
// ----------------------------------------------------------------------

static RWBoolean
LeggiInteroDaFileSTDictionary(FILE * file_dizionario,
							  int &valore_intero,
							  char &ch);
// ----------------------------------------------------------------------
// Scandisce il file a partire dal carattere corrente, il cui valore e'
// in ch, alla ricerca di un intero con segno. Se viene riconosciuto
// viene posto in 'valore_intero', ch contiene il prossimo carattere del
// file, restituito 1, altrimenti 0.
// ----------------------------------------------------------------------

static RWBoolean LeggiBlanks(FILE * file_dizionario, char &ch);
// ----------------------------------------------------------------------
// Scandisce il file alla ricerca del primo carattere non-blanks.
// Se trova un carattere non blanks pone in ch e ritorna 1,
// ritorna 0 se il file e' finito.
// ---------------------------------------------------------------------

// /////////////////////////////////////////////////////////////////////
STDizionario::STDizionario()
{
	theDictionary = STNew RWHashDictionary(2048);

	if (G_Diz == NULL)
		G_Diz = this;
}

// //////////////////////////////////////////////////////////////////////
STDizionario::~STDizionario(void)
{
	theDictionary->clearAndDestroy();
	STDelete theDictionary;

	if (G_Diz == this)
		G_Diz = NULL;
}

// /////////////////////////////////////////////////////////////////////
RWBoolean
STDizionario::Load(const RWCString &theApplicationName)
{
	RWCString sEnv = theApplicationName;
	{
		sEnv.toUpper();
		sEnv = "ST_" + sEnv + "_LNO";
		if (getenv(sEnv) != NULL)
			sEnv = getenv(sEnv);
		else
			sEnv = "";
	}
	

	RWCString pgmName = theApplicationName;
#ifdef DOS
	if (sEnv == "")
	{
		// tolgo il suffisso .EXE se esiste
		static RWCRegexp re("\\.[eE][xX][eE]");
		pgmName(re) = "";
	}
#endif


	RWCString dict_file_name;

	if (sEnv == "")
	{
		const char *language = getenv("ST_LANGUAGE");
		if (language == NULL)
			language = "it";
		dict_file_name = pgmName + "_" + language + ".lno";
		theLanguage = language;
	}
	else
		dict_file_name = sEnv;


	FILE *dict_file = fopen(dict_file_name, "r");
	if (dict_file == 0)
		STError("Errore in Apertura File: %s", (const char *)dict_file_name);

	char aWord[LUNG_STR_BUFFER];
	STDizWordKey aKey = 0;

	char ch = '\0';

	int r = 0;
	while (!feof(dict_file))
	{
		int qq;
		if (!LeggiInteroDaFileSTDictionary(dict_file, qq, ch))
			break;
		aKey = qq;

		if (!LeggiStringaDaFileSTDictionary(dict_file, aWord, ch))
			break;

		InsertWord(aKey, aWord);

		if (!LeggiBlanks(dict_file, ch))
		{
			r = 1;
			break;
		}
	}

	fclose(dict_file);
	return r;
}

// //////////////////////////////////////////////////////////////////////
RWCString
STDizionario::GetWord(const STDizWordKey &aWordKey) const
{
	RWCollectableInt theTarget(aWordKey.Get());

	RWCollectableString *tmp = (RWCollectableString *) theDictionary->findValue(&theTarget);

	RWCString r;

	if (tmp)
		r = *tmp;

	RWCRegexp re("%[0-9][0-9]?");

	for (;;)
	{
		RWCSubString ss = r(re);
		if (ss.length() == 0)
			break;

		int i = atoi((const char *)(RWCString(ss)) + 1) - 1;

		if (i >= 0 && i < aWordKey.GetA().Size())
			ss = aWordKey.GetA()[i];
		else
			break;
	}

	return r;
}

// /////////////////////////////////////////////////////////////////////
RWCString
STDizionario::GetLanguage(void) const
{
	return theLanguage;
}

// /////////////////////////////////////////////////////////////////////
RWBoolean
STDizionario::InsertWord(const STDizWordKey &aKey, const RWCString &aWord)
{
	RWCollectableInt *theKey = STNew RWCollectableInt(aKey.Get());
	RWCollectableString *theWord = STNew RWCollectableString(aWord);

	if (theDictionary->insertKeyAndValue(theKey, theWord) == NULL)
		return 0;				// Chiave gia' presente
	else
		return 1;
}

// /////////////////////////////////////////////////////////////////////
RWBoolean
STDizionario::RemoveWord(const STDizWordKey &aKey)
{
	RWCollectableInt theKey(aKey.Get());

	if (theDictionary->remove(&theKey) == NULL)
		return 0;				// Chiave non trovata
	else
		return 1;
}

// /////////////////////////////////////////////////////////////////////
static RWBoolean
LeggiInteroDaFileSTDictionary(FILE * file_dizionario,
							  int &valore_intero,
							  char &ch)
{
	char str[LUNG_STR_BUFFER];
	int cursor = 0;

	while (!feof(file_dizionario) && cursor < LUNG_STR_BUFFER)
	{

		if (!(isdigit(ch) || ch == '-'))
		{

			ch = getc(file_dizionario);
			continue;
		}

		str[cursor++] = ch;		// Riconosciuto primo carattere valido per
		// int

		while (!feof(file_dizionario) && cursor < LUNG_STR_BUFFER)
		{
			ch = getc(file_dizionario);

			if (isdigit(ch))

				str[cursor++] = ch;

			else if (ch == ' ' || ch == '\n')
			{
				str[cursor] = '\0';
				if (!sscanf(str, "%d", &valore_intero))
					return 0;
				return 1;
			}
			else
			{					// Errore sintattico
				valore_intero = 0;
				return 0;
			}

		}						// END WHILE

	}							// END WHILE
	return 0;
}

// /////////////////////////////////////////////////////////////////////
static RWBoolean
LeggiBlanks(FILE * file_dizionario, char &ch)
{
	ch = getc(file_dizionario);

	// va avanti fino al \n incluso, quando lo trova legge il primo char valido
	while (ch != EOF && (ch == ' ' || ch == '\n'))
		ch = getc(file_dizionario);

	// se c'e` un commento va avanti fino al return incluso e legge il prossimo char
	if (ch == '/')
	{
		while (ch != EOF && ch != '\n')
			ch = getc(file_dizionario);
		ch = getc(file_dizionario);
	}

	if (ch == EOF)
		return 0;
	else
		return 1;
}

// /////////////////////////////////////////////////////////////////////
RWBoolean
LeggiStringaDaFileSTDictionary(FILE * file_dizionario,
							   char str[LUNG_STR_BUFFER],
							   char &ch)
{
	int cursor = 0;
	int finito = 0;

	while (!feof(file_dizionario) && !finito && cursor < LUNG_STR_BUFFER)
	{

		if (ch != '"')
		{

			ch = getc(file_dizionario);
			continue;
		}

		while (!feof(file_dizionario) && !finito && cursor < LUNG_STR_BUFFER)
		{
			ch = getc(file_dizionario);

			switch (ch)
			{
			default:
				str[cursor++] = ch;
				break;

			case '"':
				str[cursor] = '\0';
				finito = 1;
				break;

			case '\n':
				str[cursor] = 0;
				cerr << "Raggiunto \\n nella stringa \"" << str << "\"" << endl;
				exit(1);
				break;

			case '\\':
				if (!feof(file_dizionario) && cursor < LUNG_STR_BUFFER)
				{
					ch = getc(file_dizionario);

					switch (ch)
					{
					case '"':
					case '\\':
						str[cursor++] = ch;
						break;

					default:	// Errore Sintattico
						return 0;

					}			// END SWITCH
				}				// END IF
				break;

			}					// END SWITCH
		}						// END WHILE
	}							// END WHILE

	if (finito)
		return 1;
	else
		return 0;
}
