#include <st_dbnew.h>
#include <st_dblst.h>
#include <st_dbxx.h>

STImplementClassInfo2(STDbSlist, STSlist, STDbEl)
STImplementAssignClone(STDbSlist)

void STDbSlist::operator = (const STDbSlist &s)
{
	STSlist::operator = (s);
}

int STDbSlist::STIsEqual(const STRoot *p) const
{
	return STSlist::STIsEqual(p);
}


void STDbSlist::AddHead(STRoot *p)
{
	STRoot *a = DynamicCast(STDbBase *, p);
	if (a == 0)
		STError("STDbSlist::AddHead() - called with wrong object type");
	STSlist::AddHead(a);
}

void STDbSlist::AddTail(STRoot *p)
{
	STRoot *a = DynamicCast(STDbBase *, p);
	if (a == 0)
		STError("STDbSlist::AddTail() - called with wrong object type");
		
	STSlist::AddTail(a);
}

STRoot * STDbSlist::GetHead()
{
	STRoot *a = STSlist::GetHead();
	return DynamicCast(STDbBase *, a);
}

STRoot * STDbSlist::Remove(STRoot *p)
{
	STRoot *a = STSlist::Remove(p);
	return DynamicCast(STDbBase *, a);
}

STRoot * STDbSlist::Search(STRoot *p) const
{
	STRoot *a = STSlist::Search(p);
	return DynamicCast(STDbBase *, a);
}

STDbError STDbSlist::Select(STDbTransaction &tr, const char *theClassName, const STDbWhereLogical &w, STSelectType st)
{
	return STDbBase::Select(tr, theClassName, w, *this, st);
}

STDbError STDbSlist::Select(STDbTransaction &tr, const char *theClassName, STSelectType st)
{
	return STDbBase::Select(tr, theClassName, STDbWhereLogicalTrue, *this, st);
}


ostream & STDbSlist::STDebug(ostream &s) const
{
	s << "List of {\n";

	STDbSlistIterator it(*this);
	STDbBase *p;
	while (p = it())
		p->STDebug(s);

	s << "}\n\n";

	return s;
}

///////////////////////////////////////////////////////////////////////////////


STDbError STDbSlist::Load(STDbTransaction &tr, const char *theClassName, const STDbWhereLogical &w, STSelectType st)
{
	/* LEO
	STDbSlist list;
	STDbError e = list.Select(tr, theClassName, w, st);

	for (;;)
	{
		STRoot *pr = list.GetHead();
		STDbBase *p = DynamicCast(STDbBase *, pr);

		if (p == NULL)
			break;

		// LEO p->SetBack();
		AddTail(p);
	}

	return e;
	*/

	return Select(tr, theClassName, w, st);
}


void STDbSlist::Erase()
{
	STDbSlistIterator it(*this);
	STDbBase *p;
	while (p = it())
		p->Erase();
}

void STDbSlist::Add(STDbBase *p)
{
	AddTail(p);
}

int STDbSlist::Check(STDbTransaction &tr) const
{
	STDbSlistIterator it(*this);
	STDbBase *p;
	while (p = it())
		if (p->Check(tr) == 0)
			return 0;

	return 1;
}

STDbError STDbSlist::Save(STDbTransaction &tr, SaveType sv) const
{
	STDbSlistIterator it(*this);
	STDbBase *p;
	while (p = it())
	{
		STDbError e;
		e = p->Save(tr, sv);
		if (e == ST_DB_OK)
			;
		else
			return e;
	}

	return ST_DB_OK;
}

void STDbSlist::SetBack()
{
	STDbSlistIterator it(*this);
	STDbBase *p;
	while (p = it())
		p->SetBack();
}

void STDbSlist::ResetBack()
{
	STDbSlistIterator it(*this);
	STDbBase *p;
	while (p = it())
		p->ResetBack();
}


///////////////////////////////////////////////////////////////////////////////

STDbBase * STDbSlistIterator::operator () ()
{
	STRoot *p = STSlistIterator::operator ()();
	return DynamicCast(STDbBase *, p);
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
