#ifndef __st_root_h__
#define __st_root_h__

#include <iostream.h>
#include <stdlib.h>

#include "st_tvect.h"
#include "st_err.h"

#ifndef DOS
	typedef int             Int32;
	typedef short           Int16;
	typedef unsigned int    UInt32;
	typedef unsigned short  UInt16;
#else
	typedef long            Int32;
	typedef short           Int16;
	typedef unsigned long   UInt32;
	typedef unsigned short  UInt16;
#endif

typedef const char * ClassIdType;

#ifdef NO_TEMPLATES
	#ifndef D_STTVectPC_STTypeInfo
		typedef /* const (bug cl) */ class STTypeInfo *PC_STTypeInfo;
		declare(STTVect, PC_STTypeInfo);
	#endif
#endif

#ifdef NO_EXCEPTIONS
	void ST_Throw(const char *);
	extern void (*G_pfThrow)(const char *);
#else
	#define ST_Throw(a) throw(a)
#endif

class STTypeInfo
{
public:
	STTypeInfo(const char *pcName, const STTypeInfo *theClassBases[]);

	virtual           ~STTypeInfo();

	ClassIdType        GetClassId()   const { return m_pcClassName; }
	const char *       GetClassName() const { return m_pcClassName; }

	int                IsSame(const STTypeInfo *p) const { return p == this; }
	int                IsDerivedFrom(const STTypeInfo *p) const;

#ifndef NO_TEMPLATES
	STTVect<const STTypeInfo *> GetDirectBaseClasses() const;
	STTVect<const STTypeInfo *> GetDirectDerivedClasses() const;
	STTVect<const STTypeInfo *> GetDerivedClasses() const;
#else
	STTVect(PC_STTypeInfo) GetDirectBaseClasses() const;
	STTVect(PC_STTypeInfo) GetDirectDerivedClasses() const;
	STTVect(PC_STTypeInfo) GetDerivedClasses() const;
#endif

	static const STTypeInfo * GetTypeInfo(ClassIdType ClassId);

protected:
	const char               *m_pcClassName;
	const STTypeInfo        **m_ppSTTypeInfoBases;


	static void               Register(const STTypeInfo *);
	static const STTypeInfo **s_ppSTTypeInfo;
	static int                s_nTop;
	static int                s_nMax;
};







#define STDefineClassInfo \
	static  const STTypeInfo   s_STTypeInfo; \
	static  const STTypeInfo  *s_paSTTypeInfoBases[]; \
	static  const STTypeInfo * GetSTI(); \
	virtual const STTypeInfo * GetRTTI() const; \
	virtual void *             IsA(ClassIdType ClassId) const; \


#define STTypeInfoMethods(theClass, theClassName) \
	class theClass; \
	const STTypeInfo theClass::s_STTypeInfo(theClassName, theClass::s_paSTTypeInfoBases); \
	const STTypeInfo * theClass::GetSTI()        { return &s_STTypeInfo; } \
	const STTypeInfo * theClass::GetRTTI() const { return &s_STTypeInfo; }

#define STIsAMethods0(theClass) \
	void * theClass::IsA(ClassIdType ClassId) const \
	{ \
		if (ClassId == 0) return (void *)this; \
		if (ClassId == s_STTypeInfo.GetClassId()) return (void *)this; \
		return 0; \
	}

#define STIsAMethods1(theClass, b1) \
	void * theClass::IsA(ClassIdType ClassId) const \
	{ \
		if (ClassId == 0) return (void *)this; \
		if (ClassId == s_STTypeInfo.GetClassId()) return (void *)this; \
		return b1::IsA(ClassId); \
	}

#define STIsAMethods2(theClass, b1, b2) \
	void * theClass::IsA(ClassIdType ClassId) const \
	{ \
		if (ClassId == 0) return (void *)this; \
		if (ClassId == s_STTypeInfo.GetClassId()) return (void *)this; \
		void *p1 = b1::IsA(ClassId); \
		void *p2 = b2::IsA(ClassId); \
		if (p1 == p2) return p1; \
		if (p1 == 0 && p2) return p2; \
		if (p2 == 0 && p1) return p1; \
		return 0; \
	}

#define STIsAMethods3(theClass, b1, b2, b3) \
	void * theClass::IsA(ClassIdType ClassId) const \
	{ \
		if (ClassId == 0) return (void *)this; \
		if (ClassId == s_STTypeInfo.GetClassId()) return (void *)this; \
		void *p[3]; \
		p[0] = b1::IsA(ClassId); \
		p[1] = b2::IsA(ClassId); \
		p[2] = b3::IsA(ClassId); \
\
		void *aa = 0; \
		for (int i = 0; i < 3; i++) \
			if ((aa = p[i]) != 0) \
				break; \
		if (aa == 0) \
			return 0; \
\
		for (i = 0; i < 3; i++) \
			if (p[i] != 0 && p[i] != aa) \
				return 0; \
		return aa; \
	}

#define STImplementClassInfo0(theClass) \
	STTypeInfoMethods(theClass, #theClass) \
	STIsAMethods0(theClass) \
	const STTypeInfo * theClass::s_paSTTypeInfoBases[] = { 0 };

#define STImplementClassInfo1(theClass, b1) \
	STTypeInfoMethods(theClass, #theClass) \
	STIsAMethods1(theClass, b1) \
	const STTypeInfo * theClass::s_paSTTypeInfoBases[] = { &b1::s_STTypeInfo, 0 };

#define STImplementTemplateInfo1(theClass, theClassName, b1) \
	STTypeInfoMethods(theClass, theClassName) \
	STIsAMethods1(theClass, b1) \
	const STTypeInfo * theClass::s_paSTTypeInfoBases[] = { &b1::s_STTypeInfo, 0 };

#define STImplementClassInfo2(theClass, b1, b2) \
	STTypeInfoMethods(theClass, #theClass) \
	STIsAMethods2(theClass, b1, b2) \
	const STTypeInfo * theClass::s_paSTTypeInfoBases[] = { &b1::s_STTypeInfo, &b2::s_STTypeInfo, 0 };

#define STImplementClassInfo3(theClass, b1, b2, b3) \
	STTypeInfoMethods(theClass, #theClass) \
	STIsAMethods3(theClass, b1, b2, b3) \
	const STTypeInfo * theClass::s_paSTTypeInfoBases[] = { &b1::s_STTypeInfo, &b2::s_STTypeInfo, &b3::s_STTypeInfo, 0 };

////////////////////////////////////////////////////////////////////////////////

#define STDeclareAbstractAssignClone2(ClassName, ClassReturned) \
	virtual ClassReturned * STCreate() const = 0; \
	virtual ClassReturned * STClone() const = 0; \
	virtual void            STAssign(const STRoot *p); \
    virtual int             STIsEqual(const STRoot *p) const;

#define STDeclareAssignClone2(ClassName, ClassReturned) \
	virtual ClassReturned * STCreate() const; \
	virtual ClassReturned * STClone() const; \
	virtual void            STAssign(const STRoot *p); \
    virtual int             STIsEqual(const STRoot *p) const;

#define STImplementAbstractAssignClone2(ClassName, ClassNameReturned) \
	ClassNameReturned * ClassName::STCreate() const { return NULL; } \
	ClassNameReturned * ClassName::STClone() const  { return NULL; } \
	void ClassName::STAssign(const STRoot *p) { \
		ClassName *ps = DynamicCast(ClassName *, p); \
		if (ps == 0) \
			STError(#ClassName ":STAssign() - invalid obejct"); \
		*this = *ps; \
	}

#define STImplementAssignClone2(ClassName, ClassNameReturned) \
	ClassNameReturned * ClassName::STCreate() const { return STNew ClassName; } \
	ClassNameReturned * ClassName::STClone() const  { return STNew ClassName(*this); } \
	void ClassName::STAssign(const STRoot *p) { \
		ClassName *ps = DynamicCast(ClassName *, p); \
		if (ps == 0) \
			STError(#ClassName ":STAssign() - invalid obejct"); \
		*this = *ps; \
	}


// Queste quattro define potranno essere modificate in 
// STImplementAssignClone2(ClassName, ClassName)
// quando si avra` a che fare con un compilatore serio

#define STDeclareAbstractAssignClone(ClassName) \
	STDeclareAbstractAssignClone2(ClassName, STRoot)

#define STDeclareAssignClone(ClassName) \
	STDeclareAssignClone2(ClassName, STRoot)

#define STImplementAssignClone(ClassName) \
	STImplementAssignClone2(ClassName, STRoot)

#define STImplementAbstractAssignClone(ClassName) \
	STImplementAbstractAssignClone2(ClassName, STRoot)


class STRoot
{
public:
	STDefineClassInfo

	virtual           ~STRoot();
	virtual STRoot *   STCreate() const = 0;
	virtual STRoot *   STClone() const = 0;
	virtual void       STAssign(const STRoot *) = 0;
	virtual int        STIsEqual(const STRoot *) const = 0;
	
	virtual int        STCompareTo(const STRoot *) const;
	virtual ostream &  STDebug(ostream &) const;
};

inline ostream & operator << (ostream &s, const STRoot &a)
{
	a.STDebug(s);
	return s;
}


#ifdef NO_TEMPLATES
	extern const STRoot *__tmpDC__;

	#define DynamicCast(T, p) \
		(((__tmpDC__ = (p)) == 0) ? 0 : (T)((__tmpDC__)->IsA(((T)0)->GetSTI()->GetClassId())))

#else

	#define DynamicCast(T, p) ST__DynamicCast<T>(p)
	template <class T> /* Ok Macro */
	class ST__DynamicCast
	{
	public:
		ST__DynamicCast(const STRoot *p) {
			m_T = p == 0 ? 0 : (T)(p->IsA(((T)0)->GetSTI()->GetClassId())); }
		operator T () { return m_T; }
	private:
		T m_T;
	};  

#endif

#endif // __st_root_h__
