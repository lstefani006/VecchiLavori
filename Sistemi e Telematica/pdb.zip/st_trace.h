#ifndef __ST_TRACE_H__
#define __ST_TRACE_H__

class STTrace
{
public:
	STTrace(const char *f, int l, const char *m);
	~STTrace();

	void PrintStack() const;

protected:
	const char *m_msg;
	const STTrace *m_pPrevious;

	static const STTrace *S_pLast;
};


#ifndef ST_TRACE_DISABLE
#	define ST_TRACE(a) STTrace __sttrace__(__FILE__, __LINE__, a)
#else
#	define ST_TRACE(a) ((void)0)
#endif


#endif
