#include <st_dbnew.h>
#include "st_stru.h"
#include "st_err.h"
#include "libdb_it.lnh"



#if defined(__DECCXX) && !defined(NO_TEMPLATES)
#pragma define_template STTSlist<STElemento *>
#pragma define_template STTSlistIterator<STElemento *>
#pragma define_template STTSlist<DbVal *>
#pragma define_template STTSlistIterator<DbVal *>
#pragma define_template STTVect<WordKey>
#pragma define_template STTVect<RWCString>
#endif
 
//////////////////////////////////////////////////////////////////////////////
//                        CLASSE STChiave
//////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(STChiave, STRoot)
STImplementAssignClone(STChiave)

#ifndef NO_TEMPLATES
	STImplementClassInfo1(STTSlist<DbVal *>, STSlist)
#else
	STImplementClassInfo1(STTSlist(P_DbVal), STSlist)
	implement(STTSlist, P_DbVal)
	implement(STTSlistIterator, P_DbVal)
	implement(STTVect, STDizWordKey)
	implement(STTVect, RWCString)
#endif


STChiave::STChiave(const STChiave &r)
{
   m_ListaCampi = r.m_ListaCampi;
}

void STChiave::operator = (const STChiave& r)
{
   m_ListaCampi = r.m_ListaCampi;
}

int STChiave::STIsEqual(const STRoot *p) const
{
   STChiave *ps = DynamicCast(STChiave*, p);
   if (ps == 0)
      return 0;

   return (m_ListaCampi.STIsEqual(&ps->m_ListaCampi));
}

void STChiave::AddCampo(const DbVal *nuovoCampo)
{
   // Aggiunge un campo in coda alla lista.
   m_ListaCampi.AddTail(nuovoCampo->STClone());
}

const DbVal* STChiave::GetCampo(int idx) const
// La numerazione dei campi della lista parte da 1 e non da 0.
{
#ifndef NO_TEMPLATES
   STTSlistIterator<DbVal *> it(m_ListaCampi);
#else
   STTSlistIterator(P_DbVal) it(m_ListaCampi);
#endif
   DbVal *campo;

   for (int i = 0; i < idx; i++)
      campo = it();

   return campo;
}


//////////////////////////////////////////////////////////////////////////////
//                        CLASSE STElemento
//////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(STElemento, STRoot)
STImplementAssignClone(STElemento)

#ifndef NO_TEMPLATES
	static __dummy(class STTSlist<STElemento *>);
	STImplementClassInfo1(STTSlist<STElemento *>, STSlist)
#else
	STImplementClassInfo1(STTSlist(P_STElemento), STSlist)
	implement(STTSlist, P_STElemento)
	implement(STTSlistIterator, P_STElemento)
#endif


STElemento::STElemento()
{
   // m_Chiave viene costruito per default come una lista vuota
   m_pDescrizione = NULL;
}

STElemento::STElemento(const STElemento &r)
{
   m_Chiave       = r.m_Chiave;
   m_pDescrizione = DynamicCast(DbString *,  r.m_pDescrizione->STClone());
}

STElemento::STElemento(const STChiave& Chiave, const DbString *pDescrizione)
{
   m_Chiave       = Chiave;
   m_pDescrizione = DynamicCast(DbString *,  pDescrizione->STClone());
}

STElemento::~STElemento()
{
   // m_Chiave non e' un puntatore
   STDelete m_pDescrizione;
}

void STElemento::operator = ( const STElemento& r)
{
   // m_Chiave non e' un puntatore
   STDelete m_pDescrizione;
   
   m_Chiave       = r.m_Chiave;
   m_pDescrizione = DynamicCast(DbString *,  r.m_pDescrizione->STClone());
}

int STElemento::STIsEqual(const STRoot *p) const
{
   STElemento *ps = DynamicCast(STElemento *, p);
   if (ps == 0)
      return 0;
   
   return m_Chiave.STIsEqual(&ps->m_Chiave) &&
          m_pDescrizione->STIsEqual(ps->m_pDescrizione);
}

int STElemento::SortCompare( const STRoot *elemento1, const STRoot *elemento2)
{
   STElemento *el1 = DynamicCast( STElemento*, elemento1);
   STElemento *el2 = DynamicCast( STElemento*, elemento2);
 
   ST_COND_APPL( el1 != NULL && el2 != NULL, "Tipo diverso da STElemento");

   RWCString descr1 = el1->GetDescrizione()->UsrPrint();
   RWCString descr2 = el2->GetDescrizione()->UsrPrint();

   if ( descr1 > descr2 ) return 1;
   
   else if ( descr1 < descr2 ) return -1;

   else return 0;
}

int STElemento::RicercaChiaveEtCreaDescrizione( 
#ifndef NO_TEMPLATES
                                    const STTSlist<STElemento*> &listaElementi,
#else
				    const STTSlist(P_STElemento) &listaElementi,
#endif
                                    const STChiave &chiave,
                                    DbString* &descrizione)
{
   // Attenzione: metodo provvisorio. Ricerca l'elemento di chiave stabilita 
   // all'interno di una lista di elementi e valorizza la descrizione passata
   // come reference.

#ifndef NO_TEMPLATES
   STTSlistIterator<STElemento*> it( listaElementi);
#else
   STTSlistIterator(P_STElemento) it( listaElementi);
#endif

   STElemento* nextElemento = NULL;

   RWCString codice;

   while ( nextElemento = it() )
  
      if ( nextElemento->GetChiave().STIsEqual( &chiave) )
      {
         descrizione = STNew DbString( *nextElemento->GetDescrizione());
         return 1;
      }
   descrizione = NULL;
   return 0;
}

int STElemento::RicercaDescrizioneEtCreaChiave(
#ifndef NO_TEMPLATES
                                    const STTSlist<STElemento*> &listaElementi,
#else
				    const STTSlist(P_STElemento) &listaElementi,
#endif
                                    const DbString* descrizione,
                                    STChiave &chiave)
{
   // Attenzione: metodo provvisorio. Ricerca l'elemento di descrizione stabilita
   // all'interno di una lista di elementi e valorizza la chiave passata
   // come reference.
#ifndef NO_TEMPLATES
   STTSlistIterator<STElemento*> it( listaElementi);
#else
   STTSlistIterator(P_STElemento) it( listaElementi);
#endif

   STElemento* nextElemento = NULL;

   while ( nextElemento = it() )

      if ( nextElemento->GetDescrizione()->STIsEqual( descrizione) )
      {
         chiave = nextElemento->GetChiave();
         return 1;
      }
   return 0;
}



//////////////////////////////////////////////////////////////////////////////
//                        CLASSE STIndirizzo
//////////////////////////////////////////////////////////////////////////////
STImplementClassInfo1(STIndirizzo, STRoot)
STImplementAssignClone(STIndirizzo)

STIndirizzo::STIndirizzo()
   : m_Via(VIA_LEN), m_CAP(CAP_LEN),
     m_Citta(CITTA_LEN), m_Provincia(PROV_LEN)
{
   m_Via       = "";
   m_CAP       = "";
   m_Citta     = "";
   m_Provincia = "";
}

STIndirizzo::STIndirizzo(const STIndirizzo &r)
   : m_Via(VIA_LEN), m_CAP(CAP_LEN),
     m_Citta(CITTA_LEN), m_Provincia(PROV_LEN)
{
   m_Via       = r.m_Via;
   m_CAP       = r.m_CAP;
   m_Citta     = r.m_Citta;
   m_Provincia = r.m_Provincia;
}

void STIndirizzo::operator = ( const STIndirizzo& r)
{
   m_Via       = r.m_Via;
   m_CAP       = r.m_CAP;
   m_Citta     = r.m_Citta;
   m_Provincia = r.m_Provincia;
}

int STIndirizzo::STIsEqual(const STRoot *p) const
{
   STIndirizzo *ps = DynamicCast(STIndirizzo*, p);
   if (ps == 0)
      return 0;

   return (m_Via.STIsEqual(&ps->m_Via) &&
           m_CAP.STIsEqual(&ps->m_CAP) &&
           m_Citta.STIsEqual(&ps->m_Citta) &&
           m_Provincia.STIsEqual(&ps->m_Provincia) );
}





////////////////////////////////////////////////////////////////////////

STWordKeyList::STWordKeyList()
{
}


void STWordKeyList::InsertKey( WordKey theKey)
{
   Append( theKey);   
}

void STWordKeyList::InsertKeyPosition( WordKey theKey, int thePosition)
{
   Append( theKey);    // append fittizio per la riallocazione del vettore

   // scalamento in avanti dei valori preesistenti

   for (int i = Size() - 1; i > thePosition; i--)
      (*this)[i] = (*this)[i - 1];

   (*this)[thePosition] = theKey;
}

WordKey STWordKeyList::GetKeyFromString( Dizionario *theDiz, 
                                         RWCString   theString) const
{
   for ( int i = 0 ; i< Size() ; i++)
   
      if ( theDiz->GetWord( (*this)[i]) == theString)
    
         return (*this)[i];

   ST_COND_APPL( 0, "Ricerca stringa flag fallita!");

   return MSG_LIBDB_NULL;
}


//////////////////////////////////////////////////////////////////////////

STFlagValues::STFlagValues()
{
}

void STFlagValues::operator = ( const STFlagValues &r)
{
   itsDbFormats  = r.itsDbFormats;
   itsKeyFormats = r.itsKeyFormats;
}

void STFlagValues::InsertFlag( RWCString theDbFormat, WordKey theKeyFormat)
{
   itsDbFormats.Append( theDbFormat);
   itsKeyFormats.Append( theKeyFormat);
}

RWCString STFlagValues::GetDbFormat( WordKey theKeyFormat) const
{
   for ( int i = 0 ; i< itsKeyFormats.Size() ; i++)
      if ( itsKeyFormats[i] == theKeyFormat)
         return itsDbFormats[i];
   
   ST_COND_APPL( 0, "Ricerca chiave flag fallita!");
   return RWCString();
}

WordKey STFlagValues::GetKeyFormat( RWCString theDbFormat) const
{
   for ( int i = 0 ; i< itsDbFormats.Size() ; i++)
      if ( itsDbFormats[i] == theDbFormat)
         return itsKeyFormats[i];
 
   return MSG_LIBDB_NULL;
}


STWordKeyList STFlagValues::GetFlagKeys(void) const
{
   STWordKeyList theKeyList;

   if ( itsKeyFormats.Size() < 1 )

      ST_COND_APPL( 0, "Numero scelte flag = 0!");

   for ( int i = 0 ; i< itsKeyFormats.Size() ; i++)

      theKeyList.InsertKey( itsKeyFormats[i]);

   return theKeyList;
}


// ritorna la stringa per l'utente corrispondente al codice 
RWCString STFlagValues::GetUsrValue(Dizionario *pDiz, const DbVal *pCodice)
{
	return pDiz->GetWord(GetKeyFormat(pCodice->UsrPrint()));
}

// partendo da cio` che vede l'utente ritorna il valore del DB
RWCString STFlagValues::GetDbValue(Dizionario *pDiz, const RWCString &strUser)
{
   for ( int i = 0 ; i< itsKeyFormats.Size() ; i++)
      if ( pDiz->GetWord(itsKeyFormats[i]) == strUser)
         return itsDbFormats[i];

   ST_COND_APPL(0, "non trovo la scelta nella lista");
   return RWCString();
}
