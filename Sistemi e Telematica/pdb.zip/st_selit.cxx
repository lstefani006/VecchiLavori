#include <st_dbnew.h>
#include <iostream.h>

#include "st_err.h"
#include "st_dbxx.h"
#include "st_selit.h"


STDbSelectIterator::STDbSelectIterator(STDbTransaction &tr, const char *ClassName, const STDbWhereLogical &w, STSelectType st)
{
	m_pDbTransaction = &tr;
	m_pStrWhere      = strdup(w.StrWhere(tr));


#ifndef NO_TEMPLATES
	STTVect<DbVal *> vw = w.ValWhere();
#else
	STTVect(P_DbVal) vw = w.ValWhere();
#endif

	for (int i = 0; i < vw.Size(); i++)
		m_ValWhere.Append(DynamicCast(DbVal *, vw[i]->STClone()));

	/* crea la lista delle classi da considerare */
	m_bFirst         = 1;

	m_pDbStmt        = 0;
	m_DbError        = ST_DB_OK;
	m_SelectType     = st;

	m_ClassName      = ClassName;
}


STDbSelectIterator::~STDbSelectIterator()
{
	STDelete m_pDbStmt;

	free((char*)m_pStrWhere);

	for (int i = 0; i < m_ValWhere.Size(); i++)
		STDelete m_ValWhere[i];
}

STDbBase * STDbSelectIterator::operator () (STDbBase *pSTDbBase)
{
	const STDbClassInfo &theCI = STDbG::DbGetClassInfo(m_ClassName);

	if (m_bFirst)
	{
		RWCString str(RWSize_T(2048));

		str = "select ";
		for (int i = 0; i < theCI.Map().Size(); i++)
		{
			if (i > 0)
				str += ", ";
			str += theCI.Map()[i].Col();
		}

		str += " from ";
		str += theCI.Map().Table();

		str += " where ";
		str += m_pStrWhere;

		if (m_pDbTransaction->GetDbType() == ST_DB_ORACLE)
		{
			if (m_SelectType == STSelectForUpdate)
				str += " for update";
			else
				if (m_SelectType == STSelectForUpdateNoWait)
					str += " for update nowait";
		}
		else
		if (m_pDbTransaction->GetDbType() == ST_DB_ODBC)
		{
		}

		m_pDbStmt = STNew STDbStmt(*m_pDbTransaction);
		m_DbError = m_pDbStmt->Parse(str, m_ValWhere);

		if (m_DbError != ST_DB_OK)
			return NULL;
	}

	/* creo l'oggetto */
	STDbBase *pA;
	
	if (pSTDbBase == NULL)
		pA = STDbG::DbCreateObject(m_ClassName);
	else
		pA = pSTDbBase;

	/* faccio il binding */
	for (int i = 0; i < theCI.Map().Size(); i++)
	{
		const STDbColMap &theDbColMap = (theCI.Map()[i]);
		m_pDbStmt->Bind((DbVal *)pA->GetDbCol(theDbColMap.Offset()));
	}

	/* eseguo lo statment */
	if (m_bFirst == 1)
		m_DbError = m_pDbStmt->Exec();

	m_bFirst = 0;

	/* trovo il record */
	if (m_DbError == ST_DB_OK)
		m_DbError = m_pDbStmt->Fetch();


	if (m_DbError != ST_DB_OK)
	{
		if (pSTDbBase == NULL)
			STDelete pA;
		pA = NULL;
	}

	if (m_DbError == ST_DB_NOT_FOUND)
	{
		STDelete m_pDbStmt;
		m_pDbStmt = NULL;

		return NULL;
	}


	if (m_DbError == ST_DB_OK)
		pA->SetBack();

	ST_COND_LIBR(m_DbError == ST_DB_NOT_FOUND || m_DbError == ST_DB_OK || m_DbError == ST_DB_LOCK, "STDbSelectIterator::operator()() - internal error");
	return pA;
}
