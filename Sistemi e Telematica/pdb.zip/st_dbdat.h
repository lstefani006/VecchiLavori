/******************************************************************************

	Copyright (c)  1995


	File Name:            st_dbdat.h

*****************************************************************************/

#ifndef __DATATYPE_H__
#define __DATATYPE_H__

#include "st_root.h"
#include "st_diz.h"
#include "st_valid.h"
#include "st_db.h"

#include <rw/cstring.h>
#include <rw/rwtime.h>
#include <rw/rwdate.h>

////////////////////////////////////////////////////////////////////////////////

#define DEFAULT_MAX_LENGTH  1000
#define ORA_SOLARE	'A'
#define ORA_LEGALE	'B'

class DbVal : public virtual STRoot
{
public:
	STDefineClassInfo

	enum NullValues { Null, NotNull };

private:
	DbVal();           // -- NotNull

public:
	DbVal(NullValues);

	DbVal(const DbVal &);
	void operator = (const DbVal &r);
	~DbVal();


	virtual STRoot   *    STCreate()                  const = 0;
	virtual STRoot   *    STClone()                   const = 0;
	virtual void          STAssign(const STRoot *)          = 0;
	virtual int           STIsEqual(const STRoot *)   const = 0;
	virtual int           STCompareTo(const STRoot *) const = 0;

	/* user dependent functions */
	virtual STDizWordKey  UsrValidate(RWCString &strToValidate) const = 0;
	virtual RWCString     UsrPrint() const = 0;
	virtual void          UsrSet(const RWCString &strToSet) = 0;
	virtual int           UsrMaxLength() const;

	virtual void          SetValidator(STValidator *);
	virtual void          ResetValidator();
	virtual STValidator * GetValidator() const;
	virtual void          SetMask(const char *);
	virtual const char *  GetMask() const;


	// db dependent functions for Db
	virtual int          GetDbSize    () const = 0;
	virtual const void * GetDbAddress () const = 0;

private:
	// serve per settare il campo a null
	friend class DbStmtOdbc;
	friend class DbStmtOracle;
	virtual	void PostFetchNull(int bNull);


public:
	// ANSI SQL compliant functions
	virtual RWCString    DbPrint      (STDbType) const = 0;
	virtual RWCString    GetDbType    () const = 0;  /* es return CHAR(4) */

	// funzione usata per sapere se il campo puo' contenere campi NULL
	int                  CanBeNull() const { return m_bCanBeNull; }

	// funzione per settare a NULL o a NOT NULL un campo
	virtual void         SetNull      (int bNull);

	// funzione per sapere se un campo e' NULL o contiene un valore
	virtual int          IsNull       () const;
	                               
	// non usare questa funzione (usata da Bind)
	int *                GetNull() { return &m_bNull; }

	// funzione per settare a valore NULL o NOT NULL il campo
	virtual void         Reset(NullValues) = 0;
protected:
	STValidator *m_pSTValidator;
	
private:
	int          m_bNull;
	int          m_bCanBeNull;
	RWCString    m_strMask;
};


////////////////////////////////////////////////////////////////////////////////

class DbString : public DbVal
{
public:
	STDefineClassInfo
	STDeclareAssignClone(DbString)

private:
	DbString();

public: 
	DbString(DbVal::NullValues, int nMaxLen, const char *pcStr = 0);
	DbString(int nMaxLen, const char *pcStr = 0);   // NULL
	DbString(const DbString &);
	~DbString();

	void operator = (const char *pcStr);
	void operator = (const DbString &r);
	void operator = (const RWCString &r) { operator = (r.data()); }

	char & operator [] (int i)       { return m_p[i]; }
	char   operator [] (int i) const { return m_p[i]; }

	operator const char* () const { return m_p; }

	int length() const { return strlen(m_p); }
	const char * data() const { return m_p; }

	virtual STDizWordKey UsrValidate(RWCString &strToValidate) const;
	virtual RWCString    UsrPrint() const;
	virtual void         UsrSet(const RWCString &strToSet);
	virtual int          UsrMaxLength() const;
	virtual int          STCompareTo(const STRoot *) const;

	virtual int          IsNull() const;
	int                  isNull() const { return IsNull(); }

	virtual void         SetNull(int bNull);

	virtual void         Reset(NullValues);

	RWCString            operator () (int start, int len) const {
		return RWCString(m_p + start, len);
	}

	virtual ostream & STDebug(ostream &) const;

public:
	virtual int          GetDbSize    () const;
	virtual const void * GetDbAddress () const;
	virtual RWCString    DbPrint      (STDbType) const;
	virtual RWCString    GetDbType    () const;
	void KillLastBlanks();

protected:
	int m_nMaxLen;
	char *m_p;

};

int operator == (const DbString &a, const RWCString &c);
int operator != (const DbString &a, const RWCString &c);
int operator >  (const DbString &a, const RWCString &c);
int operator >= (const DbString &a, const RWCString &c);
int operator <  (const DbString &a, const RWCString &c);
int operator <= (const DbString &a, const RWCString &c);

int operator == (const DbString &a, const DbString &c);
int operator != (const DbString &a, const DbString &c);
int operator >  (const DbString &a, const DbString &c);
int operator >= (const DbString &a, const DbString &c);
int operator <  (const DbString &a, const DbString &c);
int operator <= (const DbString &a, const DbString &c);

int operator == (const DbString &a, const char *c);
int operator != (const DbString &a, const char *c);
int operator >  (const DbString &a, const char *c);
int operator >= (const DbString &a, const char *c);
int operator <  (const DbString &a, const char *c);
int operator <= (const DbString &a, const char *c);

inline ostream & operator << (ostream &r, const DbString &s)
{
	return r << s.data();
}

inline istream & operator >> (istream &r, DbString &s)
{
	return r >> (&s[0]);
}

////////////////////////////////////////////////////////////////////////////////

class DbInt : public DbVal
{
public:
	STDefineClassInfo
	STDeclareAssignClone(DbInt)
private:
	DbInt();

public:
	DbInt(DbVal::NullValues, int nDigits, Int32 = 0);
	DbInt(int nDigits, Int32 = 0);
	DbInt(const DbInt &);
	void operator = (const DbInt &);

	void operator = (Int32 nValue);
	operator Int32 () const { return m_nValue; }

	virtual STDizWordKey UsrValidate(RWCString &strToValidate) const;
	virtual RWCString    UsrPrint() const;
	virtual void         UsrSet(const RWCString &strToSet);
	virtual int          UsrMaxLength() const;
	virtual int          STCompareTo(const STRoot *) const;

	virtual void         Reset(NullValues);

	virtual ostream & STDebug(ostream &) const;
public:
	virtual int          GetDbSize    () const;
	virtual const void * GetDbAddress () const;
	virtual RWCString    DbPrint      (STDbType) const;
	virtual RWCString    GetDbType    () const;

protected:
	Int32 m_nValue;
	int   m_nDigits;
};

inline int operator == (const DbInt &a, Int32 c) { return Int32 (a) == c; }
inline int operator != (const DbInt &a, Int32 c) { return Int32 (a) != c; }
inline int operator >  (const DbInt &a, Int32 c) { return Int32 (a) >  c; }
inline int operator >= (const DbInt &a, Int32 c) { return Int32 (a) >= c; }
inline int operator <  (const DbInt &a, Int32 c) { return Int32 (a) <  c; }
inline int operator <= (const DbInt &a, Int32 c) { return Int32 (a) <= c; }

inline int operator == (const DbInt &a, const DbInt &c) { return Int32 (a) == Int32 (c); }
inline int operator != (const DbInt &a, const DbInt &c) { return Int32 (a) != Int32 (c); }
inline int operator >  (const DbInt &a, const DbInt &c) { return Int32 (a) >  Int32 (c); }
inline int operator >= (const DbInt &a, const DbInt &c) { return Int32 (a) >= Int32 (c); }
inline int operator <  (const DbInt &a, const DbInt &c) { return Int32 (a) <  Int32 (c); }
inline int operator <= (const DbInt &a, const DbInt &c) { return Int32 (a) <= Int32 (c); }

////////////////////////////////////////////////////////////////////////////////

class DbShort : public DbVal
{
public:
	STDefineClassInfo
	STDeclareAssignClone(DbShort)

private:
	DbShort();

public:
	DbShort(DbVal::NullValues, int nDigits, Int16 = 0);
	DbShort(int nDigits, Int16 = 0);
	DbShort(const DbShort &);
	void operator = (const DbShort &);

	void operator = (Int16 nValue);
	operator Int16 () const { return m_nValue; }

	virtual STDizWordKey UsrValidate(RWCString &strToValidate) const;
	virtual RWCString    UsrPrint() const;
	virtual void         UsrSet(const RWCString &strToSet);
	virtual int          UsrMaxLength() const;
	virtual int          STCompareTo(const STRoot *) const;

	virtual void         Reset(NullValues);

	virtual ostream & STDebug(ostream &) const;
public:
	virtual int          GetDbSize    () const;
	virtual const void * GetDbAddress () const;
	virtual RWCString    DbPrint      (STDbType) const;
	virtual RWCString    GetDbType    () const;

protected:
	Int16 m_nValue;
	int   m_nDigits;
};

inline int operator == (const DbShort &a, Int16 c) { return Int16 (a) == c; }
inline int operator != (const DbShort &a, Int16 c) { return Int16 (a) != c; }
inline int operator >  (const DbShort &a, Int16 c) { return Int16 (a) >  c; }
inline int operator >= (const DbShort &a, Int16 c) { return Int16 (a) >= c; }
inline int operator <  (const DbShort &a, Int16 c) { return Int16 (a) <  c; }
inline int operator <= (const DbShort &a, Int16 c) { return Int16 (a) <= c; }

inline int operator == (const DbShort &a, const DbShort &c) { return Int16 (a) == Int16 (c); }
inline int operator != (const DbShort &a, const DbShort &c) { return Int16 (a) != Int16 (c); }
inline int operator >  (const DbShort &a, const DbShort &c) { return Int16 (a) >  Int16 (c); }
inline int operator >= (const DbShort &a, const DbShort &c) { return Int16 (a) >= Int16 (c); }
inline int operator <  (const DbShort &a, const DbShort &c) { return Int16 (a) <  Int16 (c); }
inline int operator <= (const DbShort &a, const DbShort &c) { return Int16 (a) <= Int16 (c); }

////////////////////////////////////////////////////////////////////////////////

class DbChar : public DbVal
{
public:
	STDefineClassInfo
	STDeclareAssignClone(DbChar)

	DbChar(DbVal::NullValues, char = ' ');
	DbChar(char = ' ');
	DbChar(const DbChar &);
	void operator = (const DbChar &);

	void operator = (char cValue);
	operator const char () const { return m_cValue[0]; }

	virtual STDizWordKey UsrValidate(RWCString &strToValidate) const;
	virtual RWCString    UsrPrint() const;
	virtual void         UsrSet(const RWCString &strToSet);
	virtual int          UsrMaxLength() const;
	virtual int          STCompareTo(const STRoot *) const;

	virtual void         Reset(NullValues);

	virtual ostream & STDebug(ostream &) const;
public:
	virtual int          GetDbSize    () const;
	virtual const void * GetDbAddress () const;
	virtual RWCString    DbPrint      (STDbType) const;
	virtual RWCString    GetDbType    () const;

protected:
	char m_cValue[2];
};

inline int operator == (const DbChar &a, char c) { return char (a) == c; }
inline int operator != (const DbChar &a, char c) { return char (a) != c; }

inline int operator == (const DbChar &a, const DbChar &c) { return char (a) == char (c); }
inline int operator != (const DbChar &a, const DbChar &c) { return char (a) != char (c); }
inline int operator >= (const DbChar &a, const DbChar &c) { return char (a) >= char (c); }
inline int operator > (const DbChar &a, const DbChar &c) { return char (a) > char (c); }
inline int operator <= (const DbChar &a, const DbChar &c) { return char (a) <= char (c); }
inline int operator < (const DbChar &a, const DbChar &c) { return char (a) < char (c); }

////////////////////////////////////////////////////////////////////////////////

class DbDouble : public DbVal
{
public:
	STDefineClassInfo
	STDeclareAssignClone(DbDouble)

private:
	DbDouble();

public:
	DbDouble(DbVal::NullValues, int sz1, int sz2, double theVal = 0.0);
	DbDouble(int sz1, int sz2, double theVal = 0.0);
	DbDouble(const DbDouble &);
	void operator = (const DbDouble &);

	void operator = (double dValue);
	operator const double () const { return m_dValue; }

	virtual STDizWordKey UsrValidate(RWCString &strToValidate) const;
	virtual RWCString    UsrPrint() const;
	virtual void         UsrSet(const RWCString &strToSet);
	virtual int          UsrMaxLength() const;
	virtual int          STCompareTo(const STRoot *) const;

	virtual void         Reset(NullValues);

	virtual ostream & STDebug(ostream &) const;
public:
	virtual int          GetDbSize    () const;
	virtual const void * GetDbAddress () const;
	virtual RWCString    DbPrint      (STDbType) const;
	virtual RWCString    GetDbType    () const;

	int                  Sz1() const { return m_nSize1; }
	int                  Sz2() const { return m_nSize2; }

protected:
	double m_dValue;
	int    m_nSize1;
    int    m_nSize2;
};

inline int operator == (const DbDouble &a, double c) { return double (a) == c; }
inline int operator != (const DbDouble &a, double c) { return double (a) != c; }
inline int operator >  (const DbDouble &a, double c) { return double (a) >  c; }
inline int operator >= (const DbDouble &a, double c) { return double (a) >= c; }
inline int operator <  (const DbDouble &a, double c) { return double (a) <  c; }
inline int operator <= (const DbDouble &a, double c) { return double (a) <= c; }

inline int operator == (const DbDouble &a, const DbDouble &c) { return double (a) == double (c); }
inline int operator != (const DbDouble &a, const DbDouble &c) { return double (a) != double (c); }
inline int operator >  (const DbDouble &a, const DbDouble &c) { return double (a) >  double (c); }
inline int operator >= (const DbDouble &a, const DbDouble &c) { return double (a) >= double (c); }
inline int operator <  (const DbDouble &a, const DbDouble &c) { return double (a) <  double (c); }
inline int operator <= (const DbDouble &a, const DbDouble &c) { return double (a) <= double (c); }

////////////////////////////////////////////////////////////////////////////////

/*
 * classe per memorizzare l'ora di oggi o di un giorno specificato
 */
class DbTS : public DbVal, public RWTime
{
public:
	STDefineClassInfo
	STDeclareAssignClone(DbTS)

	DbTS(DbVal::NullValues);
	DbTS();

	DbTS(int YY, int MM, int DD, int hh, int mm, int ss = 0);
	DbTS(unsigned long seconds);
	DbTS(unsigned hour, unsigned minute, unsigned seconds = 0,
			 const RWZone& zone = RWZone::local());
	DbTS(const RWDate &,
			 unsigned hour, unsigned minute, unsigned seconds = 0,
			 const RWZone& zone = RWZone::local());
	DbTS(const RWDate&, const RWCString& strTime,
			 const RWZone& zone = RWZone::local(),
			 const RWLocale& locale = RWLocale::global());
	DbTS(const struct tm *, const RWZone& = RWZone::local());
	DbTS(const RWTime &);
	DbTS(const DbTS &);

	void operator = (const RWTime &);
	void operator = (const DbTS &);

	virtual void SetNull(int bNull);

	virtual void         Reset(NullValues);

	static DbTS Now() { return DbTS(now()); }

	virtual STDizWordKey UsrValidate(RWCString &strToValidate) const;
	virtual RWCString    UsrPrint() const;
	virtual void         UsrSet(const RWCString &strToSet);
	virtual int          STCompareTo(const STRoot *) const;

	virtual ostream & STDebug(ostream &) const;
public:
	virtual int          GetDbSize    () const;
	virtual const void * GetDbAddress () const;
	virtual RWCString    DbPrint      (STDbType) const;
	virtual RWCString    GetDbType    () const;
};


inline ostream & operator << (ostream &r, const DbTS &s)
{
	return r << RWTime(s);
}

extern DbTS NullDate;

inline int operator == (const DbTS &a, const RWTime &c) { return RWTime (a) == c; }
inline int operator != (const DbTS &a, const RWTime &c) { return RWTime (a) != c; }
inline int operator >  (const DbTS &a, const RWTime &c) { return RWTime (a) >  c; }
inline int operator >= (const DbTS &a, const RWTime &c) { return RWTime (a) >= c; }
inline int operator <  (const DbTS &a, const RWTime &c) { return RWTime (a) <  c; }
inline int operator <= (const DbTS &a, const RWTime &c) { return RWTime (a) <= c; }

inline int operator == (const DbTS &a, const DbTS &c) { return RWTime (a) == RWTime (c); }
inline int operator != (const DbTS &a, const DbTS &c) { return RWTime (a) != RWTime (c); }
inline int operator >  (const DbTS &a, const DbTS &c) { return RWTime (a) >  RWTime (c); }
inline int operator >= (const DbTS &a, const DbTS &c) { return RWTime (a) >= RWTime (c); }
inline int operator <  (const DbTS &a, const DbTS &c) { return RWTime (a) <  RWTime (c); }
inline int operator <= (const DbTS &a, const DbTS &c) { return RWTime (a) <= RWTime (c); }

////////////////////////////////////////////////////////////////////////////////


class DbRaw : public DbVal
{
public:
	STDefineClassInfo
	STDeclareAssignClone(DbRaw)

private:
	DbRaw();

public:
	DbRaw(DbVal::NullValues, int sz);
	DbRaw(int sz);
	DbRaw(const DbRaw &);
	void  operator = (const DbRaw &);
	~DbRaw();

	unsigned char * GetBuff() const { return m_pBuff; }
	int             GetSize() const { return m_nSize; }

	void            SetBit(int i, int nValue);
	int             GetBit(int i) const;
	virtual void    Reset(NullValues);

	/* funzioni non usate */
	virtual STDizWordKey UsrValidate(RWCString &strToValidate) const;
	virtual RWCString    UsrPrint() const;
	virtual void         UsrSet(const RWCString &strToSet);
	virtual int          STCompareTo(const STRoot *) const;

	virtual ostream & STDebug(ostream &) const;
public:
	unsigned char *m_pBuff;
	int            m_nSize;

	virtual int          GetDbSize    () const;
	virtual const void * GetDbAddress () const;
	virtual RWCString    DbPrint      (STDbType) const;
	virtual RWCString    GetDbType    () const;
};




#endif
