#ifndef __ST_ERR_H__
#define __ST_ERR_H__

// stampa un messaggio di errore, genera il core ed esce
// funzione da chiamare il caso di errore applicativo
// inizialmente e' NULL --> da settare nel main
extern void (*G_pfError)(const char *);
void STError(const char *s, ...);

// stampa un messaggio e ritorna
void STDebug(const char *s, ...);

/////////////////////////////////////////////////////////////////////

#define STDebugStack(pcMsg) __STDebugStack(pcMsg, __FILE__, __LINE__)
#define STDebugStackTrace() __STDebugStack::Trace()


class __STDebugStack
{
public:
	__STDebugStack(const char *pcMsg, const char *pcFile, int nLine);
	~__STDebugStack() { nTop -= 1; }

	static void Trace();

protected:
	#define STDebugStack_SIZE 100
	static int         nTop;
	static int         aLine[STDebugStack_SIZE];
	static const char *aFile[STDebugStack_SIZE];
	static const char *aMsg[STDebugStack_SIZE];
};

#endif
