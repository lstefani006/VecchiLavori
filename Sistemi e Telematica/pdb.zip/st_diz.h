/********************************************************************

   Copyright (c) 1995

   File Name:		STDiz.h
   Author:          Marco Cresta
   Date:            2/3/95

   Class:	        STDizionario

 ********************************************************************/

#ifndef __ST_DIZ_H__
#define __ST_DIZ_H__

#include <rw/cstring.h>
#include <rw/hashdict.h>
#include <st_tvect.h>

#ifdef NO_TEMPLATES
	#ifndef D_STTVectRWCString
		#define D_STTVectRWCString
		declare(STTVect, RWCString);
	#endif
#endif

extern class STDizionario *G_Diz;
extern int MSG_LIBDB_NULL;

class STDizWordKey
{
public:
	STDizWordKey() : m_a(1) { m_w = MSG_LIBDB_NULL; }
	STDizWordKey(const STDizWordKey &r) : m_a(r.m_a) { m_w = r.m_w; }
	STDizWordKey(int r) : m_a(1) { m_w = r; }
	void operator = (const STDizWordKey &r) { m_a = r.m_a; m_w = r.m_w; }
	void operator = (int r) { m_a.Reset(); m_w = r; }
	void AddMsg(const RWCString &m) { m_a.Append(m); }

	operator int & () { return m_w; }
	operator int () const { return m_w; }

	int IsOk() const { return m_w == MSG_LIBDB_NULL; }
	int Get() const { return m_w; }

#ifndef NO_TEMPLATES
	STTVect<RWCString> GetA() const { return m_a; }
#else
	STTVect(RWCString) GetA() const { return m_a; }
#endif

protected:
	int                  m_w;

#ifndef NO_TEMPLATES
	STTVect<RWCString>   m_a;
#else
	STTVect(RWCString)   m_a;
#endif
};

inline int operator == (const STDizWordKey &a, const STDizWordKey &b) { return a.Get() == b.Get(); }
inline int operator != (const STDizWordKey &a, const STDizWordKey &b) { return a.Get() != b.Get(); }
inline int operator == (const STDizWordKey &a, int b) { return a.Get() == b; }
inline int operator != (const STDizWordKey &a, int b) { return a.Get() != b; }

class STDizionario
{
public:
	STDizionario();
	~STDizionario();

	RWBoolean Load(const RWCString &theDictionaryFile);

	RWCString GetWord(const STDizWordKey &aKey) const;
	RWCString GetLanguage(void) const;

protected:
	RWBoolean InsertWord(const STDizWordKey &aKey, const RWCString &aWord);
	RWBoolean RemoveWord(const STDizWordKey &aKey);

private:
	RWCString theLanguage;
	RWHashDictionary *theDictionary;
};

// definizioni per mantenere la compatibilita' nella versione precedente
typedef STDizionario Dizionario;
#define WordKey STDizWordKey 

#endif
