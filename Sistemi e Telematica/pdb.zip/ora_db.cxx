#ifdef ST_LIBDB_ORACLE



#include <st_dbnew.h>
#include <stdlib.h>
#include <iostream.h>
#include <strstream.h>
#include <rw/defs.h>

#include <st_err.h>
#include <st_dbdat.h>
#include <st_db.h>
#include "prtbl_d2.h"
#include "ora_db.h"
#include <ocidfn.h>
#include <strstream.h>
      

#ifdef DOS
	//#define INT_TYPE                 3
	#define NO_DATA_FOUND         1403
	#define VAR_NOT_IN_LIST       1007
#endif


#ifdef NO_TEMPLATES
	implement(STTVect, uchar7);
	implement(STTVect, sb2);
#endif

static const char * err_report(Lda_Def *, Cda_Def *cursor);
static const char * err_report(DbStmtOracle *);
static const char * err_report(DbConnectionOracle *);
static const char * err_report(DbTransactionOracle *);



/* in Oracle ogni transazione ha la sua connessione */
struct OraData
{
	enum { NotConnected, Used, Free } m_Status;
	Lda_Def                           m_lda;
	ub1                               m_hda[512];
	RWCString                         m_User;
	RWCString                         m_Passwd;

	OraData() { m_Status = NotConnected; }
};

// massimo numero di connessioni aperte contemporaneamente
#define MAX_ORA_TR 25
static OraData G_OraData[MAX_ORA_TR];

// numero massimo di connessioni aperte in stato Free
const static int G_MaxConnectionsFree = 1;

static int Open(const RWCString &l, const RWCString &p, int &r, Lda_Def *m_lda)
{
	for (int i = 0; i < MAX_ORA_TR; i++)
		if (G_OraData[i].m_Status == OraData::Free)
			if (l == G_OraData[i].m_User && p == G_OraData[i].m_Passwd)
			{
				G_OraData[i].m_Status = OraData::Used;
				r = 0;
				*m_lda = G_OraData[i].m_lda;
				return i;
			}

	for (i = 0; i < MAX_ORA_TR; i++)
		if (G_OraData[i].m_Status == OraData::NotConnected)
		{
			r = orlon(&G_OraData[i].m_lda,
					  G_OraData[i].m_hda,
					  (text *)(const char *)l, -1, 
					  (text *)(const char *)p, -1,
					  0);

			if (r == 0)
			{
				G_OraData[i].m_Status = OraData::Used;
				G_OraData[i].m_User = l;
				G_OraData[i].m_Passwd = p;
			}
			*m_lda = G_OraData[i].m_lda;
			return i;
		}

	ST_COND_LIBR(0, "too many transactions opened");
	return -1;
}

static void EndTr(int i, int bCommit, int &r, Lda_Def *m_lda)
{
	if (bCommit == 0)
		r = orol(&G_OraData[i].m_lda);
	else
		r = ocom(&G_OraData[i].m_lda);

	*m_lda = G_OraData[i].m_lda;
}

static void CloseAll()
{
	for (int i = 0; i < MAX_ORA_TR; i++)
		if (G_OraData[i].m_Status != OraData::NotConnected)
		{
			ologof(&G_OraData[i].m_lda);
			G_OraData[i].m_Status = OraData::NotConnected;
		}
}

void ForceClose(int i)
{
	ologof(&G_OraData[i].m_lda);
	G_OraData[i].m_Status = OraData::NotConnected;
}

static void Close(int i)
{
	G_OraData[i].m_Status = OraData::Free;

	// conto il massimo numero di connessioni in stato
	// Free e dealloco la connessione se viene superato il max
	int n = 0;
	for (int c = 0; c < MAX_ORA_TR; c++)
		if (G_OraData[c].m_Status == OraData::Free)
			if (++n > G_MaxConnectionsFree)
			{
				ForceClose(i);
				break;
			}
}

////////////////////////////////////////////////////////////////////////////////

DbConnectionOracle::DbConnectionOracle()
{
	m_DbError    = ST_DB_OK;
}

STDbError DbConnectionOracle::Login(const char *pcUser, const char *pcPasswd, const char *pcHost)
{
	/* mi logo e mi slogo subito */

	char aUser[100];
	strcpy(aUser, pcUser);
	if (pcHost != NULL && pcHost[0] != '\0')
	{
		strcat(aUser, "@");
		strcat(aUser, pcHost);
	}


	int r;
	Lda_Def m_lda;
	m_IndexOraData = Open(aUser, pcPasswd, r, &m_lda);
	{
	int r1;
	Lda_Def m_lda2;
	EndTr(m_IndexOraData, 0, r1, &m_lda2);
	ForceClose(m_IndexOraData);
	}

	/* traduzione errori */
	     if (r && m_lda.rc == 1017)  m_DbError = ST_DB_LOGIN_FAIL;
	else if (r && m_lda.rc == 1109)  m_DbError = ST_DB_NOT_AVAILABLE;
	else if (r && m_lda.rc == 1507)  m_DbError = ST_DB_NOT_AVAILABLE;
	else if (r && m_lda.rc == 1034)  m_DbError = ST_DB_NOT_AVAILABLE;

	else if (r && m_lda.rc == 12154) m_DbError = ST_DB_NOT_AVAILABLE;
	else if (r)                      m_DbError = ST_DB_ERROR;
	else                             m_DbError = ST_DB_OK;

	if (m_DbError < 0)
		ST_Throw(STDbException(m_DbError, err_report(this)));

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_LOGIN_FAIL, "DbConnectionOracle::Login() - internal error");
	return m_DbError;
}

STDbError DbConnectionOracle::Logout()
{
	ST_COND_APPL(m_DbError == ST_DB_OK, "DbConnectionOracle::Logout() - called with Login failed");
	return m_DbError;
}

DbConnectionOracle::~DbConnectionOracle()
{
	CloseAll();
}

RWCString DbConnectionOracle::GetParameterMarker(int i) const
{
	char b[10];
	ostrstream ss(b, sizeof(b));
	ss << ":" << i + 1 << ends;
	return b;
}

RWCString DbConnectionOracle::DbPrint(const DbVal *pDbVal) const
{
	if (pDbVal->IsNull())
		return RWCString("NULL");

	if (DynamicCast(DbString *, pDbVal))
	{
		DbString *pDbString = DynamicCast(DbString *, pDbVal);

		RWCString r("'");
		const char *p = *pDbString;

		while (*p)
		{
			if (*p == '\'')
				r.append(*p);
			r.append(*p);
			p++;
		}
		r.append("'");
		return r;
	}
	else if (DynamicCast(DbInt *, pDbVal))
	{
		DbInt *pDbInt = DynamicCast(DbInt *, pDbVal);
		char b[20];
		ostrstream s(b, sizeof(b));
		s << Int32(*pDbInt) << ends;
		return RWCString(b);
	}
	else if (DynamicCast(DbShort *, pDbVal))
	{
		DbShort *pDbShort = DynamicCast(DbShort *, pDbVal);
		char b[20];
		ostrstream s(b, sizeof(b));
		s << Int16(*pDbShort) << ends;
		return RWCString(b);
	}
	else if (DynamicCast(DbChar *, pDbVal))
	{
		DbChar *pDbChar = DynamicCast(DbChar *, pDbVal);
		const char c = *pDbChar;
		char b[20];
		ostrstream s(b, sizeof(b));
		s << "CHR(" << int(c) << ")" << ends;
		return RWCString(b);
	}
	else if (DynamicCast(DbDouble *, pDbVal))
	{
		DbDouble *pDbDouble = DynamicCast(DbDouble *, pDbVal);
		const double dd = *pDbDouble;
		char b[20];
		sprintf(b, "%.*f", pDbDouble->Sz2(), dd);
		return RWCString(b);
	}
	else if (DynamicCast(DbTS *, pDbVal))
	{
		DbTS *pDbTS = DynamicCast(DbTS *, pDbVal);

		char b[80];
		RWDate d(*pDbTS);

		RWCString s(pDbTS->asString('S'));
		if (s.length() == 1)
			s = "0" + s;
		int nSec = atoi(s);

		sprintf(b,
			"TO_DATE('%04d %02d %02d %02d %02d %02d', 'YYYY MM DD HH24 MI SS')",
			d.year(),
			d.month(),
			d.dayOfMonth(),
			pDbTS->hour(),
			pDbTS->minute(),
			nSec);

		return RWCString(b);
	}
	else if (DynamicCast(DbRaw *, pDbVal))
	{
		DbRaw *pDbRaw = DynamicCast(DbRaw *, pDbVal);

		unsigned char *pBuff = pDbRaw->GetBuff();

		RWCString r("'");
		for (int i = 0; i < pDbRaw->GetSize(); i++)
		{
			char b[3];
			sprintf(b, "%02x", int(pBuff[i]));
			r.append(b);
		}
		r.append("'");
		return r;
	}
	else
	{
		STError("DbConnectionOracle::DbPrint : unknown type");
		return RWCString("");
	}
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

DbTransactionOracle::DbTransactionOracle(DbConnectionOracle &cn, const char *strUser, const char *strPasswd, const char *strHost)
	: STDbTransactionData(cn),
	  m_DbError(ST_DB_OK),
	  m_bBegin(0)
{
	char aUser[100];
	strcpy(aUser, strUser);
	if (strHost != NULL && strHost[0] != '\0')
	{
		strcat(aUser, "@");
		strcat(aUser, strHost);
	}


	int r;
	Lda_Def m_lda;
	m_IndexOraData = Open(aUser, strPasswd, r, &m_lda);

	/* traduzione errori */
	     if (r && m_lda.rc == 1017) m_DbError = ST_DB_BEGINTRANSACTION_FAIL;
	else if (r && m_lda.rc == 1109) m_DbError = ST_DB_NOT_AVAILABLE;
	else if (r && m_lda.rc == 1507) m_DbError = ST_DB_NOT_AVAILABLE;
	else if (r && m_lda.rc == 1034) m_DbError = ST_DB_NOT_AVAILABLE;
	else if (r)                     m_DbError = ST_DB_ERROR;
	else                            m_DbError = ST_DB_OK;

	if (m_DbError == ST_DB_ERROR)
		ST_Throw(STDbException(m_DbError, err_report(this)));

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_BEGINTRANSACTION_FAIL, "DbTransactionOracle::BeginTransaction() - internal error");
}

STDbError DbTransactionOracle::BeginTransaction()
{
	if (m_DbError == ST_DB_OK)
		m_bBegin = 1;

	return m_DbError;
}

STDbError DbTransactionOracle::EndTransaction(STEndTransactionType cr)
{
	ST_COND_APPL(m_bBegin              == 1,        "DbTransactionOracle::EndTransaction() - called before BeginTransaction");
	ST_COND_APPL(m_DbError             == ST_DB_OK, "DbTransactionOracle::EndTransaction() - called with previous error");

	m_bBegin = 0;

	int r;

	Lda_Def m_lda;
	EndTr(m_IndexOraData, cr == STCommit, r, &m_lda);

	     if (r && m_lda.rc == 1)    m_DbError = ST_DB_DUPL_KEY;
	else if (r && m_lda.rc == 1400) m_DbError = ST_DB_NULL_KEY;
	else if (r && m_lda.rc == 2292) m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_lda.rc == 2291) m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_lda.rc == 2290) m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_lda.rc == 60)   m_DbError = ST_DB_LOCK;
	else if (r && m_lda.rc == 4020) m_DbError = ST_DB_LOCK;
	else if (r && m_lda.rc == 104)  m_DbError = ST_DB_LOCK;
	else if (r)                     m_DbError = ST_DB_ERROR;
	else                            m_DbError = ST_DB_OK;

	if (m_DbError < 0)
		ST_Throw(STDbException(m_DbError, err_report(this)));

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_DUPL_KEY || m_DbError == ST_DB_LOCK, "DbTransactionOracle::EndTransaction() - internal error");
	return m_DbError;
}

DbTransactionOracle::~DbTransactionOracle()
{
	if (m_bBegin)
		EndTransaction(STRollback);

	Close(m_IndexOraData);
}

////////////////////////////////////////////////////////////////////////////////

DbStmtOracle::DbStmtOracle(DbTransactionOracle &tro)
	: STDbStmtData(tro),
	  m_nDescribePos(1),
	  m_nBindPos(1),
	  m_DbError(ST_DB_OK),
	  m_bCursorOpen(0),
	  m_DbStack(10),
	  m_bNeedReset(0)
{
	ST_COND_APPL(&tro != 0, "DbStmtOracle::DbStmtOracle() - called with null DbTranctionOracle");

	m_pDbTransactionOracle = &tro;

	int r = oopen(&m_Cursor,
	              &G_OraData[tro.m_IndexOraData].m_lda,
	              0, -1, -1, 0, -1);

	/* traduzione dei codici di errore */
	m_DbError = (r == 0) ? ST_DB_OK : ST_DB_ERROR;
	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, err_report(this)));

	m_bCursorOpen = 1;
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::DbStmtOracle() - internal error");
}

STDbError DbStmtOracle::Parse(const char *pcStmt)
{
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Parse() - internal error");
	ST_COND_LIBR(m_bCursorOpen == 1, "DbStmtOracle::Parse() - internal error");
	ST_COND_APPL(pcStmt    != 0,     "DbStmtOracle::Parse() - null pcStmt");

	if (getenv("ST_DB_DEBUG"))
		STDebug("%s", pcStmt);

	int r;

	m_bNeedReset = 1;
	m_nDescribePos = 1;
	m_nBindPos     = 1;
	m_DbStack.Reset();
	m_DbStack_NULL.Reset();
	m_DbStack_TS.Reset();


	r = oparse(&m_Cursor,
			  (text *)pcStmt,
			  (sb4) -1, 
#define DEFER_PARSE    1
#define NO_DEFER_PARSE 0
			  NO_DEFER_PARSE,   // oppure DEFER_PARSE
#define VERSION_7      2
			  (ub4) VERSION_7);

	/* traduzione codici di errore */
	m_DbError = (r == 0) ? ST_DB_OK : ST_DB_ERROR;

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, err_report(this)));

	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Parse() - internal error");
	return m_DbError;
}

#ifndef NO_TEMPLATES
STDbError DbStmtOracle::Parse(const char *pcStmt, const STTVect<DbVal *> &s)
#else
STDbError DbStmtOracle::Parse(const char *pcStmt, const STTVect(P_DbVal) &s)
#endif
{
	STDbError e = Parse(pcStmt);

	if (e != ST_DB_OK)
		return e;

	/*
	 * in questo modo sono sicuro che gli elementi dell'array
	 * non verranno reallocati se l'array e' troppo piccolo
	 */
	m_DbStack_Marker.Resize(s.Size());
	m_DbStack_Marker.Reset();
	m_DbStack_TSMarker.Resize(s.Size());
	m_DbStack_TSMarker.Reset();

	m_DbStack_Marker.SetCanResize(0);
	m_DbStack_TSMarker.SetCanResize(0);

	for (int i = 0; i < s.Size(); i++)
	{
		sword  ftype;
		ub1   *progv;
		sword  progvl;

		DbVal *pDbVal = s[i];

		if (getenv("ST_DB_DEBUG"))
		{
			ostrstream s;
			RWCString r = DbPrint(pDbVal);
			s << "Valore \":" << i + 1 << "\" = \"" << r << "\"" << ends;
			STDebug("%s", s.str());
			s.rdbuf()->freeze(0);
		}


		if (DynamicCast(DbString *, pDbVal))
		{
			ftype = SQLT_AVC;
			progv = (ub1 *) pDbVal->GetDbAddress();
			progvl = pDbVal->GetDbSize();
		}
		else if (DynamicCast(DbInt *, pDbVal))
		{
			ftype = SQLT_INT;
			progv = (ub1 *) pDbVal->GetDbAddress();
			progvl = pDbVal->GetDbSize();
		}
		else if (DynamicCast(DbShort *, pDbVal))
		{
			ftype = SQLT_INT;
			progv = (ub1 *) pDbVal->GetDbAddress();
			progvl = pDbVal->GetDbSize();
		}
		else if (DynamicCast(DbChar *, pDbVal))
		{
			ftype = SQLT_AVC;
			progv = (ub1 *) pDbVal->GetDbAddress();
			progvl = pDbVal->GetDbSize();
		}
		else if (DynamicCast(DbDouble *, pDbVal))
		{
			ftype = SQLT_FLT;
			progv = (ub1 *) pDbVal->GetDbAddress();
			progvl = pDbVal->GetDbSize();
		}
		else if (DynamicCast(DbTS *, pDbVal))
		{
			DbTS *pTS = DynamicCast(DbTS *, pDbVal);

			RWDate d(*pTS);
			RWCString s(pTS->asString('S'));
			int sec;
			sscanf(s, "%d", &sec);

			int YYYY = d.year();
			int MM   = d.month();
			int DD   = d.dayOfMonth();
			int hh   = pTS->hour();
			int mm   = pTS->minute();
			int ss   = sec;

			/* per evitare problemi con i numeri maggiori di 127 */
			uchar7 bb;
			bb.c[0] = (YYYY / 100) + 100;
			bb.c[1] = (YYYY % 100) + 100;
			bb.c[2] = MM;
			bb.c[3] = DD;
			bb.c[4] = hh + 1;
			bb.c[5] = mm + 1;
			bb.c[6] = ss + 1;

			m_DbStack_TSMarker.Append(bb);
			uchar7 *pbb = &m_DbStack_TSMarker.Last();

			ftype = SQLT_DAT;
			progv = (ub1 *) pbb;
			progvl = 7;
		}
		else if (DynamicCast(DbRaw *, pDbVal))
		{
			ftype = SQLT_BIN;
			progv = (ub1 *) pDbVal->GetDbAddress();
			progvl = pDbVal->GetDbSize();
		}
		else
		{
			m_DbError = ST_DB_ERROR;
			ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Parse() - DataType derived variable unknown");
		}

		m_DbStack_Marker.Append(pDbVal->IsNull() ? -1 : 0);
		sb2 *indp = &m_DbStack_Marker.Last();

		int r = obndrn(&m_Cursor,  // cursor
					   i + 1,      // sqlvn
					   progv,
					   progvl,
					   ftype,
					   -1,         // scale (not used)
					   indp,       // indp
					   0,          // fmt   (not used)
					   -1,         // fmtl  (not used)
					   -1);        // fmtt  (not used)

		m_DbError = (r == 0) ? ST_DB_OK : ST_DB_ERROR;

		if (m_DbError < 0)
			ST_Throw (STDbException(m_DbError, err_report(this)));

		ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Parse() - internal error");
	}

	return ST_DB_OK;
}


STDbError DbStmtOracle::Bind(DbVal *pDbVal)
{
	ST_COND_LIBR(m_bCursorOpen == 1,    "DbStmtOracle::Bind() - internal error");
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Bind() - internal error");

	if (m_bNeedReset)
	{
		m_bNeedReset = 0;

		m_DbStack.Reset();

		m_DbStack_NULL.Resize(1024);  // si spera che non si facciano piu' di 1024 bind
		m_DbStack_NULL.Reset();

		m_DbStack_TS.Resize(128);  // si spera che non si facciano piu' di 128 bind con DbTS
		m_DbStack_TS.Reset();

		m_DbStack_NULL.SetCanResize(0);
		m_DbStack_TS.SetCanResize(0);

		m_nBindPos = 1;
	}


	sword  ftype;
	ub1   *buf;
	sword  bufl;

	if (DynamicCast(DbString *, pDbVal))
	{
		ftype = SQLT_AVC;
		buf = (ub1 *) pDbVal->GetDbAddress();
		bufl = pDbVal->GetDbSize();
	}
	else
	if (DynamicCast(DbInt *, pDbVal))
	{
		ftype = SQLT_INT;
		buf = (ub1 *) pDbVal->GetDbAddress();
		bufl = pDbVal->GetDbSize();
	}
	else
	if (DynamicCast(DbShort *, pDbVal))
	{
		ftype = SQLT_INT;
		buf = (ub1 *) pDbVal->GetDbAddress();
		bufl = pDbVal->GetDbSize();
	}
	else
	if (DynamicCast(DbChar *, pDbVal))
	{
		ftype = SQLT_AVC;
		buf = (ub1 *) pDbVal->GetDbAddress();
		bufl = pDbVal->GetDbSize();
	}
	else
	if (DynamicCast(DbDouble *, pDbVal))
	{
		ftype = SQLT_FLT;
		buf = (ub1 *) pDbVal->GetDbAddress();
		bufl = pDbVal->GetDbSize();
	}
	else
	if (DynamicCast(DbTS *, pDbVal))
	{
		uchar7 bb;
		m_DbStack_TS.Append(bb);
		uchar7 *pbb = &m_DbStack_TS.Last();

		ftype = SQLT_DAT;
		buf = (ub1 *) pbb;
		bufl = 7;
	}
	else
	if (DynamicCast(DbRaw *, pDbVal))
	{
		ftype = SQLT_BIN;
		buf = (ub1 *) pDbVal->GetDbAddress();
		bufl = pDbVal->GetDbSize();
	}
	else
	{
		m_DbError = ST_DB_ERROR;
		ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Bind() - DataType derived variable unknown");
	}

	m_DbStack_NULL.Append(0);
	sb2 *ind = &m_DbStack_NULL.Last();

	m_DbStack.Append(pDbVal);
	
	int r = odefin(&m_Cursor,                                   // cursor
				   m_nBindPos++,                                // pos
				   buf,
				   bufl,
				   ftype,                                       // ftype
				   -1,                                          // scale (not used)
				   ind,                                         // indp
	               0,                                           // fmt   (not used)
	               -1,                                          // fmtl  (not used)
	               -1,                                          // fmtt  (not used)
	               0,                                           // rlen
	               0);                                          // rcode

	m_DbError = (r == 0) ? ST_DB_OK : ST_DB_ERROR;

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, err_report(this)));

	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Bind() - internal error");
	return m_DbError;
}

STDbError DbStmtOracle::Exec(long &nNumOfProcessedRows)
{
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Exec() - internal error");

	int r = oexec(&m_Cursor);

	     if (r && m_Cursor.rc == 1)                            m_DbError = ST_DB_DUPL_KEY;
	else if (r && m_Cursor.rc == 1400)                         m_DbError = ST_DB_NULL_KEY;
	else if (r && m_Cursor.rc == 2292)                         m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_Cursor.rc == 2291)                         m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_Cursor.rc == 2290)                         m_DbError = ST_DB_REFERENTIAL_INTEGRITY;
	else if (r && m_Cursor.rc == 60)                           m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 4020)                         m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 104)                          m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 54)                           m_DbError = ST_DB_LOCK; // lock table nowait o select for update nowait
	else if (r)                                                m_DbError = ST_DB_ERROR;
	else if (r == 0 && m_Cursor.fc == 9 && m_Cursor.rpc == 0)  m_DbError = ST_DB_NOT_FOUND;  // delete
	else if (r == 0 && m_Cursor.fc == 5 && m_Cursor.rpc == 0)  m_DbError = ST_DB_NOT_FOUND;  // update
	else                                                       m_DbError = ST_DB_OK;

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, err_report(this)));

	nNumOfProcessedRows = m_Cursor.rpc;

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_DUPL_KEY || m_DbError == ST_DB_NOT_FOUND || m_DbError == ST_DB_LOCK, "DbStmtOracle::Exec() - internal error");
	return m_DbError;
}


STDbError DbStmtOracle::Fetch()
{
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Fetch() - internal error");

	int r = ofetch(&m_Cursor);

	     if (r && m_Cursor.rc == NO_DATA_FOUND) m_DbError = ST_DB_NOT_FOUND;
	else if (r && m_Cursor.rc == 60)            m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 4020)          m_DbError = ST_DB_LOCK;
	else if (r && m_Cursor.rc == 104)           m_DbError = ST_DB_LOCK;
	else if (r)                                 m_DbError = ST_DB_ERROR; 
	else                                        m_DbError = ST_DB_OK; 

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, err_report(this)));

	if (m_DbError == ST_DB_OK)
	{
		int nTS = 0;
		for (int i = 0; i < m_DbStack.Size(); i++)
		{
			DbVal *pDbVal = m_DbStack[i];

			pDbVal->PostFetchNull(m_DbStack_NULL[i] != 0);

			if (m_DbStack_NULL[i] != 0)
			{
				if (DynamicCast(DbTS *, pDbVal))
					nTS++;
				continue;
			}

			if (DynamicCast(DbString *, pDbVal))
			{
				DbString *p = DynamicCast(DbString *, pDbVal);
				p->KillLastBlanks();
				if (*p == "")
					p->PostFetchNull(1);
			}
			else
			if (DynamicCast(DbInt *, pDbVal))
			{
			}
			else
			if (DynamicCast(DbShort *, pDbVal))
			{
			}
			else
			if (DynamicCast(DbChar *, pDbVal))
			{
			}
			else
			if (DynamicCast(DbDouble *, pDbVal))
			{
			}
			else
			if (DynamicCast(DbTS *, pDbVal))
			{
				DbTS *p = DynamicCast(DbTS *, pDbVal);

				uchar7 *bb = &(m_DbStack_TS[nTS++]);
				int Y, M, D, h, m ,s;

				Y = (bb->c[0] - 100) * 100 + bb->c[1] - 100;
				M = bb->c[2];
				D = bb->c[3];
				h = bb->c[4] - 1;
				m = bb->c[5] - 1;
				s = bb->c[6] - 1;

				RWDate day(D, M, Y);
				RWTime tim(day, h, m, s);

				*p = tim;
			}
			else
			if (DynamicCast(DbRaw *, pDbVal))
			{
			}
			else
			{
				m_DbError = ST_DB_ERROR;
				ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Fetch() - DataType derived variable unknown");
			}
		}
	}


	m_bNeedReset = 1;

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_NOT_FOUND || m_DbError == ST_DB_LOCK, "DbStmtOracle::Fetch() - internal error");
	return m_DbError;
}


STDbError DbStmtOracle::Describe(RWCString &strColName, DbVal *&rpDbVal)
{
	ST_COND_LIBR(m_DbError == ST_DB_OK, "DbStmtOracle::Describe() - internal error");

	sword pos = m_nDescribePos;

	sb4 dbsize;
	sb2 dbtype;
	sb1 cbuf[256];
	sb4 cbufl = sizeof(cbuf);
	sb4 dsize;
	sb2 prec;
	sb2 scale;
	sb2 nullok;

	int r = odescr(&m_Cursor,
	               pos,
	               &dbsize,
	               &dbtype,
	               cbuf,
	               &cbufl,
	               &dsize,
	               &prec,
	               &scale,
	               &nullok);

	     if (r && m_Cursor.rc == VAR_NOT_IN_LIST) m_DbError = ST_DB_NOT_FOUND;
	else if (r)                                   m_DbError = ST_DB_ERROR;
	else                                          m_DbError = ST_DB_OK;


	if (m_DbError == ST_DB_OK)
	{
		cbuf[cbufl] = '\0';

		// cerr << cbuf << ":\n";
		// cerr << "dbsize:" << dbsize << "\n";
		// cerr << "dbtype:" << dbtype << "\n";
		// cerr << "dsize :" << dsize  << "\n";
		// cerr << "prec  :" << prec   << "\n";
		// cerr << "scale :" << scale  << "\n";
		// cerr << "nullok:" << nullok << "\n";

		int nInternalOracleType = dbtype;

		switch (nInternalOracleType)
		{
		case SQLT_CHR: //  1 (VARCHAR2)
		case SQLT_AFC: // 96 (CHAR)
			rpDbVal = STNew DbString(dbsize);
			break;

		case SQLT_BIN: // 23 (RAW)
			rpDbVal = STNew DbRaw(dbsize);
			break;

		case SQLT_NUM: //  2 (NUMBER)
			     if (prec < 5  && scale == 0) rpDbVal = STNew DbShort(prec);
			else if (prec < 10 && scale == 0) rpDbVal = STNew DbInt(prec);
			else                              rpDbVal = STNew DbDouble(prec, scale);
			break;
	
		case SQLT_DAT: // 12 (DATE)
			rpDbVal = STNew DbTS;
			break;

		default:
			ST_COND_LIBR(0, "DbStmtOracle::Descride() - oracle dbtype variable unknown");
		}

		strColName = (char *)cbuf;

		m_nDescribePos += 1;

		m_DbError = ST_DB_OK;
	}

	if (m_DbError < 0)
		ST_Throw (STDbException(m_DbError, err_report(this)));

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_NOT_FOUND, "DbStmtOracle::Describe() - internal error");
	return m_DbError;
}

DbStmtOracle::~DbStmtOracle()
{
	if (m_bCursorOpen)
	{
		m_bCursorOpen = 0;

		int r = ocan(&m_Cursor);
		m_DbError = (r == 0 || r == -1003) ? ST_DB_OK : ST_DB_ERROR;

		if (m_DbError < 0)
			ST_Throw (STDbException(m_DbError, err_report(this)));

		r = oclose(&m_Cursor);
		m_DbError = (r == 0 || r == -1003) ? ST_DB_OK : ST_DB_ERROR;

		if (m_DbError < 0)
			ST_Throw (STDbException(m_DbError, err_report(this)));
	}
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

static const char * err_report(DbConnectionOracle *cn)
{
	return err_report(&G_OraData[cn->m_IndexOraData].m_lda, (Cda_Def *)&G_OraData[cn->m_IndexOraData].m_lda);
}

static const char * err_report(DbTransactionOracle *cn)
{
	/*
	return err_report(&cn->m_lda, (Cda_Def *)&cn->m_lda);
	*/

	return err_report(&G_OraData[cn->m_IndexOraData].m_lda,
		   (Cda_Def *)&G_OraData[cn->m_IndexOraData].m_lda);
}

static const char * err_report(DbStmtOracle *stm)
{
	return err_report(&(G_OraData[stm->m_pDbTransactionOracle->m_IndexOraData].m_lda), &stm->m_Cursor);
}

static const char * err_report(Lda_Def *lda, Cda_Def *cursor)
{
	static char msg[2048];

	strcpy(msg, "ORACLE error: \"");
	oerhms(lda, cursor->rc, (text *)msg + strlen(msg), (sword) sizeof msg);
	if (msg[strlen((const char *)msg) - 1] == '\n')
		msg[strlen((const char *)msg) - 1] = 0;
	strcat(msg, "\"");

	if (cursor->fc > 0)
	{
		strcat(msg, " OCI function ");       
#ifndef DOS
		strcat(msg, (char *)oci_func_tab[cursor->fc]);
#else
		strcat(msg, "no oci_func_tab");
#endif
	}

	ostrstream s(msg, sizeof(msg), ios::ate);
	s << "  SQL function code " << cursor->ft << ends;

	return msg;
}


#endif // ST_LIBDB_ORACLE
