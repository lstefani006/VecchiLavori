#include <iostream.h>

#include <st_trace.h>

const STTrace * STTrace::S_pLast = NULL;


STTrace::STTrace(const char *f, int l, const char *m)
{
	m_msg = m;
	cerr << "BEGIN " << m_msg << endl;
	cerr << "{\t" << f << "," << l <<  endl;

	m_pPrevious = S_pLast;
	S_pLast = this;
}

STTrace::~STTrace()
{
	cerr << "} END " << m_msg << endl;

	S_pLast = m_pPrevious;
}


void STTrace::PrintStack() const
{
	cerr << "STTrace::PrintStack :-" << endl;

	const STTrace *p = this;

	while (p)
	{
		cerr << "\t" << p->m_msg << endl;
		p = p->m_pPrevious;
	}

	cerr << endl;
}
