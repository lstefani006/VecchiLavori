#include <strstrea.h>
