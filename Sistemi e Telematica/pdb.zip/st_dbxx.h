#ifndef __ST_DBXX_H__
#define __ST_DBXX_H__

#include <iostream.h>

#include <st_dbdat.h>
#include <st_db.h>


#include <st_where.h>
#include <st_map.h>

class STDbBase;
class STDbSlist;


struct STDbClassInfo
{
	/* non si puo` usare il costruttore in quanto questi dati devono
	   essere preparati prima degli altri costruttori */

	const char          * ClassName;
	STDbMap             * m_pMap;
	void               (* m_pCreateMap)();
	STDbBase          *(* m_pGetClassInstance)();

	STDbMap &           Map() const { return *m_pMap; }
	void                SetMap(STDbMap *p) { m_pMap = p; }
};


//////////////////////////////////////////////////////////////////////////////

class STDbG
{
public:
	STDbG(const STDbClassInfo *pDbClassInfo);

	static void                  DbMain();
	static void                  DbCreateSql(int &ac, char **&av);

	static STDbBase *            DbCreateObject(const char *strClassName);

	static const STDbClassInfo & DbGetClassInfo(const char *strClassName);

	static void                  DbInfo();

private:
	static void DbCreateMapping(int);

	static const STDbClassInfo *m_DbReg[];
	static int                  m_DbRegTop;
};


#define STDeclareDbClass(ClassName)                                  \
	STDefineClassInfo                                                \
	STDeclareAssignClone(ClassName)                                  \
	static STDbClassInfo          CI;                                \
	virtual const STDbClassInfo * GetCI() const;                     \
	static  STDbBase            * GetClassInstance();                \
	virtual const DbVal         * GetDbCol(int nOffset) const;       \
	static  void                  CreateMap()

#define STDefineDbClass(ClassName)                                   \
	void ClassName::CreateMap()


#define STRegisterDbClass0(ClassName)                                 \
	STDbClassInfo ClassName::CI = {								      \
		#ClassName,                                                   \
		(STDbMap *)NULL,                                              \
		ClassName::CreateMap,									      \
		ClassName::GetClassInstance								      \
	};                                                                \
	STDbBase *ClassName::GetClassInstance()                           \
		{ return STNew ClassName; }                                   \
	const DbVal *ClassName::GetDbCol(int nOffset) const               \
		{ return (DbVal *)(((char *)this) + nOffset); }               \
	const STDbClassInfo  *ClassName::GetCI() const                    \
		{ return &CI; }                                               \
	STImplementAssignClone(ClassName)                                 \
	static STDbG __DbG##ClassName(&ClassName::CI);


#define STRegisterDbBase()                                      \
	STImplementClassInfo1(STDbBase, STDbEl)                     \
	STRegisterDbClass0(STDbBase)

#ifndef NO_TEMPLATES
#define STRegisterDbClass(ClassName, Dummy, ClassBaseName)         \
	STImplementClassInfo1(ClassName, ClassBaseName)                   \
	int ClassName::STIsEqual(const STRoot *p) const                   \
		{ return ClassBaseName::STIsEqual(p); }                       \
	STImplementClassInfo1(STTDbSlist<ClassName *>, STDbSlist)         \
	STRegisterDbClass0(ClassName)
#else // NO_TEMPLATES    
#define STRegisterDbClass(ClassName, Dummy, ClassBaseName)         \
	STImplementClassInfo1(ClassName, ClassBaseName)                   \
	int ClassName::STIsEqual(const STRoot *p) const                   \
		{ return ClassBaseName::STIsEqual(p); }                       \
	STImplementClassInfo1(STTDbSlist(P_##ClassName), STDbSlist)       \
	STRegisterDbClass0(ClassName)
#endif // NO_TEMPLATES



#define STDbOffset(ClassName, DataMember) \
	((long)(&(((ClassName *)0)->DataMember)))

#define STDbMap1(a)          CI.SetMap(STNew STDbMap(#a))
#define STDbMap2(a, b, c)    ((void)0) /* vecchia voce */
#define STDbMap3(a, b, c)    CI.Map().Put(STDbOffset(a, b), #c, STNotKey)
#define STDbMap3Key(a, b, c) CI.Map().Put(STDbOffset(a, b), #c, STPrimaryKey)

#define STDbMapDebug()       CI.Map().Debug()
		
#define CM(a, b) STDbWhereData(&(a::CI), STDbOffset(a, b))

#define C_Tab(a)       RWCString(a::CI.Map().Table())
#define C_Col(a, b)    (a::CI.Map().Get(STDbOffset(a, b)).Col())
#define C_TabCol(a, b) (C_Tab(a, b) + "." + C_Col(a, b))


//////////////////////////////////////////////////////////////////////////////

enum STSelectType {STSelectNoLock, STSelectForUpdate, STSelectForUpdateNoWait};

class STDbEl : public virtual STRoot
{
public:
	STDefineClassInfo

	STDbEl() {}
	STDbEl(const STDbEl &) {}
	void operator = (const STDbEl &) {}

	enum SaveType { All = 7, UpdateOnly = 1, DeleteOnly = 2, InsertOnly = 4, None = 0 };

	virtual void      Erase() = 0;
	virtual int       Check(STDbTransaction &) const = 0;
	virtual STDbError Save(STDbTransaction &, SaveType = All) const = 0;
};

class STDbBase : public STDbEl 
{
public:
	STDbBase(int Dummy = 0);
	STDbBase(const STDbBase &r);
	void operator = (const STDbBase &r);
	~STDbBase();

	STDeclareDbClass(STDbBase)
	{
		CI.SetMap(STNew STDbMap);
	}

	int STCompareTo(const STRoot *) const;

	virtual STDbError Select(STDbTransaction &, STDbWhereLogical, STSelectType = STSelectNoLock);
	virtual STDbError Insert(STDbTransaction &) const;
	virtual STDbError Update(STDbTransaction &) const;
	virtual STDbError Delete(STDbTransaction &) const;

	static STDbError  Select(STDbTransaction &, const char *theClassName,                           STDbSlist &, STSelectType = STSelectNoLock);
	static STDbError  Select(STDbTransaction &, const char *theClassName, const STDbWhereLogical &, STDbSlist &, STSelectType = STSelectNoLock);

	static long       Count(STDbTransaction &, const STDbWhereLogical &);
	static STDbError  LockTable(STDbTransaction &tr, const STDbClassInfo &rDbClassInfo);


	virtual STDbWhereLogical GetWhereCondition() const;
	const DbVal *            GetDbCol(const STDbWhereData &w) const;

	virtual void             CreateSql() const;
	virtual ostream &        STDebug(ostream &) const;

private:
	friend class STDbSelectIterator;

	/* dati per il livello 3 */
protected:
	int m_bOnLevel3;
	int m_bErased;
	STDbBase *m_pBack;

	int AreKeyFieldsChanged() const;

public:
	void SetBack();
	void ResetBack();

	virtual STDbError Load(STDbTransaction &, const STDbWhereLogical &, STSelectType = STSelectNoLock);

	virtual void      Erase();
	virtual int       Check(STDbTransaction &) const;
	virtual STDbError Save(STDbTransaction &, SaveType = All) const;

	int               IsRecordChanged() const;
	int               IsErased() const { return m_bErased; }

	virtual SaveType  GetSaveType() const;
};

#include <st_dblst.h>

#endif
