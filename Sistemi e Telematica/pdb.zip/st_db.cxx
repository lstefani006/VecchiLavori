#include <st_dbnew.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <strstream.h>
#include <rw/defs.h>
#include <rw/regexp.h>

#include <st_dbdat.h>
#include <st_err.h>
#include <st_db.h>
#include "prtbl_d2.h"


#ifdef ST_LIBDB_ODBC
	#include "odbc_db.h"
#endif

#ifdef ST_LIBDB_ORACLE
	#include "ora_db.h"
#endif

////////////////////////////////////////////////////////////////////////////////

void (*G_pfEnterIdle)() = NULL;
void (*G_pfLeaveIdle)() = NULL;

class EnterIdle
{
public:
	EnterIdle()  { if (nCount++ == 0 && G_pfEnterIdle) (*G_pfEnterIdle)(); }
	~EnterIdle() { if (--nCount == 0 && G_pfLeaveIdle) (*G_pfLeaveIdle)(); }

	static int nCount;
};

int EnterIdle::nCount = 0;


////////////////////////////////////////////////////////////////////////////////

STDbConnectionData::~STDbConnectionData() {}
STDbTransactionData::~STDbTransactionData() {}
STDbStmtData::~STDbStmtData() {}

////////////////////////////////////////////////////////////////////////////////

struct
{
	STDbError    m_DbError;
	const char * m_pcDbErrorMsg;
}
const DbErrorStrings[] = 
{
	ST_DB_OK                    , "Ok",
	ST_DB_LOGIN_FAIL            , "Login fail",
	ST_DB_BEGINTRANSACTION_FAIL , "Begin transaction failure",
	ST_DB_NOT_FOUND             , "Not found",
	ST_DB_DUPL_KEY              , "Duplicated key",
	ST_DB_LOCK                  , "Lock",

	/* errori che generano un eccezione */
	ST_DB_ERROR                 , "Error",
	ST_DB_PROT                  , "Protection error",
	ST_DB_REFERENTIAL_INTEGRITY , "Referential integrity error",
	ST_DB_NOT_UNIQUE            , "Where condition matches more rows",
	ST_DB_NOT_AVAILABLE         , "Data base not available",
	ST_DB_NULL_KEY              , "Null key",

	ST_DB_OK                    , 0
};

const char * STGetDbErrorString(STDbError e)
{
	for (int i = 0; DbErrorStrings[i].m_pcDbErrorMsg; i++)
		if (DbErrorStrings[i].m_DbError == e)
			return DbErrorStrings[i].m_pcDbErrorMsg;
	
	return "Unknown error";
}

////////////////////////////////////////////////////////////////////////////////

STDbException::STDbException(STDbError e, const char *pc)
{
	ST_COND_LIBR(int(e) < 0, "DbException::DbException() - called with a STDbError >= 0");

	strncpy(m_aMsg, pc, sizeof(m_aMsg));
	m_aMsg[sizeof(m_aMsg) - 1] = 0;

	m_DbError = e;

	STDebug("Portable data base msg: %s (%d)\n%s\n",
		STGetDbErrorString(e),
		int(e),
		pc);

	STDebugStackTrace();
}

void STDbException::operator = (const STDbException &e)
{
	strcpy(m_aMsg, e.m_aMsg);
	m_DbError = e.m_DbError;
}

#ifdef NO_EXCEPTIONS
void ST_Throw(const STDbException &r)
{
	char *b = STNew char [2048];
	sprintf(b, "Portable data base msg: %d\n%s\n",
		int(r.ErrorCode()),
		r.Msg());
	ST_Throw(b);
	STDelete [] b;
}
#endif // NO_EXCEPTIONS

////////////////////////////////////////////////////////////////////////////////

STDbConnection G_DbConnection;

STDbConnection::STDbConnection(STDbType theDbType)
	: m_DbType(theDbType),
	  m_DbError(ST_DB_OK),
	  m_pDbConnectionData(0),
	  m_bConnected(0)
{
	m_acUser[0] = 0;
	m_acPasswd[0] = 0;

	ST_COND_APPL(
			theDbType == ST_DB_ODBC    ||
			theDbType == ST_DB_ORACLE,
			"STDbConnection::STDbConnection() - STDbType unknown");
}

STDbError STDbConnection::Login(const char *pcUser, const char *pcPasswd, const char *pcHost)
{
	EnterIdle ei;

	ST_COND_APPL(m_bConnected == 0,        "STDbConnection::Login() - called with open connection");
	ST_COND_LIBR(m_pDbConnectionData == 0, "STDbConnection::Login() - internal error");
	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_LOGIN_FAIL, "STDbConnection::Login() - internal error");

	strcpy(m_acUser,   pcUser);
	strcpy(m_acPasswd, pcPasswd);

	if (pcHost != NULL && pcHost[0] != '\0')
		strcpy(m_acHost, pcHost);
	else
		strcpy(m_acHost, "");

	switch (m_DbType)
	{
#ifdef ST_LIBDB_ORACLE
	case ST_DB_ORACLE:
		m_pDbConnectionData = STNew DbConnectionOracle;
		break;
#endif

#ifdef ST_LIBDB_ODBC
	case ST_DB_ODBC:
		m_pDbConnectionData = STNew DbConnectionOdbc;
		break;
#endif

	default:
		ST_COND_LIBR(0, "DbCondition::Login() - internal errror");
	}

	ST_COND_LIBR(m_pDbConnectionData != 0, "STDbConnection::Login() - internal errror");
	
	m_DbError = m_pDbConnectionData->Login(m_acUser, m_acPasswd, m_acHost[0] != '\0' ? m_acHost : NULL);

	if (m_DbError == ST_DB_LOGIN_FAIL)
	{
		STDelete m_pDbConnectionData;
		m_pDbConnectionData = 0;
	}

	if (m_DbError == ST_DB_OK)
		m_bConnected = 1;

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_LOGIN_FAIL, "STDbConnection::Login() - internal error");
	return m_DbError;
}

STDbError STDbConnection::Logout()
{
	EnterIdle ei;

	ST_COND_APPL(m_bConnected        != 0,    "STDbConnection::Logout() - Logout called before Login");
	ST_COND_APPL(m_pDbConnectionData != 0,    "STDbConnection::Logout() - Logout called before Login");
	ST_COND_APPL(m_DbError       == ST_DB_OK, "STDbConnection::Logout() - Logout called with Login error");

	m_bConnected = 0;
	m_DbError = m_pDbConnectionData->Logout();

	STDelete m_pDbConnectionData;
	m_pDbConnectionData = 0;

	ST_COND_LIBR(m_DbError == ST_DB_OK,       "STDbConnection::Logout() - internal error");
	return m_DbError;
}

STDbConnection::~STDbConnection()
{
	if (m_bConnected)
		Logout();

	STDelete m_pDbConnectionData;
}


RWCString STDbConnection::GetParameterMarker(int i) const
{
	return m_pDbConnectionData->GetParameterMarker(i);
}

RWCString STDbConnection::DbPrint(const DbVal *p) const
{
	return m_pDbConnectionData->DbPrint(p);
}



////////////////////////////////////////////////////////////////////////////////


STDbTransaction::STDbTransaction(STDbConnection &cn)
{
	EnterIdle ei;

	ST_COND_APPL(&cn != 0,       "STDbTransaction::STDbTransaction() - called with a null STDbConnection");
	ST_COND_APPL(cn.Connected(), "STDbTransaction::STDbTransaction() - called with an unconnected STDbConnection");

	m_DbError = ST_DB_OK;
	m_bBegin = 0;

	m_pDbConnection = &cn;

	switch (m_pDbConnection->GetDbType())
	{
#ifdef ST_LIBDB_ORACLE
	case ST_DB_ORACLE:
		m_pDbTransactionData = STNew DbTransactionOracle(*(DbConnectionOracle *)cn.m_pDbConnectionData, cn.m_acUser, cn.m_acPasswd, cn.m_acHost[0] != '\0' ? cn.m_acHost : NULL);
		break;
#endif

#ifdef ST_LIBDB_ODBC
	case ST_DB_ODBC:
		m_pDbTransactionData = STNew DbTransactionOdbc(*(DbConnectionOdbc *)cn.m_pDbConnectionData, cn.m_acUser, cn.m_acPasswd, cn.m_acHost[0] != '\0' ? cn.m_acHost : NULL);
		break;
#endif

	default:
		ST_COND_APPL(0, "STDbTransaction::DbTranasction() - STDbType unknown");
	}

	ST_COND_LIBR(m_pDbTransactionData != 0, "STDbTransaction::DbTranasction() - internal error");

	m_DbError = m_pDbTransactionData->Error();
}

STDbError STDbTransaction::BeginTransaction()
{
	EnterIdle ei;

	ST_COND_APPL(m_bBegin == 0,             "STDbTransaction::BeginTransaction() - called with an open transaction");
	ST_COND_LIBR(m_pDbTransactionData != 0, "STDbTransaction::BeginTransaction() - internal error");

	m_DbError = m_pDbTransactionData->BeginTransaction();

	if (m_DbError == ST_DB_OK)
		m_bBegin = 1;

	if (m_pDbConnection->GetDbType() == ST_DB_ORACLE)
	{
		if (getenv("ST_DB_TRACE"))
		{
			STDbStmt s(*this);
			s.Parse("alter session set sql_trace=true");
			s.Exec();
		}
	}

	return m_DbError;
}

STDbError STDbTransaction::EndTransaction(STEndTransactionType cr)
{
	EnterIdle ei;

	ST_COND_APPL(m_bBegin             == 1,        "STDbTransaction::EndTransaction() - called without BeginTransaction");
	ST_COND_APPL(m_DbError            == ST_DB_OK, "STDbTransaction::EndTransaction() - called with Error");
	ST_COND_LIBR(m_pDbTransactionData != 0,        "STDbTransaction::EndTransaction() - internal error");

	m_bBegin = 0;

	m_DbError = m_pDbTransactionData->EndTransaction(cr);

	return m_DbError;
}

STDbTransaction::~STDbTransaction()
{
	EnterIdle ei;

	ST_COND_LIBR(m_pDbTransactionData != 0, "STDbTransaction::~EndTransaction() - internal error");

	if (m_bBegin)
		EndTransaction(STRollback);

	ST_COND_LIBR(m_DbError == ST_DB_OK || ST_DB_BEGINTRANSACTION_FAIL, "STDbTransaction::~STDbTransaction() - internal error");
	STDelete m_pDbTransactionData;
}

RWCString STDbTransaction::GetParameterMarker(int i) const
{
	return m_pDbConnection->GetParameterMarker(i);
}

////////////////////////////////////////////////////////////////////////////////

#define STMT_CSTR       0
#define STMT_PARSE      1
#define STMT_BIND       2
#define STMT_EXEC       3
#define STMT_FETCH      4
#define STMT_DESCRIBE   5

STDbStmt::STDbStmt(STDbTransaction &tr)
	: m_pDbTransaction(&tr),
	  m_nState(STMT_CSTR),
	  m_DbError(ST_DB_OK)
{
	EnterIdle ei;

	ST_COND_APPL(&tr != 0, "STDbStmt::STDbStmt() - called with null STDbTransaction");

	switch (tr.GetDbType())
	{
#ifdef ST_LIBDB_ORACLE
	case ST_DB_ORACLE:
		m_pDbStmtData = STNew DbStmtOracle(*(DbTransactionOracle *)tr.m_pDbTransactionData);
		break;
#endif

#ifdef ST_LIBDB_ODBC
	case ST_DB_ODBC:
		m_pDbStmtData = STNew DbStmtOdbc(*(DbTransactionOdbc *)tr.m_pDbTransactionData);
		break;
#endif

	default:
		ST_COND_APPL(0, "STDbStmt::STDbStmt() - STDbType unknown");
	}

	m_DbError = m_pDbStmtData->Error();

	m_nState = STMT_CSTR;

	ST_COND_LIBR(m_pDbStmtData != 0, "STDbStmt::STDbStmt() - internal error");
	ST_COND_LIBR(m_DbError == ST_DB_OK, "STDbStmt::STDbStmt() - internal error");
}

STDbError STDbStmt::Parse(const char *pcStmt)
{
	EnterIdle ei;

	ST_COND_LIBR(m_pDbStmtData != 0,         "STDbStmt::Parser() - internal error");
	ST_COND_APPL(pcStmt        != 0,         "STDbStmt::Parser() - null pcStmt ");
//*	ST_COND_APPL(m_nState      == STMT_CSTR, "STDbStmt::Parser() - called with error");
	ST_COND_APPL(m_DbError     == ST_DB_OK,  "STDbStmt::Parser() - called with error");
	m_strStmt = pcStmt;
	m_DbError = m_pDbStmtData->Parse(pcStmt);
	m_nState = STMT_PARSE;
	ST_COND_APPL(m_DbError == ST_DB_OK, "STDbStmt::Parser() - internal error");
	return m_DbError;
}

#ifndef NO_TEMPLATES
STDbError STDbStmt::Parse(const char *pcStmt, const STTVect<DbVal *> &v)
#else
STDbError STDbStmt::Parse(const char *pcStmt, const STTVect(P_DbVal) &v)
#endif
{
	EnterIdle ei;

	ST_COND_LIBR(m_pDbStmtData != 0,         "STDbStmt::Parser() - internal error");
	ST_COND_APPL(pcStmt        != 0,         "STDbStmt::Parser() - null pcStmt ");
//*	ST_COND_APPL(m_nState      == STMT_CSTR, "STDbStmt::Parser() - called with error");
	ST_COND_APPL(m_DbError     == ST_DB_OK,  "STDbStmt::Parser() - called with error");
	m_strStmt = pcStmt;
	m_DbError = m_pDbStmtData->Parse(pcStmt, v);
	m_nState = STMT_PARSE;
	ST_COND_APPL(m_DbError == ST_DB_OK, "STDbStmt::Parser() - internal error");
	return m_DbError;
}

STDbError STDbStmt::Bind(DbVal &rDbVal)
{
	return Bind(&rDbVal);
}

STDbError STDbStmt::Bind(DbVal *pDbVal)
{
	ST_COND_LIBR(m_pDbStmtData != 0,                              "STDbStmt::Bind() - internal error");
	ST_COND_APPL(m_DbError == ST_DB_OK,                           "STDbStmt::Bind() - called with previous error");
//*	ST_COND_APPL(m_nState == STMT_PARSE || m_nState == STMT_BIND || m_nState == STMT_FETCH, "Stmt::Bind() - called before Parse");

	m_DbError = m_pDbStmtData->Bind(pDbVal);

	m_nState = STMT_BIND;

	ST_COND_LIBR(m_DbError == ST_DB_OK,                              "STDbStmt::Bind() - internal error");
	return m_DbError;
}

long STDbStmt::m_lDummy = 0;

STDbError STDbStmt::Exec(long &nNumOfProcessedRows)
{
	EnterIdle ei;

	ST_COND_LIBR(m_pDbStmtData != 0,                              "STDbStmt::Exec() - internal error");
//*	ST_COND_APPL(m_nState == STMT_PARSE || m_nState == STMT_BIND, "STDbStmt::Exec() - called before Parse");
	ST_COND_APPL(m_DbError == ST_DB_OK,                           "STDbStmt::Exec() - called with previous error");

	m_DbError = m_pDbStmtData->Exec(nNumOfProcessedRows);
	m_nState = STMT_EXEC;

	/*
	 * Insert returns ST_DB_OK or ST_DB_DUPL_KEY
	 * Delete returns ST_DB_OK or ST_DB_NOT_FOUND
	 * Update returns ST_DB_OK or ST_DB_NOT_FOUND
	 * Select returns ST_DB_OK or ST_DB_LOCK
	 */
	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_DUPL_KEY || m_DbError == ST_DB_NOT_FOUND || m_DbError == ST_DB_LOCK,  "STDbStmt::Exec() - internal error");
	return m_DbError;
}

STDbError STDbStmt::Fetch()
{
	EnterIdle ei;

	/*
	 * used only in select statments
	 */
	ST_COND_LIBR(m_pDbStmtData != 0,                                                       "STDbStmt::Fetch() - internal error");
//*	ST_COND_APPL(m_nState == STMT_EXEC || m_nState == STMT_FETCH || m_nState == STMT_BIND, "STDbStmt::Fetch() - incorrect use");
	ST_COND_APPL(m_DbError == ST_DB_OK,                                                    "STDbStmt::Fetch() - called with error");

	m_DbError =  m_pDbStmtData->Fetch();

	m_nState = STMT_FETCH;

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_NOT_FOUND || m_DbError == ST_DB_LOCK, "STDbStmt::Fetch() - internal error");
	return m_DbError;
}


STDbError STDbStmt::Describe(RWCString &strColName, DbVal *&rpDbVal)
{
	EnterIdle ei;

	ST_COND_LIBR(m_pDbStmtData != 0,                                  "STDbStmt::Describe() - internal error");
//*	ST_COND_APPL(m_nState == STMT_PARSE || m_nState == STMT_DESCRIBE, "STDbStmt::Describe() - called not after Exec or Fetch");
	ST_COND_APPL(m_DbError == ST_DB_OK,                               "STDbStmt::Describe() - called with error");

	m_DbError = m_pDbStmtData->Describe(strColName, rpDbVal);

	m_nState = STMT_DESCRIBE;

	ST_COND_LIBR(m_DbError == ST_DB_OK || m_DbError == ST_DB_NOT_FOUND, "STDbStmt::Describe() - internal error");
	return m_DbError;
}

STDbStmt::~STDbStmt()
{
	STDelete m_pDbStmtData;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////


/*
* void DbVal::PostFetch(STDbType t)
* {
* 	ST_COND_APPL(t == ST_DB_ORACLE, "unsupported db (non deve essere odbc)");
* 
* 	{
* 		DbString *p = DynamicCast(DbString *, this);
* 		if (p)
* 		{
* 			if (*p == "")
* 				m_bNull = 1;
* 		}
* 	}
* 
* 
* 	// m_bNull viene settato da oracle
* 	if (m_bNull)
* 		m_bNull = 1;
*	
*	// se il campo e` NOT NULL e nel db e` stato
*	// tirato su un campo NULL
*	if (!m_bCanBeNull && m_bNull)
*	{
*		m_bNull = 0;
*		Reset(NotNull);
*	}
*
*	if (m_bNull)
*		Reset(Null);
*}
*
*void DbChar::PostFetch(STDbType t)
*{
*	DbVal::PostFetch(t);
*}
*
*void DbString::PostFetch(STDbType t)
*{
*	ST_COND_APPL(t == ST_DB_ORACLE, "unsupported db");
*
*	KillLastBlanks();
*	DbVal::PostFetch(t);
*}
*
*void DbInt::PostFetch(STDbType t)
*{
*	DbVal::PostFetch(t);
*}
*
*void DbShort::PostFetch(STDbType t)
*{
*	DbVal::PostFetch(t);
*}
*
*void DbDouble::PostFetch(STDbType t)
*{
*	DbVal::PostFetch(t);
*}
*
*
*void DbRaw::PostFetch(STDbType t)
*{                               
*	DbVal::PostFetch(t);
*}
*
*void DbTS::PostFetch(STDbType t)
*{
*	DbVal::PostFetch(t);
*
*	ST_COND_APPL(t == ST_DB_ORACLE, "unsupported db (non deve odbc)");
*
*	int Y, M, D, h, m ,s;
*
*	unsigned char *p = (unsigned char *)m_b;
*
*	if (DbVal::IsNull() || p[0] == 0)
*	{
*		*this = NullDate;
*		return;
*	}
*
*	Y = (p[0] - 100) * 100 + p[1] - 100;
*	M = p[2];
*	D = p[3];
*	h = p[4] - 1;
*	m = p[5] - 1;
*	s = p[6] - 1;
*
*	RWDate day(D, M, Y);
*	RWTime tim(day, h, m, s);
*
*	*this = tim;
*}
*/

