#ifndef __ORA_DB_H__
#define __ORA_DB_H__

#include <stdlib.h>
#include <iostream.h>
#include <rw/defs.h>

#include <st_db.h>
#include <st_tvect.h>

/* include per ORACLE */
extern "C"
{
#ifdef DOS
	#ifndef _MSC_VER
		#error "Usare il compilatore Microsoft"
	#endif

	#ifdef _WIN32
	#else
		#pragma pack(2)		// solo Win 16 bit
	#endif
#endif

#include <oratypes.h>
#include <ocidfn.h>
#include <ociapr.h>    

#ifndef DOS
	#include <ocidem.h>
#endif

#ifdef DOS
	#ifndef _WIN32
		#pragma pack()		// solo Win 16 bit
	#else
	#endif
#endif

}

struct uchar7
{
	friend int operator == (const uchar7 &, const uchar7 &) { return 0; }
	unsigned char c[20];
};

#ifdef NO_TEMPLATES
	#ifndef D_uchar7
		#define D_uchar7
		declare(STTVect, uchar7);
	#endif
	#ifndef D_sb2
		#define D_sb2
		declare(STTVect, sb2);
	#endif
#endif

////////////////////////////////////////////////////////////////////////////////

class DbConnectionOracle : public STDbConnectionData
{
public:
	DbConnectionOracle();
	~DbConnectionOracle();

	STDbError Login(const char *pcUser, const char *pcPasswd, const char *pcHost);
	STDbError Logout();
	STDbError Error() const { return m_DbError; }

	RWCString GetParameterMarker(int) const;
	RWCString DbPrint(const DbVal *) const;

	STDbError   m_DbError;
	int         m_IndexOraData;
};


////////////////////////////////////////////////////////////////////////////////


class DbTransactionOracle : public STDbTransactionData
{
public:
	DbTransactionOracle(DbConnectionOracle &cn, const char *pcUser, const char *pcPasswd, const char *pcHost);
	~DbTransactionOracle();

	STDbError BeginTransaction();
	STDbError EndTransaction(STEndTransactionType);
	STDbError Error() const { return m_DbError; }

	STDbConnectionData * GetDbConnectionData();

	int m_IndexOraData;

	/* in Oracle ogni transazione ha la sua connessione */
	int                   m_bUsed;
	STDbError             m_DbError;
	int                   m_bBegin;
};


////////////////////////////////////////////////////////////////////////////////

class DbStmtOracle : public STDbStmtData
{
public:
	DbStmtOracle(DbTransactionOracle &);
	~DbStmtOracle();

	STDbError Parse(const char *pcStmt);
#ifndef NO_TEMPLATES
	STDbError Parse(const char *pcStmt, const STTVect<DbVal *> &);
#else
	STDbError Parse(const char *pcStmt, const STTVect(P_DbVal) &);
#endif

	STDbError Bind(DbVal *);
	STDbError Exec(long &nNumOfProcessedRows);
	STDbError Fetch();
	STDbError Describe(RWCString &strColName, DbVal *&rpDbVal);

	STDbError Error() const { return m_DbError; }

	DbTransactionOracle *m_pDbTransactionOracle;
	STDbError            m_DbError;
	Cda_Def              m_Cursor;
	int                  m_nDescribePos;
	int                  m_nBindPos;
	int                  m_bCursorOpen;
      
	/*
	 * lista che memorizza i DbVal da riempire nella Fetch
	 */
#ifndef NO_TEMPLATES
	STTVect<DbVal *>     m_DbStack;
#else 
	STTVect(P_DbVal)     m_DbStack;
#endif

	/*
	 * lista che contiene i 7 bytes che oracle scrivera' 
	 * nella fetch per memorizzare il risultato di un DbTS
	 */
#ifndef NO_TEMPLATES
	STTVect<uchar7>               m_DbStack_TS;
#else 
	STTVect(uchar7)               m_DbStack_TS;
#endif

#ifndef NO_TEMPLATES
	/*
	 * lista per indicare a oracle se il parametro nella where condition
	 * e' null oppure no
	 */
	STTVect<sb2>                  m_DbStack_Marker;

	/*
	 * lista per memorizzare i DbTS in formato oracle nelle where condition
	 */
	STTVect<uchar7>               m_DbStack_TSMarker;

	/*
	 * lista che oracle usera' per indicare se un campo e' null o valorizzato
	 */
	STTVect<sb2>                  m_DbStack_NULL;
#else 
	STTVect(sb2)                  m_DbStack_Marker;
	STTVect(uchar7)               m_DbStack_TSMarker;
	STTVect(sb2)                  m_DbStack_NULL;
#endif

	int m_bNeedReset;
};


#endif
