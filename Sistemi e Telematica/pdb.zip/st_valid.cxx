#include <st_dbnew.h>
/**************************************************************************

   Copyright (c) 1995

   Nome File:           st_valid.cpp
   Autore:              Marco Cresta / Vittorio Regestro / Gabriella Muratore
   Data:                21/6/95

   Class:               STValidator e derivate
   Eredita':


**************************************************************************/

#include <ctype.h>
#include "st_valid.h"
#include "st_dbdat.h"
#include "libdb_it.lnh"

/////////////////////////////////////////////////////////////////////////////
// CLASSE STValidator
/////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(STValidator, STRoot)
// classe astratta STImplementAssignClone(STValidator)

#ifdef DOS
STRoot * STValidator::STCreate()                const { return 0; }
STRoot * STValidator::STClone()                 const { return 0; }
void     STValidator::STAssign(const STRoot *)        {           }
#endif


STValidator::~STValidator()
{
}

STValidator::STValidator(const STValidator &)
{
}

void STValidator::operator = (const STValidator &)
{
}

int
STValidator::STIsEqual(const STRoot * p) const
{
	STValidator * ps = DynamicCast(STValidator *, p);
	if (ps == 0)
		return 0;
	else
		return 1;
}

/////////////////////////////////////////////////////////////////////////////
// CLASSE STValString
/////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(STValString, STValidator)
STImplementAssignClone(STValString)

STValString::STValString()
{
	itsMinLen = 0;
	itsMaxLen = STVALSTRING_MAX_LEN;
	itsCase = None;
}

STValString::STValString(int theMinLen, int theMaxLen)
{
	itsMinLen = theMinLen;
	itsMaxLen = theMaxLen;
	itsCase = None;
}

STValString::STValString(Case c, int theMinLen, int theMaxLen)
{
	itsMinLen = theMinLen;
	itsMaxLen = theMaxLen;
	itsCase   = c;
}

STValString::STValString(const STValString & r)
{
	itsMinLen = r.itsMinLen;
	itsMaxLen = r.itsMaxLen;
	itsCase   = r.itsCase;
}

void STValString::operator = (const STValString & r)
{
	itsMinLen = r.itsMinLen;
	itsMaxLen = r.itsMaxLen;
	itsCase   = r.itsCase;
}

int
STValString::STIsEqual(const STRoot * p) const
{
	STValString *ps = DynamicCast(STValString *, p);
	if (ps == 0)
		return 0;

	return itsMinLen == ps->itsMinLen && itsMaxLen == ps->itsMaxLen;
}

STDizWordKey
STValString::RunValidator(RWCString & theString)
{
	if ((int)theString.length() < itsMinLen)
		return MSG_LIBDB_STRTOOSHORT;

	if ((int)theString.length() > itsMaxLen)
		return MSG_LIBDB_STRTOOLONG;

	     if (itsCase == Lower) theString.toLower();
	else if (itsCase == Upper) theString.toUpper();

	const char *p = (const char*)theString;
	for (; *p; p++)
		if (*p != ' ' && *p != '\t')
			break;
	if (*p == '\0' && itsMinLen)
		return MSG_LIBDB_STRNULL;

	return MSG_LIBDB_NULL;
}

/////////////////////////////////////////////////////////////////////////////
// CLASSE STValNum
/////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(STValNum, STValidator)
STImplementAssignClone(STValNum)

STValNum::STValNum(STValNum::Op theOp, double theValue)
{
	itsOp = theOp;
	itsValue = theValue;
}

STValNum::STValNum()
{
}

STValNum::STValNum(const STValNum & r)
{
	itsOp = r.itsOp;
	itsValue = r.itsValue;
}

void STValNum::operator = (const STValNum & r)
{
	itsOp = r.itsOp;
	itsValue = r.itsValue;
}

int
STValNum::STIsEqual(const STRoot * p) const
{
	STValNum *ps = DynamicCast(STValNum *, p);
	if (ps == 0)
		return 0;

	return itsOp == ps->itsOp && itsValue == ps->itsValue;
}

STDizWordKey
STValNum::RunValidator(RWCString & theString)
{
	RWCString aString(theString);

	if (theString == "")
		return MSG_LIBDB_VALORE_NON_VALIDO;

	DbDouble a(20, 10);
	STDizWordKey w = a.UsrValidate(aString);
	if (w != MSG_LIBDB_NULL)
		return MSG_LIBDB_VALORE_NON_VALIDO;
	a.UsrSet(aString);

	switch (itsOp)
	{
	case GE:
		if (a >= itsValue) break;
		return MSG_LIBDB_VALORE_NON_VALIDO;
	case GT:
		if (a >  itsValue) break;
		return MSG_LIBDB_VALORE_NON_VALIDO;
	case LT:
		if (a <  itsValue) break;
		return MSG_LIBDB_VALORE_NON_VALIDO;
	case LE:
		if (a <= itsValue) break;
		return MSG_LIBDB_VALORE_NON_VALIDO;
	case EQ:
		if (a == itsValue) break;
		return MSG_LIBDB_VALORE_NON_VALIDO;
	case NE:
		if (a != itsValue) break;
		return MSG_LIBDB_VALORE_NON_VALIDO;
	}

	return MSG_LIBDB_NULL;
}


/////////////////////////////////////////////////////////////////////////////
// CLASSE STValCodFisc
/////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(STValCodFisc, STValidator)
STImplementAssignClone(STValCodFisc)

#define CODFISC_LEN 16

STValCodFisc::STValCodFisc()
{
}

STValCodFisc::STValCodFisc(const STValCodFisc &)
{
}

void STValCodFisc::operator = (const STValCodFisc &)
{
}

int
STValCodFisc::STIsEqual(const STRoot * p) const
{
	STValCodFisc * ps = DynamicCast(STValCodFisc *, p);
	if (ps == 0)
		return 0;
	else
		return 1;
}

STDizWordKey
STValCodFisc::RunValidator(RWCString & theCodFisc)
{
	theCodFisc.toUpper();


	static char mese[] = "ABCDEHLMPRST";

	typedef struct
	{
		char dato;
		int valore;
	} Conversione;

	static Conversione DecoPari[] =
	{
		'A', 0,  'B', 1,  'C', 2,  'D', 3,  'E', 4,  'F', 5,  'G', 6,
		'H', 7,  'I', 8,  'J', 9,  'K', 10, 'L', 11, 'M', 12, 'N', 13,
		'O', 14, 'P', 15, 'Q', 16, 'R', 17, 'S', 18, 'T', 19, 'U', 20,
		'V', 21, 'W', 22, 'X', 23, 'Y', 24, 'Z', 25, '0', 0,  '1', 1,
		'2', 2,  '3', 3,  '4', 4,  '5', 5,  '6', 6,  '7', 7,  '8', 8,  '9', 9
	};

	static Conversione DecoDispari[] =
	{
		'A', 1,  'B', 0,  'C', 5,  'D', 7,  'E', 9,  'F', 13, 'G', 15,
		'H', 17, 'I', 19, 'J', 21, 'K', 2,  'L', 4,  'M', 18, 'N', 20,
		'O', 11, 'P', 3,  'Q', 6,  'R', 8,  'S', 12, 'T', 14, 'U', 16,
		'V', 10, 'W', 22, 'X', 25, 'Y', 24, 'Z', 23, '0', 1,  '1', 0,
		'2', 5,  '3', 7,  '4', 9,  '5', 13, '6', 15, '7', 17, '8', 19, '9', 21
	};

	static Conversione CarControllo[] =
	{
		 0, 'A',  1, 'B',  2, 'C',  3, 'D',  4, 'E',  5, 'F',  6, 'G',
		 7, 'H',  8, 'I',  9, 'J', 10, 'K', 11, 'L', 12, 'M', 13, 'N',
		14, 'O', 15, 'P', 16, 'Q', 17, 'R', 18, 'S', 19, 'T', 20, 'U',
		21, 'V', 22, 'W', 23, 'X', 24, 'Y', 25, 'Z'
	};

	// e' ammesso un codice fiscale vuoto
	if (theCodFisc.isNull())
		return MSG_LIBDB_NULL;

	// controllo che il codice fiscale sia 16 caratteri
	if (theCodFisc.length() != CODFISC_LEN)
		return MSG_LIBDB_CODFISC_ERR_LEN;

	// controllo che i primi sei caratteri del codice fiscale siano lettere
	for (int i = 0; i < 6; i++)
	{
		if (!isalpha(((const char *)theCodFisc)[i]))
			return MSG_LIBDB_CODFISC_NOT_ALPHA;
	}

	// controllo che i successivi due caratteri del codice fiscale siano
	// numeri
	for (i = 6; i < 8; i++)
	{
		if (!isdigit(((const char *)theCodFisc)[i]))
			return MSG_LIBDB_CODFISC_NOT_NUM;
	}

	// controllo l'esattezza del mese
	for (i = 0; i < 12; i++)
		if (mese[i] == ((const char *)theCodFisc)[i])
			break;

	if (i > 12)
		return MSG_LIBDB_CODFISC_ERR_MONTH;

	// controllo esattezza del giorno
	char gg[3];
	gg[0] = ((const char *)theCodFisc)[9];
	gg[1] = ((const char *)theCodFisc)[10];
	gg[2] = 0;

	int giorno;
	giorno = atoi(gg);
	if (giorno < 1 || giorno > 71)
		return MSG_LIBDB_CODFISC_ERR_DAY;
	if (giorno > 31 && giorno < 41)
		return MSG_LIBDB_CODFISC_ERR_DAY;

	// controllo l'esattezza del codice fiscale
	int ctrdisp = 0;
	i = 0;
	int e = 0;

	while (i < 36 && e < 15)
	{
		if (((const char *)theCodFisc)[e] == DecoDispari[i].dato)
		{
			ctrdisp += DecoDispari[i].valore;
			e += 2;
			i = 0;
		}
		else
			i += 1;
	}

	if (i > 36)
		return MSG_LIBDB_CODFISC_ERR_CHECKSUM;

	int ctrpari = 0;
	i = 0;
	e = 1;

	while (i < 36 && e < 15)
	{
		if (((const char *)theCodFisc)[e] == DecoPari[i].dato)
		{
			ctrdisp += DecoPari[i].valore;
			e += 2;
			i = 0;
		}
		else
			i += 1;
	}

	if (i > 36)
		return MSG_LIBDB_CODFISC_ERR_CHECKSUM;

	ctrpari = ctrdisp / 26;
	ctrpari = ctrpari * 26;
	int res = ctrdisp - ctrpari;

	for (i = 0; i < 26; i++)
	{
		if (res == CarControllo[i].dato)
		{
			if (CarControllo[i].valore == ((const char *)theCodFisc)[15])
				return MSG_LIBDB_NULL;
		}
	}

	return MSG_LIBDB_CODFISC_ERR_CHECKSUM;
}

/////////////////////////////////////////////////////////////////////////////
// CLASSE STValPartIva
/////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(STValPartIva, STValidator)
STImplementAssignClone(STValPartIva)

#define PARIVA_LEN 11

STValPartIva::STValPartIva()
{
}

STValPartIva::STValPartIva(const STValPartIva &)
{
}

void STValPartIva::operator = (const STValPartIva &)
{
}

int
STValPartIva::STIsEqual(const STRoot * p) const
{
	STValPartIva * ps = DynamicCast(STValPartIva *, p);
	if (ps == 0)
		return 0;
	else
		return 1;
}

STDizWordKey
STValPartIva::RunValidator(RWCString & thePartIva)
{
	int i;

	// e' ammessa una partita IVA vuota
	if (thePartIva.isNull())
		return MSG_LIBDB_NULL;

	// controllo che la partita IVA sia 11 caratteri
	if (thePartIva.length() != PARIVA_LEN)
		return MSG_LIBDB_PARIVA_ERR_LEN;

	// controllo che tutti i caratteri della partita IVA siano numeri
	for (i = 0; i < PARIVA_LEN; i++)
		if (! isdigit(((const char *)thePartIva)[i]))
			return MSG_LIBDB_PARIVA_NOT_NUM;

	// controllo esattezza della partita IVA
	int ctrdisp = 0;

	for (i = 0; i < 10; i += 2)
		ctrdisp += ((const char *)thePartIva)[i] - '0';

	for (i = 1; i < 10; i += 2)
	{
		int ctrp = 2 * (((const char *)thePartIva)[i] - '0');
		ctrdisp += (ctrp / 10) + (ctrp % 10);
	}

	int res = (10 - (ctrdisp % 10)) % 10;
	if (res == ((const char *)thePartIva)[10] - '0')
		return MSG_LIBDB_NULL;

	return MSG_LIBDB_PARIVA_ERR_CHECKSUM;
}

/////////////////////////////////////////////////////////////////////////////
// CLASSE STValFlag
/////////////////////////////////////////////////////////////////////////////

STImplementClassInfo1(STValFlag, STValidator)
STImplementAssignClone(STValFlag)

STValFlag::STValFlag()
{
	itsRange = "";
}

STValFlag::STValFlag(const RWCString & theRange)
{
	itsRange = theRange;
}

STValFlag::STValFlag(Case c, const RWCString & theRange)
{
	itsRange = theRange;
	itsCase  = c;
}

STValFlag::STValFlag(const STValFlag & r)
{
	itsRange = r.itsRange;
	itsCase  = r.itsCase;
}

void STValFlag::operator = (const STValFlag & r)
{
	itsRange = r.itsRange;
	itsCase  = r.itsCase;
}

int
STValFlag::STIsEqual(const STRoot * p) const
{
	STValFlag *ps = DynamicCast(STValFlag *, p);
	if (ps == 0)
		return 0;

	return itsRange == ps->itsRange;
}

STDizWordKey
STValFlag::RunValidator(RWCString & theFlag)
{
	if (theFlag.length() != 1)
		return MSG_LIBDB_FLAG_ERR_LEN;

	if (itsRange.first(((const char *)theFlag)[0]) == RW_NPOS)
		return MSG_LIBDB_FLAG_OUT_OF_RANGE;

	     if (itsCase == Lower) theFlag.toLower();
	else if (itsCase == Upper) theFlag.toUpper();

	return MSG_LIBDB_NULL;
}


/////////////////////////////////////////////////////////////////////////////
// CLASSE STValTS
/////////////////////////////////////////////////////////////////////////////


STImplementClassInfo1(STValTS, STValidator)
STImplementAssignClone(STValTS)

STValTS::STValTS()
{
}

STValTS::STValTS(const RWCString &strFmt)
	: m_strFmt(strFmt)
{
}

STValTS::STValTS(const STValTS &r)
	: m_strFmt(r.m_strFmt)
{
}

void STValTS::operator = (const STValTS & r)
{
	m_strFmt = r.m_strFmt;
}

int
STValTS::STIsEqual(const STRoot * p) const
{
	STValTS *ps = DynamicCast(STValTS *, p);
	if (ps == 0)
		return 0;

	return m_strFmt == ps->m_strFmt;
}

STDizWordKey
STValTS::RunValidator(RWCString & theString)
{
	/* questo validatore e' quello di default solo che con questo
	   si puo' specificare il formato aspettato del TS */
	return STDizWordKey();
}


/////////////////////////////////////////////////////////////////////////////
// CLASSE STValAnd
/////////////////////////////////////////////////////////////////////////////


STImplementClassInfo1(STValAnd, STValidator)
STImplementAssignClone(STValAnd)

STValAnd::STValAnd()
{
	m_pValA = NULL;
	m_pValB = NULL;
}

STValAnd::~STValAnd()
{
	STDelete m_pValA;
	STDelete m_pValB;
}

STValAnd::STValAnd(STValidator *a, STValidator *b)
{
	m_pValA = a;
	m_pValB = b;
}

STValAnd::STValAnd(const STValAnd &r)
{
	m_pValA = DynamicCast(STValidator *, r.m_pValA->STClone());
	m_pValB = DynamicCast(STValidator *, r.m_pValB->STClone());
}

void STValAnd::operator = (const STValAnd & r)
{
	STDelete m_pValA;
	STDelete m_pValB;
	m_pValA = DynamicCast(STValidator *, r.m_pValA->STClone());
	m_pValB = DynamicCast(STValidator *, r.m_pValB->STClone());
}

int
STValAnd::STIsEqual(const STRoot * p) const
{
	STValAnd *ps = DynamicCast(STValAnd *, p);
	if (ps == 0)
		return 0;

	return m_pValA == ps->m_pValB;
}

STDizWordKey
STValAnd::RunValidator(RWCString & theString)
{
	STDizWordKey e = m_pValA->RunValidator(theString);

	return !e.IsOk() ? e : m_pValB->RunValidator(theString);
}



/////////////////////////////////////////////////////////////////////////////
// CLASSE STValOr
/////////////////////////////////////////////////////////////////////////////


STImplementClassInfo1(STValOr, STValidator)
STImplementAssignClone(STValOr)

STValOr::STValOr()
{
	m_pValA = NULL;
	m_pValB = NULL;
}

STValOr::~STValOr()
{
	STDelete m_pValA;
	STDelete m_pValB;
}

STValOr::STValOr(STValidator *a, STValidator *b)
{
	m_pValA = a;
	m_pValB = b;
}

STValOr::STValOr(const STValOr &r)
{
	m_pValA = DynamicCast(STValidator *, r.m_pValA->STClone());
	m_pValB = DynamicCast(STValidator *, r.m_pValB->STClone());
}

void STValOr::operator = (const STValOr & r)
{
	STDelete m_pValA;
	STDelete m_pValB;
	m_pValA = DynamicCast(STValidator *, r.m_pValA->STClone());
	m_pValB = DynamicCast(STValidator *, r.m_pValB->STClone());
}

int
STValOr::STIsEqual(const STRoot * p) const
{
	STValOr *ps = DynamicCast(STValOr *, p);
	if (ps == 0)
		return 0;

	return m_pValA == ps->m_pValB;
}

STDizWordKey
STValOr::RunValidator(RWCString & theString)
{
	STDizWordKey a = m_pValA->RunValidator(theString);
	STDizWordKey b = m_pValB->RunValidator(theString);

	return a.IsOk() ? STDizWordKey() : b;
}
