////////////////////////////////////////////////////////////////////////////////

class STDbConnectionData
{
public:
	virtual ~STDbConnectionData();
	virtual STDbError Login(const char *pcUser, const char *pcPasswd, const char *pcHost) = 0;
	virtual STDbError Logout() = 0;
	virtual STDbError Error() const = 0;
	virtual RWCString GetParameterMarker(int i) const = 0;
	virtual RWCString DbPrint(const DbVal *) const = 0;
};

class STDbTransactionData
{
public:
	STDbTransactionData(STDbConnectionData &p) : m_DbConnectionData(p) {}

	virtual ~STDbTransactionData();
	virtual STDbError BeginTransaction() = 0;
	virtual STDbError EndTransaction(STEndTransactionType)   = 0;

	virtual STDbError Error() const = 0;

	STDbConnectionData &m_DbConnectionData;

	RWCString DbPrint(const DbVal *p) const { return m_DbConnectionData.DbPrint(p); }
};

class STDbStmtData
{
public:
	STDbStmtData(STDbTransactionData &p) : m_DbTransactionData(p) {}

	virtual ~STDbStmtData();
	virtual STDbError Parse(const char *pcStmt) = 0;
#ifndef NO_TEMPLATES
	virtual STDbError Parse(const char *pcStmt, const STTVect<DbVal *> &) = 0;
#else
	virtual STDbError Parse(const char *pcStmt, const STTVect(P_DbVal) &) = 0;
#endif
	virtual STDbError Bind(DbVal *pDbVal) = 0;
	virtual STDbError Exec(long &nNumOfProcessedRows) = 0;
	virtual STDbError Fetch() = 0;
	virtual STDbError Describe(RWCString &strColName, DbVal *&rpDbVal) = 0;

	virtual STDbError Error() const = 0;

	RWCString DbPrint(const DbVal *p) const { return m_DbTransactionData.DbPrint(p); }

	STDbTransactionData &m_DbTransactionData;
};
