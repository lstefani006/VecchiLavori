// FILE LeoDB.cpp
// generato: Mon Jul 21 17:28:42 1997


#include <st_dbnew.h>
#include <st_dbxx.h>
#include <st_rel.h>
#include <st_dblst.h>
#include <st_selit.h>

#include "LeoDB.h"

#if defined(__DECCXX) && !defined(NO_TEMPLATES)
	#pragma define_template STTDbSlist<LeoDB *>
	#pragma define_template STTDbSlistIterator<LeoDB *>
#endif


#ifdef NO_TEMPLATES
	implement(STTDbSlist, P_LeoDB);
	implement(STTDbSlistIterator, P_LeoDB);
#endif // NO_TEMPLATES


void (*LeoDB::SetValidator)(LeoDB *) = NULL;

#ifndef NO_TEMPLATES
	static void __dummy__(STTDbSlist<LeoDB *>);
#endif

STRegisterDbClass(LeoDB, LeoDB_ClassId, STDbBase)

LeoDB::LeoDB()
	: STDbBase(0 /* dummy */),
	  f_char1(DbVal::NotNull),
	  f_char2(DbVal::Null),
	  f_date1(DbVal::Null),
	  f_date2(DbVal::Null),
	  f_date3(DbVal::Null),
	  f_number6(DbVal::Null, 6),
	  f_number2(DbVal::Null, 2),
	  f_varchar4(DbVal::Null, 4),
	  f_number11_9(DbVal::Null, 11, 9),
	  f_raw(DbVal::Null, 10)
{

	if (SetValidator != NULL)
		(*SetValidator)(this);
}


LeoDB::LeoDB(const LeoDB &r)
	: STDbBase(r),
	  f_char1(r.f_char1),
	  f_char2(r.f_char2),
	  f_date1(r.f_date1),
	  f_date2(r.f_date2),
	  f_date3(r.f_date3),
	  f_number6(r.f_number6),
	  f_number2(r.f_number2),
	  f_varchar4(r.f_varchar4),
	  f_number11_9(r.f_number11_9),
	  f_raw(r.f_raw)
{
}


void LeoDB:: operator = (const LeoDB &r)
{
	STDbBase::operator = (r);
	f_char1 = r.f_char1;
	f_char2 = r.f_char2;
	f_date1 = r.f_date1;
	f_date2 = r.f_date2;
	f_date3 = r.f_date3;
	f_number6 = r.f_number6;
	f_number2 = r.f_number2;
	f_varchar4 = r.f_varchar4;
	f_number11_9 = r.f_number11_9;
	f_raw = r.f_raw;
}


STDefineDbClass(LeoDB)
{
	STDbMap1   (LEO);
	STDbMap3Key(LeoDB, f_char1, f_char1);
	STDbMap3   (LeoDB, f_char2, f_char2);
	STDbMap3   (LeoDB, f_date1, f_date1);
	STDbMap3   (LeoDB, f_date2, f_date2);
	STDbMap3   (LeoDB, f_date3, f_date3);
	STDbMap3   (LeoDB, f_number6, f_number6);
	STDbMap3   (LeoDB, f_number2, f_number2);
	STDbMap3   (LeoDB, f_varchar4, f_varchar4);
	STDbMap3   (LeoDB, f_number11_9, f_number11_9);
	STDbMap3   (LeoDB, f_raw, f_raw);
}

