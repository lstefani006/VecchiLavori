// FILE LeoDB.h
// generato: Mon Jul 21 17:28:42 1997


#ifndef __LeoDB_h__
#define __LeoDB_h__

#include <st_err.h>
#include <st_dbxx.h>
#include <st_rel.h>
#include <st_dblst.h>
#include <st_selit.h>


class LeoDB : public STDbBase
{
public:

	static void (*SetValidator)(LeoDB *);

	struct STDbSetValidator
	{
		STDbSetValidator(void (*p)(LeoDB *)) { LeoDB::SetValidator = p; }
	};

	LeoDB();
	LeoDB(const LeoDB&);
	void operator = (const LeoDB&);
	
	// campi del db
	DbChar     f_char1;
	DbChar     f_char2;
	DbTS       f_date1;
	DbTS       f_date2;
	DbTS       f_date3;
	DbInt      f_number6;
	DbShort    f_number2;
	DbString   f_varchar4;
	DbDouble   f_number11_9;
	DbRaw      f_raw;

	STDeclareDbClass(LeoDB);
};



#ifdef NO_TEMPLATES
	#ifndef D_STTDbSlistP_LeoDB
		#define D_STTDbSlistP_LeoDB
		#define D_STTDbSlistIteratorP_LeoDB
		typedef LeoDB *P_LeoDB;
		declare(STTDbSlist, P_LeoDB);
		declare(STTDbSlistIterator, P_LeoDB);
		declare(STTDbSelectIterator, P_LeoDB);
	#endif
#endif // NO_TEMPLATES


#endif // __LeoDB__h
