#ifndef __ST_LINK_H__
#define __ST_LINK_H__

#include <st_dbnew.h>

/*
 * Classe wrapper che memorizza un puntatore e
 * lo dealloca qunado STLink va fuori scopo
 */
template <class T> class STLink
{
public:
	STLink(T *p)       { m_p = p; }
	~STLink()          { STDelete m_p; }
	T * Pt()           { return m_p; }
	T * operator -> () { return m_p; }

private:
	void operator = (T *);
	T *m_p;
};


#endif
