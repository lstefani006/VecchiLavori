#ifdef __AIX

#include <serlzer.h>

// Funzione in cui si usano i templates usati dalla
// libreria moses_cln.a

void ddd()
{
	VECT<mString> A;
	VECT<short>   B;
	VECT<long>    C;

	cout << A << B << C;
}

#endif
