#include <st_dbnew.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#ifdef    LINUX
#include <typeinfo.h>
#endif // LINUX

#include <iostream.h>

#include "stmt.h"

#ifdef __DECCXX
	extern "C" {
		#include <alloca.h>
	}
#endif

#include "value.h"

ValueScalar::ValueScalar(int sz)
{
	m_sz = sz;
	m_p = STNew char [m_sz + 1];
	memset(m_p, '\0', m_sz + 1);
}

ValueScalar::ValueScalar(const char *p)
{
	m_sz = strlen(p);
	m_p = STNew char [m_sz + 1];
	memcpy(m_p, p, m_sz + 1);
}

ValueScalar::ValueScalar(const char *p, int sz)
{
	m_sz = sz;
	m_p = STNew char [m_sz + 1];
	memcpy(m_p, p, m_sz);
	m_p[sz] = '\0';
}

ValueScalar::ValueScalar(const ValueScalar &r)
{
	m_sz = r.m_sz;
	m_p = STNew char [m_sz + 1];
	memcpy(m_p, r.m_p, m_sz + 1);
}

void ValueScalar::operator = (const ValueScalar &r)
{
	if (this == &r)
		return;

	STDelete m_p;

	m_sz = r.m_sz;
	m_p = STNew char [m_sz + 1];
	memcpy(m_p, r.m_p, m_sz + 1);
}

ValueRoot * ValueScalar::Clone() const
{
	return STNew ValueScalar(*this);
}

ValueScalar::~ValueScalar()
{
	STDelete [] m_p;
}

int ValueScalar::IsNum() const
{
	const char *p = m_p;

	if (*p == '+' || *p == '-')
		p++;

	int nNum = 0;
	while (*p >= '0' && *p <= '9')
	{
		nNum += 1;
		p++;
	}

	if (*p == '.')
	{
		p++;

		while (*p >= '0' && *p <= '9')
		{
			nNum += 1;
			p++;
		}
	}

	if (nNum == 0)
		return 0;

	if (*p == 'e' || *p == 'E')
	{
		p++;

		if (*p == '+' || *p == '-')
			p++;

		if (!(*p >= '0' && *p <= '9'))
			return 0;

		while (*p >= '0' && *p <= '9')
			p++;
	}

	if (*p)
		return 0;
	
	return (p - m_p) ? 1 : 0;
}

int ValueScalar::IsZero() const
{
	if (!IsNum())
		return 0;
	if (GetNum() == 0)
		return 1;
	return 0;
}

int ValueScalar::True()  const { return StrEq(m_p, "True"); }
int ValueScalar::False() const { return StrEq(m_p, "False"); }
int ValueScalar::IsBool() const { return True() || False(); }

void ValueScalar::Print(ostream &s) const
{
	s << m_p << flush;
}

Value operator == (const ValueScalar &a, const ValueScalar &b)
{
	if (a.IsNum() && b.IsNum())
	{
		if (a.GetNum() == b.GetNum())
			return Value("True");
		else
			return Value("False");
	}
	else
	{
		if (strcmp(a.GetChar(), b.GetChar()) == 0)
			return Value("True");
		else
			return Value("False");
	}
}

Value operator != (const ValueScalar &a, const ValueScalar &b)
{
	if (a.IsNum() && b.IsNum())
	{
		if (a.GetNum() != b.GetNum())
			return Value("True");
		else
			return Value("False");
	}
	else
	{
		if (strcmp(a.GetChar(), b.GetChar()) != 0)
			return Value("True");
		else
			return Value("False");
	}
}


////////////////////////////////////////////////////////////////////////////////

ValueArray::ValueArray()
{
}

ValueArray::ValueArray(const ValueArray &r)
{
	for (int i = 0; i < r.m_a.Size(); i++)
		m_a.Append(r.m_a[i]->Clone());
}

void ValueArray::operator = (const ValueArray &r)
{
	if (&r == this) 
		return;

	int i;

	for (i = 0; i < r.m_a.Size(); i++)
		STDelete m_a[i];
	m_a.Reset();

	for (i = 0; i < r.m_a.Size(); i++)
		m_a.Append(r.m_a[i]->Clone());
}                  

ValueArray::~ValueArray()
{
	for (int i = 0; i < m_a.Size(); i++)
		STDelete m_a[i];
}  

ValueRoot * ValueArray::Clone() const
{
	return STNew ValueArray(*this);
}

void ValueArray::ArrayPut(const Value &r)
{
	m_a.Append(r.Clone());
}

Value & ValueArray::ArrayGet(int i) const
{
	if (i < 0 || i >= m_a.Size())
	{
		cerr << "ArrayGet chiamato con gli indici errati\n";
		abort();
	}
	return *(m_a[i]);
}

void ValueArray::Print(ostream &s) const
{
	for (int i = 0; i < m_a.Size(); i++)
	{
		s << i+1 << "[";
		m_a[i]->Print(s);
		s << "] ";
	}
}

Value operator == (const ValueArray &a, const ValueArray &b)
{
	if (a.m_a.Size() != b.m_a.Size())
		return Value("False");

	for (int i = 0; i < a.m_a.Size(); i++)
		if (a.m_a[i] != b.m_a[i])
			return Value("False");

	return Value("True");
}

Value operator != (const ValueArray &a, const ValueArray &b)
{
	if (a.m_a.Size() != b.m_a.Size())
		return Value("True");

	for (int i = 0; i < a.m_a.Size(); i++)
		if (a.m_a[i] != b.m_a[i])
			return Value("True");

	return Value("False");
}

////////////////////////////////////////////////////////////////////////////////

ValueObject::ValueObject(const Object *pObjectType)
	: m_pObjectType(pObjectType)
{
	for (int i = 0; i < m_pObjectType->GetNumOfMembers(); i++)
		m_a.Append(STNew Value);
}

ValueObject::ValueObject(const ValueObject &r)
{
	m_pObjectType = r.m_pObjectType;
	for (int i = 0; i < r.m_a.Size(); i++)
		m_a.Append(r.m_a[i]->Clone());
}

void ValueObject::operator = (const ValueObject &r)
{
	if (&r == this) 
		return;

	int i;
	for (i = 0; i < m_a.Size(); i++)
		STDelete m_a[i];
	m_a.Reset();

	m_pObjectType = r.m_pObjectType;
	for (i = 0; i < r.m_a.Size(); i++)
		m_a.Append(r.m_a[i]->Clone());
}                  

ValueObject::~ValueObject()
{
	for (int i = 0; i < m_a.Size(); i++)
		STDelete m_a[i];
}  

ValueRoot * ValueObject::Clone() const
{
	return STNew ValueObject(*this);
}

Value * ValueObject::GetField(const char *pFieldName)
{
	int i = m_pObjectType->GetIndexOf(pFieldName);

	if (i == -1)
		return NULL;

	return m_a[i];
}

void ValueObject::Print(ostream &s) const
{
	for (int i = 0; i < m_a.Size(); i++)
	{
		s << m_pObjectType->GetFieldName(i) << "[";
		m_a[i]->Print(s);
		s << "] ";
	}
}
 
Value operator == (const ValueObject &a, const ValueObject &b)
{
	if (&a == &b)
		return Value("True");
	else
		return Value("False");
}
Value operator != (const ValueObject &a, const ValueObject &b)
{
	if (&a != &b)
		return Value("True");
	else
		return Value("False");
}

////////////////////////////////////////////////////////////////////////////////

#ifdef __DECCXX
#pragma define_template STTVect<Value>
#endif

Value::Value(int sz)
{
	m_pV = STNew ValueScalar(sz);
}

Value::Value()
{
	m_pV = STNew ValueScalar("");
}

Value::Value(Value::Type t, const class Object *pObjectType)
{
	switch (t)
	{
		case Scalar:
			m_pV = STNew ValueScalar("");
			break;
		case Array:
			m_pV = STNew ValueArray();
			break;
		case Object:
			m_pV = STNew ValueObject(pObjectType);
			m_pV->IncOwners();
			break;
		default:
			cerr << "Unknow Value::Type\n";
			break;
	}
}

Value::Value(const char *p)
{
	m_pV = STNew ValueScalar(p);
}

Value::Value(const char *p, int sz)
{
	m_pV = STNew ValueScalar(p, sz);
}

Value::Value(const Value &r)
{
	if (r.IsObject())
	{
		m_pV = r.m_pV;
		m_pV->IncOwners();
	}
	else
		m_pV = r.m_pV->Clone();
}

Value * Value::Clone() const
{
	return STNew Value(*this);
}



void Value::operator = (const Value &r)
{
	if (this == &r)
		return;

	if (m_pV == r.m_pV)
		return;

	if (!IsObject())
	{
		STDelete m_pV;
	}
	else
	{
		int n = m_pV->DecOwners();
		if (n == 0)
			STDelete m_pV;
	}

	if (!r.IsObject())
	{
		m_pV = r.m_pV->Clone();
	}
	else
	{
		m_pV = r.m_pV;
		m_pV->IncOwners();
	}
}


Value::~Value()
{
	if (!IsObject())
		STDelete m_pV;
	else
	{
		int r = m_pV->DecOwners();
		if (r == 0)
			STDelete m_pV;
	}
	m_pV = NULL;
}

// ARRAY
void Value::ArrayPut(const Value &v)
{
	ValueArray *pA = NULL;
	if (m_pV->IsArray())
		pA = (ValueArray *)m_pV;


	if (pA == NULL)
		m_pV = pA = STNew ValueArray();

	pA->ArrayPut(v);
}

// ARRAY
Value & Value::ArrayGet(int i) const
{
	ValueArray *pA = NULL;
	if (m_pV->IsArray())
		pA = (ValueArray *)m_pV;

	if (pA == NULL)
		pA = STNew ValueArray();

	if (pA == NULL)
	{
		cerr << "Chiamo ArrayGet senza un array\n";
    	abort();
	}

	return pA->ArrayGet(i);
}

double Value::GetNum() const
{
	if (m_pV->IsNum())
		return m_pV->GetNum();
   return 0;
}

int Value::True()  const { return m_pV->IsBool() ? ((ValueScalar *)m_pV)->True() : 0; }
int Value::False() const { return m_pV->IsBool() ? ((ValueScalar *)m_pV)->False() : 0; }


int Value::IsZero() const
{
	if (m_pV->IsNum())
		return m_pV->GetNum() == 0;
	return 0;
}

////////////////////////////////////////////////////////////////

class StrMem
{
public:
	StrMem(int sz) { p = STNew char [sz]; }
	~StrMem() { STDelete [] p; }
	char *p;
};

Value operator & (const Value &a, const Value &b)
{
	if (a.IsString() && b.IsString())
	{
		const ValueScalar *pA = (const ValueScalar *)(a.m_pV);
		const ValueScalar *pB = (const ValueScalar *)(b.m_pV);

		StrMem p(pA->Len() + pB->Len() + 1);
		strcpy(p.p, a.GetChar());
		strcat(p.p, b.GetChar());
		return Value(p.p);
	}

	return Value();
}

Value operator + (const Value &a, const Value &b)
{
	if (!(a.IsNum() && b.IsNum()))
		return Value();

	char buff[100];    
	sprintf(buff, "%g", a.GetNum() + b.GetNum());
	return Value(buff);
}

Value operator - (const Value &a, const Value &b)
{
	if (!(a.IsNum() && b.IsNum()))
		return Value();

	const ValueScalar *pA = (const ValueScalar *)(a.m_pV);
	const ValueScalar *pB = (const ValueScalar *)(b.m_pV);

	char buff[100];    
	sprintf(buff, "%g", pA->GetNum() - pB->GetNum());
	return Value(buff);
}

Value operator * (const Value &a, const Value &b)
{
	if (!(a.IsNum() && b.IsNum()))
		return Value();

	char buff[100];    
	sprintf(buff, "%g", a.GetNum() * b.GetNum());
	return Value(buff);
}

Value operator / (const Value &a, const Value &b)
{
	if (!(a.IsNum() && b.IsNum()))
		return Value();

	char buff[100];    
	sprintf(buff, "%g", a.GetNum() / b.GetNum());
	return Value(buff);
}

Value operator > (const Value &a, const Value &b)
{
	if (a.IsNum() && b.IsNum())
	{
		if (a.GetNum() > b.GetNum())
			return Value("True");
		else
			return Value("False");
	}
	else
	if (a.IsString() && b.IsString())
	{
		if (strcmp(a.GetChar(), b.GetChar()) > 0)
			return Value("True");
		else
			return Value("False");
	}
	else
		return Value("");
}

Value operator >= (const Value &a, const Value &b)
{
	if (a.IsNum() && b.IsNum())
	{
		if (a.GetNum() >= b.GetNum())
			return Value("True");
		else
			return Value("False");
	}
	else
	if (a.IsString() && b.IsString())
	{
		if (strcmp(a.GetChar(), b.GetChar()) >= 0)
			return Value("True");
		else
			return Value("False");
	}
	else
		return Value("");
}

Value operator < (const Value &a, const Value &b)
{
	if (a.IsNum() && b.IsNum())
	{
		if (a.GetNum() < b.GetNum())
			return Value("True");
		else
			return Value("False");
	}
	else
	if (a.IsString() && b.IsString())
	{
		if (strcmp(a.GetChar(), b.GetChar()) < 0)
			return Value("True");
		else
			return Value("False");
	}
	else
		return Value("");
}

Value operator <= (const Value &a, const Value &b)
{
	if (a.IsNum() && b.IsNum())
	{
		if (a.GetNum() <= b.GetNum())
			return Value("True");
		else
			return Value("False");
	}
	else
	if (a.IsString() && b.IsString())
	{
		if (strcmp(a.GetChar(), b.GetChar()) <= 0)
			return Value("True");
		else
			return Value("False");
	}
	else
		return Value("");
}

Value operator == (const Value &a, const Value &b)
{
	if (a.IsString() && b.IsString())
	{
		return ((ValueScalar &)*(a.m_pV)) == ((ValueScalar &)*(b.m_pV));
	}
	else
	if (a.IsObject() && b.IsObject())
	{
		return ((ValueObject &)*(a.m_pV)) == ((ValueObject &)*(b.m_pV));
	}
	else
	if (a.IsArray() && b.IsArray())
	{
		return ((ValueArray &)*(a.m_pV)) == ((ValueArray &)*(b.m_pV));
	}
	else
		return Value("False");
}

Value operator != (const Value &a, const Value &b)
{
	if (a.IsString() && b.IsString())
	{
		return ((ValueScalar &)*(a.m_pV)) != ((ValueScalar &)*(b.m_pV));
	}
	else
	if (a.IsObject() && b.IsObject())
	{
		return ((ValueObject &)*(a.m_pV)) != ((ValueObject &)*(b.m_pV));
	}
	else
	if (a.IsArray() && b.IsArray())
	{
		return ((ValueArray &)*(a.m_pV)) == ((ValueArray &)*(b.m_pV));
	}
	else
		return Value("False");
}

Value operator || (const Value &a, const Value &b)
{
	return Value((a.True() || b.True()) ? "True" : "False");
}

Value operator && (const Value &a, const Value &b)
{
	return Value((a.True() && b.True()) ? "True" : "False");
}

Value operator ! (const Value &a)
{
	return Value(a.False() ? "True" : "False");
}

Value operator - (const Value &a)
{
	if (a.IsNum())
	{
		char buff[100];
		sprintf(buff, "%g", -(a.GetNum()));
		return Value(buff);
	}
	else
		return Value("");
}


Value Len(const Value &a)
{
	if (a.IsString())
	{
		char buff[100];
		sprintf(buff, "%d", a.Len());
		return Value(buff);
	}
	else
		return Value("");
}

Value Dim(const Value &a)
{
	if (a.IsArray())
	{
		char buff[100];
		sprintf(buff, "%d", a.Dim());
		return Value(buff);
	}
	else
		return Value("0");
}


Value Sub(const Value &str, const Value &a, const Value &b)
{
	if (!(a.IsNum() && b.IsNum()))
		return Value("");

	int ia = (int) a.GetNum();
	int ib = (int) b.GetNum();

	if (!str.IsArray())
	{
		StrMem buff(ib - ia + 2);

		strncpy(buff.p, str.GetChar() + ia - 1, ib - ia + 1);
		buff.p[ib - ia + 1] = 0;
		return Value(buff.p);
	}
	else
	{
		if (ia == ib)
			return str.ArrayGet(ia - 1);
		
		Value v;

		for (int i = ia; i <= ib; i++)
			v.ArrayPut(str.ArrayGet(i - 1));
		
		return v;
	}
}
