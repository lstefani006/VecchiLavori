#include <st_dbnew.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "p.h"
#include "symtb.h"


int StrEq(const char *a, const char *b)
{
	for (;;)
	{
		char ca = tolower(*a);
		char cb = tolower(*b);

		if (ca != cb)
			return 0;

		if (ca == '\0')
			return 1;

		a++;
		b++;
	}
}


SymbolTable::SymbolTable()
{
	m_sz     = 0;
	m_pName  = NULL;
}

void SymbolTable::Insert(Src s, const char *Name)
{
	Value e("");
	Insert(s, Name, e);
}

void SymbolTable::Insert(Src s, const char *Name, const Value &r)
{
	for (int i = 0; i < m_sz; i++)
		if (StrEq(m_pName[i], Name))
			RunTimeError(s, "\"%s\" duplicated variable", Name);

	m_sz += 1;

	m_pName  = (char **) realloc(m_pName,  m_sz * sizeof(char *));

	m_pName [m_sz - 1] = strdup(Name);
	m_aValue.Append(r);
}

Value & SymbolTable::Assign(Src s, const char *Name)
{
	for (int i = 0; i < m_sz; i++)
		if (StrEq(m_pName[i], Name))
			return m_aValue[i];
	
	RunTimeError(s, "\"%s\" variable not found", Name);
	return m_aValue[0];
}

Value SymbolTable::Search(Src s, const char *Name)
{
	for (int i = 0; i < m_sz; i++)
		if (StrEq(m_pName[i], Name))
			return m_aValue[i];

	RunTimeError(s, "\"%s\" variable/function not found", Name);
	return Value("");
}


SymbolTable::~SymbolTable()
{
	for (int i = 0; i < m_sz; i++)
		free(m_pName[i]);
	free(m_pName);
}

////////////////////////////////////////////////////////////////////////////////

SymbolTable_Program::SymbolTable_Program()
{
}

void SymbolTable_Program::Add(External *p)
{
	for (int i = 0; i < m_lst.Size(); i++)
		if (StrEq(m_lst[i]->Name(), p->Name()))
			RunTimeError(p->GetSrc(), "duplicate function");
	m_lst.Append(p);
}

Function * SymbolTable_Program::SearchFunction(const char *pName, const char *pObjType)
{
	char b[1024];
	b[0] = '\0';
	if (pObjType)
	{
		strcat(b, pObjType);
		strcat(b, ".");
	}
	strcat(b, pName);

	for (int i = 0; i < m_lst.Size(); i++)
		if (StrEq(m_lst[i]->Name(), b))
		{
			if (m_lst[i]->IsFunction())
				return (Function *) m_lst[i];
			return NULL;
		}

	return NULL;
}


Object * SymbolTable_Program::SearchObject(const char *pName)
{
	for (int i = 0; i < m_lst.Size(); i++)
		if (StrEq(m_lst[i]->Name(), pName))
		{
			if (m_lst[i]->IsObject())
				return (Object *) m_lst[i];
			return NULL;
		}

	return NULL;
}
