#include <st_dbnew.h>
#ifndef __VALUE_H__
#define __VALUE_H__

#include <iostream.h>

#include <string.h>
#include "st_tvect.h"

class Value;
class Object;

class ValueRoot
{
public:
	ValueRoot() { m_Ref = 0; }
	virtual ~ValueRoot()
	{
		if (m_Ref != 0)
		{

			cerr << "Delete mRef!=0";
			exit(1);
		}
	}
	
	virtual ValueRoot * Clone() const = 0;

	virtual int Len()       const = 0;
	virtual int Dim()       const = 0;
	virtual int IsNum()     const = 0;
	virtual int IsBool()    const = 0;
	virtual int IsString()  const = 0;
	virtual int IsArray()   const = 0;
	virtual const Object * IsObject() const = 0;

	virtual const char * GetChar()   const { return NULL; }
	virtual double       GetNum() const { return 0.0; }
	virtual Value *      GetField(const char *) { return NULL; }

	int DecOwners() { return --m_Ref; }
	int IncOwners() { return ++m_Ref; }

	virtual void Print(ostream &) const = 0;


private:
	int m_Ref;
};

/*
 * array di caratteri:
 *   vengono allocati m_sz + 1 caratteri per cui e` sempre garantito lo '\0' terminatore
 *   sia per strighe che per buffer
 *   - stringa ascii zero terminata -- m_sz ritorna il num di chars eccetto '\0' (strlen())
 *   - buffer di memoria --- memoria di m_sz bytes; comunque c'e` un carattere in piu` che contiene '\0'
 */
class ValueScalar : public ValueRoot
{
public:
	ValueScalar(int sz);
	ValueScalar(const char *p);
	ValueScalar(const char *p, int sz);
	ValueScalar(const ValueScalar &r);
	~ValueScalar();
	void operator = (const ValueScalar &);
	ValueRoot * Clone() const;

	int Len()       const { return m_sz; }
	int Dim()       const { return 0; }
	int IsNum()     const;
	int IsBool()    const;
	int IsString()  const { return 1; }
	int IsArray()   const { return 0; }
	const Object * IsObject() const { return 0; }
	
	int True()      const;
	int False()     const;
	int IsZero()    const;

	double GetNum() const { return atof(m_p); }
	const char *GetChar()   const { return m_p; }

	void Print(ostream &s) const;
protected:                                       
	char *m_p;
	int   m_sz; //
};

class ValueArray : public ValueRoot
{
public:
	ValueArray();
	~ValueArray();
	ValueArray(const ValueArray &);
	void operator = (const ValueArray &);
	ValueRoot * Clone() const;

	int Len()       const { return 0; }
	int Dim()       const { return m_a.Size(); }
	int IsNum()     const { return 0; }
	int IsBool()    const { return 0; }
	int IsString()  const { return 0; }
	int IsArray()   const { return 1; }
	const Object * IsObject()  const { return 0; }

	void    ArrayPut(const Value &);
	Value & ArrayGet(int i) const;

	void Print(ostream &s) const;

	friend Value operator == (const ValueArray &a, const ValueArray &b);
	friend Value operator != (const ValueArray &a, const ValueArray &b);
	
protected:
	STTVect<Value *> m_a;
};


class ValueObject : public ValueRoot
{
public:
	ValueObject(const class Object *);
	ValueObject(const ValueObject &);
	~ValueObject();
	void operator = (const ValueObject &);
	ValueRoot * Clone() const;

	int Len()       const { return 0; }
	int Dim()       const { return 0; }
	int IsNum()     const { return 0; }
	int IsBool()    const { return 0; }
	int IsString()  const { return 0; }
	int IsArray()   const { return 0; }
	const Object * IsObject()  const { return m_pObjectType; }
	virtual Value * GetField(const char *FieldName);

	void Print(ostream &s) const;

	friend Value operator == (const ValueArray &a, const ValueArray &b);
	friend Value operator != (const ValueArray &a, const ValueArray &b);
	
protected:
	const Object * m_pObjectType;
	STTVect<Value *> m_a;
};

class Value
{
public:
	enum Type { Scalar, Array, Object };
	Value(Type, const class Object * = NULL);
	
	Value();
	Value(const char *p);
	Value(const char *p, int sz);
	Value(const Value &);
	~Value();
	void operator = (const Value &);
	Value * Clone() const;

	int Len() const { return m_pV->Len(); }
	int Dim() const { return m_pV->Dim(); }

	int IsNum()     const { return m_pV->IsNum();    }
	int IsBool()    const { return m_pV->IsBool();   }
	int IsString()  const { return m_pV->IsString(); }
	int IsArray()   const { return m_pV->IsArray();  }
	const class Object * IsObject() const { return m_pV->IsObject(); }

	int True()      const;
	int False()     const;

	int IsZero()    const;
	double GetNum() const;

	friend Value operator &  (const Value &a, const Value &b);
	friend Value operator +  (const Value &a, const Value &b);
	friend Value operator -  (const Value &a, const Value &b);
	friend Value operator *  (const Value &a, const Value &b);
	friend Value operator /  (const Value &a, const Value &b);
	friend Value operator >  (const Value &a, const Value &b);
	friend Value operator >= (const Value &a, const Value &b);
	friend Value operator <  (const Value &a, const Value &b);
	friend Value operator <= (const Value &a, const Value &b);
	friend Value operator == (const Value &a, const Value &b);
	friend Value operator != (const Value &a, const Value &b);
	friend Value operator || (const Value &a, const Value &b);
	friend Value operator && (const Value &a, const Value &b);
	friend Value operator !  (const Value &a);
	friend Value operator -  (const Value &a);

	friend Value Len(const Value &);
	friend Value Dim(const Value &);
	friend Value Sub(const Value &, const Value &, const Value &);

	const char * GetString() const { return m_pV->GetChar(); }
	const char * GetChar()   const { return m_pV->GetChar(); }

	void    ArrayPut(const Value &);
	Value & ArrayGet(int i) const;

	Value * GetField(const char *FieldName) { return m_pV->GetField(FieldName); }

	void Print(ostream &s) { m_pV->Print(s); }

protected:
	Value(int sz);

	ValueRoot *m_pV;
};


#endif

