#include <st_dbnew.h>

#include <stdio.h>

#ifndef _WIN32
#include <strstream.h>
#else
#include <strstrea.h>
#endif


#include <mdir.h>

#include <native.h>

void File_Open(SymbolTable &l)
{
	Src s;

	const char *Name = l.Assign(s, "Name").GetString();
	const char *Mode = l.Assign(s, "Mode").GetString();

	FILE *f = ::fopen(Name, Mode);
	if (f == NULL)
		throw Value("False");

	Value *Self = &l.Assign(s, "Self");

	char b[20]; sprintf(b, "%p", f);
	*Self->GetField("f") = Value(b);

	throw Value("True");
}

static Native file_Open("File.Open", File_Open);

///////////////////////////////////////////////////////////////////////////

void File_Close(SymbolTable &l)
{
	Src s;

	FILE *f;
	Value *Self = &l.Assign(s, "Self");
	const char *p = Self->GetField("f")->GetString();
	sscanf(p, "%p", &f);


	int r = ::fclose(f);
	if (r == 0)
		throw Value("True");
	else
		throw Value("False");
}

static Native file_Close("File.Close", File_Close);

///////////////////////////////////////////////////////////////////////////

void File_ReadChar(SymbolTable &l)
{
	Src s;

	FILE *f;
	Value *Self = &l.Assign(s, "Self");
	const char *p = Self->GetField("f")->GetString();
	sscanf(p, "%p", &f);

	int r = ::fgetc(f);
	if (r == EOF)
		throw Value("False");
	else
	{
		char b[2];
		b[0] = r;
		b[1] = '\0';

		l.Assign(s, "C") = Value(b);

		throw Value("True");
	}
}

static Native file_ReadChar("File.ReadChar", File_ReadChar);

///////////////////////////////////////////////////////////////////////////
void File_ReadInt(SymbolTable &l)
{
	Src s;

	FILE *f;
	Value *Self = &l.Assign(s, "Self");
	const char *p = Self->GetField("f")->GetString();
	sscanf(p, "%p", &f);

	int n;
	int r = ::fscanf(f, "%d", &n);
	if (r == EOF)
		throw Value("False");
	else
	{
		char b[20];
		sprintf(b, "%d", n);
		l.Assign(s, "N") = Value(b);

		throw Value("True");
	}
}

static Native file_ReadInt("File.ReadInt", File_ReadInt);

///////////////////////////////////////////////////////////////////////////
void File_ReadReal(SymbolTable &l)
{
	Src s;

	FILE *f;
	Value *Self = &l.Assign(s, "Self");
	const char *p = Self->GetField("f")->GetString();
	sscanf(p, "%p", &f);

	double n;
	int r = ::fscanf(f, "%g", &n);
	if (r == EOF)
		throw Value("False");
	else
	{
		char b[20];
		sprintf(b, "%g", n);
		l.Assign(s, "R") = Value(b);

		throw Value("True");
	}
}

static Native file_ReadReal("File.ReadReal", File_ReadReal);

///////////////////////////////////////////////////////////////////////////
void File_ReadLine(SymbolTable &l)
{
	Src s;

	FILE *f;
	Value *Self = &l.Assign(s, "Self");
	const char *p = Self->GetField("f")->GetString();
	sscanf(p, "%p", &f);

	char *c = STNew char [1024 * 64];
	char *r = ::fgets(c, 1024*64, f); 
	if (r == NULL)
	{
		throw Value("False");
		STDelete [] c;
	}
	else
	{
		l.Assign(s, "L") = Value(c);
		STDelete [] c;
		throw Value("True");
	}
}

static Native file_ReadLine("File.ReadLine", File_ReadLine);

///////////////////////////////////////////////////////////////////////////
void File_ReadAll(SymbolTable &l)
{
	Src s;

	FILE *f;
	Value *Self = &l.Assign(s, "Self");
	{
	const char *p = Self->GetField("f")->GetString();
	sscanf(p, "%p", &f);
	}

	int szBuff = 1024*1024;
	char *c = (char *)malloc(szBuff);
	char *p = c;

	for (;;)
	{
		size_t sz = fread(p, 1, 1024 * 1024, f);
		p += sz;

		if (sz == 0)
			break;

		if (sz < 1024 * 1024)
			break;

		szBuff = szBuff * 2;
		sz = p - c;
		c = (char *)realloc(c, szBuff);
		p = c + sz;
	}

	if (ferror(f))
	{
		free(c);
		throw Value("False");
	}
	else
	{
		l.Assign(s, "Body") = Value(c, p - c);
		free(c);
		throw Value("True");
	}
}

static Native file_ReadAll("File.ReadAll", File_ReadAll);

///////////////////////////////////////////////////////////////////////////

void File_WriteVar(SymbolTable &l)
{
	Src s;

	FILE *f;
	Value *Self = &l.Assign(s, "Self");
	const char *p = Self->GetField("f")->GetString();
	sscanf(p, "%p", &f);

	const char *c = l.Assign(s, "V").GetString();

	::fprintf(f, "%s", c);
	throw Value("True");
}

static Native file_WriteVar("File.WriteVar", File_WriteVar);

///////////////////////////////////////////////////////////////////////////

void File_WriteAll(SymbolTable &l)
{
	Src s;

	FILE *f;
	Value *Self = &l.Assign(s, "Self");
	const char *p = Self->GetField("f")->GetString();
	sscanf(p, "%p", &f);

	const char *c = l.Assign(s, "Body").GetString();
	int len       = l.Assign(s, "Body").Len();

	::fwrite(c, 1, len, f);
	throw Value("True");
}

static Native file_WriteAll("File.WriteAll", File_WriteAll);




///////////////////////////////////////////////////////////////////////////

static void rMkDir(SymbolTable &l)
{
	Src s;
	const char *pPath = l.Assign(s, "Path").GetString();
	int e = MkDir(pPath);
	if (e)
		throw Value("True");
	else
		throw Value("False");
}
static Native sMkDir("MkDir", rMkDir);

static void rRmDir(SymbolTable &l)
{
	Src s;
	const char *pPath = l.Assign(s, "Path").GetString();
	int e = RmDir(pPath , 0);
	if (e)
		throw Value("True");
	else
		throw Value("False");
}
static Native sRmDir("RmDir", rRmDir);

///////////////////////////////////////////////////////////////////////////

static void Dir_SetThis(mDirectory *v, Src &s, SymbolTable &l)
{
    char b[20];
    sprintf(b, "%p", v);
    *(l.Assign(s, "Self").GetField("v")) = Value(b);
}

static mDirectory *Dir_GetThis(Src &s, SymbolTable &l)
{
    const char *p = l.Assign(s, "Self").GetField("v")->GetString();
    mDirectory *pmDirectory;
    sscanf(p, "%p", &pmDirectory);
    return pmDirectory;
}


static void Dir_Open(SymbolTable &l)
{
	Src s;

	mDirectory *v = STNew mDirectory;
	Dir_SetThis(v, s, l);

	const char *pPath = l.Search(s, "Path").GetString();

	STRING e = v->Open(pPath);

	if (e.Len() == 0)
		throw Value("True");
	else
		throw Value("False");
}
static Native sDir_Open("Directory.Open", Dir_Open);

static void Dir_GetNext(SymbolTable &l)
{
	Src s;

	mDirectory *v = Dir_GetThis(s, l);

	STRING FileName;
	INT32  Size;
	STRING DateLastChange;
	INT16  bDirectory;

	int e = v->GetNext(FileName, Size, DateLastChange, bDirectory);

	if (!e)
		throw Value("False");

	l.Assign(s, "FileName")       = Value(FileName.Str());
	l.Assign(s, "DateLastChange") = Value(DateLastChange.Str());

	{
		char b[100];
		ostrstream ss(b, sizeof(b));
		ss << Size << ends;
		l.Assign(s, "Size") = Value(b);
	}

	if (bDirectory)
		l.Assign(s, "bDirectory") = Value("True");
	else
		l.Assign(s, "bDirectory") = Value("False");

	throw Value("True");
}
static Native sDir_GetNext("Directory.GetNext", Dir_GetNext);

static void Dir_Close(SymbolTable &l)
{
	Src s;
	mDirectory *v = Dir_GetThis(s, l);
	STDelete v;
	throw Value("True");
}
static Native sDir_Close("Directory.Close", Dir_Close);
