#include <st_dbnew.h>
#include <stdio.h>

#include <mprocess.h>
#include <native.h>

static void SetThis(mProcess *v, Src &s, SymbolTable &l)
{
	char b[20];
	sprintf(b, "%p", v);
	*(l.Assign(s, "Self").GetField("v")) = Value(b);
}

static mProcess *GetThis(Src &s, SymbolTable &l)
{
	const char *p = l.Assign(s, "Self").GetField("v")->GetString();
	mProcess *pmProcess;
	sscanf(p, "%p", &pmProcess);
	return pmProcess;
}

void Process_Run(SymbolTable &l)
{
	Src s;

	mProcess *v = STNew mProcess;
	SetThis(v, s, l);

	const char *pCommand = l.Search(s, "Command").GetString();

	int e = v->Run(pCommand);
	
	if (e)
		throw Value("True");
	else
		throw Value("False");
}
static Native sProcess_Run("Process.Run", Process_Run);
////////////////////////////////////////////////////////////////////////


void Process_Kill(SymbolTable &l)
{
	Src s;

	mProcess *v = GetThis(s, l);

	int e = v->Kill();

	if (e)
		throw Value("True");
	else
		throw Value("False");
}
static Native sProcess_Kill("Process.Kill", Process_Kill);

///////////////////////////////////////////////////////////////////////////

void Process_Wait(SymbolTable &l)
{
	Src s;

	mProcess *v = GetThis(s, l);

	Value *vExitCode = &l.Assign(s, "ExitCode");

	int ExitCode;
	int e = v->Wait(ExitCode);
	if (e == 0)
		throw Value("False");

	char b[10]; sprintf(b, "%d", ExitCode);
	*vExitCode = Value(b);

	throw Value("True");
}
static Native sProcess_Wait("Process.Wait", Process_Wait);

////////////////////////////////////////////////////////////////////////

void Process_IsRunning(SymbolTable &l)
{
	Src s;
	mProcess *v = GetThis(s, l);

	int e = v->IsRunning();
	if (e == 0)
		throw Value("False");
	else
		throw Value("True");
}
static Native sProcess_IsRunning("Process.IsRunning", Process_IsRunning);

////////////////////////////////////////////////////////////////////////

void Process_GetPid(SymbolTable &l)
{
	Src s;

	mProcess *v = GetThis(s, l);

	int pid = v->GetPid();
	char b[20]; sprintf(b, "%d", pid);
	throw Value(b);
}
static Native sProcess_GetPid("Process.GetPid", Process_GetPid);

////////////////////////////////////////////////////////////////////////

void Process_SetPid(SymbolTable &l)
{
	Src s;

	mProcess *v = GetThis(s, l);

	Value *vPid = &l.Assign(s, "Pid");

	v->SetPid(vPid->GetNum());
	throw Value("True");
}
static Native sProcess_SetPid("Process.SetPid", Process_SetPid);

////////////////////////////////////////////////////////////////////////

void Process_Release(SymbolTable &l)
{
	Src s;

	mProcess *v = GetThis(s, l);

	STDelete v;

	throw Value("True");
}
static Native sProcess_Release("Process.Release", Process_Release);
