#include <st_dbnew.h>
#include <stdio.h>

#include <native.h>
#include <tcp_net.h>

void TcpClient_Init(SymbolTable &l)
{
	Src s;
	Value *Self = &l.Assign(s, "Self");

	TcpClient *p = STNew TcpClient;
	char b[20]; sprintf(b, "%p", p);
	*Self->GetField("v")          = Value(b);

	*Self->GetField("ServerName") = l.Search(s, "ServerName");
	*Self->GetField("Port")       = l.Search(s, "Port");

	const char *pServer = l.Search(s, "ServerName").GetString();
	int         nPort   = l.Search(s, "Port").GetNum();

	int e = 0;
	try
	{
		p->Connect(pServer, nPort);
	}
	catch (Tcp_ConnectionError)
	{
		e = 1;
	}

	if (e)
		throw Value("False");
	else
		throw Value("True");
}


static Native tcp_Init("TcpClient.Init", TcpClient_Init);


void TcpClient_Tx(SymbolTable &l)
{
	Src s;
	Value *Self = &l.Assign(s, "Self");

	const char *p = Self->GetField("v")->GetString();

	TcpClient *pTcpClient;
	sscanf(p, "%p", &pTcpClient);

	Value *Buff = &l.Assign(s, "Buff");

	const char *pBuff = Buff->GetString();
	int         szBuff = Buff->Len();

	pTcpClient->Tx(pBuff, szBuff);
}


static Native tcp_Tx("TcpClient.Tx", TcpClient_Tx);


void TcpClient_Rx(SymbolTable &l)
{
	Src s;
	Value *Self = &l.Assign(s, "Self");

	const char *p = Self->GetField("v")->GetString();
	int mSec = l.Assign(s, "mSec").GetNum();

	TcpClient *pTcpClient;
	sscanf(p, "%p", &pTcpClient);

	Value *Buff = &l.Assign(s, "Buff");

	char b[1024];
	int r = pTcpClient->Rx(b, sizeof(b), mSec);

	if (r == 0)
		throw Value("False");

	*Buff = Value(b, r);
	throw Value("True");
}

static Native tcp_Rx("TcpClient.Rx", TcpClient_Rx);


void TcpClient_RxAll(SymbolTable &l)
{
	Src s;
	Value *Self = &l.Assign(s, "Self");

	const char *p = Self->GetField("v")->GetString();
	int mSec = l.Assign(s, "mSec").GetNum();
	int SizeToRx = l.Assign(s, "SizeToRx").GetNum();

	TcpClient *pTcpClient;
	sscanf(p, "%p", &pTcpClient);

	Value *Buff = &l.Assign(s, "Buff");

	char b[1024];
	int r = pTcpClient->RxAll(b, SizeToRx, mSec);

	if (r == 0)
		throw Value("False");

	*Buff = Value(b, r);
	throw Value("True");
}


static Native tcp_RxAll("TcpClient.RxAll", TcpClient_RxAll);


void TcpClient_Connected(SymbolTable &l)
{
	Src s;
	Value *Self = &l.Assign(s, "Self");

	const char *p = Self->GetField("v")->GetString();

	TcpClient *pTcpClient;
	sscanf(p, "%p", &pTcpClient);

	int r = pTcpClient->Connected();

	if (r == 0)
		throw Value("False");
	else
		throw Value("True");
}


static Native tcp_Connected("TcpClient.Connected", TcpClient_Connected);


void TcpClient_Close(SymbolTable &l)
{
	Src s;
	Value *Self = &l.Assign(s, "Self");

	const char *p = Self->GetField("v")->GetString();

	TcpClient *pTcpClient;
	sscanf(p, "%p", &pTcpClient);

	STDelete pTcpClient;

	*Self->GetField("v") = Value("");
}


static Native tcp_Close("TcpClient.Close", TcpClient_Close);


void TcpClient_GetLocalHost(SymbolTable &l)
{
	const char *r = TcpClient::GetLocalHost();
	throw Value(r);
}


static Native tcp_GetLocalHost("TcpClient.GetLocalHost", TcpClient_GetLocalHost);

