#include <st_dbnew.h>
#include <stdio.h>

#ifndef _WIN32
#include <strstream.h>
#else
#include <strstrea.h>
#endif

#include <native.h>
#include <moses.h>

static void S_Moses_Connection_Open(SymbolTable &l)
{
	Src s;
	const char *pServer = l.Assign(s, "ServerName").GetString();
	int         nPort   = l.Assign(s, "Port").GetNum();

	STRING r = Moses_Connection_Open(pServer, nPort);

	throw Value(r.Str());
}


static Native Connection_Open("Moses_Connection_Open", S_Moses_Connection_Open);

/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Connection_Close(SymbolTable &l)
{
	STRING r = Moses_Connection_Close();
	throw Value(r.Str());
}


static Native Connection_Close("Moses_Connection_Close", S_Moses_Connection_Close);


/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Work_Begin(SymbolTable &l)
{
	Src s;
	const char *pLogin  = l.Assign(s, "Login")      .GetString();
	const char *pPasswd = l.Assign(s, "Password")   .GetString();
	const char *pClient = l.Assign(s, "ClientType") .GetString();

	INT32 out_Pid;
	STRING r = Moses_Work_Begin(pLogin, pPasswd, pClient, out_Pid);

	char b[20];
	sprintf(b, "%d", out_Pid);

	l.Assign(s, "Pid") = Value(b);

	throw Value(r.Str());
}


static Native Work_Begin("Moses_Work_Begin", S_Moses_Work_Begin);

/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Work_End(SymbolTable &l)
{
	Src s;
	int Pid = l.Assign(s, "Pid").GetNum();
	int bOk = l.Assign(s, "bOk").GetNum();

	STRING r = Moses_Work_End(Pid, bOk);

	throw Value(r.Str());
}


static Native Work_End("Moses_Work_End", S_Moses_Work_End);

/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Work_ListClient(SymbolTable &l)
{
	Src s;

	VECT<STRING> LoginList;
	VECT<STRING> ClientTypeList;
	VECT<STRING> TcpAddrList;

	STRING r = Moses_Work_ListClient(LoginList, ClientTypeList, TcpAddrList);


	l.Assign(s, "LoginList")      = Value(Value::Array);
	l.Assign(s, "ClientTypeList") = Value(Value::Array);
	l.Assign(s, "TcpAddrList")    = Value(Value::Array);

	for (int i = 0; i < LoginList.Size(); i++)
	{
		l.Assign(s, "LoginList").ArrayPut(Value(LoginList[i].Str()));
		l.Assign(s, "ClientTypeList").ArrayPut(Value(ClientTypeList[i].Str()));
		l.Assign(s, "TcpAddrList").ArrayPut(Value(TcpAddrList[i].Str()));
	}

	throw Value(r.Str());
}

static Native Work_ListClient("Moses_Work_ListClient", S_Moses_Work_ListClient);
/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Work_SetSession(SymbolTable &l)
{
	Src s;
	int bClosed = l.Assign(s, "bClosed").GetNum();

	STRING r = Moses_Work_SetSession(bClosed);

	throw Value(r.Str());
}


static Native Work_SetSession("Moses_Work_SetSession", S_Moses_Work_SetSession);

/////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Connection_Dial(SymbolTable &l)
{
	Src s;
	const char *pProvider = l.Assign(s, "Provider").GetString();
	STRING r = Moses_Connection_Dial(pProvider);
	throw Value(r.Str());
}
static Native Connection_Dial("Moses_Connection_Dial", S_Moses_Connection_Dial);

static void S_Moses_Connection_HungUp(SymbolTable &l)
{
	Src s;
	const char *pProvider = l.Assign(s, "Provider").GetString();
	STRING r = Moses_Connection_HungUp(pProvider);
	throw Value(r.Str());
}
static Native Connection_HungUp("Moses_Connection_HungUp", S_Moses_Connection_HungUp);

static void S_Moses_Connection_IsRemote(SymbolTable &l)
{
	Src s;
	const char *pProvider = l.Assign(s, "Provider").GetString();
	INT16 out_bRemote;
	STRING r = Moses_Connection_IsRemote(pProvider, out_bRemote);
	l.Assign(s, "bRemote") = Value(STRING::Set(out_bRemote).Str());
	throw Value(r.Str());
}
static Native Connection_Dial_IsRemote("Moses_Connection_IsRemote", S_Moses_Connection_IsRemote);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_GetInfo(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox").GetString();
	const char *pPwd     = l.Assign(s, "Pwd"    ).GetString();
	INT32       MsgId    = l.Assign(s, "MsgId")  .GetNum();

	
	VECT<STRING> Status;
	STRING       Sender, Destination, Subject;
	INT16        bIncoming;
	INT32        BodySize;

	STRING r = Moses_MB_GetInfo(
			pMailbox,
			pPwd,
			MsgId,
			Status,
			Sender, Destination, Subject,
			bIncoming,
			BodySize);

	// Assegnamento x un Vettore di Stringhe.
	l.Assign(s, "Status") = Value(Value::Array);
	for (int i = 0; i < Status.Size(); i++)
		l.Assign(s, "Status").ArrayPut(Value(Status[i].Str()));

	l.Assign(s, "Sender")      = Value(Sender.Str());
	l.Assign(s, "Destination") = Value(Destination.Str());
	l.Assign(s, "Subject")     = Value(Subject.Str());
	l.Assign(s, "MsgId")       = Value(STRING::Set(bIncoming).Str());
	l.Assign(s, "BodySize")    = Value(STRING::Set(BodySize).Str());

	throw Value(r.Str());
}

static Native MB_GetInfo("Moses_MB_GetInfo", S_Moses_MB_GetInfo);

//////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_MB_CheckMailbox(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox").GetString();
	const char *pPwd     = l.Assign(s, "Pwd"    ).GetString();

	STRING r = Moses_MB_CheckMailbox(
			pMailbox,
			pPwd);

	throw Value(r.Str());
}

static Native MB_CheckMailbox("Moses_MB_CheckMailbox", S_Moses_MB_CheckMailbox);

/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_SetInfoEx(SymbolTable &l)
{
	Src s;

	const char *pMailbox      = l.Assign(s, "Mailbox")    .GetString();
	const char *pPwd          = l.Assign(s, "Pwd"    )    .GetString();
	INT32       MsgId         = l.Assign(s, "MsgId")      .GetNum();
	const char *pSender       = l.Assign(s, "Sender")     .GetString();
	const char *pDestination  = l.Assign(s, "Destination").GetString();
	const char *pSubject      = l.Assign(s, "Subject")    .GetString();
	INT16       bIncoming     = l.Assign(s, "bIncoming")  .GetNum();


	Value&v = l.Assign(s, "Status");
	if (!v.IsArray())
		throw Value("Moses_MB_SetInfoEx: Status require an array value");

	VECT<STRING> Status;
	for (int i = 0; i < v.Dim(); i++)
		Status.Append(STRING(v.ArrayGet(i).GetString()));

	
	STRING r = Moses_MB_SetInfoEx(
			pMailbox,
			pPwd,
			MsgId,
			pSender,
			pDestination,
			pSubject,
			bIncoming,
			Status);

	throw Value(r.Str());
}
static Native MB_SetInfoEx("Moses_MB_SetInfoEx", S_Moses_MB_SetInfoEx);


//////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_ChangeDescr(SymbolTable &l)
{
	Src s;

	const char *pMailbox      = l.Assign(s, "Mailbox"    ).GetString();
	const char *pPwd          = l.Assign(s, "Pwd"        ).GetString();
	const char *pDescr        = l.Assign(s, "Descr"      ).GetString();

	STRING r = Moses_MB_ChangeDescr(
			pMailbox,
			pPwd,
			pDescr);

	throw Value(r.Str());
}

static Native MB_ChangeDescr("Moses_MB_ChangeDescr", S_Moses_MB_ChangeDescr);


//////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_ChangePassword(SymbolTable &l)
{
	Src s;

	const char *pMailbox      = l.Assign(s, "Mailbox"    ).GetString();
	const char *pPwdCurrent   = l.Assign(s, "PwdCurrent" ).GetString();
	const char *pPwdNew       = l.Assign(s, "PwdNew"     ).GetString();

	STRING r = Moses_MB_ChangePassword(
			pMailbox,
			pPwdCurrent,
			pPwdNew);

	throw Value(r.Str());
}

static Native MB_ChangePassword("Moses_MB_ChangePassword", S_Moses_MB_ChangePassword);


//////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_ChangeOwner(SymbolTable &l)
{
	Src s;

	const char *pMailbox      = l.Assign(s, "Mailbox"  ).GetString();
	const char *pOwner        = l.Assign(s, "Owner"    ).GetString();

	STRING r = Moses_MB_ChangeOwner(
			pMailbox,
			pOwner);

	throw Value(r.Str());
}

static Native MB_ChangeOwner("Moses_MB_ChangeOwner", S_Moses_MB_ChangeOwner);

//////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_CreateMailbox(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox" ).GetString();
	const char *pOwner   = l.Assign(s, "Owner"   ).GetString();
	const char *pPwd     = l.Assign(s, "Pwd"     ).GetString();
	const char *pDescr   = l.Assign(s, "Descr"   ).GetString();

	STRING r = Moses_MB_CreateMailbox(
			pMailbox,
			pOwner,
			pPwd,
			pDescr);

	throw Value(r.Str());
}

static Native MB_CreateMailbox("Moses_MB_CreateMailbox", S_Moses_MB_CreateMailbox);


////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_DeleteMailbox(SymbolTable &l)
{
	Src s;

	const char *pMailBoxName = l.Assign(s, "MailBoxName" ).GetString();

	STRING r = Moses_MB_DeleteMailbox(pMailBoxName);

	throw Value(r.Str());
}

static Native MB_DeleteMailbox("Moses_MB_DeleteMailbox", S_Moses_MB_DeleteMailbox);

////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_ListMailbox(SymbolTable &l)
{
	Src s;

	INT32   Index       = l.Assign(s, "Index").GetNum();
	STRING  MailBoxName, Owner, Pwd, Descr;
	INT16   Valid;

	STRING r = Moses_MB_ListMailbox(
			Index,
			MailBoxName,
			Owner,
			Pwd,
			Descr,
			Valid);

	l.Assign(s, "MailBoxName")  = Value(MailBoxName.Str());
	l.Assign(s, "Owner")        = Value(Owner.Str());
	l.Assign(s, "Pwd")          = Value(Pwd.Str());
	l.Assign(s, "Descr")        = Value(Descr.Str());

	if (Valid)
		l.Assign(s, "Valid")    = Value("True");
	else
		l.Assign(s, "Valid")    = Value("False");

	throw Value(r.Str());
}
static Native MB_ListMailbox("Moses_MB_ListMailbox", S_Moses_MB_ListMailbox);


////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_CreateFolder(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox" ).GetString();
	const char *pPwd     = l.Assign(s, "Pwd"     ).GetString();
	const char *pFolder  = l.Assign(s, "Folder"  ).GetString();

	STRING r = Moses_MB_CreateFolder(pMailbox,
			pPwd,
			pFolder);

	throw Value(r.Str());
}

static Native MB_CreateFolder("Moses_MB_CreateFolder", S_Moses_MB_CreateFolder);


////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_DeleteFolder(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox" ).GetString();
	const char *pPwd     = l.Assign(s, "Pwd"     ).GetString();
	const char *pFolder  = l.Assign(s, "Folder"  ).GetString();

	STRING r = Moses_MB_DeleteFolder(pMailbox,
			pPwd,
			pFolder);

	throw Value(r.Str());
}

static Native MB_DeleteFolder("Moses_MB_DeleteFolder", S_Moses_MB_DeleteFolder);

////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_ListFolder(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox").GetString();
	const char *pPwd     = l.Assign(s, "Pwd"    ).GetString();
	const char *pFolder     = l.Assign(s, "Folder"    ).GetString();

	
	VECT<STRING> FolderList;
	VECT<INT16>  Deleted;

	STRING r = Moses_MB_ListFolder(
			pMailbox,
			pPwd,
			pFolder,
			FolderList,
			Deleted);

	// Assegnamento x un Vettore di Stringhe.
	l.Assign(s, "FolderList") = Value(Value::Array);
	for (int i = 0; i < FolderList.Size(); i++)
		l.Assign(s, "FolderList").ArrayPut(Value(FolderList[i].Str()));

	// Assegnamento x un Vettore di INT16.
	l.Assign(s, "Deleted") = Value(Value::Array);
	for (int ii = 0; ii < Deleted.Size(); ii++)
	{
		char b[10];
		ostrstream ss(b, sizeof(b));
		ss << Deleted[ii] << ends;

		l.Assign(s, "Deleted").ArrayPut(Value(b));
	}

	throw Value(r.Str());
}

static Native MB_ListFolder("Moses_MB_ListFolder", S_Moses_MB_ListFolder);


////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_UndeleteFolder(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox" ).GetString();
	const char *pPwd     = l.Assign(s, "Pwd"     ).GetString();
	const char *pFolder  = l.Assign(s, "Folder"  ).GetString();

	STRING r = Moses_MB_UndeleteFolder(pMailbox,
			pPwd,
			pFolder);

	throw Value(r.Str());
}

static Native MB_UndeleteFolder("Moses_MB_UndeleteFolder", S_Moses_MB_UndeleteFolder);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_GetNewId(SymbolTable &l)
{
	Src    s;
	INT32  MsgId;

	STRING r = Moses_MB_GetNewId(MsgId);

	l.Assign(s, "MsgId")       = Value(STRING::Set(MsgId).Str());

	throw Value(r.Str());
}

static Native MB_GetNewId("Moses_MB_GetNewId", S_Moses_MB_GetNewId);

/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_WriteInFolder(SymbolTable &l)
{
	Src s;

	const char *pMailbox     = l.Assign(s, "Mailbox"    ).GetString();
	const char *pPwd         = l.Assign(s, "Pwd"        ).GetString();
	const char *pFolder      = l.Assign(s, "Folder"     ).GetString();
	INT32       MsgId        = l.Assign(s, "MsgId"      ).GetNum();
	const char *pSender      = l.Assign(s, "Sender"     ).GetString();
	const char *pDestination = l.Assign(s, "Destination").GetString();
	const char *pSubject     = l.Assign(s, "Subject"    ).GetString();
	INT16       bIncoming    = l.Assign(s, "bIncoming"  ).GetNum();
	INT32       szBody       = l.Assign(s, "Body"       ).Len();
	const char *pBody        = l.Assign(s, "Body"       ).GetString();

	STRING r = Moses_MB_WriteInFolder(
			pMailbox,
			pPwd,
			pFolder,
			MsgId,
			pSender,
			pDestination,
			pSubject,
			bIncoming,
			szBody,
			pBody);

	throw Value(r.Str());
}

static Native MB_WriteInFolder("Moses_MB_WriteInFolder", S_Moses_MB_WriteInFolder);


////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_ListMsg(SymbolTable &l)
{
	Src s;

	const char *pMailbox    = l.Assign(s, "Mailbox"   ).GetString();
	const char *pPwd        = l.Assign(s, "Pwd"       ).GetString();
	const char *pFolder     = l.Assign(s, "Folder"    ).GetString();
	const char *pUserField  = l.Assign(s, "UserField" ).GetString();
	const char *pAccessed   = l.Assign(s, "Accessed"  ).GetString();
	const char *pSender     = l.Assign(s, "Sender"    ).GetString();
	const char *pReceiver   = l.Assign(s, "Receiver"   ).GetString();

	
	VECT<INT32>  MsgIdList;

	STRING r = Moses_MB_ListMsg(
			pMailbox,
			pPwd,
			pFolder,
			pUserField,
			pAccessed,
			pSender,
			pReceiver,
			MsgIdList);


	// Assegnamento x un Vettore di INT32.
	l.Assign(s, "MsgIdList") = Value(Value::Array);
	for (int i = 0; i < MsgIdList.Size(); i++)
	{
		char b[10];
		ostrstream ss(b, sizeof(b));
		ss << MsgIdList[i] << ends;

		l.Assign(s, "MsgIdList").ArrayPut(Value(b));
	}

	throw Value(r.Str());
}

static Native MB_ListMsg("Moses_MB_ListMsg", S_Moses_MB_ListMsg);

/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_MsgRead(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox").GetString();
	const char *pPwd     = l.Assign(s, "Pwd"    ).GetString();
	INT32       MsgId    = l.Assign(s, "MsgId")  .GetNum();

	
	STRING Body;

	STRING r = Moses_MB_MsgRead(
			pMailbox,
			pPwd,
			MsgId,
			Body);

	l.Assign(s, "Body") = Value(Body.Str());

	throw Value(r.Str());
}

static Native MB_MsgRead("Moses_MB_MsgRead", S_Moses_MB_MsgRead);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_Log_NewMsgId(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox").GetString();
	const char *pPwd     = l.Assign(s, "Pwd"    ).GetString();
	INT32       OldMsgId = l.Assign(s, "OldMsgId")  .GetNum();
	INT32       NewMsgId = l.Assign(s, "NewMsgId")  .GetNum();


	STRING r = Moses_Log_NewMsgId(
			pMailbox,
			pPwd,
			OldMsgId,
			NewMsgId);

	throw Value(r.Str());
}

static Native Log_NewMsgId("Moses_Log_NewMsgId", S_Moses_Log_NewMsgId);

/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_MsgFile(SymbolTable &l)
{
	Src s;

	INT32       MsgId    = l.Assign(s, "MsgId")  .GetNum();

	
	STRING MsgFile;

	STRING r = Moses_MB_MsgFile(
			MsgId,
			MsgFile);

	l.Assign(s, "MsgFile") = Value(MsgFile.Str());

	throw Value(r.Str());
}

static Native MB_MsgFile("Moses_MB_MsgFile", S_Moses_MB_MsgFile);



/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_Msg_Delete(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox").GetString();
	const char *pPwd     = l.Assign(s, "Pwd"    ).GetString();
	INT32       MsgId    = l.Assign(s, "MsgId")  .GetNum();

	STRING r = Moses_MB_Msg_Delete(
			pMailbox,
			pPwd,
			MsgId);

	throw Value(r.Str());
}

static Native MB_Msg_Delete("Moses_MB_Msg_Delete", S_Moses_MB_Msg_Delete);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_MoveMsg(SymbolTable &l)
{
	Src s;

	const char *pMailbox    = l.Assign(s, "Mailbox"   ).GetString();
	const char *pPwd        = l.Assign(s, "Pwd"       ).GetString();
	INT32       MsgId       = l.Assign(s, "MsgId"     ).GetNum();
	const char *pDestFolder = l.Assign(s, "DestFolder").GetString();

	STRING r = Moses_MB_MoveMsg(
			pMailbox,
			pPwd,
			MsgId,
			pDestFolder);

	throw Value(r.Str());
}

static Native MB_MoveMsg("Moses_MB_MoveMsg", S_Moses_MB_MoveMsg);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_MoveMsg2(SymbolTable &l)
{
	Src s;

	const char *pMailboxS   = l.Assign(s, "MailboxSource"   ).GetString();
	const char *pPwdS       = l.Assign(s, "PwdSource"       ).GetString();
	const char *pMailboxD   = l.Assign(s, "MailboxDest"     ).GetString();
	const char *pPwdD       = l.Assign(s, "PwdDest"         ).GetString();
	INT32       MsgId       = l.Assign(s, "MsgId"           ).GetNum();
	const char *pDestFolder = l.Assign(s, "DestFolder"      ).GetString();

	STRING r = Moses_MB_MoveMsg2(
			pMailboxS,
			pPwdS,
			pMailboxD,
			pPwdD,
			MsgId,
			pDestFolder);

	throw Value(r.Str());
}

static Native MB_MoveMsg2("Moses_MB_MoveMsg2", S_Moses_MB_MoveMsg2);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_Set_Userfield(SymbolTable &l)
{
	Src s;

	const char *pMailbox    = l.Assign(s, "Mailbox"   ).GetString();
	const char *pPwd        = l.Assign(s, "Pwd"       ).GetString();
	INT32       MsgId       = l.Assign(s, "MsgId"     ).GetNum();
	const char *pValue      = l.Assign(s, "Value"     ).GetString();

	STRING r = Moses_MB_Set_Userfield(
			pMailbox,
			pPwd,
			MsgId,
			pValue);

	throw Value(r.Str());
}

static Native MB_Set_Userfield("Moses_MB_Set_Userfield", S_Moses_MB_Set_Userfield);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_Get_Userfield(SymbolTable &l)
{
	Src s;

	const char *pMailbox    = l.Assign(s, "Mailbox"   ).GetString();
	const char *pPwd        = l.Assign(s, "Pwd"       ).GetString();
	INT32       MsgId       = l.Assign(s, "MsgId"     ).GetNum();

	STRING OutValue;

	STRING r = Moses_MB_Get_Userfield(
			pMailbox,
			pPwd,
			MsgId,
			OutValue);

	l.Assign(s, "OutValue") = Value(OutValue.Str());

	throw Value(r.Str());
}

static Native MB_Get_Userfield("Moses_MB_Get_Userfield", S_Moses_MB_Get_Userfield);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_UndeleteMsg(SymbolTable &l)
{
	Src    s;

	INT32  MsgId     = l.Assign(s, "MsgId").GetNum();
	INT16  Recovered;

	STRING r = Moses_MB_UndeleteMsg(MsgId, Recovered);

	l.Assign(s, "Recovered")   = Value(STRING::Set(Recovered).Str());

	throw Value(r.Str());
}

static Native MB_UndeleteMsg("Moses_MB_UndeleteMsg", S_Moses_MB_UndeleteMsg);


/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MB_Purge(SymbolTable &l)
{
	Src    s;

	const char *pMailboxName    = l.Assign(s, "MailboxName"   ).GetString();
	INT16  Deleted;

	STRING r = Moses_MB_Purge(pMailboxName, Deleted);

	l.Assign(s, "Deleted")   = Value(STRING::Set(Deleted).Str());

	throw Value(r.Str());
}

static Native MB_Purge("Moses_MB_Purge", S_Moses_MB_Purge);


/////////////////////////////////////////////////////////////////////////////////////
//
// Scheduler section
// 
/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Scheduler_Add(SymbolTable &l)
{
	Src    s;

	const char *pWhen    = l.Assign(s, "When"   ).GetString();
	const char *pAction  = l.Assign(s, "Action"   ).GetString();

	STRING r = Moses_Scheduler_Add(pWhen, pAction);

	throw Value(r.Str());
}

static Native Scheduler_Add("Moses_Scheduler_Add", S_Moses_Scheduler_Add);

/////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_Scheduler_Delete(SymbolTable &l)
{
	Src    s;

	INT16    Index = l.Assign(s, "Index").GetNum();

	STRING r = Moses_Scheduler_Delete(Index);

	throw Value(r.Str());
}

static Native Scheduler_Delete("Moses_Scheduler_Delete", S_Moses_Scheduler_Delete);

////////////////////////////////////////////////////////////////////////////////
static void S_Moses_Scheduler_List(SymbolTable &l)
{
	Src s;
	
	VECT<INT16>  IndexList;
	VECT<STRING> WhenList;
	VECT<STRING> ActionList;

	STRING r = Moses_Scheduler_List(
			IndexList,
			WhenList,
			ActionList);


	// Assegnamento x un Vettore di INT16.
	l.Assign(s, "IndexList") = Value(Value::Array);
	for (int ii = 0; ii < IndexList.Size(); ii++)
	{
		char b[10];
		ostrstream ss(b, sizeof(b));
		ss << IndexList[ii] << ends;

		l.Assign(s, "IndexList").ArrayPut(Value(b));
	}

	// Assegnamento x un Vettore di Stringhe.
	l.Assign(s, "WhenList") = Value(Value::Array);
	for (int i = 0; i < WhenList.Size(); i++)
		l.Assign(s, "WhenList").ArrayPut(Value(WhenList[i].Str()));
	
	// Assegnamento x un Vettore di Stringhe.
	l.Assign(s, "ActionList") = Value(Value::Array);
	for (int iii = 0; iii < ActionList.Size(); iii++)
		l.Assign(s, "ActionList").ArrayPut(Value(ActionList[iii].Str()));

	throw Value(r.Str());
}

static Native Scheduler_List("Moses_Scheduler_List", S_Moses_Scheduler_List);


/////////////////////////////////////////////////////////////////////////////////////
//
// OL section
// 
/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_OL_Set(SymbolTable &l)
{
	Src    s;

	const char *pDaysAccessed    = l.Assign(s, "DaysAccessed"   ).GetString();
	const char *pDaysSent        = l.Assign(s, "DaysSent"       ).GetString();
	const char *pDaysDispatched  = l.Assign(s, "DaysDispatched" ).GetString();

	STRING r = Moses_OL_Set(pDaysAccessed, pDaysSent, pDaysDispatched);

	throw Value(r.Str());
}

static Native OL_Set("Moses_OL_Set", S_Moses_OL_Set);

////////////////////////////////////////////////////////////////////////////////
static void S_Moses_OL_Get(SymbolTable &l)
{
	Src    s;

	STRING DaysAccessed, DaysSent, DaysDispatched;

	STRING r = Moses_OL_Get(DaysAccessed, DaysSent, DaysDispatched);

	l.Assign(s, "DaysAccessed")    = Value(DaysAccessed.Str());
	l.Assign(s, "DaysSent")        = Value(DaysSent.Str());
	l.Assign(s, "DaysDispatched")  = Value(DaysDispatched.Str());

	throw Value(r.Str());
}

static Native OL_Get("Moses_OL_Get", S_Moses_OL_Get);


/////////////////////////////////////////////////////////////////////////////////////
//
// Licence section
// 
/////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Licence_Set(SymbolTable &l)
{
	Src    s;

	const char *pDateLicence    = l.Assign(s, "Date").GetString();
	const char *pPwd            = l.Assign(s, "Pwd").GetString();

	STRING r = Moses_Licence_Set(pPwd, pDateLicence);

	throw Value(r.Str());
}

static Native Licence_Set("Moses_Licence_Set", S_Moses_Licence_Set);

////////////////////////////////////////////////////////////////////////////////
static void S_Moses_Licence_Get(SymbolTable &l)
{
	Src    s;

	STRING DaysAccessed, DaysSent, DateLicence;

	STRING r = Moses_Licence_Get(DateLicence);

	l.Assign(s, "Date")    = Value(DateLicence.Str());

	throw Value(r.Str());
}

static Native Licence_Get("Moses_Licence_Get", S_Moses_Licence_Get);


////////////////////////////////////////////////////////////////////////////////////
// FM Section
////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_FM_ListFile(SymbolTable &l)
{
	Src s;

	const char *PathDir = l.Assign(s, "PathDir").GetString();

	VECT<STRING> NameFile, TypeFile, DateFile;
	VECT<INT32>  DimFile;

	STRING r = Moses_FM_ListFile(
			PathDir,
			NameFile, TypeFile, DateFile, DimFile);
	
	l.Assign(s, "NameFileList") = Value(Value::Array);
	l.Assign(s, "TypeFileList") = Value(Value::Array);
	l.Assign(s, "DateFileList") = Value(Value::Array);
	l.Assign(s, "DimFileList" ) = Value(Value::Array);
	for (int i = 0; i < NameFile.Size(); i++)
	{
		l.Assign(s, "NameFileList").ArrayPut(Value(NameFile[i].Str()));
		l.Assign(s, "TypeFileList").ArrayPut(Value(TypeFile[i].Str()));
		l.Assign(s, "DateFileList").ArrayPut(Value(DateFile[i].Str()));
		l.Assign(s, "DimFileList") .ArrayPut(Value(STRING::Set(DimFile[i]).Str()));
	}

	throw Value(r.Str());
}
static Native FM_ListFile("Moses_FM_ListFile", S_Moses_FM_ListFile);



////////////////////////////////////////////////////////////////////////////////
static void S_Moses_FM_GetFile(SymbolTable &l)
{
	Src s;

	const char *f = l.Assign(s, "StartPathNameFile").GetString();

	STRING Body;

	STRING r = Moses_FM_GetFile(f, Body);
	
	l.Assign(s, "BodyFile") = Value(Body.Str(), Body.Len());

	throw Value(r.Str());
}
static Native FM_GetFile("Moses_FM_GetFile", S_Moses_FM_GetFile);



////////////////////////////////////////////////////////////////////////////////
static void S_Moses_FM_PutFile(SymbolTable &l)
{
	Src s;

	const char *f = l.Assign(s, "FinalPathName").GetString();
	const char *body = l.Assign(s, "BodyFile").GetString();
	int        len   = l.Assign(s, "BodyFile").Len();

	STRING r = Moses_FM_PutFile(f, STRING(body, len));
	
	throw Value(r.Str());
}
static Native FM_PutFile("Moses_FM_PutFile", S_Moses_FM_PutFile);

////////////////////////////////////////////////////////////////////////////////
static void S_Moses_EH_Add(SymbolTable &l)
{
	Src s;

	const char *MailboxName = l.Assign(s, "MailboxName") .GetString();
	const char *Folder      = l.Assign(s, "Folder")      .GetString();
	const char *Source      = l.Assign(s, "Source")      .GetString();
	const char *Destination = l.Assign(s, "Destination") .GetString();
	const char *Subject     = l.Assign(s, "Subject")     .GetString();
	const char *Action      = l.Assign(s, "Action")      .GetString();
	int         Index       = l.Assign(s, "Index")       .GetNum();

	STRING r = Moses_EH_Add(
			MailboxName,
			Folder,
			Source,
			Destination, 
			Subject, 
			Action,
			Index);

	throw Value(r.Str());
}
static Native EH_Add("Moses_EH_Add", S_Moses_EH_Add);
////////////////////////////////////////////////////////////////////////////////

static void S_Moses_EH_List(SymbolTable &l)
{
	Src s;

	int         Index       = l.Assign(s, "Index")       .GetNum();
	const char *MailboxName = l.Assign(s, "MailboxName") .GetString();
	const char *Folder      = l.Assign(s, "Folder")      .GetString();


	STRING out_Source, out_Destination, out_Subject, out_Action;
	INT16  out_Valid;

	STRING r = Moses_EH_List(
			Index,
			MailboxName,
			Folder,
			out_Source,
			out_Destination, 
			out_Subject, 
			out_Action,
			out_Valid);

	l.Assign(s, "Source")      = Value(out_Source     .Str());
	l.Assign(s, "Destination") = Value(out_Destination.Str());
	l.Assign(s, "Subject")     = Value(out_Subject    .Str());
	l.Assign(s, "Action")      = Value(out_Action     .Str());
	l.Assign(s, "Valid")       = Value(out_Valid ? "True" : "False");

	throw Value(r.Str());
}
static Native EH_List("Moses_EH_List", S_Moses_EH_List);
////////////////////////////////////////////////////////////////////////////////

static void S_Moses_EH_Delete(SymbolTable &l)
{
	Src s;

	const char *MailboxName = l.Assign(s, "MailboxName") .GetString();
	const char *Folder      = l.Assign(s, "Folder")      .GetString();
	int         Index       = l.Assign(s, "Index")       .GetNum();


	INT16  out_Valid;

	STRING r = Moses_EH_Delete(
			MailboxName,
			Folder,
			Index,
			out_Valid);

	l.Assign(s, "Valid")       = Value(out_Valid ? "True" : "False");

	throw Value(r.Str());
}
static Native EH_Delete("Moses_EH_Delete", S_Moses_EH_Delete);
////////////////////////////////////////////////////////////////////////////////
