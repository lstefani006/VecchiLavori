#include <st_dbnew.h>
#include <stdio.h>

#include <native.h>
#include <moses.h>


////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_User_Delete(SymbolTable &l)
{
	Src s;

	const char *pUserName	= l.Assign(s, "UserName").GetString();
	INT32       bCascade   	= l.Assign(s, "bCascade").GetNum();

	STRING r = Moses_User_Delete( pUserName, bCascade);

	throw Value(r.Str());
}
static Native User_Delete("Moses_User_Delete", S_Moses_User_Delete);

static void S_Moses_User_Modify(SymbolTable &l)
{
	Src s;

	const char *pUserName	= l.Assign(s, "UserName").GetString();
	const char *pUserPwd  	= l.Assign(s, "UserPwd" ).GetString();
	const char *pUserClientType	= l.Assign(s, "UserClientType" ).GetString();
	const char *pUserDescr 	= l.Assign(s, "UserDescr" ).GetString();
	const char *pUserRights	= l.Assign(s, "UserRights" ).GetString();
	const char *pUserDefaultMBox= l.Assign(s, "UserDefaultMBox" ).GetString();
	const char *pUserKeyId	= l.Assign(s, "UserKeyId" ).GetString();

	STRING r = Moses_User_Modify(
	pUserName,
  	pUserPwd, 
	pUserClientType, 
	pUserDescr, 
	pUserRights, 
	pUserDefaultMBox, 
	pUserKeyId);

	throw Value(r.Str());
}
static Native User_Modify("Moses_User_Modify", S_Moses_User_Modify);

static void S_Moses_User_ChangePassword(SymbolTable &l)
{
	Src s;

	const char *pUserName	= l.Assign(s, "UserName").GetString();
	const char *pUserPwdOld = l.Assign(s, "UserPwdOld" ).GetString();
	const char *pUserPwdNew = l.Assign(s, "UserPwdNew" ).GetString();

	STRING r = Moses_User_ChangePassword(
			pUserName,
			pUserPwdOld, 
			pUserPwdNew);

	throw Value(r.Str());
}
static Native User_ChangePassword("Moses_User_ChangePassword", S_Moses_User_ChangePassword);

static void S_Moses_User_Add(SymbolTable &l)
{
	Src s;

	const char *pUserName	= l.Assign(s, "UserName").GetString();
	const char *pUserPwd  	= l.Assign(s, "UserPwd" ).GetString();
	const char *pUserClientType	= l.Assign(s, "UserClientType" ).GetString();
	const char *pUserDescr 	= l.Assign(s, "UserDescr" ).GetString();
	const char *pUserRights	= l.Assign(s, "UserRights" ).GetString();
	const char *pUserDefaultMBox= l.Assign(s, "UserDefaultMBox" ).GetString();
	const char *pUserKeyId	= l.Assign(s, "UserKeyId" ).GetString();

	STRING r = Moses_User_Add(
			pUserName,
			pUserPwd, 
			pUserClientType, 
			pUserDescr, 
			pUserRights, 
			pUserDefaultMBox, 
			pUserKeyId);

	throw Value(r.Str());
}
static Native User_Add("Moses_User_Add", S_Moses_User_Add);

static void S_Moses_User_List(SymbolTable &l)
{
	Src s;

	INT32   Index   	= l.Assign(s, "Index").GetNum();
	STRING 	UserName, UserPwd, UserClientType, UserDescr, UserRights, UserDefaultMBox, UserKeyId;
	INT16 	Valid;

	STRING r = Moses_User_List(
	Index,
	UserName,
  	UserPwd, 
	UserClientType, 
	UserDescr, 
	UserRights, 
	UserDefaultMBox, 
	UserKeyId,
	Valid);

	l.Assign(s, "UserName")		= Value(UserName.Str());
	l.Assign(s, "UserPwd")		= Value(UserPwd.Str());
	l.Assign(s, "UserClientType")	= Value(UserClientType.Str());
	l.Assign(s, "UserDescr")	= Value(UserDescr.Str());
	l.Assign(s, "UserRights")	= Value(UserRights.Str());
	l.Assign(s, "UserDefaultMBox")	= Value(UserDefaultMBox.Str());
	l.Assign(s, "UserKeyId")	= Value(UserKeyId.Str());
	if (Valid)
		l.Assign(s, "Valid")    = Value("True");
	else
		l.Assign(s, "Valid")    = Value("False");

	throw Value(r.Str());
}
static Native User_List("Moses_User_List", S_Moses_User_List);

////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_MSL_List(SymbolTable &l)
{
	Src s;

	VECT<STRING> 	NameList,
					DescrList;

	STRING r = Moses_MSL_List( NameList, DescrList);

	l.Assign(s, "NameList") = Value(Value::Array);
	for (int i = 0; i < NameList.Size(); i++)
		l.Assign(s, "NameList").ArrayPut(Value(NameList[i].Str()));

	l.Assign(s, "DescrList") = Value(Value::Array);
	for (i = 0; i < DescrList.Size(); i++)
		l.Assign(s, "DescrList").ArrayPut(Value(DescrList[i].Str()));

	throw Value(r.Str());
}
static Native MSL_List("Moses_MSL_List", S_Moses_MSL_List);

static void S_Moses_MSL_Add(SymbolTable &l)
{
	Src s;

	const char *pName	= l.Assign(s, "Name").GetString();
	const char *pDescr	= l.Assign(s, "Descr"	).GetString();

	STRING r = Moses_MSL_Add( pName, pDescr);

	throw Value(r.Str());
}
static Native MSL_Add("Moses_MSL_Add", S_Moses_MSL_Add);

static void S_Moses_MSL_Modify(SymbolTable &l)
{
	Src s;

	const char *pName	= l.Assign(s, "Name").GetString();
	const char *pDescr	= l.Assign(s, "Descr"	).GetString();

	STRING r = Moses_MSL_Modify( pName, pDescr);

	throw Value(r.Str());
}
static Native MSL_Modify("Moses_MSL_Modify", S_Moses_MSL_Modify);

static void S_Moses_MSL_Delete(SymbolTable &l)
{
	Src s;

	const char *pName	= l.Assign(s, "Name").GetString();

	STRING r = Moses_MSL_Delete( pName );

	throw Value(r.Str());
}
static Native MSL_Delete("Moses_MSL_Delete", S_Moses_MSL_Delete);


////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_Client_Add(SymbolTable &l)
{
	Src s;

	const char *pClientName		= l.Assign(s, "ClientName").GetString();
	const char *pClientDescr  	= l.Assign(s, "ClientDescr" ).GetString();
	const char *pClientType		= l.Assign(s, "ClientType" ).GetString();
	INT16		Active			= l.Assign(s, "Active").GetNum();

	STRING r = Moses_Client_Add(
			pClientName,
			pClientDescr, 
			pClientType, 
			Active);

	throw Value(r.Str());
}
static Native Client_Add("Moses_Client_Add", S_Moses_Client_Add);

static void S_Moses_Client_Modify(SymbolTable &l)
{
	Src s;

	const char *pClientName		= l.Assign(s, "ClientName").GetString();
	const char *pClientDescr  	= l.Assign(s, "ClientDescr" ).GetString();
	const char *pClientType		= l.Assign(s, "ClientType" ).GetString();
	INT16		Active			= l.Assign(s, "Active").GetNum();

	STRING r = Moses_Client_Modify(
			pClientName,
			pClientDescr, 
			pClientType, 
			Active);

	throw Value(r.Str());
}
static Native Client_Modify("Moses_Client_Modify", S_Moses_Client_Modify);

static void S_Moses_Client_List(SymbolTable &l)
{
	Src s;

	VECT<STRING> ClientNameList	;
	VECT<STRING> ClientDescrList;
	VECT<STRING> ClientTypeList	;
	VECT<INT16>	 ActiveList		;

	STRING r = Moses_Client_List(
			ClientNameList,
			ClientDescrList, 
			ClientTypeList, 
			ActiveList);

	l.Assign(s, "ClientNameList") 	= Value(Value::Array);
	l.Assign(s, "ClientDescrList") 	= Value(Value::Array);
	l.Assign(s, "ClientTypeList") 	= Value(Value::Array);
	l.Assign(s, "ActiveList") 		= Value(Value::Array);
	for (int i = 0; i < ClientNameList.Size(); i++)
	{
		l.Assign(s, "ClientNameList").	ArrayPut(Value(ClientNameList[i].Str()));
		l.Assign(s, "ClientDescrList").	ArrayPut(Value(ClientDescrList[i].Str()));
		l.Assign(s, "ClientTypeList").	ArrayPut(Value(ClientTypeList[i].Str()));
		l.Assign(s, "ActiveList").		ArrayPut(Value(STRING::Set(ActiveList[i]).Str()));
	}

	throw Value(r.Str());
}
static Native Client_List("Moses_Client_List", S_Moses_Client_List);

static void S_Moses_Client_Delete(SymbolTable &l)
{
	Src s;

	const char *pClientName		= l.Assign(s, "ClientName").GetString();

	STRING r = Moses_Client_Delete(pClientName);

	throw Value(r.Str());
}
static Native Client_Delete("Moses_Client_Delete", S_Moses_Client_Delete);

static void S_Moses_Client_Run(SymbolTable &l)
{
	Src s;

	const char *pClientName		= l.Assign(s, "ClientName").GetString();

	STRING r = Moses_Client_Run(pClientName);

	throw Value(r.Str());
}
static Native Client_Run("Moses_Client_Run", S_Moses_Client_Run);

static void S_Moses_Client_Kill(SymbolTable &l)
{
	Src s;

	const char* ClientName = l.Assign(s, "ClientName").GetString();

	STRING r = Moses_Client_Kill(ClientName);

	throw Value(r.Str());
}
static Native Client_Kill("Moses_Client_Kill", S_Moses_Client_Kill);


static void S_Moses_Client_RunningList(SymbolTable &l)
{
	Src s;

	VECT<STRING> ClientNameList	;

	STRING r = Moses_Client_RunningList( ClientNameList);

	l.Assign(s, "ClientNameList") 	= Value(Value::Array);
	for (int i = 0; i < ClientNameList.Size(); i++)
		l.Assign(s, "ClientNameList").	ArrayPut(Value(ClientNameList[i].Str()));

	throw Value(r.Str());
}
static Native Client_RunningList("Moses_Client_RunningList", S_Moses_Client_RunningList);


////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_DL_Add(SymbolTable &l)
{
	Src s;

	const char *pDLName		= l.Assign(s, "DLName").GetString();
	const char *pPwd  		= l.Assign(s, "Pwd" ).GetString();
	const char *pDescr		= l.Assign(s, "Descr" ).GetString();

	STRING r = Moses_DL_Add(
			pDLName,
			pPwd, 
			pDescr);

	throw Value(r.Str());
}
static Native DL_Add("Moses_DL_Add", S_Moses_DL_Add);

static void S_Moses_DL_Modify(SymbolTable &l)
{
	Src s;

	const char *pDLName		= l.Assign(s, "DLName").GetString();
	const char *pPwd  		= l.Assign(s, "Pwd" ).GetString();
	const char *pDescr		= l.Assign(s, "Descr" ).GetString();

	STRING r = Moses_DL_Modify(
			pDLName,
			pPwd, 
			pDescr);

	throw Value(r.Str());
}
static Native DL_Modify("Moses_DL_Modify", S_Moses_DL_Modify);

static void S_Moses_DL_List(SymbolTable &l)
{
	Src s;

	VECT<STRING> DLNameList;
	VECT<STRING> PwdList  ;
	VECT<STRING> DescrList;

	STRING r = Moses_DL_List(
			DLNameList,
			PwdList, 
			DescrList);

	l.Assign(s, "DLNameList") 	= Value(Value::Array);
	l.Assign(s, "PwdList") 		= Value(Value::Array);
	l.Assign(s, "DescrList") 	= Value(Value::Array);
	for (int i = 0; i < DLNameList.Size(); i++)
	{
		l.Assign(s, "DLNameList").	ArrayPut(Value(DLNameList[i].Str()));
		l.Assign(s, "PwdList").		ArrayPut(Value(PwdList[i].Str()));
		l.Assign(s, "DescrList").	ArrayPut(Value(DescrList[i].Str()));
	}

	throw Value(r.Str());
}
static Native DL_List("Moses_DL_List", S_Moses_DL_List);

static void S_Moses_DL_Delete(SymbolTable &l)
{
	Src s;

	const char *pDLName		= l.Assign(s, "DLName").GetString();

	STRING r = Moses_DL_Delete( pDLName);

	throw Value(r.Str());
}
static Native DL_Delete("Moses_DL_Delete", S_Moses_DL_Delete);

static void S_Moses_DL_Member_Add(SymbolTable &l)
{
	Src s;

	const char *pDLName		= l.Assign(s, "DLName").GetString();
	const char *pPwd  		= l.Assign(s, "Pwd" ).GetString();
	const char *pUser		= l.Assign(s, "User" ).GetString();

	STRING r = Moses_DL_Member_Add(
			pDLName,
			pPwd, 
			pUser);

	throw Value(r.Str());
}
static Native DL_Member_Add("Moses_DL_Member_Add", S_Moses_DL_Member_Add);

static void S_Moses_DL_Member_Delete(SymbolTable &l)
{
	Src s;

	const char *pDLName		= l.Assign(s, "DLName").GetString();
	const char *pPwd  		= l.Assign(s, "Pwd" ).GetString();
	const char *pUser		= l.Assign(s, "User" ).GetString();

	STRING r = Moses_DL_Member_Delete(
			pDLName,
			pPwd, 
			pUser);

	throw Value(r.Str());
}
static Native DL_Member_Delete("Moses_DL_Member_Delete", S_Moses_DL_Member_Delete);

static void S_Moses_DL_Member_List(SymbolTable &l)
{
	Src s;

	const char *pDLName		= l.Assign(s, "DLName").GetString();
	const char *pPwd  		= l.Assign(s, "Pwd" ).GetString();
	VECT<STRING> UserList;

	STRING r = Moses_DL_Member_List(
			pDLName,
			pPwd, 
			UserList);

	l.Assign(s, "UserList") 	= Value(Value::Array);
	for (int i = 0; i < UserList.Size(); i++)
		l.Assign(s, "UserList").ArrayPut(Value(UserList[i].Str()));

	throw Value(r.Str());
}
static Native DL_Member_List("Moses_DL_Member_List", S_Moses_DL_Member_List);

////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_ART_Add(SymbolTable &l)
{
	Src s;

	const char *pUserName	= l.Assign(s, "UserName").GetString();
	int			bInternal	= l.Assign(s, "bInternal").GetNum();
	const char *pMailBoxType= l.Assign(s, "MailBoxType" ).GetString();
	const char *pMailBoxAddress	= l.Assign(s, "MailBoxAddress" ).GetString();
	const char *pSubjectAdd	= l.Assign(s, "SubjectAdd" ).GetString();

	STRING r = Moses_ART_Add(
			pUserName,
			bInternal, 
			pMailBoxType,
			pMailBoxAddress,
			pSubjectAdd);

	throw Value(r.Str());
}
static Native ART_Add("Moses_ART_Add", S_Moses_ART_Add);

static void S_Moses_ART_Delete(SymbolTable &l)
{
	Src s;

	const char *pUserName	= l.Assign(s, "UserName").GetString();
	int			bInternal	= l.Assign(s, "bInternal").GetNum();
	const char *pMailBoxType= l.Assign(s, "MailBoxType" ).GetString();

	STRING r = Moses_ART_Delete(
			pUserName,
			bInternal, 
			pMailBoxType);

	throw Value(r.Str());
}
static Native ART_Delete("Moses_ART_Delete", S_Moses_ART_Delete);

static void S_Moses_ART_Modify(SymbolTable &l)
{
	Src s;

	const char *pUserName	= l.Assign(s, "UserName").GetString();
	int			bInternal	= l.Assign(s, "bInternal").GetNum();
	const char *pMailBoxType= l.Assign(s, "MailBoxType" ).GetString();
	const char *pMailBoxAddress	= l.Assign(s, "MailBoxAddress" ).GetString();
	const char *pSubjectAdd	= l.Assign(s, "SubjectAdd" ).GetString();

	STRING r = Moses_ART_Modify(
			pUserName,
			bInternal, 
			pMailBoxType,
			pMailBoxAddress,
			pSubjectAdd);

	throw Value(r.Str());
}
static Native ART_Modify("Moses_ART_Modify", S_Moses_ART_Modify);


static void S_Moses_ART_OutAddress(SymbolTable &l)
{
	Src s;

	const char *pUserName	= l.Assign(s, "UserName").GetString();
	const char *pMBoxType	= l.Assign(s, "MBoxType" ).GetString();

	STRING MailBoxType;
	STRING MailAddress;
	STRING SubjectAdd;

	STRING r = Moses_ART_OutAddress(
			pUserName,
			pMBoxType,
			MailBoxType,
			MailAddress,
			SubjectAdd);


	l.Assign(s, "MailBoxType")	=	Value(MailBoxType.Str());
	l.Assign(s, "MailAddress")	=	Value(MailAddress.Str());
	l.Assign(s, "SubjectAdd")	=	Value(SubjectAdd.Str());

	throw Value(r.Str());
}
static Native ART_OutAddress("Moses_ART_OutAddress", S_Moses_ART_OutAddress);


static void S_Moses_ART_InAddress(SymbolTable &l)
{
	Src s;

	const char *pMailBoxType = 	l.Assign(s, "MailBoxType" ).GetString();
	const char *pMailAddress =	l.Assign(s, "MailAddress" ).GetString();
	const char *pSubjectAdd = 	l.Assign(s, "SubjectAdd" ).GetString();

	STRING UserName;

	STRING r = Moses_ART_InAddress(
			pMailBoxType,
			pMailAddress,
			pSubjectAdd,
			UserName);

	l.Assign(s, "UserName")	= Value(UserName.Str());

	throw Value(r.Str());
}
static Native ART_InAddress("Moses_ART_InAddress", S_Moses_ART_InAddress); 

static void S_Moses_ART_List(SymbolTable &l)
{
	Src s;

	int Index = l.Assign(s, "Index" ).GetNum();

	STRING	UserName;
	INT16 	bInternal;
	STRING	MailBoxType;
	STRING	MailBoxAddress;
	STRING	SubjectAdd;
	INT16 	Valid;

	STRING r = Moses_ART_List(
			Index,
			UserName,
			bInternal,
			MailBoxType,
			MailBoxAddress,
			SubjectAdd,
			Valid);

	l.Assign(s, "UserName")		= Value(UserName.Str());
	l.Assign(s, "bInternal")	= Value(STRING::Set(bInternal).Str());
	l.Assign(s, "MailBoxType")	= Value(MailBoxType.Str());
	l.Assign(s, "MailBoxAddress")	= Value(MailBoxAddress.Str());
	l.Assign(s, "SubjectAdd")	= Value(SubjectAdd.Str());
	if (Valid)
		l.Assign(s, "Valid")    = Value("True");
	else
		l.Assign(s, "Valid")    = Value("False");

	throw Value(r.Str());
}
static Native ART_List("Moses_ART_List", S_Moses_ART_List);

static void S_Moses_ART_ListUsers(SymbolTable &l)
{
	Src s;

	const char* MailBoxType = l.Assign(s, "MailBoxType" ).GetString();
	INT16		bInternal 	= l.Assign(s, "bInternal" ).GetNum();

	VECT<STRING>	UsersList;

	STRING r = Moses_ART_ListUsers(
			MailBoxType,
			bInternal,
			UsersList);

	l.Assign(s, "UsersList")		= Value(Value::Array);
	for (int i = 0; i < UsersList.Size(); i++)
		l.Assign(s, "UsersList").ArrayPut(Value(UsersList[i].Str()));

	throw Value(r.Str());
}
static Native ART_ListUsers("Moses_ART_ListUsers", S_Moses_ART_ListUsers);

static void S_Moses_ART_ListAddresses(SymbolTable &l)
{
	Src s;

	const char* MailBoxType = l.Assign(s, "MailBoxType" ).GetString();
	INT16		bInternal 	= l.Assign(s, "bInternal" ).GetNum();

	VECT<STRING>	MailAddressList;

	STRING r = Moses_ART_ListAddresses(
			MailBoxType,
			bInternal,
			MailAddressList);

	l.Assign(s, "MailAddressList")		= Value(Value::Array);
	for (int i = 0; i < MailAddressList.Size(); i++)
		l.Assign(s, "MailAddressList").ArrayPut(Value(MailAddressList[i].Str()));

	throw Value(r.Str());
}
static Native ART_ListAddresses("Moses_ART_ListAddresses", S_Moses_ART_ListAddresses);

////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_Log(SymbolTable &l)
{
	Src s;

	int	ClientId 		= 	l.Assign(s, "ClientId" ).GetNum();
	const char *pLogMsg	=	l.Assign(s, "LogMsg" ).GetString();

	STRING r = Moses_Log(
			ClientId,
			pLogMsg);

	throw Value(r.Str());
}
static Native Log("Moses_Log", S_Moses_Log); 

////////////////////////////////////////////////////////////////////////////////////

static void S_Moses_MS_List(SymbolTable &l)
{
	Src s;

	VECT<STRING> 	TypeList,
					DescrList;

	STRING r = Moses_MS_List( TypeList, DescrList);

	l.Assign(s, "TypeList") = Value(Value::Array);
	for (int i = 0; i < TypeList.Size(); i++)
		l.Assign(s, "TypeList").ArrayPut(Value(TypeList[i].Str()));

	l.Assign(s, "DescrList") = Value(Value::Array);
	for (i = 0; i < DescrList.Size(); i++)
		l.Assign(s, "DescrList").ArrayPut(Value(DescrList[i].Str()));

	throw Value(r.Str());
}
static Native MS_List("Moses_MS_List", S_Moses_MS_List);

static void S_Moses_MS_Add(SymbolTable &l)
{
	Src s;

	const char *pType	= l.Assign(s, "Type").GetString();
	const char *pDescr	= l.Assign(s, "Descr"	).GetString();

	STRING r = Moses_MS_Add( pType, pDescr);

	throw Value(r.Str());
}
static Native MS_Add("Moses_MS_Add", S_Moses_MS_Add);

static void S_Moses_MS_Delete(SymbolTable &l)
{
	Src s;

	const char *pType	= l.Assign(s, "Type").GetString();

	STRING r = Moses_MS_Delete( pType );

	throw Value(r.Str());
}
static Native MS_Delete("Moses_MS_Delete", S_Moses_MS_Delete);

////////////////////////////////////////////////////////////////////////////////////
static void S_Moses_Event_NewMsgInFolder(SymbolTable &l)
{
	Src s;

	const char *pMailBoxName= l.Assign(s, "MailBoxName").GetString();
	const char *pPwd		= l.Assign(s, "Pwd"	).GetString();
	const char *pFolder		= l.Assign(s, "Folder"	).GetString();

	INT32 EventId;

	STRING r = Moses_Event_NewMsgInFolder( pMailBoxName, pPwd, pFolder, EventId);

	l.Assign(s, "EventId")	= Value(STRING::Set(EventId).Str());

	throw Value(r.Str());
}
static Native Event_NewMsgInFolder("Moses_Event_NewMsgInFolder", S_Moses_Event_NewMsgInFolder);

static void S_Moses_Event_Alert_NewMsgInFolder(SymbolTable &l)
{
	Src s;

	INT32 EventId	= l.Assign(s, "EventId").GetNum();

	INT32 MsgId;
	STRING Folder;

	STRING r = Moses_Event_Alert_NewMsgInFolder( EventId, MsgId, Folder );

	l.Assign(s, "MsgId")	= Value(STRING::Set(MsgId).Str());
	l.Assign(s, "Folder")	= Value(Folder.Str());

	throw Value(r.Str());
}
static Native Event_Alert_NewMsgInFolder("Moses_Event_Alert_NewMsgInFolder", S_Moses_Event_Alert_NewMsgInFolder);



static void S_Moses_Event_NewMsgForMTD(SymbolTable &l)
{
	Src s;

	const char *pMailType	= l.Assign(s, "MailType").GetString();

	INT32 EventId;

	STRING r = Moses_Event_NewMsgForMTD( pMailType, EventId);

	l.Assign(s, "EventId")	= Value(STRING::Set(EventId).Str());

	throw Value(r.Str());
}
static Native Event_NewMsgForMTD("Moses_Event_NewMsgForMTD", S_Moses_Event_NewMsgForMTD);

static void S_Moses_Event_Alert_NewMsgForMTD(SymbolTable &l)
{
	Src s;

	INT32 EventId	= l.Assign(s, "EventId").GetNum();

	INT32 MsgId;

	STRING r = Moses_Event_Alert_NewMsgForMTD( EventId, MsgId );

	l.Assign(s, "MsgId")	= Value(STRING::Set(MsgId).Str());

	throw Value(r.Str());
}
static Native Event_Alert_NewMsgForMTD("Moses_Event_Alert_NewMsgForMTD", S_Moses_Event_Alert_NewMsgForMTD);



static void S_Moses_Event_Delete(SymbolTable &l)
{
	Src s;

	INT32 EventId = l.Assign(s,"EventId").GetNum();

	STRING r = Moses_Event_Delete(EventId);

	l.Assign(s, "EventId")	= Value(STRING::Set(EventId).Str());

	throw Value(r.Str());
}
static Native Event_Delete("Moses_Event_Delete", S_Moses_Event_Delete);



static void S_Moses_Event_GetEvent(SymbolTable &l)
{
	Src s;

	INT32 mSec	= l.Assign(s, "mSec").GetNum();

	INT32 EventId;

	STRING r = Moses_Event_GetEvent( mSec, EventId );

	l.Assign(s, "EventId")	= Value(STRING::Set(EventId).Str());

	throw Value(r.Str());
}
static Native Event_GetEvent("Moses_Event_GetEvent", S_Moses_Event_GetEvent);

////////////////////////////////////////////////////////////////////////////////////
/*
static void S_Moses_MB_GetInfo(SymbolTable &l)
{
	Src s;

	const char *pMailbox = l.Assign(s, "Mailbox").GetString();
	const char *pPwd     = l.Assign(s, "Pwd"    ).GetString();
	INT32       MsgId    = l.Assign(s, "MsgId")  .GetNum();

	VECT<STRING> Status;
	STRING       Sender, Destination, Subject;
	INT16        bIncoming;
	INT32        BodySize;

	STRING r = Moses_MB_GetInfo(
			pMailbox,
			pPwd,
			MsgId,
			Status,
			Sender, Destination, Subject,
			bIncoming,
			BodySize);

	l.Assign(s, "Status") = Value(Value::Array);
	for (int i = 0; i < Status.Size(); i++)
		l.Assign(s, "Status").ArrayPut(Value(Status[i].Str()));

	l.Assign(s, "Sender")      = Value(Sender.Str());
	l.Assign(s, "Destination") = Value(Destination.Str());
	l.Assign(s, "Subject")     = Value(Subject.Str());
	l.Assign(s, "MsgId")       = Value(STRING::Set(bIncoming).Str());
	l.Assign(s, "BodySize")    = Value(STRING::Set(BodySize).Str());

	throw Value(r.Str());
}

static Native MB_GetInfo("Moses_MB_GetInfo", S_Moses_MB_GetInfo);

*/
