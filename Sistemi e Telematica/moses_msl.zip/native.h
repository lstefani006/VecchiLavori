#include <st_dbnew.h>

#include <symtb.h>

class Native
{
public:
	Native(const char *FunctionName, void (*pFun)(SymbolTable &));
	static void Execute(const char *FunctionName, SymbolTable &l);

private:
	struct Reg
	{
		const char *FunctionName;
		void (*pFunction)(SymbolTable &l);
	};

	static Reg Tb[1000];
	static int Top;
};
