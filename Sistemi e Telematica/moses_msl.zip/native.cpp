#include <st_dbnew.h>
#include <native.h>

Native::Native(const char *FunctionName, void (*pFun)(SymbolTable &))
{
	Tb[Top].FunctionName = FunctionName;
	Tb[Top].pFunction= pFun;
	Top++;
}


void Native::Execute(const char *FunctionName, SymbolTable &l)
{
	for (int i = 0; i < Top; i++)
		if (StrEq(Tb[i].FunctionName, FunctionName))
		{
			(*(Tb[i].pFunction))(l);
			break;
		}
}


Native::Reg Native::Tb[1000];
int Native::Top = 0;
