#include <st_dbnew.h>
#ifndef _VAR_H_
#define _VAR_H_

#include <st_tvect.h>

class Expr;

class Var
{
public:
	Var(const char *, int bOut = 0);
	~Var();

	Var(const Var &);
	void operator = (const Var &r);

	const char *GetSymbol() const { return m_pStr; }

	void SetOut(int bOut) { m_bOut = bOut; }
	int IsOut() const { return m_bOut; }

protected:
	char *m_pStr;
	int  m_bOut;
};

class VarList
{
public:
	VarList() {}

	void Add(Var *v) { m_v.Append(v); }

	const Var * Get(int i) const { return i < m_v.Size() ? m_v[i] : 0; }
	Var * Get(int i) { return i < m_v.Size() ? m_v[i] : 0; }

	int GetNum() const { return m_v.Size(); }

	int IsOut(int i) const { return m_v[i]->IsOut(); }

protected:

	STTVect<Var *> m_v;
};

#endif
