#include <st_dbnew.h>
#include <stdio.h>
#include <stdlib.h>

#include "./st_tvect.h"
#ifdef DBCLEO
#include <st_dbxx.h>
#endif

#include "p.h"
#include "value.h"

extern int yyparse();

#ifdef YYDEBUG
extern int yydebug;
#endif

extern FILE *yyin;

#ifdef DBCLEO
STDbTransaction *G_DbTransaction = 0;
#endif

#ifdef DECCXX
#pragma define_template STTVect<int>
#endif

const char * GoCleo(int ac, char **av);

int main(int ac, char *av[])
{
#ifdef DBCLEO
	if (getenv("ST_DB_LOGIN") == NULL || getenv("ST_DB_PASSW") == NULL)
	{
		cerr << "specificare le var. di env. ST_DB_LOGIN ST_DB_PASSW" << endl;
		exit(1);
	}

	STDbG::DbMain();
	STDbG::DbCreateSql(ac, av);
	// STDbG::DbInfo();

	STDbConnection cn;
	cn.Login(getenv("ST_DB_LOGIN"), getenv("ST_DB_PASSW"));

	G_DbTransaction = STNew STDbTransaction(cn);
	G_DbTransaction->BeginTransaction();
#endif

#ifdef YYDEBUG
	yydebug = 0;
#endif

	ac--;
	av++;
	cout << GoCleo(ac, av) << endl;

#ifdef DBCLEO
	STDelete G_DbTransaction;
#endif

	return 0;
}


const char * GoCleo(int ac, char **av)
{
	static char *b = STNew char [1024 * 1024];

	/* apro il file da interpretare */
	if (ac == 0)
	{
		sprintf(b, "Error: use cleo file function");
		return b;
	}

	int opz_t = 0;
	if (ac >= 1 && strcmp(av[0], "-t") == 0)
	{
		ac--;
		av++;

		opz_t = 1;
	}

	if (ac >= 1)
		yyin = fopen(av[0], "r");
	if (yyin == NULL)
	{
		sprintf(b, "Error: cannot open file %s", av[0]);
		return b;
	}
	PushFile(av[0]);
	ac--;
	av++;

	if (ac < 1)
	{
		sprintf(b, "Error: main function required");
		return b;
	}
	const char *pMain = av[0];
	ac--;
	av++;

	Value *p = STNew Value[ac];
	for (int i = 0; i < ac; i++)
		p[i] = av[i];

	Value r;
	try 
	{
		yyparse();
		if (opz_t)
			return "";

		Function *pFunction = Program.SearchFunction(pMain);
		if (pFunction)
			r = pFunction->Execute(ac, p);
		else
		{
			Src s;
			s.File = "cleo";
			s.Line = 0;
			RunTimeError(s, "function \"%s\" not found", pMain);
		}
	}
	catch(SyntaxError err)
	{
		r = err.Msg;
	}

	STDelete [] p;

	if (yyin)
		fclose(yyin);

	if (!r.IsArray())
		strncpy(b, r.GetString(), 1024 * 1024);
	else
		sprintf(b, "Error: returning an array from main function");
	return b;
}
