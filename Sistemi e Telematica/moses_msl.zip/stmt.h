#include <st_dbnew.h>
#ifndef _STMT_H
#define _STMT_H

#ifdef LINUX
#include <typeinfo.h>
#endif
#include <iostream.h>

#include "expr.h"
int StrEq(const char *, const char *);

class SymbolTable;

#ifndef SRC_DEFINED
#define SRC_DEFINED
struct Src
{
	const char *File;
	const char *Line;
};
#endif

// LEO mancano i distruttori

class Stmt
{
public:
	Stmt(Src s) : m_Src(s) {}
	virtual ~Stmt() {}
	virtual void Execute(SymbolTable *) const = 0;

	const Src GetSrc() const { return m_Src; }

protected:
	Src m_Src;
};

class StmtNull : public Stmt
{
public:
	StmtNull(Src s) : Stmt(s) {}
	virtual void Execute(SymbolTable *) const;
};

class StmtIf : public Stmt
{
public:
	StmtIf(Src s, Expr *e, Stmt *a, Stmt *b) : Stmt(s) { m_pExpr = e; m_pStmt1 = a; m_pStmt2 = b; }
	~StmtIf() { STDelete m_pExpr; STDelete m_pStmt1; STDelete m_pStmt2; }
	void Execute(SymbolTable *) const;
protected:
	Expr *m_pExpr;
	Stmt *m_pStmt1;
	Stmt *m_pStmt2;
};


class StmtWhile : public Stmt
{
public:
	StmtWhile(Src s, Expr *e, Stmt *a) : Stmt(s) { m_pExpr = e; m_pStmt1 = a; }
	~StmtWhile() { STDelete m_pExpr; STDelete m_pStmt1; }
	void Execute(SymbolTable *) const;
protected:
	Expr *m_pExpr;
	Stmt *m_pStmt1;
};

class StmtFor : public Stmt
{
public:
	StmtFor(Src w, Expr *v, Expr *a, Expr *b, Expr *c, Stmt *s) : Stmt(w) { m_v = v; m_a = a; m_b = b; m_c = c; m_s = s; }
	~StmtFor() { STDelete m_v; STDelete m_a; STDelete m_b; STDelete m_c; STDelete m_s; }
	void Execute(SymbolTable *) const;
protected:
	Expr *m_v;
	Expr *m_a;
	Expr *m_b;
	Expr *m_c;
	Stmt *m_s;
};

class StmtList : public Stmt
{
public:
	StmtList(Src s, Stmt *a, Stmt *b) : Stmt(s) { m_pStmt1 = a; m_pStmt2 = b; }
	~StmtList() { STDelete m_pStmt1; STDelete m_pStmt2; }
	void Execute(SymbolTable *) const;

protected:
	Stmt *m_pStmt1;
	Stmt *m_pStmt2;
};

class StmtReturn : public Stmt
{
public:
	StmtReturn(Src s, Expr *a) : Stmt(s) { m_pExpr = a; }
	~StmtReturn() { STDelete m_pExpr; }
	void Execute(SymbolTable *) const;
protected:
	Expr *m_pExpr;
};

class StmtThrow : public Stmt
{
public:
	StmtThrow(Src s, Expr *a) : Stmt(s) { m_pExpr = a; }
	~StmtThrow() { STDelete m_pExpr; }
	void Execute(SymbolTable *) const;
protected:
	Expr *m_pExpr;
};

class StmtExHandling : public Stmt
{
public:
	StmtExHandling(Src s) : Stmt(s) {}
	virtual int CatchAndExecute(SymbolTable *, const Value &) const = 0; // usata per eseguire la Finally (se c'e`) e il Catch opportuno quando viene lanciata una eccezione
	virtual void ExecuteFinally(SymbolTable *) const = 0; // usata per eseguire il Finally sul Return dentro una Try
};

class StmtCatch : public StmtExHandling
{
public:
	StmtCatch(Src s, StmtExHandling *pLeftExHandling, Expr *pExpr, Stmt *pStmt) : StmtExHandling(s) { m_pLeftExHandling = pLeftExHandling; m_pExpr = pExpr; m_pStmt = pStmt; }
	~StmtCatch() { STDelete m_pLeftExHandling; STDelete m_pExpr; STDelete m_pStmt; }
	void Execute(SymbolTable *) const;
	int  CatchAndExecute(SymbolTable *, const Value &) const; // returns 1 if catched
	virtual void ExecuteFinally(SymbolTable *) const;
protected:
	StmtExHandling   *m_pLeftExHandling;
	Expr        *m_pExpr;
	Stmt        *m_pStmt;
};

class StmtFinally : public StmtExHandling
{
public:
	StmtFinally(Src s, Stmt *pStmt) : StmtExHandling(s) { m_pStmt = pStmt; }
	~StmtFinally() { STDelete m_pStmt; }
	void Execute(SymbolTable *) const;
	int  CatchAndExecute(SymbolTable *, const Value &) const; // returns always zero
	virtual void ExecuteFinally(SymbolTable *) const;

protected:
	Stmt      *m_pStmt;
};


class StmtTry : public Stmt
{
public:
	StmtTry(Src s, Stmt *pTry, StmtExHandling *pExHandling) : Stmt(s) { m_pTry = pTry; m_pExHandling = pExHandling; }
	~StmtTry(){ STDelete m_pTry; STDelete m_pExHandling; }

	void Execute(SymbolTable *) const;

protected:
	Stmt      *m_pTry;
	StmtExHandling *m_pExHandling;
};

class StmtPrint : public Stmt
{
public:
	StmtPrint(Src s, Expr *a) : Stmt(s) { m_pExpr = a; }
	~StmtPrint() { STDelete m_pExpr; }
	void Execute(SymbolTable *) const;
protected:
	Expr *m_pExpr;
};

class StmtContinue : public Stmt
{
public:
	StmtContinue(Src s) : Stmt(s) {}
	~StmtContinue() {}
	void Execute(SymbolTable *) const;
};

class StmtBreak : public Stmt
{
public:
	StmtBreak(Src s) : Stmt(s) {}
	~StmtBreak() {}
	void Execute(SymbolTable *) const;
};

class StmtInput : public Stmt
{
public:
	StmtInput(Src s, Expr *a, int bLine) : Stmt(s) { m_pExpr = a; m_bLine = bLine; }
	~StmtInput() { STDelete m_pExpr; }
	void Execute(SymbolTable *) const;
protected:
	Expr *m_pExpr;
	int   m_bLine;
};

class StmtAssign : public Stmt
{
public:
	StmtAssign(Src s, Expr *v, Expr *a) : Stmt(s) { m_pExprLeft = v; m_pExpr = a; }
	~StmtAssign() { STDelete m_pExprLeft; STDelete m_pExpr; }
	void Execute(SymbolTable *) const;
protected:
	Expr    *m_pExprLeft;
	Expr    *m_pExpr;
};

class StmtCall : public Stmt
{
public:
	StmtCall(Src s, Expr *a, ExprList *b) : Stmt(s) { m_a = a; m_b = b; }
	~StmtCall() { STDelete m_a; STDelete m_b; }
	void Execute(SymbolTable *) const;
protected:
	Expr      *m_a;
	ExprList  *m_b;
};

class StmtCase : public Stmt
{
public:
	StmtCase(Src s, Expr *e, Stmt *d, StmtCase *c) 
		: Stmt(s) { m_pExpr = e; m_pStmtCase = c; m_pStmt = d; }
	StmtCase(Src s, Stmt *d, StmtCase *c)
		: Stmt(s) { m_pExpr = NULL; m_pStmtCase = c; m_pStmt = d; }
	~StmtCase() { STDelete m_pExpr; STDelete m_pStmtCase; STDelete m_pStmt; }
	void Execute(SymbolTable *) const { cerr << "ERRORE INTERNO"; }
	int TestAndExecute(SymbolTable *, const Value &r);
protected:
	Expr     *m_pExpr;
	StmtCase *m_pStmtCase;
	Stmt     *m_pStmt;
};

class StmtSwitch : public Stmt
{
public:
	StmtSwitch(Src s, Expr *e, StmtCase *c) : Stmt(s) { m_pExpr = e; m_pStmt = c; }
	~StmtSwitch() { STDelete m_pExpr; STDelete m_pStmt; }
	void Execute(SymbolTable *) const;
protected:
	Expr *m_pExpr;
	StmtCase *m_pStmt;
};

//////////////////////////////////////////////////////////////////

class External
{
public:
	virtual ~External() {}
	virtual const char *Name() const = 0;
	virtual const Src GetSrc() const = 0;

	virtual int IsFunction() const { return 0; }
	virtual int IsObject()   const { return 0; }
};

class Function : public External
{
public:
	Function(Src s, Var *Name, VarList *a, VarList *b, Stmt *c, int bReturn)
	{
		m_Src             = s;
		m_pVarName        = Name;
		m_pVarList_Args   = a;
		m_pVarList_Vars   = b;
		m_pStmt           = c;
		m_pObject         = NULL;
		m_bReturn         = bReturn;
	}

	virtual ~Function() {}

	Value Execute(int nNumVal, Value *);

	int GetNumParams() const;

	const char *Name() const;

	const Src GetSrc() const { return m_Src; }

	const VarList * GetVarList() const { return m_pVarList_Args; }

	virtual int IsFunction() const { return 1; }

	void InObject(const class Object *p);

	int IsProcedure() const { return m_bReturn == 0; }

protected:
	Src      m_Src;
	Var     *m_pVarName;
	VarList *m_pVarList_Args;
	VarList *m_pVarList_Vars;
	Stmt    *m_pStmt;

	int      m_bReturn;

	class Object *m_pObject;
};


class Object : public External
{
public:
	Object(Src s, const Var &Name)
	{
		m_Src             = s;
		m_pVarName        = STNew Var(Name);
	}

	virtual ~Object() { STDelete m_pVarName; }

	virtual const char *Name() const { return m_pVarName->GetSymbol(); }

	void Add(VarList *p)  { Var *v; for (int i = 0; (v = p->Get(i)) != NULL; i++) m_Vars.Append(v); }

	const Src GetSrc() const { return m_Src; }

	virtual int IsObject() const { return 1; }

	int GetNumOfMembers() const { return m_Vars.Size(); }

	int GetIndexOf(const char *p) const
	{
		for (int i = 0; i < m_Vars.Size(); i++)
			if (StrEq(m_Vars[i]->GetSymbol(), p))
				return i;
		return -1;
	}

	const char * GetFieldName(int i) const
	{
		for (int k = 0; k < m_Vars.Size(); k++)
			if (i == k)
				return m_Vars[i]->GetSymbol();
		return 0;
	}

protected:
	Src      m_Src;
	Var     *m_pVarName;

	STTVect<Var *>      m_Vars;
};

void RunTimeError(Src s, const char *Msg, ...);

#endif
