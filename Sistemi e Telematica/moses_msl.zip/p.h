#include <st_dbnew.h>
#ifndef _P_H_
#define _P_H_

#ifdef    LINUX
#include <typeinfo.h>
#endif // LINUX

#include <iostream.h>
#include <string.h>

#include "expr.h"
#include "var.h"
#include "stmt.h"
#include "st_tvect.h"
#include "symtb.h"

int StrEq(const char *, const char *);

#if defined(_WIN32)
	#define isatty(a) 0
	#define alloca(a) malloc(a)
#endif


#ifndef SRC_DEFINED
#define SRC_DEFINED
struct Src
{
	const char *File;
	int         Line;
};
#endif

Src  GetSrc();
void PushFile(const char *f);


struct SyntaxError
{
	const char *Msg;
	SyntaxError(const char *p) { Msg = p; }
};

void RunTimeError(Src s, const char *Msg, ...);

#endif
