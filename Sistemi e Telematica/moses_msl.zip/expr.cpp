#include <st_dbnew.h>
#include <string.h>
#include <stdlib.h>
#ifdef    LINUX
#include <typeinfo.h>
#endif // LINUX
#include <iostream.h>

#ifdef _WIN32
#include <strstrea.h>
#else
#include <strstream.h>
#endif 

#include "expr.h"
#include "stmt.h"
#include "symtb.h"
#include "p.h"

#ifdef DBCLEO
#include <st_dbxx.h>
#endif

#ifdef __DECCXX
#pragma define_template STTVect<Expr *>
#endif


ExprString::ExprString(Src s, const char *p, int sz)
	: Expr(s)
{
	m_a = strdup(p);
	if (sz != -1)
		m_a[sz] = 0;
}

ExprString::~ExprString()
{
	free(m_a);
}

Value ExprString::Execute(SymbolTable *) const
{
	return Value(m_a);
}

ExprList::~ExprList()
{
	for (int i = 0; i < m_lst.Size(); i++)
		STDelete m_lst[i];
}

Value ExprOr::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsBool() && b.IsBool()))
		RunTimeError(GetSrc(), "operator OR called with no boolean values");
	return a || b;
}

Value ExprAnd::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsBool() && b.IsBool()))
		RunTimeError(GetSrc(), "operator AND called with no boolean values");
	return a && b;
}

Value ExprNot::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	if (!a.IsBool())
		RunTimeError(GetSrc(), "operator NOT called with no boolean value");
	return !a;
}

Value ExprGT::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsString() && b.IsString()))
		RunTimeError(GetSrc(), "operator > called with no scalar values");
	return a > b;
}

Value ExprGE::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsString() && b.IsString()))
		RunTimeError(GetSrc(), "operator >= called with no scalar values");
	return a >= b;
}

Value ExprLT::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsString() && b.IsString()))
		RunTimeError(GetSrc(), "operator < called with no scalar values");
	return a < b;
}

Value ExprLE::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsString() && b.IsString()))
		RunTimeError(GetSrc(), "operator <= called with no scalar values");
	return a <= b;
}

Value ExprEQ::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	return a == b;
}

Value ExprNE::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	return a != b;
}

Value ExprPlus::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsNum() && b.IsNum()))
		RunTimeError(GetSrc(), "operator + called with no numeric values");
	return a + b;
}

Value ExprMinus::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsNum() && b.IsNum()))
		RunTimeError(GetSrc(), "operator - called with no numeric values");
	return a - b;
}

Value ExprTimes::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsNum() && b.IsNum()))
		RunTimeError(GetSrc(), "operator * called with no numeric values");
	return a * b;
}

Value ExprDiv::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsNum() && b.IsNum()))
		RunTimeError(GetSrc(), "operator / called with no numeric values");
	if (a.IsZero())
		RunTimeError(GetSrc(), "divide by zero");
	return a / b;
}

Value ExprNeg::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	if (!a.IsNum())
		RunTimeError(GetSrc(), "operator - called with no numeric value");
	return -a;
}

Value ExprVar::Execute(SymbolTable *t) const
{
	return t->Search(GetSrc(), m_a->GetSymbol());
}

Value * ExprVar::GetLeftValue(SymbolTable *t)
{
	Value &v = t->Assign(GetSrc(), m_a->GetSymbol());
	return &v;
}

Value ExprConcat::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));
	Value b(m_b->Execute(t));
	if (!(a.IsString() && b.IsString()))
		RunTimeError(GetSrc(), "operator & called with no scalar values");
	return a & b;
}

Value ExprFun::Execute(SymbolTable *t) const
{
	const char *pFunName = NULL;
	if (m_a->IsExprVar())
		pFunName = ((ExprVar *)m_a)->GetVar();
	else
	if (m_a->IsExprDot())
	{
		ExprDot *pExprDot = (ExprDot *)m_a;
		pFunName = pExprDot->GetField()->GetSymbol();
	}
	else
		RunTimeError(GetSrc(), "syntax error");
	const char *pObjType = NULL;
	Value self;
	if (m_a->IsExprDot())
	{
		ExprDot *pExprDot = (ExprDot *)m_a;
		self = pExprDot->GetLeftExpr()->Execute(t);
		if (!self.IsObject())
			RunTimeError(GetSrc(), "calling a function \"%s\" without an object", pFunName);
		pObjType = self.IsObject()->Name();
	}
	Function *f = Program.SearchFunction(pFunName, pObjType);
	if (f == NULL)
	{
		if (pObjType == NULL)
			RunTimeError(GetSrc(), "call to undefined function \"%s\"", pFunName);
		else
			RunTimeError(GetSrc(), "call to undefined function \"%s.%s\"", pObjType, pFunName);
	}
	if (f->IsProcedure())
		RunTimeError(GetSrc(), "call to a procedure instead of function");
	if (pObjType == NULL && m_b->Size() != f->GetNumParams() ||
			pObjType != NULL && m_b->Size() + 1 != f->GetNumParams())
		RunTimeError(GetSrc(),
				"wrong number of arguments in function call \"%s\"",
				f->Name());
	Value *v = STNew Value [f->GetNumParams()];
	{
		int i;
		for (i = 0; i < m_b->Size(); i++)
			v[i] = m_b->Get(i)->Execute(t);
		if (pObjType)
			v[i] = self;
	}
	Value r(f->Execute(f->GetNumParams(), v));
	// ricopio i parametri in uscita
	const VarList *pVarListOut = f->GetVarList();
	pVarListOut->GetNum();
	{
		for (int i = 0; i < pVarListOut->GetNum(); i++)
			if (pVarListOut->IsOut(i))
			{
				Value *pV = m_b->Get(i)->GetLeftValue(t);
				if (pV == NULL)
					RunTimeError(GetSrc(),
							"not a left value on %dth parameter in function call \"%s\"",
							i + 1,
							f->Name());
				*pV = v[i];
			}
	}
	STDelete [] v;
	return r;
}

#ifdef DBCLEO
extern STDbTransaction *G_DbTransaction;
#endif
Value ExprFind::Execute(SymbolTable *t) const
{
#ifdef DBCLEO
	if (m_b->Size() != 3)
		RunTimeError(GetSrc(), "wrong number of arguments in function Find");
	Value Tabella  (m_b->Get(0)->Execute(t));
	Value Colonna  (m_b->Get(1)->Execute(t));
	Value Condition(m_b->Get(2)->Execute(t));
	Value Sql("select " & Colonna & " from " & Tabella & " where " & Condition);
	DbString r(4096);
	Value v;
	try
	{
		STDbStmt stmt(*G_DbTransaction);
		stmt.Parse(Sql.GetString());
		stmt.Bind(&r);
		stmt.Exec();
		while (stmt.Fetch() == ST_DB_OK)
		{
			Value vr(r);
			v.ArrayPut(vr);
			stmt.Bind(&r);
		}
	}
	catch (STDbException &r)
	{
		return Value("Error: ") & r.Msg();
	}
	return v;
#else
	Value r;
	r.ArrayPut(Value("leo"));
	r.ArrayPut(Value("stefani"));
	return r;
#endif
}

Value ExprLen::Execute(SymbolTable *t) const
{
	Value v(m_b->Execute(t));
	if (!v.IsString())
		RunTimeError(GetSrc(), "function Len called with no scalar value");
	return Len(m_b->Execute(t));
}

Value ExprDim::Execute(SymbolTable *t) const
{
	Value v(m_b->Execute(t));
	if (!v.IsArray())
		RunTimeError(GetSrc(), "function Dim called with no array value");
	return Dim(v);
}

Value ExprChr::Execute(SymbolTable *t) const
{
	Value v(m_b->Execute(t));
	if (!v.IsNum())
		RunTimeError(GetSrc(), "function Chr called with no numeric value");
	int n = (int) v.GetNum();
	char b[2];
	b[0] = (char)n;
	b[1] = '\0';
	return Value(b);
}

Value ExprVal::Execute(SymbolTable *t) const
{
	Value v(m_b->Execute(t));
	if (!v.IsString())
		RunTimeError(GetSrc(), "function Val called with no scalar value");
	if (v.Len() != 1)
		RunTimeError(GetSrc(), "function Val called with scalar value of len <> 1");
		
	int n = *v.GetChar();
	char b[100];
	ostrstream s(b, sizeof(b));
	s << n << ends;
	return Value(b);
}

Value ExprArray::Execute(SymbolTable *t) const
{
	Value a(m_a->Execute(t));

	if (a.IsArray())
	{
		Value b;
		Value c;
		if (m_b == NULL && m_c != NULL)
		{
			b = Value("1");
			c = m_c->Execute(t);
		}
		else
		if (m_b != NULL && m_c == NULL)
		{
			b = m_b->Execute(t);
			c = Dim(a);
		}
		else
		{
			b = m_b->Execute(t);
			c = m_c->Execute(t);
		}

		if (!(b.IsNum() && c.IsNum()))
			RunTimeError(GetSrc(), "operator [] called with no numeric values");

		int ib = (int) b.GetNum();
		int ic = (int) c.GetNum();
		int l  = a.Dim();

		if (ib < 1 || ic < 1 || ib > l || ic > l || ic < ib)
			RunTimeError(GetSrc(), "operator [] called with index out of range");

		return Sub(a, b, c);
	}
	else
	if (a.IsString())
	{
		Value b;
		Value c;
		if (m_b == NULL && m_c != NULL)
		{
			b = Value("1");
			c = m_c->Execute(t);
		}
		else
		if (m_b != NULL && m_c == NULL)
		{
			b = m_b->Execute(t);
			c = Len(a);
		}
		else
		{
			b = m_b->Execute(t);
			c = m_c->Execute(t);
		}

		if (!(b.IsNum() && c.IsNum()))
			RunTimeError(GetSrc(), "operator [] called with no numeric values");

		int ib = (int) b.GetNum();
		int ic = (int) c.GetNum();
		int l  = a.Len();

		if (ib < 1 || ic < 1 || ib > l || ic > l || ic < ib)
			RunTimeError(GetSrc(), "operator [] called with index out of range");

		return Sub(a, b, c);
	}
	else
	{
		RunTimeError(GetSrc(), "operator [] called with no array or scalar value");
		return Value();
	}
}

Value * ExprArray::GetLeftValue(SymbolTable *t)
{
	// LEO non e' supportato una cosa come a[4] = "4" quando a e' uno scalare

	Value *a = m_a->GetLeftValue(t);
	if (a == NULL)
		RunTimeError(GetSrc(), "operator [] called with no left value");

	if (a->IsString() && a->Len() > 0)
	{
		RunTimeError(GetSrc(), "operator [] on left side called with scalar value is not supported");
		return NULL;
	}
	else
	if (a->IsString() && a->Len() == 0 || a->IsArray() || a->IsObject())
	{
		if (!a->IsArray())
			*a = Value(Value::Array);

		Value b;
		Value c;
		if (m_b == NULL && m_c != NULL)
		{
			b = Value("1");
			c = m_c->Execute(t);
		}
		else
		if (m_b != NULL && m_c == NULL)
		{
			b = m_b->Execute(t);
			c = Dim(*a);
		}
		else
		{
			b = m_b->Execute(t);
			c = m_c->Execute(t);
		}

		if (!(b.IsNum() && c.IsNum()))
			RunTimeError(GetSrc(), "operator [] called with no numeric values");

		int ib = (int) b.GetNum() - 1;
		int ic = (int) c.GetNum() - 1;
		if (ib != ic)
			RunTimeError(GetSrc(), "operator [ TO ] not supported with arrays");

		if (ib < 0 || ic < 0 || ic < ib)
			RunTimeError(GetSrc(), "operator [] called with index out of range");

		while (ib >= a->Dim())
			a->ArrayPut(Value());

		return & a->ArrayGet(ib);
	}
	else
	{
		RunTimeError(GetSrc(), "operator [] called with wrong value type");
		return NULL;
	}
}

Value ExprNew::Execute(SymbolTable *) const
{
	Object *p = Program.SearchObject(m_a->GetSymbol());
	if (p == NULL)
		RunTimeError(GetSrc(), "cannot create object \"%s\"", m_a->GetSymbol());
	return Value(Value::Object, p);
}

Value ExprDot::Execute(SymbolTable *t) const
{
	return *((ExprDot*)this)->GetLeftValue(t);
}

Value * ExprDot::GetLeftValue(SymbolTable *t)
{
	Value a = m_a->Execute(t);
	if (!a.IsObject())
		RunTimeError(GetSrc(), "operator . called without object");
	Value *p = a.GetField(m_b->GetSymbol());
	if (p == NULL)
		RunTimeError(GetSrc(), "unknow field \"%s\" in object \"%s\"",
				m_b->GetSymbol(),
				a.IsObject()->Name());
	return p;
}

