#include <st_dbnew.h>
#include "var.h"

#include <stdlib.h>
#include <string.h>


Var::Var(const char *p, int bOut)
{
	m_pStr = strdup(p);
	m_bOut = bOut;
}

Var::~Var()
{
	if (m_pStr)
		free (m_pStr);
}

Var::Var(const Var &r)
{
	m_pStr = strdup(r.m_pStr);
	m_bOut = r.m_bOut;
}


void Var::operator = (const Var &r)
{
	if (m_pStr)
		free (m_pStr);

	m_pStr = strdup(r.m_pStr);
	m_bOut = r.m_bOut;
}
