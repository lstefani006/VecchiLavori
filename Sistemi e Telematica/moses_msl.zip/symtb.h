#include <st_dbnew.h>
#ifndef __SYMTB_H__
#define __SYMTB_H__

#include "stmt.h"
#include "var.h"


/*
 * contiene le variabili locali ad una funzione
 */
class SymbolTable
{
public:
	SymbolTable();
	~SymbolTable();

	Value Search(Src s, const char *Name);
	void Insert(Src s, const char *Name);
	void Insert(Src s, const char *Name, const Value &);
	Value & Assign(Src s, const char *Name);

	Value & operator [] (int i) { return m_aValue[i]; }
	int numOfVars() const { return m_aValue.Size(); }

protected:
	int m_sz;
	char **m_pName;
	STTVect<Value> m_aValue;
};

/*
 * Contiene la lista delle funzioni o funzioni membro
 * e dei nomi degli oggetti
 */
class SymbolTable_Program
{
public:
	SymbolTable_Program();

	void Add(External *p);
	Function * SearchFunction(const char *pFuntcionName, const char *pObjType = NULL);
	Object   * SearchObject(const char *pObjectName);

private:
	STTVect<External *> m_lst;
};

extern SymbolTable_Program Program;

#endif
