typedef union {
	Expr      *pExpr;
	ExprList  *pExprList;
	Var       *pVar;
	Stmt      *pStmt;
	StmtCase  *pStmtCase;
	VarList   *pVarList;
	Function  *pFunction;
	Object    *pObject;
	StmtExHandling *pStmtExHandling;
} YYSTYPE;
#define	FUNCTION	258
#define	PROCEDURE	259
#define	P_BEGIN	260
#define	P_END	261
#define	NATIVE	262
#define	VAR	263
#define	IN	264
#define	OUT	265
#define	IF	266
#define	THEN	267
#define	ELSE	268
#define	WHILE	269
#define	FOR	270
#define	TO	271
#define	STEP	272
#define	RETURN	273
#define	PRINT	274
#define	INPUT	275
#define	INPUTLINE	276
#define	STRING	277
#define	VAR_ID	278
#define	FIND	279
#define	LEN	280
#define	DIM	281
#define	NEW	282
#define	SWITCH	283
#define	CASE	284
#define	DEFAULT	285
#define	CONTINUE	286
#define	BREAK	287
#define	TRY	288
#define	CATCH	289
#define	THROW	290
#define	FINALLY	291
#define	CHR	292
#define	VAL	293
#define	OR	294
#define	AND	295
#define	GT	296
#define	GE	297
#define	LT	298
#define	LE	299
#define	EQ	300
#define	NE	301
#define	NOT	302
#define	NEG	303
#define	OBJECT	304


extern YYSTYPE yylval;
