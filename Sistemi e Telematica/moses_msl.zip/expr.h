#include <st_dbnew.h>
#ifndef _EXPR_H_
#define _EXPR_H_

#ifndef SRC_DEFINED
#define SRC_DEFINED
struct Src
{
	const char *File;
	int         Line;
};
#endif

#include "value.h"
#include "var.h"

#include "st_tvect.h"

class SymbolTable;

class Expr
{
public:
	Expr(Src s) : m_Src(s) {}
	virtual ~Expr() {}

	virtual	Value Execute(SymbolTable *) const = 0;

	const Src GetSrc() const { return m_Src; }

	virtual Value * GetLeftValue(SymbolTable *) { return NULL; }


	virtual int IsExprDot() const { return 0; }
	virtual int IsExprVar() const { return 0; }

protected:
	Src m_Src;
};

class ExprString : public Expr
{
public:
	ExprString(Src s, const char *p, int sz = -1);
	~ExprString();
	virtual	Value Execute(SymbolTable *) const;
protected:
	char *m_a;
};

class ExprOr : public Expr
{
public:
	ExprOr(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprOr() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprAnd : public Expr
{
public:
	ExprAnd(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprAnd() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprNot : public Expr
{
public:
	ExprNot(Src s, Expr *a) : Expr(s) { m_a = a; }
	~ExprNot() { STDelete m_a; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
};

class ExprGT : public Expr
{
public:
	ExprGT(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprGT() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprGE : public Expr
{
public:
	ExprGE(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprGE() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprLT : public Expr
{
public:
	ExprLT(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprLT() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprLE : public Expr
{
public:
	ExprLE(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprLE() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprEQ : public Expr
{
public:
	ExprEQ(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprEQ() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprNE : public Expr
{
public:
	ExprNE(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprNE() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprPlus : public Expr
{
public:
	ExprPlus(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprPlus() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprMinus : public Expr
{
public:
	ExprMinus(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprMinus() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprTimes : public Expr
{
public:
	ExprTimes(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprTimes() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprDiv : public Expr
{
public:
	ExprDiv(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprDiv() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprConcat : public Expr
{
public:
	ExprConcat(Src s, Expr *a, Expr *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprConcat() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
	Expr *m_b;
};

class ExprNeg : public Expr
{
public:
	ExprNeg(Src s, Expr *a) : Expr(s) { m_a = a; }
	~ExprNeg() { STDelete m_a; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_a;
};

class ExprVar : public Expr
{
public:
	ExprVar(Src s, Var *a) : Expr(s) { m_a = a; }
	~ExprVar() { STDelete m_a; }
	virtual	Value Execute(SymbolTable *) const;
	virtual Value * GetLeftValue(SymbolTable *);

	virtual int IsExprVar() const { return 1; }
	const char * GetVar() const { return m_a->GetSymbol(); }

protected:
	Var  *m_a;
};

class ExprList
{
public:
	ExprList() {}
	~ExprList();

	void Add(Expr *e) { m_lst.Append(e); }
	Expr * Get(int i) const { return m_lst[i]; }
	int Size() const { return m_lst.Size(); }

protected:
	STTVect<Expr *> m_lst;
};

class ExprFun : public Expr
{
public:
	ExprFun(Src s, Expr *e, ExprList *b) : Expr(s) { m_a = e; m_b = b; }
	~ExprFun() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr     *m_a;          // il nome della funzione ossia ExprVar o ExprDot
	ExprList *m_b;          // la lista degli argomenti
};

class ExprFind : public Expr
{
public:
	ExprFind(Src s, ExprList *b) : Expr(s) { m_b = b; }
	~ExprFind() { STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	ExprList *m_b;
};

class ExprLen : public Expr
{
public:
	ExprLen(Src s, Expr *b) : Expr(s) { m_b = b; }
	~ExprLen() { STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_b;
};

class ExprDim : public Expr
{
public:
	ExprDim(Src s, Expr *b) : Expr(s) { m_b = b; }
	~ExprDim() { STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_b;
};

class ExprChr : public Expr
{
public:
	ExprChr(Src s, Expr *b) : Expr(s) { m_b = b; }
	~ExprChr() { STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_b;
};

class ExprVal : public Expr
{
public:
	ExprVal(Src s, Expr *b) : Expr(s) { m_b = b; }
	~ExprVal() { STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Expr *m_b;
};

class ExprArray : public Expr
{
public:
	ExprArray(Src s, Expr *a, Expr *b, Expr *c) : Expr(s) { m_a = a; m_b = b; m_c = c; }
	~ExprArray() { STDelete m_a; STDelete m_b; STDelete m_c; }
	virtual	Value Execute(SymbolTable *) const;
	virtual Value * GetLeftValue(SymbolTable *);
protected:
	Expr *m_a;
	Expr *m_b;
	Expr *m_c;
};


class ExprNew : public Expr
{
public:
	ExprNew(Src s, Var *a) : Expr(s) { m_a = a; }
	~ExprNew() { STDelete m_a; }
	virtual	Value Execute(SymbolTable *) const;
protected:
	Var *m_a;
};


class ExprDot : public Expr
{
public:
	ExprDot(Src s, Expr *a, Var *b) : Expr(s) { m_a = a; m_b = b; }
	~ExprDot() { STDelete m_a; STDelete m_b; }
	virtual	Value Execute(SymbolTable *) const;

	const Expr * GetLeftExpr() const { return m_a; }
	const Var  * GetField()    const { return m_b; }

	virtual int IsExprDot() const { return 1; }

	virtual Value * GetLeftValue(SymbolTable *);
protected:
	Expr *m_a;
	Var  *m_b;
};

#endif
