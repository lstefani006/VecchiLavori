#ifndef __ST_TVECT_H__
#define __ST_TVECT_H__

#include <st_dbnew.h>
#include <stdlib.h>

template <class T>
class STTVect
{
public:
	STTVect(int sz = 10);
	STTVect(const STTVect<T> &);
	~STTVect();
	void operator = (const STTVect<T> &);

	void Reset() { m_nTop = 0; }
	void Append(T a);
	void Append(const STTVect<T> &s);

	void Resize(int sz);
	int  Size() const { return m_nTop; }

	T& operator [] (int i);
	T  operator [] (int i) const;

protected:
	int m_nTop;
	int m_nMaxSize;
	T  *m_pT;
};

#ifndef __AIX
#include <st_tvect.c>
#endif

#endif
