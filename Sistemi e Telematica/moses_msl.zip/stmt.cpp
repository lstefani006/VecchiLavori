#include <st_dbnew.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "stmt.h" 
#include "symtb.h" 
#include "value.h" 
#include "p.h" 
#include "native.h"

struct exBreak : public Src
{
	exBreak(const Src &s)
	{
		File = s.File;
		Line = s.Line;
	}
};

struct exContinue : public Src
{
	exContinue(const Src &s)
	{
		File = s.File;
		Line = s.Line;
	}
};

struct exThrow : public Src
{
	exThrow(const Value &a, const Src &s)
		: m_v(a)
	{
		File = s.File;
		Line = s.Line;
	}
	Value m_v;
};

void RunTimeError(Src s, const char *Msg, ...)
{
	va_list ag;
	va_start(ag, Msg);

	static char b[1024];

	int n;
	n = sprintf(b, "Error in file %s line %d - ", s.File, s.Line);
	
	vsprintf(b + n, Msg, ag);

	throw SyntaxError(b);
}


void StmtNull::Execute(SymbolTable *) const
{
}


void StmtIf::Execute(SymbolTable *t) const
{
	Value e = m_pExpr->Execute(t);
	if (!e.IsBool())
		RunTimeError(m_pExpr->GetSrc(), "If statment requires a boolean value");

	if (e.True())
		m_pStmt1->Execute(t);
	else
		m_pStmt2->Execute(t);
}

int StmtCase::TestAndExecute(SymbolTable *t, const Value &r)
{
	if (m_pStmtCase != NULL && m_pStmtCase->TestAndExecute(t, r))
		return 1;

	Value e;
	if (m_pExpr)
	{
		e = m_pExpr->Execute(t);
		if (!e.IsString())
			RunTimeError(m_pExpr->GetSrc(), "Case statment requires a scalar value");
	}

	if (m_pExpr == NULL || (e == r).True())
	{
		m_pStmt->Execute(t);
		return 1;
	}
	else
		return 0;
}

void StmtSwitch::Execute(SymbolTable *t) const
{
	Value e = m_pExpr->Execute(t);

	if (!e.IsString())
		RunTimeError(m_pExpr->GetSrc(), "Switch statment requires scalar value");

	m_pStmt->TestAndExecute(t, e);
}

void StmtWhile::Execute(SymbolTable *t) const
{
	for (;;)
	{
		Value e = m_pExpr->Execute(t);

		if (!e.IsBool())
			RunTimeError(m_pExpr->GetSrc(), "While statment requires a boolean value");

		if (e.False())
			break;

		try
		{
			m_pStmt1->Execute(t);
		}
		catch (exBreak)
		{
			break;
		}
		catch (exContinue)
		{
		}
	}
}

void StmtTry::Execute(SymbolTable *t) const
{
	try
	{
		m_pTry->Execute(t);

		/*
		 * se arrivo qui non ci sono eccezioni
		 * devo ancora gestire la finally
		 */
		if (m_pExHandling)
			m_pExHandling->ExecuteFinally(t);
	}
	catch (exThrow ex)
	{
		/*
		 * esegue anche la finally
		 */
		int r = m_pExHandling->CatchAndExecute(t, ex.m_v);
		if (!r)
			throw;
	}
	catch (Value ex)  // per gestire la finally anche con il Return
	{
		m_pExHandling->ExecuteFinally(t);
		throw;
	}
}


void StmtContinue::Execute(SymbolTable *) const
{
	throw exContinue(GetSrc());
}

void StmtBreak::Execute(SymbolTable *) const
{
	throw exBreak(GetSrc());
}

void StmtCatch::Execute(SymbolTable *) const
{
	abort();
}

int StmtCatch::CatchAndExecute(SymbolTable *t, const Value &v) const
{
	int r = 0;

	if (m_pLeftExHandling) 
		r = m_pLeftExHandling->CatchAndExecute(t, v);

	if (r)
		return 1;   // eccezione gia` gestita da un blocco piu` annidato

	Value e;

	if (m_pExpr)
	{
		e = m_pExpr->Execute(t);
		if (!e.IsString())
			RunTimeError(m_pExpr->GetSrc(), "Catch statment require scalar values");

		if ((e == v).True())
			r = 1;
	}
	else
		r = 1;

	if (r)
		m_pStmt->Execute(t);

	return r;
}

void StmtCatch::ExecuteFinally(SymbolTable *t) const
{
	if (m_pLeftExHandling) 
		m_pLeftExHandling->ExecuteFinally(t);
}

void StmtFinally::Execute(SymbolTable *) const
{
	abort();
}

int StmtFinally::CatchAndExecute(SymbolTable *t, const Value &) const
{
	m_pStmt->Execute(t);

	return 0;  // comunque l'eccezione deve essere ancora gestita
}

void StmtFinally::ExecuteFinally(SymbolTable *t) const
{
	m_pStmt->Execute(t);
}


void StmtFor::Execute(SymbolTable *t) const
{
	Value *pV = m_v->GetLeftValue(t);
	if (pV == NULL)
		RunTimeError(m_a->GetSrc(), "For statment a left value");
	*pV = m_a->Execute(t);

	for (;;)
	{
		Value end(m_b->Execute(t));
		Value step(m_c->Execute(t));

		if (!(pV->IsNum() && end.IsNum() && step.IsNum()))
			RunTimeError(m_a->GetSrc(), "For statment require numeric values");

		if ((step > Value("0")).True())
		{
			if ((*pV > end).True())
				break;
		}
		else
		{
			if ((*pV < end).True())
				break;
		}

		try
		{
			m_s->Execute(t);
		}
		catch (exBreak)
		{
			break;
		}
		catch (exContinue)
		{
		}

		step = m_c->Execute(t);

		*pV = *pV + step;
	}
}



void StmtList::Execute(SymbolTable *t) const
{
	m_pStmt1->Execute(t);
	m_pStmt2->Execute(t);
}

void StmtReturn::Execute(SymbolTable *t) const
{
	if (m_pExpr)
		throw m_pExpr->Execute(t);
	else
		throw Value();
}

void StmtThrow::Execute(SymbolTable *t) const
{
	Value e = m_pExpr->Execute(t);

	if (!e.IsString())
		RunTimeError(GetSrc(), "Throw accept only scalar value");

	throw exThrow(e, GetSrc());
}

void StmtPrint::Execute(SymbolTable *t) const
{
	m_pExpr->Execute(t).Print(cout);
}

void StmtInput::Execute(SymbolTable *t) const
{
	char b[4096];

	if (!m_bLine)
		scanf("%s", b);
	else
	{
		// leggo un riga non vuota
		do
			gets(b);
		while (strlen(b) == 0);
	}

	Value *pV = m_pExpr->GetLeftValue(t);
	if (pV)
		*pV = Value(b);
	else
		RunTimeError(GetSrc(), "not a left value ");
}

void StmtAssign::Execute(SymbolTable *t) const
{
	Value *pV = m_pExprLeft->GetLeftValue(t);
	if (pV == NULL)
		RunTimeError(m_pExprLeft->GetSrc(), "Assign requires a left value");

	*pV = m_pExpr->Execute(t);
}

void StmtCall::Execute(SymbolTable *t) const
{
	const char *pFunName = NULL;
	if (m_a->IsExprVar())
		pFunName = ((ExprVar *)m_a)->GetVar();
	else
	if (m_a->IsExprDot())
	{
		ExprDot *pExprDot = (ExprDot *)m_a;
		pFunName = pExprDot->GetField()->GetSymbol();
	}
	else
		RunTimeError(GetSrc(), "syntax error");


	const char *pObjType = NULL;
	Value self;
	if (m_a->IsExprDot())
	{
		ExprDot *pExprDot = (ExprDot *)m_a;

		self = pExprDot->GetLeftExpr()->Execute(t);
		if (!self.IsObject())
			RunTimeError(GetSrc(), "calling a function \"%s\" without an object", pFunName);

		pObjType = self.IsObject()->Name();
	}

	Function *f = Program.SearchFunction(pFunName, pObjType);
	if (f == NULL)
	{
		if (pObjType == NULL)
			RunTimeError(GetSrc(), "call to undefined function \"%s\"", pFunName);
		else
			RunTimeError(GetSrc(), "call to undefined function \"%s.%s\"", pObjType, pFunName);
	}

	if (pObjType == NULL && m_b->Size() != f->GetNumParams() ||
			pObjType != NULL && m_b->Size() + 1 != f->GetNumParams())
		RunTimeError(GetSrc(),
				"wrong number of arguments in function call \"%s\"",
				f->Name());

	Value *v = STNew Value [f->GetNumParams()];
	{
		int i;
		for (i = 0; i < m_b->Size(); i++)
			v[i] = m_b->Get(i)->Execute(t);
		if (pObjType)
			v[i] = self;
	}

	f->Execute(f->GetNumParams(), v);

	// ricopio i parametri in uscita
	const VarList *pVarListOut = f->GetVarList();
	pVarListOut->GetNum();

	{
		for (int i = 0; i < pVarListOut->GetNum(); i++)
			if (pVarListOut->IsOut(i))
			{
				Value *pV = m_b->Get(i)->GetLeftValue(t);
				if (pV == NULL)
					RunTimeError(GetSrc(),
							"not a left value on %dth parameter in function call \"%s\"",
							i + 1,
							f->Name());

				*pV = v[i];
			}
	}

	STDelete [] v;
}

////////////////////////////////////////////////////////////////


Value Function::Execute(int nNumVal, Value *pValue)
{
	if (GetNumParams() != nNumVal)
		RunTimeError(GetSrc(),
				"wrong number of parameters in function call \"%s\"",
				Name());

	SymbolTable lSymbolTable;

	int i;
	const Var *pVar;
	for (i = 0; (pVar = m_pVarList_Args->Get(i)) != 0; i++)
	{
		lSymbolTable.Insert(GetSrc(), pVar->GetSymbol());
		lSymbolTable.Assign(GetSrc(), pVar->GetSymbol()) = pValue[i];
	}

	// variabili locali
	if (m_pVarList_Vars)
		for (i = 0; (pVar = m_pVarList_Vars->Get(i)) != 0; i++)
			lSymbolTable.Insert(GetSrc(), pVar->GetSymbol());

	int ret = 0;

	Value nn;

	try
	{
		if (m_pStmt)
			m_pStmt->Execute(&lSymbolTable);
		else
		{
			/*
			cerr << "\nEseguo la chiamata " << m_pVarName->GetSymbol() << endl;
			cerr << "Argomenti:\n";
			for (int j = 0; j < lSymbolTable.numOfVars(); j++)
			{
				cerr << "\t" ;
				lSymbolTable[j].Print(cerr);
				cerr << "\n";
				// LEO gestire la chiamata esterna
			}
			*/

			Native::Execute(m_pVarName->GetSymbol(), lSymbolTable);
		}
	}
	catch (Value r)
	{
		ret = 1;
		nn = r;
	}
	catch (exContinue ex)
	{
		RunTimeError(ex, "statment Continue must be inside a loop statment");
	}
	catch (exBreak ex)
	{
		RunTimeError(ex, "statment Break must be inside a loop statment");
	}

	if (m_bReturn == 1 && ret == 0)
		RunTimeError(GetSrc(), "function require RETURN statment");

	// ricopio i valori dalle variabili parametro all'array in ingresso
	for (i = 0; (pVar = m_pVarList_Args->Get(i)) != 0; i++)
		if (pVar->IsOut())
			pValue[i] = lSymbolTable.Search(GetSrc(), pVar->GetSymbol());

	return nn;
}

int Function::GetNumParams() const
{
	return m_pVarList_Args->GetNum();
}

const char * Function::Name() const 
{
	return m_pVarName->GetSymbol();
}

void Function::InObject(const Object *p)
{
	char b[1000];
	strcpy(b, p->Name());
	strcat(b, ".");
	strcat(b, m_pVarName->GetSymbol());
	STDelete m_pVarName;
	m_pVarName = STNew Var(b);

	m_pVarList_Args->Add(STNew Var("Self"));
}
