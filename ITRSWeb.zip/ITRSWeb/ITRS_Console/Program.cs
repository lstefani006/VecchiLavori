using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Remoting;
using System.Diagnostics;

using ITRS_BL;


namespace ITRS_Console
{
	class Program
	{
		static void PutEnv(string k, string v)
		{
			k = k.Replace('.', '_');
			Environment.SetEnvironmentVariable(k, v);
		}

		[MTAThread]
		static void Main(string[] a9rgs)
		{

			string args = U.F("{0} {1} {2}", "leo", "pppp", "A2");
			using (U.RunProcess rp = new U.RunProcess("$$\\ITRS_Import\\ITRS_Import.exe", args))
			{
				rp.Start();

				int exitCode;
				bool b = rp.WaitTimeout(1000 * 60 * 60, out exitCode);
				if (!(b && exitCode == 0))
					throw new Exception();
			}

			
			
			PutEnv("PuTTY.host", "172.31.11.31");
			PutEnv("PuTTY.login", "leo");
			PutEnv("PuTTY.pwd", "spectrum");

			//TestImportMassivo();


			ITRS_BL.ServerItems.StartServer();

			for (; ; )
			{
				Console.WriteLine("Server started: press 'Q' and return to exit");
				string r = Console.ReadLine();
				if (r == "Q")
					break;
			}

			ITRS_BL.ServerItems.StopServer();
		}

		private static void TestImportMassivo()
		{
			/*
			using (Stream s = new U.UnixStream(U.ZipSingleFileCreate("C:\\lts_a1.zip", "lts_a1.dat")))
			{
				using (ITRS_BL.Oracle.FileCastelloWriter fc = new ITRS_BL.Oracle.FileCastelloWriter(s))
				{
					for (int i = 0; i < 1000 * 11; ++i)
					{
						ITRS_BL.Oracle.RecordCastello r = new ITRS_BL.Oracle.RecordCastello();
						r.Targa = string.Format("A{0:0000000}", i);
						r.Nazionalita = "I";
						r.DataSegnalazione = DateTime.Now.Date;
						r.Scadenza = DateTime.Now.Date.AddDays(10);
						r.TipoVeicolo = "AUTOVETTURA";
						r.Note = "speriamo bene " + i.ToString();
						r.Operazione = "1";

						fc.Add(r);
					}
				}
			}

			bool onLinux = true;
			if (onLinux)
				U.PuTTYClient.Upload(null, "c:\\", "lts_a1.zip", "AllineamentoTargheCEPS", null);

			Console.WriteLine("Inizio import");
			Console.ReadLine();
			*/

			bool onLinux = false;
			ITRS_BL.BLLTSImport m = new BLLTSImport();
			// m.ImportMassivo("04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46", "c:\\20061220112717.txt", BLLTSImport.TipoLTS.A1, onLinux);
			// m.ImportMassivo("04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46", "c:\\22222.txt", BLLTSImport.TipoLTS.A2, onLinux);
			m.ImportMassivo("04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46",
				"d:\\Revisioni_scadute-20070114.txt", 
				BLLTSImport.TipoLTS.A2, onLinux);

			Console.WriteLine("Finito");
			Console.ReadLine();

			Environment.Exit(0);
		}
	}
}
