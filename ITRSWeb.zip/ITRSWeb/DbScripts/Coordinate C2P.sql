begin
update c2p set lat=40.69188, lon=14.83554 where idc2p=1 ;	-- Salerno Est	
update c2p set lat=40.69244, lon=14.83361 where idc2p=13;	-- Salerno Ovest	
update c2p set lat=40.62291, lon=15.18224 where idc2p=2 ;	-- Contursi Est	
update c2p set lat=40.62439, lon=15.18152 where idc2p=14;	-- Contursi Ovest	
update c2p set lat=40.39792, lon=15.58133 where idc2p=3 ;	-- Sala Consilina Est	
update c2p set lat=40.39884, lon=15.58002 where idc2p=15;	-- Sala Consilina Ovest	
update c2p set lat=40.01757, lon=15.89976 where idc2p=4 ;	-- Lauria Est	
update c2p set lat=40.01736, lon=15.89900 where idc2p=16;	-- Lauria Ovest	
update c2p set lat=39.84191, lon=16.24685 where idc2p=5 ;	-- Frascineto Est	
update c2p set lat=39.84248, lon=16.24457 where idc2p=17;	-- Frascineto Ovest	
update c2p set lat=39.57821, lon=16.24346 where idc2p=6 ;	-- Tarsia Est	
update c2p set lat=39.57962, lon=16.24319 where idc2p=18;	-- Tarsia Ovest	
update c2p set lat=39.34435, lon=16.23505 where idc2p=7 ;	-- Cosenza Est	
update c2p set lat=39.34602, lon=16.23437 where idc2p=19;	-- Cosenza Ovest	
update c2p set lat=39.18733, lon=16.30684 where idc2p=8 ;	-- Rogliano Est	
update c2p set lat=39.18954, lon=16.30740 where idc2p=20;	-- Rogliano Ovest	
update c2p set lat=38.92963, lon=16.23812 where idc2p=9	;	-- Lametia Est	
update c2p set lat=39.92993, lon=16.23518 where idc2p=21;	-- Lametia Ovest	
update c2p set lat=38.75035, lon=16.19221 where idc2p=22;	-- Pizzo Ovest	
update c2p set lat=38.43931, lon=15.94190 where idc2p=11;	-- Rosarno Est	
update c2p set lat=38.44060, lon=15.94324 where idc2p=23;	-- Rosarno Ovest	
update c2p set lat=38.22733, lon=15.64626 where idc2p=12;	-- Villa S.Giovanni Est	
update c2p set lat=38.22848, lon=15.64876 where idc2p=24;	-- Villa S.Giovanni Ovest	
update c2p set lat=41.29142, lon=15.94861 where idc2p=25;	-- Cerignola
update c2p set lat=40.89247, lon=16.87333 where idc2p=26;       -- villa pieve

end;

