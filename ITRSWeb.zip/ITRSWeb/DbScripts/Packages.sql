DROP PACKAGE ITRS_TRANSITI_EVENTI
GO
DROP PACKAGE ITRS_SORVEGLIANZA
GO
DROP PACKAGE ITRS_SMLOG
GO
DROP PACKAGE ITRS_QJ
GO
DROP PACKAGE ITRS_LTS_MWP
GO
DROP PACKAGE ITRS_INTERVENTO
GO
DROP PACKAGE ITRS_INDAGINI
GO

CREATE PACKAGE ITRS_INDAGINI IS

procedure QUERYINDAGINETRANSITI
(
	p_qjid        in varchar2,
	p_targa       in varchar2,
	p_nazionalita in varchar2,
	p_di          in date,
	p_df          in date,
        p_idc2p       in C2P.IDC2P%type,
	p_found       out int,
        p_MaxRec      out int
);

procedure QUERYINDAGINEEVENTI
(
	p_qjid        in varchar2,
	p_targa       in varchar2,
	p_nazionalita in varchar2,
	p_di          in date,
	p_df          in date,
        p_idc2p       in C2P.IDC2P%type,
        p_tipoEvento  in EVENTIDASEGNALARE.ENUMTIPOEVENTO%type,
	p_found       out int,
        p_MaxRec      out int
);

procedure CancellaIndagine
(
	p_qjid        in varchar2
);

end ITRS_INDAGINI;
GO
CREATE PACKAGE ITRS_INTERVENTO as

TYPE T_CURSOR IS REF CURSOR;

procedure CreateIntervento
(
  p_QJID        in  QJOBS.QJID%TYPE,
  p_QJTYPE      in  QJOBS.QJTYPE%TYPE,
  p_QJARGS      in  QJOBS.QJARGS%TYPE,
  p_QJPKIDUSER  in  QJOBS.QJPKIDUSER%TYPE,
  p_TARGA       in  TRANSITI.TARGA%TYPE,
  p_NAZIONALITA in  TRANSITI.NAZIONALITA%TYPE,
  p_MOTIVO      in  LTS.MOTIVO%TYPE,
  p_NOTE        in  LTS.NOTE%TYPE,
  p_IDCOA       in  COA.IDCOA%TYPE,

p_QJOBIDOLD   out QJOBS.QJID%TYPE
);

  procedure QueryIntervento
  (
  p_QJID        in  QJOBS.QJID%TYPE,
  p_TARGA       in  TRANSITI.TARGA%TYPE,
  p_NAZIONALITA in  TRANSITI.NAZIONALITA%TYPE,
  p_DI          in  DATE,
  p_DF          in  DATE,
  p_ROWS        out integer,
  p_PRIMO_TRANSITO in out VARCHAR2 -- true o false
  );

  procedure DeleteIntervento
  (
  p_QJID        in  QJOBS.QJID%TYPE,
  p_TARGA       out TRANSITI.TARGA%TYPE,
  p_NAZIONALITA out TRANSITI.NAZIONALITA%TYPE,
  p_QMGR        out T_CURSOR
  );


  procedure Test
  (
  p_QJID        in  QJOBS.QJID%TYPE,
  p_TARGA       in  TRANSITI.TARGA%TYPE,
  p_NAZIONALITA in  TRANSITI.NAZIONALITA%TYPE,
  p_DI          in  DATE,
  p_ROWS        out integer,
  p_STR         out TRANSITI.TARGA%TYPE
  );

  procedure OnAllarme
  (
  p_TARGA               in TRANSITI.TARGA%TYPE,
  p_NAZIONALITA         in TRANSITI.NAZIONALITA%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITI.DATAORARILEVAMENTO%TYPE,

  p_QMGR_NAME           in C2P.QMGR_NAME%TYPE,
  p_TIPOVARCO           in VARCHAR2
  );


  procedure ListaInterventiPerCoa
  (
		p_IdCoa       in  COA.IdCoa%type,
		p_Cur         out T_CURSOR
  );


  procedure CancellaInterventoPerCoa
  (
    p_IdCoa       in  COA.IdCoa%type,
    p_TARGA       in TRANSITI.TARGA%TYPE,
    p_NAZIONALITA in TRANSITI.NAZIONALITA%TYPE,
    p_QMGR        out T_CURSOR

  );

--  type InterventoRec is record
--  (
--    ProgressivoQuery          Number,
--    QJID                     	QJOBSRES_INTERVENTI.QJID%type,
--    TARGA                    	QJOBSRES_INTERVENTI.TARGA%type,
--    NAZIONALITA              	QJOBSRES_INTERVENTI.NAZIONALITA%type,
--    DATAORARILEVAMENTO       	QJOBSRES_INTERVENTI.DATAORARILEVAMENTO%type,
--    C2P_DESCRIZIONE          	QJOBSRES_INTERVENTI.C2P_DESCRIZIONE%type,
--    C2P_DIREZIONE            	QJOBSRES_INTERVENTI.C2P_DIREZIONE%type,
--    ENUMTIPOVARCO            	QJOBSRES_INTERVENTI.ENUMTIPOVARCO%type,
--    ENUMSTATOTRANSITO        	QJOBSRES_INTERVENTI.ENUMSTATOTRANSITO%type,
--    EVENTOASSOCIATOALTRANSITO	QJOBSRES_INTERVENTI.EVENTOASSOCIATOALTRANSITO%type
--  );
--  type InterventoCur is ref cursor InterventoRec%type;


end;

GO
CREATE PACKAGE ITRS_LTS_MWP AS

TYPE T_CURSOR IS REF CURSOR;


procedure GetListC2PFromTarga
(
p_Targa       in  TRANSITI.TARGA%type,
p_Nazionalita in  TRANSITI.TARGA%type,
p_Qmgr        out T_CURSOR
);


END;
GO
CREATE PACKAGE ITRS_QJ as

	-- stati QUEUE, RUN, SOSP, ERR, RRES, END, ABRQ, ABAK, CANC
	-- QUEUE job in coda
	-- RUN   job in esecuzione
	-- SOSP  job sospeso
	-- ERR   job terminato con eccezione
	-- RRES  job in run che ha prodotto risultati intermedi
	-- END   job terminato con successo
	-- ABRQ  job con richiesta di abort in corso
	-- ABAK  job che ha accettato la richiesta di abort
	-- CANC  job cancellato dall'utente dopo la sospensione

	-- crea un nuovo job in stato QUEUE
	procedure QJ_Create
	(
		p_QJID       in QJOBS.QJID%TYPE,
		p_QJTYPE     in QJOBS.QJTYPE%TYPE,
		p_QJARGS     in QJOBS.QJARGS%TYPE,
		p_QJPKIDUSER in QJOBS.QJPKIDUSER%TYPE
	);
	procedure QJ_CreateEx
	(
		p_QJID       in QJOBS.QJID%TYPE,
		p_QJTYPE     in QJOBS.QJTYPE%TYPE,
		p_QJARGS     in QJOBS.QJARGS%TYPE,
		p_QJPKIDUSER in QJOBS.QJPKIDUSER%TYPE,
                p_JobAccepted out int  -- 1 accettato, 0 non accettato
	);

	-- User : metto il job in stato ABRQ
	procedure QJ_Abort(p_QJID in QJOBS.QJID%TYPE);

	-- User : metto il job in stato SOSP (solo se sono in QUEUE)
	procedure QJ_Suspend(p_QJID in QJOBS.QJID%TYPE);

	-- User : metto il job in stato QUEUE (solo se sono in SOSP)
	procedure QJ_Resume(p_QJID in QJOBS.QJID%TYPE);

	-- Batch : cambia lo stato
	procedure QJ_ChangeStatus(p_QJID in QJOBS.QJID%TYPE, p_QJSTATUS in QJOBS.QJSTATUS%TYPE);

	-- Batch : memorizza lo stato attuale di esecuzione
	procedure QJ_Progress
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJSTATUS      in QJOBS.QJSTATUS%TYPE,
		p_QJPROGRMSG    in QJOBS.QJPROGRMSG%TYPE,
		p_QJTOTALSTEPS  in QJOBS.QJTOTALSTEPS%TYPE,
		p_QJCURRENTSTEP in QJOBS.QJCURRENTSTEP%TYPE,
		p_QJRESRECORDCOUNT in QJOBS.QJRESRECORDCOUNT%TYPE
	);

	-- Batch : da chiamare quando il batch va in eccezione
	procedure QJ_Error
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJERRMSG      in QJOBS.QJERRMSG%TYPE
	);


	-- Batch : da chiamare quando il batch termina
	procedure QJ_End
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJPROGRMSG    in QJOBS.QJPROGRMSG%TYPE,
		p_QJRESULT      in QJOBS.QJRESULT%TYPE
	);

	-- User : da chiamare quando l'utente interroga il risultato.
	-- In questo modo si prolunga la vita del result del job.
	procedure QJ_Access
	(
		p_QJID          in QJOBS.QJID%TYPE
	);

	-- User : mette in stato CANC i job vecchi
	procedure QJ_Purge;

        -- User: mette in CANC i joob che soddisfano le caratteristiche in
        -- ingresso.
	procedure QJ_Canc
        (
                p_QJID       QJOBS.QJID%type,
                p_QJTYPE     QJOBS.QJTYPE%type,
                p_QJPKIDUSER QJOBS.QJPKIDUSER%type,
                p_QJSTATUS   QJOBS.QJSTATUS%type
        );


	-- Batch: ottiene il prossivo job da eseguire, se esiste.
	procedure QJ_GetNextToRun
	(
		p_QJID       out QJOBS.QJID%TYPE,
		p_QJARGS     out QJOBS.QJARGS%TYPE,
		p_QJTYPE     out QJOBS.QJTYPE%TYPE
	);

end;
GO
CREATE PACKAGE ITRS_SMLOG AS

procedure AddMessage
(
  p_Application smlog.smapplication%type,
  p_Type smlog.smtype%type,
  p_Message smlog.smmessage%type,
  p_Exception smlog.smexception%type
);

END;
GO
CREATE PACKAGE ITRS_SORVEGLIANZA AS

procedure AccodaEvento
(
  p_TARGA               in EVENTIDASEGNALARE.TARGA%TYPE,
  p_NAZIONALITA         in EVENTIDASEGNALARE.NAZIONALITA%TYPE,
  p_DATAORAINSERIMENTO  in EVENTIDASEGNALARE.DATAORAINSERIMENTO%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITISUEVENTO.DATAORARILEVAMENTO%TYPE,
  p_IDEVENTO            in EVENTIDASEGNALARE.IDEVENTO%TYPE,
  p_IDCOA               in EVENTIDASEGNALARE.IDCOACOMPETENZA%type,
  p_Img                 in ImmaginiSuEvento.IMMAGINE%type
);


TYPE T_CURSOR IS REF CURSOR;

procedure GetListaEventi
(
  p_IDCOA               in  EVENTIDASEGNALARE.IDCOACOMPETENZA%type,
  p_Cur                 out T_CURSOR
);

procedure GetDatiSorveglianza
(
  p_TARGA               in EVENTIDASEGNALARE.TARGA%TYPE,
  p_NAZIONALITA         in EVENTIDASEGNALARE.NAZIONALITA%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITISUEVENTO.DATAORARILEVAMENTO%TYPE,
  p_Cur                 out T_CURSOR
);

END;
GO
CREATE PACKAGE ITRS_TRANSITI_EVENTI AS

procedure TransitoPrendiInCarico
(
  p_Targa                 in Transiti.Targa%type,
  p_Nazionalita           in Transiti.NAZIONALITA%type,
  p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,
  p_IdUtentePresaInCarico in Transiti.IDUTENTEPRESAINCARICO%type,
  p_Updated               out integer
);

procedure TransitoAzioneSuPresaInCarico
(
  p_Targa                 in Transiti.Targa%type,
  p_Nazionalita           in Transiti.NAZIONALITA%type,
  p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,

  p_StatoTransito         in Transiti.ENUMSTATOTRANSITO%type,
  p_NoteChiusura          in Transiti.NOTECHIUSURA%type,
  p_Updated               out integer
);

--------------------------------------------------------------------

procedure EventoPrendiInCarico
(
  p_Targa                 in EventiDaSegnalare.Targa%type,
  p_Nazionalita           in EventiDaSegnalare.NAZIONALITA%type,
  p_DataOraInserimento    in EventiDaSegnalare.DATAORAINSERIMENTO%type,
  p_IdEvento              in EventiDaSegnalare.IDEVENTO%type,
  p_IdUtentePresaInCarico in EventiDaSegnalare.IDUTENTEPRESAINCARICO%type,
  p_Updated               out integer
);

procedure EventoAzioneSuPresaInCarico
(
  p_Targa                 in EventiDaSegnalare.Targa%type,
  p_Nazionalita           in EventiDaSegnalare.NAZIONALITA%type,
  p_DataOraInserimento    in EventiDaSegnalare.DATAORAINSERIMENTO%type,
  p_IdEvento              in EventiDaSegnalare.IDEVENTO%type,

  p_StatoAllarme          in EventiDaSegnalare.ENUMSTATOALLARME%type,
  p_NoteChiusura          in EventiDaSegnalare.NOTECHIUSURA%type,
  p_Updated               out integer
);


END;

GO


