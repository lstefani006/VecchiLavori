ALTER TABLE "ITRS"."LTS" ADD 
(
tab_telaio         VARCHAR2(21) NULL, 
tab_data_furto     VARCHAR2(11) NULL, 
tab_fabbrica       VARCHAR2(25) NULL, 
tab_modello        VARCHAR2(20) NULL, 
tab_tipo_veicolo   VARCHAR2(25) NULL, 
tab_tipo_denuncia  VARCHAR2(16) NULL, 
tab_codice_ufficio VARCHAR2(7)  NULL, 
tab_ufficio        VARCHAR2(40) NULL 
); 



ALTER TABLE ITRS.TRANSITI MODIFY (TARGAACQUISITA VARCHAR2(32)) ;


ALTER TABLE INDAGINI_TRANSITI ADD ("TARGAACQUISITA" VARCHAR2(32)) ;
ALTER TABLE INDAGINI_TRANSITI ADD ("NAZIONALITAACQUISITA" VARCHAR2(6)) ;


CREATE TABLE ITRS.NAZIONI ( 
  SIGLA_NAZIONE VARCHAR2(4) NOT NULL , 
  NOME_NAZIONE VARCHAR2(30) NOT NULL ) 
;



insert into nazioni values('A','Austria');
insert into nazioni values('AL','Albania');
insert into nazioni values('B','Belgio');
insert into nazioni values('BG','Bulgaria');
insert into nazioni values('CH','Svizzera');
insert into nazioni values('CZ','Repubblica Ceca');
insert into nazioni values('D','Germania');
insert into nazioni values('DK','Danimarca');
insert into nazioni values('E','Spagna');
insert into nazioni values('F','Francia');
insert into nazioni values('FIN','Finlandia');
insert into nazioni values('GB','GranBretagna');
insert into nazioni values('GR','Grecia');
insert into nazioni values('H','Ungheria');
insert into nazioni values('HR','Croazia');
insert into nazioni values('I','Italia');
insert into nazioni values('IRL','Irlanda');
insert into nazioni values('L','Lussemburgo');
insert into nazioni values('MC','Monaco');
insert into nazioni values('N','Norvegia');
insert into nazioni values('NL','Olanda');
insert into nazioni values('P','Portogallo');
insert into nazioni values('PL','Polonia');
insert into nazioni values('RO','Romania');
insert into nazioni values('RSM','San Marino');
insert into nazioni values('S','Svezia');
insert into nazioni values('SK','Slovacchia');
insert into nazioni values('SLO','Slovenia');
insert into nazioni values('TR','Turchia');
insert into nazioni values('YU','Yugoslavia');




ALTER TABLE USERLOG
	DROP CONSTRAINT SYS_C009264
GO
DROP TABLE USERLOG
GO

CREATE TABLE USERLOG ( 
	ID              	NUMBER(22,0) NOT NULL,
	TSATTIVITA      	DATE NOT NULL,
	TIPOATTIVITA    	VARCHAR2(25) NOT NULL,
	DESCATTIVITA    	VARCHAR2(4000) NOT NULL,
	IDUTENTEATTIVITA	VARCHAR2(36) NULL 
	)
GO

ALTER TABLE USERLOG
	ADD ( CONSTRAINT SYS_C009264
	PRIMARY KEY (ID)
	NOT DEFERRABLE INITIALLY IMMEDIATE )
GO



update c2p set lat=40.69188, lon=14.83554 where idc2p=1
go
update c2p set lat=40.69244, lon=14.83361 where idc2p=13
go
update c2p set lat=40.62291, lon=15.18224 where idc2p=2
go
update c2p set lat=40.62439, lon=15.18152 where idc2p=14
go
update c2p set lat=40.39792, lon=15.58133 where idc2p=3 
go
update c2p set lat=40.39884, lon=15.58002 where idc2p=15
go
update c2p set lat=40.01757, lon=15.89976 where idc2p=4 
go
update c2p set lat=40.01736, lon=15.89900 where idc2p=16
go
update c2p set lat=39.84191, lon=16.24685 where idc2p=5 
go
update c2p set lat=39.84248, lon=16.24457 where idc2p=17
go
update c2p set lat=39.57821, lon=16.24346 where idc2p=6 
go
update c2p set lat=39.57962, lon=16.24319 where idc2p=18
go
update c2p set lat=39.34435, lon=16.23505 where idc2p=7 
go
update c2p set lat=39.34602, lon=16.23437 where idc2p=19
go
update c2p set lat=39.18733, lon=16.30684 where idc2p=8 
go
update c2p set lat=39.18954, lon=16.30740 where idc2p=20
go
update c2p set lat=38.92963, lon=16.23812 where idc2p=9	
go
update c2p set lat=39.92993, lon=16.23518 where idc2p=21
go
update c2p set lat=38.75035, lon=16.19221 where idc2p=22
go
update c2p set lat=38.43931, lon=15.94190 where idc2p=11
go
update c2p set lat=38.44060, lon=15.94324 where idc2p=23
go
update c2p set lat=38.22733, lon=15.64626 where idc2p=12
go
update c2p set lat=38.22848, lon=15.64876 where idc2p=24
go
update c2p set lat=41.29142, lon=15.94861 where idc2p=25
go
update c2p set lat=40.89247, lon=16.87333 where idc2p=26
go


INSERT INTO ITRS.ASPNET_ROLES(APPLICATIONNAME, ROLENAME) VALUES ( 'ITRS_WEB', 'Import/Export LTS C' )
go
INSERT INTO ITRS.ASPNET_ROLES(APPLICATIONNAME, ROLENAME) VALUES ( 'ITRS_WEB', 'Amministrazione LTS' )
go

INSERT INTO ITRS.ASPNET_USERSINROLES(USERNAME, ROLENAME, APPLICATIONNAME) VALUES ('Admin', 'Import/Export LTS C', 'ITRS_WEB')
go
INSERT INTO ITRS.ASPNET_USERSINROLES(USERNAME, ROLENAME, APPLICATIONNAME) VALUES ('Admin', 'Amministrazione LTS', 'ITRS_WEB')
go
