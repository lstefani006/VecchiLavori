delete from Segnalazioni
where
IDEVENTO
in 
(
    select 
    IDEVENTO 
    from EVENTIDASEGNALARE 
    where ENUMTIPOEVENTO = 'VMS'
)

delete from EVENTIDASEGNALARE 
where ENUMTIPOEVENTO = 'VMS'

delete from TransitiEventi
where
idEvento
not in 
(
	select IdEvento
	from EVENTIDASEGNALARE 
)

delete from ImmaginiSuEvento
where exists
(
	select 
	T.*
	from
	ImmaginiSuEvento T
	left outer join TransitiEventi TE
	on  TE.Targa              = T.Targa
	and TE.Nazionalita        = T.Nazionalita
	and TE.DataOraRilevamento = T.DataOraRilevamento
	where TE.Targa is null
)

delete from TransitiSuEvento
where exists
(
	select 
	T.*
	from
	TransitiSuEvento T
	left outer join TransitiEventi TE
	on  TE.Targa              = T.Targa
	and TE.Nazionalita        = T.Nazionalita
	and TE.DataOraRilevamento = T.DataOraRilevamento
	where TE.Targa is null
)


