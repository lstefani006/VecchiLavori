DROP PACKAGE BODY ITRS_INDAGINI
GO
DROP PACKAGE BODY ITRS_QJ
GO
DROP PACKAGE BODY ITRS_LTS_MWP
GO
DROP PACKAGE BODY ITRS_TRANSITI_EVENTI
GO
DROP PACKAGE BODY ITRS_SORVEGLIANZA
GO
DROP PACKAGE BODY ITRS_SMLOG
GO
DROP PACKAGE BODY ITRS_INTERVENTO
GO

CREATE PACKAGE BODY ITRS_INTERVENTO as

-- ritorna in p_QJOBIDOLD
-- il guid del nuovo job
-- oppure il guid di un job esistente
-- oppure '' se non e` stato possibile lanciare il job
procedure CreateIntervento
(
p_QJID        in QJOBS.QJID%TYPE,
p_QJTYPE      in QJOBS.QJTYPE%TYPE,
p_QJARGS      in QJOBS.QJARGS%TYPE,
p_QJPKIDUSER  in QJOBS.QJPKIDUSER%TYPE,
p_TARGA       in TRANSITI.TARGA%TYPE,
p_NAZIONALITA in TRANSITI.NAZIONALITA%TYPE,
p_MOTIVO      in LTS.MOTIVO%TYPE,
p_NOTE        in LTS.NOTE%TYPE,
p_IDCOA       in COA.IDCOA%TYPE,

p_QJOBIDOLD   out QJOBS.QJID%TYPE
)
is
P_IDLTS LTS.IDLTS%type;
p_JobAccepted int;

begin

    -- controllo se esiste gia` una entry per l'utente/targa/nazionalita
    BEGIN
      SELECT idlts INTO P_IDLTS FROM lts
      WHERE
      TARGA = p_TARGA and
      NAZIONALITA = p_NAZIONALITA and
      AddrDest = p_IDCOA and
      EnumTipoLts = 'C' and
      EnumTipoDest = 'COA';

    exception
      WHEN no_data_found THEN
        -- non esiste --> lo inserisco
        INSERT INTO ITRS.LTS
        (TARGA,   NAZIONALITA,   IDLTS,           ENUMTIPOLTS, IDUTENTERICHIEDENTE, MOTIVO,   NOTE,   DATAORAINSERIMENTO, DATAORAINIZIOVALIDITA, DATAORAFINEVALIDITA, ENUMTIPODEST, ADDRDEST, ENUMLIVELLOPRIORITA)
        VALUES
        (p_TARGA, p_NAZIONALITA, SEQ_LTS.nextval, 'C',         p_QJPKIDUSER,        p_MOTIVO, p_NOTE, SYSDATE,            SYSDATE,               SYSDATE + (356*30),             'COA',        p_IDCOA,  'MAX');
    END;


    begin
      -- Cerco un intervento con la stessa targa/nazionalita` in stato QUEUE, RUN, RRES, END
      -- se lo trovo e` inutile lanciare un nuovo job --> ritorno il QJID del job appena trovato
      select
      QJOBS.QJID into p_QJOBIDOLD
      from QJOBS_INTERVENTI
      inner join QJOBS
      on QJOBS.QJID = QJOBS_INTERVENTI.QJID
      where
      QJOBS_INTERVENTI.TARGA = p_TARGA and
      QJOBS_INTERVENTI.NAZIONALITA = p_NAZIONALITA and
      QJOBS.QJSTATUS in ('QUEUE', 'RUN', 'RRES', 'END');

    exception
      when no_data_found then

    	ITRS.ITRS_QJ.QJ_CreateEx(P_QJID, P_QJTYPE, P_QJARGS, p_QJPKIDUSER, p_JobAccepted);
        if (p_JobAccepted = 0) then
          p_QJOBIDOLD := '';
          return;
        end if;

        INSERT INTO ITRS.QJOBS_INTERVENTI
        (
          QJID, TARGA, NAZIONALITA,
          UT_DATAORARILEVAMENTO, UT_C2P_DESCRIZIONE, UT_C2P_DIREZIONE,
          UT_ENUMTIPOVARCO, UT_ENUMSTATOTRANSITO, UT_EVENTOASSOCIATOALTRANSITO,
          UT_IDEVENTO, UT_DATAORAINSERIMENTO, UT_ENUMSTATOALLARME
        )
        VALUES
        (
          P_QJID, P_TARGA, P_NAZIONALITA,
          NULL, NULL, NULL,
          NULL, NULL, NULL,
          null, null, null
        );

        p_QJOBIDOLD := P_QJID;
    end;
end;

procedure QueryIntervento
(
	p_QJID           in     QJOBS.QJID%TYPE,
	p_TARGA          in     TRANSITI.TARGA%TYPE,
	p_NAZIONALITA    in     TRANSITI.NAZIONALITA%TYPE,
	p_DI             in     date,
	p_DF             in     date,
	p_ROWS           out    integer,
	p_PRIMO_TRANSITO in out varchar2
)
is
begin
        -- ricerco e metto il risultato nella tabella QJOBSRES_INTERVENTI
        -- i transiti per la targa/di/df nella tabella TRANSITI.
        -- Memorizzo inoltre i dati realtivi all'evento associato al transito
        -- (se esiste) qualora questo sia un evento di tipo LTS

	insert into ITRS.QJOBSRES_INTERVENTI
	(
	QJID,
	TARGA,
	NAZIONALITA,
	DATAORARILEVAMENTO,
	C2P_DESCRIZIONE,
	C2P_DIREZIONE,
	ENUMTIPOVARCO,
	ENUMSTATOTRANSITO,
	EVENTOASSOCIATOALTRANSITO,

        -- dati dell'eventuale allarme per LTS
        IDEVENTO,
        DATAORAINSERIMENTO,
        ENUMSTATOALLARME
	)
	select
	p_QJID                                 QJID,
	TRANSITI.TARGA                         TARGA,
	TRANSITI.NAZIONALITA                   NAZIONALITA,
	TRANSITI.DATAORARILEVAMENTO            DATAORARILEVAMENTO,
	C2P.DESCRIZIONE                        C2P_DESCRIZIONE,
	C2P.DIREZIONE                          C2P_DIREZIONE,
	TRANSITI.ENUMTIPOVARCO                 ENUMTIPOVARCO,
	TRANSITI.ENUMSTATOTRANSITO             ENUMSTATOTRANSITO, -- DARIC RIC NORIC PIC (preso in carico)
	nvl2(TRANSITISUEVENTO.TARGA, 'S', 'N') EVENTOASSOCIATOALTRANSITO,
        EVENTIDASEGNALARE.IDEVENTO             IDEVENTO,
        EVENTIDASEGNALARE.DATAORAINSERIMENTO   DATAORAINSERIMENTO,
        EVENTIDASEGNALARE.ENUMSTATOALLARME     ENUMSTATOALLARME

	from
        (
          -- prendo i transiti e il transiti segnalati
          select
          TARGA,
          NAZIONALITA,
          DATAORARILEVAMENTO,
          ENUMTIPOVARCO,
          ENUMSTATOTRANSITO,
          IDC2P
          from Transiti TA
          where
              TA.DATAORARILEVAMENTO >= p_DI
          and TA.DATAORARILEVAMENTO < p_DF
          and TA.Targa = p_TARGA
          and TA.Nazionalita = p_NAZIONALITA

          union

          select
          TARGA,
          NAZIONALITA,
          DATAORARILEVAMENTO,
          ENUMTIPOVARCO,
          ENUMSTATOTRANSITO,
          IDC2P
          from
          transitiSuEvento TB
          where
              TB.DATAORARILEVAMENTO >= p_DI
          and TB.DATAORARILEVAMENTO < p_DF
          and TB.Targa = p_TARGA
          and TB.Nazionalita = p_NAZIONALITA
        ) TRANSITI

	inner join C2P
	on C2P.IDC2P = TRANSITI.IDC2P

        -- controllo se nella tabella gemella a Transiti esiste lo stesso
        -- record.
	left outer join TRANSITISUEVENTO
	on  TRANSITI.TARGA              = TRANSITISUEVENTO.TARGA
	and TRANSITI.NAZIONALITA        = TRANSITISUEVENTO.NAZIONALITA
	and TRANSITI.DATAORARILEVAMENTO = TRANSITISUEVENTO.DATAORARILEVAMENTO

        left outer join TRANSITIEVENTI
        on  TRANSITIEVENTI.TARGA = TRANSITI.TARGA
        and TRANSITIEVENTI.NAZIONALITA = TRANSITI.NAZIONALITA
        and TRANSITIEVENTI.DATAORARILEVAMENTO = TRANSITI.DATAORARILEVAMENTO

        left outer join EVENTIDASEGNALARE
        on  EVENTIDASEGNALARE.TARGA = TRANSITIEVENTI.TARGA
        and EVENTIDASEGNALARE.NAZIONALITA = TRANSITIEVENTI.NAZIONALITA
        and EVENTIDASEGNALARE.DATAORAINSERIMENTO = TRANSITIEVENTI.DATAORAINSERIMENTO
        and EVENTIDASEGNALARE.IDEVENTO = TRANSITIEVENTI.IDEVENTO

	where
        EVENTIDASEGNALARE.ENUMTIPOEVENTO = 'TS'; -- transito segnalato
        /*
	select
	p_QJID                                 QJID,
	TRANSITI.TARGA                         TARGA,
	TRANSITI.NAZIONALITA                   NAZIONALITA,
	TRANSITI.DATAORARILEVAMENTO            DATAORARILEVAMENTO,
	C2P.DESCRIZIONE                        C2P_DESCRIZIONE,
	C2P.DIREZIONE                          C2P_DIREZIONE,
	TRANSITI.ENUMTIPOVARCO                 ENUMTIPOVARCO,
	TRANSITI.ENUMSTATOTRANSITO             ENUMSTATOTRANSITO, -- DARIC RIC NORIC PIC (preso in carico)
	nvl2(TRANSITISUEVENTO.TARGA, 'S', 'N') EVENTOASSOCIATOALTRANSITO,
        EVENTIDASEGNALARE.IDEVENTO             IDEVENTO,
        EVENTIDASEGNALARE.DATAORAINSERIMENTO   DATAORAINSERIMENTO,
        EVENTIDASEGNALARE.ENUMSTATOALLARME     ENUMSTATOALLARME

	from TRANSITI

	inner join C2P
	on C2P.IDC2P = TRANSITI.IDC2P

        -- controllo se nella tabella gemella a Transiti esiste lo stesso
        -- record.
	left outer join TRANSITISUEVENTO
	on  TRANSITI.TARGA              = TRANSITISUEVENTO.TARGA
	and TRANSITI.NAZIONALITA        = TRANSITISUEVENTO.NAZIONALITA
	and TRANSITI.DATAORARILEVAMENTO = TRANSITISUEVENTO.DATAORARILEVAMENTO

        left outer join TRANSITIEVENTI
        on  TRANSITIEVENTI.TARGA = TRANSITI.TARGA
        and TRANSITIEVENTI.NAZIONALITA = TRANSITI.NAZIONALITA
        and TRANSITIEVENTI.DATAORARILEVAMENTO = TRANSITI.DATAORARILEVAMENTO

        left outer join EVENTIDASEGNALARE
        on  EVENTIDASEGNALARE.TARGA = TRANSITIEVENTI.TARGA
        and EVENTIDASEGNALARE.NAZIONALITA = TRANSITIEVENTI.NAZIONALITA
        and EVENTIDASEGNALARE.DATAORAINSERIMENTO = TRANSITIEVENTI.DATAORAINSERIMENTO
        and EVENTIDASEGNALARE.IDEVENTO = TRANSITIEVENTI.IDEVENTO

	where
	TRANSITI.DATAORARILEVAMENTO >= p_DI
	and TRANSITI.DATAORARILEVAMENTO < p_DF
	and TRANSITI.Targa = p_TARGA
	and TRANSITI.Nazionalita = p_NAZIONALITA
        and EVENTIDASEGNALARE.ENUMTIPOEVENTO = 'TS'; -- transito segnalato
        */

	p_ROWS := sql%rowcount;

	-- Sto facendo la ricerca del transito per una targa.
	-- Nella tabella QJOBS_INTERVENTI e` memorizzato il transito piu` recente,
	-- o l'ultimo transito ottenuto quando il campo chiama OnAllarme.
	-- Se esiste gia` l'ultimo transito nella QJOBS_INTERVENTI
	-- (sia per allarmi o perche` ne avevo trovato uno in precedenza)
	-- non memorizzo niente.
	-- Per evitare di fare troppe query, il parametro p_PRIMO_TRANSITO indica se e` gia` stato
	-- memorizzato il primo transito per questa targa.
	if (p_ROWS > 0 and p_PRIMO_TRANSITO = 'false') then
	  declare
			p_DATE date;
		begin
			-- qui rifaccio la query xche` potrebbe, nel frattempo, essere arrivato OnAllarme
			-- e poi per lockare il record per evitare problemi di concorrenza
			select
			UT_DATAORARILEVAMENTO into p_DATE
			from QJOBS_INTERVENTI
			where
			TARGA = p_TARGA and
			NAZIONALITA = p_NAZIONALITA and
			QJID = p_QJID and
			not (UT_DATAORARILEVAMENTO is null)
			for update;

			p_PRIMO_TRANSITO := 'true';

		exception when no_data_found then
			p_PRIMO_TRANSITO := 'false';
		end;

		if (p_PRIMO_TRANSITO = 'false') then
			-- non e` stato ancora rilevato il primo transito, ma, nell'ultima query
			-- ne ho trovato almeno uno.
			declare
				p_DATAORARILEVAMENTO        ITRS.QJOBSRES_INTERVENTI.DATAORARILEVAMENTO%type;
				p_C2P_DESCRIZIONE           ITRS.QJOBSRES_INTERVENTI.C2P_DESCRIZIONE%type;
				p_C2P_DIREZIONE             ITRS.QJOBSRES_INTERVENTI.C2P_DIREZIONE%type;
				p_ENUMTIPOVARCO             ITRS.QJOBSRES_INTERVENTI.ENUMTIPOVARCO%type;
				p_ENUMSTATOTRANSITO         ITRS.QJOBSRES_INTERVENTI.ENUMSTATOTRANSITO%type;
				p_EVENTOASSOCIATOALTRANSITO ITRS.QJOBSRES_INTERVENTI.EVENTOASSOCIATOALTRANSITO%type;

                                p_UT_IDEVENTO               ITRS.QJOBSRES_INTERVENTI.IDEVENTO%type;
                                p_UT_DATAORAINSERIMENTO     ITRS.QJOBSRES_INTERVENTI.DATAORAINSERIMENTO%type;
                                p_UT_ENUMSTATOALLARME       ITRS.QJOBSRES_INTERVENTI.ENUMSTATOALLARME%type;

			begin
				-- cerco il transito piu` recente con rownum <= 1
				select
				DATAORARILEVAMENTO,
				C2P_DESCRIZIONE,
				C2P_DIREZIONE,
				ENUMTIPOVARCO,
				ENUMSTATOTRANSITO,
				EVENTOASSOCIATOALTRANSITO,

                                IDEVENTO,
                                DATAORAINSERIMENTO,
                                ENUMSTATOALLARME

				into
				p_DATAORARILEVAMENTO,
				p_C2P_DESCRIZIONE,
				p_C2P_DIREZIONE,
				p_ENUMTIPOVARCO,
				p_ENUMSTATOTRANSITO,
				p_EVENTOASSOCIATOALTRANSITO,

                                p_UT_IDEVENTO,
                                p_UT_DATAORAINSERIMENTO,
                                p_UT_ENUMSTATOALLARME

				from ITRS.QJOBSRES_INTERVENTI
				where
				QJID = p_QJID and
				TARGA = p_TARGA and
				NAZIONALITA = p_NAZIONALITA and
				rownum <= 1
				order by DATAORARILEVAMENTO desc;

				-- aggiorno QJOBS_INTERVENTI con i dati del transito piu` recente
				update ITRS.QJOBS_INTERVENTI
				set
				UT_DATAORARILEVAMENTO        = p_DATAORARILEVAMENTO,
				UT_C2P_DESCRIZIONE           = p_C2P_DESCRIZIONE,
				UT_C2P_DIREZIONE             = p_C2P_DIREZIONE,
				UT_ENUMTIPOVARCO             = p_ENUMTIPOVARCO,
				UT_ENUMSTATOTRANSITO         = p_ENUMSTATOTRANSITO,
				UT_EVENTOASSOCIATOALTRANSITO = p_EVENTOASSOCIATOALTRANSITO,

                                UT_IDEVENTO                  = p_UT_IDEVENTO,
                                UT_DATAORAINSERIMENTO        = p_UT_DATAORAINSERIMENTO,
                                UT_ENUMSTATOALLARME          = p_UT_ENUMSTATOALLARME

				where
				TARGA = p_TARGA and
				NAZIONALITA = p_NAZIONALITA and
				QJID = p_QJID;

				p_PRIMO_TRANSITO := 'true';
			end;
		end if;
	end if;

	-- qui scrivo nel DB e rilascio il lock for update
	commit;
end;


  procedure DeleteIntervento
  (
  p_QJID        in  QJOBS.QJID%TYPE ,
  p_TARGA       out TRANSITI.TARGA%TYPE,
  p_NAZIONALITA out TRANSITI.NAZIONALITA%TYPE,
  p_QMGR        out T_CURSOR
  )
  is
  begin
    -- trovo il targa/nazionalita associata all'intervento
    select Targa, Nazionalita
    into p_Targa, p_Nazionalita
    from QJOBS_INTERVENTI
    where QJID = p_QJID;

    -- cancello TUTTE le entry che si riferiscono a questa targa in LTS
    delete from LTS
    where
    Targa = p_Targa and
    Nazionalita = p_Nazionalita and
    EnumTipoLts = 'C' and
    EnumTipoDest = 'COA';

    -- cancello tutte la roba associata a QJID
    delete from ITRS.QJOBSRES_INTERVENTI where QJID = p_QJID;
    delete from ITRS.QJOBS_INTERVENTI where QJID = p_QJID;
    delete from ITRS.QJOBS where  QJID = p_QJID;

    -- chiamo la sp per sapere quali C2P sono da aggiornare
    -- nel caso che la targa/nazionalita` non sia piu` nella
    -- tabella LTS
    ITRS_LTS_MWP.GetListC2PFromTarga(p_Targa, p_Nazionalita, p_QMGR);

  exception
    when others then
      rollback;
      raise;
  end;


  procedure Test
  (
  p_QJID        in  QJOBS.QJID%TYPE,
  p_TARGA       in  TRANSITI.TARGA%TYPE,
  p_NAZIONALITA in  TRANSITI.NAZIONALITA%TYPE,
  p_DI          in  DATE,
  p_ROWS        out integer,
  p_STR         out TRANSITI.TARGA%TYPE
  )
  is
  P_VAR VARCHAR2(100);
  begin

  p_ROWS:=10000000000;
  p_STR := 'cicci';

  select QJSTATUS into P_VAR from QJOBS where QJID = p_QJID;

  end;


procedure OnAllarme
(
  p_TARGA               in TRANSITI.TARGA%TYPE,
  p_NAZIONALITA         in TRANSITI.NAZIONALITA%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITI.DATAORARILEVAMENTO%TYPE,

  p_QMGR_NAME           in C2P.QMGR_NAME%TYPE,
  p_TIPOVARCO           in VARCHAR2
)
is
	p_C2P_DESCRIZIONE     C2P.DESCRIZIONE%type;
	p_C2P_DIREZIONE       C2P.DIREZIONE%type;
	p_ENUMSTATOTRANSITO   TRANSITI.ENUMSTATOTRANSITO%type;
	p_ENUMTIPOVARCO       TRANSITI.ENUMTIPOVARCO%type;

        p_IDEVENTO            NUMBER(10,0) null;
        p_DATAORAINSERIMENTO  DATE null;
        p_ENUMSTATOALLARME    varchar2(5) null;
begin

	-- traduco il tipo varco: se non esiste la voce si genera una case_not_found exception
	case LTRIM(p_TIPOVARCO, '0')
	when ITRS_CONST_PKG.VAL_TIPOVARCO_1 then p_ENUMTIPOVARCO := ITRS_CONST_PKG.VAL_TIPOVARCO_USCITA;
	when ITRS_CONST_PKG.VAL_TIPOVARCO_2 then p_ENUMTIPOVARCO := ITRS_CONST_PKG.VAL_TIPOVARCO_INGRESSO;
	when ITRS_CONST_PKG.VAL_TIPOVARCO_3 then p_ENUMTIPOVARCO := ITRS_CONST_PKG.VAL_TIPOVARCO_SX;
	when ITRS_CONST_PKG.VAL_TIPOVARCO_4 then p_ENUMTIPOVARCO := ITRS_CONST_PKG.VAL_TIPOVARCO_DX;
	end case;

	select
	DESCRIZIONE, DIREZIONE
	into
	p_C2P_DESCRIZIONE, p_C2P_DIREZIONE
	from C2P
	where
	QMGR_NAME = p_QMGR_NAME;

        -- trovo se esiste l'allarme associato di tipo LTS
        begin
          select
          EVENTIDASEGNALARE.IDEVENTO,
          EVENTIDASEGNALARE.DATAORAINSERIMENTO,
          EVENTIDASEGNALARE.ENUMSTATOALLARME
          into
          p_IDEVENTO,
          p_DATAORAINSERIMENTO,
          p_ENUMSTATOALLARME
          from EVENTIDASEGNALARE
          inner join TRANSITIEVENTI
          on  TRANSITIEVENTI.TARGA = EVENTIDASEGNALARE.TARGA
          and TRANSITIEVENTI.NAZIONALITA = EVENTIDASEGNALARE.NAZIONALITA
          and TRANSITIEVENTI.DATAORAINSERIMENTO = EVENTIDASEGNALARE.DATAORAINSERIMENTO
          and TRANSITIEVENTI.IDEVENTO = EVENTIDASEGNALARE.IDEVENTO
          where
              TRANSITIEVENTI.TARGA = p_Targa
          and TRANSITIEVENTI.NAZIONALITA = p_Nazionalita
          and TRANSITIEVENTI.DATAORARILEVAMENTO = p_DATAORARILEVAMENTO
          and EVENTIDASEGNALARE.TARGA = p_Targa
          and EVENTIDASEGNALARE.NAZIONALITA = p_Nazionalita
          and EVENTIDASEGNALARE.ENUMTIPOEVENTO = 'TS';
        exception when no_data_found then
          p_IDEVENTO := null;
          p_DATAORAINSERIMENTO := null;
        end;


	declare
		cursor cur is
			select
			QJOBS.QJID
			from QJOBS_INTERVENTI
			inner join QJOBS
			on QJOBS.QJID = QJOBS_INTERVENTI.QJID
			where
			QJOBS_INTERVENTI.TARGA = p_TARGA and
			QJOBS_INTERVENTI.NAZIONALITA= p_NAZIONALITA and
			QJOBS.QJSTATUS in ('QUEUE', 'RUN', 'RRES', 'END');

		rec cur%rowtype;

	begin
		open cur;
		loop
			fetch cur into rec;
			exit when not cur%FOUND;

			update ITRS.QJOBS_INTERVENTI
			set
			UT_DATAORARILEVAMENTO        = p_DATAORARILEVAMENTO,
			UT_C2P_DESCRIZIONE           = p_C2P_DESCRIZIONE,
			UT_C2P_DIREZIONE             = p_C2P_DIREZIONE,
			UT_ENUMTIPOVARCO             = p_ENUMTIPOVARCO,
			UT_ENUMSTATOTRANSITO         = p_ENUMSTATOTRANSITO,
			UT_EVENTOASSOCIATOALTRANSITO = 'S'
			where
			TARGA = p_TARGA and
			NAZIONALITA = p_NAZIONALITA and
			QJID = rec.QJID;

        begin

	-- metto il record nella tabella dei risultati
	insert into ITRS.QJOBSRES_INTERVENTI
	(
        QJID,
        TARGA,
        NAZIONALITA,
        DATAORARILEVAMENTO,
        C2P_DESCRIZIONE,
        C2P_DIREZIONE,
        ENUMTIPOVARCO,
        ENUMSTATOTRANSITO,
        EVENTOASSOCIATOALTRANSITO,

        -- dati dell'eventuale allarme per LTS
        IDEVENTO,
        DATAORAINSERIMENTO,
        ENUMSTATOALLARME
      )
      values
      (
        rec.QJID,
        p_TARGA,
        p_NAZIONALITA,
        p_DATAORARILEVAMENTO,
        p_C2P_DESCRIZIONE,
        p_C2P_DIREZIONE,
        p_ENUMTIPOVARCO,
        p_ENUMSTATOTRANSITO,
        'S',

        -- dati dell'eventuale allarme per LTS
        p_IDEVENTO,
        p_DATAORAINSERIMENTO,
        p_ENUMSTATOALLARME
      );

      exception
        when DUP_VAL_ON_INDEX then
          null;
      end;


      end loop;
      close cur;
      end;
end;

-- lista degli interventi per coa.
procedure ListaInterventiPerCoa
(
	p_IdCoa  in  COA.IdCoa%TYPE,
	p_Cur    out T_CURSOR
)
is
	p_PKID  ASPNET_USERS.PKID%TYPE;
begin

	OPEN p_Cur FOR
		SELECT
		LTS.Note,
		LTS.Motivo,
		QJOBS.*,
		QJOBS_INTERVENTI.*

		FROM LTS
		inner join QJOBS_INTERVENTI
		on
		QJOBS_INTERVENTI.TARGA = Lts.TARGA and
		QJOBS_INTERVENTI.NAZIONALITA= Lts.NAZIONALITA
		inner join QJOBS
		on QJOBS.QJID = QJOBS_INTERVENTI.QJID
		where
		LTS.AddrDest = p_IdCoa and
		LTS.EnumTipoLts = 'C' and
    LTS.EnumTipoDest = 'COA'
    order by QJOBS_INTERVENTI.Targa;

end;


procedure CancellaInterventoPerCoa
(
p_IdCoa       in COA.IdCoa%type,
p_TARGA       in TRANSITI.TARGA%TYPE,
p_NAZIONALITA in TRANSITI.NAZIONALITA%TYPE,
p_QMGR        out T_CURSOR
)
is
	p_PKID  ASPNET_USERS.PKID%TYPE;
	p_NumeroJobs number;
begin

	-- cancello l'entry in LTS per l'intervento/coa
	delete from LTS
	where Targa = p_TARGA and
	Nazionalita = p_Nazionalita and
	LTS.AddrDest = p_IdCoa and
  LTS.EnumTipoLts = 'C' and
  LTS.EnumTipoDest = 'COA';

  -- controllo se ci sono altri COA che condividono lo stesso intervento
  select count(*) into p_NumeroJobs
  from LTS
  where Targa = p_TARGA and
  Nazionalita = p_Nazionalita and
  LTS.EnumTipoLts = 'C' and
  LTS.EnumTipoDest = 'COA';

  -- se p_NumeroJobs=0 cancello tutti i record di tutti gli interventi
  -- afferenti a quella targa.
  declare cursor cur is
    select
    QJID
    FROM QJOBS_INTERVENTI
    where
    QJOBS_INTERVENTI.TARGA = p_TARGA and
    QJOBS_INTERVENTI.NAZIONALITA= p_NAZIONALITA and
    p_NumeroJobs = 0;

    rec cur%rowtype;
    begin
      open cur;
      loop
        fetch cur into rec;
	exit when not cur%FOUND;

        delete from ITRS.QJOBSRES_INTERVENTI where QJID = rec.QJID;
        delete from ITRS.QJOBS_INTERVENTI where QJID = rec.QJID;
        delete from ITRS.QJOBS where QJID = rec.QJID;
      end loop;
    end;

   ITRS_LTS_MWP.GetListC2PFromTarga(p_Targa, p_Nazionalita, p_QMGR);

end;

-- end del package body
end;
GO
CREATE PACKAGE BODY ITRS_SMLOG AS

procedure AddMessage
(
  p_Application smlog.smapplication%type,
  p_Type        smlog.smtype%type,
  p_Message     smlog.smmessage%type,
  p_Exception   smlog.smexception%type
)
is
  p_LastId smlog.smid%type;
begin

  -- questa implementazione dovrebbe essere resistente a piu` applicazioni
  -- che chiamano AddMessage in contemporanea.
  -- Per evitare corse, si mette un for update
  -- nella select dei parametri, lock che viene rilasciato
  -- alla fine della transazione (che il DAL deve aprire)

  begin
    select parvalue into p_LastId from parametri
    where partipo='smlog_id'
    for update;
  exception when no_data_found then
    -- qui potrebbe esserci una corsa... ma avviene solo al primo insert.
    insert into Parametri (parvalue, partipo) values (0, 'smlog_id');
    p_LastId := -1;
  end;

  -- determino il prossimo smId. Al max 100 record nella tabella.

  p_LastId := p_LastId + 1;
  if (p_LastId >= 100) then
    p_LastId := 0;
  end if;


  -- provo ad updatare il record. Se c'e` bene
  -- se non c'e`, smLog e` vuota (per quell'smId) e dunque faccio insert
  update smLog
  set
  SMAPPLICATION = p_Application,
  SMMESSAGE     = p_Message,
  SMEXCEPTION   = p_Exception,
  SMTYPE        = p_Type,
  SMTS          = sysdate
  where smId = p_LastId;

  if sql%rowcount = 0 then
    INSERT INTO ITRS.SMLOG
    (
      SMID,
      SMAPPLICATION,
      SMMESSAGE,
      SMEXCEPTION,
      SMTYPE,
      SMTS
    )
    VALUES
    (
      p_LastId,
      p_Application,
      p_Message,
      p_Exception,
      p_Type,
      SYSDATE
    );
  end if;

  -- aggiorno il contatore dell'ultimo smID
  update Parametri
  set parvalue = p_LastId
  where partipo = 'smlog_id';

  -- qui devo rilasciare la transazione per rilasciare il lock
end;

END;
GO
CREATE PACKAGE BODY ITRS_SORVEGLIANZA AS

procedure AccodaEvento
(
  p_TARGA               in EVENTIDASEGNALARE.TARGA%TYPE,
  p_NAZIONALITA         in EVENTIDASEGNALARE.NAZIONALITA%TYPE,
  p_DATAORAINSERIMENTO  in EVENTIDASEGNALARE.DATAORAINSERIMENTO%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITISUEVENTO.DATAORARILEVAMENTO%TYPE,
  p_IDEVENTO            in EVENTIDASEGNALARE.IDEVENTO%TYPE,
  p_IDCOA               in EVENTIDASEGNALARE.IDCOACOMPETENZA%type,
  p_Img                 in ImmaginiSuEvento.IMMAGINE%type
)
is
  p_ProgrMin NUMBER;
  p_ProgrMax NUMBER;
begin

  begin
    select
    ProgrMax, ProgrMin into p_ProgrMax, p_ProgrMin
    from SorveglianzaResCount
    where IdCoa = p_IdCoa
    for update;
  exception when no_data_found then
    insert into SorveglianzaResCount
    (IdCoa, ProgrMin, ProgrMax) values
    (p_IdCoa, 0, -1);

    p_ProgrMin := 0;
    p_ProgrMax := -1;

  end;

  if (p_ProgrMax - p_ProgrMin + 1 >= 100) then
    -- aggiorno il record piu` vecchio con il piu` nuovo
    update SorveglianzaRes
    set
    Targa = p_Targa,
    Nazionalita = p_Nazionalita,
    DataOraInserimento = p_DataOraInserimento,
    DataOraRilevamento = p_DataOraRilevamento,
    IdEvento = p_IdEvento,
    Progr = p_ProgrMax + 1,
    Immagine = p_Img
    where
    IdCoa = p_IdCoa
    and Progr = p_ProgrMin;

    update SorveglianzaResCount
    set
    ProgrMin = p_ProgrMin + 1,
    ProgrMax = p_ProgrMax + 1
    where
    IdCoa    = p_IdCoa;

  else
    insert into SorveglianzaRes
    (
      Targa,
      Nazionalita,
      DataOraInserimento,
      DataOraRilevamento,
      IdEvento,
      IdCoa,
      Progr,
      Immagine
    )
    values
    (
      p_Targa,
      p_Nazionalita,
      p_DataOraInserimento,
      p_DataOraRilevamento,
      p_IdEvento,
      p_IdCoa,
      p_ProgrMax + 1,
      p_Img
    );

    update SorveglianzaResCount
    set
    ProgrMax = p_ProgrMax + 1
    where
    IdCoa = p_IdCoa;

  end if;
end;

procedure GetListaEventi
(
  p_IDCOA  in  EVENTIDASEGNALARE.IDCOACOMPETENZA%type,
  p_Cur    out T_CURSOR
)
is
begin

  OPEN p_Cur FOR

    select
    S.Targa,
    S.Nazionalita,
    S.Immagine,

    E.DataOraInserimento,
    E.IdEvento,
    E.EnumTipoEvento         TipoEvento,
    E.EnumStatoAllarme       StatoAllarme,
    UTEV.UserName            EvUtentePresaInCarico,
    E.DataOraPresaInCarico   EvDataOraPresaInCarico,
    E.DataOraChiusura        EvDataOraChiusura,
    E.NoteChiusura           EvNoteChiusura,
    E.EnumClasseUrgenza,

    T.EnumTipoVarco,
    T.DataOraRilevamento,
    T.EnumStatoTransito,
    UTTR.UserName           TrUtentePresaInCarico,
    T.DataOraPresaInCarico  TrDataOraPresaInCarico,
    T.DataOraChiusura       TrDataOraChiusura,
    T.NoteChiusura          TrNoteChiusura,

    nvl(T.Latitudine,  C2P.Lat) TrLatitudine,
    nvl(T.Longitudine, C2P.Lon) TrLongitudine,

    C2p.DIREZIONE           TrC2PDirezione,
    C2p.DESCRIZIONE         TrC2PDescrizione,

    Strade.DESCRIZIONESTRADA TrC2pStrada


    from SorveglianzaRes S

    inner join EventiDaSegnalare E
    on  E.Targa              = S.Targa
    and E.Nazionalita        = S.Nazionalita
    and E.DataOraInserimento = S.DataOraInserimento
    and E.IdEvento           = S.IdEvento

    inner join TransitiSuEvento T
    on  T.Targa              = S.Targa
    and T.Nazionalita        = S.Nazionalita
    and T.DataOraRilevamento = S.DataOraRilevamento

    left outer join ASPNET_USERS UTEV
    on  UTEV.pkid = E.IdUtentePresaInCarico

    left outer join ASPNET_USERS UTTR
    on  UTTR.pkid = T.IdUtentePresaInCarico

    inner join C2P
    on C2P.IDC2P = T.IDC2P

    inner join Strade
    on Strade.CODICESTRADA = C2P.CODICESTRADA

    where S.IDCOA = p_IDCOA
    order by S.Progr desc;

end;



procedure GetDatiSorveglianza
(
  p_TARGA               in EVENTIDASEGNALARE.TARGA%TYPE,
  p_NAZIONALITA         in EVENTIDASEGNALARE.NAZIONALITA%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITISUEVENTO.DATAORARILEVAMENTO%TYPE,
  p_Cur                 out T_CURSOR
)
is
begin
  OPEN p_Cur FOR

    select
    T.Targa,
    T.Nazionalita,

    E.DataOraInserimento,
    E.IdEvento,
    E.EnumTipoEvento         TipoEvento,
    E.EnumStatoAllarme       StatoAllarme,
    UTEV.UserName            EvUtentePresaInCarico,
    E.DataOraPresaInCarico   EvDataOraPresaInCarico,
    E.DataOraChiusura        EvDataOraChiusura,
    E.NoteChiusura           EvNoteChiusura,
    E.EnumClasseUrgenza,

    T.EnumTipoVarco,
    T.DataOraRilevamento,
    T.EnumStatoTransito,
    UTTR.UserName           TrUtentePresaInCarico,
    T.DataOraPresaInCarico  TrDataOraPresaInCarico,
    T.DataOraChiusura       TrDataOraChiusura,
    T.NoteChiusura          TrNoteChiusura,

    nvl(T.Latitudine,  C2P.Lat) TrLatitudine,
    nvl(T.Longitudine, C2P.Lon) TrLongitudine,

    C2p.DIREZIONE           TrC2PDirezione,
    C2p.DESCRIZIONE         TrC2PDescrizione,

    Strade.DESCRIZIONESTRADA TrC2pStrada

    from TransitiSuEvento T

    inner join TransitiEventi TE
    on  TE.Targa              = T.Targa
    and TE.Nazionalita        = T.Nazionalita
    and TE.DataOraRilevamento = T.DataOraRilevamento

    inner join EventiDaSegnalare E
    on  E.Targa              = TE.Targa
    and E.Nazionalita        = TE.Nazionalita
    and E.DataOraInserimento = TE.DataOraInserimento
    and E.IdEvento           = TE.IdEvento
    and E.EnumTipoEvento     = 'TS'

    left outer join ASPNET_USERS UTEV
    on  UTEV.pkid = E.IdUtentePresaInCarico

    left outer join ASPNET_USERS UTTR
    on  UTTR.pkid = T.IdUtentePresaInCarico

    inner join C2P
    on C2P.IDC2P = T.IDC2P

    inner join Strade
    on Strade.CODICESTRADA = C2P.CODICESTRADA

    where
    T.Targa = p_Targa
    and T.Nazionalita = p_Nazionalita
    and T.DataOraRilevamento = p_DataOraRilevamento;


end;

END;
GO
CREATE PACKAGE BODY ITRS_TRANSITI_EVENTI AS

procedure TransitoPrendiInCarico
(
  p_Targa                 in Transiti.Targa%type,
  p_Nazionalita           in Transiti.NAZIONALITA%type,
  p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,
  p_IdUtentePresaInCarico in Transiti.IDUTENTEPRESAINCARICO%type,
  p_Updated               out integer
)
is
begin

  update TransitiSuEvento
  set
  IdUtentePresaInCarico = p_IdUtentePresaInCarico,
  DataOraPresaInCarico  = sysdate,
  EnumStatoTransito     = 'PIC'
  where
  Targa = p_Targa and
  Nazionalita = p_Nazionalita and
  DataOraRilevamento = p_DataOraRilevamento and
  EnumStatoTransito = 'DARIC';

  p_Updated := sql%rowcount;

  update Transiti
  set
  IdUtentePresaInCarico = p_IdUtentePresaInCarico,
  DataOraPresaInCarico  = sysdate,
  EnumStatoTransito     = 'PIC'
  where
  Targa = p_Targa and
  Nazionalita = p_Nazionalita and
  DataOraRilevamento = p_DataOraRilevamento and
  EnumStatoTransito = 'DARIC';

  p_Updated := p_Updated + sql%rowcount;

end;


procedure TransitoAzioneSuPresaInCarico
(
  p_Targa                 in Transiti.Targa%type,
  p_Nazionalita           in Transiti.NAZIONALITA%type,
  p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,

  p_StatoTransito         in Transiti.ENUMSTATOTRANSITO%type,
  p_NoteChiusura          in Transiti.NOTECHIUSURA%type,

  p_Updated               out integer
)
is
begin
  case
  when p_StatoTransito = 'DARIC' then
    begin
      update TransitiSuEvento
      set
      IdUtentePresaInCarico = null,
      DataOraPresaInCarico  = null,
      EnumStatoTransito     = 'DARIC',
      DataOraChiusura       = null,
      NoteChiusura          = null
      where
      Targa = p_Targa and
      Nazionalita = p_Nazionalita and
      DataOraRilevamento = p_DataOraRilevamento and
      EnumStatoTransito = 'PIC' ;

      p_Updated := sql%rowcount;

      update Transiti
      set
      IdUtentePresaInCarico = null,
      DataOraPresaInCarico  = null,
      EnumStatoTransito     = 'DARIC',
      DataOraChiusura       = null,
      NoteChiusura          = null
      where
      Targa = p_Targa and
      Nazionalita = p_Nazionalita and
      DataOraRilevamento = p_DataOraRilevamento and
      EnumStatoTransito = 'PIC' ;

      p_Updated := p_Updated + sql%rowcount;

    end;

  when p_StatoTransito = 'RIC' or p_StatoTransito = 'NORIC' then
    begin
      update TransitiSuEvento
      set
      EnumStatoTransito     = p_StatoTransito,
      DataOraChiusura       = sysdate,
      NoteChiusura          = p_NoteChiusura
      where
      Targa = p_Targa and
      Nazionalita = p_Nazionalita and
      DataOraRilevamento = p_DataOraRilevamento and
      EnumStatoTransito = 'PIC' ;

      p_Updated := sql%rowcount;


      update Transiti
      set
      EnumStatoTransito     = p_StatoTransito,
      DataOraChiusura       = sysdate,
      NoteChiusura          = p_NoteChiusura
      where
      Targa = p_Targa and
      Nazionalita = p_Nazionalita and
      DataOraRilevamento = p_DataOraRilevamento and
      EnumStatoTransito = 'PIC';

      p_Updated := p_Updated + sql%rowcount;

    end;
  else
    null;
  end case;
end;
--------------------------------------------------------------------------------

procedure EventoPrendiInCarico
(
  p_Targa                 in EventiDaSegnalare.Targa%type,
  p_Nazionalita           in EventiDaSegnalare.NAZIONALITA%type,
  p_DataOraInserimento    in EventiDaSegnalare.DATAORAINSERIMENTO%type,
  p_IdEvento              in EventiDaSegnalare.IDEVENTO%type,
  p_IdUtentePresaInCarico in EventiDaSegnalare.IDUTENTEPRESAINCARICO%type,
  p_Updated               out integer
)
is
begin
  -- 'ACQ','PIC','CNF','NCNF'
  update EventiDaSegnalare
  set
  IdUtentePresaInCarico = p_IdUtentePresaInCarico,
  DataOraPresaInCarico  = sysdate,
  EnumStatoAllarme      = 'PIC'
  where
  Targa = p_Targa and
  Nazionalita = p_Nazionalita and
  DataOraInserimento = p_DataOraInserimento and
  IdEvento = p_IdEvento and
  EnumStatoAllarme = 'ACQ';

  p_Updated := sql%rowcount;
end;

procedure EventoAzioneSuPresaInCarico
(
  p_Targa                 in EventiDaSegnalare.Targa%type,
  p_Nazionalita           in EventiDaSegnalare.NAZIONALITA%type,
  p_DataOraInserimento    in EventiDaSegnalare.DATAORAINSERIMENTO%type,
  p_IdEvento              in EventiDaSegnalare.IDEVENTO%type,

  p_StatoAllarme          in EventiDaSegnalare.ENUMSTATOALLARME%type,
  p_NoteChiusura          in EventiDaSegnalare.NOTECHIUSURA%type,
  p_Updated               out integer

)
is
begin
  -- 'ACQ','PIC','CNF','NCNF'
  case
  when p_StatoAllarme = 'ACQ' then
    begin
      update EventiDaSegnalare
      set
      IdUtentePresaInCarico = null,
      DataOraPresaInCarico  = null,
      EnumStatoAllarme      = 'ACQ',
      DataOraChiusura       = null,
      NoteChiusura          = null
      where
      Targa = p_Targa and
      Nazionalita = p_Nazionalita and
      DataOraInserimento = p_DataOraInserimento and
      IdEvento = p_IdEvento and
      EnumStatoAllarme = 'PIC' ;

      p_Updated := sql%rowcount;

    end;

  when p_StatoAllarme = 'CNF' or p_StatoAllarme = 'NCNF' then
    begin
      update EventiDaSegnalare
      set
      EnumStatoAllarme      = p_StatoAllarme,
      DataOraChiusura       = sysdate,
      NoteChiusura          = p_NoteChiusura
      where
      Targa = p_Targa and
      Nazionalita = p_Nazionalita and
      DataOraInserimento = p_DataOraInserimento and
      IdEvento = p_IdEvento and
      EnumStatoAllarme = 'PIC' ;

      p_Updated := sql%rowcount;

    end;
  else
    null;
  end case;
end;



END;
GO
CREATE PACKAGE BODY ITRS_LTS_MWP AS



procedure GetListC2PFromTarga
(
p_Targa       in TRANSITI.TARGA%type,
p_Nazionalita in TRANSITI.TARGA%type,
p_Qmgr        out T_CURSOR
)
is
begin
  -- apro un cursore che ritorna la lista dei C2P purche`
  -- la targa NON sia gia` nel LTS
  OPEN p_Qmgr FOR
    SELECT
    c2p.QMGR_NAME,
    c2p.DATAORARILEVAMENTO
    from C2P
    where not exists
    (
      select * from LTS
      where
      LTS.TARGA = p_Targa and
      LTS.Nazionalita = p_Nazionalita
    );
end;


END;
GO
CREATE PACKAGE BODY ITRS_QJ as

	-- stati QUEUE, RUN, SOSP, ERR, RRES, END, ABRQ, ABAK, CANC
	-- QUEUE job in coda
	-- RUN   job in esecuzione
	-- SOSP  job sospeso
	-- ERR   job terminato con eccezione
	-- RRES  job in run che ha prodotto risultati intermedi
	-- END   job terminato con successo
	-- ABRQ  job con richiesta di abort in corso
	-- ABAK  job che ha accettato la richiesta di abort
	-- CANC  job da cancellare perche` scaduto (sysdate - QJLASTRESACCESS > QJRESTIMEOUTSEC)

	-- crea un nuovo job in stato QUEUE
	procedure QJ_Create
	(
		p_QJID       in QJOBS.QJID%TYPE,
		p_QJTYPE     in QJOBS.QJTYPE%TYPE,
		p_QJARGS     in QJOBS.QJARGS%TYPE,
		p_QJPKIDUSER in QJOBS.QJPKIDUSER%TYPE
	)
	is
		p_QJPRIORITY QJOBS.QJPRIORITY%type;
	begin
		select QJPRIORITY into p_QJPRIORITY from QJOBTYPES where QJTYPE = p_QJTYPE;

		insert into ITRS.QJOBS
		(QJID,     QJTYPE,   QJPRIORITY,   QJARGS,   QJPKIDUSER, QJSTATUS, QJTSQUEUE, QJLASTRESACCESS)
		values
		(p_QJID, p_QJTYPE, p_QJPRIORITY, p_QJARGS, p_QJPKIDUSER, 'QUEUE',  sysdate,   sysdate);

	end;

        -- crea un nuovo job in stato Queue ma
	procedure QJ_CreateEx
	(
		p_QJID        in  QJOBS.QJID%TYPE,
		p_QJTYPE      in  QJOBS.QJTYPE%TYPE,
		p_QJARGS      in  QJOBS.QJARGS%TYPE,
		p_QJPKIDUSER  in  QJOBS.QJPKIDUSER%TYPE,
                p_JobAccepted out int  -- 1 accettato, 0 non accettato
	)
        is
		p_QJPRIORITY      QJOBS.QJPRIORITY%type;
		p_QJMAXRES        QJOBTYPES.QJMAXRES%type;
                p_ACTUALNUMRES    QJOBTYPES.QJMAXRES%type;
                p_QJQUEUECRITERIA QJOBTYPES.QJQUEUECRITERIA%type;
        begin
                -- trovo la priorita e il massimo numero di jobs nella tabella
                -- QJOBS per il tipo di job in ingresso.
		select QJOBTYPES.QJPRIORITY,  QJOBTYPES.QJMAXRES, QJOBTYPES.QJQUEUECRITERIA
                into p_QJPRIORITY, p_QJMAXRES, p_QJQUEUECRITERIA
                from QJOBTYPES
                where QJTYPE = p_QJTYPE;

                -- se esiste il massimo numero numero di job
                -- allora controllo il numero di job effettivi nella
                -- QJOBS.
                -- se quelli effettivi eccedono non accodo ed esco.
                if (p_QJMAXRES is not null and p_QJMAXRES > 0) then

                  case
                    when (p_QJQUEUECRITERIA = 'MT') then
                      select
                      count(*) into p_ACTUALNUMRES
                      from QJOBS
                      where QJOBS.QJTYPE = p_QJTYPE
                      and   QJOBS.QJSTATUS <> 'CANC';

                    when (p_QJQUEUECRITERIA = 'MU') then
                      select
                      count(*) into p_ACTUALNUMRES
                      from QJOBS
                      where QJOBS.QJTYPE = p_QJTYPE
                      and   QJOBS.QJPKIDUSER = p_QJPKIDUSER
                      and   QJOBS.QJSTATUS <> 'CANC';

                    else
                      p_ACTUALNUMRES := 1000000;

                  end case;

                  if (p_ACTUALNUMRES >= p_QJMAXRES) then
                    p_JobAccepted := 0;
                    return;
                  end if;
                end if;

		insert into ITRS.QJOBS
		(QJID,     QJTYPE,   QJPRIORITY,   QJARGS,   QJPKIDUSER, QJSTATUS, QJTSQUEUE, QJLASTRESACCESS)
		values
		(p_QJID, p_QJTYPE, p_QJPRIORITY, p_QJARGS, p_QJPKIDUSER, 'QUEUE',  sysdate,   sysdate);

                p_JobAccepted := 1;
        end;



	-- User : metto il job in stato ABRQ
	procedure QJ_Abort(p_QJID in QJOBS.QJID%TYPE)
	is
	begin
		update QJOBS
		set    QJSTATUS = 'ABRQ'
		where
		QJID = p_QJID
		and QJSTATUS in ('QUEUE' , 'RUN', 'RRES');

	end;

	-- User : metto il job in stato SOSP (solo se sono in QUEUE)
	procedure QJ_Suspend(p_QJID in QJOBS.QJID%TYPE)
	is
	begin
		update QJOBS
		set    QJSTATUS = 'SOSP'
		where
		QJID = p_QJID
		and QJSTATUS = 'QUEUE';

	end;

	-- User : metto il job in stato QUEUE (solo se sono in SOSP)
	procedure QJ_Resume(p_QJID in QJOBS.QJID%TYPE)
	is
	begin
		update QJOBS
		set    QJSTATUS = 'QUEUE'
		where
		QJID = p_QJID
		and QJSTATUS = 'SOSP';

	end;


	-- Batch : cambia lo stato -
	procedure QJ_ChangeStatus(p_QJID in QJOBS.QJID%TYPE, p_QJSTATUS in QJOBS.QJSTATUS%TYPE)
	is
	begin
		update QJOBS
		set    QJSTATUS = p_QJSTATUS,
		       QJTSLAST = sysdate
		where  QJID = p_QJID;
	end;


	-- Batch : memorizza lo stato attuale di esecuzione
	procedure QJ_Progress
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJSTATUS      in QJOBS.QJSTATUS%TYPE,
		p_QJPROGRMSG    in QJOBS.QJPROGRMSG%TYPE,
		p_QJTOTALSTEPS  in QJOBS.QJTOTALSTEPS%TYPE,
		p_QJCURRENTSTEP in QJOBS.QJCURRENTSTEP%TYPE,
		p_QJRESRECORDCOUNT in QJOBS.QJRESRECORDCOUNT%TYPE
	)
	is
	begin

   update QJOBS set
   QJSTATUS = p_QJSTATUS,
	QJTSLAST = sysdate
	where
	 QJID = p_QJID;


		if p_QJPROGRMSG is not null then
       update QJOBS set
		   QJPROGRMSG = p_QJPROGRMSG
		   where
		   QJID = p_QJID;
		end if;

		if p_QJTOTALSTEPS is not null then
       update QJOBS set
		   QJTOTALSTEPS = p_QJTOTALSTEPS
		   where
		   QJID = p_QJID;
		end if;

		if p_QJCURRENTSTEP is not null then
       update QJOBS set
		   QJCURRENTSTEP = p_QJCURRENTSTEP
		   where
		   QJID = p_QJID;
		end if;

		if p_QJRESRECORDCOUNT is not null then
       update QJOBS set
		   QJRESRECORDCOUNT = p_QJRESRECORDCOUNT
		   where
		   QJID = p_QJID;
		end if;


	end;


	-- Batch : da chiamare quando il batch va in eccezione
	procedure QJ_Error
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJERRMSG      in QJOBS.QJERRMSG%TYPE
	)
	is
	begin

		update QJOBS set
		QJSTATUS = 'ERR',
		QJERRMSG = p_QJERRMSG,
		QJTSLAST = sysdate
		where
		QJID = p_QJID;

	end;



	-- Batch : da chiamare quando il batch termina
	procedure QJ_End
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJPROGRMSG    in QJOBS.QJPROGRMSG%TYPE,
		p_QJRESULT      in QJOBS.QJRESULT%TYPE
	)
	is
	begin
		update QJOBS set
		QJSTATUS = 'END',
		QJPROGRMSG = p_QJPROGRMSG,
		QJRESULT = p_QJRESULT,
		QJTSLAST = sysdate
		where
		QJID = p_QJID;

	end;


	-- User : da chiamare quando l'utente interroga il risultato.
	-- In questo modo si prolunga la vita del result del job.
	procedure QJ_Access
	(
		p_QJID          in QJOBS.QJID%TYPE
	)
	is
	begin
		update QJOBS set
		QJLASTRESACCESS = sysdate
		where
		QJID = p_QJID;
	end;


	-- Batch : mette in stato CANC i jobs vecchi in stato terminale
	procedure QJ_Purge
	is
	begin
		update QJOBS
		set QJSTATUS = 'CANC'
		where
		QJID in
		(
			select Q.QJID
			from QJOBS Q, QJOBTYPES T
			where
			Q.QJTYPE = T.QJTYPE
			and ((sysdate -  QJLASTRESACCESS) * 24 * 3600) > T.QJRESTIMEOUTSEC
		)
		and QJSTATUS in ( 'ERR', 'END', 'ABAK', 'SOSP', 'ABRQ');
	end;

        -- User: mette in CANC i job che soddisfano le caratteristiche in ingresso
	procedure QJ_Canc
        (
          p_QJID       QJOBS.QJID%type,
          p_QJTYPE     QJOBS.QJTYPE%type,
          p_QJPKIDUSER QJOBS.QJPKIDUSER%type,
          p_QJSTATUS   QJOBS.QJSTATUS%type
        )
	is
	begin
		update QJOBS
		set QJSTATUS = 'CANC'
		where
                    (p_QJID is null       or QJID = p_QJID)
                and (p_QJTYPE is null     or QJTYPE = p_QJTYPE)
                and (p_QJPKIDUSER is null or QJPKIDUSER = p_QJPKIDUSER)
                and (p_QJSTATUS is null   or QJSTATUS = p_QJSTATUS)
		and QJSTATUS in ('ERR', 'END', 'ABAK', 'SOSP');
	end;



	-- Batch: ottiene il prossivo job da eseguire, se esiste.
	procedure QJ_GetNextToRun
	(
		p_QJID       out QJOBS.QJID%TYPE,
		p_QJARGS     out QJOBS.QJARGS%TYPE,
		p_QJTYPE     out QJOBS.QJTYPE%TYPE
	)
	is
		nTotalRunning int;
		nTotalAllowed int;

	begin

		p_QJID := null;
		p_QJARGS := null;

		-- numero totale di job in stato running
		select count(*) into nTotalRunning from QJOBS
		where QJSTATUS = 'RUN' or QJSTATUS = 'RRES';

		-- numero totale di job permessi
		select QJMAXRUNNING into nTotalAllowed from QJOBTYPES
		where QJTYPE = '*';

		begin
			select QJMAXRUNNING into nTotalAllowed from QJOBTYPES
			where QJTYPE = '*';
		exception
			when no_data_found then

				insert into ITRS.QJOBTYPES
				(QJTYPE, QJMAXRUNNING, QJPRIORITY, QJDESCR, QJRUNTIMEOUTSEC, QJQUEUETIMEOUTSEC, QJRESTIMEOUTSEC)
				values
				('*',              10,        '5',     ' ',             120,              1200,          150000);
		end;

		if nTotalRunning >= nTotalAllowed
		then
			return; -- non posso servire un job in coda... troppi job in corso
		end if;

		declare

		cursor cur is
			-- primo job in QUEUE con
			-- a) priorita` piu` alta
			-- b) piu` vecchio
			-- c) con numero di job dello stesso tipo in running < del massimo
			--    consentito
			select
			Q.QJID, Q.QJTYPE, Q.QJARGS
			from QJOBS Q
			inner join QJOBTYPES T
			on Q.QJTYPE = T.QJTYPE
			where
			rownum = 1
			and Q.QJSTATUS = 'QUEUE'
			and T.QJMAXRUNNING >
				(
					select count (*) from QJOBS R
					where (R.QJSTATUS = 'RUN' or R.QJSTATUS = 'RRES')
					and R.QJTYPE = Q.QJTYPE
				)
			order by
			Q.QJPRIORITY desc,
			Q.QJTSQUEUE asc
			for update;

		rec cur%rowtype;


		begin

			open cur;
			loop
				fetch cur into rec;
				exit when not cur%FOUND;

				update QJOBS
				set
				QJSTATUS = 'RUN',
				QJTSLAST = sysdate
				where current of cur;

				p_QJID   := rec.QJID;
				p_QJARGS := rec.QJARGS;
				p_QJTYPE := rec.QJTYPE;


				-- esco comunque anche in caso di errore
				exit;
			end loop;
			close cur;
		end;
	end;


end;
GO
CREATE PACKAGE BODY ITRS_INDAGINI as
procedure QUERYINDAGINETRANSITI
(
	p_qjid        in varchar2,
	p_targa       in varchar2,
	p_nazionalita in varchar2,
	p_di          in date,
	p_df          in date,
        p_idc2p       in C2P.IDC2P%type,
	p_found       out int,
        p_MaxRec      out int
)
is
begin

	BEGIN
		select parValue into p_MaxRec from Parametri where ParTipo='INDAGINE_MAXREC';
	exception
	WHEN no_data_found THEN
        	insert into Parametri (parTipo, parValue) values ('INDAGINE_MAXREC', 1000);
		p_MaxRec := 1000;
	END;

	INSERT INTO ITRS.INDAGINI_TRANSITI
	(
		QJID,
		TARGA,
		NAZIONALITA,
		DATAORARILEVAMENTO,

                C2P_DESCRIZIONE,
                C2P_DIREZIONE,
                ENUMTIPOVARCO,
                ENUMSTATOTRANSITO
	)
        select
	p_qjid as QJID,
	Transiti.TARGA,
	Transiti.NAZIONALITA,
	Transiti.DATAORARILEVAMENTO,
        C2P.DESCRIZIONE,
        C2P.DIREZIONE,
        Transiti.ENUMTIPOVARCO,
        Transiti.ENUMSTATOTRANSITO

	from
	Transiti

        inner join C2P
        on C2P.IdC2P = Transiti.IDC2P

	where
	Transiti.DATAORARILEVAMENTO >= p_di
	and Transiti.DATAORARILEVAMENTO < p_df
	and (p_targa is null or Transiti.Targa like p_targa)
	and (p_nazionalita is null or Transiti.Nazionalita = p_nazionalita)
        and (p_idc2p is null or Transiti.IdC2P = p_idc2p)
        and rownum <= p_MaxRec;

	p_found := sql%rowcount;
end;


procedure QUERYINDAGINEEVENTI
(
	p_qjid        in varchar2,
	p_targa       in varchar2,
	p_nazionalita in varchar2,
	p_di          in date,
	p_df          in date,
        p_idc2p       in C2P.IDC2P%type,
        p_tipoEvento  in EVENTIDASEGNALARE.ENUMTIPOEVENTO%type,
	p_found       out int,
        p_MaxRec      out int
)
is
begin

	BEGIN
		select parValue into p_MaxRec from Parametri where ParTipo='INDAGINE_MAXREC';
	exception
	WHEN no_data_found THEN
        	insert into Parametri (parTipo, parValue) values ('INDAGINE_MAXREC', 1000);
		p_MaxRec := 1000;
	END;


      insert into ITRS.INDAGINI_EVENTI
      (
	QJID,
	TARGA,
	NAZIONALITA,
	DATAORAINSERIMENTO,
	IDEVENTO,
	ENUMTIPOEVENTO,
	ENUMSTATOALLARME,
	UTENTEPRESAINCARICO,
	DATAORAPRESAINCARICO,
	DATAORACHIUSURA,
	NOTECHIUSURA,
	COADICOMPETENZA,
	CLASSEDIURGENZA,
	DATAULTIMOTRANSITO
      )
      select
      *
      from
      (
        /*
        select
        p_qjid as QJID,
        E.Targa,
        E.Nazionalita,
        E.DataOraInserimento,
        E.IdEvento,
        E.EnumTipoEvento     as EnumTipoEvento,
        E.EnumStatoAllarme   as EnumStatoAllarme,
        U.UserName           as UtentePresaInCarico,
        E.DataOraPresaInCarico,
        E.DataOraChiusura,
        E.NoteChiusura,
        COA.Descrizione      as CoaDiCompetenza,
        E.EnumClasseUrgenza  as ClasseDiUrgenza,

        max(TE.DataOraRilevamento) as DataUltimoTransito

        from
        EventiDaSegnalare E

        inner join TransitiEventi TE
        on  TE.Targa = E.Targa
        and TE.Nazionalita = E.Nazionalita
        and TE.DataOraInserimento = E.DataOraInserimento
        and TE.IdEvento = E.IdEvento
        and (p_targa is null or TE.Targa like p_targa)
        and (p_nazionalita is null or TE.Nazionalita = p_nazionalita)

        inner join TransitiSuEvento TSE
        on  TSE.Targa = TE.Targa
        and TSE.Nazionalita = TE.Nazionalita
        and TSE.DataOraRilevamento = TE.DataOraRilevamento
        and TSE.DataOraRilevamento >= p_di
        and TSE.DataOraRilevamento <  p_df
        and (p_targa is null or TSE.Targa like p_targa)
        and (p_nazionalita is null or TSE.Nazionalita = p_nazionalita)

        left outer join COA
        on COA.IdCoa = E.IdCoaCompetenza

        left outer join aspnet_users U
        on U.PkId = E.IdUtentePresaInCarico

        where

        (p_targa is null or E.Targa like p_targa)
        and (p_nazionalita is null or E.Nazionalita = p_nazionalita)
        and (p_tipoEvento is null or E.EnumTipoEvento = p_tipoEvento)
        and (p_idc2p is null or TSE.IdC2P = p_idc2p)

        group by
            E.Targa,
            E.Nazionalita,
            E.DataOraInserimento,
            E.IdEvento,
            E.EnumTipoEvento,
            E.EnumStatoAllarme,
            U.UserName,
            E.DataOraPresaInCarico,
            E.DataOraChiusura,
            E.NoteChiusura,
            COA.Descrizione,
            E.EnumClasseUrgenza

        having
        max(TE.DataOraRilevamento) >= p_di and
        max(TE.DataOraRilevamento) <  p_df
        */

	select
        p_qjid as QJID,
        TSE.Targa,
        TSE.Nazionalita,
        TSE.DataOraInserimento,
        TSE.IdEvento,
        E.EnumTipoEvento     as EnumTipoEvento,
        E.EnumStatoAllarme   as EnumStatoAllarme,
        U.UserName           as UtentePresaInCarico,
        E.DataOraPresaInCarico,
        E.DataOraChiusura,
        E.NoteChiusura,
        COA.Descrizione      as CoaDiCompetenza,
        E.EnumClasseUrgenza  as ClasseDiUrgenza,
        TSE.DataOraRilevamento as DataUltimoTransito
	from
	(
		select
		max(TSE2.DATAORARILEVAMENTO) as DataOraRilevamento,
                TSE2.IdEvento,
                TSE2.Targa,
                TSE2.Nazionalita,
                TSE2.DataOraInserimento
		from TransitiEventi TSE2

                inner join TransitiSuEvento T2
                on  TSE2.Targa = T2.Targa
                and TSE2.Nazionalita = T2.Nazionalita
                and TSE2.DataOraRilevamento = T2.DataOraRilevamento
                and (p_idc2p is null or T2.IdC2P = p_idc2p)

		where p_Di <= TSE2.DATAORARILEVAMENTO
		and p_Df   > TSE2.DATAORARILEVAMENTO
                and (p_targa is null or TSE2.Targa like p_targa)
                and (p_nazionalita is null or TSE2.Nazionalita = p_nazionalita)

		group by TSE2.IDEVENTO, TSE2.targa, TSE2.NAZIONALITA, TSE2.DataOraInserimento
	) TSE
        inner join EVENTIDASEGNALARE E
        on  TSE.Targa = E.Targa
        and TSE.Nazionalita = E.Nazionalita
        and TSE.DataOraInserimento = E.DataOraInserimento
        and TSE.IdEvento = E.IdEvento
        and (p_tipoEvento is null or E.EnumTipoEvento = p_tipoEvento)

        inner join TransitiSuEvento T
        on  TSE.Targa = T.Targa
        and TSE.Nazionalita = T.Nazionalita
        and TSE.DataOraRilevamento = T.DataOraRilevamento
        and (p_idc2p is null or T.IdC2P = p_idc2p)

        left outer join COA
        on COA.IdCoa = E.IdCoaCompetenza

        left outer join aspnet_users U
        on U.PkId = E.IdUtentePresaInCarico
      )
      where
      rownum <= p_MaxRec
      ;

      p_found := sql%rowcount;

end;


procedure CancellaIndagine
(
	p_qjid in varchar2
)
is
begin
	delete from ITRS.INDAGINI_TRANSITI where QJID = p_qjid;
        delete from ITRS.INDAGINI_EVENTI   where QJID = p_qjid;
	delete from ITRS.QJOBS where QJOBS.QJID = p_qjid;
end;


end;
GO

