using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Configuration;
using System.Xml;
using System.Xml.Serialization;
using System.Text.RegularExpressions;

using System.Data;
using System.Data.Common;

/*
CREATE TABLE t_targherubate(
tab_targa VARCHAR2(10) NOT NULL,     
tab_telaio VARCHAR2(21),     
tab_data_furto VARCHAR2(11),     
tab_fabbrica VARCHAR2(25),     
tab_modello VARCHAR2(20),     
tab_tipo_veicolo VARCHAR2(25),     
tab_tipo_denuncia VARCHAR2(16) NOT NULL,     
tab_codice_ufficio VARCHAR2(7) NOT NULL,     
tab_ufficio VARCHAR2(40) NOT NULL,     
tab_targa_ant_post VARCHAR2(5) NOT NULL,     
tab_indice varchar2(26) not null,     
tab_nazionalita varchar2(15),     
tab_data_insert date);

CREATE TABLE t_targherubate_cancellate(
tab_targa_c VARCHAR2(10) NOT NULL,     
tab_telaio_c VARCHAR2(21),     
tab_data_furto_c VARCHAR2(11),     
tab_fabbrica_c VARCHAR2(25),     
tab_modello_c VARCHAR2(20),     
tab_tipo_veicolo_c VARCHAR2(25),     
tab_tipo_denuncia_c VARCHAR2(16) NOT NULL,     
tab_codice_ufficio_c VARCHAR2(7) NOT NULL,     
tab_ufficio_c VARCHAR2(40) NOT NULL,     
tab_targa_ant_post_c VARCHAR2(5) NOT NULL,     
tab_indice_c varchar2(26) not null,     
tab_nazionalita_c varchar2(15),     
tab_data_insert_c date);

*/
class CEPS_Export
{
	static void Main(string[] args)
	{

		CEPS_Export ce = new CEPS_Export();

		ce.ExportMassivoPerProva("c:\\A1_Castello.txt", new UltimaLettura());

		//ce.ExportTargheA2daFile("c:\\A2.txt", "c:\\A2.xml");
		return;
		//ce.Run(args);
	}


	public void Run(string[] args)
	{
	again:
		Console.Clear();
		Console.WriteLine("Export targhe rubate/veicoli non revisionati.");
		Console.WriteLine("1) Export massivo targhe rubate");
		Console.WriteLine("2) Export incrementale targhe rubate");
		Console.WriteLine("3) Export massivo veicoli non revisionati");
		Console.WriteLine("3) Export incrementale veicoli non revisionati");
		Console.WriteLine();
		Console.Write("Scegliere (digitare 1 o 2 o 3 o 4): ");
		string s = Console.ReadLine();
		if (!(s == "1" || s == "2" || s == "3" || s == "4"))
		{
			Console.WriteLine("Digitare 1 o 2 o 3 o 4");
			goto again;
		}

		string fileName = null;
		string localWorkingFolder = ConfigurationManager.AppSettings["LocalWorkingFolder"];

		bool trasferisciIlFile = ChiediConfermaTrasferimentoFTP();

		UltimaLettura ultimaElaborazione = null;

		string fileNameUltimaEsecuzione = "UltimaEsecuzione.xml";
		if (localWorkingFolder != null) fileNameUltimaEsecuzione = Path.Combine(localWorkingFolder, fileNameUltimaEsecuzione);
		if (File.Exists(fileNameUltimaEsecuzione))
		{
			using (Stream ss = File.OpenRead(fileNameUltimaEsecuzione))
			{
				XmlSerializer xs = new XmlSerializer(typeof(UltimaLettura));
				ultimaElaborazione = (UltimaLettura)xs.Deserialize(ss);
			}
		}
		else
			ultimaElaborazione = new UltimaLettura();

		switch (s)
		{
		case "1":
			{
				fileName = string.Format("EXP_MAS_TR_{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}.xml", DateTime.Now);
				if (localWorkingFolder != null)
					fileName = Path.Combine(localWorkingFolder, fileName);

				Console.WriteLine();
				Console.WriteLine("Export massivo targhe rubate");
				Console.WriteLine("  file file prodotto = {0}", Path.ChangeExtension(fileName, ".zip"));
				Console.WriteLine("  trasferimento file al server: {0}", trasferisciIlFile ? "si" : "no");

				ChiediConferma();

				Console.Write("Elaborazione in corso...");
				ExportMassivoA1(fileName, ultimaElaborazione);

				Console.WriteLine();
			}
			break;
		case "2":
			{
				if (ultimaElaborazione.ExportIncrementale_TargheRubate.HasValue)
					Console.WriteLine("Ultima lettura effettuata {0}", ultimaElaborazione.ExportIncrementale_TargheRubate.Value);
				else
					Console.WriteLine("Ultima lettura effettuata: <nessuna>");

				DateTime dal = ChiediDataInizio();

				fileName = string.Format("EXP_INCR_TR_{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}.xml", dal);
				if (localWorkingFolder != null)
					fileName = Path.Combine(localWorkingFolder, fileName);


				Console.WriteLine();
				Console.WriteLine("Export incrementale targe rubate");
				Console.WriteLine("  file prodotto = {0}", Path.ChangeExtension(fileName, ".zip"));
				Console.WriteLine("  variazioni estratte dal {0}", dal);
				Console.WriteLine("  trasferimento file al server: {0}", trasferisciIlFile ? "si" : "no");
				ChiediConferma();

				Console.Write("Elaborazione in corso...");
				ExportIncrementaleA1(fileName, dal, ultimaElaborazione);
				Console.WriteLine();
			}
			break;

		case "3":
			{
				if (ultimaElaborazione.ExportMassivo_TargheNonRevisionate.HasValue)
					Console.WriteLine("Ultima lettura effettuata {0}", ultimaElaborazione.ExportMassivo_TargheNonRevisionate.Value);
				else
					Console.WriteLine("Ultima lettura effettuata: <nessuna>");

				DateTime dal = DateTime.Now;
				fileName = string.Format("EXP_MAS_VNR_{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}.xml", dal);
				if (localWorkingFolder != null)
					fileName = Path.Combine(localWorkingFolder, fileName);


				string fileNameIn = ChiediFileIngresso("File da elaborare per l'import massivo: ");


				Console.WriteLine();
				Console.WriteLine("Export massivo veicoli non revisionati");
				Console.WriteLine("  file da elaborare = {0}", fileNameIn);
				Console.WriteLine("  file prodotto = {0}", Path.ChangeExtension(fileName, ".zip"));
				Console.WriteLine("  trasferimento file al server: {0}", trasferisciIlFile ? "si" : "no");

				ChiediConferma();

				Console.Write("Lettura dati in corso...");
				ExportMassivoA2(fileNameIn, fileName);

				ultimaElaborazione.ExportMassivo_TargheNonRevisionate = dal;
				Console.WriteLine();
			}
			break;

		case "4":
			{
				if (ultimaElaborazione.ExportIncrementale_TargheNonRevisionate.HasValue)
					Console.WriteLine("Ultima lettura effettuata {0}", ultimaElaborazione.ExportIncrementale_TargheNonRevisionate.Value);
				else
					Console.WriteLine("Ultima lettura effettuata: <nessuna>");

				DateTime dal = DateTime.Now;


				fileName = string.Format("EXP_INCR_VNR_{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}.xml", dal);
				if (localWorkingFolder != null)
					fileName = Path.Combine(localWorkingFolder, fileName);

				string fileNameIns = ChiediFileIngresso("File NUOVI inserimenti da elaborare per l'import incrementale : ");
				string fileNameDel = ChiediFileIngresso("File CANCELLAZIONI da elaborare per l'import incrementale : ");

				Console.WriteLine();
				Console.WriteLine("Export incrementale veicoli non revisionati");
				Console.WriteLine("  file inserimenti = {0}", fileNameIns);
				Console.WriteLine("  file cancellazioni = {0}", fileNameDel);
				Console.WriteLine("  file prodotto = {0}", Path.ChangeExtension(fileName, ".zip"));
				Console.WriteLine("  trasferimento file al server: {0}", trasferisciIlFile ? "si" : "no");

				ChiediConferma();

				Console.Write("Lettura dati in corso...");
				ExportIncrementaleA2(fileNameIns, fileNameDel, fileName);
				Console.WriteLine();
			}
			break;

		}

		Console.Write("Creazione del file .zip in corso....");
		string path = Path.GetDirectoryName(fileName);
		string fileZippedWithPath = U.ZipSingleFile(fileName, path);
		File.Delete(fileName);
		Console.WriteLine();

		if (trasferisciIlFile)
		{
			Console.Write("Trasferimento del file al server remoto in corso....");
			using (FtpClientLib.FTPClient c = new FtpClientLib.FTPClient())
			{
				c.RemoteHost = ConfigurationManager.AppSettings["FTP_Host"];
				c.RemoteUser = ConfigurationManager.AppSettings["FTP_User"];
				c.RemotePass = ConfigurationManager.AppSettings["FTP_Pass"];
				c.RemotePath = ConfigurationManager.AppSettings["FTP_Path"];

				c.UploadEvent += delegate { Console.Write("."); };
				c.login();
				c.setBinaryMode(true);
				c.upload(fileZippedWithPath);
			}
			Console.WriteLine();
		}

		{
			using (Stream ss = File.OpenWrite(fileNameUltimaEsecuzione))
			{
				XmlSerializer xs = new XmlSerializer(typeof(UltimaLettura));
				xs.Serialize(ss, ultimaElaborazione);
			}
		}

		Console.WriteLine("Elaborazione terminata con successo");
		Environment.Exit(0);
	}

	DateTime ChiediDataInizio()
	{
		Console.Write("Export dalla data: ");

		for (; ; )
		{
			DateTime r;
			bool ok = DateTime.TryParse(Console.ReadLine(), out r);
			if (ok)
				return r;

			Console.WriteLine("Data in formato non corretto.");
			Console.WriteLine("Formati accettati:  GG/MM/AAAA oppure GG/MM/AAAA HH:MM");
		}
	}

	string ChiediFileIngresso(string s)
	{
		Console.Write(s);

		for (; ; )
		{
			string r = Console.ReadLine();
			if (r == null) r = "";
			r = r.Trim();

			if (File.Exists(r))
				return r;

			Console.WriteLine("Il file {0} non esiste.", r);
			Console.Write(s);
		}
	}


	void ChiediConferma()
	{
		string sn;
		do
		{
			Console.Write("Vuoi procedere ? (S/N) ");
			sn = Console.ReadLine();
		} while (!(sn == "S" || sn == "N"));
		if (sn == "N") Environment.Exit(1);
	}

	bool ChiediConfermaTrasferimentoFTP()
	{
		string sn;
		do
		{
			Console.Write("Vuoi trasferire il file al server FTP ? (S/N) ");
			sn = Console.ReadLine();
		} while (!(sn == "S" || sn == "N"));
		return (sn == "S") ? true : false;
	}


	string ConnectionString
	{
		get
		{
			// Get the application configuration file.
			ConnectionStringsSection sett = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).ConnectionStrings;
			ConnectionStringSettings cs = sett.ConnectionStrings["DbCEPS"];
			return cs.ConnectionString;
		}
	}
	string ProviderName
	{
		get
		{
			// Get the application configuration file.
			ConnectionStringsSection sett = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).ConnectionStrings;
			ConnectionStringSettings cs = sett.ConnectionStrings["DbCEPS"];
			return cs.ProviderName;
		}
	}

	void Incr(char[] g)
	{
		for (int i = g.Length - 1; i >= 0; i--)
		{
			if (g[i] >= '0' && g[i] <= '9')
			{
				if (g[i] == '9')
				{
					g[i] = '0';
				}
				else
				{
					g[i] = (char)(g[i] + 1);
					break;
				}
			}
			else
			{
				if (g[i] == 'Z')
				{
					g[i] = 'A';
				}
				else
				{
					g[i] = (char)(g[i] + 1);
					break;
				}
			}
		}
	}

	void ExportMassivoPerProva(string fileName, UltimaLettura ultimaElaborazione)
	{
		DateTime tsNow = DateTime.Now;

		try
		{
			//using (XmlWriterCEPS xw = new XmlWriterCEPS(fileName))
			using (StreamWriter fs = File.CreateText(fileName))
			{
				int n = 0;

				char[] t = new char[7];
				t[0] = 'A';
				t[1] = 'A';
				t[2] = '0';
				t[3] = '0';
				t[4] = '0';
				t[5] = 'A';
				t[6] = 'T';

				for (int i = 0; i < 1024 * 1024 * 4; i++)
				{
					string targa = string.Format("{0}{1}{2}{3}{4}{5}{6}", t[0], t[1], t[2], t[3], t[4], t[5], t[6]);
					Incr(t);

					Record R = new Record();
					R.EnumTipoLTS = "A1";
					R.TipoOperazione = "ins";

					R.TabTarga = targa;
					R.TabTelaio = "";
					R.TabDataFurto = tsNow;
					R.TabFabbrica = "";
					R.TabModello = "";
					R.TabTipoVeicolo = "A";
					R.TabTipoDenuncia = "";
					R.TabCodiceUfficio = "";
					R.TabUfficio = "";
					R.TabTargaAntPost = "";
					R.TabIndice = "";
					R.TabNazionalita = "I";
					R.TabDataInsert = tsNow;

					//xw.Add(R);

					//fs.Write(targa);
					//fs.Write("|");
					//fs.Write("I");
					//fs.Write("|");
					//fs.Write(tsNow.AddYears(1).ToString(@"dd/MM/yyyy HH\:mm\:ss"));
					//fs.Write("|");
					//fs.Write(tsNow.ToString(@"dd/MM/yyyy HH\:mm\:ss"));
					//fs.Write("|");
					//fs.WriteLine("N");



					fs.Write("1 ");
					fs.Write(targa);
					fs.Write(" ");
					fs.Write("I");
					fs.Write(" ");
					fs.Write(tsNow.AddYears(1).ToString(@"dd/MM/yyyy "));
					fs.Write(" ");
					fs.Write(tsNow.ToString(@"dd/MM/yyyy "));
					fs.Write(" ");
					fs.WriteLine("Nota");




					if (++n % 1024 == 0) Console.Write(".");
				}
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
			Environment.Exit(1);
		}
	}

	void ExportMassivoA1(string fileName, UltimaLettura ultimaElaborazione)
	{
		string c = @"
			select 
			'A1'                 as EnumTipoLTS,
			'ins'                as TipoOperazione,
			Tab_Targa            as TabTarga,
			Tab_Telaio           as TabTelaio,
			Tab_Data_Furto       as TabDataFurto,
			Tab_Fabbrica         as TabFabbrica,
			Tab_Modello          as TabModello,
			Tab_Tipo_Veicolo     as TabTipoVeicolo, 
			Tab_Tipo_Denuncia    as TabTipoDenuncia,
			Tab_Codice_Ufficio   as TabCodiceUfficio,
			Tab_Ufficio          as TabUfficio,
			Tab_Targa_Ant_Post   as TabTargaAntPost,
			Tab_Indice           as TabIndice,
			Tab_Nazionalita      as TabNazionalita,
			Tab_Data_Insert      as TabDataInsert
			from t_targherubate
			where 
			    Tab_Targa_Ant_Post = 'POST'
			and Tab_Data_Insert is not null
			order by Tab_Data_Insert asc
		";


		try
		{
			using (XmlWriterCEPS xw = new XmlWriterCEPS(fileName))
			{
				int n = 0;
				foreach (Record rd in Query<Record>(c, null, null))
				{
					xw.Add(rd);
					if (++n % 1024 == 0) Console.Write(".");
				}

				if (xw.UltimaDataInsert.HasValue)
					ultimaElaborazione.ExportMassivo_TargheRubate = xw.UltimaDataInsert.Value;

			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
			Environment.Exit(1);
		}

	}

//    /// <summary>
//    /// per ora non si conoscono le tabelle per l'A2 !
//    /// </summary>
//    /// <param name="fileName"></param>
//    /// <param name="dal"></param>
//    void ExportIncrementaleA2(string fileName, DateTime dal, UltimaLettura ultimaElaborazione)
//    {
//        string c = @"
//		select 
//		'A2'                 as EnumTipoLTS,
//		'ins'                as TipoOperazione,
//
//		Tab_Targa            as TabTarga,
//		Tab_Telaio           as TabTelaio,
//		Tab_Data_Furto       as TabDataFurto,
//		Tab_Fabbrica         as TabFabbrica,
//		Tab_Modello          as TabModello,
//		Tab_Tipo_Veicolo     as TabTipoVeicolo, 
//		Tab_Tipo_Denuncia    as TabTipoDenuncia,
//		Tab_Codice_Ufficio   as TabCodiceUfficio,
//		Tab_Ufficio          as TabUfficio,
//		Tab_Targa_Ant_Post   as TabTargaAntPost,
//		Tab_Indice           as TabIndice,
//		Tab_Nazionalita      as TabNazionalita,
//		Tab_Data_Insert      as TabDataInsert
//		from dual
//		";

//        try
//        {
//            using (XmlWriterCEPS xw = new XmlWriterCEPS(fileName))
//            {
//                int n = 0;
//                foreach (Record rd in Query<Record>(c, "p_Tab_Data_Insert", dal))
//                {
//                    xw.Add(rd);
//                    if (++n % 1024 == 0) Console.Write(".");
//                }

//                if (xw.UltimaDataInsert.HasValue)
//                    ultimaElaborazione.ExportIncrementale_TargheNonRevisionate = xw.UltimaDataInsert.Value;
//            }
//        }
//        catch (Exception ex)
//        {
//            Console.WriteLine(ex.Message);
//            Environment.Exit(1);
//        }
//    }

	/// <summary>
	/// Export targhe rubate A1
	/// </summary>
	/// <param name="fileName"></param>
	/// <param name="dal"></param>
	void ExportIncrementaleA1(string fileName, DateTime dal, UltimaLettura ultimaElaborazione)
	{
		string c = @"
		select * from
		(
			select 
			'A1'                 as EnumTipoLTS,
			'ins'                as TipoOperazione,
			Tab_Targa            as TabTarga,
			Tab_Telaio           as TabTelaio,
			Tab_Data_Furto       as TabDataFurto,
			Tab_Fabbrica         as TabFabbrica,
			Tab_Modello          as TabModello,
			Tab_Tipo_Veicolo     as TabTipoVeicolo, 
			Tab_Tipo_Denuncia    as TabTipoDenuncia,
			Tab_Codice_Ufficio   as TabCodiceUfficio,
			Tab_Ufficio          as TabUfficio,
			Tab_Targa_Ant_Post   as TabTargaAntPost,
			Tab_Indice           as TabIndice,
			Tab_Nazionalita      as TabNazionalita,
			Tab_Data_Insert      as TabDataInsert
			from t_targherubate
			where 
			    Tab_Targa_Ant_Post = 'POST'
			and Tab_Data_Insert >= :p_Tab_Data_Insert
			and Tab_Data_Insert is not null

			union

			select 
			'A1'                 as EnumTipoLTS,
			'del'                as TipoOperazione,
			Tab_Targa_c          as TabTarga,
			Tab_Telaio_c         as TabTelaio,
			Tab_Data_Furto_c     as TabDataFurto,
			Tab_Fabbrica_c       as TabFabbrica,
			Tab_Modello_c        as TabModello,
			Tab_Tipo_Veicolo_c   as TabTipoVeicolo, 
			Tab_Tipo_Denuncia_c  as TabTipoDenuncia,
			Tab_Codice_Ufficio_c as TabCodiceUfficio,
			Tab_Ufficio_c        as TabUfficio,
			Tab_Targa_Ant_Post_c as TabTargaAntPost,
			Tab_Indice_c         as TabIndice,
			Tab_Nazionalita_c    as TabNazionalita,
			Tab_Data_Insert_c    as TabDataInsert
			from t_targherubate_cancellate
			where 
			    Tab_Targa_Ant_Post_c = 'POST'
			and Tab_Data_Insert_c >= :p_Tab_Data_Insert
			and Tab_Data_Insert_c is not null

		) T
		order by T.TabDataInsert asc
		";

		try
		{
			int n = 0;
			using (XmlWriterCEPS xw = new XmlWriterCEPS(fileName))
			{
				foreach (Record rd in Query<Record>(c, "p_Tab_Data_Insert", dal))
				{
					xw.Add(rd);
					if (++n % 1024 == 0) Console.Write(".");
				}


				if (xw.UltimaDataInsert.HasValue)
					ultimaElaborazione.ExportIncrementale_TargheRubate = xw.UltimaDataInsert.Value;
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
			Environment.Exit(1);
		}
	}

	void ExportMassivoA2(string fileNameIn, string fileNameOut)
	{

		try
		{
			using (XmlWriterCEPS xw = new XmlWriterCEPS(fileNameOut))
			{
				LeggiFileA2(fileNameIn, xw, "ins");
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
			Environment.Exit(1);
		}
	}

	void ExportIncrementaleA2(string fileNameInA2Ins, string fileNameInA2Del, string fileNameOut)
	{
		try
		{
			using (XmlWriterCEPS xw = new XmlWriterCEPS(fileNameOut))
			{
				LeggiFileA2(fileNameInA2Ins, xw, "ins");
				LeggiFileA2(fileNameInA2Del, xw, "del");
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
			Environment.Exit(1);
		}
	}


	private static void LeggiFileA2(string fileNameIn, XmlWriterCEPS xw, string insDel)
	{
		Regex rg = new Regex("^[A-Z0-9]{7,8}$");
		int n = 0;
		int nLine = 0;
		DateTime tsNow = DateTime.Now;
		using (StreamReader sr = File.OpenText(fileNameIn))
		{
			for (; ; )
			{
				string ln = sr.ReadLine();
				if (ln == null) break;
				if (ln.Length == 0) continue;
				nLine += 1;


				char tipo_veicolo = ln[0];
				string targa = ln.Substring(1, 8).Trim();
				string provincia = ln.Substring(9);

				if (!(tipo_veicolo == 'A' || tipo_veicolo == 'M'))
				{
					Console.WriteLine("Il record alla riga {0} non inizia per A o per M.", nLine);
					Environment.Exit(1);
				}

				bool ok = rg.IsMatch(targa);
				if (!ok)
				{
					Console.WriteLine("Il record alla riga {0} contiene una targa non corretta.", nLine);
					Environment.Exit(1);
				}

				Record R = new Record();
				R.EnumTipoLTS = "A2";
				R.TipoOperazione = insDel;

				R.TabTarga = targa;
				R.TabTelaio = "";
				R.TabDataFurto = tsNow;
				R.TabFabbrica = "";
				R.TabModello = "";
				R.TabTipoVeicolo = tipo_veicolo == 'A' ? "A" : "M";
				R.TabTipoDenuncia = "";
				R.TabCodiceUfficio = "";
				R.TabUfficio = "";
				R.TabTargaAntPost = "";
				R.TabIndice = "";
				R.TabNazionalita = "I";
				R.TabDataInsert = tsNow;

				xw.Add(R);

				if (++n % 1024 == 0) Console.Write(".");
			}
		}
	}


	IEnumerable<T> Query<T>(string commandText, string parName, DateTime? dd)
		where T : new()
	{
		DbProviderFactory dbF = DbProviderFactories.GetFactory(this.ProviderName);
		using (DbConnection cn = dbF.CreateConnection())
		{
			cn.ConnectionString = this.ConnectionString;
			cn.Open();

			DbCommand cmd = cn.CreateCommand();
			cmd.CommandText = commandText;
			cmd.CommandType = CommandType.Text;

			if (parName != null)
			{
				DbParameter p = dbF.CreateParameter();
				p.Direction = ParameterDirection.Input;
				p.ParameterName = parName;
				p.Value = dd.Value;
				cmd.Parameters.Add(p);
			}

			using (DbDataReader rd = cmd.ExecuteReader())
			{
				DynamicRecordBinder<T> b = new DynamicRecordBinder<T>();
				b.ColumnBinder(rd);

				while (rd.Read())
				{
					T t = new T();

					b.Binder(rd, t);

					yield return t;
				}
			}
		}
	}

}

class Record
{
	#region dati
	string _TipoOperazione;
	string _TabTarga;
	string _TabTelaio;
	DateTime _TabDataFurto;
	string _TabFabbrica;
	string _TabModello;
	string _TabTipoVeicolo;
	string _TabTipoDenuncia;
	string _TabCodiceUfficio;
	string _TabUfficio;
	string _TabTargaAntPost;
	string _TabIndice;
	string _TabNazionalita;
	DateTime _TabDataInsert;

	string _EnumTipoLTS;
	#endregion

	public string TipoOperazione { get { return _TipoOperazione; } set { _TipoOperazione = value; } }
	public string EnumTipoLTS { get { return _EnumTipoLTS; } set { _EnumTipoLTS = value; } }

	public string TabTarga { get { return _TabTarga; } set { _TabTarga = value; } }
	public string TabTelaio { get { return _TabTelaio; } set { _TabTelaio = value; } }
	public DateTime TabDataFurto { get { return _TabDataFurto; } set { _TabDataFurto = value; } }
	public string TabFabbrica { get { return _TabFabbrica; } set { _TabFabbrica = value; } }
	public string TabModello { get { return _TabModello; } set { _TabModello = value; } }
	public string TabTipoVeicolo { get { return _TabTipoVeicolo; } set { _TabTipoVeicolo = value; } }
	public string TabTipoDenuncia { get { return _TabTipoDenuncia; } set { _TabTipoDenuncia = value; } }
	public string TabCodiceUfficio { get { return _TabCodiceUfficio; } set { _TabCodiceUfficio = value; } }
	public string TabUfficio { get { return _TabUfficio; } set { _TabUfficio = value; } }
	public string TabTargaAntPost { get { return _TabTargaAntPost; } set { _TabTargaAntPost = value; } }
	public string TabIndice { get { return _TabIndice; } set { _TabIndice = value; } }
	public string TabNazionalita { get { return _TabNazionalita; } set { _TabNazionalita = value; } }
	public DateTime TabDataInsert { get { return _TabDataInsert; } set { _TabDataInsert = value; } }
}


class XmlWriterCEPS : IDisposable
{
	XmlWriter _xw;
	DateTime? _ultimaDataInsert;

	public XmlWriterCEPS(string fileName)
	{
		_ultimaDataInsert = null;

		XmlWriterSettings ws = new XmlWriterSettings();
		ws.Indent = true;
		ws.IndentChars = "\t";
		_xw = XmlWriter.Create(fileName, ws);

		_xw.WriteStartDocument();
		_xw.WriteStartElement("Radice", "urn:ImportLTS");
		_xw.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");
		_xw.WriteAttributeString("xsi", "schemaLocation", null, "urn:ImportLTS ImportLTS.xsd");
	}

	public DateTime? UltimaDataInsert
	{
		get { return _ultimaDataInsert; }
	}

	public void Close()
	{
		if (_xw != null)
		{
			_xw.WriteEndElement();
			_xw.WriteEndDocument();
			_xw.Close();
			_xw = null;
		}
	}

	void IDisposable.Dispose()
	{
		Close();
	}


	public void Add(Record r)
	{
		_xw.WriteStartElement("Record");
		{
			_xw.WriteAttributeString("EnumTipoLTS", r.EnumTipoLTS);
			_xw.WriteAttributeString("TipoOperazione", r.TipoOperazione);

			WriteElement("TabTarga", r.TabTarga);
			WriteElement("TabTelaio", r.TabTelaio);

			WriteElement("TabDataFurto", XmlConvert.ToString(r.TabDataFurto, "yyyy-MM-ddTHH:mm:ss"));

			WriteElement("TabFabbrica", r.TabFabbrica);
			WriteElement("TabModello", r.TabModello);
			WriteElement("TabTipoVeicolo", r.TabTipoVeicolo);
			WriteElement("TabTipoDenuncia", r.TabTipoDenuncia);
			WriteElement("TabCodiceUfficio", r.TabCodiceUfficio);
			WriteElement("TabUfficio", r.TabUfficio);
			WriteElement("TabTargaAntPost", r.TabTargaAntPost);
			WriteElement("TabIndice", r.TabIndice);
			WriteElement("TabNazionalita", r.TabNazionalita);

			WriteElement("TabDataInsert", XmlConvert.ToString(r.TabDataInsert, "yyyy-MM-ddTHH:mm:ss"));
		}
		_xw.WriteEndElement();

		if (!_ultimaDataInsert.HasValue)
			_ultimaDataInsert = r.TabDataInsert;
		else if (r.TabDataInsert > _ultimaDataInsert.Value)
			_ultimaDataInsert = r.TabDataInsert;
	}

	public void WriteElement(string name, string value)
	{
		if (value == null) value = string.Empty;
		value = value.Trim();
		_xw.WriteElementString(name, value);
	}

}

[Serializable]
public class UltimaLettura
{
	public DateTime? ExportIncrementale_TargheRubate;
	public DateTime? ExportIncrementale_TargheNonRevisionate;
	public DateTime? ExportMassivo_TargheRubate;
	public DateTime? ExportMassivo_TargheNonRevisionate;
}
