using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using ZipLib = ICSharpCode.SharpZipLib;


public static partial class U
{
	/// <summary>
	/// Zippa il file specificato in "fileToZip" producendo
	/// il file .zip nella directory specificata in "outputDir".
	/// Se il file in ingresso e` name.txt il file .zip sara` name.zip
	/// </summary>
	/// <param name="fileToZip">file da zippare - puo` avere un path completo</param>
	/// <param name="outputDir">directory in cui si scrive il file zippato</param>
	/// <returns>il file zippato completo di path</returns>
	public static string ZipSingleFile(string fileToZip, string outputDir)
	{
		if (outputDir == "") outputDir = ".";

		if (fileToZip == null)
			throw new ArgumentNullException("fileToZip");
		if (outputDir == null)
			throw new ArgumentNullException("outputDir");

		if (!Directory.Exists(outputDir))
			throw new ArgumentException("directory do not exists.", "outputDir");

		string fileZipOut = Path.Combine(outputDir, Path.GetFileNameWithoutExtension(fileToZip) + ".zip");

		ZipLib.Checksums.Crc32 crc = new ZipLib.Checksums.Crc32();
		using (ZipLib.Zip.ZipOutputStream s = new ZipLib.Zip.ZipOutputStream(File.Create(fileZipOut)))
		{
			s.SetLevel(6); // 0 - store only to 9 - means best compression

			using (FileStream fs = File.OpenRead(fileToZip))
			{
				byte[] buffer = new byte[fs.Length];

				int rd = 0;
				while (rd < fs.Length)
					rd += fs.Read(buffer, rd, buffer.Length - rd);

				string fileNameNoPath = Path.GetFileName(fileToZip);

				ZipLib.Zip.ZipEntry ze = new ZipLib.Zip.ZipEntry(fileNameNoPath);
				ze.DateTime = DateTime.Now;
				ze.Size = fs.Length;
				fs.Close();

				crc.Reset();
				crc.Update(buffer);
				ze.Crc = crc.Value;

				s.PutNextEntry(ze);

				s.Write(buffer, 0, buffer.Length);
			}

			s.Finish();
			s.Close();
		}
		return fileZipOut;
	}

	/// <summary>
	/// Unizppa il file specificato in "fileNameZipWithPath" e posiziona il primo 
	/// file entro l'archivio nella directory "outputDir".
	/// Eventuali path associati al file da unzippare sono ignorati.
	/// Ritorna il path completo del file unzippato.
	/// </summary>
	/// <param name="fileNameZipWithPath"></param>
	/// <param name="outputDir">directory in cui scrivere il file</param>
	/// <returns>il path completo del file unzippato</returns>
	public static string UnzipSingleFile(string fileNameZipWithPath, string outputDir)
	{
		if (fileNameZipWithPath == null)
			throw new ArgumentNullException("fileNameZipWithPath");
		if (outputDir == null)
			throw new ArgumentNullException("outputDir");

		if (!Directory.Exists(outputDir))
			throw new ArgumentException("directory do not exists.", "outputDir");

		using (ZipLib.Zip.ZipInputStream s = new ZipLib.Zip.ZipInputStream(File.OpenRead(fileNameZipWithPath)))
		{
			ZipLib.Zip.ZipEntry theEntry = null;
			while ((theEntry = s.GetNextEntry()) != null)
			{
				string fileNameNoPath = Path.GetFileName(theEntry.Name);
				string fileNameWithPath = Path.Combine(outputDir, fileNameNoPath);

				if (fileNameNoPath != String.Empty)
				{
					using (FileStream streamWriter = File.Create(fileNameWithPath))
					{
						int size = 64 * 1024;
						byte[] data = new byte[size];
						while (true)
						{
							size = s.Read(data, 0, data.Length);
							if (size <= 0)
								break;
							streamWriter.Write(data, 0, size);
						}
					}

					return fileNameWithPath;
				}
			}
		}

		return null;
	}

}
