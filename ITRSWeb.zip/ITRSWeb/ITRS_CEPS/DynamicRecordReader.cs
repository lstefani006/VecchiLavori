using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Data;
using System.Diagnostics;
using System.Globalization;

/// <summary>
/// Classe per valorizzare i campi di un record di tipo T da un OracleDataReader.
/// I campi da assegnare devono essere proprita` pubbliche.
/// Tutte le colonne della query devono essere presenti com property nel record T.
/// Il record T puo` contenere altre proprieta` o metodi.
/// Il binding per ogni colonna viene effettuatto in maniera case insensitive.
/// Il binding presume una corrispondenza tra i tipi ritornati dall'OracleDataReader
/// e i tipi delle property. Se non vi e` stretta corrispondenza si chiama Convert.To*.
/// Si puo` gestire l'evento <para>BindProperty</para> per effettuare, per colonna 
/// un binding custom. Valizzare <code>e.Done = true</code> nell'evento per evitare 
/// che il <c>ColumnBinder</c> esegua nuovamente il binding.
/// </summary>
/// <typeparam name="T"></typeparam>
public class DynamicRecordBinder<T>
{
	readonly object[] _dummy = new object[0];
	List<BindableProperty> _pi;

	class BindableProperty
	{
		//static object[] _args = new object[0];

		public BindableProperty(PropertyInfo pi, string dbColName)
		{
			this._pi = pi;
			Type pt = pi.PropertyType;

			this._dbColName = dbColName;

			if (pt == typeof(string) || pt == typeof(byte[]))
			{
				this._pt = pt;
				this._isNullable = true;
				this._isGenericType = false;
				this._isEnum = false;
			}
			else if (pt.IsGenericType && pt.GetGenericTypeDefinition() == typeof(Nullable<>))
			{
				this._pt = pi.PropertyType.GetGenericArguments()[0];
				this._isNullable = true;
				this._isGenericType = true;
				this._isEnum = this._pt.IsEnum;
			}
			else
			{
				this._pt = pt;
				this._isNullable = false;
				this._isGenericType = false;
				this._isEnum = pt.IsEnum;
			}
		}


		public string Name { get { return this._pi.Name; } }
		public string DbColName { get { return this._dbColName; } }
		public string TypeName { get { return this._pi.PropertyType.Name; } }

		public void SetNull(object target)
		{
			if (_isNullable == false)
				throw new ArgumentException("tipo non nullabile", Name);

			_pi.SetValue(target, null, null);
		}

		public void SetNotNull(object target, object value)
		{
			if (this._isEnum == false)
			{
				// se i tipi sono diversi faccio la conversione di tipo automatica
				if (value.GetType() != this._pt)
					value = Convert.ChangeType(value, this._pt, CultureInfo.InvariantCulture);
			}
			else
			{
				value = Enum.Parse(this._pt, (string)value);
			}

			_pi.SetValue(target, value, null);
		}

		public override string ToString()
		{
			return string.Format("BindableProperty Name={0} dbColName={1} isEnum={2} isNullable={3} isGenericType={4} propertyType={5}",
				this.Name,
				this.DbColName,
				this._isEnum,
				this._isNullable,
				this._isGenericType,
				this._pt.ToString());
		}



		readonly PropertyInfo _pi;
		/// <summary>
		/// e` un Enum o un Nullable(Enum)
		/// </summary>
		readonly bool _isEnum;
		/// <summary>
		/// e` un Nullable(T) o string o byte[]
		/// </summary>
		readonly bool _isNullable;
		/// <summary>
		/// e` un Nullable(T) compreso Nullable(Enum)
		/// </summary>
		readonly bool _isGenericType;
		readonly string _dbColName;
		/// <summary>
		/// tipo della proprieta` se _isNullable e` false
		/// altrimenti ritorna il tipo T di Nullable(T)
		/// </summary>
		readonly Type _pt;
	}

	public void ColumnBinder(IDataReader rd)
	{
		_pi = new List<BindableProperty>(rd.FieldCount);

		for (int c = 0; c < rd.FieldCount; ++c)
		{
			string dbColName = rd.GetName(c);

			PropertyInfo p = typeof(T).GetProperty(dbColName, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

			if (p == null)
			{
				string s = "Property " + dbColName + " non trovata in " + typeof(T).Name;
				Debug.Assert(p != null, s);
				throw new Exception();
			}
			BindableProperty bp = new BindableProperty(p, dbColName);

			_pi.Add(bp);
		}
	}

	public void Binder(IDataReader rd, T record)
	{
		for (int c = 0; c < rd.FieldCount; ++c)
		{
			try
			{
				if (rd.IsDBNull(c))
					this.SetNull(record, c, _pi[c].DbColName);
				else
					this.SetNotNull(record, c, _pi[c].DbColName, rd[c]);
			}
			catch (Exception ex)
			{
				string s = string.Format(
					"Errore assegnando la property {0} della classe {1}. ", _pi[c].ToString(), typeof(T).Name);
				s += "Tipo letto dal DB " + rd[c].GetType().Name + ".";

				throw new Exception(s, ex);
			}
		}
	}


	public class BindPropertyEventArgs
	{
		public BindPropertyEventArgs(T record, int c, string dbColName, object v)
		{
			this.Record = record;
			this.ColumnIndex = c;
			this.DbColName = dbColName;
			this.Value = v;
			this.Done = false;
		}
		readonly public T Record;
		readonly public int ColumnIndex;
		readonly public object Value;
		readonly public string DbColName;
		public bool Done;
	}
	public delegate void BindPropertyDelegate(object sender, BindPropertyEventArgs e);
	public event BindPropertyDelegate BindProperty;

	protected virtual void SetNull(T record, int c, string dbColName)
	{
		if (BindProperty != null)
		{
			BindPropertyEventArgs e = new BindPropertyEventArgs(record, c, dbColName, DBNull.Value);
			BindProperty(this, e);
			if (e.Done == false)
				_pi[c].SetNull(record);
		}
		else
		{
			_pi[c].SetNull(record);
		}


	}

	protected virtual void SetNotNull(T record, int c, string dbColName, object v)
	{
		if (BindProperty != null)
		{
			BindPropertyEventArgs e = new BindPropertyEventArgs(record, c, dbColName, v);
			BindProperty(this, e);
			if (e.Done == false)
				_pi[c].SetNotNull(record, v);
		}
		else
		{
			_pi[c].SetNotNull(record, v);
		}
	}
}
