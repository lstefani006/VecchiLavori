using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

using ITRS_BL;

public partial class Diagnostica_DiagnosticaTelecamereStorica : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		if (!IsCallback)
		{
			BLCacher.FillFromC2P(this.ddlC2P, new ListItem("Tutti", "-1"));
			rpDiaCamere.ItemDataBound += rpDiaCamere_ItemDataBound;
		}
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsCallback)
		{
			if (!IsPostBack)
			{
				this.edit_Di.Text = DateTime.Now.Date.ToShortDateString();
				this.edit_Df.Text = DateTime.Now.Date.ToShortDateString();
			}

			RegisterClientId("DIASTO", this.edit_Di, this.edit_Df);
		}
	}


	void rpDiaCamere_ItemDataBound(object sender, RepeaterItemEventArgs e)
	{
		if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
		{
			C2PDiagnosticaStorica ds = (C2PDiagnosticaStorica)e.Item.DataItem;

			SettaColore(ds, e.Item, "DIAG_CS_ALIVE");
			SettaColore(ds, e.Item, "DIAG_CD_ALIVE");
			SettaColore(ds, e.Item, "DIAG_CE_ALIVE");
			SettaColore(ds, e.Item, "DIAG_CU_ALIVE");
		}
	}

	void SettaColore(C2PDiagnosticaStorica eee, RepeaterItem ri, string prop)
	{
		SettaColore(eee, ri, prop, true);
	}
	void SettaColore(C2PDiagnosticaStorica eee, RepeaterItem ri, string prop, bool b)
	{
		HtmlTableCell td = ri.FindControl(prop) as HtmlTableCell;
		if (td != null)
		{
			object tt = eee.GetType().GetProperty(prop).GetValue(eee, null);

			try
			{
				if (b)
				{
					if (Convert.ToString(tt).ToLower() == "false")
					{
						td.BgColor = "Red";
						td.InnerText = "Fail";
					}
					else
					{
						//td.BgColor = "Green";
						td.InnerText = "OK";
					}
				}
			}
			catch
			{
			}

			td.Align = "center";
		}
	}


	protected string W(object e)
	{
		if (e == null) return "?";
		return e.ToString();
	}

	protected void btnRicerca_Click(object sender, EventArgs e)
	{
		using (BLC2P bl = new BLC2P())
		{
			try
			{
				int IdC2P = Int32.Parse(this.ddlC2P.SelectedValue);

				DateTime di = DateTime.Parse(edit_Di.Text);
				DateTime df = DateTime.Parse(edit_Df.Text);

				if (di > df)
				{
					lbl_WriteError(lblError, "La data di fine ricerca non deve essere minore della data di inizio ricerca");
					return;
				}

				df = df.AddDays(1);

				List<C2PDiagnosticaStorica> rr;
				if (IdC2P < 0)
					rr = bl.GetListaDiagnosticaStorica(null, di, df);
				else
					rr = bl.GetListaDiagnosticaStorica(IdC2P, di, df);

				this.rpDiaCamere.DataSource = rr;
				this.rpDiaCamere.DataBind();

			}
			catch (Exception ex)
			{
				lbl_WriteError(lblError, ex.Message);
			}
		}
	}
}
