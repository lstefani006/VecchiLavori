using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ITRS_BL;
using System.Collections.Generic;

public partial class Diagnostica_ResetC2P : System.Web.UI.UserControl
{
	public static string strDescrizione = "Descrizione";

	protected void Page_Init(object sender, EventArgs e)
	{
		if (!Page.IsCallback)
		{
			using (BLLTSImport bl2 = new BLLTSImport())
			{
				List<BLLTSImport.AttivazioneA2> r = bl2.GetListaAttivazioneA2();

				rptC2P.DataSource = r;
				rptC2P.DataBind();
				hfC2P.Value = r[0].IdC2P.ToString();
			}
		}
	}


	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			UpdateDataFromC2P();
		}
	}

	///////////////////////////////////////////////////////////////////////////

	protected void rptC2P_ItemCommand(object source, RepeaterCommandEventArgs e)
	{
		_idC2P = short.Parse(e.CommandArgument.ToString());
		hfC2P.Value = _idC2P.ToString();

		UpdateDataFromC2P();
	}


	protected void attiva_Click(object sender, EventArgs e)
	{
		this.Page.Validate();
		if (!this.Page.IsValid)
		{
			return;
		}

		try
		{
			_idC2P = short.Parse(hfC2P.Value);

			using (BLLTSImport bl2 = new BLLTSImport())
			{
				BLLTSImport.AttivazioneA2 r = new BLLTSImport.AttivazioneA2();
				r.IdC2P = _idC2P;
				r.DataOraInizioAttivazione = DateTime.Parse(di.Text);
				r.DataOraFineAttivazione = DateTime.Parse(df.Text);

				if (r.DataOraInizioAttivazione > r.DataOraFineAttivazione)
				{
					DateTime ? t = r.DataOraInizioAttivazione;
					r.DataOraInizioAttivazione = r.DataOraFineAttivazione;
					r.DataOraFineAttivazione = t;
				}

				string v = "";
				v += ckTipoVeicoli.Items.FindByValue("A").Selected ? "A" : "";
				v += ckTipoVeicoli.Items.FindByValue("M").Selected ? "M" : "";
				r.TipoVeicolo = v;

				v = "";
				v += ckCorsieAttivate.Items.FindByValue("E").Selected ? "E" : "";
				v += ckCorsieAttivate.Items.FindByValue("U").Selected ? "U" : "";
				v += ckCorsieAttivate.Items.FindByValue("S").Selected ? "S" : "";
				v += ckCorsieAttivate.Items.FindByValue("D").Selected ? "D" : "";
				r.CorsieAbilitate = v;

				string[] aa = mg.Text.Split(':');
				int m = int.Parse(aa[0]);
				int g = int.Parse(aa[1]);
				r.GiorniTolleranzaRevisione = g + m * 30;

				bl2.AggiornaAttivazioneA2(this.Page.User.Identity.Name, r);
			}

			UpdateDataFromC2P();
		}
		catch (Exception ex)
		{
			lblError.Text = "Errore durante l'attivazione! (" + ex.Message + ")";
		}
	}
	protected void disattiva_Click(object sender, EventArgs e)
	{
		try
		{
			_idC2P = short.Parse(hfC2P.Value);

			using (BLLTSImport bl2 = new BLLTSImport())
			{
				bl2.AggiornaAttivazioneA2(this.Page.User.Identity.Name, _idC2P, null, null, null, null, null, null);
			}

			UpdateDataFromC2P();
		}
		catch (Exception ex)
		{
			lblError.Text = "Errore durante la disattivazione! (" + ex.Message + ")";
		}
	}

	protected short _idC2P;

	private void UpdateDataFromC2P()
	{
		_idC2P = short.Parse(hfC2P.Value);

		using (BLLTSImport bl = new BLLTSImport())
		{
			List<BLLTSImport.AttivazioneA2> lst = bl.GetListaAttivazioneA2();

			foreach (BLLTSImport.AttivazioneA2 r in lst)
			{
				if (r.IdC2P != _idC2P) continue;

				areaDiServizio.InnerText = r.Descrizione;

				if (r.DataOraInizioAttivazione.HasValue)
					di.Text = r.DataOraInizioAttivazione.Value.ToString("g");
				else
					di.Text = "";

				if (r.DataOraFineAttivazione.HasValue)
					df.Text = r.DataOraFineAttivazione.Value.ToString("g");
				else
					df.Text = "";

				if (r.GiorniTolleranzaRevisione.HasValue)
				{
					int v = r.GiorniTolleranzaRevisione.Value;

					mg.Text = string.Format("{0}:{1}", v / 30, v % 30);
				}
				else
					mg.Text = "";


				if (string.IsNullOrEmpty(r.CorsieAbilitate))
					r.CorsieAbilitate = "EUSD";

				ckCorsieAttivate.Items.FindByValue("E").Selected = r.CorsieAbilitate.Contains("E");
				ckCorsieAttivate.Items.FindByValue("S").Selected = r.CorsieAbilitate.Contains("S");
				ckCorsieAttivate.Items.FindByValue("D").Selected = r.CorsieAbilitate.Contains("D");
				ckCorsieAttivate.Items.FindByValue("U").Selected = r.CorsieAbilitate.Contains("U");


				if (string.IsNullOrEmpty(r.TipoVeicolo)) r.TipoVeicolo = "AM";
				ckTipoVeicoli.Items.FindByValue("A").Selected = r.TipoVeicolo.Contains("A");
				ckTipoVeicoli.Items.FindByValue("M").Selected = r.TipoVeicolo.Contains("M");
			}


			rptC2P.DataSource = lst;
			rptC2P.DataBind();

		}
	}
	protected void btnResetC2P_Click(object sender, EventArgs e)
	{
		try
		{
			using (BLLTSImport bl = new BLLTSImport())
			{
				_idC2P = short.Parse(hfC2P.Value);
				bool ignoraA2 = true;
				bl.Reset_A1BC_C2P(PageBase.UserName, _idC2P, ignoraA2);

			}
		}
		catch (Exception ex)
		{
			lblError.Text = "Errore durante il reset A2 ! (" + ex.Message + ")";
		}
	}
	protected void btnResetAllC2P_Click(object sender, EventArgs e)
	{
		try
		{
			using (BLLTSImport bl = new BLLTSImport())
			{
				bool ignoraA2 = true;
				bl.Reset_A1BC_C2P(PageBase.UserName, null, ignoraA2);
			}

		}
		catch (Exception ex)
		{
			lblError.Text = "Errore durante il reset A2 ! (" + ex.Message + ")";
		}
	}
}
