using System;
using System.Data;
using System.Configuration;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using ITRS_BL;

public partial class Diagnostica_DiagnosticaTransiti : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		BLCacher.FillFromC2P(ddlC2P, new ListItem("Tutti", "-1"));
		this.rpDiaTransiti.ItemDataBound += new RepeaterItemEventHandler(rpDiaTransiti_ItemDataBound);
	}


	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			calDataRep.Text = DateTime.Now.Date.ToShortDateString();
		}

		RegisterClientId("ST1", calDataRep);
	}

	public string HHMM(object per)
	{
		decimal periodo = Convert.ToDecimal(per);

		int hh = (int)(periodo / 60);
		int mm = (int)(periodo % 60);

		string s = "";
		if (hh < 10) s += "0" + hh.ToString(); else s += hh.ToString();
		s += ":";
		if (mm < 10) s += "0" + mm.ToString(); else s += mm.ToString();
		return s;
	}


	void rpDiaTransiti_ItemDataBound(object sender, RepeaterItemEventArgs e)
	{
		if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
		{
			DiaTransitiRecord eee = ((DiaTransitiRecord)e.Item.DataItem);

			SettaColore(eee, e.Item, "NumTr");
			SettaColore(eee, e.Item, "NumEv", false);
			SettaColore(eee, e.Item, "NumTr_S");
			SettaColore(eee, e.Item, "NumTr_D");
			SettaColore(eee, e.Item, "NumTr_E");
			SettaColore(eee, e.Item, "NumTr_U");

			SettaColore(eee, e.Item, "NumEv_S", false);
			SettaColore(eee, e.Item, "NumEv_D", false);
			SettaColore(eee, e.Item, "NumEv_E", false);
			SettaColore(eee, e.Item, "NumEv_U", false);
		}
	}
	void SettaColore(DiaTransitiRecord eee, RepeaterItem ri, string prop)
	{
		SettaColore(eee, ri, prop, true);
	}
	void SettaColore(DiaTransitiRecord eee, RepeaterItem ri, string prop, bool b)
	{
		HtmlTableCell td = ri.FindControl(prop) as HtmlTableCell;
		if (td != null)
		{
			object tt = eee.GetType().GetProperty(prop).GetValue(eee, null);
			if (b && Convert.ToDecimal(tt) == 0)
				td.BgColor = "Red";

			td.Align = "right";
		}
	}

	protected void btnRicerca_Click(object sender, EventArgs e)
	{
		DiagnosticaTransitiDataBind();
	}


	private void DiagnosticaTransitiDataBind()
	{
		using (BLC2P c2p = new BLC2P())
		{
			try
			{
				if (this.calDataRep.VisibleDate.HasValue == false)
					return;

				DateTime dt = this.calDataRep.VisibleDate.Value;
				int periodo = Int32.Parse(this.ddlPeriodo.SelectedValue);

				string ordinaPer = this.rbOrdinaPer.SelectedValue;
				int? IdC2P = Int32.Parse(this.ddlC2P.SelectedValue);
				if (IdC2P == -1)
					IdC2P = null;


				List<DiaTransitiRecord> rr = c2p.GetListaTransitiNelGiorno(dt.Date, periodo, IdC2P, ordinaPer);


				if (dt.Date == DateTime.Now.Date)
				{
					DateTime ora = DateTime.Now;
					int minutiMax = ora.Hour * 60 + ora.Minute;
					int minutiMin = (ora.Hour - 6) * 60 + ora.Minute;

					List<int> daRimuovere = new List<int>();
					for (int i = 0; i < rr.Count; ++i)
					{
						if (rr[i].Periodo > minutiMax)
							daRimuovere.Add(i);

						//if (rr[i].Periodo < minutiMin)
						//	daRimuovere.Add(i);
					}
					daRimuovere.Sort();
					for (int i = daRimuovere.Count - 1; i >= 0; --i)
						rr.RemoveAt(daRimuovere[i]);
				}


				rpDiaTransiti.DataSource = rr;
				rpDiaTransiti.DataBind();
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DiagnosticaTransiti.DiagnosticaDataBind");
				lblError.Text = ex.Message;
				lblError.ForeColor = Color.Red;
			}
		}
	}
}
