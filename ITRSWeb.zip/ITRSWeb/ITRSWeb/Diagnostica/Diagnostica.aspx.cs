using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using ITRS_BL;

public partial class Diagnostica_Diagnostica : PageBase
{
	private static readonly string DIAGNOSTIC_OK = "OK";
	private static readonly string DIAGNOSTIC_KO = "Fuori Servizio";

	private static readonly string RED_IMAGE = "~/Images/spia_rossa.gif";
	private static readonly string ORANGE_IMAGE = "~/Images/spia_gialla.gif";
	private static readonly string GREEN_IMAGE = "~/Images/spia_verde.gif";

	private bool IsAdministrator = false;
	private bool _requireNewBind = false;

	protected override void OnInit(EventArgs e)
	{
		base.OnInit(e);

		if (!IsCallback)
		{
			if (Roles.IsUserInRole("DiagnosticaWE"))
				IsAdministrator = true;

			this.LoadComplete += Page_LoadComplete;
			this.Load += Page_Load;
			this.rpDiagnostica.PreRender += Repeater_PreRender;
		}
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsCallback)
		{
			if (!IsAdministrator)
				btnAggiorna.Enabled = false;

			DiagnosticaDataBind();
			_requireNewBind = false;
		}
	}

	// arriva dopo gli eventi dei bottoni ecc ma prima del pre-render
	void Page_LoadComplete(object sender, EventArgs e)
	{
		if (_requireNewBind)
		{
			DiagnosticaDataBind();
			_requireNewBind = false;
		}
	}

	protected void Repeater_PreRender(object sender, EventArgs e)
	{
		foreach (RepeaterItem i in rpDiagnostica.Items)
		{
			//acquisisco l'istanza dei controlli
			HtmlInputCheckBox chkDiag_C2P_VE = i.FindControl("chkDiag_C2P_VE") as HtmlInputCheckBox;
			HtmlInputCheckBox chkDiag_CD_VE = i.FindControl("chkDiag_CD_VE") as HtmlInputCheckBox;
			HtmlInputCheckBox chkDiag_CE_VE = i.FindControl("chkDiag_CE_VE") as HtmlInputCheckBox;
			HtmlInputCheckBox chkDiag_CS_VE = i.FindControl("chkDiag_CS_VE") as HtmlInputCheckBox;
			HtmlInputCheckBox chkDiag_CU_VE = i.FindControl("chkDiag_CU_VE") as HtmlInputCheckBox;
			HtmlImage imgToggle = i.FindControl("imgToggle") as HtmlImage;
			HtmlImage imgGroup = i.FindControl("imgGroup") as HtmlImage;
			HtmlImage imgDiag_CD_Alive = i.FindControl("imgDiag_CD_Alive") as HtmlImage;
			HtmlImage imgDiag_CS_Alive = i.FindControl("imgDiag_CS_Alive") as HtmlImage;
			HtmlImage imgDiag_CE_Alive = i.FindControl("imgDiag_CE_Alive") as HtmlImage;
			HtmlImage imgDiag_CU_Alive = i.FindControl("imgDiag_CU_Alive") as HtmlImage;

			HtmlGenericControl ulHide = i.FindControl("ulHide") as HtmlGenericControl;

			chkDiag_C2P_VE.Attributes.Add("onclick", "javascript:ViewEnableChange(" + string.Format("['{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}']", new object[] { chkDiag_C2P_VE.ClientID, chkDiag_CD_VE.ClientID, chkDiag_CE_VE.ClientID, chkDiag_CS_VE.ClientID, chkDiag_CU_VE.ClientID, imgGroup.ClientID, imgDiag_CD_Alive.ClientID, imgDiag_CE_Alive.ClientID, imgDiag_CS_Alive.ClientID, imgDiag_CU_Alive.ClientID }) + ");");
			imgToggle.Attributes.Add("onclick", "javascript:Toggle(" + string.Format("this,{0}", ulHide.ClientID) + ");");
			//collapse all
			ulHide.Attributes.Add("style", "display:none");

			imgDiag_CD_Alive.Attributes.Add("style", !chkDiag_CD_VE.Checked ? "display:none" : string.Empty);
			imgDiag_CS_Alive.Attributes.Add("style", !chkDiag_CS_VE.Checked ? "display:none" : string.Empty);
			imgDiag_CE_Alive.Attributes.Add("style", !chkDiag_CE_VE.Checked ? "display:none" : string.Empty);
			imgDiag_CU_Alive.Attributes.Add("style", !chkDiag_CU_VE.Checked ? "display:none" : string.Empty);

			//init state checkbox
			chkDiag_CD_VE.Disabled = !chkDiag_C2P_VE.Checked;
			chkDiag_CE_VE.Disabled = !chkDiag_C2P_VE.Checked;
			chkDiag_CS_VE.Disabled = !chkDiag_C2P_VE.Checked;
			chkDiag_CU_VE.Disabled = !chkDiag_C2P_VE.Checked;

			//Authorization
			if (!IsAdministrator)
			{
				chkDiag_C2P_VE.Disabled = true;
				chkDiag_CD_VE.Disabled = true;
				chkDiag_CS_VE.Disabled = true;
				chkDiag_CE_VE.Disabled = true;
				chkDiag_CU_VE.Disabled = true;
			}
		}
	}

	protected void DiagnosticUpdate_Click(object sender, EventArgs e)
	{
		foreach (RepeaterItem i in rpDiagnostica.Items)
		{
			HiddenField idC2P = i.FindControl("idC2P") as HiddenField;
			Label lblDescrizione = i.FindControl("lblDescrizione") as Label;
			HtmlInputCheckBox chkDiag_C2P_VE = i.FindControl("chkDiag_C2P_VE") as HtmlInputCheckBox;

			HtmlInputCheckBox chkDiag_CD_VE = i.FindControl("chkDiag_CD_VE") as HtmlInputCheckBox;
			Label lblDiag_CD_Alive = i.FindControl("lblDiag_CD_Alive") as Label;
			Label lblCDStatus = i.FindControl("lblCDStatus") as Label;

			HtmlInputCheckBox chkDiag_CE_VE = i.FindControl("chkDiag_CE_VE") as HtmlInputCheckBox;
			Label lblDiag_CE_Alive = i.FindControl("lblDiag_CE_Alive") as Label;
			Label lblCEStatus = i.FindControl("lblCEStatus") as Label;

			HtmlInputCheckBox chkDiag_CS_VE = i.FindControl("chkDiag_CS_VE") as HtmlInputCheckBox;
			Label lblDiag_CS_Alive = i.FindControl("lblDiag_CS_Alive") as Label;
			Label lblCSStatus = i.FindControl("lblCSStatus") as Label;

			HtmlInputCheckBox chkDiag_CU_VE = i.FindControl("chkDiag_CU_VE") as HtmlInputCheckBox;
			Label lblDiag_CU_Alive = i.FindControl("lblDiag_CU_Alive") as Label;
			Label lblCUStatus = i.FindControl("lblCUStatus") as Label;

			try
			{
				C2PDiagnostic updatedDiagnostic = new C2PDiagnostic();
				updatedDiagnostic.IdC2P = int.Parse(idC2P.Value);
				updatedDiagnostic.Diag_C2P_VE = chkDiag_C2P_VE.Checked;
				updatedDiagnostic.Diag_CD_VE = chkDiag_CD_VE.Checked;
				updatedDiagnostic.Diag_CE_VE = chkDiag_CE_VE.Checked;
				updatedDiagnostic.Diag_CS_VE = chkDiag_CS_VE.Checked;
				updatedDiagnostic.Diag_CU_VE = chkDiag_CU_VE.Checked;

				using (BLC2P d = new BLC2P())
				{
					d.AggiornaC2PDiagnostic(updatedDiagnostic);
				}
			}
			catch (Exception ex)
			{
				lblError.Text = ex.Message;
			}

		}

		_requireNewBind = true;
	}

	private void DiagnosticaDataBind()
	{
		using (BLC2P c2p = new BLC2P())
		{
			try
			{
				List<C2PDiagnostic> listOfC2P = c2p.GetListaDiagnostica("Descrizione");
				rpDiagnostica.DataSource = listOfC2P;
				rpDiagnostica.DataBind();

				chkSystemCheck.Src = CheckSystem(listOfC2P) ? GREEN_IMAGE : RED_IMAGE;
			}
			catch (Exception ex)
			{
				lblError.Text = ex.Message;
			}
		}
	}


	protected C2PDiagnostic R { get { return (C2PDiagnostic)this.GetDataItem(); } }

	private static bool isC2PAlive(C2PDiagnostic c)
	{
		// ci sono dei C2P non ancora montati il cui messaggio di diagnostica non e` ancora pervenuto al centro
		if (c.Diag_TSUpdate.HasValue == false)
			return false; // non e` mai arrivato un msg di diagnostica.

		// Se un C2P e` vivo, puo` avere Diag_C2P_Alive == null se
		// non e` mai andato fuori linea - ossia se i suoi messaggi sono sempre arrivati
		// DiagnosticaC2PPoller mette il campo true SOLO se Diag_C2P_Alive == null o Diag_C2P_Alive == 'true'
		// e se non arrivano piu` messaggi.
		// N.B. Il centro mette 'true' Diag_C2P_Alive ad ogni messaggio
		if (c.Diag_C2P_Alive == null)
			return true; // nessuno ha finora updatato Diag_C2P_Alive (notare che DiagnosticaC2P nel centro non lo fa!)

		// qui Diag_C2P_Alive e` valorizzato:
		// 1) DiagnosticaC2P (al centro) lo mette a 'true' ad ogni messaggio
		// 2) DiagnosticaC2PPoller (nel serivzio) lo mette a 'false' ogni volta che i messaggi non arrivano (a timeout)
		return c.Diag_C2P_Alive == "true";
	}

	protected static string VerifyC2P(C2PDiagnostic c)
	{
		if (isC2PAlive(c))
			return DIAGNOSTIC_OK;
		else
			return DIAGNOSTIC_KO;
	}

	protected bool CheckSystem(List<C2PDiagnostic> listOfC2P)
	{
		foreach (C2PDiagnostic c2p in listOfC2P)
		{
			if (c2p.Diag_C2P_VE == true)
			{
				//controllo se e' in servizio
				if (isC2PAlive(c2p))
				{
					if (c2p.Diag_CD_VE)
						if (c2p.Diag_CD_Alive != "true" && c2p.Diag_CD_Alive != null) return false;
					if (c2p.Diag_CE_VE)
						if (c2p.Diag_CE_Alive != "true" && c2p.Diag_CE_Alive != null) return false;
					if (c2p.Diag_CS_VE)
						if (c2p.Diag_CS_Alive != "true" && c2p.Diag_CS_Alive != null) return false;
					if (c2p.Diag_CU_VE)
						if (c2p.Diag_CU_Alive != "true" && c2p.Diag_CU_Alive != null) return false;
				}
				else
					return false;
			}
		}
		return true;
	}

	protected string GroupStateImage(C2PDiagnostic group)
	{
		bool IsC2PAvaiable = isC2PAlive(group);

		if (!IsC2PAvaiable)
			return RED_IMAGE;

		if (group.Diag_CD_Alive != "true" && group.Diag_CD_Alive != null && group.Diag_CD_VE == true)
			return ORANGE_IMAGE;

		if (group.Diag_CS_Alive != "true" && group.Diag_CS_Alive != null && group.Diag_CS_VE == true)
			return ORANGE_IMAGE;

		if (group.Diag_CE_Alive != "true" && group.Diag_CE_Alive != null && group.Diag_CE_VE == true)
			return ORANGE_IMAGE;

		if (group.Diag_CU_Alive != "true" && group.Diag_CU_Alive != null && group.Diag_CU_VE == true)
			return ORANGE_IMAGE;

		return GREEN_IMAGE;
	}

	protected string CameraImage(C2PDiagnostic group, string state)
	{
		bool IsC2PAvaiable = isC2PAlive(group);
		return IsC2PAvaiable && (state == "true" || state == null) ? GREEN_IMAGE : RED_IMAGE;
	}
}
