using System;
using System.Data;
using System.Drawing;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Diagnostics;
using ITRS_BL;


public partial class Login : System.Web.UI.Page
{
	#region Stato della pagina
	/// <summary>
	/// stato della pagina memorizzato nel control State
	/// </summary>
	[Serializable]
	protected class PageState
	{
		public RichiestaCambioPassword richiestaCambioPassword = RichiestaCambioPassword.Nessuna;
		public int giorniRimasti = -1;
		public string userNameLogato = null;
		public string pwdUtenteLogato = null;
		public bool cambioPassword = false;
		public int coaCompetenza;
	}
	protected PageState _pageState = new PageState();
	protected override void LoadControlState(object savedState)
	{
		_pageState = (PageState)savedState;
	}
	protected override object SaveControlState()
	{
		return _pageState;
	}

	protected enum RichiestaCambioPassword
	{
		Nessuna,
		Facoltativa,
		Obbligatoria,
		PrimoAccesso
	}
	#endregion

	protected Login()
	{
		this.Init += Page_Init;
		this.Load += Page_Load;
	}

	protected void Page_Init(object sender, EventArgs e)
	{
		Page.RegisterRequiresControlState(this);

		if (!IsPostBack)
			_pageState = new PageState();

		this.PreRender += Login_PreRender;

		this.CambiaPasswordControl1.PasswordCambiata += CambiaPasswordControl1_PasswordCambiata;
		this.CambiaPasswordControl1.Cancella += CambiaPasswordControl1_Cancella;
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
			LockAllInactiveUsers();

		if (!ClientScript.IsClientScriptBlockRegistered(this.GetType(), "pulisciErrore"))
		{
			string src = @"
			function pulisciErrore()
			{
				try {
					var e = document.getElementById('" + lblError.ClientID + @"');
					e.innerText = '';
					e = document.getElementById('" + divAccessoNegato.ClientID + @"');
					if (e) e.innerText = '';
				} catch (ex)
				{
					alert(ex);
				}
			}
";
			ClientScript.RegisterClientScriptBlock(this.GetType(), "pulisciErrore", src, true);

			btnLogin.OnClientClick = "pulisciErrore(); return true;";
		}
	}

	private static void LockAllInactiveUsers()
	{
		try
		{
			// chiamata per mettere in Lock tutti gli utenti che non usano il sistema da piu` di 6mesi
			int d = ReadAppSettings.ToInt32("Login.LockUtentiInattivi.DopoGiorni", 30 * 6);
			OracleMembershipProvider oraProvider = Membership.Provider as OracleMembershipProvider;
			oraProvider.LockInactiveUsers(d);
		}
		catch
		{
		}
	}

	void Login_PreRender(object sender, EventArgs e)
	{
		if (_pageState.richiestaCambioPassword == RichiestaCambioPassword.Nessuna)
		{
			mvLogin.ActiveViewIndex = 0;
		}
		else
		{
			mvLogin.ActiveViewIndex = 1;

			switch (_pageState.richiestaCambioPassword)
			{
			case RichiestaCambioPassword.Facoltativa:
				lblCambioFacolativo.Visible = true;
				lblCambioObbligatorio.Visible = false;
				lblCambioPrimaPwd.Visible = false;
				break;

			case RichiestaCambioPassword.Obbligatoria:
				lblCambioFacolativo.Visible = false;
				lblCambioObbligatorio.Visible = true;
				lblCambioPrimaPwd.Visible = false;
				break;

			case RichiestaCambioPassword.PrimoAccesso:
				lblCambioFacolativo.Visible = false;
				lblCambioObbligatorio.Visible = false;
				lblCambioPrimaPwd.Visible = true;
				break;
			}
		}
	}

	protected void btnLogin_Click(object sender, EventArgs e)
	{
		_pageState.userNameLogato = null;
		_pageState.pwdUtenteLogato = null;
		_pageState.coaCompetenza = -1;

		divAccessoNegato.Visible = false;


		// carico i dati dell'utente (per leggere gli attuali valorid del LastLoginDate/LastActivityDate
		// che Membership.ValidateUser aggiorna in caso di successo.
		MembershipUserWithProfile mu = null;
		try
		{
			Roles.DeleteCookie();
			// indico che non voglio updatare LastActivityDate
			mu = (MembershipUserWithProfile)Membership.GetUser(txtLogin.Text, false);
			if (mu == null)
				mu = (MembershipUserWithProfile)Membership.GetUser(txtLogin.Text.ToLower(), false);
		}
		catch
		{
		}


		try
		{
			// in caso di successo e se l'utente e` IsApproved=true
			// sono aggiornati i campi LastLoginDate, LastActivityDate 
			bool b = Membership.ValidateUser(txtLogin.Text, txtPassword.Text);
			if (!b)
			{
				string lw = txtLogin.Text.ToLower();
				b = Membership.ValidateUser(lw, txtPassword.Text);
				if (b)
					txtLogin.Text = lw;
			}

			if (!b)
			{
				divAccessoNegato.Visible = true;
				PageBase.AddUserActivity("System", TipoAttivita.Accesso, "Accesso al sistema fallito - user:{0} password:{1} indirizzo TCP/IP:{2}", txtLogin.Text, "?????????????", Request.UserHostAddress);
				return;
			}
		}
		catch (Oracle.DataAccess.Client.OracleException ex)
		{
			this.lblError.Text = "Errore di connessione al data base. Errore=" + ex.Number.ToString();
			return;
		}

		_pageState.userNameLogato = txtLogin.Text;
		_pageState.pwdUtenteLogato = txtPassword.Text;
		_pageState.richiestaCambioPassword = RichiestaCambioPassword.Nessuna;
		if (mu.IdCoaDiCompetenza.HasValue)
			_pageState.coaCompetenza = mu.IdCoaDiCompetenza.Value;
		else
			_pageState.coaCompetenza = -1;

		try
		{
			ControlloScedenzaPassword(mu);

			if (_pageState.richiestaCambioPassword == RichiestaCambioPassword.Nessuna)
				DoLogin(_pageState.userNameLogato);
		}
		catch (Exception ex)
		{
			this.lblError.Text = "Errore nella fase di accesso al sistema. Errore=" + ex.Message;
			Log.Write(ex, "Login");
			return;
		}
	}

	/// <summary>
	/// controlla se e` necessario richiedere una nuova password.
	/// Ritorna false se si puo` procedere con il login, true se si deve chiedere la password
	/// </summary>
	/// <param name="mu"></param>
	/// <returns></returns>
	private bool ControlloScedenzaPassword(MembershipUserWithProfile mu)
	{
		// l'amministratore di sistema non deve sottostare alle politiche di cambio password
		if (mu.UserProfile == "Amministratore sistema")
			return false;

		if (mu.LastPasswordChangedDate == mu.CreationDate)
		{
			// primo login: cambio password obbligatorio
			_pageState.richiestaCambioPassword = RichiestaCambioPassword.PrimoAccesso;
			this.CambiaPasswordControl1.BottoneCancellaAbilitato = false;
			this.CambiaPasswordControl1.UserName = _pageState.userNameLogato;
			return true;
		}

		int ngObbligatori = ReadAppSettings.ToInt32("Login.CambioPassword.Obbligatorio.DopoGiorni", 30);
		int ngFacoltativi = ReadAppSettings.ToInt32("Login.CambioPassword.Facoltativo.DopoGiorni", 25);

		TimeSpan ts = DateTime.Now.Date.Subtract(mu.LastPasswordChangedDate.Date);
		if (ts.Days >= ngObbligatori)
		{
			// cambio password obbligatorio
			_pageState.richiestaCambioPassword = RichiestaCambioPassword.Obbligatoria;
			this.CambiaPasswordControl1.BottoneCancellaAbilitato = false;
			this.CambiaPasswordControl1.UserName = _pageState.userNameLogato;
			return true;

		}

		if (ts.Days >= ngFacoltativi)
		{
			// cambio password facoltativo
			_pageState.giorniRimasti = ngObbligatori - ts.Days;
			_pageState.richiestaCambioPassword = RichiestaCambioPassword.Facoltativa;
			this.CambiaPasswordControl1.BottoneCancellaAbilitato = true;
			this.CambiaPasswordControl1.UserName = _pageState.userNameLogato;
			return true;
		}

		return false;
	}

	private void DoLogin(string userName)
	{
		try
		{
			ITRSUtility.SetCoaDiAppartenenza(_pageState.userNameLogato, _pageState.coaCompetenza);
			PageBase.AddUserActivity(_pageState.userNameLogato, TipoAttivita.Accesso, "Accesso utente {0} indirizzo TCP/IP {1}", txtLogin.Text, Request.UserHostAddress);
			ITRSUtility.UpdateUserRoles(userName);
			FormsAuthentication.RedirectFromLoginPage(userName, false);
		}
		catch (Exception ex)
		{
			this.lblError.Text = "Errore nella fase di accesso al sistema. Errore=" + ex.Message;
			Log.Write(ex, "Login");
			return;
		}

	}

	void CambiaPasswordControl1_PasswordCambiata(object sender, EventArgs e)
	{
		DoLogin(_pageState.userNameLogato);
	}

	void CambiaPasswordControl1_Cancella(object sender, EventArgs e)
	{
		DoLogin(_pageState.userNameLogato);
	}
}



