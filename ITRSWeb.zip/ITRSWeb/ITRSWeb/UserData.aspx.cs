using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class UserData : PageBase
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsCallback)
		{
			MembershipUserWithProfile mu = Membership.GetUser((object)UserPkId, false) as MembershipUserWithProfile;

			txtNomeUtente.Text = mu.UserName;
			txtProfilo.Text = mu.UserProfile;

			StringBuilder r = new StringBuilder();
			foreach (string t in Roles.GetRolesForUser())
			{
				HtmlTableRow tr = new HtmlTableRow();
				tb.Rows.Add(tr);

				HtmlTableCell tc1 = new HtmlTableCell();
				tr.Cells.Add(tc1);

				HtmlTableCell tc2 = new HtmlTableCell();
				tr.Cells.Add(tc2);

				tc2.InnerText = t;
			}
		}
	}
}
