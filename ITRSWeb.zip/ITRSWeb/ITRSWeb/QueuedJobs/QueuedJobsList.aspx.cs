using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Diagnostics;

using ITRS_BL;

public partial class QueuedJobs_Default : PageBase
{
			//    <asp:templatefield headertext="Dettaglio">
			//    <itemtemplate><%# Eval("JobArgsHtml")%></itemtemplate>
			//</asp:templatefield>

    //  <asp:templatefield headertext="Prova">
    //		<itemtemplate><%# StampaHtml(Container.DataItem)%></itemtemplate>
    //  </asp:templatefield>
	//public string StampaHtml(object o)
	//{
	//    ITRS_BL.QueueJob r = (ITRS_BL.QueueJob)o;
	//    return r.JobArgsHtml;
	//}
	protected void Page_Load(object sender, EventArgs e)
	{

		if (!this.ClientScript.IsClientScriptBlockRegistered(this.GetType(), "RefreshGrid"))
		{
			string id = this.gvJobs.UniqueID.Replace('$', '_');
			string pb = this.ClientScript.GetPostBackEventReference(this.btnRefreshEsterno, "");
			string s = string.Format(@"
			var refreshGridTimer = setTimeout('AutoRefresh();', 5000);

			function AutoRefresh()
			{{
				var gv = document.getElementById('{0}');
				if (gv != null && gv.rows.length > 0 && gv.rows[0].cells.length > 12)
				{{
					var lnkRefresh = gv.rows[0].cells[12].children[0];	
					if (lnkRefresh && lnkRefresh.onclick)
						lnkRefresh.onclick();
				}}
				else
				{{
					{1};
				}}
				
				refreshGridTimer = setTimeout('AutoRefresh();', 5000);
			}}
			", id, pb);

			this.ClientScript.RegisterClientScriptBlock(this.GetType(), "RefreshGrid", s, true);
		}
		btnRefreshEsterno.Style.Add(HtmlTextWriterStyle.Visibility, "hidden");
	}

	public void gvJobs_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		/*
			<asp:TemplateField ShowHeader="False">
				<ItemTemplate>
					<asp:LinkButton ID="B1" runat="server" CommandName="B1" >B1</asp:LinkButton>
				</ItemTemplate>
			</asp:TemplateField>
			<asp:TemplateField ShowHeader="False">
				<ItemTemplate>
					<asp:LinkButton ID="B2" runat="server" CommandName="B2" >B2</asp:LinkButton>
				</ItemTemplate>
			</asp:TemplateField>

			Control c1 = e.Row.Cells[12].FindControl("B1");
			Control c2 = e.Row.Cells[13].FindControl("B2");
		*/
		try
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				ITRS_BL.QueueJob r = (ITRS_BL.QueueJob)e.Row.DataItem;

				FindControlDelegate<LinkButton> f1 = delegate(LinkButton p) { return p.CommandName == "B1"; };
				FindControlDelegate<LinkButton> f2 = delegate(LinkButton p) { return p.CommandName == "B2"; };
				LinkButton b1 = FindControlRecursive(e.Row, f1);
				LinkButton b2 = FindControlRecursive(e.Row, f2);
				switch (r.Status)
				{
				case BLQueueJobs.JobStatus.QUEUE:
					b1.CommandName = "AbortJob";
					b1.Text = "Abort";
					b1.CommandArgument = r.Id;
					b1.OnClientClick = "return confirm('Vuoi abortire il job ?')";


					b2.CommandName = "SuspendJob";
					b2.Text = "Suspend";
					b2.CommandArgument = r.Id;
					b2.OnClientClick = "return confirm('Vuoi sospendere il job ?')";
					break;

				case BLQueueJobs.JobStatus.SOSP:
					b1.CommandName = "ResumeJob";
					b1.Text = "Resume";
					b1.CommandArgument = r.Id;
					b1.OnClientClick = "return confirm('Vuoi riprendere il job ?')";

					b2.Visible = false;
					break;

				case BLQueueJobs.JobStatus.RUN:
				case BLQueueJobs.JobStatus.RRES:
					b1.CommandName = "AbortJob";
					b1.Text = "Abort";
					b1.CommandArgument = r.Id;
					b1.OnClientClick = "return confirm('Vuoi abortire il job ?')";

					b2.Visible = false;
					break;

				default:
					b1.Visible = false;
					b2.Visible = false;
					break;
				}

				// copio lo stato del job tradotto in italiano.
				string stato = ITRSUtility.Translate(r.Status);
				e.Row.Cells[GridView_GetCellIndex(gvJobs, "Status")].Text = stato;

				// cambio il tipo, nel caso di "INTERVENTI".
				if (r.Type == "INTERVENTI")
					e.Row.Cells[GridView_GetCellIndex(gvJobs, "Type")].Text = "Intervento";


				TableCell tc = e.Row.Cells[GridView_GetCellIndex(gvJobs, "JobArgsHtml")];
				tc.Text = "";
				tc.Controls.Add(new LiteralControl(r.JobArgsHtml));
			}
		}
		catch (Exception ex)
		{
			Debug.Assert(false, ex.Message);
		}
	}
	protected void gvJobs_RowCommand(object sender, GridViewCommandEventArgs e)
	{
		string jobId = e.CommandArgument.ToString();
		ITRS_BL.BLQueueJobs bl = new ITRS_BL.BLQueueJobs();

		switch (e.CommandName)
		{
		case "AbortJob":
			bl.Abort(jobId);
			break;

		case "SuspendJob":
			bl.Suspend(jobId);
			break;

		case "ResumeJob":
			bl.Resume(jobId);
			break;

		default:
			Debug.Assert(false, e.CommandName);
			break;
		}
		this.gvJobs.DataBind();
	}

	protected void btnRefreshEsterno_Click(object sender, EventArgs e)
	{

	}
}
