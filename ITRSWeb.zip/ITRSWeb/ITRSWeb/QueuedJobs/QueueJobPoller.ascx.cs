using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;

using ITRS_BL;

public partial class QueuedJobs_QueueJobPoller : System.Web.UI.UserControl
{
	static bool QueryRunning(BLQueueJobs.JobStatus status)
	{
		switch (status)
		{
		case BLQueueJobs.JobStatus.QUEUE:
		case BLQueueJobs.JobStatus.RUN:
		case BLQueueJobs.JobStatus.RRES:
		case BLQueueJobs.JobStatus.SOSP:
		case BLQueueJobs.JobStatus.ABRQ:
			return true;

		case BLQueueJobs.JobStatus.ERR:
		case BLQueueJobs.JobStatus.END:
		case BLQueueJobs.JobStatus.ABAK:
		case BLQueueJobs.JobStatus.CANC:
			return false;

		default:
			Debug.Assert(false, status.ToString());
			return false;
		}
	}

	public class ClientData
	{
		public bool DataReady;
		public string Status;
		public string StatusDescr;
		public int? CurrentStep;
		public int? TotalSteps;
		public string ProgressMessage;
		public string ErrorMessage;
		public int? ResRecordCount;
	}

	protected override void OnInit(EventArgs e)
	{
		this.Page.RegisterRequiresControlState(this);
		base.OnInit(e);
	}

	public void StartPollingJob(string jobId)
	{
		this.hfClientData.Value = "";
		this.hfJobId.Value = jobId;
		this.Visible = true;

		BLQueueJobs bl = new BLQueueJobs();
		QueueJob JobData = bl.GetRunningJobData(this.hfJobId.Value);

		// la prima volta che viene chiamata la maschera
		this.btnRisultatiIntermedi.Style[HtmlTextWriterStyle.Visibility] = "hidden";

		if (QueryRunning(JobData.Status))
		{
			// siamo in attesa che il job si concluda...
			this.clientTimerQueryResult.EnableServerCalls = "true";
		}
		else
		{
			// il job e` gia` terminato... 
			this.clientTimerQueryResult.EnableServerCalls = "false";
			OnRefreshRequested(JobData, false);
		}
	}

	public void StopPolling()
	{
		this.hfJobId.Value = "";
		this.hfClientData.Value = "";
		this.clientTimerQueryResult.EnableServerCalls = "false";
		this.Visible = true;
	}

	[Bindable(true)]
	[DefaultValue(true)]
	public override bool Visible
	{
		get { return _Visible; }
		set { _Visible = value; }
	}
	bool _Visible;

	protected override object SaveControlState() { return _Visible; }
	protected override void LoadControlState(object state) { _Visible = (bool)state; }


	protected void Page_Load(object sender, EventArgs e)
	{
		PageBase pb = (PageBase)(this.Page);

		pb.RegisterClientId("QP",
			this.xlblRecordDisponibili,
			this.xlblStato,
			this.xlblAvanzamento,
			this.btnRisultatiIntermedi,
			this.hfJobId,
			this.hfClientData
			);

		if (!Page.ClientScript.IsClientScriptBlockRegistered("PollerJob"))
		{
			string m = Page.ClientScript.GetPostBackEventReference(this.btnRisultatiIntermedi, "");
			string s = string.Format("function MostraRisultatiIntermedi() {{ {0}; }}", m);

			Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PollerJob", s + script, true);

			Page.ClientScript.RegisterStartupScript(this.GetType(), "ddddd", "InitPoller();", true);
		}
	}


	const string script =
@"
function InitPoller()
{
	var tmp = QP.hfClientData();
	if (tmp == undefined)
		return;

	var msg = tmp.value;
	if (msg == '')
		return;

	var r = new ClientState(msg);
	if (r.DataReady == false)
		return;

	RenderPoller(r);
}
function RenderPoller(r)
{
	var c;
	
	if (r.StatusDescr != '')
	{
		c = QP.xlblStato();
		c.style.visibility = 'visible';
		c.innerText = r.StatusDescr;
	}

	if (r.CurrentStep != null)
	{
		var p = document.getElementById('tbProgress');
		updateProgress(p, r.CurrentStep, r.TotalSteps);
	}
	
	if (r.ProgressMessage != null && r.ProgressMessage != '')
	{
		c = QP.xlblAvanzamento();
		c.style.visibility = 'visible';
		c.innerText = r.ProgressMessage;
	}
	
	if (r.ResRecordCount != null)
	{
		c = QP.xlblRecordDisponibili();
		c.innerText = r.ResRecordCount;
		c.style.visibility = 'visible';
		
		if (r.ResRecordCount > 0)
		{
			c = QP.btnRisultatiIntermedi();
			if (c != null)
				c.style.visibility = 'visible';
		}
	}
}

function onJobProgressMsg(msg)
{
	if (QP.hfClientData() == undefined)
		return false;

	QP.hfClientData().value = msg;
	if (msg == '')
		return true;

	var r = new ClientState(msg);
	if (r.DataReady == false)
		return true;
		

	RenderPoller(r);
	
	/*
	-- QUEUE job in coda
	-- RUN   job in esecuzione
	-- SOSP  job sospeso
	-- ERR   job terminato con eccezione
	-- RRES  job in run che ha prodotto risultati intermedi
	-- END   job terminato con successo
	-- ABRQ  job con richiesta di abort in corso
	-- ABAK  job che ha accettato la richiesta di abort
	-- CANC  job da cancellare perche` scaduto (sysdate - QJLASTRESACCESS > QJRESTIMEOUTSEC)
	*/
	var ret;
	switch (r.Status)
	{
	case 'QUEUE': ret = true;  break;
	case 'RUN':   ret = true;  break;
	case 'SOSP':  ret = true;  break;
	case 'ERR':   ret = false; break;
	case 'RRES':  ret = true;  break;
	case 'END':   ret = false; break;
	
	case 'ABRQ':  ret = true;  break;
	case 'ABAK':  ret = false; break;
	case 'CANC':  ret = false; break;
	}

	if (ret == false)
		MostraRisultatiIntermedi();
	
	return ret;
}

function getArg()
{
	var hf = QP.hfJobId();
	return hf.value;
}
		
function updateProgress(tb, ss, cc)
{
	if (cc <= 0) return;
	if (ss < 0 && ss >= cc) return;

	// scalo i valori in modo che siano al max 20
	var scale_kk = cc / 20;
	if (scale_kk == 0) scale_kk = 1;
	var scale_kki = Math.ceil(scale_kk);
	cc = Math.ceil(cc/scale_kki);
	ss = Math.ceil(ss/scale_kki);

	if (tb.rows[0].cells.length != cc)
	{
		tb.width = '200px';
		
		var nn = tb.rows[0].cells.length;
		for (var tt = 0; tt < nn; ++tt)
			tb.rows[0].deleteCell(0);
			
		tb.style.backgroundColor = 'white';
			
		var ww = 100 / cc;
			
		for (var ii = 0; ii < cc; ++ii)
		{
			var c = tb.rows[0].insertCell(0);
			c.style.backgroundColor = 'white';
			c.style.width = ww.toString() + '%';
			c.style.height = '10px';
		}
	}
	
	if (true)
	{
		for (var ii = 0; ii < cc; ++ii)
			if (ii <= ss)
				tb.rows[0].cells[ii].style.backgroundColor = 'black';
	}
}

";

	protected void clientTimerQueryResult_ClientCall(object sender, ITRSControls.ClientTimerClientTimerEventArgs e)
	{
		// questa funzione viene chiamata sulla callback.

		BLQueueJobs bl = new BLQueueJobs();
		QueueJob JobData = bl.GetRunningJobData(e.Args);

		ClientData cd = new ClientData();
		cd.DataReady = false;

		if (JobData != null)
		{
			cd.DataReady = true;
			cd.StatusDescr = ITRSUtility.Translate(JobData.Status);
			cd.Status = JobData.Status.ToString();
			cd.CurrentStep = JobData.CurrentStep;
			cd.TotalSteps = JobData.TotalSteps;
			cd.ProgressMessage = JobData.ProgressMessage;
			cd.ErrorMessage = JobData.ErrorMessage;
			cd.ResRecordCount = JobData.ResRecordCount;
		}

		e.Result = ClientState.Serialize(cd);
	}

	public delegate void RefreshRequestedDelegate(object sender, RefreshEvent e);
	public event RefreshRequestedDelegate RefreshRequested;

	[Serializable]
	public class RefreshEvent : EventArgs
	{
		public RefreshEvent(QueueJob queueJob, bool mostraRisultatiIntermedi) 
		{ 
			this.QueueJob = queueJob;
			this.MostraRisultatiIntermedi = mostraRisultatiIntermedi;

		}
		public readonly QueueJob QueueJob;
		public readonly bool MostraRisultatiIntermedi;
	}

	protected void OnRefreshRequested(QueueJob qj, bool mostraRisultatiIntermedi)
	{
		if (this.RefreshRequested != null)
			this.RefreshRequested(this, new RefreshEvent(qj, mostraRisultatiIntermedi));
	}

	protected void btnRisultatiIntermedi_Click(object sender, EventArgs e)
	{
		this.btnRisultatiIntermedi.Style[HtmlTextWriterStyle.Visibility] = "hidden";
		BLQueueJobs bl = new BLQueueJobs();
		QueueJob JobData = bl.GetRunningJobData(hfJobId.Value);

		if (QueryRunning(JobData.Status) == false)
			this.clientTimerQueryResult.EnableServerCalls = "false";

		OnRefreshRequested(JobData, true);
	}
}
