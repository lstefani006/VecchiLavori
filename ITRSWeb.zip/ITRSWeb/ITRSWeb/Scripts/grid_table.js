// ---------------------------------------------------------
// Global JavaScript functions used by grid tables
// ---------------------------------------------------------
var vArraySelectedRow = new Array();		// Row to store selected rows

var vArraySelectedCells = new Array();

function CellObject(pCell)
{
	this.Cell = pCell;
	this.BGColor = pCell.style.backgroundColor;
	this.TXTColor = pCell.style.color;
}

function RowObject(pRow)
	// ***********************************************************
	//
	// Function:	RowObject
	//		Constructor for a row array object to keep track
	//		of selected rows.
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
{
	this.Row = pRow;
	this.BGColor = pRow.style.backgroundColor;
	this.TXTColor = pRow.style.color;
	this.Cancelled = pRow.bCancelled;
	return;
}

function fnGetSelectedRows() 
	// ***********************************************************
	//
	// Function:	fnGetSelectedRows
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
{
	return vArraySelectedRow;
}


function fnEnableSort() {
	// ***********************************************************
	// Function:	fnEnableSort
	// ***********************************************************
	parent.fnSetSortFlag(true);
	return;
}

function fnGridTableSort(vSortColumn) {
	// ***********************************************************
	//
	// Function:	fnGridTableSort
	// Parameters:	
	// Returns:	 
	//
	// ***********************************************************

	var vAscendingSort = vSortColumn;
	var vDescendingSort = "-" + vSortColumn;

	if((tblData.className == "clsSingleSelect") || (tblData.className == "clsMultiSelect")){
		fnUnselectAll(tblData);
	}

	sortField.value = (sortField.value == vAscendingSort ? vDescendingSort : vAscendingSort);
	<!-- set cursor to watch here? -->
		listing.innerHTML = source.documentElement.transformNode(stylesheet);

	fnApplyRowColor(tblData);

	// let some tables perform their own post-sort formatting
	if ( window.fnAfterSort )
		fnAfterSort( tblData );

	return;
}

function fnUnselectAll(objTable) {

	for (z=0; z<(objTable.rows.length-1); z++) {

		if ( fnIsRowHighlighted( objTable.rows(z) ) ) {

			fnToggleRow(objTable, objTable.rows(z));	
			// let some tables perform their own post-unselect formatting
			if ( parent.fnPostToggleRow )
				parent.fnPostToggleRow(objTable.rows(z).length);	
		}
	}
}


function fnApplyRowColor(objTable) {

	// ***********************************************************
	//
	// Function:	fnApplyRowColor
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	for (i=0; i<(objTable.rows.length-1); i++)
	{
		if ((i % 2) == 0)
			objTable.rows(i).style.backgroundColor = "#ffffff";
		else
			objTable.rows(i).style.backgroundColor = "lightgrey";
	}
	return;
}

function fnScrollLabels() {

	// ***********************************************************
	//
	// Function:	fnScrollLabels
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	fnScrollLabels1( "iframeButtons" );
	return;
}

function fnScrollLabels2() {

	// ***********************************************************
	// Function:	fnScrollLabels
	// ***********************************************************
	fnScrollLabels1( "iframeButtons2" );
	return;
}

function fnScrollLabels1( strFrameName )
{

	// ***********************************************************
	//
	// Function:	fnScrollLabels
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	parent.fnScroll1(document.body.scrollLeft, strFrameName);
	return;
}

function fnResetXML() {

	// ***********************************************************
	//
	// Function:	fnResetXML
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	sortField.value = vOriginalSort;

	//this is a solution to the problem where the page keeps loading.....
	top.fnRefreshDummy();

	<!-- set cursor to watch here? -->
		listing.innerHTML = source.documentElement.transformNode(stylesheet);
	fnApplyRowColor(tblData);
	return;
}


function fnFilterCodes(pColumn, pCodes) {
	// ***********************************************************
	//
	// Function:	fnFilterCodes
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	var i;
	var vFilterString="";

	// Loop through code array and create the filter string.
	for (i=0; i<pCodes.length; i++) {
		if (i == (pCodes.length-1)) {
			vFilterString += pColumn + " = '" + pCodes[i] + "'";
		} else {
			vFilterString += pColumn + " = '" + pCodes[i] + "' or ";
		}
	}
	return vFilterString;
}

function fnFilterDates(pColumn, pStart, pEnd) {
	// ***********************************************************
	//
	// Function:	fnFilterDates
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	var vFilterString="";

	if (pStart && pEnd) {
		vFilterString = pColumn + " $ge$ '" + pStart + "' and " + pColumn + " $le$ '" + pEnd + "'";
	}

	if (pStart && !pEnd) {
		vFilterString = pColumn + " $ge$ '" + pStart + "'";
	}

	if (!pStart && pEnd) {
		vFilterString = pColumn + " $le$ '" + pEnd + "'";
	}

	return vFilterString;
}

function fnFormatDate(pDate) {
	// due to retire -Still used in ABPBUI, mjbeermann-02/21/2002
	// ***********************************************************
	//
	// Function:	fnFormatDate
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	var vDateString = "";
	var newDate = new Date(pDate);
	if (isNaN(newDate)) return vDateString;
	var vYear = newDate.getFullYear();
	var vMonth = newDate.getMonth();
	var vDay = String(newDate.getDate());
	if (String(vMonth+1).length == 1) {
		vMonth = "0" + String(vMonth+1);
	} else {
		vMonth = String(vMonth+1);	}

	if (vDay.length == 1) {
		vDay = "0" + vDay;
	}

	vDateString = vYear + vMonth + vDay;
	return vDateString;
}

function fnFormatNativeDate(pLocalDate, pLocalDateFormat) {
	// ***********************************************************
	// Function:   fnFormatNativeDate
	// Parameters: pLocalDate is a date in Locale-specific format
	//               e.g. '08/22/2001' or '22-08-2001'
	//             pDateFormat is the date format for the Locale
	//               e.g. '%m/%d/%Y' or '%d-%m-%y'
	// Returns:    The pLocalDate reformatted in Excelergy Native format
	//               e.g. 20020331
	// Modifications: 02/20/2002, Mike Beermann.  new function.
	// ***********************************************************
	var vNativeDate = '';
	var vYear;
	var vMonth;
	var vDay;
	var vFirstFormat;
	var xSeparator;
	var vSecondFormat;
	var vThirdFormat;

	if (pLocalDateFormat == '' || pLocalDate == '') {
		// get out, no format or date to reformat
		return('');
	}

	vFirstFormat  = pLocalDateFormat.substr(0, 2)
		vSeparator    = pLocalDateFormat.substr(2, 1)
		vSecondFormat = pLocalDateFormat.substr(3, 2)
		vThirdFormat  = pLocalDateFormat.substr(6, 2)

		var SplitDate;
	SplitDate = pLocalDate.split(vSeparator);

	if (vFirstFormat == '%m') {
		vMonth = SplitDate[0];
		if (vSecondFormat == '%d') {
			vDay  = SplitDate[1];
			vYear = SplitDate[2];
		} else {
			if (vSecondFormat == '%y' || vSecondFormat == '%Y') {
				vYear = SplitDate[1];
				vDay  = SplitDate[2];
			}
		}
	} else {
		if (vFirstFormat == '%d') {
			vDay = SplitDate[0];
			if (vSecondFormat == '%m') {
				vMonth = SplitDate[1];
				vYear  = SplitDate[2];
			} else {
				if (vSecondFormat == '%y' || vSecondFormat == '%Y') {
					vYear  = SplitDate[1];
					vMonth = SplitDate[2];
				}
			}
		} else {
			if (vFirstFormat == '%y' || vFirstFormat == '%Y') {
				vYear = SplitDate[0];
				if (vSecondFormat == '%m') {
					vMonth = SplitDate[1];
					vDay   = SplitDate[2];
				} else {
					if (vSecondFormat == '%d') {
						vDay   = SplitDate[1];
						vMonth = SplitDate[2];
					}
				}
			} else {
				// get out, no date-format
				return('');
			}
		}
	}

	vMonth = (vMonth.length == 1 ? "0" + vMonth : vMonth);
	vDay = (vDay.length == 1 ? "0" + vDay : vDay);
	vNativeDate = vYear + vMonth + vDay;
	return vNativeDate;
}

function fnIsRowHighlighted(pRow) {
	// ***********************************************************
	//
	// Function:	fnIsRowHighlighted
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	return pRow.bHighlighted;
}

function fnUnhighlightRow(pRow, pBGColor, pColor) {
	// ***********************************************************
	//
	// Function:	fnUnhighlightRow
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
	//pRow.className = "";
	pRow.style.color = pColor;
	pRow.style.backgroundColor = pBGColor;
	pRow.bHighlighted = false;
	return;
}

function fnUnhighlightCells(pRow) {
	// ***********************************************************
	//
	// Function:	fnUnhighlightCells
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
	var x =0;
	for(x = 0; x < pRow.cells.length; x++)
	{
		pRow.cells[x].style.backgroundColor = vArraySelectedCells[x].BGColor;
		pRow.cells[x].style.color = vArraySelectedCells[x].TXTColor;
		pRow.cells[x].bHighlighted = false;

	}
	return;
}

function fnHighlightRow(pRow) {
	// ***********************************************************
	//
	// Function:	fnHighlightRow
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
	pRow.style.color = "black";
	pRow.style.backgroundColor = "yellow";
	pRow.bHighlighted = true;
	return;
}

function fnHighlightCells(pRow) {
	// ***********************************************************
	//
	// Function:	fnHighlightCells
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
	for(i = 0; i < pRow.cells.length; i++)
	{
		vArraySelectedCells[i] = new CellObject(pRow.cells[i]);
		pRow.cells[i].style.backgroundColor = "yellow";
		pRow.cells[i].style.color = "black";
		pRow.cells[i].bHighlighted = true;
	}
	return;
}

function fnUnhighlightLinks(pRow) {
	// ***********************************************************
	//
	// Function:	fnUnhighlightLinks
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
	if (pRow.bHasLinks) {
		vArrayLinks = pRow.Links.split(",");
		for (j=0; j<vArrayLinks.length; j++) {
			if ( pRow.cells[ Number(vArrayLinks[j]) ] != null){
				pRow.cells[Number(vArrayLinks[j])].children[0].className = "clsUnhighlightLink";
			}	
		}
	}
	return;
}

function fnHighlightLinks(pRow) {
	// ***********************************************************
	//
	// Function:	fnHighlightLinks
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
	if (pRow.bHasLinks) {
		vArrayLinks = pRow.Links.split(",");
		for (j=0; j<vArrayLinks.length; j++) {
			if ( pRow.cells[Number(vArrayLinks[j])] != null){
				pRow.cells[Number(vArrayLinks[j])].children[0].className = "clsHighlightLink";
			}	
		}
	}
	return;
}

function fnToggleRow(pTable, pRow) {
	// ***********************************************************
	//
	// Function:	fnToggleRow
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
	var vFoundRow = false;
	var vArrayLinks;
	var vTempArray = new Array();
	var vLength;

	for (i=vArraySelectedRow.length-1; i>=0; i--) {
		// Catch this flag for later use
		if (pRow == vArraySelectedRow[i].Row) vFoundRow = true;

		// Unhighlight the row
		fnUnhighlightRow(vArraySelectedRow[i].Row, vArraySelectedRow[i].BGColor, vArraySelectedRow[i].TXTColor);
		fnUnhighlightCells(vArraySelectedRow[i].Row);

		// Handle any links that exist on this row
		fnUnhighlightLinks(vArraySelectedRow[i].Row);

		// Destroy is array object
		vArraySelectedRow[i] = null;

	}

	vArraySelectedRow.length = 0;

	// Now highlight the selected row
	if (!vFoundRow) {
		vArraySelectedRow[vArraySelectedRow.length] = new RowObject(pRow);
		fnHighlightRow(pRow);
		fnHighlightCells(pRow);
		fnHighlightLinks(pRow);
	}
	return;



	// First check if this is multi-select of single-select table
	// Unhighlight all selected row only if
	if ((pTable.className == "clsSingleSelect") || ((pTable.className == "clsMultiSelect") && (fnCheckCtrlKey() == false)) ) {
		// Single-select table logic:
		// Check the selected row array to unselected selected rows

		for (i=vArraySelectedRow.length-1; i>=0; i--) {
			// Catch this flag for later use
			if (pRow == vArraySelectedRow[i].Row) vFoundRow = true;

			// Unhighlight the row
			fnUnhighlightRow(vArraySelectedRow[i].Row, vArraySelectedRow[i].BGColor, vArraySelectedRow[i].TXTColor);
			fnUnhighlightCells(vArraySelectedRow[i].Row);

			// Handle any links that exist on this row
			fnUnhighlightLinks(vArraySelectedRow[i].Row);

			// Destroy is array object
			vArraySelectedRow[i] = null;

		}

		vArraySelectedRow.length = 0;
	} else {

		// Logic to handle multi-select tables with the control key depressed
		for (i=vArraySelectedRow.length-1; i>=0; i--) {
			// Catch this flag for later use
			if (pRow == vArraySelectedRow[i].Row) {
				vFoundRow = true;

				// Unhighlight the row
				fnUnhighlightRow(vArraySelectedRow[i].Row, vArraySelectedRow[i].BGColor, vArraySelectedRow[i].TXTColor);

				// Handle any links that exist on this row
				fnUnhighlightLinks(vArraySelectedRow[i].Row);

				// Remove that row from the selected rows array
				vLength = 0;
				for (j=0; j<vArraySelectedRow.length; j++) {
					if (vArraySelectedRow[j].Row != pRow) {
						vTempArray[vLength++] = vArraySelectedRow[j];
					}
				}

				// Copy over the temp array and then clean up
				for (j=0; j<vTempArray.length; j++) {
					vArraySelectedRow[j] = vTempArray[j];
				}

				vArraySelectedRow.length = vTempArray.length;
				delete vTempArray;

				// Exit cause we hit a row
				break;
			}
		}
	}

	// Now highlight the selected row
	if (!vFoundRow) {
		vArraySelectedRow[vArraySelectedRow.length] = new RowObject(pRow);
		fnHighlightRow(pRow);
		fnHighlightCells(pRow);
		fnHighlightLinks(pRow);
	}
	return;
}

function fnSelectRow(pTable, pRow) {
	// ***********************************************************
	//
	// Function:	fnSelectRow
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************
	fnToggleRow(pTable, pRow);
	//parent.fnPostToggleRow(vArraySelectedRow.length);
	return;
}

function fnCheckCtrlKey() {
	// ***********************************************************
	//
	// Function:	fnCheckCtrlKey
	// Parameters:	
	// Returns:	
	//
	// ***********************************************************

	if (window.event != null) {
		if (window.event.ctrlKey) {
			return true;
		} else {
			return false;
		}
	}
}

