﻿function InitResize()
{
	var ua = navigator.userAgent.toLowerCase();
	var isIE = (ua.indexOf('msie') != -1 && !this.isOpera && (ua.indexOf('webtv') == -1) );

	if (isIE)
	{
		window.attachEvent('onresize', DoResize);
		DoResize();
	}
	else
	{
		window.onresize = DoResize;
		DoResize();
	}
}

function MM_findObj(n, d) 
{
	var p,i,x;  
	if(!d) 
		d = document; 
	if((p=n.indexOf("?"))>0&&parent.frames.length) 
	{
		d=parent.frames[n.substring(p+1)].document; 
		n=n.substring(0,p);
	}
	if(!(x=d[n])&&d.all) 
		x=d.all[n]; 

	for (i=0;!x&&i<d.forms.length;i++) 
		x=d.forms[i][n];

	for(i=0;!x&&d.layers&&i<d.layers.length;i++) 
		x=MM_findObj(n,d.layers[i].document);

	if(!x && d.getElementById) 
		x=d.getElementById(n); 
	return x;
} 

function DoResize()
{ 
	var myWidth = 0;
	var myHeight = 0;

	if (typeof(window.innerWidth) == 'number') 
	{
		//Non-IE
		myWidth  = window.innerWidth;
		myHeight = window.innerHeight;
	} 
	else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) 
	{
		//IE 6+ in 'standards compliant mode'
		myWidth  = document.documentElement.clientWidth;
		myHeight = document.documentElement.clientHeight;
	} 

	else if (document.body && ( document.body.clientWidth || document.body.clientHeight )) 
	{
		//IE 4 compatible
		myWidth  = document.body.clientWidth;
		myHeight = document.body.clientHeight;
	}

//	var obj  = MM_findObj("divMenu");    
//	var obj1 = MM_findObj("imgLogo");
//	var obj2 = MM_findObj("tblUsrInfo");
//	var obj3 = MM_findObj("footerBar");
	var obj  = MM_findObj("mainContainerRow");    
	var obj1 = MM_findObj("mainHeader");
	var obj2 = MM_findObj("mainFooter");
	// var obj3 = MM_findObj("footerBar");
	
	
	var deductW = 10;
	var deductH = 40;      

	// var w = obj1.clientWidth;
	// var h = myHeight - deductH - obj1.clientHeight - obj2.clientHeight - obj3.clientHeight;
	var h = myHeight - deductH - obj1.clientHeight - obj2.clientHeight; // - obj3.clientHeight;
	if (h < 100) h = 100;

	obj.style.height = h + 'px';
	// obj.style.width = w + 'px';      
}

