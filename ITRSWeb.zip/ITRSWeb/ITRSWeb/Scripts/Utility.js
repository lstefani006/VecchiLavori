﻿if (/Mozilla\/5\.0/.test(navigator.userAgent))
	document.write('<script type="text/javascript" src="/ITRSWeb/Scripts/MozillaUtility.js"></script>');
