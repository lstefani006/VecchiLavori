﻿
function ClientState(msg)
{
	this.Read(msg);
}

ClientState.prototype.Read = ClientState_Read;
ClientState.prototype.Write = ClientState_Write;
ClientState.prototype.Decode = ClientState_Decode;
ClientState.prototype.Encode = ClientState_Encode;
ClientState.prototype.EncodeSingle = ClientState_EncodeSingle;
ClientState.prototype.DecodeDate = ClientState_DecodeDate;
ClientState.prototype.EncodeDate = ClientState_EncodeDate;

function ClientState_EncodeDate(d)
{
	var r = d.getFullYear() + " " +
		+ (d.getMonth() + 1) + " " +
		+ d.getDate() + " " +
		+ d.getHours() + " " +
		+ d.getMinutes() + " " +
		+ d.getSeconds();
	return r;
}

function ClientState_DecodeDate(s)
{
	var dc = s.split(' ');
	var d = new Date(
			parseInt(dc[0], 10),
			parseInt(dc[1], 10) - 1,
			parseInt(dc[2], 10),
			parseInt(dc[3], 10),
			parseInt(dc[4], 10),
			parseInt(dc[5], 10),
			0
			);
	return d;
}

function ClientState_Read(msg)
{
	var b64 = new Base64();
	msg = b64.decode(msg);


	this.__Field = new Array();
	this.__Type  = new Array();
	this.__ServerType  = new Array();

	var e = this.Decode(msg, "|");
	for (var i = 0; i < e.length; ++i)
	{
		var t = this.Decode(e[i], ":");

		var field = t[0];
		var type  = t[1];
		var value = t[2];

		var serverType = "";
		if (t.length == 4)
			serverType = t[3];

		this.__Field[i] = field;
		this.__Type[i] = type;
		this.__ServerType[i] = serverType;


		switch(type)
		{
			case "d":
				this[field] = this.DecodeDate(value);
			break;
			case "d?":
				if (value != "")
					this[field] = this.DecodeDate(value);
				else
					this[field] = null;
			break;


			case "b":
				this[field] = value == "1";
			break;
			case "b?":
				if (value != "")
					this[field] = value == "1";
				else
					this[field] = null;
			break;


			case "i":
				this[field] = parseInt(value,10); 
			break;
			case "i?":
				if (value != "")
					this[field] = parseInt(value,10); 
				else
					this[field] = null;
			break;

			case "r":
				this[field] = parseFloat(value);
			break;
			case "r?":
				if (value != "")
					this[field] = parseFloat(value);
				else
					this[field] = null;
			break;


			case "s":
				if (value != "")
					this[field] = value.substr(1); // se la string e` !=null la stringa viene prefissa con un punto
				else
					this[field] = null;
			break;

			case "o":
				if (value == "")
					this[field] = null;
				else
					this[field] = new ClientState(value);
			break;

			case "B":
			{
				if (value == "")
					this[field] = null;
				else if (value == ".")
					this[field] = new Array();
				else
				{
					value = value.substr(1);
					this[field] = new Array();
					var a = this.Decode(value, ";");
					for (var ai = 0; ai < a.length; ai++)
						this[field][ai] = a[ai] == "1";
				}
			}
			break;
			
			case "S":
			{
				if (value == "")
					this[field] = null;
				else if (value == ".")
					this[field] = new Array();
				else
				{
					value = value.substr(1);
					this[field] = new Array();
					var a = this.Decode(value, ";");
					for (var ai = 0; ai < a.length; ai++)
						if (a[ai] != "")
							this[field][ai] = a[ai].substr(1);
						else
							this[field][ai] = null;
						
				}
			}
			break;
			

			case "I":
			{
				if (value == "")
					this[field] = null;
				else if (value == ".")
					this[field] = new Array();
				else
				{
					value = value.substr(1);
					this[field] = new Array();
					var a = this.Decode(value, ";");
					for (var ai = 0; ai < a.length; ai++)
						this[field][ai] = parseInt(a[ai],10);
				}
			}
			break;

			case "D":
			{
				if (value == "")
					this[field] = null;
				else if (value == ".")
					this[field] = new Array();
				else
				{
					value = value.substr(1);
					this[field] = new Array();
					var a = this.Decode(value, ";");
					for (var ai = 0; ai < a.length; ai++)
						this[field][ai] = this.DecodeDate(a[ai]);
				}
			}
			break;

			case "D?":
			{
				if (value == "")
					this[field] = null;
				else if (value == ".")
					this[field] = new Array();
				else
				{
					value = value.substr(1);
					this[field] = new Array();
					var a = this.Decode(value, ";");
					for (var ai = 0; ai < a.length; ai++)
					{
						if (a[ai] != "")
							this[field][ai] = this.DecodeDate(a[ai]);
						else
							this[field][ai] = null;
					}
				}
			}
			break;

			case "R":
			{
				if (value == "")
					this[field] = null;
				else if (value == ".")
					this[field] = new Array();
				else
				{
					value = value.substr(1);
					this[field] = new Array();
					var a = this.Decode(value, ";");
					for (var ai = 0; ai < a.length; ai++)
						this[field][ai] = parseFloat(a[ai]);
				}
			}
			break;

			case "O":
			{
				if (value == "")
					this[field] = null;
				else if (value == ".")
					this[field] = new Array();
				else
				{
					value = value.substr(1);
					this[field] = new Array();
					var a = this.Decode(value, ";");
					for (var ai = 0; ai < a.length; ai++)
					{
						if (a[ai].length == 0)
							this[field][ai] = null;
						else
							this[field][ai] = new ClientState(a[ai]);
					}
				}
			}
			break;
		}
	}
}

function ClientState_Decode(str, sep)
{
	var r = new Array();
	r[0] = "";
	var ri = 0;

	var cc;
	var cn;
	var len = str.length;

	for (var i = 0; i < len; i++)
	{
		cc = str.charAt(i);
		cn = "";
		if (i + 1 < len)
			cn = str.charAt(i+1);

		if (cc != sep)
		{
			r[ri] += cc;
			continue;
		}

		if (cn != sep)
		{
			ri += 1;
			r[ri] = "";
		}
		else
		{
			r[ri] += sep;
			i++;
		}
	}
	return r;
}

function ClientState_Write()
{
	var r = "";
	for (var i = 0; i < this.__Field.length; ++i)
	{
		var field = this.__Field[i];
		var type  = this.__Type[i];
		var value = this[field];

		if (i == 0)
			r += field + ":";
		else
			r += "|" + field + ":";

		switch (type)
		{
			case "d":
				r += "d:" + this.EncodeDate(value);
			break;
			case "d?":
				if (value != null)
					r += "d?:" + this.EncodeDate(value);
				else
					r += "d?:";
			break;

			case "b":
				r += "b:" + (value == true ? "1" : "0");
			break;
			case "b?":
				if (value != null)
					r += "b?:" + (value == true ? "1" : "0");
				else
					r += "b?:";
			break;

			case "i":
				r += "i:" + value;
			break;
			case "i?":
				if (value != null)
					r += "i?:" + value;
				else
					r += "i?:";
			break;

			case "r":
				r += "r:" + value;
			break;
			case "r?":
				if (r != null)
					r += "r?:" + value;
				else
					r += "r?:";
			break;


			case "s":
				if (value != null)
					r += "s:." + this.Encode(value);
				else
					r += "s:";
			break;

			case "o":
			{
				var st = this.__ServerType[i];
				r += "o:" + this.Encode(st) + ":";
				if (value != null)
					r += this.Encode(value.Write());
				else
					r += "null";
			}
			break;

			case "B":
			{
				r += "B:";
				if (value != null)
				{
					r += (value.length == 0) ? "." : "+";
				
					for (var t = 0; t < value.length; t++)
					{
						if (t > 0) r += ";";
						r += value[t] == true ? "1" : "0";
					}
				}
			}
			break;

			case "I":
			{
				r += "I:";
				if (value != null)
				{
					r += (value.length == 0) ? "." : "+";
				
					for (var t = 0; t < value.length; t++)
					{
						if (t > 0) r += ";";
						r += value[t];
					}
				}
			}
			break;

			case "R":
			{
				r += "R:";
				if (value != null)
				{
					r += (value.length == 0) ? "." : "+";
				
					for (var t = 0; t < value.length; t++)
					{
						if (t > 0) r += ";";
						r += value[t];
					}
				}
			}
			break;

			case "S":
			{
				r += "S:";
				if (value != null)
				{
					r += (value.length == 0) ? "." : "+";
				
					for (var t = 0; t < value.length; t++)
					{
						if (t > 0) r += ";";
						if (value[t] != null)
							r += "." + this.Encode(value[t]);
					}
				}
			}
			break;
			
			case "D":
			{
				r += "D:";
				if (value != null)
				{
					r += (value.length == 0) ? "." : "+";
				
					for (var t = 0; t < value.length; t++)
					{
						if (t > 0) r += ";";
						r += this.EncodeDate(value[t]);
					}
				}
			}
			break;
			
			case "D?":
			{
				r += "D?:";
				if (value != null)
				{
					r += (value.length == 0) ? "." : "+";
				
					for (var t = 0; t < value.length; t++)
					{
						if (t > 0) r += ";";
						
						if (value[t] != null)
							r += this.EncodeDate(value[t]);
					}
				}
			}
			break;

			case "O":
			{
				r += "O:";
				if (value != null)
				{
					r += (value.length == 0) ? "." : "+";
				
				
					var st = this.__ServerType[i];
					r += this.Encode(st) + ":";

					for (var t = 0; t < value.length; t++)
					{
						if (t > 0) r += ";";
						if (value[t] != null)
							r += this.Encode(value[t].Write());
						else
							r += "null";
					}
				}
			}
			break;
		}
	}
	
	
	var b64 = new Base64();
	r = b64.encode(r);

	return r;
}

function ClientState_Encode(s)
{
	if (false)
	{
		s = s.replace(/\;/g, ";;");
		s = s.replace(/\|/g, "||");
		s = s.replace(/\:/g, "::");
	}
	else
	{
		s = this.EncodeSingle(s, ";");
		s = this.EncodeSingle(s, "|");
		s = this.EncodeSingle(s, ":");
	}
	return s;
}

function ClientState_EncodeSingle(s, c)
{
	var r = "";
	var p;
	for (var i = 0; i < s.length; i = p)
	{
		var p = s.indexOf(c, i);
		if (p < 0)
		{
			r += s.substr(i);
			break;
		}
		p += 1;
		r += s.substr(i, p - i) + c;
	}
	return r;
}


/*****************************************************************************\

 Javascript "Base64" library

 @version: 1.0 - 2005.11.19
 @author: Matteo Casati - http://www.guru4.net/
 @notes: first release.

\*****************************************************************************/

// static class (Base64) declaration
function Base64() {}

// publics
Base64.prototype.encode = function(s)
{
	Base64._setStr(s);
	var result = new Array();	// use array as string builder
	var inBuffer = new Array(3);
	var lineCount = 0;
	var done = false;
	while(!done && (inBuffer[0] = Base64._getStr()) != Base64._inputEnd)
	{
		inBuffer[1] = Base64._getStr();
		inBuffer[2] = Base64._getStr();
		result[result.length] = (Base64._chars[ inBuffer[0] >> 2 ]);
		if (inBuffer[1] != Base64._inputEnd)
		{
			result[result.length] = (Base64._chars [(( inBuffer[0] << 4 ) & 0x30) | (inBuffer[1] >> 4) ]);
			if (inBuffer[2] != Base64._inputEnd)
			{
				result[result.length] = (Base64._chars [((inBuffer[1] << 2) & 0x3c) | (inBuffer[2] >> 6) ]);
				result[result.length] = (Base64._chars [inBuffer[2] & 0x3F]);
			}
			else
			{
				result[result.length] = (Base64._chars [((inBuffer[1] << 2) & 0x3c)]);
				result[result.length] = ("=");
				done = true;
			}
		} 
		else
		{
			result[result.length] = (Base64._chars [(( inBuffer[0] << 4 ) & 0x30)]);
			result[result.length] = ("=");
			result[result.length] = ("=");
			done = true;
		}
		lineCount += 4;
		if (lineCount >= 76)
		{
			result[result.length] = ("\n");
			lineCount = 0;
		}
	}
	return result.join("");
}

Base64.prototype.decode = function(s)
{
	Base64._setStr(s);
	var result = new Array();	// use array as string builder
	var inBuffer = new Array(4);
	var done = false;
	while (!done && (inBuffer[0] = Base64._getReverse()) != Base64._inputEnd && (inBuffer[1] = Base64._getReverse()) != Base64._inputEnd)
	{
		inBuffer[2] = Base64._getReverse();
		inBuffer[3] = Base64._getReverse();
		result[result.length] = Base64._n2s((((inBuffer[0] << 2) & 0xff)| inBuffer[1] >> 4));
		if(inBuffer[2] != Base64._inputEnd)
		{
			result[result.length] = Base64._n2s((((inBuffer[1] << 4) & 0xff)| inBuffer[2] >> 2));
			if (inBuffer[3] != Base64._inputEnd)
				result[result.length] = Base64._n2s((((inBuffer[2] << 6)  & 0xff) | inBuffer[3]));
			else 
				done = true;
		}
		else
			done = true;
	}
	return result.join("");
}

// privates
Base64._inputEnd = -1;
Base64._chars = new Array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9","+","/");
Base64._reverseChars = new Array();
for(var i = 0; i < Base64._chars.length; i++)
    Base64._reverseChars[Base64._chars[i]] = i;
Base64._str = "";
Base64._count = 0;
Base64._setStr = function(s)
{
    Base64._str = s;
    Base64._count = 0;
}
Base64._getStr = function()
{    
    if(!Base64._str) 
		return Base64._inputEnd;
    if(Base64._count >= Base64._str.length) 
		return Base64._inputEnd;
    var c = Base64._str.charCodeAt(Base64._count) & 0xff;
    Base64._count++;
    return c;
}
Base64._getReverse = function()
{   
    if(!Base64._str)
		return Base64._inputEnd;
    while(true)
    {      
        if(Base64._count >= Base64._str.length) 
			return Base64._inputEnd;
        var nextCharacter = Base64._str.charAt(Base64._count);
        Base64._count++;
        if(Base64._reverseChars[nextCharacter])
            return Base64._reverseChars[nextCharacter];
        if (nextCharacter == "A") 
			return 0;
    }
    return Base64._inputEnd;
}
Base64._n2s = function(n)
{
    n = n.toString(16);
    if(n.length == 1)
		n = "0" + n;
    n = "%" + n;
    return unescape(n);
}
