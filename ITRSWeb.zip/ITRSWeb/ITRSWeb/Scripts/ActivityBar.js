﻿function ActivityBar(id, okImage, failImage)
{
	this._id = id;
	this._okImage = okImage;
	this._failImage = failImage;
	this._n = 1;
	this.timerID = null;
}
ActivityBar.prototype = {
	Init : function(idParent)
	{
		if (typeof(idParent) == "undefined")
		{
			document.write("<table><tr>");
			for (var idx = 0; idx < 3; idx++)
			{
				if (idx == 0)
				{
					var s = "<td><img id='" + this._id + idx + "' alt='OK' src='" + this._okImage + "' /></td>";
					document.write(s);
				}
				else
				{
					var s = "<td><img id='" + this._id + idx + "' alt='Fail' src='" + this._failImage + "' /></td>";
					document.write(s);
				}
			}
			document.write("</tr></table>");
		}
		else
		{
			var par = document.getElementById(idParent);
			var s = "<table><tr>";
			for (var idx = 0; idx < 3; idx++)
			{
				if (idx == 0)
					s += "<td><img id='" + this._id + idx + "' alt='OK' src='" + this._okImage + "' /></td>";
				else
					s += "<td><img id='" + this._id + idx + "' alt='Fail' src='" + this._failImage + "' /></td>";
			}
			s += "</tr></table>";
			
			par.innerHTML = s;
		}
		
		
		this._okImage   = document.getElementById(this._id + 0).src;
		this._failImage = document.getElementById(this._id + 1).src;
		
		this.SetImage(true);
		
		var cb = this;
		this.timerID = window.setTimeout(function() { cb.OnTimeout('visible'); }, 1000 * 30);
	},
	
	SetImage : function(ok, visibility)
	{
		if (ok)
		{
			for (var idx = 0; idx < 3; ++idx)
			{
				var img = document.getElementById(this._id + idx);
				if (img.src != this._okImage) img.src = this._okImage;
				if (this._n == 1 || this._n == 3)
					img.style.visibility = (idx == 1) ? "visible" : "hidden";
				else
					img.style.visibility = (idx == this._n) ? "visible" : "hidden";
			}
		}
		else
		{
			for (var idx = 0; idx < 3; ++idx)
			{
				var img = document.getElementById(this._id + idx);
				if (img.src != this._failImage) img.src = this._failImage;
				img.style.visibility = visibility;
			}
		}
	},
	
	Toggle : function()
	{
		if (this.timerID != null) 
		{
			window.clearTimeout(this.timerID);
			this.timerID = null;
		}
		
		this._n = (this._n + 1) % 4;
		this.SetImage(true);
		
		var cb = this;
		this.timerID = window.setTimeout(function() { cb.OnTimeout("visible"); }, 1000 * 30);
	},
	
	OnTimeout : function(visibility)
	{
		if (this.timerID != null) 
		{
			window.clearTimeout(this.timerID);
			this.timerID = null;
		}
	
		this.SetImage(false, visibility);
		
		var cb = this;
		var newVisibility = (visibility == "visible") ? "hidden" : "visible";
		this.timerID = window.setTimeout(function() { cb.OnTimeout(newVisibility); }, 500);
	}
};
