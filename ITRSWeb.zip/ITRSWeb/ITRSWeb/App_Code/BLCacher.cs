using System;
using System.Data;
using System.IO;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.Caching;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ITRS_BL;



public static class BLCacher
{
	/// <summary>
	/// Inserisce nella <c>DropDownList d</c> tutti i C2P presenti nel DB.
	/// La query nel DB viene cachata per 1 ora.
	/// </summary>
	/// <param name="d">la DropDownList da riempire</param>
	public static void FillFromC2P(DropDownList d)
	{
		FillFromC2P(d, null);
	}

	/// <summary>
	/// Inserisce nella <c>DropDownList d</c> tutti i C2P presenti nel DB.
	/// La query nel DB viene cachata per 1 ora.
	/// <c>defaultListItem</c> se valorizzato permete di mettere in testa alla lista un item di default.
	/// </summary>
	/// <param name="d">la DropDownList da riempire</param>
	/// <param name="defaultListItem">l'eventuale item in testa alla lista.</param>
	public static void FillFromC2P(DropDownList d, ListItem defaultListItem)
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			if (Cache["listaC2P"] == null)
			{
				using (BLC2P bl = new BLC2P())
				{
					List<KeyDescription<int>> ch = bl.GetListaKeyDescription();
					CacheAdd("listaC2P", ch);
				}
			}
			List<KeyDescription<int>> lst = (List<KeyDescription<int>>)Cache["listaC2P"];

			if (defaultListItem != null)
				d.Items.Add(defaultListItem);

			foreach (KeyDescription<int> c in lst)
				d.Items.Add(new ListItem(c.Description, c.Code.ToString()));
		}
		catch (Exception ex)
		{
			Log.Write(ex, "FillFromC2P");
			throw;
		}
	}

	public static List<Coa> GetListaCOA()
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			List<Coa> ch = Cache["listaCOA"] as List<Coa>;
			if (ch == null)
			{
				BLCoa bl = new BLCoa();
				ch = bl.GetListaCOACB();
				CacheAdd("listaCOA", ch);
			}
			return ch;
		}
		catch (Exception ex)
		{
			Log.Write(ex, "GetListaCOA");
			throw;
		}
	}


	public static string GetDescrizioneCOA(int idCoa)
	{
		List<Coa> r = GetListaCOA();
		foreach (Coa c in r)
		{
			if (c.IdCOA == idCoa)
				return c.Descrizione;
		}
		return idCoa.ToString();
	}

	public static List<BLLTS.UtenteRichiedente> GetListaUtenteRichiedentePerRicercaLTS()
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			List<BLLTS.UtenteRichiedente> ch = Cache["ListaUtenteRichiedentePerRicercaLTS"] as List<BLLTS.UtenteRichiedente>;
			if (ch == null)
			{
				BLLTS bl = new BLLTS();
				ch = bl.GetListaUtentiRichiedenti();
				CacheAddForMinutes("ListaUtenteRichiedentePerRicercaLTS", ch, 5);
			}
			return ch;
		}
		catch (Exception ex)
		{
			Log.Write(ex, "GetListaUtenteRichiedentePerRicercaLTS");
			throw;
		}
	}

	public static List<BLSorveglianza.TransitoSegnalatoSorveglianza> BLSorveglianza_GetListaSorveglianza(int cacheSecTimeout, int idCoa, BLSorveglianza.SorvTipoLTS tipoSorv)
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			string key = string.Format("BLSorveglianza_GetListaSorveglianza_{0}_{1}", idCoa, tipoSorv.ToString());

			List<BLSorveglianza.TransitoSegnalatoSorveglianza> ret = Cache[key] as List<BLSorveglianza.TransitoSegnalatoSorveglianza>;
			if (ret == null)
			{
				using (BLSorveglianza bl = new BLSorveglianza())
				{
					ret = bl.GetListaSorveglianza(idCoa, tipoSorv);
					CacheAddForSeconds(key, ret, cacheSecTimeout);
				}
			}
			return ret;
		}
		catch (Exception ex)
		{
			Log.Write(ex, "BLSorveglianza_GetListaSorveglianza");
			throw;
		}
	}

	//public static void BLSorveglianza_Invalidate_ListaSorveglianza(int idCoa)
	//{
	//    string key = string.Format("BLSorveglianza_GetListaSorveglianza_{0}", idCoa);
	//    CacheInvalidateWidhFileDep(key);
	//}


	public static BLSorveglianza.TransitoSegnalatoPrecedente BLSorveglianza_GetTransitoSegnalatoPrecedente(TimeSpan ts, string targa, string nazionalita, DateTime dataOraRilevamento)
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			string key = string.Format("BLSorveglianza_GetTransitoSegnalatoPrecedente_{0}_{1}_{2:yyyy}{2:MM}{2:dd}{2:HH}{2:mm}{2:ss}", targa, nazionalita, dataOraRilevamento);

			List<BLSorveglianza.TransitoSegnalatoPrecedente> lst;

			lst = Cache[key] as List<BLSorveglianza.TransitoSegnalatoPrecedente>;
			if (lst == null)
			{
				using (BLSorveglianza bl = new BLSorveglianza())
				{
					lst = new List<BLSorveglianza.TransitoSegnalatoPrecedente>();
					BLSorveglianza.TransitoSegnalatoPrecedente tp = bl.GetTransitoSegnalatoPrecedente(targa, nazionalita, dataOraRilevamento);
					if (tp != null)
						lst.Add(tp);

					CacheAddForTimeSpan(key, lst, ts);
				}
			}

			if (lst.Count == 0) return null;
			return lst[0];
		}
		catch (Exception ex)
		{
			Log.Write(ex, "BLSorveglianza_GetListaSorveglianza");
			throw;
		}
	}



	public static SytemDiagnostic BLC2P_RefreshDiagnostica(int cacheSecTimeout, int idCoa)
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			string key = string.Format("BLC2P_RefreshDiagnostica_{0}", idCoa);
			SytemDiagnostic ret = Cache[key] as SytemDiagnostic;
			if (ret == null)
			{
				using (BLC2P b = new BLC2P())
				{
					ret = b.RefreshDiagnostica(idCoa);
					CacheAddForSeconds(key, ret, cacheSecTimeout);
				}
			}
			return ret;
		}
		catch (Exception ex)
		{
			Log.Write(ex, "BLC2P_RefreshDiagnostica");
			throw;
		}
	}


	/// <summary>
	/// Inserisce nella Cache di asp.net il <c>value</c> con chiave <c>key</c> 
	/// </summary>
	/// <param name="Cache"></param>
	/// <param name="key"></param>
	/// <param name="value"></param>
	private static void CacheAdd(string key, object value)
	{
		Cache Cache = HttpContext.Current.Cache;
		Cache.Insert(key, value, null, DateTime.Now.AddHours(1), Cache.NoSlidingExpiration);
	}

	private static void CacheAddForMinutes(string key, object value, int minutiNellaCache)
	{
		Cache Cache = HttpContext.Current.Cache;
		Cache.Insert(key, value, null, DateTime.Now.AddMinutes(minutiNellaCache), Cache.NoSlidingExpiration);
	}

	private static void CacheAddForSeconds(string key, object value, int secondiNellaCache)
	{
		Cache Cache = HttpContext.Current.Cache;
		Cache.Insert(key, value, null, DateTime.Now.AddSeconds(secondiNellaCache), Cache.NoSlidingExpiration);
	}

	/*
	/// <summary>
	/// Mette nella cache l'oggetto specificando la dipendenza da un file
	/// ottenuto direttamente dalla key ossia /ITRSWeb/CacheDep/[key].dep
	/// Non e` necessario che il file esista ! Il primo che lo crea invalidta la cache!
	/// </summary>
	/// <param name="key"></param>
	/// <param name="value"></param>
	/// <param name="secondiNellaCache"></param>
	private static void CacheAddForSecondsWithFileDep(string key, object value, int secondiNellaCache)
	{
		Cache Cache = HttpContext.Current.Cache;

		string path = HttpContext.Current.Server.MapPath("/ITRSweb/CacheDep");
		string fn = Path.Combine(path, key + ".dep");

		// creo il file NON perche` sia necessario per la cache depency
		// ma per fare "debugging" in BL_Cacher: quando arriva il pacchetto
		// UPD che indica nel messaggio un file che non esiste ho un baco !
		if (!File.Exists(fn))
		{
			using (StreamWriter ws = File.CreateText(fn)) { }
		}

		CacheDependency cdep = new CacheDependency(fn);
		Cache.Insert(key, value, cdep, DateTime.Now.AddSeconds(secondiNellaCache), Cache.NoSlidingExpiration);
	}
	private static void CacheInvalidateWidhFileDep(string key)
	{
		// A rigori non serve !!! e` il server BL_Cacher che si occupa di invalidare la cache!
		//Cache Cache = HttpContext.Current.Cache;
		//Cache.Remove(key);

		try
		{
			string groupAddr = ReadAppSettings.ToString("ITRS.InvalidateCache.GroupAddr", "224.211.45.5");
			int groupPort = ReadAppSettings.ToInt32("ITRS.InvalidateCache.GroupPort", 12084);

			byte[] msg = System.Text.Encoding.UTF8.GetBytes(key);
			Network.UDP.Multicast.Send(groupAddr, groupPort, msg);
		}
		catch (Exception ex)
		{
			Log.Write(ex, "CacheInvalidateWidhFileDep");
		}

	}
	public delegate R MethodToCache<R>();
	public delegate R MethodToCache<R, A>(A a);
	public delegate R MethodToCache<R, A, B>(A a, B b);
	public static R CacheMethod<R>(string key, TimeSpan ts, MethodToCache<R> m) where R : class
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;
			R ret = Cache[key] as R;
			if (ret == null)
			{
				ret = m();
				CacheAddForTimeSpan(key, ret, ts);
			}
			return ret;
		}
		catch (Exception ex)
		{
			Log.Write(ex, string.Format("CacheMethod {0}", key));
			throw;
		}
	}
	public static R CacheMethod<R, A>(string key, TimeSpan ts, MethodToCache<R, A> m, A a) where R : class
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			R ret = Cache[key] as R;
			if (ret == null)
			{
				ret = m(a);
				CacheAddForTimeSpan(key, ret, ts);
			}
			return ret;
		}
		catch (Exception ex)
		{
			Log.Write(ex, string.Format("CacheMethod {0}", key));
			throw;
		}
	}
	public static R CacheMethod<R, A, B>(string key, TimeSpan ts, MethodToCache<R, A, B> m, A a, B b) where R : class
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			R ret = Cache[key] as R;
			if (ret == null)
			{
				ret = m(a, b);
				CacheAddForTimeSpan(key, ret, ts);
			}
			return ret;
		}
		catch (Exception ex)
		{
			Log.Write(ex, string.Format("CacheMethod {0}", key));
			throw;
		}
	}
	*/

	public static void CacheAddForTimeSpan(string key, object value, TimeSpan ts)
	{
		Cache Cache = HttpContext.Current.Cache;
		DateTime dt = DateTime.Now.Add(ts);
		Cache.Insert(key, value, null, dt, Cache.NoSlidingExpiration);
	}

	public static byte[] BLTransiti_GetBlobImmagine(string targa, string nazionalita, DateTime dataOraRilevamento)
	{
		bool imgInC2P;
		return BLTransiti_GetBlobImmagine(targa, nazionalita, dataOraRilevamento, out imgInC2P);
	}


	public static byte[] BLTransiti_GetBlobImmagine(string targa, string nazionalita, DateTime dataOraRilevamento, out bool imgInC2P)
	{
		Cache Cache = HttpContext.Current.Cache;

		string key = string.Format("BLTransiti_GetBlobImmagine_{0}_{1}_{2:yyyy}{2:MM}{2:dd}{2:HH}{2:mm}{2:ss}", targa, nazionalita, dataOraRilevamento);

		byte[] r = Cache[key] as byte[];

		if (Cache[key] == null)
		{
			BLTransiti bl = new BLTransiti();
			r = bl.GetBlobImmagine(targa, nazionalita, dataOraRilevamento, out imgInC2P);
			if (r != null && r.Length > 0)
				CacheAddForMinutes(key, r, 5);
		}
		else
			imgInC2P = false;

		return r;
	}

	public static DatiTarga BLTransiti_GetDatiTarga(string targa, string nazionalita, DateTime dataOraRilevamento)
	{
		try
		{
			Cache Cache = HttpContext.Current.Cache;

			string key = string.Format("BLTransiti_GetDatiTarga_{0}_{1}_{2:yyyy}{2:MM}{2:dd}{2:HH}{2:mm}{2:ss}", targa, nazionalita, dataOraRilevamento);

			List<DatiTarga> r = Cache[key] as List<DatiTarga>;
			if (r == null)
			{
				r = new List<DatiTarga>(1);
				using (BLTransiti bl = new BLTransiti())
				{
					DatiTarga dt = bl.GetDatiTarga(targa, nazionalita, dataOraRilevamento);
					if (dt != null)
						r.Add(dt);
				}
				CacheAddForMinutes(key, r, 5);
			}

			if (r.Count == 0) return null;
			return r[0];
		}
		catch
		{
			// se c'e` errore NON li faccio vedere.
			return null;
		}
	}

	static public List<BLLTSImport.Nazione> GetListaNazioni()
	{
		Cache Cache = HttpContext.Current.Cache;

		string key = "ListaNazioni";

		List<BLLTSImport.Nazione> r = Cache[key] as List<BLLTSImport.Nazione>;

		if (Cache[key] == null)
		{
			BLLTSImport bl = new BLLTSImport();
			r = bl.GetListaNazioni();
			CacheAdd(key, r);
		}
		return r;
	}

}
