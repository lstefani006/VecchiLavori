using System.Web.Security;
using System.Configuration.Provider;
using System.Collections.Specialized;
using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.Web;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Web.Configuration;
using System.Web.Hosting;

#if USA_ORACLE_PER_MICROSOFT

using System.Data.OracleClient;
/*
CREATE TABLE ITRS.AspNet_Users
(
  PKID                                   varchar2(36)   default '' NOT NULL ,
  Username                               nvarchar2(25)  default '' NOT NULL,
  ApplicationName                        varchar2(25)   default '' NOT NULL,
  Email                                  nvarchar2(100) default '' NOT NULL,
  UserComments                           nvarchar2(255) default NULL,
  UserPassword                           nvarchar2(25)  default '' NOT NULL ,
  PasswordQuestion                       nvarchar2(255) default NULL,
  PasswordAnswer                         nvarchar2(255) default NULL,
  IsApproved                             number(1)      default NULL,
  LastActivityDate                       date           default NULL,
  LastLoginDate                          date           default NULL,
  LastPasswordChangedDate                date           default NULL,
  CreationDate                           date           default NULL,
  IsOnLine                               number(1)      default NULL,
  IsLockedOut                            number(1)      default NULL,
  LastLockedOutDate                      date           default NULL,
  FailedPwdAttemptCount                  number(8)      default NULL,
  FailedPwdAttemptWinStart               date           default NULL,
  FailedPwdAnswAttemptCount              number(8)      default NULL,
  FailedPwdAnswAttemptWinStart           date           default NULL,

  PRIMARY KEY(PKID)
) tablespace ITRS_DATA

ALTER TABLE usersinroles ADD INDEX ( PKID  ) ;
*/

/*
 * IsApproved		e` il flag che permette all'amministratore di sistema di concedere l'accesso o no al singolo utente
 * IsLockedOut		e` il flag che viene impostato dopo un tot numero di accessi errato ad una data login
 */




public sealed class OracleMembershipProvider : MembershipProvider
{
	//
	// Global connection string, generated password length, generic exception message, event log info.
	//
	private int newPasswordLength = 8;
	private string eventSource = "OracleMembershipProvider";
	private string eventLog = "Application";
	private string exceptionMessage = "An exception occurred. Please check the Event Log.";
	private string tableName = "AspNet_Users";
	private string connectionString;

	private const string encryptionKey = "AE09F72B007CAAB5";

	//
	// If false, exceptions are thrown to the caller. If true,
	// exceptions are written to the event log.
	//
	private bool _WriteExceptionsToEventLog;

	public bool WriteExceptionsToEventLog
	{
		get { return _WriteExceptionsToEventLog; }
		set { _WriteExceptionsToEventLog = value; }
	}


	//
	// System.Configuration.Provider.ProviderBase.Initialize Method
	//
	public override void Initialize(string name, NameValueCollection config)
	{
		//
		// Initialize values from web.config.
		//
		if (config == null)
			throw new ArgumentNullException("config");

		if (name == null || name.Length == 0)
			name = "OracleMembershipProvider";

		if (String.IsNullOrEmpty(config["description"]))
		{
			config.Remove("description");
			config.Add("description", "Sample Oracle Membership provider");
		}

		// Initialize the abstract base class.
		base.Initialize(name, config);

		_ApplicationName = GetConfigValue(config["applicationName"], HostingEnvironment.ApplicationVirtualPath);
		_MaxInvalidPasswordAttempts = Convert.ToInt32(GetConfigValue(config["maxInvalidPasswordAttempts"], "5"));
		_PasswordAttemptWindow = Convert.ToInt32(GetConfigValue(config["passwordAttemptWindow"], "10"));
		_MinRequiredNonAlphanumericCharacters = Convert.ToInt32(GetConfigValue(config["minRequiredNonAlphanumericCharacters"], "1"));
		_MinRequiredPasswordLength = Convert.ToInt32(GetConfigValue(config["minRequiredPasswordLength"], "7"));
		_PasswordStrengthRegularExpression = Convert.ToString(GetConfigValue(config["passwordStrengthRegularExpression"], ""));
		_EnablePasswordReset = Convert.ToBoolean(GetConfigValue(config["enablePasswordReset"], "true"));
		_EnablePasswordRetrieval = Convert.ToBoolean(GetConfigValue(config["enablePasswordRetrieval"], "true"));
		_RequiresQuestionAndAnswer = Convert.ToBoolean(GetConfigValue(config["requiresQuestionAndAnswer"], "false"));
		_RequiresUniqueEmail = Convert.ToBoolean(GetConfigValue(config["requiresUniqueEmail"], "true"));
		_WriteExceptionsToEventLog = Convert.ToBoolean(GetConfigValue(config["writeExceptionsToEventLog"], "true"));
		_RequiresClientCertificate = Convert.ToBoolean(GetConfigValue(config["requiresClientCertificate"], "true"));

		string temp_format = config["passwordFormat"];
		if (temp_format == null)
			temp_format = "Hashed";

		switch (temp_format)
		{
		case "Hashed":
			_PasswordFormat = MembershipPasswordFormat.Hashed;
			break;
		case "Encrypted":
			_PasswordFormat = MembershipPasswordFormat.Encrypted;
			break;
		case "Clear":
			_PasswordFormat = MembershipPasswordFormat.Clear;
			break;
		default:
			throw new ProviderException("Password format not supported.");
		}

		//
		// Initialize OracleConnection.
		//

		ConnectionStringSettings ConnectionStringSettings =
		  ConfigurationManager.ConnectionStrings[config["connectionStringName"]];

		if (ConnectionStringSettings == null || ConnectionStringSettings.ConnectionString.Trim() == "")
		{
			throw new ProviderException("Connection string cannot be blank.");
		}

		connectionString = ConnectionStringSettings.ConnectionString;


	}

	private static string GetConfigValue(string configValue, string defaultValue)
	{
		if (String.IsNullOrEmpty(configValue))
			return defaultValue;
		return configValue;
	}


	//
	// System.Web.Security.MembershipProvider properties.
	//
	private string _ApplicationName;
	private bool _EnablePasswordReset;
	private bool _EnablePasswordRetrieval;
	private bool _RequiresQuestionAndAnswer;
	private bool _RequiresUniqueEmail;
	private int _MaxInvalidPasswordAttempts;
	private int _PasswordAttemptWindow;
	private MembershipPasswordFormat _PasswordFormat;
	private int _MinRequiredNonAlphanumericCharacters;
	private int _MinRequiredPasswordLength;
	private string _PasswordStrengthRegularExpression;
	private bool _RequiresClientCertificate;


	public override string ApplicationName
	{
		get { return _ApplicationName; }
		set { _ApplicationName = value; }
	}

	public override bool EnablePasswordReset { get { return _EnablePasswordReset; } }
	public override bool EnablePasswordRetrieval { get { return _EnablePasswordRetrieval; } }
	public override bool RequiresQuestionAndAnswer { get { return _RequiresQuestionAndAnswer; } }
	public override bool RequiresUniqueEmail { get { return _RequiresUniqueEmail; } }
	public override int MaxInvalidPasswordAttempts { get { return _MaxInvalidPasswordAttempts; } }
	public override int PasswordAttemptWindow { get { return _PasswordAttemptWindow; } }
	public override MembershipPasswordFormat PasswordFormat { get { return _PasswordFormat; } }
	public override int MinRequiredNonAlphanumericCharacters { get { return _MinRequiredNonAlphanumericCharacters; } }
	public override int MinRequiredPasswordLength { get { return _MinRequiredPasswordLength; } }
	public override string PasswordStrengthRegularExpression { get { return _PasswordStrengthRegularExpression; } }

	/// <summary>
	/// LS: Added property for client certificate.
	/// </summary>
	public bool RequiresClientCertificate { get { return _RequiresClientCertificate; } }

	//
	// MembershipProvider.ChangePassword
	//
	public override bool ChangePassword(string username, string oldPwd, string newPwd)
	{
		if (!ValidateUser(username, oldPwd))
			return false;

		ValidatePasswordEventArgs args = new ValidatePasswordEventArgs(username, newPwd, true);

		OnValidatingPassword(args);

		if (args.Cancel)
			if (args.FailureInformation != null)
				throw args.FailureInformation;
			else
				throw new MembershipPasswordException("Change password canceled due to new password validation failure.");


		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("UPDATE " + tableName + " " +
				" SET UserPassword = :UserPassword, LastPasswordChangedDate = :LastPasswordChangedDate " +
				" WHERE Username = :Username AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":UserPassword", EncodePassword(newPwd));
		cmd.Parameters.AddWithValue(":LastPasswordChangedDate", DateTime.Now);
		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

		int rowsAffected = 0;

		try
		{
			conn.Open();

			rowsAffected = cmd.ExecuteNonQuery();
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "ChangePassword");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		if (rowsAffected > 0)
		{
			return true;
		}

		return false;
	}



	//
	// MembershipProvider.ChangePasswordQuestionAndAnswer
	//
	public override bool ChangePasswordQuestionAndAnswer(string username,
				  string password,
				  string newPwdQuestion,
				  string newPwdAnswer)
	{
		if (!ValidateUser(username, password))
			return false;

		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("UPDATE " + tableName + " " +
				" SET PasswordQuestion = :Question, PasswordAnswer = :Answer" +
				" WHERE Username = :Username AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":Question", newPwdQuestion);
		cmd.Parameters.AddWithValue(":Answer", EncodePassword(newPwdAnswer));
		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);


		int rowsAffected = 0;

		try
		{
			conn.Open();
			rowsAffected = cmd.ExecuteNonQuery();
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "ChangePasswordQuestionAndAnswer");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		if (rowsAffected > 0)
		{
			return true;
		}

		return false;
	}

	private void CreateUserInternal(
		OracleTransaction tr,

		string username,
		string password,
		string email,
		string passwordQuestion,
		string passwordAnswer,
		bool isApproved,
		ref object providerUserKey,
		string userComments,
		out MembershipCreateStatus status)
	{
		ValidatePasswordEventArgs args = new ValidatePasswordEventArgs(username, password, true);

		OnValidatingPassword(args);

		if (args.Cancel)
		{
			status = MembershipCreateStatus.InvalidPassword;
			return;
		}

		if (RequiresUniqueEmail && GetUserNameByEmail(email) != "")
		{
			status = MembershipCreateStatus.DuplicateEmail;
			return;
		}

		MembershipUser u = GetUser(username, false);

		if (u != null)
		{
			status = MembershipCreateStatus.DuplicateUserName;
			return;
		}

		DateTime createDate = DateTime.Now;

		if (providerUserKey == null)
			providerUserKey = Guid.NewGuid();
		else
		{
			if (!(providerUserKey is Guid))
			{
				status = MembershipCreateStatus.InvalidProviderUserKey;
				return;
			}
		}

		OracleCommand cmd = new OracleCommand("INSERT INTO " + tableName +
			  " (PKID, Username, UserPassword, Email, PasswordQuestion, " +
			  " PasswordAnswer, IsApproved," +
			  " UserComments, CreationDate, LastPasswordChangedDate, LastActivityDate," +
			  " ApplicationName, IsLockedOut, LastLockedOutDate," +
			  " FailedPwdAttemptCount, FailedPwdAttemptWinStart, " +
			  " FailedPwdAnswAttemptCount, FailedPwdAnswAttemptWinStart)" +
			  " Values(:PKID, :Username, :UserPassword, :Email, :PasswordQuestion, " +
			  " :PasswordAnswer, :IsApproved, :UserComments, :CreationDate, :LastPasswordChangedDate, " +
			  " :LastActivityDate, :ApplicationName, :IsLockedOut, :LastLockedOutDate, " +
			  " :FailedPwdAttemptCount, :FailedPwdAttemptWinStart, " +
			  " :FailedPwdAnswAttemptCount, :FailedPwdAnswAttemptWinStart)", tr.Connection);

		cmd.Transaction = tr;

		if (string.IsNullOrEmpty(email))
			email = "?";

		cmd.Parameters.AddWithValue(":PKID", providerUserKey.ToString());
		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":UserPassword", EncodePassword(password));
		cmd.Parameters.AddWithValue(":Email", email);
		cmd.Parameters.AddWithValue(":PasswordQuestion", passwordQuestion);
		cmd.Parameters.AddWithValue(":PasswordAnswer", passwordAnswer == null ? null : EncodePassword(passwordAnswer));
		cmd.Parameters.AddWithValue(":IsApproved", isApproved ? 1 : 0);
		cmd.Parameters.AddWithValue(":UserComments", userComments);
		cmd.Parameters.AddWithValue(":CreationDate", createDate);
		cmd.Parameters.AddWithValue(":LastPasswordChangedDate", createDate);
		cmd.Parameters.AddWithValue(":LastActivityDate", createDate);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);
		cmd.Parameters.AddWithValue(":IsLockedOut", 0); //false
		cmd.Parameters.AddWithValue(":LastLockedOutDate", createDate);
		cmd.Parameters.AddWithValue(":FailedPwdAttemptCount", 0);
		cmd.Parameters.AddWithValue(":FailedPwdAttemptWinStart", createDate);
		cmd.Parameters.AddWithValue(":FailedPwdAnswAttemptCount", 0);
		cmd.Parameters.AddWithValue(":FailedPwdAnswAttemptWinStart", createDate);

		try
		{
			int recAdded = cmd.ExecuteNonQuery();

			if (recAdded > 0)
				status = MembershipCreateStatus.Success;
			else
				status = MembershipCreateStatus.UserRejected;
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
				WriteToEventLog(e, "CreateUser");

			status = MembershipCreateStatus.ProviderError;
		}
	}


	public override MembershipUser CreateUser(string username,
			 string password,
			 string email,
			 string passwordQuestion,
			 string passwordAnswer,
			 bool isApproved,
			 object providerUserKey,
			 out MembershipCreateStatus status)
	{
		using (OracleConnection cn = new OracleConnection(connectionString))
		{
			cn.Open();

			using (OracleTransaction tr = cn.BeginTransaction())
			{
				CreateUserInternal(
					tr,
					username,
					password,
					email,
					passwordQuestion,
					passwordAnswer,
					isApproved,
					ref providerUserKey,
					"", // userComments
					out status);

				if (status == MembershipCreateStatus.Success)
					tr.Commit();

			}

			return GetUser(username, false);
		}
	}

	//
	// MembershipProvider.DeleteUser
	//
	public override bool DeleteUser(string username, bool deleteAllRelatedData)
	{
		MembershipUser u = GetUser(username, false);
		if (u == null)
			return false;

		using (OracleConnection conn = new OracleConnection(connectionString))
		{
			conn.Open();

			using (OracleTransaction tr = conn.BeginTransaction())
			{
				try
				{
					int rows = 0;

					using (OracleCommand cmd = conn.CreateCommand())
					{
						cmd.Transaction = tr;
						cmd.CommandText = "delete from aspnet_userprofile where pkid = :k";
						cmd.Parameters.AddWithValue(":k", u.ProviderUserKey.ToString());
						rows = cmd.ExecuteNonQuery();
					}

					using (OracleCommand cmd = conn.CreateCommand())
					{
						cmd.Transaction = tr;
						cmd.CommandText = " delete from aspnet_usersinroles where username = :k";
						cmd.Parameters.AddWithValue(":k", username);
						rows = cmd.ExecuteNonQuery();
					}


					using (OracleCommand cmd = conn.CreateCommand())
					{
						cmd.Transaction = tr;
						cmd.CommandText = "delete from aspnet_users where username = :k";
						cmd.Parameters.AddWithValue(":k", username);
						rows = cmd.ExecuteNonQuery();
					}

					if (rows >= 1)
					{
						tr.Commit();
						return true;
					}
				}
				catch (OracleException e)
				{
					if (e.Code == 2292)
						return false;

					throw e;
				}
			}

			return false;
		}
	}



	//
	// MembershipProvider.GetAllUsers
	//
	public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
	{
		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("SELECT Count(*) FROM " + tableName +
										  " WHERE ApplicationName = :ApplicationName", conn);
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		MembershipUserCollection users = new MembershipUserCollection();

		OracleDataReader reader = null;
		totalRecords = 0;

		try
		{
			conn.Open();
			totalRecords = Convert.ToInt32(cmd.ExecuteScalar());

			if (totalRecords <= 0) { return users; }

			cmd.CommandText =
				"SELECT PKID, Username, Email, PasswordQuestion," +
				" UserComments, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
				" LastActivityDate, LastPasswordChangedDate, LastLockedOutDate " +
				" FROM " + tableName + " " +
				" WHERE ApplicationName = :ApplicationName " +
				" ORDER BY Username Asc";
			cmd.Parameters.Clear();
			cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

			using (reader = cmd.ExecuteReader())
			{
				int counter = 0;
				int startIndex = pageSize * pageIndex;
				int endIndex = startIndex + pageSize - 1;

				ReaderOrdinal ro = new ReaderOrdinal(reader);

				while (reader.Read())
				{
					if (counter >= startIndex)
					{
						MembershipUser u = GetUserFromReader(reader, ro);
						users.Add(u);
					}

					if (counter >= endIndex) { cmd.Cancel(); }

					counter++;
				}
				reader.Close();
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "GetAllUsers");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			if (reader != null) { reader.Close(); }
			conn.Close();
		}

		return users;
	}


	//
	// MembershipProvider.GetNumberOfUsersOnline
	//
	public override int GetNumberOfUsersOnline()
	{

		TimeSpan onlineSpan = new TimeSpan(0, System.Web.Security.Membership.UserIsOnlineTimeWindow, 0);
		DateTime compareTime = DateTime.Now.Subtract(onlineSpan);

		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("SELECT Count(*) FROM " + tableName +
				" WHERE LastActivityDate > :CompareDate AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":CompareDate", compareTime);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

		int numOnline = 0;

		try
		{
			conn.Open();

			numOnline = Convert.ToInt32(cmd.ExecuteScalar());
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "GetNumberOfUsersOnline");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		return numOnline;
	}



	//
	// MembershipProvider.GetPassword
	//
	public override string GetPassword(string username, string answer)
	{
		if (!EnablePasswordRetrieval)
		{
			throw new ProviderException("Password Retrieval Not Enabled.");
		}

		if (PasswordFormat == MembershipPasswordFormat.Hashed)
		{
			throw new ProviderException("Cannot retrieve Hashed passwords.");
		}

		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("SELECT UserPassword, PasswordAnswer, IsLockedOut FROM " + tableName +
			  " WHERE Username = :Username AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

		string password = "";
		string passwordAnswer = "";
		OracleDataReader reader = null;

		try
		{
			conn.Open();

			using (reader = cmd.ExecuteReader(CommandBehavior.SingleRow))
			{
				if (reader.HasRows)
				{
					reader.Read();

					if (reader.GetInt32(2) > 0)
						throw new MembershipPasswordException("The supplied user is locked out.");

					password = reader.GetString(0);
					passwordAnswer = reader.GetString(1);
				}
				else
				{
					throw new MembershipPasswordException("The supplied user name is not found.");
				}
				reader.Close();
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "GetPassword");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			if (reader != null) { reader.Close(); }
			conn.Close();
		}


		if (RequiresQuestionAndAnswer && !CheckPassword(answer, passwordAnswer))
		{
			UpdateFailureCount(username, "passwordAnswer");

			throw new MembershipPasswordException("Incorrect password answer.");
		}


		if (PasswordFormat == MembershipPasswordFormat.Encrypted)
		{
			password = UnEncodePassword(password);
		}

		return password;
	}



	//
	// MembershipProvider.GetUser(string, bool)
	//
	public override MembershipUser GetUser(string username, bool userIsOnline)
	{
		try
		{
			using (OracleConnection conn = new OracleConnection(connectionString))
			{
				conn.Open();

				MembershipUser u = null;

				using (OracleCommand cmd = new OracleCommand("SELECT PKID, Username, Email, PasswordQuestion," +
					 " UserComments, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
					 " LastActivityDate, LastPasswordChangedDate, LastLockedOutDate" +
					 " FROM " + tableName + " WHERE Username = :Username AND ApplicationName = :ApplicationName", conn))
				{

					cmd.Parameters.AddWithValue(":Username", username);
					cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

					using (OracleDataReader reader = cmd.ExecuteReader())
					{
						if (!reader.HasRows)
							return null;

						ReaderOrdinal ro = new ReaderOrdinal(reader);
						reader.Read();
						u = GetUserFromReader(reader, ro);
					}
				}

				if (userIsOnline)
				{
					using (OracleCommand updateCmd = new OracleCommand("UPDATE " + tableName + " " +
							  "SET LastActivityDate = :LastActivityDate " +
							  "WHERE Username = :Username AND ApplicationName = :ApplicationName", conn))
					{
						updateCmd.Parameters.AddWithValue(":LastActivityDate", DateTime.Now);
						updateCmd.Parameters.AddWithValue(":Username", username);
						updateCmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

						updateCmd.ExecuteNonQuery();
					}
				}
				return u;
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "GetUser(String, Boolean)");
				throw new ProviderException(exceptionMessage);
			}
			else
				throw e;
		}
	}


	//
	// MembershipProvider.GetUser(object, bool)
	//
	public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
	{
		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("SELECT PKID, Username, Email, PasswordQuestion," +
			  " UserComments, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
			  " LastActivityDate, LastPasswordChangedDate, LastLockedOutDate" +
			  " FROM " + tableName + " WHERE PKID = :PKID", conn);

		cmd.Parameters.AddWithValue(":PKID", providerUserKey);

		MembershipUser u = null;
		OracleDataReader reader = null;

		try
		{
			conn.Open();

			using (reader = cmd.ExecuteReader())
			{
				if (reader.HasRows)
				{
					ReaderOrdinal ro = new ReaderOrdinal(reader);
					reader.Read();
					u = GetUserFromReader(reader, ro);

					reader.Close();

					if (userIsOnline)
					{
						OracleCommand updateCmd = new OracleCommand("UPDATE " + tableName + " " +
								  "SET LastActivityDate = :LastActivityDate " +
								  "WHERE PKID = :PKID", conn);

						updateCmd.Parameters.AddWithValue(":LastActivityDate", DateTime.Now);
						updateCmd.Parameters.AddWithValue(":PKID", providerUserKey);

						updateCmd.ExecuteNonQuery();
					}
				}
				reader.Close();
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "GetUser(Object, Boolean)");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			if (reader != null) { reader.Close(); }

			conn.Close();
		}

		return u;
	}

	class ReaderOrdinal
	{
		public readonly int colPKID;
		public readonly int colUsername;
		public readonly int colApplicationName;
		public readonly int colEmail;
		public readonly int colUserComments;
		public readonly int colUserPassword;
		public readonly int colPasswordQuestion;
		public readonly int colPasswordAnswer;
		public readonly int colIsApproved;
		public readonly int colLastActivityDate;
		public readonly int colLastLoginDate;
		public readonly int colLastPasswordChangedDate;
		public readonly int colCreationDate;
		public readonly int colIsOnLine;
		public readonly int colIsLockedOut;
		public readonly int colLastLockedOutDate;
		public readonly int colFailedPwdAttemptCount;
		public readonly int colFailedPwdAttemptWinStart;
		public readonly int colFailedPwdAnswAttemptCount;
		public readonly int colFailedPwdAnswAttemptWinStart;


		OracleDataReader _reader;

		public ReaderOrdinal(OracleDataReader reader)
		{
			_reader = reader;

			colPKID = GetOrdinal("PKID");
			colUsername = GetOrdinal("Username");
			colApplicationName = GetOrdinal("ApplicationName");
			colEmail = GetOrdinal("Email");
			colUserComments = GetOrdinal("UserComments");
			colUserPassword = GetOrdinal("UserPassword");
			colPasswordQuestion = GetOrdinal("PasswordQuestion");
			colPasswordAnswer = GetOrdinal("PasswordAnswer");
			colIsApproved = GetOrdinal("IsApproved");
			colLastActivityDate = GetOrdinal("LastActivityDate");
			colLastLoginDate = GetOrdinal("LastLoginDate");
			colLastPasswordChangedDate = GetOrdinal("LastPasswordChangedDate");
			colCreationDate = GetOrdinal("CreationDate");
			colIsOnLine = GetOrdinal("IsOnLine");
			colIsLockedOut = GetOrdinal("IsLockedOut");
			colLastLockedOutDate = GetOrdinal("LastLockedOutDate");
			colFailedPwdAttemptCount = GetOrdinal("FailedPwdAttemptCount");
			colFailedPwdAttemptWinStart = GetOrdinal("FailedPwdAttemptWinStart");
			colFailedPwdAnswAttemptCount = GetOrdinal("FailedPwdAnswAttemptCount");
			colFailedPwdAnswAttemptWinStart = GetOrdinal("FailedPwdAnswAttemptWinStart");
		}

		private int GetOrdinal(string fieldName)
		{
			for (int c = 0; c < _reader.FieldCount; c++)
			{
				string nc = _reader.GetName(c);
				if (string.Compare(fieldName, nc, true) == 0)
					return c;
			}
			return -1;
		}


		public T GetValue<T>(int col, T nullValue)
		{
			Debug.Assert(col >= 0);

			if (_reader.IsDBNull(col)) return nullValue;
			return (T)_reader[col];
		}
	}

	//
	// GetUserFromReader
	//    A helper function that takes the current row from the OracleDataReader
	// and hydrates a MembershiUser from the values. Called by the 
	// MembershipUser.GetUser implementation.
	//
	private MembershipUser GetUserFromReader(OracleDataReader reader, ReaderOrdinal ro)
	{
		object providerUserKey = new Guid(reader.GetValue(ro.colPKID).ToString());
		string username = reader.IsDBNull(ro.colUsername) ? "" : reader.GetString(ro.colUsername);
		string email = reader.IsDBNull(ro.colEmail) ? "" : reader.GetString(ro.colEmail);
		string passwordQuestion = reader.IsDBNull(ro.colPasswordQuestion) ? "" : reader.GetString(ro.colPasswordQuestion);
		string comment = reader.IsDBNull(ro.colUserComments) ? "" : reader.GetString(ro.colUserComments);
		bool isApproved = reader.IsDBNull(ro.colIsApproved) ? false : reader.GetInt32(ro.colIsApproved) > 0;
		bool isLockedOut = reader.IsDBNull(ro.colIsLockedOut) ? false : reader.GetInt32(ro.colIsLockedOut) > 0;
		DateTime creationDate = reader.IsDBNull(ro.colCreationDate) ? DateTime.Now : reader.GetDateTime(ro.colCreationDate);
		DateTime lastLoginDate = reader.IsDBNull(ro.colLastLoginDate) ? DateTime.Now : reader.GetDateTime(ro.colLastLoginDate);
		DateTime lastActivityDate = reader.IsDBNull(ro.colLastActivityDate) ? DateTime.Now : reader.GetDateTime(ro.colLastActivityDate);
		DateTime lastPasswordChangedDate = reader.IsDBNull(ro.colLastPasswordChangedDate) ? DateTime.Now : reader.GetDateTime(ro.colLastPasswordChangedDate);
		DateTime lastLockedOutDate = reader.IsDBNull(ro.colLastLockedOutDate) ? DateTime.Now : reader.GetDateTime(ro.colLastLockedOutDate);

		// qui e` stato cambiato .... faceva new MembershipUser(this.Name....
		// in questo modo ritorniamo in maniera trasparente al framework anche l'indicazione del profilo
		MembershipUser u = new MembershipUserWithProfile(
			this.connectionString,
			this.Name,
											  username,
											  providerUserKey,
											  email,
											  passwordQuestion,
											  comment,
											  isApproved,
											  isLockedOut,
											  creationDate,
											  lastLoginDate,
											  lastActivityDate,
											  lastPasswordChangedDate,
											  lastLockedOutDate);

		return u;
	}


	//
	// MembershipProvider.UnlockUser
	//
	public override bool UnlockUser(string username)
	{
		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("UPDATE " + tableName + " " +
										  " SET IsLockedOut = 0, LastLockedOutDate = :LastLockedOutDate " +
										  " WHERE Username = :Username AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.Add(":LastLockedOutDate", OracleType.DateTime).Value = DateTime.Now;
		cmd.Parameters.Add(":Username", OracleType.VarChar, 255).Value = username;
		cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;

		int rowsAffected = 0;

		try
		{
			conn.Open();

			rowsAffected = cmd.ExecuteNonQuery();
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "UnlockUser");
				throw new ProviderException(exceptionMessage);
			}
			else
				throw e;
		}
		finally
		{
			conn.Close();
		}

		if (rowsAffected > 0)
			return true;

		return false;
	}


	public void LockInactiveUsers(int inactivityDays)
	{
		try
		{
			using (OracleConnection conn = new OracleConnection(connectionString))
			{

				using (OracleCommand cmd = conn.CreateCommand())
				{
					cmd.CommandText = @"
update ASPNET_USERS
set IsLockedOut = 1
where
PKID in 
(
	select 
	ASPNET_USERS.PKID
	from ASPNET_USERS
	inner join ASPNET_USERPROFILE
	on ASPNET_USERS.PKID = ASPNET_USERPROFILE.PKID
	where
	ASPNET_USERS.ApplicationName = :ApplicationName 
	and :DtNow - trunc(ASPNET_USERS.LastActivityDate) >= :InactivityDays
	and ASPNET_USERPROFILE.PROFILE <> 'Amministrazione sistema'
)
";
					cmd.Parameters.Add(":DtNow", OracleType.DateTime, 0).Value = DateTime.Now.Date;
					cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;
					cmd.Parameters.Add(":InactivityDays", OracleType.Int32, 0).Value = inactivityDays;

					conn.Open();
					cmd.ExecuteNonQuery();
				}
			}

		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "LockInactiveUsers");
				throw new ProviderException(exceptionMessage);
			}
			else
				throw e;
		}
	}



	//
	// MembershipProvider.GetUserNameByEmail
	//

	public override string GetUserNameByEmail(string email)
	{
		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("SELECT Username" +
			  " FROM " + tableName + " WHERE Email = :Email AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.Add(":Email", OracleType.VarChar, 128).Value = email;
		cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;

		string username = "";

		try
		{
			conn.Open();
			username = (string)cmd.ExecuteScalar();
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "GetUserNameByEmail");
				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		if (username == null)
			username = "";

		return username;
	}




	//
	// MembershipProvider.ResetPassword
	//

	public override string ResetPassword(string username, string answer)
	{
		if (!EnablePasswordReset)
			throw new NotSupportedException("Password reset is not enabled.");

		if (answer == null && RequiresQuestionAndAnswer)
		{
			UpdateFailureCount(username, "passwordAnswer");
			throw new ProviderException("Password answer required for password reset.");
		}

		string newPassword = Membership.GeneratePassword(newPasswordLength, MinRequiredNonAlphanumericCharacters);

		ValidatePasswordEventArgs args = new ValidatePasswordEventArgs(username, newPassword, true);

		OnValidatingPassword(args);

		if (args.Cancel)
			if (args.FailureInformation != null)
				throw args.FailureInformation;
			else
				throw new MembershipPasswordException("Reset password canceled due to password validation failure.");


		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("SELECT PasswordAnswer, IsLockedOut FROM " + tableName + " " +
			  " WHERE Username = :Username AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.Add(":Username", OracleType.VarChar, 255).Value = username;
		cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;

		int rowsAffected = 0;
		string passwordAnswer = "";
		OracleDataReader reader = null;

		try
		{
			conn.Open();

			using (reader = cmd.ExecuteReader(CommandBehavior.SingleRow))
			{
				if (reader.HasRows)
				{
					reader.Read();

					if (reader.GetInt32(1) > 0)
						throw new MembershipPasswordException("The supplied user is locked out.");

					passwordAnswer = reader.GetString(0);
				}
				else
				{
					throw new MembershipPasswordException("The supplied user name is not found.");
				}
				reader.Close();
			}

			if (RequiresQuestionAndAnswer && !CheckPassword(answer, passwordAnswer))
			{
				UpdateFailureCount(username, "passwordAnswer");

				throw new MembershipPasswordException("Incorrect password answer.");
			}

			OracleCommand updateCmd = new OracleCommand("UPDATE " + tableName + " " +
				" SET UserPassword = :UserPassword, LastPasswordChangedDate = :LastPasswordChangedDate" +
				" WHERE Username = :Username AND ApplicationName = :ApplicationName AND IsLockedOut = 0", conn);

			updateCmd.Parameters.Add(":UserPassword", OracleType.VarChar, 255).Value = EncodePassword(newPassword);
			updateCmd.Parameters.Add(":LastPasswordChangedDate", OracleType.DateTime).Value = DateTime.Now;
			updateCmd.Parameters.Add(":Username", OracleType.VarChar, 255).Value = username;
			updateCmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;

			rowsAffected = updateCmd.ExecuteNonQuery();
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "ResetPassword");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			if (reader != null) { reader.Close(); }
			conn.Close();
		}

		if (rowsAffected > 0)
		{
			return newPassword;
		}
		else
		{
			throw new MembershipPasswordException("User not found, or user is locked out. Password not Reset.");
		}
	}



	public override void UpdateUser(MembershipUser user)
	{
		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("UPDATE " + tableName + " " +
				" SET Email = :Email, UserComments = :UserComments," +
				" IsApproved = :IsApproved" +
				" WHERE Username = :Username AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.Add(":Email", OracleType.VarChar, 128).Value = user.Email;
		cmd.Parameters.Add(":UserComments", OracleType.VarChar, 255).Value = user.Comment;
		cmd.Parameters.Add(":IsApproved", OracleType.Byte).Value = user.IsApproved;
		cmd.Parameters.Add(":Username", OracleType.VarChar, 255).Value = user.UserName;
		cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;


		try
		{
			conn.Open();

			cmd.ExecuteNonQuery();
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "UpdateUser");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}
	}


	//
	// MembershipProvider.ValidateUser
	//

	public override bool ValidateUser(string username, string password)
	{
		bool isValid = false;

		OracleConnection conn = new OracleConnection(connectionString);

		// viene cercato l'utente NON lockato
		// isApproved serve ulteriormente per concedere l'accesso al sistema
		OracleCommand cmd = conn.CreateCommand();
		cmd.CommandText = "SELECT UserPassword, IsApproved FROM " + tableName + " " +
				" WHERE Username = :Username AND ApplicationName = :ApplicationName AND IsLockedOut = 0";

		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

		bool isApproved = false;
		string pwd = "";

		try
		{
			conn.Open();

			using (OracleDataReader reader = cmd.ExecuteReader())
			{
				if (!reader.Read())
					return false;

				pwd = reader.GetString(0);
				isApproved = reader.GetInt32(1) > 0;
			}

			if (CheckPassword(password, pwd))
			{
				if (isApproved)
				{
					isValid = true;

					OracleCommand updateCmd = conn.CreateCommand();
					updateCmd.CommandText = "UPDATE " + tableName + @" 
SET 
LastLoginDate = :LastLoginDate, 
LastActivityDate = :LastActivityDate
WHERE Username = :Username AND ApplicationName = :ApplicationName";

					updateCmd.Parameters.AddWithValue(":LastLoginDate", DateTime.Now);
					updateCmd.Parameters.AddWithValue(":LastActivityDate", DateTime.Now);
					updateCmd.Parameters.AddWithValue(":Username", username);
					updateCmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

					updateCmd.ExecuteNonQuery();
				}
			}
			else
			{
				if (conn.State == ConnectionState.Open)
					conn.Close();

				UpdateFailureCount(username, "password");
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "ValidateUser");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		return isValid;
	}


	//
	// UpdateFailureCount
	//   A helper method that performs the checks and updates associated with
	// password failure tracking.
	//

	private void UpdateFailureCount(string username, string failureType)
	{
		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = conn.CreateCommand();
		cmd.CommandText = "SELECT FailedPwdAttemptCount, " +
						"  FailedPwdAttemptWinStart, " +
						"  FailedPwdAnswAttemptCount, " +
						"  FailedPwdAnswAttemptWinStart " +
						"  FROM " + tableName + " " +
						"  WHERE Username = :Username AND ApplicationName = :ApplicationName";

		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

		OracleDataReader reader = null;
		DateTime windowStart = new DateTime();
		int failureCount = 0;

		try
		{
			conn.Open();

			using (reader = cmd.ExecuteReader(CommandBehavior.SingleRow))
			{
				if (reader.HasRows)
				{
					ReaderOrdinal ro = new ReaderOrdinal(reader);

					reader.Read();

					if (failureType == "password")
					{
						failureCount = (int)ro.GetValue(ro.colFailedPwdAttemptCount, (decimal)0);
						windowStart = ro.GetValue(ro.colFailedPwdAttemptWinStart, DateTime.Now);
					}

					if (failureType == "passwordAnswer")
					{
						failureCount = reader.GetInt32(2);
						windowStart = reader.GetDateTime(3);
					}
				}
				reader.Close();
			}

			DateTime windowEnd = windowStart.AddMinutes(PasswordAttemptWindow);

			if (failureCount == 0 || DateTime.Now > windowEnd)
			{
				// First password failure or outside of PasswordAttemptWindow. 
				// Start a new password failure count from 1 and a new window starting now.

				if (failureType == "password")
					cmd.CommandText = "UPDATE " + tableName + " " +
									  "SET FailedPwdAttemptCount = :Count, " +
									  "FailedPwdAttemptWinStart = :WindowStart " +
									  "WHERE Username = :Username AND ApplicationName = :ApplicationName";

				if (failureType == "passwordAnswer")
					cmd.CommandText = "UPDATE " + tableName + " " +
									  "SET FailedPwdAnswAttemptCount = :Count, " +
									  "FailedPwdAnswAttemptWinStart = :WindowStart " +
									  "WHERE Username = :Username AND ApplicationName = :ApplicationName";

				cmd.Parameters.Clear();

				cmd.Parameters.AddWithValue(":Count", 1);
				cmd.Parameters.AddWithValue(":WindowStart", DateTime.Now);
				cmd.Parameters.AddWithValue(":Username", username);
				cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

				if (cmd.ExecuteNonQuery() < 0)
					throw new ProviderException("Unable to update failure count and window start.");
			}
			else
			{
				if (failureCount++ >= MaxInvalidPasswordAttempts)
				{
					// Password attempts have exceeded the failure threshold. Lock out
					// the user.

					cmd.CommandText = "UPDATE " + tableName + " " +
									  "  SET IsLockedOut = :IsLockedOut, LastLockedOutDate = :LastLockedOutDate " +
									  "  WHERE Username = :Username AND ApplicationName = :ApplicationName";

					cmd.Parameters.Clear();

					cmd.Parameters.Add(":IsLockedOut", OracleType.Byte).Value = true;
					cmd.Parameters.Add(":LastLockedOutDate", OracleType.DateTime).Value = DateTime.Now;
					cmd.Parameters.Add(":Username", OracleType.VarChar, 255).Value = username;
					cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;

					if (cmd.ExecuteNonQuery() < 0)
						throw new ProviderException("Unable to lock out user.");
				}
				else
				{
					// Password attempts have not exceeded the failure threshold. Update
					// the failure counts. Leave the window the same.

					if (failureType == "password")
						cmd.CommandText = "UPDATE " + tableName + " " +
										  "  SET FailedPwdAttemptCount = :Count" +
										  "  WHERE Username = :Username AND ApplicationName = :ApplicationName";

					if (failureType == "passwordAnswer")
						cmd.CommandText = "UPDATE " + tableName + " " +
										  "  SET FailedPwdAnswAttemptCount = :Count" +
										  "  WHERE Username = :Username AND ApplicationName = :ApplicationName";

					cmd.Parameters.Clear();

					cmd.Parameters.Add(":Count", OracleType.Int32).Value = failureCount;
					cmd.Parameters.Add(":Username", OracleType.VarChar, 255).Value = username;
					cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;

					if (cmd.ExecuteNonQuery() < 0)
						throw new ProviderException("Unable to update failure count.");
				}
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "UpdateFailureCount");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			if (reader != null) { reader.Close(); }
			conn.Close();
		}
	}


	//
	// CheckPassword
	//   Compares password values based on the MembershipPasswordFormat.
	//

	private bool CheckPassword(string password, string dbpassword)
	{
		string pass1 = password;
		string pass2 = dbpassword;

		switch (PasswordFormat)
		{
		case MembershipPasswordFormat.Encrypted:
			pass2 = UnEncodePassword(dbpassword);
			break;
		case MembershipPasswordFormat.Hashed:
			pass1 = EncodePassword(password);
			break;
		default:
			break;
		}

		if (pass1 == pass2)
		{
			return true;
		}

		return false;
	}


	//
	// EncodePassword
	//   Encrypts, Hashes, or leaves the password clear based on the PasswordFormat.
	//

	private string EncodePassword(string password)
	{
		string encodedPassword = password;

		switch (PasswordFormat)
		{
		case MembershipPasswordFormat.Clear:
			break;
		case MembershipPasswordFormat.Encrypted:
			encodedPassword =
			  Convert.ToBase64String(EncryptPassword(Encoding.Unicode.GetBytes(password)));
			break;
		case MembershipPasswordFormat.Hashed:
			HMACSHA1 hash = new HMACSHA1();
			hash.Key = HexToByte(encryptionKey);
			encodedPassword =
			  Convert.ToBase64String(hash.ComputeHash(Encoding.Unicode.GetBytes(password)));
			break;
		default:
			throw new ProviderException("Unsupported password format.");
		}

		return encodedPassword;
	}


	//
	// UnEncodePassword
	//   Decrypts or leaves the password clear based on the PasswordFormat.
	//

	private string UnEncodePassword(string encodedPassword)
	{
		string password = encodedPassword;

		switch (PasswordFormat)
		{
		case MembershipPasswordFormat.Clear:
			break;
		case MembershipPasswordFormat.Encrypted:
			password =
			  Encoding.Unicode.GetString(DecryptPassword(Convert.FromBase64String(password)));
			break;
		case MembershipPasswordFormat.Hashed:
			throw new ProviderException("Cannot unencode a hashed password.");
		default:
			throw new ProviderException("Unsupported password format.");
		}

		return password;
	}

	//
	// HexToByte
	//   Converts a hexadecimal string to a byte array. Used to convert encryption
	// key values from the configuration.
	//

	private byte[] HexToByte(string hexString)
	{
		byte[] returnBytes = new byte[hexString.Length / 2];
		for (int i = 0; i < returnBytes.Length; i++)
			returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
		return returnBytes;
	}


	//
	// MembershipProvider.FindUsersByName
	//

	public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
	{

		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("SELECT Count(*) FROM " + tableName + " " +
				  "WHERE Username LIKE :UsernameSearch AND ApplicationName = :ApplicationName", conn);
		cmd.Parameters.Add(":UsernameSearch", OracleType.VarChar, 255).Value = usernameToMatch;
		cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = _ApplicationName;

		MembershipUserCollection users = new MembershipUserCollection();

		OracleDataReader reader = null;

		try
		{
			conn.Open();
			totalRecords = Convert.ToInt32(cmd.ExecuteScalar());

			if (totalRecords <= 0) { return users; }

			cmd.CommandText = "SELECT PKID, Username, Email, PasswordQuestion," +
			  " UserComments, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
			  " LastActivityDate, LastPasswordChangedDate, LastLockedOutDate " +
			  " FROM " + tableName + " " +
			  " WHERE Username LIKE :UsernameSearch AND ApplicationName = :ApplicationName " +
			  " ORDER BY Username Asc";

			using (reader = cmd.ExecuteReader())
			{
				int counter = 0;
				int startIndex = pageSize * pageIndex;
				int endIndex = startIndex + pageSize - 1;

				ReaderOrdinal ro = new ReaderOrdinal(reader);

				while (reader.Read())
				{
					if (counter >= startIndex)
					{
						MembershipUser u = GetUserFromReader(reader, ro);
						users.Add(u);
					}

					if (counter >= endIndex) { cmd.Cancel(); }

					counter++;
				}
				reader.Close();
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "FindUsersByName");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			if (reader != null) { reader.Close(); }

			conn.Close();
		}

		return users;
	}

	//
	// MembershipProvider.FindUsersByEmail
	//

	public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
	{
		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("SELECT Count(*) FROM " + tableName + " " +
										  "WHERE Email LIKE :EmailSearch AND ApplicationName = :ApplicationName", conn);
		cmd.Parameters.Add(":EmailSearch", OracleType.VarChar, 255).Value = emailToMatch;
		cmd.Parameters.Add(":ApplicationName", OracleType.VarChar, 255).Value = ApplicationName;

		MembershipUserCollection users = new MembershipUserCollection();

		OracleDataReader reader = null;
		totalRecords = 0;

		try
		{
			conn.Open();
			totalRecords = Convert.ToInt32(cmd.ExecuteScalar());

			if (totalRecords <= 0) { return users; }

			cmd.CommandText = "SELECT PKID, Username, Email, PasswordQuestion," +
					 " UserComments, IsApproved, IsLockedOut, CreationDate, LastLoginDate," +
					 " LastActivityDate, LastPasswordChangedDate, LastLockedOutDate " +
					 " FROM " + tableName + " " +
					 " WHERE Email LIKE :Username AND ApplicationName = :ApplicationName " +
					 " ORDER BY Username Asc";

			using (reader = cmd.ExecuteReader())
			{
				int counter = 0;
				int startIndex = pageSize * pageIndex;
				int endIndex = startIndex + pageSize - 1;

				ReaderOrdinal ro = new ReaderOrdinal(reader);

				while (reader.Read())
				{
					if (counter >= startIndex)
					{
						MembershipUser u = GetUserFromReader(reader, ro);
						users.Add(u);
					}

					if (counter >= endIndex) { cmd.Cancel(); }

					counter++;
				}
				reader.Close();
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "FindUsersByEmail");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			if (reader != null) { reader.Close(); }

			conn.Close();
		}

		return users;
	}

	//
	// WriteToEventLog
	//   A helper function that writes exception detail to the event log. Exceptions
	// are written to the event log as a security measure to avoid private database
	// details from being returned to the browser. If a method does not return a status
	// or boolean indicating the action succeeded or failed, a generic exception is also 
	// thrown by the caller.
	//

	private void WriteToEventLog(Exception e, string action)
	{
		EventLog log = new EventLog();
		log.Source = eventSource;
		log.Log = eventLog;

		string message = "An exception occurred communicating with the data source.\n\n";
		message += "Action: " + action + "\n\n";
		message += "Exception: " + e.ToString();

		log.WriteEntry(message);
	}



	/// <summary>
	/// Genera l'utente associando immediatamente i ruoli ppresenti nel profilo passato.
	public MembershipUser CreateUserWithProfile(string username,
			 string password,
			 string email,
			 string passwordQuestion,
			 string passwordAnswer,
			 bool isApproved,
			 object providerUserKey,
			 string userProfile,
			 string userComments,
			 int? idCoaDiCompetenza,
			 out MembershipCreateStatus status)
	{
		try
		{
			using (OracleConnection cn = new OracleConnection(connectionString))
			{
				cn.Open();

				using (OracleTransaction tr = cn.BeginTransaction())
				{
					CreateUserInternal(
						tr,

						username,
						password,
						email,
						passwordQuestion,
						passwordAnswer,
						isApproved,
						ref providerUserKey,
						userComments,
						out status);

					if (status != MembershipCreateStatus.Success)
					{
						tr.Rollback();
						return null;
					}

					if (status == MembershipCreateStatus.Success)
					{
						InsertUserProfile(tr, providerUserKey, userProfile, idCoaDiCompetenza);

						tr.Commit();

						Roles.AddUserToRoles(username, ITRSUtility.GetRolesOfProfile(userProfile));
					}
				}
			}

			return GetUser(username, false);
		}
		catch
		{
			status = MembershipCreateStatus.ProviderError;
			return null;
		}
	}

	private static void DeleteUserProfile(string connectionString, object providerUserKey)
	{
		using (OracleConnection conn = new OracleConnection(connectionString))
		{
			using (OracleCommand cmd = new OracleCommand("", conn))
			{
				cmd.CommandText = "delete from aspnet_userprofile where pkid = :k";
				cmd.Parameters.AddWithValue(":k", providerUserKey.ToString());
				conn.Open();
				cmd.ExecuteNonQuery();
			}
		}
	}
	private static void InsertUserProfile(string connectionString, object providerUserKey, string userProfile, int? idCoaDiCompetenza)
	{
		using (OracleConnection conn = new OracleConnection(connectionString))
		{
			using (OracleCommand cmd = new OracleCommand("", conn))
			{
				cmd.CommandText = "insert into aspnet_userprofile (pkid, profile, idCoaDiCompetenza) values (:k, :p, :c)";
				cmd.Parameters.AddWithValue(":k", providerUserKey.ToString());
				cmd.Parameters.AddWithValue(":p", userProfile);
				if (idCoaDiCompetenza.HasValue)
					cmd.Parameters.AddWithValue(":c", idCoaDiCompetenza.Value);
				else
					cmd.Parameters.AddWithValue(":c", DBNull.Value);

				conn.Open();
				cmd.ExecuteNonQuery();
			}
		}
	}

	private static void InsertUserProfile(OracleTransaction tr, object providerUserKey, string userProfile, int? idCoaDiCompetenza)
	{
		using (OracleCommand cmd = new OracleCommand("", tr.Connection))
		{
			cmd.Transaction = tr;

			cmd.CommandText = "insert into aspnet_userprofile (pkid, profile, idCoaDiCompetenza) values (:k, :p, :c)";
			cmd.Parameters.AddWithValue(":k", providerUserKey.ToString());
			cmd.Parameters.AddWithValue(":p", userProfile);
			if (idCoaDiCompetenza.HasValue)
				cmd.Parameters.AddWithValue(":c", idCoaDiCompetenza.Value);
			else
				cmd.Parameters.AddWithValue(":c", DBNull.Value);

			cmd.ExecuteNonQuery();
		}
	}

	private static void UpdateUserProfile(string connectionString, object providerUserKey, string newUserProfile)
	{
		using (OracleConnection conn = new OracleConnection(connectionString))
		{
			using (OracleCommand cmd = new OracleCommand("", conn))
			{
				cmd.CommandText = "update aspnet_userprofile set profile = :p where pkid = :k";
				cmd.Parameters.AddWithValue(":k", providerUserKey.ToString());
				cmd.Parameters.AddWithValue(":p", newUserProfile);

				conn.Open();
				cmd.ExecuteNonQuery();
			}
		}
	}
	private static void UpdateCoaDiCompetenza(string connectionString, object providerUserKey, int? idCoaDiCompetenza)
	{
		using (OracleConnection conn = new OracleConnection(connectionString))
		{
			using (OracleCommand cmd = new OracleCommand("", conn))
			{
				cmd.CommandText = "update aspnet_userprofile set idCoaDiCompetenza = :c where pkid = :k";
				cmd.Parameters.AddWithValue(":k", providerUserKey.ToString());

				if (idCoaDiCompetenza.HasValue)
					cmd.Parameters.AddWithValue(":c", idCoaDiCompetenza.Value);
				else
					cmd.Parameters.AddWithValue(":c", DBNull.Value);

				conn.Open();
				cmd.ExecuteNonQuery();
			}
		}
	}


	private static string GetUserProfile(string connectionString, object providerUserKey)
	{
		using (OracleConnection conn = new OracleConnection(connectionString))
		{
			using (OracleCommand cmd = new OracleCommand("", conn))
			{
				cmd.CommandText = "select Profile from aspnet_userprofile where pkid=:k";
				cmd.Parameters.AddWithValue(":k", providerUserKey.ToString());

				conn.Open();
				object profile = cmd.ExecuteOracleScalar();

				string userProfile = "";
				if (profile != null)
					userProfile = (string)profile;

				return userProfile;
			}
		}
	}


	/// <summary>
	/// Cambia il profilo dell'utente
	/// </summary>
	/// <param name="username"></param>
	/// <param name="newProfile"></param>
	public void ChangeUserProfile(string username, string newProfile)
	{
		MembershipUser u = GetUser(username, false);

		string[] r = Roles.GetRolesForUser(username);
		if (r.Length > 0)
			Roles.RemoveUserFromRoles(username, r);
		Roles.AddUserToRoles(username, ITRSUtility.GetRolesOfProfile(newProfile));

		UpdateUserProfile(connectionString, u.ProviderUserKey, newProfile);
	}

	public void ChangeIdCoaDiCompetenza(string username, int? idCoaDiCompetenza)
	{
		MembershipUser u = GetUser(username, false);

		UpdateCoaDiCompetenza(connectionString, u.ProviderUserKey, idCoaDiCompetenza);
	}

	public bool ChangePassword(string username, string newPwd)
	{
		OracleConnection conn = new OracleConnection(connectionString);
		OracleCommand cmd = new OracleCommand("UPDATE " + tableName + " " +
				" SET UserPassword = :UserPassword, LastPasswordChangedDate = :LastPasswordChangedDate " +
				" WHERE Username = :Username AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":UserPassword", EncodePassword(newPwd));
		cmd.Parameters.AddWithValue(":LastPasswordChangedDate", DateTime.Now);
		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

		int rowsAffected = 0;

		try
		{
			conn.Open();
			rowsAffected = cmd.ExecuteNonQuery();
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "ChangePassword");

				throw new ProviderException(exceptionMessage);
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		if (rowsAffected > 0)
		{
			return true;
		}

		return false;
	}

}
[Serializable]
public class MembershipUserWithProfile : MembershipUser
{
	public MembershipUserWithProfile(string connectionString, string providerName, string name, object providerUserKey, string email, string passwordQuestion, string comment, bool isApproved, bool isLockedOut, DateTime creationDate, DateTime lastLoginDate, DateTime lastActivityDate, DateTime lastPasswordChangedDate, DateTime lastLockoutDate)
		: base(providerName, name, providerUserKey, email, passwordQuestion, comment, isApproved, isLockedOut, creationDate, lastLoginDate, lastActivityDate, lastPasswordChangedDate, lastLockoutDate)
	{
		_userProfile = "";

		try
		{
			using (OracleConnection conn = new OracleConnection(connectionString))
			{
				using (OracleCommand cmd = new OracleCommand("", conn))
				{
					cmd.CommandText = "select Profile, IdCoaDiCompetenza from aspnet_userprofile where pkid=:k";
					cmd.Parameters.AddWithValue(":k", providerUserKey.ToString());

					conn.Open();

					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						if (rd.Read())
						{
							if (!rd.IsDBNull(0))
								_userProfile = (string)rd[0];
							else
								_userProfile = "";

							if (!rd.IsDBNull(1))
								_IdCoaDiCompetenza = Convert.ToInt32(rd[1]);
							else
								_IdCoaDiCompetenza = null;
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			string g = ex.Message;
		}
	}


	public int? _IdCoaDiCompetenza;

	public int? IdCoaDiCompetenza
	{
		get { return _IdCoaDiCompetenza; }
		set { _IdCoaDiCompetenza = value; }
	}

	public string UserProfile
	{
		get { return _userProfile; }
		set { _userProfile = value; }
	}


	private string _userProfile;

}
#endif
