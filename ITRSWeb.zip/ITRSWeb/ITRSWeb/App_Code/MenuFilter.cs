using System.IO;
using System.Text;
using System.Web;

/// <summary>
/// Summary description for MenuUndefinedFilter
/// </summary>
public class MenuUndefinedFilter : Stream
{
	private Stream _stream;

	public MenuUndefinedFilter(Stream s)
	{
		_stream = s;
	}

	public override void Flush()
	{
		_stream.Flush();
	}

	public override void Close()
	{
		if (_stream != null)
		{
			_stream.Close();
			_stream = null;
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
			Close();

		base.Dispose(disposing);
	}

	public override void Write(byte[] buffer, int offset, int count)
	{
		Encoding e = HttpContext.Current.Response.ContentEncoding;
		string s = e.GetString(buffer, offset, count);

		string c1 = "onmouseover=\"TreeView_HoverNode(";
		string r1 = "onmouseover=\"if (typeof(TreeView_HoverNode) != 'undefined' && typeof(ctl00_cphLeft_tvMenu_Data) != 'undefined') TreeView_HoverNode(";

		string c2 = "onmouseout=\"TreeView_UnhoverNode(";
		string r2 = "onmouseout=\"if (typeof(TreeView_UnhoverNode) != 'undefined' && typeof(ctl00_cphLeft_tvMenu_Data) != 'undefined' && typeof(this.hoverClass) != 'undefined') TreeView_UnhoverNode(";

		s = s.Replace(c1, r1);
		s = s.Replace(c2, r2);
		buffer = e.GetBytes(s);

		_stream.Write(buffer, 0, buffer.Length);
	}


	public override long Seek(long offset, SeekOrigin origin) { return _stream.Seek(offset, origin); }
	public override void SetLength(long value) { _stream.SetLength(value); }
	public override int Read(byte[] buffer, int offset, int count) { return _stream.Read(buffer, offset, count); }
	public override bool CanRead { get { return _stream.CanRead; } }
	public override bool CanSeek { get { return _stream.CanSeek; } }
	public override bool CanWrite { get { return _stream.CanWrite; } }
	public override long Length { get { return _stream.Length; } }
	public override long Position { get { return _stream.Position; } set { _stream.Position = value; } }
}
