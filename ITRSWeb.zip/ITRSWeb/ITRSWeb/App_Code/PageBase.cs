using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Globalization;
using System.Collections.Generic;
using System.Reflection;

using ITRS_BL;

/// <summary>
/// Summary description for PageBase
/// </summary>
public class PageBase : System.Web.UI.Page
{
	public PageBase()
	{
	}

	protected void RegisterCommonScripts()
	{
		ClientScriptManager csm = this.Page.ClientScript;
		if (!csm.IsClientScriptIncludeRegistered("griglia_selezionabile"))
			csm.RegisterClientScriptInclude("griglia_selezionabile", "/ITRSWeb/Scripts/grid_table.js");
	}


	/// <summary>
	/// Aggiunge sulle righe di tipo DataControlRowType.Header la freccina per indicare il verso dell'ordinamento delle colonne.
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	protected void gv_RowCreated(object sender, GridViewRowEventArgs e)
	{
		GridView gv = (GridView)sender;
		if (e.Row.RowType == DataControlRowType.Header)
			AddGlyph(gv, e.Row);

		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			e.Row.Attributes.Add("onMouseOver", "this.style.cursor='hand';");
			e.Row.Attributes.Add("ondblclick", ClientScript.GetPostBackEventReference(gv, "Select$" + e.Row.RowIndex.ToString()));
			e.Row.Attributes.Add("onclick", "fnSelectRow(this.parent, this);");

			// questo fa il postback e seleziona la riga: conservo l'esempio, non si sa mai ... puo` servire per:
			// Select$, Sort$, Page$, Delete$, Edit$
			// e.Row.Attributes.Add("onclick", ClientScript.GetPostBackEventReference(gv, "Select$" + e.Row.RowIndex.ToString()));
		}
	}


	/// <summary>
	/// Aggiunge la freccina per indicare il verso dell'ordinamento delle colonne.
	/// </summary>
	/// <param name="grid"></param>
	/// <param name="item"></param>
	private void AddGlyph(GridView grid, GridViewRow item)
	{
		Label glyph = new Label();
		glyph.EnableTheming = false;
		glyph.Font.Name = "webdings";
		glyph.Font.Size = FontUnit.XSmall;
		glyph.Text = (grid.SortDirection == SortDirection.Ascending ? "5" : "6");
		glyph.Width = new Unit(20, UnitType.Pixel);

		Label glyphEmpty = new Label();
		glyphEmpty.EnableTheming = false;
		glyphEmpty.Font.Name = "webdings";
		glyphEmpty.Font.Size = FontUnit.XSmall;
		glyphEmpty.Text = "";
		glyphEmpty.Width = new Unit(20, UnitType.Pixel);


		// Find the column you sorted by
		for (int i = 0; i < grid.Columns.Count; i++)
		{
			// se esiste la sort espression
			if (grid.Columns[i].SortExpression.Length > 0)
			{
				string colSort = grid.Columns[i].SortExpression;
				string newSort = grid.SortExpression;
				if (colSort != "" && colSort == newSort)
					item.Cells[i].Controls.Add(glyph);
				else
					item.Cells[i].Controls.Add(glyphEmpty);
			}
		}
	}



	protected delegate bool FindControlDelegate<T>(T p) where T : Control;

	protected T FindControlRecursive<T>(GridViewRow row, FindControlDelegate<T> fcd) where T : Control
	{
		foreach (TableCell tc in row.Cells)
		{
			T r = FindControlRecursive(tc, fcd);
			if (r != null) return r;
		}
		return null;
	}

	protected T FindControlRecursive<T>(Control p, FindControlDelegate<T> fcd) where T : Control
	{
		T tc = p as T;
		if (tc != null && fcd(tc))
			return tc;

		foreach (Control c in p.Controls)
		{
			T r = FindControlRecursive(c, fcd);
			if (r != null) return r;
		}

		return null;
	}

	protected delegate void WriteErrorDelegate(Exception ex);
	protected event WriteErrorDelegate WriteError;

	protected void HandleError(GridView gv)
	{
		Debug.Assert(WriteError != null);

		gv.RowDeleted += new GridViewDeletedEventHandler(gv_RowDeleted);
		gv.RowUpdated += new GridViewUpdatedEventHandler(gv_RowUpdated);
	}
	protected void HandleError(DetailsView dv)
	{
		Debug.Assert(WriteError != null);

		dv.ItemDeleted += new DetailsViewDeletedEventHandler(dv_ItemDeleted);
		dv.ItemInserted += new DetailsViewInsertedEventHandler(dv_ItemInserted);
		dv.ItemUpdated += new DetailsViewUpdatedEventHandler(dv_ItemUpdated);
	}

	void dv_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
	{
		Debug.Assert(WriteError != null);

		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}

	void dv_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
	{
		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}

	void dv_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
	{
		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}
	protected void HandleError(ObjectDataSource ds)
	{
		Debug.Assert(WriteError != null);

		ds.Deleted += new ObjectDataSourceStatusEventHandler(ds_Deleted);
		ds.Inserted += new ObjectDataSourceStatusEventHandler(ds_Inserted);
		ds.Updated += new ObjectDataSourceStatusEventHandler(ds_Updated);

		ds.Selected += new ObjectDataSourceStatusEventHandler(ds_Selected);
	}

	void ds_Selected(object sender, ObjectDataSourceStatusEventArgs e)
	{
		Debug.Assert(WriteError != null);

		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}

	private void gv_RowUpdated(object sender, GridViewUpdatedEventArgs e)
	{
		Debug.Assert(WriteError != null);

		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}

	private void gv_RowDeleted(object sender, GridViewDeletedEventArgs e)
	{
		Debug.Assert(WriteError != null);

		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}
	void ds_Inserted(object sender, ObjectDataSourceStatusEventArgs e)
	{
		Debug.Assert(WriteError != null);

		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}
	void ds_Deleted(object sender, ObjectDataSourceStatusEventArgs e)
	{
		Debug.Assert(WriteError != null);

		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}
	void ds_Updated(object sender, ObjectDataSourceStatusEventArgs e)
	{
		Debug.Assert(WriteError != null);

		if (e.Exception == null) return;
		e.ExceptionHandled = true;
		if (WriteError != null) WriteError(e.Exception);
	}

	// silvia 
	protected void lbl_WriteError(Label lblError, string text)
	{
		lblError.ForeColor = System.Drawing.Color.Red;
		lblError.Text = text;
	}

	protected bool dv_CheckField(ref string field)
	{
		if (field != null)
			field = field.Trim();
		else
			field = "";

		if (string.IsNullOrEmpty(field))
			return false;

		return true;
	}

	protected bool dv_IsDate(ref string strField)
	{
		DateTime field;
		if (!DateTime.TryParse(strField, out field))
		{
			strField = "";
			return false;
		}

		return true;
	}

	protected bool dv_IsInteger(ref string strField)
	{
		int field;
		if (!int.TryParse(strField, out field))
		{
			strField = "";
			return false;
		}

		return true;
	}

	protected bool dv_IsDouble(ref string strField)
	{
		double field;

		if (!double.TryParse(strField, out field))
		{
			strField = "";
			return false;
		}

		return true;
	}

	/////////////////////////////////////////////////////

	public void RegisterClientId(string prexif, params Control[] clist)
	{
		string s = string.Format("var {0} = new Object();\n", prexif);
		foreach (Control c in clist)
		{
			s += string.Format("{0}.{1} = function() {{ return document.getElementById('{2}'); }};\n", prexif, c.ID, c.ClientID);
		}

		if (!ClientScript.IsClientScriptBlockRegistered(prexif))
		{
			Page.ClientScript.RegisterClientScriptBlock(this.GetType(), prexif, s, true);
		}
	}


	protected void dv_ToUpperAndTrim(ref string strField)
	{

		if (strField != null)
		{
			strField = strField.ToUpper().Trim();
			strField = strField.Replace(" ", "");
		}
		else
			strField = "";
	}

	protected void dv_CheckNazionalita(ref string strField)
	{
		if (strField != null)
			strField = strField.Trim();
		else
			strField = "";

		if (string.IsNullOrEmpty(strField))
			strField = "I";
		else
			strField = strField.ToUpper();
	}


	public int GridView_GetCellIndex(GridView gv, string dataField)
	{
		for (int i = 0; i < gv.Columns.Count; i++)
		{
			DataControlField dcf = gv.Columns[i];
			PropertyInfo pi = dcf.GetType().GetProperty("DataField");
			if (pi != null)
			{
				string columnDataField = (string)pi.GetValue(dcf, new object[0]);
				if (columnDataField == dataField)
					return i;
			}
		}
		Debug.Assert(false, "DataField not found: " + dataField);
		return -1;
	}


	/*
	public enum TipoAttivita
	{
		Accesso,
		Sorveglianza,
		Intervento,
		Indagine,

		ReportTVPD,
		ReportTVT,
		ReportTSC2P,
		ReportVTPD,
		ReportVTST,

		Transito,
		Evento,

		AmministrazioneUtenti,

		LTS,
		LTB
	}
	*/

	public static string UserName
	{
		get
		{
			HttpContext ctx = HttpContext.Current;
			return ctx.User.Identity.Name;
		}
	}
	public static string UserPkId
	{
		get
		{
			HttpContext ctx = HttpContext.Current;

			string UserPkId = (string)ctx.Cache["UserKey " + UserName];
			if (string.IsNullOrEmpty(UserPkId))
			{
				ITRS_BL.BLQueueJobs blq = new ITRS_BL.BLQueueJobs();
				UserPkId = blq.GetUserPkId(UserName);
				ctx.Cache["UserKey " + UserName] = UserPkId;
			}
			return UserPkId;
		}
	}

	public static void AddUserActivity(string UserName, TipoAttivita tipoAttivita, string descrizioneAttivita)
	{
		try
		{
			using (ITRS_BL.BLLog blLog = new ITRS_BL.BLLog())
				blLog.AddUserActivity(UserName, tipoAttivita, descrizioneAttivita);
		}
		catch
		{
		}

	}
	public static void AddUserActivity(string UserName, TipoAttivita tipoAttivita, string descrizioneAttivita, params object[] args)
	{
		AddUserActivity(UserName, tipoAttivita, string.Format(descrizioneAttivita, args));
	}
	public static void AddUserActivity(TipoAttivita tipoAttivita, string descrizioneAttivita)
	{
		HttpContext ctx = HttpContext.Current;
		string UserName = ctx.User.Identity.Name;
		AddUserActivity(UserName, tipoAttivita, descrizioneAttivita);

	}
	public static void AddUserActivity(TipoAttivita tipoAttivita, string descrizioneAttivita, params object[] args)
	{
		AddUserActivity(tipoAttivita, string.Format(descrizioneAttivita, args));
	}
}

