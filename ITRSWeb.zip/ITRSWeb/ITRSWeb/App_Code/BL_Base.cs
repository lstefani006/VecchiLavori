using System;
using System.Data;
using System.Configuration;

using Oracle.DataAccess.Client;



/// <summary>
/// Summary description for BL_Base
/// </summary>
public class BL_Base
{
	public BL_Base()
	{
	}

	protected OracleConnection CreateConnection()
	{
		OracleConnection cn = new OracleConnection();
		cn.ConnectionString = ConfigurationManager.ConnectionStrings["itrs_odp"].ConnectionString;
		return cn;
	}

	protected T CreateConnection<T>()
		where T : System.Data.IDbConnection, new()
	{
		T cn = new T();
		cn.ConnectionString = ConfigurationManager.ConnectionStrings["itrs_odp"].ConnectionString;
		return cn;
	}

	protected P AddWithValue<T, P>(T cmd, string parameterName, object value)
		where T : System.Data.IDbCommand
		where P : System.Data.IDbDataParameter 
	{
		P par = (P) cmd.CreateParameter();
		par.ParameterName = parameterName;
		par.Value = value;
		cmd.Parameters.Add(par);
		return par;
	}


}
