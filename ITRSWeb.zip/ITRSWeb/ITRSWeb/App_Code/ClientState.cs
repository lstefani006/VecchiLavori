using System;
using System.Reflection;
using System.Globalization;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;


[AttributeUsage(AttributeTargets.Field /*| AttributeTargets.Property*/)]
public class NotCSF : Attribute
{
}



public static class ClientState
{
	interface IGenericMember
	{
		object GetValue(object r);
		void SetValue(object r, object v);
		Type GetMemberType();
	}

	class FieldMember : IGenericMember
	{
		readonly FieldInfo _f;
		public FieldMember(FieldInfo f) { _f = f; }

		public object GetValue(object r) { return _f.GetValue(r); }
		public void SetValue(object r, object v) { _f.SetValue(r, v); }
		public Type GetMemberType() { return _f.FieldType; }
	}
	class PropertyMember : IGenericMember
	{
		readonly PropertyInfo _f;
		public PropertyMember(PropertyInfo f) { _f = f; }

		public object GetValue(object r) { return _f.GetValue(r, new object[] { }); }
		public void SetValue(object r, object v) { _f.SetValue(r, v, null); }
		public Type GetMemberType() { return _f.PropertyType; }
	}

	public static DateTime EncodeDate(string v)
	{
		string[] dc = v.Split(' ');
		DateTime dt = new DateTime(
			int.Parse(dc[0]),
			int.Parse(dc[1]),
			int.Parse(dc[2]),
			int.Parse(dc[3]),
			int.Parse(dc[4]),
			int.Parse(dc[5]));
		return dt;
	}

	public static string DecodeDate(DateTime dt)
	{
		string g = dt.ToString("yyyy MM dd HH mm ss");
		return g;
	}

	public static string Serialize(object v)
	{
		Type t = v.GetType();

		string r = "";

		MemberInfo[] mi = t.GetMembers(BindingFlags.Public | BindingFlags.Instance);

		bool first = true;

		foreach (MemberInfo m in mi)
		{
			IGenericMember f = null;
			if (m is FieldInfo)
				f = new FieldMember((FieldInfo)m);
			else if (m is PropertyInfo)
				f = new PropertyMember((PropertyInfo)m);
			else
				continue;

			if (!IsCSField(m))
				continue;

			if (!first)
				r += "|";
			else
				first = false;
			r += m.Name;


			if (f.GetMemberType() == typeof(Boolean))
			{
				bool fv = (bool)f.GetValue(v);
				r += ":b:" + (fv ? "1" : "0");
			}
			else if (f.GetMemberType() == typeof(Boolean?))
			{
				bool? fv = (bool?)f.GetValue(v);
				if (fv.HasValue)
					r += ":b?:" + (fv.Value ? "1" : "0");
				else
					r += ":b?:";
			}
			else if (f.GetMemberType() == typeof(Double))
			{
				double fv = (double)f.GetValue(v);
				r += ":r:" + EncodeString(fv.ToString(CultureInfo.InvariantCulture));
			}
			else if (f.GetMemberType() == typeof(Double?))
			{
				double? fv = (double?)f.GetValue(v);
				if (fv.HasValue)
					r += ":r?:" + EncodeString(fv.Value.ToString(CultureInfo.InvariantCulture));
				else
					r += ":r?:";
			}
			else if (f.GetMemberType() == typeof(DateTime))
			{
				DateTime fv = (DateTime)f.GetValue(v);
				r += ":d:" + EncodeString(DecodeDate(fv));
			}
			else if (f.GetMemberType() == typeof(DateTime?))
			{
				DateTime? fv = (DateTime?)f.GetValue(v);
				if (fv.HasValue)
					r += ":d?:" + EncodeString(DecodeDate(fv.Value));
				else
					r += ":d?";
			}
			else if (f.GetMemberType() == typeof(Int32))
			{
				int fv = (int)f.GetValue(v);
				r += ":i:" + EncodeString(fv.ToString(CultureInfo.InvariantCulture));
			}
			else if (f.GetMemberType() == typeof(Int32?))
			{
				int? fv = (int?)f.GetValue(v);
				if (fv.HasValue)
					r += ":i?:" + EncodeString(fv.Value.ToString(CultureInfo.InvariantCulture));
				else
					r += ":i?:";
			}
			else if (f.GetMemberType() == typeof(string))
			{
				string fv = (string)f.GetValue(v);
				if (fv != null)
					r += ":s:." + EncodeString(fv);
				else
					r += ":s:";
			}
			else if (f.GetMemberType() == typeof(int[]))
			{
				int[] fv = (int[])f.GetValue(v);
				r += ":I:";
				if (fv != null)
				{
					r += (fv.Length == 0) ? "." : "+";
					Prepend z = new Prepend(r, ";");
					for (int n = 0; n < fv.Length; ++n)
						z.Add(EncodeString(fv[n].ToString(CultureInfo.InvariantCulture)));
					r = z.ToString();
				}
			}
			else if (f.GetMemberType() == typeof(string[]))
			{
				string[] fv = (string[])f.GetValue(v);
				r += ":S:";
				if (fv != null)
				{
					r += (fv.Length == 0) ? "." : "+";
					Prepend z = new Prepend(r, ";");
					for (int n = 0; n < fv.Length; ++n)
						if (fv[n] != null)
							z.Add("." + EncodeString(fv[n]));
					r = z.ToString();
				}
			}
			else if (f.GetMemberType() == typeof(double[]))
			{
				double[] fv = (double[])f.GetValue(v);
				r += ":R:";
				if (fv != null)
				{
					r += (fv.Length == 0) ? "." : "+";
					Prepend z = new Prepend(r, ";");
					for (int n = 0; n < fv.Length; ++n)
						z.Add(EncodeString(fv[n].ToString(CultureInfo.InvariantCulture)));
					r = z.ToString();
				}
			}
			else if (f.GetMemberType() == typeof(DateTime[]))
			{
				DateTime[] fv = (DateTime[])f.GetValue(v);
				r += ":D:";
				if (fv != null)
				{
					r += (fv.Length == 0) ? "." : "+";
					Prepend z = new Prepend(r, ";");
					for (int n = 0; n < fv.Length; ++n)
						z.Add(EncodeString(DecodeDate(fv[n])));
					r = z.ToString();
				}
			}
			else if (f.GetMemberType() == typeof(DateTime?[]))
			{
				DateTime?[] fv = (DateTime?[])f.GetValue(v);
				r += ":D?:";
				if (fv != null)
				{
					r += (fv.Length == 0) ? "." : "+";
					Prepend z = new Prepend(r, ";");
					for (int n = 0; n < fv.Length; ++n)
						if (fv[n].HasValue)
							z.Add(EncodeString(DecodeDate(fv[n].Value)));
						else
							z.Add("");

					r = z.ToString();
				}
			}
			else
				throw new ArgumentException("ClientState.Serialize: tipo non supportato", m.Name);

			//else if (f.FieldType == typeof(DateTime[]))
			//            {
			//                Array fv = (Array)f.GetValue(v);
			//                r += ":O:" + fv.GetValue(0).GetType().AssemblyQualifiedName + ":";
			//                Prepend z = new Prepend(r, ";");
			//                for (int n = 0; n < fv.Length; ++n)
			//                {
			//                    if (fv.GetValue(n) == null)
			//                        z.Add("null");
			//                    else
			//                    {
			//                        object rrr = fv.GetValue(n);
			//                        string rrss = Serialize(rrr);
			//                        z.Add(EncodeString(rrss));
			//                    }
			//                }
			//                r = z.ToString();
			//            }
			//        }
			//        else
			//        {
			//            object fv = f.GetValue(v);
			//            if (fv != null)
			//            {
			//                string serverType = fv.GetType().AssemblyQualifiedName;
			//                r += ":o:" + serverType + ":";

			//                string co = Serialize(fv);
			//                r += EncodeString(co);
			//            }
			//            else
			//            {
			//                r += ":o:null:";
			//            }
			//        }
			//	}
			//	break;
			//default:
			//	Debug.Assert(false);
			//		throw new ArgumentException("ClientState.Serialize: tipo non supportato", f.Name);
			//}
		}
		// return r;

		byte[] by = System.Text.Encoding.UTF8.GetBytes(r);
		string ss = Convert.ToBase64String(by);
		return ss;

	}


	private static bool IsCSField(MemberInfo f)
	{
		object[] attrs = f.GetCustomAttributes(true);
		foreach (object att in attrs)
			if (att is NotCSF)
				return false;
		return true;
	}

	public static T DeserializeType<T>(string m) where T : new()
	{
		return (T)Deserialize(typeof(T), m);
	}

	public static object Deserialize(Type ty, string m)
	{
		byte [] by = Convert.FromBase64String(m);
		m = System.Text.Encoding.UTF8.GetString(by);

		string[] e = Decode(m, '|');

		object r = Activator.CreateInstance(ty);

		for (int i = 0; i < e.Length; ++i)
		{
			string[] t = Decode(e[i], ':');

			string field = t[0];
			string type = t[1];
			string value = t[2];

			FieldInfo f = ty.GetField(field);

			switch (type)
			{
			case "b":
				f.SetValue(r, value == "1");
				break;
			case "b?":
				{
					bool? b = null;
					if (value != "")
						b = (value == "1");
					f.SetValue(r, b);
				}
				break;


			case "d":
				f.SetValue(r, EncodeDate(value));
				break;
			case "d?":
				{
					DateTime? dt = null;
					if (value != null)
						dt = EncodeDate(value);
					f.SetValue(r, dt);
				}
				break;

			case "i":
				f.SetValue(r, int.Parse(value, CultureInfo.InvariantCulture));
				break;
			case "i?":
				{
					int? n = null;
					if (value != "")
						n = int.Parse(value, CultureInfo.InvariantCulture);
					f.SetValue(r, n);
				}
				break;

			case "s":
				if (value != "")
					f.SetValue(r, value.Substring(1));
				else
					f.SetValue(r, null);
				break;

			case "r":
				f.SetValue(r, double.Parse(value, CultureInfo.InvariantCulture));
				break;
			case "r?":
				{
					double? d = null;
					if (value != "")
						d = double.Parse(value, CultureInfo.InvariantCulture);
					f.SetValue(r, d);
				}
				break;


			case "I":
				{
					if (value == "")
						f.SetValue(r, null);
					else if (value == ".")
						f.SetValue(r, new int[0]);
					else
					{
						value = value.Substring(1);
						string[] a = Decode(value, ';');

						int[] ia = new int[a.Length];
						for (int ai = 0; ai < a.Length; ai++)
							ia[ai] = int.Parse(a[ai], CultureInfo.InvariantCulture);
						f.SetValue(r, ia);
					}
				}
				break;

			case "R":
				{
					if (value == "")
						f.SetValue(r, null);
					else if (value == ".")
						f.SetValue(r, new double[0]);
					else
					{
						value = value.Substring(1);
						string[] a = Decode(value, ';');

						double[] ia = new double[a.Length];
						for (int ai = 0; ai < a.Length; ai++)
							ia[ai] = double.Parse(a[ai], CultureInfo.InvariantCulture);
						f.SetValue(r, ia);
					}
				}
				break;

			case "D":
				{
					if (value == "")
						f.SetValue(r, null);
					else if (value == ".")
						f.SetValue(r, new DateTime[0]);
					else
					{
						value = value.Substring(1);
						string[] a = Decode(value, ';');
						DateTime[] ia = new DateTime[a.Length];
						for (int ai = 0; ai < a.Length; ai++)
							ia[ai] = EncodeDate(a[ai]);
						f.SetValue(r, ia);
					}
				}
				break;

			case "D?":
				{
					if (value == "")
						f.SetValue(r, null);
					else if (value == ".")
						f.SetValue(r, new DateTime?[0]);
					else
					{
						value = value.Substring(1);
						string[] a = Decode(value, ';');
						DateTime?[] ia = new DateTime?[a.Length];
						for (int ai = 0; ai < a.Length; ai++)
							if (a[ai] != "")
								ia[ai] = EncodeDate(a[ai]);
							else
								ia[ai] = null;
						f.SetValue(r, ia);
					}
				}
				break;
			case "B":
				{
					if (value == "")
						f.SetValue(r, null);
					else if (value == ".")
						f.SetValue(r, new bool[0]);
					else
					{
						value = value.Substring(1);
						string[] a = Decode(value, ';');

						bool[] ia = new bool[a.Length];
						for (int ai = 0; ai < a.Length; ai++)
							ia[ai] = a[ai] == "1";
						f.SetValue(r, ia);
					}
				}
				break;

			case "S":
				{
					if (value == "")
						f.SetValue(r, null);
					else if (value == ".")
						f.SetValue(r, new string[0]);
					else
					{
						value = value.Substring(1);
						string[] a = Decode(value, ';');

						for (int n = 0; n < a.Length; n++)
							if (a[n] == "")
								a[n] = null;
							else
								a[n] = a[n].Substring(1);
						f.SetValue(r, a);
					}
				}
				break;

			case "O":
				{
					Debug.Assert(false);
				}
				break;
			}
		}

		return r;
	}

	static string EncodeString(string m)
	{
		m = m.Replace("|", "||");
		m = m.Replace(":", "::");
		m = m.Replace(";", ";;");
		return m;
	}

	static string[] Decode(string str, char sep)
	{
		List<string> r = new List<string>();
		r.Add("");

		int ri = 0;
		int len = str.Length;

		for (int i = 0; i < len; i++)
		{
			char cc = str[i];
			char cn = '\0';

			if (i + 1 < len)
				cn = str[i + 1];

			if (cc != sep)
			{
				r[ri] += cc;
				continue;
			}

			if (cn != sep)
			{
				ri += 1;
				r.Add("");
			}
			else
			{
				r[ri] += sep;
				i++;
			}
		}
		return r.ToArray();
	}

	class Prepend
	{
		bool f = true;
		string p;
		string r = string.Empty;

		public Prepend(string r, string p) { this.r = r; this.p = p; }
		public Prepend(string p) { this.p = p; }

		public void Add(string v)
		{
			if (f)
			{
				f = false;
				r += v;
			}
			else
				r += p + v;
		}

		public override string ToString()
		{
			return r;
		}
	}

	public static T[] Redim<T>(T[] a, int n)
	{
		if (a == null && n < 0)
			throw new ArgumentException("cannot allocate negative size array");

		if (a != null && a.Length + n < 0)
			throw new ArgumentException("cannot allocate negative size array");

		if (a == null)
			return new T[n];

		T[] ret = new T[a.Length + n];
		int nn = Math.Min(a.Length, ret.Length);
		for (int i = 0; i < nn; ++i)
			ret[i] = a[i];

		return ret;
	}
	public static T[] Append<T>(T[] a, T v)
	{
		T[] ret = Redim(a, +1);
		a[a.Length - 1] = v;
		return ret;
	}
	public static T[] InsertTop<T>(T[] a, T v, int nMaxRow)
	{
		if (a.Length < nMaxRow)
			a = Redim(a, +1);

		for (int i = a.Length - 1; i > 0; --i)
			a[i] = a[i - 1];
		a[0] = v;

		return a;
	}
}

/*
public class ClientSharedDataReader
{
	Dictionary<string, object> _r;

	public ClientSharedDataReader(string shData)
	{
		_r = parseMsg(shData);
	}

	public object this[string tag]
	{
		get { return _r[tag]; }
	}

	public string GetString(string tag) { return (String)_r[tag]; }
	public int? GetInt32(string tag) { return (Int32?)_r[tag]; }
	public Boolean? GetBoolean(string tag) { return (Boolean?)_r[tag]; }
	public DateTime? GetDateTime(string tag) { return (DateTime?)_r[tag]; }
	public double? GetDouble(string tag) { return (double?)_r[tag]; }

	private static List<string> split2(string a, char sep)
	{
		int al = a.Length;

		List<string> r = new List<string>();
		int ri = 0;

		r.Add("");
		for (int i = 0; i < al; ++i)
		{
			char c = a[i];

			if (c != sep)
			{
				r[ri] += c;
				continue;
			}

			if ((i + 1) < al && a[i + 1] == sep)
			{
				r[ri] += sep;
				i++;
			}
			else
			{
				ri += 1;
				r.Add("");
			}
		}

		return r;
	}


	// costruisce al volo un oggetto partendo da un messaggio formattato cosi':
	// msg := <tuple>|<tuple>|<tuple>
	// tuple := <variable>:<value>
	// tuple := <variable>:<type>:<value>
	// In uscita l'oggetto crea tante proprieta` <variable> con assegnate <value>
	public static Dictionary<string, object> parseMsg(string msg)
	{
		Dictionary<string, object> r = new Dictionary<string, object>();

		List<string> a = split2(msg, '|');
		for (int c = 0; c < a.Count; c++)
		{
			string s = a[c];
			List<string> touple = split2(s, ':');

			string variable;
			string type;
			string value;

			switch (touple.Count)
			{
			case 1:
				variable = touple[0];
				r[variable] = "";
				break;
			case 2:
				variable = touple[0];
				value = touple[1];
				r[variable] = value;
				break;
			case 3:
				variable = touple[0];
				type = touple[1];
				value = touple[2];
				switch (type)
				{
				case "i":
					{
						int? v;
						if (value == "")
							v = null;
						else
							v = int.Parse(value, CultureInfo.InvariantCulture);
						r[variable] = v;
					}
					break;
				case "r":
					{
						double? v;
						if (value == "")
							v = null;
						else
							v = double.Parse(value, CultureInfo.InvariantCulture);
						r[variable] = v;
					}
					break;
				case "b":
					{
						bool? v;
						if (value == "")
							v = null;
						else
							v = value.ToLower() == "true";
						r[variable] = v;
					}
					break;

				case "d":
					{
						DateTime? v;
						if (value == "")
							v = null;
						else
						{
							string[] dtp = value.Split(' ');
							int yyyy = int.Parse(dtp[0]);
							int MM = int.Parse(dtp[1]);
							int dd = int.Parse(dtp[2]);
							int HH = int.Parse(dtp[3]);
							int mm = int.Parse(dtp[4]);
							int ss = int.Parse(dtp[5]);

							v = new DateTime(yyyy, MM, dd, HH, mm, ss);
						}

						r[variable] = v;
					}
					break;
				case "s":
					r[variable] = value;
					break;
				}
				break;
			}
		}
		return r;
	}
}
 * */

/*
public class ClientSharedDataWriter
{
	private StringBuilder r = new StringBuilder();
	bool first = true;


	public void Add(string tag, string value)
	{
		Add(tag, "s", value);
	}
	public void Add(string tag, int value)
	{
		string s = value.ToString(CultureInfo.InvariantCulture);
		Add(tag, "i", s);
	}
	public void Add(string tag, int? value)
	{
		string s = string.Empty;
		if (value.HasValue)
			s = value.Value.ToString(CultureInfo.InvariantCulture);
		Add(tag, "i", s);
	}
	public void Add(string tag, bool? value)
	{
		string s = string.Empty;
		if (value.HasValue)
			s = value.Value ? "true" : "false";
		Add(tag, "b", s);
	}
	public void Add(string tag, bool value)
	{
		string s = value ? "true" : "false";
		Add(tag, "b", s);
	}
	public void Add(string tag, DateTime value)
	{
		string s = value.ToString("yyyy MM dd HH mm ss");
		Add(tag, "d", s);
	}

	public void Add(string tag, DateTime? value)
	{
		string s = string.Empty;
		if (value.HasValue)
			s = value.Value.ToString("yyyy MM dd HH mm ss");

		Add(tag, "d", s);
	}

	public void Add(string tag, double value)
	{
		string s = value.ToString(CultureInfo.InvariantCulture);
		Add(tag, "r", s);
	}
	public void Add(string tag, double? value)
	{
		string s = string.Empty;
		if (value.HasValue)
			s = value.Value.ToString(CultureInfo.InvariantCulture);
		Add(tag, "r", s);
	}



	public override string ToString()
	{
		return r.ToString();
	}

	private void Add(string tag, string type, string value)
	{
		if (value == null)
			value = string.Empty;

		value = value.Replace("|", "||");
		value = value.Replace(":", "::");

		if (first)
		{
			r.AppendFormat("{0}:{1}:{2}", tag, type, value);
			first = false;
		}
		else
			r.AppendFormat("|{0}:{1}:{2}", tag, type, value);
	}
}


*/