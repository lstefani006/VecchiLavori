using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

using ITRS_BL;

public static class ImageUtility
{

	public static byte[] ElaboraImmagineTargaToArray(byte[] a, int xs, int xe, int ys, int ye, int outW, int outH, double lum, double cnt)
	{
		using (Bitmap bmp = ElaboraImmagineTargaToBitmap(a, xs, xe, ys, ye, outW, outH, lum, cnt))
		{
			return GetImageData(bmp);
		}
	}

	public static string TargaHandler_BuildRequest(string targa, string nazionalita, DateTime dataOraRilevamento, int xs, int xe, int ys, int ye, int outW, int outH, double lum, double cnt)
	{
		string url = "/ITRSWeb/Handler/TargaHandler.ashx?t={0}&n={1}&d={2}&xs={3}&xe={4}&ys={5}&ye={6}&outW={7}&outH={8}&lum={9}&cnt={10}";
		return string.Format(url,
			targa, nazionalita, ITRSUtility.DateTimeToYYYY_MM_DD_HH24_MI_SS(dataOraRilevamento),
			xs, xe, ys, ye,
			outW, outH,
			lum, cnt);
	}


	public static Bitmap ElaboraImmagineTargaToBitmap(byte[] a, int xs, int xe, int ys, int ye, int outW, int outH, double lum, double cnt)
	{
		if (a == null || a.Length == 0)
		{
			int w = outW;
			int h = outH;
			Bitmap bmp = new Bitmap(w, h);
			using (Graphics gr = Graphics.FromImage(bmp))
			{
				using (Brush br = new SolidBrush(Color.White))
				{
					gr.FillRectangle(br, new Rectangle(0, 0, w, h));
				}
				using (Font f = new Font("Verdana", 10))
				{
					using (Brush b = new SolidBrush(Color.Red))
					{
						gr.DrawString("Targa non disponibile", f, b, 10, 10);
					}
				}
			}

			return bmp;
		}
		else
		{
			if (xs > xe) U.Swap(ref xs, ref xe);
			if (ys > ye) U.Swap(ref ys, ref ye);
			Rectangle srcRect = new Rectangle(xs, ys, xe - xs, ye - ys);
			srcRect.Inflate(10, 8);

			if (true)
			{
				Point centro = new Point(srcRect.X + srcRect.Width / 2, srcRect.Y + srcRect.Height / 2);

				double srcK = (double)srcRect.Width / srcRect.Height;
				double dstK = (double)outW / outH;

				int newDX;
				int newDY;

				if (dstK > srcK)
				{
					// tengo ferma la Y
					newDY = srcRect.Height;
					newDX = (int)(newDY * dstK);
				}
				else
				{
					// tengo ferma la X
					newDX = srcRect.Width;
					newDY = (int)(newDX / dstK);
				}
				srcRect = new Rectangle(centro.X - newDX / 2, centro.Y - newDY / 2, newDX, newDY);
			}

			byte[] colorLookup = null;

			if (cnt != 1.0 || lum != 0)
			{
				colorLookup = new byte[256];
				for (int i = 0; i < 256; i++)
				{
					double c = 128 + (i - 128) * cnt + lum;
					if (c > 255) c = 255;
					else if (c < 0) c = 0;
					colorLookup[i] = (byte)c;
				}
			}


			using (Bitmap bmpSrc = new Bitmap(new MemoryStream(a)))
			{
				Bitmap bmpDest = new Bitmap(outW, outH, PixelFormat.Format24bppRgb);
				using (Graphics gr = Graphics.FromImage(bmpDest))
				{
					Rectangle destRect = new Rectangle(0, 0, outW, outH);

					using (Brush brBlack = new SolidBrush(Color.Black))
					{
						gr.FillRectangle(brBlack, destRect);
					}

					gr.DrawImage(bmpSrc, destRect, srcRect, GraphicsUnit.Pixel);
				}

				if (colorLookup != null)
					ImageUtility.TransformBitmap(bmpDest, colorLookup);

				return bmpDest;
			}
		}
	}

	private static byte[] GetImageData(Bitmap bmp)
	{
		MemoryStream ms = new MemoryStream();
		bmp.Save(ms, ImageFormat.Jpeg);
		ms.Flush();
		return ms.ToArray();
	}


	public static void TransformBitmap(Bitmap bmp, byte[] colorLookup)
	{
		// Lock the bitmap's bits.  
		Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
		BitmapData bmpData = bmp.LockBits(rect, ImageLockMode.ReadWrite, bmp.PixelFormat);

		// Get the address of the first line.
		IntPtr ptr = bmpData.Scan0;

		int n = bmp.Width * bmp.Height * 3;
		byte[] rgbValues = new byte[n];

		// Copy the RGB values into the array.
		Marshal.Copy(ptr, rgbValues, 0, n);

		// Set every red value to 255.  
		for (int c = 0; c < n; c++)
			rgbValues[c] = colorLookup[rgbValues[c]];

		// Copy the RGB values back to the bitmap
		Marshal.Copy(rgbValues, 0, ptr, n);

		// Unlock the bits.
		bmp.UnlockBits(bmpData);
	}
}
