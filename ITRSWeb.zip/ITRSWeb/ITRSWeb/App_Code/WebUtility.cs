using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Collections.Generic;

using ZipLib = ICSharpCode.SharpZipLib;


/// <summary>
/// Summary description for WU
/// </summary>
public static class WU
{
	/// <summary>
	/// Spedisce il file <para>fileName</para> nella <para>Responce</para>.
	/// </summary>
	/// <param name="Response">HttpResponce a cui mandare il file</param>
	/// <param name="fileName">file da spedire</param>
	/// <param name="fileNameDownload">nome che appare al cliente</param>
	public static void SendFile(HttpResponse Response, string fileName, string fileNameDownload)
	{
		const int ChunkSize = 10000;
		byte[] buffer = new byte[ChunkSize];

		string fn = Path.GetFileName(fileName);

		Response.Clear();
		using (FileStream iStream = File.OpenRead(fileName))
		{
			long dataLengthToRead = iStream.Length;
			Response.ContentType = "application/octet-stream";
			Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileNameDownload + "\"");
			while (dataLengthToRead > 0 && Response.IsClientConnected)
			{
				int lengthRead = iStream.Read(buffer, 0, ChunkSize);
				Response.OutputStream.Write(buffer, 0, lengthRead);
				Response.Flush();
				dataLengthToRead -= lengthRead;
			}
		}
		Response.Close();
	}

	public static void ZipHtml(string path, List<string> filenames, string fnzip)
	{
		byte[] buffer = new byte[4096];

		ZipLib.Checksums.Crc32 crc = new ZipLib.Checksums.Crc32();

		using (ZipLib.Zip.ZipOutputStream s = new ZipLib.Zip.ZipOutputStream(File.Create(path + "\\" + fnzip)))
		{
			s.SetLevel(6);

			foreach (string fn in filenames)
			{
				crc.Reset();
				using (FileStream fs = File.OpenRead(path + "\\" + fn))
				{
					int nr;
					do
					{
						nr = fs.Read(buffer, 0, buffer.Length);
						crc.Update(buffer, 0, nr);
					}
					while (nr > 0);


					ZipLib.Zip.ZipEntry ze = new ZipLib.Zip.ZipEntry(fn);
					ze.DateTime = DateTime.Now;
					ze.Size = fs.Length;
					ze.Crc = crc.Value;
					s.PutNextEntry(ze);
				}

				using (FileStream fs = File.OpenRead(path + "\\" + fn))
				{
					int nr;
					do
					{
						nr = fs.Read(buffer, 0, buffer.Length);
						s.Write(buffer, 0, nr);
					} 
					while (nr > 0);
				}
			}
			s.Finish();
			s.Close();
		}
	}
}
