using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

[Serializable]
public class IndagineInterventoData
{
	public string sortExpression;
	public SortDirection sortDirection;
	public string jobId;
	public bool includiImmagini;
}

[Serializable]
public class IndagineEventoData
{
	public string sortExpression;
	public SortDirection sortDirection;
	public string jobId;
	public bool includiImmagini;
}

[Serializable]
public class ExportLTSData
{
	public string IdUtenteRichiedente;
	public int IdCoa;
}

[Serializable]
public class ExportLTBData
{
	public string fileName;

	public string IdUtenteRichiedente;
	public int IdCoa;
}

[Serializable]
public class ExportSystemActivityData
{
    public string fileName;

    public string sort;
    public DateTime? From;
    public DateTime? To;
    public string Tipo;
    public string Utente;
}

[Serializable]
public class ExportTempiVelocitaPerDirezioneData
{
    public string fileName;
    public string sort;

    public DateTime Data;
    public string Direzione;
}

[Serializable]
public class ExportTempiVelocitaSuTrattaData
{
    public string fileName;
    public string sort;

    public DateTime Data;
    public int IdTratta;
}

[Serializable]
public class ExportVolumeTrafficiSuTrattaData
{
    public string fileName;
    public string sort;

    public DateTime Data;
    public int IdC2P;
}

[Serializable]
public class ExportVolumeTrafficiPerDirezioneData
{
    public string fileName;
    public string sort;

    public DateTime Data;
    public string Direzione;
}

[Serializable]
public class ExportTempiSostaData
{
    public string fileName;
    public string sort;

    public DateTime Data;
    public int IdC2P;
}

[Serializable]
public class ExportIndagineDettaglioTransito
{
	public string Targa;
	public string Nazionalita;
	public DateTime DataOraRilevamento;
	public string JobId;
}
[Serializable]
public class ExportSorveglianzaDettaglioTransito
{
	public string Targa;
	public string Nazionalita;
	public DateTime DataOraRilevamento;
}
