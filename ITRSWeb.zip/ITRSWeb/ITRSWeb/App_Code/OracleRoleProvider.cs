#if USA_ORACLE_PER_MICROSOFT

using System.Web.Security;
using System.Configuration.Provider;
using System.Collections.Specialized;
using System;
using System.Configuration;
using System.Diagnostics;
using System.Web;
using System.Globalization;
using System.Data.OracleClient;
using System.Collections.Generic;

/*
CREATE TABLE AspNet_Roles
(
  Rolename        varchar (255) NOT NULL,
  ApplicationName varchar (255) NOT NULL,

  Primary Key(Rolename, ApplicationName)
) tablespace ITRS_DATA
go

CREATE TABLE AspNet_UsersInRoles
(
  Username        varchar(255) NOT NULL,
  Rolename        varchar(255) NOT NULL,
  ApplicationName varchar(255) NOT NULL,

  Primary Key(UserName, Rolename, ApplicationName)
) tablespace ITRS_DATA
*/


public sealed class OracleRoleProvider : RoleProvider
{
	//
	// Global connection string, generic exception message, event log info.
	//

	private string _rolesTable = "AspNet_Roles";
	private string _usersInRolesTable = "AspNet_UsersInRoles";

	private string eventSource = "OracleRoleProvider";
	private string eventLog = "Application";
	private string exceptionMessage = "An exception occurred. Please check the Event Log.";

	private ConnectionStringSettings _connectionStringSettings;
	private string _connectionString;


	//
	// If false, exceptions are thrown to the caller. If true,
	// exceptions are written to the event log.
	//
	private bool _writeExceptionsToEventLog = false;

	public bool WriteExceptionsToEventLog
	{
		get { return _writeExceptionsToEventLog; }
		set { _writeExceptionsToEventLog = value; }
	}

	//
	// System.Configuration.Provider.ProviderBase.Initialize Method
	//
	public override void Initialize(string name, NameValueCollection config)
	{
		//
		// Initialize values from web.config.
		//
		if (config == null)
			throw new ArgumentNullException("config");

		if (name == null || name.Length == 0)
			name = "OracleRoleProvider";

		if (String.IsNullOrEmpty(config["description"]))
		{
			config.Remove("description");
			config.Add("description", "Sample Oracle Role provider");
		}

		// Initialize the abstract base class.
		base.Initialize(name, config);

		if (config["applicationName"] == null || config["applicationName"].Trim() == "")
			_ApplicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
		else
			_ApplicationName = config["applicationName"];

		if (config["writeExceptionsToEventLog"] != null)
		{
			if (config["writeExceptionsToEventLog"].ToUpper() == "TRUE")
				_writeExceptionsToEventLog = true;
		}


		// Initialize OracleConnection.
		_connectionStringSettings = ConfigurationManager.
		  ConnectionStrings[config["connectionStringName"]];

		if (_connectionStringSettings == null || _connectionStringSettings.ConnectionString.Trim() == "")
			throw new ProviderException("Connection string cannot be blank.");

		_connectionString = _connectionStringSettings.ConnectionString;
	}



	//
	// System.Web.Security.RoleProvider properties.
	//
	private string _ApplicationName;


	public override string ApplicationName
	{
		get { return _ApplicationName; }
		set { _ApplicationName = value; }
	}

	//
	// System.Web.Security.RoleProvider methods.
	//

	//
	// RoleProvider.AddUsersToRoles
	//

	public override void AddUsersToRoles(string[] usernames, string[] rolenames)
	{
		foreach (string rolename in rolenames)
		{
			if (!RoleExists(rolename))
			{
				throw new ProviderException("Role name not found.");
			}
		}

		foreach (string username in usernames)
		{
			if (username.IndexOf(',') > 0)
			{
				throw new ArgumentException("User names cannot contain commas.");
			}

			foreach (string rolename in rolenames)
			{
				if (IsUserInRole(username, rolename))
				{
					throw new ProviderException("User is already in role.");
				}
			}
		}


		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = new OracleCommand("INSERT INTO " + _usersInRolesTable + " " +
				" (Username, Rolename, ApplicationName) " +
				" Values(:Username, :Rolename, :ApplicationName)", conn);

		OracleParameter userParm = cmd.Parameters.AddWithValue(":Username", "");
		OracleParameter roleParm = cmd.Parameters.AddWithValue(":Rolename", "");
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		OracleTransaction tran = null;

		try
		{
			conn.Open();
			tran = conn.BeginTransaction();
			cmd.Transaction = tran;

			foreach (string username in usernames)
			{
				foreach (string rolename in rolenames)
				{
					userParm.Value = username;
					roleParm.Value = rolename;
					cmd.ExecuteNonQuery();
				}
			}

			tran.Commit();
		}
		catch (OracleException e)
		{
			try
			{
				tran.Rollback();
			}
			catch { }


			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "AddUsersToRoles");
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}
	}


	//
	// RoleProvider.CreateRole
	//

	public override void CreateRole(string rolename)
	{
		if (rolename.IndexOf(',') > 0)
		{
			throw new ArgumentException("Role names cannot contain commas.");
		}

		if (RoleExists(rolename))
		{
			throw new ProviderException("Role name already exists.");
		}

		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = new OracleCommand("INSERT INTO " + _rolesTable + " " +
				" (Rolename, ApplicationName) " +
				" Values(:Rolename, :ApplicationName)", conn);

		cmd.Parameters.AddWithValue(":Rolename", rolename);
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		try
		{
			conn.Open();

			cmd.ExecuteNonQuery();
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "CreateRole");
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}
	}


	//
	// RoleProvider.DeleteRole
	//

	public override bool DeleteRole(string rolename, bool throwOnPopulatedRole)
	{
		if (!RoleExists(rolename))
		{
			throw new ProviderException("Role does not exist.");
		}

		if (throwOnPopulatedRole && GetUsersInRole(rolename).Length > 0)
		{
			throw new ProviderException("Cannot delete a populated role.");
		}

		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = new OracleCommand("DELETE FROM " + _rolesTable + " " +
				" WHERE Rolename = :Rolename AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":Rolename", rolename);
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);


		OracleCommand cmd2 = new OracleCommand("DELETE FROM " + _usersInRolesTable + " " +
				" WHERE Rolename = :Rolename AND ApplicationName = :ApplicationName", conn);

		cmd2.Parameters.AddWithValue(":Rolename", rolename);
		cmd2.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		OracleTransaction tran = null;

		try
		{
			conn.Open();
			tran = conn.BeginTransaction();
			cmd.Transaction = tran;
			cmd2.Transaction = tran;

			cmd2.ExecuteNonQuery();
			cmd.ExecuteNonQuery();

			tran.Commit();
		}
		catch (OracleException e)
		{
			try
			{
				tran.Rollback();
			}
			catch { }


			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "DeleteRole");

				return false;
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		return true;
	}


	//
	// RoleProvider.GetAllRoles
	//
	public override string[] GetAllRoles()
	{
		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = conn.CreateCommand();
		cmd.CommandText = "SELECT Rolename FROM " + _rolesTable + " " +
				   " WHERE ApplicationName = :ApplicationName";
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		List<string> ret = new List<string>();
		try
		{
			conn.Open();

			using (OracleDataReader reader = cmd.ExecuteReader())
			{
				while (reader.Read())
					ret.Add(reader.GetString(0));
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
				WriteToEventLog(e, "GetAllRoles");
			else
				throw e;
		}
		finally
		{
			conn.Close();
		}

		Comparison<string> c = delegate(string a, string b)
		{
			return String.Compare(a, b, true);
		};

		ret.Sort(c);
		return ret.ToArray();
	}


	//
	// RoleProvider.GetRolesForUser
	//

	public override string[] GetRolesForUser(string username)
	{
		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = new OracleCommand("SELECT Rolename FROM " + _usersInRolesTable + " " +
				" WHERE Username = :Username AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		List<string> ret = new List<string>();

		try
		{
			conn.Open();

			using (OracleDataReader reader = cmd.ExecuteReader())
			{
				while (reader.Read())
					ret.Add(reader.GetString(0));
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
				WriteToEventLog(e, "GetRolesForUser");
			else
				throw e;
		}
		finally
		{
			conn.Close();
		}

		Comparison<string> c = delegate(string a, string b)
		{
			return string.Compare(a, b, true);
		};

		ret.Sort(c);

		return ret.ToArray();
	}


	//
	// RoleProvider.GetUsersInRole
	//

	public override string[] GetUsersInRole(string rolename)
	{
		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = conn.CreateCommand();

		cmd.CommandText ="SELECT Username FROM " + _usersInRolesTable +
				  " WHERE Rolename = :Rolename AND ApplicationName = :ApplicationName";

		cmd.Parameters.AddWithValue(":Rolename", rolename);
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		List<string> ret = new List<string>();
		try
		{
			conn.Open();

			using (OracleDataReader reader = cmd.ExecuteReader())
			{
				while (reader.Read())
					ret.Add(reader.GetString(0));
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
				WriteToEventLog(e, "GetUsersInRole");
			else
				throw e;
		}
		finally
		{
			conn.Close();
		}

		Comparison<string> c = delegate(string a, string b)
		{
			return string.Compare(a, b, true);
		};

		ret.Sort(c);

		return ret.ToArray();
	}


	//
	// RoleProvider.IsUserInRole
	//

	public override bool IsUserInRole(string username, string rolename)
	{
		bool userIsInRole = false;

		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = new OracleCommand("SELECT COUNT(*) FROM " + _usersInRolesTable + " " +
				" WHERE Username = :Username AND Rolename = :Rolename AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":Username", username);
		cmd.Parameters.AddWithValue(":Rolename", rolename);
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		try
		{
			conn.Open();

			long numRecs = Convert.ToInt64(cmd.ExecuteScalar());

			if (numRecs > 0)
			{
				userIsInRole = true;
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "IsUserInRole");
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		return userIsInRole;
	}

	//public bool IsUserInRole<T>(string username, string rolename)
	//    where T: System.Data.IDbConnection, new() 
	//{
	//    bool userIsInRole = false;

	//    T cn = new T();
	//    cn.ConnectionString = connectionString;

	//    System.Data.IDbCommand cmd = cn.CreateCommand();
	//    cmd.CommandText ="SELECT COUNT(*) FROM " + usersInRolesTable + " " +
	//        " WHERE Username = :Username AND Rolename = :Rolename AND ApplicationName = :ApplicationName";

	//    //OracleCommand cmd = new OracleCommand("SELECT COUNT(*) FROM " + usersInRolesTable + " " +
	//    //        " WHERE Username = :Username AND Rolename = :Rolename AND ApplicationName = :ApplicationName", conn);

	//    System.Data.IDataParameter par;

	//    // cmd.Parameters.AddWithValue(":Username", username);
	//    par = cmd.CreateParameter();
	//    par.ParameterName = ":UserName";
	//    par.Value = username;
	//    cmd.Parameters.Add(par);

	//    // cmd.Parameters.AddWithValue(":Rolename", rolename);
	//    par = cmd.CreateParameter();
	//    par.ParameterName = ":Rolename";
	//    par.Value = rolename;
	//    cmd.Parameters.Add(par);

	//    // cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);
	//    par = cmd.CreateParameter();
	//    par.ParameterName = ":ApplicationName";
	//    par.Value = ApplicationName;
	//    cmd.Parameters.Add(par);


	//    //cmd.Parameters.AddWithValue(":Username", username);
	//    //cmd.Parameters.AddWithValue(":Rolename", rolename);
	//    //cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

	//    try
	//    {
	//        cn.Open();

	//        long numRecs = Convert.ToInt64(cmd.ExecuteScalar());

	//        if (numRecs > 0)
	//            userIsInRole = true;
	//    }
	//    catch (OracleException e)
	//    {
	//        if (WriteExceptionsToEventLog)
	//            WriteToEventLog(e, "IsUserInRole");
	//        else
	//            throw e;
	//    }
	//    finally
	//    {
	//        cn.Close();
	//    }

	//    return userIsInRole;
	//}



	//
	// RoleProvider.RemoveUsersFromRoles
	//

	public override void RemoveUsersFromRoles(string[] usernames, string[] rolenames)
	{
		foreach (string rolename in rolenames)
		{
			if (!RoleExists(rolename))
			{
				throw new ProviderException("Role name not found.");
			}
		}

		foreach (string username in usernames)
		{
			foreach (string rolename in rolenames)
			{
				if (!IsUserInRole(username, rolename))
				{
					throw new ProviderException("User is not in role.");
				}
			}
		}


		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = new OracleCommand("DELETE FROM " + _usersInRolesTable + " " +
				" WHERE Username = :Username AND Rolename = :Rolename AND ApplicationName = :ApplicationName", conn);

		OracleParameter userParm = cmd.Parameters.AddWithValue(":Username", "");
		OracleParameter roleParm = cmd.Parameters.AddWithValue(":Rolename", "");
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		OracleTransaction tran = null;

		try
		{
			conn.Open();
			tran = conn.BeginTransaction();
			cmd.Transaction = tran;

			foreach (string username in usernames)
			{
				foreach (string rolename in rolenames)
				{
					userParm.Value = username;
					roleParm.Value = rolename;
					cmd.ExecuteNonQuery();
				}
			}

			tran.Commit();
		}
		catch (OracleException e)
		{
			try
			{
				tran.Rollback();
			}
			catch { }


			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "RemoveUsersFromRoles");
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}
	}


	//
	// RoleProvider.RoleExists
	//

	public override bool RoleExists(string rolename)
	{
		bool exists = false;

		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = new OracleCommand("SELECT COUNT(*) FROM " + _rolesTable + " " +
				  " WHERE Rolename = :Rolename AND ApplicationName = :ApplicationName", conn);

		cmd.Parameters.AddWithValue(":Rolename", rolename);
		cmd.Parameters.AddWithValue(":ApplicationName", ApplicationName);

		try
		{
			conn.Open();

			long numRecs = Convert.ToInt64(cmd.ExecuteScalar());

			if (numRecs > 0)
			{
				exists = true;
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "RoleExists");
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			conn.Close();
		}

		return exists;
	}

	//
	// RoleProvider.FindUsersInRole
	//

	public override string[] FindUsersInRole(string rolename, string usernameToMatch)
	{
		OracleConnection conn = new OracleConnection(_connectionString);
		OracleCommand cmd = new OracleCommand("SELECT Username FROM " + _usersInRolesTable + " " +
				  "WHERE Username LIKE :UsernameSearch AND Rolename = :Rolename AND ApplicationName = :ApplicationName", conn);
		cmd.Parameters.AddWithValue(":UsernameSearch", usernameToMatch);
		cmd.Parameters.AddWithValue(":RoleName", rolename);
		cmd.Parameters.AddWithValue(":ApplicationName", _ApplicationName);

		string tmpUserNames = "";
		OracleDataReader reader = null;

		try
		{
			conn.Open();

			using (reader = cmd.ExecuteReader())
			{
				while (reader.Read())
				{
					tmpUserNames += reader.GetString(0) + ",";
				}
				reader.Close();
			}
		}
		catch (OracleException e)
		{
			if (WriteExceptionsToEventLog)
			{
				WriteToEventLog(e, "FindUsersInRole");
			}
			else
			{
				throw e;
			}
		}
		finally
		{
			if (reader != null) { reader.Close(); }

			conn.Close();
		}

		if (tmpUserNames.Length > 0)
		{
			// Remove trailing comma.
			tmpUserNames = tmpUserNames.Substring(0, tmpUserNames.Length - 1);
			return tmpUserNames.Split(',');
		}

		return new string[0];
	}

	//
	// WriteToEventLog
	//   A helper function that writes exception detail to the event log. Exceptions
	// are written to the event log as a security measure to avoid private database
	// details from being returned to the browser. If a method does not return a status
	// or boolean indicating the action succeeded or failed, a generic exception is also 
	// thrown by the caller.
	//

	private void WriteToEventLog(OracleException e, string action)
	{
		EventLog log = new EventLog();
		log.Source = eventSource;
		log.Log = eventLog;

		string message = exceptionMessage + "\n\n";
		message += "Action: " + action + "\n\n";
		message += "Exception: " + e.ToString();

		log.WriteEntry(message);
	}

}
#endif