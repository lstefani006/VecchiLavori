using System;
using System.Data;
using System.Configuration;

using Oracle.DataAccess.Client;

/// <summary>
/// Summary description for BL_Login
/// </summary>
public class BL_Login : BL_Base
{
	public BL_Login()
	{
	}

	public bool Login(string userName, string password)
	{
		try
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = cn.CreateCommand())
				{

					cmd.CommandType = CommandType.Text;
					cmd.CommandText = @"select PKID from ""LeoProva"" where ""Login""=:a and ""Password""=:b and ""IsLockedOut""='N'";
					OCI.AddWithValue(cmd, ":a", userName);
					OCI.AddWithValue(cmd, ":b", password);
					cn.Open();
					object obj = cmd.ExecuteScalar();
					if (obj == null)
						return false;

					return true;
				}
			}
		}
		catch (Exception ex)
		{
			string g = ex.Message;
			throw;
		}
	}
}
