using System;
using System.Data;
using System.Drawing;
using System.Configuration;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;


using ITRS_BL;


/// <summary>
/// Summary description for ITRSUtility
/// </summary>
public class ITRSUtility
{
	public static string TranslateNullable(StatoTransito? t)
	{
		if (!t.HasValue)
			return "";
		return Translate(t.Value);
	}

	public static string Translate(StatoTransito t)
	{
		switch (t)
		{
		case StatoTransito.DARIC:
			return "Pendente";

		case StatoTransito.NORIC:
			return "Targa non confermata";

		case StatoTransito.PIC:
			return "In trattazione";

		case StatoTransito.RIC:
			return "Allarme confermato";

		default:
			Debug.Assert(false, "t.StatoTransito non gestito");
			return "";
		}
	}

	public static string TranslateNullable(TipoVarco? t)
	{
		if (!t.HasValue)
			return "";
		return Translate(t.Value);
	}

	public static string Translate(TipoVarco t)
	{
		switch (t)
		{
		case TipoVarco.D:
			return "Corsia destra";

		case TipoVarco.S:
			return "Corsia sinistra";

		case TipoVarco.E:
			return "Entrata area di servizio";

		case TipoVarco.U:
			return "Uscita area di servizio";

		default:
			Debug.Assert(false, "t.TipoVarco non gestito");
			return "";
		}
	}

	public static string TranslateNullable(Direzione? t)
	{
		if (!t.HasValue)
			return "";
		return Translate(t.Value);
	}


	public static string Translate(Direzione t)
	{
		switch (t)
		{
		case Direzione.NORD:
			return "Nord";

		case Direzione.SUD:
			return "Sud";

		default:
			Debug.Assert(false, "t.DirezioneC2P non gestito");
			return "";
		}
	}


	public static string Translate(BLQueueJobs.JobStatus jobStatus)
	{
		switch (jobStatus)
		{
		case BLQueueJobs.JobStatus.QUEUE:
			return "Accodato";

		case BLQueueJobs.JobStatus.RUN:
			return "In esecuzione";

		case BLQueueJobs.JobStatus.SOSP:
			return "Sospeso";

		case BLQueueJobs.JobStatus.ERR:
			return "Errore";
		case BLQueueJobs.JobStatus.RRES:
			return "Ris. parziali";
		case BLQueueJobs.JobStatus.END:
			return "Concluso";
		case BLQueueJobs.JobStatus.ABRQ:
			return "In attesa di abort";
		case BLQueueJobs.JobStatus.ABAK:
			return "Abortito";
		case BLQueueJobs.JobStatus.CANC:
			return "Cancellato";
		default:
			Debug.Assert(false, "BLQueueJobs.JobStatus non gestito");
			return "";
		}
	}

	public static string Translate(ClasseUrgenza cu)
	{
		switch (cu)
		{
		case ClasseUrgenza.ATT:
			return "Attuale";

		case ClasseUrgenza.OBS:
			return "Obsoleto";

		case ClasseUrgenza.RIT:
			return "Ritardato";

		default:
			Debug.Assert(false, "ClasseUrgenza non gestito");
			return "";
		}
	}
	public static string Translate(TipoEvento? te)
	{
		if (te.HasValue)
			return Translate(te.Value);
		else
			return "";
	}
	public static string Translate(TipoEvento te)
	{
		switch (te)
		{

		case TipoEvento.EFV:
			return "Elevata frequenza di visite su singola area";

		case TipoEvento.ENV:
			return "Elevato numero di aree di servizio visitate";

		case TipoEvento.TS:
			return "Transito segnalato";

		case TipoEvento.TSE:
			return "Tempo di sosta elevato su singola area di servizio";

		case TipoEvento.VMS:
			return "Superamento velocit� media di tratta";

		default:
			Debug.Assert(false, "TipoEvento non gestito");
			return "";
		}
	}

	public static string Translate(StatoAllarme st)
	{
		switch (st)
		{
		case StatoAllarme.ACQ:
			return "Pendente";

		case StatoAllarme.CNF:
			return "Allarme positivo";

		case StatoAllarme.NCNF:
			return "Allarme negativo";

		case StatoAllarme.PIC:
			return "In trattazione";

		default:
			Debug.Assert(false, "StatoAllarme non gestito");
			return "";
		}
	}
	public static string Translate(StatoAllarme ? st)
	{
		if (st.HasValue)
			return Translate(st.Value);
		else
			return "";
	}


	public static string PrintDataOra(DateTime dt)
	{
		return dt.ToString("G");
	}
	public static string PrintDataOra(DateTime? dt)
	{
		if (dt.HasValue)
			return dt.Value.ToString("G");
		return "";
	}

	/// <summary>
	/// Ritorna -1 se l'utente non sta lavorando in un COA, altrimenti l'id del COA
	/// </summary>
	/// <returns></returns>
	public static int GetCoaDiAppartenenza()
	{
		try
		{
			HttpRequest Request = HttpContext.Current.Request;

			string userName = HttpContext.Current.User.Identity.Name;

			for (int c = 0; c < Request.Cookies.Count; ++c)
			{
				if (Request.Cookies[c].Name == "CoaAppartenenza_" + userName)
				{
					int idCoa = int.Parse(Request.Cookies[c].Value);
					return idCoa;
				}
			}

		}
		catch (Exception ex)
		{
			Log.Write(ex, "GetCoaDiAppartenenza");
			return -1;
		}

		return -1;
	}

	public static void PulisciCookieCoaDiAppartenenza()
	{
		try
		{
			HttpRequest Request = HttpContext.Current.Request;

			List<string> ee = new List<string>();

			for (int c = 0; c < Request.Cookies.Count; ++c)
				if (Request.Cookies[c].Name.StartsWith("CoaAppartenenza_"))
					ee.Add(Request.Cookies[c].Name);

			foreach (string ck in ee)
				Request.Cookies.Remove(ck);
		}
		catch (Exception ex)
		{
			Log.Write(ex, "PulisciCookieCoaDiAppartenenza");
		}
	}

	/// <summary>
	/// Imposta il Coa di competenza dell'utente collegato.
	/// </summary>
	/// <param name="idCoa"></param>
	public static void SetCoaDiAppartenenza(string userName, int idCoa)
	{
		HttpResponse Response = HttpContext.Current.Response;

		if (idCoa < 0)
			Response.Cookies.Remove("CoaAppartenenza_" + userName);
		else
		{
			HttpCookie ck = new HttpCookie("CoaAppartenenza_" + userName);
			ck.Value = idCoa.ToString();
			ck.Expires = DateTime.Now.AddDays(10);
			Response.Cookies.Add(ck);
		}
	}


	public static List<string> GetProfileList()
	{
		List<string> ret = new List<string>();

		// <add key="Profilo_1" value="NomeProfilo1,Ruolo1,Ruolo2,Ruolo3"/>
		for (int i = 0; i < 100; ++i)
		{
			string key = string.Format("Profilo_{0}", i);
			string value = ConfigurationManager.AppSettings[key];
			if (string.IsNullOrEmpty(value))
				continue;

			string[] g = value.Split(',');
			string rr = g[0].Trim(' ', '\t', '\n', '\r');
			ret.Add(rr);
		}
		return ret;
	}

	public static string[] GetRolesOfProfile(string profileName)
	{
		List<string> ret = new List<string>();

		// <add key="Profilo_1" value="NomeProfilo1, Ruolo1, Ruolo2, Ruolo3"/>
		for (int i = 0; i < 100; ++i)
		{
			string key = string.Format("Profilo_{0}", i);
			string value = ConfigurationManager.AppSettings[key];
			if (string.IsNullOrEmpty(value))
				continue;

			string[] g = value.Split(',');
			if (g[0] == profileName)
			{
				for (int r = 1; r < g.Length; ++r)
				{
					string rr = g[r].Trim(' ', '\t', '\n', '\r');
					if (!rr.StartsWith("#"))
						ret.Add(rr);
				}
				break;
			}
		}
		return ret.ToArray();
	}
	public static string GetDefaultProfileForNewUsers()
	{
		string value = ConfigurationManager.AppSettings["Profilo_Default"];
		return value;
	}

	// //////////////////////////////////////////////////////////////////
	// Controllo targa/nazionalita

	public static string ControllaTarga(ref string targa, bool targaObbligatoria)
	{
		if (targa == null) targa = string.Empty;
		targa = targa.Replace(" ", "").ToUpper();

		if (targa.Length == 0 && targaObbligatoria)
			return "Inserire una targa";

		foreach (char c in targa)
		{
			if (!(c >= 'A' && c <= 'Z' || c >= '0' && c <= '9'))
			{
				return "La targa puo` contenere solo caratteri A-Z 0-9";
			}
		}
		if (targa.Length > 10)
			return "La targa contiene troppi caratteri";

		if (targa.Length < 3)
			return "Targa troppo corta";

		return null;
	}
	public static string ControllaNazionalita(ref string nazione, bool nazioneObbligatoria)
	{
		if (nazione == null) nazione = string.Empty;
		nazione = nazione.Replace(" ", "").ToUpper();

		if (nazione.Length == 0 && nazioneObbligatoria)
			return "Inserire una targa";


		foreach (char c in nazione)
			if (!(c >= 'A' && c <= 'Z'))
				return "La nazionalita` puo` contenere solo caratteri A-Z";

		if (nazione.Length > 3)
			return "La nazionalita` contiene troppi caratteri";

		return null;
	}


	public static void UpdateUserRoles(string userName)
	{
		MembershipUserWithProfile mu = Membership.GetUser(userName, false) as MembershipUserWithProfile;
		OracleMembershipProvider mo = Membership.Provider as OracleMembershipProvider;
		mo.ChangeUserProfile(mu.UserName, mu.UserProfile);
	}


	public static string ControllaPassword(string newPwd1, string newPwd2, string oldPwd)
	{
		if (newPwd1 != newPwd2)
			return "Le due password inserite non coincidono!";

		int minPwdLen = ReadAppSettings.ToInt32("Login.MinPasswordLen", 6);

		if (newPwd2.Length < minPwdLen)
			return string.Format( "La password deve essere composta da almeno {0} caratteri!", minPwdLen);

		if (oldPwd != null)
		{
			if (newPwd1 == oldPwd)
				return "La nuova password non puo` coincidere con la password attuale!";
		}

		int number = 0;
		int letter = 0;
		int other = 0;

		for (int i = 0; i < newPwd1.Length; ++i)
		{
			if (char.IsNumber(newPwd1, i))
				number += 1;

			else if (char.IsLetter(newPwd1, i))
				letter += 1;

			else if (char.IsControl(newPwd1, i))
				return "La password non puo` contenere caratteri di controllo!";

			else if (char.IsWhiteSpace(newPwd1, i))
				return "La password non puo` contenere spazi bianchi!";

			else if (!char.IsPunctuation(newPwd1, i))
				return "La password non puo` contenere altri caratteri al di fuori di numeri, lettere e caratteri di interpunzione!";

			else
				other += 1;
		}


		if (number == 0 && ReadAppSettings.ToBoolean("Login.NuovaPassword.NumeriObbligatori", false))
			return "La nuova password deve contenere almeno un numero!";

		if (letter == 0 && ReadAppSettings.ToBoolean("Login.NuovaPassword.LettereObbligatorie", false))
			return "La nuova password deve contenere almeno una lettera!";

		if (other == 0 && ReadAppSettings.ToBoolean("Login.NuovaPassword.AltriObbligatori", false))
			return "La nuova password deve contenere almeno una carattere diverso da lettera e numero!";

		return null;
	}

	/// <summary>
	/// Controlla la password.
	/// Ritorna false se la password e` errata
	/// </summary>
	/// <param name="newPwd1"></param>
	/// <param name="newPwd2"></param>
	/// <param name="oldPwd"></param>
	/// <param name="lblError"></param>
	/// <returns>false se la password e` errata</returns>
	public static bool ControllaPassword(string newPwd1, string newPwd2, string oldPwd, Label lblError)
	{
		string errMsg = ControllaPassword(newPwd1, newPwd2, oldPwd);
		if (string.IsNullOrEmpty(errMsg))
			return true;

		lblError.Visible = true;
		lblError.ForeColor = Color.Red;
		lblError.Text = errMsg;
		return false;
	}



	public static T ReadQueryString<T>(HttpContext context, string key, T defaultValue)
	{
		string[] allKeys = context.Request.QueryString.AllKeys;
		for (int i = 0; i < allKeys.Length; ++i)
		{
			if (string.Compare(allKeys[i], key, true) == 0)
			{
				string v = context.Request.QueryString[i];
				T ret = (T)Convert.ChangeType(v, typeof(T), CultureInfo.InvariantCulture);
				return ret;
			}
		}
		return defaultValue;
	}

	public static DateTime ReadQueryString(HttpContext context, string key, DateTime defaultValue)
	{
		string[] allKeys = context.Request.QueryString.AllKeys;
		for (int i = 0; i < allKeys.Length; ++i)
		{
			if (string.Compare(allKeys[i], key, true) == 0)
			{
				string v = context.Request.QueryString[i];
				try
				{
					return YYYY_MM_DD_HH24_MI_SS_ToDateTime(v);
				}
				catch
				{
					return defaultValue;
				}
			}
		}
		return defaultValue;
	}

	public static string DateTimeToYYYY_MM_DD_HH24_MI_SS(DateTime dt)
	{
		// yyyy MM dd HH mm ss
		return string.Format("{0:yyyy} {0:MM} {0:dd} {0:HH} {0:mm} {0:ss}", dt);
	}
	public static DateTime YYYY_MM_DD_HH24_MI_SS_ToDateTime(string sv)
	{
		string[] s = sv.Split(' ');
		return new DateTime(
			int.Parse(s[0]),
			int.Parse(s[1]),
			int.Parse(s[2]),
			int.Parse(s[3]),
			int.Parse(s[4]),
			int.Parse(s[5]));
	}
}
