using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;

[Serializable]
public class RuoliUtente
{
	public RuoliUtente(string u, string r) { _ruolo = r; _utente = u; }
	string _ruolo;
	string _utente;

	public string Utente { get { return _utente; } }
	public string Ruolo { get { return _ruolo; } }
}

[Serializable]
public class Ruoli
{
	public Ruoli(string r) { _ruolo = r; }
	string _ruolo;

	public string Ruolo { get { return _ruolo; } }
}

[Serializable]
public class Utenti
{
	public Utenti(string u) { _utente = u; }
	string _utente;

	public string Utente { get { return _utente; } }
}


/// <summary>
/// Summary description for BL_RuoliDellUtente
/// </summary>
public class BL_RuoliDellUtente
{
	public BL_RuoliDellUtente()
	{
	}

	public List<MembershipUser> GetUtenti()
	{
		List<MembershipUser> ret = new List<MembershipUser>();
		foreach (MembershipUser u in Membership.GetAllUsers())
			ret.Add(u);
		return ret;
	}

    //public List<MembershipUser> DeleteUtente()
    //{
    //    //List<MembershipUser> ret = new List<MembershipUser>();
    //    //foreach (MembershipUser u in Membership.DeleteUser())
    //    //    ret.Add(u);
    //    //return ret;
    //}


	public List<Ruoli> GetRuoli()
	{
		List<Ruoli> ret = new List<Ruoli>();
		foreach (string s in Roles.GetAllRoles())
			ret.Add(new Ruoli(s));
		return ret;
	}

	public List<RuoliUtente> GetRuoliUtente(string utente)
	{
		List<RuoliUtente> ret = new List<RuoliUtente>();
		foreach (string s in Roles.GetRolesForUser(utente))
			ret.Add(new RuoliUtente(utente, s));
		return ret;
	}

	public List<Utenti> GetUtentiAbilitatiAlRuolo(string ruolo)
	{
		List<Utenti> ret = new List<Utenti>();
		foreach (string s in Roles.GetUsersInRole(ruolo))
			ret.Add(new Utenti(s));
		return ret;
	}


	public List<RuoliUtente> GetNuoviRuoliUtente(string utente)
	{
		string[] vecchiRuoli = Roles.GetRolesForUser(utente);
		string[] tuttiIRuoli = Roles.GetAllRoles();

		List<RuoliUtente> ret = new List<RuoliUtente>();

		foreach (string s in tuttiIRuoli)
		{
			bool found = false;
			foreach (string vr in vecchiRuoli)
				if (s == vr)
				{
					found = true;
					break;
				}
			if (!found)
				ret.Add(new RuoliUtente(utente, s));
		}

		return ret;
	}

	public List<RuoliUtente> GetNuoviUtentiPerRuolo(string ruolo)
	{
		MembershipUserCollection tuttiGliUtenti = Membership.GetAllUsers();
		string[] utentiAttuali = Roles.GetUsersInRole(ruolo);

		List<RuoliUtente> ret = new List<RuoliUtente>();

		foreach (MembershipUser s in tuttiGliUtenti)
		{
			bool found = false;
			foreach (string vr in utentiAttuali)
				if (s.UserName == vr)
				{
					found = true;
					break;
				}
			if (!found)
				ret.Add(new RuoliUtente(s.UserName, ruolo));
		}

		return ret;
       
	}


	public void RemoveUserFromRoles(string utente, string ruolo)
	{
		Roles.RemoveUserFromRoles(utente, new string[] { ruolo });
	}
}
