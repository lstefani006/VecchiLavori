using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Main : System.Web.UI.MasterPage
{
	protected override void OnLoad(EventArgs e)
	{
		base.OnLoad(e);
	}
	protected override void OnPreRender(EventArgs e)
	{
		base.OnPreRender(e);
		utenteCollegato.InnerHtml = "Operatore collegato: " + HttpContext.Current.User.Identity.Name;

		int idCoa = ITRSUtility.GetCoaDiAppartenenza();
		if (idCoa >= 0)
		{
			string g = BLCacher.GetDescrizioneCOA(idCoa);
			this.coaUtenteCollegato.InnerText = "COA di appartenenza: " + g;
		}
	}
}
