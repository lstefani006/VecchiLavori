using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class ProvaAccesso : PageBase
{
	public ProvaAccesso()
	{
	}

	protected void Page_Init(object sender, EventArgs e)
	{
		Evento1.CambioStato += new Dettaglio_Evento.CambioStatoDelegate(Evento1_CambioStato);
//		Transito1.CambioStato += new Dettaglio_Transito.CambioStatoDelegate(Transito1_CambioStato);
	}

	//void Transito1_CambioStato(object sender, Dettaglio_Transito.CambioStatoEvent e)
	//{
	//}
	void Evento1_CambioStato(object sender, Dettaglio_Evento.CambioStatoEvent e)
	{
	}
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			Transito1.VisualizzaTS("CA941GC", "I", new DateTime(2006, 04, 27, 14, 29, 13));
			Evento1.VisualizzaEvento("CA941GC", "I", new DateTime(2006, 04, 27, 15, 24, 38), 1131488);
			Immagine1.VisualizzaImmagine("CA941GC", "I", new DateTime(2006, 04, 27, 14, 29, 13));
		}
	}
}
