using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Text;

using ITRS_BL;

public partial class LTS_ImportMassivo : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		if (!IsCallback)
		{
			try
			{
				// file della CB con i file presenti su linux
				using (BLLTSImport bl = new BLLTSImport())
				{
					bool ftpError;
					List<string> ret = bl.GetListaFileSuLinuxPerImport(out ftpError);
					if (ftpError == false)
					{
						foreach (string fileName in ret)
							this.fileSuLinux.Items.Add(new ListItem(fileName, fileName));
					}
					else
					{
						this.fileSuLinux.Items.Add(new ListItem("Server non disponibile", ""));
					}
				}
			}
			catch
			{
				this.fileSuLinux.Items.Add(new ListItem("Server non disponibile", ""));
			}
		}
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsCallback)
		{
			rbTipoSorgente_SelectedIndexChanged(null, null);
			importMassivo_UpdateZone.InnerHtml = BuildAttivitaDelGiorno();
		}
	}

	protected void rbTipoSorgente_SelectedIndexChanged(object sender, EventArgs e)
	{
		switch (rbTipoSorgente.SelectedValue)
		{
		case "pathDaLinux":
			this.fileUploadLocale.Visible = false;
			this.fileLocale.Visible = false;
			this.fileSuLinux.Visible = true;
			break;
		case "pathDaWeb":
			this.fileUploadLocale.Visible = false;
			this.fileLocale.Visible = true;
			this.fileSuLinux.Visible = false;
			break;

		case "Upload":
			this.fileUploadLocale.Visible = true;
			this.fileLocale.Visible = false;
			this.fileSuLinux.Visible = false;
			break;
		}
	}

	protected void btnCarica_Click(object sender, EventArgs e)
	{
		lblError.Text = "";

		bool incrementale = (rbMetodoImportazione.SelectedValue == "incrementale") ? true : false;
		BLLTSImport.TipoLTS tipoLTS = rbTipoA1orA2.SelectedValue == "A1" ? BLLTSImport.TipoLTS.A1 : BLLTSImport.TipoLTS.A2;

		if (incrementale && BLLTSImport.TipoLTS.A2 == tipoLTS)
		{
			lblError.ForeColor = System.Drawing.Color.Red;
			lblError.Text = "Gli import A2 possono essere solo massivi !";
			return;
		}

		try
		{
			switch (rbTipoSorgente.SelectedValue)
			{
			case "Upload":
				{
					if (fileUploadLocale.HasFile == false)
					{
						lblError.ForeColor = System.Drawing.Color.Red;
						lblError.Text = "Selezionare un file!";
						return;
					}

					string ext = Path.GetExtension(fileUploadLocale.FileName).ToLower();
					if (!(ext == ".zip" || ext == ".txt"))
					{
						lblError.Text = "Il file non ha l'estensione corretta! Deve essere .zip o .txt";
						return;
					}

					Byte[] fileBytes = fileUploadLocale.FileBytes;
					using (BLLTSImport bl = new BLLTSImport())
					{
						if (incrementale)
							bl.ImportIncrementaleA1(UserName, Path.GetFileName(fileUploadLocale.FileName), fileBytes);
						else
							bl.ImportMassivo(UserName, Path.GetFileName(fileUploadLocale.FileName), fileBytes, tipoLTS);
					}
				}
				break;

			case "pathDaLinux":
				{
					bool onLinux = true;

					string fileDaImportare = this.fileSuLinux.SelectedValue;
					string ext = Path.GetExtension(fileDaImportare).ToLower();
					if (!(ext == ".zip" || ext == ".txt"))
					{
						lblError.Text = "Il file non ha l'estensione corretta! Deve essere .zip o .txt";
						return;
					}

					using (BLLTSImport bl = new BLLTSImport())
					{
						if (incrementale)
							bl.ImportIncrementaleA1(UserName, fileDaImportare, onLinux);
						else
							bl.ImportMassivo(UserName, fileDaImportare, tipoLTS, onLinux);
					}
				}
				break;

			case "pathDaWeb":
				{
					bool onLinux = false;

					string fileDaImportare = this.fileLocale.Text.Trim();

					string ext = Path.GetExtension(fileDaImportare).ToLower();
					if (!(ext == ".zip" || ext == ".txt"))
					{
						lblError.Text = "Il file non ha l'estensione corretta! Deve essere .zip o .txt";
						return;
					}

					using (BLLTSImport bl = new BLLTSImport())
					{
						if (incrementale)
							bl.ImportIncrementaleA1(UserName, fileDaImportare, onLinux);
						else
							bl.ImportMassivo(UserName, fileDaImportare, tipoLTS, onLinux);
					}
				}
				break;

			default:
				Debug.Assert(false);
				break;
			}

			lblError.ForeColor = System.Drawing.Color.Black;
			lblError.Text = "Import massivo lanciato!";
		}
		catch (FileNotFoundException ex)
		{
			lblError.Text = "File non trovato: " + ex.Message;
		}
		catch (Exception ex)
		{
			Log.Write(ex, "LTS_ImportMassivo.btnCarica_Click");
			lblError.Text = ex.Message;
		}
	}

	private string BuildAttivitaDelGiorno()
	{
		try
		{
			using (StringWriter sw = new StringWriter())
			{
				sw.WriteLine("<table cellspacing=\"0\" cellpadding=\"5\" border=\"0\" style=\"border-style:double; border-width:2pt; border-color:#E7E5DB;border-collapse:collapse\">");
				{
					sw.WriteLine("<tr style=\"color:#585880;border-color:#CCCCCC;border-width:1pt;border-style:solid;font-weight:normal;\" class=\"theme_header\">");
					{
						sw.WriteLine("<td>Data/Ora</tr>");
						sw.WriteLine("<td>Operatore</tr>");
						sw.WriteLine("<td>Descrizione</tr>");
					}
					sw.WriteLine("</tr>");

					BLLog bl = new BLLog();
					List<BLLog.UserLogData> r = bl.GetAttivitaDelGiorno(DateTime.Now.Date, "ImportLTS");
					// List<BLLog.UserLogData> r = bl.GetAttivitaDelGiorno(new DateTime(2006, 9,8), "Accesso");// TODO LEO
					int n = 0;
					foreach (BLLog.UserLogData u in r)
					{
						if (n % 2 == 0)
							sw.WriteLine("<tr style=\"font-weight:normal; color:#585880; background:#FFFFFF\">");
						else
							sw.WriteLine("<tr style=\"font-weight:normal; color:#585880; background:#F8F7F4\">");

						{
							sw.WriteLine("<td>{0}</tr>", u.TS);
							sw.WriteLine("<td>{0}</tr>", u.UserName);
							sw.WriteLine("<td>{0}</tr>", u.Descrizione);
						}
						sw.WriteLine("</tr>");

						n++;
					}

					if (n == 0)
					{
						sw.WriteLine("<tr style=\"font-weight:normal; color:#585880; background:#FFFFFF\">");
						sw.WriteLine("<td colspan='3'>Nessun import e` stato effettuato oggi.</td>");
						sw.WriteLine("</tr>");
					}
				}
				sw.WriteLine("</table>");

				sw.Flush();
				return sw.ToString();
			}
		}
		catch
		{
			return "";
		}
	}

	protected void clientTimerImportMassivo_ClientCall(object sender, ITRSControls.ClientTimerClientTimerEventArgs e)
	{
		e.Result = BuildAttivitaDelGiorno();
	}
	protected void btnResetA2_Click(object sender, EventArgs e)
	{
		try
		{
			using (BLLTSImport bl = new BLLTSImport())
			{
				bl.CancellaLTS(UserName, BLLTSImport.TipoLTS.A2);
			}
		}
		catch (Exception ex)
		{
			lblError.ForeColor = System.Drawing.Color.Red;
			lblError.Text = ex.Message;
		}
	}
}
