using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

using ITRS_BL;

public partial class LTS_ExpImpLTS_TipoC : PageBase
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}

	protected void btnExport_Click(object sender, EventArgs e)
	{
		ExportLTSData dd = new ExportLTSData();
		dd.IdUtenteRichiedente = UserPkId;
		dd.IdCoa = ITRSUtility.GetCoaDiAppartenenza();
		if (dd.IdCoa < 0)
		{
			lblError.Text = "Attenzione! Solo un operatore con assegnato il COA di competenza puo` esportare i dati";
			return;
		}

		MemoryStream ms = new MemoryStream();
		BinaryFormatter bf = new BinaryFormatter();
		bf.Serialize(ms, dd);
		string gg = Convert.ToBase64String(ms.ToArray());
		dnlWindow.Attributes["src"] = "/ITRSWeb/LTS/DownloadLTSTipoC.aspx?Action=" + gg;
	}

	protected void btnImport_Click(object sender, EventArgs e)
	{
		if (!fileUpload.HasFile)
		{
			lblError.Text = "Selezionare un file!";
			return;
		}

		int IdCoa = ITRSUtility.GetCoaDiAppartenenza();
		if (IdCoa < 0)
		{
			lblError.Text = "Attenzione! Solo un operatore con assegnato il COA di competenza puo` esportare i dati";
			return;
		}


		Byte[] fileContent = fileUpload.FileBytes;

		BLLTS bl = new BLLTS();
		List<string> err = bl.Import_LTS_C(UserPkId, IdCoa, System.Text.Encoding.UTF8.GetString(fileContent));


		if (err.Count > 0)
			PageBase.AddUserActivity(TipoAttivita.LTS,	"Import in LTS Tipo C: errori riscontrati: {0}", err.Count);
		else
			PageBase.AddUserActivity(TipoAttivita.LTS, "Import in LTS Tipo C: nessun errore riscontrato");



		if (err.Count == 0)
		{
			lblError.Text = "Elaborazione terminata con successo.";
			return;
		}

		Repeater1.DataSource = err;
		Repeater1.DataBind();

	}
}
