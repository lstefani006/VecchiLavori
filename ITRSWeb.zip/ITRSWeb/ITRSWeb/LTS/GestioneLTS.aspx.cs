using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;

using ITRS_BL;


public partial class LTS_GestioneLTS : PageBase
{
	/*
			<tr>
				<td>Inizio validita` dal (GG/MM/AAAA hh.mm.ss):</td>
				<td>
					<asp:TextBox runat="server" ID="txRicercaInizioDal" />
					<asp:CustomValidator runat="server" ID="custDal" ControlToValidate="txRicercaInizioDal"
					Display="Dynamic" ErrorMessage="Immettere una data/ora nel formato GG/MM/AAAA hh.mm.ss"
					Text="Data in formato non corretto (GG/MM/AAAA hh.mm.ss)"
					OnServerValidate="custDal_ServerValidate"
					ClientValidationFunction="validateDate_txRicercaInizioDal"
					EnableClientScript="true" />
				</td>
			</tr>
			<tr>
				<td>Inizio validita` al (GG/MM/AAAA hh.mm.ss):</td>
				<td>
					<asp:TextBox runat="server" ID="txRicercaInizioAl" />
					<asp:CustomValidator runat="server" ID="CustomValidator1" ControlToValidate="txRicercaInizioAl"
					Display="Dynamic" ErrorMessage="Immettere una data/ora nel formato GG/MM/AAAA hh.mm.ss"
					Text="Data in formato non corretto (GG/MM/AAAA hh.mm.ss)"
					OnServerValidate="custDal_ServerValidate"
					ClientValidationFunction="validateDate_txRicercaInizioAl"
					EnableClientScript="true" />
				</td>
			</tr>
			<tr>
				<td>Fine validita` dal (GG/MM/AAAA hh.mm.ss):</td>
				<td>
					<asp:TextBox runat="server" ID="txRicercaFineDal" />
					<asp:CustomValidator runat="server" ID="CustomValidator2" ControlToValidate="txRicercaFineDal"
					Display="Dynamic" ErrorMessage="Immettere una data/ora nel formato GG/MM/AAAA hh.mm.ss"
					Text="Data in formato non corretto (GG/MM/AAAA hh.mm.ss)"
					OnServerValidate="custDal_ServerValidate"
					ClientValidationFunction="validateDate_txRicercaFineDal"
					EnableClientScript="true" />
				</td>
			</tr>
			<tr>
				<td>Fine validita` al (GG/MM/AAAA hh.mm.ss):</td>
				<td>
					<asp:TextBox runat="server" ID="txRicercaFineAl" />
					<asp:CustomValidator runat="server" ID="CustomValidator3" ControlToValidate="txRicercaFineAl"
					Display="Dynamic" ErrorMessage="Immettere una data/ora nel formato GG/MM/AAAA hh.mm.ss"
					Text="Data in formato non corretto (GG/MM/AAAA hh.mm.ss)"
					OnServerValidate="custDal_ServerValidate"
					ClientValidationFunction="validateDate_txRicercaFineAl"
					EnableClientScript="true" />
				</td>
			</tr>
	 * 
	 * 
	 * 

			<tr><td>Inizio validita` dal:</td><td><%= this.txRicercaInizioDal.Text %></td></tr>
			<tr><td>Inizio validita` al:</td><td><%= this.txRicercaInizioAl.Text %></td></tr>
			<tr><td>Fine validita` dal:</td><td><%= this.txRicercaFineDal.Text %></td></tr>
			<tr><td>Fine validita` al:</td><td><%= this.txRicercaFineAl.Text %></td></tr>

 
	 * 
			<asp:BoundField DataField="DataOraInserimento" SortExpression="DataOraInserimento" HeaderText="Inserito il" />
			<asp:BoundField DataField="DataOraInizioValidita" SortExpression="DataOraInizioValidita" HeaderText="Valido dal"  />
			<asp:BoundField DataField="DataOraFineValidita" SortExpression="DataOraFineValidita" HeaderText="Valido fino"  />

 
	*/

	protected override void OnInit(EventArgs e)
	{
		base.OnInit(e);

		this.Page.RegisterRequiresControlState(this);
		this.PreRender += new EventHandler(LTS_GestioneLTS_PreRender);

		this._id = new ControlState();

		try
		{
			List<ITRS_BL.Coa> lstCoa = BLCacher.GetListaCOA();
			foreach (ITRS_BL.Coa c in lstCoa)
				edit_ddlCoa.Items.Add(new ListItem(c.Descrizione, c.IdCOA.ToString()));
		}
		catch
		{
			lblError.Text = "Errore leggendo la lista dei COA";
		}

		try
		{
			List<ITRS_BL.Coa> lstCoa = BLCacher.GetListaCOA();
			ricerca_ddlRicercaCoa.Items.Add(new ListItem("Tutti i COA", ""));
			foreach (ITRS_BL.Coa c in lstCoa)
				ricerca_ddlRicercaCoa.Items.Add(new ListItem(c.Descrizione, c.IdCOA.ToString()));
		}
		catch
		{
			lblError.Text = "Errore leggendo la lista dei COA";
		}

		try
		{
			List<ITRS_BL.BLLTS.UtenteRichiedente> lstUtRic = BLCacher.GetListaUtenteRichiedentePerRicercaLTS();
			foreach (ITRS_BL.BLLTS.UtenteRichiedente c in lstUtRic)
				ricerca_ddlUtenteRichiedente.Items.Add(new ListItem(c.UserName, c.Chiave));
		}
		catch
		{
			lblError.Text = "Errore leggendo la lista degli utenti richiedenti.";
		}


		try
		{
			List<ITRS_BL.BLLTSImport.Nazione> listaNazioni = BLCacher.GetListaNazioni();

			ricerca_ddlNazionalita.Items.Add(new ListItem("* - tutte le nazioni", ""));
			foreach (ITRS_BL.BLLTSImport.Nazione c in listaNazioni)
			{
				edit_ddrNazionalita.Items.Add(new ListItem(c.Sigla_Nazione + " " + c.Nome_Nazione, c.Sigla_Nazione));
				ricerca_ddlNazionalita.Items.Add(new ListItem(c.Sigla_Nazione + " " + c.Nome_Nazione, c.Sigla_Nazione));
			}
			edit_ddrNazionalita.SelectedValue = "I";
			ricerca_ddlNazionalita.SelectedValue = "I";

		}
		catch
		{
			lblError.Text = "Errore leggendo la lista delle nazioni.";
		}

		this.ricerca_ddlTipoSegnalazione.Attributes["onchange"] = "return ddlTipoSegnalazioneOnChange(this);";
		this.filtroIdCOAperC_Visible = false;
		this.filtroRichiedente_Visible = false;
		this.filtroEmail_Visible = false;

	}

	public bool filtroIdCOAperC_Visible { set { SetTbRowVisible(filtroIdCOAperC, value); } }
	public bool filtroRichiedente_Visible { set { SetTbRowVisible(filtroRichiedente, value); } }
	public bool filtroEmail_Visible { set { SetTbRowVisible(filtroEmail, value); } }

	public bool riepilogoRichiedente_Visible { set { SetTbRowVisible(riepilogoRichiedente, value); } }
	public bool riepilogoEmail_Visible { set { SetTbRowVisible(riepilogoEmail, value); } }
	public bool riepilogoCOA_Visible { set { SetTbRowVisible(riepilogoCOA, value); } }

	private void SetTbRowVisible(HtmlTableRow tr, bool v)
	{
		if (v)
			tr.Style[HtmlTextWriterStyle.Visibility] = "";
		else
			tr.Style[HtmlTextWriterStyle.Visibility] = "hidden";
	}

	private void RemoveDDLItem(DropDownList d, string value)
	{
		for (int r = 0; r < d.Items.Count; ++r)
			if (d.Items[r].Value == value)
			{
				d.Items.RemoveAt(r);
				return;
			}
	}

	private static void RemoveAllDDLItemsExcept(DropDownList d, string value)
	{
		for (; ; )
		{
		again:
			for (int r = 0; r < d.Items.Count; ++r)
				if (d.Items[r].Value != value)
				{
					d.Items.RemoveAt(r);
					goto again;
				}
		}
	}


	//Gli utenti appartenenti ad un COA, con gli opportuni privilegi 
	// Consultazione LTS A1 Consultazione LTS A2 
	// Consultazione LTS  B Consultazione LTS  C  
	// Gestione LTS A1      Gestione LTS A2 
	// Gestione LTS  B      Gestione LTS  C
	// 
	//5) Vedere targhe lista A non scadute e inseriti dal CEPS
	//6) Vedere e modificare targhe in lista B con qualsiasi scadenza e appartenenti solo all'operatore
	//7) Vedere e modificare targhe in lista C con qualsiasi scadenza e inserite dagli operatori del COA di appartenenza

	bool _consultazione_A1;
	bool _consultazione_A2;
	bool _consultazione_B;
	bool _consultazione_C;

	bool _gestione_A1;
	bool _gestione_A2;
	bool _gestione_B;
	bool _gestione_C;

	//Creiamo nuovo privilegio Amministrazione LTS che associato ad un operatore gli permette di:
	//1) Vedere e modificare targhe lista A con qualsiasi scadenza e appartenenti a chiunque
	//2) Vedere e modificare targhe lista B con qualsiasi scadenza e appartenenti a chiunque
	//3) Vedere e modificare targhe lista C con qualsiasi scadenza e appartenenti a chiunque
	//4) Vedere e modificare targhe lista BIANCA con qualsiasi scadenza e appartenenti a chiunque
	bool _amministrazione_LTS;



	protected void Page_Load(object sender, EventArgs e)
	{
		_consultazione_A1 = User.IsInRole("Consultazione LTS A1");
		_consultazione_A2 = User.IsInRole("Consultazione LTS A2");
		_consultazione_B = User.IsInRole("Consultazione LTS B");
		_consultazione_C = User.IsInRole("Consultazione LTS C");

		_gestione_A1 = User.IsInRole("Gestione LTS A1"); if (_gestione_A1) _consultazione_A1 = true;
		_gestione_A2 = User.IsInRole("Gestione LTS A2"); if (_gestione_A2) _consultazione_A2 = true;
		_gestione_B = User.IsInRole("Gestione LTS B"); if (_gestione_B) _consultazione_B = true;
		_gestione_C = User.IsInRole("Gestione LTS C"); if (_gestione_C) _consultazione_C = true;

		_amministrazione_LTS = User.IsInRole("Amministrazione LTS");
		if (_amministrazione_LTS)
		{
			_consultazione_A1 = true;
			_consultazione_A2 = true;
			_consultazione_B = true;
			_consultazione_C = true;

			_gestione_A1 = true;
			_gestione_A2 = true;
			_gestione_B = true;
			_gestione_C = true;
		}
		ClientScript.RegisterHiddenField("amministrazione_LTS", _amministrazione_LTS ? "true" : "false");

		if (!(_gestione_A1 || _gestione_A2 || _gestione_B || _gestione_C))
		{
			this.btnNuovoRecordLts.Enabled = false;
		}


		// questa e` usata in ricerca.
		if (!_consultazione_A1) RemoveDDLItem(ricerca_ddlTipoSegnalazione, "A1");
		if (!_consultazione_A2) RemoveDDLItem(ricerca_ddlTipoSegnalazione, "A2");
		if (!_consultazione_B) RemoveDDLItem(ricerca_ddlTipoSegnalazione, "B");
		if (!_consultazione_C) RemoveDDLItem(ricerca_ddlTipoSegnalazione, "C");

		// questa dropdown e` usata in insert.
		if (!_gestione_A1) RemoveDDLItem(edit_ddlTipoLTS, "A1");
		if (!_gestione_A2) RemoveDDLItem(edit_ddlTipoLTS, "A2");
		if (!_gestione_B) RemoveDDLItem(edit_ddlTipoLTS, "B");
		if (!_gestione_C) RemoveDDLItem(edit_ddlTipoLTS, "C");

		if (!IsPostBack)
		{
			this.gvLTS.Sort("Targa", SortDirection.Ascending);
			this.divParametri.Visible = true;
			this.divEditing.Visible = false;
		}

		base.RegisterClientId("LTS",
			/*this.txRicercaInizioDal, this.txRicercaInizioAl,
			this.txRicercaFineDal, this.txRicercaFineAl,*/
			this.ricerca_txRicercaInseritoDal,
			this.ricerca_txRicercaInseritoAl,
			this.btnRicerca,
			this.filtroIdCOAperC,
			this.filtroRichiedente,
			this.filtroEmail,

			this.riepilogoCOA,
			this.riepilogoEmail,
			this.riepilogoRichiedente);

		//this.MaintainScrollPositionOnPostBack = true;
	}

	#region ControlState
	protected override object SaveControlState()
	{
		return _id;
	}
	protected override void LoadControlState(object state)
	{
		_id = state as ControlState;
	}

	[Serializable]
	class ControlState
	{
		public ControlState()
		{
			NuovoLTS = false;
			Sel_Targa = null;
			RicercaPremuta = false;
		}

		public bool RicercaPremuta;

		public bool NuovoLTS;

		public string Sel_Targa;
		public string Sel_Nazionalita;
		public long Sel_IdLts;


		public string Riepologo_Targa = "";
		public string Riepilogo_Nazionalita = "";
		public string Riepologo_TipoLTS = "";

		public string Riepologo_Dal = "";
		public string Riepologo_Al = "";
		public string Riepologo_Richiedente = "";
		public string Riepologo_Email = "";
		public string Riepologo_COA = "";
	}

	ControlState _id = null;
	#endregion


	protected void btnRicerca_Click(object sender, EventArgs e)
	{
		_id.RicercaPremuta = true;

		if (!Page.IsValid)
		{
			lblError.Text = "Dati di ricerca non corretti";
			return;
		}

		this.gvLTS.Sort("Targa", SortDirection.Ascending);
		this.divParametri.Visible = true;
		this._id.Sel_Targa = null;
		this._id.Sel_Nazionalita = null;



		ricerca_txRicercaInseritoDal.Text = ricerca_txRicercaInseritoDal.Text.Trim();
		ricerca_txRicercaInseritoAl.Text = ricerca_txRicercaInseritoAl.Text.Trim();

		DateTime dtA, dtB;
		dtA = new DateTime();
		dtB = new DateTime();

		if (ricerca_txRicercaInseritoDal.Text.Length > 0 && !DateTime.TryParse(ricerca_txRicercaInseritoDal.Text, out dtA))
		{
			txtRicercaError.Text = "Data di inizio ricerca in formato non corretto.";
			txtRicercaError.ForeColor = Color.Red;
			return;
		}
		bool bA = ricerca_txRicercaInseritoDal.Text.Length > 0;


		if (ricerca_txRicercaInseritoAl.Text.Length > 0 && !DateTime.TryParse(ricerca_txRicercaInseritoAl.Text, out dtB))
		{
			txtRicercaError.Text = "Data di fine ricerca in formato non corretto.";
			txtRicercaError.ForeColor = Color.Red;
			return;
		}
		bool bB = ricerca_txRicercaInseritoAl.Text.Length > 0;

		if (bA && bB && dtA > dtB)
		{
			txtRicercaError.Text = "Data fine inizio ricerca maggiore della data fine.";
			txtRicercaError.ForeColor = Color.Red;
			return;
		}


		_id.Riepologo_Targa = ricerca_tbTarga.Text;
        try
        {
            _id.Riepilogo_Nazionalita = ricerca_ddlNazionalita.SelectedItem.Text;
        }
        catch
        {
            _id.Riepilogo_Nazionalita = "I";
        }
		_id.Riepologo_Dal = ricerca_txRicercaInseritoDal.Text;
		_id.Riepologo_Al = ricerca_txRicercaInseritoAl.Text;
		_id.Riepologo_TipoLTS = ricerca_ddlTipoSegnalazione.SelectedItem.Text;
		_id.Riepologo_Richiedente = ricerca_ddlUtenteRichiedente.SelectedItem.Text;
		_id.Riepologo_Email = ricerca_txRicercaEmail.Text;
		_id.Riepologo_COA = ricerca_ddlRicercaCoa.SelectedItem.Text;

		string msg = string.Format("Ricerca in LTS: Targa:{0} Naz: {1} Dal:{2} Al:{3} TipoLTS:{4} Richiedente:{5} Email:{6} COA:{7}",
			_id.Riepologo_Targa,
			_id.Riepilogo_Nazionalita,
			_id.Riepologo_Dal,
			_id.Riepologo_Al,
			_id.Riepologo_TipoLTS,
			_id.Riepologo_Richiedente,
			_id.Riepologo_Email,
			_id.Riepologo_COA);

		AddUserActivity(TipoAttivita.LTS, msg);

		StopEditing();
	}

	protected void gvLTS_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ITRS_BL.BLLTS.LTSRecord row = (ITRS_BL.BLLTS.LTSRecord)e.Row.DataItem;

			if (row.EnumTipoLTS == "B")
			{
				// contiene l'e-mail
				e.Row.Cells[gvLTS.GetCellIndex("AddrDest")].Text = row.AddrDest;
			}
			else if (row.EnumTipoLTS == "C")
			{
				// e` un Intervento.
				// contiene idCoa in formato string (sob)
				string coaDescr = BLCacher.GetDescrizioneCOA(int.Parse(row.AddrDest));
				e.Row.Cells[gvLTS.GetCellIndex("AddrDest")].Text = coaDescr;
			}
			else
			{
				e.Row.Cells[gvLTS.GetCellIndex("AddrDest")].Text = "";
				//e.Row.Cells[gvLTS.GetCellIndex("UserNameRichiedente")].Text = "";
			}
		}
	}


	protected void gvLTS_SelectCount(object sender, ITRSControls.ExGridSelectCountEventArgs e)
	{
		try
		{
			ITRS_BL.BLLTS bl = new ITRS_BL.BLLTS();

			string targa;
			string nazionalita;
			string tipoSegnalazione;
			DateTime? ricercaInizioDal;
			DateTime? ricercaInizioAl;
			DateTime? ricercaFineDal;
			DateTime? ricercaFineAl;
			string IdUtenteRichiedente = null;
			int? IdCoa = null;
			DateTime? ricercaInseritoDal;
			DateTime? ricercaInseritoAl;
			string ricercaEmail;
			int? idCoaPerTipoC;

			string IdUtenteCollegato;
			int? IdCoaDiCompetenzaUtenteCollegato;

			LeggiDati(out targa, out nazionalita,
				out tipoSegnalazione,
				out ricercaInizioDal, out ricercaInizioAl,
				out ricercaFineDal, out ricercaFineAl,
				out IdUtenteRichiedente, out IdCoa,
				out ricercaInseritoDal, out ricercaInseritoAl,
				out ricercaEmail,
				out idCoaPerTipoC,

				out IdUtenteCollegato,
				out IdCoaDiCompetenzaUtenteCollegato);

			int r = bl.GetLTSCount(targa, nazionalita,
				tipoSegnalazione,
				ricercaInizioDal, ricercaInizioAl,
				ricercaFineDal, ricercaFineAl,
				IdUtenteRichiedente, IdCoa,
				ricercaInseritoDal, ricercaInseritoAl,
				ricercaEmail, idCoaPerTipoC,
				IdUtenteCollegato, IdCoaDiCompetenzaUtenteCollegato);
			e.Count = r;
		}
		catch
		{
			// per lo meno NON faccio crollare la maschera.
			// Lo sparo alla prima pagina invece che all'ultima.
			e.Count = 0;
		}

	}

	private void LeggiDati(out string targa, out string nazionalita,
		out string tipoSegnalazione,
		out DateTime? ricercaInizioDal, out DateTime? ricercaInizioAl,
		out DateTime? ricercaFineDal, out DateTime? ricercaFineAl,
		out string IdUtenteRichiedente,
		out int? IdCoa,
		out DateTime? ricercaInseritoDal,
		out DateTime? ricercaInseritoAl,
		out string ricercaEmail,
		out int? idCoaPerTipoC,

		out string IdUtenteCollegato,
		out int? IdCoaDiAppartenenzaUtenteCollegato
	)
	{
		targa = ricerca_tbTarga.Text.Trim().ToUpper();
		if (targa.Length > 0)
		{
			if (!(targa.Contains("%") || targa.Contains("_")))
				targa += "%";
		}
		else
			targa = null;

        try
        {
            nazionalita = ricerca_ddlNazionalita.SelectedValue;
            if (nazionalita == "") nazionalita = null;
        }
        catch
        {
            nazionalita = "I";
        }
		tipoSegnalazione = ricerca_ddlTipoSegnalazione.SelectedValue;
		if (tipoSegnalazione == "")
		{
			// vorrebbe vedere tutto - restringo a cio` che puo vedere
			tipoSegnalazione = "";
			if (_consultazione_A1) tipoSegnalazione += "A1";
			if (_consultazione_A2) tipoSegnalazione += "A2";
			if (_consultazione_B) tipoSegnalazione += "B";
			if (_consultazione_C) tipoSegnalazione += "C";
		}



		if (_amministrazione_LTS == false)
		{
			IdUtenteCollegato = UserPkId;

			ITRSUtility.GetCoaDiAppartenenza();
			IdCoaDiAppartenenzaUtenteCollegato = ITRSUtility.GetCoaDiAppartenenza();
			// se non appartiene al COA lascio -1 cosi` non trova niente

			// un utente normale vede
			// A1/A2        le entry valide ora
			// B (Email)    le entry che ha immesso lui
			// C (indagini) le entry del suo COA
		}
		else
		{
			// L'amministratore puo` vedere tutto di tutti.
			IdUtenteCollegato = null;
			IdCoaDiAppartenenzaUtenteCollegato = null;
		}

		IdUtenteRichiedente = null;
		IdCoa = null;
		ricercaEmail = null;
		idCoaPerTipoC = null;

		switch (ricerca_ddlTipoSegnalazione.SelectedValue)
		{
		default:
		case "":
			break;

		case "A1":
		case "A2":
			break;

		case "B":
			{
				ricercaEmail = ricerca_txRicercaEmail.Text.Trim();

				// solo l'amministratore puo` vedere di altri utenti
				if (_amministrazione_LTS)
				{
					// qui leggo l'utente richiedente dalla ddlUtenteRichiedente.
					// basta assegnare ut.Chiave e si ottiene ut.IdUtenteRichiedente / ut.IdCoa
					ITRS_BL.BLLTS.UtenteRichiedente ut = new ITRS_BL.BLLTS.UtenteRichiedente();
					ut.Chiave = ricerca_ddlUtenteRichiedente.SelectedValue;
					IdUtenteRichiedente = ut.IdUtenteRichiedente;
					IdCoa = ut.IdCoa;
				}
				else
				{
					// notare che l'utente normale NON ammistrativo
					// specifica sempre IdUtenteCollegato
					// e dunque per il tipo B vede SOLO le sue entry di tipo B
				}

			}
			break;

		case "C":
			{
				// lettura dalla dropdown per sapere quale COA utilizzare per i tipo "C"
				// questo e` utilizzato solo dal profilo amministratore LTS
				if (_amministrazione_LTS)
				{
					if (ricerca_ddlRicercaCoa.SelectedValue == "")
						idCoaPerTipoC = null;
					else
						idCoaPerTipoC = int.Parse(ricerca_ddlRicercaCoa.SelectedValue);
				}
				else
				{
					// notare che l'utente NON amministrativo
					// specifica sempre il COA di compentenza 
					// e dunque vede solo le indagini di sua pertinenza.
				}


				// qui leggo l'utente richiedente dalla ddlUtenteRichiedente.
				// basta assegnare ut.Chiave e si ottiene ut.IdUtenteRichiedente / ut.IdCoa
				ITRS_BL.BLLTS.UtenteRichiedente ut = new ITRS_BL.BLLTS.UtenteRichiedente();
				ut.Chiave = ricerca_ddlUtenteRichiedente.SelectedValue;
				IdUtenteRichiedente = ut.IdUtenteRichiedente;
				IdCoa = ut.IdCoa;
			}
			break;
		}

		ricercaInizioDal = null;
		ricercaInizioAl = null;
		ricercaFineDal = null;
		ricercaFineAl = null;

		ricercaInseritoDal = null;
		if (ricerca_txRicercaInseritoDal.Text.Length > 0)
			ricercaInseritoDal = DateTime.Parse(ricerca_txRicercaInseritoDal.Text);

		ricercaInseritoAl = null;
		if (ricerca_txRicercaInseritoAl.Text.Length > 0)
			ricercaInseritoAl = DateTime.Parse(ricerca_txRicercaInseritoAl.Text);

	}
	protected void odsLTS_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
	{
		string targa;
		string nazionalita;
		string tipoSegnalazione;

		DateTime? ricercaInizioDal;
		DateTime? ricercaInizioAl;
		DateTime? ricercaFineDal;
		DateTime? ricercaFineAl;
		string IdUtenteRichiedente = null;
		int? IdCoa = null;
		DateTime? ricercaInseritoDal;
		DateTime? ricercaInseritoAl;
		string ricercaEmail;
		int? idCoaPerTipoC;


		string IdUtenteCollegato;
		int? IdCoaDiCompetenzaUtenteCollegato;


		LeggiDati(out targa, out nazionalita,
			out tipoSegnalazione,
			out ricercaInizioDal, out ricercaInizioAl, out ricercaFineDal, out ricercaFineAl,
			out IdUtenteRichiedente, out IdCoa,
			out ricercaInseritoDal, out ricercaInseritoAl, out ricercaEmail, out idCoaPerTipoC,
			out IdUtenteCollegato,
			out IdCoaDiCompetenzaUtenteCollegato);

		e.InputParameters["targa"] = targa;
		e.InputParameters["nazionalita"] = nazionalita;
		e.InputParameters["tipoLTS"] = tipoSegnalazione;
		e.InputParameters["ricercaInizioDal"] = ricercaInizioDal;
		e.InputParameters["ricercaInizioAl"] = ricercaInizioAl;
		e.InputParameters["ricercaFineDal"] = ricercaFineDal;
		e.InputParameters["ricercaFineAl"] = ricercaFineAl;
		e.InputParameters["IdUtenteRichiedente"] = IdUtenteRichiedente;
		e.InputParameters["IdCoa"] = IdCoa;
		e.InputParameters["ricercaInseritoDal"] = ricercaInseritoDal;
		e.InputParameters["ricercaInseritoAl"] = ricercaInseritoAl;
		e.InputParameters["ricercaEmail"] = ricercaEmail;
		e.InputParameters["idCoaPerTipoC"] = idCoaPerTipoC;
		e.InputParameters["IdUtenteCollegato"] = IdUtenteCollegato;
		e.InputParameters["IdCoaDiCompetenzaUtenteCollegato"] = IdCoaDiCompetenzaUtenteCollegato;
	}

	/*
	 * Regole per la modtifica/inserimento
	 * 
	 * A1/A2 hanno nel DB EnumTipoDest='COA',   AddrDest=<stringa vuota> e` implicito il COA di competenza
	 * B     hanno nel DB EnumTipoDest='EMAIL', AddrDest=l'indirizzo di e-mail
	 * C     hanno nel DB EnumTipoDest='COA',   AddrDest=idCoa in formato stringa	  
	 * 
	 * Si possono inserire/cancellare/modificare record A1/A2
	 * la modifica comporta solo Motivo/Note
	 * 
	 * Si possono inserire/cancellare/modificare record B (e-mail)
	 * la modifica comporta solo Motivo/Note/AddrDest (e-mail)
	 * 
	 * Si possono inserire/cancellare/modificare record C (interventi)
	 * la modifica comporta solo Motivo/Note/AddrDest (idCoa)
	 */


	protected void gvLTS_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		// resetto la selezione corrente se clicco una seconda 
		// volta nella stessa riga della grid view
		if (e.NewSelectedIndex == gvLTS.SelectedIndex)
			e.NewSelectedIndex = -1;
	}

	void StopEditing()
	{
		this.divEditing.Visible = false;
		this._id.NuovoLTS = false;
		this._id.Sel_Targa = null;
		this.gvLTS.SelectedIndex = -1;
	}

	protected void gvLTS_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (gvLTS.SelectedIndex < 0)
		{
			StopEditing();
			return;
		}

		try
		{
			this._id.NuovoLTS = false;
			this._id.Sel_Targa = (string)gvLTS.SelectedDataKey["Targa"];
			this._id.Sel_Nazionalita = (string)gvLTS.SelectedDataKey["Nazionalita"];
			this._id.Sel_IdLts = (long)gvLTS.SelectedDataKey["IdLTS"];

			ITRS_BL.BLLTS bl = new ITRS_BL.BLLTS();
			ITRS_BL.BLLTS.LTSRecord rec = bl.GetLTSFromKey(_id.Sel_Targa, _id.Sel_Nazionalita, _id.Sel_IdLts);

			if (rec.EnumTipoLTS == "A1" && _gestione_A1 == false)
			{
				StopEditing();
				return;
			}
			if (rec.EnumTipoLTS == "A2" && _gestione_A2 == false)
			{
				StopEditing();
				return;
			}
			if (rec.EnumTipoLTS == "B" && _gestione_B == false)
			{
				StopEditing();
				return;
			}
			if (rec.EnumTipoLTS == "C" && _gestione_C == false)
			{
				StopEditing();
				return;
			}

			FillFromLTS(rec);
		}
		catch
		{
			lblError.Text = "Errore caricando la targa selezionata dalla LTS";
		}
	}

	void LTS_GestioneLTS_PreRender(object sender, EventArgs e)
	{
		if (_id.RicercaPremuta == false)
		{
			this.gvLTS.Visible = false;
			this.divParametri.Visible = false;
		}
		ManageControls();


		riepilogoDati_Targa.Text = _id.Riepologo_Targa;
		riepilogoDati_Nazionalita.Text = _id.Riepilogo_Nazionalita;
		riepilogoDati_Dal.Text = _id.Riepologo_Dal;
		riepilogoDati_Al.Text = _id.Riepologo_Al;
		riepilogoDati_TipoLTS.Text = _id.Riepologo_TipoLTS;
		riepilogoDati_Richiedente.Text = _id.Riepologo_Richiedente;
		riepilogoDati_Email.Text = _id.Riepologo_Email;
		riepilogoDati_COA.Text = _id.Riepologo_COA;

	}

	private void FillFromLTS(ITRS_BL.BLLTS.LTSRecord rec)
	{
		edit_txTarga.Text = rec.Targa;
		try
		{
			edit_ddrNazionalita.SelectedValue = rec.Nazionalita;
		}
		catch
		{
		}

		edit_txTipoLTS.Text = rec.EnumTipoLTS;
		edit_ddlTipoLTS.SelectedValue = rec.EnumTipoLTS;
		edit_txMotivo.Text = rec.Motivo;
		edit_txNote.Text = rec.Note;

		if (edit_ddlTipoLTS.SelectedValue == "B")
		{
			edit_txDestinazione.Text = rec.AddrDest;
		}
		else if (edit_ddlTipoLTS.SelectedValue == "C")
		{
			edit_ddlCoa.SelectedValue = rec.AddrDest;
			edit_txDestinazione.Text = BLCacher.GetDescrizioneCOA(int.Parse(rec.AddrDest));
		}
		else
		{
			edit_txDestinazione.Text = "";
		}


		edit_txValidoDal.Text = rec.DataOraInizioValidita.ToString();
		edit_txValidoAl.Text = rec.DataOraFineValidita.ToString();

		ManageControls();
	}

	protected string OperazioneEditingInCorso()
	{
		if (_id.Sel_Targa != null)
		{
			return "Modifica targa segnalata";
		}
		else if (_id.NuovoLTS == true)
		{
			return "Registrazione nuova targa segnalata";
		}
		else
		{
			return "";
		}
	}

	private void ManageControls()
	{
		switch (ricerca_ddlTipoSegnalazione.SelectedValue)
		{
		case "":
			filtroEmail_Visible = false;
			filtroIdCOAperC_Visible = false;
			filtroRichiedente_Visible = false;

			//riepilogoEmail_Visible = false;
			//riepilogoCOA_Visible = false;
			//riepilogoRichiedente_Visible = false;

			riepilogoTable.Rows.Remove(riepilogoEmail);
			riepilogoTable.Rows.Remove(riepilogoCOA);
			riepilogoTable.Rows.Remove(riepilogoRichiedente);


			break;

		case "A1":
		case "A2":
			filtroEmail_Visible = false;
			filtroIdCOAperC_Visible = false;
			filtroRichiedente_Visible = false;

			riepilogoTable.Rows.Remove(riepilogoEmail);
			riepilogoTable.Rows.Remove(riepilogoCOA);
			riepilogoTable.Rows.Remove(riepilogoRichiedente);

			break;

		case "B":
			// Email
			filtroEmail_Visible = true;
			filtroIdCOAperC_Visible = false;
			filtroRichiedente_Visible = _amministrazione_LTS;

			riepilogoTable.Rows.Remove(riepilogoCOA);
			// solo l'amministratore puo` vedere le richieste B fatti da altri
			if (_amministrazione_LTS == false)
				riepilogoTable.Rows.Remove(riepilogoRichiedente);

			break;

		case "C":
			filtroEmail_Visible = false;
			filtroIdCOAperC_Visible = _amministrazione_LTS;
			filtroRichiedente_Visible = false;

			riepilogoTable.Rows.Remove(riepilogoEmail);
			if (_amministrazione_LTS == false)
				riepilogoTable.Rows.Remove(riepilogoCOA);
			riepilogoTable.Rows.Remove(riepilogoRichiedente);

			break;
		}


		if (_id.Sel_Targa != null)
		{
			this.divEditing.Visible = true;
			this.btnNuovoRecordLts.Visible = false;
			this.btnDelete.Visible = true;
		}
		else if (_id.NuovoLTS == true)
		{
			this.divEditing.Visible = true;
			this.btnNuovoRecordLts.Visible = false;
			this.btnDelete.Visible = false;
		}
		else
		{
			this.divEditing.Visible = false;
			this.btnNuovoRecordLts.Visible = true;
			this.btnDelete.Visible = false;

			// esco dalla funzione!
			return;
		}

		if (_id.Sel_Targa != null)
		{
			// updateMode
			edit_txTarga.ReadOnly = true;
			edit_ddrNazionalita.ReadOnly = true;
			edit_txTipoLTS.Visible = true;
			edit_ddlTipoLTS.Visible = false;
			edit_txDestinazione.ReadOnly = true;
			edit_txValidoDal.ReadOnly = true;

			edit_txValidoAl.ReadOnly = false;  // si puo` modificare la data di fine validita`
			edit_txMotivo.ReadOnly = false; // il motivo e le note
			edit_txNote.ReadOnly = false;

		}
		else if (_id.NuovoLTS)
		{
			// insert mode
			edit_txTarga.ReadOnly = false;
			edit_ddrNazionalita.ReadOnly = false;

			edit_txTipoLTS.Visible = false;
			edit_ddlTipoLTS.Visible = true;

			edit_txMotivo.ReadOnly = false;
			edit_txNote.ReadOnly = false;
			edit_txDestinazione.ReadOnly = false;

			// l'inizio validita` del record e` sempre read-only
			edit_txValidoDal.ReadOnly = true;

			// e` sempre possibile modificare la data di fine validita`
			edit_txValidoAl.ReadOnly = false;
		}

		switch (edit_ddlTipoLTS.SelectedValue)
		{
		case "A1":
		case "A2":
			{
				edit_trDestinazione.Visible = false;
				//edit_lblDestinazione.InnerText = "Destinazione:";
				//edit_txDestinazione.ReadOnly = true;
				//edit_txDestinazione.Text = "";
			}
			break;

		case "B":
			{
				edit_trDestinazione.Visible = true;

				edit_lblDestinazione.InnerText = "Indirizzo e-mail:";
				edit_ddlCoa.Visible = false;
				edit_txDestinazione.Visible = true;
				edit_txDestinazione.ReadOnly = false;
			}
			break;

		case "C":
			{
				if (_amministrazione_LTS)
				{
					edit_trDestinazione.Visible = true;
					edit_lblDestinazione.InnerText = "COA destinatario:";

					if (_id.NuovoLTS)
					{
						edit_ddlCoa.Visible = true;
						edit_txDestinazione.Visible = false;
					}
					else
					{
						edit_ddlCoa.Visible = false;
						edit_txDestinazione.Visible = true;
					}
				}
				else
				{
					// si assume SOLO il COA di appartenenza
					// --> non faccio vedere la riga
					edit_trDestinazione.Visible = false;
				}
			}
			break;
		}

	}


	protected void btnNuovoRecordLts_Click(object sender, EventArgs e)
	{
		_id.NuovoLTS = true;
		_id.Sel_Targa = null;

		ITRS_BL.BLLTS.LTSRecord rec = CreateEmptyLTS();
		FillFromLTS(rec);
	}

	private ITRS_BL.BLLTS.LTSRecord CreateEmptyLTS()
	{
		ITRS_BL.BLLTS.LTSRecord rec = new ITRS_BL.BLLTS.LTSRecord();
		rec.Targa = "";
		rec.Nazionalita = "";
		rec.Motivo = "";
		rec.IdUtenteRichiedente = UserPkId;
		rec.Note = "";
		rec.AddrDest = "";

		rec.DataOraInserimento = DateTime.Now;
		rec.DataOraInizioValidita = DateTime.Now;
		rec.DataOraFineValidita = rec.DataOraInizioValidita.AddDays(ITRS_BL.ReadAppSettings.ToInt32("LTS.DataOraFineValidita.Delta", 2));

		if (_gestione_A1) rec.EnumTipoLTS = "A1";
		else if (_gestione_A2) rec.EnumTipoLTS = "A2";
		else if (_gestione_B) rec.EnumTipoLTS = "B";
		else if (_gestione_C) rec.EnumTipoLTS = "C";

		switch (rec.EnumTipoLTS)
		{
		case "A1":
		case "A2":
			rec.EnumTipoDest = "COA";
			break;
		case "B":
			rec.EnumTipoDest = "EMAIL";
			break;
		case "C":
			rec.EnumTipoDest = "COA";
			if (ITRSUtility.GetCoaDiAppartenenza() >= 0)
				rec.AddrDest = ITRSUtility.GetCoaDiAppartenenza().ToString();
			break;
		}
		rec.EnumLivelloPriorita = "MAX";

		return rec;
	}

	protected void btnSave_Click(object sender, EventArgs e)
	{
		if (_id.NuovoLTS)
		{
			ITRS_BL.BLLTS.LTSRecord rec = CreateEmptyLTS();

			rec.EnumTipoLTS = edit_ddlTipoLTS.SelectedValue;
			rec.EnumLivelloPriorita = "MAX";

			if (true)
			{
				string targa = this.edit_txTarga.Text.Trim().ToUpper();
				string naz = edit_ddrNazionalita.SelectedValue;
				if (naz == "")
					naz = "I";

				string msg;
				msg = ITRSUtility.ControllaTarga(ref targa, true);
				if (msg != null)
				{
					lblError.Text = msg;
					return;
				}
				msg = ITRSUtility.ControllaNazionalita(ref naz, true);
				if (msg != null)
				{
					lblError.Text = msg;
					return;
				}

				rec.Targa = targa;
				rec.Nazionalita = naz;
			}


			switch (rec.EnumTipoLTS)
			{
			case "A1":
			case "A2":
				rec.EnumTipoDest = "COA";
				rec.AddrDest = "";
				break;
			case "B":
				rec.EnumTipoDest = "EMAIL";

				if (edit_txDestinazione.Text.Contains("@") == false)
				{
					lblError.Text = "Indirizzo e-mail non corretto";
					return;
				}
				rec.AddrDest = edit_txDestinazione.Text.Trim();
				break;
			case "C":
				rec.EnumTipoDest = "COA";

				if (_amministrazione_LTS)
				{
					rec.AddrDest = edit_ddlCoa.SelectedValue;
				}
				else
				{
					if (ITRSUtility.GetCoaDiAppartenenza() < 0)
					{
						lblError.Text = "L'operatore deve essere assegnato ad un COA";
						return;
					}

					rec.AddrDest = ITRSUtility.GetCoaDiAppartenenza().ToString();
				}
				break;
			}

			rec.Motivo = edit_txMotivo.Text.Trim();
			rec.Note = edit_txNote.Text.Trim();

			// Sono valorizzate read-only

			//rec.DataOraInserimento = DateTime.Now;
			//if (!DateTime.TryParse(txValidoDal.Text, out ddd))
			//{
			//    lblError.Text = "Data inizio validita` non corretta";
			//    return;
			//}
			//else
			//    rec.DataOraInizioValidita = ddd;

			DateTime ddd;
			if (!DateTime.TryParse(edit_txValidoAl.Text, out ddd))
			{
				lblError.Text = "Data fine validita` non corretta";
				return;
			}
			else
				rec.DataOraFineValidita = ddd;

			if (rec.DataOraInizioValidita > rec.DataOraFineValidita)
			{
				lblError.Text = "La data di fine validita` deve essere maggiore della data di inizio validita`";
				return;
			}


			try
			{
				if (rec.EnumTipoLTS == "A1" && _gestione_A1 == false)
				{
					lblError.Text = "Non si hanno i privilegi per inserire una targa di tipo A1";
					return;
				}
				if (rec.EnumTipoLTS == "A2" && _gestione_A2 == false)
				{
					lblError.Text = "Non si hanno i privilegi per inserire una targa di tipo A2";
					return;
				}
				if (rec.EnumTipoLTS == "B" && _gestione_B == false)
				{
					lblError.Text = "Non si hanno i privilegi per inserire una targa di tipo B";
					return;
				}
				if (rec.EnumTipoLTS == "C" && _gestione_C == false)
				{
					lblError.Text = "Non si hanno i privilegi per inserire una targa di tipo C";
					return;
				}

				ITRS_BL.BLLTS bl = new ITRS_BL.BLLTS();
				bool ok = bl.InsertLTS(rec);
				if (!ok)
				{
					// chiave duplicata.
					lblError.Text = "Esiste gia` una targa della categoria selezionata nella LTS!";
					return;
				}

				switch (rec.EnumTipoLTS)
				{
				case "A1":
				case "A2":
					PageBase.AddUserActivity(TipoAttivita.LTS,
						"Nuova targa in LTS Targa:{0} Nazionalita:{1} Tipo:{2} Motivo:{3} Note:{4} DataInizioValidita`:{5} DataFineValidita`:{6}",
						rec.Targa, rec.Nazionalita, rec.EnumTipoLTS, rec.Motivo, rec.Note,
						rec.DataOraInizioValidita, rec.DataOraFineValidita);
					break;
				case "B":
					PageBase.AddUserActivity(TipoAttivita.LTS,
						"Nuova targa in LTS Targa:{0} Nazionalita:{1} Tipo:{2} Motivo:{3} Note:{4} Dest:{5} DataInizioValidita`:{6} DataFineValidita`:{7}",
						rec.Targa, rec.Nazionalita, rec.EnumTipoLTS, rec.Motivo, rec.Note,
						rec.AddrDest,
						rec.DataOraInizioValidita, rec.DataOraFineValidita);
					break;
				case "C":
					PageBase.AddUserActivity(TipoAttivita.LTS,
						"Nuova targa in LTS Targa:{0} Nazionalita:{1} Tipo:{2} Motivo:{3} Note:{4} Dest:{5} DataInizioValidita`:{6} DataFineValidita`:{7}",
						rec.Targa, rec.Nazionalita, rec.EnumTipoLTS, rec.Motivo, rec.Note,
						edit_ddlCoa.SelectedItem.Text,
						rec.DataOraInizioValidita, rec.DataOraFineValidita);
					break;
				}
			}
			catch
			{
				lblError.Text = "Errore inserendo la nuova targa nella LTS";
				return;
			}


		}
		else if (_id.Sel_Targa != null)
		{
			ITRS_BL.BLLTS bl = new ITRS_BL.BLLTS();
			ITRS_BL.BLLTS.LTSRecord rec = bl.GetLTSFromKey(_id.Sel_Targa, _id.Sel_Nazionalita, _id.Sel_IdLts);

			rec.Motivo = edit_txMotivo.Text;
			rec.Note = edit_txNote.Text;

			Debug.Assert(edit_txValidoAl.ReadOnly == false);
			DateTime ddd;
			if (!DateTime.TryParse(edit_txValidoAl.Text, out ddd))
			{
				lblError.Text = "Data fine validita` non corretta";
				return;
			}
			else
				rec.DataOraFineValidita = ddd;

			if (rec.DataOraInizioValidita > rec.DataOraFineValidita)
			{
				lblError.Text = "La data di fine validita` deve essere maggiore della data di inizio validita`";
				return;
			}

			switch (rec.EnumTipoLTS)
			{
			case "A1":
			case "A2":
				break;

			case "B":
				if (edit_txDestinazione.Text.Contains("@") == false)
				{
					lblError.Text = "Indirizzo e-mail non corretto";
					return;
				}
				rec.AddrDest = edit_txDestinazione.Text;
				break;

			case "C":
				// Qui non modifico la destinazione perche` cambierebbe da un Coa ad un altro
				//rec.EnumTipoDest = edit_ddlCoa.SelectedValue;
				break;
			}

			try
			{
				if (rec.EnumTipoLTS == "A1" && _gestione_A1 == false)
				{
					lblError.Text = "Non si hanno i privilegi per modificare una targa di tipo A1";
					return;
				}
				if (rec.EnumTipoLTS == "A2" && _gestione_A2 == false)
				{
					lblError.Text = "Non si hanno i privilegi per modificare una targa di tipo A2";
					return;
				}
				if (rec.EnumTipoLTS == "B" && _gestione_B == false)
				{
					lblError.Text = "Non si hanno i privilegi per modificare una targa di tipo B";
					return;
				}
				if (rec.EnumTipoLTS == "C" && _gestione_C == false)
				{
					lblError.Text = "Non si hanno i privilegi per modificare una targa di tipo C";
					return;
				}

				bl.UpdateLTS(rec);

				switch (rec.EnumTipoLTS)
				{
				case "A1":
				case "A2":
					PageBase.AddUserActivity(TipoAttivita.LTS,
						"Modifica LTS Targa:{0} Nazionalita:{1} Tipo:{2} Motivo:{3} Note:{4} DataInizioValidita`:{5} DataFineValidita`:{6}",
						rec.Targa, rec.Nazionalita, rec.EnumTipoLTS, rec.Motivo, rec.Note,
						rec.DataOraInizioValidita, rec.DataOraFineValidita);
					break;
				case "B":
					PageBase.AddUserActivity(TipoAttivita.LTS,
						"Modifica LTS Targa:{0} Nazionalita:{1} Tipo:{2} Motivo:{3} Note:{4} Dest:{5} DataInizioValidita`:{6} DataFineValidita`:{7}",
						rec.Targa, rec.Nazionalita, rec.EnumTipoLTS, rec.Motivo, rec.Note,
						rec.AddrDest,
						rec.DataOraInizioValidita, rec.DataOraFineValidita);
					break;
				case "C":
					PageBase.AddUserActivity(TipoAttivita.LTS,
						"Modifica LTS Targa:{0} Nazionalita:{1} Tipo:{2} Motivo:{3} Note:{4} Dest:{5} DataInizioValidita`:{6} DataFineValidita`:{7}",
						rec.Targa, rec.Nazionalita, rec.EnumTipoLTS, rec.Motivo, rec.Note,
						edit_ddlCoa.SelectedItem.Text,
						rec.DataOraInizioValidita, rec.DataOraFineValidita);
					break;
				}
			}
			catch
			{
				lblError.Text = "Errore modificando i dati nella LTS";
			}


		}
		else
			Debug.Assert(false);

		StopEditing();
	}
	protected void btnCancel_Click(object sender, EventArgs e)
	{
		StopEditing();
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		try
		{
			ITRS_BL.BLLTS bl = new ITRS_BL.BLLTS();
			ITRS_BL.BLLTS.LTSRecord rec = bl.GetLTSFromKey(_id.Sel_Targa, _id.Sel_Nazionalita, _id.Sel_IdLts);


			if (rec.EnumTipoLTS == "A1" && _gestione_A1 == false)
			{
				lblError.Text = "Non si hanno i privilegi per cancellare una targa di tipo A1";
				return;
			}
			if (rec.EnumTipoLTS == "A2" && _gestione_A2 == false)
			{
				lblError.Text = "Non si hanno i privilegi per cancellare una targa di tipo A2";
				return;
			}
			if (rec.EnumTipoLTS == "B" && _gestione_B == false)
			{
				lblError.Text = "Non si hanno i privilegi per cancellare una targa di tipo B";
				return;
			}
			if (rec.EnumTipoLTS == "C" && _gestione_C == false)
			{
				lblError.Text = "Non si hanno i privilegi per cancellare una targa di tipo C";
				return;
			}

			bl.DeleteLTS(rec);

			StopEditing();

			PageBase.AddUserActivity(TipoAttivita.LTS,
				"Cancellazione da LTS Targa:{0} Nazionalita:{1} Tipo:{2}", rec.Targa, rec.Nazionalita, rec.EnumTipoLTS);
		}
		catch
		{
			lblError.Text = "Impossibile cancellare la targa dalla LTS";
		}
	}
	protected void custDal_ServerValidate(object source, ServerValidateEventArgs args)
	{
		CustomValidator cv = (CustomValidator)source;

		TextBox tb = (TextBox)cv.Parent.FindControl(cv.ControlToValidate);
		bool b = false;

		DateTime ts = DateTime.Now;

		if (b == false)
		{
			try
			{
				ts = DateTime.ParseExact(tb.Text, "d/M/yyyy H:m:s", null);
				b = true;
			}
			catch
			{
			}
		}

		if (b == false)
		{
			try
			{
				ts = DateTime.ParseExact(tb.Text, "d/M/yyyy", null);
				args.IsValid = true;
				b = true;
			}
			catch
			{
			}
		}

		args.IsValid = b;
		if (b == false)
			tb.Text = "";
		else
			tb.Text = ts.ToString();
	}
}
