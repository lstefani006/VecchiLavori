using System;
using System.Data;
using System.IO;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

using System.Runtime.Serialization.Formatters.Binary;

using ITRS_BL;
using ZipLib = ICSharpCode.SharpZipLib;

public partial class LTS_DownloadLTSTipoC : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			string action = Request.QueryString["Action"];
			if (string.IsNullOrEmpty(action))
				return;

			done.Value = action;

			string s = @"
			window.setTimeout('pluto()', 2000);

			function pluto()
			{
				document.downloadLTS.btnDownload.click();
			}
			";
			ClientScript.RegisterStartupScript(GetType(), "ddd", s, true);
		}

	}

	protected void btnDownload_Click(object sender, EventArgs e)
	{
		string action = done.Value;

		if (string.IsNullOrEmpty(action))
			return;

		done.Value = "";

		BinaryFormatter bf = new BinaryFormatter();
		ExportLTSData dt = bf.Deserialize(new MemoryStream(Convert.FromBase64String(action))) as ExportLTSData;

		BLLTS bl = new BLLTS();

		string content = bl.GeneraFileLTS_C_ForExport(dt.IdCoa, DateTime.Now);

		PageBase.AddUserActivity(TipoAttivita.LTS, "Export LTS C");

		string fileName = string.Format("LTS_C_{0:yyyy}{0:MM}{0:dd}_{0:HH}{0:mm}{0:ss}.txt", DateTime.Now);

		byte[] buff = System.Text.Encoding.UTF8.GetBytes(content);

		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "text/plain";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", fileName));
		Response.AddHeader("Content-Length", buff.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(buff);
		Response.End();
	}
}
