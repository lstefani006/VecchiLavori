//#define ProvaMenu

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Xml;

public partial class MenuVert : System.Web.UI.UserControl
{
	public MenuVert()
	{
		_tree = new MenuItem();
		_userRoles = new Dictionary<string, bool>();
	}

	Dictionary<string, bool> _userRoles;

	protected void Page_Load(object sender, EventArgs e)
	{
#if !ProvaMenu
		string[] roles = Roles.GetRolesForUser();
		foreach (string r in roles)
			_userRoles.Add(r, true);
#endif
	}

	public override void RenderControl(HtmlTextWriter w)
	{
		BuildTree();

		base.RenderControl(w);

		if (UseTable == false)
		{
			w.RenderBeginTag(HtmlTextWriterTag.Ul);
			RenderNodes(w, _tree, true);
			w.RenderEndTag();
		}
		else
		{
			RenderControl_Table(w);
		}
	}

	private void RenderNodes(HtmlTextWriter w, MenuItem node, bool skipHead)
	{
		if (skipHead == false)
		{
			if (node.Url != null)
			{
				string url = node.Url;
				if (node.Url.StartsWith("~"))
					url = "/ITRSweb" + node.Url.Substring(1);
				w.AddAttribute("href", url);
				w.AddAttribute("title", node.Description);
				w.RenderBeginTag(HtmlTextWriterTag.A);
				w.Write(node.Text);
				w.RenderEndTag();
			}
			else if (node.Text != null)
			{
				w.Write(node.Text);
			}

		}

		if (node.DownNode.Count > 0)
		{
			if (skipHead == false)
				w.RenderBeginTag(HtmlTextWriterTag.Ul);

			foreach (MenuItem n in node.DownNode)
			{
				w.RenderBeginTag(HtmlTextWriterTag.Li);

				RenderNodes(w, n, false);

				w.RenderEndTag();
			}
			if (skipHead == false)
				w.RenderEndTag();
		}
	}


	public void RenderControl_Table(HtmlTextWriter w)
	{
		w.RenderBeginTag(HtmlTextWriterTag.Table);
		RenderNodes_Table(w, _tree, 2, 0, true);
		w.RenderEndTag();
	}

	private void RenderNodes_Table(HtmlTextWriter w, MenuItem node, int maxLevel, int currentLevel, bool skipHead)
	{
		if (skipHead == false)
		{
			w.RenderBeginTag(HtmlTextWriterTag.Tr);
			{
				for (int i = 0; i < currentLevel; ++i)
				{
					w.AddAttribute(HtmlTextWriterAttribute.Width, "8px");
					w.RenderBeginTag(HtmlTextWriterTag.Td);
					w.WriteEncodedText(" ");
					w.RenderEndTag();
				}

				if (currentLevel == 0)
					w.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");

				{
					if (node.Url != null)
					{
						w.RenderBeginTag(HtmlTextWriterTag.Td);
						string url = node.Url;
						if (node.Url.StartsWith("~"))
							url = "/ITRSweb" + node.Url.Substring(1);
						w.AddAttribute("href", url);
						w.AddAttribute("title", node.Description);
						w.AddAttribute(HtmlTextWriterAttribute.Class, "MenuVertClass");
						w.RenderBeginTag(HtmlTextWriterTag.A);
						w.Write(node.Text);
						w.RenderEndTag();
					}
					else if (node.Text != null)
					{
						w.AddStyleAttribute(HtmlTextWriterStyle.FontSize, "12px");
						w.RenderBeginTag(HtmlTextWriterTag.Td);
						w.Write(node.Text);
					}
				}
				w.RenderEndTag();
			}
			w.RenderEndTag();
		}

		foreach (MenuItem n in node.DownNode)
		{
			if (skipHead == false)
				RenderNodes_Table(w, n, maxLevel, currentLevel + 1, false);
			else
				RenderNodes_Table(w, n, maxLevel, currentLevel, false);
		}

	}


	MenuItem _tree;
	bool UseTable = true;

	[Serializable]
	class MenuItem
	{
		public MenuItem()
		{
			_downNode = new List<MenuItem>();
		}

		public MenuItem(string t, string u, string descr, MenuItem parent)
		{
			_downNode = new List<MenuItem>();
			_text = t;
			_url = u;
			_descr = descr;
			if (parent != null)
				parent.DownNode.Add(this);
		}

		public MenuItem(string t, MenuItem parent)
		{
			_downNode = new List<MenuItem>();
			_text = t;
			_url = null;
			if (parent != null)
				parent.DownNode.Add(this);
		}


		private string _text;
		private string _url;
		private List<MenuItem> _downNode;
		private string _descr;

		public string Text
		{
			get { return _text; }
			set { _text = value; }
		}
		public string Url
		{
			get { return _url; }
			set { _url = value; }
		}
		public List<MenuItem> DownNode
		{
			get { return _downNode; }
			set { _downNode = value; }
		}
		public string Description
		{
			get { return _descr; }
			set { _descr = value; }
		}
	}

	void BuildTree()
	{
#if ProvaMenu
		string path = Server.MapPath("/ProvaMenu");
#else
		string path = Server.MapPath("/ITRSweb");
#endif
		XmlDocument doc = new XmlDocument();
		doc.Load(path + @"\web.sitemap");

		XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
		nsmgr.AddNamespace("n", "http://schemas.microsoft.com/AspNet/SiteMap-File-1.0");
		XmlElement el = doc.DocumentElement;

		_tree = BuildMenuLevel(null, nsmgr, el);
	}

	private MenuItem BuildMenuLevel(MenuItem parent, XmlNamespaceManager nsmgr, XmlNode el)
	{
		XmlNodeList nl = el.SelectNodes("./n:siteMapNode", nsmgr);
		foreach (XmlNode n in nl)
		{
			string title = n.Attributes["title"].InnerText;

			string description = null;
			if (n.Attributes["description"] != null)
				description = n.Attributes["description"].InnerText;

			string url = null;
			if (n.Attributes["url"] != null)
				url = n.Attributes["url"].InnerText;

			string roles = "";
			if (n.Attributes["roles"] != null)
				roles = n.Attributes["roles"].InnerText;

			if (CheckRoles(roles))
			{
				MenuItem mi = new MenuItem(title, url, description, parent);
				BuildMenuLevel(mi, nsmgr, n);

				if (parent == null)
					return mi;
			}
		}
		return null;
	}

	bool CheckRoles(string roles)
	{
		if (_userRoles == null || _userRoles.Count == 0)
			return true;

		if (roles == "")
			return true;

		string[] rs = roles.Split(',');

		foreach (string r in rs)
		{
			string rt = r.Trim();

			if (rt == "*")
				return true;

			if (_userRoles.ContainsKey(rt))
				return true;

		}

		return false;
	}
}
