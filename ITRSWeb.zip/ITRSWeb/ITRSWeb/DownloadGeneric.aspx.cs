using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using ITRS_BL;


public partial class DownloadGeneric : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			string action = Request.QueryString["Action"];
			if (string.IsNullOrEmpty(action))
				return;

			done.Value = action;

			string s = "window.setTimeout('document.downloadGeneric.btnDownload.click()', 1000);";
			ClientScript.RegisterStartupScript(GetType(), "downloadGenericTag", s, true);
		}
	}

	protected void btnDownload_Click(object sender, EventArgs e)
	{
		string action = done.Value;

		if (string.IsNullOrEmpty(action))
			return;

		done.Value = "";

		BinaryFormatter bf = new BinaryFormatter();
		object dt = bf.Deserialize(new MemoryStream(Convert.FromBase64String(action)));

		if (dt is ExportLTBData)
		{
			ExportLTB(dt as ExportLTBData);
		}
		else if (dt is ExportSystemActivityData)
		{
			ExportSystemActivity(dt as ExportSystemActivityData);
		}
		else if (dt is ExportTempiVelocitaPerDirezioneData)
		{
			ExportTempiVelocitaPerDirezione(dt as ExportTempiVelocitaPerDirezioneData);
		}
		else if (dt is ExportTempiVelocitaSuTrattaData)
		{
			ExportTempiVelocitaSuTratta(dt as ExportTempiVelocitaSuTrattaData);
		}
		else if (dt is ExportTempiSostaData)
		{
			ExportTempiSostaTratta(dt as ExportTempiSostaData);
		}
		else if (dt is ExportVolumeTrafficiPerDirezioneData)
		{
			ExportVolumeTrafficoPerDirezione(dt as ExportVolumeTrafficiPerDirezioneData);
		}
		else if (dt is ExportVolumeTrafficiSuTrattaData)
		{
			ExportVolumeTrafficoSuTratta(dt as ExportVolumeTrafficiSuTrattaData);
		}
		else if (dt is ExportIndagineDettaglioTransito)
		{
			ExportIndagineDettaglioTransito(dt as ExportIndagineDettaglioTransito);
		}
		else if (dt is ExportSorveglianzaDettaglioTransito)
		{
			ExportSorveglianzaDettaglioTransito(dt as ExportSorveglianzaDettaglioTransito);
		}
	}

	void ExportLTB(ExportLTBData dt)
	{
		ITRS_BL.BLTargheBianche bl = new ITRS_BL.BLTargheBianche();

		byte[] content = bl.ExportTargheBianche();

		PageBase.AddUserActivity(TipoAttivita.LTS, "Export LTB");


		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "text/xml";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", dt.fileName));
		Response.AddHeader("Content-Length", content.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(content);
		Response.End();
	}

	void ExportSystemActivity(ExportSystemActivityData dt)
	{
		ITRS_BL.BLLog bl = new ITRS_BL.BLLog();

		byte[] content = bl.ExportSystemActivities(dt.From, dt.To, dt.Utente, dt.Tipo, dt.sort);

		PageBase.AddUserActivity(TipoAttivita.AmministrazioneUtenti, "Export attivita' di sistema");


		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "application/x-msexcel";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", dt.fileName));
		Response.AddHeader("Content-Length", content.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(content);
		Response.End();
	}

	void ExportTempiVelocitaPerDirezione(ExportTempiVelocitaPerDirezioneData dt)
	{
		ITRS_BL.BLStatistiche bl = new ITRS_BL.BLStatistiche();

		byte[] content = bl.ExportTempiVelocitaPerDirezione(dt.Data, dt.Direzione, dt.sort);

		PageBase.AddUserActivity(TipoAttivita.ReportTVPD, "Export report tempi medi e velocita' medie per direzione");

		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "application/x-msexcel";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", dt.fileName));
		Response.AddHeader("Content-Length", content.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(content);
		Response.End();
	}

	void ExportTempiVelocitaSuTratta(ExportTempiVelocitaSuTrattaData dt)
	{
		ITRS_BL.BLStatistiche bl = new ITRS_BL.BLStatistiche();

		byte[] content = bl.ExportTempiVelocitaSuTratta(dt.Data, dt.IdTratta, dt.sort);

		PageBase.AddUserActivity(TipoAttivita.ReportVTST, "Export report tempi medi e velocita' medie su tratta");

		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "application/x-msexcel";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", dt.fileName));
		Response.AddHeader("Content-Length", content.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(content);
		Response.End();
	}

	void ExportTempiSostaTratta(ExportTempiSostaData dt)
	{
		ITRS_BL.BLStatistiche bl = new ITRS_BL.BLStatistiche();

		byte[] content = bl.ExportTempiSostaC2P(dt.Data, dt.IdC2P, dt.sort);

		PageBase.AddUserActivity(TipoAttivita.ReportTSC2P, "Export report tempi sosta medi su area di servizio");

		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "application/x-msexcel";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", dt.fileName));
		Response.AddHeader("Content-Length", content.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(content);
		Response.End();
	}

	void ExportVolumeTrafficoSuTratta(ExportVolumeTrafficiSuTrattaData dt)
	{
		ITRS_BL.BLStatistiche bl = new ITRS_BL.BLStatistiche();

		byte[] content = bl.ExportVolumeTrafficoSuTratta(dt.Data, dt.IdC2P, dt.sort);

		PageBase.AddUserActivity(TipoAttivita.ReportVTST, "Export volume traffico su tratta");

		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "application/x-msexcel";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", dt.fileName));
		Response.AddHeader("Content-Length", content.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(content);
		Response.End();
	}

	void ExportVolumeTrafficoPerDirezione(ExportVolumeTrafficiPerDirezioneData dt)
	{
		ITRS_BL.BLStatistiche bl = new ITRS_BL.BLStatistiche();

		byte[] content = bl.ExportVolumeTrafficoPerDirezione(dt.Data, dt.Direzione, dt.sort);

		PageBase.AddUserActivity(TipoAttivita.ReportVTPD, "Export report volume traffico per direzione");

		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "application/x-msexcel";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", dt.fileName));
		Response.AddHeader("Content-Length", content.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(content);
		Response.End();
	}


	void ExportIndagineDettaglioTransito(ExportIndagineDettaglioTransito dt)
	{
		ITRS_BL.BLIndagini bl = new ITRS_BL.BLIndagini();
		ITRS_BL.ResultQueryIndagineTransito qi = bl.GetResultJobIndagineTransiti(dt.JobId, dt.Targa, dt.Nazionalita, dt.DataOraRilevamento);
		if (qi == null)
		{
			Response.Close();
			return;
		}

		string rootDir = Path.Combine(System.IO.Path.GetTempPath(), Guid.NewGuid().ToString());
		System.IO.Directory.CreateDirectory(rootDir);

		string prefix = string.Format("RicercaTransiti_{0:yyyy}{0:MM}{0:dd}_{0:HH}{0:mm}{0:ss}", DateTime.Now);


		string htmlFileName = string.Format("{0}.htm", prefix);
		string htmlDir = string.Format("{0}_files", prefix);

		System.IO.Directory.CreateDirectory(rootDir + "\\" + htmlDir);


		List<string> files = new List<string>();

		files.Add(htmlFileName);
		using (StreamWriter fs = File.CreateText(Path.Combine(rootDir, htmlFileName)))
		{
			ITRS_BL.IndaginiQueueJob JobData = bl.GetJobData(dt.JobId);


			fs.WriteLine("<h1>Transito<h1>");

			fs.WriteLine("<table border='1' >");
			{
				fs.WriteLine("<tr><td>Targa</td><td>{0}</td></tr>", qi.TargaAcquisita);
				fs.WriteLine("<tr><td>Nazionalita`</td><td>{0}</td></tr>", qi.NazionalitaAcquisita);
				fs.WriteLine("<tr><td>Rivelato il</td><td>{0}</td></tr>", qi.DataOraRilevamento.ToString());
				fs.WriteLine("<tr><td>Area di servizio</td><td>{0}</td></tr>", qi.C2p_Descrizione);
				fs.WriteLine("<tr><td>Direzione</td><td>{0}</td></tr>", ITRSUtility.Translate(qi.C2p_Direzione));
				fs.WriteLine("<tr><td>Varco</td><td>{0}</td></tr>", ITRSUtility.Translate(qi.EnumTipoVarco));
				fs.WriteLine("<tr><td>Stato</td><td>{0}</td></tr>", ITRSUtility.Translate(qi.EnumStatoTransito));
			}
			fs.WriteLine("</table>");
			fs.WriteLine("<br/>");
			fs.WriteLine("<br/>");


			if (true)
			{
				string imgPath = string.Format("{0}/img.jpg", htmlDir);

				if (qi.Immagine == null)
				{
					ITRS_BL.BLTransiti bl2 = new ITRS_BL.BLTransiti();
					bool imgInC2P;
					qi.Immagine = bl2.GetBlobImmagine(dt.Targa, dt.Nazionalita, dt.DataOraRilevamento, out imgInC2P);
				}

				if (qi.Immagine != null)
				{
					fs.WriteLine("<img src='{0}' alt='' />", imgPath);

					files.Add(imgPath);
					string imgFilePath = Path.Combine(rootDir, imgPath);
					using (FileStream fImg = File.Create(imgFilePath))
					{
						fImg.Write(qi.Immagine, 0, qi.Immagine.Length);
					}
				}
				else
					fs.WriteLine("Immagine non disponibile");
			}
		}

		// zip
		string fnzip = Path.GetFileNameWithoutExtension(htmlFileName) + ".zip";
		WU.ZipHtml(rootDir, files, fnzip);

		WU.SendFile(Response, rootDir + "\\" + fnzip, fnzip);
		Directory.Delete(rootDir, true);
	}


	void ExportSorveglianzaDettaglioTransito(ExportSorveglianzaDettaglioTransito dt)
	{
		ITRS_BL.BLTransiti bl = new ITRS_BL.BLTransiti();
		ITRS_BL.DatiTransito qi = bl.GetDatiTransitoOrTransitoSuEvento(dt.Targa, dt.Nazionalita, dt.DataOraRilevamento);
		if (qi == null)
		{
			Response.Close();
			return;
		}

		string rootDir = Path.Combine(System.IO.Path.GetTempPath(), Guid.NewGuid().ToString());
		System.IO.Directory.CreateDirectory(rootDir);

		string prefix = string.Format("SorveglianzaTransito_{0:yyyy}{0:MM}{0:dd}_{0:HH}{0:mm}{0:ss}", DateTime.Now);


		string htmlFileName = string.Format("{0}.htm", prefix);
		string htmlDir = string.Format("{0}_files", prefix);

		System.IO.Directory.CreateDirectory(rootDir + "\\" + htmlDir);


		List<string> files = new List<string>();

		files.Add(htmlFileName);
		using (StreamWriter fs = File.CreateText(Path.Combine(rootDir, htmlFileName)))
		{
			fs.WriteLine("<h1>Transito<h1>");

			fs.WriteLine("<table border='1' >");
			{
				fs.WriteLine("<tr><td>Targa</td><td>{0}</td></tr>", qi.TargaAcquisita);
				fs.WriteLine("<tr><td>Nazionalita`</td><td>{0}</td></tr>", qi.NazionalitaAcquisita);
				fs.WriteLine("<tr><td>Rivelato il</td><td>{0}</td></tr>", qi.DataOraRilevamento.ToString());
				fs.WriteLine("<tr><td>Area di servizio</td><td>{0}</td></tr>", qi.DescrizioneC2P);
				fs.WriteLine("<tr><td>Direzione</td><td>{0}</td></tr>", ITRSUtility.Translate(qi.DirezioneC2P));
				fs.WriteLine("<tr><td>Varco</td><td>{0}</td></tr>", ITRSUtility.Translate(qi.TipoVarco));
				fs.WriteLine("<tr><td>Stato</td><td>{0}</td></tr>", ITRSUtility.Translate(qi.StatoTransito));
			}
			fs.WriteLine("</table>");
			fs.WriteLine("<br/>");
			fs.WriteLine("<br/>");


			if (true)
			{
				string imgPath = string.Format("{0}/img.jpg", htmlDir);

				byte[] Immagine = null;
				if (Immagine == null)
				{
					ITRS_BL.BLTransiti bl2 = new ITRS_BL.BLTransiti();
					bool imgInC2P;
					Immagine = bl2.GetBlobImmagine(dt.Targa, dt.Nazionalita, dt.DataOraRilevamento, out imgInC2P);
				}

				if (Immagine != null)
				{
					fs.WriteLine("<img src='{0}' alt='' />", imgPath);

					files.Add(imgPath);
					string imgFilePath = Path.Combine(rootDir, imgPath);
					using (FileStream fImg = File.Create(imgFilePath))
					{
						fImg.Write(Immagine, 0, Immagine.Length);
					}
				}
				else
					fs.WriteLine("Immagine non disponibile");
			}
		}

		// zip
		string fnzip = Path.GetFileNameWithoutExtension(htmlFileName) + ".zip";
		WU.ZipHtml(rootDir, files, fnzip);

		WU.SendFile(Response, rootDir + "\\" + fnzip, fnzip);
		Directory.Delete(rootDir, true);
	}
}
