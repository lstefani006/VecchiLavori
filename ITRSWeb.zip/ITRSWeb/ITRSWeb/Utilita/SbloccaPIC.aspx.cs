using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Globalization;

using ITRS_BL;

public partial class Utilita_SbloccaPIC : PageBase
{
	[Serializable]
	class PageState
	{
		public int? idCoa = null;

		public string trSort = "Targa";
		public string trSortDir = "";

		public string evSort = "evTarga";
		public string evSortDir = "";
	}
	PageState _pageState = new PageState();
	protected override void LoadControlState(object savedState)
	{
		// faccio try/catch per evitare l'invalid cast quando si ricomila
		try { _pageState = (PageState)savedState; }
		catch { }
	}
	protected override object SaveControlState()
	{
		return _pageState;
	}

	protected override void OnInit(EventArgs e)
	{
		Page.RegisterRequiresControlState(this);

		this.Load += Page_Load;
		this.LoadComplete += Page_LoadComplete;

		base.OnInit(e);
	}

	protected bool AbilitazioneRipristino;

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsCallback)
		{
			if (User.IsInRole("Operatore sorveglianza"))
			{
				_pageState.idCoa = ITRSUtility.GetCoaDiAppartenenza();
				AbilitazioneRipristino = false;
			}

			if (User.IsInRole("RipristinoTrEvCoa"))
			{
				_pageState.idCoa = ITRSUtility.GetCoaDiAppartenenza();
				AbilitazioneRipristino = true;
			}

			if (User.IsInRole("RipristinoTrEv"))
			{
				_pageState.idCoa = null;
				AbilitazioneRipristino = true;
			}
		}

		if (!IsPostBack)
		{
			// la prima volta carico i dati.. altrimenti che visualizzo?
			LoadTrData();
			LoadEvData();
		}

		if (IsPostBack && !IsCallback)
		{
			// sui post back devo ricaricare i dati perche` e` l'unico modo per farmi 
			// arrivare gli eventi nella griglia. Si frutta la fase ProcessPostData second try
			// Notare che qui ho gia` caricato i dati del pageControlState.. per cui
			// posso sapere l'idCoa del precedente post back.
			// 
			LoadTrData();
			LoadEvData();
		}
	}

	bool _reloadTR = false;
	bool _reloadEV = false;

	void Page_LoadComplete(object sender, EventArgs e)
	{
		// qui sono gia` passato dagli eventi .. ossia rpTrPIC_ItemCommand e rpEvPIC_ItemCommand
		// gli eventi richiedono tramite _reloadXX se e` necessario ricaricare i dati dal DB.
		// altrimenti e` un peccato rompere le scatole al DB un'altra volta

		if (_reloadTR && this.rpTrPIC.Visible)
			LoadTrData();

		if (_reloadEV && this.rpEvPIC.Visible)
			LoadEvData();
	}

	void LoadTrData()
	{
		int? idCoa = _pageState.idCoa;

		string sort = _pageState.trSort + _pageState.trSortDir;
		using (BLTransiti bl = new BLTransiti())
		{
			ICollection<TransitoPresoInCarico> r = bl.GetListaTransitiPresiInCarico(sort, idCoa);
			this.rpTrPIC.DataSource = r;
			this.rpTrPIC.DataBind();
		}
	}
	void LoadEvData()
	{
		int? idCoa = _pageState.idCoa;

		string sort = _pageState.evSort + _pageState.evSortDir;
		using (BLEventi bl = new BLEventi())
		{
			ICollection<EventoPresoInCarico> r = bl.GetListaEventiTSPresiInCarico(sort, idCoa);
			this.rpEvPIC.DataSource = r;
			this.rpEvPIC.DataBind();
		}
	}


	protected int NumEv()
	{
		try
		{
			return ((ICollection<EventoPresoInCarico>)this.rpEvPIC.DataSource).Count;
		}
		catch
		{
			return 0;
		}
	}
	protected int NumTr()
	{
		try
		{
			return ((ICollection<TransitoPresoInCarico>)this.rpTrPIC.DataSource).Count;
		}
		catch
		{
			return 0;
		}
	}

	public class trCA
	{
		public string t;
		public string n;
		public DateTime d;
	}
	public class evCA
	{
		public string t;
		public string n;
		public DateTime d;
		public string i; // il mio povero serializzatore non supporta Int64
		public DateTime trd;
	}

	// funzioni per costruire la CommandArg sui link di ripristino
	protected string trBuildCommandArg(TransitoPresoInCarico tr)
	{
		trCA c = new trCA();
		c.t = tr.Targa;
		c.n = tr.Nazionalita;
		c.d = tr.DataOraRilevamento;
		return ClientState.Serialize(c);
	}
	protected string evBuildCommandArg(EventoPresoInCarico ev)
	{
		evCA c = new evCA();
		c.t = ev.evTarga;
		c.n = ev.evNazionalita;
		c.d = ev.evDataOraInserimento;
		c.i = ev.evIdEvento.ToString(CultureInfo.InvariantCulture);
		c.trd = ev.trDataOraRilevamento;
		return ClientState.Serialize(c);
	}

	// funzioni che ritornano l'html relativo alla freccetta del sort sull'header
	protected string TrGP(string s) { return GP(s, _pageState.trSort, _pageState.trSortDir); }
	protected string EvGP(string s) { return GP(s, _pageState.evSort, _pageState.evSortDir); }
	private static string GP(string s, string currentSort, string currentDir)
	{
		string none = string.Empty;
		string asc = "<span class='SbloccaPIC_GP'>6</span>";
		string dsc = "<span class='SbloccaPIC_GP'>5</span>";

		if (s != currentSort)
			return none;

		if (currentDir == string.Empty)
			return asc;
		else
			return dsc;
	}

	// funzioni che ritornano l'item corrente tipato 
	protected TransitoPresoInCarico TR { get { return (TransitoPresoInCarico)this.Page.GetDataItem(); } }
	protected EventoPresoInCarico EV { get { return (EventoPresoInCarico)this.Page.GetDataItem(); } }

	protected string Q(string v) 
	{
		if (AbilitazioneRipristino == false) return "return false;";
		return string.Format("return a(\"{0}\")", v); 
	}

	protected void rpTrPIC_ItemCommand(object source, RepeaterCommandEventArgs e)
	{
		if (e.CommandName == "R")
		{
			trCA tr = ClientState.DeserializeType<trCA>((string)e.CommandArgument);
			SbloccaTransito(tr);
			_reloadTR = true;
		}
		else if (e.CommandName == "S")
		{
			SetNewSort((string)e.CommandArgument, ref _pageState.trSort, ref _pageState.trSortDir);
			_reloadTR = true;
		}
	}
	protected void rpEvPIC_ItemCommand(object source, RepeaterCommandEventArgs e)
	{
		if (e.CommandName == "R")
		{
			evCA ev = ClientState.DeserializeType<evCA>((string)e.CommandArgument);
			SbloccaEvento(ev);
			_reloadEV = true;
		}
		else if (e.CommandName == "S")
		{
			SetNewSort((string)e.CommandArgument, ref _pageState.evSort, ref _pageState.evSortDir);
			_reloadEV = true;
		}
	}

	static void SetNewSort(string newSort, ref string currentSort, ref string currentDir)
	{
		if (newSort == currentSort)
		{
			if (currentDir == string.Empty)
				currentDir = " desc";
			else
				currentDir = string.Empty;
		}
		else
		{
			currentSort = newSort;
			currentDir = string.Empty;
		}
	}

	protected void SbloccaTransito(trCA tr)
	{
		using (BLTransiti bl = new BLTransiti())
		{
			bool b = bl.AnnullaTransitoPresoInCarico(tr.t, tr.n, tr.d);
			if (b)
				ClientScript.RegisterStartupScript(this.GetType(), "pp", "alert('Transito ripristinato!')", true);
			else
				ClientScript.RegisterStartupScript(this.GetType(), "pp", "alert('Transito NON ripristinato!')", true);
		}
	}
	protected void SbloccaEvento(evCA ev)
	{
		using (BLEventi bl = new BLEventi())
		{
			Int64 i = Convert.ToInt64(ev.i, CultureInfo.InvariantCulture);
			bool b = bl.AnnullaPresaInCaricoEvTS(ev.t, ev.n, ev.d, i, ev.trd);
			if (b)
				ClientScript.RegisterStartupScript(this.GetType(), "pp", "alert('Evento ripristinato!')", true);
			else
				ClientScript.RegisterStartupScript(this.GetType(), "pp", "alert('Evento NON ripristinato!')", true);
		}
	}
}
