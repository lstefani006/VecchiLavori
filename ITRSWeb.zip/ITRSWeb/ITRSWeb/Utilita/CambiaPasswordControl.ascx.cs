using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;


public partial class Utilita_CambiaPasswordControl : System.Web.UI.UserControl
{
	#region Stato della pagina
	/// <summary>
	/// stato della pagina memorizzato nel control State
	/// </summary>
	[Serializable]
	protected class PageState
	{
		public bool _bottoneCancellaAbilitato;
		public bool _bottoneContinuaAbilitato;
		public string _vecchiaPassword;
		public string _userName;
		public bool _pwdCambiata;
		public string _errMsg;
	}
	protected PageState _pageState = new PageState();

	protected override void LoadControlState(object savedState)
	{
		_pageState = (PageState)savedState;
	}
	protected override object SaveControlState()
	{
		return _pageState;
	}
	#endregion

	public Utilita_CambiaPasswordControl()
	{
		this.Init += Page_Init;
	}

	protected override bool SupportAutoEvents
	{
		get { return false; }
	}

	protected void Page_Init(object sender, EventArgs e)
	{
		Page.RegisterRequiresControlState(this);

		this.PreRender += Utilita_CambiaPasswordControl_PreRender;
	}

	void Utilita_CambiaPasswordControl_PreRender(object sender, EventArgs e)
	{
		if (_pageState._vecchiaPassword != null)
			tbCambiaPwd.Rows.RemoveAt(0);

		if (_pageState._pwdCambiata)
		{
			btnContinua.Visible = true;
			btnCambiaPassword.Visible = false;
			btnCancella.Visible = false;
		}
		else
		{
			btnContinua.Visible = false;
			btnCambiaPassword.Visible = true;
			btnCancella.Visible = true;
		}

		if (_pageState._errMsg != null)
		{
			lblErrorPwd.ForeColor = System.Drawing.Color.Red;
			lblErrorPwd.Text = _pageState._errMsg;
			lblErrorPwd.Visible = true;
		}
		else
			lblErrorPwd.Visible = false;

		this.btnCancella.Visible = _pageState._bottoneCancellaAbilitato;
		this.btnContinua.Visible = _pageState._bottoneContinuaAbilitato;
	}


	protected void btnCambiaPassword_Click(object sender, EventArgs e)
	{
		MembershipUserWithProfile mu;
		if (string.IsNullOrEmpty(this.UserName))
			mu = (MembershipUserWithProfile)Membership.GetUser(false);
		else
			mu = (MembershipUserWithProfile)Membership.GetUser(this.UserName, false);

		string pwdold = this.VecchiaPassword == null ? this.pwdOld.Text : this.VecchiaPassword;

		string errMsg = ITRSUtility.ControllaPassword(pwd1.Text, pwd2.Text, pwdold);
		if (!string.IsNullOrEmpty(errMsg))
		{
			_pageState._errMsg = errMsg;
			return;
		}


		bool b = mu.ChangePassword(pwdold, pwd1.Text);
		if (b)
		{
			_pageState._pwdCambiata = true;
			_pageState._errMsg = "Password cambiata!";
			_pageState._bottoneContinuaAbilitato = true;
		}
	}
	protected void btnCancella_Click(object sender, EventArgs e)
	{
		if (Cancella != null)
			Cancella(this, new EventArgs());
	}

	public string UserName
	{
		set { _pageState._userName = value;  }
		get { return _pageState._userName; }
	}

	public string VecchiaPassword
	{
		set { _pageState._vecchiaPassword = value; }
		get { return _pageState._vecchiaPassword; }
	}

	[Bindable(true), Category("Behavior"), DefaultValue("False")]
	public bool BottoneCancellaAbilitato
	{
		set { _pageState._bottoneCancellaAbilitato = value; }
		get { return _pageState._bottoneCancellaAbilitato; }
	}

	[Bindable(true), Category("Behavior"), DefaultValue("False")]
	public bool BottoneContinuaAbilitato
	{
		set { _pageState._bottoneContinuaAbilitato = value; }
		get { return _pageState._bottoneContinuaAbilitato; }
	}


	public event EventHandler PasswordCambiata;
	public event EventHandler Cancella;

	protected void btnContinua_Click(object sender, EventArgs e)
	{
		if (PasswordCambiata != null)
			PasswordCambiata(this, new EventArgs());
	}
}
