using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for ManageUserRoles
/// </summary>
public partial class ManageUserRoles : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			lkRuoli_Click(null, null);
		}

		// perdo a causa della mancanza del viewstate il bold sul link su di un poskBack
		// MultiView1.ActiveViewIndex resiste pero` alla mancanza del view state
		if (this.MultiView1.ActiveViewIndex == 0)
		{
			this.lkRuoli.Font.Bold = true;
			this.lkUtenti.Font.Bold = false;
		}
		else
		{
			this.lkRuoli.Font.Bold = false;
			this.lkUtenti.Font.Bold = true;
		}
	}

	protected void lkRuoli_Click(object sender, EventArgs e)
	{
		this.MultiView1.ActiveViewIndex = 0;
		this.lkRuoli.Font.Bold = true;
		this.lkUtenti.Font.Bold = false;
	}

	protected void lkUtenti_Click(object sender, EventArgs e)
	{
		this.MultiView1.ActiveViewIndex = 1;
		this.lkRuoli.Font.Bold = false;
		this.lkUtenti.Font.Bold = true;
	}

	protected void btnNuovoRuoloPerUtente_Click(object sender, EventArgs e)
	{
		string utente = gvListaUtenti.SelectedValue.ToString();
		string ruolo = ddlRuoliNuoviPerUtente.SelectedValue;

		if (ruolo == "") return;
		Roles.AddUserToRole(utente, ruolo);
		ddlRuoliNuoviPerUtente.DataBind();
	}

	protected void btnAssegnaUtenteAlRuolo_Click(object sender, EventArgs e)
	{
		string ruolo = ddlRuoli.SelectedValue;
		string utente = dllNuoviUtentiPerRuolo.SelectedValue;

		if (utente == "") return;
		Roles.AddUserToRole(utente, ruolo);
		dllNuoviUtentiPerRuolo.DataBind();
	}

	// quando si cancella una riga non c'e` un modo per costringere la lista
	// ad aggiornarsi... --> databind()
	protected void gvRuoli_RowDeleted(object sender, GridViewDeletedEventArgs e)
	{
		// questa chiamata chiama bl.
		ddlRuoliNuoviPerUtente.DataBind();
	}

	// quando si cancella una riga non c'e` un modo per costringere la lista
	// ad aggiornarsi... --> databind()
	protected void gvUtenti_RowDeleted(object sender, GridViewDeletedEventArgs e)
	{
		dllNuoviUtentiPerRuolo.DataBind();
	}

	protected void gvListaUtenti_PageIndexChanging(object sender, GridViewPageEventArgs e)
	{
		gvListaUtenti.SelectedIndex = 0;
	}
    protected void MultiView1_ActiveViewChanged(object sender, EventArgs e)
    {

    }
}
