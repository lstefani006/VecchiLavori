using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

// la classe viene fatta derivare da PageBase al posto di System.Web.UI.Page
public partial class Amministrazione_AdminCOA : PageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        // per gestire gli errori di aggiornamento del db e della details view
        base.WriteError += new WriteErrorDelegate(AdminCOA_WriteError);
        base.HandleError(this.gvCOA);
        base.HandleError(this.dvCOA);
        base.HandleError(this.odsCOA);
        base.HandleError(this.odsRowCOA);

		////// imposta le freccette per il sort e
		////// la manina e il doppio click per la selezione
		////// nella grid view
		////this.gvCOA.RowCreated += new GridViewRowEventHandler(base.gv_RowCreated);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        // imposto il sort iniziale della grid view
        if (!IsPostBack)
            this.gvCOA.Sort("IdCOA", SortDirection.Ascending);

        if (this.lblError.EnableViewState == true)
            this.lblError.Text = "";

        // per gestire il controllo dei campi prima i fare insert/update (validazione)
        this.dvCOA.ItemInserting += new DetailsViewInsertEventHandler(dvCOA_ItemInserting);
        this.dvCOA.ItemUpdating += new DetailsViewUpdateEventHandler(dvCOA_ItemUpdating);


        // se ri-seleziono una riga gia` selezionata tolgo la selezione
        gvCOA.SelectedIndexChanging += new GridViewSelectEventHandler(gvCOA_SelectedIndexChanging);

        // la riga selezionata � cambiata: modifico il comportamento del detail view.
        gvCOA.SelectedIndexChanged += new EventHandler(gvCOA_SelectedIndexChanged);


        // per rinfrescare la griglia quando si inserisce/modifica/cancella
        // un record dal detail view
        dvCOA.ItemUpdated += new DetailsViewUpdatedEventHandler(dvCOA_ItemUpdated);
        dvCOA.ItemInserted += new DetailsViewInsertedEventHandler(dvCOA_ItemInserted);
        dvCOA.ItemDeleted += new DetailsViewDeletedEventHandler(dvCOA_ItemDeleted);
    }

    private void AdminCOA_WriteError(Exception ex)
    {
        this.lblError.ForeColor = System.Drawing.Color.Red;
        if (ex.InnerException == null)
            this.lblError.Text = ex.Message;
        else
            this.lblError.Text = ex.InnerException.Message;
    }


    void dvCOA_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
    {
        // se ho cancellato una riga ... costringo la grid view a riaggiornarsi
		gvCOA.SelectedIndex = -1;
		gvCOA.DataBind();

		// vado in insert mode nella datail view
		//if (gvTratte.Rows.Count == 0)
		this.dvCOA.ChangeMode(DetailsViewMode.Insert);
	}

    void dvCOA_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
    {
        // se ho inserito una riga ... costringo la grid view a riaggiornarsi
		gvCOA.SelectedIndex = -1;
		gvCOA.DataBind();
    }

    void dvCOA_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
    {
        // se ho aggiornato una riga ... costringo la grid view a riaggiornarsi
		gvCOA.SelectedIndex = -1;
		gvCOA.DataBind();
    }

    void gvCOA_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        // resetto la selezione corrente se clicco una seconda volta nella stessa riga della
        // grid view
        if (e.NewSelectedIndex == gvCOA.SelectedIndex)
            e.NewSelectedIndex = -1;
    }
    void gvCOA_SelectedIndexChanged(object sender, EventArgs e)
    {
        // se seleziono una riga nella grid view metto la detail view 
        // nella modalita` di visualizzazione (che poi consentira` di editare/cancella 
        // il record).
        // Se la grid view rimane senza selezione vado direttamente in edit-mode.
        if (gvCOA.SelectedIndex >= 0)
            this.dvCOA.ChangeMode(DetailsViewMode.ReadOnly);
        else
            this.dvCOA.ChangeMode(DetailsViewMode.Insert);

        this.dvCOA.DataBind();
    }


    // controllo di validita` dei campi quando si fa l'aggiornamento di un record
    void dvCOA_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
    {
		string descrizione = (string)e.NewValues["Descrizione"];
		if (descrizione != null) descrizione = descrizione.Trim();
		if (string.IsNullOrEmpty(descrizione))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Descrizione COA' � obbligatorio");
			return;
		}
		e.NewValues["Descrizione"] = descrizione;
	}


    // controllo di validita` dei campi quando si fa l'inserimento di un nuovo record
    void dvCOA_ItemInserting(object sender, DetailsViewInsertEventArgs e)
    {
		string field;

		field = (string)e.Values["IdCOA"];
		if (!base.dv_CheckField(ref field))
		{
            e.Cancel = true;
            base.lbl_WriteError(lblError, "Il campo 'Id COA' � obbligatorio");
            return;
        }

		if (!base.dv_IsInteger(ref field))
		{
            e.Cancel = true;
            base.lbl_WriteError(lblError, "Il campo 'Id COA' deve essere un numero");
			return;
        }
		e.Values["IdCOA"] = field;

        field = (string)e.Values["Descrizione"];
		if (!base.dv_CheckField(ref field))
		{
            e.Cancel = true;
            base.lbl_WriteError(lblError, "Il campo 'Descrizione COA' � obbligatorio");
            return;
        }
        e.Values["Descrizione"] = field;
    }
}
