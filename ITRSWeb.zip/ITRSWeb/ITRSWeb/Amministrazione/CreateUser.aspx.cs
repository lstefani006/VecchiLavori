using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using ITRS_BL;

public partial class CreateUser : System.Web.UI.Page
{

	protected void Page_Init(object sender, EventArgs e)
	{
		foreach (string p in ITRSUtility.GetProfileList())
		{
			ddlProfilo.Items.Add(new ListItem(p, p));
		}

		List<ITRS_BL.Coa> lstCoa = BLCacher.GetListaCOA();
		ddlCoa.Items.Add(new ListItem("<nessuno>", ""));
		foreach (ITRS_BL.Coa c in lstCoa)
		{
			ddlCoa.Items.Add(new ListItem(c.Descrizione, c.IdCOA.ToString()));
		}

		this.Page.RegisterRequiresControlState(this);
	}

	#region ControlState
	protected override object SaveControlState()
	{
		return _id;
	}
	protected override void LoadControlState(object state)
	{
		_id = state as ControlState;
	}

	[Serializable]
	class ControlState
	{
		public ControlState()
		{
			EditVisibile=false;
		}

		public bool EditVisibile;
	}
	ControlState _id = null;
	#endregion


	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
			_id = new ControlState();

	}
	protected void btnCreateUser_Click(object sender, EventArgs e)
	{
		if (this.TxtUserName.Text.Length < 4)
		{
			this.lblError.Text = "Il nome utente deve essere composto da almeno 4 caratteri";
			this.lblError.ForeColor = System.Drawing.Color.Red;
			return;
		}

		string errMsg = ITRSUtility.ControllaPassword(TxtPassword.Text, TxtConfermaPassword.Text, null);
		if (!string.IsNullOrEmpty(errMsg))
		{
			this.lblError.Text = errMsg;
			this.lblError.ForeColor = System.Drawing.Color.Red;
		}

		// NOTA BENE  lo username DEVE essere minuscolo cosi diventa CASE INSENSITIVE
		this.TxtUserName.Text = this.TxtUserName.Text.ToLower();

		int? idCoaDiCompetenza = null;
		if (ddlCoa.SelectedValue != "")
			idCoaDiCompetenza = Convert.ToInt32(ddlCoa.SelectedValue);

		try
		{
			OracleMembershipProvider mp = Membership.Provider as OracleMembershipProvider;

			MembershipCreateStatus status;
			MembershipUser newUser = mp.CreateUserWithProfile(
				TxtUserName.Text,
				TxtPassword.Text,
				TxtEmailUtente.Text,
				"",
				"",
				true, 
				null,
				this.ddlProfilo.SelectedValue,
				this.TxtNote.Text,
				idCoaDiCompetenza,
				out status);

			if (newUser == null)
			{
				PageBase.AddUserActivity(TipoAttivita.AmministrazioneUtenti, "Creazione utente {0} con password {1} fallita",
					TxtUserName.Text,
					TxtPassword.Text);

				lblError.Text = GetErrorMessage(status);
				this.lblError.ForeColor = System.Drawing.Color.Red;
				return;
			}

			PageBase.AddUserActivity(
				TipoAttivita.AmministrazioneUtenti, 
				"Creazione utente:'{0}' password:'{1}' profilo:'{2}'",
				TxtUserName.Text,
				TxtPassword.Text,
				ddlProfilo.SelectedValue);

			// Response.Redirect("/ITRSweb/Amministrazione/ManageUserRoles.aspx");

			this.lblError.Text = "Utente creato con successo";
			this.lblError.ForeColor = System.Drawing.Color.Red;
		}
		catch
		{
			lblError.Text = "E' avvenuto un errore durante la creazione dell'utente";
			this.lblError.ForeColor = System.Drawing.Color.Red;
		}
	}


	public string GetErrorMessage(MembershipCreateStatus status)
	{
		switch (status)
		{
		case MembershipCreateStatus.DuplicateUserName:
			return "Username gia' esistente,si prega di inserirne uno diverso.";

		case MembershipCreateStatus.DuplicateEmail:
			return "L' indirizzo email risulta gi� associato ad un altro utente.";

		case MembershipCreateStatus.InvalidPassword:
			return "La password inserita non � valida.";

		case MembershipCreateStatus.InvalidEmail:
			return "L'indirizzo email inserito non � valido.";

		case MembershipCreateStatus.InvalidAnswer:
			return "La risposta alla domanda di sicurezza non � valida.";

		case MembershipCreateStatus.InvalidQuestion:
			return "La domanda di sicurezza non � valida.";

		case MembershipCreateStatus.InvalidUserName:
			return "Lo username inserito non � valido,si prega di sceglierne uno diverso.";

		case MembershipCreateStatus.ProviderError:
			return "Il provider di autenticazione ha dato un errore,si prega di contattare l' amministrazione del servizio.";

		case MembershipCreateStatus.UserRejected:
			return "La richiesta di registrazione � stata cancellata,se il problema persiste contattare l' amministratore del sevizio";

		default:
			return "Si � verificato un errore non conosciuto,si prega di controllare i dati inseriti e riprovare.";
		}
	}
}
