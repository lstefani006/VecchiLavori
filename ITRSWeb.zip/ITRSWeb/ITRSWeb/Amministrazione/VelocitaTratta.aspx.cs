using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Collections;
using System.Drawing;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using ITRS_BL;

public partial class Amministrazione_VelocitaTratta : PageBase
{
	[Serializable]
	public class DatiTratte
	{
		#region variabili private
		int _IdTratta;
		string _Descrizione;
		int _Km;
		string _TempoPercorrenza;
		int _VelocitaMedia;
		#endregion

		public int IdTratta { get { return _IdTratta; } set { _IdTratta = value; } }
		public string Descrizione { get { return _Descrizione; } set { _Descrizione = value; } }
		public int Km { get { return _Km; } set { _Km = value; } }
		public string TempoPercorrenza { get { return _TempoPercorrenza; } set { _TempoPercorrenza = value; } }
		public int VelocitaMedia { get { return _VelocitaMedia; } set { _VelocitaMedia = value; } }
	}


	protected void Page_Init(object sender, EventArgs e)
	{
		Page.RegisterRequiresControlState(this);
		this.MaintainScrollPositionOnPostBack = true;
	}

	[Serializable]
	class PageState
	{
		public int SelectedIdTratta = -1;
		public List<DatiTratte> ListaTratte;
	}
	PageState _pageState = new PageState();
	protected override void LoadControlState(object savedState)
	{
		_pageState = (PageState)savedState;
	}
	protected override object SaveControlState()
	{
		return _pageState;
	}


	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			_pageState = new PageState();
			_pageState.SelectedIdTratta = -1;
			_pageState.ListaTratte = new List<DatiTratte>();

			CaricaDati();
		}

		gvTratte.DataSource = _pageState.ListaTratte;
		gvTratte.DataBind();

	}
	protected void gvTratte_RowCommand(object sender, GridViewCommandEventArgs e)
	{
		if (e.CommandName == "Select")
		{
			int idTratta = int.Parse((string)e.CommandArgument);

			_pageState.SelectedIdTratta = idTratta;

			for (int i = 0; i < _pageState.ListaTratte.Count; ++i)
			{
				if (_pageState.ListaTratte[i].IdTratta == idTratta)
				{
					tbVelocita.Text = _pageState.ListaTratte[i].VelocitaMedia.ToString();
					lblTrattaSelezionata.Text = _pageState.ListaTratte[i].Descrizione + ":";

					break;
				}
			}
		}
	}

	protected override void OnPreRender(EventArgs e)
	{
		base.OnPreRender(e);

		if (_pageState.SelectedIdTratta >= 0)
			divModifica.Visible = true;
		else
			divModifica.Visible = false;

		gvTratte.DataSource = _pageState.ListaTratte;
		gvTratte.DataBind();
	}

	private void CaricaDati()
	{
		using (BLTratte bl = new BLTratte())
		{
			List<Tratta> lt = bl.GetListaTratte(null);
			_pageState.ListaTratte.Clear();


			foreach (Tratta t in lt)
			{
				DatiTratte dt = new DatiTratte();
				dt.Descrizione = t.Descrizione;
				dt.IdTratta = t.IdTratta;
				dt.Km = (int)t.LunghezzaKm;
				dt.VelocitaMedia = (int)(t.LunghezzaKm / (t.TempoMinPercorrenzaSecondi / 3600.0));
				dt.TempoPercorrenza = TimeSpan.FromSeconds(t.TempoMinPercorrenzaSecondi).ToString();
				_pageState.ListaTratte.Add(dt);

			}
		}
	}


	protected void btnSalva_Click(object sender, EventArgs e)
	{
		Page.Validate();

		if (!Page.IsValid)
		{
			lblError.ForeColor = Color.Red;
			lblError.Text = "Inserire la velocita` media";
			return;
		}

		if (tbVelocita.Text.Trim() == "")
		{
			lblError.ForeColor = Color.Red;
			lblError.Text = "Inserire la velocita` media";
			return;
		}

		int nuovaVelocita;
		if (!		Int32.TryParse(this.tbVelocita.Text, out nuovaVelocita))
		{
			lblError.ForeColor = Color.Red;
			lblError.Text = "Il campo velocita` contiene un numero non valido";
			return;
		}

		try
		{

			using (BLTratte blTratte = new BLTratte())
			{
				blTratte.UpdateVelocita(_pageState.SelectedIdTratta, nuovaVelocita);
			}
			_pageState.SelectedIdTratta = -1;

			CaricaDati();
			gvTratte.DataSource = _pageState.ListaTratte;
			gvTratte.DataBind();

		}
		catch (Exception ex)
		{
			Log.Write(ex, "UpdateVelocita");
			lblError.ForeColor = Color.Red;
			lblError.Text = "Errore durante la fase di aggiornamento della base dati";
			return;
		}
	}
	protected void btnAnnulla_Click(object sender, EventArgs e)
	{
		_pageState.SelectedIdTratta = -1;
	}
}
