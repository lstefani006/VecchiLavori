using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Amministrazione_AdminStrade : PageBase
{
	/*
	 * Dopo un po' di vicissitudini ho scelto per la selezione nella grid view 
	 * di fare un doppio click.
	 * Se si mette un link "Select" tutto funziona ... ma � brutto
	 * Se si mette un immagine nel link arrivano 2 postback al server: � sicuramente
	 * un baco (si evidenzia bene con il tcp_trace).
	 * Se si trasforma il bottonField in un template... si perde la possibilita` di sortare
	 * o paginare la griglia con EnableSortingAndPagingCallbacks=true ... un vero peccato.
	 * Ora non � una questione di gusti... il doppio click � quasi obbligatorio.
	 * Per evitare complicazioni il buttonField � sempre presente come prima colonna
	 * (potrebbe essere dovunque) ma con Text="" --> si generano gli script ma
	 * si non si vede il bottone; con questa accortezza si puo` chiamare lo script Select$
	 * che � armato in base.gv_RowCreated
	 * 
	 * 			<asp:ButtonField ButtonType="link" CommandName="Select" Text="" />

	*/


	protected void Page_Init(object sender, EventArgs e)
	{
		// per gestire gli errori di aggiornamento del db e della details view
		base.WriteError += new WriteErrorDelegate(AdminStrade_WriteError);
		base.HandleError(this.gvStrade);
		base.HandleError(this.dvStrada);
		base.HandleError(this.odsStrade);
		base.HandleError(this.odsRowStrada);

		////// imposta le freccette per il sort e
		////// la manina e il doppio click per la selezione
		////// nella grid view
		////this.gvStrade.RowCreated += new GridViewRowEventHandler(base.gv_RowCreated);

//		this.dvStrada.PreRender += new EventHandler(dvStrada_PreRender);
	}
	protected void Page_Load(object sender, EventArgs e)
	{
		// imposto il sort iniziale della grid view
		if (!IsPostBack)
			this.gvStrade.Sort("CodiceStrada", SortDirection.Ascending);

		if (this.lblError.EnableViewState == true)
			this.lblError.Text = "";

		// per gestire il controllo dei campi prima i fare insert/update (validazione)
		this.dvStrada.ItemInserting += new DetailsViewInsertEventHandler(dvStrada_ItemInserting);
		this.dvStrada.ItemUpdating += new DetailsViewUpdateEventHandler(dvStrada_ItemUpdating);


		// se ri-seleziono una riga gia` selezionata tolgo la selezione
		gvStrade.SelectedIndexChanging += new GridViewSelectEventHandler(gvStrade_SelectedIndexChanging);

		// la riga selezionata � cambiata: modifico il comportamento del detail view.
		gvStrade.SelectedIndexChanged += new EventHandler(gvStrade_SelectedIndexChanged);


		// per rinfrescare la griglia quando si inserisce/modifica/cancella
		// un record dal detail view
		dvStrada.ItemUpdated += new DetailsViewUpdatedEventHandler(dvStrada_ItemUpdated);
		dvStrada.ItemInserted += new DetailsViewInsertedEventHandler(dvStrada_ItemInserted);
		dvStrada.ItemDeleted += new DetailsViewDeletedEventHandler(dvStrada_ItemDeleted);
	}


	void dvStrada_PreRender(object sender, EventArgs e)
	{
		foreach (DetailsViewRow dvr in dvStrada.Rows)
		{
			if (dvr.Cells.Count < 2) continue;
			dvr.Cells[0].Width = new Unit(15, UnitType.Percentage);
			dvr.Cells[1].Width = new Unit(85, UnitType.Percentage);

			if (dvr.Cells[1].Controls.Count == 0) continue;
			TextBox tb = dvr.Cells[1].Controls[0] as TextBox;
			if (tb != null)
			{
				tb.Width = new Unit(98, UnitType.Percentage);
			}
		}
	}

	private void AdminStrade_WriteError(Exception ex)
	{
		this.lblError.ForeColor = System.Drawing.Color.Red;
		if (ex.InnerException == null)
			this.lblError.Text = ex.Message;
		else
			this.lblError.Text = ex.InnerException.Message;
	}


	void dvStrada_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
	{
		// se ho cancellato una riga ... costringo la grid view a riaggiornarsi
		gvStrade.SelectedIndex = -1;
		gvStrade.DataBind();

		// vado in insert mode nella datail view
		//if (gvTratte.Rows.Count == 0)
		this.dvStrada.ChangeMode(DetailsViewMode.Insert);

	}

	void dvStrada_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
	{
		// se ho inserito una riga ... costringo la grid view a riaggiornarsi
		gvStrade.SelectedIndex = -1;
		gvStrade.DataBind();
	}

	void dvStrada_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
	{
		// se ho aggiornato una riga ... costringo la grid view a riaggiornarsi
		gvStrade.SelectedIndex = -1;
		gvStrade.DataBind();
	}

	void gvStrade_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		// resetto la selezione corrente se clicco una seconda volta nella stessa riga della
		// grid view
		if (e.NewSelectedIndex == gvStrade.SelectedIndex)
			e.NewSelectedIndex = -1;
	}

	void gvStrade_SelectedIndexChanged(object sender, EventArgs e)
	{
		// se seleziono una riga nella grid view metto la detail view 
		// nella modalita` di visualizzazione (che poi consentira` di editare/cancella 
		// il record).
		// Se la grid view rimane senza selezione vado direttamente in edit-mode.
		if (gvStrade.SelectedIndex >= 0)
			this.dvStrada.ChangeMode(DetailsViewMode.ReadOnly);
		else
			this.dvStrada.ChangeMode(DetailsViewMode.Insert);

		this.dvStrada.DataBind();
	}


	// controllo di validita` dei campi quando si fa l'aggiornamento di un record
	void dvStrada_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
	{
		string field;

		field = (string)e.NewValues["Descrizione"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Descrizione Strada' � obbligatorio");
			return;
		}
		e.NewValues["Descrizione"] = field;
	}


	// controllo di validita` dei campi quando si fa l'inserimento di un nuovo record
	void dvStrada_ItemInserting(object sender, DetailsViewInsertEventArgs e)
	{
		string field;

		field = (string)e.Values["CodiceStrada"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Codice Strada' � obbligatorio");
			return;
		}

		field = (string)e.Values["Descrizione"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Descrizione Strada' � obbligatorio");
			return;
		}
		e.Values["Descrizione"] = field;
	}

}
