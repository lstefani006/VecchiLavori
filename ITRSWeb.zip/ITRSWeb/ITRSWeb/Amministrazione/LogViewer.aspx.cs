using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Xml;
using ITRS_BL;

public partial class Amministrazione_LogViewer : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		tbXml.Visible = false;
		tbXml.ReadOnly = true;
	}
	protected void gvLog_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (gvLog.SelectedIndex < 0)
		{
			tbXml.Text = "";
			tbXml.Visible = false;
			return;
		}

		string smEx = (string)gvLog.SelectedDataKey["smException"];
		if (string.IsNullOrEmpty(smEx))
		{
			tbXml.Text = "";
			tbXml.Visible = false;
			return;
		}

		tbXml.Text = smEx;
		tbXml.Visible = true;
	}

	protected void gvLog_RowCreated(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			BLLog.RecordLog row = (BLLog.RecordLog)e.Row.DataItem;
			if (!string.IsNullOrEmpty(row.smException))
				e.Row.ForeColor = Color.Red;
		}
	}

	protected void gvLog_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			BLLog.RecordLog row = (BLLog.RecordLog)e.Row.DataItem;

			if (!string.IsNullOrEmpty(row.smException))
			{
				try
				{
					XmlDocument doc = new XmlDocument();
					doc.LoadXml(row.smException);
					XmlNode n = doc.DocumentElement.SelectSingleNode("Exception/Message");
					e.Row.Cells[6].Text = n.InnerText;
				}
				catch
				{
					e.Row.Cells[6].Text = "Errore leggendo l'eccezione.";
				}
			}
			else
			{
				e.Row.Cells[6].Text = "";
			}
		}
	}
}
