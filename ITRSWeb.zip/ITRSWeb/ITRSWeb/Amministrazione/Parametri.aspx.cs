using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using ITRS_BL;

public partial class Amministrazione_Parametri : PageBase
{
	#region Page State
	[Serializable]
	class PageState
	{
		public bool visualizzaParametri = true;
		public bool visualizzaLink = false;
	}
	PageState _pageState = new PageState();
	protected override void LoadControlState(object savedState)
	{
		try { _pageState = (PageState)savedState; }
		catch { }
	}
	protected override object SaveControlState()
	{
		return _pageState;
	}
	#endregion

	protected void Page_Init(object sender, EventArgs e)
	{
		Page.RegisterRequiresControlState(this);
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			string P = Request.QueryString["P"];
			if (P.ToUpper() == "FALSE")
			{
				_pageState.visualizzaLink = false;
				_pageState.visualizzaParametri = false;
			}
			else if (P.ToUpper() == "TRUE")
			{
				_pageState.visualizzaLink = false;
				_pageState.visualizzaParametri = true;
			}
			else
			{
				_pageState.visualizzaLink = true;
				_pageState.visualizzaParametri = true;
			}
		}

		if (_pageState.visualizzaParametri == false)
		{
			_titolo = "Gestione allarmi obsoleti";
			this.Title = "Gestione allarmi obsoleti";
			elTitolo.InnerText = _titolo;
		}
		else
		{
			_titolo = "Parametri";
			elTitolo.InnerText = _titolo;
		}

		if (!IsPostBack)
			LoadParametri();

		LoadTsDelay();
	}

	protected string _titolo;

	private void LoadParametri()
	{
		BL_Parametri p = new BL_Parametri();
		List<BL_Parametri.Parametro> plist = p.GetParametri();

		for (int i = 0; i < plist.Count; ++i)
		{
			BL_Parametri.Parametro par = plist[i];

			switch (par.ParTipo)
			{
			case "TEMPO_SOSTA":
				tbTempoDiSosta.Text = par.ParValue.ToString();
				break;
			case "FREQ_VISITE":
				tbFrequenzaVisite.Text = par.ParValue.ToString();
				break;
			case "NUM_C2P_VISITE":
				tbNumeroVisite.Text = par.ParValue.ToString();
				break;
			case "PURGER_LOTTO":
				//tbLotto.Text = par.ParValue.ToString();
				break;
			case "PURGER_EXPTIME":
				TbExpirationTime.Text = par.ParValue.ToString();
				break;
			case "TEMPO_ATT":
				TbTempoAttesa.Text = par.ParValue.ToString();
				break;
			case "TEMPO_RIT":
				TbTempoRitardo.Text = par.ParValue.ToString();
				break;
			case "INDAGINE_MAXREC":
				TbIndagineM.Text = par.ParValue.ToString();
				break;
			}
		}
	}


	protected void btnSave_Click(object sender, EventArgs e)
	{
		if (_pageState.visualizzaParametri)
			SaveParametri();
		else
			SaveTsDelay();
	}

	private void SaveParametri()
	{
		this.Validate();

		if (!this.IsValid)
		{
			// TODO mettere una label per gli errori prima del bottone di ok 
			// e valorizzare il Text con una stringa qui
			return;
		}

		// salvare i dati
		using (BL_Parametri p = new BL_Parametri())
		{
			decimal tempoDiSosta = decimal.Parse(tbTempoDiSosta.Text);
			p.SaveParametro("TEMPO_SOSTA", tempoDiSosta);

			decimal FrequenzaVisite = decimal.Parse(tbFrequenzaVisite.Text);
			p.SaveParametro("FREQ_VISITE", FrequenzaVisite);

			decimal NumeroVisite = decimal.Parse(tbNumeroVisite.Text);
			p.SaveParametro("NUM_C2P_VISITE", NumeroVisite);

			//decimal Lotto = decimal.Parse(tbLotto.Text);
			//p.SaveParametro("PURGER_LOTTO", Lotto);

			decimal ExpirationTime = decimal.Parse(TbExpirationTime.Text);
			p.SaveParametro("PURGER_EXPTIME", ExpirationTime);

			decimal TempoAttesa = decimal.Parse(TbTempoAttesa.Text);
			p.SaveParametro("TEMPO_ATT", TempoAttesa);

			decimal TempoRitardo = decimal.Parse(TbTempoRitardo.Text);
			p.SaveParametro("TEMPO_RIT", TempoRitardo);

			decimal IndagineMR = decimal.Parse(TbIndagineM.Text);
			p.SaveParametro("INDAGINE_MAXREC", IndagineMR);
		}
	}

	private void Parametri_WriteError(Exception ex)
	{
		this.lblError.ForeColor = System.Drawing.Color.Red;
		if (ex.InnerException == null)
			this.lblError.Text = ex.Message;
		else
			this.lblError.Text = ex.InnerException.Message;
	}


	///////////////////////////////////////////////////////////////////

	private void LoadTsDelay()
	{
		using (BLC2P bl = new BLC2P())
		{
			this.rptC2PDelay.DataSource = bl.GetTsDelay();
			this.rptC2PDelay.DataBind();
		}
	}

	protected void btnParametri_Click(object sender, EventArgs e)
	{
		_pageState.visualizzaParametri = true;
		LoadParametri();
	}
	protected void btnTsDelay_Click(object sender, EventArgs e)
	{
		_pageState.visualizzaParametri = false;
		LoadTsDelay();
	}

	void Page_PreRender(object sender, EventArgs e)
	{
		btnParametri.Visible = _pageState.visualizzaLink;
		btnTsDelay.Visible = _pageState.visualizzaLink;
		mvPar.ActiveViewIndex = _pageState.visualizzaParametri ? 0 : 1;
	}

	protected C2PTsDelay R { get { return (C2PTsDelay)this.Page.GetDataItem(); } }

	protected string RTS
	{
		get
		{
			long min = R.TsDelay.HasValue ? R.TsDelay.Value : 30;
			TimeSpan ts = new TimeSpan(0, (int)min, 0);
			string s  = string.Format("{0:00}:{1:00}", ts.Hours, ts.Minutes);
			return s;
		}
	}

	public void SaveTsDelay()
	{
		this.Validate();
		if (!this.IsValid)
			return;

		using (BLC2P bl = new BLC2P())
		{
			List<C2PTsDelay> d = bl.GetTsDelay();

			foreach (RepeaterItem ri in this.rptC2PDelay.Items)
			{
				if (ri.ItemType == ListItemType.Item || ri.ItemType == ListItemType.AlternatingItem)
				{
					TextBox tb = (TextBox)ri.FindControl("edtDelayMin");
					HiddenField hf = (HiddenField)ri.FindControl("idC2p");

					int idC2P = int.Parse(hf.Value);
					TimeSpan ts = TimeSpan.Parse(tb.Text);

					C2PTsDelay rr = U.FindFirst(d, delegate(C2PTsDelay r) { return r.IdC2P == idC2P; });
					if (rr.TsDelay != ts.TotalMinutes)
					{
						rr.TsDelay = (long)ts.TotalMinutes;
						bl.UpdateTsDelay(rr);
					}
				}
			}
		}
	}
}

