using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


public partial class Amministrazione_AttivitaSistema : System.Web.UI.Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        ITRS_BL.BLLog bl = new ITRS_BL.BLLog();

        ddlTipo.DataSource = bl.GetAllTipi();
        ddlTipo.DataBind();

        ddlUtenti.DataSource = bl.GetAllUtenti();
        ddlUtenti.DataBind();
    }
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			this.gvLog.Sort("TS", SortDirection.Descending);
			this.gvLog.Visible = false;
		}
	}
	protected void btnRicerca_Click(object sender, EventArgs e)
	{
		this.gvLog.Sort("TS", SortDirection.Descending);
		this.gvLog.Visible = true;
	}
	protected void gvLog_SelectCount(object sender, ITRSControls.ExGridSelectCountEventArgs e)
	{
		try
		{
			ITRS_BL.BLLog bl = new ITRS_BL.BLLog();


			DateTime? da = this.calcDal.SelectedDate;
			DateTime? a = this.calcAl.SelectedDate;

			int r = bl.GetUserActivityCount(da, a, ddlTipo.SelectedItem.Text, ddlUtenti.SelectedItem.Text);
			e.Count = r;
		}
		catch
		{
			// per lo meno NON faccio crollare la maschera.
			// Lo sparo alla prima pagina invece che all'ultima.
			e.Count = 0;
		}

	}
	protected void odsUserLog_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
	{
		e.InputParameters["da"] = this.calcDal.SelectedDate;
        e.InputParameters["a"] = this.calcAl.SelectedDate;
        e.InputParameters["utente"] = this.ddlUtenti.Text;
        e.InputParameters["tipo"] = this.ddlTipo.Text;
	}
    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);
        this.btnExport.Visible = (gvLog.Visible && gvLog.Rows.Count > 0);
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        string sort = gvLog.SortExpression;        
        sort += (gvLog.SortDirection == SortDirection.Descending) ? " desc" : string.Empty;

        ExportSystemActivityData dd = new ExportSystemActivityData();

		string filePrefix = string.Format("AttivitaSistema_{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now);

        if (calcDal.VisibleDate == null || calcAl.VisibleDate == null)
        {
            dd.fileName = string.Format("{0}.xls", filePrefix);
            dd.From = null;
            dd.To = null;
        }
        else
        {
            dd.fileName = string.Format("{0}_{1}-{2}.xls", filePrefix, calcDal.VisibleDate.Value.ToString("ddMMyy"), calcAl.VisibleDate.Value.ToString("ddMMyy"));
            dd.From = calcDal.VisibleDate.Value;
            dd.To = calcAl.VisibleDate.Value;
        }

        dd.Tipo = ddlTipo.SelectedItem.Text;
        dd.Utente = ddlUtenti.SelectedItem.Text;
        dd.sort = sort;

        MemoryStream ms = new MemoryStream();
        BinaryFormatter bf = new BinaryFormatter();
        bf.Serialize(ms, dd);
        string gg = Convert.ToBase64String(ms.ToArray());
        dnlWindow.Attributes["src"] = "/ITRSWeb/DownloadGeneric.aspx?Action=" + gg;
    }
}
