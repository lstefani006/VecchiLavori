using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Amministrazione_AdminC2P : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		// per gestire gli errori di aggiornamento del db e della details view
		base.WriteError += new WriteErrorDelegate(AdminC2P_WriteError);
		base.HandleError(this.gvC2P);
		base.HandleError(this.dvC2P);
		base.HandleError(this.odsC2P);
		base.HandleError(this.odsRowC2P);
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		// imposto il sort iniziale della grid view
		if (!IsPostBack)
			this.gvC2P.Sort("IdC2P", SortDirection.Ascending);

		if (this.lblError.EnableViewState == true)
			this.lblError.Text = "";

		// per gestire il controllo dei campi prima i fare insert/update (validazione)
		this.dvC2P.ItemInserting += new DetailsViewInsertEventHandler(dvC2P_ItemInserting);
		this.dvC2P.ItemUpdating += new DetailsViewUpdateEventHandler(dvC2P_ItemUpdating);


		// se ri-seleziono una riga gia` selezionata tolgo la selezione
		gvC2P.SelectedIndexChanging += new GridViewSelectEventHandler(gvC2P_SelectedIndexChanging);

		// la riga selezionata � cambiata: modifico il comportamento del detail view.
		gvC2P.SelectedIndexChanged += new EventHandler(gvC2P_SelectedIndexChanged);


		// per rinfrescare la griglia quando si inserisce/modifica/cancella
		// un record dal detail view
		dvC2P.ItemUpdated += new DetailsViewUpdatedEventHandler(dvC2P_ItemUpdated);
		dvC2P.ItemInserted += new DetailsViewInsertedEventHandler(dvC2P_ItemInserted);
		dvC2P.ItemDeleted += new DetailsViewDeletedEventHandler(dvC2P_ItemDeleted);

  }

	private void AdminC2P_WriteError(Exception ex)
	{
		this.lblError.ForeColor = System.Drawing.Color.Red;
		if (ex.InnerException == null)
			this.lblError.Text = ex.Message;
		else
			this.lblError.Text = ex.InnerException.Message;
	}

	void dvC2P_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
	{
		// se ho cancellato una riga ... costringo la grid view a riaggiornarsi
		gvC2P.SelectedIndex = -1;
		gvC2P.DataBind();

		// vado in insert mode nella datail view
		//if (gvTratte.Rows.Count == 0)
		this.dvC2P.ChangeMode(DetailsViewMode.Insert);

	}

	void dvC2P_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
	{
		// se ho inserito una riga ... costringo la grid view a riaggiornarsi
		gvC2P.SelectedIndex = -1;
		gvC2P.DataBind();
	}

	void dvC2P_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
	{
		// se ho aggiornato una riga ... costringo la grid view a riaggiornarsi
		gvC2P.SelectedIndex = -1;
		gvC2P.DataBind();
	}

	void gvC2P_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		// resetto la selezione corrente se clicco una seconda volta nella stessa riga della
		// grid view
		if (e.NewSelectedIndex == gvC2P.SelectedIndex)
			e.NewSelectedIndex = -1;
	}

	void gvC2P_SelectedIndexChanged(object sender, EventArgs e)
	{
		// se seleziono una riga nella grid view metto la detail view 
		// nella modalita` di visualizzazione (che poi consentira` di editare/cancella 
		// il record).
		// Se la grid view rimane senza selezione vado direttamente in edit-mode.
		if (gvC2P.SelectedIndex >= 0)
			this.dvC2P.ChangeMode(DetailsViewMode.ReadOnly);
		else
			this.dvC2P.ChangeMode(DetailsViewMode.Insert);

		this.dvC2P.DataBind();
	}


	// controllo di validita` dei campi quando si fa l'aggiornamento di un record
	void dvC2P_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
	{
		string field;

		// Nessun validatore per IdCOA perche' e' una Combo Box

		field = (string)e.NewValues["Descrizione"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Descrizione' � obbligatorio");
			return;
		}
		e.NewValues["Descrizione"] = field;

		// Nessun validatore per TrattaPrec, TrattaSucc, Direzione perche' sono
		// Combo Box


		field = (string)e.NewValues["QmgrName"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'QmgrName' � obbligatorio");
			return;
		}
		e.NewValues["QmgrName"] = field;

		// Nessun validatore per CodiceStrada perche' e' una Combo Box

		field = (string)e.NewValues["Km"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Km' � obbligatorio");
			return;
		}

		e.NewValues["Km"] = field;
	}


	// controllo di validita` dei campi quando si fa l'inserimento di un nuovo record
	void dvC2P_ItemInserting(object sender, DetailsViewInsertEventArgs e)
	{
		string field;

		field = (string)e.Values["IdC2P"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Id C2P' � obbligatorio");
			return;
		}

		if (!base.dv_IsInteger(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Id C2P' deve essere un numero");
			return;
		}
		e.Values["IdC2P"] = field;

		// Nessun validatore per IdCOA perche' e' una Combo Box

		field = (string)e.Values["Descrizione"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Descrizione' � obbligatorio");
			return;
		}
		e.Values["Descrizione"] = field;

		// Nessun validatore per TrattaPrec, TrattaSucc, Direzione perche' sono
		// Combo Box


		field = (string)e.Values["QmgrName"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'QmgrName' � obbligatorio");
			return;
		}
		e.Values["QmgrName"] = field;

		// Nessun validatore per CodiceStrada perche' e' una Combo Box

		field = (string)e.Values["Km"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Km' � obbligatorio");
			return;
		}

		if (!base.dv_IsDouble(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo deve essere un numero");
			return;
		}
		e.Values["Km"] = field;

	}

}
