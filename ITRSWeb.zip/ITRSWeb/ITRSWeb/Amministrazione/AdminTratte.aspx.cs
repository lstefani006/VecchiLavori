using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Amministrazione_AdminTratte : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		// per gestire gli errori di aggiornamento del db e della details view
		base.WriteError += new WriteErrorDelegate(AdminTratte_WriteError);
		base.HandleError(this.gvTratte);
		base.HandleError(this.dvTratta);
		base.HandleError(this.odsTratte);
		base.HandleError(this.odsRowTratta);

		//////// imposta le freccette per il sort e
		//////// la manina e il doppio click per la selezione
		//////// nella grid view
		//////this.gvTratte.RowCreated += new GridViewRowEventHandler(base.gv_RowCreated);
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		// imposto il sort iniziale della grid view
		if (!IsPostBack)
			this.gvTratte.Sort("IdTratta", SortDirection.Ascending);

		if (this.lblError.EnableViewState == true)
			this.lblError.Text = "";

		// per gestire il controllo dei campi prima i fare insert/update (validazione)
		this.dvTratta.ItemInserting += new DetailsViewInsertEventHandler(dvTratta_ItemInserting);
		this.dvTratta.ItemUpdating += new DetailsViewUpdateEventHandler(dvTratta_ItemUpdating);


		// se ri-seleziono una riga gia` selezionata tolgo la selezione
		gvTratte.SelectedIndexChanging += new GridViewSelectEventHandler(gvTratte_SelectedIndexChanging);

		// la riga selezionata � cambiata: modifico il comportamento del detail view.
		gvTratte.SelectedIndexChanged += new EventHandler(gvTratte_SelectedIndexChanged);


		// per rinfrescare la griglia quando si inserisce/modifica/cancella
		// un record dal detail view
		dvTratta.ItemUpdated += new DetailsViewUpdatedEventHandler(dvTratta_ItemUpdated);
		dvTratta.ItemInserted += new DetailsViewInsertedEventHandler(dvTratta_ItemInserted);
		dvTratta.ItemDeleted += new DetailsViewDeletedEventHandler(dvTratta_ItemDeleted);
	}

	private void AdminTratte_WriteError(Exception ex)
	{
		this.lblError.ForeColor = System.Drawing.Color.Red;
		if (ex.InnerException == null)
			this.lblError.Text = ex.Message;
		else
			this.lblError.Text = ex.InnerException.Message;
	}
	void dvTratta_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
	{
		// se ho cancellato una riga ... costringo la grid view a riaggiornarsi
		gvTratte.SelectedIndex = -1;
		gvTratte.DataBind();

		// vado in insert mode nella datail view
		//if (gvTratte.Rows.Count == 0)
			this.dvTratta.ChangeMode(DetailsViewMode.Insert);

	}

	void dvTratta_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
	{
		// se ho inserito una riga ... costringo la grid view a riaggiornarsi
		gvTratte.SelectedIndex = -1;
		gvTratte.DataBind();
	}

	void dvTratta_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
	{
		// se ho aggiornato una riga ... costringo la grid view a riaggiornarsi
		gvTratte.SelectedIndex = -1;
		gvTratte.DataBind();
	}

	void gvTratte_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		// resetto la selezione corrente se clicco una seconda volta nella stessa riga della
		// grid view
		if (e.NewSelectedIndex == gvTratte.SelectedIndex)
			e.NewSelectedIndex = -1;
	}

	void gvTratte_SelectedIndexChanged(object sender, EventArgs e)
	{
		// se seleziono una riga nella grid view metto la detail view 
		// nella modalita` di visualizzazione (che poi consentira` di editare/cancella 
		// il record).
		// Se la grid view rimane senza selezione vado direttamente in edit-mode.
		if (gvTratte.SelectedIndex >= 0)
			this.dvTratta.ChangeMode(DetailsViewMode.ReadOnly);
		else
			this.dvTratta.ChangeMode(DetailsViewMode.Insert);

		this.dvTratta.DataBind();
	}


	// controllo di validita` dei campi quando si fa l'aggiornamento di un record
	void dvTratta_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
	{
		string field;

		// Nessun validatore per Direzione perche' e' una Combo Box

		field = (string)e.NewValues["TempoMinPercorrenzaSecondi"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Tempo Percorrenza' � obbligatorio");
			return;
		}

		if (!base.dv_IsInteger(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Tempo Percorrenza' deve essere un numero");
			return;
		}
		e.NewValues["TempoMinPercorrenzaSecondi"] = field;

		field = (string)e.NewValues["Descrizione"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Descrizione' � obbligatorio");
			return;
		}
		e.NewValues["Descrizione"] = field;

		// Nessun validatore per CodiceSTrada perche' e' una Combo Box

		field = (string)e.NewValues["LunghezzaKm"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Lunghezza' � obbligatorio");
			return;
		}

		if (!base.dv_IsDouble(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Lunghezza' deve essere un numero");
			return;
		}
		e.NewValues["LunghezzaKm"] = field;

	}

	// controllo di validita` dei campi quando si fa l'inserimento di un nuovo record
	void dvTratta_ItemInserting(object sender, DetailsViewInsertEventArgs e)
	{
		string field;

		field = (string)e.Values["IdTratta"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Id Tratta' � obbligatorio");
			return;
		}

		if (!base.dv_IsInteger(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Id Tratta' deve essere un numero");
			return;
		}
		e.Values["IdTratta"] = field;

		// Nessun validatore per Direzione perche' e' una Combo Box

		field = (string)e.Values["TempoMinPercorrenzaSecondi"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Tempo Percorrenza' � obbligatorio");
			return;
		}

		if (!base.dv_IsInteger(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Tempo Percorrenza' deve essere un numero");
			return;
		}
		e.Values["TempoMinPercorrenzaSecondi"] = field;

		field = (string)e.Values["Descrizione"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Descrizione' � obbligatorio");
			return;
		}
		e.Values["Descrizione"] = field;

		// Nessun validatore per CodiceStrada perche' e' una Combo Box

		field = (string)e.Values["LunghezzaKm"];
		if (!base.dv_CheckField(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Lunghezza' � obbligatorio");
			return;
		}

		if (!base.dv_IsDouble(ref field))
		{
			e.Cancel = true;
			base.lbl_WriteError(lblError, "Il campo 'Lunghezza' deve essere un numero");
			return;
		}
		e.Values["LunghezzaKm"] = field;

	}

}
