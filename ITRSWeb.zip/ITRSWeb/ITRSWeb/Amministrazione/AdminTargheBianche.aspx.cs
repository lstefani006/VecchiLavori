using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

using ITRS_BL;

public partial class Amministrazione_AdminTargheBianche : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		this.Page.RegisterRequiresControlState(this);
		this._id = new ControlState();

		this.PreRender += new EventHandler(Amministrazione_AdminTargheBianche_PreRender);

		try
		{
			List<ITRS_BL.BLLTSImport.Nazione> listaNazioni = BLCacher.GetListaNazioni();
			foreach (ITRS_BL.BLLTSImport.Nazione c in listaNazioni)
			{
				edit_ddlNazioni.Items.Add(new ListItem(c.Sigla_Nazione + " - " + c.Nome_Nazione, c.Sigla_Nazione));
			}
		}
		catch
		{
			lblError.Text = "Errore leggendo la lista delle nazioni.";
		}


		//					<asp:RequiredFieldValidator runat="server" ID="val_edit_Targa" ControlToValidate="edit_Targa"
		//						Display="Dynamic" ErrorMessage="Immettere la targa!" Text="Immettere una targa!" />

		RequiredFieldValidator v = new RequiredFieldValidator();
		v.ID = "val_edit_targa";
		v.Display = ValidatorDisplay.Dynamic;
		v.ErrorMessage = "Immettere la targa!";
		v.Text = "";
		v.EnableClientScript = true;
		edit_Targa.AddValidator(v);


		//RequiredFieldValidator v2 = new RequiredFieldValidator();
		//v2.ID = "val_edit_Descrizione";
		//v2.Display = ValidatorDisplay.Dynamic;
		//v2.ErrorMessage = "Immetere la descrizione!";
		//v2.Text = "Immettere la descrizione! 2";
		//v2.EnableClientScript = true;
		//edit_Descrizione.AddValidator(v2);
	}


	#region ControlState
	protected override object SaveControlState()
	{
		return _id;
	}
	protected override void LoadControlState(object state)
	{
		_id = state as ControlState;
	}

	[Serializable]
	class ControlState
	{
		public bool OnModify;
		public bool OnInsert;

		public string Selected_Targa;
		public string Selected_Nazionalita;
		public int Selected_IdLTS;
	}

	ControlState _id = null;
	#endregion


	protected void Page_Load(object sender, EventArgs e)
	{
		// imposto il sort iniziale della grid view
		if (!IsPostBack)
			this.gvTargheBianche.Sort("Targa", SortDirection.Ascending);

		// se ri-seleziono una riga gia` selezionata tolgo la selezione
		gvTargheBianche.SelectedIndexChanging += new GridViewSelectEventHandler(gvTargheBianche_SelectedIndexChanging);

		// la riga selezionata � cambiata: modifico il comportamento del detail view.
		gvTargheBianche.SelectedIndexChanged += new EventHandler(gvTargheBianche_SelectedIndexChanged);

		base.RegisterClientId("LTB", edit_DataInizioValidita, edit_DataFineValidita);

		if (!IsPostBack)
			this.edit_ddlNazioni.SelectedValue = "I";

		if (User.IsInRole("Gestione LTS Bianca") == false)
		{
			this.edit_btnNuovo.Enabled = false;
			this.btnExport.Enabled = false;
			this.btnImport.Enabled = false;
		}
	}


	void Amministrazione_AdminTargheBianche_PreRender(object sender, EventArgs e)
	{
		if (!(_id.OnInsert || _id.OnModify))
		{
			edit_DivEdit.Visible = false;
			return;
		}

		edit_DivEdit.Visible = true;

		if (_id.OnModify)
		{
			edit_Targa.ReadOnly = true;
			edit_ddlNazioni.ReadOnly = true;
		}

		if (_id.OnInsert)
		{
			edit_Targa.ReadOnly = false;
			edit_ddlNazioni.ReadOnly = false;

			edit_btnDelete.Visible = false;
		}
	}

	private new void WriteError(string message)
	{
		this.lblError.ForeColor = System.Drawing.Color.Red;
		this.lblError.Text = message;
	}


	protected void gvTargheBianche_OnSelectCount(object sender, ITRSControls.ExGridSelectCountEventArgs e)
	{
		try
		{
			ITRS_BL.BLTargheBianche bl = new ITRS_BL.BLTargheBianche();
			e.Count = bl.GetTargheBiancheCount();
		}
		catch
		{
			e.Count = 0;
		}
	}

	void gvTargheBianche_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		// resetto la selezione corrente se clicco una seconda volta nella stessa riga della
		// grid view
		if (e.NewSelectedIndex == gvTargheBianche.SelectedIndex)
			e.NewSelectedIndex = -1;
	}

	void gvTargheBianche_SelectedIndexChanged(object sender, EventArgs e)
	{

		if (User.IsInRole("Gestione LTS Bianca") == false)
			return;

			// se seleziono una riga nella grid view metto la detail view 
		// nella modalita` di visualizzazione (che poi consentira` di editare/cancella 
		// il record).
		// Se la grid view rimane senza selezione vado direttamente in edit-mode.
		if (gvTargheBianche.SelectedIndex >= 0)
		{
			_id.Selected_Targa = (string)gvTargheBianche.SelectedDataKey["Targa"];
			_id.Selected_Nazionalita = (string)gvTargheBianche.SelectedDataKey["Nazionalita"];
			_id.Selected_IdLTS = (int)gvTargheBianche.SelectedDataKey["IdLTS"];

			_id.OnModify = true;
			_id.OnInsert = false;


			ITRS_BL.BLTargheBianche bl = new ITRS_BL.BLTargheBianche();
			ITRS_BL.TargheBianche tb = bl.GetTargheBianche(_id.Selected_Targa, _id.Selected_Nazionalita, _id.Selected_IdLTS);

			edit_Targa.Text = tb.Targa;
			edit_ddlNazioni.SelectedValue = tb.Nazionalita;
			edit_Descrizione.Text = tb.Descrizione;
			edit_Motivo.Text = tb.Motivo;
			edit_DataInizioValidita.Text = tb.TsInizioValidita.ToString("d");
			edit_DataFineValidita.Text = tb.TsFineValidita.ToString("d");
		}
	}

	protected void edit_btnNuovo_Click(object sender, EventArgs e)
	{
		_id.OnInsert = true;
		_id.OnModify = false;

		edit_Targa.Text = "";
		edit_ddlNazioni.SelectedValue = "I";
		edit_DataInizioValidita.Text = DateTime.Now.Date.ToString("d");
		edit_Descrizione.Text = "";
		edit_Motivo.Text = "";
	}

	protected void edit_btnAnnulla_Click(object sender, EventArgs e)
	{
		_id.OnInsert = false;
		_id.OnModify = false;

		gvTargheBianche.SelectedIndex = -1;
	}

	protected void edit_btnSave_Click(object sender, EventArgs e)
	{
		try
		{
			ITRS_BL.BLTargheBianche bl = new ITRS_BL.BLTargheBianche();

			ITRS_BL.TargheBianche tb;
			if (_id.OnModify)
				tb = bl.GetTargheBianche(_id.Selected_Targa, _id.Selected_Nazionalita, _id.Selected_IdLTS);
			else
				tb = new ITRS_BL.TargheBianche();


			tb.TsInizioValidita = DateTime.Parse(edit_DataInizioValidita.Text);
			tb.TsFineValidita = DateTime.Parse(edit_DataFineValidita.Text);
			tb.Motivo = edit_Motivo.Text;
			tb.Descrizione = edit_Descrizione.Text;

			if (tb.TsInizioValidita > tb.TsFineValidita)
			{
				WriteError("La data di fine validita` deve essere maggiore della data di inizio validita`");
				return;
			}
			if (tb.TsFineValidita < DateTime.Now.Date)
			{
				WriteError("La data di fine validita` deve essere maggiore/uguale della data attuale");
				return;
			}


			if (_id.OnInsert)
			{
				string targa = edit_Targa.Text.ToUpper();
				string msg = ITRSUtility.ControllaTarga(ref targa, true);
				if (msg != null)
				{
					WriteError(msg);
					return;
				}

				tb.Targa = targa;
				tb.Nazionalita = edit_ddlNazioni.SelectedValue;

				bool inserito = bl.InserisciTargheBianche(tb);
				if (!inserito)
				{
					WriteError("Targa gia` presente nella lista bianca!");
					return;
				}

			}
			else
				bl.AggiornaTargheBianche(tb);


			if (_id.OnInsert)
				PageBase.AddUserActivity(TipoAttivita.LTB,
					"Inserimento in LTB Targa:{0} Nazionalita:{1} Descrizione:{2} InzioValidita`:{3} FineValidita`:{4}", tb.Targa, tb.Nazionalita, tb.Descrizione, tb.TsInizioValidita, tb.TsFineValidita);
			else
				PageBase.AddUserActivity(TipoAttivita.LTB,
					"Modifica in LTB Targa:{0} Nazionalita:{1} Descrizione:{2} InzioValidita`:{3} FineValidita`:{4}", tb.Targa, tb.Nazionalita, tb.Descrizione, tb.TsInizioValidita, tb.TsFineValidita);

			_id.OnInsert = false;
			_id.OnModify = false;

			gvTargheBianche.SelectedIndex = -1;
		}
		catch
		{
			WriteError("Errore salvando la targa");
		}
	}

	protected void edit_btnDelete_Click(object sender, EventArgs e)
	{
		try
		{
			ITRS_BL.BLTargheBianche bl = new ITRS_BL.BLTargheBianche();

			ITRS_BL.TargheBianche tb;
			tb = bl.GetTargheBianche(_id.Selected_Targa, _id.Selected_Nazionalita, _id.Selected_IdLTS);

			bl.CancellaTargheBianche(tb);

			PageBase.AddUserActivity(TipoAttivita.LTB,
				"Cancellazione da LTB Targa:{0} Nazionalita:{1} Descrizione:{2} InzioValidita`:{3} FineValidita`:{4}", tb.Targa, tb.Nazionalita, tb.Descrizione, tb.TsInizioValidita, tb.TsFineValidita);


			_id.OnInsert = false;
			_id.OnModify = false;

			gvTargheBianche.SelectedIndex = -1;

		}
		catch /*(Exception ex)*/
		{
			WriteError("Errore durante la cancellazione della targa");
		}
	}

	protected void btnExport_Click(object sender, EventArgs e)
	{
		ExportLTBData dd = new ExportLTBData();
		dd.fileName = string.Format("LTB_{0:yyyy}{0:MM}{0:dd}_{0:HH}{0:mm}{0:ss}.xml", DateTime.Now);
		dd.IdUtenteRichiedente = UserPkId;
		dd.IdCoa = ITRSUtility.GetCoaDiAppartenenza();
		if (dd.IdCoa < 0)
		{
			lblErrorExpImp.Text = "Attenzione! Solo un operatore con assegnato il COA di competenza puo` esportare i dati";
			return;
		}

		MemoryStream ms = new MemoryStream();
		BinaryFormatter bf = new BinaryFormatter();
		bf.Serialize(ms, dd);
		string gg = Convert.ToBase64String(ms.ToArray());
		dnlWindow.Attributes["src"] = "/ITRSWeb/DownloadGeneric.aspx?Action=" + gg;
	}

	protected void btnImport_Click(object sender, EventArgs e)
	{
		if (!fileUpload.HasFile)
		{
			lblErrorExpImp.Text = "Selezionare un file!";
			return;
		}

		int IdCoa = ITRSUtility.GetCoaDiAppartenenza();
		if (IdCoa < 0)
		{
			lblErrorExpImp.Text = "Attenzione! Solo un operatore con assegnato il COA di competenza puo` esportare i dati";
			return;
		}


		Byte[] fileContent = fileUpload.FileBytes;

		ITRS_BL.BLTargheBianche bl = new ITRS_BL.BLTargheBianche();
		List<string> err = bl.ImportTargheBianche(fileContent);

		if (err.Count > 0)
			PageBase.AddUserActivity(TipoAttivita.LTB, "Import in LTB: errori riscontrati: ", err.Count);
		else
			PageBase.AddUserActivity(TipoAttivita.LTB, "Import in LTB: operazione terminata con successo.");

		if (err.Count == 0)
		{
			lblErrorExpImp.Text = "Elaborazione terminata con successo.";
			return;
		}

		Repeater1.DataSource = err;
		Repeater1.DataBind();
	}
}
