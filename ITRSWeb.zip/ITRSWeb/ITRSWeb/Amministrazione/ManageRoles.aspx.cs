using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for ManageRoles
/// </summary>
public partial class ManageRoles : System.Web.UI.Page
{
	public ManageRoles()
	{
	}

	private string script = @"
	<script type='text/javascript' >
	var lbRoles;
	var btnDeleteSelected;
	var btnAddRole;
	var txtNewRole;
	var lbRolesSelected;

	function ManageRolesInit()
	{
		lbRoles = document.all['lbRoles'];
		btnDeleteSelected = document.all['btnDeleteSelected'];
		btnAddRole = document.all['btnAddRole'];
		txtNewRole = document.all['txtNewRole'];
		lbRolesSelected = document.all['lbRolesSelected'];

		if (lbRoles.selectedIndex == -1 || lbRoles.options.length == 0)
			btnDeleteSelected.disabled = true;
	}

	function lbRoles_OnChange()
	{
		btnDeleteSelected.disabled = false;
	}
	
	function btnAddRole_onclick()
	{
		var s = txtNewRole.value;
		if (s == '')
		{
			alert('Attenzione: inserire nuovo ruolo!');
			window.event.returnValue = false;
			return;
		}
		
		for (var i = 0; i < lbRoles.options.length; ++i)
			if (lbRoles.options[i].value == s)
			{
				alert('Attenzione: ruolo gia` presente!');
				window.event.returnValue = false;
				return;
			}
	}
	
	function btnDeleteSelected_onclick()
	{
		lbRolesSelected.value = lbRoles.options[lbRoles.selectedIndex].value;
		return true;
	}

	ManageRolesInit();
</script>
";

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!ClientScript.IsStartupScriptRegistered("ManageRolesInit"))
		{
			script = script.Replace("'lbRoles'", "'" + lbRoles.UniqueID + "'");
			script = script.Replace("'btnDeleteSelected'", "'" + btnDeleteSelected.UniqueID + "'");
			script = script.Replace("'btnAddRole'", "'" + btnAddRole.UniqueID + "'");
			script = script.Replace("'txtNewRole'", "'" + txtNewRole.UniqueID + "'");
			script = script.Replace("'lbRolesSelected'", "'" + lbRolesSelected.UniqueID + "'");

			ClientScript.RegisterStartupScript(typeof(Page), "ManageRolesInit", script);
		}

		lbRoles.Attributes["onChange"] = "lbRoles_OnChange()";

		if (!IsPostBack)
			lbRolesDataBind();
	}

	private void lbRolesDataBind()
	{
		lbRoles.DataSource = Roles.GetAllRoles();
		lbRoles.DataBind();
	}

	protected void btnDeleteSelected_Click(object sender, EventArgs e)
	{
		try
		{
			if (lbRolesSelected.Value.Length > 0)
			{
				Roles.DeleteRole(lbRolesSelected.Value);
			}
		}
		catch (Exception ex)
		{
			lblErrorDelete.Text = ex.Message;
		}
		lbRolesDataBind();
	}


	protected void btnAddRole_Click(object sender, EventArgs e)
	{
		try
		{
			string r = txtNewRole.Text.Trim();
			if (r.Length > 0)
			{
				Roles.CreateRole(r);
				lbRolesDataBind();
				txtNewRole.Text = string.Empty;
			}
		}
		catch (Exception ex)
		{
			lblErrorAdd.Text = ex.Message;
		}

		lbRolesDataBind();

	}
}
