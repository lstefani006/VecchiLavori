using System;
using System.Data;
using System.Configuration;
using System.Drawing;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using ITRS_BL;


/// <summary>
/// Summary description for ManageUserRoles
/// </summary>
public partial class ManageUser : System.Web.UI.Page
{
	protected void Page_Init(object sender, EventArgs e)
	{
		foreach (string p in ITRSUtility.GetProfileList())
		{
			ddProfili.Items.Add(new ListItem(p, p));
		}

		List<ITRS_BL.Coa> lstCoa = BLCacher.GetListaCOA();
		ddlCoa.Items.Add(new ListItem("<nessuno>", ""));
		foreach (ITRS_BL.Coa c in lstCoa)
		{
			ddlCoa.Items.Add(new ListItem(c.Descrizione, c.IdCOA.ToString()));
		}

		this.RegisterRequiresControlState(this);
	}


	#region ControlState
	protected override object SaveControlState()
	{
		return _id;
	}
	protected override void LoadControlState(object state)
	{
		_id = state as ControlState;
	}

	[Serializable]
	class ControlState
	{
		public ControlState()
		{
			EditVisibile = false;
		}

		public bool EditVisibile;
	}
	ControlState _id = null;
	#endregion


	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
			_id = new ControlState();
		else
			this.divUtenteSelezionato.Visible = _id.EditVisibile;
	}

	protected void gvListaUtenti_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (gvListaUtenti.SelectedIndex < 0)
		{
			divUtenteSelezionato.Visible = false;
			_id.EditVisibile = false;
			return;
		}

		divUtenteSelezionato.Visible = true;
		_id.EditVisibile = true;


		string us = (string)gvListaUtenti.SelectedDataKey["UserName"];

		MembershipUser mu = Membership.GetUser(us, false);
		ckApprovato.Checked = mu.IsApproved;
		txNomeUtente.Text = mu.UserName;
		txNote.Text = mu.Comment;
		txEmail.Text = mu.Email;
		ddProfili.SelectedValue = (mu as MembershipUserWithProfile).UserProfile;
		ddlCoa.SelectedValue = (mu as MembershipUserWithProfile).IdCoaDiCompetenza.ToString();

		if (mu.IsLockedOut)
			btnUnlock.Enabled = true;
		else
			btnUnlock.Enabled = false;
	}

	protected string W(object e)
	{
		if (e == null) return "";
		if (true)
		{
			DateTime t = (DateTime)e;
			if (t == new DateTime(2000, 1, 1))
				return "";
		}
		return e.ToString();
	}

	protected void btnCancella_Click(object sender, EventArgs e)
	{
		if (gvListaUtenti.SelectedIndex < 0)
		{
			divUtenteSelezionato.Visible = false;
			_id.EditVisibile = false;
			return;
		}

		string us = (string)gvListaUtenti.SelectedDataKey["UserName"];

		MembershipUser mu = Membership.GetUser(us, false);

		bool ok = Membership.DeleteUser(us);

		if (!ok)
		{
			txError.Text = "Non e` possibile cancellare l'operatore dal data base, si puo` solo deselezionare Approvato";
			return;
		}

		divUtenteSelezionato.Visible = false;
		gvListaUtenti.SelectedIndex = -1;
		_id.EditVisibile = false;

		PageBase.AddUserActivity(
	TipoAttivita.AmministrazioneUtenti,
	"Cancellazione utente:'{0}' ",
	mu.UserName);
	}
	protected void btnSalva_Click(object sender, EventArgs e)
	{
		if (gvListaUtenti.SelectedIndex < 0)
		{
			divUtenteSelezionato.Visible = false;
			_id.EditVisibile = false;

			return;
		}

		string us = (string)gvListaUtenti.SelectedDataKey["UserName"];

		MembershipUser mu = Membership.GetUser(us, false);

		bool cambiato = false;

		string attivita = "";

		if (ckApprovato.Checked != mu.IsApproved)
		{
			mu.IsApproved = ckApprovato.Checked;
			cambiato = true;

			if (mu.IsApproved)
				attivita += "Approvato,";
			else
				attivita += "Non approvato,";
		}

		if (mu.Comment != txNote.Text)
		{
			mu.Comment = txNote.Text;
			cambiato = true;

			attivita += "Note,";
		}

		if (mu.Email != txEmail.Text)
		{
			mu.Email = txEmail.Text;
			cambiato = true;

			attivita += "Email,";
		}

		if (txPassword.Text.Length > 0 || txPasswordConferma.Text.Length > 0)
		{
			string errMsg = ITRSUtility.ControllaPassword(txPassword.Text, txPasswordConferma.Text, null);
			if (!string.IsNullOrEmpty(errMsg))
			{
				txError.Text = errMsg;
				txError.ForeColor = Color.Red;
				return;
			}
		}

		if (cambiato)
			Membership.UpdateUser(mu);

		if (ddProfili.SelectedValue != (mu as MembershipUserWithProfile).UserProfile)
		{
			OracleMembershipProvider mo = Membership.Provider as OracleMembershipProvider;
			mo.ChangeUserProfile(mu.UserName, ddProfili.SelectedValue);

			attivita += "Profilo,";
			cambiato = true;
		}

		if (txPassword.Text.Length > 0 || txPasswordConferma.Text.Length > 0)
		{
			OracleMembershipProvider mo = Membership.Provider as OracleMembershipProvider;
			mo.ChangePassword(mu.UserName, txPassword.Text);

			attivita += "Password,";
			cambiato = true;
		}


		string coa = (mu as MembershipUserWithProfile).IdCoaDiCompetenza.ToString();
		if (ddlCoa.SelectedValue != coa)
		{
			OracleMembershipProvider mo = Membership.Provider as OracleMembershipProvider;
			int? idCoaDiCompetenza = null;
			if (ddlCoa.SelectedValue.Length > 0)
				idCoaDiCompetenza = Int32.Parse(ddlCoa.SelectedValue);
			mo.ChangeIdCoaDiCompetenza(mu.UserName, idCoaDiCompetenza);

			attivita += "COA";
			cambiato = true;
		}



		divUtenteSelezionato.Visible = false;
		_id.EditVisibile = false;
		gvListaUtenti.SelectedIndex = -1;


		if (cambiato)
		{
			PageBase.AddUserActivity(
				TipoAttivita.AmministrazioneUtenti,
				"Modifica utente:'{0}' modifiche:" + attivita,
				mu.UserName);
		}
	}
	protected void gvListaUtenti_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		if (e.NewSelectedIndex == gvListaUtenti.SelectedIndex)
		{
			e.NewSelectedIndex = -1;
			divUtenteSelezionato.Visible = false;
			_id.EditVisibile = false;

		}
	}
	protected void gvListaUtenti_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			MembershipUserWithProfile us = (MembershipUserWithProfile)e.Row.DataItem;

			if (us.IdCoaDiCompetenza.HasValue)
				e.Row.Cells[gvListaUtenti.GetCellIndex("IdCoaDiCompetenza")].Text = BLCacher.GetDescrizioneCOA(us.IdCoaDiCompetenza.Value);
			else
				e.Row.Cells[gvListaUtenti.GetCellIndex("IdCoaDiCompetenza")].Text = "";
		}

	}
	protected void btnUnlock_Click(object sender, EventArgs e)
	{
		if (gvListaUtenti.SelectedIndex < 0)
		{
			divUtenteSelezionato.Visible = false;
			_id.EditVisibile = false;
			return;
		}

		string us = (string)gvListaUtenti.SelectedDataKey["UserName"];

		MembershipUser mu = Membership.GetUser(us, false);
		bool ok = mu.UnlockUser();

		this.txError.Text = "Utente sbloccato";
		this.btnUnlock.Enabled = false;


		PageBase.AddUserActivity(
			TipoAttivita.AmministrazioneUtenti,
			"Unlock utente:'{0}'",
			mu.UserName);

	}
}
