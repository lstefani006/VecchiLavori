using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using System.ComponentModel;
using ITRS_BL;

public partial class Dettaglio_Transito : System.Web.UI.UserControl
{

	/// <summary>
	/// Flag per visualizzare le due righe iniziali "Targa: Nazionalita`":
	/// Questa proprieta` non e` memorizzata ne` nel ViewState ne` nel ControlState, per cui
	/// deve essere impostata nella pagina .aspx o o nella fase Init (Page_Init, OnInit ecc)
	/// </summary>
	[Bindable(true), Category("Behavior"), DefaultValue("true")]
	public bool ShowTargaNazionalita
	{
		get { return _ShowTargaNazionalita; }
		set { _ShowTargaNazionalita = value; }
	}
	bool _ShowTargaNazionalita = true;


	//#region evento CambioStato
	//[Serializable]
	//public class CambioStatoEvent : EventArgs
	//{
	//    public CambioStatoEvent(string targa, string nazionalita, DateTime dataOraRilevamento, StatoTransito statoTransito)
	//    {
	//        this.Targa = targa;
	//        this.Nazionalita = nazionalita;
	//        this.DataOraRilevamento = dataOraRilevamento;
	//        this.StatoTransito = statoTransito;
	//    }
	//    public readonly string Targa;
	//    public readonly string Nazionalita;
	//    public readonly DateTime DataOraRilevamento;
	//    public readonly StatoTransito StatoTransito;
	//}
	//public delegate void CambioStatoDelegate(object sender, CambioStatoEvent e);
	//public event CambioStatoDelegate CambioStato;
	//#endregion

	#region ControlState
	protected override object SaveControlState() { return _id; }
	protected override void LoadControlState(object state) { _id = state as DatiTransito; }

	[Serializable]
	class DatiTransito
	{
		public DatiTransito()
		{
			targa = string.Empty;
			nazionalita = string.Empty;
			dataOraRilevamento = DateTime.MinValue;
			premutoLinkPresoInCarico = false;
		}
		public string targa;
		public string nazionalita;
		public DateTime dataOraRilevamento;
		public bool premutoLinkPresoInCarico;
	}
	DatiTransito _id = null;
	#endregion

	#region Visualizza nascondi transito
	public void VisualizzaTS(string targa, string nazionalita, DateTime dataOraRilevamento)
	{
		_id = new DatiTransito();
		_id.targa = targa;
		_id.nazionalita = nazionalita;
		_id.dataOraRilevamento = dataOraRilevamento;

		this.Visible = true;
	}

	public void NascondiTS()
	{
		this.Visible = false;
		this._id = null;
	}
	#endregion

	protected override void OnInit(EventArgs e)
	{
		this.Page.RegisterRequiresControlState(this);
		base.OnInit(e);

		this.PreRender += new EventHandler(DettaglioTransito_DettTransito_PreRender);
		int n = 0;
		foreach (ListItem r in this.rblStatoTR.Items)
			r.Attributes["onclick"] = string.Format("VisualizzaNoteTR({0});", n++);


		try
		{
			List<ITRS_BL.BLLTSImport.Nazione> listaNazioni = BLCacher.GetListaNazioni();
			foreach (ITRS_BL.BLLTSImport.Nazione c in listaNazioni)
			{
				this.ddlNazionalitaRiconosciutaDallOperatore.Items.Add(new ListItem(c.Sigla_Nazione + " - " + c.Nome_Nazione, c.Sigla_Nazione));
			}
		}
		catch
		{
			lblError.Text = "Errore leggendo la lista delle nazioni.";
		}

	}

	public bool ExportTransitoVisible
	{
		get { return lnkExportTR.Visible; }
		set { lnkExportTR.Visible = value; }
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsCallback)
		{
			PageBase pb = (PageBase)this.Page;

			pb.RegisterClientId("T1", lblNoteTR, tbNoteTR, trPresaInCarico1_1, trPresaInCarico1_2);

			if (!this.Page.ClientScript.IsClientScriptBlockRegistered("TR"))
			{
				string s = @"
function VisualizzaNoteTR(n) 
{
	// 0 Riconosciuto
	// 1 Non riconosciuto
	// 2 Esci da presa in carico

	if (n == 0 || n == 1)
	{
		T1.lblNoteTR().style.visibility = 'visible';
		T1.tbNoteTR().style.visibility = 'visible';
	}
	else
	{
		T1.lblNoteTR().style.visibility = 'hidden';
		T1.tbNoteTR().style.visibility = 'hidden';
	}

	if (n == 0)
	{
		T1.trPresaInCarico1_1().style.visibility = 'visible';
		T1.trPresaInCarico1_2().style.visibility = 'visible';
	}
	else
	{
		T1.trPresaInCarico1_1().style.visibility = 'hidden';
		T1.trPresaInCarico1_2().style.visibility = 'hidden';
	}

} ";
				this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "TR", s, true);
			}
		}
	}

	bool TransitoValidatoConCambioTarga(ITRS_BL.DatiTransito t)
	{
		// se e` ancora da Validare o in Validazione il tr non ha subito un cambio targa.
		if (t.StatoTransito != StatoTransito.RIC)
			return false;

		// se nella targa c'e` un ~ il tr non ha subito un cambio targa.
		if (t.Targa.StartsWith("~"))
			return false;

		if (t.Targa != t.TargaAcquisita || t.Nazionalita != t.NazionalitaAcquisita)
			return true;

		return false;
	}

	bool TransitoDaValidare(ITRS_BL.DatiTransito t)
	{
		return t.StatoTransito == StatoTransito.PIC;
	}

	void DettaglioTransito_DettTransito_PreRender(object sender, EventArgs e)
	{
		if (this.Visible == false || _id == null)
		{
			this.Visible = false;
			return;
		}

		this.lblDataOraRilevamento.Text = ITRSUtility.PrintDataOra(_id.dataOraRilevamento);

		// qui leggo dalla tabella TRANSITI o dalla tabella TRANSITISUEVENTO
		using (BLTransiti bl = new BLTransiti())
		{
			ITRS_BL.DatiTransito t = bl.GetDatiTransitoOrTransitoSuEvento(_id.targa, _id.nazionalita, _id.dataOraRilevamento);
			if (t == null)
				return;

			// prime 2 righe di targa/nazionalita.
			// Rappresentano la targa acquisita prima dell'eventuale Validazione manuale con una nuova targa
			if (_ShowTargaNazionalita)
			{
				if (this.TransitoValidatoConCambioTarga(t))
				{
					this.lblTarga.Text = t.Targa;
					this.lblNazionalita.Text = t.Nazionalita;
				}
				else
				{
					this.lblTarga.Text = t.TargaAcquisita;
					this.lblNazionalita.Text = t.Nazionalita;
				}
			}
			else
			{
				this.tbTransito.Rows.Remove(this.trTargaNaz1);
				this.tbTransito.Rows.Remove(this.trTargaNaz2);
			}

			// seconde 2 righe di targa/naz
			if (this.TransitoValidatoConCambioTarga(t))
			{
				this.lblTargaAcquisita.Text = t.TargaAcquisita;
				this.lblNazionalitaAcquisita.Text = t.NazionalitaAcquisita;
			}
			else
			{
				this.tbTransito.Rows.Remove(this.trTargaAcquisita);
				this.tbTransito.Rows.Remove(this.trNazionalitaAcquisita);
			}

			this.lblStrada.Text = t.CodiceStrada;
			this.lblDirezioneC2P.Text = ITRSUtility.Translate(t.DirezioneC2P);
			this.lblDescrizioneC2P.Text = t.DescrizioneC2P;

			if (t.Latitudine == null)
			{
				this.tbTransito.Rows.Remove(this.trTransitoMobile1);
				this.tbTransito.Rows.Remove(this.trTransitoMobile2);
				this.tbTransito.Rows.Remove(this.trTransitoMobile3);
			}
			else
			{
				this.tbTransito.Rows.Remove(this.trTransitoFisso1);
				this.tbTransito.Rows.Remove(this.trTransitoFisso2);
				this.tbTransito.Rows.Remove(this.trTransitoFisso3);
				this.tbTransito.Rows.Remove(this.trTransitoFisso4);
			}

			if (Roles.IsUserInRole("Gestione transiti"))
			{
				if (t.StatoTransito == StatoTransito.DARIC ||
					(t.StatoTransito == StatoTransito.PIC && Page.User.Identity.Name == t.UtentePresaInCarico))
					this.lnkPresaInCaricoTR.Visible = true;
				else
					this.lnkPresaInCaricoTR.Visible = false;
			}
			else
				this.lnkPresaInCaricoTR.Visible = false;


			if (_id.premutoLinkPresoInCarico)
			{
				this.lnkPresaInCaricoTR.Enabled = false;
			}
			else
			{
				tbTransito.Rows.Remove(this.trPresaInCarico0);
				tbTransito.Rows.Remove(this.trPresaInCarico1);

				// se sono gia` state rimosse NON mi pianto
				try
				{
					tbTransito.Rows.Remove(this.trPresaInCarico1_1);
					tbTransito.Rows.Remove(this.trPresaInCarico1_2);
				}
				catch { }

				tbTransito.Rows.Remove(this.trPresaInCarico2);
				tbTransito.Rows.Remove(this.trPresaInCarico3);
				tbTransito.Rows.Remove(this.trPresaInCarico4);
			}



			this.lblStatoTransito.Text = ITRSUtility.Translate(t.StatoTransito);
			this.lblEnumTipoVarco.Text = ITRSUtility.Translate(t.TipoVarco);
			this.lblUtentePresaInCaricoTR.Text = t.UtentePresaInCarico == null ? "" : t.UtentePresaInCarico;
			this.lblDataOraPresaInCaricoTR.Text = ITRSUtility.PrintDataOra(t.DataOraPresaInCarico);
			this.lblDataOraChiusuraTR.Text = ITRSUtility.PrintDataOra(t.DataOraChiusura);
			this.lblNoteChiusuraTR.Text = t.NoteChiusura == null ? "" : t.NoteChiusura;


			// righe per il cambio targa.
			if (this.TransitoDaValidare(t) == false)
			{
				tbTransito.Rows.Remove(this.trPresaInCarico1_1);
				tbTransito.Rows.Remove(this.trPresaInCarico1_2);
			}
		}
	}

	protected void lnkPresaInCaricoTR_Click(object sender, EventArgs e)
	{
		using (BLTransiti blTransiti = new BLTransiti())
		{
			ITRS_BL.DatiTransito tr = blTransiti.GetDatiTransitoOrTransitoSuEvento(
				this._id.targa,
				this._id.nazionalita,
				this._id.dataOraRilevamento);
			if (tr == null)
				return;

			PageBase.AddUserActivity(TipoAttivita.Transito, "Presa in carico del transito Targa:{0} Nazionalita:{1} Rilevato:{2}", this._id.targa, this._id.nazionalita, this._id.dataOraRilevamento.ToString("G"));

			if (tr != null && tr.StatoTransito == StatoTransito.DARIC)
			{
				BLQueueJobs blq = new BLQueueJobs();
				string UserPkId = blq.GetUserPkId(Page.User.Identity.Name);

				blTransiti.PrendiInCarico(_id.targa, _id.nazionalita, _id.dataOraRilevamento, UserPkId);

				_id.premutoLinkPresoInCarico = true;
				try
				{
					if (tr.NazionalitaAcquisita != "?")
					{
						this.tbTargaRiconosciutaDallOperatore.Text = tr.TargaAcquisita;
						this.ddlNazionalitaRiconosciutaDallOperatore.SelectedValue = tr.NazionalitaAcquisita;
					}
					else
					{
						this.ddlNazionalitaRiconosciutaDallOperatore.SelectedValue = "I";
					}
				}
				catch
				{
				}
			}
			else if (tr != null && tr.StatoTransito == StatoTransito.PIC && tr.UtentePresaInCarico == Page.User.Identity.Name)
			{
				_id.premutoLinkPresoInCarico = true;
				try
				{
					this.tbTargaRiconosciutaDallOperatore.Text = tr.TargaAcquisita;
					this.ddlNazionalitaRiconosciutaDallOperatore.SelectedValue = tr.NazionalitaAcquisita;
				}
				catch
				{
				}
			}
			else
			{
				// errore non si puo` piu` prenderlo in carico xche qualcun altro l'ha preso o non esiste piu`
				lblError.Text = "Impossibile prendere in carico il transito.";
				lblError.Visible = true;
				return;
			}
		}
	}

	protected void btnOkTR_Click(object sender, EventArgs e)
	{
		using (BLTransiti bl = new BLTransiti())
		{
			ITRS_BL.DatiTransito t = bl.GetDatiTransitoOrTransitoSuEvento(_id.targa, _id.nazionalita, _id.dataOraRilevamento);
			if (t == null) // LEO non dovrebbe succedere ... ma in debug ci sono finito
				return;

			switch (rblStatoTR.SelectedIndex)
			{
			case 0: // RIC
				{
					// Se riconosce (valida) il transito DEVE 
					// 1) o confermare la targa
					// 2) o cambiarla.
					// Ma la targa CI DEVE ESSERE.

					string targaRiconosciutaDallOperatore = tbTargaRiconosciutaDallOperatore.Text.Replace(" ", "").ToUpper();
					//string nazioneRiconosciutaDallOperatore = tbNazionalitaRiconosciutaDallOperatore.Text.Replace(" ", "").ToUpper();
					string nazioneRiconosciutaDallOperatore = this.ddlNazionalitaRiconosciutaDallOperatore.SelectedValue;

					string msg = ITRSUtility.ControllaTarga(ref targaRiconosciutaDallOperatore, true);
					if (msg != null)
					{
						lblError.Text = msg;
						lblError.Visible = true;
						return;
					}
					msg = ITRSUtility.ControllaNazionalita(ref nazioneRiconosciutaDallOperatore, true);
					if (msg != null)
					{
						lblError.Text = msg;
						lblError.Visible = true;
						return;
					}

					string note = tbNoteTR.Text;
					StatoTransito nuovoStato = StatoTransito.RIC;

					// controlli finiti : ora passo alla modifica del DB

					bl.AzioneSuPresaInCarico(_id.targa, _id.nazionalita, _id.dataOraRilevamento,
						nuovoStato, note,
						targaRiconosciutaDallOperatore, nazioneRiconosciutaDallOperatore);

					// comunque sia esco dallo stato di premuto link di presa in carico
					_id.premutoLinkPresoInCarico = false;

					if (t.Targa != targaRiconosciutaDallOperatore || t.Nazionalita != nazioneRiconosciutaDallOperatore)
					{
						PageBase.AddUserActivity(TipoAttivita.Transito, "Cambio stato del transito Targa:{0} Nazionalita:{1} Rilevato:{2} Nuovo stato:{3} Targa val:{4} Naz. val:{5}", this._id.targa, this._id.nazionalita, this._id.dataOraRilevamento.ToString("G"), nuovoStato, targaRiconosciutaDallOperatore, nazioneRiconosciutaDallOperatore);

						// VisualizzaTS(targaRiconosciutaDallOperatore, nazioneRiconosciutaDallOperatore, t.DataOraRilevamento);

						//if (CambioStato != null)
						//    CambioStato(this, new CambioStatoEvent(_id.targa, _id.nazionalita, _id.dataOraRilevamento, nuovoStato));
					}
					else
						PageBase.AddUserActivity(TipoAttivita.Transito, "Cambio stato del transito Targa:{0} Nazionalita:{1} Rilevato:{2} Nuovo stato:{3}", this._id.targa, this._id.nazionalita, this._id.dataOraRilevamento.ToString("G"), nuovoStato);
				}
				break;

			case 1: // NORIC
				{
					StatoTransito nuovoStato = StatoTransito.NORIC;
					string note = tbNoteTR.Text;
					bl.AzioneSuPresaInCarico(_id.targa, _id.nazionalita, _id.dataOraRilevamento, nuovoStato, note, null, null);
					PageBase.AddUserActivity(TipoAttivita.Transito, "Cambio stato del transito Targa:{0} Nazionalita:{1} Rilevato:{2} Nuovo stato:{3}", this._id.targa, this._id.nazionalita, this._id.dataOraRilevamento.ToString("G"), nuovoStato);

					_id.premutoLinkPresoInCarico = false;
				}
				break;

			case 2: // DARIC
				{
					StatoTransito nuovoStato = StatoTransito.DARIC;
					string note = "";
					bl.AzioneSuPresaInCarico(_id.targa, _id.nazionalita, _id.dataOraRilevamento, nuovoStato, note, null, null);
					PageBase.AddUserActivity(TipoAttivita.Transito, "Cambio stato del transito Targa:{0} Nazionalita:{1} Rilevato:{2} Nuovo stato:{3}", this._id.targa, this._id.nazionalita, this._id.dataOraRilevamento.ToString("G"), nuovoStato);
					_id.premutoLinkPresoInCarico = false;
				}
				break;
			}

			//if (CambioStato != null)
			//    CambioStato(this, new CambioStatoEvent(_id.targa, _id.nazionalita, _id.dataOraRilevamento, nuovoStato));
		}
	}

	protected void btnEsciDaPresaInCarico_Click(object sender, EventArgs e)
	{
		using (BLTransiti bl = new BLTransiti())
		{
			ITRS_BL.DatiTransito t = bl.GetDatiTransitoOrTransitoSuEvento(_id.targa, _id.nazionalita, _id.dataOraRilevamento);
			if (t == null) // LEO non dovrebbe succedere ... ma in debug ci sono finito
				return;

			StatoTransito nuovoStato = StatoTransito.DARIC;
			string note = "";
			bl.AzioneSuPresaInCarico(_id.targa, _id.nazionalita, _id.dataOraRilevamento, nuovoStato, note, null, null);
			PageBase.AddUserActivity(TipoAttivita.Transito, "Cambio stato del transito Targa:{0} Nazionalita:{1} Rilevato:{2} Nuovo stato:{3}", this._id.targa, this._id.nazionalita, this._id.dataOraRilevamento.ToString("G"), nuovoStato);
			_id.premutoLinkPresoInCarico = false;
		}
	}

	/*private static string ControllaTarga(string targa)
	{
		foreach (char c in targa)
		{
			if (!(c >= 'A' && c <= 'Z' || c >= '0' && c <= '9'))
			{
				return "La targa puo` contenere solo caratteri A-Z 0-9";
			}
		}

		if (targa.Length < 5)
			return "Targa troppo corta";

		return null;
	}
	private static string ControllaNazione(string nazione)
	{
		foreach (char c in nazione)
			if (!(c >= 'A' && c <= 'Z'))
				return "La nazione puo` contenere solo caratteri A-Z";

		return null;
	}*/


	protected void lnkExportTR_Click(object sender, EventArgs e)
	{
		ExportTransitoEvent ev = new ExportTransitoEvent(_id.targa, _id.nazionalita, _id.dataOraRilevamento);
		if (ExportTransito != null)
			ExportTransito(this, ev);
	}

	#region evento ExportTransito
	[Serializable]
	public class ExportTransitoEvent : EventArgs
	{
		public ExportTransitoEvent(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			this.Targa = targa;
			this.Nazionalita = nazionalita;
			this.DataOraRilevamento = dataOraRilevamento;
		}

		public readonly string Targa;
		public readonly string Nazionalita;
		public readonly DateTime DataOraRilevamento;
	}

	public delegate void ExportTransitoDelegate(object sender, ExportTransitoEvent e);

	public event ExportTransitoDelegate ExportTransito;
	#endregion

}
