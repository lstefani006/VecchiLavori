﻿var transito_ua = navigator.userAgent.toLowerCase();
var transito_isIE = (transito_ua.indexOf('msie') != -1 && !this.isOpera && (transito_ua.indexOf('webtv') == -1) );

// serve per capire se e` la prima volta che viene invocato un comando sulla mappa.
var transito_firstMap = true;

function mapCmd(c)
{
    try
    {
	    if (transito_firstMap)
	    {
		    // attacco l'evento solo al primo comando. Altrimenti
		    // per ragioni inspiegabili fa boom.
		    transito_firstMap = false;
		    foto.imgMap().onreadystatechange = mapOnReadyStateChanged;
	    }

	    //	ZoomIn = 0;
	    //	ZoomOut = 1,
	    //	PanNorth = 2,
	    //	PanNorthEast = 3,
	    //	PanEast = 4,
	    //	PanSouthEast = 5,
	    //	PanSouth = 6,
	    //	PanSouthWest = 7,
	    //	PanWest = 8,
	    //	PanNorthWest = 9

	    var msg = foto.hfDatiImmagine().value;
	    var dt = new ClientState(msg);
	    dt.mCmds += c;
	    foto.hfDatiImmagine().value = dt.Write();
    	
	    var u = "/ITRSWeb/Handler/MapHandler.ashx?";
	    u += "lat=" + dt.mLat;
	    u +="&lon=" + dt.mLon;
	    u +="&alt=" + dt.mAlt;
	    u +="&steps=" + dt.mCmds;
    	
	    mapDisabilitaBottoni("rrrr"); // basta che non sia "complete"
	    foto.imgMap().src = u;
	}
	catch (eeee)
	{
	}
	
	return false;
}

function mapDisabilitaBottoni(r)
{
    try
    {
	    // abilito/disabilito i controlli
	    // sulla mappa in modo da
	    // renderli non utilizzabili quando la mappa sta 
	    // caricando.
    	
	    var a = new Array();
	    a[0] = foto.mapZoomIn();
	    a[1] = foto.mapZoomOut();
	    a[2] = foto.mapPanNorthWest();
	    a[3] = foto.mapPanNorth();
	    a[4] = foto.mapPanNorthEast();
	    a[5] = foto.mapPanWest();
	    a[6] = foto.mapPanEast();
	    a[7] = foto.mapPanSouthWest();
	    a[8] = foto.mapPanSouth();
	    a[9] = foto.mapPanSouthEast();
    	
	    for (var c = 0; c < a.length; c++)
	    {
		    var btn = a[c];
		    if (r == "complete")
		    {
			    btn.disabled = false;
			    btn.style.cursor = 'auto';
		    }
		    else
		    {
			    btn.disabled = true;
			    btn.style.cursor = 'wait';
		    }
	    }
    	
	    if (r == "complete")
		    foto.imgMap().style.cursor = 'auto';
	    else
		    foto.imgMap().style.cursor = 'wait';
	}
	catch(eeeer)
	{
	}
}

function mapOnReadyStateChanged()
{
    try
    {
	    // abilito/disabilito i controlli
	    // sulla mappa in modo da
	    // renderli non utilizzabili quando la mappa sta 
	    // caricando.
    	
	    var r = event.srcElement.readyState;
	    mapDisabilitaBottoni(r);
	}
	catch (eeeee)
	{
	}
}

function mapPanIE()
{
	try
	{
		var c = "C(" + window.event.offsetX + "," + window.event.offsetY + ")";
		mapCmd(c);
		//alert(c);
		
		return false;
	}
	catch (e)
	{
		//alert(e);
		return false;
	}
}

function mapPanFF(event)
{
	try
	{
		var img = foto.imgMap();

		var offImg = new Object();
		offImg.x = 0;
		offImg.y = 0;
		offsetImgFF(offImg, img)

		var x = event.pageX - offImg.x;
		var y = event.pageY - offImg.y;
		
		var c = "C(" + x + "," + y + ")";
		mapCmd(c);

		return false;
	}
	catch (e)
	{
		//alert(e);
		return false;
	}
}

//////////////////////////////////////////////////////////////

var firstTransito = true;

function imgTransitoOnReadyStateChanged()
{
    try
    {
	    var a = new Array();
	    a[0] = foto.btnZoomIn();
	    a[1] = foto.btnZoomOut();
	    a[2] = foto.cntDw();
	    a[3] = foto.cntUp();
	    a[4] = foto.lumDw();
	    a[5] = foto.lumUp();
	    a[6] = foto.btnReset();
    	
	    var r = event.srcElement.readyState;
    	
	    for (var c = 0; c < a.length; c++)
	    {
		    var btn = a[c];
		    if (r == "complete")
		    {
			    btn.disabled = false;
			    btn.style.cursor = 'auto';
		    }
		    else
		    {
			    btn.disabled = true;
			    btn.style.cursor = 'wait';
		    }
	    }
    	
	    if (r == "complete")
		    foto.imgTransito().style.cursor = 'crosshair';
	    else
		    foto.imgTransito().style.cursor = 'wait';
	}
	catch (eeeeer)
	{
	}
}

	
function zoom(k)
{
    try
    {
	    var msg = foto.hfDatiImmagine().value;
	    var dt = new ClientState(msg);
	    dt.z *= k;
	    foto.hfDatiImmagine().value = dt.Write();
	    GetImage(dt);
	}
	catch (wwewew)
	{
	}		
	return false;
}

function cnt(k)
{
    try
    {
	    var msg = foto.hfDatiImmagine().value;
	    var dt = new ClientState(msg);
	    dt.cnt *= k;
	    foto.hfDatiImmagine().value = dt.Write();
	    GetImage(dt);
	    GetImageTarga(dt);
	}
	catch (uyuyu)
	{
	}		
	return false;
}

function lum(k)
{
    try
    {
	    var msg = foto.hfDatiImmagine().value;
	    var dt = new ClientState(msg);
	    dt.lum += k;
	    foto.hfDatiImmagine().value = dt.Write();
	    GetImage(dt);
	    GetImageTarga(dt);
	}
	catch (uyuyu)
	{
	}		
	return false;
}

function resetLunCntZoom()
{
    try
    {
	    var msg = foto.hfDatiImmagine().value;
	    var dt = new ClientState(msg);
	    dt.cnt = 1.0;
	    dt.lum = 0.0;
	    dt.x = 0.0;
	    dt.y = 0.0;
	    dt.z = 1.0;
    	
	    foto.hfDatiImmagine().value = dt.Write();
	    GetImage(dt);
	    GetImageTarga(dt);
	}
	catch (gfggfgf)
	{
	}		
	return false;
}

function offsetImgFF(r, c)
{
    try
    {
	    if (c.localName == "BODY")
		    return;
    		
	    r.x += c.offsetLeft;
	    r.y += c.offsetTop;
    	
	    offsetImgFF(r, c.offsetParent);
	}
	catch (yhgtytt)
	{
	}
	
}

function panFF(event)
{
	try
	{
		var msg = foto.hfDatiImmagine().value;
		var dt = new ClientState(msg);
		
		var img = foto.imgTransito();

		var cx = img.width / 2;
		var cy = img.height / 2;
		
		var offImg = new Object();
		offImg.x = 0;
		offImg.y = 0;
		offsetImgFF(offImg, img)
		

		var x = event.pageX - offImg.x;
		var y = event.pageY - offImg.y;
		
		dt.x = dt.s * (x - cx) * dt.z + dt.x;
		dt.y = dt.s * (y - cy) * dt.z + dt.y;
		
		foto.hfDatiImmagine().value = dt.Write();

		GetImage(dt);		
		
		return false;
	}
	catch (e)
	{
		//alert(e);
		return false;
	}
}

function panIE()
{
	try
	{
		var msg = foto.hfDatiImmagine().value;
		var dt = new ClientState(msg);

		var cx = foto.imgTransito().width / 2;
		var cy = foto.imgTransito().height / 2;

		dt.x = dt.s * (window.event.offsetX - cx) * dt.z + dt.x;
		dt.y = dt.s * (window.event.offsetY - cy) * dt.z + dt.y;

		foto.hfDatiImmagine().value = dt.Write();

		GetImage(dt);		
		return false;
	}
	catch (e)
	{
		//alert(e);
		return false;
	}
}




function GetImage(r)
{
    try
    {
	    if (firstTransito == true)
	    {
		    firstTransito = false;
		    foto.imgTarga().onreadystatechange = imgTransitoOnReadyStateChanged;
	    }

	    var u = "/ITRSWeb/Handler/ImageHandler.ashx?";
	    u+= "t=" + r.t;
	    u+="&n=" + r.n;
	    u+="&d=" + r.EncodeDate(r.d);
	    u+="&z=" + r.z;
	    u+="&x=" + r.x;
	    u+="&y=" + r.y;
	    u+="&s=" + r.s;
	    u+="&lum=" + r.lum;
	    u+="&cnt=" + r.cnt;

	    var c = foto.imgTransito();
	    c.src = u;
	}
	catch (iiiuu)
	{
	}
}



function GetImageTarga(r)
{
    try
    {
	    var u = "/ITRSWeb/Handler/TargaHandler.ashx?";
	    u += "t=" + r.t;
	    u +="&n=" + r.n;
	    u +="&d=" + r.EncodeDate(r.d);
	    u +="&lum=" + r.lum;
	    u +="&cnt=" + r.cnt;
	    
	    u += "&xs=" + r.xs;
	    u += "&xe=" + r.xe;
	    u += "&ys=" + r.ys;
	    u += "&ye=" + r.ye;
	    
	    u += "&outW=" + r.outW;
	    u += "&outH=" + r.outH;
	    
	    var c = foto.imgTarga();
	    c.src = u;
	}
	catch (iiiuu)
	{
	}
}
