using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.IO;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using ITRS_BL;

public partial class Dettaglio_Segnalazione : System.Web.UI.UserControl
{
	protected void Page_Init(object sender, EventArgs e)
	{
		this.PreRender += new EventHandler(Dettaglio_Segnalazione_PreRender);
	}

	BLSegnalazioni.Segnalazione _segnalazione;

	protected override void LoadControlState(object savedState)
	{
		_segnalazione = (BLSegnalazioni.Segnalazione)savedState;
	}
	protected override object SaveControlState()
	{
		return _segnalazione;
	}

	public void VisualizzaSegnalazione(BLSegnalazioni.Segnalazione segnalazione)
	{
		_segnalazione = segnalazione;
	}

	public void VisualizzaSegnalazione(string Targa, string Nazionalita, DateTime DataOraInserimento, int IdEvento, int ProgressivoSegnalazione)
	{
		BLSegnalazioni bl = new BLSegnalazioni();
		_segnalazione = bl.GetSegnalazione(Targa, Nazionalita, DataOraInserimento, IdEvento, ProgressivoSegnalazione);

	}

	public string GetHtmlSegnalazione(string Targa, string Nazionalita, DateTime DataOraInserimento, int IdEvento, int ProgressivoSegnalazione)
	{
		using (BLSegnalazioni bl = new BLSegnalazioni())
		{
			_segnalazione = bl.GetSegnalazione(Targa, Nazionalita, DataOraInserimento, IdEvento, ProgressivoSegnalazione);

			Dettaglio_Segnalazione_PreRender(null, null);

			System.IO.StringWriter stringWriter = new System.IO.StringWriter();
			Html32TextWriter wr = new Html32TextWriter(stringWriter);

			this.tbSegnalazione.RenderControl(wr);

			string html = stringWriter.GetStringBuilder().ToString();

			_segnalazione = null;

			return html;
		}
	}
	
	protected void Page_Load(object sender, EventArgs e)
	{
		this.Page.RegisterRequiresControlState(this);
	}

	void Dettaglio_Segnalazione_PreRender(object sender, EventArgs e)
	{
		if (_segnalazione == null)
			return;

		lblTarga.Text = _segnalazione.Targa;
		lblNazionalita.Text = _segnalazione.Nazionalita;
		lblTipoLts.Text = nu(_segnalazione.TipoLts);
		lblUtenteRichiedente.Text = nu(_segnalazione.UtenteRichiedente);
		lblMotivo.Text = nu(_segnalazione.Motivo);
		lblNote.Text = nu(_segnalazione.Note);
		lblDataOraInizioValidita.Text = _segnalazione.DataOraInizioValidita.ToShortDateString();
		lblDataOraFineValidita.Text = _segnalazione.DataOraFineValidita.HasValue ? _segnalazione.DataOraFineValidita.Value.ToShortDateString() : "";
		lblTipoDest.Text = nu(_segnalazione.TipoDest);
		lblAddrDest.Text = nu(_segnalazione.AddrDest);
		lblLivelloPriorita.Text = nu(_segnalazione.LivelloPriorita);
	}

	string nu(string v)
	{
		if (v == null) return string.Empty;
		return v;
	}
}
