using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Diagnostics;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using ITRS_BL;

public partial class Dettaglio_Evento : System.Web.UI.UserControl, ICallbackEventHandler
{
	[Serializable]
	class DatiEvento
	{
		public DatiEvento()
		{
			targa = string.Empty;
			nazionalita = string.Empty;
		}
		public string targa;
		public string nazionalita;
		public DateTime dataOraInserimento;
		public Int64 idEvento;
		public bool premutoLinkPresoInCarico;
	}

	DatiEvento _id = null;

	#region evento CambioStato
	[Serializable]
	public class CambioStatoEvent : EventArgs
	{
		public CambioStatoEvent(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento, StatoAllarme statoAllarme)
		{
			this.Targa = targa;
			this.Nazionalita = nazionalita;
			this.DataOraInserimento = dataOraInserimento;
			this.IdEvento = idEvento;
			this.StatoAllarme = statoAllarme;
		}

		public readonly string Targa;
		public readonly string Nazionalita;
		public readonly DateTime DataOraInserimento;
		public readonly Int64 IdEvento;
		public readonly StatoAllarme StatoAllarme;
	}

	public delegate void CambioStatoDelegate(object sender, CambioStatoEvent e);

	public event CambioStatoDelegate CambioStato;
	#endregion

	#region PossoPrendereInCarico
	public delegate void PossoPrendereInCaricoDelegate(object sender, PossoPrendereInCaricoEvent e);
	public event PossoPrendereInCaricoDelegate PossoPrendereInCarico;
	[Serializable]
	public class PossoPrendereInCaricoEvent : EventArgs
	{
		public PossoPrendereInCaricoEvent(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento, StatoAllarme statoAllarme)
		{
			this.Targa = targa;
			this.Nazionalita = nazionalita;
			this.DataOraInserimento = dataOraInserimento;
			this.IdEvento = idEvento;
			this.StatoAllarme = statoAllarme;

			this._prendiInCarico = false;
			this._prendiInCaricoImpostato = false;
		}

		public readonly string Targa;
		public readonly string Nazionalita;
		public readonly DateTime DataOraInserimento;
		public readonly Int64 IdEvento;
		public readonly StatoAllarme StatoAllarme;
		private bool _prendiInCarico;
		private bool _prendiInCaricoImpostato;

		public bool PrendiInCarico
		{
			get { return _prendiInCarico; }
			set { _prendiInCarico = value; _prendiInCaricoImpostato = true; }
		}

		public bool PrendiInCaricoImpostato { get { return _prendiInCaricoImpostato; } }
	}
	#endregion PossoPrendereInCarico

	#region Control State
	protected override object SaveControlState()
	{
		return _id;
	}
	protected override void LoadControlState(object state)
	{
		_id = state as DatiEvento;
	}
	#endregion


	bool _ShowTargaNazionalita = true;

	[Bindable(true), Category("Behavior"), DefaultValue("true")]
	public bool ShowTargaNazionalita
	{
		get { return _ShowTargaNazionalita; }
		set { _ShowTargaNazionalita = value; }
	}

	protected override void OnInit(EventArgs e)
	{
		this.Page.RegisterRequiresControlState(this);
		base.OnInit(e);

		this.PreRender += new EventHandler(Dettaglio_Evento_PreRender);
		int n = 0;
		foreach (ListItem r in this.rblStatoEv.Items)
			r.Attributes["onclick"] = string.Format("VisualizzaNoteEv({0});", n++);

		GestionePopupSegnalazione();
	}

	public void VisualizzaEvento(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento)
	{
		_id = new DatiEvento();
		_id.targa = targa;
		_id.nazionalita = nazionalita;
		_id.dataOraInserimento = dataOraInserimento;
		_id.idEvento = idEvento;

		this.Visible = true;
	}

	public void NascondiEvento()
	{
		this.Visible = false;
		this._id = null;
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsCallback)
		{
			PageBase pb = (PageBase)this.Page;

			pb.RegisterClientId("EV", lblNoteEv, tbNoteEv);

			if (!this.Page.ClientScript.IsClientScriptBlockRegistered("EV"))
			{
				string s = @"
function VisualizzaNoteEv(n) 
{
	if (n == 0 || n == 1)
	{
		EV.lblNoteEv().style.visibility = 'visible';
		EV.tbNoteEv().style.visibility = 'visible';
	}
	else
	{
		EV.lblNoteEv().style.visibility = 'hidden';
		EV.tbNoteEv().style.visibility = 'hidden';
	}
} ";
				this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "EV", s, true);
			}

			pb.RegisterClientId("DEV", this.dpSegnalazioni);
		}
	}


	void Dettaglio_Evento_PreRender(object sender, EventArgs e)
	{
		if (this.Visible == false || _id == null || _id.idEvento < 0)
		{
			this.Visible = false;
			return;
		}

		using (BLEventi blEventi = new BLEventi())
		{
			DettEvento ev = blEventi.GetDatiEvento(
				this._id.targa,
				this._id.nazionalita,
				this._id.dataOraInserimento,
				this._id.idEvento);

			if (ev == null)
			{
				this.Visible = false;
				return;
			}

			this.lblTargaEv.Text = ev.Targa;
			this.lblNazionalitaEv.Text = ev.Nazionalita;
			this.lblDataOraInserimento.Text = ev.DataOraInserimento.ToString("G");
			this.lblTipoEvento.Text = ITRSUtility.Translate(ev.TipoEvento);
			this.lblClasseDiUrgenza.Text = ITRSUtility.Translate(ev.ClasseDiUrgenza);
			this.lblStatoAllarme.Text = ITRSUtility.Translate(ev.StatoAllarme);
			this.lblCoaDiCompetenza.Text = ev.CoaDiCompetenza;
			this.lblTransitiNonRiconosciuti.Text = ev.TransitiNonRiconosciuti.ToString();
			this.lblUtentePresaInCarico.Text = ev.UtentePresaInCarico;
			this.lblDataOraPresaInCarico.Text = ITRSUtility.PrintDataOra(ev.DataOraPresaInCarico);
			this.lblDataOraChiusura.Text = ITRSUtility.PrintDataOra(ev.DataOraChiusura);
			this.lblNoteChiusura.Text = ev.NoteChiusura;

			bool b = OnPossoPrendereInCarico(ev);
			if (b)
				this.lnkPresaInCaricoEv.Visible = true;
			else
				this.lnkPresaInCaricoEv.Visible = false;

			if (_id.premutoLinkPresoInCarico)
				this.lnkPresaInCaricoEv.Enabled = false;
			else
				NascondiPresaInCarico();

			if (ShowTargaNazionalita == false)
				NascondiTargaNazionalita();


			using (BLSegnalazioni blSegnalazioni = new BLSegnalazioni())
			{
				List<BLSegnalazioni.Segnalazione> lstSegnalazioni = blSegnalazioni.GetSegnalazioniSuEvento(ev.Targa, ev.Nazionalita, ev.DataOraInserimento, ev.IdEvento, null);
				foreach (BLSegnalazioni.Segnalazione segnalazione in lstSegnalazioni)
				{
					string text = /*segnalazione.ProgressivoSegnalazione.ToString() + " - " + */ segnalazione.DataOraInizioValidita.ToShortDateString();
					string value = segnalazione.ProgressivoSegnalazione.ToString();
					this.dpSegnalazioni.Items.Add(new ListItem(text, value));
				}
				this.promptSegnalazioni.InnerText = string.Format(this.promptSegnalazioni.InnerText, lstSegnalazioni.Count);
				if (lstSegnalazioni.Count == 0)
				{
					this.dpSegnalazioni.Visible = false;
					this.lnkApriSegnalazione.Visible = false;
				}

				string arg =
					this._id.targa + "|" +
					this._id.nazionalita + "|" +
					this._id.dataOraInserimento.ToString("G") + "|" +
					this._id.idEvento;

				this.lnkApriSegnalazione.OnClientClick = string.Format("return EventoApriSegnalazione('{0}', '');", arg);
			}
		}
	}

	protected virtual bool OnPossoPrendereInCarico(DettEvento ev)
	{
		if (PossoPrendereInCarico != null)
		{
			PossoPrendereInCaricoEvent eeee = new PossoPrendereInCaricoEvent(ev.Targa, ev.Nazionalita, ev.DataOraInserimento, ev.IdEvento, ev.StatoAllarme);
			PossoPrendereInCarico(this, eeee);

			if (eeee.PrendiInCaricoImpostato)
				return eeee.PrendiInCarico;
		}

		// Basta che ci sia anche un solo transito non in stato RIC che l'evento
		// non si puo` prendere in carico.
		if (Roles.IsUserInRole("Gestione allarmi") &&
			ITRSUtility.GetCoaDiAppartenenza() == ev.IdCoaDiCompetenza &&
			ev.TransitiNonRiconosciuti == 0 &&
			((ev.StatoAllarme == StatoAllarme.ACQ) ||
			((ev.StatoAllarme == StatoAllarme.PIC) && (Page.User.Identity.Name == ev.UtentePresaInCarico)))
			)
			return true;
		else
			return false;
	}

	protected void lnkPresaInCaricoEv_Click(object sender, EventArgs e)
	{
		using (BLEventi blEventi = new BLEventi())
		{
			DettEvento ev = blEventi.GetDatiEvento(
				this._id.targa,
				this._id.nazionalita,
				this._id.dataOraInserimento,
				this._id.idEvento);
			if (ev != null && ev.StatoAllarme == StatoAllarme.ACQ)
			{
				// e` ancora da acquisire
				using (BLQueueJobs blq = new BLQueueJobs())
				{
					string UserPkId = blq.GetUserPkId(Page.User.Identity.Name);

					BLEventi bl = new BLEventi();
					bool b = bl.PrendiInCarico(_id.targa, _id.nazionalita, _id.dataOraInserimento, _id.idEvento, UserPkId);

					PageBase.AddUserActivity(TipoAttivita.Evento, "Presa in carico dell'evento Targa:{0} Nazionalita:{1} Inserito il:{2} Nuovo stato:{3}",
						this._id.targa,
						this._id.nazionalita,
						this._id.dataOraInserimento.ToString("G"),
						"Preso in carico");

					this.lnkPresaInCaricoEv.Enabled = false;

					_id.premutoLinkPresoInCarico = true;

					if (CambioStato != null)
						CambioStato(this, new CambioStatoEvent(_id.targa, _id.nazionalita, _id.dataOraInserimento, _id.idEvento, StatoAllarme.PIC));
				}
			}
			else if (ev != null && ev.StatoAllarme == StatoAllarme.PIC && ev.UtentePresaInCarico == Page.User.Identity.Name)
			{
				// non faccio nulla dato che ci sto gia` lavorando
				_id.premutoLinkPresoInCarico = true;
			}
			else
			{
				// errore non si puo` piu` prenderlo in carico xche qualcun altro l'ha preso o non esiste piu`
				lblError.Text = "Impossibile prendere in carico l'evento.";
				lblError.Visible = true;
			}
		}
	}


	protected void btnOkEsciDaPresaInCarico_Click(object sender, EventArgs e)
	{
		// quale deve essere il valore di default?
		StatoAllarme nuovoStatoAllarme;
		string note;

		nuovoStatoAllarme = StatoAllarme.ACQ;		// esci da presa in carico
		this.lnkPresaInCaricoEv.Enabled = true;
		note = "";

		using (BLEventi bl = new BLEventi())
		{
			bool b = bl.AzioneSuPresaInCarico(_id.targa, _id.nazionalita, _id.dataOraInserimento, _id.idEvento, nuovoStatoAllarme, note);

			PageBase.AddUserActivity(TipoAttivita.Evento, "Cambio stato dell'evento Targa:{0} Nazionalita:{1} Inserito il:{2} Nuovo stato:{3}", this._id.targa, this._id.nazionalita, this._id.dataOraInserimento.ToString("G"), nuovoStatoAllarme);

			_id.premutoLinkPresoInCarico = false;

			if (CambioStato != null)
				CambioStato(this, new CambioStatoEvent(_id.targa, _id.nazionalita, _id.dataOraInserimento, _id.idEvento, nuovoStatoAllarme));
		}
	}
	protected void btnOkEv_Click(object sender, EventArgs e)
	{
		// quale deve essere il valore di default?
		StatoAllarme nuovoStatoAllarme;
		string note;

		switch (rblStatoEv.SelectedIndex)
		{
		case 0:
			nuovoStatoAllarme = StatoAllarme.CNF;		// Confermato
			note = tbNoteEv.Text;
			this.lnkPresaInCaricoEv.Enabled = false;
			break;
		case 1:
			nuovoStatoAllarme = StatoAllarme.NCNF;		// Non confermato
			note = tbNoteEv.Text;
			this.lnkPresaInCaricoEv.Enabled = false;
			break;
		case 2:
			nuovoStatoAllarme = StatoAllarme.ACQ;		// esci da presa in carico
			this.lnkPresaInCaricoEv.Enabled = true;
			note = "";
			break;

		default:
			Debug.Assert(false);
			nuovoStatoAllarme = StatoAllarme.ACQ;
			note = "";
			break;
		}

		using (BLEventi bl = new BLEventi())
		{
			bool b = bl.AzioneSuPresaInCarico(_id.targa, _id.nazionalita, _id.dataOraInserimento, _id.idEvento, nuovoStatoAllarme, note);

			PageBase.AddUserActivity(TipoAttivita.Evento, "Cambio stato dell'evento Targa:{0} Nazionalita:{1} Inserito il:{2} Nuovo stato:{3}", this._id.targa, this._id.nazionalita, this._id.dataOraInserimento.ToString("G"), nuovoStatoAllarme);

			_id.premutoLinkPresoInCarico = false;

			if (CambioStato != null)
				CambioStato(this, new CambioStatoEvent(_id.targa, _id.nazionalita, _id.dataOraInserimento, _id.idEvento, nuovoStatoAllarme));
		}
	}


	private void NascondiPresaInCarico()
	{
		tbEvento.Rows.Remove(this.trPresaInCarico0);
		tbEvento.Rows.Remove(this.trPresaInCarico1);
		tbEvento.Rows.Remove(this.trPresaInCarico2);
		tbEvento.Rows.Remove(this.trPresaInCarico3);
		tbEvento.Rows.Remove(this.trPresaInCarico4);
	}

	private void NascondiTargaNazionalita()
	{
		tbEvento.Rows.Remove(this.trTargaNaz1);
		tbEvento.Rows.Remove(this.trTargaNaz2);
	}


	#region Gestione popup segnalazione


	private void GestionePopupSegnalazione()
	{
		// qui si da il bianco
		if (!Page.ClientScript.IsClientScriptBlockRegistered("Evento_" + this.ID))
		{
			string cbReference = Page.ClientScript.GetCallbackEventReference(this, "arg", "RiceviHtmlSegnalazione", "context");
			string s = @"

// quando si preme su Apri si chiama questa funzione che chiama il server
// specificando il progressivo della segnalazione che si prova nella
// drop downlist.
function EventoApriSegnalazione(arg, context) 
{
	var dp = DEV.dpSegnalazioni();
	arg += '|' + dp.value;
" + cbReference + @"; 
	return false; // blocco la chiamata al client
}

// il server mi ritorna la risposta qui.
function RiceviHtmlSegnalazione(rvalue, context) 
{
	var dp = DEV.dpSegnalazioni();

	var w = new PopupWindow('PopupCalendar_Div');
	w.offsetY = 30;
	w.offsetX = -80;
	//w.setSize('400', '400');
	w.autoHide();
	w.populate(rvalue);

	var anchorname = dp.id;
	w.showPopup(anchorname);
}
";
			Page.ClientScript.RegisterClientScriptBlock(
				this.GetType(),
				"Evento_" + this.ID, s, true);
		}
	}

	string _htmlSegnalazione;

	public string GetCallbackResult()
	{
		if (_htmlSegnalazione == null)
			return "";
		return _htmlSegnalazione;
	}

	public void RaiseCallbackEvent(string eventArgument)
	{
		string[] args = eventArgument.Split('|');
		string Targa = args[0];
		string Nazionalita = args[1];
		DateTime DataOraInserimento = DateTime.Parse(args[2]);
		int IdEvento = int.Parse(args[3]);
		int ProgressivoSegnalazione = int.Parse(args[4]);

		using (BLSegnalazioni bl = new BLSegnalazioni())
		{
			BLSegnalazioni.Segnalazione segnalazione = bl.GetSegnalazione(Targa, Nazionalita, DataOraInserimento, IdEvento, ProgressivoSegnalazione);


			lblTarga.Text = segnalazione.Targa;
			lblNazionalita.Text = segnalazione.Nazionalita;
			lblTipoLts.Text = nu(segnalazione.TipoLts);
			lblUtenteRichiedente.Text = nu(segnalazione.UtenteRichiedente);
			lblMotivo.Text = nu(segnalazione.Motivo);
			lblNote.Text = nu(segnalazione.Note);
			lblDataOraInizioValidita.Text = segnalazione.DataOraInizioValidita.ToShortDateString();
			lblDataOraFineValidita.Text = segnalazione.DataOraFineValidita.HasValue ? segnalazione.DataOraFineValidita.Value.ToShortDateString() : "";
			lblTipoDest.Text = nu(segnalazione.TipoDest);
			lblAddrDest.Text = nu(segnalazione.AddrDest);
			lblLivelloPriorita.Text = nu(segnalazione.LivelloPriorita);


			this.divSegnalazione.Visible = true;

			System.IO.StringWriter stringWriter = new System.IO.StringWriter();
			Html32TextWriter wr = new Html32TextWriter(stringWriter);
			this.divSegnalazione.RenderControl(wr);

			this.divSegnalazione.Visible = false;

			_htmlSegnalazione = stringWriter.GetStringBuilder().ToString();
		}
	}
	string nu(string a) { return a == null ? string.Empty : a; }

	#endregion
}
