using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Dettaglio_TransitoSegnalato : System.Web.UI.UserControl
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}

	public event Dettaglio_Transito.ExportTransitoDelegate ExportTransito
	{
		add { _dettTransito.ExportTransito += value; }
		remove { _dettTransito.ExportTransito -= value; }
	}

	public void VisualizzaTransitoSegnalato(
		string targa, string nazionalita, DateTime dataOraRilevamento,
		DateTime ? dataOraInserimento, Int64 ? idEvento)
	{
		_dettTransito.VisualizzaTS(targa, nazionalita, dataOraRilevamento);
		_dettImmagine.VisualizzaImmagine(targa, nazionalita, dataOraRilevamento);

		if (idEvento.HasValue && dataOraInserimento.HasValue)
		{
			_dettEvento.VisualizzaEvento(targa, nazionalita, dataOraInserimento.Value, idEvento.Value);
			_colDatiEvento.Visible = true;

		}
		else
		{
			_dettEvento.NascondiEvento();
			_colDatiEvento.Visible = false;
		}

		this.Visible = true;
	}

	public void NascondiTransitoSegnalato()
	{
		_dettTransito.NascondiTS();
		_dettImmagine.NascondiImmagine();
		_dettEvento.NascondiEvento();
		_colDatiEvento.Visible = false;

		this.Visible = false;
	}
}
