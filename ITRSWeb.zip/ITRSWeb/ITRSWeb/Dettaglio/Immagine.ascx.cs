using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using ITRS_BL;

public partial class Dettaglio_Immagine : System.Web.UI.UserControl
{
	class DatiImmagine
	{
		public DatiImmagine()
		{
			t = string.Empty;
			n = string.Empty;
			d = DateTime.MinValue;
			x = y = 0;
			z = 1;
			s = 3;

			cnt = 1.0;
			lum = 0.0;

			mLat = 0;
			mLon = 0;
			mAlt = 10;
			mCmds = "";
		}
		public string t;
		public string n;
		public DateTime d;
		public double x, y, z, s;
		public double lum, cnt;
		public double mLat;
		public double mLon;
		public double mAlt;
		public string mCmds;

		public int xs;
		public int xe;
		public int ys;
		public int ye;

		public int outW;
		public int outH;
	}

	DatiImmagine _id = null;


	public void VisualizzaImmagine(string targa, string nazionalita, DateTime dataOraRilevamento)
	{
		_id = new DatiImmagine();
		_id.t = targa;
		_id.n = nazionalita;
		_id.d = dataOraRilevamento;

		_id.xs = -1;
		_id.xe = -1;
		_id.ys = -1;
		_id.ye = -1;

		using (BLTransiti blTR = new BLTransiti())
		{
			blTR.GetLatLonTransito(targa, nazionalita, dataOraRilevamento, out _id.mLat, out _id.mLon);

			DatiTarga dt = blTR.GetDatiTarga(targa, nazionalita, dataOraRilevamento);
			if (dt != null)
			{
				if (dt.xStart.HasValue && dt.xEnd.HasValue && dt.yStart.HasValue && dt.yEnd.HasValue)
				{
					_id.xs = dt.xStart.Value;
					_id.xe = dt.xEnd.Value;
					_id.ys = dt.yStart.Value;
					_id.ye = dt.yEnd.Value;

					_id.outW = (int)this.imgTarga.Width.Value;
					_id.outH = (int)this.imgTarga.Height.Value;
				}
			}
		}

		hfDatiImmagine.Value = ClientState.Serialize(_id);

		this.multiViewFotoCartina.ActiveViewIndex = 0;
		this.Visible = true;
	}

	public void NascondiImmagine()
	{
		this.multiViewFotoCartina.ActiveViewIndex = 0;
		this.Visible = false;
		this.hfDatiImmagine.Value = "";
	}


	protected void Page_Init(object sender, EventArgs e)
	{
		this.PreRender += new EventHandler(Dettaglio_Immagine_PreRender);
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		PageBase pb = (PageBase)this.Page;

		pb.RegisterClientId("foto",
			hfDatiImmagine, imgTransito, imgMap,

			mapZoomIn, mapZoomOut,
			mapPanNorthWest, mapPanNorth, mapPanNorthEast,
			mapPanWest, mapPanEast,
			mapPanSouthWest, mapPanSouth, mapPanSouthEast,

			btnZoomIn, btnZoomOut, cntDw, cntUp, lumDw, lumUp, btnReset,

			imgTarga
			);
	}


	void Dettaglio_Immagine_PreRender(object sender, EventArgs e)
	{
		if (this.Visible == false || hfDatiImmagine.Value == "")
		{
			this.Visible = false;
			return;
		}

		if (_id == null)
			_id = (DatiImmagine)(ClientState.Deserialize(typeof(DatiImmagine), hfDatiImmagine.Value));

		if (this.multiViewFotoCartina.ActiveViewIndex == 0)
		{
			BuildPopupImage();

			this.imgTransito.ImageUrl = BuildImgUrl();
			this.imgTransito.Attributes["onclick"] = "return transito_isIE ? panIE() : panFF(event);";
			this.imgTransito.Style.Add(HtmlTextWriterStyle.Cursor, "crosshair");

			if (_id.xe == -1 && _id.xs == -1)
				this.imgTarga.Visible = false;
			else
			{
				this.imgTarga.Visible = true;
				this.imgTarga.ImageUrl = BuildTargaImgUrl();
			}

			this.imgTransito.Visible = true;
			this.imgMap.Visible = false;
		}
		else
		{
			this.imgMap.ImageUrl = BuildMapUrl();
			this.imgMap.Attributes["onclick"] = "return transito_isIE ? mapPanIE() : mapPanFF(event);";
			this.imgMap.Visible = true;
			this.imgTransito.Visible = false;
			this.imgTarga.Visible = false;
		}
	}

	private string BuildMapUrl()
	{
		string u = "~/Handler/MapHandler.ashx?";
		u += "&lat=" + _id.mLat.ToString(CultureInfo.InvariantCulture);
		u += "&lon=" + _id.mLon.ToString(CultureInfo.InvariantCulture);
		u += "&alt=" + _id.mAlt.ToString(CultureInfo.InvariantCulture);
		u += "&steps=" + _id.mCmds;

		return u;
	}


	private string BuildImgUrl()
	{
		string u = "~/Handler/ImageHandler.ashx?";
		u += "t=" + _id.t;
		u += "&n=" + _id.n;
		u += "&d=" + _id.d.ToString("yyyy MM dd HH mm ss");
		u += "&z=" + _id.z.ToString(CultureInfo.InvariantCulture);
		u += "&x=" + _id.x.ToString(CultureInfo.InvariantCulture);
		u += "&y=" + _id.y.ToString(CultureInfo.InvariantCulture);
		u += "&s=" + _id.s.ToString(CultureInfo.InvariantCulture);
		u += "&lum=" + _id.lum.ToString(CultureInfo.InvariantCulture);
		u += "&cnt=" + _id.cnt.ToString(CultureInfo.InvariantCulture);

		return u;
	}

	private string BuildTargaImgUrl()
	{
		return ImageUtility.TargaHandler_BuildRequest(_id.t, _id.n, _id.d, _id.xs, _id.xe, _id.ys, _id.ye,
			_id.outW, _id.outH, _id.lum, _id.cnt);
	}


	private void BuildPopupImage()
	{
		string host_port = Request.Url.Authority;

		string u = "http://{0}/ITRSweb/Handler/ImageHandler2.ashx?";
		u = string.Format(u, host_port);
		u += "t=" + _id.t;
		u += "&n=" + _id.n;
		u += "&d=" + _id.d.ToString("yyyy MM dd HH mm ss");

		string src = @"
	var oPopup = window.createPopup();
function popupImage()
{{
    var oPopupBody = oPopup.document.body;
	oPopupBody.style.backgroundColor = ""lightyellow"";
	oPopupBody.style.border = ""solid black 1px"";    
    oPopupBody.innerHTML = ""<img src='{0}' width='800' height='600'></img>"";
    oPopup.show(100, 100, 800, 600);
	return false;
}}

";
		src = string.Format(src, u, this.mapPopupZoom.ClientID);
		Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "WWEE@" + this.ClientID, src, true);
	}

	protected void linkFoto_Click(object sender, EventArgs e)
	{
		this.multiViewFotoCartina.ActiveViewIndex = 0;
	}
	protected void lnkCartina_Click(object sender, EventArgs e)
	{
		this.multiViewFotoCartina.ActiveViewIndex = 1;
	}
}
