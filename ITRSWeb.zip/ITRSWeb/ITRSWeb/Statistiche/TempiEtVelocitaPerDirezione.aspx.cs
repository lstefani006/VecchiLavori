using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using ITRS_BL;


public partial class Statistiche_TempiEtVelocitaPerDirezione : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		// per gestire gli errori di aggiornamento del db e della details view
		base.WriteError += new WriteErrorDelegate(TempiEtVelocitaPerDirezione_WriteError);
		base.HandleError(this.gvTempiEtVelocita);
		base.HandleError(this.odsTempiEtVelocita);
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		// imposto il sort iniziale della grid view
		if (!IsPostBack)
		{
			this.gvTempiEtVelocita.Sort("Ora_Da", SortDirection.Ascending);
			gvTempiEtVelocita.Visible = false;
		}

		if (this.lblError.EnableViewState == true)
			this.lblError.Text = "";

		RegisterClientId("ST1", calDataRep);

	}

    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);
        this.btnExport.Visible = (gvTempiEtVelocita.Visible && gvTempiEtVelocita.Rows.Count>0);
    }

	private void TempiEtVelocitaPerDirezione_WriteError(Exception ex)
	{
		this.lblError.ForeColor = System.Drawing.Color.Red;
		if (ex.InnerException == null)
			this.lblError.Text = ex.Message;
		else
			this.lblError.Text = ex.InnerException.Message;
	}

	protected void btnData_Click(object sender, EventArgs e)
	{
		gvTempiEtVelocita.Visible = true;

		AddUserActivity(TipoAttivita.ReportTVPD, "Consultazione report Tempo Medio e Velocit� Media di Percorrenza per Direzione del giorno {0}", calDataRep.SelectedDate.Value.ToString("dd/MM/yyyy"));

		if (calDataRep.SelectedDate.HasValue)
			gvTempiEtVelocita.Caption = "Tempo Medio e Velocit� Media di Percorrenza per Direzione del giorno: " + calDataRep.SelectedDate.Value.ToString("dd/MM/yyyy");
		else
			gvTempiEtVelocita.Caption = "Nessuna Data selezionata";
	}

    protected string Duration(int sec)
    {
        TimeSpan s = new TimeSpan(0, 0, sec);
        return s.Hours.ToString("00") + ":" + s.Minutes.ToString("00") + ":" + s.Seconds.ToString("00");
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        string sort = gvTempiEtVelocita.SortExpression;
        sort += (gvTempiEtVelocita.SortDirection == SortDirection.Descending) ? " desc" : string.Empty;

        ExportTempiVelocitaPerDirezioneData dd = new ExportTempiVelocitaPerDirezioneData();
        dd.fileName = string.Format("TempiVelocitaPerDirezione_{0}-{1}.xls", calDataRep.VisibleDate.Value.ToString("ddMMyy"), ddlDirezione.SelectedValue);
        dd.Data = calDataRep.VisibleDate.Value;
        dd.Direzione = ddlDirezione.SelectedValue;

        dd.sort = sort;

        MemoryStream ms = new MemoryStream();
        BinaryFormatter bf = new BinaryFormatter();
        bf.Serialize(ms, dd);
        string gg = Convert.ToBase64String(ms.ToArray());
        dnlWindow.Attributes["src"] = "/ITRSWeb/DownloadGeneric.aspx?Action=" + gg;
    }
}
