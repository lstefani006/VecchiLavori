using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Drawing;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

using ITRS_BL;


public partial class Diagnostica_StatisticaAllarmi : PageBase
{
	protected void Page_Init()
	{
		int idCoa = ITRSUtility.GetCoaDiAppartenenza();
		if (idCoa < 0) idCoa = 1;

		List<ITRS_BL.Coa> lstCoa = BLCacher.GetListaCOA();
		foreach (ITRS_BL.Coa c in lstCoa)
		{
			ListItem cc = new ListItem(c.Descrizione, c.IdCOA.ToString());
			if (idCoa == c.IdCOA) cc.Selected = true;
			coaSelezionato.Items.Add(cc);
		}

		if (idCoa == 1)
		{
			turnoDiServizioSala.Visible = true;
			turnoDiServizioLame.Visible = false;
		}
		else
		{
			turnoDiServizioSala.Visible = false;
			turnoDiServizioLame.Visible = true;
		}
	}
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			edit_DataRicerca.Text = DateTime.Now.ToShortDateString();

			//int idCoa = ITRSUtility.GetCoaDiAppartenenza();
			//if (idCoa > 0)
			//    coaSelezionato.SelectedValue = idCoa.ToString();

			hfRicercaLanciata.Value = "F";
		}

		if (!IsCallback)
		{
			RegisterClientId("STARIC", edit_DataRicerca);
			_stSorv = new BLSorveglianza.StatisticaSorveglianza();
			divRisultati.Visible = hfRicercaLanciata.Value == "T";
		}
	}
	protected void btnRicerca_Click(object sender, EventArgs e)
	{
		int idCoa = int.Parse(coaSelezionato.SelectedValue);
		DateTime di;
		DateTime df;

		if (!DateTime.TryParse(edit_DataRicerca.Text, out di))
		{
			lblError.Text = "Inserire una data corretta!";
			lblError.ForeColor = Color.Red;
			return;
		}
		df = di;

		string[] turno;
		if (idCoa == 1)
			turno = turnoDiServizioSala.SelectedValue.Split(' ');
		else
			turno = turnoDiServizioLame.SelectedValue.Split(' ');
		int HHi = int.Parse(turno[0]);
		int MIi = int.Parse(turno[1]);
		int HHf = int.Parse(turno[2]);
		int MIf = int.Parse(turno[3]);

		TimeSpan tsI = new TimeSpan(HHi, MIi, 0);
		TimeSpan tsF = new TimeSpan(HHf, MIf, 0);

		if (tsI < tsF)
		{
			di = di.Add(tsI);
			df = df.Add(tsF);
		}
		else
		{
			di = di.Add(tsI);
			df = df.AddDays(1).Add(tsF);
		}


		using (BLSorveglianza bl = new BLSorveglianza())
		{
			_stSorv = bl.GetReportAllarmiTS(idCoa, di, df);
			divRisultati.Visible = true;
			hfRicercaLanciata.Value = "T";
		}
	}

	protected BLSorveglianza.StatisticaSorveglianza _stSorv;

	protected void coaSelezionato_Changed(object sender, EventArgs e)
	{
		int idCoa = int.Parse(coaSelezionato.SelectedItem.Value);
		if (idCoa == 1)
		{
			turnoDiServizioSala.Visible = true;
			turnoDiServizioLame.Visible = false;
		}
		else
		{
			turnoDiServizioSala.Visible = false;
			turnoDiServizioLame.Visible = true;
		}
	}
}
