using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using ITRS_BL;


public partial class Statistiche_TempiSostaC2P : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		// per gestire gli errori di aggiornamento del db e della details view
		base.WriteError += new WriteErrorDelegate(TempiSostaC2P_WriteError);
		base.HandleError(this.gvTempiSostaC2P);
		base.HandleError(this.odsTempiSostaC2P);
	}
	
    protected void Page_Load(object sender, EventArgs e)
	{
		// imposto il sort iniziale della grid view
		if (!IsPostBack)
		{
			this.gvTempiSostaC2P.Sort("Ora_Da", SortDirection.Ascending);
			gvTempiSostaC2P.Visible = false;
		}

		if (this.lblError.EnableViewState == true)
			this.lblError.Text = "";

		RegisterClientId("ST1", this.calDataRep);
	}

    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);
        this.btnExport.Visible = (gvTempiSostaC2P.Visible && gvTempiSostaC2P.Rows.Count > 0);
    }
	
    private void TempiSostaC2P_WriteError(Exception ex)
	{
		this.lblError.ForeColor = System.Drawing.Color.Red;
		if (ex.InnerException == null)
			this.lblError.Text = ex.Message;
		else
			this.lblError.Text = ex.InnerException.Message;
	}

	protected void btnData_Click(object sender, EventArgs e)
	{
		gvTempiSostaC2P.Visible = true;

		AddUserActivity(TipoAttivita.ReportTSC2P, "Consultazione report Densita` del traffico su tratta del giorno {0}", calDataRep.SelectedDate.Value.ToString("dd/MM/yyyy"));


		if (calDataRep.SelectedDate.HasValue)
			gvTempiSostaC2P.Caption = "Densita` del traffico su Tratta del giorno: " + calDataRep.SelectedDate.Value.ToString("dd/MM/yyyy");
		else
			gvTempiSostaC2P.Caption = "Nessuna Data selezionata";
	}

    protected string Duration(int sec)
    {
        TimeSpan s = new TimeSpan(0, 0, sec);
        return s.Hours.ToString("00") + ":" + s.Minutes.ToString("00") + ":" + s.Seconds.ToString("00");
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        string sort = gvTempiSostaC2P.SortExpression;
        sort += (gvTempiSostaC2P.SortDirection == SortDirection.Descending) ? " desc" : string.Empty;

        ExportTempiSostaData dd = new ExportTempiSostaData();
        dd.fileName = string.Format("TempiSostaC2P_{0}-{1}.xls", calDataRep.VisibleDate.Value.ToString("ddMMyy"), ddlTratte.SelectedItem.Text);
        dd.Data = calDataRep.VisibleDate.Value;
        dd.IdC2P = int.Parse(ddlTratte.SelectedValue);

        dd.sort = sort;

        MemoryStream ms = new MemoryStream();
        BinaryFormatter bf = new BinaryFormatter();
        bf.Serialize(ms, dd);
        string gg = Convert.ToBase64String(ms.ToArray());
        dnlWindow.Attributes["src"] = "/ITRSWeb/DownloadGeneric.aspx?Action=" + gg;
    }
}
