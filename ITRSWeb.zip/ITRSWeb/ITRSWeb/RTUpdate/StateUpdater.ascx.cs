using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Caching;
using ITRS_BL;

public partial class RTUpdate_StateUpdater : System.Web.UI.UserControl
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsCallback)
		{
			int nCoaAppartenenza = ITRSUtility.GetCoaDiAppartenenza();

			if (!(this.Page.User.IsInRole("DiagnosticaRO") || this.Page.User.IsInRole("Operatore sorveglianza")))
			{
				clientTimerRTUpdate.PollingPeriod = -1;
				this.Visible = false;
			}

			if (nCoaAppartenenza < 0)
				this.Visible = false;
		}
	}
	protected void clientTimerRTUpdate_ClientCall(object sender, ITRSControls.ClientTimerClientTimerEventArgs e)
	{
		try
		{
			int nCoaAppartenenza = ITRSUtility.GetCoaDiAppartenenza();
			SytemDiagnostic d = BLCacher.BLC2P_RefreshDiagnostica(5, nCoaAppartenenza);
			if (d == null)
			{
				e.Result = "";
				return;
			}

			e.Result = string.Format("{0},{1}/{2}", (d.Diagnostica ? "Y" : "N"), d.SorveglianzaA1, d.SorveglianzaA2);

			if (this.Page.User.IsInRole("DiagnosticaRO"))
				e.Result += ",Y";
			else
				e.Result += ",N";

			if (this.Page.User.IsInRole("Operatore sorveglianza"))
				e.Result += ",Y";
			else
				e.Result += ",N";

		}
		catch
		{
			e.Result = "";
		}
	}
}
