﻿function Intervento_OnJobProgressMsg(msg)
{
	var ret = true; // valore ritornato da questa funzione
	var cdModificato = false;
	var r = new ClientState(msg);
	// memorizzo il messaggio
	GI.hfClientData().value = msg;

	// se esiste un ultimo rilevamento lo visualizzo
	if (r.UT_DataOraRilevamento != "")
	{
		// copio i valori dell'ultimo transito.
		GI.UT_DataOraRilevamento().innerText = r.UT_DataOraRilevamento;
		GI.UT_Descrizione().innerText        = r.UT_Descrizione;
		GI.UT_Direzione().innerText          = r.UT_Direzione;
		GI.UT_TipoVarco().innerText          = r.UT_TipoVarco;
		GI.UT_StatoTransito().innerText      = r.UT_StatoTransito;
		
		// setto lo stile
		var a = new Array();
		a[0] = GI.UT_DataOraRilevamento();
		a[1] = GI.UT_Descrizione();
		a[2] = GI.UT_Direzione();
		a[3] = GI.UT_TipoVarco();
		a[4] = GI.UT_StatoTransito();
		for (var ai = 0; ai < a.length; ai++)
		{
			var cn = a[ai];
			if (r.UT_EventoAssociatoAlTransito == true)
				cn.style.cssText = "FONT-Style: bold; FONT-SIZE: 12px; COLOR: #FF0000";
			else
				cn.style.cssText = "FONT-SIZE: 12px; COLOR: #585880";
		}
		
		// controllo se e` un nuovo transito.
		if (r.UT_DataOraRilevamentoVisualizzato != r.UT_DataOraRilevamento)
		{
			// aggiorno il messaggio!
			r.UT_DataOraRilevamentoVisualizzato = r.UT_DataOraRilevamento;
			cdModificato = true;
			
			GI.btnQuery().style.visibility = "visible";
		}
	}
		
	if (r.EndProcessed == false)
	{
		var c;
		
		if (r.StatusDescr != '')
		{
			c = GI.xlblStato();
			c.style.visibility = "visible";
			c.innerText = r.StatusDescr;
		}

		if (r.CurrentStep != null)
		{
			var p = document.getElementById("tbProgress");
			updateProgress(p, r.CurrentStep - 1, r.TotalSteps);
		}
		
		if (r.ProgressMessage != null && r.ProgressMessage != '')
		{
			c = GI.xlblAvanzamento();
			c.style.visibility = "visible";
			c.innerText = r.ProgressMessage;
		}
		
		if (r.ResRecordCount != null)
		{
			c = GI.xlblRecordDisponibili();
			c.innerText = r.ResRecordCount;
			c.style.visibility = "visible";
			
			if (r.ResRecordCount > 0)
			{
				c = GI.btnRisultatiIntermedi();
				if (c != null)
					c.style.visibility = "visible";
			}
		}
		
		if (r.Status == "END")
		{
			r.EndProcessed = true;
			cdModificato = true;
				
			// Qui simulo un POST (non callback)
			MostraRisultatiIntermedi();
		}
		
		
		/*
		-- QUEUE job in coda
		-- RUN   job in esecuzione
		-- SOSP  job sospeso
		-- ERR   job terminato con eccezione
		-- RRES  job in run che ha prodotto risultati intermedi
		-- END   job terminato con successo
		-- ABRQ  job con richiesta di abort in corso
		-- ABAK  job che ha accettato la richiesta di abort
		-- CANC  job da cancellare perche` scaduto (sysdate - QJLASTRESACCESS > QJRESTIMEOUTSEC)
		*/
		switch (r.Status)
		{
		case "QUEUE": ret = true;  break;
		case "RUN":   ret = true;  break;
		case "SOSP":  ret = true;  break;
		case "ERR":   ret = false; break;
		case "RRES":  ret = true;  break;
		case "END":   ret = true;  break; // ATTENZIONE
		case "ABRQ":  ret = true;  break;
		case "ABAK":  ret = false; break;
		case "CANC":  ret = false; break;
		
		default:
			alert("Che stato e` : " + r.Status);
			ret = false;
			break;
		}
		
		
	}
	
	if (cdModificato)
		GI.hfClientData().value = r.Write();
		
	return ret;
}

function Intervento_GetArg()
{
	return GI.hfClientData().value;
}
		
function updateProgress(tb, ss, cc)
{
	if (cc <= 0) return;
	if (ss < 0 && ss >= cc) return;
	
	// scalo i valori in modo che siano al max 20
	var scale_kk = cc / 20;
	if (scale_kk == 0) scale_kk = 1;
	var scale_kki = Math.ceil(scale_kk);
	cc = Math.ceil(cc/scale_kki);
	ss = Math.ceil(ss/scale_kki);

	if (tb.rows[0].cells.length != cc)
	{
		tb.width = "200px";
		
		var nn = tb.rows[0].cells.length;
		for (var tt = 0; tt < nn; ++tt)
			tb.rows[0].deleteCell(0);
			
		tb.style.backgroundColor = "white";
			
		var ww = 100 / cc;
			
		for (var ii = 0; ii < cc; ++ii)
		{
			var c = tb.rows[0].insertCell(0);
			c.style.backgroundColor = "white";
			c.style.width = ww.toString() + "%";
			c.style.height = "10px";
		}
	}
	
	if (true)
	{
		for (var ii = 0; ii < cc; ++ii)
			if (ii <= ss)
				tb.rows[0].cells[ii].style.backgroundColor = "black";
	}
}


