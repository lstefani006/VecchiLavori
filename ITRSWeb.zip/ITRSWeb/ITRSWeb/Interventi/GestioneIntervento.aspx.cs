using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Web;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using System.Reflection;
using ITRS_BL;

public partial class Interventi_GestioneIntervento : PageBase
{
	InterventiQueueJob JobData;

	ClientData _cd = null;

	protected void Page_Init(object sender, EventArgs e)
	{
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			// recupero e memorizzo il JobId
			string JobId = Request["JobId"];
			if (string.IsNullOrEmpty(JobId))
				return;

			_cd = new ClientData();
			_cd.JobId = JobId;
			hfJobId.Value = JobId;

			_cd.EndProcessed = false;
			_cd.UT_DataOraRilevamentoVisualizzato = "";
			_cd.UT_DataOraRilevamento = "";
		}
		else
		{
			_cd = (ClientData)ClientState.Deserialize(typeof(ClientData), hfClientData.Value);
		}

		// leggiamo dal DB a che punto siamo con il job
		// La lettura la si fa in tutti casi, sia ClientCallback che PostBack
		if (true)
		{
			BL_Interventi bl = new BL_Interventi();
			this.JobData = bl.GetRunningJobData(_cd.JobId);
		}

		if (!IsPostBack)
		{
			// la prima volta che viene chiamata la maschera

			// il record piu` recente sara` il primo ad essere visualizzato nella 
			// lista dei transiti e anche nell'ultimo transito aggiornato dinamicamente
			if (this.JobData.DataOraRilevamento.HasValue)
				_cd.UT_DataOraRilevamentoVisualizzato = this.JobData.DataOraRilevamento.Value.ToString("G");
			else
				_cd.UT_DataOraRilevamentoVisualizzato = "";

			// siccome e` la prima volta non faccio vedere i bottoni di aggiornamento
			this.btnQuery.Style[HtmlTextWriterStyle.Visibility] = "hidden";
			this.btnRisultatiIntermedi.Style[HtmlTextWriterStyle.Visibility] = "hidden";
			this.gvTransiti.Sort("DataOraRilevamento", SortDirection.Descending);


			if (QueryRunning(JobData.Status))
			{
				// siamo in attesa che il job si concluda...
				this.clientTimerQueryResult.EnableServerCalls = "true";

				// comunico al client che deve aspettarsi la fine del job (prima o poi)
				_cd.EndProcessed = false;

				this.pnQueryFinita.Visible = false;
				this.pnQueryRunning.Visible = true;
			}
			else
			{
				// il job e` gia` terminato... 
				// il polling continua solo se il job e` terminato con successo
				// in modo da stare in attesa di eventuali nuovi transiti.

				if (JobData.Status != BLQueueJobs.JobStatus.END)
					this.clientTimerQueryResult.EnableServerCalls = "false";
				else
					this.clientTimerQueryResult.EnableServerCalls = "true";

				// dato che e` terminato lo comunico al cliente
				this._cd.EndProcessed = true;

				this.pnQueryRunning.Visible = false;
				this.pnQueryFinita.Visible = true;
				this.xlblRecordDisponibili2.Text = this.JobData.ResRecordCount.ToString();
			}

			gvTransiti.Enabled = false;
			gvTransiti.Visible = false;

			// stabilisco se c'e` qualcosa da vedere nel Griglia
			// NOTARE che qui sono al caricamento della maschera ...
			// mi sforzo e faccio cmq la query sui risultati se ci sono.
			if (JobData.Status == BLQueueJobs.JobStatus.END || JobData.Status == BLQueueJobs.JobStatus.RRES)
			{
				// c'e` qualcosa da vedere.
				gvTransiti.Enabled = true;
				gvTransiti.Visible = true;
				gvTransiti.EmptyDataText = "La ricerca non ha trovato transiti ";
				// se non ci sono record la griglia fa vedere il messaggio di griglia vuota.
			}

		}

		if (!IsCallback)
		{
			// non sono in call back, per cui la maschera viene renderizzata tutta
			// al browser.... devo aggiornare tutti i campi.

			// scrivo / riscrivo l'intestazione
			// in caso di primo caricamento della pagina o di PostBack non client IsCallback
			lblTarga.Text = this.JobData.Targa;
			lblNazionalita.Text = this.JobData.Nazionalita;

			// scrivo i dati dell'ultimo transito
			if (this.JobData.DataOraRilevamento.HasValue)
				this.UT_DataOraRilevamento.Text = this.JobData.DataOraRilevamento.Value.ToString("G");
			else
				this.UT_DataOraRilevamento.Text = "";

			if (this.JobData.Descrizione != null)
				this.UT_Descrizione.Text = this.JobData.Descrizione;
			else
				this.UT_Descrizione.Text = "";

			this.UT_Direzione.Text = ITRSUtility.TranslateNullable(this.JobData.Direzione);
			this.UT_TipoVarco.Text = ITRSUtility.TranslateNullable(this.JobData.TipoVarco);
			this.UT_StatoTransito.Text = ITRSUtility.TranslateNullable(this.JobData.StatoTransito);
		}


		if (IsPostBack && !IsCallback)
		{
			// sono in un postback NON causato da una callback
			// Abilito/disabilito il polling a seconda del DB.

			// leggiamo dal DB a che punto siamo con il job
			if (QueryRunning(this.JobData.Status))
			{
				// siamo in attesa che il job si concluda... abilito il polling
				clientTimerQueryResult.EnableServerCalls = "true";
			}
			else
			{
				// il job e` terminato... 
				// il polling non serve solo se il job e` andato a buon fine
				// per vedere  se ci sono altri transiti.
				if (JobData.Status != BLQueueJobs.JobStatus.END)
					clientTimerQueryResult.EnableServerCalls = "false";
				else
					clientTimerQueryResult.EnableServerCalls = "true";

				_cd.EndProcessed = true;
				this.pnQueryRunning.Visible = false;
				this.pnQueryFinita.Visible = true;

				if (this.JobData.ResRecordCount.HasValue)
					this.xlblRecordDisponibili2.Text = this.JobData.ResRecordCount.ToString();
				else
					this.xlblRecordDisponibili2.Text = "0";
			}

			// se sono in un postback che ricarica tutta la pagina 
			// devo gestire la presenza o meno del bottone che ricarica la lista dei transiti.
			if (_cd.UT_DataOraRilevamentoVisualizzato == "")
			{
				if (this.JobData.DataOraRilevamento.HasValue == true)
				{
					btnQuery.Style[HtmlTextWriterStyle.Visibility] = "visible";
					btnRisultatiIntermedi.Style[HtmlTextWriterStyle.Visibility] = "visible";
				}
				else
				{
					btnQuery.Style[HtmlTextWriterStyle.Visibility] = "hidden";
					btnRisultatiIntermedi.Style[HtmlTextWriterStyle.Visibility] = "hidden";
				}
			}
			else
			{
				if (_cd.UT_DataOraRilevamentoVisualizzato == this.JobData.DataOraRilevamento.Value.ToString("G"))
				{
					btnQuery.Style[HtmlTextWriterStyle.Visibility] = "hidden";
					btnRisultatiIntermedi.Style[HtmlTextWriterStyle.Visibility] = "hidden";
				}
				else
				{
					btnQuery.Style[HtmlTextWriterStyle.Visibility] = "visible";
					btnRisultatiIntermedi.Style[HtmlTextWriterStyle.Visibility] = "visible";
				}
			}
		}


		RegisterClientId("GI",
			xlblRecordDisponibili,
			xlblStato,
			xlblAvanzamento,
			btnQuery, btnRisultatiIntermedi,

			hfClientData,

			this.UT_DataOraRilevamento,
			this.UT_Descrizione,
			this.UT_Direzione,
			this.UT_TipoVarco,
			this.UT_StatoTransito
			);

		if (!ClientScript.IsClientScriptBlockRegistered("InterventoJobId"))
		{
			string g = this.ClientScript.GetPostBackEventReference(btnQuery, "");
			string m = this.ClientScript.GetPostBackEventReference(btnRisultatiIntermedi, "");

			string s = string.Format("function DoQuery() {{ {0}; }}", g);
			s += string.Format("function MostraRisultatiIntermedi() {{ {0} }};", m);

			Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "InterventoJobId", s, true);
		}

		hfClientData.Value = ClientState.Serialize(_cd);
	}

	static bool QueryRunning(BLQueueJobs.JobStatus status)
	{
		switch (status)
		{
		case BLQueueJobs.JobStatus.QUEUE:
		case BLQueueJobs.JobStatus.RUN:
		case BLQueueJobs.JobStatus.RRES:
		case BLQueueJobs.JobStatus.SOSP:
		case BLQueueJobs.JobStatus.ABRQ:
			return true;

		case BLQueueJobs.JobStatus.ERR:
		case BLQueueJobs.JobStatus.END:
		case BLQueueJobs.JobStatus.ABAK:
		case BLQueueJobs.JobStatus.CANC:
			return false;

		default:
			Debug.Assert(false, status.ToString());
			return false;
		}
	}

	public class ClientData
	{
		public string JobId;


		public bool EndProcessed;

		public string Status;
		public string StatusDescr;
		public int? CurrentStep;
		public int? TotalSteps;
		public string ProgressMessage;
		public string ErrorMessage;
		public int? ResRecordCount;
		public string UT_DataOraRilevamento;
		public string UT_Descrizione;
		public string UT_Direzione;
		public string UT_TipoVarco;
		public string UT_StatoTransito;
		public bool? UT_EventoAssociatoAlTransito;

		public string UT_DataOraRilevamentoVisualizzato;
	}

	protected void clientTimerQueryResult_ClientCall(object sender, ITRSControls.ClientTimerClientTimerEventArgs e)
	{
		_cd = (ClientData)ClientState.Deserialize(typeof(ClientData), e.Args);

		if (true)
		{
			_cd.StatusDescr = ITRSUtility.Translate(JobData.Status);
			_cd.Status = JobData.Status.ToString();

			_cd.CurrentStep = JobData.CurrentStep;
			_cd.TotalSteps = JobData.TotalSteps;
			_cd.ProgressMessage = JobData.ProgressMessage;
			_cd.ErrorMessage = JobData.ErrorMessage;
			_cd.ResRecordCount = JobData.ResRecordCount;

			if (JobData.DataOraRilevamento.HasValue)
				_cd.UT_DataOraRilevamento = JobData.DataOraRilevamento.Value.ToString("G");
			else
				_cd.UT_DataOraRilevamento = ""; // in questo modo gli comunico che non c'e` ancora un transito

			_cd.UT_Descrizione = JobData.Descrizione;
			_cd.UT_Direzione = ITRSUtility.TranslateNullable(JobData.Direzione);
			_cd.UT_TipoVarco = ITRSUtility.TranslateNullable(JobData.TipoVarco);
			_cd.UT_StatoTransito = ITRSUtility.TranslateNullable(JobData.StatoTransito);

			_cd.UT_EventoAssociatoAlTransito = JobData.EventoAssociatoAlTransito;
		}

		e.Result = ClientState.Serialize(_cd);
	}

	protected void btnQuery_Click(object sender, EventArgs e)
	{
		this.gvTransiti.Enabled = true;
		this.gvTransiti.Visible = true;
		this.gvTransiti.DataBind();

		// posso riutilizzare il bottone dopo
		this.btnQuery.Style[HtmlTextWriterStyle.Visibility] = "hidden";
	}
	protected void btnRisultatiIntermedi_Click(object sender, EventArgs e)
	{
		this.gvTransiti.Enabled = true;
		this.gvTransiti.Visible = true;
		this.gvTransiti.DataBind();

		// posso riutilizzare il bottone dopo
		this.btnRisultatiIntermedi.Style[HtmlTextWriterStyle.Visibility] = "hidden";
	}


	protected void gvTransiti_SelectCount(object sender, ITRSControls.ExGridSelectCountEventArgs e)
	{
		try
		{
			ITRS_BL.BL_Interventi bl = new ITRS_BL.BL_Interventi();
			int r = bl.GetResultJobInterventoCount(_cd.JobId);
			e.Count = r;
		}
		catch
		{
			// per lo meno NON faccio crollare la maschera.
			// Lo sparo alla prima pagina invece che all'ultima.
			e.Count = 0;
		}
	}
	protected void gvTransiti_RowCreated(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ITRS_BL.ResultQueryIntervento row = (ITRS_BL.ResultQueryIntervento)e.Row.DataItem;
			if (row.EventoAssociatoAlTransito)
				e.Row.ForeColor = Color.Red;
		}
	}
	protected void gvTransiti_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ITRS_BL.ResultQueryIntervento row = (ITRS_BL.ResultQueryIntervento)e.Row.DataItem;

			e.Row.Cells[gvTransiti.GetCellIndex("StatoTransito")].Text = ITRSUtility.Translate(row.StatoTransito);
			e.Row.Cells[gvTransiti.GetCellIndex("Direzione")].Text = ITRSUtility.Translate(row.Direzione);
			e.Row.Cells[gvTransiti.GetCellIndex("TipoVarco")].Text = ITRSUtility.Translate(row.TipoVarco);
			e.Row.Cells[gvTransiti.GetCellIndex("StatoAllarme")].Text = ITRSUtility.Translate(row.StatoAllarme);

			if (row.IdEvento.HasValue)
			{
				e.Row.Cells[gvTransiti.GetCellIndex("IdEvento")].Text = row.IdEvento.ToString();
				e.Row.Cells[gvTransiti.GetCellIndex("DataOraInserimento")].Text = row.DataOraInserimento.ToString();
			}
			else
			{
				e.Row.Cells[gvTransiti.GetCellIndex("IdEvento")].Text = "";
				e.Row.Cells[gvTransiti.GetCellIndex("DataOraInserimento")].Text = "";
			}
		}
	}

	protected void gvTransiti_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (gvTransiti.SelectedIndex < 0)
		{
			mvListaOrDettaglio.ActiveViewIndex = 0;
			this.dettTransito.NascondiTransitoSegnalato();
			return;
		}

		DataKey pk = gvTransiti.SelectedDataKey;

		DateTime dataOraRilevamento = (DateTime)pk.Values["DataOraRilevamento"];
		string targa = (string)pk.Values["Targa"];
		string nazionalita = (string)pk.Values["Nazionalita"];

		mvListaOrDettaglio.ActiveViewIndex = 1;

		object objIdEvento = pk.Values["IdEvento"];
		object objDataOraInserimentoEvento = pk.Values["DataOraInserimento"];

		int? idEvento = null;
		if (objIdEvento != null) 
			idEvento = Convert.ToInt32(objIdEvento);

		DateTime? dtInserimento = null;
		if (objDataOraInserimentoEvento != null)
			dtInserimento = Convert.ToDateTime(objDataOraInserimentoEvento);

		this.dettTransito.VisualizzaTransitoSegnalato(targa, nazionalita, dataOraRilevamento, dtInserimento, idEvento);
	}

	protected void lnkTornaAllaLista_Click(object sender, EventArgs e)
	{
		this.dettTransito.NascondiTransitoSegnalato();
		mvListaOrDettaglio.ActiveViewIndex = 0;
	}
}
