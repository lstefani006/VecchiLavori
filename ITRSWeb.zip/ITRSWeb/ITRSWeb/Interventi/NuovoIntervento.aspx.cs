using System;
using System.Data;
using System.ComponentModel;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ITRS_BL;

public partial class Interventi_NuovoIntervento : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		try
		{
			List<ITRS_BL.BLLTSImport.Nazione> listaNazioni = BLCacher.GetListaNazioni();
			foreach (ITRS_BL.BLLTSImport.Nazione c in listaNazioni)
				ddlNazioni.Items.Add(new ListItem(c.Sigla_Nazione + " - " + c.Nome_Nazione, c.Sigla_Nazione));
			ddlNazioni.SelectedValue = "I";
		}
		catch
		{
			lblError.Text = "Errore leggendo la lista delle nazioni.";
		}
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			this.gvInterventiPerCoa.Sort("Targa", SortDirection.Ascending);
		}

		int idCoa = ITRSUtility.GetCoaDiAppartenenza();
		if (idCoa < 0)
		{
			lblError.Text = "Attenzione: questa funzionalita` e` disponibile solo per gli operatori al COA!";
			return;
		}



		// se ri-seleziono una riga gia` selezionata tolgo la selezione
		gvInterventiPerCoa.SelectedIndexChanging += new GridViewSelectEventHandler(gvInterventiPerCoa_SelectedIndexChanging);

		// la riga selezionata � cambiata: modifico il comportamento del detail view.
		gvInterventiPerCoa.SelectedIndexChanged += new EventHandler(gvInterventiPerCoa_SelectedIndexChanged);
	}
	protected void btnIniziaIntervento_Click(object sender, EventArgs e)
	{
		BL_Interventi.JobArgs ja = new BL_Interventi.JobArgs();
		ja.Targa = tbTarga.Text.ToUpper().Trim();
		ja.Nazionalita = ddlNazioni.Text.ToUpper().Trim();
		ja.IdCoa = ITRSUtility.GetCoaDiAppartenenza();
		if (ja.IdCoa < 0)
		{
			lblError.Text = "Attenzione: questa funzionalita` e` disponibile solo per gli operatori al COA!";
			return;
		}
		ja.Motivo = tbMotivo.Text;
		ja.Note = tbNote.Text;

		if (ja.Nazionalita.Length == 0)
			ja.Nazionalita = "I";

		BLQueueJobs blq = new BLQueueJobs();
		string UserPkId = blq.GetUserPkId(User.Identity.Name);

		BL_Interventi bl = new BL_Interventi();
		string jobId = bl.StartIntervento(ja, UserPkId);
		if (jobId == null)
		{
			lblError.Text = "Impossibile lanciare il job. Provare piu' tardi";
			return;
		}

		AddUserActivity(TipoAttivita.Intervento, "Nuovo intervento Targa:{0} Nazionalita`:{1} Motivo:{2}", ja.Targa, ja.Nazionalita, ja.Motivo);

		Server.Transfer("~/Interventi/GestioneIntervento.aspx?JobId=" + jobId);
	}

	protected void gvInterventiPerCoa_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		// resetto la selezione corrente se clicco una seconda volta nella stessa riga della
		// grid view
		if (e.NewSelectedIndex == gvInterventiPerCoa.SelectedIndex)
			e.NewSelectedIndex = -1;

	}

	public void gvInterventiPerCoa_SelectedIndexChanged(object sender, EventArgs e)
	{
		BL_Interventi.JobArgs ja = new BL_Interventi.JobArgs();
		ja.Targa = (string)gvInterventiPerCoa.SelectedDataKey[0];
		ja.Nazionalita = (string)gvInterventiPerCoa.SelectedDataKey[1];
		ja.IdCoa = ITRSUtility.GetCoaDiAppartenenza();
		ja.Motivo = "";
		ja.Note = "";

		BLQueueJobs blq = new BLQueueJobs();
		string UserPkId = blq.GetUserPkId(User.Identity.Name);

		BL_Interventi bl = new BL_Interventi();
		string jobId = bl.StartIntervento(ja, UserPkId); 
		if (jobId == null)
		{
			lblError.Text = "Impossibile lanciare il job. Provare piu' tardi";
			return;
		}

		AddUserActivity(TipoAttivita.Intervento, "Visualizzazione intervento Targa:{0} Nazionalita`:{1} Motivo:{2}", ja.Targa, ja.Nazionalita, ja.Motivo);

		Response.Redirect("~/Interventi/GestioneIntervento.aspx?JobId=" + jobId);
	}
	protected void gvInterventiPerCoa_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ListaInterventiPerCoaRes r = (ListaInterventiPerCoaRes)e.Row.DataItem;

			e.Row.Cells[gvInterventiPerCoa.GetCellIndex("QjStatus")].Text = ITRSUtility.Translate(r.QjStatus);
		}
	}
}

