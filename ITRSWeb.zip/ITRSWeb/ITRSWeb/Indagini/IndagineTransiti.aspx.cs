using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.IO;
using ITRS_BL;
using ZipLib = ICSharpCode.SharpZipLib;

using System.Runtime.Serialization.Formatters.Binary;

public partial class Indagini_IndagineTransiti : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		this.jobPoller.RefreshRequested += new QueuedJobs_QueueJobPoller.RefreshRequestedDelegate(jobPoller_RefreshRequested);
		this.RegisterRequiresControlState(this);

		this.PreRender += Indagini_IndagineTransiti_PreRender;

		this.trDettTransito.ExportTransito += new Dettaglio_Transito.ExportTransitoDelegate(trDettTransito_ExportTransito);
	}


	[Serializable]
	class ControlStateData
	{
		/// <summary>
		/// Indica se la griglia e` visibile
		/// </summary>
		public bool GrigliaTransitiVisibile;
		/// <summary>
		/// indica se la ricerca e` terminata.
		/// </summary>
		public bool JobStatusEnd;

		public int RecordTrovati = -1;
	}
	ControlStateData _controlStateData;

	protected override object SaveControlState() { return _controlStateData; }
	protected override void LoadControlState(object state) { _controlStateData = state as ControlStateData; }

	public string JobId
	{
		get { return hfJobId.Value; }
		set { hfJobId.Value = value; }
	}

	protected string msgRecordTrovati
	{
		get
		{
			if (_controlStateData.RecordTrovati >= 0)
				return string.Format("Trovati {0} transiti.", _controlStateData.RecordTrovati);
			else
				return "";
		}
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			_controlStateData = new ControlStateData();

			// recupero e memorizzo il JobId
			this.JobId = Request["JobId"];
			if (string.IsNullOrEmpty(this.JobId))
				return;

			this.jobPoller.StartPollingJob(this.JobId);

			this.gvIndagineTransiti.Sort("DataOraRilevamento", SortDirection.Ascending);
			this.gvIndagineEventi.Sort("DataOraInserimento", SortDirection.Ascending);

		}

		if (!IsCallback)
		{
			BLIndagini bl = new BLIndagini();
			IndaginiQueueJob JobData = bl.GetJobData(this.JobId);

			lblTarga.Text = JobData.JobArgs.Targa;
			lblNazionalita.Text = JobData.JobArgs.Nazionalita;
			lblDataOraInizio.Text = ITRSUtility.PrintDataOra(JobData.JobArgs.DataInizio);
			lblDataOraFine.Text = ITRSUtility.PrintDataOra(JobData.JobArgs.DataFine.AddSeconds(-1));
			lblAreaDiServizio.Text = JobData.JobArgs.DescrizioneC2P;
		}

	}

	void Indagini_IndagineTransiti_PreRender(object sender, EventArgs e)
	{
		if (_controlStateData.JobStatusEnd && User.IsInRole("Export"))
		{
			btnExport.Visible = true;
			ckbxExportConImmagini.Visible = true;
			trDettTransito.ExportTransitoVisible = true;
		}
		else
		{
			btnExport.Visible = false;
			ckbxExportConImmagini.Visible = false;
			trDettTransito.ExportTransitoVisible = false;
		}

		this.gvIndagineTransiti.Visible = _controlStateData.GrigliaTransitiVisibile;
	}

	void jobPoller_RefreshRequested(object sender, QueuedJobs_QueueJobPoller.RefreshEvent e)
	{
		if (e.QueueJob.Status == BLQueueJobs.JobStatus.END)
		{
			this.jobPoller.Visible = false;
			this._controlStateData.GrigliaTransitiVisibile = true;
			this._controlStateData.JobStatusEnd = true;

			try
			{
				ITRS_BL.BLIndagini bl = new ITRS_BL.BLIndagini();
				int r = bl.GetResultJobIndagineCount(this.JobId);
				this._controlStateData.RecordTrovati = r;
			}
			catch
			{
				this._controlStateData.RecordTrovati = -1;
			}
		}
		else if (e.QueueJob.Status == BLQueueJobs.JobStatus.RRES)
		{
			this._controlStateData.GrigliaTransitiVisibile = true;
		}
		else if (e.MostraRisultatiIntermedi)
		{
			this._controlStateData.GrigliaTransitiVisibile = true;
			this._controlStateData.RecordTrovati = -1;
		}
	}


	protected void gvIndagineTransiti_SelectedIndexChanged(object sender, EventArgs e)
	{
		hfTransitoSelezionatoTarga.Value = "";
		hfTransitoSelezionatoNazionalita.Value = "";
		hfTransitoSelezionatoDataOraRilevamento.Value = "";

		if (gvIndagineTransiti.SelectedIndex < 0)
		{
			this.trDettEvento.NascondiEvento();
			this.trDettTransito.NascondiTS();
			this.trDettImmagine.NascondiImmagine();
			return;
		}

		DataKey pk = gvIndagineTransiti.SelectedDataKey;
		DateTime dataOraRilevamento = (DateTime)pk.Values["DataOraRilevamento"];
		string targa = (string)pk.Values["Targa"];
		string nazionalita = (string)pk.Values["Nazionalita"];

		this.trDettTransito.VisualizzaTS(targa, nazionalita, dataOraRilevamento);
		this.trDettImmagine.VisualizzaImmagine(targa, nazionalita, dataOraRilevamento);
		this.trDettEvento.NascondiEvento();


		this.hfTransitoSelezionatoTarga.Value = targa;
		this.hfTransitoSelezionatoNazionalita.Value = nazionalita;
		this.hfTransitoSelezionatoDataOraRilevamento.Value = dataOraRilevamento.ToString();
	}

	protected void gvIndagineTransiti_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ITRS_BL.ResultQueryIndagineTransito row = (ITRS_BL.ResultQueryIndagineTransito)e.Row.DataItem;

			e.Row.Cells[gvIndagineTransiti.GetCellIndex("EnumStatoTransito")].Text = ITRSUtility.Translate(row.EnumStatoTransito);
			e.Row.Cells[gvIndagineTransiti.GetCellIndex("C2p_Direzione")].Text = ITRSUtility.Translate(row.C2p_Direzione);
			e.Row.Cells[gvIndagineTransiti.GetCellIndex("EnumTipoVarco")].Text = ITRSUtility.Translate(row.EnumTipoVarco);

			// il mapping tra Targa/TargaAcquisita lo fa la query!!!

		}
	}
	protected void gvIndagineTransiti_SelectCount(object sender, ITRSControls.ExGridSelectCountEventArgs e)
	{
		try
		{
			if (_controlStateData.RecordTrovati >= 0)
			{
				e.Count = _controlStateData.RecordTrovati;
			}
			else
			{
				ITRS_BL.BLIndagini bl = new ITRS_BL.BLIndagini();
				int r = bl.GetResultJobIndagineCount(this.JobId);
				e.Count = r;
				_controlStateData.RecordTrovati = r;
			}
		}
		catch
		{
			// per lo meno NON faccio crollare la maschera.
			// Lo sparo alla prima pagina invece che all'ultima.
			e.Count = 0;
			_controlStateData.RecordTrovati = -1;
		}
	}

	/////////////////////////////////////////////////////////////


	protected void gvIndagineEventi_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ITRS_BL.Evento row = (ITRS_BL.Evento)e.Row.DataItem;

			e.Row.Cells[gvIndagineEventi.GetCellIndex("TipoEvento")].Text = ITRSUtility.Translate(row.TipoEvento);
			e.Row.Cells[gvIndagineEventi.GetCellIndex("StatoAllarme")].Text = ITRSUtility.Translate(row.StatoAllarme);
		}
	}
	protected void gvIndagineEventi_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (gvIndagineEventi.SelectedIndex < 0)
		{
			this.trDettEvento.NascondiEvento();

			return;
		}

		DataKey pk = gvIndagineEventi.SelectedDataKey;

		string targa = (string)pk.Values["Targa"];
		string nazionalita = (string)pk.Values["Nazionalita"];
		DateTime dataOraInserimento = (DateTime)pk.Values["DataOraInserimento"];
		int IdEvento = Convert.ToInt32(pk.Values["IdEvento"]);

		this.trDettEvento.VisualizzaEvento(targa, nazionalita, dataOraInserimento, IdEvento);
	}


	protected void btnExport_Click(object sender, EventArgs e)
	{
		// registro i dati che serviranno quando l'op preme Export
		IndagineInterventoData dd = new IndagineInterventoData();
		dd.sortExpression = gvIndagineTransiti.SortExpression;
		dd.sortDirection = gvIndagineTransiti.SortDirection;
		dd.jobId = this.JobId;
		dd.includiImmagini = ckbxExportConImmagini.Checked;

		AddUserActivity(TipoAttivita.Indagine, "Export transiti");

		MemoryStream ms = new MemoryStream();
		BinaryFormatter bf = new BinaryFormatter();
		bf.Serialize(ms, dd);
		string gg = Convert.ToBase64String(ms.ToArray());
		dnlWindow.Attributes["src"] = "/ITRSWeb/Indagini/ExportIndagine.aspx?Action=" + Server.UrlEncode(gg);

		if (dd.includiImmagini)
			lblExportLanciato.Visible = true;
	}

	void trDettTransito_ExportTransito(object sender, Dettaglio_Transito.ExportTransitoEvent e)
	{
		ExportIndagineDettaglioTransito dd = new ExportIndagineDettaglioTransito();
		dd.Targa = e.Targa;
		dd.Nazionalita = e.Nazionalita;
		dd.DataOraRilevamento = e.DataOraRilevamento;
		dd.JobId = this.JobId;
		

		AddUserActivity(TipoAttivita.Indagine, "Export transito selezionato");

		MemoryStream ms = new MemoryStream();
		BinaryFormatter bf = new BinaryFormatter();
		bf.Serialize(ms, dd);
		string gg = Convert.ToBase64String(ms.ToArray());
		dnlWindow.Attributes["src"] = "/ITRSWeb/DownloadGeneric.aspx?Action=" + Server.UrlEncode(gg);
	}
}
