using System;
using System.Data;
using System.IO;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

using System.Runtime.Serialization.Formatters.Binary;

using ITRS_BL;
using ZipLib = ICSharpCode.SharpZipLib;


public partial class Indagini_ExportIndagine : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			string action = Request.QueryString["Action"];
			if (string.IsNullOrEmpty(action))
				return;

			done.Value = action;

			string s = @"window.setTimeout('document.downloadFileForm.btnDownload.click()', 1000);";
			ClientScript.RegisterStartupScript(GetType(), "downloadFileFormTag", s, true);
		}
	}

	protected void btnDownload_Click(object sender, EventArgs e)
	{
		DoDownload();
	}


	private void DoDownload()
	{
		string action = done.Value;

		if (string.IsNullOrEmpty(action))
			return;

		done.Value = "";

		BinaryFormatter bf = new BinaryFormatter();
		IndagineInterventoData dt = bf.Deserialize(new MemoryStream(Convert.FromBase64String(action))) as IndagineInterventoData;

		string sortColumn = dt.sortExpression;
		if (dt.sortDirection == SortDirection.Descending) sortColumn += " desc";

		List<ResultQueryIndagineTransito> r;
		IndaginiQueueJob JobData;
		using (ITRS_BL.BLIndagini bl = new BLIndagini())
		{
			r = bl.GetResultJobIndagineTransiti(dt.jobId, sortColumn, dt.includiImmagini, 0, 0);
			JobData = bl.GetJobData(dt.jobId);
		}

		string rootDir = Path.Combine(System.IO.Path.GetTempPath(), Guid.NewGuid().ToString());
		System.IO.Directory.CreateDirectory(rootDir);

		// nome della directory delle immagini e nome del file html (senza .html)
		string prefix = string.Format("RicercaTransiti_{0:yyyy}{0:MM}{0:dd}_{0:HH}{0:mm}{0:ss}", DateTime.Now);

		// file html (con lo stesso nome della directory delle immagini + .html)
		string htmlFileName = string.Format("{0}.htm", prefix);

		// directory associata al file .hmt - stesso nome con appeso _files
		string htmlFilesDir = string.Format("{0}_files", prefix);

		// directory per le immagini.
		System.IO.Directory.CreateDirectory(rootDir + "\\" + htmlFilesDir);


		List<string> files = new List<string>();

		files.Add(htmlFileName);
		using (StreamWriter fs = File.CreateText(Path.Combine(rootDir, htmlFileName)))
		{
			fs.WriteLine("<h1>Ricerca rintraccio COA Transiti<h1>");

			fs.WriteLine("<h2>Dati ricerca e rintraccio<h2>");
			fs.WriteLine("<table>");
			fs.WriteLine("<tr><td>Targa:</td><td>{0}</td></tr>", JobData.JobArgs.Targa);
			fs.WriteLine("<tr><td>Nazionalita`:</td><td>{0}</td></tr>", JobData.JobArgs.Nazionalita);
			fs.WriteLine("<tr><td>Inizio ricerca:</td><td>{0}</td></tr>", JobData.JobArgs.DataInizio);
			fs.WriteLine("<tr><td>Fine ricerca:</td><td>{0}</td></tr>", JobData.JobArgs.DataFine);
			fs.WriteLine("<tr><td>Area di servizio:</td><td>{0}</td></tr>", JobData.JobArgs.DescrizioneC2P);
			fs.WriteLine("</table>");

			fs.WriteLine("<h2>Risultati ricerca e rintraccio<h2>");
			fs.WriteLine("<table border='1' >");
			{
				fs.WriteLine("<tr>");
				{
					fs.WriteLine("<td>Targa</td>");
					fs.WriteLine("<td>Nazionalita`</td>");
					fs.WriteLine("<td>Rivelato il</td>");
					fs.WriteLine("<td>Area di servizio</td>");
					fs.WriteLine("<td>Direzione</td>");
					fs.WriteLine("<td>Varco</td>");
					fs.WriteLine("<td>Stato</td>");
					if (dt.includiImmagini)
						fs.WriteLine("<td>Foto</td>");
				}
				fs.WriteLine("</tr>");

				int n = 0;

				foreach (ResultQueryIndagineTransito qi in r)
				{
					n++;
					if (n % 100 == 0)
						Log.Write("Export ricerca/rintraccio {0}/{1}", n, r.Count);

					fs.WriteLine("<tr>");
					{
						fs.WriteLine("<td>{0}</td>", qi.TargaAcquisita);
						fs.WriteLine("<td>{0}</td>", qi.NazionalitaAcquisita);
						fs.WriteLine("<td>{0}</td>", qi.DataOraRilevamento);
						fs.WriteLine("<td>{0}</td>", qi.C2p_Descrizione);
						fs.WriteLine("<td>{0}</td>", ITRSUtility.Translate(qi.C2p_Direzione));
						fs.WriteLine("<td>{0}</td>", ITRSUtility.Translate(qi.EnumTipoVarco));
						fs.WriteLine("<td>{0}</td>", ITRSUtility.Translate(qi.EnumStatoTransito));


						if (dt.includiImmagini)
						{
							string imgPath = string.Format("{0}/img_{1}.jpg", htmlFilesDir, n);

							if (qi.Immagine == null)
							{
								using (BLTransiti bl2 = new BLTransiti())
								{
									bool imgInC2P;
									qi.Immagine = bl2.GetBlobImmagine(qi.Targa, qi.Nazionalita, qi.DataOraRilevamento, out imgInC2P);
								}
							}

							if (qi.Immagine != null)
							{
								fs.WriteLine("<td><a href='{0}' />Apri</td>", imgPath);

								files.Add(imgPath);
								using (FileStream fImg = File.Create(Path.Combine(rootDir, imgPath)))
								{
									fImg.Write(qi.Immagine, 0, qi.Immagine.Length);
								}
							}
							else
								fs.WriteLine("<td>Immagine non disponibile</td>");
						}
					}
					fs.WriteLine("</tr>");
				}
				fs.WriteLine("</table>");
			}
		}

		// zip
		string fnzip = Path.GetFileNameWithoutExtension(htmlFileName) + ".zip";
		WU.ZipHtml(rootDir, files, fnzip);

		bool bUsaNuovoTransferimento = true;

		if (bUsaNuovoTransferimento)
		{
			WU.SendFile(Response, rootDir + "\\" + fnzip, fnzip);
			Directory.Delete(rootDir, true);
		}
		else
		{
			SendFileOld(rootDir, fnzip);
		}
	}

	private void SendFileOld(string g, string fnzip)
	{
		// download
		byte[] buff = null;
		using (FileStream srz = File.OpenRead(g + "\\" + fnzip))
		{
			buff = new byte[srz.Length];
			int rd = 0;
			while (rd < srz.Length)
				rd += srz.Read(buff, rd, buff.Length - rd);
		}

		// delete del file
		Directory.Delete(g, true);

		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "application/octet-stream";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", fnzip));
		Response.AddHeader("Content-Length", buff.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(buff);
		Response.End();
	}
}
