using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.IO;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Runtime.Serialization.Formatters.Binary;
using ITRS_BL;

public partial class Indagini_IndagineEventi : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		this.jobPoller.RefreshRequested += new QueuedJobs_QueueJobPoller.RefreshRequestedDelegate(jobPoller_RefreshRequested);
		this.RegisterRequiresControlState(this);

		this.PreRender += Indagini_IndagineEventi_PreRender;
	}

	void Indagini_IndagineEventi_PreRender(object sender, EventArgs e)
	{
		if (_controlStateData.JobStatusEnd && User.IsInRole("Export"))
		{
			ckbxExportConImmagini.Visible = true;
			btnExport.Visible = true;
		}
		else
		{
			ckbxExportConImmagini.Visible = false;
			btnExport.Visible = false;
		}

		this.gvIndagineEventi.Visible = _controlStateData.GrigliaEventiVisibile;
	}

	[Serializable]
	class ControlStateData
	{
		/// <summary>
		/// Indica se la griglia e` visibile
		/// </summary>
		public bool GrigliaEventiVisibile;
		/// <summary>
		/// indica se la ricerca e` terminata.
		/// </summary>
		public bool JobStatusEnd;
	}
	ControlStateData _controlStateData;


	protected override object SaveControlState() { return _controlStateData; }
	protected override void LoadControlState(object state) { _controlStateData = state as ControlStateData; }

	public string JobId { get { return hfJobId.Value; } set { hfJobId.Value = value; } }

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			this._controlStateData = new ControlStateData();

			// recupero e memorizzo il JobId
			this.JobId = Request["JobId"];
			if (string.IsNullOrEmpty(this.JobId))
				return;

			this.jobPoller.StartPollingJob(this.JobId);

			this.gvIndagineEventi.Sort("Targa", SortDirection.Ascending);
			this.gvIndagineTransiti.Sort("DataOraRilevamento", SortDirection.Ascending);
		}

		if (!IsCallback)
		{
			BLIndagini bl = new BLIndagini();
			IndaginiQueueJob JobData = bl.GetJobData(this.JobId);

			lblTarga.Text = JobData.JobArgs.Targa;
			lblNazionalita.Text = JobData.JobArgs.Nazionalita;
			lblDataOraInizio.Text = ITRSUtility.PrintDataOra(JobData.JobArgs.DataInizio);
			lblDataOraFine.Text = ITRSUtility.PrintDataOra(JobData.JobArgs.DataFine.AddSeconds(-1));
			lblAreaDiServizio.Text = JobData.JobArgs.DescrizioneC2P;

			if (JobData.JobArgs.TipoEvento.HasValue)
				lblTipoEvento.Text = ITRSUtility.Translate(JobData.JobArgs.TipoEvento);
			else
				lblTipoEvento.Text = "Tutti";
		}
	}


	void jobPoller_RefreshRequested(object sender, QueuedJobs_QueueJobPoller.RefreshEvent e)
	{
		if (e.QueueJob.Status == BLQueueJobs.JobStatus.END)
		{
			this.jobPoller.Visible = false;
			this._controlStateData.GrigliaEventiVisibile = true;
			this._controlStateData.JobStatusEnd = true;
		}
		else if (e.QueueJob.Status == BLQueueJobs.JobStatus.RRES)
		{
			this._controlStateData.GrigliaEventiVisibile = true;
		}
		else if (e.MostraRisultatiIntermedi)
		{
			this._controlStateData.GrigliaEventiVisibile = true;
		}
	}


	protected void gvIndagineEventi_SelectedIndexChanged(object sender, EventArgs e)
	{
		hfEventoSelezionatoTarga.Value = "";
		hfEventoSelezionatoNazionalita.Value = "";
		hfEventoSelezionatoDataOraInserimento.Value = "";
		hfEventoSelezionatoIdEvento.Value = "";

		if (gvIndagineEventi.SelectedIndex < 0)
		{
			this.trDettTransito.NascondiTS();
			this.trDettEvento.NascondiEvento();
			this.trDettImmagine.NascondiImmagine();
			return;
		}

		DataKey pk = gvIndagineEventi.SelectedDataKey;
		DateTime dataOraInserimento = (DateTime)pk.Values["DataOraInserimento"];
		string targa = (string)pk.Values["Targa"];
		string nazionalita = (string)pk.Values["Nazionalita"];
		int idEvento = Convert.ToInt32(pk.Values["IdEvento"]);

		this.trDettEvento.VisualizzaEvento(targa, nazionalita, dataOraInserimento, idEvento);

		this.trDettImmagine.NascondiImmagine();
		this.trDettTransito.NascondiTS();


		this.hfEventoSelezionatoTarga.Value = targa;
		this.hfEventoSelezionatoNazionalita.Value = nazionalita;
		this.hfEventoSelezionatoDataOraInserimento.Value = dataOraInserimento.ToString();
		this.hfEventoSelezionatoIdEvento.Value = idEvento.ToString();
	}

	protected void gvIndagineEventi_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ITRS_BL.ResultQueryIndagineEvento row = (ITRS_BL.ResultQueryIndagineEvento)e.Row.DataItem;

			e.Row.Cells[gvIndagineEventi.GetCellIndex("EnumTipoEvento")].Text = ITRSUtility.Translate(row.EnumTipoEvento);
			e.Row.Cells[gvIndagineEventi.GetCellIndex("EnumStatoAllarme")].Text = ITRSUtility.Translate(row.EnumStatoAllarme);
		}
	}

	protected void gvIndagineEventi_SelectCount(object sender, ITRSControls.ExGridSelectCountEventArgs e)
	{
		try
		{
			ITRS_BL.BLIndagini bl = new ITRS_BL.BLIndagini();
			int r = bl.GetResultJobIndagineCount(this.JobId);
			e.Count = r;
		}
		catch
		{
			// per lo meno NON faccio crollare la maschera.
			// Lo sparo alla prima pagina invece che all'ultima.
			e.Count = 0;
		}
	}


	/////////////////////////////////////////////////////////////


	protected void gvIndagineTransiti_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ITRS_BL.DatiTransito row = (ITRS_BL.DatiTransito)e.Row.DataItem;

			e.Row.Cells[gvIndagineTransiti.GetCellIndex("StatoTransito")].Text = ITRSUtility.Translate(row.StatoTransito);
			e.Row.Cells[gvIndagineTransiti.GetCellIndex("DirezioneC2P")].Text = ITRSUtility.Translate(row.DirezioneC2P);
			e.Row.Cells[gvIndagineTransiti.GetCellIndex("TipoVarco")].Text = ITRSUtility.Translate(row.TipoVarco);
		}
	}
	protected void gvIndagineTransiti_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (gvIndagineTransiti.SelectedIndex < 0)
		{
			this.trDettTransito.NascondiTS();
			this.trDettImmagine.NascondiImmagine();

			return;
		}

		DataKey pk = gvIndagineTransiti.SelectedDataKey;

		string targa = (string)pk.Values["Targa"];
		string nazionalita = (string)pk.Values["Nazionalita"];
		DateTime dataOraRilevamento = (DateTime)pk.Values["DataOraRilevamento"];

		this.trDettTransito.VisualizzaTS(targa, nazionalita, dataOraRilevamento);
		this.trDettImmagine.VisualizzaImmagine(targa, nazionalita, dataOraRilevamento);
	}


	protected void btnExport_Click(object sender, EventArgs e)
	{
		// registro i dati che serviranno quando l'op preme Export
		IndagineEventoData dd = new IndagineEventoData();
		dd.sortExpression = gvIndagineEventi.SortExpression;
		dd.sortDirection = gvIndagineEventi.SortDirection;
		dd.jobId = this.JobId;
		dd.includiImmagini = ckbxExportConImmagini.Checked;

		AddUserActivity(TipoAttivita.Indagine, "Export eventi");


		MemoryStream ms = new MemoryStream();
		BinaryFormatter bf = new BinaryFormatter();
		bf.Serialize(ms, dd);
		string gg = Convert.ToBase64String(ms.ToArray());
		dnlWindow.Attributes["src"] = "/ITRSWeb/Indagini/ExportIndaginiEventi.aspx?Action=" + Server.UrlEncode(gg);

		if (dd.includiImmagini)
			lblExportLanciato.Visible = true;
	}
}
