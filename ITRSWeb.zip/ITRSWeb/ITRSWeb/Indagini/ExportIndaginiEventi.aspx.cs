using System;
using System.Data;
using System.IO;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

using System.Runtime.Serialization.Formatters.Binary;

using ITRS_BL;

public partial class Indagini_ExportIndaginiEventi : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			string action = Request.QueryString["Action"];
			if (string.IsNullOrEmpty(action))
				return;

			done.Value = action;

			string s = @"window.setTimeout('document.form1.btnDownload.click()', 1000);";
			ClientScript.RegisterStartupScript(GetType(), "ExportIndaginiEventiTag", s, true);
		}

	}

	protected void btnDownload_Click(object sender, EventArgs e)
	{
		DoDownload();
	}

	void DoDownload()
	{
		string action = done.Value;

		if (string.IsNullOrEmpty(action))
			return;

		done.Value = "";

		BinaryFormatter bf = new BinaryFormatter();
		IndagineEventoData dt = bf.Deserialize(new MemoryStream(Convert.FromBase64String(action))) as IndagineEventoData;

		string sortColumn = dt.sortExpression;
		if (dt.sortDirection == SortDirection.Descending) sortColumn += " desc";


		string rootDir = Path.Combine(System.IO.Path.GetTempPath(), Guid.NewGuid().ToString());
		System.IO.Directory.CreateDirectory(rootDir);

		string prefix = string.Format("RicercaEventi_{0:yyyy}{0:MM}{0:dd}_{0:HH}{0:mm}{0:ss}", DateTime.Now);


		string fn = string.Format("{0}.html", prefix);
		string fnDir = string.Format("{0}_files", prefix);

		System.IO.Directory.CreateDirectory(rootDir + "\\" + fnDir);


		int n = 0;
		List<string> files = new List<string>();
		files.Add(fn);
		using (StreamWriter fs = File.CreateText(Path.Combine(rootDir, fn)))
		{
			IndaginiQueueJob JobData;
			List<ResultQueryIndagineEvento> listaEventi;
			using (BLIndagini bl = new BLIndagini())
			{
				JobData = bl.GetJobData(dt.jobId);
				listaEventi = bl.GetResultJobIndagineEventi(dt.jobId, sortColumn, 0, 0);
			}


			fs.WriteLine("<h1>Ricerca e rintraccio eventi<h1>");

			fs.WriteLine("<h2>Dati ricerca e rintraccio<h2>");
			fs.WriteLine("<table>");
			fs.WriteLine("<tr><td>Targa:</td><td>{0}</td></tr>", JobData.JobArgs.Targa);
			fs.WriteLine("<tr><td>Nazionalita`:</td><td>{0}</td></tr>", JobData.JobArgs.Nazionalita);
			fs.WriteLine("<tr><td>Inizio ricerca:</td><td>{0}</td></tr>", JobData.JobArgs.DataInizio);
			fs.WriteLine("<tr><td>Fine ricerca:</td><td>{0}</td></tr>", JobData.JobArgs.DataFine);
			fs.WriteLine("<tr><td>Area di servizio:</td><td>{0}</td></tr>", JobData.JobArgs.DescrizioneC2P);

			if (JobData.JobArgs.TipoEvento.HasValue)
				fs.WriteLine("<tr><td>Tipo evento:</td><td>{0}</td></tr>", ITRSUtility.Translate(JobData.JobArgs.TipoEvento));
			else
				fs.WriteLine("<tr><td>Tipo evento:</td><td>{0}</td></tr>", "Tutti");
			fs.WriteLine("</table>");

			fs.WriteLine("<h2>Risultati ricerca e rintraccio<h2>");
			fs.WriteLine("<table border='1' >");
			{
				fs.WriteLine("<tr>");
				{
					fs.WriteLine("<td>Targa</td>");
					fs.WriteLine("<td>Nazionalita`</td>");
					fs.WriteLine("<td>Inserito il</td>");
					fs.WriteLine("<td>Tipo evento</td>");
					fs.WriteLine("<td>Coa di competenza</td>");
					fs.WriteLine("<td>Stato</td>");
					fs.WriteLine("<td>Dettagli</td>");
					if (dt.includiImmagini)
						fs.WriteLine("<td>Foto</td>");
				}
				fs.WriteLine("</tr>");

				foreach (ResultQueryIndagineEvento qi in listaEventi)
				{
					n++;
					if (n % 100 == 0)
						Log.Write("Export eventi {0}/{1}", n, listaEventi.Count);

					fs.WriteLine("<tr>");
					{
						fs.WriteLine("<td>{0}</td>", qi.Targa);
						fs.WriteLine("<td>{0}</td>", qi.Nazionalita);
						fs.WriteLine("<td>{0}</td>", qi.DataOraInserimento.ToString());
						fs.WriteLine("<td>{0}</td>", ITRSUtility.Translate(qi.EnumTipoEvento));
						fs.WriteLine("<td>{0}</td>", qi.COADiCompetenza);
						fs.WriteLine("<td>{0}</td>", ITRSUtility.Translate(qi.EnumStatoAllarme));

						if (qi.EnumTipoEvento != TipoEvento.TS)
						{
							fs.WriteLine("<td>N.A.</td>"); // Dettagli 
							if (dt.includiImmagini)
								fs.WriteLine("<td>N.A.</td>"); // Foto
						}
						else
						{
							string imgPath = string.Format("{0}/img_{1}.jpg", fnDir, n);

							using (BLTransiti blTr = new BLTransiti())
							{
								List<DatiTransito> dtr;
								dtr = blTr.GetTransitiDellEvento(qi.Targa, qi.Nazionalita, qi.DataOraInserimento, (int)qi.IdEvento, "Targa");
								if (dtr.Count >= 1)
								{
									fs.WriteLine("<td>"); // Dettagli
									if (true)
									{
										fs.WriteLine("<table>");
										fs.WriteLine("<tr><td>Rilevato il:</td><td>{0}</td></tr>", dtr[0].DataOraRilevamento.ToString());
										fs.WriteLine("<tr><td>Area di servizio</td><td>{0}</td></tr>", dtr[0].DescrizioneC2P);
										fs.WriteLine("<tr><td>Direzione</td><td>{0}</td></tr>", ITRSUtility.Translate(dtr[0].DirezioneC2P));
										fs.WriteLine("<tr><td>Varco</td><td>{0}</td></tr>", ITRSUtility.Translate(dtr[0].TipoVarco));
										fs.WriteLine("<tr><td>Stato</td><td>{0}</td></tr>", ITRSUtility.Translate(dtr[0].StatoTransito));
										fs.WriteLine("</table>");
									}
									fs.WriteLine("</td>");

									// Foto
									if (dt.includiImmagini)
									{
										bool imgInC2P;
										using (BLTransiti bl2 = new BLTransiti())
										{
											byte[] a = bl2.GetBlobImmagine(qi.Targa, qi.Nazionalita, dtr[0].DataOraRilevamento, out imgInC2P);

											if (a != null)
											{
												fs.WriteLine("<td><a href='{0}' />Apri</td>", imgPath);

												files.Add(imgPath);
												using (FileStream fImg = File.Create(Path.Combine(rootDir, imgPath)))
												{
													fImg.Write(a, 0, a.Length);
												}
											}
											else
												fs.WriteLine("<td>Immagine non disponibile</td>");
										}
									}
								}
								else
								{
									fs.WriteLine("<td>N.A.</td>"); // Dettagli 
									if (dt.includiImmagini)
										fs.WriteLine("<td>N.A.</td>"); // Foto
								}
							}
						}
					}
					fs.WriteLine("</tr>");
				}
				fs.WriteLine("</table>");
			}
		}

		// zip
		string fnzip = Path.GetFileNameWithoutExtension(fn) + ".zip";
		WU.ZipHtml(rootDir, files, fnzip);

		// download
		bool usaSendFileNuovo = true;
		if (usaSendFileNuovo)
		{
			WU.SendFile(Response, rootDir + "\\" + fnzip, fnzip);
			Directory.Delete(rootDir, true);
		}
		else
		{
			SendFileOld(rootDir, fnzip);
		}
	}

	private void SendFileOld(string g, string fnzip)
	{
		byte[] buff = null;
		using (FileStream srz = File.OpenRead(g + "\\" + fnzip))
		{
			buff = new byte[srz.Length];
			int rd = 0;
			while (rd < srz.Length)
				rd += srz.Read(buff, rd, buff.Length - rd);
		}

		// delete
		Directory.Delete(g, true);

		// risposta.
		Response.Clear();
		//Response.ContentType = "application/x-zip-compressed";
		Response.ContentType = "application/octet-stream";
		Response.AddHeader("Content-Disposition", string.Format("Attachment; filename=\"{0}\"", fnzip));
		Response.AddHeader("Content-Length", buff.Length.ToString());

		Response.BufferOutput = true;
		Response.BinaryWrite(buff);
		Response.End();
	}


}
