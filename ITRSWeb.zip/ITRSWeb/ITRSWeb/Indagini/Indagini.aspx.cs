using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ITRS_BL;

public partial class Indagini_Indagini : PageBase
{
	protected void Page_Init(object sender, EventArgs e)
	{
		int n = 0;
		foreach (ListItem li in this.rbTipoRicerca.Items)
		{
			li.Attributes.Add("onclick", "OnChangeTipoRicerca(" + n.ToString() + ");");
			n++;
		}

		ddlAreaDiServizio.Items.Clear();
		ddlAreaDiServizio.Items.Add(new ListItem("Tutte", "-1"));
		foreach (Coa t in BLCacher.GetListaCOA())
		{
			ListItem li = new ListItem("di comp. " + t.Descrizione, (-10 - t.IdCOA).ToString());
			ddlAreaDiServizio.Items.Add(li);
		}
		BLCacher.FillFromC2P(ddlAreaDiServizio);

		try
		{
			List<ITRS_BL.BLLTSImport.Nazione> listaNazioni = BLCacher.GetListaNazioni();
			ddlNazioni.Items.Add(new ListItem("* - tutte le nazioni", ""));
			foreach (ITRS_BL.BLLTSImport.Nazione c in listaNazioni)
				ddlNazioni.Items.Add(new ListItem(c.Sigla_Nazione + " - " + c.Nome_Nazione, c.Sigla_Nazione));
			ddlNazioni.SelectedValue = "";
		}
		catch
		{
		}

	}

	protected void Page_Load(object sender, EventArgs e)
	{
		base.RegisterClientId("Indg", tbDI, tbDF);


		if (!IsPostBack)
		{
			// Vediamo se c'era una indagine attiva...
			if (Request.Cookies["LastIndagine"] != null)
			{
				BLQueueJobs blq2 = new BLQueueJobs();
				try
				{
					string JobId = hfJobId.Value = Request.Cookies["LastIndagine"].Value;
					IndaginiQueueJob qj = (IndaginiQueueJob)blq2.GetRunningJobData(JobId);
					blq2.Access(JobId);

					// Se arrivo qui, il job esiste
					BLIndagini.JobArgs ja = qj.JobArgs;
					txtTarga.Text = ja.Targa;
					ddlNazioni.SelectedValue = ja.Nazionalita == null ? string.Empty : ja.Nazionalita;

					btnRicerca.Text = "Nuova Ricerca";
					btnAttivaOldIndagine.Visible = true;
					if (ja.VoglioTransiti)
						rbTipoRicerca.SelectedIndex = 0;
					else
					{
						rbTipoRicerca.SelectedIndex = 1;

						// TODO: Attivare la riga con la combo del tipo evento
						Control ctrlRiga = tbDatiIndagine.FindControl("RigaTipoEvento");
						HtmlTableRow tr = (HtmlTableRow)ctrlRiga;
						tr.Style[HtmlTextWriterStyle.Visibility] = "visible";

						// e selezionare la riga giusta
						if (!ja.TipoEvento.HasValue)
						{
							ddlTipoEvento.SelectedIndex = 0;
						}
						else
						{
							string te = ITRSUtility.Translate(ja.TipoEvento.Value);
							ddlTipoEvento.Items.FindByText(te).Selected = true;
						}
					}
					// Selezionare la riga giusta nella combo del C2P
					ddlAreaDiServizio.Items.FindByText(ja.DescrizioneC2P).Selected = true;
					tbDI.Text = ja.DataInizio.ToString();
					tbDF.Text = ja.DataFine.ToString();
				}
				catch
				{
				}
			}
		}

		RegisterClientId("SI", this.tbDatiIndagine.FindControl("RigaTipoEvento"));

		if (!Page.ClientScript.IsStartupScriptRegistered("Indagini_ChangeTipoRicerca"))
		{
			string s = @"
function OnChangeTipoRicerca(n)
{
    var c = SI.RigaTipoEvento();
	if (c != null)
	{
		if (n == 0)
			c.style.visibility='hidden';
		else
			c.style.visibility = 'visible';
	}
}

";
			Page.ClientScript.RegisterStartupScript(this.GetType(), "Indagini_ChangeTipoRicerca", s, true);
		}
	}

	protected void btnRicerca_Click(object sender, EventArgs e)
	{
		// I controlli con validazione non mi fanno neanche arrivare qui se la
		// validazione non ha successo....
		BLIndagini bl = new BLIndagini();
		BLIndagini.JobArgs ja = new BLIndagini.JobArgs();

		// Compilare i job args a partire dai TextBox
		if (txtTarga.Text.Length == 0)
			ja.Targa = "";
		else
			ja.Targa = txtTarga.Text.ToUpper().Trim();

		if (ddlNazioni.SelectedValue.Length == 0)
			ja.Nazionalita = null;
		else
			ja.Nazionalita = ddlNazioni.SelectedValue.ToUpper().Trim();

		if (true)
		{
			ja.IdC2P = int.Parse(ddlAreaDiServizio.SelectedValue);
			if (ja.IdC2P < 0) ja.IdC2P = null;

			if (int.Parse(ddlAreaDiServizio.SelectedValue) <= -10)
				ja.IdCoa = -10 - int.Parse(ddlAreaDiServizio.SelectedValue);
			else
				ja.IdCoa = null;

			ja.DescrizioneC2P = ddlAreaDiServizio.SelectedItem.Text;
		}

		if (rbTipoRicerca.SelectedIndex != 0)
		{
			switch (int.Parse(ddlTipoEvento.SelectedValue))
			{
			case 0:
				ja.TipoEvento = TipoEvento.TS;
				break;
			case 1:
				ja.TipoEvento = TipoEvento.VMS;
				break;
			case 2:
				ja.TipoEvento = TipoEvento.TSE;
				break;
			case 3:
				ja.TipoEvento = TipoEvento.EFV;
				break;
			case 4:
				ja.TipoEvento = TipoEvento.ENV;
				break;
			case -1:
			default:
				ja.TipoEvento = null;
				break;
			}
		}

		if (DateTime.TryParse(tbDI.Text, out ja.DataInizio) == false)
		{
			lbMessage.Text = "Formato data inizio non valido";
			return;
		}

		if (DateTime.TryParse(tbDF.Text, out ja.DataFine) == false)
		{
			lbMessage.Text = "Formato data fine non valido";
			return;
		}

		if (ja.DataFine < ja.DataInizio)
		{
			lbMessage.Text = "Data inizio maggiore di data fine";
			return;
		}
		ja.VoglioTransiti = (rbTipoRicerca.SelectedIndex == 0);

		BLQueueJobs blq = new BLQueueJobs();
		string UserPkId = blq.GetUserPkId(User.Identity.Name);

		string JobId = hfJobId.Value = bl.StartIndagine(ja, UserPkId);

		string note = tbNoteRicerca.Text;

		if (ja.VoglioTransiti)
		{
			AddUserActivity(TipoAttivita.Indagine, 
				"Nuova ricerca su transiti Targa:{0} Nazionalita`:{1} Data inizio:{2} Data fine:{3} Note:{4}", 
					ja.Targa, ja.Nazionalita, ja.DataInizio.ToString("G"), ja.DataFine.ToString("G"), note);

			Response.Cookies["LastIndagine"].Value = JobId;
			Response.Redirect("~/Indagini/IndagineTransiti.aspx?JobId=" + JobId);
		}
		else
		{
			AddUserActivity(TipoAttivita.Indagine, 
				"Nuova ricerca su eventi Targa:{0} Nazionalita`:{1} Data inizio:{2} Data fine:{3} Tipo evento:{4} Note:{5}", 
					ja.Targa, 
					ja.Nazionalita, 
					ja.DataInizio.ToString("G"), 
					ja.DataFine.ToString("G"), 
					ja.TipoEvento == null ? "tutti" : ja.TipoEvento.Value.ToString(),
					note);

			Response.Cookies["LastIndagine"].Value = JobId;
			Response.Redirect("~/Indagini/IndagineEventi.aspx?JobId=" + JobId);
		}
	}
	protected void btnAttivaOldIndagine_Click(object sender, EventArgs e)
	{
		string JobId = hfJobId.Value;
		bool VoglioTransiti = (rbTipoRicerca.SelectedIndex == 0);


		BLIndagini.JobArgs ja = null;
		try
		{
			BLQueueJobs blq2 = new BLQueueJobs();
			IndaginiQueueJob qj = (IndaginiQueueJob)blq2.GetRunningJobData(JobId);
			ja = qj.JobArgs;
		}
		catch { }


		if (VoglioTransiti)
		{
			if (ja != null)
				AddUserActivity(TipoAttivita.Indagine, "Visualizzazione ricerca su transiti Targa:{0} Nazionalita`:{1} Data inizio:{2} Data fine:{3}", ja.Targa, ja.Nazionalita, ja.DataInizio.ToString("G"), ja.DataFine.ToString("G"));

			Response.Cookies["LastIndagine"].Value = JobId;
			Response.Redirect("~/Indagini/IndagineTransiti.aspx?JobId=" + JobId);
		}
		else
		{
			if (ja != null)
				AddUserActivity(TipoAttivita.Indagine, "Visualizzazione ricerca su eventi Targa:{0} Nazionalita`:{1} Data inizio:{2} Data fine:{3} Tipo evento:{4}", ja.Targa, ja.Nazionalita, ja.DataInizio.ToString("G"), ja.DataFine.ToString("G"), ja.TipoEvento == null ? "tutti" : ja.TipoEvento.Value.ToString());

			Response.Cookies["LastIndagine"].Value = JobId;
			Response.Redirect("~/Indagini/IndagineEventi.aspx?JobId=" + JobId);
		}
	}
}
