﻿function GetNewAlarmArgs()
{
	return "";
}

function RefreshTbTransitiSegnalati(result) 
{
	if (result == "")
		return true;
		
	var r = new ClientState(result);
	
	var divTrSegnalato = SO.divTransitoSegnalatoPiuRecente();
	if (divTrSegnalato != null)
	{
		if (r.tbHtml == "")
			divTrSegnalato.innerText = "";
		else 
		{
			if (SO.hfUltimoTrSegnalato().value != r.tbTS)
			{
				divTrSegnalato.innerHTML = r.tbTS;
				SO.hfUltimoTrSegnalato().value = r.tbTS;
			}
		}
	}
	
	var de = SO.divEventi();
	if (de != null)
	{
		if (r.tbHtml == "")
			de.innerText = "";
		else
			de.innerHTML = r.tbHtml;
	}
	
	try
	{
		var ttt = document.getElementById('divAllTsPrec');
		if (r.divTsPrec == "")
			ttt.innerText = "";
		else
			ttt.innerHTML = r.divTsPrec;
	}
	catch (exDivTsPrec)
	{
	}
	
//	Sorv_Aggiornamento();
	
	return true;
}



/*
	var lastAggiornamentoSorveglianza = 0;
	
	function Sorv_Aggiornamento()
	{
		lastAggiornamentoSorveglianza = (lastAggiornamentoSorveglianza + 1) % 8;

		var agg = document.getElementById('h3Title');
		
		switch (lastAggiornamentoSorveglianza)
		{
		case 0: agg.innerText = 'Sorveglianza - allarme piu` recente  |'; break;
		case 1: agg.innerText = 'Sorveglianza - allarme piu` recente  /'; break;
		case 2: agg.innerText = 'Sorveglianza - allarme piu` recente  -'; break;
		case 3: agg.innerText = 'Sorveglianza - allarme piu` recente  \\'; break;
		case 4: agg.innerText = 'Sorveglianza - allarme piu` recente  |'; break;
		case 5: agg.innerText = 'Sorveglianza - allarme piu` recente  /'; break;
		case 6: agg.innerText = 'Sorveglianza - allarme piu` recente  -'; break;
		case 7: agg.innerText = 'Sorveglianza - allarme piu` recente  \\'; break;
		}
	}
*/


function caricaDatiDaHfValue()
{
	try
	{
		var msg = SO.hfClientData().value;
		RefreshTbTransitiSegnalati(msg);
	}
	catch (ex)
	{
		//alert(ex);
	}
}

function SorveglianzaOnSubmit()
{
	try
	{
		SO.hfUltimoTrSegnalato().value = '';
		SO.hfClientData().value;
	}
	catch (ex)
	{
	}
}


var sorvImgPopup = window.createPopup();
function sorvPopupImage(url)
{
    var oPopupBody = sorvImgPopup.document.body;
	oPopupBody.style.backgroundColor = "lightyellow";
	oPopupBody.style.border = "solid black 1px";    
    oPopupBody.innerHTML = "<img src='" + url + "' width='800' height='600'></img>";
    sorvImgPopup.show(100, 100, 800, 600);
	return false;
}

////////////////////////////////////////////////////////////////

var sorvTsPrecPopup=null;
function sorvPopupTsPrec(id,anchorname)
{
	sorvPopupTsPrec_2(id,anchorname);
}

function sorvPopupTsPrec_1(id,anchorname)
{
	if (sorvTsPrecPopup == null)
		sorvTsPrecPopup = window.createPopup();
		
    var oPopupBody = sorvTsPrecPopup.document.body;
	oPopupBody.style.backgroundColor = "lightyellow";
	oPopupBody.style.border = "solid black 1px";    
	
	var el = document.getElementById(id);
	
	var c = getAnchorWindowPosition(anchorname);
	
    oPopupBody.innerHTML = el.innerHTML;
    sorvTsPrecPopup.show(c.x - 300, c.y + 10, 300, 200, document.body);
}


function sorvPopupTsPrec_2(id, anchorname)
{
	if (sorvTsPrecPopup == null)
		sorvTsPrecPopup = new PopupWindow('PopupCalendar_Div');
	sorvTsPrecPopup.offsetY = 35;
	sorvTsPrecPopup.offsetX = -300;
	sorvTsPrecPopup.setSize('300', '200');
	sorvTsPrecPopup.autoHide();
	
	var el = document.getElementById(id);
	sorvTsPrecPopup.populate(el.innerHTML);

	sorvTsPrecPopup.showPopup(anchorname);
}
