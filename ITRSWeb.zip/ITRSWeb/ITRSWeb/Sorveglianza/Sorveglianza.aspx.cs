using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Xml;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Caching;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;

using ITRS_BL;

public partial class Sorveglianza_Sorveglianza : PageBase
{
	/// <summary>
	/// dati che vanno al client tramite il meccanismo di client callback implementato
	/// con il timer.
	/// </summary>
	class ClientData
	{
		public string tbTS = "";
		public string tbHtml = "";
		public string divTsPrec = "";
	}

	protected void Page_Init(object sender, EventArgs e)
	{
		Page.RegisterRequiresControlState(this);

		this.PreRender += new EventHandler(Sorveglianza_Sorveglianza_PreRender);

		this._dettaglioTransito.ExportTransito += trDettTransito_ExportTransito;
	}

	void trDettTransito_ExportTransito(object sender, Dettaglio_Transito.ExportTransitoEvent e)
	{
		ExportSorveglianzaDettaglioTransito dd = new ExportSorveglianzaDettaglioTransito();
		dd.Targa = e.Targa;
		dd.Nazionalita = e.Nazionalita;
		dd.DataOraRilevamento = e.DataOraRilevamento;

		AddUserActivity(TipoAttivita.Sorveglianza, "Export transito selezionato");

		MemoryStream ms = new MemoryStream();
		BinaryFormatter bf = new BinaryFormatter();
		bf.Serialize(ms, dd);
		string gg = Convert.ToBase64String(ms.ToArray());
		dnlWindow.Attributes["src"] = "/ITRSWeb/DownloadGeneric.aspx?Action=" + Server.UrlEncode(gg);
	}

	#region Stato della pagina
	/// <summary>
	/// stato della pagina memorizzato nel control State
	/// </summary>
	[Serializable]
	class PageState
	{
		//public bool DettVisibile = false;
		public int mwActiveViewIndex = 0;

		// dati del transito
		public string DettTarga = "";
		public string DettNazionalita = "";
		public DateTime? DettDataOraRilevamento = null;

		// dati dell'evento
		public DateTime? DettDataOraInserimento = null;
		public Int64? DettIdEvento = null;

		// tipo visualizzazione
		public BLSorveglianza.SorvTipoLTS TipoSorv = BLSorveglianza.SorvTipoLTS.noA2;
	}
	PageState _pageState = new PageState();
	protected override void LoadControlState(object savedState)
	{
		// faccio try/catch per evitare l'invalid cast quando si ricomila
		try {
			_pageState = (PageState)savedState;
			visualizzaA1A2.SelectedValue = _pageState.TipoSorv.ToString();
		}
		catch { }
	}
	protected override object SaveControlState()
	{
		return _pageState;
	}
	#endregion

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsCallback)
		{
			if (!IsPostBack)
			{
				this._dettaglioTransito.NascondiTransitoSegnalato();
				AddUserActivity(TipoAttivita.Sorveglianza, "Pagina sorveglianza attivata");
				this.gvListaStatica.Sort("DataOraRilevamento", SortDirection.Descending);
			}

			//MaintainScrollPositionOnPostBack = true;

			RegisterClientId("SO", hfClientData, divTransitoSegnalatoPiuRecente, divEventi, hfDettTr, hfUltimoTrSegnalato);

			if (!ClientScript.IsClientScriptBlockRegistered("Sorveglianza1"))
			{
				Type ty = this.GetType();

				ClientScript.RegisterClientScriptInclude("Sorveglianza1", "/ITRSWeb/Sorveglianza/Sorveglianza.js");

				// questa funzione, lanciata ad ogni caricamento della pagina
				// serve per presentare la lista degli eventi al cliente prelevandoli
				// dal controllo hfClientData.
				ClientScript.RegisterStartupScript(ty, "Sorveglianza2", "caricaDatiDaHfValue();", true);

				// questa parte si occupa di agganciare tutti i link di apertura dettagli nella parte
				// dinamica ad un bottone che funge da tramite per fare un post al server.
				// Ogni link specifica in "a" i dettagli dell'evento da aprire.
				// I dettagli sono memorizzati in un hidden field in modo da arrivare al server
				// quando viene chiamata la submit tramite "postBack"
				string postBack = ClientScript.GetPostBackEventReference(this._btnApriDettaglio, "");
				ClientScript.RegisterClientScriptBlock(ty, "Sorveglianza3",
					"function apriDett(a) { SO.hfDettTr().value = a; " + postBack + "; }", true);

				// questo si occupa di lanciare al server l'evento di click su bottone azione veloce rimorchio
				// valorizzando il hfDettTr i dati delle evento selezionato
				string postBackAzioneVeloceRimorchio = ClientScript.GetPostBackEventReference(this._btnAzioneVeloceSuRimorchio, "");
				ClientScript.RegisterClientScriptBlock(ty, "SorveglianzaAzioneVeloceSuRimorchio",
					"function apriAzioneVeloceSuRimorchio(a) { SO.hfDettTr().value = a; " + postBackAzioneVeloceRimorchio + "; }", true);


				// questo si occupa di lanciare al server l'evento di click su bottone azione veloce rimorchio
				// valorizzando il hfDettTr i dati delle evento selezionato
				string postBackAzioneVeloceComePrecedente = ClientScript.GetPostBackEventReference(this._btnAzioneVeloceComePrecedente, "");
				ClientScript.RegisterClientScriptBlock(ty, "SorveglianzaAzioneVeloceComePrecedente",
					"function apriAzioneVeloceComePrecedente(a) { SO.hfDettTr().value = a; " + postBackAzioneVeloceComePrecedente + "; }", true);


				// prima di fare il submit, cancello l'html nel campo hfUltimoTrSegnalato in modo da
				// 1) evitare di fare il post troppo "grosso"
				// 2) evitare di dover disabilitare il validatePage.
				ClientScript.RegisterOnSubmitStatement(ty, "SorveglianzaOnSubmit", "SorveglianzaOnSubmit();");
			}
		}
	}

	/// <summary>
	/// Funzione chiamata in polling dal cliente per l'aggiornamento automatico
	/// della tabella degli eventi di sorveglianza.
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	protected void clientTimer_GetNewAlarm(object sender, ITRSControls.ClientTimerClientTimerEventArgs e)
	{
		try
		{
			ClientData cd = BuildDynamicHtml();
			e.Result = ClientState.Serialize(cd);
		}
		catch
		{
			e.Result = "";
		}
	}

	void Sorveglianza_Sorveglianza_PreRender(object sender, EventArgs e)
	{
		// la parte dinamica viene serializzata nell'hidden field.
		// Quando la pagina arrivera` al client lo script allo startup si
		// occupera` di deserializzare il suo contenuto e visualizzare gli elementi
		// nella pagina stessa.
		ClientData cd = BuildDynamicHtml();
		hfClientData.Value = ClientState.Serialize(cd);


		mvSorv.ActiveViewIndex = _pageState.mwActiveViewIndex;
		switch (_pageState.mwActiveViewIndex)
		{
		case 0:
			_lkVisEvDin.Visible = false;
			titoloListaOrDettaglio.InnerText = "Sorveglianza - lista ultimi allarmi";
			break;
		case 1:
			_lkVisEvSta.Visible = false;
			titoloListaOrDettaglio.InnerText = "Sorveglianza - lista allarmi";
			break;
		case 2:
			titoloListaOrDettaglio.InnerText = "Sorveglianza - allarme selezionato";
			break;
		}
	}

	ClientData BuildDynamicHtml()
	{
		ClientData cd = new ClientData();
		cd.tbTS = "";
		cd.tbHtml = "";

		int idCoa = ITRSUtility.GetCoaDiAppartenenza();
		List<BLSorveglianza.TransitoSegnalatoSorveglianza> listaTransitiSegnalati = BLCacher.BLSorveglianza_GetListaSorveglianza(4, idCoa, _pageState.TipoSorv);

		// dettaglio allarme piu` recente
		if (listaTransitiSegnalati.Count > 0)
		{
			BLSorveglianza.TransitoSegnalatoSorveglianza transitoSegnalatoPiuRecente = listaTransitiSegnalati[0];
			cd.tbTS = GetHtmlTransitoSegnalatoPiuRecente(transitoSegnalatoPiuRecente, /*transitoSegnalatoPrecedente,*/ idCoa);
		}
		else
			cd.tbTS = "<sp>Nessun allarme attivo!</sp>";

		// lista allarmi
		if (_pageState.mwActiveViewIndex == 0)
			cd.tbHtml = GetHtmlListaTransitiSegnalati(listaTransitiSegnalati, ref cd.divTsPrec);
		else
			cd.tbHtml = "<sp>Nessun allarme attivo!</sp>";

		return cd;
	}



	#region Gestione parte dinamica

	string GetFileNameTipoVeicoloSegnalazione(string TipoVeicoloSegnalazione)
	{
		string url = null;

		switch (TipoVeicoloSegnalazione)
		{
		case "AUTOCARAVAN/CAMPER": url = "/ITRSWeb/Images/tipoVeicolo_AUTOCARAVAN_CAMPER.gif"; break;
		case "AUTOMEZZO PESANTE": url = "/ITRSWeb/Images/tipoVeicolo_AUTOMEZZO_PESANTE.gif"; break;
		case "FUORISTRADA": url = "/ITRSWeb/Images/tipoVeicolo_FUORISTRADA.gif"; break;
		case "AUTOVETTURA": url = "/ITRSWeb/Images/tipoVeicolo_AUTOVETTURA.gif"; break;
		case "MOTOVEICOLO": url = "/ITRSWeb/Images/tipoVeicolo_MOTOVEICOLO.gif"; break;
		case "AUTOBUS": url = "/ITRSWeb/Images/tipoVeicolo_AUTOBUS.gif"; break;
		}
		if (url != null)
			return url;

		try
		{
			string path = Server.MapPath("/ITRSweb/Images");
			string fn = string.Format("tipoVeicolo_{0}.gif", TipoVeicoloSegnalazione);
			string fnp = Path.Combine(path, fn);
			if (File.Exists(fnp))
				return "/ITRSweb/Images/" + fn;
		}
		catch
		{
		}
		return "/ITRSWeb/Images/tipoVeicolo_UNKNOWN.GIF";
	}

	/// <summary>
	/// Questa funzione costruisce la parte superiore della maschera, quella che contiene la cartina
	/// e i dettagli a destra.
	/// </summary>
	private string GetHtmlTransitoSegnalatoPiuRecente(
		BLSorveglianza.TransitoSegnalatoSorveglianza ts,
		int idCoa)
	{
		HtmlTable tbTransitoSegnalato = new HtmlTable();

		HtmlTableRow trTransitoSegnalato = new HtmlTableRow();
		tbTransitoSegnalato.Rows.Add(trTransitoSegnalato);

		if (true)
		{
			HtmlTableCell tdLeft = new HtmlTableCell();
			trTransitoSegnalato.Cells.Add(tdLeft);

			HtmlTable tbLeft = new HtmlTable();
			tdLeft.Controls.Add(tbLeft);

			HtmlTableRow trLeftUpp = new HtmlTableRow();
			HtmlTableRow trLeftDow = new HtmlTableRow();
			tbLeft.Rows.Add(trLeftUpp);
			tbLeft.Rows.Add(trLeftDow);


			HtmlTableCell tdLeftUp = new HtmlTableCell();
			trLeftUpp.Cells.Add(tdLeftUp);
			tdLeftUp.ColSpan = 2;

			HtmlTableCell tdLeftDowLeft = new HtmlTableCell();
			HtmlTableCell tdLeftDowRight = new HtmlTableCell();
			trLeftDow.Cells.Add(tdLeftDowLeft);
			trLeftDow.Cells.Add(tdLeftDowRight);


			if (true)
			{
				HtmlImage img = new HtmlImage();
				img.Width = 400;
				img.Height = 300;
				tdLeftUp.Controls.Add(img);

				bool mettiImmagine = true;
				if (mettiImmagine == false)
				{
					// qui si mette la cartina!!!
					string url = "/ITRSWeb/Handler/SorveglianzaHandler.ashx?Targa={0}&Naz={1}&DR={2}&IdCoa={3}";
					img.Src = string.Format(url, ts.Targa, ts.Nazionalita, ts.DataOraRilevamento.ToString("G"), idCoa);

					if (ts.Immagine != null)
					{
						string key = "SorveglianzaMap Targa={0}&Naz={1}&DR={2}&IdCoa={3}";
						key = string.Format(key, ts.Targa, ts.Nazionalita, ts.DataOraRilevamento.ToString("G"), idCoa);
						BLCacher.CacheAddForTimeSpan(key, ts.Immagine, new TimeSpan(0, 5, 0));
					}
				}
				else
				{
					// qui invece mettiamo la foto del transito.
					string url = "/ITRSWeb/Handler/ImageHandler.ashx?t={0}&n={1}&d={2}&outW=400";
					img.Src = string.Format(url, ts.Targa, ts.Nazionalita, ts.DataOraRilevamento.ToString("yyyy MM dd HH mm ss"));
					BLCacher.BLTransiti_GetBlobImmagine(ts.Targa, ts.Nazionalita, ts.DataOraRilevamento);
				}
			}

			if (ts.PL_XSTART.HasValue && ts.PL_XEND.HasValue &&
				ts.PL_YSTART.HasValue && ts.PL_YEND.HasValue)
			{
				HtmlImage img = new HtmlImage();
				img.Width = 300;
				img.Height = 100;
				img.Alt = "Dettaglio targa";
				tdLeftDowLeft.Controls.Add(img);

				img.Src = ImageUtility.TargaHandler_BuildRequest(
					ts.Targa, ts.Nazionalita, ts.DataOraRilevamento,
					ts.PL_XSTART.Value, ts.PL_XEND.Value, ts.PL_YSTART.Value, ts.PL_YEND.Value,
					img.Width, img.Height, 0, 1);

				byte[] a = BLCacher.BLTransiti_GetBlobImmagine(ts.Targa, ts.Nazionalita, ts.DataOraRilevamento);

				byte[] targaImg = ImageUtility.ElaboraImmagineTargaToArray(a, ts.PL_XSTART.Value, ts.PL_XEND.Value, ts.PL_YSTART.Value, ts.PL_YEND.Value, img.Width, img.Height, 0, 1);

				//System.Diagnostics.Debug.WriteLine("Metto in cache : " + img.Src);

				BLCacher.CacheAddForTimeSpan(img.Src, targaImg, new TimeSpan(0, 1, 0));
			}
			else
			{
				tdLeftDowLeft.InnerText = "Dettaglio targa non disponibile";
			}

			if (true)
			{
				HtmlTable tbx = new HtmlTable();
				tdLeftDowRight.Controls.Add(tbx);

				HtmlTableRow tr1 = new HtmlTableRow(); tbx.Rows.Add(tr1);
				HtmlTableRow tr2 = new HtmlTableRow(); tbx.Rows.Add(tr2);
				HtmlTableRow tr3 = new HtmlTableRow(); tbx.Rows.Add(tr3);

				HtmlTableCell td1 = new HtmlTableCell(); tr1.Cells.Add(td1);
				HtmlTableCell td2 = new HtmlTableCell(); tr2.Cells.Add(td2);
				HtmlTableCell td3 = new HtmlTableCell(); tr3.Cells.Add(td3);

				td1.InnerText = "Tipologia targa";

				{
					string url = null;

					if (ts.PL_VEHICLE_TYPE == null)
						ts.PL_VEHICLE_TYPE = "";

					switch (ts.PL_VEHICLE_TYPE.ToUpper())
					{
					case "AUTOVEICOLO": url = "/ITRSWeb/Images/TipoTarga_AUTOVEICOLO.gif"; break;
					case "MOTOVEICOLO": url = "/ITRSWeb/Images/TipoTarga_MOTOVEICOLO.gif"; break;
					case "RIMORCHIO": url = "/ITRSWeb/Images/TipoTarga_RIMORCHIO.gif"; break;
					default: url = "/ITRSWeb/Images/tipoTarga_UNKNOWN.GIF"; break;
					}

					HtmlImage img = new HtmlImage();
					img.Src = url;
					img.Alt = ts.PL_VEHICLE_TYPE;
					td2.Controls.Add(img);
				}

				{
					string postBack = GetPopupImageUrl(ts.Targa, ts.Nazionalita, ts.DataOraRilevamento);
					td3.InnerHtml = "<a href='#' onClick=\"" + postBack + "\" >Zoom immagine</a>";
				}
			}
		}


		if (true)
		{
			HtmlTableCell tdRight = new HtmlTableCell();
			tdRight.VAlign = "Top";
			trTransitoSegnalato.Cells.Add(tdRight);

			// genero l'html per la riga
			HtmlTable tb = new HtmlTable();
			tdRight.Controls.Add(tb);

			if (true)
			{
				tb.Style.Add(HtmlTextWriterStyle.BorderStyle, "Solid");
				tb.Style.Add(HtmlTextWriterStyle.BorderWidth, "1");

				GetDettaglioSorveglianzaRowTitle(tb, "Transito segnalato");

				GetDettaglioSorveglianzaRowLink(tb, "Targa:", ts.Targa + " / " + ts.Nazionalita, GetPostBackUrl(ts));
				GetDettaglioSorveglianzaRow(tb, "Strada:", ts.TrC2pStrada/*TRC2PSTRADA*/ + " / " + ITRSUtility.Translate(ts.TrC2PDirezione/*TRC2PDIREZIONE*/));
				GetDettaglioSorveglianzaRow(tb, "Area di servizio:", ts.TrC2PDescrizione/*TRC2PDESCRIZIONE*/);

				string urlImg = null;
				switch (ts.EnumTipoVarco/*ENUMTIPOVARCO*/)
				{
				case TipoVarco.D: urlImg = "/ITRSWeb/Images/TipoVarco_D.gif"; break;
				case TipoVarco.S: urlImg = "/ITRSWeb/Images/TipoVarco_S.gif"; break;
				case TipoVarco.E: urlImg = "/ITRSWeb/Images/TipoVarco_E.gif"; break;
				case TipoVarco.U: urlImg = "/ITRSWeb/Images/TipoVarco_U.gif"; break;
				}
				GetDettaglioSorveglianzaRowImage(tb, "Tipo varco:", urlImg, ITRSUtility.Translate(ts.EnumTipoVarco/*ENUMTIPOVARCO*/));
				GetDettaglioSorveglianzaRow(tb, "Data ora rilevamento:", ts.DataOraRilevamento/*DATAORARILEVAMENTO*/);
				GetDettaglioSorveglianzaRow(tb, "Stato transito:", ITRSUtility.Translate(ts.EnumStatoTransito/*ENUMSTATOTRANSITO*/));
				GetDettaglioSorveglianzaRow(tb, "Stato evento:", ITRSUtility.Translate(ts.StatoAllarme/*STATOALLARME*/));
				GetDettaglioSorveglianzaRow(tb, "Classe urgenza:", ITRSUtility.Translate(ts.EnumClasseUrgenza/*ENUMCLASSEURGENZA*/));

				if (ts.StatoAllarme/*STATOALLARME*/ == StatoAllarme.CNF || ts.StatoAllarme/*STATOALLARME*/ == StatoAllarme.NCNF)
					GetDettaglioSorveglianzaRow(tb, "Note chiusura ev:", ts.EvNoteChiusura/*EVNOTECHIUSURA*/);

				GetDettaglioSorveglianzaRowTitle(tb, "Dati segnalazione");

				if (ts.EnumTipoLtsSegnalazione1 != null && ts.EnumTipoLtsSegnalazione1 == "A2")
					GetDettaglioSorveglianzaRow(tb, "Note segnalazione:", ts.NoteSegnalazione1, "Sorv_ValueNonRevisionati");
				else
					GetDettaglioSorveglianzaRow(tb, "Note segnalazione:", ts.NoteSegnalazione1, "Sorv_ValueRubati");

				if (ts.TipoVeicoloSegnalazione1 == null) ts.TipoVeicoloSegnalazione1 = "";

				string urlImgTipoVeicolo = GetFileNameTipoVeicoloSegnalazione(ts.TipoVeicoloSegnalazione1);

				GetDettaglioSorveglianzaRowImage(tb, "Tipo veicolo segnalazione:", urlImgTipoVeicolo, ts.TipoVeicoloSegnalazione1);

				GetDettaglioSorveglianzaRowTitle(tb, "Transito segnalato precedente");

				if (ts.PrecTsEvDataOraInserimento.HasValue)
				{
					GetDettaglioSorveglianzaRow(tb, "Data ora rilevamento:", ts.PrecTsTrDataOraRilevamento.Value);
					GetDettaglioSorveglianzaRow(tb, "Strada:", ts.PrecTsTrStrada + " / " + ITRSUtility.Translate(ts.PrecTsTrC2PDirezione.Value));
					GetDettaglioSorveglianzaRow(tb, "Area di servizio:", ts.PrecTsTrC2PDescrizione);

					GetDettaglioSorveglianzaRow(tb, "Stato transito:", ITRSUtility.Translate(ts.PrecTsTrStatoTransito.Value));
					if (ts.PrecTsTrStatoTransito.Value == StatoTransito.RIC || ts.PrecTsTrStatoTransito.Value == StatoTransito.NORIC)
						GetDettaglioSorveglianzaRow(tb, "Note chiusura tr:", ts.PresTsTrNoteChiusura);

					GetDettaglioSorveglianzaRow(tb, "Stato evento:", ITRSUtility.Translate(ts.PrecTsEvStatoAllarme));
					if (ts.PrecTsEvStatoAllarme.Value == StatoAllarme.NCNF || ts.PrecTsEvStatoAllarme.Value == StatoAllarme.CNF)
						GetDettaglioSorveglianzaRow(tb, "Note chiusura: ev", ts.PrecTsEvNoteChiusura);
				}
				else
					GetDettaglioSorveglianzaRow(tb, "", "nessun rilevamento");


				GetDettaglioSorveglianzaRowTitle(tb, "Azioni");
				GetDettaglioSorveglianzaRowLink(tb, "", "Gestisci " + ts.Targa + " / " + ts.Nazionalita, GetPostBackUrl(ts));

				// esiste un transito segnalato precedente
				if (IsAbilitataAzioneRapidaTransitoPrecedente(ts))
				{
					GetDettaglioSorveglianzaRowLink(tb, "", "Chiudi come il precedente TS",
						GetPostBackUrlPerAzioneVeloceComePrecedente(
							ts, ts.PrecTsEvDataOraInserimento.Value, ts.PrecTsEvIdEvento.Value));
				}
				else if (IsAbilitataAzioneRapidaPerRimorchioMotociclo(ts))
					GetDettaglioSorveglianzaRowLink(tb, "", "Chiudi TS motociclo/rimorchio", GetPostBackUrlPerAzioneVeloceSuRimorchioMotociclo(ts));
			}
		}


		if (true)
		{
			System.IO.StringWriter stringWriter = new System.IO.StringWriter();
			Html32TextWriter wr = new Html32TextWriter(stringWriter);

			tbTransitoSegnalato.RenderControl(wr);
			return stringWriter.GetStringBuilder().ToString();
		}
	}
	private static bool IsAbilitataAzioneRapidaTransitoPrecedente(BLSorveglianza.TransitoSegnalatoSorveglianza ts)
	{
		if (!ts.PrecTsEvDataOraInserimento.HasValue)
			return false;

		if (!ts.PrecTsEvStatoAllarme.HasValue)
			return false;

		StatoAllarme sa = ts.PrecTsEvStatoAllarme.Value;
		if (sa == StatoAllarme.NCNF || sa == StatoAllarme.CNF)
			return true;

		return false;
	}
	private static bool IsAbilitataAzioneRapidaTransitoPrecedente(BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato ts)
	{
		if (!ts.PrecTsEvDataOraInserimento.HasValue)
			return false;

		if (!ts.PrecTsEvStatoAllarme.HasValue)
			return false;

		StatoAllarme sa = ts.PrecTsEvStatoAllarme.Value;
		if (sa == StatoAllarme.NCNF || sa == StatoAllarme.CNF)
			return true;

		return false;
	}


	private static bool IsAbilitataAzioneRapidaPerRimorchioMotociclo(BLSorveglianza.TransitoSegnalatoSorveglianza s)
	{
		// bisogna avere entrambi i ruoli abilitati
		if (!(Roles.IsUserInRole("Gestione transiti") && Roles.IsUserInRole("Gestione allarmi")))
			return false;

		// transito e allarme devono essere entrambi da gestire
		if (!(s.EnumStatoTransito == StatoTransito.DARIC && s.StatoAllarme == StatoAllarme.ACQ))
			return false;

		// le targhe dei motocicli sono composte da due lettere seguite da 5 o 6 numeri.
		// Per abilitare il bottone di azione rapida di annullo evento
		// viene controlla la targa per vedere se corrisponde alla targa di un motociclo
		// Se si e se l'operatore vede un camion allora si puo` annullare l'evento
		Regex rg = new Regex("^[A-Z]{2}[0-9]{5,6}$");
		Match m = rg.Match(s.Targa);
		if (m.Success)
			return true;  // se sembra una targa di moto faccio vedere il pulsante

		// se la segnalazione e` MOTOVEICOLO MOTOFURGONE e il tipo targa e` rimorchio
		// faccio vedere il bottone
		if (s.TipoVeicoloSegnalazione1 != null && s.TipoVeicoloSegnalazione1.StartsWith("MOTO") && s.PL_VEHICLE_TYPE != null && s.PL_VEHICLE_TYPE == "RIMORCHIO")
			return true;

		// se il tipo targa riconosciuto dal lettore e` motoveicolo
		// faccio vedere il bottone
		if (s.PL_VEHICLE_TYPE == "MOTOVEICOLO")
			return true;

		return false;
	}
	private static bool IsAbilitataAzioneRapidaPerRimorchioMotociclo(BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato s)
	{
		// bisogna avere entrambi i ruoli abilitati
		if (!(Roles.IsUserInRole("Gestione transiti") && Roles.IsUserInRole("Gestione allarmi")))
			return false;

		// transito e allarme devono essere entrambi da gestire
		if (!(s.EnumStatoTransito == StatoTransito.DARIC && s.StatoAllarme == StatoAllarme.ACQ))
			return false;

		// le targhe dei motocicli sono composte da due lettere seguite da 5 o 6 numeri.
		// Per abilitare il bottone di azione rapida di annullo evento
		// viene controlla la targa per vedere se corrisponde alla targa di un motociclo
		// Se si e se l'operatore vede un camion allora si puo` annullare l'evento
		Regex rg = new Regex("^[A-Z]{2}[0-9]{5,6}$");
		Match m = rg.Match(s.Targa);
		if (m.Success)
			return true;  // se sembra una targa di moto faccio vedere il pulsante

		// se la segnalazione e` MOTOVEICOLO MOTOFURGONE e il tipo targa e` rimorchio
		// faccio vedere il bottone
		if (s.TipoVeicoloSegnalazione1 != null && s.TipoVeicoloSegnalazione1.StartsWith("MOTO") && s.PL_VEHICLE_TYPE != null && s.PL_VEHICLE_TYPE == "RIMORCHIO")
			return true;

		// se il tipo targa riconosciuto dal lettore e` motoveicolo
		// faccio vedere il bottone
		if (s.PL_VEHICLE_TYPE == "MOTOVEICOLO")
			return true;

		return false;
	}
	private static void GetDettaglioSorveglianzaRow(HtmlTable tb, string descrizione, DateTime? valore)
	{
		string r = valore.HasValue ? valore.Value.ToString("G") : null;
		GetDettaglioSorveglianzaRow(tb, descrizione, r);
	}

	private static void GetDettaglioSorveglianzaRowTitle(HtmlTable tb, string title)
	{
		HtmlTableRow tr = new HtmlTableRow();
		tb.Rows.Add(tr);

		HtmlTableCell td1 = new HtmlTableCell();
		td1.Align = "left";
		td1.ColSpan = 2;
		td1.Attributes["class"] = "Sorv_Title";
		tr.Cells.Add(td1);

		td1.InnerText = title;
	}

	private static void GetDettaglioSorveglianzaRow(HtmlTable tb, string descrizione, string valore)
	{
		HtmlTableRow tr = new HtmlTableRow();
		tb.Rows.Add(tr);

		HtmlTableCell td1 = new HtmlTableCell();
		tr.Cells.Add(td1);
		td1.Align = "right";
		td1.Attributes["class"] = "Sorv_Descr";
		td1.InnerText = descrizione;

		HtmlTableCell td2 = new HtmlTableCell();
		tr.Cells.Add(td2);

		td2.Attributes["class"] = "Sorv_Value";
		if (valore == null || valore == "")
		{
			valore = "<span>&nbsp</span>";
			td2.InnerHtml = valore;
		}
		else
			td2.InnerText = valore;
	}
	private static void GetDettaglioSorveglianzaRow(HtmlTable tb, string descrizione, string valore, string css_class)
	{
		HtmlTableRow tr = new HtmlTableRow();
		tb.Rows.Add(tr);

		HtmlTableCell td1 = new HtmlTableCell();
		tr.Cells.Add(td1);
		td1.Align = "right";
		td1.Attributes["class"] = "Sorv_Descr";
		td1.InnerText = descrizione;

		HtmlTableCell td2 = new HtmlTableCell();
		tr.Cells.Add(td2);

		td2.Attributes["class"] = css_class;
		if (valore == null || valore == "")
		{
			valore = "<span>&nbsp</span>";
			td2.InnerHtml = valore;
		}
		else
			td2.InnerText = valore;
	}

	private static void GetDettaglioSorveglianzaRowImage(HtmlTable tb, string descrizione, string imgUrl, string descr)
	{
		HtmlTableRow tr = new HtmlTableRow();
		tb.Rows.Add(tr);

		HtmlTableCell td1 = new HtmlTableCell();
		tr.Cells.Add(td1);
		td1.Align = "right";
		td1.Attributes["class"] = "Sorv_Descr";
		td1.InnerText = descrizione;

		HtmlTableCell td2 = new HtmlTableCell();
		tr.Cells.Add(td2);
		td2.VAlign = "Center";

		HtmlTable tbIn = new HtmlTable();
		td2.Controls.Add(tbIn);
		HtmlTableRow trIn = new HtmlTableRow();
		tbIn.Rows.Add(trIn);


		HtmlTableCell tdInL = new HtmlTableCell(); trIn.Cells.Add(tdInL);
		HtmlTableCell tdInR = new HtmlTableCell(); trIn.Cells.Add(tdInR);

		HtmlImage img = new HtmlImage();
		img.Src = imgUrl;
		img.Alt = descr;
		tdInL.Controls.Add(img);

		HtmlGenericControl g = new HtmlGenericControl("span");
		g.InnerText = descr;
		g.Attributes["class"] = "Sorv_Value";
		tdInR.VAlign = "Center";
		tdInR.Controls.Add(g);
	}
	private static void GetDettaglioSorveglianzaRowLink(HtmlTable tb, string descrizione, string valore, string postBack)
	{
		HtmlTableRow tr = new HtmlTableRow();
		tr.Height = "20px";
		tb.Rows.Add(tr);

		HtmlTableCell td1 = new HtmlTableCell();
		td1.Align = "right";
		td1.Attributes["class"] = "Sorv_Descr";
		td1.InnerText = descrizione;
		tr.Cells.Add(td1);

		HtmlTableCell td2 = new HtmlTableCell();
		tr.Cells.Add(td2);

		if (valore == null || valore == "")
		{
			valore = "<span>&nbsp</span>";
			td2.InnerHtml = valore;
		}
		else
			td2.InnerHtml = "<a class='SorvLink' href=\"" + postBack + "\">" + valore + "</a>";
	}
	private static void GetDettaglioSorveglianzaRowLink2(HtmlTable tb, string valore, string postBack)
	{
		HtmlTableRow tr = new HtmlTableRow();
		tb.Rows.Add(tr);

		HtmlTableCell td1 = new HtmlTableCell();
		td1.Align = "left";
		tr.Cells.Add(td1);
		td1.ColSpan = 2;
		td1.Attributes["class"] = "Sorv_Value";
		td1.InnerHtml = "<a href='#' onClick=\"" + postBack + "\" >" + valore + "</a>";
	}
	string GetPostBackUrl(BLSorveglianza.TransitoSegnalatoSorveglianza s)
	{
		string arg = string.Format("{0} {1} {2} {3} {4}",
			s.Targa,
			s.Nazionalita,
			s.DataOraRilevamento.ToString("yyyy MM dd HH mm ss"),
			s.DataOraInserimento.ToString("yyyy MM dd HH mm ss"),
			s.IdEvento);
		string href = "javascript:apriDett('" + arg + "');";
		return href;
	}
	string GetPostBackUrlPerAzioneVeloceSuRimorchioMotociclo(BLSorveglianza.TransitoSegnalatoSorveglianza s)
	{
		string arg = string.Format("{0} {1} {2} {3} {4}",
			s.Targa,
			s.Nazionalita,
			s.DataOraRilevamento.ToString("yyyy MM dd HH mm ss"),
			s.DataOraInserimento.ToString("yyyy MM dd HH mm ss"),
			s.IdEvento);
		string href = "javascript:apriAzioneVeloceSuRimorchio('" + arg + "');";
		return href;
	}
	string GetPostBackUrlPerAzioneVeloceSuRimorchioMotociclo(BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato s)
	{
		string arg = string.Format("{0} {1} {2} {3} {4}",
			s.Targa,
			s.Nazionalita,
			s.DataOraRilevamento.ToString("yyyy MM dd HH mm ss"),
			s.DataOraInserimento.ToString("yyyy MM dd HH mm ss"),
			s.IdEvento);
		string href = "javascript:apriAzioneVeloceSuRimorchio('" + arg + "');";
		return href;
	}

	string GetPostBackUrlPerAzioneVeloceComePrecedente(BLSorveglianza.TransitoSegnalatoSorveglianza ts, DateTime PrecTsEvDataOraInserimento, Int64 PrecTsEvIdEvento)
	{
		string arg = string.Format("{0} {1} {2} {3} {4} {5} {6}",
			ts.Targa,
			ts.Nazionalita,
			ts.DataOraRilevamento.ToString("yyyy MM dd HH mm ss"),
			ts.DataOraInserimento.ToString("yyyy MM dd HH mm ss"),
			ts.IdEvento,

			PrecTsEvDataOraInserimento.ToString("yyyy MM dd HH mm ss"),
			PrecTsEvIdEvento
			);
		string href = "javascript:apriAzioneVeloceComePrecedente('" + arg + "');";
		return href;
	}
	string GetPostBackUrlPerAzioneVeloceComePrecedente(BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato ts, DateTime PrecTsEvDataOraInserimento, Int64 PrecTsEvIdEvento)
	{
		string arg = string.Format("{0} {1} {2} {3} {4} {5} {6}",
			ts.Targa,
			ts.Nazionalita,
			ts.DataOraRilevamento.ToString("yyyy MM dd HH mm ss"),
			ts.DataOraInserimento.ToString("yyyy MM dd HH mm ss"),
			ts.IdEvento,

			PrecTsEvDataOraInserimento.ToString("yyyy MM dd HH mm ss"),
			PrecTsEvIdEvento
			);
		string href = "javascript:apriAzioneVeloceComePrecedente('" + arg + "');";
		return href;
	}



	string GetHtmlListaTransitiSegnalati(List<BLSorveglianza.TransitoSegnalatoSorveglianza> lst, ref string divTsPRec)
	{
		HtmlTable tbListaTransitiSegnalati = new HtmlTable();
		tbListaTransitiSegnalati.Border = 1;
		tbListaTransitiSegnalati.CellSpacing = 0;

		int nRiga = 0;
		foreach (BLSorveglianza.TransitoSegnalatoSorveglianza s in lst)
			BuildRigaTabellaTransitiSegnalati(tbListaTransitiSegnalati, s, nRiga++, ref divTsPRec);

		System.IO.StringWriter sw = new System.IO.StringWriter();
		Html32TextWriter wr = new Html32TextWriter(sw);
		tbListaTransitiSegnalati.RenderControl(wr);
		string html = sw.GetStringBuilder().ToString();

		return html;
	}
	void BuildRigaTabellaTransitiSegnalati(HtmlTable tb, BLSorveglianza.TransitoSegnalatoSorveglianza s, int nRiga, ref String divTsPrec)
	{
		if (tb.Rows.Count == 0)
		{
			HtmlTableRow tr = new HtmlTableRow();
			tb.Rows.Add(tr);
			tr.Attributes.Add("cellspacing", "0");
			tr.Style.Add(HtmlTextWriterStyle.FontWeight, "bold");

			GetDettaglioSorveglianzaCell(tr, "Targa");
			GetDettaglioSorveglianzaCell(tr, "Strada");
			GetDettaglioSorveglianzaCell(tr, "Area di servizio");
			GetDettaglioSorveglianzaCell(tr, "Direzione");
			GetDettaglioSorveglianzaCell(tr, "Tipo varco");

			// dati del transito.
			GetDettaglioSorveglianzaCell(tr, "Data ora rilevamento");
			GetDettaglioSorveglianzaCell(tr, "Stato transito");

			// dati dell.evento
			GetDettaglioSorveglianzaCell(tr, "Stato evento");
			GetDettaglioSorveglianzaCell(tr, "Classe urgenza");
			GetDettaglioSorveglianzaCell(tr, "Note segnalazione");

			GetDettaglioSorveglianzaCell(tr, "Azioni");
			GetDettaglioSorveglianzaCell(tr, "TS Prec");
		}

		if (true)
		{
			HtmlTableRow tr = new HtmlTableRow();
			tb.Rows.Add(tr);
			if (nRiga % 2 == 0)
				tr.BgColor = "white";


			GetDettaglioSorveglianzaCellLink(tr, s.Targa + " / " + s.Nazionalita, GetPostBackUrl(s));
			GetDettaglioSorveglianzaCell(tr, s.TrC2pStrada);
			GetDettaglioSorveglianzaCell(tr, s.TrC2PDescrizione);
			GetDettaglioSorveglianzaCell(tr, ITRSUtility.Translate(s.TrC2PDirezione));
			GetDettaglioSorveglianzaCell(tr, ITRSUtility.Translate(s.EnumTipoVarco));

			// dati del transito.
			GetDettaglioSorveglianzaCell(tr, s.DataOraRilevamento);
			GetDettaglioSorveglianzaCell(tr, ITRSUtility.Translate(s.EnumStatoTransito));

			// dati dell.evento
			GetDettaglioSorveglianzaCell(tr, ITRSUtility.Translate(s.StatoAllarme));
			GetDettaglioSorveglianzaCell(tr, ITRSUtility.Translate(s.EnumClasseUrgenza));

			if (s.EnumTipoLtsSegnalazione1 != null && s.EnumTipoLtsSegnalazione1 == "A2")
			{
				if (!string.IsNullOrEmpty(s.TipoVeicoloSegnalazione1))
					GetDettaglioSorveglianzaCell(tr, s.TipoVeicoloSegnalazione1 + " - " + s.NoteSegnalazione1, "Sorv_ValueNonRevisionati");
				else
					GetDettaglioSorveglianzaCell(tr, s.NoteSegnalazione1, "Sorv_ValueNonRevisionati");
			}
			else
			{
				if (!string.IsNullOrEmpty(s.TipoVeicoloSegnalazione1))
					GetDettaglioSorveglianzaCell(tr, s.TipoVeicoloSegnalazione1 + " - " + s.NoteSegnalazione1, "Sorv_ValueRubati");
				else
					GetDettaglioSorveglianzaCell(tr, s.NoteSegnalazione1, "Sorv_ValueRubati");
			}


			if (IsAbilitataAzioneRapidaTransitoPrecedente(s))
			{
				GetDettaglioSorveglianzaCellLink(tr, "Chiudi come il TS precedente", GetPostBackUrlPerAzioneVeloceComePrecedente(s, s.PrecTsEvDataOraInserimento.Value, s.PrecTsEvIdEvento.Value));
			}
			else if (IsAbilitataAzioneRapidaPerRimorchioMotociclo(s))
			{
				GetDettaglioSorveglianzaCellLink(tr, "Annulla evento per rimorchio/motociclo", GetPostBackUrlPerAzioneVeloceSuRimorchioMotociclo(s));
			}
			else
			{
				GetDettaglioSorveglianzaCellLink(tr, null, null);
			}

			if (s.PrecTsEvIdEvento.HasValue)
			{
				divTsPrec += string.Format("<div id='divPopupTsPrec_{0}'>", nRiga);
				divTsPrec += GetHtmlForPopup(s);
				divTsPrec += "</div>";
				string idA = string.Format("aPopupTsPrec_{0}", nRiga);
				string fn = string.Format("sorvPopupTsPrec('divPopupTsPrec_{0}', '{1}'); return false;", nRiga, idA);
				GetDettaglioSorveglianzaCellLink3(tr, "Apri", fn, idA);
			}
			else GetDettaglioSorveglianzaCell(tr, "");


		}
	}
	private static void GetDettaglioSorveglianzaCell(HtmlTableRow tr, string valore)
	{
		HtmlTableCell td = new HtmlTableCell();
		//td.Align = "right";
		tr.Cells.Add(td);

		if (valore == null || valore == "")
			td.InnerHtml = "<span>&nbsp</span>";
		else
			td.InnerText = valore;
	}
	private static void GetDettaglioSorveglianzaCell(HtmlTableRow tr, string valore, string css_class)
	{
		HtmlTableCell td = new HtmlTableCell();
		//td.Align = "right";
		tr.Cells.Add(td);

		td.Attributes["class"] = css_class;

		if (valore == null || valore == "")
			td.InnerHtml = "<span>&nbsp</span>";
		else
			td.InnerText = valore;
	}
	private static void GetDettaglioSorveglianzaCellLink(HtmlTableRow tr, string valore, string postBack)
	{
		HtmlTableCell td = new HtmlTableCell();
		tr.Cells.Add(td);

		if (valore == null || valore == "")
			td.InnerHtml = "<span>&nbsp</span>";
		else
			td.InnerHtml = "<a href=\"" + postBack + "\" >" + valore + "</a>";
	}
	private static void GetDettaglioSorveglianzaCellLink2(HtmlTableRow tr, string valore, string postBack)
	{
		HtmlTableCell td = new HtmlTableCell();
		tr.Cells.Add(td);

		if (valore == null || valore == "")
			td.InnerHtml = "<span>&nbsp</span>";
		else
			td.InnerHtml = "<a href='#' onClick=\"" + postBack + "\" >" + valore + "</a>";
	}
	private static void GetDettaglioSorveglianzaCellLink3(HtmlTableRow tr, string valore, string postBack, string idA)
	{
		HtmlTableCell td = new HtmlTableCell();
		tr.Cells.Add(td);

		if (valore == null || valore == "")
			td.InnerHtml = "<span>&nbsp</span>";
		else
			td.InnerHtml = "<a id='" + idA + "' href='#' onClick=\"" + postBack + "\" >" + valore + "</a>";
	}
	private static void GetDettaglioSorveglianzaCell(HtmlTableRow tr, DateTime? valore)
	{
		string r = valore.HasValue ? valore.Value.ToString("G") : null;
		GetDettaglioSorveglianzaCell(tr, r);
	}
	#endregion

	protected void _btnApriDettaglio_ServerClick(object sender, EventArgs e)
	{
		string[] ev = hfDettTr.Value.Split();

		int nn = 0;
		string targa = ev[nn++];
		string nazionalita = ev[nn++];
		int yyyy = int.Parse(ev[nn++]);
		int MM = int.Parse(ev[nn++]);
		int dd = int.Parse(ev[nn++]);
		int HH = int.Parse(ev[nn++]);
		int mm = int.Parse(ev[nn++]);
		int ss = int.Parse(ev[nn++]);
		DateTime dataOraRilevamento = new DateTime(yyyy, MM, dd, HH, mm, ss);
		yyyy = int.Parse(ev[nn++]);
		MM = int.Parse(ev[nn++]);
		dd = int.Parse(ev[nn++]);
		HH = int.Parse(ev[nn++]);
		mm = int.Parse(ev[nn++]);
		ss = int.Parse(ev[nn++]);
		DateTime dataOraInserimento = new DateTime(yyyy, MM, dd, HH, mm, ss);
		Int64 idEvento = Int64.Parse(ev[nn++]);

		_pageState.DettTarga = targa;
		_pageState.DettNazionalita = nazionalita;
		_pageState.DettDataOraRilevamento = dataOraRilevamento;
		_pageState.DettDataOraInserimento = dataOraInserimento;
		_pageState.DettIdEvento = idEvento;
		_pageState.mwActiveViewIndex = 2;

		_dettaglioTransito.VisualizzaTransitoSegnalato(
			_pageState.DettTarga,
			_pageState.DettNazionalita,
			_pageState.DettDataOraRilevamento.Value,
			_pageState.DettDataOraInserimento.Value,
			_pageState.DettIdEvento.Value);

	}
	protected void _lkVisEvDin_Click(object sender, EventArgs e)
	{
		_pageState.mwActiveViewIndex = 0;
		_dettaglioTransito.NascondiTransitoSegnalato();
	}
	protected void _lkVisEvSta_Click(object sender, EventArgs e)
	{
		_pageState.mwActiveViewIndex = 1;
		_dettaglioTransito.NascondiTransitoSegnalato();
	}
	protected void odsListaStatica_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
	{
		int idCoa = ITRSUtility.GetCoaDiAppartenenza();
		e.InputParameters["idCoa"] = idCoa;
		e.InputParameters["tipoSorv"] = _pageState.TipoSorv.ToString();
	}

	protected void gvListaStatica_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (gvListaStatica.SelectedIndex < 0)
			return;

		_pageState.DettTarga = (string)gvListaStatica.SelectedDataKey["Targa"];
		_pageState.DettNazionalita = (string)gvListaStatica.SelectedDataKey["Nazionalita"];
		_pageState.DettDataOraRilevamento = (DateTime)gvListaStatica.SelectedDataKey["DataOraRilevamento"];
		_pageState.DettDataOraInserimento = (DateTime)gvListaStatica.SelectedDataKey["DataOraInserimento"];
		_pageState.DettIdEvento = Convert.ToInt64(gvListaStatica.SelectedDataKey["IdEvento"]);

		_pageState.mwActiveViewIndex = 2;

		_dettaglioTransito.VisualizzaTransitoSegnalato(
			_pageState.DettTarga,
			_pageState.DettNazionalita,
			_pageState.DettDataOraRilevamento.Value,
			_pageState.DettDataOraInserimento.Value,
			_pageState.DettIdEvento.Value);
	}
	protected void gvListaStatica_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		// resetto la selezione corrente se clicco una seconda 
		// volta nella stessa riga della grid view
		if (e.NewSelectedIndex == gvListaStatica.SelectedIndex)
			e.NewSelectedIndex = -1;
	}
	protected void gvListaStatica_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			ITRS_BL.BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato s = (ITRS_BL.BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato)e.Row.DataItem;

			e.Row.Cells[gvListaStatica.GetCellIndex("TrC2PDirezione")].Text = ITRSUtility.Translate(s.TrC2PDirezione);
			e.Row.Cells[gvListaStatica.GetCellIndex("EnumTipoVarco")].Text = ITRSUtility.Translate(s.EnumTipoVarco);
			e.Row.Cells[gvListaStatica.GetCellIndex("EnumStatoTransito")].Text = ITRSUtility.Translate(s.EnumStatoTransito);
			e.Row.Cells[gvListaStatica.GetCellIndex("StatoAllarme")].Text = ITRSUtility.Translate(s.StatoAllarme);
			e.Row.Cells[gvListaStatica.GetCellIndex("EnumClasseUrgenza")].Text = ITRSUtility.Translate(s.EnumClasseUrgenza);

			HyperLink hpc = e.Row.Cells[11].Controls[0] as HyperLink;

			if (IsAbilitataAzioneRapidaTransitoPrecedente(s))
			{
				hpc.NavigateUrl = GetPostBackUrlPerAzioneVeloceComePrecedente(s, s.PrecTsEvDataOraInserimento.Value, s.PrecTsEvIdEvento.Value);
				hpc.Text = "Chiudi come il TS precedente";
			}
			else if (IsAbilitataAzioneRapidaPerRimorchioMotociclo(s))
			{
				hpc.NavigateUrl = GetPostBackUrlPerAzioneVeloceSuRimorchioMotociclo(s);
				hpc.Text = "Chiudi per rimorchio/motociclo";
			}
			else
				hpc.Visible = false;

		}
	}


	protected void gvListaStatica_SelectCount(object sender, ITRSControls.ExGridSelectCountEventArgs e)
	{
		try
		{
			using (ITRS_BL.BLSorveglianza bl = new ITRS_BL.BLSorveglianza())
			{
				int idCoa = ITRSUtility.GetCoaDiAppartenenza();
				int r = bl.GetListaSorveglianzaPaginataCount(idCoa, _pageState.TipoSorv.ToString());
				e.Count = r;
			}
		}
		catch
		{
			// per lo meno NON faccio crollare la maschera.
			// Lo sparo alla prima pagina invece che all'ultima.
			e.Count = 0;
		}

	}

	protected void _btnAzioneVeloceSuRimorchio_ServerClick(object sender, EventArgs e)
	{
		string[] ev = hfDettTr.Value.Split();

		int nn = 0;
		string targa = ev[nn++];
		string nazionalita = ev[nn++];
		int yyyy = int.Parse(ev[nn++]);
		int MM = int.Parse(ev[nn++]);
		int dd = int.Parse(ev[nn++]);
		int HH = int.Parse(ev[nn++]);
		int mm = int.Parse(ev[nn++]);
		int ss = int.Parse(ev[nn++]);
		DateTime dataOraRilevamento = new DateTime(yyyy, MM, dd, HH, mm, ss);
		yyyy = int.Parse(ev[nn++]);
		MM = int.Parse(ev[nn++]);
		dd = int.Parse(ev[nn++]);
		HH = int.Parse(ev[nn++]);
		mm = int.Parse(ev[nn++]);
		ss = int.Parse(ev[nn++]);
		DateTime dataOraInserimento = new DateTime(yyyy, MM, dd, HH, mm, ss);
		Int64 idEvento = Int64.Parse(ev[nn++]);

		AzioneVeloceSuRimorchio(targa, nazionalita, dataOraRilevamento, idEvento, dataOraInserimento);
	}
	protected void AzioneVeloceSuRimorchio(string targa, string nazionalita, DateTime dataOraRilevamento, Int64 idEvento, DateTime dataOraInserimento)
	{
		string fase = string.Empty;
		try
		{
			using (BLTransiti blTransiti = new BLTransiti())
			{
				fase = "LeggiDatiTransito";
				ITRS_BL.DatiTransito tr = blTransiti.GetDatiTransitoOrTransitoSuEvento(targa, nazionalita, dataOraRilevamento);
				if (tr == null || tr.StatoTransito != StatoTransito.DARIC)
				{
					lblErrore.ForeColor = System.Drawing.Color.Red;
					lblErrore.Text = "Transito gia` preso in carico.";
					return;
				}

				fase = "Transito.PrendiInCarico";
				PageBase.AddUserActivity(TipoAttivita.Transito, "Presa in carico del transito Targa:{0} Nazionalita:{1} Rilevato:{2}", targa, nazionalita, dataOraRilevamento.ToString("G"));
				blTransiti.PrendiInCarico(targa, nazionalita, dataOraRilevamento, UserPkId);

				fase = "Transito.AzioneSuPresaInCarico";
				PageBase.AddUserActivity(TipoAttivita.Transito, "Cambio stato del transito Targa:{0} Nazionalita:{1} Rilevato:{2} Nuovo stato:{3}", targa, nazionalita, dataOraRilevamento.ToString("G"), StatoTransito.RIC);
				blTransiti.AzioneSuPresaInCarico(targa, nazionalita, dataOraRilevamento, StatoTransito.RIC, "Rimorchio/Motociclo",
					targa, nazionalita);
			}

			using (BLEventi blEventi = new BLEventi())
			{
				DettEvento ev = blEventi.GetDatiEvento(targa, nazionalita, dataOraInserimento, idEvento);
				if (ev == null || ev.StatoAllarme != StatoAllarme.ACQ)
				{
					lblErrore.ForeColor = System.Drawing.Color.Red;
					lblErrore.Text = "Evento gia` preso in carico.";
					return;
				}

				fase = "Evento.PrendiInCarico";
				PageBase.AddUserActivity(TipoAttivita.Evento, "Presa in carico dell'evento Targa:{0} Nazionalita:{1} Inserito il:{2} Nuovo stato:{3}", targa, nazionalita, dataOraInserimento.ToString("G"), "Preso in carico");
				blEventi.PrendiInCarico(targa, nazionalita, dataOraInserimento, idEvento, UserPkId);

				fase = "Evento.AzioneSuPresaInCarico";
				PageBase.AddUserActivity(TipoAttivita.Evento, "Cambio stato dell'evento Targa:{0} Nazionalita:{1} Inserito il:{2} Nuovo stato:{3}", targa, nazionalita, dataOraInserimento.ToString("G"), StatoAllarme.NCNF);
				blEventi.AzioneSuPresaInCarico(targa, nazionalita, dataOraInserimento, idEvento, StatoAllarme.NCNF, "Rimorchio/Motociclo");
			}
		}
		catch (Exception ex)
		{
			Log.Write(ex, "AzioneVeloceSuRimorchio-{0}", fase);
			lblErrore.ForeColor = System.Drawing.Color.Red;
			lblErrore.Text = "Errore durante la fase: " + fase;
		}
	}

	protected void _btnAzioneVeloceComePrecedente_ServerClick(object sender, EventArgs e)
	{
		string[] ev = hfDettTr.Value.Split();

		int nn = 0;
		string targa = ev[nn++];
		string nazionalita = ev[nn++];
		int yyyy = int.Parse(ev[nn++]);
		int MM = int.Parse(ev[nn++]);
		int dd = int.Parse(ev[nn++]);
		int HH = int.Parse(ev[nn++]);
		int mm = int.Parse(ev[nn++]);
		int ss = int.Parse(ev[nn++]);
		DateTime dataOraRilevamento = new DateTime(yyyy, MM, dd, HH, mm, ss);
		yyyy = int.Parse(ev[nn++]);
		MM = int.Parse(ev[nn++]);
		dd = int.Parse(ev[nn++]);
		HH = int.Parse(ev[nn++]);
		mm = int.Parse(ev[nn++]);
		ss = int.Parse(ev[nn++]);
		DateTime dataOraInserimento = new DateTime(yyyy, MM, dd, HH, mm, ss);
		Int64 idEvento = Int64.Parse(ev[nn++]);

		yyyy = int.Parse(ev[nn++]);
		MM = int.Parse(ev[nn++]);
		dd = int.Parse(ev[nn++]);
		HH = int.Parse(ev[nn++]);
		mm = int.Parse(ev[nn++]);
		ss = int.Parse(ev[nn++]);
		DateTime transitoPrecDataOraInserimento = new DateTime(yyyy, MM, dd, HH, mm, ss);
		Int64 transitoPrecIdEvento = Int64.Parse(ev[nn++]);

		AzioneVeloceComePrecedente(targa, nazionalita, dataOraRilevamento, idEvento, dataOraInserimento /*transitoPrecDataOraInserimento, transitoPrecIdEvento*/);
	}

	protected void AzioneVeloceComePrecedente(string targa, string nazionalita, DateTime dataOraRilevamento, Int64 idEvento, DateTime dataOraInserimento /*, DateTime precDataOraInserimento, int precIdEvento*/)
	{
		string fase = string.Empty;
		try
		{
			using (BLTransiti blTransiti = new BLTransiti())
			{
				fase = "LeggiDatiTransito";
				ITRS_BL.DatiTransito tr = blTransiti.GetDatiTransitoOrTransitoSuEvento(targa, nazionalita, dataOraRilevamento);
				if (tr == null || tr.StatoTransito != StatoTransito.DARIC)
				{
					lblErrore.ForeColor = System.Drawing.Color.Red;
					lblErrore.Text = "Transito gia` preso in carico.";
					return;
				}

				fase = "Transito.PrendiInCarico";
				PageBase.AddUserActivity(TipoAttivita.Transito, "Presa in carico del transito Targa:{0} Nazionalita:{1} Rilevato:{2}", targa, nazionalita, dataOraRilevamento.ToString("G"));
				blTransiti.PrendiInCarico(targa, nazionalita, dataOraRilevamento, UserPkId);

				fase = "Transito.AzioneSuPresaInCarico";
				PageBase.AddUserActivity(TipoAttivita.Transito, "Cambio stato del transito Targa:{0} Nazionalita:{1} Rilevato:{2} Nuovo stato:{3}", targa, nazionalita, dataOraRilevamento.ToString("G"), StatoTransito.RIC);
				blTransiti.AzioneSuPresaInCarico(targa, nazionalita, dataOraRilevamento, StatoTransito.RIC, "Rimorchio/Motociclo",
					targa, nazionalita);
			}

			BLSorveglianza.TransitoSegnalatoPrecedente tsp;
			using (BLSorveglianza blSorv = new BLSorveglianza())
			{
				tsp = blSorv.GetTransitoSegnalatoPrecedente(targa, nazionalita, dataOraRilevamento);
				if (tsp == null)
				{
					lblErrore.ForeColor = System.Drawing.Color.Red;
					lblErrore.Text = "Transito precedente non trovato!";
					return;
				}


				if (tsp.EvStatoAllarme != StatoAllarme.NCNF && tsp.EvStatoAllarme != StatoAllarme.CNF)
				{
					lblErrore.ForeColor = System.Drawing.Color.Red;
					lblErrore.Text = "L'evento associato al transito precedente non e` chiuso!";
					return;
				}
			}

			using (BLEventi blEventi = new BLEventi())
			{
				DettEvento ev = blEventi.GetDatiEvento(targa, nazionalita, dataOraInserimento, idEvento);
				if (ev == null || ev.StatoAllarme != StatoAllarme.ACQ)
				{
					lblErrore.ForeColor = System.Drawing.Color.Red;
					lblErrore.Text = "Evento gia` preso in carico.";
					return;
				}

				fase = "Evento.PrendiInCarico";
				PageBase.AddUserActivity(TipoAttivita.Evento, "Presa in carico dell'evento Targa:{0} Nazionalita:{1} Inserito il:{2} Nuovo stato:{3}", targa, nazionalita, dataOraInserimento.ToString("G"), "Preso in carico");
				blEventi.PrendiInCarico(targa, nazionalita, dataOraInserimento, idEvento, UserPkId);

				fase = "Evento.AzioneSuPresaInCarico";
				PageBase.AddUserActivity(TipoAttivita.Evento, "Cambio stato dell'evento Targa:{0} Nazionalita:{1} Inserito il:{2} Nuovo stato:{3}", targa, nazionalita, dataOraInserimento.ToString("G"), StatoAllarme.NCNF);
				blEventi.AzioneSuPresaInCarico(targa, nazionalita, dataOraInserimento, idEvento,
					tsp.EvStatoAllarme,
					tsp.EvNoteChiusura);
			}
		}
		catch (Exception ex)
		{
			Log.Write(ex, "AzioneVeloceComePrecedente-{0}", fase);
			lblErrore.ForeColor = System.Drawing.Color.Red;
			lblErrore.Text = "Errore durante la fase: " + fase;
		}
	}


	private string GetPopupImageUrl(string targa, string nazionalita, DateTime dataOraRilevamento)
	{
		string host_port = Request.Url.Authority;
		string u = "http://{0}/ITRSweb/Handler/ImageHandler2.ashx?";
		u = string.Format(u, host_port);
		u += "t=" + targa;
		u += "&n=" + nazionalita;
		u += "&d=" + dataOraRilevamento.ToString("yyyy MM dd HH mm ss");
		return "javascript:sorvPopupImage('" + u + "');";
	}


	private string GetHtmlForPopup(BLSorveglianza.TransitoSegnalatoSorveglianza ts)
	{
		HtmlGenericControl div = new HtmlGenericControl("div");
		{
			div.Style.Add(HtmlTextWriterStyle.BorderColor, "black");
			div.Style.Add(HtmlTextWriterStyle.BorderWidth, "1px");
			div.Style.Add(HtmlTextWriterStyle.BorderStyle, "solid");
			div.Style.Add(HtmlTextWriterStyle.BackgroundColor, "lightyellow");
			div.Style.Add(HtmlTextWriterStyle.TextAlign, "center");
		}

		HtmlGenericControl span = new HtmlGenericControl("span");
		{
			span.Style.Add("font-family", "Tahoma");
			span.Style.Add(HtmlTextWriterStyle.FontSize, "14px");
			span.Style.Add(HtmlTextWriterStyle.FontWeight, "bold");
			span.InnerHtml = "Transito segnalato precedente";
		}
		div.Controls.Add(span);

		HtmlGenericControl br = new HtmlGenericControl("br");
		div.Controls.Add(br);

		HtmlTable tb = new HtmlTable();
		{
			GetDettaglioPopupRow(tb, "Targa/Naz:", ts.Targa + " / " + ts.Nazionalita);
			GetDettaglioPopupRow(tb, "Data ora rilevamento:", ts.PrecTsTrDataOraRilevamento.Value);
			GetDettaglioPopupRow(tb, "Strada:", ts.PrecTsTrStrada + " / " + ITRSUtility.Translate(ts.PrecTsTrC2PDirezione.Value));
			GetDettaglioPopupRow(tb, "Area di servizio:", ts.PrecTsTrC2PDescrizione);
			GetDettaglioPopupRow(tb, "Tipo varco:", ITRSUtility.TranslateNullable(ts.PrecTsTrTipoVarco));

			GetDettaglioPopupRow(tb, "Stato transito:", ITRSUtility.TranslateNullable(ts.PrecTsTrStatoTransito));
			if (ts.PrecTsTrStatoTransito.Value == StatoTransito.RIC || ts.PrecTsTrStatoTransito.Value == StatoTransito.NORIC)
				GetDettaglioPopupRow(tb, "Note chiusura tr:", ts.PresTsTrNoteChiusura);

			GetDettaglioPopupRow(tb, "Stato evento:", ITRSUtility.Translate(ts.PrecTsEvStatoAllarme));
			if (ts.PrecTsEvStatoAllarme.Value == StatoAllarme.NCNF || ts.PrecTsEvStatoAllarme.Value == StatoAllarme.CNF)
				GetDettaglioPopupRow(tb, "Note chiusura ev:", ts.PrecTsEvNoteChiusura);
		}
		div.Controls.Add(tb);

		if (true)
		{
			System.IO.StringWriter stringWriter = new System.IO.StringWriter();
			Html32TextWriter wr = new Html32TextWriter(stringWriter);

			div.RenderControl(wr);
			string h = stringWriter.GetStringBuilder().ToString();
			return h;
		}
	}

	private static void GetDettaglioPopupRow(HtmlTable tb, string descrizione, string valore)
	{
		HtmlTableRow tr = new HtmlTableRow();
		tb.Rows.Add(tr);

		HtmlTableCell td1 = new HtmlTableCell();
		tr.Cells.Add(td1);
		td1.Align = "right";
		td1.InnerText = descrizione;
		td1.Style.Add(HtmlTextWriterStyle.FontFamily, "Tahoma");
		td1.Style.Add(HtmlTextWriterStyle.FontSize, "12px");

		HtmlTableCell td2 = new HtmlTableCell();
		tr.Cells.Add(td2);
		td2.Align = "left";
		td2.Style.Add(HtmlTextWriterStyle.FontWeight, "bold");
		td2.Style.Add(HtmlTextWriterStyle.FontSize, "12px");
		td2.Style.Add(HtmlTextWriterStyle.FontFamily, "Tahoma");

		if (valore == null || valore == "")
		{
			valore = "<span>&nbsp</span>";
			td2.InnerHtml = valore;
		}
		else
			td2.InnerText = valore;
	}
	private static void GetDettaglioPopupRow(HtmlTable tb, string descrizione, DateTime? valore)
	{
		string r = valore.HasValue ? valore.Value.ToString("G") : null;
		GetDettaglioPopupRow(tb, descrizione, r);
	}

	protected void visualizzaA1A2_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (visualizzaA1A2.SelectedValue == "Tutti")
			_pageState.TipoSorv = BLSorveglianza.SorvTipoLTS.Tutti;
		else
			_pageState.TipoSorv = BLSorveglianza.SorvTipoLTS.noA2;
	}
}
