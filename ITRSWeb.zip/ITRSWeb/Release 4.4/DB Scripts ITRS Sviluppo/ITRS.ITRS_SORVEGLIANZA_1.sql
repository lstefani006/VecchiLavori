DROP PACKAGE BODY ITRS.ITRS_SORVEGLIANZA
GO
CREATE PACKAGE BODY ITRS.ITRS_SORVEGLIANZA AS

procedure AccodaEvento
(
  p_TARGA               in EVENTIDASEGNALARE.TARGA%TYPE,
  p_NAZIONALITA         in EVENTIDASEGNALARE.NAZIONALITA%TYPE,
  p_DATAORAINSERIMENTO  in EVENTIDASEGNALARE.DATAORAINSERIMENTO%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITISUEVENTO.DATAORARILEVAMENTO%TYPE,
  p_IDEVENTO            in EVENTIDASEGNALARE.IDEVENTO%TYPE,
  p_IDCOA               in EVENTIDASEGNALARE.IDCOACOMPETENZA%type,
  p_Img                 in ImmaginiSuEvento.IMMAGINE%type
)
is
  p_ProgrMin NUMBER;
  p_ProgrMax NUMBER;
begin

  -- la tabella SorveglianzaRes e` organizzata come una tabella circolare.
  -- Prog la PK viene incrementata sempre di uno ad ogni insert.
  -- Arrivati ad un numero di item massimi in SorveglianzaRes
  -- la tabella comincia a circolare updatando i record vecchi
  -- (che vengono persi).
  -- Il numero di item max e` cablato in questa SP ed e` attualmente 1000.
  -- Notare che se un allarme NON gestito diventa il 1000 al prossimo evento
  -- viene perso. Inoltre non e` detto che quest'evento sia preceduto da altri
  -- 999 eventi da questire, dato che gli eventi gestiti RIMANGONO nella tabella.
  -- Se questo comportamento non e` accettabile si puo`:
  -- 1) aumentare a 5000 il numero di record ... in questo modo non si risolve
  --    nulla ma si diminuisce la probabilita` che il fenomeno diventi apparente
  -- 2) Gestire la tabella SorvegianzaRes in modo diverso.

  begin
    select
    ProgrMax, ProgrMin into p_ProgrMax, p_ProgrMin
    from SorveglianzaResCount
    where IdCoa = p_IdCoa
    for update;
  exception when no_data_found then
    insert into SorveglianzaResCount
    (IdCoa, ProgrMin, ProgrMax) values
    (p_IdCoa, 0, -1);

    p_ProgrMin := 0;
    p_ProgrMax := -1;

  end;

  if (p_ProgrMax - p_ProgrMin + 1 >= 1000) then
    -- aggiorno il record piu` vecchio con il piu` nuovo
    update SorveglianzaRes
    set
    Targa = p_Targa,
    Nazionalita = p_Nazionalita,
    DataOraInserimento = p_DataOraInserimento,
    DataOraRilevamento = p_DataOraRilevamento,
    IdEvento = p_IdEvento,
    Progr = p_ProgrMax + 1,
    Immagine = p_Img
    where
    IdCoa = p_IdCoa
    and Progr = p_ProgrMin;

    update SorveglianzaResCount
    set
    ProgrMin = p_ProgrMin + 1,
    ProgrMax = p_ProgrMax + 1
    where
    IdCoa    = p_IdCoa;

  else
    insert into SorveglianzaRes
    (
      Targa,
      Nazionalita,
      DataOraInserimento,
      DataOraRilevamento,
      IdEvento,
      IdCoa,
      Progr,
      Immagine
    )
    values
    (
      p_Targa,
      p_Nazionalita,
      p_DataOraInserimento,
      p_DataOraRilevamento,
      p_IdEvento,
      p_IdCoa,
      p_ProgrMax + 1,
      p_Img
    );

    update SorveglianzaResCount
    set
    ProgrMax = p_ProgrMax + 1
    where
    IdCoa = p_IdCoa;

  end if;
end;

procedure GetListaEventi
(
  p_IDCOA  in  EVENTIDASEGNALARE.IDCOACOMPETENZA%type,
  p_Cur    out T_CURSOR
)
is
begin

  OPEN p_Cur FOR

    select Q.* from
    (
    select
    S.Targa,
    S.Nazionalita,
    S.Immagine,

    E.DataOraInserimento,
    E.IdEvento,
    E.EnumTipoEvento         TipoEvento,
    E.EnumStatoAllarme       StatoAllarme,
    UTEV.UserName            EvUtentePresaInCarico,
    E.DataOraPresaInCarico   EvDataOraPresaInCarico,
    E.DataOraChiusura        EvDataOraChiusura,
    E.NoteChiusura           EvNoteChiusura,
    E.EnumClasseUrgenza,

    T.EnumTipoVarco,
    T.DataOraRilevamento,
    T.EnumStatoTransito,
    UTTR.UserName           TrUtentePresaInCarico,
    T.DataOraPresaInCarico  TrDataOraPresaInCarico,
    T.DataOraChiusura       TrDataOraChiusura,
    T.NoteChiusura          TrNoteChiusura,

    nvl(T.Latitudine,  C2P.Lat) TrLatitudine,
    nvl(T.Longitudine, C2P.Lon) TrLongitudine,

    C2p.DIREZIONE           TrC2PDirezione,
    C2p.DESCRIZIONE         TrC2PDescrizione,

    Strade.DESCRIZIONESTRADA TrC2pStrada
    from SorveglianzaRes S

    inner join EventiDaSegnalare E
    on  E.Targa              = S.Targa
    and E.Nazionalita        = S.Nazionalita
    and E.DataOraInserimento = S.DataOraInserimento
    and E.IdEvento           = S.IdEvento

    inner join TransitiSuEvento T
    on  T.Targa              = S.Targa
    and T.Nazionalita        = S.Nazionalita
    and T.DataOraRilevamento = S.DataOraRilevamento

    left outer join ASPNET_USERS UTEV
    on  UTEV.pkid = E.IdUtentePresaInCarico

    left outer join ASPNET_USERS UTTR
    on  UTTR.pkid = T.IdUtentePresaInCarico

    inner join C2P
    on C2P.IDC2P = T.IDC2P

    inner join Strade
    on Strade.CODICESTRADA = C2P.CODICESTRADA

    where
    S.IDCOA = p_IDCOA and
    -- la sorveglianza fa vedere solo i transiti NON in stato Non Riconosciuto
    -- e con stato allarme QCQ e PIC (ossia non quelli gia` presi in carico)
    T.EnumStatoTransito <> 'NORIC' and
    (E.EnumStatoAllarme = 'ACQ' or E.EnumStatoAllarme = 'PIC')
    order by S.Progr desc
    ) Q
    where rownum <= 10;

end;



procedure GetDatiSorveglianza
(
  p_TARGA               in EVENTIDASEGNALARE.TARGA%TYPE,
  p_NAZIONALITA         in EVENTIDASEGNALARE.NAZIONALITA%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITISUEVENTO.DATAORARILEVAMENTO%TYPE,
  p_Cur                 out T_CURSOR
)
is
begin
  OPEN p_Cur FOR

    select
    T.Targa,
    T.Nazionalita,

    E.DataOraInserimento,
    E.IdEvento,
    E.EnumTipoEvento         TipoEvento,
    E.EnumStatoAllarme       StatoAllarme,
    UTEV.UserName            EvUtentePresaInCarico,
    E.DataOraPresaInCarico   EvDataOraPresaInCarico,
    E.DataOraChiusura        EvDataOraChiusura,
    E.NoteChiusura           EvNoteChiusura,
    E.EnumClasseUrgenza,

    T.EnumTipoVarco,
    T.DataOraRilevamento,
    T.EnumStatoTransito,
    UTTR.UserName           TrUtentePresaInCarico,
    T.DataOraPresaInCarico  TrDataOraPresaInCarico,
    T.DataOraChiusura       TrDataOraChiusura,
    T.NoteChiusura          TrNoteChiusura,

    nvl(T.Latitudine,  C2P.Lat) TrLatitudine,
    nvl(T.Longitudine, C2P.Lon) TrLongitudine,

    C2p.DIREZIONE           TrC2PDirezione,
    C2p.DESCRIZIONE         TrC2PDescrizione,

    Strade.DESCRIZIONESTRADA TrC2pStrada

    from TransitiSuEvento T

    inner join TransitiEventi TE
    on  TE.Targa              = T.Targa
    and TE.Nazionalita        = T.Nazionalita
    and TE.DataOraRilevamento = T.DataOraRilevamento

    inner join EventiDaSegnalare E
    on  E.Targa              = TE.Targa
    and E.Nazionalita        = TE.Nazionalita
    and E.DataOraInserimento = TE.DataOraInserimento
    and E.IdEvento           = TE.IdEvento
    and E.EnumTipoEvento     = 'TS'

    left outer join ASPNET_USERS UTEV
    on  UTEV.pkid = E.IdUtentePresaInCarico

    left outer join ASPNET_USERS UTTR
    on  UTTR.pkid = T.IdUtentePresaInCarico

    inner join C2P
    on C2P.IDC2P = T.IDC2P

    inner join Strade
    on Strade.CODICESTRADA = C2P.CODICESTRADA

    where
    T.Targa = p_Targa
    and T.Nazionalita = p_Nazionalita
    and T.DataOraRilevamento = p_DataOraRilevamento;


end;

END;
GO
