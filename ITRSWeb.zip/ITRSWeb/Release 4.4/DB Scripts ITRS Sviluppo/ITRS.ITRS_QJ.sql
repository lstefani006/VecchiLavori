DROP PACKAGE ITRS.ITRS_QJ
GO
CREATE PACKAGE ITRS.ITRS_QJ as

	-- stati QUEUE, RUN, SOSP, ERR, RRES, END, ABRQ, ABAK, CANC
	-- QUEUE job in coda
	-- RUN   job in esecuzione
	-- SOSP  job sospeso
	-- ERR   job terminato con eccezione
	-- RRES  job in run che ha prodotto risultati intermedi
	-- END   job terminato con successo
	-- ABRQ  job con richiesta di abort in corso
	-- ABAK  job che ha accettato la richiesta di abort
	-- CANC  job cancellato dall'utente dopo la sospensione

	-- crea un nuovo job in stato QUEUE
	procedure QJ_Create
	(
		p_QJID       in QJOBS.QJID%TYPE,
		p_QJTYPE     in QJOBS.QJTYPE%TYPE,
		p_QJARGS     in QJOBS.QJARGS%TYPE,
		p_QJPKIDUSER in QJOBS.QJPKIDUSER%TYPE
	);
	procedure QJ_CreateEx
	(
		p_QJID       in QJOBS.QJID%TYPE,
		p_QJTYPE     in QJOBS.QJTYPE%TYPE,
		p_QJARGS     in QJOBS.QJARGS%TYPE,
		p_QJPKIDUSER in QJOBS.QJPKIDUSER%TYPE,
                p_JobAccepted out int  -- 1 accettato, 0 non accettato
	);

	-- User : metto il job in stato ABRQ
	procedure QJ_Abort(p_QJID in QJOBS.QJID%TYPE);

	-- User : metto il job in stato SOSP (solo se sono in QUEUE)
	procedure QJ_Suspend(p_QJID in QJOBS.QJID%TYPE);

	-- User : metto il job in stato QUEUE (solo se sono in SOSP)
	procedure QJ_Resume(p_QJID in QJOBS.QJID%TYPE);

	-- Batch : cambia lo stato
	procedure QJ_ChangeStatus(p_QJID in QJOBS.QJID%TYPE, p_QJSTATUS in QJOBS.QJSTATUS%TYPE);

	-- Batch : memorizza lo stato attuale di esecuzione
	procedure QJ_Progress
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJSTATUS      in QJOBS.QJSTATUS%TYPE,
		p_QJPROGRMSG    in QJOBS.QJPROGRMSG%TYPE,
		p_QJTOTALSTEPS  in QJOBS.QJTOTALSTEPS%TYPE,
		p_QJCURRENTSTEP in QJOBS.QJCURRENTSTEP%TYPE,
		p_QJRESRECORDCOUNT in QJOBS.QJRESRECORDCOUNT%TYPE
	);

	-- Batch : da chiamare quando il batch va in eccezione
	procedure QJ_Error
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJERRMSG      in QJOBS.QJERRMSG%TYPE
	);


	-- Batch : da chiamare quando il batch termina
	procedure QJ_End
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJPROGRMSG    in QJOBS.QJPROGRMSG%TYPE,
		p_QJRESULT      in QJOBS.QJRESULT%TYPE
	);

	-- User : da chiamare quando l'utente interroga il risultato.
	-- In questo modo si prolunga la vita del result del job.
	procedure QJ_Access
	(
		p_QJID          in QJOBS.QJID%TYPE
	);

	-- User : mette in stato CANC i job vecchi
	procedure QJ_Purge;

        -- User: mette in CANC i joob che soddisfano le caratteristiche in
        -- ingresso.
	procedure QJ_Canc
        (
                p_QJID       QJOBS.QJID%type,
                p_QJTYPE     QJOBS.QJTYPE%type,
                p_QJPKIDUSER QJOBS.QJPKIDUSER%type,
                p_QJSTATUS   QJOBS.QJSTATUS%type
        );


	-- Batch: ottiene il prossivo job da eseguire, se esiste.
	procedure QJ_GetNextToRun
	(
		p_QJID       out QJOBS.QJID%TYPE,
		p_QJARGS     out QJOBS.QJARGS%TYPE,
		p_QJTYPE     out QJOBS.QJTYPE%TYPE
	);

end;
GO
