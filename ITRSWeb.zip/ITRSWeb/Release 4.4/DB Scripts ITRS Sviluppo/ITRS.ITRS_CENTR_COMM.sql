DROP PACKAGE ITRS.ITRS_CENTR_COMM
GO
CREATE PACKAGE ITRS.ITRS_CENTR_COMM          IS

PROCEDURE InsertAllarmi(V_TARGA IN varchar2,V_NAZ IN varchar2,V_QMGR_NAME IN varchar2,D_DATAORARILEV IN date,V_ENUMTIPOVARCO IN varchar2,
                       N_CONFACQTARGA IN number,V_FORMATO IN varchar2,V_CODIFICA IN varchar2,V_RISOLUZIONE IN varchar2,V_IMMAGINE IN varchar2,
                       V_CLASSE_URGENZA OUT varchar2, V_SEQ_IM_CUR OUT Varchar2,ERRCODE OUT integer, ERRMSG OUT varchar2, RETVAL OUT integer);

PROCEDURE DatiEmail ( V_ID_VARCO IN varchar2, V_ID_UTENTE IN varchar2, V_ID_C2P IN varchar2, VARCO OUT varchar2, UTENTE OUT varchar2,DIREZIONE OUT varchar2,VARCODESC OUT varchar2,CODICESTRADA OUT varchar2,KM OUT varchar2, ERRCODE OUT integer, ERRMSG OUT varchar2, RETVAL OUT integer);


end ITRS_CENTR_COMM;
GO
