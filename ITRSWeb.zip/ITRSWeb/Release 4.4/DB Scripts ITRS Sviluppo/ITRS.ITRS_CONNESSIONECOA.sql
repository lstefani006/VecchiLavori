DROP PACKAGE ITRS.ITRS_CONNESSIONECOA
GO
CREATE PACKAGE ITRS.ITRS_CONNESSIONECOA as
procedure Login
  (
  p_UserPkId     in   ASPNET_USERS.PKID%type,
  p_IdCoa        in   COA.IDCOA%type,
  p_IdSessione   in   CONNESSIONIATTIVECOA.IdSessione%type,
  p_IdPostazione out  CONNESSIONIATTIVECOA.IdPostazione%type
  );
  procedure Logout(p_IdSessione in   CONNESSIONIATTIVECOA.IdSessione%type);

end;
GO
