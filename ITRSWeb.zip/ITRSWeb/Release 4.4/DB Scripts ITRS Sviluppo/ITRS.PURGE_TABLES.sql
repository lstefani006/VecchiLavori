DROP PROCEDURE ITRS.PURGE_TABLES
GO
CREATE PROCEDURE ITRS.PURGE_TABLES IS

actdate date;
Purge_Max    number(6);
NumofDays number(10);
Righe		number :=0;

begin
 dbms_output.put_line('Inizio esecuzione Purge_Tables');

 select trunc(sysdate) into actdate from dual;

 select ParValue
 into Purge_Max
 from Parametri
 where ParTipo = 'PURGER_LOTTO';

 dbms_output.put_line('Valore parametro PURGER_LOTTO ' || to_char(Purge_Max));

 select ParValue
 into NumofDays
 from Parametri
 where ParTipo = 'PURGER_EXPTIME';

 dbms_output.put_line('Verranno cancellati i records piu'' vecchi del '||to_char(actdate - NumofDays,'dd/mm/yy hh24:mi:ss'));

 Righe := 1;

 while Righe <> 0 loop
 	--Cancella da EventiDaSegnalare-Segnalazioni-TransitiEventi
  delete from EventiDaSegnalare
  where dataorainserimento <= actdate - NumofDays
  and rownum <= Purge_Max;

  Righe := SQL%ROWCOUNT;
  commit;

  dbms_output.put_line('Cancellati '||to_char(Righe)||' records da EventiDaSegnalare');

 end loop;

 Righe := 1;

 while Righe <> 0 loop
 	--Cancella da TransitiSuEvento-ImmaginiSuEvento
  delete from TransitiSuEvento
  where dataorainserimento <= actdate - NumofDays
  and rownum <= Purge_Max;

  Righe := SQL%ROWCOUNT;
  commit;

  dbms_output.put_line('Cancellati '||to_char(Righe)||' records da TransitiSuEvento');

 end loop;

 --Cancella da tabelle statistiche giornaliere
 Righe := 0;

 delete from Tempi_Veloc_Percorr_Tratta
 where data_rep <= actdate - NumofDays;

 Righe := SQL%ROWCOUNT;

 dbms_output.put_line('Cancellati '||to_char(Righe)||' records da Tempi_Veloc_Percorr_Tratta');

 Righe := 0;

 delete from Tempi_Veloc_Percorr_Direz
 where data_rep <= actdate - NumofDays;

 Righe := SQL%ROWCOUNT;

 dbms_output.put_line('Cancellati '||to_char(Righe)||' records da Tempi_Veloc_Percorr_Direz');

 Righe := 0;

 delete from Vol_Traff_Tratta
 where data_rep <= actdate - NumofDays;

 Righe := SQL%ROWCOUNT;

 dbms_output.put_line('Cancellati '||to_char(Righe)||' records da Vol_Traff_Tratta');

 Righe := 0;

 delete from Vol_Traff_Direz
 where data_rep <= actdate - NumofDays;

 Righe := SQL%ROWCOUNT;

 dbms_output.put_line('Cancellati '||to_char(Righe)||' records da Vol_Traff_Direz');

 Righe := 0;

 delete from Tempi_Sosta_C2p
 where data_rep <= actdate - NumofDays;

 Righe := SQL%ROWCOUNT;
 commit;

 dbms_output.put_line('Cancellati '||to_char(Righe)||' records da Tempi_Sosta_C2p');

 dbms_output.put_line('Purge_Tables terminato senza anomalie');

 Exception
  when Others then
           dbms_output.put_line('Errore durante esecuzione Purge_Tables');
           dbms_output.put_line('Errore: ' || substr(sqlerrm,1,250));
	   Rollback;

end Purge_Tables;
GO
