DROP PACKAGE ITRS.ITRS_INDAGINI
GO
CREATE PACKAGE ITRS.ITRS_INDAGINI IS

procedure QUERYINDAGINETRANSITI
(
	p_qjid        in varchar2,
	p_targa       in varchar2,
	p_nazionalita in varchar2,
	p_di          in date,
	p_df          in date,
        p_idc2p       in C2P.IDC2P%type,
	p_found       out int,
        p_MaxRec      out int
);

procedure QUERYINDAGINEEVENTI
(
	p_qjid        in varchar2,
	p_targa       in varchar2,
	p_nazionalita in varchar2,
	p_di          in date,
	p_df          in date,
        p_idc2p       in C2P.IDC2P%type,
        p_tipoEvento  in EVENTIDASEGNALARE.ENUMTIPOEVENTO%type,
	p_found       out int,
        p_MaxRec      out int
);

procedure CancellaIndagine
(
	p_qjid        in varchar2
);

end ITRS_INDAGINI;
GO
