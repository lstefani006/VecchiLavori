DROP FUNCTION ITRS.PART_DATE
GO
CREATE FUNCTION ITRS.PART_DATE (partition_name varchar2) return DATE
is
begin
  return (TO_DATE(substr(partition_name,4,6),'ddmmyy'));
end;
GO
