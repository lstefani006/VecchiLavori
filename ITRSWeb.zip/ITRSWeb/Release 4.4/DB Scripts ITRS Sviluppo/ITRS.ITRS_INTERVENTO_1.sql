DROP PACKAGE BODY ITRS.ITRS_INTERVENTO
GO
CREATE PACKAGE BODY ITRS.ITRS_INTERVENTO as

-- ritorna in p_QJOBIDOLD
-- il guid del nuovo job
-- oppure il guid di un job esistente
-- oppure '' se non e` stato possibile lanciare il job
procedure CreateIntervento
(
p_QJID        in QJOBS.QJID%TYPE,
p_QJTYPE      in QJOBS.QJTYPE%TYPE,
p_QJARGS      in QJOBS.QJARGS%TYPE,
p_QJPKIDUSER  in QJOBS.QJPKIDUSER%TYPE,
p_TARGA       in TRANSITI.TARGA%TYPE,
p_NAZIONALITA in TRANSITI.NAZIONALITA%TYPE,
p_MOTIVO      in LTS.MOTIVO%TYPE,
p_NOTE        in LTS.NOTE%TYPE,
p_IDCOA       in COA.IDCOA%TYPE,

p_QJOBIDOLD   out QJOBS.QJID%TYPE
)
is
P_IDLTS LTS.IDLTS%type;
p_JobAccepted int;

begin

    -- controllo se esiste gia` una entry per l'utente/targa/nazionalita
    BEGIN
      SELECT idlts INTO P_IDLTS FROM lts_bc
      WHERE
      TARGA = p_TARGA and
      NAZIONALITA = p_NAZIONALITA and
      AddrDest = p_IDCOA and
      EnumTipoLts = 'C' and
      EnumTipoDest = 'COA';

    exception
      WHEN no_data_found THEN
        -- non esiste --> lo inserisco
        INSERT INTO ITRS.LTS_BC
        (TARGA,   NAZIONALITA,   IDLTS,           ENUMTIPOLTS, IDUTENTERICHIEDENTE, MOTIVO,   NOTE,   DATAORAINSERIMENTO, DATAORAINIZIOVALIDITA, DATAORAFINEVALIDITA, ENUMTIPODEST, ADDRDEST, ENUMLIVELLOPRIORITA)
        VALUES
        (p_TARGA, p_NAZIONALITA, SEQ_LTS.nextval, 'C',         p_QJPKIDUSER,        p_MOTIVO, p_NOTE, SYSDATE,            SYSDATE,               SYSDATE + (356*30),             'COA',        p_IDCOA,  'MAX');
    END;


    begin
      -- Cerco un intervento con la stessa targa/nazionalita` in stato QUEUE, RUN, RRES, END
      -- se lo trovo e` inutile lanciare un nuovo job --> ritorno il QJID del job appena trovato
      select
      QJOBS.QJID into p_QJOBIDOLD
      from QJOBS_INTERVENTI
      inner join QJOBS
      on QJOBS.QJID = QJOBS_INTERVENTI.QJID
      where
      QJOBS_INTERVENTI.TARGA = p_TARGA and
      QJOBS_INTERVENTI.NAZIONALITA = p_NAZIONALITA and
      QJOBS.QJSTATUS in ('QUEUE', 'RUN', 'RRES', 'END');

    exception
      when no_data_found then

    	ITRS.ITRS_QJ.QJ_CreateEx(P_QJID, P_QJTYPE, P_QJARGS, p_QJPKIDUSER, p_JobAccepted);
        if (p_JobAccepted = 0) then
          p_QJOBIDOLD := '';
          return;
        end if;

        INSERT INTO ITRS.QJOBS_INTERVENTI
        (
          QJID, TARGA, NAZIONALITA,
          UT_DATAORARILEVAMENTO, UT_C2P_DESCRIZIONE, UT_C2P_DIREZIONE,
          UT_ENUMTIPOVARCO, UT_ENUMSTATOTRANSITO, UT_EVENTOASSOCIATOALTRANSITO,
          UT_IDEVENTO, UT_DATAORAINSERIMENTO, UT_ENUMSTATOALLARME
        )
        VALUES
        (
          P_QJID, P_TARGA, P_NAZIONALITA,
          NULL, NULL, NULL,
          NULL, NULL, NULL,
          null, null, null
        );

        p_QJOBIDOLD := P_QJID;
    end;
end;

procedure QueryIntervento
(
	p_QJID           in     QJOBS.QJID%TYPE,
	p_TARGA          in     TRANSITI.TARGA%TYPE,
	p_NAZIONALITA    in     TRANSITI.NAZIONALITA%TYPE,
	p_DI             in     date,
	p_DF             in     date,
	p_ROWS           out    integer,
	p_PRIMO_TRANSITO in out varchar2
)
is
begin
        -- ricerco e metto il risultato nella tabella QJOBSRES_INTERVENTI
        -- i transiti per la targa/di/df nella tabella TRANSITI.
        -- Memorizzo inoltre i dati realtivi all'evento associato al transito
        -- (se esiste) qualora questo sia un evento di tipo LTS

	insert into ITRS.QJOBSRES_INTERVENTI
	(
	QJID,
	TARGA,
	NAZIONALITA,
	DATAORARILEVAMENTO,
	C2P_DESCRIZIONE,
	C2P_DIREZIONE,
	ENUMTIPOVARCO,
	ENUMSTATOTRANSITO,
	EVENTOASSOCIATOALTRANSITO,

        -- dati dell'eventuale allarme per LTS
        IDEVENTO,
        DATAORAINSERIMENTO,
        ENUMSTATOALLARME
	)
	select
	p_QJID                                 QJID,
	TRANSITI.TARGA                         TARGA,
	TRANSITI.NAZIONALITA                   NAZIONALITA,
	TRANSITI.DATAORARILEVAMENTO            DATAORARILEVAMENTO,
	C2P.DESCRIZIONE                        C2P_DESCRIZIONE,
	C2P.DIREZIONE                          C2P_DIREZIONE,
	TRANSITI.ENUMTIPOVARCO                 ENUMTIPOVARCO,
	TRANSITI.ENUMSTATOTRANSITO             ENUMSTATOTRANSITO, -- DARIC RIC NORIC PIC (preso in carico)
	nvl2(TRANSITISUEVENTO.TARGA, 'S', 'N') EVENTOASSOCIATOALTRANSITO,
        EVENTIDASEGNALARE.IDEVENTO             IDEVENTO,
        EVENTIDASEGNALARE.DATAORAINSERIMENTO   DATAORAINSERIMENTO,
        EVENTIDASEGNALARE.ENUMSTATOALLARME     ENUMSTATOALLARME

	from
        (
          -- prendo i transiti e il transiti segnalati
          select
          TARGA,
          NAZIONALITA,
          DATAORARILEVAMENTO,
          ENUMTIPOVARCO,
          ENUMSTATOTRANSITO,
          IDC2P
          from Transiti TA
          where
              TA.DATAORARILEVAMENTO >= p_DI
          and TA.DATAORARILEVAMENTO < p_DF
          and TA.Targa = p_TARGA
          and TA.Nazionalita = p_NAZIONALITA

          union

          select
          TARGA,
          NAZIONALITA,
          DATAORARILEVAMENTO,
          ENUMTIPOVARCO,
          ENUMSTATOTRANSITO,
          IDC2P
          from
          transitiSuEvento TB
          where
              TB.DATAORARILEVAMENTO >= p_DI
          and TB.DATAORARILEVAMENTO < p_DF
          and TB.Targa = p_TARGA
          and TB.Nazionalita = p_NAZIONALITA
        ) TRANSITI

	inner join C2P
	on C2P.IDC2P = TRANSITI.IDC2P

        -- controllo se nella tabella gemella a Transiti esiste lo stesso
        -- record.
	left outer join TRANSITISUEVENTO
	on  TRANSITI.TARGA              = TRANSITISUEVENTO.TARGA
	and TRANSITI.NAZIONALITA        = TRANSITISUEVENTO.NAZIONALITA
	and TRANSITI.DATAORARILEVAMENTO = TRANSITISUEVENTO.DATAORARILEVAMENTO

        left outer join TRANSITIEVENTI
        on  TRANSITIEVENTI.TARGA = TRANSITI.TARGA
        and TRANSITIEVENTI.NAZIONALITA = TRANSITI.NAZIONALITA
        and TRANSITIEVENTI.DATAORARILEVAMENTO = TRANSITI.DATAORARILEVAMENTO

        left outer join EVENTIDASEGNALARE
        on  EVENTIDASEGNALARE.TARGA = TRANSITIEVENTI.TARGA
        and EVENTIDASEGNALARE.NAZIONALITA = TRANSITIEVENTI.NAZIONALITA
        and EVENTIDASEGNALARE.DATAORAINSERIMENTO = TRANSITIEVENTI.DATAORAINSERIMENTO
        and EVENTIDASEGNALARE.IDEVENTO = TRANSITIEVENTI.IDEVENTO
        and EVENTIDASEGNALARE.ENUMTIPOEVENTO = 'TS' -- transito segnalato
        ;

	p_ROWS := sql%rowcount;

	-- Sto facendo la ricerca del transito per una targa.
	-- Nella tabella QJOBS_INTERVENTI e` memorizzato il transito piu` recente,
	-- o l'ultimo transito ottenuto quando il campo chiama OnAllarme.
	-- Se esiste gia` l'ultimo transito nella QJOBS_INTERVENTI
	-- (sia per allarmi o perche` ne avevo trovato uno in precedenza)
	-- non memorizzo niente.
	-- Per evitare di fare troppe query, il parametro p_PRIMO_TRANSITO indica se e` gia` stato
	-- memorizzato il primo transito per questa targa.
	if (p_ROWS > 0 and p_PRIMO_TRANSITO = 'false') then
	  declare
			p_DATE date;
		begin
			-- qui rifaccio la query xche` potrebbe, nel frattempo, essere arrivato OnAllarme
			-- e poi per lockare il record per evitare problemi di concorrenza
			select
			UT_DATAORARILEVAMENTO into p_DATE
			from QJOBS_INTERVENTI
			where
			TARGA = p_TARGA and
			NAZIONALITA = p_NAZIONALITA and
			QJID = p_QJID and
			not (UT_DATAORARILEVAMENTO is null)
			for update;

			p_PRIMO_TRANSITO := 'true';

		exception when no_data_found then
			p_PRIMO_TRANSITO := 'false';
		end;

		if (p_PRIMO_TRANSITO = 'false') then
			-- non e` stato ancora rilevato il primo transito, ma, nell'ultima query
			-- ne ho trovato almeno uno.
			declare
				p_DATAORARILEVAMENTO        ITRS.QJOBSRES_INTERVENTI.DATAORARILEVAMENTO%type;
				p_C2P_DESCRIZIONE           ITRS.QJOBSRES_INTERVENTI.C2P_DESCRIZIONE%type;
				p_C2P_DIREZIONE             ITRS.QJOBSRES_INTERVENTI.C2P_DIREZIONE%type;
				p_ENUMTIPOVARCO             ITRS.QJOBSRES_INTERVENTI.ENUMTIPOVARCO%type;
				p_ENUMSTATOTRANSITO         ITRS.QJOBSRES_INTERVENTI.ENUMSTATOTRANSITO%type;
				p_EVENTOASSOCIATOALTRANSITO ITRS.QJOBSRES_INTERVENTI.EVENTOASSOCIATOALTRANSITO%type;

                                p_UT_IDEVENTO               ITRS.QJOBSRES_INTERVENTI.IDEVENTO%type;
                                p_UT_DATAORAINSERIMENTO     ITRS.QJOBSRES_INTERVENTI.DATAORAINSERIMENTO%type;
                                p_UT_ENUMSTATOALLARME       ITRS.QJOBSRES_INTERVENTI.ENUMSTATOALLARME%type;

			begin
				-- cerco il transito piu` recente con rownum <= 1
				select
				DATAORARILEVAMENTO,
				C2P_DESCRIZIONE,
				C2P_DIREZIONE,
				ENUMTIPOVARCO,
				ENUMSTATOTRANSITO,
				EVENTOASSOCIATOALTRANSITO,

                                IDEVENTO,
                                DATAORAINSERIMENTO,
                                ENUMSTATOALLARME

				into
				p_DATAORARILEVAMENTO,
				p_C2P_DESCRIZIONE,
				p_C2P_DIREZIONE,
				p_ENUMTIPOVARCO,
				p_ENUMSTATOTRANSITO,
				p_EVENTOASSOCIATOALTRANSITO,

                                p_UT_IDEVENTO,
                                p_UT_DATAORAINSERIMENTO,
                                p_UT_ENUMSTATOALLARME

				from ITRS.QJOBSRES_INTERVENTI
				where
				QJID = p_QJID and
				TARGA = p_TARGA and
				NAZIONALITA = p_NAZIONALITA and
				rownum <= 1
				order by DATAORARILEVAMENTO desc;

				-- aggiorno QJOBS_INTERVENTI con i dati del transito piu` recente
				update ITRS.QJOBS_INTERVENTI
				set
				UT_DATAORARILEVAMENTO        = p_DATAORARILEVAMENTO,
				UT_C2P_DESCRIZIONE           = p_C2P_DESCRIZIONE,
				UT_C2P_DIREZIONE             = p_C2P_DIREZIONE,
				UT_ENUMTIPOVARCO             = p_ENUMTIPOVARCO,
				UT_ENUMSTATOTRANSITO         = p_ENUMSTATOTRANSITO,
				UT_EVENTOASSOCIATOALTRANSITO = p_EVENTOASSOCIATOALTRANSITO,

                                UT_IDEVENTO                  = p_UT_IDEVENTO,
                                UT_DATAORAINSERIMENTO        = p_UT_DATAORAINSERIMENTO,
                                UT_ENUMSTATOALLARME          = p_UT_ENUMSTATOALLARME

				where
				TARGA = p_TARGA and
				NAZIONALITA = p_NAZIONALITA and
				QJID = p_QJID;

				p_PRIMO_TRANSITO := 'true';
			end;
		end if;
	end if;

	-- qui scrivo nel DB e rilascio il lock for update
	commit;
end;


  procedure DeleteIntervento
  (
  p_QJID        in  QJOBS.QJID%TYPE ,
  p_TARGA       out TRANSITI.TARGA%TYPE,
  p_NAZIONALITA out TRANSITI.NAZIONALITA%TYPE,
  p_QMGR        out T_CURSOR
  )
  is
  begin
    -- trovo il targa/nazionalita associata all'intervento
    select Targa, Nazionalita
    into p_Targa, p_Nazionalita
    from QJOBS_INTERVENTI
    where QJID = p_QJID;

    -- cancello TUTTE le entry che si riferiscono a questa targa in LTS
    delete from LTS_BC
    where
    Targa = p_Targa and
    Nazionalita = p_Nazionalita and
    EnumTipoLts = 'C' and
    EnumTipoDest = 'COA';

    -- cancello tutte la roba associata a QJID
    delete from ITRS.QJOBSRES_INTERVENTI where QJID = p_QJID;
    delete from ITRS.QJOBS_INTERVENTI where QJID = p_QJID;
    delete from ITRS.QJOBS where  QJID = p_QJID;

    -- chiamo la sp per sapere quali C2P sono da aggiornare
    -- nel caso che la targa/nazionalita` non sia piu` nella
    -- tabella LTS
    ITRS_LTS_MWP.GetListC2PFromTarga(p_Targa, p_Nazionalita, p_QMGR);

  exception
    when others then
      rollback;
      raise;
  end;


  procedure Test
  (
  p_QJID        in  QJOBS.QJID%TYPE,
  p_TARGA       in  TRANSITI.TARGA%TYPE,
  p_NAZIONALITA in  TRANSITI.NAZIONALITA%TYPE,
  p_DI          in  DATE,
  p_ROWS        out integer,
  p_STR         out TRANSITI.TARGA%TYPE
  )
  is
  P_VAR VARCHAR2(100);
  begin

  p_ROWS:=10000000000;
  p_STR := 'cicci';

  select QJSTATUS into P_VAR from QJOBS where QJID = p_QJID;

  end;


procedure OnAllarme
(
  p_TARGA               in TRANSITI.TARGA%TYPE,
  p_NAZIONALITA         in TRANSITI.NAZIONALITA%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITI.DATAORARILEVAMENTO%TYPE,

  p_QMGR_NAME           in C2P.QMGR_NAME%TYPE,
  p_TIPOVARCO           in VARCHAR2
)
is
	p_ENUMTIPOVARCO       TRANSITI.ENUMTIPOVARCO%type;
	p_C2P_DESCRIZIONE     C2P.DESCRIZIONE%type;
	p_C2P_DIREZIONE       C2P.DIREZIONE%type;

	p_ENUMSTATOTRANSITO   TRANSITI.ENUMSTATOTRANSITO%type;

        p_IDEVENTO            NUMBER(10,0) null;
        p_DATAORAINSERIMENTO  DATE null;
        p_ENUMSTATOALLARME    varchar2(5) null;
begin

	-- traduco il tipo varco: se non esiste la voce si genera una case_not_found exception
	case LTRIM(p_TIPOVARCO, '0')
	when ITRS_CONST_PKG.VAL_TIPOVARCO_1 then p_ENUMTIPOVARCO := ITRS_CONST_PKG.VAL_TIPOVARCO_USCITA;
	when ITRS_CONST_PKG.VAL_TIPOVARCO_2 then p_ENUMTIPOVARCO := ITRS_CONST_PKG.VAL_TIPOVARCO_INGRESSO;
	when ITRS_CONST_PKG.VAL_TIPOVARCO_3 then p_ENUMTIPOVARCO := ITRS_CONST_PKG.VAL_TIPOVARCO_SX;
	when ITRS_CONST_PKG.VAL_TIPOVARCO_4 then p_ENUMTIPOVARCO := ITRS_CONST_PKG.VAL_TIPOVARCO_DX;
	end case;

	select
	DESCRIZIONE, DIREZIONE
	into
	p_C2P_DESCRIZIONE, p_C2P_DIREZIONE
	from C2P
	where
	QMGR_NAME = p_QMGR_NAME;

        -- trovo se esiste l'allarme associato di tipo TS
        begin
          select
          EVENTIDASEGNALARE.IDEVENTO,
          EVENTIDASEGNALARE.DATAORAINSERIMENTO,
          EVENTIDASEGNALARE.ENUMSTATOALLARME
          into
          p_IDEVENTO,
          p_DATAORAINSERIMENTO,
          p_ENUMSTATOALLARME
          from EVENTIDASEGNALARE
          inner join TRANSITIEVENTI
          on  TRANSITIEVENTI.TARGA              = EVENTIDASEGNALARE.TARGA
          and TRANSITIEVENTI.NAZIONALITA        = EVENTIDASEGNALARE.NAZIONALITA
          and TRANSITIEVENTI.DATAORAINSERIMENTO = EVENTIDASEGNALARE.DATAORAINSERIMENTO
          and TRANSITIEVENTI.IDEVENTO           = EVENTIDASEGNALARE.IDEVENTO
          where
              TRANSITIEVENTI.TARGA              = p_Targa
          and TRANSITIEVENTI.NAZIONALITA        = p_Nazionalita
          and TRANSITIEVENTI.DATAORARILEVAMENTO = p_DATAORARILEVAMENTO
          and EVENTIDASEGNALARE.TARGA           = p_Targa
          and EVENTIDASEGNALARE.NAZIONALITA     = p_Nazionalita
          and EVENTIDASEGNALARE.ENUMTIPOEVENTO  = 'TS';
        exception when no_data_found then
          return;
        end;

        begin
          select
          TRANSITISUEVENTO.ENUMSTATOTRANSITO
          into
          p_ENUMSTATOTRANSITO
          from TRANSITISUEVENTO
          where
          TRANSITISUEVENTO.TARGA = p_Targa
          and TRANSITISUEVENTO.NAZIONALITA = p_Nazionalita
          and TRANSITISUEVENTO.DATAORARILEVAMENTO = p_DATAORARILEVAMENTO;
        exception when no_data_found then
          return;
        end;


	declare
		cursor cur is
			select
			QJOBS.QJID
			from QJOBS_INTERVENTI
			inner join QJOBS
			on QJOBS.QJID = QJOBS_INTERVENTI.QJID
			where
			QJOBS_INTERVENTI.TARGA = p_TARGA and
			QJOBS_INTERVENTI.NAZIONALITA= p_NAZIONALITA and
			QJOBS.QJSTATUS in ('QUEUE', 'RUN', 'RRES', 'END');

		rec cur%rowtype;

	begin
		open cur;
		loop
			fetch cur into rec;
			exit when not cur%FOUND;

			update ITRS.QJOBS_INTERVENTI
			set
			UT_DATAORARILEVAMENTO        = p_DATAORARILEVAMENTO,
			UT_C2P_DESCRIZIONE           = p_C2P_DESCRIZIONE,
			UT_C2P_DIREZIONE             = p_C2P_DIREZIONE,
			UT_ENUMTIPOVARCO             = p_ENUMTIPOVARCO,
			UT_ENUMSTATOTRANSITO         = p_ENUMSTATOTRANSITO,
			UT_EVENTOASSOCIATOALTRANSITO = 'S'
			where
			TARGA = p_TARGA and
			NAZIONALITA = p_NAZIONALITA and
			QJID = rec.QJID;

        begin

	-- metto il record nella tabella dei risultati
	insert into ITRS.QJOBSRES_INTERVENTI
	(
        QJID,
        TARGA,
        NAZIONALITA,
        DATAORARILEVAMENTO,
        C2P_DESCRIZIONE,
        C2P_DIREZIONE,
        ENUMTIPOVARCO,
        ENUMSTATOTRANSITO,
        EVENTOASSOCIATOALTRANSITO,

        -- dati dell'eventuale allarme per LTS
        IDEVENTO,
        DATAORAINSERIMENTO,
        ENUMSTATOALLARME
      )
      values
      (
        rec.QJID,
        p_TARGA,
        p_NAZIONALITA,
        p_DATAORARILEVAMENTO,
        p_C2P_DESCRIZIONE,
        p_C2P_DIREZIONE,
        p_ENUMTIPOVARCO,
        p_ENUMSTATOTRANSITO,
        'S',

        -- dati dell'eventuale allarme per LTS
        p_IDEVENTO,
        p_DATAORAINSERIMENTO,
        p_ENUMSTATOALLARME
      );

      exception
        when DUP_VAL_ON_INDEX then
          null;
      end;


      end loop;
      close cur;
      end;
end;

-- lista degli interventi per coa.
procedure ListaInterventiPerCoa
(
	p_IdCoa  in  COA.IdCoa%TYPE,
	p_Cur    out T_CURSOR
)
is
	p_PKID  ASPNET_USERS.PKID%TYPE;
begin

	OPEN p_Cur FOR
		SELECT
		LTS.Note,
		LTS.Motivo,
		QJOBS.*,
		QJOBS_INTERVENTI.*

		FROM LTS
		inner join QJOBS_INTERVENTI
		on
		QJOBS_INTERVENTI.TARGA = Lts.TARGA and
		QJOBS_INTERVENTI.NAZIONALITA= Lts.NAZIONALITA
		inner join QJOBS
		on QJOBS.QJID = QJOBS_INTERVENTI.QJID
		where
		LTS.AddrDest = p_IdCoa and
		LTS.EnumTipoLts = 'C' and
    LTS.EnumTipoDest = 'COA'
    order by QJOBS_INTERVENTI.Targa;

end;


procedure CancellaInterventoPerCoa
(
p_IdCoa       in COA.IdCoa%type,
p_TARGA       in TRANSITI.TARGA%TYPE,
p_NAZIONALITA in TRANSITI.NAZIONALITA%TYPE,
p_QMGR        out T_CURSOR
)
is
	p_PKID  ASPNET_USERS.PKID%TYPE;
	p_NumeroJobs number;
begin

	-- cancello l'entry in LTS per l'intervento/coa
	delete from LTS_BC
	where Targa = p_TARGA and
	Nazionalita = p_Nazionalita and
	AddrDest = p_IdCoa and
  EnumTipoLts = 'C' and
  EnumTipoDest = 'COA';

  -- controllo se ci sono altri COA che condividono lo stesso intervento
  select count(*) into p_NumeroJobs
  from LTS
  where Targa = p_TARGA and
  Nazionalita = p_Nazionalita and
  LTS.EnumTipoLts = 'C' and
  LTS.EnumTipoDest = 'COA';

  -- se p_NumeroJobs=0 cancello tutti i record di tutti gli interventi
  -- afferenti a quella targa.
  declare cursor cur is
    select
    QJID
    FROM QJOBS_INTERVENTI
    where
    QJOBS_INTERVENTI.TARGA = p_TARGA and
    QJOBS_INTERVENTI.NAZIONALITA= p_NAZIONALITA and
    p_NumeroJobs = 0;

    rec cur%rowtype;
    begin
      open cur;
      loop
        fetch cur into rec;
	exit when not cur%FOUND;

        delete from ITRS.QJOBSRES_INTERVENTI where QJID = rec.QJID;
        delete from ITRS.QJOBS_INTERVENTI where QJID = rec.QJID;
        delete from ITRS.QJOBS where QJID = rec.QJID;
      end loop;
    end;

   ITRS_LTS_MWP.GetListC2PFromTarga(p_Targa, p_Nazionalita, p_QMGR);

end;

-- end del package body
end;
GO
