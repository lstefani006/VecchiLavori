DROP PACKAGE ITRS.ITRS_LTS_MWP
GO
CREATE PACKAGE ITRS.ITRS_LTS_MWP AS

TYPE T_CURSOR IS REF CURSOR;


procedure GetListC2PFromTarga
(
p_Targa       in  TRANSITI.TARGA%type,
p_Nazionalita in  TRANSITI.TARGA%type,
p_Qmgr        out T_CURSOR
);


END;
GO
