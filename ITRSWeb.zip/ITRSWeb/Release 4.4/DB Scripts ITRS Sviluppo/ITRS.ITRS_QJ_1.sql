DROP PACKAGE BODY ITRS.ITRS_QJ
GO
CREATE PACKAGE BODY ITRS.ITRS_QJ as

	-- stati QUEUE, RUN, SOSP, ERR, RRES, END, ABRQ, ABAK, CANC
	-- QUEUE job in coda
	-- RUN   job in esecuzione
	-- SOSP  job sospeso
	-- ERR   job terminato con eccezione
	-- RRES  job in run che ha prodotto risultati intermedi
	-- END   job terminato con successo
	-- ABRQ  job con richiesta di abort in corso
	-- ABAK  job che ha accettato la richiesta di abort
	-- CANC  job da cancellare perche` scaduto (sysdate - QJLASTRESACCESS > QJRESTIMEOUTSEC)

	-- crea un nuovo job in stato QUEUE
	procedure QJ_Create
	(
		p_QJID       in QJOBS.QJID%TYPE,
		p_QJTYPE     in QJOBS.QJTYPE%TYPE,
		p_QJARGS     in QJOBS.QJARGS%TYPE,
		p_QJPKIDUSER in QJOBS.QJPKIDUSER%TYPE
	)
	is
		p_QJPRIORITY QJOBS.QJPRIORITY%type;
	begin
		select QJPRIORITY into p_QJPRIORITY from QJOBTYPES where QJTYPE = p_QJTYPE;

		insert into ITRS.QJOBS
		(QJID,     QJTYPE,   QJPRIORITY,   QJARGS,   QJPKIDUSER, QJSTATUS, QJTSQUEUE, QJLASTRESACCESS)
		values
		(p_QJID, p_QJTYPE, p_QJPRIORITY, p_QJARGS, p_QJPKIDUSER, 'QUEUE',  sysdate,   sysdate);

	end;

        -- crea un nuovo job in stato Queue ma
	procedure QJ_CreateEx
	(
		p_QJID        in  QJOBS.QJID%TYPE,
		p_QJTYPE      in  QJOBS.QJTYPE%TYPE,
		p_QJARGS      in  QJOBS.QJARGS%TYPE,
		p_QJPKIDUSER  in  QJOBS.QJPKIDUSER%TYPE,
                p_JobAccepted out int  -- 1 accettato, 0 non accettato
	)
        is
		p_QJPRIORITY      QJOBS.QJPRIORITY%type;
		p_QJMAXRES        QJOBTYPES.QJMAXRES%type;
                p_ACTUALNUMRES    QJOBTYPES.QJMAXRES%type;
                p_QJQUEUECRITERIA QJOBTYPES.QJQUEUECRITERIA%type;
        begin
                -- trovo la priorita e il massimo numero di jobs nella tabella
                -- QJOBS per il tipo di job in ingresso.
		select QJOBTYPES.QJPRIORITY,  QJOBTYPES.QJMAXRES, QJOBTYPES.QJQUEUECRITERIA
                into p_QJPRIORITY, p_QJMAXRES, p_QJQUEUECRITERIA
                from QJOBTYPES
                where QJTYPE = p_QJTYPE;

                -- se esiste il massimo numero numero di job
                -- allora controllo il numero di job effettivi nella
                -- QJOBS.
                -- se quelli effettivi eccedono non accodo ed esco.
                if (p_QJMAXRES is not null and p_QJMAXRES > 0) then

                  case
                    when (p_QJQUEUECRITERIA = 'MT') then
                      select
                      count(*) into p_ACTUALNUMRES
                      from QJOBS
                      where QJOBS.QJTYPE = p_QJTYPE
                      and   QJOBS.QJSTATUS <> 'CANC';

                    when (p_QJQUEUECRITERIA = 'MU') then
                      select
                      count(*) into p_ACTUALNUMRES
                      from QJOBS
                      where QJOBS.QJTYPE = p_QJTYPE
                      and   QJOBS.QJPKIDUSER = p_QJPKIDUSER
                      and   QJOBS.QJSTATUS <> 'CANC';

                    else
                      p_ACTUALNUMRES := 1000000;

                  end case;

                  if (p_ACTUALNUMRES >= p_QJMAXRES) then
                    p_JobAccepted := 0;
                    return;
                  end if;
                end if;

		insert into ITRS.QJOBS
		(QJID,     QJTYPE,   QJPRIORITY,   QJARGS,   QJPKIDUSER, QJSTATUS, QJTSQUEUE, QJLASTRESACCESS)
		values
		(p_QJID, p_QJTYPE, p_QJPRIORITY, p_QJARGS, p_QJPKIDUSER, 'QUEUE',  sysdate,   sysdate);

                p_JobAccepted := 1;
        end;



	-- User : metto il job in stato ABRQ
	procedure QJ_Abort(p_QJID in QJOBS.QJID%TYPE)
	is
	begin
		update QJOBS
		set    QJSTATUS = 'ABRQ'
		where
		QJID = p_QJID
		and QJSTATUS in ('QUEUE' , 'RUN', 'RRES');

	end;

	-- User : metto il job in stato SOSP (solo se sono in QUEUE)
	procedure QJ_Suspend(p_QJID in QJOBS.QJID%TYPE)
	is
	begin
		update QJOBS
		set    QJSTATUS = 'SOSP'
		where
		QJID = p_QJID
		and QJSTATUS = 'QUEUE';

	end;

	-- User : metto il job in stato QUEUE (solo se sono in SOSP)
	procedure QJ_Resume(p_QJID in QJOBS.QJID%TYPE)
	is
	begin
		update QJOBS
		set    QJSTATUS = 'QUEUE'
		where
		QJID = p_QJID
		and QJSTATUS = 'SOSP';

	end;


	-- Batch : cambia lo stato -
	procedure QJ_ChangeStatus(p_QJID in QJOBS.QJID%TYPE, p_QJSTATUS in QJOBS.QJSTATUS%TYPE)
	is
	begin
		update QJOBS
		set    QJSTATUS = p_QJSTATUS,
		       QJTSLAST = sysdate
		where  QJID = p_QJID;
	end;


	-- Batch : memorizza lo stato attuale di esecuzione
	procedure QJ_Progress
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJSTATUS      in QJOBS.QJSTATUS%TYPE,
		p_QJPROGRMSG    in QJOBS.QJPROGRMSG%TYPE,
		p_QJTOTALSTEPS  in QJOBS.QJTOTALSTEPS%TYPE,
		p_QJCURRENTSTEP in QJOBS.QJCURRENTSTEP%TYPE,
		p_QJRESRECORDCOUNT in QJOBS.QJRESRECORDCOUNT%TYPE
	)
	is
	begin

   update QJOBS set
   QJSTATUS = p_QJSTATUS,
	QJTSLAST = sysdate
	where
	 QJID = p_QJID;


		if p_QJPROGRMSG is not null then
       update QJOBS set
		   QJPROGRMSG = p_QJPROGRMSG
		   where
		   QJID = p_QJID;
		end if;

		if p_QJTOTALSTEPS is not null then
       update QJOBS set
		   QJTOTALSTEPS = p_QJTOTALSTEPS
		   where
		   QJID = p_QJID;
		end if;

		if p_QJCURRENTSTEP is not null then
       update QJOBS set
		   QJCURRENTSTEP = p_QJCURRENTSTEP
		   where
		   QJID = p_QJID;
		end if;

		if p_QJRESRECORDCOUNT is not null then
       update QJOBS set
		   QJRESRECORDCOUNT = p_QJRESRECORDCOUNT
		   where
		   QJID = p_QJID;
		end if;


	end;


	-- Batch : da chiamare quando il batch va in eccezione
	procedure QJ_Error
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJERRMSG      in QJOBS.QJERRMSG%TYPE
	)
	is
	begin

		update QJOBS set
		QJSTATUS = 'ERR',
		QJERRMSG = p_QJERRMSG,
		QJTSLAST = sysdate
		where
		QJID = p_QJID;

	end;



	-- Batch : da chiamare quando il batch termina
	procedure QJ_End
	(
		p_QJID          in QJOBS.QJID%TYPE,
		p_QJPROGRMSG    in QJOBS.QJPROGRMSG%TYPE,
		p_QJRESULT      in QJOBS.QJRESULT%TYPE
	)
	is
	begin
		update QJOBS set
		QJSTATUS = 'END',
		QJPROGRMSG = p_QJPROGRMSG,
		QJRESULT = p_QJRESULT,
		QJTSLAST = sysdate
		where
		QJID = p_QJID;

	end;


	-- User : da chiamare quando l'utente interroga il risultato.
	-- In questo modo si prolunga la vita del result del job.
	procedure QJ_Access
	(
		p_QJID          in QJOBS.QJID%TYPE
	)
	is
	begin
		update QJOBS set
		QJLASTRESACCESS = sysdate
		where
		QJID = p_QJID;
	end;


	-- Batch : mette in stato CANC i jobs vecchi in stato terminale
	procedure QJ_Purge
	is
	begin
		update QJOBS
		set QJSTATUS = 'CANC'
		where
		QJID in
		(
			select Q.QJID
			from QJOBS Q, QJOBTYPES T
			where
			Q.QJTYPE = T.QJTYPE
			and ((sysdate -  QJLASTRESACCESS) * 24 * 3600) > T.QJRESTIMEOUTSEC
		)
		and QJSTATUS in ( 'ERR', 'END', 'ABAK', 'SOSP', 'ABRQ');
	end;

        -- User: mette in CANC i job che soddisfano le caratteristiche in ingresso
	procedure QJ_Canc
        (
          p_QJID       QJOBS.QJID%type,
          p_QJTYPE     QJOBS.QJTYPE%type,
          p_QJPKIDUSER QJOBS.QJPKIDUSER%type,
          p_QJSTATUS   QJOBS.QJSTATUS%type
        )
	is
	begin
		update QJOBS
		set QJSTATUS = 'CANC'
		where
                    (p_QJID is null       or QJID = p_QJID)
                and (p_QJTYPE is null     or QJTYPE = p_QJTYPE)
                and (p_QJPKIDUSER is null or QJPKIDUSER = p_QJPKIDUSER)
                and (p_QJSTATUS is null   or QJSTATUS = p_QJSTATUS)
		and QJSTATUS in ('ERR', 'END', 'ABAK', 'SOSP');
	end;



	-- Batch: ottiene il prossivo job da eseguire, se esiste.
	procedure QJ_GetNextToRun
	(
		p_QJID       out QJOBS.QJID%TYPE,
		p_QJARGS     out QJOBS.QJARGS%TYPE,
		p_QJTYPE     out QJOBS.QJTYPE%TYPE
	)
	is
		nTotalRunning int;
		nTotalAllowed int;

	begin

		p_QJID := null;
		p_QJARGS := null;

		-- numero totale di job in stato running
		select count(*) into nTotalRunning from QJOBS
		where QJSTATUS = 'RUN' or QJSTATUS = 'RRES';

		-- numero totale di job permessi
		select QJMAXRUNNING into nTotalAllowed from QJOBTYPES
		where QJTYPE = '*'
                for update;

		begin
			select QJMAXRUNNING into nTotalAllowed from QJOBTYPES
			where QJTYPE = '*';
		exception
			when no_data_found then

				insert into ITRS.QJOBTYPES
				(QJTYPE, QJMAXRUNNING, QJPRIORITY, QJDESCR, QJRUNTIMEOUTSEC, QJQUEUETIMEOUTSEC, QJRESTIMEOUTSEC)
				values
				('*',              10,        '5',     ' ',             120,              1200,          150000);
		end;

		if nTotalRunning >= nTotalAllowed
		then
			return; -- non posso servire un job in coda... troppi job in corso
		end if;

		declare

		cursor cur is
			-- primo job in QUEUE con
			-- a) priorita` piu` alta
			-- b) piu` vecchio
			-- c) con numero di job dello stesso tipo in running < del massimo
			--    consentito
			select
			Q.QJID, Q.QJTYPE, Q.QJARGS
			from QJOBS Q
			inner join QJOBTYPES T
			on Q.QJTYPE = T.QJTYPE
			where
			rownum = 1
			and Q.QJSTATUS = 'QUEUE'
			and T.QJMAXRUNNING >
				(
					select count (*) from QJOBS R
					where (R.QJSTATUS = 'RUN' or R.QJSTATUS = 'RRES')
					and R.QJTYPE = Q.QJTYPE
				)
			order by
			Q.QJPRIORITY desc,
			Q.QJTSQUEUE asc
			for update;

		rec cur%rowtype;


		begin

			open cur;
			loop
				fetch cur into rec;
				exit when not cur%FOUND;

				update QJOBS
				set
				QJSTATUS = 'RUN',
				QJTSLAST = sysdate
				where current of cur;

				p_QJID   := rec.QJID;
				p_QJARGS := rec.QJARGS;
				p_QJTYPE := rec.QJTYPE;


				-- esco comunque anche in caso di errore
				exit;
			end loop;
			close cur;
		end;
	end;


end;
GO
