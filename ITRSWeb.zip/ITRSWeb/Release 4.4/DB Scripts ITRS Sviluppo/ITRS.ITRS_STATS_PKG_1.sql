DROP PACKAGE BODY ITRS.ITRS_STATS_PKG
GO
CREATE PACKAGE BODY ITRS.ITRS_STATS_PKG is
/*******************************************************************************
* Module    : ITRS_STATS_PKG
* Description :
********************************************************************************
*                         Revision history
*
*  Date      Who       Description
*  --------  -------   ------------------------------------------------
*  06/02/06  P.Lercari first release
***********************************************************************************/
PROCEDURE Calcola_Stats is

cursor C_Transiti is
Select distinct targa,nazionalita
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
order by targa,nazionalita;

cursor C_Trans_Correlati (Targa_Id varchar2,nazione varchar2) is
Select dataorarilevamento,idc2p,enumtipovarco
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and targa = Targa_Id
and nazionalita = nazione
order by dataorarilevamento;

cursor C_c2p is
select idc2p
from C2p
order by idc2p;

cursor C_Transiti_Uscita (C2p number) is
Select distinct targa,nazionalita
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and idc2p=C2p
and enumtipovarco = itrs_const_pkg.VAL_TIPOVARCO_USCITA
order by targa,nazionalita;

cursor C_Trans_Uscita_Correlati (Targa_Id varchar2,nazione varchar2) is
Select dataorarilevamento,idc2p,enumtipovarco
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and targa = Targa_Id
and nazionalita = nazione
order by dataorarilevamento;

Count_Fetch number(20);
v_targa transiti.targa%type;
v_naz transiti.nazionalita%type;
d_data_rilev date;
d_data_rilev_old date;
d_data_rilev_prec date;
delta_t number(20);
tempo_percorr number(20);
n_idc2p transiti.idc2p%type;
n_idc2p_old transiti.idc2p%type;
tratta_id tratte.idtratta%type;
c2p_id c2p.idc2p%type;
c2p_prec_id c2p.idc2p%type;
n_idc2p_prec c2p.idc2p%type;
v_tipovarco transiti.enumtipovarco%type;
v_tipovarco_old transiti.enumtipovarco%type;
v_tipovarco_prec transiti.enumtipovarco%type;
n_tratta_prec c2p.idtrattaprec%type;
n_tratta_succ c2p.idtrattasucc%type;
n_tratta_succ_old c2p.idtrattasucc%type;
d_data_rep date;
v_ora_da varchar2(2);
v_ora_a varchar2(2);
n_lunghkm tratte.lunghezzakm%type;
vel_percorr number(20,2);
direz c2p.direzione%type;
v_strada tratte.codicestrada%type;
v_direz tratte.direzione%type;
tempo_sosta number(20);
t_sosta_medio number(20);
Existtab integer;
gg date;

begin

 dbms_output.put_line('Inizio esecuzione Calcola_Stats alle ' ||to_char(sysdate,'HH24:MI:SS'));

   	SELECT count(*) into Existtab
      FROM USER_TABLES
      WHERE TABLE_NAME = 'TAB_APP';
    if Existtab =1 then
      EXECUTE IMMEDIATE 'DROP TABLE TAB_APP';
      dbms_output.put_line('droppata TAB_APP');
    end if;

    EXECUTE IMMEDIATE 'CREATE TABLE TAB_APP(data_rep date,
                                            	ora_da varchar2(2),
						ora_a varchar2(2),
						strada varchar2(10),
						direzione varchar2(5),
						tratta_id number(3),
						tempo_percorr number(20),
						veloc_percorr number(20,2))';

    dbms_output.put_line('creata TAB_APP');
  	vel_percorr := 0;

    open C_Transiti;
     loop
      Count_Fetch := 0;

      fetch C_Transiti into v_targa,v_naz;
      exit when C_Transiti%NOTFOUND;
      --dbms_output.put_line('Valore targa '||v_targa||' nazione '||v_naz);
    	d_data_rilev_old := null;
    	n_idc2p_old := null;
    	v_tipovarco_old := null;
    	n_tratta_succ_old := null;

    	open C_Trans_Correlati (v_targa,v_naz);
    		loop
     		fetch C_Trans_Correlati into d_data_rilev,n_idc2p,v_tipovarco;
     		exit when C_Trans_Correlati%NOTFOUND;
     		Count_Fetch := Count_Fetch + 1;
     --dbms_output.put_line('Valore data_rilev_old-c2p_old-tipovarco_old-data_rilev-c2p-tipovarco '||d_data_rilev_old||' '||n_idc2p_old||' '||v_tipovarco_old||' '||d_data_rilev||' '||n_idc2p||' '||v_tipovarco);
		select IdTrattaPrec,IdTrattaSucc
     		into n_tratta_prec,n_tratta_succ
     		from C2p
     		where IdC2p = n_idc2p;

     		if Count_Fetch <> 1 then
					if (n_idc2p <> n_idc2p_old) and (v_tipovarco in (itrs_const_pkg.VAL_TIPOVARCO_INGRESSO,itrs_const_pkg.VAL_TIPOVARCO_SX,itrs_const_pkg.VAL_TIPOVARCO_DX))
						and (v_tipovarco_old in (itrs_const_pkg.VAL_TIPOVARCO_USCITA,itrs_const_pkg.VAL_TIPOVARCO_SX,itrs_const_pkg.VAL_TIPOVARCO_DX))
						and (n_tratta_succ_old = n_tratta_prec) then

				select lunghezzakm,codicestrada,direzione
     				into n_lunghkm,v_strada,v_direz
     				from Tratte
     				where IdTratta = n_tratta_prec;

        		d_data_rep := to_date(to_char(d_data_rilev,'dd/mm/yy'),'dd/mm/yy');
        		v_ora_da := to_char(d_data_rilev,'hh24');
        		v_ora_a := to_char(d_data_rilev+1/24,'hh24');
        		delta_t := (d_data_rilev - d_data_rilev_old)*86400;
			      vel_percorr := n_lunghkm/(delta_t/3600);

						EXECUTE IMMEDIATE 'insert into TAB_APP (data_rep,ora_da,ora_a,strada,direzione,tratta_id,tempo_percorr,veloc_percorr)
						                   values (:1,:2,:3,:4,:5,:6,:7,:8)'
				     using d_data_rep,v_ora_da,v_ora_a,v_strada,v_direz,n_tratta_prec,delta_t,vel_percorr;
					end if;
     		end if;

   			d_data_rilev_old := d_data_rilev;
   			n_idc2p_old := n_idc2p;
   			v_tipovarco_old := v_tipovarco;
   			n_tratta_succ_old := n_tratta_succ;

  	end loop;
 	close C_Trans_Correlati;

 end loop;
 close C_Transiti;


 EXECUTE IMMEDIATE 'insert into Tempi_Veloc_Percorr_Tratta(data_rep,ora_da,ora_a,strada,direzione,tratta_id,tempo_percorr_medio,vel_percorr_media)
  select data_rep,ora_da,ora_a,strada,direzione,tratta_id,avg (tempo_percorr),avg(veloc_percorr)
  from tab_app
  group by data_rep,ora_da,ora_a,strada,direzione,tratta_id';


 commit;
 dbms_output.put_line('Fine popolamento Tempi_Veloc_Percorr_Tratta alle ' ||to_char(sysdate,'HH24:MI:SS'));

 insert into Tempi_Veloc_Percorr_Direz(data_rep,ora_da,ora_a,strada,direzione,tempo_percorr_medio,vel_percorr_media)
 select data_rep,ora_da,ora_a,strada,direzione,avg(tempo_percorr_medio),avg(vel_percorr_media)
 from Tempi_Veloc_Percorr_Tratta
 where data_rep>=trunc(sysdate-1)
 and data_rep<trunc(sysdate)
 group by data_rep,ora_da,ora_a,strada,direzione;

 commit;
 dbms_output.put_line('Fine popolamento Tempi_Veloc_Percorr_Direz alle ' ||to_char(sysdate,'HH24:MI:SS'));

 gg := to_date(to_char(sysdate-1,'dd/mm/yy'),'dd/mm/yy');

 --insert into Vol_Traff_Tratta (data_rep,ora_da,ora_a,c2p,c_trans)
 --select gg,to_char(dataorarilevamento,'hh24') ora_1,to_char(dataorarilevamento+1/24,'hh24') ora_2,IdC2p,count(*)
 --from Transiti
 --where dataorarilevamento>=trunc(sysdate-1)
 --and dataorarilevamento<trunc(sysdate)
 --and enumtipovarco in (itrs_const_pkg.VAL_TIPOVARCO_SX,itrs_const_pkg.VAL_TIPOVARCO_DX)
 --group by gg,ora_1,ora_2,IdC2p;

 insert into Vol_Traff_Tratta (data_rep,ora_da,ora_a,c2p,c_trans)
 select gg,to_char(dataorarilevamento,'hh24'),to_char(dataorarilevamento+1/24,'hh24'),IdC2p,count(*)
 from Transiti
 where dataorarilevamento>=trunc(sysdate-1)
 and dataorarilevamento<trunc(sysdate)
 and enumtipovarco in (itrs_const_pkg.VAL_TIPOVARCO_SX,itrs_const_pkg.VAL_TIPOVARCO_DX)
 group by gg,to_char(dataorarilevamento,'hh24'),to_char(dataorarilevamento+1/24,'hh24'),IdC2p;

 commit;
 dbms_output.put_line('Fine popolamento Vol_Traff_Tratta alle ' ||to_char(sysdate,'HH24:MI:SS'));

 --insert into Vol_Traff_Direz(data_rep,ora_da,ora_a,strada,direzione,c_trans)
 --select gg,to_char(dataorarilevamento,'hh24') ora_1,to_char(dataorarilevamento+1/24,'hh24') ora_2,CodiceStrada,Direzione,count(*)
 --from Transiti a,C2p b
 --where dataorarilevamento>=trunc(sysdate-1)
 --and dataorarilevamento<trunc(sysdate)
 --and enumtipovarco in (itrs_const_pkg.VAL_TIPOVARCO_SX,itrs_const_pkg.VAL_TIPOVARCO_DX)
 --and a.IdC2p = b.IdC2p
 --group by gg,ora_1,ora_2,CodiceStrada,Direzione;

 insert into Vol_Traff_Direz(data_rep,ora_da,ora_a,strada,direzione,c_trans)
 select gg,to_char(a.dataorarilevamento,'hh24'),to_char(a.dataorarilevamento+1/24,'hh24'),CodiceStrada,Direzione,count(*)
 from Transiti a,C2p b
 where a.dataorarilevamento>=trunc(sysdate-1)
 and a.dataorarilevamento<trunc(sysdate)
 and enumtipovarco in (itrs_const_pkg.VAL_TIPOVARCO_SX,itrs_const_pkg.VAL_TIPOVARCO_DX)
 and a.IdC2p = b.IdC2p
 group by gg,to_char(a.dataorarilevamento,'hh24'),to_char(a.dataorarilevamento+1/24,'hh24'),CodiceStrada,Direzione;

 commit;
 dbms_output.put_line('Fine popolamento Vol_Traff_Direz alle ' ||to_char(sysdate,'HH24:MI:SS'));

 SELECT count(*) into Existtab
      FROM USER_TABLES
      WHERE TABLE_NAME = 'TAB_APP1';
    if Existtab =1 then
      EXECUTE IMMEDIATE 'DROP TABLE TAB_APP1';
      dbms_output.put_line('droppata TAB_APP1');
    end if;

    EXECUTE IMMEDIATE 'CREATE TABLE TAB_APP1(data_rep date,
                                            ora_da varchar2(2),
																						ora_a varchar2(2),
																						c2p number(3),
																						tempo_sosta number(20))';
    dbms_output.put_line('creata TAB_APP1');

 open C_C2p;
  loop
  	fetch C_C2p into c2p_id;
    exit when C_C2p%NOTFOUND;

    open C_Transiti_Uscita(c2p_id);
    loop
  	Count_Fetch := 0;

    fetch C_Transiti_Uscita into v_targa,v_naz;
    exit when C_Transiti_Uscita%NOTFOUND;
		d_data_rilev_prec := null;
		n_idc2p_prec := null;
		v_tipovarco_prec := null;
    --dbms_output.put_line('Valore targa '||v_targa||' nazione '||v_naz);
    open C_Trans_Uscita_Correlati (v_targa,v_naz);
    loop
     fetch C_Trans_Uscita_Correlati into d_data_rilev,n_idc2p,v_tipovarco;
     exit when C_Trans_Uscita_Correlati%NOTFOUND;
     Count_Fetch := Count_Fetch + 1;
     --dbms_output.put_line('Valore data_rilev_prec-c2p_prec-tipovarco_prec-data_rilev-c2p-tipovarco '||
     --d_data_rilev_prec||' '||n_idc2p_prec||' '||v_tipovarco_prec||' '||d_data_rilev||' '||n_idc2p||' '||v_tipovarco);
     if Count_Fetch <> 1 then
			if (n_idc2p = c2p_id) and (n_idc2p = n_idc2p_prec) and (v_tipovarco = itrs_const_pkg.VAL_TIPOVARCO_USCITA)
				and (v_tipovarco_prec=itrs_const_pkg.VAL_TIPOVARCO_INGRESSO) then
				d_data_rep := to_date(to_char(d_data_rilev,'dd/mm/yy'),'dd/mm/yy');
			  v_ora_da := to_char(d_data_rilev,'hh24');
        v_ora_a := to_char(d_data_rilev+1/24,'hh24');
        delta_t := (d_data_rilev - d_data_rilev_prec)*86400;

						EXECUTE IMMEDIATE 'insert into TAB_APP1 (data_rep,ora_da,ora_a,c2p,tempo_sosta)
						                   values (:1,:2,:3,:4,:5)'
				     using d_data_rep,v_ora_da,v_ora_a,n_idc2p,delta_t;

			end if;
     end if;

    d_data_rilev_prec := d_data_rilev;
   	n_idc2p_prec := n_idc2p;
   	v_tipovarco_prec := v_tipovarco;

   end loop;
   close C_Trans_Uscita_Correlati;

  end loop;
  close C_Transiti_Uscita;

 end loop;
 close C_C2p;

 EXECUTE IMMEDIATE 'insert into Tempi_Sosta_C2p(data_rep,ora_da,ora_a,c2p,tempo_sosta_medio)
  select data_rep,ora_da,ora_a,c2p,avg(tempo_sosta)
  from tab_app1
  group by data_rep,ora_da,ora_a,c2p';

 commit;
 dbms_output.put_line('Fine popolamento Tempi_Sosta_C2p alle ' ||Substr(to_char(sysdate, 'HH24:MI:SS'),1,10));

 dbms_output.put_line('Fine esecuzione Calcola_Stats alle ' ||to_char(sysdate,'HH24:MI:SS'));

 dbms_output.put_line ('Calcola_Stats terminato senza anomalie');


 	Exception when Others then
    dbms_output.put_line('Errore durante esecuzione Calcola_Stats');
    dbms_output.put_line('Errore: ' || substr(sqlerrm,1,250));
    Rollback;
    return;

end Calcola_Stats;

end itrs_stats_pkg;
GO
