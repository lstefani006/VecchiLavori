DROP PACKAGE ITRS.PARTMGR
GO
CREATE PACKAGE ITRS.PARTMGR
IS
    FUNCTION  part_date(in_partition_name VARCHAR2) RETURN DATE;
    PROCEDURE addpartition(in_execmode VARCHAR2 DEFAULT 'NORMAL');
    PROCEDURE droppartition(in_execmode VARCHAR2 DEFAULT 'NORMAL');
END partmgr;
GO
