DROP PACKAGE BODY ITRS.ITRS_SMLOG
GO
CREATE PACKAGE BODY ITRS.ITRS_SMLOG AS

procedure AddMessage
(
  p_Application smlog.smapplication%type,
  p_Type        smlog.smtype%type,
  p_Message     smlog.smmessage%type,
  p_Exception   smlog.smexception%type
)
is
  p_LastId smlog.smid%type;
begin

  -- questa implementazione dovrebbe essere resistente a piu` applicazioni
  -- che chiamano AddMessage in contemporanea.
  -- Per evitare corse, si mette un for update
  -- nella select dei parametri, lock che viene rilasciato
  -- alla fine della transazione (che il DAL deve aprire)

  begin
    select parvalue into p_LastId from parametri
    where partipo='smlog_id'
    for update;
  exception when no_data_found then
    -- qui potrebbe esserci una corsa... ma avviene solo al primo insert.
    insert into Parametri (parvalue, partipo) values (0, 'smlog_id');
    p_LastId := -1;
  end;

  -- determino il prossimo smId. Al max 100 record nella tabella.

  p_LastId := p_LastId + 1;
  if (p_LastId >= 100) then
    p_LastId := 0;
  end if;


  -- provo ad updatare il record. Se c'e` bene
  -- se non c'e`, smLog e` vuota (per quell'smId) e dunque faccio insert
  update smLog
  set
  SMAPPLICATION = p_Application,
  SMMESSAGE     = p_Message,
  SMEXCEPTION   = p_Exception,
  SMTYPE        = p_Type,
  SMTS          = sysdate
  where smId = p_LastId;

  if sql%rowcount = 0 then
    INSERT INTO ITRS.SMLOG
    (
      SMID,
      SMAPPLICATION,
      SMMESSAGE,
      SMEXCEPTION,
      SMTYPE,
      SMTS
    )
    VALUES
    (
      p_LastId,
      p_Application,
      p_Message,
      p_Exception,
      p_Type,
      SYSDATE
    );
  end if;

  -- aggiorno il contatore dell'ultimo smID
  update Parametri
  set parvalue = p_LastId
  where partipo = 'smlog_id';

  -- qui devo rilasciare la transazione per rilasciare il lock
end;

END;
GO
