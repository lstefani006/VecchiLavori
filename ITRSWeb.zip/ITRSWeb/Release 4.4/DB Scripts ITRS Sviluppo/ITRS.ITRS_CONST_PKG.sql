DROP PACKAGE ITRS.ITRS_CONST_PKG
GO
CREATE PACKAGE ITRS.ITRS_CONST_PKG   is
/*  Date      Who       Description
*  --------  -------   ------------------------------------------------
*  27/12/05  P.Lercari first release
***********************************************************************************/

VAL_TIPOVARCO_USCITA  		CONSTANT CHAR(1) := 'U';       ---Valore Tipovarco Uscita
VAL_TIPOVARCO_INGRESSO		CONSTANT CHAR(1) := 'E';       ---Valore Tipovarco Entrata
VAL_TIPOVARCO_SX          CONSTANT CHAR(1) := 'S';       ---Valore Tipovarco Sx
VAL_TIPOVARCO_DX          CONSTANT CHAR(1) := 'D';       ---Valore Tipovarco Dx

VAL_TIPOEVENTO_TS		  CONSTANT CHAR(2) := 'TS';     ---Valore Tipoevento Transito Segnalato
VAL_TIPOEVENTO_TSE		CONSTANT CHAR(3) := 'TSE';     ---Valore Tipoevento Tempo Sosta Elevato
VAL_TIPOEVENTO_EFV  	CONSTANT CHAR(3) := 'EFV';     ---Valore Tipoevento Elevata Frequenza Visite
VAL_TIPOEVENTO_ENV  	CONSTANT CHAR(3) := 'ENV';     ---Valore Tipoevento Elevato Numero Visite
VAL_TIPOEVENTO_VMS    CONSTANT CHAR(3) := 'VMS';     ---Valore Tipoevento Superamentovelocita' media di tratta

VAL_STATOALLARME_CONF		CONSTANT CHAR(3) := 'CNF';     ---Valore Statoallarme Confermato
VAL_STATOALLARME_ACQ		CONSTANT CHAR(3) := 'ACQ';     ---Valore Statoallarme Acquisito

VAL_STATOTRANSITO_ACQ   CONSTANT CHAR(5) := 'DARIC';     ---Valore Statotransito Acquisito

VAL_CLASSEURGENZA_ATT		    CONSTANT CHAR(3) := 'ATT';     ---Valore Classe Urgenza Attuale
VAL_CLASSEURGENZA_RIT       CONSTANT CHAR(3) := 'RIT';     ---Valore Classe Urgenza In Ritardo
VAL_CLASSEURGENZA_OBS       CONSTANT CHAR(3) := 'OBS';     ---Valore Classe Urgenza Obsoleto

VAL_NAZ_DEFAULT         CONSTANT CHAR(1) := 'I';  --Valore default nazionalita

VAL_TIPOVARCO_1					CONSTANT CHAR(1) := '1';     ---Primo valore Tipo Varco
VAL_TIPOVARCO_2					CONSTANT CHAR(1) := '2';     ---Secondo valore Tipo Varco
VAL_TIPOVARCO_3					CONSTANT CHAR(1) := '3';     ---Terzo valore Tipo Varco
VAL_TIPOVARCO_4					CONSTANT CHAR(1) := '4';     ---Quarto valore Tipo Varco

VAL_DESCVARCO_1				CONSTANT CHAR(32) := 'Corsia di marcia (rilevamento 1)';     ---Primo valore Descrizione Varco
VAL_DESCVARCO_2				CONSTANT CHAR(32) := 'Corsia di marcia (rilevamento 2)';     ---Secondo valore Descrizione Varco
VAL_DESCVARCO_3				CONSTANT CHAR(37) := 'In ingresso alla stazione di servizio';     ---Terzo valore Descrizione Varco
VAL_DESCVARCO_4				CONSTANT CHAR(36) := 'In uscita dalla stazione di servizio';     ---Quarto valore Descrizione Varco
end;
GO
