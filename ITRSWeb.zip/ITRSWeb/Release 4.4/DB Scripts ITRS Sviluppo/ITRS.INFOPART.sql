DROP VIEW ITRS.INFOPART
GO
CREATE VIEW ITRS.INFOPART ( TABLESPACE_NAME, PARTITION_NAME, TABLE_NAME, HIGH_VALUE )
AS
SELECT t.TABLESPACE_NAME,
           p.PARTITION_NAME ,
           p.TABLE_NAME     ,
           p.HIGH_VALUE
    FROM user_tablespaces    t,
         user_tab_partitions p
    WHERE t.TABLESPACE_NAME LIKE 'ITRS_128K%' AND
          p.TABLESPACE_NAME (+) = t.TABLESPACE_NAME
    ORDER BY partmgr.part_date(t.TABLESPACE_NAME) DESC,
             partmgr.part_date(p.PARTITION_NAME)  DESC,
             p.TABLE_NAME
GO
