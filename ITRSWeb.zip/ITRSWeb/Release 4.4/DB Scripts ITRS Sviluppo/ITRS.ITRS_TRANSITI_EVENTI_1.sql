DROP PACKAGE BODY ITRS.ITRS_TRANSITI_EVENTI
GO
CREATE PACKAGE BODY ITRS.ITRS_TRANSITI_EVENTI AS

procedure TransitoPrendiInCarico
(
	p_Targa                 in Transiti.Targa%type,
	p_Nazionalita           in Transiti.NAZIONALITA%type,
	p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,
	p_IdUtentePresaInCarico in Transiti.IDUTENTEPRESAINCARICO%type,
	p_Updated               out integer
)
is
begin

	update TransitiSuEvento
	set
	IdUtentePresaInCarico = p_IdUtentePresaInCarico,
	DataOraPresaInCarico  = sysdate,
	EnumStatoTransito     = 'PIC'
	where
	Targa = p_Targa and
	Nazionalita = p_Nazionalita and
	DataOraRilevamento = p_DataOraRilevamento and
	EnumStatoTransito = 'DARIC';

	p_Updated := sql%rowcount;

	update Transiti
	set
	IdUtentePresaInCarico = p_IdUtentePresaInCarico,
	DataOraPresaInCarico  = sysdate,
	EnumStatoTransito     = 'PIC'
	where
	Targa = p_Targa and
	Nazionalita = p_Nazionalita and
	DataOraRilevamento = p_DataOraRilevamento and
	EnumStatoTransito = 'DARIC';

	p_Updated := p_Updated + sql%rowcount;

end;


procedure TransitoAzioneSuPresaInCarico
(
	p_Targa                 in Transiti.Targa%type,
	p_Nazionalita           in Transiti.NAZIONALITA%type,
	p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,

	p_StatoTransito         in Transiti.ENUMSTATOTRANSITO%type,
	p_NoteChiusura          in Transiti.NOTECHIUSURA%type,

	p_Updated               out integer
)
is
begin
	case
	when p_StatoTransito = 'DARIC' then
		begin
			update TransitiSuEvento
			set
			IdUtentePresaInCarico = null,
			DataOraPresaInCarico  = null,
			EnumStatoTransito     = 'DARIC',
			DataOraChiusura       = null,
			NoteChiusura          = null
			where
			Targa = p_Targa and
			Nazionalita = p_Nazionalita and
			DataOraRilevamento = p_DataOraRilevamento and
			EnumStatoTransito = 'PIC' ;

			p_Updated := sql%rowcount;

			update Transiti
			set
			IdUtentePresaInCarico = null,
			DataOraPresaInCarico  = null,
			EnumStatoTransito     = 'DARIC',
			DataOraChiusura       = null,
			NoteChiusura          = null
			where
			Targa = p_Targa and
			Nazionalita = p_Nazionalita and
			DataOraRilevamento = p_DataOraRilevamento and
			EnumStatoTransito = 'PIC' ;

			p_Updated := p_Updated + sql%rowcount;

		end;

	when p_StatoTransito = 'RIC' or p_StatoTransito = 'NORIC' then
		begin
			update TransitiSuEvento
			set
			EnumStatoTransito     = p_StatoTransito,
			DataOraChiusura       = sysdate,
			NoteChiusura          = p_NoteChiusura
			where
			Targa = p_Targa and
			Nazionalita = p_Nazionalita and
			DataOraRilevamento = p_DataOraRilevamento and
			EnumStatoTransito = 'PIC' ;

			p_Updated := sql%rowcount;


			update Transiti
			set
			EnumStatoTransito     = p_StatoTransito,
			DataOraChiusura       = sysdate,
			NoteChiusura          = p_NoteChiusura
			where
			Targa = p_Targa and
			Nazionalita = p_Nazionalita and
			DataOraRilevamento = p_DataOraRilevamento and
			EnumStatoTransito = 'PIC';

			p_Updated := p_Updated + sql%rowcount;

		end;
	else
		null;
	end case;
end;


procedure TransitoAzioneSuPresaInCarico2
(
	p_Targa                 in Transiti.Targa%type,
	p_Nazionalita           in Transiti.NAZIONALITA%type,
	p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,

	p_StatoTransito         in Transiti.ENUMSTATOTRANSITO%type,
	p_NoteChiusura          in Transiti.NOTECHIUSURA%type,

	p_NuovaTarga            in Transiti.Targa%type,
	p_NuovaNazionalita      in Transiti.NAZIONALITA%type,

	p_Updated               out integer
)
is
begin
	case when p_StatoTransito = 'DARIC' then

		update TransitiSuEvento
		set
		IdUtentePresaInCarico = null,
		DataOraPresaInCarico  = null,
		EnumStatoTransito     = 'DARIC',
		DataOraChiusura       = null,
		NoteChiusura          = null
		where
		Targa              = p_Targa and
		Nazionalita        = p_Nazionalita and
		DataOraRilevamento = p_DataOraRilevamento and
		EnumStatoTransito  = 'PIC' ;

		p_Updated := sql%rowcount;

		update Transiti
		set
		IdUtentePresaInCarico = null,
		DataOraPresaInCarico  = null,
		EnumStatoTransito     = 'DARIC',
		DataOraChiusura       = null,
		NoteChiusura          = null
		where
		Targa = p_Targa and
		Nazionalita = p_Nazionalita and
		DataOraRilevamento = p_DataOraRilevamento and
		EnumStatoTransito = 'PIC' ;

		p_Updated := p_Updated + sql%rowcount;

	when p_StatoTransito = 'NORIC' then

		update TransitiSuEvento
		set
		EnumStatoTransito     = p_StatoTransito,
		DataOraChiusura       = sysdate,
		NoteChiusura          = p_NoteChiusura
		where
		Targa = p_Targa and
		Nazionalita = p_Nazionalita and
		DataOraRilevamento = p_DataOraRilevamento and
		EnumStatoTransito = 'PIC' ;

		p_Updated := sql%rowcount;

		update Transiti
		set
		EnumStatoTransito     = p_StatoTransito,
		DataOraChiusura       = sysdate,
		NoteChiusura          = p_NoteChiusura
		where
		Targa = p_Targa and
		Nazionalita = p_Nazionalita and
		DataOraRilevamento = p_DataOraRilevamento and
		EnumStatoTransito = 'PIC';

		p_Updated := p_Updated + sql%rowcount;

	when p_StatoTransito = 'RIC' and p_Targa = p_NuovaTarga and p_Nazionalita = p_NuovaNazionalita then

		-- RIC con conferma della targa proposta.

		update TransitiSuEvento
		set
		EnumStatoTransito     = 'RIC',
		DataOraChiusura       = sysdate,
		NoteChiusura          = p_NoteChiusura
		where
		Targa = p_Targa and
		Nazionalita = p_Nazionalita and
		DataOraRilevamento = p_DataOraRilevamento and
		EnumStatoTransito = 'PIC' ;

            	p_Updated := sql%rowcount;


		update Transiti
		set
		EnumStatoTransito     = 'RIC',
		DataOraChiusura       = sysdate,
		NoteChiusura          = p_NoteChiusura
		where
		Targa              = p_Targa and
		Nazionalita        = p_Nazionalita and
		DataOraRilevamento = p_DataOraRilevamento and
		EnumStatoTransito  = 'PIC';

		p_Updated := p_Updated + sql%rowcount;

	when p_StatoTransito = 'RIC' and (p_Targa <> p_NuovaTarga or p_Nazionalita <> p_NuovaNazionalita) then

		-- chiudo il transito corrente (potrebbe esserci)
		update TransitiSuEvento
		set
		EnumStatoTransito  = 'NORIC',
		DataOraChiusura    = sysdate,
		NoteChiusura       = p_NoteChiusura
		where
		Targa              = p_Targa and
		Nazionalita        = p_Nazionalita and
		DataOraRilevamento = p_DataOraRilevamento and
		EnumStatoTransito  = 'PIC'
		;
            	p_Updated := sql%rowcount;

		-- chiudo il transito corrente
		-- questo CI DEVE essere
		update Transiti
		set
		EnumStatoTransito  = 'NORIC',
		DataOraChiusura    = sysdate,
		NoteChiusura       = p_NoteChiusura
		where
		Targa              = p_Targa and
		Nazionalita        = p_Nazionalita and
		DataOraRilevamento = p_DataOraRilevamento and
		EnumStatoTransito  = 'PIC'
		;

		p_Updated := p_Updated + sql%rowcount;

                if p_NuovaTarga is not null and p_NuovaNazionalita is not null then
		begin

			-- creo un nuovo transito con i vecchi dati ma con la nuova targa
			-- e in stato 'RIC'
			-- N.B. non creo un TransitoSuEvento
			-- Qui la sfiga potrebbe vederci benissimo:
			-- potrebbe esiste gia` un transito della nuova targa/naz...
			-- alla stessa ora!!!!!
			-- per evitare spiacevoli malfunzionamenti ignoro brutalmente l'errore.
			-- D'altra parte se esiste gia` un transito l'operatore e` contento
			insert into Transiti
			(
				TARGA,
				NAZIONALITA,
				DATAORARILEVAMENTO,
				IDC2P,
				ENUMTIPOVARCO,
				DATAORAINSERIMENTO,
				ENUMSTATOTRANSITO,
				LATITUDINE,
				LONGITUDINE,
				TARGAACQUISITA,
				NAZIONALITAACQUISITA,
				CONFIDENZAACQUISIZIONETARGA,
				MARCAVEICOLO,
				MODELLOVEICOLO,
				IDUTENTEPRESAINCARICO,
				DATAORAPRESAINCARICO,
				DATAORACHIUSURA,
				NOTECHIUSURA
			)
			select
			p_NuovaTarga        TARGA,
			p_NuovaNazionalita  NAZIONALITA,
			DATAORARILEVAMENTO,
			IDC2P,
			ENUMTIPOVARCO,
			DATAORAINSERIMENTO,
			'RIC'               ENUMSTATOTRANSITO,
			LATITUDINE,
			LONGITUDINE,
			TARGAACQUISITA,
			NAZIONALITAACQUISITA,
			CONFIDENZAACQUISIZIONETARGA,
			MARCAVEICOLO,
			MODELLOVEICOLO,
			IDUTENTEPRESAINCARICO,
			DATAORAPRESAINCARICO,
			DATAORACHIUSURA,
			NOTECHIUSURA

			from Transiti
			where
			Targa = p_Targa
			and Nazionalita = p_Nazionalita
			and DataOraRilevamento = p_DataOraRilevamento
			and EnumStatoTransito = 'NORIC'
			;

			insert into Immagini
			(
				Targa,
				Nazionalita,
				DataOraRilevamento,
				IdImmagine,
				Immagine,
				DataOraUltimaRichiesta,
				Formato,
				Codifica,
				Risoluzione
			)
			select
			p_NuovaTarga       Targa,
			p_NuovaNazionalita Nazionalita,
			DataOraRilevamento,
			IdImmagine,
			Immagine,
			DataOraUltimaRichiesta,
			Formato,
			Codifica,
			Risoluzione
                        from Immagini
			where
			Targa = p_Targa
			and Nazionalita = p_Nazionalita
			and DataOraRilevamento = p_DataOraRilevamento
			;

			exception when DUP_VAL_ON_INDEX then
				DBMS_OUTPUT.PUT_LINE('Esiste gia` un transito con la nuova targa!');
		end;
                end if;

	else
		DBMS_OUTPUT.PUT_LINE('Errore - dati in ingresso errati');
	end case;
end;



procedure TransitoRiconoscimentoManuale
(
	p_Targa                 in Transiti.Targa%type,
	p_Nazionalita           in Transiti.NAZIONALITA%type,
	p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,

	p_NoteChiusura          in Transiti.NOTECHIUSURA%type,

	p_Nuova_Targa           in Transiti.Targa%type,
	p_Nuova_Nazionalita     in Transiti.NAZIONALITA%type
)
is
begin
	-- a fronte di un transito non riconosciuto totalmente
	-- l'operatore ha effettuato il riconoscimento manuale
	-- Il transito va' in stato RIC.

	-- l'operazione nel DB e` complicata dal fatto che
	-- l'immagine e` in un'altra tabella


	insert into Transiti
	(
		TARGA,
		NAZIONALITA,
		DATAORARILEVAMENTO,
		IDC2P,
		ENUMTIPOVARCO,
		DATAORAINSERIMENTO,
		ENUMSTATOTRANSITO,
		LATITUDINE,
		LONGITUDINE,
		TARGAACQUISITA,
		NAZIONALITAACQUISITA,
		CONFIDENZAACQUISIZIONETARGA,
		MARCAVEICOLO,
		MODELLOVEICOLO,
		IDUTENTEPRESAINCARICO,
		DATAORAPRESAINCARICO,
		DATAORACHIUSURA,
		NOTECHIUSURA
	)
	select
	p_Nuova_Targa        TARGA,
	p_Nuova_Nazionalita  NAZIONALITA,
	DATAORARILEVAMENTO,
	IDC2P,
	ENUMTIPOVARCO,
	DATAORAINSERIMENTO,
	'RIC'                ENUMSTATOTRANSITO,
	LATITUDINE,
	LONGITUDINE,
	TARGAACQUISITA,
	NAZIONALITAACQUISITA,
	CONFIDENZAACQUISIZIONETARGA,
	MARCAVEICOLO,
	MODELLOVEICOLO,
	IDUTENTEPRESAINCARICO,
	DATAORAPRESAINCARICO,
	sysdate              DATAORACHIUSURA,
	p_NoteChiusura       NOTECHIUSURA

	from Transiti
	where
	Targa = p_Targa
	and Nazionalita = p_Nazionalita
	and DataOraRilevamento = p_DataOraRilevamento
	and EnumStatoTransito = 'PIC'
	;


	if ( sql%rowcount = 0 ) then
		return;
	end if;

	-- questa funziona anche se ci sono piu` immagini per transito
	update Immagini
	set
	Targa = p_Nuova_Targa,
	Nazionalita = p_Nuova_Nazionalita
	where
	Targa = p_Targa
	and Nazionalita = p_Nazionalita
	and DataOraRilevamento = p_DataOraRilevamento;

	-- infine cancello il transito
	delete from Transiti
	where Targa = p_Targa
	and   Nazionalita = p_Nazionalita
	and   DataOraRilevamento = p_DataOraRilevamento
	and   EnumStatoTransito = 'PIC'
	;

	update itrs.INDAGINI_TRANSITI
	set
	Targa = p_Nuova_Targa,
	Nazionalita = p_Nuova_Nazionalita
	where Targa = p_Targa
	and   Nazionalita = p_Nazionalita
	and   DataOraRilevamento = p_DataOraRilevamento;


end;


--------------------------------------------------------------------------------

procedure EventoPrendiInCarico
(
	p_Targa                 in EventiDaSegnalare.Targa%type,
	p_Nazionalita           in EventiDaSegnalare.NAZIONALITA%type,
	p_DataOraInserimento    in EventiDaSegnalare.DATAORAINSERIMENTO%type,
	p_IdEvento              in EventiDaSegnalare.IDEVENTO%type,
	p_IdUtentePresaInCarico in EventiDaSegnalare.IDUTENTEPRESAINCARICO%type,
	p_Updated               out integer
)
is
begin
	-- 'ACQ','PIC','CNF','NCNF'
	update EventiDaSegnalare
	set
	IdUtentePresaInCarico = p_IdUtentePresaInCarico,
	DataOraPresaInCarico  = sysdate,
	EnumStatoAllarme      = 'PIC'
	where
	Targa = p_Targa and
	Nazionalita = p_Nazionalita and
	DataOraInserimento = p_DataOraInserimento and
	IdEvento = p_IdEvento and
	EnumStatoAllarme = 'ACQ';

	p_Updated := sql%rowcount;
end;

procedure EventoAzioneSuPresaInCarico
(
	p_Targa                 in EventiDaSegnalare.Targa%type,
	p_Nazionalita           in EventiDaSegnalare.NAZIONALITA%type,
	p_DataOraInserimento    in EventiDaSegnalare.DATAORAINSERIMENTO%type,
	p_IdEvento              in EventiDaSegnalare.IDEVENTO%type,

	p_StatoAllarme          in EventiDaSegnalare.ENUMSTATOALLARME%type,
	p_NoteChiusura          in EventiDaSegnalare.NOTECHIUSURA%type,
	p_Updated               out integer

)
is
begin
	-- 'ACQ','PIC','CNF','NCNF'
	case
	when p_StatoAllarme = 'ACQ' then
		begin
			update EventiDaSegnalare
			set
			IdUtentePresaInCarico = null,
			DataOraPresaInCarico  = null,
			EnumStatoAllarme      = 'ACQ',
			DataOraChiusura       = null,
			NoteChiusura          = null
			where
			Targa = p_Targa and
			Nazionalita = p_Nazionalita and
			DataOraInserimento = p_DataOraInserimento and
			IdEvento = p_IdEvento and
			EnumStatoAllarme = 'PIC' ;

			p_Updated := sql%rowcount;

		end;

	when p_StatoAllarme = 'CNF' or p_StatoAllarme = 'NCNF' then
		begin
			update EventiDaSegnalare
			set
			EnumStatoAllarme      = p_StatoAllarme,
			DataOraChiusura       = sysdate,
			NoteChiusura          = p_NoteChiusura
			where
			Targa = p_Targa and
			Nazionalita = p_Nazionalita and
			DataOraInserimento = p_DataOraInserimento and
			IdEvento = p_IdEvento and
			EnumStatoAllarme = 'PIC' ;

			p_Updated := sql%rowcount;

		end;
	else
		null;
	end case;
end;



END;
GO
