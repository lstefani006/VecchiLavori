DROP PACKAGE ITRS.ITRS_SMLOG
GO
CREATE PACKAGE ITRS.ITRS_SMLOG AS

procedure AddMessage
(
  p_Application smlog.smapplication%type,
  p_Type smlog.smtype%type,
  p_Message smlog.smmessage%type,
  p_Exception smlog.smexception%type
);

END;
GO
