DROP PACKAGE BODY ITRS.ITRS_INDAGINI
GO
CREATE PACKAGE BODY ITRS.ITRS_INDAGINI as
procedure QUERYINDAGINETRANSITI
(
	p_qjid        in varchar2,
	p_targa       in varchar2,
	p_nazionalita in varchar2,
	p_di          in date,
	p_df          in date,
        p_idc2p       in C2P.IDC2P%type,
	p_found       out int,
        p_MaxRec      out int
)
is
begin

	BEGIN
		select parValue into p_MaxRec from Parametri where ParTipo='INDAGINE_MAXREC';
	exception
	WHEN no_data_found THEN
        	insert into Parametri (parTipo, parValue) values ('INDAGINE_MAXREC', 1000);
		p_MaxRec := 1000;
	END;

	INSERT INTO ITRS.INDAGINI_TRANSITI
	(
		QJID,
		TARGA,
		NAZIONALITA,
		DATAORARILEVAMENTO,

                C2P_DESCRIZIONE,
                C2P_DIREZIONE,
                ENUMTIPOVARCO,
                ENUMSTATOTRANSITO,

                TARGAACQUISITA,
                NAZIONALITAACQUISITA
	)
        select
	p_qjid as QJID,
	Transiti.TARGA,
	Transiti.NAZIONALITA,
	Transiti.DATAORARILEVAMENTO,
        C2P.DESCRIZIONE,
        C2P.DIREZIONE,
        Transiti.ENUMTIPOVARCO,
        Transiti.ENUMSTATOTRANSITO,
	Transiti.TARGAACQUISITA,
	Transiti.NAZIONALITAACQUISITA

	from
	Transiti

        inner join C2P
        on C2P.IdC2P = Transiti.IDC2P

	where
	Transiti.DATAORARILEVAMENTO >= p_di
	and Transiti.DATAORARILEVAMENTO < p_df
	and (p_targa is null or Transiti.Targa like p_targa)
	and (p_nazionalita is null or Transiti.Nazionalita = p_nazionalita)
        and (p_idc2p is null or Transiti.IdC2P = p_idc2p)
        and rownum <= p_MaxRec;

	p_found := sql%rowcount;
end;


procedure QUERYINDAGINEEVENTI
(
	p_qjid        in varchar2,
	p_targa       in varchar2,
	p_nazionalita in varchar2,
	p_di          in date,
	p_df          in date,
        p_idc2p       in C2P.IDC2P%type,
        p_tipoEvento  in EVENTIDASEGNALARE.ENUMTIPOEVENTO%type,
	p_found       out int,
        p_MaxRec      out int
)
is
begin

	BEGIN
		select parValue into p_MaxRec from Parametri where ParTipo='INDAGINE_MAXREC';
	exception
	WHEN no_data_found THEN
        	insert into Parametri (parTipo, parValue) values ('INDAGINE_MAXREC', 1000);
		p_MaxRec := 1000;
	END;


      insert into ITRS.INDAGINI_EVENTI
      (
	QJID,
	TARGA,
	NAZIONALITA,
	DATAORAINSERIMENTO,
	IDEVENTO,
	ENUMTIPOEVENTO,
	ENUMSTATOALLARME,
	UTENTEPRESAINCARICO,
	DATAORAPRESAINCARICO,
	DATAORACHIUSURA,
	NOTECHIUSURA,
	COADICOMPETENZA,
	CLASSEDIURGENZA,
	DATAULTIMOTRANSITO
      )
      select
      *
      from
      (
        /*
        select
        p_qjid as QJID,
        E.Targa,
        E.Nazionalita,
        E.DataOraInserimento,
        E.IdEvento,
        E.EnumTipoEvento     as EnumTipoEvento,
        E.EnumStatoAllarme   as EnumStatoAllarme,
        U.UserName           as UtentePresaInCarico,
        E.DataOraPresaInCarico,
        E.DataOraChiusura,
        E.NoteChiusura,
        COA.Descrizione      as CoaDiCompetenza,
        E.EnumClasseUrgenza  as ClasseDiUrgenza,

        max(TE.DataOraRilevamento) as DataUltimoTransito

        from
        EventiDaSegnalare E

        inner join TransitiEventi TE
        on  TE.Targa = E.Targa
        and TE.Nazionalita = E.Nazionalita
        and TE.DataOraInserimento = E.DataOraInserimento
        and TE.IdEvento = E.IdEvento
        and (p_targa is null or TE.Targa like p_targa)
        and (p_nazionalita is null or TE.Nazionalita = p_nazionalita)

        inner join TransitiSuEvento TSE
        on  TSE.Targa = TE.Targa
        and TSE.Nazionalita = TE.Nazionalita
        and TSE.DataOraRilevamento = TE.DataOraRilevamento
        and TSE.DataOraRilevamento >= p_di
        and TSE.DataOraRilevamento <  p_df
        and (p_targa is null or TSE.Targa like p_targa)
        and (p_nazionalita is null or TSE.Nazionalita = p_nazionalita)

        left outer join COA
        on COA.IdCoa = E.IdCoaCompetenza

        left outer join aspnet_users U
        on U.PkId = E.IdUtentePresaInCarico

        where

        (p_targa is null or E.Targa like p_targa)
        and (p_nazionalita is null or E.Nazionalita = p_nazionalita)
        and (p_tipoEvento is null or E.EnumTipoEvento = p_tipoEvento)
        and (p_idc2p is null or TSE.IdC2P = p_idc2p)

        group by
            E.Targa,
            E.Nazionalita,
            E.DataOraInserimento,
            E.IdEvento,
            E.EnumTipoEvento,
            E.EnumStatoAllarme,
            U.UserName,
            E.DataOraPresaInCarico,
            E.DataOraChiusura,
            E.NoteChiusura,
            COA.Descrizione,
            E.EnumClasseUrgenza

        having
        max(TE.DataOraRilevamento) >= p_di and
        max(TE.DataOraRilevamento) <  p_df
        */

	select
        p_qjid as QJID,
        TSE.Targa,
        TSE.Nazionalita,
        TSE.DataOraInserimento,
        TSE.IdEvento,
        E.EnumTipoEvento     as EnumTipoEvento,
        E.EnumStatoAllarme   as EnumStatoAllarme,
        U.UserName           as UtentePresaInCarico,
        E.DataOraPresaInCarico,
        E.DataOraChiusura,
        E.NoteChiusura,
        COA.Descrizione      as CoaDiCompetenza,
        E.EnumClasseUrgenza  as ClasseDiUrgenza,
        TSE.DataOraRilevamento as DataUltimoTransito
	from
	(
		select
		max(TSE2.DATAORARILEVAMENTO) as DataOraRilevamento,
                TSE2.IdEvento,
                TSE2.Targa,
                TSE2.Nazionalita,
                TSE2.DataOraInserimento
		from TransitiEventi TSE2

                inner join TransitiSuEvento T2
                on  TSE2.Targa = T2.Targa
                and TSE2.Nazionalita = T2.Nazionalita
                and TSE2.DataOraRilevamento = T2.DataOraRilevamento
                and (p_idc2p is null or T2.IdC2P = p_idc2p)

		where p_Di <= TSE2.DATAORARILEVAMENTO
		and p_Df   > TSE2.DATAORARILEVAMENTO
                and (p_targa is null or TSE2.Targa like p_targa)
                and (p_nazionalita is null or TSE2.Nazionalita = p_nazionalita)

		group by TSE2.IDEVENTO, TSE2.targa, TSE2.NAZIONALITA, TSE2.DataOraInserimento
	) TSE
        inner join EVENTIDASEGNALARE E
        on  TSE.Targa = E.Targa
        and TSE.Nazionalita = E.Nazionalita
        and TSE.DataOraInserimento = E.DataOraInserimento
        and TSE.IdEvento = E.IdEvento
        and (p_tipoEvento is null or E.EnumTipoEvento = p_tipoEvento)

        inner join TransitiSuEvento T
        on  TSE.Targa = T.Targa
        and TSE.Nazionalita = T.Nazionalita
        and TSE.DataOraRilevamento = T.DataOraRilevamento
        and (p_idc2p is null or T.IdC2P = p_idc2p)

        left outer join COA
        on COA.IdCoa = E.IdCoaCompetenza

        left outer join aspnet_users U
        on U.PkId = E.IdUtentePresaInCarico
      )
      where
      rownum <= p_MaxRec
      ;

      p_found := sql%rowcount;

end;


procedure CancellaIndagine
(
	p_qjid in varchar2
)
is
begin
	delete from ITRS.INDAGINI_TRANSITI where QJID = p_qjid;
        delete from ITRS.INDAGINI_EVENTI   where QJID = p_qjid;
	delete from ITRS.QJOBS where QJOBS.QJID = p_qjid;
end;


end;
GO
