DROP PACKAGE BODY ITRS.ITRS_LTS_MWP
GO
CREATE PACKAGE BODY ITRS.ITRS_LTS_MWP AS



procedure GetListC2PFromTarga
(
p_Targa       in TRANSITI.TARGA%type,
p_Nazionalita in TRANSITI.TARGA%type,
p_Qmgr        out T_CURSOR
)
is
begin
  -- apro un cursore che ritorna la lista dei C2P purche`
  -- la targa NON sia gia` nel LTS
  OPEN p_Qmgr FOR
    SELECT
    c2p.QMGR_NAME,
    c2p.DATAORARILEVAMENTO
    from C2P
    where not exists
    (
      select * from LTS
      where
      LTS.TARGA = p_Targa and
      LTS.Nazionalita = p_Nazionalita
    );
end;


END;
GO
