DROP PACKAGE BODY ITRS.PARTMGR
GO
CREATE PACKAGE BODY ITRS.PARTMGR
IS

    EXECMODE_NORMAL		CONSTANT VARCHAR2(9) := 'NORMAL'   ;
    EXECMODE_PROBEONLY  CONSTANT VARCHAR2(9) := 'PROBEONLY';


    -- Input: '%ddmmyy'
    -- Output: DATE<dd/mm/yy>
    FUNCTION part_date (in_partition_name VARCHAR2) RETURN DATE
    IS
    BEGIN
        RETURN (TO_DATE(SUBSTR(in_partition_name,-6,6),'DDMMYY'));
    END part_date;


    PROCEDURE addpartition(in_execmode VARCHAR2 DEFAULT 'NORMAL')
    IS
        my_part_id              varchar2(6)     ;
        my_part_name            varchar2(20)    ;
        my_max_date             date            ;
        my_str_date             varchar2(8)     ;
        my_today                date            ;
        my_str_sql              varchar2(4000)  ;
        my_par_partiz_back      integer         ;
        my_par_partiz_forward   integer         ;

        err_tbsp_exist EXCEPTION; PRAGMA EXCEPTION_INIT(err_tbsp_exist, -1543);
        err_dbf_exist  EXCEPTION; PRAGMA EXCEPTION_INIT(err_dbf_exist , -1537);

    BEGIN

        IF in_execmode IS NULL OR
           (in_execmode IS NOT NULL AND
            UPPER(in_execmode) NOT IN (EXECMODE_NORMAL, EXECMODE_PROBEONLY))
        THEN
            RAISE_APPLICATION_ERROR(-20000, 'addpartition Invalid parameter ' || in_execmode);
        END IF;

        SELECT ParValue INTO my_par_partiz_back    FROM Parametri WHERE partipo = 'PARTMGR.DaysBack'   ;
        SELECT ParValue INTO my_par_partiz_forward FROM Parametri WHERE partipo = 'PARTMGR.DaysForward';

        -- prendo da user_tab_partitions in modo da creare prima le partizioni su tablespace preesistente
        SELECT MAX(partmgr.part_date(PARTITION_NAME))
        INTO my_max_date
        FROM user_tab_partitions
        WHERE TABLE_NAME IN ('IMMAGINI','TRANSITI');

        SELECT TRUNC(SYSDATE) INTO my_today FROM DUAL;

        -- se non c'e' gap tra ultima partizione presente e prima partizione da creare...
        IF my_max_date + 1 > my_today - my_par_partiz_back THEN
            -- allora creo partizione giornaliera successiva
            my_part_id  := TO_CHAR(my_max_date + 1, 'DDMMYY');
            my_part_name:= 'DAY' || to_char(my_max_date + 1, 'DDMMYY');
            my_str_date := TO_CHAR(my_max_date + 2, 'YYYYMMDD');
        ELSE
            -- altrimenti creo partizione unica per tutto il gap
            my_part_id   := TO_CHAR(my_today - my_par_partiz_back, 'ddmmyy');
            my_part_name := 'DAY' || to_char(my_today - my_par_partiz_back, 'DDMMYY');
            my_str_date  := TO_CHAR(my_today - my_par_partiz_back + 1, 'YYYYMMDD');
        END IF;

        BEGIN
            my_str_sql := 'CREATE TABLESPACE ITRS_128K_D' || my_part_id || ' DATAFILE ''/oradata/itrsdb/itrs_data_part/ITRS_128K_D' || my_part_id || '_01.DBF'' size 1M autoextend on next 1M extent management local uniform size 128K ';
            DBMS_OUTPUT.PUT_LINE(my_str_sql);
            IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;
        EXCEPTION
            WHEN err_tbsp_exist THEN NULL;
        END;

        BEGIN
            my_str_sql := 'ALTER TABLESPACE ITRS_128K_D' || my_part_id || ' ADD DATAFILE ''/oradata/itrsdb/itrs_data_part/ITRS_128K_D' || my_part_id || '_02.DBF'' size 1M autoextend on next 1M ';
            DBMS_OUTPUT.PUT_LINE(my_str_sql);
            IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;
        EXCEPTION
            WHEN err_dbf_exist THEN NULL;
        END;

        BEGIN
            my_str_sql := 'ALTER TABLESPACE ITRS_128K_D' || my_part_id || ' ADD DATAFILE ''/oradata/itrsdb/itrs_data_part/ITRS_128K_D' || my_part_id || '_03.DBF'' size 1M autoextend on next 1M ';
            DBMS_OUTPUT.PUT_LINE(my_str_sql);
            IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;
        EXCEPTION
            WHEN err_dbf_exist THEN NULL;
        END;

        -- prima immagini e poi transiti, per evitare che vengano inseriti transiti senza immagini
        my_str_sql := 'ALTER TABLE Immagini ADD PARTITION ' || my_part_name || ' VALUES LESS THAN (TO_DATE(''' || my_str_date || ''',''YYYYMMDD'')) TABLESPACE ITRS_128K_D' || my_part_id;
        DBMS_OUTPUT.PUT_LINE(my_str_sql);
        IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;

        my_str_sql := 'ALTER TABLE Transiti ADD PARTITION ' || my_part_name || ' VALUES LESS THAN (TO_DATE(''' || my_str_date || ''',''YYYYMMDD'')) TABLESPACE ITRS_128K_D' || my_part_id;
        DBMS_OUTPUT.PUT_LINE(my_str_sql);
        IF UPPER(in_execmode) = EXECMODE_NORMAL
        THEN
            BEGIN
                EXECUTE IMMEDIATE my_str_sql;
            EXCEPTION
            WHEN OTHERS THEN
                my_str_sql := 'ALTER TABLE Immagini DROP PARTITION ' || my_part_name;
                DBMS_OUTPUT.PUT_LINE(my_str_sql);
                EXECUTE IMMEDIATE my_str_sql; dbms_output.put_line('DONE');
            END;
            DBMS_OUTPUT.PUT_LINE('DONE');
        END IF;

        -- gl TODO: qui ci vorrebbe un controllo di coerenza su infopart per verificare lo stato della partizione appena aggiunta

    END addpartition;


    PROCEDURE droppartition(in_execmode VARCHAR2 DEFAULT 'NORMAL')
    IS

        my_min_data     date          ;
        my_part_id      varchar2(6)   ;
        my_part_name    varchar2(20)  ;
        my_str_sql      varchar2(4000);

       err_part_not_exist EXCEPTION; PRAGMA EXCEPTION_INIT(err_part_not_exist, -14006);
       err_tbsp_not_exist EXCEPTION; PRAGMA EXCEPTION_INIT(err_tbsp_not_exist, -959  );

    BEGIN

        IF in_execmode IS NULL OR
           (in_execmode IS NOT NULL AND
            UPPER(in_execmode) NOT IN (EXECMODE_NORMAL, EXECMODE_PROBEONLY))
        THEN
            RAISE_APPLICATION_ERROR(-20000, 'droppartition Invalid parameter ' || in_execmode);
        END IF;

        -- prendo da user_tablespaces in modo da eliminare prima eventuali tbsp rimasti senza partizioni
        SELECT MIN(partmgr.part_date(TABLESPACE_NAME))
        INTO my_min_data
        FROM user_tablespaces WHERE TABLESPACE_NAME LIKE 'ITRS_128K\_D______' ESCAPE '\';

        my_part_id   := TO_CHAR(my_min_data, 'DDMMYY');
        my_part_name := 'DAY' || to_char(my_min_data,'DDMMYY');

        --  my_str_sql := 'ALTER TABLE IMMAGINI DISABLE CONSTRAINT Im_Trans_FK';
        --    DBMS_OUTPUT.PUT_LINE(my_str_sql);
        --    IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;

        BEGIN
            my_str_sql := 'ALTER TABLE Immagini DROP PARTITION ' || my_part_name;
            DBMS_OUTPUT.PUT_LINE(my_str_sql);
            IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;
        EXCEPTION
            WHEN err_part_not_exist THEN NULL;
        END;

        BEGIN
            my_str_sql := 'ALTER TABLE Transiti DROP PARTITION ' || my_part_name;
            DBMS_OUTPUT.PUT_LINE(my_str_sql);
            IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;
        EXCEPTION
            WHEN err_part_not_exist THEN NULL;
        END;

        --  my_str_sql := 'ALTER TABLE Immagini ENABLE NOVALIDATE CONSTRAINT Im_Trans_FK';
        --    DBMS_OUTPUT.PUT_LINE(my_str_sql);
        --    IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;

        BEGIN
            my_str_sql := 'DROP TABLESPACE ITRS_128K_D' || my_part_id || ' INCLUDING CONTENTS AND DATAFILES';
            DBMS_OUTPUT.PUT_LINE(my_str_sql);
            IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;
        EXCEPTION
            WHEN err_tbsp_not_exist THEN NULL;
        END;

        -- gl TODO: qui ci vorrebbe un controllo di coerenza su infopart per verificare lo stato della partizione appena tolta

        --EXCEPTION
        --    WHEN OTHERS
        --    THEN
        --        my_str_sql := 'ALTER TABLE Immagini ENABLE NOVALIDATE CONSTRAINT Im_Trans_FK';
        --        DBMS_OUTPUT.PUT_LINE(my_str_sql);
        --        IF UPPER(in_execmode) = EXECMODE_NORMAL THEN EXECUTE IMMEDIATE my_str_sql; DBMS_OUTPUT.PUT_LINE('DONE'); END IF;

    END droppartition;

END partmgr;
GO
