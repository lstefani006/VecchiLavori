DROP PACKAGE ITRS.ITRS_INTERVENTO
GO
CREATE PACKAGE ITRS.ITRS_INTERVENTO as

TYPE T_CURSOR IS REF CURSOR;

procedure CreateIntervento
(
  p_QJID        in  QJOBS.QJID%TYPE,
  p_QJTYPE      in  QJOBS.QJTYPE%TYPE,
  p_QJARGS      in  QJOBS.QJARGS%TYPE,
  p_QJPKIDUSER  in  QJOBS.QJPKIDUSER%TYPE,
  p_TARGA       in  TRANSITI.TARGA%TYPE,
  p_NAZIONALITA in  TRANSITI.NAZIONALITA%TYPE,
  p_MOTIVO      in  LTS.MOTIVO%TYPE,
  p_NOTE        in  LTS.NOTE%TYPE,
  p_IDCOA       in  COA.IDCOA%TYPE,

p_QJOBIDOLD   out QJOBS.QJID%TYPE
);

  procedure QueryIntervento
  (
  p_QJID        in  QJOBS.QJID%TYPE,
  p_TARGA       in  TRANSITI.TARGA%TYPE,
  p_NAZIONALITA in  TRANSITI.NAZIONALITA%TYPE,
  p_DI          in  DATE,
  p_DF          in  DATE,
  p_ROWS        out integer,
  p_PRIMO_TRANSITO in out VARCHAR2 -- true o false
  );

  procedure DeleteIntervento
  (
  p_QJID        in  QJOBS.QJID%TYPE,
  p_TARGA       out TRANSITI.TARGA%TYPE,
  p_NAZIONALITA out TRANSITI.NAZIONALITA%TYPE,
  p_QMGR        out T_CURSOR
  );


  procedure Test
  (
  p_QJID        in  QJOBS.QJID%TYPE,
  p_TARGA       in  TRANSITI.TARGA%TYPE,
  p_NAZIONALITA in  TRANSITI.NAZIONALITA%TYPE,
  p_DI          in  DATE,
  p_ROWS        out integer,
  p_STR         out TRANSITI.TARGA%TYPE
  );

  procedure OnAllarme
  (
  p_TARGA               in TRANSITI.TARGA%TYPE,
  p_NAZIONALITA         in TRANSITI.NAZIONALITA%TYPE,
  p_DATAORARILEVAMENTO  in TRANSITI.DATAORARILEVAMENTO%TYPE,

  p_QMGR_NAME           in C2P.QMGR_NAME%TYPE,
  p_TIPOVARCO           in VARCHAR2
  );


  procedure ListaInterventiPerCoa
  (
		p_IdCoa       in  COA.IdCoa%type,
		p_Cur         out T_CURSOR
  );


  procedure CancellaInterventoPerCoa
  (
    p_IdCoa       in  COA.IdCoa%type,
    p_TARGA       in TRANSITI.TARGA%TYPE,
    p_NAZIONALITA in TRANSITI.NAZIONALITA%TYPE,
    p_QMGR        out T_CURSOR

  );

--  type InterventoRec is record
--  (
--    ProgressivoQuery          Number,
--    QJID                     	QJOBSRES_INTERVENTI.QJID%type,
--    TARGA                    	QJOBSRES_INTERVENTI.TARGA%type,
--    NAZIONALITA              	QJOBSRES_INTERVENTI.NAZIONALITA%type,
--    DATAORARILEVAMENTO       	QJOBSRES_INTERVENTI.DATAORARILEVAMENTO%type,
--    C2P_DESCRIZIONE          	QJOBSRES_INTERVENTI.C2P_DESCRIZIONE%type,
--    C2P_DIREZIONE            	QJOBSRES_INTERVENTI.C2P_DIREZIONE%type,
--    ENUMTIPOVARCO            	QJOBSRES_INTERVENTI.ENUMTIPOVARCO%type,
--    ENUMSTATOTRANSITO        	QJOBSRES_INTERVENTI.ENUMSTATOTRANSITO%type,
--    EVENTOASSOCIATOALTRANSITO	QJOBSRES_INTERVENTI.EVENTOASSOCIATOALTRANSITO%type
--  );
--  type InterventoCur is ref cursor InterventoRec%type;


end;
GO
