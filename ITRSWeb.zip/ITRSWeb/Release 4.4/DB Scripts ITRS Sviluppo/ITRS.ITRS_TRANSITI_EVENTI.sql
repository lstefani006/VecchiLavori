DROP PACKAGE ITRS.ITRS_TRANSITI_EVENTI
GO
CREATE PACKAGE ITRS.ITRS_TRANSITI_EVENTI AS

procedure TransitoPrendiInCarico
(
  p_Targa                 in Transiti.Targa%type,
  p_Nazionalita           in Transiti.NAZIONALITA%type,
  p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,
  p_IdUtentePresaInCarico in Transiti.IDUTENTEPRESAINCARICO%type,
  p_Updated               out integer
);

procedure TransitoAzioneSuPresaInCarico
(
  p_Targa                 in Transiti.Targa%type,
  p_Nazionalita           in Transiti.NAZIONALITA%type,
  p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,

  p_StatoTransito         in Transiti.ENUMSTATOTRANSITO%type,
  p_NoteChiusura          in Transiti.NOTECHIUSURA%type,
  p_Updated               out integer
);

procedure TransitoAzioneSuPresaInCarico2
(
  p_Targa                 in Transiti.Targa%type,
  p_Nazionalita           in Transiti.NAZIONALITA%type,
  p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,

  p_StatoTransito         in Transiti.ENUMSTATOTRANSITO%type,
  p_NoteChiusura          in Transiti.NOTECHIUSURA%type,

  p_NuovaTarga            in Transiti.Targa%type,
  p_NuovaNazionalita      in Transiti.NAZIONALITA%type,


  p_Updated               out integer
);


procedure TransitoRiconoscimentoManuale
(
  p_Targa                 in Transiti.Targa%type,
  p_Nazionalita           in Transiti.NAZIONALITA%type,
  p_DataOraRilevamento    in Transiti.DATAORARILEVAMENTO%type,

  p_NoteChiusura          in Transiti.NOTECHIUSURA%type,

  p_Nuova_Targa           in Transiti.Targa%type,
  p_Nuova_Nazionalita     in Transiti.NAZIONALITA%type
);


--------------------------------------------------------------------

procedure EventoPrendiInCarico
(
  p_Targa                 in EventiDaSegnalare.Targa%type,
  p_Nazionalita           in EventiDaSegnalare.NAZIONALITA%type,
  p_DataOraInserimento    in EventiDaSegnalare.DATAORAINSERIMENTO%type,
  p_IdEvento              in EventiDaSegnalare.IDEVENTO%type,
  p_IdUtentePresaInCarico in EventiDaSegnalare.IDUTENTEPRESAINCARICO%type,
  p_Updated               out integer
);

procedure EventoAzioneSuPresaInCarico
(
  p_Targa                 in EventiDaSegnalare.Targa%type,
  p_Nazionalita           in EventiDaSegnalare.NAZIONALITA%type,
  p_DataOraInserimento    in EventiDaSegnalare.DATAORAINSERIMENTO%type,
  p_IdEvento              in EventiDaSegnalare.IDEVENTO%type,

  p_StatoAllarme          in EventiDaSegnalare.ENUMSTATOALLARME%type,
  p_NoteChiusura          in EventiDaSegnalare.NOTECHIUSURA%type,
  p_Updated               out integer
);


END;
GO
