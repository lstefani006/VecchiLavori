DROP PROCEDURE ITRS.HOUSEKEEPING
GO
CREATE PROCEDURE ITRS.HOUSEKEEPING(in_execmode VARCHAR2 default 'NORMAL')
IS

    EXECMODE_NORMAL    CONSTANT VARCHAR2(9) := 'NORMAL'   ;
    EXECMODE_PROBEONLY CONSTANT VARCHAR2(9) := 'PROBEONLY';

    my_max_date           date   ;
    my_min_data           date   ;
    my_today              date   ;
    my_num_partiz         integer;
    my_par_partiz_back    integer;
    my_par_partiz_forward integer;
    my_num_partiz_create  integer;
    my_num_partiz_drop    integer;

    PROCEDURE OutputLine(in_msg VARCHAR2)
    IS
    BEGIN
        DBMS_OUTPUT.PUT_LINE('HOUSEKEEPING ' || TO_CHAR(SYSDATE,'YY-MM-DD HH24:MI:SS') || ' - ' || in_msg);
    END;

BEGIN

    OutputLine('Inizio esecuzione');

    SELECT TRUNC(SYSDATE) INTO my_today FROM DUAL;

    -- prendo da user_tab_partitions in modo da costruire prima le partizioni su tablespace preesistente
    SELECT MAX(partmgr.part_date(PARTITION_NAME))
    INTO my_max_date
    FROM user_tab_partitions WHERE TABLE_NAME IN ('IMMAGINI','TRANSITI');

    -- SELECT MIN(partmgr.part_date(PARTITION_NAME))
    -- INTO my_min_data
    -- FROM user_tablespaces
    -- WHERE TABLESPACE_NAME like 'ITRS_128K\_D______' ESCAPE '\';

    SELECT COUNT(TABLESPACE_NAME)
    INTO my_num_partiz
    FROM user_tablespaces
    WHERE TABLESPACE_NAME LIKE 'ITRS_128K\_D______' ESCAPE '\';

    SELECT ParValue INTO my_par_partiz_back    FROM Parametri WHERE ParTipo = 'PARTMGR.DaysBack'   ;
    SELECT ParValue INTO my_par_partiz_forward FROM Parametri WHERE ParTipo = 'PARTMGR.DaysForward';

    OutputLine('Data odierna:            '||TO_CHAR(my_today, 'DDMMYY'   ));
    OutputLine('Numero partizioni:       '||TO_CHAR(my_num_partiz        ));
    OutputLine('Ultima partizione:       '||TO_CHAR(my_max_date, 'DDMMYY'));
    OutputLine('PARTMGR.DaysBack:        '||TO_CHAR(my_par_partiz_back   ));
    OutputLine('PARTMGR.DaysForward:     '||TO_CHAR(my_par_partiz_forward));

    IF my_par_partiz_back + 1 < my_today - my_max_date
    THEN
        my_num_partiz_create := my_par_partiz_back + my_par_partiz_forward + 1;
    ELSE
        my_num_partiz_create := my_today - my_max_date + my_par_partiz_forward;
    END IF;
    my_num_partiz_drop := my_num_partiz + my_num_partiz_create - my_par_partiz_back - my_par_partiz_forward - 1;
    IF my_num_partiz_create < 0 THEN my_num_partiz_create := 0; END IF;
    IF my_num_partiz_drop   < 0 THEN my_num_partiz_drop   := 0; END IF;

    OutputLine('Partizioni da creare:    ' || TO_CHAR(my_num_partiz_create));
    OutputLine('Partizioni da eliminare: ' || TO_CHAR(my_num_partiz_drop  ));


    IF UPPER(in_execmode) <> EXECMODE_PROBEONLY
    THEN

        OutputLine('Creazione partizioni - Inizio esecuzione');
        FOR i IN 1..my_num_partiz_create LOOP

            BEGIN
                OutputLine('Creazione partizione ' || TO_CHAR(i) || ' di ' || TO_CHAR(my_num_partiz_create));
                partmgr.addpartition(in_execmode); OutputLine('Creazione partizione completata');
            EXCEPTION WHEN OTHERS THEN OutputLine('Inserimento partizione - Errore: ' || SUBSTR(SQLERRM, 1, 250));
            END;

        END LOOP;
        OutputLine('Creazione partizioni - Fine esecuzione');

        OutputLine('Eliminazione partizioni - Inizio esecuzione');
        FOR i in 1..my_num_partiz_drop LOOP

            BEGIN
                OutputLine('Eliminazione partizione ' || TO_CHAR(i) || ' di ' || TO_CHAR(my_num_partiz_drop));
                partmgr.droppartition(in_execmode); OutputLine('Eliminazione partizione completata');
            EXCEPTION WHEN OTHERS THEN OutputLine('Eliminazione partizione - Errore: ' || SUBSTR (SQLERRM, 1, 250));
            END;

        END LOOP;
        OutputLine('Eliminazione partizioni - Fine esecuzione');

    END IF;


    IF UPPER(in_execmode) <> EXECMODE_PROBEONLY
    THEN

        BEGIN
            OutputLine('Ricompilazione Itrs_comp_anom_pkg');
            EXECUTE IMMEDIATE 'ALTER PACKAGE Itrs_comp_anom_pkg COMPILE';
        EXCEPTION WHEN OTHERS THEN OutputLine('Ricompilazione itrs_comp_anom_pkg - Errore: ' || SUBSTR(SQLERRM, 1, 250));
        END;

        BEGIN
            OutputLine('Ricompilazione Itrs_centr_comm');
            EXECUTE IMMEDIATE 'ALTER PACKAGE Itrs_centr_comm COMPILE';
        EXCEPTION WHEN OTHERS THEN OutputLine('Ricompilazione itrs_centr_comm - Errore: ' || SUBSTR(SQLERRM, 1, 250));
        END;

        BEGIN
            OutputLine('Ricompilazione Itrs_stats_pkg');
            EXECUTE IMMEDIATE 'ALTER PACKAGE Itrs_stats_pkg COMPILE';
        EXCEPTION WHEN OTHERS THEN OutputLine('Ricompilazione itrs_stats_pkg - Errore: ' || SUBSTR(SQLERRM, 1, 250));
        END;

    END IF;

    OutputLine('Fine esecuzione');

END HouseKeeping;
GO
