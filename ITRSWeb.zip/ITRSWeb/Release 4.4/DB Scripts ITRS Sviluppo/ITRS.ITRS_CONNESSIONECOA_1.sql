DROP PACKAGE BODY ITRS.ITRS_CONNESSIONECOA
GO
CREATE PACKAGE BODY ITRS.ITRS_CONNESSIONECOA as
procedure Login
  (
  p_UserPkId     in   ASPNET_USERS.PKID%type,
  p_IdCoa        in   COA.IDCOA%type,
  p_IdSessione   in   CONNESSIONIATTIVECOA.IdSessione%type,
  p_IdPostazione out  CONNESSIONIATTIVECOA.IdPostazione%type
  )
  is
  p_IdPostazioneOld CONNESSIONIATTIVECOA.IdPostazione%type;
  p_IdCoaOld        COA.IDCOA%type;
  p_IdPostazioneNew CONNESSIONIATTIVECOA.IdPostazione%type;
  begin
  null;
  -- controllo se l'utente ha ancora la postazione attiva.

  begin
    select
    IdPostazione, IdCoa
    into
    p_IdPostazioneOld, p_IdCoaOld
    from ConnessioniAttiveCoa
    where
    IdUtente = p_UserPkId;
  exception
    when no_data_found then
      p_IdPostazioneOld := null;
      p_IdCoaOld := null;
  end;

  if (p_IdCoaOld = p_IdCoa) then

    update ConnessioniAttiveCoa
    set
    IdSessione = p_IdSessione
    where
    IdUtente = p_UserPkId;

  else

    delete from ConnessioniAttiveCoa
    where IdUtente = p_UserPkId;

    p_IdPostazioneNew := 0;
    while p_IdPostazioneNew <= 999
    loop
      begin
        null;
      exception when no_data_found then
        null;
      end;
    end loop;




  end if;

  end;

  procedure Logout
  (
  p_IdSessione CONNESSIONIATTIVECOA.IdSessione%type
  )
  is
  begin
  null;
  end;

end;
GO
