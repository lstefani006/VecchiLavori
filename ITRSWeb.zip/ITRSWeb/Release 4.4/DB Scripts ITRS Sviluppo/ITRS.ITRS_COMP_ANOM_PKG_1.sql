DROP PACKAGE BODY ITRS.ITRS_COMP_ANOM_PKG
GO
CREATE PACKAGE BODY ITRS.ITRS_COMP_ANOM_PKG is
/*******************************************************************************
* Module    : ITRS_COMP_ANOM_PKG
* Description :
********************************************************************************
*                         Revision history
*
*  Date      Who       Description
*  --------  -------   ------------------------------------------------
*  23/12/05  P.Lercari first release
*  31/07/06  P.Lercari Filtro su tabella LTBianche
***********************************************************************************/

PROCEDURE Calcola_TSE is

cursor C_Transiti is
Select distinct targa,nazionalita
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and enumtipovarco = itrs_const_pkg.VAL_TIPOVARCO_USCITA
and (targa,nazionalita) not in (select targa,nazionalita
												from LTBianche
												where dataorainiziovalidita <= sysdate-1
												and dataorafinevalidita >= sysdate-1)
order by targa,nazionalita;

cursor C_Trans_Correlati (Targa_Id varchar2,nazione varchar2) is
Select dataorarilevamento,idc2p,enumtipovarco
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and targa = Targa_Id
and nazionalita = nazione
union
select dataorarilevamento,idc2p,enumtipovarco
from Transiti
where dataorarilevamento = (select max(dataorarilevamento)
			  										from Transiti
			  										where dataorarilevamento>=trunc(sysdate-2)
			  										and dataorarilevamento<trunc(sysdate-1)
			  										and targa = Targa_Id
			  										and nazionalita = nazione)
and targa = Targa_Id
and nazionalita = nazione
order by dataorarilevamento;

Count_Fetch number(10);
n_tempo_sosta parametri.parvalue%type;
v_targa transiti.targa%type;
v_naz transiti.nazionalita%type;
d_data_rilev date;
d_data_rilev_prec date;
delta_t number(10);
n_idc2p transiti.idc2p%type;
v_tipovarco transiti.enumtipovarco%type;
n_idc2p_prec transiti.idc2p%type;
v_tipovarco_prec transiti.enumtipovarco%type;
n_idcoa c2p.idcoa%type;
d_ora_ins date;
ev_id eventidasegnalare.idevento%type;
InizioT date;
FineT date;

Begin

 select sysdate into InizioT from dual;

 dbms_output.put_line('Inizio esecuzione Calcola_TSE alle ' ||Substr(to_char(InizioT, 'HH24:MI:SS'),1,10));

 Count_Fetch := 0;

 select PARVALUE
 into n_tempo_sosta
 from Parametri
 where partipo = 'TEMPO_SOSTA';

 open C_Transiti;
  loop
  	--26/01/06
  	Count_Fetch := 0;
  	--26/01/06

    fetch C_Transiti into v_targa,v_naz;
    exit when C_Transiti%NOTFOUND;

    --dbms_output.put_line('Valore targa '||v_targa||' nazione '||v_naz);

		d_data_rilev_prec := null;
		n_idc2p_prec := null;
		v_tipovarco_prec := null;

    open C_Trans_Correlati (v_targa,v_naz);
    loop
     fetch C_Trans_Correlati into d_data_rilev,n_idc2p,v_tipovarco;
     exit when C_Trans_Correlati%NOTFOUND;
     Count_Fetch := Count_Fetch + 1;
     --dbms_output.put_line('Valore data_rilev_prec-c2p_prec-tipovarco_prec-data_rilev-c2p-tipovarco '||d_data_rilev_prec||' '||n_idc2p_prec||' '||v_tipovarco_prec||' '||d_data_rilev||' '||n_idc2p||' '||v_tipovarco);

     if Count_Fetch <> 1 then
			if (n_idc2p = n_idc2p_prec) and (v_tipovarco = itrs_const_pkg.VAL_TIPOVARCO_USCITA) and (v_tipovarco_prec=itrs_const_pkg.VAL_TIPOVARCO_INGRESSO) then
				delta_t := (d_data_rilev - d_data_rilev_prec)*1440;
				if delta_t >= n_tempo_sosta then
					select IdCOA
					into n_idcoa
					from C2P
					where IdC2p = n_idc2p;

					d_ora_ins := sysdate;
 					insert into EventiDaSegnalare(TARGA,NAZIONALITA,DATAORAINSERIMENTO,IDEVENTO,ENUMTIPOEVENTO,ENUMSTATOALLARME,
                                        NOTECHIUSURA,IDCOACOMPETENZA,ENUMCLASSEURGENZA)
					values (v_targa,v_naz,d_ora_ins,SEQ_EV.nextval,itrs_const_pkg.VAL_TIPOEVENTO_TSE,itrs_const_pkg.VAL_STATOALLARME_ACQ,null,
					        n_idcoa,itrs_const_pkg.VAL_CLASSEURGENZA_ATT);

          --dbms_output.put_line('Inserita in EventiDaSegnalare targa '||v_targa);

					select SEQ_EV.currval into ev_id from dual;

			   	begin

						insert into TransitiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,DATAORAINSERIMENTO,ENUMSTATOTRANSITO,
						                             LATITUDINE,LONGITUDINE,TARGAACQUISITA,NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,
						                             MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,DATAORACHIUSURA,NOTECHIUSURA)
						select TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,d_ora_ins,ENUMSTATOTRANSITO,LATITUDINE,LONGITUDINE,TARGAACQUISITA,
						       NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,
						       DATAORACHIUSURA,NOTECHIUSURA
						from Transiti
						where targa = v_targa
						and nazionalita = v_naz
						and dataorarilevamento = d_data_rilev_prec;

						--dbms_output.put_line('Inserito primo record in TransitiSuEvento targa '||v_targa);

					exception when dup_val_on_index then
 						null;
					end;

					begin

						insert into TransitiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,DATAORAINSERIMENTO,ENUMSTATOTRANSITO,
						                             LATITUDINE,LONGITUDINE,TARGAACQUISITA,NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,
						                             MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,DATAORACHIUSURA,NOTECHIUSURA)
						select TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,d_ora_ins,ENUMSTATOTRANSITO,LATITUDINE,LONGITUDINE,TARGAACQUISITA,
						       NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,
						       DATAORACHIUSURA,NOTECHIUSURA
						from Transiti
						where targa = v_targa
						and nazionalita = v_naz
						and dataorarilevamento = d_data_rilev;

						--dbms_output.put_line('Inserito secondo record in TransitiSuEvento targa '||v_targa);

					exception when dup_val_on_index then
 						null;
					end;

					begin

					insert into ImmaginiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDIMMAGINE,IMMAGINE,FORMATO,CODIFICA,RISOLUZIONE)
 					select targa,nazionalita,dataorarilevamento,idimmagine,immagine,formato,codifica,risoluzione
 					from Immagini
 					where targa = v_targa
					and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev_prec;

 					--dbms_output.put_line('Inserito primo record in ImmaginiSuEvento targa '||v_targa);

				exception when dup_val_on_index then
 						null;
				end;

				begin

					insert into ImmaginiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDIMMAGINE,IMMAGINE,FORMATO,CODIFICA,RISOLUZIONE)
 					select targa,nazionalita,dataorarilevamento,idimmagine,immagine,formato,codifica,risoluzione
 					from Immagini
 					where targa = v_targa
					and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev;

 					--dbms_output.put_line('Inserito secondo record in ImmaginiSuEvento targa '||v_targa);

				exception when dup_val_on_index then
 						null;
				end;

					insert into TransitiEventi(TARGA,NAZIONALITA,DATAORAINSERIMENTO,DATAORARILEVAMENTO,IDEVENTO)
					select targa,nazionalita,d_ora_ins,dataorarilevamento,ev_id
					from Transiti
					where targa = v_targa and nazionalita = v_naz
					and (dataorarilevamento = d_data_rilev_prec or dataorarilevamento = d_data_rilev);

					--dbms_output.put_line('Inserita in TransitiEventi targa '||v_targa);
				end if;
		end if;

   end if;
   d_data_rilev_prec := d_data_rilev;
   n_idc2p_prec := n_idc2p;
   v_tipovarco_prec := v_tipovarco;

  end loop;
 close C_Trans_Correlati;

 end loop;
 close C_Transiti;
 commit;

 select sysdate into FineT from dual;

 dbms_output.put_line('Fine esecuzione Calcola_TSE alle ' ||Substr(to_char(FineT, 'HH24:MI:SS'),1,10));

 dbms_output.put_line ('Calcola_TSE terminato senza anomalie');


 Exception when Others then
           dbms_output.put_line('Errore durante esecuzione Calcola_TSE');
           dbms_output.put_line('Errore: ' || substr(sqlerrm,1,250));
           Rollback;
           return;
end Calcola_TSE;

PROCEDURE Calcola_EFV is

cursor C_Transiti_Ingresso is
select idc2p,targa,nazionalita,count(*)
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and enumtipovarco = itrs_const_pkg.VAL_TIPOVARCO_INGRESSO
and (targa,nazionalita) not in (select targa,nazionalita
												from LTBianche
												where dataorainiziovalidita <= sysdate-1
												and dataorafinevalidita >= sysdate-1)
group by idc2p,targa,nazionalita
order by idc2p,targa,nazionalita;

cursor C_Trans_Correlati (c2p number,Targa_Id varchar2,nazione varchar2) is
Select dataorarilevamento
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and targa = Targa_Id
and nazionalita = nazione
and idc2p = c2p
and enumtipovarco = itrs_const_pkg.VAL_TIPOVARCO_INGRESSO
order by dataorarilevamento;

conta number(10);
n_freq_visite parametri.parvalue%type;
v_targa transiti.targa%type;
v_naz transiti.nazionalita%type;
d_data_rilev date;
n_idc2p transiti.idc2p%type;
v_tipovarco transiti.enumtipovarco%type;
n_idcoa c2p.idcoa%type;
d_ora_ins date;
ev_id eventidasegnalare.idevento%type;
InizioT date;
FineT date;

Begin

 select sysdate into InizioT from dual;

 dbms_output.put_line('Inizio esecuzione Calcola_EFV alle ' ||Substr(to_char(InizioT, 'HH24:MI:SS'),1,10));

 select PARVALUE
 into n_freq_visite
 from Parametri
 where partipo = 'FREQ_VISITE';

 open C_Transiti_Ingresso;
  loop
   conta := 0;
   fetch C_Transiti_Ingresso into n_idc2p,v_targa,v_naz,conta;
   exit when C_Transiti_Ingresso%NOTFOUND;

   --conta := conta + 1;
   --dbms_output.put_line('Valore c2p '||n_idc2p||' targa '||v_targa||' nazione '||v_naz||' num visite '||conta);

   if conta >= n_freq_visite then
   	
   	select IdCOA
		into n_idcoa
		from C2P
		where IdC2p = n_idc2p;

		d_ora_ins := sysdate;
 	  insert into EventiDaSegnalare(TARGA,NAZIONALITA,DATAORAINSERIMENTO,IDEVENTO,ENUMTIPOEVENTO,ENUMSTATOALLARME,
                                        NOTECHIUSURA,IDCOACOMPETENZA,ENUMCLASSEURGENZA)
		values (v_targa,v_naz,d_ora_ins,SEQ_EV.nextval,itrs_const_pkg.VAL_TIPOEVENTO_EFV,itrs_const_pkg.VAL_STATOALLARME_ACQ,
					    null,n_idcoa,itrs_const_pkg.VAL_CLASSEURGENZA_ATT);

    --dbms_output.put_line('Inserita in EventiDaSegnalare targa '||v_targa);

    open C_Trans_Correlati (n_idc2p,v_targa,v_naz);
    loop
     fetch C_Trans_Correlati into d_data_rilev;
     exit when C_Trans_Correlati%NOTFOUND;

					select SEQ_EV.currval into ev_id from dual;

    		  begin

            insert into TransitiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,DATAORAINSERIMENTO,ENUMSTATOTRANSITO,
						                             LATITUDINE,LONGITUDINE,TARGAACQUISITA,NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,
						                             MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,DATAORACHIUSURA,NOTECHIUSURA)
						select TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,d_ora_ins,ENUMSTATOTRANSITO,LATITUDINE,LONGITUDINE,TARGAACQUISITA,
						       NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,
						       DATAORACHIUSURA,NOTECHIUSURA
						from Transiti
						where targa = v_targa
						and nazionalita = v_naz
						and dataorarilevamento = d_data_rilev;

            --dbms_output.put_line('Inserita in TransitiSuEvento targa '||v_targa);

					exception when dup_val_on_index then
 					 	null;
					end;

    		begin

					insert into ImmaginiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDIMMAGINE,IMMAGINE,FORMATO,CODIFICA,RISOLUZIONE)
 					select targa,nazionalita,dataorarilevamento,idimmagine,immagine,formato,codifica,risoluzione
 					from Immagini
 					where targa = v_targa
					and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev;

 					--dbms_output.put_line('Inserita in ImmaginiSuEvento targa '||v_targa);

				exception when dup_val_on_index then
 						null;
				end;

					insert into TransitiEventi(TARGA,NAZIONALITA,DATAORAINSERIMENTO,DATAORARILEVAMENTO,IDEVENTO)
					select v_targa,v_naz,d_ora_ins,dataorarilevamento,ev_id
					from Transiti
					where targa = v_targa and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev;

					--dbms_output.put_line('Inserita in TransitiEventi targa '||v_targa);

   end loop;
  close C_Trans_Correlati;
  end if;
 end loop;
 close C_Transiti_Ingresso;
 commit;

 select sysdate into FineT from dual;

 dbms_output.put_line('Fine esecuzione Calcola_EFV alle ' ||Substr(to_char(FineT, 'HH24:MI:SS'),1,10));

 dbms_output.put_line ('Calcola_EFV terminato senza anomalie');


 Exception when Others then
           dbms_output.put_line('Errore durante esecuzione Calcola_EFV');
           dbms_output.put_line('Errore: ' || substr(sqlerrm,1,250));
           Rollback;
           return;
 end Calcola_EFV;

PROCEDURE Calcola_ENV is

cursor C_Transiti_Ingresso is
Select distinct targa,nazionalita
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and enumtipovarco = itrs_const_pkg.VAL_TIPOVARCO_INGRESSO
and (targa,nazionalita) not in (select targa,nazionalita
												from LTBianche
												where dataorainiziovalidita <= sysdate-1
												and dataorafinevalidita >= sysdate-1)
order by targa,nazionalita;

cursor C_C2p (Targa_Id varchar2,nazione varchar2) is
Select distinct idc2p
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and targa = Targa_Id
and nazionalita = nazione
and enumtipovarco = itrs_const_pkg.VAL_TIPOVARCO_INGRESSO
order by idc2p;

cursor C_Trans_Correlati (Targa_Id varchar2,nazione varchar2,c2p number) is
Select dataorarilevamento
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and targa = Targa_Id
and nazionalita = nazione
and idc2p = c2p
and enumtipovarco = itrs_const_pkg.VAL_TIPOVARCO_INGRESSO
order by dataorarilevamento;

conta_c2p number(10);
n_elev_visite parametri.parvalue%type;
v_targa transiti.targa%type;
v_naz transiti.nazionalita%type;
d_data_rilev date;
n_idc2p transiti.idc2p%type;
n_idc2p_rec transiti.idc2p%type;
v_tipovarco transiti.enumtipovarco%type;
n_idcoa c2p.idcoa%type;
d_ora_ins date;
max_data_rilev date;
ev_id eventidasegnalare.idevento%type;
esci integer;
InizioT date;
FineT date;

Begin

 select sysdate into InizioT from dual;

 dbms_output.put_line('Inizio esecuzione Calcola_ENV alle ' ||Substr(to_char(InizioT, 'HH24:MI:SS'),1,10));

 select PARVALUE
 into n_elev_visite
 from Parametri
 where partipo = 'NUM_C2P_VISITE';

 open C_Transiti_Ingresso;
  loop
   fetch C_Transiti_Ingresso into v_targa,v_naz;
   exit when C_Transiti_Ingresso%NOTFOUND;

   --dbms_output.put_line('Valore targa '||v_targa||' nazione '||v_naz);

    esci := 0;
    open C_C2p (v_targa,v_naz);
    loop
     conta_c2p := 0;
     fetch C_C2p into n_idc2p;
     exit when C_C2p%NOTFOUND;

		--dbms_output.put_line('Valore c2p '||n_idc2p);

		 	conta_c2p := conta_c2p+1;
			--dbms_output.put_line('Valore conta c2p '||conta_c2p);
				if conta_c2p = n_elev_visite then
					esci := 1;

					--inserisco dati del c2p relativo al transito piu' recente
					select max(dataorarilevamento)
					into max_data_rilev
					from Transiti
					where dataorarilevamento>=trunc(sysdate-1)
					and dataorarilevamento<trunc(sysdate)
					and targa = v_targa
					and nazionalita = v_naz
					and enumtipovarco = itrs_const_pkg.VAL_TIPOVARCO_INGRESSO;

					select IdC2p
					into n_idc2p_rec
					from Transiti
					where targa = v_targa
					and nazionalita = v_naz
					and dataorarilevamento = max_data_rilev;

					select IdCOA
					into n_idcoa
					from C2P
					where IdC2p = n_idc2p_rec;

				d_ora_ins := sysdate;
 				insert into EventiDaSegnalare(TARGA,NAZIONALITA,DATAORAINSERIMENTO,IDEVENTO,ENUMTIPOEVENTO,ENUMSTATOALLARME,
                                      NOTECHIUSURA,IDCOACOMPETENZA,ENUMCLASSEURGENZA)
				values (v_targa,v_naz,d_ora_ins,SEQ_EV.nextval,itrs_const_pkg.VAL_TIPOEVENTO_ENV,itrs_const_pkg.VAL_STATOALLARME_ACQ,
					      null,n_idcoa,itrs_const_pkg.VAL_CLASSEURGENZA_ATT);

        --dbms_output.put_line('Inserita in EventiDaSegnalare targa '||v_targa);

			  select SEQ_EV.currval into ev_id from dual;
				---per ogni c2p associato alla targa-transito non solo quello corrente

				open C_Trans_Correlati (v_targa,v_naz,n_idc2p_rec);
    		loop

     		fetch C_Trans_Correlati into d_data_rilev;
     		exit when C_Trans_Correlati%NOTFOUND;

				begin
					insert into TransitiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,DATAORAINSERIMENTO,ENUMSTATOTRANSITO,
						                             LATITUDINE,LONGITUDINE,TARGAACQUISITA,NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,
						                             MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,DATAORACHIUSURA,NOTECHIUSURA)
					select TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,d_ora_ins,ENUMSTATOTRANSITO,LATITUDINE,LONGITUDINE,TARGAACQUISITA,
						       NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,
						       DATAORACHIUSURA,NOTECHIUSURA
					from Transiti
					where targa = v_targa
					and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev;

					--dbms_output.put_line('Inserita in TransitiSuEvento targa '||v_targa);

				exception when dup_val_on_index then
 						null;
				end;

				begin
          insert into ImmaginiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDIMMAGINE,IMMAGINE,FORMATO,CODIFICA,RISOLUZIONE)
 					select targa,nazionalita,dataorarilevamento,idimmagine,immagine,formato,codifica,risoluzione
 					from Immagini
 					where targa = v_targa
					and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev;

					--dbms_output.put_line('Inserita in ImmaginiSuEvento targa '||v_targa);

				exception when dup_val_on_index then
 						null;
				end;

					insert into TransitiEventi(TARGA,NAZIONALITA,DATAORAINSERIMENTO,DATAORARILEVAMENTO,IDEVENTO)
					select v_targa,v_naz,d_ora_ins,dataorarilevamento,ev_id
					from Transiti
					where targa = v_targa and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev;

					--dbms_output.put_line('Inserita in TransitiEventi targa '||v_targa);

   end loop;
  close C_Trans_Correlati;
	end if;
	---se si e' raggiunta la soglia si deve uscire da C_C2p
	if esci = 1 then
		exit;
	end if;
  end loop;
  close C_C2p;
 end loop;
 close C_Transiti_Ingresso;
 commit;

 select sysdate into FineT from dual;

 dbms_output.put_line('Fine esecuzione Calcola_ENV alle ' ||Substr(to_char(FineT, 'HH24:MI:SS'),1,10));

 dbms_output.put_line ('Calcola_ENV terminato senza anomalie');


 Exception when Others then
           dbms_output.put_line('Errore durante esecuzione Calcola_ENV');
           dbms_output.put_line('Errore: ' || substr(sqlerrm,1,250));
           Rollback;
           return;

end Calcola_ENV;

PROCEDURE Calcola_VMS is

cursor C_Transiti is
Select distinct targa,nazionalita
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
order by targa,nazionalita;

cursor C_Trans_Correlati (Targa_Id varchar2,nazione varchar2) is
Select dataorarilevamento,idc2p,enumtipovarco
from Transiti
where dataorarilevamento>=trunc(sysdate-1)
and dataorarilevamento<trunc(sysdate)
and targa = Targa_Id
and nazionalita = nazione
union
select dataorarilevamento,idc2p,enumtipovarco
from Transiti
where dataorarilevamento = (select max(dataorarilevamento)
			  										from Transiti
			  										where dataorarilevamento>=trunc(sysdate-2)
			  										and dataorarilevamento<trunc(sysdate-1)
			  										and targa = Targa_Id
			  										and nazionalita = nazione)
and targa = Targa_Id
and nazionalita = nazione
order by dataorarilevamento;

Count_Fetch number(10);
n_tempo_min_percor number(10);
v_targa transiti.targa%type;
v_naz transiti.nazionalita%type;
d_data_rilev date;
d_data_rilev_old date;
delta_t number(10);
n_idc2p transiti.idc2p%type;
n_idc2p_old transiti.idc2p%type;
v_tipovarco transiti.enumtipovarco%type;
v_tipovarco_old transiti.enumtipovarco%type;
n_tratta_prec c2p.idtrattaprec%type;
n_tratta_succ c2p.idtrattasucc%type;
n_tratta_succ_old c2p.idtrattasucc%type;
n_idcoa c2p.idcoa%type;
d_ora_ins date;
ev_id eventidasegnalare.idevento%type;
InizioT date;
FineT date;

Begin

 select sysdate into InizioT from dual;

 dbms_output.put_line('Inizio esecuzione Calcola_VMS alle ' ||Substr(to_char(InizioT, 'HH24:MI:SS'),1,10));

 Count_Fetch := 0;

 open C_Transiti;
  loop
  	--26/01/06
  	Count_Fetch := 0;
  	--26/01/06
    fetch C_Transiti into v_targa,v_naz;
    exit when C_Transiti%NOTFOUND;

    --dbms_output.put_line('Valore targa '||v_targa||' nazione '||v_naz);

		d_data_rilev_old := null;
   	n_idc2p_old := null;
   	v_tipovarco_old := null;
   	n_tratta_succ_old := null;

    open C_Trans_Correlati (v_targa,v_naz);
    loop
     fetch C_Trans_Correlati into d_data_rilev,n_idc2p,v_tipovarco;
     exit when C_Trans_Correlati%NOTFOUND;
     Count_Fetch := Count_Fetch + 1;

     --dbms_output.put_line('Valore data_rilev_old-c2p_old-tipovarco_old-data_rilev-c2p-tipovarco '||d_data_rilev_old||' '||n_idc2p_old||' '||v_tipovarco_old||' '||d_data_rilev||' '||n_idc2p||' '||v_tipovarco);
     select IdTrattaPrec,IdTrattaSucc
     into n_tratta_prec,n_tratta_succ
     from C2p
     where IdC2p = n_idc2p;

     if Count_Fetch <> 1 then
			if (n_idc2p <> n_idc2p_old) and (v_tipovarco in (itrs_const_pkg.VAL_TIPOVARCO_INGRESSO,itrs_const_pkg.VAL_TIPOVARCO_SX,itrs_const_pkg.VAL_TIPOVARCO_DX))
			and (v_tipovarco_old in (itrs_const_pkg.VAL_TIPOVARCO_USCITA,itrs_const_pkg.VAL_TIPOVARCO_SX,itrs_const_pkg.VAL_TIPOVARCO_DX))
			and (n_tratta_succ_old = n_tratta_prec) then
				delta_t := (d_data_rilev - d_data_rilev_old)*86400;

				select tempominpercorrenzasecondi
				into n_tempo_min_percor
				from Tratte
				where idtratta = n_tratta_prec;

				if delta_t <= n_tempo_min_percor then
					select IdCOA
					into n_idcoa
					from C2P
					where IdC2p = n_idc2p;

					d_ora_ins := sysdate;
 					insert into EventiDaSegnalare(TARGA,NAZIONALITA,DATAORAINSERIMENTO,IDEVENTO,ENUMTIPOEVENTO,ENUMSTATOALLARME,
                                        NOTECHIUSURA,IDCOACOMPETENZA,ENUMCLASSEURGENZA)
					values (v_targa,v_naz,d_ora_ins,SEQ_EV.nextval,itrs_const_pkg.VAL_TIPOEVENTO_VMS,itrs_const_pkg.VAL_STATOALLARME_ACQ,null,
					        n_idcoa,itrs_const_pkg.VAL_CLASSEURGENZA_ATT);

          --dbms_output.put_line('Inserita in EventiDaSegnalare targa '||v_targa);

					select SEQ_EV.currval into ev_id from dual;

			   	begin

						insert into TransitiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,DATAORAINSERIMENTO,ENUMSTATOTRANSITO,
						                             LATITUDINE,LONGITUDINE,TARGAACQUISITA,NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,
						                             MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,DATAORACHIUSURA,NOTECHIUSURA)
						select TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,d_ora_ins,ENUMSTATOTRANSITO,LATITUDINE,LONGITUDINE,TARGAACQUISITA,
						       NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,
						       DATAORACHIUSURA,NOTECHIUSURA
						from Transiti
						where targa = v_targa
						and nazionalita = v_naz
						and dataorarilevamento = d_data_rilev_old;

						--dbms_output.put_line('Inserito primo record in TransitiSuEvento targa '||v_targa);

						exception when dup_val_on_index then
 							null;
						end;


					begin

						insert into TransitiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,DATAORAINSERIMENTO,ENUMSTATOTRANSITO,
						                             LATITUDINE,LONGITUDINE,TARGAACQUISITA,NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,
						                             MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,DATAORACHIUSURA,NOTECHIUSURA)
						select TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDC2P,ENUMTIPOVARCO,d_ora_ins,ENUMSTATOTRANSITO,LATITUDINE,LONGITUDINE,TARGAACQUISITA,
						       NAZIONALITAACQUISITA,CONFIDENZAACQUISIZIONETARGA,MARCAVEICOLO,MODELLOVEICOLO,IDUTENTEPRESAINCARICO,DATAORAPRESAINCARICO,
						       DATAORACHIUSURA,NOTECHIUSURA
						from Transiti
						where targa = v_targa
						and nazionalita = v_naz
						and dataorarilevamento = d_data_rilev;

						--dbms_output.put_line('Inserito secondo record in TransitiSuEvento targa '||v_targa);

					exception when dup_val_on_index then
 						null;
					end;

			begin

					insert into ImmaginiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDIMMAGINE,IMMAGINE,FORMATO,CODIFICA,RISOLUZIONE)
 					select targa,nazionalita,dataorarilevamento,idimmagine,immagine,formato,codifica,risoluzione
 					from Immagini
 					where targa = v_targa
					and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev_old;

 					--dbms_output.put_line('Inserito primo record in ImmaginiSuEvento targa '||v_targa);

				exception when dup_val_on_index then
 						null;
			end;

			begin

					insert into ImmaginiSuEvento(TARGA,NAZIONALITA,DATAORARILEVAMENTO,IDIMMAGINE,IMMAGINE,FORMATO,CODIFICA,RISOLUZIONE)
 					select targa,nazionalita,dataorarilevamento,idimmagine,immagine,formato,codifica,risoluzione
 					from Immagini
 					where targa = v_targa
					and nazionalita = v_naz
					and dataorarilevamento = d_data_rilev;

 					--dbms_output.put_line('Inserito secondo record in ImmaginiSuEvento targa '||v_targa);

				exception when dup_val_on_index then
 						null;
				end;

					insert into TransitiEventi(TARGA,NAZIONALITA,DATAORAINSERIMENTO,DATAORARILEVAMENTO,IDEVENTO)
					select targa,nazionalita,d_ora_ins,dataorarilevamento,ev_id
					from Transiti
					where targa = v_targa and nazionalita = v_naz
					and (dataorarilevamento = d_data_rilev_old or dataorarilevamento = d_data_rilev);

					--dbms_output.put_line('Inserita in TransitiEventi targa '||v_targa);

		 end if;
	  end if;

   end if;
   d_data_rilev_old := d_data_rilev;
   n_idc2p_old := n_idc2p;
   v_tipovarco_old := v_tipovarco;
   n_tratta_succ_old := n_tratta_succ;

  end loop;
 close C_Trans_Correlati;

 end loop;
 close C_Transiti;
 commit;

 select sysdate into FineT from dual;

 dbms_output.put_line('Fine esecuzione Calcola_VMS alle ' ||Substr(to_char(FineT, 'HH24:MI:SS'),1,10));

 dbms_output.put_line ('Calcola_VMS terminato senza anomalie');


 Exception when Others then
           dbms_output.put_line('Errore durante esecuzione Calcola_VMS');
           dbms_output.put_line('Errore: ' || substr(sqlerrm,1,250));
           Rollback;
           return;
end Calcola_VMS;

PROCEDURE Comp_Anom_Main is

InizioT date;
FineT date;

begin

	select sysdate into InizioT from dual;

	dbms_output.put_line('Inizio esecuzione Comp_Anom_Main alle ' ||Substr(to_char(InizioT, 'HH24:MI:SS'),1,10));

	Calcola_TSE;

	Calcola_EFV;

	Calcola_ENV;

	Calcola_VMS;

	select sysdate into FineT from dual;

	dbms_output.put_line('Fine esecuzione Comp_Anom_Main alle ' ||Substr(to_char(FineT, 'HH24:MI:SS'),1,10));

end Comp_Anom_Main;

end itrs_comp_anom_pkg;
GO
