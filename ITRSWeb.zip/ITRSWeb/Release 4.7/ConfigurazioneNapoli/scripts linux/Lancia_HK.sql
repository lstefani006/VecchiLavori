spool Lancia_HK

set serveroutput on
exec dbms_output.enable(1000000);
set timing on

:declare

begin
 Housekeeping;
-- Housekeeping('probeonly');
end;
/

spool off
exit;

