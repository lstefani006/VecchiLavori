#! /bin/sh

. ~/.bash_profile

EXE_DIR=$HOME/itrsas/db/scripts
OUTPUT_DIR=$HOME/itrsas/db/scripts/OUTPUT
ERROR_DIR=$HOME/itrsas/db/scripts/ERROR
ERR_FILE=$ERROR_DIR/ERR_`date +%y%m%d%H%M`
OUT_FILE=$OUTPUT_DIR/OUT_`date +%y%m%d%H%M`
DIR=/oradata/sarcdb

if [ ! -d $DIR ]
then
        echo "Esco" > $ERR_FILE
        exit
fi

cd $EXE_DIR

echo `date +%y%m%d%H%M` > $EXE_DIR/LAST_TMP

#sqlplus itrs/itrs @Lancia_Comp_Anom.sql > /dev/null
#Res_sqlplus=`echo $?`
#if [ $Res_sqlplus -ne 0 ]
#then
      #mv $EXE_DIR/Lancia_Comp_Anom.lst `date +$EXE_DIR/Lancia_Comp_Anom_%y%m%d%H%M`.lst
        #echo "Elaborazione corrente non terminata correttamente vedere Lancia_Comp_Anom_*.lst">$ERR_FILE
        #echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
#else
       #grep Errore Lancia_Comp_Anom.lst > /dev/null
       #if [ $? = "0" ]
       #then
       #mv $EXE_DIR/Lancia_Comp_Anom.lst `date +$EXE_DIR/Lancia_Comp_Anom_%y%m%d%H%M`.lst
       #echo "Elaborazione corrente non terminata correttamente vedere Lancia_Comp_Anom_*.lst">$ERR_FILE
       #echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       #fi
      #grep ORA Lancia_Comp_Anom.lst > /dev/null
      #if [ $? = "0" ]
      #then
       #mv $EXE_DIR/Lancia_Comp_Anom.lst `date +$EXE_DIR/Lancia_Comp_Anom_%y%m%d%H%M`.lst
       #echo "Elaborazione corrente non terminata correttamente vedere Lancia_Comp_Anom_*.lst">$ERR_FILE
       #echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       #fi
#fi

sqlplus itrs/itrs @Lancia_Calcola_Stats.sql > /dev/null
Res_sqlplus=`echo $?`
if [ $Res_sqlplus -ne 0 ]
then
      mv $EXE_DIR/Lancia_Calcola_Stats.lst `date +$EXE_DIR/Lancia_Calcola_Stats_%y%m%d%H%M`.lst
        echo "Elaborazione corrente non terminata correttamente vedere Lancia_Calcola_Stats_*.lst">>$ERR_FILE
        echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
else
       grep Errore Lancia_Calcola_Stats.lst > /dev/null
       if [ $? = "0" ]
       then
       mv $EXE_DIR/Lancia_Calcola_Stats.lst `date +$EXE_DIR/Lancia_Calcola_Stats_%y%m%d%H%M`.lst
       echo "Elaborazione corrente non terminata correttamente vedere Lancia_Calcola_Stats_*.lst">>$ERR_FILE
       echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       fi
      grep ORA Lancia_Calcola_Stats.lst > /dev/null
      if [ $? = "0" ]
      then
       mv $EXE_DIR/Lancia_Calcola_Stats.lst `date +$EXE_DIR/Lancia_Calcola_Stats_%y%m%d%H%M`.lst
       echo "Elaborazione corrente non terminata correttamente vedere Lancia_Calcola_Stats_*.lst">>$ERR_FILE
       echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       fi
fi

sqlplus itrs/itrs @Lancia_PurgeTab.sql > /dev/null
Res_sqlplus=`echo $?`
if [ $Res_sqlplus -ne 0 ]
then
      mv $EXE_DIR/Lancia_PurgeTab.lst `date +$EXE_DIR/Lancia_PurgeTab_%y%m%d%H%M`.lst
        echo "Elaborazione corrente non terminata correttamente vedere Lancia_PurgeTab_*.lst">>$ERR_FILE
        echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
else
       grep Errore Lancia_PurgeTab.lst > /dev/null
       if [ $? = "0" ]
       then
       mv $EXE_DIR/Lancia_PurgeTab.lst `date +$EXE_DIR/Lancia_PurgeTab_%y%m%d%H%M`.lst
       echo "Elaborazione corrente non terminata correttamente vedere Lancia_PurgeTab_*.lst">>$ERR_FILE
       echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       fi
      grep ORA Lancia_PurgeTab.lst > /dev/null
      if [ $? = "0" ]
      then
       mv $EXE_DIR/Lancia_PurgeTab.lst `date +$EXE_DIR/Lancia_PurgeTab_%y%m%d%H%M`.lst
       echo "Elaborazione corrente non terminata correttamente vedere Lancia_PurgeTab_*.lst">>$ERR_FILE
       echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       fi
fi

sqlplus system/oadmin @Lancia_Stats_Itrs.sql > /dev/null
Res_sqlplus=`echo $?`
if [ $Res_sqlplus -ne 0 ]
then
      mv $EXE_DIR/Lancia_Stats_Itrs.lst `date +$EXE_DIR/Lancia_Stats_Itrs_%y%m%d%H%M`.lst
        echo "Elaborazione corrente non terminata correttamente vedere Lancia_Stats_Itrs_*.lst">>$ERR_FILE
        echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
        exit 1
else
       grep Errore Lancia_Stats_Itrs.lst > /dev/null
       if [ $? = "0" ]
       then
       mv $EXE_DIR/Lancia_Stats_Itrs.lst `date +$EXE_DIR/Lancia_Stats_Itrs_%y%m%d%H%M`.lst
       echo "Elaborazione corrente non terminata correttamente vedere Lancia_Stats_Itrs_*.lst">>$ERR_FILE
       echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       exit 1
       fi
      grep ORA Lancia_Stats_Itrs.lst > /dev/null
      if [ $? = "0" ]
      then
       mv $EXE_DIR/Lancia_Stats_Itrs.lst `date +$EXE_DIR/Lancia_Stats_Itrs_%y%m%d%H%M`.lst
       echo "Elaborazione corrente non terminata correttamente vedere Lancia_Stats_Itrs_*.lst">>$ERR_FILE
       echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       exit 1
       fi
fi


echo "Elaborazione del giorno terminata correttamente" >>$OUT_FILE
\rm -f $EXE_DIR/LAST_TMP
exit 0

