spool PurgeTab_Allarmi_CompAnom 
set serveroutput on
set timing on
declare

begin

commit;

 DBMS_OUTPUT.put_line('Fine PurgeTab_Allarmi_CompAnom '||to_char(sysdate,'hh24:mi:ss'));

 Exception when Others then
 dbms_output.put_line('Errore durante esecuzione PurgeTab_Allarmi_CompAnom');
           dbms_output.put_line('Errore: ' || substr(sqlerrm,1,250));
           Rollback;

end;
/
spool off
exit;

