spool Lancia_Calcola_Stats

set serveroutput on
set timing on

declare

begin
 itrs_stats_pkg.Calcola_Stats;
end;
/

spool off
exit;

