spool Lancia_PurgeTab

set serveroutput on
set timing on

declare

begin
 Purge_Tables;
end;
/

spool off
exit;

