#! /bin/sh

. ~/.bash_profile

EXE_DIR=$HOME/itrsas/db/scripts
OUTPUT_DIR=$HOME/itrsas/db/scripts/OUTPUT
ERROR_DIR=$HOME/itrsas/db/scripts/ERROR
ERR_FILE=$ERROR_DIR/ERR_`date +%y%m%d%H%M`
OUT_FILE=$OUTPUT_DIR/OUT_`date +%y%m%d%H%M`
DIR=/oradata/sarcdb

if [ ! -d $DIR ]
then
        echo "Esco" > $ERR_FILE
        exit
fi

cd $EXE_DIR

sqlplus itrs/itrs @Lancia_HK.sql > /dev/null
Res_sqlplus=`echo $?`
if [ $Res_sqlplus -ne 0 ]
then
      mv $EXE_DIR/Lancia_HK.lst `date +$EXE_DIR/Lancia_HK_%y%m%d%H%M`.lst
        echo "Elaborazione corrente non terminata correttamente vedere Lancia_HK_*.lst">>$ERR_FILE
        echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
        exit 1
else
       grep Errore Lancia_HK.lst > /dev/null
       if [ $? = "0" ]
       then
       mv $EXE_DIR/Lancia_HK.lst `date +$EXE_DIR/Lancia_HK_%y%m%d%H%M`.lst
       echo "Elaborazione corrente non terminata correttamente vedere Lancia_HK_*.lst">>$ERR_FILE
       echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       exit 1
       fi
      grep ORA Lancia_HK.lst > /dev/null
      if [ $? = "0" ]
      then
       mv $EXE_DIR/Lancia_HK.lst `date +$EXE_DIR/Lancia_HK_%y%m%d%H%M`.lst
       echo "Elaborazione corrente non terminata correttamente vedere Lancia_HK_*.lst">>$ERR_FILE
       echo "Elaborazione corrente non terminata correttamente vedere $ERR_FILE">>$OUT_FILE
       exit 1
       fi
fi


echo "Elaborazione Housekeeping terminata correttamente" >>$OUT_FILE
exit 0

