set timing on
spool Lancia_Stats_Itrs

select to_char(sysdate,'dd/mm/yyyy hh24:mi:ss') from dual
/

exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'ASPNET_USERS',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'ASPNET_USERSINROLES',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'CONNESSIONIATTIVECOA',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'ELENCO_PARTIZIONI',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'EVENTIDASEGNALARE',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'IMMAGINI',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'IMMAGINISUEVENTO',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'LTBIANCHE',estimate_percent=>10,block_sample=>true,cascade=>true)
-- exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'LTS_A1',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'LTS_A2',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'LTS_BC',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'SORVEGLIANZARES',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'SORVEGLIANZARESCOUNT',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'ASPNET_USERPROFILE',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'USERLOG',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'NAZIONI',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'QJOBS',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'SEGNALAZIONI',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'TEMPI_SOSTA_C2P',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'TEMPI_VELOC_PERCORR_DIREZ',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'TEMPI_VELOC_PERCORR_TRATTA',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'TRANSITI',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'TRANSITIEVENTI',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'TRANSITISUEVENTO',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'VOL_TRAFF_DIREZ',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'VOL_TRAFF_TRATTA',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'ASPNET_ROLES',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'C2P',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'COA',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'MODIDISEGNALAZIONE',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'PARAMETRI',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'QJOBTYPES',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'STRADE',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'TRATTE',estimate_percent=>100,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'INDAGINI_EVENTI',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'INDAGINI_TRANSITI',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'QJOBSRES_INTERVENTI',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'QJOBS_INTERVENTI',estimate_percent=>10,block_sample=>true,cascade=>true)
exec dbms_stats.gather_table_stats(ownname=>'ITRS',tabname=>'SMLOG',estimate_percent=>10,block_sample=>true,cascade=>true)

select to_char(sysdate,'dd/mm/yyyy hh24:mi:ss') from dual
/

spool off

exit;

