#!/bin/sh

echo cleaning log files older than 10 days
find $RUNTIME_DIR -name \*.log.\* -ctime +10 -exec rm {} \;
find /home/itrs/itrsas/db/scripts -name Lancia_\*.lst -ctime +10 -exec rm {} \;

# find -name STD_\*.txt -ctime +10 -exec ls -l {} \;

