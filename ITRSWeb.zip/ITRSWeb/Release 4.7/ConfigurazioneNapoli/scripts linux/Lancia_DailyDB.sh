#!/bin/sh

#su - itrs
#cd ~itrs/itrsas/db/scripts

alias stato='/app/itrs/srvlib/bin/SYU_wdshell'

cd ~/itrsas/db/scripts
echo -n ">> running Lancia_HK.sh at " >> ./cronlog.txt
date >> ./cronlog.txt
./Lancia_HK.sh
echo -n "-- running Lancia_Comp_Anom_Stats_PurgeTab.sh at " >> ./cronlog.txt
date >> ./cronlog.txt
./Lancia_Comp_Anom_Stats_PurgeTab.sh
echo -n "-- running Log_Cleaner.sh at " >> ./cronlog.txt
date >> ./cronlog.txt
./Log_Cleaner.sh >> ./cronlog.txt
echo -n "<< Lancia_HK.sh done at " >> ./cronlog.txt
date >> ./cronlog.txt

