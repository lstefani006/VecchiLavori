
select 'EVENTIDASEGNALARE' , R.* from
(
select count(*) N, trunc(DATAORAINSERIMENTO) D from EVENTIDASEGNALARE
group by trunc(DATAORAINSERIMENTO) 
)R order by R.D


select 'TRANSITISUEVENTO' , R.* from
(
select count(*) N, trunc(DATAORAINSERIMENTO) D from TRANSITISUEVENTO
group by trunc(DATAORAINSERIMENTO) 
)R order by R.D

select 'TRANSITI' , R.* from
(
select count(*) N, trunc(DATAORAINSERIMENTO) D from TRANSITI
group by trunc(DATAORAINSERIMENTO) 
)R order by R.D
