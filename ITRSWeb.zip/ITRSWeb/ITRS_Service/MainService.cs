using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.Runtime.Remoting;


namespace ITRS_Service
{
	public partial class MainService : ServiceBase
	{
		public MainService()
		{
			InitializeComponent();
		}

		protected override void OnStart(string[] args)
		{
			ITRS_BL.ServerItems.StartServer();
		}

		protected override void OnStop()
		{
			ITRS_BL.ServerItems.StopServer();
		}
	}
}
