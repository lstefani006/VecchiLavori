using System;
using System.Collections.Generic;
using System.ServiceProcess;
using System.Text;

namespace ITRS_Service
{
	static class Program
	{
        [MTAThread]
		static void Main()
		{
			string[] args = Environment.GetCommandLineArgs();
			if (args.Length >= 2 && args[1] == "-debug")
			{
				DebugMain(args);
			}
			else
			{
				ServiceBase[] ServicesToRun;
				ServicesToRun = new ServiceBase[] { new MainService() };
				ServiceBase.Run(ServicesToRun);
			}
		}

		private static void DebugMain(string [] args)
		{
			if (args.Length >= 3 && args[2] == "-genova")
			{
				PutEnv("PuTTY.host", "172.31.11.31");
				PutEnv("PuTTY.login", "leo");
				PutEnv("PuTTY.pwd", "spectrum");
			}

			ITRS_BL.ServerItems.StartServer();
			System.Threading.Thread.Sleep(1000 * 3600 * 365); // 1 anno
			ITRS_BL.ServerItems.StopServer();
		}

		static void PutEnv(string k, string v)
		{
			k = k.Replace('.', '_');
			Environment.SetEnvironmentVariable(k, v);
		}

	}
}