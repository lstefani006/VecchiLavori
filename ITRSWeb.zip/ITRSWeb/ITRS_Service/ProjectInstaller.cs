using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;

namespace ITRS_Service
{
	[RunInstaller(true)]
	public partial class ProjectInstaller : Installer
	{
		public ProjectInstaller()
		{
			InitializeComponent();

			this.serviceProcessInstaller1.Account = System.ServiceProcess.ServiceAccount.LocalSystem;

			this.AfterInstall += ProjectInstaller_AfterInstall;
		}

		void ProjectInstaller_AfterInstall(object sender, InstallEventArgs e)
		{
			using (ScmWrapper.ServiceControlManager scm = new ScmWrapper.ServiceControlManager())
			{
				scm.SetRestartOnFailure(this.serviceInstaller1.ServiceName, 3600 * 24, 2 * 60);
			}
		}
	}
}