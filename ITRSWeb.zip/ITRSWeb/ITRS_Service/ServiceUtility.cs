using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace ScmWrapper
{
	/*
	class _
	{
		static void Main()
		{
			using (ServiceControlManager scm = new ServiceControlManager())
			{
				scm.SetRestartOnFailure("ITRS_Service", 3600 * 24, 2 * 60);
				scm.HasRestartOnFailure("ITRS_Service");
			}
		}
	}
	*/


	#region Win32 API Declarations

	[Flags]
	enum ServiceControlAccessRights : int
	{
		SC_MANAGER_CONNECT = 0x0001, // Required to connect to the service control manager. 
		SC_MANAGER_CREATE_SERVICE = 0x0002, // Required to call the CreateService function to create a service object and add it to the database. 
		SC_MANAGER_ENUMERATE_SERVICE = 0x0004, // Required to call the EnumServicesStatusEx function to list the services that are in the database. 
		SC_MANAGER_LOCK = 0x0008, // Required to call the LockServiceDatabase function to acquire a lock on the database. 
		SC_MANAGER_QUERY_LOCK_STATUS = 0x0010, // Required to call the QueryServiceLockStatus function to retrieve the lock status information for the database
		SC_MANAGER_MODIFY_BOOT_CONFIG = 0x0020, // Required to call the NotifyBootConfigStatus function. 
		SC_MANAGER_ALL_ACCESS = 0xF003F // Includes STANDARD_RIGHTS_REQUIRED, in addition to all access rights in this table. 
	}

	[Flags]
	enum ServiceAccessRights : int
	{
		SERVICE_QUERY_CONFIG = 0x0001, // Required to call the QueryServiceConfig and QueryServiceConfig2 functions to query the service configuration. 
		SERVICE_CHANGE_CONFIG = 0x0002, // Required to call the ChangeServiceConfig or ChangeServiceConfig2 function to change the service configuration. Because this grants the caller the right to change the executable file that the system runs, it should be granted only to administrators. 
		SERVICE_QUERY_STATUS = 0x0004, // Required to call the QueryServiceStatusEx function to ask the service control manager about the status of the service. 
		SERVICE_ENUMERATE_DEPENDENTS = 0x0008, // Required to call the EnumDependentServices function to enumerate all the services dependent on the service. 
		SERVICE_START = 0x0010, // Required to call the StartService function to start the service. 
		SERVICE_STOP = 0x0020, // Required to call the ControlService function to stop the service. 
		SERVICE_PAUSE_CONTINUE = 0x0040, // Required to call the ControlService function to pause or continue the service. 
		SERVICE_INTERROGATE = 0x0080, // Required to call the ControlService function to ask the service to report its status immediately. 
		SERVICE_USER_DEFINED_CONTROL = 0x0100, // Required to call the ControlService function to specify a user-defined control code.
		SERVICE_ALL_ACCESS = 0xF01FF // Includes STANDARD_RIGHTS_REQUIRED in addition to all access rights in this table. 
	}

	enum ServiceConfig2InfoLevel : int
	{
		SERVICE_CONFIG_DESCRIPTION = 0x00000001, // The lpBuffer parameter is a pointer to a SERVICE_DESCRIPTION structure.
		SERVICE_CONFIG_FAILURE_ACTIONS = 0x00000002 // The lpBuffer parameter is a pointer to a SERVICE_FAILURE_ACTIONS structure.
	}

	enum SC_ACTION_TYPE : uint
	{
		SC_ACTION_NONE = 0x00000000, // No action.
		SC_ACTION_RESTART = 0x00000001, // Restart the service.
		SC_ACTION_REBOOT = 0x00000002, // Reboot the computer.
		SC_ACTION_RUN_COMMAND = 0x00000003 // Run a command.
	}

	struct SERVICE_FAILURE_ACTIONS
	{
		/// <summary>
		/// The time after which to reset the failure count to zero if there are no failures, in seconds
		/// </summary>
		[MarshalAs(UnmanagedType.U4)]
		public UInt32 dwResetPeriod;

		[MarshalAs(UnmanagedType.LPStr)]
		public String lpRebootMsg;
		[MarshalAs(UnmanagedType.LPStr)]
		public String lpCommand;

		[MarshalAs(UnmanagedType.U4)]
		public UInt32 cActions;
		public IntPtr lpsaActions;
	}

	struct SC_ACTION
	{
		[MarshalAs(UnmanagedType.U4)]
		public SC_ACTION_TYPE Type;
		[MarshalAs(UnmanagedType.U4)]
		public UInt32 Delay;
	}

	#endregion

	#region Native Methods

	static class NativeMethods
	{

		[DllImport("advapi32.dll", EntryPoint = "OpenSCManager")]
		public static extern IntPtr OpenSCManager(
			string machineName,
			string databaseName,
			ServiceControlAccessRights desiredAccess);

		[DllImport("advapi32.dll", EntryPoint = "CloseServiceHandle")]
		public static extern int CloseServiceHandle(IntPtr hSCObject);

		[DllImport("advapi32.dll", EntryPoint = "OpenService")]
		public static extern IntPtr OpenService(
			IntPtr hSCManager,
			string serviceName,
			ServiceAccessRights desiredAccess);

		[DllImport("advapi32.dll", EntryPoint = "QueryServiceConfig2")]
		public static extern int QueryServiceConfig2(
			IntPtr hService,
			ServiceConfig2InfoLevel dwInfoLevel,
			IntPtr lpBuffer,
			int cbBufSize,
			out int pcbBytesNeeded);

		[DllImport("advapi32.dll", EntryPoint = "ChangeServiceConfig2")]
		public static extern int ChangeServiceConfig2(
			IntPtr hService,
			ServiceConfig2InfoLevel dwInfoLevel,
			IntPtr lpInfo);
	}

	#endregion

	public class ServiceControlManager : IDisposable
	{
		private IntPtr _SCManager;
		private bool _disposed;

		/// <summary>
		/// Calls the Win32 OpenService function and performs error checking.
		/// </summary>
		/// <exception cref="ComponentModel.Win32Exception">"Unable to open the requested Service."</exception>
		private IntPtr OpenService(string serviceName, ServiceAccessRights desiredAccess)
		{
			// Open the service
			IntPtr service = NativeMethods.OpenService(
				_SCManager,
				serviceName,
				desiredAccess);

			// Verify if the service is opened
			if (service == IntPtr.Zero)
			{
				throw new Win32Exception(Marshal.GetLastWin32Error(), "Unable to open the requested Service.");
			}

			return service;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ServiceControlManager"/> class.
		/// </summary>
		/// <exception cref="ComponentModel.Win32Exception">"Unable to open Service Control Manager."</exception>
		[SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
		public ServiceControlManager()
		{
			// Open the service control manager
			_SCManager = NativeMethods.OpenSCManager(
				null,
				null,
				ServiceControlAccessRights.SC_MANAGER_CONNECT);

			// Verify if the SC is opened
			if (_SCManager == IntPtr.Zero)
			{
				throw new Win32Exception(Marshal.GetLastWin32Error(), "Unable to open Service Control Manager.");
			}
		}

		/// <summary>
		/// Dertermines whether the nominated service is set to restart on failure.
		/// </summary>
		/// <exception cref="ComponentModel.Win32Exception">"Unable to query the Service configuration."</exception>
		[SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
		public bool HasRestartOnFailure(string serviceName)
		{
			const int bufferSize = 1024 * 8;

			IntPtr service = IntPtr.Zero;
			IntPtr bufferPtr = IntPtr.Zero;
			bool result = false;

			try
			{
				// Open the service
				service = OpenService(serviceName, ServiceAccessRights.SERVICE_QUERY_CONFIG);

				int dwBytesNeeded = 0;

				// Allocate memory for struct
				bufferPtr = Marshal.AllocHGlobal(bufferSize);
				int queryResult = NativeMethods.QueryServiceConfig2(
					service,
					ServiceConfig2InfoLevel.SERVICE_CONFIG_FAILURE_ACTIONS,
					bufferPtr,
					bufferSize,
					out dwBytesNeeded);

				if (queryResult == 0)
				{
					throw new Win32Exception(Marshal.GetLastWin32Error(), "Unable to query the Service configuration.");
				}

				// Cast the buffer to a QUERY_SERVICE_CONFIG struct
				SERVICE_FAILURE_ACTIONS config =
					(SERVICE_FAILURE_ACTIONS)Marshal.PtrToStructure(bufferPtr, typeof(SERVICE_FAILURE_ACTIONS));

				// Determine whether the service is set to auto restart
				if (config.cActions >= 1)
				{
					SC_ACTION action1 = (SC_ACTION)Marshal.PtrToStructure(PtrIndex(config.lpsaActions, 0), typeof(SC_ACTION));
					bool result1 = (action1.Type == SC_ACTION_TYPE.SC_ACTION_RESTART);
					result = result1;

					if (config.cActions >= 2)
					{
						SC_ACTION action2 = (SC_ACTION)Marshal.PtrToStructure(PtrIndex(config.lpsaActions, 1), typeof(SC_ACTION));
						bool result2 = (action2.Type == SC_ACTION_TYPE.SC_ACTION_RESTART);

						if (config.cActions >= 3)
						{
							SC_ACTION action3 = (SC_ACTION)Marshal.PtrToStructure(PtrIndex(config.lpsaActions, 2), typeof(SC_ACTION));
							bool result3 = (action3.Type == SC_ACTION_TYPE.SC_ACTION_RESTART);
						}
					}
				}

				return result;
			}
			finally
			{
				// Clean up
				if (bufferPtr != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(bufferPtr);
					bufferPtr = IntPtr.Zero;
				}

				if (service != IntPtr.Zero)
				{
					NativeMethods.CloseServiceHandle(service);
					service = IntPtr.Zero;
				}
			}
		}

		/// <summary>
		/// Sets the nominated service to restart on failure.
		/// </summary>
		[SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
		public void SetRestartOnFailure(string serviceName, int ResePeriodSec, int delayActionSec)
		{
			// The time after which to reset the failure count to zero if there are no failures, in seconds
			uint ResetPeriod = (uint)(ResePeriodSec);

			uint delayFirstFailure = (uint)(delayActionSec * 1000);
			uint delaySecondFailure = (uint)(delayActionSec * 1000);
			uint delaySubsequentFailures = (uint)(delayActionSec * 1000);

			const int actionCount = 3;
			IntPtr service = IntPtr.Zero;
			IntPtr failureActionsPtr = IntPtr.Zero;
			IntPtr actionPtr = IntPtr.Zero;

			try
			{
				// Open the service
				service = OpenService(serviceName,
					ServiceAccessRights.SERVICE_CHANGE_CONFIG |
					ServiceAccessRights.SERVICE_START);

				// Allocate memory for the individual actions
				actionPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(SC_ACTION)) * actionCount);

				// Set up the restart action - First Failure
				SC_ACTION action1 = new SC_ACTION();
				action1.Type = delayFirstFailure == 0 ? SC_ACTION_TYPE.SC_ACTION_NONE : SC_ACTION_TYPE.SC_ACTION_RESTART;
				action1.Delay = delayFirstFailure;
				Marshal.StructureToPtr(action1, PtrIndex(actionPtr, 0), false);

				// Set up the "restart" action - Second Failure
				SC_ACTION action2 = new SC_ACTION();
				action2.Type = delaySecondFailure == 0 ? SC_ACTION_TYPE.SC_ACTION_NONE : SC_ACTION_TYPE.SC_ACTION_RESTART;
				action2.Delay = delaySecondFailure;
				Marshal.StructureToPtr(action2, PtrIndex(actionPtr, 1), false);

				// Set up the "restart" action - Subsequent failure
				SC_ACTION action3 = new SC_ACTION();
				action3.Type = delaySubsequentFailures == 0 ? SC_ACTION_TYPE.SC_ACTION_NONE : SC_ACTION_TYPE.SC_ACTION_RESTART;
				action3.Delay = delaySubsequentFailures;
				Marshal.StructureToPtr(action3, PtrIndex(actionPtr, 2), false);

				// Set up the failure actions
				SERVICE_FAILURE_ACTIONS failureActions = new SERVICE_FAILURE_ACTIONS();
				failureActions.dwResetPeriod = ResetPeriod;
				failureActions.cActions = actionCount;
				failureActions.lpsaActions = actionPtr;
				failureActions.lpCommand = null;
				failureActions.lpRebootMsg = null;

				failureActionsPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(SERVICE_FAILURE_ACTIONS)));
				Marshal.StructureToPtr(failureActions, failureActionsPtr, false);

				// Make the change
				int changeResult = NativeMethods.ChangeServiceConfig2(
					service,
					ServiceConfig2InfoLevel.SERVICE_CONFIG_FAILURE_ACTIONS,
					failureActionsPtr);

				// Check that the change occurred
				if (changeResult == 0)
					throw new Win32Exception(Marshal.GetLastWin32Error(), "Unable to change the Service configuration.");
			}
			finally
			{
				// Clean up
				if (failureActionsPtr != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(failureActionsPtr);
					failureActionsPtr = IntPtr.Zero;
				}

				if (actionPtr != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(actionPtr);
					actionPtr = IntPtr.Zero;
				}

				if (service != IntPtr.Zero)
				{
					NativeMethods.CloseServiceHandle(service);
					service = IntPtr.Zero;
				}
			}
		}

		private static IntPtr PtrIndex(IntPtr baseAddres, int idx)
		{
			IntPtr r = (IntPtr)((Int64)baseAddres + idx * Marshal.SizeOf(typeof(SC_ACTION)));
			return r;
		}

		#region IDisposable Members

		/// <summary>
		/// See <see cref="IDisposable.Dispose"/>.
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Implements the Dispose(bool) pattern outlined by MSDN and enforced by FxCop.
		/// </summary>
		private void Dispose(bool disposing)
		{
			if (!this._disposed)
			{
				if (disposing)
				{
					// Dispose managed resources here
				}

				// Unmanaged resources always need disposing
				if (_SCManager != IntPtr.Zero)
				{
					NativeMethods.CloseServiceHandle(_SCManager);
					_SCManager = IntPtr.Zero;
				}
			}
			_disposed = true;
		}

		/// <summary>
		/// Finalizer for the <see cref="ServiceControlManager"/> class.
		/// </summary>
		~ServiceControlManager()
		{
			Dispose(false);
		}

		#endregion
	}
}