using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:TargaValidator runat=server></{0}:TargaValidator>")]
	public class TargaValidator : CustomValidator
	{
		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			base.
		}

		string s = @"";


		protected override void OnLoad(EventArgs e)
		{
		}

	}
}
