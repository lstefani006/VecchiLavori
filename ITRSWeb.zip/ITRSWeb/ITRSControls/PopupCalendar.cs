using System;
using System.IO;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace ITRSControls
{
	[DefaultProperty("IDText")]
	[ToolboxData("<{0}:PopupCalendar runat=server></{0}:PopupCalendar>")]
	[ValidationPropertyAttribute("Text")]
	public class PopupCalendar : WebControl, INamingContainer 
	{
		[Bindable(true), Category("Behavior"), DefaultValue("False"), Themeable(true)]
		public bool UseDIV
		{
			get { return ReadViewStateProperty("UseDIV", false); }
			set { WriteViewStateProperty("UseDIV", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseRequiredValidator
		{
			get { return ReadViewStateProperty("rq", false); }
			set { WriteViewStateProperty("rq", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseRangeValidator
		{
			get { return ReadViewStateProperty("rv", false); }
			set { WriteViewStateProperty("rv", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("9999/12/31")]
		public string RangeValidator_MaximumValue
		{
			get { return ReadViewStateProperty("rv_MaximumValue", "9999/12/31"); }
			set { WriteViewStateProperty("rv_MaximumValue", value); }
		}
		[Bindable(true), Category("Behavior"), DefaultValue("2000/1/1")]
		public string RangeValidator_MinimumValue
		{
			get { return ReadViewStateProperty("rv_MinimumValue", "2000/1/1"); }
			set { WriteViewStateProperty("rv_MinimumValue", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("Date")]
		public ValidationDataType RangeValidator_Type
		{
			get { return ReadViewStateProperty("rv_Type", ValidationDataType.Date); }
			set { WriteViewStateProperty("rv_Type", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("Range error on field.")]
		public string RangeValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("rv_ErrorMessage", "Range error on field."); }
			set { WriteViewStateProperty("rv_ErrorMessage", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("Required field.")]
		public string RequiredValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("rq_ErrorMessage", "Required field."); }
			set { WriteViewStateProperty("rq_ErrorMessage", value); }
		}

		[Bindable(true), Category("Layout"), Themeable(true)]
		[DefaultValue(typeof(Unit), "")]
		public Unit TextWidth
		{
			get { return ReadViewStateProperty("TextWidth", new Unit()); }
			set { WriteViewStateProperty("TextWidth", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(true)]
		public string ImagePath
		{
			get { return ReadViewStateProperty("ImagePath", string.Empty); }
			set { WriteViewStateProperty("ImagePath", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(true)]
		public string ScriptPath
		{
			get { return ReadViewStateProperty("ScriptPath", string.Empty); }
			set { WriteViewStateProperty("ScriptPath", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public DateTime? SelectedDate
		{
			get
			{
				EnsureChildControls();
				_SelectedDate = null;
				if (_t.Text != null && _t.Text != "")
					_SelectedDate = DateTime.Parse(_t.Text);	
				return _SelectedDate;			
			}
			set
			{
				EnsureChildControls(); 
				_SelectedDate = value;
				if (_SelectedDate.HasValue)
				{
					DateTime dt = (DateTime)_SelectedDate;
					_t.Text = dt.ToString("d");
				}
				else _t.Text = "";
			}
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public DateTime? VisibleDate
		{
			get
			{
				EnsureChildControls();
				if (_t.Text != null && _t.Text != "")
					_VisibleDate = DateTime.Parse(_t.Text);
				return _VisibleDate;
			}
			set
			{
				EnsureChildControls();
				_VisibleDate = value;
				if (_VisibleDate != null)
				{
					DateTime dt = (DateTime)_VisibleDate;
					_t.Text = dt.ToString("d");
				}
			}
		
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string Text
		{
			get
			{
				EnsureChildControls();
				return _t.Text;
			}
			set
			{
				EnsureChildControls();
				_t.Text = value;
			}
		}


		[Bindable(true), Themeable(true), Category("Appearance"), DefaultValue("Yellow")]
		public Color Validators_BackColor
		{
			get { return ReadViewStateProperty("Validators_BackColor", Color.Yellow); }
			set { WriteViewStateProperty("Validators_BackColor", value); }
		}

		[Themeable(true), Bindable(true), Category("Appearance"), DefaultValue("Red")]
		public Color Validators_ForeColor
		{
			get { return ReadViewStateProperty("Validators_ForeColor", Color.Red); }
			set { WriteViewStateProperty("Validators_ForeColor", value); }
		}


		[Themeable(true), Bindable(true), Category("Appearance"), DefaultValue("Black")]
		public Color Validators_BorderColor
		{
			get { return ReadViewStateProperty("Validators_BorderColor", Color.Black); }
			set { WriteViewStateProperty("Validators_BorderColor", value); }
		}

		[Themeable(true), Bindable(true), Category("Appearance"), DefaultValue("Solid")]
		public BorderStyle Validators_BorderStyle
		{
			get { return ReadViewStateProperty("Validators_BorderStyle", BorderStyle.Solid); }
			set { WriteViewStateProperty("Validators_BorderStyle", value); }
		}

		[Themeable(true), Bindable(true), DefaultValue(typeof(Unit), "1px"), Category("Appearance")]
		public Unit Validators_BorderWidth
		{
			get { return ReadViewStateProperty("Validators_BorderWidth", new Unit(1, UnitType.Pixel)); }
			set { WriteViewStateProperty("Validators_BorderWidth", value); }
		}

		[Themeable(true), Bindable(true), DefaultValue(typeof(Unit), "2px"), Category("Appearance")]
		public Unit Validators_Padding
		{
			get { return ReadViewStateProperty("Validators_Padding", new Unit(2, UnitType.Pixel)); }
			set { WriteViewStateProperty("Validators_Padding", value); }
		}


		protected override void OnPreRender(System.EventArgs e)
		{
			base.OnPreRender(e);

			ClientScriptManager csm = this.Page.ClientScript;

			if (ScriptPath.Length > 0)
			{
				if (!csm.IsClientScriptIncludeRegistered("PopupCalendar_scripts_Start"))
				{
					string s = this.ScriptPath;
					csm.RegisterClientScriptInclude("PopupCalendar_scripts_Start", s);
				}
			}
			else
			{
				if (!csm.IsClientScriptBlockRegistered("PopupCalendar_scripts_Start"))
				{
					string resName = "RSControls.PopupCalendar.js";
					Stream stream = this.GetType().Assembly.GetManifestResourceStream(resName);
					StreamReader rdr = new StreamReader(stream);
					string scriptStr =
							"\r\n<script language=\"javascript\">\r\n" +
							rdr.ReadToEnd() +
							"\r\n</script>";
					rdr.Close();
					stream.Close();
					csm.RegisterClientScriptBlock(this.GetType(), "PopupCalendar_scripts_Start", scriptStr);
				}
			}


			if (!csm.IsClientScriptBlockRegistered("PopupCalendar_scripts"))
			{
				string nl = Environment.NewLine;
				string s = string.Empty;

				if (UseDIV)
					s += "var cal = new CalendarPopup('PopupCalendar_Div');" + nl;
				else
					s += "var cal = new CalendarPopup();" + nl;
					
				if ((CultureInfo.CurrentCulture.Name.ToUpper() == "IT-IT"))
				{
					s += "cal.setWeekStartDay(1); // week is Monday - Saturday" + nl;
					s += "cal.setMonthNames(\"Gennaio\", \"Febbraio\", \"Marzo\", \"Aprile\", \"Maggio\", \"Giugno\", \"Luglio\", \"Agosto\", \"Settembre\", \"Ottobre\", \"Novembre\", \"Dicembre\");" + nl;
					s += "cal.setDayHeaders(\"D\",\"L\",\"M\", \"m\", \"G\", \"V\", \"S\");" + nl;
					s += "cal.setTodayText(\"Oggi\");" + nl;
				}
				s += "cal.showNavigationDropdowns();" + nl;
				s += "cal.setCssPrefix('PopupCalendar');" + nl;
				s += @"

// ritorna la data togliendo l'eventuale ora
function estraiData(arg)
{
	var av = arg.split(/[ \/:.]/);
	var DD = av[0];
	var MM = av[1];
	var YYYY = av[2];
	var HH = av[3];
	var MI = av[4];
	var SS = av[5];

	var ts = new Date(YYYY, MM - 1, DD, 0, 0, 0);
	if (
		ts.getDate()     != DD     ||
		ts.getMonth()    != MM - 1 ||
		ts.getFullYear() != YYYY 
	   )
	{
		return null;
	}
	
	DD = ts.getDate();
	MM = ts.getMonth() + 1;
	YYYY = ts.getFullYear();
	
	if (DD < 10) DD = '0' + DD;
	if (MM < 10) MM = '0' + MM;

	var r = DD + '/' + MM + '/' + YYYY;
	return r;
}
";
				csm.RegisterClientScriptBlock(this.GetType(), "PopupCalendar_scripts", s, true);
			}

			this.EnsureChildControls();


			if (!csm.IsClientScriptBlockRegistered("PopupCalendar_scripts_" + this.ClientID))
			{
				string gg = @"
function returnCalFunction_{0}(y,m,d)
{
	if (d < 10) d = '0' + d;	
	if (m < 10) m = '0' + m;	
	var nuovaData = d + '/' + m + '/' + y;

	var c = document.getElementById('{0}');

	var arg = c.value;
	var av   = arg.split(/[ \/:.]/);
	var DD   = av[0];
	var MM   = av[1];
	var YYYY = av[2];
	var HH   = av[3];
	var MI   = av[4];
	var SS   = av[5];

	var ts = new Date(YYYY, MM - 1, DD, HH, MM, SS);
	if (
		ts.getDate()     != DD     ||
		ts.getMonth()    != MM - 1 ||
		ts.getFullYear() != YYYY   ||
		ts.getHours()    != HH     ||
		ts.getMinutes()  != MI     ||
		ts.getSeconds()  != SS
	   )
	{
		// non c'era un data valida - non riesco a capire l'ora --> metto 00.00.00 !
		c.value = nuovaData ; // + ' 00.00.00';
	}
	else
	{
		// recupero la vecchia ora
		if (HH < 10) HH = '0' + HH;
		if (MM < 10) MM = '0' + MM;
		if (SS < 10) SS = '0' + SS;

		c.value = nuovaData ; // + ' ' + HH + '.' + MM + '.' + SS;
	}
}
cal.setReturnFunction('returnCalFunction_{0}');
";
				gg = gg.Replace("{0}", _t.ClientID);
				csm.RegisterClientScriptBlock(this.GetType(), "PopupCalendar_scripts_" + this.ClientID, gg, true);
			}

		}



		protected override void CreateChildControls()
		{
			_t = new TextBox();
			_t.ID = "txtData";
			if (!this.TextWidth.IsEmpty)
			{
				this._t.Width = this.TextWidth;
			}
						
			this.Controls.Add(this._t);

			HtmlGenericControl g = new HtmlGenericControl();
			g.InnerHtml = "&nbsp;";
			this.Controls.Add(g);

			HtmlAnchor l = new HtmlAnchor();
			l.ID = "linkData";
			l.HRef = "#";

			HtmlImage img = new HtmlImage();
			if (string.IsNullOrEmpty(ImagePath))
				img.Src = "PopupCalendar/PopupCalendar.gif";
			else
				img.Src = this.ImagePath;

			img.Border = 0;
			l.Controls.Add(img);

			this.Controls.Add(l);

			string e = string.Format("document.getElementById('{0}')", _t.ClientID);
			string a = l.ClientID;
			string s;
			if ((CultureInfo.CurrentCulture.Name.ToUpper() == "IT-IT"))
				s = string.Format("cal.setReturnFunction('returnCalFunction_{2}'); cal.select({0}, '{1}', 'dd/MM/yyyy', estraiData({0}.value)); return false;", e, a, _t.ClientID);
			else
				s = string.Format("cal.setReturnFunction('returnCalFunction_{2}'); cal.select({0}, '{1}', 'MM/dd/yyyy'); return false;", e, a, _t.ClientID);
			l.Attributes["onclick"] = s;


			HtmlGenericControl divContainer = new HtmlGenericControl("span");
			divContainer.Style.Add(HtmlTextWriterStyle.Position, "relative");
			this.Controls.Add(divContainer);


			HtmlGenericControl div1 = new HtmlGenericControl("span");
			divContainer.Controls.Add(div1);

			HtmlGenericControl div2 = new HtmlGenericControl("span");
			divContainer.Controls.Add(div2);

			div1.Style.Add(HtmlTextWriterStyle.Position, "absolute");
			div2.Style.Add(HtmlTextWriterStyle.Position, "absolute");

			div1.Style.Add(HtmlTextWriterStyle.Left, "5px");
			div2.Style.Add(HtmlTextWriterStyle.Left, "5px");

			if (UseRequiredValidator)
			{
				HtmlGenericControl g2 = new HtmlGenericControl();
				g2.InnerHtml = "&nbsp;";
				this.Controls.Add(g2);

				RequiredFieldValidator _reqVal = new RequiredFieldValidator();

				_reqVal.ControlToValidate = "txtData";
				_reqVal.ErrorMessage = this.RequiredValidator_ErrorMessage;
				_reqVal.BackColor = this.Validators_BackColor;
				_reqVal.ForeColor = this.Validators_ForeColor;
				_reqVal.BorderColor = this.Validators_BorderColor;
				_reqVal.BorderStyle = this.Validators_BorderStyle;
				_reqVal.BorderWidth = this.Validators_BorderWidth;
				if (!this.Validators_Padding.IsEmpty)
					_reqVal.Style.Add(HtmlTextWriterStyle.Padding, this.Validators_Padding.ToString());


				div1.Controls.Add(_reqVal);
			}

			if (UseRangeValidator)
			{
				HtmlGenericControl g2 = new HtmlGenericControl();
				g2.InnerHtml = "&nbsp;";
				this.Controls.Add(g2);

				RangeValidator _rangeVal = new RangeValidator();

				_rangeVal.ControlToValidate = "txtData";
				_rangeVal.Type = ValidationDataType.Date;
				_rangeVal.EnableTheming = false;
				_rangeVal.ErrorMessage = this.RangeValidator_ErrorMessage;
				_rangeVal.Type = this.RangeValidator_Type;
				_rangeVal.MaximumValue = this.RangeValidator_MaximumValue;
				_rangeVal.MinimumValue = this.RangeValidator_MinimumValue;
				_rangeVal.CultureInvariantValues = true;
				_rangeVal.Enabled = this.UseRangeValidator;
				_rangeVal.BackColor = this.Validators_BackColor;
				_rangeVal.ForeColor = this.Validators_ForeColor;
				_rangeVal.BorderColor = this.Validators_BorderColor;
				_rangeVal.BorderStyle = this.Validators_BorderStyle;
				_rangeVal.BorderWidth = this.Validators_BorderWidth;
				if (!this.Validators_Padding.IsEmpty)
					_rangeVal.Style.Add(HtmlTextWriterStyle.Padding, this.Validators_Padding.ToString());

				div2.Controls.Add(_rangeVal);
			}

			base.CreateChildControls();

			this.ChildControlsCreated = true;
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			if (this.DesignMode)
				this.EnsureChildControls();

			this.Page.RegisterRequiresControlState(this);
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			EnsureChildControls();
		}

		TextBox _t;
		DateTime? _SelectedDate; // l'ultima data selezionata
		DateTime? _VisibleDate;  // l'ultima data visibile

		private T ReadViewStateProperty<T>(string key, T defValue)
		{
			object obj = ViewState[key];
			if (obj != null) return (T)obj;
			return defValue;
		}

		private void WriteViewStateProperty<T>(string key, T value)
		{
			base.ViewState[key] = value;
		}

	}
}
