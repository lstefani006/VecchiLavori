using System;
using System.Web;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Text;

namespace ITRSControls
{
	public class TextBoxWithValidatorField : DataControlField
	{
		#region Private properties
		private bool _inInsertMode;
		#endregion

		#region Custom properties
		public virtual string DataFormatString
		{
			get { return ReadViewStateProperty("DataFormatString", string.Empty); }
			set { WriteViewStateProperty("DataFormatString", value); }
		}

		public virtual bool ConvertEmptyStringToNull
		{
			get { return ReadViewStateProperty("ConvertEmptyStringToNull", false); }
			set { WriteViewStateProperty("ConvertEmptyStringToNull", value); }
		}

		public virtual bool HtmlEncode
		{
			get { return ReadViewStateProperty("HtmlEncode", true); }
			set { WriteViewStateProperty("HtmlEncode", value); }
		}
		public virtual string NullDisplayText
		{
			get { return ReadViewStateProperty("NullDisplayText", ""); }
			set { WriteViewStateProperty("NullDisplayText", value); }
		}

		public virtual bool ApplyFormatInEditMode
		{
			get { return ReadViewStateProperty("ApplyFormatInEditMode", true); }
			set { WriteViewStateProperty("ApplyFormatInEditMode", value); }
		}

		// *******************************************************************
		// PROPERTY: DataField
		// Indicates the field providing the date in view mode
		public virtual string DataField
		{
			get { return ReadViewStateProperty("DataField", string.Empty); }
			set { WriteViewStateProperty("DataField", value); }
		}

		// *******************************************************************
		// PROPERTY: ReadOnly
		// Indicates the field from which the text of the drop-down items is taken
		public virtual bool ReadOnly
		{
			get { return ReadViewStateProperty("ReadOnly", false); }
			set { WriteViewStateProperty("ReadOnly", value); }
		}

		//[Bindable(true), Category("Appearance"), DefaultValue("")]
		public Unit TextWidth
		{
			get { return ReadViewStateProperty("TextWidth", new Unit()); }
			set { WriteViewStateProperty("TextWidth", value); }
		}

		public Unit Validators_Width
		{
			get { return ReadViewStateProperty("Validators_Width", new Unit()); }
			set { WriteViewStateProperty("Validators_Width", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseRequiredValidator
		{
			get { return ReadViewStateProperty("rq", false); }
			set { WriteViewStateProperty("rq", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseRangeValidator
		{
			get { return ReadViewStateProperty("rv", false); }
			set { WriteViewStateProperty("rv", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string ValidationGroup
		{
			get { return ReadViewStateProperty("ValidationGroup", ""); }
			set { WriteViewStateProperty("ValidationGroup", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string RangeValidator_MaximumValue
		{
			get { return ReadViewStateProperty("rv_MaximumValue", ""); }
			set { WriteViewStateProperty("rv_MaximumValue", value); }
		}
		//[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string RangeValidator_MinimumValue
		{
			get { return ReadViewStateProperty("rv_MinimumValue", ""); }
			set { WriteViewStateProperty("rv_MinimumValue", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("String")]
		public ValidationDataType Type
		{
			get { return ReadViewStateProperty("Type", ValidationDataType.String); }
			set { WriteViewStateProperty("Type", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("Range error on field")]
		public string RangeValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("rv_ErrorMessage", "Range error on field"); }
			set { WriteViewStateProperty("rv_ErrorMessage", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("Required field")]
		public string RequiredValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("rq_ErrorMessage", "Required field"); }
			set { WriteViewStateProperty("rq_ErrorMessage", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseRegularExpressionValidator
		{
			get { return ReadViewStateProperty("rev", false); }
			set { WriteViewStateProperty("rev", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("Required field")]
		public string RegularExpressionValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("rev_ErrorMessage", "Required field"); }
			set { WriteViewStateProperty("rev_ErrorMessage", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("String")]
		public string RegularExpressionValidator_ValidationExpression
		{
			get { return ReadViewStateProperty("rev_ValidationExpression", ""); }
			set { WriteViewStateProperty("rev_ValidationExpression", value); }
		}


		//[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseCompareValidator
		{
			get { return ReadViewStateProperty("cv", false); }
			set { WriteViewStateProperty("cv", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("Comparison check failed.")]
		public string CompareValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("cv_ErrorMessage", "Comparison check failed."); }
			set { WriteViewStateProperty("cv_ErrorMessage", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("String")]
		public ValidationCompareOperator CompareValidator_Operator
		{
			get { return ReadViewStateProperty("cv_Operator", ValidationCompareOperator.DataTypeCheck); }
			set { WriteViewStateProperty("cv_Operator", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("String")]
		public string CompareValidator_ValueToCompare
		{
			get { return ReadViewStateProperty("cv_ValueToCompare", ""); }
			set { WriteViewStateProperty("cv_ValueToCompare", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseCustomValidator
		{
			get { return ReadViewStateProperty("cm", false); }
			set { WriteViewStateProperty("cm", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("String")]
		public string CustomValidator_ClientValidationFunction
		{
			get { return ReadViewStateProperty("cm_ClientValidationFunction", ""); }
			set { WriteViewStateProperty("cm_ClientValidationFunction", value); }
		}

		//[Bindable(true), Category("Behavior"), DefaultValue("String")]
		public string CustomValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("cm_ErrorMessage", ""); }
			set { WriteViewStateProperty("cm_ErrorMessage", value); }
		}

		private T ReadViewStateProperty<T>(string key, T defValue)
		{
			object obj = ViewState[key];
			if (obj != null) return (T)obj;
			return defValue;
		}

		private void WriteViewStateProperty<T>(string key, T value)
		{
			base.ViewState[key] = value;
			OnFieldChanged();
		}

		#endregion

		#region Overridden methods
		// *******************************************************************
		// METHOD: CreateField
		// Must override because it is abstract on the base class
		protected override DataControlField CreateField()
		{
			return new TextBoxWithValidatorField();
		}

		// *******************************************************************
		// METHOD: ExtractValuesFromCell
		// Extract values from cell (presumably in edit mode)
		public override void ExtractValuesFromCell(IOrderedDictionary dictionary, DataControlFieldCell cell, DataControlRowState rowState, bool includeReadOnly)
		{
			object selectedValue = null;

			// entro qui se NON sono in Insert oppure se sono in insert ma InsertVisible
			if (((rowState & DataControlRowState.Insert) == DataControlRowState.Normal) 
				|| this.InsertVisible)
			{
				if (cell.Controls.Count > 0)
				{
					TextBoxWithValidator tv = cell.Controls[0] as TextBoxWithValidator;

					if (tv == null)
						throw new InvalidOperationException("TextBoxRequireValidatorField could not extract control.");

					selectedValue = tv.Text;
				}
				else if (includeReadOnly)
				{
					string str = cell.Text;
					if (str == "&nbsp;")
					{
						selectedValue = string.Empty;
					}
					else if (this.HtmlEncode)
					{
						selectedValue = HttpUtility.HtmlDecode(str);
					}
					else
					{
						selectedValue = str;
					}
				}


				if (selectedValue != null)
				{
					if (((selectedValue is string) && 
						(((string)selectedValue).Length == 0)) && 
						this.ConvertEmptyStringToNull)
					{
						selectedValue = null;
					}
					if (((selectedValue is string) && 
						(((string)selectedValue) == this.NullDisplayText)) && 
						(this.NullDisplayText.Length > 0))
					{
						selectedValue = null;
					}
					if (dictionary.Contains(DataField))
					{
						dictionary[DataField] = selectedValue;
					}
					else
					{
						dictionary.Add(DataField, selectedValue);
					}
				}
			}
		}

		// *******************************************************************
		// METHOD: CopyProperties
		//  
		protected override void CopyProperties(DataControlField newField)
		{
			TextBoxWithValidatorField cf = (TextBoxWithValidatorField)newField;

			cf.DataField = this.DataField;
			cf.ReadOnly = this.ReadOnly;

			cf.TextWidth = this.TextWidth;
			cf.Type = this.Type;
			cf.ConvertEmptyStringToNull = this.ConvertEmptyStringToNull;
			cf.HtmlEncode = this.HtmlEncode;
			cf.DataFormatString = this.DataFormatString;
			cf.NullDisplayText = this.NullDisplayText;
			cf.Validators_Width = this.Validators_Width;
			cf.UseRequiredValidator = this.UseRequiredValidator;
			cf.UseRangeValidator = this.UseRangeValidator;
			cf.UseRegularExpressionValidator = this.UseRegularExpressionValidator;
			cf.UseCompareValidator = this.UseCompareValidator;
			cf.RangeValidator_MaximumValue = this.RangeValidator_MaximumValue;
			cf.RangeValidator_MinimumValue = this.RangeValidator_MinimumValue;
			cf.RangeValidator_ErrorMessage = this.RangeValidator_ErrorMessage;
			cf.RequiredValidator_ErrorMessage = this.RequiredValidator_ErrorMessage;
			cf.RegularExpressionValidator_ErrorMessage = this.RegularExpressionValidator_ErrorMessage;
			cf.RegularExpressionValidator_ValidationExpression = this.RegularExpressionValidator_ValidationExpression;
			cf.CompareValidator_Operator = this.CompareValidator_Operator;
			cf.CompareValidator_ErrorMessage = this.CompareValidator_ErrorMessage;
			cf.CompareValidator_ValueToCompare = this.CompareValidator_ValueToCompare;
			cf.CustomValidator_ClientValidationFunction = this.CustomValidator_ClientValidationFunction;
			cf.CustomValidator_ErrorMessage = this.CustomValidator_ErrorMessage;
			cf.UseCustomValidator = this.UseCustomValidator;

			base.CopyProperties(cf);
		}

		// *******************************************************************
		// METHOD: InitializeCell
		// 
		public override void InitializeCell(DataControlFieldCell cell, DataControlCellType cellType, DataControlRowState rowState, int rowIndex)
		{
			// Call the base method
			base.InitializeCell(cell, cellType, rowState, rowIndex);

			// Initialize the contents of the cell quitting if it is a header/footer
			if (cellType == DataControlCellType.DataCell)
				InitializeDataCell(cell, rowState);
		}
		#endregion

		#region Custom methods
		// *******************************************************************
		// METHOD: InitializeDataCell
		// 
		protected virtual void InitializeDataCell(DataControlFieldCell cell, DataControlRowState rowState)
		{
			Control ctrl = null;

			// If we're in edit/insert mode...
			bool isInsertMode = (rowState & DataControlRowState.Insert) != 0;
			bool isEditMode = (rowState & DataControlRowState.Edit) != 0;

			if ((!ReadOnly && isEditMode) || isInsertMode)
			{
				TextBoxWithValidator tv = new TextBoxWithValidator();

				tv.TextWidth = this.TextWidth;
				tv.Type = this.Type;
				//tv.ConvertEmptyStringToNull = this.ConvertEmptyStringToNull;
				//tv.HtmlEncode = this.HtmlEncode;
				//tv.DataFormatString = this.DataFormatString;
				//tv.NullDisplayText = this.NullDisplayText;
				tv.Validators_Width = this.Validators_Width;
				tv.UseRequiredValidator = this.UseRequiredValidator;
				tv.UseRangeValidator = this.UseRangeValidator;
				tv.UseRegularExpressionValidator = this.UseRegularExpressionValidator;
				tv.UseCompareValidator = this.UseCompareValidator;
				tv.RangeValidator_MaximumValue = this.RangeValidator_MaximumValue;
				tv.RangeValidator_MinimumValue = this.RangeValidator_MinimumValue;
				tv.RangeValidator_ErrorMessage = this.RangeValidator_ErrorMessage;
				tv.RequiredValidator_ErrorMessage = this.RequiredValidator_ErrorMessage;
				tv.RegularExpressionValidator_ValidationExpression = this.RegularExpressionValidator_ValidationExpression;
				tv.RegularExpressionValidator_ErrorMessage = this.RegularExpressionValidator_ErrorMessage;
				tv.CompareValidator_Operator = this.CompareValidator_Operator;
				tv.CompareValidator_ErrorMessage = this.CompareValidator_ErrorMessage;
				tv.CompareValidator_ValueToCompare = this.CompareValidator_ValueToCompare;
				tv.CustomValidator_ClientValidationFunction = this.CustomValidator_ClientValidationFunction;
				tv.CustomValidator_ErrorMessage = this.CustomValidator_ErrorMessage;
				tv.ToolTip = this.HeaderText;
				tv.UseCustomValidator = this.UseCustomValidator;


				cell.Controls.Add(tv);

				// Save the control to use for binding (edit/insert mode)
				if (DataField.Length != 0)
					ctrl = tv;

				_inInsertMode = isInsertMode;
			}
			else if (DataField.Length != 0)
			{
				// Save the control to use for binding (view mode)
				ctrl = cell;
			}

			// If the column is visible, trigger the binding process
			if ((ctrl != null) && Visible)
			{
				ctrl.DataBinding += new EventHandler(this.OnBindingField);
			}
		}

		// *******************************************************************
		// METHOD: OnBindingField
		// 
		protected virtual void OnBindingField(object sender, EventArgs e)
		{
			Control target = (Control)sender;

			// If in view mode ...
			if (target is TableCell)
			{
				((TableCell)target).Text = LookupValueForView(target.NamingContainer);
			}
			else if (target is TextBoxWithValidator)
			{
				TextBoxWithValidator tv = (TextBoxWithValidator)target;
				string str = LookupValueForEdit(target.NamingContainer);
				tv.Text = str;
			}
		}

		// *******************************************************************
		// METHOD: LookupValueForEdit
		// 
		protected virtual string LookupValueForEdit(Control container)
		{
			if (container == null)
				throw new HttpException("No data bound container");

			// Get the data item object
			if (!_inInsertMode)
			{
				object dataItem = DataBinder.GetDataItem(container);
				object o = DataBinder.GetPropertyValue(dataItem, DataField);
				if (o == null)
					return this.NullDisplayText;

				if (string.IsNullOrEmpty(this.DataFormatString))
				{
					string r = o.ToString();
					if (r.Length == 0 && this.ConvertEmptyStringToNull)
						return this.NullDisplayText;
					return r;
				}
				else
				{
					string g = string.Format(this.DataFormatString, o);
					if (g.Length == 0 && this.ConvertEmptyStringToNull)
						return this.NullDisplayText;
					return g;
				}
			}
			return string.Empty;
		}

		// *******************************************************************
		// METHOD: LookupValueForView
		// 
		protected virtual string LookupValueForView(Control container)
		{
			if (container == null)
				throw new HttpException("No data bound container");

			// Take care of what's displayed at design-time
			if (DesignMode)
				return GetDesignTimeValue();

			// Get the data item object
			object dataItem = DataBinder.GetDataItem(container);
			object o = DataBinder.GetPropertyValue(dataItem, DataField);
			if (o == null)
				return this.NullDisplayText;

			if (string.IsNullOrEmpty(this.DataFormatString))
			{
				string r = o.ToString();
				if (r.Length == 0 && this.ConvertEmptyStringToNull)
					return this.NullDisplayText;
				return r;
			}
			else
			{
				string g = string.Format(this.DataFormatString, o);
				if (g.Length == 0 && this.ConvertEmptyStringToNull)
					return this.NullDisplayText;
				return g;
			}
		}


		// *******************************************************************
		// METHOD: GetDesignTimeValue
		// 
		protected virtual string GetDesignTimeValue()
		{
			return "<select><option>Databound Date</option></select>";
		}

		#endregion
	}
}
