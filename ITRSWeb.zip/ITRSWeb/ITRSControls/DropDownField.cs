using System;
using System.Web;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Text;

namespace ITRSControls
{
	/*
	 <expo:DropDownField 
	 	DataValueField="campoCodice" 
	    DataTextField="campoDescrizione"    
	    HeaderText="Posted by" 
        DataSourceIDForEdit="EmployeeDataSource" 
        DataValueFieldForEdit="campoCodice"
	    DataTextFieldForEdit="TestName" />
	*/
	public class DropDownField : DataControlField
	{
		#region Private properties
		private string _dataValue;
		private DropDownList _dropDown;
		private bool _inInsertMode;
		#endregion

		#region Custom properties
		// *******************************************************************
		// PROPERTY: DropDownControl
		// Returns the helper drop-down control used to edit values
		public virtual DropDownList DropDownControl
		{
			get
			{
				if (_dropDown == null)
					_dropDown = new DropDownList();
				return _dropDown;
			}
		}

		// *******************************************************************
		// PROPERTY: DataValueField
		// Indicates the field providing the value for the field in view mode
		public virtual string DataValueField
		{
			get
			{
				object o = this.ViewState["DataValueField"];
				if (o != null)
					return (string)o;
				return String.Empty;
			}
			set
			{
				ViewState["DataValueField"] = value;
				OnFieldChanged();
			}
		}

		// *******************************************************************
		// PROPERTY: DataTextField
		// Indicates the field providing the display text for the field in view mode.
		// This is useful only if the original query contains an inner join. No exception
		// is thrown if the field missing. In this case, the drop-down list will be created 
		// a little earlier and cached.
		public virtual string DataTextField
		{
			get
			{
				object o = this.ViewState["DataTextField"];
				if (o != null)
					return (string)o;
				return String.Empty;
			}
			set
			{
				ViewState["DataTextField"] = value;
				OnFieldChanged();
			}
		}

		// *******************************************************************
		// PROPERTY: ReadOnly
		// Indicates the field from which the text of the drop-down items is taken
		public virtual bool ReadOnly
		{
			get
			{
				object o = base.ViewState["ReadOnly"];
				if (o != null)
					return (bool)o;
				return false;
			}
			set
			{
				base.ViewState["ReadOnly"] = value;
				OnFieldChanged();
			}
		}

		// *******************************************************************
		// PROPERTY: DataSourceIDForEdit
		// Indicates the source for populating the drop-down list when in edit mode.
		// The drop-down list is created when the DetailsView enters in edit mode. It is 
		// created when the DetailsView is first displayed (in view mode) if there's no
		// inner joined field.
		public virtual string DataSourceIDForEdit
		{
			get
			{
				object o = this.ViewState["DataSourceIDForEdit"];
				if (o != null)
					return (string)o;
				return String.Empty;
			}
			set
			{
				this.ViewState["DataSourceIDForEdit"] = value;
				OnFieldChanged();
			}
		}

		// *******************************************************************
		// PROPERTY: DataValueFieldForEdit
		// Indicates the field from which the value of the drop-down items is taken when in edit mode
		public virtual string DataValueFieldForEdit
		{
			get
			{
				object o = this.ViewState["DataValueFieldForEdit"];
				if (o != null)
					return (string)o;
				return String.Empty;
			}
			set
			{
				ViewState["DataValueFieldForEdit"] = value;
				OnFieldChanged();
			}
		}

		// *******************************************************************
		// PROPERTY: DataTextFieldForEdit
		// Indicates the field from which the text of the drop-down items is taken when in edit mode
		public virtual string DataTextFieldForEdit
		{
			get
			{
				object o = this.ViewState["DataTextFieldForEdit"];
				if (o != null)
					return (string)o;
				return DataValueFieldForEdit;   // Defaults to the value field
			}
			set
			{
				ViewState["DataTextFieldForEdit"] = value;
				OnFieldChanged();
			}
		}


		public virtual bool AllowNull
		{
			get
			{
				object o = this.ViewState["AllowNull"];
				return (o != null) ? (bool)o : true ;
			}
			set
			{
				ViewState["AllowNull"] = value;
				OnFieldChanged();
			}
		}
		#endregion

		#region Overridden methods
		// *******************************************************************
		// METHOD: CreateField
		// Must override because it is abstract on the base class
		protected override DataControlField CreateField()
		{
			return new DropDownField();
		}

		// *******************************************************************
		// METHOD: ExtractValuesFromCell
		// Extract values from cell (presumably in edit mode)
		public override void ExtractValuesFromCell(IOrderedDictionary dictionary, DataControlFieldCell cell, DataControlRowState rowState, bool includeReadOnly)
		{
			// TODO LEO IMPORTANTE: manca la gestione del NULL da DB: 
			// quando dd.SelectedValue ritorna il valore assegnato a NULL bisogna inserire il NULL nel record.

			object selectedValue = null;
			if (cell.Controls.Count > 0)
			{
				DropDownList dd = cell.Controls[0] as DropDownList;

				if (dd == null)
					throw new InvalidOperationException("DropDownField could not extract control.");

				selectedValue = dd.SelectedValue;
				if (AllowNull && dd.SelectedValue == "")
					selectedValue = null;
			}


			// Add the value to the dictionary
			if (dictionary.Contains(DataValueField))
				dictionary[DataValueField] = selectedValue;
			else
				dictionary.Add(DataValueField, selectedValue);
		}

		// *******************************************************************
		// METHOD: CopyProperties
		// Copy specific properties to a given copy of the field type
		protected override void CopyProperties(DataControlField newField)
		{
			DropDownField ddf = (DropDownField)newField;

			ddf.DataValueField = this.DataValueField;
			ddf.DataTextField = this.DataTextField;
			ddf.DataSourceIDForEdit = this.DataSourceIDForEdit;
			ddf.DataValueFieldForEdit = this.DataValueFieldForEdit;
			ddf.DataTextFieldForEdit = this.DataTextFieldForEdit;
			ddf.ReadOnly = this.ReadOnly;

			base.CopyProperties(newField);
		}

		// *******************************************************************
		// METHOD: InitializeCell
		// 
		public override void InitializeCell(DataControlFieldCell cell, DataControlCellType cellType, DataControlRowState rowState, int rowIndex)
		{
			// Call the base method
			base.InitializeCell(cell, cellType, rowState, rowIndex);

			// Initialize the contents of the cell quitting if it is a header/footer
			if (cellType == DataControlCellType.DataCell)
				InitializeDataCell(cell, rowState);
		}
		#endregion

		#region Custom methods
		// *******************************************************************
		// METHOD: InitializeDataCell
		// 
		protected virtual void InitializeDataCell(DataControlFieldCell cell, DataControlRowState rowState)
		{
			Control ctrl = null;

			// If we're in edit/insert mode...
			bool isInsertMode = (rowState & DataControlRowState.Insert) != 0;
			bool isEditMode = (rowState & DataControlRowState.Edit) != 0;

			if ((!ReadOnly && isEditMode) || isInsertMode)
			{
				DropDownList dd = this.DropDownControl;
				dd.ToolTip = this.HeaderText;
				cell.Controls.Add(dd);

				// Save the control to use for binding (edit/insert mode)
				if ((DataValueFieldForEdit.Length != 0) &&
					(DataSourceIDForEdit.Length != 0))
					ctrl = dd;

				_inInsertMode = isInsertMode;
			}
			else if (DataValueField.Length != 0)
			{
				// Save the control to use for binding (view mode)
				ctrl = cell;
			}

			// If the column is visible, trigger the binding process
			if ((ctrl != null) && Visible)
			{
				ctrl.DataBinding += new EventHandler(this.OnBindingField);
			}
		}

		// *******************************************************************
		// METHOD: OnBindingField
		// 
		protected virtual void OnBindingField(object sender, EventArgs e)
		{
			Control target = (Control)sender;

			// If in view mode ...
			if (target is TableCell)
			{
				((TableCell)target).Text = LookupValueForView(target);
			}
			else if (target is DropDownList)
			{
				DropDownList dd = (DropDownList)target;
				if (!_inInsertMode)
				{
					_dataValue = LookupValueForEdit(target);
					dd.DataBound += new EventHandler(OnDropDownDataBound);
				}
				dd.DataTextField = this.DataTextFieldForEdit;
				dd.DataValueField = this.DataValueFieldForEdit;
				dd.DataSourceID = this.DataSourceIDForEdit;
			}
		}

		// *******************************************************************
		// METHOD: OnDropDownDataBound
		// 
		private void OnDropDownDataBound(object sender, EventArgs e)
		{
			DropDownList dd = (DropDownList)sender;
			if (AllowNull)
			{
				bool found = false;
				foreach (ListItem i in dd.Items)
					if (i.Value == "")
					{
						found = true;
						break;
					}
						
				if (!found)
					dd.Items.Insert(0, new ListItem("", ""));
			}


			ListItem li = dd.Items.FindByValue(_dataValue);
			li.Selected = true;
		}

		// *******************************************************************
		// METHOD: LookupValueForEdit
		// 
		protected virtual string LookupValueForEdit(Control target)
		{
			// Get the data item object
			object dataItem = DataBinder.GetDataItem(target.NamingContainer);

			// LEO qui ho aggiunto il controllo sul NULL:
			// se il campo del record ritorna NULL significa che nella dropDownList deve
			// esserici un item corrispondente per il NULL in modo da
			// poterlo associare sia in ingresso che in uscita.
			// Invece di ritornare string.Empty si dovrebbe ritornare una string che identifichi univocamente
			// il valore NULL es <NULL>
			// Se infine la DropDownList contiene nella lista l'accoppiata <NULL> / "non assegnato"
			// si puo` fare il binding correttamente.

			// controllo se la proprieta` del record campo DataValueField ritorna null.
			// Se si ritorno string nulla per indicare nella DropDownList il valore null.
			object dataValue = DataBinder.GetPropertyValue(dataItem, DataValueField);
			if (dataValue == null)
				return string.Empty;

			return dataValue.ToString();
		}

		/// <summary>
		/// LookupValueForView ritorna la stringa da visualizzare
		/// nella maschera.
		/// </summary>
		/// <param name="target"></param>
		/// <returns>la stringa da visualizzare</returns>
		protected virtual string LookupValueForView(Control target)
		{
			// Take care of what's displayed at design-time
			if (DesignMode)
				return GetDesignTimeValue();

			if (target == null)
				throw new HttpException("No data bound container");

			// Get the data item object
			object dataItem = DataBinder.GetDataItem(target.NamingContainer);
			if ((dataItem == null) && !DesignMode)
				throw new HttpException("Data item not found");

			_dataValue = "";

			bool error = true;
			if (DataTextField != "")
			{
				try
				{
					object dv = DataBinder.GetPropertyValue(dataItem, DataTextField);
					if (dv != null)
					{
						_dataValue = dv.ToString();
						error = false;
					}
				}
				catch
				{
				}
			}

			if (error)
			{
				FillDropDown(target);
				object dv = DataBinder.GetPropertyValue(dataItem, DataValueField);

				string itemValue = (dv == null) ? "" : dv.ToString();

				ListItem item = DropDownControl.Items.FindByValue(itemValue);
				if (item == null)
					throw new Exception("il valore '" + itemValue + "' non e` presente nella lista");
				_dataValue = item.Text;
			}

			return _dataValue;
		}

		// *******************************************************************
		// METHOD: GetDesignTimeValue
		// 
		protected virtual string GetDesignTimeValue()
		{
			return "<select><option>Databound</option></select>";
		}


		// *******************************************************************
		// METHOD: FillDropDown
		//
		private void FillDropDown(Control target)
		{
			DropDownList ddl = this.DropDownControl;
			target.Controls.Add(ddl);
			ddl.DataTextField = this.DataTextFieldForEdit;
			ddl.DataValueField = this.DataValueFieldForEdit;
			ddl.DataSourceID = this.DataSourceIDForEdit;

			ddl.DataBind();

			if (AllowNull)
			{
				foreach (ListItem i in ddl.Items)
					if (i.Value == "")
						return;

				ddl.Items.Insert(0, new ListItem("", ""));
			}
		}
		#endregion
	}
}
