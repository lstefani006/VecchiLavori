using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:EditableLabel runat=server></{0}:EditableLabel>")]
	[ValidationProperty("Text")]
	public class EditableLabel : WebControl, INamingContainer
	{
		public EditableLabel()
		{
			_validator = new List<BaseValidator>();
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string Text
		{
			get
			{
				if (_controlState.ReadOnly == false)
					_controlState.Text = _textBox.Text;

				return _controlState.Text;
			}
			set
			{
				if (value == null) value = string.Empty;
				_controlState.Text = value;
			}
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("False")]
		public bool ReadOnly
		{
			get { return _controlState.ReadOnly; }
			set { _controlState.ReadOnly = value; }
		}


		public void AddValidator(BaseValidator value)
		{
			EnsureChildControls();

			if (value != null)
			{
				_validator.Add(value);
				value.ControlToValidate = "textbox";
				this.Controls.Add(value);
			}
		}


		TextBox _textBox;
		Label _label;
		List<BaseValidator> _validator;

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			if (this.DesignMode)
				this.EnsureChildControls();

			this.Page.RegisterRequiresControlState(this);
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			EnsureChildControls();

			if (!Page.IsPostBack)
			{
				_controlState = new ControlState();
				_controlState.ReadOnly = false;
				_controlState.Text = "";
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			this.EnsureChildControls();

			_textBox.Text = _controlState.Text;
			_label.Text = _controlState.Text;

			if (_controlState.ReadOnly)
			{
				_label.Visible = true;
				_textBox.Visible = false;

				foreach (BaseValidator v in _validator)
					v.Visible = false;
			}
			else
			{
				_label.Visible = false;
				_textBox.Visible = true;
				foreach (BaseValidator v in _validator)
					v.Visible = true;
			}

			base.OnPreRender(e);
		}

		//protected override void Render(HtmlTextWriter writer)
		//{
		//    string id = this.ID;
		//    this.ID = id + "0";

		//    if (_controlState.ReadOnly)
		//    {

		//        _label.ID = id;
		//        _label.RenderControl(writer);
		//    }
		//    else
		//    {
		//        _textBox.ID = id;
		//        _textBox.RenderControl(writer);
		//    }
		//}

		protected override void CreateChildControls()
		{
			this._textBox = new TextBox();
			this._textBox.ID = "textbox";
			if (!this.Width.IsEmpty)
				this._textBox.Width = this.Width;

			this.Controls.Add(this._textBox);

			this._label = new Label();
			this._label.ID = "label";
			if (!this.Width.IsEmpty)
				this._label.Width = this.Width;

			this.Controls.Add(this._label);

			this.ChildControlsCreated = true;
		}

		[Serializable]
		class ControlState
		{
			public bool ReadOnly;
			public string Text;
		}

		ControlState _controlState;
		protected override object SaveControlState() { return _controlState; }
		protected override void LoadControlState(object state) { _controlState = state as ControlState; }

	}
}
