using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:TextBoxWithValidator runat=server></{0}:TextBoxWithValidator>")]
	public class TextBoxWithValidator : WebControl, INamingContainer
	{
		[Bindable(true), Category("Appearance"), DefaultValue("String")]
		public string Text
		{
			get { EnsureChildControls(); return _t.Text;  }
			set { EnsureChildControls(); _t.Text = value; }
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public Unit TextWidth
		{
			get { return ReadViewStateProperty("TextWidth", new Unit()); }
			set { WriteViewStateProperty("TextWidth", value); }
		}


		[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseRequiredValidator
		{
			get { return ReadViewStateProperty("rq", false); }
			set { WriteViewStateProperty("rq", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseRangeValidator
		{
			get { return ReadViewStateProperty("rv", false); }
			set { WriteViewStateProperty("rv", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string RangeValidator_MaximumValue
		{
			get { return ReadViewStateProperty("rv_MaximumValue", ""); }
			set { WriteViewStateProperty("rv_MaximumValue", value); }
		}
		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string RangeValidator_MinimumValue
		{
			get { return ReadViewStateProperty("rv_MinimumValue", ""); }
			set { WriteViewStateProperty("rv_MinimumValue", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public ValidationDataType Type
		{
			get { return ReadViewStateProperty("Type", ValidationDataType.String); }
			set { WriteViewStateProperty("Type", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("Range error on field.")]
		public string RangeValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("rv_ErrorMessage", "Range error on field."); }
			set { WriteViewStateProperty("rv_ErrorMessage", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("Required field.")]
		public string RequiredValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("rq_ErrorMessage", "Required field."); }
			set { WriteViewStateProperty("rq_ErrorMessage", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string ValidationGroup
		{
			get { return ReadViewStateProperty("ValidationGroup", ""); }
			set { WriteViewStateProperty("ValidationGroup", value); }
		}

		/* RegularExpressionValidator_Begin */
		[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseRegularExpressionValidator
		{
			get { return ReadViewStateProperty("rev", false); }
			set { WriteViewStateProperty("rev", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("Field in wrong format.")]
		public string RegularExpressionValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("rev_ErrorMessage", "Field in wrong format."); }
			set { WriteViewStateProperty("rev_ErrorMessage", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string RegularExpressionValidator_ValidationExpression
		{
			get { return ReadViewStateProperty("rev_ValidationExpression", ""); }
			set { WriteViewStateProperty("rev_ValidationExpression", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseCompareValidator
		{
			get { return ReadViewStateProperty("cv", false); }
			set { WriteViewStateProperty("cv", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("Comparison check failed.")]
		public string CompareValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("cv_ErrorMessage", "Comparison check failed."); }
			set { WriteViewStateProperty("cv_ErrorMessage", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public ValidationCompareOperator CompareValidator_Operator
		{
			get { return ReadViewStateProperty("cv_Operator", ValidationCompareOperator.DataTypeCheck); }
			set { WriteViewStateProperty("cv_Operator", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string CompareValidator_ValueToCompare
		{
			get { return ReadViewStateProperty("cv_ValueToCompare", ""); }
			set { WriteViewStateProperty("cv_ValueToCompare", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool UseCustomValidator
		{
			get { return ReadViewStateProperty("cm", false); }
			set { WriteViewStateProperty("cm", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string CustomValidator_ClientValidationFunction
		{
			get { return ReadViewStateProperty("cm_ClientValidationFunction", ""); }
			set { WriteViewStateProperty("cm_ClientValidationFunction", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("String")]
		public string CustomValidator_ErrorMessage
		{
			get { return ReadViewStateProperty("cm_ErrorMessage", ""); }
			set { WriteViewStateProperty("cm_ErrorMessage", value); }
		}

		[Bindable(true), Themeable(true), Category("Appearance"), DefaultValue("Yellow")]
		public Color Validators_BackColor
		{
			get { return ReadViewStateProperty("Validators_BackColor", Color.Yellow); }
			set { WriteViewStateProperty("Validators_BackColor", value); }
		}

		[Themeable(true), Bindable(true), Category("Appearance"), DefaultValue("Red")]
		public Color Validators_ForeColor
		{
			get { return ReadViewStateProperty("Validators_ForeColor", Color.Red); }
			set { WriteViewStateProperty("Validators_ForeColor", value); }
		}

		[Themeable(true), Bindable(true), Category("Appearance"), DefaultValue("Black")]
		public Color Validators_BorderColor
		{
			get { return ReadViewStateProperty("Validators_BorderColor", Color.Black); }
			set { WriteViewStateProperty("Validators_BorderColor", value); }
		}

		[Themeable(true), Bindable(true), Category("Appearance"), DefaultValue("Solid")]
		public BorderStyle Validators_BorderStyle
		{
			get { return ReadViewStateProperty("Validators_BorderStyle", BorderStyle.Solid); }
			set { WriteViewStateProperty("Validators_BorderStyle", value); }
		}

		[Themeable(true), Bindable(true), DefaultValue(typeof(Unit), "1px"), Category("Appearance")]
		public Unit Validators_BorderWidth
		{
			get { return ReadViewStateProperty("Validators_BorderWidth", new Unit(1, UnitType.Pixel)); }
			set { WriteViewStateProperty("Validators_BorderWidth", value); }
		}

		[Themeable(true), Bindable(true), DefaultValue(typeof(Unit), "2px"), Category("Appearance")]
		public Unit Validators_Padding
		{
			get { return ReadViewStateProperty("Validators_Padding", new Unit(2, UnitType.Pixel)); }
			set { WriteViewStateProperty("Validators_Padding", value); }
		}

		[Themeable(true), Bindable(true), DefaultValue(typeof(Unit), "100px"), Category("Appearance")]
		public Unit Validators_Width
		{
			get { return ReadViewStateProperty("Validators_Width", new Unit(100, UnitType.Pixel)); }
			set { WriteViewStateProperty("Validators_Width", value); }
		}

		[Themeable(true), Bindable(true),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
		Category("Appearance")]
		public FontInfo Validators_Font
		{
			get
			{
				object obj = ViewState["Validators_Font"];
				if (obj == null)
				{
					obj = new System.Web.UI.WebControls.Style().Font;
					ViewState["Validators_Font"] = obj;
				}
				return (FontInfo)obj;
			}
					
			set 
			{
				object obj = ViewState["Validators_Font"];
				if (obj == null)
				{
					obj = new System.Web.UI.WebControls.Style().Font;
					ViewState["Validators_Font"] = obj;
				}
				FontInfo fi = (FontInfo)obj;
				fi.CopyFrom(value);
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

			this.EnsureChildControls();
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			if (this.DesignMode)
				this.EnsureChildControls();

			this.Page.RegisterRequiresControlState(this);
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			EnsureChildControls();
		}

		TextBox _t;
		RequiredFieldValidator _reqVal;
		RangeValidator _rangeVal;
		RegularExpressionValidator _regVal;
		CompareValidator _compVal;
		CustomValidator _custVal;

		protected override void CreateChildControls()
		{
			this._t = new TextBox();
			this._t.ID = "txtData";
			if (!this.TextWidth.IsEmpty)
			{
				this._t.Width = this.TextWidth;
			}
			this._t.TextChanged += new EventHandler(this._t_TextChanged);
			this.Controls.Add(this._t);

			HtmlGenericControl divContainer = new HtmlGenericControl("span");
			divContainer.Style.Add(HtmlTextWriterStyle.Position, "relative");
			this.Controls.Add(divContainer);


			HtmlGenericControl div1 = new HtmlGenericControl("span");
			divContainer.Controls.Add(div1);

			HtmlGenericControl div2 = new HtmlGenericControl("span");
			divContainer.Controls.Add(div2);

			HtmlGenericControl div3 = new HtmlGenericControl("span");
			divContainer.Controls.Add(div3);

			HtmlGenericControl div4 = new HtmlGenericControl("span");
			divContainer.Controls.Add(div4);

			HtmlGenericControl div5 = new HtmlGenericControl("span");
			divContainer.Controls.Add(div5);

			div1.Style.Add(HtmlTextWriterStyle.Position, "absolute");
			div2.Style.Add(HtmlTextWriterStyle.Position, "absolute");
			div3.Style.Add(HtmlTextWriterStyle.Position, "absolute");
			div4.Style.Add(HtmlTextWriterStyle.Position, "absolute");
			div5.Style.Add(HtmlTextWriterStyle.Position, "absolute");

			div1.Style.Add(HtmlTextWriterStyle.Left, "5px");
			div2.Style.Add(HtmlTextWriterStyle.Left, "5px");
			div3.Style.Add(HtmlTextWriterStyle.Left, "5px");
			div4.Style.Add(HtmlTextWriterStyle.Left, "5px");
			div5.Style.Add(HtmlTextWriterStyle.Left, "5px");

			if (true)
			{
				_reqVal = new RequiredFieldValidator();
				_reqVal.ControlToValidate = "txtData";
				_reqVal.EnableTheming = false;
				_reqVal.ErrorMessage = this.RequiredValidator_ErrorMessage;
				_reqVal.Enabled = this.UseRequiredValidator;
				_reqVal.BackColor = this.Validators_BackColor;
				_reqVal.ForeColor = this.Validators_ForeColor;
				_reqVal.BorderColor = this.Validators_BorderColor;
				_reqVal.BorderStyle = this.Validators_BorderStyle;
				_reqVal.BorderWidth = this.Validators_BorderWidth;
				if (!this.Validators_Padding.IsEmpty)
					_reqVal.Style.Add(HtmlTextWriterStyle.Padding, this.Validators_Padding.ToString());

				if (!this.Validators_Width.IsEmpty)
					_reqVal.Style.Add(HtmlTextWriterStyle.Width, this.Validators_Width.ToString());

				if (this.Validators_Font != null)
					_reqVal.Font.CopyFrom(this.Validators_Font);

				if (!string.IsNullOrEmpty(this.ValidationGroup))
					_reqVal.ValidationGroup = this.ValidationGroup;
				
				div1.Controls.Add(_reqVal);
			}

			if (true)
			{
				_rangeVal = new RangeValidator();
				_rangeVal.ControlToValidate = "txtData";
				_rangeVal.CultureInvariantValues = true;
				_rangeVal.EnableTheming = false;
				_rangeVal.ErrorMessage = this.RangeValidator_ErrorMessage;
				_rangeVal.Type = this.Type;
				_rangeVal.MaximumValue = this.RangeValidator_MaximumValue;
				_rangeVal.MinimumValue = this.RangeValidator_MinimumValue;
				_rangeVal.Enabled = this.UseRangeValidator;
				_rangeVal.BackColor = this.Validators_BackColor;
				_rangeVal.ForeColor = this.Validators_ForeColor;
				_rangeVal.BorderColor = this.Validators_BorderColor;
				_rangeVal.BorderStyle = this.Validators_BorderStyle;
				_rangeVal.BorderWidth = this.Validators_BorderWidth;
				if (!this.Validators_Padding.IsEmpty)
					_rangeVal.Style.Add(HtmlTextWriterStyle.Padding, this.Validators_Padding.ToString());

				if (!this.Validators_Width.IsEmpty)
					_rangeVal.Style.Add(HtmlTextWriterStyle.Width, this.Validators_Width.ToString());

				if (this.Validators_Font != null)
					_rangeVal.Font.CopyFrom(this.Validators_Font);

				if (!string.IsNullOrEmpty(this.ValidationGroup))
					_rangeVal.ValidationGroup = this.ValidationGroup;
				
				div2.Controls.Add(_rangeVal);
			}

			if (true)
			{
				_regVal = new RegularExpressionValidator();
				_regVal.ControlToValidate = "txtData";
				_regVal.EnableTheming = false;
				_regVal.ValidationExpression = this.RegularExpressionValidator_ValidationExpression;
				_regVal.ErrorMessage = this.RegularExpressionValidator_ErrorMessage;
				_regVal.Enabled = this.UseRegularExpressionValidator;
				_regVal.BackColor = this.Validators_BackColor;
				_regVal.ForeColor = this.Validators_ForeColor;
				_regVal.BorderColor = this.Validators_BorderColor;
				_regVal.BorderStyle = this.Validators_BorderStyle;
				_regVal.BorderWidth = this.Validators_BorderWidth;
				if (!this.Validators_Padding.IsEmpty)
					_regVal.Style.Add(HtmlTextWriterStyle.Padding, this.Validators_Padding.ToString());

				if (!this.Validators_Width.IsEmpty)
					_regVal.Style.Add(HtmlTextWriterStyle.Width, this.Validators_Width.ToString());

				if (this.Validators_Font != null)
					_regVal.Font.CopyFrom(this.Validators_Font);

				if (!string.IsNullOrEmpty(this.ValidationGroup))
					_regVal.ValidationGroup = this.ValidationGroup;

				div3.Controls.Add(_regVal);
			}

			if (true)
			{
				_compVal = new CompareValidator();
				_compVal.CultureInvariantValues = true;
				_compVal.ControlToValidate = "txtData";
				_compVal.EnableTheming = false;
				_compVal.ErrorMessage = this.CompareValidator_ErrorMessage;
				_compVal.Enabled = this.UseCompareValidator;
				_compVal.Operator = this.CompareValidator_Operator;
				_compVal.Type = this.Type;
				_compVal.ValueToCompare = this.CompareValidator_ValueToCompare;
				_compVal.BackColor = this.Validators_BackColor;
				_compVal.ForeColor = this.Validators_ForeColor;
				_compVal.BorderColor = this.Validators_BorderColor;
				_compVal.BorderStyle = this.Validators_BorderStyle;
				_compVal.BorderWidth = this.Validators_BorderWidth;
				if (!this.Validators_Padding.IsEmpty)
					_compVal.Style.Add(HtmlTextWriterStyle.Padding, this.Validators_Padding.ToString());

				if (!this.Validators_Width.IsEmpty)
					_compVal.Style.Add(HtmlTextWriterStyle.Width, this.Validators_Width.ToString());

				if (this.Validators_Font != null)
					_compVal.Font.CopyFrom(this.Validators_Font);

				if (!string.IsNullOrEmpty(this.ValidationGroup))
					_compVal.ValidationGroup = this.ValidationGroup;

				div4.Controls.Add(_compVal);
			}

			if (true)
			{
				_custVal = new CustomValidator();
				_custVal.ControlToValidate = "txtData";
				_custVal.EnableTheming = false;
				_custVal.ErrorMessage = this.CustomValidator_ErrorMessage;
				_custVal.ClientValidationFunction = this.CustomValidator_ClientValidationFunction;
				_custVal.BackColor = this.Validators_BackColor;
				_custVal.ForeColor = this.Validators_ForeColor;
				_custVal.BorderColor = this.Validators_BorderColor;
				_custVal.BorderStyle = this.Validators_BorderStyle;
				_custVal.BorderWidth = this.Validators_BorderWidth;
				_custVal.Enabled = this.UseCustomValidator;
				if (!this.Validators_Padding.IsEmpty)
					_custVal.Style.Add(HtmlTextWriterStyle.Padding, this.Validators_Padding.ToString());

				if (!this.Validators_Width.IsEmpty)
					_custVal.Style.Add(HtmlTextWriterStyle.Width, this.Validators_Width.ToString());

				if (this.Validators_Font != null)
					_compVal.Font.CopyFrom(this.Validators_Font);

				if (!string.IsNullOrEmpty(this.ValidationGroup))
					_custVal.ValidationGroup = this.ValidationGroup;

				div5.Controls.Add(_custVal);
			}

			base.CreateChildControls();

			this.ChildControlsCreated = true;
		}

		public event EventHandler TextChanged;

		void _t_TextChanged(object sender, EventArgs e)
		{
			if (TextChanged != null)
				TextChanged(this, e);
		}

		private T ReadViewStateProperty<T>(string key, T defValue)
		{
			object obj = ViewState[key];
			if (obj != null) return (T)obj;
			return defValue;
		}

		private void WriteViewStateProperty<T>(string key, T value)
		{
			base.ViewState[key] = value;
		}

	}
}
