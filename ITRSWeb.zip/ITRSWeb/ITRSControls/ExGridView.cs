using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Diagnostics;
using System.Reflection;

namespace ITRSControls
{
	[ToolboxData("<{0}:ExGridView runat=server></{0}:ExGridView>")]
	public class ExGridView : GridView
	{
		[Bindable(true), Category("Behavior"), DefaultValue("False"), Themeable(true)]
		public bool RowClientSelect
		{
			get { return ReadViewStateProperty("RowClientSelect", false); }
			set { ViewState["RowClientSelect"] = value; }
		}

		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(true)]
		public string RowClientSelectScript
		{
			get { return ReadViewStateProperty("RowClientSelectScript", string.Empty); }
			set { ViewState["RowClientSelectScript"] = value; }
		}


		[Bindable(true), Category("Behavior"), DefaultValue("False"), Themeable(true)]
		public bool AddGlyp
		{
			get { return ReadViewStateProperty("AddGlyp", false); }
			set { ViewState["AddGlyp"] = value; }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("False")]
		public bool FireSelectEventOnDblClick
		{
			get { return ReadViewStateProperty("FireSelectEventOnDblClick", false); }
			set { ViewState["FireSelectEventOnDblClick"] = value; }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string OnClientDblClick
		{
			get { return ReadViewStateProperty("OnClientDblClick", ""); }
			set { ViewState["OnClientDblClick"] = value; }
		}


		[Bindable(true), Category("Behavior")]
		public int TotalNumberOfRows
		{
			get { return ReadViewStateProperty("TotalNumberOfRows", -1); }
			set { ViewState["TotalNumberOfRows"] = value; }
		}

		protected override ICollection CreateColumns(PagedDataSource dataSource, bool useDataSource)
		{
			if (dataSource != null)
				TotalNumberOfRows = dataSource.DataSourceCount;
			return base.CreateColumns(dataSource, useDataSource);
		}





		private T ReadViewStateProperty<T>(string key, T defValue)
		{
			object obj = ViewState[key];
			if (obj != null) return (T)obj;
			return defValue;
		}

		public ExGridView()
		{
		}

		protected override void OnRowCreated(GridViewRowEventArgs e)
		{
			base.OnRowCreated(e);

			if (AddGlyp && this.AllowSorting)
			{
				if (e.Row.RowType == DataControlRowType.Header)
					AddGlyph(e.Row);
			}

			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				if (RowClientSelect)
					e.Row.Attributes.Add("onclick", "fnSelectRow(this.parent, this);");

				if (FireSelectEventOnDblClick)
					e.Row.Attributes.Add("ondblclick", Page.ClientScript.GetPostBackEventReference(this, "Select$" + e.Row.RowIndex.ToString()));

				if (OnClientDblClick != "")
					e.Row.Attributes.Add("ondblclick", string.Format(OnClientDblClick, e.Row.RowIndex.ToString()));

				if (RowClientSelect || FireSelectEventOnDblClick || OnClientDblClick != "")
					e.Row.Attributes.Add("onMouseOver", "this.style.cursor='hand';");


			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			if (RowClientSelect)
			{
				ClientScriptManager csm = this.Page.ClientScript;
				if (!csm.IsClientScriptIncludeRegistered("griglia_selezionabile"))
					csm.RegisterClientScriptInclude("griglia_selezionabile", RowClientSelectScript);
			}
			base.OnPreRender(e);
		}

		private void AddGlyph(GridViewRow item)
		{
			Label glyph = new Label();
			glyph.EnableTheming = false;
			glyph.Font.Name = "webdings";
			glyph.Font.Size = FontUnit.XSmall;
			glyph.Text = (this.SortDirection == SortDirection.Ascending ? "5" : "6");
			glyph.Width = new Unit(20, UnitType.Pixel);

			Label glyphEmpty = new Label();
			glyphEmpty.EnableTheming = false;
			glyphEmpty.Font.Name = "webdings";
			glyphEmpty.Font.Size = FontUnit.XSmall;
			glyphEmpty.Text = "";
			glyphEmpty.Width = new Unit(20, UnitType.Pixel);


			// Find the column you sorted by
			for (int i = 0; i < this.Columns.Count; i++)
			{
				// se esiste la sort espression
				if (this.Columns[i].SortExpression.Length > 0)
				{
					string colSort = this.Columns[i].SortExpression;
					string newSort = this.SortExpression;
					if (colSort != "" && colSort == newSort)
						item.Cells[i].Controls.Add(glyph);
					else
						item.Cells[i].Controls.Add(glyphEmpty);
				}
			}
		}

		public event ExGridSelectCountEventHandler SelectCount;

		protected override DataSourceSelectArguments CreateDataSourceSelectArguments()
		{
			// questo arzigogolo serve per evitare il baco della GridView
			// quando si clicca sul pager per vedere l'ultima pagina.
			try
			{
				return base.CreateDataSourceSelectArguments();
			}
			catch (OverflowException ex)
			{
				// ASP.NET 2.0 si pianta perche` PageIndex e` valorizzato a 2.000.000.000
				// sull'ultima pagina (della serie NON so quale e` l'ultima pagina).
				string g = ex.Message;
			}


			// qui non faccio altro che chiedere alla pagina QUANTI record ha

			ExGridSelectCountEventArgs e = new ExGridSelectCountEventArgs();

			if (SelectCount != null)
				SelectCount(this, e);

			// finalmente capisco quale e` l'ultima pagina.
			this.PageIndex = e.Count / this.PageSize;

			return base.CreateDataSourceSelectArguments();
		}

		public int GetCellIndex(string dataField)
		{
			for (int i = 0; i < this.Columns.Count; i++)
			{
				DataControlField dcf = this.Columns[i];
				PropertyInfo pi = dcf.GetType().GetProperty("DataField");
				if (pi != null)
				{
					string columnDataField = (string)pi.GetValue(dcf, new object[0]);
					if (columnDataField == dataField)
						return i;
				}
			}
			Debug.Assert(false, "DataField not found: " + dataField);
			return -1;
		}

	}

	public class ExGridSelectCountEventArgs : EventArgs
	{
		public int Count;
	}

	public delegate void ExGridSelectCountEventHandler(object sender, ExGridSelectCountEventArgs e);

}
