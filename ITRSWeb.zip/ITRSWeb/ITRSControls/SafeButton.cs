using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:SafeButton runat=server></{0}:SafeButton>")]
	public class SafeButton : Button
	{
		/*
		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string Text
		{
			get
			{
				String s = (String)ViewState["Text"];
				return ((s == null) ? String.Empty : s);
			}

			set
			{
				ViewState["Text"] = value;
			}
		}
		*/

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			string scr = @"
			function DisableSubmit()
			{
				var dt = function(flag)
				{
					try 
					{
						var s;
						for (s in SafeButtonList)
						{
							var v = document.getElementById(SafeButtonList[s]);
							v.disabled = flag;
						}
					} catch (ex)
					{
					}
				}

				window.setTimeout(function() { dt(true); } , 0);
				window.setTimeout(function() { dt(false); }, 10 * 1000);
			}
";

			if (!Page.ClientScript.IsOnSubmitStatementRegistered("SafeButton_1"))
			{
				Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "SafeButton_1", scr, true);
				Page.ClientScript.RegisterOnSubmitStatement(this.GetType(), "SafeButton_1", "DisableSubmit();");
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			Page.ClientScript.RegisterArrayDeclaration("SafeButtonList", string.Format("'{0}'", this.ClientID));
		}

		protected override void RenderContents(HtmlTextWriter output)
		{
			base.RenderContents(output);
		}
	}
}
