using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:ClientTimer runat=server></{0}:ClientTimer>")]
	public class ClientTimer : WebControl, ICallbackEventHandler
	{
		[Bindable(true), Category("Behavior"), DefaultValue("1000")]
		public int PollingPeriod
		{
			get { return ReadViewStateProperty("PollingPeriod", 1000); }
			set { ViewState["PollingPeriod"] = value; }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string CallServerScript
		{
			get { return ReadViewStateProperty("CallServerScript", ""); }
			set { ViewState["CallServerScript"] = value; }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("")]
		public string ClientCallbackScript
		{
			get { return ReadViewStateProperty("ClientCallbackScript", ""); }
			set { ViewState["ClientCallbackScript"] = value; }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("alert(exceptionMsg);")]
		public string ClientCallbackErrorScript
		{
			get { return ReadViewStateProperty("ClientCallbackErrorScript", "alert(exceptionMsg);"); }
			set { ViewState["ClientCallbackErrorScript"] = value; }
		}

		[Bindable(true), Category("Behavior"), DefaultValue("true")]
		public string EnableServerCalls
		{
			//get { return ReadViewStateProperty("EnableServerCalls", "true"); }
			//set { ViewState["EnableServerCalls"] = value; }
			get { return _EnableServerCalls; }
			set { _EnableServerCalls = value; }
		}
		string _EnableServerCalls = "true";

		protected override void OnInit(EventArgs e)
		{
			this.Page.RegisterRequiresControlState(this);
			base.OnInit(e);
		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

			if (!Page.ClientScript.IsClientScriptBlockRegistered("ClientTimerScript_StartUp"))
			{
				string s = @"
function ClientTimer_Start_All()
{
	for (var i = 0; i < ClientTimerScript_Startup.length; ++i)
	{
		var c = ClientTimerScript_Startup[i]+'()';
		eval(c);
	}
}
";
				Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ClientTimerScript_StartUp", s, true);
			}

			if (this.PollingPeriod > 0)
			{

				if (!Page.ClientScript.IsClientScriptBlockRegistered("ClientTimerScript_" + this.ID))
				{
					Page.ClientScript.RegisterArrayDeclaration("ClientTimerScript_Startup", string.Format("\"ClientTimer_Start_{0}\"", this.ID));

					bool useAsync = true;
					string cb = Page.ClientScript.GetCallbackEventReference(
						this,
						"arg",
						string.Format("ClientTimer_ClientCallback_{0}", this.ID),
						"context",
						string.Format("ClientTimer_ClientErrorCallback_{0}", this.ID),
						useAsync);

					string callbackScript = @"

var ClientTimer_PendingCall_{0} = false; 
var ClientTimer_Period_{0} = {1}; // 1 -- il periodo di polling

function ClientTimer_Start_{0}()
{
	window.setTimeout(ClientTimer_TimerCallback_{0}, ClientTimer_Period_{0});
}

function ClientTimer_TimerCallback_{0}()
{
	if (ClientTimer_PendingCall_{0} == false)
	{
		var arg = 'arg';
		var context = 'context';

		// 5 -- variabile valorizzata lato server per far partire l'interrogazione
		var makeCall = {5};
		if (makeCall == false)
		{
			return;	
		}

		try
		{
			do
			{
				// 2 -- qui mettere il codice per assegnare arg e context
				{2}
			}
			while (false);
		}
		catch (ex)
		{
			alert('ClientTimer_TimerCallback_{0}:' + ex.message);
		}

		if (makeCall)
		{
			ClientTimer_PendingCall_{0} = true;
			ClientTimer_CallServer_{0}(arg, context);
		}
	}
}

function ClientTimer_ClientCallback_{0}(result, context)
{
	try
	{
		var nextCall = true;
		do 
		{
			// 3 -- qui mettere il codice o la chiamata che usano <result> e <context>
			{3}
		} 
		while (false);

		if (nextCall)
		{
			ClientTimer_PendingCall_{0} = false;
			window.setTimeout(ClientTimer_TimerCallback_{0}, ClientTimer_Period_{0});
		}
	}
	catch(ex)
	{
		alert('ClientTimer_ClientCallback_{0}:' + ex.message);
	}
}

function ClientTimer_ClientErrorCallback_{0}(exceptionMsg, context)
{
	var nextCall = false;

	do
	{
		// 4 -- qui mettere il codice di gestione dell'eccezione
		{4}
	}
	while (false);
	
	if (nextCall)
	{
		ClientTimer_PendingCall_{0} = false;
		window.setTimeout(ClientTimer_ClientCallback_Caller_{0}, ClientTimer_Period_{0});
	}
}

function ClientTimer_CallServer_{0}(arg, context) 
{ 
	" + cb + @";
}";
					callbackScript = callbackScript.Replace("{1}", this.PollingPeriod.ToString());
					callbackScript = callbackScript.Replace("{2}", this.CallServerScript);
					callbackScript = callbackScript.Replace("{3}", this.ClientCallbackScript);
					callbackScript = callbackScript.Replace("{4}", this.ClientCallbackErrorScript);
					callbackScript = callbackScript.Replace("{5}", this.EnableServerCalls);

					// lo faccio all'ultimo per dare la possibilita` agli argomenti di 
					// sopra di specificare se necessario anche {0}
					callbackScript = callbackScript.Replace("{0}", this.ID);

					Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ClientTimerScript_" + this.ID, callbackScript, true);
				}
			}
		}

		protected override object SaveControlState()
		{
			return _EnableServerCalls;
		}
		protected override void LoadControlState(object state)
		{
			_EnableServerCalls = (string)state;
		}


		protected override void Render(HtmlTextWriter w)
		{
			Page.ClientScript.RegisterForEventValidation(this.UniqueID);
			if (this.DesignMode)
			{
				w.RenderBeginTag(HtmlTextWriterTag.Span);
				w.Write("ClientTimer");
				w.RenderEndTag();
			}
		}

		#region ICallbackEventHandler Members

		string _callBackRes;


		void ICallbackEventHandler.RaiseCallbackEvent(string eventArgument)
		{
			_callBackRes = OnClientCall(eventArgument);
		}

		string ICallbackEventHandler.GetCallbackResult()
		{
			return _callBackRes;
		}


		#endregion

		public virtual string OnClientCall(string args)
		{
			if (ClientCall != null)
			{
				ClientTimerClientTimerEventArgs e = new ClientTimerClientTimerEventArgs();
				e.Args = args;
				ClientCall(this, e);
				return e.Result;
			}

			return string.Empty;
		}

		public event ClientTimerClientTimerEventHandler ClientCall;


		private T ReadViewStateProperty<T>(string key, T defValue)
		{
			object obj = ViewState[key];
			if (obj != null) return (T)obj;
			return defValue;
		}

	}

	public class ClientTimerClientTimerEventArgs : EventArgs
	{
		public string Args;
		public string Result;
	}

	public delegate void ClientTimerClientTimerEventHandler(object sender, ClientTimerClientTimerEventArgs e);
}
