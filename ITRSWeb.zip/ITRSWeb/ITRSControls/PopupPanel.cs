using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


[assembly: WebResource("ITRSControls.PopupPanel.js", "text/javascript")]

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:PopupPanel runat=server></{0}:PopupPanel>")]
	public class PopupPanel : WebControl, INamingContainer, ICallbackEventHandler
	{
		/*
		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string Text
		{
			get
			{
				String s = (String)ViewState["Text"];
				return ((s == null) ? String.Empty : s);
			}

			set
			{
				ViewState["Text"] = value;
			}
		}
		*/

		protected override void OnPreRender(EventArgs e)
		{
			Type ty = this.GetType();
			if (this.Page.ClientScript.IsClientScriptBlockRegistered(ty, "PopupPanelKey"))
			{
				this.Page.ClientScript.RegisterClientScriptBlock(ty, "PopupPanelKey", "", true);
				this.Page.ClientScript.RegisterClientScriptResource(ty, "ITRSControls.PopupPanel.js");
			}
			base.OnPreRender(e);
		}

		protected override void RenderContents(HtmlTextWriter w)
		{
			w.Write("<span>PopupPanel</span>");
		}

		#region ICallbackEventHandler Members

		private void GestionePopup()
		{
			// qui si da il bianco
			if (!Page.ClientScript.IsClientScriptBlockRegistered("PopupPanelKey_" + this.ID))
			{
				string RichiediAlServerHTML = string.Format("RichiediAlServerHTML_{0}", this.ID);
				string RiceviDalServerHtml = string.Format("RiceviDalServerHtml_{0}", this.ID);

				string cbReference = Page.ClientScript.GetCallbackEventReference(this, "arg", RiceviDalServerHtml, "context");
				string s = @"

// Chiamare questa funzione per aprire il PopupPanel
function " + RichiediAlServerHTML + @"(arg, context) 
{
	" + cbReference + @"; 
	return false; // blocco la chiamata al client
}

// Qui viene notificata la risposta proveniente dal server.
// A fronte del 'rvalue' che contiene l'html qui si apre il popup.
function " + RiceviDalServerHtml + @"(rvalue, context) 
{
	var w = new PopupWindow(" + div + @");
	w.offsetY = + " + offsetY + @";
	w.offsetX = + " + offsetX + @";
	//w.setSize('400', '400');
	w.autoHide();
	w.populate(rvalue);

	var anchorname = "+ anchorname + @";
	w.showPopup(anchorname);
}
";
				Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopupPanelKey" + this.ID, s, true);
			}
		}

		string offsetX = "-10";
		string offsetY = "+10";
		string anchorname = "'anchor'";
		string div = "'div'";

		string _html;
		public string GetCallbackResult()
		{
			return _html;
		}

		public void RaiseCallbackEvent(string eventArgument)
		{
			_html = "";
		}

		#endregion
	}
}
