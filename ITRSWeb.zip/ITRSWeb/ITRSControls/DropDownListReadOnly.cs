using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:DropDownListReadOnly runat=server></{0}:DropDownListReadOnly>")]
	public class DropDownListReadOnly : WebControl, INamingContainer
	{
		public string SelectedValue
		{
			get
			{
				return _ddl.SelectedValue;
			}
			set
			{
				_ddl.SelectedValue = value;

				foreach (ListItem li in _ddl.Items)
					if (li.Value == value)
						_label.Text = li.Value;
			}
		}

		public ListItemCollection Items
		{
			get
			{
				EnsureChildControls();
				return _ddl.Items;
			}
		}


		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("False")]
		public bool ReadOnly
		{
			get { return _controlState.ReadOnly; }
			set { _controlState.ReadOnly = value; }
		}


		DropDownList _ddl;
		Label _label;

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			this.EnsureChildControls();

			this.Page.RegisterRequiresControlState(this);
			_ddl.SelectedIndexChanged += new EventHandler(_ddl_SelectedIndexChanged);
		}

		void _ddl_SelectedIndexChanged(object sender, EventArgs e)
		{
			_controlState.SelectedValue = _ddl.SelectedValue;
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			EnsureChildControls();

			if (!Page.IsPostBack)
			{
				_controlState = new ControlState();
				_controlState.ReadOnly = false;
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			this.EnsureChildControls();

			if (_controlState.ReadOnly)
			{
				_label.Visible = true;
				_ddl.Visible = false;
			}
			else
			{
				_label.Visible = false;
				_ddl.Visible = true;
			}

			base.OnPreRender(e);
		}

		protected override void CreateChildControls()
		{
			this._ddl = new DropDownList();
			this._ddl.ID = "ddp";
			if (!this.Width.IsEmpty)
				this._ddl.Width = this.Width;

			this.Controls.Add(this._ddl);

			this._label = new Label();
			this._label.ID = "label";
			if (!this.Width.IsEmpty)
				this._label.Width = this.Width;

			this.Controls.Add(this._label);

			this.ChildControlsCreated = true;
		}

		[Serializable]
		class ControlState
		{
			public bool ReadOnly;
			public string SelectedValue;
		}

		ControlState _controlState;
		protected override object SaveControlState() { return _controlState; }
		protected override void LoadControlState(object state) { _controlState = state as ControlState; }
	}
}
