using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:AlertWebControl runat=server></{0}:AlertWebControl>")]
	public class AlertWebControl : WebControl
	{
		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string AlertText
		{
			get { string s = _alertText; return s == null ? "" : s; }
			set { _alertText = value; }
		}

		string _alertText;

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

			if (AlertText.Length > 0)
			{
				string a = string.Format("alert('{0}');", AlertText);
				Page.ClientScript.RegisterStartupScript(this.GetType(), "Alert" + ID, a, true);
			}
		}
	}
}
