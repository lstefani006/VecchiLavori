using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ITRSControls
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:QueueJobStatus runat=server></{0}:QueueJobStatus>")]
	public class QueueJobStatus : WebControl, INamingContainer,
		ICallbackEventHandler,
		IPostBackEventHandler
	{
		[Bindable(true)]
		[Category("Behavior")]
		[DefaultValue("")]
		public string JobId
		{
			get { return _cd.JobId; }
			set { _cd.JobId = value; }
		}

		protected override void Render(HtmlTextWriter output)
		{
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

			if (!Page.ClientScript.IsClientScriptBlockRegistered("CallServerKey"))
			{
				string cbReference = Page.ClientScript.GetCallbackEventReference(this,
						"arg", "ReceiveServerData", "context");

				// questa e` la funzione da chiamare per invocare il server.
				string callbackScript = "function CallServer(arg, context) { " + cbReference + "} ;";

				Page.ClientScript.RegisterClientScriptBlock(
					this.GetType(),
					"CallServerKey",
					callbackScript, true);
			}
		}

		#region ICallbackEventHandler Members

		public string GetCallbackResult()
		{
			throw new Exception("The method or operation is not implemented.");
		}

		public void RaiseCallbackEvent(string eventArgument)
		{
			throw new Exception("The method or operation is not implemented.");
		}

		#endregion

		private T ReadViewStateProperty<T>(string key, T defValue)
		{
			object obj = ViewState[key];
			if (obj != null) return (T)obj;
			return defValue;
		}

		// questi dati persistono anche se il view state e` disabilitato
		ControlData _cd;

		[Serializable]
		public class ControlData
		{
			public string JobId;
		}

		protected override void LoadControlState(object savedState)
		{
			object[] st = (object[])savedState;
			base.LoadControlState(st[0]);
			_cd = (ControlData)st[1];
		}

		protected override object SaveControlState()
		{
			object[] st = new object[2];
			st[0] = base.SaveControlState();
			st[1] = _cd;
			return st;
		}

		#region IPostBackEventHandler Members

		public void RaisePostBackEvent(string eventArgument)
		{
			throw new Exception("The method or operation is not implemented.");
		}

		#endregion
	}
}
