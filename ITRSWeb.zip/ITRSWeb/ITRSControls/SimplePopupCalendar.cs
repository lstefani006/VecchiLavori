using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Globalization;

namespace ITRSControls
{
	[ToolboxData("<{0}:SimplePopupCalendar runat=server></{0}:SimplePopupCalendar>")]
	public class SimplePopupCalendar : WebControl, INamingContainer
	{
		[Bindable(true), Category("Behavior"), DefaultValue("False"), Themeable(true)]
		public bool UseDIV
		{
			get { return ReadViewStateProperty("UseDIV", false); }
			set { WriteViewStateProperty("UseDIV", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(true)]
		public string ImagePath
		{
			get { return ReadViewStateProperty("ImagePath", string.Empty); }
			set { WriteViewStateProperty("ImagePath", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(true)]
		public string ScriptPath
		{
			get { return ReadViewStateProperty("ScriptPath", string.Empty); }
			set { WriteViewStateProperty("ScriptPath", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(false)]
		public string ControlToReadWriteDate
		{
			get { return ReadViewStateProperty("ControlToReadWriteDate", string.Empty); }
			set { WriteViewStateProperty("ControlToReadWriteDate", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(false)]
		public string DefaultHour
		{
			get { return ReadViewStateProperty("DefaultHour", string.Empty); }
			set { WriteViewStateProperty("DefaultHour", value); }
		}

		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(false)]
		public string OffsetX
		{
			get { return ReadViewStateProperty("OffsetX", string.Empty); }
			set { WriteViewStateProperty("OffsetX", value); }
		}
		[Bindable(true), Category("Behavior"), DefaultValue(""), Themeable(false)]
		public string OffsetY
		{
			get { return ReadViewStateProperty("OffsetY", string.Empty); }
			set { WriteViewStateProperty("OffsetY", value); }
		}

		protected override void OnPreRender(System.EventArgs e)
		{
			base.OnPreRender(e);

			ClientScriptManager csm = this.Page.ClientScript;

			//if (ScriptPath.Length > 0)
			//{
			//    if (!csm.IsClientScriptIncludeRegistered("PopupCalendar_scripts_Start"))
			//    {
			//        string s = this.ScriptPath;
			//        csm.RegisterClientScriptInclude("PopupCalendar_scripts_Start", s);
			//    }
			//}
			//else
			{
				if (!csm.IsClientScriptBlockRegistered("PopupCalendar_scripts_Start"))
				{
					string resName = "ITRSControls.PopupCalendar.js";
					Stream stream = this.GetType().Assembly.GetManifestResourceStream(resName);
					StreamReader rdr = new StreamReader(stream);
					string scriptStr = rdr.ReadToEnd();
					rdr.Close();
					stream.Close();
					csm.RegisterClientScriptBlock(this.GetType(), "PopupCalendar_scripts_Start", scriptStr, true);
				}
			}


			if (!csm.IsClientScriptBlockRegistered("SimplePopupCalendar_scripts"))
			{
				string s = @"
function SimplePopupCalendar_Crea(UseDiv, language, retCallFunction, x, y)
{
	var scal;
	if (UseDiv)
		scal= new CalendarPopup('PopupCalendar_Div');
	else
		scal = new CalendarPopup();
					
	if (language == 'it')
	{
		scal.setWeekStartDay(1); // week is Monday - Saturday
		scal.setMonthNames('Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre');
		scal.setDayHeaders('D','L','M', 'm', 'G', 'V', 'S');
		scal.setTodayText('Oggi');
	}
	scal.showNavigationDropdowns();
	scal.setCssPrefix('PopupCalendar');
	scal.setReturnFunction(retCallFunction);

	if (x != '')
		scal.offsetX = parseInt(x);
	if (y != '')
		scal.offsetY = parseInt(y);

	return scal;
}


// ritorna la data togliendo l'eventuale ora
function SimplePopupCalendar_estraiData(arg, language)
{
	var av = arg.split(/[ \/:.]/);

	var DD, MM, YYYY;

	if (language == 'it')
	{
		DD = av[0];
		MM = av[1];
		YYYY = av[2];
	}
	else
	{
		MM = av[0];
		DD = av[1];
		YYYY = av[2];
	}

	var ts = new Date(YYYY, MM - 1, DD, 0, 0, 0);
	if (
		ts.getDate()     != DD     ||
		ts.getMonth()    != MM - 1 ||
		ts.getFullYear() != YYYY 
	   )
	{
		return null;
	}
	
	DD = ts.getDate();
	MM = ts.getMonth() + 1;
	YYYY = ts.getFullYear();
	
	if (DD < 10) DD = '0' + parseInt(DD);
	if (MM < 10) MM = '0' + parseInt(MM);

	var r;
	if (language == 'it')
		r = DD + '/' + MM + '/' + YYYY;
	else
		r = MM + '/' + DD + '/' + YYYY;

	return r;
}

function SimplePopupCalendar_RetCal(y,m,d, c, defaultHour, language)
{
	if (parseInt(d) < 10) d = '0' + parseInt(d);	
	if (parseInt(m) < 10) m = '0' + parseInt(m);	
	var nuovaData;
	if (language == 'it')
		nuovaData = d + '/' + m + '/' + y;
	else
		nuovaData = m + '/' + d + '/' + y;

	if (defaultHour == '')
	{
		c.value = nuovaData;
		return;
	}

	var arg = c.value;
	var av   = arg.split(/[ \/:.]/);

	var DD,MM,YYYY;
	if (language == 'it')
	{
		DD   = av[0];
		MM   = av[1];
		YYYY = av[2];
	}
	else
	{
		MM   = av[0];
		DD   = av[1];
		YYYY = av[2];
	}

	var HH = av[3];
	var MI = av[4];
	var SS = av[5];

	var ts = new Date(YYYY, MM - 1, DD, HH, MI, SS);
	if (
		ts.getDate()     != DD     ||
		ts.getMonth()    != MM - 1 ||
		ts.getFullYear() != YYYY   ||
		ts.getHours()    != HH     ||
		ts.getMinutes()  != MI     ||
		ts.getSeconds()  != SS
	   )
	{
		// non c'era un data valida - non riesco a capire l'ora --> metto l'ora di default
		c.value = nuovaData + ' ' + defaultHour;
	}
	else
	{
		// recupero la vecchia ora
		HH = parseInt(HH);
		MI = parseInt(MI);
		SS = parseInt(SS);
		if (HH < 10) HH = '0' + HH;
		if (MI < 10) MI = '0' + MI;
		if (SS < 10) SS = '0' + SS;

		c.value = nuovaData + ' ' + HH + '.' + MI + '.' + SS;
	}
}
";
				csm.RegisterClientScriptBlock(this.GetType(), "SimplePopupCalendar_scripts", s, true);
			}

			this.EnsureChildControls();


			if (!csm.IsClientScriptBlockRegistered("SimplePopupCalendar_scripts_" + this.ClientID))
			{
				string nl = Environment.NewLine;
				string gg = string.Empty;

				gg += @"
var scal_{0} = SimplePopupCalendar_Crea({4}, '{3}', 'SimplePopupCalendar_RetCal_{0}', '{5}', '{6}');

function SimplePopupCalendar_RetCal_{0}(y,m,d)
{
	var c = document.getElementById('{1}');
	SimplePopupCalendar_RetCal(y, m, d, c, '{2}', '{3}');
}
";

				Control t = this.FindControl(ControlToReadWriteDate);
				if (t == null)
					t = this.Parent.FindControl(ControlToReadWriteDate);
				if (t == null)
					throw new ApplicationException(string.Format("{0}: non trovo il controllo da cui prendere la data", this.ID));

				string language = CultureInfo.CurrentCulture.Name.ToUpper() == "IT-IT" ? "it" : "en";

				gg = gg.Replace("{0}", this.ClientID);
				gg = gg.Replace("{1}", t.ClientID);
				gg = gg.Replace("{2}", this.DefaultHour);
				gg = gg.Replace("{3}", language);
				gg = gg.Replace("{4}", this.UseDIV ? "true" : "false");

				gg = gg.Replace("{5}", this.OffsetX);
				gg = gg.Replace("{6}", this.OffsetY);

				csm.RegisterStartupScript(this.GetType(), "PopupCalendar_scripts_" + this.ClientID, gg, true);
			}

			if (true)
			{
				Control t = this.FindControl(ControlToReadWriteDate);
				if (t == null)
					t = this.Parent.FindControl(ControlToReadWriteDate);
				if (t == null)
					throw new ApplicationException(string.Format("{0}: non trovo il controllo da cui prendere la data", this.ID));

				string c = string.Format("document.getElementById('{0}')", t.ClientID);
				string a = _l.ClientID;
				string s;
				if ((CultureInfo.CurrentCulture.Name.ToUpper() == "IT-IT"))
					s = string.Format("scal_{2}.select({0}, '{1}', 'dd/MM/yyyy', SimplePopupCalendar_estraiData({0}.value, 'it')); return false;", c, a, this.ClientID);
				else
					s = string.Format("scal_{2}.select({0}, '{1}', 'MM/dd/yyyy', SimplePopupCalendar_estraiData({0}.value, 'en')); return false;", c, a, this.ClientID);
				_l.Attributes["onclick"] = s;
			}
		}

		HtmlAnchor _l;


		protected override void CreateChildControls()
		{
			_l = new HtmlAnchor();
			_l.ID = "linkData";
			_l.HRef = "#";
			{
				HtmlImage img = new HtmlImage();
				if (string.IsNullOrEmpty(ImagePath))
					img.Src = "PopupCalendar/PopupCalendar.gif";
				else
					img.Src = this.ImagePath;

				img.Border = 0;
				_l.Controls.Add(img);
			}

			this.Controls.Add(_l);


			base.CreateChildControls();

			this.ChildControlsCreated = true;
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			if (this.DesignMode)
				this.EnsureChildControls();
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			EnsureChildControls();
		}

		private T ReadViewStateProperty<T>(string key, T defValue)
		{
			object obj = ViewState[key];
			if (obj != null) return (T)obj;
			return defValue;
		}

		private void WriteViewStateProperty<T>(string key, T value)
		{
			base.ViewState[key] = value;
		}
	}
}
