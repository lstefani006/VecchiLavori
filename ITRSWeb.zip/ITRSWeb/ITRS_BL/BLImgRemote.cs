using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

using Oracle.DataAccess.Client;

namespace ITRS_BL
{
	public partial class BLImgRemote : Component
	{
		public BLImgRemote()
		{
			InitializeComponent();
		}

		public BLImgRemote(IContainer container)
		{
			container.Add(this);

			InitializeComponent();
		}


		public byte[] GetImgFromC2P(string qmgr, string targa, DateTime dtOraRilevamento)
		{
			try
			{
				// ODBC=DSN=stl;UID=stl;PWD=stl
				string db = qmgr;


				string tsStr = dtOraRilevamento.ToString("yyyy MM dd HH mm ss");

				byte[] ret = null;

				// connettersi al db opportuno
				using (OracleConnection cn = new OracleConnection())
				{
					cn.ConnectionString = string.Format("Data Source={0}; User ID=stl; Password=stl;", db);
					cn.Open();

					using (OracleCommand cmd = cn.CreateCommand())
					{
						cmd.CommandText = @"
select
immagine_posteriore
from
dati_immagini_in IMG
inner join transiti TR
on TR.id_Uni = IMG.id_Uni
where
IMG.NUMERO_TARGA = '" + targa + @"'
and TR.DATA_ORA_INGRESSO = to_date('" + tsStr + @"', 'YYYY MM DD HH24 MI SS')
";



						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							while (rd.Read())
							{
								if (!rd.IsDBNull(0))
								{
									ret = (byte[])rd[0];
									break;
								}
							}
						}
					}
				}

				// scaricare l'immagine

				return ret;
			}
			catch (Exception ex)
			{
				string f = String.Format("qmgr={0} t={1} dt={2}", qmgr, targa, dtOraRilevamento);
				Log.Write(ex, f);
				return null;
			}
		}
	}
}
