//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	using System;

	/// <summary>
	/// Provides means to manipulate general-purpose collections.
	/// </summary>
	/// <typeparam name="T">
	/// The element type of the <see cref="ICollection&lt;T&gt;"/>.
	/// </typeparam>
    public interface ICollection<T> : IReadOnlyCollection<T>
	{
		/// <summary>
		/// Adds the <paramref name="Item"/> to
		/// the <see cref="ICollection&lt;T&gt;"/>. 
		/// </summary>
		/// <param name="Item">
		/// The object to add to the <see cref="ICollection&lt;T&gt;"/>.
		/// </param>
		/// <returns>
		/// <c>true</c> if <paramref name="Item"/> was successfully added to the
		/// <see cref="ICollection&lt;T&gt;"/>; otherwise, <c>false</c>.
		/// This method also returns <c>false</c> if a particular
		/// <see cref="ICollection&lt;T&gt;"/> implementation supports only unique
		/// elements and the collection already contains the specified <paramref name="Item"/>.
		/// </returns>
		bool Add(T Item);

		/// <summary>
		/// Removes the <paramref name="Item"/> from
		/// the <see cref="ICollection&lt;T&gt;"/>. 
		/// </summary>
		/// <param name="Item">
		/// The object to remove from the <see cref="ICollection&lt;T&gt;"/>.
		/// </param>
		/// <returns>
		/// <para>
		/// <c>true</c> if <paramref name="Item"/> was successfully removed from the
		/// <see cref="ICollection&lt;T&gt;"/>; otherwise, <c>false</c>. This method
		/// also returns <c>false</c> if <paramref name="Item"/> is not found
		/// in the original <see cref="ICollection&lt;T&gt;"/>.
		/// </para>
		/// <para>
		/// Implementations can vary in how they deal with single or multiple occurences
		/// of an element in the <see cref="ICollection&lt;T&gt;"/> and in which order
		/// the elements are removed.
		/// </para>
		/// </returns>
		bool Remove(T Item);

		/// <summary>
		/// Removes all items from the <see cref="ICollection&lt;T&gt;"/>.
		/// </summary>
		/// <remarks>
		/// <see cref="IReadOnlyCollection&lt;T&gt;.Count"/> must be set to zero, and
		/// references to other objects from elements of the collection must be released.
		/// </remarks>
		void Clear();

	}
}