//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	using System;

	/// <summary>
	/// Represents a balanced binary search tree.
	/// </summary>
	/// <remarks>
	/// <para>
	/// This binary search tree is kept balanced using the AVL algorithm invented
	/// by G.M. Adelson-Velsky and E.M. Landis.
	/// </para>
	/// <para>
	/// <see cref="BalancedBinaryTree&lt;T&gt;"/> provides guaranteed O(log2 n) time cost for
	/// the <see cref="Add"/>, <see cref="Contains"/>, and <see cref="Remove"/> operations.
	/// </para>
	/// <para>
	/// <see cref="BalancedBinaryTree&lt;T&gt;"/> elements must be immutable for the
	/// <see cref="IComparable&lt;T&gt;"/> interface as long as they are used in the tree.
	/// Every element in the <see cref="BalancedBinaryTree&lt;T&gt;"/> must be unique.
	/// An element cannot be a <c>null</c> reference.
	/// </para>
	/// </remarks>
	/// <typeparam name="T">
	/// The element type of the <see cref="BalancedBinaryTree&lt;T&gt;"/>.
	/// </typeparam>
	public sealed class BalancedBinaryTree<T> : ICollection<T> where T : IComparable<T>
	{
		/// <summary>
		/// Represents a node in a balanced binary search tree.
		/// </summary>
		/// <remarks>
		/// The <see cref="Node"/> contains a value, a reference to the parent node,
		/// a reference to the left child node, a reference to the right child node,
		/// and a balance factor for this node.
		/// </remarks>
		internal sealed class Node
		{
			/// <summary>
			/// The object contained in this node.
			/// </summary>
			public T Item;

			/// <summary>
			/// The reference to the parent node of this <see cref="Node"/> or <c>null</c>
			/// if this <see cref="Node"/> is the root node in the balanced binary tree.
			/// </summary>
			public Node Parent;

			/// <summary>
			/// The reference to the left child node of this <see cref="Node"/>
			/// or <c>null</c> if this <see cref="Node"/> has no left child node.
			/// </summary>
			public Node Left;

			/// <summary>
			/// The reference to the right child node of this <see cref="Node"/>
			/// or <c>null</c> if this <see cref="Node"/> has no right child node.
			/// </summary>
			public Node Right;

			/// <summary>
			/// The balance factor of this node.
			/// </summary>
			/// <remarks>
			/// The balance factor of a node is the height of its right subtree minus the height
			/// of its left subtree. A node with balance factor 1, 0, or -1 is considered balanced.
			/// A node with balance factor -2 or 2 is considered unbalanced and requires rebalancing
			/// the tree.
			/// </remarks>
			public sbyte Balance;

			/// <summary>
			/// Initializes a new instance of the <see cref="Node"/> class containing the
			/// specified value.
			/// </summary>
			/// <param name="Item">
			/// The object to contain in the <see cref="Node"/>.
			/// </param>
			/// <remarks>
			/// The <see cref="Parent"/>, <see cref="Left"/>, and <see cref="Right"/> fields are
			/// initialized to <c>null</c>. The <see cref="Balance"/> factor field is initialized
			/// to zero.
			/// </remarks>
			public Node(T Item)
			{
				this.Item = Item;
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="Node"/> class containing the
			/// specified value and the reference to the parent node of this <see cref="Node"/>.
			/// </summary>
			/// <param name="Item">
			/// The object to contain in the <see cref="Node"/>.
			/// </param>
			/// <param name="Parent">
			/// The reference to the parent node of this <see cref="Node"/>.
			/// </param>
			/// <remarks>
			/// The <see cref="Left"/> and <see cref="Right"/> fields are initialized to
			/// <c>null</c>. The <see cref="Balance"/> factor field is initialized to zero.
			/// </remarks>
			public Node(T Item, Node Parent)
			{
				this.Item	= Item;
				this.Parent	= Parent;
			}
		}

		/// <summary>
		/// Enumerates the elements of the <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </summary>
		/// <remarks>
		/// <para>
		/// The elements are enumerated in ascending order.
		/// </para>
		/// <para>
		/// Initially, the enumerator is positioned before the first element in the collection.
		/// At this position, <see cref="Current"/> is undefined. Therefore, you must call
		/// <see cref="MoveNext"/> to advance the enumerator to the first element of the
		/// collection before reading the value of <see cref="Current"/>.
		/// </para>
		/// <para>
		/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/> is
		/// called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
		/// </para>
		/// <para>
		/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is
		/// positioned after the last element in the collection and <see cref="MoveNext"/>
		/// returns <c>false</c>. When the enumerator is at this position, subsequent calls to
		/// <see cref="MoveNext"/> also return <c>false</c>. If the last call to
		/// <see cref="MoveNext"/> returned <c>false</c>, <see cref="Current"/> is undefined.
		/// You cannot set <see cref="Current"/> to the first element of the collection again;
		/// you must create a new enumerator instance instead.
		/// </para>
		/// </remarks>
		public struct AscendingOrderEnumerator : IEnumerator<T>
		{
			/// <summary>
			/// The <see cref="Node"/> at the current position of the enumerator.
			/// </summary>
			private Node _Next;

			/// <summary>
			/// The element at the current position of the enumerator.
			/// </summary>
			private T _Current;

			/// <summary>
			/// Gets the element at the current position of the enumerator. 
			/// </summary>
			/// <value>
			/// The element in the <see cref="BalancedBinaryTree&lt;T&gt;"/> at the current
			/// position of the enumerator.
			/// </value>
			/// <remarks>
			/// <para>
			/// <see cref="Current"/> is undefined under any of the following conditions:
			/// 1) The enumerator is positioned before the first element in the collection,
			/// immediately after the enumerator is created. <see cref="MoveNext"/> must be
			/// called to advance the enumerator to the first element of the collection
			/// before reading the value of <see cref="Current"/>; 2) The last call to
			/// <see cref="MoveNext"/> returned <c>false</c>, which indicates the end of
			/// the collection.
			/// </para>
			/// <para>
			/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/>
			/// is called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
			/// </para>
			/// </remarks>
			public T Current
			{
				get
				{
					return this._Current;
				}
			}

			/// <summary>
			/// Advances the enumerator to the next element of the
			/// <see cref="BalancedBinaryTree&lt;T&gt;"/>.
			/// </summary>
			/// <returns>
			/// <c>true</c> if the enumerator was successfully advanced to the next element;
			/// <c>false</c> if the enumerator has passed the end of the collection.
			/// </returns>
			/// <remarks>
			/// <para>
			/// After an enumerator is created, the enumerator is positioned before the first element
			/// in the collection, and the first call to <see cref="MoveNext"/> advances the
			/// enumerator to the first element of the collection.
			/// </para>
			/// <para>
			/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is positioned
			/// after the last element in the collection and <see cref="MoveNext"/> returns <c>false</c>.
			/// When the enumerator is at this position, subsequent calls to <see cref="MoveNext"/>
			/// also return <c>false</c>.
			/// </para> 
			/// </remarks>
			public bool MoveNext()
			{
				if (this._Next == null)
				{
					return false;
				}

				this._Current = this._Next.Item;

				if (this._Next.Right == null)
				{
					while((this._Next.Parent != null) && (this._Next == this._Next.Parent.Right))
					{
						this._Next = this._Next.Parent;
					}

					this._Next = this._Next.Parent;
				}
				else
				{
					for(this._Next = this._Next.Right; this._Next.Left != null; this._Next = this._Next.Left);
				}

				return true;
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="AscendingOrderEnumerator"/>
			/// structure with the specified <paramref name="Node"/>.
			/// </summary>
			/// <param name="Node">
			/// The node from which to start enumerating the
			/// <see cref="BalancedBinaryTree&lt;T&gt;"/> elements.
			/// </param>
			internal AscendingOrderEnumerator(Node Node)
			{
				if (Node != null)
				{
					while (Node.Left != null)
					{
						Node = Node.Left;
					}
				}

				this._Next		= Node;
				this._Current	= default(T);
			}
		}

		/// <summary>
		/// The root node of this <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </summary>
		private Node _Root;

		/// <summary>
		/// The number of elements contained in this <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </summary>
		private int _Count;

		/// <summary>
		/// Gets the number of elements contained in this <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </summary>
		/// <value>
		/// The number of elements contained in this <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </value>
		/// <remarks>
		/// Retrieving the value of this property is an O(1) operation.
		/// </remarks>
		public int Count
		{
			get
			{
				return this._Count;
			}
		}

		/// <summary>
		/// Adds the specified <paramref name="Item"/> to this
		/// <see cref="BalancedBinaryTree&lt;T&gt;"/> if it is not already present.
		/// </summary>
		/// <param name="Item">
		/// The item to be added to this <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </param>
		/// <returns>
		/// <c>true</c> if this <see cref="BalancedBinaryTree&lt;T&gt;"/> did not
		/// already contain the specified <paramref name="Item"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Item"/> is a <c>null</c> reference.
		/// </exception>
		public bool Add(T Item)
		{
			if (Item == null)
			{
				throw new ArgumentNullException();
			}

			if (this._Root == null)
			{
				this._Root = new Node(Item);
			}
			else
			{
				Node p = this._Root;

				for(;;)
				{
					int Comparer = Item.CompareTo(p.Item);

					if (Comparer < 0)
					{
						if (p.Left != null)
						{
							p = p.Left;
						}
						else
						{
							p.Left = new Node(Item, p);
							p.Balance--;

							break;
						}
					}
					else if (Comparer > 0)
					{
						if (p.Right != null)
						{
							p = p.Right;
						}
						else
						{
							p.Right = new Node(Item, p);
							p.Balance++;

							break;
						}
					}
					else
					{
						return false;
					}
				}

				while ((p.Balance != 0) && (p.Parent != null))
				{
					if (p.Parent.Left == p)
					{
						p.Parent.Balance--;
					}
					else
					{
						p.Parent.Balance++;
					}

					p = p.Parent;

					if (p.Balance == -2)
					{
						Node x = p.Left;

						if (x.Balance == -1)
						{
							x.Parent = p.Parent;

							if (p.Parent == null)
							{
								this._Root = x;
							}
							else
							{
								if (p.Parent.Left == p)
								{
									p.Parent.Left = x;
								}
								else
								{
									p.Parent.Right = x;
								}
							}

							p.Left = x.Right;

							if (p.Left != null)
							{
								p.Left.Parent = p;
							}

							x.Right = p;
							p.Parent = x;

							x.Balance = 0;
							p.Balance = 0;
						}
						else
						{
							Node w = x.Right;

							w.Parent = p.Parent;

							if (p.Parent == null)
							{
								this._Root = w;
							}
							else
							{
								if (p.Parent.Left == p)
								{
									p.Parent.Left = w;
								}
								else
								{
									p.Parent.Right = w;
								}
							}

							x.Right = w.Left;

							if (x.Right != null)
							{
								x.Right.Parent = x;
							}

							p.Left = w.Right;

							if (p.Left != null)
							{
								p.Left.Parent = p;
							}

							w.Left = x;
							w.Right = p;

							x.Parent = w;
							p.Parent = w;

							if (w.Balance == -1)
							{
								x.Balance = 0;
								p.Balance = 1;
							}
							else if (w.Balance == 0)
							{
								x.Balance = 0;
								p.Balance = 0;
							}
							else // w.Balance == 1
							{
								x.Balance = -1;
								p.Balance = 0;
							}

							w.Balance = 0;
						}

						break;
					}
					else if (p.Balance == 2)
					{
						Node x = p.Right;

						if (x.Balance == 1)
						{
							x.Parent = p.Parent;

							if (p.Parent == null)
							{
								this._Root = x;
							}
							else
							{
								if (p.Parent.Left == p)
								{
									p.Parent.Left = x;
								}
								else
								{
									p.Parent.Right = x;
								}
							}

							p.Right = x.Left;

							if (p.Right != null)
							{
								p.Right.Parent = p;
							}

							x.Left = p;
							p.Parent = x;

							x.Balance = 0;
							p.Balance = 0;
						}
						else
						{
							Node w = x.Left;

							w.Parent = p.Parent;

							if (p.Parent == null)
							{
								this._Root = w;
							}
							else
							{
								if (p.Parent.Left == p)
								{
									p.Parent.Left = w;
								}
								else
								{
									p.Parent.Right = w;
								}
							}

							x.Left = w.Right;

							if (x.Left != null)
							{
								x.Left.Parent = x;
							}

							p.Right = w.Left;

							if (p.Right != null)
							{
								p.Right.Parent = p;
							}

							w.Right = x;
							w.Left = p;

							x.Parent = w;
							p.Parent = w;

							if (w.Balance == 1)
							{
								x.Balance = 0;
								p.Balance = -1;
							}
							else if (w.Balance == 0)
							{
								x.Balance = 0;
								p.Balance = 0;
							}
							else // w.Balance == -1
							{
								x.Balance = 1;
								p.Balance = 0;
							}

							w.Balance = 0;
						}

						break;
					}
				}
			}

			this._Count++;
			return true;
		}

		/// <summary>
		/// Removes all elements from this <see cref="BalancedBinaryTree&lt;T&gt;"/>. 
		/// </summary>
		/// <remarks>
		/// <para>
		/// This method is an O(1) operation.
		/// </para>
		/// <para>
		/// The <see cref="Count"/> property is set to zero, and references to other
		/// objects from elements of the collection are also released.
		/// </para>
		/// </remarks>
		public void Clear()
		{
			this._Root	= null;
			this._Count = 0;
		}

		/// <summary>
		/// Determines whether this <see cref="BalancedBinaryTree&lt;T&gt;"/>
		/// contains a specific item.
		/// </summary>
		/// <param name="Item">
		/// The item to locate in this <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </param>
		/// <returns>
		/// <c>true</c>, if <paramref name="Item"/> is found in this
		/// <see cref="BalancedBinaryTree&lt;T&gt;"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Item"/> is a <c>null</c> reference.
		/// </exception>
		public bool Contains(T Item)
		{
			if (Item == null)
			{
				throw new ArgumentNullException();
			}

			for (Node p = this._Root; p != null; )
			{
				int Comparer = Item.CompareTo(p.Item);

				if (Comparer < 0)
				{
					p = p.Left;
				}
				else if (Comparer > 0)
				{
					p = p.Right;
				}
				else
				{
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Copies the <see cref="BalancedBinaryTree&lt;T&gt;"/> elements to
		/// an existing one-dimensional <see cref="Array"/>, starting at the
		/// specified array index.
		/// </summary>
		/// <param name="Array">
		/// The one-dimensional <see cref="Array"/> that is the destination of the elements
		/// copied from this <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// <paramref name="Array"/> must have zero-based indexing.
		/// </param>
		/// <param name="Index">
		/// The zero-based index in <paramref name="Array"/> at which copying begins.
		/// </param>
		/// <remarks>
		/// <para>
		/// The elements are copied to <paramref name="Array"/> in ascending order.
		/// </para>
		/// <para>
		/// This method is an O(n) operation, where n is
		/// <see cref="Count"/>.
		/// </para>
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Array"/> is a <c>null</c> reference.
		/// </exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="Index"/> is outside of <paramref name="Array"/> bounds.
		/// </exception>
		/// <exception cref="ArgumentException">
		/// The number of elements in the source <see cref="BalancedBinaryTree&lt;T&gt;"/>
		/// is greater than the available space from <paramref name="Index"/> to the end
		/// of the destination <paramref name="Array"/>.
		/// </exception>
		public void CopyTo(T[] Array, int Index)
		{
			if (Array == null)
			{
				throw new ArgumentNullException();
			}

			if ((Index < 0) || (Index >= Array.Length))
			{
				throw new ArgumentOutOfRangeException();
			}

			if ((Array.Length - Index) < this._Count)
			{
				throw new ArgumentException();
			}

			if (this._Root != null)
			{
				Node p = this._Root;

				while (p.Left != null)
				{
					p = p.Left;
				}

				for(;;)
				{
					Array[Index] = p.Item;

					if (p.Right == null)
					{
						for(;;)
						{
							if (p.Parent == null)
							{
								return;
							}

							if (p != p.Parent.Right)
							{
								break;
							}

							p = p.Parent;
						}

						p = p.Parent;
					}
					else
					{
						for (p = p.Right; p.Left != null; p = p.Left);
					}

					Index++;
				}
			}
		}

		/// <summary>
		/// Returns an enumerator that iterates through the <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </summary>
		/// <returns>
		/// An <see cref="AscendingOrderEnumerator"/> for the <see cref="BalancedBinaryTree&lt;T&gt;"/>.
		/// </returns>
		public AscendingOrderEnumerator GetEnumerator()
		{
			return new AscendingOrderEnumerator(this._Root);
		}

		/// <summary>
		/// Removes the specified <paramref name="Item"/> from this
		/// <see cref="BalancedBinaryTree&lt;T&gt;"/> if it is present. 
		/// </summary>
		/// <param name="Item">
		/// The item to be removed from this <see cref="BalancedBinaryTree&lt;T&gt;"/>,
		/// if present.
		/// </param>
		/// <returns>
		/// <c>true</c> if this <see cref="BalancedBinaryTree&lt;T&gt;"/>
		/// contained the specified <paramref name="Item"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Item"/> is a <c>null</c> reference.
		/// </exception>
		public bool Remove(T Item)
		{
			if (Item == null)
			{
				throw new ArgumentNullException();
			}

			for (Node p = this._Root; p != null; )
			{
				int Comparer = Item.CompareTo(p.Item);

				if (Comparer < 0)
				{
					p = p.Left;
				}
				else if (Comparer > 0)
				{
					p = p.Right;
				}
				else
				{
					Node y; // node from which rebalancing begins

					if (p.Right == null)	// Case 1: p has no right child
					{
						if (p.Left != null)
						{
							p.Left.Parent = p.Parent;
						}

						if (p.Parent == null)
						{
							this._Root = p.Left;

							goto Done;
						}

						if (p == p.Parent.Left)
						{
							p.Parent.Left = p.Left;

							y = p.Parent;
							// goto LeftDelete;
						}
						else
						{
							p.Parent.Right = p.Left;

							y = p.Parent;
							goto RightDelete;
						}
					}
					else if (p.Right.Left == null)	// Case 2: p's right child has no left child
					{
						if (p.Left != null)
						{
							p.Left.Parent = p.Right;
							p.Right.Left = p.Left;
						}

						p.Right.Balance = p.Balance;
						p.Right.Parent = p.Parent;

						if (p.Parent == null)
						{
							this._Root = p.Right;
						}
						else
						{
							if (p == p.Parent.Left)
							{
								p.Parent.Left = p.Right;
							}
							else
							{
								p.Parent.Right = p.Right;
							}
						}

						y = p.Right;

						goto RightDelete;
					}
					else	// Case 3: p's right child has a left child
					{
						Node s = p.Right.Left;

						while (s.Left != null)
						{
							s = s.Left;
						}

						if (p.Left != null)
						{
							p.Left.Parent = s;
							s.Left = p.Left;
						}

						s.Parent.Left = s.Right;

						if (s.Right != null)
						{
							s.Right.Parent = s.Parent;
						}

						p.Right.Parent = s;
						s.Right = p.Right;

						y = s.Parent; // for rebalacing, must be set before we change s.Parent

						s.Balance = p.Balance;
						s.Parent = p.Parent;

						if (p.Parent == null)
						{
							this._Root = s;
						}
						else
						{
							if (p == p.Parent.Left)
							{
								p.Parent.Left = s;
							}
							else
							{
								p.Parent.Right = s;
							}
						}

						// goto LeftDelete;
					}

					// rebalancing begins

					LeftDelete:

					y.Balance++;

					if (y.Balance == 1)
					{
						goto Done;
					}
					else if (y.Balance == 2)
					{
						Node x = y.Right;

						if (x.Balance == -1)
						{
							Node w = x.Left;

							w.Parent = y.Parent;

							if (y.Parent == null)
							{
								this._Root = w;
							}
							else
							{
								if (y.Parent.Left == y)
								{
									y.Parent.Left = w;
								}
								else
								{
									y.Parent.Right = w;
								}
							}

							x.Left = w.Right;

							if (x.Left != null)
							{
								x.Left.Parent = x;
							}

							y.Right = w.Left;

							if (y.Right != null)
							{
								y.Right.Parent = y;
							}

							w.Right = x;
							w.Left = y;

							x.Parent = w;
							y.Parent = w;

							if (w.Balance == 1)
							{
								x.Balance = 0;
								y.Balance = -1;
							}
							else if (w.Balance == 0)
							{
								x.Balance = 0;
								y.Balance = 0;
							}
							else // w.Balance == -1
							{
								x.Balance = 1;
								y.Balance = 0;
							}

							w.Balance = 0;

							y = w; // for next iteration
						}
						else
						{						
							x.Parent = y.Parent;

							if (y.Parent != null)
							{
								if (y.Parent.Left == y)
								{
									y.Parent.Left = x;
								}
								else
								{
									y.Parent.Right = x;
								}
							}
							else
							{
								this._Root = x;
							}

							y.Right = x.Left;

							if (y.Right != null)
							{
								y.Right.Parent = y;
							}

							x.Left = y;
							y.Parent = x;

							if (x.Balance == 0)
							{
								x.Balance = -1;
								y.Balance = 1;

								goto Done;
							}
							else
							{
								x.Balance = 0;
								y.Balance = 0;

								y = x; // for next iteration
							}
						}
					}

					goto LoopTest;


					RightDelete:

					y.Balance--;

					if (y.Balance == -1)
					{
						goto Done;
					}
					else if (y.Balance == -2)
					{
						Node x = y.Left;

						if (x.Balance == 1)
						{
							Node w = x.Right;

							w.Parent = y.Parent;

							if (y.Parent == null)
							{
								this._Root = w;
							}
							else
							{
								if (y.Parent.Left == y)
								{
									y.Parent.Left = w;
								}
								else
								{
									y.Parent.Right = w;
								}
							}

							x.Right = w.Left;

							if (x.Right != null)
							{
								x.Right.Parent = x;
							}

							y.Left = w.Right;

							if (y.Left != null)
							{
								y.Left.Parent = y;
							}

							w.Left = x;
							w.Right = y;

							x.Parent = w;
							y.Parent = w;

							if (w.Balance == -1)
							{
								x.Balance = 0;
								y.Balance = 1;
							}
							else if (w.Balance == 0)
							{
								x.Balance = 0;
								y.Balance = 0;
							}
							else // w.Balance == 1
							{
								x.Balance = -1;
								y.Balance = 0;
							}

							w.Balance = 0;

							y = w; // for next iteration
						}
						else
						{						
							x.Parent = y.Parent;

							if (y.Parent != null)
							{
								if (y.Parent.Left == y)
								{
									y.Parent.Left = x;
								}
								else
								{
									y.Parent.Right = x;
								}
							}
							else
							{
								this._Root = x;
							}

							y.Left = x.Right;

							if (y.Left != null)
							{
								y.Left.Parent = y;
							}

							x.Right = y;
							y.Parent = x;

							if (x.Balance == 0)
							{
								x.Balance = 1;
								y.Balance = -1;

								goto Done;
							}
							else
							{
								x.Balance = 0;
								y.Balance = 0;

								y = x; // for next iteration
							}
						}
					}

					LoopTest:

					if (y.Parent != null)
					{
						if (y == y.Parent.Left)
						{
							y = y.Parent;
							goto LeftDelete;
						}

						y = y.Parent;
						goto RightDelete;
					}

					Done:
					
					this._Count--;
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="BalancedBinaryTree&lt;T&gt;"/> class.
		/// </summary>
		/// <remarks>
		/// This constructor is an O(1) operation.
		/// </remarks>
		public BalancedBinaryTree()
		{
			this._Root	= null;
			this._Count	= 0;
		}

		#region Testing

		internal void TreeTest()
		{
			int c = 0;
			int h = 0;

			AvlTreeTest(this._Root, ref c, ref h);

			//System.Console.WriteLine("\n\n   * TEST: items count: " + c.ToString() + ", tree height: " + h.ToString());
		}

		private void AvlTreeTest(BalancedBinaryTree<T>.Node node, ref int count, ref int height)
		{
			if (node == null)
			{
				count = 0;
				height = 0;
				return;
			}

			int heightL = 0, heightR = 0;
			int countL = 0, countR = 0;

			AvlTreeTest(node.Left, ref countL, ref heightL);
			AvlTreeTest(node.Right, ref countR, ref heightR);

			count = 1 + countL + countR;
			height = 1 + (heightL > heightR ? heightL : heightR);

			if ((heightR - heightL) != node.Balance)
			{
				//System.Console.WriteLine("   * ERROR: balance factor of node {" + node.Item.ToString() + "} is " + node.Balance.ToString() + ", but should be " + (heightR - heightL).ToString());
			}
			else if (node.Balance < -1 || node.Balance > 1)
			{
				//System.Console.WriteLine("   * ERROR: balance factor of node {" + node.Item.ToString() + "} is " + node.Balance.ToString());
			}
		}

		#endregion

	}
}