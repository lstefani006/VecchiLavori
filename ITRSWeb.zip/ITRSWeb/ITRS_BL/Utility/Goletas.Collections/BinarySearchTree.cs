//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	using System;

	/// <summary>
	/// Represents a binary search tree.
	/// </summary>
	/// <remarks>
	/// <para>
	/// A binary search tree is a binary tree where every node's left subtree
    /// has keys less than the node's key, and every right subtree has keys
    /// greater than the node's key.
	/// </para>
	/// <para>
	/// The <see cref="BinarySearchTree&lt;T&gt;"/> is not balanced. For random
	/// data inputs <see cref="BinarySearchTree&lt;T&gt;"/> provides approximately
	/// O(log2 n) time cost for the <see cref="Add"/>, <see cref="Contains"/>, and
	/// <see cref="Remove"/> operations in best case, but the operations can be as
	/// worse as O(n) for sorted input.
	/// </para>
	/// <para>
	/// <see cref="BinarySearchTree&lt;T&gt;"/> elements must be immutable for the
	/// <see cref="IComparable&lt;T&gt;"/> interface as long as they are used in the
	/// tree. Every element in the <see cref="BinarySearchTree&lt;T&gt;"/> must be
	/// unique. An element cannot be a <c>null</c> reference.
	/// </para>
	/// <para>
	/// Operations on unbalanced trees for random inputs can be faster than
	/// operations on balanced trees because balanced trees perform additional
	/// work (rebalancing) to keep themselves balanced.
	/// </para>
	/// </remarks>
	/// <typeparam name="T">
	/// The element type of the <see cref="BinarySearchTree&lt;T&gt;"/>.
	/// </typeparam>
    public sealed class BinarySearchTree<T> : ICollection<T> where T : IComparable<T>
	{
		/// <summary>
		/// Represents a node in a binary search tree.
		/// </summary>
		/// <remarks>
		/// The <see cref="Node"/> contains a value, a reference to the parent node,
		/// a reference to the left child node, and a reference to the right child node.
		/// </remarks>
		internal sealed class Node
		{
			/// <summary>
			/// The value contained in this node.
			/// </summary>
			public T Value;

			/// <summary>
			/// The reference to the parent node of this <see cref="Node"/> or <c>null</c>
			/// if this <see cref="Node"/> is the root node in the binary search tree.
			/// </summary>
			public Node Parent;

			/// <summary>
			/// The reference to the left child node of this <see cref="Node"/> or <c>null</c>
			/// if this <see cref="Node"/> has no left child node.
			/// </summary>
			public Node Left;

			/// <summary>
			/// The reference to the right child node of this <see cref="Node"/> or <c>null</c>
			/// if this <see cref="Node"/> has no right child node.
			/// </summary>
			public Node Right;

			/// <summary>
			/// Initializes a new instance of the <see cref="Node"/> class, containing
			/// the specified value.
			/// </summary>
			/// <param name="Value">
			/// The value to contain in the <see cref="Node"/>.
			/// </param>
			/// <remarks>
			/// The <see cref="Parent"/>, <see cref="Left"/>, and <see cref="Right"/>
			/// fields are initialized to <c>null</c>.
			/// </remarks>
			public Node(T Value)
			{
				this.Value = Value;
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="Node"/> class, containing the
			/// specified value and the reference to the parent node of this <see cref="Node"/>.
			/// </summary>
			/// <param name="Value">
			/// The value to contain in the <see cref="Node"/>.
			/// </param>
			/// <param name="Parent">
			/// The reference to the parent node of this <see cref="Node"/>.
			/// </param>
			/// The <see cref="Left"/> and <see cref="Right"/> fields are initialized to <c>null</c>.
			public Node(T Value, Node Parent)
			{
				this.Value  = Value;
				this.Parent = Parent;
			}
		}

		/// <summary>
		/// Enumerates the elements of the <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </summary>
		/// <remarks>
		/// <para>
		/// The elements are enumerated in ascending order.
		/// </para>
		/// <para>
		/// Initially, the enumerator is positioned before the first element in the collection.
		/// At this position, <see cref="Current"/> is undefined. Therefore, you must call
		/// <see cref="MoveNext"/> to advance the enumerator to the first element of the collection
		/// before reading the value of <see cref="Current"/>.
		/// </para>
		/// <para>
		/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/> is called.
		/// <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
		/// </para>
		/// <para>
		/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is positioned
		/// after the last element in the collection and <see cref="MoveNext"/> returns <c>false</c>.
		/// When the enumerator is at this position, subsequent calls to <see cref="MoveNext"/>
		/// also return <c>false</c>. If the last call to <see cref="MoveNext"/> returned <c>false</c>,
		/// <see cref="Current"/> is undefined. You cannot set <see cref="Current"/> to the first
		/// element of the collection again; you must create a new enumerator instance instead.
		/// </para>
		/// </remarks>
		public struct AscendingOrderEnumerator : IEnumerator<T>
		{
			/// <summary>
			/// The <see cref="Node"/> at the current position of the enumerator.
			/// </summary>
			private Node _Next;

			/// <summary>
			/// The element at the current position of the enumerator.
			/// </summary>
			private T _Current;

			/// <summary>
			/// Gets the element at the current position of the enumerator. 
			/// </summary>
			/// <value>
			/// The element in the <see cref="BinarySearchTree&lt;T&gt;"/>
			/// at the current position of the enumerator.
			/// </value>
			/// <remarks>
			/// <para>
			/// <see cref="Current"/> is undefined under any of the following conditions: 1) The enumerator
			/// is positioned before the first element in the collection, immediately after the enumerator
			/// is created. <see cref="MoveNext"/> must be called to advance the enumerator to the first
			/// element of the collection before reading the value of <see cref="Current"/>; 2) The last call
			/// to <see cref="MoveNext"/> returned <c>false</c>, which indicates the end of the collection.
			/// </para>
			/// <para>
			/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/> is called.
			/// <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
			/// </para>
			/// </remarks>
			public T Current
			{
				get
				{
					return this._Current;
				}
			}

			/// <summary>
			/// Advances the enumerator to the next element of the
			/// <see cref="BinarySearchTree&lt;T&gt;"/>.
			/// </summary>
			/// <returns>
			/// <c>true</c> if the enumerator was successfully advanced to the next element;
			/// <c>false</c> if the enumerator has passed the end of the collection.
			/// </returns>
			/// <remarks>
			/// <para>
			/// After an enumerator is created, the enumerator is positioned before the first element
			/// in the collection, and the first call to <see cref="MoveNext"/> advances the enumerator
			/// to the first element of the collection.
			/// </para>
			/// <para>
			/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is positioned
			/// after the last element in the collection and <see cref="MoveNext"/> returns <c>false</c>.
			/// When the enumerator is at this position, subsequent calls to <see cref="MoveNext"/> also
			/// return <c>false</c>.
			/// </para> 
			/// </remarks>
			public bool MoveNext()
			{
				if (this._Next == null)
				{
					return false;
				}

				this._Current = this._Next.Value;

				if (this._Next.Right == null)
				{
					while((this._Next.Parent != null) && (this._Next == this._Next.Parent.Right))
					{
						this._Next = this._Next.Parent;
					}

					this._Next = this._Next.Parent;
				}
				else
				{
					for(this._Next = this._Next.Right; this._Next.Left != null; this._Next = this._Next.Left);
				}

				return true;
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="AscendingOrderEnumerator"/>
			/// structure with the specified <paramref name="Node"/>.
			/// </summary>
			/// <param name="Node">
			/// The node from which to start enumerating the
			/// <see cref="BinarySearchTree&lt;T&gt;"/> elements.
			/// </param>
			internal AscendingOrderEnumerator(Node Node)
			{
				if (Node != null)
				{
					while (Node.Left != null)
					{
						Node = Node.Left;
					}
				}

				this._Next		= Node;
				this._Current	= default(T);
			}
		}

		/// <summary>
		/// The root node of this <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </summary>
        private Node _Root;

		/// <summary>
		/// The number of elements contained in this <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </summary>
		private int _Count;

		/// <summary>
		/// Gets the number of elements contained in this <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </summary>
		/// <value>
		/// The number of elements contained in this <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </value>
		/// <remarks>
		/// Retrieving the value of this property is an O(1) operation.
		/// </remarks>
		public int Count
		{
			get
			{
				return this._Count;
			}
		}

		/// <summary>
		/// Adds the specified <paramref name="Item"/> to this
		/// <see cref="BinarySearchTree&lt;T&gt;"/> if it is not already present.
		/// </summary>
		/// <param name="Item">
		/// The item to be added to this <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </param>
		/// <returns>
		/// <c>true</c> if this <see cref="BinarySearchTree&lt;T&gt;"/> did not
		/// already contain the specified <paramref name="Item"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Item"/> is a <c>null</c> reference.
		/// </exception>
		public bool Add(T Item)
		{
			if (Item == null)
			{
				throw new ArgumentNullException();
			}

			if (this._Root == null)
			{
				this._Root = new Node(Item);
			}
			else
			{
				for(Node p = this._Root; ; )
				{
					int Comparer = Item.CompareTo(p.Value);

					if (Comparer < 0)
					{
						if (p.Left != null)
						{
							p = p.Left;
						}
						else
						{
							p.Left = new Node(Item, p);

							break;
						}
					}
					else if (Comparer > 0)
					{
						if (p.Right != null)
						{
							p = p.Right;
						}
						else
						{
							p.Right = new Node(Item, p);

							break;
						}
					}
					else
					{
						return false;
					}
				}
			}

			this._Count++;
			return true;
		}

		/// <summary>
		/// Removes all of the elements from this <see cref="BinarySearchTree&lt;T&gt;"/>. 
		/// </summary>
		/// <remarks>
		/// <para>
		/// This method is an O(1) operation.
		/// </para>
		/// <para>
		/// The <see cref="Count"/> property is set to zero, and references to other objects
		/// from elements of the collection are also released.
		/// </para>
		/// </remarks>
		public void Clear()
		{
			this._Root	= null;
			this._Count	= 0;
		}

		/// <summary>
		/// Determines whether this <see cref="BinarySearchTree&lt;T&gt;"/>
		/// contains a specific item.
		/// </summary>
		/// <param name="Item">
		/// The item to locate in this <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </param>
		/// <returns>
		/// <c>true</c>, if <paramref name="Item"/> is found in this
		/// <see cref="BinarySearchTree&lt;T&gt;"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Item"/> is a <c>null</c> reference.
		/// </exception>
		public bool Contains(T Item)
		{
			if (Item == null)
			{
				throw new ArgumentNullException();
			}

			for (Node p = this._Root; p != null; )
			{
				int Comparer = Item.CompareTo(p.Value);

				if (Comparer < 0)
				{
					p = p.Left;
				}
				else if (Comparer > 0)
				{
					p = p.Right;
				}
				else
				{
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Copies the <see cref="BinarySearchTree&lt;T&gt;"/> elements to an existing
		/// one-dimensional <see cref="Array"/>, starting at the specified array index.
		/// </summary>
		/// <param name="Array">
		/// The one-dimensional <see cref="Array"/> that is the destination of the elements
		/// copied from this <see cref="BinarySearchTree&lt;T&gt;"/>. <paramref name="Array"/>
		/// must have zero-based indexing.
		/// </param>
		/// <param name="Index">
		/// The zero-based index in <paramref name="Array"/> at which copying begins.
		/// </param>
		/// <remarks>
		/// <para>
		/// The elements are copied to <paramref name="Array"/> in ascending order.
		/// </para>
		/// <para>
		/// This method is an O(n) operation, where n is <see cref="Count"/>.
		/// </para>
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Array"/> is a <c>null</c> reference.
		/// </exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="Index"/> is outside of <paramref name="Array"/> bounds.
		/// </exception>
		/// <exception cref="ArgumentException">
		/// The number of elements in the source <see cref="BinarySearchTree&lt;T&gt;"/>
		/// is greater than the available space from <paramref name="Index"/> to the end
		/// of the destination <paramref name="Array"/>.
		/// </exception>
		public void CopyTo(T[] Array, int Index)
		{
			if (Array == null)
			{
				throw new ArgumentNullException();
			}

			if ((Index < 0) || (Index >= Array.Length))
			{
				throw new ArgumentOutOfRangeException();
			}

			if ((Array.Length - Index) < this._Count)
			{
				throw new ArgumentException();
			}

			if (this._Root != null)
			{
				Node p = this._Root;

				while (p.Left != null)
				{
					p = p.Left;
				}

				for(;;)
				{
					Array[Index] = p.Value;

					if (p.Right == null)
					{
						for(;;)
						{
							if (p.Parent == null)
							{
								return;
							}

							if (p != p.Parent.Right)
							{
								break;
							}

							p = p.Parent;
						}

						p = p.Parent;
					}
					else
					{
						for (p = p.Right; p.Left != null; p = p.Left);
					}

					Index++;
				}
			}
		}

		/// <summary>
		/// Returns an enumerator that iterates through the <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </summary>
		/// <returns>
		/// An <see cref="AscendingOrderEnumerator"/>
		/// for the <see cref="BinarySearchTree&lt;T&gt;"/>.
		/// </returns>
		public AscendingOrderEnumerator GetEnumerator()
		{
			return new AscendingOrderEnumerator(this._Root);
		}

		/// <summary>
		/// Removes the specified <paramref name="Item"/> from this
		/// <see cref="BinarySearchTree&lt;T&gt;"/> if it is present. 
		/// </summary>
		/// <param name="Item">
		/// The item to be removed from this <see cref="BinarySearchTree&lt;T&gt;"/>,
		/// if present.
		/// </param>
		/// <returns>
		/// <c>true</c> if this <see cref="BinarySearchTree&lt;T&gt;"/>
		/// contained the specified <paramref name="Item"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Item"/> is a <c>null</c> reference.
		/// </exception>
		public bool Remove(T Item)
		{
			if (Item == null)
			{
				throw new ArgumentNullException();
			}

			for (Node p = this._Root; p != null; )
			{
				int Comparer = Item.CompareTo(p.Value);

				if (Comparer < 0)
				{
					p = p.Left;
				}
				else if (Comparer > 0)
				{
					p = p.Right;
				}
				else
				{
					if (p.Right == null)	// Case 1: p has no right child
					{
						if (p.Left != null)
						{
							p.Left.Parent = p.Parent;
						}
						
						if (p.Parent == null)
						{
							this._Root = p.Left;
						}
						else
						{
							if (p == p.Parent.Left)
							{
								p.Parent.Left = p.Left;
							}
							else
							{
								p.Parent.Right = p.Left;
							}
						}
					}
					else if (p.Right.Left == null)	// Case 2: p's right child has no left child
					{
						if (p.Left != null)
						{
							p.Left.Parent = p.Right;
							p.Right.Left = p.Left;
						}
						
						p.Right.Parent = p.Parent;
						
						if (p.Parent == null)
						{
							this._Root = p.Right;
						}
						else
						{
							if (p == p.Parent.Left)
							{
								p.Parent.Left = p.Right;
							}
							else
							{
								p.Parent.Right = p.Right;
							}
						}
					}
					else	// Case 3: p's right child has a left child
					{
						Node s = p.Right.Left;

						while (s.Left != null)
						{
							s = s.Left;
						}
						
						if (p.Left != null)
						{
							p.Left.Parent = s;
							s.Left = p.Left;
						}

						s.Parent.Left = s.Right;

						if (s.Right != null)
						{
							s.Right.Parent = s.Parent;
						}

						p.Right.Parent = s;
						s.Right = p.Right;
						
						s.Parent = p.Parent;
						
						if (p.Parent == null)
						{
							this._Root = s;
						}
						else
						{
							if (p == p.Parent.Left)
							{
								p.Parent.Left = s;
							}
							else
							{
								p.Parent.Right = s;
							}
						}
					}

					this._Count--;
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="BinarySearchTree&lt;T&gt;"/>
		/// class.
		/// </summary>
		/// <remarks>
		/// This constructor is an O(1) operation.
		/// </remarks>
		public BinarySearchTree()
		{
			this._Root	= null;
			this._Count	= 0;
		}

	}
}