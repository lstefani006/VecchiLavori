//
// Copyright � 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	public interface IEnumerable<T>
	{
		IEnumerator<T> GetEnumerator();
	}
}