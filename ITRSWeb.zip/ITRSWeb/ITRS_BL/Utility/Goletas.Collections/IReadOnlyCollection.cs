//
// Copyright � 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	using System;

	/// <summary>
	/// Defines basic functionality common to all collections.
	/// </summary>
	/// <remarks>
	/// The <see cref="IReadOnlyCollection&lt;T&gt;"/> interface is the base
	/// interface for classes in the <see cref="Goletas.Collections"/> namespace.
	/// </remarks>
	/// <typeparam name="T">
	/// The element type of the <see cref="IReadOnlyCollection&lt;T&gt;"/>.
	/// </typeparam>
	public interface IReadOnlyCollection<T>
	{
		/// <summary>
		/// Gets the number of elements contained
		/// in the <see cref="IReadOnlyCollection&lt;T&gt;"/>.
		/// </summary>
		/// <value>
		/// The number of elements contained
		/// in the <see cref="IReadOnlyCollection&lt;T&gt;"/>.
		/// </value>
		int Count
		{
			get;
		}

		/// <summary>
		/// Determines whether the <see cref="IReadOnlyCollection&lt;T&gt;"/> contains
		/// a specific value.
		/// </summary>
		/// <param name="Item">
		/// The object to locate in the <see cref="IReadOnlyCollection&lt;T&gt;"/>.
		/// </param>
		/// <returns>
		/// <c>true</c> if <paramref name="Item"/> is found in the
		/// <see cref="IReadOnlyCollection&lt;T&gt;"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// Implementations can vary in how they determine equality of objects.
		/// </remarks>
		bool Contains(T Item);

		/// <summary>
		/// Copies the <see cref="IReadOnlyCollection&lt;T&gt;"/> elements to an existing
		/// one-dimensional <see cref="Array"/>, starting at the specified array index.
		/// </summary>
		/// <param name="Array">
		/// The one-dimensional <see cref="Array"/> that is the destination of the
		/// elements copied from this <see cref="IReadOnlyCollection&lt;T&gt;"/>.
		/// <paramref name="Array"/> must have zero-based indexing.
		/// </param>
		/// <param name="Index">
		/// The zero-based index in <paramref name="Array"/> at which copying begins.
		/// </param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Array"/> is a <c>null</c> reference.
		/// </exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="Index"/> is outside of <paramref name="Array"/> bounds.
		/// </exception>
		/// <exception cref="ArgumentException">
		/// The number of elements in the source <see cref="IReadOnlyCollection&lt;T&gt;"/>
		/// is greater than the available space from <paramref name="Index"/> to the end
		/// of the destination <paramref name="Array"/>.
		/// </exception>
		void CopyTo(T[] Array, int Index);

	}
}