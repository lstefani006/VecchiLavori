//
// Copyright � 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	using System;

	/// <summary>
	/// The exception that is thrown when the key specified for accessing an
	/// element in a collection does not match any key in the collection.
	/// </summary>
	/// <remarks>
	/// <see cref="KeyNotFoundException"/> is thrown when an operation attempts to
	/// retrieve an element from a collection using a key that does not exist in
	/// that collection.
	/// </remarks>
	public sealed class KeyNotFoundException : Exception
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="KeyNotFoundException"/>
		/// class using default property values.
		/// </summary>
		public KeyNotFoundException()
		{

		}
		
	}
}