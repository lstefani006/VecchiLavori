//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	using System;

	/// <summary>
	/// Represents a collection of key/value pairs.
	/// </summary>
	/// <remarks>
	/// <para>
	/// Each element in the <see cref="IDictionary&lt;K,V&gt;"/> interface is a
	/// key/value pair stored in the <see cref="KeyValuePair&lt;K,V&gt;"/> object.
	/// </para>
	/// <para>
	/// Each pair must have a unique <see cref="KeyValuePair&lt;K,V&gt;.Key"/>.
	/// Implementations can vary in whether they allow the key to be a <c>null</c>
	/// reference. The <see cref="KeyValuePair&lt;K,V&gt;.Value"/> can be a <c>null</c>
	/// reference and does not have to be unique. The <see cref="IDictionary&lt;K,V&gt;"/>
	/// interface allows the contained keys and values to be enumerated, but it does not
	/// imply any particular sort order.
	/// </para>
	/// </remarks>
	/// <typeparam name="K">
	/// The type of keys in the <see cref="IDictionary&lt;K,V&gt;"/>.
	/// </typeparam>
	/// <typeparam name="V">
	/// The type of values in the <see cref="IDictionary&lt;K,V&gt;"/>.
	/// </typeparam>
    public interface IDictionary<K, V> : IReadOnlyCollection<KeyValuePair<K, V>>
	{
		/// <summary>
		/// Adds an element with the provided <paramref name="Key"/> and
		/// <paramref name="Value"/> to the <see cref="IDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <param name="Key">
		/// The object to use as the key of the element to add.
		/// </param>
		/// <param name="Value">
		/// The object to use as the value of the element to add.
		/// </param>
		/// <returns>
		/// <c>true</c> if the element was successfully added to the
		/// <see cref="IDictionary&lt;K,V&gt;"/>; otherwise, <c>false</c>.
		/// This method also returns <c>false</c> if a particular
		/// <see cref="IDictionary&lt;K,V&gt;"/> implementation supports only unique
		/// keys and the dictionary already contains the specified <paramref name="Key"/>.
		/// </returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Key"/> is a <c>null</c> reference.
		/// </exception>
		bool Add(K Key, V Value);

		/// <summary>
		/// Gets or sets the element with the specified <paramref name="Key"/>.
		/// </summary>
		/// <param name="Key">
		/// The key of the element to get or set.
		/// </param>
		/// <returns>
		/// The value of the element with the specified <paramref name="Key"/>.
		/// </returns>
		/// <remarks>
		/// You can use the <see cref="this"/> property to add new elements by setting
		/// the value of a key that does not exist in <see cref="IDictionary&lt;K,V&gt;"/>.
		/// If the specified <paramref name="Key"/> already exists in the dictionary,
		/// setting the <see cref="this"/> property overwrites the old value.
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Key"/> is a <c>null</c> reference.
		/// </exception>
		/// <exception cref="KeyNotFoundException">
		/// The property is retrieved and <paramref name="Key"/> is not found.
		/// </exception>
		V this[K Key] { get; set; }

		/// <summary>
		/// Retrieves the value associated with the specified <paramref name="Key"/>. 
		/// </summary>
		/// <param name="Key">
		/// The key whose value to retrieve.
		/// </param>
		/// <param name="Value">
		/// If the key is found, the value associated with the specified <paramref name="Key"/>;
		/// otherwise, the default value for the type of the <paramref name="Value"/> parameter.
		/// </param>
		/// <returns>
		/// <c>true</c> if <see cref="IDictionary&lt;K,V&gt;"/> contains an element with the
		/// specified <paramref name="Key"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Key"/> is a <c>null</c> reference.
		/// </exception>
		bool Retrieve(K Key, out V Value);

		/// <summary>
		/// Gets an <see cref="IReadOnlyCollection&lt;T&gt;"/> containing the keys of the
		/// <see cref="IDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <value>
		/// An <see cref="IReadOnlyCollection&lt;T&gt;"/> containing the keys of the
		/// object that implements <see cref="IDictionary&lt;K,V&gt;"/>. 
		/// </value>
		IReadOnlyCollection<K> Keys { get; }

		/// <summary>
		/// Gets an <see cref="IReadOnlyCollection&lt;T&gt;"/> containing the values of the
		/// <see cref="IDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <value>
		/// An <see cref="IReadOnlyCollection&lt;T&gt;"/> containing the values of the
		/// object that implements <see cref="IDictionary&lt;K,V&gt;"/>. 
		/// </value>
		IReadOnlyCollection<V> Values { get; }

		/// <summary>
		/// Removes the element with the specified <paramref name="Key"/>
		/// from the <see cref="IDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <param name="Key">
		/// The key of the element to remove.
		/// </param>
		/// <returns>
		/// <c>true</c> if the element is successfully removed; otherwise, <c>false</c>.
		/// This method also returns false if <paramref name="Key"/> was not found in
		/// the original <see cref="IDictionary&lt;K,V&gt;"/>.
		/// </returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Key"/> is a <c>null</c> reference.
		/// </exception>
		bool Remove(K Key);

		/// <summary>
		/// Removes all elements from the <see cref="IDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <remarks>
		/// <see cref="IReadOnlyCollection&lt;T&gt;.Count"/> must be set to zero, and
		/// references to other objects from elements of the collection must be released.
		/// </remarks>
		void Clear();

	}
}