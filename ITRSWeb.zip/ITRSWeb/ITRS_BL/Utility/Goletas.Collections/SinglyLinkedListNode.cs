//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
    /// <summary>
    /// Represents a node in a singly linked list.
    /// </summary>
    /// <remarks>
    /// The <see cref="SinglyLinkedListNode&lt;T&gt;"/> contains
	/// a value and a reference to the next node.
    /// </remarks>
	/// <typeparam name="T">
	/// The type of the <see cref="Item"/> contained
	/// in the <see cref="SinglyLinkedListNode&lt;T&gt;"/>.
	/// </typeparam>
    public sealed class SinglyLinkedListNode<T>
    {
        /// <summary>
        /// The object contained in this node.
        /// </summary>
        public T Item;

        /// <summary>
        /// The reference to the next node in the singly linked list or <c>null</c>
		/// if this <see cref="SinglyLinkedListNode&lt;T&gt;"/> is the last node in
		/// the singly linked list.
        /// </summary>
        public SinglyLinkedListNode<T> Next;

		/// <summary>
		/// Initializes a new instance of the <see cref="SinglyLinkedListNode&lt;T&gt;"/>
		/// class containing the specified object.
		/// </summary>
		/// <param name="Item">
		/// The object to contain in the <see cref="SinglyLinkedListNode&lt;T&gt;"/>.
		/// </param>
		/// <remarks>
		/// The <see cref="Next"/> field is initialized to <c>null</c>.
		/// </remarks>
		public SinglyLinkedListNode(T Item)
		{
			this.Item = Item;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="SinglyLinkedListNode&lt;T&gt;"/>
		/// class containing the specified object and the reference to the next node in
		/// the singly linked list.
		/// </summary>
		/// <param name="Item">
		/// The object to contain in the <see cref="SinglyLinkedListNode&lt;T&gt;"/>.
		/// </param>
		/// <param name="Next">
		/// The reference to the next node in the singly linked list.
		/// </param>
        public SinglyLinkedListNode(T Item, SinglyLinkedListNode<T> Next)
		{
			this.Item	= Item;
			this.Next	= Next;
		}

    }
}