//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	using System;

    /// <summary>
    /// Represents a variable size first-in-first-out [FIFO] collection
    /// of objects of the same arbitrary type.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <see cref="LinkedListQueue&lt;T&gt;"/> is implemented as
	/// a singly linked list.
    /// </para>
	/// <para>
	/// <see cref="LinkedListQueue&lt;T&gt;"/> provides O(1) time cost for the
	/// <see cref="Enqueue"/> and <see cref="Dequeue"/> operations.
	/// </para>
    /// <para>
    /// <see cref="LinkedListQueue&lt;T&gt;"/> accepts <c>null</c> as a valid
	/// value for reference types and allows duplicate elements.
    /// </para>
    /// </remarks>
	/// <typeparam name="T">
	/// The element type of the <see cref="LinkedListQueue&lt;T&gt;"/>.
	/// </typeparam>
    public sealed class LinkedListQueue<T> : IReadOnlyCollection<T>
    {
		/// <summary>
		/// Enumerates the elements of a <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// </summary>
		/// <remarks>
		/// <para>
		/// The elements are enumerated in first-in-first-out [FIFO] order, similar to the order
		/// of the elements returned by a succession of calls to the <see cref="Dequeue()"/> method.
		/// </para>
		/// <para>
		/// Initially, the enumerator is positioned before the first element in the collection.
		/// At this position, <see cref="Current"/> is undefined. Therefore, you must call
		/// <see cref="MoveNext"/> to advance the enumerator to the first element of the collection
		/// before reading the value of <see cref="Current"/>.
		/// </para>
		/// <para>
		/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/> is called.
		/// <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
		/// </para>
		/// <para>
		/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is
		/// positioned after the last element in the collection and <see cref="MoveNext"/>
		/// returns <c>false</c>. When the enumerator is at this position, subsequent calls to
		/// <see cref="MoveNext"/> also return <c>false</c>. If the last call to
		/// <see cref="MoveNext"/> returned <c>false</c>, <see cref="Current"/> is undefined.
		/// You cannot set <see cref="Current"/> to the first element of the collection again;
		/// you must create a new enumerator instance instead.
		/// </para>
		/// </remarks>
		public struct Enumerator : IEnumerator<T>
		{
			/// <summary>
			/// The <see cref="SinglyLinkedListNode&lt;T&gt;"/>
			/// at the current position of the enumerator.
			/// </summary>
			private SinglyLinkedListNode<T> _Next;

			/// <summary>
			/// The element at the current position of the enumerator.
			/// </summary>
			private T _Current;

			/// <summary>
			/// Gets the element at the current position of the enumerator. 
			/// </summary>
			/// <value>
			/// The element in the <see cref="LinkedListQueue&lt;T&gt;"/>
			/// at the current position of the enumerator.
			/// </value>
			/// <remarks>
			/// <para>
			/// <see cref="Current"/>
			/// is undefined under any of the following conditions: 1) The enumerator is positioned
			/// before the first element in the collection, immediately after the enumerator is created.
			/// <see cref="MoveNext"/> must be called to advance the enumerator to the first element
			/// of the collection before reading the value of <see cref="Current"/>; 2) The last call
			/// to  <see cref="MoveNext"/> returned <c>false</c>, which indicates the end of the
			/// collection.
			/// </para>
			/// <para>
			/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/>
			/// is called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
			/// </para>
			/// </remarks>
			public T Current
			{
				get
				{
					return this._Current;
				}
			}

			/// <summary>
			/// Advances the enumerator to the next element of the
			/// <see cref="LinkedListQueue&lt;T&gt;"/>.
			/// </summary>
			/// <returns>
			/// <c>true</c> if the enumerator was successfully advanced to the next element;
			/// <c>false</c> if the enumerator has passed the end of the collection.
			/// </returns>
			/// <remarks>
			/// <para>
			/// After an enumerator is created, the enumerator is positioned before the first element
			/// in the collection, and the first call to <see cref="MoveNext"/> advances the enumerator
			/// to the first element of the collection.
			/// </para>
			/// <para>
			/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is
			/// positioned after the last element in the collection and <see cref="MoveNext"/>
			/// returns <c>false</c>. When the enumerator is at this position, subsequent calls
			/// to <see cref="MoveNext"/> also return <c>false</c>.
			/// </para> 
			/// </remarks>
			public bool MoveNext()
			{
				if (this._Next == null)
				{
					return false;
				}

				this._Current	= this._Next.Item;
				this._Next		= this._Next.Next;

				return true;
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="Enumerator"/> structure with
			/// the specified <paramref name="Node"/>.
			/// </summary>
			/// <param name="Node">
			/// The node from which to start enumerating the
			/// <see cref="LinkedListQueue&lt;T&gt;"/> elements.
			/// </param>
			public Enumerator(SinglyLinkedListNode<T> Node)
			{
				this._Next		= Node;
				this._Current	= default(T);
			}
		}

		/// <summary>
		/// The first none in the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// If this node is <c>null</c>, then the queue is empty.
		/// </summary>
		private SinglyLinkedListNode<T> _First;

		/// <summary>
		/// The last node in the <see cref="LinkedListQueue&lt;T&gt;"/>
		/// </summary>
		private SinglyLinkedListNode<T> _Last;

		/// <summary>
		/// The number of elements contained in the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// </summary>
        private int _Count;

		/// <summary>
		/// Gets the number of elements contained
		/// in the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// </summary>
		/// <value>
		/// The number of elements contained in the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// </value>
		/// <remarks>
		/// Retrieving the value of this property is an O(1) operation.
		/// </remarks>
        public int Count
        {
            get
            {
                return this._Count;
            }
        }

        /// <summary>
        /// Adds an object to the end of the <see cref="LinkedListQueue&lt;T&gt;"/>. 
        /// </summary>
        /// <param name="Item">
        /// The object to add to the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// The value can be <c>null</c> for reference types.
        /// </param>
		/// <remarks>
		/// This method is an O(1) operation.
		/// </remarks>
        public void Enqueue(T Item)
        {
            if (this._First != null)
			{
				this._Last.Next = new SinglyLinkedListNode<T>(Item);
				this._Last = this._Last.Next;
			}
			else
			{
				this._First = new SinglyLinkedListNode<T>(Item);
				this._Last = this._First;
			}

			this._Count++;
        }

		/// <summary>
		/// Determines whether an element is in the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// </summary>
		/// <param name="Item">
		/// The object to locate in the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// The value can be <c>null</c> for reference types.
		/// </param>
		/// <returns>
		/// <c>true</c> if the <paramref name="Item"/> is found in the
		/// <see cref="LinkedListQueue&lt;T&gt;"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// <para>
		/// This method determines equality by calling <see cref="Object.Equals(object)"/>.
		/// To enhance performance, it is recommended that in addition to implementing
		/// <see cref="Object.Equals(object)"/>, any class/struct also implement
		/// <see cref="IEquatable&lt;T&gt;"/> interface for their own type.
		/// </para>
		/// <para>
		/// This method is an O(n) operation, where n is <see cref="Count"/>.
		/// </para>
		/// </remarks>
		public bool Contains(T Item)
		{
			SinglyLinkedListNode<T> p = this._First;

			if (Item != null)
			{
				while (p != null)
				{
					if (Item.Equals(p.Item))
					{
						return true;
					}

					p = p.Next;
				}
			}
			else
			{
				while (p != null)
				{
					if (p.Item == null)
					{
						return true;
					}

					p = p.Next;
				}
			}

			return false;
		}

        /// <summary>
        /// Returns the object at the beginning of the <see cref="LinkedListQueue&lt;T&gt;"/>
        /// without removing it.
        /// </summary>
        /// <returns>
        /// The object at the beginning of the <see cref="LinkedListQueue&lt;T&gt;"/>.
        /// </returns>
        /// <remarks>
        /// <para>
        /// This method is similar to the <see cref="Dequeue()"/> method, but <see cref="Peek"/>
		/// does not modify the <see cref="LinkedListQueue&lt;T&gt;"/>.
        /// </para>
        /// <para>
        /// This method is an O(1) operation.
        /// </para>
        /// </remarks>
		/// <exception cref="InvalidOperationException">
		/// The <see cref="LinkedListQueue&lt;T&gt;"/> is empty.
		/// </exception>
        public T Peek()
        {
			if (this._First == null)
			{
				throw new InvalidOperationException();
			}

			return this._First.Item;
        }

        /// <summary>
        /// Removes and returns the object at the beginning of the <see cref="LinkedListQueue&lt;T&gt;"/>. 
        /// </summary>
        /// <returns>
        /// The object that is removed from the beginning of the <see cref="LinkedListQueue&lt;T&gt;"/>.
        /// </returns>
        /// <remarks>
        /// <para>
        /// This method is similar to the <see cref="Peek()"/> method, but <see cref="Peek()"/>
		/// does not modify the <see cref="LinkedListQueue&lt;T&gt;"/>.
        /// </para>
        /// <para>
        /// This method is an O(1) operation.
        /// </para>
        /// </remarks>
		/// <exception cref="InvalidOperationException">
		/// The <see cref="LinkedListQueue&lt;T&gt;"/> is empty.
		/// </exception>
        public T Dequeue()
        {
			if (this._First == null)
			{
				throw new InvalidOperationException();
			}

			T Item = this._First.Item;

			this._First = this._First.Next;

			if (this._First == null)
			{
				this._Last = null;
			}

			this._Count--;

			return Item;			
        }

        /// <summary>
        /// Removes all objects from the <see cref="LinkedListQueue&lt;T&gt;"/>. 
        /// </summary>
		/// <remarks>
		/// <para>
		/// <see cref="Count"/> is set to zero and references to other objects from
		/// elements of the collection are also released.
		/// </para>
		/// <para>
		/// This method is an O(1) operation.
		/// </para>
		/// </remarks>
        public void Clear()
        {
            this._First	= null;
			this._Last	= null;
			this._Count	= 0;
        }

		/// <summary>
		/// Copies the <see cref="LinkedListQueue&lt;T&gt;"/> elements to an existing
		/// one-dimensional <see cref="Array"/>, starting at the specified
		/// array index.
		/// </summary>
		/// <param name="Array">
		/// The one-dimensional <see cref="Array"/> that is the destination of the elements
		/// copied from this <see cref="LinkedListQueue&lt;T&gt;"/>. <paramref name="Array"/>
		/// must have zero-based indexing.
		/// </param>
		/// <param name="Index">
		/// The zero-based index in <paramref name="Array"/> at which copying begins.
		/// </param>
		/// <remarks>
		/// <para>
		/// The elements are copied to the <paramref name="Array"/> in first-in-first-out
		/// [FIFO] order, similar to the order of the elements returned by a succession of
		/// calls to the <see cref="Dequeue()"/>
		/// method.
		/// </para>
		/// <para>
		/// This method is an O(n) operation, where n is <see cref="Count"/>.
		/// </para>
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Array"/> is a <c>null</c> reference.
		/// </exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="Index"/> is outside of <paramref name="Array"/> bounds.
		/// </exception>
		/// <exception cref="ArgumentException">
		/// The number of elements in the source <see cref="LinkedListQueue&lt;T&gt;"/>
		/// is greater than the available space from <paramref name="Index"/> to the end
		/// of the destination <paramref name="Array"/>.
		/// </exception>
		public void CopyTo(T[] Array, int Index)
		{
			if (Array == null)
			{
				throw new ArgumentNullException();
			}

			if ((Index < 0) || (Index >= Array.Length))
			{
				throw new ArgumentOutOfRangeException();
			}

			if ((Array.Length - Index) < this._Count)
			{
				throw new ArgumentException();
			}

			if (this._First != null)
			{
				SinglyLinkedListNode<T> p = this._First;

				for(;;)
				{
					Array[Index] = p.Item;

					if (p.Next == null)
					{
						break;
					}

					p = p.Next;
					Index++;
				}
			}
		}
		
		/// <summary>
		/// Returns an enumerator that iterates through the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// </summary>
		/// <returns>
		/// An <see cref="Enumerator"/> for the <see cref="LinkedListQueue&lt;T&gt;"/>.
		/// </returns>
		/// <remarks>
		/// This method is an O(1) operation.
		/// </remarks>
		public Enumerator GetEnumerator()
		{
			return new Enumerator(this._First);
		}
		
        /// <summary>
        /// Initializes a new instance of the <see cref="LinkedListQueue&lt;T&gt;"/> class.
        /// </summary>
		/// <remarks>
		/// This constructor is an O(1) operation.
		/// </remarks>
        public LinkedListQueue()
        {
			this._First	= null;
			this._Last	= null;
            this._Count	= 0;
        }

	}
}