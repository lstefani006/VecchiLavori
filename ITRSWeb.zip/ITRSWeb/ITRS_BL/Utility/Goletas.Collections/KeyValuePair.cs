//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	/// <summary>
	/// Represents a key/value pair that can be set or retrieved.
	/// </summary>
	/// <typeparam name="K">
	/// The type of the <see cref="Key"/> contained
	/// in the <see cref="KeyValuePair&lt;K,V&gt;"/>.
	/// </typeparam>
	/// <typeparam name="V">
	/// The type of the <see cref="Value"/> contained
	/// in the <see cref="KeyValuePair&lt;K,V&gt;"/>.
	/// </typeparam>
	public struct KeyValuePair<K,V>
	{
		/// <summary>
		/// The key contained in this <see cref="KeyValuePair&lt;K,V&gt;"/>.
		/// </summary>
		public K Key;

		/// <summary>
		/// The value contained in this <see cref="KeyValuePair&lt;K,V&gt;"/>.
		/// </summary>
		public V Value;

		/// <summary>
		/// Initializes a new instance of the <see cref="KeyValuePair&lt;K,V&gt;"/>
		/// structure with the specified key and value.
		/// </summary>
		/// <param name="Key">
		/// The key identifying each <see cref="KeyValuePair&lt;K,V&gt;"/>.
		/// </param>
		/// <param name="Value">
		/// The definition associated with the <paramref name="Key"/>
		/// of this <see cref="KeyValuePair&lt;K,V&gt;"/>.
		/// </param>
		public KeyValuePair(K Key, V Value)
		{
			this.Key	= Key;
			this.Value	= Value;
		}

	}
}