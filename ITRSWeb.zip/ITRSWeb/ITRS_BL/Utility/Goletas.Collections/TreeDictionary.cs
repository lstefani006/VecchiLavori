//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	using System;

	/// <summary>
	/// Represents a collection of key/value pairs that are sorted on the key.
	/// </summary>
	/// <remarks>
	/// <para>
	/// Each element in the <see cref="TreeDictionary&lt;K,V&gt;"/> is a
	/// key/value pair stored in the <see cref="KeyValuePair&lt;K,V&gt;"/> object.
	/// </para>
	/// <para>
	/// A key cannnot be a <c>null</c> reference. Each key must be unique within
	/// <see cref="TreeDictionary&lt;K,V&gt;"/>. Keys must be immutable for the
	/// <see cref="IComparable&lt;T&gt;"/> interface as long as they are used as
	/// keys in the <see cref="TreeDictionary&lt;K,V&gt;"/>.
	/// </para>
	/// <para>
	/// <see cref="TreeDictionary&lt;K,V&gt;"/> uses the same algorithms as
	/// <see cref="BalancedBinaryTree&lt;T&gt;"/> to store and manage its elements.
	/// <see cref="TreeDictionary&lt;K,V&gt;"/> provides guaranteed O(log2 n) time cost
	/// for the <see cref="Add"/>, <see cref="Contains"/>, <see cref="Retrieve"/>,
	/// <see cref="Replace"/> and <see cref="Remove"/> operations.
	/// </para>
	/// </remarks>
	/// <typeparam name="K">
	/// The type of keys in the <see cref="TreeDictionary&lt;K,V&gt;"/>.
	/// </typeparam>
	/// <typeparam name="V">
	/// The type of values in the <see cref="TreeDictionary&lt;K,V&gt;"/>.
	/// </typeparam>
	public sealed class TreeDictionary<K, V> : IDictionary<K, V> where K : IComparable<K>
	{
		/// <summary>
		/// Represents a node in <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <remarks>
		/// The <see cref="Node"/> contains a key/value pair, a reference to the parent
		/// node, a reference to the left child node, a reference to the right child node,
		/// and a balance factor for this node.
		/// </remarks>
		internal sealed class Node
		{
			/// <summary>
			/// The key/value pair contained in this node.
			/// </summary>
			public KeyValuePair<K, V> Item;

			/// <summary>
			/// The reference to the parent node of this <see cref="Node"/> or <c>null</c> if
			/// this <see cref="Node"/> is the root node in <see cref="TreeDictionary&lt;K,V&gt;"/>.
			/// </summary>
			public Node Parent;

			/// <summary>
			/// The reference to the left child node of this <see cref="Node"/>
			/// or <c>null</c> if this <see cref="Node"/> has no left child node.
			/// </summary>
			public Node Left;

			/// <summary>
			/// The reference to the right child node of this <see cref="Node"/>
			/// or <c>null</c> if this <see cref="Node"/> has no right child node.
			/// </summary>
			public Node Right;

			/// <summary>
			/// The balance factor of this node.
			/// </summary>
			/// <remarks>
			/// The balance factor of a node is the height of its right subtree minus the height
			/// of its left subtree. A node with balance factor 1, 0, or -1 is considered balanced.
			/// A node with balance factor -2 or 2 is considered unbalanced and requires rebalancing
			/// the tree.
			/// </remarks>
			public sbyte Balance;

			/// <summary>
			/// Initializes a new instance of the <see cref="Node"/> class containing the
			/// specified key/value pair.
			/// </summary>
			/// <param name="Item">
			/// The key/value pair to contain in the <see cref="Node"/>.
			/// </param>
			/// <remarks>
			/// The <see cref="Parent"/>, <see cref="Left"/>, and <see cref="Right"/> fields are
			/// initialized to <c>null</c>. The <see cref="Balance"/> factor field is initialized
			/// to zero.
			/// </remarks>
			public Node(KeyValuePair<K, V> Item)
			{
				this.Item = Item;
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="Node"/> class containing the
			/// specified key/value pair and the reference to the parent node of this
			/// <see cref="Node"/>.
			/// </summary>
			/// <param name="Item">
			/// The key/value pair to contain in the <see cref="Node"/>.
			/// </param>
			/// <param name="Parent">
			/// The reference to the parent node of this <see cref="Node"/>.
			/// </param>
			/// <remarks>
			/// The <see cref="Left"/> and <see cref="Right"/> fields are initialized to
			/// <c>null</c>. The <see cref="Balance"/> factor field is initialized to zero.
			/// </remarks>
			public Node(KeyValuePair<K, V> Item, Node Parent)
			{
				this.Item	= Item;
				this.Parent	= Parent;
			}
		}

		/// <summary>
		/// Represents the collection of keys in <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <remarks>
		/// The <see cref="KeyCollection"/> is not a static copy; instead, the
		/// <see cref="KeyCollection"/> refers back to the keys in the original
		/// <see cref="TreeDictionary&lt;K,V&gt;"/>. Therefore, changes to the
		/// <see cref="TreeDictionary&lt;K,V&gt;"/> continue to be reflected in
		/// the <see cref="KeyCollection"/>.
		/// </remarks>
		public sealed class KeyCollection : IReadOnlyCollection<K>
		{
			/// <summary>
			/// Enumerates the elements of the <see cref="KeyCollection"/>.
			/// </summary>
			/// <remarks>
			/// <para>
			/// The elements are enumerated in ascending order.
			/// </para>
			/// <para>
			/// Initially, the enumerator is positioned before the first element in the collection.
			/// At this position, <see cref="Current"/> is undefined. Therefore, you must call
			/// <see cref="MoveNext"/> to advance the enumerator to the first element of the
			/// collection before reading the value of <see cref="Current"/>.
			/// </para>
			/// <para>
			/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/> is
			/// called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
			/// </para>
			/// <para>
			/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is
			/// positioned after the last element in the collection and <see cref="MoveNext"/>
			/// returns <c>false</c>. When the enumerator is at this position, subsequent calls to
			/// <see cref="MoveNext"/> also return <c>false</c>. If the last call to
			/// <see cref="MoveNext"/> returned <c>false</c>, <see cref="Current"/> is undefined.
			/// You cannot set <see cref="Current"/> to the first element of the collection again;
			/// you must create a new enumerator instance instead.
			/// </para>
			/// </remarks>
			public struct AscendingOrderEnumerator : IEnumerator<K>
			{
				/// <summary>
				/// The <see cref="Node"/> at the current position of the enumerator.
				/// </summary>
				private Node _Next;

				/// <summary>
				/// The element at the current position of the enumerator.
				/// </summary>
				private K _Current;

				/// <summary>
				/// Gets the element at the current position of the enumerator. 
				/// </summary>
				/// <value>
				/// The element in the <see cref="KeyCollection"/> at the current position
				/// of the enumerator.
				/// </value>
				/// <remarks>
				/// <para>
				/// <see cref="Current"/> is undefined under any of the following conditions:
				/// 1) The enumerator is positioned before the first element in the collection,
				/// immediately after the enumerator is created. <see cref="MoveNext"/> must be
				/// called to advance the enumerator to the first element of the collection
				/// before reading the value of <see cref="Current"/>; 2) The last call to
				/// <see cref="MoveNext"/> returned <c>false</c>, which indicates the end of
				/// the collection.
				/// </para>
				/// <para>
				/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/>
				/// is called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
				/// </para>
				/// </remarks>
				public K Current
				{
					get
					{
						return this._Current;
					}
				}

				/// <summary>
				/// Advances the enumerator to the next element of the <see cref="KeyCollection"/>.
				/// </summary>
				/// <returns>
				/// <c>true</c> if the enumerator was successfully advanced to the next element;
				/// <c>false</c> if the enumerator has passed the end of the collection.
				/// </returns>
				/// <remarks>
				/// <para>
				/// After an enumerator is created, the enumerator is positioned before the first element
				/// in the collection, and the first call to <see cref="MoveNext"/> advances the
				/// enumerator to the first element of the collection.
				/// </para>
				/// <para>
				/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is positioned
				/// after the last element in the collection and <see cref="MoveNext"/> returns <c>false</c>.
				/// When the enumerator is at this position, subsequent calls to <see cref="MoveNext"/>
				/// also return <c>false</c>.
				/// </para> 
				/// </remarks>
				public bool MoveNext()
				{
					if (this._Next == null)
					{
						return false;
					}

					this._Current = this._Next.Item.Key;

					if (this._Next.Right == null)
					{
						while ((this._Next.Parent != null) && (this._Next == this._Next.Parent.Right))
						{
							this._Next = this._Next.Parent;
						}

						this._Next = this._Next.Parent;
					}
					else
					{
						for (this._Next = this._Next.Right; this._Next.Left != null; this._Next = this._Next.Left) ;
					}

					return true;
				}

				/// <summary>
				/// Initializes a new instance of the <see cref="AscendingOrderEnumerator"/>
				/// structure with the specified <paramref name="Node"/>.
				/// </summary>
				/// <param name="Node">
				/// The node from which to start enumerating the <see cref="KeyCollection"/>
				/// elements.
				/// </param>
				internal AscendingOrderEnumerator(Node Node)
				{
					if (Node != null)
					{
						while (Node.Left != null)
						{
							Node = Node.Left;
						}
					}

					this._Next = Node;
					this._Current = default(K);
				}
			}
			
			/// <summary>
			/// The dictionary for which this <see cref="KeyCollection"/> was created.
			/// </summary>
			private TreeDictionary<K, V> _TreeDictionary;

			/// <summary>
			/// Gets the number of elements contained in this <see cref="KeyCollection"/>.
			/// </summary>
			/// <value>
			/// The number of elements contained in this <see cref="KeyCollection"/>.
			/// </value>
			/// <remarks>
			/// Retrieving the value of this property is an O(1) operation.
			/// </remarks>
			public int Count
			{
				get
				{
					return this._TreeDictionary._Count;
				}
			}

			/// <summary>
			/// Determines whether this <see cref="KeyCollection"/> contains a specific key.
			/// </summary>
			/// <param name="Item">
			/// The key to locate in this <see cref="KeyCollection"/>.
			/// </param>
			/// <returns>
			/// <c>true</c>, if <paramref name="Item"/> is found in this
			/// <see cref="KeyCollection"/>; otherwise, <c>false</c>.
			/// </returns>
			/// <remarks>
			/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
			/// </remarks>
			/// <exception cref="ArgumentNullException">
			/// <paramref name="Item"/> is a <c>null</c> reference.
			/// </exception>
			public bool Contains(K Item)
			{
				if (Item == null)
				{
					throw new ArgumentNullException();
				}

				for (Node p = this._TreeDictionary._Root; p != null; )
				{
					int Comparer = Item.CompareTo(p.Item.Key);

					if (Comparer < 0)
					{
						p = p.Left;
					}
					else if (Comparer > 0)
					{
						p = p.Right;
					}
					else
					{
						return true;
					}
				}

				return false;
			}

			/// <summary>
			/// Copies the <see cref="KeyCollection"/> elements to an existing
			/// one-dimensional <see cref="Array"/>, starting at the specified array index.
			/// </summary>
			/// <param name="Array">
			/// The one-dimensional <see cref="Array"/> that is the destination of the elements
			/// copied from this <see cref="KeyCollection"/>.
			/// <paramref name="Array"/> must have zero-based indexing.
			/// </param>
			/// <param name="Index">
			/// The zero-based index in <paramref name="Array"/> at which copying begins.
			/// </param>
			/// <remarks>
			/// <para>
			/// The elements are copied to <paramref name="Array"/> in ascending order.
			/// </para>
			/// <para>
			/// This method is an O(n) operation, where n is <see cref="Count"/>.
			/// </para>
			/// </remarks>
			/// <exception cref="ArgumentNullException">
			/// <paramref name="Array"/> is a <c>null</c> reference.
			/// </exception>
			/// <exception cref="ArgumentOutOfRangeException">
			/// <paramref name="Index"/> is outside of <paramref name="Array"/> bounds.
			/// </exception>
			/// <exception cref="ArgumentException">
			/// The number of elements in the source <see cref="KeyCollection"/> is greater
			/// than the available space from <paramref name="Index"/> to the end of the
			/// destination <paramref name="Array"/>.
			/// </exception>
			public void CopyTo(K[] Array, int Index)
			{
				if (Array == null)
				{
					throw new ArgumentNullException();
				}

				if ((Index < 0) || (Index >= Array.Length))
				{
					throw new ArgumentOutOfRangeException();
				}

				if ((Array.Length - Index) < this._TreeDictionary._Count)
				{
					throw new ArgumentException();
				}

				if (this._TreeDictionary._Root != null)
				{
					Node p = this._TreeDictionary._Root;

					while (p.Left != null)
					{
						p = p.Left;
					}

					for (; ; )
					{
						Array[Index] = p.Item.Key;

						if (p.Right == null)
						{
							for (; ; )
							{
								if (p.Parent == null)
								{
									return;
								}

								if (p != p.Parent.Right)
								{
									break;
								}

								p = p.Parent;
							}

							p = p.Parent;
						}
						else
						{
							for (p = p.Right; p.Left != null; p = p.Left) ;
						}

						Index++;
					}
				}
			}

			/// <summary>
			/// Returns an enumerator that iterates through the <see cref="KeyCollection"/>.
			/// </summary>
			/// <returns>
			/// An <see cref="AscendingOrderEnumerator"/> for the <see cref="KeyCollection"/>.
			/// </returns>
			public AscendingOrderEnumerator GetEnumerator()
			{
				return new AscendingOrderEnumerator(this._TreeDictionary._Root);
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="KeyCollection"/>
			/// class with the specified <paramref name="TreeDictionary"/>
			/// </summary>
			/// <remarks>
			/// This constructor is an O(1) operation.
			/// </remarks>
			internal KeyCollection(TreeDictionary<K, V> TreeDictionary)
			{
				this._TreeDictionary = TreeDictionary;
			}
		}

		/// <summary>
		/// Represents the collection of values in <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <remarks>
		/// The <see cref="ValueCollection"/> is not a static copy; instead, the
		/// <see cref="ValueCollection"/> refers back to the keys in the original
		/// <see cref="TreeDictionary&lt;K,V&gt;"/>. Therefore, changes to the
		/// <see cref="TreeDictionary&lt;K,V&gt;"/> continue to be reflected in
		/// the <see cref="ValueCollection"/>.
		/// </remarks>
		public sealed class ValueCollection : IReadOnlyCollection<V>
		{
			/// <summary>
			/// Enumerates the elements of the <see cref="ValueCollection"/>.
			/// </summary>
			/// <remarks>
			/// <para>
			/// The elements are enumerated in ascending order.
			/// </para>
			/// <para>
			/// Initially, the enumerator is positioned before the first element in the collection.
			/// At this position, <see cref="Current"/> is undefined. Therefore, you must call
			/// <see cref="MoveNext"/> to advance the enumerator to the first element of the
			/// collection before reading the value of <see cref="Current"/>.
			/// </para>
			/// <para>
			/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/> is
			/// called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
			/// </para>
			/// <para>
			/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is
			/// positioned after the last element in the collection and <see cref="MoveNext"/>
			/// returns <c>false</c>. When the enumerator is at this position, subsequent calls to
			/// <see cref="MoveNext"/> also return <c>false</c>. If the last call to
			/// <see cref="MoveNext"/> returned <c>false</c>, <see cref="Current"/> is undefined.
			/// You cannot set <see cref="Current"/> to the first element of the collection again;
			/// you must create a new enumerator instance instead.
			/// </para>
			/// </remarks>
			public struct AscendingOrderEnumerator : IEnumerator<V>
			{
				/// <summary>
				/// The <see cref="Node"/> at the current position of the enumerator.
				/// </summary>
				private Node _Next;

				/// <summary>
				/// The element at the current position of the enumerator.
				/// </summary>
				private V _Current;

				/// <summary>
				/// Gets the element at the current position of the enumerator. 
				/// </summary>
				/// <value>
				/// The element in the <see cref="ValueCollection"/> at the current
				/// position of the enumerator.
				/// </value>
				/// <remarks>
				/// <para>
				/// <see cref="Current"/> is undefined under any of the following conditions:
				/// 1) The enumerator is positioned before the first element in the collection,
				/// immediately after the enumerator is created. <see cref="MoveNext"/> must be
				/// called to advance the enumerator to the first element of the collection
				/// before reading the value of <see cref="Current"/>; 2) The last call to
				/// <see cref="MoveNext"/> returned <c>false</c>, which indicates the end of
				/// the collection.
				/// </para>
				/// <para>
				/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/>
				/// is called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
				/// </para>
				/// </remarks>
				public V Current
				{
					get
					{
						return this._Current;
					}
				}

				/// <summary>
				/// Advances the enumerator to the next element of the <see cref="ValueCollection"/>.
				/// </summary>
				/// <returns>
				/// <c>true</c> if the enumerator was successfully advanced to the next element;
				/// <c>false</c> if the enumerator has passed the end of the collection.
				/// </returns>
				/// <remarks>
				/// <para>
				/// After an enumerator is created, the enumerator is positioned before the first element
				/// in the collection, and the first call to <see cref="MoveNext"/> advances the
				/// enumerator to the first element of the collection.
				/// </para>
				/// <para>
				/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is positioned
				/// after the last element in the collection and <see cref="MoveNext"/> returns <c>false</c>.
				/// When the enumerator is at this position, subsequent calls to <see cref="MoveNext"/>
				/// also return <c>false</c>.
				/// </para> 
				/// </remarks>
				public bool MoveNext()
				{
					if (this._Next == null)
					{
						return false;
					}

					this._Current = this._Next.Item.Value;

					if (this._Next.Right == null)
					{
						while ((this._Next.Parent != null) && (this._Next == this._Next.Parent.Right))
						{
							this._Next = this._Next.Parent;
						}

						this._Next = this._Next.Parent;
					}
					else
					{
						for (this._Next = this._Next.Right; this._Next.Left != null; this._Next = this._Next.Left) ;
					}

					return true;
				}

				/// <summary>
				/// Initializes a new instance of the <see cref="AscendingOrderEnumerator"/>
				/// structure with the specified <paramref name="Node"/>.
				/// </summary>
				/// <param name="Node">
				/// The node from which to start enumerating the
				/// <see cref="ValueCollection"/> elements.
				/// </param>
				internal AscendingOrderEnumerator(Node Node)
				{
					if (Node != null)
					{
						while (Node.Left != null)
						{
							Node = Node.Left;
						}
					}

					this._Next = Node;
					this._Current = default(V);
				}
			}

			/// <summary>
			/// The dictionary for which this <see cref="ValueCollection"/> was created.
			/// </summary>
			private TreeDictionary<K, V> _TreeDictionary;

			/// <summary>
			/// Gets the number of elements contained in this <see cref="ValueCollection"/>.
			/// </summary>
			/// <value>
			/// The number of elements contained in this <see cref="ValueCollection"/>.
			/// </value>
			/// <remarks>
			/// Retrieving the value of this property is an O(1) operation.
			/// </remarks>
			public int Count
			{
				get
				{
					return this._TreeDictionary._Count;
				}
			}

			/// <summary>
			/// Determines whether this <see cref="ValueCollection"/> contains a specific value.
			/// </summary>
			/// <param name="Item">
			/// The value to locate in this <see cref="ValueCollection"/>.
			/// </param>
			/// <returns>
			/// <c>true</c>, if <paramref name="Item"/> is found in this
			/// <see cref="ValueCollection"/>; otherwise, <c>false</c>.
			/// </returns>
			/// <remarks>
			/// This method is an O(n) operation, where n is <see cref="Count"/>.
			/// </remarks>
			public bool Contains(V Item)
			{
				if (this._TreeDictionary._Root != null)
				{
					Node p = this._TreeDictionary._Root;

					while (p.Left != null)
					{
						p = p.Left;
					}

					if (Item != null)
					{
						for (; ; )
						{
							if (Item.Equals(p.Item.Value))
							{
								return true;
							}

							if (p.Right == null)
							{
								for (; ; )
								{
									if (p.Parent == null)
									{
										return false;
									}

									if (p != p.Parent.Right)
									{
										break;
									}

									p = p.Parent;
								}

								p = p.Parent;
							}
							else
							{
								for (p = p.Right; p.Left != null; p = p.Left) ;
							}
						}
					}
					else
					{
						for (; ; )
						{
							if (p.Item.Value == null)
							{
								return true;
							}

							if (p.Right == null)
							{
								for (; ; )
								{
									if (p.Parent == null)
									{
										return false;
									}

									if (p != p.Parent.Right)
									{
										break;
									}

									p = p.Parent;
								}

								p = p.Parent;
							}
							else
							{
								for (p = p.Right; p.Left != null; p = p.Left) ;
							}
						}
					}
				}

				return false;
			}

			/// <summary>
			/// Copies the <see cref="ValueCollection"/> elements to an existing
			/// one-dimensional <see cref="Array"/>, starting at the specified array index.
			/// </summary>
			/// <param name="Array">
			/// The one-dimensional <see cref="Array"/> that is the destination of the elements
			/// copied from this <see cref="ValueCollection"/>.
			/// <paramref name="Array"/> must have zero-based indexing.
			/// </param>
			/// <param name="Index">
			/// The zero-based index in <paramref name="Array"/> at which copying begins.
			/// </param>
			/// <remarks>
			/// <para>
			/// The elements are copied to <paramref name="Array"/> in ascending order.
			/// </para>
			/// <para>
			/// This method is an O(n) operation, where n is <see cref="Count"/>.
			/// </para>
			/// </remarks>
			/// <exception cref="ArgumentNullException">
			/// <paramref name="Array"/> is a <c>null</c> reference.
			/// </exception>
			/// <exception cref="ArgumentOutOfRangeException">
			/// <paramref name="Index"/> is outside of <paramref name="Array"/> bounds.
			/// </exception>
			/// <exception cref="ArgumentException">
			/// The number of elements in the source <see cref="ValueCollection"/> is greater
			/// than the available space from <paramref name="Index"/> to the end of the
			/// destination <paramref name="Array"/>.
			/// </exception>
			public void CopyTo(V[] Array, int Index)
			{
				if (Array == null)
				{
					throw new ArgumentNullException();
				}

				if ((Index < 0) || (Index >= Array.Length))
				{
					throw new ArgumentOutOfRangeException();
				}

				if ((Array.Length - Index) < this._TreeDictionary._Count)
				{
					throw new ArgumentException();
				}

				if (this._TreeDictionary._Root != null)
				{
					Node p = this._TreeDictionary._Root;

					while (p.Left != null)
					{
						p = p.Left;
					}

					for (; ; )
					{
						Array[Index] = p.Item.Value;

						if (p.Right == null)
						{
							for (; ; )
							{
								if (p.Parent == null)
								{
									return;
								}

								if (p != p.Parent.Right)
								{
									break;
								}

								p = p.Parent;
							}

							p = p.Parent;
						}
						else
						{
							for (p = p.Right; p.Left != null; p = p.Left) ;
						}

						Index++;
					}
				}
			}

			/// <summary>
			/// Returns an enumerator that iterates through the <see cref="ValueCollection"/>.
			/// </summary>
			/// <returns>
			/// An <see cref="AscendingOrderEnumerator"/> for the <see cref="ValueCollection"/>.
			/// </returns>
			public AscendingOrderEnumerator GetEnumerator()
			{
				return new AscendingOrderEnumerator(this._TreeDictionary._Root);
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="ValueCollection"/>
			/// class with the specified <paramref name="TreeDictionary"/>
			/// </summary>
			/// <remarks>
			/// This constructor is an O(1) operation.
			/// </remarks>
			internal ValueCollection(TreeDictionary<K, V> TreeDictionary)
			{
				this._TreeDictionary = TreeDictionary;
			}
		}

		/// <summary>
		/// Enumerates the elements of the <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <remarks>
		/// <para>
		/// The elements are enumerated in ascending order.
		/// </para>
		/// <para>
		/// Initially, the enumerator is positioned before the first element in the collection.
		/// At this position, <see cref="Current"/> is undefined. Therefore, you must call
		/// <see cref="MoveNext"/> to advance the enumerator to the first element of the
		/// collection before reading the value of <see cref="Current"/>.
		/// </para>
		/// <para>
		/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/> is
		/// called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
		/// </para>
		/// <para>
		/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is
		/// positioned after the last element in the collection and <see cref="MoveNext"/>
		/// returns <c>false</c>. When the enumerator is at this position, subsequent calls to
		/// <see cref="MoveNext"/> also return <c>false</c>. If the last call to
		/// <see cref="MoveNext"/> returned <c>false</c>, <see cref="Current"/> is undefined.
		/// You cannot set <see cref="Current"/> to the first element of the collection again;
		/// you must create a new enumerator instance instead.
		/// </para>
		/// </remarks>
		public struct AscendingOrderEnumerator : IEnumerator<KeyValuePair<K, V>>
		{
			/// <summary>
			/// The <see cref="Node"/> at the current position of the enumerator.
			/// </summary>
			private Node _Next;

			/// <summary>
			/// The element at the current position of the enumerator.
			/// </summary>
			private KeyValuePair<K, V> _Current;

			/// <summary>
			/// Gets the element at the current position of the enumerator. 
			/// </summary>
			/// <value>
			/// The element in the <see cref="TreeDictionary&lt;K,V&gt;"/> at the current
			/// position of the enumerator.
			/// </value>
			/// <remarks>
			/// <para>
			/// <see cref="Current"/> is undefined under any of the following conditions:
			/// 1) The enumerator is positioned before the first element in the collection,
			/// immediately after the enumerator is created. <see cref="MoveNext"/> must be
			/// called to advance the enumerator to the first element of the collection
			/// before reading the value of <see cref="Current"/>; 2) The last call to
			/// <see cref="MoveNext"/> returned <c>false</c>, which indicates the end of
			/// the collection.
			/// </para>
			/// <para>
			/// <see cref="Current"/> returns the same object until <see cref="MoveNext"/>
			/// is called. <see cref="MoveNext"/> sets <see cref="Current"/> to the next element.
			/// </para>
			/// </remarks>
			public KeyValuePair<K, V> Current
			{
				get
				{
					return this._Current;
				}
			}

			/// <summary>
			/// Advances the enumerator to the next element of the
			/// <see cref="TreeDictionary&lt;K,V&gt;"/>.
			/// </summary>
			/// <returns>
			/// <c>true</c> if the enumerator was successfully advanced to the next element;
			/// <c>false</c> if the enumerator has passed the end of the collection.
			/// </returns>
			/// <remarks>
			/// <para>
			/// After an enumerator is created, the enumerator is positioned before the first element
			/// in the collection, and the first call to <see cref="MoveNext"/> advances the
			/// enumerator to the first element of the collection.
			/// </para>
			/// <para>
			/// If <see cref="MoveNext"/> passes the end of the collection, the enumerator is positioned
			/// after the last element in the collection and <see cref="MoveNext"/> returns <c>false</c>.
			/// When the enumerator is at this position, subsequent calls to <see cref="MoveNext"/>
			/// also return <c>false</c>.
			/// </para> 
			/// </remarks>
			public bool MoveNext()
			{
				if (this._Next == null)
				{
					return false;
				}

				this._Current = this._Next.Item;

				if (this._Next.Right == null)
				{
					while ((this._Next.Parent != null) && (this._Next == this._Next.Parent.Right))
					{
						this._Next = this._Next.Parent;
					}

					this._Next = this._Next.Parent;
				}
				else
				{
					for (this._Next = this._Next.Right; this._Next.Left != null; this._Next = this._Next.Left) ;
				}

				return true;
			}

			/// <summary>
			/// Initializes a new instance of the <see cref="AscendingOrderEnumerator"/>
			/// structure with the specified <paramref name="Node"/>.
			/// </summary>
			/// <param name="Node">
			/// The node from which to start enumerating the
			/// <see cref="TreeDictionary&lt;K,V&gt;"/> elements.
			/// </param>
			internal AscendingOrderEnumerator(Node Node)
			{
				if (Node != null)
				{
					while (Node.Left != null)
					{
						Node = Node.Left;
					}
				}

				this._Next = Node;
				this._Current = new KeyValuePair<K, V>();
			}
		}

		/// <summary>
		/// The root node of this <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		private Node _Root;

		/// <summary>
		/// The number of elements contained in this <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		private int _Count;

		/// <summary>
		/// <see cref="KeyCollection"/> containing the
		/// keys in <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// </summary>
		private KeyCollection _Keys;

		/// <summary>
		/// <see cref="ValueCollection"/> containing the
		/// values in <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// </summary>
		private ValueCollection _Values;

		/// <summary>
		/// Adds an element with the provided <paramref name="Key"/> and
		/// <paramref name="Value"/> to the <see cref="TreeDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <param name="Key">
		/// The object to use as the key of the element to add.
		/// </param>
		/// <param name="Value">
		/// The object to use as the value of the element to add.
		/// </param>
		/// <returns>
		/// <c>true</c> if this <see cref="TreeDictionary&lt;K,V&gt;"/> did not
		/// already contain the specified <paramref name="Key"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Key"/> is a <c>null</c> reference.
		/// </exception>
		public bool Add(K Key, V Value)
		{
			if (Key == null)
			{
				throw new ArgumentNullException();
			}

			if (this._Root == null)
			{
				this._Root = new Node(new KeyValuePair<K, V>(Key, Value));
			}
			else
			{
				Node p = this._Root;

				for (; ; )
				{
					int Comparer = Key.CompareTo(p.Item.Key);

					if (Comparer < 0)
					{
						if (p.Left != null)
						{
							p = p.Left;
						}
						else
						{
							p.Left = new Node(new KeyValuePair<K, V>(Key, Value), p);
							p.Balance--;

							break;
						}
					}
					else if (Comparer > 0)
					{
						if (p.Right != null)
						{
							p = p.Right;
						}
						else
						{
							p.Right = new Node(new KeyValuePair<K, V>(Key, Value), p);
							p.Balance++;

							break;
						}
					}
					else
					{
						return false;
					}
				}

				while ((p.Balance != 0) && (p.Parent != null))
				{
					if (p.Parent.Left == p)
					{
						p.Parent.Balance--;
					}
					else
					{
						p.Parent.Balance++;
					}

					p = p.Parent;

					if (p.Balance == -2)
					{
						Node x = p.Left;

						if (x.Balance == -1)
						{
							x.Parent = p.Parent;

							if (p.Parent == null)
							{
								this._Root = x;
							}
							else
							{
								if (p.Parent.Left == p)
								{
									p.Parent.Left = x;
								}
								else
								{
									p.Parent.Right = x;
								}
							}

							p.Left = x.Right;

							if (p.Left != null)
							{
								p.Left.Parent = p;
							}

							x.Right = p;
							p.Parent = x;

							x.Balance = 0;
							p.Balance = 0;
						}
						else
						{
							Node w = x.Right;

							w.Parent = p.Parent;

							if (p.Parent == null)
							{
								this._Root = w;
							}
							else
							{
								if (p.Parent.Left == p)
								{
									p.Parent.Left = w;
								}
								else
								{
									p.Parent.Right = w;
								}
							}

							x.Right = w.Left;

							if (x.Right != null)
							{
								x.Right.Parent = x;
							}

							p.Left = w.Right;

							if (p.Left != null)
							{
								p.Left.Parent = p;
							}

							w.Left = x;
							w.Right = p;

							x.Parent = w;
							p.Parent = w;

							if (w.Balance == -1)
							{
								x.Balance = 0;
								p.Balance = 1;
							}
							else if (w.Balance == 0)
							{
								x.Balance = 0;
								p.Balance = 0;
							}
							else // w.Balance == 1
							{
								x.Balance = -1;
								p.Balance = 0;
							}

							w.Balance = 0;
						}

						break;
					}
					else if (p.Balance == 2)
					{
						Node x = p.Right;

						if (x.Balance == 1)
						{
							x.Parent = p.Parent;

							if (p.Parent == null)
							{
								this._Root = x;
							}
							else
							{
								if (p.Parent.Left == p)
								{
									p.Parent.Left = x;
								}
								else
								{
									p.Parent.Right = x;
								}
							}

							p.Right = x.Left;

							if (p.Right != null)
							{
								p.Right.Parent = p;
							}

							x.Left = p;
							p.Parent = x;

							x.Balance = 0;
							p.Balance = 0;
						}
						else
						{
							Node w = x.Left;

							w.Parent = p.Parent;

							if (p.Parent == null)
							{
								this._Root = w;
							}
							else
							{
								if (p.Parent.Left == p)
								{
									p.Parent.Left = w;
								}
								else
								{
									p.Parent.Right = w;
								}
							}

							x.Left = w.Right;

							if (x.Left != null)
							{
								x.Left.Parent = x;
							}

							p.Right = w.Left;

							if (p.Right != null)
							{
								p.Right.Parent = p;
							}

							w.Right = x;
							w.Left = p;

							x.Parent = w;
							p.Parent = w;

							if (w.Balance == 1)
							{
								x.Balance = 0;
								p.Balance = -1;
							}
							else if (w.Balance == 0)
							{
								x.Balance = 0;
								p.Balance = 0;
							}
							else // w.Balance == -1
							{
								x.Balance = 1;
								p.Balance = 0;
							}

							w.Balance = 0;
						}

						break;
					}
				}
			}

			this._Count++;
			return true;
		}

		/// <summary>
		/// Overwrites the value for the specified <paramref name="Key"/> in
		/// <see cref="TreeDictionary&lt;K,V&gt;"/> with the new <paramref name="Value"/>
		/// </summary>
		/// <param name="Key">
		/// The key whose value to replace.
		/// </param>
		/// <param name="Value">
		/// The value to associate with the specified <paramref name="Key"/>.
		/// </param>
		/// <returns>
		/// <c>true</c> if an element with the speficied <paramref name="Key"/>
		/// was found and updated with the new <paramref name="Value"/>; otherwise,
		/// <c>false</c>.
		/// </returns>
		/// <remarks>
		/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </remarks>
		public bool Replace(K Key, V Value)
		{
			if (Key == null)
			{
				throw new ArgumentNullException();
			}

			for (Node p = this._Root; p != null; )
			{
				int Comparer = Key.CompareTo(p.Item.Key);

				if (Comparer < 0)
				{
					p = p.Left;
				}
				else if (Comparer > 0)
				{
					p = p.Right;
				}
				else
				{
					p.Item.Value = Value;
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Retrieves the value associated with the specified <paramref name="Key"/>. 
		/// </summary>
		/// <param name="Key">
		/// The key whose value to retrieve.
		/// </param>
		/// <param name="Value">
		/// If the key is found, the value associated with the specified <paramref name="Key"/>;
		/// otherwise, the default value for the type of the <paramref name="Value"/> parameter.
		/// </param>
		/// <returns>
		/// <c>true</c> if <see cref="TreeDictionary&lt;K,V&gt;"/> contains an element with the
		/// specified <paramref name="Key"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Key"/> is a <c>null</c> reference.
		/// </exception>
		public bool Retrieve(K Key, out V Value)
		{
			if (Key == null)
			{
				throw new ArgumentNullException();
			}

			for (Node p = this._Root; p != null; )
			{
				int Comparer = Key.CompareTo(p.Item.Key);

				if (Comparer < 0)
				{
					p = p.Left;
				}
				else if (Comparer > 0)
				{
					p = p.Right;
				}
				else
				{
					Value = p.Item.Value;
					return true;
				}
			}

			Value = default(V);
			return false;
		}

		/// <summary>
		/// Removes the element with the specified <paramref name="Key"/>
		/// from the <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <param name="Key">
		/// The key of the element to remove.
		/// </param>
		/// <returns>
		/// <c>true</c> if this <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// contained the specified element; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Key"/> is a <c>null</c> reference.
		/// </exception>
		public bool Remove(K Key)
		{
			if (Key == null)
			{
				throw new ArgumentNullException();
			}

			for (Node p = this._Root; p != null; )
			{
				int Comparer = Key.CompareTo(p.Item.Key);

				if (Comparer < 0)
				{
					p = p.Left;
				}
				else if (Comparer > 0)
				{
					p = p.Right;
				}
				else
				{
					Node y; // node from which rebalancing begins

					if (p.Right == null)	// Case 1: p has no right child
					{
						if (p.Left != null)
						{
							p.Left.Parent = p.Parent;
						}

						if (p.Parent == null)
						{
							this._Root = p.Left;

							goto Done;
						}

						if (p == p.Parent.Left)
						{
							p.Parent.Left = p.Left;

							y = p.Parent;
							// goto LeftDelete;
						}
						else
						{
							p.Parent.Right = p.Left;

							y = p.Parent;
							goto RightDelete;
						}
					}
					else if (p.Right.Left == null)	// Case 2: p's right child has no left child
					{
						if (p.Left != null)
						{
							p.Left.Parent = p.Right;
							p.Right.Left = p.Left;
						}

						p.Right.Balance = p.Balance;
						p.Right.Parent = p.Parent;

						if (p.Parent == null)
						{
							this._Root = p.Right;
						}
						else
						{
							if (p == p.Parent.Left)
							{
								p.Parent.Left = p.Right;
							}
							else
							{
								p.Parent.Right = p.Right;
							}
						}

						y = p.Right;

						goto RightDelete;
					}
					else	// Case 3: p's right child has a left child
					{
						Node s = p.Right.Left;

						while (s.Left != null)
						{
							s = s.Left;
						}

						if (p.Left != null)
						{
							p.Left.Parent = s;
							s.Left = p.Left;
						}

						s.Parent.Left = s.Right;

						if (s.Right != null)
						{
							s.Right.Parent = s.Parent;
						}

						p.Right.Parent = s;
						s.Right = p.Right;

						y = s.Parent; // for rebalacing, must be set before we change s.Parent

						s.Balance = p.Balance;
						s.Parent = p.Parent;

						if (p.Parent == null)
						{
							this._Root = s;
						}
						else
						{
							if (p == p.Parent.Left)
							{
								p.Parent.Left = s;
							}
							else
							{
								p.Parent.Right = s;
							}
						}

						// goto LeftDelete;
					}

					// rebalancing begins

					LeftDelete:

					y.Balance++;

					if (y.Balance == 1)
					{
						goto Done;
					}
					else if (y.Balance == 2)
					{
						Node x = y.Right;

						if (x.Balance == -1)
						{
							Node w = x.Left;

							w.Parent = y.Parent;

							if (y.Parent == null)
							{
								this._Root = w;
							}
							else
							{
								if (y.Parent.Left == y)
								{
									y.Parent.Left = w;
								}
								else
								{
									y.Parent.Right = w;
								}
							}

							x.Left = w.Right;

							if (x.Left != null)
							{
								x.Left.Parent = x;
							}

							y.Right = w.Left;

							if (y.Right != null)
							{
								y.Right.Parent = y;
							}

							w.Right = x;
							w.Left = y;

							x.Parent = w;
							y.Parent = w;

							if (w.Balance == 1)
							{
								x.Balance = 0;
								y.Balance = -1;
							}
							else if (w.Balance == 0)
							{
								x.Balance = 0;
								y.Balance = 0;
							}
							else // w.Balance == -1
							{
								x.Balance = 1;
								y.Balance = 0;
							}

							w.Balance = 0;

							y = w; // for next iteration
						}
						else
						{
							x.Parent = y.Parent;

							if (y.Parent != null)
							{
								if (y.Parent.Left == y)
								{
									y.Parent.Left = x;
								}
								else
								{
									y.Parent.Right = x;
								}
							}
							else
							{
								this._Root = x;
							}

							y.Right = x.Left;

							if (y.Right != null)
							{
								y.Right.Parent = y;
							}

							x.Left = y;
							y.Parent = x;

							if (x.Balance == 0)
							{
								x.Balance = -1;
								y.Balance = 1;

								goto Done;
							}
							else
							{
								x.Balance = 0;
								y.Balance = 0;

								y = x; // for next iteration
							}
						}
					}

					goto LoopTest;


				RightDelete:

					y.Balance--;

					if (y.Balance == -1)
					{
						goto Done;
					}
					else if (y.Balance == -2)
					{
						Node x = y.Left;

						if (x.Balance == 1)
						{
							Node w = x.Right;

							w.Parent = y.Parent;

							if (y.Parent == null)
							{
								this._Root = w;
							}
							else
							{
								if (y.Parent.Left == y)
								{
									y.Parent.Left = w;
								}
								else
								{
									y.Parent.Right = w;
								}
							}

							x.Right = w.Left;

							if (x.Right != null)
							{
								x.Right.Parent = x;
							}

							y.Left = w.Right;

							if (y.Left != null)
							{
								y.Left.Parent = y;
							}

							w.Left = x;
							w.Right = y;

							x.Parent = w;
							y.Parent = w;

							if (w.Balance == -1)
							{
								x.Balance = 0;
								y.Balance = 1;
							}
							else if (w.Balance == 0)
							{
								x.Balance = 0;
								y.Balance = 0;
							}
							else // w.Balance == 1
							{
								x.Balance = -1;
								y.Balance = 0;
							}

							w.Balance = 0;

							y = w; // for next iteration
						}
						else
						{
							x.Parent = y.Parent;

							if (y.Parent != null)
							{
								if (y.Parent.Left == y)
								{
									y.Parent.Left = x;
								}
								else
								{
									y.Parent.Right = x;
								}
							}
							else
							{
								this._Root = x;
							}

							y.Left = x.Right;

							if (y.Left != null)
							{
								y.Left.Parent = y;
							}

							x.Right = y;
							y.Parent = x;

							if (x.Balance == 0)
							{
								x.Balance = 1;
								y.Balance = -1;

								goto Done;
							}
							else
							{
								x.Balance = 0;
								y.Balance = 0;

								y = x; // for next iteration
							}
						}
					}

				LoopTest:

					if (y.Parent != null)
					{
						if (y == y.Parent.Left)
						{
							y = y.Parent;
							goto LeftDelete;
						}

						y = y.Parent;
						goto RightDelete;
					}

				Done:

					this._Count--;
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Gets or sets the element with the specified <paramref name="Key"/>.
		/// </summary>
		/// <param name="Key">
		/// The key of the element to get or set.
		/// </param>
		/// <returns>
		/// The value of the element with the specified <paramref name="Key"/>.
		/// </returns>
		/// <remarks>
		/// <para>
		/// The <see cref="this"/> property can be used to add new elements by setting
		/// the value of a key that does not exist in <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// If the specified <paramref name="Key"/> already exists in the dictionary,
		/// setting the <see cref="this"/> property overwrites the old value.
		/// </para>
		/// <para>
		/// Accessing this property is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </para>
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Key"/> is a <c>null</c> reference.
		/// </exception>
		/// <exception cref="KeyNotFoundException">
		/// The property is retrieved and <paramref name="Key"/> is not found.
		/// </exception>
		public V this[K Key]
		{
			get
			{
				if (Key == null)
				{
					throw new ArgumentNullException();
				}

				for (Node p = this._Root; p != null; )
				{
					int Comparer = Key.CompareTo(p.Item.Key);

					if (Comparer < 0)
					{
						p = p.Left;
					}
					else if (Comparer > 0)
					{
						p = p.Right;
					}
					else
					{
						return p.Item.Value;
					}
				}

				throw new KeyNotFoundException();
			}
			set
			{
				if (Key == null)
				{
					throw new ArgumentNullException();
				}

				if (this._Root == null)
				{
					this._Root = new Node(new KeyValuePair<K, V>(Key, value));
				}
				else
				{
					Node p = this._Root;

					for (; ; )
					{
						int Comparer = Key.CompareTo(p.Item.Key);

						if (Comparer < 0)
						{
							if (p.Left != null)
							{
								p = p.Left;
							}
							else
							{
								p.Left = new Node(new KeyValuePair<K, V>(Key, value), p);
								p.Balance--;

								break;
							}
						}
						else if (Comparer > 0)
						{
							if (p.Right != null)
							{
								p = p.Right;
							}
							else
							{
								p.Right = new Node(new KeyValuePair<K, V>(Key, value), p);
								p.Balance++;

								break;
							}
						}
						else
						{
							p.Item.Value = value;
							return;
						}
					}

					while ((p.Balance != 0) && (p.Parent != null))
					{
						if (p.Parent.Left == p)
						{
							p.Parent.Balance--;
						}
						else
						{
							p.Parent.Balance++;
						}

						p = p.Parent;

						if (p.Balance == -2)
						{
							Node x = p.Left;

							if (x.Balance == -1)
							{
								x.Parent = p.Parent;

								if (p.Parent == null)
								{
									this._Root = x;
								}
								else
								{
									if (p.Parent.Left == p)
									{
										p.Parent.Left = x;
									}
									else
									{
										p.Parent.Right = x;
									}
								}

								p.Left = x.Right;

								if (p.Left != null)
								{
									p.Left.Parent = p;
								}

								x.Right = p;
								p.Parent = x;

								x.Balance = 0;
								p.Balance = 0;
							}
							else
							{
								Node w = x.Right;

								w.Parent = p.Parent;

								if (p.Parent == null)
								{
									this._Root = w;
								}
								else
								{
									if (p.Parent.Left == p)
									{
										p.Parent.Left = w;
									}
									else
									{
										p.Parent.Right = w;
									}
								}

								x.Right = w.Left;

								if (x.Right != null)
								{
									x.Right.Parent = x;
								}

								p.Left = w.Right;

								if (p.Left != null)
								{
									p.Left.Parent = p;
								}

								w.Left = x;
								w.Right = p;

								x.Parent = w;
								p.Parent = w;

								if (w.Balance == -1)
								{
									x.Balance = 0;
									p.Balance = 1;
								}
								else if (w.Balance == 0)
								{
									x.Balance = 0;
									p.Balance = 0;
								}
								else // w.Balance == 1
								{
									x.Balance = -1;
									p.Balance = 0;
								}

								w.Balance = 0;
							}

							break;
						}
						else if (p.Balance == 2)
						{
							Node x = p.Right;

							if (x.Balance == 1)
							{
								x.Parent = p.Parent;

								if (p.Parent == null)
								{
									this._Root = x;
								}
								else
								{
									if (p.Parent.Left == p)
									{
										p.Parent.Left = x;
									}
									else
									{
										p.Parent.Right = x;
									}
								}

								p.Right = x.Left;

								if (p.Right != null)
								{
									p.Right.Parent = p;
								}

								x.Left = p;
								p.Parent = x;

								x.Balance = 0;
								p.Balance = 0;
							}
							else
							{
								Node w = x.Left;

								w.Parent = p.Parent;

								if (p.Parent == null)
								{
									this._Root = w;
								}
								else
								{
									if (p.Parent.Left == p)
									{
										p.Parent.Left = w;
									}
									else
									{
										p.Parent.Right = w;
									}
								}

								x.Left = w.Right;

								if (x.Left != null)
								{
									x.Left.Parent = x;
								}

								p.Right = w.Left;

								if (p.Right != null)
								{
									p.Right.Parent = p;
								}

								w.Right = x;
								w.Left = p;

								x.Parent = w;
								p.Parent = w;

								if (w.Balance == 1)
								{
									x.Balance = 0;
									p.Balance = -1;
								}
								else if (w.Balance == 0)
								{
									x.Balance = 0;
									p.Balance = 0;
								}
								else // w.Balance == -1
								{
									x.Balance = 1;
									p.Balance = 0;
								}

								w.Balance = 0;
							}

							break;
						}
					}
				}

				this._Count++;
			}
		}

		/// <summary>
		/// Gets a collection containing the keys in <see cref="TreeDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <value>
		/// <see cref="KeyCollection"/> containing the
		/// keys in <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// </value>
		public KeyCollection Keys
		{
			get
			{
				return this._Keys;
			}
		}

		/// <summary>
		/// Gets a collection containing the values in <see cref="TreeDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <value>
		/// <see cref="ValueCollection"/> containing the
		/// values in <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// </value>
		public ValueCollection Values
		{
			get
			{
				return this._Values;
			}
		}

		/// <summary>
		/// Gets a collection containing the keys in <see cref="TreeDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <value>
		/// <see cref="IReadOnlyCollection&lt;T&gt;"/> containing the
		/// keys in <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// </value>
		IReadOnlyCollection<K> IDictionary<K, V>.Keys
		{
			get
			{
				return this._Keys;
			}
		}

		/// <summary>
		/// Gets a collection containing the values in <see cref="TreeDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <value>
		/// <see cref="IReadOnlyCollection&lt;T&gt;"/> containing the
		/// values in <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// </value>
		IReadOnlyCollection<V> IDictionary<K, V>.Values
		{
			get
			{
				return this._Values;
			}
		}

		/// <summary>
		/// Removes all elements from this <see cref="TreeDictionary&lt;K,V&gt;"/>. 
		/// </summary>
		/// <remarks>
		/// <para>
		/// This method is an O(1) operation.
		/// </para>
		/// <para>
		/// The <see cref="Count"/> property is set to zero, and references to other
		/// objects from elements of the collection are also released.
		/// </para>
		/// </remarks>
		public void Clear()
		{
			this._Root	= null;
			this._Count	= 0;
		}

		/// <summary>
		/// Gets the number of elements contained in this <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <value>
		/// The number of elements contained in this <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </value>
		/// <remarks>
		/// Retrieving the value of this property is an O(1) operation.
		/// </remarks>
		public int Count
		{
			get
			{
				return this._Count;
			}
		}

		/// <summary>
		/// Determines whether this <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// contains a specific key/value pair.
		/// </summary>
		/// <param name="Item">
		/// The <see cref="KeyValuePair&lt;K,V&gt;"/> structure to locate in
		/// this <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </param>
		/// <returns>
		/// <c>true</c>, if <paramref name="Item"/> is found in this
		/// <see cref="TreeDictionary&lt;K,V&gt;"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <remarks>
		/// <para>
		/// This method determines equality by first using
		/// <see cref="IComparable&lt;T&gt;.CompareTo"/> for the key and then using
		/// <see cref="object.Equals(object)"/> for the value.
		/// </para>
		/// <para>
		/// To enhance performance, it is recommended that in addition to implementing
		/// <see cref="Object.Equals(object)"/>, any class/struct also implement
		/// <see cref="IEquatable&lt;T&gt;"/> interface for their own type.
		/// </para>
		/// <para>
		/// This method is an O(log2 n) operation, where n is <see cref="Count"/>.
		/// </para>
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Item"/> is a <c>null</c> reference.
		/// </exception>
		public bool Contains(KeyValuePair<K, V> Item)
		{
			if (Item.Key == null)
			{
				throw new ArgumentNullException();
			}

			for (Node p = this._Root; p != null; )
			{
				int Comparer = Item.Key.CompareTo(p.Item.Key);

				if (Comparer < 0)
				{
					p = p.Left;
				}
				else if (Comparer > 0)
				{
					p = p.Right;
				}
				else
				{
					if (Item.Value != null)
					{
						return Item.Value.Equals(p.Item.Value);
					}

					return (p.Item.Value == null);
				}
			}

			return false;
		}

		/// <summary>
		/// Copies the <see cref="TreeDictionary&lt;K,V&gt;"/> elements to an existing
		/// one-dimensional <see cref="Array"/>, starting at the specified array index.
		/// </summary>
		/// <param name="Array">
		/// The one-dimensional <see cref="Array"/> that is the destination of the elements
		/// copied from this <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// <paramref name="Array"/> must have zero-based indexing.
		/// </param>
		/// <param name="Index">
		/// The zero-based index in <paramref name="Array"/> at which copying begins.
		/// </param>
		/// <remarks>
		/// <para>
		/// The elements are copied to <paramref name="Array"/> in ascending order.
		/// </para>
		/// <para>
		/// This method is an O(n) operation, where n is <see cref="Count"/>.
		/// </para>
		/// </remarks>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="Array"/> is a <c>null</c> reference.
		/// </exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="Index"/> is outside of <paramref name="Array"/> bounds.
		/// </exception>
		/// <exception cref="ArgumentException">
		/// The number of elements in the source <see cref="TreeDictionary&lt;K,V&gt;"/>
		/// is greater than the available space from <paramref name="Index"/> to the end
		/// of the destination <paramref name="Array"/>.
		/// </exception>
		public void CopyTo(KeyValuePair<K, V>[] Array, int Index)
		{
			if (Array == null)
			{
				throw new ArgumentNullException();
			}

			if ((Index < 0) || (Index >= Array.Length))
			{
				throw new ArgumentOutOfRangeException();
			}

			if ((Array.Length - Index) < this._Count)
			{
				throw new ArgumentException();
			}

			if (this._Root != null)
			{
				Node p = this._Root;

				while (p.Left != null)
				{
					p = p.Left;
				}

				for (; ; )
				{
					Array[Index] = p.Item;

					if (p.Right == null)
					{
						for (; ; )
						{
							if (p.Parent == null)
							{
								return;
							}

							if (p != p.Parent.Right)
							{
								break;
							}

							p = p.Parent;
						}

						p = p.Parent;
					}
					else
					{
						for (p = p.Right; p.Left != null; p = p.Left) ;
					}

					Index++;
				}
			}
		}

		/// <summary>
		/// Returns an enumerator that iterates through the
		/// <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </summary>
		/// <returns>
		/// An <see cref="AscendingOrderEnumerator"/> for the
		/// <see cref="TreeDictionary&lt;K,V&gt;"/>.
		/// </returns>
		public AscendingOrderEnumerator GetEnumerator()
		{
			return new AscendingOrderEnumerator(this._Root);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="TreeDictionary&lt;K,V&gt;"/> class.
		/// </summary>
		/// <remarks>
		/// This constructor is an O(1) operation.
		/// </remarks>
		public TreeDictionary()
		{
			this._Keys		= new KeyCollection(this);
			this._Values	= new ValueCollection(this);
		}

	}
}