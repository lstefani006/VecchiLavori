//
// Copyright � 2005 - 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
    /// <summary>
    /// Represents a node in a doubly linked list.
    /// </summary>
    /// <remarks>
    /// The <see cref="DoublyLinkedListNode&lt;T&gt;"/> contains a value,
	/// a reference to the next node, and a reference to the previous node.
    /// </remarks>
	/// <typeparam name="T">
	/// The type of the <see cref="Item"/> contained
	/// in the <see cref="DoublyLinkedListNode&lt;T&gt;"/>.
	/// </typeparam>
    public sealed class DoublyLinkedListNode<T>
    {
        /// <summary>
        /// The object contained in this node.
        /// </summary>
        public T Item;

        /// <summary>
        /// The reference to the previous node in the doubly linked list or <c>null</c>
        /// if this <see cref="DoublyLinkedListNode&lt;T&gt;"/> is the first node in
		/// the doubly linked list. 
        /// </summary>
        public DoublyLinkedListNode<T> Previous;

        /// <summary>
        /// The reference to the next node in the doubly linked list or <c>null</c>
        /// if this <see cref="DoublyLinkedListNode&lt;T&gt;"/> is the last node in
		/// the doubly linked list.
        /// </summary>
        public DoublyLinkedListNode<T> Next;

		/// <summary>
		/// Initializes a new instance of the <see cref="DoublyLinkedListNode&lt;T&gt;"/>
		/// class containing the specified object.
		/// </summary>
		/// <param name="Item">
		/// The object to contain in the <see cref="DoublyLinkedListNode&lt;T&gt;"/>.
		/// </param>
		/// <remarks>
		/// The <see cref="Previous"/> and <see cref="Next"/> fields are initialized to <c>null</c>.
		/// </remarks>
		public DoublyLinkedListNode(T Item)
		{
			this.Item = Item;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="DoublyLinkedListNode&lt;T&gt;"/>
		/// class, containing the specified object and the references to the previous and
		/// next nodes in the doubly linked list.
		/// </summary>
		/// <param name="Item">
		/// The object to contain in the <see cref="DoublyLinkedListNode&lt;T&gt;"/>.
		/// </param>
		/// <param name="Previous">
		/// The reference to the previous node in the doubly linked list.
		/// </param>
		/// <param name="Next">
		/// The reference to the next node in the doubly linked list.
		/// </param>
        public DoublyLinkedListNode(T Item, DoublyLinkedListNode<T> Previous, DoublyLinkedListNode<T> Next)
		{
			this.Item		= Item;
			this.Previous   = Previous;
			this.Next       = Next;   
		}

    }
}