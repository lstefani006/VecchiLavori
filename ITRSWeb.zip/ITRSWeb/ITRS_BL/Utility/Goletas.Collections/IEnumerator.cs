//
// Copyright � 2006 Maksim Goleta. All rights reserved.
// GOLETAS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//

namespace Goletas.Collections
{
	public interface IEnumerator<T>
	{
		bool MoveNext();

		T Current
		{
			get;
		}

	}
}