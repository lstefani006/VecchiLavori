using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Configuration;
using System.Globalization;
using System.Diagnostics;

namespace ITRS_BL
{
	public static class ClassProvider<T>
		where T : class
	{
		public static T CreateFactory(string key)
		{
			if (_IDalFactory == null)
			{
				lock (_lock)
				{
					if (_IDalFactory == null)
					{
						string s = ConfigurationManager.AppSettings[key];
						Type ty = Type.GetType(s);
						_IDalFactory = (T)Activator.CreateInstance(ty);
					}
				}
			}

			return _IDalFactory;
		}

		private static volatile T _IDalFactory = null;
		private static volatile object _lock = new object();
	}


	public static class ReadAppSettings
	{
		private static string GetAppSettings(string k)
		{

			string v = Environment.GetEnvironmentVariable(k.Replace('.', '_'));
			if (v == null)
				v = ConfigurationManager.AppSettings[k];
			return v;
		}

		public static int ToInt32(string k, int defaultValue)
		{
			string s = GetAppSettings(k);
			int r;
			if (int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out r))
				return r;
			return defaultValue;
		}

		public static bool ToBoolean(string k, bool defaultValue)
		{
			string s = GetAppSettings(k);
			if (s != null)
				return bool.Parse(s);
			return defaultValue;
		}

		/// <summary>
		/// Ritorna un DateTime formattato in "YYYY MM DD HH MI SS"
		/// (i valori possono essere separati da blank - / : )
		/// </summary>
		/// <param name="k">Nome nel file di configurazione</param>
		/// <param name="defaultValue">Valore di default o in caso di errore</param>
		/// <returns>il parametro di configurazione</returns>
		public static DateTime ToDateTime(string k, DateTime defaultValue)
		{
			string s = GetAppSettings(k);
			if (s == null) return defaultValue;
			s = s.Trim();
			try
			{
				string[] a = s.Split(' ', ':', '/', '-');

				int[] b = new int[6];
				int bi = 0;

				for (int ai = 0; ai < a.Length; ++ai)
				{
					string v = a[ai].Trim();
					if (v != "")
						b[bi++] = Int32.Parse(v);
				}

				if (bi != 6)
					return defaultValue;

				return new DateTime(b[0], b[1], b[2], b[3], b[4], b[5]);
			}
			catch
			{
				return defaultValue;
			}
		}

		public static string ToString(string k, string defaultValue)
		{
			string s = GetAppSettings(k);
			if (s == null)
				s = defaultValue;

			if (s.StartsWith("$$"))
			{
				string root = Environment.GetEnvironmentVariable("ITRS_Root");
				if (root == null)
					root = ConfigurationManager.AppSettings["RootPath"];

				if (root == null)
				{
					Log.Write("Inserire il path di root nel file di configurazione");
					throw new Exception("Inserire il path di root nel file di configurazione");
				}

				s = s.Replace("$$", root);
			}

			return s;
		}

		/// <summary>
		/// Legge il contenuto del file specificato dalla chiave k
		/// Se la chiave non e` specificata nel file .config la funzione ritorna defaultValue.
		/// Se la chiave e` specificata nel file .config ma il valore e` vuoto la funzione ritorna defaultValue.
		/// Se la chiave e` specificata nel file .config il valore indica punta al path di un file che DEVE esistere e la funzione ritorna il contenuto del file
		/// </summary>
		/// <param name="k">La chiave nel file di configurazione</param>
		/// <param name="defaultValue">il valore di default se la chiave non esiste o se il valore e` ""</param>
		/// <returns>il contenuto del file o il valore di defualt</returns>
		public static string ToStringFromFile(string k, string defaultValue)
		{
			string s = GetAppSettings(k);
			if (s == null)
				return defaultValue;

			if (s.StartsWith("$$"))
			{
				string root = Environment.GetEnvironmentVariable("ITRS_Root");
				if (root == null)
					root = ConfigurationManager.AppSettings["RootPath"];

				if (root == null)
				{
					Log.Write("Inserire il path di root nel file di configurazione");
					throw new Exception("Inserire il path di root nel file di configurazione");
				}

				s = s.Replace("$$", root);
			}

			if (s != "")
				s = File.ReadAllText(s);

			return s;
		}



	}

	public static class Log
	{
		private static string ApplicationName
		{
			get
			{
				string s = ReadAppSettings.ToString("LogIdentifier", "");
				if (s != "") s += ": ";
				if (AppDomain.CurrentDomain.SetupInformation.ConfigurationFile.IndexOf("web.config", StringComparison.CurrentCultureIgnoreCase) < 0)
					s += AppDomain.CurrentDomain.FriendlyName;
				else
					s += AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
				return s;
			}
		}
		public static void Write(string msg)
		{
			Trace.WriteLine(msg);
			using (BLLog bl = new BLLog())
			{
				bl.Add(ApplicationName, BLLog.LogType.Trace, msg);
			}
		}

		public static void Write(string fmt, params object[] args)
		{
			string msg = string.Format(fmt, args);
			Write(msg);
		}

		public static void Write(Exception ex, string fmt, params object[] args)
		{
			string msg = string.Format(fmt, args);
			Write(ex, msg);
		}

		public static void Write(Exception ex, string context)
		{
			Trace.WriteLine(context);
			Trace.WriteLine("{");

			Trace.WriteLine("Message:");
			Trace.WriteLine(ex.Message);

			Trace.WriteLine("Stack trace:");
			Trace.WriteLine(ex.StackTrace);

			Trace.WriteLine("}");

			string exMsg = WriteException(ex);

			using (BLLog bl = new BLLog())
			{
				bl.Add(ApplicationName, BLLog.LogType.Error, context, exMsg);
			}
		}


		private static string WriteException(Exception ex)
		{
			StringWriter ss = new StringWriter();
			XmlTextWriter xw = new XmlTextWriter(ss);

			xw.Formatting = Formatting.Indented;
			xw.Indentation = 2;
			xw.IndentChar = ' ';
			xw.WriteStartDocument();
			xw.WriteStartElement("Log");

			WriteException(xw, ex);

			xw.WriteStartElement("StackTrace");
			xw.WriteString(Environment.StackTrace);
			xw.WriteEndElement();

			xw.WriteEndElement();
			xw.WriteEndDocument();

			xw.Flush();

			return ss.ToString();
		}
		private static void WriteException(XmlTextWriter xw, Exception ex)
		{
			xw.WriteStartElement("Exception");

			xw.WriteStartElement("Message");
			xw.WriteString(ex.Message);
			xw.WriteEndElement();

			xw.WriteStartElement("Source");
			xw.WriteString(ex.Source);
			xw.WriteEndElement();

			xw.WriteStartElement("StackTrace");
			xw.WriteString(ex.StackTrace);
			xw.WriteEndElement();

			if (ex.InnerException != null)
			{
				xw.WriteStartElement("InnerException");
				WriteException(xw, ex.InnerException);
				xw.WriteEndElement();
			}

			xw.WriteEndElement();
		}
	}

	public static partial class U
	{
		public static void Swap<T>(ref T a, ref T b)
		{
			T t = a;
			a = b;
			b = t;
		}

		public static IEnumerable<List<T>> Group<T>(IEnumerable<T> e, int maxItems)
		{
			List<T> lst = new List<T>(maxItems);
			foreach (T r in e)
			{
				lst.Add(r);

				if (lst.Count >= maxItems)
				{
					yield return lst;
					lst.Clear();
				}
			}
			if (lst.Count > 0)
				yield return lst;
		}


		public delegate bool GroupByPredicate<T>(T a, T b);
		/// <summary>
		/// Raggruppa un enumerabile in ingresso usando il predicato.
		/// Se l'enumerabile e` sortato per un qualche criterio, si puo` accorpare
		/// tutti gli elementi che condividono lo stesso criterio.
		/// Si puo` anche usare un criterio di raggruppamento esterno, per es il massimo numero
		/// di elementi per raggruppamento.
		/// Il principale vantaggio di questa implementazione (alquanto sofisticata) consiste
		/// nel fatto che non consuma memoria.
		/// </summary>
		/// <example>
		/// <code>
		///		List<U2<string, int>> r = ..... // viene valorizzata da qualche parte
		///		foreach (IEnumerable<T> g in U.GroupBy(r, predicate))
		///		{
		///			// ho un gruppo in 'g'
		///			foreach (T e in g)
		///			{
		///				// e e` un elemento del gruppo g
		///			}
		///		}
		/// </code>
		/// </example>
		/// <typeparam name="T">il tipo dell'enumerabile</typeparam>
		/// <param name="e">l'enumerabile di tipo T da partizionare</param>
		/// <param name="predicate">il predicato che ritorna true per indicare lo stesso gruppo</param>
		/// <returns>un enumerabile di enumerabile di T</returns>
		public static IEnumerable<IEnumerable<T>> GroupBy<T>(IEnumerable<T> e, GroupByPredicate<T> predicate)
		{
			using (IEnumerator<T> en = e.GetEnumerator())
			{
				if (en.MoveNext() == false)
					yield break;

				SameGroup<T> sg;
				do
				{
					sg = new SameGroup<T>(en, en.Current, predicate);
					yield return sg;
				}
				while (sg.Eof == false);
			}
		}

		private class SameGroup<T> : IEnumerable<T>
		{
			internal SameGroup(IEnumerator<T> e, T first, GroupByPredicate<T> predicate)
			{
				_e = e;
				_first = first;
				_predicate = predicate;
				_eof = false;
			}

			readonly IEnumerator<T> _e;
			readonly T _first;
			readonly GroupByPredicate<T> _predicate;
			bool _eof;

			public bool Eof { get { return _eof; } }

			public IEnumerator<T> GetEnumerator()
			{
				yield return _first;

				while (_e.MoveNext())
				{
					if (_predicate(_first, _e.Current) == true)
						yield return _e.Current;
					else
						yield break;
				}
				_eof = true;
			}

			System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
			{
				return GetEnumerator();
			}
		}


		public delegate bool FilterPredicate<T>(T a);
		public static IEnumerable<T> Filter<T>(IEnumerable<T> e, FilterPredicate<T> predicate)
		{
			foreach (T r in e)
			{
				if (predicate(r))
					yield return r;
			}
		}

		public delegate bool FindFirstPredicate<T>(T a);
		public static T FindFirst<T>(IEnumerable<T> e, FindFirstPredicate<T> predicate)
		{
			foreach (T r in e)
			{
				if (predicate(r))
					return r;
			}
			return default(T);
		}


		[Serializable]
		public class R2<T1, T2>
		{
			private T1 _t1;
			private T2 _t2;

			public T1 F1 { get { return _t1; } set { _t1 = value; } }
			public T2 F2 { get { return _t2; } set { _t2 = value; } }
		}
		[Serializable]
		public class R3<T1, T2, T3>
		{
			private T1 _t1;
			private T2 _t2;
			private T3 _t3;

			public T1 F1 { get { return _t1; } set { _t1 = value; } }
			public T2 F2 { get { return _t2; } set { _t2 = value; } }
			public T3 F3 { get { return _t3; } set { _t3 = value; } }
		}
		[Serializable]
		public class R4<T1, T2, T3, T4>
		{
			private T1 _t1;
			private T2 _t2;
			private T3 _t3;
			private T4 _t4;

			public T1 F1 { get { return _t1; } set { _t1 = value; } }
			public T2 F2 { get { return _t2; } set { _t2 = value; } }
			public T3 F3 { get { return _t3; } set { _t3 = value; } }
			public T4 F4 { get { return _t4; } set { _t4 = value; } }
		}
		[Serializable]
		public class R5<T1, T2, T3, T4, T5>
		{
			private T1 _t1;
			private T2 _t2;
			private T3 _t3;
			private T4 _t4;
			private T5 _t5;

			public T1 F1 { get { return _t1; } set { _t1 = value; } }
			public T2 F2 { get { return _t2; } set { _t2 = value; } }
			public T3 F3 { get { return _t3; } set { _t3 = value; } }
			public T4 F4 { get { return _t4; } set { _t4 = value; } }
			public T5 F5 { get { return _t5; } set { _t5 = value; } }
		}
		[Serializable]
		public class R6<T1, T2, T3, T4, T5, T6>
		{
			private T1 _t1;
			private T2 _t2;
			private T3 _t3;
			private T4 _t4;
			private T5 _t5;
			private T6 _t6;

			public T1 F1 { get { return _t1; } set { _t1 = value; } }
			public T2 F2 { get { return _t2; } set { _t2 = value; } }
			public T3 F3 { get { return _t3; } set { _t3 = value; } }
			public T4 F4 { get { return _t4; } set { _t4 = value; } }
			public T5 F5 { get { return _t5; } set { _t5 = value; } }
			public T6 F6 { get { return _t6; } set { _t6 = value; } }
		}


		public class RunProcess : IDisposable
		{
			Process _p;

			public event DataReceivedEventHandler Stdout { add { _p.OutputDataReceived += value; } remove { _p.OutputDataReceived -= value; } }
			public event DataReceivedEventHandler Stderr { add { _p.ErrorDataReceived += value; } remove { _p.ErrorDataReceived -= value; } }

			public RunProcess()
			{
				_p = new Process();
				_p.StartInfo.UseShellExecute = false;
				_p.StartInfo.RedirectStandardError = true;
				_p.StartInfo.RedirectStandardOutput = true;
			}
			public RunProcess(string exe, string args)
				: this()
			{
				_p.StartInfo.FileName = exe;
				_p.StartInfo.Arguments = args;
			}
			public virtual void Start()
			{
				_p.Start();
				_p.BeginErrorReadLine();
				_p.BeginOutputReadLine();
			}
			public virtual void Start(string exe, string args)
			{
				_p.StartInfo.FileName = exe;
				_p.StartInfo.Arguments = args;
				_p.Start();
				_p.BeginErrorReadLine();
				_p.BeginOutputReadLine();
			}

			public virtual int WaitForEver()
			{
				_p.WaitForExit();
				return _p.ExitCode;
			}

			/// <summary>
			/// Ritorna false per timeout, true se il processo e` finito.
			/// </summary>
			/// <param name="millisec"></param>
			/// <param name="exitCode"></param>
			/// <returns></returns>
			public virtual bool WaitTimeout(int millisec, out int exitCode)
			{
				exitCode = -1;

				bool b = _p.WaitForExit(millisec);
				if (b == false)
					return false; // timeout

				exitCode = _p.ExitCode;
				return true;
			}

			public virtual void Kill()
			{
				_p.CancelErrorRead();
				_p.CancelOutputRead();
				_p.Kill();
				_p.WaitForExit();
			}
			public void Dispose()
			{
				_p.Dispose();
			}
		}

		public class PlinkProcess : IDisposable
		{
			RunProcess _p;

			public event DataReceivedEventHandler Stdout { add { _p.Stdout += value; } remove { _p.Stdout -= value; } }
			public event DataReceivedEventHandler Stderr { add { _p.Stderr += value; } remove { _p.Stderr -= value; } }

			string _login;
			string _pwd;
			string _host;

			public string Login { get { return _login; } set { _login = value; } }
			public string Host { get { return _host; } set { _host = value; } }
			public string Pwd { get { return _pwd; } set { _pwd = value; } }

			public PlinkProcess(string connectionId)
			{
				_p = new RunProcess();

				if (!string.IsNullOrEmpty(connectionId))
					connectionId += ".";

				_login = ReadAppSettings.ToString(connectionId + "PuTTY.login", "mwp");
				_pwd = ReadAppSettings.ToString(connectionId + "PuTTY.pwd", "mwp");
				_host = ReadAppSettings.ToString(connectionId + "PuTTY.host", "172.22.58.54");
			}

			public void Start(string remoteCmd)
			{
				string exe = ReadAppSettings.ToString("PuTTY.plink.exe", @"$$\PuTTY\plink.exe");
				string args = string.Format("-T -batch -storekey -ssh -l {0} -pw {1} {2} {3}", _login, _pwd, _host, remoteCmd);
				_p.Start(exe, args);
			}

			public int WaitForEver()
			{
				return _p.WaitForEver();
			}

			public bool WaitTimeout(int millisec, out int exitCode)
			{
				return _p.WaitTimeout(millisec, out exitCode);
			}

			public void Kill()
			{
				_p.Kill();
			}

			public void Dispose()
			{
				_p.Dispose();
			}
		}

		public class PscpProcess : IDisposable
		{
			RunProcess _p;

			public event DataReceivedEventHandler Stdout { add { _p.Stdout += value; } remove { _p.Stdout -= value; } }
			public event DataReceivedEventHandler Stderr { add { _p.Stderr += value; } remove { _p.Stderr -= value; } }

			string _login;
			string _pwd;
			string _host;

			public string Login { get { return _login; } set { _login = value; } }
			public string Host { get { return _host; } set { _host = value; } }
			public string Pwd { get { return _pwd; } set { _pwd = value; } }


			public PscpProcess(string connectionId)
			{
				_p = new RunProcess();

				if (string.IsNullOrEmpty(connectionId))
					connectionId = "";
				else
					connectionId += ".";

				_login = ReadAppSettings.ToString(connectionId + "PuTTY.login", "mwp");
				_pwd = ReadAppSettings.ToString(connectionId + "PuTTY.pwd", "mwp");
				_host = ReadAppSettings.ToString(connectionId + "PuTTY.host", "172.22.58.54");
			}
			public void Upload(string localPath, string localFileName, string remotePath, string remoteFileName)
			{
				if (string.IsNullOrEmpty(localPath))
					localPath = ".";

				if (string.IsNullOrEmpty(localFileName))
					throw new ArgumentException("localFileName required", "localFileName");

				if (string.IsNullOrEmpty(remotePath))
					remotePath = ".";

				if (string.IsNullOrEmpty(remoteFileName))
					remoteFileName = localFileName;

				string src = Path.Combine(localPath, localFileName);
				string dst = remotePath + "/" + remoteFileName;

				string exe = ReadAppSettings.ToString("PuTTY.pscp.exe", @"$$\PuTTY\pscp.exe");
				string args = string.Format("-q -pw {0} -batch -storekey \"{1}\" {2}@{3}:{4}", _pwd, src, _login, _host, dst);
				_p.Start(exe, args);
			}
			public void Download(string remotePath, string remoteFileName, string localPath, string localFileName)
			{
				if (string.IsNullOrEmpty(remotePath))
					remotePath = ".";

				if (string.IsNullOrEmpty(remoteFileName))
					throw new ArgumentException("remoteFileName required", "remoteFileName");

				if (string.IsNullOrEmpty(localPath))
					localPath = ".";

				if (string.IsNullOrEmpty(localFileName))
					localFileName = remoteFileName;

				string src = remotePath + "/" + remoteFileName;
				string dst = Path.Combine(localPath, localFileName);

				string exe = ReadAppSettings.ToString("PuTTY.pscp.exe", @"$$\PuTTY\pscp.exe");
				string args = string.Format("-q -pw {0} -batch -storekey {1}@{2}:{3} \"{4}\"", _pwd, _login, _host, src, dst);

				_p.Start(exe, args);
			}

			public int WaitForEver() { return _p.WaitForEver(); }
			public bool WaitTimeout(int millisec, out int exitCode) { return _p.WaitTimeout(millisec, out exitCode); }
			public void Kill() { _p.Kill(); }
			public void Dispose() { _p.Dispose(); }
		}

		public class PuTTYException : Exception
		{
			public PuTTYException(int exitCode, string msg, string stdErr)
				: base(msg)
			{
				this.ExitCode = exitCode;
				this.StdErr = stdErr;
			}

			public override string Message
			{
				get
				{
					return base.Message + ": exit code = " + ExitCode.ToString() + " " + StdErr;
				}
			}

			readonly int ExitCode;
			readonly string StdErr;
		}

		public static class FtpClient
		{
			public static void Download(string connectionId,
				string remotePath, string remoteFileName,
				string localPath, string localFileName)
			{
				if (string.IsNullOrEmpty(remoteFileName))
					throw new ArgumentException("remoteFileName required", "remoteFileName");

				if (string.IsNullOrEmpty(localPath))
					localPath = ".";

				if (string.IsNullOrEmpty(localFileName))
					localFileName = remoteFileName;

				using (FtpClientLib.FTPClient ftp = new FtpClientLib.FTPClient())
				{
					ReadCfg(connectionId, ftp);

					if (!string.IsNullOrEmpty(remotePath))
						ftp.RemotePath = remotePath;

					// qui mi logo al server FTP e al contempo vado alla directory remota se specificata.
					ftp.login();
					ftp.setBinaryMode(true);

					string localPathFileName = Path.Combine(localPath, localFileName);

					ftp.download(remoteFileName, localPathFileName);
				}
			}
			public static void Upload(string connectionId,
				string localPath, string localFileName,
				string remotePath, string remoteFileName)
			{
				if (string.IsNullOrEmpty(localPath))
					localPath = ".";

				if (string.IsNullOrEmpty(localFileName))
					throw new ArgumentException("localFileName required", "localFileName");

				if (string.IsNullOrEmpty(remoteFileName))
					remoteFileName = localFileName;


				using (FtpClientLib.FTPClient ftp = new FtpClientLib.FTPClient())
				{
					ReadCfg(connectionId, ftp);

					if (!string.IsNullOrEmpty(remotePath))
						ftp.RemotePath = remotePath;

					// qui mi logo al server FTP e al contempo vado alla directory remota se specificata.
					ftp.login();
					ftp.setBinaryMode(false);

					string localPathFileName = Path.Combine(localPath, localFileName);
					using (FileStream sr = File.OpenRead(localPathFileName))
					{
						ftp.upload(sr, sr.Length, remoteFileName);
					}
				}
			}

			public static string[] Dir(string connectionId, string remoteDir)
			{
				using (FtpClientLib.FTPClient ftp = new FtpClientLib.FTPClient())
				{
					ReadCfg(connectionId, ftp);

					if (string.IsNullOrEmpty(remoteDir))
						remoteDir = ".";

					ftp.RemotePath = remoteDir;
					// qui mi logo al server FTP e al contempo vado alla directory remota se specificata.
					ftp.login();

					return ftp.getFileList("*");
				}
			}
			private static void ReadCfg(string connectionId, FtpClientLib.FTPClient ftp)
			{
				if (string.IsNullOrEmpty(connectionId))
					connectionId = "";
				else
					connectionId += ".";
				ftp.RemoteHost = ReadAppSettings.ToString(connectionId + "ftp.host", "172.22.58.54");
				ftp.RemoteUser = ReadAppSettings.ToString(connectionId + "ftp.login", "mwp");
				ftp.RemotePass = ReadAppSettings.ToString(connectionId + "ftp.pwd", "mwp");
				ftp.RemotePort = ReadAppSettings.ToInt32(connectionId + "ftp.port", 21);
			}
		}
		public static class PuTTYClient
		{
			public static void Download(string connectionId, string remotePath, string remoteFileName, string localPath, string localFileName)
			{
				string err = string.Empty;
				using (PscpProcess p = new PscpProcess(connectionId))
				{
					p.Stderr += delegate(object sender, DataReceivedEventArgs e)
					{
						if (!string.IsNullOrEmpty(e.Data))
							err += e.Data + Environment.NewLine;
					};

					p.Download(remotePath, remoteFileName, localPath, localFileName);
					int ec = p.WaitForEver();
					if (ec != 0)
						new PuTTYException(ec, "PuTTYClient.Download", err);
				}
			}
			public static void Upload(string connectionId, string localPath, string localFileName, string remotePath, string remoteFileName)
			{
				string err = string.Empty;
				using (PscpProcess p = new PscpProcess(connectionId))
				{
					p.Stderr += delegate(object sender, DataReceivedEventArgs e)
					{
						if (!string.IsNullOrEmpty(e.Data))
							err += e.Data + Environment.NewLine;
					};
					p.Upload(localPath, localFileName, remotePath, remoteFileName);
					int ec = p.WaitForEver();
					if (ec != 0)
						new PuTTYException(ec, "PuTTYClient.Upload", err);
				}
			}
			public static string[] Dir(string connectionId, string remoteDir)
			{
				List<string> ret = new List<string>();
				string err = string.Empty;
				using (PlinkProcess p = new PlinkProcess(connectionId))
				{
					p.Stderr += delegate(object sender, DataReceivedEventArgs e)
					{
						if (!string.IsNullOrEmpty(e.Data))
							err += e.Data + Environment.NewLine;
					};
					p.Stdout += delegate(object sender, DataReceivedEventArgs e)
					{
						if (!string.IsNullOrEmpty(e.Data)) ret.Add(e.Data);
					};

					if (string.IsNullOrEmpty(remoteDir))
						p.Start("ls -1");
					else
						p.Start("ls -1 " + remoteDir);

					int ec = p.WaitForEver();
					if (ec != 0)
						throw new PuTTYException(ec, "PuTTYClient.Dir", err);
					return ret.ToArray();
				}
			}
			public static void Execute(string connectionId, string remoteCmd)
			{
				string err = string.Empty;
				using (PlinkProcess p = new PlinkProcess(connectionId))
				{
					p.Stderr += delegate(object sender, DataReceivedEventArgs e)
					{
						if (!string.IsNullOrEmpty(e.Data))
							err += e.Data + Environment.NewLine;
					};

					p.Start(remoteCmd);

					int ec = p.WaitForEver();
					if (ec != 0)
						throw new PuTTYException(ec, "PuTTYClient.Dir", err);
				}
			}
			public static int ExecuteAndReturnExitCode(string connectionId, string remoteCmd)
			{
				string err = string.Empty;
				using (PlinkProcess p = new PlinkProcess(connectionId))
				{
					p.Stderr += delegate(object sender, DataReceivedEventArgs e)
					{
						if (!string.IsNullOrEmpty(e.Data))
							err += e.Data + Environment.NewLine;
					};

					p.Start(remoteCmd);

					int ec = p.WaitForEver();
					return ec;
				}
			}
			public static void Execute(string connectionId, string remoteCmd, int milliSecTimeout)
			{
				string err = string.Empty;
				using (PlinkProcess p = new PlinkProcess(connectionId))
				{
					p.Stderr += delegate(object sender, DataReceivedEventArgs e)
					{
						if (!string.IsNullOrEmpty(e.Data))
							err += e.Data + Environment.NewLine;
					};

					p.Start(remoteCmd);

					int ec;
					bool b = p.WaitTimeout(milliSecTimeout, out ec);
					if (b == false)
					{
						p.Kill();
						throw new PuTTYException(-1, "PuTTYClient.Execute: timeout", "");
					}
					if (ec != 0)
						throw new PuTTYException(ec, "PuTTYClient.Execute", err);
				}
			}
		}

		public static void Dos2Unix(string fileName)
		{
			string destFile = Path.GetTempFileName();
			Dos2Unix(fileName, destFile);

			File.Delete(fileName);
			File.Move(destFile, fileName);
		}
		public static void Dos2Unix(string src, string dst)
		{
			// dos usa <CR><NL>
			// unix usa <NL>

			const byte NL = 10;
			//const byte CR = 13;

			using (StreamReader sr = File.OpenText(src))
			{
				using (FileStream fs = File.Create(dst, 1024 * 64 /*buffer dim*/))
				{
					for (; ; )
					{
						string s = sr.ReadLine();
						if (s == null) break;

						byte[] a = Encoding.UTF8.GetBytes(s);
						fs.Write(a, 0, a.Length);
						fs.WriteByte(NL);
					}
				}
			}
		}
		public static void Unix2Dos(string fileName)
		{
			string destFile = Path.GetTempFileName();
			Unix2Dos(fileName, destFile);

			File.Delete(fileName);
			File.Move(destFile, fileName);
		}
		public static void Unix2Dos(string src, string dst)
		{
			// dos usa <CR><NL>
			// unix usa <NL>

			const byte CR = 13;
			const byte NL = 10;

			using (FileStream r = File.OpenRead(src))
			{
				using (FileStream w = File.Create(dst, 1024 * 64))
				{
					byte[] a = new byte[1024 * 64];
					for (; ; )
					{
						int n = r.Read(a, 0, a.Length);
						if (n <= 0) break;

						for (int i = 0; i < n; ++i)
						{
							if (a[i] == NL)
							{
								w.WriteByte(CR);
								w.WriteByte(NL);
							}
							else
								w.WriteByte(a[i]);
						}
					}
				}
			}
		}

		public static string F(string fmt, params object[] args) { return string.Format(fmt, args); }

		public delegate void F0();
		public delegate void F1<T1>(T1 a1);
		public delegate void F2<T1, T2>(T1 a1, T2 a2);
		public delegate void F3<T1, T2, T3>(T1 a1, T2 a2, T3 a3);
		public delegate void F4<T1, T2, T3, T4>(T1 a1, T2 a2, T3 a3, T4 a4);
		public delegate void F5<T1, T2, T3, T4, T5>(T1 a1, T2 a2, T3 a3, T4 a4, T5 a5);
		public delegate void F6<T1, T2, T3, T4, T5, T6>(T1 a1, T2 a2, T3 a3, T4 a4, T5 a5, T6 a6);

		public static class ThreadPool
		{
			public static void QueueUserWorkItem(F0 f0)
			{
				System.Threading.WaitCallback wc = delegate(object args)
				{
					try { f0(); }
					catch { }
				};

				System.Threading.ThreadPool.QueueUserWorkItem(wc, null);
			}

			public static void QueueUserWorkItem<T1>(F1<T1> f1, T1 a1)
			{
				R2<T1, F1<T1>> arg = new R2<T1, F1<T1>>();
				arg.F1 = a1;
				arg.F2 = f1;

				System.Threading.WaitCallback wc = delegate(object args)
				{
					try { arg.F2(arg.F1); }
					catch { }
				};

				System.Threading.ThreadPool.QueueUserWorkItem(wc, arg);
			}

			public static void QueueUserWorkItem<T1, T2>(F2<T1, T2> f2, T1 a1, T2 a2)
			{
				R3<T1, T2, F2<T1, T2>> arg = new R3<T1, T2, F2<T1, T2>>();
				arg.F1 = a1;
				arg.F2 = a2;
				arg.F3 = f2;

				System.Threading.WaitCallback wc = delegate(object args)
				{
					try { arg.F3(arg.F1, arg.F2); }
					catch { }
				};

				System.Threading.ThreadPool.QueueUserWorkItem(wc, arg);
			}

			public static void QueueUserWorkItem<T1, T2, T3>(F3<T1, T2, T3> f3, T1 a1, T2 a2, T3 a3)
			{
				R4<T1, T2, T3, F3<T1, T2, T3>> arg = new R4<T1, T2, T3, F3<T1, T2, T3>>();
				arg.F1 = a1;
				arg.F2 = a2;
				arg.F3 = a3;
				arg.F4 = f3;

				System.Threading.WaitCallback wc = delegate(object args)
				{
					try { arg.F4(arg.F1, arg.F2, arg.F3); }
					catch { }
				};

				System.Threading.ThreadPool.QueueUserWorkItem(wc, arg);
			}
			public static void QueueUserWorkItem<T1, T2, T3, T4>(F4<T1, T2, T3, T4> f4, T1 a1, T2 a2, T3 a3, T4 a4)
			{
				R5<T1, T2, T3, T4, F4<T1, T2, T3, T4>> arg = new R5<T1, T2, T3, T4, F4<T1, T2, T3, T4>>();
				arg.F1 = a1;
				arg.F2 = a2;
				arg.F3 = a3;
				arg.F4 = a4;
				arg.F5 = f4;

				System.Threading.WaitCallback wc = delegate(object args)
				{
					try { arg.F5(arg.F1, arg.F2, arg.F3, arg.F4); }
					catch { }
				};

				System.Threading.ThreadPool.QueueUserWorkItem(wc, arg);
			}
		}

		public static void GC_Collect()
		{
			try
			{
				GC.Collect();
				//GC.WaitForPendingFinalizers();
				//GC.Collect();
			}
			catch
			{
			}
		}
		public class GC_Collecter : IDisposable
		{
			int _max;
			int _c;

			public GC_Collecter(string cfg)
			{
				_c = 0;
				_max = ReadAppSettings.ToInt32("GC_Collecter." + cfg, 100 * 1024);
			}

			public void Collect()
			{
				if (++_c % _max == 0)
					GC_Collect();
			}

			void IDisposable.Dispose()
			{
				GC_Collect();
			}
		}

		public class DerivedStream : Stream
		{
			protected Stream _s;

			// Read ,Write, CanRead, CanSeek, CanWrite, Flush, Length, Position, Seek, and SetLength

			public DerivedStream(Stream s)
			{
				_s = s;
			}

			public override bool CanRead { get { return _s.CanRead; } }
			public override bool CanSeek { get { return _s.CanSeek; } }
			public override bool CanWrite { get { return _s.CanWrite; } }
			public override long Length { get { return _s.Length; } }
			public override long Position { get { return _s.Position; } set { _s.Position = value; } }

			public override void Flush() { _s.Flush(); }
			public override int Read(byte[] buffer, int offset, int count) { return _s.Read(buffer, offset, count); }
			public override long Seek(long offset, SeekOrigin origin) { return _s.Seek(offset, origin); }
			public override void SetLength(long value) { _s.SetLength(value); }
			public override void Write(byte[] buffer, int offset, int count) { _s.Write(buffer, offset, count); }


			public override void Close()
			{
				this.Dispose(true);
				GC.SuppressFinalize(this);
			}
			protected override void Dispose(bool disposing)
			{
				try
				{
					if (disposing && this._s != null)
					{
						try
						{
							this.Flush();
						}
						finally
						{
							this._s.Close();
						}
					}
				}
				finally
				{
					if (this._s != null)
					{
						this._s = null;
						base.Dispose(disposing);
					}
				}
			}
		}

		/// <summary>
		/// stream per scrivere su di uno stream in formato Unix.
		/// Per utilizzare lo stream basta
		/// using (StreamWriter sw = new StreamWriter(new UnixStream(File.Create("pippo.txt")))
		/// {
		///		sw.WriteLine(....);
		/// }
		/// </summary>
		public class UnixStream : DerivedStream
		{
			public UnixStream(Stream s)
				: this(s, 1024)
			{
			}
			public UnixStream(Stream s, int readBufferSize)
				: base(s)
			{
				_crNLpending = false;
				_rd = new ReadData(readBufferSize);
			}


			public override bool CanSeek { get { return false; } }
			public override bool CanRead { get { return true; } }
			public override bool CanWrite { get { return true; } }

			public override long Length { get { throw new NotImplementedException(); } }
			public override long Position { get { throw new NotImplementedException(); } set { throw new NotImplementedException(); } }
			public override long Seek(long offset, SeekOrigin origin) { throw new NotImplementedException(); }
			public override void SetLength(long value) { throw new NotImplementedException(); }

			const byte CR = 13;
			const byte NL = 10;

			public override void Write(byte[] buffer, int offset, int count)
			{
				// dos usa <CR><NL>
				// unix usa <NL>

				// entrambi gli indici puntano a buffer. Si ha sempre b < c
				int b = 0; // primo da scrivere
				int c = 0; // indice corrente
				while (c < count - 1)
				{
					if (buffer[c] == CR && buffer[c + 1] == NL)
					{
						_s.Write(buffer, b, c - b);
						_s.WriteByte(NL);
						c += 2;
						b = c;
					}
					else
						++c;
				}

				if (b < count)
					_s.Write(buffer, b, count - b);
			}

			struct ReadData
			{
				byte[] buffer;
				int top;
				int read;

				public ReadData(int bufferSize)
				{
					top = 0;
					read = 0;
					buffer = new byte[bufferSize];
				}

				/// <summary>
				/// Lettura un byte alla volta bufferizzata.
				/// La prima volta che si chiama la funzione si ha _rd.read == 0 -> in questo modo 
				/// si fa sempre una lettura _s.Read in quanto anche _rd.top == 0
				/// Alle successive chiamate e` garantito che _rd.read > 0 --> si legge dal buffer
				/// se c'e` qualcosa da leggere altrimenti si procede ad una lettura fisica.
				/// </summary>
				/// <returns>-1 a fine file, altrimenti il byte letto</returns>
				public int ReadByte(Stream s)
				{
					if (top < read)
						return buffer[top++];

					top = 0;
					read = s.Read(buffer, 0, buffer.Length);
					if (read <= 0)
						return -1;

					return buffer[top++];
				}
			}

			ReadData _rd;
			public bool _crNLpending;

			public override int Read(byte[] buffer, int offset, int count)
			{
				int rd = 0;

				if (_crNLpending && rd < count)
				{
					_crNLpending = false;
					buffer[offset++] = NL;
					rd++;
				}

				while (rd < count)
				{
					int bi = _rd.ReadByte(_s);
					if (bi < 0)
						break;
					byte b = (byte)bi;

					if (b != NL)
					{
						buffer[offset++] = b;
						rd++;
					}
					else
					{
						buffer[offset++] = CR;
						rd++;

						if (rd < count)
						{
							buffer[offset++] = NL;
							rd++;
						}
						else
							_crNLpending = true;
					}
				}

				return rd;
			}
		}
	}

	/// <summary>
	/// Classe che contiene la coppia chiave/valore
	/// Il valore puo` essere tipizzato a seconda del DB.
	/// </summary>
	/// <typeparam name="C"></typeparam>
	[Serializable]
	public class KeyDescription<C>
	{
		public KeyDescription() { }
		public KeyDescription(C c, string d) { _code = c; _descr = d; }
		public C Code { get { return _code; } set { _code = value; } }
		public string Description { get { return _descr; } set { _descr = value; } }

		private C _code;
		private string _descr;
	}
}
