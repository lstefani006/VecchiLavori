using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ITRS_BL
{
	public interface PoolThreadWorker<T>
	{
		void StartWorkerOnPoolThread();
		void DoWork(T args);
		void StopWorkerOnPoolThread();
	}

	/// <summary>
	/// Classe che implementa un thread pool abortibile.
	/// Ogni thread esegue un <c>PoolThreadWorker</c> che espone metodi
	/// da eseguire all'entrata del thread, in uscita dal thread e ad ogni comando accodato dai clienti
	/// del pool.
	/// Un comando e` una classe specificata con <code>T</code>.
	/// Il <c>PoolThreadWorker</c> esegue il lavoro chiamando il metodo <c>DoWork</c> e specificando
	/// in <c>args</c> il comando da eseguire.
	/// 
	/// I comandi vengono accodati in una coda gestita dal WorkPool. I vari thread costituenti il pool
	/// sono in listen sulla coda per eseguire il comando.
	/// I comando accodato o in esecuzione puo` essere abortito: l'operazione di abort e` paricolosa 
	/// dal punto di vista della stabilitita` dell'application domain, ma rappresenta comunque l'unico
	/// modo per interrompere un thread (a meno di altri tipi di sincronizzazione).
	/// L'abort di un thread non fa dimuninuire il numero di thread nel thread pool.
	/// Se invece il job e` ancora in coda, l'operazione di abort semplicemente rimuove il job prima
	/// di essere eseguito.
	/// 
	/// Ogni job accodato e` descritto da in <c>WorkItem</c>. Tramite questa classe si puo` monitorare
	/// lo stato del job e ottenere l'AutoresetEvent per bloccarsi sulla terminazione del job.
	/// Un job puo` finire bene, morire per eccezione o per abort.
	/// Nel primo caso assume stato Completed, nel secondo Completed con Exception valorizzato, nel terzo con
	/// Aborted.
	/// </summary>
	/// <typeparam name="T">i parametri da passare al PoolThreadWorker</typeparam>
	/// <typeparam name="PW">il PoolThreadWorker che effettua il lavoro</typeparam>
	public class WorkPool<T, PW> : IDisposable
		where PW : PoolThreadWorker<T>, new()
	{
		public enum WorkItemStatus { Initial, Queued, Executing, Completed, Aborted, UnQueued }

		/// <summary>
		/// Identificatore di un job nel WorkPool
		/// </summary>
		public sealed class WorkItem : IDisposable
		{
			internal WorkItem(T args)
			{
				this._args = args;
				this._Status = WorkItemStatus.Initial;
				this._Queued = null;
				this._Executed = null;
				this._Completed = null;
				this._Aborted = null;
				this._UnQueued = null;

				this._Exception = null;
				this._EventCompleted = new AutoResetEvent(false);
			}
			private T _args;
			volatile private WorkItemStatus _Status;
			private AutoResetEvent _EventCompleted;
			private Exception _Exception;

			private DateTime? _Queued;
			private DateTime? _Executed;
			private DateTime? _Completed;
			private DateTime? _Aborted;
			private DateTime? _UnQueued;

			/// <summary>
			/// Argomenti in ingresso al thread
			/// </summary>
			public T Args { get { return _args; } }

			/// <summary>
			/// Eccezione che eventualmente si e` verificata durante l'esecuzione del job.
			/// </summary>
			public Exception Exception
			{
				get { return _Exception; }
				internal set { _Exception = value; }
			}
			/// <summary>
			/// Evento segnalato quando e` terminata l'esecuzione del job (anche su eccezione)
			/// </summary>
			public AutoResetEvent EventCompleted { get { return _EventCompleted; } }

			/// <summary>
			/// Stato del job
			/// </summary>
			public WorkItemStatus Status
			{
				get { return _Status; }
				set
				{
					if (_Status != value)
					{
						switch (value)
						{
						case WorkItemStatus.Queued:
							_Status = value;
							_Queued = DateTime.Now;
							break;
						case WorkItemStatus.Executing:
							_Status = value;
							_Executed = DateTime.Now;
							break;
						case WorkItemStatus.Aborted:
							_Status = value;
							_Aborted = DateTime.Now;
							_EventCompleted.Set();
							break;
						case WorkItemStatus.Completed:
							_Status = value;
							_Completed = DateTime.Now;
							_EventCompleted.Set();
							break;
						case WorkItemStatus.UnQueued:
							_Status = value;
							_UnQueued = DateTime.Now;
							break;
						}
					}
				}
			}

			/// <summary>
			/// Momento in cui il job e`stato accodato
			/// </summary>
			public DateTime? Queued { get { return _Queued; } }
			/// <summary>
			/// Momento in cui il job e`stato eseguito dal thread
			/// </summary>
			public DateTime? Executed { get { return _Executed; } }
			/// <summary>
			/// Momento in cui il thread ha terminato l'esecuzione del job - anche per eccezione
			/// </summary>
			public DateTime? Completed { get { return _Completed; } }
			/// <summary>
			/// Momento in cui il job e` stato abortito con Cancel
			/// </summary>
			public DateTime? Aborted { get { return _Aborted; } }
			/// <summary>
			/// Momento in cui il job e` stato tolto dalla coda con Cancel
			/// </summary>
			public DateTime? UnQueued { get { return _UnQueued; } }

			void IDisposable.Dispose()
			{
				_EventCompleted.Close();
				IDisposable d = _args as IDisposable;
				if (d != null)
					d.Dispose();
			}
		}

		private readonly LinkedList<WorkItem> _workQueue;
		private readonly Dictionary<WorkItem, Thread> _workThread;
		private Thread[] _thWorker;
		private readonly int _maxQueueLen;    // numero di item massimo nella coda.
		private volatile bool _StopThread;
		private readonly int _threadExitTimeout;
		private volatile bool _bWaitOnQueueFull;

		/// <summary>
		/// Crea un pool di thread per effettuare un job.
		/// Ogni job � abortibile.
		/// </summary>
		/// <param name="nThreads">numero di thread nel thread pool</param>
		/// <param name="qw">istanza di chi eseguir� il job nel thread del thread pool</param>
		/// <param name="threadExitTimeout">timeout per rispondere all'abort da parte dei thread</param>
		/// <param name="maxQueueLen">numero massimo di item in coda. Sopra questo limite i clienti si bloccano.</param>
		/// <param name="bWaitOnQueueFull">specifica se si deve rimanere bloccati o no su coda piena</param>
		public WorkPool(int nThreads, int threadExitTimeout, int maxQueueLen, bool bWaitOnQueueFull)
		{
			_maxQueueLen = maxQueueLen;
			_StopThread = false;
			_workQueue = new LinkedList<WorkItem>();
			_workThread = new Dictionary<WorkItem, Thread>();
			_threadExitTimeout = threadExitTimeout;
			_bWaitOnQueueFull = bWaitOnQueueFull;

			_thWorker = new Thread[nThreads];
			for (int t = 0; t < _thWorker.Length; ++t)
				_thWorker[t] = this.CreateNewThread();
		}

		private Thread CreateNewThread()
		{
			Thread th = new Thread(new ThreadStart(WaitAndDoNextWork));
			th.IsBackground = true;
			th.Start();
			return th;
		}

		void IDisposable.Dispose()
		{
			StopPool();
		}

		public void StopPool()
		{
			if (_thWorker != null)
			{
				lock (this)
				{
					_StopThread = true;
					Monitor.PulseAll(this); // sveglio i thread
				}

				for (int t = 0; t < _thWorker.Length; ++t)
				{
					bool bThredExited = _thWorker[t].Join(_threadExitTimeout);
					if (!bThredExited)
						_thWorker[t].Abort();
					_thWorker[t] = null;
				}
				_thWorker = null;
			}
		}

		public int PendingWorks { get { lock (this) { return _workQueue.Count; } } }
		public int RunningWorks { get { lock (this) { return _workThread.Count; } } }

		/// <summary>
		/// Accoda un job da eseguire.
		/// </summary>
		/// <param name="args">gli argomomenti del job</param>
		/// <returns>la classe per controllare il job. Null se la coda degli eventi e` piena</returns>
		public WorkItem QueueUserWorkItem(T args)
		{
			lock (this)
			{
				// se ci sono troppi elementi in coda aspetto
				while (_workQueue.Count >= _maxQueueLen)
					if (_bWaitOnQueueFull)
						Monitor.Wait(this);
					else
						return null;

				// accodo il batch
				WorkItem wi = new WorkItem(args);
				_workQueue.AddLast(wi);
				wi.Status = WorkItemStatus.Queued;

				// se il batch accodato e` il primo, sveglio i thread che consuma gli eventi
				if (_workQueue.Count == 1)
					Monitor.PulseAll(this);

				return wi;
			}
		}

		/// <summary>
		/// Interrompe un job.
		/// Il Job puo` essere in esecuzione o ancora in coda.
		/// Se e` in esecuzione <c>allowAbort</c> deve essere true per abortire il thread su cui gira.
		/// In questo caso, abortito il thread, il thread pool si occupa di crearne uno nuovo per 
		/// mantenere costanti il numero di thread nel thread pool.
		/// </summary>
		/// <param name="item">job da abortire</param>
		/// <param name="allowAbort">true se si puo` abortire un job in stato Executing</param>
		/// <returns>il nuovo stato acquisito dal job.</returns>
		public WorkItemStatus Cancel(WorkItem item, bool allowAbort)
		{
			if (item == null)
				throw new ArgumentNullException("item");

			lock (this)
			{
				if (_workQueue.Contains(item))
				{
					_workQueue.Remove(item);
					item.Status = WorkItemStatus.UnQueued;

					// se la coda prima era piena sveglio i produttori eventualmente bloccati.
					if (_workQueue.Count + 1 >= _maxQueueLen)
						Monitor.PulseAll(this);
				}
				else if (_workThread.ContainsKey(item))
				{
					if (allowAbort)
					{
						Thread th = _workThread[item];
						th.Abort();
						th.Join(_threadExitTimeout); // qui il timeout serve solo per "sicurezza"
						_workThread.Remove(item);
						// item.Status = WorkItemStatus.Aborted; --> lo setto quando il lavoro � effettivamente abortito

						// ho abortito un thread.
						// Ricreo un altro thread per rimpinguare il tread pool
						for (int t = 0; t < _thWorker.Length; ++t)
							if (_thWorker[t] == th)
							{
								_thWorker[t] = CreateNewThread();
								break;
							}
					}
				}
				return item.Status;
			}
		}

		private void WaitAndDoNextWork()
		{
			PW poolWorker = new PW();
			try
			{
				poolWorker.StartWorkerOnPoolThread();

				DoWorkLoop(poolWorker);
			}
			finally
			{
				poolWorker.StopWorkerOnPoolThread();
			}
		}

		private void DoWorkLoop(PW poolWorker)
		{
			while (!_StopThread)
			{
				WorkItem wi;
				lock (this)
				{
					// se la coda e` vuota aspetta un evento
					while (_workQueue.Count == 0)
					{
						// rilascio il lock e aspetto un Pulse
						Monitor.Wait(this);
						// qui ho ripreso il lock su this.

						// ricontrollo se c'e` qualcosa in coda o se devo uscire
						if (_StopThread)
							return;
					}

					// consumo l'evento in coda
					wi = _workQueue.First.Value;
					wi.Status = WorkItemStatus.Executing;
					_workQueue.RemoveFirst();
					_workThread.Add(wi, Thread.CurrentThread);

					// se la coda era piena sveglio i produttori
					if (_workQueue.Count == _maxQueueLen - 1)
						Monitor.PulseAll(this);
				}

				try
				{
					// faccio il lavoro.
					poolWorker.DoWork(wi.Args);

					wi.Status = WorkItemStatus.Completed;
				}
				catch (ThreadAbortException)
				{
					wi.Status = WorkItemStatus.Aborted;
				}
				catch (Exception ex)
				{
					// la gestione dell'eccezione la deve fare il PoolWorker
					// qui evito solo di "perdere" il thread
					wi.Status = WorkItemStatus.Completed;
					wi.Exception = ex;
				}
				finally
				{
					lock (this)
					{
						if (_workThread.ContainsKey(wi))
							_workThread.Remove(wi);
					}

				}
			}
		}
	}



}
