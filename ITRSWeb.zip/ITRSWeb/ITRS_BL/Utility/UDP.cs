using System;
using System.Collections.Generic;
using System.Text;

using System.Net;
using System.Net.Sockets;

namespace Network
{
	public static class UDP
	{
		public delegate void ReceiveDelegate(object sender, ReceiveEvent ev);
		public delegate void ErrorDelegate(object sender, ErrorEvent ev);

		public class ReceiveEvent : EventArgs
		{
			public ReceiveEvent(IPEndPoint from, byte[] msg)
			{
				this.From = from;
				this.Msg = msg;
				this.Continue = true;
			}
			readonly public IPEndPoint From;
			readonly public byte[] Msg;
			public bool Continue;
		}
		public class ErrorEvent : EventArgs
		{
			public ErrorEvent(Exception ex)
			{
				this.Exception = ex;
				this.Continue = true;
			}
			readonly public Exception Exception;
			public bool Continue;
		}


		public static class Broadcast
		{
			/// <summary>
			/// Manda un pacchetto all'indirizzo broadcast.
			/// </summary>
			/// <param name="addr">e` un indirizzo tipo "192.168.1.255" che indica di inviare 
			/// il pacchetto a tutta la sottorete di tipo C ossia a tutti i PC che hanno come indirizzo 192.168.1.*</param>
			/// <param name="port">la porta a cui mandare il messaggio</param>
			/// <param name="msg">il messagio da inviare</param>
			static void Send(string addr, int port, byte[] msg)
			{
				try
				{
					using (Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
					{
						IPAddress broadcast = IPAddress.Parse(addr);
						IPEndPoint ep = new IPEndPoint(broadcast, port);
						s.SendTo(msg, ep);
					}
				}
				catch
				{
					throw;
				}
			}



			public class Listener
			{
				public event ReceiveDelegate Receive;
				public event ErrorDelegate Error;

				private void StartListen(int listenPort)
				{
					bool Continue = true;

					using (UdpClient listener = new UdpClient(listenPort))
					{
						while (Continue)
						{
							try
							{
								IPEndPoint groupEP = new IPEndPoint(IPAddress.Any, listenPort);
								byte[] msg = listener.Receive(ref groupEP);
								if (Receive != null)
								{
									ReceiveEvent ev = new ReceiveEvent(groupEP, msg);
									Receive(this, ev);
									Continue = ev.Continue;
								}
							}
							catch (Exception ex)
							{
								if (Error != null)
								{
									ErrorEvent ev = new ErrorEvent(ex);
									Error(this, new ErrorEvent(ex));
									Continue = ev.Continue;
								}
							}
						}
					}
				}
			}

		}

		public static class Multicast
		{
			public class Listener
			{
				/// <summary>
				/// Listener multicast UDP.
				/// Il multicast e` una comunicazione tra PC che si dichiarano appartententi
				/// allo stesso gruppo di multicast.
				/// L'indirizzo di multicasto NON ha niente a che fare con l'indirizzo di rete dei PC,
				/// ma e` un indirizzo logico a cui aderiscono i vari soggetti della comunicazione.
				/// </summary>
				/// <param name="groupAddress">l'indirizzo del gruppo di multicast (deve essere tra 224.0.0.2 a 244.255.255.255)</param>
				/// <param name="groupPort">porta del multicast</param>
				public Listener(string groupAddress, int groupPort)
				{
					this._GroupAddress = IPAddress.Parse(groupAddress);
					this._GroupPort = groupPort;
				}

				private readonly IPAddress _GroupAddress;
				private readonly int _GroupPort;
				public event ReceiveDelegate Receive;
				public event ErrorDelegate Error;

				public void Listen()
				{
					bool Continue = true;

					using (UdpClient listener = new UdpClient())
					{
						IPEndPoint groupEP = new IPEndPoint(_GroupAddress, _GroupPort);
						listener.JoinMulticastGroup(_GroupAddress);
						listener.Connect(groupEP);

						while (Continue)
						{
							try
							{
								byte[] msg = listener.Receive(ref groupEP);

								if (Receive != null)
								{
									ReceiveEvent ev = new ReceiveEvent(groupEP, msg);
									Receive(this, ev);
									Continue = ev.Continue;
								}
							}
							catch (Exception ex)
							{
								if (this.Error != null)
								{
									ErrorEvent ev = new ErrorEvent(ex);
									this.Error(this, ev);
									Continue = ev.Continue;
								}
							}
						}

					}
				}
			}


			public static void Send(string groupAddr, int groupPort, byte[] msg)
			{
				using (UdpClient sender = new UdpClient())
				{
					IPAddress gp = IPAddress.Parse(groupAddr);
					IPEndPoint groupEP = new IPEndPoint(gp, groupPort);

					try
					{
						sender.Send(msg, msg.Length, groupEP);
						sender.Close();
					}
					catch
					{
						throw;
					}
				}
			}
		}
	}
}
