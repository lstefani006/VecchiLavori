using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;

#if ODP
using OP = Oracle.DataAccess.Client;
using ODbType = Oracle.DataAccess.Client.OracleDbType;
#else
#endif




namespace OracleFacade
{

	public class OracleConnection : IDisposable
	{
		public OracleConnection() { _cn = new OP.OracleConnection(); }
		public OracleConnection(string connectionString) { _cn = new OP.OracleConnection(connectionString); }

		public void Dispose() { _cn.Dispose(); }
		public string ConnectionString { get { return _cn.ConnectionString; } set { _cn.ConnectionString = value; } }
		public ConnectionState State { get { return _cn.State; } }

		//		public event OracleInfoMessageEventHandler InfoMessage;

		public OracleTransaction BeginTransaction()
		{
			return new OracleTransaction(this, _cn.BeginTransaction());
		}
		public OracleTransaction BeginTransaction(IsolationLevel il)
		{
			return new OracleTransaction(this, _cn.BeginTransaction(il));
		}

		public void Close() { _cn.Close(); }
		public OracleCommand CreateCommand() { return new OracleCommand(this, _cn.CreateCommand()); }

		public void Open() { _cn.Open(); }

		internal OP.OracleConnection InternalConnection { get { return _cn; } }

		private OP.OracleConnection _cn;

	}

	public class OracleTransaction : IDisposable
	{
		internal OracleTransaction(OracleConnection cn, OP.OracleTransaction tr) { _cn = cn; _tr = tr; }

		public OracleConnection Connection { get { return _cn; } }
		public IsolationLevel IsolationLevel { get { return _tr.IsolationLevel; } }

		public void Commit() { _tr.Commit(); }
		public void Rollback() { _tr.Rollback(); }

		public void Dispose() { _tr.Dispose(); }

		internal OP.OracleTransaction InternalTransaction { get { return _tr; } }

		private OracleConnection _cn;
		private OP.OracleTransaction _tr;
	}

	public class OracleCommand : IDisposable
	{
		internal OracleCommand(OracleConnection cn, OP.OracleCommand cmd)
		{
			_cn = cn;
			_cmd = cmd;
			_tr = null;
		}

		public OracleCommand() { _cmd = new OP.OracleCommand(); }
		public OracleCommand(string commandText) { _cmd = new OP.OracleCommand(commandText); }
		public OracleCommand(string commandText, OracleConnection connection)
		{
			_cmd = new OP.OracleCommand(commandText, connection.InternalConnection);
			_cn = connection;
		}
		// non esiste con questi parametri in oracle
		//public OracleCommand(string commandText, OracleConnection connection, OracleTransaction tr)
		//{
		//    _cmd = new OP.OracleCommand(commandText, connection.InternalConnection, tr.InternalTransaction);
		//    _cn = connection;
		//    _tr = tr;
		//}

		public void Dispose() { _cmd.Dispose(); }

		public string CommandText { get { return _cmd.CommandText; } set { _cmd.CommandText = value; } }
		public int CommandTimeout { get { return _cmd.CommandTimeout; } set { _cmd.CommandTimeout = value; } }
		public CommandType CommandType { get { return _cmd.CommandType; } set { _cmd.CommandType = value; } }
		public OracleConnection Connection
		{
			get { return _cn; }
			set { _cn = value; _cmd.Connection = _cn.InternalConnection; }
		}
		public OracleTransaction Transaction
		{
			get { return _tr; }
			// non c'e` in oracle
			//set { _tr = value; _cmd.Transaction = value.InternalTransaction; }
		}

		public OracleParameterCollection Parameters
		{
			get
			{
				if (_pc == null)
					_pc = new OracleParameterCollection(_cmd.Parameters);
				return _pc;
			}
		}

		

		// public override UpdateRowSource UpdatedRowSource { get; set; }
		public void Cancel() { _cmd.Cancel(); }
		public OracleParameter CreateParameter() { return new OracleParameter(_cmd.CreateParameter()); }
		public int ExecuteNonQuery() { return _cmd.ExecuteNonQuery(); }
		public OracleDataReader ExecuteReader() { return new OracleDataReader(_cmd.ExecuteReader()); }
		public OracleDataReader ExecuteReader(CommandBehavior behavior) { return new OracleDataReader(_cmd.ExecuteReader(behavior)); }
		public object ExecuteScalar() { return _cmd.ExecuteScalar(); }
		public void Prepare() { _cmd.Prepare(); }
		//public void ResetCommandTimeout() { _cmd.ResetCommandTimeout(); }


		private OracleConnection _cn;
		private OP.OracleCommand _cmd;
		private OracleTransaction _tr;
		private OracleParameterCollection _pc;
	}

	public class OracleParameter
	{
		internal OracleParameter(OP.OracleParameter p) { _p = p; }
		internal OP.OracleParameter InternalParameter
		{
			get { return _p; }
		}

		public OracleParameter() { _p = new OP.OracleParameter(); }
		public OracleParameter(string name, object value) { _p = new OP.OracleParameter(name, value); }
		public OracleParameter(string name, OracleType oracleType)
		{
			_p = new OP.OracleParameter(name, Translate(oracleType));
		}
		public OracleParameter(string name, OracleType oracleType, int size)
		{ _p = new OP.OracleParameter(name, Translate(oracleType), size); }
		public OracleParameter(string name, OracleType oracleType, int size, string srcColumn)
		{
			_p = new OP.OracleParameter(name, Translate(oracleType), size, srcColumn);
		}
		//Non c'e` in oracle
		//public OracleParameter(string name, OracleType oracleType, int size, ParameterDirection direction, string sourceColumn, DataRowVersion sourceVersion, bool sourceColumnNullMapping, object value)
		//{
		//    _p = new OP.OracleParameter(name, Translate(oracleType), size, direction, sourceColumn, sourceVersion, sourceColumnNullMapping, value);
		//}
		public OracleParameter(string name, OracleType oracleType, int size, ParameterDirection direction, bool isNullable, byte precision, byte scale, string srcColumn, DataRowVersion srcVersion, object value)
		{
			_p = new OP.OracleParameter(name, Translate(oracleType), size, direction, isNullable, precision, scale, srcColumn, srcVersion, value);
		}

		public ParameterDirection Direction { get { return _p.Direction; } set { _p.Direction = value; } }
		public bool IsNullable { get { return _p.IsNullable; } set { _p.IsNullable = value; } }
		public string ParameterName { get { return _p.ParameterName; } set { _p.ParameterName = value; } }
		public int Size { get { return _p.Size; } set { _p.Size = value; } }
		public string SourceColumn { get { return _p.SourceColumn; } set { _p.SourceColumn = value; } }
		public DataRowVersion SourceVersion { get { return _p.SourceVersion; } set { _p.SourceVersion = value; } }
		public object Value { get { return _p.Value; } set { _p.Value = value; } }

		internal static ODbType Translate(OracleType ty)
		{
			string s = ty.ToString();
			return (ODbType)Enum.Parse(typeof(ODbType), s);
		}


		private OP.OracleParameter _p;
	}
	public class OracleParameterCollection
	{
		internal OracleParameterCollection(OP.OracleParameterCollection pc) { _pc = pc; }

		public OracleParameter this[int index]
		{
			get { return new OracleParameter(_pc[index]); }
			set { _pc[index] = value.InternalParameter; }
		}
		public OracleParameter this[string parameterName]
		{
			get { return new OracleParameter(_pc[parameterName]); }
			set { _pc[parameterName] = value.InternalParameter; }
		}
		public int Add(object value)
		{
			return _pc.Add(value);
		}
		public OracleParameter Add(OracleParameter value)
		{
			return new OracleParameter(_pc.Add(value.InternalParameter));
		}
		public OracleParameter Add(string parameterName, OracleType dataType)
		{
			return new OracleParameter(_pc.Add(parameterName, Translate(dataType)));
		}
		public OracleParameter Add(string parameterName, OracleType dataType, int size)
		{
			return new OracleParameter(_pc.Add(parameterName, Translate(dataType), size));
		}
		public OracleParameter Add(string parameterName, OracleType dataType, int size, string srcColumn)
		{
			return new OracleParameter(_pc.Add(parameterName, Translate(dataType), size, srcColumn));
		}
		public OracleParameter AddWithValue(string parameterName, object value)
		{
#if ODP
			return new OracleParameter(_pc.Add(parameterName, value));
#else
			return new OracleParameter(_pc.AddWithValue(parameterName, value));
#endif
		}
		public void Clear()
		{
			_pc.Clear();
		}

		OP.OracleParameterCollection _pc;

		internal static ODbType Translate(OracleType ty)
		{
			string s = ty.ToString();
			return (ODbType)Enum.Parse(typeof(ODbType), s);
		}
	}

	public class OracleDataReader : IDisposable
	{
		internal OracleDataReader(OP.OracleDataReader dr) { _dr = dr; }

		public void Dispose() { _dr.Dispose(); }

		public int Depth { get { return _dr.Depth; } }
		public int FieldCount { get { return _dr.FieldCount; } }
		public bool HasRows { get { return _dr.HasRows; } }
		public bool IsClosed { get { return _dr.IsClosed; } }
		public int RecordsAffected { get { return _dr.RecordsAffected; } }

		public object this[int i] { get { return _dr[i]; } }
		public object this[string name] { get { return _dr[name]; } }

		public void Close() { _dr.Close(); }
		public bool GetBoolean(int i) { return _dr.GetBoolean(i); }
		public byte GetByte(int i) { return _dr.GetByte(i); }
		public long GetBytes(int i, long fieldOffset, byte[] buffer2, int bufferoffset, int length)
		{
			return _dr.GetBytes(i, fieldOffset, buffer2, bufferoffset, length);
		}
		public char GetChar(int i) { return _dr.GetChar(i); }
		public long GetChars(int i, long fieldOffset, char[] buffer2, int bufferoffset, int length)
		{
			return _dr.GetChars(i, fieldOffset, buffer2, bufferoffset, length);
		}
		public string GetDataTypeName(int i) { return _dr.GetDataTypeName(i); }
		public DateTime GetDateTime(int i) { return _dr.GetDateTime(i); }
		public decimal GetDecimal(int i) { return _dr.GetDecimal(i); }
		public double GetDouble(int i) { return _dr.GetDouble(i); }
		public Type GetFieldType(int i) { return _dr.GetFieldType(i); }
		public float GetFloat(int i) { return _dr.GetFloat(i); }
		public Guid GetGuid(int i) { return _dr.GetGuid(i); }
		public short GetInt16(int i) { return _dr.GetInt16(i); }
		public int GetInt32(int i) { return _dr.GetInt32(i); }
		public long GetInt64(int i) { return _dr.GetInt64(i); }
		public string GetName(int i) { return _dr.GetName(i); }
		public int GetOrdinal(string name) { return _dr.GetOrdinal(name); }
		public string GetString(int i) { return _dr.GetString(i); }
		public TimeSpan GetTimeSpan(int i) { return _dr.GetTimeSpan(i); }
		public object GetValue(int i) { return _dr.GetValue(i); }
		public bool IsDBNull(int i) { return _dr.IsDBNull(i); }
		public bool NextResult() { return _dr.NextResult(); }
		public bool Read() { return _dr.Read(); }


		private OP.OracleDataReader _dr;
	}

	// mio - compatibile microsoft
	public enum OracleType
	{
		BFile = 1,
		Blob = 2,
		Char = 3,
		Clob = 4,
		Cursor = 5,
		DateTime = 6,
		IntervalDayToSecond = 7,
		IntervalYearToMonth = 8,
		LongRaw = 9,
		LongVarChar = 10,
		NChar = 11,
		NClob = 12,
		Number = 13,
		NVarChar = 14,
		Raw = 15,
		RowId = 16,
		Timestamp = 18,
		TimestampLocal = 19,
		TimestampWithTZ = 20,
		VarChar = 22,
		Byte = 23,
		UInt16 = 24,
		UInt32 = 25,
		SByte = 26,
		Int16 = 27,
		Int32 = 28,
		Float = 29,
		Double = 30,
	}


}
