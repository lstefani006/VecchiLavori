using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Xml;
using System.Threading;
using ITRS_BL.IDal;

using ZipLib = ICSharpCode.SharpZipLib;
//using ICSharpCode.SharpZipLib.Checksums;
//using ICSharpCode.SharpZipLib.Zip;

namespace ITRS_BL
{
	[DataObject]
	public class BLLTS : Component
	{
		#region Costruttori
		public BLLTS()
		{
			InitializeComponent();
		}

		public BLLTS(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
				components.Dispose();
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		int _c = -1;
		int _startRowIndex = 0;
		int _maximumRows = 0;

		public List<LTSRecord> GetLTS(string sortColumns, int startRowIndex, int maximumRows,
			string targa, string nazionalita,
			string tipoLTS,
			DateTime? ricercaInizioDal, DateTime? ricercaInizioAl,
			DateTime? ricercaFineDal, DateTime? ricercaFineAl,
			string IdUtenteRichiedente, int? IdCoa,
			DateTime? ricercaInseritoDal, DateTime? ricercaInseritoAl,
			string ricercaEmail, int? idCoaPerTipoC,
			string IdUtenteCollegato, int? IdCoaDiCompetenzaUtenteCollegato)
		{
			try
			{
				_startRowIndex = startRowIndex;
				_maximumRows = maximumRows;

				maximumRows += 1;

				IDalLTS dal = DalProvider.DAL.CreateDalLTS();
				List<LTSRecord> r = dal.GetLTSList(sortColumns, startRowIndex, maximumRows,
					targa, nazionalita, tipoLTS,
					ricercaInizioDal, ricercaInizioAl,
					ricercaFineDal, ricercaFineAl,
					IdUtenteRichiedente, IdCoa,
					ricercaInseritoDal, ricercaInseritoAl,
					ricercaEmail, idCoaPerTipoC,
					IdUtenteCollegato, IdCoaDiCompetenzaUtenteCollegato);

				if (r.Count == _maximumRows + 1)
				{
					// una in piu` a destra --> esiste la pagina successiva
					_c = _startRowIndex + _maximumRows + 1;
					r.RemoveAt(r.Count - 1);
				}
				else
				{
					// non esiste la pagina a destra
					_c = _startRowIndex + r.Count;
				}

				return r;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLLTS.GetLTS");
				throw;
			}
		}

		public int GetLTSCount(string targa, string nazionalita, string tipoLTS,
			DateTime? ricercaInizioDal, DateTime? ricercaInizioAl,
			DateTime? ricercaFineDal, DateTime? ricercaFineAl,
			string IdUtenteRichiedente, int? IdCoa,
			DateTime? ricercaInseritoDal, DateTime? ricercaInseritoAl,
			string ricercaEmail,
			int? idCoaPerTipoC,
			string IdUtenteCollegato, int? IdCoaDiCompetenzaUtenteCollegato)
		{
			return _c;
			//try
			//{
			//    IDalLTS dal = DalProvider.DAL.CreateDalLTS();
			//    return dal.GetLTSListCount(targa, nazionalita, tipoLTS,
			//        ricercaInizioDal, ricercaInizioAl,
			//        ricercaFineDal, ricercaFineAl,
			//        IdUtenteRichiedente, IdCoa,
			//        ricercaInseritoDal, ricercaInseritoAl,
			//        ricercaEmail, idCoaPerTipoC,
			//        IdUtenteCollegato, IdCoaDiCompetenzaUtenteCollegato);
			//}
			//catch (Exception ex)
			//{
			//    Log.Write(ex, "BLLTS.GetLTSCount");
			//    throw;
			//}
		}

		public LTSRecord GetLTSFromKey(string targa, string nazionalita, long idLts)
		{
			try
			{
				IDalLTS dal = DalProvider.DAL.CreateDalLTS();
				return dal.GetLTSFromKey(targa, nazionalita, idLts);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLLTS.GetLTSFromKey");
				throw;
			}
		}

		private List<string> GetQmgrNameList()
		{
			List<string> QmgrNameList = new List<string>();
			IDalLTS dal = DalProvider.DAL.CreateDalLTS();
			List<MWPC2PInfo> c2p = dal.GetListC2P();
			foreach (MWPC2PInfo ci in c2p)
				QmgrNameList.Add(ci.QmgrName);
			return QmgrNameList;
		}

		public bool InsertLTS(BLLTS.LTSRecord rec)
		{
			try
			{
				IDalLTS dal = DalProvider.DAL.CreateDalLTS();
				bool ok = dal.Insert(rec);
				if (!ok)
				{
					// chiave duplicata ... e` possibile dato che inserisce da interfaccia
					return false;
				}

				DateTime validoDal = DateTime.Now;
				Debug.Assert(validoDal >= rec.DataOraInizioValidita);


				// trovo la lista dei C2P a cui notificare questo evento sulla LTS
				List<string> c2pList = this.GetQmgrNameList();

				if (rec.EnumTipoLTS != "A2")
				{
					bool ignoraA2 = true;
					// trovo la massima data di fine validita per questa targa/nazionalita
					// tra tutti i record in validita` nell'istante validoDal (ossia ORA).
					DateTime? maxDataFineValidita = dal.GetMaxDataFineValidita(rec.Targa, rec.Nazionalita, validoDal, ignoraA2);
					MWPServices.MWPInterface mwp = new ITRS_BL.MWPServices.MWPInterface();

					if (maxDataFineValidita == null)
					{
						// non dovrebbe mai accadere dato che ho appena inserito.
					}
					else if (maxDataFineValidita.Value == rec.DataOraFineValidita)
					{
						// il record appena inserito e` quello con dataFineValidita maggiore!!!
						// devo notificare ai C2P targa/naz/dataFineValidita.
						mwp.ManageAllarmeConDataInizioDataFine(rec.Targa, rec.Nazionalita,
							rec.DataOraInizioValidita, rec.DataOraFineValidita, c2pList, true, 1000);
					}
					else if (maxDataFineValidita.Value < rec.DataOraFineValidita)
					{
						// non dovrebbe mai accadere dato che ho appena inserito
					}
					else
					{
						// maxDataFineValidita > della data appena inserita.
						// Questa condizione e` normale - esiste un'altra entry della stessa targa 
						// ma con data di fine validita maggiore di quella inserita.

						// Non devo notificare niente
					}
				}

				return true;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLLTS.Insert");
				throw;
			}
		}

		public void UpdateLTS(BLLTS.LTSRecord rec)
		{
			try
			{
				IDalLTS dal = DalProvider.DAL.CreateDalLTS();
				dal.Update(rec);


				DateTime validoDal = DateTime.Now;
				Debug.Assert(validoDal >= rec.DataOraInizioValidita);

				if (rec.EnumTipoLTS != "A2")
				{
					bool ignoraA2 = true;
					DateTime? maxDataFineValidita = dal.GetMaxDataFineValidita(rec.Targa, rec.Nazionalita, validoDal, ignoraA2);

					List<string> c2pList = this.GetQmgrNameList();

					MWPServices.MWPInterface mwp = new ITRS_BL.MWPServices.MWPInterface();

					if (maxDataFineValidita == null)
					{
						// non dovrebbe mai accadere dato che ho appena updatato.
					}
					else if (maxDataFineValidita.Value == rec.DataOraFineValidita)
					{
						// il record appena updatato e` quello con dataFineValidita maggiore!!!
						// devo notificare ai C2P targa/naz/dataFineValidita.
						mwp.ManageAllarmeConDataInizioDataFine(rec.Targa, rec.Nazionalita,
							rec.DataOraInizioValidita, rec.DataOraFineValidita, c2pList, true, 1000);
					}
					else if (maxDataFineValidita.Value < rec.DataOraFineValidita)
					{
						// non dovrebbe mai accadere dato che ho appena updatato
					}
					else
					{
						// maxDataFineValidita > della data appena inserita.
						// Non devo notificare niente
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLLTS.Update");
				throw;
			}
		}

		public void DeleteLTS(BLLTS.LTSRecord rec)
		{
			try
			{
				IDalLTS dal = DalProvider.DAL.CreateDalLTS();
				dal.Delete(rec);


				// cerco la massima data di fine validita per questa targa/naz.
				// Se non esiste alcun record devo notificare ai C2P la cancellazione.
				// Se e` < di quella cancellata devo notificare ai C2P lo sponstamente all'indietro della data di fine validita.
				// Se e` > non devo noficare niente in quanto i C2P hanno gia` questa data di fine validita.

				List<string> c2pList = this.GetQmgrNameList();

				DateTime validoDal = DateTime.Now;

				if (rec.EnumTipoLTS != "A2")
				{
					bool ignoraA2 = true;

					MWPServices.MWPInterface mwp = new ITRS_BL.MWPServices.MWPInterface();

					DateTime? maxDataFineValidita = dal.GetMaxDataFineValidita(rec.Targa, rec.Nazionalita, validoDal, ignoraA2);
					if (maxDataFineValidita == null)
					{
						// la targa in questione era l'ultima targa in LTS: notifico la cancellazione.
						mwp.ManageAllarmeConDataInizioDataFine(rec.Targa, rec.Nazionalita,
							rec.DataOraInizioValidita, rec.DataOraFineValidita, c2pList, false, 1000);
					}
					else if (maxDataFineValidita.Value < rec.DataOraFineValidita)
					{
						// esiste un'altra entry con "maxDataFineValidita" minore di quella appena cancellata
						// questa diviene la dataDiFineValidita da aggiornare ai C2P
						mwp.ManageAllarmeConDataInizioDataFine(rec.Targa, rec.Nazionalita,
							DateTime.Now, maxDataFineValidita.Value, c2pList, true, 1000);
					}
					else if (maxDataFineValidita.Value == rec.DataOraFineValidita)
					{
						// esiste un'altra entry con "maxDataFineValidita" UGUALE a quella appena cancellata
						// E` una condizione che si puo` verificare quando la stessa targa/naz e` presente
						// due volte nella LTS con la stessa data di fine validita.

						// Non serve inoltrare alcun messaggio.
					}
					else
					{
						// esiste un'altra entry con "maxDataFineValidita" MAGGIORE di quella appena cancellata
						// Non serve inoltrare alcun messaggio.
					}
				}

			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLLTS.Delete");
				throw;
			}
		}


		public List<UtenteRichiedente> GetListaUtentiRichiedenti()
		{
			try
			{
				IDalLTS dal = DalProvider.DAL.CreateDalLTS();
				return dal.GetListaUtentiRichiedenti();
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLLTS.GetListaUtentiRichiedenti");
				throw;
			}
		}


		public string GeneraFileLTS_C_ForExport(int IdCoa, DateTime validoAl)
		{
			StringWriter sw = new StringWriter(System.Globalization.CultureInfo.InvariantCulture);
			try
			{
				IDalLTS dal = DalProvider.DAL.CreateDalLTS();
				List<LTSRecord> lst = dal.GetLTSForExportTipoC(IdCoa, validoAl);

				foreach (LTSRecord r in lst)
				{
					sw.Write("1 {0}", r.Targa); // si simula un inserimento... questo e` un file in uscita
					sw.Write(" {0}", r.Nazionalita);
					sw.Write(" {0:dd}/{0:MM}/{0:yyyy}", r.DataOraFineValidita);
					sw.Write(" {0:dd}/{0:MM}/{0:yyyy}", r.DataOraInserimento);
					sw.Write(" {0}", r.Note);
					sw.WriteLine();
				}

				sw.Flush();
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLLTS.GeneraFileLTSForExport");
				throw;
			}

			return sw.GetStringBuilder().ToString();
		}


		public class FileLTSRecord
		{
			public string operazione;
			public string targa;
			public string nazionalita;
			public DateTime scadenza;
			public DateTime data_segnalazione;
			public string note;
		}

		private void LeggiFileLTS(string fileContent, out List<string> errorList, out List<FileLTSRecord> recordList)
		{
			StringReader sr = new StringReader(fileContent);

			errorList = new List<string>();
			recordList = new List<FileLTSRecord>();

			int nLine = 0;
			for (; ; )
			{
				string ss = sr.ReadLine();
				if (ss == null) break;
				ss = ss.Trim();
				if (ss.Length == 0) continue;
				nLine++;


				string operazione;
				if (true)
				{
					operazione = IsolaCampo(ref ss);
					if (operazione.Length == 0)
					{
						errorList.Add(string.Format("Riga {0}: il primo carattere di ogni riga deve essere '0' oppure '1'", nLine));
						continue;
					}
					if (!(operazione == "0" || operazione == "1"))
					{
						errorList.Add(string.Format("Riga {0}: il primo carattere di ogni riga deve essere '0' oppure '1'", nLine));
						continue;
					}
				}

				// 1 <targa> <nazione> <scadenza> <data seg> <nota>
				// 0 <targa> <nazione>

				// targa
				string targa;
				if (true)
				{
					targa = IsolaCampo(ref ss).ToUpper();

					if (targa.Length == 0)
					{
						errorList.Add(string.Format("Riga {0}: campo targa non presente", nLine));
						continue;
					}
					if (targa.Length > 10)
					{
						errorList.Add(string.Format("Riga {0}: campo targa troppo lungo", nLine));
						continue;
					}
					if (targa.Length <= 3)
					{
						errorList.Add(string.Format("Riga {0}: campo targa troppo corto", nLine));
						continue;
					}
					if (CheckAZ09(targa, true) == false)
					{
						errorList.Add(string.Format("Riga {0}: il campo targa contiene caratteri non validi", nLine));
						continue;
					}
				}

				string nazionalita;
				if (true)
				{
					nazionalita = IsolaCampo(ref ss).ToUpper();

					if (nazionalita.Length == 0)
					{
						errorList.Add(string.Format("Riga {0}: campo nazione non presente", nLine));
						continue;
					}
					if (nazionalita.Length > 3)
					{
						errorList.Add(string.Format("Riga {0}: campo nazione troppo lungo", nLine));
						continue;
					}
					if (CheckAZ09(nazionalita, false) == false)
					{
						errorList.Add(string.Format("Riga {0}: campo nazione contiene caratteri non validi", nLine));
						continue;
					}
				}

				DateTime scadenza = new DateTime();
				if (operazione == "1")
				{
					string strScadenza = IsolaCampo(ref ss);

					bool ok = CheckDate(strScadenza, nLine, "scadenza", out scadenza, errorList);
					if (!ok) continue;
				}

				DateTime dataSegnalazione = new DateTime();
				if (operazione == "1")
				{
					string strSegnalazione = IsolaCampo(ref ss);

					bool ok = CheckDate(strSegnalazione, nLine, "data di segnalazione", out dataSegnalazione, errorList);
					if (!ok) continue;
				}

				string note = "";
				if (operazione == "1")
					note = ss;


				// se sono arrivato qui ho letto correttamente la riga.

				FileLTSRecord rec = new FileLTSRecord();
				rec.operazione = operazione;
				rec.targa = targa;
				rec.nazionalita = nazionalita;
				rec.scadenza = scadenza;
				rec.data_segnalazione = dataSegnalazione;
				rec.note = note;

				recordList.Add(rec);
			}
		}

		static bool CheckAZ09(string ss, bool permettiNumeri)
		{
			foreach (char c in ss)
			{
				if (c >= 'A' && c <= 'Z') continue;
				if (permettiNumeri && c >= '0' && c <= '9') continue;
				return false;
			}
			return true;
		}

		static string IsolaCampo(ref string ss)
		{
			char[] ws = new char[] { ' ', '\t' };

			int idx = ss.IndexOfAny(ws);
			if (idx < 0)
			{
				string ret = ss;
				ss = "";
				return ret;
			}
			else
			{
				string ret = ss.Substring(0, idx);

				// faccio avanzare il rimanente della stringa
				// togliendo gli eventuali caratteri bianchi
				ss = ss.Substring(idx + 1);
				ss = ss.TrimStart(ws);

				return ret;
			}
		}

		static bool CheckDate(string ss, int nLine, string nomeCampo, out DateTime dt, List<string> errorList)
		{
			dt = new DateTime();
			if (ss.Length > 10)
			{
				errorList.Add(string.Format("Riga {0}: campo {1} troppo lungo", nLine, nomeCampo));
				return false;
			}
			if (ss.Length < 10)
			{
				errorList.Add(string.Format("Riga {0}: campo {1} troppo corto", nLine, nomeCampo));
				return false;
			}

			if (ss[2] != '/' || ss[5] != '/')
			{
				errorList.Add(string.Format("Riga {0}: campo {1} non nel formato gg/mm/aaaa", nLine, nomeCampo));
				return false;
			}

			try
			{
				int gg = Int32.Parse(ss.Substring(0, 2));
				int mm = Int32.Parse(ss.Substring(3, 2));
				int aaaa = Int32.Parse(ss.Substring(6, 4));
				dt = new DateTime(aaaa, mm, gg);
			}
			catch
			{
				errorList.Add(string.Format("Riga {0}: campo {1} non nel formato gg/mm/aaaa", nLine, nomeCampo));
				return false;
			}

			return true;
		}

		public List<string> Import_LTS_C(string IdUtenteRichiedente, int IdCoa, string contenutoFile)
		{
			List<string> errorList;
			List<FileLTSRecord> recordList;
			LeggiFileLTS(contenutoFile, out errorList, out recordList);

			if (errorList.Count > 0)
				return errorList;

			try
			{
				IDalLTS dal = DalProvider.DAL.CreateDalLTS();

				foreach (FileLTSRecord recFile in recordList)
				{
					LTSRecord recDB = dal.GetLTSDiTipoC(recFile.targa, recFile.nazionalita, IdCoa);

					if (recFile.operazione == "0")
					{
						// cancellazione
						if (recDB != null)
						{
							this.DeleteLTS(recDB);
						}
						else
						{
							// non c'e` niente di cancellare
						}
					}
					else
					{
						// inserimento/update

						if (recFile.scadenza < DateTime.Now)
						{
							// non inserisco nel DB record scaduti!
							continue;
						}

						if (recDB == null)
						{
							recDB = new LTSRecord();

							recDB.Targa = recFile.targa;
							recDB.Nazionalita = recFile.nazionalita;
							recDB.EnumTipoLTS = "C";
							recDB.AddrDest = IdCoa.ToString();
							recDB.EnumTipoDest = "COA";
							recDB.DataOraInserimento = DateTime.Now;
							recDB.DataOraFineValidita = recFile.scadenza;

							if (recFile.data_segnalazione < DateTime.Now)
								recDB.DataOraInizioValidita = recFile.data_segnalazione;
							else
								recDB.DataOraInizioValidita = DateTime.Now;

							recDB.EnumLivelloPriorita = "MAX";
							recDB.IdUtenteRichiedente = IdUtenteRichiedente;
							recDB.Note = recFile.note;
							recDB.Motivo = "";

							this.InsertLTS(recDB);
						}
						else
						{
							recDB.Note = recFile.note;
							recDB.DataOraFineValidita = recFile.scadenza;

							if (recFile.data_segnalazione < DateTime.Now)
								recDB.DataOraInizioValidita = recFile.data_segnalazione;
							else
								recDB.DataOraInizioValidita = DateTime.Now;

							recDB.IdUtenteRichiedente = IdUtenteRichiedente;

							this.UpdateLTS(recDB);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLLTS.ImportaFileLTS");
				throw;
			}

			return errorList; // e` vuota --> nessun errore
		}


		[Serializable]
		public class LTSRecord
		{
			public String Targa { get { return _TARGA; } set { _TARGA = value; } }
			public String Nazionalita { get { return _NAZIONALITA; } set { _NAZIONALITA = value; } }
			public Int64 IdLTS { get { return _IDLTS; } set { _IDLTS = value; } }
			public String EnumTipoLTS { get { return _ENUMTIPOLTS; } set { _ENUMTIPOLTS = value; } }
			public String IdUtenteRichiedente { get { return _IDUTENTERICHIEDENTE; } set { _IDUTENTERICHIEDENTE = value; } }
			public string UserNameRichiedente { get { return _UserNameRichiedente; } set { _UserNameRichiedente = value; } }
			public String Motivo { get { return _MOTIVO; } set { _MOTIVO = value; } }
			public String Note { get { return _NOTE; } set { _NOTE = value; } }
			public DateTime DataOraInserimento { get { return _DATAORAINSERIMENTO; } set { _DATAORAINSERIMENTO = value; } }
			public DateTime DataOraInizioValidita { get { return _DATAORAINIZIOVALIDITA; } set { _DATAORAINIZIOVALIDITA = value; } }
			public DateTime DataOraFineValidita { get { return _DATAORAFINEVALIDITA; } set { _DATAORAFINEVALIDITA = value; } }
			public String EnumTipoDest { get { return _ENUMTIPODEST; } set { _ENUMTIPODEST = value; } }
			public String AddrDest { get { return _ADDRDEST; } set { _ADDRDEST = value; } }
			public String EnumLivelloPriorita { get { return _ENUMLIVELLOPRIORITA; } set { _ENUMLIVELLOPRIORITA = value; } }
			public int ProgressivoQuery { get { return _ProgressivoQuery; } set { _ProgressivoQuery = value; } }

			#region dati
			protected String _TARGA;
			protected String _NAZIONALITA;
			protected Int64 _IDLTS;
			protected String _ENUMTIPOLTS;
			protected String _IDUTENTERICHIEDENTE;
			protected String _MOTIVO;
			protected String _NOTE;
			protected DateTime _DATAORAINSERIMENTO;
			protected DateTime _DATAORAINIZIOVALIDITA;
			protected DateTime _DATAORAFINEVALIDITA;
			protected String _ENUMTIPODEST;
			protected String _ADDRDEST;
			protected String _ENUMLIVELLOPRIORITA;
			protected string _UserNameRichiedente;
			protected int _ProgressivoQuery;
			#endregion
		}

		/// <summary>
		/// Classe utilizzata per ottenere la lista degli utenti richiedenti
		/// assieme a "operatori di [Coa]" che indica qualunque operatore di un COA.
		/// Il tipo di chiave viene determinato mettendo un 
		/// "A" per tutti gli utenti
		/// "C" prima dell'IdCoa, 
		/// "U" per un utente specifico
		/// 
		/// IdCoa e IdUtenteRichiedente ritornano NULL per "A"
		/// IdCoa valorizzato e IdUtenteRichiedente NULL per "C"
		/// IdCoa NULL e IdUtenteRichiedente valorizzato per "U"
		/// </summary>
		[Serializable]
		public class UtenteRichiedente
		{
			private string _userName;
			private string _chiave;
			private int _Num;

			public string UserName { get { return _userName; } set { _userName = value; } }
			public string Chiave { set { _chiave = value; } get { return _chiave; } }
			public int Num { set { _Num = value; } get { return _Num; } }

			private bool IsCoa { get { return _chiave.StartsWith("C"); } }
			private bool IsUtenteRichiedente { get { return _chiave.StartsWith("U"); } }

			public int? IdCoa { get { if (this.IsCoa) return int.Parse(_chiave.Substring(1)); else return null; } }
			public string IdUtenteRichiedente { get { if (this.IsUtenteRichiedente) return _chiave.Substring(1); else return null; } }
		}

		/// <summary>
		/// Server per 1) cancellare le entry scadute nella lista LTS
		/// 2) per cancellare le righe della tabella USERLOG - attivita` utente.
		/// </summary>
		public static void StartServer()
		{
			BLLTS bl = new BLLTS();

			Thread th = new Thread(bl.CancellaEntryScaduteNellaLTSObject);
			th.IsBackground = true;
			th.Start();
		}
		public static void StopServer()
		{
		}

		private void CancellaEntryScaduteNellaLTSObject(object dummy)
		{
			string[] hhmm = ReadAppSettings.ToString("CancellazioneLTS", "3:30").Split(':', '.');
			TimeSpan tsRun = new TimeSpan(int.Parse(hhmm[0]), int.Parse(hhmm[1]), 0);

			DateTime dtLast = DateTime.Now;
			for (; ; )
			{
				Thread.Sleep(1000 * 30); // 30 secondi

				DateTime dtNow = DateTime.Now;

				if (dtNow <= dtLast) continue; // ora legale o cose simili

				// data/ora in cui lanciare il comando
				DateTime dtRun = DateTime.Now.Date.Add(tsRun);

				// se la data/ora di lancio sta nell'intervallo (dtLast,dtNow]
				// la lancio
				if (dtLast < dtRun && dtRun <= dtNow)
				{
					try
					{
						CancellaEntryScaduteNellaLTS("System");
					}
					catch
					{
					}

					try
					{
						BLLog blLog = new BLLog();
						DateTime tsPurgeUntil = DateTime.Now;
						int giorni = ReadAppSettings.ToInt32("UserActivity.Purge.Delay.Days", 90);
						tsPurgeUntil = tsPurgeUntil.AddDays(-giorni);
						blLog.PurgeUserActivity(tsPurgeUntil);
					}
					catch
					{
					}
				}

				// sposto dtLast
				dtLast = dtNow;
			}
		}

		public void CancellaEntryScaduteNellaLTS(string userName)
		{
			try
			{
				IDalLTS dal = DalProvider.DAL.CreateDalLTS();
				if (dal.UltimaCancellazioneLTSEseguita() == true)
					return;

				LogWrite(userName, "Cancellazione LTS: inizio attivita");

				List<string> c2pList = this.GetQmgrNameList();

				List<MWPDataLTS> recList = dal.GetEntryLTSScadute();

				if (recList.Count > 0)
				{
					MWPServices.MWPInterface mwp = new ITRS_BL.MWPServices.MWPInterface();
					mwp.ManageAllarmeConDataInizioDataFine(c2pList, recList, 1000);

					dal.CancellaEntryLTSScadute(recList);
				}

				LogWrite(userName, "Cancellazione LTS: attivita terminata");
			}
			catch (Exception ex)
			{
				LogWrite(userName, "Cancellazione LTS: con errore ({0})", ex.Message);
				Log.Write(ex, "BLLTS.CancellaEntryLTSScadute");
				throw;
			}
		}

		private void LogWrite(string userName, string fmt, params object[] args)
		{
			string a = string.Format(fmt, args);

			using (ITRS_BL.BLLog blLog = new ITRS_BL.BLLog())
			{
				blLog.AddUserActivity(userName, TipoAttivita.CancellazioneLTS, a);
			}
		}
	}
}
