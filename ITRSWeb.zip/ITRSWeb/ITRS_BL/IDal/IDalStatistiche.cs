using System;
using System.Collections.Generic;
using System.Text;

namespace ITRS_BL.IDal
{
	public interface IDalStatistiche
	{
		int GetTempiEtVelocitaSuTrattaCount(DateTime data);
		List<BLStatistiche.TempiEtVelocitaSuTratta> GetTempiEtVelocitaSuTratta(DateTime data, string sortColumns, int startRowIndex, int maximumRows);

        int GetTempiEtVelocitaSuTrattaCount(DateTime data, int idTratta);
        List<BLStatistiche.TempiEtVelocitaSuTratta> GetTempiEtVelocitaSuTratta(DateTime data, int idTratta, string sortColumns, int startRowIndex, int maximumRows);

		int GetVolumeTrafficoTrattaCount(DateTime data);
		List<BLStatistiche.VolumeTrafficoTratta> GetVolumeTrafficoTratta(DateTime data, string sortColumns, int startRowIndex, int maximumRows);

        int GetVolumeTrafficoTrattaCount(DateTime data, int idC2P);
        List<BLStatistiche.VolumeTrafficoTratta> GetVolumeTrafficoTratta(DateTime data, int idC2P, string sortColumns, int startRowIndex, int maximumRows);

		int GetTempiEtVelocitaPerDirezioneCount(DateTime data);
		List<BLStatistiche.TempiEtVelocitaPerDirezione> GetTempiEtVelocitaPerDirezione(DateTime data, string sortColumns, int startRowIndex, int maximumRows);

        int GetTempiEtVelocitaPerDirezioneCount(DateTime data, string direzione);
        List<BLStatistiche.TempiEtVelocitaPerDirezione> GetTempiEtVelocitaPerDirezione(DateTime data, string direzione, string sortColumns, int startRowIndex, int maximumRows);

		int GetVolumeTrafficoDirezioneCount(DateTime data);
		List<BLStatistiche.VolumeTrafficoDirezione> GetVolumeTrafficoDirezione(DateTime data, string sortColumns, int startRowIndex, int maximumRows);

        int GetVolumeTrafficoDirezioneCount(DateTime data, string direzione);
        List<BLStatistiche.VolumeTrafficoDirezione> GetVolumeTrafficoDirezione(DateTime data, string direzione, string sortColumns, int startRowIndex, int maximumRows);

		int GetTempiSostaC2PCount(DateTime data);
		List<BLStatistiche.TempiSostaC2P> GetTempiSostaC2P(DateTime data, string sortColumns, int startRowIndex, int maximumRows);

        int GetTempiSostaC2PCount(DateTime data, int idC2p);
        List<BLStatistiche.TempiSostaC2P> GetTempiSostaC2P(DateTime data, int idC2p, string sortColumns, int startRowIndex, int maximumRows);

		int GetTarghePerC2PCount(DateTime data, int idC2p);
		List<BLStatistiche.TarghePerC2P> GetTarghePerC2P(DateTime data, int idC2p, string sortColumns, int startRowIndex, int maximumRows);
	}
}
