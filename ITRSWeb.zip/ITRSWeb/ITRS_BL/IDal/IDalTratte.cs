using System;
using System.Collections.Generic;
using System.Text;

using ITRS_BL.IDal;

namespace ITRS_BL.IDal
{
	public interface IDalTratta
	{
		List<Tratta> GetLista(string columnsSort);
		Tratta GetRecord(Tratta st);
		void Cancella(Tratta st);
		void Aggiorna(Tratta st);
		void Inserisci(Tratta st);
	}
}
