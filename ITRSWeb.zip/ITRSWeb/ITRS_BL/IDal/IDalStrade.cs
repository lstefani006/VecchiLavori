using System;
using System.Collections.Generic;
using System.Text;

namespace ITRS_BL.IDal
{
	public interface IDalStrada
	{
		List<Strada> GetLista(string columnsSort);
		Strada GetRecord(Strada st);
		void Cancella(Strada st);
		void Aggiorna(Strada st);
		void Inserisci(Strada st);
	}
}
