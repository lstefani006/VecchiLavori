using System;
using System.Collections.Generic;
using System.Text;
using ITRS_BL;
using ITRS_BL.IDal;
using System.Data;

namespace ITRS_BL.IDal
{

	public interface IDalLTS
	{
		List<BLLTS.LTSRecord> GetLTSList(string sortColumns, int startRowIndex, int maximumRows,
			string targa, string nazionalita,
			string tipoLTS,
			DateTime? ricercaInizioDal, DateTime? ricercaInizioAl,
			DateTime? ricercaFineDal, DateTime? ricercaFineAl,
			string IdUtenteRichiedente, int? IdCoa,
			DateTime? ricercaInseritoDal, DateTime? ricercaInseritoAl,
			string ricercaEmail, int? idCoaPerTipoC,
			string IdUtenteCollegato, int? IdCoaDiCompetenzaUtenteCollegato);
		int GetLTSListCount(string targa,
			string nazionalita,
			string tipoLTS,
			DateTime? ricercaInizioDal, DateTime? ricercaInizioAl,
			DateTime? ricercaFineDal, DateTime? ricercaFineAl,
			string IdUtenteRichiedente, int? IdCoa,
			DateTime? ricercaInseritoDal, DateTime? ricercaInseritoAl,
			string ricercaEmail, int? idCoaPerTipoC,
			string IdUtenteCollegato, int? IdCoaDiCompetenzaUtenteCollegato);

		BLLTS.LTSRecord GetLTSFromKey(string targa, string nazionalita, long idLts);
		BLLTS.LTSRecord GetLTSDiTipoC(string targa, string nazionalita, int idCoa);


		List<BLLTS.UtenteRichiedente> GetListaUtentiRichiedenti();


		void Update(BLLTS.LTSRecord rec);
		/// <summary>
		/// Inserisce il record.
		/// </summary>
		/// <param name="rec">ritorna true se riesce ad inserire, false se chiave duplicata.</param>
		/// <returns></returns>
		bool Insert(BLLTS.LTSRecord rec);

		int Delete(BLLTS.LTSRecord rec);

		//		int GetNumberOfLTSFromTarga(string targa, string nazionalita, DateTime validoIl);

		/// <summary>
		/// Ritorna la massima Data di fine validita`.
		/// </summary>
		/// <param name="targa"></param>
		/// <param name="nazionalita"></param>
		/// <param name="validoIl"></param>
		/// <returns></returns>
		DateTime? GetMaxDataFineValidita(string targa, string nazionalita, DateTime validoIl, bool ignoraA2);


		List<MWPC2PInfo> GetListC2P();
		List<MWPC2PInfo> GetListC2P(int idC2P);

		List<string> GetListaQmgr();

		IEnumerable<MWPDataLTS> UpdateC2PfromLTS(DateTime validoIl, bool ignoraA2);

		IEnumerable<MWPDataLTS_A2> UpdateC2PfromLTS_A2();


		List<BLLTS.LTSRecord> GetLTSForExportTipoC(int idCOA, DateTime validoAl);


		List<MWPDataLTS> GetEntryLTSScadute();
		void CancellaEntryLTSScadute(List<MWPDataLTS> e);
		bool UltimaCancellazioneLTSEseguita();

	}

	public delegate void ElaboraLTS(List<MWPDataLTS> ltsData);
	public delegate void ElaboraLTSOneRecord(MWPDataLTS ltsData);


	[Serializable]
	public class MWPDataLTS
	{
		public string enumTipoLTS { get { return _enumTipoLTS; } set { _enumTipoLTS = value; } }
		public string targa { get { return _targa; } set { _targa = value; } }
		public string nazionalita { get { return _nazionalita; } set { _nazionalita = value; } }
		public DateTime dataOraInizio { get { return _dataOraInizio; } set { _dataOraInizio = value; } }
		public DateTime dataOraFine { get { return _dataOraFine; } set { _dataOraFine = value; } }
		public bool AddCommand { get { return _Add; } set { _Add = value; } }


		private string _enumTipoLTS;
		private string _targa;
		private string _nazionalita;
		private DateTime _dataOraInizio;
		private DateTime _dataOraFine;
		private bool _Add;
	}


	[Serializable]
	public class MWPDataLTS_A2
	{
		public String Targa { get { return _Targa; } set { _Targa = value; } }
		public String Nazionalita { get { return _Nazionalita; } set { _Nazionalita = value; } }
		public DateTime DataRevisione { get { return _DataRevisione; } set { _DataRevisione = value; } }
		public String TipoVeicolo { get { return _TipoVeicolo; } set { _TipoVeicolo = value; } }

		#region dati
		protected String _Targa;
		protected String _Nazionalita;
		protected DateTime _DataRevisione;
		protected String _TipoVeicolo;
		#endregion
	}


}
