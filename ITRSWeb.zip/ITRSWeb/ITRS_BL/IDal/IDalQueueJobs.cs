using System;
using System.Collections.Generic;
using System.Text;

namespace ITRS_BL.IDal
{
	public interface IDalQueueJobs
	{
		string GetUserPkId(string userName);

		//void Create(string jobId, string jobType, string jobArgs, string jobPkIdUser);
		bool CreateEx(string jobId, string jobType, string jobArgs, string jobPkIdUser);
		void Abort(string jobId);
		void Suspend(string jobId);
		void Resume(string jobId);
		void Error(string jobId, string jobErrMsg);
		void Canc(string jobId, string jobType, string jobPkIdUser, BLQueueJobs.JobStatus? jobStatus);


		void Access(string jobId);

		void Progress(string jobId, string jobStatus, string jobProgrMsg, int? jobTotalSteps, int? jobCurrentStep, int ?jobResRecordCount);

		void End(string jobId);
		void Purge();
		void GetNextToRun(out string jobId, out string jobArgs, out string jobType);

		string GetStatus(string jobId);
		int? GetResRecordCount(string jobId);


		List<QueueJob> GetRunningJobs(string sortColumns);
		QueueJob GetRunningJobData(string jobId);

		string GetNetTypeFromJobType(string jobType);


		List<QueueJob> GetCancJobs();

		List<QueueJobType> GetJobTypes();
		void SaveJobTypes(QueueJobType qt);
		void SaveJobTypes(List<QueueJobType> qt);


	}
}
