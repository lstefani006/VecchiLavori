using System;
using System.Collections.Generic;
using System.Text;
using ITRS_BL;
using ITRS_BL.IDal;

namespace ITRS_BL.IDal
{

	public interface IDalLog
	{
		void Add(string application, string logType, string message, string ex);
		List<BLLog.RecordLog> GetLogs();

		void AddUserActivity(string IdUtenteAttivita, TipoAttivita TipoAttivita, string DescrizioneAttivita);

		List<BLLog.UserLogData> GetUserActivity(string sortColumns, int startRowIndex, int maximumRows, DateTime? da, DateTime? a, string utente, string tipo);
        int GetUserActivityCount(DateTime? da, DateTime? a, string utente, string tipo);

		void PurgeUserActivity(DateTime tsPurgeUntil);

        List<string> GetAllTipi();
        List<string> GetAllUtenti();

		List<BLLog.UserLogData> GetAttivitaDelGiorno(DateTime attivitaDelGiorno, string tipoAttivita);
	}
}
