using System;
using System.Data;
using System.Collections.Generic;
using System.Text;

using ITRS_BL.IDal;

namespace ITRS_BL.IDal
{

	public interface IDalEventi
	{
		List<Evento> GetEventiFromTransito(string targa, string nazionalita, DateTime dataOraRilevamento, string sortColumns);
		DettEvento GetDatiEvento(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento);


		bool PrendiInCarico(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento, string idUtentePresaInCarico);
		bool AzioneSuPresaInCarico(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento, StatoAllarme statoAllarme, string noteChiusura);

		List<EventoPresoInCarico> GetListaEventiTSPresiInCarico(string sort, int? idCoa);
		bool AnnullaPresaInCaricoEvTS(string targa, string nazionalita, DateTime evDataOraInserimento, Int64 evIdEvento, DateTime trDataOraRilevamento);
	}
}