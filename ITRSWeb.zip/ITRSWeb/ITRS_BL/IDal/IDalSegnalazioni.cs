using System;
using System.Collections.Generic;
using System.Text;

namespace ITRS_BL.IDal
{
	public interface IDalSegnalazioni
	{
		List<BLSegnalazioni.Segnalazione> GetSegnalazioniSuEvento(string Targa, string Nazionalita, DateTime DataOraInserimento, int IdEvento, string columnsSort);
		BLSegnalazioni.Segnalazione GetSegnalazione(string Targa, string Nazionalita, DateTime DataOraInserimento, int IdEvento, int progressivoSegnalazione);

	}
}
