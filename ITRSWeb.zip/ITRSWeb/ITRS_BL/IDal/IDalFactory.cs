using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;


namespace ITRS_BL.IDal
{
	public interface IDalFactory
	{
		IDalTransiti CreateDalTransiti();
		IDalIndagini CreateDalIndagini();
		IDalQueueJobs CreateDalQueueJobs();
		IDalStrada CreateDalStrade();
		IDalC2P CreateDalC2P();
		IDalCoa CreateDalCoa();
		IDalTargheBianche CreateDalTargheBianche();
		IDalTratta CreateDalTratta();
		IDalInterventi CreateDalInterventi();
		IDalEventi CreateDalEventi();
		IDalParametri CreateDalParametri();
		IDalLog CreateDalLog();
		IDalStatistiche CreateDalStatistiche();
		IDalSegnalazioni CreateDalSegnalazioni();
		IDalSorveglianza CreateDalSorveglianza();
		IDalLTS CreateDalLTS();
		IDalLTSImport CreateDalLTSImport();
		IDalLock CreateDalLock(string lockId);
	}


	public static class DalProvider
	{
		public static IDalFactory DAL
		{
			get
			{
				return ClassProvider<IDalFactory>.CreateFactory("DAL");
			}
		}
	}
}
