using System;
using System.Collections.Generic;
using System.Text;

namespace ITRS_BL.IDal
{
	public interface IDalTargheBianche
	{
		List<TargheBianche> GetLista(string columnsSort, int startRowIndex, int maximumRows, DateTime validoIl);
		int GetCount(DateTime validoIl);

		List<TargheBianche> GetLista(string columnsSort, DateTime validoIl);

		TargheBianche GetRecord(TargheBianche st);
		void Cancella(TargheBianche st);
		void Aggiorna(TargheBianche st);
		void Inserisci(TargheBianche st);

		bool EsisteEntryValida(string targa, string nazionalita, out int idLts);
		bool EsisteEntry(string targa, string nazionalita, out int idLts);
	}

}
