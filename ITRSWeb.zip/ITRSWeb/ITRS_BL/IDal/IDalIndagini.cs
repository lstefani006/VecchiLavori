using System;
using System.Collections.Generic;
using System.Text;
using ITRS_BL;
using ITRS_BL.IDal;

namespace ITRS_BL.IDal
{

	public interface IDalIndagini
	{
        int QueryPerIndagineTransiti(string jobId, string targa, string nazionalita, DateTime di, DateTime df, int? IdC2P, int ?IdCoa, ref int MaxRec);
		int QueryPerIndagineEventi(string jobId, string targa, string nazionalita, DateTime di, DateTime df, int? IdC2P, int? IdCoa, TipoEvento? TipoEvento, ref int MaxRec);
        List<ResultQueryIndagineTransito> GetResultJobIndagineTransiti(string jobId, string sortColumns, bool includiIndagini, int startRowIndex, int maximumRows);
        List<ResultQueryIndagineEvento> GetResultJobIndagineEventi(string jobId, string sortColumns, int startRowIndex, int maximumRows);
        void CancellaIndagine(string jobId);


		ResultQueryIndagineTransito GetResultJobIndagineTransiti(string jobId, string targa, string nazionalita, DateTime dataOraRilevamento);
	}
}
