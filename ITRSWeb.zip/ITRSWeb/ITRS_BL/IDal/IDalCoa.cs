using System;
using System.Collections.Generic;
using System.Text;

namespace ITRS_BL.IDal
{
	public interface IDalCoa
	{
		List<Coa> GetLista(string columnsSort);
		Coa GetRecord(Coa r);
		void Cancella(Coa r);
		void Aggiorna(Coa r);
		void Inserisci(Coa r);
	}
}
