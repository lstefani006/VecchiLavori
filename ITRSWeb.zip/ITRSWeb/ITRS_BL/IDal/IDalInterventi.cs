using System;
using System.Collections.Generic;
using System.Text;

using ITRS_BL.IDal;

namespace ITRS_BL.IDal
{

	public interface IDalInterventi
	{
		string Create(string jobId, string jobType, string jobArgs, string jobUser, string targa, string nazionalita, string Note, string Motivo, int IdCoa);

		/// <summary>
		/// Procedura lanciata dal motore dei jobs per effettuare la ricerca per un intervento.
		/// </summary>
		/// <param name="jobId">il job da eseguire</param>
		/// <param name="jobArgs">gli argomenti del job</param>
		/// <returns>il numero di record trovati</returns>
		int QueryIntervento(string jobId, BL_Interventi.JobArgs jobArgs, ref bool primoTransitoLetto);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="jobId"></param>
		/// <param name="sortColumns"></param>
		/// <returns></returns>
		List<ResultQueryIntervento> GetResultJobIntervento(string jobId, string sortColumns, int startRowIndex, int maximumRows);


		List<MWPC2PInfo> DeleteIntervento(string jobId, out string targa, out string nazionalita);


		List<ListaInterventiPerCoaRes> ListaInterventiPerCoa(int IdCoa);


		InterventiQueueJob GetRunningJobData(string jobId);



		List<MWPC2PInfo> GetQmgrForMWP(string targa, string nazionalita, bool ignoraA2);

		List<MWPC2PInfo> CancellaInterventoPerCoa(int idCoa, string targa, string nazionalita);
	}

	public class MWPC2PInfo
	{
		private string _QmgrName;

		public string QmgrName
		{
			get { return _QmgrName; }
			set { _QmgrName = value; }
		}
		private DateTime? _DataOraRilevamento;

		public DateTime? DataOraRilevamento
		{
			get { return _DataOraRilevamento; }
			set { _DataOraRilevamento = value; }
		}
	}

}
