using System;
using System.Collections.Generic;
using System.Text;

namespace ITRS_BL.IDal
{
	public interface IDalSorveglianza
	{
		List<BLSorveglianza.TransitoSegnalatoSorveglianza> GetListaSorveglianza(int idCOA, BLSorveglianza.SorvTipoLTS tipoSorv);

		BLSorveglianza.DatiTransitoSegnalatoSuMessaggioMWP GetDatiPerTransitoSegnalazioneSuMessaggioMWP(string Targa, string Nazionalita, DateTime DataOraRilevamento);

		void AccodaEvento(
			 string p_TARGA,
			 string p_NAZIONALITA,
			 DateTime p_DATAORAINSERIMENTO,
			 DateTime p_DATAORARILEVAMENTO,
			 Int64 p_IDEVENTO,
			 int p_IDCOA,
			 byte[] p_Img,
			 DateTime? p_PrecEvDataOraInserimento,
			 int? p_PrecEvIdEvento,
			 DateTime? p_PrecTrDataOraRilevamento,
			string p_EnumTipoLtsSegnalazione1,
			string p_TipoVeicoloSegnalazione1,
  string p_NoteSegnalazione1,
  string p_EnumTipoLtsSegnalazione2,
  string p_TipoVeicoloSegnalazione2,
  string p_NoteSegnalazione2,
  string p_EnumTipoLtsSegnalazione3,
  string p_TipoVeicoloSegnalazione3,
  string p_NoteSegnalazione3

		);


		byte[] GetMapSorveglianza(int idCoa, string Targa, string Nazionalita, DateTime DataOraRilevamento);


		List<BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato> GetListaSorveglianzaPaginata(string sortColumns, int startRowIndex, int maximumRows, int idCoa, BLSorveglianza.SorvTipoLTS tipoSorv);
		int GetListaSorveglianzaPaginataCount(int idCoa, BLSorveglianza.SorvTipoLTS tipoSorv);

		BLSorveglianza.TransitoSegnalatoPrecedente GetTransitoSegnalatoPrecedente(string targa, string nazionalita, DateTime dataOraRilevamento);

		BLSorveglianza.StatisticaSorveglianza GetReportAllarmiTS(int idCoa, DateTime di, DateTime df);


		List<BLSorveglianza.SegnalazioniAssociateAllEvento> GetSegnalazioniAssociate(
			string p_TARGA,
			string p_NAZIONALITA,
			 DateTime p_DATAORAInserimento);


	}
}
