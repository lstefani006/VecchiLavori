using System;
using System.Collections.Generic;
using System.Text;

namespace ITRS_BL.IDal
{
	public interface IDalC2P
	{
		List<C2P> GetLista(string columnsSort);
		C2P GetRecord(C2P r);
		void Cancella(C2P r);
		void Aggiorna(C2P r);
		void Inserisci(C2P r);

        List<C2PDiagnostic> GetListaDiagnostica(string columnsSort);
        C2PDiagnostic GetRecord(C2PDiagnostic r);
        void AggiornaDiagnostica(C2PDiagnostic r);
        SytemDiagnostic RefreshDiagnostica(int IdCoa);

		List<DiaTransitiRecord> GetListaTransitiNelGiorno(DateTime d, int periodoMinuti, int? c2p, string ordinaPer);

		List<C2PDiagnosticaStorica> GetListaDiagnosticaStorica(DateTime di, DateTime df);
		List<C2PDiagnosticaStorica> GetListaDiagnosticaStorica(int idC2P, DateTime di, DateTime df);
		void DiagnosticaC2PPoller(int updateMinuteTimeout);

		List<C2PTsDelay> GetTsDelay();
		void UpdateTsDelay(C2PTsDelay r);
	}
}
