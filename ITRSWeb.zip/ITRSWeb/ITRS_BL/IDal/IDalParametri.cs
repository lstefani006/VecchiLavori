using System;
using System.Collections.Generic;
using System.Text;

using ITRS_BL.IDal;


namespace ITRS_BL.IDal
{
	public interface IDalParametri
	{
		List<BL_Parametri.Parametro> GetParametri();
		void SaveParametro(string parTipo, decimal parValue);
		void SaveParametri(List<BL_Parametri.Parametro> parList);
	}
}
