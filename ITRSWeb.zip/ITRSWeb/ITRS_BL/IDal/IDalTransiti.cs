using System;
using System.Data;
using System.Collections.Generic;
using System.Text;

using ITRS_BL.IDal;

namespace ITRS_BL.IDal
{

	public interface IDalTransiti
	{
		int GetTransitiCount();
		List<Transiti> GetTransiti(string sortColumns, int startRowIndex, int maximumRows);

		DatiTransito GetDatiTransitoOrTransitoSuEvento(string targa, string nazionalita, DateTime dataOraRilevamento);
		
		byte [] GetBlobImmagine(string targa, string nazionalita, DateTime dataOraRilevamento);
		void GetLatLonTransito(string targa, string nazionalita, DateTime dataOraRilevamento, out double lat, out double lon);

		List<DatiTransito> GetTransitiDellEvento(string targa, string nazionalita, DateTime dataOraInserimento, int idEvento, string sortColumns);

		bool PrendiInCarico(string targa, string nazionalita, DateTime dataOraRilevamento, string idUtentePresaInCarico);
		bool AzioneSuPresaInCarico(string targa, string nazionalita, DateTime dataOraRilevamento, StatoTransito statoTransito, string noteChiusura, string TargaValidata, string NazionalitaValidata);

		void RiconoscimentoManuale(string targa, string nazionalita, DateTime dataOraRilevamento, string targaRiconosciutaDallOperatore, string nazioneRiconosciutaDallOperatore, string note);

		void GetTransitoData(string targa, string naz, DateTime dataOraRilevamento, out string targaRil, out int idC2P, out string qmgr);
		void SaveImmagine(string targa, string naz, DateTime dataOraRilevamento, byte[] img);

		DatiTarga GetDatiTarga(string targa, string naz, DateTime dataOraRilevamento);

		List<TransitoPresoInCarico> GetListaTransitiPresiInCarico(string sortColumns, int? IdCoa);
		bool AnnullaTransitoPresoInCarico(string targa, string nazionalita, DateTime dataOraRilevamento);
	}
}
