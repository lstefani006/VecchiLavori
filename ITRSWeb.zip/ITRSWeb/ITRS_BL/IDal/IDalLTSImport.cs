using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ITRS_BL.IDal;


namespace ITRS_BL.IDal
{
	public interface IDalLTSImport
	{
		void ImportIncrementaleA1(string UserPkId, Stream s, bool daImportMassivo, bool inviaMessaggiDeltaAiC2P);
		void ImportMassivo(BLLTSImport.TipoLTS tipoLTS, string UserPkId, string fileNameWithPath);
		void CancellaLTS(BLLTSImport.TipoLTS tipoLTS);


		List<BLLTSImport.Nazione> GetListaNazioni();

		int CreaDifferenze(string UserPkId, string fileNameIn, string fileNameOut);


		List<BLLTSImport.AttivazioneA2> GetListaAttivazioneA2();
		void AggiornaAttivazioneA2(BLLTSImport.AttivazioneA2 record);
	}

	/// <summary>
	/// Classe per ottenere un lock GLOBALE usando il DB.
	/// Il lock, identificato con un lockId, e` fatto tenendo una transazione aperta e facendo select for update nowait.
	/// In questo modo e` possibile acquisire in esclusiva il lock o informare che il lock e` gia` stato preso.
	/// </summary>
	public interface IDalLock : IDisposable
	{
		bool IsLockAcquired { get; }
	}
}
