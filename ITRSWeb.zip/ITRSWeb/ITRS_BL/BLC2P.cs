using System;
using System.Data;
using System.ComponentModel;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Threading;
using System.Configuration;
using System.Collections.Generic;
using ITRS_BL.IDal;

namespace ITRS_BL
{
	public partial class BLC2P : Component
	{
		public BLC2P()
		{
			InitializeComponent();
		}

		public BLC2P(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<C2P> GetLista(string columnsSort)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				return t.GetLista(columnsSort);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella C2P", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<KeyDescription<int>> GetListaKeyDescription()
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				List<C2P> cList = t.GetLista("Descrizione");

				List<KeyDescription<int>> r = new List<KeyDescription<int>>();

				foreach (C2P c in cList)
				{
					KeyDescription<int> k = new KeyDescription<int>(c.IdC2P, c.Descrizione);
					r.Add(k);
				}

				return r;

			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella C2P", ex);
			}
		}


		[DataObjectMethod(DataObjectMethodType.Select)]
		public C2P GetC2P(int idC2P)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				C2P r = new C2P();
				r.IdC2P = idC2P;
				return t.GetRecord(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella C2P", ex);
			}
		}


		[DataObjectMethod(DataObjectMethodType.Delete)]
		public void CancellaC2P(C2P r)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				t.Cancella(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella cancellazione del record", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Update)]
		public void AggiornaC2P(C2P r)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				t.Aggiorna(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nell'aggiornamento del record", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Insert)]
		public void InserisciC2P(C2P r)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				t.Inserisci(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nell'inserimento del record", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<C2PDiagnostic> GetListaDiagnostica(string columnsSort)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				return t.GetListaDiagnostica(columnsSort);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella C2PDiagnostic", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public C2PDiagnostic GetC2PDiagnostic(int idC2P)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				C2PDiagnostic r = new C2PDiagnostic();
				r.IdC2P = idC2P;
				return t.GetRecord(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella C2PDiagnostic", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public SytemDiagnostic RefreshDiagnostica(int idCoa)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				return t.RefreshDiagnostica(idCoa);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della diagnostica e sorveglianza ", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Update)]
		public void AggiornaC2PDiagnostic(C2PDiagnostic r)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				t.AggiornaDiagnostica(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nell'aggiornamento del record della tabella C2PDiagnostic", ex);
			}
		}

		public List<DiaTransitiRecord> GetListaTransitiNelGiorno(DateTime d, int periodoMinuti, int? IdC2P, string ordinaPer)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				return t.GetListaTransitiNelGiorno(d, periodoMinuti, IdC2P, ordinaPer);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetListaTransitiNelGiorno", ex);
			}
		}

		public List<C2PDiagnosticaStorica> GetListaDiagnosticaStorica(int? idC2P, DateTime di, DateTime df)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				if (idC2P.HasValue)
					return t.GetListaDiagnosticaStorica(idC2P.Value, di, df);
				else
					return t.GetListaDiagnosticaStorica(di, df);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetListaDiagnosticaStorica", ex);
			}
		}

		static Timer _TimerDiagnosticaC2PPoller = null;
		/// <summary>
		/// Server per pollare l'attivita` dei C2P ai fini Diagnostici
		/// </summary>
		public static void StartServer()
		{
			if (_TimerDiagnosticaC2PPoller == null)
			{
				int pt = 60 * ReadAppSettings.ToInt32("BLC2P.Diagnostica.PollingPeriod.Min", 3);
				int updateMinTimeout = ReadAppSettings.ToInt32("BLC2P.Diagnostica.UpdateTimeout.Min", 10);
				_TimerDiagnosticaC2PPoller = new Timer(DiagnosticaC2PPoller, updateMinTimeout, 1000 * pt, 1000 * pt);
			}
		}
		public static void StopServer()
		{
			if (_TimerDiagnosticaC2PPoller != null)
			{
				_TimerDiagnosticaC2PPoller.Dispose();
				_TimerDiagnosticaC2PPoller = null;
			}
		}

		private static void DiagnosticaC2PPoller(object st)
		{
			try
			{
				int tm = (int)st;
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				t.DiagnosticaC2PPoller(tm);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DiagnosticaC2PPoller");
			}
		}


		public List<C2PTsDelay> GetTsDelay()
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				return t.GetTsDelay();
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetTsDelay", ex);
			}
		}
		public void UpdateTsDelay(C2PTsDelay r)
		{
			try
			{
				IDalC2P t = DalProvider.DAL.CreateDalC2P();
				t.UpdateTsDelay(r);
			}
			catch (Exception ex)
			{
				throw new ApplicationException("UpdateTsDelay", ex);
			}
		}
	}

	[Serializable]
	public class C2P
	{
		public string QmgrName { get { return _QmgrName; } set { _QmgrName = value; } }
		public string CodiceStrada { get { return _CodiceStrada; } set { _CodiceStrada = value; } }
		public string Km { get { return _Km; } set { _Km = value; } }
		public int IdC2P { get { return _IdC2P; } set { _IdC2P = value; } }
		public int IdCOA { get { return _IdCOA; } set { _IdCOA = value; } }
		public int? IdTrattaPrec { get { return _IdTrattaPrec; } set { _IdTrattaPrec = value; } }
		public int? IdTrattaSucc { get { return _IdTrattaSucc; } set { _IdTrattaSucc = value; } }
		public string Direzione { get { return _Direzione; } set { _Direzione = value; } }
		public string Descrizione { get { return _Descrizione; } set { _Descrizione = value; } }
		public string DescrCOA { get { return _DescrCOA; } set { _DescrCOA = value; } }
		public string DescrTrattaPrec { get { return _DescrTrattaPrec; } set { _DescrTrattaPrec = value; } }
		public string DescrTrattaSucc { get { return _DescrTrattaSucc; } set { _DescrTrattaSucc = value; } }
		public double Lat { get { return _Lat; } set { _Lat = value; } }
		public double Lon { get { return _Lon; } set { _Lon = value; } }

		string _QmgrName;
		string _CodiceStrada;
		string _Km;
		int _IdC2P;
		int _IdCOA;

		string _DescrCOA;

		int? _IdTrattaPrec;
		int? _IdTrattaSucc;

		string _DescrTrattaPrec;
		string _DescrTrattaSucc;

		string _Direzione;
		string _Descrizione;

		double _Lat;
		double _Lon;
	}

	[Serializable]
	public class C2PDiagnostic
	{
		public int IdC2P { get { return _IdC2P; } set { _IdC2P = value; } }
		public string Descrizione { get { return _Descrizione; } set { _Descrizione = value; } }
		public bool Diag_C2P_VE { get { return _Diag_C2P_VE; } set { _Diag_C2P_VE = value; } }
		public DateTime? Diag_TSUpdate { get { return _Diag_TSUpdate; } set { _Diag_TSUpdate = value; } }
		public bool Diag_CD_VE { get { return _Diag_CD_VE; } set { _Diag_CD_VE = value; } }
		public bool Diag_CS_VE { get { return _Diag_CS_VE; } set { _Diag_CS_VE = value; } }
		public bool Diag_CE_VE { get { return _Diag_CE_VE; } set { _Diag_CE_VE = value; } }
		public bool Diag_CU_VE { get { return _Diag_CU_VE; } set { _Diag_CU_VE = value; } }
		public string Diag_CD_Status { get { return _CDStatus; } set { _CDStatus = value; } }
		public string Diag_CS_Status { get { return _CSStatus; } set { _CSStatus = value; } }
		public string Diag_CE_Status { get { return _CEStatus; } set { _CEStatus = value; } }
		public string Diag_CU_Status { get { return _CUStatus; } set { _CUStatus = value; } }
		public string Diag_C2P_Alive { get { return _C2PAlive; } set { _C2PAlive = value; } }
		public string Diag_CD_Alive { get { return _CDAlive; } set { _CDAlive = value; } }
		public string Diag_CS_Alive { get { return _CSAlive; } set { _CSAlive = value; } }
		public string Diag_CE_Alive { get { return _CEAlive; } set { _CEAlive = value; } }
		public string Diag_CU_Alive { get { return _CUAlive; } set { _CUAlive = value; } }

		#region dati
		private int _IdC2P;
		private DateTime? _Diag_TSUpdate;
		private string _Descrizione;
		private string _C2PAlive;
		private string _CDAlive;
		private string _CSAlive;
		private string _CEAlive;
		private string _CUAlive;
		private string _CDStatus;
		private string _CSStatus;
		private string _CEStatus;
		private string _CUStatus;
		private bool _Diag_CD_VE;
		private bool _Diag_CS_VE;
		private bool _Diag_CE_VE;
		private bool _Diag_CU_VE;
		private bool _Diag_C2P_VE;
		#endregion
	}

	[Serializable]
	public class SytemDiagnostic
	{
		public bool Diagnostica   { get { return _Diagnostica; }    set { _Diagnostica = value;    } }
		public int SorveglianzaA1 { get { return _SorveglianzaA1; } set { _SorveglianzaA1 = value; } }
		public int SorveglianzaA2 { get { return _SorveglianzaA2; } set { _SorveglianzaA2 = value; } }

		#region dati
		private bool _Diagnostica;
		private int _SorveglianzaA1;
		private int _SorveglianzaA2;
		#endregion
	}

	[Serializable]
	public class DiaTransitiRecord
	{
		public string C2P { get { return _C2P; } set { _C2P = value; } }
		public decimal Periodo { get { return _Periodo; } set { _Periodo = value; } }
		public decimal NumTr { get { return _NumTr; } set { _NumTr = value; } }
		public decimal NumEv { get { return _NumEv; } set { _NumEv = value; } }
		public decimal NumTr_S { get { return _NumTr_S; } set { _NumTr_S = value; } }
		public decimal NumTr_D { get { return _NumTr_D; } set { _NumTr_D = value; } }
		public decimal NumTr_E { get { return _NumTr_E; } set { _NumTr_E = value; } }
		public decimal NumTr_U { get { return _NumTr_U; } set { _NumTr_U = value; } }
		public decimal NumEv_S { get { return _NumEv_S; } set { _NumEv_S = value; } }
		public decimal NumEv_D { get { return _NumEv_D; } set { _NumEv_D = value; } }
		public decimal NumEv_E { get { return _NumEv_E; } set { _NumEv_E = value; } }
		public decimal NumEv_U { get { return _NumEv_U; } set { _NumEv_U = value; } }

		private string _C2P;
		private decimal _Periodo;
		private decimal _NumTr;
		private decimal _NumEv;
		private decimal _NumTr_S;
		private decimal _NumTr_D;
		private decimal _NumTr_E;
		private decimal _NumTr_U;
		private decimal _NumEv_S;
		private decimal _NumEv_D;
		private decimal _NumEv_E;
		private decimal _NumEv_U;
	}

	[Serializable]
	public class C2PDiagnosticaStorica
	{
		public string C2P_DESCR { get { return _C2P_DESCR; } set { _C2P_DESCR = value; } }
		public decimal DIAG_PROG { get { return _DIAG_PROG; } set { _DIAG_PROG = value; } }
		public DateTime DIAG_TSUPDATE { get { return _DIAG_TSUPDATE; } set { _DIAG_TSUPDATE = value; } }
		public string DIAG_CD_ALIVE { get { return _DIAG_CD_ALIVE; } set { _DIAG_CD_ALIVE = value; } }
		public string DIAG_CS_ALIVE { get { return _DIAG_CS_ALIVE; } set { _DIAG_CS_ALIVE = value; } }
		public string DIAG_CE_ALIVE { get { return _DIAG_CE_ALIVE; } set { _DIAG_CE_ALIVE = value; } }
		public string DIAG_CU_ALIVE { get { return _DIAG_CU_ALIVE; } set { _DIAG_CU_ALIVE = value; } }
		public string DIAG_C2P_ALIVE { get { return _DIAG_C2P_ALIVE; } set { _DIAG_C2P_ALIVE = value; } }
		public string DIAG_CD_STATUS { get { return _DIAG_CD_STATUS; } set { _DIAG_CD_STATUS = value; } }
		public string DIAG_CS_STATUS { get { return _DIAG_CS_STATUS; } set { _DIAG_CS_STATUS = value; } }
		public string DIAG_CE_STATUS { get { return _DIAG_CE_STATUS; } set { _DIAG_CE_STATUS = value; } }
		public string DIAG_CU_STATUS { get { return _DIAG_CU_STATUS; } set { _DIAG_CU_STATUS = value; } }

		#region dati
		decimal _DIAG_PROG;
		DateTime _DIAG_TSUPDATE;
		string _DIAG_CD_ALIVE;
		string _DIAG_CS_ALIVE;
		string _DIAG_CE_ALIVE;
		string _DIAG_CU_ALIVE;
		string _DIAG_C2P_ALIVE;
		string _DIAG_CD_STATUS;
		string _DIAG_CS_STATUS;
		string _DIAG_CE_STATUS;
		string _DIAG_CU_STATUS;
		string _C2P_DESCR;
		#endregion
	}


	[Serializable]
	public class C2PTsDelay
	{
		public Int16 IdC2P { get { return _IdC2P; } set { _IdC2P = value; } }
		public String C2PDescr { get { return _C2PDescr; } set { _C2PDescr = value; } }
		public Int64? TsDelay { get { return _TsDelay; } set { _TsDelay = value; } }
		public String CoaDescr { get { return _CoaDescr; } set { _CoaDescr = value; } }

		#region dati
		protected Int16 _IdC2P;
		protected String _C2PDescr;
		protected Int64? _TsDelay;
		protected String _CoaDescr;
		#endregion
	}

}
