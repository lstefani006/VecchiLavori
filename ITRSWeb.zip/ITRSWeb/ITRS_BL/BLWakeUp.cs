using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace ITRS_BL
{
	/// <summary>
	/// Classe remotizzata utilizzata da Web per indicare al server/servizio
	/// che esiste nel DB un nuovo job da elaborare.
	/// </summary>
	public partial class BLWakeUp : Component
	{
		public BLWakeUp()
		{
			InitializeComponent();
		}

		public BLWakeUp(IContainer container)
		{
			container.Add(this);

			InitializeComponent();
		}

		/// <summary>
		/// chiamando questo metodo si indica al server che esiste nel DB un nuovo
		/// job da eseguire.
		/// </summary>
		public void NuovoJobAccodato()
		{
			BLQueueJobs.NuovoJobInCoda();
		}
	}
}
