using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using ITRS_BL.IDal;


namespace ITRS_BL
{
	[DataObjectAttribute]
	public partial class BLSegnalazioni : Component
	{
		public BLSegnalazioni()
		{
			InitializeComponent();
		}

		public BLSegnalazioni(IContainer container)
		{
			container.Add(this);

			InitializeComponent();
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Segnalazione> GetSegnalazioniSuEvento(string Targa, string Nazionalita, DateTime DataOraInserimento, int IdEvento, string columnsSort)
		{

			if (string.IsNullOrEmpty(columnsSort))
				columnsSort = "ProgressivoSegnalazione";
			IDalSegnalazioni dal = DalProvider.DAL.CreateDalSegnalazioni();
			List<Segnalazione> r = dal.GetSegnalazioniSuEvento(Targa, Nazionalita, DataOraInserimento, IdEvento, columnsSort);
			return r;
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public Segnalazione GetSegnalazione(string Targa, string Nazionalita, DateTime DataOraInserimento, int IdEvento, int progressivoSegnalazione)
		{
			IDalSegnalazioni dal = DalProvider.DAL.CreateDalSegnalazioni();
			Segnalazione r = dal.GetSegnalazione(Targa, Nazionalita, DataOraInserimento, IdEvento, progressivoSegnalazione);
			return r;
		}



		[Serializable]
		public class Segnalazione
		{
			public String Targa { get { return _TARGA; } set { _TARGA = value; } }
			public String Nazionalita { get { return _NAZIONALITA; } set { _NAZIONALITA = value; } }
			public DateTime DataOraInserimento { get { return _DATAORAINSERIMENTO; } set { _DATAORAINSERIMENTO = value; } }
			public Int64 IdEvento { get { return _IDEVENTO; } set { _IDEVENTO = value; } }
			public Int16 ProgressivoSegnalazione { get { return _PROGRESSIVOSEGNALAZIONE; } set { _PROGRESSIVOSEGNALAZIONE = value; } }
			public String TipoLts { get { return _TIPOLTS; } set { _TIPOLTS = value; } }
			public String UtenteRichiedente { get { return _UtenteRichiedente; } set { _UtenteRichiedente = value; } }
			public String Motivo { get { return _MOTIVO; } set { _MOTIVO = value; } }
			public String Note { get { return _NOTE; } set { _NOTE = value; } }
			public DateTime DataOraInizioValidita { get { return _DATAORAINIZIOVALIDITA; } set { _DATAORAINIZIOVALIDITA = value; } }
			public DateTime? DataOraFineValidita { get { return _DATAORAFINEVALIDITA; } set { _DATAORAFINEVALIDITA = value; } }
			public String TipoDest { get { return _TIPODEST; } set { _TIPODEST = value; } }
			public String AddrDest { get { return _ADDRDEST; } set { _ADDRDEST = value; } }
			public String LivelloPriorita { get { return _LIVELLOPRIORITA; } set { _LIVELLOPRIORITA = value; } }
			#region dati
			protected String _TARGA;
			protected String _NAZIONALITA;
			protected DateTime _DATAORAINSERIMENTO;
			protected Int64 _IDEVENTO;
			protected Int16 _PROGRESSIVOSEGNALAZIONE;
			protected String _TIPOLTS;
			protected String _UtenteRichiedente;
			protected String _MOTIVO;
			protected String _NOTE;
			protected DateTime _DATAORAINIZIOVALIDITA;
			protected DateTime? _DATAORAFINEVALIDITA;
			protected String _TIPODEST;
			protected String _ADDRDEST;
			protected String _LIVELLOPRIORITA;
			#endregion
		}
	}


}
