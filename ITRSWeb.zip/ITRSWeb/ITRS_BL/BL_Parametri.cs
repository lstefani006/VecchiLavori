using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

using ITRS_BL.IDal;

namespace ITRS_BL
{
	public partial class BL_Parametri : Component
	{
		public BL_Parametri()
		{
			InitializeComponent();
		}

		public BL_Parametri(IContainer container)
		{
			container.Add(this);

			InitializeComponent();
		}

		public List<Parametro> GetParametri()
		{
			//List<Parametro> ret = new List<Parametro>();
			//ret.Add(new Parametro("TEMPO_SOSTA", 5));
			//ret.Add(new Parametro("FREQ_VISITE", 1));
			//ret.Add(new Parametro("NUM_C2P_VISITE", 1));
			//ret.Add(new Parametro("PURGER_LOTTO", 10000));
			//ret.Add(new Parametro("PURGER_EXPTIME", 180));
			//ret.Add(new Parametro("TEMPO_ATT", 720));
			//ret.Add(new Parametro("TEMPO_RIT", 1440));

			IDalParametri t = DalProvider.DAL.CreateDalParametri();
			return t.GetParametri();
		}

		public void SaveParametro(string parTipo, decimal parValue)
		{
			IDalParametri t = DalProvider.DAL.CreateDalParametri();
			t.SaveParametro(parTipo, parValue);
		}

		public void SaveParametri(List<Parametro> parList)
		{
			IDalParametri t = DalProvider.DAL.CreateDalParametri();
			t.SaveParametri(parList);
		}


		[Serializable]
		public class Parametro
		{
			public Parametro() { }
			public Parametro(string p, decimal v) { this.partipo = p; this.parvalue = v; }
			private string partipo;

			public string ParTipo
			{
				get { return partipo; }
				set { partipo = value; }
			}
			private decimal parvalue;

			public decimal ParValue
			{
				get { return parvalue; }
				set { parvalue = value; }
			}

		}
	}
}
