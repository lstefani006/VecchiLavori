using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace ITRS_BL
{

	public partial class Echo : Component
	{
		public Echo()
		{
			InitializeComponent();
		}

		public Echo(IContainer container)
		{
			container.Add(this);

			InitializeComponent();
		}

		public string DoEcho(string s)
		{
			return "Hello: " + s;
		}
	}
}
