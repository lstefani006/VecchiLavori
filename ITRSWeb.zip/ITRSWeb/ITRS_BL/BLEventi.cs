using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

using ITRS_BL.IDal;

namespace ITRS_BL
{
	[DataObject]
	public partial class BLEventi : Component
	{
		public BLEventi()
		{
			InitializeComponent();
		}

		public BLEventi(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Evento> GetEventiDelTransito(string targa, string nazionalita, DateTime dataOraRilevamento, string sortColumns)
		{
			if (targa == null || targa == "")
				return new List<Evento>();

			try
			{
				if (string.IsNullOrEmpty(sortColumns))
					sortColumns = "DataOraInserimento";
				IDalEventi t = DalProvider.DAL.CreateDalEventi();
				return t.GetEventiFromTransito(targa, nazionalita, dataOraRilevamento, sortColumns);
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Err??? TODO", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public DettEvento GetDatiEvento(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento)
		{
			try
			{
				IDalEventi t = DalProvider.DAL.CreateDalEventi();
				return t.GetDatiEvento(targa, nazionalita, dataOraInserimento, idEvento);
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Err??? TODO", ex);
			}

		}


		public bool PrendiInCarico(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento, string idUtentePresaInCarico)
		{
			try
			{
				IDalEventi t = DalProvider.DAL.CreateDalEventi();
				return t.PrendiInCarico(targa, nazionalita, dataOraInserimento, idEvento, idUtentePresaInCarico);
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Err??? TODO", ex);
			}
		}

		public bool AzioneSuPresaInCarico(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento, StatoAllarme statoAllarme, string noteChiusura)
		{
			try
			{
				IDalEventi t = DalProvider.DAL.CreateDalEventi();
				return t.AzioneSuPresaInCarico(targa, nazionalita, dataOraInserimento, idEvento, statoAllarme, noteChiusura);
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Err??? TODO", ex);
			}
		}

		public List<EventoPresoInCarico> GetListaEventiTSPresiInCarico(string sort, int? idCoa)
		{
			try
			{
				IDalEventi t = DalProvider.DAL.CreateDalEventi();
				return t.GetListaEventiTSPresiInCarico(sort, idCoa);
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetListaEventiTSPresiInCarico", ex);
			}
		}

		public bool AnnullaPresaInCaricoEvTS(string targa, string nazionalita, DateTime evDataOraInserimento, Int64 evIdEvento, DateTime trDataOraRilevamento)
		{
			try
			{
				IDalEventi t = DalProvider.DAL.CreateDalEventi();
				return t.AnnullaPresaInCaricoEvTS(targa, nazionalita, evDataOraInserimento, evIdEvento, trDataOraRilevamento);
			}
			catch (Exception ex)
			{
				throw new ApplicationException("AnnullaPresaInCaricoEvTS", ex);
			}
		}
	}

	public enum ClasseUrgenza
	{
		/// <summary>
		/// Attuale
		/// </summary>
		ATT,
		/// <summary>
		/// ritardato
		/// </summary>
		RIT,
		/// <summary>
		/// obsoleto
		/// </summary>
		OBS
	}

	public enum TipoEvento
	{
		/// <summary>
		/// Transito Segnalato
		/// </summary>
		TS,
		/// <summary>
		/// Superamento velocit� media di tratta
		/// </summary>
		VMS,
		/// <summary>
		/// Tempo di Sosta Elevato (su singola area di servizio)
		/// </summary>
		TSE,
		/// <summary>
		/// Elevata Frequenza di Visite (su singola area)
		/// </summary>
		EFV,
		/// <summary>
		/// Elevato Numero di aree di servizio Visitate
		/// </summary>
		ENV
	}

	[Serializable]
	public enum StatoAllarme
	{
		/// <summary>
		/// Acquisito
		/// </summary>
		ACQ,
		/// <summary>
		/// Preso in carico
		/// </summary>
		PIC,
		/// <summary>
		/// Confermato
		/// </summary>
		CNF,
		/// <summary>
		/// Non confermato
		/// </summary>
		NCNF
	}

	[Serializable]
	public class Evento
	{
		#region Dati
		private string _targa;
		private string _nazionalita;
		private DateTime _DataOraInserimento;
		private int _IdEvento;

		private TipoEvento _TipoEvento;
		private StatoAllarme _StatoAllarme;
		private string _UtentePresaInCarico;
		private DateTime? _DataOraPresaInCarico;
		private DateTime? _DataOraChiusura;
		private string _NoteChiusura;
		private string _CoaDiCompetenza;
		private int _IdCoaDiCompetenza;
		private ClasseUrgenza _ClasseDiUrgenza;
		#endregion

		#region Property
		public string Targa { get { return _targa; } set { _targa = value; } }
		public string Nazionalita { get { return _nazionalita; } set { _nazionalita = value; } }
		public DateTime DataOraInserimento { get { return _DataOraInserimento; } set { _DataOraInserimento = value; } }
		public int IdEvento { get { return _IdEvento; } set { _IdEvento = value; } }
		public TipoEvento TipoEvento { get { return _TipoEvento; } set { _TipoEvento = value; } }
		public StatoAllarme StatoAllarme { get { return _StatoAllarme; } set { _StatoAllarme = value; } }
		public string UtentePresaInCarico { get { return _UtentePresaInCarico; } set { _UtentePresaInCarico = value; } }
		public DateTime? DataOraPresaInCarico { get { return _DataOraPresaInCarico; } set { _DataOraPresaInCarico = value; } }
		public DateTime? DataOraChiusura { get { return _DataOraChiusura; } set { _DataOraChiusura = value; } }
		public string NoteChiusura { get { return _NoteChiusura; } set { _NoteChiusura = value; } }
		public string CoaDiCompetenza { get { return _CoaDiCompetenza; } set { _CoaDiCompetenza = value; } }
		public int IdCoaDiCompetenza { get { return _IdCoaDiCompetenza; } set { _IdCoaDiCompetenza = value; } }
		public ClasseUrgenza ClasseDiUrgenza { get { return _ClasseDiUrgenza; } set { _ClasseDiUrgenza = value; } }
		#endregion
	}

	[Serializable]
	public class DettEvento
	{
		#region Dati
		private string _targa;
		private string _nazionalita;
		private DateTime _DataOraInserimento;
		private int _IdEvento;

		private TipoEvento _TipoEvento;
		private StatoAllarme _StatoAllarme;
		private string _UtentePresaInCarico;
		private DateTime? _DataOraPresaInCarico;
		private DateTime? _DataOraChiusura;
		private string _NoteChiusura;
		private string _CoaDiCompetenza;
		private int _IdCoaDiCompetenza;
		private ClasseUrgenza _ClasseDiUrgenza;
		private int _TransitiNonRiconosciuti;
		#endregion

		#region Property
		public string Targa { get { return _targa; } set { _targa = value; } }
		public string Nazionalita { get { return _nazionalita; } set { _nazionalita = value; } }
		public DateTime DataOraInserimento { get { return _DataOraInserimento; } set { _DataOraInserimento = value; } }
		public int IdEvento { get { return _IdEvento; } set { _IdEvento = value; } }
		public TipoEvento TipoEvento { get { return _TipoEvento; } set { _TipoEvento = value; } }
		public StatoAllarme StatoAllarme { get { return _StatoAllarme; } set { _StatoAllarme = value; } }
		public string UtentePresaInCarico { get { return _UtentePresaInCarico; } set { _UtentePresaInCarico = value; } }
		public DateTime? DataOraPresaInCarico { get { return _DataOraPresaInCarico; } set { _DataOraPresaInCarico = value; } }
		public DateTime? DataOraChiusura { get { return _DataOraChiusura; } set { _DataOraChiusura = value; } }
		public string NoteChiusura { get { return _NoteChiusura; } set { _NoteChiusura = value; } }
		public string CoaDiCompetenza { get { return _CoaDiCompetenza; } set { _CoaDiCompetenza = value; } }
		public int IdCoaDiCompetenza { get { return _IdCoaDiCompetenza; } set { _IdCoaDiCompetenza = value; } }
		public ClasseUrgenza ClasseDiUrgenza { get { return _ClasseDiUrgenza; } set { _ClasseDiUrgenza = value; } }
		public int TransitiNonRiconosciuti { get { return _TransitiNonRiconosciuti; } set { _TransitiNonRiconosciuti = value; } }
		#endregion
	}

	[Serializable]
	public class EventoPresoInCarico
	{
		public String evTarga { get { return _evTarga; } set { _evTarga = value; } }
		public String evNazionalita { get { return _evNazionalita; } set { _evNazionalita = value; } }
		public DateTime evDataOraInserimento { get { return _evDataOraInserimento; } set { _evDataOraInserimento = value; } }
		public Int64 evIdEvento { get { return _evIdEvento; } set { _evIdEvento = value; } }
		public DateTime? evDataOraPresaInCarico { get { return _evDataOraPresaInCarico; } set { _evDataOraPresaInCarico = value; } }
		public String evCoaDiCompetenza { get { return _evCoaDiCompetenza; } set { _evCoaDiCompetenza = value; } }
		public String evOperatorePresaInCarico { get { return _evOperatorePresaInCarico; } set { _evOperatorePresaInCarico = value; } }
		public DateTime trDataOraRilevamento { get { return _trDataOraRilevamento; } set { _trDataOraRilevamento = value; } }
		public TipoVarco trTipoVarco { get { return _trTipoVarco; } set { _trTipoVarco = value; } }
		public Direzione trDirezione { get { return _trDirezione; } set { _trDirezione = value; } }
		public String trAreaDiServizio { get { return _trAreaDiServizio; } set { _trAreaDiServizio = value; } }
		public String trStrada { get { return _trStrada; } set { _trStrada = value; } }

		#region dati
		protected String _evTarga;
		protected String _evNazionalita;
		protected DateTime _evDataOraInserimento;
		protected Int64 _evIdEvento;
		protected DateTime? _evDataOraPresaInCarico;
		protected String _evCoaDiCompetenza;
		protected String _evOperatorePresaInCarico;
		protected DateTime _trDataOraRilevamento;
		protected TipoVarco _trTipoVarco;
		protected Direzione _trDirezione;
		protected String _trAreaDiServizio;
		protected String _trStrada;
		#endregion
	}

}
