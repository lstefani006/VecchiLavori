using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Threading;

namespace ITRS_BL
{
	/// <summary>
	/// Questa strana classe serve per invalidare la cache web su di un evento udp.
	/// In un ambiente il load balancing, la cache non e` in share.
	/// L'effetto e` che un web puo` invalidare la propria cache quando l'utente modifica
	/// lo stato, ma non riesce a invalidare la cache in un altro web server.
	/// La soluzione "raccogliticcia" e` la seguente:
	/// 1) Web1 chiama la funzione BLCacher.CacheInvalidateWidhFileDep per invalidare una entry
	///    per chiave.
	///    Questa funzione invia un pacchetto UPD.Multicast in rete per avvisare che l'entry deve essere rimossa.
	/// 2) Un servizio ospita questa classe server di UDP.Multicast che quando arriva il messaggio
	///    legge in contenuto e aggiorna un file in ~/ITRSWeb/CacheDep/[chiave].dep
	/// 3) La cache su web ha anche la dipendenza a questo file: quando viene modificato la cache viene invalidata.
	/// </summary>
	public partial class BL_Cacher : Component
	{
		public BL_Cacher()
		{
			InitializeComponent();
		}

		public BL_Cacher(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public static void StartServer()
		{
			Network.UDP.ReceiveDelegate rx = delegate(object sender, Network.UDP.ReceiveEvent ev)
			{
				try
				{
					string CacheDepDir = ReadAppSettings.ToString("ITRS.InvalidateCache.CacheDepDir.", "");
					if (CacheDepDir == "")
						CacheDepDir = Path.Combine(ReadAppSettings.ToString("RootPath", ""), "ITRSWeb/CacheDep");

					string key = System.Text.Encoding.UTF8.GetString(ev.Msg);
					string fn = Path.Combine(CacheDepDir, key + ".dep");
					if (!File.Exists(fn))
						Log.Write("BL_Cacher.ThreadFunc: Il file {0} non corrisponde a nessuna chiave", fn);
					else
						File.SetLastWriteTime(fn, DateTime.Now);
				}
				catch
				{
				}
			};

			Network.UDP.ErrorDelegate er = delegate(object sender, Network.UDP.ErrorEvent ev)
			{
				Log.Write(ev.Exception, "BL_Cacher.ThreadFunc");
			};

			ThreadStart thd = delegate()
			{
				for (; ; )
				{
					try
					{
						string groupAddr = ReadAppSettings.ToString("ITRS.InvalidateCache.GroupAddr", "224.211.45.5");
						int groupPort = ReadAppSettings.ToInt32("ITRS.InvalidateCache.GroupPort", 12084);

						Network.UDP.Multicast.Listener lst = new Network.UDP.Multicast.Listener(groupAddr, groupPort);
						lst.Receive += rx;
						lst.Error += er;
						lst.Listen();
					}
					catch (Exception ex)
					{
						Log.Write(ex, "BL_Cacher.ThreadFunc");
						Thread.Sleep(1000 * 10);
					}
				}
			};

			_th = new Thread(thd);
			_th.IsBackground = true;
			_th.Start();
		}

		public static void StopServer()
		{
			try
			{
				_th.Abort();
				_th = null;
			}
			catch { }
		}


		static Thread _th = null;
	}
}
