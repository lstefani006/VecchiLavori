using System;
using System.ComponentModel;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Threading;
using System.Configuration;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using ITRS_BL.IDal;


namespace ITRS_BL
{
	/// <summary>
	/// Classe per gestire la coda dei job.
	/// La classe NON e` remotizzata.
	/// La classe viene utilizzata sia dal cliente web che dal server/servizio.
	/// Il cliente accoda i job nel DB (tabella QueuedJobs) e li monitorizza.
	/// Il server va in polling sulla tabella QueuedJobs per cercare nuovi job da eseguire e per
	/// cercare job da cancellare.
	/// 
	/// Per evitare che il server va in polling troppo frequentemente nella tabella dei job,
	/// (tipo una volta al secondo), esiste una classe BLWakeUp - remotizzata - che viene 
	/// utilizzata dai clienti quando accodano i job per informare il server che esitono job da eseguire.
	/// In questo modo il server viene svegliato subito e serve il job.
	/// Il server comunque va in poll nella tabella (ogni 10 secondi) perche` il sistema potrebbe
	/// avere non disponibile uno sei due servizi.
	/// </summary>
	public partial class BLQueueJobs : Component
	{
		public BLQueueJobs()
		{
			InitializeComponent();
		}

		public BLQueueJobs(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public string GetUserPkId(string userName)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				string pkid = t.GetUserPkId(userName);
				return pkid;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.GetUserPkId");
				throw;
			}

		}

		/// <summary>
		/// Server per gestire i Job in coda
		/// </summary>
		public static void StartServer()
		{
			if (_th != null) return;
			lock (_thLock)
			{
				if (_th == null)
				{
					_th = new Thread(new ThreadStart(DoWork));
					_th.IsBackground = true;
					_th.Start();
				}
			}
		}

		public static void StopServer()
		{
			_evQuitThread.Set();

			bool bThreadUscito = _th.Join(5000);
			if (!bThreadUscito)
				_th.Abort();
			_th = null;
		}

		static Thread _th = null;
		static object _thLock = new object();
		static System.Threading.AutoResetEvent _evNuovoJobInCoda = new AutoResetEvent(false);
		static System.Threading.AutoResetEvent _evQuitThread = new AutoResetEvent(false);
		static SortedDictionary<string, string> _NetTypeCache = new SortedDictionary<string, string>();

		public static void NuovoJobInCoda()
		{
			_evNuovoJobInCoda.Set();
		}

		private static void DoWork()
		{
			// in questo modo parte subito facendo il purge
			DateTime lastPurge = new DateTime(2000, 1, 1);

			for (; ; )
			{
				try
				{
					int sec = ReadAppSettings.ToInt32("QJType_PollTimeSec", 10);

					int nw = WaitHandle.WaitAny(new WaitHandle[] { _evNuovoJobInCoda, _evQuitThread }, 1000 * sec, false);

					// nw indica 1) evento in coda 2) quit dal thread 3) timeout
					// devo uscire dal thread per richiesta di quit.
					// e fare polling sul db per 1) e 3)
					if (nw == 1)
						return;

					// controllo se esiste un job da eseguire.
					if (true)
					{
						ExecuteJobData jrt = new ExecuteJobData();

						BLQueueJobs bl = new BLQueueJobs();
						if (bl.GetNextToRun(out jrt.jobId, out jrt.jobArgs, out jrt.jobType))
						{
#if DEBUG
							//Console.WriteLine("Running job {0} type={1}", jrt.jobId, jrt.jobType);
#endif
							ThreadPool.QueueUserWorkItem(new WaitCallback(bl.ExecuteJob), jrt);
						}
					}

					// pulisco i job non piu` usati.
					int hPurge = ReadAppSettings.ToInt32("QJType_PurgePeriodHours", 1);
					TimeSpan ts = DateTime.Now - lastPurge;
					if (ts.Hours > hPurge)
					{
						lastPurge = DateTime.Now;
						BLQueueJobs bl = new BLQueueJobs();
						ThreadPool.QueueUserWorkItem(new WaitCallback(bl.Purge));
					}
				}
				catch (Exception ex)
				{
					Log.Write(ex, "BLQueueJobs.DoWork");
				}
			}
		}


		private static IJobRunner GetJobRunnerFromType(string type)
		{
			string s;
			lock (_NetTypeCache)
			{
				if (!_NetTypeCache.ContainsKey(type))
				{
					IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
					s = t.GetNetTypeFromJobType(type);
					_NetTypeCache[type] = s;
				}
				else
					s = _NetTypeCache[type];
			}
			Type ty = Type.GetType(s);
			IJobRunner jr = (IJobRunner)Activator.CreateInstance(ty);
			return jr;
		}

		private class ExecuteJobData
		{
			public string jobId;
			public string jobArgs;
			public string jobType;
		}

		private void ExecuteJob(object data)
		{
			ExecuteJobData jobData = (ExecuteJobData)data;
			try
			{

				// costruisco partendo dal jobType una istanza della classe BL
				// che eseguira` il batch
				IJobRunner r = GetJobRunnerFromType(jobData.jobType);

				// gli argomenti del batch nel DB sono sotto forma di stringa in xml.
				// Deserializzo la stringa in oggetto.
				XmlSerializerFactory f = new XmlSerializerFactory();
				XmlSerializer xs = f.CreateSerializer(r.GetJobArgsType());
				object sd = xs.Deserialize(new StringReader(jobData.jobArgs));

				r.ExecuteJob(jobData.jobId, sd);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.ExecuteJob");

				// qui sono alla frutta.
				// Il job e` finito con errore. 
				// Recupero la situazione controllando lo stato e mettendolo in ERR
				try
				{
					JobStatus js = this.GetStatus(jobData.jobId);
					if (js == JobStatus.QUEUE || js == JobStatus.RRES || js == JobStatus.RUN)
					{
						this.Error(jobData.jobId, "Errore nell'esecuzione del job");
					}
				}
				catch
				{
				}
			}
		}

		/// <summary>
		/// Mette un nuovo job in coda.
		/// Ritorna l'id del nuovo job o stringa vuota ""
		/// se il job non e` stato messo in coda per in accordo 
		/// con i criteri di accodamento descritti in QJTYPES
		/// </summary>
		/// <param name="jobType"></param>
		/// <param name="jobArgs"></param>
		/// <param name="jobPkIdUser"></param>
		/// <returns>il jobId o "" se il job non e` stato messo in coda</returns>
		public string Create(string jobType, object jobArgs, string jobPkIdUser)
		{
			Debug.Assert(jobType != null);
			Debug.Assert(jobArgs != null);
			Debug.Assert(jobPkIdUser != null);

			string jobArgsString = CreateJobArgsString(jobArgs);
			return CreateString(jobType, jobArgsString, jobPkIdUser);
		}

		public static string CreateJobId()
		{
			string jobId = Guid.NewGuid().ToString("N").ToUpper();
			return jobId;
		}

		public static string CreateJobArgsString(object jobArgs)
		{
			StringWriter sw = new StringWriter();
			XmlSerializerFactory f = new XmlSerializerFactory();
			XmlSerializer xr = f.CreateSerializer(jobArgs.GetType());
			xr.Serialize(sw, jobArgs);
			sw.Flush();

			string jobArgsString = sw.ToString();
			return jobArgsString;
		}

		private string CreateString(string jobType, string jobArgs, string jobPkIdUser)
		{
			try
			{
				string jobId = CreateJobId();
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				bool b = t.CreateEx(jobId, jobType, jobArgs, jobPkIdUser);

				ITRS_BL.BLWakeUp bl = new ITRS_BL.BLWakeUp();
				bl.NuovoJobAccodato();

				if (b == false)
					return "";

				return jobId;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.CreateString");
				throw new ApplicationException("Errore accodando il job", ex);
			}
		}


		public void Abort(string jobId)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.Abort(jobId);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.Abort");
				throw new ApplicationException("Errore abortendo il job", ex);
			}

		}

		public void Access(string jobId)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.Access(jobId);

			}
			catch (Exception ex)
			{
				Log.Write("BLQueueJobs.Access", ex);
				throw;
			}
		}

		/// <summary>
		/// Funzione che permette di mettere in stato canc tutti i job che rispondono al criterio in ingresso.
		/// </summary>
		/// <param name="jobType">tipo del job o null per tutti i tipi dei job</param>
		/// <param name="jobPkIdUser">id dell'utente o null per tutti gli utenti</param>
		/// <param name="jobStatus">stato del job o null per tutti gli stati</param>
		public void Canc(string jobType, string jobPkIdUser, JobStatus? jobStatus)
		{
			if (jobStatus.HasValue)
			{
				LinkedList<JobStatus> ok = new LinkedList<JobStatus>(new JobStatus[] { JobStatus.ERR, JobStatus.END, JobStatus.ABAK, JobStatus.SOSP });
				Debug.Assert(ok.Contains(jobStatus.Value));
			}
			Debug.Assert(jobType != null || jobStatus != null);

			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.Canc(null, jobType, jobPkIdUser, jobStatus);

			}
			catch (Exception ex)
			{
				Log.Write("BLQueueJobs.Canc", ex);
				throw;
			}
		}
		/// <summary>
		/// Funzione che permette di mettere in stato canc il job in ingresso
		/// </summary>
		public void Canc(string jobId)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.Canc(jobId, null, null, null);

			}
			catch (Exception ex)
			{
				Log.Write("BLQueueJobs.Canc", ex);
				throw;
			}
		}


		public void Suspend(string jobId)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.Suspend(jobId);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.Suspend");

				throw new ApplicationException("Errore sospendendo il job", ex);
			}
		}

		public void Error(string jobId, string jobErrorMsg)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.Error(jobId, jobErrorMsg);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.Error");

				throw new ApplicationException("Errore nella scrittura dell'errore del job", ex);
			}
		}

		public void Resume(string jobId)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.Resume(jobId);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.Resume");

				throw new ApplicationException("Errore riavviando il job", ex);
			}
		}

		public void Progress(string jobId, JobStatus jobStatus, string jobProgrMsg, int? jobTotalSteps, int? jobCurrentStep, int? jobResRecordCount)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.Progress(jobId, jobStatus.ToString(), jobProgrMsg, jobTotalSteps, jobCurrentStep, jobResRecordCount);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.Progress");

				throw new ApplicationException("Errore cambiando aggiornando lo stato del job", ex);
			}
		}

		public void End(string jobId)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.End(jobId);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.End");

				throw new ApplicationException("Errore terminado il job", ex);
			}

		}

		private void Purge(object dummy)
		{
			try
			{
				IDalQueueJobs dal = DalProvider.DAL.CreateDalQueueJobs();
				dal.Purge();  // marca da cancellare

				// qui faccio il loop per trovare marcati da cancellare
				List<QueueJob> r = dal.GetCancJobs();
				foreach (QueueJob q in r)
				{
#if DEBUG
					//Console.WriteLine("Purge job={0} type={1}", q.Id, q.Type);
#endif
					IJobRunner jr = GetJobRunnerFromType(q.Type);
					if (jr == null)
						continue;

					try
					{
						// qui chiamo le BL derivate per cancellare
						jr.DeleteJob(q.Id);
					}
					catch (Exception ex)
					{
						Log.Write(ex, "BLQueueJobs.Purge");
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.Purge");

				throw new ApplicationException("Errore durante la ricerca dei job vecchi", ex);
			}

		}
		public bool GetNextToRun(out string jobId, out string jobArgs, out string jobType)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.GetNextToRun(out jobId, out jobArgs, out jobType);
				return jobId != null;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.GetNextToRun");

				throw new ApplicationException("Errore durante la ricerca del job da eseguire", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<QueueJob> GetRunningJobs(string sortColumns)
		{
			if (sortColumns.ToUpper().Contains("REFRESH"))
				sortColumns = "";

			if (string.IsNullOrEmpty(sortColumns))
				sortColumns = "QJTSQueue";

			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				List<QueueJob> retBase = t.GetRunningJobs(sortColumns);

				List<QueueJob> retDerived = new List<QueueJob>();
				foreach (QueueJob qjBase in retBase)
				{
					IJobRunner jr = GetJobRunnerFromType(qjBase.Type);

					QueueJob qjDerived = CreateDerivedQueueJob(qjBase, jr);

					retDerived.Add(qjDerived);
				}

				return retDerived;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.GetRunningJobs");

				throw new ApplicationException("Errore durante la lettura dei job attivi", ex);
			}
		}

		private static QueueJob CreateDerivedQueueJob(QueueJob qjBase, IJobRunner jr)
		{
			// chiamo jr per vedere se il batch mi ritorna una classe derivata da QueueJob
			// e con qualche caratteristica ulteriore oltre alla ridefinizione di JobArgsHtml
			QueueJob qjDerived = jr.GetJobData(qjBase);
			if (qjDerived == null)
			{
				// chiamo il job per vedere se ha derivato una classe da QueueJob
				// solo per ridefinire JobArgsHtml
				Type qjDerivedType = jr.GetQueueJobType();
				if (qjDerivedType != null)
				{
					// qui creo la classe derivata e faccio valorizzo anche _argsData.
					qjDerived = qjBase.CreateDerivedQueueJob(qjDerivedType, jr.GetJobArgsType());
				}
			}
			if (qjDerived == null)
				return qjBase; // mi basta la classe base

			return qjDerived;
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public QueueJob GetRunningJobData(string jobId)
		{
			try
			{
				// prima leggo SOLO il record in QJOBS
				// ossia leggo il record base.
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				QueueJob qjBase = t.GetRunningJobData(jobId);

				// poi, in funzione del tipo qj.Type, leggo il QueueJob derivato
				// invocando la GetJobData
				IJobRunner jr = GetJobRunnerFromType(qjBase.Type);

				return CreateDerivedQueueJob(qjBase, jr);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.GetRunningJobData");

				throw new ApplicationException("Errore durante la lettura del job", ex);
			}
		}


		//public bool CheckStatus(string currentStatus, string newStatus)
		//{
		//    //stati QUEUE, RUN, SOSP, ERR, RRES, END, ABRQ, ABAK, CANC
		//    //QUEUE job in coda
		//    //RUN   job in esecuzione
		//    //SOSP  job sospeso
		//    //ERR   job terminato con eccezione
		//    //RRES  job in run che ha prodotto risultati intermedi
		//    //END   job terminato con successo
		//    //ABRQ  job con richiesta di abort in corso
		//    //ABAK  job che ha accettato la richiesta di abort
		//    //CANC  job da cancellare perche` scaduto (sysdate - QJLASTRESACCESS > QJRESTIMEOUTSEC)

		//    switch (currentStatus)
		//    {
		//    case "QUEUE":
		//        if (newStatus == "SOSP") return true;
		//        if (newStatus == "RUN") return true;
		//        if (newStatus == "ABRQ") return true;
		//        return false;

		//    case "RUN":
		//        if (newStatus == "ERR") return true;
		//        if (newStatus == "RRES") return true;
		//        if (newStatus == "ABRQ") return true;
		//        if (newStatus == "END") return true;
		//        return false;

		//    case "SOSP":
		//        if (newStatus == "QUEUE") return true;
		//        return false;

		//    case "ERR":
		//        return false;

		//    case "RRES":
		//        if (newStatus == currentStatus) return true;
		//        if (newStatus == "ERR") return true;
		//        if (newStatus == "ABRQ") return true;
		//        if (newStatus == "END") return true;
		//        return false;

		//    case "END":
		//        return false;

		//    case "ABRQ":
		//        if (newStatus == "ABAK") return true;
		//        return false;

		//    case "ABAK":
		//        return false;

		//    case "CANC":
		//        return false;

		//    default:
		//        throw new ArgumentException("valore non contemplato", "currentStatus");
		//    }
		//}


		public JobStatus GetStatus(string jobId)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				string status = t.GetStatus(jobId);
				return (JobStatus)Enum.Parse(typeof(JobStatus), status);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.GetStatus");

				throw new ApplicationException("Errore reggendo lo stato del job", ex);
			}
		}

		public int? GetResRecordCount(string jobId)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				return t.GetResRecordCount(jobId);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.GetResRecordCount");

				throw new ApplicationException("Errore reggendo il numero di record prodotti dal job", ex);
			}
		}

		public enum JobStatus
		{
			/// <summary>
			/// job accodato
			/// </summary>
			QUEUE,
			/// <summary>
			/// job in esecuzione
			/// </summary>
			RUN,
			/// <summary>
			/// job sospeso
			/// </summary>
			SOSP,
			/// <summary>
			/// job terminato con errore
			/// </summary>
			ERR,
			/// <summary>
			/// job in esecuzione con risultati parziali
			/// </summary>
			RRES,
			/// <summary>
			/// job terminato con successo
			/// </summary>
			END,
			/// <summary>
			/// richiesta di abort del job
			/// </summary>
			ABRQ,
			/// <summary>
			/// il job ha accettato la richiesta di abort
			/// </summary>
			ABAK,
			/// <summary>
			/// job da cancellare 
			/// </summary>
			CANC,
		}


		public List<QueueJobType> GetJobTypes()
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				return t.GetJobTypes();
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.GetJobTypes");

				throw new ApplicationException("Errore leggendo GetJobTypes", ex);
			}
		}

		public void SaveJobTypes(QueueJobType qt)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.SaveJobTypes(qt);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.SaveJobTypes");

				throw new ApplicationException("Errore salvando SaveJobTypes", ex);
			}
		}
		public void SaveJobTypes(List<QueueJobType> qt)
		{
			try
			{
				IDalQueueJobs t = DalProvider.DAL.CreateDalQueueJobs();
				t.SaveJobTypes(qt);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLQueueJobs.SaveJobTypes");

				throw new ApplicationException("Errore salvando SaveJobTypes", ex);
			}
		}

	}

	public interface IJobRunner
	{
		/// <summary>
		/// Metodo che esegue il job nel server.
		/// </summary>
		/// <param name="jobId"></param>
		/// <param name="jobArgs"></param>
		void ExecuteJob(string jobId, object jobArgs);

		/// <summary>
		/// Stringa che identifica il tipo del job.
		/// </summary>
		string JobType { get; }

		/// <summary>
		/// Metodo che ritorna il tipo della classe utilizzata per memorizzare gli argomenti
		/// del job.
		/// </summary>
		/// <returns></returns>
		Type GetJobArgsType();

		/// <summary>
		/// Metodo che ritorna il tipo della classe derivata da QueueJob, quando questa
		/// e` derivata dal batch.
		/// Il metodo puo` ritornare anche "null" se non deriva la classe QueueJob.
		/// </summary>
		/// <returns></returns>
		Type GetQueueJobType();

		void DeleteJob(string jobId);

		/// <summary>
		/// Metodo da implementare quando il job deve ritornare una classe QueueJob derivata
		/// con campi aggiuntivi rispetto alla QueueJob.
		/// Se il job deve implementare una classe QueueJob derivata per il solo motivo di 
		/// implementare il metodo JobArgsHtml questo metodo deve ritornare null.
		/// Se il job non implementa una classe derivata da QueueJob questo metodo deve ritornare null.
		/// Se il job implementa una classe derivata da QueueJob con altre caratteristiche oltre a riderivare 
		/// JobArgsHtml allora il metodo ritorna la classe derivata.
		/// </summary>
		/// <param name="baseQueueJobData">la classe base da riderivare</param>
		/// <returns>la classe derivata o null</returns>
		QueueJob GetJobData(QueueJob baseQueueJobData);
	}


	[Serializable]
	public class QueueJob
	{
		#region fields
		private string QJID;
		private string QJTYPE;
		private string QJPRIORITY;
		private string QJARGS;
		private string QJPKIDUSER;
		private BLQueueJobs.JobStatus QJSTATUS;
		private DateTime QJTSQUEUE;
		private DateTime? QJTSRUN;
		private DateTime? QJTSLAST;
		private string QJERRMSG;
		private string QJPROGRMSG;
		private int? QJTOTALSTEPS;
		private int? QJCURRENTSTEP;
		private byte[] QJRESULT;
		private DateTime? QJLASTRESACCESS;
		private int? QJRESRECORDCOUNT;
		private string QJUSERNAME;
		#endregion

		public string Id { get { return QJID; } set { QJID = value; } }
		public string Type { get { return QJTYPE; } set { QJTYPE = value; } }
		public string Priority { get { return QJPRIORITY; } set { QJPRIORITY = value; } }
		public string Args { get { return QJARGS; } set { QJARGS = value; } }
		public string PkIdUser { get { return QJPKIDUSER; } set { QJPKIDUSER = value; } }
		public string UserName { get { return QJUSERNAME; } set { QJUSERNAME = value; } }
		public BLQueueJobs.JobStatus Status { get { return QJSTATUS; } set { QJSTATUS = value; } }
		public DateTime TsQueue { get { return QJTSQUEUE; } set { QJTSQUEUE = value; } }
		public DateTime? TsRun { get { return QJTSRUN; } set { QJTSRUN = value; } }
		public DateTime? TsLast { get { return QJTSLAST; } set { QJTSLAST = value; } }
		public string ErrorMessage { get { return QJERRMSG; } set { QJERRMSG = value; } }
		public string ProgressMessage { get { return QJPROGRMSG; } set { QJPROGRMSG = value; } }
		public int? TotalSteps { get { return QJTOTALSTEPS; } set { QJTOTALSTEPS = value; } }
		public int? CurrentStep { get { return QJCURRENTSTEP; } set { QJCURRENTSTEP = value; } }
		public byte[] Result { get { return QJRESULT; } set { QJRESULT = value; } }
		public DateTime? TsLastAccess { get { return QJLASTRESACCESS; } set { QJLASTRESACCESS = value; } }
		public int? ResRecordCount { get { return QJRESRECORDCOUNT; } set { QJRESRECORDCOUNT = value; } }
		public string JobArgsHtml { get { return GetJobArgsHtml(); } }
		protected virtual string GetJobArgsHtml() { return ""; }
		/// <summary>
		/// Crea una classe derivata da QueueJob, copia tutti i campi e valorizza <c>_argsData</c>
		/// partendo dall'istanza <c>this</c>.
		/// </summary>
		/// <param name="q"></param>
		/// <param name="t"></param>
		public QueueJob CreateDerivedQueueJob(Type queueJobDerived, Type argsType)
		{
			Debug.Assert(queueJobDerived != null);
			Debug.Assert(typeof(QueueJob).IsAssignableFrom(queueJobDerived), "GetQueueJobType ritorna un tipo non derivato da QueueJob");

			QueueJob target = this;
			if (queueJobDerived != typeof(QueueJob))
			{
				// creo la classe derivata
				target = (QueueJob)Activator.CreateInstance(queueJobDerived);

				// e con un funambolismo copio tutti i campi
				object[] idx = new object[0];
				PropertyInfo[] pl = typeof(QueueJob).GetProperties(BindingFlags.Public | BindingFlags.Instance);
				foreach (PropertyInfo p in pl)
				{
					if (p.CanWrite)
					{
						object v = p.GetValue(this, idx);
						p.SetValue(target, v, idx);
					}
				}
			}

			// valorizzo partendo dagli argomenti in xml, l'oggetto degli argomenti.
			target._argsData = null;
			if (true)
			{
				XmlSerializerFactory f = new XmlSerializerFactory();
				XmlSerializer xs = f.CreateSerializer(argsType);
				target._argsData = xs.Deserialize(new StringReader(this.Args));
			}

			return target;
		}

		public void DeserializeArgs(Type argsType)
		{
			XmlSerializerFactory f = new XmlSerializerFactory();
			XmlSerializer xs = f.CreateSerializer(argsType);
			_argsData = xs.Deserialize(new StringReader(this.Args));
		}

		protected object _argsData = null;
	}

	[Serializable]
	public class QueueJobType
	{
		public String QJTYPE { get { return _QJTYPE; } set { _QJTYPE = value; } }
		public Int32 QJMAXRUNNING { get { return _QJMAXRUNNING; } set { _QJMAXRUNNING = value; } }
		public String QJPRIORITY { get { return _QJPRIORITY; } set { _QJPRIORITY = value; } }
		public String QJDESCR { get { return _QJDESCR; } set { _QJDESCR = value; } }
		public Int32 QJRUNTIMEOUTSEC { get { return _QJRUNTIMEOUTSEC; } set { _QJRUNTIMEOUTSEC = value; } }
		public Int32 QJQUEUETIMEOUTSEC { get { return _QJQUEUETIMEOUTSEC; } set { _QJQUEUETIMEOUTSEC = value; } }
		public Int32 QJRESTIMEOUTSEC { get { return _QJRESTIMEOUTSEC; } set { _QJRESTIMEOUTSEC = value; } }
		#region dati
		protected String _QJTYPE;
		protected Int32 _QJMAXRUNNING;
		protected String _QJPRIORITY;
		protected String _QJDESCR;
		protected Int32 _QJRUNTIMEOUTSEC;
		protected Int32 _QJQUEUETIMEOUTSEC;
		protected Int32 _QJRESTIMEOUTSEC;
		#endregion
	}
}
