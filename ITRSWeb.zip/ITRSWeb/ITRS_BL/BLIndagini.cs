using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.Serialization;
using System.IO;
using System.Threading;
using ITRS_BL.IDal;

namespace ITRS_BL
{
	[DataObjectAttribute]
	public partial class BLIndagini : Component, IJobRunner
	{
		public BLIndagini()
		{
			InitializeComponent();
		}

		public BLIndagini(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		[Serializable]
		public class JobArgs
		{
			public bool VoglioTransiti;
			public string Targa;
			public string Nazionalita;
			public DateTime DataInizio;
			public DateTime DataFine;
			public int? IdC2P;
			public int? IdCoa;
			public string DescrizioneC2P;
			public TipoEvento? TipoEvento;
		}

		public string StartIndagine(JobArgs sd, string jobUser)
		{
			BLQueueJobs bl = new BLQueueJobs();
			return bl.Create(this.JobType, sd, jobUser);
		}

		#region IJobRunner Members
		void IJobRunner.ExecuteJob(string jobId, object jobArgs) { this.ExecuteIndagine(jobId, (JobArgs)jobArgs); }
		public string JobType { get { return "INDAGINI"; } }
		public Type GetJobArgsType() { return typeof(JobArgs); }
		public Type GetQueueJobType() { return typeof(IndaginiQueueJob); }
		public QueueJob GetJobData(QueueJob baseQueueJobData) { return null; }
		void IJobRunner.DeleteJob(string jobId)
		{
			IDalIndagini dal = DalProvider.DAL.CreateDalIndagini();
			dal.CancellaIndagine(jobId);
		}

		#endregion


		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<ResultQueryIndagineTransito> GetResultJobIndagineTransiti(string jobId, string sortColumns, int startRowIndex, int maximumRows)
		{
			return GetResultJobIndagineTransiti(jobId, sortColumns, false, startRowIndex, maximumRows);
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public ResultQueryIndagineTransito GetResultJobIndagineTransiti(string jobId, string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			IDalIndagini dal = DalProvider.DAL.CreateDalIndagini();
			ResultQueryIndagineTransito r = dal.GetResultJobIndagineTransiti(jobId, targa, nazionalita, dataOraRilevamento);
			return r;
		}

		
		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<ResultQueryIndagineTransito> GetResultJobIndagineTransiti(string jobId, string sortColumns, bool includiImmagini, int startRowIndex, int maximumRows)
		{
			// aggiorno l'accesso ai dati di questo job.
			using (BLQueueJobs blq = new BLQueueJobs())
			{
				blq.Access(jobId);
			}

			if (string.IsNullOrEmpty(sortColumns))
				sortColumns = "DATAORARILEVAMENTO";
			IDalIndagini dal = DalProvider.DAL.CreateDalIndagini();
			List<ResultQueryIndagineTransito> r = dal.GetResultJobIndagineTransiti(jobId, sortColumns, includiImmagini, startRowIndex, maximumRows);
			return r;
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public int GetResultJobIndagineCount(string jobId)
		{
			BLQueueJobs bl = new BLQueueJobs();
			int? r = bl.GetResRecordCount(jobId);
			if (r.HasValue)
				return r.Value;
			return 0; // ritorno 0 per dire che non ci sono record
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<ResultQueryIndagineEvento> GetResultJobIndagineEventi(string jobId, string sortColumns, int startRowIndex, int maximumRows)
		{
			// aggiorno l'accesso ai dati di questo job.
			using (BLQueueJobs blq = new BLQueueJobs())
			{
				blq.Access(jobId);
			}

			if (string.IsNullOrEmpty(sortColumns))
				sortColumns = "DATAULTIMOTRANSITO";
			IDalIndagini dal = DalProvider.DAL.CreateDalIndagini();
			List<ResultQueryIndagineEvento> r = dal.GetResultJobIndagineEventi(jobId, sortColumns, startRowIndex, maximumRows);
			return r;
		}

		//[DataObjectMethod(DataObjectMethodType.Select)]
		public IndaginiQueueJob GetJobData(string jobId)
		{
			BLQueueJobs bl = new BLQueueJobs();
			QueueJob q = bl.GetRunningJobData(jobId);
			IndaginiQueueJob jq = (IndaginiQueueJob)q;
			return jq;
		}

		private void ExecuteIndagine(string jobId, JobArgs jobArgs)
		{
			BLQueueJobs bl = new BLQueueJobs();
			int totalSteps = 0;
			int currentStep = 0;

			int DaysStep = ReadAppSettings.ToInt32("BL_Indagini_DaysStep", 7);
			TimeSpan ts = new TimeSpan(DaysStep, 0, 0, 0);

			System.Globalization.CultureInfo it = new System.Globalization.CultureInfo("it-it");

			try
			{
				DateTime di = jobArgs.DataInizio;
				DateTime df = jobArgs.DataFine.AddSeconds(1); // l'operatore intende estremi inclusi. Noi no

				// determino il numero di passi necessari per la query
				{
					DateTime af = df; // af = valore finale dello step
					DateTime ai = df.Subtract(ts); // ai valore iniziale dello step.

					// determino il numero di step
					while (af > di)
					{
						totalSteps++;
						af = ai;
						ai = ai.Subtract(ts);
					}
				}
				DateTime tf = df;
				DateTime ti = df.Subtract(ts);


				BLQueueJobs.JobStatus status = BLQueueJobs.JobStatus.RUN;
				IDalIndagini dal = DalProvider.DAL.CreateDalIndagini();

				int recordFound = 0;
				int MaxRec = 0;
				while (tf > di)
				{
					if (tf > df) tf = df;
					if (ti < di) ti = di;

					Thread.Sleep(ReadAppSettings.ToInt32("BL_Indagini.Wait", 100));

					status = bl.GetStatus(jobId);
					if (status == BLQueueJobs.JobStatus.ABRQ)
					{
						bl.Progress(jobId, BLQueueJobs.JobStatus.ABAK, null, null, null, null);
						break;
					}

					DateTime tsFineDaPresentare;
					if (tf == df)
						tsFineDaPresentare = df.AddSeconds(-1);
					else
						tsFineDaPresentare = tf;

					string msg;
					if (jobArgs.VoglioTransiti)
						msg = string.Format("Ricerca transiti dal {0} al {1} in corso.", ti.ToString("G", it), tsFineDaPresentare.ToString("G", it));
					else
						msg = string.Format("Ricerca eventi dal {0} al {1} in corso.", ti.ToString("G", it), tsFineDaPresentare.ToString("G", it));
					if (recordFound > 0)
						msg += string.Format(" Record trovati {0}", recordFound);

					if (currentStep == 0)
						bl.Progress(jobId, BLQueueJobs.JobStatus.RUN, msg, totalSteps, currentStep, null);
					else
						bl.Progress(jobId, BLQueueJobs.JobStatus.RRES, msg, totalSteps, currentStep, null);

					if (jobArgs.VoglioTransiti)
						recordFound += dal.QueryPerIndagineTransiti(jobId, jobArgs.Targa, jobArgs.Nazionalita, ti, tf, jobArgs.IdC2P, jobArgs.IdCoa, ref MaxRec);
					else
						recordFound += dal.QueryPerIndagineEventi(jobId, jobArgs.Targa, jobArgs.Nazionalita, ti, tf, jobArgs.IdC2P, jobArgs.IdCoa, jobArgs.TipoEvento, ref MaxRec);

					if (recordFound > 0)
						bl.Progress(jobId, BLQueueJobs.JobStatus.RRES, null, null, null, recordFound);

					if (recordFound >= MaxRec)
						break;


					tf = ti;
					ti = ti.Subtract(ts);
					currentStep++;
				}

				string msg2;
				if (recordFound >= MaxRec)
				{
					if (jobArgs.VoglioTransiti)
						msg2 = string.Format("La ricerca ha individuato troppi transiti (transiti trovati:{0} Max:{1}). Utilizzare criteri piu' selettivi.", recordFound, MaxRec);
					else
						msg2 = string.Format("La ricerca ha individuato troppi eventi  (eventi trovati:{0} Max:{1}). Utilizzare criteri piu' selettivi.", recordFound, MaxRec);
					bl.Progress(jobId, BLQueueJobs.JobStatus.ERR, msg2, null, null, null);
				}
				else
				{
					if (jobArgs.VoglioTransiti)
						msg2 = string.Format("Ricerca transiti terminata. Trovati {0} transiti.", recordFound);
					else
						msg2 = string.Format("Ricerca eventi terminata. Trovati {0} eventi.", recordFound);
					bl.Progress(jobId, BLQueueJobs.JobStatus.END, msg2, null, null, null);
				}
			}
			catch
			{
				if (jobArgs.VoglioTransiti)
					bl.Progress(jobId, BLQueueJobs.JobStatus.ERR, "Ricerca transiti terminata con errore.", null, null, null);
				else
					bl.Progress(jobId, BLQueueJobs.JobStatus.ERR, "Ricerca eventi terminata con errore.", null, null, null);
				throw;
			}
		}

	}
	[Serializable]
	public class IndaginiQueueJob : QueueJob
	{
		public BLIndagini.JobArgs JobArgs
		{
			get
			{
				return (BLIndagini.JobArgs)base._argsData;
			}
		}

		protected override string GetJobArgsHtml()
		{
			string g = "";
			g += "<table>";
			g += "<tr><td>Targa:</td><td>{0}</td></tr>";
			g += "<tr><td>Nazionalit&agrave;:</td><td>{1}</td></tr>";
			g += "<tr><td>DataInizio:</td><td>{2}</td></tr>";
			g += "<tr><td>DataFine:</td><td>{3}</td></tr>";
			g += "<tr><td>VoglioTransiti:</td><td>{4}</td></tr>";
			g += "<tr><td>DescrizioneC2P:</td><td>{5}</td></tr>";
			g += "<tr><td>IdC2P:</td><td>{6}</td></tr>";
			g += "<tr><td>TipoEvento:</td><td>{7}</td></tr>";
			g += "</table>";

			g = string.Format(g,
				JobArgs.Targa,
				JobArgs.Nazionalita == null ? "" : JobArgs.Nazionalita,
				JobArgs.DataInizio.ToString("G"),
				JobArgs.DataFine.ToString("G"),
				JobArgs.VoglioTransiti.ToString(),
				JobArgs.DescrizioneC2P,
				JobArgs.IdC2P.HasValue ? JobArgs.IdC2P.Value.ToString() : "",
				JobArgs.TipoEvento.HasValue ? JobArgs.TipoEvento.Value.ToString() : "");

			return g;
		}
	}
	/// <summary>
	/// Risultato della query sui transiti fatta nel job
	/// </summary>
	[Serializable]
	public class ResultQueryIndagineTransito
	{
		private string _JobId;
		public string QJID
		{
			get { return _JobId; }
			set { _JobId = value; }
		}

		private string _Targa;
		public string Targa
		{
			get { return _Targa; }
			set { _Targa = value; }
		}

		private string _Nazionalita;
		public string Nazionalita
		{
			get { return _Nazionalita; }
			set { _Nazionalita = value; }
		}


		private DateTime _DataOraRilevamento;
		public DateTime DataOraRilevamento
		{
			get { return _DataOraRilevamento; }
			set { _DataOraRilevamento = value; }
		}

		private string _C2pDescrizione;
		public string C2p_Descrizione
		{
			get { return _C2pDescrizione; }
			set { _C2pDescrizione = value; }
		}

		private Direzione _Direzione;
		public Direzione C2p_Direzione
		{
			get { return _Direzione; }
			set { _Direzione = value; }
		}

		private TipoVarco _TipoVarco;
		public TipoVarco EnumTipoVarco
		{
			get { return _TipoVarco; }
			set { _TipoVarco = value; }
		}

		private StatoTransito _StatoTransito;
		public StatoTransito EnumStatoTransito
		{
			get { return _StatoTransito; }
			set { _StatoTransito = value; }
		}

		private long _ProgressivoQuery;
		public long ProgressivoQuery
		{
			get { return _ProgressivoQuery; }
			set { _ProgressivoQuery = value; }
		}

		private string _TargaAcquisita;
		public string TargaAcquisita
		{
			get { return _TargaAcquisita; }
			set { _TargaAcquisita = value; }
		}

		private string _NazionalitaAcquisita;
		public string NazionalitaAcquisita
		{
			get { return _NazionalitaAcquisita; }
			set { _NazionalitaAcquisita = value; }
		}

		private byte[] _Immagine;
		public byte [] Immagine
		{
			get { return _Immagine; }
			set { _Immagine = value; }
		}
	}
	/// <summary>
	/// Risultato della query sugli eventi fatta nel job
	/// </summary>
	[Serializable]
	public class ResultQueryIndagineEvento
	{
		private string _JobId;
		public string QJID
		{
			get { return _JobId; }
			set { _JobId = value; }
		}

		private string _Targa;
		public string Targa
		{
			get { return _Targa; }
			set { _Targa = value; }
		}

		private string _Nazionalita;
		public string Nazionalita
		{
			get { return _Nazionalita; }
			set { _Nazionalita = value; }
		}

		private DateTime _DataOraInserimento;
		public DateTime DataOraInserimento
		{
			get { return _DataOraInserimento; }
			set { _DataOraInserimento = value; }
		}

		private long _IdEvento;
		public long IdEvento
		{
			get { return _IdEvento; }
			set { _IdEvento = value; }
		}

		private TipoEvento _TipoEvento;
		public TipoEvento EnumTipoEvento
		{
			get { return _TipoEvento; }
			set { _TipoEvento = value; }
		}

		private StatoAllarme _StatoAllarme;
		public StatoAllarme EnumStatoAllarme
		{
			get { return _StatoAllarme; }
			set { _StatoAllarme = value; }
		}

		private string _UtentePresaInCarico;
		public string UtentePresaInCarico
		{
			get { return _UtentePresaInCarico; }
			set { _UtentePresaInCarico = value; }
		}

		private DateTime? _DataOraPresaInCarico;
		public DateTime? DataOraPresaInCarico
		{
			get { return _DataOraPresaInCarico; }
			set { _DataOraPresaInCarico = value; }
		}

		private DateTime? _DataOraChiusura;
		public DateTime? DataOraChiusura
		{
			get { return _DataOraChiusura; }
			set { _DataOraChiusura = value; }
		}

		private string _NoteChiusura;
		public string NoteChiusura
		{
			get { return _NoteChiusura; }
			set { _NoteChiusura = value; }
		}

		private string _COADiCompetenza;
		public string COADiCompetenza
		{
			get { return _COADiCompetenza; }
			set { _COADiCompetenza = value; }
		}

		private ClasseUrgenza _ClasseDiUrgenza;
		public ClasseUrgenza ClasseDiUrgenza
		{
			get { return _ClasseDiUrgenza; }
			set { _ClasseDiUrgenza = value; }
		}

		private DateTime _DataUltimoTransito;
		public DateTime DataUltimoTransito
		{
			get { return _DataUltimoTransito; }
			set { _DataUltimoTransito = value; }
		}

		private long _ProgressivoQuery;
		public long ProgressivoQuery
		{
			get { return _ProgressivoQuery; }
			set { _ProgressivoQuery = value; }
		}
	}
}
