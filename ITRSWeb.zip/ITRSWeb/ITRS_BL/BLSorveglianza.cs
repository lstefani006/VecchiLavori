using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.Serialization;
using System.IO;
using ITRS_BL.IDal;

namespace ITRS_BL
{
	[DataObjectAttribute]
	public partial class BLSorveglianza : Component
	{
		public BLSorveglianza()
		{
			InitializeComponent();
		}

		public BLSorveglianza(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public enum SorvTipoLTS
		{
			Tutti, noA2
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<TransitoSegnalatoSorveglianza> GetListaSorveglianza(int idCOA, BLSorveglianza.SorvTipoLTS tipoSorv)
		{
			IDalSorveglianza dal = DalProvider.DAL.CreateDalSorveglianza();
			List<TransitoSegnalatoSorveglianza> r = dal.GetListaSorveglianza(idCOA, tipoSorv);
			return r;
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public DatiTransitoSegnalatoSuMessaggioMWP GetDatiPerTransitoSegnalazioneSuMessaggioMWP(string Targa, string Nazionalita, DateTime DataOraRilevamento)
		{
			IDalSorveglianza dal = DalProvider.DAL.CreateDalSorveglianza();
			DatiTransitoSegnalatoSuMessaggioMWP r = dal.GetDatiPerTransitoSegnalazioneSuMessaggioMWP(Targa, Nazionalita, DataOraRilevamento);
			return r;
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public byte[] GetMapSorveglianza(int idCoa, string Targa, string Nazionalita, DateTime DataOraRilevamento)
		{
			IDalSorveglianza dal = DalProvider.DAL.CreateDalSorveglianza();
			byte[] r = dal.GetMapSorveglianza(idCoa, Targa, Nazionalita, DataOraRilevamento);
			return r;
		}


		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato> GetListaSorveglianzaPaginata(string sortColumns, int startRowIndex, int maximumRows, int idCoa, string tipoSorv)
		{
			try
			{
				SorvTipoLTS sorvTipoLTS = (SorvTipoLTS)Enum.Parse(typeof(SorvTipoLTS), tipoSorv);

				IDalSorveglianza dal = DalProvider.DAL.CreateDalSorveglianza();
				return dal.GetListaSorveglianzaPaginata(sortColumns, startRowIndex, maximumRows, idCoa, sorvTipoLTS);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLSorveglianza.GetListaSorveglianzaPaginata");
				throw;
			}
		}
		public int GetListaSorveglianzaPaginataCount(int idCoa, string tipoSorv)
		{
			try
			{
				SorvTipoLTS sorvTipoLTS = (SorvTipoLTS)Enum.Parse(typeof(SorvTipoLTS), tipoSorv);

				IDalSorveglianza dal = DalProvider.DAL.CreateDalSorveglianza();
				return dal.GetListaSorveglianzaPaginataCount(idCoa, sorvTipoLTS);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BLSorveglianza.GetListaSorveglianzaPaginataCount");
				throw;
			}
		}

		public void AccodaEvento(
			 string p_TARGA,
			 string p_NAZIONALITA,
			 DateTime p_DATAORAINSERIMENTO,
			 DateTime p_DATAORARILEVAMENTO,
			 Int64 p_IDEVENTO,
			 int p_IDCOA,
			 byte[] p_Img,

			DateTime? p_PrecEvDataOraInserimento,
			int? p_PrecEvIdEvento,
			DateTime? p_PrecTrDataOraRilevamento
			)
		{
			try
			{
				IDalSorveglianza dal = DalProvider.DAL.CreateDalSorveglianza();

				string p_EnumTipoLtsSegnalazione1 = null;
				string p_TipoVeicoloSegnalazione1 = null;
				string p_NoteSegnalazione1 = null;

				string p_EnumTipoLtsSegnalazione2 = null;
				string p_TipoVeicoloSegnalazione2 = null;
				string p_NoteSegnalazione2 = null;

				string p_EnumTipoLtsSegnalazione3 = null;
				string p_TipoVeicoloSegnalazione3 = null;
				string p_NoteSegnalazione3 = null;

				List<SegnalazioniAssociateAllEvento> sgn = dal.GetSegnalazioniAssociate(p_TARGA, p_NAZIONALITA, p_DATAORAINSERIMENTO);

				sgn.Sort(delegate(SegnalazioniAssociateAllEvento a, SegnalazioniAssociateAllEvento b)
					{
						int na;
						switch (a.EnumTipoLtsSegnalazione)
						{
						case "A1": na = 1; break;
						case "B":  na = 2; break;
						case "C":  na = 3; break;
						case "A2": na = 4; break;
						default: na = 0; break;
						}
						int nb;
						switch (b.EnumTipoLtsSegnalazione)
						{
						case "A1": nb = 1; break;
						case "B":  nb = 2; break;
						case "C":  nb = 3; break;
						case "A2": nb = 4; break;
						default: nb = 0; break;
						}

						return na.CompareTo(nb);
					});

				foreach (SegnalazioniAssociateAllEvento s in sgn)
				{
					if (p_EnumTipoLtsSegnalazione1 == null)
					{
						p_EnumTipoLtsSegnalazione1 = s.EnumTipoLtsSegnalazione;
						p_TipoVeicoloSegnalazione1 = s.TipoVeicoloSegnalazione;
						p_NoteSegnalazione1 = s.NoteSegnalazione;
					}
					else if (p_EnumTipoLtsSegnalazione2 == null)
					{
						p_EnumTipoLtsSegnalazione2 = s.EnumTipoLtsSegnalazione;
						p_TipoVeicoloSegnalazione2 = s.TipoVeicoloSegnalazione;
						p_NoteSegnalazione2 = s.NoteSegnalazione;
					}
					else if (p_EnumTipoLtsSegnalazione3 == null)
					{
						p_EnumTipoLtsSegnalazione3 = s.EnumTipoLtsSegnalazione;
						p_TipoVeicoloSegnalazione3 = s.TipoVeicoloSegnalazione;
						p_NoteSegnalazione3 = s.NoteSegnalazione;
					}
				}

				dal.AccodaEvento(p_TARGA, p_NAZIONALITA, p_DATAORAINSERIMENTO, p_DATAORARILEVAMENTO, p_IDEVENTO,
					p_IDCOA, p_Img,
					p_PrecEvDataOraInserimento, p_PrecEvIdEvento, p_PrecTrDataOraRilevamento,

					p_EnumTipoLtsSegnalazione1,
					p_TipoVeicoloSegnalazione1,
					p_NoteSegnalazione1,
					p_EnumTipoLtsSegnalazione2,
					p_TipoVeicoloSegnalazione2,
					p_NoteSegnalazione2,
					p_EnumTipoLtsSegnalazione3,
					p_TipoVeicoloSegnalazione3,
					p_NoteSegnalazione3
				);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "AccodaEvento");
				throw;
			}
		}


		public TransitoSegnalatoPrecedente GetTransitoSegnalatoPrecedente(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			try
			{
				IDalSorveglianza dal = DalProvider.DAL.CreateDalSorveglianza();
				return dal.GetTransitoSegnalatoPrecedente(targa, nazionalita, dataOraRilevamento);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetTransitoSegnalatoPrecedente");
				throw;
			}
		}

		public BLSorveglianza.StatisticaSorveglianza GetReportAllarmiTS(int idCoa, DateTime di, DateTime df)
		{
			try
			{
				IDalSorveglianza dal = DalProvider.DAL.CreateDalSorveglianza();
				return dal.GetReportAllarmiTS(idCoa, di, df);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetReportAllarmiTS");
				throw;
			}
		}


		[Serializable]
		public class TransitoSegnalatoSorveglianza
		{
			/*			public string EnumTipoLtsSegnalazione { get { return _EnumTipoLtsSegnalazione; } set { _EnumTipoLtsSegnalazione = value; } }
						public String TARGA { get { return _TARGA; } set { _TARGA = value; } }
						public String NAZIONALITA { get { return _NAZIONALITA; } set { _NAZIONALITA = value; } }
						public DateTime DATAORAINSERIMENTO { get { return _DATAORAINSERIMENTO; } set { _DATAORAINSERIMENTO = value; } }
						public Int64 IDEVENTO { get { return _IDEVENTO; } set { _IDEVENTO = value; } }
						public TipoEvento TIPOEVENTO { get { return _TIPOEVENTO; } set { _TIPOEVENTO = value; } }
						public StatoAllarme STATOALLARME { get { return _STATOALLARME; } set { _STATOALLARME = value; } }
						public String EVUTENTEPRESAINCARICO { get { return _EVUTENTEPRESAINCARICO; } set { _EVUTENTEPRESAINCARICO = value; } }
						public DateTime? EVDATAORAPRESAINCARICO { get { return _EVDATAORAPRESAINCARICO; } set { _EVDATAORAPRESAINCARICO = value; } }
						public DateTime? EVDATAORACHIUSURA { get { return _EVDATAORACHIUSURA; } set { _EVDATAORACHIUSURA = value; } }
						public String EVNOTECHIUSURA { get { return _EVNOTECHIUSURA; } set { _EVNOTECHIUSURA = value; } }
						public ClasseUrgenza ENUMCLASSEURGENZA { get { return _ENUMCLASSEURGENZA; } set { _ENUMCLASSEURGENZA = value; } }
						public TipoVarco ENUMTIPOVARCO { get { return _ENUMTIPOVARCO; } set { _ENUMTIPOVARCO = value; } }
						public DateTime DATAORARILEVAMENTO { get { return _DATAORARILEVAMENTO; } set { _DATAORARILEVAMENTO = value; } }
						public StatoTransito ENUMSTATOTRANSITO { get { return _ENUMSTATOTRANSITO; } set { _ENUMSTATOTRANSITO = value; } }
						public String TRUTENTEPRESAINCARICO { get { return _TRUTENTEPRESAINCARICO; } set { _TRUTENTEPRESAINCARICO = value; } }
						public DateTime? TRDATAORAPRESAINCARICO { get { return _TRDATAORAPRESAINCARICO; } set { _TRDATAORAPRESAINCARICO = value; } }
						public DateTime? TRDATAORACHIUSURA { get { return _TRDATAORACHIUSURA; } set { _TRDATAORACHIUSURA = value; } }
						public String TRNOTECHIUSURA { get { return _TRNOTECHIUSURA; } set { _TRNOTECHIUSURA = value; } }
						public Decimal TRLATITUDINE { get { return _TRLATITUDINE; } set { _TRLATITUDINE = value; } }
						public Decimal TRLONGITUDINE { get { return _TRLONGITUDINE; } set { _TRLONGITUDINE = value; } }
						public Direzione TRC2PDIREZIONE { get { return _TRC2PDIREZIONE; } set { _TRC2PDIREZIONE = value; } }
						public String TRC2PDESCRIZIONE { get { return _TRC2PDESCRIZIONE; } set { _TRC2PDESCRIZIONE = value; } }
						public String TRC2PSTRADA { get { return _TRC2PSTRADA; } set { _TRC2PSTRADA = value; } }
						public byte[] IMMAGINE { get { return _IMMAGINE; } set { _IMMAGINE = value; } }
						public int PROGRESSIVOQUERY { get { return _PROGRESSIVOQUERY; } set { _PROGRESSIVOQUERY = value; } }


						public string NoteSegnalazione1 { get { return _NoteSegnalazione1; } set { _NoteSegnalazione1 = value; } }
						public string TipoVeicoloSegnalazione1 { get { return _TipoVeicoloSegnalazione1; } set { _TipoVeicoloSegnalazione1 = value; } }
						public string EnumTipoLtsSegnalazione1 { get { return _EnumTipoLtsSegnalazione1; } set { _EnumTipoLtsSegnalazione1 = value; } }


						public int? PL_XSTART { get { return _PL_XSTART; } set { _PL_XSTART = value; } }
						public int? PL_YSTART { get { return _PL_YSTART; } set { _PL_YSTART = value; } }
						public int? PL_XEND { get { return _PL_XEND; } set { _PL_XEND = value; } }
						public int? PL_YEND { get { return _PL_YEND; } set { _PL_YEND = value; } }
						public string PL_NET_ID { get { return _PL_NET_ID; } set { _PL_NET_ID = value; } }
						public string PL_LAYOUT_ID { get { return _PL_LAYOUT_ID; } set { _PL_LAYOUT_ID = value; } }
						public string PL_VEHICLE_TYPE { get { return _PL_VEHICLE_TYPE; } set { _PL_VEHICLE_TYPE = value; } }
						public string PL_VEHICLE_ID { get { return _PL_VEHICLE_ID; } set { _PL_VEHICLE_ID = value; } }

						public DateTime? PrecTsEvDataOraInserimento { get { return _PrecTsEvDataOraInserimento; } set { _PrecTsEvDataOraInserimento = value; } }
						public int? PrecTsEvIdEvento { get { return _PrecTsEvIdEvento; } set { _PrecTsEvIdEvento = value; } }
						public StatoAllarme? PrecTsEvStatoAllarme { get { return _PrecTsEvStatoAllarme; } set { _PrecTsEvStatoAllarme = value; } }
						public string PrecTsEvNoteChiusura { get { return _PrecTsEvNoteChiusura; } set { _PrecTsEvNoteChiusura = value; } }


						public DateTime? PrecTsTrDataOraRilevamento { get { return _PrecTsTrDataOraRilevamento; } set { _PrecTsTrDataOraRilevamento = value; } }
						public StatoTransito? PrecTsTrStatoTransito { get { return _PrecTsTrStatoTransito; } set { _PrecTsTrStatoTransito = value; } }
						public string PrecTsTrC2PDescrizione { get { return _PrecTsTrC2PDescrizione; } set { _PrecTsTrC2PDescrizione = value; } }
						public Direzione? PrecTsTrC2PDirezione { get { return _PrecTsTrC2PDirezione; } set { _PrecTsTrC2PDirezione = value; } }
						public string PrecTsTrStrada { get { return _PrecTsTrStrada; } set { _PrecTsTrStrada = value; } }
						public TipoVarco? PrecTsTrTipoVarco { get { return _PrecTsTrTipoVarco; } set { _PrecTsTrTipoVarco = value; } }
						public string PresTsTrNoteChiusura { get { return _PresTsTrNoteChiusura; } set { _PresTsTrNoteChiusura = value; } }


						#region dati

						protected int _PROGRESSIVOQUERY;
						protected String _TARGA;
						protected String _NAZIONALITA;
						protected DateTime _DATAORAINSERIMENTO;
						protected Int64 _IDEVENTO;
						protected TipoEvento _TIPOEVENTO;
						protected StatoAllarme _STATOALLARME;
						protected String _EVUTENTEPRESAINCARICO;
						protected DateTime? _EVDATAORAPRESAINCARICO;
						protected DateTime? _EVDATAORACHIUSURA;
						protected String _EVNOTECHIUSURA;
						protected ClasseUrgenza _ENUMCLASSEURGENZA;
						protected TipoVarco _ENUMTIPOVARCO;
						protected DateTime _DATAORARILEVAMENTO;
						protected StatoTransito _ENUMSTATOTRANSITO;
						protected String _TRUTENTEPRESAINCARICO;
						protected DateTime? _TRDATAORAPRESAINCARICO;
						protected DateTime? _TRDATAORACHIUSURA;
						protected String _TRNOTECHIUSURA;
						protected Decimal _TRLATITUDINE;
						protected Decimal _TRLONGITUDINE;
						protected Direzione _TRC2PDIREZIONE;
						protected String _TRC2PDESCRIZIONE;
						protected String _TRC2PSTRADA;
						protected byte[] _IMMAGINE;
						string _NoteSegnalazione;
						string _TipoVeicoloSegnalazione;
						string _EnumTipoLtsSegnalazione;

						public int? _PL_XSTART;
						public int? _PL_YSTART;
						public int? _PL_XEND;
						public int? _PL_YEND;
						public string _PL_NET_ID;
						public string _PL_LAYOUT_ID;
						public string _PL_VEHICLE_TYPE;
						public string _PL_VEHICLE_ID;

						DateTime? _PrecTsEvDataOraInserimento;
						int? _PrecTsEvIdEvento;
						StatoAllarme? _PrecTsEvStatoAllarme;
						string _PrecTsEvNoteChiusura;
						private DateTime? _PrecTsTrDataOraRilevamento;
						private StatoTransito? _PrecTsTrStatoTransito;
						private string _PrecTsTrC2PDescrizione;
						private Direzione? _PrecTsTrC2PDirezione;
						private string _PrecTsTrStrada;
						private TipoVarco? _PrecTsTrTipoVarco;
						private string _PresTsTrNoteChiusura;


						#endregion
			*/
			public String NoteSegnalazione1 { get { return _NoteSegnalazione1; } set { _NoteSegnalazione1 = value; } }
			public String TipoVeicoloSegnalazione1 { get { return _TipoVeicoloSegnalazione1; } set { _TipoVeicoloSegnalazione1 = value; } }
			public String EnumTipoLtsSegnalazione1 { get { return _EnumTipoLtsSegnalazione1; } set { _EnumTipoLtsSegnalazione1 = value; } }
			public String NoteSegnalazione2 { get { return _NoteSegnalazione2; } set { _NoteSegnalazione2 = value; } }
			public String TipoVeicoloSegnalazione2 { get { return _TipoVeicoloSegnalazione2; } set { _TipoVeicoloSegnalazione2 = value; } }
			public String EnumTipoLtsSegnalazione2 { get { return _EnumTipoLtsSegnalazione2; } set { _EnumTipoLtsSegnalazione2 = value; } }
			public String NoteSegnalazione3 { get { return _NoteSegnalazione3; } set { _NoteSegnalazione3 = value; } }
			public String TipoVeicoloSegnalazione3 { get { return _TipoVeicoloSegnalazione3; } set { _TipoVeicoloSegnalazione3 = value; } }
			public String EnumTipoLtsSegnalazione3 { get { return _EnumTipoLtsSegnalazione3; } set { _EnumTipoLtsSegnalazione3 = value; } }
			public String Targa { get { return _Targa; } set { _Targa = value; } }
			public String Nazionalita { get { return _Nazionalita; } set { _Nazionalita = value; } }
			public Byte[] Immagine { get { return _Immagine; } set { _Immagine = value; } }
			public DateTime DataOraInserimento { get { return _DataOraInserimento; } set { _DataOraInserimento = value; } }
			public Int64 IdEvento { get { return _IdEvento; } set { _IdEvento = value; } }
			public TipoEvento TipoEvento { get { return _TipoEvento; } set { _TipoEvento = value; } }
			public StatoAllarme StatoAllarme { get { return _StatoAllarme; } set { _StatoAllarme = value; } }
			public String EvUtentePresaInCarico { get { return _EvUtentePresaInCarico; } set { _EvUtentePresaInCarico = value; } }
			public DateTime? EvDataOraPresaInCarico { get { return _EvDataOraPresaInCarico; } set { _EvDataOraPresaInCarico = value; } }
			public DateTime? EvDataOraChiusura { get { return _EvDataOraChiusura; } set { _EvDataOraChiusura = value; } }
			public String EvNoteChiusura { get { return _EvNoteChiusura; } set { _EvNoteChiusura = value; } }
			public ClasseUrgenza EnumClasseUrgenza { get { return _EnumClasseUrgenza; } set { _EnumClasseUrgenza = value; } }
			public TipoVarco EnumTipoVarco { get { return _EnumTipoVarco; } set { _EnumTipoVarco = value; } }
			public DateTime DataOraRilevamento { get { return _DataOraRilevamento; } set { _DataOraRilevamento = value; } }
			public StatoTransito EnumStatoTransito { get { return _EnumStatoTransito; } set { _EnumStatoTransito = value; } }
			public String TrUtentePresaInCarico { get { return _TrUtentePresaInCarico; } set { _TrUtentePresaInCarico = value; } }
			public DateTime? TrDataOraPresaInCarico { get { return _TrDataOraPresaInCarico; } set { _TrDataOraPresaInCarico = value; } }
			public DateTime? TrDataOraChiusura { get { return _TrDataOraChiusura; } set { _TrDataOraChiusura = value; } }
			public String TrNoteChiusura { get { return _TrNoteChiusura; } set { _TrNoteChiusura = value; } }
			public Decimal? TrLatitudine { get { return _TrLatitudine; } set { _TrLatitudine = value; } }
			public Decimal? TrLongitudine { get { return _TrLongitudine; } set { _TrLongitudine = value; } }
			public Direzione TrC2PDirezione { get { return _TrC2PDirezione; } set { _TrC2PDirezione = value; } }
			public String TrC2PDescrizione { get { return _TrC2PDescrizione; } set { _TrC2PDescrizione = value; } }
			public String TrC2pStrada { get { return _TrC2pStrada; } set { _TrC2pStrada = value; } }
			public Int32? PL_XSTART { get { return _PL_XSTART; } set { _PL_XSTART = value; } }
			public Int32? PL_YSTART { get { return _PL_YSTART; } set { _PL_YSTART = value; } }
			public Int32? PL_XEND { get { return _PL_XEND; } set { _PL_XEND = value; } }
			public Int32? PL_YEND { get { return _PL_YEND; } set { _PL_YEND = value; } }
			public String PL_NET_ID { get { return _PL_NET_ID; } set { _PL_NET_ID = value; } }
			public String PL_LAYOUT_ID { get { return _PL_LAYOUT_ID; } set { _PL_LAYOUT_ID = value; } }
			public String PL_VEHICLE_TYPE { get { return _PL_VEHICLE_TYPE; } set { _PL_VEHICLE_TYPE = value; } }
			public String PL_VEHICLE_ID { get { return _PL_VEHICLE_ID; } set { _PL_VEHICLE_ID = value; } }
			public DateTime? PrecTsEvDataOraInserimento { get { return _PrecTsEvDataOraInserimento; } set { _PrecTsEvDataOraInserimento = value; } }
			public Int64? PrecTsEvIdEvento { get { return _PrecTsEvIdEvento; } set { _PrecTsEvIdEvento = value; } }
			public StatoAllarme? PrecTsEvStatoAllarme { get { return _PrecTsEvStatoAllarme; } set { _PrecTsEvStatoAllarme = value; } }
			public String PrecTsEvNoteChiusura { get { return _PrecTsEvNoteChiusura; } set { _PrecTsEvNoteChiusura = value; } }
			public DateTime? PrecTsTrDataOraRilevamento { get { return _PrecTsTrDataOraRilevamento; } set { _PrecTsTrDataOraRilevamento = value; } }
			public StatoTransito? PrecTsTrStatoTransito { get { return _PrecTsTrStatoTransito; } set { _PrecTsTrStatoTransito = value; } }
			public String PrecTsTrC2PDescrizione { get { return _PrecTsTrC2PDescrizione; } set { _PrecTsTrC2PDescrizione = value; } }
			public Direzione? PrecTsTrC2PDirezione { get { return _PrecTsTrC2PDirezione; } set { _PrecTsTrC2PDirezione = value; } }
			public String PrecTsTrStrada { get { return _PrecTsTrStrada; } set { _PrecTsTrStrada = value; } }
			public TipoVarco? PrecTsTrTipoVarco { get { return _PrecTsTrTipoVarco; } set { _PrecTsTrTipoVarco = value; } }
			public String PresTsTrNoteChiusura { get { return _PresTsTrNoteChiusura; } set { _PresTsTrNoteChiusura = value; } }

			#region dati
			protected String _NoteSegnalazione1;
			protected String _TipoVeicoloSegnalazione1;
			protected String _EnumTipoLtsSegnalazione1;
			protected String _NoteSegnalazione2;
			protected String _TipoVeicoloSegnalazione2;
			protected String _EnumTipoLtsSegnalazione2;
			protected String _NoteSegnalazione3;
			protected String _TipoVeicoloSegnalazione3;
			protected String _EnumTipoLtsSegnalazione3;
			protected String _Targa;
			protected String _Nazionalita;
			protected Byte[] _Immagine;
			protected DateTime _DataOraInserimento;
			protected Int64 _IdEvento;
			protected TipoEvento _TipoEvento;
			protected StatoAllarme _StatoAllarme;
			protected String _EvUtentePresaInCarico;
			protected DateTime? _EvDataOraPresaInCarico;
			protected DateTime? _EvDataOraChiusura;
			protected String _EvNoteChiusura;
			protected ClasseUrgenza _EnumClasseUrgenza;
			protected TipoVarco _EnumTipoVarco;
			protected DateTime _DataOraRilevamento;
			protected StatoTransito _EnumStatoTransito;
			protected String _TrUtentePresaInCarico;
			protected DateTime? _TrDataOraPresaInCarico;
			protected DateTime? _TrDataOraChiusura;
			protected String _TrNoteChiusura;
			protected Decimal? _TrLatitudine;
			protected Decimal? _TrLongitudine;
			protected Direzione _TrC2PDirezione;
			protected String _TrC2PDescrizione;
			protected String _TrC2pStrada;
			protected Int32? _PL_XSTART;
			protected Int32? _PL_YSTART;
			protected Int32? _PL_XEND;
			protected Int32? _PL_YEND;
			protected String _PL_NET_ID;
			protected String _PL_LAYOUT_ID;
			protected String _PL_VEHICLE_TYPE;
			protected String _PL_VEHICLE_ID;
			protected DateTime? _PrecTsEvDataOraInserimento;
			protected Int64? _PrecTsEvIdEvento;
			protected StatoAllarme? _PrecTsEvStatoAllarme;
			protected String _PrecTsEvNoteChiusura;
			protected DateTime? _PrecTsTrDataOraRilevamento;
			protected StatoTransito? _PrecTsTrStatoTransito;
			protected String _PrecTsTrC2PDescrizione;
			protected Direzione? _PrecTsTrC2PDirezione;
			protected String _PrecTsTrStrada;
			protected TipoVarco? _PrecTsTrTipoVarco;
			protected String _PresTsTrNoteChiusura;
			#endregion
		}

		[Serializable]
		public class TransitoSegnalatoPrecedente
		{
			#region Dati
			TipoVarco _TrTipoVarco;
			StatoTransito _TrStatoTransito;
			string _TrC2P;
			string _TrC2pStrada;
			string _TrUserName;
			DateTime? _TrDataOraPresaInCarico;
			DateTime? _TrDataOraChiusura;
			string _TrNoteChiusura;
			StatoAllarme _EvStatoAllarme;
			string _EvUserName;
			DateTime? _EvDataOraPresaInCarico;
			string _EvNoteChiusura;
			DateTime? _EvDataOraChiusura;
			Direzione _TrC2PDirezione;
			DateTime _TrDataOraRilevamento;

			DateTime _EvDataOraInserimento;
			int _EvIdEvento;

			#endregion

			public DateTime TrDataOraRilevamento { get { return _TrDataOraRilevamento; } set { _TrDataOraRilevamento = value; } }
			public TipoVarco TrTipoVarco { get { return _TrTipoVarco; } set { _TrTipoVarco = value; } }
			public StatoTransito TrStatoTransito { get { return _TrStatoTransito; } set { _TrStatoTransito = value; } }
			public string TrC2P { get { return _TrC2P; } set { _TrC2P = value; } }
			public Direzione TrC2PDirezione { get { return _TrC2PDirezione; } set { _TrC2PDirezione = value; } }
			public string TrC2pStrada { get { return _TrC2pStrada; } set { _TrC2pStrada = value; } }
			public string TrUserName { get { return _TrUserName; } set { _TrUserName = value; } }
			public DateTime? TrDataOraPresaInCarico { get { return _TrDataOraPresaInCarico; } set { _TrDataOraPresaInCarico = value; } }
			public DateTime? TrDataOraChiusura { get { return _TrDataOraChiusura; } set { _TrDataOraChiusura = value; } }
			public string TrNoteChiusura { get { return _TrNoteChiusura; } set { _TrNoteChiusura = value; } }
			public StatoAllarme EvStatoAllarme { get { return _EvStatoAllarme; } set { _EvStatoAllarme = value; } }
			public string EvUserName { get { return _EvUserName; } set { _EvUserName = value; } }
			public DateTime? EvDataOraPresaInCarico { get { return _EvDataOraPresaInCarico; } set { _EvDataOraPresaInCarico = value; } }
			public DateTime? EvDataOraChiusura { get { return _EvDataOraChiusura; } set { _EvDataOraChiusura = value; } }
			public string EvNoteChiusura { get { return _EvNoteChiusura; } set { _EvNoteChiusura = value; } }

			public DateTime EvDataOraInserimento { get { return _EvDataOraInserimento; } set { _EvDataOraInserimento = value; } }
			public int EvIdEvento { get { return _EvIdEvento; } set { _EvIdEvento = value; } }
		}

		[Serializable]
		public class StatisticaSorveglianza
		{
			public int TotaleTransitiSegnalati { get { return _TotaleTransitiSegnalati; } set { _TotaleTransitiSegnalati = value; } }
			public int AllarmiPositivi { get { return _AllarmiPositivi; } set { _AllarmiPositivi = value; } }
			public int AllarmiNegativi { get { return _AllarmiNegativi; } set { _AllarmiNegativi = value; } }
			public int AllarmiTrattati { get { return _AllarmiTrattati; } set { _AllarmiTrattati = value; } }
			public int AllarmiNonTrattati { get { return _AllarmiNonTrattati; } set { _AllarmiNonTrattati = value; } }
			public int AllarmiChiusiDalSistema { get { return _AllarmiChiusiDalSistema; } set { _AllarmiChiusiDalSistema = value; } }

			int _TotaleTransitiSegnalati;
			int _AllarmiPositivi;
			int _AllarmiNegativi;
			int _AllarmiTrattati;
			int _AllarmiNonTrattati;
			int _AllarmiChiusiDalSistema;
		}

		[Serializable]
		public class DatiTransitoSegnalatoSuMessaggioMWP
		{
			public String Targa { get { return _Targa; } set { _Targa = value; } }
			public String Nazionalita { get { return _Nazionalita; } set { _Nazionalita = value; } }
			public DateTime EvDataOraInserimento { get { return _EvDataOraInserimento; } set { _EvDataOraInserimento = value; } }
			public Int64 EvIdEvento { get { return _EvIdEvento; } set { _EvIdEvento = value; } }
			public TipoEvento EvTipoEvento { get { return _EvTipoEvento; } set { _EvTipoEvento = value; } }
			public StatoAllarme EvStatoAllarme { get { return _EvStatoAllarme; } set { _EvStatoAllarme = value; } }
			public String EvUtentePresaInCarico { get { return _EvUtentePresaInCarico; } set { _EvUtentePresaInCarico = value; } }
			public DateTime? EvDataOraPresaInCarico { get { return _EvDataOraPresaInCarico; } set { _EvDataOraPresaInCarico = value; } }
			public DateTime? EvDataOraChiusura { get { return _EvDataOraChiusura; } set { _EvDataOraChiusura = value; } }
			public String EvNoteChiusura { get { return _EvNoteChiusura; } set { _EvNoteChiusura = value; } }
			public ClasseUrgenza EvClasseUrgenza { get { return _EvClasseUrgenza; } set { _EvClasseUrgenza = value; } }
			public TipoVarco TrTipoVarco { get { return _TrTipoVarco; } set { _TrTipoVarco = value; } }
			public DateTime TrDataOraRilevamento { get { return _TrDataOraRilevamento; } set { _TrDataOraRilevamento = value; } }
			public StatoTransito TrStatoTransito { get { return _TrStatoTransito; } set { _TrStatoTransito = value; } }
			public String TrUtentePresaInCarico { get { return _TrUtentePresaInCarico; } set { _TrUtentePresaInCarico = value; } }
			public DateTime? TrDataOraPresaInCarico { get { return _TrDataOraPresaInCarico; } set { _TrDataOraPresaInCarico = value; } }
			public DateTime? TrDataOraChiusura { get { return _TrDataOraChiusura; } set { _TrDataOraChiusura = value; } }
			public String TrNoteChiusura { get { return _TrNoteChiusura; } set { _TrNoteChiusura = value; } }
			public String TrPlateVehicleType { get { return _TrPlateVehicleType; } set { _TrPlateVehicleType = value; } }
			public Decimal? TrLatitudine { get { return _TrLatitudine; } set { _TrLatitudine = value; } }
			public Decimal? TrLongitudine { get { return _TrLongitudine; } set { _TrLongitudine = value; } }
			public Int16 TrIdC2P { get { return _TrIdC2P; } set { _TrIdC2P = value; } }
			public String TrC2PDirezione { get { return _TrC2PDirezione; } set { _TrC2PDirezione = value; } }
			public String TrC2PDescrizione { get { return _TrC2PDescrizione; } set { _TrC2PDescrizione = value; } }
			public String TrTipoVeicoloSegnalazione { get { return _TrTipoVeicoloSegnalazione; } set { _TrTipoVeicoloSegnalazione = value; } }
			public String EvTipoLTS { get { return _EvTipoLTS; } set { _EvTipoLTS = value; } }
			public String TrC2pStrada { get { return _TrC2pStrada; } set { _TrC2pStrada = value; } }

			#region dati
			protected String _Targa;
			protected String _Nazionalita;
			protected DateTime _EvDataOraInserimento;
			protected Int64 _EvIdEvento;
			protected TipoEvento _EvTipoEvento;
			protected StatoAllarme _EvStatoAllarme;
			protected String _EvUtentePresaInCarico;
			protected DateTime? _EvDataOraPresaInCarico;
			protected DateTime? _EvDataOraChiusura;
			protected String _EvNoteChiusura;
			protected ClasseUrgenza _EvClasseUrgenza;
			protected TipoVarco _TrTipoVarco;
			protected DateTime _TrDataOraRilevamento;
			protected StatoTransito _TrStatoTransito;
			protected String _TrUtentePresaInCarico;
			protected DateTime? _TrDataOraPresaInCarico;
			protected DateTime? _TrDataOraChiusura;
			protected String _TrNoteChiusura;
			protected String _TrPlateVehicleType;
			protected Decimal? _TrLatitudine;
			protected Decimal? _TrLongitudine;
			protected Int16 _TrIdC2P;
			protected String _TrC2PDirezione;
			protected String _TrC2PDescrizione;
			protected String _TrTipoVeicoloSegnalazione;
			protected String _EvTipoLTS;
			protected String _TrC2pStrada;
			#endregion
			/*
			public String Targa { get { return _Targa; } set { _Targa = value; } }
			public String Nazionalita { get { return _Nazionalita; } set { _Nazionalita = value; } }
			public DateTime EvDataOraInserimento { get { return _EvDataOraInserimento; } set { _EvDataOraInserimento = value; } }
			public Int64 EvIdEvento { get { return _EvIdEvento; } set { _EvIdEvento = value; } }
			public TipoEvento EvTipoEvento { get { return _EvTipoEvento; } set { _EvTipoEvento = value; } }
			public StatoAllarme EvStatoAllarme { get { return _EvStatoAllarme; } set { _EvStatoAllarme = value; } }
			public String EvUtentePresaInCarico { get { return _EvUtentePresaInCarico; } set { _EvUtentePresaInCarico = value; } }
			public DateTime? EvDataOraPresaInCarico { get { return _EvDataOraPresaInCarico; } set { _EvDataOraPresaInCarico = value; } }
			public DateTime? EvDataOraChiusura { get { return _EvDataOraChiusura; } set { _EvDataOraChiusura = value; } }
			public String EvNoteChiusura { get { return _EvNoteChiusura; } set { _EvNoteChiusura = value; } }
			public ClasseUrgenza EvClasseUrgenza { get { return _EvClasseUrgenza; } set { _EvClasseUrgenza = value; } }
			public TipoVarco TrTipoVarco { get { return _TrTipoVarco; } set { _TrTipoVarco = value; } }
			public DateTime TrDataOraRilevamento { get { return _TrDataOraRilevamento; } set { _TrDataOraRilevamento = value; } }
			public StatoTransito TrStatoTransito { get { return _TrStatoTransito; } set { _TrStatoTransito = value; } }
			public String TrUtentePresaInCarico { get { return _TrUtentePresaInCarico; } set { _TrUtentePresaInCarico = value; } }
			public DateTime? TrDataOraPresaInCarico { get { return _TrDataOraPresaInCarico; } set { _TrDataOraPresaInCarico = value; } }
			public DateTime? TrDataOraChiusura { get { return _TrDataOraChiusura; } set { _TrDataOraChiusura = value; } }
			public String TrNoteChiusura { get { return _TrNoteChiusura; } set { _TrNoteChiusura = value; } }
			public String TrPlateVehicleType { get { return _TrPlateVehicleType; } set { _TrPlateVehicleType = value; } }
			public Decimal? TrLatitudine { get { return _TrLatitudine; } set { _TrLatitudine = value; } }
			public Decimal? TrLongitudine { get { return _TrLongitudine; } set { _TrLongitudine = value; } }
			public Int16 TrIdC2P { get { return _TrIdC2P; } set { _TrIdC2P = value; } }
			public String TrC2PDirezione { get { return _TrC2PDirezione; } set { _TrC2PDirezione = value; } }
			public String TrC2PDescrizione { get { return _TrC2PDescrizione; } set { _TrC2PDescrizione = value; } }
			public String TrTipoVeicoloSegnalazione { get { return _TrTipoVeicoloSegnalazione; } set { _TrTipoVeicoloSegnalazione = value; } }
			public String TrC2pStrada { get { return _TrC2pStrada; } set { _TrC2pStrada = value; } }

			#region dati
			protected String _Targa;
			protected String _Nazionalita;
			protected DateTime _EvDataOraInserimento;
			protected Int64 _EvIdEvento;
			protected TipoEvento _EvTipoEvento;
			protected StatoAllarme _EvStatoAllarme;
			protected String _EvUtentePresaInCarico;
			protected DateTime? _EvDataOraPresaInCarico;
			protected DateTime? _EvDataOraChiusura;
			protected String _EvNoteChiusura;
			protected ClasseUrgenza _EvClasseUrgenza;
			protected TipoVarco _TrTipoVarco;
			protected DateTime _TrDataOraRilevamento;
			protected StatoTransito _TrStatoTransito;
			protected String _TrUtentePresaInCarico;
			protected DateTime? _TrDataOraPresaInCarico;
			protected DateTime? _TrDataOraChiusura;
			protected String _TrNoteChiusura;
			protected String _TrPlateVehicleType;
			protected Decimal? _TrLatitudine;
			protected Decimal? _TrLongitudine;
			protected Int16 _TrIdC2P;
			protected String _TrC2PDirezione;
			protected String _TrC2PDescrizione;
			protected String _TrTipoVeicoloSegnalazione;
			protected String _TrC2pStrada;
			#endregion
			*/
		}

		[Serializable]
		public class SegnalazioniAssociateAllEvento
		{
			public string EnumTipoLtsSegnalazione { get { return _EnumTipoLtsSegnalazione; } set { _EnumTipoLtsSegnalazione = value; } }
			public string TipoVeicoloSegnalazione { get { return _TipoVeicoloSegnalazione; } set { _TipoVeicoloSegnalazione = value; } }
			public string NoteSegnalazione { get { return _NoteSegnalazione; } set { _NoteSegnalazione = value; } }

			private string _EnumTipoLtsSegnalazione;
			private string _TipoVeicoloSegnalazione;
			private string _NoteSegnalazione;
		}


		[Serializable]
		public class TransitoSegnalatoSorveglianzaPaginato
		{
			public String Targa { get { return _Targa; } set { _Targa = value; } }
			public String Nazionalita { get { return _Nazionalita; } set { _Nazionalita = value; } }
			public DateTime DataOraRilevamento { get { return _DataOraRilevamento; } set { _DataOraRilevamento = value; } }
			public TipoVarco EnumTipoVarco { get { return _EnumTipoVarco; } set { _EnumTipoVarco = value; } }
			public String TrC2pStrada { get { return _TrC2pStrada; } set { _TrC2pStrada = value; } }
			public Direzione TrC2PDirezione { get { return _TrC2PDirezione; } set { _TrC2PDirezione = value; } }
			public String TrC2PDescrizione { get { return _TrC2PDescrizione; } set { _TrC2PDescrizione = value; } }
			public StatoTransito EnumStatoTransito { get { return _EnumStatoTransito; } set { _EnumStatoTransito = value; } }
			public DateTime DataOraInserimento { get { return _DataOraInserimento; } set { _DataOraInserimento = value; } }
			public Int64 IdEvento { get { return _IdEvento; } set { _IdEvento = value; } }
			public StatoAllarme StatoAllarme { get { return _StatoAllarme; } set { _StatoAllarme = value; } }
			public ClasseUrgenza EnumClasseUrgenza { get { return _EnumClasseUrgenza; } set { _EnumClasseUrgenza = value; } }
			public String NoteSegnalazione1 { get { return _NoteSegnalazione1; } set { _NoteSegnalazione1 = value; } }
			public String TipoVeicoloSegnalazione1 { get { return _TipoVeicoloSegnalazione1; } set { _TipoVeicoloSegnalazione1 = value; } }
			public String EnumTipoLtsSegnalazione1 { get { return _EnumTipoLtsSegnalazione1; } set { _EnumTipoLtsSegnalazione1 = value; } }
			public DateTime? PrecTsEvDataOraInserimento { get { return _PrecTsEvDataOraInserimento; } set { _PrecTsEvDataOraInserimento = value; } }
			public Int64? PrecTsEvIdEvento { get { return _PrecTsEvIdEvento; } set { _PrecTsEvIdEvento = value; } }
			public StatoAllarme? PrecTsEvStatoAllarme { get { return _PrecTsEvStatoAllarme; } set { _PrecTsEvStatoAllarme = value; } }
			public String PL_VEHICLE_TYPE { get { return _PL_VEHICLE_TYPE; } set { _PL_VEHICLE_TYPE = value; } }

			#region dati
			protected String _Targa;
			protected String _Nazionalita;
			protected DateTime _DataOraRilevamento;
			protected TipoVarco _EnumTipoVarco;
			protected String _TrC2pStrada;
			protected Direzione _TrC2PDirezione;
			protected String _TrC2PDescrizione;
			protected StatoTransito _EnumStatoTransito;
			protected DateTime _DataOraInserimento;
			protected Int64 _IdEvento;
			protected StatoAllarme _StatoAllarme;
			protected ClasseUrgenza _EnumClasseUrgenza;
			protected String _NoteSegnalazione1;
			protected String _TipoVeicoloSegnalazione1;
			protected String _EnumTipoLtsSegnalazione1;
			protected DateTime? _PrecTsEvDataOraInserimento;
			protected Int64? _PrecTsEvIdEvento;
			protected StatoAllarme? _PrecTsEvStatoAllarme;
			protected String _PL_VEHICLE_TYPE;
			#endregion
		}

	}
}
