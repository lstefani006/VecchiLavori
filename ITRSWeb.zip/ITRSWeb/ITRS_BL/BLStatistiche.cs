using System;
using System.ComponentModel;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Threading;
using System.Configuration;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using ITRS_BL.IDal;


namespace ITRS_BL
{
	public partial class BLStatistiche : Component
	{
		public BLStatistiche()
		{
			InitializeComponent();
		}

		public BLStatistiche(IContainer container)
		{
			container.Add(this);

			InitializeComponent();
		}

		public int GetTempiEtVelocitaSuTrattaCount(DateTime data)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetTempiEtVelocitaSuTrattaCount(data);
		}

        public int GetTempiEtVelocitaSuTrattaCount(DateTime data, int idTratta)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetTempiEtVelocitaSuTrattaCount(data, idTratta);
        }

		public List<BLStatistiche.TempiEtVelocitaSuTratta> GetTempiEtVelocitaSuTratta(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetTempiEtVelocitaSuTratta(data, sortColumns, startRowIndex, maximumRows);
		}

        public List<BLStatistiche.TempiEtVelocitaSuTratta> GetTempiEtVelocitaSuTratta(DateTime data, int idTratta, string sortColumns, int startRowIndex, int maximumRows)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetTempiEtVelocitaSuTratta(data, idTratta, sortColumns, startRowIndex, maximumRows);
        }

		public int GetVolumeTrafficoTrattaCount(DateTime data)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetVolumeTrafficoTrattaCount(data);
		}

        public int GetVolumeTrafficoTrattaCount(DateTime data, int idTratta)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetVolumeTrafficoTrattaCount(data, idTratta);
        }

		public List<BLStatistiche.VolumeTrafficoTratta> GetVolumeTrafficoTratta(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetVolumeTrafficoTratta(data, sortColumns, startRowIndex, maximumRows);
		}

        public List<BLStatistiche.VolumeTrafficoTratta> GetVolumeTrafficoTratta(DateTime data, int idTratta, string sortColumns, int startRowIndex, int maximumRows)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetVolumeTrafficoTratta(data, idTratta, sortColumns, startRowIndex, maximumRows);
        }

		public int GetTempiEtVelocitaPerDirezioneCount(DateTime data)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetTempiEtVelocitaPerDirezioneCount(data);
		}

		public List<BLStatistiche.TempiEtVelocitaPerDirezione> GetTempiEtVelocitaPerDirezione(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetTempiEtVelocitaPerDirezione(data, sortColumns, startRowIndex, maximumRows);
		}

        public int GetTempiEtVelocitaPerDirezioneCount(DateTime data, string direzione)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetTempiEtVelocitaPerDirezioneCount(data, direzione);
        }

        public List<BLStatistiche.TempiEtVelocitaPerDirezione> GetTempiEtVelocitaPerDirezione(DateTime data, string direzione, string sortColumns, int startRowIndex, int maximumRows)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetTempiEtVelocitaPerDirezione(data, direzione, sortColumns, startRowIndex, maximumRows);
        }

		public int GetVolumeTrafficoDirezioneCount(DateTime data)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetVolumeTrafficoDirezioneCount(data);
		}

		public List<BLStatistiche.VolumeTrafficoDirezione> GetVolumeTrafficoDirezione(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetVolumeTrafficoDirezione(data, sortColumns, startRowIndex, maximumRows);
		}

        public int GetVolumeTrafficoDirezioneCount(DateTime data, string direzione)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetVolumeTrafficoDirezioneCount(data, direzione);
        }

        public List<BLStatistiche.VolumeTrafficoDirezione> GetVolumeTrafficoDirezione(DateTime data, string direzione, string sortColumns, int startRowIndex, int maximumRows)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetVolumeTrafficoDirezione(data, direzione, sortColumns, startRowIndex, maximumRows);
        }

		public int GetTempiSostaC2PCount(DateTime data)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetTempiSostaC2PCount(data);
		}

		public List<BLStatistiche.TempiSostaC2P> GetTempiSostaC2P(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetTempiSostaC2P(data, sortColumns, startRowIndex, maximumRows);
		}

        public int GetTempiSostaC2PCount(DateTime data, int idC2P)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetTempiSostaC2PCount(data, idC2P);
        }

        public List<BLStatistiche.TempiSostaC2P> GetTempiSostaC2P(DateTime data, int idC2P, string sortColumns, int startRowIndex, int maximumRows)
        {
            IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
            return t.GetTempiSostaC2P(data, idC2P, sortColumns, startRowIndex, maximumRows);
        }

		public int GetTarghePerC2PCount(DateTime data, int idC2P)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetTarghePerC2PCount(data, idC2P);
		}

		public List<BLStatistiche.TarghePerC2P> GetTarghePerC2P(DateTime data, int idC2P, string sortColumns, int startRowIndex, int maximumRows)
		{
			IDalStatistiche t = DalProvider.DAL.CreateDalStatistiche();
			return t.GetTarghePerC2P(data, idC2P, sortColumns, startRowIndex, maximumRows);
		}
		
		//Modifica Frascatani 05/09/2006        
        public byte[] ExportTempiVelocitaPerDirezione(DateTime data, string direzione, string sort)
        {
            try
            {
                List<TempiEtVelocitaPerDirezione> lst = GetTempiEtVelocitaPerDirezione(data, direzione, sort, 0, 100000);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (StreamWriter sw = new StreamWriter(ms))
                    {
                        //titolo
                        sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}\t{4}","OraDa","OraA","Tempo Percorrenza (sec)","Velocita' (Km/h)", "Numero veicoli"));
                        foreach (TempiEtVelocitaPerDirezione tb in lst)
                        {
                            sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}\t{4}", tb.OraDa.ToString(), tb.OraA.ToString(),Duration(tb.TempoPercorrenzaSecondi), tb.Velocita.ToString(), tb.NumeroVeicoli.ToString()));
                        }
                    }
                    return ms.ToArray();
                }
            }
            catch (Exception ex)
            {
                Log.Write(ex, "ExportTempiVelocitaPerDirezione");
                throw;
            }
        }
		protected string Duration(int sec)
		{
			TimeSpan s = new TimeSpan(0, 0, sec);
			return s.Hours.ToString("00") + ":" + s.Minutes.ToString("00") + ":" + s.Seconds.ToString("00");
		}


        public byte[] ExportTempiVelocitaSuTratta(DateTime data, int idTratta, string sort)
        {
            try
            {
                List<TempiEtVelocitaSuTratta> lst = GetTempiEtVelocitaSuTratta(data, idTratta, sort, 0, 100000);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (StreamWriter sw = new StreamWriter(ms))
                    {
                        //titolo
                        sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}\t{4}", "OraDa", "OraA", "Tempo Percorrenza (sec)", "Velocita' (Km/h)", "Numero veicoli"));
                        foreach (TempiEtVelocitaSuTratta tb in lst)
                        {
                            sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}\t{4}", tb.OraDa.ToString(), tb.OraA.ToString(), Duration(tb.TempoPercorrenzaSecondi), tb.Velocita.ToString(), tb.NumeroVeicoli.ToString()));
                        }
                    }
                    return ms.ToArray();
                }
            }
            catch (Exception ex)
            {
                Log.Write(ex, "ExportTempiVelocitaPerTratta");
                throw;
            }
        }
        public byte[] ExportTempiSostaC2P(DateTime data, int idC2P, string sort)
        {
            try
            {
                List<TempiSostaC2P> lst = GetTempiSostaC2P(data, idC2P, sort, 0, 100000);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (StreamWriter sw = new StreamWriter(ms))
                    {
                        //titolo
                        sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}", "OraDa", "OraA", "Tempo Sosta Medio (sec)", "Numeri veicoli"));
                        foreach (TempiSostaC2P tb in lst)
                        {
                            sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}", tb.OraDa.ToString(), tb.OraA.ToString(), Duration(tb.TempoSostaMedio), tb.NumeroVeicoli.ToString()));
                        }
                    }
                    return ms.ToArray();
                }
            }
            catch (Exception ex)
            {
                Log.Write(ex, "ExportTempiSostaC2P");
                throw;
            }
        }
        public byte[] ExportVolumeTrafficoSuTratta(DateTime data, int idTratta, string sort)
        {
            try
            {
                List<VolumeTrafficoTratta> lst = GetVolumeTrafficoTratta(data, idTratta, sort, 0, 100000);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (StreamWriter sw = new StreamWriter(ms))
                    {
                        //titolo
                        sw.WriteLine(string.Format("{0}\t{1}\t{2}", "OraDa", "OraA", "Numero Transiti"));
                        foreach (VolumeTrafficoTratta tb in lst)
                        {
                            sw.WriteLine(string.Format("{0}\t{1}\t{2}", tb.OraDa.ToString(), tb.OraA.ToString(), tb.C_Trans.ToString()));
                        }
                    }
                    return ms.ToArray();
                }
            }
            catch (Exception ex)
            {
                Log.Write(ex, "ExportVolumeTrafficoSuTratta");
                throw;
            }
        }
        public byte[] ExportVolumeTrafficoPerDirezione(DateTime data, string direzione, string sort)
        {
            try
            {
                List<VolumeTrafficoDirezione> lst = GetVolumeTrafficoDirezione(data, direzione, sort, 0, 100000);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (StreamWriter sw = new StreamWriter(ms))
                    {
                        //titolo
                        sw.WriteLine(string.Format("{0}\t{1}\t{2}", "OraDa", "OraA", "Numero Transiti"));
                        foreach (VolumeTrafficoDirezione tb in lst)
                        {
                            sw.WriteLine(string.Format("{0}\t{1}\t{2}", tb.OraDa.ToString(), tb.OraA.ToString(), tb.C_Trans.ToString()));
                        }
                    }
                    return ms.ToArray();
                }
            }
            catch (Exception ex)
            {
                Log.Write(ex, "ExportVolumeTrafficoPerDirezione");
                throw;
            }
        }
        //Fine

		[Serializable]
		public class TempiEtVelocitaSuTratta
		{
			private DateTime _DataRep;
			public DateTime DataRep
			{
				get { return _DataRep; }
				set { _DataRep = value; }
			}

			private int _OraDa;
			public int OraDa
			{
				get { return _OraDa; }
				set { _OraDa = value; }
			}

			private int _OraA;
			public int OraA
			{
				get { return _OraA; }
				set { _OraA = value; }
			}

			private string _Strada;
			public string Strada
			{
				get { return _Strada; }
				set { _Strada = value; }
			}

			private string _Direzione;
			public string Direzione
			{
				get { return _Direzione; }
				set { _Direzione = value; }
			}

			private string _DescrizioneTratta;
			public string DescrizioneTratta
			{
				get { return _DescrizioneTratta; }
				set { _DescrizioneTratta = value; }
			}

			private int _TempoPercorrenzaSecondi;
			public int TempoPercorrenzaSecondi
			{
				get { return _TempoPercorrenzaSecondi; }
				set { _TempoPercorrenzaSecondi = value; }
			}

			private decimal _Velocita;
			public decimal Velocita
			{
				get { return _Velocita; }
				set { _Velocita = value; }
			}
	
			private int ?_NumeroVeicoli;
			public int ?NumeroVeicoli
			{
				get { return _NumeroVeicoli; }
				set { _NumeroVeicoli = value; }
			}

		}
		[Serializable]
		public class VolumeTrafficoTratta
		{
			private DateTime _DataRep;
			public DateTime DataRep
			{
				get { return _DataRep; }
				set { _DataRep = value; }
			}

			private int _OraDa;
			public int OraDa
			{
				get { return _OraDa; }
				set { _OraDa = value; }
			}

			private int _OraA;
			public int OraA
			{
				get { return _OraA; }
				set { _OraA = value; }
			}

			private int _C2P;
			public int C2P
			{
			  get { return _C2P; }
			  set { _C2P = value; }
			}

			private int _C_Trans;
			public int C_Trans
			{
				get { return _C_Trans; }
				set { _C_Trans = value; }
			}

			private string _DescrizioneC2P;
			public string DescrizioneC2P
			{
				get { return _DescrizioneC2P; }
				set { _DescrizioneC2P = value; }
			}
		}
		[Serializable]
		public class TempiEtVelocitaPerDirezione
		{
			private DateTime _DataRep;
			public DateTime DataRep
			{
				get { return _DataRep; }
				set { _DataRep = value; }
			}

			private int _OraDa;
			public int OraDa
			{
				get { return _OraDa; }
				set { _OraDa = value; }
			}

			private int _OraA;
			public int OraA
			{
				get { return _OraA; }
				set { _OraA = value; }
			}

			private string _Strada;
			public string Strada
			{
				get { return _Strada; }
				set { _Strada = value; }
			}

			private string _Direzione;
			public string Direzione
			{
				get { return _Direzione; }
				set { _Direzione = value; }
			}

			private int _TempoPercorrenzaSecondi;
			public int TempoPercorrenzaSecondi
			{
				get { return _TempoPercorrenzaSecondi; }
				set { _TempoPercorrenzaSecondi = value; }
			}

			private decimal _Velocita;
			public decimal Velocita
			{
				get { return _Velocita; }
				set { _Velocita = value; }
			}

			private int ?_NumeroVeicoli;
			public int? NumeroVeicoli
			{
				get { return _NumeroVeicoli; }
				set { _NumeroVeicoli = value; }
			}

		}
		[Serializable]
		public class VolumeTrafficoDirezione
		{
			private DateTime _DataRep;
			public DateTime DataRep
			{
				get { return _DataRep; }
				set { _DataRep = value; }
			}

			private int _OraDa;
			public int OraDa
			{
				get { return _OraDa; }
				set { _OraDa = value; }
			}

			private int _OraA;
			public int OraA
			{
				get { return _OraA; }
				set { _OraA = value; }
			}

			private string _Strada;
			public string Strada
			{
				get { return _Strada; }
				set { _Strada = value; }
			}

			private string _Direzione;
			public string Direzione
			{
				get { return _Direzione; }
				set { _Direzione = value; }
			}

			private int _C_Trans;
			public int C_Trans
			{
				get { return _C_Trans; }
				set { _C_Trans = value; }
			}
		}
		[Serializable]
		public class TempiSostaC2P
		{
			private DateTime _DataRep;
			public DateTime DataRep
			{
				get { return _DataRep; }
				set { _DataRep = value; }
			}

			private int _OraDa;
			public int OraDa
			{
				get { return _OraDa; }
				set { _OraDa = value; }
			}

			private int _OraA;
			public int OraA
			{
				get { return _OraA; }
				set { _OraA = value; }
			}

			private int _C2P;
			public int C2P
			{
				get { return _C2P; }
				set { _C2P = value; }
			}

			private int _TempoSostaMedio;
			public int TempoSostaMedio
			{
				get { return _TempoSostaMedio; }
				set { _TempoSostaMedio = value; }
			}

			private string _DescrizioneC2P;
			public string DescrizioneC2P
			{
				get { return _DescrizioneC2P; }
				set { _DescrizioneC2P = value; }
			}

			private int ?_NumeroVeicoli;
			public int ?NumeroVeicoli
			{
				get { return _NumeroVeicoli; }
				set { _NumeroVeicoli = value; }
			}

		}

		[Serializable]
		public class TarghePerC2P
		{
			private DateTime _DataRep;
			public DateTime DataRep
			{
				get { return _DataRep; }
				set { _DataRep = value; }
			}

			private int _C2P;
			public int C2P
			{
				get { return _C2P; }
				set { _C2P = value; }
			}

			private string _DescrizioneC2P;
			public string DescrizioneC2P
			{
				get { return _DescrizioneC2P; }
				set { _DescrizioneC2P = value; }
			}

			private int _TargheRicIta;
			public int TargheRicIta
			{
				get { return _TargheRicIta; }
				set { _TargheRicIta = value; }
			}

			private int _TargheRicEst;
			public int TargheRicEst
			{
				get { return _TargheRicEst; }
				set { _TargheRicEst = value; }
			}

			private int _TargheNonRic;
			public int TargheNonRic
			{
				get { return _TargheNonRic; }
				set { _TargheNonRic = value; }
			}
		}

	}
}
