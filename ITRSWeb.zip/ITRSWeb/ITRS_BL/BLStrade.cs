using System;
using System.ComponentModel;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Threading;
using System.Configuration;
using System.Collections.Generic;
using ITRS_BL.IDal;

namespace ITRS_BL
{
	public partial class BLStrade : Component
	{
		public BLStrade()
		{
			InitializeComponent();
		}

		public BLStrade(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Strada> GetListaStrade(string columnsSort)
		{
			try
			{
				if (columnsSort.ToLower() == "descrizione")
					columnsSort = "DescrizioneStrada";
				else if (columnsSort.ToLower() == "descrizione desc")
					columnsSort = "DescrizioneStrada desc";

				IDalStrada t = DalProvider.DAL.CreateDalStrade();
				return t.GetLista(columnsSort);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella strade", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Strada> GetListaStradeCB()
		{
			try
			{
				string columnsSort = "DescrizioneStrada";
				IDalStrada t = DalProvider.DAL.CreateDalStrade();
				return t.GetLista(columnsSort);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella strade", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<DirezioneStrada> GetListaDirezioniCB()
		{
			List<DirezioneStrada> r = new List<DirezioneStrada>();

			DirezioneStrada d;

			d = new DirezioneStrada();
			d.Codice = "NORD";
			d.Descrizione = "Nord";
			r.Add(d);

			d = new DirezioneStrada();
			d.Codice = "SUD";
			d.Descrizione = "Sud";
			r.Add(d);
			return r;
		}



		[DataObjectMethod(DataObjectMethodType.Select)]
		public Strada GetStrada(string codiceStrada)
		{
			try
			{
				IDalStrada t = DalProvider.DAL.CreateDalStrade();
				Strada r = new Strada();
				r.CodiceStrada = codiceStrada;
				return t.GetRecord(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella strade", ex);
			}
		}


		[DataObjectMethod(DataObjectMethodType.Delete)]
		public void CancellaStrada(string codiceStrada)
		{
			try
			{
				IDalStrada t = DalProvider.DAL.CreateDalStrade();
				Strada r = new Strada();
				r.CodiceStrada = codiceStrada;
				t.Cancella(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella cancellazione del record", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Update)]
		public void AggiornaStrada(string codiceStrada, string descrizione)
		{
			Strada st = new Strada();
			st.CodiceStrada = codiceStrada;
			st.Descrizione = descrizione;

			try
			{
				IDalStrada t = DalProvider.DAL.CreateDalStrade();
				Strada r = new Strada();
				r.CodiceStrada = codiceStrada;
				r.Descrizione = descrizione;
				t.Aggiorna(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nell'aggiornamento del record", ex);
			}
		}

		[DataObjectMethod(DataObjectMethodType.Insert)]
		public void InserisciStrada(string codiceStrada, string descrizione)
		{
			Strada st = new Strada();
			st.CodiceStrada = codiceStrada;
			st.Descrizione = descrizione;

			try
			{
				IDalStrada t = DalProvider.DAL.CreateDalStrade();
				Strada r = new Strada();
				r.CodiceStrada = codiceStrada;
				r.Descrizione = descrizione;
				t.Inserisci(r);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nell'inserimento del record", ex);
			}
		}

	}

	[Serializable]
	public class Strada
	{
		public string CodiceStrada
		{
			get { return _CodiceStrada; }
			set { _CodiceStrada = value; }
		}

		public string Descrizione
		{
			get { return _Descrizione; }
			set { _Descrizione = value; }
		}

		private string _Descrizione;
		private string _CodiceStrada;
	}

	[Serializable]
	public class DirezioneStrada
	{
		public string Codice
		{
			get { return _Codice; }
			set { _Codice = value; }
		}

		public string Descrizione
		{
			get { return _Descrizione; }
			set { _Descrizione = value; }
		}

		private string _Descrizione;
		private string _Codice;
	}

}
