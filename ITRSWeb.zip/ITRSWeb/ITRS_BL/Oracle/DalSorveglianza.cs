using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif
// 04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46 LEO
// 04cb7e87-b4a7-48fc-8c4b-8e0ed088fe47 Admin

namespace ITRS_BL.Oracle
{
	public class DalSorveglianza : DalBase, IDalSorveglianza
	{
		public List<BLSorveglianza.TransitoSegnalatoSorveglianza> GetListaSorveglianza(int idCoa, BLSorveglianza.SorvTipoLTS tipoSorv)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"
select 
NoteSegnalazione1,
TipoVeicoloSegnalazione1,
EnumTipoLtsSegnalazione1,

NoteSegnalazione2,
TipoVeicoloSegnalazione2,
EnumTipoLtsSegnalazione2,

NoteSegnalazione3,
TipoVeicoloSegnalazione3,
EnumTipoLtsSegnalazione3,

Targa,
Nazionalita,
decode(rownum, 1, Immagine, null) Immagine,

DataOraInserimento,
IdEvento,
/*TipoEvento*/ TipoEvento,
/*StatoAllarme*/ StatoAllarme,
EvUtentePresaInCarico,
EvDataOraPresaInCarico,
EvDataOraChiusura,
EvNoteChiusura,
/*ClasseUrgenza*/EnumClasseUrgenza,

/*TipoVarco*/ EnumTipoVarco,
DataOraRilevamento,
/*StatoTransito*/ EnumStatoTransito,
TrUtentePresaInCarico,
TrDataOraPresaInCarico,
TrDataOraChiusura,
TrNoteChiusura,

TrLatitudine,
TrLongitudine,

/*Direzione*/ TrC2PDirezione,
TrC2PDescrizione,

TrC2pStrada,

PL_XSTART,
PL_YSTART,
PL_XEND,
PL_YEND,
PL_NET_ID,
PL_LAYOUT_ID,
PL_VEHICLE_TYPE,
PL_VEHICLE_ID,

PrecTsEvDataOraInserimento,
PrecTsEvIdEvento,
/*StatoAllarme*/ PrecTsEvStatoAllarme,
PrecTsEvNoteChiusura,

PrecTsTrDataOraRilevamento,
/* StatoTransito */ PrecTsTrStatoTransito,
PrecTsTrC2PDescrizione,
/* Direzione */ PrecTsTrC2PDirezione,
PrecTsTrStrada,
/* TipoVarco */ PrecTsTrTipoVarco,
PresTsTrNoteChiusura

from
(
	select  /*+ FIRST_ROWS(n) */ 
	S.Targa,
	S.Nazionalita,
	S.Immagine,

	S.ENUMTIPOLTSSEGNALAZIONE1,
	S.TIPOVEICOLOSEGNALAZIONE1,
	S.NOTESEGNALAZIONE1,

	S.ENUMTIPOLTSSEGNALAZIONE2,
	S.TIPOVEICOLOSEGNALAZIONE2,
	S.NOTESEGNALAZIONE2,

	S.ENUMTIPOLTSSEGNALAZIONE3,
	S.TIPOVEICOLOSEGNALAZIONE3,
	S.NOTESEGNALAZIONE3,


	E.DataOraInserimento,
	E.IdEvento,
	E.EnumTipoEvento         TipoEvento,
	E.EnumStatoAllarme       StatoAllarme,
	UTEV.UserName            EvUtentePresaInCarico,
	E.DataOraPresaInCarico   EvDataOraPresaInCarico,
	E.DataOraChiusura        EvDataOraChiusura,
	E.NoteChiusura           EvNoteChiusura,
	E.EnumClasseUrgenza,

	T.EnumTipoVarco,
	T.DataOraRilevamento,
	T.EnumStatoTransito,
	UTTR.UserName               TrUtentePresaInCarico,
	T.DataOraPresaInCarico      TrDataOraPresaInCarico,
	T.DataOraChiusura           TrDataOraChiusura,
	T.NoteChiusura              TrNoteChiusura,

	T.PL_XSTART,
	T.PL_YSTART,
	T.PL_XEND,
	T.PL_YEND,
	T.PL_NET_ID,
	T.PL_LAYOUT_ID,
	T.PL_VEHICLE_TYPE,
	T.PL_VEHICLE_ID,

	nvl(T.Latitudine,  C2P_TR.Lat) TrLatitudine,
	nvl(T.Longitudine, C2P_TR.Lon) TrLongitudine,

	C2P_TR.DIREZIONE               TrC2PDirezione,
	C2P_TR.DESCRIZIONE             TrC2PDescrizione,

	Strade_TR.DESCRIZIONESTRADA    TrC2pStrada,

	PrecTsEv.DATAORAINSERIMENTO     PrecTsEvDataOraInserimento,
	PrecTsEv.IDEVENTO               PrecTsEvIdEvento,
	PrecTsEv.ENUMSTATOALLARME       PrecTsEvStatoAllarme,
	PrecTsEv.NOTECHIUSURA           PrecTsEvNoteChiusura,
    S.PRECTRDATAORARILEVAMENTO      PrecTsTrDataOraRilevamento,
    PrecTr.ENUMSTATOTRANSITO        PrecTsTrStatoTransito,
    PrecTrC2P.DESCRIZIONE           PrecTsTrC2PDescrizione,
    PrecTrC2P.DIREZIONE             PrecTsTrC2PDirezione,
    PrecTrStrada.DESCRIZIONESTRADA  PrecTsTrStrada,
	PrecTr.EnumTipoVarco            PrecTsTrTipoVarco,
	PrecTr.NoteChiusura             PresTsTrNoteChiusura

	from SorveglianzaRes S

	inner join EventiDaSegnalare E
	on  E.Targa              = S.Targa
	and E.Nazionalita        = S.Nazionalita
	and E.DataOraInserimento = S.DataOraInserimento
	and E.IdEvento           = S.IdEvento

	inner join TransitiSuEvento T
	on  T.Targa              = S.Targa
	and T.Nazionalita        = S.Nazionalita
	and T.DataOraRilevamento = S.DataOraRilevamento

	left outer join ASPNET_USERS UTEV
	on  UTEV.pkid = E.IdUtentePresaInCarico

	left outer join ASPNET_USERS UTTR
	on  UTTR.pkid = T.IdUtentePresaInCarico

	inner join C2P C2P_TR
	on C2P_TR.IDC2P = T.IDC2P

	inner join Strade Strade_TR
	on Strade_TR.CODICESTRADA = C2P_TR.CODICESTRADA

	left outer join EVENTIDASEGNALARE PrecTsEv
	on  PrecTsEv.Targa              = S.Targa
	and PrecTsEv.Nazionalita        = S.Nazionalita
	and PrecTsEv.DataOraInserimento = S.PrecEvDataOraInserimento
	and PrecTsEv.IdEvento           = S.PrecEvIdEvento

	left outer join TransitiSuEvento PrecTr
	on  PrecTr.Targa              = S.Targa
	and PrecTr.Nazionalita        = S.Nazionalita
	and PrecTr.DataOraRilevamento = S.PRECTRDATAORARILEVAMENTO

	left outer join C2P PrecTrC2P
	on PrecTrC2P.IDC2P = PrecTr.IDC2P

	left outer join Strade PrecTrStrada
	on PrecTrStrada.CODICESTRADA = PrecTrC2P.CODICESTRADA

	where 
	S.IDCOA = :p_idCoa and
	-- la sorveglianza fa vedere solo i transiti NON in stato Non Riconosciuto
	-- e con stato allarme QCQ e PIC (ossia non quelli gia` presi in carico)
	T.EnumStatoTransito <> 'NORIC' and (E.EnumStatoAllarme = 'ACQ' or E.EnumStatoAllarme = 'PIC')

	-- se voglio vedere solo le A2 scelgo i record con segnalazione A2 ma
	-- che non hanno segnalazione A1
	-- in ENUMTIPOLTSSEGNALAZIONE1 se l'allarme e` di tipo A1 c'e` sempre A1 anche se esiste una segnalazione
	-- di tipo A2 (che andra` ENUMTIPOLTSSEGNALAZIONE2)
	-- se l'allarme e` solo A2 allora si avra` ENUMTIPOLTSSEGNALAZIONE1 = 'A2'
	and (:p_tipoSorv is null or S.ENUMTIPOLTSSEGNALAZIONE1 <> :p_tipoSorv)
	order by S.Progr desc
) Q
where rownum <= 10
";

					cmd.CommandText = q;
					cmd.AddWithValue("p_idCoa", idCoa);
					switch (tipoSorv)
					{
					case BLSorveglianza.SorvTipoLTS.Tutti:
						cmd.AddWithValue("p_tipoSorv", (string)null);
						break;

					case BLSorveglianza.SorvTipoLTS.noA2:
						cmd.AddWithValue("p_tipoSorv", "A2");
						break;
					}
					List<BLSorveglianza.TransitoSegnalatoSorveglianza> ret = RecordReader<BLSorveglianza.TransitoSegnalatoSorveglianza>(cmd);
					return ret;
				}
			}
		}

		/// <summary>
		/// metodo chiamato per raccogliere le informazioni sul tr segnalato quando arrivano 
		/// i messaggi MWP
		/// </summary>
		/// <param name="Targa"></param>
		/// <param name="Nazionalita"></param>
		/// <param name="DataOraRilevamento"></param>
		/// <returns></returns>
		public BLSorveglianza.DatiTransitoSegnalatoSuMessaggioMWP GetDatiPerTransitoSegnalazioneSuMessaggioMWP(string Targa, string Nazionalita, DateTime DataOraRilevamento)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"
select
T.Targa,
T.Nazionalita,

E.DataOraInserimento                       EvDataOraInserimento,  
E.IdEvento                                 EvIdEvento,
E.EnumTipoEvento         /*TipoEvento*/    EvTipoEvento,
E.EnumStatoAllarme       /*StatoAllarme*/  EvStatoAllarme,
UTEV.UserName                              EvUtentePresaInCarico,
E.DataOraPresaInCarico                     EvDataOraPresaInCarico,
E.DataOraChiusura                          EvDataOraChiusura,
E.NoteChiusura                             EvNoteChiusura,
E.EnumClasseUrgenza      /*ClasseUrgenza*/ EvClasseUrgenza,

T.EnumTipoVarco          /*TipoVarco*/     TrTipoVarco,
T.DataOraRilevamento                       TrDataOraRilevamento,
T.EnumStatoTransito      /*StatoTransito*/ TrStatoTransito,
UTTR.UserName                              TrUtentePresaInCarico,
T.DataOraPresaInCarico                     TrDataOraPresaInCarico,
T.DataOraChiusura                          TrDataOraChiusura,
T.NoteChiusura                             TrNoteChiusura,
T.PL_VEHICLE_TYPE                          TrPlateVehicleType,
nvl(T.Latitudine,  C2P.Lat)                TrLatitudine,
nvl(T.Longitudine, C2P.Lon)                TrLongitudine,
T.IDC2P                                    TrIdC2P,
C2p.DIREZIONE                              TrC2PDirezione,
C2p.DESCRIZIONE                            TrC2PDescrizione,

nvl(SGA1.tab_tipo_veicolo, SGA2.tab_tipo_veicolo) TrTipoVeicoloSegnalazione,
nvl(SGA1.EnumTipoLTS, SGA2.EnumTipoLTS)    EvTipoLTS,

Strade.DESCRIZIONESTRADA TrC2pStrada

from TransitiSuEvento T

inner join TransitiEventi TE
on  TE.Targa              = T.Targa
and TE.Nazionalita        = T.Nazionalita
and TE.DataOraRilevamento = T.DataOraRilevamento

inner join EventiDaSegnalare E
on  E.Targa              = TE.Targa
and E.Nazionalita        = TE.Nazionalita
and E.DataOraInserimento = TE.DataOraInserimento
and E.IdEvento           = TE.IdEvento
and E.EnumTipoEvento     = 'TS'

left outer join ASPNET_USERS UTEV
on  UTEV.pkid = E.IdUtentePresaInCarico

left outer join ASPNET_USERS UTTR
on  UTTR.pkid = T.IdUtentePresaInCarico

inner join C2P
on C2P.IDC2P = T.IDC2P

inner join Strade
on Strade.CODICESTRADA = C2P.CODICESTRADA

left outer join Segnalazioni SGA1
on  SGA1.Targa              = E.Targa
and SGA1.Nazionalita        = E.Nazionalita
and SGA1.DataOraInserimento = E.DataOraInserimento
and SGA1.IdEvento           = E.IdEvento
and (SGA1.EnumTipoLTS = 'A1')

left outer join Segnalazioni SGA2
on  SGA2.Targa              = E.Targa
and SGA2.Nazionalita        = E.Nazionalita
and SGA2.DataOraInserimento = E.DataOraInserimento
and SGA2.IdEvento           = E.IdEvento
and (SGA2.EnumTipoLTS = 'A2' )

where
T.Targa = :p_Targa
and T.Nazionalita = :p_Nazionalita
and T.DataOraRilevamento = :p_DataOraRilevamento
";

					cmd.CommandText = q;
					cmd.AddWithValue("p_Targa", Targa);
					cmd.AddWithValue("p_Nazionalita", Nazionalita);
					cmd.AddWithValue("p_DataOraRilevamento", DataOraRilevamento);

					List<BLSorveglianza.DatiTransitoSegnalatoSuMessaggioMWP> ret = RecordReader<BLSorveglianza.DatiTransitoSegnalatoSuMessaggioMWP>(cmd);
					if (ret.Count == 0)
						return null;
					if (ret.Count != 1)
						throw new ApplicationException("ITRS_SORVEGLIANZA.GetDatiSorveglianza ritorna piu` di un record");
					return ret[0];
				}
			}
		}

		public byte[] GetMapSorveglianza(int idCoa, string Targa, string Nazionalita, DateTime DataOraRilevamento)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = @"
select Immagine 
from SorveglianzaRes 
where 
idCoa = :p_idCoa and
targa = :p_targa and 
nazionalita = :p_nazionalita and 
dataOraRilevamento = :p_dataOraRilevamento";

					cmd.AddWithValue("p_targa", Targa);
					cmd.AddWithValue("p_nazionalita", Nazionalita);
					cmd.AddWithValue("p_dataOraRilevamento", DataOraRilevamento);
					cmd.AddWithValue("p_idCoa", idCoa);

					cn.Open();

					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						rd.FetchSize = cmd.RowSize;

						while (rd.Read())
						{
							if (rd.IsDBNull(0))
								return null;

							byte[] r = (byte[])rd[0];
							return r;
						}
					}

					return null;
				}
			}
		}

		public void AccodaEvento(
			 string p_TARGA,
			 string p_NAZIONALITA,
			 DateTime p_DATAORAINSERIMENTO,
			 DateTime p_DATAORARILEVAMENTO,
			 Int64 p_IDEVENTO,
			 int p_IDCOA,
			 byte[] p_Img,
			DateTime? p_PrecEvDataOraInserimento,
			int? p_PrecEvIdEvento,
			DateTime? p_PrecTrDataOraRilevamento,
			string p_EnumTipoLtsSegnalazione1,
			string p_TipoVeicoloSegnalazione1,
			string p_NoteSegnalazione1,
			string p_EnumTipoLtsSegnalazione2,
			string p_TipoVeicoloSegnalazione2,
			string p_NoteSegnalazione2,
			string p_EnumTipoLtsSegnalazione3,
			string p_TipoVeicoloSegnalazione3,
			string p_NoteSegnalazione3
			)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "ITRS_SORVEGLIANZA.AccodaEvento";

					cmd.AddWithValue("p_TARGA", p_TARGA);
					cmd.AddWithValue("p_NAZIONALITA", p_NAZIONALITA);
					cmd.AddWithValue("p_DATAORAINSERIMENTO", p_DATAORAINSERIMENTO);
					cmd.AddWithValue("p_DATAORARILEVAMENTO", p_DATAORARILEVAMENTO);
					cmd.AddWithValue("p_IDEVENTO", p_IDEVENTO);
					cmd.AddWithValue("p_IDCOA", p_IDCOA);
					cmd.AddWithValue("p_Img", p_Img);

					cmd.AddWithValue("p_PrecEvDataOraInserimento", p_PrecEvDataOraInserimento);
					cmd.AddWithValue("p_PrecEvIdEvento", p_PrecEvIdEvento);
					cmd.AddWithValue("p_PrecTrDataOraRilevamento", p_PrecTrDataOraRilevamento);


					cmd.AddWithValue("p_EnumTipoLtsSegnalazione1", p_EnumTipoLtsSegnalazione1);
					cmd.AddWithValue("p_TipoVeicoloSegnalazione1", p_TipoVeicoloSegnalazione1);
					cmd.AddWithValue("p_NoteSegnalazione1", p_NoteSegnalazione1);

					cmd.AddWithValue("p_EnumTipoLtsSegnalazione2", p_EnumTipoLtsSegnalazione2);
					cmd.AddWithValue("p_TipoVeicoloSegnalazione2", p_TipoVeicoloSegnalazione2);
					cmd.AddWithValue("p_NoteSegnalazione2", p_NoteSegnalazione2);

					cmd.AddWithValue("p_EnumTipoLtsSegnalazione3", p_EnumTipoLtsSegnalazione3);
					cmd.AddWithValue("p_TipoVeicoloSegnalazione3", p_TipoVeicoloSegnalazione3);
					cmd.AddWithValue("p_NoteSegnalazione3", p_NoteSegnalazione3);

					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						// cmd.Transaction = tr;
						try
						{
							cmd.ExecuteNonQuery();
							tr.Commit();
						}
						catch (OracleException ex)
						{
							// la chiave duplicata e` permessa perche` in load balancing
							// potrebbe essere avvivato prima l'altro servizio.
							if (ex.Number != 1)
								Log.Write(ex, "AccodaEvento");

							tr.Rollback();

							if (ex.Number != 1)
								throw ex;
						}
					}
				}
			}
		}

		public List<BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato> GetListaSorveglianzaPaginata(string sortColumns, int startRowIndex, int maximumRows, int idCoa, BLSorveglianza.SorvTipoLTS tipoSorv)
		{
			if (string.IsNullOrEmpty(sortColumns)) sortColumns = "Targa";

			string colName;
			string ascDesc;
			if (true)
			{
				string[] c = sortColumns.Split(' ');
				colName = c[0];
				ascDesc = "";
				if (c.Length == 2) ascDesc = c[1];
			}

			switch (colName.ToUpper())
			{
			case "TARGA":
				sortColumns = "TARGA {0}, DATAORARILEVAMENTO";
				break;
			case "NAZIONALITA":
				sortColumns = "NAZIONALITA  {0}, TARGA, DATAORARILEVAMENTO";
				break;

			case "TRC2PSTRADA":
				sortColumns = "TRC2PSTRADA {0}, DATAORARILEVAMENTO";
				break;

			case "TRC2PDESCRIZIONE":
				sortColumns = "TRC2PDESCRIZIONE {0}, DATAORARILEVAMENTO";
				break;

			case "TRC2PDIREZIONE":
				sortColumns = "TRC2PDIREZIONE {0}, DATAORARILEVAMENTO";
				break;

			case "ENUMTIPOVARCO":
				sortColumns = "ENUMTIPOVARCO {0}, DATAORARILEVAMENTO";
				break;

			case "DATAORARILEVAMENTO":
				sortColumns = "DATAORARILEVAMENTO {0}, TARGA";
				break;

			case "ENUMSTATOTRANSITO":
				sortColumns = "ENUMTIPOVARCO {0}, DATAORARILEVAMENTO";
				break;

			case "STATOALLARME":
				sortColumns = "ENUMTIPOVARCO {0}, DATAORARILEVAMENTO";
				break;

			case "ENUMCLASSEURGENZA":
				sortColumns = "ENUMTIPOVARCO {0}, DATAORARILEVAMENTO";
				break;
			}

			sortColumns = string.Format(sortColumns, ascDesc);


			using (OracleConnection cn = this.CreateConnection())
			{
				string g = @"
select
S.Targa,
S.Nazionalita,
T.DataOraRilevamento,
T.EnumTipoVarco          /*TipoVarco*/     EnumTipoVarco,
Strade.DESCRIZIONESTRADA TrC2pStrada,
C2p.DIREZIONE            /*Direzione*/     TrC2PDirezione,
C2p.DESCRIZIONE          TrC2PDescrizione,
T.EnumStatoTransito      /*StatoTransito*/ EnumStatoTransito,
E.DataOraInserimento,
E.IdEvento,
E.EnumStatoAllarme       /*StatoAllarme*/ StatoAllarme,
E.EnumClasseUrgenza      /*ClasseUrgenza*/EnumClasseUrgenza,
S.NoteSegnalazione1,
S.TipoVeicoloSegnalazione1,
S.EnumTipoLtsSegnalazione1,

PrecTsEv.DATAORAINSERIMENTO     PrecTsEvDataOraInserimento,
PrecTsEv.IDEVENTO               PrecTsEvIdEvento,
PrecTsEv.ENUMSTATOALLARME       /*StatoAllarme*/ PrecTsEvStatoAllarme,
T.PL_VEHICLE_TYPE

from SorveglianzaRes S

inner join EventiDaSegnalare E
on  E.Targa              = S.Targa
and E.Nazionalita        = S.Nazionalita
and E.DataOraInserimento = S.DataOraInserimento
and E.IdEvento           = S.IdEvento

inner join TransitiSuEvento T
on  T.Targa              = S.Targa
and T.Nazionalita        = S.Nazionalita
and T.DataOraRilevamento = S.DataOraRilevamento

inner join C2P
on C2P.IDC2P = T.IDC2P

inner join Strade
on Strade.CODICESTRADA = C2P.CODICESTRADA

left outer join EVENTIDASEGNALARE PrecTsEv
on  PrecTsEv.Targa              = S.Targa
and PrecTsEv.Nazionalita        = S.Nazionalita
and PrecTsEv.DataOraInserimento = S.PrecEvDataOraInserimento
and PrecTsEv.IdEvento           = S.PrecEvIdEvento

where 
S.IDCOA = :p_IDCOA 
and (:p_tipoSorv is null or S.EnumTipoLtsSegnalazione1 <> :p_tipoSorv)

order by
{0}
";

				using (OracleCommand cmd = PageQuery(cn, string.Format(g, sortColumns), startRowIndex, maximumRows))
				{
					cmd.AddWithValue(":p_idCoa", idCoa);

					switch (tipoSorv)
					{
					case BLSorveglianza.SorvTipoLTS.Tutti:
						cmd.AddWithValue("p_tipoSorv", (string)null);
						break;

					case BLSorveglianza.SorvTipoLTS.noA2:
						cmd.AddWithValue("p_tipoSorv", "A2");
						break;
					}


					List<BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato> ret = RecordReader<BLSorveglianza.TransitoSegnalatoSorveglianzaPaginato>(cmd);
					return ret;
				}
			}
		}


		public int GetListaSorveglianzaPaginataCount(int idCoa, BLSorveglianza.SorvTipoLTS tipoSorv)
		{
			using (OracleConnection cn = this.CreateConnection())
			{

				string g = @"
select
count(*)
from SorveglianzaRes S

inner join EventiDaSegnalare E
on  E.Targa              = S.Targa
and E.Nazionalita        = S.Nazionalita
and E.DataOraInserimento = S.DataOraInserimento
and E.IdEvento           = S.IdEvento

inner join TransitiSuEvento T
on  T.Targa              = S.Targa
and T.Nazionalita        = S.Nazionalita
and T.DataOraRilevamento = S.DataOraRilevamento

where 
S.IDCOA = :p_IDCOA 
and (:p_tipoSorv is null or S.EnumTipoLtsSegnalazione1 <> :p_tipoSorv)
";

				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = g;
					cmd.AddWithValue("p_idCoa", idCoa);

					switch (tipoSorv)
					{
					case BLSorveglianza.SorvTipoLTS.Tutti:
						cmd.AddWithValue("p_tipoSorv", (string)null);
						break;

					case BLSorveglianza.SorvTipoLTS.noA2:
						cmd.AddWithValue("p_tipoSorv", "A2");
						break;
					}


					cn.Open();
					object ret = cmd.ExecuteScalar();

					return Convert.ToInt32(ret);
				}
			}
		}


		public BLSorveglianza.TransitoSegnalatoPrecedente GetTransitoSegnalatoPrecedente(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = @"

select
TR.DataOraRilevamento     TrDataOraRilevamento, 
TR.ENUMTIPOVARCO          TrTipoVarco,
TR.ENUMSTATOTRANSITO      TrStatoTransito,
C2P.Descrizione           TrC2P,
C2p.Direzione             TrC2PDirezione,
Strade.DESCRIZIONESTRADA  TrC2pStrada,
UTTR.UserName             TrUserName,
TR.DATAORAPRESAINCARICO   TrDataOraPresaInCarico,
TR.DATAORACHIUSURA        TrDataOraChiusura,
TR.NOTECHIUSURA           TrNoteChiusura,

EV.ENUMSTATOALLARME       EvStatoAllarme,
UTEV.UserName             EvUserName,
EV.DATAORAPRESAINCARICO   EvDataOraPresaInCarico,
EV.DATAORACHIUSURA        EvDataOraChiusura,
EV.NOTECHIUSURA           EvNoteChiusura,

EV.DataOraInserimento     EvDataOraInserimento,
EV.IdEvento               EvIdEvento
from
(
	select
	*
	from
	(
		select
		*
		from  TransitiSuEvento TSEin
		where TSEin.DataOraRilevamento <  :p_DataOraRilevamentoMax
		and   TSEin.DataOraRilevamento >= :p_DataOraRilevamentoMin
		and   TSEin.Targa              =  :p_Targa
		and   TSEin.Nazionalita        =  :p_Nazionalita
		order by TSEin.DataOraRilevamento desc
	)
	where rownum <= 1
) TR

inner join TRANSITIEVENTI TREV
on  TREV.Targa              = TR.Targa
and TREV.Nazionalita        = TR.Nazionalita
and TREV.DataOraRilevamento = TR.DataOraRilevamento

inner join EVENTIDASEGNALARE EV
on  EV.Targa              = TREV.Targa
and EV.Nazionalita        = TREV.Nazionalita
and EV.DataOraInserimento = TREV.DataOraInserimento
and EV.IdEvento           = TREV.IdEvento

left outer join ASPNET_USERS UTEV
on  UTEV.pkid = EV.IdUtentePresaInCarico

left outer join ASPNET_USERS UTTR
on  UTTR.pkid = TR.IdUtentePresaInCarico

inner join C2P
on C2P.IDC2P = TR.IDC2P

inner join Strade
on Strade.CODICESTRADA = C2P.CODICESTRADA

where EV.ENUMTIPOEVENTO = 'TS'
";

					int min = ReadAppSettings.ToInt32("BLSorveglianza.GetTransitoSegnalatoPrecedente_Minuti", 60);

					DateTime p_DataOraRilevamentoMax = dataOraRilevamento;
					DateTime p_DataOraRilevamentoMin = dataOraRilevamento.Subtract(new TimeSpan(0, min, 0));

					cmd.AddWithValue("p_Targa", targa);
					cmd.AddWithValue("p_Nazionalita", nazionalita);
					cmd.AddWithValue("p_DataOraRilevamentoMax", p_DataOraRilevamentoMax);
					cmd.AddWithValue("p_DataOraRilevamentoMin", p_DataOraRilevamentoMin);

					List<BLSorveglianza.TransitoSegnalatoPrecedente> ret;
					ret = RecordReader<BLSorveglianza.TransitoSegnalatoPrecedente>(cmd);
					if (ret.Count == 1)
						return ret[0];
					return null;
				}
			}
		}


		public BLSorveglianza.StatisticaSorveglianza GetReportAllarmiTS(int idCoa, DateTime di, DateTime df)
		{
			string q = @"
select 
sum(TS.TotaleTransitiSegnalati)                                                     TotaleTransitiSegnalati,
sum(TS.AllarmiPositivi)                                                             AllarmiPositivi,
sum(TS.AllarmiNegativi)                                                             AllarmiNegativi,
sum(TS.AllarmiPositivi) + sum(TS.AllarmiNegativi)                                   AllarmiTrattati,
sum(TS.TotaleTransitiSegnalati) - sum(TS.AllarmiPositivi) - sum(TS.AllarmiNegativi) - sum(TS.AllarmiChiusiDalSistema) AllarmiNonTrattati,
sum(TS.AllarmiChiusiDalSistema)                                                     AllarmiChiusiDalSistema 
from
(
	select count(*) TotaleTransitiSegnalati, 0 AllarmiPositivi, 0 AllarmiNegativi, 0 AllarmiChiusiDalSistema
	from EVENTIDASEGNALARE
	where ENUMTIPOEVENTO = 'TS'
	and DATAORAINSERIMENTO >= :p_di
	and DATAORAINSERIMENTO <  :p_df
	and IDCOACOMPETENZA = :p_IdCoa
	and (ENUMSTATOALLARME='CNF' or ENUMSTATOALLARME='NCNF')
	-- and IDUTENTEPRESAINCARICO <> '04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46'

	union

	select 0 TotaleTransitiSegnalati, count(*) AllarmiPositivi, 0 AllarmiNegativi, 0 AllarmiChiusiDalSistema
	from EVENTIDASEGNALARE
	where ENUMTIPOEVENTO = 'TS'
	and DATAORAINSERIMENTO >= :p_di
	and DATAORAINSERIMENTO <  :p_df
	and ENUMSTATOALLARME='CNF'
	and IDCOACOMPETENZA = :p_IdCoa
	and IDUTENTEPRESAINCARICO <> '04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46'

	union

	select 0 TotaleTransitiSegnalati, 0 AllarmiPositivi, count(*) AllarmiNegativi, 0 AllarmiChiusiDalSistema
	from EVENTIDASEGNALARE
	where ENUMTIPOEVENTO = 'TS'
	and DATAORAINSERIMENTO >= :p_di
	and DATAORAINSERIMENTO <  :p_df
	and ENUMSTATOALLARME='NCNF'
	and IDCOACOMPETENZA = :p_IdCoa
	and IDUTENTEPRESAINCARICO <> '04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46'
	union

	select 0 TotaleTransitiSegnalati, 0 AllarmiPositivi, 0 AllarmiNegativi, count(*) AllarmiChiusiDalSistema
	from EVENTIDASEGNALARE
	where ENUMTIPOEVENTO = 'TS'
	and DATAORAINSERIMENTO >= :p_di
	and DATAORAINSERIMENTO <  :p_df
	and (ENUMSTATOALLARME='CNF' or ENUMSTATOALLARME='NCNF')
	and IDCOACOMPETENZA = :p_IdCoa
	and IDUTENTEPRESAINCARICO = '04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46'
) TS
";
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = q;

					cmd.AddWithValue("p_di", di);
					cmd.AddWithValue("p_df", df);
					cmd.AddWithValue("p_IdCoa", idCoa);

					List<BLSorveglianza.StatisticaSorveglianza> ret = new List<BLSorveglianza.StatisticaSorveglianza>(1);
					ret = RecordReader<BLSorveglianza.StatisticaSorveglianza>(cmd);
					return ret[0];
				}
			}

		}


		public List<BLSorveglianza.SegnalazioniAssociateAllEvento> GetSegnalazioniAssociate(
			string p_TARGA,
			string p_NAZIONALITA,
			 DateTime p_DATAORAInserimento)
		{

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"
select
ENUMTIPOLTS      EnumTipoLtsSegnalazione,
TAB_TIPO_VEICOLO TipoVeicoloSegnalazione,
Note             NoteSegnalazione
from Segnalazioni
where
    Targa = :p_Targa
and Nazionalita = :p_Nazionalita
and DataOraInserimento = :p_DataOraInserimento
";

					cmd.CommandText = q;
					cmd.AddWithValue("p_Targa", p_TARGA);
					cmd.AddWithValue("p_Nazionalita", p_NAZIONALITA);
					cmd.AddWithValue("p_DataOraInserimento", p_DATAORAInserimento);

					List<BLSorveglianza.SegnalazioniAssociateAllEvento> ret = RecordReader<BLSorveglianza.SegnalazioniAssociateAllEvento>(cmd);
					return ret;
				}
			}
		}

	}
}

