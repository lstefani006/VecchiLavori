using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using Oracle.DataAccess.Client;
#else
#endif

namespace ITRS_BL.Oracle
{
	class DalCoa : DalBase, IDalCoa
	{
		#region IDalCoa Members
		public List<Coa> GetLista(string columnsSort)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT IDCOA, DESCRIZIONE FROM COA order by " + columnsSort;
					cmd.CommandType = CommandType.Text;

					int colIDCOA = -1;
					int colDESCRIZIONE = -1;

					RecordColumnBinder<Coa> rcb = delegate(OracleDataReader rd)
					{
						colIDCOA = rd.GetOrdinal("IDCOA");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
					};

					RecordBinder<Coa> rt = delegate(OracleDataReader rd, Coa t)
					{
						t.IdCOA = (int)rd.GetDouble(colIDCOA);
						t.Descrizione = rd.GetString(colDESCRIZIONE);
					};

					cn.Open();
					return this.RecordReader<Coa>(cmd, rt, rcb);
				}
			}
		}



		public Coa GetRecord(Coa t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"SELECT IDCOA, DESCRIZIONE FROM COA where ";
					q += "IDCOA = :P_IDCOA";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					int colIDCOA = -1;
					int colDESCRIZIONE = -1;

					cmd.AddWithValue("P_IDCOA", t.IdCOA);

					RecordColumnBinder<Coa> rcb = delegate(OracleDataReader rd)
					{
						colIDCOA = rd.GetOrdinal("IDCOA");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
					};

					RecordBinder<Coa> rt = delegate(OracleDataReader rd, Coa tb)
					{
						tb.IdCOA = (int)rd.GetDouble(colIDCOA);
						tb.Descrizione = rd.GetString(colDESCRIZIONE);
					};

					List<Coa> r = this.RecordReader<Coa>(cmd, rt, rcb);
					if (r.Count == 0) return null;
					return r[0];
				}
			}
		}

		public void Cancella(Coa t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"DELETE from COA where ";
					q += "IDCOA = :P_IDCOA";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue("P_IDCOA", t.IdCOA);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Aggiorna(Coa t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"UPDATE COA SET ";
					q += "DESCRIZIONE = :P_DESCRIZIONE";
					q += " WHERE ";

					q += "IDCOA = :P_IDCOA";
					cmd.CommandText = q;

					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DESCRIZIONE", t.Descrizione);
					cmd.AddWithValue("P_IDCOA", t.IdCOA);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Inserisci(Coa t)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						string q = "INSERT INTO COA (";
						q += "IDCOA";
						q += ", DESCRIZIONE";
						q += ") VALUES (";
						q += ":P_IDCOA";
						q += ", :P_DESCRIZIONE";
						q += ")";

						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue("P_IDCOA", t.IdCOA);
						cmd.AddWithValue("P_DESCRIZIONE", t.Descrizione);

						cn.Open();
						cmd.ExecuteNonQuery();
					}
				}
			}
			catch (OracleException ex)
			{
				if (ex.Number == 1)
					throw new ApplicationException("Record gia` presente", ex);
				else
					throw;
			}
		}

		#endregion
	}
}
