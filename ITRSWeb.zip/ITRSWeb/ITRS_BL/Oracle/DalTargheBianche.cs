using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using Oracle.DataAccess.Client;
#else
#endif

namespace ITRS_BL.Oracle
{
	class DalTargheBianche : DalBase, IDalTargheBianche
	{
		#region IDalTargheBianche Members
		public List<TargheBianche> GetLista(string columnsSort, int startRowIndex, int maximumRows, DateTime validoIl)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"
SELECT 
TARGA, 
NAZIONALITA, 
IDLTS, 
DESCRIZIONE, 
DATAORAINIZIOVALIDITA, 
DATAORAFINEVALIDITA, 
MOTIVO 
FROM 
LTBIANCHE 
where 
DATAORAINIZIOVALIDITA <= :p_validoIl and 
DATAORAFINEVALIDITA >= :p_validoIl
order by " + columnsSort;
					cmd.CommandType = CommandType.Text;
					this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					cmd.AddWithValue(":p_validoIl", validoIl);

					int colTARGA = -1;
					int colNAZIONALITA = -1;
					int colIDLTS = -1;
					int colDESCRIZIONE = -1;
					int colDATAORAINIZIOVALIDITA = -1;
					int colDATAORAFINEVALIDITA = -1;
					int colMOTIVO = -1;

					RecordColumnBinder<TargheBianche> rcb = delegate(OracleDataReader rd)
					{
						colTARGA = rd.GetOrdinal("TARGA");
						colNAZIONALITA = rd.GetOrdinal("NAZIONALITA");
						colIDLTS = rd.GetOrdinal("IDLTS");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colDATAORAINIZIOVALIDITA = rd.GetOrdinal("DATAORAINIZIOVALIDITA");
						colDATAORAFINEVALIDITA = rd.GetOrdinal("DATAORAFINEVALIDITA");
						colMOTIVO = rd.GetOrdinal("MOTIVO");
					};

					RecordBinder<TargheBianche> rt = delegate(OracleDataReader rd, TargheBianche t)
					{
						t.Targa = rd.GetString(colTARGA);
						t.Nazionalita = rd.GetString(colNAZIONALITA);
						t.IdLTS = (int)rd.GetDecimal(colIDLTS);
						t.Descrizione = rd.GetString(colDESCRIZIONE);
						t.TsInizioValidita = rd.GetDateTime(colDATAORAINIZIOVALIDITA);
						t.TsFineValidita = rd.GetDateTime(colDATAORAFINEVALIDITA);

						if (rd.IsDBNull(colMOTIVO))
							t.Motivo = null;
						else
							t.Motivo = rd.GetString(colMOTIVO);

					};

					cn.Open();
					return this.RecordReader<TargheBianche>(cmd, rt, rcb);
				}
			}
		}


		public List<TargheBianche> GetLista(string columnsSort, DateTime validoIl)
		{
			if (string.IsNullOrEmpty(columnsSort))
				columnsSort = "TARGA";

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"
SELECT 
TARGA, 
NAZIONALITA, 
IDLTS, 
DESCRIZIONE, 
DATAORAINIZIOVALIDITA, 
DATAORAFINEVALIDITA, 
MOTIVO 
FROM 
LTBIANCHE 
where 
DATAORAINIZIOVALIDITA <= :p_validoIl and 
DATAORAFINEVALIDITA >= :p_validoIl
order by " + columnsSort;
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue(":p_validoIl", validoIl);

					int colTARGA = -1;
					int colNAZIONALITA = -1;
					int colIDLTS = -1;
					int colDESCRIZIONE = -1;
					int colDATAORAINIZIOVALIDITA = -1;
					int colDATAORAFINEVALIDITA = -1;
					int colMOTIVO = -1;

					RecordColumnBinder<TargheBianche> rcb = delegate(OracleDataReader rd)
					{
						colTARGA = rd.GetOrdinal("TARGA");
						colNAZIONALITA = rd.GetOrdinal("NAZIONALITA");
						colIDLTS = rd.GetOrdinal("IDLTS");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colDATAORAINIZIOVALIDITA = rd.GetOrdinal("DATAORAINIZIOVALIDITA");
						colDATAORAFINEVALIDITA = rd.GetOrdinal("DATAORAFINEVALIDITA");
						colMOTIVO = rd.GetOrdinal("MOTIVO");
					};

					RecordBinder<TargheBianche> rt = delegate(OracleDataReader rd, TargheBianche t)
					{
						t.Targa = rd.GetString(colTARGA);
						t.Nazionalita = rd.GetString(colNAZIONALITA);
						t.IdLTS = (int)rd.GetDecimal(colIDLTS);
						t.Descrizione = rd.GetString(colDESCRIZIONE);
						t.TsInizioValidita = rd.GetDateTime(colDATAORAINIZIOVALIDITA);
						t.TsFineValidita = rd.GetDateTime(colDATAORAFINEVALIDITA);
						if (rd.IsDBNull(colMOTIVO))
							t.Motivo = null;
						else
							t.Motivo = rd.GetString(colMOTIVO);
					};

					cn.Open();
					return this.RecordReader<TargheBianche>(cmd, rt, rcb);
				}
			}
		}


		public int GetCount(DateTime validoIl)
		{
			try
			{
				string q = @"
select 
count(*) 
from 
LTBIANCHE
where 
DATAORAINIZIOVALIDITA <= :p_validoIl and 
DATAORAFINEVALIDITA >= :p_validoIl
";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue(":p_validoIl", validoIl);

						return (int)cmd.ExecuteScalar<decimal>();
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("DalTargheBianche.GetCount", ex);
			}
		}


		public TargheBianche GetRecord(TargheBianche t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"SELECT TARGA, 
										NAZIONALITA,	
										IDLTS, 
										DESCRIZIONE, 
										DATAORAINIZIOVALIDITA, 
										DATAORAFINEVALIDITA, 
										MOTIVO FROM 
										LTBIANCHE where ";
					q += "TARGA = :P_TARGA";
					q += " and NAZIONALITA = :P_NAZIONALITA";
					q += " and IDLTS = :P_IDLTS";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					int colTARGA = -1;
					int colNAZIONALITA = -1;
					int colIDLTS = -1;
					int colDESCRIZIONE = -1;
					int colDATAORAINIZIOVALIDITA = -1;
					int colDATAORAFINEVALIDITA = -1;
					int colMOTIVO = -1;

					cmd.AddWithValue("P_TARGA", t.Targa);
					cmd.AddWithValue("P_NAZIONALITA", t.Nazionalita);
					cmd.AddWithValue("P_IDLTS", t.IdLTS);

					RecordColumnBinder<TargheBianche> rcb = delegate(OracleDataReader rd)
					{
						colTARGA = rd.GetOrdinal("TARGA");
						colNAZIONALITA = rd.GetOrdinal("NAZIONALITA");
						colIDLTS = rd.GetOrdinal("IDLTS");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colDATAORAINIZIOVALIDITA = rd.GetOrdinal("DATAORAINIZIOVALIDITA");
						colDATAORAFINEVALIDITA = rd.GetOrdinal("DATAORAFINEVALIDITA");
						colMOTIVO = rd.GetOrdinal("MOTIVO");
					};

					RecordBinder<TargheBianche> rt = delegate(OracleDataReader rd, TargheBianche tb)
					{
						tb.Targa = rd.GetString(colTARGA);
						tb.Nazionalita = rd.GetString(colNAZIONALITA);
						tb.IdLTS = (int)rd.GetDouble(colIDLTS);
						tb.Descrizione = rd.GetString(colDESCRIZIONE);
						tb.TsInizioValidita = rd.GetDateTime(colDATAORAINIZIOVALIDITA);
						tb.TsFineValidita = rd.GetDateTime(colDATAORAFINEVALIDITA);

						if (rd.IsDBNull(colMOTIVO))
							tb.Motivo = null;
						else
							tb.Motivo = rd.GetString(colMOTIVO);
					};

					List<TargheBianche> r = this.RecordReader<TargheBianche>(cmd, rt, rcb);
					if (r.Count == 0) return null;
					return r[0];
				}
			}
		}

		public void Cancella(TargheBianche t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"DELETE from LTBIANCHE where ";
					q += "TARGA = :P_TARGA";
					q += " and NAZIONALITA = :P_NAZIONALITA";
					q += " and IDLTS = :P_IDLTS";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue("P_TARGA", t.Targa);
					cmd.AddWithValue("P_NAZIONALITA", t.Nazionalita);
					cmd.AddWithValue("P_IDLTS", t.IdLTS);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public bool EsisteEntryValida(string targa, string nazionalita, out int idLTs)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.AddWithValue("P_TARGA", targa);
					cmd.AddWithValue("P_NAZIONALITA", nazionalita);
					cmd.AddWithValue("p_Now", DateTime.Now.Date);

					cn.Open();

					cmd.CommandText = @"
select 

max(IDLTS) idlts
 
from LTBIANCHE 
where 
Targa = :p_Targa and
Nazionalita = :p_Nazionalita and
DATAORAINIZIOVALIDITA <= :p_Now and 
DATAORAFINEVALIDITA >= :p_Now";

					idLTs = -1;
					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						while (rd.Read())
						{
							if (rd.IsDBNull(0))
								return false;

							idLTs = Convert.ToInt32(rd[0]);
							return true;
						}

						return false;
					}
				}
			}
		}

		public bool EsisteEntry(string targa, string nazionalita, out int idLTs)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.AddWithValue("P_TARGA", targa);
					cmd.AddWithValue("P_NAZIONALITA", nazionalita);

					cn.Open();

					cmd.CommandText = @"
select 

max(IDLTS) idlts
 
from LTBIANCHE 
where 
Targa = :p_Targa and
Nazionalita = :p_Nazionalita";

					idLTs = -1;
					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						while (rd.Read())
						{
							if (rd.IsDBNull(0))
								return false;

							idLTs = Convert.ToInt32(rd[0]);
							return true;
						}

						return false;
					}
				}
			}
		}


		public void Aggiorna(TargheBianche t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"UPDATE LTBIANCHE SET ";
					q += "DESCRIZIONE = :P_DESCRIZIONE";
					q += ", DATAORAINIZIOVALIDITA = :P_DATAORAINIZIOVALIDITA";
					q += ", DATAORAFINEVALIDITA = :P_DATAORAFINEVALIDITA";
					q += ", MOTIVO = :P_MOTIVO";
					q += " WHERE ";

					q += "TARGA = :P_TARGA";
					q += " and NAZIONALITA = :P_NAZIONALITA";
					q += " and IDLTS = :P_IDLTS";
					cmd.CommandText = q;

					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DESCRIZIONE", t.Descrizione);
					cmd.AddWithValue("P_DATAORAINIZIOVALIDITA", t.TsInizioValidita);
					cmd.AddWithValue("P_DATAORAFINEVALIDITA", t.TsFineValidita);
					cmd.AddWithValue("P_MOTIVO", t.Motivo);
					cmd.AddWithValue("P_TARGA", t.Targa);
					cmd.AddWithValue("P_NAZIONALITA", t.Nazionalita);
					cmd.AddWithValue("P_IDLTS", t.IdLTS);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Inserisci(TargheBianche t)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						string q = "INSERT INTO LTBIANCHE (";
						q += "TARGA";
						q += ", NAZIONALITA";
						q += ", IDLTS";
						q += ", DESCRIZIONE";
						q += ", DATAORAINIZIOVALIDITA";
						q += ", DATAORAFINEVALIDITA";
						q += ", MOTIVO";
						q += ") VALUES (";
						q += ":P_TARGA";
						q += ", :P_NAZIONALITA";
						q += ", SEQ_LTSB.nextval";
						q += ", :P_DESCRIZIONE";
						q += ", :P_DATAORAINIZIOVALIDITA";
						q += ", :P_DATAORAFINEVALIDITA";
						q += ", :P_MOTIVO";
						q += ")";

						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue("P_TARGA", t.Targa);
						cmd.AddWithValue("P_NAZIONALITA", t.Nazionalita);
						cmd.AddWithValue("P_DESCRIZIONE", t.Descrizione);
						cmd.AddWithValue("P_DATAORAINIZIOVALIDITA", t.TsInizioValidita);
						cmd.AddWithValue("P_DATAORAFINEVALIDITA", t.TsFineValidita);
						cmd.AddWithValue("P_MOTIVO", t.Motivo);

						cn.Open();
						cmd.ExecuteNonQuery();
					}
				}
			}
			catch (OracleException ex)
			{
				if (ex.Number == 1)
					throw new ApplicationException("Record gia` presente", ex);
				else
					throw;
			}
		}

		#endregion
	}
}
