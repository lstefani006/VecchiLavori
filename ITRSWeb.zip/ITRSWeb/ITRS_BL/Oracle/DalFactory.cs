using System;
using System.Data;
using System.Text;
using System.Collections.Generic;
using ITRS_BL.IDal;


namespace ITRS_BL.Oracle
{
	public class DalFactory : IDalFactory 
	{
		public IDalTransiti CreateDalTransiti() { return new DalTransiti(); }
		public IDalIndagini CreateDalIndagini() { return new DalIndagini(); }
		public IDalQueueJobs CreateDalQueueJobs() { return new DalQueueJobs(); }
		public IDalStrada CreateDalStrade() { return new DalStrada(); }
		public IDalC2P CreateDalC2P() { return new DalC2P(); }
		public IDalCoa CreateDalCoa() { return new DalCoa(); }
		public IDalTargheBianche CreateDalTargheBianche() { return new DalTargheBianche(); }
		public IDalTratta CreateDalTratta() { return new DalTratta(); }
		public IDalInterventi CreateDalInterventi() { return new DalInterventi(); }
		public IDalEventi CreateDalEventi() { return new DalEventi(); }
		public IDalParametri CreateDalParametri() { return new DalParametri(); }
		public IDalLog CreateDalLog() { return new DalLog(); }
		public IDalStatistiche CreateDalStatistiche() { return new DalStatistiche(); }
		public IDalSegnalazioni CreateDalSegnalazioni() { return new DalSegnalazioni(); }
		public IDalSorveglianza CreateDalSorveglianza() { return new DalSorveglianza(); }
		public IDalLTS CreateDalLTS() { return new DalLTS(); }
		public IDalLTSImport CreateDalLTSImport() { return new DalLTSImport();  }
		public IDalLock CreateDalLock(string lockId) { return new OracleLock(lockId); }
	}
}
