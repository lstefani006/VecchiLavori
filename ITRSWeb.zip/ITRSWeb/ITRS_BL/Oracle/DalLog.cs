using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Diagnostics;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

using System.Data.Common;


using ITRS_BL.IDal;
using ITRS_BL.Utility;

namespace ITRS_BL.Oracle
{
	class DalLog : DalBase, IDalLog
	{
		public void Add(string application, string logType, string message, string ex)
		{
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = "ITRS_SMLOG.AddMessage";
						cmd.CommandType = CommandType.StoredProcedure;

						cmd.AddWithValue("p_Application", application);
						cmd.AddWithValue("p_Type", logType);

						if (message.Length > 4000)
							message = message.Substring(0, 4000);
						cmd.AddWithValue("p_Message", message);

						if (ex != null && ex.Length > 4000)
							ex = ex.Substring(0, 4000);
						cmd.AddWithValue("p_Exception", ex);

						cmd.ExecuteNonQuery();
					}

					tr.Commit();
				}
			}
		}

		public List<BLLog.RecordLog> GetLogs()
		{
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = @"
					SELECT * FROM
					(
					select 
					smID,
					smApplication,
					smMessage,
					smException,
					smType,
					smTS
					from 
					smLog 
					order by smTS desc, smID desc
					)
					where rownum <= 100
					";
					cmd.CommandType = CommandType.Text;

					return RecordReader<BLLog.RecordLog>(cmd);
				}
			}

		}

		public void PurgeUserActivity(DateTime tsPurgeUntil)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = @"delete from USERLOG where TSATTIVITA < :t";

					cmd.AddWithValue(":t", tsPurgeUntil);
					cmd.CommandType = CommandType.Text;

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void AddUserActivity(string IdUtenteAttivita, TipoAttivita TipoAttivita, string DescrizioneAttivita)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = @"
INSERT INTO ITRS.USERLOG
(ID, TSATTIVITA, TIPOATTIVITA, DESCATTIVITA, IDUTENTEATTIVITA) 
VALUES
(SEQ_USERLOG.nextval, SYSDATE, :p_TipoAttivita, :p_DescAttivita, :p_IdUtenteAttivita)";

					cmd.AddWithValue("p_IdUtenteAttivita", IdUtenteAttivita);
					cmd.AddWithValue("p_TipoAttivita", TipoAttivita.ToString());
					cmd.AddWithValue("p_DescAttivita", DescrizioneAttivita);
					cmd.CommandType = CommandType.Text;

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}


        public List<BLLog.UserLogData> GetUserActivity(string sortColumns, int startRowIndex, int maximumRows, DateTime? da, DateTime? a, string utente, string tipo)
		{
            if (utente.Trim() == "TUTTI")
                utente = "%";

            if (tipo.Trim() == "TUTTI")
                tipo = "%";

			using (OracleConnection cn = CreateConnection())
			{
				if (string.IsNullOrEmpty(sortColumns))
					sortColumns = "ts";

				switch (sortColumns.ToLower())
				{
				case "username":
					sortColumns = "username asc, id asc";
					break;
				case "username desc":
					sortColumns = "username desc, id asc";
					break;

				case "ts":
					sortColumns = "id asc";
					break;
				case "ts desc":
					sortColumns = "id desc";
					break;

				case "descrizione":
					sortColumns = "descattivita asc, id asc ";
					break;
				case "descrizione desc":
					sortColumns = "descattivita desc, id asc ";
					break;

				case "tipo":
					sortColumns = "tipoattivita asc, id asc";
					break;
				case "tipo desc":
					sortColumns = "tipoattivita desc, id asc";
					break;

				default:
					Debug.Assert(false);
					break;
				}

                string q;

                if (utente.Trim() != string.Empty)
                {

                    q = @"
select 
TSATTIVITA       as ts, 
TIPOATTIVITA     as Tipo, 
DESCATTIVITA     as Descrizione, 
IdUtenteAttivita as UserName
FROM USERLOG
where 
    ((:da is null) or TsAttivita >= :da)
and ((:a  is null) or TsAttivita < :a)
and (TIPOATTIVITA like :tipo)
and (IdUtenteAttivita LIKE :utente)
order by
{0}
";
                }
                else 
                {

                    q = @"
select 
TSATTIVITA       as ts, 
TIPOATTIVITA     as Tipo, 
DESCATTIVITA     as Descrizione, 
IdUtenteAttivita as UserName
FROM USERLOG
where 
    ((:da is null) or TsAttivita >= :da)
and ((:a  is null) or TsAttivita < :a)
and (TIPOATTIVITA LIKE :tipo)
order by
{0}
";
                
                }

				if (a.HasValue)
					a = a.Value.Date.AddDays(1);

				using (OracleCommand cmd = PageQuery(cn, string.Format(q, sortColumns), startRowIndex, maximumRows))
				{
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue("da", da);
                    cmd.AddWithValue("a", a);
                    cmd.AddWithValue("tipo", tipo);

                    if (utente.Trim() != string.Empty)
                        cmd.AddWithValue("utente", utente);

					return RecordReader<BLLog.UserLogData>(cmd);
				}
			}

		}

		public int GetUserActivityCount(DateTime? da, DateTime? a, string utente, string tipo)
		{
            if (utente.Trim() == "TUTTI")
                utente = "%";

            if (tipo.Trim() == "TUTTI")
                tipo = "%";

			using (OracleConnection cn = CreateConnection())
			{
                string q;

                if (utente.Trim() != string.Empty)
                {
                    q = @"
select 
count(*) aaaa
FROM USERLOG
where 
    ((:da is null) or TsAttivita >= :da)
and ((:a  is null) or TsAttivita < :a)
and TIPOATTIVITA LIKE :tipo 
and (IdUtenteAttivita LIKE :utente)
";
                }
                else
                {

                    q = @"
select 
count(*) aaaa
FROM USERLOG
where 
    ((:da is null) or TsAttivita >= :da)
and ((:a  is null) or TsAttivita < :a)
and TIPOATTIVITA LIKE :tipo 
";
                }

				if (a.HasValue)
					a = a.Value.Date.AddDays(1);


				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = q;

					cmd.AddWithValue("da", da);
                    cmd.AddWithValue("a", a);
                    cmd.AddWithValue("tipo", tipo);

                    if (utente.Trim() != string.Empty)
                        cmd.AddWithValue("utente", utente);

					cn.Open();

					object r = cmd.ExecuteScalar();
					return Convert.ToInt32(r);
				}
			}
		}

        public List<string> GetAllTipi() 
        {
            List<string> tipi = new List<string>();
            tipi.Add("TUTTI");

			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = @"
SELECT DISTINCT TIPOATTIVITA AS TIPO
FROM USERLOG      
ORDER BY tipo";

					cmd.CommandType = CommandType.Text;
                    cn.Open();

                    using (OracleDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                            tipi.Add(r["TIPO"] as string);                        
                    }
				}
			}

            return (tipi.Count > 0) ? tipi : null;
    
        }

        public List<string> GetAllUtenti() 
        {
            List<string> utenti = new List<string>();
            utenti.Add("TUTTI");

            using (OracleConnection cn = CreateConnection())
            {
                using (OracleCommand cmd = CreateCommand(cn))
                {
                    cmd.CommandText = @"
SELECT DISTINCT IDUTENTEATTIVITA as USERNAME
FROM USERLOG
ORDER BY IDUTENTEATTIVITA";

                    cmd.CommandType = CommandType.Text;
                    cn.Open();

                    using (OracleDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                            utenti.Add((r["USERNAME"] != DBNull.Value)?r["USERNAME"] as string:string.Empty);
                    }
                }
            }

            return (utenti.Count > 0)?utenti:null;
        }

		public List<BLLog.UserLogData> GetAttivitaDelGiorno(DateTime attivitaDelGiorno, string tipoAttivita)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = @"
select
TSATTIVITA       as ts, 
TIPOATTIVITA     as Tipo, 
DESCATTIVITA     as Descrizione, 
IdUtenteAttivita as UserName
from USERLOG
where 
TIPOATTIVITA = :ta
and trunc(TSATTIVITA) = :d
order by id desc
";

					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue(":ta", tipoAttivita);
					cmd.AddWithValue(":d", attivitaDelGiorno.Date);

					return RecordReader<BLLog.UserLogData>(cmd);
				}
			}
		}
	}
}
