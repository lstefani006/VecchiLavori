using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using ODP=Oracle.DataAccess.Client;
#else
#endif

namespace ITRS_BL.Oracle
{
	public class prova
	{
		public static void P(string connectionString)
		{
			ODP.OracleConnection cn = new ODP.OracleConnection(connectionString);

			using (cn)
			{
				cn.Open();
				ODP.OracleCommand cmd = cn.CreateCommand();

				cmd.CommandText = @"
SELECT
QMGR_NAME,
CODICESTRADA,
KM,
IDC2P,
IDCOA,
DESCRIZIONE,
IDTRATTAPREC,
IDTRATTASUCC,
DIREZIONE,
TPREC.DESCRIZIONE DESCRTRATTAPREC,
TSUCC.DESCRIZIONE DESCRTRATTASUCC
FROM C2P
INNER JOIN TRATTE TPREC ON
TPREC.IDTRATTA = IDTRATTAPREC
INNER JOIN TRATTE TSUCC ON
TSUCC.IDTRATTA = IDTRATTASUCC
"
;
				//cmd.CommandText = "select * from c2p";
				//OracleDataAdapter da = new OracleDataAdapter(cmd);
				//OracleCommandBuilder cb = new OracleCommandBuilder(da);
				//da.Fill(new DataSet());

				using (ODP.OracleDataReader rd = cmd.ExecuteReader(CommandBehavior.SchemaOnly | CommandBehavior.KeyInfo))
				{
					StreamWriter sw = File.CreateText("c:\\leo.csv");

					DataTable dt = rd.GetSchemaTable();

					dt.WriteXml("c:\\leo.xml");
					dt.WriteXmlSchema("c:\\leo.xsl");

					for (int c = 0; c < dt.Columns.Count; ++c)
						sw.Write("{0};", dt.Columns[c].ColumnName);
					sw.WriteLine();

					for (int r = 0; r < dt.Rows.Count; ++r)
					{
						for (int c = 0; c < dt.Columns.Count; ++c)
							sw.Write("{0};", dt.Rows[r][c]);
						sw.WriteLine();
					}
					sw.Close();

					while (rd.Read())
					{
						for (int i = 0; i < rd.FieldCount; ++i)
						{
							if (!rd.IsDBNull(i))
							{
								object obj = rd[i];
								obj.ToString();
							}
						}
					}
				}
			}
		}


		public static void Q(string connectionString)
		{
			ODP.OracleConnection cn = new ODP.OracleConnection(connectionString);

			using (cn)
			{
				cn.Open();
				ODP.OracleCommand cmd = cn.CreateCommand();


				cmd.CommandText = @"
SELECT
QMGR_NAME,
CODICESTRADA,
KM,
IDC2P,
IDCOA,
DESCRIZIONE,
IDTRATTAPREC,
IDTRATTASUCC,
DIREZIONE,
TPREC.DESCRIZIONE DESCRTRATTAPREC,
TSUCC.DESCRIZIONE DESCRTRATTASUCC
FROM C2P
INNER JOIN TRATTE TPREC ON
TPREC.IDTRATTA = IDTRATTAPREC
INNER JOIN TRATTE TSUCC ON
TSUCC.IDTRATTA = IDTRATTASUCC
"
;
				//cmd.CommandText = "select * from c2p";
				ODP.OracleDataAdapter da = new ODP.OracleDataAdapter(cmd);
				ODP.OracleCommandBuilder cb = new ODP.OracleCommandBuilder(da);
				//da.Fill(new DataSet())

				da.MissingSchemaAction = MissingSchemaAction.AddWithKey; ;

				DataSet ds = new DataSet();
				da.FillSchema(ds, SchemaType.Source, "FILES");
				ds.WriteXmlSchema("c:\\leo2.xsl");
				da.Fill(ds);
				ds.WriteXml("c:\\leo2.xml");


				// solo per le SP (meglio che niente)
				ODP.OracleCommandBuilder.DeriveParameters(cmd);


			}
		}
	}


	class DalTratta : DalBase, IDalTratta
	{
		#region IDalTratta Members
		public List<Tratta> GetLista(string columnsSort)
		{

			using (ODP.OracleConnection cn = CreateConnection())
			{
				// prova.Q(cn.ConnectionString);

				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT IDTRATTA, LUNGHEZZAKM, TEMPOMINPERCORRENZASECONDI, DESCRIZIONE, CODICESTRADA, DIREZIONE FROM TRATTE order by " + columnsSort;
					cmd.CommandType = CommandType.Text;

					int colIDTRATTA = -1;
					int colLUNGHEZZAKM = -1;
					int colTEMPOMINPERCORRENZASECONDI = -1;
					int colDESCRIZIONE = -1;
					int colCODICESTRADA = -1;
					int colDIREZIONE = -1;

					RecordColumnBinder<Tratta> rcb = delegate(ODP.OracleDataReader rd)
					{
						colIDTRATTA = rd.GetOrdinal("IDTRATTA");
						colLUNGHEZZAKM = rd.GetOrdinal("LUNGHEZZAKM");
						colTEMPOMINPERCORRENZASECONDI = rd.GetOrdinal("TEMPOMINPERCORRENZASECONDI");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colCODICESTRADA = rd.GetOrdinal("CODICESTRADA");
						colDIREZIONE = rd.GetOrdinal("DIREZIONE");
					};

					RecordBinder<Tratta> rt = delegate(ODP.OracleDataReader rd, Tratta t)
					{
						t.IdTratta = (int)rd.GetDouble(colIDTRATTA);
						t.LunghezzaKm = rd.GetDouble(colLUNGHEZZAKM);
						t.TempoMinPercorrenzaSecondi = (int)rd.GetDouble(colTEMPOMINPERCORRENZASECONDI);
						t.Descrizione = rd.GetString(colDESCRIZIONE);
						t.CodiceStrada = rd.GetString(colCODICESTRADA);
						t.Direzione = rd.GetString(colDIREZIONE);
					};

					cn.Open();
					return this.RecordReader<Tratta>(cmd, rt, rcb);
				}
			}
		}



		public Tratta GetRecord(Tratta t)
		{
			using (ODP.OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"SELECT IDTRATTA, LUNGHEZZAKM, TEMPOMINPERCORRENZASECONDI, DESCRIZIONE, CODICESTRADA, DIREZIONE FROM TRATTE where ";
					q += "IDTRATTA = :P_IDTRATTA";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					int colIDTRATTA = -1;
					int colLUNGHEZZAKM = -1;
					int colTEMPOMINPERCORRENZASECONDI = -1;
					int colDESCRIZIONE = -1;
					int colCODICESTRADA = -1;
					int colDIREZIONE = -1;

					cmd.AddWithValue("P_IDTRATTA", t.IdTratta);

					RecordColumnBinder<Tratta> rcb = delegate(ODP.OracleDataReader rd)
					{
						colIDTRATTA = rd.GetOrdinal("IDTRATTA");
						colLUNGHEZZAKM = rd.GetOrdinal("LUNGHEZZAKM");
						colTEMPOMINPERCORRENZASECONDI = rd.GetOrdinal("TEMPOMINPERCORRENZASECONDI");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colCODICESTRADA = rd.GetOrdinal("CODICESTRADA");
						colDIREZIONE = rd.GetOrdinal("DIREZIONE");
					};

					RecordBinder<Tratta> rt = delegate(ODP.OracleDataReader rd, Tratta tb)
					{
						tb.IdTratta = (int)rd.GetDouble(colIDTRATTA);
						tb.LunghezzaKm = rd.GetDouble(colLUNGHEZZAKM);
						tb.TempoMinPercorrenzaSecondi = (int)rd.GetDouble(colTEMPOMINPERCORRENZASECONDI);
						tb.Descrizione = rd.GetString(colDESCRIZIONE);
						tb.CodiceStrada = rd.GetString(colCODICESTRADA);
						tb.Direzione = rd.GetString(colDIREZIONE);
					};

					List<Tratta> r = this.RecordReader<Tratta>(cmd, rt, rcb);
					if (r.Count == 0) return null;
					return r[0];
				}
			}
		}

		public void Cancella(Tratta t)
		{
			using (ODP.OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"DELETE from TRATTE where ";
					q += "IDTRATTA = :P_IDTRATTA";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue("P_IDTRATTA", t.IdTratta);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Aggiorna(Tratta t)
		{
			using (ODP.OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"UPDATE TRATTE SET ";
					q += "LUNGHEZZAKM = :P_LUNGHEZZAKM";
					q += ", TEMPOMINPERCORRENZASECONDI = :P_TEMPOMINPERCORRENZASECONDI";
					q += ", DESCRIZIONE = :P_DESCRIZIONE";
					q += ", CODICESTRADA = :P_CODICESTRADA";
					q += ", DIREZIONE = :P_DIREZIONE";
					q += " WHERE ";

					q += "IDTRATTA = :P_IDTRATTA";
					cmd.CommandText = q;

					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_LUNGHEZZAKM", t.LunghezzaKm);
					cmd.AddWithValue("P_TEMPOMINPERCORRENZASECONDI", t.TempoMinPercorrenzaSecondi);
					cmd.AddWithValue("P_DESCRIZIONE", t.Descrizione);
					cmd.AddWithValue("P_CODICESTRADA", t.CodiceStrada);
					cmd.AddWithValue("P_DIREZIONE", t.Direzione);
					cmd.AddWithValue("P_IDTRATTA", t.IdTratta);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Inserisci(Tratta t)
		{
			try
			{
				using (ODP.OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						string q = "INSERT INTO TRATTE (";
						q += "IDTRATTA";
						q += ", LUNGHEZZAKM";
						q += ", TEMPOMINPERCORRENZASECONDI";
						q += ", DESCRIZIONE";
						q += ", CODICESTRADA";
						q += ", DIREZIONE";
						q += ") VALUES (";
						q += ":P_IDTRATTA";
						q += ", :P_LUNGHEZZAKM";
						q += ", :P_TEMPOMINPERCORRENZASECONDI";
						q += ", :P_DESCRIZIONE";
						q += ", :P_CODICESTRADA";
						q += ", :P_DIREZIONE";
						q += ")";

						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue("P_IDTRATTA", t.IdTratta);
						cmd.AddWithValue("P_LUNGHEZZAKM", t.LunghezzaKm);
						cmd.AddWithValue("P_TEMPOMINPERCORRENZASECONDI", t.TempoMinPercorrenzaSecondi);
						cmd.AddWithValue("P_DESCRIZIONE", t.Descrizione);
						cmd.AddWithValue("P_CODICESTRADA", t.CodiceStrada);
						cmd.AddWithValue("P_DIREZIONE", t.Direzione);

						cn.Open();
						cmd.ExecuteNonQuery();
					}
				}
			}
			catch (ODP.OracleException ex)
			{
				if (ex.Number == 1)
					throw new ApplicationException("Record gia` presente", ex);
				else
					throw;
			}
		}

		#endregion
	}
}
