using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Diagnostics;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

using System.Data.Common;


using ITRS_BL.IDal;
using ITRS_BL.Utility;

namespace ITRS_BL.Oracle
{
	public class DalTransiti : DalBase, IDalTransiti
	{
		public DatiTarga GetDatiTarga(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			string q = @"
select 
nvl(A.PL_XSTART,       B.PL_XSTART)       XSTART,
nvl(A.PL_YSTART,       B.PL_YSTART)       YSTART,
nvl(A.PL_XEND,         B.PL_XEND)         XEND,
nvl(A.PL_YEND,         B.PL_YEND)         YEND,
nvl(A.PL_NET_ID,       B.PL_NET_ID)       NETID,
nvl(A.PL_LAYOUT_ID,    B.PL_LAYOUT_ID)    LAYOUTID,
nvl(A.PL_VEHICLE_TYPE, B.PL_VEHICLE_TYPE) VEHICLETYPE,
nvl(A.PL_VEHICLE_ID,   B.PL_VEHICLE_ID)   VEHICLEID
from 
(
	select targa, nazionalita, dataOraRilevamento,
	PL_XSTART,
	PL_YSTART,
	PL_XEND,
	PL_YEND,
	PL_NET_ID,
	PL_LAYOUT_ID,
	PL_VEHICLE_TYPE,
	PL_VEHICLE_ID
	from Transiti
	where
	targa = :t and nazionalita=:n and dataOraRilevamento=:d
) A
full outer join 
(
	select targa, nazionalita, dataOraRilevamento,
	PL_XSTART,
	PL_YSTART,
	PL_XEND,
	PL_YEND,
	PL_NET_ID,
	PL_LAYOUT_ID,
	PL_VEHICLE_TYPE,
	PL_VEHICLE_ID

	from TransitiSuEvento
	where
	targa = :t and nazionalita=:n and dataOraRilevamento=:d
) B
on B.targa               = A.targa
and B.nazionalita        = A.nazionalita
and B.dataOraRilevamento = A.dataOraRilevamento

";

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = q;
					cmd.AddWithValue("t", targa);
					cmd.AddWithValue("n", nazionalita);
					cmd.AddWithValue("d", dataOraRilevamento);

					List<DatiTarga> ret = new List<DatiTarga>();
					ret = RecordReader<DatiTarga>(cmd);
					if (ret.Count == 0)
						return null;
					return ret[0];
				}
			}
		}

		public byte[] GetBlobImmagine(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			try
			{
				string q = @"
				select 
				Immagine
				from {0}
				where
				targa = :t and nazionalita=:n and dataOraRilevamento=:d and immagine is not null";

				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, "Immagini");
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraRilevamento);

						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							rd.FetchSize = cmd.RowSize;

							if (rd.Read())
							{
								if (!rd.IsDBNull(0))
								{
									OracleBlob blob = rd.GetOracleBlob(0);
									return blob.Value;
								}
							}
						}
					}

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, "ImmaginiSuEvento");
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraRilevamento);
						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							if (rd.Read())
							{
								if (!rd.IsDBNull(0))
								{
									OracleBlob blob = rd.GetOracleBlob(0);
									return blob.Value;
								}
							}
						}

						return null;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetBlobImmagini");
				throw new ApplicationException("GetBlobImmagini", ex);
			}
		}

		public void GetLatLonTransito(string targa, string nazionalita, DateTime dataOraRilevamento, out double lat, out double lon)
		{
			try
			{
				string q = @"
select 
distinct
T.Latitudine,
T.Longitudine,
C2p.Lat as C2pLat,
C2p.Lon as C2pLon 
from
(
	select
	Latitudine,
	Longitudine,
	IdC2p
	from TRANSITIsuEvento
	where
	TARGA = :t and
	NAZIONALITA = :n and
	DATAORARILEVAMENTO = :d
union
	select 
	Latitudine,
	Longitudine,
	IdC2p
	from TRANSITI
	where
	TARGA = :t and
	NAZIONALITA = :n and
	DATAORARILEVAMENTO = :d
) T
inner join C2P
on T.Idc2p = C2p.IDC2P";

				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraRilevamento);

						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							if (rd.Read())
							{
								if (!rd.IsDBNull(0))
								{
									lat = Convert.ToDouble(rd[0]);
									lon = Convert.ToDouble(rd[1]);
								}
								else
								{
									lat = Convert.ToDouble(rd[2]);
									lon = Convert.ToDouble(rd[3]);
								}

								return;
							}
						}
					}
				}

				lat = 0;
				lon = 0;
				Debug.Assert(false);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetLatLonTransito");
				throw new ApplicationException("GetLatLonTransito", ex);
			}
		}


		#region Query del batch
		public int GetTransitiCount()
		{
			try
			{
				string q = @"select count(*) from Transiti";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						return (int)cmd.ExecuteScalar<decimal>();
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetTransiti", ex);
			}
		}
		public List<Transiti> GetTransiti(string sortColumns, int startRowIndex, int maximumRows)
		{
			try
			{
				if (sortColumns.Trim() == "")
					sortColumns = "Targa";

				string q =
				@"select 
				Targa, 
				Nazionalita,
				DataOraRilevamento,
				IdC2P,
				EnumStatoTransito StatoTransito,
				EnumTipoVarco TipoVarco
				from Transiti where Targa like :t ORDER BY " + sortColumns;

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.PageQuery(cn, q, startRowIndex, maximumRows))
					{
						cmd.AddWithValue("t", "%");
						cmd.CommandTimeout = 1000;
						return RecordReader<Transiti>(cmd);
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetTransiti", ex);
			}
		}
		#endregion

		private DatiTransito GetDatiTransitoSuTabella(string targa, string nazionalita, DateTime dataOraRilevamento, string tabella)
		{
			Debug.Assert(tabella.ToLower() == "transiti" || tabella.ToLower() == "transitisuevento");
			try
			{
				string q;
				if (tabella.ToLower() == "transiti")
				{
					q = @"
select 
Transiti.Targa,
Transiti.Nazionalita,
Transiti.DataOraRilevamento,

C2P.Descrizione            DescrizioneC2P,
C2P.Direzione              DirezioneC2P,
C2P.CodiceStrada           CodiceStrada,
Transiti.EnumTipoVarco     TipoVarco,
Transiti.EnumStatoTransito StatoTransito,
Transiti.Latitudine,
Transiti.Longitudine,
Transiti.MarcaVeicolo,
Transiti.ModelloVeicolo,

Transiti.DataOraPresaInCarico,
Transiti.DataOraChiusura,

U.UserName                     UtentePresaInCarico,
Transiti.NoteChiusura,
Transiti.TargaAcquisita        TargaAcquisita,
Transiti.NazionalitaAcquisita  NazionalitaAcquisita

from Transiti

inner join C2P
on C2P.IdC2P = Transiti.IdC2P

left outer join aspnet_users U
on U.PKID = Transiti.IdUtentePresaInCarico

where Transiti.Targa = :t and 
Transiti.Nazionalita = :n and 
Transiti.DataOraRilevamento = :d";
				}
				else
				{
					q = @"
select 
transitisuevento.Targa,
transitisuevento.Nazionalita,
transitisuevento.DataOraRilevamento,

C2P.Descrizione           DescrizioneC2P,
C2P.Direzione             DirezioneC2P,
C2P.CodiceStrada          CodiceStrada,
transitisuevento.EnumTipoVarco         TipoVarco,
transitisuevento.EnumStatoTransito     StatoTransito,
transitisuevento.Latitudine,
transitisuevento.Longitudine,
transitisuevento.MarcaVeicolo,
transitisuevento.ModelloVeicolo,

transitisuevento.DataOraPresaInCarico,
transitisuevento.DataOraChiusura,

U.UserName                             UtentePresaInCarico,
transitisuevento.NoteChiusura,
transitisuevento.Targa                 TargaAcquisita,
transitisuevento.Nazionalita           NazionalitaAcquisita

from transitisuevento

inner join C2P
on C2P.IdC2P = transitisuevento.IdC2P

left outer join aspnet_users U
on U.PKID = transitisuevento.IdUtentePresaInCarico

where transitisuevento.Targa = :t and 
transitisuevento.Nazionalita = :n and 
transitisuevento.DataOraRilevamento = :d";
				}

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, tabella);
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraRilevamento);

						List<DatiTransito> r = RecordReader<DatiTransito>(cmd);
						if (r.Count == 0)
							return null;

						return r[0];
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalTransiti.GetDatiTransito");
				throw;
			}
		}

		public DatiTransito GetDatiTransitoOrTransitoSuEvento(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			DatiTransito tr = GetDatiTransitoSuTabella(targa, nazionalita, dataOraRilevamento, "transiti");
			if (tr != null)
				return tr;

			return GetDatiTransitoSuTabella(targa, nazionalita, dataOraRilevamento, "TransitiSuEvento");
		}

		public List<DatiTransito> GetTransitiDellEvento(string targa, string nazionalita, DateTime dataOraInserimento, int idEvento, string sortColumns)
		{
			try
			{
				string q = @"
select 
TSE.Targa,
TSE.Nazionalita,
TSE.DataOraRilevamento,

C2P.Descrizione           DescrizioneC2P,
C2P.Direzione             DirezioneC2P,
C2P.CodiceStrada          CodiceStrada,
TSE.EnumTipoVarco         TipoVarco,
TSE.EnumStatoTransito     StatoTransito,
TSE.Latitudine,
TSE.Longitudine,
TSE.MarcaVeicolo,
TSE.ModelloVeicolo,
TSE.DataOraPresaInCarico,
TSE.DataOraChiusura,

U.UserName                UtentePresaInCarico,
TSE.NoteChiusura,

TSE.Targa                 TargaAcquisita,
TSE.Nazionalita           NazionalitaAcquisita

from TransitiSuEvento TSE

inner join TransitiEventi TE
on  TE.Targa = TSE.Targa
and TE.Nazionalita = TSE.Nazionalita
and TE.DataOraRilevamento = TSE.DataOraRilevamento

inner join C2P
on C2P.IdC2P = TSE.IdC2P

left outer join aspnet_users U
on U.PKID = TSE.IdUtentePresaInCarico

where

    TE.Targa = :t
and TE.Nazionalita = :n
and TE.DataOraInserimento = :d
and TE.IdEvento = : i

order by ";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = q + sortColumns;

						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraInserimento);
						cmd.AddWithValue("i", idEvento);

						List<DatiTransito> r = RecordReader<DatiTransito>(cmd);
						return r;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalTransiti.GetDatiTransito");
				throw;
			}
		}

		public bool PrendiInCarico(string targa, string nazionalita, DateTime dataOraRilevamento, string idUtentePresaInCarico)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						using (OracleCommand cmd = this.CreateCommand(cn))
						{
							cmd.CommandText = "ITRS_TRANSITI_EVENTI.TransitoPrendiInCarico";
							cmd.CommandType = CommandType.StoredProcedure;

							cmd.AddWithValue("p_Targa", targa);
							cmd.AddWithValue("p_Nazionalita", nazionalita);
							cmd.AddWithValue("p_DataOraRilevamento", dataOraRilevamento);

							cmd.AddWithValue("p_IdUtentePresaInCarico", idUtentePresaInCarico);
							OracleParameter p_Updated = cmd.AddInt64OutParameter("p_Updated");
							cmd.ExecuteNonQuery();
							int updated = Convert.ToInt32(p_Updated.Value);
							if (updated == 0)
							{
								tr.Commit();//todo ? xche`
								return false;
							}

							if (!(updated == 1 || updated == 2))
								throw new ApplicationException("PrendiInCarico: aggiornati " + updated + " records");
						}
						tr.Commit();
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalTransiti.PrendiInCarico");
				throw;
			}
		}

		public bool AzioneSuPresaInCarico(string targa, string nazionalita, DateTime dataOraRilevamento, StatoTransito statoTransito, string noteChiusura, string TargaValidata, string NazionalitaValidata)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();

					using (OracleTransaction tr = cn.BeginTransaction())
					{
						using (OracleCommand cmd = this.CreateCommand(cn))
						{
							cmd.CommandText = "ITRS_TRANSITI_EVENTI.TransitoAzioneSuPresaInCarico2";
							cmd.CommandType = CommandType.StoredProcedure;

							cmd.AddWithValue("P_TARGA", targa);
							cmd.AddWithValue("P_NAZIONALITA", nazionalita);
							cmd.AddWithValue("P_DATAORARILEVAMENTO", dataOraRilevamento);
							cmd.AddWithValue("P_STATOTRANSITO", statoTransito.ToString());
							cmd.AddWithValue("P_NOTECHIUSURA", noteChiusura);
							cmd.AddWithValue("p_NuovaTarga", TargaValidata);
							cmd.AddWithValue("p_NuovaNazionalita", NazionalitaValidata);

							OracleParameter p_Updated = cmd.AddInt64OutParameter("P_UPDATED");
							cmd.ExecuteNonQuery();

							int updated = Convert.ToInt32(p_Updated.Value);
							if (updated == 0)
							{
								tr.Commit();
								return false;
							}

							if (!(updated == 1 || updated == 2))
								throw new ApplicationException("AzioneSuPresaInCarico: aggiornati " + updated + " records");
						}

						// se chiudo un transito in stato NORIC chiudo tutti gli eventi associati
						if (IsTransitoChiuso(targa, nazionalita, TargaValidata, NazionalitaValidata, statoTransito))
						{
							// ho metto il transito in NORIC oppure ho fatto un cambio targa
							ChiudiEventiAssociati(targa, nazionalita, dataOraRilevamento, cn);
						}

						tr.Commit();
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalTransiti.AzioneSuPresaInCarico");
				throw;
			}
		}

		/// <summary>
		/// Un transito va in stato chiuso se lo stato e` NoRic e 
		/// se e' Ric con cambio targa e/o nazionalita.
		/// Notare che un cambio targa e` possibile anche con una targa totalmente 
		/// riconosciuta dal lettore targhe.
		/// Una targa parzialmente riconosciuta NON puo` avere eventi associati
		/// </summary>
		/// <param name="oldTarga"></param>
		/// <param name="oldNaz"></param>
		/// <param name="newTarga"></param>
		/// <param name="newNaz"></param>
		/// <param name="statoTransito"></param>
		/// <returns></returns>
		static bool IsTransitoChiuso(string oldTarga, string oldNaz, string newTarga, string newNaz, StatoTransito statoTransito)
		{
			switch (statoTransito)
			{
			case StatoTransito.NORIC:
				return true;

			case StatoTransito.RIC:
				if (eq(oldTarga, newTarga) == false)
					return true;

				if (eq(oldNaz, newNaz) == false)
					return true;

				return false;

			default:
				return false;
			}
		}

		private static bool eq(string a, string b)
		{
			if (a == null && b == null) return true;
			if (a != null && b == null) return false;
			if (a == null && b != null) return false;
			return a == b;
		}

		public void ChiudiEventiAssociati(string targa, string nazionalita, DateTime dataOraRilevamento, OracleConnection cn)
		{
			if (cn == null) { cn = CreateConnection(); cn.Open(); }
			using (OracleCommand cmd1 = this.CreateCommand(cn))
			{
				cmd1.CommandText = @"
select 
DataOraInserimento, 
IdEvento 
from 
TransitiEventi 
where 
    Targa              = :p_Targa 
and Nazionalita        = :p_Nazionalita 
and DataOraRilevamento = :p_DataOraRilevamento
";
				cmd1.AddWithValue("p_Targa", targa);
				cmd1.AddWithValue("p_Nazionalita", nazionalita);
				cmd1.AddWithValue("p_DataOraRilevamento", dataOraRilevamento);

				List<DataEventiDelTransito> rDte = RecordReader<DataEventiDelTransito>(cmd1);

				foreach (DataEventiDelTransito dte in rDte)
				{
					using (OracleCommand cmd2 = this.CreateCommand(cn))
					{
						cmd2.CommandText = @"
update EventiDaSegnalare
set
ENUMSTATOALLARME = 'NCNF'
where
    Targa              = :p_Targa 
and Nazionalita        = :p_Nazionalita 
and DataOraInserimento = :p_DataOraInserimento
and IdEvento           = :p_IdEvento
";
						cmd2.AddWithValue("p_Targa", targa);
						cmd2.AddWithValue("p_Nazionalita", nazionalita);
						cmd2.AddWithValue("p_DataOraInserimento", dte.DataOraInserimento);
						cmd2.AddWithValue("p_IdEvento", dte.IdEvento);

						cmd2.ExecuteNonQuery();
					}
				}
			}
		}

		public class DataEventiDelTransito
		{
			private DateTime _DataOraInserimento;

			public DateTime DataOraInserimento
			{
				get { return _DataOraInserimento; }
				set { _DataOraInserimento = value; }
			}
			private decimal _IdEvento;

			public decimal IdEvento
			{
				get { return _IdEvento; }
				set { _IdEvento = value; }
			}
		}

		public void RiconoscimentoManuale(string targa, string nazionalita, DateTime dataOraRilevamento, string targaRiconosciutaDallOperatore, string nazioneRiconosciutaDallOperatore, string note)
		{
			Debug.Assert(targa.StartsWith("~"));

			using (OracleConnection cn = this.CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = "ITRS_TRANSITI_EVENTI.TransitoRiconoscimentoManuale";
						cmd.CommandType = CommandType.StoredProcedure;

						cmd.AddWithValue("P_TARGA", targa);
						cmd.AddWithValue("P_NAZIONALITA", nazionalita);
						cmd.AddWithValue("P_DATAORARILEVAMENTO", dataOraRilevamento);
						cmd.AddWithValue("P_NOTECHIUSURA", note);

						cmd.AddWithValue("P_NUOVA_TARGA", targaRiconosciutaDallOperatore);
						cmd.AddWithValue("P_NUOVA_NAZIONALITA", nazioneRiconosciutaDallOperatore);

						// devo fare update di transiti e immagini.
						// misa tanto che si fanno due insert e 2 due delete.
						cmd.ExecuteNonQuery();

						tr.Commit();
					}
				}

			}
		}

		public void GetTransitoData(string targa, string nazionalita, DateTime dataOraRilevamento, out string targaRil, out int idC2P, out string qmgr)
		{
			targaRil = null;
			idC2P = -1;
			qmgr = null;
			try
			{
				string q = @"
				select 
				{0}.TargaAcquisita, {0}.idC2P, c2p.QMGR_NAME
				from {0}
				inner join c2p
				on c2p.idc2p = {0}.idC2p
				where
				{0}.targa = :t and {0}.nazionalita=:n and {0}.dataOraRilevamento=:d";

				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, "Transiti");
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraRilevamento);

						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							if (rd.Read())
							{
								targaRil = (string)rd[0];
								idC2P = Convert.ToInt32(rd[1]);
								qmgr = (string)rd[2];
								return;
							}
						}
					}

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, "TransitiSuEvento");
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraRilevamento);
						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							if (rd.Read())
							{
								targaRil = (string)rd[0];
								idC2P = Convert.ToInt32(rd[1]);
								qmgr = (string)rd[2];
								return;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetTransitoData");
				throw new ApplicationException("GetTransitoData", ex);
			}
		}

		public void SaveImmagine(string targa, string naz, DateTime dataOraRilevamento, byte[] img)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = @"
insert into immagini
(targa, nazionalita, dataOraRilevamento, IdImmagine, immagine, 
FORMATO, CODIFICA, RISOLUZIONE)
values
(
:t, :n, :d, seq_im.nextval, :i, 
'base64', 'JPEG', '1024x768'
)";
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", naz);
						cmd.AddWithValue("d", dataOraRilevamento);
						cmd.AddWithValue("i", img);

						cmd.ExecuteNonQuery();
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "SaveImmagine");
			}
		}




		public List<TransitoPresoInCarico> GetListaTransitiPresiInCarico(string sortColumn, int? IdCoa)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					string q = @"
select 
Tr.Targa                 Targa, 
Tr.Nazionalita           Nazionalita, 
Tr.DataOraRilevamento    DataOraRilevamento, 
Tr.DATAORAPRESAINCARICO  DataOraPresaInCarico,
Tr.ENUMTIPOVARCO         /* TipoVarco */ TipoVarco,
C2p.DIREZIONE            /* Direzione */ Direzione,  
C2P.DESCRIZIONE          AreaDiServizio,
Strade.DESCRIZIONESTRADA Strada, 
COA.DESCRIZIONE          CoaDiCompetenza,
Ut.USERNAME              Operatore
from TRANSITISUEVENTO Tr
left outer join ASPNET_USERS Ut on Ut.pkid = Tr.IdUtentePresaInCarico
inner join C2P                  on C2P.IDC2P = Tr.IDC2P
inner join Strade               on Strade.CODICESTRADA = C2P.CODICESTRADA
inner join COA                  on COA.IDCOA = C2P.IDCOA
where
Tr.ENUMSTATOTRANSITO    =  'PIC'
and (:p_IdCoa is null or C2P.IdCoa = :p_IdCoa)
order by {0}
";
					cmd.CommandText = string.Format(q, sortColumn);
					cmd.AddWithValue(":p_IdCoa", IdCoa);
					List<TransitoPresoInCarico> ret = RecordReader<TransitoPresoInCarico>(cmd);
					return ret;
				}
			}
		}


		public bool AnnullaTransitoPresoInCarico(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					string q = @"
update {0}
set ENUMSTATOTRANSITO = 'DARIC'
where 
TARGA = :p_targa
and NAZIONALITA = :p_nazionalita
and DATAORARILEVAMENTO = :p_dataOraRilevamento
and ENUMSTATOTRANSITO = 'PIC'
";
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, "transiti");
						cmd.AddWithValue(":p_targa", targa);
						cmd.AddWithValue(":p_nazionalita", nazionalita);
						cmd.AddWithValue(":p_dataOraRilevamento", dataOraRilevamento);
						cmd.ExecuteNonQuery();
					}

					int r;
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, "transitiSuEvento");
						cmd.AddWithValue(":p_targa", targa);
						cmd.AddWithValue(":p_nazionalita", nazionalita);
						cmd.AddWithValue(":p_dataOraRilevamento", dataOraRilevamento);
						r = cmd.ExecuteNonQuery();
					}

					if (r == 1)
					{
						tr.Commit();
						return true;
					}
					tr.Rollback();
					return false;
				}
			}
		}
	}
}
