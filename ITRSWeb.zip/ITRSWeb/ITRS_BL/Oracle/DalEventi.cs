using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

using System.Data.Common;


using ITRS_BL.IDal;
using ITRS_BL.Utility;

namespace ITRS_BL.Oracle
{
	class DalEventi : DalBase, IDalEventi
	{
		public List<Evento> GetEventiFromTransito(string targa, string nazionalita, DateTime dataOraRilevamento, string sortColumns)
		{
			string q =
@"
select 
E.Targa,
E.Nazionalita,
E.DataOraInserimento,
E.IdEvento,

E.EnumTipoEvento     as TipoEvento,
E.EnumStatoAllarme   as StatoAllarme,
U.UserName           as UtentePresaInCarico,
E.DataOraPresaInCarico,
E.DataOraChiusura,
E.NoteChiusura,
COA.Descrizione      as CoaDiCompetenza,
E.EnumClasseUrgenza  as ClasseDiUrgenza

from 
EventiDaSegnalare E

inner join TransitiEventi TE
on  TE.Targa = E.Targa
and TE.Nazionalita = E.Nazionalita
and TE.DataOraInserimento = E.DataOraInserimento
and TE.IdEvento = E.IdEvento

left outer join COA
on COA.IdCoa = E.IdCoaCompetenza

left outer join aspnet_users U
on U.PkId = E.IdUtentePresaInCarico

where

TE.Targa = :t
and TE.Nazionalita =:n
and TE.DataOraRilevamento = :d
order by ";

			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = q + sortColumns;
						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraRilevamento);

						List<Evento> ret = RecordReader<Evento>(cmd);
						return ret;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetEventiFromTransito");
				throw;
			}

		}

		public DettEvento GetDatiEvento(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento)
		{
			/*
						string q = @"
			select 
			E.Targa,
			E.Nazionalita,
			E.DataOraInserimento,
			E.IdEvento,

			E.EnumTipoEvento     as TipoEvento,
			E.EnumStatoAllarme   as StatoAllarme,
			U.UserName           as UtentePresaInCarico,
			E.DataOraPresaInCarico,
			E.DataOraChiusura,
			E.NoteChiusura,
			COA.Descrizione      as CoaDiCompetenza,
			E.IdCoaCompetenza    as IdCoaDiCompetenza,

			E.EnumClasseUrgenza  as ClasseDiUrgenza

			from 
			EventiDaSegnalare E

			left outer join COA
			on COA.IdCoa = E.IdCoaCompetenza

			left outer join aspnet_users U
			on U.PkId = E.IdUtentePresaInCarico

			where

			E.Targa = :t
			and E.Nazionalita=:n
			and E.DataOraInserimento = :d
			and E.IdEvento = :i";
			*/
			string q = @"
select 
E.Targa,
E.Nazionalita,
E.DataOraInserimento,
E.IdEvento,
E.EnumTipoEvento            as TipoEvento,
E.EnumStatoAllarme          as StatoAllarme,
U.UserName                  as UtentePresaInCarico,
E.DataOraPresaInCarico,
E.DataOraChiusura,
E.NoteChiusura,
COA.Descrizione             as CoaDiCompetenza,
E.IdCoaCompetenza           as IdCoaDiCompetenza,
E.EnumClasseUrgenza         as ClasseDiUrgenza,
count(TR.EnumStatoTransito) as TransitiNonRiconosciuti

from 
EventiDaSegnalare E

left outer join COA
on COA.IdCoa = E.IdCoaCompetenza

left outer join aspnet_users U
on U.PkId = E.IdUtentePresaInCarico

inner join TRANSITIEVENTI TE
on  TE.TARGA              = E.TARGA
and TE.NAZIONALITA        = E.NAZIONALITA
and TE.DATAORAINSERIMENTO = E.DATAORAINSERIMENTO
and TE.IDEVENTO           = E.IDEVENTO

left outer join TRANSITISUEVENTO TR
on  TR.TARGA              = TE.TARGA
and TR.NAZIONALITA        = TE.NAZIONALITA
and TR.DataOraRilevamento = TE.DataOraRilevamento
and TR.EnumStatoTransito  <> 'RIC'

where
    E.Targa = :t
and E.Nazionalita=:n
and E.DataOraInserimento = :d
and E.IdEvento = :i

group by

E.Targa,
E.Nazionalita,
E.DataOraInserimento,
E.IdEvento,
E.EnumTipoEvento,
E.EnumStatoAllarme,
U.UserName,
E.DataOraPresaInCarico,
E.DataOraChiusura,
E.NoteChiusura,
COA.Descrizione,
E.IdCoaCompetenza,
E.EnumClasseUrgenza
";
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = q;
						cmd.AddWithValue("t", targa);
						cmd.AddWithValue("n", nazionalita);
						cmd.AddWithValue("d", dataOraInserimento);
						cmd.AddWithValue("i", idEvento);

						List<DettEvento> ret = RecordReader<DettEvento>(cmd);
						if (ret.Count > 0)
							return ret[0];
						return null;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetDatiEvento");
				throw;
			}
		}


		public bool PrendiInCarico(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento, string idUtentePresaInCarico)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						using (OracleCommand cmd = this.CreateCommand(cn))
						{
							cmd.CommandText = "ITRS_TRANSITI_EVENTI.EventoPrendiInCarico";
							cmd.CommandType = CommandType.StoredProcedure;

							cmd.AddWithValue("p_Targa", targa);
							cmd.AddWithValue("p_Nazionalita", nazionalita);
							cmd.AddWithValue("p_DataOraInserimento", dataOraInserimento);
							cmd.AddWithValue("p_IdEvento", idEvento);

							cmd.AddWithValue("p_IdUtentePresaInCarico", idUtentePresaInCarico);
							OracleParameter p_Updated = cmd.AddInt64OutParameter("p_Updated");
							cmd.ExecuteNonQuery();

							int updated = Convert.ToInt32(p_Updated.Value);
							if (updated == 0)
							{
								tr.Commit();
								return false;
							}

							if (updated != 1)
								throw new ApplicationException("PrendiInCarico: aggiornati " + updated + " records");
						}
						tr.Commit();
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalEventi.PrendiInCarico");
				throw;
			}
		}

		public bool AzioneSuPresaInCarico(string targa, string nazionalita, DateTime dataOraInserimento, Int64 idEvento, StatoAllarme statoAllarme, string noteChiusura)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						using (OracleCommand cmd = this.CreateCommand(cn))
						{
							cmd.CommandText = "ITRS_TRANSITI_EVENTI.EventoAzioneSuPresaInCarico";
							cmd.CommandType = CommandType.StoredProcedure;

							cmd.AddWithValue("p_Targa", targa);
							cmd.AddWithValue("p_Nazionalita", nazionalita);
							cmd.AddWithValue("p_DataOraInserimento", dataOraInserimento);
							cmd.AddWithValue("p_IdEvento", idEvento);

							cmd.AddWithValue("p_StatoAllarme", statoAllarme.ToString());
							cmd.AddWithValue("p_NoteChiusura", noteChiusura);

							OracleParameter p_Updated = cmd.AddInt64OutParameter("p_Updated");
							cmd.ExecuteNonQuery();

							int updated = Convert.ToInt32(p_Updated.Value);
							if (updated == 0)
							{
								tr.Commit();
								return false;
							}

							if (updated != 1)
								throw new ApplicationException("AzioneSuPresaInCarico: aggiornati " + updated + " records");
						}
						tr.Commit();
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalEventi.AzioneSuPresaInCarico");
				throw;
			}
		}


		public List<EventoPresoInCarico> GetListaEventiTSPresiInCarico(string sort, int? idCoa)
		{
			string q = @"
select 
Ev.Targa                 evTarga, 
Ev.Nazionalita           evNazionalita,
Ev.DATAORAINSERIMENTO    evDataOraInserimento,
Ev.IdEvento              evIdEvento,
Ev.DATAORAPRESAINCARICO  evDataOraPresaInCarico,
COA.DESCRIZIONE          evCoaDiCompetenza,
Ut.USERNAME              evOperatorePresaInCarico,
TrEv.DataOraRilevamento  trDataOraRilevamento, 
Tr.ENUMTIPOVARCO         /*TipoVarco*/trTipoVarco,
C2P.DIREZIONE            /*Direzione*/trDirezione,
C2P.DESCRIZIONE          trAreaDiServizio,
Strade.DESCRIZIONESTRADA trStrada

from EVENTIDASEGNALARE Ev

inner join TRANSITIEVENTI TrEv
on  Ev.TARGA = TrEv.TARGA
and Ev.NAZIONALITA = TrEv.NAZIONALITA
and Ev.DATAORAINSERIMENTO = TrEv.DATAORAINSERIMENTO
and Ev.IDEVENTO = TrEv.IDEVENTO

inner join TransitiSuEvento Tr
on  Tr.TARGA = TrEv.TARGA
and Tr.NAZIONALITA = TrEv.NAZIONALITA
and Tr.DATAORARILEVAMENTO = TrEv.DATAORARILEVAMENTO

left outer join ASPNET_USERS Ut on Ut.pkid = Ev.IdUtentePresaInCarico
inner join C2P                  on C2P.IDC2P = Tr.IDC2P
inner join Strade               on Strade.CODICESTRADA = C2P.CODICESTRADA
inner join COA                  on COA.IDCOA = Ev.IDCOACOMPETENZA

where Ev.ENUMSTATOALLARME = 'PIC'
and Ev.ENUMTIPOEVENTO = 'TS'

and (:p_idCoa is null or Ev.IDCOACOMPETENZA = :p_idCoa)
order by {0}
";
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = string.Format(q, sort);
					cmd.AddWithValue(":p_idCoa", idCoa);

					return RecordReader<EventoPresoInCarico>(cmd);
				}
			}
		}

		public bool AnnullaPresaInCaricoEvTS(string targa, string nazionalita, DateTime evDataOraInserimento, Int64 evIdEvento, DateTime trDataOraRilevamento)
		{
			// annullo la resa in carico stando attento a non beccare eventi/transiti che non sono in stato da Annullare
			// ossia Tr in confermato, Ev in PIC

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"
update EVENTIDASEGNALARE
set ENUMSTATOALLARME = 'ACQ'
where
TARGA = :p_targa
and NAZIONALITA = :p_nazionalita
and DATAORAINSERIMENTO = :p_dataOraInserimento
and IDEVENTO = :p_idEvento
and ENUMSTATOALLARME = 'PIC'
and EnumTipoEvento = 'TS'
and exists
(
	select * from TRANSITISUEVENTO
	where 
	TARGA = :p_targa
	and NAZIONALITA = :p_nazionalita
	and DATAORARILEVAMENTO = :p_dataOraRilevamento
	and ENUMSTATOTRANSITO = 'RIC'
)
";
					cmd.AddWithValue(":p_targa", targa);
					cmd.AddWithValue(":p_nazionalita", nazionalita);
					cmd.AddWithValue(":p_dataOraInserimento", evDataOraInserimento);
					cmd.AddWithValue(":p_dataOraRilevamento", trDataOraRilevamento);
					cmd.AddWithValue(":p_idEvento", evIdEvento);

					cn.Open();

					int r = cmd.ExecuteNonQuery();
					return r > 0; // se ha updatato ritorno true
				}
			}

		}
	}
}
