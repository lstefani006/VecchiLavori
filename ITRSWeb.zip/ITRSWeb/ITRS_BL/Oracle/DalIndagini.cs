using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Configuration;
using System.Diagnostics;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

using System.Data.Common;

using ITRS_BL.IDal;

namespace ITRS_BL.Oracle
{
	class DalIndagini : DalBase, IDalIndagini
	{
		public int QueryPerIndagineTransiti(string jobId, string targa, string nazionalita, DateTime di, DateTime df, int? IdC2P, int? IdCoa, ref int MaxRec)
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.CommandText = "ITRS.ITRS_INDAGINI.QUERYINDAGINETRANSITI2";

						cmd.AddWithValue("P_QJID", jobId);
						cmd.AddWithValue("P_TARGA", targa);
						cmd.AddWithValue("P_NAZIONALITA", nazionalita);
						cmd.AddWithValue("P_DI", di);
						cmd.AddWithValue("P_DF", df);
						cmd.AddWithValue("P_IDC2P", IdC2P);
						cmd.AddWithValue("P_IDCOA", IdCoa);

						OracleParameter pRows = cmd.AddInt64OutParameter("P_FOUND");
						OracleParameter pMaxRec = cmd.AddInt64OutParameter("P_MAXREC");
						cn.Open();
						cmd.ExecuteNonQuery();

						object mr = pMaxRec.Value;
						MaxRec = (int)(long)mr;

						object ret = pRows.Value;
						return (int)(long)ret;
					}
				}
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				throw;
			}
		}

		public int QueryPerIndagineEventi(string jobId, string targa, string nazionalita, DateTime di, DateTime df, int? IdC2P, int? IdCoa, TipoEvento? TipoEvento, ref int MaxRec)
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						using (OracleCommand cmd = CreateCommand(cn))
						{
							cmd.CommandType = CommandType.StoredProcedure;
							cmd.CommandText = "ITRS.ITRS_INDAGINI.QUERYINDAGINEEVENTI2";

							cmd.AddWithValue("P_QJID", jobId);
							cmd.AddWithValue("P_TARGA", targa);
							cmd.AddWithValue("P_NAZIONALITA", nazionalita);
							cmd.AddWithValue("P_DI", di);
							cmd.AddWithValue("P_DF", df);
							cmd.AddWithValue("P_IDCOA", IdCoa);


							//Console.WriteLine("DATA INIZIO = {0}", di);
							//Console.WriteLine("DATA FINE = {0}", df);
							cmd.AddWithValue("P_IDC2P", IdC2P);
							string ste = null;
							if (TipoEvento != null) ste = TipoEvento.Value.ToString();
							cmd.AddWithValue("P_TIPOEVENTO", ste);

							OracleParameter pRows = cmd.AddInt64OutParameter("P_FOUND");
							OracleParameter pMaxRec = cmd.AddInt64OutParameter("P_MAXREC");
							cmd.ExecuteNonQuery();

							object mr = pMaxRec.Value;
							MaxRec = (int)(long)mr;

							object ret = pRows.Value;

							//Console.WriteLine("N. OF RECS: {0}", ret);
							//Console.WriteLine("MAX RECS: {0}", mr);

							tr.Commit();

							return (int)(long)ret;
						}

					}
				}
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				throw;
			}
		}

		public void CancellaIndagine(string jobId)
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						using (OracleCommand cmd = CreateCommand(cn))
						{
							cmd.CommandType = CommandType.StoredProcedure;
							cmd.CommandText = "ITRS.ITRS_INDAGINI.CANCELLAINDAGINE";

							cmd.AddWithValue("P_QJID", jobId);
							cmd.ExecuteNonQuery();
						}
						tr.Commit();
					}
				}
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				throw;
			}
		}

		public List<ResultQueryIndagineTransito> GetResultJobIndagineTransiti(string jobId, string columnsSort, bool includiImmagini, int startRowIndex, int maximumRows)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;

					string q = @"
SELECT
IT.QJID,
IT.TARGA,
IT.NAZIONALITA,
IT.DATAORARILEVAMENTO,
IT.C2P_DESCRIZIONE,
IT.C2P_DIREZIONE,
IT.ENUMTIPOVARCO,
nvl(Transiti.ENUMSTATOTRANSITO, TSE.ENUMSTATOTRANSITO) ENUMSTATOTRANSITO,
decode(nvl(Transiti.ENUMSTATOTRANSITO, TSE.ENUMSTATOTRANSITO), 'RIC', IT.TARGA, IT.TARGAACQUISITA) TARGAACQUISITA,
decode(nvl(Transiti.ENUMSTATOTRANSITO, TSE.ENUMSTATOTRANSITO), 'RIC', IT.NAZIONALITA, IT.NAZIONALITAACQUISITA) NAZIONALITAACQUISITA ";
					if (includiImmagini)
					{
						q += @"
,
nvl(IMG.IMMAGINE, IMGEV.IMMAGINE) IMMAGINE ";
					}
					q += @"
FROM 
INDAGINI_TRANSITI IT

left outer join Transiti
on  Transiti.TARGA              = IT.TARGA
and Transiti.NAZIONALITA        = IT.NAZIONALITA
and Transiti.DATAORARILEVAMENTO = IT.DATAORARILEVAMENTO

left outer join TransitiSuEvento TSE
on  TSE.TARGA              = IT.TARGA
and TSE.NAZIONALITA        = IT.NAZIONALITA
and TSE.DATAORARILEVAMENTO = IT.DATAORARILEVAMENTO ";
					if (includiImmagini)
					{
						q += @"

left outer join IMMAGINI IMG
on  IMG.TARGA              = IT.TARGA
and IMG.NAZIONALITA        = IT.NAZIONALITA
and IMG.DATAORARILEVAMENTO = IT.DATAORARILEVAMENTO 

left outer join IMMAGINISUEVENTO IMGEV
on  IMGEV.TARGA              = IT.TARGA
and IMGEV.NAZIONALITA        = IT.NAZIONALITA
and IMGEV.DATAORARILEVAMENTO = IT.DATAORARILEVAMENTO ";

					}

					q += @"
WHERE 
IT.QJID = :P_QJID ";

					cmd.CommandText = q;
					switch (columnsSort.ToLower())
					{
					case "targaacquisita":
						columnsSort = "IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.DataOraRilevamento, IT.ROWID";
						break;
					case "nazionalitaacquisita":
						columnsSort = "IT.NazionalitaAcquisita, IT.DataOraRilevamento, IT.TargaAcquisita, IT.ROWID";
						break;
					case "dataorarilevamento":
						columnsSort = "IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					case "c2p_descrizione":
						columnsSort = "IT.c2p_descrizione, IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					case "c2p_direzione":
						columnsSort = "IT.c2p_direzione, IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					case "enumtipovarco":
						columnsSort = "IT.enumtipovarco, IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					case "enumstatotransito":
						columnsSort = "IT.enumstatotransito, IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;

					case "targaacquisita desc":
						columnsSort = "IT.TargaAcquisita desc, IT.NazionalitaAcquisita, IT.DataOraRilevamento, IT.ROWID";
						break;
					case "nazionalitaacquisita desc":
						columnsSort = "IT.NazionalitaAcquisita desc, IT.DataOraRilevamento, IT.TargaAcquisita, IT.ROWID";
						break;
					case "dataorarilevamento desc":
						columnsSort = "IT.DataOraRilevamento desc, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					case "c2p_descrizione desc":
						columnsSort = "IT.c2p_descrizione desc, IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					case "c2p_direzione desc":
						columnsSort = "IT.c2p_direzione desc, IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					case "enumtipovarco desc":
						columnsSort = "IT.enumtipovarco desc, IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					case "enumstatotransito desc":
						columnsSort = "IT.enumstatotransito desc, IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;

					default:
						System.Diagnostics.Debug.Assert(false);
						columnsSort = "IT.DataOraRilevamento, IT.TargaAcquisita, IT.NazionalitaAcquisita, IT.ROWID";
						break;
					}

					columnsSort = columnsSort.Replace("IT.TargaAcquisita", "decode(nvl(Transiti.ENUMSTATOTRANSITO, TSE.ENUMSTATOTRANSITO), 'RIC', IT.TARGA, IT.TARGAACQUISITA)");
					columnsSort = columnsSort.Replace("IT.NazionalitaAcquisita", "decode(nvl(Transiti.ENUMSTATOTRANSITO, TSE.ENUMSTATOTRANSITO), 'RIC', IT.NAZIONALITA, IT.NAZIONALITAACQUISITA)");

					cmd.CommandText += " order by " + columnsSort;

					cmd.AddWithValue(":P_QJID", jobId);

					if (maximumRows > 0)
						this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					if (includiImmagini == false)
					{
						List<ResultQueryIndagineTransito> rr = this.RecordReader<ResultQueryIndagineTransito>(cmd);
						return rr;
					}
					else
					{
						// Fetch 100 righe alla volta !!
						// Una immagine e` circa 30KB. --> 30KB * 30 = 900KB
						List<ResultQueryIndagineTransito> rr = this.RecordReader<ResultQueryIndagineTransito>(cmd, 30);
						return rr;
					}
				}
			}
		}

		public ResultQueryIndagineTransito GetResultJobIndagineTransiti(string jobId, string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;

					string q = @"
SELECT
IT.QJID,
IT.TARGA,
IT.NAZIONALITA,
IT.DATAORARILEVAMENTO,
IT.C2P_DESCRIZIONE,
IT.C2P_DIREZIONE,
IT.ENUMTIPOVARCO,
nvl(Transiti.ENUMSTATOTRANSITO, TSE.ENUMSTATOTRANSITO) ENUMSTATOTRANSITO,
decode(nvl(Transiti.ENUMSTATOTRANSITO, TSE.ENUMSTATOTRANSITO), 'RIC', IT.TARGA, IT.TARGAACQUISITA) TARGAACQUISITA,
decode(nvl(Transiti.ENUMSTATOTRANSITO, TSE.ENUMSTATOTRANSITO), 'RIC', IT.NAZIONALITA, IT.NAZIONALITAACQUISITA) NAZIONALITAACQUISITA,
nvl(IMG.IMMAGINE, IMGEV.IMMAGINE) IMMAGINE
FROM 
INDAGINI_TRANSITI IT
left outer join Transiti
on  Transiti.TARGA              = IT.TARGA
and Transiti.NAZIONALITA        = IT.NAZIONALITA
and Transiti.DATAORARILEVAMENTO = IT.DATAORARILEVAMENTO
left outer join TransitiSuEvento TSE
on  TSE.TARGA              = IT.TARGA
and TSE.NAZIONALITA        = IT.NAZIONALITA
and TSE.DATAORARILEVAMENTO = IT.DATAORARILEVAMENTO
left outer join IMMAGINI IMG
on  IMG.TARGA              = IT.TARGA
and IMG.NAZIONALITA        = IT.NAZIONALITA
and IMG.DATAORARILEVAMENTO = IT.DATAORARILEVAMENTO 

left outer join IMMAGINISUEVENTO IMGEV
on  IMGEV.TARGA              = IT.TARGA
and IMGEV.NAZIONALITA        = IT.NAZIONALITA
and IMGEV.DATAORARILEVAMENTO = IT.DATAORARILEVAMENTO 
WHERE 
    IT.QJID = :P_QJID
and IT.TARGA = :P_TARGA
and IT.NAZIONALITA = :P_NAZIONALITA
and IT.DATAORARILEVAMENTO = :P_DATAORARILEVAMENTO";

					cmd.CommandText = q;

					cmd.AddWithValue(":P_QJID", jobId);
					cmd.AddWithValue(":P_TARGA", targa);
					cmd.AddWithValue(":P_NAZIONALITA", nazionalita);
					cmd.AddWithValue(":P_DATAORARILEVAMENTO", dataOraRilevamento);

					List<ResultQueryIndagineTransito> rr = this.RecordReader<ResultQueryIndagineTransito>(cmd);
					if (rr.Count == 0)
						return null;
					return rr[0];
				}
			}
		}


		public List<ResultQueryIndagineEvento> GetResultJobIndagineEventi(string jobId, string columnsSort, int startRowIndex, int maximumRows)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = @"
SELECT
IE.QJID,
IE.TARGA,
IE.NAZIONALITA,
IE.DATAORAINSERIMENTO,
IE.IDEVENTO,
IE.ENUMTIPOEVENTO,
EVS.ENUMSTATOALLARME,
U.USERNAME as UTENTEPRESAINCARICO,
EVS.DATAORAPRESAINCARICO,
EVS.DATAORACHIUSURA,
EVS.NOTECHIUSURA,
IE.COADICOMPETENZA,
IE.CLASSEDIURGENZA,
IE.DATAULTIMOTRANSITO
FROM 
INDAGINI_EVENTI IE

inner join EventiDaSegnalare EVS
on  EVS.Targa              = IE.Targa
and EVS.Nazionalita        = IE.Nazionalita
and EVS.DataOraInserimento = IE.DataOraInserimento
and EVS.IDEVENTO           = IE.IDEVENTO

left outer join aspnet_users U
on U.pkid = EVS.IDUTENTEPRESAINCARICO

WHERE 
QJID = :P_QJID";
					cmd.CommandText += " order by " + columnsSort;

					cmd.AddWithValue(":P_QJID", jobId);

					if (maximumRows > 0)
						this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					cn.Open();
					return this.RecordReader<ResultQueryIndagineEvento>(cmd);
				}
			}
		}
	}
}
