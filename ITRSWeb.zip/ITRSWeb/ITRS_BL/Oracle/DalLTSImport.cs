using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.Common;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Schema;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

using ITRS_BL.IDal;
using ITRS_BL.Utility;

namespace ITRS_BL.Oracle
{
	public class RecordCastello : IComparable<RecordCastello>
	{
		string _operazione;
		string _targa;
		string _nazionalita;
		DateTime? _scadenza;
		DateTime? _data_segnalazione;
		string _note;
		string _tipoVeicolo;

		public string Operazione { get { return _operazione; } set { _operazione = value; } }
		public string Targa { get { return _targa; } set { _targa = value; } }
		public string Nazionalita { get { return _nazionalita; } set { _nazionalita = value; } }
		public DateTime? Scadenza { get { return _scadenza; } set { _scadenza = value; } }
		public DateTime? DataSegnalazione { get { return _data_segnalazione; } set { _data_segnalazione = value; } }
		public string Note { get { return _note; } set { _note = value; } }
		public string TipoVeicolo { get { return _tipoVeicolo; } set { _tipoVeicolo = value; } }

		public int CompareTo(RecordCastello other)
		{
			int r = string.Compare(this._targa, other._targa);
			if (r == 0)
				r = string.Compare(this._nazionalita, other._nazionalita);
			return r;
		}
	}
	#region lettura/scrittura FileCastello
	public class FileCastelloWriter : IDisposable
	{
		StreamWriter _sw;
		int _numeroRecord;

		public FileCastelloWriter(string fileNameOut)
		{
			_sw = File.CreateText(fileNameOut);
			_numeroRecord = 0;
		}

		public FileCastelloWriter(Stream s)
		{
			_sw = new StreamWriter(s, Encoding.UTF8);
			_numeroRecord = 0;
		}


		public void Close()
		{
			if (_sw != null)
			{
				_sw.Close();
				_sw = null;
			}
		}

		public int NumeroRecordScritti
		{
			get { return _numeroRecord; }
		}

		void IDisposable.Dispose()
		{
			Close();
		}

		public void Add(RecordCastello r)
		{
			_numeroRecord += 1;

			_sw.Write(r.Operazione);
			_sw.Write(" {0}", r.Targa);
			_sw.Write(" {0}", r.Nazionalita);
			if (r.Operazione == "1")
			{
				_sw.Write(" {0}", WriteDate(r.Scadenza.Value));
				_sw.Write(" {0}", WriteDate(r.DataSegnalazione.Value));
				_sw.Write(" {0}", r.TipoVeicolo);
				_sw.Write(" {0}", r.Note);
			}
			_sw.WriteLine();
		}

		private static string WriteDate(DateTime t)
		{
			string dd = t.Day.ToString();
			if (dd.Length == 1) dd = "0" + dd;

			string mm = t.Month.ToString();
			if (mm.Length == 1) mm = "0" + mm;

			string yyyy = t.Year.ToString();

			return dd + "/" + mm + "/" + yyyy;
		}
	}

	public abstract class FileGenericReader
	{
		protected int _numeroErrori;
		protected int _numeroDiRecordLetti;
		protected int _nLine;

		protected FileGenericReader()
		{
			_nLine = 0;
			_numeroErrori = 0;
			_numeroDiRecordLetti = 0;
		}

		public int ErrorsDetected { get { return _numeroErrori; } }
		public int NumeroDiRecordLetti { get { return _numeroDiRecordLetti; } }
		public int NumeroRigheNelFile { get { return _nLine; } }

		public event OnErrorDelegate OnError;
		public delegate void OnErrorDelegate(int lineaCorrente, string errorMessage);


		protected void ManageError(int lineaCorrente, string fmt, params object[] args)
		{
			string lastError = string.Format(fmt, args);
			_numeroErrori += 1;
			if (this.OnError != null) OnError(lineaCorrente, lastError);
		}
		protected void ManageError(int lineaCorrente, string msg)
		{
			_numeroErrori += 1;
			if (OnError != null) OnError(lineaCorrente, msg);
		}

		public delegate T ConvertRecordDelegate<T>(int lineaCorrente, string operazione, string targa, string naz, DateTime? scadenza, DateTime? data_segnalazione, string note, string tipoVeicolo);

		public IEnumerable<T> LeggiFile<T>(string fileName, ConvertRecordDelegate<T> recordBuilder)
		{
			using (StreamReader sr = File.OpenText(fileName))
			{
				foreach (T r in LeggiFile<T>(sr, recordBuilder))
					yield return r;
			}
		}

		public IEnumerable<T> LeggiFile<T>(Stream s, ConvertRecordDelegate<T> recordBuilder)
		{
			using (StreamReader sr = new StreamReader(s))
			{
				foreach (T r in LeggiFile<T>(sr, recordBuilder))
					yield return r;
			}
		}

		abstract public IEnumerable<T> LeggiFile<T>(StreamReader sr, ConvertRecordDelegate<T> recordBuilder);

		public static FileGenericReader CreateReader(BLLTSImport.TipoLTS tipo)
		{
			if (tipo == BLLTSImport.TipoLTS.A1)
				return new FileCastelloReader();
			else
				return new FileA2Reader();
		}
	}
	public class FileCastelloReader : FileGenericReader
	{
		readonly string[] _ListaTipoVeicolo;

		public FileCastelloReader()
		{
			List<string> a = new List<string>();
			for (int k = 0; ; ++k)
			{
				string tp = ReadAppSettings.ToString("LTS_Import.TipoVeicolo." + k.ToString(), "");
				if (tp.Length == 0)
					break;
				a.Add(tp);
			}
			_ListaTipoVeicolo = a.ToArray();
		}

		override public IEnumerable<T> LeggiFile<T>(StreamReader sr, ConvertRecordDelegate<T> recordBuilder)
		{
			_nLine = 0;
			_numeroErrori = 0;
			_numeroDiRecordLetti = 0;

			for (; ; )
			{
				string ss = sr.ReadLine();
				if (ss == null) break;
				_nLine++;

				ss = ss.Trim();
				if (ss.Length == 0) continue;

				string ssShort = ss;
				if (ss.Length > 20)
					ssShort = ss.Substring(0, 20) + "....";

				string operazione;
				if (true)
				{
					operazione = IsolaCampo(ref ss);
					if (operazione.Length == 0)
					{
						ManageError(_nLine, "Riga {0}: il primo carattere di ogni riga deve essere '0' oppure '1' - {1}", _nLine, ssShort);
						continue;
					}
					if (!(operazione == "0" || operazione == "1"))
					{
						ManageError(_nLine, "Riga {0}: il primo carattere di ogni riga deve essere '0' oppure '1' - {1}", _nLine, ssShort);
						continue;
					}
				}

				// 1 <targa> <nazione> <scadenza> <data seg> <nota>
				// 0 <targa> <nazione>

				// targa
				string targa;
				if (true)
				{
					targa = IsolaCampo(ref ss).ToUpper();

					if (targa.Length == 0)
					{
						ManageError(_nLine, "Riga {0}: campo targa non presente - {1}", _nLine, ssShort);
						continue;
					}
					if (targa.Length > 10)
					{
						ManageError(_nLine, "Riga {0}: campo targa troppo lungo - {1}", _nLine, ssShort);
						continue;
					}
					if (targa.Length <= 3)
					{
						ManageError(_nLine, "Riga {0}: campo targa troppo corto - {1}", _nLine, ssShort);
						continue;
					}
					if (CheckAZ09(targa, true) == false)
					{
						ManageError(_nLine, "Riga {0}: il campo targa contiene caratteri non validi - {1}", _nLine, ssShort);
						continue;
					}
				}

				string nazionalita;
				if (true)
				{
					nazionalita = IsolaCampo(ref ss).ToUpper();

					if (nazionalita.Length == 0)
					{
						ManageError(_nLine, "Riga {0}: campo nazione non presente - {1}", _nLine, ssShort);
						continue;
					}
					if (nazionalita.Length > 3)
					{
						ManageError(_nLine, "Riga {0}: campo nazione troppo lungo - {1}", _nLine, ssShort);
						continue;
					}
					if (CheckAZ09(nazionalita, false) == false)
					{
						ManageError(_nLine, "Riga {0}: campo nazione contiene caratteri non validi - {1}", _nLine, ssShort);
						continue;
					}
				}

				DateTime? scadenza = null;
				if (operazione == "1")
				{
					string strScadenza = IsolaCampo(ref ss);
					string lastError;
					bool ok = CheckDate(strScadenza, _nLine, "scadenza", out scadenza, out lastError, ssShort);
					if (!ok)
					{
						ManageError(_nLine, lastError);
						continue;
					}

					int yyyy = scadenza.Value.Year;
					int mm = scadenza.Value.Month;
					int dd = scadenza.Value.Day;

					scadenza = new DateTime(yyyy, mm, dd, 23, 59, 59);
				}

				DateTime? dataSegnalazione = null;
				if (operazione == "1")
				{
					string strSegnalazione = IsolaCampo(ref ss);

					string lastError;
					bool ok = CheckDate(strSegnalazione, _nLine, "data di segnalazione", out dataSegnalazione, out lastError, ssShort);
					if (!ok)
					{
						ManageError(_nLine, lastError);
						continue;
					}
				}

				string note = "";
				if (operazione == "1")
					note = ss;

				string tipoVeicolo = "";
				if (true)
				{
					for (int k = 0; k < _ListaTipoVeicolo.Length; ++k)
					{
						string tp = _ListaTipoVeicolo[k];
						if (note.StartsWith(tp + " "))
						{
							tipoVeicolo = tp;
							//note = note.Replace(tp + " ", "");
							break;
						}
					}
				}


				// se sono arrivato qui ho letto correttamente la riga.
				_numeroDiRecordLetti += 1;
				yield return recordBuilder(_nLine, operazione, targa, nazionalita, scadenza, dataSegnalazione, note, tipoVeicolo);
			}
		}

		static bool CheckAZ09(string ss, bool permettiNumeri)
		{
			foreach (char c in ss)
			{
				if (c >= 'A' && c <= 'Z') continue;
				if (permettiNumeri && c >= '0' && c <= '9') continue;
				return false;
			}
			return true;
		}

		static string IsolaCampo(ref string ss)
		{
			char[] ws = new char[] { ' ', '\t' };

			int idx = ss.IndexOfAny(ws);
			if (idx < 0)
			{
				string ret = ss;
				ss = "";
				return ret;
			}
			else
			{
				string ret = ss.Substring(0, idx);

				// faccio avanzare il rimanente della stringa
				// togliendo gli eventuali caratteri bianchi
				ss = ss.Substring(idx + 1);
				ss = ss.TrimStart(ws);

				return ret;
			}
		}

		static bool CheckDate(string ss, int nLine, string nomeCampo, out DateTime? dt, out string lastError, string ssShort)
		{
			lastError = null;

			dt = new DateTime();
			if (ss.Length > 10)
			{
				lastError = string.Format("Riga {0}: campo {1} troppo lungo - {2}", nLine, nomeCampo, ssShort);
				return false;
			}
			if (ss.Length < 10)
			{
				lastError = string.Format("Riga {0}: campo {1} troppo corto - {2}", nLine, nomeCampo, ssShort);
				return false;
			}

			if (ss[2] != '/' || ss[5] != '/')
			{
				lastError = string.Format("Riga {0}: campo {1} non nel formato gg/mm/aaaa - {2}", nLine, nomeCampo, ssShort);
				return false;
			}

			try
			{
				int gg = Int32.Parse(ss.Substring(0, 2));
				int mm = Int32.Parse(ss.Substring(3, 2));
				int aaaa = Int32.Parse(ss.Substring(6, 4));
				dt = new DateTime(aaaa, mm, gg);
			}
			catch
			{
				lastError = string.Format("Riga {0}: campo {1} non nel formato gg/mm/aaaa - {2}", nLine, nomeCampo, ssShort);
				return false;
			}

			return true;
		}
	}
	public class FileA2Reader : FileGenericReader
	{
		readonly Dictionary<string, string> _DicTipoVeicolo;

		public FileA2Reader()
		{
			_DicTipoVeicolo = new Dictionary<string, string>();

			for (int k = 0; ; ++k)
			{
				string tp = ReadAppSettings.ToString("LTS_Import.TipoVeicolo.A2." + k.ToString(), "");
				if (tp.Length == 0)
					break;

				string [] a = tp.Split(':');

				_DicTipoVeicolo[a[0]] = a[1];
			}
		}

		override public IEnumerable<T> LeggiFile<T>(StreamReader sr, ConvertRecordDelegate<T> recordBuilder)
		{
			_nLine = 0;
			_numeroErrori = 0;
			_numeroDiRecordLetti = 0;

			System.Globalization.CultureInfo itit = new System.Globalization.CultureInfo("it-it");


			// AAN36052120060625

			DateTime now = DateTime.Now;

			string firstLine = sr.ReadLine();

			for (; ; )
			{
				string ss = sr.ReadLine();
				if (ss == null) break;
				_nLine++;

				ss = ss.Trim();
				if (ss.Length == 0) continue;

				string ssShort = ss;
				if (ss.Length > 20)
					ssShort = ss.Substring(0, 20) + "....";

				string tipoVeicolo = ss.Substring(0, 1);

				if (_DicTipoVeicolo.ContainsKey(tipoVeicolo))
					tipoVeicolo = _DicTipoVeicolo[tipoVeicolo];
				else
					tipoVeicolo = "";

				string targa = ss.Substring(1, 8).Trim();
				if (targa.Length < 5)
				{
					ManageError(_nLine, "Riga {0}: il campo targa e` troppo corto - {1}", _nLine, ssShort);
					continue;
				}
				if (!CheckAZ09(targa, true))
				{
					ManageError(_nLine, "Riga {0}: il campo targa contiene caratteri non validi - {1}", _nLine, ssShort);
					continue;
				}

				string nazionalita = "I";
				DateTime scadutoIl;
				try
				{
					int yyyy = int.Parse(ss.Substring(9 + 0, 4));
					int mm   = int.Parse(ss.Substring(9 + 4, 2));
					int dd   = int.Parse(ss.Substring(9 + 4 + 2, 2));

					scadutoIl = new DateTime(yyyy, mm, dd);

					//if (scadutoIl > now)
					//{
					//    // non e` ancora scaduto... con lo inserisco neanche!!!
					//    continue;
					//}

				}
				catch 
				{
					ManageError(_nLine, "Riga {0}: il campo data contiene caratteri non validi - {1}", _nLine, ssShort);
					continue;
				}


				string note = U.F("Veicolo non revisionato: revisione prevista il {0}", scadutoIl.ToString("dd/MM/yyyy"));

				string operazione = "1";
				DateTime scadenza = new DateTime(2040, 1, 1);
				DateTime dataSegnalazione = new DateTime(scadutoIl.Year, scadutoIl.Month, DateTime.DaysInMonth(scadutoIl.Year, scadutoIl.Month));


				// se sono arrivato qui ho letto correttamente la riga.
				_numeroDiRecordLetti += 1;
				yield return recordBuilder(_nLine, operazione, targa, nazionalita, scadenza, dataSegnalazione, note, tipoVeicolo);
			}
		}

		static bool CheckAZ09(string ss, bool permettiNumeri)
		{
			foreach (char c in ss)
			{
				if (c >= 'A' && c <= 'Z') continue;
				if (permettiNumeri && c >= '0' && c <= '9') continue;
				return false;
			}
			return true;
		}

		static string IsolaCampo(ref string ss)
		{
			char[] ws = new char[] { ' ', '\t' };

			int idx = ss.IndexOfAny(ws);
			if (idx < 0)
			{
				string ret = ss;
				ss = "";
				return ret;
			}
			else
			{
				string ret = ss.Substring(0, idx);

				// faccio avanzare il rimanente della stringa
				// togliendo gli eventuali caratteri bianchi
				ss = ss.Substring(idx + 1);
				ss = ss.TrimStart(ws);

				return ret;
			}
		}

		static bool CheckDate(string ss, int nLine, string nomeCampo, out DateTime? dt, out string lastError, string ssShort)
		{
			lastError = null;

			dt = new DateTime();
			if (ss.Length > 10)
			{
				lastError = string.Format("Riga {0}: campo {1} troppo lungo - {2}", nLine, nomeCampo, ssShort);
				return false;
			}
			if (ss.Length < 10)
			{
				lastError = string.Format("Riga {0}: campo {1} troppo corto - {2}", nLine, nomeCampo, ssShort);
				return false;
			}

			if (ss[2] != '/' || ss[5] != '/')
			{
				lastError = string.Format("Riga {0}: campo {1} non nel formato gg/mm/aaaa - {2}", nLine, nomeCampo, ssShort);
				return false;
			}

			try
			{
				int gg = Int32.Parse(ss.Substring(0, 2));
				int mm = Int32.Parse(ss.Substring(3, 2));
				int aaaa = Int32.Parse(ss.Substring(6, 4));
				dt = new DateTime(aaaa, mm, gg);
			}
			catch
			{
				lastError = string.Format("Riga {0}: campo {1} non nel formato gg/mm/aaaa - {2}", nLine, nomeCampo, ssShort);
				return false;
			}

			return true;
		}
	}
	#endregion

	public class DalLTSImport : DalBase, IDalLTSImport
	{
		private List<BLLTSImport.Nazione> GetListaNazioni(OracleConnection cn)
		{
			using (OracleCommand cmd = CreateCommand(cn))
			{
				cmd.CommandText = "select * from nazioni";
				return this.RecordReader<BLLTSImport.Nazione>(cmd);
			}
		}
		public List<BLLTSImport.Nazione> GetListaNazioni()
		{
			using (OracleConnection cn = CreateConnection())
			{
				return GetListaNazioni(cn);
			}
		}

		public void ImportIncrementaleA1(string UserPkId, Stream s, bool daImportMassivo, bool inviaMessaggiDeltaAiC2P)
		{
			List<BLLTSImport.Nazione> nazioni = GetListaNazioni();
			LTS_ImportIncrementaleA1 d = new LTS_ImportIncrementaleA1();
			d.ImportIncrementaleA1(UserPkId, s, daImportMassivo, nazioni, inviaMessaggiDeltaAiC2P);
		}

		public void ImportMassivo(BLLTSImport.TipoLTS tipoLTS, string UserPkId, string fileNameWithPath)
		{
			LTS_x_ImportMassivo import = new LTS_x_ImportMassivo();
			import.Insert(tipoLTS, fileNameWithPath, DateTime.Now, UserPkId);
			return;
		}

		public void CancellaLTS(BLLTSImport.TipoLTS tipoLTS)
		{
			LTS_x_ImportMassivo import = new LTS_x_ImportMassivo();
			import.CancellaLTS(tipoLTS);
		}

		//////////////////////////////////////////////////////////////////////////

		/// <summary>
		/// Crea il file di differenze partendo dal formato massivo in XML o dal formato massivo Castello.
		/// In uscita si ha un file 
		/// </summary>
		/// <param name="fileNameIn"></param>
		/// <param name="A1orA2"></param>
		/// <param name="fileNameOut"></param>
		public int CreaDifferenze(string UserPkId, string fileNameIn, string fileNameOut)
		{
			LTS_ImportIncrementaleA1 d = new LTS_ImportIncrementaleA1();
			return d.CreaDifferenze(UserPkId, fileNameIn, fileNameOut);
		}


		public List<BLLTSImport.AttivazioneA2> GetListaAttivazioneA2()
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = @"
select 	
AttivazioneA2.IdC2P,
Descrizione,
DataOraInizioAttivazione,
DataOraFineAttivazione,
GiorniTolleranzaRevisione,
TipoVeicolo,
CorsieAbilitate
from AttivazioneA2
inner join C2P
on C2P.IdC2p = AttivazioneA2.IdC2P
order by Descrizione
";
					return this.RecordReader<BLLTSImport.AttivazioneA2>(cmd);
				}
			}
		}

		public void AggiornaAttivazioneA2(BLLTSImport.AttivazioneA2 record)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = @"
UPDATE ITRS.ATTIVAZIONEA2
SET 
DATAORAINIZIOATTIVAZIONE   = :p_di, 
DATAORAFINEATTIVAZIONE     = :p_df, 
GIORNITOLLERANZAREVISIONE  = :p_delta, 
TIPOVEICOLO                = :p_tipoVeicolo, 
CORSIEABILITATE            = :p_CorsieAbilitate
WHERE 
IdC2p = :p_idC2p
";
					cmd.AddWithValue("p_IdC2p", record.IdC2P);
					cmd.AddWithValue("p_di", record.DataOraInizioAttivazione);
					cmd.AddWithValue("p_df", record.DataOraFineAttivazione);
					cmd.AddWithValue("p_delta", record.GiorniTolleranzaRevisione);
					cmd.AddWithValue("p_tipoVeicolo", record.TipoVeicolo);
					cmd.AddWithValue("p_CorsieAbilitate", record.CorsieAbilitate);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

	}

	class SafeLogger : IDisposable
	{
		readonly int _maxLog;
		int _nLog;
		readonly string _UserPkId;
		readonly string _endMessage;
		bool _closed;

		public SafeLogger(string UserPkId, int maxToLog, string endMessage)
		{
			_UserPkId = UserPkId;
			_maxLog = maxToLog;
			_nLog = 0;
			_endMessage = endMessage;
			_closed = false;
		}

		public void Log(string fmt, params object[] args)
		{
			_nLog += 1;

			if (_nLog <= _maxLog)
				LogWrite(_UserPkId, fmt, _nLog);
		}

		public void Close()
		{
			if (_closed) return;

			_closed = true;
			if (_nLog > 0)
				LogWrite(_UserPkId, _endMessage, _nLog);
		}

		void IDisposable.Dispose()
		{
			Close();
		}


		public static string LogWrite(string UserPkId, string fmt, params object[] args)
		{
			try
			{
				string a = string.Format(fmt, args);
				using (ITRS_BL.BLLog blLog = new ITRS_BL.BLLog())
				{
					blLog.AddUserActivity(UserPkId, TipoAttivita.ImportLTS, a);
				}
				return a;
			}
			catch
			{
				return string.Empty;
			}
		}
	}

	class LTS_x_ImportMassivo : DalBase
	{
		public void Insert(
			BLLTSImport.TipoLTS tipoLTS,
			string fileNameWithPath,
			DateTime DataOraInserimento,
			string UserPkId)
		{
			int recordDaInserire;

			SafeLogger.LogWrite(UserPkId, "Ricerca record errati e targhe duplicate {0}", tipoLTS);

			Dictionary<int, object> righeDaScartare = GetListaRigheDaScartare(UserPkId, fileNameWithPath, tipoLTS, out recordDaInserire);
			if (recordDaInserire == 0)
			{
				SafeLogger.LogWrite(UserPkId, "Attenzione! non ci sono record da inserire !!");
				return;
			}
			U.GC_Collect();

			SafeLogger.LogWrite(UserPkId, "Creazione nuova tabella LTS_{0}", tipoLTS);
			string tableId = CreateTable(tipoLTS);
			SafeLogger.LogWrite(UserPkId, "Creata tabella LTS_{0}_{1}", tipoLTS, tableId);

			if (ReadAppSettings.ToBoolean("LTS_Import.ImportMassivo.SqlLoader", true))
				InsertSqlLoader(tipoLTS, fileNameWithPath, DataOraInserimento, UserPkId, righeDaScartare, tableId, recordDaInserire);
			else
				IntsertBulk(tipoLTS, fileNameWithPath, DataOraInserimento, UserPkId, righeDaScartare, tableId);

			U.GC_Collect();


			SafeLogger.LogWrite(UserPkId, "Swap tabella");
			if (true)
			{
				bool swapError = true;
				int nMax = ReadAppSettings.ToInt32("LTS_Import.ImportMassivo.SwapTable.NumeroMassimoTentativi", 5);
				Random m = new Random();
				for (int t = 0; t < nMax; ++t)
				{
					try
					{
						swapError = true;
						SwapTable(tipoLTS, tableId);
						swapError = false;
					}
					catch (OracleException oex)
					{
						SafeLogger.LogWrite(UserPkId, "Tentativo {0} fallito - {1}", t, oex.Message);

						// questo sleep random serve per riprovarci tra un po'
						// piu` tentativi si fanno piu` si aspetta.
						System.Threading.Thread.Sleep(500 + m.Next(t * 5000));
					}
					if (swapError == false)
						break;
				}
				if (swapError)
				{
					SafeLogger.LogWrite(UserPkId, "Swap tabella: operazione fallita");
					throw new ApplicationException("Swap tabella: operazione fallita");
				}
			}

			SafeLogger.LogWrite(UserPkId, "Drop tabelle precedenti upload");
			DropTable(tipoLTS);
		}

		public Dictionary<int, object> GetListaRigheDaScartare(string UserPkId, string fileNameWithPath, BLLTSImport.TipoLTS tipoLTS, out int recordDaInserire)
		{
			recordDaInserire = 0;
			DateTime DataOraInserimento = DateTime.Now;

			// per evitare di farmi fregare nel caso nel file ci siano targhe doppie,
			// leggo una prima volta il file per costruire la lista delle targhe con chiave targa+naz
			// per trovare le targhe duplicate.
			// Questa lista e` in memoria: attualmente in A1 ci sono 2.000.000 di targhe
			// tenendosi larghi (ma non troppo) se avessimo 10.000.000 di entry nel file (righe)
			// e una entry pesasse 100byte avremmo 10e7*1e2 = 1e9 --> 1Gbyte
			// SIAMO gia` al limite !!!!!
			// Ora pero` abbiamo 2e6*1e2 = 2e8 --> 200Mb (e` affrontabile tranquillamente)
			// L'unica soluzione per affrontare numeri piu` grossi e` 
			// 1) affidarsi al db per trovare i duplicati (e aspettare una sacco per fare l'import)
			// 2) mettere la lista su disco e diventare matti (sort esterni e altre diavolerie)
			// per ora l'unica cosa ragionevole e` tenere in memoria la lista 
			// e aspettare che la lista esploda


			// dato che si chiedera` molta memoria inizio liberando tutto.
			U.GC_Collect();

			Dictionary<string, bool> nazioni = new Dictionary<string, bool>();
			{
				using (BLLTSImport bl = new BLLTSImport())
				{
					List<BLLTSImport.Nazione> listaNazioni = bl.GetListaNazioni();
					foreach (BLLTSImport.Nazione naz in listaNazioni)
						nazioni.Add(naz.Sigla_Nazione, true);
				}
			}

			// leggo il file per avere la lista delle righe da scartare.
			Dictionary<int, object> righeDaScartare = new Dictionary<int, object>();
			{
				// questa lista contiene k=targa+naz
				// valore la riga in cui e` stata vista la chive e il numero di occorrenza della targa+n sempre nel file
				Dictionary<string, LineRecord> listaTargheDaImportare = new Dictionary<string, LineRecord>(500 * 1024);

				// questo try serve per forzare nel finally, qualunque cosa accada, un GC.Collect
				try
				{
					int numeroIns = 0;
					int numeroDel = 0;

					SafeLogger safeLoggerNazioniSconosciute = new SafeLogger(UserPkId,
						ReadAppSettings.ToInt32("ImportMassivo.maxNumeroDiNazioniSconosciuteDaLoggare", 20),
						"Il file contiene {0} record con nazioni sconosciute");

					SafeLogger safeLoggerRecordGiaScaduti = new SafeLogger(UserPkId,
						ReadAppSettings.ToInt32("ImportMassivo.maxNumeroDiRecordGiaScadutiDaLoggare", 20),
						"Il file contiene {0} record gia` scaduti");



					FileCastelloReader.ConvertRecordDelegate<string> conv = delegate(int lineaCorrente, string operazione, string targa, string naz, DateTime? scadenza, DateTime? data_segnalazione, string note, string tipoVeicolo)
					{
						if (operazione == "1")
							numeroIns += 1;
						else
							numeroDel += 1;


						string targaNazionalita = targa + "@" + naz;

						if (!nazioni.ContainsKey(naz))
						{
							safeLoggerNazioniSconosciute.Log("Import targhe: Riga {0}: {1}/{2} specifica una nazione non conosciuta dal sistema.", lineaCorrente, targa, naz);
							righeDaScartare.Add(lineaCorrente, null);
						}
						else if (scadenza < DataOraInserimento)
						{
							safeLoggerRecordGiaScaduti.Log("Import targhe: Riga {0}: '{1}/{2}' presenta una data di scadenza ({3}) gia` passata.", lineaCorrente, targa, naz, scadenza);
							righeDaScartare.Add(lineaCorrente, null);
						}
						else
						{
							if (listaTargheDaImportare.ContainsKey(targaNazionalita))
							{
								// la targa/naz e` gia` presente nel file !
								// Devo invalidare la precedente entry nel file per la stessa targa.
								LineRecord rr = listaTargheDaImportare[targaNazionalita];
								righeDaScartare.Add(rr.Line, null);// qui metto la precedente entry della stessa targa invalida
								rr.Occorrenza += 1; // qui conto il numero di volte che ho visto la stessa targa.
								rr.Line = lineaCorrente; // questa riga potenzialmente e` l'ultima
								listaTargheDaImportare[targaNazionalita] = rr;
							}
							else
							{
								// e` la prima volta che si vede questa targa/naz
								LineRecord rr;
								rr.Line = lineaCorrente;
								rr.Occorrenza = 1;
								listaTargheDaImportare.Add(targaNazionalita, rr);
							}
						}

						return targaNazionalita;
					};


					FileGenericReader fcr = FileGenericReader.CreateReader(tipoLTS);

					using (SafeLogger safeLoggerErroriNelFile = new SafeLogger(UserPkId,
						ReadAppSettings.ToInt32("ImportMassivo.MassimoNumeroDiErroriPermessiNelFile", 100),
						"Il file contiene {0} errori di sintassi"))
					{
						fcr.OnError += delegate(int lineaCorrente, string errorMsg)
						{
							safeLoggerErroriNelFile.Log(errorMsg);
							righeDaScartare.Add(lineaCorrente, null);
						};

						using (U.GC_Collecter gc = new U.GC_Collecter("GetListaRigheDaScartare"))
						{
							// leggo il file - sembra un loop a vuoto, ma si fa tutto in conv
							foreach (string targaNazionalita in fcr.LeggiFile<string>(fileNameWithPath, conv))
							{
								gc.Collect();
							}
						}
					}

					safeLoggerNazioniSconosciute.Close();
					safeLoggerRecordGiaScaduti.Close();


					using (SafeLogger safeLoggerTargheDuplicate = new SafeLogger(UserPkId,
						ReadAppSettings.ToInt32("ImportMassivo.maxNumeroDiDuplicatiLoggati", 20),
						"Sono state trovate nel file in ingresso {0} targhe duplicate"))
					{
						foreach (KeyValuePair<string, LineRecord> rrr in listaTargheDaImportare)
							if (rrr.Value.Occorrenza > 1)
							{
								string t = rrr.Key.Substring(0, rrr.Key.Length - 1);
								string n = rrr.Key.Substring(rrr.Key.Length - 1, 1);

								safeLoggerTargheDuplicate.Log("Targa duplicata nel file in ingresso {0}/{1} numero occorrenze {2}", t, n, rrr.Value);
							}
					}

					SafeLogger.LogWrite(UserPkId, "Numero totale di record nel file {0}", fcr.NumeroRigheNelFile);

					recordDaInserire = listaTargheDaImportare.Count;
					SafeLogger.LogWrite(UserPkId, "Numero di record da importare {0} (tolti i duplicati e record errati)", listaTargheDaImportare.Count);

					if (numeroDel > 0)
					{
						// sono in import massivo. NON sono concesse cancellazioni !
						string errMsg = SafeLogger.LogWrite(UserPkId, "Attenzione il file contiene dei record che indicano cancellazione: la cancellazione non e` compatibile con l'import massivo");
						throw new Exception(errMsg);
					}
				}
				finally
				{
					listaTargheDaImportare = null;
					U.GC_Collect();
				}
			}

			return righeDaScartare;
		}

		private string CreateTable(BLLTSImport.TipoLTS tipoLTS)
		{
			string sql = ReadAppSettings.ToStringFromFile("LTS_Import.ImportMassivo.Db.CreateTable", @"
CREATE TABLE ITRS.LTS_{1}_{0} 
( 
    TARGA                	VARCHAR2(10)  NOT NULL,
    NAZIONALITA          	VARCHAR2(6)   NOT NULL,
    IDLTS                	NUMBER(10,0)  NOT NULL,
    ENUMTIPOLTS          	VARCHAR2(5)   NOT NULL,
    IDUTENTERICHIEDENTE  	VARCHAR2(36)  NOT NULL,
    MOTIVO               	VARCHAR2(256) NULL,
    NOTE                 	VARCHAR2(256) NULL,
    DATAORAINSERIMENTO   	DATE          NOT NULL,
    DATAORAINIZIOVALIDITA	DATE          NOT NULL,
    DATAORAFINEVALIDITA  	DATE          NULL,
    ENUMTIPODEST         	VARCHAR2(5)   NOT NULL,
    ADDRDEST             	VARCHAR2(256) NULL,
    ENUMLIVELLOPRIORITA  	VARCHAR2(5)   NOT NULL,
    TAB_TELAIO           	VARCHAR2(21)  NULL,
    TAB_DATA_FURTO       	VARCHAR2(11)  NULL,
    TAB_FABBRICA         	VARCHAR2(25)  NULL,
    TAB_MODELLO          	VARCHAR2(20)  NULL,
    TAB_TIPO_VEICOLO     	VARCHAR2(25)  NULL,
    TAB_TIPO_DENUNCIA    	VARCHAR2(16)  NULL,
    TAB_CODICE_UFFICIO   	VARCHAR2(7)   NULL,
    TAB_UFFICIO          	VARCHAR2(40)  NULL,
    constraint LTS_{1}_{0}_PK PRIMARY KEY(TARGA, NAZIONALITA, IDLTS) using index tablespace ITRS_IDX
)
TABLESPACE ITRS_DATA
GO

ALTER TABLE ITRS.LTS_{1}_{0} ADD (CONSTRAINT LTS_{1}_{0}_CK3 CHECK (ENUMTIPODEST IN ('none','COA','EMAIL')) NOT DEFERRABLE INITIALLY IMMEDIATE)
GO

ALTER TABLE ITRS.LTS_{1}_{0} ADD (CONSTRAINT LTS_{1}_{0}_CK2 CHECK (ENUMLIVELLOPRIORITA IN ('MAX','NORM','LOW')) NOT DEFERRABLE INITIALLY IMMEDIATE)
GO

ALTER TABLE ITRS.LTS_{1}_{0} ADD (CONSTRAINT LTS_{1}_{0}_CK1 CHECK (ENUMTIPOLTS IN ('{1}')) NOT DEFERRABLE INITIALLY IMMEDIATE )
GO
");
			string tableId = U.F("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now);
			sql = U.F(sql, tableId, tipoLTS);

			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				foreach (string c in ParseSql(sql))
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = c;
						cmd.ExecuteNonQuery();
					}
				}
			}

			return tableId;
		}

		private void IntsertBulk(
			BLLTSImport.TipoLTS tipoLTS,
			string fileNameWithPath,
			DateTime DataOraInserimento,
			string UserPkId,
			Dictionary<int, object> righeDaScartare,
			string tableId)
		{
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				using (OracleCommand cmd = CreateCommand(cn))
				{
					string q = @"
insert into LTS_{1}_{0} (
TARGA, NAZIONALITA, IDLTS,ENUMTIPOLTS,ENUMLIVELLOPRIORITA,IDUTENTERICHIEDENTE,MOTIVO,NOTE,DATAORAINSERIMENTO,
DATAORAINIZIOVALIDITA,DATAORAFINEVALIDITA,ENUMTIPODEST,ADDRDEST,
tab_telaio,tab_data_furto,tab_fabbrica,tab_modello,tab_tipo_veicolo,tab_tipo_denuncia,tab_codice_ufficio,tab_ufficio
)values(
:p_Targa,:p_Nazionalita,SEQ_LTS.nextval,:p_EnumTipoLts,:p_EnumLivelloPriorita,:p_IdUtenteRichiedente,:p_Motivo,:p_Note,
:p_DataOraInserimento,:p_DataOraInizioValidita,:p_DataOraFineValidita,:p_EnumTipoDest,:p_AddressDest,:p_tab_telaio,
:p_tab_data_furto,:p_tab_fabbrica,:p_tab_modello,:p_tab_tipo_veicolo,:p_tab_tipo_denuncia,:p_tab_codice_ufficio,:p_tab_ufficio)";

					cmd.CommandText = U.F(q, tableId, tipoLTS);


					FileGenericReader fcr = FileGenericReader.CreateReader(tipoLTS);
					FileCastelloReader.ConvertRecordDelegate<RecordCastello> recordBuilder = delegate(int lineaCorrente, string operazione, string targa, string naz, DateTime? scadenza, DateTime? data_segnalazione, string note, string tipoVeicolo)
					{
						RecordCastello rec = new RecordCastello();
						rec.Operazione = operazione;
						rec.Targa = targa;
						rec.Nazionalita = naz;
						rec.Scadenza = scadenza;
						rec.DataSegnalazione = data_segnalazione;
						rec.Note = note;
						rec.TipoVeicolo = tipoVeicolo;
						return rec;
					};

					int numeroDiInsertEffettuate = 0;
					DateTime tsNow = DateTime.Now;

					// questo e` il max numero di insert per bulkinsert.
					int maxInsertBulk = ReadAppSettings.ToInt32("LTS_Import.ImportMassivo.MaxInsertBulk", 500);
					int stepRecordToLog = ReadAppSettings.ToInt32("LTS_Import.ImportMassivo.StepToLog", 100 * 1000);

					// questi sono gli array necessarri per fare il bulkinsert di maxArrayCount items;
					string[] p_Targa = new string[maxInsertBulk];
					string[] p_Nazionalita = new string[maxInsertBulk];
					string[] p_EnumTipoLts = new string[maxInsertBulk];
					string[] p_EnumLivelloPriorita = new string[maxInsertBulk];
					string[] p_IdUtenteRichiedente = new string[maxInsertBulk];
					string[] p_Motivo = new string[maxInsertBulk];
					string[] p_Note = new string[maxInsertBulk];
					DateTime[] p_DataOraInserimento = new DateTime[maxInsertBulk];
					DateTime[] p_DataOraFineValidita = new DateTime[maxInsertBulk];
					DateTime[] p_DataOraInizioValidita = new DateTime[maxInsertBulk];
					string[] p_EnumTipoDest = new string[maxInsertBulk];
					string[] p_AddressDest = new string[maxInsertBulk];
					string[] p_tab_telaio = new string[maxInsertBulk];
					string[] p_tab_data_furto = new string[maxInsertBulk];
					string[] p_tab_fabbrica = new string[maxInsertBulk];
					string[] p_tab_modello = new string[maxInsertBulk];
					string[] p_tab_tipo_veicolo = new string[maxInsertBulk];
					string[] p_tab_tipo_denuncia = new string[maxInsertBulk];
					string[] p_tab_codice_ufficio = new string[maxInsertBulk];
					string[] p_tab_ufficio = new string[maxInsertBulk];

					U.FilterPredicate<RecordCastello> filterPredicate = delegate(RecordCastello r)
					{
						return !righeDaScartare.ContainsKey(fcr.NumeroRigheNelFile);
					};

					using (U.GC_Collecter gc = new U.GC_Collecter("InsertBulk"))
					{
						// leggo il file come se fosse una collezione (LeggiFile)
						// e raggruppando i record letti a blocchi di maxInsertBulk (U.Group)
						foreach (List<RecordCastello> r in
							U.Group( // raggruppa per maxInsertBulk
								U.Filter<RecordCastello>( // filtra per scartare i record in righeDaScartare
									fcr.LeggiFile<RecordCastello>(fileNameWithPath, recordBuilder), // legge da file
									filterPredicate),
								maxInsertBulk))
						{
							int numToInsert = 0;

							gc.Collect();

							foreach (RecordCastello R in r)
							{
								p_Targa[numToInsert] = R.Targa;
								p_Nazionalita[numToInsert] = R.Nazionalita;
								p_EnumTipoLts[numToInsert] = tipoLTS.ToString();
								p_EnumLivelloPriorita[numToInsert] = "NORM";
								p_IdUtenteRichiedente[numToInsert] = UserPkId;
								p_Motivo[numToInsert] = string.Empty;
								p_Note[numToInsert] = R.Note;
								p_DataOraInserimento[numToInsert] = DataOraInserimento;
								p_DataOraInizioValidita[numToInsert] = R.DataSegnalazione.Value;
								p_DataOraFineValidita[numToInsert] = R.Scadenza.Value;
								p_EnumTipoDest[numToInsert] = "none";
								p_AddressDest[numToInsert] = string.Empty;
								p_tab_telaio[numToInsert] = string.Empty;
								p_tab_data_furto[numToInsert] = string.Empty;
								p_tab_fabbrica[numToInsert] = string.Empty;
								p_tab_modello[numToInsert] = string.Empty;
								p_tab_tipo_veicolo[numToInsert] = R.TipoVeicolo;
								p_tab_tipo_denuncia[numToInsert] = string.Empty;
								p_tab_codice_ufficio[numToInsert] = string.Empty;
								p_tab_ufficio[numToInsert] = string.Empty;

								numToInsert += 1;
							}

							if (numToInsert > 0)
							{
								cmd.Parameters.Clear();
								cmd.ArrayBindCount = numToInsert;

								cmd.AddWithValue(":p_Targa", p_Targa);
								cmd.AddWithValue(":p_Nazionalita", p_Nazionalita);
								cmd.AddWithValue(":p_EnumTipoLts", p_EnumTipoLts);
								cmd.AddWithValue(":p_EnumLivelloPriorita", p_EnumLivelloPriorita);
								cmd.AddWithValue(":p_IdUtenteRichiedente", p_IdUtenteRichiedente);
								cmd.AddWithValue(":p_Motivo", p_Motivo);
								cmd.AddWithValue(":p_Note", p_Note);
								cmd.AddWithValue(":p_DataOraInserimento", p_DataOraInserimento);
								cmd.AddWithValue(":p_DataOraInizioValidita", p_DataOraInizioValidita);
								cmd.AddWithValue(":p_DataOraFineValidita", p_DataOraFineValidita);
								cmd.AddWithValue(":p_EnumTipoDest", p_EnumTipoDest);
								cmd.AddWithValue(":p_AddressDest", p_AddressDest);
								cmd.AddWithValue(":p_tab_telaio", p_tab_telaio);
								cmd.AddWithValue(":p_tab_data_furto", p_tab_data_furto);
								cmd.AddWithValue(":p_tab_fabbrica", p_tab_fabbrica);
								cmd.AddWithValue(":p_tab_modello", p_tab_modello);
								cmd.AddWithValue(":p_tab_tipo_veicolo", p_tab_tipo_veicolo);
								cmd.AddWithValue(":p_tab_tipo_denuncia", p_tab_tipo_denuncia);
								cmd.AddWithValue(":p_tab_codice_ufficio", p_tab_codice_ufficio);
								cmd.AddWithValue(":p_tab_ufficio", p_tab_ufficio);

								cmd.ExecuteNonQuery();
							}

							numeroDiInsertEffettuate += 1;
						}

						// ogni 100.000 record logo l'avvenimento.
						if (numeroDiInsertEffettuate % (stepRecordToLog / maxInsertBulk) == 0)
							Log.Write(UserPkId, "record inseriti {0}", numeroDiInsertEffettuate * maxInsertBulk);
					}
				}
			}
		}


		private void InsertSqlLoader(
			BLLTSImport.TipoLTS tipoLTS,
			string fileNameWithPath,
			DateTime DataOraInserimento,
			string UserPkId,
			Dictionary<int, object> righeDaScartare,
			string tableId,
			int numeroDiRecordDaImportare)
		{
			SafeLogger.LogWrite(UserPkId, "Calcolo degli idlts");

			decimal idLts;
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "ITRS.SEQNEXTBYSTEP";

					cmd.AddWithValue("n", numeroDiRecordDaImportare);

					using (OracleParameter p = new OracleParameter())
					{
						p.DbType = DbType.Decimal;
						p.Direction = ParameterDirection.ReturnValue;
						p.Value = 0;
						cmd.Parameters.Add(p);

						cmd.ExecuteNonQuery();

						idLts = (decimal)p.Value;
					}
				}
			}

			SafeLogger.LogWrite(UserPkId, "Creazione file per il SqlLoader");

			string h = @"LOAD DATA
INFILE *
TRUNCATE INTO TABLE LTS_{2}_{0}
FIELDS TERMINATED BY ' ' optionally enclosed by '""' TRAILING NULLCOLS
(
targa,
nazionalita,
idlts,
DATAORAFINEVALIDITA   DATE ""DD/MM/YYYY"",
DATAORAINIZIOVALIDITA DATE ""DD/MM/YYYY"",
DATAORAINSERIMENTO    DATE ""YYYYMMDDHH24MISS"",
tab_tipo_veicolo,
note,
enumtipolts           CONSTANT '{2}',
idutenterichiedente   CONSTANT '{1}',
ENUMTIPODEST          CONSTANT 'none',
ENUMLIVELLOPRIORITA   CONSTANT 'NORM'
)
BEGINDATA";

			string LocalWorkingDir = ReadAppSettings.ToString("LTS_Import.ImportMassivo.SqlLoader.LocalWorkingDir", @"$$\ITRS_Service\tmp_ImportMassivo");
			if (!Directory.Exists(LocalWorkingDir)) Directory.CreateDirectory(LocalWorkingDir);

			string fnZip = Path.Combine(LocalWorkingDir, "SqlLoader.zip");

			// scrivo il file con lo StreamWriter f : lo StreamWriter scrive stringhe in formato Windows
			// dentro lo stream passato nel costruttore.
			// Lo stream nel costruttore e` un WriteUnixStream che strippa CR/NL e scrive solo NL
			// A sua volta WriteUnixStream scrive in uno ZipSingleFileCreate che e` uno stream che 
			// serve per zippare il file creando il file .zip fnZip con dentro il file "SqlLoader.dat"
			// N.B.
			// Le stream/stream writer in catena non hanno bisogo di essere tutti Disposed...
			// basta il primo!
			// quando si raggiunge la fine dello using lo StreamWriter flusha e chiude WriteUnixStream
			// che a sua volta chiude lo zip.
			// Tutto questo casino per evitare di consumare troppo tempo/memoria.
			// Note sul BOM... se lo StreamWriter viene creato specificando uno stream e niente altro 
			// non ci ritroveremo in unix il preampolo UTF8 che da tanto fastidio al sqlldr e in generale a 
			// Linux (un mondo in cui utf e` un modo per trattare il latte)
			using (StreamWriter f = new StreamWriter(new U.UnixStream(U.ZipSingleFileCreate(fnZip, "SqlLoader.dat"))))
			{
				f.WriteLine(h, tableId, UserPkId, tipoLTS);

				FileCastelloReader.ConvertRecordDelegate<RecordCastello> recordBuilder = delegate(int lineaCorrente, string operazione, string targa, string naz, DateTime? scadenza, DateTime? data_segnalazione, string note, string tipoVeicolo)
				{
					RecordCastello rec = new RecordCastello();
					rec.Operazione = operazione;
					rec.Targa = targa;
					rec.Nazionalita = naz;
					rec.Scadenza = scadenza;
					rec.DataSegnalazione = data_segnalazione;
					rec.Note = note;
					rec.TipoVeicolo = tipoVeicolo;
					return rec;
				};

				FileGenericReader fcr = FileGenericReader.CreateReader(tipoLTS);

				using (U.GC_Collecter gc = new U.GC_Collecter("InsertSqlLoader"))
				{
					foreach (RecordCastello r in fcr.LeggiFile<RecordCastello>(fileNameWithPath, recordBuilder))
					{
						gc.Collect();

						if (righeDaScartare.ContainsKey(fcr.NumeroRigheNelFile))
							continue;

						f.WriteLine("{0} {1} {2} {3} {4:d} {5} \"{6}\" \"{7}\"",
							r.Targa, r.Nazionalita, idLts++,
							string.Format("{0:dd}/{0:MM}/{0:yyyy}", r.Scadenza),
							string.Format("{0:dd}/{0:MM}/{0:yyyy}", r.DataSegnalazione),
							string.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DataOraInserimento),
							r.TipoVeicolo, r.Note);
					}
				}
			}


			//if (ReadAppSettings.ToBoolean("LTS_Import.ImportMassivo.SqlLoader.Remote", true))
			{
				SafeLogger.LogWrite(UserPkId, "Zip del file per il SqlLoader");

				//U.Dos2Unix(fn);
				//string fnZip = U.ZipSingleFile(fn, Path.GetDirectoryName(fn));
				//File.Delete(fn);

				string RemoteWorkingDir = ReadAppSettings.ToString("RemoteDir.SqlLoaderData", "SqlLoaderData");
				string zipFile = Path.GetFileNameWithoutExtension(fnZip) + ".zip";
				string datFile = Path.GetFileNameWithoutExtension(fnZip) + ".dat";
				string logFile = Path.GetFileNameWithoutExtension(fnZip) + ".log";

				SafeLogger.LogWrite(UserPkId, "Cancellazione file relativi a import massivi precedenti nel server");
				{
					U.PuTTYClient.ExecuteAndReturnExitCode(null, string.Format("rm -f {0}/{1}", RemoteWorkingDir, datFile));
					U.PuTTYClient.ExecuteAndReturnExitCode(null, string.Format("rm -f {0}/{1}", RemoteWorkingDir, zipFile));
					U.PuTTYClient.ExecuteAndReturnExitCode(null, string.Format("rm -f {0}/{1}", RemoteWorkingDir, logFile));
				}

				SafeLogger.LogWrite(UserPkId, "Invio del file {0} per il SqlLoader al server", fnZip);
				{
					U.PuTTYClient.Upload(null, Path.GetDirectoryName(fnZip), Path.GetFileName(fnZip), RemoteWorkingDir, null);
					File.Delete(fnZip);
				}

				{
					string cmdUnzip = "unzip -o {0}/{1} -d {0}";
					cmdUnzip = string.Format(cmdUnzip, RemoteWorkingDir, zipFile);
					SafeLogger.LogWrite(UserPkId, "Unzip del file lato remoto: {0}", cmdUnzip);
					U.PuTTYClient.Execute(null, cmdUnzip);
				}

				{
					string cmd = "$ORACLE_HOME/bin/sqlldr itrs/itrs@itrsdb direct=true control={0}/{1} log={0}/{2}";
					cmd = string.Format(cmd, RemoteWorkingDir, datFile, logFile);
					int milliSecTimeout = 1000 * ReadAppSettings.ToInt32("RemoteDir.SqlLoaderData.ExecutionSecTimeout", 60 * 60);
					SafeLogger.LogWrite(UserPkId, "Esecuzione del SqlLoader: {0}", cmd);
					U.PuTTYClient.Execute(null, cmd, milliSecTimeout);
				}
			}

			SafeLogger.LogWrite(UserPkId, "SqlLoader terminato");
		}

		public void SwapTable(BLLTSImport.TipoLTS tipoLTS, string tableId)
		{
			string sql = "CREATE OR REPLACE SYNONYM ITRS.LTS_{1} FOR ITRS.LTS_{1}_{0}";
			sql = ReadAppSettings.ToStringFromFile("LTS_Import.ImportMassivo.Db.SwapTable", sql);
			sql = U.F(sql, tableId, tipoLTS);

			List<string> tbDaCancellare = new List<string>();
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				foreach (string c in ParseSql(sql))
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = c;
						cmd.ExecuteNonQuery();
					}
				}
			}
		}

		public void DropTable(BLLTSImport.TipoLTS tipoLTS)
		{
			List<string> tbDaCancellare = new List<string>();
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				using (OracleCommand cmd = CreateCommand(cn))
				{
					string sql = ReadAppSettings.ToStringFromFile("LTS_Import.ImportMassivo.Db.DropTable.Select", @"
select T.tb
from 
(
	select 
	table_name tb, 
	substr(table_name, 1 + length('LTS_{0}_'), 8) dataTb 
	from 
	user_tables where 
	table_name like 'LTS_{0}_%'
	and table_name not in 
	(
		select 
		table_name 
		from USER_SYNONYMS
		where USER_SYNONYMS.SYNONYM_NAME = 'LTS_{0}'
	)
) T
where T.dataTb <= to_char(trunc(sysdate) - 2, 'YYYYMMDD')");

					sql = U.F(sql, tipoLTS);

					cmd.CommandText = sql;

					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						while (rd.Read())
							tbDaCancellare.Add((string)rd[0]);
					}
				}

				string cs = ReadAppSettings.ToStringFromFile("LTS_Import.ImportMassivo.Db.DropTable.Drop", "drop table {0}");
				foreach (string tb in tbDaCancellare)
				{
					foreach (string c in ParseSql(cs))
					{
						using (OracleCommand cmd = CreateCommand(cn))
						{
							cmd.CommandText = string.Format(c, tb);
							cmd.ExecuteNonQuery();
						}
					}
				}
			}
		}

		static bool CheckRecord(RecordCastello R, List<BLLTSImport.Nazione> nazioni, DateTime tsNow, Dictionary<string, int> listaTargeDaImportare)
		{
			bool nazFound = false;
			foreach (BLLTSImport.Nazione nz in nazioni)
			{
				if (R.Nazionalita == nz.Sigla_Nazione)
				{
					nazFound = true;
					break;
				}
			}

			if (!nazFound)
			{
				Log.Write("Import targhe: la nazione '{0}' non e` conosciuta dal sistema.", R.Nazionalita);
				return false;
			}

			if (R.Scadenza < tsNow)
				return false;

			string t = R.Targa + R.Nazionalita;

			if (listaTargeDaImportare.ContainsKey(t))
			{
				listaTargeDaImportare[t] -= 1;
				if (listaTargeDaImportare[t] > 0)
					return false;  // ne esiste un'altra entry della stessa targa piu` avanti nel file.
			}

			return true;
		}

		struct LineRecord
		{
			public int Line;
			public int Occorrenza;
		}


		public void CancellaLTS(BLLTSImport.TipoLTS tipoLTS)
		{
			// select TABLE_NAME from USER_SYNONYMS where SYNONYM_NAME = 'LTS_A1'
			// truncate table {TABLE_NAME}

			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				string tableName = null;

				using (OracleCommand cmd = CreateCommand(cn))
				{
					string sql = "select TABLE_NAME from USER_SYNONYMS where SYNONYM_NAME = 'LTS_{0}'";
					cmd.CommandText = U.F(sql, tipoLTS);
					object r = cmd.ExecuteScalar();
					if (r == null)
						return;

					tableName = (string)r;
				}

				using (OracleCommand cmd = CreateCommand(cn))
				{
					string sql = "truncate table {0}";
					cmd.CommandText = U.F(sql, tableName);
					cmd.ExecuteNonQuery();
				}
			}
		}
	}

	class LTS_ImportIncrementaleA1 : DalBase
	{
		public void ImportIncrementaleA1(string UserPkId, Stream s, bool daImportMassivo, List<BLLTSImport.Nazione> nazioni, bool inviaMessaggiDeltaAiC2P)
		{
			// qui si fa la lettura del file XML e l'insert nel db
			using (OracleConnection cn = this.CreateConnection())
			{
				cn.Open();

				DateTime dtNow = DateTime.Now;	// questa ora viene inserita in DB per ogni record nel

				List<RecordCastello> rList = new List<RecordCastello>(); // lista delle targhe lette dal file
				ImportIncrementaleA1_LeggiFileEtInserisciOrCancellaNelDb(UserPkId, s, cn, dtNow, rList, nazioni);

				if (inviaMessaggiDeltaAiC2P)
				{
					// Notifico ai C2P i record cambiati....
					bool ignoraA2 = true;
					ImportIncrementaleA1_NotificaAiC2PnuoveTargheOrCancellazioneTarghe(cn, rList, daImportMassivo, ignoraA2);
				}
			}
		}
		public int CreaDifferenze(string UserPkId, string fileNameIn, string fileNameOut)
		{
			DateTime tsNow = DateTime.Now;

			int numeroDifferenzeTrovate = 0;

			int numeroDel = 0;

			RecordCastello[] newRecords;
			{
				Goletas.Collections.BalancedBinaryTree<RecordCastello> tree = new Goletas.Collections.BalancedBinaryTree<RecordCastello>();

				FileGenericReader fcr = FileGenericReader.CreateReader(BLLTSImport.TipoLTS.A1);

				FileCastelloReader.ConvertRecordDelegate<RecordCastello> recordBuilder = delegate(int lineaCorrente, string operazione, string targa, string naz, DateTime? scadenza, DateTime? data_segnalazione, string note, string tipoVeicolo)
				{
					RecordCastello rec = new RecordCastello();
					rec.Operazione = operazione;
					rec.Targa = targa;
					rec.Nazionalita = naz;
					rec.Scadenza = scadenza;
					rec.DataSegnalazione = data_segnalazione;
					rec.Note = note;
					rec.TipoVeicolo = tipoVeicolo;
					return rec;
				};

				int MassimoNumeroDiErroriPermessiNelFile = ReadAppSettings.ToInt32("ImportMassivo.MassimoNumeroDiErroriPermessiNelFile", 100);
				fcr.OnError += delegate(int lineaCorrente, string errorMsg)
				{
					if (fcr.ErrorsDetected < MassimoNumeroDiErroriPermessiNelFile)
						SafeLogger.LogWrite(UserPkId, errorMsg);
				};

				foreach (RecordCastello r in fcr.LeggiFile(fileNameIn, recordBuilder))
				{
					if (r.Operazione == "0") numeroDel += 1;

					if (r.Operazione == "1")
					{
						if (r.Scadenza.Value < tsNow)
							continue;
					}
					tree.Add(r);
				}

				if (fcr.ErrorsDetected > MassimoNumeroDiErroriPermessiNelFile)
				{
					string msgErr = string.Format("Il file contiene troppi errori di sintassi - errori={0} max={1}", fcr.ErrorsDetected, MassimoNumeroDiErroriPermessiNelFile);
					SafeLogger.LogWrite(UserPkId, msgErr);
					throw new ApplicationException(msgErr);
				}

				newRecords = new RecordCastello[tree.Count];
				tree.CopyTo(newRecords, 0);
			}


			U.GC_Collect();

			if (numeroDel > 0)
				throw new ApplicationException("Attenzione il file contiene cancellazioni NON supportate nell'import massivo");


			List<RecordCastello> oldRecords;

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"
SELECT 
Targa, 
Nazionalita,
'0' Operazione
FROM LTS 
WHERE 
EnumTipoLTS = :p 
order by Targa,Nazionalita";
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue(":p", "A1");

					oldRecords = RecordReader<RecordCastello>(cmd);
				}
			}
			U.GC_Collect();

			// ho caricato le 2 liste in memoria, quella dal file e quella nel DB

			using (FileCastelloWriter xw = new FileCastelloWriter(fileNameOut))
			{
				// ora devo confrontare 2 array
				int cNew = newRecords.Length;
				int cOld = oldRecords.Count;

				int iOld = 0;
				int iNew = 0;

				while (iOld < cOld && iNew < cNew)
				{
					RecordCastello recNew = newRecords[iNew];
					RecordCastello recOld = oldRecords[iOld];

					int r = recNew.CompareTo(recOld);
					if (r == 0)
					{
						++iNew;
						++iOld;
					}
					else if (r < 0)
					{
						// ins recNew
						recNew.Operazione = "1";
						xw.Add(recNew);

						++iNew;
					}
					else
					{
						// del recOld
						recOld.Operazione = "0";
						xw.Add(recOld);

						++iOld;
					}
				}

				// da cancellare i rimanenti in oldRecords
				while (iOld < cOld)
				{
					RecordCastello recOld = oldRecords[iOld];
					recOld.Operazione = "0";
					xw.Add(recOld);
					++iOld;
				}
				// da inserire i rimanenti in newRecords
				while (iNew < cNew)
				{
					RecordCastello recNew = newRecords[iNew];
					recNew.Operazione = "1";
					xw.Add(recNew);
					++iNew;
				}

				numeroDifferenzeTrovate = xw.NumeroRecordScritti;

				Log.Write("CreaDifferenze: trovate {0} differenze", xw.NumeroRecordScritti);
			}

			U.GC_Collect();

			return numeroDifferenzeTrovate;
		}
		private string GetLTSTable(string enumTipoLTS)
		{
			if (enumTipoLTS == null)
				return "LTS_BC"; // tanto quando andro` a fare la query in LTS_BC non lo trova.

			if (enumTipoLTS == "A1")
				return "LTS_A1";

			else if (enumTipoLTS == "A2")
				return "LTS_A2";

			return "LTS_BC";
		}

		#region Incrementale A1
		private void ImportIncrementaleA1_LeggiFileEtInserisciOrCancellaNelDb(string UserPkId, Stream ms, OracleConnection cn, DateTime dtNow, List<RecordCastello> rList, List<BLLTSImport.Nazione> nazList)
		{
			Dictionary<string, object> nazioni = new Dictionary<string, object>();
			foreach (BLLTSImport.Nazione nz in nazList)
				nazioni.Add(nz.Sigla_Nazione, null);

			int lineaCorrenteNelFile = -1;

			using (OracleTransaction tr = cn.BeginTransaction())
			{
				// leggo il file 
				int numeroRecordNelFile = 0;
				int numeroRecordElaborati = 0;
				DateTime DataOraInserimento = DateTime.Now;

				FileGenericReader fcr = FileGenericReader.CreateReader(BLLTSImport.TipoLTS.A1);

				FileCastelloReader.ConvertRecordDelegate<RecordCastello> recordBuilder = delegate(int lineaCorrente, string operazione, string targa, string naz, DateTime? scadenza, DateTime? data_segnalazione, string note, string tipoVeicolo)
				{
					lineaCorrenteNelFile = lineaCorrente;

					RecordCastello rec = new RecordCastello();
					rec.Operazione = operazione;
					rec.Targa = targa;
					rec.Nazionalita = naz;
					rec.Scadenza = scadenza;
					rec.DataSegnalazione = data_segnalazione;
					rec.Note = note;
					rec.TipoVeicolo = tipoVeicolo;
					return rec;
				};

				fcr.OnError += delegate(int lineaCorrente, string errorMsg)
				{
					SafeLogger.LogWrite(UserPkId, errorMsg);
				};

				foreach (RecordCastello R in fcr.LeggiFile<RecordCastello>(ms, recordBuilder))
				{
					numeroRecordNelFile++;

					if (!nazioni.ContainsKey(R.Nazionalita))
					{
						SafeLogger.LogWrite(UserPkId, "Import targhe: la nazione '{0}' non e` conosciuta dal sistema.", R.Nazionalita);
						continue;
					}

					rList.Add(R);

					if (R.Operazione == "1")
						ImportIncrementale_InserisciInDB_CastelloA1(UserPkId, R, cn);
					else
						ImportIncrementale_EliminaDalDB_CastelloA1(R, cn);

					numeroRecordElaborati++;

					if (numeroRecordElaborati % 1000 == 0)
						SafeLogger.LogWrite(UserPkId, "ImportIncrementale: elaborati {0} record", numeroRecordElaborati);
				}

				SafeLogger.LogWrite(UserPkId, "Il file in ingresso contiene {0} record", fcr.NumeroRigheNelFile);
				if (fcr.ErrorsDetected > 0)
					SafeLogger.LogWrite(UserPkId, "Il file in ingresso contiene {0} errori", fcr.ErrorsDetected);
				SafeLogger.LogWrite(UserPkId, "Inseriti/cancellati {0} record nel DB", numeroRecordElaborati);

				tr.Commit();
			}
		}
		private void ImportIncrementale_InserisciInDB_CastelloA1(string UserPkId, RecordCastello R, OracleConnection cn)
		{
			decimal count;
			using (OracleCommand cmd = this.CreateCommand(cn))
			{
				cmd.CommandText = "SELECT count(*) FROM LTS WHERE TARGA = :p_Targa AND NAZIONALITA = :p_Nazionalita AND ENUMTIPOLTS = :p_EnumTipoLts";
				cmd.CommandType = CommandType.Text;

				cmd.AddWithValue(":p_Targa", R.Targa);
				cmd.AddWithValue(":p_Nazionalita", R.Nazionalita);
				cmd.AddWithValue(":p_EnumTipoLts", "A1");

				count = cmd.ExecuteScalar<decimal>();
			}

			if (count == 0)
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"
insert into {0} 
(TARGA,NAZIONALITA,IDLTS,ENUMTIPOLTS,
ENUMLIVELLOPRIORITA,IDUTENTERICHIEDENTE,
MOTIVO,NOTE,DATAORAINSERIMENTO,DATAORAINIZIOVALIDITA,
DATAORAFINEVALIDITA,ENUMTIPODEST,ADDRDEST,

tab_telaio, 
tab_data_furto, 
tab_fabbrica, 
tab_modello, 
tab_tipo_veicolo, 
tab_tipo_denuncia, 
tab_codice_ufficio, 
tab_ufficio 

)
Values
(
:p_Targa, :p_Nazionalita, SEQ_LTS.nextval, :p_EnumTipoLts, 
:p_EnumLivelloPriorita, :p_IdUtenteRichiedente,
:p_Motivo,:p_Note,:p_DataOraInserimento,:p_DataOraInizioValidita,
:p_DataOraFineValidita,:p_EnumTipoDest,:p_AddressDest ,

:p_tab_telaio, 
:p_tab_data_furto, 
:p_tab_fabbrica, 
:p_tab_modello, 
:p_tab_tipo_veicolo, 
:p_tab_tipo_denuncia, 
:p_tab_codice_ufficio, 
:p_tab_ufficio 
)";

					cmd.CommandType = CommandType.Text;
					cmd.CommandText = string.Format(q, GetLTSTable("A1"));


					cmd.AddWithValue(":p_Targa", R.Targa);
					cmd.AddWithValue(":p_Nazionalita", R.Nazionalita);
					cmd.AddWithValue(":p_EnumTipoLts", "A1");
					cmd.AddWithValue(":p_EnumLivelloPriorita", "NORM");
					cmd.AddWithValue(":p_IdUtenteRichiedente", UserPkId);
					cmd.AddWithValue(":p_Motivo", "");
					cmd.AddWithValue(":p_Note", R.Note);
					cmd.AddWithValue(":p_DataOraInserimento", DateTime.Now);
					cmd.AddWithValue(":p_DataOraInizioValidita", R.DataSegnalazione);
					cmd.AddWithValue(":p_DataOraFineValidita", R.Scadenza);
					cmd.AddWithValue(":p_EnumTipoDest", "none");
					cmd.AddWithValue(":p_AddressDest", "");
					cmd.AddWithValue(":p_tab_telaio", "");
					cmd.AddWithValue(":p_tab_data_furto", "");
					cmd.AddWithValue(":p_tab_fabbrica", "");
					cmd.AddWithValue(":p_tab_modello", "");
					cmd.AddWithValue(":p_tab_tipo_veicolo", R.TipoVeicolo);
					cmd.AddWithValue(":p_tab_tipo_denuncia", "");
					cmd.AddWithValue(":p_tab_codice_ufficio", "");
					cmd.AddWithValue(":p_tab_ufficio", "");

					cmd.ExecuteNonQuery();
				}
			}
			else
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{

					string q = @"
update {0} 
set
ENUMLIVELLOPRIORITA   = :p_EnumLivelloPriorita,
IDUTENTERICHIEDENTE   = :p_IdUtenteRichiedente,
MOTIVO                = :p_Motivo,
NOTE                  = :p_Note,
DATAORAINSERIMENTO    = :p_DataOraInserimento,
DATAORAINIZIOVALIDITA = :p_DataOraInizioValidita,
DATAORAFINEVALIDITA   = :p_DataOraFineValidita,
ENUMTIPODEST          = :p_EnumTipoDest,
ADDRDEST              = :p_AddressDest,

tab_telaio            = :p_tab_telaio, 
tab_data_furto        = :p_tab_data_furto, 
tab_fabbrica          = :p_tab_fabbrica, 
tab_modello           = :p_tab_modello,  
tab_tipo_veicolo      = :p_tab_tipo_veicolo, 
tab_tipo_denuncia     = :p_tab_tipo_denuncia, 
tab_codice_ufficio    = :p_tab_codice_ufficio, 
tab_ufficio           = :p_tab_ufficio

where 
    targa       = :p_Targa 
and nazionalita = :p_Nazionalita 
and EnumTipoLts = :p_EnumTipoLts
";
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = string.Format(q, GetLTSTable("A1"));


					cmd.AddWithValue(":p_EnumLivelloPriorita", "NORM");
					cmd.AddWithValue(":p_IdUtenteRichiedente", UserPkId);
					cmd.AddWithValue(":p_Motivo", "");
					cmd.AddWithValue(":p_Note", R.Note);
					cmd.AddWithValue(":p_DataOraInserimento", DateTime.Now);
					cmd.AddWithValue(":p_DataOraInizioValidita", R.DataSegnalazione);
					cmd.AddWithValue(":p_DataOraFineValidita", R.Scadenza);
					cmd.AddWithValue(":p_EnumTipoDest", "none");
					cmd.AddWithValue(":p_AddressDest", "");


					cmd.AddWithValue(":p_tab_telaio", "");
					cmd.AddWithValue(":p_tab_data_furto", "");

					cmd.AddWithValue(":p_tab_fabbrica", "");
					cmd.AddWithValue(":p_tab_modello", "");
					cmd.AddWithValue(":p_tab_tipo_veicolo", R.TipoVeicolo);
					cmd.AddWithValue(":p_tab_tipo_denuncia", "");
					cmd.AddWithValue(":p_tab_codice_ufficio", "");
					cmd.AddWithValue(":p_tab_ufficio", "");

					cmd.AddWithValue(":p_Targa", R.Targa);
					cmd.AddWithValue(":p_Nazionalita", R.Nazionalita);
					cmd.AddWithValue(":p_EnumTipoLts", "A1");

					cmd.ExecuteNonQuery();
				}
			}
		}
		private int ImportIncrementale_EliminaDalDB_CastelloA1(RecordCastello R, OracleConnection cn)
		{
			using (OracleCommand cmd = this.CreateCommand(cn))
			{
				string q = "DELETE FROM {0} WHERE TARGA = :p_Targa AND NAZIONALITA = :p_Nazionalita AND  ENUMTIPOLTS = :p_EnumTipoLts";

				cmd.CommandText = string.Format(q, GetLTSTable("A1"));
				cmd.CommandType = CommandType.Text;

				cmd.AddWithValue(":p_Targa", R.Targa);
				cmd.AddWithValue(":p_Nazionalita", R.Nazionalita);
				cmd.AddWithValue(":p_EnumTipoLts", "A1");

				return cmd.ExecuteNonQuery();
			}
		}
		private void ImportIncrementaleA1_NotificaAiC2PnuoveTargheOrCancellazioneTarghe(OracleConnection cn, List<RecordCastello> rList, bool daImportMassivo, bool ignoraA2)
		{
			DateTime tsNow = DateTime.Now;

			IDalLTS dalLTS = DalProvider.DAL.CreateDalLTS();
			List<string> c2p = dalLTS.GetListaQmgr();

			using (ITRS_BL.MWPServices.MWPInterface.ManageAllarmeList all = new ITRS_BL.MWPServices.MWPInterface.ManageAllarmeList(c2p))
			{
				foreach (RecordCastello R in rList)
				{
					decimal count = 0;
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						string q = "SELECT count(*) FROM  LTS WHERE TARGA = :p_Targa AND NAZIONALITA = :p_Nazionalita";
						if (ignoraA2)
							cmd.CommandText = U.F(q, "and EnumTipoLTS <> 'A2' ");
						else
							cmd.CommandText = U.F(q, "");

						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue(":p_Targa", R.Targa);
						cmd.AddWithValue(":p_Nazionalita", R.Nazionalita);

						count = cmd.ExecuteScalar<decimal>();
					}

					Debug.Assert(R.Operazione == "0" || R.Operazione == "1");


					if (count == 0 && R.Operazione == "0")
					{
						// non esiste piu` la targa in tutta la LTS
						// notifico ai C2P di non generare piu` allarmi per questa targa/nazionalita
						all.Add(R.Targa, R.Nazionalita, new DateTime(), new DateTime(), false);

					}
					else if (count == 1 && R.Operazione == "1")
					{
						// ho inserito il primo record nella LTS 
						// notifico ai C2P di generare allarmi per questa nuova targa/nazionalita
						if (daImportMassivo == false)
							all.Add(R.Targa, R.Nazionalita, R.DataSegnalazione.Value, R.Scadenza.Value, true);
						else
							all.Add(R.Targa, R.Nazionalita, tsNow, R.Scadenza.Value, true);
					}
				}
			}
		}
		#endregion
	}


	public class OracleLock : DalBase, IDalLock
	{
		bool _locked;
		IEnumerator<bool> _en;

		public OracleLock(string lockId)
		{
			_locked = false;
			_en = GetLock(lockId).GetEnumerator();

			if (_en.MoveNext())
				_locked = _en.Current;
		}

		public bool IsLockAcquired
		{
			get { return _locked; }
		}

		public void Dispose()
		{
			if (_en != null)
			{
				// in realta non serve scorrere tutta la collezione, e` solo x poter fare debug.
				bool b = _en.MoveNext(); // controllo che effettivamente si sia alla fine della collezione
				Debug.Assert(b == false);

				_en.Dispose(); // qui si liberano la cmd/tr/cn
				_en = null;
			}
		}

		private IEnumerable<bool> GetLock(string lockId)
		{
			bool locked = false;
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = "select parvalue from parametri where partipo = :p_tipo for update nowait";
						cmd.AddWithValue("p_tipo", lockId);

						try
						{
							object r = cmd.ExecuteScalar();
							if (r == null)
							{
								// non c'e` il record - lo metto e acquisisco il lock.
								cmd.CommandText = "INSERT INTO ITRS.PARAMETRI(PARTIPO, PARVALUE) VALUES(:p_tipo, 1)";
								cmd.ExecuteNonQuery();
							}

							locked = true;
						}
						catch (OracleException oex)
						{
							locked = false;

							if (oex.Number == 54)
							{
								// busy and nowait --> la risorsa e` lockata
							}
						}

						// qui ritorno l'eventuale lock/nolock 
						yield return locked;
					}

					tr.Rollback();
				}
			}
		}

	}

}
