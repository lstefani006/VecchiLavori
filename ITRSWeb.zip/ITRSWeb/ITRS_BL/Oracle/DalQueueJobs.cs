using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

using System.Data.Common;


using ITRS_BL.IDal;
using ITRS_BL.Utility;

namespace ITRS_BL.Oracle
{
	class DalQueueJobs : DalBase, IDalQueueJobs
	{
		public string GetUserPkId(string userName)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "select PKID from ASPNET_USERS where USERNAME = :u";
					cmd.AddWithValue(":u", userName);
					cmd.CommandType = CommandType.Text;

					cmd.Connection.Open();
					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						while (rd.Read())
						{
							object ret = rd[0];
							return (string)ret;
						}
					}
				}
			}
			Log.Write("DalQueueJobs.GetUserPkId - non trovo USERNAME nella tb ASPNET_USERS");
			throw new ApplicationException("DalQueueJobs.GetUserPkId - non trovo USERNAME nella tb ASPNET_USERS");
		}

		//public void Create(string jobId, string jobType, string jobArgs, string jobPkIdUser)
		//{
		//    using (OracleConnection cn = base.CreateConnection())
		//    {
		//        using (OracleCommand cmd = this.CreateCommand(cn))
		//        {
		//            cmd.CommandText = "ITRS.ITRS_QJ.QJ_CREATE";
		//            cmd.CommandType = CommandType.StoredProcedure;

		//            AddWithValue(cmd, "P_QJID", jobId);
		//            AddWithValue(cmd, "P_QJTYPE", jobType);
		//            AddWithValue(cmd, "P_QJARGS", jobArgs);
		//            AddWithValue(cmd, "P_QJPKIDUSER", jobPkIdUser);

		//            cmd.Connection.Open();
		//            cmd.ExecuteNonQuery();
		//        }
		//    }
		//}
		public bool CreateEx(string jobId, string jobType, string jobArgs, string jobPkIdUser)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = "ITRS.ITRS_QJ.QJ_CREATEEX";
						cmd.CommandType = CommandType.StoredProcedure;

						cmd.AddWithValue("P_QJID", jobId);
						cmd.AddWithValue("P_QJTYPE", jobType);
						cmd.AddWithValue("P_QJARGS", jobArgs);
						cmd.AddWithValue("P_QJPKIDUSER", jobPkIdUser);

						OracleParameter p_JobAccepted = cmd.AddInt32OutParameter("p_JobAccepted");
						cmd.ExecuteNonQuery();

						tr.Commit();

						return ((int)p_JobAccepted.Value) == 0 ? false : true;
					}
				}
			}
		}

		public string GetNetTypeFromJobType(string jobType)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "select QJNETTYPE from QJOBTYPES where QJTYPE = :t";
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue("t", jobType);

					cmd.Connection.Open();
					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						while (rd.Read())
						{
							return rd.GetString(0);
						}
					}

					throw new ApplicationException("Record not found on table QJOBTYPES tipo QJTYPE " + jobType);
				}
			}
		}



		public void Abort(string jobId)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = "ITRS.ITRS_QJ.QJ_ABORT";
						cmd.CommandType = CommandType.StoredProcedure;

						cmd.AddWithValue("P_QJID", jobId);

						cmd.ExecuteNonQuery();

						tr.Commit();
					}
				}
			}
		}

		public void Access(string jobId)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "ITRS.ITRS_QJ.QJ_Access";
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.AddWithValue("P_QJID", jobId);

					cmd.Connection.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Suspend(string jobId)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "ITRS.ITRS_QJ.QJ_SUSPEND";
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.AddWithValue("P_QJID", jobId);

					cmd.Connection.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Resume(string jobId)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "ITRS.ITRS_QJ.QJ_RESUME";
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.AddWithValue("P_QJID", jobId);

					cmd.Connection.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Error(string jobId, string jobErrorMsg)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "ITRS.ITRS_QJ.QJ_ERROR";
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.AddWithValue("P_QJID", jobId);
					cmd.AddWithValue("P_QJERRMSG", jobErrorMsg);

					cmd.Connection.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}


		public void Progress(string jobId, string jobStatus, string jobProgrMsg, int? jobTotalSteps, int? jobCurrentStep, int? jobResRecordCount)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "ITRS.ITRS_QJ.QJ_PROGRESS";
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.AddWithValue("P_QJID", jobId);
					cmd.AddWithValue("P_QJSTATUS", jobStatus);
					cmd.AddWithValue("P_QJPROGRMSG", jobProgrMsg);
					cmd.AddWithValue("P_QJTOTALSTEPS", jobTotalSteps);
					cmd.AddWithValue("P_QJCURRENTSTEP", jobCurrentStep);
					cmd.AddWithValue("P_QJRESRECORDCOUNT", jobResRecordCount);

					cmd.Connection.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void End(string jobId)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "ITRS.ITRS_QJ.QJ_END";
					cmd.CommandType = CommandType.StoredProcedure;

					cmd.AddWithValue("P_QJID", jobId);

					cmd.Connection.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Purge()
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = "ITRS.ITRS_QJ.QJ_PURGE";
						cmd.CommandType = CommandType.StoredProcedure;

						cmd.ExecuteNonQuery();

						tr.Commit();
					}
				}
			}
		}


		public void Canc(string jobId, string jobType, string jobPkIdUser, BLQueueJobs.JobStatus? jobStatus)
		{
			using (OracleConnection cn = base.CreateConnection())
			{
				cn.Open();

				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = "ITRS.ITRS_QJ.QJ_CANC";
						cmd.CommandType = CommandType.StoredProcedure;

						cmd.AddWithValue("p_QJID", jobId);
						cmd.AddWithValue("p_QJTYPE", jobType);
						cmd.AddWithValue("p_QJPKIDUSER", jobPkIdUser);

						if (jobStatus.HasValue)
							cmd.AddWithValue("p_QJSTATUS", jobPkIdUser.ToString());
						else
							cmd.AddWithValue("p_QJSTATUS", (string)null);

						cmd.ExecuteNonQuery();

						tr.Commit();
					}
				}
			}
		}


		public void GetNextToRun(out string jobId, out string jobArgs, out string jobType)
		{
			jobId = null;
			jobArgs = null;
			jobType = null;

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = "ITRS.ITRS_QJ.QJ_GETNEXTTORUN";
					cmd.CommandType = CommandType.StoredProcedure;

					OracleParameter p_QJID = cmd.AddStringOutParameter("P_QJID", 32);
					OracleParameter p_QJARGS = cmd.AddStringOutParameter("P_QJARGS", 1024);
					OracleParameter p_QJTYPE = cmd.AddStringOutParameter("P_QJTYPE", 10);

					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						cmd.ExecuteNonQuery();

						if (p_QJARGS.Value != DBNull.Value)
						{
							jobId = (string)p_QJID.Value;
							jobArgs = (string)p_QJARGS.Value;
							jobType = (string)p_QJTYPE.Value;
						}

						tr.Commit();
					}
				}
			}
		}



		public List<QueueJob> GetRunningJobs(string sortColumns)
		{
			try
			{
				// e` roba del tip <a>[, <b>] con <a> = xyz [Desc]
				switch (sortColumns)
				{
				case "QJUser":
					sortColumns = "QJUser, QJTsQueue";
					break;

				case "QJUser DESC":
					sortColumns = "QJUser DESC, QJTsQueue ASC";
					break;

				case "QJPriority":
					sortColumns = "QJPriority, QJTsQueue";
					break;

				case "QJPriority DESC":
					sortColumns = "QJPriority DESC, QJTsQueue ASC";
					break;

				case "QJErrMsg":
					sortColumns = "QJUser, QJTsQueue";
					break;

				case "QJErrMsg DESC ":
					sortColumns = "QJErrMsg DESC, QJTSQueue";
					break;

				}

				string q =
				@"
					SELECT 
					QJID        as id, 
					QJTYPE      as type, 
					QJPRIORITY  as Priority, 
					QJARGS      as Args,
					QJPKIDUSER  as PkIdUser, 
					QJSTATUS    as Status, 
					QJTSQUEUE   as TsQueue, 
					QJTSRUN     as TsRun, 
					QJTSLAST    as TsLast, 
					QJERRMSG    as ErrorMessage, 
					QJPROGRMSG  as ProgressMessage, 
					QJTOTALSTEPS      as TotalSteps, 
					QJCURRENTSTEP     as CurrentStep,
					QJRESRECORDCOUNT  as ResRecordCount
					FROM ITRS.QJOBS
					order by " + sortColumns;

				using (OracleConnection cn = this.CreateConnection())
				{

					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						return RecordReader<QueueJob>(cmd);
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetRunningJobs", ex);
			}
		}


		public QueueJob GetRunningJobData(string jobId)
		{
			try
			{
				string q =
				@"	SELECT 
					QJID          Id, 
					QJTYPE        Type, 
					QJPRIORITY    Priority, 
					QJARGS        Args,
					QJPKIDUSER    PkIdUser, 
					QJSTATUS      Status, 
					QJTSQUEUE     TsQueue, 
					QJTSRUN       TsRun, 
					QJTSLAST      TsLast, 
					QJERRMSG      ErrorMessage, 
					QJPROGRMSG    ProgressMessage, 
					QJTOTALSTEPS  TotalSteps, 
					QJCURRENTSTEP CurrentStep,
					QJRESRECORDCOUNT ResRecordCount
					FROM ITRS.QJOBS
					where QJID = :P_QJID";

				using (OracleConnection cn = this.CreateConnection())
				{

					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue("P_QJID", jobId);

						List<QueueJob> r = RecordReader<QueueJob>(cmd);
						if (r.Count == 0)
							return null;
						return r[0];

						//int colQJID = -1;
						//int colQJTYPE = -1;
						//int colQJPRIORITY = -1;
						//int colQJARGS = -1;
						//int colQJPKIDUSER = -1;
						//int colQJSTATUS = -1;
						//int colQJTSQUEUE = -1;
						//int colQJTSRUN = -1;
						//int colQJTSLAST = -1;
						//int colQJERRMSG = -1;
						//int colQJPROGRMSG = -1;
						//int colQJTOTALSTEPS = -1;
						//int colQJCURRENTSTEP = -1;
						//int colQJRESRECORDCOUNT = -1;


						//RecordColumnBinder<QueueJob> rcb = delegate(OracleDataReader rd)
						//{
						//    colQJID = rd.GetOrdinal("QJID");
						//    colQJTYPE = rd.GetOrdinal("QJTYPE");
						//    colQJPRIORITY = rd.GetOrdinal("QJPRIORITY");
						//    colQJARGS = rd.GetOrdinal("QJARGS");
						//    colQJPKIDUSER = rd.GetOrdinal("QJPKIDUSER");
						//    colQJSTATUS = rd.GetOrdinal("QJSTATUS");
						//    colQJTSQUEUE = rd.GetOrdinal("QJTSQUEUE");
						//    colQJTSRUN = rd.GetOrdinal("QJTSRUN");
						//    colQJTSLAST = rd.GetOrdinal("QJTSLAST");
						//    colQJERRMSG = rd.GetOrdinal("QJERRMSG");
						//    colQJPROGRMSG = rd.GetOrdinal("QJPROGRMSG");
						//    colQJTOTALSTEPS = rd.GetOrdinal("QJTOTALSTEPS");
						//    colQJCURRENTSTEP = rd.GetOrdinal("QJCURRENTSTEP");
						//    colQJRESRECORDCOUNT = rd.GetOrdinal("QJRESRECORDCOUNT");
						//};

						//RecordBinder<QueueJob> rt = delegate(OracleDataReader rd, QueueJob t)
						//{
						//    t.Id = rd.GetString(colQJID);
						//    t.Type = rd.GetString(colQJTYPE);
						//    t.Priority = rd.GetString(colQJPRIORITY);
						//    t.Args = rd.GetString(colQJARGS);
						//    t.PkIdUser = rd.GetString(colQJPKIDUSER);
						//    t.Status = (BLQueueJobs.JobStatus)Enum.Parse(typeof(BLQueueJobs.JobStatus), rd.GetString(colQJSTATUS));
						//    t.TsQueue = rd.GetDateTime(colQJTSQUEUE);

						//    if (!rd.IsDBNull(colQJTSRUN))
						//        t.TsRun = rd.GetDateTime(colQJTSRUN);
						//    else
						//        t.TsRun = null;

						//    if (!rd.IsDBNull(colQJTSLAST))
						//        t.TsLast = rd.GetDateTime(colQJTSLAST);
						//    else
						//        t.TsLast = null;

						//    if (!rd.IsDBNull(colQJERRMSG))
						//        t.ErrorMessage = rd.GetString(colQJERRMSG);
						//    else
						//        t.ErrorMessage = "";

						//    if (!rd.IsDBNull(colQJPROGRMSG))
						//        t.ProgressMessage = rd.GetString(colQJPROGRMSG);
						//    else
						//        t.ProgressMessage = "";

						//    if (!rd.IsDBNull(colQJTOTALSTEPS))
						//        t.TotalSteps = rd.GetInt32(colQJTOTALSTEPS);
						//    else
						//        t.TotalSteps = null;

						//    if (!rd.IsDBNull(colQJCURRENTSTEP))
						//        t.CurrentStep = rd.GetInt32(colQJCURRENTSTEP);
						//    else
						//        t.CurrentStep = null;

						//    if (!rd.IsDBNull(colQJRESRECORDCOUNT))
						//        t.ResRecordCount = (int)rd.GetDecimal(colQJRESRECORDCOUNT);
						//    else
						//        t.ResRecordCount = null;
						//};

						//List<QueueJob> r = RecordReader<QueueJob>(cmd, rt, rcb);
						//if (r.Count == 0)
						//    return null;
						//return r[0];
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetRunningJobs", ex);
			}
		}

		public int? GetResRecordCount(string jobId)
		{
			try
			{
				string q = @"SELECT QJRESRECORDCOUNT FROM QJOBS WHERE QJID = :t";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue(":t", jobId);

						cn.Open();
						object r = cmd.ExecuteScalar();
						if (r == null || r == DBNull.Value)
							return (int?)null;

						return (int)(decimal)r;
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetResRecordCount", ex);
			}
		}


		public string GetStatus(string jobId)
		{
			try
			{
				string q = @"SELECT QJSTATUS FROM QJOBS WHERE QJID = :t";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandTimeout = 10;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue(":t", jobId);

						string ret = cmd.ExecuteScalar<string>();
						return ret;
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetStatus", ex);
			}
		}

		public List<QueueJob> GetCancJobs()
		{
			try
			{
				string q = @"SELECT QJID id, QJTYPE type FROM QJOBS WHERE QJSTATUS = 'CANC'";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						return RecordReader<QueueJob>(cmd);
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetCancJobs", ex);
			}
		}


		public List<QueueJobType> GetJobTypes()
		{
			try
			{
				string q = @"select QJTYPE,QJMAXRUNNING,QJPRIORITY,QJDESCR,QJRUNTIMEOUTSEC,QJQUEUETIMEOUTSEC,QJRESTIMEOUTSEC from ITRS.QJOBTYPES";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						return RecordReader<QueueJobType>(cmd);
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetJobTypes", ex);
			}
		}

		public void SaveJobTypes(QueueJobType qt)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();
					SaveJobType(cn, qt);
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetJobTypes", ex);
			}
		}

		public void SaveJobTypes(List<QueueJobType> qtList)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();

					using (OracleTransaction tr = cn.BeginTransaction())
					{
						foreach (QueueJobType qt in qtList)
							SaveJobType(cn, qt);

						tr.Commit();
					} // se fa eccezione il Dispose fa Rollback di ufficio
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetJobTypes", ex);
			}
		}

		private void SaveJobType(OracleConnection cn, QueueJobType qt)
		{
			string q = @"
UPDATE ITRS.QJOBTYPES 
SET 
QJMAXRUNNING      = :maxrunning, 
QJPRIORITY        = :priority, 
QJDESCR           = :descr, 
QJRUNTIMEOUTSEC   = :runtimeoutsec, 
QJQUEUETIMEOUTSEC = :queuetimeoutsec, 
QJRESTIMEOUTSEC   = :restimeoutsec
WHERE 
QJTYPE = :type
";
			using (OracleCommand cmd = this.CreateCommand(cn))
			{
				cmd.CommandText = q;
				cmd.CommandType = CommandType.Text;

				// in oracle le tr non sono assegnabili cmd.Transaction = tr;

				cmd.AddWithValue(":maxrunning", qt.QJMAXRUNNING);
				cmd.AddWithValue(":priority", qt.QJPRIORITY);
				cmd.AddWithValue(":descr", qt.QJDESCR);
				cmd.AddWithValue(":runtimeoutsec", qt.QJRUNTIMEOUTSEC);
				cmd.AddWithValue(":queuetimeoutsec", qt.QJQUEUETIMEOUTSEC);
				cmd.AddWithValue(":restimeoutsec", qt.QJRESTIMEOUTSEC);

				cmd.AddWithValue(":type", qt.QJTYPE);

				cmd.ExecuteNonQuery();
			}
		}

	}
}
