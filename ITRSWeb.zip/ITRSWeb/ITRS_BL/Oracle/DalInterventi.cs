using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

namespace ITRS_BL.Oracle
{
	public class DalInterventi : DalBase, IDalInterventi
	{
		public string Create(string jobId, string jobType, string jobArgs, string jobPkIdUser, string targa, string nazionalita, string Note, string Motivo, int IdCoa)
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					OracleTransaction tr = null;
					try
					{
						cn.Open();
						tr = cn.BeginTransaction();

						using (OracleCommand cmd = CreateCommand(cn))
						{
							cmd.CommandType = CommandType.StoredProcedure;
							cmd.CommandText = "ITRS.ITRS_INTERVENTO.CreateIntervento";

							cmd.AddWithValue("P_QJID", jobId);
							cmd.AddWithValue("P_QJTYPE", jobType);
							cmd.AddWithValue("P_QJARGS", jobArgs);
							cmd.AddWithValue("P_QJPKIDUSER", jobPkIdUser);
							cmd.AddWithValue("P_TARGA", targa);
							cmd.AddWithValue("P_NAZIONALITA", nazionalita);
							cmd.AddWithValue("P_MOTIVO", Motivo);
							cmd.AddWithValue("P_NOTE", Note);
							cmd.AddWithValue("P_IDCOA", IdCoa);

							OracleParameter p = cmd.AddStringOutParameter("p_QJOBIDOLD", 32);
							cmd.ExecuteNonQuery();
							tr.Commit();

							if (p.Value == DBNull.Value)
								return "";

							return (string)p.Value;
						}
					}
					catch
					{
						if (tr != null)
							tr.Rollback();
						throw;
					}
				}
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				throw;
			}
		}

		/// <summary>
		/// Procedura utilizzata dalla BL, nella fase Batch, per ricercare i transiti
		/// e memorizzare i risultati nella tabella QJOBSRES_INTERVENTI
		/// </summary>
		/// <param name="jobId"></param>
		/// <param name="jobArgs"></param>
		/// <returns></returns>
		public int QueryIntervento(string jobId, BL_Interventi.JobArgs jobArgs, ref bool primoTransitoLetto)
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.CommandText = "ITRS.ITRS_INTERVENTO.QUERYINTERVENTO";

						cmd.AddWithValue("P_QJID", jobId);
						cmd.AddWithValue("P_TARGA", jobArgs.Targa);
						cmd.AddWithValue("P_NAZIONALITA", jobArgs.Nazionalita);
						cmd.AddWithValue("P_DI", jobArgs.DataInizioRicerca);
						cmd.AddWithValue("P_DF", jobArgs.DataFineRicerca);
						OracleParameter pRows = cmd.AddInt64OutParameter("P_ROWS");

						string str = primoTransitoLetto ? "true" : "false";
						OracleParameter pLettoPrimoTransito = cmd.AddStringInOutParameter("p_PRIMO_TRANSITO", str, 5);
						cn.Open();
						cmd.ExecuteNonQuery();

						OracleString r = (OracleString)pLettoPrimoTransito.Value;
						primoTransitoLetto = r.Value == "true";

						object ret = pRows.Value;
						return (int)(long)ret;
					}
				}
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				throw;
			}
		}

		public List<ResultQueryIntervento> GetResultJobIntervento(string jobId, string columnsSort, int startRowIndex, int maximumRows)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = @"
SELECT
QI.QJID,
QI.TARGA,
QI.NAZIONALITA,
QI.DATAORARILEVAMENTO,
QI.C2P_DESCRIZIONE,
QI.C2P_DIREZIONE,
QI.ENUMTIPOVARCO,
nvl(TR.ENUMSTATOTRANSITO,TREV.ENUMSTATOTRANSITO) ENUMSTATOTRANSITO,

-- QI.EVENTOASSOCIATOALTRANSITO,
nvl2(EVS.TARGA, 'S', 'N') EVENTOASSOCIATOALTRANSITO,
EVS.IDEVENTO,
EVS.DATAORAINSERIMENTO,
EVS.ENUMSTATOALLARME

FROM 
QJOBSRES_INTERVENTI QI

left outer join TRANSITI TR
on  TR.Targa = QI.TARGA
and TR.NAZIONALITA = QI.NAZIONALITA
and TR.DATAORARILEVAMENTO = QI.DATAORARILEVAMENTO

left outer join TRANSITIsuEvento TREV
on  TREV.Targa = QI.TARGA
and TREV.NAZIONALITA = QI.NAZIONALITA
and TREV.DATAORARILEVAMENTO = QI.DATAORARILEVAMENTO

LEFT outer join TransitiEventi TE
on  TE.Targa = QI.TARGA
and TE.NAZIONALITA = QI.NAZIONALITA
and TE.DATAORARILEVAMENTO = QI.DATAORARILEVAMENTO

LEFT outer join EventiDaSegnalare EVS
on  EVS.Targa = QI.TARGA
and EVS.NAZIONALITA = QI.NAZIONALITA
and EVS.IDEVENTO = TE.IDEVENTO
and EVS.DATAORAINSERIMENTO = TE.DATAORAINSERIMENTO
and EVS.EnumTipoEvento = 'TS'

WHERE 
QI.QJID = :P_QJID
";
					cmd.CommandText += " order by " + columnsSort;

					cmd.AddWithValue(":P_QJID", jobId);

					if (maximumRows > 0)
						this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					int colQJID = -1;
					int colTARGA = -1;
					int colNAZIONALITA = -1;
					int colDATAORARILEVAMENTO = -1;
					int colC2P_DESCRIZIONE = -1;
					int colC2P_DIREZIONE = -1;
					int colENUMTIPOVARCO = -1;
					int colENUMSTATOTRANSITO = -1;
					int colEVENTOASSOCIATOALTRANSITO = -1;

					int colIDEVENTO = -1;
					int colDATAORAINSERIMENTO = -1;
					int colENUMSTATOALLARME = -1;

					RecordColumnBinder<ResultQueryIntervento> rcb = delegate(OracleDataReader rd)
					{
						colQJID = rd.GetOrdinal("QJID");
						colTARGA = rd.GetOrdinal("TARGA");
						colNAZIONALITA = rd.GetOrdinal("NAZIONALITA");
						colDATAORARILEVAMENTO = rd.GetOrdinal("DATAORARILEVAMENTO");
						colC2P_DESCRIZIONE = rd.GetOrdinal("C2P_DESCRIZIONE");
						colC2P_DIREZIONE = rd.GetOrdinal("C2P_DIREZIONE");
						colENUMTIPOVARCO = rd.GetOrdinal("ENUMTIPOVARCO");
						colENUMSTATOTRANSITO = rd.GetOrdinal("ENUMSTATOTRANSITO");
						colEVENTOASSOCIATOALTRANSITO = rd.GetOrdinal("EVENTOASSOCIATOALTRANSITO");

						colIDEVENTO = rd.GetOrdinal("IDEVENTO");
						colDATAORAINSERIMENTO = rd.GetOrdinal("DATAORAINSERIMENTO");
						colENUMSTATOALLARME = rd.GetOrdinal("ENUMSTATOALLARME");
					};

					RecordBinder<ResultQueryIntervento> rt = delegate(OracleDataReader rd, ResultQueryIntervento t)
					{
						t.JobId = rd.GetString(colQJID);
						t.Targa = rd.GetString(colTARGA);
						t.Nazionalita = rd.GetString(colNAZIONALITA);
						t.DataOraRilevamento = rd.GetDateTime(colDATAORARILEVAMENTO);
						t.C2pDescrizione = rd.GetString(colC2P_DESCRIZIONE);
						t.Direzione = (Direzione)Enum.Parse(typeof(Direzione), rd.GetString(colC2P_DIREZIONE));
						t.TipoVarco = (TipoVarco)Enum.Parse(typeof(TipoVarco), rd.GetString(colENUMTIPOVARCO));
						t.StatoTransito = (StatoTransito)Enum.Parse(typeof(StatoTransito), rd.GetString(colENUMSTATOTRANSITO));
						t.EventoAssociatoAlTransito = rd.GetString(colEVENTOASSOCIATOALTRANSITO) == "S";

						if (rd.IsDBNull(colIDEVENTO))
							t.IdEvento = null;
						else
							t.IdEvento = (int)(long)rd[colIDEVENTO];

						if (rd.IsDBNull(colDATAORAINSERIMENTO))
							t.DataOraInserimento = null;
						else
							t.DataOraInserimento = (DateTime)rd[colDATAORAINSERIMENTO];

						if (rd.IsDBNull(colENUMSTATOALLARME))
							t.StatoAllarme = null;
						else
							t.StatoAllarme = (StatoAllarme)Enum.Parse(typeof(StatoAllarme), rd.GetString(colENUMSTATOALLARME));
					};


					cn.Open();
					return this.RecordReader<ResultQueryIntervento>(cmd, rt, rcb);
				}
			}
		}

		public List<MWPC2PInfo> DeleteIntervento(string jobId, out string targa, out string nazionalita)
		{
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.CommandText = "ITRS.ITRS_INTERVENTO.DeleteIntervento";

						cmd.AddWithValue("p_QJID", jobId);

						int colQmgrName = -1;
						int colDataOraRilevamento = -1;

						RecordColumnBinder<MWPC2PInfo> tColumnBinder = delegate(OracleDataReader rd)
						{
							colQmgrName = rd.GetOrdinal("QMGR_NAME");
							colDataOraRilevamento = rd.GetOrdinal("DATAORARILEVAMENTO");
						};

						RecordBinder<MWPC2PInfo> tReader = delegate(OracleDataReader rd, MWPC2PInfo t)
						{
							t.QmgrName = rd.GetString(colQmgrName);

							if (rd.IsDBNull(colDataOraRilevamento))
								t.DataOraRilevamento = null;
							else
								t.DataOraRilevamento = rd.GetDateTime(colDataOraRilevamento);
						};


						OracleParameter pTarga = cmd.AddStringOutParameter("p_TARGA", 10);
						OracleParameter pNazionalita = cmd.AddStringOutParameter("p_NAZIONALITA", 6);
						{
							List<MWPC2PInfo> ret = RecordReader<MWPC2PInfo>(cmd, "p_QMGR", tReader, tColumnBinder);
							targa = (string)pTarga.Value;
							nazionalita = (string)pNazionalita.Value;

							tr.Commit();

							return ret;
						}
					}
				}
			}
		}

		public List<ListaInterventiPerCoaRes> ListaInterventiPerCoa(int IdCoa)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "ITRS.ITRS_INTERVENTO.ListaInterventiPerCoa";
					cmd.AddWithValue("p_IdCoa", IdCoa);


					int colTarga = -1;
					int colNazionalita = -1;
					int colNote = -1;
					int colMotivo = -1;
					int colQjStatus = -1;

					RecordColumnBinder<ListaInterventiPerCoaRes> tColumnBinder = delegate(OracleDataReader rd)
					{
						colTarga = rd.GetOrdinal("Targa");
						colNazionalita = rd.GetOrdinal("Nazionalita");
						colNote = rd.GetOrdinal("Note");
						colMotivo = rd.GetOrdinal("Motivo");
						colQjStatus = rd.GetOrdinal("QjStatus");
					};


					RecordBinder<ListaInterventiPerCoaRes> tReader = delegate(OracleDataReader rd, ListaInterventiPerCoaRes t)
					{
						t.Targa = rd.GetString(colTarga);
						t.Nazionalita = rd.GetString(colNazionalita);

						if (!rd.IsDBNull(colNote))
							t.Note = rd.GetString(colNote);
						else
							t.Note = "";

						if (!rd.IsDBNull(colMotivo))
							t.Motivo = rd.GetString(colMotivo);
						else
							t.Motivo = "";

						t.QjStatus = (BLQueueJobs.JobStatus)Enum.Parse(typeof(BLQueueJobs.JobStatus), rd.GetString(colQjStatus));
					};

					List<ListaInterventiPerCoaRes> ret;
					ret = RecordReader<ListaInterventiPerCoaRes>(cmd, "p_Cur", tReader, tColumnBinder);
					return ret;
				}
			}
		}

		public InterventiQueueJob GetRunningJobData(string jobId)
		{
			try
			{
				string q =
				@"	
SELECT 
Q.QJID, 
Q.QJTYPE, 
Q.QJPRIORITY, 
Q.QJARGS,
Q.QJPKIDUSER, 
Q.QJSTATUS, 
Q.QJTSQUEUE, 
Q.QJTSRUN, 
Q.QJTSLAST, 
Q.QJERRMSG, 
Q.QJPROGRMSG, 
Q.QJTOTALSTEPS, 
Q.QJCURRENTSTEP,
Q.QJRESRECORDCOUNT,

QI.TARGA,
QI.NAZIONALITA,
QI.UT_DATAORARILEVAMENTO, 
QI.UT_C2P_DESCRIZIONE, 
QI.UT_C2P_DIREZIONE, 
QI.UT_ENUMTIPOVARCO, 

-- QI.UT_ENUMSTATOTRANSITO, 
nvl(TR.ENUMSTATOTRANSITO, TRSEV.ENUMSTATOTRANSITO) as UT_ENUMSTATOTRANSITO,

-- QI.UT_EVENTOASSOCIATOALTRANSITO,
nvl2(EVS.TARGA, 'S', 'N') UT_EVENTOASSOCIATOALTRANSITO,

-- QI.UT_IDEVENTO,
EVS.IDEVENTO as UT_IDEVENTO,

-- QI.UT_DATAORAINSERIMENTO,
EVS.DATAORAINSERIMENTO as UT_DATAORAINSERIMENTO,

-- QI.UT_ENUMSTATOALLARME,
EVS.ENUMSTATOALLARME as UT_ENUMSTATOALLARME,

U.USERNAME as QJUSERNAME

FROM ITRS.QJOBS Q

inner join QJOBS_INTERVENTI QI
on Q.QJID = QI.QJID

left outer join ITRS.ASPNET_USERS U
on U.PKID = Q.QJPKIDUSER

left outer join TRANSITI TR
on  TR.Targa = QI.TARGA
and TR.NAZIONALITA = QI.NAZIONALITA
and TR.DATAORARILEVAMENTO = QI.UT_DATAORARILEVAMENTO

left outer join TRANSITIsuEvento TRSEV
on  TRSEV.Targa = QI.TARGA
and TRSEV.NAZIONALITA = QI.NAZIONALITA
and TRSEV.DATAORARILEVAMENTO = QI.UT_DATAORARILEVAMENTO

LEFT outer join TransitiEventi TE
on  TE.Targa = QI.TARGA
and TE.NAZIONALITA = QI.NAZIONALITA
and TE.DATAORARILEVAMENTO = QI.UT_DATAORARILEVAMENTO

LEFT outer join EventiDaSegnalare EVS
on  EVS.Targa = TE.TARGA
and EVS.NAZIONALITA = TE.NAZIONALITA
and EVS.IDEVENTO = TE.IDEVENTO
and EVS.DATAORAINSERIMENTO = TE.DATAORAINSERIMENTO
and EVS.EnumTipoEvento = 'TS'

where Q.QJID = :P_QJID
";

				using (OracleConnection cn = this.CreateConnection())
				{

					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandTimeout = 10;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue("P_QJID", jobId);

						int colQJID = -1;
						int colQJTYPE = -1;
						int colQJPRIORITY = -1;
						int colQJARGS = -1;
						int colQJPKIDUSER = -1;
						int colQJSTATUS = -1;
						int colQJTSQUEUE = -1;
						int colQJTSRUN = -1;
						int colQJTSLAST = -1;
						int colQJERRMSG = -1;
						int colQJPROGRMSG = -1;
						int colQJTOTALSTEPS = -1;
						int colQJCURRENTSTEP = -1;
						int colQJRESRECORDCOUNT = -1;

						int colTARGA = -1;
						int colNAZIONALITA = -1;
						int colUT_DATAORARILEVAMENTO = -1;
						int colUT_C2P_DESCRIZIONE = -1;
						int colUT_C2P_DIREZIONE = -1;
						int colUT_ENUMTIPOVARCO = -1;
						int colUT_ENUMSTATOTRANSITO = -1;
						int colUT_EVENTOASSOCIATOALTRANSITO = -1;

						int colUT_IDEVENTO = -1;
						int colUT_DATAORAINSERIMENTO = -1;
						int colUT_ENUMSTATOALLARME = -1;


						int colQJUSERNAME = -1;


						RecordColumnBinder<InterventiQueueJob> rcb = delegate(OracleDataReader rd)
						{
							colQJID = rd.GetOrdinal("QJID");
							colQJTYPE = rd.GetOrdinal("QJTYPE");
							colQJPRIORITY = rd.GetOrdinal("QJPRIORITY");
							colQJARGS = rd.GetOrdinal("QJARGS");
							colQJPKIDUSER = rd.GetOrdinal("QJPKIDUSER");
							colQJSTATUS = rd.GetOrdinal("QJSTATUS");
							colQJTSQUEUE = rd.GetOrdinal("QJTSQUEUE");
							colQJTSRUN = rd.GetOrdinal("QJTSRUN");
							colQJTSLAST = rd.GetOrdinal("QJTSLAST");
							colQJERRMSG = rd.GetOrdinal("QJERRMSG");
							colQJPROGRMSG = rd.GetOrdinal("QJPROGRMSG");
							colQJTOTALSTEPS = rd.GetOrdinal("QJTOTALSTEPS");
							colQJCURRENTSTEP = rd.GetOrdinal("QJCURRENTSTEP");
							colQJRESRECORDCOUNT = rd.GetOrdinal("QJRESRECORDCOUNT");

							colTARGA = rd.GetOrdinal("TARGA");
							colNAZIONALITA = rd.GetOrdinal("NAZIONALITA");
							colUT_DATAORARILEVAMENTO = rd.GetOrdinal("UT_DATAORARILEVAMENTO");
							colUT_C2P_DESCRIZIONE = rd.GetOrdinal("UT_C2P_DESCRIZIONE");
							colUT_C2P_DIREZIONE = rd.GetOrdinal("UT_C2P_DIREZIONE");
							colUT_ENUMTIPOVARCO = rd.GetOrdinal("UT_ENUMTIPOVARCO");
							colUT_ENUMSTATOTRANSITO = rd.GetOrdinal("UT_ENUMSTATOTRANSITO");
							colUT_EVENTOASSOCIATOALTRANSITO = rd.GetOrdinal("UT_EVENTOASSOCIATOALTRANSITO");


							colUT_IDEVENTO = rd.GetOrdinal("UT_IDEVENTO");
							colUT_DATAORAINSERIMENTO = rd.GetOrdinal("UT_DATAORAINSERIMENTO");
							colUT_ENUMSTATOALLARME = rd.GetOrdinal("UT_ENUMSTATOALLARME");


							colQJUSERNAME = rd.GetOrdinal("QJUSERNAME");
						};

						RecordBinder<InterventiQueueJob> rt = delegate(OracleDataReader rd, InterventiQueueJob t)
						{
							t.Id = rd.GetString(colQJID);
							t.Type = rd.GetString(colQJTYPE);
							t.Priority = rd.GetString(colQJPRIORITY);
							t.Args = rd.GetString(colQJARGS);
							t.PkIdUser = rd.GetString(colQJPKIDUSER);
							t.Status = (BLQueueJobs.JobStatus)Enum.Parse(typeof(BLQueueJobs.JobStatus), rd.GetString(colQJSTATUS));

							t.TsQueue = rd.GetDateTime(colQJTSQUEUE);

							if (!rd.IsDBNull(colQJTSRUN))
								t.TsRun = rd.GetDateTime(colQJTSRUN);
							else
								t.TsRun = null;

							if (!rd.IsDBNull(colQJTSLAST))
								t.TsLast = rd.GetDateTime(colQJTSLAST);
							else
								t.TsLast = null;

							if (!rd.IsDBNull(colQJERRMSG))
								t.ErrorMessage = rd.GetString(colQJERRMSG);
							else
								t.ErrorMessage = "";

							if (!rd.IsDBNull(colQJPROGRMSG))
								t.ProgressMessage = rd.GetString(colQJPROGRMSG);
							else
								t.ProgressMessage = "";

							if (!rd.IsDBNull(colQJTOTALSTEPS))
								t.TotalSteps = rd.GetInt32(colQJTOTALSTEPS);
							else
								t.TotalSteps = null;

							if (!rd.IsDBNull(colQJCURRENTSTEP))
								t.CurrentStep = rd.GetInt32(colQJCURRENTSTEP);
							else
								t.CurrentStep = null;

							if (!rd.IsDBNull(colQJRESRECORDCOUNT))
								t.ResRecordCount = (int)rd.GetDecimal(colQJRESRECORDCOUNT);
							else
								t.ResRecordCount = null;

							t.Targa = rd.GetString(colTARGA);
							t.Nazionalita = rd.GetString(colNAZIONALITA);

							if (rd.IsDBNull(colUT_DATAORARILEVAMENTO))
								t.DataOraRilevamento = null;
							else
								t.DataOraRilevamento = rd.GetDateTime(colUT_DATAORARILEVAMENTO);

							if (rd.IsDBNull(colUT_C2P_DESCRIZIONE))
								t.Descrizione = null;
							else
								t.Descrizione = rd.GetString(colUT_C2P_DESCRIZIONE);

							if (rd.IsDBNull(colUT_C2P_DIREZIONE))
								t.Direzione = null;
							else
								t.Direzione = (Direzione)Enum.Parse(typeof(Direzione), rd.GetString(colUT_C2P_DIREZIONE));

							if (rd.IsDBNull(colUT_ENUMTIPOVARCO))
								t.TipoVarco = null;
							else
								t.TipoVarco = (TipoVarco)Enum.Parse(typeof(TipoVarco), rd.GetString(colUT_ENUMTIPOVARCO));

							if (rd.IsDBNull(colUT_ENUMSTATOTRANSITO))
								t.StatoTransito = null;
							else
								t.StatoTransito = (StatoTransito)Enum.Parse(typeof(StatoTransito), rd.GetString(colUT_ENUMSTATOTRANSITO));

							if (rd.IsDBNull(colUT_EVENTOASSOCIATOALTRANSITO))
								t.EventoAssociatoAlTransito = null;
							else
								t.EventoAssociatoAlTransito = rd.GetString(colUT_EVENTOASSOCIATOALTRANSITO) == "S";


							if (rd.IsDBNull(colUT_IDEVENTO))
								t.IdEvento = null;
							else
								t.IdEvento = (int)(long)rd[colUT_IDEVENTO];

							if (rd.IsDBNull(colUT_DATAORAINSERIMENTO))
								t.DataOraInserimento = null;
							else
								t.DataOraInserimento = rd.GetDateTime(colUT_DATAORAINSERIMENTO);

							if (rd.IsDBNull(colUT_ENUMSTATOALLARME))
								t.StatoAllarme = null;
							else
								t.StatoAllarme = (StatoAllarme)Enum.Parse(typeof(StatoAllarme), rd.GetString(colUT_ENUMSTATOALLARME));

							if (rd.IsDBNull(colQJUSERNAME))
								t.UserName = null;
							else
								t.UserName = rd.GetString(colQJUSERNAME);
						};

						List<InterventiQueueJob> r = RecordReader<InterventiQueueJob>(cmd, rt, rcb);
						if (r.Count == 0)
							return null;
						return r[0];
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetRunningJobs", ex);
			}
		}

		/// <summary>
		/// Ritorna la lista dei QmrName e data di ultimo aggiornamento
		/// </summary>
		/// <param name="targa"></param>
		/// <param name="nazionalita"></param>
		/// <returns></returns>
		public List<MWPC2PInfo> GetQmgrForMWP(string targa, string nazionalita, bool ignoraA2)
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					cn.Open();

					using (OracleCommand cmd = CreateCommand(cn))
					{
						string q = @"
SELECT
c2p.QMGR_NAME,
c2p.DATAORARILEVAMENTO
from C2P
where not exists
(
	select * from LTS
	where
	    LTS.TARGA       = :p_Targa 
	and	LTS.Nazionalita = :p_Nazionalita
	{0}
);
";

						if (ignoraA2)
							cmd.CommandText = U.F(q, "and LTS.EnumTipoLTS <> 'A2' ");
						else
							cmd.CommandText = U.F(q, "");

						cmd.AddWithValue("p_TARGA", targa);
						cmd.AddWithValue("p_NAZIONALITA", nazionalita);

						int colQmgrName = -1;
						int colDataOraRilevamento = -1;

						RecordColumnBinder<MWPC2PInfo> rcb = delegate(OracleDataReader rd)
						{
							colQmgrName = rd.GetOrdinal("QMGR_NAME");
							colDataOraRilevamento = rd.GetOrdinal("DATAORARILEVAMENTO");
						};

						RecordBinder<MWPC2PInfo> rt = delegate(OracleDataReader rd, MWPC2PInfo t)
						{
							t.QmgrName = rd.GetString(colQmgrName);

							if (rd.IsDBNull(colDataOraRilevamento))
								t.DataOraRilevamento = null;
							else
								t.DataOraRilevamento = rd.GetDateTime(colDataOraRilevamento);
						};

						List<MWPC2PInfo> ret = RecordReader<MWPC2PInfo>(cmd, "p_Qmgr", rt, rcb);
						return ret;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetQmgrForMWP");
				throw;
			}
		}

		public List<MWPC2PInfo> CancellaInterventoPerCoa(int idCoa, string targa, string nazionalita)
		{
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.CommandText = "ITRS.ITRS_INTERVENTO.CancellaInterventoPerCoa";

						cmd.AddWithValue("p_IdCoa", idCoa);
						cmd.AddWithValue("p_TARGA", targa);
						cmd.AddWithValue("p_NAZIONALITA", nazionalita);

						// cmd.ExecuteNonQuery();
						int colQmgrName = -1;
						int colDataOraRilevamento = -1;

						RecordColumnBinder<MWPC2PInfo> tColumnBinder = delegate(OracleDataReader rd)
						{
							colQmgrName = rd.GetOrdinal("QMGR_NAME");
							colDataOraRilevamento = rd.GetOrdinal("DATAORARILEVAMENTO");
						};

						RecordBinder<MWPC2PInfo> tReader = delegate(OracleDataReader rd, MWPC2PInfo t)
						{
							t.QmgrName = rd.GetString(colQmgrName);

							if (rd.IsDBNull(colDataOraRilevamento))
								t.DataOraRilevamento = null;
							else
								t.DataOraRilevamento = rd.GetDateTime(colDataOraRilevamento);
						};


						List<MWPC2PInfo> ret = RecordReader<MWPC2PInfo>(cmd, "p_QMGR", tReader, tColumnBinder);

						tr.Commit();

						return ret;
					}
				}
			}
		}
	}
}
