using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using Oracle.DataAccess.Client;
#endif

namespace ITRS_BL.Oracle
{
	class DalC2P : DalBase, IDalC2P
	{
		#region IDalC2P Members
		public List<C2P> GetLista(string columnsSort)
		{
			if (columnsSort == string.Empty)
				columnsSort = "DESCRIZIONE";

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"
SELECT 
C2P.QMGR_NAME, 
C2P.CODICESTRADA, 
C2P.KM, 
C2P.IDC2P, 
C2P.IDCOA, 
C2P.DESCRIZIONE, 
C2P.IDTRATTAPREC, 
C2P.IDTRATTASUCC, 
C2P.DIREZIONE, 
COA.DESCRIZIONE DESCRCOA, 
TPREC.DESCRIZIONE DESCRTRATTAPREC, 
TSUCC.DESCRIZIONE DESCRTRATTASUCC,
C2P.LAT,
C2P.LON
FROM C2P
INNER JOIN COA ON
COA.IDCOA = C2P.IDCOA
LEFT OUTER JOIN TRATTE TPREC ON
TPREC.IDTRATTA = IDTRATTAPREC
LEFT OUTER JOIN TRATTE TSUCC ON
TSUCC.IDTRATTA = IDTRATTASUCC
order by " + columnsSort;
					cmd.CommandType = CommandType.Text;

					int colQMGR_NAME = -1;
					int colCODICESTRADA = -1;
					int colKM = -1;
					int colIDC2P = -1;
					int colIDCOA = -1;
					int colDESCRCOA = -1;
					int colDESCRIZIONE = -1;
					int colIDTRATTAPREC = -1;
					int colIDTRATTASUCC = -1;
					int colDESCRTRATTAPREC = -1;
					int colDESCRTRATTASUCC = -1;
					int colDIREZIONE = -1;
					int colLAT = -1;
					int colLON = -1;

					RecordColumnBinder<C2P> rcb = delegate(OracleDataReader rd)
					{
						colQMGR_NAME = rd.GetOrdinal("QMGR_NAME");
						colCODICESTRADA = rd.GetOrdinal("CODICESTRADA");
						colKM = rd.GetOrdinal("KM");
						colIDC2P = rd.GetOrdinal("IDC2P");
						colIDCOA = rd.GetOrdinal("IDCOA");
						colDESCRCOA = rd.GetOrdinal("DESCRCOA");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colIDTRATTAPREC = rd.GetOrdinal("IDTRATTAPREC");
						colIDTRATTASUCC = rd.GetOrdinal("IDTRATTASUCC");
						colDESCRTRATTAPREC = rd.GetOrdinal("DESCRTRATTAPREC");
						colDESCRTRATTASUCC = rd.GetOrdinal("DESCRTRATTASUCC");
						colDIREZIONE = rd.GetOrdinal("DIREZIONE");
						colLAT = rd.GetOrdinal("LAT");
						colLON = rd.GetOrdinal("LON");
					};

					RecordBinder<C2P> rt = delegate(OracleDataReader rd, C2P t)
					{
						t.QmgrName = rd.GetString(colQMGR_NAME);
						t.CodiceStrada = rd.GetString(colCODICESTRADA);
						t.Km = rd.GetString(colKM);

						t.IdC2P = (int)rd.GetDouble(colIDC2P);
						t.IdCOA = (int)rd.GetDouble(colIDCOA);

						if (rd.IsDBNull(colDESCRCOA))
							t.DescrCOA = null;
						else
							t.DescrCOA = rd.GetString(colDESCRCOA);

						t.Descrizione = rd.GetString(colDESCRIZIONE);
						if (rd.IsDBNull(colIDTRATTAPREC))
							t.IdTrattaPrec = null;
						else
							t.IdTrattaPrec = (int)rd.GetDouble(colIDTRATTAPREC);
						if (rd.IsDBNull(colIDTRATTASUCC))
							t.IdTrattaSucc = null;
						else
							t.IdTrattaSucc = (int)rd.GetDouble(colIDTRATTASUCC);
						t.Direzione = rd.GetString(colDIREZIONE);

						if (rd.IsDBNull(colDESCRTRATTAPREC))
							t.DescrTrattaPrec = null;
						else
							t.DescrTrattaPrec = rd.GetString(colDESCRTRATTAPREC);

						if (rd.IsDBNull(colDESCRTRATTASUCC))
							t.DescrTrattaSucc = null;
						else
							t.DescrTrattaSucc = rd.GetString(colDESCRTRATTASUCC);

						t.Lat = rd.GetDouble(colLAT);
						t.Lon = rd.GetDouble(colLON);
					};

					cn.Open();
					List<C2P> rr = this.RecordReader<C2P>(cmd, rt, rcb);
					return rr;
				}
			}
		}

		public C2P GetRecord(C2P t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"SELECT QMGR_NAME, 
										CODICESTRADA, 
										KM, 
										IDC2P, 
										IDCOA, 
										DESCRIZIONE, 
										IDTRATTAPREC, 
										IDTRATTASUCC, 
										DIREZIONE,
										LAT,
										LON 
										FROM C2P where ";
					q += "IDC2P = :P_IDC2P";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					int colQMGR_NAME = -1;
					int colCODICESTRADA = -1;
					int colKM = -1;
					int colIDC2P = -1;
					int colIDCOA = -1;
					int colDESCRIZIONE = -1;
					int colIDTRATTAPREC = -1;
					int colIDTRATTASUCC = -1;
					int colDIREZIONE = -1;
					int colLAT = -1;
					int colLON = -1;

					cmd.AddWithValue("P_IDC2P", t.IdC2P);

					RecordColumnBinder<C2P> rcb = delegate(OracleDataReader rd)
					{
						colQMGR_NAME = rd.GetOrdinal("QMGR_NAME");
						colCODICESTRADA = rd.GetOrdinal("CODICESTRADA");
						colKM = rd.GetOrdinal("KM");
						colIDC2P = rd.GetOrdinal("IDC2P");
						colIDCOA = rd.GetOrdinal("IDCOA");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colIDTRATTAPREC = rd.GetOrdinal("IDTRATTAPREC");
						colIDTRATTASUCC = rd.GetOrdinal("IDTRATTASUCC");
						colDIREZIONE = rd.GetOrdinal("DIREZIONE");
						colLAT = rd.GetOrdinal("LAT");
						colLON = rd.GetOrdinal("LON");
					};

					RecordBinder<C2P> rt = delegate(OracleDataReader rd, C2P tb)
					{
						tb.QmgrName = rd.GetString(colQMGR_NAME);
						tb.CodiceStrada = rd.GetString(colCODICESTRADA);
						tb.Km = rd.GetString(colKM);
						tb.IdC2P = (int)rd.GetDouble(colIDC2P);
						tb.IdCOA = (int)rd.GetDouble(colIDCOA);
						tb.Descrizione = rd.GetString(colDESCRIZIONE);
						if (rd.IsDBNull(colIDTRATTAPREC))
							tb.IdTrattaPrec = null;
						else
							tb.IdTrattaPrec = (int)rd.GetDouble(colIDTRATTAPREC);
						if (rd.IsDBNull(colIDTRATTASUCC))
							tb.IdTrattaSucc = null;
						else
							tb.IdTrattaSucc = (int)rd.GetDouble(colIDTRATTASUCC);
						tb.Direzione = rd.GetString(colDIREZIONE);
						tb.Lat = rd.GetDouble(colLAT);
						tb.Lon = rd.GetDouble(colLON);
					};

					List<C2P> r = this.RecordReader<C2P>(cmd, rt, rcb);
					if (r.Count == 0) return null;
					return r[0];
				}
			}
		}

		public void Cancella(C2P t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"DELETE from C2P where ";
					q += "IDC2P = :P_IDC2P";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue("P_IDC2P", t.IdC2P);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Aggiorna(C2P t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"UPDATE C2P SET ";
					q += "QMGR_NAME = :P_QMGR_NAME";
					q += ", CODICESTRADA = :P_CODICESTRADA";
					q += ", KM = :P_KM";
					q += ", IDCOA = :P_IDCOA";
					q += ", DESCRIZIONE = :P_DESCRIZIONE";
					q += ", IDTRATTAPREC = :P_IDTRATTAPREC";
					q += ", IDTRATTASUCC = :P_IDTRATTASUCC";
					q += ", DIREZIONE = :P_DIREZIONE";
					q += ", LAT = :P_LAT";
					q += ", LON = :P_LON";
					q += " WHERE ";

					q += "IDC2P = :P_IDC2P";
					cmd.CommandText = q;

					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_QMGR_NAME", t.QmgrName);
					cmd.AddWithValue("P_CODICESTRADA", t.CodiceStrada);
					cmd.AddWithValue("P_KM", t.Km);
					cmd.AddWithValue("P_IDCOA", t.IdCOA);
					cmd.AddWithValue("P_DESCRIZIONE", t.Descrizione);
					cmd.AddWithValue("P_IDTRATTAPREC", t.IdTrattaPrec);
					cmd.AddWithValue("P_IDTRATTASUCC", t.IdTrattaSucc);
					cmd.AddWithValue("P_DIREZIONE", t.Direzione);
					cmd.AddWithValue("P_IDC2P", t.IdC2P);
					cmd.AddWithValue("P_LAT", t.Lat);
					cmd.AddWithValue("P_LON", t.Lon);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Inserisci(C2P t)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						string q = "INSERT INTO C2P (";
						q += "QMGR_NAME";
						q += ", CODICESTRADA";
						q += ", KM";
						q += ", IDC2P";
						q += ", IDCOA";
						q += ", DESCRIZIONE";
						q += ", IDTRATTAPREC";
						q += ", IDTRATTASUCC";
						q += ", DIREZIONE";
						q += ", LAT";
						q += ", LON";
						q += ") VALUES (";
						q += ":P_QMGR_NAME";
						q += ", :P_CODICESTRADA";
						q += ", :P_KM";
						q += ", :P_IDC2P";
						q += ", :P_IDCOA";
						q += ", :P_DESCRIZIONE";
						q += ", :P_IDTRATTAPREC";
						q += ", :P_IDTRATTASUCC";
						q += ", :P_DIREZIONE";
						q += ", :P_LAT";
						q += ", :P_LON";
						q += ")";

						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue("P_QMGR_NAME", t.QmgrName);
						cmd.AddWithValue("P_CODICESTRADA", t.CodiceStrada);
						cmd.AddWithValue("P_KM", t.Km);
						cmd.AddWithValue("P_IDC2P", t.IdC2P);
						cmd.AddWithValue("P_IDCOA", t.IdCOA);
						cmd.AddWithValue("P_DESCRIZIONE", t.Descrizione);
						cmd.AddWithValue("P_IDTRATTAPREC", t.IdTrattaPrec);
						cmd.AddWithValue("P_IDTRATTASUCC", t.IdTrattaSucc);
						cmd.AddWithValue("P_DIREZIONE", t.Direzione);
						cmd.AddWithValue("P_LAT", t.Lat);
						cmd.AddWithValue("P_LON", t.Lon);

						cn.Open();
						cmd.ExecuteNonQuery();
					}
				}
			}
			catch (OracleException ex)
			{
				if (ex.Number == 1)
					throw new ApplicationException("Record gia` presente", ex);
				else
					throw;
			}
		}

		public List<C2PDiagnostic> GetListaDiagnostica(string columnsSort)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"
SELECT 
IDC2P,
DESCRIZIONE,
DIAG_TSUPDATE,
DIAG_C2P_VE,
DIAG_CD_VE,
DIAG_CS_VE,
DIAG_CE_VE,
DIAG_CU_VE,
DIAG_C2P_ALIVE,
DIAG_CD_ALIVE,
DIAG_CS_ALIVE,
DIAG_CE_ALIVE, 
DIAG_CU_ALIVE,
DIAG_CD_STATUS, 
DIAG_CS_STATUS, 
DIAG_CE_STATUS, 
DIAG_CU_STATUS
FROM C2P  
order by " + columnsSort;
					cmd.CommandType = CommandType.Text;

					int colIDC2P = -1;
					int colDESCRIZIONE = -1;
					int colDIAG_TSUPDATE = -1;
					int colDIAG_C2P_VE = -1;
					int colDIAG_CD_VE = -1;
					int colDIAG_CS_VE = -1;
					int colDIAG_CE_VE = -1;
					int colDIAG_CU_VE = -1;
					int colDIAG_C2P_ALIVE = -1;
					int colDIAG_CD_ALIVE = -1;
					int colDIAG_CS_ALIVE = -1;
					int colDIAG_CE_ALIVE = -1;
					int colDIAG_CU_ALIVE = -1;
					int colDIAG_CD_STATUS = -1;
					int colDIAG_CS_STATUS = -1;
					int colDIAG_CE_STATUS = -1;
					int colDIAG_CU_STATUS = -1;

					RecordColumnBinder<C2PDiagnostic> rcb = delegate(OracleDataReader rd)
					{
						colIDC2P = rd.GetOrdinal("IDC2P");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colDIAG_TSUPDATE = rd.GetOrdinal("DIAG_TSUPDATE");
						colDIAG_C2P_VE = rd.GetOrdinal("DIAG_C2P_VE");
						colDIAG_CD_VE = rd.GetOrdinal("DIAG_CD_VE");
						colDIAG_CS_VE = rd.GetOrdinal("DIAG_CS_VE");
						colDIAG_CE_VE = rd.GetOrdinal("DIAG_CE_VE");
						colDIAG_CU_VE = rd.GetOrdinal("DIAG_CU_VE");
						colDIAG_C2P_ALIVE = rd.GetOrdinal("DIAG_C2P_ALIVE");
						colDIAG_CD_ALIVE = rd.GetOrdinal("DIAG_CD_ALIVE");
						colDIAG_CS_ALIVE = rd.GetOrdinal("DIAG_CS_ALIVE");
						colDIAG_CE_ALIVE = rd.GetOrdinal("DIAG_CE_ALIVE");
						colDIAG_CU_ALIVE = rd.GetOrdinal("DIAG_CU_ALIVE");
						colDIAG_CD_STATUS = rd.GetOrdinal("DIAG_CD_STATUS");
						colDIAG_CS_STATUS = rd.GetOrdinal("DIAG_CS_STATUS");
						colDIAG_CE_STATUS = rd.GetOrdinal("DIAG_CE_STATUS");
						colDIAG_CU_STATUS = rd.GetOrdinal("DIAG_CU_STATUS");
					};

					RecordBinder<C2PDiagnostic> rt = delegate(OracleDataReader rd, C2PDiagnostic t)
					{
						t.IdC2P = (int)rd.GetDouble(colIDC2P);
						t.Descrizione = rd.GetString(colDESCRIZIONE);

						if (rd.IsDBNull(colDIAG_TSUPDATE))
							t.Diag_TSUpdate = null;
						else
							t.Diag_TSUpdate = rd.GetDateTime(colDIAG_TSUPDATE);

						if (rd.IsDBNull(colDIAG_C2P_VE))
							t.Diag_C2P_VE = true;
						else
							t.Diag_C2P_VE = rd.GetString(colDIAG_C2P_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CD_VE))
							t.Diag_CD_VE = true;
						else
							t.Diag_CD_VE = rd.GetString(colDIAG_CD_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CE_VE))
							t.Diag_CE_VE = true;
						else
							t.Diag_CE_VE = rd.GetString(colDIAG_CE_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CS_VE))
							t.Diag_CS_VE = true;
						else
							t.Diag_CS_VE = rd.GetString(colDIAG_CS_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CU_VE))
							t.Diag_CU_VE = true;
						else
							t.Diag_CU_VE = rd.GetString(colDIAG_CU_VE) == "N" ? false : true;


						if (rd.IsDBNull(colDIAG_C2P_ALIVE))
							t.Diag_C2P_Alive = null;
						else
							t.Diag_C2P_Alive = rd.GetString(colDIAG_C2P_ALIVE);


						if (rd.IsDBNull(colDIAG_CD_ALIVE))
							t.Diag_CD_Alive = null;
						else
							t.Diag_CD_Alive = rd.GetString(colDIAG_CD_ALIVE);

						if (rd.IsDBNull(colDIAG_CE_ALIVE))
							t.Diag_CE_Alive = null;
						else
							t.Diag_CE_Alive = rd.GetString(colDIAG_CE_ALIVE);

						if (rd.IsDBNull(colDIAG_CS_ALIVE))
							t.Diag_CS_Alive = null;
						else
							t.Diag_CS_Alive = rd.GetString(colDIAG_CS_ALIVE);

						if (rd.IsDBNull(colDIAG_CU_ALIVE))
							t.Diag_CU_Alive = null;
						else
							t.Diag_CU_Alive = rd.GetString(colDIAG_CU_ALIVE);

						if (rd.IsDBNull(colDIAG_CD_STATUS))
							t.Diag_CD_Status = null;
						else
							t.Diag_CD_Status = rd.GetString(colDIAG_CD_STATUS);

						if (rd.IsDBNull(colDIAG_CE_STATUS))
							t.Diag_CE_Status = null;
						else
							t.Diag_CE_Status = rd.GetString(colDIAG_CE_STATUS);

						if (rd.IsDBNull(colDIAG_CS_STATUS))
							t.Diag_CS_Status = null;
						else
							t.Diag_CS_Status = rd.GetString(colDIAG_CS_STATUS);

						if (rd.IsDBNull(colDIAG_CU_STATUS))
							t.Diag_CU_Status = null;
						else
							t.Diag_CU_Status = rd.GetString(colDIAG_CU_STATUS);

					};

					cn.Open();
					return this.RecordReader<C2PDiagnostic>(cmd, rt, rcb);
				}
			}
		}

		public C2PDiagnostic GetRecord(C2PDiagnostic t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"SELECT 
                                IDC2P,
                                DESCRIZIONE,
                                DIAG_TSUPDATE,
                                DIAG_C2P_VE,
                                DIAG_CD_VE,
                                DIAG_CS_VE,
                                DIAG_CE_VE,
                                DIAG_CU_VE,
                                DIAG_CD_ALIVE,
                                DIAG_CS_ALIVE,
                                DIAG_CE_ALIVE, 
                                DIAG_CU_ALIVE,
                                DIAG_CD_STATUS, 
                                DIAG_CS_STATUS, 
                                DIAG_CE_STATUS, 
                                DIAG_CU_STATUS
								FROM C2P where ";
					q += "IDC2P = :P_IDC2P";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					int colIDC2P = -1;
					int colDESCRIZIONE = -1;
					int colDIAG_TSUPDATE = -1;
					int colDIAG_C2P_VE = -1;
					int colDIAG_CD_VE = -1;
					int colDIAG_CS_VE = -1;
					int colDIAG_CE_VE = -1;
					int colDIAG_CU_VE = -1;
					int colDIAG_CD_ALIVE = -1;
					int colDIAG_CS_ALIVE = -1;
					int colDIAG_CE_ALIVE = -1;
					int colDIAG_CU_ALIVE = -1;
					int colDIAG_CD_STATUS = -1;
					int colDIAG_CS_STATUS = -1;
					int colDIAG_CE_STATUS = -1;
					int colDIAG_CU_STATUS = -1;

					cmd.AddWithValue("P_IDC2P", t.IdC2P);

					RecordColumnBinder<C2PDiagnostic> rcb = delegate(OracleDataReader rd)
					{
						colIDC2P = rd.GetOrdinal("IDC2P");
						colDESCRIZIONE = rd.GetOrdinal("DESCRIZIONE");
						colDIAG_TSUPDATE = rd.GetOrdinal("DIAG_TSUPDATE");
						colDIAG_C2P_VE = rd.GetOrdinal("DIAG_C2P_VE");
						colDIAG_CD_VE = rd.GetOrdinal("DIAG_CD_VE");
						colDIAG_CS_VE = rd.GetOrdinal("DIAG_CS_VE");
						colDIAG_CE_VE = rd.GetOrdinal("DIAG_CE_VE");
						colDIAG_CU_VE = rd.GetOrdinal("DIAG_CU_VE");
						colDIAG_CD_ALIVE = rd.GetOrdinal("DIAG_CD_ALIVE");
						colDIAG_CS_ALIVE = rd.GetOrdinal("DIAG_CS_ALIVE");
						colDIAG_CE_ALIVE = rd.GetOrdinal("DIAG_CE_ALIVE");
						colDIAG_CU_ALIVE = rd.GetOrdinal("DIAG_CU_ALIVE");
						colDIAG_CD_STATUS = rd.GetOrdinal("DIAG_CD_STATUS");
						colDIAG_CS_STATUS = rd.GetOrdinal("DIAG_CS_STATUS");
						colDIAG_CE_STATUS = rd.GetOrdinal("DIAG_CE_STATUS");
						colDIAG_CU_STATUS = rd.GetOrdinal("DIAG_CU_STATUS");
					};

					RecordBinder<C2PDiagnostic> rt = delegate(OracleDataReader rd, C2PDiagnostic tb)
					{
						t.IdC2P = (int)rd.GetDouble(colIDC2P);
						t.Descrizione = rd.GetString(colDESCRIZIONE);

						if (rd.IsDBNull(colDIAG_TSUPDATE))
							t.Diag_TSUpdate = null;
						else
							t.Diag_TSUpdate = rd.GetDateTime(colDIAG_TSUPDATE);

						if (rd.IsDBNull(colDIAG_C2P_VE))
							t.Diag_C2P_VE = true;
						else
							t.Diag_C2P_VE = rd.GetString(colDIAG_C2P_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CD_VE))
							t.Diag_CD_VE = true;
						else
							t.Diag_CD_VE = rd.GetString(colDIAG_CD_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CE_VE))
							t.Diag_CE_VE = true;
						else
							t.Diag_CE_VE = rd.GetString(colDIAG_CE_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CS_VE))
							t.Diag_CS_VE = true;
						else
							t.Diag_CS_VE = rd.GetString(colDIAG_CS_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CD_VE))
							t.Diag_CD_VE = true;
						else
							t.Diag_CD_VE = rd.GetString(colDIAG_CD_VE) == "N" ? false : true;

						if (rd.IsDBNull(colDIAG_CD_ALIVE))
							t.Diag_CD_Alive = null;
						else
							t.Diag_CD_Alive = rd.GetString(colDIAG_CD_ALIVE);

						if (rd.IsDBNull(colDIAG_CE_ALIVE))
							t.Diag_CE_Alive = null;
						else
							t.Diag_CE_Alive = rd.GetString(colDIAG_CE_ALIVE);

						if (rd.IsDBNull(colDIAG_CS_ALIVE))
							t.Diag_CS_Alive = null;
						else
							t.Diag_CS_Alive = rd.GetString(colDIAG_CS_ALIVE);

						if (rd.IsDBNull(colDIAG_CU_ALIVE))
							t.Diag_CU_Alive = null;
						else
							t.Diag_CU_Alive = rd.GetString(colDIAG_CU_ALIVE);

						if (rd.IsDBNull(colDIAG_CD_STATUS))
							t.Diag_CD_Status = null;
						else
							t.Diag_CD_Status = rd.GetString(colDIAG_CD_STATUS);

						if (rd.IsDBNull(colDIAG_CE_STATUS))
							t.Diag_CE_Status = null;
						else
							t.Diag_CE_Status = rd.GetString(colDIAG_CE_STATUS);

						if (rd.IsDBNull(colDIAG_CS_STATUS))
							t.Diag_CS_Status = null;
						else
							t.Diag_CS_Status = rd.GetString(colDIAG_CS_STATUS);

						if (rd.IsDBNull(colDIAG_CU_STATUS))
							t.Diag_CU_Status = null;
						else
							t.Diag_CU_Status = rd.GetString(colDIAG_CU_STATUS);
					};

					List<C2PDiagnostic> r = this.RecordReader<C2PDiagnostic>(cmd, rt, rcb);
					if (r.Count == 0) return null;
					return r[0];
				}
			}
		}

		public void AggiornaDiagnostica(C2PDiagnostic t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"UPDATE C2P SET ";
					q += " DIAG_C2P_VE = :P_DIAG_C2P_VE";
					q += ", DIAG_CD_VE = :P_DIAG_CD_VE";
					q += ", DIAG_CS_VE = :P_DIAG_CS_VE";
					q += ", DIAG_CE_VE = :P_DIAG_CE_VE";
					q += ", DIAG_CU_VE = :P_DIAG_CU_VE";
					q += " WHERE ";
					q += "IDC2P = :P_IDC2P";
					cmd.CommandText = q;

					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_IDC2P", t.IdC2P);
					cmd.AddWithValue("P_DIAG_C2P_VE", t.Diag_C2P_VE ? "Y" : "N");
					cmd.AddWithValue("P_DIAG_CD_VE", t.Diag_CD_VE ? "Y" : "N");
					cmd.AddWithValue("P_DIAG_CS_VE", t.Diag_CS_VE ? "Y" : "N");
					cmd.AddWithValue("P_DIAG_CE_VE", t.Diag_CE_VE ? "Y" : "N");
					cmd.AddWithValue("P_DIAG_CU_VE", t.Diag_CU_VE ? "Y" : "N");

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public SytemDiagnostic RefreshDiagnostica(int IdCoa)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"
select 
sum(Diagnostica)    Diagnostica,
sum(SorveglianzaA1) SorveglianzaA1,
sum(SorveglianzaA2) SorveglianzaA2
from
(
	SELECT 
	CASE WHEN COUNT(*) = 0 THEN 1 ELSE 0 END AS Diagnostica, 
	0   AS SorveglianzaA1, 
	0   AS SorveglianzaA2, 
	'D' AS Tipo
	FROM C2P
	WHERE     
	((DIAG_C2P_VE = 'Y') AND DIAG_TSUPDATE is null) OR
	((DIAG_C2P_VE = 'Y') AND (DIAG_C2P_ALIVE is not null and DIAG_C2P_ALIVE <> 'true')) OR
	((DIAG_CD_VE = 'Y' OR DIAG_CD_VE IS NULL) AND (DIAG_CD_ALIVE IS NOT NULL) AND (DIAG_CD_ALIVE <> 'true')) OR 
	((DIAG_CS_VE = 'Y' OR DIAG_CS_VE IS NULL) AND (DIAG_CS_ALIVE IS NOT NULL) AND (DIAG_CS_ALIVE <> 'true')) OR 
	((DIAG_CE_VE = 'Y' OR DIAG_CE_VE IS NULL) AND (DIAG_CE_ALIVE IS NOT NULL) AND (DIAG_CE_ALIVE <> 'true')) OR 
	((DIAG_CU_VE = 'Y' OR DIAG_CU_VE IS NULL) AND (DIAG_CU_ALIVE IS NOT NULL) AND (DIAG_CU_ALIVE <> 'true'))

	UNION

	SELECT     
	0 AS Diagnostica, 
	nvl(sum(decode(s.ENUMTIPOLTSSEGNALAZIONE1, 'A2', 0, 1)), 0) SorveglianzaA1,
	nvl(sum(decode(s.ENUMTIPOLTSSEGNALAZIONE1, 'A2', 1, 0)), 0) SorveglianzaA2,
	'S' AS Tipo
	FROM SORVEGLIANZARES S 
	INNER JOIN EVENTIDASEGNALARE E 
	ON E.TARGA = S.TARGA AND 
	E.NAZIONALITA = S.NAZIONALITA AND 
	E.DATAORAINSERIMENTO = S.DATAORAINSERIMENTO 
	AND E.IDEVENTO = S.IDEVENTO 
	INNER JOIN TRANSITISUEVENTO T 
	ON T .TARGA = S.TARGA AND 
	T .NAZIONALITA = S.NAZIONALITA AND 
	T .DATAORARILEVAMENTO = S.DATAORARILEVAMENTO 
	INNER JOIN C2P ON C2P.IDC2P = T .IDC2P
	WHERE
	(S.IDCOA = :P_IDCOA) AND 
	(T .ENUMSTATOTRANSITO <> 'NORIC') AND 
	(E.ENUMSTATOALLARME = 'ACQ' OR E.ENUMSTATOALLARME = 'PIC')
)";

					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					int colDiagnostica = -1;
					int colSorveglianzaA1 = -1;
					int colSorveglianzaA2 = -1;

					cmd.AddWithValue("P_IDCOA", IdCoa);

					RecordColumnBinder<SytemDiagnostic> rcb = delegate(OracleDataReader rd)
					{
						colDiagnostica = rd.GetOrdinal("DIAGNOSTICA");
						colSorveglianzaA1 = rd.GetOrdinal("SORVEGLIANZAA1");
						colSorveglianzaA2 = rd.GetOrdinal("SORVEGLIANZAA2");
					};

					RecordBinder<SytemDiagnostic> rt = delegate(OracleDataReader rd, SytemDiagnostic t)
					{
						t.Diagnostica = Convert.ToBoolean(rd[colDiagnostica]);
						t.SorveglianzaA1 = Convert.ToInt32(rd[colSorveglianzaA1]);
						t.SorveglianzaA2 = Convert.ToInt32(rd[colSorveglianzaA2]);
					};

					List<SytemDiagnostic> r = this.RecordReader<SytemDiagnostic>(cmd, rt, rcb);
					if (r.Count != 1)
					{
						Log.Write("Errore nel recupero dati diagnostica e sorveglianza");
						return null;
					}
					return r[0];
				}
			}
		}
		#endregion


		public List<DiaTransitiRecord> GetListaTransitiNelGiorno(DateTime d, int periodoMinuti, int? IdC2P, string ordinaPer)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				cn.Open();

				bool bDaInserire = false;
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = "select count(*) from periodi where DELTA_MINUTI = :p";
					cmd.AddWithValue(":p", periodoMinuti);
					object t = cmd.ExecuteScalar();
					if (Convert.ToInt32(t) == 0)
						bDaInserire = true;
				}

				if (bDaInserire)
				{
					int p = 24 * 60 / periodoMinuti;
					for (int i = 0; i < p; ++i)
					{
						using (OracleCommand cmd = CreateCommand(cn))
						{
							cmd.CommandText = "insert into periodi (DELTA_MINUTI, PROGRESSIVO_MINUTI) values (:d, :p)";
							cmd.AddWithValue(":d", periodoMinuti);
							cmd.AddWithValue(":p", i * periodoMinuti);
							cmd.ExecuteNonQuery();
						}
					}
				}

				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"
			select
			Periodo,
			C2P,
			sum(NumTr_S) + sum(NumTr_D) + sum(NumTr_E) + sum(NumTr_U) NumTr,
			sum(NumEv_S) + sum(NumEv_D) + sum(NumEv_E) + sum(NumEv_U) NumEv,
			sum(NumTr_S) NumTr_S,
			sum(NumTr_D) NumTr_D,
			sum(NumTr_E) NumTr_E,
			sum(NumTr_U) NumTr_U,
			sum(NumEv_S) NumEv_S,
			sum(NumEv_D) NumEv_D,
			sum(NumEv_E) NumEv_E,
			sum(NumEv_U) NumEv_U
			from
			(
				select 
				Periodo,
				C2P,
				EnumTipoVarco,

				decode(EnumTipoVarco, 'S', NumeroTransiti, 0) NumTr_S,
				decode(EnumTipoVarco, 'D', NumeroTransiti, 0) NumTr_D,
				decode(EnumTipoVarco, 'E', NumeroTransiti, 0) NumTr_E,
				decode(EnumTipoVarco, 'U', NumeroTransiti, 0) NumTr_U,

				decode(EnumTipoVarco, 'S', NumeroTransitiAllarmati, 0) NumEv_S,
				decode(EnumTipoVarco, 'D', NumeroTransitiAllarmati, 0) NumEv_D,
				decode(EnumTipoVarco, 'E', NumeroTransitiAllarmati, 0) NumEv_E,
				decode(EnumTipoVarco, 'U', NumeroTransitiAllarmati, 0) NumEv_U

				from
				(
					select TT.*
					from
					(
						select 
						periodi.PROGRESSIVO_MINUTI Periodo, 
						C2P.Descrizione C2P, 
						E.ENUMTIPOVARCO, 
						0 NumeroTransiti, 
						0 NumeroTransitiAllarmati 
						from C2P, periodi,
						( 
							      select 'E' ENUMTIPOVARCO from dual
							union select 'U' ENUMTIPOVARCO from dual
							union select 'D' ENUMTIPOVARCO from dual
							union select 'S' ENUMTIPOVARCO from dual
						) E
						where periodi.DELTA_MINUTI = :p_periodo
						and   (:P_idC2P is null or C2P.IdC2P = :P_idC2P)
					) TT
					
					union

					select 
					ITRS.""ArrotondaData""(TRANSITI.DATAORARILEVAMENTO, :p_periodo) Periodo,
					C2p.Descrizione C2P, 
					TRANSITI.ENUMTIPOVARCO,
					count(*) NumeroTransiti, 
					0        NumeroTransitiAllarmati  
					from TRANSITI
					inner join C2p
					on C2p.idC2P = TRANSITI.IDC2P
					where
					trunc(TRANSITI.DATAORARILEVAMENTO) = :p_data
					and   (:P_idC2P is null or TRANSITI.IdC2P = :P_idC2P)
					group by 
					TRANSITI.ENUMTIPOVARCO, 
					C2p.Descrizione, 
					ITRS.""ArrotondaData""(TRANSITI.DATAORARILEVAMENTO, :p_periodo)

					union

					select 
					ITRS.""ArrotondaData""(TRANSITISUEVENTO.DATAORARILEVAMENTO, :p_periodo) Periodo,
					C2p.Descrizione C2P, 
					TRANSITISUEVENTO.ENUMTIPOVARCO,
					0        NumeroTransiti,
					count(*) NumeroTransitiAllarmati
					from TRANSITISUEVENTO
					inner join C2p
					on C2p.idC2P = TRANSITISUEVENTO.IDC2P
					where
					trunc(TRANSITISUEVENTO.DATAORARILEVAMENTO) = :p_data
					and  (:P_idC2P is null or TRANSITISUEVENTO.IdC2P = :P_idC2P)
					group by TRANSITISUEVENTO.ENUMTIPOVARCO, 
					C2p.Descrizione, 
					ITRS.""ArrotondaData""(TRANSITISUEVENTO.DATAORARILEVAMENTO, :p_periodo)
				)
			)
			group by Periodo,C2P
			";

					if (ordinaPer.ToLower() == "periodo")
						q += "order by Periodo,C2P";
					else
						q += "order by C2P, Periodo";

					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue("p_data", d.Date);
					cmd.AddWithValue("p_periodo", periodoMinuti);
					cmd.AddWithValue("p_idC2P", IdC2P);

					List<DiaTransitiRecord> ret;
					ret = RecordReader<DiaTransitiRecord>(cmd);
					return ret;
				}
			}
		}

		List<int> GetListaC2P()
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cn.Open();

					cmd.CommandText = "select idC2p from c2p order by Descrizione";

					List<int> ret = new List<int>();
					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						while (rd.Read())
						{
							int d = Convert.ToInt32(rd[0]);
							ret.Add(d);
						}
					}
					return ret;
				}
			}
		}


		public List<C2PDiagnosticaStorica> GetListaDiagnosticaStorica(DateTime di, DateTime df)
		{
			List<C2PDiagnosticaStorica> ret = new List<C2PDiagnosticaStorica>();
			foreach (int c2p in GetListaC2P())
			{
				List<C2PDiagnosticaStorica> t = GetListaDiagnosticaStorica(c2p, di, df);
				ret.AddRange(t);
			}
			return ret;
		}


		public List<C2PDiagnosticaStorica> GetListaDiagnosticaStorica(int idC2P, DateTime di, DateTime df)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"
select 
T.DIAG_PROG,
T.DIAG_TSUPDATE,
T.DIAG_CD_ALIVE,
T.DIAG_CS_ALIVE,
T.DIAG_CE_ALIVE,
T.DIAG_CU_ALIVE,
T.DIAG_CD_STATUS,
T.DIAG_CS_STATUS,
T.DIAG_CE_STATUS,
T.DIAG_CU_STATUS,
C2P.Descrizione C2P_Descr
from
(
	select * from DIAGN_C2P
	where IDC2P = :p_idC2P
	and DIAG_TSUPDATE >= :p_di
	and DIAG_TSUPDATE <= :p_df

	union all

	select * from DIAGN_C2P
	where DIAG_PROG in
	(
		select 
		max(DIAG_PROG) DIAG_PROG
		from DIAGN_C2P
		where IDC2P = :p_idC2P
		and DIAGN_C2P.DIAG_TSUPDATE < :p_di
	)
) T
inner join C2P
on C2P.IDC2P = T.IDC2P
order by DIAG_PROG asc
";
					cmd.AddWithValue("p_idC2P", idC2P);
					cmd.AddWithValue("p_di", di);
					cmd.AddWithValue("p_df", df);

					return RecordReader<C2PDiagnosticaStorica>(cmd);
				}
			}
		}


		public void DiagnosticaC2PPoller(int updateMinuteTimeout)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				cn.Open();
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"
update C2P
set
DIAG_TSUPDATE  = sysdate,
DIAG_C2P_ALIVE = 'false',
DIAG_CD_ALIVE  = 'false',
DIAG_CS_ALIVE  = 'false',
DIAG_CE_ALIVE  = 'false',
DIAG_CU_ALIVE  = 'false',
DIAG_CD_STATUS = null,
DIAG_CS_STATUS = null,
DIAG_CE_STATUS = null,
DIAG_CU_STATUS = null
where 
(DIAG_C2P_ALIVE = 'true' or DIAG_C2P_ALIVE is null)
and DIAG_TSUPDATE + :p_m / 1440.0 < sysdate
";
					cmd.AddWithValue(":p_m", (double)updateMinuteTimeout);
					cmd.ExecuteNonQuery();

				}
			}
		}


		public void UpdateTsDelay(C2PTsDelay r)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				cn.Open();
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"update c2p set ts_delay = :p where idC2p = :i";
					cmd.AddWithValue("p", r.TsDelay);
					cmd.AddWithValue("i", r.IdC2P);
					cmd.ExecuteNonQuery();
				}
			}
		}


		public List<C2PTsDelay> GetTsDelay()
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				cn.Open();

				for (int i = 0; i < 2; ++i)
				{
					bool colonnaMancante = false;

					try
					{
						using (OracleCommand cmd = this.CreateCommand(cn))
						{
							cmd.CommandText = @"
select 
c2p.IdC2P, 
c2p.DESCRIZIONE C2PDescr, 
c2p.TS_DELAY    TsDelay,
COA.DESCRIZIONE CoaDescr
from C2P
inner join COA
on COA.IDCOA = c2p.IDCOA
order by
COA.DESCRIZIONE,
C2P.Descrizione
";

							List<C2PTsDelay> ret = RecordReader<C2PTsDelay>(cmd);
							return ret;
						}
					}
					catch (OracleException ex)
					{
						// ORA-00904 - invalid identifier - manca la colonna!!!
						if (ex.Number != 904)
							throw;

						colonnaMancante = true;
					}

					if (colonnaMancante)
					{
						using (OracleCommand cmd = this.CreateCommand(cn))
						{
							cmd.CommandText = "ALTER TABLE ITRS.C2P ADD ( TS_DELAY NUMBER(15, 0) DEFAULT null NULL )";
							cmd.ExecuteNonQuery();
						}
					}
				}

				return null;
			}
		}
	}
}
