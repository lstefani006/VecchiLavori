using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Diagnostics;
using System.Configuration;
using System.Reflection;
using System.Globalization;

using ODP = Oracle.DataAccess.Client;
using ODPT = Oracle.DataAccess.Types;

namespace ITRS_BL.Oracle
{
	/// <summary>
	/// classe facade di OracleCommand
	/// ODP.OracleCommand ha il brutto vizio di esporre parametri OracleParameter che implementano
	/// IDisposable. (nessun altro provider lo fa).
	/// Alla fine dello sviluppo mi sono accorto di questa caratteristica dell'odp perche` il sistema
	/// non riusciva a rilasciare efficacemente la memoria dato che il tutto era demandato al GC causando
	/// molta "pressione" sullo stesso. L'assunto, con il senno di poi e` banale: se un oggetto e` disposabile 
	/// bisogna chiamare Dispose appena possibile.
	/// Usando il reflector inoltre ho visto che il OracleParameter libera un GCHandle ossia un handle win32.
	/// Un handle sicuramente punta a della memoria e, dato che l'applicativo tratta immagini, anche della memoria 
	/// grossina. Cosi` si spiegano la memoria virtuale che cresce e il numero di handle elevato.
	/// Inoltre la cosa sgradevole e` che siccome gli OracleParameter venivano usati e rilasciati subito andavano
	/// nella generazione 1 del GC: un parametro occupa pochissima memoria managed, ma potenzialmente molta memoria
	/// unmanaged. Cosi` il GC era tranquillo e non faceva collect anche in condizioni di memoria critiche.
	/// 
	/// Per evitare di scorrermi tutto il programma ho preferito fare un facade alla OracleCommand e alla 
	/// OracleParameterCollection per chiamare Dispose di tutti i parametri OracleParameter alla
	/// dispose di OracleCommand. 
	/// OracleParameterCollection inoltre su Clear fa Dispose dei OracleParameter
	/// 
	/// L'applicativo non tiene in vita parametri dopo che OracleCommand e` disposed dato che 
	/// non ero sicuro se la cosa e` lecita o no, dunque il paradigma dovrebbe tenere.
	/// </summary>
	public class OracleCommand : IDisposable
	{
		ODP.OracleCommand _cmd;
		bool _disposed;
		OracleParameterCollection _parameterCollectionFacade;

		public OracleCommand(ODP.OracleCommand cmd)
		{
			_cmd = cmd;
			_disposed = false;
			_parameterCollectionFacade = new OracleParameterCollection(this);
		}

		public string CommandText { get { return _cmd.CommandText; } set { _cmd.CommandText = value; } }
		public CommandType CommandType { get { return _cmd.CommandType; } set { _cmd.CommandType = value; } }
		public int CommandTimeout { get { return _cmd.CommandTimeout; } set { _cmd.CommandTimeout = value; } }
		public bool BindByName { get { return _cmd.BindByName; } }
		public long RowSize { get { return _cmd.RowSize; } }
		public int ArrayBindCount { get { return _cmd.ArrayBindCount; } set { _cmd.ArrayBindCount = value; } }
		public ODP.OracleConnection Connection { get { return _cmd.Connection; } }

		public OracleParameterCollection Parameters { get { return _parameterCollectionFacade; } }
		public ODP.OracleParameter CreateParameter() { return _cmd.CreateParameter(); }

		public int ExecuteNonQuery() { return _cmd.ExecuteNonQuery(); }
		public ODP.OracleDataReader ExecuteReader() { return _cmd.ExecuteReader(); }
		public object ExecuteScalar() { return _cmd.ExecuteScalar(); }

		public T ExecuteScalar<T>()
		{
			Debug.Assert(this.BindByName == true);

			using (ConnectionOpener cno = new ConnectionOpener(this.Connection))
			{
				object r = this.ExecuteScalar();
				return (T)r;
			}
		}


		public void Dispose()
		{
			if (_disposed == false)
			{
				_disposed = true;

				try
				{
					foreach (ODP.OracleParameter p in _cmd.Parameters)
						p.Dispose();
				}
				catch
				{
					Debug.Assert(false);
				}

				try
				{
					_cmd.Dispose();
				}
				catch
				{
					Debug.Assert(false);
				}
				finally
				{
					_cmd = null;
				}

				_parameterCollectionFacade = null;
			}
		}

		public void AddWithValue(string paramterName, string value)
		{
			ODP.OracleParameter p = new ODP.OracleParameter();
			p.ParameterName = paramterName;
			p.Direction = ParameterDirection.Input;
			p.OracleDbType = ODP.OracleDbType.Varchar2;
			if (value == null) p.Value = DBNull.Value; else p.Value = value;
			this.Parameters.Add(p);
		}
		public void AddWithValue(string paramterName, byte[] value)
		{
			ODP.OracleParameter p = new ODP.OracleParameter();
			p.ParameterName = paramterName;
			p.Direction = ParameterDirection.Input;
			p.OracleDbType = ODP.OracleDbType.Blob;
			if (value == null) p.Value = DBNull.Value; else p.Value = value;
			this.Parameters.Add(p);
		}

		public void AddWithValue(string paramterName, Int32 value)
		{
			Int32? v = value;
			AddWithValue(paramterName, v);
		}
		public void AddWithValue(string paramterName, Int32? value)
		{
			ODP.OracleParameter p = new ODP.OracleParameter();
			p.ParameterName = paramterName;
			p.Direction = ParameterDirection.Input;
			p.DbType = DbType.Int32;
			if (value.HasValue) p.Value = value; else p.Value = DBNull.Value;
			this.Parameters.Add(p);
		}

		public void AddWithValue(string paramterName, Int64 value)
		{
			Int64? v = value;
			AddWithValue(paramterName, v);
		}
		public void AddWithValue(string paramterName, Int64? value)
		{
			ODP.OracleParameter p = new ODP.OracleParameter();
			p.ParameterName = paramterName;
			p.Direction = ParameterDirection.Input;
			p.DbType = DbType.Int64;
			if (value.HasValue) p.Value = value; else p.Value = DBNull.Value;
			this.Parameters.Add(p);
		}

		public void AddWithValue(string paramterName, Single value)
		{
			Single? v = value;
			AddWithValue(paramterName, v);
		}
		public void AddWithValue(string paramterName, Single? value)
		{
			ODP.OracleParameter p = new ODP.OracleParameter();
			p.ParameterName = paramterName;
			p.Direction = ParameterDirection.Input;
			p.DbType = DbType.Single;
			if (value.HasValue) p.Value = value; else p.Value = DBNull.Value;
			this.Parameters.Add(p);
		}

		public void AddWithValue(string paramterName, Double value)
		{
			Double? v = value;
			AddWithValue(paramterName, v);
		}
		public void AddWithValue(string paramterName, Double? value)
		{
			ODP.OracleParameter p = new ODP.OracleParameter();
			p.ParameterName = paramterName;
			p.Direction = ParameterDirection.Input;
			p.DbType = DbType.Double;
			if (value.HasValue) p.Value = value; else p.Value = DBNull.Value;
			this.Parameters.Add(p);
		}

		public void AddWithValue(string paramterName, Decimal value)
		{
			Decimal? v = value;
			AddWithValue(paramterName, v);
		}
		public void AddWithValue(string paramterName, Decimal? value)
		{
			ODP.OracleParameter p = new ODP.OracleParameter();
			p.ParameterName = paramterName;
			p.Direction = ParameterDirection.Input;
			p.DbType = DbType.Decimal;
			if (value.HasValue) p.Value = value; else p.Value = DBNull.Value;
			this.Parameters.Add(p);
		}

		public void AddWithValue(string paramterName, DateTime value)
		{
			DateTime? v = value;
			AddWithValue(paramterName, v);
		}
		public void AddWithValue(string paramterName, DateTime? value)
		{
			ODP.OracleParameter p = new ODP.OracleParameter();
			p.ParameterName = paramterName;
			p.Direction = ParameterDirection.Input;
			p.DbType = DbType.DateTime;
			if (value.HasValue) p.Value = value; else p.Value = DBNull.Value;
			this.Parameters.Add(p);
		}

		public void AddWithValue(string paramterName, string[] values)
		{
			ODP.OracleParameter p = new ODP.OracleParameter(paramterName, ODP.OracleDbType.Varchar2);
			p.Direction = ParameterDirection.Input;
			p.Value = values;
			this.Parameters.Add(p);
		}
		public void AddWithValue(string paramterName, int[] values)
		{
			ODP.OracleParameter p = new ODP.OracleParameter(paramterName, ODP.OracleDbType.Int32);
			p.Direction = ParameterDirection.Input;
			p.Value = values;
			this.Parameters.Add(p);
		}
		public void AddWithValue(string paramterName, decimal[] values)
		{
			ODP.OracleParameter p = new ODP.OracleParameter(paramterName, ODP.OracleDbType.Decimal);
			p.Direction = ParameterDirection.Input;
			p.Value = values;
			this.Parameters.Add(p);
		}
		public void AddWithValue(string paramterName, double[] values)
		{
			ODP.OracleParameter p = new ODP.OracleParameter(paramterName, ODP.OracleDbType.Double);
			p.Direction = ParameterDirection.Input;
			p.Value = values;
			this.Parameters.Add(p);
		}
		public void AddWithValue(string paramterName, DateTime[] values)
		{
			ODP.OracleParameter p = new ODP.OracleParameter(paramterName, ODP.OracleDbType.Date);
			p.Direction = ParameterDirection.Input;
			p.Value = values;
			this.Parameters.Add(p);
		}


		public ODP.OracleParameter AddStringOutParameter(string paramterName, int maxSize)
		{
			Debug.Assert(maxSize > 0, "devi specificare la grandezza della stringa cosi' come e` nel DB");
			ODP.OracleParameter p = this.CreateParameter();
			p.ParameterName = paramterName;
			p.OracleDbType = ODP.OracleDbType.Varchar2;
			p.DbType = DbType.String;
			p.Direction = ParameterDirection.Output;
			p.IsNullable = true;
			p.Value = DBNull.Value;
			p.Size = maxSize;
			this.Parameters.Add(p);
			return p;
		}
		public ODP.OracleParameter AddInt64OutParameter(string paramterName)
		{
			ODP.OracleParameter p = this.CreateParameter();
			p.ParameterName = paramterName;
			p.DbType = DbType.Int64;
			p.Direction = ParameterDirection.Output;
			p.OracleDbType = ODP.OracleDbType.Int64;
			p.IsNullable = true;
			p.Value = DBNull.Value;
			this.Parameters.Add(p);
			return p;
		}
		public ODP.OracleParameter AddStringInOutParameter(string paramterName, string inValue, int size)
		{
			ODP.OracleParameter p = this.CreateParameter();
			p.ParameterName = paramterName;
			p.DbType = DbType.String;
			p.OracleDbType = ODP.OracleDbType.Varchar2;
			p.Direction = ParameterDirection.InputOutput;
			p.Size = size;
			p.IsNullable = true;
			p.Value = inValue;
			this.Parameters.Add(p);
			return p;
		}
		public ODP.OracleParameter AddInt32OutParameter(string paramterName)
		{
			ODP.OracleParameter p = this.CreateParameter();
			p.ParameterName = paramterName;
			p.DbType = DbType.Int32;
			p.Direction = ParameterDirection.Output;
			p.OracleDbType = ODP.OracleDbType.Int32;
			p.IsNullable = true;
			p.Value = DBNull.Value;
			this.Parameters.Add(p);
			return p;
		}

		/// <summary>
		/// Anche se sono public non chiamarmi
		/// </summary>
		/// <param name="p"></param>
		public void __Parameters_Add(ODP.OracleParameter p) { _cmd.Parameters.Add(p); }
		/// <summary>
		/// Anche se sono public non chiamarmi
		/// </summary>
		/// <param name="p"></param>
		public void __Parameters_Clear()
		{
			foreach (ODP.OracleParameter p in _cmd.Parameters)
				p.Dispose();
			_cmd.Parameters.Clear();
		}
	}

	public class OracleParameterCollection
	{
		OracleCommand _cmd;

		public OracleParameterCollection(OracleCommand cmd) { _cmd = cmd; }
		public void Add(ODP.OracleParameter p) { _cmd.__Parameters_Add(p); }
		public void Clear() { _cmd.__Parameters_Clear(); }
	}

	/// <summary>
	/// Classe Disposable che prende una connessione in ingresso.
	/// Se la connessione e` gia` aperta ConnectionOpener con fa niente,
	/// se la connessione e` chiusa ConnectionOpener la apre per poi chiuderla con Dispose.
	/// E` obbligatorio usare using (ConnectionOpener cno = new ConnectionOpener(cn)) { ... }
	/// </summary>
	internal class ConnectionOpener : IDisposable
	{
		ODP.OracleConnection _cn;

		public ConnectionOpener(ODP.OracleConnection cn)
		{
			_cn = null;
			if (cn.State != ConnectionState.Open)
			{
				cn.Open();
				_cn = cn;
			}
		}
		public ConnectionOpener(OracleCommand cmd)
			: this(cmd.Connection)
		{
		}


		void IDisposable.Dispose()
		{
			if (_cn != null)
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
				_cn = null;
			}
		}
	}


	public class DalBase
	{
		public DalBase()
		{
		}

		public ODP.OracleConnection CreateConnection()
		{
			ODP.OracleConnection cn = new ODP.OracleConnection();
			cn.ConnectionString = ConfigurationManager.ConnectionStrings["itrs_odp"].ConnectionString; ;
			return cn;
		}

		protected OracleCommand CreateCommand(ODP.OracleConnection cn)
		{
			ODP.OracleCommand cmd = cn.CreateCommand();
			cmd.AddToStatementCache = true;
			cmd.BindByName = true;
			return new OracleCommand(cmd);
		}
		protected OracleCommand PageQuery(ODP.OracleConnection cn, string query, int startRowIndex, int maximumRows)
		{
			string pg =
@"select * from 
(
	select /*+ FIRST_ROWS(n) */ 
	a.*, 
	rownum ProgressivoQuery
	from
	(
		{0}
	) a
	where rownum < :rowEnd
)
where ProgressivoQuery >= :rowStart";

			string q = string.Format(pg, query);

			OracleCommand cmd = CreateCommand(cn);

			cmd.CommandType = System.Data.CommandType.Text;
			cmd.CommandText = q;
			cmd.AddWithValue(":rowEnd", 1 + startRowIndex + maximumRows);
			cmd.AddWithValue(":rowStart", 1 + startRowIndex);

			return cmd;
		}
		protected void PageQuery(OracleCommand cmd, string query, int startRowIndex, int maximumRows)
		{
			string pg =
@"select * from 
(
	select /*+ FIRST_ROWS(n) */
	a.*, 
	rownum ProgressivoQuery
	from
	(
		{0}
	) a
	where rownum < :rowEnd
)
where ProgressivoQuery >= :rowStart";

			string q = string.Format(pg, query);

			cmd.CommandType = System.Data.CommandType.Text;
			cmd.CommandText = q;
			cmd.AddWithValue(":rowEnd", 1 + startRowIndex + maximumRows);
			cmd.AddWithValue(":rowStart", 1 + startRowIndex);
		}

		protected OracleCommand CreateBulkInsertCommand(ODP.OracleConnection cn, int insertCount)
		{
			OracleCommand cmd = CreateCommand(cn);
			cmd.ArrayBindCount = insertCount;
			return cmd;
		}


		public delegate void RecordBinder<T>(ODP.OracleDataReader rd, T record);
		public delegate void RecordColumnBinder<T>(ODP.OracleDataReader rd);


		/// <summary>
		/// Legge i record di tipo T utilizzando il DynamicRecordBinder
		/// </summary>
		/// <typeparam name="T">il tipo da leggere</typeparam>
		/// <param name="cmd">il comando</param>
		/// <returns>la lista dei record letti</returns>
		protected List<T> RecordReader<T>(OracleCommand cmd) where T : class, new()
		{
			DynamicRecordBinder<T> drb = new DynamicRecordBinder<T>();
			return RecordReader<T>(cmd, drb.Binder, drb.ColumnBinder);
		}
		protected List<T> RecordReader<T>(OracleCommand cmd, RecordBinder<T> tReader) where T : new()
		{
			return RecordReader<T>(cmd, tReader, null);
		}
		/// <summary>
		/// Esegue lo stmt ma imposta il numero di righe da fetchare in un colpo solo dal DB.
		/// Di default oracle sposta 64Kb per round-trip.
		/// Se si caricano record grossi o molti record si puo` impostare un numero di byte piu` grande:
		/// oracle, dopo la cmd.ExecuteReader (e prima del rd.Read) valorizza cmd.RowSize che rappresenta
		/// il numero di byte necessari per scaricare una singola riga.
		/// Specificando <paramref name="numRowsToFetch"/> <param name="numRowsToFetch"/> si impostano il numero di righe fetchate con un solo round-trip.
		/// eseguendo rd.FetchSize = cmd.RowSize * numRowsToFetch
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="cmd"></param>
		/// <returns></returns>
		protected List<T> RecordReader<T>(OracleCommand cmd, int numRowsToFetch) where T : class, new()
		{
			DynamicRecordBinder<T> drb = new DynamicRecordBinder<T>();
			return RecordReader<T>(cmd, drb.Binder, drb.ColumnBinder, numRowsToFetch);
		}

		protected List<T> RecordReader<T>(OracleCommand cmd, RecordBinder<T> tReader, RecordColumnBinder<T> tColumnBinder) where T : new()
		{
			return RecordReader<T>(cmd, tReader, tColumnBinder, 0);
		}

		protected List<T> RecordReader<T>(OracleCommand cmd, RecordBinder<T> tReader, RecordColumnBinder<T> tColumnBinder, int numRowsToFetch) where T : new()
		{
			Debug.Assert(cmd.BindByName == true);

			using (ConnectionOpener cno = new ConnectionOpener(cmd))
			{
				using (ODP.OracleDataReader rd = cmd.ExecuteReader())
				{
					if (tColumnBinder != null)
						tColumnBinder(rd);

					List<T> ret = new List<T>();

					if (numRowsToFetch > 0)
						rd.FetchSize = cmd.RowSize * numRowsToFetch;

					while (rd.Read())
					{
						T t = new T();
						tReader(rd, t);
						ret.Add(t);
					}
					return ret;
				}
			}
		}
		protected List<T> RecordReader<T>(OracleCommand cmd, string paramCursorOut, RecordBinder<T> tReader, RecordColumnBinder<T> tColumnBinder) where T : class, new()
		{
#if ODP
			Debug.Assert(cmd.BindByName == true);
#endif

			if (tReader == null && tColumnBinder == null)
			{
				DynamicRecordBinder<T> drb = new DynamicRecordBinder<T>();

				tReader = drb.Binder;
				tColumnBinder = drb.ColumnBinder;
			}

			List<T> ret = new List<T>();
			using (ConnectionOpener cno = new ConnectionOpener(cmd))
			{
				using (ODP.OracleParameter pCur = new ODP.OracleParameter())
				{
					pCur.ParameterName = paramCursorOut;
					pCur.Direction = ParameterDirection.Output;
					pCur.Value = DBNull.Value;
					pCur.OracleDbType = ODP.OracleDbType.RefCursor;
					cmd.Parameters.Add(pCur);

					cmd.ExecuteNonQuery();

					using (ODP.OracleDataReader rd = ((ODPT.OracleRefCursor)pCur.Value).GetDataReader())
					{
						if (tColumnBinder != null)
							tColumnBinder(rd);

						while (rd.Read())
						{
							T t = new T();
							tReader(rd, t);
							ret.Add(t);
						}
					}
				}
			}

			return ret;
		}

		public IEnumerable<T> ReadRecord<T>(OracleCommand cmd) where T : class, new()
		{
			using (ConnectionOpener cno = new ConnectionOpener(cmd))
			{
				DynamicRecordBinder<T> drb = new DynamicRecordBinder<T>();
				using (ODP.OracleDataReader rd = cmd.ExecuteReader())
				{
					drb.ColumnBinder(rd);
					while (rd.Read())
					{
						T t = new T();
						drb.Binder(rd, t);
						yield return t;
					}
				}
			}
		}

		/// <summary>
		/// prende in ingresso una stringa di comandi sql separati da stmt GO.
		/// La funzione ritorna le stringhe dei singoli di comandi da eseguire
		/// </summary>
		/// <param name="sql"></param>
		/// <returns></returns>
		public IEnumerable<string> ParseSql(string sql)
		{
			using (System.IO.StringReader sw = new System.IO.StringReader(sql))
			{
				string cmd = string.Empty;
				for (; ; )
				{
					string s = sw.ReadLine();
					if (s == null || s.ToUpper().Trim() == "GO")
					{
						if (!string.IsNullOrEmpty(cmd))
						{
							yield return cmd;
							cmd = string.Empty;
							continue; // salto il GO
						}
					}

					if (s == null)
						break;

					// le stringhe vuote all'inizio del comando (ossia a inizio file e dopo un GO)
					// non sono considerate
					if (s != "" || cmd != "")
						cmd += s + Environment.NewLine;
				}
			}
		}


	}

	[Serializable]
	public class DalException : ApplicationException
	{
		public DalException(string msg, Exception innerException)
			: base(msg, innerException)
		{
		}
	}

	[Serializable]
	public class DuplicatedKeyException : DalException
	{
		public DuplicatedKeyException(Exception innerException)
			: base("Impossibile inserimento - record gia` presente", innerException)
		{
		}
	}

	/// <summary>
	/// Classe per valorizzare i campi di un record di tipo T da un OracleDataReader.
	/// I campi da assegnare devono essere proprita` pubbliche.
	/// Tutte le colonne della query devono essere presenti com property nel record T.
	/// Il record T puo` contenere altre proprieta` o metodi.
	/// Il binding per ogni colonna viene effettuatto in maniera case insensitive.
	/// Il binding presume una corrispondenza tra i tipi ritornati dall'OracleDataReader
	/// e i tipi delle property. Se non vi e` stretta corrispondenza si chiama Convert.To*.
	/// Si puo` gestire l'evento <para>BindProperty</para> per effettuare, per colonna 
	/// un binding custom. Valizzare <code>e.Done = true</code> nell'evento per evitare 
	/// che il <c>ColumnBinder</c> esegua nuovamente il binding.
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class DynamicRecordBinder<T> where T : class
	{
		readonly object[] _dummy = new object[0];
		List<BindableProperty> _pi;

		class BindableProperty
		{
			//static object[] _args = new object[0];

			public BindableProperty(PropertyInfo pi, string dbColName)
			{
				this._pi = pi;
				Type pt = pi.PropertyType;

				this._dbColName = dbColName;

				if (pt == typeof(string) || pt == typeof(byte[]))
				{
					this._pt = pt;
					this._isNullable = true;
					this._isGenericType = false;
					this._isEnum = false;
				}
				else if (pt.IsGenericType && pt.GetGenericTypeDefinition() == typeof(Nullable<>))
				{
					this._pt = pi.PropertyType.GetGenericArguments()[0];
					this._isNullable = true;
					this._isGenericType = true;
					this._isEnum = this._pt.IsEnum;
				}
				else
				{
					this._pt = pt;
					this._isNullable = false;
					this._isGenericType = false;
					this._isEnum = pt.IsEnum;
				}
			}


			public string Name { get { return this._pi.Name; } }
			public string DbColName { get { return this._dbColName; } }
			public string TypeName { get { return this._pi.PropertyType.Name; } }

			public void SetNull(object target)
			{
				if (_isNullable == false)
					throw new ArgumentException("tipo non nullabile", Name);

				_pi.SetValue(target, null, null);
			}

			public void SetNotNull(object target, object value)
			{
				if (this._isEnum == false)
				{
					// se i tipi sono diversi faccio la conversione di tipo automatica
					if (value.GetType() != this._pt)
						value = Convert.ChangeType(value, this._pt, CultureInfo.InvariantCulture);
				}
				else
				{
					value = Enum.Parse(this._pt, (string)value);
				}

				_pi.SetValue(target, value, null);
			}

			public override string ToString()
			{
				return string.Format("BindableProperty Name={0} dbColName={1} isEnum={2} isNullable={3} isGenericType={4} propertyType={5}",
					this.Name,
					this.DbColName,
					this._isEnum,
					this._isNullable,
					this._isGenericType,
					this._pt.ToString());
			}



			readonly PropertyInfo _pi;
			/// <summary>
			/// e` un Enum o un Nullable(Enum)
			/// </summary>
			readonly bool _isEnum;
			/// <summary>
			/// e` un Nullable(T) o string o byte[]
			/// </summary>
			readonly bool _isNullable;
			/// <summary>
			/// e` un Nullable(T) compreso Nullable(Enum)
			/// </summary>
			readonly bool _isGenericType;
			readonly string _dbColName;
			/// <summary>
			/// tipo della proprieta` se _isNullable e` false
			/// altrimenti ritorna il tipo T di Nullable(T)
			/// </summary>
			readonly Type _pt;
		}

		public void ColumnBinder(ODP.OracleDataReader rd)
		{
			_pi = new List<BindableProperty>(rd.FieldCount);

			for (int c = 0; c < rd.FieldCount; ++c)
			{
				string dbColName = rd.GetName(c);

				PropertyInfo p = typeof(T).GetProperty(dbColName, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

				BindableProperty bp = null;
				if (p == null)
				{
					if (string.Compare(dbColName, "ProgressivoQuery", true) != 0)
					{
						string s = "Property " + dbColName + " non trovata in " + typeof(T).Name;
						Debug.Assert(p != null, s);
						throw new Exception();
					}
					bp = null;
				}
				else
					bp = new BindableProperty(p, dbColName);

				_pi.Add(bp);
			}
		}

		public void Binder(ODP.OracleDataReader rd, T record)
		{
			for (int c = 0; c < rd.FieldCount; ++c)
			{
				if (_pi[c] == null)
					continue;
				try
				{
					if (rd.IsDBNull(c))
						this.SetNull(record, c, _pi[c].DbColName);
					else
						this.SetNotNull(record, c, _pi[c].DbColName, rd[c]);
				}
				catch (Exception ex)
				{
					string s = string.Format(
						"Errore assegnando la property {0} della classe {1}. ", _pi[c].ToString(), typeof(T).Name);
					s += "Tipo letto dal DB " + rd[c].GetType().Name + ".";

					throw new Exception(s, ex);
				}
			}
		}


		public class BindPropertyEventArgs
		{
			public BindPropertyEventArgs(T record, int c, string dbColName, object v)
			{
				this.Record = record;
				this.ColumnIndex = c;
				this.DbColName = dbColName;
				this.Value = v;
				this.Done = false;
			}
			readonly public T Record;
			readonly public int ColumnIndex;
			readonly public object Value;
			readonly public string DbColName;
			public bool Done;
		}
		public delegate void BindPropertyDelegate(object sender, BindPropertyEventArgs e);
		public event BindPropertyDelegate BindProperty;

		protected virtual void SetNull(T record, int c, string dbColName)
		{
			if (BindProperty != null)
			{
				BindPropertyEventArgs e = new BindPropertyEventArgs(record, c, dbColName, DBNull.Value);
				BindProperty(this, e);
				if (e.Done == false)
					_pi[c].SetNull(record);
			}
			else
			{
				_pi[c].SetNull(record);
			}
		}

		protected virtual void SetNotNull(T record, int c, string dbColName, object v)
		{
			if (BindProperty != null)
			{
				BindPropertyEventArgs e = new BindPropertyEventArgs(record, c, dbColName, v);
				BindProperty(this, e);
				if (e.Done == false)
					_pi[c].SetNotNull(record, v);
			}
			else
			{
				_pi[c].SetNotNull(record, v);
			}
		}
	}

}

