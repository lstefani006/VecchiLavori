using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Diagnostics;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

using System.Data.Common;


using ITRS_BL.IDal;
using ITRS_BL.Utility;

namespace ITRS_BL.Oracle
{
	class DalLTS : DalBase, IDalLTS
	{
		private static string BuildWhereFromTipoLTS(string tipoLTS)
		{
			string ww = "";
			if (!string.IsNullOrEmpty(tipoLTS))
			{
				for (int i = 0; i < tipoLTS.Length; ++i)
				{
					switch (tipoLTS[i])
					{
					case 'A':
						if (ww.Length > 0) ww += "or ";
						i += 1;
						if (tipoLTS[i] == '1')
							ww += "(EnumTipoLTS = 'A1')";
						else
							ww += "(EnumTipoLTS = 'A2')";

						break;
					case 'B':
						if (ww.Length > 0) ww += "or ";
						ww += "(EnumTipoLTS = 'B')";
						break;
					case 'C':
						if (ww.Length > 0) ww += "or ";
						ww += "(EnumTipoLTS = 'C')";
						break;
					}
				}

				if (ww.Length > 0) ww = " and ( " + ww + " ) ";
			}
			return ww;
		}
		public List<BLLTS.LTSRecord> GetLTSList(string sortColumns, int startRowIndex, int maximumRows,
			string targa, string nazionalita,
			string tipoLTS,
			DateTime? ricercaInizioDal, DateTime? ricercaInizioAl,
			DateTime? ricercaFineDal, DateTime? ricercaFineAl,
			string IdUtenteRichiedente, int? IdCoa,
			DateTime? ricercaInseritoDal, DateTime? ricercaInseritoAl,
			string ricercaEmail, int? idCoaPerTipoC,

			string IdUtenteCollegato, int? IdCoaDiCompetenzaUtenteCollegato)
		{
			if (!string.IsNullOrEmpty(ricercaEmail))
			{
				tipoLTS = null;

				if (!ricercaEmail.Contains("%"))
					ricercaEmail += "%";
			}
			else
				ricercaEmail = null;

			using (OracleConnection cn = CreateConnection())
			{
				//if (string.IsNullOrEmpty(sortColumns))
				//	sortColumns = "Targa";

				if (string.IsNullOrEmpty(sortColumns))
					sortColumns = "";


				string[] campi = new string[] 
				{ 
					"",
					"Targa",
					"Nazionalita",
					"IdLts",
					"EnumTipoLTS",
					"IdUtenteRichiedente",
					"UserNameRichiedente",
					"Motivo",
					"Note",
					"DataOraInserimento",
					"DataOraInizioValidita",
					"DataOraFineValidita",
					"EnumTipoDest",
					"AddrDest",
					"EnumLivelloPriorita"
				};
				string[] sort = new string[] 
				{ 
					"",
					"Targa {0}",
					"Nazionalita {0}, Targa asc",
					"IdLts {0}",
					"EnumTipoLTS {0}, Targa asc",
					"IdUtenteRichiedente {0}, Targa asc",
					"UserNameRichiedente {0}, Targa asc",
					"Motivo {0}, Targa asc",
					"Note {0}, Targa asc",
					"DataOraInserimento {0}, Targa asc",
					"DataOraInizioValidita {0}, Targa asc",
					"DataOraFineValidita {0}, Targa asc",
					"EnumTipoDest {0}, Targa asc",
					"AddrDest {0}, Targa asc",
					"EnumLivelloPriorita {0}, Targa asc"
				};


				string[] c = sortColumns.Split(' ');
				string colName = c[0];
				string ascDesc = "";
				if (c.Length == 2) ascDesc = c[1];

				for (int col = 0; col < campi.Length; ++col)
					if (string.Compare(campi[col], c[0], true) == 0)
					{
						sortColumns = string.Format(sort[col], ascDesc);
						break;
					}



				string q = @"
select 
Targa,
Nazionalita,
IdLts,
EnumTipoLTS,
IdUtenteRichiedente,
AspNet_users.UserName as UserNameRichiedente,
Motivo,
Note,
DataOraInserimento,
DataOraInizioValidita,
DataOraFineValidita,
EnumTipoDest,
AddrDest,
EnumLivelloPriorita

FROM {2}
left outer join AspNet_users
on IdUtenteRichiedente = PKID
where 
	    ((:p_targa               is null) or (targa like :p_targa))
	and ((:p_nazionalita         is null) or (nazionalita like :p_nazionalita))
	and ((:p_RicercaInizioDal    is null) or (DataOraInizioValidita >= :p_RicercaInizioDal))
	and ((:p_RicercaInizioAl     is null) or (DataOraInizioValidita <= :p_RicercaInizioAl))
	and ((:p_RicercaFineDal      is null) or (DataOraFineValidita   >= :p_RicercaFineDal))
	and ((:p_RicercaFineAl       is null) or (DataOraFineValidita   <= :p_RicercaFineAl))
	and ((:p_RicercaInseritoDal  is null) or (DataOraInserimento    >= :p_RicercaInseritoDal))
	and ((:p_RicercaInseritoAl   is null) or (DataOraInserimento    <= :p_RicercaInseritoAl))
	and ((:p_IdUtenteRichiedente is null) or (IdUtenteRichiedente   =  :p_IdUtenteRichiedente))
	and ((:p_RicercaEmail        is null) or (AddrDest like :p_RicercaEmail and EnumTipoLTS = 'B'))
	and ((:p_IdCoa               is null) or (IdUtenteRichiedente in (select pkid from aspnet_userprofile where idCoaDiCompetenza = :p_IdCoa)))
	and ((:p_idCoaPerTipoC       is null) or (AddrDest = to_char(:p_idCoaPerTipoC) and EnumTipoLTS = 'C' ))
	and
	(
		(:p_IdUtenteCollegato is null) or 
		(
			(EnumTipoLTS = 'B'     and IdUtenteRichiedente = :p_IdUtenteCollegato) or
			(EnumTipoLTS = 'C'     and AddrDest = to_char(:p_IdCoaDiCompetenzaUtenteColl)) or
			(EnumTipoLTS like 'A%' )
		) 
	)
			
{0}

{1}
";

                string ww = BuildWhereFromTipoLTS(tipoLTS);

				string table = "LTS";

				if (tipoLTS != null)
				{
					if (tipoLTS == "B" || tipoLTS == "C")
						table = "LTS_BC";
					else if (tipoLTS == "A1")
						table = "LTS_A1";
					else if (tipoLTS == "A2")
						table = "LTS_A2";
				}

				if (string.IsNullOrEmpty(sortColumns))
					sortColumns = "";
				else
					sortColumns = " order by " + sortColumns;

				string g = string.Format(q, ww, sortColumns, table);

				using (OracleCommand cmd = PageQuery(cn, g, startRowIndex, maximumRows))
				{
					cmd.AddWithValue(":p_targa", targa);
					cmd.AddWithValue(":p_nazionalita", nazionalita);
					cmd.AddWithValue(":p_RicercaInizioDal", ricercaInizioDal);
					cmd.AddWithValue(":p_RicercaInizioAl", ricercaInizioAl);
					cmd.AddWithValue(":p_RicercaFineDal", ricercaFineDal);
					cmd.AddWithValue(":p_RicercaFineAl", ricercaFineAl);
					cmd.AddWithValue(":p_IdUtenteRichiedente", IdUtenteRichiedente);
					cmd.AddWithValue(":p_IdCoa", IdCoa);
					cmd.AddWithValue(":p_RicercaInseritoDal", ricercaInseritoDal);
					cmd.AddWithValue(":p_RicercaInseritoAl", ricercaInseritoAl);
					cmd.AddWithValue(":p_RicercaEmail", ricercaEmail);
					cmd.AddWithValue(":p_idCoaPerTipoC", idCoaPerTipoC);

					cmd.AddWithValue(":p_IdUtenteCollegato", IdUtenteCollegato);
					cmd.AddWithValue(":p_IdCoaDiCompetenzaUtenteColl", IdCoaDiCompetenzaUtenteCollegato);

					return RecordReader<BLLTS.LTSRecord>(cmd);
				}
			}

		}
		public int GetLTSListCount(string targa,
			string nazionalita,
			string tipoLTS,
			DateTime? ricercaInizioDal, DateTime? ricercaInizioAl,
			DateTime? ricercaFineDal, DateTime? ricercaFineAl,
			string IdUtenteRichiedente, int? IdCoa,
			DateTime? ricercaInseritoDal, DateTime? ricercaInseritoAl,
			string ricercaEmail, int? idCoaPerTipoC,
			string IdUtenteCollegato, int? IdCoaDiCompetenzaUtenteCollegato)
		{
			if (!string.IsNullOrEmpty(ricercaEmail))
			{
				tipoLTS = null;

				if (!ricercaEmail.Contains("%"))
					ricercaEmail += "%";
			}
			else
				ricercaEmail = null;

			string q = @"
select 
count(*) aaaa
FROM ITRS.LTS
where 
	((:p_targa is null) or (targa like :p_targa))
	and ((:p_nazionalita         is null) or (nazionalita like :p_nazionalita))
	and ((:p_RicercaInizioDal    is null) or (DataOraInizioValidita >= :p_RicercaInizioDal))
	and ((:p_RicercaInizioAl     is null) or (DataOraInizioValidita <= :p_RicercaInizioAl))
	and ((:p_RicercaFineDal      is null) or (DataOraFineValidita   >= :p_RicercaFineDal))
	and ((:p_RicercaFineAl       is null) or (DataOraFineValidita   <= :p_RicercaFineAl))
	and ((:p_IdUtenteRichiedente is null) or (IdUtenteRichiedente   =  :p_IdUtenteRichiedente))
	and ((:p_RicercaInseritoDal  is null) or (DataOraInserimento    >= :p_RicercaInseritoDal))
	and ((:p_RicercaInseritoAl   is null) or (DataOraInserimento    <= :p_RicercaInseritoAl))
	and ((:p_RicercaEmail        is null) or (AddrDest like :p_RicercaEmail and EnumTipoLTS = 'B'))
	and ((:p_IdCoa               is null) or (IdUtenteRichiedente in (select pkid from aspnet_userprofile where idCoaDiCompetenza = :p_IdCoa)))
	and ((:p_idCoaPerTipoC       is null) or (AddrDest = to_char(:p_idCoaPerTipoC) and EnumTipoLTS = 'C' ))
	and
	(
		(:p_IdUtenteCollegato is null) or 
		(
			(EnumTipoLTS = 'B'     and IdUtenteRichiedente = :p_IdUtenteCollegato) or
			(EnumTipoLTS = 'C'     and AddrDest = to_char(:p_IdCoaDiCompetenzaUtenteColl)) or
			(EnumTipoLTS like 'A%' )
		) 
	)
{0}
";

			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = string.Format(q, BuildWhereFromTipoLTS(tipoLTS));
					cmd.AddWithValue(":p_targa", targa);
					cmd.AddWithValue(":p_nazionalita", nazionalita);
					cmd.AddWithValue(":p_RicercaInizioDal", ricercaInizioAl);
					cmd.AddWithValue(":p_RicercaInizioAl", ricercaInizioDal);
					cmd.AddWithValue(":p_RicercaFineDal", ricercaFineAl);
					cmd.AddWithValue(":p_RicercaFineAl", ricercaFineDal);
					cmd.AddWithValue(":p_IdUtenteRichiedente", IdUtenteRichiedente);
					cmd.AddWithValue(":p_IdCoa", IdCoa);
					cmd.AddWithValue(":p_RicercaInseritoDal", ricercaInseritoDal);
					cmd.AddWithValue(":p_RicercaInseritoAl", ricercaInseritoAl);
					cmd.AddWithValue(":p_RicercaEmail", ricercaEmail);
					cmd.AddWithValue(":p_idCoaPerTipoC", idCoaPerTipoC);

					cmd.AddWithValue(":p_IdUtenteCollegato", IdUtenteCollegato);
					cmd.AddWithValue(":p_IdCoaDiCompetenzaUtenteColl", IdCoaDiCompetenzaUtenteCollegato);

					cn.Open();

					object t = cmd.ExecuteScalar();
					return Convert.ToInt32(t);
				}
			}
		}

		public List<BLLTS.UtenteRichiedente> GetListaUtentiRichiedenti()
		{
			using (OracleConnection cn = CreateConnection())
			{
				string q = @"
  select
  1                                  Num,
  'Tutti gli operatori'              UserName,
  'A'                                Chiave
  from dual

union

  select
  2                                  Num,
  'Operatori di ' || Coa.Descrizione UserName,
  'C' || COA.IdCoa                   Chiave
  from Coa

union 

  select 
  3                                                                       Num,
  U.UserName || nvl2(Coa.Descrizione, ' (' || COA.Descrizione || ')', '') UserName,
  'U' || U.PkId                                                           Chiave
  
  FROM aspnet_users U
  inner join aspnet_userprofile P
  on P.pkid = U.pkid
  
  left outer join COA
  on P.IdCoaDiCompetenza = COA.IdCoa
  
order by
Num, UserName
";
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = q;
					return RecordReader<BLLTS.UtenteRichiedente>(cmd);
				}
			}
		}

		public BLLTS.LTSRecord GetLTSFromKey(OracleConnection cn, string targa, string nazionalita, long idLts)
		{
			string q = @"
select 
Targa,
Nazionalita,
IdLts,
EnumTipoLTS,
IdUtenteRichiedente,
AspNet_users.UserName as UserNameRichiedente,
Motivo,
Note,
DataOraInserimento,
DataOraInizioValidita,
DataOraFineValidita,
EnumTipoDest,
AddrDest,
EnumLivelloPriorita

FROM ITRS.LTS
left outer join AspNet_users
on IdUtenteRichiedente = PKID
where 
	targa = :p_targa
and	nazionalita = :p_nazionalita
and IdLts = :p_idLts
";
			using (OracleCommand cmd = CreateCommand(cn))
			{
				cmd.CommandText = q;
				cmd.AddWithValue("p_targa", targa);
				cmd.AddWithValue("p_nazionalita", nazionalita);
				cmd.AddWithValue("p_idLts", idLts);

				List<BLLTS.LTSRecord> lts = RecordReader<BLLTS.LTSRecord>(cmd);
				if (lts.Count == 0)
					return null;
				return lts[0];
			}
		}

		public BLLTS.LTSRecord GetLTSFromKey(string targa, string nazionalita, long idLts)
		{
			string q = @"
select 
Targa,
Nazionalita,
IdLts,
EnumTipoLTS,
IdUtenteRichiedente,
AspNet_users.UserName as UserNameRichiedente,
Motivo,
Note,
DataOraInserimento,
DataOraInizioValidita,
DataOraFineValidita,
EnumTipoDest,
AddrDest,
EnumLivelloPriorita

FROM ITRS.LTS
left outer join AspNet_users
on IdUtenteRichiedente = PKID
where 
	targa = :p_targa
and	nazionalita = :p_nazionalita
and IdLts = :p_idLts
";
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = q;
					cmd.AddWithValue("p_targa", targa);
					cmd.AddWithValue("p_nazionalita", nazionalita);
					cmd.AddWithValue("p_idLts", idLts);

					List<BLLTS.LTSRecord> lts = RecordReader<BLLTS.LTSRecord>(cmd);
					if (lts.Count == 0)
						return null;
					return lts[0];
				}
			}
		}



		public BLLTS.LTSRecord GetLTSDiTipoC(string targa, string nazionalita, int idCoa)
		{
			string q = @"
select 
Targa,
Nazionalita,
IdLts,
EnumTipoLTS,
IdUtenteRichiedente,
AspNet_users.UserName as UserNameRichiedente,
Motivo,
Note,
DataOraInserimento,
DataOraInizioValidita,
DataOraFineValidita,
EnumTipoDest,
AddrDest,
EnumLivelloPriorita

FROM ITRS.LTS
left outer join AspNet_users
on IdUtenteRichiedente = PKID
where 
	targa = :p_targa
and	nazionalita = :p_nazionalita
and EnumTipoLTS = :p_EnumTipoLTS
and AddrDest = :p_IdCoa
";
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = q;
					cmd.AddWithValue("p_targa", targa);
					cmd.AddWithValue("p_nazionalita", nazionalita);
					cmd.AddWithValue("p_EnumTipoLTS", "C");
					cmd.AddWithValue("p_IdCoa", idCoa.ToString());

					List<BLLTS.LTSRecord> lts = RecordReader<BLLTS.LTSRecord>(cmd);
					if (lts.Count == 0)
						return null;
					return lts[0];
				}
			}
		}


		public int Delete(BLLTS.LTSRecord rec)
		{
			using (OracleConnection cn = CreateConnection())
			{

				using (OracleCommand cmd = CreateCommand(cn))
				{
					string q = @"
delete from {0} where 
targa = :p_targa
and	nazionalita = :p_nazionalita
and IdLts = :p_idLts
";

					cn.Open();
					cmd.CommandText = string.Format(q, GetLTSTable(cn, rec));

					cmd.AddWithValue(":p_targa", rec.Targa);
					cmd.AddWithValue(":p_nazionalita", rec.Nazionalita);
					cmd.AddWithValue(":p_idLts", rec.IdLTS);

					return cmd.ExecuteNonQuery();

				}
			}
		}


		private string GetLTSTable(string EnumTipoLTS)
		{
			if (EnumTipoLTS == null)
				return "LTS_BC"; // tanto quando andro` a fare la query in LTS_BC non lo trova.

			if (EnumTipoLTS == "A1")
				return "LTS_A1";

			else if (EnumTipoLTS == "A2")
				return "LTS_A2";

			return "LTS_BC";
		}


		private string GetLTSTable(OracleConnection cn, BLLTS.LTSRecord rec)
		{
			if (string.IsNullOrEmpty(rec.EnumTipoLTS))
				rec = GetLTSFromKey(cn, rec.Targa, rec.Nazionalita, rec.IdLTS);

			if (rec == null)
				return "LTS_BC"; // tanto quando andro` a fare la query in LTS_BC non lo trova.

			if (rec.EnumTipoLTS == "A1")
				return "LTS_A1";

			else if (rec.EnumTipoLTS == "A2")
				return "LTS_A2";

			return "LTS_BC";
		}

		public void Update(BLLTS.LTSRecord rec)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					string q = @"
UPDATE {0} 
SET 
	ENUMTIPOLTS           = :p_ENUMTIPOLTS, 
	IDUTENTERICHIEDENTE   = :p_IDUTENTERICHIEDENTE, 
	MOTIVO                = :p_MOTIVO, 
	NOTE                  = :p_NOTE, 
	DATAORAINSERIMENTO    = :p_DATAORAINSERIMENTO, 
	DATAORAINIZIOVALIDITA = :p_DATAORAINIZIOVALIDITA, 
	DATAORAFINEVALIDITA   = :p_DATAORAFINEVALIDITA, 
	ENUMTIPODEST          = :p_ENUMTIPODEST, 
	ADDRDEST              = :p_ADDRDEST, 
	ENUMLIVELLOPRIORITA   = :p_ENUMLIVELLOPRIORITA
WHERE
	    TARGA = :p_TARGA
	and NAZIONALITA = :p_NAZIONALITA
	and IDLTS = :p_IDLTS
";

					cn.Open();
					cmd.CommandText = string.Format(q, GetLTSTable(cn, rec));

					cmd.AddWithValue("p_TARGA", rec.Targa);
					cmd.AddWithValue("p_NAZIONALITA", rec.Nazionalita);
					cmd.AddWithValue("p_IDLTS", rec.IdLTS);
					cmd.AddWithValue("p_ENUMTIPOLTS", rec.EnumTipoLTS);
					cmd.AddWithValue("p_IDUTENTERICHIEDENTE", rec.IdUtenteRichiedente);
					cmd.AddWithValue("p_MOTIVO", rec.Motivo);
					cmd.AddWithValue("p_NOTE", rec.Note);
					cmd.AddWithValue("p_DATAORAINSERIMENTO", rec.DataOraInserimento);
					cmd.AddWithValue("p_DATAORAINIZIOVALIDITA", rec.DataOraInizioValidita);
					cmd.AddWithValue("p_DATAORAFINEVALIDITA", rec.DataOraFineValidita);
					cmd.AddWithValue("p_ENUMTIPODEST", rec.EnumTipoDest);
					cmd.AddWithValue("p_ADDRDEST", rec.AddrDest);
					cmd.AddWithValue("p_ENUMLIVELLOPRIORITA", rec.EnumLivelloPriorita);

					cmd.ExecuteNonQuery();
				}
			}
		}
		public bool Insert(BLLTS.LTSRecord rec)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					string q = @"
INSERT INTO {0}
(
TARGA, NAZIONALITA, IDLTS, ENUMTIPOLTS, 
IDUTENTERICHIEDENTE, MOTIVO, NOTE, 
DATAORAINSERIMENTO, 
DATAORAINIZIOVALIDITA, DATAORAFINEVALIDITA, 
ENUMTIPODEST, ADDRDEST, ENUMLIVELLOPRIORITA
) 
VALUES
(:p_TARGA, :p_NAZIONALITA, seq_lts.nextVal, :p_ENUMTIPOLTS, 
:p_IDUTENTERICHIEDENTE, :p_MOTIVO, :p_NOTE, 
:p_DATAORAINSERIMENTO, 
:p_DATAORAINIZIOVALIDITA, :p_DATAORAFINEVALIDITA, 
:p_ENUMTIPODEST, :p_ADDRDEST, :p_ENUMLIVELLOPRIORITA)";

					cn.Open();
					cmd.CommandText = string.Format(q, GetLTSTable(cn, rec));

					cmd.AddWithValue("p_TARGA", rec.Targa);
					cmd.AddWithValue("p_NAZIONALITA", rec.Nazionalita);
					cmd.AddWithValue("p_ENUMTIPOLTS", rec.EnumTipoLTS);
					cmd.AddWithValue("p_IDUTENTERICHIEDENTE", rec.IdUtenteRichiedente);
					cmd.AddWithValue("p_MOTIVO", rec.Motivo);
					cmd.AddWithValue("p_NOTE", rec.Note);
					cmd.AddWithValue("p_DATAORAINSERIMENTO", rec.DataOraInserimento);
					cmd.AddWithValue("p_DATAORAINIZIOVALIDITA", rec.DataOraInizioValidita);
					cmd.AddWithValue("p_DATAORAFINEVALIDITA", rec.DataOraFineValidita);
					cmd.AddWithValue("p_ENUMTIPODEST", rec.EnumTipoDest);
					cmd.AddWithValue("p_ADDRDEST", rec.AddrDest);
					cmd.AddWithValue("p_ENUMLIVELLOPRIORITA", rec.EnumLivelloPriorita);

					try
					{
						cmd.ExecuteNonQuery();
					}
					catch (OracleException ex)
					{
						if (ex.Number == 1)
							return false;
						throw ex;
					}
				}
			}

			return true;
		}


//        public int GetNumberOfLTSFromTarga(string targa, string nazionalita, DateTime validoIl)
//        {
//            string q = @"
//select 
//count(*) aaaa
//FROM ITRS.LTS
//where 
//targa = :p_targa and
//nazionalita = :p_nazionalita and
//dataOraInizioValidita <= :p_data and dataOraFineValidita >= :p_data
//";

//            using (OracleConnection cn = CreateConnection())
//            {

//                using (OracleCommand cmd = CreateCommand(cn))
//                {
//                    cmd.CommandText = q;
//                    cmd.AddWithValue("p_targa", targa);
//                    cmd.AddWithValue("p_nazionalita", nazionalita);
//                    cmd.AddWithValue("p_data", validoIl);
//                    cn.Open();

//                    object t = cmd.ExecuteScalar();
//                    return Convert.ToInt32(t);
//                }
//            }
//        }

		public DateTime? GetMaxDataFineValidita(string targa, string nazionalita, DateTime validoIl, bool ignoraA2)
		{
			string q = @"
select 
max(DataOraFineValidita) maxDataFineValidita
FROM ITRS.LTS
where 
targa = :p_targa 
and nazionalita = :p_nazionalita 
and dataOraInizioValidita <= :p_data 
and dataOraFineValidita >= :p_data
{0}
";

			using (OracleConnection cn = CreateConnection())
			{

				using (OracleCommand cmd = CreateCommand(cn))
				{
					if (ignoraA2)
						cmd.CommandText = U.F(q, "and EnumTipoLTS <> 'A2' ");
					else
						cmd.CommandText = U.F(q, "");

					cmd.AddWithValue("p_targa", targa);
					cmd.AddWithValue("p_nazionalita", nazionalita);
					cmd.AddWithValue("p_data", validoIl);

					cn.Open();

					DateTime? maxDataFineValidita = null;

					using (OracleDataReader rd = cmd.ExecuteReader())
					{
						if (rd.Read())
						{
							object b = rd[0];

							if (!(b == null || b == DBNull.Value))
								maxDataFineValidita = (DateTime)b;
						}

						return maxDataFineValidita;
					}
				}
			}
		}

		public List<string> GetListaQmgr()
		{
			List<MWPC2PInfo> r = GetListC2P();

			List<string> Qmgr = new List<string>();
			foreach (MWPC2PInfo ci in r)
				Qmgr.Add(ci.QmgrName);

			return Qmgr;
		}

		public List<MWPC2PInfo> GetListC2P()
		{
			string q = @"
    SELECT
    c2p.QMGR_NAME           as QmgrName,
    c2p.DATAORARILEVAMENTO  as DataOraRilevamento
    from C2P
";

			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = q;
					return RecordReader<MWPC2PInfo>(cmd);
				}
			}
		}
		public List<MWPC2PInfo> GetListC2P(int idC2P)
		{
			string q = @"
    SELECT
    c2p.QMGR_NAME           as QmgrName,
    c2p.DATAORARILEVAMENTO  as DataOraRilevamento
    from C2P
	where IdC2P = :p_IdC2P
";

			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = q;
					cmd.AddWithValue("p_IdC2P", idC2P);
					return RecordReader<MWPC2PInfo>(cmd);
				}
			}
		}


		/// <summary>
		/// Trovo le entry nella LTS valide (ossia con data di inizio/fine validita` compresa in validoIl)
		/// e ritorno il max della DataOraFineValidita
		/// </summary>
		/// <param name="validoIl"></param>
		/// <returns></returns>
		public IEnumerable<MWPDataLTS> UpdateC2PfromLTS(DateTime validoIl, bool ignoraA2)
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					string q = @"
select 
targa, nazionalita, max(DataOraFineValidita) DataOraFineValidita
from LTS
where 
    DataOraInizioValidita <= :p_validoIl 
and DataOraFineValidita   >= :p_validoIl
{0}
group by targa, nazionalita
";
					cmd.CommandTimeout = ReadAppSettings.ToInt32("UpdateC2PfromLTS.OracleCommand.CommandTimeout", 600);

					List<MWPDataLTS> r = new List<MWPDataLTS>();

					cn.Open();

					cmd.AddWithValue(":p_validoIl", validoIl);

					if (ignoraA2)
						cmd.CommandText = U.F(q, "and EnumTipoLTS <> 'A2' ");
					else
						cmd.CommandText = U.F(q, "");

					using (OracleDataReader rd = cmd.ExecuteReader())
					{

						while (rd.Read())
						{
							MWPDataLTS e=new MWPDataLTS();
							e.targa = (string)rd[0];
							e.nazionalita = (string)rd[1];
							e.AddCommand = true;
							e.dataOraInizio = validoIl;
							e.dataOraFine = (DateTime)rd[2];

							yield return e;
						}
					}
				}
			}
		}



		public IEnumerable<MWPDataLTS_A2> UpdateC2PfromLTS_A2()
		{
			using (OracleConnection cn = CreateConnection())
			{
				using (OracleCommand cmd = CreateCommand(cn))
				{
					string q = @"
select 
Targa, 
Nazionalita, 
DataOraInizioValidita DataRevisione, 
Tab_Tipo_Veicolo      TipoVeicolo
from LTS_A2
";
					cmd.CommandTimeout = ReadAppSettings.ToInt32("UpdateC2PfromLTS.OracleCommand.CommandTimeout", 600);
					cmd.CommandText = q;

					foreach (MWPDataLTS_A2 r in ReadRecord<MWPDataLTS_A2>(cmd))
						yield return r;
				}
			}
		}


		/// <summary>
		/// Scarica la lista della LTS per il tipo e per il COA selezionato
		/// </summary>
		/// <param name="tipoLTS"></param>
		/// <param name="IdC2P"></param>
		/// <returns></returns>
		public List<BLLTS.LTSRecord> GetLTSForExportTipoC(int IdCOA, DateTime validoAl)
		{
			using (OracleConnection cn = CreateConnection())
			{
				string q = @"
select 
Targa,
Nazionalita,
EnumTipoLTS,
IdUtenteRichiedente,
AspNet_users.UserName as UserNameRichiedente,
Motivo,
Note,
DataOraInserimento,
DataOraInizioValidita,
DataOraFineValidita,
EnumTipoDest,
AddrDest,
EnumLivelloPriorita

FROM ITRS.LTS
left outer join AspNet_users
on IdUtenteRichiedente = PKID
where 
	    (EnumTipoLTS = 'C')
	and (AddrDest = to_char(:p_IdCoa))
	and (dataOraInizioValidita <= :p_validoAl and dataOraFineValidita >= :p_validoAl)

order by
targa, nazionalita
";
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = q;
					cmd.AddWithValue(":p_IdCoa", IdCOA);
					cmd.AddWithValue(":p_validoAl", validoAl);

					return RecordReader<BLLTS.LTSRecord>(cmd);
				}
			}
		}



		public List<MWPDataLTS> GetEntryLTSScadute()
		{
			using (OracleConnection cn = CreateConnection())
			{
				string q = @"
select 
EnumTipoLTS                       EnumTipoLTS,
targa                             Targa, 
nazionalita                       Nazionalita, 
max(DATAORAFINEVALIDITA)          DataOraFine,
to_date('2000 1 1', 'YYYY MM DD') DataOraInizio,
'false'                           AddCommand
from lts
group by targa, nazionalita, EnumTipoLTS
having max(DATAORAFINEVALIDITA) < sysdate
";
				using (OracleCommand cmd = CreateCommand(cn))
				{
					cmd.CommandText = q;

					return RecordReader<MWPDataLTS>(cmd);
				}
			}
		}

		public void CancellaEntryLTSScadute(List<MWPDataLTS> e)
		{
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				foreach (MWPDataLTS rec in e)
				{
					// cancello considerando la data cosi` anche se non opero in transazione
					// non cancello record eventualemente inseriti nel frattempo

					string q = @"
delete from {0} 
where targa = :p_targa
and   nazionalita = :p_nazionalita
and   DATAORAFINEVALIDITA <= :p_dataorafinevalidita
";
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, GetLTSTable(rec.enumTipoLTS));

						cmd.AddWithValue(":p_targa", rec.targa);
						cmd.AddWithValue(":p_nazionalita", rec.nazionalita);
						cmd.AddWithValue(":p_dataorafinevalidita", rec.dataOraFine);

						cmd.ExecuteNonQuery();
					}
				}
			}
		}


		public bool UltimaCancellazioneLTSEseguita()
		{
			using (OracleConnection cn = CreateConnection())
			{
				cn.Open();

				using (OracleTransaction tr = cn.BeginTransaction())
				{
					bool ret;

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = "select ULTIMACANCELLAZIONE from LTS_DATA where id=0 for update";

						object t = cmd.ExecuteScalar();
						if (t == null)
						{
							cmd.Parameters.Clear();
							cmd.CommandText = "INSERT INTO ITRS.LTS_DATA(ID, ULTIMACANCELLAZIONE) VALUES(0, :pNow)";
							cmd.AddWithValue(":pNow", DateTime.Now.Date);
							try
							{
								cmd.ExecuteNonQuery();
								ret = false;  // ho inserito --> devo fare la cancellazione
							}
							catch (OracleException orex)
							{
								if (orex.Number == 1)
								{
									// caso piu` unico che raro: tra la select e l'insert e` arrivato prima un'altro
									ret = true;
								}
								else throw;
							}
						}
						else
						{
							DateTime ultimaCancellazione = (DateTime)t;

							if (ultimaCancellazione.Date == DateTime.Now.Date)
								ret = true; // la cancellazione e` stata gia` fatta
							else
							{
								cmd.Parameters.Clear();
								cmd.CommandText = "update ITRS.LTS_DATA set ULTIMACANCELLAZIONE = :pNow where Id=0";
								cmd.AddWithValue(":pNow", DateTime.Now.Date);
								cmd.ExecuteNonQuery();

								ret = false; // devo fare la cancellazione
							}
						}
					}

					tr.Commit();
					return ret;
				}
			}
		}

	}
}

