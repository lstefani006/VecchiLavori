using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

namespace ITRS_BL.Oracle
{
	public class DalSegnalazioni : DalBase, IDalSegnalazioni
	{
		public List<BLSegnalazioni.Segnalazione> GetSegnalazioniSuEvento(string Targa, string Nazionalita, DateTime DataOraInserimento, int IdEvento, string columnsSort)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = @"
select 
S.Targa,
S.Nazionalita,
S.DATAORAINSERIMENTO,
S.IdEvento,
S.PROGRESSIVOSEGNALAZIONE,
S.ENUMTIPOLTS as TIPOLTS,
U.UserName    as UTENTERICHIEDENTE,
S.MOTIVO      as Motivo,
S.Note        as Note,
S.DATAORAINIZIOVALIDITA,
S.DATAORAFINEVALIDITA,
S.ENUMTIPODEST as TipoDest,
S.ADDRDEST,
S.ENUMLIVELLOPRIORITA as LIVELLOPRIORITA

from Segnalazioni S
inner join AspNet_users U

on (S.IDUTENTERICHIEDENTE = U.PKID or S.IDUTENTERICHIEDENTE = U.USERNAME)
where S.Targa = :t
and   S.Nazionalita = :n
and   S.DATAORAINSERIMENTO = :d
and   S.IdEvento = :i
";
					cmd.CommandText += " order by " + columnsSort;

					cmd.AddWithValue(":t", Targa);
					cmd.AddWithValue(":n", Nazionalita);
					cmd.AddWithValue(":d", DataOraInserimento);
					cmd.AddWithValue(":i", IdEvento);

					return this.RecordReader<BLSegnalazioni.Segnalazione>(cmd);
				}
			}
		}

		#region IDalSegnalazioni Members


		public BLSegnalazioni.Segnalazione GetSegnalazione(string Targa, string Nazionalita, DateTime DataOraInserimento, int IdEvento, int progressivoSegnalazione)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandType = CommandType.Text;
					cmd.CommandText = @"
select 
S.Targa,
S.Nazionalita,
S.DATAORAINSERIMENTO,
S.IdEvento,
S.PROGRESSIVOSEGNALAZIONE,
S.ENUMTIPOLTS as TIPOLTS,
U.UserName    as UTENTERICHIEDENTE,
S.MOTIVO      as Motivo,
S.Note        as Note,
S.DATAORAINIZIOVALIDITA,
S.DATAORAFINEVALIDITA,
S.ENUMTIPODEST as TipoDest,
S.ADDRDEST,
S.ENUMLIVELLOPRIORITA as LIVELLOPRIORITA

from Segnalazioni S
inner join AspNet_users U
on (S.IDUTENTERICHIEDENTE = U.PKID or S.IDUTENTERICHIEDENTE = U.USERNAME)
where S.Targa = :t
and   S.Nazionalita = :n
and   S.DATAORAINSERIMENTO = :d
and   S.IdEvento = :i
and   S.PROGRESSIVOSEGNALAZIONE = :p
";
					cmd.AddWithValue(":t", Targa);
					cmd.AddWithValue(":n", Nazionalita);
					cmd.AddWithValue(":d", DataOraInserimento);
					cmd.AddWithValue(":i", IdEvento);
					cmd.AddWithValue(":p", progressivoSegnalazione);

					List<BLSegnalazioni.Segnalazione> r = this.RecordReader<BLSegnalazioni.Segnalazione>(cmd);
					if (r.Count == 0)
						return null;
					return r[0];
				}
			}
		}

		#endregion
	}
}
