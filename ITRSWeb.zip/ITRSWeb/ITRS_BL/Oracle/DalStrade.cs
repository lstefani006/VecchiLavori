using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using Oracle.DataAccess.Client;
#else
#endif

namespace ITRS_BL.Oracle
{
	class DalStrada : DalBase, IDalStrada
	{
		#region IDalStrada Members
		public List<Strada> GetLista(string columnsSort)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT CODICESTRADA, 
												DESCRIZIONESTRADA 
												FROM STRADE order by " + columnsSort;
					cmd.CommandType = CommandType.Text;

					int colCODICESTRADA = -1;
					int colDESCRIZIONESTRADA = -1;

					RecordColumnBinder<Strada> rcb = delegate(OracleDataReader rd)
					{
						colCODICESTRADA = rd.GetOrdinal("CODICESTRADA");
						colDESCRIZIONESTRADA = rd.GetOrdinal("DESCRIZIONESTRADA");
					};

					RecordBinder<Strada> rt = delegate(OracleDataReader rd, Strada t)
					{
						t.CodiceStrada = rd.GetString(colCODICESTRADA);
						t.Descrizione = rd.GetString(colDESCRIZIONESTRADA);
					};

					cn.Open();
					return this.RecordReader<Strada>(cmd, rt, rcb);
				}
			}
		}



		public Strada GetRecord(Strada t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"SELECT CODICESTRADA, 
										DESCRIZIONESTRADA 
										FROM STRADE where ";
					q += "CODICESTRADA = :P_CODICESTRADA";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					int colCODICESTRADA = -1;
					int colDESCRIZIONESTRADA = -1;

					cmd.AddWithValue("P_CODICESTRADA", t.CodiceStrada);

					RecordColumnBinder<Strada> rcb = delegate(OracleDataReader rd)
					{
						colCODICESTRADA = rd.GetOrdinal("CODICESTRADA");
						colDESCRIZIONESTRADA = rd.GetOrdinal("DESCRIZIONESTRADA");
					};

					RecordBinder<Strada> rt = delegate(OracleDataReader rd, Strada tb)
					{
						tb.CodiceStrada = rd.GetString(colCODICESTRADA);
						tb.Descrizione = rd.GetString(colDESCRIZIONESTRADA);
					};

					List<Strada> r = this.RecordReader<Strada>(cmd, rt, rcb);
					if (r.Count == 0) return null;
					return r[0];
				}
			}
		}

		public void Cancella(Strada t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"DELETE from STRADE where ";
					q += "CODICESTRADA = :P_CODICESTRADA";
					cmd.CommandText = q;
					cmd.CommandType = CommandType.Text;

					cmd.AddWithValue("P_CODICESTRADA", t.CodiceStrada);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Aggiorna(Strada t)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					string q = @"UPDATE STRADE SET ";
					q += "DESCRIZIONESTRADA = :P_DESCRIZIONESTRADA";
					q += " WHERE ";

					q += "CODICESTRADA = :P_CODICESTRADA";
					cmd.CommandText = q;

					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DESCRIZIONESTRADA", t.Descrizione);
					cmd.AddWithValue("P_CODICESTRADA", t.CodiceStrada);

					cn.Open();
					cmd.ExecuteNonQuery();
				}
			}
		}

		public void Inserisci(Strada t)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						string q = "INSERT INTO STRADE (";
						q += "CODICESTRADA";
						q += ", DESCRIZIONESTRADA";
						q += ") VALUES (";
						q += ":P_CODICESTRADA";
						q += ", :P_DESCRIZIONESTRADA";
						q += ")";

						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;

						cmd.AddWithValue("P_CODICESTRADA", t.CodiceStrada);
						cmd.AddWithValue("P_DESCRIZIONESTRADA", t.Descrizione);

						cn.Open();
						cmd.ExecuteNonQuery();
					}
				}
			}
			catch (OracleException ex)
			{
				if (ex.Number == 1)
					throw new ApplicationException("Record gia` presente", ex);
				else
					throw;
			}
		}

		#endregion
	}
}
