using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using ITRS_BL.IDal;
using ITRS_BL.Utility;

#if ODP
using Oracle.DataAccess.Client;
#else
using System.Data.OracleClient;
#endif

namespace ITRS_BL.Oracle
{
	class DalStatistiche : DalBase, IDalStatistiche
	{
		#region IDalStatistiche Members

		public int GetTempiEtVelocitaSuTrattaCount(DateTime data)
		{
			try
			{
				string q = "select count(*) from TEMPI_VELOC_PERCORR_TRATTA where DATA_REP = :P_DATA_REP" ;

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);

						return (int)cmd.ExecuteScalar<decimal>();
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("DalStatistiche.GetTempiEtVelocitaSuTrattaCount", ex);
			}
		}

        public int GetTempiEtVelocitaSuTrattaCount(DateTime data, int idTratta)
        {
            try
            {
                string q = "select count(*) from TEMPI_VELOC_PERCORR_TRATTA where DATA_REP = :P_DATA_REP and TRATTA_ID = :P_IDTRATTA";

                using (OracleConnection cn = this.CreateConnection())
                {
                    using (OracleCommand cmd = CreateCommand(cn))
                    {
                        cmd.CommandTimeout = 1000;
                        cmd.CommandText = q;
                        cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);
						cmd.AddWithValue("P_IDTRATTA", idTratta);

						return (int)cmd.ExecuteScalar<decimal>();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("DalStatistiche.GetTempiEtVelocitaSuTrattaCount", ex);
            }
        }

		public List<BLStatistiche.TempiEtVelocitaSuTratta> GetTempiEtVelocitaSuTratta(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT TEMPI_VELOC_PERCORR_TRATTA.DATA_REP, 
												TEMPI_VELOC_PERCORR_TRATTA.ORA_DA, 
												TEMPI_VELOC_PERCORR_TRATTA.ORA_A, 
												TEMPI_VELOC_PERCORR_TRATTA.STRADA, 
												TEMPI_VELOC_PERCORR_TRATTA.DIREZIONE, 
												TEMPI_VELOC_PERCORR_TRATTA.TRATTA_ID, 
												TRATTE.DESCRIZIONE DESCRTRATTA,
												TEMPI_VELOC_PERCORR_TRATTA.TEMPO_PERCORR_MEDIO,
												TEMPI_VELOC_PERCORR_TRATTA.VEL_PERCORR_MEDIA,
												TEMPI_VELOC_PERCORR_TRATTA.NUMERO_VEICOLI
												FROM TEMPI_VELOC_PERCORR_TRATTA 
												INNER JOIN TRATTE ON
												TRATTE.IDTRATTA = TEMPI_VELOC_PERCORR_TRATTA.TRATTA_ID
												where DATA_REP = :P_DATA_REP order by " + sortColumns;
					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);

					this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					int colDATA_REP = -1;
					int colORA_DA = -1;
					int colORA_A = -1;
					int colSTRADA = -1;
					int colDIREZIONE = -1;
					int colTRATTA_ID = -1;
					int colDESCRTRATTA = -1;
					int colTEMPO_PERCORR_MEDIO = -1;
					int colVEL_PERCORR_MEDIA = -1;
					int colNUMERO_VEICOLI = -1;

					RecordColumnBinder<BLStatistiche.TempiEtVelocitaSuTratta> rcb = delegate(OracleDataReader rd)
					{
						colDATA_REP = rd.GetOrdinal("DATA_REP");
						colORA_DA = rd.GetOrdinal("ORA_DA");
						colORA_A = rd.GetOrdinal("ORA_A");
						colSTRADA = rd.GetOrdinal("STRADA");
						colDIREZIONE = rd.GetOrdinal("DIREZIONE");
						colTRATTA_ID = rd.GetOrdinal("TRATTA_ID");
						colDESCRTRATTA = rd.GetOrdinal("DESCRTRATTA");
						colTEMPO_PERCORR_MEDIO = rd.GetOrdinal("TEMPO_PERCORR_MEDIO");
						colVEL_PERCORR_MEDIA = rd.GetOrdinal("VEL_PERCORR_MEDIA");
						colNUMERO_VEICOLI = rd.GetOrdinal("NUMERO_VEICOLI");
					};

					RecordBinder<BLStatistiche.TempiEtVelocitaSuTratta> rt = delegate(OracleDataReader rd, BLStatistiche.TempiEtVelocitaSuTratta t)
					{
						t.DataRep = rd.GetDateTime(colDATA_REP);
						t.OraDa = int.Parse(rd.GetString(colORA_DA));
						t.OraA = int.Parse(rd.GetString(colORA_A));
						t.Strada = rd.GetString(colSTRADA);
						t.Direzione = rd.GetString(colDIREZIONE);

						if (rd.IsDBNull(colDESCRTRATTA))
							t.DescrizioneTratta = null;
						else
							t.DescrizioneTratta = rd.GetString(colDESCRTRATTA);

						t.TempoPercorrenzaSecondi = (int)rd.GetDecimal(colTEMPO_PERCORR_MEDIO);
						t.Velocita = rd.GetDecimal(colVEL_PERCORR_MEDIA);

						if (rd.IsDBNull(colNUMERO_VEICOLI))
							t.NumeroVeicoli = null;
						else
							t.NumeroVeicoli = (int)rd.GetDecimal(colNUMERO_VEICOLI);
					};

					cn.Open();
					return this.RecordReader<BLStatistiche.TempiEtVelocitaSuTratta>(cmd, rt, rcb);
				}
			}
		}

        public List<BLStatistiche.TempiEtVelocitaSuTratta> GetTempiEtVelocitaSuTratta(DateTime data, int idTratta, string sortColumns, int startRowIndex, int maximumRows)
        {

            using (OracleConnection cn = this.CreateConnection())
            {
                using (OracleCommand cmd = this.CreateCommand(cn))
                {
                    cmd.CommandText = @"SELECT TEMPI_VELOC_PERCORR_TRATTA.DATA_REP, 
												TEMPI_VELOC_PERCORR_TRATTA.ORA_DA, 
												TEMPI_VELOC_PERCORR_TRATTA.ORA_A, 
												TEMPI_VELOC_PERCORR_TRATTA.STRADA, 
												TEMPI_VELOC_PERCORR_TRATTA.DIREZIONE, 
												TEMPI_VELOC_PERCORR_TRATTA.TRATTA_ID, 
												TRATTE.DESCRIZIONE DESCRTRATTA,
												TEMPI_VELOC_PERCORR_TRATTA.TEMPO_PERCORR_MEDIO,
												TEMPI_VELOC_PERCORR_TRATTA.VEL_PERCORR_MEDIA,
												TEMPI_VELOC_PERCORR_TRATTA.NUMERO_VEICOLI
												FROM TEMPI_VELOC_PERCORR_TRATTA 
												INNER JOIN TRATTE ON
												TRATTE.IDTRATTA = TEMPI_VELOC_PERCORR_TRATTA.TRATTA_ID
												where DATA_REP = :P_DATA_REP and 
                                                TRATTA_ID = :P_IDTRATTA
                                                order by " + sortColumns;
                    cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);
					cmd.AddWithValue("P_IDTRATTA", idTratta);

                    this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

                    int colDATA_REP = -1;
                    int colORA_DA = -1;
                    int colORA_A = -1;
                    int colSTRADA = -1;
                    int colDIREZIONE = -1;
                    int colTRATTA_ID = -1;
                    int colDESCRTRATTA = -1;
                    int colTEMPO_PERCORR_MEDIO = -1;
					int colVEL_PERCORR_MEDIA = -1;
					int colNUMERO_VEICOLI = -1;

                    RecordColumnBinder<BLStatistiche.TempiEtVelocitaSuTratta> rcb = delegate(OracleDataReader rd)
                    {
                        colDATA_REP = rd.GetOrdinal("DATA_REP");
                        colORA_DA = rd.GetOrdinal("ORA_DA");
                        colORA_A = rd.GetOrdinal("ORA_A");
                        colSTRADA = rd.GetOrdinal("STRADA");
                        colDIREZIONE = rd.GetOrdinal("DIREZIONE");
                        colTRATTA_ID = rd.GetOrdinal("TRATTA_ID");
                        colDESCRTRATTA = rd.GetOrdinal("DESCRTRATTA");
                        colTEMPO_PERCORR_MEDIO = rd.GetOrdinal("TEMPO_PERCORR_MEDIO");
						colVEL_PERCORR_MEDIA = rd.GetOrdinal("VEL_PERCORR_MEDIA");
						colNUMERO_VEICOLI = rd.GetOrdinal("NUMERO_VEICOLI");
					};

                    RecordBinder<BLStatistiche.TempiEtVelocitaSuTratta> rt = delegate(OracleDataReader rd, BLStatistiche.TempiEtVelocitaSuTratta t)
                    {
                        t.DataRep = rd.GetDateTime(colDATA_REP);
                        t.OraDa = int.Parse(rd.GetString(colORA_DA));
                        t.OraA = int.Parse(rd.GetString(colORA_A));
                        t.Strada = rd.GetString(colSTRADA);
                        t.Direzione = rd.GetString(colDIREZIONE);

                        if (rd.IsDBNull(colDESCRTRATTA))
                            t.DescrizioneTratta = null;
                        else
                            t.DescrizioneTratta = rd.GetString(colDESCRTRATTA);

                        t.TempoPercorrenzaSecondi = (int)rd.GetDecimal(colTEMPO_PERCORR_MEDIO);
						t.Velocita = rd.GetDecimal(colVEL_PERCORR_MEDIA);

						if (rd.IsDBNull(colNUMERO_VEICOLI))
							t.NumeroVeicoli = null;
						else
							t.NumeroVeicoli = (int)rd.GetDecimal(colNUMERO_VEICOLI);
					};

                    cn.Open();
                    return this.RecordReader<BLStatistiche.TempiEtVelocitaSuTratta>(cmd, rt, rcb);
                }
            }
        }

		public int GetVolumeTrafficoTrattaCount(DateTime data)
		{
			try
			{
				string q = "select count(*) from VOL_TRAFF_TRATTA where DATA_REP = :P_DATA_REP";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);

						return (int)cmd.ExecuteScalar<decimal>();
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("DalStatistiche.GetVolumeTrafficoTrattaCount", ex);
			}
		}

		public List<BLStatistiche.VolumeTrafficoTratta> GetVolumeTrafficoTratta(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT VOL_TRAFF_TRATTA.DATA_REP, 
												VOL_TRAFF_TRATTA.ORA_DA, 
												VOL_TRAFF_TRATTA.ORA_A, 
												VOL_TRAFF_TRATTA.C2P, 
												VOL_TRAFF_TRATTA.C_TRANS, 
												C2P.DESCRIZIONE DESCRC2P
												FROM VOL_TRAFF_TRATTA 
												INNER JOIN C2P ON
												C2P.IDC2P = VOL_TRAFF_TRATTA.C2P
												where DATA_REP = :P_DATA_REP order by " + sortColumns;
					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);

					this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					int colDATA_REP = -1;
					int colORA_DA = -1;
					int colORA_A = -1;
					int colC2P = -1;
					int colC_TRANS = -1;
					int colDESCRC2P = -1;

					RecordColumnBinder<BLStatistiche.VolumeTrafficoTratta> rcb = delegate(OracleDataReader rd)
					{
						colDATA_REP = rd.GetOrdinal("DATA_REP");
						colORA_DA = rd.GetOrdinal("ORA_DA");
						colORA_A = rd.GetOrdinal("ORA_A");
						colC2P = rd.GetOrdinal("C2P");
						colC_TRANS = rd.GetOrdinal("C_TRANS");
						colDESCRC2P = rd.GetOrdinal("DESCRC2P");
					};

					RecordBinder<BLStatistiche.VolumeTrafficoTratta> rt = delegate(OracleDataReader rd, BLStatistiche.VolumeTrafficoTratta t)
					{
						t.DataRep = rd.GetDateTime(colDATA_REP);
						t.OraDa = int.Parse(rd.GetString(colORA_DA));
						t.OraA = int.Parse(rd.GetString(colORA_A));
						t.C2P = (int)rd.GetDouble(colC2P);
						t.C_Trans = (int)rd.GetDecimal(colC_TRANS);
						t.DescrizioneC2P = rd.GetString(colDESCRC2P);
					};

					cn.Open();
					return this.RecordReader<BLStatistiche.VolumeTrafficoTratta>(cmd, rt, rcb);
				}
			}
		}

        public int GetVolumeTrafficoTrattaCount(DateTime data, int idC2P)
        {
            try
            {
                string q = "select count(*) from VOL_TRAFF_TRATTA where DATA_REP = :P_DATA_REP and C2P = :P_IDC2P";

                using (OracleConnection cn = this.CreateConnection())
                {
                    using (OracleCommand cmd = CreateCommand(cn))
                    {
                        cmd.CommandTimeout = 1000;
                        cmd.CommandText = q;
                        cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);
						cmd.AddWithValue("P_IDC2P", idC2P);

						return (int)cmd.ExecuteScalar<decimal>();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("DalStatistiche.GetVolumeTrafficoTrattaCount", ex);
            }
        }

        public List<BLStatistiche.VolumeTrafficoTratta> GetVolumeTrafficoTratta(DateTime data, int idC2P, string sortColumns, int startRowIndex, int maximumRows)
        {

            using (OracleConnection cn = this.CreateConnection())
            {
                using (OracleCommand cmd = this.CreateCommand(cn))
                {
                    cmd.CommandText = @"SELECT VOL_TRAFF_TRATTA.DATA_REP, 
												VOL_TRAFF_TRATTA.ORA_DA, 
												VOL_TRAFF_TRATTA.ORA_A, 
												VOL_TRAFF_TRATTA.C2P, 
												VOL_TRAFF_TRATTA.C_TRANS, 
												C2P.DESCRIZIONE DESCRC2P
												FROM VOL_TRAFF_TRATTA 
												INNER JOIN C2P ON
												C2P.IDC2P = VOL_TRAFF_TRATTA.C2P
												where DATA_REP = :P_DATA_REP and 
                                                C2P = :P_C2P
                                                order by " + sortColumns;
                    cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);
					cmd.AddWithValue("P_C2P", idC2P);

                    this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

                    int colDATA_REP = -1;
                    int colORA_DA = -1;
                    int colORA_A = -1;
                    int colC2P = -1;
                    int colC_TRANS = -1;
                    int colDESCRC2P = -1;

                    RecordColumnBinder<BLStatistiche.VolumeTrafficoTratta> rcb = delegate(OracleDataReader rd)
                    {
                        colDATA_REP = rd.GetOrdinal("DATA_REP");
                        colORA_DA = rd.GetOrdinal("ORA_DA");
                        colORA_A = rd.GetOrdinal("ORA_A");
                        colC2P = rd.GetOrdinal("C2P");
                        colC_TRANS = rd.GetOrdinal("C_TRANS");
                        colDESCRC2P = rd.GetOrdinal("DESCRC2P");
                    };

                    RecordBinder<BLStatistiche.VolumeTrafficoTratta> rt = delegate(OracleDataReader rd, BLStatistiche.VolumeTrafficoTratta t)
                    {
                        t.DataRep = rd.GetDateTime(colDATA_REP);
                        t.OraDa = int.Parse(rd.GetString(colORA_DA));
                        t.OraA = int.Parse(rd.GetString(colORA_A));
                        t.C2P = (int)rd.GetDouble(colC2P);
                        t.C_Trans = (int)rd.GetDecimal(colC_TRANS);
                        t.DescrizioneC2P = rd.GetString(colDESCRC2P);
                    };

                    cn.Open();
                    return this.RecordReader<BLStatistiche.VolumeTrafficoTratta>(cmd, rt, rcb);
                }
            }
        }

		public int GetTempiEtVelocitaPerDirezioneCount(DateTime data)
		{
			try
			{
				string q = "select count(*) from TEMPI_VELOC_PERCORR_DIREZ where DATA_REP = :P_DATA_REP";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);

						return (int)cmd.ExecuteScalar<decimal>();
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("DalStatistiche.GetTempiEtVelocitaPerDirezioneCount", ex);
			}
		}

		public List<BLStatistiche.TempiEtVelocitaPerDirezione> GetTempiEtVelocitaPerDirezione(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT DATA_REP, 
												ORA_DA, 
												ORA_A, 
												STRADA, 
												DIREZIONE, 
												TEMPO_PERCORR_MEDIO,
												VEL_PERCORR_MEDIA,
												NUMERO_VEICOLI
												FROM TEMPI_VELOC_PERCORR_DIREZ 
												where DATA_REP = :P_DATA_REP order by " + sortColumns;
					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);

					this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					int colDATA_REP = -1;
					int colORA_DA = -1;
					int colORA_A = -1;
					int colSTRADA = -1;
					int colDIREZIONE = -1;
					int colTEMPO_PERCORR_MEDIO = -1;
					int colVEL_PERCORR_MEDIA = -1;
					int colNUMERO_VEICOLI = -1;

					RecordColumnBinder<BLStatistiche.TempiEtVelocitaPerDirezione> rcb = delegate(OracleDataReader rd)
					{
						colDATA_REP = rd.GetOrdinal("DATA_REP");
						colORA_DA = rd.GetOrdinal("ORA_DA");
						colORA_A = rd.GetOrdinal("ORA_A");
						colSTRADA = rd.GetOrdinal("STRADA");
						colDIREZIONE = rd.GetOrdinal("DIREZIONE");
						colTEMPO_PERCORR_MEDIO = rd.GetOrdinal("TEMPO_PERCORR_MEDIO");
						colVEL_PERCORR_MEDIA = rd.GetOrdinal("VEL_PERCORR_MEDIA");
						colNUMERO_VEICOLI = rd.GetOrdinal("NUMERO_VEICOLI");
					};

					RecordBinder<BLStatistiche.TempiEtVelocitaPerDirezione> rt = delegate(OracleDataReader rd, BLStatistiche.TempiEtVelocitaPerDirezione t)
					{
						t.DataRep = rd.GetDateTime(colDATA_REP);
						t.OraDa = int.Parse(rd.GetString(colORA_DA));
						t.OraA = int.Parse(rd.GetString(colORA_A));
						t.Strada = rd.GetString(colSTRADA);
						t.Direzione = rd.GetString(colDIREZIONE);
						t.TempoPercorrenzaSecondi = (int)rd.GetDecimal(colTEMPO_PERCORR_MEDIO);
						t.Velocita = rd.GetDecimal(colVEL_PERCORR_MEDIA);
						if (rd.IsDBNull(colNUMERO_VEICOLI))
							t.NumeroVeicoli = null;
						else
							t.NumeroVeicoli = (int)rd.GetDecimal(colNUMERO_VEICOLI);
					};

					cn.Open();
					return this.RecordReader<BLStatistiche.TempiEtVelocitaPerDirezione>(cmd, rt, rcb);
				}
			}
		}

        public int GetTempiEtVelocitaPerDirezioneCount(DateTime data, string direzione)
        {
            try
            {
                string q = "select count(*) from TEMPI_VELOC_PERCORR_DIREZ where DATA_REP = :P_DATA_REP and DIREZIONE = :P_DIREZIONE";

                using (OracleConnection cn = this.CreateConnection())
                {
                    using (OracleCommand cmd = CreateCommand(cn))
                    {
                        cmd.CommandTimeout = 1000;
                        cmd.CommandText = q;
                        cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);
						cmd.AddWithValue("P_DIREZIONE", direzione);

						return (int)cmd.ExecuteScalar<decimal>();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("DalStatistiche.GetTempiEtVelocitaPerDirezioneCount", ex);
            }
        }

        public List<BLStatistiche.TempiEtVelocitaPerDirezione> GetTempiEtVelocitaPerDirezione(DateTime data, string direzione, string sortColumns, int startRowIndex, int maximumRows)
        {

            using (OracleConnection cn = this.CreateConnection())
            {
                using (OracleCommand cmd = this.CreateCommand(cn))
                {
                    cmd.CommandText = @"SELECT DATA_REP, 
												ORA_DA, 
												ORA_A, 
												STRADA, 
												DIREZIONE, 
												TEMPO_PERCORR_MEDIO,
												VEL_PERCORR_MEDIA,
												NUMERO_VEICOLI
												FROM TEMPI_VELOC_PERCORR_DIREZ 
												where DATA_REP = :P_DATA_REP and
                                                DIREZIONE = :P_DIREZIONE
                                                order by " + sortColumns;
                    cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);
					cmd.AddWithValue("P_DIREZIONE", direzione);

                    this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

                    int colDATA_REP = -1;
                    int colORA_DA = -1;
                    int colORA_A = -1;
                    int colSTRADA = -1;
                    int colDIREZIONE = -1;
                    int colTEMPO_PERCORR_MEDIO = -1;
                    int colVEL_PERCORR_MEDIA = -1;
					int colNUMERO_VEICOLI = -1;

                    RecordColumnBinder<BLStatistiche.TempiEtVelocitaPerDirezione> rcb = delegate(OracleDataReader rd)
                    {
                        colDATA_REP = rd.GetOrdinal("DATA_REP");
                        colORA_DA = rd.GetOrdinal("ORA_DA");
                        colORA_A = rd.GetOrdinal("ORA_A");
                        colSTRADA = rd.GetOrdinal("STRADA");
                        colDIREZIONE = rd.GetOrdinal("DIREZIONE");
                        colTEMPO_PERCORR_MEDIO = rd.GetOrdinal("TEMPO_PERCORR_MEDIO");
                        colVEL_PERCORR_MEDIA = rd.GetOrdinal("VEL_PERCORR_MEDIA");
						colNUMERO_VEICOLI = rd.GetOrdinal("NUMERO_VEICOLI");
					};

                    RecordBinder<BLStatistiche.TempiEtVelocitaPerDirezione> rt = delegate(OracleDataReader rd, BLStatistiche.TempiEtVelocitaPerDirezione t)
                    {
                        t.DataRep = rd.GetDateTime(colDATA_REP);
                        t.OraDa = int.Parse(rd.GetString(colORA_DA));
                        t.OraA = int.Parse(rd.GetString(colORA_A));
                        t.Strada = rd.GetString(colSTRADA);
                        t.Direzione = rd.GetString(colDIREZIONE);
                        t.TempoPercorrenzaSecondi = (int)rd.GetDecimal(colTEMPO_PERCORR_MEDIO);
                        t.Velocita = rd.GetDecimal(colVEL_PERCORR_MEDIA);
						if (rd.IsDBNull(colNUMERO_VEICOLI))
							t.NumeroVeicoli = null;
						else
							t.NumeroVeicoli = (int)rd.GetDecimal(colNUMERO_VEICOLI);
					};

                    cn.Open();
                    return this.RecordReader<BLStatistiche.TempiEtVelocitaPerDirezione>(cmd, rt, rcb);
                }
            }
        }

		public int GetVolumeTrafficoDirezioneCount(DateTime data)
		{
			try
			{
				string q = "select count(*) from VOL_TRAFF_DIREZ where DATA_REP = :P_DATA_REP";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);

						return (int)cmd.ExecuteScalar<decimal>();
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("DalStatistiche.GetVolumeTrafficoDirezioneCount", ex);
			}
		}

		public List<BLStatistiche.VolumeTrafficoDirezione> GetVolumeTrafficoDirezione(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{
			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT DATA_REP, 
												ORA_DA, 
												ORA_A, 
												STRADA, 
												DIREZIONE, 
												C_TRANS
												FROM VOL_TRAFF_DIREZ 
												where DATA_REP = :P_DATA_REP order by " + sortColumns;
					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);

					this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					int colDATA_REP = -1;
					int colORA_DA = -1;
					int colORA_A = -1;
					int colSTRADA = -1;
					int colDIREZIONE = -1;
					int colC_TRANS = -1;

					RecordColumnBinder<BLStatistiche.VolumeTrafficoDirezione> rcb = delegate(OracleDataReader rd)
					{
						colDATA_REP = rd.GetOrdinal("DATA_REP");
						colORA_DA = rd.GetOrdinal("ORA_DA");
						colORA_A = rd.GetOrdinal("ORA_A");
						colSTRADA = rd.GetOrdinal("STRADA");
						colDIREZIONE = rd.GetOrdinal("DIREZIONE");
						colC_TRANS = rd.GetOrdinal("C_TRANS");
					};

					RecordBinder<BLStatistiche.VolumeTrafficoDirezione> rt = delegate(OracleDataReader rd, BLStatistiche.VolumeTrafficoDirezione t)
					{
						t.DataRep = rd.GetDateTime(colDATA_REP);
						t.OraDa = int.Parse(rd.GetString(colORA_DA));
						t.OraA = int.Parse(rd.GetString(colORA_A));
						t.Strada = rd.GetString(colSTRADA);
						t.Direzione = rd.GetString(colDIREZIONE);
						t.C_Trans = (int)rd.GetDecimal(colC_TRANS);
					};

					cn.Open();
					return this.RecordReader<BLStatistiche.VolumeTrafficoDirezione>(cmd, rt, rcb);
				}
			}
		}

        public int GetVolumeTrafficoDirezioneCount(DateTime data, string direzione)
        {
            try
            {
                string q = "select count(*) from VOL_TRAFF_DIREZ where DATA_REP = :P_DATA_REP and DIREZIONE =:P_DIREZIONE";

                using (OracleConnection cn = this.CreateConnection())
                {
                    using (OracleCommand cmd = CreateCommand(cn))
                    {
                        cmd.CommandTimeout = 1000;
                        cmd.CommandText = q;
                        cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);
						cmd.AddWithValue("P_DIREZIONE", direzione);

						return (int)cmd.ExecuteScalar<decimal>();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("DalStatistiche.GetVolumeTrafficoDirezioneCount", ex);
            }
        }

        public List<BLStatistiche.VolumeTrafficoDirezione> GetVolumeTrafficoDirezione(DateTime data, string direzione, string sortColumns, int startRowIndex, int maximumRows)
        {
            using (OracleConnection cn = this.CreateConnection())
            {
                using (OracleCommand cmd = this.CreateCommand(cn))
                {
                    cmd.CommandText = @"SELECT DATA_REP, 
												ORA_DA, 
												ORA_A, 
												STRADA, 
												DIREZIONE, 
												C_TRANS
												FROM VOL_TRAFF_DIREZ 
												where DATA_REP = :P_DATA_REP and
                                                DIREZIONE = :P_DIREZIONE
                                                order by " + sortColumns;
                    cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);
					cmd.AddWithValue("P_DIREZIONE", direzione);

                    this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

                    int colDATA_REP = -1;
                    int colORA_DA = -1;
                    int colORA_A = -1;
                    int colSTRADA = -1;
                    int colDIREZIONE = -1;
                    int colC_TRANS = -1;

                    RecordColumnBinder<BLStatistiche.VolumeTrafficoDirezione> rcb = delegate(OracleDataReader rd)
                    {
                        colDATA_REP = rd.GetOrdinal("DATA_REP");
                        colORA_DA = rd.GetOrdinal("ORA_DA");
                        colORA_A = rd.GetOrdinal("ORA_A");
                        colSTRADA = rd.GetOrdinal("STRADA");
                        colDIREZIONE = rd.GetOrdinal("DIREZIONE");
                        colC_TRANS = rd.GetOrdinal("C_TRANS");
                    };

                    RecordBinder<BLStatistiche.VolumeTrafficoDirezione> rt = delegate(OracleDataReader rd, BLStatistiche.VolumeTrafficoDirezione t)
                    {
                        t.DataRep = rd.GetDateTime(colDATA_REP);
                        t.OraDa = int.Parse(rd.GetString(colORA_DA));
                        t.OraA = int.Parse(rd.GetString(colORA_A));
                        t.Strada = rd.GetString(colSTRADA);
                        t.Direzione = rd.GetString(colDIREZIONE);
                        t.C_Trans = (int)rd.GetDecimal(colC_TRANS);
                    };

                    cn.Open();
                    return this.RecordReader<BLStatistiche.VolumeTrafficoDirezione>(cmd, rt, rcb);
                }
            }
        }

		public int GetTempiSostaC2PCount(DateTime data)
		{
			try
			{
				string q = "select count(*) from TEMPI_SOSTA_C2P where DATA_REP = :P_DATA_REP";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);

						return (int)cmd.ExecuteScalar<decimal>();
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("DalStatistiche.GetTempiSostaC2PCount", ex);
			}
		}

		public List<BLStatistiche.TempiSostaC2P> GetTempiSostaC2P(DateTime data, string sortColumns, int startRowIndex, int maximumRows)
		{

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT TEMPI_SOSTA_C2P.DATA_REP, 
												TEMPI_SOSTA_C2P.ORA_DA, 
												TEMPI_SOSTA_C2P.ORA_A, 
												TEMPI_SOSTA_C2P.C2P, 
												TEMPI_SOSTA_C2P.TEMPO_SOSTA_MEDIO, 
												C2P.DESCRIZIONE DESCRC2P,
												TEMPI_SOSTA_C2P.NUMERO_VEICOLI 
												FROM TEMPI_SOSTA_C2P 
												INNER JOIN C2P ON
												C2P.IDC2P = TEMPI_SOSTA_C2P.C2P
												where DATA_REP = :P_DATA_REP order by " + sortColumns;
					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);

					this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					int colDATA_REP = -1;
					int colORA_DA = -1;
					int colORA_A = -1;
					int colC2P = -1;
					int colTEMPO_SOSTA_MEDIO = -1;
					int colDESCRC2P = -1;
					int colNUMERO_VEICOLI = -1;

					RecordColumnBinder<BLStatistiche.TempiSostaC2P> rcb = delegate(OracleDataReader rd)
					{
						colDATA_REP = rd.GetOrdinal("DATA_REP");
						colORA_DA = rd.GetOrdinal("ORA_DA");
						colORA_A = rd.GetOrdinal("ORA_A");
						colC2P = rd.GetOrdinal("C2P");
						colTEMPO_SOSTA_MEDIO = rd.GetOrdinal("TEMPO_SOSTA_MEDIO");
						colDESCRC2P = rd.GetOrdinal("DESCRC2P");
						colNUMERO_VEICOLI = rd.GetOrdinal("NUMERO_VEICOLI");
					};

					RecordBinder<BLStatistiche.TempiSostaC2P> rt = delegate(OracleDataReader rd, BLStatistiche.TempiSostaC2P t)
					{
						t.DataRep = rd.GetDateTime(colDATA_REP);
						t.OraDa = int.Parse(rd.GetString(colORA_DA));
						t.OraA = int.Parse(rd.GetString(colORA_A));
						t.C2P = (int)rd.GetDouble(colC2P);
						t.TempoSostaMedio = (int)rd.GetDecimal(colTEMPO_SOSTA_MEDIO);
						t.DescrizioneC2P = rd.GetString(colDESCRC2P);
						if (rd.IsDBNull(colNUMERO_VEICOLI))
							t.NumeroVeicoli = null;
						else
							t.NumeroVeicoli = (int)rd.GetDecimal(colNUMERO_VEICOLI);
					};

					cn.Open();
					return this.RecordReader<BLStatistiche.TempiSostaC2P>(cmd, rt, rcb);
				}
			}
		}

        public int GetTempiSostaC2PCount(DateTime data, int idC2P)
        {
            try
            {
                string q = "select count(*) from TEMPI_SOSTA_C2P where DATA_REP = :P_DATA_REP and C2P = :P_IDC2P";

                using (OracleConnection cn = this.CreateConnection())
                {
                    using (OracleCommand cmd = CreateCommand(cn))
                    {
                        cmd.CommandTimeout = 1000;
                        cmd.CommandText = q;
                        cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);
						cmd.AddWithValue("P_IDC2P", idC2P);

						return (int)cmd.ExecuteScalar<decimal>();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("DalStatistiche.GetTempiSostaC2PCount", ex);
            }
        }

        public List<BLStatistiche.TempiSostaC2P> GetTempiSostaC2P(DateTime data, int idC2p, string sortColumns, int startRowIndex, int maximumRows)
        {

            using (OracleConnection cn = this.CreateConnection())
            {
                using (OracleCommand cmd = this.CreateCommand(cn))
                {
                    cmd.CommandText = @"SELECT TEMPI_SOSTA_C2P.DATA_REP, 
												TEMPI_SOSTA_C2P.ORA_DA, 
												TEMPI_SOSTA_C2P.ORA_A, 
												TEMPI_SOSTA_C2P.C2P, 
												TEMPI_SOSTA_C2P.TEMPO_SOSTA_MEDIO, 
												C2P.DESCRIZIONE DESCRC2P,
												TEMPI_SOSTA_C2P.NUMERO_VEICOLI 
												FROM TEMPI_SOSTA_C2P 
												INNER JOIN C2P ON
												C2P.IDC2P = TEMPI_SOSTA_C2P.C2P
												where DATA_REP = :P_DATA_REP and
                                                C2P = :P_C2P
                                                order by " + sortColumns;
                    cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);
					cmd.AddWithValue("P_C2P", idC2p);

                    this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

                    int colDATA_REP = -1;
                    int colORA_DA = -1;
                    int colORA_A = -1;
                    int colC2P = -1;
                    int colTEMPO_SOSTA_MEDIO = -1;
                    int colDESCRC2P = -1;
					int colNUMERO_VEICOLI = -1;

                    RecordColumnBinder<BLStatistiche.TempiSostaC2P> rcb = delegate(OracleDataReader rd)
                    {
                        colDATA_REP = rd.GetOrdinal("DATA_REP");
                        colORA_DA = rd.GetOrdinal("ORA_DA");
                        colORA_A = rd.GetOrdinal("ORA_A");
                        colC2P = rd.GetOrdinal("C2P");
                        colTEMPO_SOSTA_MEDIO = rd.GetOrdinal("TEMPO_SOSTA_MEDIO");
                        colDESCRC2P = rd.GetOrdinal("DESCRC2P");
						colNUMERO_VEICOLI = rd.GetOrdinal("NUMERO_VEICOLI");
					};

                    RecordBinder<BLStatistiche.TempiSostaC2P> rt = delegate(OracleDataReader rd, BLStatistiche.TempiSostaC2P t)
                    {
                        t.DataRep = rd.GetDateTime(colDATA_REP);
                        t.OraDa = int.Parse(rd.GetString(colORA_DA));
                        t.OraA = int.Parse(rd.GetString(colORA_A));
                        t.C2P = (int)rd.GetDouble(colC2P);
                        t.TempoSostaMedio = (int)rd.GetDecimal(colTEMPO_SOSTA_MEDIO);
                        t.DescrizioneC2P = rd.GetString(colDESCRC2P);
						if (rd.IsDBNull(colNUMERO_VEICOLI))
							t.NumeroVeicoli = null;
						else
							t.NumeroVeicoli = (int)rd.GetDecimal(colNUMERO_VEICOLI);
					};

                    cn.Open();
                    return this.RecordReader<BLStatistiche.TempiSostaC2P>(cmd, rt, rcb);
                }
            }
        }

		public int GetTarghePerC2PCount(DateTime data, int idC2P)
		{
			try
			{
				string q = "select count(*) from TARGHE_PER_C2P where DATA_REP = :P_DATA_REP and C2P = :P_IDC2P";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						cmd.AddWithValue("P_DATA_REP", data);
						cmd.AddWithValue("P_IDC2P", idC2P);

						return (int)cmd.ExecuteScalar<decimal>();
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("DalStatistiche.GetTarghePerC2PCount", ex);
			}
		}

		public List<BLStatistiche.TarghePerC2P> GetTarghePerC2P(DateTime data, int idC2p, string sortColumns, int startRowIndex, int maximumRows)
		{

			using (OracleConnection cn = this.CreateConnection())
			{
				using (OracleCommand cmd = this.CreateCommand(cn))
				{
					cmd.CommandText = @"SELECT	DATA_REP, 
												C2P, 
												TARGHE_RIC_ITA, 
												TARGHE_RIC_EST, 
												TARGHE_NON_RIC
												FROM TARGHE_PER_C2P 
												where DATA_REP = :P_DATA_REP and
                                                C2P = :P_C2P
                                                order by " + sortColumns;
					cmd.CommandType = CommandType.Text;
					cmd.AddWithValue("P_DATA_REP", data);
					cmd.AddWithValue("P_C2P", idC2p);

					this.PageQuery(cmd, cmd.CommandText, startRowIndex, maximumRows);

					int colDATA_REP = -1;
					int colC2P = -1;
					int colTARGHE_RIC_ITA = -1;
					int colTARGHE_RIC_EST = -1;
					int colTARGHE_NON_RIC = -1;

					RecordColumnBinder<BLStatistiche.TarghePerC2P> rcb = delegate(OracleDataReader rd)
					{
						colDATA_REP = rd.GetOrdinal("DATA_REP");
						colC2P = rd.GetOrdinal("C2P");
						colTARGHE_RIC_ITA = rd.GetOrdinal("TARGHE_RIC_ITA");
						colTARGHE_RIC_EST = rd.GetOrdinal("TARGHE_RIC_EST");
						colTARGHE_NON_RIC = rd.GetOrdinal("TARGHE_NON_RIC");
					};

					RecordBinder<BLStatistiche.TarghePerC2P> rt = delegate(OracleDataReader rd, BLStatistiche.TarghePerC2P t)
					{
						t.DataRep = rd.GetDateTime(colDATA_REP);
						t.C2P = (int)rd.GetDouble(colC2P);
						t.TargheRicIta = (int)rd.GetDecimal(colTARGHE_RIC_ITA);
						t.TargheRicEst = (int)rd.GetDecimal(colTARGHE_RIC_EST);
						t.TargheNonRic = (int)rd.GetDecimal(colTARGHE_NON_RIC);
					};

					cn.Open();
					return this.RecordReader<BLStatistiche.TarghePerC2P>(cmd, rt, rcb);
				}
			}
		}
		#endregion
	}
}
