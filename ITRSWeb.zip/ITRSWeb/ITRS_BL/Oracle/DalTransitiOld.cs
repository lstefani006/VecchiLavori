using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Diagnostics;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
using System.Data.OracleClient;
#endif

using System.Data.Common;


using ITRS_BL.IDal;
using ITRS_BL.Utility;

namespace ITRS_BL.Oracle
{
	class DalTransiti : DalBase, IDalTransiti
	{
		public byte[] GetBlobImmagine(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			try
			{
				string q = @"
				select 
				Immagine
				from {0}
				where
				targa = :t and nazionalita=:n and dataOraRilevamento=:d and immagine is not null";

				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, "Immagini");
						cmd.CommandType = CommandType.Text;
						AddWithValue(cmd, "t", targa);
						AddWithValue(cmd, "n", nazionalita);
						AddWithValue(cmd, "d", dataOraRilevamento);

						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							if (rd.Read())
							{
								if (!rd.IsDBNull(0))
								{
									OracleBlob blob = rd.GetOracleBlob(0);
									return blob.Value;
								}
							}
						}


						cmd.CommandText = string.Format(q, "ImmaginiSuEvento");
						cmd.CommandType = CommandType.Text;
						cmd.Parameters.Clear();
						AddWithValue(cmd, "t", targa);
						AddWithValue(cmd, "n", nazionalita);
						AddWithValue(cmd, "d", dataOraRilevamento);
						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							if (rd.Read())
							{
								if (!rd.IsDBNull(0))
								{
									OracleBlob blob = rd.GetOracleBlob(0);
									return blob.Value;
								}
							}
						}

						return null;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetBlobImmagini");
				throw new ApplicationException("GetBlobImmagini", ex);
			}
		}


		public void GetLatLonTransito(string targa, string nazionalita, DateTime dataOraRilevamento, out double lat, out double lon)
		{
			try
			{
				string q = @"
select 
distinct
T.Latitudine,
T.Longitudine,
C2p.Lat as C2pLat,
C2p.Lon as C2pLon 
from
(
	select
	Latitudine,
	Longitudine,
	IdC2p
	from TRANSITIsuEvento
	where
	TARGA = :t and
	NAZIONALITA = :n and
	DATAORARILEVAMENTO = :d
union
	select 
	Latitudine,
	Longitudine,
	IdC2p
	from TRANSITI
	where
	TARGA = :t and
	NAZIONALITA = :n and
	DATAORARILEVAMENTO = :d
) T
inner join C2P
on T.Idc2p = C2p.IDC2P";

				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();

					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						AddWithValue(cmd, "t", targa);
						AddWithValue(cmd, "n", nazionalita);
						AddWithValue(cmd, "d", dataOraRilevamento);

						using (OracleDataReader rd = cmd.ExecuteReader())
						{
							if (rd.Read())
							{
								if (!rd.IsDBNull(0))
								{
									lat = Convert.ToDouble(rd[0]);
									lon = Convert.ToDouble(rd[1]);
								}
								else
								{
									lat = Convert.ToDouble(rd[2]);
									lon = Convert.ToDouble(rd[3]);
								}

								return;
							}
						}
					}
				}

				lat = 0;
				lon = 0;
				Debug.Assert(false);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetLatLonTransito");
				throw new ApplicationException("GetLatLonTransito", ex);
			}
		}


		#region Query del batch
		public int GetTransitiCount()
		{
			try
			{
				string q = @"select count(*) from Transiti";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandTimeout = 1000;
						cmd.CommandText = q;
						cmd.CommandType = CommandType.Text;
						return (int)ExecuteScalar<decimal>(cmd);
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetTransiti", ex);
			}
		}
		public List<Transiti> GetTransiti(string sortColumns, int startRowIndex, int maximumRows)
		{
			try
			{
				if (sortColumns.Trim() == "")
					sortColumns = "Targa";

				string q =
				@"select 
				Targa, 
				Nazionalita,
				DataOraRilevamento,
				IdC2P,
				EnumStatoTransito StatoTransito,
				EnumTipoVarco TipoVarco
				from Transiti where Targa like :t ORDER BY " + sortColumns;

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.PageQuery(cn, q, startRowIndex, maximumRows))
					{
						AddWithValue(cmd, "t", "%");
						cmd.CommandTimeout = 1000;
						return RecordReader<Transiti>(cmd);

						//int colProgressivoQuery = -1;
						//int colTarga = -1;
						//int colNazionalita = -1;
						//int colDataOraRilevamento = -1;
						//int colIdC2P = -1;
						//int colStatoTransito = -1;
						//int colTipoVarco = -1;
						//RecordColumnBinder<Transiti> rcb = delegate(OracleDataReader rd)
						//{
						//    colProgressivoQuery = rd.GetOrdinal("ProgressivoQuery");
						//    colTarga = rd.GetOrdinal("Targa");
						//    colNazionalita = rd.GetOrdinal("Nazionalita");
						//    colDataOraRilevamento = rd.GetOrdinal("DataOraRilevamento");
						//    colIdC2P = rd.GetOrdinal("IdC2P");
						//    colStatoTransito = rd.GetOrdinal("StatoTransito");
						//    colTipoVarco = rd.GetOrdinal("TipoVarco");
						//};
						//RecordBinder<Transiti> rt = delegate(OracleDataReader rd, Transiti t)
						//{
						//    t.ProgressivoQuery = rd.GetDecimal(colProgressivoQuery);
						//    t.Targa = rd.GetString(colTarga);
						//    t.Nazionalita = rd.GetString(colNazionalita);
						//    t.DataOraRilevamento = rd.GetDateTime(colDataOraRilevamento);
						//    t.IdC2P = rd.GetInt32(colIdC2P);
						//    t.StatoTransito = rd.GetString(colStatoTransito);
						//    t.TipoVarco = rd.GetString(colTipoVarco);
						//};
						//return RecordReader<Transiti>(cmd, rt, rcb);
					}
				}
			}
			catch (Exception ex)
			{
				throw new ApplicationException("GetTransiti", ex);
			}
		}
		#endregion


		private DatiTransito GetDatiTransitoSuTabella(string targa, string nazionalita, DateTime dataOraRilevamento, string tabella)
		{
			Debug.Assert(tabella.ToLower() == "transiti" || tabella.ToLower() == "transitisuevento");
			try
			{
				string q;
				if (tabella.ToLower() == "transiti")
				{
					q = @"
select 
Transiti.Targa,
Transiti.Nazionalita,
Transiti.DataOraRilevamento,

C2P.Descrizione            DescrizioneC2P,
C2P.Direzione              DirezioneC2P,
C2P.CodiceStrada           CodiceStrada,
Transiti.EnumTipoVarco     TipoVarco,
Transiti.EnumStatoTransito StatoTransito,
Transiti.Latitudine,
Transiti.Longitudine,
Transiti.MarcaVeicolo,
Transiti.ModelloVeicolo,

Transiti.DataOraPresaInCarico,
Transiti.DataOraChiusura,

U.UserName                     UtentePresaInCarico,
Transiti.NoteChiusura,
Transiti.TargaAcquisita        TargaAcquisita,
Transiti.NazionalitaAcquisita  NazionalitaAcquisita

from Transiti

inner join C2P
on C2P.IdC2P = Transiti.IdC2P

left outer join aspnet_users U
on U.PKID = Transiti.IdUtentePresaInCarico

where Transiti.Targa = :t and 
Transiti.Nazionalita = :n and 
Transiti.DataOraRilevamento = :d";
				}
				else
				{
					q = @"
select 
transitisuevento.Targa,
transitisuevento.Nazionalita,
transitisuevento.DataOraRilevamento,

C2P.Descrizione           DescrizioneC2P,
C2P.Direzione             DirezioneC2P,
C2P.CodiceStrada          CodiceStrada,
transitisuevento.EnumTipoVarco         TipoVarco,
transitisuevento.EnumStatoTransito     StatoTransito,
transitisuevento.Latitudine,
transitisuevento.Longitudine,
transitisuevento.MarcaVeicolo,
transitisuevento.ModelloVeicolo,

transitisuevento.DataOraPresaInCarico,
transitisuevento.DataOraChiusura,

U.UserName                             UtentePresaInCarico,
transitisuevento.NoteChiusura,
transitisuevento.Targa                 TargaAcquisita,
transitisuevento.Nazionalita           NazionalitaAcquisita

from transitisuevento

inner join C2P
on C2P.IdC2P = transitisuevento.IdC2P

left outer join aspnet_users U
on U.PKID = transitisuevento.IdUtentePresaInCarico

where transitisuevento.Targa = :t and 
transitisuevento.Nazionalita = :n and 
transitisuevento.DataOraRilevamento = :d";
				}

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = string.Format(q, tabella);
						cmd.CommandType = CommandType.Text;

						AddWithValue(cmd, "t", targa);
						AddWithValue(cmd, "n", nazionalita);
						AddWithValue(cmd, "d", dataOraRilevamento);

						List<DatiTransito> r = RecordReader<DatiTransito>(cmd);
						if (r.Count == 0)
							return null;

						return r[0];
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalTransiti.GetDatiTransito");
				throw;
			}
		}

		public DatiTransito GetDatiTransitoOrTransitoSuEvento(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			DatiTransito tr = GetDatiTransitoSuTabella(targa, nazionalita, dataOraRilevamento, "transiti");
			if (tr != null)
				return tr;

			return GetDatiTransitoSuTabella(targa, nazionalita, dataOraRilevamento, "TransitiSuEvento");
		}

		public List<DatiTransito> GetTransitiDellEvento(string targa, string nazionalita, DateTime dataOraInserimento, int idEvento, string sortColumns)
		{
			try
			{
				string q = @"
select 
TSE.Targa,
TSE.Nazionalita,
TSE.DataOraRilevamento,

C2P.Descrizione           DescrizioneC2P,
C2P.Direzione             DirezioneC2P,
C2P.CodiceStrada          CodiceStrada,
TSE.EnumTipoVarco         TipoVarco,
TSE.EnumStatoTransito     StatoTransito,
TSE.Latitudine,
TSE.Longitudine,
TSE.MarcaVeicolo,
TSE.ModelloVeicolo,
TSE.DataOraPresaInCarico,
TSE.DataOraChiusura,

U.UserName                UtentePresaInCarico,
TSE.NoteChiusura,

TSE.Targa                 TargaAcquisita,
TSE.Nazionalita           NazionalitaAcquisita

from TransitiSuEvento TSE

inner join TransitiEventi TE
on  TE.Targa = TSE.Targa
and TE.Nazionalita = TSE.Nazionalita
and TE.DataOraRilevamento = TSE.DataOraRilevamento

inner join C2P
on C2P.IdC2P = TSE.IdC2P

left outer join aspnet_users U
on U.PKID = TSE.IdUtentePresaInCarico

where

    TE.Targa = :t
and TE.Nazionalita = :n
and TE.DataOraInserimento = :d
and TE.IdEvento = : i

order by ";

				using (OracleConnection cn = this.CreateConnection())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = q + sortColumns;

						AddWithValue(cmd, "t", targa);
						AddWithValue(cmd, "n", nazionalita);
						AddWithValue(cmd, "d", dataOraInserimento);
						AddWithValue(cmd, "i", idEvento);

						List<DatiTransito> r = RecordReader<DatiTransito>(cmd);
						return r;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalTransiti.GetDatiTransito");
				throw;
			}
		}


		public bool PrendiInCarico(string targa, string nazionalita, DateTime dataOraRilevamento, string idUtentePresaInCarico)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						using (OracleCommand cmd = this.CreateCommand(cn))
						{
							cmd.CommandText = "ITRS_TRANSITI_EVENTI.TransitoPrendiInCarico";
							cmd.CommandType = CommandType.StoredProcedure;

							AddWithValue(cmd, "p_Targa", targa);
							AddWithValue(cmd, "p_Nazionalita", nazionalita);
							AddWithValue(cmd, "p_DataOraRilevamento", dataOraRilevamento);

							AddWithValue(cmd, "p_IdUtentePresaInCarico", idUtentePresaInCarico);
							using (OracleParameter p_Updated = AddInt64OutParameter(cmd, "p_Updated"))
							{
								cmd.ExecuteNonQuery();
								int updated = Convert.ToInt32(p_Updated.Value);
								if (updated == 0)
								{
									tr.Commit();//todo ? xche`
									return false;
								}

								if (!(updated == 1 || updated == 2))
									throw new ApplicationException("PrendiInCarico: aggiornati " + updated + " records");

							}
						}
						tr.Commit();
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalTransiti.PrendiInCarico");
				throw;
			}
		}

		public bool AzioneSuPresaInCarico(string targa, string nazionalita, DateTime dataOraRilevamento, StatoTransito statoTransito, string noteChiusura, string TargaValidata, string NazionalitaValidata)
		{
			try
			{
				using (OracleConnection cn = this.CreateConnection())
				{
					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						using (OracleCommand cmd = this.CreateCommand(cn))
						{
							cmd.CommandText = "ITRS_TRANSITI_EVENTI.TransitoAzioneSuPresaInCarico2";
							cmd.CommandType = CommandType.StoredProcedure;

							AddWithValue(cmd, "P_TARGA", targa);
							AddWithValue(cmd, "P_NAZIONALITA", nazionalita);
							AddWithValue(cmd, "P_DATAORARILEVAMENTO", dataOraRilevamento);
							AddWithValue(cmd, "P_STATOTRANSITO", statoTransito.ToString());
							AddWithValue(cmd, "P_NOTECHIUSURA", noteChiusura);
							AddWithValue(cmd, "p_NuovaTarga", TargaValidata);
							AddWithValue(cmd, "p_NuovaNazionalita", NazionalitaValidata);

							using (OracleParameter p_Updated = AddInt64OutParameter(cmd, "P_UPDATED"))
							{
								cmd.ExecuteNonQuery();

								int updated = Convert.ToInt32(p_Updated.Value);
								if (updated == 0)
								{
									tr.Commit();
									return false;
								}

								if (!(updated == 1 || updated == 2))
									throw new ApplicationException("AzioneSuPresaInCarico: aggiornati " + updated + " records");
							}
						}
						tr.Commit();
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalTransiti.AzioneSuPresaInCarico");
				throw;
			}
		}


		public void RiconoscimentoManuale(string targa, string nazionalita, DateTime dataOraRilevamento, string targaRiconosciutaDallOperatore, string nazioneRiconosciutaDallOperatore, string note)
		{
			Debug.Assert(targa.StartsWith("~"));

			using (OracleConnection cn = this.CreateConnection())
			{
				cn.Open();
				using (OracleTransaction tr = cn.BeginTransaction())
				{
					using (OracleCommand cmd = this.CreateCommand(cn))
					{
						cmd.CommandText = "ITRS_TRANSITI_EVENTI.TransitoRiconoscimentoManuale";
						cmd.CommandType = CommandType.StoredProcedure;

						AddWithValue(cmd, "P_TARGA", targa);
						AddWithValue(cmd, "P_NAZIONALITA", nazionalita);
						AddWithValue(cmd, "P_DATAORARILEVAMENTO", dataOraRilevamento);
						AddWithValue(cmd, "P_NOTECHIUSURA", note);

						AddWithValue(cmd, "P_NUOVA_TARGA", targaRiconosciutaDallOperatore);
						AddWithValue(cmd, "P_NUOVA_NAZIONALITA", nazioneRiconosciutaDallOperatore);

						// devo fare update di transiti e immagini.
						// misa tanto che si fanno due insert e 2 due delete.
						cmd.ExecuteNonQuery();

						tr.Commit();
					}
				}

			}
		}

	}
}
