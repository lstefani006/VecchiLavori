using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

#if ODP
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
#else
#endif

using System.Data.Common;


using ITRS_BL.IDal;
using ITRS_BL.Utility;

namespace ITRS_BL.Oracle
{
	class DalParametri : DalBase, IDalParametri
	{
		public List<BL_Parametri.Parametro> GetParametri()
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					using (OracleCommand cmd = CreateCommand(cn))
					{
						cmd.CommandType = CommandType.Text;
						cmd.CommandText = "select P.parTipo, P.parValue from Parametri P order by parTipo ";

						List<BL_Parametri.Parametro> ret = RecordReader<BL_Parametri.Parametro>(cmd);
						return ret;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalParametri.GetParametri");
				throw;
			}
		}

		public void SaveParametro(string parTipo, decimal parValue)
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
                    cn.Open();
					SavePar(cn, null, parTipo, parValue);
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalParametri.SaveParametro");
				throw;
			}
		}

		public void SaveParametri(List<BL_Parametri.Parametro> parList)
		{
			try
			{
				using (OracleConnection cn = CreateConnection())
				{
					cn.Open();
					using (OracleTransaction tr = cn.BeginTransaction())
					{
						foreach (BL_Parametri.Parametro p in parList)
							SavePar(cn, tr, p.ParTipo, p.ParValue);

						tr.Commit();
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "DalParametri.SaveParametri");
				throw;
			}
		}

		private void SavePar(OracleConnection cn, OracleTransaction tr, string parTipo, decimal parValue)
		{
			using (OracleCommand cmd = CreateCommand(cn))
			{
				cmd.CommandType = CommandType.Text;
				cmd.CommandText = "update Parametri set parValue=:v where parTipo=:t";
				cmd.AddWithValue(":v", parValue);
				cmd.AddWithValue(":t", parTipo);
				int rowsAffeted = cmd.ExecuteNonQuery();
				if (rowsAffeted != 1)
					throw new ApplicationException("Parametro non salvato: parTipo=" + parTipo);
			}
		}
	}
}
