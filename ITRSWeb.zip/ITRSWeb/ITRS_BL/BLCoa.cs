using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using ITRS_BL.IDal;

namespace ITRS_BL
{
	public partial class BLCoa : Component
	{
		public BLCoa()
		{
			InitializeComponent();
		}

		public BLCoa(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		static List<Coa> r = new List<Coa>();


		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Coa> GetListaCOA(string columnsSort)
		{
			IDalCoa t = DalProvider.DAL.CreateDalCoa();
			return t.GetLista(columnsSort);
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Coa> GetListaCOACB()
		{
			try
			{
				string columnsSort = "Descrizione";
				IDalCoa t = DalProvider.DAL.CreateDalCoa();
				return t.GetLista(columnsSort);
			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella lettura della tabella COA", ex);
			}
		}


		[DataObjectMethod(DataObjectMethodType.Select)]
		public Coa GetCOA(int idCoa)
		{
			IDalCoa t = DalProvider.DAL.CreateDalCoa();
			Coa c = new Coa();
			c.IdCOA=idCoa;
			return t.GetRecord(c);
		}


		[DataObjectMethod(DataObjectMethodType.Delete)]
		public void CancellaCOA(int idCoa)
		{
			IDalCoa t = DalProvider.DAL.CreateDalCoa();
			Coa c = new Coa();
			c.IdCOA = idCoa;
			t.Cancella(c);
		}

		[DataObjectMethod(DataObjectMethodType.Update)]
		public void AggiornaCOA(int idCoa, string descrizione)
		{
			IDalCoa t = DalProvider.DAL.CreateDalCoa();
			Coa c = new Coa();
			c.IdCOA = idCoa;
			c.Descrizione = descrizione;
			t.Aggiorna(c);
		}

		[DataObjectMethod(DataObjectMethodType.Insert)]
		public void InserisciCOA(int idCoa, string descrizione)
		{
			IDalCoa t = DalProvider.DAL.CreateDalCoa();
			Coa c = new Coa();
			c.IdCOA = idCoa;
			c.Descrizione = descrizione;
			t.Inserisci(c);
		}

	}

	[Serializable]
	public class Coa
	{
		public int IdCOA
		{
			get { return _idcoa; }
			set { _idcoa = value; }
		}
		public string Descrizione
		{
			get { return _descrizione; }
			set { _descrizione = value; }
		}

		private int _idcoa;
		private string _descrizione;
	}
}
