using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Runtime.Remoting;

namespace ITRS_BL
{
	public static class ServerItems
	{
		public static void StartServer()
		{
			RemotingConfiguration.Configure(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile, false);

			KillMapPoint();

			ITRS_BL.BLGeoRef.StartServer();
			ITRS_BL.BLMap.StartServer();
			ITRS_BL.BLQueueJobs.StartServer();
			ITRS_BL.BLLTS.StartServer();
			ITRS_BL.BLC2P.StartServer();
			ITRS_BL.BLLTSImport.StartServer();
		}

		public static void StopServer()
		{
			ITRS_BL.BLC2P.StopServer();
			ITRS_BL.BLLTS.StopServer();
			ITRS_BL.BLGeoRef.StopServer();
			ITRS_BL.BLMap.StopServer();
			ITRS_BL.BLQueueJobs.StopServer();
			ITRS_BL.BLLTSImport.StopServer();

			KillMapPoint();
		}

		private static void KillMapPoint()
		{
			try
			{
				Process[] mp = Process.GetProcessesByName("mappoint");
				foreach (Process p in mp)
					p.Kill();
			}
			catch (Exception ex)
			{
				Log.Write(ex, "ITRS_BL.GeoRef.StopThread");
			}
		}


		static object obj = new object();
		/// <summary>
		/// Metodo per create MapPointApplication.
		/// Viene utilizzato per creare un map point alla volta.
		/// Chiamando questa funzione da Thread diversi (anche in contemporanea)
		/// vi ottiene la serializzazione delle creazioni di mappoint
		/// </summary>
		/// <returns></returns>
		public static MapPointApp.Application CreateMapPointApplication(string serverName)
		{
			lock (obj)
			{
				//Console.Write("{0}: CreateMapPointApplication....", serverName);
				MapPointApp.Application app = new MapPointApp.Application();
				//Console.WriteLine("done.");
				return app;
			}
		}
	}
}
