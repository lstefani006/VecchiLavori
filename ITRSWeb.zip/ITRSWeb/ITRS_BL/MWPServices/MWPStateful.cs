using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Configuration;
using System.Xml;
using System.IO;

using ITRS_BL.IDal;

namespace ITRS_BL.MWPStateful
{
	/// <summary>
	/// Gli allarmi devono essere TUTTI veicolati nelle code MWP per i COA,
	/// ma devono avere expiration time molto basso!
	/// Inoltre, tutti gli allarmi devono essere convogliati verso la sp
	/// che alimenta le tabelle temporanee degli interventi (questa attivita',
	/// probabilmente, e' meglio che sia svolta all'interno del processo di
	/// gestione allarmi piuttosto che dentro la gateway, in quanto altrimenti
	/// alcuni allarmi potrebbero essere duplicati.
	/// </summary>
	public class MWPException : ApplicationException
	{
		public MWPException(string msg) : base(msg) { }
	}

	public class MWPInterface
	{
		MWPNET.MWPCoreClass CoreObj;
		MWPNET.MWPQMgrClass QMgrObj;
		MWPNET.MWPQueueInfoClass QueueInfoObj;
		MWPNET.MWPQueueClass QueueObj;
		MWPNET.MWPMessageClass MsgObj;

		public MWPInterface()
		{
			CoreObj = null;
			QMgrObj = null;
			QueueInfoObj = null;
			QueueObj = null;
			MsgObj = null;
		}

		public void Connect()
		{
			// Connect to queue manager
			CoreObj = new MWPNET.MWPCoreClass();
			CoreObj.QMgrName = ReadAppSettings.ToString("MWPNET.CoreObj.QMgrName", "ITRS_PROD");
			CoreObj.UserName = ReadAppSettings.ToString("MWPNET.CoreObj.UserName", "ROOT");
			CoreObj.ApplicationName = ReadAppSettings.ToString("MWPNET.CoreObj.ApplicationName", "ITRSWeb");
			
			string pwd = "";
			QMgrObj = CoreObj.Connect(ref pwd);
			MWPNET.RetCodes rc = CoreObj.Error;
			if (rc != MWPNET.RetCodes.RC_OK)
				throw new MWPException("Connect: " + rc.ToString());

			// Open the queue
			QueueInfoObj = new MWPNET.MWPQueueInfoClass();
			QueueInfoObj.Name = ReadAppSettings.ToString("MWPInterface.QueueInfoObj.Name", "COAQUEUE");
			QueueInfoObj.Type = MWPNET.QueueType.QLOCAL;
			QueueObj = QMgrObj.QOpen(QueueInfoObj, MWPNET.QueueOpenType.OPEN_IN, ref pwd);
			rc = QMgrObj.Error;
			if (rc != MWPNET.RetCodes.RC_OK)
			{
				QMgrObj.Disconnect();
				throw new MWPException("Open Queue: " + rc.ToString());
			}
		}

		public void Disconnect()
		{
			QueueObj.Close();
			QMgrObj.Disconnect();
		}

		
		public string GetNextMessage(out string CorrelId, int TimeoutSec)
		{
			CorrelId = null;

			MWPNET.MWPGetMsgOptionClass GetMsgOptObj;
			// Non suspensive non destructive read 
			GetMsgOptObj = new MWPNET.MWPGetMsgOptionClass();
			GetMsgOptObj.ReadType = MWPNET.GetReadTypes.SUSPENSIVE | MWPNET.GetReadTypes.WITH_LOCK;
			GetMsgOptObj.Mode = MWPNET.GetModeType.BROWSE_FIRST;
			GetMsgOptObj.Timeout = TimeoutSec;

			// Filtered read (using CorrelId)
			MsgObj = new MWPNET.MWPMessageClass();
			MsgObj.Id = "";
			//LEO 1610 MsgObj.CorrelId = CorrelId;
			MsgObj.CorrelId = "";



			MsgObj.Length = 0;

			// Read message
			string RetMsg = null;
			QueueObj.GetMessage(GetMsgOptObj, MsgObj);
			MWPNET.RetCodes rc = QueueObj.Error;
			// Check the completion code (PEEK MESSAGE)
			if (rc == 0)
			{
				// OK: save the body of the message
				RetMsg = MsgObj.Body;
				CorrelId = MsgObj.CorrelId;

				// Now we delete the message from the queue
				GetMsgOptObj.ReadType = MWPNET.GetReadTypes.NOT_SUSPENSIVE;
				GetMsgOptObj.Mode = MWPNET.GetModeType.GET_UNDER_CURSOR;
				QueueObj.GetMessage(GetMsgOptObj, MsgObj);
				rc = QueueObj.Error;
				if (rc != MWPNET.RetCodes.RC_OK)
				{
					QueueObj.Close();
					QMgrObj.Disconnect();
					throw new MWPException("Remove Msg: " + rc.ToString());
				}
			}
			else
			{
				// NOT OK: Check again for queue empty retcode (PEEK MESSAGE)
				if (rc == MWPNET.RetCodes.RC_QUEUE_EMPTY)
				{
					// No message in queue: ok and return null string
					RetMsg = null;
				}
				else
				{
					QueueObj.Close();
					QMgrObj.Disconnect();
					throw new MWPException("Peek Msg: " + rc.ToString());
				}
			}
			return RetMsg;
		}
	}
}
