using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using ITRS_BL.IDal;
using MWPNET;

namespace ITRS_BL.MWPServices
{
	/// <summary>
	/// Gli allarmi devono essere TUTTI veicolati nelle code MWP per i COA,
	/// ma devono avere expiration time molto basso!
	/// Inoltre, tutti gli allarmi devono essere convogliati verso la sp
	/// che alimenta le tabelle temporanee degli interventi (questa attivita',
	/// probabilmente, e' meglio che sia svolta all'interno del processo di
	/// gestione allarmi piuttosto che dentro la gateway, in quanto altrimenti
	/// alcuni allarmi potrebbero essere duplicati.
	/// </summary>
	public class MWPException : ApplicationException
	{
		public MWPException(string msg) : base(msg) { }
	}

	public class MWPInterface
	{
		public void ManageAllarmeIntervento(string targa, string nazionalita, List<MWPC2PInfo> C2PList, bool Add)
		{
			// Connect to queue manager
			MWPCoreClass CoreObj = new MWPCoreClass();
			CoreObj.QMgrName = ReadAppSettings.ToString("MWPNET.CoreObj.QMgrName", "ITRS_PROD");
			CoreObj.UserName = ReadAppSettings.ToString("MWPNET.CoreObj.UserName", "ROOT");
			CoreObj.ApplicationName = ReadAppSettings.ToString("MWPNET.CoreObj.ApplicationName", "ITRSWeb");

			string pwd = "";
			MWPQMgrClass QMgrObj = CoreObj.Connect(ref pwd);
			RetCodes rc = CoreObj.Error;
						
			if (rc != RetCodes.RC_OK)
				throw new MWPException("Connect: " + rc.ToString());

			foreach (MWPC2PInfo c in C2PList)
			{
				DateTime dataOraInizio = DateTime.Now.Date.AddDays(-1);
				if (c.DataOraRilevamento.HasValue)
					dataOraInizio = c.DataOraRilevamento.Value;

				DateTime dataOraFine = new DateTime(2036, 12, 31, 23, 59, 59);

				string msg = ProduceTargaMessage(targa, nazionalita, dataOraInizio, dataOraFine, Add);


				Log.Write("ManageAllarmeIntervento QMgrName={0}", c.QmgrName);

				// Open the queue
				MWPQueueInfoClass QueueInfoObj = new MWPQueueInfoClass();
				QueueInfoObj.QMgrName = c.QmgrName;
				QueueInfoObj.Name = ReadAppSettings.ToString("ManageAllarme.QueueInfoObj.Name", "UCS_CONFIG");
				QueueInfoObj.Type = QueueType.QTX;

				MWPQueueClass QueueObj = QMgrObj.QOpen(QueueInfoObj, QueueOpenType.OPEN_OUT, ref pwd);
				rc = QMgrObj.Error;
				if (rc != RetCodes.RC_OK)
					continue;

				// Standard write
				MWPPutMsgOptionClass PutMsgOptObj = new MWPPutMsgOptionClass();
				PutMsgOptObj.Options = PutOptionsType.DEFAULT_MODE;

				// Assemble the message
				MWPMessageClass MsgObj = new MWPMessageClass();
				MsgObj.Type = MsgTypes.APPLICATION;
				MsgObj.Body = msg;
				MsgObj.Length = MsgObj.Body.Length;

				QueueObj.PutMessage(PutMsgOptObj, MsgObj);
				rc = QueueObj.Error;
				if (rc != RetCodes.RC_OK)
				{
					QueueObj.Close();
					QMgrObj.Disconnect();
					throw new MWPException("Put Message: " + rc.ToString());
				}

				QueueObj.Close();
			}

			QMgrObj.Disconnect();
		}

		public void ManageAllarmeConDataInizioDataFine(List<string> C2PList, List<MWPDataLTS> recList, int maxGroup)
		{
			// Connect to queue manager
			MWPCoreClass CoreObj = new MWPCoreClass();
			CoreObj.QMgrName = ReadAppSettings.ToString("MWPNET.CoreObj.QMgrName", "ITRS_PROD");
			CoreObj.UserName = ReadAppSettings.ToString("MWPNET.CoreObj.UserName", "ROOT");
			CoreObj.ApplicationName = ReadAppSettings.ToString("MWPNET.CoreObj.ApplicationName", "ITRSWeb");

			string pwd = "";
			MWPQMgrClass QMgrObj = CoreObj.Connect(ref pwd);
			RetCodes rc = CoreObj.Error;
			if (rc != RetCodes.RC_OK)
				throw new MWPException("Connect: " + rc.ToString());

			foreach (List<MWPDataLTS> smallRecList in U.Group(recList, maxGroup))
			{
				string msg = ProduceTargaMessage(smallRecList);

				foreach (string qmgr in C2PList)
				{
					Log.Write("ManageAllarmeConDataInizioDataFine QMgrName={0}", qmgr);

					// Open the queue
					MWPQueueInfoClass QueueInfoObj = new MWPQueueInfoClass();
					QueueInfoObj.QMgrName = qmgr;
					QueueInfoObj.Name = ReadAppSettings.ToString("ManageAllarme.QueueInfoObj.Name", "UCS_CONFIG");
					QueueInfoObj.Type = QueueType.QTX;

					MWPQueueClass QueueObj = QMgrObj.QOpen(QueueInfoObj, QueueOpenType.OPEN_OUT, ref pwd);
					rc = QMgrObj.Error;
					if (rc != RetCodes.RC_OK)
					{
						Log.Write("ManageAllarmeConDataInizioDataFine QMgrName={0} ritorna RC={1}", qmgr, rc);
						continue;
					}

					// Standard write
					MWPPutMsgOptionClass PutMsgOptObj = new MWPPutMsgOptionClass();
					PutMsgOptObj.Options = PutOptionsType.DEFAULT_MODE;

					// Assemble the message
					MWPMessageClass MsgObj = new MWPMessageClass();
					MsgObj.Type = MsgTypes.APPLICATION;
					MsgObj.Body = msg;
					MsgObj.Length = MsgObj.Body.Length;

					QueueObj.PutMessage(PutMsgOptObj, MsgObj);
					rc = QueueObj.Error;
					if (rc != RetCodes.RC_OK)
					{
						QueueObj.Close();
						QMgrObj.Disconnect();
						throw new MWPException("Put Message: " + rc.ToString());
					}

					QueueObj.Close();
				}
			}

			QMgrObj.Disconnect();
		}
		public void ManageAllarmeConDataInizioDataFine(List<string> C2PList, List<MWPDataLTS> recList)
		{
			// Connect to queue manager
			MWPCoreClass CoreObj = new MWPCoreClass();
			CoreObj.QMgrName = ReadAppSettings.ToString("MWPNET.CoreObj.QMgrName", "ITRS_PROD");
			CoreObj.UserName = ReadAppSettings.ToString("MWPNET.CoreObj.UserName", "ROOT");
			CoreObj.ApplicationName = ReadAppSettings.ToString("MWPNET.CoreObj.ApplicationName", "ITRSWeb");

			string pwd = "";
			MWPQMgrClass QMgrObj = CoreObj.Connect(ref pwd);
			RetCodes rc = CoreObj.Error;
			if (rc != RetCodes.RC_OK)
				throw new MWPException("Connect: " + rc.ToString());

			List<MWPDataLTS> smallRecList = recList;
			{
				string msg = ProduceTargaMessage(smallRecList);

				foreach (string qmgr in C2PList)
				{
					Log.Write("ManageAllarmeConDataInizioDataFine QMgrName={0}", qmgr);

					// Open the queue
					MWPQueueInfoClass QueueInfoObj = new MWPQueueInfoClass();
					QueueInfoObj.QMgrName = qmgr;
					QueueInfoObj.Name = ReadAppSettings.ToString("ManageAllarme.QueueInfoObj.Name", "UCS_CONFIG");
					QueueInfoObj.Type = QueueType.QTX;

					MWPQueueClass QueueObj = QMgrObj.QOpen(QueueInfoObj, QueueOpenType.OPEN_OUT, ref pwd);
					rc = QMgrObj.Error;
					if (rc != RetCodes.RC_OK)
					{
						Log.Write("ManageAllarmeConDataInizioDataFine QMgrName={0} ritorna RC={1}", qmgr, rc);
						continue;
					}

					// Standard write
					MWPPutMsgOptionClass PutMsgOptObj = new MWPPutMsgOptionClass();
					PutMsgOptObj.Options = PutOptionsType.DEFAULT_MODE;

					// Assemble the message
					MWPMessageClass MsgObj = new MWPMessageClass();
					MsgObj.Type = MsgTypes.APPLICATION;
					MsgObj.Body = msg;
					MsgObj.Length = MsgObj.Body.Length;

					QueueObj.PutMessage(PutMsgOptObj, MsgObj);
					rc = QueueObj.Error;
					if (rc != RetCodes.RC_OK)
					{
						QueueObj.Close();
						QMgrObj.Disconnect();
						throw new MWPException("Put Message: " + rc.ToString());
					}

					QueueObj.Close();
				}
			}

			QMgrObj.Disconnect();
		}

		public void ManageAllarmeConDataInizioDataFine(string targa, string nazionalita, DateTime dataOraInizio, DateTime dataOraFine, List<string> C2PList, bool Add, int maxGroup)
		{
			List<MWPDataLTS> recList = new List<MWPDataLTS>();
			MWPDataLTS rec = new MWPDataLTS();
			rec.targa = targa;
			rec.nazionalita = nazionalita;
			rec.dataOraInizio = dataOraInizio;
			rec.dataOraFine = dataOraFine;
			rec.AddCommand = Add;
			recList.Add(rec);

			ManageAllarmeConDataInizioDataFine(C2PList, recList, maxGroup);
		}

		public class ManageAllarmeList : IDisposable
		{
			List<MWPDataLTS> _recList;
			readonly List<string> _C2PList;

			public ManageAllarmeList(List<string> C2PList)
			{
				_recList = new List<MWPDataLTS>();
				_C2PList = C2PList;
			}

			public void Add(string targa, string nazionalita, DateTime dataOraInizio, DateTime dataOraFine, bool Add)
			{
				MWPDataLTS rec = new MWPDataLTS();
				rec.targa = targa;
				rec.nazionalita = nazionalita;
				rec.dataOraInizio = dataOraInizio;
				rec.dataOraFine = dataOraFine;
				rec.AddCommand = Add;
				_recList.Add(rec);

				int kkk = ReadAppSettings.ToInt32("ManageAllarmeList_MaxSize", 10000);
				if (_recList.Count >= kkk)
					Flush();
			}

			public void Flush()
			{
				if (_recList.Count > 0)
				{
					MWPInterface mwp = new MWPInterface();
					mwp.ManageAllarmeConDataInizioDataFine(_C2PList, _recList);
					_recList = new List<MWPDataLTS>();
				}
			}

			public void Dispose()
			{
				Flush();
			}
		}

		private static string ProduceTargaMessage(List<MWPDataLTS> entry)
		{
			StringWriter sw = new StringWriter();
			XmlTextWriter xw = new XmlTextWriter(sw);

			xw.Formatting = Formatting.Indented;
			xw.Indentation = 1;
			xw.IndentChar = '\t';
			xw.QuoteChar = '"';

			xw.WriteStartDocument(true /*standalone*/);
			xw.WriteStartElement("MSG");
			xw.WriteAttributeString("type", "XX_GA_ALL");

			for (int i = 0; i < entry.Count; ++i)
			{
				xw.WriteStartElement("LIST");
				xw.WriteAttributeString("targa", entry[i].targa);
				xw.WriteAttributeString("nazionalita", entry[i].nazionalita);
				if (entry[i].AddCommand)
				{
					xw.WriteAttributeString("operazione", "ADD");

					xw.WriteAttributeString("data_ora_inizio", entry[i].dataOraInizio.ToString(@"dd/MM/yyyy HH\:mm"));
					xw.WriteAttributeString("data_ora_fine", entry[i].dataOraFine.ToString(@"dd/MM/yyyy HH\:mm"));
					xw.WriteAttributeString("codice_allarme", "99");
					xw.WriteAttributeString("flag_allarmi_old", "1");

				}
				else
				{
					xw.WriteAttributeString("operazione", "DEL");

					xw.WriteAttributeString("data_ora_inizio", string.Empty);
					xw.WriteAttributeString("data_ora_fine", string.Empty);
					xw.WriteAttributeString("codice_allarme", string.Empty);
					xw.WriteAttributeString("flag_allarmi_old", string.Empty);

				}
				xw.WriteEndElement();
			}

			xw.WriteEndElement();

			xw.WriteEndDocument();

			xw.Flush();
			xw.Close();

			string tt = sw.ToString();
			tt = tt.Replace("utf-16", "UTF-8");
			return tt;
		}

		private static string ProduceTargaMessage(string targa, string nazionalita, DateTime dataOraInizio, DateTime dataOraFine, bool Add)
		{
			MWPDataLTS r = new MWPDataLTS();
			r.targa = targa;
			r.nazionalita = nazionalita;
			r.dataOraInizio = dataOraInizio;
			r.dataOraFine = dataOraFine;
			r.AddCommand = Add;

			List<MWPDataLTS> lr = new List<MWPDataLTS>();
			lr.Add(r);

			return ProduceTargaMessage(lr);
		}

		public void AllineamentoMassivoC2P(List<MWPC2PInfo> C2PList, string fileZip)
		{
			// Connect to queue manager
			MWPCoreClass CoreObj = new MWPCoreClass();
			CoreObj.QMgrName = ReadAppSettings.ToString("MWPNET.CoreObj.QMgrName", "ITRS_PROD");
			CoreObj.UserName = ReadAppSettings.ToString("MWPNET.CoreObj.UserName", "ROOT");
			CoreObj.ApplicationName = ReadAppSettings.ToString("MWPNET.CoreObj.ApplicationName", "ITRSWeb");

			string pwd = "";
			MWPQMgrClass QMgrObj = CoreObj.Connect(ref pwd);

			RetCodes rc = CoreObj.Error;
			if (rc != RetCodes.RC_OK)
				throw new MWPException("Connect: " + rc.ToString());

			try
			{

				string SrcFile = Path.GetFileName(fileZip);
				foreach (MWPC2PInfo c in C2PList)
					try
					{
						SendFileTransferMessage(c, QMgrObj, SrcFile);
					}
					catch
					{
					}
			}
			finally
			{
				QMgrObj.Disconnect();
			}
		}

		private void SendFileTransferMessage(MWPC2PInfo c, MWPQMgrClass QMgrObj, string SrcFileName)
		{
			MWPQueueInfoClass QueueInfoObj = new MWPQueueInfoClass();
			QueueInfoObj.QMgrName = c.QmgrName;
			QueueInfoObj.Name = ReadAppSettings.ToString("AllineamentoMassivoC2P.QueueInfoObj.Name", "MW_FTS_IN_QUEUE");
			QueueInfoObj.Type = QueueType.QREMOTE;

			string pwd = string.Empty;
			MWPQueueClass QueueObj = QMgrObj.QOpen(QueueInfoObj, QueueOpenType.OPEN_OUT, ref pwd);
			if (QMgrObj.Error != RetCodes.RC_OK)
				return;

			MWPFileTransferRequestClass FTSR = new MWPFileTransferRequestClass();
			FTSR.FileDescription = ReadAppSettings.ToString("AllineamentoMassivoC2P.FTSR.FileDescription", "Trasferimento file XML di reset C2P");
			FTSR.SenderApplName = ReadAppSettings.ToString("AllineamentoMassivoC2P.FTSR.SenderApplName", "Allineamento massivo");
			FTSR.SourceQMgrName = QMgrObj.RealName;
			FTSR.SrcDirectory = ReadAppSettings.ToString("AllineamentoMassivoC2P.FTSR.SrcDirectory", "/c2plts");
			FTSR.SrcFileName = SrcFileName;

			FTSR.TargetDirectoryId = ReadAppSettings.ToString("AllineamentoMassivoC2P.FTSR.TargetDirectoryId", "SARC");
			FTSR.TargetQMgrName = ReadAppSettings.ToString("AllineamentoMassivoC2P.FTSR.TargetQMgrName", c.QmgrName);
			FTSR.TargetQueueName = ReadAppSettings.ToString("AllineamentoMassivoC2P.FTSR.TargetQueueName", "DISCARDQUEUE");
			FTSR.UserName = ReadAppSettings.ToString("AllineamentoMassivoC2P.FTSR.UserName", "ROOT");
			FTSR.TransferType = "B";

			QueueObj.PutFileTransferRequest(FTSR, ref pwd, ref pwd);

			QueueObj.Close();
		}
	}


	public class MWPAttivazioneA2
	{
		public string BuildAttivazioneMessage(DateTime di, DateTime df, int deltaGiorni, string tipoVeicolo, string corsie)
		{
			StringWriter sw = new StringWriter();
			XmlTextWriter xw = new XmlTextWriter(sw);

			xw.Formatting = Formatting.Indented;
			xw.Indentation = 1;
			xw.IndentChar = '\t';
			xw.QuoteChar = '"';

			xw.WriteStartDocument(true /*standalone*/);
			{
				xw.WriteStartElement("AttivazioneA2");
				{

					xw.WriteElementString("DataOraInizio", di.ToString(@"dd/MM/yyyy HH\:mm") + ":00");
					xw.WriteElementString("DataOraFine", df.ToString(@"dd/MM/yyyy HH\:mm") + ":00");

					int deltaMesi = deltaGiorni / 30;
					deltaGiorni = deltaGiorni % 30;

					xw.WriteElementString("Delta", deltaMesi.ToString() + ":" + deltaGiorni.ToString());

					if (tipoVeicolo != null)
						xw.WriteElementString("TipoVeicolo", tipoVeicolo);
					else
						xw.WriteElementString("TipoVeicolo", "");

					if (corsie != null)
						xw.WriteElementString("Corsia", corsie);
					else
						xw.WriteElementString("Corsia", "");
				}
				xw.WriteEndElement();
			}
			xw.WriteEndDocument();

			xw.Flush();
			xw.Close();

			string tt = sw.ToString();
			tt = tt.Replace("utf-16", "UTF-8");
			return tt;

		}

		public string BuildDisattivazioneMessage()
		{
			StringWriter sw = new StringWriter();
			XmlTextWriter xw = new XmlTextWriter(sw);

			xw.Formatting = Formatting.Indented;
			xw.Indentation = 1;
			xw.IndentChar = '\t';
			xw.QuoteChar = '"';

			xw.WriteStartDocument(true /*standalone*/);
			{
				xw.WriteStartElement("DisattivazioneA2");
				xw.WriteEndElement();
			}
			xw.WriteEndDocument();

			xw.Flush();
			xw.Close();

			string tt = sw.ToString();
			tt = tt.Replace("utf-16", "UTF-8");
			return tt;
		}

		public void SendMsg(string msgBody, string QmgrName)
		{
			// Connect to queue manager
			MWPCoreClass CoreObj = new MWPCoreClass();
			CoreObj.QMgrName = ReadAppSettings.ToString("MWPNET.CoreObj.QMgrName", "ITRS_PROD");
			CoreObj.UserName = ReadAppSettings.ToString("MWPNET.CoreObj.UserName", "ROOT");
			CoreObj.ApplicationName = ReadAppSettings.ToString("MWPNET.CoreObj.ApplicationName", "ITRSWeb");

			string pwd = "";
			MWPQMgrClass QMgrObj = CoreObj.Connect(ref pwd);
			RetCodes rc = CoreObj.Error;
			if (rc != RetCodes.RC_OK)
				throw new MWPException("Connect: " + rc.ToString());

			if (true)
			{
				MWPQueueInfoClass QueueInfoObj = new MWPQueueInfoClass();
				QueueInfoObj.QMgrName = QmgrName;
				QueueInfoObj.Name = ReadAppSettings.ToString("ManageAllarme.QueueInfoObj.Name", "UCS_CONFIG");
				QueueInfoObj.Type = QueueType.QTX;

				MWPQueueClass QueueObj = QMgrObj.QOpen(QueueInfoObj, QueueOpenType.OPEN_OUT, ref pwd);
				rc = QMgrObj.Error;
				if (rc == RetCodes.RC_OK)
				{
					// Standard write
					MWPPutMsgOptionClass PutMsgOptObj = new MWPPutMsgOptionClass();
					PutMsgOptObj.Options = PutOptionsType.DEFAULT_MODE;

					// Assemble the message
					MWPMessageClass MsgObj = new MWPMessageClass();
					MsgObj.Type = MsgTypes.APPLICATION;
					MsgObj.Body = msgBody;
					MsgObj.Length = MsgObj.Body.Length;

					QueueObj.PutMessage(PutMsgOptObj, MsgObj);
					rc = QueueObj.Error;
					if (rc != RetCodes.RC_OK)
					{
						QueueObj.Close();
						QMgrObj.Disconnect();
						throw new MWPException("Put Message: " + rc.ToString());
					}

					QueueObj.Close();
				}
			}

			QMgrObj.Disconnect();
		}
	}
}


