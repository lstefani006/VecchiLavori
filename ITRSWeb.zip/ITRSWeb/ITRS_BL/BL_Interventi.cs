using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Configuration;
using System.Text;
using ITRS_BL.IDal;
using System.Xml.Serialization;
using System.IO;

namespace ITRS_BL
{
	[DataObjectAttribute]
	public partial class BL_Interventi : Component, IJobRunner
	{
		#region Costruttori
		public BL_Interventi()
		{
			InitializeComponent();
		}

		public BL_Interventi(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}
		#endregion

		#region Start Job Intervento - qui si scrive in QJOBS e QJOBS_INTERVENTI
		[Serializable]
		public class JobArgs
		{
			public string Targa;
			public string Nazionalita;
			public DateTime? DataInizioRicerca;
			public DateTime? DataFineRicerca;
			public string Motivo;
			public string Note;
			public int IdCoa = -1;

			public void CopyFrom(JobArgs src)
			{
				this.Targa = src.Targa;
				this.Nazionalita = src.Nazionalita;
				this.DataInizioRicerca = src.DataInizioRicerca;
				this.DataFineRicerca = src.DataFineRicerca;
				this.Motivo = src.Motivo;
				this.Note = src.Note;
				this.IdCoa = src.IdCoa;
			}
		}

		/// <summary>
		/// Inizia un intervento.
		/// Se esiste gia` l'intervento per quella targa ritorna l'intervento
		/// gia` esistente.
		/// Se ritorna <c>null</c> allora il job non e` stato lanciato
		/// </summary>
		/// <param name="sd"></param>
		/// <param name="jobUser"></param>
		/// <returns></returns>
		public string StartIntervento(JobArgs sd, string jobUser)
		{
			Debug.Assert(sd.IdCoa >= 0);

			// la lista degli interventi per un utente
			// fa vedere SOLO gli interventi che gli competono.

			// un op. quando crea un intervento
			// 1) specifica una targa/nazionalita/motivo/note.
			// 2) chiamo crea intervento
			// 3) se esiste in LTS un entry per quell'utente non si fa niente.
			// 4) se non esiste
			// 4a) inserisco record in LTS con note/motivi
			// 4b) controllo se esiste gia` un intervento sulla stessa targa.
			// 4c) se no creo il job.
			//

			/*
			 * Le query sono da fare in ordine temporale INVERSO in modo che il transito piu` recente
			 * sia disponibile nella prima query.
			 * Il primo transito verra` copiato nella tb che contiene l'ultimo allarme che viene riempita
			 * con la sp chiamata a fronte di un allarme (solo se NON c'e` gia` presente un allarme).
			 * La zona della maschera rinfrescata in polling viene riempita con i dati 
			 * disponibile in quest'ultima tabella.
			*/

			/*
			 * Cancellazione: dalla lista degli interventi per quell'utente e` disponibile il tasto
			 * cancella intervento: 
			 * a) cancella l'entry in LTS
			 * b) se non esistono piu` altri interventi cancello la roba dell'intervento. (forse)
			 * 
			 * Rimane la cancellazione dati job con purge. Quella cancella anche in LTS.
			 */

			try
			{
				string jobId = BLQueueJobs.CreateJobId();
				string jobArgsString = BLQueueJobs.CreateJobArgsString(sd);

				IDalInterventi dal = DalProvider.DAL.CreateDalInterventi();

				// chiamo GetQmgrForMWP per ottenere la lista dei QMgr che devono essere avvisati
				// quando una nuova targa sta per essere immessa nella LTS.
				// questa chiamata deve essere effettuata PRIMA della successiva Create!
				// qui si ottiene la lista di tutti i C2P se quella targa/nazionalita
				// non e` inclusa nella LTS
				bool ignoraA2 = true;
				List<MWPC2PInfo> qmgrList = dal.GetQmgrForMWP(sd.Targa, sd.Nazionalita, ignoraA2);


				IJobRunner jr = this;
				jobId = dal.Create(jobId, jr.JobType, jobArgsString, jobUser, sd.Targa, sd.Nazionalita, sd.Note, sd.Motivo, sd.IdCoa);
				if (string.IsNullOrEmpty(jobId))
					return null; // coda piena o altro... job non lanciato

				if (qmgrList.Count > 0)
				{
					MWPServices.MWPInterface mwp = new ITRS_BL.MWPServices.MWPInterface();
					mwp.ManageAllarmeIntervento(sd.Targa, sd.Nazionalita, qmgrList, true);
				}

				return jobId;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BL_Interventi.StartIntervento");
				throw;
			}
		}
		#endregion

		#region Esecuzione Job - il risultato viene messo in QJOBRES_INTERVENTI
		private void ExecuteQueryIntervento(string jobId, JobArgs jobArgs)
		{
			BLQueueJobs bl = new BLQueueJobs();

			System.Globalization.CultureInfo it = new System.Globalization.CultureInfo("it-it");


			try
			{
				DateTime di;
				DateTime df;

				if (jobArgs.DataInizioRicerca.HasValue)
					di = jobArgs.DataInizioRicerca.Value.Date;// data alle ore 0:0:0
				else
				{
					int PURGER_EXPTIME = 180;
					BL_Parametri blPar = new BL_Parametri();
					List<BL_Parametri.Parametro> lstPar = blPar.GetParametri();
					for (int i = 0; i < lstPar.Count; ++i)
						if (lstPar[i].ParTipo == "PURGER_EXPTIME")
						{
							PURGER_EXPTIME = (int)lstPar[i].ParValue;
							break;
						}

					di = DateTime.Now.Date.AddDays(-1 * PURGER_EXPTIME - 1);
				}

				if (jobArgs.DataFineRicerca.HasValue)
					df = jobArgs.DataFineRicerca.Value.Date.AddDays(1); // per fare Data < :df
				else
					df = DateTime.Now.Date.AddDays(1); // ricerco fino a domani.

				int DaysStep = ReadAppSettings.ToInt32("BL_Interverti_DaysStep", 7);

				int totalDays = (int)(df.Subtract(di).Days + .5);
				int totalSteps = totalDays / DaysStep;
				if ((totalDays % DaysStep) > 0)
					totalSteps += 1;


				BLQueueJobs.JobStatus status = BLQueueJobs.JobStatus.RUN;

				IDalInterventi dal = DalProvider.DAL.CreateDalInterventi();

				int recordFound = 0;

				//DateTime ti = di;
				//DateTime tf = di.AddDays(DaysStep);

				DateTime tf = df;
				DateTime ti = df.Subtract(new TimeSpan(DaysStep, 0, 0, 0));

				bool primoTransitoLetto = false;

				for (int currentStep = 0; currentStep < totalSteps; currentStep++)
				{
					System.Threading.Thread.Sleep(ReadAppSettings.ToInt32("BL_Interventi.Wait", 100));

					// ri-leggo dal DB lo stato per vedere se qualcuno ha richiesto l'abort.
					status = bl.GetStatus(jobId);
					if (status == BLQueueJobs.JobStatus.ABRQ)
					{
						status = BLQueueJobs.JobStatus.ABAK;
						bl.Progress(jobId, status, null, null, null, null);
						break;
					}

					string prgMsg = string.Format("Ricerca transiti dal {0} al {1} in corso.", ti.ToString("G", it), tf.ToString("G", it));
					if (currentStep == 0)
					{
						// sono al primo passo metto in RUN il job aggiorno 
						status = BLQueueJobs.JobStatus.RUN;
						bl.Progress(jobId, status, prgMsg, totalSteps, currentStep + 1, null);
					}
					else
					{
						// qui potrei essere in RUN o in RRES
						// ossia potrei aver gia` letto o no record dal DB
						bl.Progress(jobId, status, prgMsg, totalSteps, currentStep + 1, null);
					}

					JobArgs dalArgs = new JobArgs();
					dalArgs.CopyFrom(jobArgs);
					dalArgs.DataInizioRicerca = ti;
					dalArgs.DataFineRicerca = tf;
					recordFound += dal.QueryIntervento(jobId, dalArgs, ref primoTransitoLetto);

					if (recordFound > 0)
					{
						// ho dei risultati intermedi
						status = BLQueueJobs.JobStatus.RRES;
						bl.Progress(jobId, status, null, null, null, recordFound);
					}

					tf = ti;
					ti = tf.Subtract(new TimeSpan(DaysStep, 0, 0, 0));
				}


				string prgMsg2 = string.Format("Ricerca transiti terminata.");
				bl.Progress(jobId, BLQueueJobs.JobStatus.END, prgMsg2, null, null, null);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "BL_Interventi.ExecuteQueryIntervento");
				bl.Progress(jobId, BLQueueJobs.JobStatus.ERR, "Ricerca transiti terminata con errore.", null, null, null);
				throw;
			}
		}

		#endregion

		#region Query risultati - qui si legge da QJOBRES_INTERVENTI


		public int GetResultJobInterventoCount(string jobId)
		{
			BLQueueJobs bl = new BLQueueJobs();
			int? r = bl.GetResRecordCount(jobId);
			if (r.HasValue)
				return r.Value;
			return 0; // ritorno 0 per dire che non ci sono record
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<ResultQueryIntervento> GetResultJobIntervento(string jobId, string sortColumns, int startRowIndex, int maximumRows)
		{
			// aggiorno l'accesso ai dati di questo job.
			using (BLQueueJobs blq = new BLQueueJobs())
			{
				blq.Access(jobId);
			}

			if (string.IsNullOrEmpty(sortColumns))
				sortColumns = "DATAORARILEVAMENTO";
			IDalInterventi dal = DalProvider.DAL.CreateDalInterventi();
			List<ResultQueryIntervento> r = dal.GetResultJobIntervento(jobId, sortColumns, startRowIndex, maximumRows);
			return r;
		}
		[DataObjectMethod(DataObjectMethodType.Select)]
		public InterventiQueueJob GetRunningJobData(string jobId)
		{
			IDalInterventi dal = DalProvider.DAL.CreateDalInterventi();
			return dal.GetRunningJobData(jobId);
		}

		[DataObjectMethod(DataObjectMethodType.Delete)]
		public void CancellaIntervento(int idCoa, string targa, string nazionalita)
		{
			try
			{
				IDalInterventi dal = DalProvider.DAL.CreateDalInterventi();
				List<MWPC2PInfo> qmgrList = dal.CancellaInterventoPerCoa(idCoa, targa, nazionalita);

				if (qmgrList.Count > 0)
				{
					MWPServices.MWPInterface mwp = new ITRS_BL.MWPServices.MWPInterface();
					mwp.ManageAllarmeIntervento(targa, nazionalita, qmgrList, false);
				}

			}
			catch (ApplicationException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw new ApplicationException("Errore nella cancellazione del record", ex);
			}
		}

		#endregion

		#region Query per ottenere la lista degli interventi di un COA

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<ListaInterventiPerCoaRes> ListaInterventiPerCoa(int IdCoa, string sortColumns)
		{
			IDalInterventi dal = DalProvider.DAL.CreateDalInterventi();
			List<ListaInterventiPerCoaRes> r = dal.ListaInterventiPerCoa(IdCoa);


			Comparison<ListaInterventiPerCoaRes> s = delegate(ListaInterventiPerCoaRes a, ListaInterventiPerCoaRes b)
			{
				if (a == null && b == null) return 0;
				if (a == null) return -1;
				if (b == null) return +1;

				string[] g = sortColumns.Split();

				string col = g[0].ToUpper();
				int dir = 1;
				if (g.Length == 2) dir = g[1].ToUpper() == "DESC" ? -1 : 1;

				int c = 0;

				switch (col)
				{
				case "TARGA":
					c = dir * string.Compare(a.Targa, b.Targa);
					break;

				case "NAZIONALITA":
					c = dir * string.Compare(a.Nazionalita, b.Nazionalita);
					if (c == 0)
						c = string.Compare(a.Targa, b.Targa);
					break;
				case "QJSTATUS":
					c = dir * string.Compare(a.QjStatus.ToString(), b.QjStatus.ToString());
					if (c == 0)
						c = string.Compare(a.Targa, b.Targa);
					break;

				default:
					break;
				}

				return c;

			};
			r.Sort(s);

			return r;
		}

		#endregion

		#region IJobRunner Members - questa interfaccia permette a BLQueueJobs in maniera virtuale

		void IJobRunner.ExecuteJob(string jobId, object jobArgs)
		{
			this.ExecuteQueryIntervento(jobId, (JobArgs)jobArgs);
		}

		Type IJobRunner.GetJobArgsType() { return typeof(JobArgs); }
		Type IJobRunner.GetQueueJobType() { return typeof(InterventiQueueJob); }

		string IJobRunner.JobType { get { return "INTERVENTI"; } }

		QueueJob IJobRunner.GetJobData(QueueJob baseQueueJobData)
		{
			IDalInterventi dal = DalProvider.DAL.CreateDalInterventi();
			QueueJob q = dal.GetRunningJobData(baseQueueJobData.Id);

			if (q != null)
			{
				Debug.Assert(q != null, "Problemi nella ricerca del job " + baseQueueJobData.Id);
				q.DeserializeArgs(typeof(JobArgs));
			}

			return q;
		}

		void IJobRunner.DeleteJob(string jobId)
		{
			IDalInterventi dal = DalProvider.DAL.CreateDalInterventi();

			string targa;
			string nazionalita;
			List<MWPC2PInfo> qmgrList = dal.DeleteIntervento(jobId, out targa, out nazionalita);

			if (qmgrList.Count > 0)
			{
				MWPServices.MWPInterface mwp = new ITRS_BL.MWPServices.MWPInterface();
				mwp.ManageAllarmeIntervento(targa, nazionalita, qmgrList, false);
			}

		}

		#endregion
	}

	[Serializable]
	public class ResultQueryIntervento
	{
		public string JobId
		{
			get { return _JobId; }
			set { _JobId = value; }
		}

		public string Targa
		{
			get { return _Targa; }
			set { _Targa = value; }
		}

		public string Nazionalita
		{
			get { return _Nazionalita; }
			set { _Nazionalita = value; }
		}

		public DateTime DataOraRilevamento
		{
			get { return _DataOraRilevamento; }
			set { _DataOraRilevamento = value; }
		}

		public string C2pDescrizione
		{
			get { return _C2pDescrizione; }
			set { _C2pDescrizione = value; }
		}

		public Direzione Direzione
		{
			get { return _Direzione; }
			set { _Direzione = value; }
		}

		public TipoVarco TipoVarco
		{
			get { return _TipoVarco; }
			set { _TipoVarco = value; }
		}

		public StatoTransito StatoTransito
		{
			get { return _StatoTransito; }
			set { _StatoTransito = value; }
		}

		public bool EventoAssociatoAlTransito
		{
			get { return _EventoAssociatoAlTransito; }
			set { _EventoAssociatoAlTransito = value; }
		}

		public int? IdEvento
		{
			get { return _IdEvento; }
			set { _IdEvento = value; }
		}

		public DateTime? DataOraInserimento
		{
			get { return _DataOraInserimento; }
			set { _DataOraInserimento = value; }
		}

		public StatoAllarme? StatoAllarme
		{
			get { return _StatoAllarme; }
			set { _StatoAllarme = value; }
		}

		private string _JobId;
		private string _Targa;
		private string _Nazionalita;
		private DateTime _DataOraRilevamento;
		private TipoVarco _TipoVarco;
		private StatoTransito _StatoTransito;
		private bool _EventoAssociatoAlTransito;


		int? _IdEvento;
		DateTime? _DataOraInserimento;
		StatoAllarme? _StatoAllarme;
		private string _C2pDescrizione;
		private Direzione _Direzione;
	}

	[Serializable]
	public class ListaInterventiPerCoaRes
	{
		private string _Targa;
		private string _Nazionalita;
		private string _Note;
		private string _Motivo;
		private BLQueueJobs.JobStatus _QjStatus;

		public string Targa
		{
			get { return _Targa; }
			set { _Targa = value; }
		}

		public string Nazionalita
		{
			get { return _Nazionalita; }
			set { _Nazionalita = value; }
		}
		public string Note
		{
			get { return _Note; }
			set { _Note = value; }
		}
		public string Motivo
		{
			get { return _Motivo; }
			set { _Motivo = value; }
		}
		public BLQueueJobs.JobStatus QjStatus
		{
			get { return _QjStatus; }
			set { _QjStatus = value; }
		}
	}

	[Serializable]
	public class InterventiQueueJob : QueueJob
	{
		public InterventiQueueJob()
		{
		}

		public BL_Interventi.JobArgs JobArgs
		{
			get { return (BL_Interventi.JobArgs)base._argsData; }
		}

		protected override string GetJobArgsHtml()
		{
			try
			{
				string g;
				//g = string.Format("<span>Targa: </span><span>{0}</span>&nbsp;<span>Nazionalit&agrave;: </span><span>{1}</span>", 
				//	JobArgs.Targa, JobArgs.Nazionalita);

				g = "";
				g += "<table>";
				g += "<tr><td>Targa:</td><td>{0}</td></tr>";
				g += "<tr><td>Nazionalit&agrave;:</td><td>{1}</td></tr>";
				g += "</table>";

				if (JobArgs.Nazionalita != null)
					g = string.Format(g, JobArgs.Targa, JobArgs.Nazionalita);
				else
					g = string.Format(g, JobArgs.Targa, "");
				return g;
			}
			catch (Exception ecx)
			{
				ecx.ToString();
				throw;
			}
		}

		public string Targa
		{
			get { return _Targa; }
			set { _Targa = value; }
		}

		public string Nazionalita
		{
			get { return _Nazionalita; }
			set { _Nazionalita = value; }
		}

		public DateTime? DataOraRilevamento
		{
			get { return _DataOraRilevamento; }
			set { _DataOraRilevamento = value; }
		}

		public string Descrizione
		{
			get { return _Descrizione; }
			set { _Descrizione = value; }
		}

		public Direzione? Direzione
		{
			get { return _Direzione; }
			set { _Direzione = value; }
		}

		public TipoVarco? TipoVarco
		{
			get { return _TipoVarco; }
			set { _TipoVarco = value; }
		}

		public StatoTransito? StatoTransito
		{
			get { return _StatoTransito; }
			set { _StatoTransito = value; }
		}

		public bool? EventoAssociatoAlTransito
		{
			get { return _EventoAssociatoAlTransito; }
			set { _EventoAssociatoAlTransito = value; }
		}

		public int? IdEvento
		{
			get { return _IdEvento; }
			set { _IdEvento = value; }
		}

		public DateTime? DataOraInserimento
		{
			get { return _DataOraInserimento; }
			set { _DataOraInserimento = value; }
		}

		public StatoAllarme? StatoAllarme
		{
			get { return _StatoAllarme; }
			set { _StatoAllarme = value; }
		}


		string _Targa;
		string _Nazionalita;
		DateTime? _DataOraRilevamento;
		string _Descrizione;
		Direzione? _Direzione;
		TipoVarco? _TipoVarco;
		StatoTransito? _StatoTransito;

		// dati dell'eventuale allarme di tipo TS (transito segnalato)
		bool? _EventoAssociatoAlTransito;
		int? _IdEvento;
		DateTime? _DataOraInserimento;
		StatoAllarme? _StatoAllarme;

	}
}
