using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using ITRS_BL.IDal;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Schema;

namespace ITRS_BL
{
	public partial class BLTargheBianche : Component
	{
		public BLTargheBianche()
		{
			InitializeComponent();
		}

		public BLTargheBianche(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		/// <summary>
		/// Lista delle targhe VALIDE 
		/// </summary>
		/// <param name="columnsSort"></param>
		/// <param name="startRowIndex"></param>
		/// <param name="maximumRows"></param>
		/// <returns></returns>
		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<TargheBianche> GetListaTargheBianche(string columnsSort, int startRowIndex, int maximumRows)
		{
			try
			{
				if (string.IsNullOrEmpty(columnsSort))
					columnsSort = "IdLTS";

				if (string.Compare(columnsSort, "TsInizioValidita", true) == 0) columnsSort = "DATAORAINIZIOVALIDITA";
				else if (string.Compare(columnsSort, "TsInizioValidita DESC") == 0) columnsSort = "DATAORAINIZIOVALIDITA DESC";

				if (string.Compare(columnsSort, "TsFineValidita", true) == 0) columnsSort = "DATAORAFINEVALIDITA";
				else if (string.Compare(columnsSort, "TsFineValidita DESC") == 0) columnsSort = "DATAORAFINEVALIDITA DESC";

				IDalTargheBianche t = DalProvider.DAL.CreateDalTargheBianche();
				return t.GetLista(columnsSort, startRowIndex, maximumRows, DateTime.Now);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetListaTargheBianche");
				throw;
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public TargheBianche GetTargheBianche(string Targa, string Nazionalita, int idLTS)
		{
			try
			{
				IDalTargheBianche t = DalProvider.DAL.CreateDalTargheBianche();
				TargheBianche r = new TargheBianche();
				r.IdLTS = idLTS;
				r.Targa = Targa;
				r.Nazionalita = Nazionalita;
				return t.GetRecord(r);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetTargheBianche");
				throw;
			}
		}

		public int GetTargheBiancheCount()
		{
			try
			{
				IDalTargheBianche t = DalProvider.DAL.CreateDalTargheBianche();
				return t.GetCount(DateTime.Now);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetTargheBiancheCount");
				throw;
			}

		}

		[DataObjectMethod(DataObjectMethodType.Delete)]
		public void CancellaTargheBianche(TargheBianche r)
		{
			try
			{
				IDalTargheBianche t = DalProvider.DAL.CreateDalTargheBianche();
				t.Cancella(r);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "CancellaTargheBianche");
				throw;
			}

		}
		/// <summary>
		/// Aggiorna una targa esistente.
		/// </summary>
		/// <param name="r"></param>
		[DataObjectMethod(DataObjectMethodType.Update)]
		public void AggiornaTargheBianche(TargheBianche r)
		{
			try
			{
				// normalizzo la data di inizio alle 00:00:00
				// normalizzo la data di fine alle 23:59:59
				r.TsInizioValidita = new DateTime(r.TsInizioValidita.Year, r.TsInizioValidita.Month, r.TsInizioValidita.Day);
				r.TsFineValidita = new DateTime(r.TsFineValidita.Year, r.TsFineValidita.Month, r.TsFineValidita.Day, 23, 59, 59);

				IDalTargheBianche t = DalProvider.DAL.CreateDalTargheBianche();
				t.Aggiorna(r);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "AggiornaTargheBianche");
				throw;
			}

		}

		/// <summary>
		/// Inserisce una targa purche` non ci sia una entry VALIDA.
		/// </summary>
		/// <param name="r"></param>
		/// <returns></returns>
		[DataObjectMethod(DataObjectMethodType.Insert)]
		public bool InserisciTargheBianche(TargheBianche r)
		{
			try
			{
				r.TsInizioValidita = new DateTime(r.TsInizioValidita.Year, r.TsInizioValidita.Month, r.TsInizioValidita.Day);
				r.TsFineValidita = new DateTime(r.TsFineValidita.Year, r.TsFineValidita.Month, r.TsFineValidita.Day, 23, 59, 59);

				IDalTargheBianche t = DalProvider.DAL.CreateDalTargheBianche();

				int idLTS;
				if (t.EsisteEntryValida(r.Targa, r.Nazionalita, out idLTS))
					return false;

				t.Inserisci(r);
				return true;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "InserisciTargheBianche");
				throw;
			}
		}


		public byte[] ExportTargheBianche()
		{
			try
			{
				IDalTargheBianche t = DalProvider.DAL.CreateDalTargheBianche();

				List<TargheBianche> lst = t.GetLista(null, DateTime.Now);
				//List<TargheBianche> lst = new List<TargheBianche>();
				//TargheBianche ttt = new TargheBianche();
				//ttt.Targa = "AB222";
				//ttt.Nazionalita = "I";
				//ttt.Descrizione = "urca";
				//ttt.Motivo = "cavoli miei";
				//ttt.TsInizioValidita = DateTime.Now.Date.AddDays(-1);
				//ttt.TsFineValidita = DateTime.Now.Date.AddDays(+1);
				//lst.Add(ttt);

				MemoryStream ms = new MemoryStream();

				XmlWriterSettings xws = new XmlWriterSettings();
				xws.Indent = true;
				xws.IndentChars = "\t";

				XmlWriter xw = XmlWriter.Create(ms, xws);
				xw.WriteStartDocument();
				xw.WriteStartElement("LTBList", "urn:LTB");
				xw.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");
				xw.WriteAttributeString("xsi", "schemaLocation", null, "urn:LTB LTB.xsd");

				foreach (TargheBianche tb in lst)
				{
					xw.WriteStartElement("LTB");
					xw.WriteAttributeString("Operazione", "ins");
					xw.WriteElementString("Targa", tb.Targa);
					xw.WriteElementString("Nazionalita", tb.Nazionalita);
					xw.WriteElementString("DataInizioValidita", XmlConvert.ToString(tb.TsInizioValidita, "yyyy-MM-dd"));
					xw.WriteElementString("DataFineValidita", XmlConvert.ToString(tb.TsFineValidita, "yyyy-MM-dd"));
					xw.WriteElementString("Motivo", tb.Motivo);
					xw.WriteElementString("Descrizione", tb.Descrizione);
					xw.WriteEndElement();
				}

				xw.WriteEndElement();
				xw.WriteEndDocument();
				xw.Flush();


				return ms.ToArray();
			}
			catch (Exception ex)
			{
				Log.Write(ex, "ExportTarghrBianche");
				throw;
			}
		}
		public List<string> ImportTargheBianche(byte [] contenutoFile)
		{
			List<string> errorList = new List<string>();
			try
			{
				XmlReaderSettings xrs = new XmlReaderSettings();
				xrs.Schemas.Add("urn:LTB", ReadAppSettings.ToString("LTB.SchemaXsd", @".\ITRSweb\LTS\LTB.xsd"));
				xrs.ValidationType = ValidationType.Schema;
				xrs.ValidationEventHandler += delegate(object sender, ValidationEventArgs e)
				{
					if (e.Severity == XmlSeverityType.Error)
						errorList.Add(e.Message);
				};


				LTBNamespace.LTBList ltbList = null;
				try
				{
					MemoryStream ms = new MemoryStream(contenutoFile);
					using (XmlReader xr = XmlReader.Create(ms, xrs))
					{
						XmlSerializer xser = new XmlSerializer(typeof(LTBNamespace.LTBList));
						ltbList = (LTBNamespace.LTBList)xser.Deserialize(xr);
					}
				}
				catch
				{
				}

				if (errorList.Count > 0)
					return errorList;

				IDalTargheBianche dal = DalProvider.DAL.CreateDalTargheBianche();
				foreach (LTBNamespace.LTB ltb in ltbList.Items)
				{
					if (ltb.DataFineValidita < DateTime.Now) continue;

					TargheBianche tb = new TargheBianche();
					tb.Targa = ltb.Targa;
					tb.Nazionalita = ltb.Nazionalita;
					tb.TsInizioValidita = ltb.DataInizioValidita;
					tb.TsFineValidita = ltb.DataFineValidita;
					tb.Motivo = ltb.Motivo;
					tb.Descrizione = ltb.Descrizione;

					if (ltb.Operazione == LTBNamespace.OperazioneType.del)
					{
						int idLTS;
						if (dal.EsisteEntryValida(tb.Targa, tb.Nazionalita, out idLTS))
						{
							tb.IdLTS = idLTS;
							dal.Cancella(tb);
						}
					}
					else
					{
						int idLTS;
						if (dal.EsisteEntryValida(tb.Targa, tb.Nazionalita, out idLTS))
						{
							tb.IdLTS = idLTS;
							dal.Aggiorna(tb);
						}
						else
							dal.Inserisci(tb);
					}
				}

				return errorList;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "ImportTargheBianche");
				throw;
			}
		}



		#region utilita` per l'import
		static bool CheckAZ09(string ss, bool permettiNumeri)
		{
			foreach (char c in ss)
			{
				if (c >= 'A' && c <= 'Z') continue;
				if (permettiNumeri && c >= '0' && c <= '9') continue;
				return false;
			}
			return true;
		}

		static string IsolaCampo(ref string ss)
		{
			char[] ws = new char[] { ' ', '\t' };

			int idx = ss.IndexOfAny(ws);
			if (idx < 0)
			{
				string ret = ss;
				ss = "";
				return ret;
			}
			else
			{
				string ret = ss.Substring(0, idx);

				// faccio avanzare il rimanente della stringa
				// togliendo gli eventuali caratteri bianchi
				ss = ss.Substring(idx + 1);
				ss = ss.TrimStart(ws);

				return ret;
			}
		}

		static bool CheckDate(string ss, int nLine, string nomeCampo, out DateTime dt, List<string> errorList)
		{
			dt = new DateTime();
			if (ss.Length > 10)
			{
				errorList.Add(string.Format("Riga {0}: campo {1} troppo lungo", nLine, nomeCampo));
				return false;
			}
			if (ss.Length < 10)
			{
				errorList.Add(string.Format("Riga {0}: campo {1} troppo corto", nLine, nomeCampo));
				return false;
			}

			if (ss[2] != '/' || ss[5] != '/')
			{
				errorList.Add(string.Format("Riga {0}: campo {1} non nel formato gg/mm/aaaa", nLine, nomeCampo));
				return false;
			}

			try
			{
				int gg = Int32.Parse(ss.Substring(0, 2));
				int mm = Int32.Parse(ss.Substring(3, 2));
				int aaaa = Int32.Parse(ss.Substring(6, 4));
				dt = new DateTime(aaaa, mm, gg);
			}
			catch
			{
				errorList.Add(string.Format("Riga {0}: campo {1} non nel formato gg/mm/aaaa", nLine, nomeCampo));
				return false;
			}

			return true;
		}
		#endregion

	}

	[Serializable]
	public class TargheBianche
	{
		public string Targa { get { return _Targa; } set { _Targa = value; } }
		public string Nazionalita { get { return _Nazionalita; } set { _Nazionalita = value; } }
		public int IdLTS { get { return _IdLTS; } set { _IdLTS = value; } }
		public string Descrizione { get { return _Descrizione; } set { _Descrizione = value; } }
		public DateTime TsInizioValidita { get { return _TsInizioValidita; } set { _TsInizioValidita = value; } }
		public DateTime TsFineValidita { get { return _TsFineValidita; } set { _TsFineValidita = value; } }
		public string Motivo { get { return _Motivo; } set { _Motivo = value; } }

		private string _Targa;
		private string _Nazionalita;
		private int _IdLTS;
		private string _Descrizione;
		private DateTime _TsInizioValidita;
		private DateTime _TsFineValidita;
		private string _Motivo;


		/// <summary>
		/// Utilizzato solo per l'import della LTB da file
		/// </summary>
		public bool CancellaRecord;
	}
}
