using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Xml;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using ITRS_BL.MWPStateful;
using ITRS_BL.IDal;


namespace ITRS_BL
{
	public partial class BLGeoRef : Component
	{
		static List<ThreadMap> _thMap;

		/// <summary>
		/// Scoda i messaggi MWP per la sorveglianza
		/// </summary>
		public static void StartServer()
		{
			_thMap = new List<ThreadMap>();

			_thMap.Add(new ThreadMap());

			foreach (ThreadMap tm in _thMap)
				tm.Start();
		}

		public static void StopServer()
		{
			foreach (ThreadMap tm in _thMap)
				tm.Stop();
			_thMap = null;
		}

		public BLGeoRef()
		{
			InitializeComponent();
		}

		public BLGeoRef(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		[Serializable]
		public class SorvDataStatus
		{
			readonly private Queue<SorvDataElement> _queue = new Queue<SorvDataElement>();
			private byte[] _imgSinottico = null;
			int _ProgressivoUltimoEvento = -1;

			public byte[] ImgSinottico { get { return _imgSinottico; } }

			public int ProgressivoUltimoEvento { get { return _ProgressivoUltimoEvento; } }

			public SorvDataElement GetSorvDataElement(int ProgressivoEvento)
			{
				foreach (SorvDataElement sd in _queue)
					if (sd.IdentificatoreEvento == ProgressivoEvento)
						return sd;
				return null;
			}

			[Serializable]
			public class SorvDataElement
			{
				public SorvDataElement() { }
				public SorvDataElement(BLSorveglianza.TransitoSegnalatoSorveglianza s, byte[] imgDettaglio, int ProgressivoEvento)
				{
					_s = s;
					_imgDettaglio = imgDettaglio;
					_ProgressivoEvento = ProgressivoEvento;
				}

				readonly BLSorveglianza.TransitoSegnalatoSorveglianza _s;
				readonly byte[] _imgDettaglio;
				readonly int _ProgressivoEvento;

				public byte[] ImgDettaglio { get { return _imgDettaglio; } }
				public BLSorveglianza.TransitoSegnalatoSorveglianza Sorveglianza { get { return _s; } }

				/// <summary>
				/// E` il progressivo dell'evento. Attenzione NON centra nulla con l'IdEvento del DB.
				/// </summary>
				public int IdentificatoreEvento { get { return _ProgressivoEvento; } }
			}

			public void OnEvento(BLSorveglianza.TransitoSegnalatoSorveglianza s, byte[] imgSinottico, byte[] imgDettaglio)
			{
				_imgSinottico = imgSinottico;
				_ProgressivoUltimoEvento += 1;

				_queue.Enqueue(new SorvDataElement(s, imgDettaglio, _ProgressivoUltimoEvento));
				if (_queue.Count > ReadAppSettings.ToInt32("NumeroEventiMemorizzati", 20))
					_queue.Dequeue();
			}
		}


		class ThreadMap
		{
			public ThreadMap()
			{
				_evOnStopTh = new AutoResetEvent(false);
			}

			Thread _th = null;
			readonly AutoResetEvent _evOnStopTh;


			public void Start()
			{

				if (_th != null)
					throw new ArgumentException("Thread gia` lanciato");

				_th = new Thread(new ThreadStart(ThreadFunc));
				_th.IsBackground = true;
				_th.Start();
			}

			public void Stop()
			{
				_evOnStopTh.Set();

				int timeoutMapPointThreadSec = ReadAppSettings.ToInt32("timeoutMapPointThreadSec", 10);
				bool bThredExited = _th.Join(timeoutMapPointThreadSec * 1000);
				if (!bThredExited)
				{
					// il thread non e` morto spontaneamente nel timeout.... 
					// lo aiuto con la forza bruta (perdendo pero` il clean up)
					_th.Abort();
				}
			}


			class SafeThread
			{
				ITRS_BL.MWPStateful.MWPInterface _mwp;
				MapPointApp.Application _oApp;
				MapPointContainer _mpc;

				readonly AutoResetEvent _evOnStopTh;

				public SafeThread(AutoResetEvent evOnStopTh)
				{
					this._evOnStopTh = evOnStopTh;
				}

				public void Open()
				{
					this._mwp = new MWPInterface();
					this._mwp.Connect();

					this._mpc = new MapPointContainer();

					int mapWidth = ReadAppSettings.ToInt32("mapWidth", 1024 / 3);
					int mapHeight = ReadAppSettings.ToInt32("mapHeight", 768 / 3);

					this._oApp = _mpc.SetUpApplication("BLGeoRef", mapWidth, mapHeight);
				}

				public void Close()
				{
					try
					{
						// Quit MapPoint
						if (_mpc != null)
							_mpc.QuitApp(_oApp);
						_mpc = null;
					}
					catch
					{
						_mpc = null;
					}

					try
					{
						// Disconnect MWP
						if (_mwp != null)
							_mwp.Disconnect();
						_mwp = null;
					}
					catch
					{
						_mwp = null;
					}
				}

				private void Trace(string fmt, params object[] args)
				{
					bool b = ReadAppSettings.ToBoolean("BLGeoRef.Thread.Log", true);
					if (b)
					{
						Log.Write(fmt, args);
					}
				}

				/// <summary>
				/// Esce normalmente (con return) per segnale di shutdown
				/// Esce con eccezione per problemi vari
				/// </summary>
				public void WaitMsgAndWork()
				{
					int msgCount = 0;

					C2PDelayReader TsReader = new C2PDelayReader();

					for (; ; )
					{
						bool bExit = _evOnStopTh.WaitOne(0, false);
						if (bExit)
							return;

						bool test = ReadAppSettings.ToBoolean("BLGeoRef.test", false);

						int idCoa;
						string Targa;
						string Nazionalita;
						DateTime DataOraRilevamentoTransito;

						if (test == false)
						{
							// Lettura sospensiva con timeout su MWP
							int TimeoutSecMWP = ReadAppSettings.ToInt32("TimeoutSecMWP", 2);
							string CorrId;
							string msg = _mwp.GetNextMessage(out CorrId, TimeoutSecMWP);
							if (msg == null)
								continue;

							msgCount++;

							if (CorrId == null) continue;
							if (CorrId == "GW_COA_2_POST_2") continue;
							if (CorrId == "GW_COA_1_POST_2") continue;
							idCoa = (CorrId == "GW_COA_2_POST_1") ? 2 : 1;

							string msgShort = msg;
							if (msg.Length > 500) msgShort = msg.Substring(0, 500);
							Trace("1) msg={0} COA={1}: Letto messaggio {2}", msgCount, idCoa, msgShort);

							ParseXMLMsg2(msg, out Targa, out Nazionalita, out DataOraRilevamentoTransito);
						}
						else
						{
							Targa = ReadAppSettings.ToString("BLGeoRef.test.Targa", "AABBCC");
							Nazionalita = ReadAppSettings.ToString("BLGeoRef.test.Targa", "I");
							DataOraRilevamentoTransito = ReadAppSettings.ToDateTime("BLGeoRef.test.DataOraRilevamentoTransito", new DateTime(2007, 1, 26, 17, 40, 0));
							idCoa = ReadAppSettings.ToInt32("BLGeoRef.test.IdCoa", 1);
						}


						Trace("2) msg={0} COA={1}: Targa={2}, Naz={3}, DataRil={4}",
							msgCount, idCoa, Targa, Nazionalita, DataOraRilevamentoTransito);

						// Read data from db
						// Leggo i dati dell'evento da TransitiSuEvento
						using (BLSorveglianza blSorveglianza = new BLSorveglianza())
						{
							BLSorveglianza.DatiTransitoSegnalatoSuMessaggioMWP sorveglianza = blSorveglianza.GetDatiPerTransitoSegnalazioneSuMessaggioMWP(Targa, Nazionalita, DataOraRilevamentoTransito);

							Trace("3) msg={0} COA={1}: Eseguito GetDatiPerTransitoSegnalazioneSuMessaggioMWP", msgCount, idCoa);

							bool allarmeChiusoAutomaticamente = false;

							string UserPkId = ReadAppSettings.ToString("EventoRimorchio.OperatoreChiusura", "04cb7e87-b4a7-48fc-8c4b-8e0ed088fe46");


							if (allarmeChiusoAutomaticamente == false)
							{
								if (sorveglianza.EvTipoLTS == null)
								{
									// arriva un allarme SENZA segnalazione !!!
									// vuol dire che NON e` piu` in LTS --> lo posso chiudere d'ufficio
									Trace("4) Chiusura automatica segnalazione in quanto non piu` presente nella LTS");

									if (!ChiudiTS(UserPkId, sorveglianza.Targa, sorveglianza.Nazionalita, sorveglianza.TrDataOraRilevamento, sorveglianza.EvDataOraInserimento, sorveglianza.EvIdEvento, "Transito segnalato non piu` presente nella LTS"))
									{
										// se fallisce ChiudiTS ... lo considero come un allarme normale
										allarmeChiusoAutomaticamente = false;
									}
									else
									{
										Trace("4) Chiusura automatica terminata");
										allarmeChiusoAutomaticamente = true;
									}

								}
							}

							// controllo se devo chiudere per allarme obsoleto
							if (allarmeChiusoAutomaticamente == false)
							{
								TimeSpan tsDelay = TsReader.GetDelay(sorveglianza.TrIdC2P);

								if (DataOraRilevamentoTransito < DateTime.Now.Subtract(tsDelay))
								{
									// allarme obsoleto
									Trace("4) Chiusura automatica segnalazione per obsolescenza");
									if (!ChiudiTS(UserPkId, sorveglianza.Targa, sorveglianza.Nazionalita, sorveglianza.TrDataOraRilevamento, sorveglianza.EvDataOraInserimento, sorveglianza.EvIdEvento, "Transito segnalato obsoleto"))
									{
										// se fallisce ChiudiTS ... lo considero come un allarme normale
										allarmeChiusoAutomaticamente = false;
									}
									else
									{
										Trace("4) Chiusura automatica terminata");
										allarmeChiusoAutomaticamente = true;
									}
								}
							}

							if (allarmeChiusoAutomaticamente == false)
							{
								// Il legislatore, con squisita lungimiranza, permette che una targa di un motocicolo 
								// possa essere anche la targa di un rimorchio.
								// In pratica ci possono essere 2 veicoli circolanti con la stessa targa.
								// Se la targa segnalata appartiene ad un motociclo e sul lettore passa un rimorchio con la stessa
								// targa si scatena un allarme immotivato.
								// Anche un rimorchio rubato puo` far scattare l'allarme quando transita un motociclo.

								// Qui si escludono dalla sorveglianza gli allarmi di transiti segnalati quando 
								// 1) la targa e` composta da [A-Z][A-Z] seguita da 5/6 numeri - targa di un motociclo
								// AND
								// 2) se la segnalazione in A1 corrisponde ad un furto di motociclo
								// AND
								// 3) il lettore targhe dice che la forma della targa corrisponde ad un 
								// controllo se e` un allarme di TS motoveicolo/camion RIMORCHIO.
								//
								// In pratica e` l'approccio piu` conservativo.
								// Nella maschera della sorveglianza invece l'abilitazione del bottone Moto/Camion
								// e molto meno restrittiva in quanto l'azione e` a responsabilita` dell'operatore
								bool MotoRimorchio = ChiusuraAutomaticaPerMotoRimorchio(sorveglianza);
								if (MotoRimorchio)
								{
									// chiudo l'evento d'ufficio TODO LEO_FINISCI
									Trace("4) Chiusura automatica segnalazione MOTO e layout di targa RIMORCHIO");
									if (!ChiudiTS(UserPkId, sorveglianza.Targa, sorveglianza.Nazionalita, sorveglianza.TrDataOraRilevamento, sorveglianza.EvDataOraInserimento, sorveglianza.EvIdEvento, "Rimorchio/Motociclo"))
									{
										// se fallisce ChiudiTS ... lo considero come un allarme normale
										allarmeChiusoAutomaticamente = false;
									}
									else
									{
										Trace("4) Chiusura automatica terminata");
										allarmeChiusoAutomaticamente = true;
									}

								}
							}

							if (allarmeChiusoAutomaticamente == false)
							{
								// GeoRef MSG using MapPointContainer
								double Alt = 10;
								_mpc.SetUpMap(_oApp, (double)sorveglianza.TrLatitudine, (double)sorveglianza.TrLongitudine, Alt);
								_mpc.AddBookmark(_oApp, Targa, Nazionalita, DataOraRilevamentoTransito, sorveglianza.TrTipoVarco, sorveglianza.TrC2PDescrizione, sorveglianza.TrC2PDescrizione.ToString(), sorveglianza.TrC2pStrada);
								// Create Maps and (TODO) maintain status
								string FName = _mpc.SaveHTMLMap(_oApp);
								// Convert file to byte array then delete file
								// Setup internal status....

								byte[] rImg = GetImageByteArray(FName);

								_mpc.DeleteHTMLMap(FName);

								Trace("4) msg={0} COA={1}: Generata Immagine MapPoint", msgCount, idCoa);

								Trace("5) msg={0} COA={1}: blSorveglianza.AccodaEvento t={2} n={3} ins={4} ril={5} idEv={6}",
									msgCount,
									idCoa,
									sorveglianza.Targa,
									sorveglianza.Nazionalita,
									sorveglianza.EvDataOraInserimento,
									sorveglianza.TrDataOraRilevamento,
									sorveglianza.EvIdEvento
									);

								BLSorveglianza.TransitoSegnalatoPrecedente tsPrec;
								tsPrec = blSorveglianza.GetTransitoSegnalatoPrecedente(
									sorveglianza.Targa,
									sorveglianza.Nazionalita,
									sorveglianza.TrDataOraRilevamento);

								DateTime? p_PrecEvDataOraInserimento = null;
								int? p_PrecEvIdEvento = null;
								DateTime? p_PrecTrDataOraRilevamento = null;
								if (tsPrec != null)
								{
									p_PrecEvDataOraInserimento = tsPrec.EvDataOraInserimento;
									p_PrecEvIdEvento = tsPrec.EvIdEvento;
									p_PrecTrDataOraRilevamento = tsPrec.TrDataOraRilevamento;
								}

								blSorveglianza.AccodaEvento(
									sorveglianza.Targa,
									sorveglianza.Nazionalita,
									sorveglianza.EvDataOraInserimento,
									sorveglianza.TrDataOraRilevamento,
									sorveglianza.EvIdEvento,
									idCoa,
									rImg,
									p_PrecEvDataOraInserimento,
									p_PrecEvIdEvento,
									p_PrecTrDataOraRilevamento
									);

								Trace("6) msg={0} COA={1}: Eseguito AccodaEvento", msgCount, idCoa);
							}
						}
					}
				}

				private static bool ChiusuraAutomaticaPerMotoRimorchio(BLSorveglianza.DatiTransitoSegnalatoSuMessaggioMWP ts)
				{
					Regex rg = new Regex("^[A-Z]{2}[0-9]{5,6}$");
					Match m = rg.Match(ts.Targa);
					if (!m.Success)
						return false; // non e` un targa con il formato moto/rimorchio

					if (ts.TrTipoVeicoloSegnalazione != null && ts.TrTipoVeicoloSegnalazione.StartsWith("MOTO") &&
						ts.TrPlateVehicleType != null && ts.TrPlateVehicleType == "RIMORCHIO")
					{
						// la segnalazione e` quella di una moto rubata
						// e il layout della targa corrisponde a quello di un rimorchio.
						return true;
					}

					return false;
				}

				private static bool ChiudiTS(string UserPkId, string targa, string nazionalita, DateTime TrDataOraRilevamento, DateTime EvDataOraInserimento, Int64 EvIdEvento, string causale)
				{
					string fase = string.Empty;
					try
					{
						using (BLTransiti blTransiti = new BLTransiti())
						{
							fase = "LeggiDatiTransito";
							ITRS_BL.DatiTransito tr = blTransiti.GetDatiTransitoOrTransitoSuEvento(targa, nazionalita, TrDataOraRilevamento);
							if (tr == null || tr.StatoTransito != StatoTransito.DARIC)
								return false;

							fase = "Transito.PrendiInCarico";
							blTransiti.PrendiInCarico(targa, nazionalita, TrDataOraRilevamento, UserPkId);

							fase = "Transito.AzioneSuPresaInCarico";
							blTransiti.AzioneSuPresaInCarico(targa, nazionalita, TrDataOraRilevamento, StatoTransito.RIC, causale,
								targa, nazionalita);
						}

						using (BLEventi blEventi = new BLEventi())
						{
							DettEvento ev = blEventi.GetDatiEvento(targa, nazionalita, EvDataOraInserimento, EvIdEvento);
							if (ev == null || ev.StatoAllarme != StatoAllarme.ACQ)
								return false;

							fase = "Evento.PrendiInCarico";
							blEventi.PrendiInCarico(targa, nazionalita, EvDataOraInserimento, EvIdEvento, UserPkId);

							fase = "Evento.AzioneSuPresaInCarico";
							blEventi.AzioneSuPresaInCarico(targa, nazionalita, EvDataOraInserimento, EvIdEvento, StatoAllarme.NCNF, causale);
						}

						using (BLLog blLog = new BLLog())
						{
							string msg = U.F("Transito segnalato Targa={0} Nazionalita={1} Rilevato il = {2} Notificato il = {3} chiuso per {4}", targa, nazionalita, TrDataOraRilevamento, EvDataOraInserimento, causale);
							blLog.AddUserActivity("System", TipoAttivita.Evento, msg);
						}

						return true;
					}
					catch (Exception ex)
					{
						Log.Write(ex, "BLGeoRef.ChiudiTS");
						return false;
					}
				}
			}

			void ThreadFunc()
			{
				for (; ; )
				{
					string msg = string.Format("ThreadFunc partito");

					SafeThread sf = new SafeThread(this._evOnStopTh);
					try
					{
						Log.Write("{0}: Open", msg);

						sf.Open();

						Log.Write("{0}: WaitMsgAndWork", msg);

						sf.WaitMsgAndWork();

						// se sono qui e` arrivato un messaggio di quit
						Log.Write("{0}: Close", msg);
						sf.Close();

						return;
					}
					catch (ThreadAbortException)
					{
						Log.Write("{0}: Quit by abort", msg);
						return;
					}
					catch (Exception ex)
					{
						Log.Write(ex, string.Format("{0}: Error", msg));

						// errore durante il funzionamento
						// chiudo tutto (se ci riesco) e ricomincio dall'inizio
						sf.Close();

						// non faccio return perche' devo continuare a riprovarci
						Thread.Sleep(1000 * 10);
					}
				}
			}

			private static byte[] GetImageByteArray(string fileName)
			{
				using (FileStream f = File.OpenRead(fileName))
				{
					int c = (int)f.Length;
					byte[] r = new byte[c];
					int off = 0;
					while (c > 0)
					{
						int rd = f.Read(r, off, c);
						off += rd;
						c -= rd;
					}
					return r;
				}
			}

			void ParseXMLMsgNonUsare(string msg, out string Targa, out string Naz, out DateTime DataRilevamentoTransito)
			{
				XmlDocument doc = new XmlDocument();
				doc.LoadXml(msg);
				XmlElement root = doc.DocumentElement;
				XmlElement elAlarm = (XmlElement)root.SelectSingleNode("ALARM");

				Targa = elAlarm.GetAttribute("plate");
				Naz = elAlarm.GetAttribute("nation");
				if (Naz == "") Naz = "I";

				// formato 15/03/2006 06:10:30 ossia GG/MM/YYYY HH:MM:SS
				string dataRilevamento = elAlarm.GetAttribute("date");
				string[] dataRilevamentoSplitted = dataRilevamento.Split('/', ':', ' ');
				int gg = Int32.Parse(dataRilevamentoSplitted[0]);
				int MM = Int32.Parse(dataRilevamentoSplitted[1]);
				int yyyy = Int32.Parse(dataRilevamentoSplitted[2]);
				int hh = Int32.Parse(dataRilevamentoSplitted[3]);
				int mm = Int32.Parse(dataRilevamentoSplitted[4]);
				int ss = Int32.Parse(dataRilevamentoSplitted[5]);
				DataRilevamentoTransito = new DateTime(yyyy, MM, gg, hh, mm, ss);

				/*
				 * GW_COA_2_POST_1
				<?xml version="1.0" encoding="utf-8"?> 
				<MSG type="ALARM_OPERATIVE"> 
				  <ALARM type="XX_GA_ALL" 
						code="0" 
						module="FilTa" 
						plate="CK638CP"
						site="Test Elsag" 
						group="Itinere Via Hermada"
						tliId="00001"
						date="06/05/2006 17:59:59"
						text="" /> 
						<IMAGE format="JPEG" encode="base64" resolution="1024x768"></IMAGE> 
						<STATO>ACQ</STATO>
						<TIPO>TS</TIPO>
						<URGENZA>OBS</URGENZA>
						<IDIMMAGINE>445057</IDIMMAGINE>
						<IDC2P>7</IDC2P>
				</MSG>
				*/
			}

			static void ParseXMLMsg2(string msg, out string Targa, out string Naz, out DateTime DataRilevamentoTransito)
			{
				XmlDocument doc = new XmlDocument();
				doc.LoadXml(msg);
				//XmlElement root = doc.DocumentElement;
				//XmlElement elMSG = (XmlElement)root.SelectSingleNode("MSG");

				XmlElement elMSG = doc.DocumentElement;

				Targa = elMSG.SelectSingleNode("TARGA").InnerText;
				if (elMSG.SelectSingleNode("NAZIONE") != null)
					Naz = elMSG.SelectSingleNode("NAZIONE").InnerText;
				else
					Naz = "I";

				string dataRilevamento = elMSG.SelectSingleNode("ORARILE").InnerText;

				// formato 15/03/2006 06:10:30 ossia GG/MM/YYYY HH:MM:SS
				string[] dataRilevamentoSplitted = dataRilevamento.Split('/', ':', ' ');
				int gg = Int32.Parse(dataRilevamentoSplitted[0]);
				int MM = Int32.Parse(dataRilevamentoSplitted[1]);
				int yyyy = Int32.Parse(dataRilevamentoSplitted[2]);
				int hh = Int32.Parse(dataRilevamentoSplitted[3]);
				int mm = Int32.Parse(dataRilevamentoSplitted[4]);
				int ss = Int32.Parse(dataRilevamentoSplitted[5]);
				DataRilevamentoTransito = new DateTime(yyyy, MM, gg, hh, mm, ss);
			}
		}

		class C2PDelayReader
		{
			public C2PDelayReader()
			{
				_lastRead = new DateTime(2000, 1, 1); // una data molto vecchia
				_TsDelayList = new List<C2PTsDelay>();

				_readTimeoutMin = ReadAppSettings.ToInt32("C2PDelayReader.ReadTimeoutMin", 10);
				_DefaultTsDelay = ReadAppSettings.ToInt32("C2PDelayReader.DefaultTsDelay", 10);

				// forzo il caricamento della lista (e cosi` modifico la tabella se non e` aggiornata)
				this.GetDelay(1);
			}

			public TimeSpan GetDelay(int idC2P)
			{
				if (_lastRead.AddMinutes(_readTimeoutMin) < DateTime.Now)
				{
					using (BLC2P bl = new BLC2P())
					{
						_TsDelayList = bl.GetTsDelay();
						_lastRead = DateTime.Now;
					}
				}

				U.FindFirstPredicate<C2PTsDelay> p = delegate(C2PTsDelay r) { return r.IdC2P == idC2P; };
				C2PTsDelay ts = U.FindFirst<C2PTsDelay>(_TsDelayList, p);
				if (ts == null || ts.TsDelay.HasValue == false)
				{
					return new TimeSpan(0, _DefaultTsDelay, 0);
				}

				return new TimeSpan(0, (int)ts.TsDelay.Value, 0);
			}

			readonly int _readTimeoutMin;
			readonly int _DefaultTsDelay;
			DateTime _lastRead;
			List<C2PTsDelay> _TsDelayList;
		}
	}
}
