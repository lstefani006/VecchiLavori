using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Configuration;
using System.Threading;

namespace ITRS_BL
{
	/// <summary>
	/// Classe remotizzata utilizzata da web per ottenere le cartine georeferenziate.
	/// Per evitare di bloccare il server, le richieste sono accodate e servite da un ThreadPool
	/// costruito ad hoc.
	/// Ogni thread del ThreadPool possiede una sua istanza di MapPoint. 
	/// </summary>
	public partial class BLMap : Component
	{
		static ITRS_BL.WorkPool<MapCommand, ThreadWorker> _poolWorker;

		/// <summary>
		/// Server per ottenere le cartine opportunamente zoomate
		/// </summary>
		public static void StartServer()
		{
			_poolWorker = new ITRS_BL.WorkPool<MapCommand, ThreadWorker>(3, 5000, 10, false);
		}
		public static void StopServer()
		{
			_poolWorker.StopPool();
		}

		public BLMap()
		{
			InitializeComponent();
		}

		public BLMap(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		/// <summary>
		/// Metodo per ottenere la cartina proponendo in ingresso tutti i passi 
		/// che sono stati effettuati partendo da un centro passto per parametro.
		/// </summary>
		/// <param name="lat"></param>
		/// <param name="lon"></param>
		/// <param name="alt"></param>
		/// <param name="steps"></param>
		/// <returns></returns>
		public byte[] BuildMap(double lat, double lon, double alt, string steps)
		{
			ITRS_BL.WorkPool<MapCommand, ThreadWorker>.WorkItem wi;
			using (wi = _poolWorker.QueueUserWorkItem(new MapCommand(lat, lon, alt, steps)))
			{
				if (wi == null)
					return null; // troppi elementi in coda

				wi.EventCompleted.WaitOne();

				if (wi.Status == WorkPool<MapCommand, ThreadWorker>.WorkItemStatus.Completed)
				{
					if (wi.Exception != null)
					{
						Log.Write(wi.Exception, "BuildMap");
						return null;
					}
					return wi.Args._img;
				}
				else
					return null;
			}
		}

		public byte[] BuildMap2(double lat, double lon, double alt, string steps)
		{
			MapPointApp.Application app = new MapPointApp.Application();



			using (FileStream f = File.OpenRead("c:\\logo.jpg"))
			{
				byte []r = new byte[ f.Length];

				f.Read(r, 0, r.Length);

				return r;
			}
		}


		class MapCommand
		{
			public MapCommand(double lat, double lon, double alt, string steps)
			{
				_lat = lat; _lon = lon; _alt = alt; _steps = steps;
				_img = null;
			}
			readonly public double _lat;
			readonly public double _lon;
			readonly public double _alt;
			readonly public string _steps;

			public byte[] _img;
		}

		class ThreadWorker : ITRS_BL.PoolThreadWorker<MapCommand>
		{
			MapPointApp.Application _oApp;

			public void StartWorkerOnPoolThread()
			{
				int mapWidth = ReadAppSettings.ToInt32("mapWidth", 1024 / 3);
				int mapHeight = ReadAppSettings.ToInt32("mapHeight", 768 / 3);

				_oApp = ServerItems.CreateMapPointApplication("BLMap");
				_oApp.PaneState = MapPointApp.GeoPaneState.geoPaneNone;
				_oApp.Width = mapWidth + 12;
				_oApp.Height = mapHeight + 157;

				_oApp.ActiveMap.Saved = true;

				string t = ReadAppSettings.ToString("MapPointTemplate", "C:\\Program Files\\Microsoft MapPoint Europe\\Templates\\Nuova carta europea.ptt");
				_oApp.NewMap(t);
				_oApp.PaneState = MapPointApp.GeoPaneState.geoPaneNone;

				foreach (MapPointApp.PlaceCategory pc in _oApp.ActiveMap.PlaceCategories)
					if (pc.Visible)
						pc.Visible = false;
			}

			public void DoWork(MapCommand args)
			{
				MapPointApp.Location oLoc = _oApp.ActiveMap.GetLocation(args._lat, args._lon, args._alt);
				oLoc.GoTo();

				for (int ch = 0; ch < args._steps.Length; ++ch)
				{
					string ccc;
					char c = args._steps[ch];
					int x = 0;
					int y = 0;
					if (c == 'C')
					{
						int chEnd = args._steps.IndexOf(')', ch);

						string gg = args._steps.Substring(ch + 2, chEnd - ch - 2);
						string[] gga = gg.Split(',');

						x = int.Parse(gga[0]);
						y = int.Parse(gga[1]);

						ch = chEnd;
						ccc = "10";
					}
					else
						ccc = new string(c, 1);

					MapPointCommand cmd = (MapPointCommand)Enum.Parse(typeof(MapPointCommand), ccc);
					switch (cmd)
					{
					case MapPointCommand.Pan:
						{
							MapPointApp.Location locXY = _oApp.ActiveMap.XYToLocation(x, y);
							locXY.GoTo();
						}
						break;

					case MapPointCommand.PanEast:
						_oApp.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoEast, 0.5);
						break;
					case MapPointCommand.PanNorth:
						_oApp.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorth, 0.5);
						break;
					case MapPointCommand.PanNorthEast:
						_oApp.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorthEast, 0.5);
						break;
					case MapPointCommand.PanNorthWest:
						_oApp.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorthWest, 0.5);
						break;
					case MapPointCommand.PanSouth:
						_oApp.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouth, 0.5);
						break;
					case MapPointCommand.PanSouthEast:
						_oApp.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouthEast, 0.5);
						break;
					case MapPointCommand.PanSouthWest:
						_oApp.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouthWest, 0.5);
						break;
					case MapPointCommand.PanWest:
						_oApp.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoWest, 0.5);
						break;
					case MapPointCommand.ZoomIn:
						_oApp.ActiveMap.ZoomIn();
						break;
					case MapPointCommand.ZoomOut:
						_oApp.ActiveMap.ZoomOut();
						break;
					}
				}

				double lat, lon;
				CalcMapCenterCoordinates(_oApp.ActiveMap, out lat, out lon);

				Debug.Write("Lat = " + lat.ToString());
				Debug.Write("Lon = " + lon.ToString());

				//string HTMLName = ConfigurationManager.AppSettings["WebMapsPath"] + "\\" + Guid.NewGuid().ToString();
                //Modifica Frascatani 24/07/06
                string HTMLName = ReadAppSettings.ToString("WebMapsPath", string.Empty) + "\\" + Guid.NewGuid().ToString();
                
				_oApp.ActiveMap.SaveAs(HTMLName, MapPointApp.GeoSaveFormat.geoFormatHTMLMap, false);
				string fileName = HTMLName + "_files\\image_map.gif";

				byte[] img;
				using (FileStream f = File.OpenRead(fileName))
				{
					int c = (int)f.Length;
					byte[] r = new byte[c];
					int off = 0;
					while (c > 0)
					{
						int rd = f.Read(r, off, c);
						off += rd;
						c -= rd;
					}
					img = r;
				}

				Directory.Delete(HTMLName + "_files", true);
				File.Delete(HTMLName + ".htm");

				args._img = img;
			}


			private static void CalcMapCenterCoordinates(MapPointApp.Map Map, out double lat, out double lon)
			{
				MapPointApp.Location locNorthPole = Map.GetLocation(90, 0, 0);
				MapPointApp.Location locSantaCruz = Map.GetLocation(0, 90, 0);
				// Compute distance between north and south poles == half earth circumference
				double dblHalfEarth = Map.Distance(locNorthPole, Map.GetLocation(-90, 0, 0));
				// Quarter of that is the max distance a point may be away from locSantaCruz and still be in western hemisphere
				double dblQuarterEarth = dblHalfEarth / 2;
				double Pi = 3.14159265358979;

				double _Altitude = Map.Altitude;
				MapPointApp.Location locX = Map.XYToLocation(Map.Width / 2, Map.Height / 2);

				// Compute latitude from distance to north pole
				double _Latitude = 90 - 180 * Map.Distance(locNorthPole, locX) / dblHalfEarth;

				double l;
				double d;

				// Compute great circle distance to locX from point on Greenwich meridian and computed Latitude
				d = Map.Distance(Map.GetLocation(_Latitude, 0, 0), locX);

				// convert latitude to radian
				l = (_Latitude / 180) * Pi;

				// Compute Longitude from great circle distance
				double _Longitude = 180 * Math.Acos((Math.Cos((d * 2 * Pi) / (2 * dblHalfEarth)) - Math.Sin(l) * Math.Sin(l)) / (Math.Cos(l) * Math.Cos(l))) / Pi;

				// Correct longitude sign if located in western hemisphere
				if (Map.Distance(locSantaCruz, locX) > dblQuarterEarth)
				{
					_Longitude = -_Longitude;
				}

				lat = _Latitude;
				lon = _Longitude;
			}


#pragma warning disable 467
			public void StopWorkerOnPoolThread()
			{
				if (_oApp == null) return;

				_oApp.ActiveMap.Saved = true;
				_oApp.Quit();
				_oApp = null;

			}
#pragma warning restore 467
		}

		enum MapPointCommand
		{
			ZoomIn = 0,
			ZoomOut = 1,
			PanNorth = 2,
			PanNorthEast = 3,
			PanEast = 4,
			PanSouthEast = 5,
			PanSouth = 6,
			PanSouthWest = 7,
			PanWest = 8,
			PanNorthWest = 9,

			Pan = 10
		};

	}
}
