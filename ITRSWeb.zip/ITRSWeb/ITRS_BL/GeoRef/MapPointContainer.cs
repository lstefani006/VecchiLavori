using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Configuration;

namespace ITRS_BL
{
	public partial class MapPointContainer : System.ComponentModel.Component
	{
		public enum MapPointCommand
		{
			ZoomIn = 0,
			ZoomOut = 1,
			PanNorth = 2,
			PanNorthEast = 3,
			PanEast = 4,
			PanSouthEast = 5,
			PanSouth = 6,
			PanSouthWest = 7,
			PanWest = 8,
			PanNorthWest = 9
		};

		public MapPointContainer()
		{
		}

		public string BuildMapCommands(string serverName, double Lat, double Lon, double Altitude, int SizeX, int SizeY, List<MapPointContainer.MapPointCommand> CmdList)
		{
			MapPointApp.Application App = SetUpApplication(serverName, SizeX, SizeY);
			SetUpMap(App, Lat, Lon, Altitude);
			foreach (MapPointCommand cmd in CmdList)
			{
				switch (cmd)
				{
				case MapPointCommand.PanEast:
					App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoEast, 0.5);
					break;
				case MapPointCommand.PanNorth:
					App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorth, 0.5);
					break;
				case MapPointCommand.PanNorthEast:
					App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorthEast, 0.5);
					break;
				case MapPointCommand.PanNorthWest:
					App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorthWest, 0.5);
					break;
				case MapPointCommand.PanSouth:
					App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouth, 0.5);
					break;
				case MapPointCommand.PanSouthEast:
					App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouthEast, 0.5);
					break;
				case MapPointCommand.PanSouthWest:
					App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouthWest, 0.5);
					break;
				case MapPointCommand.PanWest:
					App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoWest, 0.5);
					break;
				case MapPointCommand.ZoomIn:
					App.ActiveMap.ZoomIn();
					break;
				case MapPointCommand.ZoomOut:
					App.ActiveMap.ZoomOut();
					break;
				}
			}
			string FName = null;
			try
			{
				FName = SaveHTMLMap(App);
			}
			catch { }

			QuitApp(App);

			return FName;
		}

		public enum PanWhere
		{
			North,
			NorthEast,
			East,
			SouthEast,
			South,
			SouthWest,
			West,
			NorthWest
		};

		private double _Latitude;
		private double _Altitude;
		private double _Longitude;

		public double Latitude { get { return _Latitude; } }
		public double Longitude { get { return _Longitude; } }
		public double Altitude { get { return _Altitude; } }

		private void CalcMapCenterCoordinates(MapPointApp.Map Map)
		{
			MapPointApp.Location locNorthPole = Map.GetLocation(90, 0, 0);
			MapPointApp.Location locSantaCruz = Map.GetLocation(0, 90, 0);
			// Compute distance between north and south poles == half earth circumference
			double dblHalfEarth = Map.Distance(locNorthPole, Map.GetLocation(-90, 0, 0));
			// Quarter of that is the max distance a point may be away from locSantaCruz and still be in western hemisphere
			double dblQuarterEarth = dblHalfEarth / 2;
			double Pi = 3.14159265358979;

			_Altitude = Map.Altitude;
			MapPointApp.Location locX = Map.XYToLocation(Map.Width / 2, Map.Height / 2);

			// Compute latitude from distance to north pole
			_Latitude = 90 - 180 * Map.Distance(locNorthPole, locX) / dblHalfEarth;

			double l;
			double d;

			// Compute great circle distance to locX from point on Greenwich meridian and computed Latitude
			d = Map.Distance(Map.GetLocation(_Latitude, 0, 0), locX);

			// convert latitude to radian
			l = (_Latitude / 180) * Pi;

			// Compute Longitude from great circle distance
			_Longitude = 180 * Math.Acos((Math.Cos((d * 2 * Pi) / (2 * dblHalfEarth)) - Math.Sin(l) * Math.Sin(l)) / (Math.Cos(l) * Math.Cos(l))) / Pi;

			// Correct longitude sign if located in western hemisphere
			if (Map.Distance(locSantaCruz, locX) > dblQuarterEarth)
			{
				_Longitude = -_Longitude;
			}
		}


		public void AddBookmark(MapPointApp.Application App, string Targa, string Nazionalita, DateTime DataOraRilevamentoTransito, TipoVarco tipoVarco, string TRC2PDESCRIZIONE, string TRC2PDIREZIONE, string TRC2PSTRADA)
		{
			MapPointApp.Location locX = App.ActiveMap.XYToLocation(App.ActiveMap.Width / 2, App.ActiveMap.Height / 2);
			MapPointApp.Pushpin oPush = App.ActiveMap.AddPushpin(locX, "Transito segnalato");
			oPush.BalloonState = MapPointApp.GeoBalloonState.geoDisplayBalloon;

			System.Globalization.CultureInfo itit = new System.Globalization.CultureInfo("it-it");

			oPush.Note = Targa + " " + Nazionalita;
			oPush.Note += Environment.NewLine + DataOraRilevamentoTransito.ToString("G", itit);
			oPush.Note += Environment.NewLine + TRC2PSTRADA + " " + TRC2PDIREZIONE;
			oPush.Note += Environment.NewLine + TRC2PDESCRIZIONE + " " + Translate(tipoVarco);
		}

		private static string Translate(TipoVarco t)
		{
			switch (t)
			{
			case TipoVarco.D:
				return "Corsia destra";

			case TipoVarco.S:
				return "Corsia sinistra";

			case TipoVarco.E:
				return "Entrata area di servizio";

			case TipoVarco.U:
				return "Uscita area di servizio";

			default:
				Debug.Assert(false, "t.TipoVarco non gestito");
				return "";
			}
		}



		public MapPointApp.Application SetUpApplication(string serverName, int SizeX, int SizeY)
		{
			MapPointApp.Application App = ServerItems.CreateMapPointApplication(serverName); // new MapPointApp.Application();
			App.PaneState = MapPointApp.GeoPaneState.geoPaneNone;
			App.Width = SizeX + 12;
			App.Height = SizeY + 157;
			return App;
		}

		public void SetUpMap(MapPointApp.Application App, double Lat, double Lon, double Altitude)
		{
			App.ActiveMap.Saved = true;
			App.NewMap("C:\\Program Files\\Microsoft MapPoint Europe\\Templates\\Nuova carta europea.ptt");
			App.PaneState = MapPointApp.GeoPaneState.geoPaneNone;

			foreach (MapPointApp.PlaceCategory pc in App.ActiveMap.PlaceCategories)
			{
				try
				{
					if (pc.Visible)
						pc.Visible = false;
				}
				catch (Exception e)
				{
					string a = e.Message;
				}
			}
			MapPointApp.Location oLoc = App.ActiveMap.GetLocation(Lat, Lon, Altitude);
			oLoc.GoTo();
		}

#pragma warning disable 467
		public void QuitApp(MapPointApp.Application App)
		{
			if (App != null)
			{
				App.ActiveMap.Saved = true;
				App.Quit();
				App = null;
			}
		}
#pragma warning restore 467

		public string SaveHTMLMap(MapPointApp.Application App)
		{
			//AddBookmark(App);
            //string Path = ConfigurationManager.AppSettings["WebMapsPath"]; //"C:\\WebMaps\\";
            //Modifica Frascatani 24/07/06
            string Path = ReadAppSettings.ToString("WebMapsPath", string.Empty); //"C:\\WebMaps\\";
			Path += "\\";
			string FName = Guid.NewGuid().ToString();
			string HTMLName = Path + FName;
			App.ActiveMap.SaveAs(HTMLName, MapPointApp.GeoSaveFormat.geoFormatHTMLMap, false);
			System.IO.File.Move(HTMLName + "_files\\image_map.gif", Path + FName + ".gif");
			//System.IO.File.Delete(HTMLName + "_files\\image_overview.gif");
			System.IO.File.Delete(HTMLName + ".htm");
			System.IO.Directory.Delete(HTMLName + "_files", true);
			return Path + FName + ".gif";
		}

		public void DeleteHTMLMap(string fn)
		{
			System.IO.File.Delete(fn);
		}

		public string BuildMap(string serverName, double Lat, double Lon, double Altitude, int SizeX, int SizeY)
		{
			MapPointApp.Application App = SetUpApplication(serverName, SizeX, SizeY);

			SetUpMap(App, Lat, Lon, Altitude);

			string FName = null;
			try
			{
				FName = SaveHTMLMap(App);
			}
			catch { }

			CalcMapCenterCoordinates(App.ActiveMap);

			QuitApp(App);

			return FName;
		}

		private void ZoomMap(MapPointApp.Application App, bool ZoomIn)
		{
			if (ZoomIn)
				App.ActiveMap.ZoomIn();
			else
				App.ActiveMap.ZoomOut();
		}

		private void PanMap(MapPointApp.Application App, PanWhere WherePan)
		{
			switch (WherePan)
			{
			case PanWhere.East:
				App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoEast, 0.5);
				break;
			case PanWhere.North:
				App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorth, 0.5);
				break;
			case PanWhere.NorthEast:
				App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorthEast, 0.5);
				break;
			case PanWhere.NorthWest:
				App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoNorthWest, 0.5);
				break;
			case PanWhere.South:
				App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouth, 0.5);
				break;
			case PanWhere.SouthEast:
				App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouthEast, 0.5);
				break;
			case PanWhere.SouthWest:
				App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoSouthWest, 0.5);
				break;
			case PanWhere.West:
				App.ActiveMap.Pan(MapPointApp.GeoPanCmd.geoWest, 0.5);
				break;
			}
		}

		public string BuildMapAndZoom(string serverName, double Lat, double Lon, double Altitude, int SizeX, int SizeY, bool ZoomIn)
		{
			MapPointApp.Application oApp = SetUpApplication(serverName, SizeX, SizeY);

			SetUpMap(oApp, Lat, Lon, Altitude);

			ZoomMap(oApp, ZoomIn);

			string FName = null;
			try
			{
				FName = SaveHTMLMap(oApp);
			}
			catch { };

			CalcMapCenterCoordinates(oApp.ActiveMap);

			QuitApp(oApp);

			return FName;
		}

		public string BuildMapAndPan(string serverName, double Lat, double Lon, double Altitude, int SizeX, int SizeY, PanWhere WherePan)
		{
			MapPointApp.Application oApp = SetUpApplication(serverName, SizeX, SizeY);

			SetUpMap(oApp, Lat, Lon, Altitude);

			PanMap(oApp, WherePan);

			string FName = null;
			try
			{
				FName = SaveHTMLMap(oApp);
			}
			catch { };

			CalcMapCenterCoordinates(oApp.ActiveMap);

			QuitApp(oApp);

			return FName;
		}
	}
}
