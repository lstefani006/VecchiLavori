using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using ITRS_BL.IDal;

namespace ITRS_BL
{
	/*
	<asp:objectdatasource
	  runat="server"
	  id="odsTratte"
	  typename="ITRS_BL.BLTratte"
	  selectmethod="GetListaTratte"
	  updatemethod="AggiornaTratta"
	  dataobjecttypename="ITRS_BL.Tratta" />
	*/

	[DataObjectAttribute]
	public partial class BLTratte : Component
	{
		public BLTratte()
		{
			InitializeComponent();
		}

		public BLTratte(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Tratta> GetListaTratte(string columnsSort)
		{
			if (string.IsNullOrEmpty(columnsSort))
				columnsSort = "DESCRIZIONE";
			IDalTratta t = DalProvider.DAL.CreateDalTratta();
			return t.GetLista(columnsSort);
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Tratta> GetListaTratteCB()
		{
			string columnsSort = "Descrizione";
			IDalTratta t = DalProvider.DAL.CreateDalTratta();
			return t.GetLista(columnsSort);
		}
		
		[DataObjectMethod(DataObjectMethodType.Select)]
		public Tratta GetTratta(int idTratta)
		{
			IDalTratta t = DalProvider.DAL.CreateDalTratta();
			Tratta r = new Tratta();
			r.IdTratta = idTratta;
			return t.GetRecord(r);
		}


		[DataObjectMethod(DataObjectMethodType.Delete)]
		public void CancellaTratta(Tratta r)
		{
			IDalTratta t = DalProvider.DAL.CreateDalTratta();
			t.Cancella(r);
		}

		[DataObjectMethod(DataObjectMethodType.Update)]
		public void AggiornaTratta(Tratta r)
		{
			IDalTratta t = DalProvider.DAL.CreateDalTratta();
			t.Aggiorna(r);
		}

		[DataObjectMethod(DataObjectMethodType.Insert)]
		public void InserisciTratta(Tratta r)
		{
			IDalTratta t = DalProvider.DAL.CreateDalTratta();
			t.Inserisci(r);
		}

		public void UpdateVelocita(int IdTratta, int Velocita)
		{
			Tratta t = GetTratta(IdTratta);
			double ore = t.LunghezzaKm / Velocita;
			t.TempoMinPercorrenzaSecondi = (int)(ore * 3600);
			AggiornaTratta(t);
		}

	}

	[Serializable]
	public class Tratta
	{
		private int _idTratta;
		private double _lunghezzaKm;
		private string _descrizione;
		private string _codiceStrada;
		private int _tempoMinPercorrenzaSecondi;
		private string _direzione;

		public int IdTratta
		{
			get { return _idTratta; }
			set { _idTratta = value; }
		}

		public double LunghezzaKm
		{
			get { return _lunghezzaKm; }
			set { _lunghezzaKm = value; }
		}

		public string Descrizione
		{
			get { return _descrizione; }
			set { _descrizione = value; }
		}

		public string CodiceStrada
		{
			get { return _codiceStrada; }
			set { _codiceStrada = value; }
		}

		public int TempoMinPercorrenzaSecondi
		{
			get { return _tempoMinPercorrenzaSecondi; }
			set { _tempoMinPercorrenzaSecondi = value; }
		}

		public string Direzione
		{
			get { return _direzione; }
			set { _direzione = value; }
		}
	}
}
