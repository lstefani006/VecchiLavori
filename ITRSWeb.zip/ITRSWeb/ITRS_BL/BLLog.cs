using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Xml;
using ITRS_BL.IDal;


namespace ITRS_BL
{
	[DataObject]
	public class BLLog : Component
	{
		#region Costruttori
		public BLLog()
		{
			InitializeComponent();
		}

		public BLLog(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
				components.Dispose();
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		public enum LogType
		{
			Error,
			Warning,
			Trace
		}

		public void Add(string application, LogType logType, string message)
		{
			Add(application, logType, message, null);
		}

		public void Add(string application, LogType logType, string message, string ex)
		{
			bool bFail = false;
			try
			{
				IDalLog dal = DalProvider.DAL.CreateDalLog();
				string type = logType.ToString().Substring(0, 1);
				dal.Add(application, type, message, ex);
			}
			catch
			{
				// se sono qui sono alla frutta.
				bFail = true;
			}

			if (bFail == true)
			{
				try
				{
					using (StreamWriter sw = File.AppendText("c:\\ITRS.log"))
					{
						sw.WriteLine("Date: {0}", DateTime.Now.ToString("G"));
						sw.WriteLine("Application: {0}", application);
						sw.WriteLine("Type: {0}", logType);
						if (message != null) sw.WriteLine("Message: {0}", message);
						if (ex != null) sw.WriteLine("Exception: {0}", ex);
						sw.WriteLine();
					}
				}
				catch
				{
				}
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<RecordLog> GetLogs()
		{
			try
			{
				IDalLog dal = DalProvider.DAL.CreateDalLog();
				return dal.GetLogs();
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetLogs");
				throw;
			}
		}

        [DataObjectMethod(DataObjectMethodType.Select)]
        public List<string> GetAllTipi() 
        {
            try
            {
                IDalLog dal = DalProvider.DAL.CreateDalLog();
                return dal.GetAllTipi();
            }
            catch (Exception ex)
            {
                Log.Write(ex, "GetAllTipi");
                throw;
            }
        }

        [DataObjectMethod(DataObjectMethodType.Select)]
        public List<string> GetAllUtenti() 
        {
            try
            {
                IDalLog dal = DalProvider.DAL.CreateDalLog();
                return dal.GetAllUtenti();
            }
            catch (Exception ex)
            {
                Log.Write(ex, "GetAllUtenti");
                throw;
            }
        }

		[Serializable]
		public class RecordLog
		{
			public Decimal smID { get { return _SMID; } set { _SMID = value; } }
			public String smApplication { get { return _SMAPPLICATION; } set { _SMAPPLICATION = value; } }
			public String smMessage { get { return _SMMESSAGE; } set { _SMMESSAGE = value; } }
			public String smException { get { return _SMEXCEPTION; } set { _SMEXCEPTION = value; } }
			public String smType { get { return _SMTYPE; } set { _SMTYPE = value; } }
			public DateTime smTS { get { return _SMTS; } set { _SMTS = value; } }
			#region dati
			protected Decimal _SMID;
			protected String _SMAPPLICATION;
			protected String _SMMESSAGE;
			protected String _SMEXCEPTION;
			protected String _SMTYPE;
			protected DateTime _SMTS;
			#endregion
		}

		//public void AddUserActivity(TipoAttivita tipoAttivita, string DescrizioneAttivita)
		//{
		//    AddUserActivity(null, tipoAttivita, DescrizioneAttivita);
		//}
		public void AddUserActivity(string IdUtenteAttivita, TipoAttivita tipoAttivita, string DescrizioneAttivita)
		{
			try
			{
				IDalLog dal = DalProvider.DAL.CreateDalLog();
				dal.AddUserActivity(IdUtenteAttivita, tipoAttivita, DescrizioneAttivita);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "AddUserActivity");
				throw;
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<UserLogData> GetUserActivity(string sortColumns, int startRowIndex, int maximumRows, DateTime? da, DateTime? a, string utente, string tipo)
		{
			try
			{
				IDalLog dal = DalProvider.DAL.CreateDalLog();
				return dal.GetUserActivity(sortColumns, startRowIndex, maximumRows, da, a, utente, tipo);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "AddUserActivity");
				throw;
			}
		}

		public int GetUserActivityCount(DateTime? da, DateTime? a, string utente, string tipo)
		{
			try
			{
				IDalLog dal = DalProvider.DAL.CreateDalLog();
				return dal.GetUserActivityCount(da, a, utente, tipo);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "AddUserActivityCount");
				throw;
			}
		}

		public void PurgeUserActivity(DateTime tsPurgeUntil)
		{
			try
			{
				IDalLog dal = DalProvider.DAL.CreateDalLog();
				dal.PurgeUserActivity(tsPurgeUntil);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "PurgeUserActivity");
				throw;
			}
		}

		[Serializable]
		public class UserLogData
		{
			public DateTime TS { get { return _TSATTIVITA; } set { _TSATTIVITA = value; } }
			public String Tipo { get { return _TIPOATTIVITA; } set { _TIPOATTIVITA = value; } }
			public String Descrizione { get { return _DESCATTIVITA; } set { _DESCATTIVITA = value; } }
			public String UserName { get { return _UserName; } set { _UserName = value; } }
			public int ProgressivoQuery { get { return _progressivoQuery; } set { _progressivoQuery = value; } }
			#region dati
			protected DateTime _TSATTIVITA;
			protected String _TIPOATTIVITA;
			protected String _DESCATTIVITA;
			protected String _UserName;
			protected int _progressivoQuery;
			#endregion
		}

        public byte[] ExportSystemActivities(DateTime? From, DateTime? To, string utente, string tipo, string sort)
        {
            try
            {
                IDalLog t = DalProvider.DAL.CreateDalLog();

                List<UserLogData> lst = t.GetUserActivity(sort, 0, 100000, From, To, utente, tipo);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (StreamWriter sw = new StreamWriter(ms))
                    {
                        sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}","Data/Ora","Utente","Descrizione","Tipo"));
                        foreach (UserLogData tb in lst)
                        {
                            sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}", tb.TS.ToString("dd/MM/yyyy HH.mm"), tb.UserName, tb.Descrizione, tb.Tipo));
                        }
                    }
                    return ms.ToArray();
                }                
            }
            catch (Exception ex)
            {
                Log.Write(ex, "ExportSystemActivities");
                throw;
            }
        }

		public List<BLLog.UserLogData> GetAttivitaDelGiorno(DateTime attivitaDelGiorno, string tipoAttivita)
		{
			try
			{
				IDalLog t = DalProvider.DAL.CreateDalLog();
				List<UserLogData> lst = t.GetAttivitaDelGiorno(attivitaDelGiorno, tipoAttivita);
				return lst;
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetAttivitaDelGiorno");
				throw;
			}
		}
	}


	public enum TipoAttivita
	{
		Accesso,
		Sorveglianza,
		Intervento,
		Indagine,

		ReportTVPD,
		ReportTVT,
		ReportTSC2P,
		ReportVTPD,
		ReportVTST,

		Transito,
		Evento,

		AmministrazioneUtenti,

		LTS,
		LTB,

		ImportLTS,
		CancellazioneLTS
	}
}
