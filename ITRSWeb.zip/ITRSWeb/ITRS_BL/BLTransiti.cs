using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.ComponentModel;
using System.Globalization;
using ITRS_BL.IDal;

namespace ITRS_BL
{
	#region Transiti

	[DataObject]
	public partial class BLTransiti : Component
	{
		public BLTransiti()
		{
			InitializeComponent();
		}

		public BLTransiti(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		private void InitializeComponent()
		{
		}


		public byte[] GetBlobImmagine(string targa, string nazionalita, DateTime dataOraRilevamento, out bool imgInC2P)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			byte[] img = t.GetBlobImmagine(targa, nazionalita, dataOraRilevamento);

			if (img != null)
			{
				imgInC2P = false;
				return img;
			}

			imgInC2P = true;
			try
			{
				BLTransiti blTransiti = new BLTransiti();

				string targaRil;
				int idC2P;
				string qmgr;

				blTransiti.GetTransitoData(targa, nazionalita, dataOraRilevamento, out targaRil, out idC2P, out qmgr);

				if (idC2P >= 0)
				{
					ITRS_BL.BLImgRemote bl = new ITRS_BL.BLImgRemote();
					img = bl.GetImgFromC2P(qmgr, targaRil, dataOraRilevamento);

					if (img != null)
					{
						// memorizzo l'immagine nel db
						try
						{
							blTransiti.SaveImmagine(targa, nazionalita, dataOraRilevamento, img);
						}
						catch (Exception ex)
						{
							Log.Write(ex, "SaveImmagine");
						}
					}
				}
			}
			catch
			{
				img = null;
			}

			return img;
		}

		public void GetLatLonTransito(string targa, string nazionalita, DateTime dataOraRilevamento, out double lat, out double lon)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			t.GetLatLonTransito(targa, nazionalita, dataOraRilevamento, out lat, out lon);
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<Transiti> GetTransiti(string sortColumns, int startRowIndex, int maximumRows)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			List<Transiti> lt = t.GetTransiti(sortColumns, startRowIndex, maximumRows);
			return lt;
		}

		public int GetTransitiCount()
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			return t.GetTransitiCount();
		}


		/// <summary>
		/// Legge i dati del transito. La sorgente dei dati e` la tabella TRANSITI
		/// o, se il record NON esiste, la tabella TRANSITISUEVENTO
		/// </summary>
		/// <param name="targa"></param>
		/// <param name="nazionalita"></param>
		/// <param name="dataOraRilevamento"></param>
		/// <returns></returns>
		public DatiTransito GetDatiTransitoOrTransitoSuEvento(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			return t.GetDatiTransitoOrTransitoSuEvento(targa, nazionalita, dataOraRilevamento);
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<DatiTransito> GetTransitiDellEvento(string targa, string nazionalita, DateTime dataOraInserimento, int idEvento, string sortColumns)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			return t.GetTransitiDellEvento(targa, nazionalita, dataOraInserimento, idEvento, sortColumns);
		}

		public bool PrendiInCarico(string targa, string nazionalita, DateTime dataOraRilevamento, string idUtentePresaInCarico)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			return t.PrendiInCarico(targa, nazionalita, dataOraRilevamento, idUtentePresaInCarico);
		}

		public bool AzioneSuPresaInCarico(string targa, string nazionalita, DateTime dataOraRilevamento, StatoTransito statoTransito, string noteChiusura, string TargaValidata, string NazionalitaValidata)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			return t.AzioneSuPresaInCarico(targa, nazionalita, dataOraRilevamento, statoTransito, noteChiusura, TargaValidata, NazionalitaValidata);
		}

		///// <summary>
		///// Cambio targa di un transito non riconosciuto automaticamente.
		///// Il transito va in stato RIC.
		///// </summary>
		///// <param name="targa"></param>
		///// <param name="nazionalita"></param>
		///// <param name="dataOraRilevamento"></param>
		///// <param name="targaRiconosciutaDallOperatore"></param>
		///// <param name="nazioneRiconosciutaDallOperatore"></param>
		///// <param name="note"></param>
		//public void RiconoscimentoManuale(string targa, string nazionalita, DateTime dataOraRilevamento, string targaRiconosciutaDallOperatore, string nazioneRiconosciutaDallOperatore, string note)
		//{
		//    IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
		//    t.RiconoscimentoManuale(targa, nazionalita, dataOraRilevamento, targaRiconosciutaDallOperatore, nazioneRiconosciutaDallOperatore, note);
		//}

		public void GetTransitoData(string targa, string naz, DateTime dataOraRilevamento, out string targaRil, out int idC2P, out string qmgr)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			t.GetTransitoData(targa, naz, dataOraRilevamento, out targaRil, out idC2P, out qmgr);
		}

		public void SaveImmagine(string targa, string naz, DateTime dataOraRilevamento, byte[] img)
		{
			IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
			t.SaveImmagine(targa, naz, dataOraRilevamento, img);
		}


		public DatiTarga GetDatiTarga(string targa, string naz, DateTime dataOraRilevamento)
		{
			try
			{
				IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
				return t.GetDatiTarga(targa, naz, dataOraRilevamento);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetDatiTarga");
				throw;
			}
		}

		public List<TransitoPresoInCarico> GetListaTransitiPresiInCarico(string sort, int? IdCoa)
		{
			try
			{
				IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
				return t.GetListaTransitiPresiInCarico(sort, IdCoa);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetListaTransitiPresiInCarico");
				throw;
			}
		}

		public bool AnnullaTransitoPresoInCarico(string targa, string nazionalita, DateTime dataOraRilevamento)
		{
			try
			{
				IDalTransiti t = DalProvider.DAL.CreateDalTransiti();
				return t.AnnullaTransitoPresoInCarico(targa, nazionalita, dataOraRilevamento);
			}
			catch (Exception ex)
			{
				Log.Write(ex, "AnnullaTransitoPresoInCarico");
				throw;
			}
		}

	}
	#endregion

	public enum StatoTransito
	{
		/// <summary>
		/// DaRiconoscere
		/// </summary>
		DARIC = 0,

		/// <summary>
		/// Riconosciuto
		/// </summary>
		RIC = 1,

		/// <summary>
		/// NonRiconoscito
		/// </summary>
		NORIC = 2,

		/// <summary>
		/// PresoInCarico
		/// </summary>
		PIC = 3,
	}

	public enum TipoVarco
	{
		/// <summary>
		/// CorsiaSinistra
		/// </summary>
		S = 0,
		/// <summary>
		/// CorsiaDestra
		/// </summary>
		D = 1,

		/// <summary>
		/// EntrataAreaDiServizio
		/// </summary>
		E = 2,

		/// <summary>
		/// UscitaAreaDiServizio
		/// </summary>
		U = 3,
	}

	public enum Direzione
	{
		NORD,
		SUD
	}

	[Serializable]
	public class Transiti
	{
		[DataObjectField(true)]
		public string Targa { get { return _targa; } set { _targa = value; } }

		[DataObjectField(true)]
		public string Nazionalita { get { return _nazionalita; } set { _nazionalita = value; } }

		[DataObjectField(true)]
		public DateTime DataOraRilevamento { get { return _dataOraRilevamento; } set { _dataOraRilevamento = value; } }

		public string TipoVarco { get { return _tipoVarco; } set { _tipoVarco = value; } }
		public string StatoTransito { get { return _statoTransito; } set { _statoTransito = value; } }
		public int IdC2P { get { return _idC2P; } set { _idC2P = value; } }
		public decimal ProgressivoQuery { get { return _progressivoQuery; } set { _progressivoQuery = value; } }

		#region dati
		private decimal _progressivoQuery;
		private string _targa;
		private string _nazionalita;
		private DateTime _dataOraRilevamento;
		private string _tipoVarco;
		private string _statoTransito;
		private int _idC2P;
		#endregion
	}

	[Serializable]
	public class DatiTransito
	{
		[DataObjectField(true)]
		public string Targa { get { return TARGA; } set { TARGA = value; } }
		[DataObjectField(true)]
		public string Nazionalita { get { return NAZIONALITA; } set { NAZIONALITA = value; } }
		[DataObjectField(true)]
		public DateTime DataOraRilevamento { get { return DATAORARILEVAMENTO; } set { DATAORARILEVAMENTO = value; } }
		public string CodiceStrada { get { return CODICESTRADA; } set { CODICESTRADA = value; } }
		public string DescrizioneC2P { get { return DESCRIZIONEC2P; } set { DESCRIZIONEC2P = value; } }
		public Direzione DirezioneC2P { get { return DIREZIONEC2P; } set { DIREZIONEC2P = value; } }
		public TipoVarco TipoVarco { get { return TIPOVARCO; } set { TIPOVARCO = value; } }
		public StatoTransito StatoTransito { get { return STATOTRANSITO; } set { STATOTRANSITO = value; } }
		public decimal? Latitudine { get { return LATITUDINE; } set { LATITUDINE = value; } }
		public decimal? Longitudine { get { return LONGITUDINE; } set { LONGITUDINE = value; } }
		public string MarcaVeicolo { get { return MARCAVEICOLO; } set { MARCAVEICOLO = value; } }
		public string ModelloVeicolo { get { return MODELLOVEICOLO; } set { MODELLOVEICOLO = value; } }
		public DateTime? DataOraPresaInCarico { get { return DATAORAPRESAINCARICO; } set { DATAORAPRESAINCARICO = value; } }
		public DateTime? DataOraChiusura { get { return DATAORACHIUSURA; } set { DATAORACHIUSURA = value; } }
		public string UtentePresaInCarico { get { return UTENTEPRESAINCARICO; } set { UTENTEPRESAINCARICO = value; } }
		public string NoteChiusura { get { return NOTECHIUSURA; } set { NOTECHIUSURA = value; } }

		public string TargaAcquisita { get { return TARGAACQUISITA; } set { TARGAACQUISITA = value; } }
		public string NazionalitaAcquisita { get { return NAZIONALITAACQUISITA; } set { NAZIONALITAACQUISITA = value; } }

		#region Dati
		string TARGA;
		string NAZIONALITA;

		string TARGAACQUISITA;
		string NAZIONALITAACQUISITA;

		DateTime DATAORARILEVAMENTO;
		string DESCRIZIONEC2P;
		string CODICESTRADA;
		Direzione DIREZIONEC2P;
		TipoVarco TIPOVARCO;
		StatoTransito STATOTRANSITO;
		decimal? LATITUDINE;
		decimal? LONGITUDINE;
		string MARCAVEICOLO;
		string MODELLOVEICOLO;
		DateTime? DATAORAPRESAINCARICO;
		DateTime? DATAORACHIUSURA;
		string UTENTEPRESAINCARICO;
		string NOTECHIUSURA;
		#endregion
	}

	[Serializable]
	public class DatiTarga
	{
		int? _PL_XSTART;
		int? _PL_YSTART;
		int? _PL_XEND;
		int? _PL_YEND;
		string _PL_NET_ID;
		string _PL_LAYOUT_ID;
		string _PL_VEHICLETYPE;
		string _PL_VEHICLE_ID;

		public int? xStart { get { return _PL_XSTART; } set { _PL_XSTART = value; } }
		public int? yStart { get { return _PL_YSTART; } set { _PL_YSTART = value; } }
		public int? xEnd { get { return _PL_XEND; } set { _PL_XEND = value; } }
		public int? yEnd { get { return _PL_YEND; } set { _PL_YEND = value; } }
		public string NetId { get { return _PL_NET_ID; } set { _PL_NET_ID = value; } }
		public string LayoutId { get { return _PL_LAYOUT_ID; } set { _PL_LAYOUT_ID = value; } }
		public string VehicleType { get { return _PL_VEHICLETYPE; } set { _PL_VEHICLETYPE = value; } }
		public string VehicleId { get { return _PL_VEHICLE_ID; } set { _PL_VEHICLE_ID = value; } }
	}

	[Serializable]
	public class TransitoPresoInCarico
	{
		public String Targa { get { return _Targa; } set { _Targa = value; } }
		public String Nazionalita { get { return _Nazionalita; } set { _Nazionalita = value; } }
		public DateTime DataOraRilevamento { get { return _DataOraRilevamento; } set { _DataOraRilevamento = value; } }
		public DateTime? DataOraPresaInCarico { get { return _DataOraPresaInCarico; } set { _DataOraPresaInCarico = value; } }
		public TipoVarco TipoVarco { get { return _TipoVarco; } set { _TipoVarco = value; } }
		public Direzione Direzione { get { return _Direzione; } set { _Direzione = value; } }
		public String AreaDiServizio { get { return _AreaDiServizio; } set { _AreaDiServizio = value; } }
		public String Strada { get { return _Strada; } set { _Strada = value; } }
		public String CoaDiCompetenza { get { return _CoaDiCompetenza; } set { _CoaDiCompetenza = value; } }
		public String Operatore { get { return _Operatore; } set { _Operatore = value; } }

		#region dati
		protected String _Targa;
		protected String _Nazionalita;
		protected DateTime _DataOraRilevamento;
		protected DateTime? _DataOraPresaInCarico;
		protected TipoVarco _TipoVarco;
		protected Direzione _Direzione;
		protected String _AreaDiServizio;
		protected String _Strada;
		protected String _CoaDiCompetenza;
		protected String _Operatore;
		#endregion
	}
}
