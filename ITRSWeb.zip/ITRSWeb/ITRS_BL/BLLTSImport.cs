using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using ITRS_BL.IDal;
using ITRS_BL.MWPServices;

namespace ITRS_BL
{
	public partial class BLLTSImport : Component
	{
		public enum TipoLTS { A1, A2 }

		public BLLTSImport()
		{
			InitializeComponent();
		}
		public BLLTSImport(IContainer container)
		{
			container.Add(this);

			InitializeComponent();
		}

		public void ImportIncrementaleA1(string userName, string fileName, byte[] fileDaImportare)
		{
			try
			{
				string LocalWorkingDir = ReadAppSettings.ToString("LTS_Import.ImportMassivo.LocalWorkingDir", @"$$\ITRS_Service\tmp_ImportMassivo");
				if (!Directory.Exists(LocalWorkingDir))
					Directory.CreateDirectory(LocalWorkingDir);

				string fn = Path.GetFileName(fileName);

				string fileNameWithPath = Path.Combine(LocalWorkingDir, fn);
				using (FileStream fs = File.Create(fileNameWithPath))
				{
					fs.Write(fileDaImportare, 0, fileDaImportare.Length);
				}

				bool onLinux = false;
				ImportIncrementaleA1(userName, fileNameWithPath, onLinux);
			}
			catch (FileNotFoundException)
			{
				throw;
			}
			catch (Exception ex)
			{
				LogWrite(ex, userName, "ImportIncrementale");
				throw;
			}
		}
		public void ImportIncrementaleA1(string userName, string fileDaImportare, bool onLinux)
		{
			bool b = ControlloEsistenzaFile(onLinux, fileDaImportare);
			if (!b)
				throw new FileNotFoundException("File non trovato", fileDaImportare);

			U.ThreadPool.QueueUserWorkItem(ImportIncrementaleA1_Worker_QueryLock, userName, fileDaImportare, onLinux);
		}

		public void ImportMassivo(string userName, string fileName, byte[] fileDaImportare, TipoLTS tipoLTS)
		{
			try
			{
				string LocalWorkingDir = ReadAppSettings.ToString("LTS_Import.ImportMassivo.LocalWorkingDir", @"$$\ITRS_Service\tmp_ImportMassivo");
				if (!Directory.Exists(LocalWorkingDir))
					Directory.CreateDirectory(LocalWorkingDir);

				string fn = Path.GetFileName(fileName);

				string fileNameWithPath = Path.Combine(LocalWorkingDir, fn);
				using (FileStream fs = File.Create(fileNameWithPath))
				{
					fs.Write(fileDaImportare, 0, fileDaImportare.Length);
				}

				bool onLinux = false;
				ImportMassivo(userName, fileNameWithPath, tipoLTS, onLinux);
			}
			catch (FileNotFoundException)
			{
				throw;
			}
			catch (Exception ex)
			{
				LogWrite(ex, userName, "ImportMassivo");
				throw;
			}
		}
		public void ImportMassivo(string userName, string fileDaImportare, TipoLTS tipoLTS, bool onLinux)
		{
			bool b = ControlloEsistenzaFile(onLinux, fileDaImportare);
			if (!b)
				throw new FileNotFoundException("File non trovato", fileDaImportare);

			U.ThreadPool.QueueUserWorkItem(ImportMassivoWorker_QueryLock, userName, fileDaImportare, tipoLTS, onLinux);
		}

		public List<string> GetListaFileSuLinuxPerImport(out bool error)
		{
			try
			{
				string RemotePath = ReadAppSettings.ToString("RemoteDir.AllineamentoTargheCEPS", "AllineamentoTargheCEPS");
				string[] dir = U.PuTTYClient.Dir(null, RemotePath);

				List<string> ret = new List<string>();
				foreach (string fileName in dir)
				{
					string ext = Path.GetExtension(fileName);
					if (ext == ".zip" || ext == ".txt")
						ret.Add(fileName);
				}
				error = false;

				ret.Sort();
				ret.Reverse();
				return ret;
			}
			catch (Exception ex)
			{
				error = true;
				Log.Write(ex, "GetListaFileSuLinuxPerImport");

				List<string> ret = new List<string>();
				return ret;
			}
		}
		public void Reset_A1BC_C2P(string userName, int? IdC2p, bool ignoraA2)
		{
			U.ThreadPool.QueueUserWorkItem(ResetC2P_A1BC_Worker_QueryLock, userName, IdC2p, ignoraA2);
		}

		public void CancellaLTS(string userName, TipoLTS tipoLTS)
		{
			U.ThreadPool.QueueUserWorkItem(CancellaLTSWorker_QueryLock, userName, tipoLTS);
		}


		private void SendAttivazioneA2(string userName, int IdC2P, DateTime di, DateTime df, int deltaGiorni, string tipoVeicolo, string corsie)
		{
			try
			{
				MWPAttivazioneA2 mwp = new MWPAttivazioneA2();

				string t = mwp.BuildAttivazioneMessage(di, df, deltaGiorni, tipoVeicolo, corsie);

				using (BLC2P bl = new BLC2P())
				{
					C2P c2p = bl.GetC2P(IdC2P);
					mwp.SendMsg(t, c2p.QmgrName);

					LogWrite(userName, "Attivazione A2 - C2P={0} inizio={1} fine={2} delta={3} veicolo={4} corsie={5}",
						c2p.Descrizione, di, df, deltaGiorni, tipoVeicolo, corsie);
				}
			}
			catch (Exception ex)
			{
				LogWrite(ex, userName, "AttivazioneA2: terminata con errore ({0})", ex.Message);
				throw;
			}
		}

		private void SendDisattivazioneA2(string userName, int IdC2P)
		{
			try
			{
				MWPAttivazioneA2 mwp = new MWPAttivazioneA2();

				string t = mwp.BuildDisattivazioneMessage();

				using (BLC2P bl = new BLC2P())
				{
					C2P c2p = bl.GetC2P(IdC2P);
					mwp.SendMsg(t, c2p.QmgrName);
					LogWrite(userName, "Disattivazione A2 - C2P={0}", c2p.Descrizione);
				}

			}
			catch (Exception ex)
			{
				LogWrite(ex, userName, "DisattivazioneA2: terminata con errore ({0})", ex.Message);
				throw;
			}
		}

		[DataObjectMethod(DataObjectMethodType.Select)]
		public List<AttivazioneA2> GetListaAttivazioneA2()
		{
			IDalLTSImport dal = DalProvider.DAL.CreateDalLTSImport();
			return dal.GetListaAttivazioneA2();
		}

		[DataObjectMethod(DataObjectMethodType.Update)]
		public void AggiornaAttivazioneA2(string userName,
			Int16 IdC2P,
			 String Descrizione,
			 DateTime? DataOraInizioAttivazione,
			 DateTime? DataOraFineAttivazione,
			 Int32? GiorniTolleranzaRevisione,
			 String TipoVeicolo,
			String CorsieAbilitate)
		{
			AttivazioneA2 r = new AttivazioneA2();
			r.IdC2P = IdC2P;
			r.Descrizione = Descrizione;
			r.DataOraInizioAttivazione = DataOraInizioAttivazione;
			r.DataOraFineAttivazione = DataOraFineAttivazione;
			r.GiorniTolleranzaRevisione = GiorniTolleranzaRevisione;
			r.TipoVeicolo = TipoVeicolo;
			r.CorsieAbilitate = CorsieAbilitate;

			AggiornaAttivazioneA2(userName, r);
		}


		[DataObjectMethod(DataObjectMethodType.Update)]
		public void AggiornaAttivazioneA2(string userName, AttivazioneA2 r)
		{
			IDalLTSImport dal = DalProvider.DAL.CreateDalLTSImport();

			if (r.DataOraInizioAttivazione.HasValue)
			{
				SendAttivazioneA2(userName, r.IdC2P,
					r.DataOraInizioAttivazione.Value, r.DataOraFineAttivazione.Value,
					r.GiorniTolleranzaRevisione.Value,
					r.TipoVeicolo,
					r.CorsieAbilitate);

				dal.AggiornaAttivazioneA2(r);
			}
			else
			{
				SendDisattivazioneA2(userName, r.IdC2P);
				dal.AggiornaAttivazioneA2(r);
			}
		}



		// /////////////////////////////////////////////////////////////////////////

		private static void CancellaLTSWorker_QueryLock(string userName, TipoLTS tipoLTS)
		{
			using (IDalLock serverLock = DalProvider.DAL.CreateDalLock("Import_A1"))
			{
				if (serverLock.IsLockAcquired)
				{
					// ok: sono solo al mondo... posso fare l'import.
					CancellaLTSWorker_LockAcquired(userName, tipoLTS);
				}
				else
					LogWrite(userName, "Reset C2P: impossibile iniziare l'attivita` in quando un altro import/reset e` in corso");
			}
		}
		private static void CancellaLTSWorker_LockAcquired(string userName, TipoLTS tipoLTS)
		{
			try
			{
				LogWrite(userName, "Cancellazione/reset LTS: iniziata");

				IDalLTSImport dal = DalProvider.DAL.CreateDalLTSImport();
				dal.CancellaLTS(tipoLTS);

				if (tipoLTS != TipoLTS.A2)
				{
					bool ignoraA2 = true;
					ResetC2P_A1BC_Worker_LockAcquired(userName, null, ignoraA2);
				}
				else
				{
					ResetC2P_A2_Worker_LockAcquired(userName);
				}

				LogWrite(userName, "Cancellazione/reset: terminata con successo");

				U.GC_Collect();
			}
			catch (Exception ex)
			{
				U.GC_Collect();

				LogWrite(ex, userName, "ImportMassivo: terminato con errore ({0})", ex.Message);
				throw;
			}
		}


		private static void ImportIncrementaleA1_Worker_QueryLock(string userName, string fileDaImportare, bool onLinux)
		{
			using (IDalLock serverLock = DalProvider.DAL.CreateDalLock("Import_A1"))
			{
				if (serverLock.IsLockAcquired)
				{
					// ok: sono solo al mondo... posso fare l'import.
					ImportIncrementaleA1_Worker_LockAcquired(userName, fileDaImportare, onLinux);
				}
				else
					LogWrite(userName, "Import incrementale targhe: impossibile iniziare l'attivita` in quando un altro import e` in corso");
			}  // -> qui si rilascia il lock
		}
		private static void ImportMassivoWorker_QueryLock(string userName, string fileDaImportare, TipoLTS tipoLTS, bool onLinux)
		{
			using (IDalLock serverLock = DalProvider.DAL.CreateDalLock("Import_A1"))
			{
				if (serverLock.IsLockAcquired)
				{
					// ok: sono solo al mondo... posso fare l'import.
					ImportMassivoWorker_LockAcquired(userName, fileDaImportare, tipoLTS, onLinux);
				}
				else
					LogWrite(userName, "Import massivo targhe: impossibile iniziare l'attivita` in quando un altro import e` in corso");
			}  // -> qui si rilascia il lock
		}
		private static void ResetC2P_A1BC_Worker_QueryLock(string userName, int? IdC2P, bool ignoraA2)
		{
			using (IDalLock serverLock = DalProvider.DAL.CreateDalLock("Import_A1"))
			{
				if (serverLock.IsLockAcquired)
				{
					// ok: sono solo al mondo... posso fare l'import.
					ResetC2P_A1BC_Worker_LockAcquired(userName, IdC2P, ignoraA2);
				}
				else
					LogWrite(userName, "Reset C2P: impossibile iniziare l'attivita` in quando un altro import/reset e` in corso");
			}  // -> qui si rilascia il lock
		}

		private static void ImportIncrementaleA1_Worker_LockAcquired(string userName, string fileDaImportare, bool onLinux)
		{
			try
			{
				LogWrite(userName, "Import incrementale A1 targhe: inizio");

				fileDaImportare = TrasferisciFileInLocale(userName, fileDaImportare, onLinux);

				IDalLTSImport dal = DalProvider.DAL.CreateDalLTSImport();
				using (FileStream s = File.OpenRead(fileDaImportare))
				{
					bool daImportMassivo = false;
					bool inviaMessaggiDeltaAiC2P = false;
					dal.ImportIncrementaleA1(userName, s, daImportMassivo, inviaMessaggiDeltaAiC2P);

					if (inviaMessaggiDeltaAiC2P == false)
					{
						bool ignoraA2 = true;
						ResetC2P_A1BC_Worker_LockAcquired(userName, null, ignoraA2);
					}
				}

				LogWrite(userName, "Import incrementale targe: terminato con successo");

				U.GC_Collect();
			}
			catch (Exception ex)
			{
				U.GC_Collect();
				LogWrite(ex, userName, "ImportIncrementaleWorker");
				throw;
			}
		}
		public static void ImportMassivoWorker_LockAcquired(string userName, string fileDaImportare, TipoLTS tipoLTS, bool onLinux)
		{
			try
			{
				LogWrite(userName, "ImportMassivo: iniziato");

				string fileDaImportareOnLinux = null;
				if (onLinux) fileDaImportareOnLinux = fileDaImportare;

				fileDaImportare = TrasferisciFileInLocale(userName, fileDaImportare, onLinux);

				// qui leggo il file, lo parsifico e lo inserisco nel DB
				// dopo aver cancellato tutte le entry nella tabella per A1 o per A2.
				IDalLTSImport dal = DalProvider.DAL.CreateDalLTSImport();
				dal.ImportMassivo(tipoLTS, userName, fileDaImportare);
				LogWrite(userName, "ImportMassivo: import delle targhe nel DB terminato");

				// qui carico la lista delle nuove targhe ai C2P
				if (tipoLTS != TipoLTS.A2)
				{
					bool ignoraA2 = true;
					ResetC2P_A1BC_Worker_LockAcquired(userName, null, ignoraA2);
				}
				else
				{
					ResetC2P_A2_Worker_LockAcquired(userName);
				}

				File.Delete(fileDaImportare);

				LogWrite(userName, "ImportMassivo: terminato con successo");

				U.GC_Collect();
			}
			catch (Exception ex)
			{
				U.GC_Collect();

				LogWrite(ex, userName, "ImportMassivo: terminato con errore ({0})", ex.Message);
				throw;
			}
		}
		private static void ResetC2P_A1BC_Worker_LockAcquired(string userName, int? IdC2P, bool ignoraA2)
		{
			LogWrite(userName, "Reset dei C2P A1/B/C: inizio");

			string fileSuff = "";
			if (IdC2P.HasValue)
				fileSuff = "_" + IdC2P.Value.ToString();

			try
			{
				string LocalWorkingDir = ReadAppSettings.ToString("LTS_Import.ResetAndReloadC2PfromLTS.LocalWorkingDir", @"$$\ITRS_Service\tmp_ResetC2P");
				if (!Directory.Exists(LocalWorkingDir)) Directory.CreateDirectory(LocalWorkingDir);

				IDalLTS dal = DalProvider.DAL.CreateDalLTS();

				// file da produrre - qui ho il path completo.
				// lettura del DB tabella LTS e scrittura del file xml in locale.
				string fileNameWithPath;
				{
					fileNameWithPath = Path.Combine(LocalWorkingDir, "A1" + fileSuff + ".txt");

					using (U.GC_Collecter gc = new U.GC_Collecter("SqlLoaderListaNeraWriter"))
					{
						using (SqlLoaderListaNeraWriter xW = new SqlLoaderListaNeraWriter(fileNameWithPath))
						{
							// qui si fa la query
							DateTime validoIl = DateTime.Now;
							foreach (MWPDataLTS e in dal.UpdateC2PfromLTS(validoIl, ignoraA2))
							{
								xW.Add(e);
								gc.Collect();
							}
						}
					}
				}

				U.GC_Collect();

				// zippo il file appena prodotto di <nome>.txt in <nome>.zip
				string fileNameWithPathZipped;
				{
					// qui produco il file zippato
					fileNameWithPathZipped = U.ZipSingleFile(fileNameWithPath, LocalWorkingDir);

					// cancello il file NON zippato
					File.Delete(fileNameWithPath);

					fileNameWithPath = null;//lo annullo cosi` se per caso lo usa fa bum
					LogWrite(userName, "Reset dei C2P: file per i C2P zippato {0}", fileNameWithPathZipped);
				}

				// lo spedisco a linux
				{
					string RemotePath = ReadAppSettings.ToString("RemoteDir.AllineamentoTargheC2P", "AllineamentoTargheC2P");

					U.PuTTYClient.Upload(null,
						Path.GetDirectoryName(fileNameWithPathZipped), Path.GetFileName(fileNameWithPathZipped),
						RemotePath, null);

					File.Delete(fileNameWithPathZipped);
					LogWrite(userName, "Reset dei C2P: trasferito il file {0} al server Linux", fileNameWithPathZipped);
				}

				// costruisco il nome del file .zip secondo il gusto di linux
				string remoteFileNameWithPathZip;
				{
					// RemoteFile e` la directory completa in Linux di dove si trova il file zippato
					// (e puo` essere diversa da FTP_RemotePath)
					string remoteDirectory = ReadAppSettings.ToString("LTS_Import.ResetAndReloadC2PfromLTS.RemoteDirectory", "/usr/mwp/AllineamentoTargheC2P");
					if (!remoteDirectory.EndsWith("/")) remoteDirectory += "/";
					remoteFileNameWithPathZip = remoteDirectory + Path.GetFileName(fileNameWithPathZipped); // "LTSCEPS.zip"
				}

				// genero tanti messaggi quanti sono i C2P
				{
					// qui ottengo la lista dei C2P
					List<MWPC2PInfo> c2p;

					{
						if (IdC2P.HasValue == false)
							c2p = dal.GetListC2P();
						else
							c2p = dal.GetListC2P(IdC2P.Value);
					}
					foreach (MWPC2PInfo c in c2p)
						c.DataOraRilevamento = null;

					// qui infine creo i messaggi per i C2P.
					MWPInterface blMWP = new MWPInterface();
					blMWP.AllineamentoMassivoC2P(c2p, remoteFileNameWithPathZip);

					// non posso cancellare il file .zip in remoto perche` 
					// non so quando tutti i C2P si decideranno di prendersi il file
					// ed elaborarlo.
					// Non mi risulta che esista una diagnostica al riguardo.

					if (IdC2P.HasValue == false)
						LogWrite(userName, "Reset dei C2P: inviato messaggio di reset a tutti i C2P");
					else
					{
						try
						{
							using (BLC2P blC2P = new BLC2P())
							{
								C2P rere = blC2P.GetC2P(IdC2P.Value);
								LogWrite(userName, "Reset dei C2P: inviato messaggio di reset al C2P {0}", rere.Descrizione);
							}
						}
						catch
						{
							LogWrite(userName, "Reset dei C2P: inviato messaggio di reset al C2P {0}", IdC2P.Value);
						}
					}
				}

				LogWrite(userName, "Reset dei C2P: terminato con successo");

				U.GC_Collect();

			}
			catch (Exception ex)
			{
				U.GC_Collect();
				Log.Write(ex, "BLLTS.ResetAndReloadC2PfromLTS");

				LogWrite(userName, "Reset dei C2P terminato con errore");
				throw;
			}
		}

		private static void ResetC2P_A2_Worker_LockAcquired(string userName)
		{
			LogWrite(userName, "Reset dei C2P A2: inizio");

			try
			{
				string LocalWorkingDir = ReadAppSettings.ToString("LTS_Import.ResetAndReloadC2PfromLTS.LocalWorkingDir", @"$$\ITRS_Service\tmp_ResetC2P");
				if (!Directory.Exists(LocalWorkingDir)) Directory.CreateDirectory(LocalWorkingDir);

				IDalLTS dal = DalProvider.DAL.CreateDalLTS();

				// file da produrre - qui ho il path completo.
				// lettura del DB tabella LTS e scrittura del file xml in locale.
				string fileNameWithPath;
				{
					fileNameWithPath = Path.Combine(LocalWorkingDir, "A2.txt");

					using (U.GC_Collecter gc = new U.GC_Collecter("SqlLoaderListaNeraWriter"))
					{
						using (SqlLoaderListaNeraA2Writer xW = new SqlLoaderListaNeraA2Writer(fileNameWithPath))
						{
							// qui si fa la query
							foreach (MWPDataLTS_A2 e in dal.UpdateC2PfromLTS_A2())
							{
								xW.Add(e);
								gc.Collect();
							}
						}
					}
				}

				U.GC_Collect();

				// zippo il file appena prodotto di <nome>.txt in <nome>.zip
				string fileNameWithPathZipped;
				{
					// qui produco il file zippato
					fileNameWithPathZipped = U.ZipSingleFile(fileNameWithPath, LocalWorkingDir);

					// cancello il file NON zippato
					File.Delete(fileNameWithPath);

					fileNameWithPath = null;//lo annullo cosi` se per caso lo usa fa bum
					LogWrite(userName, "Reset dei C2P A2: file per i C2P zippato {0}", fileNameWithPathZipped);
				}

				// lo spedisco a linux
				{
					string RemotePath = ReadAppSettings.ToString("RemoteDir.AllineamentoTargheC2P", "AllineamentoTargheC2P");

					U.PuTTYClient.Upload(null,
						Path.GetDirectoryName(fileNameWithPathZipped), Path.GetFileName(fileNameWithPathZipped),
						RemotePath, null);

					File.Delete(fileNameWithPathZipped);
					LogWrite(userName, "Reset dei C2P A2: trasferito il file {0} al server Linux", fileNameWithPathZipped);
				}

				// costruisco il nome del file .zip secondo il gusto di linux
				string remoteFileNameWithPathZip;
				{
					// RemoteFile e` la directory completa in Linux di dove si trova il file zippato
					// (e puo` essere diversa da FTP_RemotePath)
					string remoteDirectory = ReadAppSettings.ToString("LTS_Import.ResetAndReloadC2PfromLTS.RemoteDirectory", "/usr/mwp/AllineamentoTargheC2P");
					if (!remoteDirectory.EndsWith("/")) remoteDirectory += "/";
					remoteFileNameWithPathZip = remoteDirectory + Path.GetFileName(fileNameWithPathZipped); // "LTSCEPS.zip"
				}

				// genero tanti messaggi quanti sono i C2P
				{
					// qui ottengo la lista dei C2P
					List<MWPC2PInfo> c2p = dal.GetListC2P();
					foreach (MWPC2PInfo c in c2p)
						c.DataOraRilevamento = null;

					// qui infine creo i messaggi per i C2P.
					MWPInterface blMWP = new MWPInterface();
					blMWP.AllineamentoMassivoC2P(c2p, remoteFileNameWithPathZip);

					// non posso cancellare il file .zip in remoto perche` 
					// non so quando tutti i C2P si decideranno di prendersi il file
					// ed elaborarlo.
					// Non mi risulta che esista una diagnostica al riguardo.

					LogWrite(userName, "Reset dei C2P A2: inviato messaggio di reset a tutti i C2P");
				}

				LogWrite(userName, "Reset dei C2P A2: terminato con successo");

				U.GC_Collect();

			}
			catch (Exception ex)
			{
				U.GC_Collect();
				Log.Write(ex, "BLLTS.ResetC2P_A2_Worker_LockAcquired");

				LogWrite(userName, "Reset dei C2P terminato con errore");
				throw;
			}
		}

		private static bool ControlloEsistenzaFile(bool onLinux, string fileName)
		{
			// controllo che almeno esista il file!

			if (onLinux == false)
			{
				return File.Exists(fileName);
			}
			else
			{
				string RemotePath = ReadAppSettings.ToString("RemoteDir.AllineamentoTargheCEPS", "AllineamentoTargheCEPS");

				// sara` in Linux ?
				// Qui controllo se esiste il file!
				// Non controllo il formato!
				foreach (string g in U.PuTTYClient.Dir(null, RemotePath))
					if (g == fileName)
						return true;
				return false;
			}
		}
		private static string TrasferisciFileInLocale(string userName, string fileDaImportare, bool onLinux)
		{
			// directory in cui si depositano gli eventuali file intermedi.
			string LocalWorkingDir = ReadAppSettings.ToString("LTS_Import.ImportMassivo.LocalWorkingDir", @"$$\ITRS_Service\tmp_ImportMassivo");
			if (!Directory.Exists(LocalWorkingDir)) Directory.CreateDirectory(LocalWorkingDir);

			if (onLinux)
			{
				LogWrite(userName, "ImportMassivo: trasfererimento del il file {0} in corso", fileDaImportare);
				string RemotePath = ReadAppSettings.ToString("RemoteDir.AllineamentoTargheCEPS", "AllineamentoTargheCEPS");
				U.PuTTYClient.Download(null, RemotePath, fileDaImportare, LocalWorkingDir, null);
				LogWrite(userName, "ImportMassivo: trasferito il file {0}", fileDaImportare);
				fileDaImportare = Path.Combine(LocalWorkingDir, fileDaImportare);
			}

			if (Path.GetExtension(fileDaImportare).ToLower() == ".zip")
			{
				string fileNameWithPathUnzipped = U.UnzipSingleFile(fileDaImportare, LocalWorkingDir);
				File.Delete(fileDaImportare);
				fileDaImportare = fileNameWithPathUnzipped;

				LogWrite(userName, "ImportMassivo: unzippato il file");
			}
			return fileDaImportare;
		}


		static Thread _thServerMain;
		static AutoResetEvent _evStop;

		/// <summary>
		/// Server che sta in polling in Linux in attesa dei file delle targhe rubate/veicoli non revisionati
		/// per elaborarli
		/// </summary>
		public static void StartServer()
		{
			_evStop = new AutoResetEvent(false);
			_thServerMain = new Thread(ImportMassivoServerThread);
			_thServerMain.IsBackground = true;
			_thServerMain.Start();
		}
		public static void StopServer()
		{
			try
			{
				_evStop.Set();
				_thServerMain.Join(5 * 1000);

				_thServerMain = null;
				_evStop = null;
			}
			catch
			{
			}
			// non killo il thread ... (se sta facendo l'import il kill e` doloroso !!)
		}

		#region LogWrite
		private static void LogWrite(Exception ex, string userName, string fmt, params object[] args)
		{
			try
			{
				string a = string.Format(fmt, args);
				LogWrite(ex, userName, a);
			}
			catch { }
		}

		private static void LogWrite(Exception ex, string userName, string a)
		{
			try
			{
				LogWrite(userName, a + " - " + ex.Message);
				Log.Write(ex, a);
			}
			catch { }
		}

		private static void LogWrite(string userName, string fmt, params object[] args)
		{
			try
			{
				string a = string.Format(fmt, args);
				LogWrite(userName, a);
			}
			catch { }
		}
		private static void LogWrite(string userName, string a)
		{
			try
			{
				using (BLLog blLog = new BLLog())
					blLog.AddUserActivity(userName, TipoAttivita.ImportLTS, a);
			}
			catch { }
		}
		#endregion

		class SqlLoaderListaNeraWriter : IDisposable
		{
			StreamWriter _sw;

			public SqlLoaderListaNeraWriter(string fileToProcess)
			{
				_sw = File.CreateText(fileToProcess);
			}

			public void Close()
			{
				if (_sw != null)
				{
					_sw.Close();
					_sw = null;
				}
			}

			public void Dispose()
			{
				Close();
			}


			public void Add(MWPDataLTS r)
			{
				// AA000AA|I|12/07/2005 12:00:00|12/12/2007 23:59:59|N
				// AA000AA|F|12/07/2004 12:00:00|12/12/2007 23:59:59|N

				_sw.Write(r.targa);
				_sw.Write("|");
				_sw.Write(r.nazionalita);
				_sw.Write("|");
				_sw.Write(r.dataOraInizio.ToString(@"dd/MM/yyyy HH\:mm\:ss"));
				_sw.Write("|");
				_sw.Write(r.dataOraFine.ToString(@"dd/MM/yyyy HH\:mm\:ss"));
				_sw.Write("|");
				_sw.WriteLine("N");
			}
		}

		class SqlLoaderListaNeraA2Writer : IDisposable
		{
			StreamWriter _sw;

			Dictionary<string, string> _DicTipoVeicoloRev;


			public SqlLoaderListaNeraA2Writer(string fileToProcess)
			{
				_sw = File.CreateText(fileToProcess);

				_DicTipoVeicoloRev = new Dictionary<string, string>();
				for (int k = 0; ; ++k)
				{
					string tp = ReadAppSettings.ToString("LTS_Import.TipoVeicolo.A2." + k.ToString(), "");
					if (tp.Length == 0)
						break;

					string[] a = tp.Split(':');

					_DicTipoVeicoloRev[a[1]] = a[0];
				}
			}

			public void Close()
			{
				if (_sw != null)
				{
					_sw.Close();
					_sw = null;
				}
			}

			public void Dispose()
			{
				Close();
			}


			public void Add(MWPDataLTS_A2 r)
			{
				_sw.Write(r.Targa);
				_sw.Write("|");
				_sw.Write(r.Nazionalita);
				_sw.Write("|");
				_sw.Write(r.DataRevisione.ToString(@"dd/MM/yyyy HH\:mm\:ss"));
				_sw.Write("|");


				if (!string.IsNullOrEmpty(r.TipoVeicolo) && _DicTipoVeicoloRev.ContainsKey(r.TipoVeicolo))
					_sw.Write(_DicTipoVeicoloRev[r.TipoVeicolo]);
				else
					_sw.Write("A");

				_sw.WriteLine();
			}
		}


		[Serializable]
		public class Nazione
		{
			private string sigla_nazione;
			private string nome_nazione;

			public string Sigla_Nazione { get { return sigla_nazione; } set { sigla_nazione = value; } }
			public string Nome_Nazione { get { return nome_nazione; } set { nome_nazione = value; } }
		}
		public List<Nazione> GetListaNazioni()
		{
			try
			{

				IDalLTSImport dal = DalProvider.DAL.CreateDalLTSImport();
				return dal.GetListaNazioni();
			}
			catch (Exception ex)
			{
				Log.Write(ex, "GetListaNazioni");
				throw;
			}
		}



		public static void ImportMassivoServerThread()
		{
			try
			{
				string userName = ReadAppSettings.ToString("ImportLTS.Servizio.Utente", "Admin");
				string RemotePath = ReadAppSettings.ToString("RemoteDir.AllineamentoTargheCEPS", "AllineamentoTargheCEPS");
				string FileNamePatternA1 = ReadAppSettings.ToString("ImportLTS.Servizio.FileNamePatternA1", @"^(?<a>\d{4})(?<m>\d{2})(?<g>\d{2})(?<h>\d{2})(?<n>\d{2})(?<s>\d{2})((\.txt)|(\.zip))$");
				string FileNamePatternA2 = ReadAppSettings.ToString("ImportLTS.Servizio.FileNamePatternA2", @"^Revisioni_scadute.(?<a>\d{4})(?<m>\d{2})(?<g>\d{2})((\.txt)|(\.zip))$");
				Regex rA1 = new Regex(FileNamePatternA1);
				Regex rA2 = new Regex(FileNamePatternA2);
				for (; ; )
				{
					// aspetto un minuto ... prima di fare ls lato Linux
					if (_evStop.WaitOne(60 * 1000, false)) return;

					try
					{
						// acquisisco un lock sul DB. In questo modo i 2 servizi non
						// possono agire in contemporanea.
						ImportMassivoServerTry_QueryLock(userName, RemotePath, rA1, rA2);
					}
					catch (Exception ex)
					{
						Log.Write(ex, "ImportMassivoServerThread");
					}
				}
			}
			catch (Exception ex)
			{
				Log.Write(ex, "ImportMassivoServerThread");
			}
		}
		private static void ImportMassivoServerTry_QueryLock(string userName, string RemotePath, Regex rA1, Regex rA2)
		{
			using (IDalLock serverLock = DalProvider.DAL.CreateDalLock("Import_A1"))
			{
				if (serverLock.IsLockAcquired)
				{
					// ok: sono solo al mondo... posso fare l'import.
					ImportMassivoServerTry_LockAcquired(userName, RemotePath, rA1, rA2);
				}
			}  // -> qui si rilascia il lock
		}

		internal class ImpFile : IComparable<ImpFile>
		{
			public ImpFile(string fn, DateTime ts, TipoLTS t)
			{
				this.fileName = fn;
				this.date = ts;
				this.tipo = t;
			}
			readonly public string fileName;
			readonly public DateTime date;
			readonly public TipoLTS tipo;

			// serve per fare il sort mettendo come primo file il piu` recente.
			public int CompareTo(ImpFile a)
			{
				return -1 * this.date.CompareTo(a.date);
			}
		};

		private static ImpFile GetFileDaElaborare(string RemotePath, Regex rA1, Regex rA2)
		{
			List<ImpFile> listaFile = new List<ImpFile>();

			string[] dir = U.PuTTYClient.Dir(null, RemotePath);
			foreach (string s in dir)
			{
				Match mA1 = rA1.Match(s);
				Match mA2 = rA2.Match(s);

				if (mA1.Success)
				{
					if (mA1.Groups["a"].Success && mA1.Groups["m"].Success && mA1.Groups["g"].Success &&
						mA1.Groups["h"].Success && mA1.Groups["n"].Success && mA1.Groups["s"].Success)
					{
						int anno = int.Parse(mA1.Groups["a"].Value);
						int mese = int.Parse(mA1.Groups["m"].Value);
						int giorno = int.Parse(mA1.Groups["g"].Value);

						int ora = int.Parse(mA1.Groups["h"].Value);
						int min = int.Parse(mA1.Groups["n"].Value);
						int sec = int.Parse(mA1.Groups["s"].Value);

						try
						{
							DateTime t = new DateTime(anno, mese, giorno, ora, min, sec);
							ImpFile f = new ImpFile(s, t, TipoLTS.A1);
							listaFile.Add(f);
						}
						catch
						{
							// se sono qui vuol dire che il file ha una convenzione errata
						}
					}
				}
				else if (mA2.Success)
				{
					if (mA2.Groups["a"].Success && mA2.Groups["m"].Success && mA2.Groups["g"].Success
						/* &&
						mA2.Groups["h"].Success && mA2.Groups["n"].Success && mA2.Groups["s"].Success */
																										)
					{
						int anno = int.Parse(mA2.Groups["a"].Value);
						int mese = int.Parse(mA2.Groups["m"].Value);
						int giorno = int.Parse(mA2.Groups["g"].Value);
						//int ora = int.Parse(mA2.Groups["h"].Value);
						//int min = int.Parse(mA2.Groups["n"].Value);
						//int sec = int.Parse(mA2.Groups["s"].Value);

						int ora = 0;
						int min = 0;
						int sec = 0;

						try
						{
							DateTime t = new DateTime(anno, mese, giorno, ora, min, sec);
							ImpFile f = new ImpFile(s, t, TipoLTS.A2);
							listaFile.Add(f);
						}
						catch
						{
							// se sono qui vuol dire che il file ha una convenzione errata
						}
					}
				}
			}

			if (listaFile.Count == 0)
				return null;

			listaFile.Sort();

			ImpFile fileDaElaborare = listaFile[0];

			IEnumerable<ImpFile> listaA1 = U.Filter<ImpFile>(listaFile, delegate(ImpFile a) { return a.tipo == TipoLTS.A1; });
			IEnumerable<ImpFile> listaA2 = U.Filter<ImpFile>(listaFile, delegate(ImpFile a) { return a.tipo == TipoLTS.A2; });

			// ho dei file da con il pattern corretto
			// elaboro il piu` recente e cancello gli altri.

			// cancello tutti i file piu` vecchi eccetto il piu` recente appartenenti allo stesso tipo
			bool first = true;
			foreach (ImpFile a1 in listaA1)
			{
				if (first)
				{
					first = false;
					continue;
				}

				try
				{
					string cmd = U.F("rm -f {0}/{1}", RemotePath, a1.fileName);
					U.PuTTYClient.ExecuteAndReturnExitCode(null, cmd);
				}
				catch
				{
					// se c'e` un errore pace!
				}
			}

			first = true;
			foreach (ImpFile a2 in listaA2)
			{
				if (first)
				{
					first = false;
					continue;
				}

				try
				{
					string cmd = U.F("rm -f {0}/{1}", RemotePath, a2.fileName);
					U.PuTTYClient.ExecuteAndReturnExitCode(null, cmd);
				}
				catch
				{
					// se c'e` un errore pace!
				}
			}

			return fileDaElaborare;
		}

		private static void ImportMassivoServerTry_LockAcquired(string userName, string RemotePath, Regex rA1, Regex rA2)
		{
			ImpFile fileDaElaborare = GetFileDaElaborare(RemotePath, rA1, rA2);
			if (fileDaElaborare == null)
				return;

			// controllo che il file NON sia ancora usato
			// provo per 60 volte aspettando tra un tentativo e l'altro 60 secondi
			// --> 1 ora in totale.
			bool possoElaborareIlFile = false;
			for (int t = 0; t < 60; t++)
			{
				string cmd = U.F("/usr/sbin/lsof {0}/{1}", RemotePath, fileDaElaborare.fileName);
				int ec = U.PuTTYClient.ExecuteAndReturnExitCode(null, cmd);
				if (ec == 0)
				{
					// file usato da un altro processo --> probabilmente e` ancora in scrittura
					if (_evStop.WaitOne(60 * 1000, false)) return;
				}
				else if (ec == 1)
				{
					// se ec == 1 significa che il file non esiste o che e` pronto per essere consumato
					possoElaborareIlFile = true;
					break;
				}
				else
				{
					LogWrite(userName, U.F("Import LTS server: Return code non previsto : {0}", ec));
					break;
				}
			}
			if (possoElaborareIlFile == false)
			{
				LogWrite(userName, U.F("Import LTS server: Il file {0} e` bloccato - impossibile elaborarlo", fileDaElaborare.fileName));
				return;
			}


			bool importEffettuato = false;
			for (int t = 0; t < 3; ++t)
			{
				if (t == 0)
					LogWrite(userName, U.F("Import LTS server: inizio procedura di import"));
				else
					LogWrite(userName, U.F("Import LTS server: procedura di import - {0}' tentativo", t));

				try
				{
					int minTimeoutImport = ReadAppSettings.ToInt32("ImportLTS.MaxMinutiTimeout", 60);
					if (minTimeoutImport > 0)
					{
						string args = U.F("{0} {1} {2}", userName, fileDaElaborare.fileName, fileDaElaborare.tipo.ToString());
						string exe = ReadAppSettings.ToString("ImportLTS.ProcessoImport", "$$\\ITRS_Import\\ITRS_Import.exe");

						using (U.RunProcess rp = new U.RunProcess(exe, args))
						{
							rp.Start();

							int exitCode;
							bool b = rp.WaitTimeout(1000 * 60 * minTimeoutImport, out exitCode);
							if (!(b && exitCode == 0))
								throw new Exception();
						}
					}
					else
					{
						ImportMassivoWorker_LockAcquired(userName, fileDaElaborare.fileName, fileDaElaborare.tipo, true);
					}


					string cmd = U.F("rm -f {0}/{1}", RemotePath, fileDaElaborare.fileName);
					U.PuTTYClient.Execute(null, cmd);

					importEffettuato = true;
				}
				catch (Exception ex)
				{
					LogWrite(ex, userName, "Import");
				}

				if (importEffettuato)
					break;

				if (_evStop.WaitOne(5 * 60 * 1000, false)) return;
			}

			if (importEffettuato)
				LogWrite(userName, "Import LTS server: procedura terminata");
			else
				LogWrite(userName, "Import LTS server: non e` stato possibile elaborare il file {0}", fileDaElaborare);
		}



		[Serializable]
		public class AttivazioneA2
		{
			public Int16 IdC2P { get { return _IdC2P; } set { _IdC2P = value; } }
			public String Descrizione { get { return _Descrizione; } set { _Descrizione = value; } }
			public DateTime? DataOraInizioAttivazione { get { return _DataOraInizioAttivazione; } set { _DataOraInizioAttivazione = value; } }
			public DateTime? DataOraFineAttivazione { get { return _DataOraFineAttivazione; } set { _DataOraFineAttivazione = value; } }
			public Int32? GiorniTolleranzaRevisione { get { return _GiorniTolleranzaRevisione; } set { _GiorniTolleranzaRevisione = value; } }
			public String TipoVeicolo { get { return _TipoVeicolo; } set { _TipoVeicolo = value; } }
			public String CorsieAbilitate { get { return _CorsieAbilitate; } set { _CorsieAbilitate = value; } }

			#region dati
			protected Int16 _IdC2P;
			protected String _Descrizione;
			protected DateTime? _DataOraInizioAttivazione;
			protected DateTime? _DataOraFineAttivazione;
			protected Int32? _GiorniTolleranzaRevisione;
			protected String _TipoVeicolo;
			protected String _CorsieAbilitate;
			#endregion
		}
	}
}
