CREATE FUNCTION ITRS.ArrotondaData(d in Date, r in number)
RETURN number
AS
    hh number;
    mi number;
BEGIN
    hh := to_number(to_char(d, 'HH24'));
    mi := to_number(to_char(d, 'MI'));

    return trunc(((hh * 60) + mi) / r) * r;
END;
GO
