CREATE OR REPLACE PACKAGE BODY "ITRS"."ITRS_CENTR_COMM"                       IS
/*******************************************************************************
* Module    : ITRS_CENTR_COMM_PKG
* Description :
********************************************************************************
*                         Revision history
*
*  Date      Who       Description
*  --------  -------   ------------------------------------------------
*  10/01/06  P.Lercari first release
*  03/03/06  De Julis  Aggiunta Procedura per ricavare i dati per la spedizione delle email
*  14/03/06  De Julis  Modifica Procedura DatiEmail - Aggiunti nuovi campi da restituire
*  15/03/06  De Julis  Modifica Procedura InsertAllarmi - Aggiunta inizializzazione variabile V_SEQ_IM_CUR
*  15/03/06  De Julis  Modifica Procedura DatiEmail - Corretta decode relativa alla variabile VARCODESC
*  04/09/06  P.Lercari In InsertAllarmi tolta eccezione dup_val_on_index su tabella TransitiSuEvento
*  02/11/06  De Julis  Aggiunti parametri di input e insert su tabelle TransitiSuEvento e Transiti
*  07/11/06  Stefani   Copiati da LTS a SEGNALAZIONI tutti i campi nuovi TAB_*
*  16/01/07  Stefani   Modifica per gestire gli allarmi con V_NAZ = '?'
***********************************************************************************/

Procedure InsertAllarmi(
	V_TARGA IN varchar2,         V_NAZ IN varchar2,        V_QMGR_NAME IN varchar2,       D_DATAORARILEV IN date,
	V_ENUMTIPOVARCO IN varchar2, N_CONFACQTARGA IN number, V_FORMATO IN varchar2,         V_CODIFICA IN varchar2,
	V_RISOLUZIONE IN varchar2,   V_IMMAGINE IN varchar2,   V_XSTART IN number,            V_YSTART IN number,
	V_XEND IN number,            V_YEND IN number,         V_NETID IN varchar2,           V_LAYOUTID IN varchar2,
	V_VEHICLETYPE IN varchar2,   V_VEHICLEID IN varchar2,  V_CLASSE_URGENZA OUT varchar2, V_SEQ_IM_CUR OUT varchar2,
	ERRCODE OUT integer,         ERRMSG OUT varchar2,      RETVAL OUT integer
) is

Current_Point integer;
n_idcoa c2p.idcoa%type;
n_idc2p c2p.idc2p%type;
d_dataorains date;
diff_date number(10);
n_classe_urg_att parametri.parvalue%type;
n_classe_urg_rit parametri.parvalue%type;
v_classe_urg eventidasegnalare.enumclasseurgenza%type;
ev_id eventidasegnalare.idevento%type;
imm_id Immaginisuevento.idimmagine%type;

begin
	RETVAL:= 0;
	Current_Point := -1;
	ERRMSG := 'KO';
	V_CLASSE_URGENZA := 'KO';
	V_SEQ_IM_CUR:= '-1';

	select IdC2p,IdCOA
	into n_idc2p,n_idcoa
	from C2P
	where QMgr_Name = V_QMGR_NAME;

	Current_Point := -2;
	d_dataorains := sysdate;
	diff_date := (d_dataorains - D_DATAORARILEV)*1440;

	select PARVALUE
	into n_classe_urg_att
	from Parametri
	where partipo = 'TEMPO_ATT';

	Current_Point := -3;

	select PARVALUE
	into n_classe_urg_rit
	from Parametri
	where partipo = 'TEMPO_RIT';

	Current_Point := -4;

	v_classe_urg := itrs_const_pkg.VAL_CLASSEURGENZA_ATT;

	if (diff_date >=0 and diff_date <= n_classe_urg_att) then
		v_classe_urg := itrs_const_pkg.VAL_CLASSEURGENZA_ATT;
	elsif (diff_date >n_classe_urg_att and diff_date <= n_classe_urg_rit) then
		v_classe_urg := itrs_const_pkg.VAL_CLASSEURGENZA_RIT;
	elsif (diff_date >n_classe_urg_rit) then
		v_classe_urg := itrs_const_pkg.VAL_CLASSEURGENZA_OBS;
	end if;

	INSERT INTO EVENTIDASEGNALARE
	(
		TARGA, NAZIONALITA, DATAORAINSERIMENTO, IDEVENTO, ENUMTIPOEVENTO, ENUMSTATOALLARME, IDCOACOMPETENZA, ENUMCLASSEURGENZA
	) values (
		V_TARGA, nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT),
		d_dataorains, SEQ_EV.nextval, itrs_const_pkg.VAL_TIPOEVENTO_TS, 
		itrs_const_pkg.VAL_STATOALLARME_ACQ, n_idcoa, v_classe_urg
	);

	Current_Point := -5;

	select SEQ_EV.currval into ev_id from dual;

	Current_Point := -6;

	INSERT INTO TRANSITISUEVENTO
	(
		TARGA, NAZIONALITA, DATAORARILEVAMENTO, IDC2P, ENUMTIPOVARCO,
		DATAORAINSERIMENTO, ENUMSTATOTRANSITO, TARGAACQUISITA, NAZIONALITAACQUISITA, CONFIDENZAACQUISIZIONETARGA,
		PL_XSTART, PL_YSTART, PL_XEND, PL_YEND, PL_NET_ID,
		PL_LAYOUT_ID, PL_VEHICLE_TYPE, PL_VEHICLE_ID
	) values (
		V_TARGA, nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT),
		D_DATAORARILEV, n_idc2p,
		decode(LTRIM(V_ENUMTIPOVARCO,'0'),
			itrs_const_pkg.VAL_TIPOVARCO_1, itrs_const_pkg.VAL_TIPOVARCO_SX,
			itrs_const_pkg.VAL_TIPOVARCO_2, itrs_const_pkg.VAL_TIPOVARCO_DX,
			itrs_const_pkg.VAL_TIPOVARCO_3, itrs_const_pkg.VAL_TIPOVARCO_INGRESSO,
			itrs_const_pkg.VAL_TIPOVARCO_4, itrs_const_pkg.VAL_TIPOVARCO_USCITA,
			null),
		d_dataorains,   itrs_const_pkg.VAL_STATOTRANSITO_ACQ, V_TARGA,
		nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT),
		N_CONFACQTARGA, V_XSTART,V_YSTART,
		V_XEND, V_YEND, V_NETID, V_LAYOUTID,
		V_VEHICLETYPE,  V_VEHICLEID
	);


	Current_Point := -7;

	begin

		INSERT INTO IMMAGINISUEVENTO
		(
			TARGA, NAZIONALITA, DATAORARILEVAMENTO, IDIMMAGINE, IMMAGINE, FORMATO, CODIFICA, RISOLUZIONE
		) values (
			V_TARGA, 
			nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT), 
			D_DATAORARILEV, SEQ_IM.nextval, empty_blob(), V_FORMATO, V_CODIFICA, V_RISOLUZIONE
		);

	exception when dup_val_on_index then
		null;
	end;

	select SEQ_IM.currval into imm_id from dual;
	V_SEQ_IM_CUR:=TO_CHAR(imm_id);

	Current_Point := -8;

	INSERT INTO TRANSITIEVENTI
	(
		TARGA, NAZIONALITA, DATAORAINSERIMENTO, DATAORARILEVAMENTO, IDEVENTO
	) values (
		V_TARGA, nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT), d_dataorains, D_DATAORARILEV,ev_id
	);

	Current_Point := -9;


	-- Stefani 16/1/2007
	-- inserisco nella tabelle segnalazioni i dati provevienti dalla LTS relativi alla targa in allarme
	-- Se in V_NAZ c'e` '?' ricerco in LTS utilizzando solo la targa e memorizzo in Segnalazioni la nazionalita '?'.
	-- In questo modo quando arriva un nazionalita` sconosciuta il DB e` consistente:
	-- in EventiDaSegnalare, TransitiEventi, TransitiSuEvento, ImmaginiSuEvento il transito e` memorizzato con
	-- nazionalita` '?'. Ora anche in Segnalazioni ho la nazionalita` '?'.
	INSERT INTO SEGNALAZIONI
	(
		TARGA,                   
		NAZIONALITA,           
		DATAORAINSERIMENTO,  
		IDEVENTO,
		PROGRESSIVOSEGNALAZIONE, 
		ENUMTIPOLTS,
		IDUTENTERICHIEDENTE,
		MOTIVO,
		NOTE,
		DATAORAINIZIOVALIDITA,
		DATAORAFINEVALIDITA,
		ENUMTIPODEST,
		ADDRDEST,
		ENUMLIVELLOPRIORITA,

		TAB_TELAIO,
		TAB_DATA_FURTO,
		TAB_FABBRICA,
		TAB_MODELLO,
		TAB_TIPO_VEICOLO,
		TAB_TIPO_DENUNCIA,
		TAB_CODICE_UFFICIO,
		TAB_UFFICIO
	)
	select 
	TARGA,            
	-- NAZIONALITA, -- Stefani 16/1/2007
	nvl(V_NAZ, itrs_const_pkg.VAL_NAZ_DEFAULT) nazionalita, -- Stefani 16/1/2007
	d_dataorains,        
	ev_id,
	SEQ_SEGN.nextval, 
	ENUMTIPOLTS,           
	IDUTENTERICHIEDENTE, 
	MOTIVO,
	NOTE,
	DATAORAINIZIOVALIDITA,
	DATAORAFINEVALIDITA,
	ENUMTIPODEST,
	ADDRDEST,
	ENUMLIVELLOPRIORITA,

	TAB_TELAIO,
	TAB_DATA_FURTO,
	TAB_FABBRICA,
	TAB_MODELLO,
	TAB_TIPO_VEICOLO,
	TAB_TIPO_DENUNCIA,
	TAB_CODICE_UFFICIO,
	TAB_UFFICIO

	from LTS
	where 
	targa = V_TARGA
	-- and nazionalita = nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT); -- Stefani 16/1/2007
	and (V_NAZ = '?' or nazionalita = nvl(V_NAZ, itrs_const_pkg.VAL_NAZ_DEFAULT)); -- Stefani 16/1/2007

	Current_Point := -10;

	V_CLASSE_URGENZA := v_classe_urg;

	Current_Point := -11;

	begin

		INSERT INTO TRANSITI(
			TARGA,                       NAZIONALITA,     DATAORARILEVAMENTO,
			IDC2P,                       ENUMTIPOVARCO,   DATAORAINSERIMENTO,
			ENUMSTATOTRANSITO,           TARGAACQUISITA,  NAZIONALITAACQUISITA,
			CONFIDENZAACQUISIZIONETARGA, PL_XSTART,       PL_YSTART,
			PL_XEND,                     PL_YEND,         PL_NET_ID,
			PL_LAYOUT_ID,                PL_VEHICLE_TYPE, PL_VEHICLE_ID
		) values (
			V_TARGA, nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT), D_DATAORARILEV, n_idc2p,
			decode(LTRIM(V_ENUMTIPOVARCO,'0'),
			itrs_const_pkg.VAL_TIPOVARCO_1,itrs_const_pkg.VAL_TIPOVARCO_SX,
			itrs_const_pkg.VAL_TIPOVARCO_2,itrs_const_pkg.VAL_TIPOVARCO_DX,
			itrs_const_pkg.VAL_TIPOVARCO_3,itrs_const_pkg.VAL_TIPOVARCO_INGRESSO,
			itrs_const_pkg.VAL_TIPOVARCO_4,itrs_const_pkg.VAL_TIPOVARCO_USCITA,
			null),
			d_dataorains,   itrs_const_pkg.VAL_STATOTRANSITO_ACQ, V_TARGA,    nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT),
			N_CONFACQTARGA, V_XSTART,                             V_YSTART,   V_XEND,
			V_YEND,         V_NETID,                              V_LAYOUTID, V_VEHICLETYPE,
			V_VEHICLEID);

	exception when dup_val_on_index then
		null;
	end;


	Current_Point := -12;

	begin

		INSERT INTO IMMAGINI(
			TARGA,    NAZIONALITA, DATAORARILEVAMENTO, IDIMMAGINE,
			MMAGINE, FORMATO,     CODIFICA,           RISOLUZIONE
		) values (
			V_TARGA,      nvl(V_NAZ,itrs_const_pkg.VAL_NAZ_DEFAULT), D_DATAORARILEV, imm_id,
			empty_blob(), V_FORMATO,                                 V_CODIFICA,     V_RISOLUZIONE);

	exception when dup_val_on_index then
		null;
	end;

	-- ERRCODE :=20/0;
	-- commit;

	ERRCODE := 0;
	ERRMSG := 'OK';
	RETVAL:= 0;

	commit;

Exception when Others then
	ERRCODE  := SQLCODE;
	ERRMSG := 'Errore durante esecuzione InsertAllarmi: ' || substr(sqlerrm,1,250);
	RETVAL:= Current_Point;
end InsertAllarmi;




procedure DatiEmail
(
	V_ID_VARCO IN varchar2, V_ID_UTENTE IN varchar2, V_ID_C2P IN varchar2,   VARCO OUT varchar2,
	UTENTE OUT varchar2,    DIREZIONE OUT varchar2,  VARCODESC OUT varchar2, CODICESTRADA OUT varchar2,
	KM OUT varchar2,        ERRCODE OUT integer,     ERRMSG OUT varchar2,    RETVAL OUT integer
) is

Current_Point integer;
begin
	RETVAL:= 0;
	Current_Point := -1;
	ERRMSG := 'KO';
	UTENTE :='N.P.';
	VARCO :='N.P.';
	DIREZIONE :='N.P.';
	VARCODESC :='N.P.';
	CODICESTRADA :='N.P.';
	KM :='N.P.';

	select USERNAME into UTENTE from ASPNET_USERS where PKID=V_ID_UTENTE;

	Current_Point := -2;

	select
	decode(LTRIM(V_ID_VARCO,'0'),
	itrs_const_pkg.VAL_TIPOVARCO_1, itrs_const_pkg.VAL_TIPOVARCO_SX,
	itrs_const_pkg.VAL_TIPOVARCO_2,itrs_const_pkg.VAL_TIPOVARCO_DX,
	itrs_const_pkg.VAL_TIPOVARCO_3,itrs_const_pkg.VAL_TIPOVARCO_INGRESSO,
	itrs_const_pkg.VAL_TIPOVARCO_4,itrs_const_pkg.VAL_TIPOVARCO_USCITA,'N.P.')
	into VARCO from dual;

	Current_Point := -3;

	select DIREZIONE,CODICESTRADA,KM into DIREZIONE,CODICESTRADA,KM from C2P where IDC2P=TO_NUMBER(V_ID_C2P);

	Current_Point := -4;

	select 
	decode(LTRIM(V_ID_VARCO,'0'),
		itrs_const_pkg.VAL_TIPOVARCO_1, itrs_const_pkg.VAL_DESCVARCO_1,
		itrs_const_pkg.VAL_TIPOVARCO_2,itrs_const_pkg.VAL_DESCVARCO_2,
		itrs_const_pkg.VAL_TIPOVARCO_3,itrs_const_pkg.VAL_DESCVARCO_3,
		itrs_const_pkg.VAL_TIPOVARCO_4,itrs_const_pkg.VAL_DESCVARCO_4,'N.P.')
	into VARCODESC from dual;


	ERRCODE := 0;
	ERRMSG := 'OK';
	RETVAL:= 0;

Exception when Others then
	ERRCODE  := SQLCODE;
	ERRMSG := 'Errore durante esecuzione DatiEmail: ' || substr(sqlerrm,1,250);
	RETVAL:= Current_Point;
end DatiEmail;

end ITRS_CENTR_COMM;
