using System;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using GME;

namespace GMETestWA
{
	/// <summary>
	/// Summary description for WebPageForm.
	/// </summary>
	public class WebPageForm : Page
	{
		protected Button Button1;
		protected Label Label1;
		protected DropDownList DropDownList1;
		protected RadioButtonList RadioButtonList1;
		protected TextBox TextBox1;
		protected Label Label2;
		protected RequiredFieldValidator RequiredFieldValidator1;
		protected RangeValidator RangeValidator1;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Button Button2;
		protected ListBox ListBox1;

		private void Page_Load(object sender, EventArgs e)
		{
			string lang = RadioButtonList1.SelectedValue;
			WebBase.LocalizationCulture = new CultureInfo(lang);

			if (!IsPostBack)
			{
			}
		}

		#region Web Form Designer generated code

		protected override void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.RadioButtonList1.SelectedIndexChanged += new System.EventHandler(this.RadioButtonList1_SelectedIndexChanged);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}

		#endregion

		private void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
		{
			string lang = this.RadioButtonList1.SelectedValue;
			WebBase.LocalizationCulture = new CultureInfo(lang);
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			string lang = RadioButtonList1.SelectedValue;
			WebBase.LocalizationCulture = new CultureInfo(lang);
			Label3.Text = WebBase.GetSentence("englishSentence");
		}
		protected override void OnPreRender(EventArgs evt)
		{
			base.OnPreRender(evt);
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			WebBase.LocalizationCulture = WebBase.UserLocalizationCulture;
			Label3.Text = WebBase.GetSentence("englishSentence");
		}
	}
}