using System;
using System.Globalization;
using System.Web.UI.WebControls;
using GME;

namespace GMETestWA
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : WebBase
	{
		protected Button Button1;
		protected Label Label1;
		protected DropDownList DropDownList1;
		protected RadioButtonList RadioButtonList1;
		protected TextBox TextBox1;
		protected Label Label2;
		protected RequiredFieldValidator RequiredFieldValidator1;
		protected RangeValidator RangeValidator1;
		protected ListBox ListBox1;

		private void Page_Load(object sender, EventArgs e)
		{
			CultureInfo ci = new CultureInfo("it-it");
			LocalizationCulture = ci;

			AccessProvider["A"] = true;
			if (!IsPostBack)
			{
			}
		}

		#region Web Form Designer generated code

		protected override void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.RadioButtonList1.SelectedIndexChanged += new EventHandler(this.RadioButtonList1_SelectedIndexChanged);
			this.Load += new EventHandler(this.Page_Load);

		}

		#endregion

		private void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
		{
			string lang = this.RadioButtonList1.SelectedValue;
			LocalizationCulture = new CultureInfo(lang);
		}

	}
}