using System;
using System.Data;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using GME;

namespace GMETestWA
{
	/// <summary>
	/// Summary description for WebBaseForm.
	/// </summary>
	public class WebBaseForm : WebBase
	{
		protected Button Button1;
		protected Label Label1;
		protected DropDownList DropDownList1;
		protected RadioButtonList RadioButtonList1;
		protected TextBox TextBox1;
		protected Label Label2;
		protected RequiredFieldValidator RequiredFieldValidator1;
		protected RangeValidator RangeValidator1;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.CheckBox CheckBox1;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
		protected System.Web.UI.WebControls.Literal Literal1;
		protected GMEControlLibraryCS.PopupCalendar PopupCalendar1;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.HtmlControls.HtmlInputButton Button2;
		protected System.Web.UI.HtmlControls.HtmlGenericControl Label4;
		protected System.Web.UI.HtmlControls.HtmlSelect Select2;
		protected ListBox ListBox1;

		private void Page_Load(object sender, EventArgs e)
		{
			if (this.CheckBox1.Checked)
			{
				LocalizationCulture = UserLocalizationCulture;
			}
			else
			{
				string lang = this.RadioButtonList1.SelectedValue;
				LocalizationCulture = new CultureInfo(lang);
			}
			string s = LocalizationDictionary.GetSentence(string.Empty, string.Empty);

			AccessProvider["A"] = true;
			if (!IsPostBack)
			{
				Session["NewDataSet"] = NewDataSet();
			}
			DataGrid1.DataSource = Session["NewDataSet"];
			DataGrid1.DataBind();
		}

		#region Web Form Designer generated code

		protected override void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.RadioButtonList1.SelectedIndexChanged += new System.EventHandler(this.RadioButtonList1_SelectedIndexChanged);
			this.LinkButton1.Click += new System.EventHandler(this.LinkButton1_Click);
			this.DataGrid1.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid1_CancelCommand);
			this.DataGrid1.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid1_EditCommand);
			this.DataGrid1.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid1_UpdateCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}

		#endregion

		private void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Label3.Text = GetSentence("italianSentence");
		}

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
		}

		private DataSet NewDataSet()
		{
			DataSet ds = new DataSet();

			DataTable dt = new DataTable();

			DataColumn dc = new DataColumn("Id", typeof (int));
			dt.Columns.Add(dc);

			dt.PrimaryKey = new DataColumn[] {dc};

			dc = new DataColumn("dbNome", typeof (string));
			dt.Columns.Add(dc);

			dc = new DataColumn("dbCognome", typeof (string));
			dt.Columns.Add(dc);

			dc = new DataColumn("dbNato", typeof (DateTime));
			dt.Columns.Add(dc);

			dt.Rows.Add(new object[] {1, "Gianni" , "Marchi", DateTime.Today.AddYears(-30)});
			dt.Rows.Add(new object[] {2, "Fabrizio" , "Mannari", DateTime.Today.AddYears(-50)});
			dt.Rows.Add(new object[] {3, "Alessandro" , "Mei", DateTime.Today.AddYears(-40)});

			ds.Tables.Add(dt);

			return ds;
		}

		private void DataGrid1_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			string s = e.CommandName;
			DataGridItem i = e.Item;
			TextBox2.Text = i.Cells[2].Text;
		}
		protected override void LocalizeControl(Control c, XmlElement element)
		{
			try
			{
				if (c == Label4 && element.Name == "Text")
				{
					Label4.InnerText = element.InnerText;
				}
			}
			catch {}
		}

		private void DataGrid1_CancelCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			string s = e.CommandName;
			DataGridItem i = e.Item;
			TextBox2.Text = i.Cells[2].Text;
		
		}

		private void DataGrid1_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			string s = e.CommandName;
			DataGridItem i = e.Item;
			TextBox2.Text = i.Cells[2].Text;
			DataSet ds = Session["NewDataSet"] as DataSet;
			DataRow dr = ds.Tables[0].Rows[i.DataSetIndex];
			dr.BeginEdit();
			dr[1] = ListBox1.SelectedItem.Text;
			dr.EndEdit();
			ds.AcceptChanges();
			DataGrid1.DataSource = ds;
			DataGrid1.DataBind();
		}

		private void DataGrid1_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			string s = e.CommandName;
			DataGridItem i = e.Item;
			TextBox2.Text = i.Cells[2].Text;
		}
	}
}