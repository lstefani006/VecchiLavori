using System;
using System.Collections;
using System.Xml;
using System.IO;
using System.Text;

namespace DeployXml
{
	class _
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				ArrayList xop = new ArrayList();

				string dir = null;
				for (int i = 0; i < args.Length; ++i)
				{
					switch (args[i])
					{
						case "-x":
							xop.Add(args[++i].ToLower());
							break;
						case "-d":
							dir = args[++i];
							break;
						default:
							if (args.Length == i + 2)
							{
								if (dir == null)
								{
									Console.Error.WriteLine("use: -d option is mandatory");
									Environment.Exit(-1);
								}
								ElaboraFile(xop, dir, args[i], args[i+1]);
								Environment.Exit(0);
							}
							else
							{
								Console.Error.WriteLine("use: [-x .<file ext>] -d dir fileIn fileOut");
								Environment.Exit(-1);
							}
							break;
					}
				}
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine("Errore: {0}", ex.Message);
				Environment.Exit(-1);
			}
		}

		static void Use(string msg)
		{
			if (msg != null)
				Console.Error.WriteLine(msg);
			Console.Error.WriteLine("use: [-x .<file ext>] -d <dir> <fileIn> <fileOut>");
			Console.Error.WriteLine("-x : exclude file extension ex. -x .bat");
			Console.Error.WriteLine("-d : directory to be included in fileIn");
			Console.Error.WriteLine("<fileIn> : xml config file to read from");
			Console.Error.WriteLine("<fileOut> : xml config file to write to");
		}

		static void ElaboraFile(ArrayList xop, string dir, string fin, string configFileOut)
		{
			if (File.Exists(configFileOut))
				File.Delete(configFileOut);


			XmlDocument x = new XmlDocument();
			x.Load(fin);
			XmlNode d = x.DocumentElement.SelectSingleNode("./appSettings");
			if (d == null)
			{
				d = x.CreateElement("appSettings");
				x.DocumentElement.AppendChild(d);
			}

			int n = 0;
			for (;;)
			{
				XmlNode nn = d.SelectSingleNode(string.Format("Engine.Deploy_{0}", n++));			
				if (nn == null)
					break;

				d.RemoveChild(nn);
			}

			n = 0;

			string dirOut = Path.GetDirectoryName(configFileOut);

			ElaboraDirectory(dir, xop, x, d, ref n, dirOut, "");


			x.Save(configFileOut);
		}

		private static void ElaboraDirectory(string dirIn, ArrayList xop, XmlDocument doc, XmlNode node, ref int n, string dirOut, string relativeDir)
		{
			// file nella directory .
			if (true)
			{
				string [] df = Directory.GetFiles(dirIn);
				foreach (string fileDirIn in df)
				{
					string fn = Path.GetFileName(fileDirIn);
					string ext = Path.GetExtension(fileDirIn);

					if (xop.Contains(ext.ToLower()))
						continue;

					XmlElement xf = doc.CreateElement("add");
					node.AppendChild(xf);

					XmlAttribute a = doc.CreateAttribute("key");
					a.Value = string.Format("Engine.Deploy_{0}", n++);
					xf.Attributes.Append(a);

					a = doc.CreateAttribute("value");
					a.Value = relativeDir + fn;
					xf.Attributes.Append(a);

					if (!Directory.Exists(dirOut))
						Directory.CreateDirectory(dirOut);

					string fileDirOut = Path.Combine(dirOut, fn);

					File.Copy(fileDirIn, fileDirOut , true);
				}
			}

			if (true)
			{
				string [] subDirList = Directory.GetDirectories(dirIn);
				foreach (string subDirIn in subDirList)
				{
					string sd = Path.GetFileName(subDirIn);
					string subDirOut = Path.Combine(dirOut, sd);
					ElaboraDirectory(subDirIn, xop, doc, node, ref n, subDirOut, relativeDir + sd + @"\");
				}
			}
		}
	}
}
