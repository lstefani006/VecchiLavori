using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.ComponentModel;

namespace GMEControlLibraryCS
{
	/// <summary>
	/// Summary description for PopupCalendar.
	/// </summary>
	[DefaultProperty("Text"),
		ToolboxData("<{0}:PopupCalendar runat=server></{0}:PopupCalendar>")]
	public class PopupCalendar : System.Web.UI.WebControls.WebControl
	{
		private string _IdText;

		[Bindable(true),
			Category("Settings"),
			DefaultValue("")]
		public string IDText
		{
			get
			{
				return _IdText;
			}

			set
			{
				_IdText = value;
			}
		}

		private string _IdAnchor;

		[Bindable(true),
		Category("Settings"),
		DefaultValue("")]
		public string IDAnchor
		{
			get
			{
				return _IdAnchor;
			}

			set
			{
				_IdAnchor = value;
			}
		}

		private bool _bUseDiv;

		[Bindable(true),
		Category("Settings"),
		DefaultValue("False")]
		public bool UseDIV
		{
			get
			{
				return _bUseDiv;
			}

			set
			{
				_bUseDiv = value;
			}
		}

		private string _pathCalendar;

		[Bindable(true),
		Category("Settings"),
		DefaultValue("")]
		public string PathPopupCalendar
		{
			get
			{
				return _pathCalendar;
			}

			set
			{
				_pathCalendar = value;
			}
		}

		protected override void OnPreRender(System.EventArgs e)
		{
			if(!this.Page.IsClientScriptBlockRegistered("PopupCalendar_scripts"))
			{
				string nl = Environment.NewLine;
				
				string s = null;
			
				if(_pathCalendar==null)
					s += "<SCRIPT language=\"JavaScript\" src=\"PopupCalendar/PopupCalendar.js\"></SCRIPT>" + nl;
				else
					s += "<SCRIPT language=\"JavaScript\" src=\"" + _pathCalendar + "/PopupCalendar.js\"></SCRIPT>" + nl;
			
				s += "<SCRIPT language=\"javascript\" >" + nl;
				
				if(_bUseDiv)
					s += "var cal = new CalendarPopup('PopupCalendar_Div');" + nl;
				else
					s += "var cal = new CalendarPopup();" + nl;
			
				if(CultureInfo.CurrentCulture.Name.ToUpper() == "IT-IT")
				{
					s += "cal.setWeekStartDay(1); // week is Monday - Saturday" + nl;
					s += "cal.setMonthNames(\"Gennaio\", \"Febbraio\", \"Marzo\", \"Aprile\", \"Maggio\", \"Giugno\", \"Luglio\", \"Agosto\", \"Settembre\", \"Ottobre\", \"Novembre\", \"Dicembre\");" + nl;
					s += "cal.setDayHeaders(\"D\",\"L\",\"M\", \"m\", \"G\", \"V\", \"S\");" + nl;
					s += "cal.setTodayText(\"Oggi\");" + nl;
				}

				s += "cal.showNavigationDropdowns();" + nl;
				s += "cal.setCssPrefix('PopupCalendar');" + nl;
				s += "</SCRIPT>";

				Page.RegisterClientScriptBlock("PopupCalendar_scripts", s);
			}

		}

		/// <summary>
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter w)
		{
			if(_IdText== string.Empty)
			{
				w.WriteLine("Insert ID Text");
				return;
			}
			w.AddAttribute("HREF", "#");
			w.AddAttribute("NAME", this.ClientID);
			w.AddAttribute("ID", this.ClientID);

			// testo da cui prendere/settare la data nel calendario (vuole il puntatore al testo)
			string e = string.Format("document.getElementById('{0}')", _IdText);
			// controllo a cui ancorarsi (vuole una stringa)
			string a = _IdText;
			if( (_IdAnchor != null) && (_IdAnchor != string.Empty))
				a = _IdAnchor;

			string s = null;
			s = String.Format("cal.select({0}, '{1}', '{2}'); return false;", e, a, CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern);
			//if(CultureInfo.CurrentCulture.Name.ToUpper() == "IT-IT")
			//	s = String.Format("cal.select({0}, '{1}', 'd/M/y'); return false;", e, a);
			//else
			//	s = String.Format("cal.select({0}, '{1}', 'M/d/y'); return false;", e, a);
		
			w.AddAttribute("onClick", s);

			this.AddAttributesToRender(w);

			w.RenderBeginTag("A");
			
			if (_pathCalendar == null) 
				w.AddAttribute("src", "PopupCalendar/PopupCalendar.gif");
			else
				w.AddAttribute("src", this._pathCalendar + "/PopupCalendar.gif");
			
			w.AddAttribute("border", "0");
			w.RenderBeginTag("IMG");
			w.RenderEndTag();
			w.RenderEndTag();
		}
	}
}
