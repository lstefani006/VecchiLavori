using System;
using System.ComponentModel;
using System.Web.UI;
using System.Data;
using System.Globalization;

namespace GMEControlLibraryCS
{

	[DefaultProperty("Text"), ToolboxData("<{0}:ClientHelp runat=server></{0}:ClientHelp>")]
	public class ClientHelp: System.Web.UI.WebControls.WebControl 
	{
		string _alertText;
		string _confirmText;
		string _eventTarget;
		string _eventArgument;
		//string _titleText;
		string _userInfo;
		bool _mustSave = false;
		DataSet _dataSource = new DataSet();

		public ClientHelp()
		{
			base.Load += new EventHandler(ClientHelp_Load) ;
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public string AlertText
		{
			get
			{
				if (_alertText == null) return String.Empty ;
				return _alertText;
			}

			set
			{
				_alertText = value;
			}
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public string ConfirmText
		{
			get
			{
				if (_confirmText == null) return String.Empty ;
				return _confirmText;
			}

			set
			{
				_confirmText = value;
			}
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public string EventTarget
		{
			get
			{
				if (_eventTarget == null) return String.Empty ;
				return _eventTarget;
			}

			set
			{
				_eventTarget = value;
			}
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public string EventArgument
		{
			get
			{
				if (_eventArgument == null) return String.Empty ;
				return _eventArgument;
			}

			set
			{
				_eventArgument = value;
			}
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public string TitleText
		{
			get
			{
				object o = ViewState["CH_TitleText"] ;
				if (o == null) return String.Empty ;
				return (string)o;
			}

			set
			{
				ViewState["CH_TitleText"] = value;
			}
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public DataSet DataSource
		{
			get
			{
				return _dataSource;
			}

			set
			{
				_dataSource = value;
			}
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public bool MustSave
		{
			get
			{
				if ((_dataSource == null) && (_dataSource.HasChanges())) return true ;
				return _mustSave;
			}

			set
			{
				_mustSave = value;
			}
		}

		[Bindable(true), Category("Appearance"), DefaultValue("")]
		public string MustSaveMessage
		{
			get
			{
				if (ViewState["CH_mustSaveMessage"] != null) return (string)ViewState["CH_mustSaveMessage"];
			
				string msg ;
				if (CultureInfo.CurrentCulture.Name.ToUpper() == "IT-IT")
					msg = "Alcune modifiche non sono state salvate: sei sicuro di voler cambiare pagina ?" ;
				else
					msg = "Some changes are not saved: do you really want to leave this page ?" ;
			
				return msg;
			}

			set
			{
				ViewState["CH_mustSaveMessage"] = value;
			}
		}

		protected override void OnPreRender(System.EventArgs e)
		{
			base.OnPreRender(e);

			string nl = Environment.NewLine ;

			if (!(Page.IsStartupScriptRegistered("ClientHelp_StartupScript")))
			{
				if (Page.Session["IdUtente"] != null)
				{
					DateTime today = DateTime.Now ;
					if (Page.Session["LoginTime"] != null)
						today = (DateTime)Page.Session["LoginTime"];

					DateTime tupdate = DateTime.Now ;
					if (Page.Session["LastUpdate"] != null)
						tupdate = (DateTime)Page.Session["LastUpdate"];

					if (CultureInfo.CurrentCulture.Name.ToUpper() == "IT-IT")
					{
						_userInfo = "Id. Utente: " + Page.Session["IdUtente"].ToString() + " / Id. Operatore: " + Page.Session["IdOperatore"].ToString() + "\n\r" ;
						_userInfo += "Oggi e` " + today.ToLongDateString() + "\n\r" ;
						_userInfo += "Ultimo Aggiornamento: " + tupdate.ToLongTimeString() ;
					}
					else
					{
						_userInfo = "User Id: " + Page.Session["IdUtente"].ToString() + " Operator Id: " + Page.Session["IdOperatore"].ToString() + "\n\r" ;
						_userInfo += "Today is " + today.ToLongDateString() + "\n\r" ;
						_userInfo += "Last Update: " + tupdate.ToLongTimeString() ;
					}
				}
				else
				{
					_userInfo = String.Empty ;
				}

				string s = "" ;
				s += "<SCRIPT>" + nl ;
				s += "var timer;" + nl ;
				s += "var oBody	=	document.body;" + nl;
				s += "var oFrame =	parent.document.all('embeddedFrame');" + nl;
				s += "function do_Alert()" + nl;
				s += "{" + nl;
				s += "  clearTimeout(timer);" + nl;
				s += "  alert(document.getElementById('CH_alertHidden').value);" + nl;
				s += "}" + nl;
				s += "function do_PostBack()" + nl;
				s += "{" + nl;
				s += "  clearTimeout(timer);" + nl;
				s += "  __doPostBack(document.getElementById('CH_eventTarget').value,document.getElementById('CH_eventArgument').value);" + nl;
				s += "}" + nl;
				s += "if (document.getElementById('CH_alertHidden') != null && document.getElementById('CH_alertHidden').value != '')" + nl;
				s += "{" + nl;
				s += "  timer=setTimeout('do_Alert();', 10);" + nl;
				s += "}" + nl;
				s += "if (document.getElementById('CH_confirmHidden') != null && document.getElementById('CH_confirmHidden').value != '')" + nl;
				s += "{" + nl;
				s += "	if (confirm(document.getElementById('CH_confirmHidden').value))" + nl;
				s += "  {" + nl;
				s += "      timer = setTimeout('do_PostBack();', 10);" + nl;
				s += "  }" + nl;
				s += "}" + nl;
				s += "if (oFrame != null && oBody != null)" + nl;
				s += "{" + nl;
				s += "  if (oFrame.runtimeStyle.height != oBody.scrollHeight + (oBody.offsetHeight -" + nl;
				s += "								oBody.clientHeight) + 20)" + nl;
				s += "  {" + nl;
				s += " 	    oFrame.runtimeStyle.height = oBody.scrollHeight + (oBody.offsetHeight -" + nl;
				s += "								oBody.clientHeight) + 20;" + nl;
				s += "  }" + nl;
				s += "}" + nl;
//				s += "if (parent != null && parent.document != null && parent.document.all('divUser') != null)" + nl;
//				s += "{" + nl;
//				s += "  parent.document.all('divUser').innerText='" + _userInfo + "';" + nl;
//				s += "  parent.document.all('divUser').style.display='block';" + nl;
//				s += "  parent.document.all('divTitle').innerText=document.getElementById('CH_titleHidden').value;" + nl;
//				s += "	parent.document.all('divTitle').style.display='block';" + nl;
//				s += "}" + nl;
//				s += "else " + nl;
//				s += "{" + nl;
//				s += "  if (document.all('divUser') != null)" + nl;
//				s += "  {" + nl;
//				s += "      document.all('divUser').innerText='" + _userInfo + "';" + nl;
//				s += "      document.all('divUser').style.display='block';" + nl;
//				s += "      document.all('divTitle').innerText=document.getElementById('CH_titleHidden').value;" + nl;
//				s += "	    document.all('divTitle').style.display='block';" + nl;
//				s += "  }" + nl;
//				s += "}" + nl;
				s += "</SCRIPT>" + nl;

				Page.RegisterStartupScript("ClientHelp_StartupScript", s);

				Page.RegisterHiddenField("CH_alertHidden", AlertText);
				Page.RegisterHiddenField("CH_confirmHidden", ConfirmText);
				Page.RegisterHiddenField("CH_eventTarget", EventTarget);
				Page.RegisterHiddenField("CH_eventArgument", EventArgument);
				Page.RegisterHiddenField("CH_titleHidden", TitleText);
				Page.RegisterHiddenField("CH_mustSave", MustSave.ToString());
				Page.RegisterHiddenField("CH_mustSaveMessage", MustSaveMessage);

				//Page.RegisterHiddenField("CH_innerText", _innerText.ToString);

				// funzioni lato clienti da chiamare quando 
				// 1) bisonga abbandonare la pagina senza modifiche: il bottone deve chiamare prima della submit CheckMustSave
				// 2) si fanno delle modifiche alla pagina che non generano eventi di submit --> dico coumnque
				//    che la pagina e` da salvare. Poi o un bottone lato cliente (1) o il menu` chiederanno se bisogna abbandonare la pagina
				string sss = "" ;
				sss += "<SCRIPT>" + nl;
				sss += "function CheckMustSave()" + nl;
				sss += "{ " + nl;
				sss += "	var chms = document.getElementById('CH_mustSave');" + nl;
				sss += "	if (chms != null && chms.value == 'True') " + nl;
				sss += "	{ " + nl;
				sss += "		var chmsg = document.getElementById('CH_mustSaveMessage');" + nl;
				sss += "		var message;" + nl;
				sss += "		if (chmsg != null && chmsg.value != null) " + nl;
				sss += "			message = chmsg.value; " + nl;
				sss += "		else " + nl;
				sss += "			message = '" + this.MustSaveMessage + "';" + nl;
				sss += "		return confirm(message);" + nl;
				sss += "	}" + nl;
				sss += "	return true;" + nl;
				sss += "}" + nl;
				sss += nl;
				sss += "function SetMustSave()" + nl;
				sss += "{ " + nl;
				sss += "	var chms = document.getElementById('CH_mustSave');" + nl;
				sss += "	if (chms != null)" + nl;
				sss += "		chms.value = 'True';" + nl;
				sss += "}" + nl;
				sss += "</SCRIPT>" + nl;
				Page.RegisterClientScriptBlock("ClientHelp_CheckSetMustSave", sss);
			}
		}

		protected override void Render(System.Web.UI.HtmlTextWriter output)
		{
			if ((this.Site != null) && (this.Site.DesignMode))
			{
				output.Write("[ClientHelp (visible when DesignMode is '" + this.Site.DesignMode.ToString() + "')]") ;
			}
		}

		// bisogna fare MOLTA attenzione:
		// CH_mustSave puo` essere stato modificato lato cliente.
		// Quando arrivo qui leggo il valore lato cliente e lo memorizzo in MustSave
		// Poi forse a fronte di questo evento verra` chiamata una callback:
		// 1) si fa save --> bisogna resettare MustSave; al prossimo evento nella pagina non dovro` piu` salvare
		// 2) non si fa save --> MustSave NON viene toccato (es qualche evento di pagina per aprire dettagli);
		//    mantengo il flag (dato che poi faccio il render per rimettere nell'hidden il valore di MustSave)
		private void ClientHelp_Load(object sender, System.EventArgs e) //Handles MyBase.Load
		{
			if ((Page.IsPostBack) && (MustSave == false))
			{
				if (Page.Request.Form["CH_mustSave"].ToUpper() == "TRUE")
				{
					MustSave = true;
				}
			}
		}

	}

}
