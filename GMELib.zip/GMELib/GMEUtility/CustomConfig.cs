using System;
using System.IO;
using System.Configuration;
using System.Collections;
using System.Collections.Specialized;
using System.Threading;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Serialization;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Proxies;
using System.Runtime.Remoting.Messaging;
using System.Runtime;
using System.Reflection;


namespace GME.Utility
{
	/*
	public class ProgramSettings : MarshalByRefObject
	{
		public string a = "";
		public int b = 3;
		
		[XmlArray("c")]
		[XmlArrayItem("cItem")]
		public string [] d;
	}
	 
	in cima all'app.config:
	<configSections>
      	<section name="ProgramSettings" type="GME.Utility.CustomConfigTagHandler, GMEUtility" />
	</configSections>

	dopo 
	mettere a autoReload a true se si vuole ri-leggere automaticamente l'app.config
	quando cambia; in questo caso la classe da serializzare deve derivare da MarshalByRefObject
	se invece autoReload e` false non e` necessario che la classe derivi da MarshalByRefObject
	<ProgramSettings type="GMETest.ProgramSettings, GMETest" autoReload="true" >
		<a>Leo</a>
		<b>33</b>
		<c>
			<cItem>a</cItem>
			<cItem>b</cItem>
			<cItem>c</cItem>
		</c>
	</ProgramSettings>

	*/ 
	


	public class CustomConfigTagHandler : IConfigurationSectionHandler 
	{
		public object Create(object parent, object configContext, XmlNode section)
		{
			XPathNavigator nav = section.CreateNavigator();
			string typename = (string) nav.Evaluate("string(@type)");
			Type t = Type.GetType(typename);

			bool bAutoReload = false;
			string s = (string)nav.Evaluate("string(@autoReload)"); // se non esiste l'attributo ritorna ""
			if (s == "1" || s.ToLower() == "true")
				bAutoReload = true;

			string ConfigFile = section.BaseURI;
			if (ConfigFile == string.Empty)
				ConfigFile =AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
			else
				ConfigFile = ConfigFile.Remove(0, 8); // file:///
 
			if (bAutoReload == false)
			{
				XmlSerializer xmlDeserializer = new XmlSerializer(t);
				return xmlDeserializer.Deserialize(new XmlNodeReader(section));
			}
			else
			{
				CustomConfigSettingsReader ccr = new CustomConfigSettingsReader(section, t, ConfigFile);
				object o = ccr.GetTransparentProxy();
				return o;
			}
		}
	}




	public class CustomConfigSettingsReader : RealProxy
	{
		private FileSystemWatcher _watcher;
		private string _rootName;
		private MarshalByRefObject _target;
		volatile private bool _isValidData;
		private XmlSerializer _xs;
		private string _configFile;

		public CustomConfigSettingsReader(XmlNode section, Type type, string configFile)
			: base(type)
		{
			_configFile = configFile;
			_isValidData = false;
			_rootName = section.Name;
			_xs = new XmlSerializer(type);

			try
			{
				FileInfo info = new FileInfo(configFile);

				_watcher = new FileSystemWatcher(info.DirectoryName);
				_watcher.Filter = info.Name;
				_watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size;
				_watcher.EnableRaisingEvents = true;
				_watcher.Changed += new FileSystemEventHandler(mWatcher_Changed);
			}
			catch (Exception ex)
			{
				throw new ConfigurationException("Unable to initialize FileSystemWatcher for configuration file", ex);
			}

		}

		private void LoadConfig()
		{
			XmlDocument doc = new XmlDocument();
			doc.Load(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
			XmlNodeList nodes = doc.GetElementsByTagName(_rootName);

			if (nodes.Count == 0)
				throw new ConfigurationException("Configuration section " + _rootName + " not found");

			_target = (MarshalByRefObject) _xs.Deserialize(new XmlNodeReader(nodes[0]));
		}

		private void mWatcher_Changed(object sender, FileSystemEventArgs e)
		{
			lock(this)
			{
				_isValidData = false;
			}
		}

		public override IMessage Invoke(IMessage msg)
		{
			lock (this)
			{
				if (_isValidData == false)
				{
					LoadConfig();
					_isValidData = true;
				}

				return RemotingServices.ExecuteMessage(_target, (IMethodCallMessage)msg);
			}
		}

	}


	internal class AlternateConfig
	{
		public static Hashtable nnn = new Hashtable();
		public static NameValueCollection nvc = new NameValueCollection();

		static public NameValueCollection AppSettings
		{
			get { return nvc; }
		}

		static public Hashtable CustomConfig
		{
			get { return nnn; }
		}

		public static void LoadConfigFile(string configFile)
		{
			XmlDocument d = new XmlDocument();
			d.Load(configFile);

			XmlNodeList nd = d.DocumentElement.SelectNodes("configSections/section");

			foreach (XmlNode n in nd)
			{
				string name = n.Attributes["name"].Value;
				string type = n.Attributes["type"].Value;

				Type ty = Type.GetType(type);

				IConfigurationSectionHandler r = (IConfigurationSectionHandler)GME.Utility.ReflectionUtilities.CreateObject(ty);

				object c = r.Create(null, null, d.DocumentElement.SelectSingleNode(name));

				nnn[name] = c;
			}

			nd = d.DocumentElement.SelectNodes("appSettings/add");
			foreach (XmlNode n in nd)
			{
				string key = n.Attributes["key"].Value;
				string value = n.Attributes["value"].Value;

				nvc.Add(key, value);
			}
		}
	}

}

