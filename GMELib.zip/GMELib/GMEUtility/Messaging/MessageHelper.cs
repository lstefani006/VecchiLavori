using System;
using System.Configuration;

namespace Messaging
{
	public class MessageHelper
	{
		private MessageHelper() {}

		public static string TranslateTradingPartner(PIPEDoc.partnerTypeType ty)
		{
			string r = null;
			switch (ty)
			{
				case PIPEDoc.partnerTypeType.EnergySupplier:
					r = "EnergySupplier";
					break;
				case PIPEDoc.partnerTypeType.Distributor:
					r = "Distributor";
					break;
				case PIPEDoc.partnerTypeType.Operator:
					r = "Operator";
					break;
				case PIPEDoc.partnerTypeType.MarketParticipant:
					r = "Market Participant";
					break;
				case PIPEDoc.partnerTypeType.TaxExemptMarketParticipant:
					r = "Tax Exempt Market Participant";
					break;
			}

			return r;
		}

		public static string Translate(FA.pipTransctionType t)
		{
			return t.ToString();
		}

		public static string GenerateId30()
		{
			return NewId30.Generate();
		}
	}


	internal class NewId30
	{
		private static Int64 nNewId = 0;
		private static string sNewId = null;
		private static string sAppId = null;

		public static string Generate()
		{
			string r;
			lock (typeof (NewId30))
			{
				if (sNewId == null)
					sNewId = string.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now);

				if (sAppId == null)
				{
					sAppId = ConfigurationSettings.AppSettings["NewId30.AddId"];
					if (sAppId == null)
						sAppId = new Random().Next(100).ToString("d2");
				}
				string s = string.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now);
				if (s != sNewId)
				{
					sNewId = s;
					nNewId = 0;
				}
				r = sNewId + nNewId.ToString("D9") + sAppId;
				nNewId += 1;
			}
			return r;
		}
	}
}