using System;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using PIPEDoc;

namespace Messaging
{
	/// <summary>
	/// Questo e` un lettore " a basso livello ". Non interagisce con le classi Message TransactionFacade ecc.
	/// Il suo scopo e` di leggere uno stream XML e produrre eventi quando legge PIPEDocument, TradingPartnerDirectory,
	/// PIPTransaction o quando trova errori di validazione.
	/// </summary>
	public class PipTransactionReader
	{
		private PIPTransaction _currentPipTransaction = null;
		private PIPEDocument _currentPipeDocument = null;
		private bool _stopReading = false;

		public delegate void PIPEDocumentDelegate(PIPEDocument doc);
		public delegate void PIPEDocumentVersionErrorDelegate(PIPEDocument doc, string readVersion);

		public delegate void TradingPartnerDirectoryDelegate(PIPEDocument doc, TradingPartnerDirectory tpd);

		public delegate void PIPTransactionDelegate(PIPEDocument doc, PIPTransaction tr, XmlReader xr);
		public delegate void ValidationDelegate(PIPEDocument doc, PIPTransaction tr, ValidationEventArgs e, object innerPIP);

		public event PIPTransactionDelegate PIPTransaction;
		public event TradingPartnerDirectoryDelegate TradingPartnerDirectory;

		public event ValidationDelegate Validation;
		public event PIPEDocumentDelegate PIPEDocument;
		public event PIPEDocumentVersionErrorDelegate PIPEDocumentVersionError;

		[ThreadStatic]
		public object PIPDocInternalElement = null;


		static XmlSerializer xTradingPartnerDirectory = new XmlSerializer(typeof (TradingPartnerDirectory));

		public void StopReading()
		{
			_stopReading = true;
		}

		public PIPEDocument ReadPipeDocument(string fileSchema, string fileXml)
		{
			XmlTextReader textReader = new XmlTextReader(fileXml);
			textReader.WhitespaceHandling = WhitespaceHandling.None;

			try
			{
				return ReadPipeDocument(fileSchema, textReader);
			}
			finally
			{
				textReader.Close();				
			}
		}


		public PIPEDocument ReadPipeDocument(string fileSchema, XmlReader xrMessage)
		{
			XmlSchemaCollection sc = new XmlSchemaCollection();
			sc.Add(null, fileSchema);


			XmlValidatingReader xr = new XmlValidatingReader(xrMessage);
			xr.ValidationType = ValidationType.Schema;
			xr.Schemas.Add(sc);
			xr.ValidationEventHandler += new ValidationEventHandler(xr_ValidationEventHandler);

			object elPipeDocument = xr.NameTable.Add("PIPEDocument");
			object elTradingPartnerDirectory = xr.NameTable.Add("TradingPartnerDirectory");
			object elPIPTransaction = xr.NameTable.Add("PIPTransaction");

			while (xr.Read() && _stopReading == false)
			{
				bool doNotRead = false;
				do
				{
					object xrn = xr.Name;
					doNotRead = false;

					switch (xr.NodeType)
					{
						case XmlNodeType.Element:
						{
							if (xrn == elPipeDocument)
							{
								// se si arriva qui significa che tutti gli attributi sono valorizzati
								// correttamente.... versione compresa.

								_currentPipeDocument = new PIPEDocument();
								_currentPipeDocument.CreationDate = xr.GetAttribute("CreationDate");

								string version = xr.GetAttribute("Version");
								if (version != null && version == "1.0")
									_currentPipeDocument.Version = PIPEDoc.version.Item10;
								else
								{
									// qui non si arriva mai dato che la versione
									// e` controllata dallo schema
									OnPipeDocumentVersionError(_currentPipeDocument, version);
								}

								if (_stopReading == false)
								{
									_currentPipeDocument.ReferenceNumber = xr.GetAttribute("ReferenceNumber");
									OnPipeDocument(_currentPipeDocument);
								}
							}
							else if (xrn == elTradingPartnerDirectory)
							{
								_currentPipeDocument.TradingPartnerDirectory = (TradingPartnerDirectory) xTradingPartnerDirectory.Deserialize(xr);
								doNotRead = true;

								OnTradingPartnerDirectory(_currentPipeDocument, _currentPipeDocument.TradingPartnerDirectory);
							}
							else if (xrn == elPIPTransaction)
							{
								_currentPipTransaction = new PIPTransaction();
								_currentPipTransaction.ReferenceNumber = xr.GetAttribute("ReferenceNumber");
								_currentPipTransaction.InboundMessageCreationDate = xr.GetAttribute("InboundMessageCreationDate");
								_currentPipTransaction.InboundMessageCreationTime = xr.GetAttribute("InboundMessageCreationTime");

								if (_currentPipTransaction.ReferenceNumber == null || 
									_currentPipTransaction.ReferenceNumber.Length == 0)
								{
									// l'attributo e` opzionale. 
									// Se chi manda il documento non lo specifica Excelergy ne crea uno d'ufficio
									_currentPipTransaction.ReferenceNumber = MessageHelper.GenerateId30();
								}
							}
							else
							{
								if (_currentPipTransaction != null)
								{
									OnPIPTransaction(_currentPipeDocument, _currentPipTransaction, xr);
									_currentPipTransaction = null;

									// quando siamo qua xr punta all'endElement della PipTransaction

									this.PIPDocInternalElement = null;
								}
							}
							break;
						}
					}
				}
				while (doNotRead && _stopReading == false);
			}

			return _currentPipeDocument;
		}

		private void xr_ValidationEventHandler(object sender, ValidationEventArgs e)
		{
			if (Validation != null)
				Validation(_currentPipeDocument, _currentPipTransaction, e, this.PIPDocInternalElement);
		}


		protected virtual void OnPIPTransaction(PIPEDocument doc, PIPTransaction tr, XmlReader xr)
		{
			if (PIPTransaction != null)
				PIPTransaction(doc, tr, xr);
		}

		protected virtual void OnPipeDocument(PIPEDocument doc)
		{
			if (PIPEDocument != null)
				PIPEDocument(doc);
		}

		protected virtual void OnPipeDocumentVersionError(PIPEDocument doc, string readVersion)
		{
			if (PIPEDocumentVersionError != null)
				PIPEDocumentVersionError(doc, readVersion);
		}


		protected virtual void OnTradingPartnerDirectory(PIPEDocument doc, TradingPartnerDirectory tpd)
		{
			if (TradingPartnerDirectory != null)
				TradingPartnerDirectory(doc, tpd);
		}
	}
}