using System;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;
using PIPEDoc;

namespace Messaging
{
	/// <summary>
	/// classe per leggere i messaggi PIPE
	/// E` una sorta di class factory di <c>Message</c> partendo da un Xml da leggere.
	/// </summary>
	public class MessageReader
	{
		private Message _currentMsg;
		private TransactionFacade _currentTransaction = null;
		private Hashtable _transactionFacadeFactoryTable = new Hashtable();
		private PipTransactionReader _mr;
		private string _channelOperator = null;
		private StringCollection _RootOperators = new StringCollection();

		public delegate void NewTransactionDelegate(Message msg, TransactionFacade tr);
		public event NewTransactionDelegate NewTransaction;

		public delegate void MessageHeaderDelegate(Message msg);
		public event MessageHeaderDelegate MessageHeader;


		/// <summary>
		/// Aggiunge alla lista degli operatori root <c>rootOperator</c>.
		/// Un operatore root puo` mandare un messaggio a nome di un altro operatore.
		/// Il messaggio, cioe` puo` contenere un Sender diverso dal channelOperator,
		/// l'operatore che ha mandato fisicamente il messaggio, solo se e` un root operator.
		/// Se l'operatore channelOperator non e` root operator e non coincide con il sender 
		/// si verifica un errore di validazione.
		/// </summary>
		/// <param name="rootOperator">indica un nuovo root operator.</param>
		public void AddRootOperator(string rootOperator)
		{
			_RootOperators.Add(rootOperator);
		}

		/// <summary>
		/// Legge il <c>fileXml</c> controllando che sia aderente a <c>fileSchema</c>
		/// </summary>
		/// <param name="fileSchema">path dei file di schema</param>
		/// <param name="fileXml">path dei file XML da leggere</param>
		/// <param name="channelOperator">id dell'operatore che ha manda il messaggio cosi` come risulta dal canale</param>
		/// <returns>il messaggio</returns>
		public Message ReadMessage(string fileSchema, string fileXml, string channelOperator)
		{
			XmlTextReader xr = new XmlTextReader(fileXml);
			try
			{
				return ReadMessage(fileSchema, xr, channelOperator);
			}
			finally
			{
				xr.Close();
			}
		}


		/// <summary>
		/// Legge <c>xr</c> controllando che sia aderente a <c>fileSchema</c>
		/// </summary>
		/// <param name="fileSchema">path dei file di schema</param>
		/// <param name="xr">l'xml da leggere</param>
		/// <param name="channelOperator">id dell'operatore che ha manda il messaggio cosi` come risulta dal canale</param>
		/// <returns>il messaggio</returns>
		public Message ReadMessage(string fileSchema, XmlReader xr, string channelOperator)
		{
			Debug.Assert(_currentMsg == null);
			Debug.Assert(_mr == null);
			try
			{
				_channelOperator = channelOperator;

				_mr = new PipTransactionReader();
				_mr.PIPEDocument += new PipTransactionReader.PIPEDocumentDelegate(mr_PIPEDocument);
				_mr.PIPEDocumentVersionError += new PipTransactionReader.PIPEDocumentVersionErrorDelegate(mr_PIPEDocumentVersionError);
				_mr.PIPTransaction += new PipTransactionReader.PIPTransactionDelegate(mr_PIPTransaction);
				_mr.TradingPartnerDirectory += new Messaging.PipTransactionReader.TradingPartnerDirectoryDelegate(_mr_TradingPartnerDirectory);
				_mr.Validation += new PipTransactionReader.ValidationDelegate(mr_Validation);

				_currentMsg = new Message();
				_mr.ReadPipeDocument(fileSchema, xr);

				if (_currentMsg.Valid == false)
				{
					// questo codice serve per generare un messaggio valido 
					// anche a fronte di errori !!!

					if (_currentMsg.PIPEDocument == null)
						_currentMsg.StorePIPEDocument(new PIPEDocument());

					if (_currentMsg.PIPEDocument.ReferenceNumber == null || _currentMsg.PIPEDocument.ReferenceNumber.Length == 0)
						_currentMsg.PIPEDocument.ReferenceNumber = "UNKNOWN";


					if (_currentMsg.PIPEDocument.TradingPartnerDirectory == null)
						_currentMsg.PIPEDocument.TradingPartnerDirectory = new TradingPartnerDirectory();

					if (_currentMsg.PIPEDocument.TradingPartnerDirectory.Recipient == null)
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Recipient = new Recipient();

					if (_currentMsg.PIPEDocument.TradingPartnerDirectory.Sender == null)
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Sender = new Sender();

					if (_currentMsg.PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner == null)
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner = new TradingPartner();

					if (_currentMsg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner == null)
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner = new TradingPartner();

					if (_currentMsg.PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner.CompanyIdentifier == null)
					{
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner.CompanyIdentifier = "IDGME";
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner.CompanyName = "GME SPA";
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner.PartnerType = partnerTypeType.Operator;
					}

					if (_currentMsg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier == null)
					{
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier = channelOperator;
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyName = channelOperator;
						_currentMsg.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.PartnerType = partnerTypeType.Operator;
					}
				}
			}
			catch (Exception e)
			{
				e = e;
#if DEBUG
				Debugger.Break();
#endif
				throw;
			}

			return _currentMsg;
		}


		/// <summary>
		/// Associa all'<c>elementName</c> dello schema il tipo <c>ty</c>.
		/// Quando nell'xml si trova <c>elementName</c> viene creata la classe descritta da <c>ty</c>.
		/// La classe in <c>ty</c> deve derivare da <c>TransactionFacade</c>
		/// </summary>
		/// <param name="elementName">il nome dell'elemento</param>
		/// <param name="ty">il tpo della transazione</param>
		public void AddToFactoryTable(string elementName, Type ty)
		{
			if (ty.IsAssignableFrom(typeof (TransactionFacade)))
				throw new ArgumentException("ty deve descrivere una classe derivata da TransactionFacade", "ty");

			ConstructorInfo ci = ty.GetConstructor(
				BindingFlags.Instance | BindingFlags.Public | BindingFlags.CreateInstance | BindingFlags.Default, null,
				CallingConventions.Any, new Type[] {typeof (PIPTransaction)}, null
				);

			if (ci == null)
				throw new ArgumentException("ty", "la classe passata in ty non ha il costruttore adatto");

			_transactionFacadeFactoryTable[elementName] = ci;
		}

		/// <summary>
		/// Funzione chiamata per creare la classe derivata da <c>TransactionFacade</c> a fronte
		/// di una nuova PIPTransaction. 
		/// </summary>
		/// <param name="elmentName">l'innerElement all'interno della PIPTRansaction</param>
		/// <param name="doc">il PIPDocument</param>
		/// <param name="tr">la PIPTRansaction</param>
		/// <returns>la nuova istanza della classe derivata da TransactionFacade</returns>
		protected virtual TransactionFacade OnCreateTransaction(string elmentName, PIPEDocument doc, PIPTransaction tr)
		{
			if (!_transactionFacadeFactoryTable.ContainsKey(elmentName))
			{
				return null;
			}

			ConstructorInfo ci = (ConstructorInfo) _transactionFacadeFactoryTable[elmentName];
			if (ci == null)
				return null;

			TransactionFacade trf = (TransactionFacade) ci.Invoke(new object[] {tr});
			return trf;
		}


		private void mr_PIPEDocument(PIPEDocument doc)
		{
			_currentMsg.StorePIPEDocument(doc);
			OnMessageHeader(_currentMsg);
		}


		protected virtual void OnMessageHeader(Message msg)
		{
			if (MessageHeader != null)
				MessageHeader(msg);
		}


		private void mr_PIPTransaction(PIPEDocument doc, PIPTransaction tr, XmlReader xr)
		{
			string elementName = xr.Name;

			// creo la classe 
			_currentTransaction = this.OnCreateTransaction(elementName, doc, tr);
			if (_currentTransaction == null)
			{
				_currentMsg.SetError("X3", "Unknown element '{0}' in document message.", elementName);

				// skip al prossimo elemento
				// TODO non so se e` corretto fare questa cosa
				while (xr.Read())
					if (xr.NodeType == XmlNodeType.EndElement && xr.Name == "PIPTransaction")
						break;

				return;
			}

			// la aggiungo al messaggio
			_currentMsg.Transaction.Add(_currentTransaction);

			// leggo l'innerElement della PIPTransaction
			_currentTransaction.Read(xr);

			// qui si controllano gli eventuali attributi mancanti nella PIPTransaction
			PIPTransactionAttributes missingAttributes = _currentTransaction.CheckRequiredAttibutes();
			if (missingAttributes != PIPTransactionAttributes.None)
			{
				_currentTransaction.SetError("X3",
				                             "Missing attribute(s) on PIPTransaction element: " + missingAttributes.ToString());
			}

			OnNewTransaction(_currentMsg, _currentTransaction);

			// ho finito con la transazione corrente.
			_currentTransaction = null;
		}

		protected virtual void OnNewTransaction(Message msg, TransactionFacade tr)
		{
			if (NewTransaction != null)
				NewTransaction(msg, tr);
		}

		private void mr_Validation(PIPEDocument doc, PIPTransaction tr, ValidationEventArgs e, object innerPIP)
		{
			if (tr != null)
			{
				if (_currentTransaction != null)
				{
					_currentTransaction.SetError("X1", e.Message);
				}

				/*
				if (innerPIP is BidSubmittal)
				{
				}
				else
				{
				}
				*/
			}
			else
			{
				_currentMsg.SetError("X2", e.Message);

				// un errore a livello di documento invalida tutto. 
				// Tanto vale abbandonare la lettura
				_mr.StopReading();
			}
		}

		private void mr_PIPEDocumentVersionError(PIPEDocument doc, string readVersion)
		{
			if (readVersion == null) readVersion = string.Empty;
			if (_currentMsg != null)
			{
				_currentMsg.SetError("X5", "Version mismatch: supported version is 1.0, read version is {0}", readVersion);
				_mr.StopReading();
			}
		}

		private void _mr_TradingPartnerDirectory(PIPEDocument doc, TradingPartnerDirectory tpd)
		{
			string senderOperator = null;
			if (doc != null)
				if (doc.TradingPartnerDirectory != null)
					if (doc.TradingPartnerDirectory.Sender != null)
						if (doc.TradingPartnerDirectory.Sender.TradingPartner != null)
							if (doc.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier != null)
							{
								senderOperator = doc.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier;
							}

			if (senderOperator == null)
			{
				_currentMsg.SetError("X6", "sender Operator mismatch.");
				_mr.StopReading();
				return;
			}

			if (_channelOperator != null && 
				senderOperator != _channelOperator &&
				!_RootOperators.Contains(_channelOperator))
			{
				_currentMsg.SetError("X6", "sender Operator mismatch.");
				_mr.StopReading();
				return;
			}

		}
	}
}