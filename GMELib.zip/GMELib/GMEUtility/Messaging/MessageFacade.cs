using System;
using System.Diagnostics;
using System.Xml;

namespace Messaging
{
	[Flags]
	public enum PIPTransactionAttributes
	{
		None = 0,

		InboundMessageCreationDate = 1,
		InboundMessageCreationTime = 2,
		ReferenceNumber = 4,

		All = 1+2+4
	}


	public abstract class TransactionFacade
	{
		/// <summary>
		/// Una transazione parte da un PIPTransaction letta dal messaggio
		/// </summary>
		/// <param name="PIPTransaction"></param>
		public TransactionFacade(PIPEDoc.PIPTransaction PIPTransaction, PIPTransactionAttributes requiredAttributes)
		{
			_requiredAttributes = requiredAttributes;
			this.PIPTransaction = PIPTransaction;
		}

		/// <summary>
		/// Ritorna quali campi sono eventualmente mancanti dalla PIPTransaction.
		/// Funzione normalmente chiamata da <c>MessageReader</c> per controllare
		/// se gli attributi della PIPTransaction sono valorizzati secondo
		/// i dettami dello schema.
		/// La validazione di questi campi non puo` essere effettuata dal validatore di xsd
		/// in quando ogni innerElement di una PIPTransaction specifica quali attributi
		/// sono required.
		/// </summary>
		/// <returns>gli attributi richiesti che sono mancanti</returns>
		internal PIPTransactionAttributes CheckRequiredAttibutes()
		{
			if ((_requiredAttributes & PIPTransactionAttributes.ReferenceNumber) != 0)
			{
				if (this.PIPTransaction.ReferenceNumber == null)
					return PIPTransactionAttributes.ReferenceNumber;
			}
			if ((_requiredAttributes & PIPTransactionAttributes.InboundMessageCreationDate) != 0)
			{
				if (this.PIPTransaction.InboundMessageCreationDate == null)
					return PIPTransactionAttributes.InboundMessageCreationDate;
			}
			if ((_requiredAttributes & PIPTransactionAttributes.InboundMessageCreationTime) != 0)
			{
				if (this.PIPTransaction.InboundMessageCreationTime == null)
					return PIPTransactionAttributes.InboundMessageCreationTime;
			}
			return PIPTransactionAttributes.None;
		}

		/// <summary>
		/// Codice di errore di questa transazione. Questo codice comparira` nell'FA corrispondente
		/// </summary>
		public string ErrorCode
		{
			get { return _errorCode; }
		}
		/// <summary>
		/// Messaggio di errore associato a questa transazione. Questo messaggio comparira` nell'FA corrispondente
		/// </summary>
		public string ErrorMessage
		{
			get { return _errorMessage; }
		}

		/// <summary>
		/// Imposta l'errore al messaggio
		/// </summary>
		/// <param name="errorCode"></param>
		/// <param name="errorMessage"></param>
		public virtual void SetError(string errorCode, string errorMessage)
		{
			if (errorCode != null && errorCode.Length == 0) errorCode = null;
			if (errorMessage != null && errorMessage.Length == 0) errorMessage = null;

			if (errorCode == null) errorMessage = null;

			_errorCode = errorCode;
			_errorMessage = errorMessage;
		}

		/// <summary>
		/// Indica se il messaggio non ha errori associati
		/// </summary>
		public virtual bool Valid
		{
			get { return ErrorCode == null || ErrorCode.Length == 0; }
		}

		/// <summary>
		/// ritorna il MarketParticipantNumber della transazione da specificare
		/// nel FA. Nelle offerte e` MarketParticipantNumber nei Bilaterali e` MPN
		/// </summary>
		public abstract string FA_MarketParticipantNumber
		{
			get;
		}

		/// <summary>
		/// Ritorna il tipo di transazione da specificare nella FA
		/// </summary>
		public abstract string FA_TransactionType
		{
			get;
		}

		/// <summary>
		/// Funzione che legge la transazione da <c>xr</c>
		/// </summary>
		/// <param name="xr">reader da cui leggere</param>
		public abstract void Read(XmlReader xr);

		/// <summary>
		/// Funzione per scrivere la transazione in un <c>xw</c>
		/// </summary>
		/// <param name="xw">writer in cui scrivere</param>
		public abstract void Write(XmlWriter xw);

		/// <summary>
		/// Funzione da utilizzare nelle <c>Write(XmlWriter xw)</c> delle classi 
		/// derivate. Serve per scrivere in <c>xw</c> lo start PIPTransaction
		/// </summary>
		/// <param name="xw"></param>
		protected virtual void WriteStartPIP(XmlWriter xw)
		{
			xw.WriteStartElement("PIPTransaction");
			if (this.PIPTransaction.ReferenceNumber != null) 
				xw.WriteAttributeString("ReferenceNumber", this.PIPTransaction.ReferenceNumber);

			if (this.PIPTransaction.InboundMessageCreationDate != null)
				xw.WriteAttributeString("InboundMessageCreationDate", this.PIPTransaction.InboundMessageCreationDate);

			if (this.PIPTransaction.InboundMessageCreationTime != null)
				xw.WriteAttributeString("InboundMessageCreationTime", this.PIPTransaction.InboundMessageCreationTime);
		}
		/// <summary>
		/// Funzione simmetrica a <c>WriteStartPIP</c> da chiamare per chiudere il tag PIPTransaction
		/// </summary>
		/// <param name="xw"></param>
		protected virtual void WriteEndPIP(XmlWriter xw)
		{
			xw.WriteEndElement();
		}


		/// <summary>
		/// Scrive l'FA relativo a questa transazione
		/// </summary>
		/// <param name="w"></param>
		public void WriteFA(XmlWriter w)
		{
			w.WriteStartElement("TransactionAcknowledgement");
			w.WriteAttributeString("Status", Valid ? "Accept" : "Reject");

			w.WriteAttributeString("PIPTransactionType", FA_TransactionType);

			// notare che lo schema della PIPTransaction non obbliga a scrivere il ReferenceNumber
			// ... pero` quando si leggono le PIPTransaction, Excelergy genera un ReferenceNumber
			// di ufficio. 
			// Qui, dunque, assumo che l'attributo sia 
			Debug.Assert(PIPTransaction.ReferenceNumber != null);
			w.WriteAttributeString("OriginalReferenceNumber", PIPTransaction.ReferenceNumber);

			if (FA_MarketParticipantNumber != null && FA_MarketParticipantNumber.Length > 0)
				w.WriteAttributeString("MarketParticipantNumber", FA_MarketParticipantNumber);

			if (!Valid)
			{
				w.WriteStartElement("RejectInformation");
				w.WriteStartElement("Reason");
				w.WriteString(ErrorCode);
				w.WriteEndElement();
				w.WriteStartElement("ReasonText");
				w.WriteString(ErrorMessage);
				w.WriteEndElement();
				w.WriteEndElement();
			}
			w.WriteEndElement();
		}


		public abstract void Execute(object executeState);


		public readonly PIPEDoc.PIPTransaction PIPTransaction;
		private string _errorCode;
		private string _errorMessage;
		protected readonly PIPTransactionAttributes _requiredAttributes;
	}



	/*
		Inserimento del file controfirmato nel DB
		Verifica che chi mi ha mandato il file sia quello che ha firmato il file. (opzionale)
		
		Lettura con schema del file XML:
			Estrazione delle informazioni di testata + tranding partner.
			
			Loop sulle transazioni:
				ad ogni transazione si memorizza nel DB la transazione come blob.
		
		
		Estrazione del file non firmato dal file firmato.
		Controfirma con data.
		Memorizzazione del Blob su DB
		
		Creazione FA di risposta.
			Controllo di validita` dei dati del certificato dell'operatore.
			Lettura del file per XML well formed con schema (tutto il file)
			Inserimento nel DB TR per TR
		Scrittura dell'FA
	*/


	public class Message
	{
		public Message()
		{
			Transaction = new TransactionList();
			_PIPEDocument = null;
		}

		public void StorePIPEDocument(PIPEDoc.PIPEDocument PIPEDocument)
		{
			this._PIPEDocument = PIPEDocument;
		}

		public PIPEDoc.PIPEDocument PIPEDocument
		{
			get { return _PIPEDocument; }
		}

		public bool Valid
		{
			get { return ErrorCode == null || ErrorCode.Length == 0; }
		}
		public string ErrorCode
		{
			get { return _errorCode; }
		}
		public string ErrorMessage
		{
			get { return _errorMessage; }
		}
		public void SetError(string errorCode, string errorMessage)
		{
			if (errorCode != null && errorCode.Length == 0) errorCode = null;
			if (errorMessage != null && errorMessage.Length == 0) errorMessage = null;

			if (errorCode == null) errorMessage = null;

			_errorCode = errorCode;
			_errorMessage = errorMessage;	
		}
		public void SetError(string errorCode, string fmt, params object [] args)
		{
			string errorMessage = string.Format(fmt, args);
			SetError(errorCode, errorMessage);
		}


		public bool WriteFA(XmlWriter wFA, string FAReferenceNumber)
		{
//			bool operatoreValido = true;
//			if (messageIn.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier == null)
//				operatoreValido = false;
//			else if (codiceOperatoreSDC != messageIn.PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier)
//				operatoreValido = false;


			wFA.WriteStartDocument();
			string CreationDate = string.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now);
			string status;
			if (this.Valid == false)
			{
				status = "Reject";
			}
			else
			{
				int v = 0;
				foreach (TransactionFacade p in this.Transaction)
					if (p.Valid)
						v += 1;

				if (v > 0 && v == this.Transaction.Count)
					status = "Accept";
				else if (v == 0)
					status = "Reject";
				else
					status = "Partial";
			}

			wFA.WriteStartElement("PIPEFunctionalAcknowledgement");
			if (true)
			{
				wFA.WriteAttributeString("xmlns", "urn:XML-PIPE");
				wFA.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");
				wFA.WriteAttributeString("xsi", "schemaLocation", null, "urn:XML-PIPE PIPEFunctionalAcknowledgementv1_0.xsd");
				wFA.WriteAttributeString("ReferenceNumber", FAReferenceNumber);

				if (this._PIPEDocument != null && this._PIPEDocument.ReferenceNumber != null)
					wFA.WriteAttributeString("OriginalReferenceNumber", this._PIPEDocument.ReferenceNumber); // ReferenceNumber required
				else
				{
					// si puo` cadere qui se c'e` un errore tipo versione errata o file non XML
					wFA.WriteAttributeString("OriginalReferenceNumber", string.Empty); // ReferenceNumber required
				}

				wFA.WriteAttributeString("Status", status);
				wFA.WriteAttributeString("CreationDate", CreationDate);
				wFA.WriteAttributeString("Version", "1.0");
				wFA.WriteStartElement("TradingPartnerDirectory");
				if (true)
				{
					wFA.WriteStartElement("Sender"); 
					if (true) 
					{ 
						wFA.WriteStartElement("TradingPartner"); 
						PIPEDoc.partnerTypeType t = this._PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner.PartnerType;
						wFA.WriteAttributeString("PartnerType", MessageHelper.TranslateTradingPartner(t)); 
						if (true) 
						{ 
							wFA.WriteStartElement("CompanyName"); 
							string companyName = this._PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner.CompanyName;
							if (companyName == null) companyName = string.Empty;
							wFA.WriteString(companyName); 
							wFA.WriteEndElement(); 

							wFA.WriteStartElement("CompanyIdentifier"); 
							string companyIdentifier = this._PIPEDocument.TradingPartnerDirectory.Recipient.TradingPartner.CompanyIdentifier;
							if (companyIdentifier == null) companyIdentifier = string.Empty;
							wFA.WriteString(companyIdentifier); 
							wFA.WriteEndElement(); 
						} 
						wFA.WriteEndElement(); 
					}
					wFA.WriteEndElement(); 


					wFA.WriteStartElement("Recipient"); 
					if (true) 
					{ 
						wFA.WriteStartElement("TradingPartner"); 
						PIPEDoc.partnerTypeType t = this._PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.PartnerType;
						wFA.WriteAttributeString("PartnerType", MessageHelper.TranslateTradingPartner(t)); 
						if (true) 
						{ 
							wFA.WriteStartElement("CompanyName"); 
							string companyName = this._PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyName;
							if (companyName == null) companyName = string.Empty;
							wFA.WriteString(companyName); 
							wFA.WriteEndElement(); 

							wFA.WriteStartElement("CompanyIdentifier"); 
							string companyIdentifier = this._PIPEDocument.TradingPartnerDirectory.Sender.TradingPartner.CompanyIdentifier;
							if (companyIdentifier == null) companyIdentifier = string.Empty;
							wFA.WriteString(companyIdentifier); 
							wFA.WriteEndElement(); 
						} 
						wFA.WriteEndElement(); 
					}
					wFA.WriteEndElement(); 
				}
				wFA.WriteEndElement();

				if (!this.Valid)
				{
					wFA.WriteStartElement("RejectInformation");
						wFA.WriteStartElement("Reason");
							wFA.WriteString(this.ErrorCode);
						wFA.WriteEndElement();
						wFA.WriteStartElement("ReasonText");
							wFA.WriteString(this.ErrorMessage);
						wFA.WriteEndElement();
					wFA.WriteEndElement();
				}
				else
				{
					foreach (TransactionFacade p in this.Transaction)
					{
						p.WriteFA(wFA);
					}
				}
			}
			wFA.WriteEndDocument();
			wFA.Flush();
			wFA.Close();
			return true;
		}


		private PIPEDoc.PIPEDocument _PIPEDocument;
		public TransactionList Transaction;
		private string _errorCode;
		private string _errorMessage;
	}
}