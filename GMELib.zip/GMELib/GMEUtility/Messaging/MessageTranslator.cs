using System.IO;
using System.Xml;

namespace Messaging
{
	public abstract class MessageTranslater
	{
		public void ToXmlFile(string fileIn, string fileOut)
		{
			XmlTextReader reader = null;
			try
			{
				reader = new XmlTextReader(fileIn);
				reader.WhitespaceHandling = WhitespaceHandling.None;
				ToXmlFile(reader, fileOut);
			}
			finally
			{
				if (reader != null)
					reader.Close();
			}
		}
		public void ToXmlFile(XmlReader reader, string fileOut)
		{
			StreamWriter streamWriter = null;
			try
			{
				streamWriter = new StreamWriter(fileOut);
				_xmlWriter = new XmlTextWriter(streamWriter);
				Translate(reader);
			}
			finally
			{
				if (streamWriter != null)
					streamWriter.Close();
			}
		}
		public XmlReader ToXmlReader(string fileName)
		{
			XmlTextReader reader = null;
			try
			{
				reader = new XmlTextReader(fileName);
				reader.WhitespaceHandling = WhitespaceHandling.None;
				return ToXmlReader(reader);
			}
			finally
			{
				if (reader == null)
					reader.Close();
			}
		}
		public XmlReader ToXmlReader(XmlReader reader)
		{
			StringWriter stringWriter = new StringWriter();
			_xmlWriter = new XmlTextWriter(stringWriter);
			Translate(reader);
			return new XmlTextReader(new StringReader(stringWriter.ToString()), reader.NameTable);
		}
		private void Translate(XmlReader reader)
		{
			_xmlWriter.Formatting = Formatting.Indented;
			_xmlWriter.Indentation = 1;
			_xmlWriter.IndentChar = '\t';

			_PIPTransaction = reader.NameTable.Add("PIPTransaction");

			while (!reader.EOF)
			{
				switch (reader.NodeType)
				{
					case XmlNodeType.XmlDeclaration:
						_xmlWriter.WriteNode(reader, false);
						break;
					case XmlNodeType.Element:
						ReadPipeDocument(reader);
						break;
					default:
						reader.Read();
						break;
				}
			}

			_xmlWriter.Close();
		}
		private void ReadPipeDocument(XmlReader reader)
		{
			_xmlWriter.WriteStartElement(reader.Prefix, reader.LocalName, reader.NamespaceURI);
			_xmlWriter.WriteAttributes(reader, false);
			reader.Read();

			while (!reader.EOF)
			{
				switch (reader.NodeType)
				{
					case XmlNodeType.Element:
						object elementName = reader.Name;
						if (elementName == _PIPTransaction)
							ReadPIPTransaction(reader);
						else
							_xmlWriter.WriteNode(reader, false);
						break;
					default:
						reader.Read();
						break;
				}
			}
			_xmlWriter.WriteEndElement();
		}
		private void ReadPIPTransaction(XmlReader reader)
		{
			_xmlWriter.WriteStartElement(reader.Prefix, reader.LocalName, reader.NamespaceURI);
			_xmlWriter.WriteAttributes(reader, false);
			
			XmlDocument doc = new XmlDocument(reader.NameTable);
			doc.LoadXml(reader.ReadOuterXml());
			TranslatePIPTransaction(doc.DocumentElement);
			doc.DocumentElement.WriteContentTo(_xmlWriter);
			
			_xmlWriter.WriteEndElement();
		}
		protected abstract void TranslatePIPTransaction(XmlElement doc);
		private XmlTextWriter _xmlWriter;
		protected object _PIPTransaction;
	}
}
