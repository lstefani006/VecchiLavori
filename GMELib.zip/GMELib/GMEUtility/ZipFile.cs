﻿#region Using directives

using System;
using System.Text;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

#endregion

namespace GME.Zip
{
	public class ZipFile
	{
		public static byte[] UnzipSingleFile(byte[] bz, out string fileNameOut)
		{
			MemoryStream strmMemIn = new MemoryStream(bz);
			ZipInputStream strmZipIn = new ZipInputStream(strmMemIn);
			MemoryStream strmMemOut = new MemoryStream();

			ZipEntry objEntry = strmZipIn.GetNextEntry();
			if (objEntry == null)
			{
				fileNameOut = null;
				return null;
			}

			fileNameOut = objEntry.Name;
			int i = 0;
			byte[] b = new byte[4096];
			do
			{
				i = strmZipIn.Read(b, 0, b.Length);
				if (i > 0)
					strmMemOut.Write(b, 0, i);
			}
			while (i > 0);
			strmMemOut.Flush();
			byte[] abyUnz = strmMemOut.ToArray();
			strmMemOut.Close();
			return abyUnz;
		}


		public static byte[] ZipSingleFile(string fileName, byte[] abyFileToZip)
		{
			MemoryStream strmZipOutFileMem = new MemoryStream();
			ZipOutputStream strmZipStream = new ZipOutputStream(strmZipOutFileMem);
			ZipEntry myZipEntry = new ZipEntry(fileName);

			strmZipStream.PutNextEntry(myZipEntry);
			strmZipStream.SetLevel(-1); //default compression

			strmZipStream.Write(abyFileToZip, 0, abyFileToZip.Length);
			strmZipStream.CloseEntry();

			strmZipStream.Finish();
			strmZipStream.Flush();

			strmZipStream.Close();

			return strmZipOutFileMem.ToArray();
		}



	}
}

