if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_GME_Certificate_DistributionPoints_GME_Certificate_CA]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[GME_Certificate_DistributionPoints] DROP CONSTRAINT FK_GME_Certificate_DistributionPoints_GME_Certificate_CA

GO

 

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_GME_Certificate_List_GME_Certificate_CA]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[GME_Certificate_List] DROP CONSTRAINT FK_GME_Certificate_List_GME_Certificate_CA

GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGME_GetCertificateData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGME_GetCertificateData]

GO

 

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GME_Certificate_CA]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GME_Certificate_CA]

GO

 

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GME_Certificate_DistributionPoints]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GME_Certificate_DistributionPoints]

GO

 

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GME_Certificate_List]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GME_Certificate_List]

GO

 

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GME_Certificate_RevocationList]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GME_Certificate_RevocationList]

GO

 

CREATE TABLE [dbo].[GME_Certificate_CA] (
      [Issuer] [varchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
      [Abilitata] [bit] NOT NULL ,
      [TSCRLUltimoDownloadTentato] [datetime] NULL ,
      [TSCRLDownloadConSuccesso] [datetime] NULL ,
      [TSCRLInizioValidita] [datetime] NULL ,
      [TSCRLFineValidita] [datetime] NULL 
) ON [PRIMARY]

GO

 

CREATE TABLE [dbo].[GME_Certificate_DistributionPoints] (
      [Issuer] [varchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
      [Url] [varchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
      [Abilitato] [bit] NOT NULL 
) ON [PRIMARY]

GO

 

CREATE TABLE [dbo].[GME_Certificate_List] (
      [Issuer] [varchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
      [SerialNumber] [varchar] (64) COLLATE Latin1_General_CI_AS NOT NULL ,
      [Subject] [varchar] (512) COLLATE Latin1_General_CI_AS NULL ,
      [Autenticazione] [bit] NOT NULL ,
      [Firma] [bit] NOT NULL ,
      [TSInizioValidita] [datetime] NOT NULL ,
      [TSFineValidita] [datetime] NOT NULL ,
      [TSRegistrazione] [datetime] NOT NULL ,
      [CodiceUtenteRegistrazione] [varchar] (16) COLLATE Latin1_General_CI_AS NOT NULL ,
      [AbilitatoAutenticazione] [bit] NOT NULL ,
      [AbilitatoFirma] [bit] NOT NULL ,
      [ForceAction] [varchar] (64) COLLATE Latin1_General_CI_AS NOT NULL ,
      [LastError] [varchar] (256) COLLATE Latin1_General_CI_AS NULL 
) ON [PRIMARY]

GO

 

CREATE TABLE [dbo].[GME_Certificate_RevocationList] (
      [Issuer] [varchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
      [SerialNumber] [varchar] (64) COLLATE Latin1_General_CI_AS NOT NULL ,
      [ReasonCode] [int] NOT NULL ,
      [TSRevoca] [datetime] NULL 
) ON [PRIMARY]

GO

 

ALTER TABLE [dbo].[GME_Certificate_CA] WITH NOCHECK ADD 
      CONSTRAINT [PK_GME_Certificate_CA] PRIMARY KEY  CLUSTERED 
      (
            [Issuer]
      )  ON [PRIMARY] 

GO

 

ALTER TABLE [dbo].[GME_Certificate_DistributionPoints] WITH NOCHECK ADD 
      CONSTRAINT [PK_GME_Certificate_DistributionPoints] PRIMARY KEY  CLUSTERED 
      (
            [Issuer],
            [Url]
      )  ON [PRIMARY] 

GO

 

ALTER TABLE [dbo].[GME_Certificate_List] WITH NOCHECK ADD 
      CONSTRAINT [PK_GME_Certificate_List] PRIMARY KEY  CLUSTERED 
      (
            [Issuer],
            [SerialNumber]
      )  ON [PRIMARY] 

GO

 

ALTER TABLE [dbo].[GME_Certificate_RevocationList] WITH NOCHECK ADD 
      CONSTRAINT [PK_GME_Certificate_RevocationList] PRIMARY KEY  CLUSTERED 
      (
            [Issuer],
            [SerialNumber]
      )  ON [PRIMARY] 

GO

 

ALTER TABLE [dbo].[GME_Certificate_DistributionPoints] ADD 
      CONSTRAINT [FK_GME_Certificate_DistributionPoints_GME_Certificate_CA] FOREIGN KEY 
      (
            [Issuer]
      ) REFERENCES [dbo].[GME_Certificate_CA] (
            [Issuer]
      )

GO

 

ALTER TABLE [dbo].[GME_Certificate_List] ADD 
      CONSTRAINT [FK_GME_Certificate_List_GME_Certificate_CA] FOREIGN KEY 
      (
            [Issuer]
      ) REFERENCES [dbo].[GME_Certificate_CA] (
            [Issuer]
      )

GO


CREATE PROCEDURE spGME_GetCertificateData 
      @Issuer          varchar(256),
      @sn              varchar(64)
AS
 

-- declare 
--    @Issuer                    varchar(256),
--    @sn                        varchar(64)

select
CL.ForceAction                CertificatoForceAction,
CL.TSFineValidita             CertificatoFineValidita,
-- indicano il tipo di certificato
CL.Autenticazione             CertificatoAutenticazione,
CL.Firma                      CertificatoFirma,
-- indicano se l'amm. abilita o no la funzionalita`
-- si firma o di autenticazione
CL.AbilitatoFirma             CertificatoAbilitatoFirma,
CL.AbilitatoAutenticazione    CertificatoAbilitatoAutenticazione,
CL.CodiceUtenteRegistrazione  CertificatoCodiceUtenteRegistrazione,

CA.Abilitata                  CAAbilitata,
CA.TSCRLUltimoDownloadTentato CATSCRLUltimoDownloadTentato,
CA.TSCRLDownloadConSuccesso   CATSCRLDownloadConSuccesso,
CA.TSCRLInizioValidita        CATSCRLInizioValidita,   
CA.TSCRLFineValidita          CATSCRLFineValidita,

CRL.ReasonCode                CRLReasonCode,
CRL.TSRevoca                  CRLTSRevoca,
IsNull(DP.NDP,0)              NumeroPuntiDiDistribuzione

from GME_Certificate_List CL
left outer join
(
      select Issuer, count(*) NDP 
      from GME_Certificate_DistributionPoints 
      where Abilitato=1
      group by Issuer
) DP
on CL.Issuer = DP.Issuer

inner join GME_Certificate_CA CA
on CA.Issuer = CL.Issuer

left outer join GME_Certificate_RevocationList CRL
on CRL.Issuer = CL.Issuer
and CRL.SerialNumber = CL.SerialNumber

where 
CL.SerialNumber = @sn
and CL.Issuer = @issuer

 

GO

 

 
