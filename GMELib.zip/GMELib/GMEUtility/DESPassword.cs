using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;

namespace GME
{
	/// <summary>
	/// Codifica e decodifica una stringa usando l'algoritmo DES.
	/// </summary>
	public class DESPassword
	{
		private DESCryptoServiceProvider des;
		private byte[] key;

		/// <summary>
		/// Costruttore di default. 
		/// Imposta la chiave di codifica/decodifica, la modalita` di cifra
		/// e il paddingMode di default.
		/// </summary>
		public DESPassword()
		{
			des = new DESCryptoServiceProvider();

			this.key = Encoding.UTF8.GetBytes("LAKUDJEU");
			des.Mode = CipherMode.ECB;
			des.Padding = PaddingMode.Zeros;
		}

		/// <summary>
		/// Codifica una stringa con l'algoritmo DES.
		/// </summary>
		/// <param name="stringToEncrypt">La stringa da codificare</param>
		/// <returns>La stringa codificata in formato esadecimale</returns>
		public string Encrypt (string stringToEncrypt)
		{
			byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream (ms, des.CreateEncryptor(key, null), CryptoStreamMode.Write);
			cs.Write(inputByteArray, 0, inputByteArray.Length );
			cs.FlushFinalBlock();
			return ConvertBinaryToHexString(ms.ToArray());
		}

		/// <summary>
		/// Decodifica una stringa con l'algoritmo DES, togliendo eventuali caratteri '\0' di
		/// padding
		/// </summary>
		/// <param name="stringToDecrypt">La stringa da decodificare in formato esadecimale</param>
		/// <returns>La stringa decodificata</returns>
		public string Decrypt (string stringToDecrypt)
		{
			byte[] inputByteArray = ConvertHexStringToBinary(stringToDecrypt);
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream (ms, des.CreateDecryptor(key, null), CryptoStreamMode.Write);
			cs.Write(inputByteArray, 0, inputByteArray.Length );
			cs.FlushFinalBlock();
			string sz = Encoding.UTF8.GetString(ms.ToArray());
			//
			// rimuove i caratteri '\0' dalla stringa 
			// L'encrypt e' fatto di solito con carattere '\0' di padding, e il decrypt
			// ritorna una stringa con gli stessi caratteri '\0' di padding, che ovviamente
			// e' meglio rimuovere 
			//
			string szTrimmed =  sz.TrimEnd('\0');
			return szTrimmed;

		}

	
		protected static string ConvertBinaryToHexString (byte[] bData)
		{
			StringBuilder sHex = new StringBuilder(2 * bData.Length);
			for (int i=0; i<bData.Length; i++)
				sHex.AppendFormat("{0:X2}", bData[i]);
			return sHex.ToString();
		}

		protected static byte[] ConvertHexStringToBinary (string sData)
		{
			int iByte = sData.Length/2;
			byte [] bytevar = new byte[iByte];
			for (int i=0; i<iByte; i++)
				bytevar[i] = Convert.ToByte(sData.Substring(i*2,  2), 16);
			return bytevar;
		}


//		DISCONTINUED
//		protected static string ConvertASCIIToHex(byte[] lpData)
//		{
//			string lpszOutput = string.Empty;
//			int wInpLen = lpData.Length;
//			for (int i = 0; i< wInpLen; i++)
//			{
//				/* First nibble */
//				byte byData = (byte)(lpData[i]/16);
//				if (byData < 10)
//					lpszOutput += (char)(byData + '0');
//				else
//					lpszOutput += (char)(byData - 10 + 'A');
//
//				/* Second nibble */
//				byData = (byte)(lpData[i]%16);
//				if (byData < 10)
//					lpszOutput += (char)(byData + '0');
//				else
//					lpszOutput += (char)(byData - 10 + 'A');
//			}
//			return lpszOutput;
//		}


//		DISCONTINUED
//		protected static byte[] ConvertHexToASCII( string lpszData)
//		{
//			int wBufLen = lpszData.Length;
//			byte[] lpOutput = new byte[8];
//
//			/* Input string must be  a multiple of 16 to be valid */
//			if ((wBufLen % 16)!=0)
//				return null;
//
//			for (int i = 0; i < wBufLen; i++)
//			{
//				byte byData = 0x00;
//
//				/* High nibble */
//				if ((lpszData[i] >= '0') && (lpszData[i] <= '9'))
//					byData = (byte)(lpszData[i] - '0');
//				if ((lpszData[i] >= 'A') && (lpszData[i] <= 'F'))
//					byData = (byte)(lpszData[i] - 'A' + 10);
//				lpOutput[i/2] = (byte)(byData << 4);
//
//				i++;
//
//				/* Second nibble */
//				if ((lpszData[i] >= '0') && (lpszData[i] <= '9'))
//					byData = (byte)(lpszData[i] - '0');
//				if ((lpszData[i] >= 'A') && (lpszData[i] <= 'F'))
//					byData = (byte)(lpszData[i] - 'A' + 10);
//				lpOutput[i/2] |= byData;
//			}
//			return lpOutput;
//		}
	}
}
