using System;
using System.Data.SqlClient;
using GME.BL;
using GME.Utility;
using System.Diagnostics;

namespace GME.BS
{
	/// <summary>
	/// Summary description for BatchStatus.
	/// </summary>
	///
	public class BatchStatus : BLBase, IBatchStatus
	{

		private System.ComponentModel.IContainer components = null; 
		internal SqlConnection cn;
		internal SqlCommand cmdInsertQueue;
		internal SqlCommand cmdUpdateStart;
		internal SqlCommand cmdUpdateEnd;
		internal SqlCommand cmdDeleteBatchStatus;
		internal SqlCommand cmdSelectBatchDelGiorno;
		internal SqlCommand cmdUpdateProgress;
		internal SqlDataAdapter daBatchDelGiorno;


		public BatchStatus():base() 
		{ 
			InitializeComponent(); 
		} 

		protected override void Dispose(bool disposing) 
		{ 
			if (disposing) 
			{ 
				if (!((components == null))) 
				{ 
					components.Dispose(); 
				} 
			} 
			base.Dispose(disposing); 
		} 
		[System.Diagnostics.DebuggerStepThrough()] 
		private void InitializeComponent() 
		{
			this.cn = new System.Data.SqlClient.SqlConnection();
			this.cmdUpdateStart = new System.Data.SqlClient.SqlCommand();
			this.cmdUpdateEnd = new System.Data.SqlClient.SqlCommand();
			this.cmdInsertQueue = new System.Data.SqlClient.SqlCommand();
			this.cmdSelectBatchDelGiorno = new System.Data.SqlClient.SqlCommand();
			this.daBatchDelGiorno = new System.Data.SqlClient.SqlDataAdapter();
			this.cmdDeleteBatchStatus = new System.Data.SqlClient.SqlCommand();
			this.cmdUpdateProgress = new System.Data.SqlClient.SqlCommand();
			// 
			// cn
			// 
			this.cn.ConnectionString = "workstation id=BILSVR2;packet size=4096;user id=MeSDtSql_user;data source=BILSVR2" +
				";persist security info=False;initial catalog=MeSDtSql";
			// 
			// cmdUpdateStart
			// 
			this.cmdUpdateStart.CommandText = "UPDATE dbo.BatchStatus SET Status = @Status, TSStart = GETDATE() WHERE (BatchId =" +
				" @BatchId)";
			this.cmdUpdateStart.Connection = this.cn;
			this.cmdUpdateStart.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.VarChar, 1, "Status"));
			this.cmdUpdateStart.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BatchId", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "BatchId", System.Data.DataRowVersion.Original, null));
			// 
			// cmdUpdateEnd
			// 
			this.cmdUpdateEnd.CommandText = "UPDATE dbo.BatchStatus SET TSEnd = GETDATE(), Status = @Status, TSModifica = GETD" +
				"ATE() WHERE (BatchId = @BatchId)";
			this.cmdUpdateEnd.Connection = this.cn;
			this.cmdUpdateEnd.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.VarChar, 1, "Status"));
			this.cmdUpdateEnd.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BatchId", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "BatchId", System.Data.DataRowVersion.Original, null));
			// 
			// cmdInsertQueue
			// 
			this.cmdInsertQueue.CommandText = "INSERT INTO dbo.BatchStatus (BatchId, Status, TSQueue, Description, BatchCode, TS" +
				"DataFlusso, OperatorId, UserId) VALUES (@BatchId, @Status, @TSQueue, @Descriptio" +
				"n, @BatchCode, @TSDataFlusso, @OperatorId, @UserId)";
			this.cmdInsertQueue.Connection = this.cn;
			this.cmdInsertQueue.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BatchId", System.Data.SqlDbType.VarChar, 32, "BatchId"));
			this.cmdInsertQueue.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.VarChar, 1, "Status"));
			this.cmdInsertQueue.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSQueue", System.Data.SqlDbType.DateTime, 8, "TSQueue"));
			this.cmdInsertQueue.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Description", System.Data.SqlDbType.VarChar, 256, "Description"));
			this.cmdInsertQueue.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BatchCode", System.Data.SqlDbType.VarChar, 10, "BatchCode"));
			this.cmdInsertQueue.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSDataFlusso", System.Data.SqlDbType.DateTime, 4, "TSDataFlusso"));
			this.cmdInsertQueue.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OperatorId", System.Data.SqlDbType.VarChar, 16, "OperatorId"));
			this.cmdInsertQueue.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UserId", System.Data.SqlDbType.VarChar, 16, "UserId"));
			// 
			// cmdSelectBatchDelGiorno
			// 
			this.cmdSelectBatchDelGiorno.CommandText = @"SELECT BatchId, Status, TSQueue, BatchCode, Description, TSStart, TSEnd, Progress, TSModifica, TSDataFlusso FROM dbo.BatchStatus WHERE (TSDataFlusso = @d) OR (TSDataFlusso IS NULL) AND (CONVERT(datetime, CONVERT(varchar, TSQueue, 112)) = @q) ORDER BY TSQueue";
			this.cmdSelectBatchDelGiorno.Connection = this.cn;
			this.cmdSelectBatchDelGiorno.Parameters.Add(new System.Data.SqlClient.SqlParameter("@d", System.Data.SqlDbType.DateTime, 4, "TSDataFlusso"));
			this.cmdSelectBatchDelGiorno.Parameters.Add(new System.Data.SqlClient.SqlParameter("@q", System.Data.SqlDbType.DateTime));
			// 
			// daBatchDelGiorno
			// 
			this.daBatchDelGiorno.SelectCommand = this.cmdSelectBatchDelGiorno;
			// 
			// cmdDeleteBatchStatus
			// 
			this.cmdDeleteBatchStatus.CommandText = "DELETE FROM dbo.BatchStatus WHERE (Status = \'E\') OR (Status = \'A\')";
			this.cmdDeleteBatchStatus.Connection = this.cn;
			// 
			// cmdUpdateProgress
			// 
			this.cmdUpdateProgress.CommandText = "UPDATE dbo.BatchStatus SET Progress = @Progress, TSModifica = GETDATE() WHERE (Ba" +
				"tchId = @BatchId)";
			this.cmdUpdateProgress.Connection = this.cn;
			this.cmdUpdateProgress.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Progress", System.Data.SqlDbType.VarChar, 256, "Progress"));
			this.cmdUpdateProgress.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BatchId", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "BatchId", System.Data.DataRowVersion.Original, null));

		}

		private string CreateNewId() 
		{
			return Guid.NewGuid().ToString("N").ToUpper();
		}
	   
		public string NewBatch(string BatchCode, string descr, DateTime tsDataFlusso, string OperId, string UserId) 
		{ 
			cn.ConnectionString = BLBase.SqlConnectionstring; 
			try 
			{ 
				cn.Open(); 
				string BatchId = CreateNewId(); 
				cmdInsertQueue.Parameters["@BatchId"].Value = BatchId; 
				cmdInsertQueue.Parameters["@Status"].Value = "Q"; 
				cmdInsertQueue.Parameters["@TSQueue"].Value = DateTime.Now; 
				cmdInsertQueue.Parameters["@Description"].Value = descr; 
				cmdInsertQueue.Parameters["@BatchCode"].Value = BatchCode; 
				if (tsDataFlusso == DateTime.MinValue) 
				{ 
					cmdInsertQueue.Parameters["@TSDataFlusso"].Value = System.DBNull.Value; 
				} 
				else 
				{ 
					cmdInsertQueue.Parameters["@TSDataFlusso"].Value = tsDataFlusso; 
				} 
				cmdInsertQueue.Parameters["@OperatorId"].Value = OperId; 
				cmdInsertQueue.Parameters["@UserId"].Value = UserId; 
				cmdInsertQueue.ExecuteNonQuery(); 
				return BatchId; 
			} 
			catch (Exception ex) 
			{ 
				smError(ex); 
				throw; 
			} 
			finally 
			{ 
				cn.Close(); 
			} 
		} 

		public void StartBatch(string BatchId) 
		{ 
			cn.ConnectionString = BLBase.SqlConnectionstring; 
			try 
			{ 
				cn.Open(); 
				this.cmdUpdateStart.Parameters["@Status"].Value = "R"; 
				this.cmdUpdateStart.Parameters["@BatchId"].Value = BatchId; 
				this.cmdUpdateStart.ExecuteNonQuery(); 
			} 
			catch (Exception ex) 
			{ 
				smError(ex); 
				throw; 
			} 
			finally 
			{ 
				cn.Close(); 
			} 
		} 

		public void EndBatch(string BatchId, bool aborted) 
		{ 
			cn.ConnectionString = SqlConnectionstring; 
			try 
			{ 
				cn.Open(); 
				string status; 
				if (aborted) 
				{ 
					status = "A"; 
				} 
				else 
				{ 
					status = "E"; 
				} 
				this.cmdUpdateEnd.Parameters["@Status"].Value = status; 
				this.cmdUpdateEnd.Parameters["@BatchId"].Value = BatchId; 
				this.cmdUpdateEnd.ExecuteNonQuery(); 
			} 
			catch (Exception ex) 
			{ 
				smError(ex); 
				throw; 
			} 
			finally 
			{ 
				cn.Close(); 
			} 
		} 

		public void UpdateProgress(string BatchId, string Progress) 
		{ 
			cn.ConnectionString = BLBase.SqlConnectionstring; 
			smTraceIf(GME.Log.smLogSwitch.TraceVerbose, Progress); 
			try 
			{ 
				cn.Open(); 
				this.cmdUpdateProgress.Parameters["@Progress"].Value = Progress; 
				this.cmdUpdateProgress.Parameters["@BatchId"].Value = BatchId; 
				this.cmdUpdateProgress.ExecuteNonQuery(); 
			} 
			catch (Exception ex) 
			{ 
				smError(ex); 
				throw; 
			} 
			finally 
			{ 
				cn.Close(); 
			} 
		} 

		public DS_BatchStatus QueryBatchDelGiorno(DateTime d) 
		{ 
			cn.ConnectionString = BLBase.SqlConnectionstring;
			try 
			{ 
				cn.Open(); 
				this.cmdSelectBatchDelGiorno.Parameters["@d"].Value = d.Date; 
				this.cmdSelectBatchDelGiorno.Parameters["@q"].Value = d.AddDays(-1); 
				DS_BatchStatus ds = new DS_BatchStatus(); 
				this.daBatchDelGiorno.Fill(ds.BatchStatus); 
				return ds; 
			} 
			catch (Exception ex) 
			{ 
				smError(ex); 
				throw; 
			} 
			finally 
			{ 
				cn.Close(); 
			} 
		} 

		public void DeleteBatchAE() 
		{ 
			cn.ConnectionString = BLBase.SqlConnectionstring; 
			try 
			{ 
				cn.Open(); 
				cmdDeleteBatchStatus.ExecuteNonQuery(); 
			} 
			catch (Exception ex) 
			{ 
				smError(ex); 
				throw; 
			} 
			finally 
			{ 
				cn.Close(); 
			} 
		} 
		public bool GetRefreshMode() 
		{ 
			return GME.Utility.AppSettings.ToBoolean("SetRefresh_String", false); 
		} 
	}
}
