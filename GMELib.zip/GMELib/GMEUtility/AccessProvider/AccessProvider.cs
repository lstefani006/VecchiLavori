﻿#region Using directives

using System;
using System.Text;
using System.ComponentModel;
using System.Collections;
using System.Configuration;
using GME.Web.ExtenderProvider;


#endregion


namespace GME.AccessProviderUtilities
{
	#region Access Expression parser

	internal class Lexer
	{
		public enum Token
		{
			and, or, var, lp, rp, not,
			error, eof
		}

		string _v;
		int _i;
		public Lexer(string v)
		{
			_v = v.ToUpper();
			_i = 0;
		}

		private char NextC
		{
			get
			{
				if (_i < _v.Length)
					return _v[_i];

				return '\0';
			}
		}

		StringBuilder _r = new StringBuilder();
		public string VarValue
		{
			get { return _r.ToString(); }
		}

		public Token Next()
		{
			_r = new StringBuilder();

			if (NextC == '\0')
				return Token.eof;

			while (NextC == ' ' || NextC == '\n' || NextC == '\r' || NextC == '\t')
				++_i;

			if (IsAlpha(NextC, false))
			{
				_r.Append(NextC);
				_i++;
				while (IsAlpha(NextC, true))
				{
					_r.Append(NextC);
					_i++;
				}

				return Token.var;
			}
			else if (NextC == '&')
			{
				_i++;
				return Token.and;
			}
			else if (NextC == '|')
			{
				_i++;
				return Token.or;
			}
			else if (NextC == '(')
			{
				_i++;
				return Token.lp;
			}
			else if (NextC == ')')
			{
				_i++;
				return Token.rp;
			}
			else if (NextC == '!')
			{
				_i++;
				return Token.not;
			}


			if (NextC == '\0')
				return Token.eof;

			return Token.error;
		}

		static bool IsAlpha(char c, bool includeNumbers)
		{
			if (includeNumbers)
				return c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_';
			else
				return c >= 'A' && c <= 'Z' || c == '_';

		}
	}

	internal class LexerLetturaAnticipata
	{
		Lexer _lexer;

		public LexerLetturaAnticipata(string r)
		{
			_lexer = new Lexer(r);

			_c = _lexer.Next();
			_cs = _lexer.VarValue;
		}

		public Lexer.Token Current { get { return _c; } }
		public string CurrentValue { get { return _cs; } }


		public Lexer.Token Read()
		{
			_c = _lexer.Next();
			_cs = _lexer.VarValue;

			return _c;
		}

		Lexer.Token _c;
		string _cs;
	}

	internal class Parser
	{
		LexerLetturaAnticipata _lex;
		public Parser()
		{
			_lex =  null;
			_e = null;
		}

		exprBase _e;

		public void Parse(string v)
		{
			_lex =  new LexerLetturaAnticipata(v);

			_e = expr();

			if (_lex.Current != Lexer.Token.eof)
				throw new ApplicationException("exptected eof");
		}

		public bool Evaluate(FunctionList h)
		{
			return _e.Evaluate(h);
		}

		public void BuildSymboltable(FunctionList h)
		{
			_e.BuildSymboltable(h);
		}

		private exprBase expr()
		{
			exprBase e = null;

			switch (_lex.Current)
			{
				case Lexer.Token.not:
				case Lexer.Token.lp:
				case Lexer.Token.var:
					e = f1();
					break;

				default:
					throw new ApplicationException("expected ( ! var");
			}

			while (_lex.Current == Lexer.Token.or)
			{
				_lex.Read();
				e = new exprOr(e, f1());
			}

			return e;
		}

		private exprBase f1()
		{
			exprBase e = f2();

			while (_lex.Current == Lexer.Token.and)
			{
				_lex.Read();
				e = new exprAnd(e, f2());
			}

			return e;
		}

		private exprBase f2()
		{
			exprBase e = null;

			switch (_lex.Current)
			{
				case Lexer.Token.not:
					_lex.Read();
					e = f2();
					e = new exprNot(e);
					break;

				case Lexer.Token.lp:
					_lex.Read();
					e = expr();

					if (_lex.Current != Lexer.Token.rp)
						throw new ApplicationException("expected )");

					_lex.Read();
					break;

				case Lexer.Token.var:
				{
					string s = _lex.CurrentValue;
					_lex.Read();

					e = new exprVar(s);
				}
					break;

				default:
					throw new ApplicationException("expected ! var (");
			}

			return e;
		}

		public static bool Eval(string accessExpr, FunctionList fl)
		{
			if (accessExpr == null || accessExpr.Length == 0)
				return true;

			try
			{
				Parser p = new Parser();
				p.Parse(accessExpr);

				FunctionList h = new FunctionList();
				p.BuildSymboltable(h);

				foreach (GME.FunctionListEntry en in fl)
					h[en.Key] = en.Value;

				return p.Evaluate(h);
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.Write(ex.Message);
			}

			return true;
		}
	}

	abstract class exprBase
	{
		public abstract bool Evaluate(FunctionList h);
		public abstract void BuildSymboltable(FunctionList h);
	}

	class exprVar : exprBase
	{
		public exprVar(string var)
		{
			_var = var;
		}
		public override bool Evaluate(FunctionList h)
		{
			if (h.ContainsKey(_var))
				return h[_var];

			throw new ApplicationException("Unknown var '" + _var + "'");
		}

		public override void BuildSymboltable(FunctionList h)
		{
			if (h.ContainsKey(_var))
				return;

			h[_var] = false;
		}

		string _var;
	}

	class exprNot : exprBase
	{
		public exprNot(exprBase e)
		{
			_e = e;
		}
		public override bool Evaluate(FunctionList h)
		{
			return ! _e.Evaluate(h);
		}
		public override void BuildSymboltable(FunctionList h)
		{
			_e.BuildSymboltable(h);
		}

		exprBase _e;
	}

	class exprAnd : exprBase
	{
		public exprAnd(exprBase e1, exprBase e2)
		{
			_e1 = e1;
			_e2 = e2;
		}
		public override bool Evaluate(FunctionList h)
		{
			return _e1.Evaluate(h) && _e2.Evaluate(h);
		}
		public override void BuildSymboltable(FunctionList h)
		{
			_e1.BuildSymboltable(h);
			_e2.BuildSymboltable(h);
		}

		exprBase _e1, _e2;
	}

	class exprOr : exprBase
	{
		public exprOr(exprBase e1, exprBase e2)
		{
			_e1 = e1;
			_e2 = e2;
		}
		public override bool Evaluate(FunctionList h)
		{
			return _e1.Evaluate(h) || _e2.Evaluate(h);
		}
		public override void BuildSymboltable(FunctionList h)
		{
			_e1.BuildSymboltable(h);
			_e2.BuildSymboltable(h);
		}


		exprBase _e1, _e2;
	}


	#endregion
}

/* Purtroppo e' stato un tentativo mal riuscito.
 * 
namespace GME.Web
{
	[ProvideProperty("AccessExpression", typeof(System.Web.UI.WebControls.WebControl))]
	public class WebAccessProvider : System.ComponentModel.Component, System.ComponentModel.IExtenderProvider
	{
		#region IExtenderProvider Members

		bool System.ComponentModel.IExtenderProvider.CanExtend(object extendee)
		{
			System.Web.UI.WebControls.WebControl cExtendee = extendee as System.Web.UI.WebControls.WebControl;
			if (!Engine.CanExtendControl (cExtendee))
				return false;
			else
				return true;
		}

		#endregion


		private FunctionList _FunctionList = null;
		private bool _UseWebConfig;

		/// <summary>
		/// La lista di funzioni abilitate per l'utente/operatore collegato.
		/// Ogni funzione e` una stringa associata ad un valore booleano.
		/// </summary>
		[Browsable(false)]
		public FunctionList FunctionList
		{
			get 
			{ 
				if (_FunctionList == null)
					_FunctionList = new FunctionList();
				return _FunctionList; 
			}
			set { _FunctionList = value; }
		}

		/// <summary>
		/// Per impostare il valore delle variabili associate all'operatore/utente.
		/// </summary>
		public bool this [string var]
		{
			get { return FunctionList[var]; }
			set { FunctionList[var] = value; }
		}

		[Browsable(true)]
		[DefaultValue(false)]
		[Description("UseWebConfig e` true se l'espressione da valutare e` nel web.config alla chiave AccessExpression")]
		public bool UseWebConfig
		{
			get { return _UseWebConfig; }
			set { _UseWebConfig = value; }
		}

		/// <summary>
		/// Cambia l'espressione associata al controllo.
		/// </summary>
		/// <param name="c">il controllo</param>
		/// <param name="v">la nuova espressione</param>
		public void SetAccessExpression(System.Web.UI.WebControls.WebControl c, string v)
		{
			Engine.SetControlPropertyValue(c, "AccessExpression", v, v.Length == 0);
		}

		/// <summary>
		/// ritorna l'espressione associata al controllo
		/// </summary>
		/// <param name="c">il controllo di cui si vuole ottenere l'espressione</param>
		/// <returns>l'espressione associata al controllo</returns>
		public string GetAccessExpression(System.Web.UI.WebControls.WebControl c)
		{
			return (string)Engine.GetControlPropertyValue(c, "AccessExpression", string.Empty);
		}

		protected void InitializeHandlers()
		{
			foreach (System.Web.UI.Control c in Engine.ControlsWithValue("AccessExpression"))
			{
				//c.PreRender += new EventHandler(OnWebControlPreRender);
				c.Load += new EventHandler(OnWebControlPreRender);
			}
		}

		private void OnWebControlPreRender(object sender, EventArgs e)
		{
			if (FunctionList == null || FunctionList.Count == 0)
				return;

			System.Web.UI.WebControls.WebControl wc = (System.Web.UI.WebControls.WebControl) sender;

			string expr = GetAccessExpression(wc);
			if (expr == null || expr.Length == 0)
				return;
			
			if (UseWebConfig)
				expr = GME.Utility.AppSettings.ToString(expr);

			if (expr == null || expr.Length == 0)
				return;

			wc.Enabled = GME.AccessProviderUtilities.Parser.Eval(expr, FunctionList);
		}



		/// <summary>
		/// Data una espressione booleana e la lista di funzionalita`
		/// calcola il valore dell'espressione
		/// </summary>
		/// <param name="accessExpr">stringa che contiene l'espressione</param>
		/// <param name="fl">lista delle variabile piu` relativo valore booleano</param>
		/// <returns>il valore booleano che si ottiene interpretando l'espressione</returns>
		public static bool EvalExpression(string accessExpr, FunctionList fl)
		{
			if (accessExpr == null || accessExpr.Length == 0)
				return true;

			if (fl == null)
				return true;

			return GME.AccessProviderUtilities.Parser.Eval(accessExpr, fl);
		}

		#region Visual Studio hacks
		/// <summary>
		/// Saves all values of the provided properties for all controls, serialized
		/// in a base64-encoded in a string.
		/// </summary>
		/// <remarks>
		/// We need this because Visual Studio does not save the provided properties correctly.
		/// The name of this property is not important.
		/// <seealso cref="ExtenderProviderEngine.PropertyData"/>
		/// </remarks>
		[Browsable(false)]
		public string PropertyData
		{
			get
			{
				if (_Engine == null)
					return null;
				else
					return _Engine.PropertyData;
			}
			set
			{
				if (value == null)
					_Engine = null;
				else
				{
					_Engine = null;
					Engine.PropertyData = value;
				}
			}
		}

		/// <summary>
		/// The page or user control that is being designed
		/// </summary>
		/// <remarks>
		/// If any controls are extended, Visual Studio adds a line to the InitializeComponents, 
		/// after an assignment to <see cref="PropertyData"/>:
		/// <code>
		/// this.<i>MyExtenderProvider1</i>.VSDesigned = this;
		/// </code>
		/// The name of this property is not important.
		/// <seealso cref="ExtenderProviderEngine.VSDesigned"/>
		/// </remarks>
		[Browsable(false)]
		public System.Web.UI.Control VSDesigned
		{
			get
			{
				if (_Engine == null)
				{
					return null;
				}
				else
				{
					return Engine.VSDesigned;
				}
			}
			set
			{
				if (_Engine != null && value != null)
				{
					Engine.VSDesigned = value;
				}
			}
		}


		protected ExtenderProviderEngine Engine
		{
			get
			{
				if (_Engine == null)
				{
					_Engine = new ExtenderProviderEngine(this, Site);
					_Engine.InitialiseHandlers += new ExtenderProviderEngine.InitialiseHandlersHandler(InitializeHandlers);
				}
				return _Engine;
			}
		}
		private ExtenderProviderEngine _Engine;

		#endregion

	}
}
*/

namespace GME.Web
{
	public class WebAccessProvider
	{
		private FunctionList _FunctionList = null;

		/// <summary>
		/// La lista di funzioni abilitate per l'utente/operatore collegato.
		/// Ogni funzione e` una stringa associata ad un valore booleano.
		/// </summary>
		public FunctionList FunctionList
		{
			get 
			{ 
				if (_FunctionList == null)
					_FunctionList = new FunctionList();
				return _FunctionList; 
			}
			set { _FunctionList = value; }
		}

		/// <summary>
		/// Per impostare il valore delle variabili associate all'operatore/utente.
		/// </summary>
		public bool this [string var]
		{
			get { return FunctionList[var]; }
			set { FunctionList[var] = value; }
		}

		public bool EvaluateExpression(string expr)
		{
			if (FunctionList == null || FunctionList.Count == 0)
				return true;

			if (expr == null || expr.Length == 0)
				return true;
			
			return GME.AccessProviderUtilities.Parser.Eval(expr, FunctionList);
		}

		/// <summary>
		/// Data una espressione booleana e la lista di funzionalita`
		/// calcola il valore dell'espressione
		/// </summary>
		/// <param name="accessExpr">stringa che contiene l'espressione</param>
		/// <param name="fl">lista delle variabile piu` relativo valore booleano</param>
		/// <returns>il valore booleano che si ottiene interpretando l'espressione</returns>
		public static bool EvalExpression(string accessExpr, FunctionList fl)
		{
			if (accessExpr == null || accessExpr.Length == 0)
				return true;

			if (fl == null)
				return true;

			return GME.AccessProviderUtilities.Parser.Eval(accessExpr, fl);
		}
	}
}


namespace GME.WinForms
{
	[ProvideProperty("AccessExpression", typeof(System.Windows.Forms.Control))]
	public class WinAccessProvider : System.ComponentModel.Component, System.ComponentModel.IExtenderProvider
	{
		#region IExtenderProvider Members

		bool System.ComponentModel.IExtenderProvider.CanExtend(object extendee)
		{
			System.Windows.Forms.Control cExtendee = extendee as System.Windows.Forms.Control;

			if (cExtendee == null)
				return false;

			if (cExtendee is System.Windows.Forms.Form)
				return false;

			return true;
		}

		#endregion


		private FunctionList _FunctionList = new FunctionList();
		private bool _UseAppConfig;
		private Hashtable _h = new Hashtable();

		
		/// <summary>
		/// La lista di funzioni abilitate per l'utente/operatore collegato.
		/// Ogni funzione e` una stringa associata ad un valore booleano.
		/// </summary>
		[Browsable(false)]
		public FunctionList FunctionList
		{
			get 
			{ 
				if (_FunctionList == null)
					_FunctionList = new FunctionList();
				return _FunctionList;
			}
			//set { _FunctionList = value; RefreshAllControls(); }
		}

		/// <summary>
		/// Per impostare/leggere il valore delle variabili associate all'operatore/utente
		/// Quando si imposta il valore ad una variabile, l'extender provider automaticamente
		/// rinfresca tutti i controlli.
		/// </summary>
		public bool this [string var]
		{
			get { return FunctionList[var]; }
			set { FunctionList[var] = value; RefreshAllControls(); }
		}

		[Browsable(true)]
		[DefaultValue(false)]
		[Description("UseAppConfig e` true se l'espressione da valutare e` nel app.config alla chiave AccessExpression")]
		public bool UseAppConfig
		{
			get { return _UseAppConfig; }
			set { _UseAppConfig = value; }
		}

		/// <summary>
		/// Imposta una nuova espressione ad un controllo.
		/// Il controllo viene aggiornato automaticamente.
		/// Se v e` "" o null il controllo viene rimosso dall'access provider.
		/// </summary>
		/// <param name="c">il controllo</param>
		/// <param name="v">la nuova espressione</param>
		public void SetAccessExpression(System.Windows.Forms.Control c, string v)
		{
			if (v == null) 
				v = string.Empty;

			if (v.Length == 0 && _h.ContainsKey(c))
			{
				_h.Remove(c);

				// remove handler
			}
			else if (v.Length > 0)
			{
				if (!_h.ContainsKey(c))
				{
					// add handler
				}

				_h[c] = v;
				EnableControl(c);
			}
		}

		/// <summary>
		/// Ritorna l'espressione associata al controllo.
		/// </summary>
		/// <param name="c">il controllo</param>
		/// <returns>l'espressione associata al controllo</returns>
		public string GetAccessExpression(System.Windows.Forms.Control c)
		{
			object v = _h[c];
			if (v != null)
				return (string)v;
			else
				return string.Empty;
		}

		private void EnableControl(System.Windows.Forms.Control c)
		{
			if (FunctionList == null || FunctionList.Count == 0)
				return;

			if (_h.ContainsKey(c) == false)
				return;

			string expr = GetAccessExpression(c);
			if (expr == null || expr.Length == 0)
				return;
			
			if (UseAppConfig)
				expr = GME.Utility.AppSettings.ToString(expr);

			if (expr == null || expr.Length == 0)
				return;

			c.Enabled = GME.AccessProviderUtilities.Parser.Eval(expr, FunctionList);
		}

		/// <summary>
		/// Rinfresca tutti i controlli associati all'access provider.
		/// </summary>
		public void RefreshAllControls()
		{
			foreach (System.Windows.Forms.Control c in _h.Keys)
				EnableControl(c);
		}



		/// <summary>
		/// Data una espressione booleana e la lista di funzionalita`
		/// calcola il valore dell'espressione
		/// </summary>
		/// <param name="accessExpr">stringa che contiene l'espressione</param>
		/// <param name="fl">lista delle variabile piu` relativo valore booleano</param>
		/// <returns>il valore booleano che si ottiene interpretando l'espressione</returns>
		public static bool EvalExpression(string accessExpr, FunctionList fl)
		{
			if (accessExpr == null || accessExpr.Length == 0)
				return true;

			if (fl == null)
				return true;

			return GME.AccessProviderUtilities.Parser.Eval(accessExpr, fl);
		}
	}
}

