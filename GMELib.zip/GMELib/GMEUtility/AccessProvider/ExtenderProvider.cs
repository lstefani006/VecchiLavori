using System;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Permissions;

namespace GME.Web.ExtenderProvider
{
  /// <summary>
  /// The <c>ExtenderProviderEngine</c> class manages the values of the
  /// provided properties and contains code to (de)serialize the data.
  /// </summary>
  public class ExtenderProviderEngine
  {
    #region LifeCycleStage steps
    /// <summary>
    /// Creates the object. We need the component (or control) and site
    /// to inform Visual Studio of changes in the properties.
    /// </summary>
    /// <param name="AComponent"><c>this</c> for the component or control</param>
    /// <param name="ASite"><c>this.Site</c> for the component or control</param>
    public ExtenderProviderEngine (object AComponent, ISite ASite)
    {
      _Component = AComponent;
      _Site = ASite;
      if (_Site == null || !_Site.DesignMode)
      {
        _Stage = LifeCycleStage.Initialized;
      }
      else
      {
        _Stage = LifeCycleStage.DesignMode;
      }
    }
    /// <summary>Component or control that owns this collection</summary>
    private object _Component;
    /// <summary>Interface to designer stuff</summary>
    private ISite _Site;

    /// <summary>
    /// Lists the stages in the lifetime of this object
    /// </summary>
    private enum LifeCycleStage
    {
      /// <summary>The object lives in Visual Studio</summary>
      DesignMode,
      /// <summary>The object has been constructed in InitializeComponents</summary>
      Initialized,
      /// <summary>The property values have been set via <see cref="ExtenderProviderEngine.PropertyData"/></summary>
      PropertyDataLoaded,
      /// <summary>The <see cref="ExtenderProviderEngine.VSDesigned"/> property has been assigned and we are not in Visual Studio</summary>
      RunTime
    }
    /// <summary>
    /// Indicates that the object was created in the deserialization process and that
    /// the keys in the <see cref="PropertyValue"/> objects are still the control
    /// names.
    /// </summary>
    private LifeCycleStage _Stage;

    /// <summary>
    /// Make sure that all keys that reference controls are no longer 
    /// <see cref="System.Web.UI.Control.UniqueID"/>s (as they are in
    /// the serialized version of this object), but point to the contro
    /// instances.
    /// </summary>
    private void ReplaceKeys ()
    {
      if (_Stage == LifeCycleStage.PropertyDataLoaded && VSDesigned != null)
      {
        if (_Site != null && _Site.DesignMode)
        {
          _Stage = LifeCycleStage.DesignMode;
        }
        else
        {
          _Stage = LifeCycleStage.RunTime;
        }
        if (_PropertyList != null && _PropertyList.HasItems)
        {
          foreach (PropertyValue psl in _PropertyList.Items.Values)
          {
            psl.ReplaceKeys (this);
          }
        }
        if (_Stage == LifeCycleStage.RunTime && InitialiseHandlers != null)
        {
          InitialiseHandlers ();
        }
      }
    }

    /// <summary>Delegate for the <see cref="InitialiseHandlers"/> event</summary>
    public delegate void InitialiseHandlersHandler ();
    /// <summary> Event generated at runtime after all property values have been loaded.</summary>
    public event InitialiseHandlersHandler InitialiseHandlers;

    /// <summary>
    /// Checks for the <see cref="VSDesigned"/> control, starting from that one
    /// or one of its child controls
    /// </summary>
    private void CheckVSDesigned (System.Web.UI.Control AExtendee)
    {
      if (_VSDesigned == null && AExtendee != null)
      {
        if (_Stage == LifeCycleStage.DesignMode)
        {
          // If we walk the parent/child hierarchy from AExtendee to Page, at some
          // point we arrive at a control that is declared as a component of the designed
          // control. if we continue towards the Page, the last control that still is 
          // a component is the designed control
          for (System.Web.UI.Control cComponent = AExtendee; cComponent != null; cComponent = cComponent.Parent)
          {
            if (cComponent.Site != null && cComponent.Site.Name.Length > 0)
            {
              _VSDesigned = cComponent;
            }
          }
          if (_VSDesigned != null)
          {
            NotifyDesignerOfChange ();
          }
        }
        else if (_Stage != LifeCycleStage.RunTime)
        {
          // This must be a SetXXX line in InitializeComponents - why was VSDesigned not set?
          VSDesigned = AExtendee;
        }
      }
    }
    #endregion

    #region IExtenderProvider implementation support
    /// <summary>
    /// Call this method in the IExtenderProvider implementation to vreify
    /// that a control can be extended with the provided properties.
    /// </summary>
    /// <param name="AExtendee">Control to be extended</param>
    /// <returns>When <c>false</c> the control cannot be extended,
    /// when <c>true</c> it's up to the IExtenderProvider implementator.</returns>
    public bool CanExtendControl (System.Web.UI.Control AExtendee)
    {
      if (AExtendee == null)
      {
        return false;
      }
      else
      {
        if (VSDesigned == null) CheckVSDesigned (AExtendee);
        if (_Component is System.Web.UI.Control && AExtendee == _Component)
        {
          return false;
        }
        return (AExtendee != VSDesigned);
      }
    }
    #endregion

    #region Access to provided property values
    /// <summary>
    /// Retrieves the value for the provided property for a control.
    /// </summary>
    /// <param name="AExtendee">Control to be extended</param>
    /// <param name="APropertyName">Name of the provided property</param>
    /// <param name="ADefault">The default value for this property</param>
    public object GetControlPropertyValue (System.Web.UI.Control AExtendee, string APropertyName, object ADefault)
    {
      if (VSDesigned == null) CheckVSDesigned (AExtendee);
      if (_PropertyList != null)
      {
        PropertyValue pv = (PropertyValue )_PropertyList.Items[APropertyName];
        if (pv != null)
        {
          return pv.GetControlPropertyValue (AExtendee, ADefault);
        }
      }
      return ADefault;
    }
    
    /// <summary>
    /// Sets the value for the provided property for a control.
    /// </summary>
    /// <param name="AExtendee">Control to be extended</param>
    /// <param name="APropertyName">Name of the provided property</param>
    /// <param name="AValue">The value for this property</param>
    /// <param name="AIsDefault"><c>true</c> if the value is the default for this property</param>
    /// <returns><c>false</c> if the property value definitely has not changed</returns>
    public void SetControlPropertyValue (System.Web.UI.Control AExtendee, string APropertyName, object AValue, bool AIsDefault)
    {
      if (VSDesigned == null) CheckVSDesigned (AExtendee);
      // Ignore all SetXXX actions unless fully initialised
      if (_Stage == LifeCycleStage.RunTime || _Stage == LifeCycleStage.DesignMode)
      {
        if (_PropertyList == null)
        {
          if (AIsDefault) return; // No need to store default values
          _PropertyList = new NamedKeyCollection ();
        }
        if (AIsDefault && !_PropertyList.ContainsKey (APropertyName)) return;
        PropertyValue pv = (PropertyValue )_PropertyList.Items[APropertyName];
        if (pv == null)
        {
          pv = new PropertyValue (this);
          _PropertyList.Items.Add (APropertyName, pv);
        }
        if (pv.SetControlPropertyValue (AExtendee, AValue, AIsDefault))
        {
          NotifyDesignerOfChange ();
        }
      }
    }

    /// <summary>
    /// Indicates whether there are controls that specify non-default values for the property.
    /// </summary>
    /// <param name="APropertyName">Name of the property</param>
    public bool PropertyHasValues (string APropertyName)
    {
      if (_PropertyList == null || !_PropertyList.HasItems)
      {
        return false;
      }
      else
      {
        PropertyValue pv = (PropertyValue )_PropertyList.Items[APropertyName];
        return (pv != null && pv.HasItems);
      }
    }

    /// <summary>
    /// Returns a <see cref="ICollection"/> interface to the controls that have
    /// a non-default value for a particular property.
    /// </summary>
    public ICollection ControlsWithValue (string APropertyName)
    {
      if (_PropertyList != null && _PropertyList.HasItems)
      {
        PropertyValue pv = (PropertyValue )_PropertyList.Items[APropertyName];
        if (pv != null && pv.HasItems)
        {
          return pv.Items.Keys;
        }
      }  
      return new ArrayList ();
    }

    /// <summary>
    /// Returns a <see cref="ICollection"/> interface the controls that have
    /// a non-default value for a any property.
    /// </summary>
    public ICollection ControlsWithValue ()
    {
      Hashtable htControls = new Hashtable ();
      if (_PropertyList != null && _PropertyList.HasItems)
      {
        foreach (PropertyValue pv in _PropertyList.Items.Values)
        {
          if (pv.HasItems)
          {
            foreach (System.Web.UI.Control c in pv.Items.Keys)
            {
              htControls[c] = true;
            }
          }
        }
      }  
      return htControls.Keys;
    }

    /// <summary>
    /// Are there any non-default property values?
    /// </summary>
    public bool HasPropertyData
    {
      get
      {
        if (_PropertyList != null && _PropertyList.HasItems)
        {
          foreach (PropertyValue pv in _PropertyList.Items.Values)
          {
            if (pv.HasItems) return true;
          }
        }  
        return false;
      }
    }
    #endregion

    #region Provided property value storage

    #region NamedKeyCollection
    /// <summary>
    /// <c>NamedKeyCollection</c> is essentially a hash table that can be serialized
    /// at design time. Apparently the hash table itself does not persist its members
    /// at design time.
    /// </summary>
    [Serializable()]
    private class NamedKeyCollection : ISerializable
    {
      #region Initialisation / Serialization
      /// <summary>
      /// The default constructor is needed because the deserialization constructor is present
      /// </summary>
      public NamedKeyCollection ()
      {
      }

      /// <summary>
      /// The deserialization constructor initialises the hash list 
      /// </summary>
      protected NamedKeyCollection (SerializationInfo AInfo, StreamingContext AContext)
      {
        foreach (SerializationEntry se in AInfo)
        {
          Items.Add (se.Name, se.Value);
        }
      }

      public virtual void GetObjectData (SerializationInfo AInfo, StreamingContext AContext) 
      {
        if (HasItems)
        {
          foreach (string sKey in Items.Keys)
          {
            AInfo.AddValue (sKey, _Items[sKey]);
          }
        }
      }
      #endregion

      #region Hash table functions
      /// <summary>
      /// The <c>ContainsKey</c> method does not require a hash table to be created
      /// </summary>
      public bool ContainsKey (object AKey)
      {
        if (_Items == null)
        {
          return false;
        }
        else
        {
          return _Items.ContainsKey (AKey);
        }
      }

      /// <summary>
      /// Save some work if there are no items
      /// </summary>
      public bool HasItems
      {
        get
        {
          return (_Items != null && _Items.Count > 0);
        }
      }

      /// <summary>
      /// Clear means destruction of the list
      /// </summary>
      protected void Clear ()
      {
        _Items = null;
      }

      /// <summary>
      /// Access to the table of elements. If this object is derived from a hastable
      /// directly, there is magic at work that makes we cannt serialize the object
      /// at design time.
      /// </summary>
      public Hashtable Items
      {
        get
        {
          if (_Items == null)
          {
            _Items = new Hashtable ();
          }
          return _Items;
        }
      }
      /// <summary>= <see cref="Items"/></summary>
      private Hashtable _Items = null;
      #endregion
    }
    #endregion

    #region PropertyValue
    /// <summary>
    /// A list of property values, with controls as keys.
    /// </summary>
    /// <remarks>
    /// Note that the keys of the collection are names only shortly after deserialization, 
    /// before <see cref="ReplaceKeys"/> is called. At all other times the keys are the
    /// control objects to which the provided property values apply. As controls are 
    /// uniquely identified with a name and components are not, <c>ProvidedPropertyCollection</c>
    /// can only store property values for controls.
    /// </remarks>
    [Serializable()]
    private class PropertyValue : NamedKeyCollection
    {
      #region Constructors
      /// <summary>
      /// The default constructor is needed because the deserialization constructor is present
      /// </summary>
      public PropertyValue (ExtenderProviderEngine AEngine)
      {
        _Engine = AEngine;
      }
      internal ExtenderProviderEngine _Engine;

      /// <summary>
      /// The deserialization constructor has to be re-declared
      /// </summary>
      protected PropertyValue (SerializationInfo AInfo, StreamingContext AContext)
        : base (AInfo, AContext)
      {
      }
      #endregion

      #region Serialization
      /// <summary>
      /// In the serialization process, the keys (which are controls) are persisted with their
      /// <see cref="System.Web.UI.Control.UniqueID"/>. The reverse is done by <see cref="ReplaceKeys"/>.
      /// </summary>
      public override void GetObjectData (SerializationInfo AInfo, StreamingContext AContext) 
      {
        if (HasItems)
        {
          int nSkipStart = 0;
          if (_Engine != null && _Engine.VSDesigned != null && _Engine.VSDesigned.UniqueID != null)
          {
            // If VSDesigned is a UserControl it has a UniqueID even at design time.
            nSkipStart = _Engine.VSDesigned.UniqueID.Length + 1;
          }
          foreach (System.Web.UI.Control c in Items.Keys)
          {
            AInfo.AddValue (c.UniqueID.Substring(nSkipStart), Items[c]); 
          }
        }
      }

      /// <summary>
      /// Replaces the keys of the hash table. After serialization the keys
      /// are the control IDs, but at run-time object references are required.
      /// </summary>
      public void ReplaceKeys (ExtenderProviderEngine AEngine)
      {
        if (_Engine == null) _Engine = AEngine;
        if (HasItems)
        {
          Hashtable htByName = Items;
          Clear ();
          foreach (string sKey in htByName.Keys)
          {
            System.Web.UI.Control cControl = _Engine.VSDesigned;
            foreach (string sID in sKey.Split (new char[] {':'}))
            {
              if (sID != "")
              {
                cControl = cControl.FindControl (sID);
              }
            }
            Items.Add (cControl, htByName[sKey]);
          }
        }
      }
      #endregion

      #region Provided property values
      /// <summary>
      /// Retrieves the value for the provided property for a control.
      /// </summary>
      /// <param name="AExtendee">Control to be extended</param>
      /// <param name="ADefault">The default value for this property</param>
      public object GetControlPropertyValue (System.Web.UI.Control AExtendee, object ADefault)
      {
        if (ContainsKey (AExtendee))
        {
          return Items[AExtendee];
        }
        else
        {
          return ADefault;
        }
      }

      /// <summary>
      /// Sets the value for the provided property for a control. 
      /// </summary>
      /// <param name="AExtendee">Control to be extended</param>
      /// <param name="AValue">The value for this property</param>
      /// <param name="AIsDefault"><c>true</c> if the value is the default for this property</param>
      /// <returns><c>false</c> if the property value definitely has not changed</returns>
      public bool SetControlPropertyValue (System.Web.UI.Control AExtendee, object AValue, bool AIsDefault)
      {
        if (!ContainsKey (AExtendee))
        {
          if (AIsDefault) return false; // No need to store default values
          Items.Add (AExtendee, AValue);
        }
        else if (AIsDefault)
        {
          // Don't need this value anymore
          Items.Remove (AExtendee);
        }
        else
        {
          // Update the value
          Items[AExtendee] = AValue;
        }
        // The value might have changed
        return true;
      }
      #endregion
    }
    #endregion

    /// <summary>
    /// A list of <see cref="PropertyValue"/> objects as value, with the name of
    /// the set as key.
    /// </summary>
    private NamedKeyCollection _PropertyList;
    #endregion

    #region Visual Studio hacks
    /// <summary>
    /// Make Visual Studio update the properties of the current component. Called
    /// from the <see cref="SetControlPropertyValue"/> method.
    /// </summary>
    /// <remarks>
    /// This routine is needed because Visual Studio does not know that properties
    /// of this component have been changed, as it thinks that the extendee (the control
    /// being extended with the properties) changes. This method forces the
    /// <see cref="PropertyData"/> to be saved.
    /// </remarks>
    protected void NotifyDesignerOfChange () 
    {
      // Thanks to Paul Easter for this code on microsoft.public.dotnet.framework.aspnet.buildingcontrols

      // Tell the designer that the component has changed
      // Make sure we are in design mode
      if (_Stage == LifeCycleStage.DesignMode)
      {
        try
        {
          // Get the designer objects from the Site
          IDesignerHost dhDesigner = _Site.GetService (typeof (IDesignerHost)) as IDesignerHost;
          if (dhDesigner != null)
          {
            IComponentChangeService ccsChanger = dhDesigner.GetService (typeof (IComponentChangeService)) as IComponentChangeService;

            // Raise the OnComponentChanged to tell the designer that our component has changed.
            // "_Component" in this case is the component that has changed.
            // You need to call OnComponentChanging as well!
            ccsChanger.OnComponentChanging (_Component, null);
            ccsChanger.OnComponentChanged (_Component, null, null, null);
          }
        }
        catch
        {
          // Hopefully we will never see this error
        }
      }
    }

    /// <summary>
    /// If the <c>PropertyData</c> is published as a public property of the component,
    /// Visual Studio serializes all values of the provided properties for all controls
    /// in a base64-encoded string.
    /// </summary>
    /// <remarks>
    /// The property data could also have been published as an object - it would end up
    /// in the resources. However, Visual Studio then does not detect any change in the
    /// property value, as it looks to the object rather than the serialized output.
    /// </remarks>
    public string PropertyData
    {
      get
      {
        if (HasPropertyData)
        {
          // Serialize the property data to a string
          MemoryStream ms = new MemoryStream ();
          BinaryFormatter bf = new BinaryFormatter ();
          bf.Serialize (ms, _PropertyList);
          // Use Base64 encoding
          return Convert.ToBase64String (ms.ToArray());
        }
        else
        {
          return null;
        }
      }
      set
      {
        if (value == null)
        {
          _PropertyList = null;
          ReplaceKeys ();
        }
        else
        {
          // Deserialize the data
          MemoryStream ms = new MemoryStream (Convert.FromBase64String (value));
          BinaryFormatter bf = new BinaryFormatter ();
          _PropertyList = (NamedKeyCollection )bf.Deserialize (ms);
          _Stage = LifeCycleStage.PropertyDataLoaded;
          ReplaceKeys ();
        }
      }
    }

    /// <summary>
    /// The page or user control that is being designed.
    /// </summary>
    /// <remarks>
    /// All property values for a control are stored using its 
    /// <see cref="System.Web.UI.Control.UniqueID"/> as key - at design time.
    /// The <c>UniqueID</c> at run-time can be different for user controls, so
    /// we need to know the designed control to dereference the keys.
    /// <para>
    /// We use the assignment to VSDesigned to call <see cref="ReplaceKeys"/>
    /// and turn <c>UniqueID</c>s into control references. 
    /// </para>
    /// </remarks>
    public System.Web.UI.Control VSDesigned
    {
      get
      {
        return _VSDesigned;
      }
      set
      {
        if (value != null)
        {
          _VSDesigned = value;
          ReplaceKeys ();
        }
      }
    }
    /// <summary>= <see cref="VSDesigned"/></summary>
    private System.Web.UI.Control _VSDesigned = null;
    #endregion
  }

}
