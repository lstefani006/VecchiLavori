
using System;
using System.Collections;

namespace GME 
{
	#region Interface IboolCollection

	/// <summary>
	/// Defines size, enumerators, and synchronization methods for strongly
	/// typed collections of <see cref="bool"/> elements.
	/// </summary>
	/// <remarks>
	/// <b>IboolCollection</b> provides an <see cref="ICollection"/>
	/// that is strongly typed for <see cref="bool"/> elements.
	/// </remarks>

	public interface IboolCollection 
	{
		#region Properties
		#region Count

		/// <summary>
		/// Gets the number of elements contained in the
		/// <see cref="IboolCollection"/>.
		/// </summary>
		/// <value>The number of elements contained in the
		/// <see cref="IboolCollection"/>.</value>
		/// <remarks>Please refer to <see cref="ICollection.Count"/> for details.</remarks>

		int Count { get; }

		#endregion
		#region IsSynchronized

		/// <summary>
		/// Gets a value indicating whether access to the
		/// <see cref="IboolCollection"/> is synchronized (thread-safe).
		/// </summary>
		/// <value><c>true</c> if access to the <see cref="IboolCollection"/> is
		/// synchronized (thread-safe); otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="ICollection.IsSynchronized"/> for details.</remarks>

		bool IsSynchronized { get; }

		#endregion
		#region SyncRoot

		/// <summary>
		/// Gets an object that can be used to synchronize access
		/// to the <see cref="IboolCollection"/>.
		/// </summary>
		/// <value>An object that can be used to synchronize access
		/// to the <see cref="IboolCollection"/>.</value>
		/// <remarks>Please refer to <see cref="ICollection.SyncRoot"/> for details.</remarks>

		object SyncRoot { get; }

		#endregion
		#endregion
		#region Methods
		#region CopyTo

		/// <summary>
		/// Copies the entire <see cref="IboolCollection"/> to a one-dimensional <see cref="Array"/>
		/// of <see cref="bool"/> elements, starting at the specified index of the target array.
		/// </summary>
		/// <param name="array">The one-dimensional <see cref="Array"/> that is the destination of the
		/// <see cref="bool"/> elements copied from the <see cref="IboolCollection"/>.
		/// The <b>Array</b> must have zero-based indexing.</param>
		/// <param name="arrayIndex">The zero-based index in <paramref name="array"/>
		/// at which copying begins.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="array"/> is a null reference.</exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="arrayIndex"/> is less than zero.</exception>
		/// <exception cref="ArgumentException"><para>
		/// <paramref name="arrayIndex"/> is equal to or greater than the length of <paramref name="array"/>.
		/// </para><para>-or-</para><para>
		/// The number of elements in the source <see cref="IboolCollection"/> is greater
		/// than the available space from <paramref name="arrayIndex"/> to the end of the destination
		/// <paramref name="array"/>.</para></exception>
		/// <remarks>Please refer to <see cref="ICollection.CopyTo"/> for details.</remarks>

		void CopyTo(bool[] array, int arrayIndex);

		#endregion
		#region GetEnumerator

		/// <summary>
		/// Returns an <see cref="IboolEnumerator"/> that can
		/// iterate through the <see cref="IboolCollection"/>.
		/// </summary>
		/// <returns>An <see cref="IboolEnumerator"/>
		/// for the entire <see cref="IboolCollection"/>.</returns>
		/// <remarks>Please refer to <see cref="IEnumerable.GetEnumerator"/> for details.</remarks>

		IboolEnumerator GetEnumerator();

		#endregion
		#endregion
	}

	#endregion
	#region Interface IboolList

	/// <summary>
	/// Represents a strongly typed collection of <see cref="bool"/>
	/// objects that can be individually accessed by index.
	/// </summary>
	/// <remarks>
	/// <b>IboolList</b> provides an <see cref="IList"/>
	/// that is strongly typed for <see cref="bool"/> elements.
	/// </remarks>

	public interface
		IboolList: IboolCollection 
	{
		#region Properties
		#region IsFixedSize

		/// <summary>
		/// Gets a value indicating whether the <see cref="IboolList"/> has a fixed size.
		/// </summary>
		/// <value><c>true</c> if the <see cref="IboolList"/> has a fixed size;
		/// otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="IList.IsFixedSize"/> for details.</remarks>

		bool IsFixedSize { get; }

		#endregion
		#region IsReadOnly

		/// <summary>
		/// Gets a value indicating whether the <see cref="IboolList"/> is read-only.
		/// </summary>
		/// <value><c>true</c> if the <see cref="IboolList"/> is read-only;
		/// otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="IList.IsReadOnly"/> for details.</remarks>

		bool IsReadOnly { get; }

		#endregion
		#region Item

		/// <summary>
		/// Gets or sets the <see cref="bool"/> element at the specified index.
		/// </summary>
		/// <param name="index">The zero-based index of the
		/// <see cref="bool"/> element to get or set.</param>
		/// <value>
		/// The <see cref="bool"/> element at the specified <paramref name="index"/>.
		/// </value>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is equal to or greater than
		/// <see cref="IboolCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// The property is set and the <see cref="IboolList"/> is read-only.</exception>
		/// <remarks>Please refer to <see cref="IList.this"/> for details.</remarks>

		bool this[int index] { get; set; }

		#endregion
		#endregion
		#region Methods
		#region Add

		/// <summary>
		/// Adds a <see cref="bool"/> to the end
		/// of the <see cref="IboolList"/>.
		/// </summary>
		/// <param name="value">The <see cref="bool"/> object
		/// to be added to the end of the <see cref="IboolList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <returns>The <see cref="IboolList"/> index at which
		/// the <paramref name="value"/> has been added.</returns>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IboolList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Add"/> for details.</remarks>

		int Add(bool value);

		#endregion
		#region Clear

		/// <summary>
		/// Removes all elements from the <see cref="IboolList"/>.
		/// </summary>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IboolList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Clear"/> for details.</remarks>

		void Clear();

		#endregion
		#region Contains

		/// <summary>
		/// Determines whether the <see cref="IboolList"/>
		/// contains the specified <see cref="bool"/> element.
		/// </summary>
		/// <param name="value">The <see cref="bool"/> object
		/// to locate in the <see cref="IboolList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <returns><c>true</c> if <paramref name="value"/> is found in the
		/// <see cref="IboolList"/>; otherwise, <c>false</c>.</returns>
		/// <remarks>Please refer to <see cref="IList.Contains"/> for details.</remarks>

		bool Contains(bool value);

		#endregion
		#region IndexOf

		/// <summary>
		/// Returns the zero-based index of the first occurrence of the specified
		/// <see cref="bool"/> in the <see cref="IboolList"/>.
		/// </summary>
		/// <param name="value">The <see cref="bool"/> object
		/// to locate in the <see cref="IboolList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <returns>
		/// The zero-based index of the first occurrence of <paramref name="value"/>
		/// in the <see cref="IboolList"/>, if found; otherwise, -1.
		/// </returns>
		/// <remarks>Please refer to <see cref="IList.IndexOf"/> for details.</remarks>

		int IndexOf(bool value);

		#endregion
		#region Insert

		/// <summary>
		/// Inserts a <see cref="bool"/> element into the
		/// <see cref="IboolList"/> at the specified index.
		/// </summary>
		/// <param name="index">The zero-based index at which
		/// <paramref name="value"/> should be inserted.</param>
		/// <param name="value">The <see cref="bool"/> object
		/// to insert into the <see cref="IboolList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is greater than
		/// <see cref="IboolCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IboolList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Insert"/> for details.</remarks>

		void Insert(int index, bool value);

		#endregion
		#region Remove

		/// <summary>
		/// Removes the first occurrence of the specified <see cref="bool"/>
		/// from the <see cref="IboolList"/>.
		/// </summary>
		/// <param name="value">The <see cref="bool"/> object
		/// to remove from the <see cref="IboolList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IboolList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Remove"/> for details.</remarks>

		void Remove(bool value);

		#endregion
		#region RemoveAt

		/// <summary>
		/// Removes the element at the specified index of the
		/// <see cref="IboolList"/>.
		/// </summary>
		/// <param name="index">The zero-based index of the element to remove.</param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is equal to or greater than
		/// <see cref="IboolCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IboolList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.RemoveAt"/> for details.</remarks>

		void RemoveAt(int index);

		#endregion
		#endregion
	}

	#endregion
	#region Interface IboolEnumerator

	/// <summary>
	/// Supports type-safe iteration over a collection that
	/// contains <see cref="bool"/> elements.
	/// </summary>
	/// <remarks>
	/// <b>IboolEnumerator</b> provides an <see cref="IEnumerator"/>
	/// that is strongly typed for <see cref="bool"/> elements.
	/// </remarks>

	public interface IboolEnumerator 
	{
		#region Properties
		#region Current

		/// <summary>
		/// Gets the current <see cref="bool"/> element in the collection.
		/// </summary>
		/// <value>The current <see cref="bool"/> element in the collection.</value>
		/// <exception cref="InvalidOperationException"><para>The enumerator is positioned
		/// before the first element of the collection or after the last element.</para>
		/// <para>-or-</para>
		/// <para>The collection was modified after the enumerator was created.</para></exception>
		/// <remarks>Please refer to <see cref="IEnumerator.Current"/> for details, but note
		/// that <b>Current</b> fails if the collection was modified since the last successful
		/// call to <see cref="MoveNext"/> or <see cref="Reset"/>.</remarks>

		bool Current { get; }

		#endregion
		#endregion
		#region Methods
		#region MoveNext

		/// <summary>
		/// Advances the enumerator to the next element of the collection.
		/// </summary>
		/// <returns><c>true</c> if the enumerator was successfully advanced to the next element;
		/// <c>false</c> if the enumerator has passed the end of the collection.</returns>
		/// <exception cref="InvalidOperationException">
		/// The collection was modified after the enumerator was created.</exception>
		/// <remarks>Please refer to <see cref="IEnumerator.MoveNext"/> for details.</remarks>

		bool MoveNext();

		#endregion
		#region Reset

		/// <summary>
		/// Sets the enumerator to its initial position,
		/// which is before the first element in the collection.
		/// </summary>
		/// <exception cref="InvalidOperationException">
		/// The collection was modified after the enumerator was created.</exception>
		/// <remarks>Please refer to <see cref="IEnumerator.Reset"/> for details.</remarks>

		void Reset();

		#endregion
		#endregion
	}

	#endregion
	#region Interface IstringCollection

	/// <summary>
	/// Defines size, enumerators, and synchronization methods for strongly
	/// typed collections of <see cref="string"/> elements.
	/// </summary>
	/// <remarks>
	/// <b>IstringCollection</b> provides an <see cref="ICollection"/>
	/// that is strongly typed for <see cref="string"/> elements.
	/// </remarks>

	public interface IstringCollection 
	{
		#region Properties
		#region Count

		/// <summary>
		/// Gets the number of elements contained in the
		/// <see cref="IstringCollection"/>.
		/// </summary>
		/// <value>The number of elements contained in the
		/// <see cref="IstringCollection"/>.</value>
		/// <remarks>Please refer to <see cref="ICollection.Count"/> for details.</remarks>

		int Count { get; }

		#endregion
		#region IsSynchronized

		/// <summary>
		/// Gets a value indicating whether access to the
		/// <see cref="IstringCollection"/> is synchronized (thread-safe).
		/// </summary>
		/// <value><c>true</c> if access to the <see cref="IstringCollection"/> is
		/// synchronized (thread-safe); otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="ICollection.IsSynchronized"/> for details.</remarks>

		bool IsSynchronized { get; }

		#endregion
		#region SyncRoot

		/// <summary>
		/// Gets an object that can be used to synchronize access
		/// to the <see cref="IstringCollection"/>.
		/// </summary>
		/// <value>An object that can be used to synchronize access
		/// to the <see cref="IstringCollection"/>.</value>
		/// <remarks>Please refer to <see cref="ICollection.SyncRoot"/> for details.</remarks>

		object SyncRoot { get; }

		#endregion
		#endregion
		#region Methods
		#region CopyTo

		/// <summary>
		/// Copies the entire <see cref="IstringCollection"/> to a one-dimensional <see cref="Array"/>
		/// of <see cref="string"/> elements, starting at the specified index of the target array.
		/// </summary>
		/// <param name="array">The one-dimensional <see cref="Array"/> that is the destination of the
		/// <see cref="string"/> elements copied from the <see cref="IstringCollection"/>.
		/// The <b>Array</b> must have zero-based indexing.</param>
		/// <param name="arrayIndex">The zero-based index in <paramref name="array"/>
		/// at which copying begins.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="array"/> is a null reference.</exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="arrayIndex"/> is less than zero.</exception>
		/// <exception cref="ArgumentException"><para>
		/// <paramref name="arrayIndex"/> is equal to or greater than the length of <paramref name="array"/>.
		/// </para><para>-or-</para><para>
		/// The number of elements in the source <see cref="IstringCollection"/> is greater
		/// than the available space from <paramref name="arrayIndex"/> to the end of the destination
		/// <paramref name="array"/>.</para></exception>
		/// <remarks>Please refer to <see cref="ICollection.CopyTo"/> for details.</remarks>

		void CopyTo(string[] array, int arrayIndex);

		#endregion
		#region GetEnumerator

		/// <summary>
		/// Returns an <see cref="IstringEnumerator"/> that can
		/// iterate through the <see cref="IstringCollection"/>.
		/// </summary>
		/// <returns>An <see cref="IstringEnumerator"/>
		/// for the entire <see cref="IstringCollection"/>.</returns>
		/// <remarks>Please refer to <see cref="IEnumerable.GetEnumerator"/> for details.</remarks>

		IstringEnumerator GetEnumerator();

		#endregion
		#endregion
	}

	#endregion
	#region Interface IstringList

	/// <summary>
	/// Represents a strongly typed collection of <see cref="string"/>
	/// objects that can be individually accessed by index.
	/// </summary>
	/// <remarks>
	/// <b>IstringList</b> provides an <see cref="IList"/>
	/// that is strongly typed for <see cref="string"/> elements.
	/// </remarks>

	public interface
		IstringList: IstringCollection 
	{
		#region Properties
		#region IsFixedSize

		/// <summary>
		/// Gets a value indicating whether the <see cref="IstringList"/> has a fixed size.
		/// </summary>
		/// <value><c>true</c> if the <see cref="IstringList"/> has a fixed size;
		/// otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="IList.IsFixedSize"/> for details.</remarks>

		bool IsFixedSize { get; }

		#endregion
		#region IsReadOnly

		/// <summary>
		/// Gets a value indicating whether the <see cref="IstringList"/> is read-only.
		/// </summary>
		/// <value><c>true</c> if the <see cref="IstringList"/> is read-only;
		/// otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="IList.IsReadOnly"/> for details.</remarks>

		bool IsReadOnly { get; }

		#endregion
		#region Item

		/// <summary>
		/// Gets or sets the <see cref="string"/> element at the specified index.
		/// </summary>
		/// <param name="index">The zero-based index of the
		/// <see cref="string"/> element to get or set.</param>
		/// <value>
		/// The <see cref="string"/> element at the specified <paramref name="index"/>.
		/// </value>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is equal to or greater than
		/// <see cref="IstringCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// The property is set and the <see cref="IstringList"/> is read-only.</exception>
		/// <remarks>Please refer to <see cref="IList.this"/> for details.</remarks>

		string this[int index] { get; set; }

		#endregion
		#endregion
		#region Methods
		#region Add

		/// <summary>
		/// Adds a <see cref="string"/> to the end
		/// of the <see cref="IstringList"/>.
		/// </summary>
		/// <param name="value">The <see cref="string"/> object
		/// to be added to the end of the <see cref="IstringList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <returns>The <see cref="IstringList"/> index at which
		/// the <paramref name="value"/> has been added.</returns>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Add"/> for details.</remarks>

		int Add(string value);

		#endregion
		#region Clear

		/// <summary>
		/// Removes all elements from the <see cref="IstringList"/>.
		/// </summary>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Clear"/> for details.</remarks>

		void Clear();

		#endregion
		#region Contains

		/// <summary>
		/// Determines whether the <see cref="IstringList"/>
		/// contains the specified <see cref="string"/> element.
		/// </summary>
		/// <param name="value">The <see cref="string"/> object
		/// to locate in the <see cref="IstringList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <returns><c>true</c> if <paramref name="value"/> is found in the
		/// <see cref="IstringList"/>; otherwise, <c>false</c>.</returns>
		/// <remarks>Please refer to <see cref="IList.Contains"/> for details.</remarks>

		bool Contains(string value);

		#endregion
		#region IndexOf

		/// <summary>
		/// Returns the zero-based index of the first occurrence of the specified
		/// <see cref="string"/> in the <see cref="IstringList"/>.
		/// </summary>
		/// <param name="value">The <see cref="string"/> object
		/// to locate in the <see cref="IstringList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <returns>
		/// The zero-based index of the first occurrence of <paramref name="value"/>
		/// in the <see cref="IstringList"/>, if found; otherwise, -1.
		/// </returns>
		/// <remarks>Please refer to <see cref="IList.IndexOf"/> for details.</remarks>

		int IndexOf(string value);

		#endregion
		#region Insert

		/// <summary>
		/// Inserts a <see cref="string"/> element into the
		/// <see cref="IstringList"/> at the specified index.
		/// </summary>
		/// <param name="index">The zero-based index at which
		/// <paramref name="value"/> should be inserted.</param>
		/// <param name="value">The <see cref="string"/> object
		/// to insert into the <see cref="IstringList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is greater than
		/// <see cref="IstringCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Insert"/> for details.</remarks>

		void Insert(int index, string value);

		#endregion
		#region Remove

		/// <summary>
		/// Removes the first occurrence of the specified <see cref="string"/>
		/// from the <see cref="IstringList"/>.
		/// </summary>
		/// <param name="value">The <see cref="string"/> object
		/// to remove from the <see cref="IstringList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Remove"/> for details.</remarks>

		void Remove(string value);

		#endregion
		#region RemoveAt

		/// <summary>
		/// Removes the element at the specified index of the
		/// <see cref="IstringList"/>.
		/// </summary>
		/// <param name="index">The zero-based index of the element to remove.</param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is equal to or greater than
		/// <see cref="IstringCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.RemoveAt"/> for details.</remarks>

		void RemoveAt(int index);

		#endregion
		#endregion
	}

	#endregion
	#region Interface IstringEnumerator

	/// <summary>
	/// Supports type-safe iteration over a collection that
	/// contains <see cref="string"/> elements.
	/// </summary>
	/// <remarks>
	/// <b>IstringEnumerator</b> provides an <see cref="IEnumerator"/>
	/// that is strongly typed for <see cref="string"/> elements.
	/// </remarks>

	public interface IstringEnumerator 
	{
		#region Properties
		#region Current

		/// <summary>
		/// Gets the current <see cref="string"/> element in the collection.
		/// </summary>
		/// <value>The current <see cref="string"/> element in the collection.</value>
		/// <exception cref="InvalidOperationException"><para>The enumerator is positioned
		/// before the first element of the collection or after the last element.</para>
		/// <para>-or-</para>
		/// <para>The collection was modified after the enumerator was created.</para></exception>
		/// <remarks>Please refer to <see cref="IEnumerator.Current"/> for details, but note
		/// that <b>Current</b> fails if the collection was modified since the last successful
		/// call to <see cref="MoveNext"/> or <see cref="Reset"/>.</remarks>

		string Current { get; }

		#endregion
		#endregion
		#region Methods
		#region MoveNext

		/// <summary>
		/// Advances the enumerator to the next element of the collection.
		/// </summary>
		/// <returns><c>true</c> if the enumerator was successfully advanced to the next element;
		/// <c>false</c> if the enumerator has passed the end of the collection.</returns>
		/// <exception cref="InvalidOperationException">
		/// The collection was modified after the enumerator was created.</exception>
		/// <remarks>Please refer to <see cref="IEnumerator.MoveNext"/> for details.</remarks>

		bool MoveNext();

		#endregion
		#region Reset

		/// <summary>
		/// Sets the enumerator to its initial position,
		/// which is before the first element in the collection.
		/// </summary>
		/// <exception cref="InvalidOperationException">
		/// The collection was modified after the enumerator was created.</exception>
		/// <remarks>Please refer to <see cref="IEnumerator.Reset"/> for details.</remarks>

		void Reset();

		#endregion
		#endregion
	}

	#endregion
	#region Interface IstringboolCollection

	/// <summary>
	/// Defines size, enumerators, and synchronization methods for strongly
	/// typed collections of <see cref="FunctionListEntry"/> elements.
	/// </summary>
	/// <remarks>
	/// <b>IstringboolCollection</b> provides an <see cref="ICollection"/>
	/// that is strongly typed for <see cref="FunctionListEntry"/> elements.
	/// </remarks>

	public interface IstringboolCollection 
	{
		#region Properties
		#region Count

		/// <summary>
		/// Gets the number of elements contained in the
		/// <see cref="IstringboolCollection"/>.
		/// </summary>
		/// <value>The number of elements contained in the
		/// <see cref="IstringboolCollection"/>.</value>
		/// <remarks>Please refer to <see cref="ICollection.Count"/> for details.</remarks>

		int Count { get; }

		#endregion
		#region IsSynchronized

		/// <summary>
		/// Gets a value indicating whether access to the
		/// <see cref="IstringboolCollection"/> is synchronized (thread-safe).
		/// </summary>
		/// <value><c>true</c> if access to the <see cref="IstringboolCollection"/>
		/// is synchronized (thread-safe); otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="ICollection.IsSynchronized"/> for details.</remarks>

		bool IsSynchronized { get; }

		#endregion
		#region SyncRoot

		/// <summary>
		/// Gets an object that can be used to synchronize access
		/// to the <see cref="IstringboolCollection"/>.
		/// </summary>
		/// <value>An object that can be used to synchronize access to the
		/// <see cref="IstringboolCollection"/>.</value>
		/// <remarks>Please refer to <see cref="ICollection.SyncRoot"/> for details.</remarks>

		object SyncRoot { get; }

		#endregion
		#endregion
		#region Methods
		#region CopyTo

		/// <summary>
		/// Copies the entire <see cref="IstringboolCollection"/>
		/// to a one-dimensional <see cref="Array"/> of <see cref="FunctionListEntry"/> elements,
		/// starting at the specified index of the target array.
		/// </summary>
		/// <param name="array">The one-dimensional <see cref="Array"/> that is the
		/// destination of the <see cref="FunctionListEntry"/> elements copied from the
		/// <see cref="IstringboolCollection"/>.
		/// The <b>Array</b> must have zero-based indexing.</param>
		/// <param name="arrayIndex">The zero-based index in <paramref name="array"/>
		/// at which copying begins.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="array"/> is a null reference.</exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="arrayIndex"/> is less than zero.</exception>
		/// <exception cref="ArgumentException"><para>
		/// <paramref name="arrayIndex"/> is equal to or greater than the length of <paramref name="array"/>.
		/// </para><para>-or-</para><para>
		/// The number of elements in the source <see cref="IstringboolCollection"/>
		/// is greater than the available space from <paramref name="arrayIndex"/> to the end of the
		/// destination <paramref name="array"/>.</para></exception>
		/// <remarks>Please refer to <see cref="ICollection.CopyTo"/> for details.</remarks>

		void CopyTo(FunctionListEntry[] array, int arrayIndex);

		#endregion
		#region GetEnumerator

		/// <summary>
		/// Returns an <see cref="IstringboolEnumerator"/> that can
		/// iterate through the <see cref="IstringboolCollection"/>.
		/// </summary>
		/// <returns>An <see cref="IstringboolEnumerator"/>
		/// for the entire <see cref="IstringboolCollection"/>.</returns>
		/// <remarks>Please refer to <see cref="IEnumerable.GetEnumerator"/> for details.</remarks>

		IstringboolEnumerator GetEnumerator();

		#endregion
		#endregion
	}

	#endregion
	#region Interface IstringboolDictionary

	/// <summary>
	/// Represents a strongly typed collection of
	/// <see cref="FunctionListEntry"/> key-and-value pairs.
	/// </summary>
	/// <remarks>
	/// <b>IstringboolDictionary</b> provides an
	/// <see cref="IDictionary"/> that is strongly typed for
	/// <see cref="string"/> keys and <see cref="bool"/> values.
	/// </remarks>

	public interface
		IstringboolDictionary: IstringboolCollection 
	{
		#region Properties
		#region IsFixedSize

		/// <summary>
		/// Gets a value indicating whether the
		/// <see cref="IstringboolDictionary"/> has a fixed size.
		/// </summary>
		/// <value><c>true</c> if the <see cref="IstringboolDictionary"/>
		/// has a fixed size; otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="IDictionary.IsFixedSize"/> for details.</remarks>

		bool IsFixedSize { get; }

		#endregion
		#region IsReadOnly

		/// <summary>
		/// Gets a value indicating whether the
		/// <see cref="IstringboolDictionary"/> is read-only.
		/// </summary>
		/// <value><c>true</c> if the <see cref="IstringboolDictionary"/>
		/// is read-only; otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="IDictionary.IsReadOnly"/> for details.</remarks>

		bool IsReadOnly { get; }

		#endregion
		#region Item

		/// <summary>
		/// Gets or sets the <see cref="bool"/> value
		/// associated with the specified <see cref="string"/> key.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key
		/// whose value to get or set.</param>
		/// <value>The <see cref="bool"/> value associated with the specified
		/// <paramref name="key"/>. If the specified <paramref name="key"/> is not found,
		/// attempting to get it returns
		/// a null reference,
		/// and attempting to set it creates a new element using the specified
		/// <paramref name="key"/>.</value>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="NotSupportedException">
		/// <para>The property is set and the
		/// <see cref="IstringboolDictionary"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The property is set, <paramref name="key"/> does not exist in the collection,
		/// and the <b>IstringboolDictionary</b> has a fixed size.</para>
		/// </exception>
		/// <remarks>Please refer to <see cref="IDictionary.this"/> for details.</remarks>

		bool this[string key] { get; set; }

		#endregion
		#region Keys

		/// <summary>
		/// Gets an <see cref="IstringCollection"/> containing the keys
		/// in the <see cref="IstringboolDictionary"/>.
		/// </summary>
		/// <value>An <see cref="IstringCollection"/> containing the keys
		/// in the <see cref="IstringboolDictionary"/>.</value>
		/// <remarks>Please refer to <see cref="IDictionary.Keys"/> for details.</remarks>

		IstringCollection Keys { get; }

		#endregion
		#region Values

		/// <summary>
		/// Gets an <see cref="IboolCollection"/> containing the values
		/// in the <see cref="IstringboolDictionary"/>.
		/// </summary>
		/// <value>An <see cref="IboolCollection"/> containing the values
		/// in the <see cref="IstringboolDictionary"/>.</value>
		/// <remarks>Please refer to <see cref="IDictionary.Values"/> for details.</remarks>

		IboolCollection Values { get; }

		#endregion
		#endregion
		#region Methods
		#region Add

		/// <summary>
		/// Adds an element with the specified <see cref="string"/>
		/// key and <see cref="bool"/> value to the
		/// <see cref="IstringboolDictionary"/>.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key of the element
		/// to add to the <see cref="IstringboolDictionary"/>.</param>
		/// <param name="value">The <see cref="bool"/> value of the element
		/// to add to the <see cref="IstringboolDictionary"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <exception cref="ArgumentException">
		/// <para>An element with the specified <paramref name="key"/> already exists
		/// in the <see cref="IstringboolDictionary"/>.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringboolDictionary</b> is set to use the
		/// <see cref="IComparable"/> interface, and <paramref name="key"/> does not
		/// implement the <b>IComparable</b> interface.</para></exception>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="InvalidOperationException">
		/// The comparer throws an exception.</exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringboolDictionary"/> is read-only.
		/// </para><para>-or-</para>
		/// <para>The <b>IstringboolDictionary</b> has a fixed size.
		/// </para></exception>
		/// <remarks>Please refer to <see cref="IDictionary.Add"/> for details.</remarks>

		void Add(string key, bool value);

		#endregion
		#region Clear

		/// <summary>
		/// Removes all elements from the <see cref="IstringboolDictionary"/>.
		/// </summary>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringboolDictionary"/> is read-only.
		/// </para><para>-or-</para>
		/// <para>The <b>IstringboolDictionary</b> has a fixed size.
		/// </para></exception>
		/// <remarks>Please refer to <see cref="IDictionary.Clear"/> for details.</remarks>

		void Clear();

		#endregion
		#region Contains

		/// <summary>
		/// Determines whether the <see cref="IstringboolDictionary"/>
		/// contains the specified <see cref="string"/> key.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key to locate
		/// in the <see cref="IstringboolDictionary"/>.</param>
		/// <returns><c>true</c> if the <see cref="IstringboolDictionary"/>
		/// contains an element with the specified <paramref name="key"/>; otherwise, <c>false</c>.
		/// </returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="InvalidOperationException">
		/// The comparer throws an exception.</exception>
		/// <remarks>Please refer to <see cref="IDictionary.Contains"/> for details.</remarks>

		bool Contains(string key);

		#endregion
		#region Remove

		/// <summary>
		/// Removes the element with the specified <see cref="string"/> key
		/// from the <see cref="IstringboolDictionary"/>.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key of the element to remove
		/// from the <see cref="IstringboolDictionary"/>.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="InvalidOperationException">
		/// The comparer throws an exception.</exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringboolDictionary"/> is read-only.
		/// </para><para>-or-</para>
		/// <para>The <b>IstringboolDictionary</b> has a fixed size.
		/// </para></exception>
		/// <remarks>Please refer to <see cref="IDictionary.Remove"/> for details.</remarks>

		void Remove(string key);

		#endregion
		#endregion
	}

	#endregion
	#region Interface IstringboolList

	/// <summary>
	/// Represents a strongly typed collection of <see cref="FunctionListEntry"/>
	/// objects that can be individually accessed by index.
	/// </summary>
	/// <remarks>
	/// <b>IstringboolList</b> provides an <see cref="IList"/>
	/// that is strongly typed for <see cref="FunctionListEntry"/> elements.
	/// </remarks>

	public interface
		IstringboolList: IstringboolCollection 
	{
		#region Properties
		#region IsFixedSize

		/// <summary>
		/// Gets a value indicating whether the
		/// <see cref="IstringboolList"/> has a fixed size.
		/// </summary>
		/// <value><c>true</c> if the <see cref="IstringboolList"/>
		/// has a fixed size; otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="IList.IsFixedSize"/> for details.</remarks>

		bool IsFixedSize { get; }

		#endregion
		#region IsReadOnly

		/// <summary>
		/// Gets a value indicating whether the
		/// <see cref="IstringboolList"/> is read-only.
		/// </summary>
		/// <value><c>true</c> if the <see cref="IstringboolList"/>
		/// is read-only; otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="IList.IsReadOnly"/> for details.</remarks>

		bool IsReadOnly { get; }

		#endregion
		#region Item

		/// <summary>
		/// Gets or sets the <see cref="FunctionListEntry"/> element at the specified index.
		/// </summary>
		/// <param name="index">The zero-based index of the
		/// <see cref="FunctionListEntry"/> element to get or set.</param>
		/// <value>
		/// The <see cref="FunctionListEntry"/> element at the specified <paramref name="index"/>.
		/// </value>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is equal to or greater than
		/// <see cref="IstringboolCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">The property is set and the
		/// <see cref="IstringboolList"/> is read-only.</exception>
		/// <remarks>Please refer to <see cref="IList.this"/> for details.</remarks>

		FunctionListEntry this[int index] { get; set; }

		#endregion
		#endregion
		#region Methods
		#region Add

		/// <summary>
		/// Adds a <see cref="FunctionListEntry"/> to the end
		/// of the <see cref="IstringboolList"/>.
		/// </summary>
		/// <param name="entry">The <see cref="FunctionListEntry"/> object
		/// to be added to the end of the <see cref="IstringboolList"/>.
		/// </param>
		/// <returns>The <see cref="IstringboolList"/> index at which
		/// the <paramref name="entry"/> has been added.</returns>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringboolList</b> has a fixed size.</para>
		/// </exception>
		/// <remarks>Please refer to <see cref="IList.Add"/> for details.</remarks>

		int Add(FunctionListEntry entry);

		#endregion
		#region Clear

		/// <summary>
		/// Removes all elements from the <see cref="IstringboolList"/>.
		/// </summary>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringboolList</b> has a fixed size.</para>
		/// </exception>
		/// <remarks>Please refer to <see cref="IList.Clear"/> for details.</remarks>

		void Clear();

		#endregion
		#region Contains

		/// <summary>
		/// Determines whether the <see cref="IstringboolList"/>
		/// contains the specified <see cref="FunctionListEntry"/> element.
		/// </summary>
		/// <param name="entry">The <see cref="FunctionListEntry"/> object
		/// to locate in the <see cref="IstringboolList"/>.</param>
		/// <returns><c>true</c> if <paramref name="entry"/> is found in the
		/// <see cref="IstringboolList"/>; otherwise, <c>false</c>.</returns>
		/// <remarks>Please refer to <see cref="IList.Contains"/> for details.</remarks>

		bool Contains(FunctionListEntry entry);

		#endregion
		#region IndexOf

		/// <summary>
		/// Returns the zero-based index of the first occurrence of the specified
		/// <see cref="FunctionListEntry"/> in the <see cref="IstringboolList"/>.
		/// </summary>
		/// <param name="entry">The <see cref="FunctionListEntry"/> object
		/// to locate in the <see cref="IstringboolList"/>.</param>
		/// <returns>
		/// The zero-based index of the first occurrence of <paramref name="entry"/>
		/// in the <see cref="IstringboolList"/>, if found; otherwise, -1.
		/// </returns>
		/// <remarks>Please refer to <see cref="IList.IndexOf"/> for details.</remarks>

		int IndexOf(FunctionListEntry entry);

		#endregion
		#region Insert

		/// <summary>
		/// Inserts a <see cref="FunctionListEntry"/> element into the
		/// <see cref="IstringboolList"/> at the specified index.
		/// </summary>
		/// <param name="index">The zero-based index at which
		/// <paramref name="entry"/> should be inserted.</param>
		/// <param name="entry">The <see cref="FunctionListEntry"/> object to insert
		/// into the <see cref="IstringboolList"/>.</param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is greater than
		/// <see cref="IstringboolCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringboolList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Insert"/> for details.</remarks>

		void Insert(int index, FunctionListEntry entry);

		#endregion
		#region Remove

		/// <summary>
		/// Removes the first occurrence of the specified <see cref="FunctionListEntry"/>
		/// from the <see cref="IstringboolList"/>.
		/// </summary>
		/// <param name="entry">The <see cref="FunctionListEntry"/> object to remove
		/// from the <see cref="IstringboolList"/>.</param>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringboolList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.Remove"/> for details.</remarks>

		void Remove(FunctionListEntry entry);

		#endregion
		#region RemoveAt

		/// <summary>
		/// Removes the element at the specified index of the
		/// <see cref="IstringboolList"/>.
		/// </summary>
		/// <param name="index">The zero-based index of the element to remove.</param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="index"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="index"/> is equal to or greater than
		/// <see cref="IstringboolCollection.Count"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="IstringboolList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>IstringboolList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="IList.RemoveAt"/> for details.</remarks>

		void RemoveAt(int index);

		#endregion
		#endregion
	}

	#endregion
	#region Interface IstringboolEnumerator

	/// <summary>
	/// Supports type-safe iteration over a dictionary that
	/// contains <see cref="FunctionListEntry"/> elements.
	/// </summary>
	/// <remarks>
	/// <b>IstringboolEnumerator</b> provides an
	/// <see cref="IDictionaryEnumerator"/> that is strongly typed for
	/// <see cref="string"/> keys and <see cref="bool"/> values.
	/// </remarks>

	public interface IstringboolEnumerator 
	{
		#region Properties
		#region Current

		/// <summary>
		/// Gets the current <see cref="FunctionListEntry"/> element in the collection.
		/// </summary>
		/// <value>The current <see cref="FunctionListEntry"/> element in the collection.</value>
		/// <exception cref="InvalidOperationException"><para>The enumerator is positioned
		/// before the first element of the collection or after the last element.</para>
		/// <para>-or-</para>
		/// <para>The collection was modified after the enumerator was created.</para></exception>
		/// <remarks>Please refer to <see cref="IEnumerator.Current"/> for details, but note
		/// that <b>Current</b> fails if the collection was modified since the last successful
		/// call to <see cref="MoveNext"/> or <see cref="Reset"/>.</remarks>

		FunctionListEntry Current { get; }

		#endregion
		#region Entry

		/// <summary>
		/// Gets a <see cref="FunctionListEntry"/> containing both
		/// the key and the value of the current dictionary entry.
		/// </summary>
		/// <value>A <see cref="FunctionListEntry"/> containing both
		/// the key and the value of the current dictionary entry.</value>
		/// <exception cref="InvalidOperationException"><para>The enumerator is positioned
		/// before the first element of the dictionary or after the last element.</para>
		/// <para>-or-</para>
		/// <para>The dictionary was modified after the enumerator was created.</para></exception>
		/// <remarks>Please refer to <see cref="IDictionaryEnumerator.Entry"/> for details, but
		/// note that <b>Entry</b> fails if the collection was modified since the last successful
		/// call to <see cref="MoveNext"/> or <see cref="Reset"/>.</remarks>

		FunctionListEntry Entry { get; }

		#endregion
		#region Key

		/// <summary>
		/// Gets the <see cref="string"/> key of the current dictionary entry.
		/// </summary>
		/// <value>The <see cref="string"/> key
		/// of the current element of the enumeration.</value>
		/// <exception cref="InvalidOperationException"><para>The enumerator is positioned
		/// before the first element of the dictionary or after the last element.</para>
		/// <para>-or-</para>
		/// <para>The dictionary was modified after the enumerator was created.</para></exception>
		/// <remarks>Please refer to <see cref="IDictionaryEnumerator.Key"/> for details, but
		/// note that <b>Key</b> fails if the collection was modified since the last successful
		/// call to <see cref="MoveNext"/> or <see cref="Reset"/>.</remarks>

		string Key { get; }

		#endregion
		#region Value

		/// <summary>
		/// Gets the <see cref="bool"/> value of the current dictionary entry.
		/// </summary>
		/// <value>The <see cref="bool"/> value
		/// of the current element of the enumeration.</value>
		/// <exception cref="InvalidOperationException"><para>The enumerator is positioned
		/// before the first element of the dictionary or after the last element.</para>
		/// <para>-or-</para>
		/// <para>The dictionary was modified after the enumerator was created.</para></exception>
		/// <remarks>Please refer to <see cref="IDictionaryEnumerator.Value"/> for details, but
		/// note that <b>Value</b> fails if the collection was modified since the last successful
		/// call to <see cref="MoveNext"/> or <see cref="Reset"/>.</remarks>

		bool Value { get; }

		#endregion
		#endregion
		#region Methods
		#region MoveNext

		/// <summary>
		/// Advances the enumerator to the next element of the collection.
		/// </summary>
		/// <returns><c>true</c> if the enumerator was successfully advanced to the next element;
		/// <c>false</c> if the enumerator has passed the end of the collection.</returns>
		/// <exception cref="InvalidOperationException">
		/// The collection was modified after the enumerator was created.</exception>
		/// <remarks>Please refer to <see cref="IEnumerator.MoveNext"/> for details.</remarks>

		bool MoveNext();

		#endregion
		#region Reset

		/// <summary>
		/// Sets the enumerator to its initial position,
		/// which is before the first element in the collection.
		/// </summary>
		/// <exception cref="InvalidOperationException">
		/// The collection was modified after the enumerator was created.</exception>
		/// <remarks>Please refer to <see cref="IEnumerator.Reset"/> for details.</remarks>

		void Reset();

		#endregion
		#endregion
	}

	#endregion
	#region Struct FunctionListEntry

	/// <summary>
	/// Implements a strongly typed pair of one <see cref="string"/>
	/// key and one <see cref="bool"/> value.
	/// </summary>
	/// <remarks>
	/// <b>FunctionListEntry</b> provides a <see cref="DictionaryEntry"/> that is strongly
	/// typed for <see cref="string"/> keys and <see cref="bool"/> values.
	/// </remarks>

	[Serializable]
	public struct FunctionListEntry 
	{
		#region Private Fields

		private string _key;
		private bool _value;

		#endregion
		#region Public Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionListEntry"/>
		/// class with the specified key and value.
		/// </summary>
		/// <param name="key">
		/// The <see cref="string"/> key in the key-and-value pair.</param>
		/// <param name="value">
		/// The <see cref="bool"/> value in the key-and-value pair.
		/// This argument can be a null reference.
		/// </param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>

		public FunctionListEntry(string key, bool value) 
		{
			if ((object) key == null)
				throw new ArgumentNullException("key");

			this._key = key;
			this._value = value;
		}

		#endregion
		#region Public Properties
		#region Key

		/// <summary>
		/// Gets or sets the <see cref="string"/> key in the key-and-value pair.
		/// </summary>
		/// <value>
		/// The <see cref="string"/> key in the key-and-value pair.
		/// The default is a null reference.
		/// </value>
		/// <exception cref="ArgumentNullException">
		/// <b>Key</b> is set to a null reference.</exception>
		/// <remarks>
		/// <see cref="FunctionListEntry"/> is a value type and therefore has an implicit default
		/// constructor that zeroes all data members. This means that the <b>Key</b> property of
		/// a default-constructed <b>FunctionListEntry</b> contains a null reference by default,
		/// even though it is not possible to explicitly set <b>Key</b> to a null reference.
		/// </remarks>

		public string Key 
		{
			get { return this._key; }
			set 
			{
				if ((object) value == null)
					throw new ArgumentNullException("value");
				this._key = value;
			}
		}

		#endregion
		#region Value

		/// <summary>
		/// Gets or sets the <see cref="bool"/> value in the key-and-value pair.
		/// </summary>
		/// <value>
		/// The <see cref="bool"/> value in the key-and-value pair.
		/// This value can be a null reference, which is also the default.
		/// </value>

		public bool Value 
		{
			get { return this._value; }
			set { this._value = value; }
		}

		#endregion
		#endregion
		#region Public Operators
		#region FunctionListEntry(DictionaryEntry)

		/// <summary>
		/// Converts a <see cref="DictionaryEntry"/> to a <see cref="FunctionListEntry"/>.
		/// </summary>
		/// <param name="entry">A <see cref="DictionaryEntry"/> object to convert.</param>
		/// <returns>A <see cref="FunctionListEntry"/> object that represents
		/// the converted <paramref name="entry"/>.</returns>
		/// <exception cref="InvalidCastException">
		/// <para><paramref name="entry"/> contains a key that is not compatible
		/// with <see cref="string"/>.</para>
		/// <para>-or-</para>
		/// <para><paramref name="entry"/> contains a value that is not compatible
		/// with <see cref="bool"/>.</para>
		/// </exception>

		public static implicit operator FunctionListEntry(DictionaryEntry entry) 
		{
			FunctionListEntry pair = new FunctionListEntry();
			if (entry.Key != null) pair.Key = (string) entry.Key;
			if (entry.Value != null) pair.Value = (bool) entry.Value;
			return pair;
		}

		#endregion
		#region DictionaryEntry(FunctionListEntry)

		/// <summary>
		/// Converts a <see cref="FunctionListEntry"/> to a <see cref="DictionaryEntry"/>.
		/// </summary>
		/// <param name="pair">A <see cref="FunctionListEntry"/> object to convert.</param>
		/// <returns>A <see cref="DictionaryEntry"/> object that
		/// represents the converted <paramref name="pair"/>.</returns>

		public static implicit operator DictionaryEntry(FunctionListEntry pair) 
		{
			DictionaryEntry entry = new DictionaryEntry();
			if (pair.Key != null) entry.Key = pair.Key;
			entry.Value = pair.Value;
			return entry;
		}

		#endregion
		#endregion
	}

	#endregion
	#region Class FunctionList

	/// <summary>
	/// Implements a strongly typed collection of <see cref="FunctionListEntry"/>
	/// key-and-value pairs that are organized based on the hash code of the key.
	/// </summary>
	/// <remarks>
	/// <b>FunctionList</b> provides a <see cref="Hashtable"/> that is strongly typed
	/// for <see cref="string"/> keys and <see cref="bool"/> values.
	/// </remarks>

	[Serializable]
	public class FunctionList:
		IstringboolDictionary, IDictionary, ICloneable 
	{
		#region Private Fields

		private Hashtable _innerHash;
		private KeyList _keyList;
		private ValueList _valueList;

		#endregion
		#region Private Constructors

		// helper type to identify private ctor
		private enum Tag { Default }

		private FunctionList(Tag tag) { }

		#endregion
		#region Public Constructors
		#region FunctionList()

		/// <overloads>
		/// Initializes a new instance of the <see cref="FunctionList"/> class.
		/// </overloads>
		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that is empty and has the default initial capacity, the default load factor,
		/// the default hash code provider and the default comparer.
		/// </summary>
		/// <remarks>Please refer to <see cref="Hashtable()"/> for details.</remarks>

		public FunctionList() 
		{
			this._innerHash = new Hashtable();
		}

		#endregion
		#region FunctionList(IHashCodeProvider, IComparer)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that is empty and has the default initial capacity, the default load factor,
		/// the specified hash code provider and the specified comparer.
		/// </summary>
		/// <param name="provider">
		/// <para>The <see cref="IHashCodeProvider"/> that supplies the hash codes
		/// for all keys in the <see cref="FunctionList"/>.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default hash code provider, which is each key's
		/// implementation of <see cref="Object.GetHashCode"/>.</para></param>
		/// <param name="comparer">
		/// <para>The <see cref="IComparer"/> to use to determine whether two keys are equal.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default comparer, which is each key's
		/// implementation of <see cref="Object.Equals"/>.</para></param>
		/// <remarks>
		/// Please refer to <see cref="Hashtable(IHashCodeProvider, IComparer)"/> for details.
		/// </remarks>

		public FunctionList(IHashCodeProvider provider, IComparer comparer) 
		{
			this._innerHash = new Hashtable(provider, comparer);
		}

		#endregion
		#region FunctionList(Int32)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that is empty and has the specified initial capacity, the default load factor,
		/// the default hash code provider and the default comparer.
		/// </summary>
		/// <param name="capacity">The approximate number of elements that the new
		/// <see cref="FunctionList"/> is initially capable of storing.</param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="capacity"/> is less than zero.</exception>
		/// <remarks>Please refer to <see cref="Hashtable(Int32)"/> for details.</remarks>

		public FunctionList(int capacity) 
		{
			this._innerHash = new Hashtable(capacity);
		}

		#endregion
		#region FunctionList(Int32, IHashCodeProvider, IComparer)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that is empty and has the specified initial capacity, the default load factor,
		/// the specified hash code provider and the specified comparer.
		/// </summary>
		/// <param name="capacity">The approximate number of elements that the new
		/// <see cref="FunctionList"/> is initially capable of storing.</param>
		/// <param name="provider">
		/// <para>The <see cref="IHashCodeProvider"/> that supplies the hash codes
		/// for all keys in the <see cref="FunctionList"/>.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default hash code provider, which is each key's
		/// implementation of <see cref="Object.GetHashCode"/>.</para></param>
		/// <param name="comparer">
		/// <para>The <see cref="IComparer"/> to use to determine whether two keys are equal.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default comparer, which is each key's
		/// implementation of <see cref="Object.Equals"/>.</para></param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="capacity"/> is less than zero.</exception>
		/// <remarks>
		/// Please refer to <see cref="Hashtable(Int32, IHashCodeProvider, IComparer)"/> for details.
		/// </remarks>

		public FunctionList(int capacity,
			IHashCodeProvider provider, IComparer comparer) 
		{

			this._innerHash = new Hashtable(capacity, provider, comparer);
		}

		#endregion
		#region FunctionList(Int32, Single)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that is empty and has the specified initial capacity, the specified load factor,
		/// the default hash code provider and the default comparer.
		/// </summary>
		/// <param name="capacity">The approximate number of elements that the new
		/// <see cref="FunctionList"/> is initially capable of storing.</param>
		/// <param name="loadFactor">A number in the range from 0.1 through 1.0
		/// indicating the maximum ratio of elements to buckets.</param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="capacity"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="loadFactor"/> is less than 0.1.</para>
		/// <para>-or-</para>
		/// <para><paramref name="loadFactor"/> is greater than 1.0.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable(Int32, Single)"/> for details.</remarks>

		public FunctionList(int capacity, float loadFactor) 
		{
			this._innerHash = new Hashtable(capacity, loadFactor);
		}

		#endregion
		#region FunctionList(Int32, Single, IHashCodeProvider, IComparer)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that is empty and has the specified initial capacity, the specified load factor,
		/// the specified hash code provider and the specified comparer.
		/// </summary>
		/// <param name="capacity">The approximate number of elements that the new
		/// <see cref="FunctionList"/> is initially capable of storing.</param>
		/// <param name="loadFactor">A number in the range from 0.1 through 1.0
		/// indicating the maximum ratio of elements to buckets.</param>
		/// <param name="provider">
		/// <para>The <see cref="IHashCodeProvider"/> that supplies the hash codes
		/// for all keys in the <see cref="FunctionList"/>.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default hash code provider, which is each key's
		/// implementation of <see cref="Object.GetHashCode"/>.</para></param>
		/// <param name="comparer">
		/// <para>The <see cref="IComparer"/> to use to determine whether two keys are equal.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default comparer, which is each key's
		/// implementation of <see cref="Object.Equals"/>.</para></param>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="capacity"/> is less than zero.</para>
		/// <para>-or-</para>
		/// <para><paramref name="loadFactor"/> is less than 0.1.</para>
		/// <para>-or-</para>
		/// <para><paramref name="loadFactor"/> is greater than 1.0.</para></exception>
		/// <remarks>
		/// Please refer to <see cref="Hashtable(Int32, Single, IHashCodeProvider, IComparer)"/>
		/// for details.</remarks>

		public FunctionList(int capacity, float loadFactor,
			IHashCodeProvider provider, IComparer comparer) 
		{

			this._innerHash = new Hashtable(capacity, loadFactor, provider, comparer);
		}

		#endregion
		#region FunctionList(FunctionList)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that contains elements copied from the specified dictionary and
		/// that has the same initial capacity as the number of elements copied, the
		/// default load factor, the default hash code provider and the default comparer.
		/// </summary>
		/// <param name="dictionary">The <see cref="FunctionList"/>
		/// whose elements are copied to the new collection.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="dictionary"/> is a null reference.</exception>
		/// <remarks>Please refer to <see cref="Hashtable(IDictionary)"/> for details.</remarks>

		public FunctionList(FunctionList dictionary) 
		{
			if (dictionary == null)
				throw new ArgumentNullException("dictionary");

			this._innerHash = new Hashtable(dictionary._innerHash);
		}

		#endregion
		#region FunctionList(IDictionary)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that contains elements copied from the specified <see cref="IDictionary"/>
		/// and that has the same initial capacity as the number of elements copied, the
		/// default load factor, the default hash code provider and the default comparer.
		/// </summary>
		/// <param name="dictionary">The <see cref="IDictionary"/>
		/// whose elements are copied to the new collection.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="dictionary"/> is a null reference.</exception>
		/// <remarks>Please refer to <see cref="Hashtable(IDictionary)"/> for details.</remarks>

		public FunctionList(IDictionary dictionary) 
		{
			this._innerHash = new Hashtable(dictionary);
		}

		#endregion
		#region FunctionList(IDictionary, IHashCodeProvider, IComparer)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that contains elements copied from the specified <see cref="IDictionary"/>
		/// and that has the same initial capacity as the number of elements copied, the
		/// default load factor, the specified hash code provider and the specified comparer.
		/// </summary>
		/// <param name="dictionary">The <see cref="IDictionary"/>
		/// whose elements are copied to the new collection.</param>
		/// <param name="provider">
		/// <para>The <see cref="IHashCodeProvider"/> that supplies the hash codes
		/// for all keys in the <see cref="FunctionList"/>.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default hash code provider, which is each key's
		/// implementation of <see cref="Object.GetHashCode"/>.</para></param>
		/// <param name="comparer">
		/// <para>The <see cref="IComparer"/> to use to determine whether two keys are equal.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default comparer, which is each key's
		/// implementation of <see cref="Object.Equals"/>.</para></param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="dictionary"/> is a null reference.</exception>
		/// <remarks>
		/// Please refer to <see cref="Hashtable(IDictionary, IHashCodeProvider, IComparer)"/>
		/// for details.</remarks>

		public FunctionList(IDictionary dictionary,
			IHashCodeProvider provider, IComparer comparer) 
		{

			this._innerHash = new Hashtable(dictionary, provider, comparer);
		}

		#endregion
		#region FunctionList(IDictionary, Single)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that contains elements copied from the specified <see cref="IDictionary"/>
		/// and that has the same initial capacity as the number of elements copied, the
		/// specified load factor, the default hash code provider and the default comparer.
		/// </summary>
		/// <param name="dictionary">The <see cref="IDictionary"/>
		/// whose elements are copied to the new collection.</param>
		/// <param name="loadFactor">A number in the range from 0.1 through 1.0
		/// indicating the maximum ratio of elements to buckets.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="dictionary"/> is a null reference.</exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="loadFactor"/> is less than 0.1.</para>
		/// <para>-or-</para>
		/// <para><paramref name="loadFactor"/> is greater than 1.0.</para></exception>
		/// <remarks>
		/// Please refer to <see cref="Hashtable(IDictionary, Single)"/> for details.
		/// </remarks>

		public FunctionList(IDictionary dictionary, float loadFactor) 
		{
			this._innerHash = new Hashtable(dictionary, loadFactor);
		}

		#endregion
		#region FunctionList(IDictionary, Single, IHashCodeProvider, IComparer)

		/// <summary>
		/// Initializes a new instance of the <see cref="FunctionList"/> class
		/// that contains elements copied from the specified <see cref="IDictionary"/>
		/// and that has the same initial capacity as the number of elements copied, the
		/// specified load factor, the specified hash code provider and the specified comparer.
		/// </summary>
		/// <param name="dictionary">The <see cref="IDictionary"/>
		/// whose elements are copied to the new collection.</param>
		/// <param name="loadFactor">A number in the range from 0.1 through 1.0
		/// indicating the maximum ratio of elements to buckets.</param>
		/// <param name="provider">
		/// <para>The <see cref="IHashCodeProvider"/> that supplies the hash codes
		/// for all keys in the <see cref="FunctionList"/>.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default hash code provider, which is each key's
		/// implementation of <see cref="Object.GetHashCode"/>.</para></param>
		/// <param name="comparer">
		/// <para>The <see cref="IComparer"/> to use to determine whether two keys are equal.</para>
		/// <para>-or-</para>
		/// <para>A null reference to use the default comparer, which is each key's
		/// implementation of <see cref="Object.Equals"/>.</para></param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="dictionary"/> is a null reference.</exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <para><paramref name="loadFactor"/> is less than 0.1.</para>
		/// <para>-or-</para>
		/// <para><paramref name="loadFactor"/> is greater than 1.0.</para></exception>
		/// <remarks>
		/// Please refer to <see cref="Hashtable(IDictionary, Single, IHashCodeProvider, IComparer)"/>
		/// for details.</remarks>

		public FunctionList(IDictionary dictionary,
			float loadFactor, IHashCodeProvider provider, IComparer comparer) 
		{

			this._innerHash = new Hashtable(dictionary, loadFactor, provider, comparer);
		}

		#endregion
		#endregion
		#region Public Properties
		#region Count

		/// <summary>
		/// Gets the number of key-and-value pairs contained in the <see cref="FunctionList"/>.
		/// </summary>
		/// <value>
		/// The number of key-and-value pairs contained in the <see cref="FunctionList"/>.
		/// </value>
		/// <remarks>Please refer to <see cref="Hashtable.Count"/> for details.</remarks>

		public int Count 
		{
			get { return this._innerHash.Count; }
		}

		#endregion
		#region IsFixedSize

		/// <summary>
		/// Gets a value indicating whether the <see cref="FunctionList"/> has a fixed size.
		/// </summary>
		/// <value><c>true</c> if the <see cref="FunctionList"/> has a fixed size;
		/// otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="Hashtable.IsFixedSize"/> for details.</remarks>

		public virtual bool IsFixedSize 
		{
			get { return this._innerHash.IsFixedSize; }
		}

		#endregion
		#region IsReadOnly

		/// <summary>
		/// Gets a value indicating whether the <see cref="FunctionList"/> is read-only.
		/// </summary>
		/// <value><c>true</c> if the <see cref="FunctionList"/> is read-only;
		/// otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="Hashtable.IsReadOnly"/> for details.</remarks>

		public virtual bool IsReadOnly 
		{
			get { return this._innerHash.IsReadOnly; }
		}

		#endregion
		#region IsSynchronized

		/// <summary>
		/// Gets a value indicating whether access to the <see cref="FunctionList"/>
		/// is synchronized (thread-safe).
		/// </summary>
		/// <value><c>true</c> if access to the <see cref="FunctionList"/> is
		/// synchronized (thread-safe); otherwise, <c>false</c>. The default is <c>false</c>.</value>
		/// <remarks>Please refer to <see cref="Hashtable.IsSynchronized"/> for details.</remarks>

		public bool IsSynchronized 
		{
			get { return this._innerHash.IsSynchronized; }
		}

		#endregion
		#region Item[string]: bool

		/// <summary>
		/// Gets or sets the <see cref="bool"/> value
		/// associated with the specified <see cref="string"/> key.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key
		/// whose value to get or set.</param>
		/// <value>The <see cref="bool"/> value associated with the specified
		/// <paramref name="key"/>. If the specified <paramref name="key"/> is not found,
		/// attempting to get it returns
		/// a null reference,
		/// and attempting to set it creates a new element using the specified
		/// <paramref name="key"/>.</value>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="NotSupportedException">
		/// <para>The property is set and the <see cref="FunctionList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The property is set, <paramref name="key"/> does not exist in the collection,
		/// and the <b>FunctionList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable.this"/> for details.</remarks>

		public virtual bool this[string key] 
		{
			get 
			{
				return (bool) this._innerHash[key];
			}
			set { this._innerHash[key] = value; }
		}

		#endregion
		#region IDictionary.Item[Object]: Object

		/// <summary>
		/// Gets or sets the value associated with the specified key.
		/// </summary>
		/// <param name="key">The key whose value to get or set.
		/// This argument must be compatible with <see cref="string"/>.</param>
		/// <value>
		/// The value associated with the specified <paramref name="key"/>. If the specified
		/// <paramref name="key"/> is not found, attempting to get it returns
		/// a null reference,
		/// and attempting to set it creates a new element using the specified <paramref name="key"/>.
		/// When set, this value must be compatible with <see cref="bool"/>.
		/// </value>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="InvalidCastException">
		/// <para><paramref name="key"/> is not compatible with <see cref="string"/>.</para>
		/// <para>-or-</para>
		/// <para>The property is set to a value that is not compatible with
		/// <see cref="bool"/>.</para></exception>
		/// <exception cref="NotSupportedException">
		/// <para>The property is set and the <see cref="FunctionList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The property is set, <paramref name="key"/> does not exist in the collection,
		/// and the <b>FunctionList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable.this"/> for details.</remarks>

		object IDictionary.this[object key] 
		{
			get { return this[(string) key]; }
			set { this[(string) key] = (bool) value; }
		}

		#endregion
		#region Keys: IstringCollection

		/// <summary>
		/// Gets an <see cref="IstringCollection"/> containing
		/// the keys in the <see cref="FunctionList"/>.
		/// </summary>
		/// <value>An <see cref="IstringCollection"/> containing
		/// the keys in the <see cref="FunctionList"/>.</value>
		/// <remarks>Please refer to <see cref="Hashtable.Keys"/> for details.</remarks>

		public IstringCollection Keys 
		{
			get 
			{
				if (this._keyList == null)
					this._keyList = new KeyList(this);
				return this._keyList;
			}
		}

		#endregion
		#region IDictionary.Keys: ICollection

		/// <summary>
		/// Gets an <see cref="ICollection"/> containing
		/// the keys in the <see cref="FunctionList"/>.
		/// </summary>
		/// <value>An <see cref="ICollection"/> containing
		/// the keys in the <see cref="FunctionList"/>.</value>
		/// <remarks>Please refer to <see cref="Hashtable.Keys"/> for details.</remarks>

		ICollection IDictionary.Keys 
		{
			get { return (ICollection) Keys; }
		}

		#endregion
		#region SyncRoot

		/// <summary>
		/// Gets an object that can be used to synchronize
		/// access to the <see cref="FunctionList"/>.
		/// </summary>
		/// <value>An object that can be used to synchronize
		/// access to the <see cref="FunctionList"/>.</value>
		/// <remarks>Please refer to <see cref="Hashtable.SyncRoot"/> for details.</remarks>

		public object SyncRoot 
		{
			get { return this._innerHash.SyncRoot; }
		}

		#endregion
		#region Values: IboolCollection

		/// <summary>
		/// Gets an <see cref="IboolCollection"/> containing
		/// the values in the <see cref="FunctionList"/>.
		/// </summary>
		/// <value>An <see cref="IboolCollection"/> containing
		/// the values in the <see cref="FunctionList"/>.</value>
		/// <remarks>Please refer to <see cref="Hashtable.Values"/> for details.</remarks>

		public IboolCollection Values 
		{
			get 
			{
				if (this._valueList == null)
					this._valueList = new ValueList(this);
				return this._valueList;
			}
		}

		#endregion
		#region IDictionary.Values: ICollection

		/// <summary>
		/// Gets an <see cref="ICollection"/> containing
		/// the values in the <see cref="FunctionList"/>.
		/// </summary>
		/// <value>An <see cref="ICollection"/> containing
		/// the values in the <see cref="FunctionList"/>.</value>
		/// <remarks>Please refer to <see cref="Hashtable.Values"/> for details.</remarks>

		ICollection IDictionary.Values 
		{
			get { return (ICollection) Values; }
		}

		#endregion
		#endregion
		#region Public Methods
		#region Add(string, bool)

		/// <summary>
		/// Adds an element with the specified <see cref="string"/> key and
		/// <see cref="bool"/> value to the <see cref="FunctionList"/>.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key of the element
		/// to add to the <see cref="FunctionList"/>.</param>
		/// <param name="value">The <see cref="bool"/> value of the element
		/// to add to the <see cref="FunctionList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <exception cref="ArgumentException">
		/// An element with the specified <paramref name="key"/>
		/// already exists in the <see cref="FunctionList"/>.</exception>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="FunctionList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>FunctionList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable.Add"/> for details.</remarks>

		public virtual void Add(string key, bool value) 
		{
			this._innerHash.Add(key, value);
		}

		#endregion
		#region IDictionary.Add(Object, Object)

		/// <summary>
		/// Adds an element with the specified key and value
		/// to the <see cref="FunctionList"/>.
		/// </summary>
		/// <param name="key">The key of the element to add to the <see cref="FunctionList"/>.
		/// This argument must be compatible with <see cref="string"/>.</param>
		/// <param name="value">The value of the element to add to the <see cref="FunctionList"/>.
		/// This argument must be compatible with <see cref="bool"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <exception cref="ArgumentException">
		/// An element with the specified <paramref name="key"/>
		/// already exists in the <see cref="FunctionList"/>.</exception>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="InvalidCastException">
		/// <para><paramref name="key"/> is not compatible with <see cref="string"/>.</para>
		/// <para>-or-</para>
		/// <para><paramref name="value"/> is not compatible with <see cref="bool"/>.</para>
		/// </exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="FunctionList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>FunctionList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable.Add"/> for details.</remarks>

		void IDictionary.Add(object key, object value) 
		{
			Add((string) key, (bool) value);
		}

		#endregion
		#region Clear

		/// <summary>
		/// Removes all elements from the <see cref="FunctionList"/>.
		/// </summary>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="FunctionList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>FunctionList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable.Clear"/> for details.</remarks>

		public virtual void Clear() 
		{
			this._innerHash.Clear();
		}

		#endregion
		#region Clone

		/// <summary>
		/// Creates a shallow copy of the <see cref="FunctionList"/>.
		/// </summary>
		/// <returns>A shallow copy of the <see cref="FunctionList"/>.</returns>
		/// <remarks>Please refer to <see cref="Hashtable.Clone"/> for details.</remarks>

		public virtual object Clone() 
		{
			FunctionList dictionary = new FunctionList(Tag.Default);
			dictionary._innerHash = (Hashtable) this._innerHash.Clone();
			return dictionary;
		}

		#endregion
		#region Contains(string)

		/// <summary>
		/// Determines whether the <see cref="FunctionList"/>
		/// contains the specified <see cref="string"/> key.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key
		/// to locate in the <see cref="FunctionList"/>.</param>
		/// <returns><c>true</c> if the <see cref="FunctionList"/> contains an element
		/// with the specified <paramref name="key"/>; otherwise, <c>false</c>.</returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <remarks>Please refer to <see cref="Hashtable.Contains"/> for details.</remarks>

		public bool Contains(string key) 
		{
			return this._innerHash.Contains(key);
		}

		#endregion
		#region IDictionary.Contains(Object)

		/// <summary>
		/// Determines whether the <see cref="FunctionList"/> contains the specified key.
		/// </summary>
		/// <param name="key">The key to locate in the <see cref="FunctionList"/>.
		/// This argument must be compatible with <see cref="string"/>.</param>
		/// <returns><c>true</c> if the <see cref="FunctionList"/> contains an element
		/// with the specified <paramref name="key"/>; otherwise, <c>false</c>.</returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="InvalidCastException"><paramref name="key"/>
		/// is not compatible with <see cref="string"/>.</exception>
		/// <remarks>Please refer to <see cref="Hashtable.Contains"/> for details.</remarks>

		bool IDictionary.Contains(object key) 
		{
			return Contains((string) key);
		}

		#endregion
		#region ContainsKey

		/// <summary>
		/// Determines whether the <see cref="FunctionList"/>
		/// contains the specified <see cref="string"/> key.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key
		/// to locate in the <see cref="FunctionList"/>.</param>
		/// <returns><c>true</c> if the <see cref="FunctionList"/> contains an element
		/// with the specified <paramref name="key"/>; otherwise, <c>false</c>.</returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <remarks>Please refer to <see cref="Hashtable.ContainsKey"/> for details.</remarks>

		public bool ContainsKey(string key) 
		{
			return this._innerHash.ContainsKey(key);
		}

		#endregion
		#region ContainsValue

		/// <summary>
		/// Determines whether the <see cref="FunctionList"/>
		/// contains the specified <see cref="bool"/> value.
		/// </summary>
		/// <param name="value">The <see cref="bool"/> value
		/// to locate in the <see cref="FunctionList"/>.
		/// This argument can be a null reference.
		/// </param>
		/// <returns><c>true</c> if the <see cref="FunctionList"/> contains an element
		/// with the specified <paramref name="value"/>; otherwise, <c>false</c>.</returns>
		/// <remarks>Please refer to <see cref="Hashtable.ContainsValue"/> for details.</remarks>

		public bool ContainsValue(bool value) 
		{
			return this._innerHash.ContainsValue(value);
		}

		#endregion
		#region CopyTo(FunctionListEntry[], Int32)

		/// <summary>
		/// Copies the entire <see cref="FunctionList"/> to a one-dimensional <see cref="Array"/> of
		/// <see cref="FunctionListEntry"/> elements, starting at the specified index of the target array.
		/// </summary>
		/// <param name="array">The one-dimensional <see cref="Array"/> that is the destination of the
		/// <see cref="FunctionListEntry"/> elements copied from the <see cref="FunctionList"/>.
		/// The <b>Array</b> must have zero-based indexing.</param>
		/// <param name="arrayIndex">The zero-based index in <paramref name="array"/>
		/// at which copying begins.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="array"/> is a null reference.</exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="arrayIndex"/> is less than zero.</exception>
		/// <exception cref="ArgumentException"><para>
		/// <paramref name="arrayIndex"/> is equal to or greater than the length of <paramref name="array"/>.
		/// </para><para>-or-</para><para>
		/// The number of elements in the source <see cref="FunctionList"/> is greater than
		/// the available space from <paramref name="arrayIndex"/> to the end of the destination
		/// <paramref name="array"/>.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable.CopyTo"/> for details.</remarks>

		public void CopyTo(FunctionListEntry[] array, int arrayIndex) 
		{
			CheckTargetArray(array, arrayIndex);

			if (IsSynchronized)
				lock (SyncRoot) PerformCopyTo(array, arrayIndex);
			else
				PerformCopyTo(array, arrayIndex);
		}

		#endregion
		#region ICollection.CopyTo(Array, Int32)

		/// <summary>
		/// Copies the entire <see cref="FunctionList"/> to a one-dimensional <see cref="Array"/>,
		/// starting at the specified index of the target array.
		/// </summary>
		/// <param name="array">The one-dimensional <see cref="Array"/> that is the destination of the
		/// <see cref="FunctionListEntry"/> elements copied from the <see cref="FunctionList"/>.
		/// The <b>Array</b> must have zero-based indexing.</param>
		/// <param name="arrayIndex">The zero-based index in <paramref name="array"/>
		/// at which copying begins.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="array"/> is a null reference.</exception>
		/// <exception cref="ArgumentOutOfRangeException">
		/// <paramref name="arrayIndex"/> is less than zero.</exception>
		/// <exception cref="ArgumentException"><para>
		/// <paramref name="array"/> is multidimensional.
		/// </para><para>-or-</para><para>
		/// <paramref name="arrayIndex"/> is equal to or greater than the length of <paramref name="array"/>.
		/// </para><para>-or-</para><para>
		/// The number of elements in the source <see cref="FunctionList"/> is greater than
		/// the available space from <paramref name="arrayIndex"/> to the end of the destination
		/// <paramref name="array"/>.</para></exception>
		/// <exception cref="InvalidCastException">
		/// The <see cref="FunctionListEntry"/> type cannot be cast automatically
		/// to the type of the destination <paramref name="array"/>.</exception>
		/// <remarks>Please refer to <see cref="Hashtable.CopyTo"/> for details.</remarks>

		void ICollection.CopyTo(Array array, int arrayIndex) 
		{
			CheckTargetArray(array, arrayIndex);
			CopyTo((FunctionListEntry[]) array, arrayIndex);
		}

		#endregion
		#region GetEnumerator: IstringboolEnumerator

		/// <summary>
		/// Returns an <see cref="IstringboolEnumerator"/>
		/// that can iterate through the <see cref="FunctionList"/>.
		/// </summary>
		/// <returns>An <see cref="IstringboolEnumerator"/>
		/// for the entire <see cref="FunctionList"/>.</returns>
		/// <remarks>Please refer to <see cref="Hashtable.GetEnumerator"/> for details.</remarks>

		public IstringboolEnumerator GetEnumerator() 
		{
			return new Enumerator(this);
		}

		#endregion
		#region IDictionary.GetEnumerator: IDictionaryEnumerator

		/// <summary>
		/// Returns an <see cref="IDictionaryEnumerator"/> that can
		/// iterate through the <see cref="FunctionList"/>.
		/// </summary>
		/// <returns>An <see cref="IDictionaryEnumerator"/>
		/// for the entire <see cref="FunctionList"/>.</returns>
		/// <remarks>Please refer to <see cref="Hashtable.GetEnumerator"/> for details.</remarks>

		IDictionaryEnumerator IDictionary.GetEnumerator() 
		{
			return (IDictionaryEnumerator) GetEnumerator();
		}

		#endregion
		#region IEnumerable.GetEnumerator: IEnumerator

		/// <summary>
		/// Returns an <see cref="IEnumerator"/> that can
		/// iterate through the <see cref="FunctionList"/>.
		/// </summary>
		/// <returns>An <see cref="IEnumerator"/>
		/// for the entire <see cref="FunctionList"/>.</returns>
		/// <remarks>Please refer to <see cref="Hashtable.GetEnumerator"/> for details.</remarks>

		IEnumerator IEnumerable.GetEnumerator() 
		{
			return (IEnumerator) GetEnumerator();
		}

		#endregion
		#region Remove(string)

		/// <summary>
		/// Removes the element with the specified <see cref="string"/> key
		/// from the <see cref="FunctionList"/>.
		/// </summary>
		/// <param name="key">The <see cref="string"/> key of the element
		/// to remove from the <see cref="FunctionList"/>.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="FunctionList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>FunctionList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable.Remove"/> for details.</remarks>

		public virtual void Remove(string key) 
		{
			this._innerHash.Remove(key);
		}

		#endregion
		#region IDictionary.Remove(Object)

		/// <summary>
		/// Removes the element with the specified key
		/// from the <see cref="FunctionList"/>.
		/// </summary>
		/// <param name="key">The key of the element to remove from the <see cref="FunctionList"/>.
		/// This argument must be compatible with <see cref="string"/>.</param>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="key"/> is a null reference.</exception>
		/// <exception cref="InvalidCastException"><paramref name="key"/>
		/// is not compatible with <see cref="string"/>.</exception>
		/// <exception cref="NotSupportedException">
		/// <para>The <see cref="FunctionList"/> is read-only.</para>
		/// <para>-or-</para>
		/// <para>The <b>FunctionList</b> has a fixed size.</para></exception>
		/// <remarks>Please refer to <see cref="Hashtable.Remove"/> for details.</remarks>

		void IDictionary.Remove(object key) 
		{
			Remove((string) key);
		}

		#endregion
		#region ReadOnly

		/// <summary>
		/// Returns a read-only wrapper for the specified <see cref="FunctionList"/>.
		/// </summary>
		/// <param name="dictionary">The <see cref="FunctionList"/> to wrap.</param>
		/// <returns>A read-only wrapper around <paramref name="dictionary"/>.</returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="dictionary"/> is a null reference.</exception>
		/// <remarks>
		/// <b>ReadOnly</b> has the same effect as the <see cref="ArrayList.ReadOnly"/>
		/// method of the <see cref="ArrayList"/> class.
		/// </remarks>

		public static FunctionList ReadOnly(FunctionList dictionary) 
		{
			if (dictionary == null)
				throw new ArgumentNullException("dictionary");

			FunctionList readOnly = new ReadOnlyDictionary();

			readOnly._innerHash = dictionary._innerHash;
			readOnly._keyList = dictionary._keyList;
			readOnly._valueList = dictionary._valueList;
            
			return readOnly;
		}

		#endregion
		#region Synchronized

		/// <summary>
		/// Returns a synchronized (thread-safe) wrapper
		/// for the specified <see cref="FunctionList"/>.
		/// </summary>
		/// <param name="dictionary">The <see cref="FunctionList"/> to synchronize.</param>
		/// <returns>A synchronized (thread-safe) wrapper around <paramref name="dictionary"/>.</returns>
		/// <exception cref="ArgumentNullException">
		/// <paramref name="dictionary"/> is a null reference.</exception>
		/// <remarks>Please refer to <see cref="Hashtable.Synchronized"/> for details.</remarks>

		public static FunctionList Synchronized(FunctionList dictionary) 
		{
			if (dictionary == null)
				throw new ArgumentNullException("dictionary");

			FunctionList sync = new FunctionList(Tag.Default);
			sync._innerHash = Hashtable.Synchronized(dictionary._innerHash);

			// preserve custom read-only wrapper if present
			if (dictionary.IsReadOnly && !dictionary._innerHash.IsReadOnly)
				sync = FunctionList.ReadOnly(sync);

			return sync;
		}

		#endregion
		#endregion
		#region Private Methods
		#region CheckTargetArray

		private void CheckTargetArray(Array array, int arrayIndex) 
		{
			if (array == null)
				throw new ArgumentNullException("array");
			if (array.Rank > 1)
				throw new ArgumentException(
					"Argument cannot be multidimensional.", "array");

			if (arrayIndex < 0)
				throw new ArgumentOutOfRangeException("arrayIndex",
					arrayIndex, "Argument cannot be negative.");
			if (arrayIndex >= array.Length)
				throw new ArgumentException(
					"Argument must be less than array length.", "arrayIndex");

			if (this._innerHash.Count > array.Length - arrayIndex)
				throw new ArgumentException(
					"Argument section must be large enough for collection.", "array");
		}

		#endregion
		#region PerformCopyTo

		private void PerformCopyTo(FunctionListEntry[] array, int index) 
		{
			/*
			 * We cannot use _innerHash.CopyTo here because this method does not
			 * auto-convert array elements from DictionaryEntry to PairType.
			 */
			foreach (DictionaryEntry entry in this._innerHash)
				array[index++] = new FunctionListEntry(
					(string) entry.Key, (bool) entry.Value);
		}

		#endregion
		#endregion
		#region Class Enumerator

		private sealed class Enumerator:
			IstringboolEnumerator, IDictionaryEnumerator 
		{
			#region Private Fields

			private readonly IDictionaryEnumerator _innerEnumerator;

			#endregion
			#region Internal Constructors

			internal Enumerator(FunctionList dictionary) 
			{
				this._innerEnumerator = dictionary._innerHash.GetEnumerator();
			}

			#endregion
			#region Public Properties

			public FunctionListEntry Current 
			{
				get { return new FunctionListEntry(Key, Value); }
			}

			object IEnumerator.Current 
			{
				get { return this._innerEnumerator.Current; }
			}

			public FunctionListEntry Entry 
			{
				get { return new FunctionListEntry(Key, Value); }
			}

			DictionaryEntry IDictionaryEnumerator.Entry 
			{
				get { return this._innerEnumerator.Entry; }
			}

			public string Key 
			{
				get { return (string) this._innerEnumerator.Key; }
			}

			object IDictionaryEnumerator.Key 
			{
				get { return this._innerEnumerator.Key; }
			}

			public bool Value 
			{
				get { return (bool) this._innerEnumerator.Value; }
			}

			object IDictionaryEnumerator.Value 
			{
				get { return this._innerEnumerator.Value; }
			}

			#endregion
			#region Public Methods

			public bool MoveNext() 
			{
				return this._innerEnumerator.MoveNext();
			}

			public void Reset() 
			{
				this._innerEnumerator.Reset();
			}

			#endregion
		}

		#endregion
		#region Class KeyList

		[Serializable]
			private sealed class KeyList:
			IstringCollection, ICollection 
		{
			#region Private Fields

			private FunctionList _dictionary;

			#endregion
			#region Internal Constructors

			internal KeyList(FunctionList dictionary) 
			{
				this._dictionary = dictionary;
			}

			#endregion
			#region Public Properties

			public int Count 
			{
				get { return this._dictionary.Count; }
			}

			public bool IsSynchronized 
			{
				get { return this._dictionary.IsSynchronized; }
			}

			public object SyncRoot 
			{
				get { return this._dictionary.SyncRoot; }
			}

			#endregion
			#region Public Methods

			public void CopyTo(string[] array, int arrayIndex) 
			{
				this._dictionary.CheckTargetArray(array, arrayIndex);
				foreach (FunctionListEntry pair in this._dictionary)
					array[arrayIndex++] = pair.Key;
			}

			void ICollection.CopyTo(Array array, int arrayIndex) 
			{
				this._dictionary.CheckTargetArray(array, arrayIndex);
				CopyTo((string[]) array, arrayIndex);
			}

			public IstringEnumerator GetEnumerator() 
			{
				return new KeyEnumerator(this._dictionary);
			}

			IEnumerator IEnumerable.GetEnumerator() 
			{
				return (IEnumerator) GetEnumerator();
			}

			#endregion
		}

		#endregion
		#region Class KeyEnumerator

		[Serializable]
			private sealed class KeyEnumerator:
			IstringEnumerator, IEnumerator 
		{
			#region Private Fields

			private readonly IEnumerator _innerEnumerator;

			#endregion
			#region Internal Constructors

			internal KeyEnumerator(FunctionList dictionary) 
			{
				this._innerEnumerator = dictionary._innerHash.Keys.GetEnumerator();
			}

			#endregion
			#region Public Properties

			public string Current 
			{
				get { return (string) this._innerEnumerator.Current; }
			}

			object IEnumerator.Current 
			{
				get { return this._innerEnumerator.Current; }
			}

			#endregion
			#region Public Methods

			public bool MoveNext() 
			{
				return this._innerEnumerator.MoveNext();
			}

			public void Reset() 
			{
				this._innerEnumerator.Reset();
			}

			#endregion
		}

		#endregion
		#region Class ValueList

		[Serializable]
			private sealed class ValueList:
			IboolCollection, ICollection 
		{
			#region Private Fields

			private FunctionList _dictionary;

			#endregion
			#region Internal Constructors

			internal ValueList(FunctionList dictionary) 
			{
				this._dictionary = dictionary;
			}

			#endregion
			#region Public Properties

			public int Count 
			{
				get { return this._dictionary.Count; }
			}

			public bool IsSynchronized 
			{
				get { return this._dictionary.IsSynchronized; }
			}

			public object SyncRoot 
			{
				get { return this._dictionary.SyncRoot; }
			}

			#endregion
			#region Public Methods

			public void CopyTo(bool[] array, int arrayIndex) 
			{
				this._dictionary.CheckTargetArray(array, arrayIndex);
				foreach (FunctionListEntry pair in this._dictionary)
					array[arrayIndex++] = pair.Value;
			}

			void ICollection.CopyTo(Array array, int arrayIndex) 
			{
				this._dictionary.CheckTargetArray(array, arrayIndex);
				CopyTo((bool[]) array, arrayIndex);
			}

			public IboolEnumerator GetEnumerator() 
			{
				return new ValueEnumerator(this._dictionary);
			}

			IEnumerator IEnumerable.GetEnumerator() 
			{
				return (IEnumerator) GetEnumerator();
			}

			#endregion
		}

		#endregion
		#region Class ValueEnumerator

		[Serializable]
			private sealed class ValueEnumerator:
			IboolEnumerator, IEnumerator 
		{
			#region Private Fields

			private readonly IEnumerator _innerEnumerator;

			#endregion
			#region Internal Constructors

			internal ValueEnumerator(FunctionList dictionary) 
			{
				this._innerEnumerator = dictionary._innerHash.Values.GetEnumerator();
			}

			#endregion
			#region Public Properties

			public bool Current 
			{
				get { return (bool) this._innerEnumerator.Current; }
			}

			object IEnumerator.Current 
			{
				get { return this._innerEnumerator.Current; }
			}

			#endregion
			#region Public Methods

			public bool MoveNext() 
			{
				return this._innerEnumerator.MoveNext();
			}

			public void Reset() 
			{
				this._innerEnumerator.Reset();
			}

			#endregion
		}

		#endregion
		#region Class ReadOnlyDictionary

		[Serializable]
			private sealed class ReadOnlyDictionary: FunctionList 
		{
			#region Public Properties

			public override bool IsFixedSize 
			{
				get { return true; }
			}

			public override bool IsReadOnly 
			{
				get { return true; }
			}

			public override bool this[string key] 
			{
				get { return base[key]; }
				set 
				{
					throw new NotSupportedException(
						  "Read-only dictionaries cannot be modified."); }
			}

			#endregion
			#region Public Methods

			public override void Add(string key, bool value) 
			{
				throw new NotSupportedException(
					"Read-only dictionaries cannot be modified.");
			}

			public override void Clear() 
			{
				throw new NotSupportedException(
					"Read-only dictionaries cannot be modified.");
			}

			public override object Clone() 
			{
				return FunctionList.ReadOnly((FunctionList) base.Clone());
			}

			public override void Remove(string key) 
			{
				throw new NotSupportedException(
					"Read-only dictionaries cannot be modified.");
			}

			#endregion
		}

		#endregion
	}

	#endregion
}
