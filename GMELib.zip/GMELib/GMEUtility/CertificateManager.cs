using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Specialized;
using GME.Security;


namespace GME.Security
{
	/// <summary>
	/// Summary description for CertificateManager.
	/// </summary>
	public class CertificateManager : System.ComponentModel.Component
	{
		private System.Data.SqlClient.SqlConnection _cn;
		private System.Data.SqlClient.SqlDataAdapter daCertificateList;
		private System.Data.SqlClient.SqlDataAdapter daCertificateDistributionPoints;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand2;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand2;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand2;
		private System.Data.SqlClient.SqlDataAdapter daCertificateRevokationList;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand3;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand3;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand3;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand3;
		private System.Data.SqlClient.SqlDataAdapter daGetCertificateData;
		private System.Data.SqlClient.SqlDataAdapter daCertificateCA;
		private System.Data.SqlClient.SqlCommand cmdCertificateCA_Select;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand4;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand2;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand4;
		private System.Data.SqlClient.SqlCommand cmdCertificateList_Select;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand4;
		private System.Data.SqlClient.SqlDataAdapter daCertificateListAll;
		private SqlCommand sqlInsertCommand5;
		private SqlCommand sqlSelectCommand6;
		private SqlCommand sqlDeleteCommand5;
		private SqlCommand sqlUpdateCommand4;
		private SqlCommand sqlUpdateCommand;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		public CertificateManager(System.ComponentModel.IContainer container)
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			container.Add(this);
			InitializeComponent();

			string s = GME.Utility.AppSettings.ToString("Certificate_SqlConnectionString", null);
			if (s == null)
				s = GME.Utility.AppSettings.ToString("SqlConnectionString", string.Empty);
			_cn.ConnectionString = s;

		}

		/// <summary>
		/// Classe per la gestione dei certificati digitali.
		/// </summary>
		public CertificateManager()
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			InitializeComponent();

			string s = GME.Utility.AppSettings.ToString("Certificate_SqlConnectionString", null);
			if (s == null)
				s = GME.Utility.AppSettings.ToString("SqlConnectionString", string.Empty);
			_cn.ConnectionString = s;
		}



		/// <summary>
		/// Funzione per memorizzare un certificato di firma o di autenticazione nel DB.
		/// Se il certificato esiste gia` la funzione ritorna senza apportare modifiche alla base dati.
		/// Se il certificato esiste gia` la funzione controlla se il dichiarante e` lo stesso: se si
		/// ritorna subito, altrimenti lancia un'eccezione.
		/// Se il certificato non e` conosciuto nel DB si procede nei seguenti passi:
		/// 1) si memorizza il certificato nella GME_Certificate_List (tabella dei certificati)
		/// 2) si momorizza la sua CA nella GME_Certificate_CA in stato disabilitato se la CA non
		///    e` gia` conosciuta; altrimenti si lascia la riga inalterata.
		/// 3) si memorizzano i punti di distribuzione della CA qualora la CA non sia conosciuta.
		/// 
		/// Se la CA non e` conosciuta, l'amministratore deve abilitarla esplicitamente per consentire ai
		/// certificati di essere accettati.
		/// </summary>
		/// <param name="c">certifcato da memorizzare</param>
		/// <param name="codiceUtenteRegistrazione">utente associato al certificato</param>
		/// <param name="bAbilitaCertificatoAutenticazione">flag che indica se abilitare il ceertificato di autenticazione</param>
		/// <param name="bAbilitaCertificatoFirma">flag che indica se abilitare il ceertificato di firma</param>
		public void StoreCertificate(CertX509Ex c, string codiceUtenteRegistrazione,
			bool bAbilitaCertificatoAutenticazione, bool bAbilitaCertificatoFirma)
		{
			SqlTransaction tr = null;
			try
			{
				_cn.Open();
				tr = _cn.BeginTransaction();

				StoreCertificate(tr, c, codiceUtenteRegistrazione, bAbilitaCertificatoAutenticazione, bAbilitaCertificatoFirma);

				tr.Commit();
			}
			catch (Exception ex)
			{
				if (tr != null)
					tr.Rollback();
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}
		}

		#region Implementation
		internal void StoreCertificate(SqlTransaction tr, CertX509Ex c, string codiceUtenteRegistrazione, bool bAbilitaCertificatoAutenticazione, bool bAbilitaCertificatoFirma)
		{
			GMEUtility.DS_Certificate ds = new GMEUtility.DS_Certificate();

			SetTransaction(this.daCertificateDistributionPoints, tr);
			SetTransaction(this.daCertificateList, tr);
			SetTransaction(this.daCertificateCA, tr);

			string issuer = c.GetIssuerName();
			string sn = c.GetSerialNumberString();
			string subject = c.GetName();

			// carico nel DS i dati del certificato se esiste.
			this.daCertificateList.SelectCommand.Parameters["@Issuer"].Value = issuer;
			this.daCertificateList.SelectCommand.Parameters["@SerialNumber"].Value = sn;
			daCertificateList.Fill(ds.GME_Certificate_List);

			// ricerco il certificato
			// la ricerca e` inutile dato che se esiste e` sicuramente il primo
			GMEUtility.DS_Certificate.GME_Certificate_ListRow drCertificate;
			drCertificate = ds.GME_Certificate_List.FindByIssuerSerialNumber(issuer, sn);
			if (drCertificate != null)
			{
				// il certificato esiste, controllo che l'utente sia lo stesso:
				// se e` diverso cosa posso fare ?
				if (drCertificate.CodiceUtenteRegistrazione != codiceUtenteRegistrazione)
				{
					throw new CertException("Certificato gia` registrato ad un altro utente.");
				}

				return; // esiste gia` non devo registrarlo
			}


			// carico la lista delle CA.
			// Qui carico TUTTE le CA (a prescindere dalla CA del certificato da registrare)
			daCertificateCA.Fill(ds.GME_Certificate_CA);

			// carico la lista dei punti di distribuzione della CA del certficato da registrare.
			this.daCertificateDistributionPoints.SelectCommand.Parameters["@Issuer"].Value = issuer;
			daCertificateDistributionPoints.Fill(ds.GME_Certificate_DistributionPoints);

			string forceAction = GME.Utility.AppSettings.ToString("Certificate_DefaultForceAction");
			if (forceAction == null)
				forceAction = ""; // controlli di default (i piu` restrittivi)

			//
			// Inserisce una nuova entry con CodiceUtenteSDC e Validita' settato a <bAbilitaCertificatoUtente>
			//
			if (true)
			{
				GMEUtility.DS_Certificate.GME_Certificate_ListRow drCL = ds.GME_Certificate_List.NewGME_Certificate_ListRow();
				drCL.Issuer = issuer;
				drCL.SerialNumber = sn;
				drCL.Subject = subject;
				drCL.Autenticazione = c.IsDigitaleSignatureCertificate;
				drCL.Firma = c.IsNonRepudiationCertificate;
				drCL.TSInizioValidita = DateTime.Now;
				drCL.TSFineValidita = c.ExpirationDate;

				drCL.TSRegistrazione = DateTime.Now;
				drCL.CodiceUtenteRegistrazione = codiceUtenteRegistrazione;

				drCL.AbilitatoAutenticazione = bAbilitaCertificatoAutenticazione && c.IsDigitaleSignatureCertificate;
				drCL.AbilitatoFirma = bAbilitaCertificatoFirma && c.IsNonRepudiationCertificate;
				drCL.ForceAction = forceAction;
				drCL.SetLastErrorNull();

				ds.GME_Certificate_List.AddGME_Certificate_ListRow(drCL);
			}

			GMEUtility.DS_Certificate.GME_Certificate_CARow drCA;
			drCA = ds.GME_Certificate_CA.FindByIssuer(issuer);
			if (drCA == null)
			{
				drCA = ds.GME_Certificate_CA.NewGME_Certificate_CARow();
				drCA.Issuer = issuer;
				drCA.Abilitata = false;
				drCA.SetTSCRLUltimoDownloadTentatoNull();
				drCA.SetTSCRLDownloadConSuccessoNull();
				drCA.SetTSCRLInizioValiditaNull();
				drCA.SetTSCRLFineValiditaNull();
				ds.GME_Certificate_CA.AddGME_Certificate_CARow(drCA);
			}


			// Gestione dei punti di distribuzione
			// (il metodo ritorna null se il certificato non ha CDP)
			//
			string[] dpl = c.DistributionPointList;
			if (dpl != null)
			{
				foreach (string dp in dpl)
				{
					GMEUtility.DS_Certificate.GME_Certificate_DistributionPointsRow drCertificateDistributionPoint;
					drCertificateDistributionPoint = ds.GME_Certificate_DistributionPoints.FindByIssuerUrl(issuer, dp);
					if (drCertificateDistributionPoint == null)
					{
						drCertificateDistributionPoint = ds.GME_Certificate_DistributionPoints.NewGME_Certificate_DistributionPointsRow();
						drCertificateDistributionPoint.Issuer = issuer;
						drCertificateDistributionPoint.Url = dp;
						drCertificateDistributionPoint.Abilitato = false;

						ds.GME_Certificate_DistributionPoints.AddGME_Certificate_DistributionPointsRow(drCertificateDistributionPoint);
					}
				}
			}


			daCertificateCA.Update(ds.GME_Certificate_CA);
			daCertificateDistributionPoints.Update(ds.GME_Certificate_DistributionPoints);
			daCertificateList.Update(ds.GME_Certificate_List);
		}
		#endregion

		/// <summary>
		/// delegato per effettuare il download della CRL in un altro AppDomain,
		/// tipicamente da un PC esposto in Internet.
		/// </summary>
		/// <returns>true se il download e` stato effettuato con successo</returns>
		public delegate bool DownloadCRLDelegate(int timeOut, string Url, out DateTime currentTime, out DateTime nextTime, out CryptCRL.CRLEntry[] crlEntries);

		/// <summary>
		/// property che indica la funzione da chiamare ad ogni download di un punto di distribuzione.
		/// Da utilizzare quando si vuole downloadare la CRL di un DP da un PC non esposto ad Internet
		/// </summary>
		/// <value>la funzione da chiamre per fare il download dei DP</value>
		/// <example>
		/// CertificateManager cm = new CertificateManager();
		/// sm.DownloadDistributionPoint = new delegate(int timeOut, string Url, out DateTime currentTime, out DateTime nextTime, out GME.Security.CryptCRL.CRLEntry[] crlEntries)
		/// {
		///		currentTime = DateTime.Now;
		///		nextTime = DateTime.Now;
		///		crlEntries = null;
		///		try 
		///		{
		///			// collegamento ad un WS esposto in internet che effettua il download
		///			WSIntranetToWeb ws = new WSIntranetToWeb();
		///			return ws.DownloadDistributionPoint(timeOut, Url, out currentTime, out nextTime, out crlEntries);
		///		} catch
		///		{
		///			return false;
		///		}
		/// }
		/// </example>
		public DownloadCRLDelegate DownloadDistributionPoint
		{
			get { return _downloadDistributionPoint; }
			set { _downloadDistributionPoint = value; }
		}

		/// <summary>
		/// di default la funzione che scarica la CLR di un DP e` eseguita nello stesso PC
		/// </summary>
		private DownloadCRLDelegate _downloadDistributionPoint = new DownloadCRLDelegate(LocalDownloadDistributionPoint);

		/// <summary>
		/// flag che indica se e` necessario scaricare la CRL anche se non e` ancora
		/// la CRL stessa non e` ancora scaduta.
		/// </summary>
		public bool ForceCRLDownload
		{
			get { return _forceCRLDownload; }
			set { _forceCRLDownload = value; }
		}

		/// <summary>
		/// Scarica la CRL delle CA abilitate.
		/// La CRL ha campi che permettono di
		/// 1) capire l'ultimo tentativo di download
		/// 2) capire l'ultimo download effettuato con successo
		/// 3) capire la data di fine validita della CRL
		/// Se la CA non e` abilitata il download non avviene ma viene
		/// assegnato il campo di ultimo tentativo (naturalmente senza successo).
		/// </summary>
		public void UpdadeCRL()
		{
			SqlTransaction tr = null;
			try
			{
				_cn.Open();
				tr = _cn.BeginTransaction();

				UpdadeCRL(tr);

				if (tr != null)
					tr.Commit();
			}
			catch (Exception ex)
			{
				if (tr != null)
					tr.Rollback();
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}
		}



		#region Implementation

		private bool _forceCRLDownload = false;


		internal void UpdadeCRL(SqlTransaction tr)
		{
			Debug.Assert(tr != null);

			SetTransaction(this.daCertificateDistributionPoints, tr);
			SetTransaction(this.daCertificateRevokationList, tr);
			SetTransaction(this.daCertificateCA, tr);


			int timeOut = GME.Utility.AppSettings.ToInt32("Certificate_CRLDownloadTimeout", 30);

			GMEUtility.DS_Certificate ds = new GMEUtility.DS_Certificate();

			// carico tutte le CA conosciute
			daCertificateCA.Fill(ds.GME_Certificate_CA);

			foreach (GMEUtility.DS_Certificate.GME_Certificate_CARow drCA in ds.GME_Certificate_CA)
			{
				ds.GME_Certificate_DistributionPoints.Clear();
				ds.GME_Certificate_RevocationList.Clear();


				DateTime tsDownload = DateTime.Now;

				// parto con il presupposto che non si riesca a downloadare la CRL
				// possibili ragioni:
				// 1) CA disabilitata
				// 2) Non esistono DP per la CA
				// 3) I Dp per la CA sono tutti disabilitati
				// 5) Nessun DP abilitato ritorna la CRL
				drCA.TSCRLUltimoDownloadTentato = tsDownload;

				// se l'amministratore NON ha abilitato la CA
				if (drCA.Abilitata == false)
					continue; // passo alla prossima

				if (ForceCRLDownload == false)
				{
					// controllo la data di scadenza della CLR
					if (drCA.IsTSCRLDownloadConSuccessoNull() == false)
					{
						// se scade domani o piu` in la, la considero valida
						// se scade oggi forzo comunque il caricamento.
						if (drCA.IsTSCRLFineValiditaNull() == false &&
							drCA.TSCRLFineValidita.Date > DateTime.Now.Date)
						{
							// modifico e aggiorno le date nel DB
							drCA.TSCRLUltimoDownloadTentato = tsDownload;
							drCA.TSCRLDownloadConSuccesso = tsDownload;
							this.daCertificateCA.Update(ds.GME_Certificate_CA);
							continue;
						}
					}
				}


				// carico i dati della lista di distribuzione e della CRL associata.
				this.daCertificateDistributionPoints.SelectCommand.Parameters["@Issuer"].Value = drCA.Issuer;
				this.daCertificateDistributionPoints.Fill(ds.GME_Certificate_DistributionPoints);

				this.daCertificateRevokationList.SelectCommand.Parameters["@Issuer"].Value = drCA.Issuer;
				this.daCertificateRevokationList.Fill(ds.GME_Certificate_RevocationList);

				// lista utilizzata per capire quali entry della CRL sono da cancellare.
				ArrayList drDone = new ArrayList();

				foreach (GMEUtility.DS_Certificate.GME_Certificate_DistributionPointsRow drDP in ds.GME_Certificate_DistributionPoints)
				{
					if (drDP.Abilitato == false)
						continue;

					DateTime currentTime;
					DateTime nextTime = DateTime.MinValue;
					CryptCRL.CRLEntry[] crlEntries = null;

					// invoco il delegate che effettua il download fisico.
					bool bOk = false;
					try { bOk = DownloadDistributionPoint(timeOut, drDP.Url, out currentTime, out nextTime, out crlEntries); }
					catch { bOk = false; }

					if (bOk == false)
						continue;

					// download effettuato con successo.

					drCA.TSCRLInizioValidita = tsDownload;
					drCA.TSCRLFineValidita = nextTime;
					drCA.TSCRLUltimoDownloadTentato = tsDownload;
					drCA.TSCRLDownloadConSuccesso = tsDownload;

					for (int i = 0; i < crlEntries.Length; ++i)
					{
						string sn = string.Empty;
						for (int k = 0; k < crlEntries[i].SerialNumber.Length; k++)
							sn += crlEntries[i].SerialNumber[k].ToString("X2");

						GMEUtility.DS_Certificate.GME_Certificate_RevocationListDataTable dt = ds.GME_Certificate_RevocationList;
						GMEUtility.DS_Certificate.GME_Certificate_RevocationListRow dr;
						dr = dt.FindByIssuerSerialNumber(drCA.Issuer, sn);
						if (dr == null)
						{
							// non esiste --> inserisco la nuova entry.
							dr = dt.NewGME_Certificate_RevocationListRow();
							dr.Issuer = drCA.Issuer;
							dr.SerialNumber = sn;
							dr.TSRevoca = crlEntries[i].RevocationDate;
							dr.ReasonCode = (int)crlEntries[i].Reason;
							dt.AddGME_Certificate_RevocationListRow(dr);
						}
						else
						{
							// Aggiorno la data di revoca
							dr.TSRevoca = crlEntries[i].RevocationDate;
							dr.ReasonCode = (int)crlEntries[i].Reason;
						}

						// memorizzo la riga aggiornata
						drDone.Add(dr);
					}

					// il downoload e` riuscito passo alla prossima CA
					break;
				}

				// cancello le entry presenti nel DB ma non piu` presenti nella CRL
				foreach (GMEUtility.DS_Certificate.GME_Certificate_RevocationListRow dr in ds.GME_Certificate_RevocationList)
					if (drDone.Contains(dr) == false)
						dr.Delete();

				this.daCertificateRevokationList.Update(ds.GME_Certificate_RevocationList);
				this.daCertificateDistributionPoints.Update(ds.GME_Certificate_DistributionPoints);
				// ad ogni loop qui aggiorno una CA alla volta.
				this.daCertificateCA.Update(ds.GME_Certificate_CA);
			}
		}


		/// <summary>
		/// funzione che si occupa di contattare il DP specificato nella Url per downloadare
		/// effettivamente la CRL associata a quella CA.
		/// </summary>
		/// <param name="timeOut"></param>
		/// <param name="Url"></param>
		/// <param name="currentTime"></param>
		/// <param name="nextTime"></param>
		/// <param name="crlEntries"></param>
		/// <returns></returns>
		internal static bool LocalDownloadDistributionPoint(int timeOut, string Url, out DateTime currentTime, out DateTime nextTime, out CryptCRL.CRLEntry[] crlEntries)
		{
			crlEntries = null;
			currentTime = DateTime.MinValue;
			nextTime = DateTime.MinValue;

			try
			{
				CryptCRL d = new CryptCRL(Url, CryptCRL.CrlDownloadType.NetworkCrlDownloadOnly, timeOut);
				d.GetAllCRLData(out currentTime, out nextTime, out crlEntries);
				return true;
			}
			catch
			{
				return false;
			}
		}
		#endregion


		/// <summary>
		/// Flag che indica se controllare la validita` del certificato per le
		/// funzionalita` di firma o per quelle di autenticazione.
		/// Dato che il campo e` [Flag] si puo` richiedere contemporaneramente il
		/// controllo sulla validita` di firma e di autenticazione
		/// </summary>
		[Flags]
		public enum ControlloPer
		{
			Firma = 1,
			Autenticazione = 2
		}

		/// <summary>
		/// flag che indica se controllare o meno la data di scadenza del certificato
		/// </summary>
		public enum ControllaScadenzaCertificato
		{
			No, Si
		}

		/// <summary>
		/// Funzione che controlla la validita` di tutti i certificati persenti nella tabella GME_Certificate_List.
		/// </summary>
		/// <param name="TSTarget">controlla la validita` del certificato per questa data</param>
		/// <param name="controlloPer">flag per controllare la firma, l'autentifcazione o entrambi</param>
		/// <param name="controlloScadenzaCertificato">flag che indica se controllare la data di scadenza del certificato</param>
		public void CheckCertificates(DateTime TSTarget, ControlloPer controlloPer, ControllaScadenzaCertificato controlloScadenzaCertificato)
		{
			GMEUtility.DS_Certificate ds = new GMEUtility.DS_Certificate();

			try
			{
				_cn.Open();

				daCertificateListAll.Fill(ds.GME_Certificate_List);
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}

			foreach (GMEUtility.DS_Certificate.GME_Certificate_ListRow dr in ds.GME_Certificate_List)
			{
				string codiceUtenteOut;
				string s = CheckCertificate(dr.Issuer, dr.SerialNumber, TSTarget, controlloScadenzaCertificato, controlloPer, out codiceUtenteOut);

				if (s == null || s == string.Empty)
					dr.SetLastErrorNull();
				else
					dr.LastError = s;
			}

			try
			{
				_cn.Open();
				daCertificateListAll.Update(ds.GME_Certificate_List);
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}

		}


		/// <summary>
		/// Controlla la validita` del certificato in ingresso.
		/// </summary>
		/// <param name="issuer">CA che ha emesso il certificato</param>
		/// <param name="serialNumber">numero seriale del certificato</param>
		/// <param name="CodiceUtenteRegistrazione">utente che ha presentato il certificato</param>
		/// <param name="TSTarget">il controllo di validita` viene effettuato su questo parametro.</param>
		/// <param name="csc">se controllare la scedenza del certifcato o saltare il controllo</param>
		/// <param name="controlloPer">controllo di validita per firma o per autorizzazione o entrambe</param>
		/// <returns>null (Nothing) se il certificato e` valido. La stringa di errore se il certificato non e` valido.</returns>
		public string CheckCertificate(string issuer, string serialNumber, DateTime TSTarget, ControllaScadenzaCertificato csc, ControlloPer controlloPer, out string CodiceUtenteRegistrazione)
		{
			CodiceUtenteRegistrazione = null;
			try
			{
				_cn.Open();

				GMEUtility.DS_Certificate ds = new GMEUtility.DS_Certificate();
				daGetCertificateData.SelectCommand.Parameters["@Issuer"].Value = issuer;
				daGetCertificateData.SelectCommand.Parameters["@sn"].Value = serialNumber;
				//daGetCertificateData.SelectCommand.Parameters["@CodiceUtenteRegistrazione"].Value = CodiceUtenteRegistrazione;

				daGetCertificateData.Fill(ds.spGME_GetCertificateData);

				if (ds.spGME_GetCertificateData.Count == 0)
					return "C001: Certificato di firma non registrato nel sistema";

				GMEUtility.DS_Certificate.spGME_GetCertificateDataRow dr = ds.spGME_GetCertificateData[0];

				CodiceUtenteRegistrazione = dr.CertificatoCodiceUtenteRegistrazione;


				ForceAction[] fa = parseForceAction(dr.CertificatoForceAction);

				if (fa == null)
					throw new ApplicationException("formato ForceAction errato");
				/*
				 * Flag di forzatura (se un sertificato risulta es scaduto si puo` forzare
				 * a continuare con quel certificato con T)
				 * certificato scaduto      T
				 *							T<n>
				 * certificato revocato		C ok
				 * revocato con code		R<n>
				 * CRL scaduta				S ok
				 *							S<n>
				 * CRL non presente			P
				 * CRL non aggiornata		D
				 *							D<n>
				 * Certificato senza CDP    M
				 */
				ForceAction z;

				if (csc == ControllaScadenzaCertificato.Si && dr.CertificatoFineValidita < TSTarget)
				{
					bool b = false;
					// il certificato e` scaduto.

					z = GetForceAction(fa, 'T');
					if (z != null)
					{
						b = true;

						if (z.numberPresent == true)
						{
							if (TimeSpan.FromTicks(TSTarget.Ticks - dr.CertificatoFineValidita.Ticks).Days > z.number)
								return "C003: Certificato scaduto";
						}
					}

					if (b == false)
						return "C004: Certificato scaduto";
				}

				if ((controlloPer & ControlloPer.Autenticazione) != 0)
				{
					if (dr.CertificatoAutenticazione == false)
						return "C076: il certificato non e` un certificato di autenticazione";

					if (dr.CertificatoAbilitatoAutenticazione == false)
						return "C077: certificato non abilitato dall'amministratore per l'autenticazione";
				}
				if ((controlloPer & ControlloPer.Firma) != 0)
				{
					if (dr.CertificatoFirma == false)
						return "C078: certificato non e` un certifcato di firma";

					if (dr.CertificatoAbilitatoFirma == false)
						return "C079: certificato non abilitato dall'amministratore per la firma digitale";
				}



				if (dr.CAAbilitata == false)
				{
					// Issuer non e` presente nel DB
					// non esiste voce di forzatura in quanto se si vuole si abilita
					// l'entry nella Certificate_CA
					return "C006: Issuer non abilitato";
				}

				//
				// Certificato senza punti di distribuzione CRL
				//
				if (dr.NumeroPuntiDiDistribuzione == 0)
				{

					z = GetForceAction(fa, 'M');
					if (z != null)
						return "";
					else
						return "C016: Certificato con issuer senza CDP";
				}


				//if (dr.IsTSUltimoDownloadConSuccessoNull())
				if (dr.IsCATSCRLDownloadConSuccessoNull())
				{
					// non ha mai scaricato la CRL

					bool b = false;
					z = GetForceAction(fa, 'P');
					if (z != null)
						b = true;

					if (b == false)
						return "C008: CRL non presente per l'issuer";
				}
				else
				{
					// CRL scaricata.... ma quando ?

					if (dr.CATSCRLFineValidita < TSTarget)
					{
						// CRL scaduta.

						bool b = false;

						z = GetForceAction(fa, 'S');
						if (z != null)
						{
							b = true;
							if (z.numberPresent)
							{
								if (TimeSpan.FromTicks(TSTarget.Ticks - dr.CATSCRLFineValidita.Ticks).Days > z.number)
									return "C010: CRL scaduta";
							}
						}

						if (b == false)
							return "C011: CRL scaduta";
					}

					if (dr.IsCATSCRLUltimoDownloadTentatoNull() == false && dr.CATSCRLUltimoDownloadTentato > dr.CATSCRLDownloadConSuccesso)
					{
						// ha provato a scaricare una CRL ma ha fallito
						// --> CRL non aggiornata

						bool b = false;
						z = GetForceAction(fa, 'D');
						if (z != null)
						{
							b = true;
							if (z.numberPresent)
							{
								if (TimeSpan.FromTicks(dr.CATSCRLUltimoDownloadTentato.Ticks - dr.CATSCRLDownloadConSuccesso.Ticks).Days > z.number)
									return "C012: CRL non abbanstanza fresca";
							}
						}

						if (b == false)
							return "C014: CRL non abbanstanza fresca";
					}


					if (dr.IsCRLTSRevocaNull() == false)
					{
						z = null;
						while ((z = GetForceAction(fa, 'R', z)) != null)
						{
							if (z.numberPresent && dr.IsCRLReasonCodeNull() == false && dr.CRLReasonCode == z.number)
								break;
						}

						if (z == null)
							z = GetForceAction(fa, 'C');

						if (z == null)
							return "C015: certificato revocato";
					}
				}

			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}

			return "";
		}

		#region Implementation




		class ForceAction
		{
			public char opz;
			public bool numberPresent;
			public int number;
		}

		private ForceAction GetForceAction(ForceAction[] fa, char opz)
		{
			if (fa != null)
			{
				for (int i = 0; i < fa.Length; ++i)
					if (fa[i].opz == opz)
						return fa[i];
			}
			return null;
		}

		private ForceAction GetForceAction(ForceAction[] fa, char opz, ForceAction previous)
		{
			if (fa != null)
			{
				for (int i = 0; i < fa.Length; ++i)
				{
					if (fa[i].opz == opz && previous == null)
						return fa[i];

					if (fa[i].opz == opz && fa[i] == previous)
						previous = null;
				}
			}
			return null;
		}


		private static ForceAction[] parseForceAction(string fa)
		{
			ArrayList aa = new ArrayList();
			int i;
			for (i = 0; i < fa.Length; )
			{
				ForceAction a = new ForceAction();

				a.opz = fa[i];
				a.numberPresent = false;
				aa.Add(a);

				++i;

				if (i == fa.Length)
					break;
				if (fa[i] == '<')
				{
					++i;
					int n = 0;
					for (; ; )
					{
						if (i >= fa.Length)
							break;
						if (fa[i] == '>') { a.numberPresent = true; a.number = n; ++i; break; }
						if (!char.IsDigit(fa[i]))
							break;
						n = n * 10 + (fa[i] - '0');
						++i;
					}
				}
			}
			if (i == fa.Length)
			{
				ForceAction[] r = new ForceAction[aa.Count];
				for (int j = 0; j < aa.Count; j++)
				{
					r[j] = (ForceAction)aa[j];
				}
				return r;
			}
			else
				return null;
		}

		protected static void SetTransaction(SqlDataAdapter da, SqlTransaction tr)
		{
			if (da.SelectCommand != null)
				da.SelectCommand.Transaction = tr;
			if (da.InsertCommand != null)
				da.InsertCommand.Transaction = tr;
			if (da.DeleteCommand != null)
				da.DeleteCommand.Transaction = tr;
			if (da.UpdateCommand != null)
				da.UpdateCommand.Transaction = tr;
		}

		#endregion

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this._cn = new System.Data.SqlClient.SqlConnection();
			this.daCertificateList = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.cmdCertificateList_Select = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.daCertificateDistributionPoints = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand = new System.Data.SqlClient.SqlCommand();
			this.daCertificateRevokationList = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			this.daGetCertificateData = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			this.daCertificateCA = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand4 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			this.cmdCertificateCA_Select = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			this.daCertificateListAll = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand5 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand5 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand6 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand4 = new System.Data.SqlClient.SqlCommand();
// 
// _cn
// 
			this._cn.ConnectionString = "Server=BILSVR1;User ID=sa;Password=bilaterali;Database=GMELib;Persist Security In" +
				"fo=True";
// 
// daCertificateList
// 
			this.daCertificateList.DeleteCommand = this.sqlDeleteCommand1;
			this.daCertificateList.InsertCommand = this.sqlInsertCommand1;
			this.daCertificateList.SelectCommand = this.cmdCertificateList_Select;
			this.daCertificateList.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "GME_Certificate_List", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
                        new System.Data.Common.DataColumnMapping("SerialNumber", "SerialNumber"),
                        new System.Data.Common.DataColumnMapping("Subject", "Subject"),
                        new System.Data.Common.DataColumnMapping("Autenticazione", "Autenticazione"),
                        new System.Data.Common.DataColumnMapping("Firma", "Firma"),
                        new System.Data.Common.DataColumnMapping("TSInizioValidita", "TSInizioValidita"),
                        new System.Data.Common.DataColumnMapping("TSFineValidita", "TSFineValidita"),
                        new System.Data.Common.DataColumnMapping("TSRegistrazione", "TSRegistrazione"),
                        new System.Data.Common.DataColumnMapping("CodiceUtenteRegistrazione", "CodiceUtenteRegistrazione"),
                        new System.Data.Common.DataColumnMapping("AbilitatoAutenticazione", "AbilitatoAutenticazione"),
                        new System.Data.Common.DataColumnMapping("AbilitatoFirma", "AbilitatoFirma"),
                        new System.Data.Common.DataColumnMapping("ForceAction", "ForceAction"),
                        new System.Data.Common.DataColumnMapping("LastError", "LastError")})});
			this.daCertificateList.UpdateCommand = this.sqlUpdateCommand1;
// 
// sqlDeleteCommand1
// 
			this.sqlDeleteCommand1.CommandText = "DELETE FROM [dbo].[GME_Certificate_List] WHERE (([Issuer] = @Original_Issuer) AND" +
				" ([SerialNumber] = @Original_SerialNumber))";
			this.sqlDeleteCommand1.Connection = this._cn;
            this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
            this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
// 
// sqlInsertCommand1
// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO [dbo].[GME_Certificate_List] ([Issuer], [SerialNumber], [Subject], [Autenticazione], [Firma], [TSInizioValidita], [TSFineValidita], [TSRegistrazione], [CodiceUtenteRegistrazione], [AbilitatoAutenticazione], [AbilitatoFirma], [ForceAction], [LastError]) VALUES (@Issuer, @SerialNumber, @Subject, @Autenticazione, @Firma, @TSInizioValidita, @TSFineValidita, @TSRegistrazione, @CodiceUtenteRegistrazione, @AbilitatoAutenticazione, @AbilitatoFirma, @ForceAction, @LastError)";
			this.sqlInsertCommand1.Connection = this._cn;
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 0, "SerialNumber"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 0, "Subject"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Autenticazione", System.Data.SqlDbType.Bit, 0, "Autenticazione"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Firma", System.Data.SqlDbType.Bit, 0, "Firma"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSInizioValidita", System.Data.SqlDbType.DateTime, 0, "TSInizioValidita"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSFineValidita", System.Data.SqlDbType.DateTime, 0, "TSFineValidita"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSRegistrazione", System.Data.SqlDbType.DateTime, 0, "TSRegistrazione"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteRegistrazione", System.Data.SqlDbType.VarChar, 0, "CodiceUtenteRegistrazione"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@AbilitatoAutenticazione", System.Data.SqlDbType.Bit, 0, "AbilitatoAutenticazione"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@AbilitatoFirma", System.Data.SqlDbType.Bit, 0, "AbilitatoFirma"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 0, "ForceAction"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastError", System.Data.SqlDbType.VarChar, 0, "LastError"));
// 
// cmdCertificateList_Select
// 
			this.cmdCertificateList_Select.CommandText = @"SELECT     Issuer, SerialNumber, Subject, Autenticazione, Firma, TSInizioValidita, TSFineValidita, TSRegistrazione, CodiceUtenteRegistrazione, 
                      AbilitatoAutenticazione, AbilitatoFirma, ForceAction, LastError
FROM         dbo.GME_Certificate_List
WHERE     (Issuer = @Issuer) AND (SerialNumber = @SerialNumber)";
			this.cmdCertificateList_Select.Connection = this._cn;
            this.cmdCertificateList_Select.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
            this.cmdCertificateList_Select.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"));
// 
// sqlUpdateCommand1
// 
			this.sqlUpdateCommand1.CommandText = @"UPDATE [dbo].[GME_Certificate_List] SET [Issuer] = @Issuer, [SerialNumber] = @SerialNumber, [Subject] = @Subject, [Autenticazione] = @Autenticazione, [Firma] = @Firma, [TSInizioValidita] = @TSInizioValidita, [TSFineValidita] = @TSFineValidita, [TSRegistrazione] = @TSRegistrazione, [CodiceUtenteRegistrazione] = @CodiceUtenteRegistrazione, [AbilitatoAutenticazione] = @AbilitatoAutenticazione, [AbilitatoFirma] = @AbilitatoFirma, [ForceAction] = @ForceAction, [LastError] = @LastError WHERE (([Issuer] = @Original_Issuer) AND ([SerialNumber] = @Original_SerialNumber))";
			this.sqlUpdateCommand1.Connection = this._cn;
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 0, "SerialNumber"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 0, "Subject"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Autenticazione", System.Data.SqlDbType.Bit, 0, "Autenticazione"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Firma", System.Data.SqlDbType.Bit, 0, "Firma"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSInizioValidita", System.Data.SqlDbType.DateTime, 0, "TSInizioValidita"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSFineValidita", System.Data.SqlDbType.DateTime, 0, "TSFineValidita"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSRegistrazione", System.Data.SqlDbType.DateTime, 0, "TSRegistrazione"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteRegistrazione", System.Data.SqlDbType.VarChar, 0, "CodiceUtenteRegistrazione"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@AbilitatoAutenticazione", System.Data.SqlDbType.Bit, 0, "AbilitatoAutenticazione"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@AbilitatoFirma", System.Data.SqlDbType.Bit, 0, "AbilitatoFirma"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 0, "ForceAction"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastError", System.Data.SqlDbType.VarChar, 0, "LastError"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
// 
// daCertificateDistributionPoints
// 
			this.daCertificateDistributionPoints.DeleteCommand = this.sqlDeleteCommand2;
			this.daCertificateDistributionPoints.InsertCommand = this.sqlInsertCommand2;
			this.daCertificateDistributionPoints.SelectCommand = this.sqlSelectCommand2;
			this.daCertificateDistributionPoints.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "GME_Certificate_DistributionPoints", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
                        new System.Data.Common.DataColumnMapping("Url", "Url"),
                        new System.Data.Common.DataColumnMapping("Abilitato", "Abilitato")})});
			this.daCertificateDistributionPoints.UpdateCommand = this.sqlUpdateCommand;
// 
// sqlDeleteCommand2
// 
			this.sqlDeleteCommand2.CommandText = "DELETE FROM [dbo].[GME_Certificate_DistributionPoints] WHERE (([Issuer] = @Origin" +
				"al_Issuer) AND ([Url] = @Original_Url))";
			this.sqlDeleteCommand2.Connection = this._cn;
            this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
            this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Url", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Url", System.Data.DataRowVersion.Original, null));
// 
// sqlInsertCommand2
// 
			this.sqlInsertCommand2.CommandText = "INSERT INTO [dbo].[GME_Certificate_DistributionPoints] ([Issuer], [Url], [Abilita" +
				"to]) VALUES (@Issuer, @Url, @Abilitato)";
			this.sqlInsertCommand2.Connection = this._cn;
            this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Url", System.Data.SqlDbType.VarChar, 0, "Url"));
            this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 0, "Abilitato"));
// 
// sqlSelectCommand2
// 
			this.sqlSelectCommand2.CommandText = "SELECT     Issuer, Url, Abilitato\r\nFROM         dbo.GME_Certificate_DistributionP" +
				"oints\r\nWHERE     (Issuer = @Issuer)";
			this.sqlSelectCommand2.Connection = this._cn;
			this.sqlSelectCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
// 
// sqlUpdateCommand
// 
			this.sqlUpdateCommand.CommandText = "UPDATE [dbo].[GME_Certificate_DistributionPoints] SET [Issuer] = @Issuer, [Url] =" +
				" @Url, [Abilitato] = @Abilitato WHERE (([Issuer] = @Original_Issuer) AND ([Url] " +
				"= @Original_Url))";
			this.sqlUpdateCommand.Connection = this._cn;
            this.sqlUpdateCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlUpdateCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Url", System.Data.SqlDbType.VarChar, 0, "Url"));
            this.sqlUpdateCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 0, "Abilitato"));
            this.sqlUpdateCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
            this.sqlUpdateCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Url", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Url", System.Data.DataRowVersion.Original, null));
// 
// daCertificateRevokationList
// 
			this.daCertificateRevokationList.DeleteCommand = this.sqlDeleteCommand3;
			this.daCertificateRevokationList.InsertCommand = this.sqlInsertCommand3;
			this.daCertificateRevokationList.SelectCommand = this.sqlSelectCommand3;
			this.daCertificateRevokationList.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "GME_Certificate_RevocationList", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
                        new System.Data.Common.DataColumnMapping("SerialNumber", "SerialNumber"),
                        new System.Data.Common.DataColumnMapping("ReasonCode", "ReasonCode"),
                        new System.Data.Common.DataColumnMapping("TSRevoca", "TSRevoca")})});
			this.daCertificateRevokationList.UpdateCommand = this.sqlUpdateCommand3;
// 
// sqlDeleteCommand3
// 
			this.sqlDeleteCommand3.CommandText = "DELETE FROM [dbo].[GME_Certificate_RevocationList] WHERE (([Issuer] = @Original_I" +
				"ssuer) AND ([SerialNumber] = @Original_SerialNumber))";
			this.sqlDeleteCommand3.Connection = this._cn;
            this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
            this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
// 
// sqlInsertCommand3
// 
			this.sqlInsertCommand3.CommandText = "INSERT INTO [dbo].[GME_Certificate_RevocationList] ([Issuer], [SerialNumber], [Re" +
				"asonCode], [TSRevoca]) VALUES (@Issuer, @SerialNumber, @ReasonCode, @TSRevoca)";
			this.sqlInsertCommand3.Connection = this._cn;
            this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 0, "SerialNumber"));
            this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ReasonCode", System.Data.SqlDbType.Int, 0, "ReasonCode"));
            this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSRevoca", System.Data.SqlDbType.DateTime, 0, "TSRevoca"));
// 
// sqlSelectCommand3
// 
			this.sqlSelectCommand3.CommandText = "SELECT     Issuer, SerialNumber, ReasonCode, TSRevoca\r\nFROM         dbo.GME_Certi" +
				"ficate_RevocationList\r\nWHERE     (Issuer = @Issuer)";
			this.sqlSelectCommand3.Connection = this._cn;
			this.sqlSelectCommand3.Parameters.Add(
				new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
// 
// sqlUpdateCommand3
// 
			this.sqlUpdateCommand3.CommandText = "UPDATE [dbo].[GME_Certificate_RevocationList] SET [Issuer] = @Issuer, [SerialNumb" +
				"er] = @SerialNumber, [ReasonCode] = @ReasonCode, [TSRevoca] = @TSRevoca WHERE ((" +
				"[Issuer] = @Original_Issuer) AND ([SerialNumber] = @Original_SerialNumber))";
			this.sqlUpdateCommand3.Connection = this._cn;
            this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 0, "SerialNumber"));
            this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ReasonCode", System.Data.SqlDbType.Int, 0, "ReasonCode"));
            this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSRevoca", System.Data.SqlDbType.DateTime, 0, "TSRevoca"));
            this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
            this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
// 
// daGetCertificateData
// 
			this.daGetCertificateData.SelectCommand = this.sqlSelectCommand4;
			this.daGetCertificateData.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "spGME_GetCertificateData", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("CertificatoForceAction", "CertificatoForceAction"),
                        new System.Data.Common.DataColumnMapping("CertificatoFineValidita", "CertificatoFineValidita"),
						new System.Data.Common.DataColumnMapping("CertificatoAutenticazione", "CertificatoAutenticazione"),
						new System.Data.Common.DataColumnMapping("CertificatoFirma", "CertificatoFirma"),
						new System.Data.Common.DataColumnMapping("CertificatoAbilitatoAutenticazione", "CertificatoAbilitatoAutenticazione"),
                        new System.Data.Common.DataColumnMapping("CertificatoAbilitatoFirma", "CertificatoAbilitatoFirma"),
                        new System.Data.Common.DataColumnMapping("CertificatoCodiceUtenteRegistrazione", "CertificatoCodiceUtenteRegistrazione"),
                        new System.Data.Common.DataColumnMapping("CAAbilitata", "CAAbilitata"),
                        new System.Data.Common.DataColumnMapping("CATSCRLUltimoDownloadTentato", "CATSCRLUltimoDownloadTentato"),
                        new System.Data.Common.DataColumnMapping("CATSCRLDownloadConSuccesso", "CATSCRLDownloadConSuccesso"),
                        new System.Data.Common.DataColumnMapping("CATSCRLInizioValidita", "CATSCRLInizioValidita"),
                        new System.Data.Common.DataColumnMapping("CATSCRLFineValidita", "CATSCRLFineValidita"),
                        new System.Data.Common.DataColumnMapping("CRLReasonCode", "CRLReasonCode"),
                        new System.Data.Common.DataColumnMapping("CRLTSRevoca", "CRLTSRevoca"),
                        new System.Data.Common.DataColumnMapping("NumeroPuntiDiDistribuzione", "NumeroPuntiDiDistribuzione")
																									   })});
// 
// sqlSelectCommand4
// 
			this.sqlSelectCommand4.CommandText = "dbo.spGME_GetCertificateData";
			this.sqlSelectCommand4.CommandType = System.Data.CommandType.StoredProcedure;
			this.sqlSelectCommand4.Connection = this._cn;
            this.sqlSelectCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((byte)(0)), ((byte)(0)), "", System.Data.DataRowVersion.Current, null));
            this.sqlSelectCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256));
            this.sqlSelectCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@sn", System.Data.SqlDbType.VarChar, 64));
// 
// daCertificateCA
// 
			this.daCertificateCA.DeleteCommand = this.sqlDeleteCommand4;
			this.daCertificateCA.InsertCommand = this.sqlInsertCommand4;
			this.daCertificateCA.SelectCommand = this.cmdCertificateCA_Select;
			this.daCertificateCA.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "GME_Certificate_CA", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
                        new System.Data.Common.DataColumnMapping("Abilitata", "Abilitata"),
                        new System.Data.Common.DataColumnMapping("TSCRLUltimoDownloadTentato", "TSCRLUltimoDownloadTentato"),
                        new System.Data.Common.DataColumnMapping("TSCRLDownloadConSuccesso", "TSCRLDownloadConSuccesso"),
                        new System.Data.Common.DataColumnMapping("TSCRLInizioValidita", "TSCRLInizioValidita"),
                        new System.Data.Common.DataColumnMapping("TSCRLFineValidita", "TSCRLFineValidita")})});
			this.daCertificateCA.UpdateCommand = this.sqlUpdateCommand2;
// 
// sqlDeleteCommand4
// 
			this.sqlDeleteCommand4.CommandText = "DELETE FROM [dbo].[GME_Certificate_CA] WHERE (([Issuer] = @Original_Issuer))";
			this.sqlDeleteCommand4.Connection = this._cn;
			this.sqlDeleteCommand4.Parameters.Add(
				new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
// 
// sqlInsertCommand4
// 
			this.sqlInsertCommand4.CommandText = @"INSERT INTO [dbo].[GME_Certificate_CA] ([Issuer], [Abilitata], [TSCRLUltimoDownloadTentato], [TSCRLDownloadConSuccesso], [TSCRLInizioValidita], [TSCRLFineValidita]) VALUES (@Issuer, @Abilitata, @TSCRLUltimoDownloadTentato, @TSCRLDownloadConSuccesso, @TSCRLInizioValidita, @TSCRLFineValidita)";
			this.sqlInsertCommand4.Connection = this._cn;
            this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 0, "Abilitata"));
            this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCRLUltimoDownloadTentato", System.Data.SqlDbType.DateTime, 0, "TSCRLUltimoDownloadTentato"));
            this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCRLDownloadConSuccesso", System.Data.SqlDbType.DateTime, 0, "TSCRLDownloadConSuccesso"));
            this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCRLInizioValidita", System.Data.SqlDbType.DateTime, 0, "TSCRLInizioValidita"));
            this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCRLFineValidita", System.Data.SqlDbType.DateTime, 0, "TSCRLFineValidita"));
// 
// cmdCertificateCA_Select
// 
			this.cmdCertificateCA_Select.CommandText = "SELECT     Issuer, Abilitata, TSCRLUltimoDownloadTentato, TSCRLDownloadConSuccess" +
				"o, TSCRLInizioValidita, TSCRLFineValidita\r\nFROM         dbo.GME_Certificate_CA";
			this.cmdCertificateCA_Select.Connection = this._cn;
// 
// sqlUpdateCommand2
// 
			this.sqlUpdateCommand2.CommandText = @"UPDATE [dbo].[GME_Certificate_CA] SET [Issuer] = @Issuer, [Abilitata] = @Abilitata, [TSCRLUltimoDownloadTentato] = @TSCRLUltimoDownloadTentato, [TSCRLDownloadConSuccesso] = @TSCRLDownloadConSuccesso, [TSCRLInizioValidita] = @TSCRLInizioValidita, [TSCRLFineValidita] = @TSCRLFineValidita WHERE (([Issuer] = @Original_Issuer))";
			this.sqlUpdateCommand2.Connection = this._cn;
            this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 0, "Abilitata"));
            this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCRLUltimoDownloadTentato", System.Data.SqlDbType.DateTime, 0, "TSCRLUltimoDownloadTentato"));
            this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCRLDownloadConSuccesso", System.Data.SqlDbType.DateTime, 0, "TSCRLDownloadConSuccesso"));
            this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCRLInizioValidita", System.Data.SqlDbType.DateTime, 0, "TSCRLInizioValidita"));
            this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCRLFineValidita", System.Data.SqlDbType.DateTime, 0, "TSCRLFineValidita"));
            this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
// 
// daCertificateListAll
// 
			this.daCertificateListAll.DeleteCommand = this.sqlDeleteCommand5;
			this.daCertificateListAll.InsertCommand = this.sqlInsertCommand5;
			this.daCertificateListAll.SelectCommand = this.sqlSelectCommand6;
			this.daCertificateListAll.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "GME_Certificate_List", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
                        new System.Data.Common.DataColumnMapping("SerialNumber", "SerialNumber"),
                        new System.Data.Common.DataColumnMapping("Subject", "Subject"),
                        new System.Data.Common.DataColumnMapping("Autenticazione", "Autenticazione"),
                        new System.Data.Common.DataColumnMapping("Firma", "Firma"),
                        new System.Data.Common.DataColumnMapping("TSInizioValidita", "TSInizioValidita"),
                        new System.Data.Common.DataColumnMapping("TSFineValidita", "TSFineValidita"),
                        new System.Data.Common.DataColumnMapping("TSRegistrazione", "TSRegistrazione"),
                        new System.Data.Common.DataColumnMapping("CodiceUtenteRegistrazione", "CodiceUtenteRegistrazione"),
                        new System.Data.Common.DataColumnMapping("Abilitato", "Abilitato"),
                        new System.Data.Common.DataColumnMapping("ForceAction", "ForceAction"),
                        new System.Data.Common.DataColumnMapping("LastError", "LastError")})});
			this.daCertificateListAll.UpdateCommand = this.sqlUpdateCommand4;
// 
// sqlDeleteCommand5
// 
			this.sqlDeleteCommand5.CommandText = "DELETE FROM [dbo].[GME_Certificate_List] WHERE (([Issuer] = @Original_Issuer) AND" +
				" ([SerialNumber] = @Original_SerialNumber))";
			this.sqlDeleteCommand5.Connection = this._cn;
            this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
            this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
// 
// sqlInsertCommand5
// 
			this.sqlInsertCommand5.CommandText = @"INSERT INTO [dbo].[GME_Certificate_List] ([Issuer], [SerialNumber], [Subject], [Autenticazione], [Firma], [TSInizioValidita], [TSFineValidita], [TSRegistrazione], [CodiceUtenteRegistrazione], [Abilitato], [ForceAction], [LastError]) VALUES (@Issuer, @SerialNumber, @Subject, @Autenticazione, @Firma, @TSInizioValidita, @TSFineValidita, @TSRegistrazione, @CodiceUtenteRegistrazione, @Abilitato, @ForceAction, @LastError)";
			this.sqlInsertCommand5.Connection = this._cn;
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 0, "SerialNumber"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 0, "Subject"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Autenticazione", System.Data.SqlDbType.Bit, 0, "Autenticazione"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Firma", System.Data.SqlDbType.Bit, 0, "Firma"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSInizioValidita", System.Data.SqlDbType.DateTime, 0, "TSInizioValidita"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSFineValidita", System.Data.SqlDbType.DateTime, 0, "TSFineValidita"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSRegistrazione", System.Data.SqlDbType.DateTime, 0, "TSRegistrazione"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteRegistrazione", System.Data.SqlDbType.VarChar, 0, "CodiceUtenteRegistrazione"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 0, "Abilitato"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 0, "ForceAction"));
            this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastError", System.Data.SqlDbType.VarChar, 0, "LastError"));
// 
// sqlSelectCommand6
// 
			this.sqlSelectCommand6.CommandText = @"SELECT     Issuer, SerialNumber, Subject, Autenticazione, Firma, TSInizioValidita, TSFineValidita, TSRegistrazione, CodiceUtenteRegistrazione, ForceAction, 
                      AbilitatoAutenticazione, AbilitatoFirma, LastError
FROM         dbo.GME_Certificate_List";
			this.sqlSelectCommand6.Connection = this._cn;
// 
// sqlUpdateCommand4
// 
			this.sqlUpdateCommand4.CommandText = @"UPDATE [dbo].[GME_Certificate_List] SET [Issuer] = @Issuer, [SerialNumber] = @SerialNumber, [Subject] = @Subject, [Autenticazione] = @Autenticazione, [Firma] = @Firma, [TSInizioValidita] = @TSInizioValidita, [TSFineValidita] = @TSFineValidita, [TSRegistrazione] = @TSRegistrazione, [CodiceUtenteRegistrazione] = @CodiceUtenteRegistrazione, [Abilitato] = @Abilitato, [ForceAction] = @ForceAction, [LastError] = @LastError WHERE (([Issuer] = @Original_Issuer) AND ([SerialNumber] = @Original_SerialNumber))";
			this.sqlUpdateCommand4.Connection = this._cn;
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 0, "Issuer"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 0, "SerialNumber"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 0, "Subject"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Autenticazione", System.Data.SqlDbType.Bit, 0, "Autenticazione"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Firma", System.Data.SqlDbType.Bit, 0, "Firma"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSInizioValidita", System.Data.SqlDbType.DateTime, 0, "TSInizioValidita"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSFineValidita", System.Data.SqlDbType.DateTime, 0, "TSFineValidita"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSRegistrazione", System.Data.SqlDbType.DateTime, 0, "TSRegistrazione"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteRegistrazione", System.Data.SqlDbType.VarChar, 0, "CodiceUtenteRegistrazione"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 0, "Abilitato"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 0, "ForceAction"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastError", System.Data.SqlDbType.VarChar, 0, "LastError"));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
            this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));

		}
		#endregion
	}
}
