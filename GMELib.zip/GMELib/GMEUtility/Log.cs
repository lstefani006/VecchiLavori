﻿#region Using directives

using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text;
using System.Diagnostics;
using System.Xml;
using System.IO;

#endregion

namespace GME
{
	public class Log
	{
		private static Log _sm = new Log();

		private Log()
		{
			Trace.Listeners.Add(new SmTraceListener());
		}


		public static void smError(Exception ex)
		{
			Log.smWrite("Error", ex);
		}
		public static void smError(string message)
		{
			Log.smWrite("Error", message);
		}
		public static void smError(Exception ex, string message)
		{
			Log.smWrite("Error", ex, message);
		}
		public static void smErrorIf(bool condition, Exception ex)
		{
			Log.smWriteIf(condition, "Error", ex);
		}

		public static void smErrorIf(bool condition, string message)
		{
			Log.smWriteIf(condition, "Error", message);
		}

		public static void smErrorIf(bool condition, Exception ex, string message)
		{
			Log.smWriteIf(condition, "Error", ex, message);
		}

		public static void smTrace(Exception ex)
		{
			smTraceIf(smLogSwitch.TraceInfo, ex);
		}

		public static void smTrace(string message)
		{
			smTraceIf(smLogSwitch.TraceInfo, message);
		}

		public static void smTrace(Exception ex, string message)
		{
			smTraceIf(smLogSwitch.TraceInfo, message);
		}

		public static void smTraceIf(bool condition, Exception ex)
		{
			Log.smWriteIf(condition, "Trace", ex);
		}

		public static void smTraceIf(bool condition, string message)
		{
			Log.smWriteIf(condition, "Trace", message);
		}

		public static void smTraceIf(bool condition, Exception ex, string message)
		{
			Log.smWriteIf(condition, "Trace", ex, message);
		}

		public static void smWrite(string category, Exception ex)
		{
			Log.smWrite(category, ex, null);
		}

		public static void smWrite(string category, string message)
		{
			StringWriter writer1 = new StringWriter();
			XmlTextWriter writer2 = new XmlTextWriter(writer1);
			writer2.Formatting = Formatting.Indented;
			writer2.Indentation = 1;
			writer2.IndentChar = '\t';
			writer2.WriteStartDocument();
			writer2.WriteStartElement("Log");
			writer2.WriteStartElement("Category");
			writer2.WriteString(category);
			writer2.WriteEndElement();
			writer2.WriteStartElement("Message");
			writer2.WriteString(message);
			writer2.WriteEndElement();
			writer2.WriteStartElement("Application");
			writer2.WriteString(AppDomain.CurrentDomain.FriendlyName);
			writer2.WriteEndElement();
			writer2.WriteStartElement("TS");
			writer2.WriteString(XmlConvert.ToString(DateTime.Now));
			writer2.WriteEndElement();
			writer2.WriteStartElement("StackTrace");
			writer2.WriteString(Environment.StackTrace);
			writer2.WriteEndElement();
			writer2.WriteEndElement();
			writer2.WriteEndDocument();
			writer2.Flush();
			Trace.Flush();
			Trace.WriteLine(writer1.ToString());
			Trace.Flush();
		}

		public static void smWrite(string category, Exception ex, string message)
		{
			StringWriter writer1 = new StringWriter();
			XmlTextWriter writer2 = new XmlTextWriter(writer1);
			writer2.Formatting = Formatting.Indented;
			writer2.Indentation = 1;
			writer2.IndentChar = '\t';
			writer2.WriteStartDocument();
			writer2.WriteStartElement("Log");
			writer2.WriteStartElement("Category");
			writer2.WriteString(category);
			writer2.WriteEndElement();
			writer2.WriteStartElement("Message");
			if (message != null)
			{
				writer2.WriteString(message);
			}
			writer2.WriteEndElement();
			writer2.WriteStartElement("Application");
			writer2.WriteString(AppDomain.CurrentDomain.FriendlyName);
			writer2.WriteEndElement();
			writer2.WriteStartElement("TS");
			writer2.WriteString(XmlConvert.ToString(DateTime.Now));
			writer2.WriteEndElement();
			Log.WriteElementeException(writer2, ex);
			writer2.WriteStartElement("StackTrace");
			writer2.WriteString(Environment.StackTrace);
			writer2.WriteEndElement();
			writer2.WriteEndElement();
			writer2.WriteEndDocument();
			writer2.Flush();
			Trace.Flush();
			Trace.WriteLine(writer1.ToString());
			Trace.Flush();
		}

		public static void smWriteIf(bool condition, string category, Exception ex)
		{
			if (condition)
			{
				Log.smWrite(category, ex, null);
			}
		}

		public static void smWriteIf(bool condition, string category, string message)
		{
			if (condition)
			{
				Log.smWrite(category, message);
			}
		}

		public static void smWriteIf(bool condition, string category, Exception ex, string message)
		{
			if (condition)
			{
				Log.smWrite(category, ex, message);
			}
		}

		private static void WriteElementeException(XmlTextWriter xw, Exception ex)
		{
			xw.WriteStartElement("Exception");
			xw.WriteStartElement("Message");
			xw.WriteString(ex.Message);
			xw.WriteEndElement();
			xw.WriteStartElement("Source");
			xw.WriteString(ex.Source);
			xw.WriteEndElement();
			xw.WriteStartElement("StackTrace");
			xw.WriteString(ex.StackTrace);
			xw.WriteEndElement();
			if (ex.InnerException != null)
			{
				Log.WriteElementeException(xw, ex.InnerException);
			}
			xw.WriteEndElement();
		}


		/// <summary>
		/// Switch che governa le operazioni di Trace. Utilizzato da 
		/// </summary>
		public static TraceSwitch smLogSwitch = new TraceSwitch("SystemMonitorLogSwitch", "General application trace switch");
	}


	public class SmTraceListener : TraceListener
	{
		public delegate void TraceWriterDelegate(string msg);
		internal static TraceWriterDelegate s_TraceWriter = null;

		/// <summary>
		/// Settare a questa proprieta` il TraceWriter per spedire i messaggi 
		/// ad un DB, WS o qualunque altra cosa.
		/// </summary>
		/// <value></value>
		public static TraceWriterDelegate TraceWriter
		{
			get { return s_TraceWriter; }
			set { s_TraceWriter = value; }
		}


		// Methods
		public SmTraceListener()
		{
			this._sw = new StringWriter();
			this._closed = false;
		}
		public override void  Close()
		{
			this.Flush();
			this._closed = true;
		}

		public override void Flush()
		{
			// qui devo sparare il TRACE: dove? 
			// a livello di libreria non si puo` sapere.
			// Delego ad un delegate
			if (!this._closed)
			{
				try
				{
					this._sw.Flush();
					string msg = this._sw.GetStringBuilder().ToString();
					if (msg.Length != 0)
					{
						// LEO invocare un WS opportuno.
						if (s_TraceWriter != null)
							s_TraceWriter(msg);

						this._sw.GetStringBuilder().Length = 0;
					}
				}
				catch (Exception exception4)
				{
					if (Debugger.IsAttached)
					{
						Debugger.Log(10, "Error", exception4.Message);
						Debugger.Break();
					}
				}
			}

		}

		public override void Write(string message)
		{
			if (!this._closed)
			{
				this._sw.Write(message);
				if (this._sw.GetStringBuilder().Length > 0x400)
				{
					this.Flush();
				}
			}
		}

		public override void WriteLine(string message)
		{
			if (!this._closed)
			{
				this._sw.WriteLine(message);
				if (this._sw.GetStringBuilder().Length > 0x400)
				{
					this.Flush();
				}
			}
		}

		// Fields
		private bool _closed;
		private StringWriter _sw;
	}


	/// <summary>
	/// classe ch
	/// </summary>
	public class SmLogServer
	{
		/// <summary>
		/// Funzione chiamata dal server di remoting (tipicamente xyz_BLWS) per fare log.
		/// In questo modo si evita di scomodare il remoting per fare log dalla stessa applicazione
		/// che e` server di remoting per il log.
		/// </summary>
		/// <param name="msg">il messaggio; puo` essere in formato XML; il formato e` determinato dalla GMEUtility</param>
		/// <param name="cn">connessione al DB da usare. La connessione puo` essere gia` aperta dal chiamante, oppure la funzione la aprira` per poi richiuderla</param>
		public static void WriteMessage(string msg, SqlConnection cn)
		{
			bool xmlMessage = true; // asserisco che il messaggio sia un messaggio in XML
	
			bool cnOpened = cn.State == ConnectionState.Open;

			try
			{
				XmlDocument x = new XmlDocument();

				try
				{
					xmlMessage = true;
					x.LoadXml(msg); // qui da eccezione se il messaggio NON e` in xml
				}
				catch (XmlException)
				{
					xmlMessage = false;
				}

				if (xmlMessage)
				{
					foreach (XmlNode xn in x.SelectNodes("Log"))
					{
						SmLog_Insert cmd = new SmLog_Insert();

						cmd.SmCategory = xn.SelectSingleNode("./Category").InnerText;
						cmd.SmMessage = xn.SelectSingleNode("./Message").InnerText;
						cmd.SmApplication = xn.SelectSingleNode("./Application").InnerText;
						cmd.SmTS = XmlConvert.ToDateTime(xn.SelectSingleNode("./TS").InnerText);

						XmlNode ne = xn.SelectSingleNode("./Exception");
						StringBuilder exMessage = new StringBuilder();
						while (ne != null)
						{
							exMessage.Append(ne.SelectSingleNode("./Message").InnerText);
							exMessage.Append(Environment.NewLine);
							ne = ne.SelectSingleNode("./Exception");
						}

						if (exMessage.Length > 0)
						{
							if (exMessage.Length > 1024)
								cmd.SmExMessage = exMessage.ToString(0, 1024);
							else
								cmd.SmExMessage = exMessage.ToString();
						}
						else
							cmd.SmExMessage = SqlString.Null;

						cmd.SmXmlMessage = Encoding.UTF8.GetBytes(msg);

						if (!cnOpened) cn.Open();
						cmd.Execute(cn);
						if (!cnOpened) cn.Close();

						Console.WriteLine("{0}", "#####################################################");
						Console.WriteLine("{0}", msg);
						Console.WriteLine("{0}", "#####################################################");
					}
				}
			}
#if DEBUG
			catch (SqlException ex)
			{
				// se c'e` un errore di insert inutile provare a salvare di nuovo.
				Debug.Write(ex.Message);
			}
#endif
			catch
			{
				// un errore di codifica...
			}
	
			if (xmlMessage == false)
			{
				try
				{
					SmLog_Insert cmd = new SmLog_Insert();

					cmd.SmCategory = "Trace";
					cmd.SmMessage = msg;
					cmd.SmApplication = "";
					cmd.SmTS = DateTime.Now;
					cmd.SmExMessage = SqlString.Null;
					cmd.SmXmlMessage = SqlBinary.Null;

					if (!cnOpened) cn.Open();
					cmd.Execute(cn);
					if (!cnOpened) cn.Close();
				}
#if DEBUG
				catch (SqlException ex)
				{
					// se c'e` un errore di insert inutile provare a salvare di nuovo.
					// Debug.Write(ex.Message);
					string g = ex.Message;
					g =g.ToLower();
				}
#endif
				catch
				{
				}
			}
		}

		#region SmLog_Insert Wrapper

		/// <summary>
		/// This class is a wrapper for the SmLog_Insert stored procedure.
		/// </summary>
		public class SmLog_Insert
		{
			#region Member Variables

			protected int _recordsAffected = -1;
			protected int _returnValue = 0;
			protected SqlString _smCategory = SqlString.Null;
			protected bool _smCategorySet = false;
			protected SqlString _smMessage = SqlString.Null;
			protected bool _smMessageSet = false;
			protected SqlString _smApplication = SqlString.Null;
			protected bool _smApplicationSet = false;
			protected SqlDateTime _smTS = SqlDateTime.Null;
			protected bool _smTSSet = false;
			protected SqlString _smExMessage = SqlString.Null;
			protected bool _smExMessageSet = false;
			protected SqlBinary _smXmlMessage = SqlBinary.Null;
			protected bool _smXmlMessageSet = false;
			protected SqlInt32 _outSmId = SqlInt32.Null;
			protected bool _outSmIdSet = false;

			#endregion

			#region Constructors

			public SmLog_Insert()
			{
			}

			#endregion

			#region Public Properties

			/// <summary>
			/// Gets the return value from the SmLog_Insert stored procedure.
			/// </summary>
			public int ReturnValue
			{
				get { return _returnValue; }
			}

			/// <summary>
			/// Gets the number of rows changed, inserted, or deleted by execution of the SmLog_Insert stored procedure.
			/// </summary>
			public int RecordsAffected
			{
				get { return _recordsAffected; }
			}

			public SqlString SmCategory
			{
				get { return _smCategory; }
				set
				{
					_smCategory = value;
					_smCategorySet = true;
				}
			}

			public SqlString SmMessage
			{
				get { return _smMessage; }
				set
				{
					_smMessage = value;
					_smMessageSet = true;
				}
			}

			public SqlString SmApplication
			{
				get { return _smApplication; }
				set
				{
					_smApplication = value;
					_smApplicationSet = true;
				}
			}

			public SqlDateTime SmTS
			{
				get { return _smTS; }
				set
				{
					_smTS = value;
					_smTSSet = true;
				}
			}

			public SqlString SmExMessage
			{
				get { return _smExMessage; }
				set
				{
					_smExMessage = value;
					_smExMessageSet = true;
				}
			}

			public SqlBinary SmXmlMessage
			{
				get { return _smXmlMessage; }
				set
				{
					_smXmlMessage = value;
					_smXmlMessageSet = true;
				}
			}

			public SqlInt32 OutSmId
			{
				get { return _outSmId; }
				set
				{
					_outSmId = value;
					_outSmIdSet = true;
				}
			}

			#endregion

			#region Execute Methods

			/// <summary>
			/// This method calls the SmLog_Insert stored procedure.
			/// Description 
			/// </summary>
			public virtual void Execute(SqlConnection cn)
			{
				SqlCommand cmd = cn.CreateCommand();

				try
				{
					cmd.CommandText = "[dbo].[SmLog_Insert]";
					cmd.CommandType = CommandType.StoredProcedure;

					#region Populate Parameters

					SqlParameter prmReturnValue = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
					prmReturnValue.Direction = ParameterDirection.ReturnValue;

					SqlParameter prmSmCategory = cmd.Parameters.Add("@SmCategory", SqlDbType.VarChar);
					prmSmCategory.Direction = ParameterDirection.Input;
					prmSmCategory.Size = 32;
					if (_smCategorySet == true || this.SmCategory.IsNull == false)
					{
						prmSmCategory.Value = this.SmCategory;
					}

					SqlParameter prmSmMessage = cmd.Parameters.Add("@SmMessage", SqlDbType.VarChar);
					prmSmMessage.Direction = ParameterDirection.Input;
					prmSmMessage.Size = 256;
					if (_smMessageSet == true || this.SmMessage.IsNull == false)
					{
						prmSmMessage.Value = this.SmMessage;
					}

					SqlParameter prmSmApplication = cmd.Parameters.Add("@SmApplication", SqlDbType.VarChar);
					prmSmApplication.Direction = ParameterDirection.Input;
					prmSmApplication.Size = 256;
					if (_smApplicationSet == true || this.SmApplication.IsNull == false)
					{
						prmSmApplication.Value = this.SmApplication;
					}

					SqlParameter prmSmTS = cmd.Parameters.Add("@SmTS", SqlDbType.DateTime);
					prmSmTS.Direction = ParameterDirection.Input;
					if (_smTSSet == true || this.SmTS.IsNull == false)
					{
						prmSmTS.Value = this.SmTS;
					}

					SqlParameter prmSmExMessage = cmd.Parameters.Add("@SmExMessage", SqlDbType.VarChar);
					prmSmExMessage.Direction = ParameterDirection.Input;
					prmSmExMessage.Size = 1024;
					if (_smExMessageSet == true || this.SmExMessage.IsNull == false)
					{
						prmSmExMessage.Value = this.SmExMessage;
					}

					SqlParameter prmSmXmlMessage = cmd.Parameters.Add("@SmXmlMessage", SqlDbType.Image);
					prmSmXmlMessage.Direction = ParameterDirection.Input;
					if (_smXmlMessageSet == true || this.SmXmlMessage.IsNull == false)
					{
						prmSmXmlMessage.Value = this.SmXmlMessage;
					}

					SqlParameter prmOutSmId = cmd.Parameters.Add("@OutSmId", SqlDbType.Int);
					if (_outSmIdSet == true)
					{
						prmOutSmId.Direction = ParameterDirection.InputOutput;
					}
					else
					{
						prmOutSmId.Direction = ParameterDirection.Output;
					}
					if (_outSmIdSet == true || this.OutSmId.IsNull == false)
					{
						prmOutSmId.Value = this.OutSmId;
					}

					#endregion

					#region Execute Command

					_recordsAffected = cmd.ExecuteNonQuery();

					#endregion

					#region Get Output Parameters

					if (prmReturnValue.Value != null && prmReturnValue.Value != DBNull.Value)
					{
						_returnValue = (int) prmReturnValue.Value;
					}

					if (prmOutSmId != null && prmOutSmId.Value != null)
					{
						if (prmOutSmId.Value is SqlInt32)
						{
							this.OutSmId = (SqlInt32) prmOutSmId.Value;
						}
						else
						{
							if (prmOutSmId.Value != DBNull.Value)
							{
								this.OutSmId = new SqlInt32((int) prmOutSmId.Value);
							}
							else
							{
								this.OutSmId = SqlInt32.Null;
							}
						}
					}
					else
					{
						this.OutSmId = SqlInt32.Null;
					}

					#endregion
				}
				finally
				{
					cmd.Dispose();
				}
			}

			/// <summary>
			/// This method calls the SmLog_Insert stored procedure.
			/// </summary>
			/// <param name="cn">La connessione da usare</param>
			/// <param name="smCategory"></param>
			/// <param name="smMessage"></param>
			/// <param name="smApplication"></param>
			/// <param name="smTS"></param>
			/// <param name="smExMessage"></param>
			/// <param name="smXmlMessage"></param>
			/// <param name="outSmId"></param>
			public static void Execute(

				#region Parameters

				SqlConnection cn,
				SqlString smCategory,
				SqlString smMessage,
				SqlString smApplication,
				SqlDateTime smTS,
				SqlString smExMessage,
				SqlBinary smXmlMessage,
				ref SqlInt32 outSmId

				#endregion

				)
			{
				SmLog_Insert smLog_Insert = new SmLog_Insert();

				#region Assign Property Values

				smLog_Insert.SmCategory = smCategory;
				smLog_Insert.SmMessage = smMessage;
				smLog_Insert.SmApplication = smApplication;
				smLog_Insert.SmTS = smTS;
				smLog_Insert.SmExMessage = smExMessage;
				smLog_Insert.SmXmlMessage = smXmlMessage;
				smLog_Insert.OutSmId = outSmId;

				#endregion

				smLog_Insert.Execute(cn);

				#region Get Property Values

				outSmId = smLog_Insert.OutSmId;

				#endregion
			}

			#endregion
		}

		#endregion
		
	}

}
