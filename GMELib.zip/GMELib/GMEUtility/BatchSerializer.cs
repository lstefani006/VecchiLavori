using System;
using System.Collections;
using System.Diagnostics;
using System.Text;
using System.Threading;
using GME.BL;

namespace GME.BS
{
	public class BatchInfo : BLBase
	{
		public BatchInfo(WaitCallback ws, object state, string code, string description, DateTime tsFlowDate, 
							string starterOperator, string starterUser)
		{
			this._ws = ws;
			this._st = state;
			this._descr = description;
			this._code = code;
			this._starterOperator = starterOperator;
			this._starterUser = starterUser;
			if (tsFlowDate == DateTime.MaxValue || tsFlowDate == DateTime.MinValue)
			{
				this._flowdt = DateTime.MinValue;
			}
			else
			{
				this._flowdt = tsFlowDate;
			}
			this._Status = Status.N;
		}

		public string Msg(string m)
		{
			StringBuilder sb = new StringBuilder();
			if (!(this.BatchId == null))
			{
				sb.AppendFormat("BatchId={0} ", this.BatchId);
			}
			else
			{
				sb.AppendFormat("BatchId=<null> ");
			}
			if (this._flowdt != DateTime.MinValue && this._flowdt != DateTime.MaxValue)
			{
				sb.AppendFormat("FlowDate={0:ddMMyyyy} ", this._flowdt);
			}
			sb.AppendFormat("Code {0} ", this._code);
			sb.AppendFormat("Status {0} ", this._Status);
			if (!(m == null))
			{
				sb.Append(m);
			}
			return sb.ToString();
		}

		public enum Status
		{
			N,
			Q,
			R,
			E,
			A
		}

		private DateTime _flowdt;
		private string _code;
		private WaitCallback _ws;
		private object _st;
		private string _descr;
		private AutoResetEvent _evEnd;
		private AutoResetEvent _evAbort;
		private AutoResetEvent _evException;
		public Status _Status;
		public string _starterOperator;
		public string _starterUser;
		public string BatchId;

		public string BatchCode
		{
			get { return this._code; }
		}

		public string Description
		{
			get { return this._descr; }
		}

		public DateTime FlowDate
		{
			get { return this._flowdt; }
		}

		public void z__SetEndWorkEvent(AutoResetEvent evEnd, AutoResetEvent evAbort, AutoResetEvent evException)
		{
			_evEnd = evEnd;
			_evAbort = evAbort;
			_evException = evException;
		}

		public void z__Run()
		{
			try
			{
				m_BatchInfo = this;
				_ws(_st);
				_evEnd.Set();
			}
			catch (ThreadAbortException ex)
			{
				//
				// serve per marcare l'eccezione
				//
				BatchSerializer.SetProgressBatch(ex.Message);
				Debug.Write(ex.Message);
			}
			catch (Exception ex)
			{
				BatchSerializer.SetProgressBatch(ex.Message);
				_evException.Set();
			}
		}

		public void z__Abort()
		{
			if (!(_evAbort == null))
			{
				_evAbort.Set();
			}
		}

		[ThreadStatic()] public static BatchInfo m_BatchInfo;
	}

	public class BatchSerializer : BLBase
	{
		public static BatchSerializer BS = new BatchSerializer();
		private static Type _t_BatchStatus = null;

		public static void InitBatchSerializer()
		{
			BS = new BatchSerializer();
		}

		public Type BatchStatus
		{
			get { return _t_BatchStatus; }
			set { _t_BatchStatus = value; }
		}

		public static void InitBatchSerializer(Type batchStatus)
		{
			BS = new BatchSerializer();
			_t_BatchStatus = batchStatus;
		}

		public static void DestroyBatchSerializer()
		{
			if (!(BS == null))
			{
				BS.Close();
			}
			BS = null;
		}

		private Queue queueBI = new Queue();
		private Thread th;
		private int MaxCount = 100;
		private AutoResetEvent[] _ev = new AutoResetEvent[3];

		private BatchSerializer()
		{
			_ev[0] = null;
			_ev[1] = null;
			_ev[2] = null;
			ThreadStart ts = new ThreadStart(this.WaitAndDoNextWork);
			th = new Thread(ts);
			th.IsBackground = true;
			th.Start();
		}

		public void Close()
		{
			if (!(th == null))
			{
				th.Abort();
				th.Join();
				th = null;
			}
		}

		public int PendingBatches()
		{
			lock (this)
			{
				return this.queueBI.Count;
			}
		}

		public void Clear()
		{
			lock (this)
			{
				this.queueBI.Clear();
			}
		}

		public BatchInfo AddBatch(WaitCallback ws, object st, string code, string descr, 
									DateTime dtFlowDate, string starterOperator, 
									string starterUser)
		{
			BatchInfo r = new BatchInfo(ws, st, code, descr, dtFlowDate, starterOperator, starterUser);
			AddBatch(r);
			return r;
		}

		private void AddBatch(BatchInfo bi)
		{
			lock (this)
			{
				while (this.queueBI.Count >= MaxCount)
				{
					Monitor.Wait(this);
				}
				try
				{
					QueueBatch(bi);
				}
				catch
				{
				}
				this.queueBI.Enqueue(bi);
				if (this.queueBI.Count == 1)
				{
					Monitor.PulseAll(this);
				}
			}
		}

		private enum BatchReturn
		{
			Normal,
			Abort,
			Exception
		}


		public void WaitAndDoNextWork()
		{
			do
			{
				BatchInfo bi;
				int nq;
				lock (this)
				{
					while (this.queueBI.Count == 0)
					{
						Monitor.Wait(this);
					}
					nq = this.queueBI.Count;
					bi = ((BatchInfo) (this.queueBI.Dequeue()));
					if (this.queueBI.Count == MaxCount - 1)
					{
						Monitor.PulseAll(this);
					}
				}
				try
				{
					this.StartBatch(bi);
				}
				catch
				{
				}

				BatchReturn br = BatchReturn.Normal;
				try
				{
					//
					// _ev[0]: evento di Morte Naturale del thread
					// _ev[1]: evento di Abort 
					// _ev[2]: evento di Eccezione
					//
					lock (this)
					{
						_ev[0] = new AutoResetEvent(false);
						_ev[1] = new AutoResetEvent(false);
						_ev[2] = new AutoResetEvent(false);
					}

					bi.z__SetEndWorkEvent(_ev[0], _ev[1], _ev[2]);
					Thread twh;
					ThreadStart ts = new ThreadStart(bi.z__Run);
					twh = new Thread(ts);
					twh.IsBackground = true;
					twh.Start();

					//
					// Attende segnalazione di uno degli eventi:
					//  Morte Normale (nEv=0)
					//  Abort (nEv=1)
					//  Eccezione (nEv=2)
					//
					int nEv = AutoResetEvent.WaitAny(_ev);
					if (nEv == 1)
					{
						// abort
						if (twh.IsAlive)
						{
							twh.Abort();
							twh.Join();
						}
						br = BatchReturn.Abort;
					}
					else if (nEv == 0)
					{
						// normal - uscita normale dal batch
						if (twh.IsAlive)
							twh.Join();
						br = BatchReturn.Normal;
					}
					else if (nEv == 2)
					{
						// eccezione dal batch

						if (twh.IsAlive)
							twh.Join();

						br = BatchReturn.Exception;
					}
				}
				catch (Exception Ex)
				{
					Debug.WriteLine(Ex.Message);
				}

				try
				{
					this.EndBatch(bi, br == BatchReturn.Exception || br == BatchReturn.Abort, "");
				}
				catch
				{
				}
				bi = null;

				//
				// Leo Docet: teoricamente dovrebbe recuperare memoria dal Garbage Collector
				/*
				if (GC.GetTotalMemory(false) > 100 * 1024 * 1024) 
				{ 
					if (GME.Utility.AppSettings.ToBoolean("GG_Collect", false)) 
					{ 
						GC.Collect(); 
						if (GME.Utility.AppSettings.ToBoolean("GG_WaitForPendingFinalizers", false)) 
						{ 
							GC.WaitForPendingFinalizers(); 
						} 
					} 
				} 
				*/
			} while (true);
		}

		public void AbortBatch(BatchInfo bi)
		{
			int nq = -1;
			lock (this)
			{
				//
				// Se sto abortendo un work ancora in coda (da processare)
				// lo devo togliere dalla coda 
				// 
				if (this.queueBI.Contains(bi))
				{
					//
					// work ancora in coda
					//
					Queue nbi = new Queue();
					while (this.queueBI.Count > 0)
					{
						BatchInfo b = ((BatchInfo) (this.queueBI.Dequeue()));
						if (!(b == bi))
						{
							nbi.Enqueue(b);
						}
					}
					this.queueBI = nbi;
					nq = this.queueBI.Count;
				}
				else
				{
					//
					// work non piu' in coda: e' in corso di elaborazione
					// lancio un Abort
					//
					bi.z__Abort();
				}
			}
			try
			{
				//
				// nq>0 significa che sono andato a togliere un work dalla coda
				// devo settare sul DB lo stato di Aborted
				//
				if (nq >= 0)
				{
					this.EndBatch(bi, true, "");
				}
			}
			catch
			{
			}
		}

		//
		// Factory della classe che implementa il BatchStatus
		//
		private static IBatchStatus CreateBatchStatus()
		{
			IBatchStatus m = null;
			if (_t_BatchStatus != null)
			{
				m = (IBatchStatus) Activator.CreateInstance(_t_BatchStatus, null);
			}
			return m;
		}
		private static void QueueBatch(BatchInfo bi)
		{
			//BatchStatus s = new BatchStatus(); 
			IBatchStatus s = CreateBatchStatus();
			string d = string.Empty;

			/*
			** LAZZ: i campi starterOperator e starterUser possono essere messi nel DB con la NewBatch
			** non ha piu' molto senso aggiungerli come prefissi alla descrizione
			** 
			if (!(bi._starterOperator == null))
			{
				d += bi._starterOperator + ": ";
			}
			if (!(bi._starterUser == null))
			{
				d += bi._starterUser + ": ";
			}
			*/
			d = bi.Description;
			if (s != null)
			{
				bi.BatchId = s.NewBatch(bi.BatchCode, d, bi.FlowDate, bi._starterOperator, bi._starterUser);
				bi._Status = BatchInfo.Status.Q;
				Log.smTrace(bi.Msg(null));
			}
		}

		private void StartBatch(BatchInfo bi)
		{
			// BatchStatus s = new BatchStatus(); 
			IBatchStatus s = CreateBatchStatus();
			if (s != null)
			{
				s.StartBatch(bi.BatchId);
			}
			bi._Status = BatchInfo.Status.R;
			Log.smTrace(string.Format("BatchId={0}: started", bi.BatchId));
		}

		private void EndBatch(BatchInfo bi, bool aborted, string message)
		{
			// BatchStatus s = new BatchStatus(); 
			IBatchStatus s = CreateBatchStatus();
			if (s != null)
			{
				s.EndBatch(bi.BatchId, aborted);
			}
			if (aborted)
			{
				bi._Status = BatchInfo.Status.A;
			}
			else
			{
				bi._Status = BatchInfo.Status.E;
			}
			if (aborted)
			{
				Log.smError(bi.Msg(message));
			}
			else
			{
				Log.smTrace(bi.Msg(message));
			}
		}

		public static void SetProgressBatch(string progressMsg)
		{
			BatchInfo bi = BatchInfo.m_BatchInfo;
			if (!((bi == null || bi.BatchId == null)))
			{
				Log.smTrace(bi.Msg(progressMsg));
			}
			else
			{
				Log.smTrace(progressMsg);
			}
			if (bi != null)
			{
				if (bi.BatchId != null)
				{
					// BatchStatus s = new BatchStatus(); 
					IBatchStatus s = CreateBatchStatus();
					if (s != null)
					{
						s.UpdateProgress(bi.BatchId, progressMsg);
					}
				}
			}
		}

		public static void SetProgressBatch(Exception ex)
		{
			BatchInfo bi = BatchInfo.m_BatchInfo;
			if (bi != null)
			{
				if (bi.BatchId != null)
				{
					// BatchStatus s = new BatchStatus(); 
					IBatchStatus s = CreateBatchStatus();
					if (s != null)
					{
						s.UpdateProgress(bi.BatchId, ex.Message);
					}
				}
			}
			if ((bi != null) && (bi.BatchId != null))
			{
				Log.smTrace(ex, bi.Msg(null));
			}
			else
			{
				Log.smTrace(ex, null);
			}
		}
	}
}