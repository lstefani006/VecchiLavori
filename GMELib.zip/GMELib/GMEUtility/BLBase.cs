﻿#region Using directives

using System;
using System.Text;
using System.ComponentModel;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;
using System.Data.OracleClient;

#endregion

namespace GME.BL
{
	public class BLBase : Component
	{
		#region Funzioni d'aiuto per il DB
		// 
		/// <summary>
		/// proprieta` per ottenere la connessione al db 
		/// </summary>
		/// <value>la stringa di connessione</value>
		public static string SqlConnectionstring
		{
			get
			{
				string s = GME.Utility.AppSettings.ToString("SqlConnectionstring");
				if (s == null)
				{
					GME.Log.smError("La businnes logic e` stata istanziata nel cliente e non nel server.\n" +
					 "Probabilmente il file app.config del server o il file BL.config del client sono errati");
					throw new ApplicationException("File di configurazione del Remoting ERRATO!");
				}
				return s;
			}
		}
		public static string OracleConnectionstring
		{
			get
			{
				string s = GME.Utility.AppSettings.ToString("OracleConnectionstring");
				if (s == null)
				{
					GME.Log.smError("La businnes logic e` stata istanziata nel cliente e non nel server.\n" +
					 "Probabilmente il file app.config del server o il file BL.config del client sono errati");
					throw new ApplicationException("File di configurazione del Remoting ERRATO!");
				}
				return s;
			}
		}


		/// <summary>
		/// Imposta la transazione ai vari SqlCommand associati al data adapter
		/// </summary>
		/// <param name="da">il data adapter in questione</param>
		/// <param name="tr">la transazione da associare; puo` essere null</param>
		public static void SetTransaction(SqlDataAdapter da, SqlTransaction tr)
		{
			if (da.SelectCommand != null)
				da.SelectCommand.Transaction = tr;
			if (da.InsertCommand != null)
				da.InsertCommand.Transaction = tr;
			if (da.DeleteCommand != null)
				da.DeleteCommand.Transaction = tr;
			if (da.UpdateCommand != null)
				da.UpdateCommand.Transaction = tr;
		}
		/// <summary>
		/// Imposta la transazione ai vari OracleCommand associati al data adapter 
		/// </summary>
		/// <param name="da">il data adapter in questione</param>
		/// <param name="tr">la transazione da associare; puo` essere null</param>
		public static void SetTransaction(OracleDataAdapter da, OracleTransaction tr)
		{
			if (da.SelectCommand != null)
				da.SelectCommand.Transaction = tr;
			if (da.InsertCommand != null)
				da.InsertCommand.Transaction = tr;
			if (da.DeleteCommand != null)
				da.DeleteCommand.Transaction = tr;
			if (da.UpdateCommand != null)
				da.UpdateCommand.Transaction = tr;
		}


		/// <summary>
		/// Imposta il timeout ai vari SqlCommand del data adapter
		/// </summary>
		/// <param name="da">il data adapter in questione</param>
		/// <param name="secTimeout">timeout secondi</param>
		public static void SetTimeout(SqlDataAdapter da, int secTimeout)
		{
			if (da.SelectCommand != null)
				da.SelectCommand.CommandTimeout = secTimeout;
			if (da.InsertCommand != null)
				da.InsertCommand.CommandTimeout = secTimeout;
			if (da.DeleteCommand != null)
				da.DeleteCommand.CommandTimeout = secTimeout;
			if (da.UpdateCommand != null)
				da.UpdateCommand.CommandTimeout = secTimeout;
		}

		/// <summary>
		/// Imposta il timeout ai vari OracleCommand del data adapter
		/// </summary>
		/// <param name="da">il data adapter in questione</param>
		/// <param name="secTimeout">timeout secondi</param>
//		public static void SetTimeout(OracleDataAdapter da, int secTimeout)
//		{
//			if (da.SelectCommand != null)
//				da.SelectCommand.CommandTimeout = secTimeout;
//			if (da.InsertCommand != null)
//				da.InsertCommand.CommandTimeout = secTimeout;
//			if (da.DeleteCommand != null)
//				da.DeleteCommand.CommandTimeout = secTimeout;
//			if (da.UpdateCommand != null)
//				da.UpdateCommand.CommandTimeout = secTimeout;
//		}

		#endregion


		#region Logging methods

		protected void smError(string message)
		{
			GME.Log.smError(message);
		}

		protected void smError(Exception ex)
		{
			GME.Log.smError(ex);
		}

		protected void smError(Exception ex, string message)
		{
			GME.Log.smError(ex, message);
		}

		protected void smErrorIf(bool condition, string message)
		{
			GME.Log.smErrorIf(condition, message);
		}

		protected void smErrorIf(bool condition, Exception ex)
		{
			GME.Log.smErrorIf(condition, ex);
		}

		protected void smErrorIf(bool condition, Exception ex, string message)
		{
			GME.Log.smErrorIf(condition, ex, message);
		}

		protected void smTrace(string message)
		{
			GME.Log.smTrace(message);
		}

		protected void smTrace(Exception ex)
		{
			GME.Log.smTrace(ex);
		}

		protected void smTrace(Exception ex, string message)
		{
			GME.Log.smTrace(ex, message);
		}

		protected void smTraceIf(bool condition, string message)
		{
			GME.Log.smTraceIf(condition, message);
		}

		protected void smTraceIf(bool condition, Exception ex)
		{
			GME.Log.smTraceIf(condition, ex);
		}

		protected void smTraceIf(bool condition, Exception ex, string message)
		{
			GME.Log.smTraceIf(condition, ex, message);
		}
		#endregion
	}
}
