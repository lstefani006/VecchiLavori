using System;
using System.Collections;
using System.Reflection;

namespace GME.Utility
{
	public class AppSettings
	{

		/// <summary>
		/// Impostare appSett alla NameValueCollection negli SMART CLIENT
		/// quando questi devono leggere prima da un file XML e poi dall'app.config
		/// </summary>
		static public System.Collections.Specialized.NameValueCollection AlternateAppSettings = null;
		static public Hashtable AlternateCustomSettings = null;

		public static void LoadAlternateConfigFile(string configFile)
		{
			AlternateConfig.LoadConfigFile(configFile);

			AlternateAppSettings = AlternateConfig.AppSettings;
			AlternateCustomSettings = AlternateConfig.CustomConfig;
		}

		public static object GetConfig(string s)
		{
			object r = null;

			if (AlternateCustomSettings != null)
				r = AlternateCustomSettings[s];

			if (r == null)
				r = System.Configuration.ConfigurationSettings.GetConfig(s);

			return r;
		}

		public static string ToString(string s)
		{
			string v = null;

			if (AlternateAppSettings != null)
				v = AlternateAppSettings[s];

			if (v == null)
				v = System.Configuration.ConfigurationSettings.AppSettings[s];

			return v;
		}

		public static int ToInt32(string s, int defaultValue)
		{
			string v = ToString(s);

			if (v == null)
				return defaultValue;
			try
			{
				return int.Parse(v);
			}
			catch
			{
			}
			return defaultValue;
		}

		public static string ToString(string s, string defaultValue)
		{
			string v = ToString(s);

			if (v != null)
				return v;
			return defaultValue;
		}
		public static bool ToBoolean(string s)
		{
			return ToBoolean(s, true);
		}
		public static bool ToBoolean(string s, bool defaultValue)
		{
			string v = ToString(s);

			if (v != null)
			{
				v = v.ToLower();
				v = v.Trim();
				switch (v)
				{
					case "1":
					case "si":
					case "s":
					case "yes":
					case "y":
					case "true":
					case "t":
					case "vero":
					case "v":
						return true;

					case "0":
					case "no":
					case "n":
					case "false":
					case "f":
					case "falso":
						return false;

					default:
						return defaultValue;
				}
			}
			return defaultValue;
		}
	}



	public class DateTimeUtilities
	{
		public readonly static DateTime dtMaxSmallDateTime = new DateTime(2079, 6, 6).Date;

		// fantastica funzione che ritorna il numero di ore che vi sono nel giorno passato come parametro
		public static byte GetNumberOfHourOfDay(DateTime dt)
		{
			// l'ora legale capita di Domenica l'ultima di marzo e l'ultima di ottobre

			// 25 26 27 27 29 30 31   <-- marzo e ottobre hanno 31 giorni
			// D  L  M  M  G  V  S
			//    D  L  M  M  G  V
			//       D  L  M  M  G    ecc
			if (dt.Day < 25)
				return 24;			// dato che siamo prima del 25 non cado nei possibili giorni dell'ora legale

			int m = dt.Month;
			if (!(m == 3 || m == 10))
				return 24; // non siamo a marzo/ottobre

			// siamo in marzo o in ottobre

			if (dt.DayOfWeek != DayOfWeek.Sunday)
				return 24; // ma non e` domenica --> 24h

			// e` domenica ed e` l'ultima del mese di marzo o ottobre
			if (m == 3)
				return 23; // di marzo

			return 25;		  // di ottobre
		}
	}


	public class ReflectionUtilities
	{
		public static void SetField(object obj, string fieldName, object v)
		{
			Type ty = obj.GetType();

			PropertyInfo pi = ty.GetProperty(fieldName);
			if (pi != null)
			{
				Type tipoHeader = pi.PropertyType;
				pi.SetValue(obj, v, null);
				return;
			}
			FieldInfo mi = ty.GetField(fieldName);
			if (mi != null)
			{
				Type tipoHeader = mi.FieldType;
				mi.SetValue(obj, v);
				return;
			}

			throw new ArgumentException("L'oggetto <obj> non ha il field", fieldName);
		}

		public static Type GetFieldType(Type ty, string fieldName)
		{
			PropertyInfo pi = ty.GetProperty(fieldName);
			if (pi != null)
				return pi.PropertyType;

			FieldInfo mi = ty.GetField(fieldName);
			if (mi != null)
				return mi.FieldType;

			throw new ArgumentException("L'oggetto <obj> non ha il field", fieldName);
		}

		public static object CreateObject(Type ty)
		{
			return ty.Assembly.CreateInstance(ty.FullName);
		}
	}


}