using System;
using System.Collections;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using GME.Net;
using GME.Utility;

namespace GME.Remoting
{
	public class ClientSecurity
	{
		public static void Setup(MarshalByRefObject rm, string configName)
		{
			string WSServer = ReadAppSettings(configName + "_Server");

			if (WSServer == null)
				WSServer = configName;

			string UserName = ReadAppSettings(WSServer + "_UserName");
			string Password = ReadAppSettings(WSServer + "_Password");
			string Domain = ReadAppSettings(WSServer + "_Domain");

			// per sopportare i problemi del certificato lato server
			string CertProblems = ReadAppSettings(WSServer + "_CertProblems");

			// string ProxyUser = ReadAppSettings(WSServer + "_ProxyUser", nvc);
			// string ProxyPwd = ReadAppSettings(WSServer + "_ProxyPwd", nvc);
			// string ProxyDomain = ReadAppSettings(WSServer + "_ProxyDomain", nvc);
			// string ProxyPort = ReadAppSettings(WSServer + "_ProxyPort", nvc);

			IDictionary id = ChannelServices.GetChannelSinkProperties(rm);
			id["username"] = UserName;
			id["password"] = Password;
			id["domain"] = Domain;

			string uri = RemotingServices.GetObjectUri(rm);
			if (CertProblems != null && CertProblems != string.Empty)
				CustomCertificatePolicy.Add(uri, CertProblems);
		}


		internal static string ReadAppSettings(string key)
		{
			string r = AppSettings.ToString(key);
			return r;
		}

	}
}