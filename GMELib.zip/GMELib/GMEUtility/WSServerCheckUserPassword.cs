using System.Collections.Specialized;

namespace GME.Web
{

	/// <summary>
	/// Summary description for WSServerCheckUserPassword.
	/// </summary>
	internal class WSServerCheckUserPassword
	{
		public static void CheckUserPassword(WSAuthHeader soapHeader)
		{
			if (soapHeader == null)
				throw new AuthenticationException("Autenticazione non fornita: utente non Abilitato");

			StringCollection roles = new StringCollection();
			if (CheckUserPassword(soapHeader.Username, soapHeader.Password, roles) == false)
			{
				BusinessPrincipal.SetWSPrincipal(null, null);
				throw new AuthenticationException("UserName = [" + soapHeader.Username + "] Password = [" + soapHeader.Password + "] Non Abilitato");
			}

			BusinessPrincipal.SetWSPrincipal(soapHeader.Username, roles);
		}

		#region Implementation
		private static bool CheckUserPassword(string user, string password, StringCollection roles)
		{
			//
			// ottieni il numero di utenti abilitati all'accesso
			//
			string sUsersAllowed = GME.Utility.AppSettings.ToString("UserAllowed_Count");
			int countUsersAllowed = 0;
			try
			{
				countUsersAllowed = int.Parse(sUsersAllowed);
			}
			catch
			{
			}
			//
			// controlla se l'utente e' compreso nella lista degli utenti abilitati
			//
			for (int i = 0; i < countUsersAllowed; i++)
			{
				string usI = GME.Utility.AppSettings.ToString("UserName_" + i.ToString());
				string passI = GME.Utility.AppSettings.ToString("Password_" + i.ToString());
				if ((user == usI) && (password == passI))
				{
					GetRoles(i, roles);
					return true;
				}
			}
			return false;
		}

		private static void GetRoles(int i, StringCollection roles)
		{
			string role = GME.Utility.AppSettings.ToString("Roles_" + i.ToString());
			if (role == null || role.Length == 0)
				return;

			string [] ar = role.Split(';');
			foreach (string s in ar)
			{
				if (s.Length > 0) roles.Add(s);
			}
		}
		#endregion
	}
}
