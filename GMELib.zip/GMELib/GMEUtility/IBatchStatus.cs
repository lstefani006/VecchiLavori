using System;

namespace GME.BS
{


	/// <summary>
	/// Summary description for IBatchStatus.
	/// </summary>
	public interface IBatchStatus
	{
		string NewBatch(string BatchCode, string descr, DateTime tsDataFlusso, 
						string sOperator, string sUser);
		void StartBatch(string BatchId);
		void EndBatch(string BatchId, bool aborted);
		void UpdateProgress(string BatchId, string Progress);
		DS_BatchStatus QueryBatchDelGiorno(DateTime d);
		void DeleteBatchAE();
		bool GetRefreshMode(); 
	}
}
