using System;
using System.Collections.Specialized;
using System.Runtime.Serialization;
using System.Security.Principal;
using System.Threading;

namespace GME.Web
{
	/// <summary>
	/// interfaccia da derivare in una classe per ottenere una strategia
	/// di authenticazione custom
	/// </summary>
	public interface IAuthenticate
	{
		void CheckClientCertificate(System.Web.HttpRequest request);
		void CheckUserPassword(WSAuthHeader authHeader);
	}

	/// <summary>
	/// Eccezione lanciata quando l'autenticazione fallisce
	/// </summary>
	[Serializable]
	public class AuthenticationException : ApplicationException
	{
		public AuthenticationException(string msg) : base(msg) {}

		public AuthenticationException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData(info, context);
		}
	}

	#region Funzioni per gestire l'autenticazione ad un WS

	/// <summary>
	/// Funzioni per gestire l'autenticazione dei WS.
	/// </summary>
	public class WSServerCheckAuth
	{
		/// <summary>
		///	CheckAuth: se il certificato e' presente controlla l'autenticazione su certificato
		///	altrimenti controlla username e password.
		/// Da chiamare come prima funzione di ogni metodo esposto dal WebService.
		/// <code>GME.Web.ServerSecurity.WSServerCheckAuth.CheckAuth(Context.Request, authHeader);</code>
		/// </summary>
		/// <param name="context"></param>
		/// <param name="authHeader"></param>
		public static void CheckAuth(System.Web.HttpContext context, WSAuthHeader authHeader)
		{
			if (context.Session != null && context.Session["GME-ClientLogged"] != null)
				return;

			if (context.Request.ClientCertificate.IsPresent)
				_IAuthenticate.CheckClientCertificate(context.Request);
			else
				_IAuthenticate.CheckUserPassword(authHeader);

			if (context.Session != null)
				context.Session["GME-ClientLogged"] = string.Empty;
		}

		/// <summary>
		/// Per ottenere l'IPrincipal
		/// </summary>
		public static IPrincipal Principal
		{
			get { return Thread.CurrentPrincipal; }
		}



		/// <summary>
		/// property che consente di impostare una strategia custom per l'autenticazione
		/// sia con login/password che con i certificati digitali lato cliente.
		/// </summary>
		/// <value>l'interfaccia per autenticare il cliente</value>
		public static IAuthenticate Authenticate
		{
			get { return _IAuthenticate; }
			set { _IAuthenticate = value; }
		}

		#region Implementation
		static private IAuthenticate _IAuthenticate = new AppConfigAuthenticate();

		internal class AppConfigAuthenticate : IAuthenticate
		{
			void IAuthenticate.CheckClientCertificate(System.Web.HttpRequest request)
			{
				WSServerCheckCertificate.CheckClientCertificate(request);
			}

			void IAuthenticate.CheckUserPassword(WSAuthHeader authHeader)
			{
				WSServerCheckUserPassword.CheckUserPassword(authHeader);
			}
		}

		#endregion
	}

	#endregion


	#region funzioni per gestire l'accesso ad un sito Web Forms
	public class WebFormAuth
	{
		/// <summary>
		/// Chiamare questa funzione da Global.asax evento Global_AcquireRequestState(...).
		/// In questo modo si controlla al volo se la sessione e` scaduta. Se si, viene l'utente
		/// automaticamente rediretto alla pagina di login Login.aspx
		/// </summary>
		public static void AcquireRequestState(object sender, System.EventArgs e)
		{
			BusinessPrincipal.WebFormsAcquireRequestState(sender, e);
		}
		public static void AcquireRequestState(object sender, System.EventArgs e, string sessionTimeoutPage)
		{
			BusinessPrincipal.WebFormsAcquireRequestState(sender, e, sessionTimeoutPage);
		}


		/// <summary>
		/// Chiamare questa funzione dopo le operazioni di login in caso di successo
		/// Questa funzione si deve chiamare dalla pagina Login.aspx .
		/// Mettere nel web.config
		/// &lt;authentication mode="Forms"&gt;
		/// &lt;forms name="login" loginUrl="login.aspx" protection="All" timeout="60" /&gt;
		/// &lt;/authentication&gt;
		/// &lt;authorization&gt;
		/// &lt;deny users="?" /&gt;
		/// &lt;/authorization&gt;
		/// </summary>
		/// <param name="userName">nome dell'utente; null se l'utente non si e` logato</param>
		/// <param name="roles">lista dei ruoli; null se l'utente non si e` logato</param>
		/// <returns>true se l'utente si e` logato, false se l'utente non e` riuscito a logarsi</returns>
		public static void LoginSuccess(string userName, StringCollection roles)
		{
			BusinessPrincipal.SetWebFormPrincipal(userName, roles) ;
		}

		/// <summary>
		/// Chiamare questa funzione se l'autenticazione e` fallita
		/// </summary>
		public static void LoginFail()
		{
			BusinessPrincipal.SetWebFormPrincipal(null, null) ;
		}



		/// <summary>
		/// Per slogarsi dall'applicativo.
		/// Ripresenta la pagina di login
		/// </summary>
		public static void Logout()
		{
			BusinessPrincipal.WebFormsLogout(null);
		}
		/// <summary>
		/// Per slogarsi dall'applicativo.
		/// Presenta la pagina passata in <c>logoutPage</c>
		/// </summary>
		/// <param name="logoutPage">la pagina caricata dopo le operazioni di logout</param>
		public static void Logout(string logoutPage)
		{
			BusinessPrincipal.WebFormsLogout(logoutPage);
		}


		/// <summary>
		/// per ottenere / modificare i ruoli
		/// </summary>
		public static StringCollection Roles
		{
			get
			{
				BusinessPrincipal bp = Thread.CurrentPrincipal as BusinessPrincipal;
				if (bp == null)
					return null;
				return bp.Roles;
			}

			set
			{
				BusinessPrincipal bp = Thread.CurrentPrincipal as BusinessPrincipal;
				if (bp != null)
					bp.Roles = value;
			}
		}

		public IPrincipal Principal 
		{
			get
			{
				return Thread.CurrentPrincipal;
			}
		}
	}
	#endregion
}
