using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Text;
using System.ComponentModel;

namespace GME.Security
{
	public class CertStore : IDisposable, IEnumerable
	{
		/// <summary>
		/// Apre il certificate store utente.
		/// Chiamare Close() dovo aver usato il CertStore
		/// </summary>
		public void OpenUserStore()
		{
			_h = WinCapi.CertOpenStoreStringPara(
				WinCapi.CERT_STORE_PROV_SYSTEM,
				0,
				0,
				WinCapi.CERT_SYSTEM_STORE_CURRENT_USER,
				WinCapi.MY);
			if (_h == IntPtr.Zero)
				throw new CertException("CertOpenStoreStringPara");
		}

		/// <summary>
		/// Apre il certificate store della local machine
		/// Chiamare Close() dovo aver usato il CertStore
		/// </summary>
		public void OpenLocalMachineStore()
		{
			_h = WinCapi.CertOpenStoreStringPara(
				WinCapi.CERT_STORE_PROV_SYSTEM,
				0,
				0,
				WinCapi.CERT_SYSTEM_STORE_LOCAL_MACHINE,
				WinCapi.MY);
			if (_h == IntPtr.Zero)
				throw new CertException("CertOpenStoreStringPara");
		}

		/// <summary>
		/// numero di certificati presenti nello store
		/// </summary>
		public int CountCertificatesInStore
		{
			get
			{
				int certIndex;
				IntPtr pCertContext = IntPtr.Zero;
				for (certIndex = 0; ; certIndex++)
				{
					pCertContext = WinCapi.CertEnumCertificatesInStore(_h, pCertContext);
					if (pCertContext == IntPtr.Zero)
						break;
				}
				return certIndex;
			}
		}

		/// <summary>
		/// accede al certificato indirizzato per indice nello store
		/// </summary>
		/// <param name="index">indice [0..CountCertificatesInStore)</param>
		/// <returns>il certificato selezionato</returns>
		public CertX509Ex CertGetCertificateInStoreByIndex(int index)
		{
			int certIndex;
			CertX509Ex c = null;

			IntPtr pCertContext = IntPtr.Zero;
			for (certIndex = 0; certIndex <= index; certIndex++)
			{
				pCertContext = WinCapi.CertEnumCertificatesInStore(_h, pCertContext);
				if (pCertContext == IntPtr.Zero)
				{
					break;
				}
			}
			if (pCertContext != IntPtr.Zero)
			{
				c = new CertX509Ex(pCertContext);
				WinCapi.CertFreeCertificateContext(pCertContext);
			}
			return c;
		}

		/// <summary>
		/// ritorna il certificato cercandolo per issuer e serialnumber
		/// </summary>
		/// <param name="Issuer"></param>
		/// <param name="SerialNumberString"></param>
		/// <returns>il certificato cercato, null se non esiste</returns>
		public CertX509Ex CertGetCertificateInStoreByIssuerSerialNumber(string Issuer,
																		string SerialNumberString)
		{
			int certIndex;
			CertX509Ex c = null;

			IntPtr pCertContext = IntPtr.Zero;

			for (certIndex = 0; ; certIndex++)
			{
				pCertContext = WinCapi.CertEnumCertificatesInStore(_h, pCertContext);
				if (pCertContext == IntPtr.Zero)
				{
					break;
				}
				try
				{
					c = new CertX509Ex(pCertContext);
					if ((c.GetIssuerName() == Issuer) && (c.GetSerialNumberString() == SerialNumberString))
					{
						break;
					}
				}
				catch
				{
				}
			}
			if (pCertContext != IntPtr.Zero)
			{
				WinCapi.CertFreeCertificateContext(pCertContext);
				return c;
			}
			return null;
		}


		/// <summary>
		/// ritorna il certificato cercandolo nello store per subject
		/// </summary>
		/// <param name="certSubject"></param>
		/// <returns>il certificato</returns>
		public CertX509Ex CertFindCertificateInStore(string certSubject)
		{
			IntPtr pCertContext = WinCapi.CertFindCertificateInStore(
				_h,
				WinCapi.MY_ENCODING_TYPE,
				0,
				WinCapi.CERT_FIND_SUBJECT_STR_W,
				certSubject,
				IntPtr.Zero);
			if (pCertContext == IntPtr.Zero)
				throw new CertException("CertFindCertificateInStore");

			CertX509Ex cert = null;

			try
			{
				cert = new CertX509Ex(pCertContext);
			}
			catch
			{
				WinCapi.CertFreeCertificateContext(pCertContext);
				throw;
			}

			WinCapi.CertFreeCertificateContext(pCertContext);
			return cert;
		}

		/// <summary>
		/// chiude il certificate store
		/// </summary>
		public void Close()
		{
			if (_h != IntPtr.Zero)
			{
				int r = WinCapi.CertCloseStore(_h, 0);
				if (r == 0)
					new CertException("CertCloseStore");
				_h = IntPtr.Zero;
			}
		}

		#region Implementation
		private ArrayList EnumCertificatesInStore()
		{
			ArrayList r = new ArrayList();

			IntPtr pCertContext = IntPtr.Zero;
			for (; ; )
			{
				pCertContext = WinCapi.CertEnumCertificatesInStore(_h, pCertContext);
				if (pCertContext == IntPtr.Zero)
					break;

				CertX509Ex c = new CertX509Ex(pCertContext);

				r.Add(c);
			}
			return r;
		}


		private IntPtr _h;

		#region IDisposable Members

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}
		~CertStore()
		{
			Dispose(false);
		}

		bool disposed = false;
		private void Dispose(bool disposing)
		{
			if (!disposed)
			{
				if (disposing)
				{
					// managed resources
				}
				Close();
			}
			disposed = true;
		}
		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return new CertificateEnumerator(this.EnumCertificatesInStore());
		}

		public CertificateEnumerator GetEnumerator()
		{
			return new CertificateEnumerator(this.EnumCertificatesInStore());
		}

		public class CertificateEnumerator : IEnumerator
		{
			public CertificateEnumerator(ArrayList r)
			{
				_r = r;
				_nIndex = -1;
			}

			ArrayList _r;
			int _nIndex;

			#region IEnumerator Members

			public void Reset()
			{
				_nIndex = -1;
			}

			object IEnumerator.Current
			{
				get { return _r[_nIndex]; }
			}

			public bool MoveNext()
			{
				_nIndex++;
				return _nIndex < _r.Count;
			}

			#endregion
		}


		#endregion
		#endregion
	}
} 