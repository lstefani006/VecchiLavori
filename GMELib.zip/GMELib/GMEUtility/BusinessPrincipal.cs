using System;
using System.Collections.Specialized;
using System.Reflection;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Security;

namespace GME.Web
{
	/// <summary>
	/// Summary description for BusinessPrincipal.
	/// </summary>
	internal class BusinessPrincipal : IPrincipal
	{
		internal BusinessPrincipal(string userName, StringCollection roles)
		{
			_identity = new BusinessIdentity(userName, roles);
		}

		/// <summary>
		/// Ritorna true se l'utente collegato ha il ruolo
		/// </summary>
		/// <param name="role">il ruolo richiesto</param>
		/// <returns>true se ha il ruolo richiesto, false altrimenti</returns>
		public bool IsInRole(string role)
		{
			return _identity.IsInRole(role);
		}

		/// <summary>
		/// Ritorna l'Identity di questo contesto di sicurezza.
		/// Con l'Identity si puo` ottenere il nome dell'utente e i ruoli dell'utente.
		/// </summary>
		public IIdentity Identity
		{
			get { return _identity; }
		}


		public StringCollection Roles
		{
			get { return _identity.Roles; }
			set { _identity.Roles = value; }
		}

		private BusinessIdentity _identity;



		/////////////////////////////////
		
		private static bool SetPrincipal(string userName, StringCollection roles)
		{
			AppDomain currentdomain = Thread.GetDomain();
			currentdomain.SetPrincipalPolicy(PrincipalPolicy.UnauthenticatedPrincipal);

			IPrincipal oldPrincipal = Thread.CurrentPrincipal;

			Thread.CurrentPrincipal = new BusinessPrincipal(userName, roles);

			try
			{
				if (oldPrincipal.GetType() != typeof (BusinessPrincipal))
					currentdomain.SetThreadPrincipal(Thread.CurrentPrincipal);
			}
			catch
			{
				// failed, but we don't care because there's nothing
				// we can do in this case
			}


			return Thread.CurrentPrincipal.Identity.IsAuthenticated;
		}


		/// <summary>
		/// Chiamare questa funzione dopo le operazioni di login, sia in caso
		/// positivo (si sanno sia lo userName che la lista dei ruoli)
		/// che negativo (non si sa ne` lo userName ne` i ruoli)
		/// </summary>
		/// <param name="userName">nome dell'utente; null se l'utente non si e` logato</param>
		/// <param name="roles">lista dei ruoli; null se l'utente non si e` logato</param>
		/// <returns>true se l'utente si e` logato</returns>
		public static bool SetWinFormsPrincipal(string userName, StringCollection roles)
		{
			return SetPrincipal(userName, roles);
		}

		/// <summary>
		/// Chiamare questa funzione dopo le operazioni di login, sia in caso
		/// positivo (si sanno sia lo userName che la lista dei ruoli)
		/// che negativo (non si sa ne` lo userName ne` i ruoli).
		/// Questa funzione si deve chiamare dalla pagina Login.aspx .
		/// Mettere nel web.config
		/// &lt;authentication mode="Forms"&gt;
		/// &lt;forms name="login" loginUrl="login.aspx" protection="All" timeout="60" /&gt;
		/// &lt;/authentication&gt;
		/// &lt;authorization&gt;
		/// &lt;deny users="?" /&gt;
		/// &lt;/authorization&gt;
		/// </summary>
		/// <param name="userName">nome dell'utente; null se l'utente non si e` logato</param>
		/// <param name="roles">lista dei ruoli; null se l'utente non si e` logato</param>
		/// <returns>true se l'utente si e` logato</returns>
		public static bool SetWebFormPrincipal(string userName, StringCollection roles)
		{
			if (HttpContext.Current.Session != null)
				HttpContext.Current.Session.Clear();

			bool loggedIn = SetPrincipal(userName, roles);
			if (loggedIn)
			{
				if (HttpContext.Current.Session != null)
					HttpContext.Current.Session["GME-Principal"] = Thread.CurrentPrincipal;
				HttpContext.Current.User = Thread.CurrentPrincipal;

				// ritorno alla pagina chiamante
				FormsAuthentication.RedirectFromLoginPage(userName, false);
			}

			return Thread.CurrentPrincipal.Identity.IsAuthenticated;
		}

		/// <summary>
		/// Funzione da chiamare dopo la login applicativa
		/// </summary>
		/// <param name="userName"></param>
		/// <param name="roles"></param>
		/// <returns></returns>
		public static bool SetWSPrincipal(string userName, StringCollection roles)
		{
			return SetPrincipal(userName, roles);
		}


		/// <summary>
		/// Chiamare questa funzione da Global.asax evento Global_AcquireRequestState(...).
		/// In questo modo si controlla al volo se la sessione e` scaduta. Se si viene l'utente
		/// automaticamente rediretto alla pagina di login LoginPage
		/// </summary>
		public static void WebFormsAcquireRequestState(object sender, System.EventArgs e)
		{
			WebFormsAcquireRequestState(sender, e, null);
		}

		public static void WebFormsAcquireRequestState(object sender, System.EventArgs e, string sessionTimeoutPage)
		{
			// controllo se la sessione e` scaduta
			IPrincipal pr = null;
			if (HttpContext.Current.Session != null)
				pr = (IPrincipal) HttpContext.Current.Session["GME-Principal"];

			if (pr != null)
			{
				// la sessione non e` scaduta --> riassegno il principal dalla sessione
				Thread.CurrentPrincipal = pr;
				HttpContext.Current.User = pr;
			}
			else
			{
				// la sessione e` scaduta --> chiamo la maschera di login
				if (Thread.CurrentPrincipal.Identity.IsAuthenticated)
				{
					FormsAuthentication.SignOut();
					if (sessionTimeoutPage != null)
						HttpContext.Current.Response.Redirect(LoginPage, true);
					else
						HttpContext.Current.Response.Redirect(sessionTimeoutPage, true);
				}
			}
		
		}


		/// <summary>
		/// Funzione per slogarsi da una WebForms
		/// </summary>
		public static void WebFormsLogout(string logoutPage)
		{
			if (HttpContext.Current.Session != null)
			{
				HttpContext.Current.Session.Remove("GME-Principal");
				HttpContext.Current.Session.Abandon();
				// HttpContext.Current.Session.Clear();
			}

			FormsAuthentication.SignOut();

			// HttpContext.Current.Server.Transfer(LoginPage);
			if (logoutPage != null && logoutPage.Trim().Length > 0)
				HttpContext.Current.Response.Redirect(logoutPage, true);
			else
				HttpContext.Current.Response.Redirect(LoginPage, true);
		}

		public static string LoginPage
		{
			get
			{
				try
				{
					object r = HttpContext.Current.GetConfig("system.web/authentication");
					PropertyInfo  pi = r.GetType().GetProperty("LoginUrl", BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic);
					object v = pi.GetValue(r, new object[]{});
					return (string)v;
				}
				catch
				{

					return "Login.aspx";
				}
			}
		}
	}

	internal class BusinessIdentity : IIdentity
	{
		internal BusinessIdentity(string userName, StringCollection roles)
		{
			if (userName == null) userName = string.Empty;
			if (roles == null) roles = new StringCollection();

			this._userName = userName;
			this._roles = roles;
		}

		public string Name
		{
			get { return _userName; }
		}

		public string AuthenticationType
		{
			get { return "GME-BI"; }
		}

		public bool IsAuthenticated
		{
			get { return _userName.Length > 0; }
		}

		public bool IsInRole(string role)
		{
			return _roles.Contains(role);
		}

		public StringCollection Roles
		{
			get { return _roles; }
			set 
			{ 
				_roles = value; 
				if (_roles == null)
					_roles = new StringCollection(); 
			}
		}


		private readonly string _userName;
		private StringCollection _roles;
	}
}