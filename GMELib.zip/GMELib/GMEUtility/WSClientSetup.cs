using System;
using System.Web.Services.Protocols;
using System.Configuration;
using System.Collections.Specialized;
using System.Diagnostics;

using GME.Security;

namespace GME.Web
{
	/// <summary>
	/// Classe da inserire nel soap header dei web service
	/// per consentire l'autenticazione con login/password
	/// </summary>
	public class WSAuthHeader : SoapHeader
	{
		public string Username;
		public string Password;
	}
}

namespace GME.Net
{
	public enum CertificateProblem : long
	{
		CertEXPIRED = 0x800B0101,
		CertVALIDITYPERIODNESTING = 0x800B0102,
		CertROLE = 0x800B0103,
		CertPATHLENCONST = 0x800B0104,
		CertCRITICAL = 0x800B0105,
		CertPURPOSE = 0x800B0106,
		CertISSUERCHAINING = 0x800B0107,
		CertMALFORMED = 0x800B0108,
		CertUNTRUSTEDROOT = 0x800B0109,
		CertCHAINING = 0x800B010A,
		CertREVOKED = 0x800B010C,
		CertUNTRUSTEDTESTROOT = 0x800B010D,
		CertREVOCATION_FAILURE = 0x800B010E,
		CertCN_NO_MATCH = 0x800B010F,
		CertWRONG_USAGE = 0x800B0110,
		CertUNTRUSTEDCA = 0x800B0112,
	}


	public class CustomCertificatePolicy : System.Net.ICertificatePolicy
	{
		public delegate void ServerCertificateProblemsDelegate(string url, int certificateProblem, string msg);
		private static ServerCertificateProblemsDelegate s_ServerCertificateProblemsDelegate;

		public static ServerCertificateProblemsDelegate ServerCertificateProblems
		{
			get { return s_ServerCertificateProblemsDelegate; }
			set { s_ServerCertificateProblemsDelegate = value; }

		}

		public static void Add(string Url, string CertProblems)
		{
			lock (s_CertificateProblems)
			{
				if (s_CertificateProblems.ContainsKey(Url) == false)
					s_CertificateProblems.Add(Url, CertProblems);
			}
		}

		private static StringDictionary s_CertificateProblems = new StringDictionary();

		internal static string GetAllowedCertificateProblems(string Url)
		{
			lock (s_CertificateProblems)
			{
				if (s_CertificateProblems.ContainsKey(Url) == false)
					return null;
				else
					return s_CertificateProblems[Url];
			}
		}

		internal static void TraceCertificateProblems(string url, int problem, string msg)
		{
			try
			{
				if (s_ServerCertificateProblemsDelegate != null)
					s_ServerCertificateProblemsDelegate(url, problem, msg);
			}
			catch
			{
			}
		}


		bool System.Net.ICertificatePolicy.CheckValidationResult(System.Net.ServicePoint srvPoint, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Net.WebRequest request, int certificateProblem)
		{
			string cps = null;

			//
			// La classe intercetta anche l'errore con nessun problema sul certificato
			//
			if (certificateProblem == 0)
			{
				return true;
			}

			if (Enum.IsDefined(typeof(CertificateProblem), (long)(uint)certificateProblem))
			{
				CertificateProblem cp = (CertificateProblem)(long)(uint)certificateProblem;
				cps = cp.ToString();
			}

			string cpa = GME.Net.CustomCertificatePolicy.GetAllowedCertificateProblems(request.RequestUri.AbsoluteUri);
			if (cpa == null)
				return false;

			char[] cc = new char[2];
			cc[0] = ',';
			cc[1] = ' ';

			foreach (string s in cpa.Split(cc))
			{
				if (cps != null && cps == s)
					return true;
				if (s == "*")
					return true;
				if (s.ToUpper() == ((uint)certificateProblem).ToString("X"))
					return true;
			}

			if (cps == null)
				TraceCertificateProblems(request.RequestUri.AbsoluteUri, certificateProblem, "ERRORE: il server remoto ha un 'certificateProblem'");
			else
				TraceCertificateProblems(request.RequestUri.AbsoluteUri, certificateProblem, string.Format("ERRORE: il server remoto ha un 'certificateProblem' di tipo = {0}", cps));
			return false;
		}

	}
}

namespace GME.Web
{
	/// <summary>
	/// Classe da utilizzare lato cliente di un WebService
	/// </summary>
	public class WSClient
	{
		/// <summary>
		/// Funzione da chiamare nel Main dell'applicazione cliente dei WebServices.
		/// Predispone il cliente in modo da consentirgli di operare con WS che hanno
		/// problemi nel loro certificato SSL.
		/// Inoltre permette di agganciare un delegate per effettuare i trace
		/// degli eventuali problemi riscontrati dal a causa del certifcato SSL del server.
		/// </summary>
		/// <param name="traceServerCertificateProblems">funzione che riceve il trace degli eventi</param>
		public static void SetCertificatePolicy(GME.Net.CustomCertificatePolicy.ServerCertificateProblemsDelegate traceServerCertificateProblems)
		{
			GME.Net.CustomCertificatePolicy.ServerCertificateProblems = traceServerCertificateProblems;
			System.Net.ServicePointManager.CertificatePolicy = new GME.Net.CustomCertificatePolicy();
		}



		public static void Setup(System.Web.Services.Protocols.SoapHttpClientProtocol ws, string configName)
		{
			Type ty = ws.GetType();

			Type tipoHeader = GME.Utility.ReflectionUtilities.GetFieldType(ty, "WSAuthHeaderValue");
			object header = GME.Utility.ReflectionUtilities.CreateObject(tipoHeader);

			string userName = null, password = null;
			GME.Web.WSClient.Setup(ws, out userName, out password, configName);

			GME.Utility.ReflectionUtilities.SetField(header, "Username", userName);
			GME.Utility.ReflectionUtilities.SetField(header, "Password", password);

			GME.Utility.ReflectionUtilities.SetField(ws, "WSAuthHeaderValue", header);
		}

		private static System.Net.CookieContainer _ck = new System.Net.CookieContainer();

		//
		// Client Setup per i web services che usano authentication SoapHeader
		//
		public static void Setup(SoapHttpClientProtocol ws, out string username, out string password, string configName)
		{
			ws.CookieContainer = _ck;

			string Url = ReadAppSettings(configName + "_Url");
			string WSServer = ReadAppSettings(configName + "_WSServer");

			if (WSServer == null)
				WSServer = configName;

			// per uscire dalla propria rete
			string ProxyUser = ReadAppSettings(WSServer + "_ProxyUser");
			string ProxyPwd = ReadAppSettings(WSServer + "_ProxyPwd");
			string ProxyDomain = ReadAppSettings(WSServer + "_ProxyDomain");

			// per sopportare i problemi del certificato lato server
			string CertProblems = ReadAppSettings(WSServer + "_CertProblems");

			// per impostare i criteri di autenticazione
			string CertIssuer = ReadAppSettings(WSServer + "_Certificate_Issuer");
			string CertSN = ReadAppSettings(WSServer + "_Certificate_SN");
			string CertPIN = ReadAppSettings(WSServer + "_Certificate_PIN");
			string CertLocation = ReadAppSettings(WSServer + "_Certificate_Location");
			string CertUseMachineKeySet = ReadAppSettings(WSServer + "_Certificate_MachineKeySet");
			string UserName = ReadAppSettings(WSServer + "_UserName");
			string Password = ReadAppSettings(WSServer + "_Password");

			bool bUseMachineKeySet = false;
			if (CertUseMachineKeySet != null && CertUseMachineKeySet != string.Empty)
			{
				CertUseMachineKeySet = CertUseMachineKeySet.ToLower();
				if (CertUseMachineKeySet == "1" ||
					CertUseMachineKeySet == "si" ||
					CertUseMachineKeySet == "yes" ||
					CertUseMachineKeySet == "true")
					bUseMachineKeySet = true;
			}

			// sezione per configurare il proxy

			if (ProxyDomain == null || ProxyDomain == String.Empty)
				ProxyDomain = null;
			if (ProxyUser == null || ProxyUser == String.Empty)
				ProxyUser = null;

			string ProxyAddr = ReadAppSettings(WSServer + "_ProxyAddr");
			string ProxyPort = ReadAppSettings(WSServer + "_ProxyPort");
			if (ProxyAddr != null && ProxyAddr == string.Empty)
				ProxyAddr = null;
			if (ProxyPort != null && ProxyPort == string.Empty)
				ProxyPort = null;

			if (ProxyAddr != null)
			{
				if (ProxyPort == null)
					ws.Proxy = new System.Net.WebProxy(ProxyAddr);
				else
					ws.Proxy = new System.Net.WebProxy(ProxyAddr, int.Parse(ProxyPort));

				if (ProxyUser != null && ProxyPwd != null)
				{
					if (ProxyDomain != null)
						ws.Proxy.Credentials = new System.Net.NetworkCredential(ProxyUser, ProxyPwd, ProxyDomain);
					else
						ws.Proxy.Credentials = new System.Net.NetworkCredential(ProxyUser, ProxyPwd);
				}
			}

			// roba vecchia -- secondo me non serve piu`
			if (ProxyUser != null && ProxyDomain != null)
			{
				ws.Credentials  = new System.Net.NetworkCredential(ProxyUser, ProxyPwd, ProxyDomain);
			}


			SetClientCertificate(ws, CertIssuer, CertSN, CertPIN, CertLocation, bUseMachineKeySet);


			if (Url == null)
				throw new ApplicationException(string.Format("Voce di configurazione '{0}' mancante", configName + "_Url"));

			if (Url != "wsrem")
				ws.Url = Url;

			// queste andranno a riempire l'header
			username = UserName;
			password = Password;


			// leggo il timeout da utilizzare per le chiamate bloccanti al WS
			string strTimeoutMS = ReadAppSettings(WSServer + "_TimeoutMilliSeconds");
			if (strTimeoutMS != null)
				ws.Timeout = int.Parse(strTimeoutMS);

			if (CertProblems != null)
			{
				GME.Net.CustomCertificatePolicy.Add(Url, CertProblems);
			}
		}

		internal static string ReadAppSettings(string key)
		{
			return GME.Utility.AppSettings.ToString(key);
		}

		public void SetProxy()
		{

		}

		#region Implementation

		const string CurrentUserLocation = "CurrentUser";
		const string LocalMachineLocation = "LocalMachine";

		internal static void SetClientCertificate(SoapHttpClientProtocol ws,
			string CertIssuer, string CertSN, string CertPIN,
			string CertLocation, bool bUseMachineKeySet)
		{
			bool bStoreFound = true;
			bool bCertificateFound = false;
			CertX509Ex cert = null;

			//
			// Controlla preventivamente se Issuer/SN sono nulli
			//
			if (CertIssuer == null || CertSN == null)
				return;
			//
			// Controlla preventivamente se Issuer/SN sono stringhe vuote
			//
			if (CertIssuer == string.Empty || CertSN == string.Empty)
				return;

			try
			{
				//
				// cerca il certificato nello store CurrentUser o LocalMachine che
				// fa match con Issuer/SerialNumber
				//
				using (CertStore cs = new CertStore())
				{
					if (CertLocation == CurrentUserLocation)
						cs.OpenUserStore();
					else if (CertLocation == LocalMachineLocation)
						cs.OpenLocalMachineStore();
					else
						bStoreFound = false;

					if (bStoreFound)
					{
						int nCertificatesInStore = cs.CountCertificatesInStore;
						for (int index = 0; index < nCertificatesInStore; index++)
						{
							cert = cs.CertGetCertificateInStoreByIndex(index);
							if (cert != null)
							{
								if (cert.GetIssuerName() == CertIssuer &&
									cert.GetSerialNumberString() == CertSN)
								{
									bCertificateFound = true;
									break;
								}
							}
						}
					}
				}

				//
				// Certificato trovato: setta PIN eventuale e aggiungi certificato 
				// al set di client certificates per l'accesso al WebService
				//
				if (bCertificateFound)
				{
					cert.SetPin(CertPIN, bUseMachineKeySet);
					ws.ClientCertificates.Add(cert);
				}
			}
			catch (CertException cExc)
			{
				Trace.WriteLine(string.Format("Errore su certificato settando client certificate; Msg = {0} Win32Error = {1:X} Win32Msg={2}", cExc.Message, cExc.Win32Error, cExc.Win32Msg));
			}
			catch (Exception exc)
			{
				Trace.WriteLine(string.Format("Errore generico settando client certificate; Msg = {0}", exc.Message));
			}
		}


		#endregion

	}




}
