﻿#region Using directives

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Schema;
using GME.Utility;
using GME.Web;

#endregion

namespace GME
{
	public class WebBase : Page
	{
		#region Logging methods

		protected void smError(string message)
		{
			Log.smError(message);
		}

		protected void smError(Exception ex)
		{
			Log.smError(ex);
		}

		protected void smError(Exception ex, string message)
		{
			Log.smError(ex, message);
		}

		protected void smErrorIf(bool condition, string message)
		{
			Log.smErrorIf(condition, message);
		}

		protected void smErrorIf(bool condition, Exception ex)
		{
			Log.smErrorIf(condition, ex);
		}

		protected void smErrorIf(bool condition, Exception ex, string message)
		{
			Log.smErrorIf(condition, ex, message);
		}

		protected void smTrace(string message)
		{
			Log.smTrace(message);
		}

		protected void smTrace(Exception ex)
		{
			Log.smTrace(ex);
		}

		protected void smTrace(Exception ex, string message)
		{
			Log.smTrace(ex, message);
		}

		protected void smTraceIf(bool condition, string message)
		{
			Log.smTraceIf(condition, message);
		}

		protected void smTraceIf(bool condition, Exception ex)
		{
			Log.smTraceIf(condition, ex);
		}

		protected void smTraceIf(bool condition, Exception ex, string message)
		{
			Log.smTraceIf(condition, ex, message);
		}

		#endregion

		#region Funzioni per gestire il callPage ed il ritorno

		public ArrayList CallingStack
		{
			get
			{
				object o = Session["CallingPage"];
				if (o != null)
					return (ArrayList) o;

				ArrayList sc = new ArrayList();
				Session["CallingPage"] = sc;
				return sc;

			}
		}

		public bool IsReturnToCallerAvailable
		{
			get { return CallingStack.Count > 0; }
		}

		public void CallPage(string callingPage, string page)
		{
			CallingStack.Add(callingPage);
			Server.Transfer(page, false);
		}

		public void ReturnToCaller()
		{
			if (IsReturnToCallerAvailable)
			{
				ArrayList sc = CallingStack;
				string r = (string) sc[sc.Count - 1];
				sc.RemoveAt(sc.Count - 1);
				Server.Transfer(r, false);
			}
		}

		protected ArrayList queryControls = new ArrayList();

		protected string GetReloadQueryString()
		{
			StringBuilder s = new StringBuilder();

			foreach (Control c in queryControls)
			{
				string value = null;

				if (c is TextBox)
					value = ((TextBox) c).Text;
				else if (c is CheckBox)
					value = ((CheckBox) c).Checked.ToString();
				else if (c is DropDownList)
					value = ((DropDownList) c).SelectedIndex.ToString();
				else if (c is ListBox)
					value = ((ListBox) c).SelectedIndex.ToString();
				else
					Debug.Assert(false);

				if (value != null && value.Length > 0)
					s.AppendFormat("{0}={1}&", c.ID, Server.UrlEncode(value));
			}
			return s.ToString();
		}

		protected bool ReadQueryString()
		{
			foreach (Control c in queryControls)
			{
				string value = Request[c.ID];
				if (value != null)
				{
					if (c is TextBox)
						((TextBox) c).Text = value;
					else if (c is CheckBox)
						((CheckBox) c).Checked = bool.Parse(value);
					else if (c is DropDownList)
						((DropDownList) c).SelectedIndex = int.Parse(value);
					else if (c is ListBox)
						((ListBox) c).SelectedIndex = int.Parse(value);
					else
						Debug.Assert(false);
				}
			}

			string r = Request["Ricerca"];
			if (r != null && r == "1")
				return true;
			return false;
		}

		#endregion

		#region "Libreria per gestire le dg senza viewstate o con viewstate"

		// da chiamare per riempire la DG
		protected void DataGrid_Bind(DataGrid dg, DataView dv)
		{
			dg.DataSource = dv;
			dg.DataBind();

			ViewState[dg.UniqueID + ".Sort"] = dv.Sort;
			ViewState[dg.UniqueID + ".RowFilter"] = dv.RowFilter;
			ViewState[dg.UniqueID + ".SelectedIndex"] = dg.SelectedIndex.ToString();

			if (dg.EnableViewState == false)
				if (dg.AllowPaging)
					ViewState[dg.UniqueID + ".CurrentPageIndex"] = dg.CurrentPageIndex.ToString();
		}

		// da chiamare nel Page_Load sezione IsPostBack
		protected void DataGrid_RestoreState(DataGrid dg, DataView dv)
		{
			dg.DataSource = dv;
			dv.Sort = ViewState[dg.UniqueID + ".Sort"].ToString();
			dv.RowFilter = ViewState[dg.UniqueID + ".RowFilter"].ToString();
			dg.SelectedIndex = int.Parse(ViewState[dg.UniqueID + ".SelectedIndex"].ToString());

			if (dg.EnableViewState == false)
			{
				if (dg.AllowPaging)
					dg.CurrentPageIndex = int.Parse(ViewState[dg.UniqueID + ".CurrentPageIndex"].ToString());
				dg.DataBind();
			}
		}

		protected void DataGrid_Sort(DataGrid dg, DataView dv, string eSortExpression)
		{
			dg.SelectedIndex = -1; // tolgo la selezione quando fa sort

			if (dv.Sort == eSortExpression)
				eSortExpression += " DESC";

			dv.Sort = eSortExpression;
		}

		protected void DataGrid_SetRowFilter(DataGrid dg, DataView dv, string rowFilter)
		{
			dv.RowFilter = rowFilter;
			ViewState[dg.UniqueID + ".RowFilter"] = dv.RowFilter;
		}

		protected void DataGrid_PageIndexChanged(DataGrid dg, int eNewPageIndex)
		{
			dg.CurrentPageIndex = eNewPageIndex;
		}

		protected void DataGrid_SelectedIndexChanged(DataGrid dg)
		{
			int oldSelection = int.Parse(ViewState[dg.UniqueID + ".SelectedIndex"].ToString());
			if (dg.SelectedIndex == oldSelection)
				dg.SelectedIndex = -1;
		}

		protected void DataGrid_PopulateKey(DataGrid dg, DataTable dsTable, String[] pks)
		{
			if (!dsTable.Columns.Contains("pk_id"))
			{
				DataColumn cl = new DataColumn("pk_id", typeof (string));
				cl.AllowDBNull = true;
				cl.DefaultValue = "";
				dsTable.Columns.Add(cl);
			}

			if (dg.DataKeyField != "pk_id")
				dg.DataKeyField = "pk_id";

			foreach (DataRow dr in dsTable.Rows)
			{
				XmlDocument xd = new XmlDocument();
				xd.LoadXml("<pk_id></pk_id>");
				foreach (String c in pks)
				{
					XmlElement pk = xd.CreateElement(c);
					pk.InnerText = dr[c].ToString();
					xd.DocumentElement.AppendChild(pk);
				}

				dr["pk_id"] = xd.OuterXml;
			}

			dsTable.AcceptChanges();
		}

		protected string DataGrid_GetKey(DataGrid dg, int eItemIndex, string pk)
		{
			string pk_id = dg.DataKeys[eItemIndex].ToString();
			XmlDocument xd = new XmlDocument();
			xd.LoadXml(pk_id);
			return xd.SelectSingleNode("/pk_id/" + pk).InnerText;
		}

		protected string DataGrid_GetKey(DataGrid dg, DataGridItem dgi, String pk)
		{
			return DataGrid_GetKey(dg, dgi.ItemIndex, pk);
		}

		#endregion

		#region Localizzazione

		public WebAccessProvider AccessProvider;

		public static CultureInfo UserLocalizationCulture
		{
			get
			{
				string[] languages = HttpContext.Current.Request.UserLanguages;
				foreach (string lang in languages)
				{
					try
					{
						return CultureInfo.CreateSpecificCulture(lang);
					}
					catch
					{
					}
				}
				return DefaultCultureInfo;
			}
		}

		public static CultureInfo LocalizationCulture
		{
			get { return Thread.CurrentThread.CurrentUICulture; }
			set
			{
				if (value != null)
				{
					CultureInfo cultureInfo = value;
					if (cultureInfo.IsNeutralCulture)
					{
						try
						{
							cultureInfo = CultureInfo.CreateSpecificCulture(cultureInfo.Name);
						}
						catch
						{
							cultureInfo = CultureInfo.InvariantCulture;
						}
					}

					Thread.CurrentThread.CurrentCulture = cultureInfo;

					if (cultureInfo.LCID == CultureInfo.InvariantCulture.LCID)
						Thread.CurrentThread.CurrentUICulture = DefaultCultureInfo;
					else
						Thread.CurrentThread.CurrentUICulture = cultureInfo;
				}
			}
		}

		public static string GetSentence(string key)
		{
			return LocalizationDictionary.GetSentence(key, LocalizationCulture.Name);
		}

		private static CultureInfo DefaultCultureInfo
		{
			get { return CultureInfo.CreateSpecificCulture("en-US"); }
		}

		private static string RootedPath(string path)
		{
			if (Path.IsPathRooted(path))
				return path;
			else
				return Path.Combine(
					//System.Web.HttpContext.Current.Request.PhysicalApplicationPath
					AppDomain.CurrentDomain.SetupInformation.ApplicationBase,
					path);
		}

		/*
		TODO LIST:
		1) Supportare piu` controlli (Html).
		2) Gestire la lingua di default (nel file xsd c'e` gia`)
		3) Supportare le pagine che non derivano dalla WebBase (funzioni statiche o cose simili)
		4) Aggiornare il brutto manuale che c'e` 
	
		NO!!! 5) Dare la possibilita all'applicativo di modificare/togliere/mettere regole: si risolve cosi`:
		   la pagina applicativa ridefinisce il OnPreRender e chiama a) base.OnPreRende 
		   b) rimodifica la traduzione del controllo
		
		NO!!! 9) l'AccessProvider non "ricorda" le variabili impostate nel Page_Load.
		         Pensare se e` il caso di mettere tutto nel ViewState.
		   
		NO!!! 4) Caricare il documento XML in una struttura (albero ? hash ? ) per velocizzare le cose
		NO!!! 8) Fantascienza: gestire funzioni "esterne" per assegnare il campi ai controlli: la funzione va nel file xml
		   e deve essere compilata al volo. (Script happens nel MSDN)

		*/

		protected virtual void LocalizeControl(Control c, XmlElement element)
		{
			// proviamo a impostare la poprieta`.

			try
			{
				PropertyInfo propertyInfo = c.GetType().GetProperty(element.Name);
				if (null != propertyInfo)
				{
					// o la va o la spacca
					object v = Convert.ChangeType(element.InnerText, propertyInfo.PropertyType, CultureInfo.InvariantCulture);
					propertyInfo.SetValue(c, v, null);
				}
			}
			catch (Exception ex)
			{
				smError(ex, "GME.WebBase.LocalizeControl - cannot assing property");
			}
		}

		public static void SetTooltip(Control c, string text)
		{
			if (c is WebControl)
				((WebControl) c).ToolTip = text;
			else if (c is HtmlControl)
				((HtmlControl) c).Attributes["title"] = text;
		}

		public static void EnableControl(Control c, bool enabled)
		{
			if (c is WebControl)
				((WebControl) c).Enabled = enabled;
			else if (c is HtmlControl)
				((HtmlControl) c).Disabled = !enabled;
		}

		private void LocalizeControl(Control c, string key)
		{
			Type typeControl = c.GetType();

			XmlNodeList nodeList = LocalizationDictionary.FindNodes(key, LocalizationCulture.Name, typeControl);
			if (nodeList == null) return;

			IEnumerator enumType = nodeList.GetEnumerator();
			while (enumType.MoveNext())
			{
				XmlElement elProperty = enumType.Current as XmlElement;
				if (elProperty == null) continue;

				try
				{
					switch (elProperty.Name)
					{
						case "ForeColor":
						case "BackColor":
						{
							PropertyInfo propertyInfo = typeControl.GetProperty(elProperty.Name);
							if (propertyInfo == null) continue;

							propertyInfo.SetValue(c, Color.FromArgb(int.Parse(elProperty.InnerText, CultureInfo.InvariantCulture)), null);
							break;
						}
						case "ErrorMessage":
						case "Text":
						{
							PropertyInfo propertyInfo = typeControl.GetProperty(elProperty.Name);
							if (propertyInfo == null) continue;

							propertyInfo.SetValue(c, elProperty.InnerText, null);
							break;
						}
						case "SelectedIndex":
						{
							PropertyInfo propertyInfo = typeControl.GetProperty(elProperty.Name);
							if (propertyInfo == null) continue;

							propertyInfo.SetValue(c, int.Parse(elProperty.InnerText, CultureInfo.InvariantCulture), null);
							break;
						}
						case "ToolTip":
						{
							SetTooltip(c, elProperty.InnerText);
							break;
						}
						case "Enabled":
						{
							EnableControl(c, bool.Parse(elProperty.InnerText));
							break;
						}
						case "Visible":
						{
							c.Visible = bool.Parse(elProperty.InnerText);
							break;
						}
						case "AccessRule":
						{
							if (AccessProvider.EvaluateExpression(elProperty.InnerText))
							{
								EnableControl(c, true);
								c.Visible = true;
							}
							else
							{
								EnableControl(c, false);
								if ("Visible" == elProperty.GetAttribute("Action"))
									c.Visible = false;
								else
									c.Visible = true;
							}
							break;
						}
						case "DataGrid":
						{
							DataGrid dataGrid = c as DataGrid;
							if (dataGrid == null) continue;

							int count = Math.Min(dataGrid.Columns.Count, elProperty.ChildNodes.Count);

							for (int index = 0; index < count; ++index)
							{
								XmlElement item = elProperty.ChildNodes[index] as XmlElement;
								if (item != null)
								{
									DataGridColumn column = dataGrid.Columns[index] as DataGridColumn;
									if (column != null)
									{
										Type type = column.GetType();
										foreach (XmlAttribute attr in item.Attributes)
										{
											PropertyInfo propertyInfo = type.GetProperty(attr.Name);
											if (propertyInfo != null)
												propertyInfo.SetValue(column, attr.Value, null);
										}
									}
								}
							}
							dataGrid.DataBind();
							break;
						}
						case "DataSource":
						{
							PropertyInfo propertyInfo = typeControl.GetProperty(elProperty.Name);
							if (propertyInfo == null) continue;

							DataSet ds = new DataSet();
							DataTable dt = new DataTable("Table");
							ds.Tables.Add(dt);
							dt.Columns.Add("Text", typeof (string));
							dt.Columns.Add("Value", typeof (string));

							IEnumerator enumRow = elProperty.ChildNodes.GetEnumerator();
							while (enumRow.MoveNext())
							{
								XmlElement row = enumRow.Current as XmlElement;
								if (row != null)
									dt.Rows.Add(new object[] {row.GetAttribute("Text"), row.GetAttribute("Value")});
							}

							// trovo l'item selezionato.

							int nSel = 0;
							bool readSel = false;
							PropertyInfo piSelectedIndex = typeControl.GetProperty("SelectedIndex");
							if (piSelectedIndex != null)
							{
								nSel = (int) piSelectedIndex.GetValue(c, null);
								readSel = true;
							}

							// qui si scrive il DataSource
							propertyInfo.SetValue(c, dt, null);

							typeControl.GetMethod("DataBind").Invoke(c, new object[] {});

							// e rimetto l'item selezionato
							if (piSelectedIndex != null && readSel)
								piSelectedIndex.SetValue(c, nSel, null);

							break;
						}
						default:
						{
							LocalizeControl(c, elProperty);
							break;
						}
					}
				}
				catch (Exception ex)
				{
					smError(ex, "GME.WebBase.LocalizeControl - cannot assing property");
				}
			}
		}

		/// <summary>
		/// <para>Render is called to render all the server controls. Just prior to rendering, the localization is performed.</para>
		/// <seealso cref="System.Web.UI.Control.Render" />
		/// </summary>
		/// <param name="evt">An EventArgs that controls the event data.</param>
		protected override void OnPreRender(EventArgs evt)
		{
			base.OnPreRender(evt);
			if (LocalizationDictionary.Exist)
				ProcessControls(this.Controls);
		}

		/// <summary>
		/// <para>Render is called to render all the server controls. Just prior to rendering, the localization is performed.</para>
		/// <seealso cref="System.Web.UI.Control.Render" />
		/// </summary>
		/// <param name="writer">HtmlTextWriter</param>
		protected override void Render(HtmlTextWriter writer)
		{
			for (int i = 0; i < _localizedControlAttributeCollection.Count; ++i)
			{
				AttributeCollection ac = _localizedControlAttributeCollection[i] as AttributeCollection;
				if (null != ac)
					ac.Remove(_KeyName);
			}
			base.Render(writer);
		}

		private void ProcessControls(ControlCollection controls)
		{
			_localizedControlAttributeCollection = new ArrayList();
			for (int i = 0; i < controls.Count; ++i)
			{
				Control c = controls[i];
				ProcessControl(controls[i], true);
			}
		}

		private void ProcessControl(Control c, bool includeChildren)
		{
			// Perform the substitution if a key was found			
			string key = GetControlAttribute(c, _localizedControlAttributeCollection);
			if (null != key)
			{
				this.LocalizeControl(c, key);
			}

			// Process child controls
			if (includeChildren == true && c.HasControls())
				ProcessControls(c.Controls);
		}

		/// <summary>
		/// <para>GetControlAttribute looks a the type of control and does it's best to find an AttributeCollection.</para>
		/// </summary>
		/// <param name="c">Control to find the AttributeCollection on</param>
		/// <returns>A string containing the key for the specified control or null if a key attribute wasn't found</returns>
		private static string GetControlAttribute(Control c, ArrayList ar)
		{
			AttributeCollection ac = null;
			string key = null;

			if (c is WebControl)
			{
				WebControl w = c as WebControl;
				ac = w.Attributes;
				key = ac[_KeyName];
			}
			else if (c is HtmlControl)
			{
				HtmlControl h = c as HtmlControl;
				ac = h.Attributes;
				key = ac[_KeyName];
			}
			else if (c is UserControl)
			{
				UserControl u = c as UserControl;
				ac = u.Attributes;
				key = ac[_KeyName];
			}
			else if (c is LiteralControl) // LiteralControls don't have an attribute collection
			{
				key = null;
				ac = null;
			}
			else if (c is Literal)
			{
				Literal l = c as Literal;
				ac = null;
				key = l.ID;
			}
			else // Use reflection to check for attribute key. This is a last ditch option
			{
				Type controlType = c.GetType();
				PropertyInfo attributeProperty = controlType.GetProperty("Attributes", typeof (AttributeCollection));
				if (null != attributeProperty)
				{
					ac = attributeProperty.GetValue(c, null) as AttributeCollection;
					if (null != ac)
						key = ac[_KeyName];
				}
			}

			if (null != ac)
				ar.Add(ac);

			return key;
		}

		/// <summary>
		/// <para>Render is called to render all the server controls. Just prior to rendering, the localization is performed.</para>
		/// <seealso cref="System.Web.UI.Control.Render" />
		/// </summary>
		/// <param name="c">Control to on which to replace the key.</param>
		/// <param name="key">New key value.</param>
		private void ReplaceKey(Control c, string key)
		{
			AttributeCollection ac = null;

			// Get the AttributeCollection
			if (c is WebControl)
			{
				WebControl w = c as WebControl;
				ac = w.Attributes;
			}
			else if (c is HtmlControl)
			{
				HtmlControl h = c as HtmlControl;
				ac = h.Attributes;
			}
			else if (c is UserControl)
			{
				UserControl u = c as UserControl;
				ac = u.Attributes;
			}
			else // Use reflection to check for attribute key. This is a last ditch option
			{
				Type controlType = c.GetType();
				PropertyInfo attributeProperty = controlType.GetProperty("Attributes", typeof (AttributeCollection));
				if (null != attributeProperty)
					ac = attributeProperty.GetValue(c, null) as AttributeCollection;
			}

			//
			if (null != ac)
			{
				// Change the value of the key
				ac[_KeyName] = key;
				Reload(c);
			}
		}

		/// <summary>
		/// <para>Reloads all resources into all controls.</para>
		/// </summary>
		public void Reload()
		{
			// Perform substitutions on all controls again
			ProcessControls(this.Controls);
		}

		/// <summary>
		/// <para>Reloads all resources into the specified control. Does not reload any child controls.</para>
		/// </summary>
		/// <param name="c">Control</param>
		public void Reload(Control c)
		{
			Reload(c, false);
		}

		/// <summary>
		/// <para>Reloads all resources into the specified control. Reloads child controls if includeChildren is true</para>
		/// </summary>
		/// <param name="c">Control</param>
		/// <param name="includeChildren">If true reloads all child controls of the specified control.</param>
		public void Reload(Control c, bool includeChildren)
		{
			ProcessControl(c, includeChildren);
		}

		/// <summary>
		/// <para>Reloads the resources for a single property into the specified control. Does not reload any child controls</para>
		/// </summary>
		/// <param name="c">Control</param>
		/// <param name="property">String</param>
		public void Reload(Control c, string property)
		{
			Reload(c, property, false);
		}

		/// <summary>
		/// <para>Reloads the resources for a single property into the specified control.</para>
		/// </summary>
		/// <param name="c">Control</param>
		/// <param name="property">String</param>
		/// <param name="includeChildren">If true reloads all child controls of the specified control.</param>
		public void Reload(Control c, string property, bool includeChildren)
		{
			string key = GetControlAttribute(c, _localizedControlAttributeCollection);
			if (null != key)
			{
				this.LocalizeControl(c, key);
			}

			// If required, perform the reload on this controls children
			if (true == includeChildren)
				ProcessControls(c.Controls);
		}

		private const string _KeyName = "key";
		private ArrayList _localizedControlAttributeCollection = new ArrayList();

		public class LocalizationDictionary
		{
			public static bool Exist
			{
				get
				{
					lock (_namespacePrefix)
					{
						return _dictionary != null;
					}
				}
			}

			public static XmlElement FindElement(string key, string language)
			{
				//lock (_namespacePrefix)
				{
					if (_dictionary != null)
					{
#if DEBUG
						if (key == null || language == null)
							throw new ArgumentNullException();
#endif
						try
						{
							string xPath = string.Format("./{0}:LocalizationItem[@Key='{1}']/{0}:Translation[@language='{2}']"
							                             , _namespacePrefix, key, language.ToLower());

							return _dictionary.DocumentElement.SelectSingleNode(xPath, _namespaceManager) as XmlElement;
						}
						catch
						{
							// ??? TODO 
						}
					}
					return null;
				}
			}

			public static XmlNodeList FindNodes(string key, string language, Type type)
			{
				//lock (_namespacePrefix)
				{
					if (_dictionary != null)
					{
#if DEBUG
						if (key == null || language == null || type == null)
							throw new ArgumentNullException();
#endif
						try
						{
							XmlElement translation = FindElement(key, language);
							if (translation != null)
							{
								string path = string.Concat("*[@Type='", type.FullName, "']");
								XmlNodeList nodeList = translation.SelectNodes(path, _namespaceManager);
								if (nodeList != null && nodeList.Count > 0)
									return nodeList;
							}
						}
						catch
						{
						}
					}
					return null;
				}
			}

			public static string GetSentence(string key)
			{
				//lock (_namespacePrefix)
				{
					return GetSentence(key, LocalizationCulture.Name);
				}
			}

			public static string GetSentence(string key, string language)
			{
				//lock (_namespacePrefix)
				{
					if (_dictionary != null)
					{
#if DEBUG
						if (key == null || language == null)
							throw new ArgumentNullException();
#endif
						try
						{
							string xPath = string.Format("./{0}:LocalizationItem[@Key='{1}']/{0}:Translation[@language='{2}']/{0}:Sentence"
							                             , _namespacePrefix, key, language.ToLower());

							XmlNode sentence = _dictionary.DocumentElement.SelectSingleNode(xPath, _namespaceManager);
							if (sentence != null && sentence.HasChildNodes)
								return sentence.InnerText;
						}
						catch
						{
							// ??????????? TODO
						}
					}
					if (key == null)
						return string.Empty;
					return key;
				}
			}

			private static void ValidationEventHandle(object o, ValidationEventArgs e)
			{
				Log.smError(e.Exception, "Errore di validazione del file Localization.xml");
				throw new ApplicationException("Errore di validazione del file Localization.xml", e.Exception);
			}

			static LocalizationDictionary()
			{
				lock (_namespacePrefix)
				{
					XmlValidatingReader reader = null;
					try
					{
						string fileNameXsd = RootedPath(AppSettings.ToString("LocalizationSchemaFileName"
						                                                     , "Localization.xsd"));
						XmlSchemaCollection sc = new XmlSchemaCollection();
						sc.Add(null, fileNameXsd);

						string fileNameXml = RootedPath(AppSettings.ToString("LocalizationFileName"
						                                                     , "Localization.xml"));
						reader = new XmlValidatingReader(new XmlTextReader(fileNameXml));
						reader.ValidationType = ValidationType.Schema;
						reader.ValidationEventHandler += new ValidationEventHandler(ValidationEventHandle);
						reader.Schemas.Add(sc);

						XmlDocument d = new XmlDocument();
						_namespaceManager = new XmlNamespaceManager(d.NameTable);
						_namespaceManager.AddNamespace(_namespacePrefix, "urn:XML-Localization");
						d.Load(reader);

						_dictionary = d;
					}
#if DEBUG
					catch (Exception e)
					{
						_dictionary = null;
						_namespaceManager = null;

						Log.smError(e, "LocalizationDictionary.ctor");
						throw;
					}
#else
					catch
					{
						_dictionary = null;
						_namespaceManager = null;
					}
#endif
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}

			private static XmlDocument _dictionary = null;
			private static XmlNamespaceManager _namespaceManager = null;
			private const string _namespacePrefix = "df";
			private const string _namespaceUri = "urn:XML-Localization";
		}

		#endregion

		#region Login

		public WebBase()
		{
			AccessProvider = new WebAccessProvider();
			AccessProvider.FunctionList.Clear();

//			StringCollection roles = WinFormAuth.Roles;
//			if (roles != null)
//			{
//				foreach (string r in roles)
//					AccessProvider.FunctionList[r] = true;
//			}
		}

		protected override void OnLoad(EventArgs e)
		{
			StringCollection roles = WebFormAuth.Roles;
			if (roles != null)
			{
				foreach (string r in roles)
					AccessProvider.FunctionList[r] = true;
			}

			base.OnLoad(e);
		}



		/// <summary>
		/// Chiamare questa funzione dopo aver autenticato un utente nella pagina di login
		/// </summary>
		/// <param name="userName">il codice dell'utente</param>
		/// <param name="roles">funzioni/ruoli associati all'utente</param>
		protected virtual void LoginSuccess(string userName, StringCollection roles)
		{
			AccessProvider.FunctionList.Clear();
			foreach (string r in roles)
				AccessProvider.FunctionList[r] = true;

			WebFormAuth.LoginSuccess(userName, roles);
		}

		/// <summary>
		/// Chiamare questa funzione dopo aver autenticato un utente nella pagina di login
		/// </summary>
		/// <param name="userName">il codice dell'utente</param>
		/// <param name="roles">funzioni/ruoli associati all'utente</param>
		/// <param name="language">lingua associata all'utente</param>
		protected virtual void LoginSuccess(string userName, StringCollection roles, string language)
		{
			AccessProvider.FunctionList.Clear();
			foreach (string r in roles)
				AccessProvider.FunctionList[r] = true;

			LocalizationCulture = new CultureInfo(language);

			WebFormAuth.LoginSuccess(userName, roles);
		}


		/// <summary>
		/// Chiamare questa funzione se non si e` autenticato l'utente nella pagina di login
		/// </summary>
		protected virtual void LoginFail()
		{
			AccessProvider.FunctionList.Clear();
			WebFormAuth.LoginFail();
		}

		/// <summary>
		/// Funzione da chiamare in qualunque pagina per slogarsi della WA
		/// </summary>
		protected virtual void Logout()
		{
			AccessProvider.FunctionList.Clear();
			WebFormAuth.Logout();
		}

		/// <summary>
		/// Funzione per cambiare i ruoli all'utente.
		/// Si aggiorna anche le funzioni associate al AccessProvider
		/// </summary>
		/// <param name="roles"></param>
		protected virtual void OnChangeRoles(StringCollection roles)
		{
			string userName = User.Identity.Name;

			WebFormAuth.Roles = roles;

			AccessProvider.FunctionList.Clear();

			foreach (string r in roles)
				AccessProvider.FunctionList[r] = true;

			if (ChangedRoles != null)
				ChangedRoles(roles);
		}

		public delegate void ChangedRolesDelegate(StringCollection roles);
		public event ChangedRolesDelegate ChangedRoles;

		#endregion
	}

	public class WSBase : WebService
	{
		#region Logging methods

		protected void smError(string message)
		{
			Log.smError(message);
		}

		protected void smError(Exception ex)
		{
			Log.smError(ex);
		}

		protected void smError(Exception ex, string message)
		{
			Log.smError(ex, message);
		}

		protected void smErrorIf(bool condition, string message)
		{
			Log.smErrorIf(condition, message);
		}

		protected void smErrorIf(bool condition, Exception ex)
		{
			Log.smErrorIf(condition, ex);
		}

		protected void smErrorIf(bool condition, Exception ex, string message)
		{
			Log.smErrorIf(condition, ex, message);
		}

		protected void smTrace(string message)
		{
			Log.smTrace(message);
		}

		protected void smTrace(Exception ex)
		{
			Log.smTrace(ex);
		}

		protected void smTrace(Exception ex, string message)
		{
			Log.smTrace(ex, message);
		}

		protected void smTraceIf(bool condition, string message)
		{
			Log.smTraceIf(condition, message);
		}

		protected void smTraceIf(bool condition, Exception ex)
		{
			Log.smTraceIf(condition, ex);
		}

		protected void smTraceIf(bool condition, Exception ex, string message)
		{
			Log.smTraceIf(condition, ex, message);
		}

		#endregion

		/// <summary>
		/// soap header da utilizzare in tutti i WebService.
		/// Contiene la login/password che il cliente deve specificare
		/// (a meno che non sia richiesto il certifcato digitale lato cliente)
		/// </summary>
		public WSAuthHeader authHeader = null;

		/// <summary>
		/// Funzione da utilizzare per controllare se il cliente del web service
		/// e` autorizzato.
		/// </summary>
		protected void CheckAuth()
		{
			WSServerCheckAuth.CheckAuth(Context, authHeader);
		}

		/// <summary>
		/// Funzione da chiamare per impostare il software cliente di un web service.
		/// Si usa nel web server (WS o WA) per chiamare il WS della BL
		/// </summary>
		/// <param name="ws">web srvice client da configurare</param>
		/// <param name="configName">chiave nel file di configurazione</param>
		protected void SetupClient(SoapHttpClientProtocol ws, string configName)
		{
			WSClient.Setup(ws, configName);
		}

		protected override void Dispose(bool disposing)
		{
			base.Dispose(disposing);
		}

	}
}