﻿#region Using directives

using System;
using System.Xml.Serialization;
using GME;
using GME.Security;
using GME.Utility;

#endregion

namespace GMETest
{
	public class ProgramSettings : MarshalByRefObject
	{
		public string a = "";
		public int b = 3;

		[XmlArray("c")]
		[XmlArrayItem("cItem")] public string[] d;

	}


	internal class Program
	{
		private static void Main(string[] args)
		{

			try
			{
				AppSettings.LoadAlternateConfigFile("GMETest.exe.config");

				ProgramSettings ee = (ProgramSettings) AppSettings.GetConfig("ProgramSettings");
				Console.WriteLine(ee.a);

				CertificateManager cm = new CertificateManager();
				cm.ForceCRLDownload = true;

				// cm.DownloadDistributionPoint = new GME.Security.CertificateManager.DownloadCRLDelegate(f);

				FunctionList fl = new FunctionList();
				fl.Add("L", false);
				fl.Add("R", true);
				// bool b = GME.Web.WebAccessProvider.EvalExpression("L & R", fl);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}


		}

		private static bool f(int timeOut, string Url, out DateTime currentTime, out DateTime nextTime, out CryptCRL.CRLEntry[] crlEntries)
		{
			currentTime = DateTime.Now;
			nextTime = DateTime.Now;
			crlEntries = null;

			return false;
		}

	}
}