using System;
using System.Threading;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Xml.Serialization;
using System.Text;
using System.IO;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Proxies;
using System.Runtime.Remoting.Channels;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web.Services.Protocols;


namespace GMERemotingWS
{
	[WebService(Namespace="http://mercatoelettrico.org/RemotingWS")]
	public class RemotingWS : System.Web.Services.WebService
	{
		public RemotingWS()
		{
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion


		public GME.Web.WSAuthHeader authHeader = null;

		[WebMethod]
		[SoapHeader("authHeader")]
		public string Echo(string strMsg)
		{	
			GME.Web.WSServerCheckAuth.CheckAuth(Context, authHeader);
			return strMsg;
		}

		[WebMethod]
		[SoapHeader("authHeader")]
		public byte [] SyncProcessMessage(byte [] ar)
		{
			GME.Web.WSServerCheckAuth.CheckAuth(Context, authHeader);

			byte[] r = GME.Remoting.Server.SyncProcessMessage(ar);
			return r;
		}
	}
}
