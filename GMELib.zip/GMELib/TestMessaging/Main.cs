using System;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Messaging;

namespace TestApplication
{
	public class _
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		private static void Main()
		{
			string fileSchema = @"..\..\Schemi\PIPEDocument.xsd";
			string fileXml = @"..\..\MGPOffers-IDGRTN-01-20040901.xml";

			MessageReader rd = new MessageReader();
			rd.AddToFactoryTable("BidSubmittal", typeof (BidSubmittalFacade));
			rd.AddRootOperator("root");
			rd.NewTransaction += new Messaging.MessageReader.NewTransactionDelegate(rd_NewTransaction);
			Message msg = rd.ReadMessage(fileSchema, fileXml, "IDGME");

			// TODO mettere il channel Operator .... colui che manda il messaggio come risulta dal canale.
			// in modo da poter generare l'FA ....

			string FAReferenceNumber = MessageHelper.GenerateId30();

			XmlTextWriter wFA = new XmlTextWriter(@"c:\leo.xml", Encoding.UTF8);
			wFA.Formatting = Formatting.Indented;
			wFA.IndentChar = ' ';
			wFA.Indentation = 1;
			msg.WriteFA(wFA, FAReferenceNumber);
			wFA.Close();

			foreach (TransactionFacade tr in msg.Transaction)
			{
				XmlTextWriter xw = new XmlTextWriter(@"c:\leo0.xml", Encoding.UTF8);
				xw.Formatting = Formatting.Indented;
				xw.IndentChar = ' ';
				xw.Indentation = 1;

				tr.Write(xw);

				xw.Close();
			}

			wFA.Close();


			Console.Write("Finito ");

			Console.ReadLine();
		}

		private static void rd_NewTransaction(Message msg, TransactionFacade tr)
		{
			Console.WriteLine("tr = ");
			tr.Write(new XmlTextWriter(Console.Out));

			// msg.Transaction.Remove(tr);
		}
	}

	public class BidSubmittalFacade : TransactionFacade
	{
		static BidSubmittalFacade()
		{
			_xBid = new XmlSerializer(typeof (ME.BidSubmittal));
		}

		public BidSubmittalFacade(PIPEDoc.PIPTransaction tr)
			: base(tr, PIPTransactionAttributes.All)
		{
			_bid = null;
		}

		public override string FA_MarketParticipantNumber
		{
			get { return _bid.MarketParticipantNumber; }
		}

		public override string FA_TransactionType
		{
			get { return "BidSubmittal"; }
		}

		public override void Read(XmlReader xr)
		{
			_bid = (ME.BidSubmittal) _xBid.Deserialize(xr);
		}

		public override void Write(XmlWriter xw)
		{
			base.WriteStartPIP(xw);
			_xBid.Serialize(xw, _bid);
			base.WriteEndPIP(xw);
		}

		public override void Execute(object executeState)
		{
		}

		private static XmlSerializer _xBid;
		protected ME.BidSubmittal _bid;
	}
}