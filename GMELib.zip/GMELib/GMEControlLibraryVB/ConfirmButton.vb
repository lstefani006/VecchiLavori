Imports System.ComponentModel
Imports System.Web.UI
Imports System.Globalization

<DefaultProperty("Text"), ToolboxData("<{0}:ConfirmButton runat=server></{0}:ConfirmButton>")> Public Class ConfirmButton
	Inherits System.Web.UI.WebControls.Button

	Sub New()
		MyBase.New()
		Me.CssClass = "Bil_Button"
	End Sub

	Dim _ConfirmText As String

	<Bindable(True), Category("Appearance"), DefaultValue("")> Property ConfirmText() As String
		Get
			Return _ConfirmText
		End Get

		Set(ByVal Value As String)
			_ConfirmText = Value
		End Set
	End Property

	Private Function GetConfirmMsg() As String
		If (_ConfirmText Is Nothing OrElse _ConfirmText = String.Empty) Then
			If (CultureInfo.CurrentCulture.Name.ToUpper() = "IT-IT") Then
				Return Text + "\n\nVuoi continuare ?"
			Else
				Return Text + "\n\nContinue ?"
			End If
		End If
		Return _ConfirmText
	End Function

	Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
		If Not Me.Page.IsClientScriptBlockRegistered("ConfirmButton_scripts") Then
            Dim nl As String = Environment.NewLine

			Dim s As String = String.Empty
			s += "<SCRIPT language='javascript' >" + nl
			s += "function ConfirmButton_onClick(m)" + nl
			s += "{" + nl
			s += "	return confirm(m);" + nl
			s += "}" + nl
			s += "</SCRIPT>" + nl
			Page.RegisterClientScriptBlock("ConfirmButton_scripts", s)

		End If
	End Sub



	Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
		Dim v As String = "cb_" + Me.ClientID
		output.WriteLine("<SCRIPT LANGUAGE=""JavaScript"">")
		output.WriteLine("var " + v + " = '" + GetConfirmMsg() + "';")
		output.WriteLine("</SCRIPT>")


		Me.Attributes.Add("onclick", "if (!ConfirmButton_onClick(" + v + ")) return false;")
		'Me.Attributes.Add("onclick", "return ConfirmButton_onClick(" + v + ");")
		MyBase.Render(output)
	End Sub

End Class
