using System;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace RemOpBasedChannel
{
	internal class ExEOF : Exception
	{
	}

	public class RemOpTcpListener : IDisposable
	{
		private TcpListener m_s;

		public void Listen(int tcpPort)
		{
			IPAddress ipAddress = Dns.Resolve("localhost").AddressList[0];

			m_s = new TcpListener(ipAddress, tcpPort);
			m_s.Start();
		}

		public RemOpTcp Accept()
		{
			TcpClient c = m_s.AcceptTcpClient();
			return new RemOpTcp(c);
		}

		public void Dispose()
		{
			if (m_s != null)
				m_s.Stop();
			m_s = null;
		}
	}

	public class RemOpTcp : IDisposable
	{
		public static byte[] SendMessageAndWaitReplay(string channelData, string destinationInServer, byte [] ar)
		{
			string destinationOutServer = null;

			string[] dd = channelData.Split(':');
			string tcpAddr = dd[0];
			int tcpPort = int.Parse(dd[1], CultureInfo.InvariantCulture);

			using (RemOpTcp ns = new RemOpTcp(new TcpClient(tcpAddr, tcpPort)))
			{
				ns.WriteMessage(destinationInServer, false, ar);

				try
				{
					bool dummy;
					return ns.ReadMessage(out destinationOutServer, out dummy);
				}
				catch (ExEOF)
				{
					// non c'e` risposta --> messaggio OneWay
					return null;
				}
			}
		}

		public static RemOpTcp AsyncSendMessage(string channelData, string destinationServer, bool oneWay, byte [] ar)
		{
			string[] dd = channelData.Split(':');
			string tcpAddr = dd[0];
			int tcpPort = int.Parse(dd[1], CultureInfo.InvariantCulture);

			TcpClient c = new TcpClient(tcpAddr, tcpPort);
			RemOpTcp ns = new RemOpTcp(c);
			ns.WriteMessage(destinationServer, oneWay, ar);
			return ns;
		}

		public static void SendOneWayMessage(string channelData, string destinationServer, byte [] ar)
		{
			string[] dd = channelData.Split(':');
			string tcpAddr = dd[0];
			int tcpPort = int.Parse(dd[1], CultureInfo.InvariantCulture);

			TcpClient c = new TcpClient(tcpAddr, tcpPort);
			RemOpTcp ns = new RemOpTcp(c);
			ns.WriteMessage(destinationServer, true, ar);
			ns.Close();
		}



		TcpClient _tcp;
		NetworkStream _ns;

		public RemOpTcp(TcpClient tcp)
		{
			_tcp = tcp;
			_ns = _tcp.GetStream();
		}

		public void Close()
		{
			Dispose();
		}

		public void Dispose()
		{
			if (_ns != null)
			{
				_ns.Close();
				_ns = null;
				_tcp = null;
			}
		}

		public byte[] ReadMessage(out string destinationServer, out bool oneWay)
		{
			destinationServer = ReadString(_ns);
			oneWay = ReadBool(_ns);
			int sz = ReadInt(_ns);
			byte[] ar = new byte[sz];
			ReadArray(ar, sz, _ns);
			return ar;
		}

		public void WriteMessage(string destinationServer, bool oneWay, byte[] a)
		{
			WriteString(_ns, destinationServer);
			WriteBool(_ns, oneWay);
			WriteInt(_ns, a.Length);
			WriteArray(_ns, a);
		}


		#region Dettagli
		private static void ReadArray(byte [] ar, int sz, NetworkStream ns)
		{
			int rd = 0;
			do
			{
				rd += ns.Read(ar, rd, sz - rd); 
			}
			while (rd < sz);
		}

		private static int ReadInt(NetworkStream ns)
		{
			byte [] ar = new byte[4];
			ReadArray(ar, 4, ns);
			return ArrayToInt(ar);
		}
		private static void WriteInt(NetworkStream ns, int n)
		{
			byte [] ar = new byte[4];
			IntToArray(n, ar);
			ns.Write(ar, 0, 4);
		}
		private static void WriteArray(NetworkStream ns, byte[] a)
		{
			ns.Write(a, 0, a.Length);
		}


		private static int ArrayToInt(byte [] ar)
		{
			Debug.Assert(ar.Length == 4);
			return (ar[0] << 0) | (ar[1] << 8) | (ar[2] << 16) | (ar[3] << 24);
		}
		private static void IntToArray(int isz, byte [] ar)
		{
			uint sz = (uint)isz;
			Debug.Assert(ar.Length == 4);
			ar[0] = (byte) ((sz >> 0) & 0xff);
			ar[1] = (byte) ((sz >> 8) & 0xff);
			ar[2] = (byte) ((sz >> 16) & 0xff);
			ar[3] = (byte) ((sz >> 24) & 0xff);

			Debug.Assert(ArrayToInt(ar) == sz);
		}

		private void WriteByte(NetworkStream ns, int s)
		{
			ns.WriteByte((byte)(uint)s);
		}
		private int ReadByte(NetworkStream ns)
		{
			int n = ns.ReadByte();
			if (n < 0)
				throw new ExEOF();
			return n;
		}

		private void WriteBool(NetworkStream ns, bool s)
		{
			byte b = s ? (byte)1 : (byte)0;
			ns.WriteByte(b);
		}
		private bool ReadBool(NetworkStream ns)
		{
			int n = ns.ReadByte();
			if (n < 0)
				throw new ExEOF();
			return n == 0 ? false : true;
		}

		private void WriteString(NetworkStream ns, string s)
		{
			Debug.Assert(s.Length < 256);
			byte [] a = ASCIIEncoding.ASCII.GetBytes(s);
			WriteByte(ns, a.Length);
			WriteArray(ns, a);
		}

		private string ReadString(NetworkStream ns)
		{
			int sz = ReadByte(ns);
			byte [] a = new byte[sz];
			ReadArray(a, sz, ns);
			string r = ASCIIEncoding.ASCII.GetString(a);
			return r;
		}

		#endregion

	}


}
