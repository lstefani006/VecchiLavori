using System;
using System.IO;
using System.Runtime.Remoting.Channels;

namespace RemOpBasedChannel
{
	public class RemOpChannelHelper
	{
		private RemOpChannelHelper() {}

		public static string Parse(string url, out string objectURI)
		{

			// formato
			// remop://<server>/objectURI
			// <server> e` una etichetta

			objectURI = null;

			if (!url.StartsWith("remop://"))
			{
				return null;
			}

			int BeginChannelURI = url.IndexOf("://", 0, url.Length) + 3;
			int EndOfChannelURI = url.LastIndexOf("/");

			string ChannelURI;
			if (BeginChannelURI < EndOfChannelURI)
			{
				ChannelURI = url.Substring(BeginChannelURI, EndOfChannelURI - BeginChannelURI);
				objectURI = url.Substring(EndOfChannelURI + 1);
			}
			else
			{
				ChannelURI = url.Substring(BeginChannelURI);
			}

			return ChannelURI;
		}
	}

	[Serializable]
	public class ChannelRemOpData
	{
		private string m_DestinationServer = null;
		private string m_ObjectURI = null;
		private ITransportHeaders m_Header = null;
		private byte[] m_StreamBytes = null;

		public ChannelRemOpData() {}

		public ChannelRemOpData(string destinationServer, string objectURI, ITransportHeaders headers, Stream stream)
		{
			m_DestinationServer = destinationServer;
			m_ObjectURI = objectURI;
			m_Header = headers;
			m_StreamBytes = new Byte[(int)stream.Length];
			stream.Read(m_StreamBytes, 0, (int)stream.Length);
			stream.Position = 0;
		}

		public string DestinationServer { get { return m_DestinationServer; } }
		public string ObjectURI { get { return m_ObjectURI; } }
		public ITransportHeaders header { get { return m_Header; } }
		public Stream stream { get { return new MemoryStream(m_StreamBytes, false); } }
	}
}
