using System;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using GME.Web;
using RemOpBasedChannel.WS;

namespace RemOpBasedChannel
{
	public class RemOpServerChannel : IChannelReceiver
	{
		private string _ChannelName = "remop";
		private int _ChannelPriority = 1;
		private string _ServerName = null;
		private ChannelDataStore _DataStore;
		private IServerChannelSinkProvider _SinkProvider = null;
		private RemOpServerChannelSink _Sink = null;

		private StringDictionary _ClientChannels;
		private int _TcpPort = -1;

		private Thread _TcpListeningThread;

		/*
		public RemOpServerChannel(string serverPath)
		{
			if (serverPath != null)
				m_ServerPath = serverPath;

			Init();
		}
		*/

		public RemOpServerChannel(IDictionary properties, IServerChannelSinkProvider provider)
		{
			_SinkProvider = provider;

			if (properties != null)
			{
				_ClientChannels = new StringDictionary();

				foreach (DictionaryEntry entry in properties)
				{
					string key = (string) entry.Key;
					if (key == "name")
					{
						_ChannelName = (string) entry.Value;
					}
					else if (key == "servername")
					{
						_ServerName = (string) entry.Value;
					}
					else if (key == "priority")
					{
						_ChannelPriority = int.Parse((string) entry.Value, CultureInfo.InvariantCulture);
					}
					else if (key.StartsWith("ch_"))
					{
						string serverName = key.Substring(3);
						string channel = (string) entry.Value;
						_ClientChannels.Add(serverName, channel);
					}
					else if (key == "tcp_Port")
					{
						if (((string) entry.Value).Trim().Length > 0)
							_TcpPort = int.Parse((string) entry.Value, CultureInfo.InvariantCulture);
						else
							_TcpPort = 0;
					}

				}
			}

			if (_ServerName != null)
				Init();
		}

		private void Init()
		{
			// If a formatter provider was not specified, we must create one
			if (_SinkProvider == null)
				_SinkProvider = new BinaryServerFormatterSinkProvider();

			// Initialize the ChannelDataStore object with our channel uri
			_DataStore = new ChannelDataStore(null);
			_DataStore.ChannelUris = new string[1];
			_DataStore.ChannelUris[0] = "remop://" + _ServerName;

			PopulateChannelData(_DataStore, _SinkProvider);

			IServerChannelSink sink;
			sink = ChannelServices.CreateServerChannelSinkChain(_SinkProvider, this);

			// Add our transport sink to the chain
			_Sink = new RemOpServerChannelSink(sink, _ServerName, _ClientChannels, _TcpPort);

			StartListening(null);
		}

		public byte[] ServiceRequest(string destinationServer, bool oneWay, byte[] ain)
		{
			byte[] aout = null;

			RemOpServerChannelSink.ManageAsyncResponce_BlockCallingThread resp = new RemOpServerChannelSink.ManageAsyncResponce_BlockCallingThread(_ServerName);

			if (_Sink != null)
				aout = _Sink.ManageMessage(destinationServer, oneWay, ain, resp);

			return aout;
		}

		private void PopulateChannelData(ChannelDataStore channelData, IServerChannelSinkProvider provider)
		{
			while (provider != null)
			{
				provider.GetChannelData(channelData);
				provider = provider.Next;
			}
		}


		public string Parse(string url, out string objectURI)
		{
			return RemOpChannelHelper.Parse(url, out objectURI);
		}

		public string ChannelName
		{
			get { return _ChannelName; }
		}

		public int ChannelPriority
		{
			get { return _ChannelPriority; }
		}

		public void StartListening(object data)
		{
			if (_TcpPort > 0)
			{
				ThreadStart TcpListeningThreadStart = new ThreadStart(_Sink.TcpListenAndProcessMessage);
				_TcpListeningThread = new Thread(TcpListeningThreadStart);
				_TcpListeningThread.IsBackground = true;
				_TcpListeningThread.Start();
			}
		}

		public void StopListening(object data)
		{
			if (_TcpListeningThread != null)
			{
				_TcpListeningThread.Abort();
				_TcpListeningThread = null;
			}
		}

		public string[] GetUrlsForUri(string objectURI)
		{
			string[] URL = new string[1];

			if (!objectURI.StartsWith("/"))
				objectURI = "/" + objectURI;

			URL[0] = "remop://" + _ServerName + objectURI;
			return URL;
		}

		public object ChannelData
		{
			get { return _DataStore; }
		}

		public string ServerName
		{
			get { return _ServerName; }
		}

	}

	internal class RemOpServerChannelSink : IServerChannelSink
	{
		private IServerChannelSink _NextSink = null;
		private string _ServerName;
		private StringDictionary _ClientChannels;
		private int _TcpPort;

		public RemOpServerChannelSink(IServerChannelSink nextSink, string serverName, StringDictionary clientChannels, int tcpPort)
		{
			_NextSink = nextSink;
			_ServerName = serverName;
			_ClientChannels = clientChannels;
			_TcpPort = tcpPort;
		}

		public ServerProcessing ProcessMessage(IServerChannelSinkStack sinkStack,
		                                       IMessage requestMsg,
		                                       ITransportHeaders requestHeaders,
		                                       Stream requestStream,
		                                       out IMessage responseMsg,
		                                       out ITransportHeaders responseHeaders,
		                                       out Stream responseStream)
		{
			throw new NotSupportedException();
		}

		public Stream GetResponseStream(IServerResponseChannelSinkStack sinkStack,
		                                object state,
		                                IMessage msg,
		                                ITransportHeaders headers)
		{
			return null;
		}

		public IServerChannelSink NextChannelSink
		{
			get { return _NextSink; }
		}

		public IDictionary Properties
		{
			get { return null; }
		}

		#region Tcp

		internal void TcpListenAndProcessMessage()
		{
			using (RemOpTcpListener tcp = new RemOpTcpListener())
			{
				tcp.Listen(_TcpPort);

				for (;; )
				{
					try
					{
						// ns viene chiuso da ManageTcpMessage
						RemOpTcp ns = tcp.Accept();

						ManageTcpMessageDelegate d = new ManageTcpMessageDelegate(ManageTcpMessage);
						d.BeginInvoke(ns, new AsyncCallback(ManageTcpMessageCompletition), d);
					}
					catch (Exception e)
					{
						RemOpTrace.Trace(e, "TcpListenAndProcessMessage");
						Debug.Assert(false);
					}
				}
			}
		}

		private delegate void ManageTcpMessageDelegate(RemOpTcp ns);

		private void ManageTcpMessage(RemOpTcp ns)
		{
			try
			{
				string destinationServer;
				bool oneWay;
				byte[] ain = ns.ReadMessage(out destinationServer, out oneWay);

				ManageAsyncResponce_Tcp resp = new ManageAsyncResponce_Tcp(_ServerName, ns);

				ManageMessage(destinationServer, oneWay, ain, resp);
			}
			catch (Exception e)
			{
				RemOpTrace.Trace(e, "ManageTcpMessage");
			}
		}

		private void ManageTcpMessageCompletition(IAsyncResult ar)
		{
			try
			{
				ManageTcpMessageDelegate d = (ManageTcpMessageDelegate) ar.AsyncState;
				d.EndInvoke(ar);
			}
			catch (Exception e)
			{
				RemOpTrace.Trace(e, "ManageTcpMessageCompletition");
			}
		}

		#endregion

		internal abstract class ManageProcessMessageResponce
		{
			public ManageProcessMessageResponce(string serverName)
			{
				_serverName = serverName;
			}

			public virtual void AsyncProcessResponse(
				IMessage msg,
				ITransportHeaders headers,
				Stream stream)
			{
				ResponseMsg = msg;
				ResponseHeaders = headers;
				ResponseStream = stream;
			}

			/// <summary>
			/// gestisce il ritorno alla chiamata ProcessMessage.
			/// Ritorna il messaggio se il chiamante (es WS) deve ritornare 
			/// il valore dalla chiamata. 
			/// Ritorna null se si puo` mandare direttamente la risposta (es tcp)
			/// </summary>
			/// <returns></returns>
			public abstract byte[] ProcessCompleteResponce();

			/// <summary>
			/// gestisce i messaggi one way
			/// </summary>
			public abstract void ProcessOneWayResponce();

			/// <summary>
			/// Gestisce il ritorno alla chiamata ProcessMessage su messaggi asincroni.
			/// Se ritorna null significa che AsyncProcessResponse ha gia` rispedito 
			/// indietro il messaggio.
			/// Se ritorna != null significa che la funzione si e` bloccata e il chiamante
			/// deve rispedire indietro la risposta (WS)
			/// </summary>
			/// <returns></returns>
			public abstract byte[] ProcessAsyncResponce();

			public string _serverName;
			public IMessage ResponseMsg;
			public ITransportHeaders ResponseHeaders;
			public Stream ResponseStream;
		}

		internal class ManageAsyncResponce_BlockCallingThread : ManageProcessMessageResponce
		{
			public ManageAsyncResponce_BlockCallingThread(string serverName)
				: base(serverName)
			{
			}


			public override byte[] ProcessCompleteResponce()
			{
				object o = ResponseHeaders[CommonTransportKeys.RequestUri];
				string URI = "";
				if (o != null)
					URI = o.ToString();

				// costruisco la risposta.
				ChannelRemOpData DataOut = new ChannelRemOpData(_serverName, URI, ResponseHeaders, ResponseStream);

				MemoryStream ms = new MemoryStream();

				BinaryFormatter bf = new BinaryFormatter();
				bf.FilterLevel = TypeFilterLevel.Full;

				bf.Serialize(ms, DataOut);

				// ritorno al chiamante che dovra` gestire la risposta.
				return ms.ToArray();
			}


			public override byte[] ProcessAsyncResponce()
			{
				_th = Thread.CurrentThread;
				_th.Suspend();

				// ritorno al chiamante che dovra` gestire la risposta.
				return _aout;
			}

			public override void AsyncProcessResponse(
				IMessage msg,
				ITransportHeaders headers,
				Stream stream)
			{
				base.AsyncProcessResponse(msg, headers, stream);

				_aout = ProcessCompleteResponce();
				_th.Resume();
			}

			public override void ProcessOneWayResponce()
			{
				// non c'e` niente da chiudere
			}

			private Thread _th;
			private byte[] _aout;
		}

		internal class ManageAsyncResponce_Tcp : ManageProcessMessageResponce
		{
			public ManageAsyncResponce_Tcp(string serverName, RemOpTcp ns)
				: base(serverName)
			{
				_ns = ns;
			}

			public override void AsyncProcessResponse(
				IMessage msg,
				ITransportHeaders headers,
				Stream stream)
			{
				base.AsyncProcessResponse(msg, headers, stream);

				byte[] aout = ProcessCompleteResponce();

				_ns.WriteMessage(string.Empty, false, aout);
				_ns.Close();
			}

			public override byte[] ProcessCompleteResponce()
			{
				object o = ResponseHeaders[CommonTransportKeys.RequestUri];
				string URI = "";
				if (o != null)
					URI = o.ToString();

				// costruisco la risposta.
				ChannelRemOpData DataOut = new ChannelRemOpData(_serverName, URI, ResponseHeaders, ResponseStream);

				MemoryStream ms = new MemoryStream();

				BinaryFormatter bf = new BinaryFormatter();
				bf.FilterLevel = TypeFilterLevel.Full;

				bf.Serialize(ms, DataOut);
				byte[] aout = ms.ToArray();

				_ns.WriteMessage(string.Empty, false, aout);
				_ns.Close();

				// ho gia` mandato il messaggio --> ritorno null
				// cosi` il chiamante non deve gestire la risposta.
				return null;
			}


			public override void ProcessOneWayResponce()
			{
				_ns.Close();
			}

			public override byte[] ProcessAsyncResponce()
			{
				// il canale lo chiude AsyncProcessResponse
				// che ha gia` mandato il messaggio

				// ho gia` mandato il messaggio --> ritorno null
				// cosi` il chiamante non deve gestire la risposta.
				return null;
			}

			private RemOpTcp _ns;
		}


		internal byte[] ManageMessage(string destinationServer, bool oneWay, byte[] ain, ManageProcessMessageResponce resp)
		{
			byte[] aout = null;

			if (_ServerName != destinationServer)
			{
				// sta puntando ad un altro server --> faccio ;'op
				ManageMessageOp(destinationServer, oneWay, ain, out aout);
			}
			else
			{
				// il messaggio e` per questo server.
				ManageRemotingMessage(ain, resp, out aout);
			}

			return aout;
		}

		private void ManageRemotingMessage(byte[] ain, ManageProcessMessageResponce resp, out byte[] aout)
		{
			aout = null;

			BinaryFormatter bf = new BinaryFormatter();
			bf.FilterLevel = TypeFilterLevel.Full;

			ChannelRemOpData DataIn = (ChannelRemOpData) bf.Deserialize(new MemoryStream(ain));

			ITransportHeaders MessageHeader = DataIn.header;
			MessageHeader[CommonTransportKeys.RequestUri] = DataIn.ObjectURI;

			Stream MessageStream = DataIn.stream;

			// miracolo del Reflector
			MessageHeader["__CustomErrorsEnabled"] = false;

			// Add ourselves to the sink stack
			ServerChannelSinkStack stack = new ServerChannelSinkStack();
			stack.Push(this, resp);


			// Start the request in the sink chain
			ServerProcessing Operation = _NextSink.ProcessMessage(stack,
			                                                       null,
			                                                       MessageHeader,
			                                                       MessageStream,
			                                                       out resp.ResponseMsg,
			                                                       out resp.ResponseHeaders,
			                                                       out resp.ResponseStream);

			// Respond to the client
			switch (Operation)
			{
				case ServerProcessing.Complete:
					stack.Pop(this);
					aout = resp.ProcessCompleteResponce();
					break;

				case ServerProcessing.Async:
					stack.StoreAndDispatch(this, resp);
					aout = resp.ProcessAsyncResponce();
					break;

				case ServerProcessing.OneWay:
					resp.ProcessOneWayResponce();
					break;
			}
		}


		public void AsyncProcessResponse(IServerResponseChannelSinkStack sinkStack,
		                                 object state,
		                                 IMessage msg,
		                                 ITransportHeaders headers,
		                                 Stream stream)
		{
			ManageProcessMessageResponce resp = (ManageProcessMessageResponce) state;
			resp.AsyncProcessResponse(msg, headers, stream);
		}


		private void ManageMessageOp(string destinationServer, bool oneWay, byte[] ain, out byte[] aout)
		{
			// Wow! si vuole fare un op e magari poi un altro
			string channelValue = _ClientChannels[destinationServer];
			if (channelValue == null)
				throw new RemotingException("tipo canale sconosciuto");

			string channelType = channelValue.Substring(0, channelValue.IndexOf(","));
			string channelData = channelValue.Substring(channelValue.IndexOf(",") + 1).Trim();

			aout = null;

			if (channelType == "ws")
			{
				RemOpSink ws = new RemOpSink();
				if (channelData[0] == '#')
					WSClient.Setup(ws, channelData.Substring(1));
				else
					ws.Url = channelData;

				aout = ws.ProcessMessage(destinationServer, ain);
			}
			else if (channelType == "tcp")
			{
				if (oneWay)
					RemOpTcp.SendOneWayMessage(channelData, destinationServer, ain);
				else
					aout = RemOpTcp.SendMessageAndWaitReplay(channelData, destinationServer, ain);
			}
		}
	}
}