using System;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;

namespace RemOpBasedChannel
{
	public class RemOpClientChannel : IChannelSender
	{
		private string m_ChannelName = "remop";
		private int m_ChannelPriority = 1;
		private StringDictionary m_ClientChannels;

		private IClientChannelSinkProvider m_ClientProvider = null;

		/*
		public RemOpClientChannel()
		{
			SetupClientChannel();
		}
		*/

		public RemOpClientChannel(IDictionary properties, IClientChannelSinkProvider sinkProvider)
		{
			if (properties != null)
			{
				m_ClientChannels = new StringDictionary();

				foreach (DictionaryEntry entry in properties)
				{
					string key = (string) entry.Key;
					if (key == "name")
					{
						m_ChannelName = (string) entry.Value;
					}
					else if (key == "priority")
					{
						m_ChannelPriority = int.Parse((string) entry.Value, CultureInfo.InvariantCulture);
					}
					else if (key.StartsWith("ch_"))
					{
						string serverName = key.Substring(3);
						string channel = (string) entry.Value;
						m_ClientChannels.Add(serverName, channel);
					}
				}
			}

			m_ClientProvider = sinkProvider;

			SetupClientChannel();
		}

		public IMessageSink CreateMessageSink(string url, object remoteChannelData, out string objectURI)
		{
			objectURI = null;
			string ChannelURI = null;

			if (url != null)
			{
				ChannelURI = Parse(url, out objectURI);
			}
			else
			{
				if ((remoteChannelData != null) && (remoteChannelData is IChannelDataStore))
				{
					IChannelDataStore DataStore = (IChannelDataStore) remoteChannelData;

					ChannelURI = Parse(DataStore.ChannelUris[0], out objectURI);
					if (ChannelURI != null)
					{
						url = DataStore.ChannelUris[0];
					}
				}
			}

			if (ChannelURI != null)
			{
				return (IMessageSink) m_ClientProvider.CreateSink(this, url, remoteChannelData);
			}

			objectURI = "";
			return null;
		}

		public string Parse(string url, out string objectURI)
		{
			return RemOpChannelHelper.Parse(url, out objectURI);
		}

		public string ChannelName
		{
			get { return m_ChannelName; }
		}

		public int ChannelPriority
		{
			get { return m_ChannelPriority; }
		}

		private void SetupClientChannel()
		{
			if (m_ClientProvider == null)
			{
				m_ClientProvider = new BinaryClientFormatterSinkProvider();
				m_ClientProvider.Next = new RemOpClientChannelSinkProvider(m_ClientChannels);
			}
			else
			{
				AddClientProviderToChain(m_ClientProvider,
				                         new RemOpClientChannelSinkProvider(m_ClientChannels));
			}
		}

		private static void AddClientProviderToChain(IClientChannelSinkProvider clientChain,
		                                             IClientChannelSinkProvider clientProvider)
		{
			while (clientChain.Next != null)
			{
				clientChain = clientChain.Next;
			}

			clientChain.Next = clientProvider;
		}

		internal StringDictionary ClientChannels
		{
			get { return m_ClientChannels; }
		}
	}

	///////////////////////////////////////////////////////////////////////////////
	internal class RemOpClientChannelSinkProvider : IClientChannelSinkProvider
	{
		private StringDictionary m_ClientChannels;

		public RemOpClientChannelSinkProvider(StringDictionary clientChannels)
		{
			m_ClientChannels = clientChannels;
		}

		public IClientChannelSink CreateSink(IChannelSender channel,
		                                     string url,
		                                     object remoteChannelData)
		{
			return new RemOpClientChannelSink(url, channel, m_ClientChannels);
		}

		public IClientChannelSinkProvider Next
		{
			get { return null; }
			set { throw new NotSupportedException(); }
		}
	}

	internal class RemOpClientChannelSink : IClientChannelSink
	{
		private StringDictionary m_ClientChannels;

		public delegate void TcpAsyncDelegate(RemOpTcp ns, IClientChannelSinkStack sinkStack);

		public RemOpClientChannelSink(string url, IChannelSender channel, StringDictionary clientChannels)
		{
			url = url;
			m_ClientChannels = clientChannels;
		}

		public void AsyncProcessRequest(IClientChannelSinkStack sinkStack,
		                                IMessage msg,
		                                ITransportHeaders requestHeaders,
		                                Stream requestStream)
		{
			string url = ExtractURI(msg);

			string objectURI;
			string destinationServer = RemOpChannelHelper.Parse(url, out objectURI);

			// mi serve per ottenere i canali di trasporto disponibili
			string channelData;
			string channelType;

			ReadChannelData(destinationServer, sinkStack, out channelType, out channelData);


			ChannelRemOpData DataIn = new ChannelRemOpData(destinationServer, objectURI, requestHeaders, requestStream);

			if (channelType == "tcp")
			{
				BinaryFormatter bf = new BinaryFormatter();
				bf.FilterLevel = TypeFilterLevel.Full;

				MemoryStream ms = new MemoryStream();
				bf.Serialize(ms, DataIn);
				byte[] ar = ms.ToArray();

				bool oneWay = IsOneWayMethod((IMethodCallMessage) msg);

				// mando il messaggio - non dovrebbe essere bloccante
				RemOpTcp ns = RemOpTcp.AsyncSendMessage(channelData, destinationServer, oneWay, ar);

				if (oneWay)
				{
					// e` OneWay --> chiudo ed esco subito
					ns.Close();
				}
				else
				{
					// qui in maniera asincrona, mi metto in ascolto della risposta
					TcpAsyncDelegate Del = new TcpAsyncDelegate(TcpAsyncHandler);
					Del.BeginInvoke(ns, sinkStack, new AsyncCallback(TcpAsyncHandlerCompletion), Del); 
				}
			}
			else if (channelType == "ws")
			{
				BinaryFormatter bf = new BinaryFormatter();
				bf.FilterLevel = TypeFilterLevel.Full;

				MemoryStream ms = new MemoryStream();
				bf.Serialize(ms, DataIn);
				byte[] ar = ms.ToArray();


				RemOpBasedChannel.WS.RemOpSink ws = new RemOpBasedChannel.WS.RemOpSink();
				if (channelData[0] == '#')
					GME.Web.WSClient.Setup(ws, channelData.Substring(1));
				else
					ws.Url = channelData;

				WsAsyncState aws = new WsAsyncState();
				aws.ws = ws;
				aws.sinkStack = sinkStack;
				aws.oneWay = IsOneWayMethod((IMethodCallMessage) msg);
				ws.BeginProcessMessage(destinationServer, ar, new AsyncCallback(WsAsyncHandler), aws);
			}
			else
				throw new RemotingException("tipo di canale non supportato");
		}

		private void ReadChannelData(string destinationServer, IClientChannelSinkStack sinkStack, out string channelType, out string channelData)
		{
			string channelValue = m_ClientChannels[destinationServer];
			if (channelValue == null)
			{
				string msg2 = string.Format("RemOpClientChannel: destinationServer {0} non configurato!", destinationServer);
				RemOpTrace.Trace(msg2);
				sinkStack.DispatchException(new RemotingException(msg2));
			}

			channelType = null;
			channelData = null;
			try
			{
				channelType = channelValue.Substring(0, channelValue.IndexOf(","));
				channelData = channelValue.Substring(channelValue.IndexOf(",") + 1).Trim();
			}
			catch (Exception e)
			{
				string msg2 = string.Format("RemOpClientChannel: destinationServer {0} configurato male !", destinationServer);
				RemOpTrace.Trace(msg2);
				sinkStack.DispatchException(new RemotingException(msg2, e));
			}
		}

		internal class WsAsyncState
		{
			public RemOpBasedChannel.WS.RemOpSink ws;
			public IClientChannelSinkStack sinkStack;
			public bool oneWay;
		}
		private static void WsAsyncHandler(IAsyncResult ar)
		{
			WsAsyncState aws = (WsAsyncState) ar.AsyncState;

			try
			{
				byte [] aout = aws.ws.EndProcessMessage(ar);

				if (aout != null && aws.oneWay == false)
				{
					BinaryFormatter bf = new BinaryFormatter();
					bf.FilterLevel = TypeFilterLevel.Full;

					ChannelRemOpData ReturnData = (ChannelRemOpData) bf.Deserialize(new MemoryStream(aout));

					aws.sinkStack.AsyncProcessResponse(ReturnData.header, ReturnData.stream);
				}
			}
			catch (Exception e)
			{
				if (aws.sinkStack != null)
					aws.sinkStack.DispatchException(e);
			}
		}

		private static void TcpAsyncHandler(RemOpTcp ns, IClientChannelSinkStack sinkStack)
		{
			try
			{
				string destinationServer;
				bool oneWay;
				byte[] ar = ns.ReadMessage(out destinationServer, out oneWay);
				ns.Close();
				MemoryStream ms = new MemoryStream(ar);

				BinaryFormatter bf = new BinaryFormatter();
				bf.FilterLevel = TypeFilterLevel.Full;

				ChannelRemOpData ReturnData = (ChannelRemOpData) bf.Deserialize(new MemoryStream(ar));

				sinkStack.AsyncProcessResponse(ReturnData.header, ReturnData.stream);
			}
			catch (Exception e)
			{
				if (sinkStack != null)
					sinkStack.DispatchException(e);
			}
		}
		private static void TcpAsyncHandlerCompletion(IAsyncResult ar)
		{
			TcpAsyncDelegate d = (TcpAsyncDelegate) ar.AsyncState;
			d.EndInvoke(ar);
		}


		public void AsyncProcessResponse(IClientResponseChannelSinkStack sinkStack,
		                                 object state,
		                                 ITransportHeaders headers,
		                                 Stream stream)
		{
			throw new NotSupportedException();
		}

		public Stream GetRequestStream(IMessage msg, ITransportHeaders headers)
		{
			return null;
		}

		public void ProcessMessage(IMessage msg,
		                           ITransportHeaders requestHeaders,
		                           Stream requestStream,
		                           out ITransportHeaders responseHeaders,
		                           out Stream responseStream)
		{
			responseHeaders = null;
			responseStream = null;

			string url = ExtractURI(msg);

			string objectURI;
			string destinationServer = RemOpChannelHelper.Parse(url, out objectURI);

			// mi serve per ottenere i canali di trasporto disponibili
			string channelValue = m_ClientChannels[destinationServer];
			if (channelValue == null)
			{
				
			}
			string channelType = channelValue.Substring(0, channelValue.IndexOf(","));
			string channelData = channelValue.Substring(channelValue.IndexOf(",") + 1).Trim();

			ChannelRemOpData dataIn = new ChannelRemOpData(destinationServer, objectURI, requestHeaders, requestStream);

			///////////////////////////////////////
			ChannelRemOpData ReturnData = null;

			if (channelType == "ws")
			{
				BinaryFormatter bf = new BinaryFormatter();
				bf.FilterLevel = TypeFilterLevel.Full;

				MemoryStream ms = new MemoryStream();
				bf.Serialize(ms, dataIn);
				byte[] ar = ms.ToArray();


				RemOpBasedChannel.WS.RemOpSink ws = new RemOpBasedChannel.WS.RemOpSink();
				if (channelData[0] == '#')
					GME.Web.WSClient.Setup(ws, channelData.Substring(1));
				else
					ws.Url = channelData;

				ar = ws.ProcessMessage(destinationServer, ar);

				ReturnData = (ChannelRemOpData) bf.Deserialize(new MemoryStream(ar));
			}
			else if (channelType == "tcp")
			{
				BinaryFormatter bf = new BinaryFormatter();
				bf.FilterLevel = TypeFilterLevel.Full;

				MemoryStream ms = new MemoryStream();
				bf.Serialize(ms, dataIn);
				byte[] ar = ms.ToArray();

				ar = RemOpTcp.SendMessageAndWaitReplay(channelData, destinationServer, ar);

				ReturnData = (ChannelRemOpData) bf.Deserialize(new MemoryStream(ar));
			}
			else
			{
				RemOpTrace.Trace("RemOpClientChannelSink: tipo canale sconosciuto");
				throw new RemotingException("RemOpClientChannelSink: Tipo di canale sconosciuto");
			}

			responseHeaders = ReturnData.header;
			responseStream = ReturnData.stream;
		}


		public IClientChannelSink NextChannelSink
		{
			get { return null; }
		}

		public IDictionary Properties
		{
			get { return null; }
		}

		private string ExtractURI(IMessage msg)
		{
			return ((IMethodCallMessage) msg).Uri;
		}

		private bool IsOneWayMethod(IMethodCallMessage methodCallMessage)
		{
			MethodBase methodBase = methodCallMessage.MethodBase;
			return RemotingServices.IsOneWay(methodBase);
		}

	}
}