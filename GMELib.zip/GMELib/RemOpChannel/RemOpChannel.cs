using System;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Messaging;

namespace RemOpBasedChannel
{
	/// <summary>
	/// Classe per fare una canale custom di remoting.
	/// Serve per avere un canale unico tra cliente e server
	/// anche se tra i due c'e` internet, certificati, firewall, op ecc.
	/// In pratica si ha una canale unico che 
	/// pero` allinterno puo` transitare tra canali fisici diversi:
	/// un classico esempio:
	/// WS tra host remote e WebServer
	/// WS tra WebServer e ApplictionServer WS
	/// tcp tra ApplictionServer WS e un servizio nella stessa macchina
	/// 
	/// Non mi perdo in dettagli dato che la struttura del remoting e` semplice ;-)
	/// </summary>
	public class RemOpChannel : IChannelSender, IChannelReceiver
	{
		private RemOpClientChannel m_ClientChannel = null;
		private RemOpServerChannel m_ServerChannel = null;


		/*
		public RemOpChannel()
		{
			m_ClientChannel = new RemOpClientChannel();
		}

		public RemOpChannel(string serverPath)
		{
			m_ServerChannel = new RemOpServerChannel(serverPath);
		}
		*/

		public RemOpChannel(IDictionary properties,
		                    IClientChannelSinkProvider clientProviderChain,
		                    IServerChannelSinkProvider serverProviderChain)
		{
			m_ClientChannel = new RemOpClientChannel(properties, clientProviderChain);
			m_ServerChannel = new RemOpServerChannel(properties, serverProviderChain);
		}

		// IChannelReceiver / IChannelSender
		public string Parse(string url, out string objectURI)
		{
			return RemOpChannelHelper.Parse(url, out objectURI);
		}

		// IChannelReceiver / IChannelSender
		public string ChannelName
		{
			get
			{
				if (m_ServerChannel != null)
				{
					return m_ServerChannel.ChannelName;
				}
				else
				{
					return m_ClientChannel.ChannelName;
				}
			}
		}

		// IChannelReceiver / IChannelSender
		public int ChannelPriority
		{
			get
			{
				if (m_ServerChannel != null)
				{
					return m_ServerChannel.ChannelPriority;
				}
				else
				{
					return m_ClientChannel.ChannelPriority;
				}
			}
		}

		// IChannelReceiver
		public object ChannelData
		{
			get
			{
				if (m_ServerChannel != null)
				{
					return m_ServerChannel.ChannelData;
				}

				return null;
			}
		}

		// IChannelReceiver
		public string[] GetUrlsForUri(string objectURI)
		{
			return m_ServerChannel.GetUrlsForUri(objectURI);
		}

		// IChannelReceiver
		public void StartListening(object data)
		{
			m_ServerChannel.StartListening(data);
		}

		// IChannelReceiver
		public void StopListening(object data)
		{
			m_ServerChannel.StopListening(data);
		}

		// IChannelSender
		public IMessageSink CreateMessageSink(string url, object remoteChannelData, out string objectURI)
		{
			return m_ClientChannel.CreateMessageSink(url, remoteChannelData, out objectURI);
		}

		public byte[] ServiceRequest(string destinationServer, bool oneWay, byte[] ain)
		{
			return m_ServerChannel.ServiceRequest(destinationServer, oneWay, ain);
		}

		public static byte [] ServiceSequest(string destinationServer, bool oneWay, byte[] ain)
		{
			foreach (IChannel ch in ChannelServices.RegisteredChannels)
			{					
				if (ch is RemOpBasedChannel.RemOpChannel)
				{
					RemOpBasedChannel.RemOpChannel rs = (RemOpBasedChannel.RemOpChannel)ch;

					byte [] aout = rs.ServiceRequest(destinationServer, oneWay, ain);
					return aout;
				}
			}

			return null;
		}

		public static byte [] ServiceSequest(bool oneWay, byte [] header, byte[] message)
		{
			throw new NotImplementedException();
		}

		public string _ServerName
		{
			get
			{
				if (m_ServerChannel != null)
					return m_ServerChannel.ServerName;
				return null;
			}
		}

		public static string ServerName
		{
			get
			{
				foreach (IChannel ch in ChannelServices.RegisteredChannels)
				{					
					if (ch is RemOpBasedChannel.RemOpChannel)
					{
						RemOpChannel rs = (RemOpChannel)ch;
						return rs._ServerName;
					}
				}
				return null;
			}
		}
	}

	internal class RemOpTrace
	{
		public static void Trace(string msg)
		{
			System.Diagnostics.Trace.WriteLine("RemOpChannel: {0}" , msg);
		}

		public static void Trace(Exception ex)
		{
			Trace(ex, null);
		}

		public static void Trace(Exception ex, string msg)
		{
			if (msg != null)
				System.Diagnostics.Trace.WriteLine("RemOpChannel - Eccezione: {0}", msg);
			else
				System.Diagnostics.Trace.WriteLine("RemOpChannel - Eccezione:");

			System.Diagnostics.Trace.WriteLine("{");
			System.Diagnostics.Trace.WriteLine("{0}" , ex.Message);
			System.Diagnostics.Trace.WriteLine("{1}", ex.StackTrace);
			System.Diagnostics.Trace.WriteLine("}");
			System.Diagnostics.Trace.WriteLine("");
		}
	}
}