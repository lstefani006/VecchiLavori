using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using System.Web.Services.Protocols;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmGestionePINSocieta.
	/// </summary>
	public class frmGestionePINSocieta : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btEsci;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Label lblRagioneSociale;
		private System.Windows.Forms.Label lblCodiceConto;
		private System.Windows.Forms.Label lblPINSoc;
		private System.Windows.Forms.ComboBox cbRagioneSociale;
		private System.Windows.Forms.ComboBox cbCodiceConto;
		private System.Windows.Forms.Button btnCambiaPINSoc;
		private System.Windows.Forms.TextBox edtPINSoc;
		
		DataSet _dsListaRichiesteSocietaUtenti ;

		BindingManagerBase _bmSocieta;

		public frmGestionePINSocieta()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Recupero dal DB le informazioni sulle richieste di registrazione
			// delle societa'
			_dsListaRichiesteSocietaUtenti = GetListaRichiesteSocieta();
			if (_dsListaRichiesteSocietaUtenti == null)
			{
				DisabilitaComponenti();
				return;
			}

			// Data Binding della tabella "Societa'" con la ComboBox contenente le Ragioni Sociali
			cbRagioneSociale.DataSource    = _dsListaRichiesteSocietaUtenti;
			cbRagioneSociale.DisplayMember = "RichiestaSocieta.RagioneSociale";
			cbRagioneSociale.ValueMember   = "RichiestaSocieta.IdRichiestaRegSoc";

			// Data Binding della tabella "Societa'" con la ComboBox contenente il Codice Conto delle societa'
			cbCodiceConto.DataSource    = _dsListaRichiesteSocietaUtenti;
			cbCodiceConto.DisplayMember = "RichiestaSocieta.CodiceConto";
			cbCodiceConto.ValueMember   = "RichiestaSocieta.IdRichiestaRegSoc";

			Binding bnd;

			// Data Binding della tabella "Societa'" con la ComboBox contenente il PIN Societario
			bnd = edtPINSoc.DataBindings.Add("Text", _dsListaRichiesteSocietaUtenti, "RichiestaSocieta.PINSoc");

			_bmSocieta = this.BindingContext[_dsListaRichiesteSocietaUtenti, "RichiestaSocieta"];
			_bmSocieta.PositionChanged += new EventHandler(BindingManagerBase_PositionChanged);

		}

		private void BindingManagerBase_PositionChanged(object sender, EventArgs e)
		{
			
		}

		public DataRow CurrentRow
		{
			get 
			{
				if (_bmSocieta.Current.GetType() != typeof(DataRowView))
					return null;
				
				DataRow dr = ((DataRowView)_bmSocieta.Current).Row;
				return dr;
			}
		}

		private void DisabilitaComponenti()
		{
			btnCambiaPINSoc.Enabled = false;	
		}

		private DataSet GetListaRichiesteSocieta()
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLRichieste.BLRichieste.Search");

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		private bool AggiornaDataSet(DataSet ds)
		{
			try
			{
				// Verifico se sono state effettuate delle modifiche alle tabelle del DataSet
				if (!ds.HasChanges()) 
				{
					ds.AcceptChanges();
					return true;
				}

				DataSet xDataSet;
				// GetChanges solo per le righe modificate
				xDataSet = ds.GetChanges();

				if (xDataSet == null)
				{
					ds.AcceptChanges();
					return true;
				}

				CVAdminWSBLRichieste.BLRichieste ws = new CVAdminWSBLRichieste.BLRichieste();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginUpdate(xDataSet, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return false;

				// il Web Service ha risposto... prendo il risultato
				DataSet dsUpdated = ws.EndUpdate(asr);
				if (dsUpdated != null)
				{
					ds.AcceptChanges();
					return true;
				}
				else
				{
					ds.RejectChanges();
					return false;
				}
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return false;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return false;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmGestionePINSocieta));
			this.btEsci = new System.Windows.Forms.Button();
			this.lblRagioneSociale = new System.Windows.Forms.Label();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.lblPINSoc = new System.Windows.Forms.Label();
			this.cbRagioneSociale = new System.Windows.Forms.ComboBox();
			this.cbCodiceConto = new System.Windows.Forms.ComboBox();
			this.btnCambiaPINSoc = new System.Windows.Forms.Button();
			this.edtPINSoc = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// btEsci
			// 
			this.btEsci.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btEsci.Location = new System.Drawing.Point(240, 96);
			this.btEsci.Name = "btEsci";
			this.btEsci.Size = new System.Drawing.Size(176, 24);
			this.btEsci.TabIndex = 5;
			this.btEsci.Text = "&Chiudi";
			this.btEsci.Click += new System.EventHandler(this.btEsci_Click);
			// 
			// lblRagioneSociale
			// 
			this.lblRagioneSociale.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.lblRagioneSociale.Location = new System.Drawing.Point(8, 16);
			this.lblRagioneSociale.Name = "lblRagioneSociale";
			this.lblRagioneSociale.Size = new System.Drawing.Size(88, 16);
			this.lblRagioneSociale.TabIndex = 6;
			this.lblRagioneSociale.Text = "Ragione Sociale";
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.lblCodiceConto.Location = new System.Drawing.Point(8, 40);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(88, 16);
			this.lblCodiceConto.TabIndex = 9;
			this.lblCodiceConto.Text = "Codice Conto";
			// 
			// lblPINSoc
			// 
			this.lblPINSoc.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.lblPINSoc.Location = new System.Drawing.Point(8, 64);
			this.lblPINSoc.Name = "lblPINSoc";
			this.lblPINSoc.Size = new System.Drawing.Size(88, 16);
			this.lblPINSoc.TabIndex = 10;
			this.lblPINSoc.Text = "PIN Societario";
			// 
			// cbRagioneSociale
			// 
			this.cbRagioneSociale.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cbRagioneSociale.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.cbRagioneSociale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbRagioneSociale.Location = new System.Drawing.Point(96, 8);
			this.cbRagioneSociale.Name = "cbRagioneSociale";
			this.cbRagioneSociale.Size = new System.Drawing.Size(320, 21);
			this.cbRagioneSociale.TabIndex = 11;
			// 
			// cbCodiceConto
			// 
			this.cbCodiceConto.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cbCodiceConto.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.cbCodiceConto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCodiceConto.Location = new System.Drawing.Point(96, 32);
			this.cbCodiceConto.Name = "cbCodiceConto";
			this.cbCodiceConto.Size = new System.Drawing.Size(320, 21);
			this.cbCodiceConto.TabIndex = 12;
			// 
			// btnCambiaPINSoc
			// 
			this.btnCambiaPINSoc.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnCambiaPINSoc.Location = new System.Drawing.Point(8, 96);
			this.btnCambiaPINSoc.Name = "btnCambiaPINSoc";
			this.btnCambiaPINSoc.Size = new System.Drawing.Size(176, 24);
			this.btnCambiaPINSoc.TabIndex = 14;
			this.btnCambiaPINSoc.Text = "&Genera Nuovo PIN Societario";
			this.btnCambiaPINSoc.Click += new System.EventHandler(this.btnCambiaPINSoc_Click);
			// 
			// edtPINSoc
			// 
			this.edtPINSoc.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtPINSoc.Location = new System.Drawing.Point(96, 56);
			this.edtPINSoc.Name = "edtPINSoc";
			this.edtPINSoc.ReadOnly = true;
			this.edtPINSoc.Size = new System.Drawing.Size(320, 20);
			this.edtPINSoc.TabIndex = 15;
			this.edtPINSoc.Text = "";
			// 
			// frmGestionePINSocieta
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(424, 133);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.edtPINSoc,
																		  this.btnCambiaPINSoc,
																		  this.cbCodiceConto,
																		  this.cbRagioneSociale,
																		  this.lblPINSoc,
																		  this.lblCodiceConto,
																		  this.lblRagioneSociale,
																		  this.btEsci});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmGestionePINSocieta";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Gestione del PIN Societario";
			this.ResumeLayout(false);

		}
		#endregion

		private void btEsci_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void btnCambiaPINSoc_Click(object sender, System.EventArgs e)
		{
			if (edtPINSoc.Text != "")
			{
				DialogResult result = MessageBox.Show("Sei sicuro di voler modificare il PIN della societa' " + cbRagioneSociale.Text + " ?", "Conferma generazione nuovo PIN", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
				if (result  == DialogResult.No)
					return;
			}

			// Aggiorno PINSoc
			DataRow dr = CurrentRow ;
			dr.BeginEdit();
			dr["PINSoc"] = Guid.NewGuid().ToString("N").ToUpper();
			dr.EndEdit();

			AggiornaDataSet(_dsListaRichiesteSocietaUtenti);
		}
	}
}
