using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmReport.
	/// </summary>
	public class frmReport : System.Windows.Forms.Form
	{
		#region Controlli frmReport
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton rbAcquisti;
		private System.Windows.Forms.RadioButton rbVendite;
		private System.Windows.Forms.RadioButton rbAcquistiVendita;
		private System.Windows.Forms.Button btnCancella;
		private System.Windows.Forms.Button btnCreaReport;
		private System.Windows.Forms.SaveFileDialog saveFileDialogReport;
		private System.Windows.Forms.ComboBox cbSessione;
		private System.Windows.Forms.ComboBox cbSocieta;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbCodiceConto;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		#endregion

		DataSet _dsSocieta ;

		public frmReport()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			if (true)
			{
				DataSet dsSessione = Sessioni_GetLst();
				if (dsSessione == null)
					return;  // TODO disabilitare tutto
				cbSessione.DataSource = dsSessione;
				cbSessione.DisplayMember = "Sessioni.Titolo";
				cbSessione.ValueMember = "Sessioni.IdSessione";
				cbSessione.SelectedIndex = 0;
			}

			if (true)
			{
				_dsSocieta = Societa_Retreive_Parameters();
				if (_dsSocieta == null)
					return; // TODO disabilitare tutto
				cbSocieta.DataSource = _dsSocieta;
				cbSocieta.DisplayMember = "Societa_RagioneSociale_CodiceConto.RagioneSociale";
				cbSocieta.ValueMember   = "Societa_RagioneSociale_CodiceConto.IdSocieta";
				cbSocieta.SelectedIndex = 0;

				cbCodiceConto.DataSource = _dsSocieta;
				cbCodiceConto.DisplayMember = "Societa_RagioneSociale_CodiceConto.CodiceConto";
				cbCodiceConto.ValueMember   = "Societa_RagioneSociale_CodiceConto.IdSocieta";
				cbCodiceConto.SelectedIndex = 0;
			}
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmReport));
			this.cbSessione = new System.Windows.Forms.ComboBox();
			this.cbSocieta = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.rbAcquistiVendita = new System.Windows.Forms.RadioButton();
			this.rbVendite = new System.Windows.Forms.RadioButton();
			this.rbAcquisti = new System.Windows.Forms.RadioButton();
			this.btnCancella = new System.Windows.Forms.Button();
			this.btnCreaReport = new System.Windows.Forms.Button();
			this.saveFileDialogReport = new System.Windows.Forms.SaveFileDialog();
			this.label3 = new System.Windows.Forms.Label();
			this.cbCodiceConto = new System.Windows.Forms.ComboBox();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// cbSessione
			// 
			this.cbSessione.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbSessione.Location = new System.Drawing.Point(136, 8);
			this.cbSessione.Name = "cbSessione";
			this.cbSessione.Size = new System.Drawing.Size(368, 21);
			this.cbSessione.TabIndex = 0;
			// 
			// cbSocieta
			// 
			this.cbSocieta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbSocieta.Location = new System.Drawing.Point(136, 32);
			this.cbSocieta.Name = "cbSocieta";
			this.cbSocieta.Size = new System.Drawing.Size(368, 21);
			this.cbSocieta.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 24);
			this.label1.TabIndex = 2;
			this.label1.Text = "Sessione:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(112, 24);
			this.label2.TabIndex = 3;
			this.label2.Text = "Ragione sociale:";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.rbAcquistiVendita,
																					this.rbVendite,
																					this.rbAcquisti});
			this.groupBox1.Location = new System.Drawing.Point(16, 96);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(248, 128);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Tipo di report";
			// 
			// rbAcquistiVendita
			// 
			this.rbAcquistiVendita.Location = new System.Drawing.Point(16, 88);
			this.rbAcquistiVendita.Name = "rbAcquistiVendita";
			this.rbAcquistiVendita.Size = new System.Drawing.Size(200, 24);
			this.rbAcquistiVendita.TabIndex = 2;
			this.rbAcquistiVendita.Text = "Report acquisti/vendite";
			// 
			// rbVendite
			// 
			this.rbVendite.Location = new System.Drawing.Point(16, 56);
			this.rbVendite.Name = "rbVendite";
			this.rbVendite.Size = new System.Drawing.Size(200, 24);
			this.rbVendite.TabIndex = 1;
			this.rbVendite.Text = "Report vendite";
			// 
			// rbAcquisti
			// 
			this.rbAcquisti.Checked = true;
			this.rbAcquisti.Location = new System.Drawing.Point(16, 24);
			this.rbAcquisti.Name = "rbAcquisti";
			this.rbAcquisti.Size = new System.Drawing.Size(200, 24);
			this.rbAcquisti.TabIndex = 0;
			this.rbAcquisti.TabStop = true;
			this.rbAcquisti.Text = "Report acquisti";
			// 
			// btnCancella
			// 
			this.btnCancella.Location = new System.Drawing.Point(408, 240);
			this.btnCancella.Name = "btnCancella";
			this.btnCancella.Size = new System.Drawing.Size(96, 24);
			this.btnCancella.TabIndex = 5;
			this.btnCancella.Text = "Cancella";
			this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
			// 
			// btnCreaReport
			// 
			this.btnCreaReport.Location = new System.Drawing.Point(304, 240);
			this.btnCreaReport.Name = "btnCreaReport";
			this.btnCreaReport.Size = new System.Drawing.Size(96, 24);
			this.btnCreaReport.TabIndex = 6;
			this.btnCreaReport.Text = "Crea report";
			this.btnCreaReport.Click += new System.EventHandler(this.btnCreaReport_Click);
			// 
			// saveFileDialogReport
			// 
			this.saveFileDialogReport.Filter = "doc file (*.doc)|*.doc";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 64);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(112, 24);
			this.label3.TabIndex = 7;
			this.label3.Text = "Codice Conto:";
			// 
			// cbCodiceConto
			// 
			this.cbCodiceConto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCodiceConto.Location = new System.Drawing.Point(136, 56);
			this.cbCodiceConto.Name = "cbCodiceConto";
			this.cbCodiceConto.Size = new System.Drawing.Size(368, 21);
			this.cbCodiceConto.TabIndex = 8;
			// 
			// frmReport
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(514, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cbCodiceConto,
																		  this.label3,
																		  this.btnCreaReport,
																		  this.btnCancella,
																		  this.groupBox1,
																		  this.label2,
																		  this.label1,
																		  this.cbSocieta,
																		  this.cbSessione});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmReport";
			this.ShowInTaskbar = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Creazione report";
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		#region Funzioni statiche per chiamare i Web Services
		static DataSet Sessioni_GetLst()
		{
			bool Cancelled = false;
			if (Cancelled)
				return new CVAdmin_Main.CVAdimWSBLSessioni.BLSessioni().GetLst();
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdimWSBLSessioni.BLSessioni.GetLst");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}
		static DataSet Societa_Retreive_Parameters()
		{
			bool Cancelled = false;
			if (Cancelled)
				return new CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta().Retreive_Parameters("RagioneSociale_CodiceConto");
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.Retreive_Parameters", "RagioneSociale_CodiceConto");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}
		static DataSet Sessione_Retrieve(string IdSessione)
		{
			bool Cancelled = false;
			if (Cancelled)
				return new CVAdmin_Main.CVAdminWSBLSessione.BLSessione().Retrieve(IdSessione, "", "");
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdminWSBLSessione.BLSessione().Retrieve", IdSessione, "", "");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}
		static DataSet Budget_Retrieve(string IdSocieta, string IdSessione)
		{
			bool Cancelled = false;
			if (Cancelled)
				return new CVAdmin_Main.CVAdminWSBLBudget.BLBudget().Retrieve(IdSocieta, IdSessione);
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdminWSBLBudget.BLBudget.Retrieve", IdSocieta, IdSessione);
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}
		#endregion
		

		#region Eventi
		private void btnCancella_Click(object sender, System.EventArgs e)
		{	
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void btnCreaReport_Click(object sender, System.EventArgs e)
		{
			try
			{
				Cursor.Current = Cursors.WaitCursor;

				string IdSocieta      = (string)cbSocieta.SelectedValue;
				string RagioneSociale = (string)cbSocieta.Text;

				string IdSessione     = (string)cbSessione.SelectedValue;

				DataRow[] r = _dsSocieta.Tables[0].Select("IdSocieta = '" + IdSocieta + "'") ;
				string PartitaIVA ;
				if (r.Length != 0)
				{
					PartitaIVA = (string)r[0]["PartitaIVA"] ;
				}
				else
				{
					PartitaIVA = "" ;
				}

				DataSet dsSessione = Sessione_Retrieve(IdSessione);
				if (dsSessione == null)
					return;

				DataSet dsBudget = Budget_Retrieve(IdSocieta, IdSessione);
				if (dsBudget == null)
					return;

				saveFileDialogReport.InitialDirectory = UtilityEnvironment.CommonAppDir;
				if (saveFileDialogReport.ShowDialog() != DialogResult.OK)
					return;

				string fn = saveFileDialogReport.FileName;

				btnCancella.Enabled = false;
				btnCreaReport.Enabled = false;
				Application.DoEvents();
				btnCancella.Enabled = true;
				btnCreaReport.Enabled = true;

				Cursor.Current = Cursors.WaitCursor;


				// parte funambolica - scarico il file .dot per le funzioni CreaReportXYZ
				string fnWordDot = null;
				using (WebClient webClient = new WebClient())
				{
					string fnTmp = System.IO.Path.GetTempFileName();
					string CVAdminURL = System.Configuration.ConfigurationSettings.AppSettings["CVAdminWebServerURL"];
					webClient.DownloadFile(CVAdminURL + "/CartaIntestataGME.dot", fnTmp);

					fnWordDot = fnTmp + ".dot";
					System.IO.File.Move(fnTmp, fnWordDot);
				}

				if (rbAcquisti.Checked)
				{
					frmReportHelper.CreaReportAcquisti(dsSessione, dsBudget, IdSocieta, RagioneSociale, PartitaIVA, fnWordDot, fn);
					
					// Mia Aggiunta
					//FileStream f = new FileStream("C:\\Acquisti.htm", FileMode.Create, FileAccess.Write);
					//StreamWriter sw = new StreamWriter(f);
					//CVAdminWSBLConferme.BLConferme bl = new CVAdminWSBLConferme.BLConferme();
					//frmLogin.AddLoginInfo(bl);
					//string fris = bl.ConfermeAcquisti(dsSessione, dsBudget, IdSocieta, RagioneSociale, PartitaIVA);
					//sw.Write(fris);
					//sw.Close();
					// Fine
				}
				else if (rbVendite.Checked)
				{
					frmReportHelper.CreaReportVenditori(dsSessione, IdSocieta, RagioneSociale, PartitaIVA, fnWordDot, fn);

					// Mia Aggiunta
					//FileStream f = new FileStream("C:\\Vendite.htm", FileMode.Create, FileAccess.Write);
					//StreamWriter sw = new StreamWriter(f);
					//CVAdminWSBLConferme.BLConferme bl = new CVAdminWSBLConferme.BLConferme();
					//frmLogin.AddLoginInfo(bl);
					//string fris = bl.ConfermeVenditori(dsSessione, IdSocieta, RagioneSociale, PartitaIVA);
					//sw.Write(fris);
					//sw.Close();
					// Fine
				}
				else if (rbAcquistiVendita.Checked)
				{
					string fnDir = System.IO.Path.GetDirectoryName(fn);
					string fnNoExt = System.IO.Path.GetFileNameWithoutExtension(fn);
					string fnExt = System.IO.Path.GetExtension(fn);

					string fnA = BuildPath(fnDir, fnNoExt + "-ACQUISTO", fnExt);
					string fnV = BuildPath(fnDir, fnNoExt + "-VENDITA",  fnExt);

					frmReportHelper.CreaReportAcquisti(dsSessione, dsBudget, IdSocieta, RagioneSociale, PartitaIVA, fnWordDot, fnA);
					frmReportHelper.CreaReportVenditori(dsSessione, IdSocieta, RagioneSociale, PartitaIVA, fnWordDot, fnV);
				}
				MessageBox.Show("Report creati con successo", "Messaggio");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Errore");
			}

			GC.Collect();
		}

		static string BuildPath(string dir, string fn, string ext)
		{
			string ret = "";

			if (dir != null && dir != "")
			{
				ret += dir;
				ret += System.IO.Path.DirectorySeparatorChar;
			}

			ret += fn;

			if (ext != null && ext != "")
			{
				if (ext[0] != '.')
					ret += ".";
				ret += ext;
			}

			return ret;
		}
		#endregion
	}
}
