using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmConfermaEtValuta.
	/// </summary>
	public class frmConfermaEtValuta : System.Windows.Forms.Form
	{
		public static DialogResult Show(string msg, string ValuteRichieste, out DateTime v1)
		{
			v1 = DateTime.MinValue;

			frmConfermaEtValuta  f = new frmConfermaEtValuta(msg, ValuteRichieste);
			DialogResult r = f.ShowDialog();
			
			Debug.Assert(f._tp.Length == 1);

			if (r == DialogResult.Yes)
			{
				v1 = f._tp[0].Value;
			}

			return r;
		}

		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmConfermaEtValuta));
			// 
			// frmConfermaEtValuta
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmConfermaEtValuta";

		}
	
		public static DialogResult Show(string msg, string ValuteRichieste, out DateTime v1, out DateTime v2)
		{
			v1 = DateTime.MinValue;
			v2 = DateTime.MinValue;

			frmConfermaEtValuta  f = new frmConfermaEtValuta(msg, ValuteRichieste);
			DialogResult r = f.ShowDialog();

			Debug.Assert(f._tp.Length == 2);

			if (r == DialogResult.Yes)
			{
				v1 = f._tp[0].Value;
				v2 = f._tp[1].Value;
			}

			return r;
		}
		public static DialogResult Show(string msg, string ValuteRichieste, out DateTime v1, out DateTime v2, out DateTime v3)
		{
			v1 = DateTime.MinValue;
			v2 = DateTime.MinValue;
			v3 = DateTime.MinValue;

			frmConfermaEtValuta  f = new frmConfermaEtValuta(msg, ValuteRichieste);
			DialogResult r = f.ShowDialog();

			Debug.Assert(f._tp.Length == 3);

			if (r == DialogResult.Yes)
			{
				v1 = f._tp[0].Value;
				v2 = f._tp[1].Value;
				v3 = f._tp[2].Value;
			}

			return r;
		}

		private Button btnNo;
		private Button btnSi;
		private DateTimePicker [] _tp;

		private frmConfermaEtValuta(string msg, string ValuteRichieste)
		{
			this.DialogResult = DialogResult.No;
			string [] vr = ValuteRichieste.Split('|');
			_tp = new DateTimePicker[vr.Length];

			int ts = 0;

			this.SuspendLayout();

			TextBox txtMsg = new TextBox();
			txtMsg.Location = new Point(8, 8);
			txtMsg.Size = new Size(440, 104);
			txtMsg.Multiline = true;
			txtMsg.ReadOnly = true;
			txtMsg.Text = msg.Replace("\n", "\r\n");
			txtMsg.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			txtMsg.TabStop = false;
			this.Controls.Add(txtMsg);

			GroupBox g = null;
			if (true)
			{
				int y = txtMsg.Location.Y + txtMsg.Height + 20;

				g = new GroupBox();
				g.Text = "Date richieste per l'operazione";
				g.Location = new Point(txtMsg.Location.X, y);
				g.Size = new Size(txtMsg.Size.Width, vr.Length * 30 + 25);
				g.Anchor = AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right;
				this.Controls.Add(g);
			}

			if (true)
			{
				int yg = 20;
				for (int i = 0; i < vr.Length; ++i)
				{
					Label lbl = new Label();
					lbl.Text = vr[i];
					lbl.Location = new Point(16, yg);
					lbl.Size = new Size(220, 23);
					lbl.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
					lbl.TabStop = false;
					g.Controls.Add(lbl);

					DateTimePicker tp = new DateTimePicker();
					tp.Location = new Point(240, yg);
					tp.Size = new Size(180, 20);
					tp.Value = DateTime.Now;
					tp.Format = DateTimePickerFormat.Long;
					tp.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
					tp.TabStop = true;
					tp.TabIndex = ts++;
					_tp[i] = tp;
					g.Controls.Add(tp);

					yg += 30;
				}
			}

			if (true)
			{
				int y = g.Location.Y + g.Size.Height + 15;

				int dx = 144;

				int xNo = txtMsg.Location.X + txtMsg.Size.Width - dx;
				int xSi = xNo - 15 - dx;

				btnNo = new Button();
				btnNo.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
				btnNo.Location = new Point(xNo, y);
				btnNo.Name = "btnNo";
				btnNo.Size = new Size(dx, 24);
				btnNo.TabStop = true;
				btnNo.TabIndex = ts++;
				btnNo.Text = "No";
				btnNo.Click += new System.EventHandler(this.btnNo_Click);
				this.Controls.Add(btnNo);

				btnSi = new Button();
				btnSi.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
				btnSi.Location = new Point(xSi, y);
				btnSi.Name = "btnSi";
				btnSi.Size = new Size(dx, 24);
				btnSi.TabStop = true;
				btnSi.TabIndex = ts++;
				btnSi.Text = "Si";
				btnSi.Click += new System.EventHandler(this.btnSi_Click);
				this.Controls.Add(btnSi);
			}

			if (true)
			{
				int y = btnSi.Location.Y + btnSi.Size.Height + txtMsg.Location.Y;

				this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
				this.ClientSize = new Size(txtMsg.Location.X + txtMsg.Size.Width + txtMsg.Location.X, y);
				this.MaximizeBox = false;
				this.MinimizeBox = false;
				this.ControlBox = false;
				this.FormBorderStyle = FormBorderStyle.FixedDialog;
				this.Name = "frmConfermaEtValuta";
				this.StartPosition = FormStartPosition.CenterScreen;
				this.Text = "Conferma operazione";
				this.ResumeLayout(false);
			}

			this.DialogResult = DialogResult.No;
		}

		private void btnSi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Yes;
			this.Close();
		}

		private void btnNo_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.No;
			this.Close();
		}
	}
}
