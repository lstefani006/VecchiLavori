using System;
using System.Net;
using System.IO;
using System.Text;
using System.Net.Sockets;
using System.Diagnostics;
using System.Globalization;

namespace FtpClientLib
{
	public delegate void ConnectedDelegate();
	public delegate void UploadDelegate(string localFile, long bytesSent, long bytesToSend);
	public delegate void DownloadDelegate(long bytesReceived, long bytesToReceive);
	public delegate void MessageFromSeverDelegate(string msg);
	public delegate void CommandFromClientDelegate(string cmd);

	public class FTPClientException : IOException
	{
		public FTPClientException(string reply)
			: base(reply)
		{
			_code = -1;
			try
			{
				_code = Convert.ToInt32(reply.Substring(0, 3));
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.Message);
			}
		}

		public int FtpCode { get { return _code; } }

		private int    _code;
	}


	public class FTPClient : IDisposable
	{
		#region Private data
		private string remoteHost, remotePath, remoteUser, remotePass, mes;
		private int remotePort, bytes;
		private Socket _clientSocket;
		private bool _logined;
		private string reply;
		private int retValue;
		private static int BLOCK_SIZE = 512;
		private Byte[] buffer = new Byte[BLOCK_SIZE];
		private Encoding ASCII = Encoding.ASCII;
		private bool disposed = false;
		#endregion

		public event ConnectedDelegate         ConnectedEvent;
		public event UploadDelegate            UploadEvent;
		public event DownloadDelegate          DownloadEvent;
		public event MessageFromSeverDelegate  MessageFromSeverEvent;
		public event CommandFromClientDelegate CommandFromClientEvent;


		public FTPClient()
		{
			remoteHost  = "localhost";
			remotePath  = ".";
			remoteUser  = "anonymous";
			remotePass  = "ciccio.pasticcio@sempliciotti.it";
			remotePort  = 21;
			_logined    = false;
		}

		public FTPClient(string remoteHost, string remoteUser, string remotePass)
			: this()
		{
			this.remoteHost = remoteHost;
			this.remoteUser = remoteUser;
			this.remotePass = remotePass;
		}

		#region IDisposable implementation
		~FTPClient()
		{
			Dispose(false);
		}

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (this.disposed == false)
			{
				this.disposed = true;

				if (disposing)
					this.cleanup();
			}
		}
		#endregion


		/// Set/Get the name of the FTP server to connect to.
		public string RemoteHost
		{
			get { return this.remoteHost; }
			set { this.remoteHost = value; }
		}

		/// Set/Get the port number to use for FTP.
		public int RemotePort
		{
			get { return this.RemotePort; }
			set { this.remotePort = value; }
		}

		/// Set/Get the remote directory path.
		public string RemotePath
		{
			get { return this.remotePath; }
			set { this.remotePath = value; }
		}

		/// Set the user name to use for logging into the remote server.
		public string RemoteUser 
		{ 
			set { this.remoteUser = value; } 
			get { return this.remoteUser; } 
		}

		/// Set the password to user for logging into the remote server.
		public string RemotePass { set { this.remotePass = value; } }

		/// Return a string array containing the remote directory's file list.
		public string[] getFileList(string mask)
		{
			if (!_logined)
				login();

			using (Socket cSocket = createDataSocket())
			{
				sendCommand("NLST " + mask);

				if (!(retValue == 150 || retValue == 125))
					throw new FTPClientException(reply);

				mes = "";
				while(true)
				{
					int bytes = cSocket.Receive(buffer, buffer.Length, 0);
					mes += ASCII.GetString(buffer, 0, bytes);
					if (bytes < buffer.Length)
						break;
				}

				char[] seperator = {'\n'};
				string[] mess = mes.Split(seperator);

				cSocket.Shutdown(SocketShutdown.Both);
				cSocket.Close();

				readReply();

				if (retValue != 226)
					throw new FTPClientException(reply);

				return mess;
			}
		}

		/// Return the size of a file.
		public long getFileSize(string fileName)
		{
			if (!_logined)
				login();

			sendCommand("SIZE " + fileName);
			long size=0;

			if (retValue == 213)
				size = Int64.Parse(reply.Substring(4), CultureInfo.InvariantCulture); // prende la dim. che e' dopo il codice 213b
			else
				throw new FTPClientException(reply);

			return size;
		}

		/// Login to the remote server.
		public void login()
		{
			if (_logined)
				return;

			_clientSocket = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
			IPEndPoint ep = new IPEndPoint(Dns.Resolve(remoteHost).AddressList[0], remotePort);

			try
			{
				_clientSocket.Connect(ep);
				if (!_clientSocket.Connected)
					throw new FTPClientException("Can't connect to remote server");
			}
			catch(Exception)
			{
				throw new FTPClientException("Can't connect to remote server");
			}

			readReply();
			if (retValue != 220)
			{
				close();
				throw new FTPClientException(reply);
			}

			sendCommand("USER "+remoteUser);

			if ( !(retValue == 331 || retValue == 230) )
			{
				cleanup();
				throw new FTPClientException(reply);
			}

			if ( retValue != 230 )
			{
				sendCommand("PASS "+remotePass);
				if ( !(retValue == 230 || retValue == 202) )
				{
					cleanup();
					throw new FTPClientException(reply);
				}
			}

			_logined = true;

			if (ConnectedEvent != null)
				ConnectedEvent();

			chdir(remotePath);
		}

		/// If the value of mode is true, set binary mode for downloads.
		/// Else, set Ascii mode.
		public void setBinaryMode(bool mode)
		{
			if (mode)
				sendCommand("TYPE I");
			else
				sendCommand("TYPE A");

			if (retValue != 200)
				throw new FTPClientException(reply);
		}

		/// Download a file to the Assembly's local directory,
		/// keeping the same file name.
		public void download(string remFileName)
		{
			download(remFileName,"",false);
		}

		/// Download a remote file to the Assembly's local directory,
		/// keeping the same file name, and set the resume flag.
		public void download(string remFileName,bool resume)
		{
			download(remFileName,"",resume);
		}

		/// Download a remote file to a local file name which can include
		/// a path. The local file name will be created or overwritten,
		/// but the path must exist.
		public void download(string remFileName, string locFileName)
		{
			download(remFileName, locFileName, false);
		}

		/// Download a remote file to a local file name which can include
		/// a path, and set the resume flag. The local file name will be
		/// created or overwritten, but the path must exist.
		public void download(string remFileName,string locFileName,bool resume)
		{
			if (!_logined)
				login();

			setBinaryMode(true);

			long bytesToReceive = 0;
			try
			{
				bytesToReceive = getFileSize(remFileName);
			}
			catch (Exception)
			{
			}

			if (locFileName.Equals(""))
				locFileName = remFileName;

			if (!File.Exists(locFileName))
			{
				Stream st = File.Create(locFileName);
				st.Close();
			}

			FileStream output = new FileStream(locFileName,FileMode.Open);

			using (Socket cSocket = createDataSocket())
			{
				long offset = 0;

				if (resume)
				{
					offset = output.Length;

					if (offset > 0 )
					{
						sendCommand("REST "+offset);
						if (retValue != 350)
						{
							//Some servers may not support resuming.
							offset = 0;
						}
					}
				}

				sendCommand("RETR " + remFileName);

				if (!(retValue == 150 || retValue == 125))
					throw new FTPClientException(reply);

				long bytesReceived = offset;

				while(true)
				{
					bytes = cSocket.Receive(buffer, buffer.Length, 0);
					if (bytes <= 0)
						break;

					output.Write(buffer,0,bytes);

					bytesReceived += bytes;

					if (DownloadEvent != null)
						DownloadEvent(bytesReceived, bytesToReceive);
				}

				output.Close();
				if (cSocket.Connected)
				{
					cSocket.Shutdown(SocketShutdown.Both);
					cSocket.Close();
				}

				readReply();

				if ( !(retValue == 226 || retValue == 250) )
					throw new FTPClientException(reply);
			}
		}

		/// Upload a file.
		public void upload(string fileName)
		{
			upload(fileName,false);
		}

		/// Upload a file and set the resume flag.
		public void upload(string fileName, bool resume)
		{
			if (!_logined)
				login();

			using (Socket cSocket = createDataSocket())
			{
				long offset=0;

				if (resume)
				{
					try
					{
						setBinaryMode(true);
						offset = getFileSize(fileName);
					}
					catch(Exception)
					{
						offset = 0;
					}
				}

				if (offset > 0 )
				{
					sendCommand("REST " + offset);
					if (retValue != 350)
					{
						//Remote server may not support resuming.
						offset = 0;
					}
				}

				sendCommand("STOR " + Path.GetFileName(fileName));

				if (!(retValue == 125 || retValue == 150))
					throw new FTPClientException(reply);

				FileInfo fi = new FileInfo(fileName);
				long bytesToSend = fi.Length;

				// open input stream to read source file
				using(FileStream input = new FileStream(fileName, FileMode.Open))
				{
					if (offset != 0)
						input.Seek(offset,SeekOrigin.Begin);

					long sent = offset;
					while ((bytes = input.Read(buffer,0,buffer.Length)) > 0)
					{
						cSocket.Send(buffer, bytes, 0);

						sent += bytes;

						if (UploadEvent != null)
							UploadEvent(fileName, sent, bytesToSend);
					}
					input.Close();
				}

				if (cSocket.Connected)
				{
					cSocket.Shutdown(SocketShutdown.Both);
					cSocket.Close();
				}

				readReply();
				if ( !(retValue == 226 || retValue == 250) )
					throw new FTPClientException(reply);
			}
		}

		/// Upload a generic stream.
		public void upload(Stream sr, long bytesToSend, string remoteFileName)
		{
			if (!_logined)
				login();

			using (Socket cSocket = createDataSocket())
			{
				sendCommand("STOR " + Path.GetFileName(remoteFileName));

				if (!(retValue == 125 || retValue == 150))
					throw new FTPClientException(reply);

				long sent = 0;
				while ((bytes = sr.Read(buffer,0,buffer.Length)) > 0)
				{
					cSocket.Send(buffer, bytes, 0);

					sent += bytes;

					if (UploadEvent != null)
						UploadEvent(remoteFileName, sent, bytesToSend);
				}

				if (cSocket.Connected)
				{
					cSocket.Shutdown(SocketShutdown.Both);
					cSocket.Close();
				}

				readReply();
				if ( !(retValue == 226 || retValue == 250) )
					throw new FTPClientException(reply);
			}
		}

		/// Delete a file from the remote FTP server.
		public void deleteRemoteFile(string fileName)
		{
			if (!_logined)
				login();

			sendCommand("DELE "+fileName);

			if (retValue != 250)
				throw new FTPClientException(reply);
		}

		/// Rename a file on the remote FTP server.
		public void renameRemoteFile(string oldFileName,string newFileName)
		{
			if (!_logined)
				login();

			sendCommand("RNFR "+oldFileName);

			if (retValue != 350)
				throw new FTPClientException(reply);

			//  known problem
			//  rnto will not take care of existing file.
			//  i.e. It will overwrite if newFileName exist
			sendCommand("RNTO "+newFileName);
			if (retValue != 250)
				throw new FTPClientException(reply);
		}

		/// Create a directory on the remote FTP server.
		public void mkdir(string dirName)
		{
			if (!_logined)
				login();

			sendCommand("MKD "+dirName);

			if (retValue != 250)
				throw new FTPClientException(reply);
		}

		/// Delete a directory on the remote FTP server.
		public void rmdir(string dirName)
		{
			if (!_logined)
				login();

			sendCommand("RMD "+dirName);

			if (retValue != 250)
				throw new FTPClientException(reply);
		}

		///
		/// Change the current working directory on the remote FTP server.
		///
		///
		public void chdir(string dirName)
		{
			if (dirName.Equals("."))
				return;

			if (!_logined)
				login();

			sendCommand("CWD "+dirName);

			if (retValue != 250)
				throw new FTPClientException(reply);

			this.remotePath = dirName;
		}

		/// Close the FTP connection.
		public void close()
		{
			if (_clientSocket != null)
				sendCommand("QUIT");

			cleanup();
		}

		private void readReply()
		{
			mes = "";
			reply = readLine();
			retValue = Int32.Parse(reply.Substring(0,3), CultureInfo.InvariantCulture);
		}

		private void cleanup()
		{
			if (_clientSocket!=null && _clientSocket.Connected)
			{
				_clientSocket.Shutdown(SocketShutdown.Both);
				_clientSocket.Close();
				_clientSocket = null;
			}
			_logined = false;
		}

		private string readLine()
		{
			while(true)
			{
				bytes = _clientSocket.Receive(buffer, buffer.Length, 0);
				mes += ASCII.GetString(buffer, 0, bytes);
				if (bytes < buffer.Length)
					break;
			}

			char[] seperator = {'\n'};
			string[] mess = mes.Split(seperator);

			if (mes.Length > 2)
				mes = mess[mess.Length-2];
			else
				mes = mess[0];

			if (!mes.Substring(3,1).Equals(" "))
				return readLine();

			if (MessageFromSeverEvent != null)
			{
				for(int k=0;k < mess.Length-1;k++)
					MessageFromSeverEvent(mess[k]);
			}
			return mes;
		}

		private void sendCommand(String command)
		{
			if (CommandFromClientEvent != null)
			{
				if (command.StartsWith("PASS") == false)
					CommandFromClientEvent(command);
				else
					CommandFromClientEvent("PASS xxx");
			}

			Byte[] cmdBytes = Encoding.ASCII.GetBytes((command+"\r\n").ToCharArray());
			_clientSocket.Send(cmdBytes, cmdBytes.Length, 0);
			readReply();
		}

		private Socket createDataSocket()
		{
			sendCommand("PASV");

			if (retValue != 227)
				throw new FTPClientException(reply);

			int index1 = reply.IndexOf('(');
			int index2 = reply.IndexOf(')');
			string ipData = reply.Substring(index1+1,index2-index1-1);
			int[] parts = new int[6];

			int len = ipData.Length;
			int partCount = 0;
			string buf="";

			for (int i = 0; i < len && partCount <= 6; i++)
			{
				char ch = ipData.Substring(i,1)[0];
				if (Char.IsDigit(ch))
					buf+=ch;
				else if (ch != ',')
					throw new FTPClientException(reply + " (Malformed PASV reply)");

				if (ch == ',' || i+1 == len)
				{
					try
					{
						parts[partCount++] = Int32.Parse(buf, CultureInfo.InvariantCulture);
						buf="";
					}
					catch (Exception)
					{
						throw new FTPClientException(reply + " (Malformed PASV reply)");
					}
				}
			}

			string ipAddress = parts[0] + "." + parts[1] + "." + parts[2] + "." + parts[3];

			int port = (parts[4] << 8) + parts[5];

			Socket s = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
			IPEndPoint ep = new IPEndPoint(Dns.Resolve(ipAddress).AddressList[0], port);

			try
			{
				s.Connect(ep);
				if (!s.Connected)
					throw new FTPClientException("Can't connect to remote server");
			}
			catch(Exception)
			{
				throw new FTPClientException("Can't connect to remote server");
			}

			return s;
		}
	}
}
