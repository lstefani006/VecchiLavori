using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Web.Services.Protocols;
using System.Security.Cryptography.X509Certificates;
using System.IO;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmLogin.
	/// </summary>
	public class frmLogin : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox edtLogin;
		private System.Windows.Forms.Label lblLogin;
		private System.Windows.Forms.Label lblPwd;
		private System.Windows.Forms.TextBox edtPwd;
		private System.Windows.Forms.Button btnLogin;
		private System.Windows.Forms.Button btnCancella;
		private System.Windows.Forms.Label lblMsg;

		private static System.Net.CookieContainer _ck = null;
		private CVAdminWSLogin.BLLogin _ws = null;
		private IAsyncResult _asr = null;
		private System.Timers.Timer timerLogin;

		private static bool _isLogged = false;

		/// <summary>
		/// Proprieta' che ritorna se l'ultimo login e' andato a buon fine
		/// </summary>
		public  static bool IsLogged { get { return _isLogged; } }

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmLogin()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			edtLogin.Enabled = false;
			edtPwd.Enabled = false;
			btnLogin.Enabled = false;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.edtLogin = new System.Windows.Forms.TextBox();
			this.lblLogin = new System.Windows.Forms.Label();
			this.lblPwd = new System.Windows.Forms.Label();
			this.edtPwd = new System.Windows.Forms.TextBox();
			this.btnLogin = new System.Windows.Forms.Button();
			this.btnCancella = new System.Windows.Forms.Button();
			this.lblMsg = new System.Windows.Forms.Label();
			this.timerLogin = new System.Timers.Timer();
			((System.ComponentModel.ISupportInitialize)(this.timerLogin)).BeginInit();
			this.SuspendLayout();
			// 
			// edtLogin
			// 
			this.edtLogin.Location = new System.Drawing.Point(128, 8);
			this.edtLogin.Name = "edtLogin";
			this.edtLogin.Size = new System.Drawing.Size(208, 20);
			this.edtLogin.TabIndex = 0;
			this.edtLogin.Text = "";
			// 
			// lblLogin
			// 
			this.lblLogin.Location = new System.Drawing.Point(8, 8);
			this.lblLogin.Name = "lblLogin";
			this.lblLogin.Size = new System.Drawing.Size(112, 24);
			this.lblLogin.TabIndex = 1;
			this.lblLogin.Text = "Login:";
			// 
			// lblPwd
			// 
			this.lblPwd.Location = new System.Drawing.Point(8, 40);
			this.lblPwd.Name = "lblPwd";
			this.lblPwd.Size = new System.Drawing.Size(112, 24);
			this.lblPwd.TabIndex = 2;
			this.lblPwd.Text = "Password:";
			// 
			// edtPwd
			// 
			this.edtPwd.Location = new System.Drawing.Point(128, 32);
			this.edtPwd.Name = "edtPwd";
			this.edtPwd.PasswordChar = '*';
			this.edtPwd.Size = new System.Drawing.Size(208, 20);
			this.edtPwd.TabIndex = 3;
			this.edtPwd.Text = "";
			// 
			// btnLogin
			// 
			this.btnLogin.Location = new System.Drawing.Point(216, 88);
			this.btnLogin.Name = "btnLogin";
			this.btnLogin.Size = new System.Drawing.Size(120, 24);
			this.btnLogin.TabIndex = 4;
			this.btnLogin.Text = "Login";
			this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
			// 
			// btnCancella
			// 
			this.btnCancella.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancella.Location = new System.Drawing.Point(88, 88);
			this.btnCancella.Name = "btnCancella";
			this.btnCancella.Size = new System.Drawing.Size(120, 24);
			this.btnCancella.TabIndex = 5;
			this.btnCancella.Text = "Cancella";
			this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
			// 
			// lblMsg
			// 
			this.lblMsg.Location = new System.Drawing.Point(128, 64);
			this.lblMsg.Name = "lblMsg";
			this.lblMsg.Size = new System.Drawing.Size(208, 16);
			this.lblMsg.TabIndex = 6;
			// 
			// timerLogin
			// 
			this.timerLogin.Interval = 300;
			this.timerLogin.SynchronizingObject = this;
			this.timerLogin.Elapsed += new System.Timers.ElapsedEventHandler(this.timerLogin_Elapsed);
			// 
			// frmLogin
			// 
			this.AcceptButton = this.btnLogin;
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancella;
			this.ClientSize = new System.Drawing.Size(352, 125);
			this.Controls.Add(this.lblMsg);
			this.Controls.Add(this.btnCancella);
			this.Controls.Add(this.btnLogin);
			this.Controls.Add(this.edtPwd);
			this.Controls.Add(this.lblPwd);
			this.Controls.Add(this.lblLogin);
			this.Controls.Add(this.edtLogin);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmLogin";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Login";
			this.Load += new System.EventHandler(this.frmLogin_Load);
			((System.ComponentModel.ISupportInitialize)(this.timerLogin)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void btnLogin_Click(object sender, System.EventArgs e)
		{
			_isLogged = false;

			btnLogin.Enabled = false;
			lblMsg.Text = "Login in corso....";

			this.Enabled = false;
			Application.DoEvents();
			this.Enabled = true;

			_ck = new System.Net.CookieContainer();
			_ws = new CVAdminWSLogin.BLLogin();
			AddLoginInfo(_ws);

			_ws.AccountInfoValue = new CVAdminWSLogin.AccountInfo();
			_ws.AccountInfoValue.Login = edtLogin.Text;
			_ws.AccountInfoValue.Password = edtPwd.Text;
			_ws.CookieContainer = _ck;

			_asr = _ws.BeginLogin(null, null);
			timerLogin.Enabled = true;
		}


		/// <summary>
		/// Chiamare questa funzione per mettere le informazioni di login
		/// ad ogni proxy di WebService.
		/// </summary>
		/// <param name="ws">il web service da arricchire</param>
		public static void AddLoginInfo(System.Web.Services.Protocols.SoapHttpClientProtocol ws)
		{
			// qui associo i cookie alla nuova chiamata. Con i cookie il WebServer
			// riconosce il cliente e dunque puo` associargli la sessione.
			ws.CookieContainer = _ck;

			// qui modifico l'URL di destinazione specificando l'URL del file
			// di configurazione.
			if (true)
			{
				string [] s = ws.Url.Split(new char [] { '/' });
				string CVAdminURL = System.Configuration.ConfigurationSettings.AppSettings["CVAdminWebServerURL"];

				string ss = CVAdminURL;
				for (int i = s.Length - 1; i < s.Length; ++i)
					ss = ss + "/" + s[i];

				ws.Url = ss;
			}
		}

		private void btnCancella_Click(object sender, System.EventArgs e)
		{
			if (_asr == null)
			{
				// ha fatto cancella senza prima aver fatto un login
				// esco senza toccare il _isLogged
				timerLogin.Enabled = false;
				this.DialogResult = DialogResult.Cancel;
				this.Close();
				return;
			}

			if (_asr.IsCompleted)
			{
				LoginCompleted();
			}
			else
			{
				timerLogin.Enabled = false;

				WebClientAsyncResult wasr = _asr as WebClientAsyncResult;
				if (wasr != null)
					wasr.Abort();

				_asr = null;
				_ws = null;

				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void timerLogin_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			if (_asr != null && _asr.IsCompleted)
				LoginCompleted();
		}

		private void LoginCompleted()
		{
			try
			{
				timerLogin.Enabled = false;

 				_isLogged = _ws.EndLogin(_asr);
				_asr = null;
				_ws = null;

				if (_isLogged == false)
				{
					btnLogin.Enabled = true;
					lblMsg.Text = "";

					MessageBox.Show(this, "Login errata", "Errore");
				}
				else
				{
					this.DialogResult = DialogResult.OK;
					this.Close();
				}
			}
			catch (Exception e)
			{
				_isLogged = false;
				_asr = null;
				_ws = null;

				btnLogin.Enabled = true;
				lblMsg.Text = "";

				MessageBox.Show(this, e.Message, "Errore");
			}
		}

		private void frmLogin_Load(object sender, System.EventArgs e)
		{
			edtLogin.Enabled = true;
			edtPwd.Enabled = true;
			btnLogin.Enabled = true;
			btnCancella.Enabled = true;
			/*
#if DEBUG
			edtLogin.Text = "ciccio";
			edtPwd.Text = "pasticcio";
			btnLogin_Click(null, null);
#endif
			*/
		}
	}
}
