using System;
using System.Drawing;
using System.Xml;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Web.Services.Protocols;
using System.Security.Cryptography.X509Certificates;
using System.Data;
using System.IO;
using ExcelHelper;
using System.Text;
using System.Globalization;
using CVAdmin_Main.CVAdminWSBLBudget;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmBudgetXML.
	/// </summary>
	public class frmBudgetXML : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox gbGenerale;
		private System.Windows.Forms.Label lblCodiceConto;
		private System.Windows.Forms.ComboBox cbRagioneSociale;
		private System.Windows.Forms.Label lblRagioneSoc;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.ToolTip tltInfo;
		private System.Windows.Forms.Button btnSalva;
		private System.ComponentModel.IContainer components;

		// Variabili definite dall'utente
		private string		_IdSessione;
		private string		_FileXml;
		private DataSet		_dsBudgetsSocieta;
		private System.Windows.Forms.ComboBox cbCodiceConto;
		private System.Windows.Forms.TextBox edtPartitaIVA;
		private System.Windows.Forms.Label lblPartitaIVA;
		private System.Windows.Forms.DataGrid dgImporti;
		private DataTable	_dtSessioneAttiva;
		private DataSet dsImporti;
		private DataTable _dtImporti;
		private DataView _dvImporti;
		BindingManagerBase _bmSocieta;
		private System.Windows.Forms.Button btnAssegnaTuttiImporti;
		XmlDocument _doc;

		public DataTable SocietaDataTable
		{
			get
			{
				if (_dsBudgetsSocieta != null)
					return _dsBudgetsSocieta.Tables["Societa"];
				else 
					return null;
			}
		}

		public DataTable BudgetsDataTable
		{
			get
			{
				if (_dsBudgetsSocieta != null)
					return _dsBudgetsSocieta.Tables["Budgets"];
				else 
					return null;
			}
		}

		public DataRow CurrentRow
		{
			get 
			{
				if (_bmSocieta.Current.GetType() != typeof(DataRowView))
					return null;
				
				DataRow dr = ((DataRowView)_bmSocieta.Current).Row;
				return dr;
			}
		}

		public DataRow CurrentBudgetRow
		{
			get 
			{
				DataRow drSocieta = CurrentRow;
				if (drSocieta == null)
					return null;

				DataRow [] drBudget = drSocieta.GetChildRows("relSocietaBudget");
				Debug.Assert(drBudget.Length == 1);
				if (drBudget.Length == 1)
					return drBudget[0];
				else
					return null;
			}
		}

		public frmBudgetXML()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_IdSessione = null;
			_dsBudgetsSocieta = null;
		}

		public frmBudgetXML(DataTable dtSessioneAttiva, DataSet dsBudgetsSocieta, string IdSessione, string FileXml)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_FileXml = FileXml ;
			_IdSessione = IdSessione;
			_dtSessioneAttiva = dtSessioneAttiva ;
			_dsBudgetsSocieta = dsBudgetsSocieta ;

			Binding bnd;

			// Data Binding della tabella "Societa'" con la ComboBox contenente le Ragioni Sociali
			cbRagioneSociale.DataSource    = _dsBudgetsSocieta;
			cbRagioneSociale.DisplayMember = "Societa.RagioneSociale";
			cbRagioneSociale.ValueMember   = "Societa.IdSocieta";

			// Data Binding della tabella "Societa'" con la ComboBox contenente il Codice Conto delle societa'
			cbCodiceConto.DataSource    = _dsBudgetsSocieta;
			cbCodiceConto.DisplayMember = "Societa.CodiceConto";
			cbCodiceConto.ValueMember   = "Societa.IdSocieta";

			bnd = edtPartitaIVA.DataBindings.Add("Text", _dsBudgetsSocieta, "Societa.PartitaIVA");

			Debug.Assert(this.BindingContext.Contains(_dsBudgetsSocieta, "Societa"));
			_bmSocieta = this.BindingContext[_dsBudgetsSocieta, "Societa"];
			_bmSocieta.PositionChanged += new EventHandler(BindingManagerBase_PositionChanged);

			AbilitaBottoni(true);

			SetDataGridMapping();

			dsImporti = DataSet_Importi();

			ElaboraFileXml();

			BindDataGridDataSource(dsImporti);

		}

		private void ElaboraFileXml()
		{
			_doc = new XmlDocument() ;
			try
			{
				_doc.Load(_FileXml);
			}
			catch(Exception)
			{
				MessageBox.Show("Errore nel caricamento del file Xml!", "Errore");
				return;
			}

			try
			{
				_doc.Save(_FileXml);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Attenzione: il file xml e` a sola lettura!\nNon e` possibile elaborare il file." + ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			int n = 0;
			XmlNodeList nodelist = _doc.SelectNodes("/RENDICONTAZIONE_INCASSI/ELENCO_MOVIMENTI/MOVIMENTO");
			foreach(XmlNode node in nodelist)
			{
				string errore = null;
			
				string elaborato;
				if (node.Attributes.GetNamedItem("Elaborato") == null)
					elaborato = "Non Elaborato" ;
				else
					elaborato = "Elaborato" ;

				string codicePagamento = null;
				if (true)
				{
					XmlNode codicePagamentoNode = node.SelectSingleNode("./CODICE_PAGAMENTO");
					if (codicePagamentoNode != null)
						codicePagamento = codicePagamentoNode.InnerText;
				}

				string ragioneSociale = null;
				if (true)
				{
					XmlNode ragioneSocialeNode = node.SelectSingleNode("./OPERATORE/RAGIONE_SOCIALE");
					if (ragioneSocialeNode != null)
						ragioneSociale = ragioneSocialeNode.InnerText;
				}

				decimal importo = 0m;
				try
				{
					XmlNode importoNode = node.SelectSingleNode("./PAGAMENTO/IMPORTO");
					if (importoNode != null)
						importo = decimal.Parse(importoNode.InnerText, NumberStyles.Number, new CultureInfo("it-IT", false));
				}
				catch (Exception)
				{
				}

				if (importo == 0m)
					errore = "importo non specificato o zero";


				DateTime dataOperazione = DateTime.MinValue;
				try
				{
					XmlNode dataOpNode = node.SelectSingleNode("./PAGAMENTO/DATA_OP");
					if (dataOpNode != null)
						dataOperazione = DateTime.Parse(dataOpNode.InnerText, new CultureInfo("it-IT", false));
				}
				catch (Exception)
				{
				}

				DateTime dataValuta = DateTime.MinValue;
				try
				{
					XmlNode dataValutaNode = node.SelectSingleNode("./PAGAMENTO/DATA_VALUTA");
					if (dataValutaNode != null)
						dataValuta = DateTime.Parse(dataValutaNode.InnerText, new CultureInfo("it-IT", false));
				}
				catch (Exception)
				{
				}

				string divisa = null;
				if (true)
				{
					XmlNode divisaNode = node.SelectSingleNode("./PAGAMENTO/DIVISA");
					if (divisaNode != null)
						divisa = divisaNode.InnerText;
				}

				string causale = null;
				if (true)
				{
					XmlNode causaleNode = node.SelectSingleNode("./PAGAMENTO/CAUSALE");
					if (causaleNode != null)
						causale = causaleNode.InnerText;
				}

				// fine lettura XML: provo a interpretare i campi letti


				// trovo il codice conto dal codicePagamento.
				string codiceConto = null;
				string dataSessione = null;

				if (codicePagamento != null)
				{
					codicePagamento = codicePagamento.Replace(" ", "").ToUpper();
					if (codicePagamento.Length >= 18)
					{
						codiceConto  = codicePagamento.Substring(codicePagamento.Length - 18, 10);
						dataSessione = codicePagamento.Substring(codicePagamento.Length - 18 + 10, 8);

						DateTime TSApertura = (DateTime)_dtSessioneAttiva.Rows[0]["DataOraApertura"];
						string dataApertura = string.Format("{0:dd}{0:MM}{0:yyyy}", TSApertura);

						if (dataApertura != dataSessione)
							errore = "data sessione errata";

						if (codicePagamento.StartsWith("CP") == false)
						{
							// SENZA "CP"
							if (CausaleVersamento(codiceConto, dataSessione) != codicePagamento)
							{
								codiceConto = null;
								dataSessione = null;
								errore = "codice pagamento errato (checksum).";
							}
						}
						else
						{
							// CON "CP"
							if ("CP" + CausaleVersamento(codiceConto, dataSessione) != codicePagamento)
							{
								codiceConto = null;
								dataSessione = null;
								errore = "codice pagamento errato (checksum).";
							}
						}

						try
						{
							// tolgo gli zeri iniziali.
							if (codiceConto != null)
								codiceConto = int.Parse(codiceConto).ToString();
						}
						catch (Exception)
						{
							codiceConto = null;
							dataSessione = null;
							errore = "codice conto errato (deve essere solo numeri)";
						}
					}
				}

				// significa che il codicePagamento non c'era niente di significativo... provo con la causale
				/*
				e` commentato per evitare ambiguita` nel caso siano comporaneamente valorizzati
				i campi ./PAGAMENTO/CAUSALE e ./CODICE_PAGAMENTO magari entrambi contenenti
				CPxxxxxxxx valide ma con dati dentro diversi.
				*/
								
//				if (codiceConto == null && dataSessione == null && causale != null)
//				{
//					causale = causale.Replace(" ", "").ToUpper();
//					if (causale.Length >= 18)
//					{
//						codiceConto  = causale.Substring(causale.Length - 18, 10);
//						dataSessione = causale.Substring(causale.Length - 18 + 10, 8);
//
//						DateTime TSApertura = (DateTime)_dtSessioneAttiva.Rows[0]["DataOraApertura"];
//						string dataApertura = string.Format("{0:dd}{0:MM}{0:yyyy}", TSApertura);
//
//						if (dataApertura != dataSessione)
//							errore = "data sessione errata";
//
//						if (causale.StartsWith("CP") == false)
//						{
//							if (CausaleVersamento(codiceConto, dataSessione) != causale)
//							{
//								codiceConto = null;
//								dataSessione = null;
//								// non metto gli errori in quanto sono gia stati settati prima (quando interpreto codicePagamento)
//								//errore = "causale errata.";
//							}
//						}
//						else
//						{
//							if (CausaleVersamento(codiceConto, dataSessione) != causale)
//							{
//								codiceConto = null;
//								dataSessione = null;
//								// non metto gli errori in quanto sono gia stati settati prima (quando interpreto codicePagamento)
//								//errore = "causale errata";
//							}
//						}
//						try
//						{
//							// tolgo gli zeri iniziali.
//							if (codiceConto != null)
//								codiceConto = int.Parse(codiceConto).ToString();
//						}
//						catch (Exception)
//						{
//							codiceConto = null;
//							dataSessione = null;
//							errore = "codice conto errato (deve essere solo numeri)";
//						}
//					}
//				}
				



				DataRow drImporto = dsImporti.Tables[0].NewRow() ;

				if (errore != null)
				{
					drImporto["Errore"] = errore;
					drImporto.RowError = errore;
				}
				else
					drImporto["Errore"] = System.DBNull.Value;

				drImporto["Elaborazione"] = elaborato;

				if (codicePagamento != null && codiceConto == null)
					drImporto["Decodificato"] = "No";
				else
					drImporto["Decodificato"] = "Si";

				if (ragioneSociale != null)
					drImporto["RagioneSociale"] = ragioneSociale;
				else
					drImporto["RagioneSociale"] = System.DBNull.Value;

				if (codiceConto != null)
					drImporto["CodiceConto"] = codiceConto;
				else
					drImporto["CodiceConto"] = System.DBNull.Value;

				drImporto["Importo"] = importo;
				drImporto["ProgressivoRecordNelXml"] = n++;

				if (dataOperazione != DateTime.MinValue)
					drImporto["DataOperazione"] = dataOperazione;
				else
					drImporto["DataOperazione"] = System.DBNull.Value;

				if (dataValuta != DateTime.MinValue)
					drImporto["DataValuta"] = dataValuta;
				else
					drImporto["DataValuta"] = System.DBNull.Value;

				if (divisa != null)
					drImporto["Divisa"] = divisa;
				else
					drImporto["Divisa"] = System.DBNull.Value;

				if (codicePagamento != null)
					drImporto["CodicePagamento"] = codicePagamento;
				else
					drImporto["CodicePagamento"] = System.DBNull.Value;

				drImporto["Causale"] = causale;

				if (node.Attributes.GetNamedItem("Elaborato") == null)
					drImporto["Elaborazione"] = "Non Elaborato" ;
				else
					drImporto["Elaborazione"] = "Elaborato" ;

				dsImporti.Tables[0].Rows.Add(drImporto) ;
			}

			/*
			XmlNodeList nodelist = _doc.GetElementsByTagName("societa");
			int n = 0;
			foreach(XmlNode node in nodelist)
			{
				DataRow drImporto = dsImporti.Tables[0].NewRow() ;
				drImporto["RagioneSociale"] = node.Attributes.GetNamedItem("RagioneSociale").Value ;
				drImporto["CodiceConto"] = node.Attributes.GetNamedItem("CodiceConto").Value ;
				drImporto["PartitaIVA"] = node.Attributes.GetNamedItem("PartitaIVA").Value ;
				drImporto["Importo"] = XmlConvert.ToDecimal(node.ChildNodes.Item(0).InnerText);
				drImporto["ProgressivoRecordNelXml"] = n++;

				if (node.Attributes.GetNamedItem("Elaborato") == null)
					drImporto["Elaborazione"] = "Non Elaborato" ;
				else
					drImporto["Elaborazione"] = "Elaborato" ;

				dsImporti.Tables[0].Rows.Add(drImporto) ;
			}
			*/


		}

		private void BindDataGridDataSource(DataSet ds)
		{
			// Effettuo il DataBinding del DataSet delle Sessioni con il DataGrid
			if (ds != null)
			{
				_dtImporti = ds.Tables[0];
				_dvImporti = new DataView(_dtImporti);
				_dvImporti.AllowDelete	= false;
				_dvImporti.AllowNew	= false;
				_dvImporti.AllowEdit	= false;
				_dvImporti.Sort        = "Elaborazione" ;

				dgImporti.DataSource	= _dvImporti;
			}
		}

		private void SetDataGridMapping()
		{
			// Mapping delle colonne tra il DataTable delle Sessioni e le colonne
			// del DataGrid
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[11];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			int n = 0;
			dgCol[n].HeaderText = "Elaborazione";
			dgCol[n].MappingName = "Elaborazione";
			dgCol[n].Width = 120;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Decodificato";
			dgCol[n].MappingName = "Decodificato";
			dgCol[n].Width = 30;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Importo Bonifico";
			dgCol[n].MappingName = "Importo";
			dgCol[n].Width = 180;
			dgCol[n].Format = "c";
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Codice Conto";
			dgCol[n].MappingName = "CodiceConto";
			dgCol[n].Width = 180;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Ragione Sociale";
			dgCol[n].MappingName = "RagioneSociale";
			dgCol[n].Width = 300;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Valuta";
			dgCol[n].MappingName = "DataValuta";
			dgCol[n].Format = "g";
			dgCol[n].Width = 180;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Data operazione";
			dgCol[n].MappingName = "DataOperazione";
			dgCol[n].Format = "g";
			dgCol[n].Width = 180;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Divisa";
			dgCol[n].MappingName = "Divisa";
			dgCol[n].Width = 60;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Causale";
			dgCol[n].MappingName = "Causale";
			dgCol[n].Width = 180;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Codice pagamento";
			dgCol[n].MappingName = "CodicePagamento";
			dgCol[n].Width = 180;
			dgCol[n].NullText = "<assente>";

			n++;
			dgCol[n].HeaderText = "Errore";
			dgCol[n].MappingName = "Errore";
			dgCol[n].Width = 180;
			dgCol[n].NullText = "";


			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Importi";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgImporti.TableStyles.Add(dgStyle);
		}

		private DataSet DataSet_Importi()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("Importi");

			DataColumn c;

			c = dt.Columns.Add("Elaborazione", typeof(string));
			c.MaxLength = 30;
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("Decodificato", typeof(string));
			c.AllowDBNull = false;
			c.Unique = false;

			
			c = dt.Columns.Add("RagioneSociale", typeof(string));
			c.AllowDBNull = true;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("CodiceConto", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = true;
			c.Unique = false;

//			c = dt.Columns.Add("PartitaIVA", typeof(string));
//			c.MaxLength = 11;
//			c.AllowDBNull = true;
//			c.Unique = false;	
		
			c = dt.Columns.Add("Importo", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("DataOperazione", typeof(DateTime));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("DataValuta", typeof(DateTime));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("Divisa", typeof(string));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("CodicePagamento", typeof(string));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("Causale", typeof(string));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("ProgressivoRecordNelXml", typeof(int));
			c.AllowDBNull = false;
			c.Unique = true;

			c = dt.Columns.Add("Errore", typeof(string));
			c.AllowDBNull = true;

			return ds;
		}

		private DataRow CurrentRowGrid()
		{
			BindingManagerBase bm = dgImporti.BindingContext[dgImporti.DataSource];
			if (bm.Count == 0) // numero di righe = 0
				return null;
			DataRow dr = null;
			if (bm.Current.GetType() == typeof(DataRowView))
				dr = ((DataRowView)bm.Current).Row; 
			return dr;	
		}

		public int GetDataGridRowsNumber()
		{
			BindingManagerBase bmDataGrid = dgImporti.BindingContext[dgImporti.DataSource];
			return bmDataGrid.Count;
		}

		private int GetNumberRowsSelected()
		{
			int RowsSelected = 0;
			for (int i = 0; i < GetDataGridRowsNumber(); i++)
			{
				if (dgImporti.IsSelected(i))
				{
					RowsSelected++;
				}
			}
			return RowsSelected;
		}

		private void BindingManagerBase_PositionChanged(object sender, EventArgs e)
		{
			AbilitaBottoni(true);
		}


		private bool AggiornaDataSet(DataSet ds)
		{
			try
			{
				// Verifico se sono state effettuate delle modifiche alle tabelle del DataSet
				if (!ds.HasChanges()) 
				{
					ds.AcceptChanges();
					return true;
				}

				DataSet xDataSet;
				// GetChanges solo per le righe modificate
				xDataSet = ds.GetChanges();

				if (xDataSet == null)
				{
					ds.AcceptChanges();
					return true;
				}

				CVAdminWSBLBudget.BLBudget ws = new CVAdminWSBLBudget.BLBudget();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginUpdate(xDataSet, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return false;

				// il Web Service ha risposto... prendo il risultato
				DataSet dsUpdated = ws.EndUpdate(asr);
				if (dsUpdated != null)
				{
					ds.AcceptChanges();
					return true;
				}
				else
				{
					ds.RejectChanges();
					return false;
				}
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return false;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return false;
			}
			finally
			{
				AbilitaBottoni(true);
			}
		}

		private void AbilitaBottoni(bool enable)
		{
			btnSalva.Enabled = enable;
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBudgetXML));
			this.gbGenerale = new System.Windows.Forms.GroupBox();
			this.edtPartitaIVA = new System.Windows.Forms.TextBox();
			this.lblPartitaIVA = new System.Windows.Forms.Label();
			this.cbCodiceConto = new System.Windows.Forms.ComboBox();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.lblRagioneSoc = new System.Windows.Forms.Label();
			this.cbRagioneSociale = new System.Windows.Forms.ComboBox();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnSalva = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.dgImporti = new System.Windows.Forms.DataGrid();
			this.btnAssegnaTuttiImporti = new System.Windows.Forms.Button();
			this.gbGenerale.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgImporti)).BeginInit();
			this.SuspendLayout();
			// 
			// gbGenerale
			// 
			this.gbGenerale.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbGenerale.Controls.Add(this.edtPartitaIVA);
			this.gbGenerale.Controls.Add(this.lblPartitaIVA);
			this.gbGenerale.Controls.Add(this.cbCodiceConto);
			this.gbGenerale.Controls.Add(this.lblCodiceConto);
			this.gbGenerale.Controls.Add(this.lblRagioneSoc);
			this.gbGenerale.Controls.Add(this.cbRagioneSociale);
			this.gbGenerale.Location = new System.Drawing.Point(0, 320);
			this.gbGenerale.Name = "gbGenerale";
			this.gbGenerale.Size = new System.Drawing.Size(680, 152);
			this.gbGenerale.TabIndex = 1;
			this.gbGenerale.TabStop = false;
			this.gbGenerale.Text = "Societa\' a cui assegnare l\'importo selezionato nella griglia ";
			// 
			// edtPartitaIVA
			// 
			this.edtPartitaIVA.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.edtPartitaIVA.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtPartitaIVA.Enabled = false;
			this.edtPartitaIVA.Location = new System.Drawing.Point(8, 112);
			this.edtPartitaIVA.MaxLength = 18;
			this.edtPartitaIVA.Name = "edtPartitaIVA";
			this.edtPartitaIVA.Size = new System.Drawing.Size(176, 20);
			this.edtPartitaIVA.TabIndex = 18;
			this.edtPartitaIVA.Text = "";
			// 
			// lblPartitaIVA
			// 
			this.lblPartitaIVA.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblPartitaIVA.Location = new System.Drawing.Point(8, 96);
			this.lblPartitaIVA.Name = "lblPartitaIVA";
			this.lblPartitaIVA.Size = new System.Drawing.Size(176, 16);
			this.lblPartitaIVA.TabIndex = 17;
			this.lblPartitaIVA.Text = "Partita IVA";
			// 
			// cbCodiceConto
			// 
			this.cbCodiceConto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.cbCodiceConto.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.cbCodiceConto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCodiceConto.Location = new System.Drawing.Point(8, 72);
			this.cbCodiceConto.Name = "cbCodiceConto";
			this.cbCodiceConto.Size = new System.Drawing.Size(176, 21);
			this.cbCodiceConto.TabIndex = 9;
			this.tltInfo.SetToolTip(this.cbCodiceConto, "Elenco delle Societa\' per Codice Conto");
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblCodiceConto.Location = new System.Drawing.Point(8, 56);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(76, 16);
			this.lblCodiceConto.TabIndex = 2;
			this.lblCodiceConto.Text = "Codice Conto";
			// 
			// lblRagioneSoc
			// 
			this.lblRagioneSoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblRagioneSoc.Location = new System.Drawing.Point(8, 16);
			this.lblRagioneSoc.Name = "lblRagioneSoc";
			this.lblRagioneSoc.Size = new System.Drawing.Size(88, 16);
			this.lblRagioneSoc.TabIndex = 1;
			this.lblRagioneSoc.Text = "Ragione Sociale";
			// 
			// cbRagioneSociale
			// 
			this.cbRagioneSociale.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cbRagioneSociale.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.cbRagioneSociale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbRagioneSociale.Location = new System.Drawing.Point(8, 32);
			this.cbRagioneSociale.Name = "cbRagioneSociale";
			this.cbRagioneSociale.Size = new System.Drawing.Size(664, 21);
			this.cbRagioneSociale.TabIndex = 2;
			this.tltInfo.SetToolTip(this.cbRagioneSociale, "Elenco delle Societa\' per Ragione Sociale");
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChiudi.Location = new System.Drawing.Point(568, 488);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.Size = new System.Drawing.Size(104, 23);
			this.btnChiudi.TabIndex = 5;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa maschera");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnSalva
			// 
			this.btnSalva.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnSalva.Location = new System.Drawing.Point(400, 488);
			this.btnSalva.Name = "btnSalva";
			this.btnSalva.Size = new System.Drawing.Size(160, 23);
			this.btnSalva.TabIndex = 4;
			this.btnSalva.Text = "&Assegna singolo Importo";
			this.tltInfo.SetToolTip(this.btnSalva, "Assegna l\'importo selezionato nella griglia alla societa\' selezionata");
			this.btnSalva.Click += new System.EventHandler(this.btnSalva_Click);
			// 
			// dgImporti
			// 
			this.dgImporti.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgImporti.CaptionText = "Risultato dell\'Import  del file XML";
			this.dgImporti.DataMember = "";
			this.dgImporti.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgImporti.Location = new System.Drawing.Point(8, 8);
			this.dgImporti.Name = "dgImporti";
			this.dgImporti.Size = new System.Drawing.Size(664, 304);
			this.dgImporti.TabIndex = 6;
			// 
			// btnAssegnaTuttiImporti
			// 
			this.btnAssegnaTuttiImporti.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnAssegnaTuttiImporti.Location = new System.Drawing.Point(8, 488);
			this.btnAssegnaTuttiImporti.Name = "btnAssegnaTuttiImporti";
			this.btnAssegnaTuttiImporti.Size = new System.Drawing.Size(200, 23);
			this.btnAssegnaTuttiImporti.TabIndex = 7;
			this.btnAssegnaTuttiImporti.Text = "&Assegna automaticamente Importi";
			this.tltInfo.SetToolTip(this.btnAssegnaTuttiImporti, "Assegna l\'importo selezionato nella griglia alla societa\' selezionata");
			this.btnAssegnaTuttiImporti.Click += new System.EventHandler(this.btnAssegnaTuttiImporti_Click);
			// 
			// frmBudgetXML
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(680, 519);
			this.Controls.Add(this.btnAssegnaTuttiImporti);
			this.Controls.Add(this.dgImporti);
			this.Controls.Add(this.btnSalva);
			this.Controls.Add(this.btnChiudi);
			this.Controls.Add(this.gbGenerale);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmBudgetXML";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Import dei Budgets da file Xml";
			this.Load += new System.EventHandler(this.frmBudgetXML_Load);
			this.gbGenerale.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgImporti)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frmBudgetXML_Load(object sender, System.EventArgs e)
		{
			AbilitaBottoni(true);
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private bool IsFormClosing()
		{
			bool closing = false;
			if (this.ActiveControl.Name.CompareTo("btnChiudi")==0)
				closing = true;
			return closing;
		}

		private void btnSalva_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (_dsBudgetsSocieta == null)
					return;

				int rowsel = GetNumberRowsSelected();

				if (rowsel != 1)
				{
					MessageBox.Show("Selezionare una ed una sola riga nella griglia!", 
						"Attenzione", 
						MessageBoxButtons.OK, 
						MessageBoxIcon.Information);
					return;
				}

				Cursor.Current = Cursors.WaitCursor;

				DataRow dr = CurrentBudgetRow ;

				decimal Importo = 0m ;
				string elaborazione = "" ;
				DataRow dataRow = null ;
				string errore = null;
				BindingManagerBase bm = dgImporti.BindingContext[dgImporti.DataSource];
				for (int i = 0; i < GetDataGridRowsNumber(); i++)
				{
					if (dgImporti.IsSelected(i))
					{
						bm.Position = i;
						dataRow = CurrentRowGrid();
						Importo = (decimal)dataRow["Importo"] ;
						elaborazione = dataRow["Elaborazione"].ToString() ;

						if (dataRow.IsNull("Errore") == false)
							errore = (string)dataRow["Errore"];
					}
				}

				if (elaborazione == "Elaborato")
				{
					if (MessageBox.Show("La riga selezionata e' gia' stata elaborata!\n"+
						"Vuoi comunque addizionare al budget per la societa`\n" + 
						"selezionata nuovamente l'importo?", 
						"Attenzione", 
						MessageBoxButtons.YesNo, 
						MessageBoxIcon.Information) == DialogResult.No)
					{
						return;
					}
				}

				if (errore != null)
				{
					if (MessageBox.Show("La riga selezionata ha un errore di decodifica!\n"+
						"Vuoi comunque addizionare al budget per la societa`\n" + 
						"selezionata nuovamente l'importo?", 
						"Attenzione", 
						MessageBoxButtons.YesNo, 
						MessageBoxIcon.Information) == DialogResult.No)
					{
						return;
					}
				}

				Cursor.Current = Cursors.Arrow;

				dr.BeginEdit();
				dr["Importo"] = (decimal)dr["Importo"] + Importo ;

				if ((decimal)dr["PrezzoConvenzionaleUtente"] > 0m)
					dr["QtyMax"] = decimal.Truncate((decimal)dr["Importo"] / (decimal)dr["PrezzoConvenzionaleUtente"]);
				else
					dr["QtyMax"] = 0m;

				dr.EndEdit();
				dataRow.BeginEdit();
				dataRow["Elaborazione"] = "Elaborato" ;
				dataRow.EndEdit();


				bool IsDataSetUpdated = AggiornaDataSet(_dsBudgetsSocieta);
				if (IsDataSetUpdated)
				{
					int r = (int)dataRow["ProgressivoRecordNelXml"];
					XmlNodeList nodelist = _doc.SelectNodes("/RENDICONTAZIONE_INCASSI/ELENCO_MOVIMENTI/MOVIMENTO");
					XmlNode node = nodelist[r];

					if (node.Attributes.GetNamedItem("Elaborato") == null)
					{
						node.Attributes.Append(_doc.CreateAttribute("Elaborato"));
						try
						{
							_doc.Save(_FileXml);
						}
						catch (Exception ex)
						{
							MessageBox.Show("Attenzione: il file xml e` a sola lettura!\nNon e` possibile tracciare i movimenti importati.\n" + ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
						}
					}
						
					MessageBox.Show("Aggiornamento effettuato", "Messaggio", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}

				BindDataGridDataSource(dsImporti);
			}
			catch (SoapException ex)
			{
				Cursor = Cursors.Arrow;
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return;
			}
			catch (Exception ex)
			{
				Cursor = Cursors.Arrow;
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return;
			}
		}

		private void btnAssegnaTuttiImporti_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (_dsBudgetsSocieta == null)
					return;

				int numeroElaborati = 0;
				foreach (DataRow drImporto in dsImporti.Tables[0].Rows)
				{
					if ((string)drImporto["Elaborazione"] == "Elaborato")
						continue;

					if (drImporto.IsNull("Importo"))
						continue;

					if (drImporto.IsNull("CodiceConto"))
						continue;

					if (drImporto.IsNull("Errore") == false)
						continue;

					string codiceConto = (string)drImporto["CodiceConto"];
					decimal importo    = (decimal)drImporto["Importo"];

					DataRow [] drSocieta = this._dsBudgetsSocieta.Tables["Societa"].Select(
						string.Format("CodiceConto='{0}'", codiceConto));

					Debug.Assert(drSocieta.Length == 1 || drSocieta.Length == 0);
					if (drSocieta.Length == 1)
					{
						DataRow [] drBudget = drSocieta[0].GetChildRows("relSocietaBudget");
						Debug.Assert(drBudget.Length == 1);
						if (drBudget.Length == 1)
						{
							drBudget[0].BeginEdit();
							drBudget[0]["Importo"] = (decimal)drBudget[0]["Importo"] + importo;

							if ((decimal)drBudget[0]["PrezzoConvenzionaleUtente"] > 0m)
								drBudget[0]["QtyMax"] = decimal.Truncate((decimal)drBudget[0]["Importo"] / (decimal)drBudget[0]["PrezzoConvenzionaleUtente"]);
							else
								drBudget[0]["QtyMax"] = 0m;
							// drBudget[0]["QtyMax"]  = decimal.Truncate((decimal)drBudget[0]["Importo"] / (decimal)drBudget[0]["PrezzoConvenzionaleUtente"]);

							drBudget[0].EndEdit();

							drImporto.BeginEdit();
							drImporto["Elaborazione"] = "Elaborato" ;
							drImporto.EndEdit();

							numeroElaborati += 1;

							int progr = (int)drImporto["ProgressivoRecordNelXml"];

							XmlNodeList nodelist = _doc.SelectNodes("/RENDICONTAZIONE_INCASSI/ELENCO_MOVIMENTI/MOVIMENTO");
							XmlNode node = nodelist[progr];

							if (node.Attributes.GetNamedItem("Elaborato") == null)
							{
								node.Attributes.Append(_doc.CreateAttribute("Elaborato"));
							}
						}
					}
				}
				bool IsDataSetUpdated = AggiornaDataSet(_dsBudgetsSocieta);
				if (IsDataSetUpdated)
				{
					try
					{
						_doc.Save(_FileXml);
					}
					catch (Exception ex)
					{
						MessageBox.Show("Attenzione: il file xml e` a sola lettura!\nNon e` possibile tracciare i movimenti importati.\n" + ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
				BindDataGridDataSource(dsImporti);

				switch (numeroElaborati)
				{
					case 0:
						MessageBox.Show("Nessun movimento e` stato elaborato", "Attenzione");
						break;
					case 1:
						MessageBox.Show("E` stato elaborato automaticamente 1 movimento", "Attenzione");
						break;
					default:
						MessageBox.Show(string.Format("Sono stati elaborati automaticamente {0} movimenti", numeroElaborati), "Attenzione");
						break;
				}

			}
			catch (SoapException ex)
			{
				Cursor = Cursors.Arrow;
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return;
			}
			catch (Exception ex)
			{
				Cursor = Cursors.Arrow;
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return;
			}
		}

		static string CausaleVersamento(string CodiceConto, string DataSessione)
		{
			int numchar = 10 - CodiceConto.Length ;
			
			for (int i=0; i<numchar; i++)
				CodiceConto = "0" + CodiceConto ;

			CodiceConto = CodiceConto.ToUpper().Substring(0,10);

			string data = DataSessione;

			string CodParziale = CodiceConto + data ;
			string temp = CodiceConto + data ;
			string codifica = "" ;
			for (int i=0; i<temp.Length; i++)
				codifica = codifica + Cod(temp.Substring(i,1)) ;

			codifica = codifica + "00" ;

			int numsegmenti = (int)(codifica.Length / 7) ;
			string strresto = "" ;
			int val = 0 ;
			int resto = 0 ;
			for (int i=0; i<numsegmenti; i++)
			{
				temp = strresto + codifica.Substring(i*7, 7);
				val = Convert.ToInt32(temp);
				resto = val % 97 ;
				strresto = resto.ToString() ;
			}
			temp = strresto + codifica.Substring(numsegmenti*7, codifica.Length-numsegmenti*7);
			val = Convert.ToInt32(temp);
			resto = val % 97 ;

			int CheckSum = 98 - resto ;
			
			return CheckSum.ToString() + CodParziale ;
		}

		static string Cod(string ch)
		{
			if (ch=="0")
				return "0" ;
			if (ch=="1")
				return "1" ;
			if (ch=="2")
				return "2" ;
			if (ch=="3")
				return "3" ;
			if (ch=="4")
				return "4" ;
			if (ch=="5")
				return "5" ;
			if (ch=="6")
				return "6" ;
			if (ch=="7")
				return "7" ;
			if (ch=="8")
				return "8" ;
			if (ch=="9")
				return "9" ;
			if (ch=="A")
				return "10" ;
			if (ch=="B")
				return "11" ;
			if (ch=="C")
				return "12" ;
			if (ch=="D")
				return "13" ;
			if (ch=="E")
				return "14" ;
			if (ch=="F")
				return "15" ;
			if (ch=="G")
				return "16" ;
			if (ch=="H")
				return "17" ;
			if (ch=="I")
				return "18" ;
			if (ch=="J")
				return "19" ;
			if (ch=="K")
				return "20" ;
			if (ch=="L")
				return "21" ;
			if (ch=="M")
				return "22" ;
			if (ch=="N")
				return "23" ;
			if (ch=="O")
				return "24" ;
			if (ch=="P")
				return "25" ;
			if (ch=="Q")
				return "26" ;
			if (ch=="R")
				return "27" ;
			if (ch=="S")
				return "28" ;
			if (ch=="T")
				return "29" ;
			if (ch=="U")
				return "30" ;
			if (ch=="V")
				return "31" ;
			if (ch=="W")
				return "32" ;
			if (ch=="X")
				return "33" ;
			if (ch=="Y")
				return "34" ;
			if (ch=="Z")
				return "35" ;
			
			return "" ;
		}
	}
}
