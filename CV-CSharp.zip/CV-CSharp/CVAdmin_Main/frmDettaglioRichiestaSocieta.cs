using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmDettaglioRichiesta.
	/// </summary>
	public class frmDettaglioRichiestaSocieta : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox gbDatiSocieta;
		private System.Windows.Forms.Label lblRagioneSociale;
		private System.Windows.Forms.TextBox tbRagioneSociale;
		private System.Windows.Forms.Label lblVia;
		private System.Windows.Forms.TextBox tbViaPiazza;
		private System.Windows.Forms.Label lblCitta;
		private System.Windows.Forms.TextBox tbCitta;
		private System.Windows.Forms.Label lblCAP;
		private System.Windows.Forms.TextBox tbCAP;
		private System.Windows.Forms.Label lblNazione;
		private System.Windows.Forms.TextBox tbNazione;
		private System.Windows.Forms.Label lblTelefono;
		private System.Windows.Forms.TextBox tbTelefono;
		private System.Windows.Forms.Label lblFAX;
		private System.Windows.Forms.TextBox tbFAX;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.TextBox tbEmail;
		private System.Windows.Forms.Label lblCodiceFiscale;
		private System.Windows.Forms.TextBox tbCodiceFiscale;
		private System.Windows.Forms.Label lblPartitaIVA;
		private System.Windows.Forms.TextBox tbPartitaIVA;
		private System.Windows.Forms.Label lblABI;
		private System.Windows.Forms.TextBox tbABI;
		private System.Windows.Forms.Label lblCAB;
		private System.Windows.Forms.TextBox tbCAB;
		private System.Windows.Forms.Label lblContoCorrente;
		private System.Windows.Forms.TextBox tbContoCorrente;
		private System.Windows.Forms.Label lblStatoRichiesta;
		private System.Windows.Forms.TextBox tbStatoRichiesta;
		private System.Windows.Forms.TextBox tbCodiceContoProprieta;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.Button btnValida;
		private System.Windows.Forms.Button btnNota;
		private System.Windows.Forms.Label lblCodiceContoProprieta;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.ToolTip tltInfo;
		private System.Windows.Forms.Label lblSedeAmm;
		private System.Windows.Forms.TextBox tbSedeAmm;
		private System.Windows.Forms.Label lblRefAmm;
		private System.Windows.Forms.TextBox tbRefAmm;


		private DataRow _drRichiesta = null;
		public frmDettaglioRichiestaSocieta()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			ClearComponents();
			_drRichiesta = null;
		}

		public frmDettaglioRichiestaSocieta(DataRow dr)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ClearComponents();

			if (dr == null)
			{
				DisabilitaComponenti();
			}

			_drRichiesta = dr;
			SetComponentsData(_drRichiesta);

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Funzioni Interne

		private void Chiudi()
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void ClearComponents()
		{
			tbABI.Text = "";
			tbCAB.Text = "";
			tbCAP.Text = "";
			tbCitta.Text = "";
			tbCodiceContoProprieta.Text = "";
			tbCodiceFiscale.Text = "";
			tbContoCorrente.Text = "";
			tbEmail.Text = "";
			tbFAX.Text = "";
			tbNazione.Text = "";
			tbPartitaIVA.Text = "";
			tbRagioneSociale.Text = "";
			tbStatoRichiesta.Text = "";
			tbTelefono.Text = "";
			tbViaPiazza.Text = "";
			tbRefAmm.Text = "" ;
			tbSedeAmm.Text = "" ;
		}

		private void DisabilitaComponenti()
		{
			gbDatiSocieta.Enabled = false;
			btnNota.Enabled = false;
			btnChiudi.Enabled = true;
		}

		private void SetComponentsData(DataRow dr)
		{
			if (dr == null)
				return;

			tbStatoRichiesta.Text	= dr["StatoRichiesta"].ToString();
			tbRagioneSociale.Text	= dr["RagioneSociale"].ToString();
			tbViaPiazza.Text		= dr["Indirizzo"].ToString();
			tbCitta.Text			= dr["Citta"].ToString();
			tbCAP.Text				= dr["CAP"].ToString();
			tbNazione.Text			= dr["Nazione"].ToString();
			tbTelefono.Text			= dr["Telefono"].ToString();
			tbFAX.Text				= dr["FAX"].ToString();
			tbEmail.Text			= dr["Email"].ToString();
			tbCodiceFiscale.Text	= dr["CodiceFiscale"].ToString();
			tbPartitaIVA.Text		= dr["PartitaIVA"].ToString();
			tbABI.Text				= dr["ABI"].ToString();
			tbCAB.Text				= dr["CAB"].ToString();
			tbContoCorrente.Text	= dr["CC"].ToString();
			tbCodiceContoProprieta.Text = dr["CodiceConto"].ToString();
			tbRefAmm.Text			= dr["ReferenteAmministr"].ToString() ;
			tbSedeAmm.Text			= dr["SedeAmministrativa"].ToString() ;

			btnValida.Enabled = tbStatoRichiesta.Text.Equals("Da Validare");
			
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDettaglioRichiestaSocieta));
			this.gbDatiSocieta = new System.Windows.Forms.GroupBox();
			this.tbStatoRichiesta = new System.Windows.Forms.TextBox();
			this.lblStatoRichiesta = new System.Windows.Forms.Label();
			this.tbContoCorrente = new System.Windows.Forms.TextBox();
			this.lblContoCorrente = new System.Windows.Forms.Label();
			this.tbCAB = new System.Windows.Forms.TextBox();
			this.lblCAB = new System.Windows.Forms.Label();
			this.tbABI = new System.Windows.Forms.TextBox();
			this.lblABI = new System.Windows.Forms.Label();
			this.tbPartitaIVA = new System.Windows.Forms.TextBox();
			this.lblPartitaIVA = new System.Windows.Forms.Label();
			this.tbCodiceFiscale = new System.Windows.Forms.TextBox();
			this.lblCodiceFiscale = new System.Windows.Forms.Label();
			this.tbEmail = new System.Windows.Forms.TextBox();
			this.lblEmail = new System.Windows.Forms.Label();
			this.tbFAX = new System.Windows.Forms.TextBox();
			this.lblFAX = new System.Windows.Forms.Label();
			this.tbTelefono = new System.Windows.Forms.TextBox();
			this.lblTelefono = new System.Windows.Forms.Label();
			this.tbNazione = new System.Windows.Forms.TextBox();
			this.lblNazione = new System.Windows.Forms.Label();
			this.tbCAP = new System.Windows.Forms.TextBox();
			this.lblCAP = new System.Windows.Forms.Label();
			this.tbCitta = new System.Windows.Forms.TextBox();
			this.lblCitta = new System.Windows.Forms.Label();
			this.tbViaPiazza = new System.Windows.Forms.TextBox();
			this.lblVia = new System.Windows.Forms.Label();
			this.tbRagioneSociale = new System.Windows.Forms.TextBox();
			this.lblRagioneSociale = new System.Windows.Forms.Label();
			this.lblCodiceContoProprieta = new System.Windows.Forms.Label();
			this.tbCodiceContoProprieta = new System.Windows.Forms.TextBox();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnValida = new System.Windows.Forms.Button();
			this.btnNota = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.lblSedeAmm = new System.Windows.Forms.Label();
			this.tbSedeAmm = new System.Windows.Forms.TextBox();
			this.lblRefAmm = new System.Windows.Forms.Label();
			this.tbRefAmm = new System.Windows.Forms.TextBox();
			this.gbDatiSocieta.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbDatiSocieta
			// 
			this.gbDatiSocieta.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.tbRefAmm,
																						this.lblRefAmm,
																						this.tbSedeAmm,
																						this.lblSedeAmm,
																						this.tbStatoRichiesta,
																						this.lblStatoRichiesta,
																						this.tbContoCorrente,
																						this.lblContoCorrente,
																						this.tbCAB,
																						this.lblCAB,
																						this.tbABI,
																						this.lblABI,
																						this.tbPartitaIVA,
																						this.lblPartitaIVA,
																						this.tbCodiceFiscale,
																						this.lblCodiceFiscale,
																						this.tbEmail,
																						this.lblEmail,
																						this.tbFAX,
																						this.lblFAX,
																						this.tbTelefono,
																						this.lblTelefono,
																						this.tbNazione,
																						this.lblNazione,
																						this.tbCAP,
																						this.lblCAP,
																						this.tbCitta,
																						this.lblCitta,
																						this.tbViaPiazza,
																						this.lblVia,
																						this.tbRagioneSociale,
																						this.lblRagioneSociale});
			this.gbDatiSocieta.Location = new System.Drawing.Point(4, 4);
			this.gbDatiSocieta.Name = "gbDatiSocieta";
			this.gbDatiSocieta.Size = new System.Drawing.Size(692, 240);
			this.gbDatiSocieta.TabIndex = 0;
			this.gbDatiSocieta.TabStop = false;
			this.gbDatiSocieta.Text = " Dati Societ� ";
			// 
			// tbStatoRichiesta
			// 
			this.tbStatoRichiesta.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbStatoRichiesta.Enabled = false;
			this.tbStatoRichiesta.Location = new System.Drawing.Point(561, 15);
			this.tbStatoRichiesta.Name = "tbStatoRichiesta";
			this.tbStatoRichiesta.Size = new System.Drawing.Size(123, 20);
			this.tbStatoRichiesta.TabIndex = 27;
			this.tbStatoRichiesta.TabStop = false;
			this.tbStatoRichiesta.Text = "Stato Richiesta";
			// 
			// lblStatoRichiesta
			// 
			this.lblStatoRichiesta.Location = new System.Drawing.Point(484, 17);
			this.lblStatoRichiesta.Name = "lblStatoRichiesta";
			this.lblStatoRichiesta.Size = new System.Drawing.Size(78, 16);
			this.lblStatoRichiesta.TabIndex = 26;
			this.lblStatoRichiesta.Text = "Stato richiesta";
			// 
			// tbContoCorrente
			// 
			this.tbContoCorrente.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbContoCorrente.Enabled = false;
			this.tbContoCorrente.Location = new System.Drawing.Point(484, 201);
			this.tbContoCorrente.Name = "tbContoCorrente";
			this.tbContoCorrente.Size = new System.Drawing.Size(200, 20);
			this.tbContoCorrente.TabIndex = 25;
			this.tbContoCorrente.TabStop = false;
			this.tbContoCorrente.Text = "Conto Corrente";
			// 
			// lblContoCorrente
			// 
			this.lblContoCorrente.Location = new System.Drawing.Point(403, 203);
			this.lblContoCorrente.Name = "lblContoCorrente";
			this.lblContoCorrente.Size = new System.Drawing.Size(84, 16);
			this.lblContoCorrente.TabIndex = 24;
			this.lblContoCorrente.Text = "Conto Corrente";
			// 
			// tbCAB
			// 
			this.tbCAB.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbCAB.Enabled = false;
			this.tbCAB.Location = new System.Drawing.Point(260, 201);
			this.tbCAB.Name = "tbCAB";
			this.tbCAB.Size = new System.Drawing.Size(140, 20);
			this.tbCAB.TabIndex = 23;
			this.tbCAB.TabStop = false;
			this.tbCAB.Text = "CAB";
			// 
			// lblCAB
			// 
			this.lblCAB.Location = new System.Drawing.Point(232, 203);
			this.lblCAB.Name = "lblCAB";
			this.lblCAB.Size = new System.Drawing.Size(28, 16);
			this.lblCAB.TabIndex = 22;
			this.lblCAB.Text = "CAB";
			// 
			// tbABI
			// 
			this.tbABI.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbABI.Enabled = false;
			this.tbABI.Location = new System.Drawing.Point(96, 201);
			this.tbABI.Name = "tbABI";
			this.tbABI.Size = new System.Drawing.Size(132, 20);
			this.tbABI.TabIndex = 21;
			this.tbABI.TabStop = false;
			this.tbABI.Text = "ABI";
			// 
			// lblABI
			// 
			this.lblABI.Location = new System.Drawing.Point(7, 203);
			this.lblABI.Name = "lblABI";
			this.lblABI.Size = new System.Drawing.Size(28, 16);
			this.lblABI.TabIndex = 20;
			this.lblABI.Text = "ABI";
			// 
			// tbPartitaIVA
			// 
			this.tbPartitaIVA.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbPartitaIVA.Enabled = false;
			this.tbPartitaIVA.Location = new System.Drawing.Point(484, 169);
			this.tbPartitaIVA.Name = "tbPartitaIVA";
			this.tbPartitaIVA.Size = new System.Drawing.Size(200, 20);
			this.tbPartitaIVA.TabIndex = 19;
			this.tbPartitaIVA.TabStop = false;
			this.tbPartitaIVA.Text = "Partita IVA";
			// 
			// lblPartitaIVA
			// 
			this.lblPartitaIVA.Location = new System.Drawing.Point(403, 171);
			this.lblPartitaIVA.Name = "lblPartitaIVA";
			this.lblPartitaIVA.Size = new System.Drawing.Size(64, 16);
			this.lblPartitaIVA.TabIndex = 18;
			this.lblPartitaIVA.Text = "Partita IVA";
			// 
			// tbCodiceFiscale
			// 
			this.tbCodiceFiscale.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbCodiceFiscale.Enabled = false;
			this.tbCodiceFiscale.Location = new System.Drawing.Point(96, 169);
			this.tbCodiceFiscale.Name = "tbCodiceFiscale";
			this.tbCodiceFiscale.Size = new System.Drawing.Size(168, 20);
			this.tbCodiceFiscale.TabIndex = 17;
			this.tbCodiceFiscale.TabStop = false;
			this.tbCodiceFiscale.Text = "Codice Fiscale";
			// 
			// lblCodiceFiscale
			// 
			this.lblCodiceFiscale.Location = new System.Drawing.Point(7, 171);
			this.lblCodiceFiscale.Name = "lblCodiceFiscale";
			this.lblCodiceFiscale.Size = new System.Drawing.Size(80, 16);
			this.lblCodiceFiscale.TabIndex = 16;
			this.lblCodiceFiscale.Text = "Codice Fiscale";
			// 
			// tbEmail
			// 
			this.tbEmail.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbEmail.Enabled = false;
			this.tbEmail.Location = new System.Drawing.Point(484, 137);
			this.tbEmail.Name = "tbEmail";
			this.tbEmail.Size = new System.Drawing.Size(200, 20);
			this.tbEmail.TabIndex = 15;
			this.tbEmail.TabStop = false;
			this.tbEmail.Text = "Email";
			// 
			// lblEmail
			// 
			this.lblEmail.Location = new System.Drawing.Point(403, 139);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(40, 16);
			this.lblEmail.TabIndex = 14;
			this.lblEmail.Text = "E-mail";
			// 
			// tbFAX
			// 
			this.tbFAX.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbFAX.Enabled = false;
			this.tbFAX.Location = new System.Drawing.Point(260, 137);
			this.tbFAX.Name = "tbFAX";
			this.tbFAX.Size = new System.Drawing.Size(140, 20);
			this.tbFAX.TabIndex = 13;
			this.tbFAX.TabStop = false;
			this.tbFAX.Text = "FAX";
			// 
			// lblFAX
			// 
			this.lblFAX.Location = new System.Drawing.Point(232, 140);
			this.lblFAX.Name = "lblFAX";
			this.lblFAX.Size = new System.Drawing.Size(30, 15);
			this.lblFAX.TabIndex = 12;
			this.lblFAX.Text = "FAX";
			// 
			// tbTelefono
			// 
			this.tbTelefono.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbTelefono.Enabled = false;
			this.tbTelefono.Location = new System.Drawing.Point(96, 137);
			this.tbTelefono.Name = "tbTelefono";
			this.tbTelefono.Size = new System.Drawing.Size(132, 20);
			this.tbTelefono.TabIndex = 11;
			this.tbTelefono.TabStop = false;
			this.tbTelefono.Text = "Telefono";
			// 
			// lblTelefono
			// 
			this.lblTelefono.Location = new System.Drawing.Point(7, 139);
			this.lblTelefono.Name = "lblTelefono";
			this.lblTelefono.Size = new System.Drawing.Size(52, 16);
			this.lblTelefono.TabIndex = 10;
			this.lblTelefono.Text = "Telefono";
			// 
			// tbNazione
			// 
			this.tbNazione.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbNazione.Enabled = false;
			this.tbNazione.Location = new System.Drawing.Point(484, 105);
			this.tbNazione.Name = "tbNazione";
			this.tbNazione.Size = new System.Drawing.Size(200, 20);
			this.tbNazione.TabIndex = 9;
			this.tbNazione.TabStop = false;
			this.tbNazione.Text = "Nazione";
			// 
			// lblNazione
			// 
			this.lblNazione.Location = new System.Drawing.Point(403, 107);
			this.lblNazione.Name = "lblNazione";
			this.lblNazione.Size = new System.Drawing.Size(52, 16);
			this.lblNazione.TabIndex = 8;
			this.lblNazione.Text = "Nazione";
			// 
			// tbCAP
			// 
			this.tbCAP.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbCAP.Enabled = false;
			this.tbCAP.Location = new System.Drawing.Point(96, 105);
			this.tbCAP.Name = "tbCAP";
			this.tbCAP.Size = new System.Drawing.Size(68, 20);
			this.tbCAP.TabIndex = 7;
			this.tbCAP.TabStop = false;
			this.tbCAP.Text = "CAP";
			// 
			// lblCAP
			// 
			this.lblCAP.Location = new System.Drawing.Point(7, 107);
			this.lblCAP.Name = "lblCAP";
			this.lblCAP.Size = new System.Drawing.Size(28, 16);
			this.lblCAP.TabIndex = 6;
			this.lblCAP.Text = "CAP";
			// 
			// tbCitta
			// 
			this.tbCitta.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbCitta.Enabled = false;
			this.tbCitta.Location = new System.Drawing.Point(484, 73);
			this.tbCitta.Name = "tbCitta";
			this.tbCitta.Size = new System.Drawing.Size(200, 20);
			this.tbCitta.TabIndex = 5;
			this.tbCitta.TabStop = false;
			this.tbCitta.Text = "Citta";
			// 
			// lblCitta
			// 
			this.lblCitta.Location = new System.Drawing.Point(403, 75);
			this.lblCitta.Name = "lblCitta";
			this.lblCitta.Size = new System.Drawing.Size(36, 16);
			this.lblCitta.TabIndex = 4;
			this.lblCitta.Text = "Citt�";
			// 
			// tbViaPiazza
			// 
			this.tbViaPiazza.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbViaPiazza.Enabled = false;
			this.tbViaPiazza.Location = new System.Drawing.Point(95, 73);
			this.tbViaPiazza.Name = "tbViaPiazza";
			this.tbViaPiazza.Size = new System.Drawing.Size(305, 20);
			this.tbViaPiazza.TabIndex = 3;
			this.tbViaPiazza.TabStop = false;
			this.tbViaPiazza.Text = "Via/Piazza";
			// 
			// lblVia
			// 
			this.lblVia.Location = new System.Drawing.Point(7, 75);
			this.lblVia.Name = "lblVia";
			this.lblVia.Size = new System.Drawing.Size(64, 16);
			this.lblVia.TabIndex = 2;
			this.lblVia.Text = "Via/Piazza";
			// 
			// tbRagioneSociale
			// 
			this.tbRagioneSociale.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbRagioneSociale.Enabled = false;
			this.tbRagioneSociale.Location = new System.Drawing.Point(96, 16);
			this.tbRagioneSociale.Name = "tbRagioneSociale";
			this.tbRagioneSociale.Size = new System.Drawing.Size(305, 20);
			this.tbRagioneSociale.TabIndex = 1;
			this.tbRagioneSociale.TabStop = false;
			this.tbRagioneSociale.Text = "Ragione Sociale";
			// 
			// lblRagioneSociale
			// 
			this.lblRagioneSociale.Location = new System.Drawing.Point(8, 16);
			this.lblRagioneSociale.Name = "lblRagioneSociale";
			this.lblRagioneSociale.Size = new System.Drawing.Size(88, 16);
			this.lblRagioneSociale.TabIndex = 0;
			this.lblRagioneSociale.Text = "Ragione Sociale";
			// 
			// lblCodiceContoProprieta
			// 
			this.lblCodiceContoProprieta.Location = new System.Drawing.Point(4, 251);
			this.lblCodiceContoProprieta.Name = "lblCodiceContoProprieta";
			this.lblCodiceContoProprieta.Size = new System.Drawing.Size(84, 16);
			this.lblCodiceContoProprieta.TabIndex = 1;
			this.lblCodiceContoProprieta.Text = "Codice Conto";
			// 
			// tbCodiceContoProprieta
			// 
			this.tbCodiceContoProprieta.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbCodiceContoProprieta.Enabled = false;
			this.tbCodiceContoProprieta.Location = new System.Drawing.Point(96, 248);
			this.tbCodiceContoProprieta.Name = "tbCodiceContoProprieta";
			this.tbCodiceContoProprieta.TabIndex = 2;
			this.tbCodiceContoProprieta.TabStop = false;
			this.tbCodiceContoProprieta.Text = "Codice Conto";
			// 
			// btnChiudi
			// 
			this.btnChiudi.Location = new System.Drawing.Point(621, 248);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 3;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa finestra");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnValida
			// 
			this.btnValida.Location = new System.Drawing.Point(542, 248);
			this.btnValida.Name = "btnValida";
			this.btnValida.TabIndex = 4;
			this.btnValida.Text = "&Valida";
			this.tltInfo.SetToolTip(this.btnValida, "Valida la Societ� selezionata");
			this.btnValida.Click += new System.EventHandler(this.btnValida_Click);
			// 
			// btnNota
			// 
			this.btnNota.Location = new System.Drawing.Point(462, 248);
			this.btnNota.Name = "btnNota";
			this.btnNota.TabIndex = 6;
			this.btnNota.Text = "&Nota";
			this.tltInfo.SetToolTip(this.btnNota, "Aggiungi una Nota per la Societ�");
			this.btnNota.Click += new System.EventHandler(this.btnNota_Click);
			// 
			// lblSedeAmm
			// 
			this.lblSedeAmm.Location = new System.Drawing.Point(8, 40);
			this.lblSedeAmm.Name = "lblSedeAmm";
			this.lblSedeAmm.Size = new System.Drawing.Size(88, 24);
			this.lblSedeAmm.TabIndex = 28;
			this.lblSedeAmm.Text = "Sede Amministrativa";
			// 
			// tbSedeAmm
			// 
			this.tbSedeAmm.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbSedeAmm.Enabled = false;
			this.tbSedeAmm.Location = new System.Drawing.Point(96, 48);
			this.tbSedeAmm.Name = "tbSedeAmm";
			this.tbSedeAmm.Size = new System.Drawing.Size(305, 20);
			this.tbSedeAmm.TabIndex = 29;
			this.tbSedeAmm.TabStop = false;
			this.tbSedeAmm.Text = "Sede Amministrativa";
			// 
			// lblRefAmm
			// 
			this.lblRefAmm.Location = new System.Drawing.Point(408, 40);
			this.lblRefAmm.Name = "lblRefAmm";
			this.lblRefAmm.Size = new System.Drawing.Size(88, 24);
			this.lblRefAmm.TabIndex = 30;
			this.lblRefAmm.Text = "Referente Amministrativo";
			// 
			// tbRefAmm
			// 
			this.tbRefAmm.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbRefAmm.Enabled = false;
			this.tbRefAmm.Location = new System.Drawing.Point(484, 48);
			this.tbRefAmm.Name = "tbRefAmm";
			this.tbRefAmm.Size = new System.Drawing.Size(200, 20);
			this.tbRefAmm.TabIndex = 31;
			this.tbRefAmm.TabStop = false;
			this.tbRefAmm.Text = "Referente Amministrativo";
			// 
			// frmDettaglioRichiestaSocieta
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(698, 275);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnNota,
																		  this.btnValida,
																		  this.btnChiudi,
																		  this.tbCodiceContoProprieta,
																		  this.lblCodiceContoProprieta,
																		  this.gbDatiSocieta});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmDettaglioRichiestaSocieta";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Dettaglio Richiesta Societ�";
			this.gbDatiSocieta.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		#region Eventi della Form
		
		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			Chiudi();
		}

		private void btnValida_Click(object sender, System.EventArgs e)
		{
			if (tbCodiceContoProprieta.Text == String.Empty)
			{
				MessageBox.Show("Per Validare una Societ� � necessario inserire un Codice Conto", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			string IdSocieta = ValidaSocieta(_drRichiesta["IdRichiestaRegSoc"].ToString());
			if ((IdSocieta == null) || (IdSocieta == String.Empty))
			{
				MessageBox.Show("La Societ� non � stata validata in modo corretto", "Validazione", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			else
			{
				MessageBox.Show("La Societ� � stata validata in modo corretto", "Validazione", MessageBoxButtons.OK, MessageBoxIcon.Information);
				_drRichiesta["StatoRichiesta"] = "Valida";
				_drRichiesta.EndEdit();
				this.DialogResult = DialogResult.OK;
			}
		}

		private void btnNota_Click(object sender, System.EventArgs e)
		{
			frmNota frm = new frmNota(_drRichiesta);
			frm.ShowDialog(this);
		}


		#endregion


		#region Chiamata ai Web Services

		private string ValidaSocieta(string IdRichiestaRegSoc)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.Valida", 
				IdRichiestaRegSoc);

			if (Cancelled)
				return null;

			return (string)ret;
		}

		#endregion

	}
}
