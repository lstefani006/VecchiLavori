using System;
using System.Drawing;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Services.Protocols;
using System.Xml;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmExport.
	/// </summary>
	public class frmExport : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtNumeroTransazioniValide;
		private System.Windows.Forms.TextBox txtNumeroContiSbloc;
		private System.Windows.Forms.TextBox txtNomeFile;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private string _ftpServer = null;
		private string _ftpUser = null;
		private string _ftpPwd = null;
		private System.Windows.Forms.Button cmdTrasmettiFile;
		private System.Windows.Forms.Button cmdChiudi;
		private string _ftpDir = null;
		private System.Windows.Forms.DateTimePicker dtpDataUltimoInvio;
		private string _IdSessione;

//		private DataSet _TransazioniValide = null;

		public frmExport()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		public frmExport(string IdSessione, DateTime DataApertura)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_ftpServer = LocalSettings.appSettings["GRNT.Transazioni.ExportFileXml.ServerFtp"];
			_ftpUser   = LocalSettings.appSettings["GRNT.Transazioni.ExportFileXml.UserFtp"];
			_ftpPwd    = LocalSettings.appSettings["GRNT.Transazioni.ExportFileXml.PassFtp"];
			_ftpDir    = LocalSettings.appSettings["GRNT.Transazioni.ExportFileXml.DirFtp"];

			if (_ftpServer == null)
				MessageBox.Show("Il file di configurazione non contiene la chiave\nGRNT.Transazioni.ExportFileXml.ServerFtp", "Error");
			if (_ftpUser == null)
				MessageBox.Show("Il file di configurazione non contiene la chiave\nGRNT.Transazioni.ExportFileXml.UserFtp", "Error");
			if (_ftpPwd == null)
				MessageBox.Show("Il file di configurazione non contiene la chiave\nGRNT.Transazioni.ExportFileXml.PassFtp", "Error");
			if (_ftpDir == null)
				MessageBox.Show("Il file di configurazione non contiene la chiave\nGRNT.Transazioni.ExportFileXml.DirFtp", "Error");


			_IdSessione = IdSessione;

			dtpDataUltimoInvio.Value = DataApertura;
			txtNumeroTransazioniValide.Text = Converter.DecimalToIntegerString(GetNumeroTransazioniValide(IdSessione));
			txtNumeroContiSbloc.Text = Converter.DecimalToIntegerString(GetNumeroContiDaSbloccare(IdSessione));
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmExport));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtNumeroTransazioniValide = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtNumeroContiSbloc = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtNomeFile = new System.Windows.Forms.TextBox();
			this.cmdTrasmettiFile = new System.Windows.Forms.Button();
			this.cmdChiudi = new System.Windows.Forms.Button();
			this.dtpDataUltimoInvio = new System.Windows.Forms.DateTimePicker();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(144, 24);
			this.label1.TabIndex = 0;
			this.label1.Text = "Data ultimo invio dati:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(144, 24);
			this.label2.TabIndex = 1;
			this.label2.Text = "Numero transazioni valide:";
			// 
			// txtNumeroTransazioniValide
			// 
			this.txtNumeroTransazioniValide.Enabled = false;
			this.txtNumeroTransazioniValide.Location = new System.Drawing.Point(168, 48);
			this.txtNumeroTransazioniValide.Name = "txtNumeroTransazioniValide";
			this.txtNumeroTransazioniValide.ReadOnly = true;
			this.txtNumeroTransazioniValide.Size = new System.Drawing.Size(144, 20);
			this.txtNumeroTransazioniValide.TabIndex = 3;
			this.txtNumeroTransazioniValide.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 80);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(144, 24);
			this.label3.TabIndex = 4;
			this.label3.Text = "Numero conti da sbloccare:";
			// 
			// txtNumeroContiSbloc
			// 
			this.txtNumeroContiSbloc.Enabled = false;
			this.txtNumeroContiSbloc.Location = new System.Drawing.Point(168, 80);
			this.txtNumeroContiSbloc.Name = "txtNumeroContiSbloc";
			this.txtNumeroContiSbloc.ReadOnly = true;
			this.txtNumeroContiSbloc.Size = new System.Drawing.Size(144, 20);
			this.txtNumeroContiSbloc.TabIndex = 5;
			this.txtNumeroContiSbloc.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 112);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(144, 24);
			this.label4.TabIndex = 6;
			this.label4.Text = "Nome file:";
			// 
			// txtNomeFile
			// 
			this.txtNomeFile.Location = new System.Drawing.Point(168, 112);
			this.txtNomeFile.Name = "txtNomeFile";
			this.txtNomeFile.Size = new System.Drawing.Size(144, 20);
			this.txtNomeFile.TabIndex = 7;
			this.txtNomeFile.Text = "";
			// 
			// cmdTrasmettiFile
			// 
			this.cmdTrasmettiFile.Location = new System.Drawing.Point(8, 152);
			this.cmdTrasmettiFile.Name = "cmdTrasmettiFile";
			this.cmdTrasmettiFile.Size = new System.Drawing.Size(144, 24);
			this.cmdTrasmettiFile.TabIndex = 8;
			this.cmdTrasmettiFile.Text = "Trasmetti file XML";
			this.cmdTrasmettiFile.Click += new System.EventHandler(this.cmdTrasmettiFile_Click);
			// 
			// cmdChiudi
			// 
			this.cmdChiudi.Location = new System.Drawing.Point(168, 152);
			this.cmdChiudi.Name = "cmdChiudi";
			this.cmdChiudi.Size = new System.Drawing.Size(144, 24);
			this.cmdChiudi.TabIndex = 9;
			this.cmdChiudi.Text = "Chiudi";
			this.cmdChiudi.Click += new System.EventHandler(this.cmdChiudi_Click);
			// 
			// dtpDataUltimoInvio
			// 
			this.dtpDataUltimoInvio.Enabled = false;
			this.dtpDataUltimoInvio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpDataUltimoInvio.Location = new System.Drawing.Point(168, 16);
			this.dtpDataUltimoInvio.Name = "dtpDataUltimoInvio";
			this.dtpDataUltimoInvio.Size = new System.Drawing.Size(144, 20);
			this.dtpDataUltimoInvio.TabIndex = 10;
			// 
			// frmExport
			// 
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(322, 191);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dtpDataUltimoInvio,
																		  this.cmdChiudi,
																		  this.cmdTrasmettiFile,
																		  this.txtNomeFile,
																		  this.label4,
																		  this.txtNumeroContiSbloc,
																		  this.label3,
																		  this.txtNumeroTransazioniValide,
																		  this.label2,
																		  this.label1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmExport";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Export XML per GRTN";
			this.ResumeLayout(false);

		}
		#endregion


		static int GetNumeroContiDaSbloccare(string IdSessione)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLTransazione.BLTransazione.ContiDaSbloccare", 
				IdSessione);
			if (Cancelled)
				return 0;
			DataSet ds = (DataSet)ret;
			return ds.Tables["ContiDaSbloccare"].Rows.Count;
		}
		static int GetNumeroTransazioniValide(string IdSessione)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLTransazione.BLTransazione.NumeroTransazioniValide", 
				IdSessione);
			if (Cancelled)
				return 0;
			return (int)ret;
		}

		static DataSet CertificatiVerdi_GetExportData(string IdSessione)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLCertificatiVerdi.BLCertificatiVerdi.GetExportData", 
				IdSessione);
			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		static bool Transazione_Insert_DataExportXML(string IdSessione, DataSet ds, DateTime dataExport)
		{
			bool Cancelled;
			frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLTransazione.BLTransazione.Insert_DataExportXML", 
				IdSessione, ds, dataExport);
			if (Cancelled)
				return false;
			return true;
		}





		private void cmdChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void cmdTrasmettiFile_Click(object sender, System.EventArgs e)
		{
			try
			{
				// controllo argomenti
				if (Converter.IntegerStringToDecimal(txtNumeroContiSbloc.Text) == 0m && 
					Converter.IntegerStringToDecimal(txtNumeroTransazioniValide.Text) == 0)
				{
					MessageBox.Show("Non ci sono dati da trasmettere", "Attenzione");
					return;
				}


				Regex r = new Regex(@"^ *([0-9a-z_]+)(\.xml)? *$", RegexOptions.IgnoreCase);
				Match m = r.Match(txtNomeFile.Text);
				if (m.Success == false)
				{
					MessageBox.Show("Nome file non valido", "Attenzione");
					txtNomeFile.Focus();
					return;
				}

				string fn = m.Groups[1].ToString();  // ToString OK
				string xml_opz = m.Groups[2].ToString(); // ToString OK

				if (xml_opz == null || xml_opz == "")
					fn += ".xml";

				// data di export
				DateTime DataExport = DateTime.Now;
				string lfn = string.Format(@"{0}\{1:yyyy}_{1:MM}_{1:dd}_{1:HH}_{1:mm}_{1:ss}_{2}", 
					Path.GetTempPath(), DataExport, fn);

				// ottengo i certificati da exportare
				DataSet ds = CertificatiVerdi_GetExportData(_IdSessione);
				if (ds == null)
					return;

				DiagnosticHelper.DataSetDump("GetExportData", ds);

				// creo il file XML
				if (true)
				{
					XmlTextWriter xw = new XmlTextWriter(lfn, Encoding.UTF8);
					xw.Formatting = Formatting.Indented;
					xw.Indentation = 1;
					xw.IndentChar = '\t';

					xw.WriteStartDocument();
					xw.WriteDocType("RITORNO_ECV", null, "RITORNO_ECV-DTD.dtd", null);
					xw.WriteStartElement("RITORNO_ECV");

					foreach (DataRow dr in ds.Tables["TransazioniValide"].Rows)
					{
						xw.WriteStartElement("TRANSAZIONE");
						if (true)
						{
							string   Conto_Origine      = (string)dr["Conto_Origine"];
							string   Conto_Destinazione = (string)dr["Conto_Destinazione"];
							int      QtyCertificati     = (int)(decimal)dr["QtyCertificati"];
							string   AnnoRiferimento    = (string)dr["AnnoRiferimento"];
							DateTime DataOraOperazione  = (DateTime)dr["DataOraOperazione"];

							xw.WriteAttributeString("NUMERO_CONTO_ORIGINE", Conto_Origine);
							xw.WriteAttributeString("NUMERO_CONTO_DESTINAZIONE", Conto_Destinazione);
							xw.WriteAttributeString("NUMERO_CV", XmlConvert.ToString(QtyCertificati));
							xw.WriteAttributeString("ANNO_VALIDITA", AnnoRiferimento);
							xw.WriteAttributeString("DATA_TRANSAZIONE", XmlConvert.ToString(DataOraOperazione, "dd/MM/yyyy"));
							xw.WriteAttributeString("ORA_TRANSAZIONE", XmlConvert.ToString(DataOraOperazione, "HH-mm-ss"));
							xw.WriteAttributeString("TIPO_OPERAZIONE", "A");
							xw.WriteAttributeString("OPERATORE", "GME");
						}
						xw.WriteEndElement();
					}
					
					if (ds.Tables["ContiDaSbloccare"].Rows.Count == 0)
					{
						xw.WriteStartElement("SBLOCCO");
						xw.WriteAttributeString("NUMERO_CONTO", "non ci sono conti da sbloccare");
						xw.WriteEndElement();
					}
					else
					{
						foreach (DataRow drc in ds.Tables["ContiDaSbloccare"].Rows)
						{
							xw.WriteStartElement("SBLOCCO");
							xw.WriteAttributeString("NUMERO_CONTO", (string)drc["chiavecontoproprieta"]);
							xw.WriteEndElement();
						}
					}
					xw.WriteEndElement();
					xw.WriteEndDocument();
					xw.Close();  
				}
				// il file .xml e' stato creato.


				// Mando il file al server
				using(FtpClientLib.FTPClient ftp = new FtpClientLib.FTPClient())
				{
					ftp.RemoteUser = _ftpUser;
					ftp.RemotePass = _ftpPwd;
					ftp.RemoteHost = _ftpServer;
				
					ftp.login();
					ftp.chdir(_ftpDir);
					ftp.upload(lfn);
				}

				// lo cancello il file appena spedito
				File.Delete(lfn);

				// Insert_DataExportXML
				if (Transazione_Insert_DataExportXML(_IdSessione, ds, DataExport) == false)
					return;

				MessageBox.Show("Invio avvenuto con successo", "Messaggio");
				this.Close();
				return;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

			
	}
}

