using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Net;
using System.Configuration;

namespace CVAdmin_Main
{
	public class frmReportViewer : System.Windows.Forms.Form
	{
		private AxSHDocVw.AxWebBrowser wb;
		private string tmpfile = null;
		private System.Windows.Forms.RichTextBox edt;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmReportViewer()
		{
			InitializeComponent();
		}

		public enum Formato
		{
			Html,
			Cbi
		}
		public frmReportViewer(string title, string data, Formato fmt)
			: this()
		{
			if (fmt == Formato.Html)
			{
				edt.Visible = false;

				tmpfile = Path.GetTempPath() + "rpt.htm";
				FileStream fs = new FileStream(tmpfile, FileMode.Create, FileAccess.Write, FileShare.None);
				using (StreamWriter sw = new StreamWriter(fs))
				{
					sw.Write(data);
				}
				fs.Close();


				// dentro i file dei report in formato HTML c'e` il riferimento all'immagine
				// del logo GME. Siccome scarico i report HTML in GetTempPath()
				// si adopero per scaricare in quella dir. "gme_logo.jpg" se non esiste.
				try
				{
					if (File.Exists(Path.GetTempPath() + "gme_logo.jpg") == false)
					{
						using (WebClient webClient = new WebClient())
						{
							string fnTmp = Path.GetTempFileName();
							string CVAdminURL = ConfigurationSettings.AppSettings["CVAdminWebServerURL"];
							webClient.DownloadFile(CVAdminURL + "/gme_logo.jpg", fnTmp);
							File.Move(fnTmp, Path.GetTempPath() + "gme_logo.jpg");
						}
					}
				}
				catch (Exception)
				{
					// se fallisce pace... vedra` i report senza logo.
				}
			
				this.Text = title;
				object param = null;
				wb.Navigate(tmpfile, ref param, ref param, ref param, ref param);

			}
			else if (fmt == Formato.Cbi)
			{
				wb.Visible = false;
				edt.Text = data;
				edt.Font = new Font("Courier New", 9);
			}
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmReportViewer));
			this.wb = new AxSHDocVw.AxWebBrowser();
			this.edt = new System.Windows.Forms.RichTextBox();
			((System.ComponentModel.ISupportInitialize)(this.wb)).BeginInit();
			this.SuspendLayout();
			// 
			// wb
			// 
			this.wb.Dock = System.Windows.Forms.DockStyle.Fill;
			this.wb.Enabled = true;
			this.wb.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("wb.OcxState")));
			this.wb.Size = new System.Drawing.Size(864, 477);
			this.wb.TabIndex = 0;
			// 
			// edt
			// 
			this.edt.Dock = System.Windows.Forms.DockStyle.Fill;
			this.edt.Name = "edt";
			this.edt.ReadOnly = true;
			this.edt.Size = new System.Drawing.Size(864, 477);
			this.edt.TabIndex = 1;
			this.edt.Text = "";
			// 
			// frmReportViewer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(864, 477);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.edt,
																		  this.wb});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmReportViewer";
			this.Text = "Report Viewer";
			this.Closed += new System.EventHandler(this.frmReportHtmlViewer_Closed);
			((System.ComponentModel.ISupportInitialize)(this.wb)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frmReportHtmlViewer_Closed(object sender, System.EventArgs e)
		{
			try
			{
				if (tmpfile != null)
					File.Delete(tmpfile);
			}
			catch (Exception)
			{
			}
		}
	}
}
