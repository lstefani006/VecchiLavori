using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.Diagnostics;
using System.Threading;
using ExcelHelper;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmLogOfferte.
	/// </summary>
	public class frmLogOfferte : System.Windows.Forms.Form
	{
		private System.Windows.Forms.SaveFileDialog dlgEsportaXls;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton optOffertaAcquisto;
		private System.Windows.Forms.RadioButton optOffertaVendita;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label;
		private System.Windows.Forms.TextBox edtRagioneSociale;
		private System.Windows.Forms.TextBox edtAnno;
		private System.Windows.Forms.TextBox edtCodiceConto;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.Button btnEsportaExcel;
		private System.Windows.Forms.DataGrid dgLogOfferteAcquisto;
		private System.Windows.Forms.DataGrid dgLogOfferteVendita;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		

		DataSet dsLogAcquisti;
		DataSet dsLogVendita;
		string _IdSessione;
		private System.Windows.Forms.ProgressBar progressBar;


		private System.ComponentModel.Container components = null;

		public frmLogOfferte(string IdSessione)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_IdSessione = IdSessione;

			// si inizia sempre con l'acquisto
			optOffertaAcquisto.Checked = true;

			// rendo visibile una o l'altra griglia
			if (optOffertaAcquisto.Checked)
			{
				dgLogOfferteAcquisto.Visible = true;
				dgLogOfferteVendita.Visible = false;
			}
			else
			{
				dgLogOfferteAcquisto.Visible = false;
				dgLogOfferteVendita.Visible = true;
			}

			progressBar.Visible = false;

			dgLogOfferteVendita.Location = dgLogOfferteAcquisto.Location;
			dgLogOfferteVendita.Size     = dgLogOfferteAcquisto.Size;

			// faccio il data binding sulle 2 griglie
			SetDataGridMapping(true);
			SetDataGridMapping(false);


			dsLogAcquisti = LogOfferte_RetrieveAcquisto(IdSessione);
			if (dsLogAcquisti != null)
				dsLogVendita  = LogOfferte_RetrieveVendita(IdSessione);

			if (dsLogVendita == null || dsLogAcquisti == null)
			{
				btnEsportaExcel.Enabled = false;
				return;
			}

			DataView dvLogAcquisti = new DataView(dsLogAcquisti.Tables[0]);
			dvLogAcquisti.Sort = "IdLog";
			dvLogAcquisti.AllowDelete = false;
			dvLogAcquisti.AllowNew = false;
			dvLogAcquisti.AllowEdit = false;

			DataView dvLogVendita  = new DataView(dsLogVendita.Tables[0]);
			dvLogVendita.Sort = "IdLog";
			dvLogVendita.AllowDelete = false;
			dvLogVendita.AllowNew = false;
			dvLogVendita.AllowEdit = false;

			dgLogOfferteAcquisto.DataSource = dvLogAcquisti;
			dgLogOfferteVendita.DataSource = dvLogVendita;
		}

		void SetDataGridMapping(bool bAcquisto)
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[13];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			int n = 0;

			dgCol[n].HeaderText = "IdLog";
			dgCol[n].MappingName = "IdLog";
			dgCol[n].Width = 200;
			dgCol[n].NullText = "";
			n++;

			dgCol[n].HeaderText = "Tipo operazione";
			dgCol[n].MappingName = "TipoOperazione";
			dgCol[n].Width = 150;
			dgCol[n].NullText = "";
			n++;

			dgCol[n].HeaderText = "Ragione sociale";
			dgCol[n].MappingName = "RagioneSociale";
			dgCol[n].Width = 150;
			dgCol[n].NullText = "";
			n++;

			dgCol[n].HeaderText = "Codice conto";
			dgCol[n].MappingName = "CodiceConto";
			dgCol[n].Width = 150;
			dgCol[n].NullText = "";
			n++;

			if (bAcquisto)
			{
				dgCol[n].HeaderText = "IdOfferta Acquisto";
				dgCol[n].MappingName = "IdOffertaAcquisto";
				dgCol[n].Width = 100;
				dgCol[n].NullText = "";
			}
			else
			{
				dgCol[n].HeaderText = "IdOfferta Vendita";
				dgCol[n].MappingName = "IdOffertaVendita";
				dgCol[n].Width = 100;
				dgCol[n].NullText = "";
			}
			n++;

			if (bAcquisto)
			{
				dgCol[n].HeaderText = "Quantit� Richiesta";
				dgCol[n].MappingName = "QtyRichiesta";
				dgCol[n].Width = 100;
				dgCol[n].NullText = "";
			}
			else
			{
				dgCol[n].HeaderText = "Quantit� Offerta";
				dgCol[n].MappingName = "QtyOfferta";
				dgCol[n].Width = 100;
				dgCol[n].NullText = "";
			}
			n++;

			dgCol[n].HeaderText = "Quantit� Residua";
			dgCol[n].MappingName = "QtyResidua";
			dgCol[n].Width = 100;
			dgCol[n].NullText = "";
			n++;

			dgCol[n].HeaderText = "Anno Riferimento";
			dgCol[n].MappingName = "AnnoRiferimento";
			dgCol[n].Width = 100;
			dgCol[n].NullText = "";
			n++;

			dgCol[n].HeaderText = "Prezzo Unitario";
			dgCol[n].MappingName = "PrezzoUnitario";
			dgCol[n].Width = 100;
			dgCol[n].Format = "c";
			dgCol[n].NullText = "";

			n++;

			dgCol[n].HeaderText = "Data/Ora Creazione";
			dgCol[n].MappingName = "DataOraCreazione";
			dgCol[n].Width = 100;
			dgCol[n].Format = "g";
			dgCol[n].NullText = "";
			n++;

			dgCol[n].HeaderText = "Data/Ora Modifica";
			dgCol[n].MappingName = "DataOraModifica";
			dgCol[n].Width = 100;
			dgCol[n].Format = "g";
			dgCol[n].NullText = "";
			n++;

			dgCol[n].HeaderText = "IdSessione";
			dgCol[n].MappingName = "IdSessione";
			dgCol[n].Width = 100;
			dgCol[n].NullText = "";
			n++;

			dgCol[n].HeaderText = "IdUtente";
			dgCol[n].MappingName = "IdUtente";
			dgCol[n].Width = 100;
			dgCol[n].NullText = "";
			n++;

			DataGridTableStyle dgStyle = new DataGridTableStyle();

			if (bAcquisto)
				dgStyle.MappingName = "RetrieveAcquisto";
			else
				dgStyle.MappingName = "RetrieveVendita";

			dgStyle.GridColumnStyles.AddRange(dgCol);

			if (bAcquisto)
				dgLogOfferteAcquisto.TableStyles.Add(dgStyle);
			else
				dgLogOfferteVendita.TableStyles.Add(dgStyle);
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLogOfferte));
			this.dlgEsportaXls = new System.Windows.Forms.SaveFileDialog();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.optOffertaVendita = new System.Windows.Forms.RadioButton();
			this.optOffertaAcquisto = new System.Windows.Forms.RadioButton();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label = new System.Windows.Forms.Label();
			this.edtRagioneSociale = new System.Windows.Forms.TextBox();
			this.edtAnno = new System.Windows.Forms.TextBox();
			this.edtCodiceConto = new System.Windows.Forms.TextBox();
			this.dgLogOfferteAcquisto = new System.Windows.Forms.DataGrid();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnEsportaExcel = new System.Windows.Forms.Button();
			this.dgLogOfferteVendita = new System.Windows.Forms.DataGrid();
			this.progressBar = new System.Windows.Forms.ProgressBar();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgLogOfferteAcquisto)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgLogOfferteVendita)).BeginInit();
			this.SuspendLayout();
			// 
			// dlgEsportaXls
			// 
			this.dlgEsportaXls.DefaultExt = "xls";
			this.dlgEsportaXls.Filter = "Excel files (*.xls)|*.xls";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.optOffertaVendita,
																					this.optOffertaAcquisto});
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Tipo operazione";
			// 
			// optOffertaVendita
			// 
			this.optOffertaVendita.Location = new System.Drawing.Point(16, 56);
			this.optOffertaVendita.Name = "optOffertaVendita";
			this.optOffertaVendita.TabIndex = 1;
			this.optOffertaVendita.Text = "Offerta Vendita";
			this.optOffertaVendita.CheckedChanged += new System.EventHandler(this.optOffertaAcquistoVendita_CheckedChanged);
			// 
			// optOffertaAcquisto
			// 
			this.optOffertaAcquisto.Location = new System.Drawing.Point(16, 24);
			this.optOffertaAcquisto.Name = "optOffertaAcquisto";
			this.optOffertaAcquisto.TabIndex = 0;
			this.optOffertaAcquisto.Text = "Offerta Acquisto";
			this.optOffertaAcquisto.CheckedChanged += new System.EventHandler(this.optOffertaAcquistoVendita_CheckedChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(224, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(136, 24);
			this.label1.TabIndex = 1;
			this.label1.Text = "Ragione sociale:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(224, 56);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(136, 24);
			this.label2.TabIndex = 2;
			this.label2.Text = "Anno:";
			// 
			// label
			// 
			this.label.Location = new System.Drawing.Point(224, 88);
			this.label.Name = "label";
			this.label.Size = new System.Drawing.Size(136, 24);
			this.label.TabIndex = 3;
			this.label.Text = "Codice conto:";
			// 
			// edtRagioneSociale
			// 
			this.edtRagioneSociale.Location = new System.Drawing.Point(368, 16);
			this.edtRagioneSociale.Name = "edtRagioneSociale";
			this.edtRagioneSociale.Size = new System.Drawing.Size(208, 20);
			this.edtRagioneSociale.TabIndex = 4;
			this.edtRagioneSociale.Text = "";
			this.edtRagioneSociale.TextChanged += new System.EventHandler(this.RowFilter_TextChanged);
			// 
			// edtAnno
			// 
			this.edtAnno.Location = new System.Drawing.Point(368, 48);
			this.edtAnno.Name = "edtAnno";
			this.edtAnno.Size = new System.Drawing.Size(208, 20);
			this.edtAnno.TabIndex = 5;
			this.edtAnno.Text = "";
			this.edtAnno.TextChanged += new System.EventHandler(this.RowFilter_TextChanged);
			// 
			// edtCodiceConto
			// 
			this.edtCodiceConto.Location = new System.Drawing.Point(368, 80);
			this.edtCodiceConto.Name = "edtCodiceConto";
			this.edtCodiceConto.Size = new System.Drawing.Size(208, 20);
			this.edtCodiceConto.TabIndex = 6;
			this.edtCodiceConto.Text = "";
			this.edtCodiceConto.TextChanged += new System.EventHandler(this.RowFilter_TextChanged);
			// 
			// dgLogOfferteAcquisto
			// 
			this.dgLogOfferteAcquisto.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.dgLogOfferteAcquisto.DataMember = "";
			this.dgLogOfferteAcquisto.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgLogOfferteAcquisto.Location = new System.Drawing.Point(8, 120);
			this.dgLogOfferteAcquisto.Name = "dgLogOfferteAcquisto";
			this.dgLogOfferteAcquisto.Size = new System.Drawing.Size(720, 288);
			this.dgLogOfferteAcquisto.TabIndex = 8;
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnChiudi.Location = new System.Drawing.Point(608, 416);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btnChiudi.Size = new System.Drawing.Size(120, 24);
			this.btnChiudi.TabIndex = 9;
			this.btnChiudi.Text = "Chiudi";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnEsportaExcel
			// 
			this.btnEsportaExcel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnEsportaExcel.Location = new System.Drawing.Point(472, 416);
			this.btnEsportaExcel.Name = "btnEsportaExcel";
			this.btnEsportaExcel.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btnEsportaExcel.Size = new System.Drawing.Size(120, 24);
			this.btnEsportaExcel.TabIndex = 10;
			this.btnEsportaExcel.Text = "Esporta Excel";
			this.btnEsportaExcel.Click += new System.EventHandler(this.btnEsportaExcel_Click);
			// 
			// dgLogOfferteVendita
			// 
			this.dgLogOfferteVendita.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.dgLogOfferteVendita.DataMember = "";
			this.dgLogOfferteVendita.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgLogOfferteVendita.Location = new System.Drawing.Point(592, 16);
			this.dgLogOfferteVendita.Name = "dgLogOfferteVendita";
			this.dgLogOfferteVendita.Size = new System.Drawing.Size(136, 96);
			this.dgLogOfferteVendita.TabIndex = 11;
			// 
			// progressBar
			// 
			this.progressBar.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.progressBar.Location = new System.Drawing.Point(8, 416);
			this.progressBar.Name = "progressBar";
			this.progressBar.Size = new System.Drawing.Size(448, 23);
			this.progressBar.TabIndex = 12;
			// 
			// frmLogOfferte
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(738, 455);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.progressBar,
																		  this.dgLogOfferteVendita,
																		  this.btnEsportaExcel,
																		  this.btnChiudi,
																		  this.dgLogOfferteAcquisto,
																		  this.edtCodiceConto,
																		  this.edtAnno,
																		  this.edtRagioneSociale,
																		  this.label,
																		  this.label2,
																		  this.label1,
																		  this.groupBox1});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimizeBox = false;
			this.Name = "frmLogOfferte";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Log Offerte";
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgLogOfferteAcquisto)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgLogOfferteVendita)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		static DataSet LogOfferte_RetrieveAcquisto(string IdSessione)
		{
			bool Cancelled = false;
			if (Cancelled)
			{
				CVAdmin_Main.CVAdimnWSBLLogOfferte.BLLogOfferte bl = new CVAdmin_Main.CVAdimnWSBLLogOfferte.BLLogOfferte();
				frmLogin.AddLoginInfo(bl);
				return bl.RetrieveAcquisto(IdSessione, "", "", "");
			}
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdimnWSBLLogOfferte.BLLogOfferte.RetrieveAcquisto", IdSessione, "", "", "");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}

		static DataSet LogOfferte_RetrieveVendita(string IdSessione)
		{
			bool Cancelled = false;
			if (Cancelled)
			{
				CVAdmin_Main.CVAdimnWSBLLogOfferte.BLLogOfferte bl = new CVAdmin_Main.CVAdimnWSBLLogOfferte.BLLogOfferte();
				frmLogin.AddLoginInfo(bl);
				return bl.RetrieveVendita(IdSessione, "", "", "");
			}
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdimnWSBLLogOfferte.BLLogOfferte.RetrieveVendita", IdSessione, "", "", "");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}

		void ExportaExcel(DataSet dsExport)
		{
			dlgEsportaXls.InitialDirectory = UtilityEnvironment.CommonAppDir;
			if (dlgEsportaXls.ShowDialog() != DialogResult.OK)
				return;

			this.Enabled = false;
			Application.DoEvents();
			this.Enabled = true;

			try
			{
				using (WaitCursor wc = new WaitCursor())
				{
					using (spApplication xlApp = new spApplication())
					{
						Excel.XlBordersIndex xlEdgeRight  = Excel.XlBordersIndex.xlEdgeRight;
						Excel.XlBordersIndex xlEdgeLeft   = Excel.XlBordersIndex.xlEdgeLeft;
						Excel.XlBordersIndex xlEdgeBottom = Excel.XlBordersIndex.xlEdgeBottom;
						Excel.XlBordersIndex xlEdgeTop    = Excel.XlBordersIndex.xlEdgeTop;

						Excel.XlHAlign xlHAlignGeneral    = Excel.XlHAlign.xlHAlignGeneral;

						string exportFileName = dlgEsportaXls.FileName;

						// xlApp.Visible = true;
						xlApp.SheetsInNewWorkbook = 1;

						spWorkbook xlBook = xlApp.Workbooks.Add();

						spWorksheet xlSheet = xlBook.Worksheets[1];
						xlSheet.Name = "Log Offerte";

						// 'Titolo
						// '--------------------------------------------
						xlSheet.Cells[1, 1].Characters.Font.Size = 11;
						xlSheet.Cells[1, 1].Characters.Font.Bold = true;
						xlSheet.Cells[1, 1].Value = "Transazioni";

						xlSheet.Cells.Range(xlSheet.Cells[1, 1], xlSheet.Cells[1, 5]).HorizontalAlignment = xlHAlignGeneral;// 3;
						xlSheet.Cells.Range(xlSheet.Cells[1, 1], xlSheet.Cells[1, 5]).Merge();

						// 'Riga Intestazione
						// '--------------------------------------------
						xlSheet.Cells.EntireRow[3].Characters.Font.Size = 10;
						xlSheet.Cells.EntireRow[3].Characters.Font.Bold = true;


						// 'Prima Colonna Intestazione
						// '--------------------------------------------
						xlSheet.Cells[3, 4].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 4].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 1].Borders[xlEdgeLeft].LineStyle = 7;
						xlSheet.Cells[3, 1].Borders[xlEdgeLeft].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 4]).HorizontalAlignment = xlHAlignGeneral; // 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 4]).Merge();
						xlSheet.Cells[3, 1].Value = "IdLog";

						// '--------------------------------------------
						xlSheet.Cells[3, 8].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 8].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 5].Borders[xlEdgeLeft].LineStyle = 7;
						xlSheet.Cells[3, 5].Borders[xlEdgeLeft].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 5], xlSheet.Cells[3, 8]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 5], xlSheet.Cells[3, 8]).Merge();
						xlSheet.Cells[3, 5].Value = "Tipo Operazione";

						// '--------------------------------------------
						xlSheet.Cells[3, 12].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 12].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 9].Borders[xlEdgeLeft].LineStyle = 7;
						xlSheet.Cells[3, 9].Borders[xlEdgeLeft].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 9], xlSheet.Cells[3, 12]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 9], xlSheet.Cells[3, 12]).Merge();
						xlSheet.Cells[3, 9].Value = "Ragione Sociale";

						// '--------------------------------------------
						xlSheet.Cells[3, 14].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 14].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 13].Borders[xlEdgeLeft].LineStyle = 7;
						xlSheet.Cells[3, 13].Borders[xlEdgeLeft].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 13], xlSheet.Cells[3, 14]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 13], xlSheet.Cells[3, 14]).Merge();
						xlSheet.Cells[3, 13].Value = "Codice Conto";

						// Seconda Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 18].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 18].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 15].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 15].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 15], xlSheet.Cells[3, 18]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 15], xlSheet.Cells[3, 18]).Merge();
						if (optOffertaAcquisto.Checked)
							xlSheet.Cells[3, 15].Value = "Offerta Acquisto";
						else if (optOffertaVendita.Checked)
							xlSheet.Cells[3, 15].Value = "Offerta Vendita";


						// 'Terza Colonna Intestazione
						// '--------------------------------------------
						xlSheet.Cells[3, 22].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 22].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 19].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 19].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 19], xlSheet.Cells[3, 22]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 19], xlSheet.Cells[3, 22]).Merge();

						if (optOffertaAcquisto.Checked)
							xlSheet.Cells[3, 19].Value = "Qty Richiesta";
						if (optOffertaVendita.Checked)
							xlSheet.Cells[3, 19].Value = "Qty Offerta";
    
						// 'Quarta Colonna Intestazione
						// '--------------------------------------------
						xlSheet.Cells[3, 26].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 26].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 23].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 23].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 23], xlSheet.Cells[3, 26]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 23], xlSheet.Cells[3, 26]).Merge();
						xlSheet.Cells[3, 23].Value = "Qty Residua";


						// 'Quinta Colonna Intestazione
						// '--------------------------------------------
						xlSheet.Cells[3, 29].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 29].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 27].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 27].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 27], xlSheet.Cells[3, 29]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 27], xlSheet.Cells[3, 29]).Merge();
						xlSheet.Cells[3, 27].Value = "Anno Riferimento";


						//'Sesta Colonna Intestazione
						//'--------------------------------------------
						xlSheet.Cells[3, 32].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 32].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 30].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 30].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 30], xlSheet.Cells[3, 32]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 30], xlSheet.Cells[3, 32]).Merge();
						xlSheet.Cells[3, 30].Value = "Prezzo Unitario";

						//'Settima Colonna Intestazione
						//'--------------------------------------------
						xlSheet.Cells[3, 35].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 35].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 33].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 33].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 33], xlSheet.Cells[3, 35]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 33], xlSheet.Cells[3, 35]).Merge();
						xlSheet.Cells[3,33].Value = "Data Ora Creazione";

						xlSheet.Cells[3, 38].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 38].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 36].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 36].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 36], xlSheet.Cells[3, 38]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 36], xlSheet.Cells[3, 38]).Merge();
						xlSheet.Cells[3, 36].Value = "Data Ora Modifica";

						xlSheet.Cells[3, 42].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 42].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 39].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 39].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 39], xlSheet.Cells[3, 42]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 39], xlSheet.Cells[3, 42]).Merge();
						xlSheet.Cells[3, 39].Value = "IdSessione";

						xlSheet.Cells[3, 46].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 46].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 43].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 43].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 43], xlSheet.Cells[3, 46]).HorizontalAlignment = xlHAlignGeneral;//3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 43], xlSheet.Cells[3, 46]).Merge();
						xlSheet.Cells[3, 43].Value = "IdUtente";

						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 46]).Borders[xlEdgeBottom].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 46]).Borders[xlEdgeTop].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 46]).Borders[xlEdgeBottom].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 46]).Borders[xlEdgeTop].Weight = 3;


						// 'Righe Dati
						int i = 3;
    
						foreach (DataRow drExport in  dsExport.Tables[0].Rows)
						{
							progressBar.Increment(1);

							i = i + 1;
  
							xlSheet.Cells.EntireRow[i].Characters.Font.Size = 8;
							xlSheet.Cells.EntireRow[i].Characters.Font.Bold = false;

							xlSheet.Cells[i, 1].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 1].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[i, 4].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 4].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 1], xlSheet.Cells[i, 4]).Merge();
							xlSheet.Cells[i, 1].Value = Converter.StringToString(drExport, "IdLog");

							xlSheet.Cells[i, 5].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 5].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells[i, 8].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 8].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 5], xlSheet.Cells[i, 8]).Merge();
							xlSheet.Cells[i, 5].Value = Converter.StringToString(drExport, "TipoOperazione");

							xlSheet.Cells[i, 9].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 9].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells[i, 12].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 12].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 9], xlSheet.Cells[i, 12]).Merge();
							xlSheet.Cells[i, 9].Value = Converter.StringToString(drExport, "RagioneSociale");

							xlSheet.Cells[i, 13].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 13].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells[i, 14].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 14].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 13], xlSheet.Cells[i, 14]).Merge();
							xlSheet.Cells[i, 13].Value = Converter.StringToString(drExport, "CodiceConto");

							xlSheet.Cells[i, 15].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 15].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[i, 18].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 18].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 15], xlSheet.Cells[i, 18]).Merge();
							if (optOffertaAcquisto.Checked)
								xlSheet.Cells[i, 15].Value = Converter.StringToString(drExport, "IdOffertaAcquisto");
							else
								xlSheet.Cells[i, 15].Value = Converter.StringToString(drExport, "IdOffertaVendita");


							xlSheet.Cells[i, 22].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 22].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[i, 19].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 19].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 19], xlSheet.Cells[i, 22]).Merge();
							if (optOffertaAcquisto.Checked)
								xlSheet.Cells[i, 19].Value = Converter.DecimalToIntegerString(drExport, "QtyRichiesta");
							else
								xlSheet.Cells[i, 19].Value = Converter.DecimalToIntegerString(drExport, "QtyOfferta");


							xlSheet.Cells[i, 23].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 23].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[i, 26].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 26].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 23], xlSheet.Cells[i, 26]).Merge();
							xlSheet.Cells[i, 23].Value = Converter.DecimalToIntegerString(drExport, "QtyResidua");


							xlSheet.Cells[i, 29].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 29].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells[i, 27].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 27].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 27], xlSheet.Cells[i, 29]).Merge();
							xlSheet.Cells[i, 27].Value = Converter.StringToString(drExport, "AnnoRiferimento");


							xlSheet.Cells[i, 32].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 32].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells[i, 30].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 30].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 30], xlSheet.Cells[i, 32]).Merge();
							xlSheet.Cells[i, 30].Value = Converter.DecimalToCurrencyString(drExport,"PrezzoUnitario");


							xlSheet.Cells[i, 35].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 35].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[i, 33].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 33].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 33], xlSheet.Cells[i, 35]).Merge();
							xlSheet.Cells[i, 33].Value = Converter.DateTimeToStringDateTime(drExport, "DataOraCreazione");


							xlSheet.Cells[i, 36].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 36].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[i, 38].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 38].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 36], xlSheet.Cells[i, 38]).Merge();
							xlSheet.Cells[i, 36].Value = Converter.DateTimeToStringDateTime(drExport, "DataOraModifica");
							    

							xlSheet.Cells[i, 39].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 39].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[i, 42].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 42].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 39], xlSheet.Cells[i, 42]).Merge();
							xlSheet.Cells[i, 39].Value = Converter.StringToString(drExport, "IdSessione");

							xlSheet.Cells[i, 43].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[i, 43].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[i, 46].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[i, 46].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[i, 43], xlSheet.Cells[i, 46]).Merge();
							xlSheet.Cells[i, 43].Value = Converter.StringToString(drExport, "IdUtente");

							xlSheet.Cells.Range(xlSheet.Cells[i, 1], xlSheet.Cells[i, 46]).Borders[xlEdgeBottom].LineStyle = 7;
							xlSheet.Cells.Range(xlSheet.Cells[i, 1], xlSheet.Cells[i, 46]).Borders[xlEdgeBottom].Weight = 3;
						}

						for (int X = 1; X <= 46; ++X)
							xlSheet.Cells.EntireColumn[X].Resize.AutoFit();

						try { System.IO.File.Delete(exportFileName); } 
						catch (Exception) {} // eccezione se il file non esiste
						xlSheet.SaveAs(exportFileName);
						xlBook.Close();
						xlApp.Quit();
					}
				}
				MessageBox.Show("Foglio Excel generato con successo", "Messaggio");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void optOffertaAcquistoVendita_CheckedChanged(object sender, System.EventArgs e)
		{
			if (optOffertaAcquisto.Checked)
			{
				dgLogOfferteAcquisto.Visible = true;
				dgLogOfferteVendita.Visible = false;
			}
			else
			{
				dgLogOfferteAcquisto.Visible = false;
				dgLogOfferteVendita.Visible = true;
			}
		}

		private void RowFilter_TextChanged(object sender, System.EventArgs e)
		{
			string [] f = new string[3];

			if (edtRagioneSociale.Text.Length > 0)
				f[0] = "RagioneSociale LIKE '" + edtRagioneSociale.Text + "%' ";

			if (edtCodiceConto.Text.Length > 0)
				f[1] = "CodiceConto LIKE '" + edtCodiceConto.Text + "%' ";

			if (edtAnno.Text.Length > 0)
				f[2] = "AnnoRiferimento LIKE '" + edtAnno.Text + "%' ";



			string filter = "";
			foreach (string s in f)
			{
				if (s == null)
					continue;

				if (filter.Length > 0)
					filter += " AND ";

				filter += "(" + s + ")";
			}

			DataView dvA = dgLogOfferteAcquisto.DataSource as DataView;
			DataView dvV = dgLogOfferteVendita.DataSource as DataView;

			dvA.RowFilter = filter;
			dvV.RowFilter = filter;
		}

		private void btnEsportaExcel_Click(object sender, System.EventArgs e)
		{
			DataView dv;

			if (optOffertaAcquisto.Checked)
				dv = dgLogOfferteAcquisto.DataSource as DataView;
			else
				dv = dgLogOfferteVendita.DataSource as DataView;

			DataSet ds = new DataSet();

			DataTable dt = dv.Table.Clone();
			ds.Tables.Add(dt);

			for (int i = 0; i < dv.Count; ++i)
			{
				DataRow ro = dt.NewRow();
				DataRow ri = dv[i].Row;
				for (int c = 0; c < dt.Columns.Count; ++c)
					ro[c] = ri[c];
				dt.Rows.Add(ro);
			}

			progressBar.Minimum = 0;
			progressBar.Maximum = dv.Count;
			progressBar.Visible = true;

			ExportaExcel(ds);

			progressBar.Visible = false;
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}
	}
}
