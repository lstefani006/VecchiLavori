using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmSocietaUtenti.
	/// </summary>
	public class frmSocietaUtenti : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.GroupBox gbUtente;
		private System.Windows.Forms.TextBox tbCodiceFiscale;
		private System.Windows.Forms.Label lblCodiceFiscale;
		private System.Windows.Forms.TextBox tbNominativo;
		private System.Windows.Forms.Label lblNominativo;
		private System.Windows.Forms.TabControl tcSocietaUtenti;
		private System.Windows.Forms.TabPage tpSocieta;
		private System.Windows.Forms.TabPage tpUtenti;
		private System.Windows.Forms.DataGrid dgUtenti;
		private System.Windows.Forms.DataGrid dgSocieta;
		private System.Windows.Forms.GroupBox gbSocieta;
		private System.Windows.Forms.TextBox tbCC;
		private System.Windows.Forms.Label lblCC;
		private System.Windows.Forms.TextBox tbCAB;
		private System.Windows.Forms.Label lblCAB;
		private System.Windows.Forms.TextBox tbABI;
		private System.Windows.Forms.Label lblABI;
		private System.Windows.Forms.TextBox tbPartitaIVA;
		private System.Windows.Forms.Label lblPartitaIVA;
		private System.Windows.Forms.TextBox tbRagioneSociale;
		private System.Windows.Forms.Label lblRagioneSociale;


		private DataSet		_dsListaSocietaUtenti = null;
		private DataView	_dvSocieta = null;
		private DataView	_dvUtenti = null;
		private System.Windows.Forms.ToolTip tltInfo;
		private System.Windows.Forms.Label lblCodiceConto;
		private System.Windows.Forms.TextBox tbCodiceConto;
		private System.Windows.Forms.Label lblCodConto;
		private System.Windows.Forms.TextBox tbCodConto;
		private System.Windows.Forms.Button btnStorico;
		private System.Windows.Forms.Button btnStoricoSoc;
		private System.ComponentModel.IContainer components;

		public frmSocietaUtenti()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			_dsListaSocietaUtenti = GetListaSocietaUtenti();
			if (_dsListaSocietaUtenti == null)
			{
				DisabilitaComponenti();
				return;
			}
			BindComponents();
			SetDataGridMappingSocieta();
			SetDataGridMappingUtenti();
			InizializzaStorico();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		private void DisabilitaComponenti()
		{
			tcSocietaUtenti.Enabled = false;
			// Il bottone "Chiudi" DEVE rimanere abilitato
			// per permettere l'uscita dalla Form
			btnChiudi.Enabled = true;
		}

		private void ChangeFilterDataGridSocieta()
		{
			string filter = null;

			filter = "RagioneSociale LIKE '" + tbRagioneSociale.Text + "%' ";
			filter += "AND PartitaIVA LIKE '" + tbPartitaIVA.Text + "%' ";
			filter += "AND ABI LIKE '" + tbABI.Text + "%' ";
			filter += "AND CAB LIKE '" + tbCAB.Text + "%' ";
			filter += "AND CC LIKE '" + tbCC.Text + "%' ";
			filter += "AND CodiceConto LIKE '" + tbCodiceConto.Text + "%' ";

			if (filter != String.Empty)
			{
				_dvSocieta.RowFilter = filter;
			}
		}

		private void ChangeFilterDataGridUtenti()
		{
			string filter = null;

			filter = "Nominativo LIKE '" + tbNominativo.Text + "%' ";
			filter += "AND CodiceFiscale LIKE '" + tbCodiceFiscale.Text + "%' ";
			filter += "AND CodiceConto LIKE '" + tbCodConto.Text + "%'";
			if (filter != String.Empty)
			{
				_dvUtenti.RowFilter = filter;
			}
		}

		private void BindComponents()
		{
			_dvSocieta = new DataView(_dsListaSocietaUtenti.Tables[0]);  
			_dvSocieta.AllowDelete	= false;
			_dvSocieta.AllowNew		= false;
			_dvSocieta.AllowEdit	= false;

			_dvUtenti  = new DataView(_dsListaSocietaUtenti.Tables[1]);
			_dvUtenti.AllowDelete	= false;
			_dvUtenti.AllowNew		= false;
			_dvUtenti.AllowEdit		= false;
			
			dgSocieta.DataSource = _dvSocieta;
			dgUtenti.DataSource	 = _dvUtenti;
		}

		public static bool AggiornaDataSetSocieta(DataSet ds, string IdSocieta)
		{
			// Verifico se sono state effettuate delle modifiche alle tabelle del DataSet
			if (!ds.HasChanges()) 
			{
				ds.AcceptChanges();
				return true;
			}

			DataSet xDataSet;
			// GetChanges solo per le righe modificate
			xDataSet = ds.GetChanges();
			if (xDataSet == null)
			{
				ds.AcceptChanges();
				return true;
			}

			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.Update", ds, IdSocieta);
			if (Cancelled)
				return false;

			// il Web Service ha risposto... prendo il risultato
			DataSet dsUpdated = (DataSet)ret;
			if (dsUpdated != null)
			{
				ds.AcceptChanges();
				return true;
			}
			else
			{
				ds.RejectChanges();
				return false;
			}
		}

		public static bool AggiornaDataSetUtenti(DataSet ds, string IdUtente)
		{
			// Verifico se sono state effettuate delle modifiche alle tabelle del DataSet
			if (!ds.HasChanges()) 
			{
				ds.AcceptChanges();
				return true;
			}

			DataSet xDataSet;
			// GetChanges solo per le righe modificate
			xDataSet = ds.GetChanges();
			if (xDataSet == null)
			{
				ds.AcceptChanges();
				return true;
			}

			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLUtenti.BLUtenti.Update", ds, IdUtente);
			if (Cancelled)
				return false;

			// il Web Service ha risposto... prendo il risultato
			DataSet dsUpdated = (DataSet)ret;
			if (dsUpdated != null)
			{
				ds.AcceptChanges();
				return true;
			}
			else
			{
				ds.RejectChanges();
				return false;
			}
		}

		#region Mapping colonne DataGrid
		private void SetDataGridMappingSocieta()
		{
			// Mapping delle colonne tra il DataTable delle Transazioni e le colonne
			// del DataGrid
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[8];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			int index = 0;

			// Colonna 0
			dgCol[index].HeaderText  = "Ragione Sociale";
			dgCol[index].MappingName = "RagioneSociale";
			dgCol[index].Width = 210;

			// Colonna 1
			index++;
			dgCol[index].HeaderText  = "Indirizzo Societ�";
			dgCol[index].MappingName = "Indirizzo";
			dgCol[index].Width = 210;

			// Colonna 2
			index++;
			dgCol[index].HeaderText  = "Citt�";
			dgCol[index].MappingName = "Citta";
			dgCol[index].Width = 210;

			// Colonna 3
			index++;
			dgCol[index].HeaderText  = "Partita IVA";
			dgCol[index].MappingName = "PartitaIVA";
			dgCol[index].Width = 210;

			// Colonna 4
			index++;
			dgCol[index].HeaderText  = "ABI";
			dgCol[index].MappingName = "ABI";
			dgCol[index].Width = 210;

			// Colonna 5
			index++;
			dgCol[index].HeaderText  = "CAB";
			dgCol[index].MappingName = "CAB";
			dgCol[index].Width = 210;

			// Colonna 6
			index++;
			dgCol[index].HeaderText  = "CC";
			dgCol[index].MappingName = "CC";
			dgCol[index].Width = 210;

			// Colonna 7
			index++;
			dgCol[index].HeaderText  = "Codice Conto";
			dgCol[index].MappingName = "CodiceConto";
			dgCol[index].Width = 210;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Societa";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgSocieta.TableStyles.Add(dgStyle);
		}

		private void SetDataGridMappingUtenti()
		{
			// Mapping delle colonne tra il DataTable delle Transazioni e le colonne
			// del DataGrid
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[6];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			int index = 0;
			// Colonna 0
			dgCol[index].HeaderText = "Nominativo";
			dgCol[index].MappingName = "Nominativo";
			dgCol[index].Width = 210;

			index++;
			// Colonna 1
			dgCol[index].HeaderText = "Codice Fiscale";
			dgCol[index].MappingName = "CodiceFiscale";
			dgCol[index].Width = 210;

			index++;
			// Colonna 2
			dgCol[index].HeaderText = "Telefono";
			dgCol[index].MappingName = "Telefono";
			dgCol[index].Width = 210;

			// Colonna 3
			index++;
			dgCol[index].HeaderText = "FAX";
			dgCol[index].MappingName = "Fax";
			dgCol[index].Width = 210;

			// Colonna 4
			index++;
			dgCol[index].HeaderText = "Societa`";
			dgCol[index].MappingName = "RagioneSociale";
			dgCol[index].Width = 210;

			// Colonna 5
			index++;
			dgCol[index].HeaderText = "Codice Conto societa`";
			dgCol[index].MappingName = "CodiceConto";
			dgCol[index].Width = 210;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Utenti";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgUtenti.TableStyles.Add(dgStyle);
		}

#endregion
		
		private void Chiudi()
		{
			this.DialogResult = DialogResult.Cancel;
		}

		public DataRow CurrentRowSocieta
		{
			get 
			{
				DataTable dt = CurrentDataTableSocieta;

				BindingManagerBase bm = dgSocieta.BindingContext[dgSocieta.DataSource, dgSocieta.DataMember]; 
				if (bm.Count == 0) // numero di righe = 0
					return null;

				DataRow dr = ((DataRowView)bm.Current).Row; 
				return dr;
			}
		}

		/// <summary>
		/// ritorna l'unica (in questo caso) tabella attaccata al DataGrid
		/// </summary>
		public DataTable CurrentDataTableSocieta
		{
			get
			{
				// un po' di if per ottenere il dataset
				// posso cosi' associare il ds o il dv alla griglia

				object obj = dgSocieta.DataSource;
				DataTable dt = null;
				if (obj is DataSet)
				{
					Debug.Assert(((DataSet)obj).Tables.Count == 1);
					dt = ((DataSet)obj).Tables["Societa"];
				}
				else if (obj is DataView)
				{
					dt = ((DataView)obj).Table;
				}
				else if (obj == null)
					return null;
				else
					Debug.Assert(false, "puoi mettere come DataSource un DataView o un DataTable");

				return dt;
			}
		}

		public DataRow CurrentRowUtenti
		{
			get 
			{
				DataTable dt = CurrentDataTableUtenti;

				BindingManagerBase bm = dgUtenti.BindingContext[dgUtenti.DataSource, dgUtenti.DataMember]; 
				if (bm.Count == 0) // numero di righe = 0
					return null;

				DataRow dr = ((DataRowView)bm.Current).Row; 
				return dr;
			}
		}

		/// <summary>
		/// ritorna l'unica (in questo caso) tabella attaccata al DataGrid
		/// </summary>
		public DataTable CurrentDataTableUtenti
		{
			get
			{
				// un po' di if per ottenere il dataset
				// posso cosi' associare il ds o il dv alla griglia

				object obj = dgSocieta.DataSource;
				DataTable dt = null;
				if (obj is DataSet)
				{
					Debug.Assert(((DataSet)obj).Tables.Count == 1);
					dt = ((DataSet)obj).Tables["Utenti"];
				}
				else if (obj is DataView)
				{
					dt = ((DataView)obj).Table;
				}
				else if (obj == null)
					return null;
				else
					Debug.Assert(false, "puoi mettere come DataSource un DataView o un DataTable");

				return dt;
			}
		}

		#region Chiamata ai Web Services

		private DataSet GetListaSocietaUtenti()
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.Retrieve_SocietaUtenti");

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		private void InizializzaStorico()
		{
			bool Cancelled;
			frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.InizializzaStorico");

			if (Cancelled)
				return ;
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSocietaUtenti));
			this.btnChiudi = new System.Windows.Forms.Button();
			this.tcSocietaUtenti = new System.Windows.Forms.TabControl();
			this.tpSocieta = new System.Windows.Forms.TabPage();
			this.dgSocieta = new System.Windows.Forms.DataGrid();
			this.gbSocieta = new System.Windows.Forms.GroupBox();
			this.btnStoricoSoc = new System.Windows.Forms.Button();
			this.tbCodiceConto = new System.Windows.Forms.TextBox();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.tbCC = new System.Windows.Forms.TextBox();
			this.lblCC = new System.Windows.Forms.Label();
			this.tbCAB = new System.Windows.Forms.TextBox();
			this.lblCAB = new System.Windows.Forms.Label();
			this.tbABI = new System.Windows.Forms.TextBox();
			this.lblABI = new System.Windows.Forms.Label();
			this.tbPartitaIVA = new System.Windows.Forms.TextBox();
			this.lblPartitaIVA = new System.Windows.Forms.Label();
			this.tbRagioneSociale = new System.Windows.Forms.TextBox();
			this.lblRagioneSociale = new System.Windows.Forms.Label();
			this.tpUtenti = new System.Windows.Forms.TabPage();
			this.dgUtenti = new System.Windows.Forms.DataGrid();
			this.gbUtente = new System.Windows.Forms.GroupBox();
			this.btnStorico = new System.Windows.Forms.Button();
			this.tbCodConto = new System.Windows.Forms.TextBox();
			this.lblCodConto = new System.Windows.Forms.Label();
			this.tbCodiceFiscale = new System.Windows.Forms.TextBox();
			this.lblCodiceFiscale = new System.Windows.Forms.Label();
			this.tbNominativo = new System.Windows.Forms.TextBox();
			this.lblNominativo = new System.Windows.Forms.Label();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.tcSocietaUtenti.SuspendLayout();
			this.tpSocieta.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgSocieta)).BeginInit();
			this.gbSocieta.SuspendLayout();
			this.tpUtenti.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgUtenti)).BeginInit();
			this.gbUtente.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChiudi.Location = new System.Drawing.Point(740, 404);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 3;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa finestra");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// tcSocietaUtenti
			// 
			this.tcSocietaUtenti.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tcSocietaUtenti.Controls.Add(this.tpSocieta);
			this.tcSocietaUtenti.Controls.Add(this.tpUtenti);
			this.tcSocietaUtenti.Location = new System.Drawing.Point(4, 4);
			this.tcSocietaUtenti.Name = "tcSocietaUtenti";
			this.tcSocietaUtenti.SelectedIndex = 0;
			this.tcSocietaUtenti.Size = new System.Drawing.Size(828, 396);
			this.tcSocietaUtenti.TabIndex = 4;
			// 
			// tpSocieta
			// 
			this.tpSocieta.Controls.Add(this.dgSocieta);
			this.tpSocieta.Controls.Add(this.gbSocieta);
			this.tpSocieta.Location = new System.Drawing.Point(4, 22);
			this.tpSocieta.Name = "tpSocieta";
			this.tpSocieta.Size = new System.Drawing.Size(820, 370);
			this.tpSocieta.TabIndex = 0;
			this.tpSocieta.Text = "Societ�";
			// 
			// dgSocieta
			// 
			this.dgSocieta.AllowNavigation = false;
			this.dgSocieta.AllowSorting = false;
			this.dgSocieta.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgSocieta.CaptionText = "Risultato Ricerca";
			this.dgSocieta.DataMember = "";
			this.dgSocieta.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgSocieta.Location = new System.Drawing.Point(0, 178);
			this.dgSocieta.Name = "dgSocieta";
			this.dgSocieta.Size = new System.Drawing.Size(820, 190);
			this.dgSocieta.TabIndex = 4;
			this.tltInfo.SetToolTip(this.dgSocieta, "Lista Societ�");
			this.dgSocieta.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgSocieta_MouseDown);
			this.dgSocieta.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgSocieta_MouseUp);
			// 
			// gbSocieta
			// 
			this.gbSocieta.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
			this.gbSocieta.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbSocieta.Controls.Add(this.btnStoricoSoc);
			this.gbSocieta.Controls.Add(this.tbCodiceConto);
			this.gbSocieta.Controls.Add(this.lblCodiceConto);
			this.gbSocieta.Controls.Add(this.tbCC);
			this.gbSocieta.Controls.Add(this.lblCC);
			this.gbSocieta.Controls.Add(this.tbCAB);
			this.gbSocieta.Controls.Add(this.lblCAB);
			this.gbSocieta.Controls.Add(this.tbABI);
			this.gbSocieta.Controls.Add(this.lblABI);
			this.gbSocieta.Controls.Add(this.tbPartitaIVA);
			this.gbSocieta.Controls.Add(this.lblPartitaIVA);
			this.gbSocieta.Controls.Add(this.tbRagioneSociale);
			this.gbSocieta.Controls.Add(this.lblRagioneSociale);
			this.gbSocieta.Location = new System.Drawing.Point(2, 4);
			this.gbSocieta.Name = "gbSocieta";
			this.gbSocieta.Size = new System.Drawing.Size(818, 172);
			this.gbSocieta.TabIndex = 3;
			this.gbSocieta.TabStop = false;
			this.gbSocieta.Text = " Criteri di Ricerca ";
			// 
			// btnStoricoSoc
			// 
			this.btnStoricoSoc.Location = new System.Drawing.Point(712, 16);
			this.btnStoricoSoc.Name = "btnStoricoSoc";
			this.btnStoricoSoc.Size = new System.Drawing.Size(100, 23);
			this.btnStoricoSoc.TabIndex = 19;
			this.btnStoricoSoc.Text = "Storico &Modifiche";
			this.btnStoricoSoc.Click += new System.EventHandler(this.btnStoricoSoc_Click);
			// 
			// tbCodiceConto
			// 
			this.tbCodiceConto.Location = new System.Drawing.Point(96, 144);
			this.tbCodiceConto.Name = "tbCodiceConto";
			this.tbCodiceConto.Size = new System.Drawing.Size(168, 20);
			this.tbCodiceConto.TabIndex = 6;
			this.tbCodiceConto.Text = "";
			this.tltInfo.SetToolTip(this.tbCodiceConto, "Filtra per CodiceConto");
			this.tbCodiceConto.TextChanged += new System.EventHandler(this.tbCodiceConto_TextChanged);
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Location = new System.Drawing.Point(8, 144);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(80, 16);
			this.lblCodiceConto.TabIndex = 10;
			this.lblCodiceConto.Text = "Codice Conto";
			// 
			// tbCC
			// 
			this.tbCC.Location = new System.Drawing.Point(96, 120);
			this.tbCC.Name = "tbCC";
			this.tbCC.Size = new System.Drawing.Size(168, 20);
			this.tbCC.TabIndex = 5;
			this.tbCC.Text = "";
			this.tltInfo.SetToolTip(this.tbCC, "Filtra per CC");
			this.tbCC.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblCC
			// 
			this.lblCC.Location = new System.Drawing.Point(8, 120);
			this.lblCC.Name = "lblCC";
			this.lblCC.Size = new System.Drawing.Size(24, 16);
			this.lblCC.TabIndex = 8;
			this.lblCC.Text = "CC";
			// 
			// tbCAB
			// 
			this.tbCAB.Location = new System.Drawing.Point(96, 96);
			this.tbCAB.Name = "tbCAB";
			this.tbCAB.Size = new System.Drawing.Size(168, 20);
			this.tbCAB.TabIndex = 4;
			this.tbCAB.Text = "";
			this.tltInfo.SetToolTip(this.tbCAB, "Filtra per CAB");
			this.tbCAB.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblCAB
			// 
			this.lblCAB.Location = new System.Drawing.Point(8, 96);
			this.lblCAB.Name = "lblCAB";
			this.lblCAB.Size = new System.Drawing.Size(48, 16);
			this.lblCAB.TabIndex = 6;
			this.lblCAB.Text = "CAB";
			// 
			// tbABI
			// 
			this.tbABI.Location = new System.Drawing.Point(96, 72);
			this.tbABI.Name = "tbABI";
			this.tbABI.Size = new System.Drawing.Size(168, 20);
			this.tbABI.TabIndex = 3;
			this.tbABI.Text = "";
			this.tltInfo.SetToolTip(this.tbABI, "Filtra per ABI");
			this.tbABI.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblABI
			// 
			this.lblABI.Location = new System.Drawing.Point(8, 72);
			this.lblABI.Name = "lblABI";
			this.lblABI.Size = new System.Drawing.Size(32, 16);
			this.lblABI.TabIndex = 4;
			this.lblABI.Text = "ABI";
			// 
			// tbPartitaIVA
			// 
			this.tbPartitaIVA.Location = new System.Drawing.Point(96, 48);
			this.tbPartitaIVA.Name = "tbPartitaIVA";
			this.tbPartitaIVA.Size = new System.Drawing.Size(168, 20);
			this.tbPartitaIVA.TabIndex = 2;
			this.tbPartitaIVA.Text = "";
			this.tltInfo.SetToolTip(this.tbPartitaIVA, "Filtra per Partita IVA");
			this.tbPartitaIVA.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblPartitaIVA
			// 
			this.lblPartitaIVA.Location = new System.Drawing.Point(8, 48);
			this.lblPartitaIVA.Name = "lblPartitaIVA";
			this.lblPartitaIVA.Size = new System.Drawing.Size(64, 16);
			this.lblPartitaIVA.TabIndex = 2;
			this.lblPartitaIVA.Text = "Partita IVA";
			// 
			// tbRagioneSociale
			// 
			this.tbRagioneSociale.Location = new System.Drawing.Point(96, 24);
			this.tbRagioneSociale.Name = "tbRagioneSociale";
			this.tbRagioneSociale.Size = new System.Drawing.Size(312, 20);
			this.tbRagioneSociale.TabIndex = 1;
			this.tbRagioneSociale.Text = "";
			this.tltInfo.SetToolTip(this.tbRagioneSociale, "Filtra per Ragione Sociale");
			this.tbRagioneSociale.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblRagioneSociale
			// 
			this.lblRagioneSociale.Location = new System.Drawing.Point(8, 24);
			this.lblRagioneSociale.Name = "lblRagioneSociale";
			this.lblRagioneSociale.Size = new System.Drawing.Size(88, 16);
			this.lblRagioneSociale.TabIndex = 0;
			this.lblRagioneSociale.Text = "Ragione Sociale";
			// 
			// tpUtenti
			// 
			this.tpUtenti.Controls.Add(this.dgUtenti);
			this.tpUtenti.Controls.Add(this.gbUtente);
			this.tpUtenti.Location = new System.Drawing.Point(4, 22);
			this.tpUtenti.Name = "tpUtenti";
			this.tpUtenti.Size = new System.Drawing.Size(820, 370);
			this.tpUtenti.TabIndex = 1;
			this.tpUtenti.Text = "Utenti";
			// 
			// dgUtenti
			// 
			this.dgUtenti.AllowDrop = true;
			this.dgUtenti.AllowNavigation = false;
			this.dgUtenti.AllowSorting = false;
			this.dgUtenti.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgUtenti.CaptionText = "Risultato Ricerca";
			this.dgUtenti.DataMember = "";
			this.dgUtenti.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgUtenti.Location = new System.Drawing.Point(0, 92);
			this.dgUtenti.Name = "dgUtenti";
			this.dgUtenti.Size = new System.Drawing.Size(820, 276);
			this.dgUtenti.TabIndex = 4;
			this.tltInfo.SetToolTip(this.dgUtenti, "Lista Utenti");
			this.dgUtenti.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgUtenti_MouseDown);
			this.dgUtenti.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgSocieta_MouseUp);
			// 
			// gbUtente
			// 
			this.gbUtente.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbUtente.Controls.Add(this.btnStorico);
			this.gbUtente.Controls.Add(this.tbCodConto);
			this.gbUtente.Controls.Add(this.lblCodConto);
			this.gbUtente.Controls.Add(this.tbCodiceFiscale);
			this.gbUtente.Controls.Add(this.lblCodiceFiscale);
			this.gbUtente.Controls.Add(this.tbNominativo);
			this.gbUtente.Controls.Add(this.lblNominativo);
			this.gbUtente.Location = new System.Drawing.Point(2, 4);
			this.gbUtente.Name = "gbUtente";
			this.gbUtente.Size = new System.Drawing.Size(818, 84);
			this.gbUtente.TabIndex = 3;
			this.gbUtente.TabStop = false;
			this.gbUtente.Text = " Criteri di Ricerca ";
			// 
			// btnStorico
			// 
			this.btnStorico.Location = new System.Drawing.Point(712, 16);
			this.btnStorico.Name = "btnStorico";
			this.btnStorico.Size = new System.Drawing.Size(100, 23);
			this.btnStorico.TabIndex = 13;
			this.btnStorico.Text = "Storico &Modifiche";
			this.btnStorico.Click += new System.EventHandler(this.btnStorico_Click);
			// 
			// tbCodConto
			// 
			this.tbCodConto.Location = new System.Drawing.Point(96, 58);
			this.tbCodConto.Name = "tbCodConto";
			this.tbCodConto.Size = new System.Drawing.Size(168, 20);
			this.tbCodConto.TabIndex = 12;
			this.tbCodConto.Text = "";
			this.tltInfo.SetToolTip(this.tbCodConto, "Filtra per CodiceConto");
			this.tbCodConto.TextChanged += new System.EventHandler(this.tbCodConto_TextChanged);
			// 
			// lblCodConto
			// 
			this.lblCodConto.Location = new System.Drawing.Point(8, 64);
			this.lblCodConto.Name = "lblCodConto";
			this.lblCodConto.Size = new System.Drawing.Size(80, 16);
			this.lblCodConto.TabIndex = 11;
			this.lblCodConto.Text = "Codice Conto";
			// 
			// tbCodiceFiscale
			// 
			this.tbCodiceFiscale.Location = new System.Drawing.Point(96, 37);
			this.tbCodiceFiscale.Name = "tbCodiceFiscale";
			this.tbCodiceFiscale.Size = new System.Drawing.Size(312, 20);
			this.tbCodiceFiscale.TabIndex = 3;
			this.tbCodiceFiscale.Text = "";
			this.tltInfo.SetToolTip(this.tbCodiceFiscale, "Filtra per Codice Fiscale");
			this.tbCodiceFiscale.TextChanged += new System.EventHandler(this.tbNominativo_TextChanged);
			// 
			// lblCodiceFiscale
			// 
			this.lblCodiceFiscale.Location = new System.Drawing.Point(8, 40);
			this.lblCodiceFiscale.Name = "lblCodiceFiscale";
			this.lblCodiceFiscale.Size = new System.Drawing.Size(84, 16);
			this.lblCodiceFiscale.TabIndex = 2;
			this.lblCodiceFiscale.Text = "Codice Fiscale";
			// 
			// tbNominativo
			// 
			this.tbNominativo.Location = new System.Drawing.Point(96, 16);
			this.tbNominativo.Name = "tbNominativo";
			this.tbNominativo.Size = new System.Drawing.Size(312, 20);
			this.tbNominativo.TabIndex = 1;
			this.tbNominativo.Text = "";
			this.tltInfo.SetToolTip(this.tbNominativo, "Filtra per Nominativo");
			this.tbNominativo.TextChanged += new System.EventHandler(this.tbNominativo_TextChanged);
			// 
			// lblNominativo
			// 
			this.lblNominativo.Location = new System.Drawing.Point(8, 16);
			this.lblNominativo.Name = "lblNominativo";
			this.lblNominativo.Size = new System.Drawing.Size(64, 16);
			this.lblNominativo.TabIndex = 0;
			this.lblNominativo.Text = "Nominativo";
			// 
			// frmSocietaUtenti
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(836, 441);
			this.Controls.Add(this.tcSocietaUtenti);
			this.Controls.Add(this.btnChiudi);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmSocietaUtenti";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Gestione Societ�/Utenti";
			this.tcSocietaUtenti.ResumeLayout(false);
			this.tpSocieta.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgSocieta)).EndInit();
			this.gbSocieta.ResumeLayout(false);
			this.tpUtenti.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgUtenti)).EndInit();
			this.gbUtente.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		
		#region Eventi della Form	
		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			Chiudi();
		}

		private void tbRagioneSociale_TextChanged(object sender, System.EventArgs e)
		{
			ChangeFilterDataGridSocieta();
		}

		private void tbNominativo_TextChanged(object sender, System.EventArgs e)
		{
			ChangeFilterDataGridUtenti();
		}

		private void dgSocieta_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			// L'evento non e' stato scatenato da un DataGrid
			if (sender.GetType() != typeof(DataGrid))
				return;

			// Verifico quale delle due DataGrid ha scatenato l'evento
			DataGrid dgSender = (DataGrid)sender;
			DataGrid.HitTestInfo hti = dgSender.HitTest(new Point(e.X, e.Y));
			if (hti.Type == DataGrid.HitTestType.Cell) 
			{ 
				dgSender.CurrentCell = new DataGridCell(hti.Row, hti.Column); 
				dgSender.Select(hti.Row); 
			}
		}
		

		private void dgSocieta_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Clicks == 2)
			{
				// L'evento non e' stato scatenato da un DataGrid
				if (sender.GetType() != typeof(DataGrid))
					return;
		
				// Verifico quale delle due DataGrid ha scatenato l'evento
				DataGrid dgSender = (DataGrid)sender;
				DataGrid.HitTestInfo hti = dgSender.HitTest(new Point(e.X, e.Y));
				if (hti.Type == DataGrid.HitTestType.Cell) 
				{ 
					frmDettaglioSocieta frmDettSocieta = new frmDettaglioSocieta(CurrentRowSocieta);
					frmDettSocieta.ShowDialog(this);
					frmDettSocieta.Dispose();	
				}	
			}
		}

		private void dgUtenti_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Clicks == 2)
			{
				// L'evento non e' stato scatenato da un DataGrid
				if (sender.GetType() != typeof(DataGrid))
					return;

				// Verifico quale delle due DataGrid ha scatenato l'evento
				DataGrid dgSender = (DataGrid)sender;
				DataGrid.HitTestInfo hti = dgSender.HitTest(new Point(e.X, e.Y));
				if (hti.Type == DataGrid.HitTestType.Cell) 
				{ 
					frmDettaglioUtente frmDettUtente = new frmDettaglioUtente(CurrentRowUtenti);
					frmDettUtente.ShowDialog(this);
					frmDettUtente.Dispose();
				}	
			}
		}
		#endregion

		private void tbCodiceConto_TextChanged(object sender, System.EventArgs e)
		{
			ChangeFilterDataGridSocieta();
		}

		private void tbCodConto_TextChanged(object sender, System.EventArgs e)
		{
			ChangeFilterDataGridUtenti();
		}

		private void btnStorico_Click(object sender, System.EventArgs e)
		{
			frmStoricoUtenti frmStoUtenti = new frmStoricoUtenti();
			frmStoUtenti.ShowDialog(this);
			frmStoUtenti.Dispose();
		}

		private void btnStoricoSoc_Click(object sender, System.EventArgs e)
		{
			frmStoricoSocieta frmStoSocieta = new frmStoricoSocieta();
			frmStoSocieta.ShowDialog(this);
			frmStoSocieta.Dispose();
		}
	}
}
