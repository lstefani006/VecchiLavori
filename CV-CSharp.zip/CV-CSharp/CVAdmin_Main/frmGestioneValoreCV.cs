using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmGestioneValoreCV.
	/// </summary>
	public class frmGestioneValoreCV : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ToolTip tltInfo;
		private System.Windows.Forms.DataGrid dgReport;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.GroupBox gbDettagli;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Button btnSalva;
		private System.Windows.Forms.Button btnElimina;

		private DataSet _dsMwCertificato = null;
		private string _strLastYear = null;

		public frmGestioneValoreCV()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_dsMwCertificato = GetMwCertificato();
			if (_dsMwCertificato == null)
			{
				DisabilitaComponenti();
				return;
			}
			
			// Recupero la tabella
			DataTable dt = GetDataTableMwCertificate();
			if (dt == null)
			{
				DisabilitaComponenti();
				return;
			}
			// Poiche' dalla query sul DB la colonna "Anno" e' ordinata per anno decrescente
			// nella prima Riga e' contenuto il valore dell'ultimo anno inserito.
			// Tale valore e' utile come valore di default durante l'inserimento di una nuova riga
			if (dt.Rows.Count != 0)
			{
				_strLastYear = dt.Rows[0]["Anno"].ToString(); //ToString OK
			}
			else
			{
				DisabilitaComponenti();
				return;
			}

			// Assegno l'evento per verificare la correttezza dei dati inseriti dall'utente
			dt.ColumnChanging += new DataColumnChangeEventHandler(dtMwCertificate_Column_Changing);
			// Assegno la tabella come DataSource della griglia
			dgReport.DataSource = dt;
			// Mapping della colonne del DataBase con quelle del DataGrid
			SetDataGridMapping();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmGestioneValoreCV));
			this.gbDettagli = new System.Windows.Forms.GroupBox();
			this.dgReport = new System.Windows.Forms.DataGrid();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.btnSalva = new System.Windows.Forms.Button();
			this.btnElimina = new System.Windows.Forms.Button();
			this.gbDettagli.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgReport)).BeginInit();
			this.SuspendLayout();
			// 
			// gbDettagli
			// 
			this.gbDettagli.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.gbDettagli.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.dgReport});
			this.gbDettagli.Location = new System.Drawing.Point(1, 2);
			this.gbDettagli.Name = "gbDettagli";
			this.gbDettagli.Size = new System.Drawing.Size(355, 158);
			this.gbDettagli.TabIndex = 1;
			this.gbDettagli.TabStop = false;
			this.gbDettagli.Text = " Dettagli ";
			// 
			// dgReport
			// 
			this.dgReport.CaptionText = "Report";
			this.dgReport.DataMember = "";
			this.dgReport.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgReport.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgReport.Location = new System.Drawing.Point(3, 16);
			this.dgReport.Name = "dgReport";
			this.dgReport.Size = new System.Drawing.Size(349, 139);
			this.dgReport.TabIndex = 0;
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnChiudi.Location = new System.Drawing.Point(254, 162);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.Size = new System.Drawing.Size(98, 23);
			this.btnChiudi.TabIndex = 2;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa finestra");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnSalva
			// 
			this.btnSalva.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnSalva.Location = new System.Drawing.Point(153, 162);
			this.btnSalva.Name = "btnSalva";
			this.btnSalva.Size = new System.Drawing.Size(98, 23);
			this.btnSalva.TabIndex = 8;
			this.btnSalva.Text = "&Salva Modifiche";
			this.tltInfo.SetToolTip(this.btnSalva, "Salva tutte le modifiche effettuate nella griglia");
			this.btnSalva.Click += new System.EventHandler(this.btnSalva_Click);
			// 
			// btnElimina
			// 
			this.btnElimina.Location = new System.Drawing.Point(52, 162);
			this.btnElimina.Name = "btnElimina";
			this.btnElimina.Size = new System.Drawing.Size(98, 23);
			this.btnElimina.TabIndex = 9;
			this.btnElimina.Text = "&Elimina";
			this.tltInfo.SetToolTip(this.btnElimina, "Elimina la riga selezionata");
			this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
			// 
			// frmGestioneValoreCV
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(358, 191);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnElimina,
																		  this.btnSalva,
																		  this.btnChiudi,
																		  this.gbDettagli});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "frmGestioneValoreCV";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Gestione Valori CV";
			this.gbDettagli.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgReport)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void DisabilitaComponenti()
		{
			dgReport.Enabled = false;
			btnElimina.Enabled = false;
			btnSalva.Enabled = false;
			// Devo poter uscire dalla Form
			btnChiudi.Enabled = true;
		}

		private  void dtMwCertificate_Column_Changing( object sender, DataColumnChangeEventArgs e )
		{
			if (e.Column.ColumnName == "Anno")
			{
				Regex r = new Regex(@"^ *(\d{4})? *$", RegexOptions.IgnoreCase);
				Match m = r.Match(e.ProposedValue.ToString());	//ToString OK
				if (m.Success == false)
				{
					string strMaxAnno = GetAnnoDefaultValue();
					int dAnno = int.Parse(strMaxAnno); // Parse OK
					dAnno += 1;
					_strLastYear = dAnno.ToString(); // ToString OK
					e.ProposedValue = _strLastYear;
					return;
				}
			}
			// Se ho inserito dei Blank li elimino perche' l'espressione regolare
			// non lo fa
			e.ProposedValue = e.ProposedValue.ToString().Trim();
			if (e.Column.ColumnName == "Anno")
			{
				AggiornaUltimoAnno(e.ProposedValue.ToString());
			}
		}

		private void SetDataGridMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[2];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();
			
			int index = 0;
			dgCol[index].HeaderText = "Anno";
			dgCol[index].MappingName = "Anno";
			dgCol[index].Width = 110;
			dgCol[index].NullText = "";

			index++;
			dgCol[index].HeaderText = "Quantit� Mwh";
			dgCol[index].MappingName = "QtyMwh";
			dgCol[index].Width = 110;
			dgCol[index].NullText = "";


			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "MwCertificato";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgReport.TableStyles.Add(dgStyle);
		}

		private void Chiudi()
		{
			this.DialogResult = DialogResult.Cancel;
		}

		#region Chiamate ai Web Services

		private DataSet GetMwCertificato()
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLCertificatoVerde.BLCertificatoVerde.RetrieveMwCertificato");

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		private DataSet UpdateMwCertificato(DataSet ds)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLCertificatoVerde.BLCertificatoVerde.UpdateMwCertificato", 
				ds);

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		#endregion

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			Chiudi();
		}

		private void CurrencyStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(decimal))
				return;

			string s = (string)cevent.Value;
			decimal d = Converter.CurrencyStringToDecimal(s);
			if (d < 0m)
				throw new Exception("prezzo minore di zero");

			cevent.Value = d;
		}

		private DataTable GetDataTableMwCertificate()
		{
			if (_dsMwCertificato != null)
			{
				return _dsMwCertificato.Tables[0];
			}
			else
				return null;
			
		}

		private bool AggiornaDataSet(DataSet ds)
		{
			// Verifico se sono state effettuate delle modifiche alle tabelle del DataSet
			if (!ds.HasChanges()) 
			{
				ds.AcceptChanges();
				return true;
			}

			DataSet xDataSet;
			// GetChanges solo per le righe modificate
			xDataSet = ds.GetChanges();

			if (xDataSet == null)
			{
				ds.AcceptChanges();
				return true;
			}

			// il Web Service ha risposto... prendo il risultato
			DataSet dsUpdated = UpdateMwCertificato(xDataSet);
			if (dsUpdated != null)
			{
				ds.AcceptChanges();
				return true;
			}
			else
			{
				ds.RejectChanges();
				return false;
			}
		}

		private void btnSalva_Click(object sender, System.EventArgs e)
		{
			DataTable dtMwCertificate = GetDataTableMwCertificate();
			// Recupero solo le righe Inserite, Modificate e Cancellate
			DataRow[] modRows = dtMwCertificate.Select(null, null,  DataViewRowState.Added | 
																    DataViewRowState.ModifiedCurrent |
																	DataViewRowState.Deleted);
			foreach (DataRow dr in modRows)
			{
				dr.EndEdit();
			}

			bool bResult = AggiornaDataSet(_dsMwCertificato);
			if (bResult)
				MessageBox.Show("Aggiornamento effettuato", "Messaggio", MessageBoxButtons.OK, MessageBoxIcon.Information);
			else
				MessageBox.Show("Aggiornamento non effettuato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);

		}

		private void btnElimina_Click(object sender, System.EventArgs e)
		{
			BindingManagerBase bm = dgReport.BindingContext[dgReport.DataSource]; 
			if (bm.Count == 0) // numero di righe = 0
				return;
			DataRow dr = null;
			if (bm.Current.GetType() == typeof(DataRowView))
			{
				dr = ((DataRowView)bm.Current).Row; 
				dr.Delete();
				dr.EndEdit();
			}

			bool bResult = AggiornaDataSet(_dsMwCertificato);
			if (bResult)
				MessageBox.Show("Cancellazione effettuata", "Messaggio", MessageBoxButtons.OK, MessageBoxIcon.Information);
			else
				MessageBox.Show("Cancellazione non effettuata", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
			
		}

		private string GetAnnoDefaultValue()
		{	
			return _strLastYear;
		}

		private void AggiornaUltimoAnno(string Anno)
		{
			decimal dAnno = Converter.NumberStringToDecimal(Anno);
			decimal dCorrente = Converter.NumberStringToDecimal(_strLastYear);
			if (dAnno > dCorrente)
				_strLastYear = dAnno.ToString();
		}

//		private decimal GetQuantitaMwhDefaultValue()
//		{
//			return MWhPerCV ; //Stefano
//		}
	}
}
