using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.Globalization;
using ExcelHelper;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmPagamenti.
	/// </summary>
	public class frmPagamenti : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnEsportaPagamenti;
		private System.Windows.Forms.Button btnCancella;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.SaveFileDialog dlgEsportaXls;
		private System.Windows.Forms.ComboBox cbTitoloSessione;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmPagamenti()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			DataSet dsSessioni = GetListaSessioni();
			if (dsSessioni != null)
			{
				cbTitoloSessione.Enabled = true;
				cbTitoloSessione.DataSource = dsSessioni.Tables[0];
				cbTitoloSessione.DisplayMember = "Titolo";
				cbTitoloSessione.ValueMember = "IdSessione";
				
			}
			else
				cbTitoloSessione.Enabled = false;
		}

		static DataSet GetListaSessioni()
		{
			bool Cancelled = false;
			if (Cancelled)
				return new CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni().GetLst();

			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni.GetLst");
			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		static DataSet Transazioni_RetrievePagamenti(string IdSessione)
		{
			bool Cancelled = false;
			if (Cancelled)
			{
				return new CVAdmin_Main.CVAdminWSBLTransazioni.BLTransazioni().RetrievePagamenti(IdSessione);
			}

			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLTransazioni.BLTransazioni().RetrievePagamenti", IdSessione);
			if (Cancelled)
				return null;
			return (DataSet)ret;
		}
		static DataSet Sessione_Retrieve(string IdSessione)
		{
			bool Cancelled = false;
			if (Cancelled)
			{
				CVAdmin_Main.CVAdminWSBLSessione.BLSessione bl = new CVAdmin_Main.CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(bl);
				return bl.Retrieve(IdSessione, "", "");
			}
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdminWSBLSessione.BLSessione().Retrieve", IdSessione, "", "");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}



		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPagamenti));
			this.cbTitoloSessione = new System.Windows.Forms.ComboBox();
			this.btnEsportaPagamenti = new System.Windows.Forms.Button();
			this.btnCancella = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.dlgEsportaXls = new System.Windows.Forms.SaveFileDialog();
			this.SuspendLayout();
			// 
			// cbTitoloSessione
			// 
			this.cbTitoloSessione.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbTitoloSessione.Location = new System.Drawing.Point(108, 14);
			this.cbTitoloSessione.Name = "cbTitoloSessione";
			this.cbTitoloSessione.Size = new System.Drawing.Size(356, 21);
			this.cbTitoloSessione.TabIndex = 0;
			// 
			// btnEsportaPagamenti
			// 
			this.btnEsportaPagamenti.Location = new System.Drawing.Point(200, 56);
			this.btnEsportaPagamenti.Name = "btnEsportaPagamenti";
			this.btnEsportaPagamenti.Size = new System.Drawing.Size(128, 24);
			this.btnEsportaPagamenti.TabIndex = 1;
			this.btnEsportaPagamenti.Text = "Esporta pagamenti";
			this.btnEsportaPagamenti.Click += new System.EventHandler(this.btnEsportaPagamenti_Click);
			// 
			// btnCancella
			// 
			this.btnCancella.Location = new System.Drawing.Point(336, 56);
			this.btnCancella.Name = "btnCancella";
			this.btnCancella.Size = new System.Drawing.Size(128, 24);
			this.btnCancella.TabIndex = 2;
			this.btnCancella.Text = "Cancella";
			this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(88, 16);
			this.label1.TabIndex = 3;
			this.label1.Text = "Titolo sessione:";
			// 
			// dlgEsportaXls
			// 
			this.dlgEsportaXls.Filter = "Xls file (*.xls)|*.xls|All files|*.*";
			// 
			// frmPagamenti
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(474, 95);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label1,
																		  this.btnCancella,
																		  this.btnEsportaPagamenti,
																		  this.cbTitoloSessione});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmPagamenti";
			this.ShowInTaskbar = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Pagamenti";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnEsportaPagamenti_Click(object sender, System.EventArgs e)
		{
			try
			{
				string IdSessione = (string)cbTitoloSessione.SelectedValue;
				DataSet dsPagamenti = Transazioni_RetrievePagamenti(IdSessione);
				if (dsPagamenti == null)
					return;

				DataSet dsSessione = Sessione_Retrieve(IdSessione);
				if (dsSessione == null)
					return;

 				ExportExecel(dsPagamenti, dsSessione);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Errore");
			}
		}

		private void btnCancella_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}



//		private Excel.Range Cell(Excel.Worksheet s, int r, int c)
//		{
//			return s.Cells[r, c] as Excel.Range;
//		}
//		private Excel.Range Cell(Excel.Worksheet s, int r1, int c1, int r2, int c2)
//		{
//			Excel.Range ra = s.Cells[r1, c1] as Excel.Range;
//			Excel.Range rb = s.Cells[r2, c2] as Excel.Range;
//			return s.Cells.get_Range(ra, rb);
//		}

		private spRange Cell(spWorksheet s, int r, int c)
		{
			return s.Cells[r,c];
		}
		private spRange Cell(spWorksheet s, int r1, int c1, int r2, int c2)
		{
			return s.Cells.Range(s.Cells[r1, c1], s.Cells[r2,c2]);
		}

		string BuildSheetName(string SheetName)
		{
			StringBuilder sb = new StringBuilder();

			for (int i = 0; i < SheetName.Length; i++)
			{
				char ch = SheetName[i];

				if (ch == ':' || ch == '\\' || ch == '/' || ch == '?' ||  
					ch == '*' || ch == '['  || ch == ']' )
					sb.Append("_");
				else
					sb.Append(ch);
			}
			return sb.ToString();//ToString OK
		}


//		private void ExportExecel(DataSet dsPagamenti, DataSet dsSessione)
//		{
//			object missing = System.Reflection.Missing.Value;
//
//			dlgEsportaXls.InitialDirectory = UtilityEnvironment.CommonAppDir;
//			if (dlgEsportaXls.ShowDialog() != DialogResult.OK)
//				return;
//
//			using (WaitCursor wc = new WaitCursor())
//			{
//				// per ovviare ad un baco quando si ha Excel in inglese e il SO in italiano
//				CultureInfo ciOri = System.Threading.Thread.CurrentThread.CurrentCulture;
//				System.Threading.Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-US");
//
//				try
//				{
//					string exportFileName = dlgEsportaXls.FileName;
//
//					DataRow drSessione = dsSessione.Tables[0].Rows[0];
//
//					Excel.Application xlApp = new Excel.Application();
//					xlApp.Visible = false;
//					xlApp.SheetsInNewWorkbook = 1;
//
//					Excel.Workbook xlBook = xlApp.Workbooks.Add(Excel.XlWBATemplate.xlWBATWorksheet);
//					Excel.Worksheet xlSheet = null;
//			
//
//					string StrRagSoc = "";
//					bool rsVuoto = true;
//					int i = 0;
//					foreach (DataRow drPagamenti in dsPagamenti.Tables[0].Rows)
//					{
//						string RagioneSocialeAcquirente = (string) drPagamenti["RagioneSocialeAcquirente"];
//						if (StrRagSoc != RagioneSocialeAcquirente)
//						{
//							StrRagSoc = RagioneSocialeAcquirente;
//							i = 0;
//							if (xlSheet != null)
//								xlSheet = xlBook.Worksheets.Add(missing, missing, missing, missing) as Excel.Worksheet;
//							else
//								xlSheet = xlBook.Worksheets[1] as Excel.Worksheet;  // alla creazione Excel crea di default uno sheet
//							xlSheet.Name = BuildSheetName(RagioneSocialeAcquirente);
//
//							// DATI DELLA SESSIONE;
//							Cell(xlSheet, 1, 1).get_Characters(missing, missing).Font.Size = 11;
//							Cell(xlSheet, 1, 1).get_Characters(missing, missing).Font.Bold = true;
//
//							string Titolo = Converter.StringToString(drSessione, "Titolo");
//							string DataOraApertura = Converter.DateTimeToStringDateTime(drSessione, "DataOraApertura");
//							string DataOraChiusura = Converter.DateTimeToStringDateTime(drSessione, "DataOraChiusura");
//							Cell(xlSheet, 1, 1).NumberFormat = "@";
//							Cell(xlSheet, 1, 1).Value = "Titolo sessione: " + Titolo + " Data ora apertura: " + DataOraApertura + " Data ora chiusura: " + DataOraChiusura;
//							Cell(xlSheet, 1, 1, 1, 6).HorizontalAlignment = 3;
//							Cell(xlSheet, 1, 1, 1, 6).Merge(missing);
//
//							// RIGHE INTESTAZIONE;
//							Excel.Range r3 = xlSheet.Cells.EntireRow[3, missing] as Excel.Range;
//							r3.get_Characters(missing, missing).Font.Size = 10;
//							r3.get_Characters(missing, missing).Font.Bold = true;
//
//							Cell(xlSheet, 3, 2).NumberFormat = "@";
//							Cell(xlSheet, 3, 2).Value = "Ammontare Da Pagare";
//
//							Cell(xlSheet, 3, 3).NumberFormat = "@";
//							Cell(xlSheet, 3, 3).Value = "Pagamenti GME Sospesi";
//
//							Cell(xlSheet, 3, 4).NumberFormat = "@";
//							Cell(xlSheet, 3, 4).Value = "Pagamenti Operatore";
//
//							(xlSheet.Cells.EntireRow[4,missing] as Excel.Range).get_Characters(missing, missing).Font.Size = 10;
//							(xlSheet.Cells.EntireRow[4,missing] as Excel.Range).get_Characters(missing, missing).Font.Bold = true;
//
//							Cell(xlSheet, 4, 1).NumberFormat = "@";
//							Cell(xlSheet, 4, 1).Value = Converter.StringToString(drPagamenti, "RagioneSocialeAcquirente");
//
//							i = 5;
//						}
//						if (xlSheet != null)
//						{
//							rsVuoto = false;
//							(xlSheet.Cells.EntireRow[i,missing] as Excel.Range).get_Characters(missing, missing).Font.Size = 8;
//							(xlSheet.Cells.EntireRow[i,missing] as Excel.Range).get_Characters(missing, missing).Font.Bold = false;
//
//							Cell(xlSheet, i, 1).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//							Cell(xlSheet, i, 1).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//							Cell(xlSheet, i, 1).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//							Cell(xlSheet, i, 1).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//							string strRagioneSocialeVenditore = Converter.StringToString(drPagamenti, "RagioneSocialeVenditore");
//							string strABI = Converter.StringToString(drPagamenti, "ABI");
//							string strCAB = Converter.StringToString(drPagamenti, "CAB");
//							string strCC  = Converter.StringToString(drPagamenti, "CC");
//							Cell(xlSheet, i, 1).NumberFormat = "@";
//							Cell(xlSheet, i, 1).Value = strRagioneSocialeVenditore + " - ABI " + strABI + " - CAB " + strCAB + " - CC " + strCC;
//
//							Cell(xlSheet, i, 2).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//							Cell(xlSheet, i, 2).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//							Cell(xlSheet, i, 2).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//							Cell(xlSheet, i, 2).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//							//Cell(xlSheet, i, 2).NumberFormat = "#,###,###0.00#";
//							Cell(xlSheet, i, 2).NumberFormat = "@";
//							Cell(xlSheet, i, 2).Value = Converter.DecimalToCurrencyString(drPagamenti, "TotAmmDaPag");
//
//							Cell(xlSheet, i, 3).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//							Cell(xlSheet, i, 3).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//							Cell(xlSheet, i, 3).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//							Cell(xlSheet, i, 3).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//							Cell(xlSheet, i, 3).NumberFormat = "@";
//							Cell(xlSheet, i, 3).Value = Converter.DecimalToCurrencyString(drPagamenti, "TotPagGMESosp");
//							//Cell(xlSheet, i, 3).NumberFormat = "#,###,###0.00#";
//
//							Cell(xlSheet, i, 4).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//							Cell(xlSheet, i, 4).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//							Cell(xlSheet, i, 4).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//							Cell(xlSheet, i, 4).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//							Cell(xlSheet, i, 4).NumberFormat = "@";
//							Cell(xlSheet, i, 4).Value = Converter.DecimalToCurrencyString(drPagamenti, "TotPagOper");
//							//Cell(xlSheet, i, 4).NumberFormat = "#,###,###0.00#";
//
//							Cell(xlSheet, i, 1, i, 4).Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = 7;
//							Cell(xlSheet, i, 1, i, 4).Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 3;
//							Cell(xlSheet, i, 1, i, 4).Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = 7;
//							Cell(xlSheet, i, 1, i, 4).Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 3;
//							i = i + 1;
//							for (int X = 1; X <= 4; X++)
//								(xlSheet.Cells.EntireColumn[X,missing] as Excel.Range).get_Resize(missing, missing).AutoFit();
//						}
//					}
//
//					if (!rsVuoto)
//					{
//						try { System.IO.File.Delete(exportFileName); } 
//						catch (Exception) {} // eccezione se il file non esiste
//
//						xlSheet.SaveAs(exportFileName, missing, missing, missing, missing, missing, missing, missing, missing);
//					}
//					else
//						MessageBox.Show("Non esistono pagamenti da effettuare", "Attenzione");
//
//					if (xlBook != null)
//						xlBook.Close(false, missing, missing);
//
//					xlApp.Quit();
//				}
//				catch(Exception ex)
//				{
//					wc.RestoreCursor();
//					MessageBox.Show(ex.Message, "Errore");
//				}
//				finally
//				{
//					// rimetto a posto il thread locale (altrimenti ci mettiamo a parlare inglese)
//					System.Threading.Thread.CurrentThread.CurrentCulture = ciOri;
//				}
//			}
//
//			MessageBox.Show("Foglio Excel generato con successo", "Messaggio");
//		}

		private void ExportExecel(DataSet dsPagamenti, DataSet dsSessione)
		{
			dlgEsportaXls.InitialDirectory = UtilityEnvironment.CommonAppDir;
			if (dlgEsportaXls.ShowDialog() != DialogResult.OK)
				return;

			using (WaitCursor wc = new WaitCursor())
			{
				try
				{
					string exportFileName = dlgEsportaXls.FileName;

					DataRow drSessione = dsSessione.Tables[0].Rows[0];

					using (spApplication xlApp = new spApplication())
					{
						xlApp.Visible = false;
						xlApp.SheetsInNewWorkbook = 1;

						spWorkbook xlBook = xlApp.Workbooks.Add();
						spWorksheet xlSheet = null;

						string StrRagSoc = "";
						bool rsVuoto = true;
						int i = 0;
						foreach (DataRow drPagamenti in dsPagamenti.Tables[0].Rows)
						{
							string RagioneSocialeAcquirente = (string) drPagamenti["RagioneSocialeAcquirente"];
							if (StrRagSoc != RagioneSocialeAcquirente)
							{
								StrRagSoc = RagioneSocialeAcquirente;
								i = 0;
								if (xlSheet != null)
									xlSheet = xlBook.Worksheets.Add();
								else
									xlSheet = xlBook.Worksheets[1];  // alla creazione Excel crea di default uno sheet

								if (RagioneSocialeAcquirente.Length > 31)
								{
									xlSheet.Name = BuildSheetName(RagioneSocialeAcquirente.Substring(0, 31));
								}
								else
								{
									xlSheet.Name = BuildSheetName(RagioneSocialeAcquirente);
								}

								// DATI DELLA SESSIONE;
								Cell(xlSheet, 1, 1).Characters.Font.Size = 11;
								Cell(xlSheet, 1, 1).Characters.Font.Bold = true;

								string Titolo = Converter.StringToString(drSessione, "Titolo");
								string DataOraApertura = Converter.DateTimeToStringDateTime(drSessione, "DataOraApertura");
								string DataOraChiusura = Converter.DateTimeToStringDateTime(drSessione, "DataOraChiusura");
								// Cell(xlSheet, 1, 1).NumberFormat = "@";
								Cell(xlSheet, 1, 1).Value = "Titolo sessione: " + Titolo + " Data ora apertura: " + DataOraApertura + " Data ora chiusura: " + DataOraChiusura;
								Cell(xlSheet, 1, 1, 1, 6).HorizontalAlignment = Excel.XlHAlign.xlHAlignGeneral;//3;
								Cell(xlSheet, 1, 1, 1, 6).Merge();

								// RIGHE INTESTAZIONE;
								spRange r3 = xlSheet.Cells.EntireRow[3];
								r3.Characters.Font.Size = 10;
								r3.Characters.Font.Bold = true;

								//Cell(xlSheet, 3, 2).NumberFormat = "@";
								Cell(xlSheet, 3, 2).Value = "Ammontare Da Pagare";

								//Cell(xlSheet, 3, 3).NumberFormat = "@";
								Cell(xlSheet, 3, 3).Value = "Pagamenti GME Sospesi";

								//Cell(xlSheet, 3, 4).NumberFormat = "@";
								Cell(xlSheet, 3, 4).Value = "Pagamenti Operatore";

								xlSheet.Cells.EntireRow[4].Characters.Font.Size = 10;
								xlSheet.Cells.EntireRow[4].Characters.Font.Bold = true;

								//Cell(xlSheet, 4, 1).NumberFormat = "@";
								Cell(xlSheet, 4, 1).Value = Converter.StringToString(drPagamenti, "RagioneSocialeAcquirente");

								i = 5;
							}
							if (xlSheet != null)
							{
								rsVuoto = false;
								xlSheet.Cells.EntireRow[i].Characters.Font.Size = 8;
								xlSheet.Cells.EntireRow[i].Characters.Font.Bold = false;

								Cell(xlSheet, i, 1).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
								Cell(xlSheet, i, 1).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
								Cell(xlSheet, i, 1).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
								Cell(xlSheet, i, 1).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
								string strRagioneSocialeVenditore = Converter.StringToString(drPagamenti, "RagioneSocialeVenditore");
								string strABI = Converter.StringToString(drPagamenti, "ABI");
								string strCAB = Converter.StringToString(drPagamenti, "CAB");
								string strCC  = Converter.StringToString(drPagamenti, "CC");
								//Cell(xlSheet, i, 1).NumberFormat = "@";
								Cell(xlSheet, i, 1).Value = strRagioneSocialeVenditore + " - ABI " + strABI + " - CAB " + strCAB + " - CC " + strCC;

								Cell(xlSheet, i, 2).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
								Cell(xlSheet, i, 2).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
								Cell(xlSheet, i, 2).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
								Cell(xlSheet, i, 2).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
								//Cell(xlSheet, i, 2).NumberFormat = "#,###,###0.00#";
								//Cell(xlSheet, i, 2).NumberFormat = "@";
								Cell(xlSheet, i, 2).Value = Converter.DecimalToCurrencyString(drPagamenti, "TotAmmDaPag");

								Cell(xlSheet, i, 3).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
								Cell(xlSheet, i, 3).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
								Cell(xlSheet, i, 3).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
								Cell(xlSheet, i, 3).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
								//Cell(xlSheet, i, 3).NumberFormat = "@";
								Cell(xlSheet, i, 3).Value = Converter.DecimalToCurrencyString(drPagamenti, "TotPagGMESosp");
								//Cell(xlSheet, i, 3).NumberFormat = "#,###,###0.00#";

								Cell(xlSheet, i, 4).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
								Cell(xlSheet, i, 4).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
								Cell(xlSheet, i, 4).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
								Cell(xlSheet, i, 4).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
								//Cell(xlSheet, i, 4).NumberFormat = "@";
								Cell(xlSheet, i, 4).Value = Converter.DecimalToCurrencyString(drPagamenti, "TotPagOper");
								//Cell(xlSheet, i, 4).NumberFormat = "#,###,###0.00#";

								Cell(xlSheet, i, 1, i, 4).Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = 7;
								Cell(xlSheet, i, 1, i, 4).Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 3;
								Cell(xlSheet, i, 1, i, 4).Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = 7;
								Cell(xlSheet, i, 1, i, 4).Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 3;
								i = i + 1;
								for (int X = 1; X <= 4; X++)
									xlSheet.Cells.EntireColumn[X].Resize.AutoFit();
							}
						}

						if (!rsVuoto)
						{
							try { System.IO.File.Delete(exportFileName); } 
							catch (Exception) {} // eccezione se il file non esiste

							xlSheet.SaveAs(exportFileName);
						}
						else
							MessageBox.Show("Non esistono pagamenti da effettuare", "Attenzione");

						if (xlBook != null)
							xlBook.Close();

						xlApp.Quit();
					}
				}
				catch(Exception ex)
				{
					wc.RestoreCursor();
					MessageBox.Show(ex.Message, "Errore");
				}
			}

			MessageBox.Show("Foglio Excel generato con successo", "Messaggio");
		}
	}
}
