using System;
using System.Drawing;
using System.Collections;
using System.Globalization;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Web.Services.Protocols;
using System.Security.Cryptography.X509Certificates;
using System.Data;
using ExcelHelper;
using System.Text;
using CVAdmin_Main.CVAdminWSBLBudget;


namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmBudget.
	/// </summary>
	public class frmBudget : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox gbDatiSessione;
		private System.Windows.Forms.Label lblTitoloSessione;
		private System.Windows.Forms.Label lblDataOraApertura;
		private System.Windows.Forms.Label lblStatoSess;
		private System.Windows.Forms.Label lblPrezzoRifAnnoPrec;
		private System.Windows.Forms.Label lblPrezzoRifAnnoCorr;
		private System.Windows.Forms.Label lblPrezzoRifAnnoSucc;
		private System.Windows.Forms.GroupBox gbGenerale;
		private System.Windows.Forms.Label lblCodiceConto;
		private System.Windows.Forms.Label lblImporto;
		private System.Windows.Forms.Label lblPrezzoConvUtenteMWh;
		private System.Windows.Forms.Label lblQtyMAXAcquistabile;
		private System.Windows.Forms.TextBox edtPrezzoConvenzionale;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoSucc;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoCorr;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoPrec;
		private System.Windows.Forms.TextBox edtStatoSessione;
		private System.Windows.Forms.TextBox edtDataOraChiusura;
		private System.Windows.Forms.TextBox edtDataOraApertura;
		private System.Windows.Forms.TextBox edtTitoloSessione;
		private System.Windows.Forms.TextBox edtQtyMAXAcquistabile;
		private System.Windows.Forms.TextBox edtPrezzoConvUtenteMW;
		private System.Windows.Forms.TextBox edtPrezzoConvUtente;
		private System.Windows.Forms.TextBox edtImporto;
		private System.Windows.Forms.ComboBox cbRagioneSociale;
		private System.Windows.Forms.Label lblDAtaOraChiusura;
		private System.Windows.Forms.Label lblPrezzoConv;
		private System.Windows.Forms.Label lblRagioneSoc;
		private System.Windows.Forms.Label lblPrezzoConvUtente;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.ToolTip tltInfo;
		private System.Windows.Forms.Button btnSalva;
		private System.ComponentModel.IContainer components;

		// Variabili definite dall'utente
		private string		_IdSessione;
		private DataSet		_dsBudgetsSocieta;
		private System.Windows.Forms.Button btnElimina;
		private System.Windows.Forms.ComboBox cbCodiceConto;
		private System.Windows.Forms.Label lblImportoProposto;
		private System.Windows.Forms.TextBox edtImportoProposto;
		private System.Windows.Forms.RadioButton rdbResiduoZero;
		private System.Windows.Forms.RadioButton rdbResiduoN;
		private System.Windows.Forms.RadioButton rdbTuttoResiduo;
		private System.Windows.Forms.TextBox edtResiduo;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnReport;
		private System.Windows.Forms.SaveFileDialog dlgEsportaXls;
		private System.Windows.Forms.Button btnImport;
		private System.Windows.Forms.OpenFileDialog dlgImportXml;
		private System.Windows.Forms.Label lblSaldo;
		private System.Windows.Forms.TextBox edtSaldo;
		private System.Windows.Forms.Button btnModificaImporto;
		private System.Windows.Forms.Button btnModificaSaldo;
		private System.Windows.Forms.Label lblSaldoProposto;
		private System.Windows.Forms.TextBox edtSaldoProposto;
		private DataTable	_dtSessioneAttiva;

		private decimal MWhPerCV;   //Stefano aggiunta e inizializzata nel costruttore

		public DataTable SocietaDataTable
		{
			get
			{
				if (_dsBudgetsSocieta != null)
					return _dsBudgetsSocieta.Tables["Societa"];
				else 
					return null;
			}
		}

		public DataTable BudgetsDataTable
		{
			get
			{
				if (_dsBudgetsSocieta != null)
					return _dsBudgetsSocieta.Tables["Budgets"];
				else 
					return null;
			}
		}

		public DataRow CurrentSocietaRow
		{
			get 
			{
				if (_bmSocieta.Current.GetType() != typeof(DataRowView))
					return null;
				
				DataRow dr = ((DataRowView)_bmSocieta.Current).Row;
				return dr;
			}
		}

		public DataRow CurrentBudgetRow
		{
			get 
			{
				DataRow drSocieta = CurrentSocietaRow;
				if (drSocieta == null)
					return null;

				DataRow [] drBudget = drSocieta.GetChildRows("relSocietaBudget");
				Debug.Assert(drBudget.Length == 1);
				if (drBudget.Length == 1)
					return drBudget[0];
				else
					return null;
			}
		}
		public frmBudget()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_IdSessione = null;
			_dsBudgetsSocieta = null;
		}

		public frmBudget(DataTable dtSessioneAttiva, string IdSessione)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_IdSessione = IdSessione;
			_dtSessioneAttiva = dtSessioneAttiva;

			try
			{
				CVAdminWSBLBudget.BLBudget ws = new CVAdminWSBLBudget.BLBudget();
				frmLogin.AddLoginInfo(ws);
				MWhPerCV = ws.MWhPerCV();
			}
			catch (Exception e)
			{
				MWhPerCV = 50; // Stefano debuggare!! Debug OK !
			}



			// controllo se esiste una o piu` sessioni precedenti a questa ancora
			// da chiudere. Se si la funzione ritorna false
			if (ControllaSessioniPrecedenti(IdSessione) == false)
			{
				foreach (Control c in this.Controls)
					c.Enabled = false;

				this.btnChiudi.Enabled = true;
				_MascheraReadOnly = true;
				return;
			}


			Binding bnd;

			edtTitoloSessione.DataBindings.Add(	"Text", _dtSessioneAttiva, "Titolo");
			edtDataOraApertura.DataBindings.Add("Text", _dtSessioneAttiva, "DataOraApertura");
			edtDataOraChiusura.DataBindings.Add("Text", _dtSessioneAttiva, "DataOraChiusura");
			edtStatoSessione.DataBindings.Add(	"Text", _dtSessioneAttiva, "StatoSessione");

			bnd = edtPrezzoRifAnnoPrec.DataBindings.Add("Text", _dtSessioneAttiva, "PrezzoRiferimentoAnnoPrec");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);

			bnd = edtPrezzoRifAnnoCorr.DataBindings.Add("Text", _dtSessioneAttiva, "PrezzoRiferimentoAnnoCorr");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);

			bnd = edtPrezzoRifAnnoSucc.DataBindings.Add("Text", _dtSessioneAttiva, "PrezzoRiferimentoAnnoSucc");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);

			bnd = edtPrezzoConvenzionale.DataBindings.Add("Text", _dtSessioneAttiva, "PrezzoConvenzionale");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);

			// Carico i dati delle societa' e dei relativi budgets
			_dsBudgetsSocieta = GetDataSetDatiBudget("", _IdSessione);
			if (_dsBudgetsSocieta == null)
			{
				foreach (Control cc in this.Controls)
					cc.Enabled = false;
				btnChiudi.Enabled = true;
				_MascheraReadOnly = true;
				return;
			}

			// Ho la tabella delle societa e la tabelle dei budgets.
			// Se non esiste il budget per una societa` qui lo creo.
			// Assegno a budget.importo il saldo della sessione precedente.
			string StatoSessioneCorrente = (string)_dtSessioneAttiva.Rows[0]["StatoSessione"];
			if (StatoSessioneCorrente == "In Attesa" || StatoSessioneCorrente == "Predisposta" 
#if DEBUG
				|| StatoSessioneCorrente == "Aperta"  // solo per debug DA TOGLIERE TODO
#endif
				)
			{
				CreaInizializzaBudget_SaldoSocieta();
				// qui a fronte delle possibili modifche di CreaInizializzaBudget_SaldoSocieta()
				// salvo tutto nel DB.
				AggiornaDataSet(_dsBudgetsSocieta);
			}
			else
			{
				// se non esistono record di budget per gli altri stati sessione e` un bel problema
				// Significa che non hanno aperto la maschera dei Budget quando la sessione 
				// era in stato 
			}

			// ora per ogni societa` esiste il budget --> la maschera puo` funzionare correttamente.

			// La regola (contorta) e` questa:
			// budget.importo e` assegnato al valore di societa.saldo (fatto sopra).
			// Se si vuole si puo` modificare l'importo del budget a mano o con l'import del file Xml dei
			// movimenti del San.Paolo.
			// Puo` capitare anche di voler modificare il saldo iniziale (magari PRIMA dell'import Xml):
			// e` una tragegia perche non si sa di cosa fare dell'importo....
			// Soluzione societa.Saldo si puo` modificare SOLO se e` uguale a budget.importo:
			// se sono uguali probabilmente i movimenti devono ancora arrivare e dunque e` coerente
			// modificare il saldo (notare che viene anche contestualmente aggiornato budget.importo
			// allo stesso valore).
			// L'importo Xml attualmente non smarca come "fatto" ogni movimento (intendo dire
			// in maniera indelebile es nel db o nello stesso file). Questa non e` una
			// dimenticanza ma serve proprio per poter riprocessare il file dopo aver modificato
			// il saldo.

			// Data Binding della tabella "Societa'" con la ComboBox contenente le Ragioni Sociali
			cbRagioneSociale.DataSource    = _dsBudgetsSocieta;
			cbRagioneSociale.DisplayMember = "Societa.RagioneSociale";
			cbRagioneSociale.ValueMember   = "Societa.IdSocieta";

			// Data Binding della tabella "Societa'" con la ComboBox contenente il Codice Conto delle societa'
			cbCodiceConto.DataSource    = _dsBudgetsSocieta;
			cbCodiceConto.DisplayMember = "Societa.CodiceConto";
			cbCodiceConto.ValueMember   = "Societa.IdSocieta";

			bnd = edtImporto.DataBindings.Add("Text", _dsBudgetsSocieta, "Societa.relSocietaBudget.Importo");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(Converter.CurrencyStringToDecimal);

			bnd = edtImportoProposto.DataBindings.Add("Text", _dsBudgetsSocieta, "Societa.relSocietaBudget.ImportoProposto");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(Converter.CurrencyStringToDecimal);

			bnd = edtPrezzoConvUtente.DataBindings.Add("Text", _dsBudgetsSocieta, "Societa.relSocietaBudget.PrezzoConvenzionaleUtente");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(Converter.CurrencyStringToDecimal);

			bnd = edtPrezzoConvUtenteMW.DataBindings.Add("Text", _dsBudgetsSocieta, "Societa.relSocietaBudget.PrezzoConvenzionaleUtenteMw");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(Converter.CurrencyStringToDecimal);

			bnd = edtSaldo.DataBindings.Add("Text", _dsBudgetsSocieta, "Societa.Saldo");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(Converter.CurrencyStringToDecimal);

			bnd = edtSaldoProposto.DataBindings.Add("Text", _dsBudgetsSocieta, "Societa.relSocietaBudget.SaldoProposto");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(Converter.CurrencyStringToDecimal);
			
			bnd = edtQtyMAXAcquistabile.DataBindings.Add("Text", _dsBudgetsSocieta, "Societa.relSocietaBudget.QtyMax");
			bnd.Parse  += new ConvertEventHandler(Converter.IntegerStringToDecimal);
			bnd.Format += new ConvertEventHandler(Converter.DecimalToIntegerString);

			Debug.Assert(this.BindingContext.Contains(_dsBudgetsSocieta, "Societa"));
			_bmSocieta = this.BindingContext[_dsBudgetsSocieta, "Societa"];
			_bmSocieta.PositionChanged += new EventHandler(BindingManagerBase_PositionChanged);

			AbilitaBottoni();

			SettaResiduo();
			ImpostaAllarmePerDiscondanzaValoriDichiaratiValoriReali();

		}

		/// <summary>
		/// Controlla se esiste una o piu` sessioni precedenti a <c>IdSessione</c>
		/// in stato non chiuso (ossia sessioni che possono modificare il saldo per di una societa`)
		/// Se esistono si arrabbia con una MessageBox e ritorna false
		/// </summary>
		/// <param name="IdSessioni">sessione di lavoro</param>
		/// <returns>false su errore o se esiste una sessione ancora da chiudere</returns>
		bool ControllaSessioniPrecedenti(string IdSessione)
		{
			try
			{
				CVAdminWSBLBudget.BLBudget ws = new CVAdminWSBLBudget.BLBudget();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginGetStatoSessioneSessionePrecedenti(IdSessione, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return false;

				// il Web Service ha risposto... prendo il risultato
				DataSet ds = ws.EndGetBudgetSessionePrecedente(asr);

				bool bCannotOpenBudget = false;
				// loop per tutte le precedenti sessioni
				foreach (DataRow r in ds.Tables[0].Rows)
				{
					// le sessioni precedenti devono essere in stato "Chiusa"
					string ss = (string)r["StatoSessione"];
					if (ss != "Chiusa")
					{
						bCannotOpenBudget = true;
						break;
					}
				}

				if (bCannotOpenBudget)
				{
					MessageBox.Show("Non e` possibile aprire il budget per questa sessione\npoiche` esistono una o piu` sessioni precedenti ancora da chiudere.", "Errore");
					return false;
				}
				
				return true;
			}
			catch (SoapException e)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show(e.Message, "Errore");
				return false;
			}
			catch (Exception e)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return false;
			}
		}



		private DataSet GetDataSetDatiBudget(string IdSocieta, string IdSessione)
		{
			try
			{
				CVAdminWSBLBudget.BLBudget ws = new CVAdminWSBLBudget.BLBudget();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginRetrieve(IdSocieta, IdSessione, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return null;

				// il Web Service ha risposto... prendo il risultato
				return ws.EndRetrieve(asr);
			}
			catch (SoapException e)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show(e.Message, "Errore");
				return null;
			}
			catch (Exception e)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return null;
			}
		}

		private bool AggiornaDataSet(DataSet ds)
		{
			try
			{
				// Verifico se sono state effettuate delle modifiche alle tabelle del DataSet
				if (!ds.HasChanges()) 
				{
					ds.AcceptChanges();
					return true;
				}

				DataSet xDataSet;
				// GetChanges solo per le righe modificate
				xDataSet = ds.GetChanges();

				if (xDataSet == null)
				{
					ds.AcceptChanges();
					return true;
				}

				CVAdminWSBLBudget.BLBudget ws = new CVAdminWSBLBudget.BLBudget();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginUpdate(xDataSet, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return false;

				// il Web Service ha risposto... prendo il risultato
				DataSet dsUpdated = ws.EndUpdate(asr);
				if (dsUpdated != null)
				{
					ds.AcceptChanges();
					return true;
				}
				else
				{
					ds.RejectChanges();
					return false;
				}
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return false;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return false;
			}
			finally
			{
				AbilitaBottoni();
			}
		}


		/// <summary>
		/// funzione che assegna un budget alle societa` che non l'hanno.
		/// La funzione viene chiamata SOLO se la sessione e` in stato "In Attesa" o "Predisposta"
		/// e non esistono precedenti sessioni in stato diverso da "Chiusa"
		/// </summary>
		private void CreaInizializzaBudget_SaldoSocieta()
		{
			// mi faccio dare l'eventuale impostazione della gestione del residuo.
			DataSet dsBudgetSessionePrecedente = null;
			try
			{
				BLBudget bl = new BLBudget();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginGetBudgetSessionePrecedente(_IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				dsBudgetSessionePrecedente = bl.EndGetBudgetSessionePrecedente(asr);
#if DEBUG
				dsBudgetSessionePrecedente.WriteXml(@"c:\budget_precedente.xml");
#endif
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				frmAsyncWait.OnCatchException(ex);
			}

			DateTime ora = CVAdmin_Main.DbTime.GetDbSystemDate();
			foreach (DataRow drSoc in SocietaDataTable.Rows)
			{
				// se il saldo e` nullo lo metto a zero
				// nella tabella delle societa`
				if (drSoc.IsNull("Saldo"))
				{
					drSoc["Saldo"] = 0m;
				}

				// trovo il budget della societa`.
				DataRow [] drBudget = drSoc.GetChildRows("relSocietaBudget");
				if (drBudget.Length == 0)
				{
					// non esistono record di budget
					// li creo assegnando il budget della sessione precedente 
					// che e` memorizzato in Societa`. 
					// Bisogna stare attenti: la sessione precedente DEVE essere gia` terminata.
					// Dato che per arrivare a questa funzione e` necessario non avere
					// una precedente sessione in stato tale da poter modificare il saldo della societa`
					// il requisito e` soddisftatto.
					//
					// Inoltre provo ad ereditare la gestione del risiduo precedente.
					// (anche se non esiste non e` un problema...)

					DataRow newRow = BudgetsDataTable.NewRow();
					newRow["IdSocieta"] = drSoc["IdSocieta"];
					newRow["IdSessione"] = _IdSessione;
					newRow["Importo"] = drSoc["Saldo"];  // <-- l'importo e` uguale al saldo
					newRow["ImportoProposto"] = 0m;
					newRow["SaldoProposto"] = 0m;
					newRow["PrezzoConvenzionaleUtente"] = 0m;
					newRow["PrezzoConvenzionaleUtenteMw"] = 0m;
					newRow["QtyMax"] = 0m;
					newRow["QtyImpegnata"] = 0M;
					newRow["DataOraCreazione"] = ora;
					newRow["Residuo"] = 0m;
					newRow["SaldoSessionePrecedente"] = drSoc["Saldo"];

					// provo ad assegnare la gestione del residuo alla sessione precedente
					if (dsBudgetSessionePrecedente != null)
					{
						DataTable dtSessionePrecedente = dsBudgetSessionePrecedente.Tables["BudgetSessionePrecedente"];
						DataRow [] budgetPrec = dtSessionePrecedente.Select(string.Format("IdSocieta='{0}'", (string)drSoc["IdSocieta"]));
						if (budgetPrec.Length == 1)
							if (budgetPrec[0].IsNull("Residuo") == false)
								newRow["Residuo"] = (decimal)budgetPrec[0]["Residuo"];
					}

					BudgetsDataTable.Rows.Add(newRow);
				}
				else
				{
					// esiste gia` il budget per questa sessione per questa societa`.
					// Resta da vedere se e` stato creato da questa maschera
					// o se e` stato creato per una dichiarazione di budget lato WEB

					if (drBudget[0].IsNull("SaldoSessionePrecedente"))
					{
						// se siamo qui significa che il budget e` stato creato a causa
						// di una dichiarazione di budget lato Web dove NON si sa certo 
						// il saldo della sessione precedente.
						drBudget[0]["SaldoSessionePrecedente"] = drSoc["Saldo"];
						drBudget[0]["Importo"] = drSoc["Saldo"];

						// provo ad assegnare la gestione del residuo alla sessione precedente
						/*
						Commentato: bug segnalato il 15/11/2004.
						In pratica si sovrascriveva la gestione del residuo scelto l'operatore
						lato WEB
						
						if (dsBudgetSessionePrecedente != null)
						{
							DataTable dtSessionePrecedente = dsBudgetSessionePrecedente.Tables["BudgetSessionePrecedente"];
							DataRow [] budgetPrec = dtSessionePrecedente.Select(string.Format("IdSocieta='{0}'", (string)drSoc["IdSocieta"]));
							if (budgetPrec.Length == 1)
								if (budgetPrec[0].IsNull("Residuo") == false)
									drBudget[0]["Residuo"] = (decimal)budgetPrec[0]["Residuo"];
						}
						*/
					}
					else
					{
						// il budget e` stato creato o updatato da questa maschera.
						// Dato che SaldoSessionePRecedente e` valorizzato significa che 
						// la precedente sessione e` stata gia` chiusa. --> posso iniziare
						// a fare i calcoli per questa sessione.
					}
				}
			}
		}


		////////////////////////////////////////////////////////////////////////////
		BindingManagerBase _bmSocieta;
		bool _MascheraReadOnly = false;

		private void BindingManagerBase_PositionChanged(object sender, EventArgs e)
		{
			AbilitaBottoni();
			SettaResiduo();
			ImpostaAllarmePerDiscondanzaValoriDichiaratiValoriReali();
		}


		private void AbilitaBottoni()
		{
			btnSalva.Enabled = true;
			btnElimina.Enabled = true;
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBudget));
			this.gbDatiSessione = new System.Windows.Forms.GroupBox();
			this.edtPrezzoConvenzionale = new System.Windows.Forms.TextBox();
			this.edtPrezzoRifAnnoSucc = new System.Windows.Forms.TextBox();
			this.edtPrezzoRifAnnoCorr = new System.Windows.Forms.TextBox();
			this.edtPrezzoRifAnnoPrec = new System.Windows.Forms.TextBox();
			this.lblPrezzoConv = new System.Windows.Forms.Label();
			this.lblPrezzoRifAnnoSucc = new System.Windows.Forms.Label();
			this.lblPrezzoRifAnnoCorr = new System.Windows.Forms.Label();
			this.lblPrezzoRifAnnoPrec = new System.Windows.Forms.Label();
			this.edtStatoSessione = new System.Windows.Forms.TextBox();
			this.edtDataOraChiusura = new System.Windows.Forms.TextBox();
			this.edtDataOraApertura = new System.Windows.Forms.TextBox();
			this.lblStatoSess = new System.Windows.Forms.Label();
			this.lblDAtaOraChiusura = new System.Windows.Forms.Label();
			this.lblDataOraApertura = new System.Windows.Forms.Label();
			this.edtTitoloSessione = new System.Windows.Forms.TextBox();
			this.lblTitoloSessione = new System.Windows.Forms.Label();
			this.gbGenerale = new System.Windows.Forms.GroupBox();
			this.edtSaldoProposto = new System.Windows.Forms.TextBox();
			this.lblSaldoProposto = new System.Windows.Forms.Label();
			this.btnModificaSaldo = new System.Windows.Forms.Button();
			this.btnModificaImporto = new System.Windows.Forms.Button();
			this.edtSaldo = new System.Windows.Forms.TextBox();
			this.lblSaldo = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.rdbResiduoZero = new System.Windows.Forms.RadioButton();
			this.rdbResiduoN = new System.Windows.Forms.RadioButton();
			this.rdbTuttoResiduo = new System.Windows.Forms.RadioButton();
			this.edtResiduo = new System.Windows.Forms.TextBox();
			this.edtImportoProposto = new System.Windows.Forms.TextBox();
			this.lblImportoProposto = new System.Windows.Forms.Label();
			this.cbCodiceConto = new System.Windows.Forms.ComboBox();
			this.edtQtyMAXAcquistabile = new System.Windows.Forms.TextBox();
			this.edtPrezzoConvUtenteMW = new System.Windows.Forms.TextBox();
			this.edtPrezzoConvUtente = new System.Windows.Forms.TextBox();
			this.lblQtyMAXAcquistabile = new System.Windows.Forms.Label();
			this.lblPrezzoConvUtenteMWh = new System.Windows.Forms.Label();
			this.lblPrezzoConvUtente = new System.Windows.Forms.Label();
			this.edtImporto = new System.Windows.Forms.TextBox();
			this.lblImporto = new System.Windows.Forms.Label();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.lblRagioneSoc = new System.Windows.Forms.Label();
			this.cbRagioneSociale = new System.Windows.Forms.ComboBox();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnSalva = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.btnElimina = new System.Windows.Forms.Button();
			this.btnReport = new System.Windows.Forms.Button();
			this.btnImport = new System.Windows.Forms.Button();
			this.dlgEsportaXls = new System.Windows.Forms.SaveFileDialog();
			this.dlgImportXml = new System.Windows.Forms.OpenFileDialog();
			this.gbDatiSessione.SuspendLayout();
			this.gbGenerale.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbDatiSessione
			// 
			this.gbDatiSessione.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbDatiSessione.Controls.Add(this.edtPrezzoConvenzionale);
			this.gbDatiSessione.Controls.Add(this.edtPrezzoRifAnnoSucc);
			this.gbDatiSessione.Controls.Add(this.edtPrezzoRifAnnoCorr);
			this.gbDatiSessione.Controls.Add(this.edtPrezzoRifAnnoPrec);
			this.gbDatiSessione.Controls.Add(this.lblPrezzoConv);
			this.gbDatiSessione.Controls.Add(this.lblPrezzoRifAnnoSucc);
			this.gbDatiSessione.Controls.Add(this.lblPrezzoRifAnnoCorr);
			this.gbDatiSessione.Controls.Add(this.lblPrezzoRifAnnoPrec);
			this.gbDatiSessione.Controls.Add(this.edtStatoSessione);
			this.gbDatiSessione.Controls.Add(this.edtDataOraChiusura);
			this.gbDatiSessione.Controls.Add(this.edtDataOraApertura);
			this.gbDatiSessione.Controls.Add(this.lblStatoSess);
			this.gbDatiSessione.Controls.Add(this.lblDAtaOraChiusura);
			this.gbDatiSessione.Controls.Add(this.lblDataOraApertura);
			this.gbDatiSessione.Controls.Add(this.edtTitoloSessione);
			this.gbDatiSessione.Controls.Add(this.lblTitoloSessione);
			this.gbDatiSessione.Location = new System.Drawing.Point(0, 8);
			this.gbDatiSessione.Name = "gbDatiSessione";
			this.gbDatiSessione.Size = new System.Drawing.Size(680, 168);
			this.gbDatiSessione.TabIndex = 0;
			this.gbDatiSessione.TabStop = false;
			this.gbDatiSessione.Text = " Dati Sessione Attiva ";
			// 
			// edtPrezzoConvenzionale
			// 
			this.edtPrezzoConvenzionale.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtPrezzoConvenzionale.Enabled = false;
			this.edtPrezzoConvenzionale.Location = new System.Drawing.Point(512, 136);
			this.edtPrezzoConvenzionale.Name = "edtPrezzoConvenzionale";
			this.edtPrezzoConvenzionale.Size = new System.Drawing.Size(160, 20);
			this.edtPrezzoConvenzionale.TabIndex = 8;
			this.edtPrezzoConvenzionale.Text = "";
			// 
			// edtPrezzoRifAnnoSucc
			// 
			this.edtPrezzoRifAnnoSucc.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtPrezzoRifAnnoSucc.Enabled = false;
			this.edtPrezzoRifAnnoSucc.Location = new System.Drawing.Point(344, 136);
			this.edtPrezzoRifAnnoSucc.Name = "edtPrezzoRifAnnoSucc";
			this.edtPrezzoRifAnnoSucc.Size = new System.Drawing.Size(160, 20);
			this.edtPrezzoRifAnnoSucc.TabIndex = 7;
			this.edtPrezzoRifAnnoSucc.Text = "";
			// 
			// edtPrezzoRifAnnoCorr
			// 
			this.edtPrezzoRifAnnoCorr.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtPrezzoRifAnnoCorr.Enabled = false;
			this.edtPrezzoRifAnnoCorr.Location = new System.Drawing.Point(176, 136);
			this.edtPrezzoRifAnnoCorr.Name = "edtPrezzoRifAnnoCorr";
			this.edtPrezzoRifAnnoCorr.Size = new System.Drawing.Size(160, 20);
			this.edtPrezzoRifAnnoCorr.TabIndex = 6;
			this.edtPrezzoRifAnnoCorr.Text = "";
			// 
			// edtPrezzoRifAnnoPrec
			// 
			this.edtPrezzoRifAnnoPrec.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtPrezzoRifAnnoPrec.Enabled = false;
			this.edtPrezzoRifAnnoPrec.Location = new System.Drawing.Point(8, 136);
			this.edtPrezzoRifAnnoPrec.Name = "edtPrezzoRifAnnoPrec";
			this.edtPrezzoRifAnnoPrec.Size = new System.Drawing.Size(160, 20);
			this.edtPrezzoRifAnnoPrec.TabIndex = 5;
			this.edtPrezzoRifAnnoPrec.Text = "";
			// 
			// lblPrezzoConv
			// 
			this.lblPrezzoConv.Location = new System.Drawing.Point(512, 120);
			this.lblPrezzoConv.Name = "lblPrezzoConv";
			this.lblPrezzoConv.Size = new System.Drawing.Size(120, 16);
			this.lblPrezzoConv.TabIndex = 11;
			this.lblPrezzoConv.Text = "Prezzo Convenzionale";
			// 
			// lblPrezzoRifAnnoSucc
			// 
			this.lblPrezzoRifAnnoSucc.Location = new System.Drawing.Point(344, 120);
			this.lblPrezzoRifAnnoSucc.Name = "lblPrezzoRifAnnoSucc";
			this.lblPrezzoRifAnnoSucc.Size = new System.Drawing.Size(176, 16);
			this.lblPrezzoRifAnnoSucc.TabIndex = 10;
			this.lblPrezzoRifAnnoSucc.Text = "Prezzo di Riferimento Anno Succ.";
			// 
			// lblPrezzoRifAnnoCorr
			// 
			this.lblPrezzoRifAnnoCorr.Location = new System.Drawing.Point(176, 120);
			this.lblPrezzoRifAnnoCorr.Name = "lblPrezzoRifAnnoCorr";
			this.lblPrezzoRifAnnoCorr.Size = new System.Drawing.Size(176, 16);
			this.lblPrezzoRifAnnoCorr.TabIndex = 9;
			this.lblPrezzoRifAnnoCorr.Text = "Prezzo di Riferimento Anno Corr.";
			// 
			// lblPrezzoRifAnnoPrec
			// 
			this.lblPrezzoRifAnnoPrec.Location = new System.Drawing.Point(8, 120);
			this.lblPrezzoRifAnnoPrec.Name = "lblPrezzoRifAnnoPrec";
			this.lblPrezzoRifAnnoPrec.Size = new System.Drawing.Size(176, 16);
			this.lblPrezzoRifAnnoPrec.TabIndex = 8;
			this.lblPrezzoRifAnnoPrec.Text = "Prezzo di Riferimento Anno Prec.";
			// 
			// edtStatoSessione
			// 
			this.edtStatoSessione.Enabled = false;
			this.edtStatoSessione.Location = new System.Drawing.Point(264, 85);
			this.edtStatoSessione.Name = "edtStatoSessione";
			this.edtStatoSessione.Size = new System.Drawing.Size(120, 20);
			this.edtStatoSessione.TabIndex = 4;
			this.edtStatoSessione.Text = "";
			// 
			// edtDataOraChiusura
			// 
			this.edtDataOraChiusura.Enabled = false;
			this.edtDataOraChiusura.Location = new System.Drawing.Point(136, 85);
			this.edtDataOraChiusura.Name = "edtDataOraChiusura";
			this.edtDataOraChiusura.Size = new System.Drawing.Size(120, 20);
			this.edtDataOraChiusura.TabIndex = 3;
			this.edtDataOraChiusura.Text = "";
			// 
			// edtDataOraApertura
			// 
			this.edtDataOraApertura.Enabled = false;
			this.edtDataOraApertura.Location = new System.Drawing.Point(8, 85);
			this.edtDataOraApertura.Name = "edtDataOraApertura";
			this.edtDataOraApertura.Size = new System.Drawing.Size(120, 20);
			this.edtDataOraApertura.TabIndex = 2;
			this.edtDataOraApertura.Text = "";
			// 
			// lblStatoSess
			// 
			this.lblStatoSess.Location = new System.Drawing.Point(264, 69);
			this.lblStatoSess.Name = "lblStatoSess";
			this.lblStatoSess.Size = new System.Drawing.Size(80, 16);
			this.lblStatoSess.TabIndex = 4;
			this.lblStatoSess.Text = "Stato Sessione";
			// 
			// lblDAtaOraChiusura
			// 
			this.lblDAtaOraChiusura.Location = new System.Drawing.Point(136, 69);
			this.lblDAtaOraChiusura.Name = "lblDAtaOraChiusura";
			this.lblDAtaOraChiusura.Size = new System.Drawing.Size(104, 16);
			this.lblDAtaOraChiusura.TabIndex = 3;
			this.lblDAtaOraChiusura.Text = "Data ora chiusura";
			// 
			// lblDataOraApertura
			// 
			this.lblDataOraApertura.Location = new System.Drawing.Point(8, 69);
			this.lblDataOraApertura.Name = "lblDataOraApertura";
			this.lblDataOraApertura.Size = new System.Drawing.Size(96, 16);
			this.lblDataOraApertura.TabIndex = 2;
			this.lblDataOraApertura.Text = "Data ora apertura";
			// 
			// edtTitoloSessione
			// 
			this.edtTitoloSessione.Enabled = false;
			this.edtTitoloSessione.Location = new System.Drawing.Point(7, 38);
			this.edtTitoloSessione.Name = "edtTitoloSessione";
			this.edtTitoloSessione.Size = new System.Drawing.Size(665, 20);
			this.edtTitoloSessione.TabIndex = 1;
			this.edtTitoloSessione.Text = "";
			// 
			// lblTitoloSessione
			// 
			this.lblTitoloSessione.Location = new System.Drawing.Point(7, 22);
			this.lblTitoloSessione.Name = "lblTitoloSessione";
			this.lblTitoloSessione.Size = new System.Drawing.Size(88, 16);
			this.lblTitoloSessione.TabIndex = 0;
			this.lblTitoloSessione.Text = "Titolo Sessione";
			// 
			// gbGenerale
			// 
			this.gbGenerale.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbGenerale.Controls.Add(this.edtSaldoProposto);
			this.gbGenerale.Controls.Add(this.lblSaldoProposto);
			this.gbGenerale.Controls.Add(this.btnModificaSaldo);
			this.gbGenerale.Controls.Add(this.btnModificaImporto);
			this.gbGenerale.Controls.Add(this.edtSaldo);
			this.gbGenerale.Controls.Add(this.lblSaldo);
			this.gbGenerale.Controls.Add(this.groupBox1);
			this.gbGenerale.Controls.Add(this.edtImportoProposto);
			this.gbGenerale.Controls.Add(this.lblImportoProposto);
			this.gbGenerale.Controls.Add(this.cbCodiceConto);
			this.gbGenerale.Controls.Add(this.edtQtyMAXAcquistabile);
			this.gbGenerale.Controls.Add(this.edtPrezzoConvUtenteMW);
			this.gbGenerale.Controls.Add(this.edtPrezzoConvUtente);
			this.gbGenerale.Controls.Add(this.lblQtyMAXAcquistabile);
			this.gbGenerale.Controls.Add(this.lblPrezzoConvUtenteMWh);
			this.gbGenerale.Controls.Add(this.lblPrezzoConvUtente);
			this.gbGenerale.Controls.Add(this.edtImporto);
			this.gbGenerale.Controls.Add(this.lblImporto);
			this.gbGenerale.Controls.Add(this.lblCodiceConto);
			this.gbGenerale.Controls.Add(this.lblRagioneSoc);
			this.gbGenerale.Controls.Add(this.cbRagioneSociale);
			this.gbGenerale.Location = new System.Drawing.Point(0, 184);
			this.gbGenerale.Name = "gbGenerale";
			this.gbGenerale.Size = new System.Drawing.Size(680, 296);
			this.gbGenerale.TabIndex = 1;
			this.gbGenerale.TabStop = false;
			this.gbGenerale.Text = " Generale ";
			// 
			// edtSaldoProposto
			// 
			this.edtSaldoProposto.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtSaldoProposto.Enabled = false;
			this.edtSaldoProposto.Location = new System.Drawing.Point(256, 112);
			this.edtSaldoProposto.MaxLength = 18;
			this.edtSaldoProposto.Name = "edtSaldoProposto";
			this.edtSaldoProposto.Size = new System.Drawing.Size(208, 20);
			this.edtSaldoProposto.TabIndex = 22;
			this.edtSaldoProposto.Text = "";
			this.tltInfo.SetToolTip(this.edtSaldoProposto, "Saldo, dichiarato dalla societa` relativo alla precedente sessione");
			// 
			// lblSaldoProposto
			// 
			this.lblSaldoProposto.Location = new System.Drawing.Point(256, 96);
			this.lblSaldoProposto.Name = "lblSaldoProposto";
			this.lblSaldoProposto.Size = new System.Drawing.Size(224, 16);
			this.lblSaldoProposto.TabIndex = 21;
			this.lblSaldoProposto.Text = "Saldo della Sessione precedente dichiarato";
			// 
			// btnModificaSaldo
			// 
			this.btnModificaSaldo.Location = new System.Drawing.Point(192, 112);
			this.btnModificaSaldo.Name = "btnModificaSaldo";
			this.btnModificaSaldo.Size = new System.Drawing.Size(56, 23);
			this.btnModificaSaldo.TabIndex = 20;
			this.btnModificaSaldo.Text = "Modifica";
			this.tltInfo.SetToolTip(this.btnModificaSaldo, "Abilitazione alla modifica del campo \"Saldo della Sessione precedente\"");
			this.btnModificaSaldo.Click += new System.EventHandler(this.btnModificaSaldo_Click);
			// 
			// btnModificaImporto
			// 
			this.btnModificaImporto.Location = new System.Drawing.Point(192, 152);
			this.btnModificaImporto.Name = "btnModificaImporto";
			this.btnModificaImporto.Size = new System.Drawing.Size(56, 23);
			this.btnModificaImporto.TabIndex = 19;
			this.btnModificaImporto.Text = "Modifica";
			this.tltInfo.SetToolTip(this.btnModificaImporto, "Abilitazione alla modifica del campo \"Budget per la Sessione\"");
			this.btnModificaImporto.Click += new System.EventHandler(this.btnModificaImporto_Click);
			// 
			// edtSaldo
			// 
			this.edtSaldo.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtSaldo.Enabled = false;
			this.edtSaldo.Location = new System.Drawing.Point(8, 112);
			this.edtSaldo.MaxLength = 18;
			this.edtSaldo.Name = "edtSaldo";
			this.edtSaldo.Size = new System.Drawing.Size(176, 20);
			this.edtSaldo.TabIndex = 18;
			this.edtSaldo.Text = "";
			this.tltInfo.SetToolTip(this.edtSaldo, "Saldo, relativo alla societa`, risultante al sistema");
			this.edtSaldo.Validated += new System.EventHandler(this.edtSaldo_Validated);
			// 
			// lblSaldo
			// 
			this.lblSaldo.Location = new System.Drawing.Point(8, 96);
			this.lblSaldo.Name = "lblSaldo";
			this.lblSaldo.Size = new System.Drawing.Size(176, 16);
			this.lblSaldo.TabIndex = 17;
			this.lblSaldo.Text = "Saldo della Sessione precedente";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.rdbResiduoZero);
			this.groupBox1.Controls.Add(this.rdbResiduoN);
			this.groupBox1.Controls.Add(this.rdbTuttoResiduo);
			this.groupBox1.Controls.Add(this.edtResiduo);
			this.groupBox1.Location = new System.Drawing.Point(256, 184);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(416, 104);
			this.groupBox1.TabIndex = 16;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Tipologia di Rimborso ";
			// 
			// rdbResiduoZero
			// 
			this.rdbResiduoZero.Location = new System.Drawing.Point(16, 24);
			this.rdbResiduoZero.Name = "rdbResiduoZero";
			this.rdbResiduoZero.Size = new System.Drawing.Size(232, 16);
			this.rdbResiduoZero.TabIndex = 12;
			this.rdbResiduoZero.Text = "Effettuare il rimborso del deposito residuo";
			this.rdbResiduoZero.CheckedChanged += new System.EventHandler(this.rdbResiduoZero_CheckedChanged);
			// 
			// rdbResiduoN
			// 
			this.rdbResiduoN.Location = new System.Drawing.Point(16, 40);
			this.rdbResiduoN.Name = "rdbResiduoN";
			this.rdbResiduoN.Size = new System.Drawing.Size(200, 32);
			this.rdbResiduoN.TabIndex = 13;
			this.rdbResiduoN.Text = "Effettuare il rimborso del deposito residuo per la somma eccedente";
			this.rdbResiduoN.CheckedChanged += new System.EventHandler(this.rdbResiduoN_CheckedChanged);
			// 
			// rdbTuttoResiduo
			// 
			this.rdbTuttoResiduo.Location = new System.Drawing.Point(16, 72);
			this.rdbTuttoResiduo.Name = "rdbTuttoResiduo";
			this.rdbTuttoResiduo.Size = new System.Drawing.Size(256, 16);
			this.rdbTuttoResiduo.TabIndex = 14;
			this.rdbTuttoResiduo.Text = "Non effettuare il rimborso del deposito residuo";
			this.rdbTuttoResiduo.CheckedChanged += new System.EventHandler(this.rdbTuttoResiduo_CheckedChanged);
			// 
			// edtResiduo
			// 
			this.edtResiduo.BackColor = System.Drawing.Color.White;
			this.edtResiduo.Location = new System.Drawing.Point(216, 48);
			this.edtResiduo.MaxLength = 18;
			this.edtResiduo.Name = "edtResiduo";
			this.edtResiduo.Size = new System.Drawing.Size(184, 20);
			this.edtResiduo.TabIndex = 15;
			this.edtResiduo.Text = "";
			this.edtResiduo.Validated += new System.EventHandler(this.edtResiduo_Validated);
			// 
			// edtImportoProposto
			// 
			this.edtImportoProposto.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtImportoProposto.Enabled = false;
			this.edtImportoProposto.Location = new System.Drawing.Point(256, 152);
			this.edtImportoProposto.MaxLength = 18;
			this.edtImportoProposto.Name = "edtImportoProposto";
			this.edtImportoProposto.Size = new System.Drawing.Size(208, 20);
			this.edtImportoProposto.TabIndex = 11;
			this.edtImportoProposto.Text = "";
			this.tltInfo.SetToolTip(this.edtImportoProposto, "Totale dei bonifici dichiarati dalla societa` per questa sessione");
			// 
			// lblImportoProposto
			// 
			this.lblImportoProposto.Location = new System.Drawing.Point(256, 136);
			this.lblImportoProposto.Name = "lblImportoProposto";
			this.lblImportoProposto.Size = new System.Drawing.Size(176, 16);
			this.lblImportoProposto.TabIndex = 10;
			this.lblImportoProposto.Text = "Tot. dei Bonifici dichiarati";
			// 
			// cbCodiceConto
			// 
			this.cbCodiceConto.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.cbCodiceConto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCodiceConto.Location = new System.Drawing.Point(8, 72);
			this.cbCodiceConto.Name = "cbCodiceConto";
			this.cbCodiceConto.Size = new System.Drawing.Size(176, 21);
			this.cbCodiceConto.TabIndex = 9;
			this.tltInfo.SetToolTip(this.cbCodiceConto, "Elenco delle Societa\' per Codice Conto");
			// 
			// edtQtyMAXAcquistabile
			// 
			this.edtQtyMAXAcquistabile.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtQtyMAXAcquistabile.Enabled = false;
			this.edtQtyMAXAcquistabile.Location = new System.Drawing.Point(8, 272);
			this.edtQtyMAXAcquistabile.Name = "edtQtyMAXAcquistabile";
			this.edtQtyMAXAcquistabile.Size = new System.Drawing.Size(176, 20);
			this.edtQtyMAXAcquistabile.TabIndex = 7;
			this.edtQtyMAXAcquistabile.Text = "";
			// 
			// edtPrezzoConvUtenteMW
			// 
			this.edtPrezzoConvUtenteMW.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtPrezzoConvUtenteMW.Enabled = false;
			this.edtPrezzoConvUtenteMW.Location = new System.Drawing.Point(8, 232);
			this.edtPrezzoConvUtenteMW.Name = "edtPrezzoConvUtenteMW";
			this.edtPrezzoConvUtenteMW.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoConvUtenteMW.TabIndex = 6;
			this.edtPrezzoConvUtenteMW.Text = "";
			// 
			// edtPrezzoConvUtente
			// 
			this.edtPrezzoConvUtente.BackColor = System.Drawing.Color.White;
			this.edtPrezzoConvUtente.Location = new System.Drawing.Point(8, 192);
			this.edtPrezzoConvUtente.MaxLength = 18;
			this.edtPrezzoConvUtente.Name = "edtPrezzoConvUtente";
			this.edtPrezzoConvUtente.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoConvUtente.TabIndex = 5;
			this.edtPrezzoConvUtente.Text = "";
			this.edtPrezzoConvUtente.Validating += new System.ComponentModel.CancelEventHandler(this.edtPrezzoConvUtente_Validating);
			this.edtPrezzoConvUtente.Validated += new System.EventHandler(this.edtPrezzoConvUtente_Validated);
			// 
			// lblQtyMAXAcquistabile
			// 
			this.lblQtyMAXAcquistabile.Location = new System.Drawing.Point(8, 256);
			this.lblQtyMAXAcquistabile.Name = "lblQtyMAXAcquistabile";
			this.lblQtyMAXAcquistabile.Size = new System.Drawing.Size(176, 16);
			this.lblQtyMAXAcquistabile.TabIndex = 8;
			this.lblQtyMAXAcquistabile.Text = "Quantit� MASSIMA Acquistabile";
			// 
			// lblPrezzoConvUtenteMWh
			// 
			this.lblPrezzoConvUtenteMWh.Location = new System.Drawing.Point(8, 216);
			this.lblPrezzoConvUtenteMWh.Name = "lblPrezzoConvUtenteMWh";
			this.lblPrezzoConvUtenteMWh.Size = new System.Drawing.Size(184, 16);
			this.lblPrezzoConvUtenteMWh.TabIndex = 7;
			this.lblPrezzoConvUtenteMWh.Text = "Prezzo Convenzionale Utente MWh";
			// 
			// lblPrezzoConvUtente
			// 
			this.lblPrezzoConvUtente.Location = new System.Drawing.Point(8, 176);
			this.lblPrezzoConvUtente.Name = "lblPrezzoConvUtente";
			this.lblPrezzoConvUtente.Size = new System.Drawing.Size(156, 16);
			this.lblPrezzoConvUtente.TabIndex = 6;
			this.lblPrezzoConvUtente.Text = "Prezzo Convenzionale Utente";
			// 
			// edtImporto
			// 
			this.edtImporto.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.edtImporto.Enabled = false;
			this.edtImporto.Location = new System.Drawing.Point(8, 152);
			this.edtImporto.MaxLength = 18;
			this.edtImporto.Name = "edtImporto";
			this.edtImporto.Size = new System.Drawing.Size(176, 20);
			this.edtImporto.TabIndex = 4;
			this.edtImporto.Text = "";
			this.tltInfo.SetToolTip(this.edtImporto, "Importo totale per la societa` ottenuto come somma tra il saldo precedente e i mo" +
				"vimenti pervenuti");
			this.edtImporto.Validating += new System.ComponentModel.CancelEventHandler(this.edtImporto_Validating);
			this.edtImporto.Validated += new System.EventHandler(this.edtImporto_Validated);
			// 
			// lblImporto
			// 
			this.lblImporto.Location = new System.Drawing.Point(8, 136);
			this.lblImporto.Name = "lblImporto";
			this.lblImporto.Size = new System.Drawing.Size(128, 16);
			this.lblImporto.TabIndex = 4;
			this.lblImporto.Text = "Budget per la Sessione";
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Location = new System.Drawing.Point(8, 56);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(76, 16);
			this.lblCodiceConto.TabIndex = 2;
			this.lblCodiceConto.Text = "Codice Conto";
			// 
			// lblRagioneSoc
			// 
			this.lblRagioneSoc.Location = new System.Drawing.Point(8, 16);
			this.lblRagioneSoc.Name = "lblRagioneSoc";
			this.lblRagioneSoc.Size = new System.Drawing.Size(88, 16);
			this.lblRagioneSoc.TabIndex = 1;
			this.lblRagioneSoc.Text = "Ragione Sociale";
			// 
			// cbRagioneSociale
			// 
			this.cbRagioneSociale.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.cbRagioneSociale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbRagioneSociale.Location = new System.Drawing.Point(8, 32);
			this.cbRagioneSociale.Name = "cbRagioneSociale";
			this.cbRagioneSociale.Size = new System.Drawing.Size(664, 21);
			this.cbRagioneSociale.TabIndex = 2;
			this.tltInfo.SetToolTip(this.cbRagioneSociale, "Elenco delle Societa\' per Ragione Sociale");
			// 
			// btnChiudi
			// 
			this.btnChiudi.Location = new System.Drawing.Point(603, 488);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 5;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa maschera");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnSalva
			// 
			this.btnSalva.Location = new System.Drawing.Point(520, 488);
			this.btnSalva.Name = "btnSalva";
			this.btnSalva.TabIndex = 4;
			this.btnSalva.Text = "&Salva";
			this.tltInfo.SetToolTip(this.btnSalva, "Salva tutte le modifiche effettuate sui dati");
			this.btnSalva.Click += new System.EventHandler(this.btnSalva_Click);
			// 
			// btnElimina
			// 
			this.btnElimina.Enabled = false;
			this.btnElimina.Location = new System.Drawing.Point(296, 488);
			this.btnElimina.Name = "btnElimina";
			this.btnElimina.TabIndex = 3;
			this.btnElimina.Text = "&Elimina";
			this.tltInfo.SetToolTip(this.btnElimina, "Cancella i dati di budget per la societa\' corrente");
			this.btnElimina.Visible = false;
			this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
			// 
			// btnReport
			// 
			this.btnReport.Location = new System.Drawing.Point(3, 488);
			this.btnReport.Name = "btnReport";
			this.btnReport.TabIndex = 6;
			this.btnReport.Text = "&Report";
			this.tltInfo.SetToolTip(this.btnReport, "Genera il file excel dei budgets");
			this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
			// 
			// btnImport
			// 
			this.btnImport.Location = new System.Drawing.Point(88, 488);
			this.btnImport.Name = "btnImport";
			this.btnImport.Size = new System.Drawing.Size(88, 23);
			this.btnImport.TabIndex = 7;
			this.btnImport.Text = "&Import Budgets";
			this.tltInfo.SetToolTip(this.btnImport, "Import del file dei dati di Budgets");
			this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
			// 
			// dlgEsportaXls
			// 
			this.dlgEsportaXls.Filter = "Xls file (*.xls)|*.xls|All files|*.*";
			// 
			// dlgImportXml
			// 
			this.dlgImportXml.Filter = "Xml file (*.xml)|*.xml|All files|*.*";
			// 
			// frmBudget
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(680, 519);
			this.Controls.Add(this.btnImport);
			this.Controls.Add(this.btnReport);
			this.Controls.Add(this.btnElimina);
			this.Controls.Add(this.btnSalva);
			this.Controls.Add(this.btnChiudi);
			this.Controls.Add(this.gbGenerale);
			this.Controls.Add(this.gbDatiSessione);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmBudget";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Dati di Budget";
			this.Load += new System.EventHandler(this.frmBudget_Load);
			this.gbDatiSessione.ResumeLayout(false);
			this.gbGenerale.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmBudget_Load(object sender, System.EventArgs e)
		{
			if (_MascheraReadOnly == false)
				AbilitaBottoni(); // Abilito i bottoni solo se la maschera NON e` readonly
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void edtImporto_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (edtImporto.Text == String.Empty)
				return;

			if (IsFormClosing())
				return;
		}

		private bool IsFormClosing()
		{
			bool closing = false;
			if (this.ActiveControl.Name.CompareTo("btnChiudi")==0)
				closing = true;
			return closing;
		}

		private void btnSalva_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (_dsBudgetsSocieta == null)
					return;

				// Setto il campo Residuo
				DataRow r = CurrentBudgetRow ;
				r.BeginEdit();
				if (rdbResiduoZero.Checked == true)
				{
					r["Residuo"] = 0 ;
				}
				if (rdbTuttoResiduo.Checked == true)
				{
					r["Residuo"] = -1 ;
				}
				if (rdbResiduoN.Checked == true)
				{
					try
					{
						r["Residuo"] = Converter.NumberStringToDecimal(edtResiduo.Text) ;
					}
					catch(Exception)
					{
						try
						{
							r["Residuo"] = Converter.CurrencyStringToDecimal(edtResiduo.Text) ;
						}
						catch(Exception)
						{
							MessageBox.Show("Valore del residuo non valido", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}
					}
				}
				r.EndEdit();
									
				
				// Chiamo la EndEdit per ogni riga della tabella Societa in modo da 
				// convalidare le modifiche effettuate dall'utente
				foreach (DataRow dr in SocietaDataTable.Rows)
				{
					dr.EndEdit();
				}

				// Chiamo la EndEdit per ogni riga della tabella Budget in modo da 
				// convalidare le modifiche effettuate dall'utente
				foreach (DataRow dr in BudgetsDataTable.Rows)
				{
					dr.EndEdit();
					if (dr.RowState == DataRowState.Modified)
					{
						dr["QtyMax"] = this.CalcolaQtyMAX();
						dr["PrezzoConvenzionaleUtenteMw"] = (decimal)(dr["PrezzoConvenzionaleUtente"]) / MWhPerCV; /*cento*/

						if ((decimal)dr["Importo"] < 0m)
						{
							MessageBox.Show("Inserire un importo non negativo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}
						if (((decimal)dr["Residuo"] <= 0) && (rdbResiduoN.Checked == true))
						{
							MessageBox.Show("Inserire un valore per il residuo maggiore di zero", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}
						if ((decimal)dr["PrezzoConvenzionaleUtente"] < 0m)
						{
							MessageBox.Show("Inserire un prezzo convenzionale non negativo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}

						if ((decimal)dr["Importo"] > decimal.Parse(new string('9', 15)))
						{
							MessageBox.Show("Il valore dell'importo e' troppo grande", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}
						if ((decimal)dr["PrezzoConvenzionaleUtente"] > decimal.Parse(new string('9', 15)))
						{
							MessageBox.Show("Il valore del prezzo convenzionale utente e' troppo grande", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}

						if ((decimal)dr["PrezzoConvenzionaleUtente"] > 0m)
						{
							if ((decimal)dr["PrezzoConvenzionaleUtente"] < Converter.CurrencyStringToDecimal(edtPrezzoConvenzionale.Text))
							{
								MessageBox.Show("Il valore del prezzo convenzionale utente e' minore del prezzo convenzionale", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
								return;
							}
						}
					}
				}

				bool IsDataSetUpdated = AggiornaDataSet(_dsBudgetsSocieta);
				if (IsDataSetUpdated)
					MessageBox.Show("Aggiornamento effettuato", "Messaggio", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return;
			}
		}

		private void btnElimina_Click(object sender, System.EventArgs e)
		{
			DataRow dr   = CurrentBudgetRow;
			DataTable dt = SocietaDataTable;

			DialogResult result = MessageBox.Show("Sei sicuro di voler cancellare i dati?", "Conferma cancellazione dati", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
			if (result  == DialogResult.No)
				return;

			if (dr != null)
			{
				dr["Residuo"] = 0m ;
				dr["ImportoProposto"] = 0m;
				dr["Importo"] = 0m;
				dr["PrezzoConvenzionaleUtente"] = 0m;
				dr["PrezzoConvenzionaleUtenteMw"] = 0m;
				dr["QtyMax"] = 0m;
				dr["QtyImpegnata"] = 0M;
				dr.EndEdit();

				AggiornaDataSet(_dsBudgetsSocieta);
				AbilitaBottoni();
			}
		}




		private void edtPrezzoConvUtente_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (IsFormClosing())
				return;

			if (edtPrezzoConvUtente.Text.Trim() == String.Empty)
				return;

			try
			{
				if (Converter.CurrencyStringToDecimal(edtPrezzoConvenzionale.Text) >
					Converter.CurrencyStringToDecimal(edtPrezzoConvUtente.Text))
				{
					MessageBox.Show("Inserire un Prezzo Convenzionale Utente maggiore o uguale al Prezzo Convenzionale", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
					e.Cancel = true; 
				}
			}
			catch(Exception)
			{
				e.Cancel = true;
			}
		}
		private void edtPrezzoConvUtente_Validated(object sender, System.EventArgs e)
		{
			AbilitaBottoni();

			// Esiste una relazione tra Prezzo Convenzionale Utente e 
			// Prezzo Convenzionale Utente al MW
			// che pero` dipende dall'anno di rifermento del CV.
			// 
			if (edtPrezzoConvUtente.Text.Trim() == String.Empty)
				return;

			try
			{
				decimal prezzoConvUtente = Converter.CurrencyStringToDecimal(edtPrezzoConvUtente.Text);

				// attenzione: se si mofica il rapporto di 100MWh per CV non funziona piu` niente!!
				decimal prezzoConvUtenteMw = prezzoConvUtente /MWhPerCV; //Stefano

				// Calcolo la Quantita' Max di CV acquistabili (se possibile)
				decimal qtyMax = CalcolaQtyMAX();
				if (qtyMax >= 0m)
					
					edtQtyMAXAcquistabile.Text = Converter.DecimalToIntegerString(qtyMax);
				edtPrezzoConvUtenteMW.Text = Converter.DecimalToCurrencyString(prezzoConvUtenteMw);
			}
			catch (Exception)
			{
				edtPrezzoConvUtenteMW.Text = "";
			}


		}

		private void edtSaldo_Validated(object sender, System.EventArgs e)
		{
			// notare che se arrivo qui societa.saldo e` stato gia` modificato.
			// Qui forzo il fatto che anche budget.importo deve seguire il saldo.

			// Rendo Read Only il campo edtSaldo
			edtSaldo.BackColor = edtImportoProposto.BackColor ;
			edtSaldo.Enabled = false ;
			DataRow dr = CurrentBudgetRow ;
			dr.BeginEdit();
			dr["Importo"] = Converter.CurrencyStringToDecimal(edtSaldo.Text);
			dr.EndEdit();

			decimal qtyMax = CalcolaQtyMAX();
			if (qtyMax >= 0m)
				edtQtyMAXAcquistabile.Text = Converter.DecimalToIntegerString(qtyMax);

			this.ImpostaAllarmePerDiscondanzaValoriDichiaratiValoriReali();
		}

		private void edtImporto_Validated(object sender, System.EventArgs e)
		{
			AbilitaBottoni();

			if (edtImporto.Text == String.Empty)
				return;

			try
			{
				decimal prezzoConvUtente = Converter.CurrencyStringToDecimal(edtPrezzoConvUtente.Text);

				// Qui c'e` un problema spinoso: la conversione tra prezzo a CV e prezzo a MWh
				// deve essere fatta per Anno (i CV hanno un anno di roferimento); infatti
				// esiste cv.MwCertificato.

				// attenzione se si modifica che un CV rappresenta 100MWh non funziona piu` niente.
				decimal prezzoConvUtenteMw = prezzoConvUtente /MWhPerCV; /*cento*/ //Stefano

				// Calcolo la Quantita' Max di CV acquistabili (se possibile)
				decimal qtyMax = CalcolaQtyMAX();
				if (qtyMax >= 0m)
					edtQtyMAXAcquistabile.Text = Converter.DecimalToIntegerString(qtyMax);
				edtPrezzoConvUtenteMW.Text = Converter.DecimalToCurrencyString(prezzoConvUtenteMw);
			}
			catch (Exception)
			{
			}

			this.ImpostaAllarmePerDiscondanzaValoriDichiaratiValoriReali();

			// Rendo Read Only il campo edtImporto
			edtImporto.BackColor = edtImportoProposto.BackColor ;
			edtImporto.Enabled = false ;
		}

		private decimal CalcolaQtyMAX()
		{	
			// Uno dei due campi utili al calcolo della Quantita' MAX di certificati
			// acquistabili e' vuoto => non posso effettuare il calcolo
			if ((edtPrezzoConvUtente.Text == String.Empty) || 
				(edtImporto.Text == String.Empty))
				return -1;

			try
			{
				decimal prezzoConvUtente = Converter.CurrencyStringToDecimal(edtPrezzoConvUtente.Text);
				decimal importo = Converter.CurrencyStringToDecimal(edtImporto.Text);

				decimal QtyMAX = importo/prezzoConvUtente;
				return decimal.Truncate(QtyMAX);
			}
			catch(Exception)
			{
				return 0;
			}
		}


		private void edtResiduo_Validated(object sender, System.EventArgs e)
		{
			try
			{
				edtResiduo.Text = Converter.DecimalToCurrencyString(Converter.NumberStringToDecimal(edtResiduo.Text));
			}
			catch(Exception)
			{
				try
				{
					edtResiduo.Text = Converter.DecimalToCurrencyString(Converter.CurrencyStringToDecimal(edtResiduo.Text));
				}
				catch(Exception)
				{
					MessageBox.Show("Valore del residuo non valido", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}
			}
		}

		private void rdbResiduoZero_CheckedChanged(object sender, System.EventArgs e)
		{
			if (rdbResiduoZero.Checked == true)
			{
				edtResiduo.Text = Converter.DecimalToCurrencyString(0);
				edtResiduo.BackColor = edtImportoProposto.BackColor ;
				edtResiduo.Enabled = false ;
			}
		}

		private void rdbTuttoResiduo_CheckedChanged(object sender, System.EventArgs e)
		{
			if (rdbTuttoResiduo.Checked == true)
			{
				edtResiduo.Text = Converter.DecimalToCurrencyString(0);
				edtResiduo.BackColor = edtImportoProposto.BackColor ;
				edtResiduo.Enabled = false ;
			}
		}

		private void CreaFileExcel(DataSet ds)
		{
			DataRow[] dtSocieta = ds.Tables["Societa"].Select("", "RagioneSociale, CodiceConto");
			DataRow[] dtBudgets;

			dlgEsportaXls.InitialDirectory = UtilityEnvironment.CommonAppDir;
			if (dlgEsportaXls.ShowDialog() != DialogResult.OK)
				return;

			this.Enabled = false;
			Application.DoEvents();
			this.Enabled = true;

			try
			{
				using (WaitCursor wc = new WaitCursor())
				{
					using (spApplication xlApp = new spApplication())
					{
						Excel.XlBordersIndex xlEdgeRight  = Excel.XlBordersIndex.xlEdgeRight;
						Excel.XlBordersIndex xlEdgeLeft   = Excel.XlBordersIndex.xlEdgeLeft;
						Excel.XlBordersIndex xlEdgeBottom = Excel.XlBordersIndex.xlEdgeBottom;
						Excel.XlBordersIndex xlEdgeTop    = Excel.XlBordersIndex.xlEdgeTop;

						Excel.XlHAlign xlHAlignGeneral    = Excel.XlHAlign.xlHAlignGeneral;

						string exportFileName = dlgEsportaXls.FileName;

						// xlApp.Visible = true;
						xlApp.SheetsInNewWorkbook = 1;

						spWorkbook xlBook = xlApp.Workbooks.Add();

						spWorksheet xlSheet = xlBook.Worksheets[1];
						xlSheet.Name = "Elenco Budgets";

						// Titolo
						// --------------------------------------------
						xlSheet.Cells[1, 1].Characters.Font.Size = 11;
						xlSheet.Cells[1, 1].Characters.Font.Bold = true;
						xlSheet.Cells[1, 1].Value = "Elenco Budgets";
						xlSheet.Cells.Range(xlSheet.Cells[1, 1], xlSheet.Cells[1, 5]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[1, 1], xlSheet.Cells[1, 5]).Merge();

						// Riga Intestazione
						// --------------------------------------------
						xlSheet.Cells.EntireRow[3].Characters.Font.Size = 10;
						xlSheet.Cells.EntireRow[3].Characters.Font.Bold = true;
    
						// Prima Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 6].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 6].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 1].Borders[xlEdgeLeft].LineStyle = 7;
						xlSheet.Cells[3, 1].Borders[xlEdgeLeft].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 6]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 6]).Merge();
						xlSheet.Cells[3, 1].Value = "Ragione Sociale";
    
						// Seconda Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 8].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 8].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 7], xlSheet.Cells[3, 8]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 7], xlSheet.Cells[3, 8]).Merge();
						xlSheet.Cells[3, 7].Value = "Codice Conto";
					    
						// Terza Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 12].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 12].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 9], xlSheet.Cells[3, 12]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 9], xlSheet.Cells[3, 12]).Merge();
						xlSheet.Cells[3, 9].Value = "Titolo Sessione";
					    
						// Quarta Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 14].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 14].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 13], xlSheet.Cells[3, 14]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 13], xlSheet.Cells[3, 14]).Merge();
						xlSheet.Cells[3, 13].Value = "Importo Versato";

						// Quinta Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 16].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 16].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 15], xlSheet.Cells[3, 16]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 15], xlSheet.Cells[3, 16]).Merge();
						xlSheet.Cells[3, 15].Value = "Importo Dichiarato";

						// --------------------------------------------
						xlSheet.Cells[3, 18].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 18].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 17], xlSheet.Cells[3, 18]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 17], xlSheet.Cells[3, 18]).Merge();
						xlSheet.Cells[3, 17].Value = "Prezzo Convenzionale Utente";

						// --------------------------------------------
						xlSheet.Cells[3, 20].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 20].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 19], xlSheet.Cells[3, 20]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 19], xlSheet.Cells[3, 20]).Merge();
						xlSheet.Cells[3, 19].Value = "Prezzo Convenzionale Utente MWh";

						// --------------------------------------------
						xlSheet.Cells[3, 22].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 22].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 21], xlSheet.Cells[3, 22]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 21], xlSheet.Cells[3, 22]).Merge();
						xlSheet.Cells[3, 21].Value = "Quantita' massima acquistabile";

						// --------------------------------------------
						xlSheet.Cells[3, 25].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 25].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 23], xlSheet.Cells[3, 25]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 23], xlSheet.Cells[3, 25]).Merge();
						xlSheet.Cells[3, 23].Value = "Gestione Residuo";
					    
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 25]).Borders[xlEdgeBottom].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 25]).Borders[xlEdgeTop].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 25]).Borders[xlEdgeBottom].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 25]).Borders[xlEdgeTop].Weight = 3;

						// RIGHE DATI
						int riga = 4;
						foreach (DataRow row in dtSocieta)
						{
							xlSheet.Cells.EntireRow[riga].Characters.Font.Size = 8;
							xlSheet.Cells.EntireRow[riga].Characters.Font.Bold = false;

							if ((riga & 1) == 0)
							{
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 25]).Interior.ColorIndex = 15;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 25]).Interior.Pattern = Excel.XlPattern.xlPatternSolid;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 25]).Interior.PatternColorIndex = Excel.XlPattern.xlPatternAutomatic;
							}
					        
							dtBudgets = ds.Tables["Budgets"].Select("IdSessione = '" + _IdSessione + "' AND IdSocieta = '" + (string)row["IdSocieta"] + "'" );

							xlSheet.Cells[riga, 1].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[riga, 1].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[riga, 6].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 6].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 6]).Merge();
							xlSheet.Cells[riga, 1].NumberFormat = "@";
							xlSheet.Cells[riga, 1].Value = (string)row["RagioneSociale"];
					        
							xlSheet.Cells[riga, 8].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 8].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 7], xlSheet.Cells[riga, 8]).Merge();
							xlSheet.Cells[riga, 7].NumberFormat = "@";
							xlSheet.Cells[riga, 7].Value = (string)row["CodiceConto"];
					        
							xlSheet.Cells[riga, 12].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 12].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 9], xlSheet.Cells[riga, 12]).Merge();
							xlSheet.Cells[riga, 9].NumberFormat = "@";
							xlSheet.Cells[riga, 9].Value = edtTitoloSessione.Text ;
					        
							xlSheet.Cells[riga, 14].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 14].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 13], xlSheet.Cells[riga, 14]).Merge();
							
							decimal d ;
							
							xlSheet.Cells[riga, 13].NumberFormat = "$ #,##0.00";							
							if (dtBudgets.Length > 0)
							{
								d = (decimal)dtBudgets[0]["Importo"] ;
							}
							else
							{
								d = 0m ;
							}
							// xlSheet.Cells[riga, 13].FormulaR1C1 = d.ToString("N2" ,new CultureInfo("en-US")) ;
							xlSheet.Cells[riga, 13].FormulaR1C1Object = d;

//							xlSheet.Cells[riga, 13].NumberFormat = "@";
//							if (dtBudgets.Length > 0)
//							{
//								xlSheet.Cells[riga, 13].Value = Converter.DecimalToCurrencyString((decimal)dtBudgets[0]["Importo"]);
//							}
//							else
//							{
//								xlSheet.Cells[riga, 13].Value = Converter.DecimalToCurrencyString(0);
//							}

							xlSheet.Cells[riga, 16].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 16].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 15], xlSheet.Cells[riga, 16]).Merge();
//							xlSheet.Cells[riga, 15].NumberFormat = "@";
//							if (dtBudgets.Length > 0)
//							{
//								xlSheet.Cells[riga, 15].Value = Converter.DecimalToCurrencyString((decimal)dtBudgets[0]["ImportoProposto"]);
//							}
//							else
//							{
//								xlSheet.Cells[riga, 15].Value = Converter.DecimalToCurrencyString(0);
//							}
							xlSheet.Cells[riga, 15].NumberFormat = "$ #,##0.00";
							if (dtBudgets.Length > 0)
							{
								d = (decimal)dtBudgets[0]["ImportoProposto"];
							}
							else
							{
								d = 0m ;
							}
							//xlSheet.Cells[riga, 15].FormulaR1C1 = d.ToString("N2" ,new CultureInfo("en-US")) ;
							xlSheet.Cells[riga, 15].FormulaR1C1Object = d;

							xlSheet.Cells[riga, 18].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 18].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 17], xlSheet.Cells[riga, 18]).Merge();
//							xlSheet.Cells[riga, 17].NumberFormat = "@";
//							if (dtBudgets.Length > 0)
//							{
//								xlSheet.Cells[riga, 17].Value = Converter.DecimalToCurrencyString((decimal)dtBudgets[0]["PrezzoConvenzionaleUtente"]);
//							}
//							else
//							{
//								xlSheet.Cells[riga, 17].Value = Converter.DecimalToCurrencyString(0);
//							}
							xlSheet.Cells[riga, 17].NumberFormat = "$ #,##0.00";
							if (dtBudgets.Length > 0)
							{
								d = (decimal)dtBudgets[0]["PrezzoConvenzionaleUtente"];
							}
							else
							{
								d = 0m ;
							}
							// xlSheet.Cells[riga, 17].FormulaR1C1 = d.ToString("N2" ,new CultureInfo("en-US")) ;
							xlSheet.Cells[riga, 17].FormulaR1C1Object = d;

							xlSheet.Cells[riga, 20].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 20].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 19], xlSheet.Cells[riga, 20]).Merge();
//							xlSheet.Cells[riga, 19].NumberFormat = "@";
//							if (dtBudgets.Length > 0)
//							{
//								xlSheet.Cells[riga, 19].Value = Converter.DecimalToCurrencyString((decimal)dtBudgets[0]["PrezzoConvenzionaleUtenteMw"]);
//							}
//							else
//							{
//								xlSheet.Cells[riga, 19].Value = Converter.DecimalToCurrencyString(0);
//							}
							xlSheet.Cells[riga, 19].NumberFormat = "$ #,##0.00";
							if (dtBudgets.Length > 0)
							{
								d = (decimal)dtBudgets[0]["PrezzoConvenzionaleUtenteMw"];
							}
							else
							{
								d = 0m ;
							}
							// xlSheet.Cells[riga, 19].FormulaR1C1 = d.ToString("N2" ,new CultureInfo("en-US")) ;
							xlSheet.Cells[riga, 19].FormulaR1C1Object = d;

							xlSheet.Cells[riga, 22].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 22].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 21], xlSheet.Cells[riga, 22]).Merge();
//							xlSheet.Cells[riga, 21].NumberFormat = "@";
//							if (dtBudgets.Length > 0)
//							{
//								xlSheet.Cells[riga, 21].Value = Converter.DecimalToNumberString((decimal)dtBudgets[0]["QtyMax"]);
//							}
//							else
//							{
//								xlSheet.Cells[riga, 21].Value = Converter.DecimalToNumberString(0);
//							}
							xlSheet.Cells[riga, 21].NumberFormat = "#,##0";
							if (dtBudgets.Length > 0)
								d = (decimal)dtBudgets[0]["QtyMax"];
							else
								d = 0m;
							// xlSheet.Cells[riga, 21].FormulaR1C1 = d.ToString("N2" ,new CultureInfo("en-US")) ;
							xlSheet.Cells[riga, 21].FormulaR1C1Object = d;

							xlSheet.Cells[riga, 25].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 25].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 23], xlSheet.Cells[riga, 25]).Merge();
							xlSheet.Cells[riga, 23].NumberFormat = "@";
							if (dtBudgets.Length > 0)
							{
								if ((decimal)dtBudgets[0]["Residuo"] == 0)
								{
									xlSheet.Cells[riga, 23].Value = "Rimborsare l'intero importo." ;
								}
								else
								{
									if ((decimal)dtBudgets[0]["Residuo"] == -1)
									{
										xlSheet.Cells[riga, 23].Value = "Non effettuare alcun rimborso." ;
									}
									else
									{
										xlSheet.Cells[riga, 23].Value = "Residuo di al piu' di " + Converter.DecimalToCurrencyString((decimal)dtBudgets[0]["Residuo"]);
									}
								}
							}
							else
							{
								xlSheet.Cells[riga, 23].Value = "" ;
							}
							
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 25]).Borders[xlEdgeBottom].LineStyle = 7;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 25]).Borders[xlEdgeBottom].Weight = 3;
							
							riga++ ;
						}
						
						try { System.IO.File.Delete(exportFileName); } 
						catch (Exception) {} // eccezione se il file non esiste
						xlSheet.SaveAs(exportFileName);
				
						// xlApp.Visible = true;
						xlBook.Close();
						xlApp.Quit();
					}
				}
				MessageBox.Show("Foglio Excel generato con successo", "Messaggio", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnReport_Click(object sender, System.EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;

			// salvo il da nel db
			try
			{
				if (_dsBudgetsSocieta == null)
					return;

				// Setto il campo Residuo
				DataRow r = CurrentBudgetRow ;
				r.BeginEdit();
				if (rdbResiduoZero.Checked == true)
				{
					r["Residuo"] = 0 ;
				}
				if (rdbTuttoResiduo.Checked == true)
				{
					r["Residuo"] = -1 ;
				}
				if (rdbResiduoN.Checked == true)
				{
					try
					{
						r["Residuo"] = Converter.NumberStringToDecimal(edtResiduo.Text) ;
					}
					catch(Exception)
					{
						try
						{
							r["Residuo"] = Converter.CurrencyStringToDecimal(edtResiduo.Text) ;
						}
						catch(Exception)
						{
							MessageBox.Show("Valore del residuo non valido", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}
					}
				}
				r.EndEdit();
									

				// Chiamo la EndEdit per ogni riga della tabella Budget in modo da 
				// convalidare le modifiche effettuate dall'utente
				foreach (DataRow dr in BudgetsDataTable.Rows)
				{
					dr.EndEdit();
					if (dr.RowState == DataRowState.Modified)
					{
						dr["QtyMax"] = this.CalcolaQtyMAX();
						dr["PrezzoConvenzionaleUtenteMw"] = (decimal)(dr["PrezzoConvenzionaleUtente"]) / MWhPerCV; /*cento*/ //Stefano

						if ((decimal)dr["Importo"] < 0m)
						{
							MessageBox.Show("Inserire un importo non negativo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}
						if (((decimal)dr["Residuo"] <= 0) && (rdbResiduoN.Checked == true))
						{
							MessageBox.Show("Inserire un valore per il residuo maggiore di zero", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}
						if ((decimal)dr["PrezzoConvenzionaleUtente"] < 0m)
						{
							MessageBox.Show("Inserire un prezzo convenzionale non negativo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}

						if ((decimal)dr["Importo"] > decimal.Parse(new string('9', 15)))
						{
							MessageBox.Show("Il valore dell'importo e' troppo grande", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}
						if ((decimal)dr["PrezzoConvenzionaleUtente"] > decimal.Parse(new string('9', 15)))
						{
							MessageBox.Show("Il valore del prezzo convenzionale utente e' troppo grande", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
							return;
						}

						if ((decimal)dr["PrezzoConvenzionaleUtente"] > 0)
						{
							if ((decimal)dr["PrezzoConvenzionaleUtente"] < Converter.CurrencyStringToDecimal(edtPrezzoConvenzionale.Text))
							{
								MessageBox.Show("Il valore del prezzo convenzionale utente e' minore del prezzo convenzionale", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
								return;
							}
						}
					}
				}

				bool IsDataSetUpdated = AggiornaDataSet(_dsBudgetsSocieta);
//				if (IsDataSetUpdated)
//					MessageBox.Show("Aggiornamento effettuato", "Messaggio", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return;
			}

			// Genero il file Excel
			CreaFileExcel(_dsBudgetsSocieta);
		}

		private void rdbResiduoN_CheckedChanged(object sender, System.EventArgs e)
		{
			edtResiduo.BackColor = Color.White ;
			edtResiduo.Enabled = true ;
		}

		private void btnImport_Click(object sender, System.EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;

			// Importo il file Xml dei Budgets
			// ImportXmlBudgets();
			dlgImportXml.InitialDirectory = UtilityEnvironment.CommonAppDir;
			if (dlgImportXml.ShowDialog() != DialogResult.OK)
				return;

			string FileXml = dlgImportXml.FileName ;
			
			frmBudgetXML frm = new frmBudgetXML(_dtSessioneAttiva, _dsBudgetsSocieta, _IdSessione, FileXml);
			frm.ShowDialog(this);
		}

		private void SettaResiduo()
		{
			DataRow r = CurrentBudgetRow ;
			decimal residuo = (decimal)r["Residuo"] ;
			if (residuo == 0m)
			{
				rdbResiduoZero.Checked = true ;
				edtResiduo.Text = Converter.DecimalToCurrencyString(0);
			}
			else if (residuo == -1m)
			{
				rdbTuttoResiduo.Checked = true ;
				edtResiduo.Text = Converter.DecimalToCurrencyString(0);
			}
			else
			{
				rdbResiduoN.Checked = true ;
				edtResiduo.Text = Converter.DecimalToCurrencyString((decimal)r["Residuo"]); ;
			}
		}
		void ImpostaAllarmePerDiscondanzaValoriDichiaratiValoriReali()
		{
			decimal saldoDichiarato   = (decimal)CurrentBudgetRow["SaldoProposto"];
			decimal importoDichiarato = (decimal)CurrentBudgetRow["SaldoProposto"] + (decimal)CurrentBudgetRow["ImportoProposto"];

			decimal saldoReale        = (decimal)CurrentSocietaRow["Saldo"];
			decimal importoReale      = (decimal)CurrentBudgetRow["Importo"];

			bool dichiarazioneDiBudgetEffettuata = saldoDichiarato > 0 || importoDichiarato > 0;

			if (saldoReale != saldoDichiarato && dichiarazioneDiBudgetEffettuata)
				lblSaldo.ForeColor = Color.Red;
			else
				lblSaldo.ForeColor = Color.Black;

			if (importoReale != importoDichiarato && dichiarazioneDiBudgetEffettuata)
				lblImporto.ForeColor = Color.Red;
			else
				lblImporto.ForeColor = Color.Black;
		}

		private void btnModificaImporto_Click(object sender, System.EventArgs e)
		{
			DialogResult result = MessageBox.Show("Sei sicuro di voler modificare il campo 'Budget per la Sessione' ?", "Conferma cancellazione dati", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
			if (result  == DialogResult.No)
				return;
			edtImporto.BackColor = Color.White ;
			edtImporto.Enabled = true ;
		}

		private void btnModificaSaldo_Click(object sender, System.EventArgs e)
		{
			if (edtImporto.Text == edtSaldo.Text)
			{
				DialogResult result = MessageBox.Show("Sei sicuro di voler modificare il campo 'Saldo della Sessione precedente' ?", "Conferma cancellazione dati", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
				if (result  == DialogResult.No)
					return;
				edtSaldo.BackColor = Color.White ;
				edtSaldo.Enabled = true ;
			}
			else
			{
				MessageBox.Show("Non e' possibile modificare il 'Saldo della Sessione precedente' !", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}
	}
}
