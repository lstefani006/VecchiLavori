using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using ExcelHelper;
using System.Text;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmStoricoUtenti.
	/// </summary>
	public class frmStoricoUtenti : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnEsci;
		private System.Windows.Forms.DataGrid dgStorico;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private DataSet _dsStorico = null ;
		private DataTable _dtStorico = null ;
		private DataView _dvStorico = null ;

		public frmStoricoUtenti()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			SetDataGridMapping();

			_dsStorico = GetLista() ;
			
			BindDataGridDataSource(_dsStorico);
		}

		private void SetDataGridMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[10];
			dgCol[0] = new DataGridTextBoxColumn();
			dgCol[1] = new DataGridTextBoxColumn();
			for (int i = 2; i < dgCol.Length - 1; ++i)
				dgCol[i] = new utDataGridColoredTextBoxColumn();
			dgCol[dgCol.Length - 1] = new DataGridTextBoxColumn();


			int index = 0;

			// Colonna
			dgCol[index].HeaderText = "Time Stamp";
			dgCol[index].MappingName = "TSModifica";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 130;

			index++;
			dgCol[index].HeaderText = "ID";
			dgCol[index].MappingName = "IdUtente";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 230;


			// Colonna 0
			index++;
			dgCol[index].HeaderText = "Nominativo";
			dgCol[index].MappingName = "Nominativo";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 110;

			index++;
			// Colonna 1
			dgCol[index].HeaderText = "Codice Fiscale";
			dgCol[index].MappingName = "CodiceFiscale";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 110;

			index++;
			// Colonna 2
			dgCol[index].HeaderText = "Telefono";
			dgCol[index].MappingName = "Telefono";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 110;

			// Colonna 3
			index++;
			dgCol[index].HeaderText = "FAX";
			dgCol[index].MappingName = "Fax";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 110;

			// Colonna 4
			index++;
			dgCol[index].HeaderText = "Email";
			dgCol[index].MappingName = "Email";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 110;

			// Colonna 5
			index++;
			dgCol[index].HeaderText = "Tipo Utente";
			dgCol[index].MappingName = "TipoUtente";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 110;

			// Colonna 6
			index++;
			dgCol[index].HeaderText = "Stato Utente";
			dgCol[index].MappingName = "StatoUtente";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 110;

			// Colonna 8
			index++;
			dgCol[index].HeaderText = "Autore Modifica";
			dgCol[index].MappingName = "AutoreModifica";
			dgCol[index].NullText = "" ;
			dgCol[index].Width = 110;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Utenti";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgStorico.TableStyles.Add(dgStyle);
		}

		public DataSet GetLista()
		{
			bool Cancelled = false;
			if (Cancelled)
			{
				return new CVAdmin_Main.CVAdminWSBLUtenti.BLUtenti().GetLstStorico();
			}
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdminWSBLUtenti.BLUtenti().GetLstStorico");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}

		public void BindDataGridDataSource(DataSet ds)
		{
			// Effettuo il DataBinding del DataSet con il DataGrid
			if (ds != null)
			{
				_dtStorico = ds.Tables[0];
				_dvStorico = new DataView(_dtStorico);
				_dvStorico.AllowDelete	= false;
				_dvStorico.AllowNew		= false;
				_dvStorico.AllowEdit	= false;
				_dvStorico.Sort			= "TSModifica";
				// _dvStorico.RowFilter	= filter ;

				dgStorico.DataSource	= _dvStorico;
				dgStorico.AllowSorting = false;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
					components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmStoricoUtenti));
			this.btnEsci = new System.Windows.Forms.Button();
			this.dgStorico = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dgStorico)).BeginInit();
			this.SuspendLayout();
			// 
			// btnEsci
			// 
			this.btnEsci.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnEsci.Location = new System.Drawing.Point(632, 296);
			this.btnEsci.Name = "btnEsci";
			this.btnEsci.Size = new System.Drawing.Size(88, 24);
			this.btnEsci.TabIndex = 0;
			this.btnEsci.Text = "&Chiudi";
			this.btnEsci.Click += new System.EventHandler(this.button1_Click);
			// 
			// dgStorico
			// 
			this.dgStorico.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgStorico.DataMember = "";
			this.dgStorico.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgStorico.Location = new System.Drawing.Point(0, 0);
			this.dgStorico.Name = "dgStorico";
			this.dgStorico.Size = new System.Drawing.Size(728, 288);
			this.dgStorico.TabIndex = 1;
			// 
			// frmStoricoUtenti
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(728, 325);
			this.Controls.Add(this.dgStorico);
			this.Controls.Add(this.btnEsci);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmStoricoUtenti";
			this.Text = "Storico Utenti";
			((System.ComponentModel.ISupportInitialize)(this.dgStorico)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}
	}


	class utDataGridColoredTextBoxColumn : DataGridTextBoxColumn 
	{
		protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm, 
			int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight) 
		{ 
			Brush f = _nero;
			try
			{
				DataView dv = (DataView)cm.List;

				DataRow dr = dv[rowNum].Row;

				string id = (string)dr["IdUtente"];
				object a  = dr[this.MappingName];

				bool rosso = false;
				for (int i = rowNum + 1; i < cm.List.Count; ++i)
				{
					DataRow dr2 = dv[i].Row;
					string id2 = (string)dr2["IdUtente"];
					if (id == id2)
					{
						object b  = dr2[this.MappingName];
						if (a == null && b != null) rosso = true;
						else if (a != null && b == null) rosso = true;
						else rosso = !a.Equals(b);

						break;
					}
				}

				if (rosso)
					f = _rosso;
			}
			catch (Exception ex)
			{
				Debug.Assert(false);
			}


			base.Paint(g, bounds, cm, rowNum, backBrush, f, alignToRight); 
		}

		static Brush _rosso = new SolidBrush(Color.Red);
		static Brush _nero  = new SolidBrush(Color.Black);
	} 

}
