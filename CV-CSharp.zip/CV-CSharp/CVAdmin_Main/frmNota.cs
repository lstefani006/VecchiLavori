using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmNota.
	/// </summary>
	public class frmNota : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel pnlNota;
		private System.Windows.Forms.Panel pnlButtons;
		private System.Windows.Forms.Button btnSalva;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.RichTextBox rtbNota;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private DataRow _drRichiesta = null;

		public frmNota()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		public frmNota(DataRow dr)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			_drRichiesta = dr;
			if (_drRichiesta == null)
			{
				DisabilitaComponenti();
				return;
			}
			rtbNota.Text = _drRichiesta["Nota"].ToString();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Funzioni Interne

		private void Chiudi()
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void DisabilitaComponenti()
		{
			btnSalva.Enabled = false;
			pnlNota.Enabled = false;
			btnChiudi.Enabled = true;
		}


		#endregion

		#region Chiamate ai Web Services

		private bool UpdateNota(string IdRichiestaRegSoc, string Nota)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLRichiesta.BLRichiesta.UpdateNota", 
				IdRichiestaRegSoc,
				Nota);

			if (Cancelled)
				return false;
			return true;
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmNota));
			this.pnlNota = new System.Windows.Forms.Panel();
			this.rtbNota = new System.Windows.Forms.RichTextBox();
			this.pnlButtons = new System.Windows.Forms.Panel();
			this.btnSalva = new System.Windows.Forms.Button();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.pnlNota.SuspendLayout();
			this.pnlButtons.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlNota
			// 
			this.pnlNota.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.rtbNota});
			this.pnlNota.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlNota.Name = "pnlNota";
			this.pnlNota.Size = new System.Drawing.Size(314, 236);
			this.pnlNota.TabIndex = 0;
			// 
			// rtbNota
			// 
			this.rtbNota.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtbNota.MaxLength = 255;
			this.rtbNota.Name = "rtbNota";
			this.rtbNota.Size = new System.Drawing.Size(314, 236);
			this.rtbNota.TabIndex = 0;
			this.rtbNota.Text = "";
			// 
			// pnlButtons
			// 
			this.pnlButtons.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.btnSalva,
																					 this.btnChiudi});
			this.pnlButtons.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlButtons.Location = new System.Drawing.Point(0, 236);
			this.pnlButtons.Name = "pnlButtons";
			this.pnlButtons.Size = new System.Drawing.Size(314, 30);
			this.pnlButtons.TabIndex = 1;
			// 
			// btnSalva
			// 
			this.btnSalva.Location = new System.Drawing.Point(156, 5);
			this.btnSalva.Name = "btnSalva";
			this.btnSalva.TabIndex = 3;
			this.btnSalva.Text = "&Salva";
			this.btnSalva.Click += new System.EventHandler(this.btnSalva_Click);
			// 
			// btnChiudi
			// 
			this.btnChiudi.Location = new System.Drawing.Point(236, 5);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 2;
			this.btnChiudi.Text = "&Chiudi";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// frmNota
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(314, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pnlButtons,
																		  this.pnlNota});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmNota";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Nota";
			this.pnlNota.ResumeLayout(false);
			this.pnlButtons.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Eventi della Form
		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			Chiudi();
		}

		private void btnSalva_Click(object sender, System.EventArgs e)
		{
			if (UpdateNota(_drRichiesta["IdRichiestaRegSoc"].ToString(), rtbNota.Text))
			{
				MessageBox.Show("Nota salvata correttamente", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Information); 
				_drRichiesta["Nota"] = rtbNota.Text;
				_drRichiesta.EndEdit();
			}
			else
			{
				MessageBox.Show("Errore durante il salvataggio", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			Chiudi();
			return;
		}

		#endregion
	}
}
