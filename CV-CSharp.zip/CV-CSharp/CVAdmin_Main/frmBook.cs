using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;
using System.Data;
using CVAdmin_Main.CVAdminWSBLBudget;
using System.Diagnostics;
using System.Web.Services.Protocols;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmBook.
	/// </summary>
	public class frmBook : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ComboBox cbAnno;
		private System.Windows.Forms.Label lblAnno;
		private System.Windows.Forms.ToolTip tltInfo;
		private System.Windows.Forms.Button btnChiudi;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.DataGrid dgBookAcquisti;
		private System.Windows.Forms.GroupBox gbOfferte;
		private System.Windows.Forms.DataGrid dgBookVendita;

		private DateTime	_dbTime;
		private DataSet		_dsCurrentWebSession;
		private DataView	_dvAcquisti;
		private DataView	_dvVendite;
		private string		_IdSessione;
		private string		_StatoSessione;
		private bool		_IsSessionEnabled;
		private bool		_formError;
		
		internal class cbBind
		{
			public cbBind(string s) { _Name = s; }
			public cbBind(string name, string val) { _Name = name; _Value = val; }
			public string Name { get { return _Name; } }
			public string Value { get { return _Value; } }
			string _Name;
			string _Value;
		}

		public frmBook()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			InitLocalVariables();

			// Mappaggio delle colonne dei DataSet con le rispettive DataGrid
			SetDataGridAcquistiMapping();
			SetDataGridVenditaMapping();
			
			// Recupero la Data dal DataBase
//			_dbTime = new DateTime(1900,1,1);
			if (!CVAdmin_Main.DbTime.GetDbSystemDate(out _dbTime))
			{
				DisabilitaComponenti();
				_formError = true;
				return;
			}
			
			// Creo gli oggetti che dovranno essere collegati poi alla ComboBox
			// relativa agli Anni di Riferimento
			int AnnoMin = 0;
			int AnnoMax = 0;
			bool ris = ContrattaCVAnnoMin(_dbTime.Month, out AnnoMin, out AnnoMax) ;
			cbBind[] cbList = null ; 
			if (ris == true)
			{
				cbList = new cbBind[AnnoMax-AnnoMin+2];
				cbList[0] = new cbBind("<Tutti>", "");
				for (int i=AnnoMin;i<=AnnoMax;i++)
				{
					cbList[i-AnnoMin+1] = new cbBind(i.ToString(), i.ToString());
				}
			}
			else
			{
				cbList = new cbBind[AnnoMax-AnnoMin+1];
				cbList[0] = new cbBind("<Tutti>", "");
				for (int i=AnnoMin+1;i<=AnnoMax;i++)
				{
					cbList[i-(AnnoMin+1)+1] = new cbBind(i.ToString(), i.ToString());
				}
			}

//			cbBind [] cbList = 
//			{ 
//				new cbBind("<Tutti>", ""),
//				new cbBind((_dbTime.Year-1).ToString(), (_dbTime.Year-1).ToString()), //ToString OK
//				new cbBind(_dbTime.Year.ToString(), _dbTime.Year.ToString()),//ToString OK
//				new cbBind((_dbTime.Year+1).ToString(), (_dbTime.Year+1).ToString())//ToString OK
//			};

			// Binding dell'Array con la ComboBox
			cbAnno.DisplayMember = "Name"; 
			cbAnno.ValueMember   = "Value";
			cbAnno.DataSource	 = cbList;

			// Prelevo la Sessione Corrente...
			_dsCurrentWebSession = this.GetCurrentWebSession();

			if (_dsCurrentWebSession != null)
			{
				// e le relative informazioni
				_IdSessione = (string)_dsCurrentWebSession.Tables[0].Rows[0]["IdSessione"];;
				_StatoSessione = (string)_dsCurrentWebSession.Tables[0].Rows[0]["StatoSessione"];
				_IsSessionEnabled = this.IsSessionEnabled(_IdSessione);
			}
			else
			{
				_formError = true;
				DisabilitaComponenti();
				return;
			}

			// Recupero il Book di acquisto di tutti gli Anni di riferimento 
			// (Anno Riferimento = "") in modo da effettuare un'unica chiamata al DB.
			// Cambiando Anno di riferimento filtro solo le righe che coincidono
			// con l'Anno di riferimento selezionato
			DataSet dsAcquisto = this.GetBookAcquisto(_IdSessione, "");
			if (dsAcquisto != null)
			{
				_dvAcquisti = new DataView(dsAcquisto.Tables[0]);
				_dvAcquisti.AllowDelete = false;
				_dvAcquisti.AllowNew = false;
				_dvAcquisti.AllowEdit = false;
				_dvAcquisti.ApplyDefaultSort = false; 
				dgBookAcquisti.DataSource = _dvAcquisti;
				//SizeColumnsToContent(dgBookAcquisti, -1);
			}
			else
			{
				_formError = true;
				DisabilitaComponenti();
				return;
			}
			// recupero il Book Vendita
			DataSet dsVendita = this.GetBookVendita(_IdSessione, "");
			if (dsVendita != null)
			{
				_dvVendite = new DataView(dsVendita.Tables[0]);
				_dvVendite.AllowDelete = false;
				_dvVendite.AllowNew = false;
				_dvVendite.AllowEdit = false;
				_dvVendite.ApplyDefaultSort = false;
				dgBookVendita.DataSource = _dvVendite;
				//SizeColumnsToContent(dgBookVendita, -1);
			}
			else
			{
				DisabilitaComponenti();
				_formError = true;
				return;
			}

			// Quando cambio Anno di Riferimento nella Combo Box gestisco
			// il cambiamento attraverso la CallBack
			BindingManagerBase bm = cbAnno.BindingContext[cbList]; 
			bm.PositionChanged += new EventHandler(cbAnno_PositionChanged);
			DataGridTableStyle d = dgBookVendita.TableStyles[0];
			
// TODO LEO FLAVIO si pianta dentro AutoSizeColAcquisti
//			for (int i = 0; i < dgBookAcquisti.TableStyles[0].GridColumnStyles.Count; i++ )
//			{
//				AutoSizeColAcquisti(i);
//			}
		}

		private void InitLocalVariables()
		{
			_dsCurrentWebSession = null;
			_dvAcquisti = null;
			_dvVendite = null;
			_IdSessione = null;
			_StatoSessione = null;
			_IsSessionEnabled = false;
			_formError = false;
		}

		private void DisabilitaComponenti()
		{
			cbAnno.Enabled = false;
			dgBookAcquisti.Enabled = false;
			dgBookVendita.Enabled = false;
			btnChiudi.Enabled = true;
		}

		private void cbAnno_PositionChanged(object sender, EventArgs e)
		{
			BindingManagerBase bm = (BindingManagerBase) sender;
			if (bm.Current.GetType() != typeof(cbBind))
				return;
			cbBind item = (cbBind)bm.Current;
			// In funzione di cio' che ho selezionato nella ComboBox...
			string filter = null;

			//...filtro le righe dei DataSet da visualizzare nelle DataGrid
			filter = "AnnoRiferimento LIKE '" + item.Value + "%'";
			if (_dvAcquisti != null)
			{
				_dvAcquisti.RowFilter = filter;
				//SizeColumnsToContent(dgBookAcquisti, -1);
			}

			if (_dvVendite != null)
			{
				_dvVendite.RowFilter = filter;
				//SizeColumnsToContent(dgBookVendita, -1);
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBook));
			this.cbAnno = new System.Windows.Forms.ComboBox();
			this.lblAnno = new System.Windows.Forms.Label();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.dgBookVendita = new System.Windows.Forms.DataGrid();
			this.dgBookAcquisti = new System.Windows.Forms.DataGrid();
			this.gbOfferte = new System.Windows.Forms.GroupBox();
			((System.ComponentModel.ISupportInitialize)(this.dgBookVendita)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgBookAcquisti)).BeginInit();
			this.gbOfferte.SuspendLayout();
			this.SuspendLayout();
			// 
			// cbAnno
			// 
			this.cbAnno.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbAnno.Location = new System.Drawing.Point(46, 7);
			this.cbAnno.Name = "cbAnno";
			this.cbAnno.Size = new System.Drawing.Size(140, 21);
			this.cbAnno.TabIndex = 0;
			// 
			// lblAnno
			// 
			this.lblAnno.Location = new System.Drawing.Point(4, 9);
			this.lblAnno.Name = "lblAnno";
			this.lblAnno.Size = new System.Drawing.Size(36, 16);
			this.lblAnno.TabIndex = 4;
			this.lblAnno.Text = "Anno";
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnChiudi.Location = new System.Drawing.Point(692, 312);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.Size = new System.Drawing.Size(75, 22);
			this.btnChiudi.TabIndex = 3;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa finestra");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// dgBookVendita
			// 
			this.dgBookVendita.AllowNavigation = false;
			this.dgBookVendita.AllowSorting = false;
			this.dgBookVendita.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.dgBookVendita.CaptionText = "Offerte Vendita";
			this.dgBookVendita.DataMember = "";
			this.dgBookVendita.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgBookVendita.Location = new System.Drawing.Point(382, 19);
			this.dgBookVendita.Name = "dgBookVendita";
			this.dgBookVendita.Size = new System.Drawing.Size(388, 249);
			this.dgBookVendita.TabIndex = 8;
			this.tltInfo.SetToolTip(this.dgBookVendita, "Book Vendita");
			// 
			// dgBookAcquisti
			// 
			this.dgBookAcquisti.AllowNavigation = false;
			this.dgBookAcquisti.AllowSorting = false;
			this.dgBookAcquisti.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left);
			this.dgBookAcquisti.CaptionText = "Offerte Acquisto";
			this.dgBookAcquisti.DataMember = "";
			this.dgBookAcquisti.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgBookAcquisti.Location = new System.Drawing.Point(6, 19);
			this.dgBookAcquisti.Name = "dgBookAcquisti";
			this.dgBookAcquisti.Size = new System.Drawing.Size(374, 249);
			this.dgBookAcquisti.TabIndex = 6;
			this.tltInfo.SetToolTip(this.dgBookAcquisti, "Book Acquisto");
			// 
			// gbOfferte
			// 
			this.gbOfferte.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.gbOfferte.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.dgBookVendita,
																					this.dgBookAcquisti});
			this.gbOfferte.Location = new System.Drawing.Point(2, 36);
			this.gbOfferte.Name = "gbOfferte";
			this.gbOfferte.Size = new System.Drawing.Size(776, 272);
			this.gbOfferte.TabIndex = 6;
			this.gbOfferte.TabStop = false;
			this.gbOfferte.Text = " Offerte ";
			// 
			// frmBook
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(780, 349);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.gbOfferte,
																		  this.btnChiudi,
																		  this.lblAnno,
																		  this.cbAnno});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmBook";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Book";
			this.Load += new System.EventHandler(this.frmBook_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgBookVendita)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgBookAcquisti)).EndInit();
			this.gbOfferte.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		private DataSet GetCurrentWebSession()
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ws = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginGetCurrentWebSession(null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return null;

				// il Web Service ha risposto... prendo il risultato
				return ws.EndGetCurrentWebSession(asr);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return null;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return null;
			}
		}

		private bool ContrattaCVAnnoMin(int month, out int AnnoMin, out int AnnoMax)
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ws = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ws);

				return ws.ContrattaCVAnnoMin(month, out AnnoMin, out AnnoMax);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				AnnoMin = 0 ;
				AnnoMax = 0 ;
				return false;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				AnnoMin = 0 ;
				AnnoMax = 0 ;
				return false;
			}
		}

		private bool IsSessionEnabled(string IdSessione)
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ws = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginIsEnabled(IdSessione, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return false;

				// il Web Service ha risposto... prendo il risultato
				return ws.EndIsEnabled(asr);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return false;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return false;
			}
		}


		private DataSet GetBookAcquisto(string IdSessione, string AnnoRiferimento)
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ws = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginGetBookAcquisto(IdSessione, AnnoRiferimento, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return null;

				// il Web Service ha risposto... prendo il risultato
				return ws.EndGetBookAcquisto(asr);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return null;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return null;
			}
		}

		private DataSet GetBookVendita(string IdSessione, string AnnoRiferimento)
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ws = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore
				IAsyncResult asr = ws.BeginGetBookVendita(IdSessione, AnnoRiferimento, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return null;

				// il Web Service ha risposto... prendo il risultato
				return ws.EndGetBookVendita(asr);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				return null;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return null;
			}
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void SetDataGridAcquistiMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[3];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			int index = 0;
			dgCol[index].HeaderText = "Anno Riferimento";
			dgCol[index].MappingName = "AnnoRiferimento";
			dgCol[index].Width = 110;

			index++;
			dgCol[index].HeaderText = "Quantit� Residua";
			dgCol[index].MappingName = "QtyResidua";
			dgCol[index].Width = 110;

			index++;
			dgCol[index].HeaderText = "Prezzo Unitario";
			dgCol[index].MappingName = "PrezzoUnitario";
			dgCol[index].Width = 110;
			dgCol[index].Format = "c";
			
			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "BookAcquisto";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgBookAcquisti.TableStyles.Add(dgStyle);
		}

		private void SetDataGridVenditaMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[3];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			int index = 0;
			dgCol[index].HeaderText  = "Prezzo Unitario";
			dgCol[index].MappingName = "PrezzoUnitario";
			dgCol[index].Width = 110;
			dgCol[index].Format = "c";

			index++;
			dgCol[index].HeaderText  = "Quantit� Residua";
			dgCol[index].MappingName = "QtyResidua";
			dgCol[index].Width = 110;

			index++;
			dgCol[index].HeaderText  = "Anno Riferimento";
			dgCol[index].MappingName = "AnnoRiferimento";
			dgCol[index].Width = 110;
			
			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "BookVendita";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgBookVendita.TableStyles.Add(dgStyle);
		}


		public void AutoSizeColAcquisti(int col)  
		{ 
			float width = 0; 
 			int numRows = ((DataTable)dgBookAcquisti.DataSource).Rows.Count; 
 			Graphics g = Graphics.FromHwnd(dgBookAcquisti.Handle); 
 			StringFormat sf = new StringFormat(StringFormat.GenericTypographic); 
 			SizeF size; 
 			for(int i = 0; i < numRows; ++ i) 
 			{ 
 				size = g.MeasureString(dgBookAcquisti[i, col].ToString(), dgBookAcquisti.Font, 500, sf); 
 				if(size.Width > width) 
 					width = size.Width; 
 			} 
 			g.Dispose(); 
 			dgBookAcquisti.TableStyles["BookAcquisto"].GridColumnStyles[col].Width = (int) width + 8; // 8 is for leading and trailing padding 
 		}
 
		private void frmBook_Load(object sender, System.EventArgs e)
		{
			if (!IsSessionOpen() && !_formError)
			{
				MessageBox.Show("Nessuna sessione aperta", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}

		private bool IsSessionOpen()
		{
			bool bRet = false;
			if ((!_IsSessionEnabled) && !(_StatoSessione == "Sospesa"))
			{
				bRet = false;
			}
			else
			{
				bRet = true;
			}
			return bRet;
		}
	}
}
