using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Web.Services.Protocols;
using System.Security.Cryptography.X509Certificates;
using System.Data;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmSessioniBudget.
	/// </summary>
	public class frmSessioniBudget : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dgListaSessioni;

		private DataView _dv;

		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.Button btnApri;
		private System.Windows.Forms.ToolTip tltInfo;
		private System.ComponentModel.IContainer components;

		public frmSessioniBudget()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			SetDataGridMapping();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSessioniBudget));
			this.dgListaSessioni = new System.Windows.Forms.DataGrid();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnApri = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			((System.ComponentModel.ISupportInitialize)(this.dgListaSessioni)).BeginInit();
			this.SuspendLayout();
			// 
			// dgListaSessioni
			// 
			this.dgListaSessioni.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.dgListaSessioni.CaptionText = "Lista Sessioni";
			this.dgListaSessioni.DataMember = "";
			this.dgListaSessioni.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgListaSessioni.Location = new System.Drawing.Point(2, 3);
			this.dgListaSessioni.Name = "dgListaSessioni";
			this.dgListaSessioni.Size = new System.Drawing.Size(720, 348);
			this.dgListaSessioni.TabIndex = 0;
			this.dgListaSessioni.DoubleClick += new System.EventHandler(this.dgListaSessioni_DoubleClick);
			this.dgListaSessioni.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgListaSessioni_MouseUp);
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnChiudi.Location = new System.Drawing.Point(636, 356);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 1;
			this.btnChiudi.Text = "Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa finestra");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnApri
			// 
			this.btnApri.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnApri.Location = new System.Drawing.Point(556, 356);
			this.btnApri.Name = "btnApri";
			this.btnApri.TabIndex = 2;
			this.btnApri.Text = "&Apri";
			this.tltInfo.SetToolTip(this.btnApri, "Richiama la Form di Budget per la sessione selezionata");
			this.btnApri.Click += new System.EventHandler(this.btnApri_Click);
			// 
			// frmSessioniBudget
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(724, 389);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnApri,
																		  this.btnChiudi,
																		  this.dgListaSessioni});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmSessioniBudget";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Lista Sessioni \'In Attesa\'-\'Predisposta\'-\'Aperta\'";
			this.Load += new System.EventHandler(this.frmSessioniBudget_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgListaSessioni)).EndInit();
			this.ResumeLayout(false);

		}

		private void SetDataGridMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[10];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			dgCol[0].HeaderText = "Titolo";
			dgCol[0].MappingName = "Titolo";
			dgCol[0].Width = 200;

			dgCol[1].HeaderText = "Data Ora Apertura";
			dgCol[1].MappingName = "DataOraApertura";
			dgCol[1].Width = 150;
			dgCol[1].Format = "g";

			dgCol[2].HeaderText = "Data Ora Chiusura";
			dgCol[2].MappingName = "DataOraChiusura";
			dgCol[2].Width = 150;
			dgCol[2].Format = "g";

			dgCol[3].HeaderText = "Prezzo Riferimento Anno Precedente";
			dgCol[3].MappingName = "PrezzoRiferimentoAnnoPrec";
			dgCol[3].Width = 200;
			dgCol[3].Format = "c";

			dgCol[4].HeaderText = "Prezzo Riferimento Anno Corrente";
			dgCol[4].MappingName = "PrezzoRiferimentoAnnoCorr";
			dgCol[4].Width = 200;
			dgCol[4].Format = "c";

			dgCol[5].HeaderText = "Prezzo Riferimento Anno Successivo";
			dgCol[5].MappingName = "PrezzoRiferimentoAnnoSucc";
			dgCol[5].Width = 200;
			dgCol[5].Format = "c";

			dgCol[6].HeaderText = "Prezzo Convenzionale";
			dgCol[6].MappingName = "PrezzoConvenzionale";
			dgCol[6].Width = 120;
			dgCol[6].Format = "c";


			dgCol[7].HeaderText = "Data Ora Creazione";
			dgCol[7].MappingName = "DataOraCreazione";
			dgCol[7].Width = 150;
			dgCol[7].Format = "g";

			dgCol[8].HeaderText = "Data Ora Modifica";
			dgCol[8].MappingName = "DataOraModifica";
			dgCol[8].Width = 150;
			dgCol[8].Format = "g";

			dgCol[9].HeaderText = "Stato Sessione";
			dgCol[9].MappingName = "StatoSessione";
			dgCol[9].Width = 100;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Sessioni";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgListaSessioni.TableStyles.Add(dgStyle);
		}

		#endregion

		private void frmSessioniBudget_Load(object sender, System.EventArgs e)
		{
			DataSet ds = GetDataSet();
			//DiagnosticHelper.DataSetDump("Pippo", ds);
			if (ds != null)
			{
				_dv = new DataView(ds.Tables[0]);
				_dv.Sort = "Titolo";
				_dv.AllowDelete = false;
				_dv.AllowNew = false;
				_dv.AllowEdit = false;
				dgListaSessioni.DataSource = _dv;
				
				BindingManagerBase bm = dgListaSessioni.BindingContext[dgListaSessioni.DataSource, dgListaSessioni.DataMember]; 
				bm.CurrentChanged += new EventHandler(dgListaSessioni_CurrentChanged);
				// Se esiste almeno una riga la seleziono
				if (bm.Count != 0)
				{
//					dgListaSessioni.Select(0);
					btnApri.Enabled = true;
				}
				else
				{
					btnApri.Enabled = false;
				}
			}
			else
			{
				btnApri.Enabled	  = false;
				btnChiudi.Enabled = true;
			}
		}

		// il bookmark e' cambiato
		private void dgListaSessioni_CurrentChanged(object sender, EventArgs e)
		{
			BindingManagerBase bm = (BindingManagerBase) sender;
			if (bm.Current.GetType() != typeof(DataRowView))
				return;
		}

		/// <summary>
		/// Funzione che ritorna il data set da visualizzare nella datagrid
		/// </summary>
		private DataSet GetDataSet()
		{
			try
			{
				
				CVAdminWSBLSessioni.BLSessioni ww = new CVAdminWSBLSessioni.BLSessioni();
				frmLogin.AddLoginInfo(ww);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore

				// chiedo TUTTE le sessioni
				IAsyncResult asr = ww.BeginGetListaFiltrata(null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return null;

				// il Web Service ha risposto... prendo il risultato
				return ww.EndGetListaFiltrata(asr);
			}
			catch (SoapException e)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show(e.Message, "Errore");
				return null;
			}
			catch (Exception e)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return null;
			}
		}

		private void dgListaSessioni_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			DataGrid.HitTestInfo hti = dgListaSessioni.HitTest(new Point(e.X, e.Y)); 
			if (hti.Type == DataGrid.HitTestType.Cell) 
			{ 
				dgListaSessioni.CurrentCell = new DataGridCell(hti.Row, hti.Column); 
				dgListaSessioni.Select(hti.Row); 
			}
		}

		private void dgListaSessioni_DoubleClick(object sender, System.EventArgs e)
		{
			CallFormBudget();
		}

		private void CallFormBudget()
		{
			BindingManagerBase bm = dgListaSessioni.BindingContext[dgListaSessioni.DataSource, dgListaSessioni.DataMember];
			if (bm.Count != 0)
			{
				string IdSessione = (string)_dv.Table.Rows[dgListaSessioni.CurrentRowIndex]["IdSessione"];
				// Se esiste una Sessione Attiva visualizzo la Form relativa al budget
				DataSet ds = null;
				if (CaricaDatiSessioneAttiva(IdSessione, out ds))
				{
					frmBudget _fBudget = new frmBudget(ds.Tables[0], IdSessione);
					_fBudget.ShowDialog(this);
				}
			}
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private DataSet GetDataSetSessioneAttiva(string IdSessione)
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ws = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ws);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore

				IAsyncResult asr = ws.BeginRetrieveActive(IdSessione, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return null;

				// il Web Service ha risposto... prendo il risultato
				return ws.EndRetrieveActive(asr);
			}
			catch (SoapException e)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show(e.Message, "Errore");
				return null;
			}
			catch (Exception e)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return null;
			}
		}

		private bool CaricaDatiSessioneAttiva(string IdSessione, out DataSet dsSessioneAttiva)
		{
			dsSessioneAttiva = null;

			DataSet ds = GetDataSetSessioneAttiva(IdSessione);
			if (ds == null)
				return false;

			DataTable dt = ds.Tables[0];
			
			int NumRighe = dt.Rows.Count;

			if (NumRighe == 0)
			{
				MessageBox.Show("Non ci sono sessioni in stato 'Aperta' o in stato 'Predisposta',quindi non � possibile inserire dati di budget.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return false;
			}
			else if (NumRighe > 1)
			{
				MessageBox.Show("C'e' piu' di una sessione in stato 'Aperta' o in stato 'Predisposta',quindi non � possibile inserire dati di budget.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return false;
			}
			// Ho una riga sola...
			dsSessioneAttiva = ds;
			return true;
		}

		private void btnApri_Click(object sender, System.EventArgs e)
		{
			CallFormBudget();
		}
	}
}
