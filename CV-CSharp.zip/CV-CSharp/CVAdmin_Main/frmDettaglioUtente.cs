using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmDettaglioSocieta.
	/// </summary>
	public class frmDettaglioUtente : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.Button btnSalva;
		private System.Windows.Forms.GroupBox gbDatiSocieta;
		private System.Windows.Forms.TextBox tbEmail;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.TextBox tbFax;
		private System.Windows.Forms.Label lblFax;
		private System.Windows.Forms.TextBox tbTelefono;
		private System.Windows.Forms.Label lblTelefono;
		private System.Windows.Forms.TextBox tbCodiceFiscale;
		private System.Windows.Forms.Label lblCodiceFiscale;
		private System.Windows.Forms.TextBox tbNominativo;
		private System.Windows.Forms.Label lblNominativo;
		private System.Windows.Forms.Label lblTipoUtente;
		private System.Windows.Forms.ComboBox cbTipoUtente;
		private System.Windows.Forms.Label lblStatoUtente;
		private System.Windows.Forms.ComboBox cbStatoUtente;


		private DataSet				_dsSocietaUtenti = null;
		private DataRow				_dr = null;
		private BindingManagerBase	_bmgr = null;
		private System.Windows.Forms.Button btnStorico;

		internal class cbBind
		{
			public cbBind(string s) { _s = s; }
			public string Name { get { return _s; } }
			string _s;
		}

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmDettaglioUtente()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ClearComponents();
			_dsSocietaUtenti = null;
		}

		public frmDettaglioUtente(DataRow dr)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ClearComponents();
			_dr = dr;
			_dsSocietaUtenti = dr.Table.DataSet;
			BindComponents();
			this.Text = "Dettaglio Richiesta Utente della societa' " + (string)dr["RagioneSociale"] + " - " + (string)dr["CodiceConto"] ;
		}

		private void Chiudi()
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void AddItemsComboBoxes()
		{
		
			cbTipoUtente.Items.Add("Amministratore");
			cbTipoUtente.Items.Add("Generico");
			cbTipoUtente.SelectedIndex = 0;
		}

		private void ClearComponents()
		{
			tbCodiceFiscale.Text = "";
			tbEmail.Text		 = "";
			tbFax.Text			 = "";
			tbNominativo.Text	 = "";
			tbTelefono.Text		 = "";
			cbStatoUtente.Text	 = "";
			cbTipoUtente.Text	 = "";
		}

		private void BindComponents()
		{
			if (_dr == null)
				return;

			if (_dsSocietaUtenti == null)
				return;

			_bmgr = this.BindingContext[_dsSocietaUtenti, "Utenti"];
			for (int rr = 0; rr < _dr.Table.Rows.Count; ++rr)
				if (_dr.Table.Rows[rr] == _dr)
					_bmgr.Position = rr;

			tbNominativo.DataBindings.Add("Text", _dsSocietaUtenti, "Utenti.Nominativo");
			tbCodiceFiscale.DataBindings.Add("Text", _dsSocietaUtenti, "Utenti.CodiceFiscale");
			tbTelefono.DataBindings.Add("Text", _dsSocietaUtenti, "Utenti.Telefono");
			tbFax.DataBindings.Add("Text", _dsSocietaUtenti, "Utenti.FAX");
			tbEmail.DataBindings.Add("Text", _dsSocietaUtenti, "Utenti.Email");
			
			cbStatoUtente.CausesValidation = true;
			cbBind [] cbListStatiUtente = 
			{ 
				new cbBind("Valido"),
				new cbBind("Non Valido"),
			};
			cbStatoUtente.DataSource = cbListStatiUtente;
			// faccio il bind di una cb su di una lista con il valore selezionato preso dalla
			// nostra riga corrente
			cbStatoUtente.DisplayMember = "Name"; // il valore visualizzato e il valore della chiave
			cbStatoUtente.ValueMember   = "Name"; // sono gli stessi
			cbStatoUtente.DataBindings.Add("SelectedValue", _dsSocietaUtenti, "Utenti.StatoUtente");

			cbTipoUtente.CausesValidation = true;
			cbBind [] cbListTipoUtente = 
			{ 
				new cbBind("Amministratore"),
				new cbBind("Generico"),
			};
			cbTipoUtente.DataSource = cbListTipoUtente;
			// faccio il bind di una cb su di una lista con il valore selezionato preso dalla
			// nostra riga corrente
			cbTipoUtente.DisplayMember = "Name"; // il valore visualizzato e il valore della chiave
			cbTipoUtente.ValueMember   = "Name"; // sono gli stessi
			cbTipoUtente.DataBindings.Add("SelectedValue", _dsSocietaUtenti, "Utenti.TipoUtente");
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDettaglioUtente));
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnSalva = new System.Windows.Forms.Button();
			this.gbDatiSocieta = new System.Windows.Forms.GroupBox();
			this.cbStatoUtente = new System.Windows.Forms.ComboBox();
			this.lblStatoUtente = new System.Windows.Forms.Label();
			this.cbTipoUtente = new System.Windows.Forms.ComboBox();
			this.lblTipoUtente = new System.Windows.Forms.Label();
			this.tbEmail = new System.Windows.Forms.TextBox();
			this.lblEmail = new System.Windows.Forms.Label();
			this.tbFax = new System.Windows.Forms.TextBox();
			this.lblFax = new System.Windows.Forms.Label();
			this.tbTelefono = new System.Windows.Forms.TextBox();
			this.lblTelefono = new System.Windows.Forms.Label();
			this.tbCodiceFiscale = new System.Windows.Forms.TextBox();
			this.lblCodiceFiscale = new System.Windows.Forms.Label();
			this.tbNominativo = new System.Windows.Forms.TextBox();
			this.lblNominativo = new System.Windows.Forms.Label();
			this.btnStorico = new System.Windows.Forms.Button();
			this.gbDatiSocieta.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnChiudi
			// 
			this.btnChiudi.Location = new System.Drawing.Point(480, 220);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.Size = new System.Drawing.Size(96, 23);
			this.btnChiudi.TabIndex = 10;
			this.btnChiudi.Text = "&Chiudi";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnSalva
			// 
			this.btnSalva.Location = new System.Drawing.Point(379, 220);
			this.btnSalva.Name = "btnSalva";
			this.btnSalva.Size = new System.Drawing.Size(96, 23);
			this.btnSalva.TabIndex = 8;
			this.btnSalva.Text = "&Salva Modifiche";
			this.btnSalva.Click += new System.EventHandler(this.btnSalva_Click);
			// 
			// gbDatiSocieta
			// 
			this.gbDatiSocieta.Controls.Add(this.cbStatoUtente);
			this.gbDatiSocieta.Controls.Add(this.lblStatoUtente);
			this.gbDatiSocieta.Controls.Add(this.cbTipoUtente);
			this.gbDatiSocieta.Controls.Add(this.lblTipoUtente);
			this.gbDatiSocieta.Controls.Add(this.tbEmail);
			this.gbDatiSocieta.Controls.Add(this.lblEmail);
			this.gbDatiSocieta.Controls.Add(this.tbFax);
			this.gbDatiSocieta.Controls.Add(this.lblFax);
			this.gbDatiSocieta.Controls.Add(this.tbTelefono);
			this.gbDatiSocieta.Controls.Add(this.lblTelefono);
			this.gbDatiSocieta.Controls.Add(this.tbCodiceFiscale);
			this.gbDatiSocieta.Controls.Add(this.lblCodiceFiscale);
			this.gbDatiSocieta.Controls.Add(this.tbNominativo);
			this.gbDatiSocieta.Controls.Add(this.lblNominativo);
			this.gbDatiSocieta.Location = new System.Drawing.Point(3, 4);
			this.gbDatiSocieta.Name = "gbDatiSocieta";
			this.gbDatiSocieta.Size = new System.Drawing.Size(572, 212);
			this.gbDatiSocieta.TabIndex = 11;
			this.gbDatiSocieta.TabStop = false;
			this.gbDatiSocieta.Text = " Dati Utente";
			// 
			// cbStatoUtente
			// 
			this.cbStatoUtente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbStatoUtente.Location = new System.Drawing.Point(264, 176);
			this.cbStatoUtente.Name = "cbStatoUtente";
			this.cbStatoUtente.Size = new System.Drawing.Size(152, 21);
			this.cbStatoUtente.TabIndex = 7;
			// 
			// lblStatoUtente
			// 
			this.lblStatoUtente.Location = new System.Drawing.Point(264, 160);
			this.lblStatoUtente.Name = "lblStatoUtente";
			this.lblStatoUtente.Size = new System.Drawing.Size(72, 16);
			this.lblStatoUtente.TabIndex = 22;
			this.lblStatoUtente.Text = "Stato Utente";
			// 
			// cbTipoUtente
			// 
			this.cbTipoUtente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbTipoUtente.Location = new System.Drawing.Point(8, 176);
			this.cbTipoUtente.Name = "cbTipoUtente";
			this.cbTipoUtente.Size = new System.Drawing.Size(168, 21);
			this.cbTipoUtente.TabIndex = 6;
			// 
			// lblTipoUtente
			// 
			this.lblTipoUtente.Location = new System.Drawing.Point(8, 160);
			this.lblTipoUtente.Name = "lblTipoUtente";
			this.lblTipoUtente.Size = new System.Drawing.Size(64, 16);
			this.lblTipoUtente.TabIndex = 20;
			this.lblTipoUtente.Text = "Tipo Utente";
			// 
			// tbEmail
			// 
			this.tbEmail.Location = new System.Drawing.Point(8, 129);
			this.tbEmail.Name = "tbEmail";
			this.tbEmail.Size = new System.Drawing.Size(252, 20);
			this.tbEmail.TabIndex = 5;
			this.tbEmail.Text = "Email";
			// 
			// lblEmail
			// 
			this.lblEmail.Location = new System.Drawing.Point(8, 113);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(44, 16);
			this.lblEmail.TabIndex = 18;
			this.lblEmail.Text = "E-Mail";
			// 
			// tbFax
			// 
			this.tbFax.Location = new System.Drawing.Point(264, 84);
			this.tbFax.Name = "tbFax";
			this.tbFax.Size = new System.Drawing.Size(303, 20);
			this.tbFax.TabIndex = 4;
			this.tbFax.Text = "FAX";
			// 
			// lblFax
			// 
			this.lblFax.Location = new System.Drawing.Point(264, 68);
			this.lblFax.Name = "lblFax";
			this.lblFax.Size = new System.Drawing.Size(36, 16);
			this.lblFax.TabIndex = 16;
			this.lblFax.Text = "FAX";
			// 
			// tbTelefono
			// 
			this.tbTelefono.Location = new System.Drawing.Point(8, 84);
			this.tbTelefono.Name = "tbTelefono";
			this.tbTelefono.Size = new System.Drawing.Size(252, 20);
			this.tbTelefono.TabIndex = 3;
			this.tbTelefono.Text = "Telefono";
			// 
			// lblTelefono
			// 
			this.lblTelefono.Location = new System.Drawing.Point(8, 68);
			this.lblTelefono.Name = "lblTelefono";
			this.lblTelefono.Size = new System.Drawing.Size(56, 16);
			this.lblTelefono.TabIndex = 14;
			this.lblTelefono.Text = "Telefono";
			// 
			// tbCodiceFiscale
			// 
			this.tbCodiceFiscale.BackColor = System.Drawing.Color.White;
			this.tbCodiceFiscale.Location = new System.Drawing.Point(264, 36);
			this.tbCodiceFiscale.Name = "tbCodiceFiscale";
			this.tbCodiceFiscale.Size = new System.Drawing.Size(303, 20);
			this.tbCodiceFiscale.TabIndex = 2;
			this.tbCodiceFiscale.Text = "Codice Fiscale";
			this.tbCodiceFiscale.TextChanged += new System.EventHandler(this.tbCodiceFiscale_TextChanged);
			// 
			// lblCodiceFiscale
			// 
			this.lblCodiceFiscale.Location = new System.Drawing.Point(264, 20);
			this.lblCodiceFiscale.Name = "lblCodiceFiscale";
			this.lblCodiceFiscale.Size = new System.Drawing.Size(80, 16);
			this.lblCodiceFiscale.TabIndex = 13;
			this.lblCodiceFiscale.Text = "Codice Fiscale";
			// 
			// tbNominativo
			// 
			this.tbNominativo.BackColor = System.Drawing.Color.White;
			this.tbNominativo.Location = new System.Drawing.Point(8, 36);
			this.tbNominativo.Name = "tbNominativo";
			this.tbNominativo.Size = new System.Drawing.Size(252, 20);
			this.tbNominativo.TabIndex = 1;
			this.tbNominativo.Text = "Nominativo";
			// 
			// lblNominativo
			// 
			this.lblNominativo.Location = new System.Drawing.Point(8, 20);
			this.lblNominativo.Name = "lblNominativo";
			this.lblNominativo.Size = new System.Drawing.Size(64, 16);
			this.lblNominativo.TabIndex = 12;
			this.lblNominativo.Text = "Nominativo";
			// 
			// btnStorico
			// 
			this.btnStorico.Enabled = false;
			this.btnStorico.Location = new System.Drawing.Point(8, 220);
			this.btnStorico.Name = "btnStorico";
			this.btnStorico.Size = new System.Drawing.Size(100, 23);
			this.btnStorico.TabIndex = 9;
			this.btnStorico.Text = "Storico &Modifiche";
			this.btnStorico.Visible = false;
			this.btnStorico.Click += new System.EventHandler(this.btnStorico_Click);
			// 
			// frmDettaglioUtente
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(578, 247);
			this.Controls.Add(this.btnStorico);
			this.Controls.Add(this.gbDatiSocieta);
			this.Controls.Add(this.btnSalva);
			this.Controls.Add(this.btnChiudi);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmDettaglioUtente";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Modifica Utente";
			this.gbDatiSocieta.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void tbCodiceFiscale_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			Chiudi();
		}

		private void RefreshBinding()
		{
//			int p = _bmgr.Position;
//			_bmgr.Position = _bmgr.Count;
//			_bmgr.Position = p;

			if (_bmgr != null && _bmgr is CurrencyManager)
				((CurrencyManager)_bmgr).Refresh();

		}

		private void btnSalva_Click(object sender, System.EventArgs e)
		{
			DialogResult dr = MessageBox.Show("Sei sicuro di voler modificare i dati?", "Modificat Dati", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
			if (dr == DialogResult.No)
			{
				_dr.CancelEdit();
				RefreshBinding();
				return;
			}
			Application.DoEvents();
			_dr.EndEdit();
			_dr["DataOraModifica"] = DbTime.GetDbSystemDate();

			if (frmSocietaUtenti.AggiornaDataSetUtenti(_dsSocietaUtenti, (string)_dr["IdUtente"]))
			{
				this.DialogResult = DialogResult.OK;
				MessageBox.Show("Modifica effettuata in modo corretto", "Modifica Dati", MessageBoxButtons.OK, MessageBoxIcon.Information);
				this.Close();
			}
			else
			{
				MessageBox.Show("Modifica non effettuata", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnStorico_Click(object sender, System.EventArgs e)
		{
			frmStoricoUtenti frmStoUtenti = new frmStoricoUtenti();
			frmStoUtenti.ShowDialog(this);
			frmStoUtenti.Dispose();
		}
	}
}
