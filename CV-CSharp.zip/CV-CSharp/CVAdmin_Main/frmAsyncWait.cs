using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;
using System.Web.Services.Protocols;
using System.Reflection;
using System.Runtime.Remoting;

namespace CVAdmin_Main
{
	/// <summary>
	/// form da chiamare per effettura chiamate asincrone
	/// </summary>
	public class frmAsyncWait : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCancel;
		private System.Timers.Timer timer;
		private IAsyncResult _asr;
		private bool _cancelled = false;
		private System.ComponentModel.Container components = null;
		private Cursor _cursor;
		private TimeSpan _ts;

		/// <summary>
		/// Visualizza un finestra che aspetta il completamento di una
		/// chiamata asincrona. Fare ShowDialog per visualizzare la maschera
		/// </summary>
		/// <param name="asr">il valore ritornato dalla chiamata BeginXXX(...)</param>
		public frmAsyncWait(IAsyncResult asr)
		{
			InitializeComponent();
			_asr = asr;
			_ts = new TimeSpan(0,5,0); // aspetto al max 5minuti
		}
		public frmAsyncWait(IAsyncResult asr, TimeSpan ts)
		{
			InitializeComponent();
			_asr = asr;
			_ts = ts;
		}

		/// <summary>
		/// Visualizza un finestra che aspetta il completamento di una
		/// chiamata asincrona. Fare ShowDialog per visualizzare la maschera
		/// </summary>
		/// <param name="title">il titolo della finestra</param>
		/// <param name="asr">il valore ritornato dalla chiamata BeginXXX(...)</param>
		public frmAsyncWait(string title, IAsyncResult asr)
		{
			InitializeComponent();
			_asr = asr;
			this.Text = title;
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnCancel = new System.Windows.Forms.Button();
			this.timer = new System.Timers.Timer();
			((System.ComponentModel.ISupportInitialize)(this.timer)).BeginInit();
			this.SuspendLayout();
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(64, 8);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 0;
			this.btnCancel.Text = "Cancella";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// timer
			// 
			this.timer.Enabled = true;
			this.timer.Interval = 300;
			this.timer.SynchronizingObject = this;
			this.timer.Elapsed += new System.Timers.ElapsedEventHandler(this.timer_Elapsed);
			// 
			// frmAsyncWait
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(208, 37);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnCancel});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmAsyncWait";
			this.ShowInTaskbar = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Chiamata al server in corso";
			this.Load += new System.EventHandler(this.frmAsyncWait_Load);
			this.Closed += new System.EventHandler(this.frmAsyncWait_Closed);
			((System.ComponentModel.ISupportInitialize)(this.timer)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		// funzione che determina se la chiamata al web service e' terminata
		private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			if (_asr.IsCompleted)
			{
				_cancelled = false;
				this.DialogResult = DialogResult.OK;

				this.Close();
			}

			// riprovo al prossimo timer
		}

		// per abortire l'operazione
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			if (_asr.IsCompleted)
			{
				_cancelled = false;
				this.DialogResult = DialogResult.OK;
				this.Close();
			}
			else
			{
				WebClientAsyncResult wasr = _asr as WebClientAsyncResult;
				Debug.Assert(wasr != null);
				if (wasr != null)
					wasr.Abort();

				_cancelled = true;
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void frmAsyncWait_Load(object sender, System.EventArgs e)
		{
			_cursor = Cursor.Current;
		}

		private void frmAsyncWait_Closed(object sender, System.EventArgs e)
		{
			Cursor.Current = _cursor;
		}

		/// <summary>
		/// ritorna se l'amministratore ha premuto cancel
		/// ossia se vuole abortire la comunicazione
		/// </summary>
		public bool Cancelled
		{
			get { return _cancelled; }
		}

		/// <summary>
		/// Invoca un metodo di un WebService in maniera bloccante per
		/// il chiamante. Durante la chiamata appare una finestra per consentire
		/// all'utente di cancellare la chiamata.
		/// Attenzione che i parametri di ingresso/uscita sono object per cui
		/// il controllo dei tipi e' effettuato SOLO durante l'esecuzione del metodo
		/// e non a compile time.
		/// </summary>
		/// <param name="Cancelled">bool in uscita che indica se la chiamata e' fallita</param>
		/// <param name="bl">oggetto proxy del WebService</param>
		/// <param name="MethodName">Metodo da invocare (stringa)</param>
		/// <param name="args">argomenti al metodo da invocare</param>
		/// <returns>il risultato del metodo, null se <code>Cancelled</code> e' false</returns>
		public static object DoSoapCall(out bool Cancelled, SoapHttpClientProtocol bl, string MethodName, params object [] args)
		{
			Cancelled = false;

			try
			{
				frmLogin.AddLoginInfo(bl);

				object [] InvokeArgs;
				if (args != null)
				{
					InvokeArgs = new object [args.Length + 2];
					for (int i = 0; i < args.Length; ++i)
						InvokeArgs[i] = args[i];
					InvokeArgs[args.Length] = null;
					InvokeArgs[args.Length + 1] = null;
				}
				else
					InvokeArgs = new object [] { null, null };

				Type tbl = bl.GetType();

				IAsyncResult asr = (IAsyncResult)tbl.InvokeMember(
					"Begin" + MethodName, 
					BindingFlags.Public|BindingFlags.InvokeMethod|BindingFlags.Instance,
					null,
					bl,
					InvokeArgs);

				using (frmAsyncWait w = new frmAsyncWait(asr))
				{
					w.ShowDialog();
					if (w.Cancelled)
					{
						Cancelled = true;
						return null;
					}
				}

				return tbl.InvokeMember(
					"End" + MethodName, 
					BindingFlags.Public|BindingFlags.InvokeMethod|BindingFlags.Instance,
					null,
					bl,
					new object [] { asr });
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
			}
			catch (Exception ex)
			{
				if (ex.InnerException != null && ex.InnerException is SoapException)
				{
					Trace.WriteLine("SoapException");
					Trace.Indent();
					Trace.WriteLine(ex.InnerException.Message);
					Trace.WriteLine(ex.InnerException.StackTrace);
					Trace.Unindent();

					MessageBox.Show(ex.InnerException.Message, "Errore");
				}
				else
				{
					Trace.WriteLine("Errore di comunicazione o eccezione dal server");
					Trace.Indent();
					Trace.WriteLine(ex.Message);
					Trace.WriteLine(ex.StackTrace);
					Trace.Unindent();

					MessageBox.Show("Comunicazione con il server impossibile.\n" + ex.Message, "Errore");
				}
			}

			Cancelled = true;
			return null;
		}


		/// <summary>
		/// Chiama un WebService ed esegue il metodo specificato in ClassDotMethodName.
		/// La chiamata e' bloccante. L'utente puo' interrompere la chiamata.
		/// </summary>
		/// <param name="Cancelled">true se la chiamata al metodo e' stata cancellata</param>
		/// <param name="ClassDotMethodName">stringa nel formato a.b.c dove a.b e' il nome completo della classe istanziabile e .c e' il metodo</param>
		/// <param name="args">argomenti del metodo</param>
		/// <returns>il risultato del metodo</returns>
		public static object DoSoapCall(out bool Cancelled, string ClassDotMethodName, params object [] args)
		{
			// accetto anche le parentesi a.b.c()
			string [] sp = ClassDotMethodName.Split(new char[] { '.', '(', ')' });

			string className = sp[0];
			string method = null;
			for (int i = 1; i < sp.Length; ++i)
			{
				if (sp[i].Length > 0)
				{
					className += "." + sp[i];
					method = sp[i];
				}
			}
			// tolgo l'ultimo .x che e' il metodo.
			className = className.Replace("." + method, "");

			ObjectHandle bl = Activator.CreateInstance(null, className);

			return DoSoapCall(out Cancelled, (SoapHttpClientProtocol)bl.Unwrap(), method, args);
		}


		public static void OnCatchException(Exception e)
		{
			if (e is CancelException)
			{
				throw e;
			}
			else if (e is SoapException)
			{
				SoapException ex = e as SoapException;

				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				throw new ApplicationException(ex.Message);
			}
			else
			{
				Exception ex = e;

				if (ex.InnerException != null && ex.InnerException is SoapException)
				{
					Trace.WriteLine("SoapException");
					Trace.Indent();
					Trace.WriteLine(ex.InnerException.Message);
					Trace.WriteLine(ex.InnerException.StackTrace);
					Trace.Unindent();

					throw new ApplicationException(ex.InnerException.Message);
				}
				else
				{
					Trace.WriteLine("Errore di comunicazione o eccezione dal server");
					Trace.Indent();
					Trace.WriteLine(ex.Message);
					Trace.WriteLine(ex.StackTrace);
					Trace.Unindent();

					throw new ApplicationException("Comunicazione con il server impossibile.\n" + ex.Message);
				}
			}
		}

		public static void ShowForm(IAsyncResult asr)
		{
			using (frmAsyncWait f = new frmAsyncWait(asr))
			{
				f.ShowDialog();
				if (f.Cancelled)
					throw new CancelException();
			}
		}
	}

	public class CancelException : ApplicationException
	{
		public CancelException(string msg) : base(msg) {}
		public CancelException() : base() {}
	}
}
