using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmSceltaXML.
	/// </summary>
	public class frmSceltaXML : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnIndietro;
		private System.Windows.Forms.Button btnAvanti;
		private System.Windows.Forms.Button btnHome;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.Button btnConferma;

		private string sXmlFile;
		private string sFilenameURL;
		private string selFilenameURL;

		private AxSHDocVw.AxWebBrowser webBr;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSceltaXML(string FilenameURL)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			sFilenameURL = FilenameURL;

			try
			{
				object param = null;
				webBr.Navigate(sFilenameURL, ref param, ref param, ref param, ref param);
			}
			catch( Exception ex )
			{
				Trace.WriteLine("Errore sul componente [WebBrowser.Navigate()]");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();
			}
		}

		
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSceltaXML));
			this.btnIndietro = new System.Windows.Forms.Button();
			this.btnAvanti = new System.Windows.Forms.Button();
			this.btnHome = new System.Windows.Forms.Button();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnConferma = new System.Windows.Forms.Button();
			this.webBr = new AxSHDocVw.AxWebBrowser();
			((System.ComponentModel.ISupportInitialize)(this.webBr)).BeginInit();
			this.SuspendLayout();
			// 
			// btnIndietro
			// 
			this.btnIndietro.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnIndietro.Location = new System.Drawing.Point(8, 304);
			this.btnIndietro.Name = "btnIndietro";
			this.btnIndietro.TabIndex = 0;
			this.btnIndietro.Text = "<< Indietro";
			this.btnIndietro.Click += new System.EventHandler(this.btnIndietro_Click);
			// 
			// btnAvanti
			// 
			this.btnAvanti.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnAvanti.Location = new System.Drawing.Point(84, 304);
			this.btnAvanti.Name = "btnAvanti";
			this.btnAvanti.TabIndex = 1;
			this.btnAvanti.Text = "Avanti >>";
			this.btnAvanti.Click += new System.EventHandler(this.btnAvanti_Click);
			// 
			// btnHome
			// 
			this.btnHome.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnHome.Location = new System.Drawing.Point(160, 304);
			this.btnHome.Name = "btnHome";
			this.btnHome.TabIndex = 2;
			this.btnHome.Text = "Home";
			this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnChiudi.Location = new System.Drawing.Point(560, 304);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 3;
			this.btnChiudi.Text = "Annulla";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnConferma
			// 
			this.btnConferma.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnConferma.Location = new System.Drawing.Point(480, 304);
			this.btnConferma.Name = "btnConferma";
			this.btnConferma.TabIndex = 5;
			this.btnConferma.Text = "Conferma";
			this.btnConferma.Click += new System.EventHandler(this.btnConferma_Click);
			// 
			// webBr
			// 
			this.webBr.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.webBr.Enabled = true;
			this.webBr.Location = new System.Drawing.Point(8, 8);
			this.webBr.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("webBr.OcxState")));
			this.webBr.Size = new System.Drawing.Size(628, 292);
			this.webBr.TabIndex = 6;
			this.webBr.DocumentComplete += new AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEventHandler(this.webBr_DocumentComplete);
			// 
			// frmSceltaXML
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(642, 335);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.webBr,
																		  this.btnConferma,
																		  this.btnChiudi,
																		  this.btnHome,
																		  this.btnAvanti,
																		  this.btnIndietro});
			this.Name = "frmSceltaXML";
			this.ShowInTaskbar = false;
			this.Text = "frmSceltaXML";
			this.Load += new System.EventHandler(this.frmSceltaXML_Load);
			((System.ComponentModel.ISupportInitialize)(this.webBr)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		public string FilenameURL
		{
			get
			{
				return sFilenameURL;
			}
			set
			{
				sFilenameURL = value;
			}
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void frmSceltaXML_Load(object sender, System.EventArgs e)
		{
			try
			{
				object param = null;
				webBr.Navigate(sFilenameURL, ref param, ref param, ref param, ref param);
			}
			catch( Exception ex )
			{
				Trace.WriteLine("Errore sul componente [WebBrowser.Navigate()]");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();
			}

		}

		private void btnHome_Click(object sender, System.EventArgs e)
		{
			try
			{
				object param = null;
				webBr.Navigate(sFilenameURL, ref param, ref param, ref param, ref param);
			}
			catch( Exception ex )
			{
				Trace.WriteLine("Errore sul componente [WebBrowser.Navigate()]");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();
			}
		}

		private void btnIndietro_Click(object sender, System.EventArgs e)
		{
			try
			{
				webBr.GoBack();
			}
			catch( Exception ex )
			{
				Trace.WriteLine("Errore sul componente [WebBrowser.GoBack()]");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();
			}
		}

		private void btnAvanti_Click(object sender, System.EventArgs e)
		{
			try
			{
				webBr.GoForward();
			}
			catch( Exception ex )
			{
				Trace.WriteLine("Errore sul componente [WebBrowser.GoForward()]");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();
			}
		}

		private void btnConferma_Click(object sender, System.EventArgs e)
		{
			sFilenameURL = selFilenameURL;

			try
			{
				// recupero il contenuto del file xml selezionato
				// ed elimino l'elemento doctype
				XmlDocument doc = new XmlDocument();
				
				doc.Load(sFilenameURL);

				doc.RemoveChild( doc.DocumentType );

				sXmlFile = doc.InnerXml;

				this.DialogResult = DialogResult.OK;

			}
			catch( Exception ex )
			{
				MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
				this.DialogResult = DialogResult.Cancel;
			}

			this.Close();
		}

		public string XmlFileContent
		{
			get
			{
				return sXmlFile;
			}
			set
			{
					sXmlFile = value;
			}
		}

		private void webBr_DocumentComplete(object sender, AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEvent e)
		{
			selFilenameURL = webBr.LocationURL;
			btnConferma.Enabled = CheckFilename(selFilenameURL);
		}

		public static bool CheckFilename( string selFilename )
		{
			// abilitazione del pulsante di conferma nel caso 
			// sia stato selezionato un file .xml

			int pos = selFilename.LastIndexOf("/");

			int offset;
			string filename;
			Regex r = new Regex(@"^ *([0-9a-z_-]+)(\.xml)? *$", RegexOptions.IgnoreCase);

			if( pos > 0 )
			{
				offset = selFilename.Length - pos - 1;
				filename = selFilename.Substring(pos+1, offset );
			}
			else
				filename = selFilename;

			Match m = r.Match(filename);
			
			return m.Success;
		}

		
	}
}
