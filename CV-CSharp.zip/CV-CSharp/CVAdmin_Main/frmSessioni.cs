using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using System.Web.Services.Protocols;
using System.Security.Cryptography.X509Certificates;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmSessioni.
	/// </summary>
	public class frmSessioni : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox edtTitoloSessione;
		private System.Windows.Forms.Label lblTitoloSessione;
		private System.Windows.Forms.Label lblStatoSessione;
		private System.Windows.Forms.ComboBox cbStatoSessione;
		private System.Windows.Forms.DataGrid dgSessioni;
		private System.Windows.Forms.GroupBox gbSessioni;
		private System.Windows.Forms.Button btnNuovaSessione;
		private System.Windows.Forms.Button btnEliminaSessione;
		private System.Windows.Forms.Button btnChiudiForm;
		private System.Windows.Forms.Button btnModifcaSessione;
		private System.Windows.Forms.ToolTip toolTip;
		private System.ComponentModel.IContainer components;

		private DataView _dv;

		public frmSessioni()
		{
			InitializeComponent();

			// qui associo le colonne della data grid con le colonne del data set
			SetDataGridMapping();

			AbilitaBottoni();
		}

		private void frmSessioni_Load(object sender, System.EventArgs e)
		{
			// selezioni <qualunque stato>
			cbStatoSessione.Text = cbStatoSessione.Items[0].ToString();//ToString OK

			// ottengo il data set: TUTTE le sessioni vengono downloadate
			// Nella versione VB carica solo le sessioni che fanno match con il titolo e/o lo stato sessione
			// Qui invece si carica tutto in modo da non dover ricollegarsi al sito
			// in altre maschere (inserimento sessione) dove nel VB comunque si scaricano tutte le sessioni.
			// Tanto vale fare il download una sola volta.
			// il DataView comunque mi aiuta a vedere solo le righe che interessano.
			// Notare che il DataView non e' in grado di filtrare le righe in AND....
			// nmorale della favola il filtro agisce o con lo stato sessione o con il titolo.
			DataSet ds = GetDataSet();
			if (ds != null)
			{
				_dv = new DataView(ds.Tables[0]);
				_dv.Sort = "Titolo";
				_dv.AllowDelete = false;
				_dv.AllowNew = false;
				_dv.AllowEdit = false;
				dgSessioni.DataSource = _dv;

				// dgSessioni.SetDataBinding(ds, "Sessioni");
				BindingManagerBase bm = dgSessioni.BindingContext[dgSessioni.DataSource, dgSessioni.DataMember]; 
				bm.CurrentChanged += new EventHandler(dgSessioni_CurrentChanged);
			}

			// abilito i bottoni opportunamente.
			AbilitaBottoni();
		}


		/// <summary>
		/// Funzione per settare i nomi delle colonne, il corrispettivo
		/// campo nel data set, il formato ecc.
		/// </summary>
		void SetDataGridMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[4];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			dgCol[0].HeaderText = "Titolo";
			dgCol[0].MappingName = "Titolo";
			dgCol[0].Width = 200;

			dgCol[1].HeaderText = "Data Ora Apertura";
			dgCol[1].MappingName = "DataOraApertura";
			dgCol[1].Width = 150;
			dgCol[1].Format = "g";

			dgCol[2].HeaderText = "Data Ora Chiusura";
			dgCol[2].MappingName = "DataOraChiusura";
			dgCol[2].Width = 150;
			dgCol[2].Format = "g";

			dgCol[3].HeaderText = "Stato Sessione";
			dgCol[3].MappingName = "StatoSessione";
			dgCol[3].Width = 100;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Sessioni";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgSessioni.TableStyles.Add(dgStyle);
		}

		/// <summary>
		/// Funzione che ritorna il data set da visualizzare nella datagrid
		/// </summary>
		DataSet GetDataSet()
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ww = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ww);

				// chiamo il Web Service e aspetto il risultato.
				// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
				// dell'amministratore

				// chiedo TUTTE le sessioni
				IAsyncResult asr = ww.BeginRetrieve("", "", "", null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog();
				if (w.Cancelled)
					return null;

				// il Web Service ha risposto... prendo il risultato
				return ww.EndRetrieve(asr);
			}
			catch (SoapException e)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show(e.Message, "Errore");
				return null;
			}
			catch (Exception e)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(e.Message);
				Trace.WriteLine(e.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				return null;
			}
		}

		/// <summary>
		/// ritorna la riga contrassegnata dal bookmark (triangolino a sinistra)
		/// </summary>
		public DataRow CurrentRow
		{
			get 
			{
				DataTable dt = CurrentDataTable;

				BindingManagerBase bm = dgSessioni.BindingContext[dgSessioni.DataSource, dgSessioni.DataMember]; 
				if (bm.Count == 0) // numero di righe = 0
					return null;

				DataRow dr = ((DataRowView)bm.Current).Row; 
				return dr;
			}
		}

		/// <summary>
		/// ritorna l'unica (in questo caso) tabella attaccata al DataGrid
		/// </summary>
		public DataTable CurrentDataTable
		{
			get
			{
				// un po' di if per ottenere il dataset
				// posso cosi' associare il ds o il dv alla griglia

				object obj = dgSessioni.DataSource;
				DataTable dt = null;
				if (obj == null)
				{
					return null;
				}
				else if (obj is DataSet)
				{
					Debug.Assert(((DataSet)obj).Tables.Count == 1);
					dt = ((DataSet)obj).Tables[0];
				}
				else if (obj is DataView)
				{
					dt = ((DataView)obj).Table;
				}
				else
					Debug.Assert(false, "puoi mettere come DataSource un DataView o un DataTable");

				return dt;
			}
		}


		private void AbilitaBottoni()
		{
			DataTable dt = CurrentDataTable;
			if (dt == null)
			{
				btnEliminaSessione.Enabled = false;
				btnNuovaSessione.Enabled = false;
				btnModifcaSessione.Enabled = false;

				cbStatoSessione.Enabled = false;
				edtTitoloSessione.Enabled = false;
				return; // non c'e' piu' niente da fare
			}

			DataRow dr = CurrentRow;

			//			edtTitoloSessione.Enabled = cbStatoSessione.SelectedIndex == 0;
			//			cbStatoSessione.Enabled = edtTitoloSessione.Text.Length > 0;

			edtTitoloSessione.Enabled = true;
			cbStatoSessione.Enabled = true;

			btnNuovaSessione.Enabled = true;
			btnModifcaSessione.Enabled = true;

			// bottone ModifcaSessione
			if (dr == null)
				btnModifcaSessione.Enabled = false;
			else
				btnModifcaSessione.Enabled = true;


			// bottone EliminaSessione
			if (dr == null)
				btnEliminaSessione.Enabled = false;
			else
			{
				if (dr.RowState == DataRowState.Added)
				{
					// la sessione e' stata aggiunta localmente e poi cancellata.....
					// tutto cio' e' possibile a prescindere dallo stato
					btnEliminaSessione.Enabled = true;
				}
				else
				{
					string statoSessione = (string)dr["StatoSessione"];
					if (statoSessione.ToLower() == "In Attesa".ToLower())
						btnEliminaSessione.Enabled = true;
					else
						btnEliminaSessione.Enabled = false;

#if DEBUG
					//if (statoSessione.ToLower() == "Chiusa".ToLower())
					//	btnEliminaSessione.Enabled = true;
#endif
				}
			}
		}

		// il bookmark e' cambiato
		private void dgSessioni_CurrentChanged(object sender, EventArgs e)
		{
			BindingManagerBase bm = (BindingManagerBase) sender;
			if (bm.Current.GetType() != typeof(DataRowView))
				return;
			AbilitaBottoni();
		}



		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSessioni));
			this.gbSessioni = new System.Windows.Forms.GroupBox();
			this.cbStatoSessione = new System.Windows.Forms.ComboBox();
			this.lblStatoSessione = new System.Windows.Forms.Label();
			this.edtTitoloSessione = new System.Windows.Forms.TextBox();
			this.lblTitoloSessione = new System.Windows.Forms.Label();
			this.dgSessioni = new System.Windows.Forms.DataGrid();
			this.btnNuovaSessione = new System.Windows.Forms.Button();
			this.btnEliminaSessione = new System.Windows.Forms.Button();
			this.btnChiudiForm = new System.Windows.Forms.Button();
			this.btnModifcaSessione = new System.Windows.Forms.Button();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.gbSessioni.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgSessioni)).BeginInit();
			this.SuspendLayout();
			// 
			// gbSessioni
			// 
			this.gbSessioni.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbSessioni.Controls.Add(this.cbStatoSessione);
			this.gbSessioni.Controls.Add(this.lblStatoSessione);
			this.gbSessioni.Controls.Add(this.edtTitoloSessione);
			this.gbSessioni.Controls.Add(this.lblTitoloSessione);
			this.gbSessioni.Location = new System.Drawing.Point(8, 8);
			this.gbSessioni.Name = "gbSessioni";
			this.gbSessioni.Size = new System.Drawing.Size(664, 88);
			this.gbSessioni.TabIndex = 1;
			this.gbSessioni.TabStop = false;
			this.gbSessioni.Text = "Ricerca Sessioni";
			// 
			// cbStatoSessione
			// 
			this.cbStatoSessione.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cbStatoSessione.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbStatoSessione.Items.AddRange(new object[] {
																 "<qualunque stato sessione>",
																 "In Attesa",
																 "Predisposta",
																 "Aperta",
																 "Sospesa",
																 "Terminata",
																 "Chiusa"});
			this.cbStatoSessione.Location = new System.Drawing.Point(168, 48);
			this.cbStatoSessione.Name = "cbStatoSessione";
			this.cbStatoSessione.Size = new System.Drawing.Size(224, 21);
			this.cbStatoSessione.TabIndex = 3;
			this.toolTip.SetToolTip(this.cbStatoSessione, "Criterio di ricerca per \'Stato Sessione\'");
			this.cbStatoSessione.SelectedIndexChanged += new System.EventHandler(this.cbStatoSessione_SelectedIndexChanged);
			// 
			// lblStatoSessione
			// 
			this.lblStatoSessione.Location = new System.Drawing.Point(16, 56);
			this.lblStatoSessione.Name = "lblStatoSessione";
			this.lblStatoSessione.Size = new System.Drawing.Size(120, 16);
			this.lblStatoSessione.TabIndex = 2;
			this.lblStatoSessione.Text = "Stato Sessione:";
			// 
			// edtTitoloSessione
			// 
			this.edtTitoloSessione.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.edtTitoloSessione.Location = new System.Drawing.Point(168, 16);
			this.edtTitoloSessione.Name = "edtTitoloSessione";
			this.edtTitoloSessione.Size = new System.Drawing.Size(224, 20);
			this.edtTitoloSessione.TabIndex = 1;
			this.edtTitoloSessione.Text = "";
			this.toolTip.SetToolTip(this.edtTitoloSessione, "Criterio di ricerca per \'Titolo Sessione\'");
			this.edtTitoloSessione.TextChanged += new System.EventHandler(this.edtTitoloSessione_TextChanged);
			// 
			// lblTitoloSessione
			// 
			this.lblTitoloSessione.Location = new System.Drawing.Point(8, 24);
			this.lblTitoloSessione.Name = "lblTitoloSessione";
			this.lblTitoloSessione.Size = new System.Drawing.Size(136, 32);
			this.lblTitoloSessione.TabIndex = 0;
			this.lblTitoloSessione.Text = "Titolo Sessione:";
			// 
			// dgSessioni
			// 
			this.dgSessioni.AlternatingBackColor = System.Drawing.Color.LightGray;
			this.dgSessioni.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgSessioni.BackColor = System.Drawing.Color.DarkGray;
			this.dgSessioni.CaptionBackColor = System.Drawing.Color.White;
			this.dgSessioni.CaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
			this.dgSessioni.CaptionForeColor = System.Drawing.Color.Navy;
			this.dgSessioni.CaptionVisible = false;
			this.dgSessioni.CausesValidation = false;
			this.dgSessioni.DataMember = "";
			this.dgSessioni.ForeColor = System.Drawing.Color.Black;
			this.dgSessioni.GridLineColor = System.Drawing.Color.Black;
			this.dgSessioni.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
			this.dgSessioni.HeaderBackColor = System.Drawing.Color.Silver;
			this.dgSessioni.HeaderForeColor = System.Drawing.Color.Black;
			this.dgSessioni.LinkColor = System.Drawing.Color.Navy;
			this.dgSessioni.Location = new System.Drawing.Point(8, 104);
			this.dgSessioni.Name = "dgSessioni";
			this.dgSessioni.ParentRowsBackColor = System.Drawing.Color.White;
			this.dgSessioni.ParentRowsForeColor = System.Drawing.Color.Black;
			this.dgSessioni.ReadOnly = true;
			this.dgSessioni.SelectionBackColor = System.Drawing.Color.Navy;
			this.dgSessioni.SelectionForeColor = System.Drawing.Color.White;
			this.dgSessioni.Size = new System.Drawing.Size(664, 224);
			this.dgSessioni.TabIndex = 2;
			this.toolTip.SetToolTip(this.dgSessioni, "Lista delle sessioni che soddisfano il criterio di ricerca");
			this.dgSessioni.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgSessioni_MouseDown);
			this.dgSessioni.DoubleClick += new System.EventHandler(this.dgSessioni_DoubleClick);
			// 
			// btnNuovaSessione
			// 
			this.btnNuovaSessione.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnNuovaSessione.Location = new System.Drawing.Point(8, 336);
			this.btnNuovaSessione.Name = "btnNuovaSessione";
			this.btnNuovaSessione.Size = new System.Drawing.Size(112, 23);
			this.btnNuovaSessione.TabIndex = 3;
			this.btnNuovaSessione.Text = "Nuova Sessione";
			this.toolTip.SetToolTip(this.btnNuovaSessione, "Crea una nuova sessione");
			this.btnNuovaSessione.Click += new System.EventHandler(this.btnNuovaSessione_Click);
			// 
			// btnEliminaSessione
			// 
			this.btnEliminaSessione.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnEliminaSessione.Location = new System.Drawing.Point(248, 336);
			this.btnEliminaSessione.Name = "btnEliminaSessione";
			this.btnEliminaSessione.Size = new System.Drawing.Size(112, 23);
			this.btnEliminaSessione.TabIndex = 4;
			this.btnEliminaSessione.Text = "Elimina Sessione";
			this.toolTip.SetToolTip(this.btnEliminaSessione, "Elimina la sessione selezionata (comando attivo solo se la sessione e` in stato \'" +
				"In Attesa\')");
			this.btnEliminaSessione.Click += new System.EventHandler(this.btnEliminaSessione_Click);
			// 
			// btnChiudiForm
			// 
			this.btnChiudiForm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChiudiForm.Location = new System.Drawing.Point(560, 336);
			this.btnChiudiForm.Name = "btnChiudiForm";
			this.btnChiudiForm.Size = new System.Drawing.Size(96, 24);
			this.btnChiudiForm.TabIndex = 5;
			this.btnChiudiForm.Text = "Chiudi";
			this.toolTip.SetToolTip(this.btnChiudiForm, "Chiude questa maschera");
			this.btnChiudiForm.Click += new System.EventHandler(this.btnChiudiForm_Click);
			// 
			// btnModifcaSessione
			// 
			this.btnModifcaSessione.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnModifcaSessione.Location = new System.Drawing.Point(128, 336);
			this.btnModifcaSessione.Name = "btnModifcaSessione";
			this.btnModifcaSessione.Size = new System.Drawing.Size(112, 23);
			this.btnModifcaSessione.TabIndex = 6;
			this.btnModifcaSessione.Text = "Modifica Sessione";
			this.toolTip.SetToolTip(this.btnModifcaSessione, "Modifica la sessione selezionata");
			this.btnModifcaSessione.Click += new System.EventHandler(this.btnModifcaSessione_Click);
			// 
			// frmSessioni
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(680, 365);
			this.Controls.Add(this.btnModifcaSessione);
			this.Controls.Add(this.btnChiudiForm);
			this.Controls.Add(this.btnEliminaSessione);
			this.Controls.Add(this.btnNuovaSessione);
			this.Controls.Add(this.dgSessioni);
			this.Controls.Add(this.gbSessioni);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmSessioni";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Titolo Sessione:";
			this.Load += new System.EventHandler(this.frmSessioni_Load);
			this.gbSessioni.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgSessioni)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		// costringe la selezione di tutta la riga quando l'amministratore
		// seleziona una cella
		DataGrid.HitTestInfo _hti;
		private void dgSessioni_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e) 
		{ 
			if (e.Button == MouseButtons.Left)
			{
				DataGrid.HitTestInfo hti = dgSessioni.HitTest(new Point(e.X, e.Y)); 
				if (hti.Type == DataGrid.HitTestType.Cell) 
				{
					_hti = hti;
//					dgSessioni.CurrentCell = new DataGridCell(hti.Row, hti.Column); 
					dgSessioni.Select(hti.Row);
				}
				else
					_hti = null;

			}
		} 
		private void dgSessioni_DoubleClick(object sender, System.EventArgs e)
		{
			if (_hti == null)
				return;

			if (_hti.Type == DataGrid.HitTestType.Cell || 
				_hti.Type == DataGrid.HitTestType.RowHeader)
			{
				if (CurrentRow != null)
					btnModifcaSessione_Click(null, null);
			}
		}

		private void btnChiudiForm_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void btnNuovaSessione_Click(object sender, System.EventArgs e)
		{
			using (frmInserisciSessione2 frm = new frmInserisciSessione2(CurrentDataTable.DataSet))
			{
				frm.ShowDialog();
			}
		}

		private void btnModifcaSessione_Click(object sender, System.EventArgs e)
		{
			if (CurrentRow == null)
			{
				MessageBox.Show("E' necessario selezionare una sessione", "Attenzione!", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			using (frmModificaSessione frm = new frmModificaSessione(CurrentRow))
			{
				if (frm.ShowDialog() == DialogResult.OK)
				{
				}
			}
		}

//		private void dgSessioni_DoubleClick(object sender, System.EventArgs e)
//		{
//			if (CurrentRow != null)
//				btnModifcaSessione_Click(null, null);
//		}



		private void btnEliminaSessione_Click(object sender, System.EventArgs e)
		{
			DataRow dr = CurrentRow;
			if (dr == null)
				return;

			DataTable dt = CurrentDataTable;

			Debug.Assert(((string)dr[dt.Columns["StatoSessione"]]).ToLower() == "In Attesa".ToLower());

			DialogResult r = MessageBox.Show(
				"Vuoi cancellare la sessione selezionata ?\n" +
				"Titolo = " + dr["Titolo"].ToString(),//ToString OK
				"Attenzione",
				MessageBoxButtons.OKCancel,
				MessageBoxIcon.Question);

			if (r == DialogResult.OK)
			{
				dr.Delete();
				AggiornaDataSet(CurrentDataTable.DataSet);
			}
		}

		public static bool AggiornaDataSet(DataSet ds)
		{
			try
			{
				if (ds.HasChanges() == false)
				{
					ds.AcceptChanges();
					return true;
				}

				CVAdminWSBLSessione.BLSessione ww = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ww);

				DataSet dsc = ds.GetChanges();
				if (dsc != null)  // puo' essere null 
				{
					IAsyncResult asr = ww.BeginUpdate(dsc, null, null);
					frmAsyncWait w = new frmAsyncWait(asr);
					w.ShowDialog();
					if (w.Cancelled)
						return false;

					// il Web Service ha risposto... prendo il risultato
					string messaggioErrore = null;
					DataSet dsn = ww.EndUpdate(asr, out messaggioErrore);

					if (messaggioErrore != null)
					{
						MessageBox.Show(messaggioErrore, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
						ds.RejectChanges();
						return false;
					}
					else
					{
						ds.AcceptChanges();
						ds.Merge(dsn, true, MissingSchemaAction.Add);
						ds.AcceptChanges();
					}
				}
				else
				{
					ds.AcceptChanges();
				}

				return true;
			}
			catch (SoapException ex)
			{
				ds.RejectChanges();

				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
			}
			catch (Exception ex)
			{
				ds.RejectChanges();

				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile.\n" + ex.Message, "Errore");
			}

			return false;
		}

		private void cbStatoSessione_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			/*
			string find = null;

			if (cbStatoSessione.SelectedIndex > 0)
			{
				find = "StatoSessione = '" + cbStatoSessione.Text + "' ";
				edtTitoloSessione.Text = "";
				edtTitoloSessione.Enabled = false;
			}
			else
			{
				edtTitoloSessione.Enabled = true;

				if (edtTitoloSessione.Text.Length > 0)
					find = "Titolo LIKE '" + edtTitoloSessione.Text + "%' ";
			}

			if (CurrentDataTable == null)
				return;

			if (find != null)
				_dv.RowFilter = find;
			else
				_dv.RowFilter = "";
			*/
			Filter_Changed(sender, e);
		}

		private void edtTitoloSessione_TextChanged(object sender, System.EventArgs e)
		{
			/*
			if (CurrentDataTable == null)
				return;

			if (edtTitoloSessione.Text.Length == 0)
				cbStatoSessione.Enabled = true;
			else
				cbStatoSessione.Enabled = false;

			cbStatoSessione.SelectedIndex = 0;

			cbStatoSessione_SelectedIndexChanged(sender, e);
			*/
			Filter_Changed(sender, e);
		}

		private void Filter_Changed(object sender, System.EventArgs e)
		{
			if (CurrentDataTable == null)
				return;

			string f = "";
			if (edtTitoloSessione.Text.Length > 0)
				f += "( Titolo LIKE '" + edtTitoloSessione.Text + "%' )";

			if (cbStatoSessione.SelectedIndex > 0)
			{
				if (f.Length > 0)
					f += " AND ";
				f += " ( StatoSessione = '" + cbStatoSessione.Text + "' ) ";
			}

			_dv.RowFilter = f;
		}


	}
}
