using System;
using System.Drawing;
using System.Data;
using System.Collections;
using System.Diagnostics;
using System.ComponentModel;
using System.Windows.Forms;
using System.Globalization;
using System.Web.Services.Protocols;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmInserisciSessione2.
	/// </summary>
	public class frmInserisciSessione2 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label lblTitolo;
		private System.Windows.Forms.TextBox edtTitolo;
		private System.Windows.Forms.Label lblDataApertura;
		private System.Windows.Forms.DateTimePicker dtpDataApertura;
		private System.Windows.Forms.DateTimePicker dtpDataChiusura;
		private System.Windows.Forms.Label lblChiusura;
		private System.Windows.Forms.Label lblPrezzoConvenzionale;
		private System.Windows.Forms.TextBox edtPrezzoConvenzionale;
		private System.Windows.Forms.Label lblSessioni;
		private System.Windows.Forms.ComboBox cbSessioni;
		private System.Windows.Forms.Button btnCalcolaPrezziRif;
		private System.Windows.Forms.Button btnCancella;
		private System.Windows.Forms.Button btnSalva;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		// 
		private System.Windows.Forms.CheckBox ckPrezzoRifAnnoPrec;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoSucc;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoCorr;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoPrec;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;

		DataSet _ds;
		DataRow _dr;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cbAnniRiferimento;
		private System.Windows.Forms.TextBox edtPrezziRiferimento;
		BindingManagerBase _bmgr;

		public class TitoloIdSessione : IComparable
		{
			public TitoloIdSessione(string t, string id, DateTime dt) { _t = t; _id = id; _dt = dt; }

			public string Titolo { get { return _t; } }
			public string IdSessione { get { return _id; } }

			public string _t;
			public string _id;
			public DateTime _dt;

			public int CompareTo(object x)
			{
				TitoloIdSessione tx = (TitoloIdSessione)x;

				if (_dt > tx._dt) return -1;
				if (_dt < tx._dt) return +1;
				return 0;
			}
		}

		public frmInserisciSessione2()
		{
			InitializeComponent();
		}

		public frmInserisciSessione2(DataSet ds)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();


			ckPrezzoRifAnnoPrec.Checked = true;

			_ds = ds;
			DataTable dt = _ds.Tables[0];

			// riempo la CB con i titoli presenti (nel DataSet ci sono tutti)
			if (true)
			{
				ArrayList ar = new ArrayList();
				foreach (DataRow r in dt.Rows)
				{
					if (r.RowState != DataRowState.Deleted)
					{
						TitoloIdSessione d = new TitoloIdSessione(
							(string)r["Titolo"], 
							(string)r["IdSessione"],
							(DateTime)r["DataOraApertura"]);
						ar.Add(d);
					}
				}

				// sort il modo DESC rispetto alla DataOraApertura
				ar.Sort();
				cbSessioni.DisplayMember = "Titolo";
				cbSessioni.ValueMember = "IdSessione";
				cbSessioni.DataSource = ar;
			}

			// mapping della nuova sessione

			// un po di valori di default.
			{
				_dr = dt.NewRow();
				_dr["IdSessione"] = NewIdHelper.NewId();
				_dr["Titolo"] = "Titolo";
				_dr["DataOraApertura"] = DateTime.Now;
				_dr["DataOraChiusura"] = DateTime.Now;
				_dr["PrezzoRiferimentoAnnoPrec"] = 0;
				_dr["PrezzoRiferimentoAnnoCorr"] = 0;
				_dr["PrezzoRiferimentoAnnoSucc"] = 0;
				_dr["PrezzoConvenzionale"] = 0;
				_dr["DataOraCreazione"] = DateTime.Now; // OK poi chiedo la data al db
				_dr["DataOraModifica"] = DateTime.Now;  // OK poi chiedo la data al db
				_dr["StatoSessione"] = "In Attesa";
				// questi andranno a finire nel "Current"

				// la riga fa parte del data set
				dt.Rows.Add(_dr);

				// ... sperando che sia l'ultima.
				_bmgr = this.BindingContext[dt.DataSet, "Sessioni"];
				_bmgr.Position = dt.Rows.Count - 1;
				Debug.Assert(_dr == dt.Rows[dt.Rows.Count - 1]);
			}



			Binding bnd;


			// bindings con i controlli....
			// quando l'utente edita nei controlli mettera' il tutto nei "Proposed" (ossia avviene un BeginEdit implicita)
			bnd = edtTitolo.DataBindings.Add("Text", _ds, "Sessioni.Titolo");
			bnd.Parse  += new ConvertEventHandler(TitoloStringToString);

			dtpDataApertura.DataBindings.Add("Value", _ds, "Sessioni.DataOraApertura");
			dtpDataChiusura.DataBindings.Add("Value", _ds, "Sessioni.DataOraChiusura");
			//			dtpOraApertura.DataBindings.Add("Value", _ds, "Sessioni.DataOraApertura");
			//			dtpOraChiusura.DataBindings.Add("Value", _ds, "Sessioni.DataOraChiusura");

			// formattazione PrezzoConvenzionale
			bnd = edtPrezzoConvenzionale.DataBindings.Add("Text", _ds, "Sessioni.PrezzoConvenzionale");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(CurrencyStringToDecimal);

			bnd = edtPrezzoRifAnnoPrec.DataBindings.Add("Text", _ds, "Sessioni.PrezzoRiferimentoAnnoPrec");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(CurrencyStringToDecimal);

			bnd = edtPrezzoRifAnnoCorr.DataBindings.Add("Text", _ds, "Sessioni.PrezzoRiferimentoAnnoCorr");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(CurrencyStringToDecimal);

			bnd = edtPrezzoRifAnnoSucc.DataBindings.Add("Text", _ds, "Sessioni.PrezzoRiferimentoAnnoSucc");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(CurrencyStringToDecimal);

			// disabilitazione bottone calcolo prezzi di riferimento
			cbSessioni_SelectedIndexChanged(null,null);

			int AnnoMin = 0 ;
			int AnnoMax = 0 ;
			DateTime dat = DateTime.Now ;
			bool ris = ContrattaCVAnnoMin(dat.Month, out AnnoMin, out AnnoMax);
			if (ris == false)
				AnnoMin += 1;
			for (int i=AnnoMin;i<=AnnoMax;i++)
			{
				if ((i != dat.Year) && (i != (dat.Year - 1)) && (i != (dat.Year + 1)))
				{
					cbAnniRiferimento.Items.Add(i.ToString());
				}
			}
			if ((AnnoMin >=  (dat.Year - 1)) && (AnnoMax <= (dat.Year + 1)))
			{
				cbAnniRiferimento.Text = "" ;
				cbAnniRiferimento.Enabled = false ;
				edtPrezziRiferimento.Enabled = false ;
			}
			else
			{
				cbAnniRiferimento.Enabled = true ;
				edtPrezziRiferimento.Enabled = true ;
				cbAnniRiferimento.SelectedIndex = 0 ;
			}
		}

		private bool ContrattaCVAnnoMin(int month, out int AnnoMin, out int AnnoMax)
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ws = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ws);

				return ws.ContrattaCVAnnoMin(month, out AnnoMin, out AnnoMax);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				AnnoMin = 0 ;
				AnnoMax = 0 ;
				return false;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				AnnoMin = 0 ;
				AnnoMax = 0 ;
				return false;
			}
		}

		private void SettaPrezziRiferimento()
		{
			if (cbAnniRiferimento.Enabled == true)
			{
				DateTime dt = DateTime.Now ;
				int n = Convert.ToInt32(cbAnniRiferimento.Text) - dt.Year ;
				if (n == -10)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec10"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec10"]));
					}
				}
				else if (n == -9)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec09"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec09"]));
					}
				}
				else if (n == -8)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec08"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec08"]));
					}
				}
				else if (n == -7)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec07"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec07"]));
					}
				}
				else if (n == -6)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec06"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec06"]));
					}
				}
				else if (n == -5)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec05"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec05"]));
					}
				}
				else if (n == -4)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec04"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec04"]));
					}
				}
				else if (n == -3)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec03"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec03"]));
					}
				}
				else if (n == -2)
				{
					if (_dr["PrezzoRiferimentoAnnoPrec02"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec02"]));
					}
				}
				else if (n == 2)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc02"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc02"]));
					}
				}
				else if (n == 3)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc03"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc03"]));
					}
				}
				else if (n == 4)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc04"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc04"]));
					}
				}
				else if (n == 5)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc05"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc05"]));
					}
				}
				else if (n == 6)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc06"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc06"]));
					}
				}
				else if (n == 7)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc07"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc07"]));
					}
				}
				else if (n == 8)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc08"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc08"]));
					}
				}
				else if (n == 9)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc09"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc09"]));
					}
				}
				else if (n == 10)
				{
					if (_dr["PrezzoRiferimentoAnnoSucc10"] is DBNull)
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
					}
					else
					{
						edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc10"]));
					}
				}
			}
		}

		private void cbAnniRiferimento_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SettaPrezziRiferimento();
		}
					
		private void edtPrezziRiferimento_Validated(object sender, System.EventArgs e)
		{
			try
			{
				edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Converter.NumberStringToDecimal(edtPrezziRiferimento.Text));
				DateTime dt = DateTime.Now ;
				int n = Convert.ToInt32(cbAnniRiferimento.Text) - dt.Year ;
				if (n == -10)
				{
					_dr["PrezzoRiferimentoAnnoPrec10"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -9)
				{
					_dr["PrezzoRiferimentoAnnoPrec09"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -8)
				{
					_dr["PrezzoRiferimentoAnnoPrec08"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -7)
				{
					_dr["PrezzoRiferimentoAnnoPrec07"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -6)
				{
					_dr["PrezzoRiferimentoAnnoPrec06"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -5)
				{
					_dr["PrezzoRiferimentoAnnoPrec05"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -4)
				{
					_dr["PrezzoRiferimentoAnnoPrec04"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -3)
				{
					_dr["PrezzoRiferimentoAnnoPrec03"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -2)
				{
					_dr["PrezzoRiferimentoAnnoPrec02"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 2)
				{
					_dr["PrezzoRiferimentoAnnoSucc02"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 3)
				{
					_dr["PrezzoRiferimentoAnnoSucc03"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 4)
				{
					_dr["PrezzoRiferimentoAnnoSucc04"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 5)
				{
					_dr["PrezzoRiferimentoAnnoSucc05"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 6)
				{
					_dr["PrezzoRiferimentoAnnoSucc06"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 7)
				{
					_dr["PrezzoRiferimentoAnnoSucc07"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 8)
				{
					_dr["PrezzoRiferimentoAnnoSucc08"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 9)
				{
					_dr["PrezzoRiferimentoAnnoSucc09"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 10)
				{
					_dr["PrezzoRiferimentoAnnoSucc10"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
			}
			catch(Exception)
			{
				try
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text));
					DateTime dt = DateTime.Now ;
					int n = Convert.ToInt32(cbAnniRiferimento.Text) - dt.Year ;
					if (n == -10)
					{
						_dr["PrezzoRiferimentoAnnoPrec10"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -9)
					{
						_dr["PrezzoRiferimentoAnnoPrec09"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -8)
					{
						_dr["PrezzoRiferimentoAnnoPrec08"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -7)
					{
						_dr["PrezzoRiferimentoAnnoPrec07"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -6)
					{
						_dr["PrezzoRiferimentoAnnoPrec06"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -5)
					{
						_dr["PrezzoRiferimentoAnnoPrec05"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -4)
					{
						_dr["PrezzoRiferimentoAnnoPrec04"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -3)
					{
						_dr["PrezzoRiferimentoAnnoPrec03"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -2)
					{
						_dr["PrezzoRiferimentoAnnoPrec02"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 2)
					{
						_dr["PrezzoRiferimentoAnnoSucc02"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 3)
					{
						_dr["PrezzoRiferimentoAnnoSucc03"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 4)
					{
						_dr["PrezzoRiferimentoAnnoSucc04"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 5)
					{
						_dr["PrezzoRiferimentoAnnoSucc05"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 6)
					{
						_dr["PrezzoRiferimentoAnnoSucc06"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 7)
					{
						_dr["PrezzoRiferimentoAnnoSucc07"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 8)
					{
						_dr["PrezzoRiferimentoAnnoSucc08"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 9)
					{
						_dr["PrezzoRiferimentoAnnoSucc09"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 10)
					{
						_dr["PrezzoRiferimentoAnnoSucc10"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
				}
				catch(Exception)
				{
					MessageBox.Show("Valore del prezzo di riferimento non valido", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}
			}
		}

		private void DecimalToCurrencyString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(string))
				return;

			Binding bng = sender as Binding;
			if (bng != null && bng.Control == edtPrezzoRifAnnoPrec && ckPrezzoRifAnnoPrec.Checked == false)
				cevent.Value = "";
			else
			{
				decimal d = ((decimal) cevent.Value);
				if (d >= 0m)
					cevent.Value = Converter.DecimalToCurrencyString(d);
				else
					cevent.Value = "";
			}
		}

		private void CurrencyStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(decimal))
				return;

			Binding bng = sender as Binding;
			if (bng != null && bng.Control == edtPrezzoRifAnnoPrec && ckPrezzoRifAnnoPrec.Checked == false)
				cevent.Value = -1m;
			else
			{
				decimal d = Converter.CurrencyStringToDecimal((string)cevent.Value);
				if (d < 0m)
					throw new Exception("prezzo minore di zero");

				cevent.Value = d;
			}
		}


		private void TitoloStringToString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(string))
				return;

			string d = ((string) cevent.Value); // valore nella edit

			// controllo la lunghezza .... se e' errata rimette l'original al posto del proposed
			if (d.Length == 0)
				throw new Exception("Il titolo deve essere una stringa di almeno un carattere");

			cevent.Value = d;
		}


		private void RefreshBinding()
		{
//			if (_bmgr == null)
//				return;
//			int p = _bmgr.Position;
//			_bmgr.Position = _bmgr.Count;
//			_bmgr.Position = p;
			if (_bmgr != null && _bmgr is CurrencyManager)
				((CurrencyManager)_bmgr).Refresh();
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmInserisciSessione2));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.edtPrezziRiferimento = new System.Windows.Forms.TextBox();
			this.cbAnniRiferimento = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.ckPrezzoRifAnnoPrec = new System.Windows.Forms.CheckBox();
			this.edtPrezzoRifAnnoSucc = new System.Windows.Forms.TextBox();
			this.edtPrezzoRifAnnoCorr = new System.Windows.Forms.TextBox();
			this.edtPrezzoRifAnnoPrec = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.edtPrezzoConvenzionale = new System.Windows.Forms.TextBox();
			this.lblPrezzoConvenzionale = new System.Windows.Forms.Label();
			this.dtpDataChiusura = new System.Windows.Forms.DateTimePicker();
			this.lblChiusura = new System.Windows.Forms.Label();
			this.dtpDataApertura = new System.Windows.Forms.DateTimePicker();
			this.lblDataApertura = new System.Windows.Forms.Label();
			this.edtTitolo = new System.Windows.Forms.TextBox();
			this.lblTitolo = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.btnCalcolaPrezziRif = new System.Windows.Forms.Button();
			this.cbSessioni = new System.Windows.Forms.ComboBox();
			this.lblSessioni = new System.Windows.Forms.Label();
			this.btnCancella = new System.Windows.Forms.Button();
			this.btnSalva = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.edtPrezziRiferimento);
			this.groupBox1.Controls.Add(this.cbAnniRiferimento);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.ckPrezzoRifAnnoPrec);
			this.groupBox1.Controls.Add(this.edtPrezzoRifAnnoSucc);
			this.groupBox1.Controls.Add(this.edtPrezzoRifAnnoCorr);
			this.groupBox1.Controls.Add(this.edtPrezzoRifAnnoPrec);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.edtPrezzoConvenzionale);
			this.groupBox1.Controls.Add(this.lblPrezzoConvenzionale);
			this.groupBox1.Controls.Add(this.dtpDataChiusura);
			this.groupBox1.Controls.Add(this.lblChiusura);
			this.groupBox1.Controls.Add(this.dtpDataApertura);
			this.groupBox1.Controls.Add(this.lblDataApertura);
			this.groupBox1.Controls.Add(this.edtTitolo);
			this.groupBox1.Controls.Add(this.lblTitolo);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(576, 264);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = " Dati sessione ";
			// 
			// edtPrezziRiferimento
			// 
			this.edtPrezziRiferimento.Location = new System.Drawing.Point(280, 232);
			this.edtPrezziRiferimento.Name = "edtPrezziRiferimento";
			this.edtPrezziRiferimento.Size = new System.Drawing.Size(176, 20);
			this.edtPrezziRiferimento.TabIndex = 28;
			this.edtPrezziRiferimento.Text = "";
			this.edtPrezziRiferimento.Validated += new System.EventHandler(this.edtPrezziRiferimento_Validated);
			// 
			// cbAnniRiferimento
			// 
			this.cbAnniRiferimento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbAnniRiferimento.Location = new System.Drawing.Point(176, 232);
			this.cbAnniRiferimento.Name = "cbAnniRiferimento";
			this.cbAnniRiferimento.Size = new System.Drawing.Size(96, 21);
			this.cbAnniRiferimento.TabIndex = 27;
			this.cbAnniRiferimento.SelectedIndexChanged += new System.EventHandler(this.cbAnniRiferimento_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 232);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(160, 24);
			this.label4.TabIndex = 26;
			this.label4.Text = "Prezzo riferimento(MWh) anno";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// ckPrezzoRifAnnoPrec
			// 
			this.ckPrezzoRifAnnoPrec.Checked = true;
			this.ckPrezzoRifAnnoPrec.CheckState = System.Windows.Forms.CheckState.Checked;
			this.ckPrezzoRifAnnoPrec.Enabled = false;
			this.ckPrezzoRifAnnoPrec.Location = new System.Drawing.Point(416, 48);
			this.ckPrezzoRifAnnoPrec.Name = "ckPrezzoRifAnnoPrec";
			this.ckPrezzoRifAnnoPrec.Size = new System.Drawing.Size(144, 24);
			this.ckPrezzoRifAnnoPrec.TabIndex = 25;
			this.ckPrezzoRifAnnoPrec.Text = "Includi questo campo";
			this.ckPrezzoRifAnnoPrec.Visible = false;
			this.ckPrezzoRifAnnoPrec.CheckedChanged += new System.EventHandler(this.ckPrezzoRifAnnoPrec_CheckedChanged);
			// 
			// edtPrezzoRifAnnoSucc
			// 
			this.edtPrezzoRifAnnoSucc.Location = new System.Drawing.Point(280, 200);
			this.edtPrezzoRifAnnoSucc.Name = "edtPrezzoRifAnnoSucc";
			this.edtPrezzoRifAnnoSucc.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoRifAnnoSucc.TabIndex = 24;
			this.edtPrezzoRifAnnoSucc.Text = "";
			// 
			// edtPrezzoRifAnnoCorr
			// 
			this.edtPrezzoRifAnnoCorr.Location = new System.Drawing.Point(280, 176);
			this.edtPrezzoRifAnnoCorr.Name = "edtPrezzoRifAnnoCorr";
			this.edtPrezzoRifAnnoCorr.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoRifAnnoCorr.TabIndex = 23;
			this.edtPrezzoRifAnnoCorr.Text = "";
			// 
			// edtPrezzoRifAnnoPrec
			// 
			this.edtPrezzoRifAnnoPrec.Location = new System.Drawing.Point(280, 152);
			this.edtPrezzoRifAnnoPrec.Name = "edtPrezzoRifAnnoPrec";
			this.edtPrezzoRifAnnoPrec.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoRifAnnoPrec.TabIndex = 22;
			this.edtPrezzoRifAnnoPrec.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 208);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(224, 23);
			this.label3.TabIndex = 21;
			this.label3.Text = "Prezzo riferimento anno successivo MWh";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 184);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(224, 23);
			this.label2.TabIndex = 20;
			this.label2.Text = "Prezzo riferimento anno corrente MWh";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 160);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(224, 23);
			this.label1.TabIndex = 19;
			this.label1.Text = "Prezzo riferimento anno precedente MWh";
			// 
			// edtPrezzoConvenzionale
			// 
			this.edtPrezzoConvenzionale.Location = new System.Drawing.Point(168, 120);
			this.edtPrezzoConvenzionale.Name = "edtPrezzoConvenzionale";
			this.edtPrezzoConvenzionale.Size = new System.Drawing.Size(192, 20);
			this.edtPrezzoConvenzionale.TabIndex = 9;
			this.edtPrezzoConvenzionale.Text = "";
			// 
			// lblPrezzoConvenzionale
			// 
			this.lblPrezzoConvenzionale.Location = new System.Drawing.Point(16, 120);
			this.lblPrezzoConvenzionale.Name = "lblPrezzoConvenzionale";
			this.lblPrezzoConvenzionale.Size = new System.Drawing.Size(128, 16);
			this.lblPrezzoConvenzionale.TabIndex = 8;
			this.lblPrezzoConvenzionale.Text = "Prezzo convenzionale:";
			// 
			// dtpDataChiusura
			// 
			this.dtpDataChiusura.CustomFormat = "dd\'/\'MM\'/\'yyyy HH\':\'mm";
			this.dtpDataChiusura.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpDataChiusura.Location = new System.Drawing.Point(168, 88);
			this.dtpDataChiusura.Name = "dtpDataChiusura";
			this.dtpDataChiusura.Size = new System.Drawing.Size(128, 20);
			this.dtpDataChiusura.TabIndex = 6;
			// 
			// lblChiusura
			// 
			this.lblChiusura.Location = new System.Drawing.Point(16, 88);
			this.lblChiusura.Name = "lblChiusura";
			this.lblChiusura.Size = new System.Drawing.Size(128, 16);
			this.lblChiusura.TabIndex = 5;
			this.lblChiusura.Text = "Data/ora chiusura:";
			// 
			// dtpDataApertura
			// 
			this.dtpDataApertura.CustomFormat = "dd\'/\'MM\'/\'yyyy HH\':\'mm";
			this.dtpDataApertura.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpDataApertura.Location = new System.Drawing.Point(168, 56);
			this.dtpDataApertura.Name = "dtpDataApertura";
			this.dtpDataApertura.Size = new System.Drawing.Size(128, 20);
			this.dtpDataApertura.TabIndex = 3;
			// 
			// lblDataApertura
			// 
			this.lblDataApertura.Location = new System.Drawing.Point(16, 56);
			this.lblDataApertura.Name = "lblDataApertura";
			this.lblDataApertura.Size = new System.Drawing.Size(128, 16);
			this.lblDataApertura.TabIndex = 2;
			this.lblDataApertura.Text = "Data/ora apertura:";
			// 
			// edtTitolo
			// 
			this.edtTitolo.Location = new System.Drawing.Point(168, 24);
			this.edtTitolo.Name = "edtTitolo";
			this.edtTitolo.Size = new System.Drawing.Size(392, 20);
			this.edtTitolo.TabIndex = 1;
			this.edtTitolo.Text = "";
			// 
			// lblTitolo
			// 
			this.lblTitolo.Location = new System.Drawing.Point(16, 24);
			this.lblTitolo.Name = "lblTitolo";
			this.lblTitolo.Size = new System.Drawing.Size(104, 24);
			this.lblTitolo.TabIndex = 0;
			this.lblTitolo.Text = "Titolo sessione:";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.btnCalcolaPrezziRif);
			this.groupBox2.Controls.Add(this.cbSessioni);
			this.groupBox2.Controls.Add(this.lblSessioni);
			this.groupBox2.Location = new System.Drawing.Point(8, 280);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(576, 64);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = " Calcolo prezzo di riferimento";
			// 
			// btnCalcolaPrezziRif
			// 
			this.btnCalcolaPrezziRif.Location = new System.Drawing.Point(408, 24);
			this.btnCalcolaPrezziRif.Name = "btnCalcolaPrezziRif";
			this.btnCalcolaPrezziRif.Size = new System.Drawing.Size(160, 24);
			this.btnCalcolaPrezziRif.TabIndex = 19;
			this.btnCalcolaPrezziRif.Text = "Calcolo prezzi di riferimento";
			this.btnCalcolaPrezziRif.Click += new System.EventHandler(this.btnCalcolaPrezziRif_Click);
			// 
			// cbSessioni
			// 
			this.cbSessioni.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbSessioni.Location = new System.Drawing.Point(104, 24);
			this.cbSessioni.Name = "cbSessioni";
			this.cbSessioni.Size = new System.Drawing.Size(296, 21);
			this.cbSessioni.TabIndex = 10;
			this.cbSessioni.SelectedIndexChanged += new System.EventHandler(this.cbSessioni_SelectedIndexChanged);
			// 
			// lblSessioni
			// 
			this.lblSessioni.Location = new System.Drawing.Point(16, 24);
			this.lblSessioni.Name = "lblSessioni";
			this.lblSessioni.Size = new System.Drawing.Size(72, 16);
			this.lblSessioni.TabIndex = 9;
			this.lblSessioni.Text = "Sessioni";
			// 
			// btnCancella
			// 
			this.btnCancella.Location = new System.Drawing.Point(464, 360);
			this.btnCancella.Name = "btnCancella";
			this.btnCancella.Size = new System.Drawing.Size(112, 24);
			this.btnCancella.TabIndex = 2;
			this.btnCancella.Text = "Cancella";
			this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
			// 
			// btnSalva
			// 
			this.btnSalva.Location = new System.Drawing.Point(344, 360);
			this.btnSalva.Name = "btnSalva";
			this.btnSalva.Size = new System.Drawing.Size(112, 24);
			this.btnSalva.TabIndex = 3;
			this.btnSalva.Text = "Salva";
			this.btnSalva.Click += new System.EventHandler(this.btnSalva_Click);
			// 
			// frmInserisciSessione2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(592, 399);
			this.ControlBox = false;
			this.Controls.Add(this.btnSalva);
			this.Controls.Add(this.btnCancella);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmInserisciSessione2";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Inserimento nuova sessione";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void cbSessioni_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (cbSessioni.SelectedIndex == -1)
				btnCalcolaPrezziRif.Enabled = false;
			else
				btnCalcolaPrezziRif.Enabled = true;
		}

		private void btnCalcolaPrezziRif_Click(object sender, System.EventArgs e)
		{
			try
			{
				string IdSessione = (string)cbSessioni.SelectedValue;
				CVAdminWSBLSessione.BLSessione bl = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginGetPrezziRiferimento(IdSessione, null, null);
				frmAsyncWait w = new frmAsyncWait(asr);
				w.ShowDialog(this);
				if (w.Cancelled)
					return;

				CVAdminWSBLSessione.PrezziRiferimento pr = bl.EndGetPrezziRiferimento(asr);

				if (ckPrezzoRifAnnoPrec.Checked == false)
					pr.PrezzoRiferimentoAnnoPrec = -1m;

				_dr["PrezzoRiferimentoAnnoPrec10"] = pr.PrezzoRiferimentoAnnoPrec10;
				_dr["PrezzoRiferimentoAnnoPrec09"] = pr.PrezzoRiferimentoAnnoPrec09;
				_dr["PrezzoRiferimentoAnnoPrec08"] = pr.PrezzoRiferimentoAnnoPrec08;
				_dr["PrezzoRiferimentoAnnoPrec07"] = pr.PrezzoRiferimentoAnnoPrec07;
				_dr["PrezzoRiferimentoAnnoPrec06"] = pr.PrezzoRiferimentoAnnoPrec06;
				_dr["PrezzoRiferimentoAnnoPrec05"] = pr.PrezzoRiferimentoAnnoPrec05;
				_dr["PrezzoRiferimentoAnnoPrec04"] = pr.PrezzoRiferimentoAnnoPrec04;
				_dr["PrezzoRiferimentoAnnoPrec03"] = pr.PrezzoRiferimentoAnnoPrec03;
				_dr["PrezzoRiferimentoAnnoPrec02"] = pr.PrezzoRiferimentoAnnoPrec02;
				_dr["PrezzoRiferimentoAnnoPrec"] = pr.PrezzoRiferimentoAnnoPrec;
				_dr["PrezzoRiferimentoAnnoCorr"] = pr.PrezzoRiferimentoAnnoCorr;
				_dr["PrezzoRiferimentoAnnoSucc"] = pr.PrezzoRiferimentoAnnoSucc;
				_dr["PrezzoRiferimentoAnnoSucc02"] = pr.PrezzoRiferimentoAnnoSucc02;
				_dr["PrezzoRiferimentoAnnoSucc03"] = pr.PrezzoRiferimentoAnnoSucc03;
				_dr["PrezzoRiferimentoAnnoSucc04"] = pr.PrezzoRiferimentoAnnoSucc04;
				_dr["PrezzoRiferimentoAnnoSucc05"] = pr.PrezzoRiferimentoAnnoSucc05;
				_dr["PrezzoRiferimentoAnnoSucc06"] = pr.PrezzoRiferimentoAnnoSucc06;
				_dr["PrezzoRiferimentoAnnoSucc07"] = pr.PrezzoRiferimentoAnnoSucc07;
				_dr["PrezzoRiferimentoAnnoSucc08"] = pr.PrezzoRiferimentoAnnoSucc08;
				_dr["PrezzoRiferimentoAnnoSucc09"] = pr.PrezzoRiferimentoAnnoSucc09;
				_dr["PrezzoRiferimentoAnnoSucc10"] = pr.PrezzoRiferimentoAnnoSucc10;

				RefreshBinding();

				SettaPrezziRiferimento();
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
			}
		}

		private void ckPrezzoRifAnnoPrec_CheckedChanged(object sender, System.EventArgs e)
		{
			if (_dr == null)
				return;

			if (ckPrezzoRifAnnoPrec.Checked == false)
				_dr["PrezzoRiferimentoAnnoPrec"] = -1m;
			else
				_dr["PrezzoRiferimentoAnnoPrec"] = 0m;

			// RefreshBinding();
		}

		private void btnCancella_Click(object sender, System.EventArgs e)
		{
			_dr.Delete();  // tolgo la riga dalla tabella

			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void btnSalva_Click(object sender, System.EventArgs e)
		{
			if (_dr.HasVersion(DataRowVersion.Proposed))
			{
				if ((DateTime)_dr["DataOraApertura", DataRowVersion.Proposed] > 
					(DateTime)_dr["DataOraChiusura", DataRowVersion.Proposed])
				{
					MessageBox.Show(this, "La data/ora di chiusura deve essere successiva alla data/ora apertura", "Errore");
					return;
				}


				if ((string)_dr["StatoSessione", DataRowVersion.Current] != "Predisposta" &&
					(string)_dr["StatoSessione", DataRowVersion.Proposed] == "Predisposta")
				{
					MessageBox.Show("La sessione puo' andare in stato 'Predisposta' solo tramite l'operazione di 'Import XML'");
					return;
				}
			}


			_dr.EndEdit();

			if (ckPrezzoRifAnnoPrec.Checked == false)
				_dr["PrezzoRiferimentoAnnoPrec"] = -1m;

			DateTime dt = DbTime.GetDbSystemDate();
			_dr["DataOraCreazione"] = dt;
			_dr["DataOraModifica"] = dt;

			if (frmSessioni.AggiornaDataSet(_ds))
			{
				this.DialogResult = DialogResult.OK;
				this.Close();
			}
		}
	}
}
