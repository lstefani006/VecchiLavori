using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using ExcelHelper;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmTransazioni.
	/// </summary>
	public class frmTransazioni : System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.Label lblRagioneSociale;
		private System.Windows.Forms.ComboBox cbRagioneSociale;
		private System.Windows.Forms.GroupBox gbCriteriRicerca;
		private System.Windows.Forms.RadioButton rbTutte;
		private System.Windows.Forms.RadioButton rbTransazioniAcquisto;
		private System.Windows.Forms.RadioButton rbTransazioniVendita;
		private System.Windows.Forms.Button btnDaValidare;
		private System.Windows.Forms.Button btnValida;
		private System.Windows.Forms.Button btnNonValida;
		private System.Windows.Forms.Button btnInadempiente;
		private System.Windows.Forms.Button btnValidaTutte;
		private System.Windows.Forms.TextBox tbDeposito;
		private System.Windows.Forms.Label lblDeposito;
		private System.Windows.Forms.TextBox tbTotaleAcquisti;
		private System.Windows.Forms.Label lblTotAcquisti;
		private System.Windows.Forms.DataGrid dgTransazioni;
		private System.Windows.Forms.Button btnExcel;
		private System.Windows.Forms.ToolTip tltInfo;
		private System.Windows.Forms.SaveFileDialog dlgEsportaXls;
		
		private DataView	_dvTransazioni		= null;
		private DataTable	_dtTransazioni		= null;
		private DataSet		_dsListaTransazioni = null;
		private DataSet		_dsListaSocieta		= null;
		private DataSet		_dsTotaleAcquisti	= null;
		private DataRow		_drSelectedSession	= null;
		private System.Windows.Forms.Label lblCodiceConto;
		private System.Windows.Forms.ComboBox cbCodiceConto;
		private ArrayList	_alRagioniSociali	= null;

		// Tipi di filtraggio da effettuare sulle righe del DataGrid
		enum DGFilterType {Acquisto, Vendita, Tutte};

		enum DGColumnID
		{
			cIdTransazione = 0,
			cAcquirente,
			cAcquirente_NominativoUtente,
			cAcquirenteABI,
			cAcquirenteCAB,
			cAcquirenteCC,
			cAnnoRiferimento,
			cVenditore,
			cVenditore_NominativoUtente,
			cVenditoreABI,
			cVenditoreCAB,
			cVenditoreCC,
			cCodiceContoAcquirente,
			cCodiceContoVenditore,
			cIdOffertaAcquisto,
			cIdOffertaVendita,
			cQtyCertificati,
			cPrezzoUnitario,
			cControValore,
			cDataOraOperazione,
			cStatoTransazione,
			cImportoA,
			cImportoV,
			cPrezzoConvUtenteMwA,		
			cPrezzoConvUtenteMwV
		};

		// Classe utilizzata per effettuare il DataBinding sulla ComboBox delle Ragioni Sociali.
		// Poiche' Il DataSet delle Ragioni sociali non contiene un item che mi permette di 
		// visualizzare le Transazioni di TUTTE le societa' devo utilizzare come DataSource per
		// la Combo Box un ArrayList.
		// Tale Array List conterra' come primo valore un item che mi permettera' di
		// visualizzare le transazioni di TUTTE le societa'
		internal class cbBind
		{
			//public cbBind(string s) { _Name = s; }
			//public cbBind(string name, string val) { _Name = name; _Value = val; }
			public cbBind(string name, string val, decimal totaleAcquisti, string codiceConto) { _Name = name; _Value = val; _TotAcquisti = totaleAcquisti; _CodiceConto = codiceConto;}
			public string Name { get { return _Name; } }
			public string Value { get { return _Value; } }
			public string CodiceConto { get { return _CodiceConto; } }
			public decimal TotaleAcquisti { get { return _TotAcquisti;} }
			string _Name;
			string _Value;
			string _CodiceConto;
			decimal _TotAcquisti;
		}

		public frmTransazioni()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		public frmTransazioni(DataRow drSessioneSelezionata, DataSet dsListaTransazioni)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			_drSelectedSession = drSessioneSelezionata;
			_dsListaTransazioni = dsListaTransazioni;
			// Verifico che i parametri siano diversi da "null"
			if (_drSelectedSession == null)
			{
				DisabilitaComponenti();
				return;
			}
			if (dsListaTransazioni == null)
			{
				DisabilitaComponenti();
				return;
			}
			// Cambio il titolo della form in funzione della Sessione selezionata
			this.Text += " - Titolo Sessione: \"" + (string)_drSelectedSession["Titolo"] + "\"";

			_dsListaSocieta = GetListaSocieta();
			if (_dsListaSocieta == null)
			{
				DisabilitaComponenti();
				return;
			}

			_dsTotaleAcquisti = GetTotaleAcquisti((string)_drSelectedSession["IdSessione"]);
			if (_dsTotaleAcquisti == null)
			{
				DisabilitaComponenti();
				return;
			}

			// Bindind della lista delle Transazioni con il DataGrid
			BindDataGridDataSource(dsListaTransazioni);
			// Mapping delle colonne della Griglia
			SetDataGridMapping();

			// Creo la Lista delle Ragioni Sociali
			_alRagioniSociali = new ArrayList();
			BuildArrayList(_dsListaSocieta.Tables[0], _dsTotaleAcquisti.Tables[0], _alRagioniSociali);
			// Binding della lista delle Societa' con la ComboBox
			BindComboDataSource(_alRagioniSociali);
			// Binding della lista con la TextBox "Totale Acquisti"
			BindTotaleAcquisti(_alRagioniSociali);

			// Se cambio la Ragione sociale devo filtrare opportunamente i dati da visualizzare
			// nel DataGrid 
			BindingManagerBase bmCombo = cbRagioneSociale.BindingContext[cbRagioneSociale.DataSource]; 
			bmCombo.PositionChanged += new EventHandler(cbRagioneSociale_PositionChanged);

			//BindingManagerBase bmDataGrid = dgTransazioni.BindingContext[dgTransazioni.DataSource];
			// Se non ho Transazioni per quella societa' disabilito i bottoni
			if (GetDataGridRowsNumber() == 0)
			{
				AbilitaBottoni(false);
			}
			// Allo startup visualizzo tutte le transazioni (sia di Acquisto che di 
			// Vendita) per la Societa' selezionata.
			SetDataGridRowFilter(cbRagioneSociale.SelectedValue.ToString(), DGFilterType.Tutte);	

			// Scrivo nella TextBox relativa al "Deposito" la quantita' appropriata
			SetDepositoValue();
			// Scrivo nella TextBox relativa al "Totale Acquisti" la quantita' appropriata
			//SetTotaleAcquistiValue();
		}

		public int GetDataGridRowsNumber()
		{
			BindingManagerBase bmDataGrid = dgTransazioni.BindingContext[dgTransazioni.DataSource];
			return bmDataGrid.Count;
		}

		private bool ValidateAllEnabled()
		{
			// Il pulsante "Valida Tutte" deve essere abilitato se c'e' una Ragione Sociale
			// specifica (non e' selezionato l'item "<Tutte>") selezionata, se e' selezionata
			// l'opzione "Transazioni di Acquisto" e se esiste almeno una riga nel DataGrid
			if ((cbRagioneSociale.SelectedValue.ToString() != String.Empty) &&
				(rbTransazioniAcquisto.Checked) &&
				(GetDataGridRowsNumber() != 0))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		private void BuildArrayList(DataTable dtSocieta, DataTable dtTotaleAcquisti, ArrayList al)
		{
			if (dtTotaleAcquisti == null)
				return;
			if (al == null)
				return;

			// Inserisco nella lista l'item per visualizzare le Transazioni di 
			// tutte le societa'
			cbBind cbTutte = new cbBind("<Tutte>", "", 0M, "");
			al.Add(cbTutte);

			// Inserisco le Ragioni sociali del DataSet delle societa'
			foreach (DataRow drSocieta in dtSocieta.Rows)
			{
				string RagioneSociale = (string)drSocieta["RagioneSociale"];
				string IdSocieta = (string)drSocieta["IdSocieta"];
				string CodiceConto = (string)drSocieta["CodiceConto"];

				DataRow [] ars = dtTotaleAcquisti.Select("IdSocieta = '" + IdSocieta + "'");

				cbBind cbItem;
				if (ars.Length > 0)
					cbItem = new cbBind(RagioneSociale, RagioneSociale, (decimal)ars[0]["TotaleAcquisti"], CodiceConto);
				else
					cbItem = new cbBind(RagioneSociale, RagioneSociale, 0m, CodiceConto);

				al.Add(cbItem);
			}
		}

		private void cbRagioneSociale_PositionChanged(object sender, EventArgs e)
		{
			BindingManagerBase bm = (BindingManagerBase) sender;
			if (bm.Current.GetType() != typeof(cbBind))
				return;
			
			cbBind cb = (cbBind)bm.Current;
			// In funzione di cio' che ho selezionato nella ComboBox...
			//...filtro le righe dei DataSet da visualizzare nelle DataGrid
			if (rbTransazioniAcquisto.Checked)
				SetDataGridRowFilter(cb.Value, DGFilterType.Acquisto);
			else if (rbTransazioniVendita.Checked)
				SetDataGridRowFilter(cb.Value, DGFilterType.Vendita);
			else if (rbTutte.Checked)
				SetDataGridRowFilter(cb.Value, DGFilterType.Tutte);
			// Poiche' e' cambiata la Societa' visualizzata nella Combo devo
			// aggiornare anche i dati visualizzati nella TextBox relativa
			// al Deposito ed al Totale Acquisti
			SetDepositoValue();
			//SetTotaleAcquistiValue();
		}

		private void SetDataGridRowFilter(string RagioneSociale, DGFilterType rf)
		{
			// Filtro le colonne da visualizzare nel DataGrid
			string filter = null;
			// Se la Ragione sociale e' stringa vuota significa che voglio visualizzare
			// le transazioni di tutte le societa...
			if (RagioneSociale == String.Empty)
			{
				//..basta che la Ragione Sociale sia uguale a "%" in modo
				// che la clausola LIKE prenda tutte le societa'
				RagioneSociale += "%";
			}
			switch (rf)
			{
				case DGFilterType.Acquisto:
					filter = "Acquirente LIKE '" + RagioneSociale + "'";
				break;
				case DGFilterType.Vendita:
					filter = "Venditore LIKE '" + RagioneSociale + "'";
				break;
				case DGFilterType.Tutte:
					filter = "Acquirente LIKE '" + RagioneSociale + "' OR " + "Venditore LIKE '" + RagioneSociale + "' ";
				break;
				default:
					filter = "";
				break;
			}
			if (_dvTransazioni != null)
			{
				_dvTransazioni.RowFilter = filter;
			}
		}

		private void _dvTransazioni_OnListChanged(object sender, System.ComponentModel.ListChangedEventArgs args)
		{
			int dgRowNumber = 0;
			// Se esiste almeno una transazione nel DataGrid abilito i bottoni altrimenti
			// li disabilito
			dgRowNumber = GetDataGridRowsNumber();
			bool abilita = !(dgRowNumber == 0);
			AbilitaBottoni(abilita);
			if (dgRowNumber != 0)
			{
				// N.B. E' importante questa riga per evitare un problema che esiste quando il 
				// data source del DataGrid e' un DataView.
				// Filtrando i dati con il DataView il bookmark non viene aggiornato automaticamente
				// rimanendo settato all'ultimo valore selezionato.
				// Se il numero di tale riga e' superiore al numero di righe visualizzato
				// dal DataGrid viene lanciata un eccezione quando si da il focus al DataGrid.
				dgTransazioni.CurrentRowIndex = 0;
			}
			// Questa chiamata e' stata inserita per ovviare ad un baco che non aggiornava, a volte,
			// il Totale Acquisti cambiando Societa' nella ComboBox
			RefreshBinding();
		}

		#region Binding dei DataSource con i componenti della Form
		private void BindDataGridDataSource(DataSet ds)
		{
			// Effettuo il DataBinding del DataSet delle Transazioni con il DataGrid
			if (ds != null)
			{
				_dtTransazioni = ds.Tables[0];
				_dvTransazioni = new DataView(_dtTransazioni);
				_dvTransazioni.AllowDelete	= false;
				_dvTransazioni.AllowNew		= false;
				_dvTransazioni.AllowEdit	= false;
				dgTransazioni.DataSource	= _dvTransazioni;
				_dvTransazioni.ListChanged  += new System.ComponentModel.ListChangedEventHandler(_dvTransazioni_OnListChanged);
			}
		}

		private void BindComboDataSource(ArrayList al)
		{
			// Effettuo il DataBinding del DataSet delle Societa con la ComboBox
			if (al != null)
			{
				// DataBinding della tabella Societa' con la ComboBox
				cbRagioneSociale.DataSource = al;
				cbRagioneSociale.DisplayMember = "Name";
				cbRagioneSociale.ValueMember = "Value";

				cbCodiceConto.DataSource = al;
				cbCodiceConto.DisplayMember = "CodiceConto";
				cbCodiceConto.ValueMember = "Value";
			}
		}

		private void BindTotaleAcquisti(ArrayList al)
		{
			if (al != null)
			{
				Binding bnd = null;
				bnd = tbTotaleAcquisti.DataBindings.Add("Text", al, "TotaleAcquisti");
				bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			}
		}

		#endregion

		private DataRow CurrentRow()
		{
			BindingManagerBase bm = dgTransazioni.BindingContext[dgTransazioni.DataSource];
			if (bm.Count == 0) // numero di righe = 0
				return null;
			DataRow dr = null;
			if (bm.Current.GetType() == typeof(DataRowView))
				dr = ((DataRowView)bm.Current).Row; 
			return dr;	
		}

		#region Mapping delle colonne del DataGrid
		private void SetDataGridMapping()
		{
			// Mapping delle colonne tra il DataTable delle Transazioni e le colonne
			// del DataGrid
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[25];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			dgCol[(int)DGColumnID.cIdTransazione].HeaderText = "IdTransazione";
			dgCol[(int)DGColumnID.cIdTransazione].MappingName = "IdTransazione";
			dgCol[(int)DGColumnID.cIdTransazione].Width = 110;

			dgCol[(int)DGColumnID.cAcquirente].HeaderText = "Acquirente";
			dgCol[(int)DGColumnID.cAcquirente].MappingName = "Acquirente";
			dgCol[(int)DGColumnID.cAcquirente].Width = 110;

			dgCol[(int)DGColumnID.cAcquirente_NominativoUtente].HeaderText = "Utente Acq.";
			dgCol[(int)DGColumnID.cAcquirente_NominativoUtente].MappingName = "NominativoA";
			dgCol[(int)DGColumnID.cAcquirente_NominativoUtente].Width = 110;

			dgCol[(int)DGColumnID.cAcquirenteABI].HeaderText = "ABI Acquirente";
			dgCol[(int)DGColumnID.cAcquirenteABI].MappingName = "AcquirentiABI";
			dgCol[(int)DGColumnID.cAcquirenteABI].Width = 110;

			dgCol[(int)DGColumnID.cAcquirenteCAB].HeaderText = "CAB Acquirente";
			dgCol[(int)DGColumnID.cAcquirenteCAB].MappingName = "AcquirentiCAB";
			dgCol[(int)DGColumnID.cAcquirenteCAB].Width = 110;

			dgCol[(int)DGColumnID.cAcquirenteCC].HeaderText = "CC Acquirente";
			dgCol[(int)DGColumnID.cAcquirenteCC].MappingName = "AcquirentiCC";
			dgCol[(int)DGColumnID.cAcquirenteCC].Width = 110;
			
			dgCol[(int)DGColumnID.cAnnoRiferimento].HeaderText = "Anno Riferimento";
			dgCol[(int)DGColumnID.cAnnoRiferimento].MappingName = "AnnoRiferimento";
			dgCol[(int)DGColumnID.cAnnoRiferimento].Width = 110;

			dgCol[(int)DGColumnID.cVenditore].HeaderText = "Venditore";
			dgCol[(int)DGColumnID.cVenditore].MappingName = "Venditore";
			dgCol[(int)DGColumnID.cVenditore].Width = 110;

			dgCol[(int)DGColumnID.cVenditore_NominativoUtente].HeaderText = "Utente Vend.";
			dgCol[(int)DGColumnID.cVenditore_NominativoUtente].MappingName = "NominativoV";
			dgCol[(int)DGColumnID.cVenditore_NominativoUtente].Width = 110;


			dgCol[(int)DGColumnID.cVenditoreABI].HeaderText = "ABI Venditore";
			dgCol[(int)DGColumnID.cVenditoreABI].MappingName = "VenditoriABI";
			dgCol[(int)DGColumnID.cVenditoreABI].Width = 110;

			dgCol[(int)DGColumnID.cVenditoreCAB].HeaderText = "CAB Venditore";
			dgCol[(int)DGColumnID.cVenditoreCAB].MappingName = "VenditoriCAB";
			dgCol[(int)DGColumnID.cVenditoreCAB].Width = 110;

			dgCol[(int)DGColumnID.cVenditoreCC].HeaderText = "CC Venditore";
			dgCol[(int)DGColumnID.cVenditoreCC].MappingName = "VenditoriCC";
			dgCol[(int)DGColumnID.cVenditoreCC].Width = 110;
			
			dgCol[(int)DGColumnID.cCodiceContoAcquirente].HeaderText = "Codice Conto Acquirente";
			dgCol[(int)DGColumnID.cCodiceContoAcquirente].MappingName = "CodiceContoAcquirente";
			dgCol[(int)DGColumnID.cCodiceContoAcquirente].Width = 110;

			dgCol[(int)DGColumnID.cCodiceContoVenditore].HeaderText = "Codice Conto Venditore";
			dgCol[(int)DGColumnID.cCodiceContoVenditore].MappingName = "CodiceContoVenditore";
			dgCol[(int)DGColumnID.cCodiceContoVenditore].Width = 110;

			dgCol[(int)DGColumnID.cIdOffertaAcquisto].HeaderText = "IdOffertaAcquisto";
			dgCol[(int)DGColumnID.cIdOffertaAcquisto].MappingName = "IdOffertaAcquisto";
			dgCol[(int)DGColumnID.cIdOffertaAcquisto].Width = 110;

			dgCol[(int)DGColumnID.cIdOffertaVendita].HeaderText = "IdOffertaVendita";
			dgCol[(int)DGColumnID.cIdOffertaVendita].MappingName = "IdOffertaVendita";
			dgCol[(int)DGColumnID.cIdOffertaVendita].Width = 110;

			dgCol[(int)DGColumnID.cQtyCertificati].HeaderText = "Quantit� Certificati";
			dgCol[(int)DGColumnID.cQtyCertificati].MappingName = "QtyCertificati";
			dgCol[(int)DGColumnID.cQtyCertificati].Width = 110;

			dgCol[(int)DGColumnID.cPrezzoUnitario].HeaderText = "Prezzo Unitario";
			dgCol[(int)DGColumnID.cPrezzoUnitario].MappingName = "PrezzoUnitario";
			dgCol[(int)DGColumnID.cPrezzoUnitario].Width = 110;
			dgCol[(int)DGColumnID.cPrezzoUnitario].Format = "c";

			dgCol[(int)DGColumnID.cControValore].HeaderText = "Contro Valore";
			dgCol[(int)DGColumnID.cControValore].MappingName = "ControValore";
			dgCol[(int)DGColumnID.cControValore].Width = 110;
			dgCol[(int)DGColumnID.cControValore].Format = "c";

			dgCol[(int)DGColumnID.cDataOraOperazione].HeaderText = "Data/Ora Operazione";
			dgCol[(int)DGColumnID.cDataOraOperazione].MappingName = "DataOraOperazione";
			dgCol[(int)DGColumnID.cDataOraOperazione].Width = 110;

			dgCol[(int)DGColumnID.cStatoTransazione].HeaderText = "Stato Transazione";
			dgCol[(int)DGColumnID.cStatoTransazione].MappingName = "StatoTransazione";
			dgCol[(int)DGColumnID.cStatoTransazione].Width = 110;

			dgCol[(int)DGColumnID.cImportoA].HeaderText = "Importo Acquisto";
			dgCol[(int)DGColumnID.cImportoA].MappingName = "ImportoA";
			dgCol[(int)DGColumnID.cImportoA].Width = 110;
			dgCol[(int)DGColumnID.cImportoA].Format = "c";

			dgCol[(int)DGColumnID.cImportoV].HeaderText = "Importo Vendita";
			dgCol[(int)DGColumnID.cImportoV].MappingName = "ImportoV";
			dgCol[(int)DGColumnID.cImportoV].Width = 110;
			dgCol[(int)DGColumnID.cImportoV].Format = "c";

			dgCol[(int)DGColumnID.cPrezzoConvUtenteMwA].HeaderText = "Prezzo Convenzionale Utente Acquisto (Mw)";
			dgCol[(int)DGColumnID.cPrezzoConvUtenteMwA].MappingName = "PConvenzionaleUtenteMwA";
			dgCol[(int)DGColumnID.cPrezzoConvUtenteMwA].Width = 110;
			dgCol[(int)DGColumnID.cPrezzoConvUtenteMwA].Format = "c";

			dgCol[(int)DGColumnID.cPrezzoConvUtenteMwV].HeaderText = "Prezzo Convenzionale Utente Vendita (Mw)";
			dgCol[(int)DGColumnID.cPrezzoConvUtenteMwV].MappingName = "PConvenzionaleUtenteMwV";
			dgCol[(int)DGColumnID.cPrezzoConvUtenteMwV].Width = 110;
			dgCol[(int)DGColumnID.cPrezzoConvUtenteMwV].Format = "c";

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Transazioni";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgTransazioni.TableStyles.Add(dgStyle);
		}
		#endregion

		private void SetDepositoValue()
		{
			DataRow current = null;
			try
			{
				current = CurrentRow();
				if ((ValidateAllEnabled()) && (current != null))
				{
					decimal d = (decimal)current["ImportoA"];
					tbDeposito.Text = Converter.DecimalToCurrencyString(d);
				}
				else
				{
					tbDeposito.Text = Converter.DecimalToCurrencyString(0M);
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void SetTotaleAcquistiValue()
		{
			if (ValidateAllEnabled())
			{
				// TODO Effettuare il Binding del campo "tbTotaleAcquisti" con il field "TotaleAcquisti" del DataSet
				tbTotaleAcquisti.Text = "Da fare";//Converter.DecimalToCurrencyString(d);
			}
			else
			{
				tbTotaleAcquisti.Text = Converter.DecimalToCurrencyString(0M);
			}
		}

		private void DisabilitaComponenti()
		{
			gbCriteriRicerca.Enabled = false;
			AbilitaBottoni(false);
		}

		#region Chiamata ai Web Services
		static DataSet GetTotaleAcquisti(string IdSessione)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.GetTotaleAcquisti", IdSessione);
			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		private DataSet GetListaSocieta()
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.GetLst",
				"");

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}
		#endregion

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTransazioni));
			this.btnChiudi = new System.Windows.Forms.Button();
			this.dgTransazioni = new System.Windows.Forms.DataGrid();
			this.gbCriteriRicerca = new System.Windows.Forms.GroupBox();
			this.cbCodiceConto = new System.Windows.Forms.ComboBox();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.rbTransazioniVendita = new System.Windows.Forms.RadioButton();
			this.rbTransazioniAcquisto = new System.Windows.Forms.RadioButton();
			this.rbTutte = new System.Windows.Forms.RadioButton();
			this.lblRagioneSociale = new System.Windows.Forms.Label();
			this.cbRagioneSociale = new System.Windows.Forms.ComboBox();
			this.btnDaValidare = new System.Windows.Forms.Button();
			this.btnValida = new System.Windows.Forms.Button();
			this.btnNonValida = new System.Windows.Forms.Button();
			this.btnInadempiente = new System.Windows.Forms.Button();
			this.btnValidaTutte = new System.Windows.Forms.Button();
			this.tbDeposito = new System.Windows.Forms.TextBox();
			this.lblDeposito = new System.Windows.Forms.Label();
			this.tbTotaleAcquisti = new System.Windows.Forms.TextBox();
			this.lblTotAcquisti = new System.Windows.Forms.Label();
			this.btnExcel = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.dlgEsportaXls = new System.Windows.Forms.SaveFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.dgTransazioni)).BeginInit();
			this.gbCriteriRicerca.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnChiudi.Location = new System.Drawing.Point(941, 372);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 10;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa finestra");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// dgTransazioni
			// 
			this.dgTransazioni.AllowNavigation = false;
			this.dgTransazioni.AllowSorting = false;
			this.dgTransazioni.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.dgTransazioni.CaptionText = "Risultato Ricerca - Transazioni";
			this.dgTransazioni.DataMember = "";
			this.dgTransazioni.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgTransazioni.Location = new System.Drawing.Point(2, 105);
			this.dgTransazioni.Name = "dgTransazioni";
			this.dgTransazioni.Size = new System.Drawing.Size(1026, 263);
			this.dgTransazioni.TabIndex = 1;
			this.tltInfo.SetToolTip(this.dgTransazioni, "Lista delle Transazioni che soddisfano i criteri di ricerca");
			this.dgTransazioni.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgTransazioni_MouseUp);
			this.dgTransazioni.CurrentCellChanged += new System.EventHandler(this.dgTransazioni_CurrentCellChanged);
			// 
			// gbCriteriRicerca
			// 
			this.gbCriteriRicerca.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.gbCriteriRicerca.Controls.AddRange(new System.Windows.Forms.Control[] {
																						   this.cbCodiceConto,
																						   this.lblCodiceConto,
																						   this.rbTransazioniVendita,
																						   this.rbTransazioniAcquisto,
																						   this.rbTutte,
																						   this.lblRagioneSociale,
																						   this.cbRagioneSociale});
			this.gbCriteriRicerca.Location = new System.Drawing.Point(2, 4);
			this.gbCriteriRicerca.Name = "gbCriteriRicerca";
			this.gbCriteriRicerca.Size = new System.Drawing.Size(1026, 92);
			this.gbCriteriRicerca.TabIndex = 0;
			this.gbCriteriRicerca.TabStop = false;
			this.gbCriteriRicerca.Text = " Criteri di Ricerca ";
			// 
			// cbCodiceConto
			// 
			this.cbCodiceConto.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.cbCodiceConto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCodiceConto.Location = new System.Drawing.Point(104, 40);
			this.cbCodiceConto.Name = "cbCodiceConto";
			this.cbCodiceConto.Size = new System.Drawing.Size(256, 21);
			this.cbCodiceConto.TabIndex = 2;
			this.tltInfo.SetToolTip(this.cbCodiceConto, "Elenco delle Societa\' per Codice Conto");
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Location = new System.Drawing.Point(8, 40);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(92, 20);
			this.lblCodiceConto.TabIndex = 7;
			this.lblCodiceConto.Text = "Codice Conto:";
			// 
			// rbTransazioniVendita
			// 
			this.rbTransazioniVendita.Location = new System.Drawing.Point(276, 69);
			this.rbTransazioniVendita.Name = "rbTransazioniVendita";
			this.rbTransazioniVendita.Size = new System.Drawing.Size(136, 20);
			this.rbTransazioniVendita.TabIndex = 4;
			this.rbTransazioniVendita.Text = "Transazioni di Vendita";
			this.tltInfo.SetToolTip(this.rbTransazioniVendita, "Visualizza solo le Transazioni di Vendita della Societa\' selezionata");
			this.rbTransazioniVendita.CheckedChanged += new System.EventHandler(this.rbTransazioniVendita_CheckedChanged);
			// 
			// rbTransazioniAcquisto
			// 
			this.rbTransazioniAcquisto.Location = new System.Drawing.Point(128, 69);
			this.rbTransazioniAcquisto.Name = "rbTransazioniAcquisto";
			this.rbTransazioniAcquisto.Size = new System.Drawing.Size(140, 20);
			this.rbTransazioniAcquisto.TabIndex = 3;
			this.rbTransazioniAcquisto.Text = "Transazioni di Acquisto";
			this.tltInfo.SetToolTip(this.rbTransazioniAcquisto, "Visualizza solo le Transazioni di Acquisto della Societa\' selezionata");
			this.rbTransazioniAcquisto.CheckedChanged += new System.EventHandler(this.rbTransazioniAcquisto_CheckedChanged);
			// 
			// rbTutte
			// 
			this.rbTutte.Checked = true;
			this.rbTutte.Location = new System.Drawing.Point(8, 69);
			this.rbTutte.Name = "rbTutte";
			this.rbTutte.Size = new System.Drawing.Size(120, 20);
			this.rbTutte.TabIndex = 2;
			this.rbTutte.TabStop = true;
			this.rbTutte.Text = "Tutte le transazioni";
			this.tltInfo.SetToolTip(this.rbTutte, "Visualizza tutte le Transazioni della Societa\' selezionata");
			this.rbTutte.CheckedChanged += new System.EventHandler(this.rbTutte_CheckedChanged);
			// 
			// lblRagioneSociale
			// 
			this.lblRagioneSociale.Location = new System.Drawing.Point(8, 20);
			this.lblRagioneSociale.Name = "lblRagioneSociale";
			this.lblRagioneSociale.Size = new System.Drawing.Size(92, 20);
			this.lblRagioneSociale.TabIndex = 6;
			this.lblRagioneSociale.Text = "Ragione Sociale:";
			// 
			// cbRagioneSociale
			// 
			this.cbRagioneSociale.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.cbRagioneSociale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbRagioneSociale.Location = new System.Drawing.Point(104, 16);
			this.cbRagioneSociale.Name = "cbRagioneSociale";
			this.cbRagioneSociale.Size = new System.Drawing.Size(912, 21);
			this.cbRagioneSociale.TabIndex = 1;
			this.tltInfo.SetToolTip(this.cbRagioneSociale, "Elenco delle Societa\' per Ragione Sociale");
			// 
			// btnDaValidare
			// 
			this.btnDaValidare.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnDaValidare.Enabled = false;
			this.btnDaValidare.Location = new System.Drawing.Point(4, 372);
			this.btnDaValidare.Name = "btnDaValidare";
			this.btnDaValidare.TabIndex = 2;
			this.btnDaValidare.Text = "&Da Validare";
			this.tltInfo.SetToolTip(this.btnDaValidare, "Cambia lo stato delle Transazioni selezionate in \"Da Validare\"");
			this.btnDaValidare.Click += new System.EventHandler(this.btnDaValidare_Click);
			// 
			// btnValida
			// 
			this.btnValida.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnValida.Enabled = false;
			this.btnValida.Location = new System.Drawing.Point(84, 372);
			this.btnValida.Name = "btnValida";
			this.btnValida.TabIndex = 3;
			this.btnValida.Text = "&Valida";
			this.tltInfo.SetToolTip(this.btnValida, "Cambia lo stato delle Transazioni selezionate in \"Valida\"");
			this.btnValida.Click += new System.EventHandler(this.btnValida_Click);
			// 
			// btnNonValida
			// 
			this.btnNonValida.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnNonValida.Enabled = false;
			this.btnNonValida.Location = new System.Drawing.Point(164, 372);
			this.btnNonValida.Name = "btnNonValida";
			this.btnNonValida.TabIndex = 4;
			this.btnNonValida.Text = "&Non Valida";
			this.tltInfo.SetToolTip(this.btnNonValida, "Cambia lo stato delle Transazioni selezionate in \"Non Valida\"");
			this.btnNonValida.Click += new System.EventHandler(this.btnNonValida_Click);
			// 
			// btnInadempiente
			// 
			this.btnInadempiente.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnInadempiente.Enabled = false;
			this.btnInadempiente.Location = new System.Drawing.Point(244, 372);
			this.btnInadempiente.Name = "btnInadempiente";
			this.btnInadempiente.Size = new System.Drawing.Size(84, 23);
			this.btnInadempiente.TabIndex = 5;
			this.btnInadempiente.Text = "&Inadempiente";
			this.tltInfo.SetToolTip(this.btnInadempiente, "Cambia lo stato delle Transazioni selezionate in \"Inadempiente\"");
			this.btnInadempiente.Click += new System.EventHandler(this.btnInadempiente_Click);
			// 
			// btnValidaTutte
			// 
			this.btnValidaTutte.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnValidaTutte.Enabled = false;
			this.btnValidaTutte.Location = new System.Drawing.Point(332, 372);
			this.btnValidaTutte.Name = "btnValidaTutte";
			this.btnValidaTutte.TabIndex = 6;
			this.btnValidaTutte.Text = "Valida &Tutte";
			this.tltInfo.SetToolTip(this.btnValidaTutte, "Valida tutte le Transazioni compatibili con il Deposito del Cliente");
			this.btnValidaTutte.Click += new System.EventHandler(this.btnValidaTutte_Click);
			// 
			// tbDeposito
			// 
			this.tbDeposito.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.tbDeposito.Location = new System.Drawing.Point(475, 373);
			this.tbDeposito.Name = "tbDeposito";
			this.tbDeposito.ReadOnly = true;
			this.tbDeposito.Size = new System.Drawing.Size(140, 20);
			this.tbDeposito.TabIndex = 7;
			this.tbDeposito.TabStop = false;
			this.tbDeposito.Text = "";
			this.tbDeposito.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// lblDeposito
			// 
			this.lblDeposito.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.lblDeposito.Location = new System.Drawing.Point(422, 375);
			this.lblDeposito.Name = "lblDeposito";
			this.lblDeposito.Size = new System.Drawing.Size(52, 16);
			this.lblDeposito.TabIndex = 13;
			this.lblDeposito.Text = "Deposito:";
			// 
			// tbTotaleAcquisti
			// 
			this.tbTotaleAcquisti.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.tbTotaleAcquisti.Location = new System.Drawing.Point(707, 373);
			this.tbTotaleAcquisti.Name = "tbTotaleAcquisti";
			this.tbTotaleAcquisti.ReadOnly = true;
			this.tbTotaleAcquisti.Size = new System.Drawing.Size(128, 20);
			this.tbTotaleAcquisti.TabIndex = 8;
			this.tbTotaleAcquisti.TabStop = false;
			this.tbTotaleAcquisti.Text = "";
			this.tbTotaleAcquisti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// lblTotAcquisti
			// 
			this.lblTotAcquisti.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.lblTotAcquisti.Location = new System.Drawing.Point(621, 375);
			this.lblTotAcquisti.Name = "lblTotAcquisti";
			this.lblTotAcquisti.Size = new System.Drawing.Size(85, 16);
			this.lblTotAcquisti.TabIndex = 15;
			this.lblTotAcquisti.Text = "Totale Acquisti:";
			// 
			// btnExcel
			// 
			this.btnExcel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnExcel.Location = new System.Drawing.Point(840, 372);
			this.btnExcel.Name = "btnExcel";
			this.btnExcel.Size = new System.Drawing.Size(96, 23);
			this.btnExcel.TabIndex = 9;
			this.btnExcel.Text = "Esporta in &Excel";
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			// 
			// dlgEsportaXls
			// 
			this.dlgEsportaXls.Filter = "Excel files (*.xls)|*.xls";
			// 
			// frmTransazioni
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1028, 409);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnExcel,
																		  this.lblTotAcquisti,
																		  this.tbTotaleAcquisti,
																		  this.lblDeposito,
																		  this.tbDeposito,
																		  this.btnValidaTutte,
																		  this.btnInadempiente,
																		  this.btnNonValida,
																		  this.btnValida,
																		  this.btnDaValidare,
																		  this.gbCriteriRicerca,
																		  this.dgTransazioni,
																		  this.btnChiudi});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(1036, 300);
			this.Name = "frmTransazioni";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Transazioni";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			((System.ComponentModel.ISupportInitialize)(this.dgTransazioni)).EndInit();
			this.gbCriteriRicerca.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void AbilitaBottoni(bool enable)
		{
			//btnDaValidare.Enabled	= enable;
			//btnInadempiente.Enabled = enable;
			//btnNonValida.Enabled	= enable;
			//btnValida.Enabled		= enable;
			btnExcel.Enabled		= enable;
			// Il bottone "Valida Tutte"  ha un comportamento diverso dagli altri bottoni, deve cioe'
			// essere abilitato/disabilitato a seconda di determinate condizioni
			//btnValidaTutte.Enabled  = ValidateAllEnabled();
		}

		private void rbTutte_CheckedChanged(object sender, System.EventArgs e)
		{
			if (rbTutte.Checked)
			{
				SetDataGridRowFilter(cbRagioneSociale.SelectedValue.ToString(), DGFilterType.Tutte);
				SetDepositoValue();
				RefreshBinding();
			}
		}

		private void rbTransazioniAcquisto_CheckedChanged(object sender, System.EventArgs e)
		{
			if (rbTransazioniAcquisto.Checked)
			{
				SetDataGridRowFilter(cbRagioneSociale.SelectedValue.ToString(), DGFilterType.Acquisto);	
				SetDepositoValue();
				RefreshBinding();
			}
		}

		private void rbTransazioniVendita_CheckedChanged(object sender, System.EventArgs e)
		{
			if (rbTransazioniVendita.Checked)
			{
				SetDataGridRowFilter(cbRagioneSociale.SelectedValue.ToString(), DGFilterType.Vendita);
				SetDepositoValue();
				RefreshBinding();
			}
		}

		private void dgTransazioni_CurrentCellChanged(object sender, System.EventArgs e)
		{
			SetDepositoValue();
		}

		private void dgTransazioni_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			DataGrid.HitTestInfo hti = dgTransazioni.HitTest(new Point(e.X, e.Y)); 
			if (hti.Type == DataGrid.HitTestType.Cell) 
			{ 
				dgTransazioni.CurrentCell = new DataGridCell(hti.Row, hti.Column); 
				dgTransazioni.Select(hti.Row); 
			}
		}

		private int GetNumberRowsSelected()
		{
			int RowsSelected = 0;
			for (int i = 0; i < GetDataGridRowsNumber(); i++)
			{
				if (dgTransazioni.IsSelected(i))
				{
					RowsSelected++;
				}
			}
			return RowsSelected;
		}

		private void ModificaStatoTransazione(string Stato)
		{
			int rowsel = 0;

			rowsel = GetNumberRowsSelected();
			if (rowsel == 0)
			{
				MessageBox.Show("Non ci sono transazioni selezionate nella griglia", 
								"Attenzione", 
								MessageBoxButtons.OK, 
								MessageBoxIcon.Information);
				return;
			}

			string message = null;

			if (rowsel == 1)
			{
				message = "Sei sicuro di voler modificare lo stato della Transazione selezionata?";
			}
			else
			{
				message = "Sei sicuro di voler modificare lo stato delle " + 
						  rowsel.ToString() +  
						  " Transazioni selezionate?";
			}
			DialogResult dr = MessageBox.Show(message, 
											  "Attenzione", 
											  MessageBoxButtons.YesNo, 
											  MessageBoxIcon.Information);
			if (dr == DialogResult.No)
				return;
		
			// Disabilito l'invio degli eventi che ridisegnano il DataGrid
			this.dgTransazioni.SuspendLayout();

			BindingManagerBase bm = dgTransazioni.BindingContext[dgTransazioni.DataSource];
			for (int i = 0; i < GetDataGridRowsNumber(); i++)
			{
				if (dgTransazioni.IsSelected(i))
				{
					bm.Position = i;
					DataRow dataRow = CurrentRow();
					// Cambio lo Stato della Transazione corrente
					dataRow["StatoTransazione"] = Stato;
					dataRow["PagabileDaGME"]	= System.DBNull.Value;
					dataRow["FileExportBanca"]	= System.DBNull.Value;
					dataRow["Causale"]			= System.DBNull.Value;
					// Applico la modifica al DataSource
					dataRow.EndEdit();
				}
			}

			// Abilito l'invio degli eventi che ridisegnano il DataGrid
			this.dgTransazioni.ResumeLayout();
			AggiornaDataSet(_dsListaTransazioni);
		}

		private void btnDaValidare_Click(object sender, System.EventArgs e)
		{
			ModificaStatoTransazione("Da Validare");
		}

		private void btnValida_Click(object sender, System.EventArgs e)
		{
			ModificaStatoTransazione("Valida");
		}

		private void btnNonValida_Click(object sender, System.EventArgs e)
		{
			ModificaStatoTransazione("Non Valida");
		}

		private void btnInadempiente_Click(object sender, System.EventArgs e)
		{
			ModificaStatoTransazione("Inadempiente");
		}

		private void btnValidaTutte_Click(object sender, System.EventArgs e)
		{
			DialogResult dr = MessageBox.Show("Sei sicuro di voler modificare lo stato di tutte le Transazioni?", 
											  "Attenzione", 
											  MessageBoxButtons.YesNo, 
											  MessageBoxIcon.Information);
			if (dr == DialogResult.No)
			{
				return;
			}
			decimal deposito = Converter.CurrencyStringToDecimal(tbDeposito.Text);
			decimal totaleAcquisti = Converter.CurrencyStringToDecimal(tbTotaleAcquisti.Text);
			BindingManagerBase bm = dgTransazioni.BindingContext[dgTransazioni.DataSource];

			// Disabilito l'invio degli eventi che ridisegnano il DataGrid
			this.dgTransazioni.SuspendLayout();

			if (deposito >= totaleAcquisti)
			{
				for (int i = 0; i < GetDataGridRowsNumber(); i++)
				{
					bm.Position = i;
					DataRow dataRow = CurrentRow();
					if (dataRow["StatoTransazione"].ToString().Equals("Da Validare"))
					{
						// Cambio lo Stato della Transazione corrente
						dataRow["StatoTransazione"] = "Valida";
						dataRow["PagabileDaGME"]	= "SI";
						// Applico la modifica al DataSource
						dataRow.EndEdit();
					}
				}
			}
			else
			{
				decimal prezzoUnitario = 0M;
				decimal prezzoConvenzionaleUtenteMWAcquisto = 0M;
				for (int i = 0; i < GetDataGridRowsNumber(); i++)
				{
					bm.Position = i;
					DataRow dataRow = CurrentRow();
					if (dataRow["StatoTransazione"].ToString().Equals("Da Validare"))
					{
						prezzoUnitario = (decimal)dataRow["PrezzoUnitario"];
						prezzoConvenzionaleUtenteMWAcquisto = (decimal)dataRow["PConvenzionaleUtenteMwA"];
						if (prezzoUnitario <= prezzoConvenzionaleUtenteMWAcquisto)
						{
							// Cambio lo Stato della Transazione corrente
							dataRow["StatoTransazione"] = "Valida";
							dataRow["PagabileDaGME"]	= "SI";
						}
						else
						{
							dataRow["StatoTransazione"] = "Non Valida";
							dataRow["PagabileDaGME"]	= System.DBNull.Value;
							dataRow["FileExportBanca"]	= System.DBNull.Value;
							dataRow["Causale"]			= System.DBNull.Value;
						}
						dataRow.EndEdit();
					}
				}

			}

			AggiornaDataSet(_dsListaTransazioni);

			// Abilito l'invio degli eventi che ridisegnano il DataGrid
			this.dgTransazioni.ResumeLayout();
		}

		private bool AggiornaDataSet(DataSet ds)
		{
			// Verifico se sono state effettuate delle modifiche alle tabelle del DataSet
			if (!ds.HasChanges()) 
			{
				ds.AcceptChanges();
				return true;
			}

			DataSet xDataSet;
			// GetChanges solo per le righe modificate
			xDataSet = ds.GetChanges();
			if (xDataSet == null)
			{
				ds.AcceptChanges();
				return true;
			}

			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLTransazioni.BLTransazioni.UpdateStatoTransazione", ds);
			if (Cancelled)
				return false;

			// il Web Service ha risposto... prendo il risultato
			DataSet dsUpdated = (DataSet)ret;
			if (dsUpdated != null)
			{
				ds.AcceptChanges();
				return true;
			}
			else
			{
				ds.RejectChanges();
				return false;
			}
		}

		private void DecimalToCurrencyString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(string))
				return;

			Binding bng = sender as Binding;
			if (!ValidateAllEnabled())
			{
				cevent.Value = Converter.DecimalToCurrencyString(0M);
				return;
			}
			if (bng == null)
				cevent.Value = "";
			else
			{
				decimal d = ((decimal) cevent.Value);
				if (d >= 0m)
					cevent.Value = Converter.DecimalToCurrencyString(d);
				else
					cevent.Value = "";
			}
		}

//		private void RefreshBinding()
//		{
//			// TODO Rivedere questa funzione (quando bmgr.Position = bmgr.Count non viene effettuato il refresh)
//			BindingManagerBase bmgr = tbTotaleAcquisti.BindingContext[_alRagioniSociali];
//			if (bmgr == null)
//				return;
//			int p = bmgr.Position;
//			bmgr.Position = bmgr.Count ;
//			bmgr.Position = p;
//		}
		private void RefreshBinding()
		{
			BindingManagerBase bmgr = tbTotaleAcquisti.BindingContext[_alRagioniSociali];
			if (bmgr != null && bmgr is CurrencyManager)
			{
				((CurrencyManager)bmgr).Refresh();
			}
		}



		#region Creazione del file EXCEL

//		private void ExportExcel()
//		{
//			object missing = System.Reflection.Missing.Value;
//
//			dlgEsportaXls.InitialDirectory = UtilityEnvironment.CommonAppDir;
//			if (dlgEsportaXls.ShowDialog() != DialogResult.OK)
//				return;
//
//			using (WaitCursor wc = new WaitCursor())
//			{
//				// per ovviare ad un baco quando si ha Excel in inglese e il SO in italiano
//				CultureInfo ciOri = System.Threading.Thread.CurrentThread.CurrentCulture;
//				System.Threading.Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-US");
//				try
//				{
//					string exportFileName = dlgEsportaXls.FileName;
//
//					Excel.Application xlsApp = new Excel.Application();
//				
//					xlsApp.Visible = false;
//					xlsApp.SheetsInNewWorkbook = 1;
//
//					Excel.Workbook xlBook = xlsApp.Workbooks.Add(Excel.XlWBATemplate.xlWBATWorksheet);
//					Excel.Worksheet xlSheet = null;
//
//					// Se la DataGrid e' vuota non salvo il file che e' stato creato. 
//					bool dgVuota = true;
//
//					if (xlSheet != null)
//						xlSheet = xlBook.Worksheets.Add(missing, missing, missing, missing) as Excel.Worksheet;
//					else
//						xlSheet = xlBook.Worksheets[1] as Excel.Worksheet;  // alla creazione Excel crea di default uno sheet
//
//					xlSheet.Name = "Transazioni";
//				
//					// TITOLO
//					Cell(xlSheet, 1, 1).get_Characters(missing, missing).Font.Size = 11;
//					Cell(xlSheet, 1, 1).get_Characters(missing, missing).Font.Bold = true;
//					Cell(xlSheet, 1, 1).Value = "Transazioni";
//					Cell(xlSheet, 1, 1, 1, 5).HorizontalAlignment = 3;
//					Cell(xlSheet, 1, 1, 1, 5).Merge(missing);
//				
//					// RIGA INTESTAZIONE
//					(xlSheet.Cells.EntireRow[3, missing] as Excel.Range).get_Characters(missing, missing).Font.Size = 10;
//					(xlSheet.Cells.EntireRow[3, missing] as Excel.Range).get_Characters(missing, missing).Font.Bold = true;
//				
//					Cell(xlSheet, 3, 1).Value  = "IdTransazione";
//					Cell(xlSheet, 3, 2).Value  = "Acquirente";
//					Cell(xlSheet, 3, 3).Value  = "Acquirenti ABI";
//					Cell(xlSheet, 3, 4).Value  = "Acquirenti CAB";
//					Cell(xlSheet, 3, 5).Value  = "Acquirenti CC";
//					Cell(xlSheet, 3, 6).Value  = "Anno Riferimento";
//					Cell(xlSheet, 3, 7).Value  = "Venditore";
//					Cell(xlSheet, 3, 8).Value  = "Venditori ABI";
//					Cell(xlSheet, 3, 9).Value  = "Venditori CAB";
//					Cell(xlSheet, 3, 10).Value = "Venditori CC";
//					Cell(xlSheet, 3, 11).Value = "Codice Conto Acquirente";
//					Cell(xlSheet, 3, 12).Value = "Codice Conto Venditore";
//					Cell(xlSheet, 3, 13).Value = "IdOffertaAcquisto";
//					Cell(xlSheet, 3, 14).Value = "IdOffertaVendita";
//					Cell(xlSheet, 3, 15).Value = "Quantita' Certificati";
//					Cell(xlSheet, 3, 16).Value = "Prezzo Unitario";
//					Cell(xlSheet, 3, 17).Value = "Controvalore";
//					Cell(xlSheet, 3, 18).Value = "Data/Ora Operazione";
//					Cell(xlSheet, 3, 19).Value = "Stato Transazione";
//					Cell(xlSheet, 3, 20).Value = "Deposito Acq";
//					Cell(xlSheet, 3, 21).Value = "Deposito Ven";
//					Cell(xlSheet, 3, 22).Value = "PrezzoConvenzionaleUtente Acq";
//					Cell(xlSheet, 3, 23).Value = "PrezzoConvenzionaleUtente Ven";
//
//					// RIGHE DATI
//					// Parto dalla quarta riga
//					int riga = 4;
//					for (int rowCounter = 0; rowCounter < GetDataGridRowsNumber(); rowCounter++)
//					{
//						dgVuota = false;
//						(xlSheet.Cells.EntireRow[riga, missing] as Excel.Range).get_Characters(missing, missing).Font.Size = 8;
//						(xlSheet.Cells.EntireRow[riga, missing] as Excel.Range).get_Characters(missing, missing).Font.Bold = false;
//
//						if ((rowCounter & 1) == 0)
//						{
//							Cell(xlSheet, riga, 1, riga, 23).Interior.ColorIndex = 15;
//							Cell(xlSheet, riga, 1, riga, 23).Interior.Pattern = Excel.XlPattern.xlPatternSolid;
//							Cell(xlSheet, riga, 1, riga, 23).Interior.PatternColorIndex = Excel.XlPattern.xlPatternAutomatic;
//						}
//
//						// ID TRANSAZIONE
//						Cell(xlSheet, riga, 1).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 1).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 1).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 1).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 1).NumberFormat = "@";
//						Cell(xlSheet, riga, 1).Value = dgTransazioni[rowCounter, (int)DGColumnID.cIdTransazione].ToString();
//					
//						// ACQUIRENTE
//						Cell(xlSheet, riga, 2).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 2).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 2).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 2).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 2).NumberFormat = "@";
//						Cell(xlSheet, riga, 2).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirente].ToString();
//
//						// ACQUIRENTE ABI
//						Cell(xlSheet, riga, 3).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 3).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 3).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 3).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 3).NumberFormat = "@";
//						Cell(xlSheet, riga, 3).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirenteABI].ToString();
//
//						// ACQUIRENTE CAB
//						Cell(xlSheet, riga, 4).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 4).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 4).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 4).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 4).NumberFormat = "@";
//						Cell(xlSheet, riga, 4).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirenteCAB].ToString();
//
//						// ACQUIRENTE CC
//						Cell(xlSheet, riga, 5).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 5).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 5).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 5).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 5).NumberFormat = "@";
//						Cell(xlSheet, riga, 5).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirenteCC].ToString();
//
//						// ANNO RIFERIMENTO
//						Cell(xlSheet, riga, 6).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 6).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 6).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 6).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 6).NumberFormat = "@";
//						Cell(xlSheet, riga, 6).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAnnoRiferimento].ToString();
//
//						// VENDITORE
//						Cell(xlSheet, riga, 7).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 7).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 7).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 7).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 7).NumberFormat = "@";
//						Cell(xlSheet, riga, 7).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditore].ToString();
//
//						// VENDITORE ABI
//						Cell(xlSheet, riga, 8).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 8).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 8).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 8).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 8).NumberFormat = "@";
//						Cell(xlSheet, riga, 8).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditoreABI].ToString();
//
//						// VENDITORE CAB
//						Cell(xlSheet, riga, 9).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 9).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 9).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 9).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 9).NumberFormat = "@";
//						Cell(xlSheet, riga, 9).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditoreCAB].ToString();
//
//						// VENDITORE CC
//						Cell(xlSheet, riga, 10).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 10).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 10).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 10).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 10).NumberFormat = "@";
//						Cell(xlSheet, riga, 10).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditoreCC].ToString();
//
//						// CODICE CONTO ACQUIRENTE
//						Cell(xlSheet, riga, 11).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 11).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 11).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 11).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 11).NumberFormat = "@";
//						Cell(xlSheet, riga, 11).Value = dgTransazioni[rowCounter, (int)DGColumnID.cCodiceContoAcquirente].ToString();
//
//						// CODICE CONTO VENDITORE
//						Cell(xlSheet, riga, 12).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 12).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 12).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 12).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 12).NumberFormat = "@";
//						Cell(xlSheet, riga, 12).Value = dgTransazioni[rowCounter, (int)DGColumnID.cCodiceContoVenditore].ToString();
//
//						// ID OFFERTA ACQUISTO
//						Cell(xlSheet, riga, 13).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 13).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 13).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 13).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 13).NumberFormat = "@";
//						Cell(xlSheet, riga, 13).Value = dgTransazioni[rowCounter, (int)DGColumnID.cIdOffertaAcquisto].ToString();
//
//						// ID OFFERTA VENDITA
//						Cell(xlSheet, riga, 14).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 14).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 14).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 14).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 14).NumberFormat = "@";
//						Cell(xlSheet, riga, 14).Value = dgTransazioni[rowCounter, (int)DGColumnID.cIdOffertaVendita].ToString();
//        
//						// QUANTITA' CERTIFICATI
//						Cell(xlSheet, riga, 15).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 15).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 15).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 15).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 15).NumberFormat = "@";
//						Cell(xlSheet, riga, 15).Value = Converter.DecimalToIntegerString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cQtyCertificati]);
//        
//						// PREZZO UNITARIO
//						Cell(xlSheet, riga, 16).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 16).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 16).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 16).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 16).NumberFormat = "@";
//						Cell(xlSheet, riga, 16).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cPrezzoUnitario]);
//
//						// CONTRO VALORE
//						Cell(xlSheet, riga, 17).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 17).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 17).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 17).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 17).NumberFormat = "@";
//						Cell(xlSheet, riga, 17).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cControValore]);
//					        
//						// DATA/ORA OPERAZIONE
//						Cell(xlSheet, riga, 18).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 18).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 18).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 18).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 18).NumberFormat = "@";
//						Cell(xlSheet, riga, 18).Value = Converter.DateTimeToStringDateTime((DateTime)dgTransazioni[rowCounter, (int)DGColumnID.cDataOraOperazione]);
//        
//						// STATO TRANSAZIONE
//						Cell(xlSheet, riga, 19).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 19).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 19).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 19).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 19).NumberFormat = "@";
//						Cell(xlSheet, riga, 19).Value = dgTransazioni[rowCounter, (int)DGColumnID.cStatoTransazione].ToString();
//        
//						// IMPORTO ACQUISTO
//						Cell(xlSheet, riga, 20).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 20).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 20).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 20).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 20).NumberFormat = "@";
//						Cell(xlSheet, riga, 20).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cImportoA]);
//        
//						// IMPORTO VENDITA
//						Cell(xlSheet, riga, 21).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 21).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 21).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 21).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 21).NumberFormat = "@";
//						Cell(xlSheet, riga, 21).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cImportoV]);
//
//						// PREZZO CONVENZIONALE UTENTE ACQUISTO
//						Cell(xlSheet, riga, 22).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 22).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 22).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 22).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 22).NumberFormat = "@";
//						Cell(xlSheet, riga, 22).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cPrezzoConvUtenteMwA]);
//        
//						// PREZZO CONVENZIONALE UTENTE VENDITA
//						Cell(xlSheet, riga, 23).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
//						Cell(xlSheet, riga, 23).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
//						Cell(xlSheet, riga, 23).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
//						Cell(xlSheet, riga, 23).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
//						Cell(xlSheet, riga, 23).NumberFormat = "@";
//						Cell(xlSheet, riga, 23).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cPrezzoConvUtenteMwV]);
//				
//						Cell(xlSheet, 1, 1, 1 ,23).Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = 7;
//						Cell(xlSheet, 1, 1, 1 ,23).Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 3;
//						Cell(xlSheet, 1, 1, 1 ,23).Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = 7;
//
//						riga++;
//					}
//					for (int count = 1; count <= 23; count++)
//					{
//						(xlSheet.Cells.EntireColumn[count, missing] as Excel.Range).get_Resize(missing, missing).AutoFit();
//					}
//
//
//					if (!dgVuota)
//					{
//						// Se il file esiste gia' lo cancello
//						try	{System.IO.File.Delete(exportFileName);	}
//						catch(Exception) {}
//
//						xlSheet.SaveAs(exportFileName, 
//							missing, 
//							missing, 
//							missing, 
//							missing, 
//							missing, 
//							missing,
//							missing, 
//							missing);
//					}
//					else
//					{
//						MessageBox.Show("Non esistono Transazioni da esportare", "Attenzione");
//					}
//
//					if (xlBook != null)
//					{
//						xlBook.Close(false, missing, missing);
//					}
//					xlsApp.Quit();
//				}	
//				catch(Exception ex)
//				{
//					wc.RestoreCursor();
//					MessageBox.Show(ex.Message, "Errore");
//				}
//				finally
//				{
//					System.Threading.Thread.CurrentThread.CurrentCulture = ciOri;
//				}
//			}
//			MessageBox.Show("Foglio Excel generato con successo", "Messaggio");
//		}
//		private Excel.Range Cell(Excel.Worksheet s, int r, int c)
//		{
//			return s.Cells[r, c] as Excel.Range;
//		}
//
//		private Excel.Range Cell(Excel.Worksheet s, Excel.Range r, Excel.Range c)
//		{
//			return s.Cells[r, c] as Excel.Range;
//		}
//
//		private Excel.Range Cell(Excel.Worksheet s, int r1, int c1, int r2, int c2)
//		{
//			Excel.Range ra = s.Cells[r1, c1] as Excel.Range;
//			Excel.Range rb = s.Cells[r2, c2] as Excel.Range;
//			return s.Cells.get_Range(ra, rb);
//		}

		private void ExportExcel()
		{
			object missing = System.Reflection.Missing.Value;

			dlgEsportaXls.InitialDirectory = UtilityEnvironment.CommonAppDir;
			if (dlgEsportaXls.ShowDialog() != DialogResult.OK)
				return;

			Application.DoEvents();
			using (WaitCursor wc = new WaitCursor())
			{
				try
				{
					string exportFileName = dlgEsportaXls.FileName;

					using (spApplication xlsApp = new spApplication())
					{
						xlsApp.Visible = false;
						xlsApp.SheetsInNewWorkbook = 1;

						spWorkbook xlBook = xlsApp.Workbooks.Add();
						spWorksheet xlSheet = null;

						// Se la DataGrid e' vuota non salvo il file che e' stato creato. 
						bool dgVuota = true;

						if (xlSheet != null)
							xlSheet = xlBook.Worksheets.Add();
						else
							xlSheet = xlBook.Worksheets[1];

						xlSheet.Name = "Transazioni";
				
						// TITOLO
						Cell(xlSheet, 1, 1).Characters.Font.Size = 11;
						Cell(xlSheet, 1, 1).Characters.Font.Bold = true;
						Cell(xlSheet, 1, 1).Value = "Transazioni";
						Cell(xlSheet, 1, 1, 1, 5).HorizontalAlignment = Excel.XlHAlign.xlHAlignGeneral;//3;
						Cell(xlSheet, 1, 1, 1, 5).Merge();
				
						// RIGA INTESTAZIONE
						xlSheet.Cells.EntireRow[3].Characters.Font.Size = 10;
						xlSheet.Cells.EntireRow[3].Characters.Font.Bold = true;
				
						Cell(xlSheet, 3, 1).Value  = "IdTransazione";
						Cell(xlSheet, 3, 2).Value  = "Acquirente";
						Cell(xlSheet, 3, 3).Value  = "Acquirenti ABI";
						Cell(xlSheet, 3, 4).Value  = "Acquirenti CAB";
						Cell(xlSheet, 3, 5).Value  = "Acquirenti CC";
						Cell(xlSheet, 3, 6).Value  = "Anno Riferimento";
						Cell(xlSheet, 3, 7).Value  = "Venditore";
						Cell(xlSheet, 3, 8).Value  = "Venditori ABI";
						Cell(xlSheet, 3, 9).Value  = "Venditori CAB";
						Cell(xlSheet, 3, 10).Value = "Venditori CC";
						Cell(xlSheet, 3, 11).Value = "Codice Conto Acquirente";
						Cell(xlSheet, 3, 12).Value = "Codice Conto Venditore";
						Cell(xlSheet, 3, 13).Value = "IdOffertaAcquisto";
						Cell(xlSheet, 3, 14).Value = "IdOffertaVendita";
						Cell(xlSheet, 3, 15).Value = "Quantita' Certificati";
						Cell(xlSheet, 3, 16).Value = "Prezzo Unitario";
						Cell(xlSheet, 3, 17).Value = "Controvalore";
						Cell(xlSheet, 3, 18).Value = "Data/Ora Operazione";
						Cell(xlSheet, 3, 19).Value = "Stato Transazione";
						Cell(xlSheet, 3, 20).Value = "Deposito Acq";
						Cell(xlSheet, 3, 21).Value = "Deposito Ven";
						Cell(xlSheet, 3, 22).Value = "PrezzoConvenzionaleUtente Acq";
						Cell(xlSheet, 3, 23).Value = "PrezzoConvenzionaleUtente Ven";
						Cell(xlSheet, 3, 24).Value = "Utente Ven";
						Cell(xlSheet, 3, 25).Value = "Utente Acq";

						// RIGHE DATI
						// Parto dalla quarta riga
						int riga = 4;
						for (int rowCounter = 0; rowCounter < GetDataGridRowsNumber(); rowCounter++)
						{
							dgVuota = false;
							xlSheet.Cells.EntireRow[riga].Characters.Font.Size = 8;
							xlSheet.Cells.EntireRow[riga].Characters.Font.Bold = false;

							if ((rowCounter & 1) == 0)
							{
								Cell(xlSheet, riga, 1, riga, 25).Interior.ColorIndex = 15;
								Cell(xlSheet, riga, 1, riga, 25).Interior.Pattern = Excel.XlPattern.xlPatternSolid;
								Cell(xlSheet, riga, 1, riga, 25).Interior.PatternColorIndex = Excel.XlPattern.xlPatternAutomatic;
							}

							// ID TRANSAZIONE
							Cell(xlSheet, riga, 1).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 1).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 1).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 1).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 1).NumberFormat = "@";
							Cell(xlSheet, riga, 1).Value = dgTransazioni[rowCounter, (int)DGColumnID.cIdTransazione].ToString();
					
							// ACQUIRENTE
							Cell(xlSheet, riga, 2).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 2).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 2).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 2).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 2).NumberFormat = "@";
							Cell(xlSheet, riga, 2).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirente].ToString();

							// ACQUIRENTE ABI
							Cell(xlSheet, riga, 3).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 3).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 3).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 3).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 3).NumberFormat = "@";
							Cell(xlSheet, riga, 3).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirenteABI].ToString();

							// ACQUIRENTE CAB
							Cell(xlSheet, riga, 4).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 4).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 4).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 4).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 4).NumberFormat = "@";
							Cell(xlSheet, riga, 4).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirenteCAB].ToString();

							// ACQUIRENTE CC
							Cell(xlSheet, riga, 5).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 5).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 5).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 5).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 5).NumberFormat = "@";
							Cell(xlSheet, riga, 5).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirenteCC].ToString();

							// ANNO RIFERIMENTO
							Cell(xlSheet, riga, 6).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 6).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 6).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 6).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 6).NumberFormat = "@";
							Cell(xlSheet, riga, 6).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAnnoRiferimento].ToString();

							// VENDITORE
							Cell(xlSheet, riga, 7).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 7).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 7).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 7).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 7).NumberFormat = "@";
							Cell(xlSheet, riga, 7).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditore].ToString();

							// VENDITORE ABI
							Cell(xlSheet, riga, 8).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 8).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 8).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 8).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 8).NumberFormat = "@";
							Cell(xlSheet, riga, 8).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditoreABI].ToString();

							// VENDITORE CAB
							Cell(xlSheet, riga, 9).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 9).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 9).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 9).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 9).NumberFormat = "@";
							Cell(xlSheet, riga, 9).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditoreCAB].ToString();

							// VENDITORE CC
							Cell(xlSheet, riga, 10).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 10).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 10).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 10).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 10).NumberFormat = "@";
							Cell(xlSheet, riga, 10).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditoreCC].ToString();

							// CODICE CONTO ACQUIRENTE
							Cell(xlSheet, riga, 11).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 11).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 11).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 11).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 11).NumberFormat = "@";
							Cell(xlSheet, riga, 11).Value = dgTransazioni[rowCounter, (int)DGColumnID.cCodiceContoAcquirente].ToString();

							// CODICE CONTO VENDITORE
							Cell(xlSheet, riga, 12).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 12).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 12).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 12).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 12).NumberFormat = "@";
							Cell(xlSheet, riga, 12).Value = dgTransazioni[rowCounter, (int)DGColumnID.cCodiceContoVenditore].ToString();

							// ID OFFERTA ACQUISTO
							Cell(xlSheet, riga, 13).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 13).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 13).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 13).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 13).NumberFormat = "@";
							Cell(xlSheet, riga, 13).Value = dgTransazioni[rowCounter, (int)DGColumnID.cIdOffertaAcquisto].ToString();

							// ID OFFERTA VENDITA
							Cell(xlSheet, riga, 14).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 14).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 14).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 14).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 14).NumberFormat = "@";
							Cell(xlSheet, riga, 14).Value = dgTransazioni[rowCounter, (int)DGColumnID.cIdOffertaVendita].ToString();
        
							// QUANTITA' CERTIFICATI
							Cell(xlSheet, riga, 15).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 15).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 15).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 15).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 15).NumberFormat = "@";
							Cell(xlSheet, riga, 15).Value = Converter.DecimalToIntegerString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cQtyCertificati]);
        
							// PREZZO UNITARIO
							Cell(xlSheet, riga, 16).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 16).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 16).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 16).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 16).NumberFormat = "@";
							Cell(xlSheet, riga, 16).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cPrezzoUnitario]);

							// CONTRO VALORE
							Cell(xlSheet, riga, 17).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 17).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 17).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 17).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 17).NumberFormat = "@";
							Cell(xlSheet, riga, 17).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cControValore]);
					        
							// DATA/ORA OPERAZIONE
							Cell(xlSheet, riga, 18).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 18).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 18).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 18).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 18).NumberFormat = "@";
							Cell(xlSheet, riga, 18).Value = Converter.DateTimeToStringDateTime((DateTime)dgTransazioni[rowCounter, (int)DGColumnID.cDataOraOperazione]);
        
							// STATO TRANSAZIONE
							Cell(xlSheet, riga, 19).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 19).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 19).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 19).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 19).NumberFormat = "@";
							Cell(xlSheet, riga, 19).Value = dgTransazioni[rowCounter, (int)DGColumnID.cStatoTransazione].ToString();
        
							// IMPORTO ACQUISTO
							Cell(xlSheet, riga, 20).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 20).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 20).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 20).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 20).NumberFormat = "@";
							Cell(xlSheet, riga, 20).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cImportoA]);
        
							// IMPORTO VENDITA
							Cell(xlSheet, riga, 21).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 21).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 21).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 21).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 21).NumberFormat = "@";
							Cell(xlSheet, riga, 21).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cImportoV]);

							// PREZZO CONVENZIONALE UTENTE ACQUISTO
							Cell(xlSheet, riga, 22).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 22).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 22).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 22).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 22).NumberFormat = "@";
							Cell(xlSheet, riga, 22).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cPrezzoConvUtenteMwA]);
        
							// PREZZO CONVENZIONALE UTENTE VENDITA
							Cell(xlSheet, riga, 23).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 23).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 23).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 23).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 23).NumberFormat = "@";
							Cell(xlSheet, riga, 23).Value = Converter.DecimalToCurrencyString((decimal)dgTransazioni[rowCounter, (int)DGColumnID.cPrezzoConvUtenteMwV]);

							// UTENTE VENDITORE
							Cell(xlSheet, riga, 24).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 24).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 24).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 24).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 24).NumberFormat = "@";
							//STEFANO BUG FIX Cell(xlSheet, riga, 24).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirente_NominativoUtente].ToString();
							Cell(xlSheet, riga, 24).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditore_NominativoUtente].ToString();

							// UTENTE ACQUIRENTE
							Cell(xlSheet, riga, 25).Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = 7;
							Cell(xlSheet, riga, 25).Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 3;
							Cell(xlSheet, riga, 25).Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = 7;
							Cell(xlSheet, riga, 25).Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 3;
							Cell(xlSheet, riga, 25).NumberFormat = "@";
							//STEFANO BUG FIX Cell(xlSheet, riga, 25).Value = dgTransazioni[rowCounter, (int)DGColumnID.cVenditore_NominativoUtente].ToString();
							Cell(xlSheet, riga, 25).Value = dgTransazioni[rowCounter, (int)DGColumnID.cAcquirente_NominativoUtente].ToString();

							
							Cell(xlSheet, 1, 1, 1 ,25).Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = 7;
							Cell(xlSheet, 1, 1, 1 ,25).Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 3;
							Cell(xlSheet, 1, 1, 1 ,25).Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = 7;

							riga++;
						}
						for (int count = 1; count <= 25; count++)
						{
							xlSheet.Cells.EntireColumn[count].Resize.AutoFit();
						}


						if (!dgVuota)
						{
							// Se il file esiste gia' lo cancello
							try	{System.IO.File.Delete(exportFileName);	}
							catch(Exception) {}

							xlSheet.SaveAs(exportFileName);
						}
						else
						{
							MessageBox.Show("Non esistono Transazioni da esportare", "Attenzione");
						}

						if (xlBook != null)
						{
							xlBook.Close();
						}
						xlsApp.Quit();
					}
					MessageBox.Show("Foglio Excel generato con successo", "Messaggio");
				}	
				catch(Exception ex)
				{
					wc.RestoreCursor();
					MessageBox.Show(ex.Message, "Errore");
				}
			}
		}

		private spRange Cell(spWorksheet s, int r, int c)
		{
			return s.Cells[r, c];
		}
		private spRange Cell(spWorksheet s, int r1, int c1, int r2, int c2)
		{
			spRange ra = s.Cells[r1, c1];
			spRange rb = s.Cells[r2, c2];
			return s.Cells.Range(ra, rb);
		}
		#endregion

		private void btnExcel_Click(object sender, System.EventArgs e)
		{
			ExportExcel();
		}
	}
}
