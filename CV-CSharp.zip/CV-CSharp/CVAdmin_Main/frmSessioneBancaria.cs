using System;
using System.Text;
using System.Drawing;
using System.Collections;
using System.Configuration;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Diagnostics;
using System.Data.OleDb;
using System.Collections.Specialized;
using System.Web.Services.Protocols;

using CVAdmin_Main.CVAdminWSBLSessioneBancaria;


// using CV.Admin;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmSessioneBancaria : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dgMovimenti;
		DataSet _ds;
		CurrencyManager _cmMovimenti;
		CurrencyManager _cmTransazioni;
		string IdSessione = null;
		DataRow _movDaPerfezionareParzialmente = null;
		bool _SessioneAperta = false;
		DateTime _TSUltimaModifica;

		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Button btnChiudiFinestra;
		private System.Windows.Forms.ComboBox cbMovimentiFilter;
		private System.Windows.Forms.TextBox txtMovimentiFilter;
		private System.Windows.Forms.Label lblMovimentiFilter;
		private System.Windows.Forms.CheckBox chkboxVisualizzaAnchePerfezionati;
		private System.Windows.Forms.DataGrid dgTransazioni;
		private System.Windows.Forms.MenuItem mmIP;
		private System.Windows.Forms.MenuItem mnIP_Crea;
		private System.Windows.Forms.MenuItem mnIP_Pubblica;
		private System.Windows.Forms.MainMenu SessioneBancariaMenu;
		private System.Windows.Forms.MenuItem mnResidui;
		private System.Windows.Forms.MenuItem mnResidui_GeneraMovimenti;
		private System.Windows.Forms.MenuItem mnSP;
		private System.Windows.Forms.MenuItem mnSP_Genera;
		private System.Windows.Forms.MenuItem mnSP_Visualizza;
		private System.Windows.Forms.MenuItem mnSP_Invia;
		private System.Windows.Forms.MenuItem mnSP_VisualizzaTutti;

		private System.Windows.Forms.MenuItem mnSB;
		private System.Windows.Forms.MenuItem mnSB_ReportApertura;
		private System.Windows.Forms.MenuItem mnSB_ReportStato;
		private System.Windows.Forms.MenuItem mnSB_ReportChiusura;
		private System.Windows.Forms.MenuItem mnSB_ChiusuraBancaria;

		private System.Windows.Forms.ContextMenu cmnMovimenti;
		private System.Windows.Forms.MenuItem cmnMovimenti_PerfezionaPP;
		private System.Windows.Forms.MenuItem mnPP;
		private System.Windows.Forms.MenuItem mnPP_SelezionaTransazioni;
		private System.Windows.Forms.MenuItem mnPP_PerfezionaMovimento;
		private System.Windows.Forms.MenuItem mnSB_GetioneErrori;
		private System.Windows.Forms.MenuItem mnSB_IP_Cancella;
		private System.Windows.Forms.MenuItem mnSB_Perfezionamento_Annulla;
		private System.Windows.Forms.MenuItem mnSB_SessioneBancaria_Cancella;
		private System.Windows.Forms.MenuItem mnSB_SP_CancellaUltimo;
		private System.Windows.Forms.MenuItem mnSP_Salva;
		private System.Windows.Forms.SaveFileDialog saveFileDialogCBI;
		private System.Windows.Forms.Timer timerSessioneCarica;
		private System.Windows.Forms.MenuItem mnIP_Visualizza;
		private System.Windows.Forms.MenuItem mnIP_Visualizza_IP;
		private System.Windows.Forms.MenuItem mnIP_Visualizza_CA;
		private System.Windows.Forms.MenuItem mnIP_Visualizza_CV;
		private System.Windows.Forms.MenuItem mnPP_PerfezionaTransazioni;

		public frmSessioneBancaria(string IdSessione)
		{
			InitializeComponent();
			this.IdSessione = IdSessione;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSessioneBancaria));
			this.dgMovimenti = new System.Windows.Forms.DataGrid();
			this.btnChiudiFinestra = new System.Windows.Forms.Button();
			this.cbMovimentiFilter = new System.Windows.Forms.ComboBox();
			this.txtMovimentiFilter = new System.Windows.Forms.TextBox();
			this.lblMovimentiFilter = new System.Windows.Forms.Label();
			this.chkboxVisualizzaAnchePerfezionati = new System.Windows.Forms.CheckBox();
			this.dgTransazioni = new System.Windows.Forms.DataGrid();
			this.SessioneBancariaMenu = new System.Windows.Forms.MainMenu();
			this.mmIP = new System.Windows.Forms.MenuItem();
			this.mnIP_Crea = new System.Windows.Forms.MenuItem();
			this.mnIP_Visualizza = new System.Windows.Forms.MenuItem();
			this.mnIP_Pubblica = new System.Windows.Forms.MenuItem();
			this.mnSP = new System.Windows.Forms.MenuItem();
			this.mnSP_Genera = new System.Windows.Forms.MenuItem();
			this.mnSP_Visualizza = new System.Windows.Forms.MenuItem();
			this.mnSP_VisualizzaTutti = new System.Windows.Forms.MenuItem();
			this.mnSP_Salva = new System.Windows.Forms.MenuItem();
			this.mnSP_Invia = new System.Windows.Forms.MenuItem();
			this.mnPP = new System.Windows.Forms.MenuItem();
			this.mnPP_PerfezionaMovimento = new System.Windows.Forms.MenuItem();
			this.mnPP_SelezionaTransazioni = new System.Windows.Forms.MenuItem();
			this.mnPP_PerfezionaTransazioni = new System.Windows.Forms.MenuItem();
			this.mnResidui = new System.Windows.Forms.MenuItem();
			this.mnResidui_GeneraMovimenti = new System.Windows.Forms.MenuItem();
			this.mnSB = new System.Windows.Forms.MenuItem();
			this.mnSB_ReportApertura = new System.Windows.Forms.MenuItem();
			this.mnSB_ReportStato = new System.Windows.Forms.MenuItem();
			this.mnSB_ReportChiusura = new System.Windows.Forms.MenuItem();
			this.mnSB_ChiusuraBancaria = new System.Windows.Forms.MenuItem();
			this.mnSB_GetioneErrori = new System.Windows.Forms.MenuItem();
			this.mnSB_IP_Cancella = new System.Windows.Forms.MenuItem();
			this.mnSB_SP_CancellaUltimo = new System.Windows.Forms.MenuItem();
			this.mnSB_Perfezionamento_Annulla = new System.Windows.Forms.MenuItem();
			this.mnSB_SessioneBancaria_Cancella = new System.Windows.Forms.MenuItem();
			this.cmnMovimenti = new System.Windows.Forms.ContextMenu();
			this.cmnMovimenti_PerfezionaPP = new System.Windows.Forms.MenuItem();
			this.saveFileDialogCBI = new System.Windows.Forms.SaveFileDialog();
			this.timerSessioneCarica = new System.Windows.Forms.Timer(this.components);
			this.mnIP_Visualizza_IP = new System.Windows.Forms.MenuItem();
			this.mnIP_Visualizza_CA = new System.Windows.Forms.MenuItem();
			this.mnIP_Visualizza_CV = new System.Windows.Forms.MenuItem();
			((System.ComponentModel.ISupportInitialize)(this.dgMovimenti)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgTransazioni)).BeginInit();
			this.SuspendLayout();
			// 
			// dgMovimenti
			// 
			this.dgMovimenti.AllowNavigation = false;
			this.dgMovimenti.AllowSorting = false;
			this.dgMovimenti.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgMovimenti.CaptionText = "Movimenti bancari";
			this.dgMovimenti.CausesValidation = false;
			this.dgMovimenti.DataMember = "";
			this.dgMovimenti.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgMovimenti.Location = new System.Drawing.Point(8, 40);
			this.dgMovimenti.Name = "dgMovimenti";
			this.dgMovimenti.ReadOnly = true;
			this.dgMovimenti.Size = new System.Drawing.Size(856, 272);
			this.dgMovimenti.TabIndex = 0;
			this.dgMovimenti.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgMovimenti_MouseDown);
			// 
			// btnChiudiFinestra
			// 
			this.btnChiudiFinestra.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChiudiFinestra.Location = new System.Drawing.Point(712, 464);
			this.btnChiudiFinestra.Name = "btnChiudiFinestra";
			this.btnChiudiFinestra.Size = new System.Drawing.Size(152, 23);
			this.btnChiudiFinestra.TabIndex = 4;
			this.btnChiudiFinestra.Text = "Cancel";
			this.btnChiudiFinestra.Click += new System.EventHandler(this.btnChiudiFinestra_Click);
			// 
			// cbMovimentiFilter
			// 
			this.cbMovimentiFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbMovimentiFilter.Items.AddRange(new object[] {
																   "<nessun filtro>",
																   "Ragione sociale ordinante",
																   "Codice conto ordinante",
																   "Ragione sociale beneficiario",
																   "Codice conto beneficiario"});
			this.cbMovimentiFilter.Location = new System.Drawing.Point(136, 8);
			this.cbMovimentiFilter.Name = "cbMovimentiFilter";
			this.cbMovimentiFilter.Size = new System.Drawing.Size(200, 21);
			this.cbMovimentiFilter.TabIndex = 5;
			this.cbMovimentiFilter.SelectedIndexChanged += new System.EventHandler(this.cbMovimentiFilter_SelectedIndexChanged);
			// 
			// txtMovimentiFilter
			// 
			this.txtMovimentiFilter.Location = new System.Drawing.Point(344, 8);
			this.txtMovimentiFilter.Name = "txtMovimentiFilter";
			this.txtMovimentiFilter.Size = new System.Drawing.Size(240, 20);
			this.txtMovimentiFilter.TabIndex = 6;
			this.txtMovimentiFilter.Text = "";
			this.txtMovimentiFilter.TextChanged += new System.EventHandler(this.txtMovimentiFilter_TextChanged);
			// 
			// lblMovimentiFilter
			// 
			this.lblMovimentiFilter.Location = new System.Drawing.Point(16, 16);
			this.lblMovimentiFilter.Name = "lblMovimentiFilter";
			this.lblMovimentiFilter.Size = new System.Drawing.Size(120, 16);
			this.lblMovimentiFilter.TabIndex = 7;
			this.lblMovimentiFilter.Text = "Filtro lista movimenti :";
			// 
			// chkboxVisualizzaAnchePerfezionati
			// 
			this.chkboxVisualizzaAnchePerfezionati.Location = new System.Drawing.Point(600, 8);
			this.chkboxVisualizzaAnchePerfezionati.Name = "chkboxVisualizzaAnchePerfezionati";
			this.chkboxVisualizzaAnchePerfezionati.Size = new System.Drawing.Size(240, 24);
			this.chkboxVisualizzaAnchePerfezionati.TabIndex = 8;
			this.chkboxVisualizzaAnchePerfezionati.Text = "Visualizza anche i movimenti perfezionati";
			this.chkboxVisualizzaAnchePerfezionati.CheckedChanged += new System.EventHandler(this.chkboxVisualizzaAnchePerfezionati_CheckedChanged);
			// 
			// dgTransazioni
			// 
			this.dgTransazioni.AllowNavigation = false;
			this.dgTransazioni.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgTransazioni.CaptionText = "Transazioni";
			this.dgTransazioni.DataMember = "";
			this.dgTransazioni.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgTransazioni.Location = new System.Drawing.Point(8, 320);
			this.dgTransazioni.Name = "dgTransazioni";
			this.dgTransazioni.Size = new System.Drawing.Size(856, 136);
			this.dgTransazioni.TabIndex = 9;
			this.dgTransazioni.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgTransazioni_MouseUp);
			// 
			// SessioneBancariaMenu
			// 
			this.SessioneBancariaMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																								 this.mmIP,
																								 this.mnSP,
																								 this.mnPP,
																								 this.mnResidui,
																								 this.mnSB});
			// 
			// mmIP
			// 
			this.mmIP.Index = 0;
			this.mmIP.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				 this.mnIP_Crea,
																				 this.mnIP_Visualizza,
																				 this.mnIP_Pubblica});
			this.mmIP.Text = "Istruzioni di pagamento";
			// 
			// mnIP_Crea
			// 
			this.mnIP_Crea.Index = 0;
			this.mnIP_Crea.Text = "Crea";
			this.mnIP_Crea.Click += new System.EventHandler(this.mnIP_Crea_Click);
			// 
			// mnIP_Visualizza
			// 
			this.mnIP_Visualizza.Index = 1;
			this.mnIP_Visualizza.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							this.mnIP_Visualizza_IP,
																							this.mnIP_Visualizza_CA,
																							this.mnIP_Visualizza_CV});
			this.mnIP_Visualizza.Text = "Visualizza";
			// 
			// mnIP_Pubblica
			// 
			this.mnIP_Pubblica.Index = 2;
			this.mnIP_Pubblica.Text = "Pubblica";
			this.mnIP_Pubblica.Click += new System.EventHandler(this.mnIP_Pubblica_Click);
			// 
			// mnSP
			// 
			this.mnSP.Index = 1;
			this.mnSP.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				 this.mnSP_Genera,
																				 this.mnSP_Visualizza,
																				 this.mnSP_VisualizzaTutti,
																				 this.mnSP_Salva,
																				 this.mnSP_Invia});
			this.mnSP.Text = "Ordini di pagamento";
			// 
			// mnSP_Genera
			// 
			this.mnSP_Genera.Index = 0;
			this.mnSP_Genera.Text = "Genera nuovo";
			this.mnSP_Genera.Click += new System.EventHandler(this.mnSP_Genera_Click);
			// 
			// mnSP_Visualizza
			// 
			this.mnSP_Visualizza.Index = 1;
			this.mnSP_Visualizza.Text = "Visualizza ultimo";
			this.mnSP_Visualizza.Click += new System.EventHandler(this.mnSP_Visualizza_Click);
			// 
			// mnSP_VisualizzaTutti
			// 
			this.mnSP_VisualizzaTutti.Index = 2;
			this.mnSP_VisualizzaTutti.Text = "Visualizza tutti";
			this.mnSP_VisualizzaTutti.Click += new System.EventHandler(this.mnSP_VisualizzaTutti_Click);
			// 
			// mnSP_Salva
			// 
			this.mnSP_Salva.Index = 3;
			this.mnSP_Salva.Text = "Salva CBI da inviare alla banca";
			this.mnSP_Salva.Click += new System.EventHandler(this.mnSP_Salva_Click);
			// 
			// mnSP_Invia
			// 
			this.mnSP_Invia.Index = 4;
			this.mnSP_Invia.Text = "Notifica invio CBI alla banca";
			this.mnSP_Invia.Click += new System.EventHandler(this.mnSP_Invia_Click);
			// 
			// mnPP
			// 
			this.mnPP.Index = 2;
			this.mnPP.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				 this.mnPP_PerfezionaMovimento,
																				 this.mnPP_SelezionaTransazioni,
																				 this.mnPP_PerfezionaTransazioni});
			this.mnPP.Text = "Movimenti Privato-Privato";
			this.mnPP.Popup += new System.EventHandler(this.mnPP_Popup);
			// 
			// mnPP_PerfezionaMovimento
			// 
			this.mnPP_PerfezionaMovimento.Index = 0;
			this.mnPP_PerfezionaMovimento.Text = "Perfeziona movimento PP";
			this.mnPP_PerfezionaMovimento.Click += new System.EventHandler(this.mnPP_PerfezionaMovimento_Click);
			// 
			// mnPP_SelezionaTransazioni
			// 
			this.mnPP_SelezionaTransazioni.Index = 1;
			this.mnPP_SelezionaTransazioni.Text = "Seleziona transazioni per perfezionamento parziale";
			this.mnPP_SelezionaTransazioni.Click += new System.EventHandler(this.mnPP_SelezionaTransazioni_Click);
			// 
			// mnPP_PerfezionaTransazioni
			// 
			this.mnPP_PerfezionaTransazioni.Index = 2;
			this.mnPP_PerfezionaTransazioni.Text = "Perfeziona transazioni selezionate";
			this.mnPP_PerfezionaTransazioni.Click += new System.EventHandler(this.mnPP_PerfezionaTransazioni_Click);
			// 
			// mnResidui
			// 
			this.mnResidui.Index = 3;
			this.mnResidui.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnResidui_GeneraMovimenti});
			this.mnResidui.Text = "Restituzione Residui";
			// 
			// mnResidui_GeneraMovimenti
			// 
			this.mnResidui_GeneraMovimenti.Index = 0;
			this.mnResidui_GeneraMovimenti.Text = "Genera movimenti";
			this.mnResidui_GeneraMovimenti.Click += new System.EventHandler(this.mnResidui_GeneraMovimenti_Click);
			// 
			// mnSB
			// 
			this.mnSB.Index = 4;
			this.mnSB.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				 this.mnSB_ReportApertura,
																				 this.mnSB_ReportStato,
																				 this.mnSB_ReportChiusura,
																				 this.mnSB_ChiusuraBancaria,
																				 this.mnSB_GetioneErrori});
			this.mnSB.Text = "Sessione bancaria";

			this.mnSB_ReportApertura.Index = 0;
			this.mnSB_ReportApertura.Text = "Report di apertura sessione";
			this.mnSB_ReportApertura.Click += new EventHandler(mnSB_ReportApertura_Click);


			this.mnSB_ReportStato.Index = 1;
			this.mnSB_ReportStato.Text = "Report di stato sessione";
			this.mnSB_ReportStato.Click += new EventHandler(mnSB_ReportStato_Click);

			this.mnSB_ReportChiusura.Index = 2;
			this.mnSB_ReportChiusura.Text = "Report di chiusura sessione";
			this.mnSB_ReportChiusura.Click += new EventHandler(mnSB_ReportChiusura_Click);

			// 
			// mnSB_ChiusuraBancaria
			// 
			this.mnSB_ChiusuraBancaria.Index = 3;
			this.mnSB_ChiusuraBancaria.Text = "Chiusura bancaria";
			this.mnSB_ChiusuraBancaria.Click += new System.EventHandler(this.mnSB_ChiusuraBancaria_Click);
			// 
			// mnSB_GetioneErrori
			// 
			this.mnSB_GetioneErrori.Index = 3;
			this.mnSB_GetioneErrori.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							   this.mnSB_IP_Cancella,
																							   this.mnSB_SP_CancellaUltimo,
																							   this.mnSB_Perfezionamento_Annulla,
																							   this.mnSB_SessioneBancaria_Cancella});
			this.mnSB_GetioneErrori.Text = "Gestione errori";
			// 
			// mnSB_IP_Cancella
			// 
			this.mnSB_IP_Cancella.Index = 0;
			this.mnSB_IP_Cancella.Text = "Cancella istruzione di pagamento";
			this.mnSB_IP_Cancella.Click += new System.EventHandler(this.mnSB_IP_Cancella_Click);
			// 
			// mnSB_SP_CancellaUltimo
			// 
			this.mnSB_SP_CancellaUltimo.Index = 1;
			this.mnSB_SP_CancellaUltimo.Text = "Cancella ultimo ordine di pagamento";
			this.mnSB_SP_CancellaUltimo.Click += new System.EventHandler(this.mnSB_SP_CancellaUltimo_Click);
			// 
			// mnSB_Perfezionamento_Annulla
			// 
			this.mnSB_Perfezionamento_Annulla.Index = 2;
			this.mnSB_Perfezionamento_Annulla.Text = "Annulla perfezionamento totale o parziale di un movimento PP";
			this.mnSB_Perfezionamento_Annulla.Click += new System.EventHandler(this.mnSB_Perfezionamento_Annulla_Click);
			// 
			// mnSB_SessioneBancaria_Cancella
			// 
			this.mnSB_SessioneBancaria_Cancella.Index = 3;
			this.mnSB_SessioneBancaria_Cancella.Text = "Cancella la sessione bancaria";
			this.mnSB_SessioneBancaria_Cancella.Click += new System.EventHandler(this.mnSB_SessioneBancaria_Cancella_Click);
			// 
			// cmnMovimenti
			// 
			this.cmnMovimenti.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.cmnMovimenti_PerfezionaPP});
			// 
			// cmnMovimenti_PerfezionaPP
			// 
			this.cmnMovimenti_PerfezionaPP.Index = 0;
			this.cmnMovimenti_PerfezionaPP.Text = "Perfeziona movimento PP";
			this.cmnMovimenti_PerfezionaPP.Click += new System.EventHandler(this.cmnMovimenti_PerfezionaPP_Click);
			// 
			// saveFileDialogCBI
			// 
			this.saveFileDialogCBI.DefaultExt = "cbi";
			this.saveFileDialogCBI.Filter = "CBI files (*.cbi)|*.cbi";
			this.saveFileDialogCBI.Title = "Salva file CBI da inviare alla banca";
			// 
			// timerSessioneCarica
			// 
			this.timerSessioneCarica.Tick += new System.EventHandler(this.timerSessioneCarica_Tick);
			// 
			// mnIP_Visualizza_IP
			// 
			this.mnIP_Visualizza_IP.Index = 0;
			this.mnIP_Visualizza_IP.Text = "Istruzioni";
			this.mnIP_Visualizza_IP.Click += new System.EventHandler(this.mnIP_Visualizza_IP_Click);
			// 
			// mnIP_Visualizza_CA
			// 
			this.mnIP_Visualizza_CA.Index = 1;
			this.mnIP_Visualizza_CA.Text = "Report acquisti";
			this.mnIP_Visualizza_CA.Click += new System.EventHandler(this.mnIP_Visualizza_CA_Click);
			// 
			// mnIP_Visualizza_CV
			// 
			this.mnIP_Visualizza_CV.Index = 2;
			this.mnIP_Visualizza_CV.Text = "Report vendite";
			this.mnIP_Visualizza_CV.Click += new System.EventHandler(this.mnIP_Visualizza_CV_Click);
			// 
			// frmSessioneBancaria
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(872, 493);
			this.Controls.Add(this.dgTransazioni);
			this.Controls.Add(this.chkboxVisualizzaAnchePerfezionati);
			this.Controls.Add(this.lblMovimentiFilter);
			this.Controls.Add(this.txtMovimentiFilter);
			this.Controls.Add(this.cbMovimentiFilter);
			this.Controls.Add(this.btnChiudiFinestra);
			this.Controls.Add(this.dgMovimenti);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.SessioneBancariaMenu;
			this.Name = "frmSessioneBancaria";
			this.Text = "Sessione bancaria";
			this.Load += new System.EventHandler(this.frmSessioneBancaria_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgMovimenti)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgTransazioni)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frmSessioneBancaria_Load(object sender, System.EventArgs e)
		{
			_SessioneAperta = false;
			cbMovimentiFilter.SelectedIndex = 0;
			AbilitaMaschera(_SessioneAperta, false);

			// qui carico i dati della sessione (tra un secondo)
			timerSessioneCarica.Start();
		}

		void AbilitaMaschera(bool Enabled, bool EnableReadOnly)
		{
			EnableMenu(this.Menu.MenuItems, Enabled);  // disabilito i menu`
			EnableMenu(this.cmnMovimenti.MenuItems, Enabled);   // il menu contestuale.

			foreach (Control c in this.Controls) // i controlli
				c.Enabled = Enabled;

			if (EnableReadOnly)
			{
				// qui ri-abilito, dopo averli disabilitati i controlli e i menu` read-only
				object [] readOnlyControls = new object[]
				{
					mnSB_ReportApertura,
					mnSB_ReportStato,
					mnSB_ReportChiusura,
#if DEBUG
					mnSB_SessioneBancaria_Cancella,
#endif
					mnIP_Visualizza_CA,
					mnIP_Visualizza_CV,
					mnIP_Visualizza_IP,
					mnSP_VisualizzaTutti,
					lblMovimentiFilter,
					cbMovimentiFilter,
					txtMovimentiFilter,
					chkboxVisualizzaAnchePerfezionati
				};
				foreach (object c in readOnlyControls) // i controlli readOnly devono essere comunque abilitati
				{
					if (c is Control)
					{
						(c as Control).Enabled = true;
					}
					else if (c is MenuItem)
					{
						MenuItem m = c as MenuItem;
						for (;;)
						{
							m.Enabled = true;
							if (!(m.Parent is MenuItem))
								break;
							m = (MenuItem)m.Parent;
						}
					}
					else
					{
						Debug.Assert(false);
					}
				}
			}

			btnChiudiFinestra.Enabled = true;  // eccetto il bottone di chiude.
			dgMovimenti.Enabled = true;  // le due griglie.
			dgTransazioni.Enabled = true;
		}
		static void EnableMenu(System.Windows.Forms.Menu.MenuItemCollection mc, bool Enable)
		{
			foreach (MenuItem m in mc)
			{
				m.Enabled = Enable;
				EnableMenu(m.MenuItems, Enable);
			}
		}

		#region Web Services
		private bool SessioneBancaria_Esiste(BLSessioneBancaria bl, string IdSessione)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}
				IAsyncResult asr = bl.BeginSessioneBancaria_Esiste(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_Esiste(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private bool SessioneBancaria_Aperta(BLSessioneBancaria bl, string IdSessione)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}
				IAsyncResult asr = bl.BeginSessioneBancaria_Aperta(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_Aperta(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		
		private DataSet SessioneBancaria_Dati(BLSessioneBancaria bl, string IdSessione)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}
				IAsyncResult asr = bl.BeginSessioneBancaria_Dati(IdSessione, _TSUltimaModifica, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_Dati(asr, out _TSUltimaModifica);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private DataSet SessioneBancaria_Crea(BLSessioneBancaria bl, string IdSessione, DateTime ValutaGP, DateTime ValutaPP, out string msg)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}
				IAsyncResult asr = bl.BeginSessioneBancaria_Crea(IdSessione, _TSUltimaModifica, ValutaGP, ValutaPP, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_Crea(asr, out _TSUltimaModifica, out msg);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}

		private string SessioneBancaria_CreazionePossibile(BLSessioneBancaria bl, string IdSessione)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}
				IAsyncResult asr = bl.BeginSessioneBancaria_CreazionePossibile(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_CreazionePossibile(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		
		private string IstruzioniDiPagamento_Visualizza(BLSessioneBancaria bl, string IdSessione, string TipoReport)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}
				IAsyncResult asr = bl.BeginIstruzioniDiPagamento_Visualizza(IdSessione, TipoReport, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndIstruzioniDiPagamento_Visualizza(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}

		private string IstruzioniDiPagamento_Genera(BLSessioneBancaria bl, string IdSessione)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}
				IAsyncResult asr = bl.BeginIstruzioniDiPagamento_Genera(IdSessione, _TSUltimaModifica, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndIstruzioniDiPagamento_Genera(asr, out _TSUltimaModifica);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}

		private DataSet IstruzioniDiPagamento_Pubblica(string IdSessione, out string msg)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginIstruzioniDiPagamento_Pubblica(IdSessione, _TSUltimaModifica, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndIstruzioniDiPagamento_Pubblica(asr, out _TSUltimaModifica, out msg);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private DataSet Residui_Calcola(string IdSessione, DateTime valutaRestituzioneResiduo, out string msg)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginResidui_Calcola(IdSessione, _TSUltimaModifica, valutaRestituzioneResiduo, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndResidui_Calcola(asr, out _TSUltimaModifica, out msg);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private string OrdinePagamentoSanPaolo_CreaNuovo(string IdSessione)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginOrdinePagamentoSanPaolo_CreaNuovo(IdSessione, _TSUltimaModifica, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndOrdinePagamentoSanPaolo_CreaNuovo(asr, out _TSUltimaModifica);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private string OrdinePagamentoSanPaolo_VisualizzaUltimoSP(string IdSessione)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginOrdinePagamentoSanPaolo_VisualizzaUltimoSP(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndOrdinePagamentoSanPaolo_VisualizzaUltimoSP(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private string OrdinePagamentoSanPaolo_CBI_DaInviare(string IdSessione, out DateTime TSCreazione)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginOrdinePagamentoSanPaolo_CBI_DaInviare(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndOrdinePagamentoSanPaolo_CBI_DaInviare(asr, out TSCreazione);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private DataSet OrdinePagamentoSanPaolo_InviaUltimo(string IdSessione, DateTime TSInvio, out string msg)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginOrdinePagamentoSanPaolo_InviaUltimo(IdSessione, _TSUltimaModifica, TSInvio, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndOrdinePagamentoSanPaolo_InviaUltimo(asr, out _TSUltimaModifica, out msg);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private DataSet OrdinePagamentoSanPaolo_Lista_SP_CBISP(BLSessioneBancaria bl, string IdSessione)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}

				IAsyncResult asr = bl.BeginOrdinePagamentoSanPaolo_Lista_SP_CBISP(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndOrdinePagamentoSanPaolo_Lista_SP_CBISP(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		
		private string OrdinePagamentoSanPaolo_Visualizza(BLSessioneBancaria bl, string IdSessione, string IdReport)
		{
			try
			{
				if (bl == null)
				{
					bl = new BLSessioneBancaria();
					frmLogin.AddLoginInfo(bl);
				}

				IAsyncResult asr = bl.BeginOrdinePagamentoSanPaolo_Visualizza(IdSessione, IdReport, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndOrdinePagamentoSanPaolo_Visualizza(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private DataSet MovPP_Perfezionato(string IdSessione, string IdMovPP, string trList, DateTime TSPerfezionato, DateTime TSGP2, out string msg)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginMovPP_Perfezionato(IdSessione, _TSUltimaModifica, IdMovPP, trList, TSPerfezionato, TSGP2, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndMovPP_Perfezionato(asr, out _TSUltimaModifica, out msg);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}

		private string SessioneBancaria_ReportApertura(string IdSessione)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginSessioneBancaria_ReportApertura(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_ReportApertura(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private string SessioneBancaria_ReportStato(string IdSessione)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginSessioneBancaria_ReportStato(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_ReportStato(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private string SessioneBancaria_ReportChiusura(string IdSessione)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginSessioneBancaria_ReportChiusura(IdSessione, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_ReportChiusura(asr);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}


		private DataSet SessioneBancaria_Chiudi(string IdSessione, DateTime TSValuta, out string msg)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginSessioneBancaria_Chiudi(IdSessione, _TSUltimaModifica, TSValuta, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_Chiudi(asr, out _TSUltimaModifica, out msg);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}

		private DataSet IstruzioniDiPagamento_CancellaUltimo(string IdSessione, out string msg)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginIstruzioniDiPagamento_CancellaUltimo(IdSessione, _TSUltimaModifica, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndIstruzioniDiPagamento_CancellaUltimo(asr, out _TSUltimaModifica, out msg);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}

		private string OrdinePagamentoSanPaolo_CancellaUltimo(string IdSessione)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginOrdinePagamentoSanPaolo_CancellaUltimo(IdSessione, _TSUltimaModifica, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndOrdinePagamentoSanPaolo_CancellaUltimo(asr, out _TSUltimaModifica);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}
		private DataSet MovPP_PerfezionamentoErrato(string IdSessione, string IdMovimento, out string msg)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginMovPP_PerfezionamentoErrato(IdSessione, _TSUltimaModifica, IdMovimento, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndMovPP_PerfezionamentoErrato(asr, out _TSUltimaModifica, out msg);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}

		private string SessioneBancaria_Cancella(string IdSessione)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				IAsyncResult asr = bl.BeginSessioneBancaria_Cancella(IdSessione, _TSUltimaModifica, null, null);
				frmAsyncWait.ShowForm(asr);
				return bl.EndSessioneBancaria_Cancella(asr, out _TSUltimaModifica);
			}
			catch (Exception ex)
			{
				// gestione comune degli errori da soap, cancel --> trace ecc.
				// La funzione lancia CancelException su cancel
				// ApplicationException su errori di comnunicazione ecc.
				// Nel caso di ApplicationException bisogna visualizzare il messaggio associato all'operatore.
				frmAsyncWait.OnCatchException(ex);
				Debug.Assert(false);
				throw new Exception(); // non eseguito mai
			}
		}

		#endregion Web Services


		private void timerSessioneCarica_Tick(object sender, System.EventArgs e)
		{
			timerSessioneCarica.Stop();

			Cursor.Current = Cursors.WaitCursor;

			try
			{
				WebUtility.DownloadFile("gme_logo.jpg", Application.StartupPath + @"\gme_logo.jpg");
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore caricando il file gme_logo.jpg\n" + ex.Message);
			}

			try
			{
				_SessioneAperta = false;
				DataSet ds;

				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				bool EsisteSessione = SessioneBancaria_Esiste(bl, IdSessione);
				if (EsisteSessione)
				{
					_SessioneAperta = SessioneBancaria_Aperta(bl, IdSessione);
					ds = SessioneBancaria_Dati(bl, IdSessione);
					AbilitaMaschera(_SessioneAperta, true);

					// se esiste la sessione ma e` chiusa faccio vedere i mov. perfezionati
					if (_SessioneAperta == false)
						chkboxVisualizzaAnchePerfezionati.Checked = true;

					AggiornaDataSet(ds);
					return;
				}

				DialogResult r;
				DateTime TSValutaGP;
				DateTime TSValutaPP;
				r = frmConfermaEtValuta.Show("Non esiste sessione bancaria per questa sessione.\n" +
					"Vuoi creare la sessione bancaria?",
					"Valuta movimenti GP|Valuta movimenti PP", out TSValutaGP, out TSValutaPP);
				if (r == DialogResult.No)
					return;

				string msgCreazionePossibile = SessioneBancaria_CreazionePossibile(bl, IdSessione);
				if (msgCreazionePossibile != null)
				{
					MessageBox.Show("Non e` possibile creare la sessione bancaria:\n" + msgCreazionePossibile, "Attenzione", MessageBoxButtons.OK);
					return;
				}
			
				string ret;
				ds = SessioneBancaria_Crea(bl, IdSessione, TSValutaGP, TSValutaPP, out ret);
				if (ret.Length > 0)
				{
					MessageBox.Show(ret, "Attenzione");
					return;
				}

				// se sono qui significa che ho creato una sessione bancaria e 
				// che questa e` in stato aperta.
				_SessioneAperta = true;
				AggiornaDataSet(ds);
				AbilitaMaschera(_SessioneAperta, true);
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnChiudiFinestra_Click(object sender, System.EventArgs e)
		{
			timerSessioneCarica.Stop(); // casomai fosse veloce a schiacciare il bottone
			this.Close();
		}


		#region Binding DataSet e aggiornamento quando arriva un nuovo DataSet
		private void AggiornaDataSet(DataSet ds)
		{
			_ds = ds;

			if (_ds == null)
				return;

			if (true)
			{
				DataView dvTransazioni = new DataView(_ds.Tables["Transazioni"]);  
				dvTransazioni.AllowDelete	= false;
				dvTransazioni.AllowNew	= false;
				dvTransazioni.AllowEdit	= true;
				dgTransazioni.DataSource = dvTransazioni;
				Debug.Assert(this.BindingContext.Contains(dvTransazioni));
				_cmTransazioni = (CurrencyManager)this.BindingContext[dvTransazioni];

				SetDataGridMappingTransazioni();
			}
			if (true)
			{
				DataView dvMovimenti = new DataView(_ds.Tables["MovimentiBancari"]);  
				dvMovimenti.AllowDelete	= false;
				dvMovimenti.AllowNew	= false;
				dvMovimenti.AllowEdit	= false;
				dgMovimenti.DataSource = dvMovimenti;
				dvMovimenti.Sort = "SocietaSrc_RagioneSociale";
				Debug.Assert(this.BindingContext.Contains(dvMovimenti));
				_cmMovimenti = (CurrencyManager)this.BindingContext[dvMovimenti];
				_cmMovimenti.CurrentChanged += new EventHandler(this.cmMovimenti_CurrentChanged);
				dvMovimenti.ListChanged += new ListChangedEventHandler(this.dvMovimenti_ListChanged);
			
				RowFilter_Movimenti(); 
				SetDataGridMappingMovimenti();
			}
		}



		void SetDataGridMappingMovimenti()
		{
			if (dgMovimenti.TableStyles.Contains("MovimentiBancari"))
				return;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "MovimentiBancari"; // nome della tabella a cui si riferisce questa DataGridTableStyle
			dgStyle.AllowSorting = true;

			DataGridTextBoxColumn dgc;

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Ragione sociale ordinante";
			dgc.MappingName = "SocietaSrc_RagioneSociale";
			dgc.Width = 100;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Codice conto ordinante";
			dgc.MappingName = "SocietaSrc_CodiceConto";
			dgc.Width = 100;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Ragione sociale beneficiario";
			dgc.MappingName = "SocietaDst_RagioneSociale";
			dgc.Width = 100;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Codice conto beneficiario";
			dgc.MappingName = "SocietaDst_CodiceConto";
			dgc.Width = 100;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Tipo";
			dgc.MappingName = "TipoMovimento";
			dgc.Width = 40;
			dgStyle.GridColumnStyles.Add(dgc);


			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Importo";
			dgc.MappingName = "Importo";
			dgc.Width = 100;
			dgc.Format = "c"; // currency
			dgc.Alignment = HorizontalAlignment.Right;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Valuta";
			dgc.MappingName = "Valuta";
			dgc.Width = 80;
			dgc.Format = "d"; // data corta
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Causale";
			dgc.MappingName = "Causale";
			dgc.Width = 260;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Sottomesso il";
			dgc.MappingName = "TSSottomesso";
			dgc.NullText = "";
			dgc.Format = "d";
			dgc.Width = 100;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Perfezionato il";
			dgc.MappingName = "TSPerfezionato";
			dgc.NullText = "";
			dgc.Format = "d";
			dgc.Width = 120;
			dgStyle.GridColumnStyles.Add(dgc);


			dgMovimenti.TableStyles.Add(dgStyle);
		}

		void SetDataGridMappingTransazioni()
		{
			if (dgTransazioni.TableStyles.Contains("Transazioni"))
				return;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Transazioni"; // nome della tabella a cui si riferisce questa DataGridTableStyle
			dgStyle.AllowSorting = true;
			dgStyle.ReadOnly = false;


			DataGridTextBoxColumn dgc;

			dgc = new DataGridTextBoxColumn();
			dgc.ReadOnly = true;
			dgc.HeaderText = "Anno Rif.";
			dgc.MappingName = "AnnoRiferimento";
			dgc.Width = 60;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.ReadOnly = true;
			dgc.HeaderText = "Numero CV";
			dgc.MappingName = "NumeroCV";
			dgc.Format = "N0";
			dgc.Alignment = HorizontalAlignment.Right;
			dgc.Width = 80;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.ReadOnly = true;
			dgc.HeaderText = "Prezzo";
			dgc.MappingName = "Prezzo";
			dgc.Format = "c";
			dgc.Alignment = HorizontalAlignment.Right;
			dgc.Width = 100;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.ReadOnly = true;
			dgc.HeaderText = "Prezzo non coperto";
			dgc.MappingName = "PrezzoNonCoperto";
			dgc.Format = "c";
			dgc.Alignment = HorizontalAlignment.Right;
			dgc.Width = 120;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.ReadOnly = true;
			dgc.HeaderText = "Prezzo coperto";
			dgc.MappingName = "PrezzoCoperto";
			dgc.Format = "c";
			dgc.Alignment = HorizontalAlignment.Right;
			dgc.Width = 120;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.ReadOnly = true;
			dgc.HeaderText = "Prezzo Unitario MWh";
			dgc.MappingName = "PrezzoUnitario";
			dgc.Format = "c";
			dgc.Alignment = HorizontalAlignment.Right;
			dgc.Width = 150;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Stato Tr.";
			dgc.MappingName = "StatoTransazione";
			dgc.Width = 100;
			dgc.ReadOnly = true;
			dgStyle.GridColumnStyles.Add(dgc);

			DataGridBoolColumn dgck = new DataGridBoolColumn();
			dgck.HeaderText = "Da perfezionare";
			dgck.MappingName = "DaPerfezionare";
			dgck.Width = 100;
			dgck.ReadOnly = false;
			dgck.AllowNull = false;
			dgck.NullValue = false;
			dgck.TrueValue = true;
			dgck.FalseValue = false;
			dgck.Alignment = HorizontalAlignment.Left;
			dgStyle.GridColumnStyles.Add(dgck);

			dgTransazioni.TableStyles.Add(dgStyle);
		}
		#endregion


		#region Funzioni per ottenere la DataRow corrente in dgMovimenti e dgTransazioni
		/// <summary>
		/// Ritorna il movimento che ha la freccetta a sin. nella data grid dei movimenti.
		/// null se non esiste alcun movimento.
		/// </summary>
		/// <returns></returns>
		private DataRow GetMovimentoCorrente()
		{
			if (_cmMovimenti.Count == 0)
				return null;

			DataView dv = (DataView)_cmMovimenti.List;
			DataRow dr = dv[_cmMovimenti.Position].Row;
			return dr;
		}

		/// <summary>
		/// ritorna != null se il movimento corrente e` anche PP da perfezionare
		/// </summary>
		DataRow GetMovimentoCorrenteDaPerfezionare()
		{
			DataRow m = GetMovimentoCorrente();
			if (m == null)
				return null;

			if ((string)m["TipoMovimento"] == "PP" && m.IsNull("TSPerfezionato"))
				return m;

			return null;
		}
		#endregion


		#region Codice per filtrare i Movimenti visualizzati nella dgMovimenti
		private void cbMovimentiFilter_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			txtMovimentiFilter.Text = "";
		}
		private void txtMovimentiFilter_TextChanged(object sender, System.EventArgs e)
		{
			RowFilter_Movimenti();
		}
		private void chkboxVisualizzaAnchePerfezionati_CheckedChanged(object sender, System.EventArgs e)
		{
			RowFilter_Movimenti();
		}
		private void RowFilter_Movimenti()
		{
			if (_cmMovimenti == null)
				return;

			DataView dv = _cmMovimenti.List as DataView;
			/*
				"<nessun filtro>",
				"Ragione sociale ordinante",
				"Codice conto ordinante",
				"Ragione sociale beneficiario",
				"Codice conto beneficiario"});
			*/

			string s;

			switch (cbMovimentiFilter.SelectedIndex)
			{
				case 0:
					s = string.Empty;
					break;
				case 1:
					s = "SocietaSrc_RagioneSociale LIKE '" + txtMovimentiFilter.Text + "%'";
					break;
				case 2:
					s = "SocietaSrc_CodiceConto LIKE '" + txtMovimentiFilter.Text + "%'";
					break;
				case 3:
					s = "SocietaDst_RagioneSociale LIKE '" + txtMovimentiFilter.Text + "%'";
					break;
				case 4:
					s = "SocietaDst_CodiceConto LIKE '" + txtMovimentiFilter.Text + "%'";
					break;
				default:
					Debug.Assert(false);
					s = string.Empty;
					break;
			}

			if (chkboxVisualizzaAnchePerfezionati.Checked == false)
			{
				if (s.Length > 0)
					s += " And TSPerfezionato Is Null";
				else
					s = "TSPerfezionato Is Null";
			}

			dv.RowFilter = s;
		}
		#endregion


		#region Codice per gestire gli eventi del mouse su dgMovimenti

		/// <summary>
		/// micidiale funzione per evitare di cliccare 2 volte sulla checkbox
		/// per cambiarne lo stato
		private void dgTransazioni_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (_SessioneAperta)
			{
				DataGrid.HitTestInfo hti = this.dgTransazioni.HitTest(e.X, e.Y); 
				try 
				{
					if (hti.Type == DataGrid.HitTestType.Cell)
					{
						if (dgTransazioni.TableStyles["Transazioni"].GridColumnStyles[hti.Column] is DataGridBoolColumn)
							this.dgTransazioni[hti.Row, hti.Column] = ! (bool) this.dgTransazioni[hti.Row, hti.Column]; 
					}
				}                                                                                                    
				catch(Exception ex) 
				{ 
					MessageBox.Show(ex.ToString()); 
				}
			}
		} 
 
		/// <summary>
		/// Evento di click in dgMovimenti.
		/// 1) Si impone che la dgMovimenti abbia una sola riga selezionata
		/// 2) Si gestisce il menu` contestuale.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void dgMovimenti_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			DataGrid.HitTestInfo ht = dgMovimenti.HitTest(e.X, e.Y); 

			// questo serve per togliere selezioni multiple
			// e impostare la riga corrente 
			if (ht.Type == DataGrid.HitTestType.Cell || ht.Type == DataGrid.HitTestType.RowHeader)
			{
				for (int i = 0; i < _cmMovimenti.Count; ++i)
					if (dgMovimenti.IsSelected(i))
						dgMovimenti.UnSelect(i);

				dgMovimenti.CurrentCell = new DataGridCell(ht.Row, ht.Column);
				dgMovimenti.CurrentRowIndex = ht.Row;
			}

			// menu` contestuale: e' abilitato solo se il movimento e` PP la perfezionare
			if (_SessioneAperta)
			{
				if (e.Button == MouseButtons.Right && 
					(ht.Type == DataGrid.HitTestType.Cell || ht.Type == DataGrid.HitTestType.RowHeader))
				{
					if (this.GetMovimentoCorrenteDaPerfezionare() != null)
						cmnMovimenti_PerfezionaPP.Enabled = true;
					else
						cmnMovimenti_PerfezionaPP.Enabled = false;

					dgMovimenti.ContextMenu = cmnMovimenti;
				}
				else
					dgMovimenti.ContextMenu = null;
			}
			else
				dgMovimenti.ContextMenu = null;
		}
		#endregion


		#region Codice per gestire la selezione di un nuovo movimento in dgMovimenti
		private void cmMovimenti_CurrentChanged(object sender, EventArgs e)
		{
			// questo viene chiamato sia quando 
			// a) si cambia la > a sin. della dg
			// b) quando si fa sort.
			// c) quando si fa il RowFilter.
			dgMovimenti_FreccettaChanged();
		}

		private void dvMovimenti_ListChanged(object sender, ListChangedEventArgs e)
		{
			// la lista del DataView (la lista poi tramite Row punta ai DataRow)
			// e' cambiata a fronte di un sort, rowfilter
			dgMovimenti_FreccettaChanged();
		}

		private void dgMovimenti_FreccettaChanged()
		{
			try
			{
				DataView dvMovimenti = (DataView)_cmMovimenti.List;

				DataRow mov = GetMovimentoCorrente();
#if DEBUG
				if (mov == null)
					this.Text = "";
				else
					this.Text = (string)mov["IdMovimentoBancario"];
#endif

				// uso il RowFilter della view delle transazioni per visualizzare
				// solo le transazioni correlate al movimento
				if (_cmTransazioni != null)
				{
					DataView dvTransazioni = (DataView)_cmTransazioni.List;
					if (mov != null)
					{

						string f = string.Format(
							"IdMovGP='{0}' Or IdMovPP='{0}' Or IdMovPenale='{0}'",
							mov["IdMovimentoBancario"]);
						dvTransazioni.RowFilter = f;
					}
					else
						dvTransazioni.RowFilter = "IdTransazione=''";
				}


				// se si cambia la posizione nella tabella dei movimenti
				// azzero l'eventuale operazione di selezione delle transazioni
				// da perfezionare
				if (true)
				{
					dgTransazioni.TableStyles["Transazioni"].GridColumnStyles["DaPerfezionare"].Width = 0;
					_movDaPerfezionareParzialmente = null;
					mnPP_SelezionaTransazioni.Checked = false;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		#endregion

		#region Gestione Menu` Istruzioni di pagamento

		private void mnIP_Crea_Click(object sender, System.EventArgs e)
		{
			try
			{
				string r = IstruzioniDiPagamento_Genera(null, IdSessione);
				if (r == null || r.Length == 0)
					MessageBox.Show("Istruzioni di pagamento create", "Attenzione");
				else
					MessageBox.Show(r, "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void mnIP_Pubblica_Click(object sender, System.EventArgs e)
		{
			try
			{
				string ret;
				DataSet ds = IstruzioniDiPagamento_Pubblica(IdSessione, out ret);
				AggiornaDataSet(ds);
				if (ret.Length > 0)
					MessageBox.Show(ret, "Attenzione");
				else
					MessageBox.Show("Istruzioni di pagamento pubblicate", "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void mnIP_Visualizza_IP_Click(object sender, System.EventArgs e)
		{
			try
			{
				string data = IstruzioniDiPagamento_Visualizza(null, IdSessione, "IP");
				if (data == null)
					MessageBox.Show("Non esistono istruzioni di pagamento da visualizzare", "Attenzione");
				else
					new frmReportViewer("Istruzioni di pagamento", data, frmReportViewer.Formato.Html).ShowDialog(this);
		
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void mnIP_Visualizza_CA_Click(object sender, System.EventArgs e)
		{
			try
			{
				string data = IstruzioniDiPagamento_Visualizza(null, IdSessione, "CA");
				if (data == null)
					MessageBox.Show("Non esiste il report acquisti da visualizzare", "Attenzione");
				else
					new frmReportViewer("Report acquisti", data, frmReportViewer.Formato.Html).ShowDialog(this);
		
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void mnIP_Visualizza_CV_Click(object sender, System.EventArgs e)
		{
			try
			{
				string data = IstruzioniDiPagamento_Visualizza(null, IdSessione, "CV");
				if (data == null)
					MessageBox.Show("Non esiste il report vendite da visualizzare", "Attenzione");
				else
					new frmReportViewer("Report vendite", data, frmReportViewer.Formato.Html).ShowDialog(this);
		
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}


		#endregion

		#region Gestione Menu` Residui
		private void mnResidui_GeneraMovimenti_Click(object sender, System.EventArgs e)
		{
			try
			{
				DateTime TSValutaRestituzione;
				if (frmConfermaEtValuta.Show("Vuoi generare i movimenti per la restituzione del residuo ?",
					"Valuta dei movimenti di restituzione", out TSValutaRestituzione) == DialogResult.No)
					return;

				string ret;
				DataSet ds = Residui_Calcola(IdSessione, TSValutaRestituzione, out ret);
				AggiornaDataSet(ds);
				if (ret.Length > 0)
					MessageBox.Show(ret, "Attenzione");
				else
					MessageBox.Show("Movimenti per i residui generati", "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		#endregion

		#region Gestione Menu Ordini di pagamento
		private void mnSP_Genera_Click(object sender, System.EventArgs e)
		{
			try
			{
				string msg = OrdinePagamentoSanPaolo_CreaNuovo(this.IdSessione);
				MessageBox.Show(msg, "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void mnSP_Visualizza_Click(object sender, System.EventArgs e)
		{
			try
			{
				string data = OrdinePagamentoSanPaolo_VisualizzaUltimoSP(this.IdSessione);
				if (data != null)
					new frmReportViewer("Ordine di pagamento", data, frmReportViewer.Formato.Html).ShowDialog(this);
				else
					MessageBox.Show("Ultimo ordine di pagamento non disponibile", "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void mnSP_Salva_Click(object sender, System.EventArgs e)
		{
			try
			{
				DateTime TSCreazione;
				string data = OrdinePagamentoSanPaolo_CBI_DaInviare(this.IdSessione, out TSCreazione);
				if (data == null)
				{
					MessageBox.Show("Ultimo ordine di pagamento non generato o gia` inviato", "Attenzione");
					return;
				}

				string fn = string.Format("{0,4}{1,-2:00}{2,-2:00}{3,-2:00}{4,-2:00}{5,-2:00}", 
					TSCreazione.Year, TSCreazione.Month, TSCreazione.Day, TSCreazione.Hour, TSCreazione.Minute, TSCreazione.Second);
				saveFileDialogCBI.FileName = fn;
				DialogResult r = saveFileDialogCBI.ShowDialog();
				if (r == DialogResult.OK)
				{
					Stream ss = saveFileDialogCBI.OpenFile();
					StreamWriter sw = new StreamWriter(ss, Encoding.ASCII);
					sw.Write(data);
					sw.Flush();
					sw.Close();
					ss.Close();
				}

			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void mnSP_Invia_Click(object sender, System.EventArgs e)
		{
			DateTime TSInvio;
			if (frmConfermaEtValuta.Show("Selezionando questa voce si indica al programma\n"+
				"che l'ordine di pagamento e` stato inviato con successo al San Paolo.\n" +
				"Vuoi confermare l'inoltro dell'ultimo ordine di pagamento?", 
				"Data di invio al San Paolo", out TSInvio)
				== DialogResult.No)
				return;

			try
			{
				string ret;
				DataSet ds = OrdinePagamentoSanPaolo_InviaUltimo(this.IdSessione, TSInvio, out ret);
				AggiornaDataSet(ds);
				if (ret.Length > 0)
					MessageBox.Show(ret, "Attenzione");

			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void mnSP_VisualizzaTutti_Click(object sender, System.EventArgs e)
		{
			try
			{
				BLSessioneBancaria bl = new BLSessioneBancaria();
				frmLogin.AddLoginInfo(bl);

				DataSet ds = OrdinePagamentoSanPaolo_Lista_SP_CBISP(bl, this.IdSessione);
				frmListaOrdiniPagamento frm = new frmListaOrdiniPagamento(ds);
				DialogResult r =  frm.ShowDialog();
				if (r == DialogResult.OK)
				{
					string data = OrdinePagamentoSanPaolo_Visualizza(bl, IdSessione, frm.IdReport);
					if (frm.TipoReport == "SP")
						new frmReportViewer("Ordine Pagamento", data, frmReportViewer.Formato.Html).ShowDialog();
					else
						new frmReportViewer("Ordine Pagamento CBI", data, frmReportViewer.Formato.Cbi).ShowDialog();
				}
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		#endregion

		#region Gestione Menu` Perfeziona Movimenti e menu` contestuale in dgMovimenti
		private void mnPP_PerfezionaMovimento_Click(object sender, System.EventArgs e)
		{
			DataRow m = GetMovimentoCorrenteDaPerfezionare();
			if (m == null)
			{
				MessageBox.Show("Selezionare un movimento PP non perfezionato!", "Attenzione");
				return;
			}
			
			cmnMovimenti_PerfezionaPP_Click(sender, e);
		}

		private void mnPP_SelezionaTransazioni_Click(object sender, System.EventArgs e)
		{
			if (_movDaPerfezionareParzialmente == null)
			{
				DataRow m = GetMovimentoCorrenteDaPerfezionare();
				if (m == null)
				{
					MessageBox.Show("Selezionare un movimento PP non perfezionato!", "Attenzione");
					return;
				}

				foreach (DataRow tr in _ds.Tables["Transazioni"].Rows)
					tr["DaPerfezionare"] = false;

				dgTransazioni.TableStyles["Transazioni"].GridColumnStyles["DaPerfezionare"].Width = 100;
				_movDaPerfezionareParzialmente = m;
				mnPP_SelezionaTransazioni.Checked = true;
			}
			else
			{
				dgTransazioni.TableStyles["Transazioni"].GridColumnStyles["DaPerfezionare"].Width = 0;
				_movDaPerfezionareParzialmente = null;
				mnPP_SelezionaTransazioni.Checked = false;
			}
		}

		private void mnPP_PerfezionaTransazioni_Click(object sender, System.EventArgs e)
		{
			Debug.Assert(_movDaPerfezionareParzialmente != null);
			if (_movDaPerfezionareParzialmente == null)
				return;


			int numeroRigheNellaDgTransazioni = _cmTransazioni.Count;

			int numeroTransazioniSelezionate = 0;
			StringBuilder trList = new StringBuilder();
			if (true)
			{
				bool first = true;
				foreach (DataRow tr in _ds.Tables["Transazioni"].Rows)
					if ((bool)tr["DaPerfezionare"] == true)
					{
						numeroTransazioniSelezionate += 1;
						if (first == false)
							trList.Append("\n");
						first = false;
						trList.Append((string)tr["IdTransazione"]);
					}
			}

			if (numeroRigheNellaDgTransazioni == numeroTransazioniSelezionate)
			{
				MessageBox.Show("Sono state selezionate tutte le transazioni del movimento.\n" +
					"Per perfezionare tutte le transazioni di un movimento agire sulla voce\n" +
					"di menu '" + mnPP_PerfezionaMovimento.Text + "'",
					"Attenzione");
				return;
			}
			if (numeroTransazioniSelezionate == 0)
			{
				MessageBox.Show("Non e` stata selezionata neanche una transazione del movimento.\n" +
					"Per fare un perfezionamento parziale occorre selezionare almeno una transazione.",
					"Attenzione");
				return;
			}

			DateTime TSPerfezionato;
			DateTime TSGP2;

			if (numeroTransazioniSelezionate == 1)
			{
				if (frmConfermaEtValuta.Show("Vuoi perfezionare la transazione selezionata ?",
					"Data del bonifico|Valuta movimento quota coperta", out TSPerfezionato, out TSGP2) == DialogResult.No)
					return;
			}
			else
			{
				if (frmConfermaEtValuta.Show(
					string.Format("Vuoi perfezionare le {0} transazioni selezionate ?", numeroTransazioniSelezionate),
					"Data del bonifico|Valuta movimento quota coperta", out TSPerfezionato, out TSGP2) == DialogResult.No)
					return;
			}

			try
			{
				DataRow dr = (_cmMovimenti.List as DataView)[_cmMovimenti.Position].Row;
				string IdMovPP = (string)dr["IdMovimentoBancario"];

				string ret;
				DataSet ds = MovPP_Perfezionato(IdSessione, IdMovPP, trList.ToString(), TSPerfezionato, TSGP2, out ret);
				AggiornaDataSet(ds);
				if (ret.Length > 0)
					MessageBox.Show(ret, "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

		}

		private void mnPP_Popup(object sender, System.EventArgs e)
		{
			if (!_SessioneAperta)
				return;

			if (GetMovimentoCorrenteDaPerfezionare() != null)
			{
				if (_movDaPerfezionareParzialmente == null)
				{
					this.mnPP_PerfezionaMovimento.Enabled = true;
					this.mnPP_PerfezionaTransazioni.Enabled = false;
					this.mnPP_SelezionaTransazioni.Enabled = true;
				}
				else
				{
					this.mnPP_PerfezionaMovimento.Enabled = false;
					this.mnPP_SelezionaTransazioni.Enabled = true;

					// abilito il menu solo se ci sono transazioni selezionate
					int nSelezionate = 0;
					if (true)
					{
						foreach (DataRow tr in _ds.Tables["Transazioni"].Rows)
							if ((bool)tr["DaPerfezionare"])
								nSelezionate++;
					}
					if (nSelezionate == 0)
						this.mnPP_PerfezionaTransazioni.Enabled = false;
					else
						this.mnPP_PerfezionaTransazioni.Enabled = true;
				}
			}
			else
			{
				this.mnPP_PerfezionaMovimento.Enabled = false;
				this.mnPP_PerfezionaTransazioni.Enabled = false;
				this.mnPP_SelezionaTransazioni.Enabled = false;
			}
		}
		private void cmnMovimenti_PerfezionaPP_Click(object sender, System.EventArgs e)
		{
			DateTime TSPerfezionato;
			DateTime TSGP2;

			if (frmConfermaEtValuta.Show("Vuoi perfezionare tutte le transazioni del movimento selezionato?",
				"Valuta del bonifico|Valuta del movimento della quota coperta", out TSPerfezionato, out TSGP2) == DialogResult.No)
				return;

			// il movimento da perfezionare e' il movimento corrente.
			try
			{
				DataRow dr = GetMovimentoCorrenteDaPerfezionare();
				string IdMovPP = (string)dr["IdMovimentoBancario"];

				string ret;
				DataSet ds = MovPP_Perfezionato(IdSessione, IdMovPP, null, TSPerfezionato, TSGP2, out ret);
				AggiornaDataSet(ds);
				if (ret.Length > 0)
					MessageBox.Show(ret, "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		#endregion

		#region Gestione Menu` Sessione bancaria
		private void mnSB_ReportApertura_Click(object sender, EventArgs e)
		{
			try
			{
				string ret = SessioneBancaria_ReportApertura(this.IdSessione);
				if (ret == null)
					MessageBox.Show("Report non disponibile");
				else
					new frmReportViewer("Report di apertura della sessione bancaria", ret, frmReportViewer.Formato.Html).ShowDialog();
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void mnSB_ReportStato_Click(object sender, EventArgs e)
		{
			try
			{
				string ret = SessioneBancaria_ReportStato(this.IdSessione);
				if (ret == null)
					MessageBox.Show("Report non disponibile");
				else
					new frmReportViewer("Report di stato della sessione bancaria", ret, frmReportViewer.Formato.Html).ShowDialog();
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void mnSB_ReportChiusura_Click(object sender, EventArgs e)
		{
			try
			{
				string ret = SessioneBancaria_ReportChiusura(this.IdSessione);
				if (ret == null)
					MessageBox.Show("Report non disponibile");
				else
					new frmReportViewer("Report di chiusura della sessione bancaria", ret, frmReportViewer.Formato.Html).ShowDialog();
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}


		private void mnSB_ChiusuraBancaria_Click(object sender, System.EventArgs e)
		{
			try
			{
				DateTime TSValuta;

				if (frmConfermaEtValuta.Show("Vuoi effettuare la chiusura bancaria?\nAttenzione la chiusura bancaria e` un'operazione definitiva!",
					"Valuta penali e restituzione residuo", out TSValuta) == DialogResult.No)
					return;

				string ret;
				DataSet ds = SessioneBancaria_Chiudi(this.IdSessione, TSValuta, out ret);
				AggiornaDataSet(ds);
				if (ret.Length > 0)
					MessageBox.Show(ret, "Attenzione");
				else
				{
					MessageBox.Show("Sessione bancaria chiusa", "Attenzione");
					_SessioneAperta = false;
					AbilitaMaschera(_SessioneAperta, true);
				}
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void mnSB_IP_Cancella_Click(object sender, System.EventArgs e)
		{
			if (MessageBox.Show("Sei sicuro di voler cancellare le istruzioni di pagamento?", "Attenzione", MessageBoxButtons.YesNo) == DialogResult.No)
				return;

			try
			{
				string msg;
				DataSet ds = IstruzioniDiPagamento_CancellaUltimo(IdSessione, out msg);
				AggiornaDataSet(ds);
				if (msg == null | msg.Length == 0)
					MessageBox.Show("Istruzioni di pagamento cancellate", "Attenzione");
				else
					MessageBox.Show(msg, "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void mnSB_SP_CancellaUltimo_Click(object sender, System.EventArgs e)
		{
			try
			{
				string msg = OrdinePagamentoSanPaolo_CancellaUltimo(this.IdSessione);
				if (msg.Length == 0)
					MessageBox.Show("Cancellazione avvenuta con successo", "Attenzione");
				else
					MessageBox.Show(msg, "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		
		}
		private void mnSB_Perfezionamento_Annulla_Click(object sender, System.EventArgs e)
		{
			try
			{
				DataRow mov = GetMovimentoCorrente();
				if (mov == null || (string)mov["TipoMovimento"] != "PP" || mov.IsNull("TSPerfezionato") == true)
				{
					MessageBox.Show("Selezionare un movimento PP perfezionato.", "Attenzione");
					return;
				}

				DialogResult r = MessageBox.Show("Vuoi annullare il movimento PP gia` perfezionato?", "Attenzione", MessageBoxButtons.YesNo);
				if (r == DialogResult.No)
					return;
			
				string ret;
				DataSet ds = MovPP_PerfezionamentoErrato(this.IdSessione, (string)mov["IdMovimentoBancario"], out ret);
				AggiornaDataSet(ds);
				if (ret.Length > 0)
					MessageBox.Show(ret, "Attenzione");
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void mnSB_SessioneBancaria_Cancella_Click(object sender, System.EventArgs e)
		{
			DialogResult r = MessageBox.Show(
				"Vuoi cancellare l'intera sessione bancaria?\n" +
				"\n" +
				"Attenzione questo comando ignora\n" +
				"1) se sono state gia` pubblicati le istruzioni di pagamento\n" +
				"2) se uno o piu' ordini di pagamento sono stati gia` eseguiti\n" +
				"3) se qualche movimento privato e` stato gia` perfezionato\n" +
				"4) se sono gia` conteggiati i movimenti di restituzione residui\n" +
				"\n" +
				"Questo comando porta il sistema esattamente al momento di quando si 'Termina' la sessione."
				, "Attenzione", MessageBoxButtons.YesNo);
			if (r == DialogResult.No)
				return;

			try
			{
				string msg = SessioneBancaria_Cancella(this.IdSessione);
				if (msg != string.Empty)
					MessageBox.Show(msg, "Attenzione");
				else
				{
					MessageBox.Show("Sessione bancaria cancellata.", "Attenzione");
					_SessioneAperta = false;
					AbilitaMaschera(_SessioneAperta, true);
				}
			}
			catch (CancelException)
			{
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		#endregion

	}

}
