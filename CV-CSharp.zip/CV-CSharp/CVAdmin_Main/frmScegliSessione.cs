using System;
using System.Drawing;
using System.Collections;
using System.Diagnostics;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmScegliSessione.
	/// </summary>
	public class frmScegliSessione : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnConferma;
		private System.Windows.Forms.Button btnChiudi;

		private System.Windows.Forms.DataGrid dgSessioni;
		private CurrencyManager _cmSessioni;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DataRow SelectedSessionRow
		{
			get 
			{
				if (_cmSessioni == null)
					return null;

				if (_cmSessioni.Count == 0) // numero di righe = 0
					return null;

				object current = _cmSessioni.Current;
				if (current == null)
					return null;

				if (_cmSessioni.Current.GetType() == typeof(DataRowView))
					return ((DataRowView)_cmSessioni.Current).Row; 
				return null;
			}
		}

		public frmScegliSessione(string rowFilter)
			: this()
		{
			if (_cmSessioni != null)
			{
				DataView dv = (DataView)_cmSessioni.List;
				// dv.RowFilter = "StatoSessione='Terminata' OR StatoSessione='Chiusa'";
				dv.RowFilter = rowFilter;
			}
		}

		public frmScegliSessione()
		{
			InitializeComponent();

			DataSet ds = GetListaSessioni();

			if (ds != null)
			{
				DataGridTableStyle dgStyle = new DataGridTableStyle();
				dgStyle.MappingName = "Sessioni"; 
				dgStyle.AllowSorting = true;

				DataGridTextBoxColumn dgc;

				dgc = new DataGridTextBoxColumn();
				dgc.HeaderText = "Titolo";
				dgc.MappingName = "Titolo";
				dgc.Width = 100;
				dgStyle.GridColumnStyles.Add(dgc);

				dgc = new DataGridTextBoxColumn();
				dgc.HeaderText = "Data apertura";
				dgc.MappingName = "DataOraApertura";
				dgc.Width = 100;
				dgc.Format = "g";
				dgStyle.GridColumnStyles.Add(dgc);

				dgc = new DataGridTextBoxColumn();
				dgc.HeaderText = "Data chiusura";
				dgc.MappingName = "DataOraChiusura";
				dgc.Width = 100;
				dgc.Format = "g";
				dgc.NullText = string.Empty;
				dgStyle.GridColumnStyles.Add(dgc);


				dgc = new DataGridTextBoxColumn();
				dgc.HeaderText = "Stato";
				dgc.MappingName = "StatoSessione";
				dgc.Width = 100;
				dgStyle.GridColumnStyles.Add(dgc);

				dgSessioni.TableStyles.Add(dgStyle);

				DataView dv = new DataView(ds.Tables["Sessioni"]);
				dv.AllowNew = false;
				dv.AllowDelete = false;
				dv.AllowEdit = false;

				dv.Sort = "DataOraApertura DESC";


				dgSessioni.DataSource = dv;


				Debug.Assert(this.BindingContext.Contains(dv));
				_cmSessioni = (CurrencyManager)this.BindingContext[dv];
			}
			else
			{
				dgSessioni.Enabled = false;
			}
		}


		static DataSet GetListaSessioni()
		{
			bool Cancelled = false;
			if (Cancelled)
			{
				CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni bl = new CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni();
				return bl.GetLst();
			}
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
					"CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni.GetLst");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmScegliSessione));
			this.btnConferma = new System.Windows.Forms.Button();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.dgSessioni = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dgSessioni)).BeginInit();
			this.SuspendLayout();
			// 
			// btnConferma
			// 
			this.btnConferma.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnConferma.Location = new System.Drawing.Point(362, 284);
			this.btnConferma.Name = "btnConferma";
			this.btnConferma.TabIndex = 1;
			this.btnConferma.Text = "C&onferma";
			this.btnConferma.Click += new System.EventHandler(this.btnConferma_Click);
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChiudi.Location = new System.Drawing.Point(441, 284);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 2;
			this.btnChiudi.Text = "&Chiudi";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// dgSessioni
			// 
			this.dgSessioni.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgSessioni.CaptionText = "Sessioni";
			this.dgSessioni.CaptionVisible = false;
			this.dgSessioni.DataMember = "";
			this.dgSessioni.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgSessioni.Location = new System.Drawing.Point(8, 8);
			this.dgSessioni.Name = "dgSessioni";
			this.dgSessioni.Size = new System.Drawing.Size(504, 264);
			this.dgSessioni.TabIndex = 4;
			this.dgSessioni.DoubleClick += new System.EventHandler(this.dgSessioni_DoubleClick);
			// 
			// frmScegliSessione
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(538, 311);
			this.Controls.Add(this.dgSessioni);
			this.Controls.Add(this.btnChiudi);
			this.Controls.Add(this.btnConferma);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(544, 104);
			this.Name = "frmScegliSessione";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Sessioni";
			((System.ComponentModel.ISupportInitialize)(this.dgSessioni)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			_cmSessioni = null;
			this.DialogResult = DialogResult.Cancel;
		}

		private void btnConferma_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
		}

		private void dgSessioni_DoubleClick(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
		}
	}
}
