using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using ExcelHelper;
using System.Text;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmGestioneCorrispettivi.
	/// </summary>
	public class frmGestioneCorrispettivi : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btCalcolaCorrispettivi;
		private System.Windows.Forms.Button btEsci;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private DataView	_dvSessioni			= null;
		private DataTable	_dtSessioni			= null;
		private System.Windows.Forms.DataGrid dgSessioni;
		private DataSet		_dsListaSessioni	= null;
		private System.Windows.Forms.CheckBox ckbTutte;
		private System.Windows.Forms.SaveFileDialog dlgEsportaXls;
		private string		filter = "" ;
//		private DataRow		_drSelectedSession	= null;

		public frmGestioneCorrispettivi()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Mapping delle colonne tra il DataTable delle Sessioni e le colonne
			// del DataGrid
			SetDataGridMapping();

			ckbTutte.Checked = false ;
			//filter = "StatoSessione = 'Chiusa' AND Isnull(DataCorrispettivo, 'NULL') = 'NULL'" ;
			filter = "StatoSessione = 'Chiusa' AND DataCorrispettivo Is Null" ;
		}

		private void frmGestioneCorrispettivi_Load(object sender, System.EventArgs e)
		{
			_dsListaSessioni = GetListaSessioni() ;
			
			BindDataGridDataSource(_dsListaSessioni);

			AbilitaBottoni();
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		private void BindDataGridDataSource(DataSet ds)
		{
			// Effettuo il DataBinding del DataSet delle Sessioni con il DataGrid
			if (ds != null)
			{
				_dtSessioni = ds.Tables[0];
				_dvSessioni = new DataView(_dtSessioni);
				_dvSessioni.AllowDelete	= false;
				_dvSessioni.AllowNew	= false;
				_dvSessioni.AllowEdit	= false;
				_dvSessioni.Sort        = "DataOraApertura";
				_dvSessioni.RowFilter	= filter ;

				dgSessioni.DataSource	= _dvSessioni;
				_dvSessioni.ListChanged  += new System.ComponentModel.ListChangedEventHandler(_dvSessioni_OnListChanged);
			}
		}

		private void SetDataGridMapping()
		{
			// Mapping delle colonne tra il DataTable delle Sessioni e le colonne
			// del DataGrid
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[3];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			dgCol[0].HeaderText = "Data/Ora Apertura Sessione";
			dgCol[0].MappingName = "DataOraApertura";
			dgCol[0].Width = 180;
			dgCol[0].Format = "g";

			dgCol[1].HeaderText = "Titolo Sessione";
			dgCol[1].MappingName = "Titolo";
			dgCol[1].Width = 300;

			dgCol[2].HeaderText = "Data Invio Report";
			dgCol[2].MappingName = "DataCorrispettivo";
			dgCol[2].NullText = "Non ancora inviato";
			dgCol[2].Width = 180;
			dgCol[2].Format = "g";

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Sessioni";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgSessioni.TableStyles.Add(dgStyle);
		}

		public int GetDataGridRowsNumber()
		{
			BindingManagerBase bmDataGrid = dgSessioni.BindingContext[dgSessioni.DataSource];
			return bmDataGrid.Count;
		}

		private int GetNumberRowsSelected()
		{
			int RowsSelected = 0;
			for (int i = 0; i < GetDataGridRowsNumber(); i++)
			{
				if (dgSessioni.IsSelected(i))
				{
					RowsSelected++;
				}
			}
			return RowsSelected;
		}

		private DataRow CurrentRow()
		{
			BindingManagerBase bm = dgSessioni.BindingContext[dgSessioni.DataSource];
			if (bm.Count == 0) // numero di righe = 0
				return null;
			DataRow dr = null;
			if (bm.Current.GetType() == typeof(DataRowView))
				dr = ((DataRowView)bm.Current).Row; 
			return dr;	
		}

		private void CreaFileExcel(DataSet dsRisultato)
		{
			DataRow[] dt = dsRisultato.Tables[0].Select("", "RagioneSociale, CodiceConto");

			this.Enabled = false;
			Application.DoEvents();
			this.Enabled = true;

			try
			{
				using (WaitCursor wc = new WaitCursor())
				{
					using (spApplication xlApp = new spApplication())
					{
						Excel.XlBordersIndex xlEdgeRight  = Excel.XlBordersIndex.xlEdgeRight;
						Excel.XlBordersIndex xlEdgeLeft   = Excel.XlBordersIndex.xlEdgeLeft;
						Excel.XlBordersIndex xlEdgeBottom = Excel.XlBordersIndex.xlEdgeBottom;
						Excel.XlBordersIndex xlEdgeTop    = Excel.XlBordersIndex.xlEdgeTop;

						Excel.XlHAlign xlHAlignGeneral    = Excel.XlHAlign.xlHAlignGeneral;

						string exportFileName = dlgEsportaXls.FileName;

						// xlApp.Visible = true;
						xlApp.SheetsInNewWorkbook = 1;

						spWorkbook xlBook = xlApp.Workbooks.Add();

						spWorksheet xlSheet = xlBook.Worksheets[1];
						xlSheet.Name = "Elenco Corrispettivi";

						// Titolo
						// --------------------------------------------
						xlSheet.Cells[1, 1].Characters.Font.Size = 11;
						xlSheet.Cells[1, 1].Characters.Font.Bold = true;
						xlSheet.Cells[1, 1].Value = "Elenco Corrispettivi";
						xlSheet.Cells.Range(xlSheet.Cells[1, 1], xlSheet.Cells[1, 5]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[1, 1], xlSheet.Cells[1, 5]).Merge();

						// Riga Intestazione
						// --------------------------------------------
						xlSheet.Cells.EntireRow[3].Characters.Font.Size = 10;
						xlSheet.Cells.EntireRow[3].Characters.Font.Bold = true;
    
						// Prima Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 6].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 6].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 1].Borders[xlEdgeLeft].LineStyle = 7;
						xlSheet.Cells[3, 1].Borders[xlEdgeLeft].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 6]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 6]).Merge();
						xlSheet.Cells[3, 1].Value = "Ragione Sociale";
    
						// Seconda Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 8].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 8].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 7], xlSheet.Cells[3, 8]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 7], xlSheet.Cells[3, 8]).Merge();
						xlSheet.Cells[3, 7].Value = "Codice Conto";
					    
						// Terza Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 12].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 12].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 9], xlSheet.Cells[3, 12]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 9], xlSheet.Cells[3, 12]).Merge();
						xlSheet.Cells[3, 9].Value = "Titolo Sessione";
					    
						// Quarta Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 14].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 14].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 13], xlSheet.Cells[3, 14]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 13], xlSheet.Cells[3, 14]).Merge();
						xlSheet.Cells[3, 13].Value = "Data/Ora Apertura";

						// Quinta Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 16].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 16].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 15], xlSheet.Cells[3, 16]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 15], xlSheet.Cells[3, 16]).Merge();
						xlSheet.Cells[3, 15].Value = "Qty Certificati";

						// Sesta Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 18].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 18].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 17], xlSheet.Cells[3, 18]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 17], xlSheet.Cells[3, 18]).Merge();
						xlSheet.Cells[3, 17].Value = "Qty Certificati Inadempienti";
					    
						// Settima Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 20].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 20].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 19], xlSheet.Cells[3, 20]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 19], xlSheet.Cells[3, 20]).Merge();
						xlSheet.Cells[3, 19].Value = "Corrispettivo";

						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 20]).Borders[xlEdgeBottom].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 20]).Borders[xlEdgeTop].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 20]).Borders[xlEdgeBottom].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 20]).Borders[xlEdgeTop].Weight = 3;
					    

						// RIGHE DATI
						int riga = 4;
						string CConto = "" ;
						decimal SubTotale = 0 ;
						foreach (DataRow row in dt)
						{
							xlSheet.Cells.EntireRow[riga].Characters.Font.Size = 8;
							xlSheet.Cells.EntireRow[riga].Characters.Font.Bold = false;

							if ((riga & 1) == 0)
							{
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.ColorIndex = 15;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.Pattern = Excel.XlPattern.xlPatternSolid;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.PatternColorIndex = Excel.XlPattern.xlPatternAutomatic;
							}
					        
							if ( CConto != row["CodiceConto"].ToString())
							{
								// riga del Totale
								if (riga != 4)
								{
									xlSheet.Cells.EntireRow[riga].Characters.Font.Size = 8;
									xlSheet.Cells.EntireRow[riga].Characters.Font.Bold = true;

									xlSheet.Cells[riga, 18].Borders[xlEdgeRight].LineStyle = 7;
									xlSheet.Cells[riga, 18].Borders[xlEdgeRight].Weight = 3;
									xlSheet.Cells.Range(xlSheet.Cells[riga, 17], xlSheet.Cells[riga, 18]).Merge();
									xlSheet.Cells[riga, 17].NumberFormat = "@";
									xlSheet.Cells[riga, 17].Value = "Totale" ;

									xlSheet.Cells[riga, 20].Borders[xlEdgeRight].LineStyle = 7;
									xlSheet.Cells[riga, 20].Borders[xlEdgeRight].Weight = 3;
									xlSheet.Cells.Range(xlSheet.Cells[riga, 19], xlSheet.Cells[riga, 20]).Merge();
									xlSheet.Cells[riga, 19].NumberFormat = "@";
									xlSheet.Cells[riga, 19].Value = Converter.DecimalToCurrencyString(SubTotale);
					    
									xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Borders[xlEdgeBottom].LineStyle = 7;
									xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Borders[xlEdgeBottom].Weight = 3;

									SubTotale = 0 ;
									riga++ ;
									xlSheet.Cells.EntireRow[riga].Characters.Font.Size = 8;
									xlSheet.Cells.EntireRow[riga].Characters.Font.Bold = false;
									if ((riga & 1) == 0)
									{
										xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.ColorIndex = 15;
										xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.Pattern = Excel.XlPattern.xlPatternSolid;
										xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.PatternColorIndex = Excel.XlPattern.xlPatternAutomatic;
									}
								}
								
								xlSheet.Cells[riga, 1].Borders[xlEdgeLeft].LineStyle = 7;
								xlSheet.Cells[riga, 1].Borders[xlEdgeLeft].Weight = 3;
								xlSheet.Cells[riga, 6].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 6].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 6]).Merge();
								xlSheet.Cells[riga, 1].NumberFormat = "@";
								xlSheet.Cells[riga, 1].Value = row["RagioneSociale"].ToString();
					        
								xlSheet.Cells[riga, 8].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 8].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 7], xlSheet.Cells[riga, 8]).Merge();
								xlSheet.Cells[riga, 7].NumberFormat = "@";
								xlSheet.Cells[riga, 7].Value = row["CodiceConto"].ToString();
					        
								xlSheet.Cells[riga, 12].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 12].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 9], xlSheet.Cells[riga, 12]).Merge();
								xlSheet.Cells[riga, 9].NumberFormat = "@";
								xlSheet.Cells[riga, 9].Value = row["Titolo"].ToString();
					        
								xlSheet.Cells[riga, 14].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 14].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 13], xlSheet.Cells[riga, 14]).Merge();
								xlSheet.Cells[riga, 13].NumberFormat = "@";
								xlSheet.Cells[riga, 13].Value = Converter.DateTimeToStringDateTime((DateTime)row["DataOraApertura"]);

								xlSheet.Cells[riga, 16].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 16].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 15], xlSheet.Cells[riga, 16]).Merge();
								xlSheet.Cells[riga, 15].NumberFormat = "@";
								xlSheet.Cells[riga, 15].Value = Converter.DecimalToIntegerString((decimal)row["QtyCertificati"]);

								xlSheet.Cells[riga, 18].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 18].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 17], xlSheet.Cells[riga, 18]).Merge();
								xlSheet.Cells[riga, 17].NumberFormat = "@";
								xlSheet.Cells[riga, 17].Value = Converter.DecimalToIntegerString((decimal)row["QtyCertificatiInadempienti"]);

								xlSheet.Cells[riga, 20].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 20].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 19], xlSheet.Cells[riga, 20]).Merge();
								xlSheet.Cells[riga, 19].NumberFormat = "@";
								xlSheet.Cells[riga, 19].Value = Converter.DecimalToCurrencyString((decimal)row["Corrispettivo"]);
								SubTotale += (decimal)row["Corrispettivo"] ;
					    
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Borders[xlEdgeBottom].LineStyle = 7;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Borders[xlEdgeBottom].Weight = 3;
							}
							else
							{
//								xlSheet.Cells[riga, 1].Borders[xlEdgeLeft].LineStyle = 7;
//								xlSheet.Cells[riga, 1].Borders[xlEdgeLeft].Weight = 3;
//								xlSheet.Cells[riga, 6].Borders[xlEdgeRight].LineStyle = 7;
//								xlSheet.Cells[riga, 6].Borders[xlEdgeRight].Weight = 3;
//								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 6]).Merge();
//								xlSheet.Cells[riga, 1].NumberFormat = "@";
//								xlSheet.Cells[riga, 1].Value = "";
					        
								xlSheet.Cells[riga, 8].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 8].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 7], xlSheet.Cells[riga, 8]).Merge();
								xlSheet.Cells[riga, 7].NumberFormat = "@";
								xlSheet.Cells[riga, 7].Value = "";
					        
								xlSheet.Cells[riga, 12].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 12].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 9], xlSheet.Cells[riga, 12]).Merge();
								xlSheet.Cells[riga, 9].NumberFormat = "@";
								xlSheet.Cells[riga, 9].Value = row["Titolo"].ToString();
					        
								xlSheet.Cells[riga, 14].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 14].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 13], xlSheet.Cells[riga, 14]).Merge();
								xlSheet.Cells[riga, 13].NumberFormat = "@";
								xlSheet.Cells[riga, 13].Value = Converter.DateTimeToStringDateTime((DateTime)row["DataOraApertura"]);

								xlSheet.Cells[riga, 16].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 16].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 15], xlSheet.Cells[riga, 16]).Merge();
								xlSheet.Cells[riga, 15].NumberFormat = "@";
								xlSheet.Cells[riga, 15].Value = Converter.DecimalToIntegerString((decimal)row["QtyCertificati"]);

								xlSheet.Cells[riga, 18].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 18].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 17], xlSheet.Cells[riga, 18]).Merge();
								xlSheet.Cells[riga, 17].NumberFormat = "@";
								xlSheet.Cells[riga, 17].Value = Converter.DecimalToIntegerString((decimal)row["QtyCertificatiInadempienti"]);

								xlSheet.Cells[riga, 20].Borders[xlEdgeRight].LineStyle = 7;
								xlSheet.Cells[riga, 20].Borders[xlEdgeRight].Weight = 3;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 19], xlSheet.Cells[riga, 20]).Merge();
								xlSheet.Cells[riga, 19].NumberFormat = "@";
								xlSheet.Cells[riga, 19].Value = Converter.DecimalToCurrencyString((decimal)row["Corrispettivo"]);
								SubTotale += (decimal)row["Corrispettivo"] ;

								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Borders[xlEdgeBottom].LineStyle = 7;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Borders[xlEdgeBottom].Weight = 3;
							}

							CConto = row["CodiceConto"].ToString() ;

							riga++ ;
						}

						// Visualizzo l'ultimo SubTotale
						xlSheet.Cells.EntireRow[riga].Characters.Font.Size = 8;
						xlSheet.Cells.EntireRow[riga].Characters.Font.Bold = true;

						if ((riga & 1) == 0)
						{
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.ColorIndex = 15;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.Pattern = Excel.XlPattern.xlPatternSolid;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Interior.PatternColorIndex = Excel.XlPattern.xlPatternAutomatic;
						}

						xlSheet.Cells[riga, 18].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[riga, 18].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[riga, 17], xlSheet.Cells[riga, 18]).Merge();
						xlSheet.Cells[riga, 17].NumberFormat = "@";
						xlSheet.Cells[riga, 17].Value = "Totale" ;

						xlSheet.Cells[riga, 20].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[riga, 20].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[riga, 19], xlSheet.Cells[riga, 20]).Merge();
						xlSheet.Cells[riga, 19].NumberFormat = "@";
						xlSheet.Cells[riga, 19].Value = Converter.DecimalToCurrencyString(SubTotale);
					    
						xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Borders[xlEdgeBottom].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 20]).Borders[xlEdgeBottom].Weight = 3;

						
						
						try { System.IO.File.Delete(exportFileName); } 
						catch (Exception) {} // eccezione se il file non esiste
						xlSheet.SaveAs(exportFileName);
				
						xlApp.Visible = true;
						//xlBook.Close();
						//xlApp.Quit();
					}
				}
				MessageBox.Show("Foglio Excel generato con successo", "Messaggio", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void AbilitaBottoni()
		{
			int dgRowNumber = 0;
			// Se esiste almeno una transazione nel DataGrid abilito i bottoni altrimenti
			// li disabilito
			dgRowNumber = GetDataGridRowsNumber();
			bool abilita = !(dgRowNumber == 0);
			AbilitaBottoni(abilita);
		}

		private void AbilitaBottoni(bool enable)
		{
			btCalcolaCorrispettivi.Enabled = enable;
		}

		private DataSet GetListaSessioni()
		{
			bool Cancelled = false;
			if (Cancelled)
			{
				return new CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni().GetLst();
			}
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni().GetLst");
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}

		private DataSet GetCorrispettivi(string[] IdSessioni)
		{
			bool Cancelled = true;  // TODO LEO
			if (Cancelled)
			{
				CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni p;
				p = new CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni();
				frmLogin.AddLoginInfo(p);
				return p.CalcolaCorrispettivi(IdSessioni);
			}
			else
			{
				object ret = frmAsyncWait.DoSoapCall(out Cancelled, "CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni().CalcolaCorrispettivi", IdSessioni);
				if (Cancelled)
					return null;
				return (DataSet)ret;
			}
		}

		private spRange Cell(spWorksheet s, int r, int c)
		{
			return s.Cells[r,c];
		}
		private spRange Cell(spWorksheet s, int r1, int c1, int r2, int c2)
		{
			return s.Cells.Range(s.Cells[r1, c1], s.Cells[r2,c2]);
		}

		string BuildSheetName(string SheetName)
		{
			StringBuilder sb = new StringBuilder();

			for (int i = 0; i < SheetName.Length; i++)
			{
				char ch = SheetName[i];

				if (ch == ':' || ch == '\\' || ch == '/' || ch == '?' ||  
					ch == '*' || ch == '['  || ch == ']' )
					sb.Append("_");
				else
					sb.Append(ch);
			}
			return sb.ToString();//ToString OK
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmGestioneCorrispettivi));
			this.btCalcolaCorrispettivi = new System.Windows.Forms.Button();
			this.btEsci = new System.Windows.Forms.Button();
			this.dgSessioni = new System.Windows.Forms.DataGrid();
			this.ckbTutte = new System.Windows.Forms.CheckBox();
			this.dlgEsportaXls = new System.Windows.Forms.SaveFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.dgSessioni)).BeginInit();
			this.SuspendLayout();
			// 
			// btCalcolaCorrispettivi
			// 
			this.btCalcolaCorrispettivi.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btCalcolaCorrispettivi.Location = new System.Drawing.Point(560, 368);
			this.btCalcolaCorrispettivi.Name = "btCalcolaCorrispettivi";
			this.btCalcolaCorrispettivi.Size = new System.Drawing.Size(120, 24);
			this.btCalcolaCorrispettivi.TabIndex = 3;
			this.btCalcolaCorrispettivi.Text = "Calcola Corrispettivi";
			this.btCalcolaCorrispettivi.Click += new System.EventHandler(this.btCalcolaCorrispettivi_Click);
			// 
			// btEsci
			// 
			this.btEsci.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btEsci.Location = new System.Drawing.Point(688, 368);
			this.btEsci.Name = "btEsci";
			this.btEsci.Size = new System.Drawing.Size(96, 24);
			this.btEsci.TabIndex = 4;
			this.btEsci.Text = "&Chiudi";
			this.btEsci.Click += new System.EventHandler(this.btEsci_Click);
			// 
			// dgSessioni
			// 
			this.dgSessioni.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.dgSessioni.CaptionText = "Risultato Ricerca - Sessioni";
			this.dgSessioni.DataMember = "";
			this.dgSessioni.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgSessioni.Location = new System.Drawing.Point(8, 8);
			this.dgSessioni.Name = "dgSessioni";
			this.dgSessioni.Size = new System.Drawing.Size(800, 352);
			this.dgSessioni.TabIndex = 5;
			// 
			// ckbTutte
			// 
			this.ckbTutte.Location = new System.Drawing.Point(8, 368);
			this.ckbTutte.Name = "ckbTutte";
			this.ckbTutte.Size = new System.Drawing.Size(160, 24);
			this.ckbTutte.TabIndex = 6;
			this.ckbTutte.Text = "Visualizza tutte le Sessioni";
			this.ckbTutte.CheckedChanged += new System.EventHandler(this.ckbTutte_CheckedChanged);
			// 
			// dlgEsportaXls
			// 
			this.dlgEsportaXls.Filter = "Xls file (*.xls)|*.xls|All files|*.*";
			// 
			// frmGestioneCorrispettivi
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(816, 397);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.ckbTutte,
																		  this.dgSessioni,
																		  this.btEsci,
																		  this.btCalcolaCorrispettivi});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmGestioneCorrispettivi";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Gestione Corrispettivi";
			this.Load += new System.EventHandler(this.frmGestioneCorrispettivi_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgSessioni)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void btEsci_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void _dvSessioni_OnListChanged(object sender, System.ComponentModel.ListChangedEventArgs args)
		{
			int dgRowNumber = 0;
			// Se esiste almeno una transazione nel DataGrid abilito i bottoni altrimenti
			// li disabilito
			dgRowNumber = GetDataGridRowsNumber();
			bool abilita = !(dgRowNumber == 0);
			AbilitaBottoni(abilita);
			if (dgRowNumber != 0)
			{
				// N.B. E' importante questa riga per evitare un problema che esiste quando il 
				// data source del DataGrid e' un DataView.
				// Filtrando i dati con il DataView il bookmark non viene aggiornato automaticamente
				// rimanendo settato all'ultimo valore selezionato.
				// Se il numero di tale riga e' superiore al numero di righe visualizzato
				// dal DataGrid viene lanciata un eccezione quando si da il focus al DataGrid.
				dgSessioni.CurrentRowIndex = 0;
			}
		}

		private void ckbTutte_CheckedChanged(object sender, System.EventArgs e)
		{
			if (ckbTutte.Checked)
			{
				filter = "StatoSessione = 'Chiusa'" ;
			}
			else
			{
				filter = "StatoSessione = 'Chiusa' AND DataCorrispettivo Is Null" ;
			}

			BindDataGridDataSource(_dsListaSessioni);

			AbilitaBottoni();
		}

		private void btCalcolaCorrispettivi_Click(object sender, System.EventArgs e)
		{
			int j = 0;
			int rowsel = GetNumberRowsSelected();

			if (rowsel == 0)
			{
				MessageBox.Show("Non ci sono sessioni selezionate nella griglia", 
					"Attenzione", 
					MessageBoxButtons.OK, 
					MessageBoxIcon.Information);
				return;
			}

			Cursor = Cursors.WaitCursor;

			string[] IdSessioni = new string[rowsel] ;

			// Disabilito l'invio degli eventi che ridisegnano il DataGrid
			this.dgSessioni.SuspendLayout();

			BindingManagerBase bm = dgSessioni.BindingContext[dgSessioni.DataSource];
			for (int i = 0; i < GetDataGridRowsNumber(); i++)
			{
				if (dgSessioni.IsSelected(i))
				{
					bm.Position = i;
					DataRow dataRow = CurrentRow();
					IdSessioni[j] = dataRow["IdSessione"].ToString() ;
					j++ ;
				}
			}

			dlgEsportaXls.InitialDirectory = UtilityEnvironment.CommonAppDir;
			if (dlgEsportaXls.ShowDialog() != DialogResult.OK)
			{
				Cursor = Cursors.Arrow;
				return;
			}

			DataSet dsRisultato ;
			dsRisultato = GetCorrispettivi(IdSessioni);
			if (dsRisultato == null)
			{
				Cursor = Cursors.Arrow;
				// Abilito l'invio degli eventi che ridisegnano il DataGrid
				this.dgSessioni.ResumeLayout();
				MessageBox.Show("In queste/a sessione/i non ci sono transazioni valide!", 
					"Attenzione", 
					MessageBoxButtons.OK, 
					MessageBoxIcon.Information);
				return ;
			}

			// Genero il file Excel
			CreaFileExcel(dsRisultato);

			// Abilito l'invio degli eventi che ridisegnano il DataGrid
			this.dgSessioni.ResumeLayout();

			_dsListaSessioni = GetListaSessioni() ;
			
			BindDataGridDataSource(_dsListaSessioni);

			AbilitaBottoni();

			Cursor = Cursors.Arrow;
		}

	}
}
