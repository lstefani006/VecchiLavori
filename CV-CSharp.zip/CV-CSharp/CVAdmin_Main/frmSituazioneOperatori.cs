using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmSituazioneOperatori.
	/// </summary>
	public class frmSituazioneOperatori : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblOperatore;
		private System.Windows.Forms.ComboBox cbOperatori;
		private System.Windows.Forms.GroupBox gbCVAcquistabili;
		private System.Windows.Forms.GroupBox gbCVVendibili;
		private System.Windows.Forms.DataGrid dgCVVendibili;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.Label lblImportoDeposito;
		private System.Windows.Forms.Label lblPrezzoConvUtente;
		private System.Windows.Forms.Label lblQtyMAXAcquistabile;
		private System.Windows.Forms.Label lblQtyImpegnata;
		private System.Windows.Forms.Label lblQtyDisponibile;
		private System.Windows.Forms.TextBox tbImportoDeposito;
		private System.Windows.Forms.TextBox tbQtyMAXAcquistabile;
		private System.Windows.Forms.TextBox tbQtyImpegnata;
		private System.Windows.Forms.TextBox tbQtyDisponibile;



		private DataRow _drSessioneCorrente = null;
		private DataSet _dsSocieta = null;
		private DataSet _dsBankAccount = null;
		private DataSet _dsCertificates = null;
		private DataSet _dsSocietaWithRelations = null;
		private System.Windows.Forms.TextBox tbPrezzoConvUtenteMw;
		private System.Windows.Forms.ComboBox cbCodiceConto;
		private System.Windows.Forms.Label lblCodiceConto;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSituazioneOperatori()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		public frmSituazioneOperatori(DataRow dr)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_drSessioneCorrente = dr;

			if (_drSessioneCorrente != null)
			{
				// Cambio il titolo della form in funzione della Sessione selezionata
				this.Text += " - Titolo Sessione: \"" + (string)_drSessioneCorrente["Titolo"] + "\"";
			}
			else
			{
				// Disabilito tutti i componenti
				DisabilitaComponenti();
			}

			_dsSocietaWithRelations = new DataSet();

			// Recupero l'ID della sessione selezionata
			string IdSessioneCorrente = (string)_drSessioneCorrente["IdSessione"];

			// Recupero la lista delle Societa' e ne faccio il bindign sulla 
			// ComboBox
			_dsSocieta = GetListaOperatori();
			if (_dsSocieta == null)
			{
				DisabilitaComponenti();
			}
			// Recupero la lista degli Acconti bancari di tutte le societa'
			// coinvolte nella sessione corrente
			_dsBankAccount = GetBankAccounts(IdSessioneCorrente);
			if (_dsBankAccount == null)
			{
				DisabilitaComponenti();
			}

			// Recupero la lista delle quantita' dei certificati di tutte le societa'
			// coinvolte nella sessione corrente
			_dsCertificates = GetGertificates(IdSessioneCorrente);
			if (_dsCertificates == null)
			{
				DisabilitaComponenti();
			}

			// Creo le relazioni tra le tabelle recuperate dal Database
			if (!BuildTablesRelations())
			{
				DisabilitaComponenti();
			}

			SetComponentDataBinding();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSituazioneOperatori));
			this.lblOperatore = new System.Windows.Forms.Label();
			this.cbOperatori = new System.Windows.Forms.ComboBox();
			this.gbCVAcquistabili = new System.Windows.Forms.GroupBox();
			this.tbQtyDisponibile = new System.Windows.Forms.TextBox();
			this.tbQtyImpegnata = new System.Windows.Forms.TextBox();
			this.tbQtyMAXAcquistabile = new System.Windows.Forms.TextBox();
			this.tbPrezzoConvUtenteMw = new System.Windows.Forms.TextBox();
			this.tbImportoDeposito = new System.Windows.Forms.TextBox();
			this.lblQtyDisponibile = new System.Windows.Forms.Label();
			this.lblQtyImpegnata = new System.Windows.Forms.Label();
			this.lblQtyMAXAcquistabile = new System.Windows.Forms.Label();
			this.lblPrezzoConvUtente = new System.Windows.Forms.Label();
			this.lblImportoDeposito = new System.Windows.Forms.Label();
			this.gbCVVendibili = new System.Windows.Forms.GroupBox();
			this.dgCVVendibili = new System.Windows.Forms.DataGrid();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.cbCodiceConto = new System.Windows.Forms.ComboBox();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.gbCVAcquistabili.SuspendLayout();
			this.gbCVVendibili.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgCVVendibili)).BeginInit();
			this.SuspendLayout();
			// 
			// lblOperatore
			// 
			this.lblOperatore.Location = new System.Drawing.Point(4, 8);
			this.lblOperatore.Name = "lblOperatore";
			this.lblOperatore.Size = new System.Drawing.Size(92, 16);
			this.lblOperatore.TabIndex = 0;
			this.lblOperatore.Text = "Ragione Sociale:";
			// 
			// cbOperatori
			// 
			this.cbOperatori.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.cbOperatori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbOperatori.Location = new System.Drawing.Point(96, 8);
			this.cbOperatori.Name = "cbOperatori";
			this.cbOperatori.Size = new System.Drawing.Size(464, 21);
			this.cbOperatori.TabIndex = 1;
			// 
			// gbCVAcquistabili
			// 
			this.gbCVAcquistabili.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.gbCVAcquistabili.Controls.AddRange(new System.Windows.Forms.Control[] {
																						   this.tbQtyDisponibile,
																						   this.tbQtyImpegnata,
																						   this.tbQtyMAXAcquistabile,
																						   this.tbPrezzoConvUtenteMw,
																						   this.tbImportoDeposito,
																						   this.lblQtyDisponibile,
																						   this.lblQtyImpegnata,
																						   this.lblQtyMAXAcquistabile,
																						   this.lblPrezzoConvUtente,
																						   this.lblImportoDeposito});
			this.gbCVAcquistabili.Location = new System.Drawing.Point(4, 56);
			this.gbCVAcquistabili.Name = "gbCVAcquistabili";
			this.gbCVAcquistabili.Size = new System.Drawing.Size(560, 152);
			this.gbCVAcquistabili.TabIndex = 2;
			this.gbCVAcquistabili.TabStop = false;
			this.gbCVAcquistabili.Text = " Certificati Verdi Acquistabili";
			// 
			// tbQtyDisponibile
			// 
			this.tbQtyDisponibile.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbQtyDisponibile.Location = new System.Drawing.Point(176, 124);
			this.tbQtyDisponibile.Name = "tbQtyDisponibile";
			this.tbQtyDisponibile.ReadOnly = true;
			this.tbQtyDisponibile.Size = new System.Drawing.Size(184, 20);
			this.tbQtyDisponibile.TabIndex = 9;
			this.tbQtyDisponibile.TabStop = false;
			this.tbQtyDisponibile.Text = "";
			// 
			// tbQtyImpegnata
			// 
			this.tbQtyImpegnata.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbQtyImpegnata.Location = new System.Drawing.Point(176, 98);
			this.tbQtyImpegnata.Name = "tbQtyImpegnata";
			this.tbQtyImpegnata.ReadOnly = true;
			this.tbQtyImpegnata.Size = new System.Drawing.Size(184, 20);
			this.tbQtyImpegnata.TabIndex = 7;
			this.tbQtyImpegnata.TabStop = false;
			this.tbQtyImpegnata.Text = "";
			// 
			// tbQtyMAXAcquistabile
			// 
			this.tbQtyMAXAcquistabile.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbQtyMAXAcquistabile.Location = new System.Drawing.Point(176, 72);
			this.tbQtyMAXAcquistabile.Name = "tbQtyMAXAcquistabile";
			this.tbQtyMAXAcquistabile.ReadOnly = true;
			this.tbQtyMAXAcquistabile.Size = new System.Drawing.Size(184, 20);
			this.tbQtyMAXAcquistabile.TabIndex = 5;
			this.tbQtyMAXAcquistabile.TabStop = false;
			this.tbQtyMAXAcquistabile.Text = "";
			// 
			// tbPrezzoConvUtenteMw
			// 
			this.tbPrezzoConvUtenteMw.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbPrezzoConvUtenteMw.Location = new System.Drawing.Point(176, 46);
			this.tbPrezzoConvUtenteMw.Name = "tbPrezzoConvUtenteMw";
			this.tbPrezzoConvUtenteMw.ReadOnly = true;
			this.tbPrezzoConvUtenteMw.Size = new System.Drawing.Size(184, 20);
			this.tbPrezzoConvUtenteMw.TabIndex = 3;
			this.tbPrezzoConvUtenteMw.TabStop = false;
			this.tbPrezzoConvUtenteMw.Text = "";
			// 
			// tbImportoDeposito
			// 
			this.tbImportoDeposito.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbImportoDeposito.Location = new System.Drawing.Point(176, 19);
			this.tbImportoDeposito.Name = "tbImportoDeposito";
			this.tbImportoDeposito.ReadOnly = true;
			this.tbImportoDeposito.Size = new System.Drawing.Size(184, 20);
			this.tbImportoDeposito.TabIndex = 1;
			this.tbImportoDeposito.TabStop = false;
			this.tbImportoDeposito.Text = "";
			// 
			// lblQtyDisponibile
			// 
			this.lblQtyDisponibile.Location = new System.Drawing.Point(8, 126);
			this.lblQtyDisponibile.Name = "lblQtyDisponibile";
			this.lblQtyDisponibile.Size = new System.Drawing.Size(108, 16);
			this.lblQtyDisponibile.TabIndex = 8;
			this.lblQtyDisponibile.Text = "Quantit� Disponibile";
			// 
			// lblQtyImpegnata
			// 
			this.lblQtyImpegnata.Location = new System.Drawing.Point(8, 100);
			this.lblQtyImpegnata.Name = "lblQtyImpegnata";
			this.lblQtyImpegnata.Size = new System.Drawing.Size(112, 16);
			this.lblQtyImpegnata.TabIndex = 6;
			this.lblQtyImpegnata.Text = "Quantit� Impegnata";
			// 
			// lblQtyMAXAcquistabile
			// 
			this.lblQtyMAXAcquistabile.Location = new System.Drawing.Point(8, 74);
			this.lblQtyMAXAcquistabile.Name = "lblQtyMAXAcquistabile";
			this.lblQtyMAXAcquistabile.Size = new System.Drawing.Size(160, 16);
			this.lblQtyMAXAcquistabile.TabIndex = 4;
			this.lblQtyMAXAcquistabile.Text = "Quantit� massima acquistabile";
			// 
			// lblPrezzoConvUtente
			// 
			this.lblPrezzoConvUtente.Location = new System.Drawing.Point(8, 48);
			this.lblPrezzoConvUtente.Name = "lblPrezzoConvUtente";
			this.lblPrezzoConvUtente.Size = new System.Drawing.Size(172, 16);
			this.lblPrezzoConvUtente.TabIndex = 2;
			this.lblPrezzoConvUtente.Text = "Prezzo convenzionale Utente Mw";
			// 
			// lblImportoDeposito
			// 
			this.lblImportoDeposito.Location = new System.Drawing.Point(8, 21);
			this.lblImportoDeposito.Name = "lblImportoDeposito";
			this.lblImportoDeposito.Size = new System.Drawing.Size(168, 17);
			this.lblImportoDeposito.TabIndex = 0;
			this.lblImportoDeposito.Text = "Importo deposito in conto prezzo";
			// 
			// gbCVVendibili
			// 
			this.gbCVVendibili.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.gbCVVendibili.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.dgCVVendibili});
			this.gbCVVendibili.Location = new System.Drawing.Point(4, 216);
			this.gbCVVendibili.Name = "gbCVVendibili";
			this.gbCVVendibili.Size = new System.Drawing.Size(560, 168);
			this.gbCVVendibili.TabIndex = 4;
			this.gbCVVendibili.TabStop = false;
			this.gbCVVendibili.Text = " Certificati Verdi Vendibili";
			// 
			// dgCVVendibili
			// 
			this.dgCVVendibili.AllowNavigation = false;
			this.dgCVVendibili.AllowSorting = false;
			this.dgCVVendibili.DataMember = "";
			this.dgCVVendibili.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgCVVendibili.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgCVVendibili.Location = new System.Drawing.Point(3, 16);
			this.dgCVVendibili.Name = "dgCVVendibili";
			this.dgCVVendibili.ReadOnly = true;
			this.dgCVVendibili.Size = new System.Drawing.Size(554, 149);
			this.dgCVVendibili.TabIndex = 0;
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnChiudi.Location = new System.Drawing.Point(468, 388);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 5;
			this.btnChiudi.Text = "&Chiudi";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// cbCodiceConto
			// 
			this.cbCodiceConto.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.cbCodiceConto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCodiceConto.Location = new System.Drawing.Point(96, 32);
			this.cbCodiceConto.Name = "cbCodiceConto";
			this.cbCodiceConto.Size = new System.Drawing.Size(464, 21);
			this.cbCodiceConto.TabIndex = 6;
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Location = new System.Drawing.Point(4, 32);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(92, 16);
			this.lblCodiceConto.TabIndex = 7;
			this.lblCodiceConto.Text = "Codice Conto:";
			// 
			// frmSituazioneOperatori
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(564, 429);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cbCodiceConto,
																		  this.btnChiudi,
																		  this.gbCVVendibili,
																		  this.gbCVAcquistabili,
																		  this.cbOperatori,
																		  this.lblOperatore,
																		  this.lblCodiceConto});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(380, 436);
			this.Name = "frmSituazioneOperatori";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Situazione Operatori";
			this.gbCVAcquistabili.ResumeLayout(false);
			this.gbCVVendibili.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgCVVendibili)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void DisabilitaComponenti()
		{
			cbOperatori.Enabled = false;
			gbCVAcquistabili.Enabled = false;
			gbCVVendibili.Enabled  = false;
			// Il tasto chiudi deve essere abilitato per permettermi di uscire
			// dalla Form
			btnChiudi.Enabled = true;
		}

		private void Chiudi()
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.Chiudi();
		}

		private bool BuildTablesRelations()
		{
			DataTable dtSocieta = null;
			DataTable dtBankAccount = null;
			DataTable dtCertificate = null;
			try
			{
				// Recupero le tabelle su cui voglio creare le relazioni
				if (_dsSocieta != null)
				{
					dtSocieta = _dsSocieta.Tables[0].Copy();
				}
				else
				{
					return false;
				}

				if (_dsBankAccount != null)
				{
					dtBankAccount = _dsBankAccount.Tables[0].Copy();
				}
				else
				{
					return false;
				}

				if (_dsCertificates != null)
				{
					dtCertificate = _dsCertificates.Tables[0].Copy();
				}
				else
				{
					return false;
				}

				// Aggiungo le tabelle al DataSet che conterra' le tabelle
				// con tutte le relazioni
				if (_dsSocietaWithRelations == null)
					return false;

				_dsSocietaWithRelations.Tables.Add(dtSocieta);
				_dsSocietaWithRelations.Tables.Add(dtBankAccount);
				_dsSocietaWithRelations.Tables.Add(dtCertificate);
			
				// Creo la relazione tra la tabella "Societa" e la tabella "BankAccount"
				DataColumn idsocietaCol = dtSocieta.Columns["IdSocieta"];
				DataColumn bankAccountCol = dtBankAccount.Columns["IdSocieta"];
				DataRelation relSocietaBankAccount = new DataRelation("relSocietaBankAccount", 
					idsocietaCol, 
					bankAccountCol);
				_dsSocietaWithRelations.Relations.Add(relSocietaBankAccount);
				
				// Creo la relazione tra la tabella "Societa" e la tabella "Certificate"
				DataColumn societaCol = dtSocieta.Columns["IdSocieta"];
				DataColumn certificatesCol = dtCertificate.Columns["IdSocieta"];
				DataRelation relSocietaCertificate = new DataRelation("relSocietaCertificate", 
					societaCol, 
					certificatesCol);
				_dsSocietaWithRelations.Relations.Add(relSocietaCertificate);

				return true;
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message, "Errore");
				return false;
			}
		}


		private void SetComponentDataBinding()
		{
			DataTable dtSocieta = _dsSocietaWithRelations.Tables["Societa"];
			Binding bnd = null;

			// Data Binding della tabella "Societa" con la ComboBox della RagioneSociale
			cbOperatori.DataSource = dtSocieta;
			cbOperatori.DisplayMember = "RagioneSociale";
			cbOperatori.ValueMember = "IdSocieta";

			// Data Binding della tabella "Societa" con la ComboBox del CodiceConto
			cbCodiceConto.DataSource = dtSocieta;
			cbCodiceConto.DisplayMember = "CodiceConto";
			cbCodiceConto.ValueMember = "IdSocieta";

			// Data Binding della tabella "Budget" con la EditBox contenente l'Importo 
			bnd = tbImportoDeposito.DataBindings.Add("Text", dtSocieta, "relSocietaBankAccount.Importo");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
	
			bnd = tbPrezzoConvUtenteMw.DataBindings.Add("Text", dtSocieta, "relSocietaBankAccount.PrezzoConvenzionaleUtenteMw");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);

			bnd = tbQtyMAXAcquistabile.DataBindings.Add("Text", dtSocieta, "relSocietaBankAccount.QtyMax");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToIntegerString);
			bnd = tbQtyImpegnata.DataBindings.Add("Text", dtSocieta, "relSocietaBankAccount.QtyImpegnata");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToIntegerString);
			bnd = tbQtyDisponibile.DataBindings.Add("Text", dtSocieta, "relSocietaBankAccount.QtyDisponibile");
			bnd.Format += new ConvertEventHandler(Converter.DecimalToIntegerString);

			// DataBinding della tabella "Certificate" con il DataGrid
			SetDatagridMapping();
			dgCVVendibili.DataSource = dtSocieta;
			dgCVVendibili.DataMember = "relSocietaCertificate";
		}


		#region Chiamate ai Web Services

		private DataSet GetListaOperatori()
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.GetLst",
				"");

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		private DataSet GetBankAccounts(string IdSessione)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.GetBankAccount",
				IdSessione);

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		private DataSet GetGertificates(string IdSessione)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.GetCertificates",
				IdSessione);

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		#endregion

		private void DecimalToCurrencyString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(string))
				return;

			Binding bng = sender as Binding;
			if (bng == null)
				cevent.Value = "";
			else
			{
				decimal d = ((decimal) cevent.Value);
				if (d >= 0m)
					cevent.Value = Converter.DecimalToCurrencyString(d);
				else
					cevent.Value = "";
			}
		}

		private void SetDatagridMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[4];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();

			int index = 0;
			dgCol[index].HeaderText = "Anno Riferimento";
			dgCol[index].MappingName = "AnnoRiferimento";
			dgCol[index].Width = 110;

			index++;
			dgCol[index].HeaderText = "Quantit� Totale";
			dgCol[index].MappingName = "Qty";
			dgCol[index].Width = 110;

			index++;
			dgCol[index].HeaderText = "Quantit� Impegnata";
			dgCol[index].MappingName = "QtyImpegnata";
			dgCol[index].Width = 110;

			index++;
			dgCol[index].HeaderText = "Quantit� Disponibile";
			dgCol[index].MappingName = "QtyDisponibile";
			dgCol[index].Width = 110;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "Certificate";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgCVVendibili.TableStyles.Add(dgStyle);
		}

	}
}
