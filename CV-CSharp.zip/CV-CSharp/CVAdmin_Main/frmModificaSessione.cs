using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Xml;
using System.Globalization;
using System.Web.Services.Protocols;
using ExcelHelper;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmModificaSessione.
	/// </summary>
	public class frmModificaSessione : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.GroupBox gbSessione;
		private System.Windows.Forms.Label lblAnnoSucc;
		private System.Windows.Forms.Label lblAnnoCorr;
		private System.Windows.Forms.Label lblAnnoPrec;
		private System.Windows.Forms.DateTimePicker dtpDataChiusura;
		private System.Windows.Forms.DateTimePicker dtpDataApertura;
		private System.Windows.Forms.TextBox txtTitoloSessione;
		private System.Windows.Forms.Label lblDataOraChiusura;
		private System.Windows.Forms.Label lblPrezzoConvenzionale;
		private System.Windows.Forms.Label lblDataOraApertura;
		private System.Windows.Forms.Label lblTitoloSessione;
		private System.Windows.Forms.ComboBox cbStatoSessione;
		private System.Windows.Forms.Label lblStatoSessione;
		private System.Windows.Forms.Button btnImportXML;
		private System.Windows.Forms.Button btnGeneraFileXML;
		private System.Windows.Forms.Button btnModifica;
		private System.Windows.Forms.Button btnChiudi;
		
		private System.Windows.Forms.TextBox edtPrezzoConvenzionale;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoSucc;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoCorr;
		private System.Windows.Forms.TextBox edtPrezzoRifAnnoPrec;
		private System.Windows.Forms.CheckBox ckPrezzoRifAnnoPrec;
		private System.Windows.Forms.Button btnInvioXMLalGRTN;

		protected DataSet _ds;
		protected DataRow _dr;
		private System.Windows.Forms.SaveFileDialog dlgSaveGeneraFileXmlBanca;
		private System.Windows.Forms.TextBox edtPrezziRiferimento;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox cbAnniRiferimento;
		BindingManagerBase _bmgr;

		internal class cbBind
		{
			public cbBind(string s) { _s = s; }
			public string Name { get { return _s; } }
			string _s;
		}


		public frmModificaSessione()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		public frmModificaSessione(DataRow dr)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			ckPrezzoRifAnnoPrec.Checked = true;


			_dr = dr;
			_ds = _dr.Table.DataSet;

			Debug.Assert(_dr.Table.TableName == "Sessioni");


			_bmgr = this.BindingContext[_ds, "Sessioni"];
			for (int rr = 0; rr < dr.Table.Rows.Count; ++rr)
				if (dr.Table.Rows[rr] == _dr)
					_bmgr.Position = rr;

			Debug.Assert(_dr == _ds.Tables["Sessioni"].Rows[_bmgr.Position]);

			Binding bnd;


			bnd = txtTitoloSessione.DataBindings.Add("Text", _ds, "Sessioni.Titolo");
			bnd.Parse  += new ConvertEventHandler(TitoloStringToString);

			dtpDataApertura.DataBindings.Add("Value", _ds, "Sessioni.DataOraApertura");
			dtpDataChiusura.DataBindings.Add("Value", _ds, "Sessioni.DataOraChiusura");

			// formattazione PrezzoConvenzionale
			bnd = edtPrezzoConvenzionale.DataBindings.Add("Text", _ds, "Sessioni.PrezzoConvenzionale");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(CurrencyStringToDecimal);

			bnd = edtPrezzoRifAnnoPrec.DataBindings.Add("Text", _ds, "Sessioni.PrezzoRiferimentoAnnoPrec");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(CurrencyStringToDecimal);

			bnd = edtPrezzoRifAnnoCorr.DataBindings.Add("Text", _ds, "Sessioni.PrezzoRiferimentoAnnoCorr");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(CurrencyStringToDecimal);

			bnd = edtPrezzoRifAnnoSucc.DataBindings.Add("Text", _ds, "Sessioni.PrezzoRiferimentoAnnoSucc");
			bnd.Format += new ConvertEventHandler(DecimalToCurrencyString);
			bnd.Parse  += new ConvertEventHandler(CurrencyStringToDecimal);

			// faccio il bind di una cb su di una lista con il valore selezionato preso dalla
			// nostra riga corrente
			cbStatoSessione.CausesValidation = true;
			cbBind [] cbList = 
			{ 
				new cbBind("In Attesa"),
				new cbBind("Predisposta"),
				new cbBind("Aperta"),
				new cbBind("Sospesa"),
				new cbBind("Terminata"),
				new cbBind("Chiusa")
			};
			cbStatoSessione.DisplayMember = "Name"; // il valore visualizzato e il valore della chiave
			cbStatoSessione.ValueMember   = "Name"; // sono gli stessi
			cbStatoSessione.DataSource = cbList;
			cbStatoSessione.DataBindings.Add("SelectedValue", _ds, "Sessioni.StatoSessione");

			btnGeneraFileXML.Enabled = false;
			btnImportXML.Enabled = false;
			btnInvioXMLalGRTN.Enabled = false;

			switch ((string)_dr["StatoSessione"])
			{
			case "In Attesa":
				btnImportXML.Enabled = true;
				break;

			case "Terminata":
				btnInvioXMLalGRTN.Enabled = true;
				btnGeneraFileXML.Enabled = true;
				break;

			default:
				break;
			}

			if ((decimal)_dr["PrezzoRiferimentoAnnoPrec"] < 0m)
				ckPrezzoRifAnnoPrec.Checked = false;
			else
				ckPrezzoRifAnnoPrec.Checked = true;

			int AnnoMin = 0 ;
			int AnnoMax = 0 ;
			DateTime dt = DateTime.Now ;
			bool ris = ContrattaCVAnnoMin(dt.Month, out AnnoMin, out AnnoMax);
			if (ris == false)
				AnnoMin += 1;
			for (int i=AnnoMin;i<=AnnoMax;i++)
			{
				if ((i != dt.Year) && (i != (dt.Year - 1)) && (i != (dt.Year + 1)))
				{
					cbAnniRiferimento.Items.Add(i.ToString());
				}
			}
			if ((AnnoMin >=  (dt.Year - 1)) && (AnnoMax <= (dt.Year + 1)))
			{
				cbAnniRiferimento.Text = "" ;
				cbAnniRiferimento.Enabled = false ;
				edtPrezziRiferimento.Enabled = false ;
			}
			else
			{
				cbAnniRiferimento.Enabled = true ;
				edtPrezziRiferimento.Enabled = true ;
				cbAnniRiferimento.SelectedIndex = 0 ;
			}
		}
			
		private bool ContrattaCVAnnoMin(int month, out int AnnoMin, out int AnnoMax)
		{
			try
			{
				CVAdminWSBLSessione.BLSessione ws = new CVAdminWSBLSessione.BLSessione();
				frmLogin.AddLoginInfo(ws);

				return ws.ContrattaCVAnnoMin(month, out AnnoMin, out AnnoMax);
			}
			catch (SoapException ex)
			{
				Trace.WriteLine("SoapException");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show(ex.Message, "Errore");
				AnnoMin = 0 ;
				AnnoMax = 0 ;
				return false;
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore di comunicazione o eccezione dal server");
				Trace.Indent();
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
				Trace.Unindent();

				MessageBox.Show("Comunicazione con il server impossibile", "Errore");
				AnnoMin = 0 ;
				AnnoMax = 0 ;
				return false;
			}
		}

		private void cbAnniRiferimento_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DateTime dt = DateTime.Now ;
			int n = Convert.ToInt32(cbAnniRiferimento.Text) - dt.Year ;
			if (n == -10)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec10"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec10"]));
				}
			}
			else if (n == -9)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec09"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec09"]));
				}
			}
			else if (n == -8)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec08"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec08"]));
				}
			}
			else if (n == -7)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec07"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec07"]));
				}
			}
			else if (n == -6)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec06"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec06"]));
				}
			}
			else if (n == -5)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec05"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec05"]));
				}
			}
			else if (n == -4)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec04"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec04"]));
				}
			}
			else if (n == -3)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec03"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec03"]));
				}
			}
			else if (n == -2)
			{
				if (_dr["PrezzoRiferimentoAnnoPrec02"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoPrec02"]));
				}
			}
			else if (n == 2)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc02"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc02"]));
				}
			}
			else if (n == 3)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc03"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc03"]));
				}
			}
			else if (n == 4)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc04"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc04"]));
				}
			}
			else if (n == 5)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc05"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc05"]));
				}
			}
			else if (n == 6)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc06"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc06"]));
				}
			}
			else if (n == 7)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc07"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc07"]));
				}
			}
			else if (n == 8)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc08"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc08"]));
				}
			}
			else if (n == 9)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc09"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc09"]));
				}
			}
			else if (n == 10)
			{
				if (_dr["PrezzoRiferimentoAnnoSucc10"] is DBNull)
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(0);
				}
				else
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Convert.ToDecimal(_dr["PrezzoRiferimentoAnnoSucc10"]));
				}
			}
		}
					
		private void edtPrezziRiferimento_Validated(object sender, System.EventArgs e)
		{
			try
			{
				edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Converter.NumberStringToDecimal(edtPrezziRiferimento.Text));
				DateTime dt = DateTime.Now ;
				int n = Convert.ToInt32(cbAnniRiferimento.Text) - dt.Year ;
				if (n == -10)
				{
					_dr["PrezzoRiferimentoAnnoPrec10"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -9)
				{
					_dr["PrezzoRiferimentoAnnoPrec09"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -8)
				{
					_dr["PrezzoRiferimentoAnnoPrec08"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -7)
				{
					_dr["PrezzoRiferimentoAnnoPrec07"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -6)
				{
					_dr["PrezzoRiferimentoAnnoPrec06"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -5)
				{
					_dr["PrezzoRiferimentoAnnoPrec05"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -4)
				{
					_dr["PrezzoRiferimentoAnnoPrec04"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -3)
				{
					_dr["PrezzoRiferimentoAnnoPrec03"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == -2)
				{
					_dr["PrezzoRiferimentoAnnoPrec02"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 2)
				{
					_dr["PrezzoRiferimentoAnnoSucc02"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 3)
				{
					_dr["PrezzoRiferimentoAnnoSucc03"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 4)
				{
					_dr["PrezzoRiferimentoAnnoSucc04"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 5)
				{
					_dr["PrezzoRiferimentoAnnoSucc05"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 6)
				{
					_dr["PrezzoRiferimentoAnnoSucc06"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 7)
				{
					_dr["PrezzoRiferimentoAnnoSucc07"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 8)
				{
					_dr["PrezzoRiferimentoAnnoSucc08"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 9)
				{
					_dr["PrezzoRiferimentoAnnoSucc09"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
				else if (n == 10)
				{
					_dr["PrezzoRiferimentoAnnoSucc10"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
				}
			}
			catch(Exception)
			{
				try
				{
					edtPrezziRiferimento.Text = Converter.DecimalToCurrencyString(Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text));
					DateTime dt = DateTime.Now ;
					int n = Convert.ToInt32(cbAnniRiferimento.Text) - dt.Year ;
					if (n == -10)
					{
						_dr["PrezzoRiferimentoAnnoPrec10"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -9)
					{
						_dr["PrezzoRiferimentoAnnoPrec09"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -8)
					{
						_dr["PrezzoRiferimentoAnnoPrec08"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -7)
					{
						_dr["PrezzoRiferimentoAnnoPrec07"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -6)
					{
						_dr["PrezzoRiferimentoAnnoPrec06"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -5)
					{
						_dr["PrezzoRiferimentoAnnoPrec05"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -4)
					{
						_dr["PrezzoRiferimentoAnnoPrec04"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -3)
					{
						_dr["PrezzoRiferimentoAnnoPrec03"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == -2)
					{
						_dr["PrezzoRiferimentoAnnoPrec02"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 2)
					{
						_dr["PrezzoRiferimentoAnnoSucc02"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 3)
					{
						_dr["PrezzoRiferimentoAnnoSucc03"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 4)
					{
						_dr["PrezzoRiferimentoAnnoSucc04"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 5)
					{
						_dr["PrezzoRiferimentoAnnoSucc05"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 6)
					{
						_dr["PrezzoRiferimentoAnnoSucc06"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 7)
					{
						_dr["PrezzoRiferimentoAnnoSucc07"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 8)
					{
						_dr["PrezzoRiferimentoAnnoSucc08"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 9)
					{
						_dr["PrezzoRiferimentoAnnoSucc09"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
					else if (n == 10)
					{
						_dr["PrezzoRiferimentoAnnoSucc10"] = Converter.CurrencyStringToDecimal(edtPrezziRiferimento.Text);
					}
				}
				catch(Exception)
				{
					MessageBox.Show("Valore del prezzo di riferimento non valido", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}
			}
		}

		private void RefreshBinding()
		{
//			if (_bmgr == null)
//				return;
//			int p = _bmgr.Position;
//			_bmgr.Position = _bmgr.Count;
//			_bmgr.Position = p;
			if (_bmgr != null && _bmgr is CurrencyManager)
				((CurrencyManager)_bmgr).Refresh();
		}
		
		private void DecimalToCurrencyString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(string))
				return;

			Binding bng = sender as Binding;
			if (bng != null && bng.Control == edtPrezzoRifAnnoPrec && ckPrezzoRifAnnoPrec.Checked == false)
				cevent.Value = "";
			else
			{
				decimal d = ((decimal) cevent.Value);
				if (d >= 0m)
					cevent.Value = Converter.DecimalToCurrencyString(d);
				else
					cevent.Value = "";
			}
		}

		private void CurrencyStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(decimal))
				return;

			Binding bng = sender as Binding;
			if (bng != null && bng.Control == edtPrezzoRifAnnoPrec && ckPrezzoRifAnnoPrec.Checked == false)
				cevent.Value = -1m;
			else
			{
				decimal d = Converter.CurrencyStringToDecimal((string)cevent.Value);
				if (d < 0m)
					throw new Exception("prezzo minore di zero");

				cevent.Value = d;
			}
		}


		private void TitoloStringToString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType != typeof(string))
				return;

			string d = ((string) cevent.Value); // valore nella edit

			// controllo la lunghezza .... se e' errata rimette l'original al posto del proposed
			if (d.Length == 0)
				throw new Exception("Il titolo deve essere una stringa di almeno un carattere");

			cevent.Value = d;
		}

		
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmModificaSessione));
			this.gbSessione = new System.Windows.Forms.GroupBox();
			this.cbAnniRiferimento = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.edtPrezziRiferimento = new System.Windows.Forms.TextBox();
			this.cbStatoSessione = new System.Windows.Forms.ComboBox();
			this.lblStatoSessione = new System.Windows.Forms.Label();
			this.edtPrezzoConvenzionale = new System.Windows.Forms.TextBox();
			this.dtpDataChiusura = new System.Windows.Forms.DateTimePicker();
			this.dtpDataApertura = new System.Windows.Forms.DateTimePicker();
			this.txtTitoloSessione = new System.Windows.Forms.TextBox();
			this.lblDataOraChiusura = new System.Windows.Forms.Label();
			this.lblPrezzoConvenzionale = new System.Windows.Forms.Label();
			this.lblDataOraApertura = new System.Windows.Forms.Label();
			this.lblTitoloSessione = new System.Windows.Forms.Label();
			this.ckPrezzoRifAnnoPrec = new System.Windows.Forms.CheckBox();
			this.edtPrezzoRifAnnoSucc = new System.Windows.Forms.TextBox();
			this.edtPrezzoRifAnnoCorr = new System.Windows.Forms.TextBox();
			this.edtPrezzoRifAnnoPrec = new System.Windows.Forms.TextBox();
			this.lblAnnoSucc = new System.Windows.Forms.Label();
			this.lblAnnoCorr = new System.Windows.Forms.Label();
			this.lblAnnoPrec = new System.Windows.Forms.Label();
			this.btnImportXML = new System.Windows.Forms.Button();
			this.btnInvioXMLalGRTN = new System.Windows.Forms.Button();
			this.btnGeneraFileXML = new System.Windows.Forms.Button();
			this.btnModifica = new System.Windows.Forms.Button();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.dlgSaveGeneraFileXmlBanca = new System.Windows.Forms.SaveFileDialog();
			this.gbSessione.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbSessione
			// 
			this.gbSessione.Controls.Add(this.cbAnniRiferimento);
			this.gbSessione.Controls.Add(this.label1);
			this.gbSessione.Controls.Add(this.edtPrezziRiferimento);
			this.gbSessione.Controls.Add(this.cbStatoSessione);
			this.gbSessione.Controls.Add(this.lblStatoSessione);
			this.gbSessione.Controls.Add(this.edtPrezzoConvenzionale);
			this.gbSessione.Controls.Add(this.dtpDataChiusura);
			this.gbSessione.Controls.Add(this.dtpDataApertura);
			this.gbSessione.Controls.Add(this.txtTitoloSessione);
			this.gbSessione.Controls.Add(this.lblDataOraChiusura);
			this.gbSessione.Controls.Add(this.lblPrezzoConvenzionale);
			this.gbSessione.Controls.Add(this.lblDataOraApertura);
			this.gbSessione.Controls.Add(this.lblTitoloSessione);
			this.gbSessione.Controls.Add(this.ckPrezzoRifAnnoPrec);
			this.gbSessione.Controls.Add(this.edtPrezzoRifAnnoSucc);
			this.gbSessione.Controls.Add(this.edtPrezzoRifAnnoCorr);
			this.gbSessione.Controls.Add(this.edtPrezzoRifAnnoPrec);
			this.gbSessione.Controls.Add(this.lblAnnoSucc);
			this.gbSessione.Controls.Add(this.lblAnnoCorr);
			this.gbSessione.Controls.Add(this.lblAnnoPrec);
			this.gbSessione.Location = new System.Drawing.Point(4, 12);
			this.gbSessione.Name = "gbSessione";
			this.gbSessione.Size = new System.Drawing.Size(632, 280);
			this.gbSessione.TabIndex = 0;
			this.gbSessione.TabStop = false;
			this.gbSessione.Text = "Sessione Selezionata";
			// 
			// cbAnniRiferimento
			// 
			this.cbAnniRiferimento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbAnniRiferimento.Location = new System.Drawing.Point(176, 248);
			this.cbAnniRiferimento.Name = "cbAnniRiferimento";
			this.cbAnniRiferimento.Size = new System.Drawing.Size(96, 21);
			this.cbAnniRiferimento.TabIndex = 21;
			this.cbAnniRiferimento.SelectedIndexChanged += new System.EventHandler(this.cbAnniRiferimento_SelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 248);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(160, 24);
			this.label1.TabIndex = 20;
			this.label1.Text = "Prezzo riferimento(MWh) anno";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// edtPrezziRiferimento
			// 
			this.edtPrezziRiferimento.Location = new System.Drawing.Point(280, 248);
			this.edtPrezziRiferimento.Name = "edtPrezziRiferimento";
			this.edtPrezziRiferimento.Size = new System.Drawing.Size(176, 20);
			this.edtPrezziRiferimento.TabIndex = 19;
			this.edtPrezziRiferimento.Text = "";
			this.edtPrezziRiferimento.Validated += new System.EventHandler(this.edtPrezziRiferimento_Validated);
			// 
			// cbStatoSessione
			// 
			this.cbStatoSessione.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cbStatoSessione.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbStatoSessione.Location = new System.Drawing.Point(144, 92);
			this.cbStatoSessione.Name = "cbStatoSessione";
			this.cbStatoSessione.Size = new System.Drawing.Size(176, 21);
			this.cbStatoSessione.TabIndex = 6;
			// 
			// lblStatoSessione
			// 
			this.lblStatoSessione.Location = new System.Drawing.Point(16, 92);
			this.lblStatoSessione.Name = "lblStatoSessione";
			this.lblStatoSessione.Size = new System.Drawing.Size(120, 24);
			this.lblStatoSessione.TabIndex = 18;
			this.lblStatoSessione.Text = "Stato Sessione";
			this.lblStatoSessione.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// edtPrezzoConvenzionale
			// 
			this.edtPrezzoConvenzionale.Location = new System.Drawing.Point(144, 124);
			this.edtPrezzoConvenzionale.Name = "edtPrezzoConvenzionale";
			this.edtPrezzoConvenzionale.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoConvenzionale.TabIndex = 7;
			this.edtPrezzoConvenzionale.Text = "";
			// 
			// dtpDataChiusura
			// 
			this.dtpDataChiusura.CustomFormat = "dd\'/\'MM\'/\'yyyy HH\':\'mm";
			this.dtpDataChiusura.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpDataChiusura.Location = new System.Drawing.Point(432, 60);
			this.dtpDataChiusura.Name = "dtpDataChiusura";
			this.dtpDataChiusura.Size = new System.Drawing.Size(128, 20);
			this.dtpDataChiusura.TabIndex = 4;
			// 
			// dtpDataApertura
			// 
			this.dtpDataApertura.CustomFormat = "dd\'/\'MM\'/\'yyyy HH\':\'mm";
			this.dtpDataApertura.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtpDataApertura.Location = new System.Drawing.Point(144, 60);
			this.dtpDataApertura.Name = "dtpDataApertura";
			this.dtpDataApertura.Size = new System.Drawing.Size(128, 20);
			this.dtpDataApertura.TabIndex = 1;
			// 
			// txtTitoloSessione
			// 
			this.txtTitoloSessione.Location = new System.Drawing.Point(144, 28);
			this.txtTitoloSessione.Name = "txtTitoloSessione";
			this.txtTitoloSessione.Size = new System.Drawing.Size(464, 20);
			this.txtTitoloSessione.TabIndex = 0;
			this.txtTitoloSessione.Text = "";
			// 
			// lblDataOraChiusura
			// 
			this.lblDataOraChiusura.Location = new System.Drawing.Point(328, 60);
			this.lblDataOraChiusura.Name = "lblDataOraChiusura";
			this.lblDataOraChiusura.Size = new System.Drawing.Size(104, 24);
			this.lblDataOraChiusura.TabIndex = 3;
			this.lblDataOraChiusura.Text = "Data Ora Chiusura";
			this.lblDataOraChiusura.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblPrezzoConvenzionale
			// 
			this.lblPrezzoConvenzionale.Location = new System.Drawing.Point(16, 124);
			this.lblPrezzoConvenzionale.Name = "lblPrezzoConvenzionale";
			this.lblPrezzoConvenzionale.Size = new System.Drawing.Size(120, 24);
			this.lblPrezzoConvenzionale.TabIndex = 11;
			this.lblPrezzoConvenzionale.Text = "Prezzo Convenzionale";
			this.lblPrezzoConvenzionale.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblDataOraApertura
			// 
			this.lblDataOraApertura.Location = new System.Drawing.Point(16, 60);
			this.lblDataOraApertura.Name = "lblDataOraApertura";
			this.lblDataOraApertura.Size = new System.Drawing.Size(104, 24);
			this.lblDataOraApertura.TabIndex = 12;
			this.lblDataOraApertura.Text = "Data Ora Apertura";
			this.lblDataOraApertura.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblTitoloSessione
			// 
			this.lblTitoloSessione.Location = new System.Drawing.Point(16, 28);
			this.lblTitoloSessione.Name = "lblTitoloSessione";
			this.lblTitoloSessione.Size = new System.Drawing.Size(104, 24);
			this.lblTitoloSessione.TabIndex = 10;
			this.lblTitoloSessione.Text = "Titolo Sessione";
			this.lblTitoloSessione.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// ckPrezzoRifAnnoPrec
			// 
			this.ckPrezzoRifAnnoPrec.Checked = true;
			this.ckPrezzoRifAnnoPrec.CheckState = System.Windows.Forms.CheckState.Checked;
			this.ckPrezzoRifAnnoPrec.Enabled = false;
			this.ckPrezzoRifAnnoPrec.Location = new System.Drawing.Point(480, 88);
			this.ckPrezzoRifAnnoPrec.Name = "ckPrezzoRifAnnoPrec";
			this.ckPrezzoRifAnnoPrec.Size = new System.Drawing.Size(144, 24);
			this.ckPrezzoRifAnnoPrec.TabIndex = 9;
			this.ckPrezzoRifAnnoPrec.Text = "Includi anno precedente";
			this.ckPrezzoRifAnnoPrec.Visible = false;
			this.ckPrezzoRifAnnoPrec.CheckedChanged += new System.EventHandler(this.ckPrezzoRifAnnoPrec_CheckedChanged);
			// 
			// edtPrezzoRifAnnoSucc
			// 
			this.edtPrezzoRifAnnoSucc.Location = new System.Drawing.Point(280, 224);
			this.edtPrezzoRifAnnoSucc.Name = "edtPrezzoRifAnnoSucc";
			this.edtPrezzoRifAnnoSucc.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoRifAnnoSucc.TabIndex = 11;
			this.edtPrezzoRifAnnoSucc.Text = "";
			// 
			// edtPrezzoRifAnnoCorr
			// 
			this.edtPrezzoRifAnnoCorr.Location = new System.Drawing.Point(280, 200);
			this.edtPrezzoRifAnnoCorr.Name = "edtPrezzoRifAnnoCorr";
			this.edtPrezzoRifAnnoCorr.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoRifAnnoCorr.TabIndex = 10;
			this.edtPrezzoRifAnnoCorr.Text = "";
			// 
			// edtPrezzoRifAnnoPrec
			// 
			this.edtPrezzoRifAnnoPrec.Location = new System.Drawing.Point(280, 176);
			this.edtPrezzoRifAnnoPrec.Name = "edtPrezzoRifAnnoPrec";
			this.edtPrezzoRifAnnoPrec.Size = new System.Drawing.Size(176, 20);
			this.edtPrezzoRifAnnoPrec.TabIndex = 8;
			this.edtPrezzoRifAnnoPrec.Text = "";
			// 
			// lblAnnoSucc
			// 
			this.lblAnnoSucc.Location = new System.Drawing.Point(16, 224);
			this.lblAnnoSucc.Name = "lblAnnoSucc";
			this.lblAnnoSucc.Size = new System.Drawing.Size(216, 24);
			this.lblAnnoSucc.TabIndex = 18;
			this.lblAnnoSucc.Text = "Prezzo riferimento anno Successivo MWh";
			this.lblAnnoSucc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblAnnoCorr
			// 
			this.lblAnnoCorr.Location = new System.Drawing.Point(16, 200);
			this.lblAnnoCorr.Name = "lblAnnoCorr";
			this.lblAnnoCorr.Size = new System.Drawing.Size(216, 24);
			this.lblAnnoCorr.TabIndex = 16;
			this.lblAnnoCorr.Text = "Prezzo riferimento anno Corrente MWh";
			this.lblAnnoCorr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblAnnoPrec
			// 
			this.lblAnnoPrec.Location = new System.Drawing.Point(16, 176);
			this.lblAnnoPrec.Name = "lblAnnoPrec";
			this.lblAnnoPrec.Size = new System.Drawing.Size(216, 24);
			this.lblAnnoPrec.TabIndex = 13;
			this.lblAnnoPrec.Text = "Prezzo riferimento anno Precedente MWh";
			this.lblAnnoPrec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnImportXML
			// 
			this.btnImportXML.Location = new System.Drawing.Point(136, 312);
			this.btnImportXML.Name = "btnImportXML";
			this.btnImportXML.Size = new System.Drawing.Size(120, 24);
			this.btnImportXML.TabIndex = 2;
			this.btnImportXML.Text = "Import XML";
			this.btnImportXML.Click += new System.EventHandler(this.btnImportXML_Click);
			// 
			// btnInvioXMLalGRTN
			// 
			this.btnInvioXMLalGRTN.Location = new System.Drawing.Point(8, 312);
			this.btnInvioXMLalGRTN.Name = "btnInvioXMLalGRTN";
			this.btnInvioXMLalGRTN.Size = new System.Drawing.Size(120, 24);
			this.btnInvioXMLalGRTN.TabIndex = 1;
			this.btnInvioXMLalGRTN.Text = "Invio XML al GRTN";
			this.btnInvioXMLalGRTN.Click += new System.EventHandler(this.btnInvioXMLalGRTN_Click);
			// 
			// btnGeneraFileXML
			// 
			this.btnGeneraFileXML.Enabled = false;
			this.btnGeneraFileXML.Location = new System.Drawing.Point(264, 312);
			this.btnGeneraFileXML.Name = "btnGeneraFileXML";
			this.btnGeneraFileXML.Size = new System.Drawing.Size(136, 23);
			this.btnGeneraFileXML.TabIndex = 3;
			this.btnGeneraFileXML.Text = "Genera file XML banca";
			this.btnGeneraFileXML.Visible = false;
			this.btnGeneraFileXML.Click += new System.EventHandler(this.btnGeneraFileXML_Click);
			// 
			// btnModifica
			// 
			this.btnModifica.Location = new System.Drawing.Point(424, 312);
			this.btnModifica.Name = "btnModifica";
			this.btnModifica.Size = new System.Drawing.Size(96, 24);
			this.btnModifica.TabIndex = 4;
			this.btnModifica.Text = "Modifica";
			this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click);
			// 
			// btnChiudi
			// 
			this.btnChiudi.Location = new System.Drawing.Point(528, 312);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.Size = new System.Drawing.Size(104, 23);
			this.btnChiudi.TabIndex = 5;
			this.btnChiudi.Text = "Chiudi";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// dlgSaveGeneraFileXmlBanca
			// 
			this.dlgSaveGeneraFileXmlBanca.FileName = "doc1";
			// 
			// frmModificaSessione
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(640, 349);
			this.ControlBox = false;
			this.Controls.Add(this.btnChiudi);
			this.Controls.Add(this.btnModifica);
			this.Controls.Add(this.btnGeneraFileXML);
			this.Controls.Add(this.btnInvioXMLalGRTN);
			this.Controls.Add(this.btnImportXML);
			this.Controls.Add(this.gbSessione);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmModificaSessione";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Modifica Sessione";
			this.gbSessione.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void ckPrezzoRifAnnoPrec_CheckedChanged(object sender, System.EventArgs e)
		{
			if (_dr == null)
				return;

			if (ckPrezzoRifAnnoPrec.Checked == false)
				_dr["PrezzoRiferimentoAnnoPrec"] = -1m;
			else
				_dr["PrezzoRiferimentoAnnoPrec"] = 0m;
		}



		private void btnModifica_Click(object sender, System.EventArgs e)
		{
			//DiagnosticHelper.DataSetDump("Sessione modificata", _dr);

			DialogResult r = MessageBox.Show("Vuoi salvare i dati della sessione ?", "Attenzione", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
			if (r != DialogResult.Yes)
				return;

			try
			{
				if (_dr.HasVersion(DataRowVersion.Proposed))
				{
					if ((DateTime)_dr["DataOraApertura", DataRowVersion.Proposed] > 
						(DateTime)_dr["DataOraChiusura", DataRowVersion.Proposed])
					{
						MessageBox.Show(this, "La data/ora di chiusura deve essere successiva alla data/ora apertura", "Errore");
						
						_dr.RejectChanges();
						return;
					}


					if ((string)_dr["StatoSessione", DataRowVersion.Current] != "Predisposta" &&
						(string)_dr["StatoSessione", DataRowVersion.Proposed] == "Predisposta")
					{
						MessageBox.Show("La sessione puo' andare in stato 'Predisposta' solo tramite l'operazione di 'Import XML'");

						_dr.RejectChanges();
						return;
					}
				}

				if (ckPrezzoRifAnnoPrec.Checked == false)
					_dr["PrezzoRiferimentoAnnoPrec"] = -1m;

				_dr["DataOraModifica"] = CVAdmin_Main.DbTime.GetDbSystemDate();

				_dr.EndEdit();
				
				DiagnosticHelper.DataSetDump("Dopo EndEdit", _dr);

				if (frmSessioni.AggiornaDataSet(_ds))
				{
					this.DialogResult = DialogResult.OK;
					this.Close();
				}
				else
				{
					return;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			_dr.CancelEdit();

			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void btnInvioXMLalGRTN_Click(object sender, System.EventArgs e)
		{
			try
			{
				frmExport f = new frmExport((string)_dr["IdSessione"], (DateTime)_dr["DataOraApertura"]);
				f.ShowDialog();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnImportXML_Click(object sender, System.EventArgs e)
		{
			if( this.VerificaStatoSessioni() )
			{
				//if (MessageBox.Show("E' possibile importare il file XML dopo le 12:00 del giorno precedente la sessione.", "Attenzione", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
				//	return;

				frmImport dlg = new frmImport(_dr);
				dlg.ShowDialog(this);

				RefreshBinding();
			}
		}

		private bool VerificaStatoSessioni()
		{
			try
			{
				CVAdminWSBLSessioni.ReportSessioni rs = Sessioni_VerifyStatus();

				if( rs.NumPredisposte > 0 )
				{
					throw new Exception("Non � possibile fare l'import finch� ci sono sessioni in stato \"Predisposta\".");
				}
				
				if( rs.NumAperte > 0 )
				{
					throw new Exception("Non � possibile fare l'import finch� ci sono sessioni in stato \"Aperta\".");
				}

				if( rs.NumSospese > 0 )
				{
					throw new Exception("Non � possibile fare l'import finch� ci sono sessioni in stato \"Sospesa\".");
				}

				if( rs.NumTerminate > 0 )
				{
					throw new Exception("Non � possibile fare l'import finch� ci sono sessioni in stato \"Terminata\".");
				}

			}
			catch( Exception ex )
			{
				MessageBox.Show(ex.Message, 
						"Attenzione", 
						MessageBoxButtons.OK, 
						MessageBoxIcon.Information);

				return false;
			}

			return true;

		}

		private CVAdminWSBLSessioni.ReportSessioni Sessioni_VerifyStatus()
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSessioni.BLSessioni.VerifyStatus", 
				null);
			
			if (Cancelled)
				return null;
			
			return (CVAdminWSBLSessioni.ReportSessioni)ret;
		}

		private void btnGeneraFileXML_Click(object sender, System.EventArgs e)
		{
			// 
			try
			{
				string idFileXml = string.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now);
				string nomeFileXml   = idFileXml + ".xml";

				dlgSaveGeneraFileXmlBanca.FileName = nomeFileXml;
				dlgSaveGeneraFileXmlBanca.InitialDirectory = UtilityEnvironment.CommonAppDir;
				if (dlgSaveGeneraFileXmlBanca.ShowDialog() != DialogResult.OK)
					return;

				nomeFileXml = dlgSaveGeneraFileXmlBanca.FileName;
				FileInfo fi = new FileInfo(nomeFileXml);
				string nomeFileExcel = fi.DirectoryName + @"\" + fi.Name;
				nomeFileExcel = nomeFileExcel.Replace(fi.Extension, ".xls");


				string strXml = "";

				Cursor.Current = Cursors.WaitCursor;
				try
				{
					CVAdminWSBLTransazioni.BLTransazioni ww = new CVAdminWSBLTransazioni.BLTransazioni();
					frmLogin.AddLoginInfo(ww);

					string IdSessione = (string)_dr["IdSessione"];
					IAsyncResult asr = ww.BeginGeneraFileXmlPerPagamenti(IdSessione, nomeFileXml, idFileXml, null, null);
					frmAsyncWait w = new frmAsyncWait(asr);
					w.ShowDialog();
					if (w.Cancelled)
						return;

					// il Web Service ha risposto... prendo il risultato
					strXml = ww.EndGeneraFileXmlPerPagamenti(asr);
				}
				catch (SoapException ex)
				{
					Trace.WriteLine("SoapException");
					Trace.Indent();
					Trace.WriteLine(ex.Message);
					Trace.WriteLine(ex.StackTrace);
					Trace.Unindent();

					MessageBox.Show(ex.Message, "Errore");
					return;
				}
				catch (Exception ex)
				{
					Trace.WriteLine("Errore di comunicazione o eccezione dal server");
					Trace.Indent();
					Trace.WriteLine(ex.Message);
					Trace.WriteLine(ex.StackTrace);
					Trace.Unindent();

					MessageBox.Show("Comunicazione con il server impossibile", "Errore");
					return;
				}

				XmlDocument xmlDoc = new XmlDocument();
				xmlDoc.LoadXml(strXml);

				XmlNodeList nodes = xmlDoc.DocumentElement.SelectNodes("Transazione");
				if (nodes.Count == 0)
				{
					MessageBox.Show("Non esistono transazioni da pagare");
					return;
				}
				xmlDoc.Save(nomeFileXml);
				GeneraFileExcelBanca(xmlDoc, nomeFileExcel);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Errore");
			}
		}


//		private Excel.Range Cell(Excel.Worksheet s, int r, int c)
//		{
//			return s.Cells[r, c] as Excel.Range;
//		}
//		private void GeneraFileExcelBanca(XmlDocument xmlDoc, string nomeFileExcel)
//		{
//			object missing = System.Reflection.Missing.Value;
//
//			// per ovviare ad un baco quando si ha Excel in inglese e il SO in italiano
//			CultureInfo ciOri = System.Threading.Thread.CurrentThread.CurrentCulture;
//
//			// creo una cultura che verra' usata per le conversioni da XML a Excel
//			CultureInfo ciIta = new CultureInfo("it-it");
//
//			try
//			{
//				// per ovviare ad un baco descritto in 
//				// BUG: "Old Format or Invalid Type Library" Error When Automating Excel 2002
//				System.Threading.Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-US");
//
//				// il rilascio degli oggetti COM (anche se wrappati da .NET) si puo' controllare
//				// ma e' praticamente impossibile farlo perche' bisognerebbe farlo su tutti gli
//				// oggetti COM intermedi... prova con xlBook.Worksheets[1].XYZ.ABC = 1
//				// Per ovviare la funzione chiamante e' investita dell'onere di chiamare 
//				// eplicitamente il GC.Collect() che mette fuori uso tutti gli oggetti non piu' 
//				// raggiunti (compresi il wrapper COM) ==> si fa il release ==> Excel esce.
//				
//				Excel.ApplicationClass xlApp = new Excel.ApplicationClass();
//				xlApp.Visible = false;
//				xlApp.SheetsInNewWorkbook = 1;
//				Excel.Workbook xlBook = xlApp.Workbooks.Add(Excel.XlWBATemplate.xlWBATWorksheet);
//				Excel.Worksheet xlSheet = xlBook.Worksheets[1] as Excel.Worksheet;
//				xlSheet.Name = "Pagamenti Transazioni";
//
//				int nRow;
//
//				// Titolo
//				// --------------------------------------------
//				nRow = 1;
//				if (true)
//				{
//					Excel.Range r = Cell(xlSheet, nRow, 1);
//					r.get_Characters(missing, missing).Font.Size = 11;
//					r.get_Characters(missing, missing).Font.Bold = true;
//					r.Value = "Pagamenti Transazioni";
//
//					Excel.Range rg = r.get_Range(Cell(xlSheet,nRow,1), Cell(xlSheet,nRow,7));
//
//					rg.HorizontalAlignment = 3;
//					rg.Merge(missing);
//				}
//
//
//				// Riga Intestazione
//				// --------------------------------------------
//				nRow = 4;
//				if (true)
//				{
//					Excel.Range r = xlSheet.Cells.EntireRow[nRow, missing] as Excel.Range;
//					r.get_Characters(missing, missing).Font.Size = 10;
//					r.get_Characters(missing, missing).Font.Bold = true;
//
//					Cell(xlSheet, nRow, 1).Value = "Importo";
//					Cell(xlSheet, nRow, 2).Value = "Valuta";
//					Cell(xlSheet, nRow, 3).Value = "Codice Conto Acquirente";
//					Cell(xlSheet, nRow, 4).Value = "Venditore CC";
//					Cell(xlSheet, nRow, 5).Value = "Venditore ABI";
//					Cell(xlSheet, nRow, 6).Value = "Venditore CAB";
//					Cell(xlSheet, nRow, 7).Value = "Causale";
//				}
//
//				nRow = 5;
//
//				XmlNodeList nodes = xmlDoc.DocumentElement.SelectNodes("Transazione");
//				foreach (XmlElement node in nodes)
//				{
//					nRow++;
//
//					// qui si scrive dalla colonna 1 alla 7
//					Excel.Range rg = xlSheet.Cells.get_Range(Cell(xlSheet,nRow,1), Cell(xlSheet,nRow,7));
//
//					rg.HorizontalAlignment = Excel.Constants.xlRight;
//					rg.get_Characters(missing, missing).Font.Size = 9;
//					rg.get_Characters(missing, missing).Font.Bold = true;
//
//					if ((nRow & 1) > 0)
//					{
//						rg.Interior.ColorIndex = 15;
//						rg.Interior.Pattern = Excel.Constants.xlSolid;
//						rg.Interior.PatternColorIndex = Excel.Constants.xlAutomatic;
//					}
//
//					// qui impongo che TUTTE le celle che vado a scrivere dopo 
//					// siano prese as-is da Excel e non NON venga interpretato niente
//					// anche se nella stringa passata c'e' un numero o una data.
//					rg.NumberFormat = "@";
//
//					Cell(xlSheet, nRow, 1).Value = XmlConvert.ToDecimal(node.SelectSingleNode("Importo").InnerText).ToString("c", ciIta);
//					Cell(xlSheet, nRow, 2).Value = XmlConvert.ToDateTime(node.SelectSingleNode("Valuta").InnerText).ToString("d", ciIta);
//					Cell(xlSheet, nRow, 3).Value = node.SelectSingleNode("ContoCodiceAcquirente").InnerText;
//					Cell(xlSheet, nRow, 4).Value = node.SelectSingleNode("ContoCodiceVenditore").InnerText;
//					Cell(xlSheet, nRow, 5).Value = node.SelectSingleNode("ABIVenditore").InnerText;
//					Cell(xlSheet, nRow, 6).Value = node.SelectSingleNode("CABVenditore").InnerText;
//					Cell(xlSheet, nRow, 7).Value = node.SelectSingleNode("CausaleTransazione").InnerText;
//				}
//
//				for (int x = 1; x <= 7; ++x)
//				{
//					Excel.Range rc = xlSheet.Cells.EntireColumn[x, missing] as Excel.Range;
//					rc.get_Resize(missing,missing).AutoFit();
//				}
//
//
//				try { System.IO.File.Delete(nomeFileExcel); } 
//				catch (Exception) {} // eccezione se il file non esiste
//				xlSheet.SaveAs(nomeFileExcel, missing, missing, missing, missing, missing, missing, missing, missing);
//
//				xlBook.Close(false,missing,missing);
//				xlApp.Quit();
//			}
//			catch (Exception ex)
//			{
//				MessageBox.Show(ex.Message, "Errore");
//			}
//			finally
//			{
//				// rimetto a posto il thread locale (altrimenti ci mettiamo a parlare inglese)
//				System.Threading.Thread.CurrentThread.CurrentCulture = ciOri;
//			}
//		}

		private void GeneraFileExcelBanca(XmlDocument xmlDoc, string nomeFileExcel)
		{
			try
			{
				using (spApplication xlApp = new spApplication())
				{
					xlApp.Visible = false;
					xlApp.SheetsInNewWorkbook = 1;
					spWorkbook xlBook = xlApp.Workbooks.Add();
					spWorksheet xlSheet = xlBook.Worksheets[1];
					xlSheet.Name = "Pagamenti Transazioni";

					int nRow;

					// Titolo
					// --------------------------------------------
					nRow = 1;
					if (true)
					{
						spRange r = xlSheet.Cells[nRow, 1];
						r.Characters.Font.Size = 11;
						r.Characters.Font.Bold = true;
						r.Value = "Pagamenti Transazioni";

						spRange rg = r.Range(xlSheet.Cells[nRow,1], xlSheet.Cells[nRow,7]);

						rg.HorizontalAlignment = Excel.XlHAlign.xlHAlignGeneral;//3;
						rg.Merge();
					}


					// Riga Intestazione
					// --------------------------------------------
					nRow = 4;
					if (true)
					{
						spRange r = xlSheet.Cells.EntireRow[nRow];
						r.Characters.Font.Size = 10;
						r.Characters.Font.Bold = true;

						xlSheet.Cells[nRow, 1].Value = "Importo";
						xlSheet.Cells[nRow, 2].Value = "Valuta";
						xlSheet.Cells[nRow, 3].Value = "Codice Conto Acquirente";
						xlSheet.Cells[nRow, 4].Value = "Venditore CC";
						xlSheet.Cells[nRow, 5].Value = "Venditore ABI";
						xlSheet.Cells[nRow, 6].Value = "Venditore CAB";
						xlSheet.Cells[nRow, 7].Value = "Causale";
					}

					nRow = 5;

					XmlNodeList nodes = xmlDoc.DocumentElement.SelectNodes("Transazione");
					foreach (XmlElement node in nodes)
					{
						nRow++;

						// qui si scrive dalla colonna 1 alla 7
						spRange rg = xlSheet.Cells.Range(xlSheet.Cells[nRow,1], xlSheet.Cells[nRow,7]);

						rg.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;

						rg.Characters.Font.Size = 9;
						rg.Characters.Font.Bold = true;

						if ((nRow & 1) > 0)
						{
							rg.Interior.ColorIndex = 15;
							rg.Interior.Pattern = Excel.XlPattern.xlPatternSolid; // Excel.Constants.xlSolid;
							rg.Interior.PatternColorIndex = Excel.XlPattern.xlPatternAutomatic;
						}

						// qui impongo che TUTTE le celle che vado a scrivere dopo 
						// siano prese as-is da Excel e non NON venga interpretato niente
						// anche se nella stringa passata c'e' un numero o una data.
						rg.NumberFormat = "@";

						decimal Importo = XmlConvert.ToDecimal(node.SelectSingleNode("Importo").InnerText);
						DateTime Valuta = XmlConvert.ToDateTime(node.SelectSingleNode("Valuta").InnerText);

						xlSheet.Cells[nRow, 1].Value = Converter.DecimalToCurrencyString(Importo);
						xlSheet.Cells[nRow, 2].Value = Converter.DateTimeToStringDate(Valuta);
						xlSheet.Cells[nRow, 3].Value = node.SelectSingleNode("ContoCodiceAcquirente").InnerText;
						xlSheet.Cells[nRow, 4].Value = node.SelectSingleNode("ContoCodiceVenditore").InnerText;
						xlSheet.Cells[nRow, 5].Value = node.SelectSingleNode("ABIVenditore").InnerText;
						xlSheet.Cells[nRow, 6].Value = node.SelectSingleNode("CABVenditore").InnerText;
						xlSheet.Cells[nRow, 7].Value = node.SelectSingleNode("CausaleTransazione").InnerText;
					}

					for (int x = 1; x <= 7; ++x)
					{
						spRange rc = xlSheet.Cells.EntireColumn[x];
						rc.Resize.AutoFit();
					}


					try { System.IO.File.Delete(nomeFileExcel); } 
					catch (Exception) {} // eccezione se il file non esiste
					xlSheet.SaveAs(nomeFileExcel);

					xlBook.Close();
					xlApp.Quit();
				}

				MessageBox.Show("File Excel generato con successo", "Messaggio");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Errore");
			}
		}
	}
}
