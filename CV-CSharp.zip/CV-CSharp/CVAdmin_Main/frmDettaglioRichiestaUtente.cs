using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmDettaglioRichiestaUtente.
	/// </summary>
	public class frmDettaglioRichiestaUtente : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox gbSocieta;
		private System.Windows.Forms.GroupBox gbUtente;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.Button btnValida;
		private System.Windows.Forms.Label lblNominativo;
		private System.Windows.Forms.TextBox tbNominativo;
		private System.Windows.Forms.Label lblDataOraIns;
		private System.Windows.Forms.Label lblCodiceFiscale;
		private System.Windows.Forms.TextBox tbCodiceFiscale;
		private System.Windows.Forms.Label lblStatoRichiesta;
		private System.Windows.Forms.TextBox tbStatoRichiesta;
		private System.Windows.Forms.Label lblRagioneSociale;
		private System.Windows.Forms.TextBox tbRagioneSociale;
		private System.Windows.Forms.Label lblViaPiazza;
		private System.Windows.Forms.TextBox tbViaPiazza;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox tbCitta;
		private System.Windows.Forms.Label lblNazione;
		private System.Windows.Forms.TextBox tbNazione;
		private System.Windows.Forms.Label lblCodiceConto;
		private System.Windows.Forms.TextBox tbCodiceConto;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.TextBox tbDataOraIns;


		private DataRow _drRichiestaUtente	= null;
		private System.Windows.Forms.ToolTip tltInfo;
		private DataRow _drSocietaParent	= null;

		public frmDettaglioRichiestaUtente()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ClearComponents();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public frmDettaglioRichiestaUtente(DataRow dr)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ClearComponents();
			if (dr == null)
			{
				DisabilitaComponenti();
				return;
			}

			_drRichiestaUtente	= dr;
			_drSocietaParent	= _drRichiestaUtente.GetParentRow("relSocietaUtenti"); 
			SetDataComponents();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Funzioni Interne

		private void Chiudi()
		{
			this.DialogResult = DialogResult.Cancel;
		}

		private void ClearComponents()
		{
			tbCitta.Text		  = "";
			tbCodiceConto.Text	  = "";
			tbCodiceFiscale.Text  = "";
			tbDataOraIns.Text	  = "";
			tbNazione.Text		  = "";
			tbNominativo.Text	  = "";
			tbRagioneSociale.Text = "";
			tbStatoRichiesta.Text = "";
			tbViaPiazza.Text	  = "";
		}

		private void DisabilitaComponenti()
		{
			gbSocieta.Enabled = false;
			gbUtente.Enabled  = false;
			btnValida.Enabled = false;

			// Devo poter uscire dalla Form
			btnChiudi.Enabled = true;
		}

		private void SetDataComponents()
		{
			if ((_drRichiestaUtente == null) || (_drSocietaParent == null))
			{
				return;
			}

			// Inserisco i Dati relativi alla Societa' di appartenenza
			// dell'Utente
			tbRagioneSociale.Text	= _drSocietaParent["RagioneSociale"].ToString();
			tbViaPiazza.Text		= _drSocietaParent["Indirizzo"].ToString();
			tbCitta.Text			= _drSocietaParent["Citta"].ToString();
			tbNazione.Text			= _drSocietaParent["Nazione"].ToString();
			tbCodiceConto.Text		= _drSocietaParent["CodiceConto"].ToString();

			// Inserisco i dati descrittivi dell'Utente eventualmente da Validare
			tbStatoRichiesta.Text	= _drRichiestaUtente["StatoRichiesta"].ToString();
			tbNominativo.Text		= _drRichiestaUtente["Nominativo"].ToString();
			tbCodiceFiscale.Text	= _drRichiestaUtente["CodiceFiscale"].ToString();
			tbDataOraIns.Text		= _drRichiestaUtente["DataOraInserimento"].ToString();

			// In funzione dello Stato della richiesta abilito o meno il pulsante di "Valida"
			btnValida.Enabled = tbStatoRichiesta.Text.Equals("Da Validare");
		}

		#endregion


		#region Chiamata ai Web Services
		
		private string IsSocietaValidated(string IdRichiestaRegSoc)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLRichiesta.BLRichiesta.IsReqSocietaValidated",
				IdRichiestaRegSoc);

			if (Cancelled)
				return null;
			return (string)ret;
		}

		private string ValidaUtente(string IdSocietaParent, string IdRichiestaRegUtente)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLUtenti.BLUtenti.Valida",
				IdSocietaParent,
				IdRichiestaRegUtente);

			if (Cancelled)
				return null;
			return (string)ret;
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDettaglioRichiestaUtente));
			this.gbSocieta = new System.Windows.Forms.GroupBox();
			this.tbCodiceConto = new System.Windows.Forms.TextBox();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.tbNazione = new System.Windows.Forms.TextBox();
			this.lblNazione = new System.Windows.Forms.Label();
			this.tbCitta = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.tbViaPiazza = new System.Windows.Forms.TextBox();
			this.lblViaPiazza = new System.Windows.Forms.Label();
			this.tbRagioneSociale = new System.Windows.Forms.TextBox();
			this.lblRagioneSociale = new System.Windows.Forms.Label();
			this.gbUtente = new System.Windows.Forms.GroupBox();
			this.tbStatoRichiesta = new System.Windows.Forms.TextBox();
			this.lblStatoRichiesta = new System.Windows.Forms.Label();
			this.tbCodiceFiscale = new System.Windows.Forms.TextBox();
			this.lblCodiceFiscale = new System.Windows.Forms.Label();
			this.tbDataOraIns = new System.Windows.Forms.TextBox();
			this.lblDataOraIns = new System.Windows.Forms.Label();
			this.tbNominativo = new System.Windows.Forms.TextBox();
			this.lblNominativo = new System.Windows.Forms.Label();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnValida = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.gbSocieta.SuspendLayout();
			this.gbUtente.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbSocieta
			// 
			this.gbSocieta.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.tbCodiceConto,
																					this.lblCodiceConto,
																					this.tbNazione,
																					this.lblNazione,
																					this.tbCitta,
																					this.label1,
																					this.tbViaPiazza,
																					this.lblViaPiazza,
																					this.tbRagioneSociale,
																					this.lblRagioneSociale});
			this.gbSocieta.Location = new System.Drawing.Point(5, 4);
			this.gbSocieta.Name = "gbSocieta";
			this.gbSocieta.Size = new System.Drawing.Size(543, 136);
			this.gbSocieta.TabIndex = 0;
			this.gbSocieta.TabStop = false;
			this.gbSocieta.Text = " Dati Societ� di appartenenza dell\'Utente ";
			// 
			// tbCodiceConto
			// 
			this.tbCodiceConto.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbCodiceConto.Enabled = false;
			this.tbCodiceConto.Location = new System.Drawing.Point(96, 104);
			this.tbCodiceConto.Name = "tbCodiceConto";
			this.tbCodiceConto.Size = new System.Drawing.Size(144, 20);
			this.tbCodiceConto.TabIndex = 9;
			this.tbCodiceConto.TabStop = false;
			this.tbCodiceConto.Text = "Codice Conto";
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Location = new System.Drawing.Point(8, 108);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(80, 16);
			this.lblCodiceConto.TabIndex = 8;
			this.lblCodiceConto.Text = "Codice Conto";
			// 
			// tbNazione
			// 
			this.tbNazione.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbNazione.Enabled = false;
			this.tbNazione.Location = new System.Drawing.Point(342, 78);
			this.tbNazione.Name = "tbNazione";
			this.tbNazione.Size = new System.Drawing.Size(194, 20);
			this.tbNazione.TabIndex = 7;
			this.tbNazione.TabStop = false;
			this.tbNazione.Text = "Nazione";
			// 
			// lblNazione
			// 
			this.lblNazione.Location = new System.Drawing.Point(290, 80);
			this.lblNazione.Name = "lblNazione";
			this.lblNazione.Size = new System.Drawing.Size(52, 16);
			this.lblNazione.TabIndex = 6;
			this.lblNazione.Text = "Nazione";
			// 
			// tbCitta
			// 
			this.tbCitta.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbCitta.Enabled = false;
			this.tbCitta.Location = new System.Drawing.Point(96, 78);
			this.tbCitta.Name = "tbCitta";
			this.tbCitta.Size = new System.Drawing.Size(180, 20);
			this.tbCitta.TabIndex = 5;
			this.tbCitta.TabStop = false;
			this.tbCitta.Text = "Citta";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 80);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(32, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "Citt�";
			// 
			// tbViaPiazza
			// 
			this.tbViaPiazza.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbViaPiazza.Enabled = false;
			this.tbViaPiazza.Location = new System.Drawing.Point(96, 50);
			this.tbViaPiazza.Name = "tbViaPiazza";
			this.tbViaPiazza.Size = new System.Drawing.Size(440, 20);
			this.tbViaPiazza.TabIndex = 3;
			this.tbViaPiazza.TabStop = false;
			this.tbViaPiazza.Text = "Via/Piazza";
			// 
			// lblViaPiazza
			// 
			this.lblViaPiazza.Location = new System.Drawing.Point(8, 52);
			this.lblViaPiazza.Name = "lblViaPiazza";
			this.lblViaPiazza.Size = new System.Drawing.Size(60, 16);
			this.lblViaPiazza.TabIndex = 2;
			this.lblViaPiazza.Text = "Via/Piazza";
			// 
			// tbRagioneSociale
			// 
			this.tbRagioneSociale.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbRagioneSociale.Enabled = false;
			this.tbRagioneSociale.Location = new System.Drawing.Point(96, 22);
			this.tbRagioneSociale.Name = "tbRagioneSociale";
			this.tbRagioneSociale.Size = new System.Drawing.Size(440, 20);
			this.tbRagioneSociale.TabIndex = 1;
			this.tbRagioneSociale.TabStop = false;
			this.tbRagioneSociale.Text = "Ragione Sociale";
			// 
			// lblRagioneSociale
			// 
			this.lblRagioneSociale.Location = new System.Drawing.Point(8, 24);
			this.lblRagioneSociale.Name = "lblRagioneSociale";
			this.lblRagioneSociale.Size = new System.Drawing.Size(88, 16);
			this.lblRagioneSociale.TabIndex = 0;
			this.lblRagioneSociale.Text = "Ragione Sociale";
			// 
			// gbUtente
			// 
			this.gbUtente.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.tbStatoRichiesta,
																				   this.lblStatoRichiesta,
																				   this.tbCodiceFiscale,
																				   this.lblCodiceFiscale,
																				   this.tbDataOraIns,
																				   this.lblDataOraIns,
																				   this.tbNominativo,
																				   this.lblNominativo});
			this.gbUtente.Location = new System.Drawing.Point(4, 144);
			this.gbUtente.Name = "gbUtente";
			this.gbUtente.Size = new System.Drawing.Size(544, 112);
			this.gbUtente.TabIndex = 1;
			this.gbUtente.TabStop = false;
			this.gbUtente.Text = " Dati Utente ";
			// 
			// tbStatoRichiesta
			// 
			this.tbStatoRichiesta.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbStatoRichiesta.Enabled = false;
			this.tbStatoRichiesta.Location = new System.Drawing.Point(428, 18);
			this.tbStatoRichiesta.Name = "tbStatoRichiesta";
			this.tbStatoRichiesta.Size = new System.Drawing.Size(108, 20);
			this.tbStatoRichiesta.TabIndex = 7;
			this.tbStatoRichiesta.TabStop = false;
			this.tbStatoRichiesta.Text = "Stato Richiesta";
			// 
			// lblStatoRichiesta
			// 
			this.lblStatoRichiesta.Location = new System.Drawing.Point(352, 20);
			this.lblStatoRichiesta.Name = "lblStatoRichiesta";
			this.lblStatoRichiesta.Size = new System.Drawing.Size(76, 16);
			this.lblStatoRichiesta.TabIndex = 6;
			this.lblStatoRichiesta.Text = "Stato richiesta";
			// 
			// tbCodiceFiscale
			// 
			this.tbCodiceFiscale.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbCodiceFiscale.Enabled = false;
			this.tbCodiceFiscale.Location = new System.Drawing.Point(96, 81);
			this.tbCodiceFiscale.Name = "tbCodiceFiscale";
			this.tbCodiceFiscale.Size = new System.Drawing.Size(168, 20);
			this.tbCodiceFiscale.TabIndex = 5;
			this.tbCodiceFiscale.TabStop = false;
			this.tbCodiceFiscale.Text = "Codice Fiscale";
			// 
			// lblCodiceFiscale
			// 
			this.lblCodiceFiscale.Location = new System.Drawing.Point(8, 83);
			this.lblCodiceFiscale.Name = "lblCodiceFiscale";
			this.lblCodiceFiscale.Size = new System.Drawing.Size(84, 16);
			this.lblCodiceFiscale.TabIndex = 4;
			this.lblCodiceFiscale.Text = "Codice Fiscale";
			// 
			// tbDataOraIns
			// 
			this.tbDataOraIns.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbDataOraIns.Enabled = false;
			this.tbDataOraIns.Location = new System.Drawing.Point(392, 81);
			this.tbDataOraIns.Name = "tbDataOraIns";
			this.tbDataOraIns.Size = new System.Drawing.Size(144, 20);
			this.tbDataOraIns.TabIndex = 3;
			this.tbDataOraIns.TabStop = false;
			this.tbDataOraIns.Text = "Data/Ora Inserimento";
			// 
			// lblDataOraIns
			// 
			this.lblDataOraIns.Location = new System.Drawing.Point(276, 83);
			this.lblDataOraIns.Name = "lblDataOraIns";
			this.lblDataOraIns.Size = new System.Drawing.Size(116, 16);
			this.lblDataOraIns.TabIndex = 2;
			this.lblDataOraIns.Text = "Data/Ora Inserimento";
			// 
			// tbNominativo
			// 
			this.tbNominativo.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
			this.tbNominativo.Enabled = false;
			this.tbNominativo.Location = new System.Drawing.Point(96, 49);
			this.tbNominativo.Name = "tbNominativo";
			this.tbNominativo.Size = new System.Drawing.Size(440, 20);
			this.tbNominativo.TabIndex = 1;
			this.tbNominativo.TabStop = false;
			this.tbNominativo.Text = "Nominativo";
			// 
			// lblNominativo
			// 
			this.lblNominativo.Location = new System.Drawing.Point(8, 51);
			this.lblNominativo.Name = "lblNominativo";
			this.lblNominativo.Size = new System.Drawing.Size(64, 16);
			this.lblNominativo.TabIndex = 0;
			this.lblNominativo.Text = "Nominativo";
			// 
			// btnChiudi
			// 
			this.btnChiudi.Location = new System.Drawing.Point(472, 260);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 2;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa finestra");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnValida
			// 
			this.btnValida.Location = new System.Drawing.Point(392, 260);
			this.btnValida.Name = "btnValida";
			this.btnValida.TabIndex = 3;
			this.btnValida.Text = "&Valida";
			this.tltInfo.SetToolTip(this.btnValida, "Valida l\'Utente selezionato");
			this.btnValida.Click += new System.EventHandler(this.btnValida_Click);
			// 
			// frmDettaglioRichiestaUtente
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(548, 283);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnValida,
																		  this.btnChiudi,
																		  this.gbUtente,
																		  this.gbSocieta});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmDettaglioRichiestaUtente";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Dettaglio Richiesta Utente";
			this.gbSocieta.ResumeLayout(false);
			this.gbUtente.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			Chiudi();
		}

		private void btnValida_Click(object sender, System.EventArgs e)
		{
			string IdUtente = null;

			string IdSocietaParent = IsSocietaValidated(_drSocietaParent["IdRichiestaRegSoc"].ToString());
			// Se l'IdSocieta' e' null => la societa' di appartenenza dell'Utente non
			// e' ancora stat validata
			if (IdSocietaParent == null)
			{
				MessageBox.Show("Impossibile Validare l'Utente, validare prima la Societ� di appartenenza", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
			else
			{
				// Posso validare l'Utente perche' ho validato la Societa'
				IdUtente = ValidaUtente(IdSocietaParent, 
										_drRichiestaUtente["IdRichiestaRegUtente"].ToString());
				if ((IdUtente == null) || (IdUtente == String.Empty))
				{
					MessageBox.Show("L'Utente non � stato validato in modo corretto", "Validazione", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return;
				}
				else
				{
					MessageBox.Show("L'Utente � stato validato in modo corretto", "Validazione", MessageBoxButtons.OK, MessageBoxIcon.Information);
					_drRichiestaUtente["StatoRichiesta"] = "Valida";
					_drRichiestaUtente.EndEdit();
					this.DialogResult = DialogResult.OK;
				}
			}
		}
	}
}
