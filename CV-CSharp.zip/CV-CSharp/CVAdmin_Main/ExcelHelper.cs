using System;
using System.Globalization;
using System.Threading;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;

namespace ExcelHelper
{
	/// <summary>
	/// Questa classe serve come wrapper per accedere ad Excel
	/// </summary>
	public class spApplication : IDisposable
	{
		#region IDisposable implementation
		~spApplication()
		{
			Dispose(false);
		}

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (_disposed == false)
					_disposed = true;

				if (_a != null)
				{
					// rilascio contestualmente all'applicazione tutti
					// gli oggetti COM 
					// WeakReference serve per evitare di tenere in vita
					// gli oggetti com (dato che sono puntati da _comObj)
					// casomai entrasse il GC (infatti il GC mettera' Target = null)
					foreach (WeakReference wr in _comObj)
						if (wr.Target != null)
							Marshal.ReleaseComObject(wr.Target);
				}

				if (_cc != null)
					Thread.CurrentThread.CurrentCulture = _cc;
			}
		}
		private bool _disposed = false;
		#endregion

		/// <summary>
		/// Creare SEMPRE l'applicazione Excel utilizzando using(xlApp = new spApplication()) {...}
		/// ALTRIMENTI 1) Excel.exe rimarra' un processo attivo anche quando non serve piu'....
		/// 2) La lingua di questo thread del tuo programma sara' en-US anche quando 
		/// vorresti che fosse it-IT
		/// </summary>
		public spApplication()
		{
			bool bOldTypeLibraryError = false;
			try
			{
				_a = new Excel.ApplicationClass();
				_a.Visible = false;  // qui scatta l'eccezione della typelibrary
			}
			catch (Exception e)
			{
				// se c'e' l'errore Old Type Library....
				// (questo avviene se Excel ha lingua diversa dal SO)
				COMException ce = e as COMException;
				if (ce != null && ce.ErrorCode == unchecked((int)0x80028018))
				{
					bOldTypeLibraryError = true;
					Marshal.ReleaseComObject(_a);
					_a = null;
				}
				else
					throw e;
			}

			_cc = null;
			if (bOldTypeLibraryError)
			{
				_cc = Thread.CurrentThread.CurrentCulture;
				Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-US");
				_a = new Excel.ApplicationClass();
			}

			AddComObject(_a);

			_defaultNumberFormat = "@";
			_nullValue = "";
		}

		public spApplication(string defaultNumberFormat, string nullValue)
			: this()
		{
			_defaultNumberFormat = defaultNumberFormat;
			_nullValue = nullValue;
		}

		public bool Visible
		{
			set { _a.Visible = value; }
		}

		public int SheetsInNewWorkbook
		{
			set { _a.SheetsInNewWorkbook = value; }
		}

		public void Quit()
		{
			_a.Quit();
		}

		public spWorkbooks Workbooks 
		{
			get { return new spWorkbooks(_a.Workbooks, this); }
		}

		/// <summary>
		/// ogni oggetto COM DEVE essere registrato con questa funzione.
		/// </summary>
		public void AddComObject(object obj)
		{
			_comObj.Add(new WeakReference(obj));
		}

		public string DefaultNumberFormat
		{
			get { return _defaultNumberFormat; }
			set { _defaultNumberFormat = value; }
		}

		// Utilizzare questa CultureInfo per formattare le date/numeri ecc
		// prima di assegnarli a .Value.
		// Questa ritorna la CultureInfo impostata PRIMA di di aver istanziato
		// Excel (cosa che potrebbe cambiare Thread.CurrentThread.CurrentCulture
		public CultureInfo CurrentCulture 
		{
			get { return (_cc != null) ? _cc : Thread.CurrentThread.CurrentCulture; }
		}
		public string NullValue
		{
			get { return _nullValue; }
			set { _nullValue = value; }
		}

		private Excel.Application _a;
		CultureInfo _cc;
		string _defaultNumberFormat = "";
		string _nullValue = "";

		ArrayList _comObj = new ArrayList();
	}

	public class spWorkbooks
	{
		public spWorkbooks(Excel.Workbooks w, spApplication a)
		{
			_w = w;
			_a = a;
			_a.AddComObject(w);
		}

		public spWorkbook Add()
		{
			return new spWorkbook(_w.Add(Missing.Value), _a);
		}

		private Excel.Workbooks _w;
		spApplication _a;
	}

	public class spWorkbook
	{
		public spWorkbook(Excel.Workbook w, spApplication a)
		{
			_w = w;
			_a = a;
			_a.AddComObject(w);
		}

		public spSheets Worksheets
		{
			get { return new spSheets(_w.Worksheets, _a); }
		}

		public void Close()
		{
			_w.Close(false, Missing.Value, Missing.Value);
		}

		private Excel.Workbook _w;
		spApplication _a;
	}

	public class spSheets
	{
		public spSheets(Excel.Sheets w, spApplication a)
		{
			_w = w;
			_a = a;
			_a.AddComObject(w);
		}

		public spWorksheet this [int i]
		{
			get { return new spWorksheet(_w[i] as Excel.Worksheet, _a); }
		}

		public spWorksheet Add()
		{
			object m = Missing.Value;
			return new spWorksheet(_w.Add(m,m,m,m) as Excel.Worksheet, _a);
		}

		Excel.Sheets _w;
		spApplication _a;
	}

	public class spWorksheets
	{
		public spWorksheets(Excel.Worksheets w, spApplication a)
		{
			_w = w;
			_a = a;
			_a.AddComObject(_w);
		}

		public spWorksheet this [int i]
		{
			get { return new spWorksheet(_w[i] as Excel.Worksheet, _a); }
		}

		public spWorksheet Add()
		{
			return new spWorksheet(
				_w.Add(Missing.Value, Missing.Value, Missing.Value,Missing.Value) as Excel.Worksheet, 
				_a);
		}

		Excel.Worksheets _w;
		spApplication _a;
	}

	public class spWorksheet
	{
		public spWorksheet(Excel.Worksheet s, spApplication a)
		{
			_s = s;
			_a = a;
			_a.AddComObject(s);
		}

		public spRange Cells
		{
			get { return new spRange(_s.Cells, _a); }
		}

		public string Name
		{
			set { _s.Name = value; }
		}

		public void SaveAs(string fn)
		{
			Missing m = Missing.Value;
			_s.SaveAs(fn, m, m, m, m, m, m, m, m);
		}

		Excel.Worksheet _s;
		spApplication _a;
	}

	public class spRange
	{
		public spRange(Excel.Range r, spApplication a)
		{ 
			_r = r; 
			_a = a;
			_a.AddComObject(r);
		}

		public spRange this [int r, int c]
		{
			get { return new spRange(_r[r, c] as Excel.Range, _a); }
		}
		public spRange this [int r]
		{
			get { return new spRange(_r[r, Missing.Value] as Excel.Range, _a); }
		}
		public spCharacters Characters 
		{ 
			get { return new spCharacters(_r.get_Characters(Missing.Value, Missing.Value), _a); } 
		}
		public string NumberFormat 
		{ 
			set { _r.NumberFormat = value; } 
		}
		/// <summary>
		/// scrive nella cella. NB: viene assegnato automaticamente il
		/// DefaultNumberFormat impostato nel costruttore di spApplication.
		/// Questo e' inizializzato a "@" per indicare a Excel di prendere il testo
		/// senza apportare modifiche (data, numeri ecc)
		/// </summary>
		public string Value 
		{ 
			set 
			{ 
				if (_a.DefaultNumberFormat != null)
					_r.NumberFormat = _a.DefaultNumberFormat; 

				_r.Value = value; 
			} 
		}

		/// <summary>
		/// scrive nella cella. 
		/// </summary>
//		public string FormulaR1C1 
//		{ 
//			set 
//			{ 
//				_r.FormulaR1C1 = value; 
//			} 
//		}

		public object FormulaR1C1Object
		{ 
			set 
			{ 
				_r.FormulaR1C1 = value; 
			} 
		}



//		public void SetValue(string o                 ) { this.Value = o; }
//		public void SetValue(int o,      string format) { this.Value = o.ToString(format, _a.CurrentCulture); }
//		public void SetValue(short o,    string format) { this.Value = o.ToString(format, _a.CurrentCulture); }
//		public void SetValue(byte o,     string format) { this.Value = o.ToString(format, _a.CurrentCulture); }
//		public void SetValue(long o,     string format) { this.Value = o.ToString(format, _a.CurrentCulture); }
//		public void SetValue(char o                   ) { this.Value = o.ToString(_a.CurrentCulture); }
//		public void SetValue(bool o                   ) { this.Value = o.ToString(_a.CurrentCulture); }
//		public void SetValue(decimal o,  string format) { this.Value = o.ToString(format, _a.CurrentCulture); }
//		public void SetValue(float o,    string format) { this.Value = o.ToString(format, _a.CurrentCulture); }
//		public void SetValue(double o,   string format) { this.Value = o.ToString(format, _a.CurrentCulture); }
//		public void SetValue(DateTime o, string format) { this.Value = o.ToString(format, _a.CurrentCulture); }
//		public void SetValue(DataRow r, string columnName, string format)
//		{
//			if (r.IsNull(columnName))
//			{
//				this.Value = _a.NullValue;
//				return;
//			}
//
//			object o = r[columnName];
//			Type t = o.GetType();
//
//			     if (t == typeof(string))   this.SetValue((string)o);
//			else if (t == typeof(int   ))   this.SetValue((int)o, format);
//			else if (t == typeof(short ))   this.SetValue((short)o, format);
//			else if (t == typeof(byte  ))   this.SetValue((byte)o, format);
//			else if (t == typeof(long  ))   this.SetValue((long)o, format);
//			else if (t == typeof(char  ))   this.SetValue((char)o);
//			else if (t == typeof(bool  ))   this.SetValue((bool)o);
//			else if (t == typeof(decimal))  this.SetValue((decimal)o, format);
//			else if (t == typeof(float))    this.SetValue((float)o, format);
//			else if (t == typeof(double))   this.SetValue((double)o, format);
//			else if (t == typeof(DateTime)) this.SetValue((DateTime)o, format);
//			else
//			{
//				Debug.Assert(false, "tipo non riconosciuto");
//				this.SetValue("");
//			}
//		}

		public spRange Range(spRange r, spRange c) 
		{ 
			return new spRange(_r.get_Range(r._r, c._r), _a); 
		}
		public spRange Range(spRange r) 
		{ 
			return new spRange(_r.get_Range(r._r, Missing.Value), _a); 
		}
		public Excel.XlHAlign HorizontalAlignment 
		{ 
			set { _r.HorizontalAlignment = value; } 
		}
		public void Merge() 
		{ 
			_r.Merge(Missing.Value); 
		}
		public spRange EntireRow 
		{ 
			get { return new spRange(_r.EntireRow, _a); } 
		}
		public spRange EntireColumn 
		{ 
			get { return new spRange(_r.EntireColumn, _a); } 
		}
		public spRange Resize 
		{ 
			get { return new spRange(_r.get_Resize(Missing.Value, Missing.Value), _a); } 
		}
		public spBorders Borders 
		{ 
			get { return new spBorders(_r.Borders, _a); } 
		}
		public void AutoFit() 
		{ 
			_r.AutoFit(); 
		}

		public spInterior Interior
		{
			get { return new spInterior(_r.Interior, _a); }
		}

		private Excel.Range _r;
		spApplication _a;
	}

	public class spBorders
	{
		public spBorders(Excel.Borders b, spApplication a)
		{
			_b = b;
			_a = a;
			_a.AddComObject(_b);
		}
		public spBorder this [Excel.XlBordersIndex i]
		{
			get { return new spBorder(_b[i], _a); }
		}
		Excel.Borders _b;
		spApplication _a;
	}

	public class spBorder
	{
		public spBorder(Excel.Border b, spApplication a)
		{
			_b = b;
			_a = a;
			_a.AddComObject(b);
		}
		public int LineStyle
		{
			set { _b.LineStyle = value; }
		}
		public int Weight
		{
			set { _b.Weight = value; }
		}
		Excel.Border _b;
		spApplication _a;
	}

	public class spCharacters
	{
		public spCharacters(Excel.Characters c, spApplication a)
		{
			_c = c;
			_a = a;
			_a.AddComObject(c);
		}
		public spFont Font
		{
			get { return new spFont(_c.Font, _a); }
		}

		Excel.Characters _c;
		spApplication _a;
	}

	public class spFont
	{
		public spFont(Excel.Font f, spApplication a)
		{
			_f = f;
			_a = a;
			_a.AddComObject(f);
		}
		public bool Bold
		{
			set { _f.Bold = value; }
		}
		public int Size
		{
			set { _f.Size = value; }
		}

		Excel.Font _f; 
		spApplication _a;
	}

	public class spInterior
	{
		public spInterior(Excel.Interior i, spApplication a)
		{
			_i = i;
			_a = a;
			_a.AddComObject(i);

		}

		public int ColorIndex
		{
			set { _i.ColorIndex = value; }
		}

		public /*Excel.Constants*/Excel.XlPattern Pattern
		{
			set { _i.Pattern = value; }
		}
		public /*Excel.Constants*/Excel.XlPattern PatternColorIndex
		{
			set { _i.PatternColorIndex = value; }
		}

		Excel.Interior _i;
		spApplication _a;
	}
}
