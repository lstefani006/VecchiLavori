using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ExcelHelper;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmGestRichieste.
	/// </summary>
	public class frmGestRichieste : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TabControl tcSocietaUtenti;
		private System.Windows.Forms.TabPage tpSocieta;
		private System.Windows.Forms.TabPage tpUtenti;
		private System.Windows.Forms.GroupBox gbSocieta;
		private System.Windows.Forms.Label lblRagioneSociale;
		private System.Windows.Forms.TextBox tbRagioneSociale;
		private System.Windows.Forms.Label lblCodiceFiscale;
		private System.Windows.Forms.TextBox tbCodiceFiscale;
		private System.Windows.Forms.Label lblPartitaIVA;
		private System.Windows.Forms.ComboBox cbStatoRichiesta;
		private System.Windows.Forms.Label lblStatoRichiesta;
		private System.Windows.Forms.GroupBox gbCoordinatebancarie;
		private System.Windows.Forms.Label lblABI;
		private System.Windows.Forms.TextBox tbABI;
		private System.Windows.Forms.Label lblCAB;
		private System.Windows.Forms.TextBox tbCAB;
		private System.Windows.Forms.Label lblCC;
		private System.Windows.Forms.TextBox tbCC;
		private System.Windows.Forms.DataGrid dgRichiesteSocieta;
		private System.Windows.Forms.DataGrid dgRichiesteUtenti;
		private System.Windows.Forms.Button btnChiudi;
		private System.Windows.Forms.TextBox tbPartitaIVA;
		private System.Windows.Forms.ToolTip tltInfo;
		private System.Windows.Forms.GroupBox gbUtenti;
		private System.Windows.Forms.Label lblNominativo;
		private System.Windows.Forms.TextBox tbNominativo;
		private System.Windows.Forms.Label lblCodiceFiscaleU;
		private System.Windows.Forms.TextBox tbCodiceFiscaleU;
		private System.Windows.Forms.Label lblStatorichiestaU;
		private System.Windows.Forms.ComboBox cbStatoRichiestaU;
		private System.ComponentModel.IContainer components;

		enum DGSocietaColumnID
		{
			cRagioneSociale = 0,
			cCodiceFiscale,
			cPartitaIVA,
			cDataOraInserimento,
			cStatoRichiesta,
			cABI,
			cCAB,
			cCC,
			cCodiceConto,
			// DEVE essere sempre l'ultimo elemento
			cALL
		};

		internal class cbBind
		{
			public cbBind(string s) { _name = s; _value = "";}
			public cbBind(string s, string t) { _name = s; _value = t;}
			public string Name { get { return _name; } }
			public string Value { get { return _value; } }
			string _name;
			string _value;
		}

		private DataSet		_dsListaRichiesteSocietaUtenti = null;
		private DataView	_dvRichiesteSocieta = null;
		private System.Windows.Forms.Button btnExcel;
		private System.Windows.Forms.SaveFileDialog dlgEsportaXls;
		private System.Windows.Forms.TextBox tbCodiceConto;
		private System.Windows.Forms.Label lblCodiceConto;
		private System.Windows.Forms.Label lblCodConto;
		private System.Windows.Forms.TextBox tbCodConto;
		private DataView	_dvRichiesteUtenti  = null;

		public frmGestRichieste()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Recupero dal DB le informazioni sulle richieste di registrazione
			// delle societa'
			_dsListaRichiesteSocietaUtenti = GetListaRichiesteSocieta();
			if (_dsListaRichiesteSocietaUtenti == null)
			{
				DisabilitaComponenti();
				return;
			}

			// Binding dei componenti con le Sorgenti dati
			BindComponents();

			// Mapping tra le colonne della tabella delle richieste di
			// registrazione delle societa' ed il DataGrid
			SetDataGridRichiesteSocietaMapping();
			SetDataGridRichiesteUtentiMapping();
			InizializzaStorico();
		}

		public DataRow CurrentRowSocieta
		{
			get 
			{
				DataTable dt = _dsListaRichiesteSocietaUtenti.Tables[0];

				BindingManagerBase bm = dgRichiesteSocieta.BindingContext[dgRichiesteSocieta.DataSource, dgRichiesteSocieta.DataMember];
				if (bm.Count == 0) // numero di righe = 0
					return null;

				DataRow dr = ((DataRowView)bm.Current).Row; 
				return dr;
			}
		}

		public DataRow CurrentRowUtente
		{
			get 
			{
				DataTable dt = _dsListaRichiesteSocietaUtenti.Tables[1];

				BindingManagerBase bm = dgRichiesteSocieta.BindingContext[dgRichiesteUtenti.DataSource, dgRichiesteUtenti.DataMember];
				if (bm.Count == 0) // numero di righe = 0
					return null;

				DataRow dr = ((DataRowView)bm.Current).Row; 
				return dr;
			}
		}

		#region Funzioni interne

		private void EsportaExcel()
		{
			dlgEsportaXls.InitialDirectory = UtilityEnvironment.CommonAppDir;
			if (dlgEsportaXls.ShowDialog() != DialogResult.OK)
				return;

			this.Enabled = false;
			Application.DoEvents();
			this.Enabled = true;

			try
			{
				using (WaitCursor wc = new WaitCursor())
				{
					using (spApplication xlApp = new spApplication())
					{
						Excel.XlBordersIndex xlEdgeRight  = Excel.XlBordersIndex.xlEdgeRight;
						Excel.XlBordersIndex xlEdgeLeft   = Excel.XlBordersIndex.xlEdgeLeft;
						Excel.XlBordersIndex xlEdgeBottom = Excel.XlBordersIndex.xlEdgeBottom;
						Excel.XlBordersIndex xlEdgeTop    = Excel.XlBordersIndex.xlEdgeTop;

						Excel.XlHAlign xlHAlignGeneral    = Excel.XlHAlign.xlHAlignGeneral;

						string exportFileName = dlgEsportaXls.FileName;

						// xlApp.Visible = true;
						xlApp.SheetsInNewWorkbook = 1;

						spWorkbook xlBook = xlApp.Workbooks.Add();

						spWorksheet xlSheet = xlBook.Worksheets[1];
						xlSheet.Name = "Elenco Richiedenti";

						// Titolo
						// --------------------------------------------
						xlSheet.Cells[1, 1].Characters.Font.Size = 11;
						xlSheet.Cells[1, 1].Characters.Font.Bold = true;
						xlSheet.Cells[1, 1].Value = "Elenco Richiedenti";
						xlSheet.Cells.Range(xlSheet.Cells[1, 1], xlSheet.Cells[1, 5]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[1, 1], xlSheet.Cells[1, 5]).Merge();

						// Riga Intestazione
						// --------------------------------------------
						xlSheet.Cells.EntireRow[3].Characters.Font.Size = 10;
						xlSheet.Cells.EntireRow[3].Characters.Font.Bold = true;
    
						// Prima Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 8].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 8].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells[3, 1].Borders[xlEdgeLeft].LineStyle = 7;
						xlSheet.Cells[3, 1].Borders[xlEdgeLeft].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 8]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 8]).Merge();
						xlSheet.Cells[3, 1].Value = "Ragione Sociale";
    
						// Seconda Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 10].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 10].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 9], xlSheet.Cells[3, 10]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 9], xlSheet.Cells[3, 10]).Merge();
						xlSheet.Cells[3, 9].Value = "Codice Fiscale";
					    
						// Terza Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 12].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 12].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 11], xlSheet.Cells[3, 12]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 11], xlSheet.Cells[3, 12]).Merge();
						xlSheet.Cells[3, 11].Value = "Partita IVA";
					    
						// Quarta Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 14].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 14].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 13], xlSheet.Cells[3, 14]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 13], xlSheet.Cells[3, 14]).Merge();
						xlSheet.Cells[3, 13].Value = "Stato Richiesta";

						// Quinta Colonna Intestazione
						// --------------------------------------------
						xlSheet.Cells[3, 16].Borders[xlEdgeRight].LineStyle = 7;
						xlSheet.Cells[3, 16].Borders[xlEdgeRight].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 15], xlSheet.Cells[3, 16]).HorizontalAlignment = xlHAlignGeneral;
						xlSheet.Cells.Range(xlSheet.Cells[3, 15], xlSheet.Cells[3, 16]).Merge();
						xlSheet.Cells[3, 15].Value = "Codice Conto";
					    
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 16]).Borders[xlEdgeBottom].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 16]).Borders[xlEdgeTop].LineStyle = 7;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 16]).Borders[xlEdgeBottom].Weight = 3;
						xlSheet.Cells.Range(xlSheet.Cells[3, 1], xlSheet.Cells[3, 16]).Borders[xlEdgeTop].Weight = 3;

						// RIGHE DATI
						int riga = 4;
						for (int rowCounter = 0; rowCounter < GetDataGridRowsNumber(); rowCounter++, riga++)
						{
							xlSheet.Cells.EntireRow[riga].Characters.Font.Size = 8;
							xlSheet.Cells.EntireRow[riga].Characters.Font.Bold = false;

							if ((rowCounter & 1) == 0)
							{
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 16]).Interior.ColorIndex = 15;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 16]).Interior.Pattern = Excel.XlPattern.xlPatternSolid;
								xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 16]).Interior.PatternColorIndex = Excel.XlPattern.xlPatternAutomatic;
							}

							xlSheet.Cells.EntireRow[riga].Characters.Font.Size = 8;
							xlSheet.Cells.EntireRow[riga].Characters.Font.Bold = false;
					        
							xlSheet.Cells[riga, 1].Borders[xlEdgeLeft].LineStyle = 7;
							xlSheet.Cells[riga, 1].Borders[xlEdgeLeft].Weight = 3;
							xlSheet.Cells[riga, 8].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 8].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 8]).Merge();
							xlSheet.Cells[riga, 1].NumberFormat = "@";
							xlSheet.Cells[riga, 1].Value = dgRichiesteSocieta[rowCounter, (int)DGSocietaColumnID.cRagioneSociale].ToString();
					        
							xlSheet.Cells[riga, 10].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 10].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 9], xlSheet.Cells[riga, 10]).Merge();
							xlSheet.Cells[riga, 9].NumberFormat = "@";
							xlSheet.Cells[riga, 9].Value = dgRichiesteSocieta[rowCounter, (int)DGSocietaColumnID.cCodiceFiscale].ToString();
					        
							xlSheet.Cells[riga, 12].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 12].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 11], xlSheet.Cells[riga, 12]).Merge();
							xlSheet.Cells[riga, 11].NumberFormat = "@";
							xlSheet.Cells[riga, 11].Value = dgRichiesteSocieta[rowCounter, (int)DGSocietaColumnID.cPartitaIVA].ToString();
					        
							xlSheet.Cells[riga, 14].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 14].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 13], xlSheet.Cells[riga, 14]).Merge();
							xlSheet.Cells[riga, 13].NumberFormat = "@";
							xlSheet.Cells[riga, 13].Value = dgRichiesteSocieta[rowCounter, (int)DGSocietaColumnID.cStatoRichiesta].ToString();

							xlSheet.Cells[riga, 16].Borders[xlEdgeRight].LineStyle = 7;
							xlSheet.Cells[riga, 16].Borders[xlEdgeRight].Weight = 3;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 15], xlSheet.Cells[riga, 16]).Merge();
							xlSheet.Cells[riga, 15].NumberFormat = "@";
							xlSheet.Cells[riga, 15].Value = dgRichiesteSocieta[rowCounter, (int)DGSocietaColumnID.cCodiceConto].ToString();
					    
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 16]).Borders[xlEdgeBottom].LineStyle = 7;
							xlSheet.Cells.Range(xlSheet.Cells[riga, 1], xlSheet.Cells[riga, 16]).Borders[xlEdgeBottom].Weight = 3;
						}

						for (int X = 1; X < GetDataGridRowsNumber(); ++X)
							xlSheet.Cells.EntireColumn[X].Resize.AutoFit();

						try { System.IO.File.Delete(exportFileName); } 
						catch (Exception) {} // eccezione se il file non esiste
						xlSheet.SaveAs(exportFileName);
						xlBook.Close();
						xlApp.Quit();
					}
				}
				MessageBox.Show("Foglio Excel generato con successo", "Messaggio", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void ChiudiForm()
		{
			this.DialogResult = DialogResult.Cancel;
		}


		private void DisabilitaComponenti()
		{
			tcSocietaUtenti.Enabled = false;
			// Devo poter uscire dalla Form
			btnChiudi.Enabled = true;
		}

		public int GetDataGridRowsNumber()
		{
			BindingManagerBase bmDataGrid = dgRichiesteSocieta.BindingContext[dgRichiesteSocieta.DataSource];
			return bmDataGrid.Count;
		}

		private void BindComponents()
		{
			// BINDING TAB PANEL RICHIESTA SOCIETA'
			// Non posso fare il Binding se il DataSet e' nullo
			if (_dsListaRichiesteSocietaUtenti == null)
			{
				return;
			}
			
			// Binding con il DataGrid
			_dvRichiesteSocieta = new DataView(_dsListaRichiesteSocietaUtenti.Tables[0]);
			_dvRichiesteSocieta.AllowDelete = false;
			_dvRichiesteSocieta.AllowEdit   = false;
			_dvRichiesteSocieta.AllowNew    = false;
			dgRichiesteSocieta.DataSource = _dvRichiesteSocieta;

			// Evento scatenato quando si cambia il filtro del DataView
			_dvRichiesteSocieta.ListChanged  += new System.ComponentModel.ListChangedEventHandler(_dvRichiesteSocieta_OnListChanged);
			
			cbBind [] cbListSocieta = 
			{ 
				new cbBind("<qualunque stato>", ""),
				new cbBind("Da Validare", "Da Validare"),
				new cbBind("Non Valida", "Non Valida"),
				new cbBind("Valida", "Valida")
			};
			cbStatoRichiesta.DisplayMember = "Name";
			cbStatoRichiesta.ValueMember   = "Value";
			cbStatoRichiesta.DataSource = cbListSocieta;
			cbStatoRichiesta.SelectedIndex = 0;

			// BINDING TAB PANEL RICHIESTA UTENTI
			// Binding con il DataGrid
			_dvRichiesteUtenti = new DataView(_dsListaRichiesteSocietaUtenti.Tables[1]);
			_dvRichiesteUtenti.AllowDelete = false;
			_dvRichiesteUtenti.AllowEdit   = false;
			_dvRichiesteUtenti.AllowNew    = false;
			dgRichiesteUtenti.DataSource = _dvRichiesteUtenti;

			cbBind [] cbListUtenti = 
			{ 
				new cbBind("<qualunque stato>", ""),
				new cbBind("Da Validare", "Da Validare"),
				new cbBind("Non Valida", "Non Valida"),
				new cbBind("Valida", "Valida")
			};

			cbStatoRichiestaU.DisplayMember = "Name";
			cbStatoRichiestaU.ValueMember   = "Value";
			cbStatoRichiestaU.DataSource = cbListUtenti;
		}

		private void SetDataGridRichiesteSocietaMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[(int)DGSocietaColumnID.cALL];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();
			
			int index = (int)DGSocietaColumnID.cRagioneSociale;
			// Colonna 0 - RAGIONE SOCIALE
			dgCol[index].HeaderText = "Ragione Sociale";
			dgCol[index].MappingName = "RagioneSociale";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";
	
			index = (int)DGSocietaColumnID.cCodiceFiscale;
			// Colonna 1 - CODICE FISCALE
			dgCol[index].HeaderText = "Codice Fiscale";
			dgCol[index].MappingName = "CodiceFiscale";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			index = (int)DGSocietaColumnID.cPartitaIVA;
			// Colonna 2 - PARTITA IVA
			dgCol[index].HeaderText = "Partita IVA";
			dgCol[index].MappingName = "PartitaIVA";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			index = (int)DGSocietaColumnID.cDataOraInserimento;
			// Colonna 3 - DATA ORA INSERIMENTO 
			dgCol[index].HeaderText = "Data/Ora Inserimento";
			dgCol[index].MappingName = "DataOraInserimento";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			index = (int)DGSocietaColumnID.cStatoRichiesta;
			// Colonna 4 - STATO RICHIESTA
			dgCol[index].HeaderText = "Stato Richiesta";
			dgCol[index].MappingName = "StatoRichiesta";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			index = (int)DGSocietaColumnID.cABI;
			// Colonna 5 - ABI
			dgCol[index].HeaderText = "ABI";
			dgCol[index].MappingName = "ABI";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			index = (int)DGSocietaColumnID.cCAB;
			// Colonna 6 - CAB
			dgCol[index].HeaderText = "CAB";
			dgCol[index].MappingName = "CAB";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";


			index = (int)DGSocietaColumnID.cCC;
			// Colonna 7 - CC
			dgCol[index].HeaderText = "CC";
			dgCol[index].MappingName = "CC";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			index = (int)DGSocietaColumnID.cCodiceConto;
			// Colonna 8 - CodiceConto
			dgCol[index].HeaderText = "Codice Conto";
			dgCol[index].MappingName = "CodiceConto";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "RichiestaSocieta";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgRichiesteSocieta.TableStyles.Add(dgStyle);
		}

		private void SetDataGridRichiesteUtentiMapping()
		{
			DataGridTextBoxColumn [] dgCol = new DataGridTextBoxColumn[6];
			for (int i = 0; i < dgCol.Length; ++i)
				dgCol[i] = new DataGridTextBoxColumn();
			
			int index = 0;
			// Colonna 0 - NOMINATIVO
			dgCol[index].HeaderText = "Nominativo";
			dgCol[index].MappingName = "Nominativo";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";
	
			index++;
			// Colonna 1 - CODICE FISCALE
			dgCol[index].HeaderText = "Codice Fiscale";
			dgCol[index].MappingName = "CodiceFiscale";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			index++;
			// Colonna 2 - STATO RICHIESTA
			dgCol[index].HeaderText = "Stato Richiesta";
			dgCol[index].MappingName = "StatoRichiesta";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			index++;
			// Colonna 3 - DATA ORA INSERIMENTO 
			dgCol[index].HeaderText = "Data/Ora Inserimento";
			dgCol[index].MappingName = "DataOraInserimento";
			dgCol[index].Width = 210;
			dgCol[index].NullText = "";

			// Colonna 4
			index++;
			dgCol[index].HeaderText = "Societa`";
			dgCol[index].MappingName = "RagioneSociale";
			dgCol[index].Width = 210;

			// Colonna 5
			index++;
			dgCol[index].HeaderText = "Codice Conto societa`";
			dgCol[index].MappingName = "CodiceConto";
			dgCol[index].Width = 210;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "RichiestaUtenti";
			dgStyle.GridColumnStyles.AddRange(dgCol);
			dgRichiesteUtenti.TableStyles.Add(dgStyle);
		}

		private void ChangeRowFilterDataGridRichiesteSocieta()
		{
			string filter = null;

			filter = "RagioneSociale LIKE '" + tbRagioneSociale.Text + "%' ";
			filter += "AND PartitaIVA LIKE '" + tbPartitaIVA.Text + "%' ";
			filter += "AND CodiceFiscale LIKE '" + tbCodiceFiscale.Text + "%' ";
			filter += "AND StatoRichiesta LIKE '" + cbStatoRichiesta.SelectedValue + "%' ";
			filter += "AND ABI LIKE '" + tbABI.Text + "%' ";
			filter += "AND CAB LIKE '" + tbCAB.Text + "%' ";
			filter += "AND CC LIKE '" + tbCC.Text + "%' ";
			filter += "AND CodiceConto LIKE '" + tbCodiceConto.Text + "%'";
			
			if (filter != String.Empty)
			{
				_dvRichiesteSocieta.RowFilter = filter;
			}
		}

		private void ChangeRowFilterDataGridRichiesteUtenti()
		{
			string filter = null;

			filter = "Nominativo LIKE '" + tbNominativo.Text + "%' ";
			filter += "AND CodiceFiscale LIKE '" + tbCodiceFiscaleU.Text + "%' ";
			filter += "AND StatoRichiesta LIKE '" + cbStatoRichiestaU.SelectedValue + "%' ";
			filter += "AND CodiceConto LIKE '" + tbCodConto.Text + "%' ";
			
			if (filter != String.Empty)
			{
				_dvRichiesteUtenti.RowFilter = filter;
			}
		}

		#endregion

		#region Chiamate ai Web Services

		private void InizializzaStorico()
		{
			bool Cancelled;
			frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLSocieta.BLSocieta.InizializzaStorico");

			if (Cancelled)
				return ;
		}

		private DataSet GetListaRichiesteSocieta()
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLRichieste.BLRichieste.Search");

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		#endregion

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmGestRichieste));
			this.tcSocietaUtenti = new System.Windows.Forms.TabControl();
			this.tpSocieta = new System.Windows.Forms.TabPage();
			this.dgRichiesteSocieta = new System.Windows.Forms.DataGrid();
			this.gbCoordinatebancarie = new System.Windows.Forms.GroupBox();
			this.tbCC = new System.Windows.Forms.TextBox();
			this.lblCC = new System.Windows.Forms.Label();
			this.tbCAB = new System.Windows.Forms.TextBox();
			this.lblCAB = new System.Windows.Forms.Label();
			this.tbABI = new System.Windows.Forms.TextBox();
			this.lblABI = new System.Windows.Forms.Label();
			this.gbSocieta = new System.Windows.Forms.GroupBox();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.tbCodiceConto = new System.Windows.Forms.TextBox();
			this.lblStatoRichiesta = new System.Windows.Forms.Label();
			this.cbStatoRichiesta = new System.Windows.Forms.ComboBox();
			this.tbPartitaIVA = new System.Windows.Forms.TextBox();
			this.lblPartitaIVA = new System.Windows.Forms.Label();
			this.tbCodiceFiscale = new System.Windows.Forms.TextBox();
			this.lblCodiceFiscale = new System.Windows.Forms.Label();
			this.tbRagioneSociale = new System.Windows.Forms.TextBox();
			this.lblRagioneSociale = new System.Windows.Forms.Label();
			this.tpUtenti = new System.Windows.Forms.TabPage();
			this.gbUtenti = new System.Windows.Forms.GroupBox();
			this.tbCodConto = new System.Windows.Forms.TextBox();
			this.lblCodConto = new System.Windows.Forms.Label();
			this.cbStatoRichiestaU = new System.Windows.Forms.ComboBox();
			this.lblStatorichiestaU = new System.Windows.Forms.Label();
			this.tbCodiceFiscaleU = new System.Windows.Forms.TextBox();
			this.lblCodiceFiscaleU = new System.Windows.Forms.Label();
			this.tbNominativo = new System.Windows.Forms.TextBox();
			this.lblNominativo = new System.Windows.Forms.Label();
			this.dgRichiesteUtenti = new System.Windows.Forms.DataGrid();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
			this.btnExcel = new System.Windows.Forms.Button();
			this.dlgEsportaXls = new System.Windows.Forms.SaveFileDialog();
			this.tcSocietaUtenti.SuspendLayout();
			this.tpSocieta.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgRichiesteSocieta)).BeginInit();
			this.gbCoordinatebancarie.SuspendLayout();
			this.gbSocieta.SuspendLayout();
			this.tpUtenti.SuspendLayout();
			this.gbUtenti.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgRichiesteUtenti)).BeginInit();
			this.SuspendLayout();
			// 
			// tcSocietaUtenti
			// 
			this.tcSocietaUtenti.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tcSocietaUtenti.Controls.Add(this.tpSocieta);
			this.tcSocietaUtenti.Controls.Add(this.tpUtenti);
			this.tcSocietaUtenti.Location = new System.Drawing.Point(4, 4);
			this.tcSocietaUtenti.Name = "tcSocietaUtenti";
			this.tcSocietaUtenti.SelectedIndex = 0;
			this.tcSocietaUtenti.Size = new System.Drawing.Size(668, 484);
			this.tcSocietaUtenti.TabIndex = 0;
			// 
			// tpSocieta
			// 
			this.tpSocieta.Controls.Add(this.dgRichiesteSocieta);
			this.tpSocieta.Controls.Add(this.gbCoordinatebancarie);
			this.tpSocieta.Controls.Add(this.gbSocieta);
			this.tpSocieta.Location = new System.Drawing.Point(4, 22);
			this.tpSocieta.Name = "tpSocieta";
			this.tpSocieta.Size = new System.Drawing.Size(660, 458);
			this.tpSocieta.TabIndex = 0;
			this.tpSocieta.Text = "Societ�";
			// 
			// dgRichiesteSocieta
			// 
			this.dgRichiesteSocieta.AllowNavigation = false;
			this.dgRichiesteSocieta.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgRichiesteSocieta.CaptionText = "Lista Richieste";
			this.dgRichiesteSocieta.DataMember = "";
			this.dgRichiesteSocieta.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgRichiesteSocieta.Location = new System.Drawing.Point(3, 215);
			this.dgRichiesteSocieta.Name = "dgRichiesteSocieta";
			this.dgRichiesteSocieta.Size = new System.Drawing.Size(657, 241);
			this.dgRichiesteSocieta.TabIndex = 2;
			this.dgRichiesteSocieta.TabStop = false;
			this.tltInfo.SetToolTip(this.dgRichiesteSocieta, "Lista Richieste");
			this.dgRichiesteSocieta.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgRichiesteSocieta_MouseDown);
			this.dgRichiesteSocieta.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgRichiesteSocieta_MouseUp);
			// 
			// gbCoordinatebancarie
			// 
			this.gbCoordinatebancarie.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbCoordinatebancarie.Controls.Add(this.tbCC);
			this.gbCoordinatebancarie.Controls.Add(this.lblCC);
			this.gbCoordinatebancarie.Controls.Add(this.tbCAB);
			this.gbCoordinatebancarie.Controls.Add(this.lblCAB);
			this.gbCoordinatebancarie.Controls.Add(this.tbABI);
			this.gbCoordinatebancarie.Controls.Add(this.lblABI);
			this.gbCoordinatebancarie.Location = new System.Drawing.Point(3, 158);
			this.gbCoordinatebancarie.Name = "gbCoordinatebancarie";
			this.gbCoordinatebancarie.Size = new System.Drawing.Size(657, 52);
			this.gbCoordinatebancarie.TabIndex = 1;
			this.gbCoordinatebancarie.TabStop = false;
			this.gbCoordinatebancarie.Text = " Coordinate Bancarie ";
			// 
			// tbCC
			// 
			this.tbCC.Location = new System.Drawing.Point(432, 20);
			this.tbCC.Name = "tbCC";
			this.tbCC.Size = new System.Drawing.Size(136, 20);
			this.tbCC.TabIndex = 3;
			this.tbCC.Text = "";
			this.tltInfo.SetToolTip(this.tbCC, "Filtra per CC");
			this.tbCC.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblCC
			// 
			this.lblCC.Location = new System.Drawing.Point(407, 22);
			this.lblCC.Name = "lblCC";
			this.lblCC.Size = new System.Drawing.Size(24, 16);
			this.lblCC.TabIndex = 4;
			this.lblCC.Text = "CC";
			// 
			// tbCAB
			// 
			this.tbCAB.Location = new System.Drawing.Point(231, 20);
			this.tbCAB.Name = "tbCAB";
			this.tbCAB.Size = new System.Drawing.Size(160, 20);
			this.tbCAB.TabIndex = 2;
			this.tbCAB.Text = "";
			this.tltInfo.SetToolTip(this.tbCAB, "Filtra per CAB");
			this.tbCAB.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblCAB
			// 
			this.lblCAB.Location = new System.Drawing.Point(197, 22);
			this.lblCAB.Name = "lblCAB";
			this.lblCAB.Size = new System.Drawing.Size(32, 16);
			this.lblCAB.TabIndex = 2;
			this.lblCAB.Text = "CAB";
			// 
			// tbABI
			// 
			this.tbABI.Location = new System.Drawing.Point(52, 20);
			this.tbABI.Name = "tbABI";
			this.tbABI.Size = new System.Drawing.Size(132, 20);
			this.tbABI.TabIndex = 1;
			this.tbABI.Text = "";
			this.tltInfo.SetToolTip(this.tbABI, "Filtra per ABI");
			this.tbABI.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblABI
			// 
			this.lblABI.Location = new System.Drawing.Point(13, 22);
			this.lblABI.Name = "lblABI";
			this.lblABI.Size = new System.Drawing.Size(32, 16);
			this.lblABI.TabIndex = 0;
			this.lblABI.Text = "ABI";
			// 
			// gbSocieta
			// 
			this.gbSocieta.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbSocieta.Controls.Add(this.lblCodiceConto);
			this.gbSocieta.Controls.Add(this.tbCodiceConto);
			this.gbSocieta.Controls.Add(this.lblStatoRichiesta);
			this.gbSocieta.Controls.Add(this.cbStatoRichiesta);
			this.gbSocieta.Controls.Add(this.tbPartitaIVA);
			this.gbSocieta.Controls.Add(this.lblPartitaIVA);
			this.gbSocieta.Controls.Add(this.tbCodiceFiscale);
			this.gbSocieta.Controls.Add(this.lblCodiceFiscale);
			this.gbSocieta.Controls.Add(this.tbRagioneSociale);
			this.gbSocieta.Controls.Add(this.lblRagioneSociale);
			this.gbSocieta.Location = new System.Drawing.Point(3, 4);
			this.gbSocieta.Name = "gbSocieta";
			this.gbSocieta.Size = new System.Drawing.Size(657, 152);
			this.gbSocieta.TabIndex = 0;
			this.gbSocieta.TabStop = false;
			this.gbSocieta.Text = " Criteri di Ricerca ";
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Location = new System.Drawing.Point(8, 120);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(88, 16);
			this.lblCodiceConto.TabIndex = 8;
			this.lblCodiceConto.Text = "Codice Conto";
			// 
			// tbCodiceConto
			// 
			this.tbCodiceConto.Location = new System.Drawing.Point(100, 120);
			this.tbCodiceConto.Name = "tbCodiceConto";
			this.tbCodiceConto.Size = new System.Drawing.Size(360, 20);
			this.tbCodiceConto.TabIndex = 5;
			this.tbCodiceConto.Text = "";
			this.tltInfo.SetToolTip(this.tbCodiceConto, "Filtra per Codice Conto");
			this.tbCodiceConto.TextChanged += new System.EventHandler(this.tbCodiceConto_TextChanged);
			// 
			// lblStatoRichiesta
			// 
			this.lblStatoRichiesta.Location = new System.Drawing.Point(8, 96);
			this.lblStatoRichiesta.Name = "lblStatoRichiesta";
			this.lblStatoRichiesta.Size = new System.Drawing.Size(88, 16);
			this.lblStatoRichiesta.TabIndex = 7;
			this.lblStatoRichiesta.Text = "Stato Richiesta";
			// 
			// cbStatoRichiesta
			// 
			this.cbStatoRichiesta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbStatoRichiesta.Location = new System.Drawing.Point(100, 96);
			this.cbStatoRichiesta.Name = "cbStatoRichiesta";
			this.cbStatoRichiesta.Size = new System.Drawing.Size(168, 21);
			this.cbStatoRichiesta.TabIndex = 4;
			this.tltInfo.SetToolTip(this.cbStatoRichiesta, "Filtra per Stato Richiesta");
			this.cbStatoRichiesta.SelectedIndexChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// tbPartitaIVA
			// 
			this.tbPartitaIVA.Location = new System.Drawing.Point(100, 72);
			this.tbPartitaIVA.Name = "tbPartitaIVA";
			this.tbPartitaIVA.Size = new System.Drawing.Size(360, 20);
			this.tbPartitaIVA.TabIndex = 3;
			this.tbPartitaIVA.Text = "";
			this.tltInfo.SetToolTip(this.tbPartitaIVA, "Filtra per Partita IVA");
			this.tbPartitaIVA.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblPartitaIVA
			// 
			this.lblPartitaIVA.Location = new System.Drawing.Point(8, 72);
			this.lblPartitaIVA.Name = "lblPartitaIVA";
			this.lblPartitaIVA.Size = new System.Drawing.Size(60, 16);
			this.lblPartitaIVA.TabIndex = 4;
			this.lblPartitaIVA.Text = "Partita IVA";
			// 
			// tbCodiceFiscale
			// 
			this.tbCodiceFiscale.Location = new System.Drawing.Point(100, 48);
			this.tbCodiceFiscale.Name = "tbCodiceFiscale";
			this.tbCodiceFiscale.Size = new System.Drawing.Size(360, 20);
			this.tbCodiceFiscale.TabIndex = 2;
			this.tbCodiceFiscale.Text = "";
			this.tltInfo.SetToolTip(this.tbCodiceFiscale, "Filtra per Codice Fiscale");
			this.tbCodiceFiscale.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblCodiceFiscale
			// 
			this.lblCodiceFiscale.Location = new System.Drawing.Point(8, 48);
			this.lblCodiceFiscale.Name = "lblCodiceFiscale";
			this.lblCodiceFiscale.Size = new System.Drawing.Size(84, 16);
			this.lblCodiceFiscale.TabIndex = 2;
			this.lblCodiceFiscale.Text = "Codice Fiscale";
			// 
			// tbRagioneSociale
			// 
			this.tbRagioneSociale.Location = new System.Drawing.Point(100, 24);
			this.tbRagioneSociale.Name = "tbRagioneSociale";
			this.tbRagioneSociale.Size = new System.Drawing.Size(360, 20);
			this.tbRagioneSociale.TabIndex = 1;
			this.tbRagioneSociale.Text = "";
			this.tltInfo.SetToolTip(this.tbRagioneSociale, "Filtra per Ragione Sociale");
			this.tbRagioneSociale.TextChanged += new System.EventHandler(this.tbRagioneSociale_TextChanged);
			// 
			// lblRagioneSociale
			// 
			this.lblRagioneSociale.Location = new System.Drawing.Point(8, 24);
			this.lblRagioneSociale.Name = "lblRagioneSociale";
			this.lblRagioneSociale.Size = new System.Drawing.Size(88, 16);
			this.lblRagioneSociale.TabIndex = 0;
			this.lblRagioneSociale.Text = "Ragione Sociale";
			// 
			// tpUtenti
			// 
			this.tpUtenti.Controls.Add(this.gbUtenti);
			this.tpUtenti.Controls.Add(this.dgRichiesteUtenti);
			this.tpUtenti.Location = new System.Drawing.Point(4, 22);
			this.tpUtenti.Name = "tpUtenti";
			this.tpUtenti.Size = new System.Drawing.Size(660, 458);
			this.tpUtenti.TabIndex = 1;
			this.tpUtenti.Text = "Utenti";
			// 
			// gbUtenti
			// 
			this.gbUtenti.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gbUtenti.Controls.Add(this.tbCodConto);
			this.gbUtenti.Controls.Add(this.lblCodConto);
			this.gbUtenti.Controls.Add(this.cbStatoRichiestaU);
			this.gbUtenti.Controls.Add(this.lblStatorichiestaU);
			this.gbUtenti.Controls.Add(this.tbCodiceFiscaleU);
			this.gbUtenti.Controls.Add(this.lblCodiceFiscaleU);
			this.gbUtenti.Controls.Add(this.tbNominativo);
			this.gbUtenti.Controls.Add(this.lblNominativo);
			this.gbUtenti.Location = new System.Drawing.Point(3, 4);
			this.gbUtenti.Name = "gbUtenti";
			this.gbUtenti.Size = new System.Drawing.Size(657, 120);
			this.gbUtenti.TabIndex = 1;
			this.gbUtenti.TabStop = false;
			this.gbUtenti.Text = " Criteri di Ricerca ";
			// 
			// tbCodConto
			// 
			this.tbCodConto.Location = new System.Drawing.Point(96, 88);
			this.tbCodConto.Name = "tbCodConto";
			this.tbCodConto.Size = new System.Drawing.Size(348, 20);
			this.tbCodConto.TabIndex = 6;
			this.tbCodConto.Text = "";
			this.tltInfo.SetToolTip(this.tbCodConto, "Filtra per Codice Conto");
			this.tbCodConto.TextChanged += new System.EventHandler(this.tbCodConto_TextChanged);
			// 
			// lblCodConto
			// 
			this.lblCodConto.Location = new System.Drawing.Point(8, 88);
			this.lblCodConto.Name = "lblCodConto";
			this.lblCodConto.Size = new System.Drawing.Size(80, 16);
			this.lblCodConto.TabIndex = 5;
			this.lblCodConto.Text = "Codice Conto";
			// 
			// cbStatoRichiestaU
			// 
			this.cbStatoRichiestaU.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbStatoRichiestaU.Location = new System.Drawing.Point(96, 64);
			this.cbStatoRichiestaU.Name = "cbStatoRichiestaU";
			this.cbStatoRichiestaU.Size = new System.Drawing.Size(176, 21);
			this.cbStatoRichiestaU.TabIndex = 3;
			this.tltInfo.SetToolTip(this.cbStatoRichiestaU, "Filtra per Stato Richiesta");
			this.cbStatoRichiestaU.SelectedIndexChanged += new System.EventHandler(this.tbNominativo_TextChanged);
			// 
			// lblStatorichiestaU
			// 
			this.lblStatorichiestaU.Location = new System.Drawing.Point(8, 64);
			this.lblStatorichiestaU.Name = "lblStatorichiestaU";
			this.lblStatorichiestaU.Size = new System.Drawing.Size(80, 16);
			this.lblStatorichiestaU.TabIndex = 4;
			this.lblStatorichiestaU.Text = "Stato Richiesta";
			// 
			// tbCodiceFiscaleU
			// 
			this.tbCodiceFiscaleU.Location = new System.Drawing.Point(96, 40);
			this.tbCodiceFiscaleU.Name = "tbCodiceFiscaleU";
			this.tbCodiceFiscaleU.Size = new System.Drawing.Size(348, 20);
			this.tbCodiceFiscaleU.TabIndex = 2;
			this.tbCodiceFiscaleU.Text = "";
			this.tltInfo.SetToolTip(this.tbCodiceFiscaleU, "Filtra per Codice Fiscale");
			this.tbCodiceFiscaleU.TextChanged += new System.EventHandler(this.tbNominativo_TextChanged);
			// 
			// lblCodiceFiscaleU
			// 
			this.lblCodiceFiscaleU.Location = new System.Drawing.Point(8, 40);
			this.lblCodiceFiscaleU.Name = "lblCodiceFiscaleU";
			this.lblCodiceFiscaleU.Size = new System.Drawing.Size(84, 16);
			this.lblCodiceFiscaleU.TabIndex = 2;
			this.lblCodiceFiscaleU.Text = "Codice Fiscale";
			// 
			// tbNominativo
			// 
			this.tbNominativo.Location = new System.Drawing.Point(96, 16);
			this.tbNominativo.Name = "tbNominativo";
			this.tbNominativo.Size = new System.Drawing.Size(348, 20);
			this.tbNominativo.TabIndex = 1;
			this.tbNominativo.Text = "";
			this.tltInfo.SetToolTip(this.tbNominativo, "Filtra per Nominativo");
			this.tbNominativo.TextChanged += new System.EventHandler(this.tbNominativo_TextChanged);
			// 
			// lblNominativo
			// 
			this.lblNominativo.Location = new System.Drawing.Point(8, 16);
			this.lblNominativo.Name = "lblNominativo";
			this.lblNominativo.Size = new System.Drawing.Size(64, 16);
			this.lblNominativo.TabIndex = 0;
			this.lblNominativo.Text = "Nominativo";
			// 
			// dgRichiesteUtenti
			// 
			this.dgRichiesteUtenti.AllowNavigation = false;
			this.dgRichiesteUtenti.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dgRichiesteUtenti.CaptionText = "Lista Richieste";
			this.dgRichiesteUtenti.DataMember = "";
			this.dgRichiesteUtenti.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgRichiesteUtenti.Location = new System.Drawing.Point(3, 128);
			this.dgRichiesteUtenti.Name = "dgRichiesteUtenti";
			this.dgRichiesteUtenti.ParentRowsVisible = false;
			this.dgRichiesteUtenti.ReadOnly = true;
			this.dgRichiesteUtenti.Size = new System.Drawing.Size(657, 328);
			this.dgRichiesteUtenti.TabIndex = 1;
			this.dgRichiesteUtenti.TabStop = false;
			this.tltInfo.SetToolTip(this.dgRichiesteUtenti, "Lista Richieste");
			this.dgRichiesteUtenti.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgRichiesteUtenti_MouseDown);
			this.dgRichiesteUtenti.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgRichiesteSocieta_MouseUp);
			// 
			// btnChiudi
			// 
			this.btnChiudi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChiudi.Location = new System.Drawing.Point(588, 492);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.TabIndex = 3;
			this.btnChiudi.Text = "&Chiudi";
			this.tltInfo.SetToolTip(this.btnChiudi, "Chiude questa finestra");
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnExcel
			// 
			this.btnExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnExcel.Location = new System.Drawing.Point(484, 492);
			this.btnExcel.Name = "btnExcel";
			this.btnExcel.Size = new System.Drawing.Size(96, 23);
			this.btnExcel.TabIndex = 4;
			this.btnExcel.Text = "&Esporta in Excel";
			this.tltInfo.SetToolTip(this.btnExcel, "Esporta la Lista Richieste in Excel");
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			// 
			// dlgEsportaXls
			// 
			this.dlgEsportaXls.DefaultExt = "xls";
			this.dlgEsportaXls.Filter = "Excel files (*.xls)|*.xls";
			// 
			// frmGestRichieste
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(676, 529);
			this.Controls.Add(this.btnExcel);
			this.Controls.Add(this.btnChiudi);
			this.Controls.Add(this.tcSocietaUtenti);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmGestRichieste";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Gestione Richieste";
			this.tcSocietaUtenti.ResumeLayout(false);
			this.tpSocieta.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgRichiesteSocieta)).EndInit();
			this.gbCoordinatebancarie.ResumeLayout(false);
			this.gbSocieta.ResumeLayout(false);
			this.tpUtenti.ResumeLayout(false);
			this.gbUtenti.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgRichiesteUtenti)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region Eventi della Form
		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			ChiudiForm();
		}

		private void tbRagioneSociale_TextChanged(object sender, System.EventArgs e)
		{
			ChangeRowFilterDataGridRichiesteSocieta();
		}

		private void dgRichiesteSocieta_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (sender is DataGrid)
			{
				DataGrid dg = (DataGrid)sender;

				DataGrid.HitTestInfo hti = dg.HitTest(new Point(e.X, e.Y)); 
				if (hti.Type == DataGrid.HitTestType.Cell) 
				{ 
					dg.CurrentCell = new DataGridCell(hti.Row, hti.Column); 
					dg.Select(hti.Row); 
				}
			}
		}
				
		private void tbNominativo_TextChanged(object sender, System.EventArgs e)
		{
			ChangeRowFilterDataGridRichiesteUtenti();
		}

		private void dgRichiesteSocieta_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Clicks == 2)
			{
				// L'evento non e' stato scatenato da un DataGrid
				if (sender.GetType() != typeof(DataGrid))
					return;
		
				// Verifico quale delle due DataGrid ha scatenato l'evento
				DataGrid dgSender = (DataGrid)sender;
				DataGrid.HitTestInfo hti = dgRichiesteSocieta.HitTest(new Point(e.X, e.Y));
				if (hti.Type == DataGrid.HitTestType.Cell) 
				{ 
					frmDettaglioRichiestaSocieta frmDettSocieta = new frmDettaglioRichiestaSocieta(CurrentRowSocieta);
					frmDettSocieta.ShowDialog(this);
					frmDettSocieta.Dispose();	
				}	
			}
		}

		private void dgRichiesteUtenti_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Clicks == 2)
			{
				// L'evento non e' stato scatenato da un DataGrid
				if (sender.GetType() != typeof(DataGrid))
					return;
		
				// Verifico quale delle due DataGrid ha scatenato l'evento
				DataGrid dgSender = (DataGrid)sender;
				DataGrid.HitTestInfo hti = dgRichiesteUtenti.HitTest(new Point(e.X, e.Y));
				if (hti.Type == DataGrid.HitTestType.Cell) 
				{ 
					frmDettaglioRichiestaUtente frmDettUtente = new frmDettaglioRichiestaUtente(CurrentRowUtente);
					frmDettUtente.ShowDialog(this);
					frmDettUtente.Dispose();	
				}	
			}
		}

		private void _dvRichiesteSocieta_OnListChanged(object sender, System.ComponentModel.ListChangedEventArgs args)
		{
			int dgRowNumber = 0;
			// Se esiste almeno una transazione nel DataGrid abilito i bottoni altrimenti
			// li disabilito
			dgRowNumber = GetDataGridRowsNumber();
			btnExcel.Enabled = !(dgRowNumber == 0);
			if (dgRowNumber != 0)
			{
				// N.B. E' importante questa riga per evitare un problema che esiste quando il 
				// data source del DataGrid e' un DataView.
				// Filtrando i dati con il DataView il bookmark non viene aggiornato automaticamente
				// rimanendo settato all'ultimo valore selezionato.
				// Se il numero di tale riga e' superiore al numero di righe visualizzato
				// dal DataGrid viene lanciata un eccezione quando si da il focus al DataGrid.
				dgRichiesteSocieta.CurrentRowIndex = 0;
			}
		}

		private void btnExcel_Click(object sender, System.EventArgs e)
		{
			EsportaExcel();		
		}
		#endregion

		private void tbCodiceConto_TextChanged(object sender, System.EventArgs e)
		{
			ChangeRowFilterDataGridRichiesteSocieta();
		}

		private void tbCodConto_TextChanged(object sender, System.EventArgs e)
		{
			ChangeRowFilterDataGridRichiesteUtenti();
		}
	}
}
