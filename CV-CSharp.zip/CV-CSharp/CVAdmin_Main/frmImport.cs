using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Xml;
using System.IO;
using System.Data;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmImport.
	/// </summary>
	public class frmImport : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.GroupBox gbUrlImportFile;
		private System.Windows.Forms.Label lblUrlImportFile;
		private System.Windows.Forms.TextBox txtFilename;
		private System.Windows.Forms.Button btnScegli;
		private System.Windows.Forms.GroupBox gbRisultatoImport;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnSalvaRisultato;
		private System.Windows.Forms.TextBox txtScartati;
		private System.Windows.Forms.Button btnImportXML;
		private System.Windows.Forms.Button btnChiudi;
		
		private string _XmlImportURL;
		private string _inXmlStream;
		private System.Windows.Forms.TextBox txtCaricati;
		private System.Windows.Forms.TextBox txtLetti;
		private System.Windows.Forms.TextBox txtXmlResult;
		private System.Windows.Forms.SaveFileDialog saveFileDlg;
		private string _IdSessione;
		DataRow _drSessione;

		public frmImport(DataRow drSessione)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			_XmlImportURL = LocalSettings.appSettings["GRTN.Sessioni.ImportFileXml.URL"];
			
			txtFilename.Text = _XmlImportURL;
			_drSessione = drSessione;
			_IdSessione = (string)drSessione["IdSessione"];

			AbilitaImport();
			AbilitaSave();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbUrlImportFile = new System.Windows.Forms.GroupBox();
			this.btnScegli = new System.Windows.Forms.Button();
			this.txtFilename = new System.Windows.Forms.TextBox();
			this.lblUrlImportFile = new System.Windows.Forms.Label();
			this.gbRisultatoImport = new System.Windows.Forms.GroupBox();
			this.txtXmlResult = new System.Windows.Forms.TextBox();
			this.txtCaricati = new System.Windows.Forms.TextBox();
			this.txtLetti = new System.Windows.Forms.TextBox();
			this.txtScartati = new System.Windows.Forms.TextBox();
			this.btnSalvaRisultato = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btnImportXML = new System.Windows.Forms.Button();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.saveFileDlg = new System.Windows.Forms.SaveFileDialog();
			this.gbUrlImportFile.SuspendLayout();
			this.gbRisultatoImport.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbUrlImportFile
			// 
			this.gbUrlImportFile.Controls.AddRange(new System.Windows.Forms.Control[] {
																						  this.btnScegli,
																						  this.txtFilename,
																						  this.lblUrlImportFile});
			this.gbUrlImportFile.Location = new System.Drawing.Point(4, 12);
			this.gbUrlImportFile.Name = "gbUrlImportFile";
			this.gbUrlImportFile.Size = new System.Drawing.Size(636, 68);
			this.gbUrlImportFile.TabIndex = 4;
			this.gbUrlImportFile.TabStop = false;
			this.gbUrlImportFile.Text = " File da importare";
			// 
			// btnScegli
			// 
			this.btnScegli.Location = new System.Drawing.Point(576, 28);
			this.btnScegli.Name = "btnScegli";
			this.btnScegli.Size = new System.Drawing.Size(40, 20);
			this.btnScegli.TabIndex = 3;
			this.btnScegli.Text = "...";
			this.btnScegli.Click += new System.EventHandler(this.btnScegli_Click);
			// 
			// txtFilename
			// 
			this.txtFilename.Location = new System.Drawing.Point(96, 28);
			this.txtFilename.Name = "txtFilename";
			this.txtFilename.Size = new System.Drawing.Size(464, 20);
			this.txtFilename.TabIndex = 1;
			this.txtFilename.Text = "";
			this.txtFilename.Leave += new System.EventHandler(this.txtFilename_Leave);
			// 
			// lblUrlImportFile
			// 
			this.lblUrlImportFile.Location = new System.Drawing.Point(12, 32);
			this.lblUrlImportFile.Name = "lblUrlImportFile";
			this.lblUrlImportFile.Size = new System.Drawing.Size(68, 16);
			this.lblUrlImportFile.TabIndex = 0;
			this.lblUrlImportFile.Text = "URL file:";
			// 
			// gbRisultatoImport
			// 
			this.gbRisultatoImport.Controls.AddRange(new System.Windows.Forms.Control[] {
																							this.txtXmlResult,
																							this.txtCaricati,
																							this.txtLetti,
																							this.txtScartati,
																							this.btnSalvaRisultato,
																							this.label3,
																							this.label2,
																							this.label1});
			this.gbRisultatoImport.Location = new System.Drawing.Point(4, 88);
			this.gbRisultatoImport.Name = "gbRisultatoImport";
			this.gbRisultatoImport.Size = new System.Drawing.Size(636, 248);
			this.gbRisultatoImport.TabIndex = 5;
			this.gbRisultatoImport.TabStop = false;
			this.gbRisultatoImport.Text = " Risultato importazione file XML ";
			// 
			// txtXmlResult
			// 
			this.txtXmlResult.Location = new System.Drawing.Point(8, 24);
			this.txtXmlResult.Multiline = true;
			this.txtXmlResult.Name = "txtXmlResult";
			this.txtXmlResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtXmlResult.Size = new System.Drawing.Size(620, 172);
			this.txtXmlResult.TabIndex = 8;
			this.txtXmlResult.Text = "";
			// 
			// txtCaricati
			// 
			this.txtCaricati.Location = new System.Drawing.Point(284, 212);
			this.txtCaricati.Name = "txtCaricati";
			this.txtCaricati.Size = new System.Drawing.Size(76, 20);
			this.txtCaricati.TabIndex = 7;
			this.txtCaricati.Text = "";
			// 
			// txtLetti
			// 
			this.txtLetti.Location = new System.Drawing.Point(104, 212);
			this.txtLetti.Name = "txtLetti";
			this.txtLetti.Size = new System.Drawing.Size(76, 20);
			this.txtLetti.TabIndex = 6;
			this.txtLetti.Text = "";
			// 
			// txtScartati
			// 
			this.txtScartati.Location = new System.Drawing.Point(464, 212);
			this.txtScartati.Name = "txtScartati";
			this.txtScartati.Size = new System.Drawing.Size(76, 20);
			this.txtScartati.TabIndex = 5;
			this.txtScartati.Text = "";
			// 
			// btnSalvaRisultato
			// 
			this.btnSalvaRisultato.Location = new System.Drawing.Point(556, 212);
			this.btnSalvaRisultato.Name = "btnSalvaRisultato";
			this.btnSalvaRisultato.Size = new System.Drawing.Size(72, 20);
			this.btnSalvaRisultato.TabIndex = 4;
			this.btnSalvaRisultato.Text = "Salva";
			this.btnSalvaRisultato.Click += new System.EventHandler(this.btnSalvaRisultato_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(376, 216);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(84, 16);
			this.label3.TabIndex = 3;
			this.label3.Text = "Record scartati:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(196, 216);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(84, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Record caricati:";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 216);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(84, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Record letti:";
			// 
			// btnImportXML
			// 
			this.btnImportXML.Location = new System.Drawing.Point(404, 348);
			this.btnImportXML.Name = "btnImportXML";
			this.btnImportXML.Size = new System.Drawing.Size(120, 24);
			this.btnImportXML.TabIndex = 6;
			this.btnImportXML.Text = "Import XML";
			this.btnImportXML.Click += new System.EventHandler(this.btnImportXML_Click);
			// 
			// btnChiudi
			// 
			this.btnChiudi.Location = new System.Drawing.Point(532, 348);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.Size = new System.Drawing.Size(104, 23);
			this.btnChiudi.TabIndex = 7;
			this.btnChiudi.Text = "Chiudi";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// saveFileDlg
			// 
			this.saveFileDlg.Filter = "xml files (*.xml)|*.xml";
			// 
			// frmImport
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(642, 379);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnChiudi,
																		  this.btnImportXML,
																		  this.gbRisultatoImport,
																		  this.gbUrlImportFile});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmImport";
			this.ShowInTaskbar = false;
			this.Text = "Import Certificati Verdi";
			this.gbUrlImportFile.ResumeLayout(false);
			this.gbRisultatoImport.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnScegli_Click(object sender, System.EventArgs e)
		{
			frmSceltaXML dlg = new frmSceltaXML(txtFilename.Text);

			dlg.ShowDialog(this);

			if( dlg.DialogResult == DialogResult.OK )
			{
				txtFilename.Text = dlg.FilenameURL;
				
				_inXmlStream = dlg.XmlFileContent;

#if DEBUG
	// txtXmlResult.Text = _inXmlStream;
#endif

				AbilitaImport();
				AbilitaSave();
			}
		}

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void btnImportXML_Click(object sender, System.EventArgs e)
		{
			try
			{
				string outXmlStream = CertificatiVerdi_ImportData(_IdSessione, _inXmlStream);
				if (outXmlStream == null)
				{
					foreach (Control cc in this.Controls)
						cc.Enabled = false;
					btnChiudi.Enabled = true;
					return;
				}

				// recupero le info che mi servono
				XmlDocument XmlDocIn = new XmlDocument();

				XmlDocIn.LoadXml(outXmlStream);
				XmlNodeList nodeList = XmlDocIn.GetElementsByTagName("RESULT");

				XmlAttributeCollection attrColl = nodeList.Item(0).Attributes;

				XmlDocIn.DocumentElement.RemoveChild(nodeList.Item(0));
			
				txtLetti.Text = ((XmlAttribute)attrColl.GetNamedItem("REC_READ")).Value;
				txtCaricati.Text = ((XmlAttribute)attrColl.GetNamedItem("REC_ADDED")).Value;
				txtScartati.Text = ((XmlAttribute)attrColl.GetNamedItem("REC_DISCARDED")).Value;

				if( XmlDocIn.DocumentElement.ChildNodes.Count > 0 )
					txtXmlResult.Text = XmlDocIn.InnerXml;
				else
					txtXmlResult.Text = "";

				AbilitaSave();

				int recAdded = XmlConvert.ToInt32(attrColl.GetNamedItem("REC_ADDED").Value);
				if (recAdded > 0)
				{
					bool bModified = _drSessione.RowState == DataRowState.Modified;
					_drSessione["StatoSessione"] = "Predisposta";
					if (bModified == false)
						_drSessione.AcceptChanges();
				}
			}
			catch( Exception ex )
			{
				MessageBox.Show(ex.Message);
			}
		}

		private string CertificatiVerdi_ImportData(string IdSessione, string inXmlStream)
		{
			bool Cancelled = false;
			if (Cancelled)
			{
				CVAdmin_Main.CVAdminWSBLCertificatiVerdi.BLCertificatiVerdi bl;
				bl = new CVAdmin_Main.CVAdminWSBLCertificatiVerdi.BLCertificatiVerdi();
				frmLogin.AddLoginInfo(bl);
				bl.ImportData(IdSessione, inXmlStream);
			}

			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLCertificatiVerdi.BLCertificatiVerdi.ImportData", 
				IdSessione,
				inXmlStream);
			
			if (Cancelled)
				return null;
			
			return (string)ret;
		}

		private void AbilitaImport()
		{
			btnImportXML.Enabled = frmSceltaXML.CheckFilename( txtFilename.Text );
		}

		private void AbilitaSave()
		{
			btnSalvaRisultato.Enabled = ( txtXmlResult.Text.Length > 0 );
		}

		private void txtFilename_Leave(object sender, System.EventArgs e)
		{
			AbilitaImport();

			if( btnImportXML.Enabled && _inXmlStream != null && _inXmlStream.Length == 0 )
			{
				_inXmlStream = LoadFileContent( txtFilename.Text );
			}
		}

		private string LoadFileContent( string selFilename )
		{
			try
			{
				// recupero il contenuto del file xml selezionato
				// ed elimino l'elemento doctype
				XmlDocument doc = new XmlDocument();
				
				doc.Load(selFilename);

				doc.RemoveChild( doc.DocumentType );

				return doc.InnerXml;

			}
			catch( Exception ex )
			{
				MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return string.Empty;
			}
		}

		private void btnSalvaRisultato_Click(object sender, System.EventArgs e)
		{
			try
			{
				string idFileXml = string.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now);
				string nomeFileXml   = idFileXml + "_import_result.xml";

				saveFileDlg.FileName = nomeFileXml;
				saveFileDlg.InitialDirectory = UtilityEnvironment.CommonAppDir;
				if (saveFileDlg.ShowDialog() != DialogResult.OK)
					return;

				XmlDocument XmlDocIn = new XmlDocument();

				XmlDocIn.LoadXml(txtXmlResult.Text);

				XmlDocIn.Save(saveFileDlg.FileName);

			}
			catch( Exception ex )
			{
				MessageBox.Show(ex.Message, "Errore");
			}
		}

	}
}
