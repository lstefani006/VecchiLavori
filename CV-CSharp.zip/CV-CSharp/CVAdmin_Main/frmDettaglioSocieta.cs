using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmDettaglioUtente.
	/// </summary>
	public class frmDettaglioSocieta : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblRagioneSociale;
		private System.Windows.Forms.Label lblIndirizzo;
		private System.Windows.Forms.Label lblCitta;
		private System.Windows.Forms.Label lblCap;
		private System.Windows.Forms.Label lblNazione;
		private System.Windows.Forms.Label lblCodiceFiscale;
		private System.Windows.Forms.Label lblPartitaIVA;
		private System.Windows.Forms.Label lblTelefono;
		private System.Windows.Forms.Label lblFax;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.Label lblCodiceConto;
		private System.Windows.Forms.Label lblABI;
		private System.Windows.Forms.Label lblCAB;
		private System.Windows.Forms.Label lblCC;
		private System.Windows.Forms.TextBox tbRagioneSociale;
		private System.Windows.Forms.TextBox tbIndirizzo;
		private System.Windows.Forms.TextBox tbCitta;
		private System.Windows.Forms.TextBox tbCAP;
		private System.Windows.Forms.TextBox tbNazione;
		private System.Windows.Forms.TextBox tbCodiceFiscale;
		private System.Windows.Forms.TextBox tbPartitaIVA;
		private System.Windows.Forms.TextBox tbTelefono;
		private System.Windows.Forms.TextBox tbFAX;
		private System.Windows.Forms.TextBox tbEMail;
		private System.Windows.Forms.TextBox tbCodiceConto;
		private System.Windows.Forms.TextBox tbABI;
		private System.Windows.Forms.TextBox tbCAB;
		private System.Windows.Forms.TextBox tbCC;
		private System.Windows.Forms.Button btnSalva;
		private System.Windows.Forms.Button btnChiudi;


		private DataSet _dsSocietaUtenti = null;
		private BindingManagerBase _bmgr = null;
		private DataRow	_dr = null;
		private System.Windows.Forms.GroupBox gbDatiSocieta;
		private System.Windows.Forms.Label lblRefAmm;
		private System.Windows.Forms.TextBox tbRefAmm;
		private System.Windows.Forms.TextBox tbSedeAmm;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnStorico;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmDettaglioSocieta()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ClearComponents();
			_dsSocietaUtenti = null;
		}

		public frmDettaglioSocieta(DataRow dr)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ClearComponents();
			_dr = dr;
			_dsSocietaUtenti = dr.Table.DataSet;

			BindComponents();
		}

		private void Chiudi()
		{
			_dr.CancelEdit();
			this.DialogResult = DialogResult.Cancel;
		}

		private void ClearComponents()
		{
			tbABI.Text				= "";
			tbCAB.Text				= "";
			tbCAP.Text				= "";
			tbCC.Text				= "";
			tbCitta.Text			= "";
			tbCodiceConto.Text		= "";
			tbCodiceFiscale.Text	= "";
			tbEMail.Text			= "";
			tbFAX.Text				= "";
			tbIndirizzo.Text		= "";
			tbNazione.Text			= "";
			tbPartitaIVA.Text		= "";
			tbRagioneSociale.Text	= "";
			tbTelefono.Text			= "";
			tbRefAmm.Text			= "";
			tbSedeAmm.Text			= "";
		}

		private void BindComponents()
		{
			if (_dr == null)
				return;

			if (_dsSocietaUtenti == null)
				return;

			_bmgr = this.BindingContext[_dsSocietaUtenti, "Societa"];
			for (int rr = 0; rr < _dr.Table.Rows.Count; ++rr)
				if (_dr.Table.Rows[rr] == _dr)
					_bmgr.Position = rr;

			//Debug.Assert(_dr == _dsSocietaUtenti.Tables["Societa"].Rows[_bmgr.Position]);

			tbRagioneSociale.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.RagioneSociale");
			tbIndirizzo.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.Indirizzo");
			tbCitta.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.Citta");
			tbCAP.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.CAP");
			tbNazione.DataBindings.Add("Text",_dsSocietaUtenti, "Societa.Nazione");
			tbCodiceFiscale.DataBindings.Add("Text",_dsSocietaUtenti, "Societa.CodiceFiscale");
			tbPartitaIVA.DataBindings.Add("Text",_dsSocietaUtenti, "Societa.PartitaIVA");
			tbTelefono.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.Telefono");
			tbFAX.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.FAX");
			tbEMail.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.Email");
			tbCodiceConto.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.CodiceConto");
			tbABI.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.ABI");
			tbCAB.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.CAB");
			tbCC.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.CC");
			tbRefAmm.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.ReferenteAmministr");
			tbSedeAmm.DataBindings.Add("Text", _dsSocietaUtenti, "Societa.SedeAmministrativa");
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDettaglioSocieta));
			this.gbDatiSocieta = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.tbSedeAmm = new System.Windows.Forms.TextBox();
			this.tbRefAmm = new System.Windows.Forms.TextBox();
			this.lblRefAmm = new System.Windows.Forms.Label();
			this.tbCC = new System.Windows.Forms.TextBox();
			this.tbCAB = new System.Windows.Forms.TextBox();
			this.tbABI = new System.Windows.Forms.TextBox();
			this.tbCodiceConto = new System.Windows.Forms.TextBox();
			this.tbEMail = new System.Windows.Forms.TextBox();
			this.tbFAX = new System.Windows.Forms.TextBox();
			this.tbTelefono = new System.Windows.Forms.TextBox();
			this.tbPartitaIVA = new System.Windows.Forms.TextBox();
			this.tbCodiceFiscale = new System.Windows.Forms.TextBox();
			this.tbNazione = new System.Windows.Forms.TextBox();
			this.tbCAP = new System.Windows.Forms.TextBox();
			this.tbCitta = new System.Windows.Forms.TextBox();
			this.tbIndirizzo = new System.Windows.Forms.TextBox();
			this.tbRagioneSociale = new System.Windows.Forms.TextBox();
			this.lblCC = new System.Windows.Forms.Label();
			this.lblCAB = new System.Windows.Forms.Label();
			this.lblABI = new System.Windows.Forms.Label();
			this.lblCodiceConto = new System.Windows.Forms.Label();
			this.lblEmail = new System.Windows.Forms.Label();
			this.lblFax = new System.Windows.Forms.Label();
			this.lblTelefono = new System.Windows.Forms.Label();
			this.lblPartitaIVA = new System.Windows.Forms.Label();
			this.lblCodiceFiscale = new System.Windows.Forms.Label();
			this.lblNazione = new System.Windows.Forms.Label();
			this.lblCap = new System.Windows.Forms.Label();
			this.lblCitta = new System.Windows.Forms.Label();
			this.lblIndirizzo = new System.Windows.Forms.Label();
			this.lblRagioneSociale = new System.Windows.Forms.Label();
			this.btnSalva = new System.Windows.Forms.Button();
			this.btnChiudi = new System.Windows.Forms.Button();
			this.btnStorico = new System.Windows.Forms.Button();
			this.gbDatiSocieta.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbDatiSocieta
			// 
			this.gbDatiSocieta.Controls.Add(this.label1);
			this.gbDatiSocieta.Controls.Add(this.tbSedeAmm);
			this.gbDatiSocieta.Controls.Add(this.tbRefAmm);
			this.gbDatiSocieta.Controls.Add(this.lblRefAmm);
			this.gbDatiSocieta.Controls.Add(this.tbCC);
			this.gbDatiSocieta.Controls.Add(this.tbCAB);
			this.gbDatiSocieta.Controls.Add(this.tbABI);
			this.gbDatiSocieta.Controls.Add(this.tbCodiceConto);
			this.gbDatiSocieta.Controls.Add(this.tbEMail);
			this.gbDatiSocieta.Controls.Add(this.tbFAX);
			this.gbDatiSocieta.Controls.Add(this.tbTelefono);
			this.gbDatiSocieta.Controls.Add(this.tbPartitaIVA);
			this.gbDatiSocieta.Controls.Add(this.tbCodiceFiscale);
			this.gbDatiSocieta.Controls.Add(this.tbNazione);
			this.gbDatiSocieta.Controls.Add(this.tbCAP);
			this.gbDatiSocieta.Controls.Add(this.tbCitta);
			this.gbDatiSocieta.Controls.Add(this.tbIndirizzo);
			this.gbDatiSocieta.Controls.Add(this.tbRagioneSociale);
			this.gbDatiSocieta.Controls.Add(this.lblCC);
			this.gbDatiSocieta.Controls.Add(this.lblCAB);
			this.gbDatiSocieta.Controls.Add(this.lblABI);
			this.gbDatiSocieta.Controls.Add(this.lblCodiceConto);
			this.gbDatiSocieta.Controls.Add(this.lblEmail);
			this.gbDatiSocieta.Controls.Add(this.lblFax);
			this.gbDatiSocieta.Controls.Add(this.lblTelefono);
			this.gbDatiSocieta.Controls.Add(this.lblPartitaIVA);
			this.gbDatiSocieta.Controls.Add(this.lblCodiceFiscale);
			this.gbDatiSocieta.Controls.Add(this.lblNazione);
			this.gbDatiSocieta.Controls.Add(this.lblCap);
			this.gbDatiSocieta.Controls.Add(this.lblCitta);
			this.gbDatiSocieta.Controls.Add(this.lblIndirizzo);
			this.gbDatiSocieta.Controls.Add(this.lblRagioneSociale);
			this.gbDatiSocieta.Location = new System.Drawing.Point(4, 4);
			this.gbDatiSocieta.Name = "gbDatiSocieta";
			this.gbDatiSocieta.Size = new System.Drawing.Size(504, 268);
			this.gbDatiSocieta.TabIndex = 20;
			this.gbDatiSocieta.TabStop = false;
			this.gbDatiSocieta.Text = " Dati Societ�";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(256, 56);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(136, 16);
			this.label1.TabIndex = 31;
			this.label1.Text = "Sede Amministrativa";
			// 
			// tbSedeAmm
			// 
			this.tbSedeAmm.BackColor = System.Drawing.Color.White;
			this.tbSedeAmm.Location = new System.Drawing.Point(256, 72);
			this.tbSedeAmm.Name = "tbSedeAmm";
			this.tbSedeAmm.Size = new System.Drawing.Size(245, 20);
			this.tbSedeAmm.TabIndex = 4;
			this.tbSedeAmm.Text = "Sede Amministrativa";
			// 
			// tbRefAmm
			// 
			this.tbRefAmm.BackColor = System.Drawing.Color.White;
			this.tbRefAmm.Location = new System.Drawing.Point(8, 72);
			this.tbRefAmm.Name = "tbRefAmm";
			this.tbRefAmm.Size = new System.Drawing.Size(245, 20);
			this.tbRefAmm.TabIndex = 3;
			this.tbRefAmm.Text = "Referente Amministrativo";
			// 
			// lblRefAmm
			// 
			this.lblRefAmm.Location = new System.Drawing.Point(8, 56);
			this.lblRefAmm.Name = "lblRefAmm";
			this.lblRefAmm.Size = new System.Drawing.Size(136, 16);
			this.lblRefAmm.TabIndex = 23;
			this.lblRefAmm.Text = "Referente Amministrativo";
			// 
			// tbCC
			// 
			this.tbCC.Location = new System.Drawing.Point(376, 232);
			this.tbCC.MaxLength = 12;
			this.tbCC.Name = "tbCC";
			this.tbCC.Size = new System.Drawing.Size(124, 20);
			this.tbCC.TabIndex = 16;
			this.tbCC.Text = "CC";
			// 
			// tbCAB
			// 
			this.tbCAB.Location = new System.Drawing.Point(256, 232);
			this.tbCAB.MaxLength = 5;
			this.tbCAB.Name = "tbCAB";
			this.tbCAB.Size = new System.Drawing.Size(116, 20);
			this.tbCAB.TabIndex = 15;
			this.tbCAB.Text = "CAB";
			this.tbCAB.Validating += new System.ComponentModel.CancelEventHandler(this.tbCAB_Validating);
			// 
			// tbABI
			// 
			this.tbABI.Location = new System.Drawing.Point(135, 232);
			this.tbABI.MaxLength = 5;
			this.tbABI.Name = "tbABI";
			this.tbABI.Size = new System.Drawing.Size(118, 20);
			this.tbABI.TabIndex = 14;
			this.tbABI.Text = "ABI";
			this.tbABI.Validating += new System.ComponentModel.CancelEventHandler(this.tbABI_Validating);
			// 
			// tbCodiceConto
			// 
			this.tbCodiceConto.Location = new System.Drawing.Point(8, 232);
			this.tbCodiceConto.Name = "tbCodiceConto";
			this.tbCodiceConto.Size = new System.Drawing.Size(122, 20);
			this.tbCodiceConto.TabIndex = 13;
			this.tbCodiceConto.Text = "Codice Conto";
			// 
			// tbEMail
			// 
			this.tbEMail.Location = new System.Drawing.Point(256, 192);
			this.tbEMail.Name = "tbEMail";
			this.tbEMail.Size = new System.Drawing.Size(244, 20);
			this.tbEMail.TabIndex = 12;
			this.tbEMail.Text = "EMail";
			// 
			// tbFAX
			// 
			this.tbFAX.Location = new System.Drawing.Point(136, 192);
			this.tbFAX.Name = "tbFAX";
			this.tbFAX.Size = new System.Drawing.Size(118, 20);
			this.tbFAX.TabIndex = 11;
			this.tbFAX.Text = "FAX";
			// 
			// tbTelefono
			// 
			this.tbTelefono.Location = new System.Drawing.Point(8, 192);
			this.tbTelefono.Name = "tbTelefono";
			this.tbTelefono.Size = new System.Drawing.Size(122, 20);
			this.tbTelefono.TabIndex = 10;
			this.tbTelefono.Text = "Telefono";
			// 
			// tbPartitaIVA
			// 
			this.tbPartitaIVA.BackColor = System.Drawing.Color.White;
			this.tbPartitaIVA.Location = new System.Drawing.Point(256, 152);
			this.tbPartitaIVA.Name = "tbPartitaIVA";
			this.tbPartitaIVA.Size = new System.Drawing.Size(244, 20);
			this.tbPartitaIVA.TabIndex = 9;
			this.tbPartitaIVA.Text = "Partita IVA";
			// 
			// tbCodiceFiscale
			// 
			this.tbCodiceFiscale.BackColor = System.Drawing.Color.White;
			this.tbCodiceFiscale.Location = new System.Drawing.Point(8, 152);
			this.tbCodiceFiscale.Name = "tbCodiceFiscale";
			this.tbCodiceFiscale.Size = new System.Drawing.Size(245, 20);
			this.tbCodiceFiscale.TabIndex = 8;
			this.tbCodiceFiscale.Text = "Codice Fiscale";
			// 
			// tbNazione
			// 
			this.tbNazione.Location = new System.Drawing.Point(256, 112);
			this.tbNazione.Name = "tbNazione";
			this.tbNazione.Size = new System.Drawing.Size(244, 20);
			this.tbNazione.TabIndex = 7;
			this.tbNazione.Text = "Nazione";
			// 
			// tbCAP
			// 
			this.tbCAP.Location = new System.Drawing.Point(156, 112);
			this.tbCAP.Name = "tbCAP";
			this.tbCAP.Size = new System.Drawing.Size(96, 20);
			this.tbCAP.TabIndex = 6;
			this.tbCAP.Text = "CAP";
			// 
			// tbCitta
			// 
			this.tbCitta.Location = new System.Drawing.Point(8, 112);
			this.tbCitta.Name = "tbCitta";
			this.tbCitta.Size = new System.Drawing.Size(145, 20);
			this.tbCitta.TabIndex = 5;
			this.tbCitta.Text = "Citta";
			// 
			// tbIndirizzo
			// 
			this.tbIndirizzo.Location = new System.Drawing.Point(256, 32);
			this.tbIndirizzo.Name = "tbIndirizzo";
			this.tbIndirizzo.Size = new System.Drawing.Size(244, 20);
			this.tbIndirizzo.TabIndex = 2;
			this.tbIndirizzo.Text = "Indirizzo";
			// 
			// tbRagioneSociale
			// 
			this.tbRagioneSociale.BackColor = System.Drawing.Color.White;
			this.tbRagioneSociale.Location = new System.Drawing.Point(8, 32);
			this.tbRagioneSociale.Name = "tbRagioneSociale";
			this.tbRagioneSociale.Size = new System.Drawing.Size(245, 20);
			this.tbRagioneSociale.TabIndex = 1;
			this.tbRagioneSociale.Text = "Ragione Sociale";
			// 
			// lblCC
			// 
			this.lblCC.Location = new System.Drawing.Point(376, 216);
			this.lblCC.Name = "lblCC";
			this.lblCC.Size = new System.Drawing.Size(24, 16);
			this.lblCC.TabIndex = 132;
			this.lblCC.Text = "CC";
			// 
			// lblCAB
			// 
			this.lblCAB.Location = new System.Drawing.Point(260, 216);
			this.lblCAB.Name = "lblCAB";
			this.lblCAB.Size = new System.Drawing.Size(36, 16);
			this.lblCAB.TabIndex = 122;
			this.lblCAB.Text = "CAB";
			// 
			// lblABI
			// 
			this.lblABI.Location = new System.Drawing.Point(136, 216);
			this.lblABI.Name = "lblABI";
			this.lblABI.Size = new System.Drawing.Size(32, 16);
			this.lblABI.TabIndex = 112;
			this.lblABI.Text = "ABI";
			// 
			// lblCodiceConto
			// 
			this.lblCodiceConto.Location = new System.Drawing.Point(8, 216);
			this.lblCodiceConto.Name = "lblCodiceConto";
			this.lblCodiceConto.Size = new System.Drawing.Size(80, 16);
			this.lblCodiceConto.TabIndex = 102;
			this.lblCodiceConto.Text = "Codice Conto";
			// 
			// lblEmail
			// 
			this.lblEmail.Location = new System.Drawing.Point(256, 176);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(40, 16);
			this.lblEmail.TabIndex = 92;
			this.lblEmail.Text = "E-Mail";
			// 
			// lblFax
			// 
			this.lblFax.Location = new System.Drawing.Point(136, 176);
			this.lblFax.Name = "lblFax";
			this.lblFax.Size = new System.Drawing.Size(40, 16);
			this.lblFax.TabIndex = 82;
			this.lblFax.Text = "FAX";
			// 
			// lblTelefono
			// 
			this.lblTelefono.Location = new System.Drawing.Point(8, 176);
			this.lblTelefono.Name = "lblTelefono";
			this.lblTelefono.Size = new System.Drawing.Size(60, 16);
			this.lblTelefono.TabIndex = 72;
			this.lblTelefono.Text = "Telefono";
			// 
			// lblPartitaIVA
			// 
			this.lblPartitaIVA.Location = new System.Drawing.Point(256, 136);
			this.lblPartitaIVA.Name = "lblPartitaIVA";
			this.lblPartitaIVA.Size = new System.Drawing.Size(64, 20);
			this.lblPartitaIVA.TabIndex = 62;
			this.lblPartitaIVA.Text = "Partita IVA";
			// 
			// lblCodiceFiscale
			// 
			this.lblCodiceFiscale.Location = new System.Drawing.Point(8, 136);
			this.lblCodiceFiscale.Name = "lblCodiceFiscale";
			this.lblCodiceFiscale.Size = new System.Drawing.Size(84, 16);
			this.lblCodiceFiscale.TabIndex = 52;
			this.lblCodiceFiscale.Text = "Codice Fiscale";
			// 
			// lblNazione
			// 
			this.lblNazione.Location = new System.Drawing.Point(256, 96);
			this.lblNazione.Name = "lblNazione";
			this.lblNazione.Size = new System.Drawing.Size(52, 16);
			this.lblNazione.TabIndex = 42;
			this.lblNazione.Text = "Nazione";
			// 
			// lblCap
			// 
			this.lblCap.Location = new System.Drawing.Point(160, 96);
			this.lblCap.Name = "lblCap";
			this.lblCap.Size = new System.Drawing.Size(40, 16);
			this.lblCap.TabIndex = 32;
			this.lblCap.Text = "CAP";
			// 
			// lblCitta
			// 
			this.lblCitta.Location = new System.Drawing.Point(8, 96);
			this.lblCitta.Name = "lblCitta";
			this.lblCitta.Size = new System.Drawing.Size(40, 17);
			this.lblCitta.TabIndex = 22;
			this.lblCitta.Text = "Citt�";
			// 
			// lblIndirizzo
			// 
			this.lblIndirizzo.Location = new System.Drawing.Point(256, 16);
			this.lblIndirizzo.Name = "lblIndirizzo";
			this.lblIndirizzo.Size = new System.Drawing.Size(48, 16);
			this.lblIndirizzo.TabIndex = 22;
			this.lblIndirizzo.Text = "Indirizzo";
			// 
			// lblRagioneSociale
			// 
			this.lblRagioneSociale.Location = new System.Drawing.Point(7, 16);
			this.lblRagioneSociale.Name = "lblRagioneSociale";
			this.lblRagioneSociale.Size = new System.Drawing.Size(88, 16);
			this.lblRagioneSociale.TabIndex = 21;
			this.lblRagioneSociale.Text = "Ragione Sociale";
			// 
			// btnSalva
			// 
			this.btnSalva.Location = new System.Drawing.Point(304, 275);
			this.btnSalva.Name = "btnSalva";
			this.btnSalva.Size = new System.Drawing.Size(100, 23);
			this.btnSalva.TabIndex = 17;
			this.btnSalva.Text = "&Salva Modifiche";
			this.btnSalva.Click += new System.EventHandler(this.btnSalva_Click);
			// 
			// btnChiudi
			// 
			this.btnChiudi.Location = new System.Drawing.Point(408, 275);
			this.btnChiudi.Name = "btnChiudi";
			this.btnChiudi.Size = new System.Drawing.Size(100, 23);
			this.btnChiudi.TabIndex = 19;
			this.btnChiudi.Text = "&Chiudi";
			this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
			// 
			// btnStorico
			// 
			this.btnStorico.Enabled = false;
			this.btnStorico.Location = new System.Drawing.Point(8, 275);
			this.btnStorico.Name = "btnStorico";
			this.btnStorico.Size = new System.Drawing.Size(100, 23);
			this.btnStorico.TabIndex = 18;
			this.btnStorico.Text = "Storico &Modifiche";
			this.btnStorico.Visible = false;
			this.btnStorico.Click += new System.EventHandler(this.btnStorico_Click);
			// 
			// frmDettaglioSocieta
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(510, 299);
			this.Controls.Add(this.btnStorico);
			this.Controls.Add(this.btnChiudi);
			this.Controls.Add(this.btnSalva);
			this.Controls.Add(this.gbDatiSocieta);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmDettaglioSocieta";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Dettaglio  Societ�";
			this.gbDatiSocieta.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnChiudi_Click(object sender, System.EventArgs e)
		{
			Chiudi();
		}

		private void RefreshBinding()
		{
//			int p = _bmgr.Position;
//			_bmgr.Position = _bmgr.Count;
//			_bmgr.Position = p;

			if (_bmgr != null && _bmgr is CurrencyManager)
				((CurrencyManager)_bmgr).Refresh();
		}

		private void btnSalva_Click(object sender, System.EventArgs e)
		{
			DialogResult dr = MessageBox.Show("Sei sicuro di voler modificare i dati?", "Modificat Dati", MessageBoxButtons.YesNo, MessageBoxIcon.Information); 
			if (dr == DialogResult.No)
			{
				_dr.CancelEdit();
				RefreshBinding();
				return;
			}
			Application.DoEvents();
			_dr.EndEdit();

			_dr["DataOraModifica"] = CVAdmin_Main.DbTime.GetDbSystemDate();

			// Passo anche l'IdSocieta della societa' che si e' modificata in modo 
			// da riportare la modifica nello Storico
			if (frmSocietaUtenti.AggiornaDataSetSocieta(_dsSocietaUtenti, (string)_dr["IdSocieta"]))
			{
				this.DialogResult = DialogResult.OK;
				MessageBox.Show("Modifica effettuata in modo corretto", "Modifica Dati", MessageBoxButtons.OK, MessageBoxIcon.Information);
				this.Close();
			}
			else
			{
				MessageBox.Show("Modifica non effettuata", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnStorico_Click(object sender, System.EventArgs e)
		{
			frmStoricoSocieta frmStoSocieta = new frmStoricoSocieta();
			frmStoSocieta.ShowDialog(this);
			frmStoSocieta.Dispose();
		}

		private void tbABI_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Regex rg = new Regex("^\\d{1,5}$");
			if (rg.Match(tbABI.Text).Success == false)
			{
				MessageBox.Show("Il campo ABI deve contenere solo cifre numeriche e non puo' essere nullo!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
				e.Cancel = true; 
			}
		}

		private void tbCAB_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Regex rg = new Regex("^\\d{1,5}$");
			if (rg.Match(tbCAB.Text).Success == false)
			{
				MessageBox.Show("Il campo CAB deve contenere solo cifre numeriche e non puo' essere nullo!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
				e.Cancel = true; 
			}
		}
	}
}
