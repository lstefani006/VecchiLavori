using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Data;
using Word;
using System.Windows.Forms;


namespace CVAdmin_Main
{
	/// <summary>
	/// queste sono funzioni messe qui per evitare un baco dell'ambiente di sviluppo.
	/// Se si mettono direttamente entro la classe frmReport la direttiva using Word
	/// non consente di caricare piu' la finestra nell'ambiente di sviluppo.
	/// </summary>
	public class frmReportHelper
	{
		public static void CreaReportAcquisti(DataSet dsSessione, DataSet dsBudget, string IdSocieta, string cbSocietaText, string PartitaIVA, string wdDotFile, string wdFileName)
		{
			// costanti usate nella funzione
			object missing = System.Reflection.Missing.Value;
			int True = -1;
			int False = 0;

			string IdSessione =        (string)   dsSessione.Tables[0].Rows[0]["IdSessione"];
			string Titolo =            (string)   dsSessione.Tables[0].Rows[0]["Titolo"];
			DateTime DataOraApertura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraApertura"];
			DateTime DataOraChiusura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraChiusura"];

			_Application wdApp = new ApplicationClass();
			object dotFile = wdDotFile;
			_Document wdDoc = wdApp.Documents.Add(ref dotFile, ref missing, ref missing, ref missing); // TODO aggiungere path e il file da downlodare

			wdDoc.Activate();
			wdDoc.Content.InsertParagraphAfter();

			if (true)
			{
				Range wdRange = wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range;
				wdRange.Font.Name = "Times New Roman";
				wdRange.Font.Size = 14;
				wdRange.Font.Bold = True;
			}

			wdDoc.Range(ref missing, ref missing).InsertAfter("CONFERMA ACQUIRENTI\r\r");

			// Intestazione della seconda pagina in poi
			if (true)
			{
				HeaderFooter wdHeaderFooter = wdDoc.Sections.Item(1).Headers.Item(WdHeaderFooterIndex.wdHeaderFooterPrimary);
				wdHeaderFooter.Range.Font.Name = "Times New Roman";
				wdHeaderFooter.Range.Font.Size = 11;

				wdHeaderFooter.Range.InsertAfter(
					"TITOLO SESSIONE: " + Titolo + 
					" DATA ORA APERTURA: " + Converter.DateTimeToStringDateTime(DataOraApertura) +
					" DATA ORA CHIUSURA: " + Converter.DateTimeToStringDateTime(DataOraChiusura) + "\r");

				wdHeaderFooter.Range.InsertParagraphAfter();

				if (true)
				{
					Table wdTable = wdHeaderFooter.Range.Tables.Add(
						wdHeaderFooter.Range.Paragraphs.Item(wdHeaderFooter.Range.Paragraphs.Count).Range,
						2, 4, ref missing, ref missing);

					wdTable.Range.Font.Name = "Times New Roman";
					wdTable.Range.Font.Size = 11;

					DataRow drBudget = dsBudget.Tables[0].Rows[0];

					wdTable.Cell(1, 1).Range.Font.Bold = True; 
					wdTable.Cell(1, 1).Range.InsertAfter("Acquirente");
					wdTable.Cell(1, 2).Range.InsertAfter(cbSocietaText);
					wdTable.Cell(1, 3).Range.Font.Bold = True;
					wdTable.Cell(1, 3).Range.InsertAfter("Prezzo Convenzionale per certificato");
					wdTable.Cell(1, 4).Range.InsertAfter(Converter.DecimalToCurrencyString(drBudget, "PrezzoConvenzionaleUtente"));
					wdTable.Cell(2, 3).Range.Font.Bold = True;
					wdTable.Cell(2, 3).Range.InsertAfter ("Deposito in conto prezzo");
					wdTable.Cell(2, 4).Range.InsertAfter(Converter.DecimalToCurrencyString(drBudget, "Importo"));
					wdTable.Columns.AutoFit();
				}
			}

			// ------------------------------------------------------------------------------
			// Dati relativi alla sessione selezionata
			wdDoc.Content.InsertParagraphAfter();

			if (true)
			{
				Range wdRange = wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range;
				wdRange.Font.Name = "Times New Roman";
				wdRange.Font.Size = 11;
				wdRange.Font.Bold = False;
			}

			if (true)
			{
				wdDoc.Range(ref missing, ref missing).InsertAfter(
					"TITOLO SESSIONE: " + Titolo +
					" DATA ORA APERTURA: " + Converter.DateTimeToStringDateTime(DataOraApertura) +
					" DATA ORA CHIUSURA: " + Converter.DateTimeToStringDateTime(DataOraChiusura) + "\r\r");
			}

			wdDoc.Content.InsertParagraphAfter();

			// '------------------------------------------------------------------------------
			// 'Tabella relativa al Budgets dell'acquirente
			if (true)
			{
				DataRow drBudget = dsBudget.Tables[0].Rows[0];

				Table wdTable = wdDoc.Tables.Add(wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range, 2, 4, ref missing, ref missing);
				wdTable.Range.Font.Name = "Times New Roman";
				wdTable.Range.Font.Size = 11;
				wdTable.Cell(1, 1).Range.Font.Bold = True;
				wdTable.Cell(1, 1).Range.InsertAfter("Acquirente");
				wdTable.Cell(1, 2).Range.InsertAfter(cbSocietaText);
				wdTable.Cell(1, 3).Range.Font.Bold = True;
				wdTable.Cell(1, 3).Range.InsertAfter("Prezzo Convenzionale per certificato");
				wdTable.Cell(1, 4).Range.InsertAfter(Converter.DecimalToCurrencyString(drBudget, "PrezzoConvenzionaleUtente"));
				wdTable.Cell(2, 3).Range.Font.Bold = True;
				wdTable.Cell(2, 3).Range.InsertAfter("Deposito in conto prezzo");
				wdTable.Cell(2, 4).Range.InsertAfter(Converter.DecimalToCurrencyString(drBudget, "Importo"));
				wdTable.Columns.AutoFit();
			}

			// '-------------------------------------------------------------------------------
			wdDoc.Content.InsertParagraphAfter();
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Name = "Times New Roman";
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Size = 11;
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Bold = True;
			wdDoc.Range(ref missing, ref missing).InsertAfter("Riepilogo delle operazioni di acquisto eseguite:");
			wdDoc.Content.InsertParagraphAfter();
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Name = "Times New Roman";
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Size = 11;
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Bold = False;


			CVAdminWSBLTransazioni.BLTransazioni bl = new CVAdminWSBLTransazioni.BLTransazioni();
			frmLogin.AddLoginInfo(bl);

			DataSet dsTransazioniPerAnno = null;
			DataTable dtTransazioniPerAnno = null;
			try
			{
				dsTransazioniPerAnno = bl.ListaOperazioniAcquistoPerAnno(IdSessione, IdSocieta);
				dtTransazioniPerAnno = dsTransazioniPerAnno.Tables[0];
			}
			catch (Exception e)
			{
				MessageBox.Show(e.Message, "Errore");
				return;
			}

			// '-------------------------------------------------------------------------------
			// 'Visualizzaione delle Transazioni raggruppate per anno
			if (true)
			{
				Table wdTable = wdDoc.Tables.Add(wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range, dtTransazioniPerAnno.Rows.Count + 2, 6, ref missing, ref missing);
				wdTable.Range.Font.Name = "Times New Roman";
				wdTable.Range.Font.Size = 11;
				wdTable.Cell(1, 1).Range.Font.Bold = True;
				wdTable.Cell(1, 1).Range.InsertAfter("Anno Riferimento");
				wdTable.Cell(1, 2).Range.Font.Bold = True;
				wdTable.Cell(1, 2).Range.InsertAfter("Quantit� TOT.");
				wdTable.Cell(1, 3).Range.Font.Bold = True;
				wdTable.Cell(1, 3).Range.InsertAfter("Prezzo Medio Acquisti");
				wdTable.Cell(1, 4).Range.Font.Bold = True;
				wdTable.Cell(1, 4).Range.InsertAfter("CTV coperto da deposito");
				wdTable.Cell(1, 5).Range.Font.Bold = True;
				wdTable.Cell(1, 5).Range.InsertAfter("CTV non coperto da deposito");
				wdTable.Cell(1, 6).Range.Font.Bold = True;
				wdTable.Cell(1, 6).Range.InsertAfter("CTV TOT.");

				int X = 2;

				decimal QTot = 0m;
				decimal CtvCopertoTot = 0m;
				decimal CtvNonCopertoTot = 0m;
				decimal CtvTotale = 0m;

				foreach (DataRow drTransazioniPerAnno in dtTransazioniPerAnno.Rows)
				{
					wdTable.Cell(X, 1).Range.InsertAfter(Converter.StringToString(drTransazioniPerAnno, "AnnoRiferimento"));
					wdTable.Cell(X, 2).Range.InsertAfter(Converter.DecimalToIntegerString(drTransazioniPerAnno, "QTot"));
					QTot += (decimal)drTransazioniPerAnno["QTot"];

					wdTable.Cell(X, 3).Range.InsertAfter(Converter.DecimalToCurrencyString((decimal)drTransazioniPerAnno["PMedioA"] + 0.001m));

					wdTable.Cell(X, 4).Range.InsertAfter(Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVCoperto"));
					CtvCopertoTot += (decimal)drTransazioniPerAnno["CTVCoperto"];

					wdTable.Cell(X, 5).Range.InsertAfter(Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVNonCoperto"));
					CtvNonCopertoTot += (decimal)drTransazioniPerAnno["CTVNonCoperto"];

					wdTable.Cell(X, 6).Range.InsertAfter(Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVTot"));
					CtvTotale += (decimal)drTransazioniPerAnno["CTVTot"];

					X += 1;
				}
				wdTable.Columns.AutoFit();


				wdTable.Cell(X, 1).Range.InsertAfter("TOTALE");
				wdTable.Cell(X, 2).Range.InsertAfter(Converter.DecimalToIntegerString(QTot));
				wdTable.Cell(X, 4).Range.InsertAfter(Converter.DecimalToCurrencyString(CtvCopertoTot));
				wdTable.Cell(X, 5).Range.InsertAfter(Converter.DecimalToCurrencyString(CtvNonCopertoTot));
				wdTable.Cell(X, 6).Range.InsertAfter(Converter.DecimalToCurrencyString(CtvTotale));
			}


			// '--------------------------------------------------------------------------------
			// 'Transazioni raggruppate per venditore

			DataSet dsTransazioniPerVenditore = null;
			try
			{
				dsTransazioniPerVenditore = bl.ListaOperazioniAcquistoPerVenditore(IdSessione, IdSocieta);
			}
			catch (Exception e)
			{
				MessageBox.Show(e.Message, "Error");
				return;
			}
			DataTable dtTransazioniPerVenditore = dsTransazioniPerVenditore.Tables[0];

			wdDoc.Content.InsertParagraphAfter();
			if (true)
			{
				Table wdTable = wdDoc.Tables.Add(wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range, dtTransazioniPerVenditore.Rows.Count + 2, 3, ref missing, ref missing);

				wdTable.Range.Font.Name = "Times New Roman";
				wdTable.Range.Font.Size = 11;
				wdTable.Cell(1, 1).Range.Font.Bold = True;
				wdTable.Cell(1, 1).Range.InsertAfter("Acquirente");
				wdTable.Cell(1, 2).Range.Font.Bold = True;
				wdTable.Cell(1, 2).Range.InsertAfter("Venditore");
				wdTable.Cell(1, 3).Range.Font.Bold = True;
				wdTable.Cell(1, 3).Range.InsertAfter("CTV da pagare");
				wdTable.Cell(2, 1).Range.InsertAfter(cbSocietaText);

				int X = 3;

				foreach (DataRow drTransazioniPerVenditore in dtTransazioniPerVenditore.Rows)
				{
					wdTable.Cell(X, 2).Range.InsertAfter(Converter.StringToString(drTransazioniPerVenditore,"RagioneSocialeVenditore"));
					wdTable.Cell(X, 3).Range.InsertAfter(Converter.DecimalToCurrencyString(drTransazioniPerVenditore, "CTVDaPagare"));
					X += 1;
				}
				wdTable.Columns.AutoFit();
			}


			// '--------------------------------------------------------------------------------
			wdDoc.Content.InsertParagraphAfter();
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Name = "Times New Roman";
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Size = 11;
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Bold = True;
			wdDoc.Range(ref missing, ref missing).InsertAfter("Dettaglio delle singole operazioni:");

			// '--------------------------------------------------------------------------------
			// 'Dettaglio delle Transazioni
			DataSet dsDettaglioTransazioni = null;
			try
			{
				dsDettaglioTransazioni = bl.DettagliAcquisti(IdSessione, IdSocieta);
			}
			catch (Exception e)
			{
				MessageBox.Show(e.Message, "Errore");
				return;
			}
			DataTable dtDettaglioTransazioni = dsDettaglioTransazioni.Tables[0];

			foreach (DataRow drDettaglioTransazioni in dtDettaglioTransazioni.Rows)
			{
				wdDoc.Content.InsertParagraphAfter();
				wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Name = "Times New Roman";
				wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Size = 11;
				wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Bold = False;

				Table wdTable = wdDoc.Tables.Add(wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range, 13, 2, ref missing, ref missing);
				wdTable.Cell( 1, 1).Range.Font.Bold = True;
				wdTable.Cell( 1, 1).Range.InsertAfter("IdTransazione");
				wdTable.Cell( 2, 1).Range.Font.Bold = True;
				wdTable.Cell( 2, 1).Range.InsertAfter("IdOffertaAcquisto");
				wdTable.Cell( 3, 1).Range.Font.Bold = True;
				wdTable.Cell( 3, 1).Range.InsertAfter("Data Ora Operazione");
				wdTable.Cell( 4, 1).Range.Font.Bold = True;
				wdTable.Cell( 4, 1).Range.InsertAfter("Anno Riferimento");
				wdTable.Cell( 5, 1).Range.Font.Bold = True;
				wdTable.Cell( 5, 1).Range.InsertAfter("Quantit� eseguita");
				wdTable.Cell( 6, 1).Range.Font.Bold = True;
				wdTable.Cell( 6, 1).Range.InsertAfter("Prezzo eseguito");
				wdTable.Cell( 7, 1).Range.Font.Bold = True;
				wdTable.Cell( 7, 1).Range.InsertAfter("Controvalore");
				wdTable.Cell( 8, 1).Range.Font.Bold = True;
				wdTable.Cell( 8, 1).Range.InsertAfter("Controvalore coperto da deposito");
				wdTable.Cell( 9, 1).Range.Font.Bold = True;
				wdTable.Cell( 9, 1).Range.InsertAfter("Ragione Sociale Venditore");
				wdTable.Cell(10, 1).Range.Font.Bold = True;
				wdTable.Cell(10, 1).Range.InsertAfter("ABI");
				wdTable.Cell(11, 1).Range.Font.Bold = True;
				wdTable.Cell(11, 1).Range.InsertAfter("CAB");
				wdTable.Cell(12, 1).Range.Font.Bold = True;
				wdTable.Cell(12, 1).Range.InsertAfter("CC");
				wdTable.Cell(13, 1).Range.Font.Bold = True;
				wdTable.Cell(13, 1).Range.InsertAfter("Controvalore non coperto da deposito");
				//'Dettaglio
				wdTable.Cell(1, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "IdTransazione"));
				wdTable.Cell(2, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "IdOffertaAcquisto"));
				wdTable.Cell(3, 2).Range.InsertAfter(Converter.DateTimeToStringDateTime(drDettaglioTransazioni, "DataOraOperazione"));
				wdTable.Cell(4, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "AnnoRiferimento"));
				wdTable.Cell(5, 2).Range.InsertAfter(Converter.DecimalToIntegerString(drDettaglioTransazioni, "QtyEseguita"));
				wdTable.Cell(6, 2).Range.InsertAfter(Converter.DecimalToCurrencyString(drDettaglioTransazioni, "PrezzoEseguito"));
				wdTable.Cell(7, 2).Range.InsertAfter(Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTV"));
				wdTable.Cell(8, 2).Range.InsertAfter(Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTVDeposito"));
				wdTable.Cell(9, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "RagioneSocialeVenditore"));

				if ((decimal)drDettaglioTransazioni["CTVNonDeposito"] == 0m)
				{
					wdTable.Cell(10, 2).Range.InsertAfter("");
					wdTable.Cell(11, 2).Range.InsertAfter("");
					wdTable.Cell(12, 2).Range.InsertAfter("");
				}
				else
				{
					wdTable.Cell(10, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "ABI"));;
					wdTable.Cell(11, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "CAB"));
					wdTable.Cell(12, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "CC"));
				}
				wdTable.Cell(13, 2).Range.InsertAfter(Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTVNonDeposito"));
				wdTable.Columns.AutoFit();
			}

			object objExportFileName = wdFileName;
			wdDoc.SaveAs(ref objExportFileName, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
			wdDoc.Close(ref missing, ref missing, ref missing);
			wdApp.Quit(ref missing, ref missing, ref missing);
		}

		public static void CreaReportVenditori(DataSet ds, string IdSocieta, string cbSocietaText, string PartitaIVA, string wdDotFile, string wdFileName)
		{
			// costanti usate nella funzione
			object missing = System.Reflection.Missing.Value;
			int True = -1;
			int False = 0;

			string IdSessione =        (string)   ds.Tables[0].Rows[0]["IdSessione"];
			string Titolo =            (string)   ds.Tables[0].Rows[0]["Titolo"];
			DateTime DataOraApertura = (DateTime) ds.Tables[0].Rows[0]["DataOraApertura"];
			DateTime DataOraChiusura = (DateTime) ds.Tables[0].Rows[0]["DataOraChiusura"];

			_Application wdApp = new ApplicationClass();
			object dotFile = wdDotFile;
			_Document wdDoc = wdApp.Documents.Add(ref dotFile, ref missing, ref missing, ref missing); // TODO aggiungere path e il file da downlodare

			wdDoc.Activate();
			wdDoc.Content.InsertParagraphAfter();

			if (true)
			{
				Range wdRange = wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range;
				wdRange.Font.Name = "Times New Roman";
				wdRange.Font.Size = 14;
				wdRange.Font.Bold = True;
			}

			wdDoc.Range(ref missing, ref missing).InsertAfter("CONFERMA VENDITORI\r\r");


			// Intestazione della seconda pagina in poi
			if (true)
			{
				HeaderFooter wdHeaderFooter = wdDoc.Sections.Item(1).Headers.Item(WdHeaderFooterIndex.wdHeaderFooterPrimary);
				wdHeaderFooter.Range.Font.Name = "Times New Roman";
				wdHeaderFooter.Range.Font.Size = 11;

				wdHeaderFooter.Range.InsertAfter(
					"TITOLO SESSIONE: " + Titolo + 
					" DATA ORA APERTURA: " + Converter.DateTimeToStringDateTime(DataOraApertura) +
					" DATA ORA CHIUSURA: " + Converter.DateTimeToStringDateTime(DataOraChiusura) + "\r");

				wdHeaderFooter.Range.InsertParagraphAfter();

				if (true)
				{
					Table wdTable = wdHeaderFooter.Range.Tables.Add(
						wdHeaderFooter.Range.Paragraphs.Item(wdHeaderFooter.Range.Paragraphs.Count).Range,
						1, 2, ref missing, ref missing);

					wdTable.Range.Font.Name = "Times New Roman";
					wdTable.Range.Font.Size = 11;

					wdTable.Cell(1, 1).Range.Font.Bold = True; 
					wdTable.Cell(1, 1).Range.InsertAfter("Acquirente");
					wdTable.Cell(1, 2).Range.InsertAfter(cbSocietaText); // TODO

					wdTable.Columns.AutoFit();
				}
			}

			// ------------------------------------------------------------------------------
			wdDoc.Content.InsertParagraphAfter();

			if (true)
			{
				Range wdRange = wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range;
				wdRange.Font.Name = "Times New Roman";
				wdRange.Font.Size = 11;
				wdRange.Font.Bold = False;
			}

			if (true)
			{
				wdDoc.Range(ref missing, ref missing).InsertAfter(
					"TITOLO SESSIONE: " + Titolo +
					" DATA ORA APERTURA: " + Converter.DateTimeToStringDateTime(DataOraApertura) +
					" DATA ORA CHIUSURA: " + Converter.DateTimeToStringDateTime(DataOraChiusura) + "\r\r");
			}

			wdDoc.Content.InsertParagraphAfter();
			// '------------------------------------------------------------------------------
			// 'Tabella relativa al venditore
			if (true)
			{
				Table wdTable = wdDoc.Tables.Add(wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range, 1, 2, ref missing, ref missing);
				wdTable.Range.Font.Name = "Times New Roman";
				wdTable.Range.Font.Size = 11;
				wdTable.Cell(1, 1).Range.Font.Bold = True;
				wdTable.Cell(1, 1).Range.InsertAfter("Venditore");
				wdTable.Cell(1, 2).Range.InsertAfter(cbSocietaText);
				wdTable.Columns.AutoFit();
			}

			// '-------------------------------------------------------------------------------
			wdDoc.Content.InsertParagraphAfter();
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Name = "Times New Roman";
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Size = 11;
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Bold = True;
			wdDoc.Range(ref missing, ref missing).InsertAfter("Riepilogo delle operazioni di vendita eseguite:");
			wdDoc.Content.InsertParagraphAfter();
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Name = "Times New Roman";
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Size = 11;
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Bold = False;


			// TODO versione bloccante
			CVAdminWSBLTransazioni.BLTransazioni bl = null;
			DataSet dsTransazioniPerAnno = null;
			DataTable dtTransazioniPerAnno = null;
			try
			{
				bl = new CVAdminWSBLTransazioni.BLTransazioni();
				frmLogin.AddLoginInfo(bl);
				dsTransazioniPerAnno = bl.ListaOperazioniVenditaPerAnno(IdSessione, IdSocieta);
				dtTransazioniPerAnno = dsTransazioniPerAnno.Tables[0];
			}
			catch (Exception e)
			{
				MessageBox.Show(e.Message, "Errore");
				return;
			}

			// '-------------------------------------------------------------------------------
			// 'Visualizzaione delle Transazioni raggruppate per anno
			if (true)
			{
				Table wdTable = wdDoc.Tables.Add(wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range, dtTransazioniPerAnno.Rows.Count + 2, 6, ref missing, ref missing);
				wdTable.Range.Font.Name = "Times New Roman";
				wdTable.Range.Font.Size = 11;
				wdTable.Cell(1, 1).Range.Font.Bold = True;
				wdTable.Cell(1, 1).Range.InsertAfter("Anno Riferimento");
				wdTable.Cell(1, 2).Range.Font.Bold = True;
				wdTable.Cell(1, 2).Range.InsertAfter("Quantit� TOT.");
				wdTable.Cell(1, 3).Range.Font.Bold = True;
				wdTable.Cell(1, 3).Range.InsertAfter("Prezzo Medio Vendita");
				wdTable.Cell(1, 4).Range.Font.Bold = True;
				wdTable.Cell(1, 4).Range.InsertAfter("CTV coperto da deposito");
				wdTable.Cell(1, 5).Range.Font.Bold = True;
				wdTable.Cell(1, 5).Range.InsertAfter("CTV non coperto da deposito");
				wdTable.Cell(1, 6).Range.Font.Bold = True;
				wdTable.Cell(1, 6).Range.InsertAfter("CTV TOT.");

				int X = 2;

				decimal QTot = 0m;
				decimal CtvCopertoTot = 0m;
				decimal CtvNonCopertoTot = 0m;
				decimal CtvTotale = 0m;

				foreach (DataRow drTransazioniPerAnno in dtTransazioniPerAnno.Rows)
				{
					wdTable.Cell(X, 1).Range.InsertAfter(Converter.StringToString(drTransazioniPerAnno, "AnnoRiferimento"));
					wdTable.Cell(X, 2).Range.InsertAfter(Converter.DecimalToIntegerString(drTransazioniPerAnno, "QTot"));
					QTot += (decimal)drTransazioniPerAnno["QTot"];

					wdTable.Cell(X, 3).Range.InsertAfter(Converter.DecimalToCurrencyString((decimal)drTransazioniPerAnno["PMedioV"] + 0.001m));

					wdTable.Cell(X, 4).Range.InsertAfter(Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVCoperto"));
					CtvCopertoTot += (decimal)drTransazioniPerAnno["CTVCoperto"];

					wdTable.Cell(X, 5).Range.InsertAfter(Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVNonCoperto"));
					CtvNonCopertoTot += (decimal)drTransazioniPerAnno["CTVNonCoperto"];

					wdTable.Cell(X, 6).Range.InsertAfter(Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVTot"));
					CtvTotale += (decimal)drTransazioniPerAnno["CTVTot"];

					X += 1;
				}
				wdTable.Columns.AutoFit();


				wdTable.Cell(X, 1).Range.InsertAfter("TOTALE");
				wdTable.Cell(X, 2).Range.InsertAfter(Converter.DecimalToIntegerString(QTot));
				wdTable.Cell(X, 4).Range.InsertAfter(Converter.DecimalToCurrencyString(CtvCopertoTot));
				wdTable.Cell(X, 5).Range.InsertAfter(Converter.DecimalToCurrencyString(CtvNonCopertoTot));
				wdTable.Cell(X, 6).Range.InsertAfter(Converter.DecimalToCurrencyString(CtvTotale));
			}

			// '--------------------------------------------------------------------------------
			// 'Transazioni raggruppate per Acquirente

			DataSet   dsTransazioniPerAcquirente = bl.ListaOperazioniVenditaPerAcquirente(IdSessione, IdSocieta);
			DataTable dtTransazioniPerAcquirente = dsTransazioniPerAcquirente.Tables[0];

			wdDoc.Content.InsertParagraphAfter();
			if (true)
			{
				Table wdTable = wdDoc.Tables.Add(wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range, dtTransazioniPerAcquirente.Rows.Count + 2, 3, ref missing, ref missing);

				wdTable.Range.Font.Name = "Times New Roman";
				wdTable.Range.Font.Size = 11;
				wdTable.Cell(1, 1).Range.Font.Bold = True;
				wdTable.Cell(1, 1).Range.InsertAfter("Venditore");
				wdTable.Cell(1, 2).Range.Font.Bold = True;
				wdTable.Cell(1, 2).Range.InsertAfter("Acquirente");
				wdTable.Cell(1, 3).Range.Font.Bold = True;
				wdTable.Cell(1, 3).Range.InsertAfter("CTV da ricevere");
				wdTable.Cell(2, 1).Range.InsertAfter(cbSocietaText);

				int X = 3;

				foreach (DataRow drTransazioniPerAcquirente in dtTransazioniPerAcquirente.Rows)
				{
					wdTable.Cell(X, 2).Range.InsertAfter(Converter.StringToString(drTransazioniPerAcquirente, "RagioneSocialeAcquirente"));
					wdTable.Cell(X, 3).Range.InsertAfter(Converter.DecimalToCurrencyString(drTransazioniPerAcquirente, "CTVDaRicevere"));
					X += 1;
				}
				wdTable.Columns.AutoFit();
			}


			// '--------------------------------------------------------------------------------
			wdDoc.Content.InsertParagraphAfter();
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Name = "Times New Roman";
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Size = 11;
			wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Bold = True;
			wdDoc.Range(ref missing, ref missing).InsertAfter("Dettaglio delle singole operazioni:");

			// '--------------------------------------------------------------------------------
			// 'Dettaglio delle Transazioni
			DataSet dsDettaglioTransazioni = bl.DettagliVendite(IdSessione, IdSocieta);
			DataTable dtDettaglioTransazioni = dsDettaglioTransazioni.Tables[0];

			foreach (DataRow drDettaglioTransazioni in dtDettaglioTransazioni.Rows)
			{
				wdDoc.Content.InsertParagraphAfter();
				wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Name = "Times New Roman";
				wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Size = 11;
				wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range.Font.Bold = False;

				Table wdTable = wdDoc.Tables.Add(wdDoc.Paragraphs.Item(wdDoc.Paragraphs.Count).Range, 11, 2, ref missing, ref missing);
				wdTable.Cell( 1, 1).Range.Font.Bold = True;
				wdTable.Cell( 1, 1).Range.InsertAfter("IdTransazione");
				wdTable.Cell( 2, 1).Range.Font.Bold = True;
				wdTable.Cell( 2, 1).Range.InsertAfter("IdOffertaVendita");
				wdTable.Cell( 3, 1).Range.Font.Bold = True;
				wdTable.Cell( 3, 1).Range.InsertAfter("Data Ora Operazione");
				wdTable.Cell( 4, 1).Range.Font.Bold = True;
				wdTable.Cell( 4, 1).Range.InsertAfter("Anno Riferimento");
				wdTable.Cell( 5, 1).Range.Font.Bold = True;
				wdTable.Cell( 5, 1).Range.InsertAfter("Quantit� eseguita");
				wdTable.Cell( 6, 1).Range.Font.Bold = True;
				wdTable.Cell( 6, 1).Range.InsertAfter("Prezzo eseguito");
				wdTable.Cell( 7, 1).Range.Font.Bold = True;
				wdTable.Cell( 7, 1).Range.InsertAfter("Controvalore");
				wdTable.Cell( 8, 1).Range.Font.Bold = True;
				wdTable.Cell( 8, 1).Range.InsertAfter("Controvalore coperto da deposito");
				wdTable.Cell( 9, 1).Range.Font.Bold = True;
				wdTable.Cell( 9, 1).Range.InsertAfter("Controvalore non coperto da deposito");
				wdTable.Cell(10, 1).Range.Font.Bold = True;
				wdTable.Cell(10, 1).Range.InsertAfter("Ragione Sociale Acquirente");
				wdTable.Cell(11, 1).Range.Font.Bold = True;
				wdTable.Cell(11, 1).Range.InsertAfter("Partita IVA Acquirente");

				//'Dettaglio
				wdTable.Cell(1, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "IdTransazione"));
				wdTable.Cell(2, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "IdOffertaVendita"));
				wdTable.Cell(3, 2).Range.InsertAfter(Converter.DateTimeToStringDateTime(drDettaglioTransazioni, "DataOraOperazione"));
				wdTable.Cell(4, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "AnnoRiferimento"));
				wdTable.Cell(5, 2).Range.InsertAfter(Converter.DecimalToIntegerString(drDettaglioTransazioni, "QtyEseguita"));
				wdTable.Cell(6, 2).Range.InsertAfter(Converter.DecimalToCurrencyString(drDettaglioTransazioni, "PrezzoEseguito"));
				wdTable.Cell(7, 2).Range.InsertAfter(Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTV"));
				wdTable.Cell(8, 2).Range.InsertAfter(Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTVDeposito"));
				wdTable.Cell(9, 2).Range.InsertAfter(Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTVNonDeposito"));
				wdTable.Cell(10, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "RagioneSocialeAcquirente"));
				wdTable.Cell(11, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "PartitaIVAAcquirente"));

//				if ((decimal)drDettaglioTransazioni["CTVNonDeposito"] == 0m)
//				{
//					wdTable.Cell(10, 2).Range.InsertAfter("");
//				}
//				else
//				{
//					wdTable.Cell(10, 2).Range.InsertAfter(Converter.StringToString(drDettaglioTransazioni, "RagioneSocialeAcquirente"));
//				}
				wdTable.Columns.AutoFit();
			}
			object objExportFileName = wdFileName;
			wdDoc.SaveAs(ref objExportFileName, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
			wdDoc.Close(ref missing, ref missing, ref missing);
			wdApp.Quit(ref missing, ref missing, ref missing);
		}
	}
}
