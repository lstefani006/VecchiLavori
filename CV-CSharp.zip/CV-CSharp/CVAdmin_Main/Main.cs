using System;
using System.Drawing;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml;
using System.Text;
using System.IO;

namespace CVAdmin_Main
{
	/// <summary>
	/// classe per leggere i dati di configurazione della DLL CVAdmin_Main
	/// provenienti dal file di configurazione CVAdmin_Main.xml
	/// scaricato dal sito remoto ad ogni collegamento di CVAdminHost
	/// </summary>
	public class LocalSettings
	{
		private static LocalSettings _LocalSettings = new LocalSettings();

		public static LocalSettings appSettings
		{
			get { return _LocalSettings; }
		}

		public LocalSettings()
		{
		}

		/// <summary>
		/// data la chiave ritorna il valore assiociato al file.
		/// Ritorna <code>null</code> se la <code>key</code> non e' specificata nel file.
		/// </summary>
		public string this [string key]
		{
			get { return _c.Get(key); }
		}

		public void ReadXml(string xml)
		{
			if (xml == null)
				return;

			try
			{
				StringReader sr = new StringReader(xml);
				XmlTextReader tr = new XmlTextReader(sr);

				while (tr.Read())
				{
					if (tr.NodeType == XmlNodeType.Element)
					{
						if (tr.Name == "add" && tr.HasAttributes)
						{
							string k = null;
							string v = null;

							while (tr.MoveToNextAttribute())
							{
								switch (tr.Name)
								{
								case "key": 
									k = tr.Value; 
									break;

								case "value": 
									v = tr.Value; 
									break;
								}
							}

							if (k != null && v != null)
								_c.Add(k,v);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Trace.WriteLineIf(_.Error, ex.Message);
			}

		}
		private NameValueCollection _c = new NameValueCollection();
	};


	/// <summary>
	/// Summary description for MainFormRunner.
	/// </summary>
	public class MainFormRunner
	{

		public Form _mainForm = null;

		public void Run(Form mainForm, string CVAdmin_MainXml)
		{
			_mainForm = mainForm;

			CVAdmin_Main.LocalSettings.appSettings.ReadXml(CVAdmin_MainXml);

			this.mainMenu = new System.Windows.Forms.MainMenu();
			if (true)
			{
				this.mnSocietaUtenti = new MenuItem("Societ�/utenti");
				this.mnGestioneRichieste = new System.Windows.Forms.MenuItem();
				this.mnGestioneSocietaUtenti = new System.Windows.Forms.MenuItem();
				this.mnGestionePINSocieta = new System.Windows.Forms.MenuItem();
			}

			this.mnGestioneSessioni = new System.Windows.Forms.MenuItem();
			this.mnBudget = new System.Windows.Forms.MenuItem();
			this.mnLogOfferte = new System.Windows.Forms.MenuItem();
			this.mnGestioneTransazioni = new System.Windows.Forms.MenuItem();
			this.mnSituazioneOperatore = new System.Windows.Forms.MenuItem();
			this.mnGestioneValoreCV = new System.Windows.Forms.MenuItem();
//			this.mnReport = new System.Windows.Forms.MenuItem();
			this.mnPagamenti = new System.Windows.Forms.MenuItem();
			this.mnBook = new System.Windows.Forms.MenuItem();
			this.mnGestioneCorrispettivi = new System.Windows.Forms.MenuItem();
			this.mnSessioneBancaria = new System.Windows.Forms.MenuItem();
			this.mnEsci = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
				this.mnSocietaUtenti,
				this.mnGestioneSessioni,
				this.mnBudget,
				this.mnLogOfferte,
				this.mnGestioneTransazioni,
				this.mnSituazioneOperatore,
				this.mnGestioneValoreCV,
//				this.mnReport,
				this.mnPagamenti,
				this.mnBook,
			    this.mnGestioneCorrispettivi,
				this.mnSessioneBancaria,
				this.mnEsci});

			// mnSocietaUtenti
			if (true)
			{
				// mnGestioneRichieste
				this.mnGestioneRichieste.Text = "Gestione Richieste";
				this.mnGestioneRichieste.Click += new System.EventHandler(this.mnGestioneRichieste_Click);
				this.mnSocietaUtenti.MenuItems.Add(this.mnGestioneRichieste);

				// mnGestioneSocietaUtenti
				this.mnGestioneSocietaUtenti.Text = "Gestione Societ�/Utenti";
				this.mnGestioneSocietaUtenti.Click += new System.EventHandler(this.mnGestioneSocietaUtenti_Click);
				this.mnSocietaUtenti.MenuItems.Add(this.mnGestioneSocietaUtenti);

				// mnGestionePINSocieta
				this.mnGestionePINSocieta.Text = "Gestione PIN Societario";
				this.mnGestionePINSocieta.Click += new System.EventHandler(this.mnGestionePINSocieta_Click);
				this.mnSocietaUtenti.MenuItems.Add(this.mnGestionePINSocieta);
			}

			// 
			// mnGestioneSessioni
			// 
			this.mnGestioneSessioni.Text = "Gestione Sessioni";
			this.mnGestioneSessioni.Click += new System.EventHandler(this.mnGestioneSessioni_Click);
			// 
			// mnBudget
			// 
			this.mnBudget.Text = "Budget";
			this.mnBudget.Click += new System.EventHandler(this.mnBudget_Click);
			// 
			// mnLogOfferte
			// 
			this.mnLogOfferte.Text = "Log-Offerte";
			this.mnLogOfferte.Click += new System.EventHandler(this.mnLogOfferte_Click);
			// 
			// mnGestioneTransazioni
			// 
			this.mnGestioneTransazioni.Text = "Gestione Transazioni";
			this.mnGestioneTransazioni.Click += new System.EventHandler(this.mnGestioneTransazioni_Click);
			// 
			// mnSituazioneOperatore
			// 
			this.mnSituazioneOperatore.Text = "Situazione Operatori";
			this.mnSituazioneOperatore.Click += new System.EventHandler(this.mnSituazioneOperatore_Click);

#if VECCHIO_MWCERTIFICATO //Stefano
			// 
			// mnGestioneValoreCV
			// 
			this.mnGestioneValoreCV.Text = "Gestione Valore CV";
			this.mnGestioneValoreCV.Click += new System.EventHandler(this.mnGestioneValoreCV_Click);
#endif
			// 
			// mnReport
			// 
//			this.mnReport.Text = "Report";
//			this.mnReport.Click += new System.EventHandler(this.mnReport_Click);
			// 
			// mnPagamenti
			// 
			this.mnPagamenti.Text = "Pagamenti";
			this.mnPagamenti.Click += new System.EventHandler(this.mnPagamenti_Click);
			// 
			// mnBook
			// 
			this.mnBook.Text = "Book";
			this.mnBook.Click += new System.EventHandler(this.mnBook_Click);
			// 
			// mnGestioneCorrispettivi
			// 
			this.mnGestioneCorrispettivi.Text = "Gestione Corrispettivi";
			this.mnGestioneCorrispettivi.Click += new System.EventHandler(this.mnGestioneCorrispettivi_Click);
			// 
			// mnSessioneBancaria
			// 
			this.mnSessioneBancaria.Text = "Sessione bancaria";
			this.mnSessioneBancaria.Click += new System.EventHandler(this.mnSessioneBancaria_Click);
			// 
			// 
			// mnEsci
			// 
			this.mnEsci.Text = "Esci";
			this.mnEsci.Click += new System.EventHandler(this.mnEsci_Click);

			mainForm.Menu = this.mainMenu;

			// disabilito tutto il menu'
			foreach (MenuItem m in this.mainMenu.MenuItems)
				m.Enabled = false;
			this.mnEsci.Enabled = true;  // eccetto Esci

			_mainForm.Closing += new System.ComponentModel.CancelEventHandler(this.Form_Closing);

			using (frmLogin f = new frmLogin())
			{
				DialogResult r = f.ShowDialog(_mainForm);
				if (r != DialogResult.OK)
				{
					this.mnEsci.Enabled = true;
				}
				else
				{
					foreach (MenuItem m in this.mainMenu.MenuItems)
						m.Enabled = true;
				}
			}
		}

		private void mnGestioneRichieste_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmGestRichieste frm = new frmGestRichieste())
				{
					frm.ShowDialog(_mainForm);
				}
			}
		
		}

		private void mnGestioneSocietaUtenti_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmSocietaUtenti frm = new frmSocietaUtenti())
				{
					frm.ShowDialog(_mainForm);
				}
			}
		
		}

		private void mnPagamenti_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmPagamenti frm = new frmPagamenti())
				{
					frm.ShowDialog();
				}
			}
		}

		private void mnGestioneSessioni_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmSessioni frm = new frmSessioni())
				{
					frm.ShowDialog(_mainForm);
				}
			}
		}

		private void mnBudget_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmSessioniBudget frm = new frmSessioniBudget())
				{
					frm.ShowDialog(_mainForm);
				}
			}
		}

		private void mnLogOfferte_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				string IdSessione = null;

				using (frmScegliSessione frm = new frmScegliSessione())
				{
					if (frm.ShowDialog(_mainForm) != DialogResult.OK)
						return;

					DataRow dr = frm.SelectedSessionRow;
					if (dr == null)
						return;

					IdSessione = (string)dr["IdSessione"];
				}

				using (frmLogOfferte frmLogOfferte = new frmLogOfferte(IdSessione))
				{
					frmLogOfferte.ShowDialog(_mainForm);
				}
			}
		}

		private void mnGestioneTransazioni_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				DialogResult dialogResult = DialogResult.Cancel;
				using (frmScegliSessione frm = new frmScegliSessione())
				{
					do
					{
						dialogResult = frm.ShowDialog(_mainForm);
						if (dialogResult == DialogResult.Cancel)
							return;

						DataRow dr = frm.SelectedSessionRow;
						if (dr == null)
							return;

						DataSet ds = GetListaTransazioniSessione("", (string)dr["IdSessione"], "T");
						if (ds == null)
							return;

						if (ds.Tables[0].Rows.Count == 0)
						{
							MessageBox.Show("Non ci sono transazioni per la sessione \"" + (string)dr["Titolo"] + "\"", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Information);
						}
						else
						{
							using (frmTransazioni frmTran = new frmTransazioni(dr, ds))
							{
								frmTran.ShowDialog(_mainForm);
							}
						}
					}
					while(dialogResult != DialogResult.Cancel);
				}
			}
		}

		private DataSet GetListaTransazioniSessione(string RagioneSociale, string IdSessione, string TipoRicerca)
		{
			bool Cancelled;
			object ret = frmAsyncWait.DoSoapCall(out Cancelled, 
				"CVAdmin_Main.CVAdminWSBLTransazioni.BLTransazioni.Ricerca",
				RagioneSociale,
				IdSessione,
				TipoRicerca);

			if (Cancelled)
				return null;
			return (DataSet)ret;
		}

		private void mnSituazioneOperatore_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				DialogResult dialogResult = DialogResult.Cancel;
				using (frmScegliSessione frm = new frmScegliSessione())
				{
					do
					{
						dialogResult = frm.ShowDialog(_mainForm);
						if (dialogResult == DialogResult.Cancel)
							return;

						DataRow dr = frm.SelectedSessionRow;
						if (dr == null)
							return;

						frmSituazioneOperatori frmSituazioneOp = new frmSituazioneOperatori(dr);
						frmSituazioneOp.ShowDialog(_mainForm);
					}
					while(dialogResult != DialogResult.Cancel);
				}
			}
		}

		private void mnGestioneValoreCV_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmGestioneValoreCV frm = new frmGestioneValoreCV())
				{
					frm.ShowDialog(_mainForm);
				}
			}
		}

//		private void mnReport_Click(object sender, System.EventArgs e)
//		{
//			using(WaitCursor wc = new WaitCursor())
//			{
//				using (frmReport frm = new frmReport())
//				{
//					frm.ShowDialog();
//				}
//			}
//		}

		private void mnBook_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmBook frm = new frmBook())
				{
					frm.ShowDialog(_mainForm);
				}
			}
		}

		private void mnGestioneCorrispettivi_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmGestioneCorrispettivi frm = new frmGestioneCorrispettivi())
				{
					frm.ShowDialog(_mainForm);
				}
			}
		}

		private void mnGestionePINSocieta_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmGestionePINSocieta frm = new frmGestionePINSocieta())
				{
					frm.ShowDialog(_mainForm);
				}
			}
		}


		private void mnSessioneBancaria_Click(object sender, EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				using (frmScegliSessione frm = new frmScegliSessione("StatoSessione='Terminata' OR StatoSessione='Chiusa'"))
				{
					DialogResult dialogResult = DialogResult.Cancel;
					do
					{
						dialogResult = frm.ShowDialog(_mainForm);
						if (dialogResult == DialogResult.Cancel)
							return;

						DataRow dr = frm.SelectedSessionRow;
						if (dr == null)
							return;

						using (frmSessioneBancaria frmSessioneBancaria = new frmSessioneBancaria((string)dr["IdSessione"]))
						{
							frmSessioneBancaria.ShowDialog(_mainForm);
						}
					}
					while(dialogResult != DialogResult.Cancel);
				}
			}
		}

		private void mnEsci_Click(object sender, System.EventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				_mainForm.Close();
			}
		}


		private void Form_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			using(WaitCursor wc = new WaitCursor())
			{
				if (frmLogin.IsLogged)
				{
					try
					{
						CVAdminWSLogin.BLLogin ws = new CVAdminWSLogin.BLLogin();
						frmLogin.AddLoginInfo(ws);

						// La chiamata Logout e' marcata come OneWay
						// per cui aspetto solo che il server l'abbia
						// ricevuta.
						IAsyncResult asr = ws.BeginLogout(null, null);

						frmAsyncWait frm = new frmAsyncWait(asr);
						frm.ShowDialog();
					}
					catch (Exception)
					{
					}
				}
			}
		}

		private System.Windows.Forms.MainMenu mainMenu;

		private System.Windows.Forms.MenuItem mnSocietaUtenti;
		private System.Windows.Forms.MenuItem mnGestioneRichieste;
		private System.Windows.Forms.MenuItem mnGestioneSocietaUtenti;
		private System.Windows.Forms.MenuItem mnGestionePINSocieta;

		private System.Windows.Forms.MenuItem mnGestioneSessioni;
		private System.Windows.Forms.MenuItem mnBudget;
		private System.Windows.Forms.MenuItem mnGestioneValoreCV;

		private System.Windows.Forms.MenuItem mnBook;
		private System.Windows.Forms.MenuItem mnLogOfferte;
		private System.Windows.Forms.MenuItem mnGestioneTransazioni;
		private System.Windows.Forms.MenuItem mnSituazioneOperatore;
//		private System.Windows.Forms.MenuItem mnReport;
		private System.Windows.Forms.MenuItem mnPagamenti;
		private System.Windows.Forms.MenuItem mnGestioneCorrispettivi;
		private System.Windows.Forms.MenuItem mnSessioneBancaria;
		private System.Windows.Forms.MenuItem mnEsci;
	}
}
