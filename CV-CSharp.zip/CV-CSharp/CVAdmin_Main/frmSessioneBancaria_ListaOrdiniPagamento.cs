using System;
using System.Drawing;
using System.Data;
using System.Collections;
using System.Diagnostics;
using System.ComponentModel;
using System.Windows.Forms;

namespace CVAdmin_Main
{
	/// <summary>
	/// Summary description for frmListaOrdiniPagamento.
	/// </summary>
	public class frmListaOrdiniPagamento : System.Windows.Forms.Form
	{
		private DataSet ds = null;
		public string IdReport = null;
		public string TipoReport = null;

		private System.Windows.Forms.DataGrid dg;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnVisualizza;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmListaOrdiniPagamento()
		{
			InitializeComponent();
		}

		public frmListaOrdiniPagamento(DataSet ds)
			:this()
		{
			this.ds = ds;

			DataGridTableStyle dgStyle = new DataGridTableStyle();
			dgStyle.MappingName = "ListaSP";
			dgStyle.AllowSorting = true;

			DataGridTextBoxColumn dgc;

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Tipo";
			dgc.MappingName = "TipoReport";
			dgc.Width = 50;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Data creazione";
			dgc.MappingName = "TSCreazione";
			dgc.Format = "G";
			dgc.Alignment = HorizontalAlignment.Right;
			dgc.Width = 120;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Data invio";
			dgc.MappingName = "TSInvio";
			dgc.Format = "G";
			dgc.NullText = "<non inviato>";
			dgc.Alignment = HorizontalAlignment.Right;
			dgc.Width = 120;
			dgStyle.GridColumnStyles.Add(dgc);

			dgc = new DataGridTextBoxColumn();
			dgc.HeaderText = "Descrizione";
			dgc.MappingName = "NomeReport";
			dgc.Width = 400;
			dgStyle.GridColumnStyles.Add(dgc);


			dg.TableStyles.Add(dgStyle);

			dg.DataSource = ds;
			dg.DataMember = "ListaSP";
			dg.AllowSorting = true;


			Debug.Assert(this.BindingContext.Contains(ds, "ListaSP"));
			CurrencyManager cm =  (CurrencyManager)this.BindingContext[ds, "ListaSP"];
			DataView dv = (DataView)cm.List;
			dv.AllowEdit = false;
			dv.AllowDelete = false;
			dv.AllowNew = false;
			dv.Sort = "TSCreazione DESC";
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmListaOrdiniPagamento));
			this.dg = new System.Windows.Forms.DataGrid();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnVisualizza = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
			this.SuspendLayout();
			// 
			// dg
			// 
			this.dg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dg.CaptionVisible = false;
			this.dg.DataMember = "";
			this.dg.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dg.Location = new System.Drawing.Point(8, 8);
			this.dg.Name = "dg";
			this.dg.Size = new System.Drawing.Size(656, 224);
			this.dg.TabIndex = 0;
			this.dg.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dg_MouseDown);
			this.dg.DoubleClick += new System.EventHandler(this.dg_DoubleClick);
			this.dg.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dg_MouseUp);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.Location = new System.Drawing.Point(544, 248);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(112, 23);
			this.btnCancel.TabIndex = 1;
			this.btnCancel.Text = "Cancella";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnVisualizza
			// 
			this.btnVisualizza.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnVisualizza.Location = new System.Drawing.Point(416, 248);
			this.btnVisualizza.Name = "btnVisualizza";
			this.btnVisualizza.Size = new System.Drawing.Size(112, 23);
			this.btnVisualizza.TabIndex = 2;
			this.btnVisualizza.Text = "Visualizza";
			this.btnVisualizza.Click += new System.EventHandler(this.btnVisualizza_Click);
			// 
			// frmListaOrdiniPagamento
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 277);
			this.Controls.Add(this.btnVisualizza);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.dg);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmListaOrdiniPagamento";
			this.Text = "Lista ordini di pagamento";
			((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void btnVisualizza_Click(object sender, System.EventArgs e)
		{
			CurrencyManager cm =  (CurrencyManager)this.BindingContext[ds, "ListaSP"];
			DataView dv = (DataView)cm.List;

			if (dv.Count == 0)
				return;
			
			DataRow dr = dv[cm.Position].Row;
			IdReport = (string)dr["IdReport"];
			TipoReport = (string)dr["TipoReport"];
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void dg_DoubleClick(object sender, System.EventArgs e)
		{
			btnVisualizza_Click(sender, e);
		}

		private void dg_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Clicks == 2)
			{
				DataGrid.HitTestInfo hti = this.dg.HitTest(new Point(e.X, e.Y));
				if (hti.Type == DataGrid.HitTestType.Cell)
					btnVisualizza_Click(sender, e);
			}
		}

		private void dg_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			DataGrid.HitTestInfo hti = this.dg.HitTest(new Point(e.X, e.Y));
			if (hti.Type == DataGrid.HitTestType.Cell)
			{
				this.dg.CurrentCell = new DataGridCell(hti.Row, hti.Column);
				this.dg.Select(hti.Row);
			}		
		}
	}
}
