using System;
using System.Data;
using System.Diagnostics;
using System.Configuration;
using System.Globalization;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;
using System.Web.Services.Protocols;
using System.Net;

namespace CVAdmin_Main
{
	/// <summary>
	/// Classe di utilita' per convertire da stringa verso decimal e viceversa
	/// </summary>
	public class Converter
	{
		static private CultureInfo ci = null;

		public static CultureInfo DefaultCultureInfo 
		{ 
			get { ReadCulture(); return ci; } 
		}

		private static void ReadCulture()
		{
			if (ci == null)
			{
				bool bUseOverride = false;

				string strUseOverride = LocalSettings.appSettings["CultureInfo.UseOverride"];
				if (strUseOverride != null)
				{
					strUseOverride = strUseOverride.ToLower();
					if (strUseOverride == "true" ||
						strUseOverride == "yes" || 
						strUseOverride == "si" || 
						strUseOverride == "1")
					{
						bUseOverride = true;
					}
				}


				ci = new CultureInfo("it-IT", bUseOverride);
				if (ci.NumberFormat.CurrencySymbol != "�")
					ci.NumberFormat.CurrencySymbol = "�";
			}
		}

		/// <summary>
		/// Conversione da un decimal che rappresenta un currency ad una stringa
		/// rispettando il formato italiano di default (non quello utente).
		/// Il formato dovrebbe essere �1.234,56
		/// </summary>
		/// <param name="d">la quantita' di euro da convertire</param>
		/// <returns>la stringa in euro</returns>
 		public static string DecimalToCurrencyString(decimal d)
		{
			ReadCulture();
			return d.ToString("c", ci.NumberFormat);
		}
		/// <summary>
		/// Conversione da decima a string in formato currency
		/// Da usare nell'evento Format
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="cevent"></param>
		public static void DecimalToCurrencyString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(string))
			{
				decimal d = ((decimal) cevent.Value);
				cevent.Value = Converter.DecimalToCurrencyString(d);
			}
		}
		/// <summary>
		/// Converte un decimal in una stringa in formato currency
		/// partendo da un DataRow e una colonna. Se il valore e' null
		/// viene ritornata  ""
		/// </summary>
		/// <param name="dr">il data row da cui prelevare il valore da convertire</param>
		/// <param name="columnName">la colonna nel data row da leggere</param>
		/// <returns>la stringa in formato currency</returns>
		public static string DecimalToCurrencyString(DataRow dr, string columnName)
		{
			if (dr.IsNull(columnName))
				return "";

			return DecimalToCurrencyString((decimal)dr[columnName]);
		}
		
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////


		/// <summary>
		/// parsifica la stringa in ingresso per ottere un decimal
		/// La stringa deve essere in formato �1.234,56
		/// In caso di errore di formattazione viene lanciata una eccezione
		/// </summary>
		/// <param name="s">stringa da convertire</param>
		/// <returns>il numero convertito</returns>
		public static decimal CurrencyStringToDecimal(string s)
		{
			ReadCulture();

			// faccio due volte parse per ottenere il giusto numero di cifre significative
			// anche nel decimal e non solo nella stringa che lo rappresenta.
			decimal r = decimal.Parse(s, NumberStyles.Currency, ci.NumberFormat);
			string g = DecimalToCurrencyString(r);
			return decimal.Parse(g, NumberStyles.Currency, ci.NumberFormat);
		}
		/// <summary>
		/// parsifica la stringa in ingresso per ottere un decimal
		/// La stringa deve essere in formato �1.234,56
		/// </summary>
		/// <param name="s">la stringa da convertire</param>
		/// <param name="d">il numero convertito</param>
		/// <returns>true se la conversione e' avvenuta con successo</returns>
		public static bool CurrencyStringToDecimal(string s, out decimal d)
		{
			try
			{
				d = CurrencyStringToDecimal(s);
				return true;
			}
			catch (Exception)
			{
				d = 0m;
				return false;
			}
		}
		/// <summary>
		/// Prende un decimal e lo stampa su stringa in formato currency
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="cevent"></param>
		public static void CurrencyStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(decimal))
				cevent.Value = Converter.CurrencyStringToDecimal(cevent.Value.ToString());
		}

		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////

		/// <summary>
		/// Conversione da numero (non valuta!!) a stringa nel formato
		/// italiano 1.234,56
		/// </summary>
		/// <param name="d">numero da formtattare</param>
		/// <returns>stringa formattata</returns>
		public static string DecimalToNumberString(decimal d)
		{
			ReadCulture();
			return d.ToString("n", ci.NumberFormat);
		}
		public static string DecimalToNumberString(DataRow dr, string columnName)
		{
			ReadCulture();
			if (dr.IsNull(columnName))
				return "";
			return DecimalToNumberString((decimal)dr[columnName]);
		}
		public static void DecimalToNumberString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(string))
			{
				decimal d = ((decimal) cevent.Value);
				cevent.Value = Converter.DecimalToNumberString(d);
			}
		}
		/// <summary>
		/// parsifica la stringa in ingresso per ottere un decimal
		/// La stringa deve essere in formato 1.234,56
		/// In caso di errore di formattazione viene lanciata una eccezione
		/// </summary>
		/// <param name="s">stringa da convertire</param>
		/// <returns>il numero</returns>
		public static decimal NumberStringToDecimal(string s)
		{
			ReadCulture();
			decimal d = decimal.Parse(s, NumberStyles.Number, ci.NumberFormat);
			string g = DecimalToNumberString(d);
			return decimal.Parse(g, NumberStyles.Number, ci.NumberFormat);
		}
		/// <summary>
		/// parsifica la stringa in ingresso per ottere un decimal
		/// La stringa deve essere in formato 1.234,56
		/// </summary>
		/// <param name="s">la stringa da convertire</param>
		/// <param name="d">il numero convertito</param>
		/// <returns>true se la conversione e' avvenuta con successo</returns>
		public static bool NumberStringToDecimal(string s, out decimal d)
		{
			try
			{
				d = NumberStringToDecimal(s);
				return true;
			}
			catch (Exception)
			{
				d = 0m;
				return false;
			}
		}
		public static void NumberStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(decimal))
			{
				string s = (string)cevent.Value;
				cevent.Value = Converter.NumberStringToDecimal(s);
			}
		}
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////

		/// <summary>
		/// Conversione da numero (non valuta!!) a stringa nel formato
		/// italiano 1.234.333  (senza parte decimale!!!!)
		/// </summary>
		/// <param name="d">numero da formtattare</param>
		/// <returns>stringa formattata</returns>
		public static string DecimalToIntegerString(decimal d)
		{
			ReadCulture();
			return d.ToString("#,#0", ci.NumberFormat);
		}
		public static string DecimalToIntegerString(DataRow dr, string columnName)
		{
			if (dr.IsNull(columnName))
				return "";

			return DecimalToIntegerString((decimal)dr[columnName]);
		}
		public static void DecimalToIntegerString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(string))
			{
				decimal d = ((decimal) cevent.Value);
				cevent.Value = Converter.DecimalToIntegerString(d);
			}
		}
		public static decimal IntegerStringToDecimal(string s)
		{
			ReadCulture();
			if (s.IndexOf(ci.NumberFormat.NumberDecimalSeparator) != -1)
				throw new FormatException("non si accetta il punto decimale"); 
			return decimal.Parse(s, NumberStyles.Number, ci.NumberFormat);
		}
		public static void IntegerStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(decimal))
			{
				string s = (string)cevent.Value;
				cevent.Value = Converter.IntegerStringToDecimal(s);
			}
		}
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////

		public static string StringToString(DataRow dr, string columnName)
		{
			ReadCulture();

			if (dr.IsNull(columnName))
				return "";

			return (string)dr[columnName];
		}

		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////

		/// <summary>
		/// converte la data nel formato "g" che dovrebbe essere in italiano 23/1/2003 15:33:59
		/// </summary>
		/// <param name="dt"></param>
		/// <returns></returns>
		public static string DateTimeToStringDateTime(DateTime dt)
		{
			ReadCulture();
			return dt.ToString("g", ci.DateTimeFormat);
		}
		/// <summary>
		/// converte la data nel formato "g" che dovrebbe essere in italiano 23/1/2003 15:33:59.
		/// Valori DbNull sono convertiti in ""
		/// </summary>
		/// <param name="dr">DataRow da cui estrarre il campo</param>
		/// <param name="columnName">colonna del data row</param>
		/// <returns></returns>
		public static string DateTimeToStringDateTime(DataRow dr, string columnName)
		{
			ReadCulture();

			if (dr.IsNull(columnName))
				return "";

			return DateTimeToStringDateTime((DateTime)dr[columnName]);
		}
		/// <summary>
		/// Converte il DateTime nella sola data formato 21/1/2004
		/// </summary>
		/// <param name="dt"></param>
		/// <returns></returns>
		public static string DateTimeToStringDate(DateTime dt)
		{
			ReadCulture();
			return dt.ToString("d", ci.DateTimeFormat);
		}
	}

	public class NewIdHelper
	{
		public static string NewId()
		{
			Guid g = Guid.NewGuid();
			return g.ToString("N").ToUpper();
//			try
//			{
//				CVAdminWSLogin.BLLogin ws = new CVAdminWSLogin.BLLogin();
//				frmLogin.AddLoginInfo(ws);
//				return ws.NewId();
//			}
//			catch (Exception e)
//			{
//				throw e;
//			}
		}
	};


	public sealed class WaitCursor : IDisposable
	{
		public WaitCursor()
		{
			_cursor = Cursor.Current;
			Cursor.Current = Cursors.WaitCursor;
		}

		public void PutArrow()           { Cursor.Current = Cursors.Arrow; }
		public void PutWaitCursor()      { Cursor.Current = Cursors.WaitCursor; }
		public void PuttCursor(Cursor c) { Cursor.Current = c; }

		public void RestoreCursor() { Cursor.Current = _cursor; }

		~WaitCursor()
		{
			Dispose(false);
		}

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (_disposed == false)
				{
					_disposed = true;
					Cursor.Current = _cursor;
				}
			}
		}

		private bool _disposed = false;
		private Cursor _cursor = null;
	}

	/// <summary>
	/// Classe (statica) per fare il dump di un DataSet/DataTable/DataRow
	/// </summary>
	public class DiagnosticHelper
	{
		[Conditional("DEBUG")]
		private static void DataSetDump(DataRow dr, DataColumn dc, DataRowVersion vr)
		{
			if (dr.HasVersion(vr))
			{
				if (dr.IsNull(dc, vr))
					Debug.WriteLine(vr.ToString() + " value = <NULL>");
				else
					Debug.WriteLine(vr.ToString() + " value = " + dr[dc, vr].ToString());
			}
		}

		[Conditional("DEBUG")]
		public static void DataSetDump(string msg, DataRow dr)
		{
			if (msg != null)
				Debug.WriteLine(msg);
			Debug.WriteLine("RowState " + dr.RowState.ToString());
			Debug.Indent();
					
			foreach (DataColumn dc in dr.Table.Columns)
			{
				Debug.WriteLine("Colonna " + dc.ColumnName);
				Debug.Indent();

				DataSetDump(dr, dc, DataRowVersion.Current);
				DataSetDump(dr, dc, DataRowVersion.Original);
				DataSetDump(dr, dc, DataRowVersion.Proposed);
				DataSetDump(dr, dc, DataRowVersion.Default);

				Debug.Unindent();
			}

			if (dr.HasErrors)
			{
				Debug.WriteLine("Errore nella riga");
				Debug.Indent();

				if (dr.RowError != null)
					Debug.WriteLine("RowError = "  + dr.RowError);

				DataColumn [] dcerr = dr.GetColumnsInError();
				foreach (DataColumn dce in dcerr)
					Debug.WriteLine(dce.ColumnName + " " + dr.GetColumnError(dce));

				Debug.Unindent();
			}
			Debug.Unindent();
		}

		[Conditional("DEBUG")]
		public static void DataSetDump(string msg, DataTable dt)
		{
			if (msg != null)
				Debug.WriteLine(msg);
			Debug.WriteLine("DataTable " + dt.TableName);
			Debug.Indent();

			foreach (DataRow dr in dt.Rows)
				DataSetDump(null, dr);

			Debug.Unindent();
		}


		[Conditional("DEBUG")]
		public static void DataSetDump(string msg, DataSet ds)
		{
			if (msg != null)
				Debug.WriteLine(msg);

			Debug.WriteLine("DataSetDump " + ds.DataSetName);
			Debug.Indent();

			foreach (DataTable dt in ds.Tables)
				DataSetDump(null, dt);

			Debug.Unindent();
		}
	}

	public class UtilityEnvironment
	{
		public static string CommonAppDir
		{
			get 
			{ 
				string p = Application.CommonAppDataPath;
				return Path.GetDirectoryName(p);  // ritorna la dir. padre
			}
		}
	}


	public class DbTime
	{
		/// <summary>
		/// Ritorna la data del db. In caso di errore la data di questo PC
		/// </summary>
		/// <param name="dbTime"></param>
		/// <returns></returns>
		public static DateTime GetDbSystemDate()
		{
			DateTime ret;
			GetDbSystemDate(out ret);
			return ret;
		}

		static bool FirstTime = true;
		static TimeSpan dbpc;

		public static bool GetDbSystemDate(out DateTime dbTime)
		{
			if (FirstTime == false)
			{
				dbTime = DateTime.Now + dbpc;
				return true;
			}
			else
			{
				dbTime = DateTime.Now; // OK sono in GetDbSystemDate
				try
				{
					CVAdminWSLogin.BLLogin ws = new CVAdminWSLogin.BLLogin();
					frmLogin.AddLoginInfo(ws);

					// chiamo il Web Service e aspetto il risultato.
					// ShowDialog ritorna se il risultato e' stato ricevuto o su cancel 
					// dell'amministratore
					IAsyncResult asr = ws.BeginGetDBSystemDateTime(null, null);
					frmAsyncWait w = new frmAsyncWait(asr);
					w.ShowDialog();
					if (w.Cancelled)
						return false;

					// il Web Service ha risposto... prendo il risultato
					dbTime = ws.EndGetDBSystemDateTime(asr);

					dbpc = dbTime - DateTime.Now;
					FirstTime = false;
					return true;
				}
				catch (SoapException ex)
				{
					Trace.WriteLine("SoapException");
					Trace.Indent();
					Trace.WriteLine(ex.Message);
					Trace.WriteLine(ex.StackTrace);
					Trace.Unindent();

					dbpc = dbTime - DateTime.Now;
					FirstTime = true;

					MessageBox.Show(ex.Message, "Errore");
					return false;
				}
				catch (Exception ex)
				{
					Trace.WriteLine("Errore di comunicazione o eccezione dal server");
					Trace.Indent();
					Trace.WriteLine(ex.Message);
					Trace.WriteLine(ex.StackTrace);
					Trace.Unindent();

					dbpc = dbTime - DateTime.Now;
					FirstTime = true;

					MessageBox.Show("Comunicazione con il server impossibile", "Errore");
					return false;
				}
			}
		}
	}


	/// <summary>
	/// Classe per fare tracing dell'applicativo.
	/// Il nome _ della classe e` terribile ma serve per scrivere meno.
	/// Esempio d'uso: Trace.WriteLineIf(_.Error, "Tragedia in corso");
	/// Lo switch "General" comanda nel file di configurazione il livello
	/// di tracing.
	/// </summary>
	public class _
	{
		public static TraceSwitch TrSw = new TraceSwitch("General", "CV");

		static public bool Error   { get { return TrSw.TraceError; } }
		static public bool Warning { get { return TrSw.TraceWarning; } } 
		static public bool Info    { get { return TrSw.TraceInfo; } } 
		static public bool Verbose { get { return TrSw.TraceVerbose; } }
	}


	class WebUtility
	{
		public static void DownloadFile(string remoteFileName, string localFileName)
		{
			using (WebClient webClient = new WebClient())
			{
				// webClient.BaseAddress = ConfigurationSettings.AppSettings["CVAdminWebServerURL"];
				// webClient.DownloadFile(remoteFileName, localFileName);

				webClient.DownloadFile(
					ConfigurationSettings.AppSettings["CVAdminWebServerURL"] + "/" + remoteFileName,
					localFileName);
			}
		}
	}
}
