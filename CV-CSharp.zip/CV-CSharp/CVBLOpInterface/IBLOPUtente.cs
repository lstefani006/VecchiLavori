using System;
using System.Data;

namespace CV.Op
{
	[Serializable()]
	public struct InfoUtente
	{
		/// <summary>
		/// Identificativo univoco dell'Utente
		/// </summary>
		public string	IdUtente;
		/// <summary>
		/// true se il campo IdUtente e' NULL
		/// </summary>
		public bool		IdUtenteIsNull;
		/// <summary>
		/// Nominativo dell'Utente
		/// </summary>
		public string	Nominativo;
		/// <summary>
		/// true se il campo Nominativo e' NULL
		/// </summary>
		public bool		NominativoIsNull;
		/// <summary>
		/// Codice Fiscale dell'Utente
		/// </summary>
		public string	CodiceFiscale;
		/// <summary>
		/// true se il campo Codice Fiscale e' NULL
		/// </summary>
		public bool		CodiceFiscaleIsNull;
		/// <summary>
		/// Numero di telefono dell'Utente
		/// </summary>
		public string	NumTelefono;
		/// <summary>
		/// true se il campo NumTelefono e' NULL
		/// </summary>
		public bool		NumTelefonoIsNull;
		/// <summary>
		/// FAX dell'utente
		/// </summary>
		public string	Fax;
		/// <summary>
		/// true se il campo FAX e' NULL
		/// </summary>
		public bool		FaxIsNull;
		/// <summary>
		/// Indirizzo di E-mail dell'Utente
		/// </summary>
		public string	Email;
		/// <summary>
		/// true se il campo EMail e' NULL
		/// </summary>
		public bool		EmailIsNull;
		/// <summary>
		/// Tipo di Utente
		/// </summary>
		public string	TipoUtente;
		/// <summary>
		/// true se il campo TipoUtente e' NULL
		/// </summary>
		public bool		TipoUtenteIsNull;
		/// <summary>
		/// Stato dell'Utente
		/// </summary>
		public string	StatoUtente;
		/// <summary>
		/// true se il campo StatoUtente e' NULL
		/// </summary>
		public bool		StatoUtenteIsNull;
		/// <summary>
		/// Distinguished Name dell'Utente
		/// </summary>
		public string	DN;
		/// <summary>
		/// true se il campo DN e' NULL
		/// </summary>
		public bool		DNIsNull;
	}
	/// <summary>
	/// Summary description for IBLOPUtente.
	/// </summary>
	public interface IBLOPUtente
	{
		bool		IsPINValid(string pin);
		InfoUtente	GetIdUtente(string CommonName);
		bool		Registra(string IdRagioneSociale, ref InfoUtente infoU);
		string      GetIdRicRegSoc(string CodiceConto);

	}	
}
