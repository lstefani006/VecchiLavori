using System;

namespace CV.Op
{
	/// <summary>
	/// Summary description for Interface ITransazione.
	/// </summary>
	public interface IBLOPTransazione
	{
		void SetStato(string IdTransazione, string Stato);
		string GetStato(string IdTransazione);
	}
}
