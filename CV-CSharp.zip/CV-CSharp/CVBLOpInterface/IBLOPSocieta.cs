using System;
using System.Data;

namespace CV.Op
{
	[Serializable()]
	public struct BankAccount
	{
		public decimal	Importo;
		public bool		ImportoIsNull;
		public decimal	PrezzoConvUtenteMw;
		public bool		PrezzoConvUtenteMwIsNull;
		public Int64	QuantitaMax;
		public bool		QuantitaMaxIsNull;
		public Int64	QuantitaImpegnata;
		public bool		QuantitaImpegnataIsNull;
		public Int64	QuantitaDisponibile;
		public bool		QuantitaDisponibileIsNull;
	}

	[Serializable()]
	public struct InfoSocieta
	{
		public string	IdSocieta;
		public bool		IdSocietaIsNull;
		public string	RagioneSociale;
		public bool		RagioneSocialeIsNull;
		public string	Indirizzo;
		public bool		IndirizzoIsNull;
		public string	Citta;
		public bool		CittaIsNull;
		public string	CAP;
		public bool		CAPIsNull;
		public string	Nazione;
		public bool		NazioneIsNull;
		public string	CodiceFiscale;
		public bool		CodiceFiscaleIsNull;
		public string	PartitaIVA;
		public bool		PartitaIVAIsNull;
		public string	ABI;
		public bool		ABIIsNull;
		public string	CAB;
		public bool		CABIsNull;
		public string	CC;
		public bool		CCIsNull;
		public decimal	ConsensoTrattamentoDati;
		public bool		ConsensoTrattamentoDatiIsNull;
		public string	Telefono;
		public bool		TelefonoIsNull;
		public string	FAX;
		public bool		FAXIsNull;
		public string	Email;
		public bool		EmailIsNull;
		public string	CodiceConto;
		public bool		CodiceContoIsNull;
		public string	ReferenteAmministr;
		public bool		ReferenteAmministrIsNull;
		public string	SedeAmministrativa;
		public bool		SedeAmministrativaIsNull;
	}

	/// <summary>
	/// Summary description for IBLOPSocieta.
	/// </summary>
	public interface IBLOPSocieta
	{
		BankAccount GetBankAccount(string CommonName, string IdSessione);
		DataSet		GetCertificates(string CommonName, string IdSessione);
		string		GetRagioneSociale(string IdUtente);
		decimal		GetDisponibilitaAcquisto(string IdSessione, string IdUtente);
		decimal		GetDisponibilitaVendita(string IdSessione, string IdUtente, string AnnoRiferimento);
		bool		Registra(ref InfoSocieta infoS, InfoUtente infoU);
		bool		Registra(ref InfoSocieta infoS);

		DataSet		GetListaByIdSocieta(string IdSocieta);
		
		DataSet     GetSocietaPerRegistrazioneUtente();
		DataSet     GetSocietaByIdUtente(string IdUtente);
		DataSet		GetReportCV(string IdSessione, string IdSocieta);
		void		MarcaDownload(string IdReport);
		byte[]		GetDoc(string IdReport);
		bool		VerificaPINSoc(string IdRicRegSoc, string PINSoc);
		bool		VerificaPINSoc2(string CodiceConto, string PINSoc);
	}
}
