using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for IBLOPMercato.
	/// </summary>
	public interface IBLOPMercato
	{
		DataSet GetBookAcquisto(string IdSessione, string AnnoRiferimento);
		DataSet GetBookVendita(string IdSessione, string AnnoRiferimento);
		int		AddAcquisto(InfoOffertaAcquisto OfferteAcquisto, string Firma, out string IdOfferta);
		int		AddVendita(InfoOffertaVendita OfferteVendita, string Firma, out string IdOfferta);
		DataSet	GetMwCertificateList();
	}
}
