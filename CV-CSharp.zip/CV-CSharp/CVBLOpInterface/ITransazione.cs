using System;

namespace CV.Op
{
	/// <summary>
	/// Summary description for Interface ITransazione.
	/// </summary>
	public interface ITransazione
	{
		void SetStato(string IdTransazione, string Stato);
		string GetStato(string IdTransazione);
	}
}
