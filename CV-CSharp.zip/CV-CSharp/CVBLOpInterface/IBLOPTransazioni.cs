using System;
using System.Data;

namespace CV.Op
{
	[Serializable()]
	public struct BookData
	{
		/// <summary>
		/// Prezzo unitario minimo relativo ad una determinata sessione ed anno di riferimento
		/// </summary>
		public decimal	PrezzoMin;
		/// <summary>
		/// true se il campo PrezzoMin e' NULL
		/// </summary>
		public bool		PrezzoMinIsNull;
		/// <summary>
		/// Prezzo unitario MASSIMO relativo ad una determinata sessione ed anno di riferimento
		/// </summary>
		public decimal	PrezzoMAX;
		/// <summary>
		/// true se il campo PrezzoMAX e' NULL
		/// </summary>
		public bool		PrezzoMAXIsNull;
		/// <summary>
		/// QUantita' di certificati verdi scambiati nella sessione per un determinato anno di riferimento
		/// </summary>
		public decimal	VolumeScambi;
		/// <summary>
		/// true se il campo VolumeScambi e' NULL
		/// </summary>
		public bool		VolumeScambiIsNull;
		/// <summary>
		/// Prezzo Unitario relativo all'ultima transazione effettuata nella sessione per un determinato anno di riferimento
		/// </summary>
		public decimal	UltimoPrezzo1;
		/// <summary>
		/// true se il campo UltimoPrezzo1 e' NULL
		/// </summary>
		public bool		UltimoPrezzo1IsNull;
		/// <summary>
		/// Prezzo Unitario relativo alla penultima transazione effettuata nella sessione per un determinato anno di riferimento
		/// </summary>
		public decimal	UltimoPrezzo2;
		/// <summary>
		/// true se il campo UltimoPrezzo2 e' NULL
		/// </summary>
		public bool		UltimoPrezzo2IsNull;
		/// <summary>
		/// Prezzo Unitario relativo alla terzultima transazione effettuata nella sessione per un determinato anno di riferimento
		/// </summary>
		public decimal	UltimoPrezzo3;
		/// <summary>
		/// true se il campo UltimoPrezzo3 e' NULL
		/// </summary>
		public bool		UltimoPrezzo3IsNull;
	}

	/// <summary>
	/// Summary description for Interface ITransazione.
	/// </summary>
	public interface IBLOPTransazioni
	{
		BookData GetBookData(string IdSessione, string AnnoRiferimento);
		DataSet GetRecordByIdOffertaAcquisto(string IdOffertaAcquisto);
		DataSet GetRecordByIdOffertaVendita(string IdOffertaVendita);
		DataSet GetTransazioniAcquisto(string IdSessione, string IdUtente);
		DataSet GetTransazioniVendita(string IdSessione, string IdUtente);
	}
}
