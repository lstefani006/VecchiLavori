using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for IBLOPOfferteVendita.
	/// </summary>
	public interface IBLOPOfferteVendita
	{
		DataSet GetListaByUtente(string IdSessione, string IdUtente);
		decimal	GetCount(string IdSessione, string IdUtente, string AnnoRiferimento);
//		DataSet GetListaNonEseguite(string IdSessione, string IdUtente, string AnnoRiferimento);
	}
}
