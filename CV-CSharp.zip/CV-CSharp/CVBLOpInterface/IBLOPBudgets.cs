using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for IBLOPBudgets.
	/// </summary>
	public interface IBLOPBudgets
	{
		DataSet Get(string IdSocieta, string IdSessione);
		DataSet Update(DataSet ds);
	}
}
