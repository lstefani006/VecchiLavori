using System;
using System.Data;
using System.Collections;

namespace CV.Op
{

	[Serializable()] 
	public class DatiSessione 
	{
		private string strNomeSessione;

		public string NomeSessione
		{
			get
			{
				return (strNomeSessione);
			}
			set
			{
				strNomeSessione = value;
			}
		}
	}

	/// <summary>
	/// Summary description for Interface ISessioni.
	/// </summary>
	public interface IBLOPSessioni
	{
		DatiSessione GetInfoSessione(string  IdSessione);
		ArrayList GetInfoSessioni();
	}
}
