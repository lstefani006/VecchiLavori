using System;
using System.Data;

namespace CV.Op
{
	[Serializable()]
	public struct InfoOffertaAcquisto
	{
		/// <summary>
		/// Identificativo dell'Utente che effettua l'Acquisto
		/// </summary>
		public string	IdUtente;
		/// <summary>
		/// true se il campo IdUtente e' NULL
		/// </summary>
		public bool		IdUtenteIsNull;
		/// <summary>
		/// Quantita' di certficati verdi richiesta
		/// </summary>
		public decimal	QtyRichiesta;
		/// <summary>
		/// true se il campo QtyRichiesta e' NULL
		/// </summary>
		public bool		QtyRichiestaIsNull;
		/// <summary>
		/// Quantita' di certficati verdi ancora da acquistare
		/// </summary>
		public decimal	QtyResidua;
		/// <summary>
		/// true se il campo QtyResidua e' NULL
		/// </summary>
		public bool		QtyResiduaIsNull;
		/// <summary>
		/// Quantita' di certficati verdi effettivamente acquistata
		/// </summary>
		public decimal	QtyEseguita;
		/// <summary>
		/// true se il campo QtyEseguita e' NULL
		/// </summary>
		public bool		QtyEseguitaIsNull;
		/// <summary>
		/// Prezzo unitario del singolo certificato verde
		/// </summary>
		public decimal	PrezzoUnitario;
		/// <summary>
		/// true se il campo PrezzoUnitario e' NULL
		/// </summary>
		public bool		PrezzoUnitarioIsNull;
		/// <summary>
		/// Anno di riferimento per il quale e' stato effettuato l'Acquisto
		/// </summary>
		public string	AnnoRiferimento;
		/// <summary>
		/// true se il campo AnnoRiferimento e' NULL
		/// </summary>
		public bool		AnnoRiferimentoIsNull;
		/// <summary>
		/// Identificativo della sessione corrente 
		/// </summary>
		public string	IdSessione;
		/// <summary>
		/// true se il campo IdSessione e' NULL
		/// </summary>
		public bool		IdsessioneIsNull;
		public decimal	Compatibile;
		public bool		CompatibileIsNull;
	}

	/// <summary>
	/// Summary description for IBLOPOffertaAcquisto.
	/// </summary>
	public interface IBLOPOffertaAcquisto
	{
		void Delete(string IdOffertaAcquisto, string Firma);
		void DeleteIncompatible(string IdOffertaAcquisto, string Firma);
		InfoOffertaAcquisto Get(string IdOffertaAcquisto);
		int Modifica(string IdOffertaAcquisto, decimal NuovoPrezzo, decimal NuovaQtyResidua, decimal OldQtyResidual, string Firma);
	}
}
