using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for IBLOPOfferte.
	/// </summary>
	public interface IBLOPOfferte
	{
		void Abbinamento(string TipoOfferta, string IdOfferta, string IdUtente);
	}
}
