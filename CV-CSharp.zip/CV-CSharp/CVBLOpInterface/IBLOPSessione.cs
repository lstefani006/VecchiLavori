using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for IBLOPSessione.
	/// </summary>
	public interface IBLOPSessione
	{
		DataSet GetCurrentWebSession();

		DataSet GetCurrentWebSession2();

		/// <summary>
		/// 
		/// </summary>
		/// <param name="IdSessione"></param>
		/// <returns></returns>
		bool IsEnabled(string IdSessione);

		/// <summary>
		/// Ritorna tutte le prossime sessioni In Attesa (DataOraInizio > Tnow).
		/// La prima sessione ritornata e' la piu' prossima
		/// </summary>
		DataSet	GetProssimaSessioneInAttesa();

		/// <summary>
		/// Ritorna tutte le prossime sessioni Predisposte (DataOraInizio > Tnow).
		/// La prima sessione ritornata e' la piu' prossima
		/// </summary>
		DataSet	GetProssimaSessionePredisposta();

		/// <summary>
		/// Ritorna la sessione in stato Aperta e con Tnow compresi tra l'inizio e la fine sessione
		/// </summary>
		DataSet GetSessioneAperta();

		/// <summary>
		/// Ritorna i dati della sessione indicata dall'IdSessione passato
		/// </summary>
		DataSet GetDatiSession(string IdSessione);

		DataSet GetLst();

		/// <summary>
		/// Ritorna il numero di MWh per certificato verde.
		/// Attualmente` e` 50. Configurabile nell'app.config dei server della BL.
		/// </summary>
		decimal MWhPerCV
		{
			get;
		}

	}
}
