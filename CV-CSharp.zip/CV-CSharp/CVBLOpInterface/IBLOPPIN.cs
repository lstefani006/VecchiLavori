using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for IBLOPPin.
	/// </summary>
	public interface IBLOPPin
	{
		string NewPin();
		bool Verify(string strPIN);
		string CausaleVersamento(string CodiceConto, DateTime DataSessione);
	}
}
