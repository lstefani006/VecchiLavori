using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for IBLOPOfferteAcquisto.
	/// </summary>
	public interface IBLOPOfferteAcquisto
	{
		DataSet GetListaByUtente(string IdSessione, string IdUtente);
		decimal	GetCount(string IdSessione, string IdUtente, string AnnoRiferimento);
//		DataSet GetListaNonEseguite(string IdSessione, string IdUtente, string AnnoRiferimento);
	}
}
