using System;
using System.Data;

namespace CV.Op
{
	[Serializable()]
	public struct InfoOffertaVendita
	{
		/// <summary>
		/// Identificativo dell'Utente che effettua l'Acquisto
		/// </summary>
		public string	IdUtente;
		/// <summary>
		/// true se il campo IdUtente e' NULL
		/// </summary>
		public bool		IdUtenteIsNull;
		/// <summary>
		/// Quantita' di certficati verdi offerta
		/// </summary>
		public decimal	QtyOfferta;
		/// <summary>
		/// true se il campo QtyOfferta e' NULL
		/// </summary>
		public bool		QtyOffertaIsNull;
		/// <summary>
		/// Quantita' di certficati verdi ancora da vendere
		/// </summary>
		public decimal	QtyResidua;
		/// <summary>
		/// true se il campo QtyResidua e' NULL
		/// </summary>
		public bool		QtyResiduaIsNull;
		/// <summary>
		/// Quantita' di certficati verdi effettivamente venduta
		/// </summary>
		public decimal	QtyEseguita;
		/// <summary>
		/// true se il campo QtyEseguita e' NULL
		/// </summary>
		public bool		QtyEseguitaIsNull;
		/// <summary>
		/// Prezzo unitario del singolo certificato verde
		/// </summary>
		public decimal	PrezzoUnitario;
		/// <summary>
		/// true se il campo PrezzoUnitario e' NULL
		/// </summary>
		public bool		PrezzoUnitarioIsNull;
		/// <summary>
		/// Anno di riferimento per il quale e' stato effettuato la vendita
		/// </summary>
		public string	AnnoRiferimento;
		/// <summary>
		/// true se il campo AnnoRiferimento e' NULL
		/// </summary>
		public bool		AnnoRiferimentoIsNull;
		/// <summary>
		/// Identificativo della sessione corrente 
		/// </summary>
		public string	IdSessione;
		/// <summary>
		/// true se il campo IdSessione e' NULL
		/// </summary>
		public bool		IdsessioneIsNull;
		public decimal	Compatibile;
		public bool		CompatibileIsNull;
	}

	/// <summary>
	/// Summary description for IBLOPOffertaVendita.
	/// </summary>
	public interface IBLOPOffertaVendita
	{
		void Delete(string IdOffertaVendita, string Firma);
		void DeleteIncompatible(string IdOffertaVendita, string Firma);
		InfoOffertaVendita Get(string IdOffertaVendita);
		int Modifica(string IdOffertaVendita, decimal NuovoPrezzo, decimal NuovaQtyResidua, decimal OldQtyResidual, string Firma);
	}
}
