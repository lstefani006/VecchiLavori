using System;

namespace CV.Op
{
	/// <summary>
	/// Summary description for IBLOPCommon.
	/// </summary>
	public interface IBLOPCommon
	{
		DateTime GetDBSystemDate();
		bool ContrattaCVAnnoMin(int Month, out int AnnoMin, out int AnnoMax);
	}
}
