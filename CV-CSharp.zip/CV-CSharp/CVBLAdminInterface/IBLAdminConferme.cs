using System;
using System.IO;
using System.Text;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminCommon.
	/// </summary>
	public interface IBLAdminConferme
	{
		string ConfermeVenditori(DataSet dsSessione, string IdSocieta, string RagioneSociale, string PartitaIVA);
		string ConfermeAcquisti(DataSet dsSessione, DataSet dsBudget, string IdSocieta, string RagioneSociale, string PartitaIVA);
	}
}