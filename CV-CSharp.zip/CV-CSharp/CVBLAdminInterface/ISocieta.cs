using System;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for ISocieta.
	/// </summary>
	public interface ISocieta
	{
		string GetABISocieta(string IdSocieta);
	}
}
