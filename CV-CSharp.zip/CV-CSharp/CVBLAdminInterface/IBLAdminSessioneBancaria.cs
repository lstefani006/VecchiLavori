using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminSessioneBancaria.
	/// </summary>
	public interface IBLAdminSessioneBancaria
	{
		string SessioneBancaria_CreazionePossibile(string IdSessione);
		string SessioneBancaria_ReportApertura(string IdSessione);
		string SessioneBancaria_ReportStato(string IdSessione);
		string SessioneBancaria_ReportChiusura(string IdSessione);
		bool SessioneBancaria_Esiste(string IdSessione);
		bool SessioneBancaria_Aperta(string IdSessione);
		DataSet SessioneBancaria_Crea(string IdSessione, ref DateTime TSUltimaModifica, DateTime ValutaGP, DateTime ValutaPP, out string msg);
		DataSet SessioneBancaria_Dati(string IdSessione, ref DateTime TSUltimaModifica);
		string SessioneBancaria_Cancella(string IdSessione, ref DateTime TSUltimaModifica);
		DataSet SessioneBancaria_Chiudi(string IdSessione, ref DateTime TSUltimaModifica, DateTime TSValuta, out string msg);
		bool IstruzioniDiPagamento_DaGenerare(string IdSessione);
		string IstruzioniDiPagamento_Genera(string IdSessione, ref DateTime TSUltimaModifica);
		DataSet IstruzioniDiPagamento_Pubblica(string IdSessione, ref DateTime TSUltimaModifica, out string msg);
		string IstruzioniDiPagamento_Visualizza(string IdSessione, string TipoReport);
		DataSet IstruzioniDiPagamento_CancellaUltimo(string IdSessione, ref DateTime TSUltimaModifica, out string msg);
		string  OrdinePagamentoSanPaolo_CreaNuovo(string IdSessione, ref DateTime TSUltimaModifica);
		DataSet OrdinePagamentoSanPaolo_Lista_SP_CBISP(string IdSessione);
		string  OrdinePagamentoSanPaolo_Visualizza(string IdSessione, string IdReport);
		string OrdinePagamentoSanPaolo_CBI_DaInviare(string IdSessione, out DateTime TSCreazione);
		DataSet OrdinePagamentoSanPaolo_InviaUltimo(string IdSessione, ref DateTime TSUltimaModifica, DateTime TSInvio, out string msg);
		string  OrdinePagamentoSanPaolo_CancellaUltimo(string IdSessione, ref DateTime TSUltimaModifica);
		string  OrdinePagamentoSanPaolo_VisualizzaUltimoSP(string IdSessione);
		DataSet MovPP_Perfezionato(string IdSessione, ref DateTime TSUltimaModifica, string IdMovPP, string trbanPerfezionateString, DateTime TSPerfezionato, DateTime ValutaGP2, out string msg);
		DataSet MovPP_PerfezionamentoErrato(string IdSessione, ref DateTime TSUltimaModifica, string IdMovPP, out string msg);
		DataSet Residui_Calcola(string IdSessione, ref DateTime TSUltimaModifica, DateTime valutaRestituzioneResiduo, out string msg);
	}
}
