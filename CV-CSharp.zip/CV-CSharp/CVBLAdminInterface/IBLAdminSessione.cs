using System;
using System.Data;

namespace CV.Admin
{

	[Serializable()]
	public struct PrezziRiferimento
	{
		public decimal	PrezzoRiferimentoAnnoPrec10;
		public decimal	PrezzoRiferimentoAnnoPrec09;
		public decimal	PrezzoRiferimentoAnnoPrec08;
		public decimal	PrezzoRiferimentoAnnoPrec07;
		public decimal	PrezzoRiferimentoAnnoPrec06;
		public decimal	PrezzoRiferimentoAnnoPrec05;
		public decimal	PrezzoRiferimentoAnnoPrec04;
		public decimal	PrezzoRiferimentoAnnoPrec03;
		public decimal	PrezzoRiferimentoAnnoPrec02;
		public decimal	PrezzoRiferimentoAnnoPrec;
//		public bool		PrezzoRiferimentoAnnoPrecIsNull;
		public decimal	PrezzoRiferimentoAnnoCorr;
//		public bool		PrezzoRiferimentoAnnoCorrIsNull;
		public decimal	PrezzoRiferimentoAnnoSucc;
//		public bool		PrezzoRiferimentoAnnoSuccIsNull;
		public decimal	PrezzoRiferimentoAnnoSucc02;
		public decimal	PrezzoRiferimentoAnnoSucc03;
		public decimal	PrezzoRiferimentoAnnoSucc04;
		public decimal	PrezzoRiferimentoAnnoSucc05;
		public decimal	PrezzoRiferimentoAnnoSucc06;
		public decimal	PrezzoRiferimentoAnnoSucc07;
		public decimal	PrezzoRiferimentoAnnoSucc08;
		public decimal	PrezzoRiferimentoAnnoSucc09;
		public decimal	PrezzoRiferimentoAnnoSucc10;
	}

	/*
	[Serializable()]
	public struct InfoSessione
	{
		public string	IdSessione;
		public bool		IdSessioneIsNull;
		public string	Titolo;
		public bool		TitoloIsNull;
		public DateTime	DataOraCreazione;
		public bool		DataOraCreazioneIsNull;
		public DateTime DataOraApertura;
		public bool		DataOraAperturaIsNull;
		public DateTime DataOraChiusura;
		public bool		DataOraChiusuraIsNull;
		public DateTime	DataOraModifica;
		public bool		DataOraModificaIsNull;
		public decimal	PrezzoConvenzionale;
		public bool		PrezzoConvenzionaleIsNull;
		public PrezziRiferimento InfoPrezzi;
		public string	StatoSessione;
		public bool		StatoSessioneIsNull;
	}
	*/

	/// <summary>
	/// Summary description for IBLAdminSessione.
	/// </summary>
	public interface IBLAdminSessione
	{
		DataSet	GetBookAcquisto(IDbTransaction tr, string IdSessione, string AnnoRiferimento);
		DataSet	GetBookAcquisto(                   string IdSessione, string AnnoRiferimento);

		DataSet	GetBookVendita(IDbTransaction tr, string IdSessione, string AnnoRiferimento);
		DataSet	GetBookVendita(                   string IdSessione, string AnnoRiferimento);

		DataSet GetCurrentWebSession(IDbTransaction tr);
		DataSet GetCurrentWebSession();

		bool	IsEnabled(IDbTransaction tr, string IdSessione);
		bool	IsEnabled(                   string IdSessione);

// gestiti con Update
//		void	Delete(IDbTransaction tr, string IdSessione);
//		void	Delete(                   string IdSessione);
//		DataSet_Sessioni Insert(IDbTransaction tr, DataSet_Sessioni infoS);
//		DataSet_Sessioni Insert(                   DataSet_Sessioni infoS);

		DataSet Retrieve(IDbTransaction tr, string IdSessione, string Titolo, string StatoSessione);
		DataSet Retrieve(                   string IdSessione, string Titolo, string StatoSessione);

		PrezziRiferimento RetrievePrezzoRiferimento(IDbTransaction tr, string IdSessione);
		PrezziRiferimento RetrievePrezzoRiferimento(                   string IdSessione);

		DataSet RetrieveActive(IDbTransaction tr, string IdSessione);
		DataSet RetrieveActive(                   string IdSessione);

		DataSet ClearGrid();

		string  IsPossibleToSetTo(IDbTransaction tr, string IdSessione, string StatoProposta);
		string  IsPossibleToSetTo(string IdSessione, string StatoProposta);

		void    Update(IDbTransaction tr, DataSet ds, out string messaggioErrore);
		DataSet Update(                   DataSet ds, out string messaggioErrore);

		bool ContrattaCVAnnoMin(int Month, out int AnnoMin, out int AnnoMax);

// gestiti con update
//		bool    Update(string IdSessione, string Titolo, DateTime DataOraApertura, DateTime DataOraChiusura, decimal PrezzoConvenzionale, decimal PrezzoRiferimentoAnnoPrec, decimal PrezzoRiferimentoAnnoCorr, decimal PrezzoRiferimentoAnnoSucc, string StatoSessione);
//		bool    UpdateToPredisposta(string IdSessione);
	}
}
