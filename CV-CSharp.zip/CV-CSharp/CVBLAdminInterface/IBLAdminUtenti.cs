using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminUtenti.
	/// </summary>
	public interface IBLAdminUtenti
	{
		DataSet Retrieve(string Nominativo, string CodiceFiscale);
		bool Login(string Nominativo, string Password, string DN, string TipoUtente);
		void Update(DataSet ds, string IdUtente, string nominativo);
		string Valida(string IdSocietaParent, string IdRichiestaRegUtente, string nominativo);
		DataSet GetLstStorico();
	}
}
