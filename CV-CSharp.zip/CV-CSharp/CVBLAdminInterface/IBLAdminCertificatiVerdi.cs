using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminCertificatiVerdi.
	/// </summary>
	public interface IBLAdminCertificatiVerdi
	{
		DataSet GetExportData(string IdSessione);
		string ImportData(string IdSessione, string inXmlStream);
	}
}
