using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Admin
{
	[Serializable()]
	public struct ReportSessioni
	{
		public decimal	NumAperte;
		public decimal	NumSospese;
		public decimal	NumPredisposte;
		public decimal	NumTerminate;
	}
	/// <summary>
	/// Summary description for IBLAdminSessioni.
	/// </summary>
	public interface IBLAdminSessioni
	{
		DataSet GetLst();
		DataSet	GetListaFiltrata();
		ReportSessioni VerifyStatus();
		DataSet CalcolaCorrispettivi(string[] IdSessioni);
	}
}
