using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminTransazione.
	/// </summary>
	public interface IBLAdminTransazione
	{
		DataSet TransazioniValide(string IdSessione);
		int     NumeroTransazioniValide(string IdSessione);
		DataSet ContiDaSbloccare(string IdSessione);
		void    Insert_DataExportXML(string IdSessione, DataSet ds, DateTime DataOraExportXML);
		}
}
