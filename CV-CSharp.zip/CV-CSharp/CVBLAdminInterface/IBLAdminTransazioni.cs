using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminTransazioni.
	/// </summary>
	public interface IBLAdminTransazioni
	{
		//DataSet Ricerca(string RagioneSociale, string IdSessione, string TipoRicerca);
		string GeneraFileXmlPerPagamenti(string IdSessione, string NomeFileXml, string IdFileXml);
		DataSet Ricerca(string RagioneSociale, string IdSessione, string TipoRicerca);

		DataSet ListaOperazioniAcquistoPerVenditore (string IdSessione, string IdSocietaAcquirente);
		DataSet ListaOperazioniAcquistoPerAnno      (string IdSessione, string IdSocietaAcquirente);
		DataSet ListaOperazioniVenditaPerAcquirente (string IdSessione, string IdSocietaVenditore);
		DataSet ListaOperazioniVenditaPerAnno       (string IdSessione, string IdSocietaVenditore);

		DataSet DettagliAcquisti(string IdSessione, string IdSocietaAcquirente);
		DataSet DettagliVendite(string IdSessione, string IdSocietaVenditore);

		void UpdateStatoTransazione(DataSet ds);

		DataSet RetreivePagamenti(string IdSessione);
	}
}
