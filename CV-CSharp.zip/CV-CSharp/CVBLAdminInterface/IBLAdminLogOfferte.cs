using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminLogOfferte.
	/// </summary>
	public interface IBLAdminLogOfferte
	{
		DataSet RetrieveAcquisto(string IdSessione, string RagioneSociale, string Anno, string CodiceConto);
		DataSet RetrieveVendita (string IdSessione, string RagioneSociale, string Anno, string CodiceConto);
	}
}
