using System;
using System.Data;

namespace CV.Admin
{

	[Serializable()]
	public struct InfoBudget
	{
		public string	IdSessione;
		public bool		IdSessioneIsNull;	 
		public string	IdSocieta;
		public bool		IdSocietaIsNull;
		public decimal	Importo;
		public bool		ImportoIsNull;
		public decimal	PrezzoConvenzionaleUtente;
		public bool		PrezzoConvenzionaleUtenteIsNull;
		public decimal	PrezzoConvenzionaleUtenteMw;
		public bool		PrezzoConvenzionaleUtenteMwIsNull;
		public decimal	QuantitaMAX;
		public bool		QuantitaMAXIsNull;
		public decimal	QuantitaImpegnata;
		public bool		QuantitaImpegnataIsNull;
		public DateTime	DataOraCreazione;
		public bool		DataOraCreazioneIsNull;
	}

	/// <summary>
	/// Summary description for IBLAdminBudget.
	/// </summary>
	public interface IBLAdminBudget
	{
		void Delete(string IdSocieta, string IdSessione);
		void DeleteSessione(string IdSessione);
		void Insert(DataSet ds);
		void Update(DataSet ds);
		DataSet Retrieve(string IdSocieta, string IdSessione);
		DataSet GetBudgetSessionePrecedente(string IdSessione);

		/// <summary>
		/// Ritorna un DataSet che contiene: IdSessione, StatoSessione, DataOraApertura delle sessioni
		/// precedenti alla sessione <code>IdSessione</code>
		/// </summary>
		/// <param name="IdSessione">sessione</param>
		/// <returns>un data set delle sessioni precedenti</returns>
		DataSet GetStatoSessioneSessionePrecedenti(string IdSessione);

		decimal MWhPerCV
		{
			get;
		}
	}
}
