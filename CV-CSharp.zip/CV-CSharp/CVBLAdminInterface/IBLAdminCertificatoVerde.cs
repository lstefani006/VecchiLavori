using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminCertificatoVerde.
	/// </summary>
	public interface IBLAdminCertificatoVerde
	{
		void Update(DataSet ds);

#if VECCHIO_MWCERTIFICATO //Stefano

		DataSet RetrieveMwCertificato();
		void UpdateMwCertificato(DataSet ds);
#endif
	}
}
