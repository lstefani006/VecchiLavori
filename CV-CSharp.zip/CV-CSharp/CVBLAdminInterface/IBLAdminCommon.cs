using System;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for IBLAdminCommon.
	/// </summary>
	public interface IBLAdminCommon
	{
		DateTime GetDBSystemDate();

		string NewId();
		bool ContrattaCVAnnoPrecedente(int Month);
	}
}
