using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Admin
{
	/// <summary>
	/// 
	/// </summary>
	public interface IBLAdminRichiesta
	{
//		DataSet Retrieve(IDbTransaction tr, string IdRichiestaRegSoc);
//		DataSet Retrieve(                   string IdRichiestaRegSoc);
//
//		void Update(IDbTransaction tr, DataSet ds);
//		void Update(                   DataSet ds);

		void UpdateNota(string IdRichiestaRegSoc, string Nota);
		string IsReqSocietaValidated(string IdRichiestaRegSoc);
	}
}
