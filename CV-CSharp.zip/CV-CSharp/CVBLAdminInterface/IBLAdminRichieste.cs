using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Admin
{
	
	[Serializable()]
	public struct FiltroRichieste
	{
		public string	RagioneSociale;
		public string	CodiceFiscale;
		public string	PartitaIVA;
		public string	ABI;
		public string	CAB;
		public string	CC;
		public string	StatoRichiesta;
	}

	/// <summary>
	/// 
	/// </summary>
	public interface IBLAdminRichieste
	{
		DataSet Search();
		void Update(DataSet ds);
	}
}
