using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for ISocieta.
	/// </summary>
	public interface IBLAdminSocieta
	{
		DataSet GetLista(string RagioneSociale);
		DataSet GetTotaleAcquisti(string IdSessione);
		DataSet RetrieveByCodiceConto(string CodiceConto);
		DataSet Retrieve_Parameters(string TipoParametro);
		DataSet Retrieve_SocietaUtenti();
		DataSet GetBankAccount(string IdSessione);
		DataSet GetCertificates(string IdSessione);
		void	Update(DataSet ds, string IdSocieta, string nominativo);
		string  Valida(string IdRichiestaRegSoc, string nominativo);
		void    InizializzaStorico();
		DataSet GetLstStorico();
	}
}