Public Class CheckCRL

    Public Function VerifyCert(ByVal SerialNumber As String, ByVal CRLUrl As String) As String
        Dim ClasseJS As New ComBridgeJavaServices.JavaServicesClass()
        Dim ClasseJ As Object
        Dim ris As String

        Try
            ' Assicurarsi che la CLASSPATH faccia riferimento alla directory
            ' in cui e' contenuto il file CheckCRL.class
            ClasseJ = ClasseJS.JavaNew("CheckCRL")
            ris = ClasseJ.VerifyCert(SerialNumber, CRLUrl)
        Catch Ex As Exception
            Return Ex.Message
        End Try

    End Function

End Class
