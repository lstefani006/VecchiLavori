import java.io.*;
import sun.misc.*;
import java.lang.*;
import java.net.*;
import java.util.*;
import java.math.BigInteger;
import javax.naming.*;
import javax.naming.directory.*;
import java.security.*;
import java.security.cert.*;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.sql.*;

public class CheckCRL
{   	  

  public CheckCRL()
  {
  	
  }
  
  
  // Torna la stringa vuota se il Ceritficato e' valido
  // altrimenti il relativo messaggio di errore
  public String VerifyCert(String SerialNumber, String CrlUrl)
  {
  			//Path e nome del file di configurazione
    		String fileconfig = "c:/CheckCRL.ini" ;
    		// Caricamento dei dati di configurazione
    		String proxy = "" ;
    		String porta = "" ;
    		String user = "" ;
    		String pwd = "" ;
    		try
    		{      
      			Properties prop = new Properties();
      			FileInputStream fis = new FileInputStream(fileconfig);
      			prop.load(fis);

      			proxy = new String(prop.getProperty("proxy"));
      			porta = new String(prop.getProperty("porta"));
      			user = new String(prop.getProperty("user"));
      			pwd = new String(prop.getProperty("password"));      
    		} 
    		catch(Throwable ex)
    		{ 
        		return ex.getMessage() ;
    		}
  			// Fine caricamento dati di configurazione
  			
  			
  			X509CRL crl = null ;
    		Connection conn = null;      
    
    		CertificateFactory cf ;
    		X509CRLEntry x509crlentry ;
    		URL url1 ;
    		URLConnection urlc ;
    		
    		String SerialNum = "" ;
    
    		if (CrlUrl.substring(0,4).equals("ldap"))
            {
            
              try
              {
               Hashtable env = new Hashtable();
           
               env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
               env.put(Context.PROVIDER_URL, CrlUrl);
	           env.put(Context.REFERRAL, "follow");
               env.put(Context.SECURITY_AUTHENTICATION, "simple");
    
               //String user = "" ;
               //String passwd = "" ;
               //env.put(Context.SECURITY_PRINCIPAL, user);
               //env.put(Context.SECURITY_CREDENTIALS, passwd);
               DirContext ctx = new InitialDirContext(env);
               Attributes avals = ctx.getAttributes("");
               Attribute aval = avals.get("certificateRevocationList;binary");
               byte[] val = (byte[])aval.get();
               InputStream inStream = new ByteArrayInputStream(val);              

               cf = CertificateFactory.getInstance("X.509");
               crl = (X509CRL)cf.generateCRL(inStream);       
     
               //System.out.println("---CRL---");
               //System.out.println("type = " + crl.getType());
               //System.out.println("version = " + crl.getVersion());
               //System.out.println("issuer = " + crl.getIssuerDN().getName());
               //System.out.println("signing algorithm = " + crl.getSigAlgName());
               //System.out.println("signing OID = " + crl.getSigAlgOID());
               //System.out.println("this update = " + crl.getThisUpdate());
               //System.out.println("next update = " + crl.getNextUpdate());
               //System.out.println();
               //Next, let's print out information about the entries.
               //System.out.println("---Entries---");
               Set setEntries = crl.getRevokedCertificates();
               if (setEntries != null && setEntries.isEmpty() == false)
               {
                  for (Iterator iterator = setEntries.iterator(); iterator.hasNext(); )
                  {
                    x509crlentry = (X509CRLEntry)iterator.next();
                    //System.out.println("serial number = " + x509crlentry.getSerialNumber());
                    //System.out.println("revocation date = " + x509crlentry.getRevocationDate());
                    //System.out.println("extensions = " + x509crlentry.hasExtensions());
                    //System.out.println();
                    SerialNum = x509crlentry.getSerialNumber().toString(16);
     
                    if (SerialNumber.toUpperCase().equals(SerialNum.toUpperCase()))
                    {
                    	return "Certificato Revocato in data: " + x509crlentry.getRevocationDate().toString() ;
                    }
                  }
               }
               // We're done.
               //System.out.println("---");  	

               inStream.close();
             
              }
              catch(IOException ex1)      
              { 
                 return ex1.getMessage() ;
              }
              catch(CertificateException ex2)
              { 
                 return ex2.getMessage() ;
              }
              catch(CRLException ex3)
              { 
                 return ex3.getMessage() ;
              }
              catch(NamingException ex4)
              { 
                 return ex4.getMessage() ;
              }                           
  
            }
            else
            {      
 
              try
              {          
           
               url1 = new URL(CrlUrl);
               
               //Settaggi per passare per il proxy
               Properties systemProperties = System.getProperties();
               systemProperties.put("proxySet","true");
               systemProperties.put("proxyHost",proxy);
               systemProperties.put("proxyPort",porta);
               System.setProperties(systemProperties);
	
               String password = user + ":" + pwd ;
               //INSTATUATE THE BASE64Encoder
               BASE64Encoder B64Encoder = new BASE64Encoder ();
               //PLACE THE PASSWORD INTO A BYTE STREAM, THE ENCODE
               String encodedPassword = B64Encoder.encode (password.getBytes());
	
               urlc = url1.openConnection();
               urlc.setRequestProperty("Proxy-Authorization", "basic " + encodedPassword );
               //Fine settaggi per il proxy


			   // Scommentare questa riga una volta tolti i settaggi per
			   // passare il proxy
               // urlc = url1.openConnection();
 
 
               //LETTURA DELLA CRL     
               cf = CertificateFactory.getInstance("X.509");
               crl = (X509CRL)cf.generateCRL(urlc.getInputStream());
    
               //System.out.println("---CRL---");
               //System.out.println("type = " + crl.getType());
               //System.out.println("version = " + crl.getVersion());
               //System.out.println("issuer = " + crl.getIssuerDN().getName());
               //System.out.println("signing algorithm = " + crl.getSigAlgName());
               //System.out.println("signing OID = " + crl.getSigAlgOID());
               //System.out.println("this update = " + crl.getThisUpdate());
               //System.out.println("next update = " + crl.getNextUpdate());
               //System.out.println();
               // Next, let's print out information about the entries.
               //System.out.println("---Entries---");
        
               Set setEntries = crl.getRevokedCertificates();
               if (setEntries != null && setEntries.isEmpty() == false)
               {
                  for (Iterator iterator = setEntries.iterator(); iterator.hasNext(); )
                  {
                    x509crlentry = (X509CRLEntry)iterator.next();
                    //System.out.println("serial number = " + x509crlentry.getSerialNumber());
                    //System.out.println("revocation date = " + x509crlentry.getRevocationDate());
                    //System.out.println("extensions = " + x509crlentry.hasExtensions());
                    //System.out.println();
                    SerialNum = x509crlentry.getSerialNumber().toString(16);
                    
                    if (SerialNumber.toUpperCase().equals(SerialNum.toUpperCase()))
                    {
                    	return "Certificato Revocato in data: " + x509crlentry.getRevocationDate().toString() ;
                    }           
                  }
               }
               // We're done.
               //System.out.println("---");       
             
              }
              catch(IOException ex1)      
              { 
                 return ex1.getMessage() ;
              }
              catch(CertificateException ex2)
              { 
                 return ex2.getMessage() ;
              }
              catch(CRLException ex3)
              { 
                 return ex3.getMessage() ;
              }                           
            
            }        
            
            return "" ;
  }
  
  //public static void main(String args[]) {

  //	System.out.println("Starting Test...");
				
  //	CheckCRL lib = new CheckCRL();
  //	String ris = lib.VerifyCert("67BBDCD0CF025F23DC62A90D44A9FA25" , "http://onsitecrl.trustitalia.it/TrustItaliaSpATrustItaliaFD/LatestCRL.crl");
		
  //	if (ris.equals(""))
  //	{
  //		System.out.println("Certificato Valido!");	
  //	}
  //	else
  //	{
  //		System.out.println("ris = " + ris);
  // 	}
  // 	    
  //	System.out.println("End Test...");
  //}
   
}