using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace CVCrypt
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class DoWork
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			if (args.Length == 0)
			{
				Console.WriteLine("CVCrypt: programma per gestire la sicurezza del MCV");
				Console.WriteLine("Opzioni:");
				Console.WriteLine("	-e <testo da criptare>");
				Console.WriteLine("		Cripta il testo passato come paramentro");
				Console.WriteLine("	-d <testo da decriptare>");
				Console.WriteLine("		Decritta il testo passato come paramentro");
				Console.WriteLine("	-edb");
				Console.WriteLine("		Cripta le password degli utenti del MCV nel db");
				Console.WriteLine("	-ddb");
				Console.WriteLine("		Decripta le password degli utenti del MCV nel db");
				Console.WriteLine("	-l");
				Console.WriteLine("		Lista degli utenti/password degli utenti del MVC presenti nel DB");
				Console.WriteLine("	-ld");
				Console.WriteLine("		Lista degli utenti/password decrittate degli utenti del MVC presenti nel DB");
				Console.WriteLine("	-cp <idutente> <nuova password>");
				Console.WriteLine("		Cambia la password di accesso all'utente identificato con <idutente>");
				Console.WriteLine("	-cpd <idutente> <nuova password>");
				Console.WriteLine("		Cambia la password di accesso all'utente identificato con <idutente> entro un DB criptato");
				Console.WriteLine("	-initdb <login> <password>");
				Console.WriteLine("		Inserisce l'utente per il back office");
				Console.WriteLine("	-removedb");
				Console.WriteLine("		Rimuove l'utente per il back office");
				return;
			}

			try
			{

				CVCommon.SimmetricEncryptDecrypt sa = new CVCommon.SimmetricEncryptDecrypt(new System.Security.Cryptography.RijndaelManaged(), 256, "apotoliga");

				switch (args[0].ToLower())
				{
				case "-e":
					if (args.Length != 2)
					{
						Console.WriteLine("Parametro mancante");
						Console.WriteLine("Uso: CVSecurity -e <testo>");
						return;
					}
					Console.WriteLine(sa.Encrypt(args[1]));
					break;

				case "-d":
					if (args.Length != 2)
					{
						Console.WriteLine("Parametro mancante");
						Console.WriteLine("Uso: CVSecurity -d <testo>");
						return;
					}
					Console.WriteLine(sa.Decrypt(args[1]));
					break;

				case "-edb":
					Console.WriteLine("Questo comando cripta le password di accesso al MCV:");
					Console.WriteLine("le password criptate verrano memorizzate nel db.");
					Console.WriteLine("Verificare che le password del MCV siano in chiaro (opzione -l)");
					Console.WriteLine("prima di lanciare questo comando.");
					Console.WriteLine();
					Console.Write("Sei sicuro di voler continuare e criptare le password: (si per continuare): ");
					if (Console.ReadLine() == "si")
						CryptDb(sa, true);
					break;

				case "-ddb":
					Console.WriteLine("Questo comando decripta le password di accesso al MCV");
					Console.WriteLine("le password decriptate verrano memorizzate nel db.");
					Console.WriteLine("Verificare che le password del MCV siano gia' criptate (opzione -ld)");
					Console.WriteLine("prima di lanciare questo comando.");
					Console.WriteLine();
					Console.Write("Sei sicuro di voler continuare e decriptare le password: (si per continuare): ");
					if (Console.ReadLine() == "si")
						CryptDb(sa, false);
					break;

				case "-l":
					ListDb(sa, false);
					break;

				case "-ld":
					ListDb(sa, true);
					break;

				case "-initdb":
					if (args.Length != 3)
					{
						Console.WriteLine("Parametro/i mancanti");
						Console.WriteLine("Uso: CVSecurity -initdb <login> <password>");
						return;
					}
					InitDb(sa, args[1], args[2]);
					break;

				case "-removedb":
					RemoveDb(sa);
					break;


				case "-cp":
					if (args.Length != 3)
					{
						Console.WriteLine("Parametro/i mancanti");
						Console.WriteLine("Uso: CVSecurity -cp <idutente> <nuova password>");
						return;
					}
					ChangePassword(sa, args[1], args[2], false);
					break;

				case "-cpd":
					if (args.Length != 3)
					{
						Console.WriteLine("Parametro/i mancanti");
						Console.WriteLine("Uso: CVSecurity -cp <idutente> <nuova password>");
						return;
					}
					ChangePassword(sa, args[1], args[2], true);
					break;
				}
			}
			catch (Exception e)
			{
				Console.WriteLine();
				Console.WriteLine("Si e' rilevato un problema durante l'esecuizione del programma:");
				Console.WriteLine(e.Message);
			}
		}

		static void CryptDb(CVCommon.SimmetricEncryptDecrypt sa, bool bEncrypt)
		{
			using (OleDbConnection cn = new OleDbConnection(ConfigurationSettings.AppSettings["ConnectionStringAdmin"]))
			{
				cn.Open();
				OleDbTransaction tr = cn.BeginTransaction();

				UpdateUtenti(sa, cn, tr, bEncrypt);
				UpdateRichiesteRegUtenti(sa, cn, tr, bEncrypt);

				tr.Commit();
			}
		}


		static void UpdateUtenti(CVCommon.SimmetricEncryptDecrypt sa, OleDbConnection cn, OleDbTransaction tr, bool bEncrypt)
		{
			DataSet ds = new DataSet();
			DataTable dt = ds.Tables.Add("Utenti");

			DataColumn c;
			c = dt.Columns.Add("IdUtente", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;

			c = dt.Columns.Add("DN", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 1023;

			dt.PrimaryKey = new DataColumn[] { dt.Columns["IdUtente"] };

			OleDbDataAdapter da = new OleDbDataAdapter();
			da.SelectCommand = new OleDbCommand("select RAWTOHEX(IdUtente) As IdUtente, DN from US.Utenti", cn, tr);
			da.UpdateCommand = new OleDbCommand("update US.Utenti Set DN=? Where IdUtente=HEXTORAW(?)", cn, tr);
			da.UpdateCommand.Parameters.Add(new OleDbParameter("DN", OleDbType.VarChar, 1023, "DN"));
			da.UpdateCommand.Parameters.Add(new OleDbParameter("IdUtente", OleDbType.VarChar, 32, "IdUtente"));

			da.Fill(ds, "Utenti");

			foreach (DataRow dr in ds.Tables["Utenti"].Rows)
			{
				string DN = (string)dr["DN"];
				if (bEncrypt)
					DN = sa.Encrypt(DN);
				else
					DN = sa.Decrypt(DN);
				dr["DN"] = DN;
			}
			da.Update(ds, "Utenti");
		}


		static void UpdateRichiesteRegUtenti(CVCommon.SimmetricEncryptDecrypt sa, OleDbConnection cn, OleDbTransaction tr, bool bEncrypt)
		{
			DataSet ds = new DataSet();
			DataTable dt = ds.Tables.Add("RichiesteRegUtenti");

			DataColumn c;
			c = dt.Columns.Add("IdUtente", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;

			c = dt.Columns.Add("DN", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 1023;

			dt.PrimaryKey = new DataColumn[] { dt.Columns["IdUtente"] };

			OleDbDataAdapter da = new OleDbDataAdapter();
			da.SelectCommand = new OleDbCommand("select RAWTOHEX(IdRichiestaRegUtente) As IdUtente, DN from US.RichiesteRegUtenti", cn, tr);
			da.UpdateCommand = new OleDbCommand("update US.RichiesteRegUtenti Set DN=? Where IdRichiestaRegUtente=HEXTORAW(?)", cn, tr);
			da.UpdateCommand.Parameters.Add(new OleDbParameter("DN", OleDbType.VarChar, 1023, "DN"));
			da.UpdateCommand.Parameters.Add(new OleDbParameter("IdUtente", OleDbType.VarChar, 32, "IdUtente"));

			da.Fill(ds, "RichiesteRegUtenti");

			foreach (DataRow dr in ds.Tables["RichiesteRegUtenti"].Rows)
			{
				string DN = (string)dr["DN"];
				if (bEncrypt)
					DN = sa.Encrypt(DN);
				else
					DN = sa.Decrypt(DN);
				dr["DN"] = DN;
			}
			da.Update(ds, "RichiesteRegUtenti");
		}

		static void ListDb(CVCommon.SimmetricEncryptDecrypt sa, bool bDecrypt)
		{
			using (OleDbConnection cn = new OleDbConnection(ConfigurationSettings.AppSettings["ConnectionStringAdmin"]))
			{
				cn.Open();
				OleDbTransaction tr = cn.BeginTransaction();

				DataSet ds = new DataSet();
				DataTable dt = ds.Tables.Add("Utenti");

				DataColumn c;
				c = dt.Columns.Add("IdUtente", typeof(string));
				c = dt.Columns.Add("Nominativo", typeof(string));
				c = dt.Columns.Add("DN", typeof(string));

				OleDbDataAdapter da = new OleDbDataAdapter();
				da.SelectCommand = new OleDbCommand("select RAWTOHEX(IdUtente) As IdUtente, Nominativo, DN from US.Utenti", cn, tr);

				da.Fill(ds, "Utenti");

				foreach (DataRow dr in ds.Tables["Utenti"].Rows)
				{
					Console.Write("{0,-33}", dr["IdUtente"]);
					Console.Write("{0,-20}", dr["Nominativo"]);

					string DN = (string)dr["DN"];
					if (bDecrypt)
						DN = sa.Decrypt(DN);
					Console.Write("{0}", DN);
					Console.WriteLine();
				}


				tr.Rollback();
			}
		}


		// Questo Id e' usato per IdRichiestaRegSoc/IdSocieta IdRichiestaRegUtente/IdUtente
		static string Id = "F8585E9600A841C78A3EE8960D1458AC";

		static void InitDb(CVCommon.SimmetricEncryptDecrypt sa, string login, string pwd)
		{
			DateTime dt = new DateTime(2000,1,1);
			string TipoUtente = ConfigurationSettings.AppSettings["Login.TipoUtente"];

			using (OleDbConnection cn = new OleDbConnection(ConfigurationSettings.AppSettings["ConnectionStringAdmin"]))
			{
				cn.Open();
				OleDbTransaction tr = cn.BeginTransaction();


				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						INSERT INTO US.RichiesteRegSoc 
							(IdRichiestaRegSoc, 
							RagioneSociale, 
							Indirizzo, 
							Citta, 
							CAP, 
							Nazione, 
							CodiceFiscale, 
							PartitaIVA, 
							Telefono, 
							Fax, 
							Email, 
							ABI, 
							CAB, 
							CC, 
							CodiceConto,
							ConsensoTrattamentoDati, 
							DataOraInserimento,
							StatoRichiesta) 
						VALUES 
							(HEXTORAW(?), 
							'MCV', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ',
							1, 
							?,
							'Valida')
					";

					cmd.Parameters.Add("Id", OleDbType.VarChar).Value = Id;
					cmd.Parameters.Add("Id", OleDbType.DBTimeStamp).Value = dt;
					cmd.ExecuteNonQuery();
				}


				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						INSERT INTO us.RichiesteRegUtenti 
						( 
						IdRichiestaRegUtente, 
						Nominativo, 
						CodiceFiscale, 
						Telefono, 
						Fax, 
						Email, 
						DataOraInserimento,
						DN, 
						IdRIchiestaRegSoc, 
						TipoUtente,
						StatoRichiesta) 
						VALUES 
						(
						HEXTORAW(?), 
						?, 
						' ', 
						' ', 
						' ', 
						' ', 
						?,
						?, 
						HEXTORAW(?), 
						?,
						'Valida')
					";

					cmd.Parameters.Add("Id", OleDbType.VarChar).Value = Id;
					cmd.Parameters.Add("Login", OleDbType.VarChar).Value = login;
					cmd.Parameters.Add("dt", OleDbType.DBTimeStamp).Value = dt;
					cmd.Parameters.Add("Pwd", OleDbType.VarChar).Value = pwd;
					cmd.Parameters.Add("IdRegSoc", OleDbType.VarChar).Value = Id;
					cmd.Parameters.Add("tu", OleDbType.VarChar).Value = TipoUtente;

					cmd.ExecuteNonQuery();
				}

				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						INSERT INTO US.Societa 
							(IdSocieta, 
							RagioneSociale, 
							Indirizzo, 
							Citta, 
							CAP, 
							Nazione, 
							CodiceFiscale, 
							PartitaIVA, 
							Telefono, 
							Fax, 
							Email, 
							ABI, 
							CAB, 
							CC, 
							CodiceConto,
							DataOraInserimento,
							DataOraModifica,
							IdRichiestaRegSoc) 
						VALUES 
							(HEXTORAW(?), 
							'MCV', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ', 
							' ',
							' ',
							?, 
							?,
							HEXTORAW(?))
					";

					cmd.Parameters.Add("Id", OleDbType.VarChar).Value = Id;
					cmd.Parameters.Add("dc", OleDbType.DBTimeStamp).Value = dt;
					cmd.Parameters.Add("dm", OleDbType.DBTimeStamp).Value = dt;
					cmd.Parameters.Add("IdR", OleDbType.VarChar).Value = Id;
					cmd.ExecuteNonQuery();
				}

				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						INSERT INTO us.Utenti 
						( 
						IdUtente, 
						Nominativo, 
						CodiceFiscale, 
						Telefono, 
						Fax, 
						Email, 
						DN, 
						DataOraInserimento,
						DataOraModifica,
						IdSocieta, 
						IdRichiestaRegUtente,
						TipoUtente,
						StatoUtente) 
						VALUES 
						(
						HEXTORAW(?), 
						?, 
						' ', 
						' ', 
						' ', 
						' ', 
						?,
						?, 
						?, 
						HEXTORAW(?), 
						HEXTORAW(?),
						?, 
						'Valido' )
					";

					cmd.Parameters.Add("Id", OleDbType.VarChar).Value = Id;
					cmd.Parameters.Add("Login", OleDbType.VarChar).Value = login;
					cmd.Parameters.Add("Pwd", OleDbType.VarChar).Value = pwd;
					cmd.Parameters.Add("di", OleDbType.DBTimeStamp).Value = dt;
					cmd.Parameters.Add("dm", OleDbType.DBTimeStamp).Value = dt;
					cmd.Parameters.Add("IdSoc", OleDbType.VarChar).Value = Id;
					cmd.Parameters.Add("IdRegUt", OleDbType.VarChar).Value = Id;
					cmd.Parameters.Add("tu", OleDbType.VarChar).Value = TipoUtente;

					cmd.ExecuteNonQuery();
				}

				tr.Commit();
			}
		}


		static void RemoveDb(CVCommon.SimmetricEncryptDecrypt sa)
		{
			using (OleDbConnection cn = new OleDbConnection(ConfigurationSettings.AppSettings["ConnectionStringAdmin"]))
			{
				cn.Open();
				OleDbTransaction tr = cn.BeginTransaction();


				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"delete from us.utenti where idutente=HEXTORAW(?)";
					cmd.Parameters.Add("", OleDbType.VarChar).Value = Id;
					cmd.ExecuteNonQuery();
				}
				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"delete from us.societa where idsocieta=HEXTORAW(?)";
					cmd.Parameters.Add("", OleDbType.VarChar).Value = Id;
					cmd.ExecuteNonQuery();
				}
				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"delete from us.richiesteRegUtenti where IdRichiestaRegUtente=HEXTORAW(?)";
					cmd.Parameters.Add("", OleDbType.VarChar).Value = Id;
					cmd.ExecuteNonQuery();
				}
				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"delete from us.richiesteRegSoc where IDRICHIESTAREGSOC=HEXTORAW(?)";
					cmd.Parameters.Add("", OleDbType.VarChar).Value = Id;
					cmd.ExecuteNonQuery();
				}

				tr.Commit();
			}
		}

		static void ChangePassword(CVCommon.SimmetricEncryptDecrypt sa, string idutiente, string pwd, bool bEncrypt)
		{
			using (OleDbConnection cn = new OleDbConnection(ConfigurationSettings.AppSettings["ConnectionStringAdmin"]))
			{
				if (bEncrypt)
					pwd = sa.Encrypt(pwd);

				cn.Open();
				OleDbTransaction tr = cn.BeginTransaction();

				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"update us.utenti set dn=? where idutente=HEXTORAW(?)";
					cmd.Parameters.Add("pwd", OleDbType.VarChar).Value = pwd;
					cmd.Parameters.Add("id", OleDbType.VarChar).Value = idutiente;
					int m = cmd.ExecuteNonQuery();
					if (m != 1)
						Console.WriteLine("Utente NON trovato");
				}

				string IdRichiestaRegUtente;
				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"select RAWTOHEX(IdRichiestaRegUtente) from us.utenti where idutente=HEXTORAW(?)";
					cmd.Parameters.Add("id", OleDbType.VarChar).Value = idutiente;
					IdRichiestaRegUtente = (string)cmd.ExecuteScalar();
				}


				using(OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"update us.RichiesteRegUtenti set dn=? where IdRichiestaRegUtente=HEXTORAW(?)";
					cmd.Parameters.Add("pwd", OleDbType.VarChar).Value = pwd;
					cmd.Parameters.Add("id", OleDbType.VarChar).Value = IdRichiestaRegUtente;
					int m = cmd.ExecuteNonQuery();
					if (m != 1)
						Console.WriteLine("Utente NON trovato");
				}

				tr.Commit();
			}
		}
	}
}
