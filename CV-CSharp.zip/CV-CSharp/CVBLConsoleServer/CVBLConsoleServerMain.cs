using System;
using System.Runtime.Remoting;

namespace CVBLConsoleServer
{
	/// <summary>
	/// Console Server utilizzato come Host per oggetti remotizzati
	/// </summary>
	class Server
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			string strPathFileConf;
			try
			{
				if (args.Length == 0)
				{
					strPathFileConf = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
				}
				else
				{
					strPathFileConf = args[0];
				}
				RemotingConfiguration.Configure(strPathFileConf);
				Console.WriteLine("Start to listen...");
				Console.Write("Type \"q\" and return to exit: ");
				while (Console.ReadLine().ToLower() != "q")
					Console.Write("Type \"q\" and return to exit: ");
			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
				Console.ReadLine();
			}
		}
	}
}
