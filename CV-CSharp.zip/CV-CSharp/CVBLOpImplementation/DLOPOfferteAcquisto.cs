using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPOfferteAcquisto.
	/// </summary>
	internal class DLOPOfferteAcquisto : DLOPBase
	{
		public DLOPOfferteAcquisto(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public DataSet GetListaByUtente(string IdSessione, string IdUtente)
		{  
			//Stefano
			/* La query deve essere modificata per non riferirsi piu` alla tabella MWCERTIFICATO
			string strSqlQuery = "SELECT RAWTOHEX(B.IdOffertaAcquisto) IdOffertaAcquisto, QtyRichiesta, QtyResidua, AnnoRiferimento, B.PrezzoUnitario, B.Compatibile, " +
								 "QtyRichiesta - QtyResidua AS QtyEseguita, " +
								 "SUM(A.QtyCertificati * A.PrezzoUnitario)/ SUM (A.qtyCertificati) AS PrezzoMedioEseguito, " +
								 "SUM(A.QtyCertificati * A.PrezzoUnitario * C.QtyMwh) AS Controvalore " +
								 "FROM CV.OfferteAcquisto B, CV.Transazioni A, CV.MwCertificato C " +
								 "WHERE A.IdOffertaAcquisto(+) = B.IdOffertaAcquisto " +
								 "AND B.IdUtente = HEXTORAW(?) " +
								 "AND B.IdSessione = HEXTORAW(?) " +
								 "AND B.AnnoRiferimento = C.Anno " +
								 "GROUP BY B.IdOffertaAcquisto,B.QtyRichiesta,B.QtyResidua,B.AnnoRiferimento,B.PrezzoUnitario,C.QtyMwh, B.Compatibile, B.DataOraCreazione " +
								 "ORDER BY B.AnnoRiferimento, B.DataOraCreazione DESC";
			*/

			//Stefano query modificata !! V E R I F I C A R E !!
			string strSqlQuery = "SELECT RAWTOHEX(B.IdOffertaAcquisto) IdOffertaAcquisto, QtyRichiesta, QtyResidua, AnnoRiferimento, B.PrezzoUnitario, B.Compatibile, " +
				"QtyRichiesta - QtyResidua AS QtyEseguita, " +
				"SUM(A.QtyCertificati * A.PrezzoUnitario)/ SUM (A.qtyCertificati) AS PrezzoMedioEseguito, " +
				"SUM(A.QtyCertificati * A.PrezzoUnitario * "
				+ (DLOPBase.MWhPerCV).ToString() +
				@") AS Controvalore " +
				"FROM CV.OfferteAcquisto B, CV.Transazioni A " +
				"WHERE A.IdOffertaAcquisto(+) = B.IdOffertaAcquisto " +
				"AND B.IdUtente = HEXTORAW(?) " +
				"AND B.IdSessione = HEXTORAW(?) " +
				"GROUP BY B.IdOffertaAcquisto,B.QtyRichiesta,B.QtyResidua,B.AnnoRiferimento,B.PrezzoUnitario, B.Compatibile, B.DataOraCreazione " +
				"ORDER BY B.AnnoRiferimento, B.DataOraCreazione DESC";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsListaOfferteAcquisto");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdUtente", OleDbType.VarChar, 33).Value = IdUtente;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 33).Value = IdSessione;
					da.Fill(ds, "ListaOfferteAcquisto");
					return ds;
				}
			}
		}

		public decimal GetCount(string IdSessione, string IdUtenteVende, string AnnoRiferimento)
		{
			string IdSocietaVende;
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = @"
					SELECT RAWTOHEX(IdSocieta) AS IdSocieta
					FROM US.Utenti
					WHERE IdUtente = HEXTORAW(?)
				";
				cmd.Parameters.Add("IdUtente", OleDbType.VarChar).Value = IdUtenteVende;
				IdSocietaVende = (string) cmd.ExecuteScalar();
			}

			string strSqlQuery = @"
				SELECT COUNT(*) NumOfferteAcquisto 
				FROM CV.OfferteAcquisto OA, US.UTENTI UA
				WHERE OA.IdSessione = HEXTORAW(?) AND 
				OA.AnnoRiferimento = ? AND 
				OA.IdUtente = UA.IdUtente AND
				UA.IdSocieta <> HEXTORAW(?) AND 
				OA.QtyResidua <> 0 AND 
				OA.PrezzoUnitario > 0
			";

			using (OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 33).Value = IdSessione;
				selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
				selectCMD.Parameters.Add("@IdSocietaVende", OleDbType.VarChar, 33).Value = IdSocietaVende;
				return (decimal)selectCMD.ExecuteScalar();
			}
		}

//		public DataSet GetListaNonEseguite(string IdSessione, string IdUtente, string AnnoRiferimento)
//		{
//			string strSqlQuery = "SELECT RAWTOHEX(IdOffertaAcquisto) IdOffertaAcquisto, " + 
//								 "QtyRichiesta, QtyResidua, AnnoRiferimento, PrezzoUnitario, " + 
//								 "DataOraCreazione, DataOraModifica, Compatibile, " + 
//								 "RAWTOHEX(IdSessione) IdSessione, StatoOfferta, " + 
//								 "RAWTOHEX(IdUtente) IdUtente " +
//								 "FROM CV.OfferteAcquisto " +
//								 "WHERE IdSessione = HEXTORAW(?) AND " +
//								 "AnnoRiferimento = ? " + 
//								 "AND IdUtente = HEXTORAW(?) " + 
//								 "AND QtyResidua <> 0 ORDER BY PrezzoUnitario ASC";
//			using (OleDbDataAdapter da = new OleDbDataAdapter())
//			{
//				DataSet ds = new DataSet("dsOfferteAcquistoNonEseguite");
//				{
//					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
//					da.SelectCommand = selectCMD;
//					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
//					selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
//					selectCMD.Parameters.Add("@IdUtente", OleDbType.VarChar, 32).Value = IdUtente;
//					da.Fill(ds, "OfferteAcquistoNonEseguite");
//					return ds;
//				}
//			}
//		}
	}
}
