using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPOffertaVendita.
	/// </summary>
	internal class DLOPOffertaVendita : DLOPBase
	{
		public DLOPOffertaVendita(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public void Delete(string IdOffertaVendita, string Firma)
		{
			//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_OffertaVendita_Delete", m_Transaction.Connection, m_Transaction);
			//			callspCMD.CommandType = CommandType.StoredProcedure;
			//
			//			// ID Offerta Vendita (input)
			//			OleDbParameter parIdOffertaVendita = new OleDbParameter("@IDOffertaVendita", OleDbType.VarChar, 32);
			//			parIdOffertaVendita.Direction = ParameterDirection.Input;
			//			parIdOffertaVendita.IsNullable = false;
			//			parIdOffertaVendita.Value = IdOffertaVendita;
			//			callspCMD.Parameters.Add(parIdOffertaVendita);
			//
			//			// ID Log (output)
			//			OleDbParameter parIdLog = new OleDbParameter("@IDLog", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
			////			parIdLog.Direction = ParameterDirection.Output;
			//			callspCMD.Parameters.Add(parIdLog);
			//
			//			callspCMD.ExecuteNonQuery();



			//			string IdLog = callspCMD.Parameters["@IDLog"].Value.ToString();
			//			string strSqlQuery = "UPDATE CV.LogOfferteVendita SET Firma = ? WHERE IdLog = HEXTORAW(?)";
			//			
			//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
			//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
			//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
			//			insertCMD.ExecuteNonQuery();


			//			string IdLog = callspCMD.Parameters["@IDLog"].Value.ToString();
			//			string strSqlQuery = "UPDATE CV.LogOfferteVendita SET Firma = ? WHERE IdLog = HEXTORAW(?)";
			//			
			//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
			//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
			//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
			//			insertCMD.ExecuteNonQuery();

			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			LogVendita(cn, tr, "Cancellazione", IdOffertaVendita, Firma);

			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
					DELETE FROM cv.OfferteVendita 
					WHERE IdOffertaVendita = HEXTORAW(?)
				";

				cmd.Parameters.Add("IdOffertaVendita", OleDbType.VarChar).Value = IdOffertaVendita;
				cmd.ExecuteNonQuery();
			}
		}

		public void DeleteIncompatible(string IdOffertaVendita, string Firma)
		{
			//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_OffertaVendita_Delete", m_Transaction.Connection, m_Transaction);
			//			callspCMD.CommandType = CommandType.StoredProcedure;
			//
			//			// ID Offerta Vendita (input)
			//			OleDbParameter parIdOffertaVendita = new OleDbParameter("@IDOffertaVendita", OleDbType.VarChar, 32);
			//			parIdOffertaVendita.Direction = ParameterDirection.Input;
			//			parIdOffertaVendita.IsNullable = false;
			//			parIdOffertaVendita.Value = IdOffertaVendita;
			//			callspCMD.Parameters.Add(parIdOffertaVendita);
			//
			//			// ID Log (output)
			//			OleDbParameter parIdLog = new OleDbParameter("@IDLog", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
			//			parIdLog.Direction = ParameterDirection.Output;
			//			callspCMD.Parameters.Add(parIdLog);
			//
			//			callspCMD.ExecuteNonQuery();
			//
			//			string IdLog = callspCMD.Parameters["@IDLog"].Value.ToString();
			//			string strSqlQuery = "UPDATE CV.LogOfferteVendita SET Firma = ? WHERE IdLog = HEXTORAW(?)";
			//			
			//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
			//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
			//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
			//			insertCMD.ExecuteNonQuery();
			//
			//			return;

    
			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			LogVendita(cn, tr, "Cancellazione", IdOffertaVendita, Firma);

			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
					DELETE FROM cv.OfferteVendita 
					WHERE IdOffertaVendita = HEXTORAW(?)
				";

				cmd.Parameters.Add("IdOffertaVendita", OleDbType.VarChar).Value = IdOffertaVendita;
				cmd.ExecuteNonQuery();
			}
		}

		public InfoOffertaVendita Get(string IdOffertaVendita)
		{
			string strSqlQuery = "SELECT RAWTOHEX(IdUtente) IdUtente, " + 
				"QtyOfferta, QtyResidua, " + 
				"(QtyOfferta - QtyResidua) As QtyEseguita, " + 
				"PrezzoUnitario, AnnoRiferimento, " + 
				"RAWTOHEX(IdSessione) IdSessione, " + 
				"Compatibile " + 
				"FROM CV.OfferteVendita " +
				"WHERE IdOffertaVendita = HEXTORAW(?)";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdOffertaVendita", OleDbType.VarChar, 32).Value = IdOffertaVendita;
				DataSet ds = new DataSet("dsInfoOffertaVendita");
				{
					da.Fill(ds, "InfoOffertaVendita");
					DataTable dt = ds.Tables["InfoOffertaVendita"];
					InfoOffertaVendita infoOV = new InfoOffertaVendita();
					if (dt.Rows.Count != 0)
					{
						if (!dt.Rows[0].IsNull("IdUtente"))
						{
							infoOV.IdUtente = dt.Rows[0]["IdUtente"].ToString();
							infoOV.IdUtenteIsNull = false;
						}
						else
						{
							infoOV.IdUtente = "";
							infoOV.IdUtenteIsNull = true;
						}

						if (!dt.Rows[0].IsNull("QtyOfferta"))
						{
							infoOV.QtyOfferta = (decimal)dt.Rows[0]["QtyOfferta"];
							infoOV.QtyOffertaIsNull = false;
						}
						else
						{
							infoOV.QtyOfferta = 0M;
							infoOV.QtyOffertaIsNull = true;
						}
						
						if (!dt.Rows[0].IsNull("QtyResidua"))
						{
							infoOV.QtyResidua = (decimal)dt.Rows[0]["QtyResidua"];
							infoOV.QtyResiduaIsNull = false;
						}
						else
						{
							infoOV.QtyResidua = 0M;
							infoOV.QtyResiduaIsNull = true;
						}

						if (!dt.Rows[0].IsNull("QtyEseguita"))
						{
							infoOV.QtyEseguita = (decimal)dt.Rows[0]["QtyEseguita"];
							infoOV.QtyEseguitaIsNull = false;
						}
						else
						{
							infoOV.QtyEseguita = 0M;
							infoOV.QtyEseguitaIsNull = true;
						}

						if (!dt.Rows[0].IsNull("PrezzoUnitario"))
						{
							infoOV.PrezzoUnitario = (decimal)dt.Rows[0]["PrezzoUnitario"];
							infoOV.PrezzoUnitarioIsNull = false;
						}
						else
						{
							infoOV.PrezzoUnitario = 0M;
							infoOV.PrezzoUnitarioIsNull = true;
						}

						if (!dt.Rows[0].IsNull("AnnoRiferimento"))
						{
							infoOV.AnnoRiferimento = dt.Rows[0]["AnnoRiferimento"].ToString(); 
							infoOV.AnnoRiferimentoIsNull = false;
						}
						else
						{
							infoOV.AnnoRiferimento = ""; 
							infoOV.AnnoRiferimentoIsNull = true;
						}
						
						if (!dt.Rows[0].IsNull("IdSessione"))
						{
							infoOV.IdSessione = dt.Rows[0]["IdSessione"].ToString();
							infoOV.IdsessioneIsNull = false;
						}
						else
						{
							infoOV.IdSessione = "";
							infoOV.IdsessioneIsNull = true;
						}

						if (!dt.Rows[0].IsNull("Compatibile"))
						{
							infoOV.Compatibile = (decimal)dt.Rows[0]["Compatibile"];
							infoOV.CompatibileIsNull = false;
						}
						else
						{
							infoOV.Compatibile = 0M;
							infoOV.CompatibileIsNull = true;
						}
					}
					return infoOV;
				}
			}
		}

		public void UpdateQtyImpegnata(string IdUtente, string IdSessione, 
			decimal QtyOfferta, string AnnoRiferimento, string TipoModifica)
		{
			//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_QtyImpegnata_Upd", m_Transaction.Connection, m_Transaction);
			//			callspCMD.CommandType = CommandType.StoredProcedure;
			//
			//			// ID Utente
			//			OleDbParameter parIdUtente = new OleDbParameter("@IDUtente", OleDbType.VarChar, 32);
			//			parIdUtente.Direction = ParameterDirection.Input;
			//			parIdUtente.IsNullable = false;
			//			parIdUtente.Value = IdUtente;
			//			callspCMD.Parameters.Add(parIdUtente);
			//
			//			// ID Sessione (input)
			//			OleDbParameter parIdSessione = new OleDbParameter("@IDSessione", OleDbType.VarChar, 32);
			//			parIdSessione.Direction = ParameterDirection.Input;
			//			parIdSessione.IsNullable = false;
			//			parIdSessione.Value = IdSessione;
			//			callspCMD.Parameters.Add(parIdSessione);
			//
			//			// Quantita Offerta (input)
			//			OleDbParameter parQtyOfferta = new OleDbParameter("@QtyOfferta", OleDbType.Decimal);
			//			parQtyOfferta.Direction = ParameterDirection.Input;
			//			parQtyOfferta.IsNullable = false;
			//			parQtyOfferta.Value = QtyOfferta;
			//			callspCMD.Parameters.Add(parQtyOfferta);
			//
			//			// Anno Riferimento (input)
			//			OleDbParameter parAnnoRiferimento = new OleDbParameter("@AnnoRiferimento", OleDbType.VarChar, 4);
			//			parAnnoRiferimento.Direction = ParameterDirection.Input;
			//			parAnnoRiferimento.IsNullable = false;
			//			parAnnoRiferimento.Value = AnnoRiferimento;
			//			callspCMD.Parameters.Add(parAnnoRiferimento);
			//


			//			// Tipo Modifica (input)
			//			OleDbParameter parTipoModifica = new OleDbParameter("@TipoModifica", OleDbType.VarChar, 32);
			//			parTipoModifica.Direction = ParameterDirection.Input;
			//			parTipoModifica.IsNullable = false;
			//			parTipoModifica.Value = TipoModifica;
			//			callspCMD.Parameters.Add(parTipoModifica);
			//
			//			callspCMD.ExecuteNonQuery();
			//			return;

			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			string IdSocieta;
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
					SELECT RAWTOHEX(IdSocieta) AS IdSocieta
					FROM US.Utenti
					WHERE IdUtente = HEXTORAW(?)
				";

				cmd.Parameters.Add("IdUtente", OleDbType.VarChar).Value = IdUtente;

				IdSocieta = (string) cmd.ExecuteScalar();
			}
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				string ss = @"
					UPDATE cv.CertificatiVerdi
					SET QtyImpegnata = QtyImpegnata ";
				
				if (TipoModifica == "Diminuita")
					ss = ss + " - ? ";
				else
					ss = ss + " + ? ";

				ss = ss + @"
					WHERE IdSocieta = HEXTORAW(?)
					AND IdSessione  = HEXTORAW(?) 
					AND AnnoRiferimento = ?
					";

				cmd.CommandText = ss;
				cmd.Parameters.Add("in_QtyOfferta", OleDbType.Decimal).Value = QtyOfferta;
				cmd.Parameters.Add("IdSocieta", OleDbType.VarChar).Value = IdSocieta;
				cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
				cmd.Parameters.Add("AnnoRif", OleDbType.VarChar).Value = AnnoRiferimento;

				cmd.ExecuteNonQuery();
			}
		}

		public decimal Modifica(string IdOffertaVendita, decimal NuovoPrezzo, decimal NuovaQtyResidua, decimal OldQtyResidua, string Firma)
		{
			//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_OffertaVendita_Upd", m_Transaction.Connection, m_Transaction);
			//			callspCMD.CommandType = CommandType.StoredProcedure;
			//
			//			// ID Offerta Vendita (input)
			//			OleDbParameter parIdOffertaVendita = new OleDbParameter("@IDOffertaVendita", OleDbType.VarChar, 32);
			//			parIdOffertaVendita.Direction = ParameterDirection.Input;
			//			parIdOffertaVendita.IsNullable = false;
			//			parIdOffertaVendita.Value = IdOffertaVendita;
			//			callspCMD.Parameters.Add(parIdOffertaVendita);
			//
			//			// Nuovo Prezzo (input)
			//			OleDbParameter parNuovoPrezzo = new OleDbParameter("@NuovoPrezzo", OleDbType.Decimal);
			//			parNuovoPrezzo.Direction = ParameterDirection.Input;
			//			parNuovoPrezzo.IsNullable = false;
			//			parNuovoPrezzo.Value = NuovoPrezzo;
			//			callspCMD.Parameters.Add(parNuovoPrezzo);
			//
			//			// Nuova Quantita' Residua (input)
			//			OleDbParameter parNuovaQtyResidua = new OleDbParameter("@NuovaQtyResidua", OleDbType.Decimal);
			//			parNuovaQtyResidua.Direction = ParameterDirection.Input;
			//			parNuovaQtyResidua.IsNullable = false;
			//			parNuovaQtyResidua.Value = NuovaQtyResidua;
			//			callspCMD.Parameters.Add(parNuovaQtyResidua);
			//
			//			// Old Quantita' Residua (input)
			//			OleDbParameter parOldQtyResidua = new OleDbParameter("@OldQtyResidua", OleDbType.Decimal);
			//			parOldQtyResidua.Direction = ParameterDirection.Input;
			//			parOldQtyResidua.IsNullable = false;
			//			parOldQtyResidua.Value = OldQtyResidua;
			//			callspCMD.Parameters.Add(parOldQtyResidua);
			//
			//			// Return Value (output)
			//			OleDbParameter parRetVal = new OleDbParameter("@RetVal", OleDbType.Decimal);
			//			parRetVal.Direction = ParameterDirection.Output;
			//			callspCMD.Parameters.Add(parRetVal);
			//
			//			// ID Log (output)
			//			OleDbParameter parIdLog = new OleDbParameter("@IdLog", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
			//			parIdLog.Direction = ParameterDirection.Output;
			//			callspCMD.Parameters.Add(parIdLog);
			//
			//			callspCMD.ExecuteNonQuery();
			//			decimal retval = (decimal)callspCMD.Parameters["@RetVal"].Value;
			//			string IdLog = callspCMD.Parameters["@IDLog"].Value.ToString();
			//			string strSqlQuery = "UPDATE CV.LogOfferteVendita SET Firma = ? WHERE IdLog = HEXTORAW(?)";
			//			
			//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
			//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
			//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
			//			insertCMD.ExecuteNonQuery();
			//
			//
			//			//return (decimal)callspCMD.Parameters["@RetVal"].Value;
			//			return retval;

			decimal retVal;

			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			decimal loc_OVen_QtyOfferta;
			decimal loc_OVen_QtyResidua;
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
				SELECT QtyOfferta, QtyResidua
				FROM   cv.OfferteVendita
				WHERE  IdOffertaVendita = HEXTORAW(?)
				FOR UPDATE OF QtyOfferta
				";

				cmd.Parameters.Add("IdOffertaVendita", OleDbType.VarChar).Value = IdOffertaVendita;

				using (OleDbDataReader r = cmd.ExecuteReader())
				{
					if (r.Read() == false)
						throw new Exception("Non trovo IdOffertaVendita");

					loc_OVen_QtyOfferta = (decimal) r[0];
					loc_OVen_QtyResidua = (decimal) r[1];
				}
			}

			decimal loc_QtyEseguita   = loc_OVen_QtyOfferta - loc_OVen_QtyResidua;
			decimal loc_NewQtyOfferta = NuovaQtyResidua + loc_QtyEseguita;

			if (loc_OVen_QtyResidua == 0m)
			{
				retVal = 0;  // Impossibile effettuare la modifica
			}
			else if (OldQtyResidua != loc_OVen_QtyResidua) 
			{
				retVal = 0;  // --Impossibile effettuare la modifica
			}
			else
			{
				retVal = 1; // --Update effettuato

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						UPDATE cv.OfferteVendita
						SET QtyOfferta = ?,
						QtyResidua = ?,
						PrezzoUnitario = ?
						WHERE IdOffertaVendita=HEXTORAW(?)
					";

					cmd.Parameters.Add("QtyOfferta", OleDbType.Decimal).Value = loc_NewQtyOfferta;
					cmd.Parameters.Add("QtyResidua", OleDbType.Decimal).Value = NuovaQtyResidua;
					cmd.Parameters.Add("PrezzoUnitario", OleDbType.Decimal).Value = NuovoPrezzo;
					cmd.Parameters.Add("IdOffertaVendita", OleDbType.VarChar).Value = IdOffertaVendita;
					cmd.ExecuteNonQuery();
				}
			}

			LogVendita(cn, tr, "Modifica", IdOffertaVendita, Firma);

			return retVal;
		}

		public static void LogVendita(OleDbConnection cn, OleDbTransaction tr, string TipoOperazione, string IdOffertaVendita, string Firma)
		{
			if (TipoOperazione != "Cancellazione")
			{
				decimal loc_QtyOfferta;
				decimal loc_QtyResidua;
				string loc_AnnoRiferimento;
				decimal loc_PrezzoUnitario;
				DateTime loc_DataOraCreazione;
				DateTime loc_DataOraModifica;
				string loc_IdSessione;
				string loc_IdUtente;

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					// sono tutti campi NOT NULL
					cmd.CommandText = @"
					SELECT 
						QtyOfferta, 
						QtyResidua, 
						AnnoRiferimento, 
						PrezzoUnitario, 
						DataOraCreazione, 
						DataOraModifica, 
						RAWTOHEX(IdSessione) AS IdSessione, 
						RAWTOHEX(IdUtente) AS IdUtente
					FROM   cv.OfferteVendita
					WHERE  IdOffertaVendita = HEXTORAW(?)
					";

					cmd.Parameters.Add("IdOffertaVentita", OleDbType.VarChar).Value = IdOffertaVendita;

					using (OleDbDataReader r = cmd.ExecuteReader())
					{
						if (r.Read())
						{
							loc_QtyOfferta = (decimal)r[0];
							loc_QtyResidua = (decimal)r[1];
							loc_AnnoRiferimento = (string)r[2];
							loc_PrezzoUnitario = (decimal)r[3];
							loc_DataOraCreazione = (DateTime)r[4];
							loc_DataOraModifica = (DateTime)r[5];
							loc_IdSessione = (string)r[6];
							loc_IdUtente = (string)r[7];
						}
						else
							throw new Exception("Non trovo l'offerta vendita");
					}
				}

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
					INSERT INTO cv.LogOfferteVendita
						(IdLog,
						TipoOperazione,
						IdOffertaVendita,
						QtyOfferta,
						QtyResidua,
						AnnoRiferimento,
						PrezzoUnitario,
						DataOraCreazione,
						DataOraModifica,
						IdUtente,
						IdSessione,
						Firma)
					VALUES	
						(HEXTORAW(?),
						?,
						HEXTORAW(?),
						?,
						?,
						?,
						?,
						?,
						?,
						HEXTORAW(?),
						HEXTORAW(?),
						?)
					";

					string IdLog = Guid.NewGuid().ToString("N").ToUpper();

					cmd.Parameters.Add("IdLog",            OleDbType.VarChar).Value = IdLog;
					cmd.Parameters.Add("TipoOperazione",   OleDbType.VarChar).Value = TipoOperazione;
					cmd.Parameters.Add("IdOffertaVendita", OleDbType.VarChar).Value = IdOffertaVendita;
					cmd.Parameters.Add("QtyOfferta",       OleDbType.Decimal).Value = loc_QtyOfferta;
					cmd.Parameters.Add("QtyResidua",       OleDbType.Decimal).Value = loc_QtyResidua;
					cmd.Parameters.Add("AnnoRiferimento",  OleDbType.VarChar).Value = loc_AnnoRiferimento; 
					cmd.Parameters.Add("PrezzoUnitario",   OleDbType.Decimal).Value = loc_PrezzoUnitario; 
					cmd.Parameters.Add("DataOraCreazione", OleDbType.DBTimeStamp).Value = loc_DataOraCreazione; 
					cmd.Parameters.Add("DataOraModifica",  OleDbType.DBTimeStamp).Value = loc_DataOraModifica; 
					cmd.Parameters.Add("IdUtente",	       OleDbType.VarChar).Value = loc_IdUtente; 
					cmd.Parameters.Add("IdSessione",       OleDbType.VarChar).Value = loc_IdSessione; 
					cmd.Parameters.Add("Firma",            OleDbType.LongVarChar).Value = Firma; 
					cmd.ExecuteNonQuery();
				}
			}
			else
			{
				string loc_IdSessione;
				string loc_IdUtente;
				DateTime loc_DataOraCreazione;
				string loc_AnnoRiferimento;
				DateTime loc_DataOraModifica;

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
				    SELECT 
						RAWTOHEX(IdSessione) AS IdSessione, 
						RAWTOHEX(IdUtente) AS IdUtente, 
						DataOraCreazione, 
						AnnoRiferimento,
						SYSDATE AS DataOraModifica
					FROM   cv.OfferteVendita
					WHERE  IdOffertaVendita = HEXTORAW(?)
					";

					cmd.Parameters.Add("IdOffertaVentita", OleDbType.VarChar).Value = IdOffertaVendita;

					using (OleDbDataReader r = cmd.ExecuteReader())
					{
						if (r.Read())
						{
							loc_IdSessione = (string)r[0];
							loc_IdUtente = (string)r[1];
							loc_DataOraCreazione = (DateTime)r[2];
							loc_AnnoRiferimento = (string)r[3];
							loc_DataOraModifica = (DateTime)r[4];
						}
						else 
							throw new Exception("Non trovo l'offerta di vendita");
					}
				}

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
					INSERT INTO cv.LogOfferteVendita
						(IdLog,
						TipoOperazione,
						IdOffertaVendita,
						QtyOfferta,
						QtyResidua,
						AnnoRiferimento,
						PrezzoUnitario,
						DataOraCreazione,
						DataOraModifica,
						IdUtente,
						IdSessione,
						Firma)
					VALUES	
						(HEXTORAW(?),
						?,
						HEXTORAW(?),
						NULL,
						NULL,
						?,
						NULL,
						?,
						?,
						HEXTORAW(?),
						HEXTORAW(?),
						?)
					";

					string IdLog = Guid.NewGuid().ToString("N").ToUpper();

					cmd.Parameters.Add("IdLog",            OleDbType.VarChar).Value = IdLog;
					cmd.Parameters.Add("TipoOperazione",   OleDbType.VarChar).Value = TipoOperazione;
					cmd.Parameters.Add("IdOffertaVendita", OleDbType.VarChar).Value = IdOffertaVendita;
					cmd.Parameters.Add("AnnoRiferimento",  OleDbType.VarChar).Value = loc_AnnoRiferimento; 
					cmd.Parameters.Add("DataOraCreazione", OleDbType.DBTimeStamp).Value = loc_DataOraCreazione; 
					cmd.Parameters.Add("DataOraModifica",  OleDbType.DBTimeStamp).Value = loc_DataOraModifica; 
					cmd.Parameters.Add("IdUtente",	       OleDbType.VarChar).Value = loc_IdUtente; 
					cmd.Parameters.Add("IdSessione",       OleDbType.VarChar).Value = loc_IdSessione; 
					cmd.Parameters.Add("Firma",            OleDbType.LongVarChar).Value = Firma; 

					cmd.ExecuteNonQuery();
				}
			}
		}
	}
}
