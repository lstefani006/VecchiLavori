using System;
using System.Collections;
using System.Text; 
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for Sessioni.
	/// </summary>
	public class BLOPSessioni : CVRemotingBase, IBLOPSessioni
	{
		public BLOPSessioni()
		{
		}
		public DatiSessione GetInfoSessione(string IdSessione)
		{
			DatiSessione InfoSessione;
			try
			{
				InfoSessione = new DatiSessione();
				InfoSessione.NomeSessione = "Sessione di prova Remota";
				return (InfoSessione);
			}
			catch(Exception ex)
			{
				throw ex;
			}
			finally
			{
			}
		}
		public ArrayList GetInfoSessioni()
		{
			DatiSessione InfoSessione;
			ArrayList Lista;
			try
			{
				InfoSessione = new DatiSessione();
				Lista = new ArrayList();
				InfoSessione.NomeSessione = "Sessione di prova Remota 1";
				Lista.Add(InfoSessione);
				InfoSessione = new DatiSessione();
				InfoSessione.NomeSessione = "Sessione di prova Remota 2";
				Lista.Add(InfoSessione);
				return (Lista);
			}
			catch(Exception ex)
			{
				throw ex;
			}
			finally
			{
			}
		}
	}
}
