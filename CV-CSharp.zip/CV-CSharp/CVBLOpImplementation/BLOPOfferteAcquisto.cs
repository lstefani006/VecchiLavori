using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPOfferteAcquisto.
	/// </summary>
	public class BLOPOfferteAcquisto : CVRemotingBase, IBLOPOfferteAcquisto
	{
		public BLOPOfferteAcquisto()
		{
		}
		
		public DataSet GetListaByUtente(string IdSessione, string IdUtente)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _GetListaByUtente(dbTran, IdSessione, IdUtente);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal DataSet _GetListaByUtente(IDbTransaction dbTran, string IdSessione, string IdUtente)
		{
			DLOPOfferteAcquisto dl = new DLOPOfferteAcquisto(dbTran);
			DataSet ds = dl.GetListaByUtente(IdSessione, IdUtente);
			return ds;
		}

		
		public decimal GetCount(string IdSessione, string IdUtente, string AnnoRiferimento)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					decimal numOfferteAcquisto = _GetCount(dbTran, IdSessione, IdUtente, AnnoRiferimento);
					dbTran.Commit();
					return numOfferteAcquisto;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal decimal _GetCount(IDbTransaction dbTran, string IdSessione, string IdUtente, string AnnoRiferimento)
		{
			DLOPOfferteAcquisto dl = new DLOPOfferteAcquisto(dbTran);
			decimal numOfferteAcquisto = dl.GetCount(IdSessione, IdUtente, AnnoRiferimento);
			return numOfferteAcquisto;
		}


//		public DataSet GetListaNonEseguite(string IdSessione, string IdUtente, string AnnoRiferimento)
//		{
//			using (IDbConnection cn = DLOPCommon.GetDBConnection())
//			{
//				cn.Open();
//				IDbTransaction dbTran = cn.BeginTransaction();
//				try
//				{
//					DataSet ds = _GetListaNonEseguite(dbTran, IdSessione, IdUtente, AnnoRiferimento);
//					dbTran.Commit();
//					return ds;
//				}
//				catch(Exception exc)
//				{
//					dbTran.Rollback();
//					throw exc;
//				}
//			}
//		}

//		internal DataSet _GetListaNonEseguite(IDbTransaction dbTran, string IdSessione, string IdUtente, string AnnoRiferimento)
//		{
//			DLOPOfferteAcquisto dl = new DLOPOfferteAcquisto(dbTran);
//			DataSet ds = dl.GetListaNonEseguite(IdSessione, IdUtente, AnnoRiferimento);
//			return ds;
//		}
	}
}
