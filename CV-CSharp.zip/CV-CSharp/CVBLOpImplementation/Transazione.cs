using System;

namespace CV.Op
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Transazione : CVRemotingBase, ITransazione
	{
		public Transazione()
		{
		}
		public void SetStato(string IdTransazione, string Stato)
		{
		}

		public string GetStato(string IdTransazione)
		{
			return "Valida";
		}
	}
}
