using System;

namespace CV.Op
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class BLOPTransazione : CVRemotingBase, IBLOPTransazione
	{
		public BLOPTransazione()
		{
		}
		public void SetStato(string IdTransazione, string Stato)
		{
		}

		public string GetStato(string IdTransazione)
		{
			return "Valida";
		}
	}
}
