using System;
using System.Text;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPBudgets.
	/// </summary>
	public class BLOPBudgets : CVRemotingBase, IBLOPBudgets
	{
		public BLOPBudgets()
		{
		}


		public DataSet Get(string IdSocieta, string IdSessione)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					// Creo un unico DataSet contenente sia i dati delle societa
					// sia i loro dati di budget.

					// Qui carico il budget (IdSocieta puo' essere "" o null ==> tutte le societa)
					DataSet dsBudget = this.Get(dbTran, IdSocieta, IdSessione);

					// Qui carico i dati della societa (o di tutte)
					DLOPSocieta dlSocieta = new DLOPSocieta(dbTran);
					DataSet dsSocieta = dlSocieta.GetListaByIdSocieta(IdSocieta);

					DataTable dtSocieta = dsSocieta.Tables[0].Copy();

					// Creo una copia della tabella in quanto NON si puo' aggiungere
					// ad un DataSet una tabella appartenente ad un altro Dataset.					
					dsBudget.Tables.Add(dtSocieta);
				
					// Creo la relazione tra le due tabelle [Societa, Budget]
					DataTable dtBudget = dsBudget.Tables[0];
					DataColumn societaCol = dtSocieta.Columns["IdSocieta"];
					DataColumn budgetCol = dsBudget.Tables["Budgets"].Columns["IdSocieta"];
					DataRelation relSocietaBudget = new DataRelation("relSocietaBudget", societaCol, budgetCol);
					dsBudget.Relations.Add(relSocietaBudget);
					
					dbTran.Commit();
					return dsBudget;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		internal DataSet Get(IDbTransaction dbTran, string IdSocieta, string IdSessione)
		{
			DLOPBudgets dl = new DLOPBudgets(dbTran);
			DataSet ds = dl.Get(IdSessione, IdSocieta);
			return ds;
		}


		public DataSet Update(DataSet ds)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					this.Update(dbTran, ds);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal void Update(IDbTransaction dbTran, DataSet ds)
		{
			DLOPBudgets dl = new DLOPBudgets(dbTran);
			dl.Update(ds);
		}
	}
}
