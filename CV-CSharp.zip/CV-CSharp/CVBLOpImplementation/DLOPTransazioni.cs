using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPTransazioni.
	/// </summary>
	internal class DLOPTransazioni : DLOPBase
	{
		public DLOPTransazioni(IDbTransaction dbTransazione):base(dbTransazione)
		{
			m_Transaction = (OleDbTransaction)dbTransazione;
		}

		public DataSet GetRecordByIdOffertaAcquisto(string IdOffertaAcquisto)
		{   
			//Stefano
			/* La query deve essere modificata per non riferirsi piu` alla tabella MWCERTIFICATO
			string strSqlQuery = "SELECT RAWTOHEX(A.IdTransazione) IdTransazione, " + 
								 "A.QtyCertificati, (A.PrezzoUnitario) As PrezzoUnitarioMWh, " +
								 "(A.PrezzoUnitario * A.QtyCertificati * C.QtyMwh) As PrezzoTotMWh, " +
								 "A.DataOraOperazione " +
								 "FROM cv.Transazioni  A, cv.OfferteAcquisto B, cv.MwCertificato C " +
								 "WHERE  A.IdOffertaAcquisto = HEXTORAW(?) AND " +
								 "B.AnnoRiferimento = C.Anno AND " +
								 "B.IdOffertaAcquisto = HEXTORAW(?)";
			*/
			
			//Stefano query modificata !! V E R I F I C A R E !!
			string strSqlQuery = "SELECT RAWTOHEX(A.IdTransazione) IdTransazione, " + 
								"A.QtyCertificati, (A.PrezzoUnitario) As PrezzoUnitarioMWh, " +
								"(A.PrezzoUnitario * A.QtyCertificati * " 
								+ (DLOPBase.MWhPerCV).ToString() +   
								@") As PrezzoTotMWh, " +
								"A.DataOraOperazione " +
								"FROM cv.Transazioni  A, cv.OfferteAcquisto B " +
								"WHERE  A.IdOffertaAcquisto = HEXTORAW(?) AND " +
								"B.IdOffertaAcquisto = HEXTORAW(?)";
			
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsOfferteAcquisto");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdOffertaAcquisto", OleDbType.VarChar, 32).Value = IdOffertaAcquisto;
					selectCMD.Parameters.Add("@IdOffertaAcquisto", OleDbType.VarChar, 32).Value = IdOffertaAcquisto;
					da.Fill(ds, "OfferteAcquisto");
					return ds;
				}
			}
		}

		public DataSet GetRecordByIdOffertaVendita(string IdOffertaVendita)
		{
			//Stefano
			/* La query deve essere modificata per non riferirsi piu` alla tabella MWCERTIFICATO
			string strSqlQuery = "SELECT RAWTOHEX(A.IdTransazione) IdTransazione, " + 
								 "A.QtyCertificati, (A.PrezzoUnitario) As PrezzoUnitarioMWh, " +
								 "(A.PrezzoUnitario * A.QtyCertificati * C.QtyMwh) As PrezzoTotMWh, " + 
								 "A.DataOraOperazione " +
								 "FROM   cv.Transazioni  A, cv.OfferteVendita B, cv.MwCertificato C " +
								 "WHERE  A.IdOffertaVendita = HEXTORAW(?) AND " +
								 "B.AnnoRiferimento = C.Anno AND " +
								 "B.IdOffertaVendita = HEXTORAW(?)";
			*/
			
			//Stefano query modificata !! V E R I F I C A R E !!
			string strSqlQuery = "SELECT RAWTOHEX(A.IdTransazione) IdTransazione, " + 
								 "A.QtyCertificati, (A.PrezzoUnitario) As PrezzoUnitarioMWh, " +
								 "(A.PrezzoUnitario * A.QtyCertificati * "
								 + (DLOPBase.MWhPerCV).ToString() + 
								 @") As PrezzoTotMWh, " + 
								 "A.DataOraOperazione " +
								 "FROM   cv.Transazioni  A, cv.OfferteVendita B " +
								 "WHERE  A.IdOffertaVendita = HEXTORAW(?) AND " +
								 "B.IdOffertaVendita = HEXTORAW(?)";


			
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsOfferteVendita");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdOffertaVendita", OleDbType.VarChar, 32).Value = IdOffertaVendita;
					selectCMD.Parameters.Add("@IdOffertaVendita", OleDbType.VarChar, 32).Value = IdOffertaVendita;
					da.Fill(ds, "OfferteVendita");
					return ds;
				}
			}
		}

		public DataSet GetPrezziMinMax(string IdSessione, string AnnoRiferimento)
		{
			string strSqlQuery = "SELECT Min(Transazioni.PrezzoUnitario) as PrezzoMin, " +
				"Max(Transazioni.PrezzoUnitario) as PrezzoMax, " +
				"Sum(Transazioni.QtyCertificati) as VolumeScambi, " +
				"Sum(Transazioni.PrezzoUnitario*Transazioni.QtyCertificati)/Sum(Transazioni.QtyCertificati) As PrezzoRiferimento " +
				"FROM   cv.Transazioni, cv.OfferteVendita, cv.OfferteAcquisto " +
				"WHERE  cv.OfferteVendita.IdSessione = HEXTORAW(?) AND " +
				"cv.OfferteAcquisto.IdSessione = HEXTORAW(?) AND " +
				"cv.OfferteVendita.AnnoRiferimento LIKE ? AND " +
				"cv.OfferteAcquisto.AnnoRiferimento LIKE ? AND " +
				"cv.OfferteVendita.IdOffertaVendita = cv.Transazioni.IdOffertaVendita  AND " +
				"cv.OfferteAcquisto.IdOffertaAcquisto = cv.Transazioni.IdOffertaAcquisto";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsPrezziMinMax");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
					selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
					selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
					da.Fill(ds, "PrezziMinMax");
					return ds;
				}
			}
		}

		public DataSet GetUltimoPrezzo(string IdSessione, string AnnoRiferimento)
		{
			string strSqlQuery = "SELECT cv.Transazioni.PrezzoUnitario, CV.OfferteVendita.PrezzoUnitario " +
								 "FROM cv.Transazioni, CV.OfferteVendita, CV.OfferteAcquisto " +
								 "WHERE cv.OfferteVendita.IdSessione = HEXTORAW(?) AND " +
								 "cv.OfferteAcquisto.IdSessione = HEXTORAW(?) AND " +
								 "cv.OfferteVendita.AnnoRiferimento LIKE ? AND " +
								 "cv.OfferteAcquisto.AnnoRiferimento LIKE ? AND " +
								 "cv.OfferteVendita.IdOffertaVendita = cv.Transazioni.IdOffertaVendita AND " +
								 "cv.OfferteAcquisto.IdOffertaAcquisto = cv.Transazioni.IdOffertaAcquisto " +
								 "ORDER BY cv.Transazioni.DataOraOperazione DESC";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsUltimoPrezzo");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
					selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
					selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
					da.Fill(ds, "UltimoPrezzo");
					return ds;
				}
			}
		}

		public DataSet GetTransazioniAcquisto(string IdSessione, string IdUtente)
		{
			//Stefano
			/* La query deve essere modificata per non riferirsi piu` alla tabella MWCERTIFICATO
			string strSqlQuery = "SELECT RAWTOHEX(A.IdTransazione) IdTransazione, D.AnnoRiferimento, " + 
								 "A.QtyCertificati, (A.PrezzoUnitario) As PrezzoUnitarioMWh, " +
								 "(A.PrezzoUnitario * A.QtyCertificati * C.QtyMwh) As PrezzoTotMWh, " +
								 "A.DataOraOperazione " +
								 "FROM CV.Transazioni A, CV.MwCertificato C, CV.OfferteAcquisto D " +
								 "WHERE D.IdUtente = HEXTORAW(?) AND " +
								 "D.IdSessione = HEXTORAW(?) AND " +
								 "D.AnnoRiferimento = C.Anno AND " +
								 "A.IdOffertaAcquisto = D.IdOffertaAcquisto";
			*/

			//Stefano query modificata !! V E R I F I C A R E !!
			string strSqlQuery = "SELECT RAWTOHEX(A.IdTransazione) IdTransazione, D.AnnoRiferimento, " + 
								"A.QtyCertificati, (A.PrezzoUnitario) As PrezzoUnitarioMWh, " +
								"(A.PrezzoUnitario * A.QtyCertificati * "
								+ (DLOPBase.MWhPerCV).ToString() +  
								@") As PrezzoTotMWh, " +
								"A.DataOraOperazione " +
								"FROM CV.Transazioni A, CV.OfferteAcquisto D " +
								"WHERE D.IdUtente = HEXTORAW(?) AND " +
								"D.IdSessione = HEXTORAW(?) AND " +
								"A.IdOffertaAcquisto = D.IdOffertaAcquisto";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsTransazioniAcquisto");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdUtente", OleDbType.VarChar, 32).Value = IdUtente;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
					da.Fill(ds, "TransazioniAcquisto");
					return ds;
				}
			}
		}

		public DataSet GetTransazioniVendita(string IdSessione, string IdUtente)
		{
			//Stefano
			/* La query deve essere modificata per non riferirsi piu` alla tabella MWCERTIFICATO
			string strSqlQuery = "SELECT RAWTOHEX(A.IdTransazione) IdTransazione, " + 
								 "D.AnnoRiferimento, A.QtyCertificati, " + 
								 "(A.PrezzoUnitario) As PrezzoUnitarioMWh, " +
								 "(A.PrezzoUnitario * A.QtyCertificati * C.QtyMwh) As PrezzoTotMWh, " + 
								 "A.DataOraOperazione " +
								 "FROM CV.Transazioni A, CV.MwCertificato C, CV.OfferteVendita D " +
								 "WHERE D.IdUtente = HEXTORAW(?) AND " +
								 "D.IdSessione = HEXTORAW(?) AND " +
								 "D.AnnoRiferimento = C.Anno AND " +
								 "A.IdOffertaVendita = D.IdOffertaVendita";
			*/
			
			//Stefano query modificata !! V E R I F I C A R E !!
			string strSqlQuery = "SELECT RAWTOHEX(A.IdTransazione) IdTransazione, " + 
								"D.AnnoRiferimento, A.QtyCertificati, " + 
								"(A.PrezzoUnitario) As PrezzoUnitarioMWh, " +
								"(A.PrezzoUnitario * A.QtyCertificati * "
								+ (DLOPBase.MWhPerCV).ToString() + 
								@") As PrezzoTotMWh, " + 
								"A.DataOraOperazione " +
								"FROM CV.Transazioni A, CV.OfferteVendita D " +
								"WHERE D.IdUtente = HEXTORAW(?) AND " +
								"D.IdSessione = HEXTORAW(?) AND " +
								"A.IdOffertaVendita = D.IdOffertaVendita";
			
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsTransazioniVendita");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdUtente", OleDbType.VarChar, 32).Value = IdUtente;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
					da.Fill(ds, "TransazioniVendita");
					return ds;
				}
			}
		}
	}
}
