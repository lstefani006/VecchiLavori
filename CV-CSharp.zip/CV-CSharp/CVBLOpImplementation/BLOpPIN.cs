using System;
using System.Data;
using System.Text;
using System.Diagnostics;

namespace CV.Op
{
	public class BLOPPin : CVRemotingBase, IBLOPPin
	{
		public string CausaleVersamento(string CodiceConto, DateTime DataSessione)
		{
			int numchar = 10 - CodiceConto.Length ;
			
			for (int i=0; i<numchar; i++)
				CodiceConto = "0" + CodiceConto ;

			CodiceConto = CodiceConto.ToUpper().Substring(0,10);

			int g = DataSessione.Day ;
			int m = DataSessione.Month ;
			int a = DataSessione.Year ;
			string giorno = "" ;
			string mese = "" ;
			string anno = "" ;
			if (g < 10)
			{
				giorno = "0" + g.ToString() ;
			}
			else
			{
				giorno = g.ToString() ;
			}
			if (m < 10)
			{
				mese = "0" + m.ToString() ;
			}
			else
			{
				mese = m.ToString() ;
			}
			anno = a.ToString() ;
			string data = giorno + mese + anno ;

			string CodParziale = CodiceConto + data ;
			string temp = CodiceConto + data ;
			string codifica = "" ;
			for (int i=0; i<temp.Length; i++)
				codifica = codifica + Cod(temp.Substring(i,1)) ;

			codifica = codifica + "00" ;

			int numsegmenti = (int)(codifica.Length / 7) ;
			string strresto = "" ;
			int val = 0 ;
			int resto = 0 ;
			for (int i=0; i<numsegmenti; i++)
			{
				temp = strresto + codifica.Substring(i*7, 7);
				val = Convert.ToInt32(temp);
				resto = val % 97 ;
				strresto = resto.ToString() ;
			}
			temp = strresto + codifica.Substring(numsegmenti*7, codifica.Length-numsegmenti*7);
			val = Convert.ToInt32(temp);
			resto = val % 97 ;

			int CheckSum = 98 - resto ;
			
			return "CP" + CheckSum.ToString() + CodParziale ;
		}

		public string Cod(string ch)
		{
			if (ch=="0")
				return "0" ;
			if (ch=="1")
				return "1" ;
			if (ch=="2")
				return "2" ;
			if (ch=="3")
				return "3" ;
			if (ch=="4")
				return "4" ;
			if (ch=="5")
				return "5" ;
			if (ch=="6")
				return "6" ;
			if (ch=="7")
				return "7" ;
			if (ch=="8")
				return "8" ;
			if (ch=="9")
				return "9" ;
			if (ch=="A")
				return "10" ;
			if (ch=="B")
				return "11" ;
			if (ch=="C")
				return "12" ;
			if (ch=="D")
				return "13" ;
			if (ch=="E")
				return "14" ;
			if (ch=="F")
				return "15" ;
			if (ch=="G")
				return "16" ;
			if (ch=="H")
				return "17" ;
			if (ch=="I")
				return "18" ;
			if (ch=="J")
				return "19" ;
			if (ch=="K")
				return "20" ;
			if (ch=="L")
				return "21" ;
			if (ch=="M")
				return "22" ;
			if (ch=="N")
				return "23" ;
			if (ch=="O")
				return "24" ;
			if (ch=="P")
				return "25" ;
			if (ch=="Q")
				return "26" ;
			if (ch=="R")
				return "27" ;
			if (ch=="S")
				return "28" ;
			if (ch=="T")
				return "29" ;
			if (ch=="U")
				return "30" ;
			if (ch=="V")
				return "31" ;
			if (ch=="W")
				return "32" ;
			if (ch=="X")
				return "33" ;
			if (ch=="Y")
				return "34" ;
			if (ch=="Z")
				return "35" ;
			
			return "" ;
		}

		public string NewPin()
		{
			char [] CSet = new char[35+1];
			CSet[0]  = '0';
			CSet[1]  = 'A';
			CSet[2]  = 'B';
			CSet[3]  = 'C';
			CSet[4]  = '9';
			CSet[5]  = 'D';
			CSet[6]  = 'E';
			CSet[7]  = 'F';
			CSet[8]  = '8';
			CSet[9]  = 'G';
			CSet[10] = 'H';
			CSet[11] = 'I';
			CSet[12] = '7';
			CSet[13] = 'J';
			CSet[14] = 'K';
			CSet[15] = 'L';
			CSet[16] = '6';
			CSet[17] = 'M';
			CSet[18] = 'N';
			CSet[19] = 'O';
			CSet[20] = '5';
			CSet[21] = 'P';
			CSet[22] = 'Q';
			CSet[23] = 'R';
			CSet[24] = '4';
			CSet[25] = 'S';
			CSet[26] = 'T';
			CSet[27] = 'U';
			CSet[28] = '3';
			CSet[29] = 'V';
			CSet[30] = 'W';
			CSet[31] = 'X';
			CSet[32] = '2';
			CSet[33] = 'Y';
			CSet[34] = 'Z';
			CSet[35] = '1';

			Random rnd = new Random();

			StringBuilder sb = new StringBuilder();
		
			for (int i = 0; i < 15; ++i)
				sb.Append(CSet[rnd.Next(0, 35)]);

			sb.Append(computeCS(sb.ToString()));
			return sb.ToString();
		}


		public bool Verify(string strPIN)
		{
			if (strPIN.Length == 16)
				return computeCS(strPIN) == strPIN[15];
			return false;
		}

		char computeCS(string strPin)
		{
			Debug.Assert(strPin.Length == 15 || strPin.Length == 16);

			int Somma = 0;

			for (int i = 0; i < 15; ++i)
			{
				if ((i + 1) % 2 != 0)
				{
					switch (strPin[i])
					{
					case '0':
					case 'A': 
						Somma += 1; 
						break;
					case '1':
					case 'B': 
						Somma += 0; 
						break;
					case '2':
					case 'C': 
						Somma += 5; 
						break;
					case '3':
					case 'D': 
						Somma += 7; 
						break;
					case '4':
					case 'E': 
						Somma += 9; 
						break;
					case '5':
					case 'F': 
						Somma += 13; 
						break;
					case '6':
					case 'G': 
						Somma += 15; 
						break;
					case '7':
					case 'H': 
						Somma += 17; 
						break;
					case '8':
					case 'I': 
						Somma += 19; 
						break;
					case '9':
					case 'J': 
						Somma += 21; 
						break;
					case 'K': 
						Somma += 2; 
						break;
					case 'L': 
						Somma += 4; 
						break;
					case 'M': 
						Somma += 18; 
						break;
					case 'N': 
						Somma += 20; 
						break;
					case 'O': 
						Somma += 11; 
						break;
					case 'P': 
						Somma += 3; 
						break;
					case 'Q': 
						Somma += 6; 
						break;
					case 'R': 
						Somma += 8;
						break;
					case 'S': 
						Somma += 12; 
						break;
					case 'T': 
						Somma += 14; 
						break;
					case 'U': 
						Somma += 16; 
						break;
					case 'V': 
						Somma += 10; 
						break;
					case 'W': 
						Somma += 22; 
						break;
					case 'X': 
						Somma += 25; 
						break;
					case 'Y': 
						Somma += 24; 
						break;
					case 'Z': 
						Somma += 23; 
						break;
					}
				}
				else
				{
					switch (strPin[i])
					{
					case '0':
					case 'A':
						Somma += 0;
						break;
					case '1': 
					case 'B':
						Somma += 1;
						break;
					case '2': 
					case 'C':
						Somma += 2;
						break;
					case '3': 
					case 'D':
						Somma += 3;
						break;
					case '4': 
					case 'E':
						Somma += 4;
						break;
					case '5': 
					case 'F':
						Somma += 5;
						break;
					case '6': 
					case 'G':
						Somma += 6;
						break;
					case '7': 
					case 'H':
						Somma += 7;
						break;
					case '8': 
					case 'I':
						Somma += 8;
						break;
					case '9': 
					case 'J':
						Somma += 9;
						break;
					case 'K':
						Somma += 10;
						break;
					case 'L':
						Somma += 11;
						break;
					case 'M':
						Somma += 12;
						break;
					case 'N':
						Somma += 13;
						break;
					case 'O':
						Somma += 14;
						break;
					case 'P':
						Somma += 15;
						break;
					case 'Q':
						Somma += 16;
						break;
					case 'R':
						Somma += 17;
						break;
					case 'S':
						Somma += 18;
						break;
					case 'T':
						Somma += 19;
						break;
					case 'U':
						Somma += 20;
						break;
					case 'V':
						Somma += 21;
						break;
					case 'W':
						Somma += 22;
						break;
					case 'X':
						Somma += 23;
						break;
					case 'Y':
						Somma += 24;
						break;
					case 'Z':
						Somma += 25;
						break;
					}
				}
			}
                
			Somma %= 26;
    
			char chrControllo = '\0';
			switch (Somma)
			{
			case 0:
				chrControllo = 'A'; 
				break;
			case 1:
				chrControllo = 'B'; 
				break;
			case 2:
				chrControllo = 'C'; 
				break;
			case 3:
				chrControllo = 'D'; 
				break;
			case 4:
				chrControllo = 'E'; 
				break;
			case 5:
				chrControllo = 'F'; 
				break;
			case 6:
				chrControllo = 'G'; 
				break;
			case 7:
				chrControllo = 'H'; 
				break;
			case 8:
				chrControllo = 'I'; 
				break;
			case 9:
				chrControllo = 'J'; 
				break;
			case 10:
				chrControllo = 'K'; 
				break;
			case 11:
				chrControllo = 'L'; 
				break;
			case 12:
				chrControllo = 'M'; 
				break;
			case 13:
				chrControllo = 'N'; 
				break;
			case 14:
				chrControllo = 'O'; 
				break;
			case 15:
				chrControllo = 'P'; 
				break;
			case 16:
				chrControllo = 'Q'; 
				break;
			case 17:
				chrControllo = 'R'; 
				break;
			case 18:
				chrControllo = 'S'; 
				break;
			case 19:
				chrControllo = 'T';
				break;
			case 20:
				chrControllo = 'U';
				break;
			case 21:
				chrControllo = 'V'; 
				break;
			case 22:
				chrControllo = 'W'; 
				break;
			case 23:
				chrControllo = 'X'; 
				break;
			case 24:
				chrControllo = 'Y'; 
				break;
			case 25:
				chrControllo = 'Z'; 
				break;
			}
    
			return chrControllo;
		}
	}
}
