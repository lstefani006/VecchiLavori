using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPMercato.
	/// </summary>
	public class BLOPMercato : CVRemotingBase, IBLOPMercato
	{
		public BLOPMercato()
		{
		}

		public int	AddAcquisto(InfoOffertaAcquisto OfferteAcquisto, string Firma, out string IdOfferta)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					// Inizializzo la variabile di uscita
					IdOfferta = "";

					// Creo gli oggetti di BL che mi servono
					BLOPOfferte blopOfferte = new BLOPOfferte();
					BLOPOfferteVendita blopOfferteVendita = new BLOPOfferteVendita();
					BLOPSocieta blopSocieta = new BLOPSocieta();

					// Creo gli oggetti di DL che mi servono
					DLOPMercato dlopMercato = new DLOPMercato(dbTran);
					DLOPOffertaAcquisto dlopOffertaAcquisto = new DLOPOffertaAcquisto(dbTran);
					int result = 0;

					if (OfferteAcquisto.PrezzoUnitario == 0)
					{
						// trovo il numero dell offerte di vendita sottomesse da societa diverse da quella dell'utente che 
						// sta facendo questa offerta di acquisto.
						decimal count = blopOfferteVendita._GetCount(dbTran, OfferteAcquisto.IdSessione, OfferteAcquisto.IdUtente, OfferteAcquisto.AnnoRiferimento);
						if (count > 0)
						{
							decimal disponibilita = blopSocieta._GetDisponibilitaAcquisto(dbTran, OfferteAcquisto.IdSessione, OfferteAcquisto.IdUtente);
							if (disponibilita >= OfferteAcquisto.QtyRichiesta)
							{
								bool ret = dlopMercato.AddAcquisto(OfferteAcquisto, Firma, ref IdOfferta);
								if (!ret)
								{
									result = -1;
								}
								else
								{
									dlopOffertaAcquisto.UpdateQtyImpegnata(OfferteAcquisto.IdUtente, OfferteAcquisto.IdSessione, OfferteAcquisto.QtyRichiesta, "Maggiorata");
									int ris = blopOfferte._Abbinamento(dbTran, "Acquisto", IdOfferta, OfferteAcquisto.IdUtente);
									// 0  = Tutto Ok
									// -5 = Offerta totalmente incompatibile
									// -6 = Offerta parzialmente incompatibile
									if (ris != 0) result = ris ;
								}
							}
							else
							{
								// Quantit� non acquistabile
								result = -2;
							}
						}
						else
						{
							// non ci sono offerte di vendita per soddisfare l'acquisto corrente.

							// Impossibile inserire un'offerta di acquisto
							return -3;	
						}
					}
					else
					{
						decimal disponibilita = blopSocieta._GetDisponibilitaAcquisto(dbTran, OfferteAcquisto.IdSessione, OfferteAcquisto.IdUtente);
						if (disponibilita >= OfferteAcquisto.QtyRichiesta)
						{
							bool ret = dlopMercato.AddAcquisto(OfferteAcquisto, Firma, ref IdOfferta);
							if (!ret)
							{
								result = -1;
							}
							else
							{
								dlopOffertaAcquisto.UpdateQtyImpegnata(OfferteAcquisto.IdUtente, OfferteAcquisto.IdSessione, OfferteAcquisto.QtyRichiesta, "Maggiorata");
								int ris = blopOfferte._Abbinamento(dbTran, "Acquisto", IdOfferta, OfferteAcquisto.IdUtente);
								// 0  = Tutto Ok
								// -5 = Offerta totalmente incompatibile
								// -6 = Offerta parzialmente incompatibile
								if (ris != 0) result = ris ;
							}
						}
						else
						{
							// Quantit� non acquistabile
							result = -2;
						}
					}
					dbTran.Commit();
					return result;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public int AddVendita(InfoOffertaVendita OfferteVendita, string Firma, out string IdOfferta)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					// Inizializzo la variabile di uscita
					IdOfferta = ""; 

					// Creo gli oggetti di BL che mi servono
					BLOPOfferte blopOfferte = new BLOPOfferte();
					BLOPOfferteAcquisto blopOfferteAcquisto = new BLOPOfferteAcquisto();
					BLOPSocieta blopSocieta = new BLOPSocieta();

					// Creo gli oggetti di DL che mi servono
					DLOPMercato dlopMercato = new DLOPMercato(dbTran);
					DLOPOffertaVendita dlopOffertaVendita = new DLOPOffertaVendita(dbTran);
					int result = 0;

					if (OfferteVendita.PrezzoUnitario == 0)
					{
						decimal count = blopOfferteAcquisto._GetCount(dbTran, OfferteVendita.IdSessione, OfferteVendita.IdUtente, OfferteVendita.AnnoRiferimento);
						if (count > 0)
						{
							decimal disponibilita = blopSocieta._GetDisponibilitaVendita(dbTran, OfferteVendita.IdSessione, OfferteVendita.IdUtente, OfferteVendita.AnnoRiferimento);
							if (disponibilita >= OfferteVendita.QtyOfferta)
							{
								bool ret = dlopMercato.AddVendita(OfferteVendita, Firma, ref IdOfferta);
								if (!ret)
								{
									result = -1;
								}
								else
								{
									dlopOffertaVendita.UpdateQtyImpegnata(OfferteVendita.IdUtente, OfferteVendita.IdSessione, OfferteVendita.QtyOfferta, OfferteVendita.AnnoRiferimento,  "Maggiorata");
									int ris = blopOfferte._Abbinamento(dbTran, "Vendita", IdOfferta, OfferteVendita.IdUtente);
									// 0  = Tutto Ok
									// -5 = Offerta totalmente incompatibile
									// -6 = Offerta parzialmente incompatibile
									if (ris != 0) result = ris ;
								}
							}
							else
							{
								// Quantit� non acquistabile
								result = -2;
							}
						}
						else
						{
							// Impossibile inserire un'offerta di vendita
							return -3;	
						}
					}
					else
					{
						decimal disponibilita = blopSocieta._GetDisponibilitaVendita(dbTran, OfferteVendita.IdSessione, OfferteVendita.IdUtente, OfferteVendita.AnnoRiferimento);
						if (disponibilita >= OfferteVendita.QtyOfferta)
						{
							bool ret = dlopMercato.AddVendita(OfferteVendita, Firma, ref IdOfferta);
							if (!ret)
							{
								result = -1;
							}
							else
							{
								dlopOffertaVendita.UpdateQtyImpegnata(OfferteVendita.IdUtente, OfferteVendita.IdSessione, OfferteVendita.QtyOfferta, OfferteVendita.AnnoRiferimento,  "Maggiorata");
								int ris = blopOfferte._Abbinamento(dbTran, "Vendita", IdOfferta, OfferteVendita.IdUtente);
								// 0  = Tutto Ok
								// -5 = Offerta totalmente incompatibile
								// -6 = Offerta parzialmente incompatibile
								if (ris != 0) result = ris ;
							}
						}
						else
						{
							// Quantit� non acquistabile
							result = -2;
						}
					}
					dbTran.Commit();
					return result;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetBookAcquisto(string IdSessione, string AnnoRiferimento)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPMercato dl = new DLOPMercato(dbTran);
					DataSet ds = dl.GetBookAcquisto(IdSessione, AnnoRiferimento);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetBookVendita(string IdSessione, string AnnoRiferimento)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPMercato dl = new DLOPMercato(dbTran);
					DataSet ds = dl.GetBookVendita(IdSessione, AnnoRiferimento);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		public DataSet GetMwCertificateList()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPMercato dl = new DLOPMercato(dbTran);
					DataSet ds = dl.GetMwCertificateList();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
	}
}
