using System;
using System.Data;
using System.Xml;
using System.Data.OleDb;
using System.Configuration;

namespace CV.Op
{
	/// <summary>
	/// Classe base dalla quale devono derivare tutte le classi appartenente al DL.
	/// Espone verso la BL le interfaccie IDbConnection e IdbTransaction in modo che
	/// variando il DB (e la DL di conseguenza) la BL non debba essere modificata.
	/// </summary>
	internal class DLOPBase
	{
		/// <summary>
		/// Ritorna il numero di MWh per certificato verde.
		/// Attualmente` e` 50. Configurabile nell'app.config dei server della BL.
		/// </summary>
		/// 
		public static decimal MWhPerCVletto = -1;
		public static decimal MWhPerCV
		{
			get
			{	
				/* PARTE VECCHIA
					string s = ConfigurationSettings.AppSettings["MWhPerCV"];
					return XmlConvert.ToDecimal(s) ; // un numero in virgola mobile nel file app.config deve essere es 50.32
				*/

				// Verifico se MWhPerCV non sia mai stata valorizzata
				if (MWhPerCVletto < 0)
				{
					/* IO L'AVREI FATTO COSI`......
					//Devo valorizzare MWhPerCV, e` la prima volta...
					string ConnStr = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringWeb"];;
					OleDbConnection myCon = new OleDbConnection(ConnStr);
					myCon.Open();
					string strSqlQuery = @"SELECT VALORE FROM MCVSYS.PARAMETRI WHERE (IDPARAMETRO = 'MWhPerCV')";
					OleDbCommand myCom = new OleDbCommand(strSqlQuery,myCon);
					OleDbDataReader myReader = myCom.ExecuteReader();
					string s= "-1" ;
					if (myReader.Read())
						s = myReader.GetString(0) ;
					MWhPerCVletto = XmlConvert.ToDecimal(s);
					myReader.Close() ;
					myCon.Close() ;
					*/

					using (IDbConnection cn = DLOPCommon.GetDBConnection())
					{
						string strSqlQuery = @"SELECT VALORE FROM MCVSYS.PARAMETRI WHERE (IDPARAMETRO = 'MWhPerCV')";
						cn.Open();
						IDbTransaction dbTran = cn.BeginTransaction() ;
						using (OleDbDataAdapter da = new OleDbDataAdapter())
						{
							DataSet ds = new DataSet("dsParametri");
							OleDbCommand selectCMD = new OleDbCommand(strSqlQuery,(OleDbConnection)cn,(OleDbTransaction) dbTran );
							da.SelectCommand = selectCMD;
							da.Fill(ds, "Parametri");
							DataTable dt = ds.Tables["Parametri"];
							if (dt.Rows.Count != 0)
								if (!dt.Rows[0].IsNull("Valore"))
									MWhPerCVletto = XmlConvert.ToDecimal((string)dt.Rows[0]["Valore"]);
						}
						cn.Close();
					}
				}
				//Se il valore contenuto e` valido lo ritorno, altrimenti.... 50! 
				if (MWhPerCVletto >= 0)
					return MWhPerCVletto ; 
				else
					return 50 ; //debuggare!!
			}
		}
		/// <summary>
		/// Variabile contenente l'oggetto Transazione corrente.
		/// Tutte le Classi che derivano da questa DEVONO avere un oggetto Transazione
		/// in modo da poter effettuare le query in modo sicuro.
		/// </summary>
		protected OleDbTransaction m_Transaction = null;

		/// <summary>
		/// Costruttore della classe base per il DL.
		/// </summary>
		/// <param name="dbTransaction">
		/// Parametro contenente la transazione attiva sul DataBase
		/// </param>
		public DLOPBase(IDbTransaction dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}
		/// <summary>
		/// Funzione che permette di recuperare la data di sistema del DataBase
		/// utile a tutte le classi del DL.
		/// </summary>
		/// <returns>La Data di sistema del DataBase</returns>
		public DateTime GetDBSystemDate()
		{
			return DLOPCommon.GetDBSystemDate(m_Transaction);
		}

		public static string Encrypt(string s)
		{
			if (DoCrypt())
				return _sa.Encrypt(s);
			return s;

		}
		public static string Decrypt(string s)
		{
			if (DoCrypt())
				return _sa.Decrypt(s);
			return s;
		}
		static private bool DoCrypt()
		{
			if (_bFirstTime == false)
				return _sa != null;

			_bFirstTime = false;

			string s = ConfigurationSettings.AppSettings["Login.Crypt.Password"];
			if (s != null)
			{
				s = s.ToLower();
				if (s == "true" || s == "yes" || s == "si" || s == "1")
					_sa = new CVCommon.SimmetricEncryptDecrypt(new System.Security.Cryptography.RijndaelManaged(), 256, "apotoliga");
			}
			return _sa != null;
		}
		private static bool _bFirstTime = true;
		private static CVCommon.SimmetricEncryptDecrypt _sa = null;
	}
}
