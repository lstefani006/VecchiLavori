using System;
using System.Data;
using System.Runtime.Remoting;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPCommon.
	/// </summary>
	public class BLOPCommon : CVRemotingBase, IBLOPCommon
	{
		/// <summary>
		/// Funzione di utilita' che ritorna la Data di sistema del DataBase.
		/// Tutte le pagine ASPX si devono appoggiare su questa funzione per 
		/// recuperare la data. In questo modo esistera' un unico punto di riferimento
		/// per tutte le pagine Web.
		/// </summary>
		/// <returns>La Data di sistema del DataBase</returns>
		public DateTime GetDBSystemDate()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DateTime dbSystemDate = DLOPCommon.GetDBSystemDate(dbTran);
					dbTran.Commit();
					return dbSystemDate;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		public bool ContrattaCVAnnoMin(int Month, out int AnnoMin, out int AnnoMax)
		{
			return DLOPCommon.ContrattaCVAnnoMin(Month, out AnnoMin, out AnnoMax);
		}
	}
}
