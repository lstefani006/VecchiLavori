using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPMercato.
	/// </summary>
	internal class DLOPMercato : DLOPBase
	{
		public DLOPMercato(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public bool	AddAcquisto(InfoOffertaAcquisto OfferteAcquisto, string Firma, ref string IdOfferta)
		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_OffertaAcquisto_Add", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// Quantita' Richiesta (input)
//			OleDbParameter parQtyRichiesta = new OleDbParameter("@QtyRichiesta", OleDbType.Decimal);
//			parQtyRichiesta.Direction = ParameterDirection.Input;
//			parQtyRichiesta.IsNullable = false;
//			parQtyRichiesta.Value = OfferteAcquisto.QtyRichiesta;
//			callspCMD.Parameters.Add(parQtyRichiesta);
//
//			// Quantita' Residua (input)
//			OleDbParameter parQtyResidua = new OleDbParameter("@QtyResidua", OleDbType.Decimal);
//			parQtyResidua.Direction = ParameterDirection.Input;
//			parQtyResidua.IsNullable = false;
//			parQtyResidua.Value = OfferteAcquisto.QtyRichiesta;
//			callspCMD.Parameters.Add(parQtyResidua);
//
//			// Anno Riferimento (input)
//			OleDbParameter parAnnoRiferimento = new OleDbParameter("@AnnoRiferimento", OleDbType.VarChar, 4);
//			parAnnoRiferimento.Direction = ParameterDirection.Input;
//			parAnnoRiferimento.IsNullable = false;
//			parAnnoRiferimento.Value = OfferteAcquisto.AnnoRiferimento;
//			callspCMD.Parameters.Add(parAnnoRiferimento);
//
//			// Prezzo Unitario (input)
//			OleDbParameter parPrezzoUnitario = new OleDbParameter("@PrezzoUnitario", OleDbType.Decimal);
//			parPrezzoUnitario.Direction = ParameterDirection.Input;
//			parPrezzoUnitario.IsNullable = false;
//			parPrezzoUnitario.Value = OfferteAcquisto.PrezzoUnitario;
//			callspCMD.Parameters.Add(parPrezzoUnitario);
//
//			// ID Utente (input)
//			OleDbParameter parIDUtente = new OleDbParameter("@IDUtente", OleDbType.VarChar, 32);
//			parIDUtente.Direction = ParameterDirection.Input;
//			parIDUtente.IsNullable = false;
//			parIDUtente.Value = OfferteAcquisto.IdUtente;
//			callspCMD.Parameters.Add(parIDUtente);
//
//			// ID Sessione (input)
//			OleDbParameter parIDSessione = new OleDbParameter("@IDSessione", OleDbType.VarChar, 32);
//			parIDSessione.Direction = ParameterDirection.Input;
//			parIDSessione.IsNullable = false;
//			parIDSessione.Value = OfferteAcquisto.IdSessione;
//			callspCMD.Parameters.Add(parIDSessione);
//
//			// ID Acquisto (output)
//			OleDbParameter parIdAcquisto = new OleDbParameter("@IdAcquisto", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
//			parIdAcquisto.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parIdAcquisto);
//
//			// ID Log (output)
//			OleDbParameter parIdLog = new OleDbParameter("@IdLog", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
//			parIdLog.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parIdLog);
//
//			callspCMD.ExecuteNonQuery();
//			
//			// Devo inserire il campo BLOB: poiche' le Stored Procedures non possono farlo
//			// lo faccio io a mano.
//			string IdLog = callspCMD.Parameters["@IdLog"].Value.ToString();
//			string strSqlQuery = "UPDATE CV.LogOfferteAcquisto SET Firma=? WHERE IdLog = HEXTORAW(?)";
//			
//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
//			insertCMD.ExecuteNonQuery();
//
//			IdOfferta = callspCMD.Parameters["@IdAcquisto"].Value.ToString();
//			return true;

			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			string IdAcquisto = Guid.NewGuid().ToString("N").ToUpper();
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				// sono tutti campi NOT NULL
				cmd.CommandText = @"
				INSERT INTO cv.OfferteAcquisto
					(IdOffertaAcquisto,
					QtyRichiesta,
					QtyResidua,
					AnnoRiferimento,
					PrezzoUnitario,
					IdUtente,
					IdSessione)
				VALUES
					(HEXTORAW(?),
					?,
					?,
					?,
					?,
					HEXTORAW(?),
					HEXTORAW(?))
				";

				cmd.Parameters.Add("IdOffertaAcquisto",  OleDbType.VarChar).Value = IdAcquisto;
				cmd.Parameters.Add("in_QtyRichiesta",    OleDbType.Decimal).Value = OfferteAcquisto.QtyRichiesta;
				cmd.Parameters.Add("in_QtyResidua",      OleDbType.Decimal).Value = OfferteAcquisto.QtyRichiesta;
				cmd.Parameters.Add("in_AnnoRiferimento", OleDbType.VarChar).Value = OfferteAcquisto.AnnoRiferimento;
				cmd.Parameters.Add("in_PrezzoUnitario",  OleDbType.Decimal).Value = OfferteAcquisto.PrezzoUnitario;
				cmd.Parameters.Add("in_IdUtente",        OleDbType.VarChar).Value = OfferteAcquisto.IdUtente;
				cmd.Parameters.Add("in_IdSessione",      OleDbType.VarChar).Value = OfferteAcquisto.IdSessione;

				cmd.ExecuteNonQuery();
			}

			DLOPOffertaAcquisto.LogAcquisti(cn, tr, "Inserimento", IdAcquisto, Firma);

			IdOfferta = IdAcquisto;
			return true;
		}

		public bool	AddVendita(InfoOffertaVendita OfferteVendita, string Firma, ref string IdOfferta)
		{
//			
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_OffertaVendita_Add", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// Quantita' Offerta (input)
//			OleDbParameter parQtyOfferta = new OleDbParameter("@QtyOfferta", OleDbType.Decimal);
//			parQtyOfferta.Direction = ParameterDirection.Input;
//			parQtyOfferta.IsNullable = false;
//			parQtyOfferta.Value = OfferteVendita.QtyOfferta;
//			callspCMD.Parameters.Add(parQtyOfferta);
//
//			// Quantita' Residua (input)
//			OleDbParameter parQtyResidua = new OleDbParameter("@QtyResidua", OleDbType.Decimal);
//			parQtyResidua.Direction = ParameterDirection.Input;
//			parQtyResidua.IsNullable = false;
//			parQtyResidua.Value = OfferteVendita.QtyOfferta;
//			callspCMD.Parameters.Add(parQtyResidua);
//
//			// Anno Riferimento (input)
//			OleDbParameter parAnnoRiferimento = new OleDbParameter("@AnnoRiferimento", OleDbType.VarChar, 4);
//			parAnnoRiferimento.Direction = ParameterDirection.Input;
//			parAnnoRiferimento.IsNullable = false;
//			parAnnoRiferimento.Value = OfferteVendita.AnnoRiferimento;
//			callspCMD.Parameters.Add(parAnnoRiferimento);
//
//			// Prezzo Unitario (input)
//			OleDbParameter parPrezzoUnitario = new OleDbParameter("@PrezzoUnitario", OleDbType.Decimal);
//			parPrezzoUnitario.Direction = ParameterDirection.Input;
//			parPrezzoUnitario.IsNullable = false;
//			parPrezzoUnitario.Value = OfferteVendita.PrezzoUnitario;
//			callspCMD.Parameters.Add(parPrezzoUnitario);
//
//			// ID Utente (input)
//			OleDbParameter parIDUtente = new OleDbParameter("@IDUtente", OleDbType.VarChar, 32);
//			parIDUtente.Direction = ParameterDirection.Input;
//			parIDUtente.IsNullable = false;
//			parIDUtente.Value = OfferteVendita.IdUtente;
//			callspCMD.Parameters.Add(parIDUtente);
//
//			// ID Sessione (input)
//			OleDbParameter parIDSessione = new OleDbParameter("@IDSessione", OleDbType.VarChar, 32);
//			parIDSessione.Direction = ParameterDirection.Input;
//			parIDSessione.IsNullable = false;
//			parIDSessione.Value = OfferteVendita.IdSessione;
//			callspCMD.Parameters.Add(parIDSessione);
//
//			// ID Vendita (output)
//			OleDbParameter parIdVendita = new OleDbParameter("@IdVendita", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
//			parIdVendita.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parIdVendita);
//
//			// ID Log (output)
//			OleDbParameter parIdLog = new OleDbParameter("@IdLog", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
//			parIdLog.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parIdLog);
//
//			callspCMD.ExecuteNonQuery();
//			
//			string IdLog = callspCMD.Parameters["@IdLog"].Value.ToString();
//			string strSqlQuery = "UPDATE CV.LogOfferteVendita SET Firma=? WHERE IdLog = HEXTORAW(?)";
//			
//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
//			insertCMD.ExecuteNonQuery();
//
//			IdOfferta = callspCMD.Parameters["@IdVendita"].Value.ToString();
//			return true;


			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			string IdVendita = Guid.NewGuid().ToString("N").ToUpper();
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				// sono tutti campi NOT NULL
				cmd.CommandText = @"
				INSERT INTO cv.OfferteVendita
					(IdOffertaVendita,
					QtyOfferta,
					QtyResidua,
					AnnoRiferimento,
					PrezzoUnitario,
					IdUtente,
					IdSessione)
				VALUES
					(HEXTORAW(?),
					?,
					?,
					?,
					?,
					HEXTORAW(?),
					HEXTORAW(?))
				";

				cmd.Parameters.Add("IdOffertaVendita",   OleDbType.VarChar).Value = IdVendita;
				cmd.Parameters.Add("in_QtyOfferta",      OleDbType.Decimal).Value = OfferteVendita.QtyOfferta;
				cmd.Parameters.Add("in_QtyResidua",      OleDbType.Decimal).Value = OfferteVendita.QtyOfferta;
				cmd.Parameters.Add("in_AnnoRiferimento", OleDbType.VarChar).Value = OfferteVendita.AnnoRiferimento;
				cmd.Parameters.Add("in_PrezzoUnitario",  OleDbType.Decimal).Value = OfferteVendita.PrezzoUnitario;
				cmd.Parameters.Add("in_IdUtente",        OleDbType.VarChar).Value = OfferteVendita.IdUtente;
				cmd.Parameters.Add("in_IdSessione",      OleDbType.VarChar).Value = OfferteVendita.IdSessione;

				cmd.ExecuteNonQuery();
			}

			DLOPOffertaVendita.LogVendita(cn, tr, "Inserimento", IdVendita, Firma);

			IdOfferta = IdVendita;
			return true;
		}

		public DataSet GetBookAcquisto(string IdSessione, string AnnoRiferimento)
		{
			string strSqlQuery = "SELECT SUM(QtyRichiesta) AS QtyRichiesta, SUM(QtyResidua) AS QtyResidua, " + 
								 "AnnoRiferimento, PrezzoUnitario FROM cv.OfferteAcquisto " +
								 "WHERE  IdSessione = HEXTORAW(?) " +
								 "AND AnnoRiferimento LIKE ? " +
								 "AND QtyResidua <> 0 " +
								 "AND PrezzoUnitario <> 0 " +
								 "AND Compatibile <> 0 " +
								 "GROUP BY PrezzoUnitario, AnnoRiferimento " +
								 "ORDER BY PrezzoUnitario DESC";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 33).Value = IdSessione;
				selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento + "%";

				DataSet ds = new DataSet("dsBookAcquisto");
				da.Fill(ds, "BookAcquisto");
				return ds;
			}
		}

		public DataSet GetBookVendita(string IdSessione, string AnnoRiferimento)
		{
			string strSqlQuery = "SELECT SUM(QtyOfferta) AS QtyOfferta, SUM(QtyResidua) AS QtyResidua, AnnoRiferimento, PrezzoUnitario " +
								 "FROM cv.OfferteVendita " +
								 "WHERE  IdSessione = HEXTORAW(?) " +
								 "AND AnnoRiferimento LIKE ? " +
								 "AND QtyResidua <> 0 " +
								 "AND PrezzoUnitario <> 0 " +
								 "AND Compatibile <> 0 " +
								 "GROUP BY PrezzoUnitario, AnnoRiferimento " +
								 "ORDER BY PrezzoUnitario ASC";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 33).Value = IdSessione;
				selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento + "%";
				DataSet ds = new DataSet("dsBookVendita");
				da.Fill(ds, "BookVendita");
				return ds;
			}
		}

		public DataSet GetMwCertificateList()
		{
#if VECCHIO_MWCERTIFICATO
			string strSqlQuery = "SELECT Anno, QtyMwh " + 
								 "FROM CV.MwCertificato ORDER BY Anno ASC"; // StePuntoAperto

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				DataSet ds = new DataSet("dsMwCertificateList");
				da.Fill(ds, "MwCertificateList");
				return ds;
			}
#endif
			// per tranquillita` ritorno l'annoMin cose se fossi sempre a Gennaio (1)
			// (comunque il +1 sull'anno min dovrei fare la somma a +1 qui).
			int annoMin, annoMax;
			DLOPCommon.ContrattaCVAnnoMin(1, out annoMin, out annoMax);
			DataSet ds = new DataSet("dsMwCertificateList");
			DataTable dt = ds.Tables.Add("MwCertificateList");
			dt.Columns.Add("Anno", typeof(string));
			dt.Columns.Add("QtyMWh", typeof(int));

			for (int a = annoMin; a <= annoMax; a++)
				dt.Rows.Add(new object [2] {a.ToString() , (int)DLOPBase.MWhPerCV });

			return ds;
		}
	}
}
