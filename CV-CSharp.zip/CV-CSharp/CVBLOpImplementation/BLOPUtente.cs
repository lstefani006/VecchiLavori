using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPUtente.
	/// </summary>
	public class BLOPUtente : CVRemotingBase, IBLOPUtente
	{
		public BLOPUtente()
		{
		}

		public InfoUtente GetIdUtente(string CommonName)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPUtente dl = new DLOPUtente(dbTran);
					InfoUtente info = dl.GetIdUtente(CommonName);
					dbTran.Commit();
					return info;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public bool IsPINValid(string pin)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPUtente utente = new DLOPUtente(dbTran);
					bool isPinValid = utente.IsPINValid(pin);
					dbTran.Commit();
					return isPinValid;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public string GetIdRicRegSoc(string CodiceConto)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSocieta dl = new DLOPSocieta(dbTran);
					string Id = dl.GetIdRicRegSoc(CodiceConto);
					dbTran.Commit();
					return Id;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public bool Registra(string IdRichiestaRegSoc, ref InfoUtente infoU)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					bool registrazioneOK = _Registra(dbTran, IdRichiestaRegSoc, ref infoU);
					dbTran.Commit();
					return registrazioneOK;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal bool _Registra(IDbTransaction dbTran, string IdRichiestaRegSoc, ref InfoUtente infoU)
		{
			DLOPUtente utente = new DLOPUtente(dbTran);
			string idUtente = utente.Insert(IdRichiestaRegSoc, infoU);
			if (idUtente.Length != 0)
			{
				infoU.IdUtente = idUtente;
				infoU.IdUtenteIsNull = false;
			}
			else
			{
				infoU.IdUtente = "";
				infoU.IdUtenteIsNull = true;
			}

			bool registrato = (idUtente.Length == 0?false:true);
			return registrato;
		}
	}
}
