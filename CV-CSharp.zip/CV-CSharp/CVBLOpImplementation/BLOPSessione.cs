using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPSessione.
	/// </summary>
	public class BLOPSessione : CVRemotingBase, IBLOPSessione
	{
		/// <summary>
		/// Ritorna il numero di MWh per certificato verde.
		/// Attualmente` e` 50. Configurabile nell'app.config dei server della BL.
		/// </summary>
		public decimal MWhPerCV
		{
			get { return DLOPBase.MWhPerCV; }
		}


		public BLOPSessione()
		{
		}

		public DataSet GetLst()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSessione dl = new DLOPSessione(dbTran);
					DataSet ds = dl.GetLista();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public bool	IsEnabled(string IdSessione)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSessione dl = new DLOPSessione(dbTran);
					bool isSessionEnabled = dl.IsEnabled(IdSessione);
					dbTran.Commit();
					return isSessionEnabled;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetCurrentWebSession()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSessione dl = new DLOPSessione(dbTran);
					DataSet ds = dl.GetCurrentWebSession();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetCurrentWebSession2()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSessione dl = new DLOPSessione(dbTran);
					DataSet ds = dl.GetCurrentWebSession2();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetDatiSession(string IdSessione)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSessione dl = new DLOPSessione(dbTran);
					DataSet ds = dl.GetDatiSession(IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		/// <summary>
		/// Prima sessione in stato in Attesa
		/// </summary>
		/// <returns></returns>
		public DataSet GetProssimaSessioneInAttesa()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSessione dl = new DLOPSessione(dbTran);
					DataSet ds = dl.GetProssimaSessioneInAttesa();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetProssimaSessionePredisposta()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSessione dl = new DLOPSessione(dbTran);
					DataSet ds = dl.GetProssimaSessionePredisposta();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetSessioneAperta()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DataSet ds = this.GetSessioneAperta(tr);
					tr.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
		internal DataSet GetSessioneAperta(IDbTransaction tr)
		{
			DLOPSessione dl = new DLOPSessione(tr);
			DataSet ds = dl.GetSessioneAperta();
			return ds;
		}


	}
}
