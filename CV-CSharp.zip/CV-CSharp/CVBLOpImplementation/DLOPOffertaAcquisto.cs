using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPOffertaAcquisto.
	/// </summary>
	internal class DLOPOffertaAcquisto : DLOPBase
	{
		public DLOPOffertaAcquisto(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public void Delete(string IdOffertaAcquisto, string Firma)
		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_OffertaAcquisto_Delete", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// ID Offerta Acquisto (input)
//			OleDbParameter parIdOffertaAcquisto = new OleDbParameter("@IDOffertaAcquisto", OleDbType.VarChar, 32);
//			parIdOffertaAcquisto.Direction = ParameterDirection.Input;
//			parIdOffertaAcquisto.IsNullable = false;
//			parIdOffertaAcquisto.Value = IdOffertaAcquisto;
//			callspCMD.Parameters.Add(parIdOffertaAcquisto);
//
//			// ID Log (output)
//			OleDbParameter parIdLog = new OleDbParameter("@IDLog", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
////			parIdLog.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parIdLog);
//
//			callspCMD.ExecuteNonQuery();
//
//			string IdLog = callspCMD.Parameters["@IDLog"].Value.ToString();
//			string strSqlQuery = "UPDATE CV.LogOfferteAcquisto SET Firma = ? WHERE IdLog = HEXTORAW(?)";
//			
//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
//			insertCMD.ExecuteNonQuery();
//
//			return;
			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			LogAcquisti(cn, tr, "Cancellazione", IdOffertaAcquisto, Firma);

			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
				DELETE FROM cv.OfferteAcquisto 
				WHERE IdOffertaAcquisto = HEXTORAW(?)
				";
				cmd.Parameters.Add("IdOffertaAcquisto", OleDbType.VarChar).Value = IdOffertaAcquisto;
				cmd.ExecuteNonQuery();
			}
		}

		public void DeleteIncompatible(string IdOffertaAcquisto, string Firma)
		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_OffertaAcquisto_Delete", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// ID Offerta Acquisto (input)
//			OleDbParameter parIdOffertaAcquisto = new OleDbParameter("@IDOffertaAcquisto", OleDbType.VarChar, 32);
//			parIdOffertaAcquisto.Direction = ParameterDirection.Input;
//			parIdOffertaAcquisto.IsNullable = false;
//			parIdOffertaAcquisto.Value = IdOffertaAcquisto;
//			callspCMD.Parameters.Add(parIdOffertaAcquisto);
//
//			// ID Log (output)
//			OleDbParameter parIdLog = new OleDbParameter("@IDLog", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
////			parIdLog.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parIdLog);
//
//			callspCMD.ExecuteNonQuery();
//
//			string IdLog = callspCMD.Parameters["@IDLog"].Value.ToString();
//			string strSqlQuery = "UPDATE CV.LogOfferteAcquisto SET Firma= ? WHERE IdLog = HEXTORAW(?)";
//			
//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
//			insertCMD.ExecuteNonQuery();
//
//			return;

			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			LogAcquisti(cn, tr, "Cancellazione", IdOffertaAcquisto, Firma);

			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
				DELETE FROM cv.OfferteAcquisto 
				WHERE IdOffertaAcquisto = HEXTORAW(?)
				";
				cmd.Parameters.Add("IdOffertaAcquisto", OleDbType.VarChar).Value = IdOffertaAcquisto;
				cmd.ExecuteNonQuery();
			}
		}

		public decimal Modifica(string IdOffertaAcquisto, decimal NuovoPrezzo, decimal NuovaQtyResidua, decimal OldQtyResidua, string Firma)
		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_OffertaAcquisto_Upd", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// ID Offerta Acquisto (input)
//			OleDbParameter parIdOffertaAcquisto = new OleDbParameter("@IDOffertaAcquisto", OleDbType.VarChar, 32);
//			parIdOffertaAcquisto.Direction = ParameterDirection.Input;
//			parIdOffertaAcquisto.IsNullable = false;
//			parIdOffertaAcquisto.Value = IdOffertaAcquisto;
//			callspCMD.Parameters.Add(parIdOffertaAcquisto);
//
//			// Nuovo Prezzo (input)
//			OleDbParameter parNuovoPrezzo = new OleDbParameter("@NuovoPrezzo", OleDbType.Decimal);
//			parNuovoPrezzo.Direction = ParameterDirection.Input;
//			parNuovoPrezzo.IsNullable = false;
//			parNuovoPrezzo.Value = NuovoPrezzo;
//			callspCMD.Parameters.Add(parNuovoPrezzo);
//
//			// Nuova Quantita' Residua (input)
//			OleDbParameter parNuovaQtyResidua = new OleDbParameter("@NuovaQtyResidua", OleDbType.Decimal);
//			parNuovaQtyResidua.Direction = ParameterDirection.Input;
//			parNuovaQtyResidua.IsNullable = false;
//			parNuovaQtyResidua.Value = NuovaQtyResidua;
//			callspCMD.Parameters.Add(parNuovaQtyResidua);
//
//			// Old Quantita' Residua (input)
//			OleDbParameter parOldQtyResidua = new OleDbParameter("@OldQtyResidua", OleDbType.Decimal);
//			parOldQtyResidua.Direction = ParameterDirection.Input;
//			parOldQtyResidua.IsNullable = false;
//			parOldQtyResidua.Value = OldQtyResidua;
//			callspCMD.Parameters.Add(parOldQtyResidua);
//
//			// Return Value (output)
//			OleDbParameter parRetVal = new OleDbParameter("@RetVal", OleDbType.Decimal);
//			parRetVal.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parRetVal);
//
//			// ID Log (output)
//			OleDbParameter parIdLog = new OleDbParameter("@IdLog", OleDbType.VarChar, 32, ParameterDirection.Output, false, 0,0,null,DataRowVersion.Default, null);
////			parIdLog.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parIdLog);
//
//			callspCMD.ExecuteNonQuery();
//			
//			// Devo inserire il campo CLOB: poiche' le Stored Procedures non possono farlo
//			// lo faccio io a mano.
//			string IdLog = callspCMD.Parameters["@IdLog"].Value.ToString();
//			string strSqlQuery = "UPDATE CV.LogOfferteAcquisto SET Firma= ? WHERE IdLog = HEXTORAW(?)";
//			
//			OleDbCommand insertCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
//			insertCMD.Parameters.Add("@Firma", OleDbType.LongVarChar).Value = Firma;
//			insertCMD.Parameters.Add("@IdLog", OleDbType.VarChar, 32).Value = IdLog;
//			insertCMD.ExecuteNonQuery();
//
//			return (decimal)callspCMD.Parameters["@RetVal"].Value;

			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			decimal retVal = 0;

			decimal loc_OAcq_QtyRichiesta;
			decimal loc_OAcq_QtyResidua;
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
				SELECT QtyRichiesta, QtyResidua
				FROM   cv.OfferteAcquisto
				WHERE  IdOffertaAcquisto = HEXTORAW(?)
				FOR UPDATE OF QtyRichiesta
				";

				cmd.Parameters.Add("IdOffertaAcquisto", OleDbType.VarChar).Value = IdOffertaAcquisto;

				using (OleDbDataReader r = cmd.ExecuteReader())
				{
					if (r.Read() == false)
						return retVal;

					loc_OAcq_QtyRichiesta = (decimal)r[0];
					loc_OAcq_QtyResidua   = (decimal)r[1];
				}
			}
	  	    decimal loc_QtyEseguita     = loc_OAcq_QtyRichiesta - loc_OAcq_QtyResidua;
			decimal loc_NewQtyRichiesta = NuovaQtyResidua + loc_QtyEseguita;


			if (loc_OAcq_QtyResidua == 0m)
			{
				retVal = 0m; // Impossibile effettuare la modifica
			}
			else if (OldQtyResidua != loc_OAcq_QtyResidua)
			{
				retVal = 0m; // Impossibile effettuare la modifica
			}
			else
			{
				retVal = 1m; // Update effettuato

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						UPDATE cv.OfferteAcquisto
						SET QtyRichiesta = ?,
						QtyResidua = ?,
						PrezzoUnitario = ?
						WHERE IdOffertaAcquisto = HEXTORAW(?)
					";

					cmd.Parameters.Add("loc_NewQtyRichiesta", OleDbType.Decimal).Value = loc_NewQtyRichiesta;
					cmd.Parameters.Add("in_NewQtyResidua", OleDbType.Decimal).Value = NuovaQtyResidua;
					cmd.Parameters.Add("in_NewPrezzo", OleDbType.Decimal).Value = NuovoPrezzo;
					cmd.Parameters.Add("IdOffertaAcquisto", OleDbType.VarChar).Value = IdOffertaAcquisto;

					cmd.ExecuteNonQuery();
				}
			}

			LogAcquisti(cn, tr, "Modifica", IdOffertaAcquisto, Firma);

			return retVal;
		}

		public void UpdateQtyImpegnata(string IdUtente, string IdSessione, decimal QtyRichiesta, string TipoModifica)
		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_QtyImpegnataAcquisto_Upd", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// ID Utente
//			OleDbParameter parIdUtente = new OleDbParameter("@IDUtente", OleDbType.VarChar, 32);
//			parIdUtente.Direction = ParameterDirection.Input;
//			parIdUtente.IsNullable = false;
//			parIdUtente.Value = IdUtente;
//			callspCMD.Parameters.Add(parIdUtente);
//
//			// ID Sessione (input)
//			OleDbParameter parIdSessione = new OleDbParameter("@IDSessione", OleDbType.VarChar, 32);
//			parIdSessione.Direction = ParameterDirection.Input;
//			parIdSessione.IsNullable = false;
//			parIdSessione.Value = IdSessione;
//			callspCMD.Parameters.Add(parIdSessione);
//
//			// Quantita Richiesta (input)
//			OleDbParameter parQtyRichiesta = new OleDbParameter("@QtyRichiesta", OleDbType.Decimal);
//			parQtyRichiesta.Direction = ParameterDirection.Input;
//			parQtyRichiesta.IsNullable = false;
//			parQtyRichiesta.Value = QtyRichiesta;
//			callspCMD.Parameters.Add(parQtyRichiesta);
//
//			// Tipo Modifica (input)
//			OleDbParameter parTipoModifica = new OleDbParameter("@TipoModifica", OleDbType.VarChar, 32);
//			parTipoModifica.Direction = ParameterDirection.Input;
//			parTipoModifica.IsNullable = false;
//			parTipoModifica.Value = TipoModifica;
//			callspCMD.Parameters.Add(parTipoModifica);
//
//			callspCMD.ExecuteNonQuery();
//			return;

			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;

			string IdSocieta;
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
					SELECT RAWTOHEX(IdSocieta) AS IdSocieta
					FROM US.Utenti Utenti
					WHERE Utenti.IdUtente = HEXTORAW(?)
				";
				cmd.Parameters.Add("IdUtente", OleDbType.VarChar).Value = IdUtente;

				IdSocieta = (string)cmd.ExecuteScalar();
			}

			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				if (TipoModifica == "Diminuita")
				{
					cmd.CommandText = @"
					UPDATE cv.Budgets
					SET QtyImpegnata = QtyImpegnata - ?
					WHERE IdSocieta  = HEXTORAW(?)
					AND IdSessione = HEXTORAW(?)
					";
				}
				else
				{
					cmd.CommandText = @"
					UPDATE cv.Budgets
					SET QtyImpegnata = QtyImpegnata + ?
					WHERE IdSocieta  = HEXTORAW(?)
					AND IdSessione = HEXTORAW(?)
					";
				}

				cmd.Parameters.Add("in_QtyRichiesta", OleDbType.Decimal).Value = QtyRichiesta;
				cmd.Parameters.Add("IdSocieta", OleDbType.VarChar).Value = IdSocieta;
				cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;

				cmd.ExecuteNonQuery();
			}
		}

		public InfoOffertaAcquisto Get(string IdOffertaAcquisto)
		{
			string strSqlQuery = "SELECT RAWTOHEX(IdUtente) IdUtente, " + 
								 "QtyRichiesta, QtyResidua, " + 
								 "(QtyRichiesta - QtyResidua) As QtyEseguita, " + 
								 "PrezzoUnitario, AnnoRiferimento, " +
								 "RAWTOHEX(IdSessione) IdSessione, Compatibile " +
								 "FROM CV.OfferteAcquisto " +
								 "WHERE IdOffertaAcquisto = HEXTORAW(?)";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdOffertaAcquisto", OleDbType.VarChar, 32).Value = IdOffertaAcquisto;
				
				DataSet ds = new DataSet("dsInfoOffertaAcquisto");
				{
					da.Fill(ds, "InfoOffertaAcquisto");
					DataTable dt = ds.Tables["InfoOffertaAcquisto"];
					InfoOffertaAcquisto infoOA = new InfoOffertaAcquisto();
					if (dt.Rows.Count != 0)
					{
						if (!dt.Rows[0].IsNull("IdUtente"))
						{
							infoOA.IdUtente = dt.Rows[0]["IdUtente"].ToString();
							infoOA.IdUtenteIsNull = false;
						}
						else
						{
							infoOA.IdUtente = "";
							infoOA.IdUtenteIsNull = true;
						}

						if (!dt.Rows[0].IsNull("QtyRichiesta"))
						{
							infoOA.QtyRichiesta = (decimal)dt.Rows[0]["QtyRichiesta"];
							infoOA.QtyRichiestaIsNull = false;
						}
						else
						{
							infoOA.QtyRichiesta = 0M;
							infoOA.QtyRichiestaIsNull = true;
						}

						if (!dt.Rows[0].IsNull("QtyResidua"))
						{
							infoOA.QtyResidua = (decimal)dt.Rows[0]["QtyResidua"];
							infoOA.QtyResiduaIsNull = false;
						}
						else
						{
							infoOA.QtyResidua = 0M;
							infoOA.QtyResiduaIsNull = true;
						}

						if (!dt.Rows[0].IsNull("QtyEseguita"))
						{
							infoOA.QtyEseguita = (decimal)dt.Rows[0]["QtyEseguita"];
							infoOA.QtyEseguitaIsNull = false;
						}
						else
						{
							infoOA.QtyEseguita = 0M;
							infoOA.QtyEseguitaIsNull = true;
						}

						if (!dt.Rows[0].IsNull("PrezzoUnitario"))
						{
							infoOA.PrezzoUnitario = (decimal)dt.Rows[0]["PrezzoUnitario"];
							infoOA.PrezzoUnitarioIsNull = false;
						}
						else
						{
							infoOA.PrezzoUnitario = 0M;
							infoOA.PrezzoUnitarioIsNull = true;
						}

						if (!dt.Rows[0].IsNull("AnnoRiferimento"))
						{
							infoOA.AnnoRiferimento = dt.Rows[0]["AnnoRiferimento"].ToString(); 
							infoOA.AnnoRiferimentoIsNull = false;
						}
						else
						{
							infoOA.AnnoRiferimento = ""; 
							infoOA.AnnoRiferimentoIsNull = true;
						}
						
						if (!dt.Rows[0].IsNull("IdSessione"))
						{
							infoOA.IdSessione = dt.Rows[0]["IdSessione"].ToString();
							infoOA.IdsessioneIsNull = false;
						}
						else
						{
							infoOA.IdSessione = "";
							infoOA.IdsessioneIsNull = true;
						}

						if (!dt.Rows[0].IsNull("Compatibile"))
						{
							infoOA.Compatibile = (decimal)dt.Rows[0]["Compatibile"];
							infoOA.CompatibileIsNull = false;
						}
						else
						{
							infoOA.Compatibile = 0M;
							infoOA.CompatibileIsNull = true;
						}
					}
					return infoOA;
				}
			}
		}

		public static void LogAcquisti(OleDbConnection cn, OleDbTransaction tr, string TipoOperazione, string IdOffertaAcquisto, string Firma)
		{
			if (TipoOperazione != "Cancellazione")
			{
				decimal loc_QtyRichiesta;
				decimal loc_QtyResidua;
				string loc_AnnoRiferimento;
				decimal loc_PrezzoUnitario;
				DateTime loc_DataOraCreazione;
				DateTime loc_DataOraModifica;
				string loc_IdSessione;
				string loc_IdUtente;

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					// sono tutti campi NOT NULL
					cmd.CommandText = @"
					SELECT 
						QtyRichiesta, 
						QtyResidua, 
						AnnoRiferimento, 
						PrezzoUnitario, 
						DataOraCreazione, 
						DataOraModifica, 
						RAWTOHEX(IdSessione) AS IdSessione, 
						RAWTOHEX(IdUtente) AS IdUtente
					FROM   cv.OfferteAcquisto
					WHERE  IdOffertaAcquisto = HEXTORAW(?)
					";

					cmd.Parameters.Add("IdOffertaAcquisto", OleDbType.VarChar).Value = IdOffertaAcquisto;

					using (OleDbDataReader r = cmd.ExecuteReader())
					{
						if (r.Read())
						{
							loc_QtyRichiesta = (decimal)r[0];
							loc_QtyResidua = (decimal)r[1];
							loc_AnnoRiferimento = (string)r[2];
							loc_PrezzoUnitario = (decimal)r[3];
							loc_DataOraCreazione = (DateTime)r[4];
							loc_DataOraModifica = (DateTime)r[5];
							loc_IdSessione = (string)r[6];
							loc_IdUtente = (string)r[7];
						}
						else
							throw new Exception("Non trovo l'offerta di acquisto");
					}

				}

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
					INSERT INTO cv.LogOfferteAcquisto
						(IdLog,
						TipoOperazione,
						IdOffertaAcquisto,
						QtyRichiesta,
						QtyResidua,
						AnnoRiferimento,
						PrezzoUnitario,
						DataOraCreazione,
						DataOraModifica,
						IdUtente,
						IdSessione,
						Firma)
					VALUES	
						(HEXTORAW(?),
						?,
						HEXTORAW(?),
						?,
						?,
						?,
						?,
						?,
						?,
						HEXTORAW(?),
						HEXTORAW(?),
						?)
					";

					string IdLog = Guid.NewGuid().ToString("N").ToUpper();

					cmd.Parameters.Add("IdLog",            OleDbType.VarChar).Value = IdLog;
					cmd.Parameters.Add("TipoOperazione",   OleDbType.VarChar).Value = TipoOperazione;
					cmd.Parameters.Add("IdOffertaAcquisto",OleDbType.VarChar).Value = IdOffertaAcquisto;
					cmd.Parameters.Add("QtyRichiesta",     OleDbType.Decimal).Value = loc_QtyRichiesta;
					cmd.Parameters.Add("QtyResidua",       OleDbType.Decimal).Value = loc_QtyResidua;
					cmd.Parameters.Add("AnnoRiferimento",  OleDbType.VarChar).Value = loc_AnnoRiferimento; 
					cmd.Parameters.Add("PrezzoUnitario",   OleDbType.Decimal).Value = loc_PrezzoUnitario; 
					cmd.Parameters.Add("DataOraCreazione", OleDbType.DBTimeStamp).Value = loc_DataOraCreazione; 
					cmd.Parameters.Add("DataOraModifica",  OleDbType.DBTimeStamp).Value = loc_DataOraModifica; 
					cmd.Parameters.Add("IdUtente",	       OleDbType.VarChar).Value = loc_IdUtente; 
					cmd.Parameters.Add("IdSessione",       OleDbType.VarChar).Value = loc_IdSessione; 
					cmd.Parameters.Add("Firma",            OleDbType.LongVarChar).Value = Firma; 
					cmd.ExecuteNonQuery();
				}
			}
			else
			{
				string loc_IdSessione;
				string loc_IdUtente;
				DateTime loc_DataOraCreazione;
				string loc_AnnoRiferimento;
				DateTime loc_DataOraModifica;

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
				    SELECT 
						RAWTOHEX(IdSessione) AS IdSessione, 
						RAWTOHEX(IdUtente) AS IdUtente, 
						DataOraCreazione, 
						AnnoRiferimento,
						SYSDATE AS DataOraModifica
					FROM   cv.OfferteAcquisto
					WHERE  IdOffertaAcquisto = HEXTORAW(?)
					";

					cmd.Parameters.Add("IdOffertaAcquisto", OleDbType.VarChar).Value = IdOffertaAcquisto;

					using (OleDbDataReader r = cmd.ExecuteReader())
					{
						if (r.Read())
						{
							loc_IdSessione = (string)r[0];
							loc_IdUtente = (string)r[1];
							loc_DataOraCreazione = (DateTime)r[2];
							loc_AnnoRiferimento = (string)r[3];
							loc_DataOraModifica = (DateTime)r[4];
						}
						else 
							throw new Exception("Non trovo l'offerta di acquisto");
					}
				}

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
					INSERT INTO cv.LogOfferteAcquisto
						(IdLog,
						TipoOperazione,
						IdOffertaAcquisto,
						QtyRichiesta,
						QtyResidua,
						AnnoRiferimento,
						PrezzoUnitario,
						DataOraCreazione,
						DataOraModifica,
						IdUtente,
						IdSessione,
						Firma)
					VALUES	
						(HEXTORAW(?),
						?,
						HEXTORAW(?),
						NULL,
						NULL,
						?,
						NULL,
						?,
						?,
						HEXTORAW(?),
						HEXTORAW(?),
						?)
					";

					string IdLog = Guid.NewGuid().ToString("N").ToUpper();

					cmd.Parameters.Add("IdLog",            OleDbType.VarChar).Value = IdLog;
					cmd.Parameters.Add("TipoOperazione",   OleDbType.VarChar).Value = TipoOperazione;
					cmd.Parameters.Add("IdOffertaAcquisto", OleDbType.VarChar).Value = IdOffertaAcquisto;
					cmd.Parameters.Add("AnnoRiferimento",  OleDbType.VarChar).Value = loc_AnnoRiferimento; 
					cmd.Parameters.Add("DataOraCreazione", OleDbType.DBTimeStamp).Value = loc_DataOraCreazione; 
					cmd.Parameters.Add("DataOraModifica",  OleDbType.DBTimeStamp).Value = loc_DataOraModifica; 
					cmd.Parameters.Add("IdUtente",	       OleDbType.VarChar).Value = loc_IdUtente; 
					cmd.Parameters.Add("IdSessione",       OleDbType.VarChar).Value = loc_IdSessione; 
					cmd.Parameters.Add("Firma",            OleDbType.LongVarChar).Value = Firma; 

					cmd.ExecuteNonQuery();
				}
			}
		}
	}
}
