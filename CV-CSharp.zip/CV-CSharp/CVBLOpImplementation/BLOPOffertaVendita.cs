using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPOffertaVendita.
	/// </summary>
	public class BLOPOffertaVendita : CVRemotingBase, IBLOPOffertaVendita
	{
		public BLOPOffertaVendita()
		{
		}

		
		public void Delete(string IdOffertaVendita, string Firma)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					_Delete(dbTran, IdOffertaVendita, Firma);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		internal void _Delete(IDbTransaction dbTran, string IdOffertaVendita, string Firma)
		{
			// Prelevo le informazioni dell'offerta di acquisto
			InfoOffertaVendita infoOV = Get(IdOffertaVendita);

			DLOPOffertaVendita dl = new DLOPOffertaVendita(dbTran);
			dl.Delete(IdOffertaVendita, Firma);
			dl.UpdateQtyImpegnata(infoOV.IdUtente, infoOV.IdSessione, infoOV.QtyOfferta, infoOV.AnnoRiferimento, "Diminuita");
			return;
		}

	
		public void DeleteIncompatible(string IdOffertaVendita, string Firma)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					_DeleteIncompatible(dbTran, IdOffertaVendita, Firma);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		internal void _DeleteIncompatible(IDbTransaction dbTran, string IdOffertaVendita, string Firma)
		{
			DLOPOffertaVendita dl = new DLOPOffertaVendita(dbTran);
			dl.DeleteIncompatible(IdOffertaVendita, Firma);
			return;
		}

		
		public int Modifica(string IdOffertaVendita, decimal NuovoPrezzo, decimal NuovaQtyResidua, decimal OldQtyResidua, string Firma)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					BLOPOfferteAcquisto blopOfferteAcquisto = new BLOPOfferteAcquisto();
					BLOPSocieta blopSocieta = new BLOPSocieta();
					DLOPOffertaVendita dlopOffertaVendita = new DLOPOffertaVendita(dbTran);

					InfoOffertaVendita infoOV = Get(IdOffertaVendita);
					bool operazioneOK = true;
					decimal diffQty = 0M;
					decimal disponibilita = 0M;
					decimal qty = 0M;
					int retVal = 0;
					decimal NewQtyOfferta = NuovaQtyResidua + (infoOV.QtyOfferta - infoOV.QtyResidua);
					// la seguente riga produce un risultato che non viene usato neanche nel VB
					// DataSet dsListaNonEseguite = blopOfferteAcquisto._GetListaNonEseguite(dbTran, infoOV.IdSessione, infoOV.IdUtente, infoOV.AnnoRiferimento);
					if (NuovoPrezzo == 0)
					{
						decimal numOfferteAcquisto = blopOfferteAcquisto._GetCount(dbTran, infoOV.IdSessione, infoOV.IdUtente, infoOV.AnnoRiferimento);
						if (numOfferteAcquisto > 0)
						{
							if (NewQtyOfferta > infoOV.QtyOfferta)
							{
								diffQty = NewQtyOfferta - infoOV.QtyOfferta;
								disponibilita = blopSocieta._GetDisponibilitaVendita(dbTran, infoOV.IdSessione, infoOV.IdUtente, infoOV.AnnoRiferimento);
								if (disponibilita >= diffQty)
								{
									qty = dlopOffertaVendita.Modifica(IdOffertaVendita, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
									if (qty == 1)
									{
										dlopOffertaVendita.UpdateQtyImpegnata(infoOV.IdUtente, infoOV.IdSessione, diffQty, infoOV.AnnoRiferimento, "Maggiorata");
									}
									else
									{
										// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
										retVal = -1;
										operazioneOK = false;
									}
								}
								else
								{
									// Quantita' non disponibile
									retVal = -2;
									operazioneOK = false;
								}
							}
							else if (NewQtyOfferta < infoOV.QtyOfferta)
							{
								diffQty = infoOV.QtyOfferta - NewQtyOfferta;
								qty = dlopOffertaVendita.Modifica(IdOffertaVendita, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
								if (qty == 1)
								{
									dlopOffertaVendita.UpdateQtyImpegnata(infoOV.IdUtente, infoOV.IdSessione, diffQty, infoOV.AnnoRiferimento, "Diminuita");
								}
								else
								{
									// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
									retVal = -1;
									operazioneOK = false;
								}
							}
							else if (NewQtyOfferta == infoOV.QtyOfferta)
							{
								qty = dlopOffertaVendita.Modifica(IdOffertaVendita, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
								if (qty != 1)
								{
									// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
									retVal = -1;
									operazioneOK = false;
								}
							}
						} // fine if (numOfferteAcquisto > 0)
						else
						{
							// Impossibile effettuare la modifica
							retVal = -3;
							operazioneOK = false;
						}
					} // fine if (Nuovo Prezzo == 0)
					else
					{
						if (NewQtyOfferta > infoOV.QtyOfferta)
						{
							diffQty = NewQtyOfferta - infoOV.QtyOfferta;
							disponibilita = blopSocieta._GetDisponibilitaVendita(dbTran, infoOV.IdSessione, infoOV.IdUtente, infoOV.AnnoRiferimento);
							if (disponibilita >= diffQty)
							{
								qty = dlopOffertaVendita.Modifica(IdOffertaVendita, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
								if (qty ==1)
								{
									dlopOffertaVendita.UpdateQtyImpegnata(infoOV.IdUtente, infoOV.IdSessione, diffQty, infoOV.AnnoRiferimento, "Maggiorata");
								}
								else
								{
									// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
									retVal = -1;
									operazioneOK = false;
								}
							}
							else
							{
								// Quantita' non disponibile
								retVal = -2;
								operazioneOK = false;
							}
						}
						else if (NewQtyOfferta < infoOV.QtyOfferta)
						{
							diffQty = infoOV.QtyOfferta - NewQtyOfferta;
							qty = dlopOffertaVendita.Modifica(IdOffertaVendita, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
							if (qty == 1)
							{
								dlopOffertaVendita.UpdateQtyImpegnata(infoOV.IdUtente, infoOV.IdSessione, diffQty, infoOV.AnnoRiferimento, "Diminuita");
							}
							else
							{
								// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
								retVal = -1;
								operazioneOK = false;
							}
						}
						else if (NewQtyOfferta == infoOV.QtyOfferta)
						{
							qty = dlopOffertaVendita.Modifica(IdOffertaVendita, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
							if (qty != 1)
							{
								// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
								retVal = -1;
								operazioneOK = false;
							}
						}
					}
					if ((NuovaQtyResidua != 0) && (operazioneOK) && (qty != 0))
					{
						BLOPOfferte blopOfferte = new BLOPOfferte();
						int ris = blopOfferte._Abbinamento(dbTran, "Vendita", IdOffertaVendita, infoOV.IdUtente);
						// 0  = Tutto Ok
						// -5 = Offerta totalmente incompatibile
						// -6 = Offerta parzialmente incompatibile
						if (ris != 0) retVal = ris ;
					}
					dbTran.Commit();
					return retVal;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		
		public InfoOffertaVendita Get(string IdOffertaVendita)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					InfoOffertaVendita infoOV = _Get(dbTran, IdOffertaVendita);
					dbTran.Commit();
					return infoOV;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		internal InfoOffertaVendita _Get(IDbTransaction dbTran, string IdOffertaVendita)
		{
			DLOPOffertaVendita dl = new DLOPOffertaVendita(dbTran);
			InfoOffertaVendita infoOV = dl.Get(IdOffertaVendita);
			return infoOV;
		}
	}
}
