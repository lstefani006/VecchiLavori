using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPOfferte.
	/// </summary>
	public class BLOPOfferte : CVRemotingBase, IBLOPOfferte
	{
		public BLOPOfferte()
		{
		}

		public void Abbinamento(string TipoOfferta, string IdOfferta, string IdUtente)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					_Abbinamento(dbTran, TipoOfferta, IdOfferta, IdUtente);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal int _Abbinamento(IDbTransaction dbTran, string TipoOfferta, string IdOfferta, string IdUtente)
		{
			// 0  = Tutto Ok
			// -5 = Offerta totalmente incompatibile
			// -6 = Offerta parzialmente incompatibile
			int ris = 0 ; 
			DLOPOfferte dl = new DLOPOfferte(dbTran);
			if (TipoOfferta.Equals("Acquisto"))
			{
				ris = dl.OffertaAcquistoAbbinamento(IdOfferta, IdUtente);
			}
			else if (TipoOfferta.Equals("Vendita"))
			{
				ris = dl.OffertaVenditaAbbinamento(IdOfferta, IdUtente);
			}
			return ris;
		}
	}
}
