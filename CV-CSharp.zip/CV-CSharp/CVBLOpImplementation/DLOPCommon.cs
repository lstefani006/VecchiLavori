using System;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Classe di utilita' per tutte le classi appartenenti al DL.
	/// </summary>
	internal class DLOPCommon
	{
		public DLOPCommon()
		{
		}

		/// <summary>
		/// Metodo statico che preleva dal file di configurazione la stringa di connessione verso il 
		/// DataBase
		/// </summary>
		/// <returns>La stringa di connessione al DataBase</returns>
		private static string GetConnectionString()
		{
			string strConnectionString = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringWeb"];
			return strConnectionString;

		}
		static public IDbConnection GetDBConnection()
		{
			string strConnectionString = GetConnectionString();
			return new OleDbConnection(strConnectionString);
		}

		static public DateTime GetDBSystemDate(IDbTransaction dbTran)
		{
			string strDateQry = "SELECT SYSDATE FROM DUAL";
			using (OleDbCommand cmd = new OleDbCommand(strDateQry, (OleDbConnection)dbTran.Connection, (OleDbTransaction)dbTran))
			{
				return (DateTime)cmd.ExecuteScalar();
			}
		}

		static public bool ContrattaCVAnnoMin(int Month, out int AnnoMin, out int AnnoMax)
		{
			string min = System.Configuration.ConfigurationSettings.AppSettings["ContrattaCVAnnoMin"];
			string max = System.Configuration.ConfigurationSettings.AppSettings["ContrattaCVAnnoMax"];
			DateTime dt = DateTime.Now ;
			try
			{
				int n = Convert.ToInt16(min);
				AnnoMin = dt.AddYears(n).Year ;
			}
			catch(Exception ex)
			{
				AnnoMin = dt.AddYears(-1).Year ;
			}
			try
			{
				int n = Convert.ToInt16(max);
				AnnoMax = dt.AddYears(n).Year ;
			}
			catch(Exception ex)
			{
				AnnoMax = dt.AddYears(+1).Year ;
			}

			string s = System.Configuration.ConfigurationSettings.AppSettings["ContrattaCVAnnoMin.Range"];
			if (s == null)
				return Month >= 1 && Month <= 10;

			string []a = s.Split(' ', ',', ':', '-');
			if (a.Length < 2)
				return Month >= 1 && Month <= 10;

			int inizio = int.Parse(a[0]);
			int fine   = int.Parse(a[1]);

			return Month >= inizio && Month <= fine;
		}
	}
}
