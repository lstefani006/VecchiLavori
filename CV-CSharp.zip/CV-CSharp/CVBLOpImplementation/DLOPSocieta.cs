using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Diagnostics;

namespace CV.Op
{
	/// <summary>
	/// Classe che si occupa del recupero dei dati dal DataBase da passare, poi, alla
	/// Business Logic.
	/// </summary>
	internal class DLOPSocieta : DLOPBase
	{
		public DLOPSocieta(IDbTransaction dbTransaction) : base(dbTransaction)
		{
		}

		public DataSet GetReportCV(string IdSessione, string IdSocieta)
		{
			if ((IdSessione != "") && (IdSocieta == ""))
			{
				string strSqlQuery = @"
				SELECT 
					RAWTOHEX(IdReport) as IdReport,
					RAWTOHEX(IdSocieta) as IdSocieta,
					RAWTOHEX(IdSessione) as IdSessione,
					NomeReport,
					FormatoReport,
					TipoReport,
					TSPubblicazione,
					TSCreazione,
					Note,
					TSInvio,
					TSRicevuto,
					TSDownload
				FROM CV.ReportCV
				WHERE (IdSessione = HEXTORAW(?) OR IdSessione Is Null)
				AND IdSocieta Is Null AND TSPubblicazione Is Not Null
				";

				using (OleDbDataAdapter da = new OleDbDataAdapter())
				{
					da.SelectCommand = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;

					DataSet ds = new DataSet("ReportCV");
					da.Fill(ds, "ReportCV");
					return ds;
				}
			}
			else if ((IdSessione == "") && (IdSocieta != ""))
			{
				string strSqlQuery = @"
				SELECT 
					RAWTOHEX(IdReport) as IdReport,
					RAWTOHEX(IdSocieta) as IdSocieta,
					RAWTOHEX(IdSessione) as IdSessione,
					NomeReport,
					FormatoReport,
					TipoReport,
					TSPubblicazione,
					TSCreazione,
					Note,
					TSInvio,
					TSRicevuto,
					TSDownload
				FROM CV.ReportCV
				WHERE (IdSocieta = HEXTORAW(?) OR IdSocieta Is Null)
				AND IdSessione Is Null AND TSPubblicazione Is Not Null
				";

				using (OleDbDataAdapter da = new OleDbDataAdapter())
				{
					da.SelectCommand = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand.Parameters.Add("@IdSocieta", OleDbType.VarChar, 32).Value = IdSocieta;

					DataSet ds = new DataSet("ReportCV");
					da.Fill(ds, "ReportCV");
					return ds;
				}
			}
			else
			{
				string strSqlQuery = @"
				SELECT 
					RAWTOHEX(IdReport) as IdReport,
					RAWTOHEX(IdSocieta) as IdSocieta,
					RAWTOHEX(IdSessione) as IdSessione,
					NomeReport,
					FormatoReport,
					TipoReport,
					TSPubblicazione,
					TSCreazione,
					Note,
					TSInvio,
					TSRicevuto,
					TSDownload
				FROM CV.ReportCV
				WHERE (IdSocieta = HEXTORAW(?) OR IdSocieta Is Null)
				AND (IdSessione = HEXTORAW(?) OR IdSessione Is Null)
				AND TSPubblicazione Is Not Null
				";

				using (OleDbDataAdapter da = new OleDbDataAdapter())
				{
					da.SelectCommand = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand.Parameters.Add("@IdSocieta", OleDbType.VarChar, 32).Value = IdSocieta;
					da.SelectCommand.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;

					DataSet ds = new DataSet("ReportCV");
					da.Fill(ds, "ReportCV");
					return ds;
				}
			}
		}

		public void MarcaDownload(string IdReport)
		{
			string sqlInsert =	"UPDATE CV.ReportCV SET " +
				"TSDownload = SYSDATE " +
				"WHERE IdReport = HEXTORAW(?) AND TSDownload Is Null " ;
										
			OleDbCommand cmd = new OleDbCommand(sqlInsert, m_Transaction.Connection, m_Transaction);
			cmd.Parameters.Add("IdReport",		OleDbType.VarChar).Value = IdReport ;
		
			cmd.ExecuteNonQuery();
		}

		protected OleDbDataAdapter GetDataAdapter()
		{
			return GetDataAdapter(null, (OleDbParameter [])null);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere)
		{
			OleDbParameter [] pars = new OleDbParameter [1];
			pars[0] = parWhere;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere1, OleDbParameter parWhere2)
		{
			OleDbParameter [] pars = new OleDbParameter [2];
			pars[0] = parWhere1;
			pars[1] = parWhere2;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			// Query di SELECT per il Data Adapter
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				// N.B. Lo spazio alla fine della stringa e' MOLTO IMPORTANTE non toglierlo!!!!!
				string sqlCmd = "SELECT RAWTOHEX(IdSocieta) AS IdSocieta, " +
					"RagioneSociale AS RagioneSociale, " +
					"Indirizzo AS Indirizzo,  " +
					"Citta AS Citta, " +
					"CAP AS CAP, " +
					"Nazione AS Nazione, " +
					"CodiceFiscale AS CodiceFiscale, " +
					"PartitaIVA AS PartitaIVA, " +
					"Telefono AS Telefono, " +
					"Fax AS Fax, " +
					"Email AS Email, " +
					"ABI AS ABI, " +
					"CAB AS CAB, " +
					"CC AS CC, " +
					"ReferenteAmministr AS ReferenteAmministr, " +
					"SedeAmministrativa AS SedeAmministrativa, " +
					"CodiceConto AS CodiceConto, " +
					"DataOraInserimento AS DataOraInserimento, " +
					"DataOraModifica AS DataOraModifica, " +
					"RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc, " +
					"ChiaveContoProprieta AS ChiaveContoProprieta, " +
					"Saldo AS Saldo " +
					"FROM US.Societa "; 

				if (Valid(sql))
					sqlCmd += sql;

				cmd.CommandText = sqlCmd;

				if (Valid(sql) && parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						if (p != null)
							cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// update
			if (true)
			{
				//OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Update", m_Transaction.Connection, m_Transaction);
				//cmd.CommandType = CommandType.StoredProcedure;
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText =	"UPDATE US.Societa SET " +
					"Indirizzo = ?, " +
					"Citta = ?, " +
					"CAP = ?, " +
					"Nazione = ?, " +
					"Telefono = ?, " +
					"Fax = ?, " +
					"Email = ?, " +
					"CodiceConto = ?, " +
					"ABI = ?, " +
					"CAB = ?, " +
					"CC = ?, " +
					"ReferenteAmministr = ?, " +
					"SedeAmministrativa = ?, " +
					"ChiaveContoProprieta = ?, " +
					"Saldo = ? " +
					"WHERE IdSocieta = HEXTORAW(?)";
					
				cmd.Parameters.Add(new OleDbParameter("Indirizzo",						OleDbType.VarChar,	255, "Indirizzo"));
				cmd.Parameters.Add(new OleDbParameter("Citta",							OleDbType.VarChar,	255, "Citta"));
				cmd.Parameters.Add(new OleDbParameter("CAP",							OleDbType.VarChar,	255, "CAP"));
				cmd.Parameters.Add(new OleDbParameter("Nazione",						OleDbType.VarChar,  255, "Nazione"));
				cmd.Parameters.Add(new OleDbParameter("Telefono",						OleDbType.VarChar,  255, "Telefono"));
				cmd.Parameters.Add(new OleDbParameter("Fax",							OleDbType.VarChar,  255, "Fax"));
				cmd.Parameters.Add(new OleDbParameter("Email",							OleDbType.VarChar,  255, "Email"));
				cmd.Parameters.Add(new OleDbParameter("CodiceConto",					OleDbType.VarChar,  255, "CodiceConto"));
				cmd.Parameters.Add(new OleDbParameter("ABI",							OleDbType.VarChar,  255, "ABI"));
				cmd.Parameters.Add(new OleDbParameter("CAB",							OleDbType.VarChar,  255, "CAB"));
				cmd.Parameters.Add(new OleDbParameter("CC",								OleDbType.VarChar,  255, "CC"));
				cmd.Parameters.Add(new OleDbParameter("ReferenteAmministr",				OleDbType.VarChar,  100, "ReferenteAmministr"));
				cmd.Parameters.Add(new OleDbParameter("SedeAmministrativa",				OleDbType.VarChar,  100, "SedeAmministrativa"));
				cmd.Parameters.Add(new OleDbParameter("ChiaveContoProprieta",			OleDbType.VarChar,  255, "ChiaveContoProprieta"));
				cmd.Parameters.Add(new OleDbParameter("Saldo",							OleDbType.Decimal,	  0, "Saldo"));		
				cmd.Parameters.Add(new OleDbParameter("IdSocieta",		                OleDbType.VarChar,   32, "IdSocieta"));

				da.UpdateCommand = cmd;
			}
			// TODO: (Flavio) Query di INSERT, UPDATE, DELETE per la classe AdminSocieta
			da.MissingSchemaAction = MissingSchemaAction.Error;
			return da;
		}

		public static DataSet DataSet_Societa()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("Societa");

			DataColumn c;
			c = dt.Columns.Add("IdSocieta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("RagioneSociale", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("Indirizzo", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Citta", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("CAP", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Nazione", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("CodiceFiscale", typeof(string));
			c.MaxLength = 16;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PartitaIVA", typeof(string));
			c.MaxLength = 11;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Telefono", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("FAX", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Email", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("ABI", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("CAB", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("CC", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("ReferenteAmministr", typeof(string));
			c.MaxLength = 100;
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("SedeAmministrativa", typeof(string));
			c.MaxLength = 100;
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("CodiceConto", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;
			
			c = dt.Columns.Add("DataOraInserimento", typeof(DateTime));
			c.AllowDBNull = false;
			//			c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("DataOraModifica", typeof(DateTime));
			c.AllowDBNull = false;
			//			c.DefaultValue = new DateTime(1900,1,1);
	
			c = dt.Columns.Add("IdRichiestaRegSoc", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;
			
			c = dt.Columns.Add("Saldo", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("ChiaveContoProprieta", typeof(string));
			c.AllowDBNull = true;
			c.MaxLength = 255;
			c.Unique = false;

			dt.PrimaryKey = new DataColumn[] {	dt.Columns["IdSocieta"]};
			return ds;

		}

		public DataSet GetListaByIdSocieta(string IdSocieta)
		{
			OleDbDataAdapter da = null;

			if (Valid(IdSocieta))
			{
				OleDbParameter par = new OleDbParameter("IdSocieta", OleDbType.VarChar);
				par.Value = IdSocieta;

				da = GetDataAdapter("WHERE IdSocieta = HEXTORAW(?)", par);
			}
			else
				da = GetDataAdapter();

			using (da)
			{
				DataSet ds = DataSet_Societa();
				da.Fill(ds, "Societa");
				return ds;
			}
		}

		public string GetRagioneSociale(string IdUtente)
		{
			Debug.Assert(Valid(IdUtente));

			string strSqlQuery = "SELECT RagioneSociale " +
								 "FROM us.Societa, us.Utenti " +
								 "WHERE Utenti.IdUtente = HEXTORAW(?) " +
								 "AND Societa.IdSocieta = Utenti.IdSocieta";

			using (OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				selectCMD.Parameters.Add("@IdUtente", OleDbType.VarChar, 32).Value = IdUtente;
				return (string)selectCMD.ExecuteScalar();
			}
		}

		public byte[] GetDoc(string IdReport)
		{
			string strSqlQuery = "SELECT RawReport " +
				"FROM CV.ReportCV " +
				"WHERE IdReport = HEXTORAW(?) " ;

			using (OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				selectCMD.Parameters.Add("@IdReport", OleDbType.VarChar, 32).Value = IdReport ;
				return (byte[])selectCMD.ExecuteScalar();
			}
		}

		public BankAccount GetBankAccount(string CommonName, string IdSessione)
		{
			CommonName = Encrypt(CommonName);

			string strSqlQuery = "SELECT B.Importo, B.PrezzoConvenzionaleUtenteMw, " + 
								 "B.QtyMax, B.QtyImpegnata, " +
								 "(B.QtyMax - B.QtyImpegnata) As QtyDisponibile " +
								 "FROM   US.Societa S, CV.Budgets B, US.Utenti U " +
								 "WHERE  U.DN = ? AND " + // OK Crypt
								 "U.IdSocieta = S.IdSocieta AND " +
								 "S.IdSocieta = B.IdSocieta AND " +
								 "B.IdSessione = HEXTORAW(?)";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@CommonName", OleDbType.VarChar, 1024).Value = CommonName;
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 33).Value = IdSessione;
				DataSet ds = new DataSet("dsBankAccount");
				{
					da.Fill(ds, "BankAccount");
					DataTable dt = ds.Tables["BankAccount"];
					BankAccount ba = new BankAccount();
					// Le societa possono avere o meno un Budget gia' assegnato
					if (dt.Rows.Count == 0)
					{
						ba.ImportoIsNull = true;
						ba.PrezzoConvUtenteMwIsNull = true;
						ba.QuantitaDisponibileIsNull = true;
						ba.QuantitaImpegnataIsNull = true;
						ba.QuantitaMaxIsNull = true;
						return ba;
					}
					if (dt.Rows.Count == 1)
					{
						if (!dt.Rows[0].IsNull("Importo"))
						{
							ba.Importo = Convert.ToDecimal(dt.Rows[0]["Importo"]);
							ba.ImportoIsNull = false;
						}
						else
						{
							ba.Importo = 0M;
							ba.ImportoIsNull = true;
						}
						if (!dt.Rows[0].IsNull("PrezzoConvenzionaleUtenteMw"))
						{
							ba.PrezzoConvUtenteMw = Convert.ToDecimal(dt.Rows[0]["PrezzoConvenzionaleUtenteMw"]);
							ba.PrezzoConvUtenteMwIsNull = false;
						}
						else
						{
							ba.PrezzoConvUtenteMw = 0M;
							ba.PrezzoConvUtenteMwIsNull = true;
						}
						if (!dt.Rows[0].IsNull("QtyDisponibile"))
						{
							ba.QuantitaDisponibile = Convert.ToInt64(dt.Rows[0]["QtyDisponibile"]);
							ba.QuantitaDisponibileIsNull = false;
						}
						else
						{
							ba.QuantitaDisponibile = 0;
							ba.QuantitaDisponibileIsNull = true;
						}
						if (!dt.Rows[0].IsNull("QtyImpegnata"))
						{
							ba.QuantitaImpegnata = Convert.ToInt64(dt.Rows[0]["QtyImpegnata"]);
							ba.QuantitaImpegnataIsNull = false;
						}
						else
						{
							ba.QuantitaImpegnata = 0;
							ba.QuantitaImpegnataIsNull = true;
						}
						if (!dt.Rows[0].IsNull("QtyMax"))
						{
							ba.QuantitaMax = Convert.ToInt64(dt.Rows[0]["QtyMax"]);
							ba.QuantitaMaxIsNull = false;
						}
						else
						{
							ba.QuantitaMax = 0;
							ba.QuantitaMaxIsNull = true;
						}
						return ba;
					}
					else
					{
						throw new ApplicationException("Errore il ResultSet contiene piu' di una riga");
					}
				}
			}
		}
		
		public DataSet GetCertificates(string CommonName, string IdSessione)
		{
			string strSqlQuery = null;
			DateTime data = base.GetDBSystemDate();

			CommonName = Encrypt(CommonName);

			int AnnoMin = 0 ;
			int AnnoMax = 0 ;
			if (DLOPCommon.ContrattaCVAnnoMin(data.Month, out AnnoMin, out AnnoMax))
			{
				strSqlQuery = "SELECT RAWTOHEX(S.IdSocieta) AS IdSocieta, " + 
							  "RAWTOHEX(C.IdCertificatoVerde) AS IdCertificatoVerde, " +
							  "C.AnnoRiferimento, C.QtyImpegnata, C.Qty AS QtyMax, " +
							  "C.Qty - C.QtyImpegnata AS QtyDisponibile " +
							  "FROM CV.CertificatiVerdi C, US.Societa S, US.Utenti U " +
							  "WHERE U.DN = '" + CommonName + "' " + // OK Crypt
							  "AND U.IdSocieta = S.IdSocieta " +
							  "AND S.IdSocieta = C.IdSocieta " +
							  "AND C.IdSessione =  HEXTORAW('" + IdSessione + "') " +
							  "AND (C.AnnoRiferimento = '" + AnnoMin.ToString() +  "' " ;	
				for(int i=AnnoMin+1;i<AnnoMax;i++)
				{
					strSqlQuery += " OR C.AnnoRiferimento = '" + i.ToString() + "' " ;
				}
				strSqlQuery +=	" OR C.AnnoRiferimento = '" + AnnoMax.ToString() + "') " +
								" ORDER BY C.AnnoRiferimento DESC";
//							  "AND (C.AnnoRiferimento = '" + data.AddYears(-1).Year +  "' " +
//							  "OR C.AnnoRiferimento = '" + data.Year + "' " +
//							  "OR C.AnnoRiferimento = '" + data.AddYears(+1).Year + "') " +
//							  "ORDER BY C.AnnoRiferimento DESC";
			}
			else
			{
				AnnoMin += 1 ;
				strSqlQuery = "SELECT RAWTOHEX(S.IdSocieta) AS IdSocieta, " + 
							  "RAWTOHEX(C.IdCertificatoVerde) AS IdCertificatoVerde, " +
							  "C.AnnoRiferimento, C.QtyImpegnata, C.Qty AS QtyMax, " +
							  "C.Qty - C.QtyImpegnata AS QtyDisponibile " +
							  "FROM CV.CertificatiVerdi C, US.Societa S, US.Utenti U " +
							  "WHERE U.DN = '" + CommonName + "' " +  // OK Crypt
							  "AND U.IdSocieta = S.IdSocieta " +
							  "AND S.IdSocieta = C.IdSocieta " +
							  "AND C.IdSessione =  HEXTORAW('" + IdSessione + "') " + 
							  "AND (C.AnnoRiferimento = '" + AnnoMin.ToString() +  "' " ;	
				for(int i=AnnoMin+1;i<AnnoMax;i++)
				{
					strSqlQuery += " OR C.AnnoRiferimento = '" + i.ToString() + "' " ;
				}
				strSqlQuery +=	" OR C.AnnoRiferimento = '" + AnnoMax.ToString() + "') " +
								" ORDER BY C.AnnoRiferimento DESC";
//							  "AND (C.AnnoRiferimento = '" + data.Year + "' " +
//							  "OR C.AnnoRiferimento = '" + data.AddYears(+1).Year + "') " +
//							  "ORDER BY C.AnnoRiferimento DESC";
			}
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				da.SelectCommand = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				DataSet ds = new DataSet("dsCertificates");
				da.Fill(ds, "Certificates");
				return ds;
			}
		}

		public decimal GetDisponibilitaAcquisto(string IdSessione, string IdUtente)
		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_RetrieveQtyDisponibileAcq", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			
//			// ID Utente (input)
//			OleDbParameter parIDUtente = new OleDbParameter("@IDUtente", OleDbType.VarChar, 32);
//			parIDUtente.Direction = ParameterDirection.Input;
//			parIDUtente.IsNullable = false;
//			parIDUtente.Value = IdUtente;
//			callspCMD.Parameters.Add(parIDUtente);
//			// ID Sessione (input)
//			OleDbParameter parIdSessione = new OleDbParameter("@IDSessione", OleDbType.VarChar, 32);
//			parIdSessione.Direction = ParameterDirection.Input;
//			parIdSessione.IsNullable = false;
//			parIdSessione.Value = IdSessione;
//			callspCMD.Parameters.Add(parIdSessione);
//			// Qty Disponibilita Acquisto (output)
//			OleDbParameter parQtyDisponibileAcq = new OleDbParameter("@QtyDisponibilitaAcq", OleDbType.Decimal);
//			parQtyDisponibileAcq.Direction = ParameterDirection.Output;
//			parQtyDisponibileAcq.IsNullable = false;
//			callspCMD.Parameters.Add(parQtyDisponibileAcq);
//
//			callspCMD.ExecuteNonQuery();
//
//			return (decimal)callspCMD.Parameters["@QtyDisponibilitaAcq"].Value;
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = "SELECT CV.Budgets.QtyMax - CV.Budgets.QtyImpegnata " + 
					" FROM CV.Budgets, US.Utenti " + 
					" WHERE  US.Utenti.IdUtente = HEXTORAW(?) AND " + 
					" CV.Budgets.IdSocieta = US.Utenti.IdSocieta AND " +
					" CV.Budgets.IdSessione = HEXTORAW(?)";

				cmd.Parameters.Add("in_IdUtente", OleDbType.VarChar).Value = IdUtente;
				cmd.Parameters.Add("in_IdSessione", OleDbType.VarChar).Value = IdSessione;
				
				using(OleDbDataReader rd = cmd.ExecuteReader())
				{
					if (rd.Read())
					{
						if (rd.IsDBNull(0))
							return 0m;

						return (decimal)rd[0];
					}
					return 0m;
				}
			}
		}

		public decimal GetDisponibilitaVendita(string IdSessione, string IdUtente, string AnnoRiferimento)
		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_RetrieveQtyDisponibile", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
			//			// ID Utente (input)
//			OleDbParameter parIDUtente = new OleDbParameter("@IDUtente", OleDbType.VarChar, 32);
//			parIDUtente.Direction = ParameterDirection.Input;
//			parIDUtente.IsNullable = false;
//			parIDUtente.Value = IdUtente;
//			callspCMD.Parameters.Add(parIDUtente);
//			// ID Sessione (input)
//			OleDbParameter parIdSessione = new OleDbParameter("@IDSessione", OleDbType.VarChar, 32);
//			parIdSessione.Direction = ParameterDirection.Input;
//			parIdSessione.IsNullable = false;
//			parIdSessione.Value = IdSessione;
//			callspCMD.Parameters.Add(parIdSessione);
//			// Anno Riferimento (input)
//			OleDbParameter parAnnoRif = new OleDbParameter("@AnnoRiferimento", OleDbType.VarChar, 4);
//			parAnnoRif.Direction = ParameterDirection.Input;
//			parAnnoRif.IsNullable = false;
//			parAnnoRif.Value = AnnoRiferimento;
//			callspCMD.Parameters.Add(parAnnoRif);
//			// Qty Disponibilita Vendita (output)
//			OleDbParameter parQtyDisponibileVen = new OleDbParameter("@QtyDisponibilitaVen", OleDbType.Decimal);
//			parQtyDisponibileVen.Direction = ParameterDirection.Output;
//			parQtyDisponibileVen.IsNullable = false;
//			callspCMD.Parameters.Add(parQtyDisponibileVen);
//
//			callspCMD.ExecuteNonQuery();
//
//			return (decimal)callspCMD.Parameters["@QtyDisponibilitaVen"].Value;


			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = "SELECT CertificatiVerdi.Qty - CertificatiVerdi.QtyImpegnata AS QtyDisponibile " + 
					" FROM   cv.CertificatiVerdi CertificatiVerdi, US.Utenti Utenti " + 
					" WHERE  Utenti.IdUtente = HEXTORAW(?) AND " +
					" CertificatiVerdi.IdSocieta = Utenti.IdSocieta AND " + 
					" CertificatiVerdi.AnnoRiferimento = ? AND " + 
					" CertificatiVerdi.IdSessione = HEXTORAW(?)";


				cmd.Parameters.Add("in_IdUtente", OleDbType.VarChar).Value = IdUtente;
				cmd.Parameters.Add("in_AnnoRiferimento", OleDbType.VarChar).Value = AnnoRiferimento;
				cmd.Parameters.Add("in_IdSessione", OleDbType.VarChar).Value = IdSessione;

				using (OleDbDataReader rd = cmd.ExecuteReader())
				{
					if (rd.Read())
					{
						if (rd.IsDBNull(0))
							return 0m;

						return (decimal)rd[0];
					}
					return 0m;
				}
			}
		}

		public string Insert(InfoSocieta infoS)
		{
			try
			{
//				OleDbCommand callspCMD = new OleDbCommand("US.sp_Societa_Add", m_Transaction.Connection, m_Transaction);
//				callspCMD.CommandType = CommandType.StoredProcedure;
//
//				// Ragione Sociale (input)
//				OleDbParameter parRagioneSociale = new OleDbParameter("@RagioneSociale", OleDbType.VarChar, 255);
//				parRagioneSociale.Direction = ParameterDirection.Input;
//				parRagioneSociale.IsNullable = false;
//				parRagioneSociale.Value = infoS.RagioneSociale;
//				callspCMD.Parameters.Add(parRagioneSociale);
//
//				// Indirizzo (input)
//				OleDbParameter parIndirizzo = new OleDbParameter("@Indirizzo", OleDbType.VarChar, 255);
//				parIndirizzo.Direction = ParameterDirection.Input;
//				parIndirizzo.IsNullable = false;
//				parIndirizzo.Value = infoS.Indirizzo;
//				callspCMD.Parameters.Add(parIndirizzo);
//
//				// Citta' (input)
//				OleDbParameter parCitta = new OleDbParameter("@Citta", OleDbType.VarChar, 255);
//				parCitta.Direction = ParameterDirection.Input;
//				parCitta.IsNullable = false;
//				parCitta.Value = infoS.Citta;
//				callspCMD.Parameters.Add(parCitta);
//
//				// CAP (input)
//				OleDbParameter parCAP = new OleDbParameter("@CAP", OleDbType.VarChar, 255);
//				parCAP.Direction = ParameterDirection.Input;
//				parCAP.IsNullable = false;
//				parCAP.Value = infoS.CAP;
//				callspCMD.Parameters.Add(parCAP);
//
//				// Nazione (input)
//				OleDbParameter parNazione = new OleDbParameter("@Nazione", OleDbType.VarChar, 255);
//				parNazione.Direction = ParameterDirection.Input;
//				parNazione.IsNullable = false;
//				parNazione.Value = infoS.Nazione;
//				callspCMD.Parameters.Add(parNazione);
//
//				// Codice Fiscale (input)
//				OleDbParameter parCodiceFiscale = new OleDbParameter("@CodiceFiscale", OleDbType.VarChar, 16);
//				parCodiceFiscale.Direction = ParameterDirection.Input;
//				parCodiceFiscale.IsNullable = false;
//				parCodiceFiscale.Value = infoS.CodiceFiscale;
//				callspCMD.Parameters.Add(parCodiceFiscale);
//
//				// Partita IVA (input)
//				OleDbParameter parPartitaIVA = new OleDbParameter("@PartitaIVA", OleDbType.VarChar, 11);
//				parPartitaIVA.Direction = ParameterDirection.Input;
//				parPartitaIVA.IsNullable = false;
//				parPartitaIVA.Value = infoS.PartitaIVA;
//				callspCMD.Parameters.Add(parPartitaIVA);
//
//				// ABI (input)
//				OleDbParameter parABI = new OleDbParameter("@ABI", OleDbType.VarChar, 255);
//				parABI.Direction = ParameterDirection.Input;
//				parABI.IsNullable = false;
//				parABI.Value = infoS.ABI;
//				callspCMD.Parameters.Add(parABI);
//
//				// CAB (input)
//				OleDbParameter parCAB = new OleDbParameter("@CAB", OleDbType.VarChar, 255);
//				parCAB.Direction = ParameterDirection.Input;
//				parCAB.IsNullable = false;
//				parCAB.Value = infoS.CAB;
//				callspCMD.Parameters.Add(parCAB);
//
//				// CC (input)
//				OleDbParameter parCC = new OleDbParameter("@CC", OleDbType.VarChar, 255);
//				parCC.Direction = ParameterDirection.Input;
//				parCC.IsNullable = false;
//				parCC.Value = infoS.CC;
//				callspCMD.Parameters.Add(parCC);
//
//				// Consenso Trattamento Dati (input)
//				OleDbParameter parCTD = new OleDbParameter("@CTD", OleDbType.Decimal);
//				parCTD.Direction = ParameterDirection.Input;
//				parCTD.IsNullable = false;
//				parCTD.Value = infoS.ConsensoTrattamentoDati;
//				callspCMD.Parameters.Add(parCTD);
//
//				// Telefono (input)
//				OleDbParameter parTel = new OleDbParameter("@Tel", OleDbType.VarChar, 255);
//				parTel.Direction = ParameterDirection.Input;
//				parTel.IsNullable = false;
//				parTel.Value = infoS.Telefono;
//				callspCMD.Parameters.Add(parTel);
//
//				// FAX (input)
//				OleDbParameter parFax = new OleDbParameter("@Fax", OleDbType.VarChar, 255);
//				parFax.Direction = ParameterDirection.Input;
//				parFax.IsNullable = false;
//				parFax.Value = infoS.FAX;
//				callspCMD.Parameters.Add(parFax);
//
//				// Email (input)
//				OleDbParameter parEmail = new OleDbParameter("@Email", OleDbType.VarChar, 255);
//				parEmail.Direction = ParameterDirection.Input;
//				parEmail.IsNullable = false;
//				parEmail.Value = infoS.Email;
//				callspCMD.Parameters.Add(parEmail);
//				
//				// CodiceConto (input)
//				OleDbParameter parCodiceConto = new OleDbParameter("@CodiceConto", OleDbType.VarChar, 255);
//				parCodiceConto.Direction = ParameterDirection.Input;
//				parCodiceConto.IsNullable = false;
//				parCodiceConto.Value = infoS.CodiceConto;
//				callspCMD.Parameters.Add(parCodiceConto);
//
//				// GUID (output)
//				OleDbParameter parGUID = new OleDbParameter("@GUID", OleDbType.VarChar);
//				parGUID.Direction = ParameterDirection.Output;
//				parGUID.Size = 32;
//				callspCMD.Parameters.Add(parGUID);
//
//				callspCMD.ExecuteNonQuery();
//				return (string)callspCMD.Parameters["@GUID"].Value;



				using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
				{
					cmd.CommandText = 
						"INSERT INTO US.RichiesteRegSoc " +
						"	(IdRichiestaRegSoc, " +
						"	RagioneSociale, " +
						"	Indirizzo, " +
						"	Citta, " +
						"	CAP, " +
						"	Nazione, " +
						"	CodiceFiscale, " +
						"	PartitaIVA, " +
						"	Telefono, " +
						"	Fax, " +
						"	Email, " +
						"	ABI, " +
						"	CAB, " +
						"	CC, " +
						"	ReferenteAmministr, " +
						"	SedeAmministrativa, " +
						"	ConsensoTrattamentoDati, " +
						"	CodiceConto) " +
						"VALUES " +
						"	(HEXTORAW(?), " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?, " +
						"	?)";

					string guid = Guid.NewGuid().ToString("N").ToUpper();

					cmd.Parameters.Add("IdRichiestaRegSoc", OleDbType.VarChar).Value = guid;
					cmd.Parameters.Add("RagioneSociale", OleDbType.VarChar).Value = infoS.RagioneSociale;
					cmd.Parameters.Add("Indirizzo", OleDbType.VarChar).Value = infoS.Indirizzo;
					cmd.Parameters.Add("Citta", OleDbType.VarChar).Value = infoS.Citta;
					cmd.Parameters.Add("CAP", OleDbType.VarChar).Value = infoS.CAP;
					cmd.Parameters.Add("Nazione", OleDbType.VarChar).Value = infoS.Nazione;
					cmd.Parameters.Add("CodiceFiscale", OleDbType.VarChar).Value = infoS.CodiceFiscale;
					cmd.Parameters.Add("PartitaIVA", OleDbType.VarChar).Value = infoS.PartitaIVA;
					cmd.Parameters.Add("Telefono", OleDbType.VarChar).Value = infoS.Telefono;
					cmd.Parameters.Add("Fax", OleDbType.VarChar).Value = infoS.FAX;
					cmd.Parameters.Add("Email", OleDbType.VarChar).Value = infoS.Email;
					cmd.Parameters.Add("ABI", OleDbType.VarChar).Value = infoS.ABI;
					cmd.Parameters.Add("CAB", OleDbType.VarChar).Value = infoS.CAB;
					cmd.Parameters.Add("CC", OleDbType.VarChar).Value = infoS.CC;
					cmd.Parameters.Add("ReferenteAmministr", OleDbType.VarChar).Value = infoS.ReferenteAmministr;
					cmd.Parameters.Add("SedeAmministrativa", OleDbType.VarChar).Value = infoS.SedeAmministrativa;
					cmd.Parameters.Add("ConsensoTrattamentoDati", OleDbType.Decimal).Value = infoS.ConsensoTrattamentoDati;
					cmd.Parameters.Add("CodiceConto", OleDbType.Decimal).Value = infoS.CodiceConto;

					cmd.ExecuteNonQuery();

					return guid;
				}
			}
			catch(OleDbException exc)
			{
				int i = 0 ;
				i = exc.Message.IndexOf("UC_RAGSOC") ;
				if (i>0)
				{
					throw new ApplicationException("Registrazione non effettuata: Societ� gi� presente in archivio." , exc);
				}
				i = exc.Message.IndexOf("UC_CF_PIVA") ;
				if (i>0)
				{
					throw new ApplicationException("Registrazione non effettuata: Societ� gi� presente in archivio." , exc);
				}
				i = exc.Message.IndexOf("UC_CODICE_CONTO") ;
				if (i>0)
				{
					throw new ApplicationException("Registrazione non effettuata: Codice conto gi� presente in archivio." , exc);
				}
				throw new ApplicationException("Registrazione non effettuata: Certificato gi� usato per un'altra registrazione." , exc);
			}
		}


		public DataSet GetSocietaPerRegistrazioneUtente()
		{
			bool bSocietaRegistrate = false;

			string s = ConfigurationSettings.AppSettings["Registrazione.SocietaRegistrate"];
			if (s != null)
			{
				s = s.ToLower();
				if (s == "true" || s == "yes" || s == "si" || s == "1")
					bSocietaRegistrate = true;
			}

			if (bSocietaRegistrate == true)
			{
				using(OleDbDataAdapter da = new OleDbDataAdapter(
						  "select RAWTOHEX(IdSocieta) AS IdSocieta, RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc, RagioneSociale, CodiceFiscale, PartitaIva from us.Societa",
						  m_Transaction.Connection))
				{
					da.SelectCommand.Transaction = m_Transaction;

					DataSet ds = new DataSet();
					DataTable dt = ds.Tables.Add("Societa");
					dt.Columns.Add("IdSocieta", typeof(string));
					dt.Columns.Add("IdRichiestaRegSoc", typeof(string));
					dt.Columns.Add("RagioneSociale", typeof(string));
					dt.Columns.Add("CodiceFiscale", typeof(string));
					dt.Columns.Add("PartitaIva", typeof(string));
					da.Fill(ds, "Societa");
					return ds;
				}
			}
			else
			{
				using(OleDbDataAdapter da = new OleDbDataAdapter(
						  "select RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc, RagioneSociale, CodiceFiscale, PartitaIva from us.RichiesteRegSoc",
						  m_Transaction.Connection))
				{
					da.SelectCommand.Transaction = m_Transaction;

					DataSet ds = new DataSet();
					DataTable dt = ds.Tables.Add("Societa");
					dt.Columns.Add("IdRichiestaRegSoc", typeof(string));
					dt.Columns.Add("RagioneSociale", typeof(string));
					dt.Columns.Add("CodiceFiscale", typeof(string));
					dt.Columns.Add("PartitaIva", typeof(string));
					da.Fill(ds, "Societa");
					return ds;
				}
			}
		}

		public bool VerificaPINSoc(string IdRicRegSoc, string PINSoc)
		{
			string strSqlQuery = @"
			SELECT RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc
			FROM US.RichiesteRegSoc
			WHERE HEXTORAW(IdRichiestaRegSoc) = ? AND PINSoc = ? " ;

			using (OleDbCommand cmd = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				cmd.Parameters.Add("@IdRichiestaRegSoc", OleDbType.VarChar).Value = IdRicRegSoc;
				cmd.Parameters.Add("@PINSoc",			OleDbType.VarChar).Value = PINSoc;

				using (OleDbDataReader rd = cmd.ExecuteReader())
				{
					if (rd.Read())
						return true;

					return false;
				}
			}
		}

		public bool VerificaPINSoc2(string CodiceConto, string PINSoc)
		{
			string strSqlQuery = @"
			SELECT RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc
			FROM US.RichiesteRegSoc
			WHERE CodiceConto = ? AND PINSoc = ? " ;

			using (OleDbCommand cmd = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				cmd.Parameters.Add("@CodiceConto", OleDbType.VarChar).Value = CodiceConto;
				cmd.Parameters.Add("@PINSoc",	   OleDbType.VarChar).Value = PINSoc;

				using (OleDbDataReader rd = cmd.ExecuteReader())
				{
					if (rd.Read())
						return true;

					return false;
				}
			}
		}

		public string GetIdRicRegSoc(string CodiceConto)
		{
			string strSqlQuery = @"
				SELECT RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc
				FROM US.RichiesteRegSoc
				WHERE CodiceConto = ?" ;

			using (OleDbCommand cmd = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				cmd.Parameters.Add("@CodiceConto", OleDbType.VarChar, 1023).Value = CodiceConto;

				using (OleDbDataReader rd = cmd.ExecuteReader())
				{
					if (rd.Read())
						return (string)rd["IdRichiestaRegSoc"];

					return "";
				}
			}
		}

		public DataSet GetSocietaByIdUtente(string IdUtente)
		{
			string strSqlQuery = @"
				SELECT 
					RAWTOHEX(Societa.IdSocieta) as IdSocieta,
					Societa.RagioneSociale,
					Societa.CodiceConto
				FROM us.Societa Societa, us.Utenti Utenti
				WHERE Utenti.IdUtente = HEXTORAW(?)
				AND Societa.IdSocieta = Utenti.IdSocieta
			";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				da.SelectCommand = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand.Parameters.Add("@IdUtente", OleDbType.VarChar, 32).Value = IdUtente;

				DataSet ds = new DataSet("Societa");
				da.Fill(ds, "Societa");
				return ds;
			}
		}


		private static bool Valid(string s)
		{
			return s != null && s.Length > 0;
		}
	}
}
