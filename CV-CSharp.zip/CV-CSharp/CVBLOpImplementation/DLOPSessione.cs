using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPSessione.
	/// </summary>
	internal class DLOPSessione : DLOPBase
	{
		public DLOPSessione(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public static DataSet DataSet_Sessioni()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("Sessioni");

			DataColumn c;
			c = dt.Columns.Add("IdSessione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = true;

			c = dt.Columns.Add("Titolo", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;  // TODO LEO con true si pianta a causa di titoli uguali tipo aaa e AAA (constraints violato)
			c.DefaultValue = "Titolo";

			c = dt.Columns.Add("DataOraApertura", typeof(DateTime));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("DataOraChiusura", typeof(DateTime));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec10", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec09", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec08", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec07", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec06", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec05", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec04", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec03", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec02", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoCorr", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc02", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc03", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc04", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc05", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc06", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc07", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc08", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc09", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc10", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoConvenzionale", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("DataOraCreazione", typeof(DateTime));
			c.AllowDBNull = false;
			//			c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("DataOraModifica", typeof(DateTime));
			c.AllowDBNull = false;
			//			c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("StatoSessione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("DataCorrispettivo", typeof(DateTime));
			c.AllowDBNull = true;

			dt.PrimaryKey = new DataColumn[] { dt.Columns["IdSessione"] };

			return ds;
		}

		public DataSet GetLista()
		{
			string strSqlQuery = "SELECT RAWTOHEX(IdSessione) AS IdSessione, " + 
				"Titolo, " +
				"DataOraApertura, DataOraChiusura, " +
				"PrezzoRiferimentoAnnoPrec10, " +
				"PrezzoRiferimentoAnnoPrec09, " +
				"PrezzoRiferimentoAnnoPrec08, " +
				"PrezzoRiferimentoAnnoPrec07, " +
				"PrezzoRiferimentoAnnoPrec06, " +
				"PrezzoRiferimentoAnnoPrec05, " +
				"PrezzoRiferimentoAnnoPrec04, " +
				"PrezzoRiferimentoAnnoPrec03, " +
				"PrezzoRiferimentoAnnoPrec02, " +
				"PrezzoRiferimentoAnnoPrec, " +
				"PrezzoRiferimentoAnnoCorr, " +
				"PrezzoRiferimentoAnnoSucc, " +
				"PrezzoRiferimentoAnnoSucc02, " +
				"PrezzoRiferimentoAnnoSucc03, " +
				"PrezzoRiferimentoAnnoSucc04, " +
				"PrezzoRiferimentoAnnoSucc05, " +
				"PrezzoRiferimentoAnnoSucc06, " +
				"PrezzoRiferimentoAnnoSucc07, " +
				"PrezzoRiferimentoAnnoSucc08, " +
				"PrezzoRiferimentoAnnoSucc09, " +
				"PrezzoRiferimentoAnnoSucc10, " +
				"PrezzoConvenzionale, " +
				"DataOraCreazione, " + 
				"DataOraModifica, " +
				"StatoSessione, " +
				"DataCorrispettivo " +	
				"FROM CV.Sessioni " +
				"WHERE StatoSessione = 'Chiusa' OR StatoSessione = 'Terminata' " +
				"ORDER BY DataOraCreazione DESC";
			
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = DataSet_Sessioni();
				da.SelectCommand = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.Fill(ds, "Sessioni");
				return ds;
			}
		}
		
		public bool IsEnabled(string IdSessione)
		{
			// Nella SELECT ho inserito anche la SYSDATE in modo da non dover effettuare un'altra
			// SELECT per recuperare la data di sistema
			string strSqlQuery = "SELECT SYSDATE DataCorrente, " + 
								 "DataOraApertura, DataOraChiusura, StatoSessione " +
								 "FROM cv.Sessioni WHERE IdSessione = HEXTORAW(?)";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsStateSession");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
					da.Fill(ds, "StateSession");
					DataTable dt = ds.Tables["StateSession"];
					if (dt.Rows.Count != 0)
					{
						DateTime currentDate = (DateTime)dt.Rows[0]["DataCorrente"];
						DateTime dataOraApertura = (DateTime)dt.Rows[0]["DataOraApertura"];
						DateTime dataOraChiusura = (DateTime)dt.Rows[0]["DataOraChiusura"];
						string strStatoSessione = (string)dt.Rows[0]["StatoSessione"];

						if ((dataOraApertura <= currentDate) &&
							(dataOraChiusura >= currentDate) &&
							(strStatoSessione != "Sospesa") &&
							(strStatoSessione != "Abortita"))
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					return false;
				}
			}
		}

		public DataSet GetCurrentWebSession()
		{
			string[] aSqlQueries = new string[4];
			
			aSqlQueries[0] = "SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, " +
							 "PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, " +
							 "PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione " +
							 "FROM CV.Sessioni " +
							 "WHERE DataOraApertura <= SYSDATE " +
							 "AND DataOraChiusura >= SYSDATE " +
							 "AND StatoSessione = 'Aperta'";
			aSqlQueries[1] =	"SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, " +
								"PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, " +
								"PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione " +
								"FROM CV.Sessioni " +
								"WHERE DataOraApertura <= SYSDATE " +
								"AND DataOraChiusura >= SYSDATE " +
								"AND StatoSessione = 'Sospesa'";
			aSqlQueries[2] =	"SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, " +
								"PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, " +
								"PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione " +
								"FROM CV.Sessioni " +
								"WHERE DataOraApertura < SYSDATE " +
								"AND DataOraChiusura < SYSDATE " +
								"AND StatoSessione = 'Terminata'";
			aSqlQueries[3] =	"SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, " +
								"PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, " +
								"PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione " +
								"FROM CV.Sessioni " +
								"WHERE (DataOraApertura < SYSDATE " +
								"AND DataOraChiusura < SYSDATE) " +
								"OR StatoSessione = 'Abortita' "+
								"ORDER BY DataOraChiusura DESC";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsWebSession");
				{
					for (int i = 0; i < 4; i++)
					{
						da.SelectCommand = new OleDbCommand(aSqlQueries[i], m_Transaction.Connection, m_Transaction);
						da.Fill(ds, "WebSession");
						if (ds.Tables["WebSession"].Rows.Count != 0)
							return ds;
					}
					return ds;
				}
			}
		}

		public DataSet GetCurrentWebSession2()
		{
			string[] aSqlQueries = new string[3];
			
			aSqlQueries[0] =	"SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, " +
				"PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, " +
				"PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione " +
				"FROM CV.Sessioni " +
				"WHERE DataOraApertura <= SYSDATE " +
				"AND DataOraChiusura >= SYSDATE " +
				"AND StatoSessione = 'Sospesa'";
			aSqlQueries[1] =	"SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, " +
				"PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, " +
				"PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione " +
				"FROM CV.Sessioni " +
				"WHERE DataOraApertura < SYSDATE " +
				"AND DataOraChiusura < SYSDATE " +
				"AND StatoSessione = 'Terminata'";
			aSqlQueries[2] =	"SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, " +
				"PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, " +
				"PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione " +
				"FROM CV.Sessioni " +
				"WHERE (DataOraApertura < SYSDATE " +
				"AND DataOraChiusura < SYSDATE) " +
				"OR StatoSessione = 'Abortita' "+
				"ORDER BY DataOraChiusura DESC";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsWebSession");
				
				for (int i = 0; i < 3; i++)
				{
					da.SelectCommand = new OleDbCommand(aSqlQueries[i], m_Transaction.Connection, m_Transaction);
					da.Fill(ds, "WebSession");
					if (ds.Tables["WebSession"].Rows.Count != 0)
						return ds;
				}
				return ds;
			}
		}

		public DataSet GetDatiSession(string IdSessione)
		{
			string sql = @"
				SELECT 
					RAWTOHEX(IdSessione)IdSessione, 
					Titolo, 
					DataOraApertura, 
					DataOraChiusura,
					PrezzoRiferimentoAnnoPrec10, 
					PrezzoRiferimentoAnnoPrec09, 
					PrezzoRiferimentoAnnoPrec08, 
					PrezzoRiferimentoAnnoPrec07, 
					PrezzoRiferimentoAnnoPrec06, 
					PrezzoRiferimentoAnnoPrec05, 
					PrezzoRiferimentoAnnoPrec04, 
				 	PrezzoRiferimentoAnnoPrec03, 
					PrezzoRiferimentoAnnoPrec02, 
					PrezzoRiferimentoAnnoPrec, 
					PrezzoRiferimentoAnnoCorr, 
					PrezzoRiferimentoAnnoSucc, 
					PrezzoRiferimentoAnnoSucc02, 
					PrezzoRiferimentoAnnoSucc03, 
					PrezzoRiferimentoAnnoSucc04, 
					PrezzoRiferimentoAnnoSucc05, 
					PrezzoRiferimentoAnnoSucc06, 
					PrezzoRiferimentoAnnoSucc07, 
					PrezzoRiferimentoAnnoSucc08, 
					PrezzoRiferimentoAnnoSucc09, 
					PrezzoRiferimentoAnnoSucc10, 
					PrezzoConvenzionale, 
					DataOraCreazione,
					DataOraModifica,
					DataCorrispettivo,
					StatoSessione
				FROM CV.Sessioni 
				WHERE IdSessione = HEXTORAW(?) 
			";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("Sessioni");
				OleDbCommand _cmd = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
				_cmd.Parameters.Add(new OleDbParameter("@IdSessione", OleDbType.VarWChar, 32)) ;
				_cmd.Parameters["@IdSessione"].Value = IdSessione ;
				da.SelectCommand = _cmd ;
				da.Fill(ds, "Sessioni");
				return ds;
			}
		}

		public DataSet GetProssimaSessioneInAttesa()
		{
			string sql = @"
				SELECT 
					RAWTOHEX(IdSessione)IdSessione, 
					Titolo, 
					DataOraApertura, 
					DataOraChiusura,
					PrezzoConvenzionale, 
					StatoSessione
				FROM CV.Sessioni 
				WHERE SYSDATE < DataOraApertura 
				AND StatoSessione = 'In Attesa'
				ORDER BY DataOraApertura ASC
			";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("Sessioni");
				da.SelectCommand = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
				da.Fill(ds, "Sessioni");
				return ds;
			}
		}

		public DataSet GetProssimaSessionePredisposta()
		{
			string sql = @"
				SELECT 
					RAWTOHEX(IdSessione)IdSessione, 
					Titolo, 
					DataOraApertura, 
					DataOraChiusura,
					PrezzoConvenzionale, 
					StatoSessione
				FROM CV.Sessioni 
				WHERE SYSDATE < DataOraApertura 
				AND StatoSessione = 'Predisposta'
				ORDER BY DataOraApertura ASC
			";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("Sessioni");
				da.SelectCommand = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
				da.Fill(ds, "Sessioni");
				return ds;
			}
		}

		public DataSet GetSessioneAperta()
		{
			string sql = @"
				SELECT 
					RAWTOHEX(IdSessione)IdSessione, 
					Titolo, 
					DataOraApertura, 
					DataOraChiusura,
					PrezzoConvenzionale, 
					StatoSessione
				FROM CV.Sessioni 
				WHERE 
				    DataOraApertura <= SYSDATE AND SYSDATE <= DataOraChiusura
				AND StatoSessione = 'Aperta'
			";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("Sessioni");
				da.SelectCommand = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
				da.Fill(ds, "Sessioni");
				return ds;
			}
		}

	}
}
