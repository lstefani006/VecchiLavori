using System;
using System.Text;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPSocieta.
	/// </summary>
	public class BLOPSocieta : CVRemotingBase, IBLOPSocieta
	{		
		public BLOPSocieta()
		{
		}

		/// <summary>
		/// Ritorna la societa' identificata da IdSocieta
		/// oppure tutte le societa' disponibili se IdSocieta=null oppure =""
		/// </summary>
		/// <param name="IdSocieta"></param>
		/// <returns></returns>
		public DataSet GetListaByIdSocieta(string IdSocieta)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DataSet ds = this.GetListaByIdSocieta(tr, IdSocieta);
					tr.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
		internal DataSet GetListaByIdSocieta(IDbTransaction tr, string IdSocieta)
		{
			DLOPSocieta dl = new DLOPSocieta(tr);
			DataSet ds = dl.GetListaByIdSocieta(IdSocieta);
			return ds;
		}

		public bool VerificaPINSoc(string IdRicRegSoc, string PINSoc)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSocieta dl = new DLOPSocieta(dbTran);
					bool ris = dl.VerificaPINSoc(IdRicRegSoc, PINSoc);
					dbTran.Commit();
					return ris;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public bool VerificaPINSoc2(string CodiceConto, string PINSoc)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSocieta dl = new DLOPSocieta(dbTran);
					bool ris = dl.VerificaPINSoc2(CodiceConto, PINSoc);
					dbTran.Commit();
					return ris;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetReportCV(string IdSessione, string IdSocieta)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DataSet ds = this.GetReportCV(tr, IdSessione, IdSocieta);
					tr.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
		internal DataSet GetReportCV(IDbTransaction tr, string IdSessione, string IdSocieta)
		{
			DLOPSocieta dl = new DLOPSocieta(tr);
			DataSet ds = dl.GetReportCV(IdSessione, IdSocieta);
			return ds;
		}

		public byte[] GetDoc(string IdReport)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					byte[] doc = this.GetDoc(tr, IdReport);
					tr.Commit();
					return doc;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
		internal byte[] GetDoc(IDbTransaction tr, string IdReport)
		{
			DLOPSocieta dl = new DLOPSocieta(tr);
			byte[] doc = dl.GetDoc(IdReport);
			return doc;
		}

		public void MarcaDownload(string IdReport)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					this.MarcaDownload(tr, IdReport);
					tr.Commit();
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
		internal void MarcaDownload(IDbTransaction tr, string IdReport)
		{
			DLOPSocieta dl = new DLOPSocieta(tr);
			dl.MarcaDownload(IdReport);
		}

		public string GetRagioneSociale(string IdUtente)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					string strRagioneSociale = _GetRagioneSociale(dbTran, IdUtente);
					dbTran.Commit();
					return strRagioneSociale;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal string _GetRagioneSociale(IDbTransaction dbTran, string IdUtente)
		{
			DLOPSocieta dl = new DLOPSocieta(dbTran);
			string strRagioneSociale = dl.GetRagioneSociale(IdUtente);
			return strRagioneSociale;
		}

		public BankAccount GetBankAccount(string CommonName, string IdSessione)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					BankAccount ba = _GetBankAccount(dbTran, CommonName, IdSessione);
					dbTran.Commit();
					return ba;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal BankAccount _GetBankAccount(IDbTransaction dbTran, string CommonName, string IdSessione)
		{
			DLOPSocieta dl = new DLOPSocieta(dbTran);
			BankAccount ba = dl.GetBankAccount(CommonName, IdSessione);
			return ba;
		}

		
		public DataSet GetCertificates(string CommonName, string IdSessione)
		{		
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _GetCertificates(dbTran, CommonName, IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		internal DataSet _GetCertificates(IDbTransaction dbTran, string CommonName, string IdSessione)
		{
			DLOPSocieta dl = new DLOPSocieta(dbTran);
			DataSet ds = dl.GetCertificates(CommonName, IdSessione);
			return ds;
		}

		
		public decimal GetDisponibilitaAcquisto(string IdSessione, string IdUtente)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					decimal disponibilitaAcquisto = _GetDisponibilitaAcquisto(dbTran, IdSessione, IdUtente);
					dbTran.Commit();
					return disponibilitaAcquisto;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal decimal _GetDisponibilitaAcquisto(IDbTransaction dbTran, string IdSessione, string IdUtente)
		{
			DLOPSocieta dl = new DLOPSocieta(dbTran);
			decimal disponibilitaAcquisto = dl.GetDisponibilitaAcquisto(IdSessione, IdUtente);
			return disponibilitaAcquisto;
		}

		
		public decimal GetDisponibilitaVendita(string IdSessione, string IdUtente, string AnnoRiferimento)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					decimal disponibilitaVendita = _GetDisponibilitaVendita(dbTran, IdSessione, IdUtente, AnnoRiferimento);
					dbTran.Commit();
					return disponibilitaVendita;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		internal decimal _GetDisponibilitaVendita(IDbTransaction dbTran, string IdSessione, string IdUtente, string AnnoRiferimento)
		{
			DLOPSocieta dl = new DLOPSocieta(dbTran);
			decimal disponibilitaVendita = dl.GetDisponibilitaVendita(IdSessione, IdUtente, AnnoRiferimento);
			return disponibilitaVendita;
		}

	
		public bool	Registra(ref InfoSocieta infoS, InfoUtente infoU)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					bool registrata = _Registra(dbTran, ref infoS, infoU);
					dbTran.Commit();
					return registrata;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		public bool	Registra(ref InfoSocieta infoS)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					bool registrata = _Registra(dbTran, ref infoS);
					dbTran.Commit();
					return registrata;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		internal bool _Registra(IDbTransaction dbTran, ref InfoSocieta infoS, InfoUtente infoU)
		{
			DLOPSocieta societa = new DLOPSocieta(dbTran);
			bool registrata = false;
			string idSocieta = societa.Insert(infoS);
			if (idSocieta.Length != 0)
			{
				infoS.IdSocieta = idSocieta;
				infoS.IdSocietaIsNull = false;
				BLOPUtente blopUtente = new BLOPUtente();
				bool utenteRegistrato = blopUtente._Registra(dbTran, idSocieta, ref infoU);
				registrata = (utenteRegistrato ? true : false);
			}
			else
			{
				infoS.IdSocieta = "";
				infoS.IdSocietaIsNull = true;
				registrata = false;
			}
			return registrata;
		}
		internal bool _Registra(IDbTransaction dbTran, ref InfoSocieta infoS)
		{
			DLOPSocieta societa = new DLOPSocieta(dbTran);
			bool registrata = false;
			string idSocieta = societa.Insert(infoS);
			if (idSocieta.Length != 0)
			{
				infoS.IdSocieta = idSocieta;
				infoS.IdSocietaIsNull = false;
				registrata = true;
			}
			else
			{
				infoS.IdSocieta = "";
				infoS.IdSocietaIsNull = true;
				registrata = false;
			}
			return registrata;
		}


		public DataSet GetSocietaPerRegistrazioneUtente()
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSocieta societa = new DLOPSocieta(dbTran);
					DataSet ds = societa.GetSocietaPerRegistrazioneUtente();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetSocietaByIdUtente(string IdUtente)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPSocieta societa = new DLOPSocieta(dbTran);
					DataSet ds = societa.GetSocietaByIdUtente(IdUtente);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

	}
}
