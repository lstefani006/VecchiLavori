using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPBudgets.
	/// </summary>
	internal class DLOPBudgets : DLOPBase
	{
		public DLOPBudgets(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public static DataSet DataSet_Budget()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("Budgets");

			DataColumn c;
			c = dt.Columns.Add("IdSessione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("IdSocieta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("Importo", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("ImportoProposto", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoConvenzionaleUtente", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoConvenzionaleUtenteMw", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("QtyMax", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("QtyImpegnata", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;
			c.DefaultValue = 0M;

			c = dt.Columns.Add("DataOraCreazione", typeof(DateTime));
			c.AllowDBNull = false;
			//OK		c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("Residuo", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("SaldoProposto", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;
	
			dt.PrimaryKey = new DataColumn[] { dt.Columns["IdSocieta"], dt.Columns["IdSessione"] };
			return ds;

		}

		public DataSet Get(string IdSessione, string IdSocieta)
		{
			OleDbDataAdapter da;

			if (Valid(IdSessione) && Valid(IdSocieta))
			{
				OleDbParameter [] pars = new OleDbParameter[2];
				pars[0] = new OleDbParameter("IdSocieta", OleDbType.VarChar);
				pars[0].Value = IdSocieta;
				pars[1] = new OleDbParameter("IdSessione", OleDbType.VarChar);
				pars[1].Value = IdSessione;
				da = GetDataAdapter("WHERE IdSocieta = HEXTORAW(?) AND IdSessione = HEXTORAW(?) ", pars);
			}
			else if (Valid(IdSessione))
			{
				OleDbParameter par = new OleDbParameter();
				par = new OleDbParameter("IdSessione", OleDbType.VarChar);
				par.Value = IdSessione;
				da = GetDataAdapter("WHERE IdSessione = HEXTORAW(?) ", par);
			}
			else if (Valid(IdSocieta))
			{
				OleDbParameter par = new OleDbParameter();
				par = new OleDbParameter("IdSocieta", OleDbType.VarChar);
				par.Value = IdSocieta;
				da = GetDataAdapter("WHERE IdSocieta = HEXTORAW(?) ", par);
			}
			else
			{
				da = GetDataAdapter();
			}

			using (da)
			{
				DataSet ds = DataSet_Budget();
				da.Fill(ds, "Budgets");
				return ds;
			}
		}

		protected OleDbDataAdapter GetDataAdapter()
		{
			return GetDataAdapter(null, (OleDbParameter [])null);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere)
		{
			OleDbParameter [] pars = new OleDbParameter [1];
			pars[0] = parWhere;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere1, OleDbParameter parWhere2)
		{
			OleDbParameter [] pars = new OleDbParameter [2];
			pars[0] = parWhere1;
			pars[1] = parWhere2;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			// Query di SELECT per il Data Adapter
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				// N.B. Lo spazio alla fine della stringa e' MOLTO IMPORTANTE non toglierlo!!!!!
				string sqlCmd = "SELECT RAWTOHEX(IdSocieta) IdSocieta, " + 
					"RAWTOHEX(IdSessione) IdSessione, " + 
					"Importo, " +
					"ImportoProposto, " +
					"SaldoProposto, " +
					"PrezzoConvenzionaleUtente, " + 
					"PrezzoConvenzionaleUtenteMw, " + 
					"QtyMax, " + 
					"QtyImpegnata, " + 
					"DataOraCreazione, " +
					"Residuo " +
					"FROM CV.Budgets ";

				if (Valid(sql))
					sqlCmd += sql;

				cmd.CommandText = sqlCmd;

				if (Valid(sql) && parsWhere != null)
				{
					foreach (OleDbParameter p in parsWhere)
						if (p != null)
							cmd.Parameters.Add(p);
				}

				da.SelectCommand = cmd;
			}

			// INSERT
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText =	"INSERT INTO CV.Budgets (" +
					"Importo, " +
					"ImportoProposto, " +
					"SaldoProposto, " +
					"Residuo, " +
					"IdMovResiduo, " +
					"PrezzoConvenzionaleUtente, " +
					"PrezzoConvenzionaleUtenteMw, " +
					"QtyMax, " +
					"QtyImpegnata, " +
					"DataOraCreazione, " +
					"IdSessione, " +
					"IdSocieta" +
					") VALUES (?, ?, ?, ?, null, ?, ?, ?, ?, SYSDATE, HEXTORAW(?), HEXTORAW(?))";

				cmd.Parameters.Add(new OleDbParameter("Importo",						OleDbType.Decimal,		 0, "Importo"));
				cmd.Parameters.Add(new OleDbParameter("ImportoProposto",				OleDbType.Decimal,		 0, "ImportoProposto"));
				cmd.Parameters.Add(new OleDbParameter("SaldoProposto",					OleDbType.Decimal,		 0, "SaldoProposto"));
				cmd.Parameters.Add(new OleDbParameter("Residuo",						OleDbType.Decimal,       0, "Residuo"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionaleUtente",		OleDbType.Decimal,		 0, "PrezzoConvenzionaleUtente"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionaleUtenteMw",	OleDbType.Decimal,		 0, "PrezzoConvenzionaleUtenteMw"));
				cmd.Parameters.Add(new OleDbParameter("QtyMax",							OleDbType.Decimal,       0, "QtyMax"));
				cmd.Parameters.Add(new OleDbParameter("QtyImpegnata",					OleDbType.Decimal,       0, "QtyImpegnata"));
				cmd.Parameters.Add(new OleDbParameter("IdSessione",		                OleDbType.VarChar,      32, "IdSessione"));
				cmd.Parameters.Add(new OleDbParameter("IdSocieta",		                OleDbType.VarChar,      32, "IdSocieta"));

				da.InsertCommand = cmd;
			}

			// UPDATE
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText = "UPDATE CV.Budgets SET " +
					"Importo = ?, " +
					"ImportoProposto = ?, " +
					"SaldoProposto = ?, " +
					"Residuo = ?, " +
					"PrezzoConvenzionaleUtente = ?, " +
					"PrezzoConvenzionaleUtenteMw = ?, " +
					"QtyMax = ?, " +
					"QtyImpegnata = ? " +
					"WHERE IdSessione = HEXTORAW(?) " +
					"AND IdSocieta = HEXTORAW(?)";
					
				cmd.Parameters.Add(new OleDbParameter("Importo",						OleDbType.Decimal,		 0, "Importo"));
				cmd.Parameters.Add(new OleDbParameter("ImportoProposto",				OleDbType.Decimal,		 0, "ImportoProposto"));
				cmd.Parameters.Add(new OleDbParameter("SaldoProposto",					OleDbType.Decimal,		 0, "SaldoProposto"));
				cmd.Parameters.Add(new OleDbParameter("Residuo",						OleDbType.Decimal,       0, "Residuo"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionaleUtente",		OleDbType.Decimal,		 0, "PrezzoConvenzionaleUtente"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionaleUtenteMw",	OleDbType.Decimal,		 0, "PrezzoConvenzionaleUtenteMw"));
				cmd.Parameters.Add(new OleDbParameter("QtyMax",							OleDbType.Decimal,       0, "QtyMax"));
				cmd.Parameters.Add(new OleDbParameter("QtyImpegnata",					OleDbType.Decimal,       0, "QtyImpegnata"));
				cmd.Parameters.Add(new OleDbParameter("IdSessione",		                OleDbType.VarChar,      32, "IdSessione"));
				cmd.Parameters.Add(new OleDbParameter("IdSocieta",		                OleDbType.VarChar,      32, "IdSocieta"));

				da.UpdateCommand = cmd;
			}

			// DELETE
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("DELETE FROM CV.BUDGETS WHERE IdSessione = HEXTORAW(?) AND IdSocieta = HEXTORAW(?)", m_Transaction.Connection, m_Transaction);
				cmd.CommandType = CommandType.Text;

				OleDbParameter IdSessionePar = new OleDbParameter("IdSessione", OleDbType.VarChar);
				IdSessionePar.SourceColumn = "IdSessione";
				IdSessionePar.SourceVersion = DataRowVersion.Original;
				cmd.Parameters.Add(IdSessionePar);

				OleDbParameter IdSocietaPar = new OleDbParameter("IdSocieta", OleDbType.VarChar);
				IdSocietaPar.SourceColumn = "IdSocieta";
				IdSocietaPar.SourceVersion = DataRowVersion.Original;
				cmd.Parameters.Add(IdSocietaPar);

				da.DeleteCommand = cmd;
			}

			da.MissingSchemaAction = MissingSchemaAction.Error;
			return da;
		}

		public void Update(DataSet ds)
		{
			OleDbDataAdapter da = GetDataAdapter();
			da.Update(ds, "Budgets");
		}


		private static bool Valid(string s)
		{
			return s != null && s.Length > 0;
		}

	}
}
