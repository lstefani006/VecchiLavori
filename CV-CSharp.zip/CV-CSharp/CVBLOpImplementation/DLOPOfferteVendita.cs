using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPOfferteVendita.
	/// </summary>
	internal class DLOPOfferteVendita : DLOPBase
	{
		public DLOPOfferteVendita(IDbTransaction dbTransaction) :  base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}
		public DataSet GetListaByUtente(string IdSessione, string IdUtente)
		{
			//Stefano
			/* La query deve essere modificata per non riferirsi piu` alla tabella MWCERTIFICATO
			string strSqlQuery = "SELECT RAWTOHEX(B.IdOffertaVendita) IdOffertaVendita, " + 
								 "QtyOfferta, QtyResidua, " + 
								 "AnnoRiferimento, B.PrezzoUnitario, B.Compatibile, " +
								 "QtyOfferta - QtyResidua AS QtyEseguita, " +
								 "SUM(A.QtyCertificati * A.PrezzoUnitario)/ SUM (A.qtyCertificati) AS PrezzoMedioEseguito, " +
								 "SUM(A.QtyCertificati * A.PrezzoUnitario * C.QtyMwh) AS Controvalore " +
								 "FROM CV.OfferteVendita B, CV.Transazioni A, CV.MwCertificato C " +
								 "WHERE A.IdOffertaVendita(+) = B.IdOffertaVendita " +
								 "AND B.IdUtente = HEXTORAW(?) " +
								 "AND B.IdSessione = HEXTORAW(?) " +
								 "AND B.AnnoRiferimento = C.Anno " +
								 "GROUP BY B.IdOffertaVendita, B.QtyOfferta, " + 
								 "B.QtyResidua, B.AnnoRiferimento, " + 
								 "B.PrezzoUnitario, C.QtyMwh, " + 
								 "B.Compatibile, B.DataOraCreazione " +
								 "ORDER BY B.AnnoRiferimento, B.DataOraCreazione DESC";
			*/

			//Stefano query modificata !! V E R I F I C A R E !!
			string strSqlQuery = "SELECT RAWTOHEX(B.IdOffertaVendita) IdOffertaVendita, " + 
								"QtyOfferta, QtyResidua, " + 
								"AnnoRiferimento, B.PrezzoUnitario, B.Compatibile, " +
								"QtyOfferta - QtyResidua AS QtyEseguita, " +
								"SUM(A.QtyCertificati * A.PrezzoUnitario)/ SUM (A.qtyCertificati) AS PrezzoMedioEseguito, " +
								"SUM(A.QtyCertificati * A.PrezzoUnitario * " 
								+ (DLOPBase.MWhPerCV).ToString() + 
								@") AS Controvalore " +
								"FROM CV.OfferteVendita B, CV.Transazioni A " +
								"WHERE A.IdOffertaVendita(+) = B.IdOffertaVendita " +
								"AND B.IdUtente = HEXTORAW(?) " +
								"AND B.IdSessione = HEXTORAW(?) " +
								"GROUP BY B.IdOffertaVendita, B.QtyOfferta, " + 
								"B.QtyResidua, B.AnnoRiferimento, " + 
								"B.PrezzoUnitario, " + 
								"B.Compatibile, B.DataOraCreazione " +
								"ORDER BY B.AnnoRiferimento, B.DataOraCreazione DESC";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsListaOfferteVendita");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdUtente", OleDbType.VarChar, 33).Value = IdUtente;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 33).Value = IdSessione;
					da.Fill(ds, "ListaOfferteVendita");
					return ds;
				}
			}
		}

//		public DataSet GetListaNonEseguite(string IdSessione, string IdUtente, string AnnoRiferimento)
//		{
//			string strSqlQuery = "SELECT RAWTOHEX(IdOffertaVendita) IdOffertaVendita, " + 
//								 "QtyOfferta, QtyResidua, AnnoRiferimento, " + 
//								 "PrezzoUnitario, DataOraCreazione, DataOraModifica, " + 
//								 "Compatibile, RAWTOHEX(IdSessione) IdSessione, " + 
//								 "StatoOfferta, RAWTOHEX(IdUtente) IdUtente " +
//								 "FROM CV.OfferteVendita " +
//								 "WHERE IdSessione = HEXTORAW(?) AND " +
//								 "AnnoRiferimento = ? " +
//								 "AND IdUtente = HEXTORAW(?) " + 
//								 "AND QtyResidua <> 0 ORDER BY PrezzoUnitario ASC";
//
//			using (OleDbDataAdapter da = new OleDbDataAdapter())
//			{
//				DataSet ds = new DataSet("dsOfferteVenditaNonEseguite");
//				{
//					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
//					da.SelectCommand = selectCMD;
//					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
//					selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
//					selectCMD.Parameters.Add("@IdUtente", OleDbType.VarChar, 32).Value = IdUtente;
//					
//					da.Fill(ds, "OfferteVenditaNonEseguite");
//					return ds;
//				}
//			}
//		}

		/// <summary>
		/// Ritorna il numero delle offerte di vendita sottomesse da utenti
		/// che non appartengono alla stessa societa di <code>IdUtenteAcq</code>
		/// </summary>
		/// <param name="IdSessione">Sessione in cui si fa la ricerca</param>
		/// <param name="IdUtenteAcq">Utente in ingresso</param>
		/// <param name="AnnoRiferimento">L'anno di riferimento</param>
		/// <returns></returns>
		public decimal GetCount(string IdSessione, string IdUtenteAcq, string AnnoRiferimento)
		{
//			string strSqlQuery = "SELECT COUNT(*) " +
//								 "FROM cv.OfferteVendita " +
//								 "WHERE IdSessione = HEXTORAW(?) " + 
//								 "AND AnnoRiferimento = ? " +
//								 "AND IdUtente <> HEXTORAW(?) " + 
//								 "AND QtyResidua <> 0 AND PrezzoUnitario > 0";


			string IdSocietaAcq;
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = @"
					SELECT RAWTOHEX(IdSocieta) AS IdSocieta
					FROM US.Utenti
					WHERE IdUtente = HEXTORAW(?)
				";
				cmd.Parameters.Add("IdUtente", OleDbType.VarChar).Value = IdUtenteAcq;
				IdSocietaAcq = (string) cmd.ExecuteScalar();
			}


			string strSqlQuery = @"
				SELECT COUNT(*) 
				FROM cv.OfferteVendita OV, US.UTENTI UV
				WHERE OV.IdSessione = HEXTORAW(?) 
				AND OV.AnnoRiferimento = ? 
				AND OV.IdUtente = UV.IdUtente
				AND UV.IdSocieta <> HEXTORAW(?)
				AND OV.QtyResidua <> 0 
				AND OV.PrezzoUnitario > 0
			";
			using(OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 33).Value = IdSessione;
				selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
				selectCMD.Parameters.Add("@IdSocietaAcq", OleDbType.VarChar, 33).Value = IdSocietaAcq;
				return (decimal)selectCMD.ExecuteScalar();
			}
		}
	}
}
