using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPUtente.
	/// </summary>
	internal class DLOPUtente : DLOPBase
	{
		public DLOPUtente(IDbTransaction dbTransaction) : base(dbTransaction)
		{
		}

		public InfoUtente GetIdUtente(string CommonName)
		{
			CommonName = Encrypt(CommonName);

			string strSqlQuery = "SELECT RAWTOHEX(IdUtente) AS IdUtente, " + 
								 "StatoUtente, Nominativo " +
								 "FROM us.Utenti WHERE DN = ?"; // Ok Crypt

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsInfoUtente");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@DN", OleDbType.VarChar, 1023).Value = CommonName; // OK Crypt

					da.Fill(ds, "InfoUtente");
					DataTable dt = ds.Tables["InfoUtente"];
					InfoUtente infoU = new InfoUtente();
					if (dt.Rows.Count != 0)
					{
						if (!dt.Rows[0].IsNull("IdUtente"))
						{
							infoU.IdUtente = (string)dt.Rows[0]["IdUtente"];
							infoU.IdUtenteIsNull = false;
						}
						else
						{
							infoU.IdUtente = "";
							infoU.IdUtenteIsNull = true;
						}

						if (!dt.Rows[0].IsNull("StatoUtente"))
						{
							infoU.StatoUtente = (string)dt.Rows[0]["StatoUtente"];
							infoU.StatoUtenteIsNull = false;
						}
						else
						{
							infoU.StatoUtente = "";
							infoU.StatoUtenteIsNull = true;
						}
						if (!dt.Rows[0].IsNull("Nominativo"))
						{
							infoU.Nominativo = (string)dt.Rows[0]["Nominativo"];
							infoU.NominativoIsNull = false;
						}
						else
						{
							infoU.Nominativo = "";
							infoU.NominativoIsNull = true;
						}
					}
					return infoU;
				}
			}
		}

		public bool IsPINValid(string pin)
		{
			pin = Encrypt(pin);

			string strSqlQuery = "SELECT COUNT(*) " + 
								 "FROM US.Utenti Utenti " +
								 "WHERE DN = ?"; //OK cript

			using (OleDbCommand cmd = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				cmd.Parameters.Add("@DN", OleDbType.VarChar, 1023).Value = pin;
				decimal pinIsPresent = (decimal)cmd.ExecuteScalar();
				return (pinIsPresent == 0 ? false:true);
			}
		}

		public string Insert(string IdRichiestaRegistrazioneSocieta, InfoUtente infoU)
		{
			try
			{
				using(OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
				{
					cmd.CommandText = @"
						select count(*) 
						from us.RichiesteRegUtenti 
						where CodiceFiscale=?
					";

					cmd.Parameters.Add("CodiceFiscale", OleDbType.VarChar).Value = infoU.CodiceFiscale;
					
					decimal r = (decimal)cmd.ExecuteScalar();
					if (r > 0)
						throw new Exception("Errore: e' stato gia' registrato un utente con lo stesso codice fiscale.");
				}




				string DN = Encrypt(infoU.DN); // OK Crypt

				using(OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
				{
					cmd.CommandText = 
						"INSERT INTO us.RichiesteRegUtenti " +
						"( " +
						" IdRichiestaRegUtente, " +
						"Nominativo, " +
						"CodiceFiscale, " +
						"Telefono, " +
						"Fax, " +
						"Email, " +
						"DN, " +  // OK Crypt
						"IdRIchiestaRegSoc, " +
						"TipoUtente) " +
						"VALUES " +
						"( HEXTORAW(?), " +
						"?, " +
						"?, " +
						"?, " +
						"?, " +
						"?, " +
						"?, " +
						"HEXTORAW(?), " +
						"? )";

					Guid g = Guid.NewGuid();
					string guid = g.ToString("N").ToUpper();

					cmd.Parameters.Add("Guid",              OleDbType.VarChar).Value = guid;
					cmd.Parameters.Add("Nominativo",        OleDbType.VarChar).Value = infoU.Nominativo;
					cmd.Parameters.Add("CodiceFiscale",     OleDbType.VarChar).Value = infoU.CodiceFiscale;
					cmd.Parameters.Add("Telefono",          OleDbType.VarChar).Value = infoU.NumTelefono;
					cmd.Parameters.Add("Fax",               OleDbType.VarChar).Value = infoU.Fax;
					cmd.Parameters.Add("Email",             OleDbType.VarChar).Value = infoU.Email;
					cmd.Parameters.Add("DN",                OleDbType.VarChar).Value = DN; // OK Crypt
					cmd.Parameters.Add("IdRIchiestaRegSoc", OleDbType.VarChar).Value = IdRichiestaRegistrazioneSocieta;
					cmd.Parameters.Add("TipoUtente",        OleDbType.VarChar).Value = infoU.TipoUtente;

					cmd.ExecuteNonQuery();

					return guid;
				}
			}
			catch(OleDbException exc)
			{
				throw new ApplicationException("Registrazione non effettuata: Certificato gi� usato per un'altra registrazione", exc);
			}
		}
	}
}
