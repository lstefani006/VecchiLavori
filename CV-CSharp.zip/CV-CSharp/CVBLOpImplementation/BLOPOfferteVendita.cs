using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPOfferteVendita.
	/// </summary>
	public class BLOPOfferteVendita : CVRemotingBase, IBLOPOfferteVendita
	{
		public BLOPOfferteVendita()
		{
		}

		public DataSet GetListaByUtente(string IdSessione, string IdUtente)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _GetListaByUtente(dbTran, IdSessione, IdUtente);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal DataSet _GetListaByUtente(IDbTransaction dbTran, string IdSessione, string IdUtente)
		{
			DLOPOfferteVendita dl = new DLOPOfferteVendita(dbTran);
			DataSet ds = dl.GetListaByUtente(IdSessione, IdUtente);
			return ds;
		}

		
		public decimal GetCount(string IdSessione, string IdUtente, string AnnoRiferimento)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					decimal numOfferteVendita = _GetCount(dbTran, IdSessione, IdUtente, AnnoRiferimento);
					dbTran.Commit();
					return numOfferteVendita;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}	
		}

		internal decimal _GetCount(IDbTransaction dbTran, string IdSessione, string IdUtente, string AnnoRiferimento)
		{
			DLOPOfferteVendita dl = new DLOPOfferteVendita(dbTran);
			decimal numOfferteVendita = dl.GetCount(IdSessione, IdUtente, AnnoRiferimento);
			return numOfferteVendita;
		}

	
//		public DataSet GetListaNonEseguite(string IdSessione, string IdUtente, string AnnoRiferimento)
//		{
//			using (IDbConnection cn = DLOPCommon.GetDBConnection())
//			{
//				cn.Open();
//				IDbTransaction dbTran = cn.BeginTransaction();
//				try
//				{
//					DataSet ds = _GetListaNonEseguite(dbTran, IdSessione, IdUtente, AnnoRiferimento);
//					dbTran.Commit();
//					return ds;
//				}
//				catch(Exception exc)
//				{
//					dbTran.Rollback();
//					throw exc;
//				}
//			}
//		}
//		
//		internal DataSet _GetListaNonEseguite(IDbTransaction dbTran, string IdSessione, string IdUtente, string AnnoRiferimento)
//		{
//			DLOPOfferteVendita dl = new DLOPOfferteVendita(dbTran);
//			DataSet ds = dl.GetListaNonEseguite(IdSessione, IdUtente, AnnoRiferimento);
//			return ds;
//		}
	}
}
