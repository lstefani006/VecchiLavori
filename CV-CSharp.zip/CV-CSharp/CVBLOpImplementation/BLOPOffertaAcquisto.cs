using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPOffertaAcquisto.
	/// </summary>
	public class BLOPOffertaAcquisto : CVRemotingBase, IBLOPOffertaAcquisto
	{
		public BLOPOffertaAcquisto()
		{
		}

		public void Delete(string IdOffertaAcquisto, string Firma)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					_Delete(dbTran, IdOffertaAcquisto, Firma);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		internal void _Delete(IDbTransaction dbTran, string IdOffertaAcquisto, string Firma)
		{
			// Prelevo le informazioni dell'offerta di acquisto
			InfoOffertaAcquisto infoOA = Get(IdOffertaAcquisto);

			DLOPOffertaAcquisto dl = new DLOPOffertaAcquisto(dbTran);
			dl.Delete(IdOffertaAcquisto, Firma);
			dl.UpdateQtyImpegnata(infoOA.IdUtente, infoOA.IdSessione, infoOA.QtyRichiesta, "Diminuita");
			return;
		}

	
		public void DeleteIncompatible(string IdOffertaAcquisto, string Firma)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					_DeleteIncompatible(dbTran, IdOffertaAcquisto, Firma);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		internal void _DeleteIncompatible(IDbTransaction dbTran, string IdOffertaAcquisto, string Firma)
		{
			DLOPOffertaAcquisto dl = new DLOPOffertaAcquisto(dbTran);
			dl.DeleteIncompatible(IdOffertaAcquisto, Firma);
			return;
		}
		
		
		public InfoOffertaAcquisto Get(string IdOffertaAcquisto)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					InfoOffertaAcquisto infoOA = _Get(dbTran, IdOffertaAcquisto);
					dbTran.Commit();
					return infoOA;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		
		internal InfoOffertaAcquisto _Get(IDbTransaction dbTran, string IdOffertaAcquisto)
		{
			DLOPOffertaAcquisto dl = new DLOPOffertaAcquisto(dbTran);
			InfoOffertaAcquisto infoOA = dl.Get(IdOffertaAcquisto);
			return infoOA;
		}

		
		public int Modifica(string IdOffertaAcquisto, decimal NuovoPrezzo, decimal NuovaQtyResidua, decimal OldQtyResidua, string Firma)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					// Creo le istanze delle classi BL che mi servono
					BLOPOfferteVendita blopOfferteVendita = new BLOPOfferteVendita();
					BLOPSocieta blopSocieta = new BLOPSocieta();
					
					DLOPOffertaAcquisto dlopOffertaAcquisto = new DLOPOffertaAcquisto(dbTran);
					
					InfoOffertaAcquisto infoOA = Get(IdOffertaAcquisto);

					decimal NewQtyRichiesta = NuovaQtyResidua + infoOA.QtyRichiesta - infoOA.QtyResidua;
					decimal numOfferteVendita = 0M;
					decimal diffQty = 0M;
					decimal disponibilita = 0M;
					decimal qty = 0M;
					int retVal = 0;
					bool operazioneOK = true;
					if (NuovoPrezzo == 0)
					{
						numOfferteVendita = blopOfferteVendita._GetCount(dbTran, infoOA.IdSessione, infoOA.IdUtente, infoOA.AnnoRiferimento);
						if (numOfferteVendita > 0)
						{
							if (NewQtyRichiesta > infoOA.QtyRichiesta)
							{
								diffQty = NewQtyRichiesta - infoOA.QtyRichiesta;
								disponibilita = blopSocieta._GetDisponibilitaAcquisto(dbTran, infoOA.IdSessione, infoOA.IdUtente);
								if (disponibilita >= diffQty)
								{
									qty = dlopOffertaAcquisto.Modifica(IdOffertaAcquisto, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
									if (qty == 1)
									{
										dlopOffertaAcquisto.UpdateQtyImpegnata(infoOA.IdUtente, infoOA.IdSessione, diffQty, "Maggiorata");
									}
									else
									{
										// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
										retVal = -1;
										operazioneOK = false;
									}
								}
								else
								{
									// Quantita' non acquistabile
									retVal = -2;
									operazioneOK = false;
								}
							}
							else if (NewQtyRichiesta < infoOA.QtyRichiesta)
							{
								diffQty = infoOA.QtyRichiesta - NewQtyRichiesta;
								qty = dlopOffertaAcquisto.Modifica(IdOffertaAcquisto, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
								if (qty == 1)
								{
									dlopOffertaAcquisto.UpdateQtyImpegnata(infoOA.IdUtente, infoOA.IdSessione, diffQty, "Diminuita");
								}
								else
								{
									// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
									retVal = -1;
									operazioneOK = false;
								}
							}
							else if (NewQtyRichiesta == infoOA.QtyRichiesta)
							{
								qty = dlopOffertaAcquisto.Modifica(IdOffertaAcquisto, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
								if (qty != 1)
								{
									// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
									retVal = -1;
									operazioneOK = false;
								}
							}
						}
						else
						{
							// Impossibile effettuare la modifica
							retVal = -3;
							operazioneOK = false;
						}
					}
					else
					{
						if (NewQtyRichiesta > infoOA.QtyRichiesta)
						{
							diffQty = NewQtyRichiesta - infoOA.QtyRichiesta;
							disponibilita = blopSocieta._GetDisponibilitaAcquisto(dbTran, infoOA.IdSessione, infoOA.IdUtente);
							if (disponibilita >= diffQty)
							{
								qty = dlopOffertaAcquisto.Modifica(IdOffertaAcquisto, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
								if (qty == 1)
								{
									dlopOffertaAcquisto.UpdateQtyImpegnata(infoOA.IdUtente, infoOA.IdSessione, diffQty, "Maggiorata");
								}
								else
								{
									// Impossibile effettuare una modifica in quanto c'e' stata una variazione nella Quantita' Eseguita
									retVal = -1;
									operazioneOK = false;
								}
							}
							else
							{
								// Quantita' non acquistabile
								retVal = -2;
								operazioneOK = false;
							}
						}
						else if (NewQtyRichiesta < infoOA.QtyRichiesta)
						{
							diffQty = infoOA.QtyRichiesta - NewQtyRichiesta;
							qty = dlopOffertaAcquisto.Modifica(IdOffertaAcquisto, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
							if (qty == 1)
							{
								dlopOffertaAcquisto.UpdateQtyImpegnata(infoOA.IdUtente, infoOA.IdSessione, diffQty, "Diminuita");
							}
							else
							{	
								// Impossibile effettuare una modifica in quanto c'� stata una variazione nella Quantit� Eseguita
								retVal = -1;
								operazioneOK = false;
							}
						}
						else if (NewQtyRichiesta == infoOA.QtyRichiesta)
						{
							qty = dlopOffertaAcquisto.Modifica(IdOffertaAcquisto, NuovoPrezzo, NuovaQtyResidua, OldQtyResidua, Firma);
							if (qty != 1)
							{
								// Impossibile effettuare una modifica in quanto c'� stata una variazione nella Quantit� Eseguita
								retVal = -1;
								operazioneOK = false;
							}
						}
					}
					if ((NuovaQtyResidua != 0) && (operazioneOK) && (qty != 0))
					{
						BLOPOfferte blopOfferte = new BLOPOfferte();
						int ris = blopOfferte._Abbinamento(dbTran, "Acquisto", IdOffertaAcquisto, infoOA.IdUtente);
						// 0  = Tutto Ok
						// -5 = Offerta totalmente incompatibile
						// -6 = Offerta parzialmente incompatibile
						if (ris != 0) retVal = ris ;
					}
					dbTran.Commit();
					return retVal;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
	}
}
