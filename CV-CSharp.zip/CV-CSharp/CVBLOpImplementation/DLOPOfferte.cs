using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for DLOPOfferte.
	/// </summary>
	internal class DLOPOfferte : DLOPBase
	{
		public DLOPOfferte(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public int OffertaAcquistoAbbinamento(string IdOffertaAcquisto, string IdUtente)
		{
			// 0  = Tutto Ok
			// -5 = Offerta totalmente incompatibile
			// -6 = Offerta parzialmente incompatibile
			int ris = 0 ;

			// per scrivere di meno...
			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;


			// dichiarazioni di variabili
			decimal loc_QtyAbbinata = 0m;
			decimal loc_QtyResiduaVendita = 0m;
			decimal loc_QtyResiduaAcquisto = 0m;
			decimal loc_PrezzoAcquisto = 0m;

			// carico i dati dell'offerta di vendita appena inserita.
			// Lock del record.
			decimal loc_OAcq_QtyResidua;
			decimal loc_OAcq_PrezzoUnitario;
			string  loc_OAcq_IdSessione;
			string  loc_OAcq_AnnoRiferimento;
			// Dichiaro un cursore per le OfferteAcquisto
			// In particolare si tratta della sola offerta d�acquisto appena inserita
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
					SELECT 
						QtyResidua, 
						PrezzoUnitario, 
						RAWTOHEX(IdSessione) AS IdSessione, 
						AnnoRiferimento
					FROM   cv.OfferteAcquisto
					WHERE  IdOffertaAcquisto = HEXTORAW(?)
					FOR UPDATE
				";
				Par(cmd, "in_IdOffertaAcquisto", IdOffertaAcquisto);

				using (OleDbDataReader r = cmd.ExecuteReader())
				{
					if (r.Read() == false)
						return ris;

					// i campi letti non possono essere null --> leggo direttamente il valore
					loc_OAcq_QtyResidua      = (decimal)r[0];
					loc_OAcq_PrezzoUnitario  = (decimal)r[1];
					loc_OAcq_IdSessione      = (string) r[2];
					loc_OAcq_AnnoRiferimento = (string) r[3];
				}
			}

			// Ricavo i dati di budget della societ� rappresentata dall�utente che ha
			// sottomesso l�offerta
			string loc_IdSocieta_Acq = null;
			decimal loc_PrezzoConvUtenteMw_Acq = 0m;
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				// se l'utente sta sottoponendo un offerta di Acquisto
				// deve avere il budget --> ha il PrezzoConvenzionaleUtenteMw
				cmd.CommandText = @"
				SELECT 
					RAWTOHEX(C.IdSocieta) AS IdSocieta, 
					A.PrezzoConvenzionaleUtenteMw AS PrezzoConvenzionaleUtenteMw
				FROM CV.Budgets A, US.Utenti B, US.Societa C
				WHERE B.IdSocieta = C.IdSocieta AND
					A.IdSocieta = C.IdSocieta AND
					B.IdUtente = HEXTORAW(?) AND
					A.IdSessione = HEXTORAW(?)
				";

				Par(cmd, "in_IdUtente", IdUtente);
				Par(cmd, "loc_OAcq_IdSessione", loc_OAcq_IdSessione);

				using (OleDbDataReader r = cmd.ExecuteReader())
				{
					if (r.Read())
					{
						if (r.IsDBNull(0))
							throw new Exception("non trovo l'id della societa'");
						if (r.IsDBNull(1))
							throw new Exception("non trovo il prezzo convenzionale");

						loc_IdSocieta_Acq = (string)r[0];
						loc_PrezzoConvUtenteMw_Acq = (decimal)r[1];
					}
					else
						throw new Exception("non trovo i dati di Societa/Budget");
				}
			}

			loc_QtyResiduaAcquisto = loc_OAcq_QtyResidua;
			loc_PrezzoAcquisto = loc_OAcq_PrezzoUnitario;


			// Se ho presentato un�offerta a mercato 
			// (ossia senza indicazione del Prezzo Unitario proposto di acquisto), 
			// cerco il prezzo minimo fra le offerte di
			// vendita sottomesse dallo stesso utente o da utenti della stessa societa
			// altrimenti uso il prezzo indicato nell�offerta d�acquisto 
			decimal loc_PrezzoAppoggio;
			bool loc_PrezzoAppoggioNull;
			if (loc_OAcq_PrezzoUnitario == 0m)
			{
				// offerta a mercato
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
					SELECT MIN(OV.PrezzoUnitario) AS PrezzoUnitarioMin
					FROM cv.OfferteVendita OV, US.Utenti U
					WHERE   OV.IdSessione      = HEXTORAW(?)
						AND U.IdUtente         = OV.IdUtente
						AND U.IdSocieta        = HEXTORAW(?)
						AND OV.AnnoRiferimento = ? 
						AND OV.QtyResidua      <> 0
						AND OV.Compatibile     <> 0
					";

					Par(cmd, "loc_OAcq_IdSessione",      loc_OAcq_IdSessione);
					Par(cmd, "loc_IdSocieta_Acq",        loc_IdSocieta_Acq);
					Par(cmd, "loc_OAcq_AnnoRiferimento", loc_OAcq_AnnoRiferimento);

					using (OleDbDataReader r = cmd.ExecuteReader())
					{
						if (r.Read() == true && r.IsDBNull(0) == false)
						{
							loc_PrezzoAppoggioNull = false;
							loc_PrezzoAppoggio = (decimal) r[0];
						}
						else
						{
							// E SE NON HO PRESENTATO OFFERTE DI VENDITA? 
							// allora loc_PrezzoAppoggio e' NULL e lo tratto poi
							loc_PrezzoAppoggioNull = true;
							loc_PrezzoAppoggio = 0m; // lo assegno per evitare che il compilatore dopo dia warning
						}
					}
				}
			}
			else
			{
				loc_PrezzoAppoggioNull = false;
				loc_PrezzoAppoggio = loc_OAcq_PrezzoUnitario;
			}

			const decimal bruttoNumero = 922337203685477.5807m;

			decimal loc_PrezzoCompatibile;
			if (loc_PrezzoAppoggioNull)
				loc_PrezzoCompatibile = bruttoNumero;
			else
			{
				// A questo punto vado a cercare il prezzo minimo fra le offerte di
				// vendita sottomesse dallo stesso utente, con prezzo inferiore o uguale a quello
				// ricavato al passo precedente
				// Prezzo Min tra quelli di vendita
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						SELECT MIN(OV.PrezzoUnitario) AS loc_PrezzoCompatibile 
						FROM cv.OfferteVendita OV, us.Utenti U
						WHERE OV.IdSessione = HEXTORAW(?) AND
						OV.IdUtente = U.IdUtente AND
						U.IdSocieta = HEXTORAW(?) AND
						OV.AnnoRiferimento = ? AND
						OV.PrezzoUnitario <= ?
						AND OV.QtyResidua <> 0
						AND OV.Compatibile <> 0
					";

					Par(cmd, "loc_OAcq_IdSessione", loc_OAcq_IdSessione);
					Par(cmd, "loc_IdSocieta_Acq", loc_IdSocieta_Acq);
					Par(cmd, "loc_OAcq_AnnoRiferimento", loc_OAcq_AnnoRiferimento);
					Par(cmd, "loc_PrezzoAppoggio", loc_PrezzoAppoggio);

					using (OleDbDataReader r = cmd.ExecuteReader())
					{
						if (r.Read() == true && r.IsDBNull(0) == false)
						{
							loc_PrezzoCompatibile = (decimal) r[0];
						}
						else
							loc_PrezzoCompatibile = bruttoNumero;
					}

					// L�obiettivo � individuare un PrezzoCompatibile, ossia il minimo prezzo
					// dichiarato in una offerta di vendita dello stesso utente a prezzo inferiore
					// a quello dichiarato nell�offerta di acquisto. Tale valore �
					// impostato ad un valore massimo nel caso in cui non esistano offerte di
					// vendita dello stesso utente.	
				}
			}


			// Se la precedente ricerca ha individuato un record, OSSIA ESISTE UN�OFFERTA
			// DI VENDITA, EMESSA DALLO STESSO UTENTE, CON PREZZO INFERIORE A QUELLO
			// DICHIARATO NELL�OFFERTA D�ACQUISTO, dichiaro l�offerta NON COMPATIBILE
			decimal loc_Compatibile;
			if (loc_PrezzoCompatibile != bruttoNumero)
				loc_Compatibile = 0m;
			else
				loc_Compatibile = 1m;
			

			// Dichiaro un cursore per le OfferteVendita
			// In ogni caso, la ricerca avviene fra quelle sottomesse da
			// utenti non appartenenti alla stessa societa
			// In ogni caso escludo le offerte precedentemente dichiarate NON COMPATIBILI (?).
			// Inoltre lavoro solo con quelle offerte a prezzo inferiore al PrezzoCompatibile
			// calcolato in precedenza. QUESTO SIGNIFICA CHE CONSIDERO LA PILA DELLE OFFERTE
			// DI VENDITA SOLO FINO A QUELLE A PREZZO PARI A QUELLO INDICATO NELLA PI�
			// CONVENIENTE IMMESSA DALLO STESSO UTENTE (mi pare che sia ragionevole).
			decimal loc_PrezzoAcq_SUP;
			decimal loc_PrezzoAcq_INF;
			if (loc_PrezzoAcquisto > 0)
			{
				loc_PrezzoAcq_SUP = loc_PrezzoAcquisto;
				loc_PrezzoAcq_INF = -1;
			}
			else
			{
				loc_PrezzoAcq_SUP = 999999999999999.9999m;
				loc_PrezzoAcq_INF = 0;
			}

			// ricerca delle offerte di vendita
			// NOTARE che la ricerca avviene con Compatibile <> 0
			DataSet dsOVen = new DataSet();
			using (OleDbDataAdapter daOVen = new OleDbDataAdapter())
			{
				DataTable dtOVen = dsOVen.Tables.Add("OVen");
				dtOVen.Columns.Add("IdOffertaVendita", typeof(string));
				dtOVen.Columns.Add("QtyResidua", typeof(decimal));
				dtOVen.Columns.Add("PrezzoUnitario", typeof(decimal));

				OleDbCommand cmd = new OleDbCommand("", cn, tr);
				daOVen.SelectCommand = cmd;

				cmd.CommandText = @"
					SELECT
						RAWTOHEX(OV.IdOffertaVendita) AS IdOffertaVendita, 
						OV.QtyResidua, 
						OV.PrezzoUnitario 
					FROM cv.OfferteVendita OV, us.Utenti UVen
					WHERE OV.IdSessione = HEXTORAW(?)
					AND	OV.AnnoRiferimento = ? 
					AND OV.QtyResidua <> 0 
					AND	OV.IdUtente = UVen.IdUtente
					AND UVen.IdSocieta <> HEXTORAW(?)
					AND	OV.PrezzoUnitario > ? 
					AND	OV.PrezzoUnitario <= ?
					AND	OV.PrezzoUnitario < ? 
					AND	OV.Compatibile <> 0
					ORDER BY OV.PrezzoUnitario ASC, OV.DataOraModifica ASC
					FOR UPDATE
				";

				Par(cmd, "loc_OAcq_IdSessione", loc_OAcq_IdSessione);
				Par(cmd, "loc_OAcq_AnnoRiferimento", loc_OAcq_AnnoRiferimento);
				Par(cmd, "in_IdSocieta", loc_IdSocieta_Acq);
				Par(cmd, "loc_PrezzoAcq_INF", loc_PrezzoAcq_INF);
				Par(cmd, "loc_PrezzoAcq_SUP", loc_PrezzoAcq_SUP);
				Par(cmd, "loc_PrezzoCompatibile", loc_PrezzoCompatibile);

				daOVen.Fill(dsOVen, "OVen");
			}

			CV.DiagnosticHelper.DataSetDump("OffertaAcquistoAbbinamento - dsOVen", dsOVen);

			decimal loc_OVen_PrezzoUnitario = 0m;
			foreach (DataRow drOVen in dsOVen.Tables[0].Rows)
			{
				string loc_OVen_IdOffertaVendita = (string)  drOVen[0];
				decimal loc_OVen_QtyResidua      = (decimal) drOVen[1];
				loc_OVen_PrezzoUnitario  =         (decimal) drOVen[2];

				// Esco dal loop se non ho altre offerte di vendita.
				// Esco dal loop se non ho pi� nulla da acquistare
				// Esco dal loop se il prezzo di vendita � superiore al prezzo di
				// acquisto (questa cosa, forse, � superflua [sono d�accordo - GL], 
				// in quanto dovrebbe essere controllata dal WHERE della SELECT).
				if (loc_QtyResiduaAcquisto == 0m)
					break;

				if (loc_OVen_PrezzoUnitario > loc_PrezzoAcquisto && loc_PrezzoAcquisto > 0m)
					break;

				// Ho una offerta di vendita abbinabile con la mia offerta di acquisto.
				// Si abbina la quantit� residua minima fra le due.
				if (loc_QtyResiduaAcquisto <= loc_OVen_QtyResidua)
					loc_QtyAbbinata = loc_QtyResiduaAcquisto;
				else
					loc_QtyAbbinata = loc_OVen_QtyResidua;

				// Calcolo le nuove quantit� residue.
				// una delle 2 va a zero. 
				// L�altra viene decrementata di QtyAbbinata. 
				// Poteva essere fatto + agevolmente nell�IF precedente.

				loc_QtyResiduaAcquisto = loc_QtyResiduaAcquisto - loc_QtyAbbinata;
				loc_QtyResiduaVendita = loc_OVen_QtyResidua - loc_QtyAbbinata;

				// Inserisco la transazione di compravendita
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						INSERT INTO cv.Transazioni
							(QtyCertificati, 
							PrezzoUnitario, 
							IdOffertaVendita, 
							IdOffertaAcquisto)
						VALUES 
							(?, 
							?, 
							HEXTORAW(?),
							HEXTORAW(?))
					";

					Par(cmd, "loc_QtyAbbinata", loc_QtyAbbinata);
					Par(cmd, "loc_OVen_PrezzoUnitario", loc_OVen_PrezzoUnitario);
					Par(cmd, "loc_OVen_IdOffertaVendita", loc_OVen_IdOffertaVendita);
					Par(cmd, "in_IdOffertaAcquisto", IdOffertaAcquisto);

					cmd.ExecuteNonQuery();
				}


				// Aggiorno la quantit� residua di vendita
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						UPDATE cv.OfferteVendita
						SET QtyResidua = ?
						WHERE IdOffertaVendita = HEXTORAW(?)
					";

					Par(cmd, "loc_QtyResiduaVendita", loc_QtyResiduaVendita);
					Par(cmd, "IdOffertaVendita", loc_OVen_IdOffertaVendita);

					cmd.ExecuteNonQuery();
				}

				// Aggiorno il numero di certificati vendibili (avendone acquistati,
				// ne ho di pi�). MI CHIEDO COME MAI NON VENGA AGGIORNATA QUESTA
				// QUANTIT� PER LA SOCIET� CHE HA VENDUTO!?!?!?
				if (loc_OVen_PrezzoUnitario <= loc_PrezzoConvUtenteMw_Acq)
				{
					using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
					{
						cmd.CommandText = @"
							UPDATE cv.CertificatiVerdi
							SET Qty = Qty + ?
							WHERE IdSocieta = HEXTORAW(?)
							AND IdSessione = HEXTORAW(?) 
							AND AnnoRiferimento = ?
						";

						Par(cmd, "loc_QtyAbbinata", loc_QtyAbbinata);
						Par(cmd, "loc_IdSocieta", loc_IdSocieta_Acq);
						Par(cmd, "loc_OAcq_IdSessione", loc_OAcq_IdSessione);
						Par(cmd, "loc_OAcq_AnnoRiferimento", loc_OAcq_AnnoRiferimento);

						cmd.ExecuteNonQuery();
					}
				}

				// Se una offerta al meglio � stata abbinata parzialmente, di qui in poi
				// si assume di avere a che fare con una offerta con limite di prezzo
				// pari al prezzo della transazione appena eseguita.
				if (loc_OAcq_PrezzoUnitario == 0m)
				{
					loc_PrezzoAcquisto = loc_OVen_PrezzoUnitario;
					// All�uscita dal loop conterra� il prezzo unitario a cui e� stata
					// effettuato l�ultima transazione parziale (ossia il piu� alto, essendo le 
					// offerte di vendita ordinate per prezzo crescente).
				}
			}

			if (loc_OAcq_PrezzoUnitario == 0m)
			{
				// Caso di offerta al meglio

				if (loc_PrezzoAcquisto == 0m)
				{
					// Non si e� trovato abbinamento, neppure per quantita� parziale
					loc_Compatibile = 0m;
				}
				else
				{
					// Si e� trovato abbinamento, anche per quantita� parziale
					loc_Compatibile = 1m;
				}

				// Aggiorno la quantit� residua di acquisto
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						UPDATE cv.OfferteAcquisto
						SET QtyResidua     = ?,
							PrezzoUnitario = ?,
							Compatibile    = ?
						WHERE IdOffertaAcquisto = HEXTORAW(?)
					";

					Par(cmd, "loc_QtyResiduaAcquisto", loc_QtyResiduaAcquisto);
					Par(cmd, "loc_PrezzoAcquisto",     loc_PrezzoAcquisto);
					Par(cmd, "loc_Compatibile",        loc_Compatibile);
					Par(cmd, "IdOffertaAcquisto",      IdOffertaAcquisto);

					cmd.ExecuteNonQuery();
				}

				loc_OAcq_PrezzoUnitario = loc_OVen_PrezzoUnitario;
			}
			else
			{
				// Caso di offerta con proposta di prezzo

				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
						UPDATE cv.OfferteAcquisto
						SET QtyResidua = ?,
						Compatibile = ?
						WHERE IdOffertaAcquisto = HEXTORAW(?)
					";

					Par(cmd, "loc_QtyResiduaAcquisto", loc_QtyResiduaAcquisto);
					Par(cmd, "loc_Compatibile",        loc_Compatibile);
					Par(cmd, "IdOffertaAcquisto",      IdOffertaAcquisto);

					cmd.ExecuteNonQuery();
				}
			}

			// Modifica effettuata da Sandro
			if ((loc_QtyResiduaAcquisto == loc_OAcq_QtyResidua) && (loc_Compatibile == 0m))
			{
				ris = -5 ; // Offerta totalmente incompatibile
			}
			if ((loc_QtyResiduaAcquisto < loc_OAcq_QtyResidua) && (loc_Compatibile == 0m) && (loc_QtyResiduaAcquisto != 0))
			{
				ris = -6 ; // Offerta parzialmente incompatibile
			}
			// Fine modifica
		
			if (loc_Compatibile == 0m)
			{
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
					UPDATE CV.Budgets
					SET QtyImpegnata = QtyImpegnata - ?
					WHERE IdSocieta = ?
					AND IdSessione = ?
					";

					Par(cmd, "loc_QtyResiduaAcquisto", loc_QtyResiduaAcquisto);
					Par(cmd, "loc_IdSocieta", loc_IdSocieta_Acq);
					Par(cmd, "loc_OAcq_IdSessione", loc_OAcq_IdSessione);

					cmd.ExecuteNonQuery();
				}
			}

			return ris;
		}

		private static void Par(OleDbCommand cmd, string pName, string pValue)
		{
			cmd.Parameters.Add(pName, OleDbType.VarChar).Value = pValue;
		}
		private static void Par(OleDbCommand cmd, string pName, decimal pValue)
		{
			cmd.Parameters.Add(pName, OleDbType.Decimal).Value = pValue;
		}

		public int OffertaVenditaAbbinamento(string IdOffertaVendita, string IdUtente)
		{
			// 0  = Tutto Ok
			// -5 = Offerta totalmente incompatibile
			// -6 = Offerta parzialmente incompatibile
			int ris = 0 ;

			// dichiarazioni di variabili
			decimal loc_QtyAbbinata = 0m;
			decimal loc_QtyResiduaVendita = 0m;
			decimal loc_QtyResiduaAcquisto = 0m;
			decimal loc_PrezzoVendita = 0m;

			decimal loc_PrezzoConvUtenteMw = 0m;

			decimal loc_PrezzoCompatibile = 0m;
			decimal loc_flag = 0m;

			decimal loc_PrezzoVend_INF = 0m;
			decimal loc_PrezzoVend_OR = 0m;

			OleDbConnection cn = m_Transaction.Connection;
			OleDbTransaction tr = m_Transaction;


			// carico i dati dell'offerta di vendita appena inserita.
			// Lock del record.
			decimal loc_OVen_QtyResidua;
			decimal loc_OVen_PrezzoUnitario;
			string  loc_OVen_IdSessione;
			string  loc_OVen_AnnoRiferimento;
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
					SELECT 
						QtyResidua, 
						PrezzoUnitario, 
						RAWTOHEX(IdSessione) AS IdSessione, 
						AnnoRiferimento 
					FROM CV.OfferteVendita 
					WHERE IdOffertaVendita = HEXTORAW(?)
					FOR UPDATE
					";
				Par(cmd, "IdOffertaVendita", IdOffertaVendita);

				using (OleDbDataReader r = cmd.ExecuteReader())
				{
					if (r.Read() == false)
						return ris;

					loc_OVen_QtyResidua      = (decimal)r["QtyResidua"];
					loc_OVen_PrezzoUnitario  = (decimal)r["PrezzoUnitario"];
					loc_OVen_IdSessione      = (string) r["IdSessione"];
					loc_OVen_AnnoRiferimento = (string) r["AnnoRiferimento"];
				}
			}

			loc_QtyResiduaVendita = loc_OVen_QtyResidua;
			loc_PrezzoVendita     = loc_OVen_PrezzoUnitario;


			// Aggiunta per .NET
			// ricavo la societa di chi vende
			// in modo da fare le seguenti query per "la stessa societa di chi vende" o
			// per "una societa' diversa da chi vende"
			string loc_OVen_IdSocieta = null;
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
				SELECT RAWTOHEX(IdSocieta) AS IdSocieta
				FROM US.Utenti
				WHERE IdUtente = HEXTORAW(?)
				";

				Par(cmd, "in_IdUtente", IdUtente);
				loc_OVen_IdSocieta = (string)cmd.ExecuteScalar();
			}


			// Mi ricavo il max PrezzoUnitario fra le offerte di acquisto
			// a) vecchia versione: dello stesso utente
			// b) versione attuale: degli utenti appartenti alla stessa societa di chi vende
			// per la stessa sessione e con prezzo maggiore dell'attuale offerta
			// di vendita --> ottengo il PrezzoCompatibile
			//
			// Questo prezzo impone che questa vendita non potra' essere
			// fatta ad un prezzo minore del prezzo di eventuali offerte di acquisto
			// dello stesso utente.
			// Es.
			// offerta vendita prezzo unitario 100 /*cento*/
			// offerte acquisto prezzo unitario 80 90 120
			// --> siccome vuole acquistare a 120 non permetto che venda
			//     ad un prezzo minore di 120 (anche se ha specificato 100)
			loc_PrezzoCompatibile = 0m;
			using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
			{
				cmd.CommandText = @"
						SELECT MAX(OA.PrezzoUnitario)
						FROM cv.OfferteAcquisto OA, us.UTENTI U
						WHERE OA.AnnoRiferimento = ?
						AND OA.IdSessione  = HEXTORAW(?)
						AND OA.IdUtente    = U.IdUtente
						AND U.IdSocieta    = HEXTORAW(?)
						AND OA.QtyResidua     <> 0
						AND OA.PrezzoUnitario >= ?
						AND OA.Compatibile    <> 0
					";

				Par(cmd, "loc_OVen_AnnoRiferimento", loc_OVen_AnnoRiferimento);
				Par(cmd, "loc_OVen_IdSessione",      loc_OVen_IdSessione);
				Par(cmd, "loc_OVen_IdSocieta",       loc_OVen_IdSocieta);
				Par(cmd, "loc_OVen_PrezzoUnitario",  loc_OVen_PrezzoUnitario);

				using (OleDbDataReader rd = cmd.ExecuteReader())
				{
					if (rd.Read())
					{
						if (rd.IsDBNull(0) == false)
							loc_PrezzoCompatibile = (decimal)rd[0];
					}
				}
			}

			if (loc_PrezzoCompatibile == 0m)
				loc_flag = 1m;
			else
				loc_flag = 0m;

			if (loc_PrezzoVendita > 0m)
			{
				// offerta di vendita con prezzo

				// cosi' si selezioneranno solo le offerte di acquisto
				// ad un prezzo maggione il prezzo di vendita
				// o le offerte di acquisto a mercato
				loc_PrezzoVend_INF = loc_PrezzoVendita;
				loc_PrezzoVend_OR  = 0; 
			}
			else
			{
				// offerta di vendita a mercato

				// cosi' si selezioneranno solo le offerte di acquisto con un prezzo
				// escludendo le offerte di acquisto a mercato
				loc_PrezzoVend_INF = 0.0001m;
				loc_PrezzoVend_OR  = -1m;
			}


			// dichiaro il "cursore" per le OfferteVendita
			DataSet dsOAcq = new DataSet();
			DataTable dtOAcq = dsOAcq.Tables.Add("OAcq");
			dtOAcq.Columns.Add("IdOffertaAcquisto", typeof(string));
			dtOAcq.Columns.Add("QtyResidua", typeof(decimal));
			dtOAcq.Columns.Add("PrezzoUnitario", typeof(decimal));
			dtOAcq.Columns.Add("IdUtente", typeof(string));
			dtOAcq.Columns.Add("Mercato", typeof(decimal));
			using (OleDbDataAdapter daOAcq = new OleDbDataAdapter())
			{
				// trovo tutte le offerte di acquisto 
				// non dello stesso utente (Attenzione stessa societa!!)
				// per lo stesso anno stessa sessione
				// con prezzo congruente alla mia offerta di vendita
				OleDbCommand cmd = new OleDbCommand("", cn, tr);
				daOAcq.SelectCommand = cmd;
				cmd.CommandText = @"
						SELECT 
							RAWTOHEX(OA.IdOffertaAcquisto) AS IdOffertaAcquisto, 
							OA.QtyResidua AS QtyResidua, 
							OA.PrezzoUnitario AS PrezzoUnitario, 
							RAWTOHEX(OA.IdUtente) AS IdUtente, 
							SIGN(OA.PrezzoUnitario) AS Mercato
						FROM cv.OfferteAcquisto OA, us.UTENTI UAcq
						WHERE OA.IdSessione = HEXTORAW(?)
						AND OA.AnnoRiferimento = ?
						AND OA.QtyResidua <> 0
						AND OA.IdUtente = UAcq.IdUtente
						AND UAcq.IdSocieta <> HEXTORAW(?) 
						AND (OA.PrezzoUnitario >= ? OR OA.PrezzoUnitario = ?)
						AND OA.PrezzoUnitario > ?
						AND OA.Compatibile <> 0
						AND SIGN(OA.PrezzoUnitario) >= 0
						ORDER BY Mercato ASC, OA.PrezzoUnitario DESC, OA.DataOraModifica ASC
						FOR UPDATE
					";

				Par(cmd, "IdSessione",            loc_OVen_IdSessione);
				Par(cmd, "AnnoRiferimento",       loc_OVen_AnnoRiferimento);
				Par(cmd, "loc_OVen_IdSocieta",    loc_OVen_IdSocieta);
				Par(cmd, "loc_PrezzoVend_INF",    loc_PrezzoVend_INF);
				Par(cmd, "loc_PrezzoVend_OR",     loc_PrezzoVend_OR);
				Par(cmd, "loc_PrezzoCompatibile", loc_PrezzoCompatibile);

				cmd.Connection = cn;
				cmd.Transaction = tr;

				daOAcq.Fill(dsOAcq, "OAcq");
			}

			foreach (DataRow drOAcq in dsOAcq.Tables["OAcq"].Rows)
			{
				string  loc_OAcq_IdOffertaAcquisto = (string)  drOAcq["IdOffertaAcquisto"];
				decimal loc_OAcq_QtyResidua        = (decimal) drOAcq["QtyResidua"];
				decimal loc_OAcq_PrezzoUnitario    = (decimal) drOAcq["PrezzoUnitario"];
				string  loc_OAcq_IdUtente          = (string)  drOAcq["IdUtente"];
				decimal loc_OAcq_Mercato           = (decimal) drOAcq["Mercato"];

				// se non ho piu' da vendere esco	
				if (loc_QtyResiduaVendita == 0)
					break;

				// se vendo a prezzo
				// esco se trovo un prezzo di acquisto minore a quello ricercato
				if (loc_PrezzoVendita > 0m && loc_PrezzoVendita > loc_OAcq_PrezzoUnitario)
					break;

				// ritrovo la quantita che riesco ad abbinare con questa offerta di acquisto
				if (loc_QtyResiduaVendita <= loc_OAcq_QtyResidua)
					loc_QtyAbbinata = loc_QtyResiduaVendita;
				else
					loc_QtyAbbinata = loc_OAcq_QtyResidua;

				loc_QtyResiduaVendita  -= loc_QtyAbbinata;
				loc_QtyResiduaAcquisto = loc_OAcq_QtyResidua - loc_QtyAbbinata;

				// inserisco la transazione di compraventita.
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
							INSERT INTO cv.Transazioni (
								QtyCertificati,
								PrezzoUnitario,
								IdOffertaVendita,
								IdOffertaAcquisto)
							VALUES (
								?,
								?,
								HEXTORAW(?),
								HEXTORAW(?))
						";
					Par(cmd, "loc_QtyAbbinata",            loc_QtyAbbinata);
					Par(cmd, "loc_OAcq_PrezzoUnitario",    loc_OAcq_PrezzoUnitario);
					Par(cmd, "in_IdOffertaVendita",        IdOffertaVendita);
					Par(cmd, "loc_OAcq_IdOffertaAcquisto", loc_OAcq_IdOffertaAcquisto);
					cmd.ExecuteNonQuery();
				}

				// trovo la societa e il prezzo convenzionale di chi acquista
				string loc_IdSocieta = null;
				loc_PrezzoConvUtenteMw = 0m;
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
							SELECT  RAWTOHEX(C.IdSocieta), A.PrezzoConvenzionaleUtenteMw
							FROM cv.Budgets A, US.Utenti B, US.Societa C
							WHERE B.IdSocieta = C.IdSocieta
							AND A.IdSocieta = C.IdSocieta
							AND B.IdUtente = HEXTORAW(?)
							AND A.IdSessione = HEXTORAW(?)
						";

					Par(cmd, "loc_OAcq_IdUtente",   loc_OAcq_IdUtente);
					Par(cmd, "loc_OVen_IdSessione", loc_OVen_IdSessione);

					using (OleDbDataReader r = cmd.ExecuteReader())
					{
						if (r.Read())
						{
							if (r.IsDBNull(0))
								throw new Exception("Cannot found record");
							if (r.IsDBNull(1))
								throw new Exception("Cannot found record");

							object r0 = r[0];
							object r1 = r[1];

							loc_IdSocieta = (string)r0;// r[0];
							loc_PrezzoConvUtenteMw = (decimal)r1;//(decimal)r[1];
						}
						else
							throw new Exception("Cannot found record");
					}
				}

				// se chi acquista sta acquistando ad un prezzo minore del suo
				// prezzo convenzionale
				if (loc_OAcq_PrezzoUnitario <= loc_PrezzoConvUtenteMw)
				{
					// metto a disponibilita' di chi ha appena comprato i CV acquistati
					using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
					{
						cmd.CommandText = @"
								UPDATE cv.CertificatiVerdi
								SET Qty = Qty + ?
								WHERE IdSocieta = HEXTORAW(?)
								AND IdSessione = HEXTORAW(?)
								AND AnnoRiferimento = ?
							";

						Par(cmd, "loc_QtyAbbinata",          loc_QtyAbbinata);
						Par(cmd, "loc_IdSocieta",            loc_IdSocieta);
						Par(cmd, "loc_OVen_IdSessione",      loc_OVen_IdSessione);
						Par(cmd, "loc_OVen_AnnoRiferimento", loc_OVen_AnnoRiferimento);

						cmd.ExecuteNonQuery();
					}
				}

				// aggiorno la quantita disponibile per l'offerta di acquisto
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
							UPDATE cv.OfferteAcquisto
							SET QtyResidua = ?
							WHERE IdOffertaAcquisto = HEXTORAW(?)
							";

					Par(cmd, "loc_QtyResiduaAcquisto", loc_QtyResiduaAcquisto);
					Par(cmd, "IdOffertaAcquisto",      loc_OAcq_IdOffertaAcquisto);
					cmd.ExecuteNonQuery();
				}

				// se si sta facendo una offerta di vendita a mercato...
				if (loc_OVen_PrezzoUnitario == 0m)
				{
					// impongo che per le prossime offerte di acquisto (se ce ne sono)
					// il prezzo di vendita sia almemo il prezzo appena pattuito
					loc_PrezzoVendita = loc_OAcq_PrezzoUnitario;
				}
			}

			// se avevo una offerta di vendita a mercato
			if (loc_OVen_PrezzoUnitario == 0m)
			{
				// un'offerta di acquisto senza limite di prezzo
				// non si abbinera' solo nel caso in cui fosse incompatibile
 
				// se non sono riuscito a piazzarla.....
				if (loc_PrezzoVendita == 0m)
					loc_flag = 0m; // la rendo non compatibile
				else
					loc_flag = 1m; // e' compatibile

				// aggiorno la quantita' residua di vendita, il nuovo prezzo e la "compatibilita'"
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
							UPDATE cv.OfferteVendita
							SET QtyResidua = ?,
							PrezzoUnitario = ?,
							Compatibile = ? 
							WHERE IdOffertaVendita = HEXTORAW(?)
							";

					Par(cmd, "loc_QtyResiduaVendita", loc_QtyResiduaVendita);
					Par(cmd, "loc_PrezzoVendita",     loc_PrezzoVendita);
					Par(cmd, "loc_flag",              loc_flag);
					Par(cmd, "IdOffertaVendita",      IdOffertaVendita);
					cmd.ExecuteNonQuery();
				}
			}
			else
			{
				// era una offerta di vendita con prezzo
				// aggiorno la quantita residua e il flag di compatibilita
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
							UPDATE cv.OfferteVendita
							SET QtyResidua = ?,
							Compatibile = ?
							WHERE IdOffertaVendita = HEXTORAW(?)
							";

					Par(cmd, "loc_QtyResiduaVendita", loc_QtyResiduaVendita);
					Par(cmd, "loc_flag",              loc_flag);
					Par(cmd, "IdOffertaVendita",      IdOffertaVendita);
					cmd.ExecuteNonQuery();
				}
			}

			// Modifica effettuata da Sandro
			if ((loc_QtyResiduaVendita == loc_OVen_QtyResidua) && (loc_flag == 0))
			{
				ris = -5 ; // Offerta totalmente incompatibile
			}
			if ((loc_QtyResiduaVendita < loc_OVen_QtyResidua) && (loc_flag == 0) && (loc_QtyResiduaVendita != 0))
			{
				ris = -6 ; // Offerta parzialmente incompatibile
			}
			// Fine modifica

			// se ho trattato una offerta di vendita che e' risultata NON Compatibile
			if (loc_flag == 0)
			{
				// tolgo nella disponibilita di chi ha venduto
				// la quantita' trattata
				using (OleDbCommand cmd = new OleDbCommand("", cn, tr))
				{
					cmd.CommandText = @"
							UPDATE cv.CertificatiVerdi
							SET QtyImpegnata = QtyImpegnata - ?
							WHERE IdSocieta  = HEXTORAW(?)
							AND IdSessione = HEXTORAW(?)
							AND AnnoRiferimento = ?
							";

					Par(cmd, "loc_QtyResiduaVendita",    loc_QtyResiduaVendita);
					Par(cmd, "loc_OVen_IdSocieta",       loc_OVen_IdSocieta);
					Par(cmd, "loc_OVen_IdSessione",      loc_OVen_IdSessione);
					Par(cmd, "loc_OVen_AnnoRiferimento", loc_OVen_AnnoRiferimento);
					cmd.ExecuteNonQuery();
				}
			}

			return ris ;
		}
	}
}
