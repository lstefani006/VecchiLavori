using System;
using System.Data;

namespace CV.Op
{
	/// <summary>
	/// Summary description for BLOPTransazione.
	/// </summary>
	public class BLOPTransazioni : CVRemotingBase, IBLOPTransazioni
	{
		public BLOPTransazioni()
		{
		}

		public DataSet GetRecordByIdOffertaVendita(string IdOffertaVendita)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPTransazioni dl = new DLOPTransazioni(dbTran);
					DataSet ds = dl.GetRecordByIdOffertaVendita(IdOffertaVendita);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetRecordByIdOffertaAcquisto(string IdOffertaAcquisto)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPTransazioni dl = new DLOPTransazioni(dbTran);
					DataSet ds = dl.GetRecordByIdOffertaAcquisto(IdOffertaAcquisto);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public BookData GetBookData(string IdSessione, string AnnoRiferimento)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPTransazioni dl = new DLOPTransazioni(dbTran);
					DataSet dsUltimiPrezzi = dl.GetUltimoPrezzo(IdSessione, AnnoRiferimento);
					DataSet dsPrezziMinMax = dl.GetPrezziMinMax(IdSessione, AnnoRiferimento);
					
					DataTable dtUltimiPrezzi = dsUltimiPrezzi.Tables["UltimoPrezzo"];
					DataTable dtPrezziMinMax = dsPrezziMinMax.Tables["PrezziMinMax"];
					BookData bd = new BookData();
					if (dtPrezziMinMax.Rows.Count != 0)
					{
						if (!dtPrezziMinMax.Rows[0].IsNull("PrezzoMax"))
						{
							bd.PrezzoMAX = (decimal)dtPrezziMinMax.Rows[0]["PrezzoMax"];
							bd.PrezzoMAXIsNull = false;
						}
						else
						{
							bd.PrezzoMAX = 0M;
							bd.PrezzoMAXIsNull = true;
						}
						if (!dtPrezziMinMax.Rows[0].IsNull("PrezzoMin"))
						{
							bd.PrezzoMin = (decimal)dtPrezziMinMax.Rows[0]["PrezzoMin"];
							bd.PrezzoMinIsNull = false;
						}
						else
						{
							bd.PrezzoMin = 0M;
							bd.PrezzoMinIsNull = true;
						}
						if (!dtPrezziMinMax.Rows[0].IsNull("VolumeScambi"))
						{
							bd.VolumeScambi = (decimal)dtPrezziMinMax.Rows[0]["VolumeScambi"];
							bd.VolumeScambiIsNull = false;
						}
						else
						{
							bd.VolumeScambi = 0M;
							bd.VolumeScambiIsNull = true;
						}
					}
					// Devo prelevare gli ultimi tre prezzi Unitari
					// 
					switch (dtUltimiPrezzi.Rows.Count)
					{
						case 0:
						break;
						case 1:
							if (!dtUltimiPrezzi.Rows[0].IsNull("PrezzoUnitario"))
							{
								bd.UltimoPrezzo1 = (decimal)dtUltimiPrezzi.Rows[0]["PrezzoUnitario"];
								bd.UltimoPrezzo1IsNull = false;
							}
							else
							{
								bd.UltimoPrezzo1 = 0M;
								bd.UltimoPrezzo1IsNull = true;
							}
						break;
						case 2:
							if (!dtUltimiPrezzi.Rows[1].IsNull("PrezzoUnitario"))
							{
								bd.UltimoPrezzo2 = (decimal)dtUltimiPrezzi.Rows[1]["PrezzoUnitario"];
								bd.UltimoPrezzo2IsNull = false;
							}
							else
							{
								bd.UltimoPrezzo2 = 0M;
								bd.UltimoPrezzo2IsNull = true;
							}
							goto case 1;
						case 3:
							if (!dtUltimiPrezzi.Rows[2].IsNull("PrezzoUnitario"))
							{
								bd.UltimoPrezzo3 = (decimal)dtUltimiPrezzi.Rows[2]["PrezzoUnitario"];
								bd.UltimoPrezzo3IsNull = false;
							}
							else
							{
								bd.UltimoPrezzo3 = 0M;
								bd.UltimoPrezzo3IsNull = true;
							}
							goto case 2;
						// La tabella contiene piu' di tre righe => devo prelevare le prime tre
						default:
							goto case 3;
					}
					dbTran.Commit();
					return bd;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetTransazioniAcquisto(string IdSessione, string IdUtente)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPTransazioni dl = new DLOPTransazioni(dbTran);
					DataSet ds = dl.GetTransazioniAcquisto(IdSessione, IdUtente);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetTransazioniVendita(string IdSessione, string IdUtente)
		{
			using (IDbConnection cn = DLOPCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLOPTransazioni dl = new DLOPTransazioni(dbTran);
					DataSet ds = dl.GetTransazioniVendita(IdSessione, IdUtente);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
	}
}
