using System;
using System.Collections;
using System.Text; 
using System.Data;
using System.Data.OleDb;

namespace CV.Op
{
	/// <summary>
	/// Summary description for Sessioni.
	/// </summary>
	public class Sessioni : CVRemotingBase, ISessioni
	{
		public Sessioni()
		{
		}

		private string GetConnectionString()
		{
			string strConnectionString;
			string strProvider;
			string strUser;
			string strPassword;
			string strDataSource;
			StringBuilder strBuilder;

			strBuilder = new StringBuilder();
			strProvider = "MSDAORA.1";
			strPassword = "gme_op";
			strUser = "gme_op";
			strDataSource = "orcl-gme";
			// Costruisco la Connection String
			strBuilder.Append("Provider=");
			strBuilder.Append(strProvider);
			strBuilder.Append(";");
			strBuilder.Append("Password=");
			strBuilder.Append(strPassword);
			strBuilder.Append(";");
			strBuilder.Append("User ID=");
			strBuilder.Append(strUser);
			strBuilder.Append(";");
			strBuilder.Append("Data Source=");
			strBuilder.Append(strDataSource);
			//strConnectionString = "Provider=MSDAORA.1;Password=gme_op;User ID=gme_op;Data Source=orcl-gme"
			strConnectionString = strBuilder.ToString();
			return (strConnectionString);
		}

		public DataSet GetListaSessioni()
		{
			if (false)
			{
				OleDbConnection Conn = null;
				OleDbDataAdapter daDataAdapter = null;
				DataSet dsSessioni = null;
				string strConnectionString;
				string strSqlQuery;
				strSqlQuery = "SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione FROM CV.SESSIONI ORDER BY DataOraCreazione DESC";
				strConnectionString = GetConnectionString();
				using (Conn)
				{
					using (daDataAdapter)
					{
						Conn = new OleDbConnection(strConnectionString);
						daDataAdapter = new OleDbDataAdapter(strSqlQuery, Conn);
						dsSessioni = new DataSet();
						// Riempio il Dataset tramite il DataAdapter => DataSet sconnesso
						daDataAdapter.Fill(dsSessioni);
						return (dsSessioni);
					}
				}
			}
			else
			{
				string strConnectionString = GetConnectionString();

				string strSqlQuery = "SELECT RAWTOHEX(IdSessione) IdSessione, Titolo, DataOraApertura, DataOraChiusura, " +
					"PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, PrezzoRiferimentoAnnoSucc, PrezzoConvenzionale, DataOraCreazione, DataOraModifica, StatoSessione FROM CV.SESSIONI ORDER BY DataOraCreazione DESC";
				using (OleDbConnection cn = new OleDbConnection(strConnectionString))
				{
					using (OleDbDataAdapter da = new OleDbDataAdapter(strSqlQuery, cn))
					{
						DataSet ds = new DataSet("dsSessione");
						da.Fill(ds, "Sessione");
						return ds;
					}
				}
				return new DataSet();
			}
		}

		public DatiSessione GetInfoSessione(string IdSessione)
		{
			DatiSessione InfoSessione;
			try
			{
				InfoSessione = new DatiSessione();
				InfoSessione.NomeSessione = "Sessione di prova Remota";
				return (InfoSessione);
			}
			catch(Exception ex)
			{
				throw ex;
			}
			finally
			{
			}
		}
		public ArrayList GetInfoSessioni()
		{
			DatiSessione InfoSessione;
			ArrayList Lista;
			try
			{
				InfoSessione = new DatiSessione();
				Lista = new ArrayList();
				InfoSessione.NomeSessione = "Sessione di prova Remota 1";
				Lista.Add(InfoSessione);
				InfoSessione = new DatiSessione();
				InfoSessione.NomeSessione = "Sessione di prova Remota 2";
				Lista.Add(InfoSessione);
				return (Lista);
			}
			catch(Exception ex)
			{
				throw ex;
			}
			finally
			{
			}
		}
	}
}
