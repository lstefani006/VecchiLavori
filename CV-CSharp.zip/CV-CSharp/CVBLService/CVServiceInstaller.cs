using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;

namespace CVBLService
{
	/// <summary>
	/// Summary description for ProjectInstaller.
	/// </summary>
	[RunInstaller(true)]
	public class ProjectInstaller : System.Configuration.Install.Installer
	{
		private System.ServiceProcess.ServiceProcessInstaller ServiceProcessInstallerCV;
		private System.ServiceProcess.ServiceInstaller ServiceInstallerCV;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ProjectInstaller()
		{
			// This call is required by the Designer.
			components = components;
			InitializeComponent();

		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ServiceProcessInstallerCV = new System.ServiceProcess.ServiceProcessInstaller();
			this.ServiceInstallerCV = new System.ServiceProcess.ServiceInstaller();
			// 
			// ServiceProcessInstallerCV
			// 
			this.ServiceProcessInstallerCV.Account = System.ServiceProcess.ServiceAccount.LocalSystem;
			this.ServiceProcessInstallerCV.Password = null;
			this.ServiceProcessInstallerCV.Username = null;
			// 
			// ServiceInstallerCV
			// 
			this.ServiceInstallerCV.ServiceName = "CVBLService";
			// 
			// ProjectInstaller
			// 
			this.Installers.AddRange(new System.Configuration.Install.Installer[] {this.ServiceProcessInstallerCV,this.ServiceInstallerCV});

		}
		#endregion

		public override void Install(System.Collections.IDictionary stateSaver)
		{
			Microsoft.Win32.RegistryKey system,
				//HKEY_LOCAL_MACHINE\Services\CurrentControlSet
				currentControlSet,
				//...\Services
				services,
				//...\<Service Name>
				service; 

			try
			{
				//Let the project installer do its job
				base.Install(stateSaver);

				//Open the HKEY_LOCAL_MACHINE\SYSTEM key
				system = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("System");
				//Open CurrentControlSet
				currentControlSet = system.OpenSubKey("CurrentControlSet");
				//Go to the services key
				services = currentControlSet.OpenSubKey("Services");
				//Open the key for your service, and allow writing
				service = services.OpenSubKey(this.ServiceInstallerCV.ServiceName, true);
				//Add your service's description as a REG_SZ value named "Description"
				service.SetValue("Description", "CV Application Server");
			}
			catch(Exception e)
			{
				Console.WriteLine("An exception was thrown during service installation:\n" + e.ToString());
			}

		}

		public override void Uninstall(System.Collections.IDictionary savedState)
		{
			Microsoft.Win32.RegistryKey system,
				currentControlSet,
				services,
				service;

			try
			{
				//Drill down to the service key and open it with write permission
				system = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("System");
				currentControlSet = system.OpenSubKey("CurrentControlSet");
				services = currentControlSet.OpenSubKey("Services");
				service = services.OpenSubKey(this.ServiceInstallerCV.ServiceName, true);
			}
			catch(Exception e)
			{
				Console.WriteLine("Exception encountered while uninstalling service:\n" + e.ToString());
			}
			finally
			{
				//Let the project installer do its job
				base.Uninstall(savedState);
			}

		}
	}
}
