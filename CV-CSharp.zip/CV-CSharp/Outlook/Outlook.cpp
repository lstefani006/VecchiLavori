/*
Questo mirabolante programma serve per firmare
dei dati con una chiave digitale.

Il nome OutLook.exe e' necessario perche' con la chiava IPN-NET i dati
sono criptati solo da processi che si chiamano Outlook.exe IExplorer.exe e pochi altri.
(Gli altri vengono buttati fuori)

*/
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <wincrypt.h>
#include <string>
#include <vector>
#include <iostream>

using namespace std;

static void ZeroMem(void *p ,int sz)
{
	char *pt = (char *)p;
	for (int i = 0; i < sz; ++i)
		pt[i] = 0;
}

template <typename T> class Malloc
{
public:
	Malloc(int nItems)
	{
		_p = (T *) GlobalAllocPtr(GHND, sizeof(T) * nItems);
	}
	Malloc(int nBytes, bool)
	{
		_p = (T *) GlobalAllocPtr(GHND, nBytes);
	}

	T * pt() { return _p; }

	~Malloc()
	{
		GlobalFreePtr(_p);
	}

private:
	T * _p;

	void operator = (const Malloc<T> &);
	Malloc(const Malloc<T> &);
};

class CertEx
{
public: 
	CertEx(string msg)
	{
		_e = GetLastError();
		_msg = msg;
	}

	string Msg() { return _msg; }
	unsigned int Error() { return _e; }

private:
	string _msg;
	unsigned int _e;
};

struct CertificateData
{
	string Subject;
	wstring ProvName;
	wstring KeyContainerName;
};



class Certificate;


class CertificateStore
{
public:
	CertificateStore()
	{
		_hStoreHandle = ::CertOpenStore(CERT_STORE_PROV_SYSTEM, X509_ASN_ENCODING, NULL, CERT_SYSTEM_STORE_CURRENT_USER, L"MY");
		if (_hStoreHandle == NULL)
			throw new CertEx("CertOpenStore");
	}

	~CertificateStore()
	{
		if (_hStoreHandle != NULL)
		{
			if (!CertCloseStore(_hStoreHandle, 0))
			{
				_hStoreHandle = NULL;
				throw new CertEx("CertCloseStore");
			}
			_hStoreHandle = NULL;
		}
	}

	vector<CertificateData> GetCertList()
	{
		vector<CertificateData> listCert;

		PCCERT_CONTEXT pCertContext = NULL;

		try
		{
			while (pCertContext = CertEnumCertificatesInStore(_hStoreHandle, pCertContext)) 
			{
				DWORD cbNameLen = 0;
				if(!(cbNameLen = CertGetNameString(   
					pCertContext,   
					CERT_NAME_SIMPLE_DISPLAY_TYPE,   
					0,
					NULL,   
					NULL,   
					0)))
				{
					throw new CertEx("CertGetNameString");
				}

				Malloc<char> sz(cbNameLen + 1);

				if(!CertGetNameString(   
					pCertContext,   
					CERT_NAME_SIMPLE_DISPLAY_TYPE,   
					0,
					NULL,   
					sz.pt(),   
					cbNameLen+1))
				{
					throw new CertEx("CertGetNameString");
				}

				CertificateData pd;
				pd.Subject = sz.pt();

				DWORD KeyProvInfoLen;
				if (CertGetCertificateContextProperty(pCertContext, CERT_KEY_PROV_INFO_PROP_ID, NULL, &KeyProvInfoLen) == FALSE)
					continue;

				////////////////////////////
				Malloc<CRYPT_KEY_PROV_INFO> KeyProvInfo(KeyProvInfoLen, true);

				if (CertGetCertificateContextProperty(pCertContext,
					CERT_KEY_PROV_INFO_PROP_ID,
					KeyProvInfo.pt(),
					&KeyProvInfoLen) == FALSE)
				{
					throw new CertEx("CertGetCertificateContextProperty");
				}

				pd.ProvName = KeyProvInfo.pt()->pwszProvName;
				pd.KeyContainerName = KeyProvInfo.pt()->pwszContainerName;

				////////////////////////////

				listCert.push_back(pd);
			}


			return listCert;
		}
		catch (CertEx *)
		{
			if (pCertContext != NULL)
			{
				if (!CertFreeCertificateContext(pCertContext))
					throw new CertEx("CertFreeCertificateContext");
			}
			throw;
		}
	}

	Certificate * FindCertificateBySubject(string Subject);

	HCERTSTORE GetHandle()
	{
		return _hStoreHandle;
	}

private:
	HCERTSTORE _hStoreHandle;
};



class Certificate
{
public:
	typedef vector<BYTE> RawData;

	Certificate(PCCERT_CONTEXT p_PCCERT_CONTEXT)
	{
		_pSignerCert = p_PCCERT_CONTEXT;
	}

	Certificate(RawData CertEncoded)
	{
		_pSignerCert = ::CertCreateCertificateContext(
			PKCS_7_ASN_ENCODING | X509_ASN_ENCODING, &(CertEncoded[0]), (DWORD)CertEncoded.size());

		if (_pSignerCert == NULL)
			throw new CertEx("CertCreateCertificateContext");
	}

	~Certificate()
	{
		if (_pSignerCert != NULL)
		{
			if (!CertFreeCertificateContext(_pSignerCert))
			{
				_pSignerCert = NULL;
				throw new CertEx("CertFreeCertificateContext");
			}
			_pSignerCert = NULL;
		}
	}

	RawData GetX509Encoded()
	{
		RawData ret;
		for (DWORD i = 0; i < _pSignerCert->cbCertEncoded; ++i)
			ret.push_back(_pSignerCert->pbCertEncoded[i]);

		return ret;
	}

	RawData Sign(RawData din)
	{
		CRYPT_SIGN_MESSAGE_PARA SigParams;
		ZeroMem(&SigParams, sizeof(SigParams));

		SigParams.cbSize = sizeof(CRYPT_SIGN_MESSAGE_PARA);
		SigParams.HashAlgorithm.pszObjId = szOID_RSA_MD5;
		SigParams.pSigningCert = _pSignerCert;
		SigParams.dwMsgEncodingType = X509_ASN_ENCODING | PKCS_7_ASN_ENCODING;
		SigParams.rgpMsgCert = & (this->_pSignerCert);
		SigParams.cMsgCert = 1;

		SigParams.HashAlgorithm.Parameters.cbData = NULL;
		SigParams.cAuthAttr = 0;
		SigParams.dwInnerContentType = 0;
		SigParams.cMsgCrl = 0;
		SigParams.cUnauthAttr = 0;
		SigParams.dwFlags = 0;
		SigParams.pvHashAuxInfo = NULL;
		SigParams.rgAuthAttr = NULL;

		//--------------------------------------------------------------------
		// With two calls to CryptSignMessage, sign the message.
		// First, get the size of the output signed BLOB.

		const BYTE * MessageArray[1] = { &(din[0]) };
		DWORD MessageSizeArray[1] = { (DWORD)din.size() };

		DWORD cbSignedMessageBlob;
		if(!CryptSignMessage(
			&SigParams,            // Signature parameters
			FALSE,                 // Not detached
			1,                     // Number of messages
			MessageArray,          // Messages to be signed
			MessageSizeArray,      // Size of messages
			NULL,                  // Buffer for signed message
			&cbSignedMessageBlob)) // Size of buffer
		{
			throw new CertEx("CryptSignMessage");
		}

		//--------------------------------------------------------------------
		// Allocate memory for the signed BLOB.
		Malloc<BYTE> pbSignedMessageBlob(cbSignedMessageBlob);

		//--------------------------------------------------------------------
		// Get the SignedMessageBlob.

		if(!CryptSignMessage(
			&SigParams,            // Signature parameters
			FALSE,                 // Not detached
			1,                     // Number of messages
			MessageArray,          // Messages to be signed
			MessageSizeArray,      // Size of messages
			pbSignedMessageBlob.pt(),// Buffer for signed message
			&cbSignedMessageBlob)) // Size of buffer
		{
			if (GetLastError() == 0)
			{
				RawData ret;
				return ret;  // ha premuto cancel
			}

			throw new CertEx("CryptSignMessage");
		}

		RawData dout;

		for (DWORD i = 0; i < cbSignedMessageBlob; ++i)
			dout.push_back(pbSignedMessageBlob.pt()[i]);

		return dout;
	}



private:
	PCCERT_CONTEXT _pSignerCert;
};

Certificate * CertificateStore::FindCertificateBySubject(string Subject)
{
	PCCERT_CONTEXT pCert = CertFindCertificateInStore(
		this->_hStoreHandle, X509_ASN_ENCODING, 0,
		CERT_FIND_SUBJECT_STR_A,
		Subject.c_str(),
		NULL);

	if (pCert == NULL)
		return NULL;

	return new Certificate(pCert);
}



void Error()
{
	cerr << "Outlook.exe -l\n";
	cerr << "\tlista i certificati presenti\n";
	cerr << "Outlook \"subject\" \"fileIn\" \"fileOut\"\n";
	cerr << "\tsegna il contenuto del file fileIn. UScita in fileOut\n";
	exit(1);
}

// ritorna 0 tutto ok
// 1 errore
// 2 cancel
int main(int argc, char *argv[])
{
	try
	{
		if (argc == 1)
			Error();

		if (argc == 2 && string(argv[1]) == "-l")
		{
			CertificateStore cs;

			vector<CertificateData> r = cs.GetCertList();

			for (int i = 0; i < (int)r.size(); ++i)
				cout << r[i].Subject << "\n";

			return 0;
		}
		if (argc != 4)
			Error();

		CertificateStore cs;
		Certificate *cf = cs.FindCertificateBySubject(argv[1]);
		if (cf == NULL)
		{
			cerr << "Cannot find " << argv[1] << "certificate\n";
			exit(1);
		}

		vector<BYTE> d;
		if (true)
		{
			FILE *fin = fopen(argv[2], "rb");
			if (fin == NULL)
			{
				cerr << "Cannot open file " << argv[2] << "\n";
				exit(1);
			}
			for (;;)
			{
				int ch = fgetc(fin);
				if (ch < 0)
					break;
				d.push_back(ch);
			}
			fclose(fin);
		}


		vector<BYTE> c = cf->Sign(d);
		if (c.size() == 0)
		{
			cerr << "Cancelled\n";
			exit(2);
		}

		if (true)
		{
			FILE *fout = fopen(argv[3], "wb");
			if (!fout)
			{
				cerr << "Cannot open file " << argv[3] << "\n";
				exit(2);
			}
			for (int i = 0; i < (int)c.size(); ++i)
				fputc(c[i], fout);
			fclose(fout);
		}

		delete cf;

		return 0;
	}
	catch (CertEx *pCertEx)
	{
		cerr << pCertEx->Msg() << "\n";
		cerr << "Win32 Error = " << pCertEx->Error();
		delete pCertEx;
		return 1;
	}
}

