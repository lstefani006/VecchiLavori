SELECT
RAWTOHEX(T.IdTransazione) AS IdTransazione,
A.RagioneSociale AS Acquirente,
A.ABI AS AcquirentiABI,
A.CAB AS AcquirentiCAB, 
A.CC AS AcquirentiCC, 
A.AnnoRiferimento AS AnnoRiferimento, 
RAWTOHEX(A.IdSocieta) AS IdSocietaAcq, 
V.RagioneSociale AS Venditore, 
V.ABI AS VenditoriABI, 
V.CAB AS VenditoriCAB, 
V.CC AS VenditoriCC, 
A.CodiceConto AS CodiceContoAcquirente, 
V.CodiceConto AS CodiceContoVenditore, 
RAWTOHEX(T.IdOffertaAcquisto) AS IdOffertaAcquisto, 
RAWTOHEX(T.IdOffertaVendita) AS IdOffertaVendita, 
T.QtyCertificati AS QtyCertificati, 
T.PrezzoUnitario AS PrezzoUnitario, 
(T.QtyCertificati *  T.PrezzoUnitario * 100) AS ControValore, 
T.DataOraOperazione AS DataOraOperazione, 
T.StatoTransazione AS StatoTransazione, 
BudgetsA.Importo AS ImportoA, 
BudgetsV.Importo AS ImportoV, 
BudgetsA.PrezzoConvenzionaleUtente AS PrezzoConvenzionaleUtenteA, 
BudgetsV.PrezzoConvenzionaleUtente AS PrezzoConvenzionaleUtenteV, 
BudgetsA.PrezzoConvenzionaleUtenteMw AS PConvenzionaleUtenteMwA, 
BudgetsV.PrezzoConvenzionaleUtenteMw AS PConvenzionaleUtenteMwV, 
UtentiA.Nominativo AS NominativoA, 
UtentiV.Nominativo AS NominativoV  
FROM 
	CV.Acquirenti A,
	CV.Venditori V,
	CV.Transazioni T,
    CV.Budgets BudgetsV,
	CV.Budgets BudgetsA,
	CV.Utenti UtentiA,
	CV.Utenti UtentiV 
WHERE	A.IdOffertaAcquisto = T.IdOffertaAcquisto 
		AND V.IdOffertaVendita = T.IdOffertaVendita 
		AND A.IdSocieta = BudgetsA.IdSocieta 
		AND V.IdSocieta = BudgetsV.IdSocieta 
		AND A.IdSessione = HEXTORAW('A') 
		AND (A.RagioneSociale LIKE 'A' 
       OR V.RagioneSociale LIKE 'A') 
		AND BudgetsV.IdSessione = HEXTORAW('A') 
		AND BudgetsA.IdSessione = HEXTORAW('A') 
       AND UtentiA.IdUtente = A.IdUtente 
       AND UtentiV.IdUtente = V.IdUtente ;
