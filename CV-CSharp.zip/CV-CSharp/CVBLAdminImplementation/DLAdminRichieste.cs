using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace CV.Admin
{
	/// <summary>
	/// 
	/// </summary>
	internal class DLAdminRichieste : DLAdminBase
	{
		internal DLAdminRichieste(IDbTransaction dbTransaction) : base(dbTransaction)
		{
		}

		public void Update(DataSet ds)
		{
			OleDbDataAdapter da = GetDataAdapter();
			da.Update(ds, "RichiestaSocieta");
		}

		public DataSet Search(string IdRichiestaRagSoc)
		{
			OleDbDataAdapter da = null;
			if (IdRichiestaRagSoc != String.Empty)
			{
				string sql = "WHERE IdRichiestaRegSoc = HEXTORAW(?) ";
				OleDbParameter par = new OleDbParameter("IdRichiestaRegSoc", OleDbType.VarChar);
				par.Value = IdRichiestaRagSoc;
				da = GetDataAdapter(sql, par);
			}
			else
			{
				da = GetDataAdapter();
			}

			DataSet ds = DataSet_RichiesteSocieta();
			da.Fill(ds, "RichiestaSocieta");
			da.Dispose();
			return ds;
			
		}

		internal DataSet SearchUtenti(string IdRichiestaRegUtente)
		{
			OleDbDataAdapter da = null;
			if (IdRichiestaRegUtente != String.Empty)
			{
				string sql = "WHERE IdRichiestaRegUtente = HEXTORAW(?) ";
				OleDbParameter par = new OleDbParameter("IdRichiestaRegUtente", OleDbType.VarChar);
				par.Value = IdRichiestaRegUtente;
				da = GetDataAdapterUtente(sql, par);
			}
			else
			{
				da = GetDataAdapterUtente(null, (OleDbParameter [])null);
			}
			
			DataSet ds = DataSet_RichiesteUtenti();
			da.Fill(ds, "RichiestaUtenti");

			if (MustCrypt)
			{
				foreach (DataRow dr in ds.Tables["RichiestaUtenti"].Rows)
				{
					string DN = (string)dr["DN"]; // OK Crypt
					dr["DN"] = Decrypt(DN); // OK Crypt
				}
				ds.AcceptChanges();
			}

			return ds;
		}

		protected OleDbDataAdapter GetDataAdapter()
		{
			return GetDataAdapter(null, (OleDbParameter [])null);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere)
		{
			OleDbParameter [] pars = new OleDbParameter [1];
			pars[0] = parWhere;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere1, OleDbParameter parWhere2)
		{
			OleDbParameter [] pars = new OleDbParameter [2];
			pars[0] = parWhere1;
			pars[1] = parWhere2;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				string sqlCmd = "SELECT " +
								"RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc, " + 
								"RagioneSociale, " +
								"Indirizzo, " +
								"Citta, " + 
								"CAP, " + 
								"Nazione, " + 
								"CodiceFiscale, " + 
								"PartitaIVA, " + 
								"Telefono, " + 
								"FAX, " + 
								"Email, " +
								"ABI, " +
								"CAB, " +
								"CC, " +
								"ReferenteAmministr, " +
								"SedeAmministrativa, " +
								"CodiceConto, " +
								"ConsensoTrattamentoDati, " +
								"DataOraInserimento, " +
								"Nota, " +
								"PINSoc, " +
								"StatoRichiesta " +
								"FROM US.RICHIESTEREGSOC ";

				if (sql != null && sql.Length > 0)
					sqlCmd += sql;

				sqlCmd += " ORDER BY RagioneSociale " ;
				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// insert
			
			// UPDATE
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText = "UPDATE US.RICHIESTEREGSOC SET " +
					"RagioneSociale = ?, " +
					"Indirizzo = ?, " +
					"Citta = ?, " + 
					"CAP = ?, " + 
					"Nazione = ?, " + 
					"CodiceFiscale = ?, " + 
					"PartitaIVA = ?, " + 
					"Telefono = ?, " + 
					"FAX = ?, " + 
					"Email = ?, " +
					"ABI = ?, " +
					"CAB = ?, " +
					"CC = ?, " +
					"ReferenteAmministr = ?, " +
					"SedeAmministrativa = ?, " +
					"CodiceConto = ?, " +
					"PINSoc = ? " +
					"WHERE IdRichiestaRegSoc = HEXTORAW(?) " ;

				cmd.Parameters.Add(new OleDbParameter("RagioneSociale",					OleDbType.VarChar,  255, "RagioneSociale"));
				cmd.Parameters.Add(new OleDbParameter("Indirizzo",						OleDbType.VarChar,	255, "Indirizzo"));
				cmd.Parameters.Add(new OleDbParameter("Citta",							OleDbType.VarChar,	255, "Citta"));
				cmd.Parameters.Add(new OleDbParameter("CAP",							OleDbType.VarChar,	255, "CAP"));
				cmd.Parameters.Add(new OleDbParameter("Nazione",						OleDbType.VarChar,  255, "Nazione"));
				cmd.Parameters.Add(new OleDbParameter("CodiceFiscale",					OleDbType.VarChar,	16,	 "CodiceFiscale"));
				cmd.Parameters.Add(new OleDbParameter("PartitaIVA",						OleDbType.VarChar,	11,	 "PartitaIVA"));
				cmd.Parameters.Add(new OleDbParameter("Telefono",						OleDbType.VarChar,  255, "Telefono"));
				cmd.Parameters.Add(new OleDbParameter("Fax",							OleDbType.VarChar,  255, "Fax"));
				cmd.Parameters.Add(new OleDbParameter("Email",							OleDbType.VarChar,  255, "Email"));
				cmd.Parameters.Add(new OleDbParameter("ABI",							OleDbType.VarChar,  255, "ABI"));
				cmd.Parameters.Add(new OleDbParameter("CAB",							OleDbType.VarChar,  255, "CAB"));
				cmd.Parameters.Add(new OleDbParameter("CC",								OleDbType.VarChar,  255, "CC"));
				cmd.Parameters.Add(new OleDbParameter("ReferenteAmministr",				OleDbType.VarChar,  100, "ReferenteAmministr"));
				cmd.Parameters.Add(new OleDbParameter("SedeAmministrativa",				OleDbType.VarChar,  100, "SedeAmministrativa"));
				cmd.Parameters.Add(new OleDbParameter("CodiceConto",					OleDbType.VarChar,  255, "CodiceConto"));
				cmd.Parameters.Add(new OleDbParameter("PINSoc",							OleDbType.VarChar,  255, "PINSoc"));
				cmd.Parameters.Add(new OleDbParameter("IdRichiestaRegSoc",		        OleDbType.VarChar,   32, "IdRichiestaRegSoc"));

				da.UpdateCommand = cmd;
			}

			// delete
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("DELETE FROM US.RICHIESTEREGSOC WHERE IdRichiestaRegSoc = HEXTORAW(?)", m_Transaction.Connection, m_Transaction);
				cmd.CommandType = CommandType.Text;

				OleDbParameter p = new OleDbParameter("IdRichiestaRegSoc", OleDbType.VarChar);
				p.SourceColumn = "IdRichiestaRegSoc";
				p.SourceVersion = DataRowVersion.Original;
				cmd.Parameters.Add(p);

				da.DeleteCommand = cmd;
			}

			// Determines the action that occurs when a mapping is missing from a source table or a source column
			//da.MissingMappingAction = MissingMappingAction.Error; questo da' sempre errore
			//da.MissingMappingAction = MissingMappingAction.Ignore; questo non da' errore ma ritorna una lista vuota

			// Determines the action to take when existing DataSet schema does not match incoming data.
			da.MissingSchemaAction = MissingSchemaAction.Error;

			return da;
		}

		private OleDbDataAdapter GetDataAdapterUtente(string sql, OleDbParameter parWhere)
		{
			OleDbParameter [] pars = new OleDbParameter [1];
			pars[0] = parWhere;
			return GetDataAdapterUtente(sql, pars);
		}

		private OleDbDataAdapter GetDataAdapterUtente(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				string sqlCmd = "SELECT " +
								"RAWTOHEX(U.IdRichiestaRegUtente) AS IdRichiestaRegUtente, " + 
								"U.Nominativo, " +
								"U.CodiceFiscale, " + 
								"U.Telefono, " + 
								"U.FAX, " + 
								"U.Email, " +
								"U.DataOraInserimento, " +
								"U.DN, " +   // OK Crypt le funzioni di ricerca poi ritorneranno il DN in chiaro
								"U.Nota, " +
								"RAWTOHEX(U.IdRichiestaRegSoc) AS IdRichiestaRegSoc, " +
								"U.TipoUtente, " +
								"U.StatoRichiesta, " +
								"S.RagioneSociale, " +
								"S.CodiceConto " +
								"FROM US.RICHIESTEREGUTENTI U, US.RICHIESTEREGSOC S ";

//				if (sql != null && sql.Length > 0)
//					sqlCmd += sql;
				
				if (sql != null && sql.Length > 0)
				{
					sqlCmd += sql;
					sqlCmd += " AND U.IdRichiestaRegSoc = S.IdRichiestaRegSoc ";
				}
				else
				{
					sqlCmd += " WHERE U.IdRichiestaRegSoc = S.IdRichiestaRegSoc ";
				}

				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// insert
			if (true)
			{
			}
			
			// UPDATE

			// delete
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("DELETE FROM US.RICHIESTEREGUTENTI WHERE IdRichiestaRegUtente = HEXTORAW(?)", m_Transaction.Connection, m_Transaction);
				cmd.CommandType = CommandType.Text;

				OleDbParameter p = new OleDbParameter("IdRichiestaRegUtente", OleDbType.VarChar);
				p.SourceColumn = "IdRichiestaRegUtente";
				p.SourceVersion = DataRowVersion.Original;
				cmd.Parameters.Add(p);

				da.DeleteCommand = cmd;
			}

			da.MissingSchemaAction = MissingSchemaAction.Error;

			return da;
		}

		
		public static DataSet DataSet_RichiesteSocieta()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("RichiestaSocieta");

			DataColumn c;
			c = dt.Columns.Add("IdRichiestaRegSoc", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = true;

			c = dt.Columns.Add("RagioneSociale", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("Indirizzo", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("Citta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("CAP", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("Nazione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("CodiceFiscale", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 16;
			c.Unique = false; 

			c = dt.Columns.Add("PartitaIVA", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 11;
			c.Unique = false; 

			c = dt.Columns.Add("Telefono", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("FAX", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("Email", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("ABI", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("CAB", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("CC", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("ReferenteAmministr", typeof(string));
			c.MaxLength = 100;
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("SedeAmministrativa", typeof(string));
			c.MaxLength = 100;
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("CodiceConto", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("ConsensoTrattamentoDati", typeof(decimal));
			c.AllowDBNull = false;
			c.Unique = false; 
		
			c = dt.Columns.Add("DataOraInserimento", typeof(DateTime));
			c.AllowDBNull = false;
			c.Unique = false; 
//OK		c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("Nota", typeof(string));
			c.AllowDBNull = true;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("PINSoc", typeof(string));
			c.AllowDBNull = true;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("StatoRichiesta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 
			c.DefaultValue = "Da Validare";

			dt.PrimaryKey = new DataColumn[] { dt.Columns["IdRichiestaRegSoc"] };
			return ds;

		}

		private static DataSet DataSet_RichiesteUtenti()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("RichiestaUtenti");

			DataColumn c;
			c = dt.Columns.Add("IdRichiestaRegUtente", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = true;

			c = dt.Columns.Add("Nominativo", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("CodiceFiscale", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 16;
			c.Unique = false; 

			c = dt.Columns.Add("Telefono", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("FAX", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("Email", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("DataOraInserimento", typeof(DateTime));
			c.AllowDBNull = false;
			c.Unique = false; 
//			c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("DN", typeof(string)); // OK Crypt
			c.AllowDBNull = false;
			c.MaxLength = 1023;
			c.Unique = false; 

			c = dt.Columns.Add("Nota", typeof(string));
			c.AllowDBNull = true;
			c.MaxLength = 255;
			c.Unique = false;
 
			c = dt.Columns.Add("IdRichiestaRegSoc", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("TipoUtente", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 

			c = dt.Columns.Add("StatoRichiesta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false; 
			c.DefaultValue = "Da Validare";

			c = dt.Columns.Add("RagioneSociale", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("CodiceConto", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			dt.PrimaryKey = new DataColumn[] { dt.Columns["IdRichiestaRegUtente"] };
			return ds;
		}
	}
}
