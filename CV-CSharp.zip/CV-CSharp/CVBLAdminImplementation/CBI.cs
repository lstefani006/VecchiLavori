using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Diagnostics;
using System.Data;

namespace CBI
{
#if ESEMPIO_CBI_WRITER
	class _
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			using (CBIWriter cw = new CBIWriter())
			{
				CBIHeader pc = new CBIHeader();
				pc._PC_mittente = "8R698";
				pc._PC_ricevente = "01025";
				pc._PC_data_creazione = new DateTime(2003, 5, 23);
				pc._PC_nome_supporto = "OPPIO 00000000000011";  // id univoco.

				FileStream fs = new FileStream(@"c:\leo.cbi", FileMode.Create, FileAccess.Write, FileShare.None);
				cw.Open(fs, pc);


				CBIDisposizione pg = new CBIDisposizione();
				pg._10_abi_ordinante = "01025";
				pg._10_cab_ordinante = "03236";
				pg._10_cc_ordinante = "100000002087";
				pg._10_importo = 1000.21m;

				pg._10_abi_destinatario = "88888";
				pg._10_cab_destinatario = "99999";
				pg._10_cc_destinatario  = "777777777777";
				pg._10_codice_azienda = pc._PC_mittente;

				pg._20_ragione_sociale_ordinante = "GESTORE DEL MERCATO ELETTRICO";
				pg._20_indirizzo_ordinante = "VLE MARESCIALLO PILSUDSKI,92";
				pg._20_localita_ordinante = "ROMA";
				pg._20_piva_ordinante = "06208031002";

				pg._30_ragione_sociale_beneficiario = "Leo Stefani";

				pg._50_causale = "pagamento CV ....";


				cw.ScriviDisposizione(pg);
				cw.ScriviDisposizione(pg);
				cw.ScriviDisposizione(pg);
				cw.ScriviDisposizione(pg);

				cw.Close(); // questo non serve se si chiama Dispose
			}
		}
	}
#endif

	public class CBIHeader
	{
		public string   _PC_mittente;
		public string   _PC_ricevente;
		public DateTime _PC_data_creazione = DateTime.MinValue;
		public string   _PC_nome_supporto;
		public string   _PC_campo_a_disposizione;
	}

	public class CBIDisposizione
	{
		public DateTime _10_data_esecuzione_disposizione = DateTime.MinValue;
		public DateTime _10_data_valuta_beneficiario = DateTime.MinValue;
		public decimal  _10_importo = 0;
		public string   _10_abi_ordinante = null;
		public string   _10_cab_ordinante = null;
		public string   _10_cc_ordinante = null;
		public string   _10_abi_destinatario = null;
		public string   _10_cab_destinatario = null;
		public string   _10_cc_destinatario = null;
		public string   _10_codice_azienda = null; // dovrebbe essere DisposizionePagamento.mittente

		public string   _20_ragione_sociale_ordinante;
		public string   _20_indirizzo_ordinante;
		public string   _20_localita_ordinante;
		public string   _20_piva_ordinante;

		public string   _30_ragione_sociale_beneficiario;

		public string   _50_causale;
	};

	public class CBIWriter : IDisposable
	{
		public CBIWriter()
		{
			this.tw = null;
			this.pc = null;
		}
		public CBIWriter(TextWriter tw, CBIHeader pc)
		{
			Open(tw, pc);
		}
		public CBIWriter(Stream stream, CBIHeader pc)
			: this(new StreamWriter(stream, Encoding.ASCII), pc)
		{
		}
		public CBIWriter(string fileName, CBIHeader pc)
			: this(new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None), pc)
		{
		}

		public bool TruncateField
		{
			get { return truncateField; }
			set { truncateField = value; }
		}

		public void Open(Stream stream, CBIHeader pc)
		{
			Open(new StreamWriter(stream, Encoding.ASCII), pc);
		}
		public void Open(TextWriter tw, CBIHeader pc)
		{
			if (tw == null)
				throw new ArgumentNullException("tw", "null TextWriter");
			if (pc == null)
				throw new ArgumentNullException("pc", "null CBIHeader");

			this.tw = tw;
			this.pc = pc;
		}

		public void ScriviDisposizione(CBIDisposizione pg)
		{
			if (WriteHeader)
			{
				if (this.tw == null)
					throw new InvalidOperationException("this.tw is null on CBIWriter.ScriviDisposizione");
				if (this.pc == null)
					throw new InvalidOperationException("this.pc is null on CBIWriter.ScriviDisposizione");

				RecordDiTesta();
				WriteHeader = false;
			}
			TipoRecord10(pg);
			TipoRecord20(pg);
			TipoRecord30(pg);
			TipoRecord50(pg);
			TipoRecord70(pg);
		}


		public void Close()
		{
			if (tw != null)
			{
				if (WriteHeader)
				{
					// caso strano ma possibile: non ci sono pagamenti da mandare
					RecordDiTesta();
					WriteHeader = false;
				}

				RecordDiCoda();
				tw.Flush();
				tw.Close();
				tw = null;
			}
		}


		enum of { o, f };

		CBIHeader pc = null;
		TextWriter tw = null;
		int _position = 0;
		bool WriteHeader = true;
		bool truncateField = true;

		int     _numero_disposizioni = 0;   // avanza non appena chiamato il TipoRecord10
		decimal _tot_importi_positivi = 0m; // in Euro; avanza su _10_importo
		int     _numero_record = 0;         // avanza ad ogni inizio_record()


		private void RecordDiTesta()
		{
			inizio_record(" PC");
			an(of.o,   4,   8, pc._PC_mittente);
			_n(of.o,   9,  13, pc._PC_ricevente);
			_n(of.o,  14,  19, pc._PC_data_creazione);
			an(of.o,  20,  39, pc._PC_nome_supporto);
			an(of.f,  40,  45, pc._PC_campo_a_disposizione);
			an(of.f,  46, 104, null); // filler
			an(of.f, 105, 111, null); // qualificatore di flusso
			an(of.f, 112, 113, null); // filler
			an(of.f, 114, 114, "E"); // codice divisa
			an(of.f, 115, 115, null); // filler
			_n(of.f, 116, 120, null); // centro applicativo
			fine_record();

		}
		private void RecordDiCoda()
		{
			inizio_record(" EF");
			an(of.o,   4,   8, pc._PC_mittente);
			_n(of.o,   9,  13, pc._PC_ricevente);
			_n(of.o,  14,  19, pc._PC_data_creazione);
			an(of.o,  20,  39, pc._PC_nome_supporto);
			an(of.f,  40,  45, pc._PC_campo_a_disposizione);
			_n(of.o,  46,  52, _numero_disposizioni.ToString(CultureInfo.InvariantCulture));
			_n(of.o,  53,  67, "0"); // tot. importi negativi
			_n(of.o,  68,  82, ((long)(_tot_importi_positivi * 100m /*cento*/ )).ToString(CultureInfo.InvariantCulture)); // tot. importi positivi
			_n(of.o,  83,  89, _numero_record.ToString(CultureInfo.InvariantCulture)); // numero record
			an(of.f,  90, 113, null); // filler
			an(of.f, 114, 114, "E"); // codice divisa
			_n(of.f, 115, 120, null); // giornata applicativa
			fine_record();
		}

		private void TipoRecord10(CBIDisposizione pg)
		{
			_numero_disposizioni += 1;

			inizio_record(" 10");
			_n(of.o,   4,  10, _numero_disposizioni.ToString(CultureInfo.InvariantCulture));
			an(of.f,  11,  16, null); // filler
			_n(of.f,  17,  22, pg._10_data_esecuzione_disposizione);
			_n(of.f,  23,  28, pg._10_data_valuta_beneficiario);
			an(of.o,  29,  33, "48000");
			_n(of.o,  34,  46, ((long)(pg._10_importo * 100m /*cento*/ )).ToString(CultureInfo.InvariantCulture));
			an(of.o,  47,  47, "+");

			_n(of.o,  48,  52, pg._10_abi_ordinante);
			_n(of.o,  53,  57, pg._10_cab_ordinante);
			an(of.o,  58,  69, pg._10_cc_ordinante);

			_n(of.o,  70,  74, pg._10_abi_destinatario); // e' obbligatorio per se il 144 e` blank
			_n(of.o,  75,  79, pg._10_cab_destinatario); 
			an(of.o,  80,  91, pg._10_cc_destinatario);

			an(of.f,  92,  96, pg._10_codice_azienda);
			_n(of.f,  97,  97, null); // tipo_codice
			an(of.f,  98, 113, null); // codice_cliente_beneficiario
			_n(of.f, 114, 114, null); // modalita pagamento

			an(of.f, 115, 119, null); // filler
			an(of.f, 120, 120, "E"); // codice divisa

			_tot_importi_positivi += pg._10_importo;
			fine_record();
		}

		private void TipoRecord20(CBIDisposizione pg)
		{
			inizio_record(" 20");
			_n(of.o,   4,  10, _numero_disposizioni.ToString(CultureInfo.InvariantCulture));
			an(of.o,  11,  40, pg._20_ragione_sociale_ordinante);
			an(of.f,  41,  70, pg._20_indirizzo_ordinante);
			an(of.f,  71, 100, pg._20_localita_ordinante);
			an(of.f, 101, 116, pg._20_piva_ordinante);
			an(of.f, 117, 120, null); // filler
			fine_record();
		}

		private void TipoRecord30(CBIDisposizione pg)
		{
			inizio_record(" 30");
			_n(of.o,   4,  10, _numero_disposizioni.ToString(CultureInfo.InvariantCulture));
			an(of.o,  11, 100, pg._30_ragione_sociale_beneficiario);
			an(of.f, 101, 116, null); // codice fiscale cliente creditore.
			an(of.f, 117, 120, null); // filler
			fine_record();
		}
		private void TipoRecord50(CBIDisposizione pg)
		{
			inizio_record(" 50");
			_n(of.o,   4,  10, _numero_disposizioni.ToString(CultureInfo.InvariantCulture));
			an(of.o,  11, 100, pg._50_causale);
			an(of.f, 101, 120, null); // filler
			fine_record();
		}
		private void TipoRecord70(CBIDisposizione pg)
		{
			inizio_record(" 70");
			_n(of.o,   4,  10, _numero_disposizioni.ToString(CultureInfo.InvariantCulture));
			an(of.f,  11, 120, null); // filler
			fine_record();
		}


		#region Dispose
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}
		protected virtual void Dispose(bool disposing)
		{
			if (this.disposed == false)
			{
				if (disposing)
					Close();

				this.disposed = true;         
			}
		}
		~CBIWriter()      
		{
			Dispose(false);
		}
		bool disposed = false;
		#endregion

		void an(of c, int posA, int posB, string v)
		{
			int n = posB - posA + 1;
			Debug.Assert(_position == posA);
			if (c == of.f && v == null)
				v = string.Empty; // se e' facoltativo assegno blank

			if (c == of.o && v == null)
				throw new ArgumentException("Generazione CBI: campo <an> obbligatorio", "v");

			if (truncateField == false && v.Length > n)
				throw new ArgumentException("Generazione CBI: campo <an> di lunghezza errata", "v");

			if (v.Length > n)
				v = v.Substring(0, n);

			string w = v.PadRight(n); // paddato con spazi a destra
			write(w);
		}

		void _n(of c, int posA, int posB, string v)
		{
			// v deve essere tutto numeri.
			int n = posB - posA + 1;
			Debug.Assert(_position == posA);

			if (c == of.f && v == null)
			{
				// i campi facoltativi, qualora non valorizzati, 
				// indipendentemente dal formato <n> o <an>
				// vanno impostati a blank
				write(string.Empty.PadLeft(n));
				return;
			}

			if (c == of.o && v == null)
				throw new ArgumentException("Generazione CBI: campo <n> obbligatorio", "v");

			Regex rg = new Regex("^[0-9]*$");
			if (rg.Match(v).Success == false)
				throw new ArgumentException("Generazione CBI: il campo <n> deve contenere solo numeri", "v");

			if (v.Length > n) // ignoro truncateField perche` se un numero sborda e` un problema serio.
				throw new ArgumentException("Generazione CBI: il campo <n> contiene troppi caratteri", "v");

			if (v.Length > n)
				v = v.Substring(0, n);  // lo so che non serve, ma non fa male.

			string w = v.PadLeft(n, '0'); // allineato a destra con zeri non significativi a sin.
			write(w);
		}
		void _n(of c, int posA, int posB, DateTime dt)
		{
			if (dt == DateTime.MinValue)
				_n(c, posA, posB, null);  // trucco per la data nulla
			else
			{
				int y = dt.Year >= 2000 ? dt.Year - 2000 : dt.Year - 1900;
				string v = string.Format("{0,2:00}{1,2:00}{2,2:00}", dt.Day, dt.Month, y);
				_n(c, posA, posB, v);
			}
		}

		void write(string v)
		{
			tw.Write(v);
			_position += v.Length;
		}

		void inizio_record(string tr)
		{
			_position = 1;
			write(tr);
			_numero_record += 1;
		}
		void fine_record()
		{
			tw.Write("\n"); // return in stile unix
		}
	}
}
