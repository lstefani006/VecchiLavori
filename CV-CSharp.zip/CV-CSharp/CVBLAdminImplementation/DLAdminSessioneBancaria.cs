using System;
using System.Data;
using System.Text;
using System.Data.OleDb;
using CVBLAdminImplementation;

namespace CV.Admin
{
	internal class DLAdminSessioneBancaria :  DLAdminBase
	{
		public DLAdminSessioneBancaria(OleDbTransaction tr, string IdSessione, bool ForUpdate)
			: base(tr)
		{
			_Transaction = tr;
			_IdSessione = IdSessione;
			_ForUpdate = ForUpdate;


			_Transazioni      = GetDA_Transazioni(_Transaction, _IdSessione);
			_MovimentiBancari = GetDA_MovimentiBancari(_Transaction, _IdSessione, _ForUpdate);
			_SessioniBancarie = GetDA_SessioniBancarie(_Transaction, _IdSessione, _ForUpdate);
			_TrBan            = GetDA_TrBan(_Transaction, _IdSessione);
			_Budgets          = GetDA_Budgets(_Transaction, _IdSessione, _ForUpdate);
			_Societa          = GetDA_Societa(_Transaction, null, null);
			_Sessioni         = GetDA_Sessioni(_Transaction, _IdSessione);
			//_MwCertificato    = GetDA_MwCertficato(_Transaction);
			_ReportCV         = GetDA_ReportCV(_Transaction, _IdSessione, false, _ForUpdate);
		}

		public OleDbTransaction Transaction
		{
			get { return _Transaction; }
		}

		readonly private string _IdSessione = null;
		readonly private OleDbTransaction _Transaction = null;
		readonly private bool _ForUpdate = false;

		readonly private OleDbDataAdapter _Transazioni = null;
		readonly private OleDbDataAdapter _MovimentiBancari = null;
		readonly private OleDbDataAdapter _SessioniBancarie = null;
		readonly private OleDbDataAdapter _TrBan = null;
		readonly private OleDbDataAdapter _Budgets = null;
		readonly private OleDbDataAdapter _Societa = null;
		readonly private OleDbDataAdapter _Sessioni = null;
		//readonly private OleDbDataAdapter _MwCertificato = null;
		readonly private OleDbDataAdapter _ReportCV = null;

		/// <summary>
		/// Carico tutto il data set con tutte le tabelle della sessione.
		/// </summary>
		/// <param name="ds"></param>
		public void Fill(dsGestioneBancaria ds)
		{
			// l'ordine di caricamento e' importante in quanto bisogna
			// rispettare le relazioni implementate nel data set passato
			// in ingresso
			//_MwCertificato.Fill(ds, ds.MwCertficato.TableName);
			_Societa.Fill(ds, ds.Societa.TableName);    
			_Sessioni.Fill(ds, ds.Sessioni.TableName);  
			_Transazioni.Fill(ds, ds.Transazioni.TableName);
			_MovimentiBancari.Fill(ds, ds.MovimentiBancari.TableName);
			_SessioniBancarie.Fill(ds, ds.SessioniBancarie.TableName);
			_TrBan.Fill(ds, ds.TrBan.TableName);
			_Budgets.Fill(ds, ds.Budgets.TableName);
			_ReportCV.Fill(ds, ds.ReportCV.TableName);

#if DEBUG
			ds.WriteXml(@"c:\ds_fill.xml");
#endif
		}

		/// <summary>
		/// salva tutto il data set nel DB
		/// (anche ReportCV !!).
		/// </summary>
		/// <param name="ds">DataSet da salvare nel DB</param>
		public void Update(dsGestioneBancaria ds, ref DateTime TSUltimaModifica)
		{
#if DEBUG
			ds.WriteXml(@"c:\ds_update.xml");
#endif
			if (ds.HasChanges() == false)
				return;

			if (ds.SessioniBancarie.Rows.Count > 0)
			{
				// sto modificando una sessione bancaria
				if (ds.SessioniBancarie[0].RowState == DataRowState.Modified ||
					ds.SessioniBancarie[0].RowState == DataRowState.Unchanged)
				{
					DateTime TSUltimaModificaNelDb = ds.SessioniBancarie[0].TSUltimaModifica;

					// per evitare problemi di arrotondamento dovuti al diverso
					// formato del DateTime di .NET e del DATE di Oracle.
					TimeSpan timeSpan = TSUltimaModificaNelDb - TSUltimaModifica;
					if (timeSpan.TotalSeconds > 1)
						throw new ApplicationException("Un altro operatore sta lavorando nella sessione bancaria\n" +
							"e ha modificato i dati.\n"+
							"Due o piu` operatori non possono operare contemporaneamente nella SessioneBancaria bancaria.");

					TSUltimaModifica = DateTime.Now;
					ds.SessioniBancarie[0].TSUltimaModifica = TSUltimaModifica;
				}
				else if (ds.SessioniBancarie[0].RowState == DataRowState.Added)
				{
					// sto creando la sessione bancaria
					// L'insert associato inserisce anche TSUltimaModifica
					TSUltimaModifica = DateTime.Now;
					ds.SessioniBancarie[0].TSUltimaModifica = TSUltimaModifica;
				}
			}


			// l'ordine di salvataggio e' importante in quanto bisogna
			// rispettare i constraints del data base.
			//_MwCertificato.Update(ds, ds.MwCertficato.TableName);
			_Transazioni.Update(ds, ds.Transazioni.TableName);

			_MovimentiBancari.Update(ds.MovimentiBancari.Select(null,null, DataViewRowState.Added));
			_MovimentiBancari.Update(ds.MovimentiBancari.Select(null,null, DataViewRowState.ModifiedCurrent));


			_Societa.Update(ds, ds.Societa.TableName); // tabella moidificata solo in Saldo
			_Sessioni.Update(ds, ds.Sessioni.TableName); // tabella mai modificata
			_Budgets.Update(ds, ds.Budgets.TableName);
			_SessioniBancarie.Update(ds, ds.SessioniBancarie.TableName);
			_TrBan.Update(ds, ds.TrBan.TableName);
			_ReportCV.Update(ds, ds.ReportCV.TableName);

			_MovimentiBancari.Update(ds.MovimentiBancari.Select(null,null, DataViewRowState.Deleted));

			//			_MwCertificato.Update(ds, ds.MwCertficato.TableName);
			//			_Transazioni.Update(ds, ds.Transazioni.TableName);
			//			_MovimentiBancari.Update(ds, ds.MovimentiBancari.TableName);
			//			_Societa.Update(ds, ds.Societa.TableName); // tabella moidificata solo in Saldo
			//			_Sessioni.Update(ds, ds.Sessioni.TableName); // tabella mai modificata
			//			_Budgets.Update(ds, ds.Budgets.TableName);
			//			_SessioniBancarie.Update(ds, ds.SessioniBancarie.TableName);
			//			_TrBan.Update(ds, ds.TrBan.TableName);
			//			_ReportCV.Update(ds, ds.ReportCV.TableName);

		}

		static private void ParOriginal(OleDbCommand cmd, OleDbType ty, int size, string source)
		{
			cmd.Parameters.Add(new OleDbParameter("Original_" + source, ty, size, ParameterDirection.Input, false, 0, 0, source, DataRowVersion.Original, null));
		}


		static private OleDbDataAdapter GetDA_Transazioni(OleDbTransaction tr, string IdSessione)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;

			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.UpdateCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			// la gestione bancaria non cancella le transazioni

			string sql = @"
				SELECT 
					RAWTOHEX(TR.IdTransazione) IdTransazione, 
					TR.QtyCertificati          QtyCertificati, 
					TR.PrezzoUnitario          PrezzoUnitario,
					OA.AnnoRiferimento         AnnoRiferimento,
					TR.DataOraOperazione       DataOraOperazione,
					TR.StatoTransazione        StatoTransazione,
					TR.FileExportBanca         FileExportBanca,
					TR.PagabileDaGme           PagabileDaGme,
					TR.Causale                 Causale,
					RAWTOHEX(UTA.IdSocieta)    IdSocietaAcq,
					RAWTOHEX(UTV.IdSocieta)    IdSocietaVen
				FROM 
					cv.Transazioni     TR, 
					cv.OfferteAcquisto OA, 
					cv.OfferteVendita  OV,
					us.Utenti          UTA, 
					us.Utenti          UTV
				WHERE
					OA.IdSessione = HEXTORAW(?)
				AND OV.IdSessione = HEXTORAW(?)
				AND TR.IdOffertaAcquisto = OA.IdOffertaAcquisto
				AND TR.IdOffertaVendita  = OV.IdOffertaVendita
				AND OA.IdUtente = UTA.IdUtente
				AND OV.IdUtente = UTV.IdUtente
				ORDER BY 
					IdSocietaAcq, IdSocietaVen
			";

			da.SelectCommand.CommandText = sql;
			da.SelectCommand.Parameters.Add("IdSessioneOA", IdSessione);
			da.SelectCommand.Parameters.Add("IdSessioneOV", IdSessione);


			// la sessione bancaria modifica solo questi campi
			da.UpdateCommand.CommandText = @"
				UPDATE cv.Transazioni
				SET
					StatoTransazione = ?,
					FileExportBanca = ?,
					PagabileDaGme = ?,
					Causale = ?
				WHERE IdTransazione = HEXTORAW(?)
			";
			da.UpdateCommand.Parameters.Add("StatoTransazione", OleDbType.VarWChar, 255, "StatoTransazione");
			da.UpdateCommand.Parameters.Add("FileExportBanca",  OleDbType.VarWChar, 255, "FileExportBanca");
			da.UpdateCommand.Parameters.Add("PagabileDaGme",    OleDbType.VarWChar, 255, "PagabileDaGme");
			da.UpdateCommand.Parameters.Add("Causale",          OleDbType.VarWChar, 255, "Causale");
			ParOriginal(da.UpdateCommand, OleDbType.VarWChar, 32, "IdTransazione");

			return da;
		}

		static private OleDbDataAdapter GetDA_TrBan(OleDbTransaction tr, string IdSessione)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;

			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.InsertCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.UpdateCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.DeleteCommand = new OleDbCommand(string.Empty, tr.Connection, tr);

			da.SelectCommand.CommandText = @"
				SELECT 
					RAWTOHEX(IdSessione)    AS IdSessione, 
					RAWTOHEX(IdTransazione) AS IdTransazione, 
					ImportoMovPP,
					ImportoMovGP,
					RAWTOHEX(IdMovPP)       AS IdMovPP,
					RAWTOHEX(IdMovGP)       AS IdMovGP,
					RAWTOHEX(IdMovPenale)   AS IdMovPenale
				FROM cv.TrBan
				WHERE IdSessione = HEXTORAW(?)";
			da.SelectCommand.Parameters.Add("IdSessione", IdSessione);

			da.InsertCommand.CommandText = @"
				INSERT INTO cv.TrBan
				(IdSessione, IdTransazione, ImportoMovPP, ImportoMovGP, IdMovPP,     IdMovGP,     IdMovPenale) 
				VALUES 
				(HEXTORAW(?), HEXTORAW(?),  ?,            ?,            HEXTORAW(?), HEXTORAW(?), HEXTORAW(?) )";
			da.InsertCommand.Parameters.Add("IdSessione",      OleDbType.VarWChar, 32, "IdSessione");
			da.InsertCommand.Parameters.Add("IdTransazione",   OleDbType.VarWChar, 32, "IdTransazione");
			da.InsertCommand.Parameters.Add("ImportoMovPP",    OleDbType.Decimal,   0, "ImportoMovPP");
			da.InsertCommand.Parameters.Add("ImportoMovGP",    OleDbType.Decimal,   0, "ImportoMovGP");
			da.InsertCommand.Parameters.Add("IdMovPP",         OleDbType.VarWChar, 32, "IdMovPP");
			da.InsertCommand.Parameters.Add("IdMovGP",         OleDbType.VarWChar, 32, "IdMovGP");
			da.InsertCommand.Parameters.Add("IdMovPenale",     OleDbType.VarWChar, 32, "IdMovPenale");

			da.UpdateCommand.CommandText = @"
				UPDATE cv.TrBan 
				SET 
					IdSessione      = HEXTORAW(?), 
					IdTransazione   = HEXTORAW(?), 
					ImportoMovPP    = ?,
					ImportoMovGP    = ?,
					IdMovPP         = HEXTORAW(?),
					IdMovGP         = HEXTORAW(?),
					IdMovPenale     = HEXTORAW(?)
				WHERE 
					IdSessione    = HEXTORAW(?) AND 
					IdTransazione = HEXTORAW(?)";

			da.UpdateCommand.Parameters.Add("IdSessione",     OleDbType.VarWChar, 32, "IdSessione");
			da.UpdateCommand.Parameters.Add("IdTransazione",  OleDbType.VarWChar, 32, "IdTransazione");
			da.UpdateCommand.Parameters.Add("ImportoMovPP",   OleDbType.Decimal,   1, "ImportoMovPP");
			da.UpdateCommand.Parameters.Add("ImportoMovGP",   OleDbType.Decimal,   1, "ImportoMovGP");
			da.UpdateCommand.Parameters.Add("IdMovPP",        OleDbType.VarWChar, 32, "IdMovPP");
			da.UpdateCommand.Parameters.Add("IdMovGP",        OleDbType.VarWChar, 32, "IdMovGP");
			da.UpdateCommand.Parameters.Add("IdMovPenale",    OleDbType.VarWChar, 32, "IdMovPenale");
			ParOriginal(da.UpdateCommand,                     OleDbType.VarWChar, 32, "IdSessione");
			ParOriginal(da.UpdateCommand,                     OleDbType.VarWChar, 32, "IdTransazione");

			da.DeleteCommand.CommandText = @"
				DELETE FROM cv.TrBan 
				WHERE 
					IdSessione    = HEXTORAW(?) 
				AND IdTransazione = HEXTORAW(?)";
			ParOriginal(da.DeleteCommand, OleDbType.VarWChar, 32, "IdSessione");
			ParOriginal(da.DeleteCommand, OleDbType.VarWChar, 32, "IdTransazione");

			return da;
		}

		static private OleDbDataAdapter GetDA_SessioniBancarie(OleDbTransaction tr, string IdSessione, bool ForUpdate)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;

			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.InsertCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.UpdateCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.DeleteCommand = new OleDbCommand(string.Empty, tr.Connection, tr);

			string sql;

			sql = @"
				SELECT 
					RAWTOHEX(IdSessione) IdSessione, 
					TSApertura, 
					TSChiusura,
					Note,
					TSUltimaModifica
				FROM cv.SessioniBancarie
				";

			if (IdSessione != null && IdSessione.Length > 0)
				sql += " WHERE cv.SessioniBancarie.IdSessione = HEXTORAW(?)";

			if (ForUpdate)
				sql += " FOR UPDATE ";

			da.SelectCommand.CommandText = sql;

			if (IdSessione != null && IdSessione.Length > 0)
				da.SelectCommand.Parameters.Add("IdSessione", IdSessione);

			/////////////////////////////////////

			da.InsertCommand.CommandText = @"
				INSERT INTO cv.SessioniBancarie 
				(IdSessione, TSApertura, TSChiusura, Note, TSUltimaModifica) 
				VALUES 
				(HEXTORAW(?), ?, ?, ?, ?)";
			da.InsertCommand.Parameters.Add("IdSessione",       OleDbType.VarWChar,     32, "IdSessione");
			da.InsertCommand.Parameters.Add("TSApertura",       OleDbType.DBTimeStamp,   0, "TSApertura");
			da.InsertCommand.Parameters.Add("TSChiusura",       OleDbType.DBTimeStamp,   0, "TSChiusura");
			da.InsertCommand.Parameters.Add("Note",             OleDbType.VarWChar,    255, "Note");
			da.InsertCommand.Parameters.Add("TSUltimaModifica", OleDbType.DBTimeStamp,   0, "TSUltimaModifica");

			da.UpdateCommand.CommandText = @"
				UPDATE cv.SessioniBancarie 
				SET 
					IdSessione = HEXTORAW(?), 
					TSApertura = ?, 
					TSChiusura = ?,
					Note = ?,
					TSUltimaModifica = ?
				WHERE 
					IdSessione = HEXTORAW(?)";
			da.UpdateCommand.Parameters.Add("IdSessione",       OleDbType.VarWChar,     32, "IdSessione");
			da.UpdateCommand.Parameters.Add("TSApertura",       OleDbType.DBTimeStamp,   0, "TSApertura");
			da.UpdateCommand.Parameters.Add("TSChiusura",       OleDbType.DBTimeStamp,   0, "TSChiusura");
			da.UpdateCommand.Parameters.Add("Note",             OleDbType.VarWChar,    255, "Note");
			da.UpdateCommand.Parameters.Add("TSUltimaModifica", OleDbType.DBTimeStamp,   0, "TSUltimaModifica");
			ParOriginal(da.UpdateCommand,                       OleDbType.VarWChar,     32, "IdSessione");

			da.DeleteCommand.CommandText = "DELETE FROM cv.SessioniBancarie WHERE IdSessione = HEXTORAW(?)";
			ParOriginal(da.DeleteCommand, OleDbType.VarWChar, 32, "IdSessione");

			return da;
		}

		static private OleDbDataAdapter GetDA_Budgets(OleDbTransaction tr, string IdSessione, bool ForUpdate)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;

			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.InsertCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.UpdateCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.DeleteCommand = new OleDbCommand(string.Empty, tr.Connection, tr);

			da.SelectCommand.CommandText = @"
				SELECT 
					RAWTOHEX(IdSessione) AS IdSessione, 
					RAWTOHEX(IdSocieta)  AS IdSocieta, 
					SaldoProposto,
					ImportoProposto, 
					Importo,
					PrezzoConvenzionaleUtente,
					PrezzoConvenzionaleUtenteMw,
					Residuo,
					RAWTOHEX(IdMovResiduo) AS IdMovResiduo
				FROM cv.Budgets BU
				WHERE BU.IdSessione = HEXTORAW(?)";
			if (ForUpdate)
				da.SelectCommand.CommandText += " FOR UPDATE";
			da.SelectCommand.Parameters.Add("IdSessione", IdSessione);

			da.InsertCommand.CommandText = @"
				INSERT INTO cv.Budgets
				(IdSessione, IdSocieta, SaldoProposto, ImportoProposto, Importo, 
				 PrezzoConvenzionaleUtente, PrezzoConvenzionaleUtenteMw, Residuo, IdMovResiduo) 
				VALUES 
				(HEXTORAW(?), HEXTORAW(?), ?, ?, ?, ?, ?, ?, HEXTORAW(?))";

			da.InsertCommand.Parameters.Add("IdSessione",                  OleDbType.VarWChar, 32, "IdSessione");
			da.InsertCommand.Parameters.Add("IdSocieta",                   OleDbType.VarWChar, 32, "IdSocieta");
			da.InsertCommand.Parameters.Add("SaldoProposto",               OleDbType.Decimal,   0, "SaldoProposto");
			da.InsertCommand.Parameters.Add("ImportoProposto",             OleDbType.Decimal,   0, "ImportoProposto");
			da.InsertCommand.Parameters.Add("Importo",                     OleDbType.Decimal,   0, "Importo");
			da.InsertCommand.Parameters.Add("PrezzoConvenzionaleUtente",   OleDbType.Decimal,   0, "PrezzoConvenzionaleUtente");
			da.InsertCommand.Parameters.Add("PrezzoConvenzionaleUtenteMw", OleDbType.Decimal,   0, "PrezzoConvenzionaleUtenteMw");
			da.InsertCommand.Parameters.Add("Residuo",                     OleDbType.Decimal,   0, "Residuo");
			da.InsertCommand.Parameters.Add("IdMovResiduo",                OleDbType.VarWChar, 32, "IdMovResiduo");

			da.UpdateCommand.CommandText = @"
				UPDATE cv.Budgets 
				SET 
					IdSessione = HEXTORAW(?), 
					IdSocieta = HEXTORAW(?),
					SaldoProposto = ?,
					ImportoProposto = ?, 
					Importo = ?, 
					PrezzoConvenzionaleUtente = ?, 
					PrezzoConvenzionaleUtenteMw = ?, 
					Residuo = ?,
					IdMovResiduo = HEXTORAW(?)
			WHERE IdSessione = HEXTORAW(?) AND IdSocieta = HEXTORAW(?)";

			da.UpdateCommand.Parameters.Add("IdSessione",                  OleDbType.VarWChar, 32, "IdSessione");
			da.UpdateCommand.Parameters.Add("IdSocieta",                   OleDbType.VarWChar, 32, "IdSocieta");
			da.UpdateCommand.Parameters.Add("SaldoProposto",               OleDbType.Decimal,   0, "SaldoProposto");
			da.UpdateCommand.Parameters.Add("ImportoProposto",             OleDbType.Decimal,   0, "ImportoProposto");
			da.UpdateCommand.Parameters.Add("Importo",                     OleDbType.Decimal,   0, "Importo");
			da.UpdateCommand.Parameters.Add("PrezzoConvenzionaleUtente",   OleDbType.Decimal,   0, "PrezzoConvenzionaleUtente");
			da.UpdateCommand.Parameters.Add("PrezzoConvenzionaleUtenteMw", OleDbType.Decimal,   0, "PrezzoConvenzionaleUtenteMw");
			da.UpdateCommand.Parameters.Add("Residuo",                     OleDbType.Decimal,   0, "Residuo");
			da.UpdateCommand.Parameters.Add("IdMovResiduo",                OleDbType.VarWChar, 32, "IdMovResiduo");
			ParOriginal(da.UpdateCommand,                                  OleDbType.VarWChar, 32, "IdSessione");
			ParOriginal(da.UpdateCommand,                                  OleDbType.VarWChar, 32, "IdSocieta");

			da.DeleteCommand.CommandText = @"
				DELETE FROM cv.BudgetSB 
				WHERE IdSessione = HEXTORAW(?) AND IdSocieta = HEXTORAW(?)";
			ParOriginal(da.DeleteCommand, OleDbType.VarWChar, 32, "IdSessione");
			ParOriginal(da.DeleteCommand, OleDbType.VarWChar, 32, "IdSocieta");

			return da;
		}

		static private OleDbDataAdapter GetDA_MovimentiBancari(OleDbTransaction tr, string IdSessione, bool ForUpdate)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;

			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.InsertCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.UpdateCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.DeleteCommand = new OleDbCommand(string.Empty, tr.Connection, tr);

			string sql = @"
				SELECT 
					RAWTOHEX(IdMovimentoBancario) as IdMovimentoBancario, 
					RAWTOHEX(IdSocietaSrc) as IdSocietaSrc, 
					RAWTOHEX(IdSocietaDst) as IdSocietaDst, 
					TipoMovimento, 
					Importo, 
					Valuta,
					Causale, 
					TSSottomesso, 
					TSPerfezionato, 
					Note,
					RAWTOHEX(IdSessione) as IdSessione,
					SocSrc.RagioneSociale as SocietaSrc_RagioneSociale,
					SocSrc.CodiceConto    as SocietaSrc_CodiceConto,
					SocDst.RagioneSociale as SocietaDst_RagioneSociale,
					SocDst.CodiceConto    as SocietaDst_CodiceConto
				FROM cv.MovimentiBancari MV, us.Societa SocSrc, us.Societa SocDst
				WHERE 
					    MV.IdSessione = HEXTORAW(?)
					AND MV.IdSocietaSrc = SocSrc.IdSocieta
					AND MV.IdSocietaDst = SocDst.IdSocieta
				ORDER BY IdSocietaSrc, IdSocietaDst
			";

			if (ForUpdate)
				sql += " FOR UPDATE";
			
			da.SelectCommand.CommandText = sql;
			da.SelectCommand.Parameters.Add("IdSessione", IdSessione);

			da.InsertCommand.CommandText = @"
				INSERT INTO cv.MovimentiBancari
				(IdMovimentoBancario, IdSocietaSrc, IdSocietaDst, Importo, Valuta, Causale, TipoMovimento, TSPerfezionato, TSSottomesso, Note, IdSessione)
				VALUES 
				(HEXTORAW(?), HEXTORAW(?), HEXTORAW(?), ?, ?, ?, ?, ?, ?, ?, HEXTORAW(?))";
			da.InsertCommand.Parameters.Add("IdMovimentoBancario", OleDbType.VarWChar,     32, "IdMovimentoBancario");
			da.InsertCommand.Parameters.Add("IdSocietaSrc",        OleDbType.VarWChar,     32, "IdSocietaSrc");
			da.InsertCommand.Parameters.Add("IdSocietaDst",        OleDbType.VarWChar,     32, "IdSocietaDst");
			da.InsertCommand.Parameters.Add("Importo",             OleDbType.Decimal,       0, "Importo");
			da.InsertCommand.Parameters.Add("Valuta",              OleDbType.DBTimeStamp,   0, "Valuta");
			da.InsertCommand.Parameters.Add("Causale",             OleDbType.VarWChar,    255, "Causale");
			da.InsertCommand.Parameters.Add("TipoMovimento",       OleDbType.VarWChar,      2, "TipoMovimento");
			da.InsertCommand.Parameters.Add("TSPerfezionato",      OleDbType.DBTimeStamp,   0, "TSPerfezionato");
			da.InsertCommand.Parameters.Add("TSSottomesso",        OleDbType.DBTimeStamp,   0, "TSSottomesso");
			da.InsertCommand.Parameters.Add("Note",                OleDbType.VarWChar,    255, "Note");
			da.InsertCommand.Parameters.Add("IdSessione",          OleDbType.VarWChar,     32, "IdSessione");

			da.UpdateCommand.CommandText = @"
				UPDATE cv.MovimentiBancari 
				SET 
					IdMovimentoBancario = HEXTORAW(?), 
					IdSocietaSrc = HEXTORAW(?), 
					IdSocietaDst = HEXTORAW(?), 
					TipoMovimento = ?, 
					Importo = ?, 
					Causale = ?, 
					Valuta = ?,
					TSSottomesso = ?, 
					TSPerfezionato = ?, 
					Note = ?,
					IdSessione = HEXTORAW(?)
				WHERE IdMovimentoBancario = HEXTORAW(?)";
			da.UpdateCommand.Parameters.Add("IdMovimentoBancario", OleDbType.VarWChar,     32, "IdMovimentoBancario");
			da.UpdateCommand.Parameters.Add("IdSocietaSrc",        OleDbType.VarWChar,     32, "IdSocietaSrc");
			da.UpdateCommand.Parameters.Add("IdSocietaDst",        OleDbType.VarWChar,     32, "IdSocietaDst");
			da.UpdateCommand.Parameters.Add("TipoMovimento",       OleDbType.VarWChar,      2, "TipoMovimento");
			da.UpdateCommand.Parameters.Add("Importo",             OleDbType.Decimal,       0, "Importo");
			da.UpdateCommand.Parameters.Add("Causale",             OleDbType.VarWChar,    255, "Causale");
			da.UpdateCommand.Parameters.Add("Valuta",              OleDbType.DBTimeStamp,   0, "Valuta");
			da.UpdateCommand.Parameters.Add("TSSottomesso",        OleDbType.DBTimeStamp,   0, "TSSottomesso");
			da.UpdateCommand.Parameters.Add("TSPerfezionato",      OleDbType.DBTimeStamp,   0, "TSPerfezionato");
			da.UpdateCommand.Parameters.Add("Note",                OleDbType.VarWChar,    255, "Note");
			da.UpdateCommand.Parameters.Add("IdSessione",          OleDbType.VarWChar,    32,  "IdSessione");
			ParOriginal(da.UpdateCommand,                          OleDbType.VarWChar,     32, "IdMovimentoBancario");

			da.DeleteCommand.CommandText = @"
				DELETE FROM cv.MovimentiBancari WHERE IdMovimentoBancario = HEXTORAW(?)";
			ParOriginal(da.DeleteCommand, OleDbType.VarWChar, 32, "IdMovimentoBancario");

			return da;
		}

		static private OleDbDataAdapter GetDA_Societa(OleDbTransaction tr, string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;

			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.UpdateCommand = new OleDbCommand(string.Empty, tr.Connection, tr);

			string sqlCmd = @"SELECT 
				RAWTOHEX(IdSocieta) AS IdSocieta,
				RagioneSociale,
				Indirizzo,
				Citta,
				CAP,
				Nazione,
				CodiceFiscale,
				PartitaIVA,
				Telefono,
				Fax,
				Email,
				ABI,
				CAB,
				CC,
				CodiceConto,
				ReferenteAmministr,
				SedeAmministrativa,
				ChiaveContoProprieta,
				DataOraInserimento,
				DataOraModifica,
				RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc,
				Saldo
				FROM US.Societa "; 

			if (sql != null && sql.Length > 0)
				sqlCmd += " WHERE (" + sql + ")";

			da.SelectCommand.CommandText = sqlCmd;

			if (parsWhere != null)
				foreach (OleDbParameter p in parsWhere)
					da.SelectCommand.Parameters.Add(p);

			///////////////////////////////////////////
			da.UpdateCommand.CommandText = @"
				UPDATE US.Societa 
				SET    Saldo = ? 
				WHERE  IdSocieta = HEXTORAW(?)";
			da.UpdateCommand.Parameters.Add("Saldo", OleDbType.Decimal, 19, "Saldo");
			ParOriginal(da.UpdateCommand, OleDbType.VarWChar, 32, "IdSocieta");

			return da;
		}
		static private OleDbDataAdapter GetDA_Sessioni(OleDbTransaction tr, string IdSessione)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;

			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);

			StringBuilder sb = new StringBuilder(500);
			sb.Append(@"
				SELECT 
					RAWTOHEX(IdSessione) as IdSessione, 
					StatoSessione, 
					Titolo,
					DataOraApertura,
					DataOraChiusura,
					PrezzoConvenzionale
				FROM cv.Sessioni SS
				");

			if (IdSessione != null && IdSessione.Length > 0)
				sb.Append(" WHERE SS.IdSessione = HEXTORAW(?)");

			da.SelectCommand.CommandText = sb.ToString();

			if (IdSessione != null && IdSessione.Length > 0)
				da.SelectCommand.Parameters.Add("IdSessione", IdSessione);

			return da;
		}
//		static private OleDbDataAdapter GetDA_MwCertficato(OleDbTransaction tr)
//		{
//			OleDbDataAdapter da = new OleDbDataAdapter();
//			da.MissingSchemaAction = MissingSchemaAction.Error;
//
//			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
//			da.SelectCommand.CommandText = "SELECT Anno, QtyMWh FROM cv.MwCertificato"; // StePuntoAperto
//			return da;
//		}
		/*
		static private OleDbDataAdapter GetDA_ReportCV_Filler(OleDbTransaction tr, string IdSessione, string IdReport, string [] TipoReport)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;

			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);

			StringBuilder sb = new StringBuilder(500);
			sb.Append(@"
				SELECT 
					RAWTOHEX(IdReport) AS IdReport, 
					TipoReport, 
					NomeReport, 
					FormatoReport, 
					RawReport, 
					RAWTOHEX(IdSessione) AS IdSessione, 
					RAWTOHEX(IdSocieta)  AS IdSocieta, 
					TSCreazione, 
					TSPubblicazione, 
					TSDownload, 
					TSInvio, 
					TSRicevuto,
					RAWTOHEX(IdReportGroup) AS IdReportGroup,
					Note
				FROM cv.ReportCV
				");

			bool Where = false;
			if (IdSessione != null && IdSessione.Length > 0)
			{
				sb.Append(" WHERE cv.ReportCV.IdSessione = HEXTORAW(?)");
				da.SelectCommand.Parameters.Add("IdSessione", IdSessione);
				Where = true;
			}

			if (IdReport != null && IdReport.Length > 0)
			{
				if (Where)
					sb.Append(" AND   (cv.ReportCV.IdReport = HEXTORAW(?))");
				else
					sb.Append(" WHERE (cv.ReportCV.IdReport = HEXTORAW(?))");
				da.SelectCommand.Parameters.Add("IdReport", IdReport);
				Where = true;
			}

			if (TipoReport != null && TipoReport.Length > 0)
			{
				if (Where)
					sb.Append(" AND (");
				else
					sb.Append(" WHERE (");

				bool First = true;
				foreach (string s in TipoReport)
				{
					if (First == false)
						sb.Append(" OR ");
					else
						First = false;

					sb.Append("cv.ReportCV.TipoReport = ?");
					da.SelectCommand.Parameters.Add("TipoReport_" + s, s);
				}
				sb.Append(")");
				Where = true;
			}
			da.SelectCommand.CommandText = sb.ToString();

			return da;
		}
		*/

		static private OleDbDataAdapter GetDA_ReportCV(OleDbTransaction tr, string IdSessione, bool updateTSDownload, bool ForUpdate)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();
			da.MissingSchemaAction = MissingSchemaAction.Error;


			da.SelectCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.InsertCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.UpdateCommand = new OleDbCommand(string.Empty, tr.Connection, tr);
			da.DeleteCommand = new OleDbCommand(string.Empty, tr.Connection, tr);

			StringBuilder sb = new StringBuilder(500);
			sb.Append(@"
				SELECT 
					RAWTOHEX(IdReport) AS IdReport, 
					TipoReport, 
					NomeReport, 
					FormatoReport, 
					RawReport, 
					RAWTOHEX(IdSessione) AS IdSessione, 
					RAWTOHEX(IdSocieta)  AS IdSocieta, 
					TSCreazione, 
					TSPubblicazione, 
					TSDownload, 
					TSInvio, 
					TSRicevuto,
					RAWTOHEX(IdReportGroup) AS IdReportGroup,
					Note
				FROM cv.ReportCV
				WHERE 
					cv.ReportCV.IdSessione = HEXTORAW(?)
				");

			if (ForUpdate)
				sb.Append(" For Update");

			da.SelectCommand.CommandText = sb.ToString();
			da.SelectCommand.Parameters.Add("IdSessione", IdSessione);



			da.InsertCommand.CommandText = @"
				INSERT INTO cv.ReportCV 
				(FormatoReport, IdReport, IdSessione, IdSocieta, NomeReport, RawReport, TipoReport, TSCreazione, TSDownload, TSInvio, TSPubblicazione, TSRicevuto, IdReportGroup, Note) 
				VALUES 
				(?, HEXTORAW(?), HEXTORAW(?), HEXTORAW(?), ?, ?, ?, ?, ?, ?, ?, ?, HEXTORAW(?), ?)";

			da.InsertCommand.Parameters.Add("FormatoReport",   OleDbType.VarWChar, 10, "FormatoReport");
			da.InsertCommand.Parameters.Add("IdReport",        OleDbType.VarWChar, 32, "IdReport");
			da.InsertCommand.Parameters.Add("IdSessione",      OleDbType.VarWChar, 32, "IdSessione");
			da.InsertCommand.Parameters.Add("IdSocieta",       OleDbType.VarWChar, 32, "IdSocieta");
			da.InsertCommand.Parameters.Add("NomeReport",      OleDbType.VarWChar, 255, "NomeReport");
			da.InsertCommand.Parameters.Add("RawReport",       OleDbType.LongVarBinary, 10*1024*1024, "RawReport");
			da.InsertCommand.Parameters.Add("TipoReport",      OleDbType.VarWChar,   10, "TipoReport");
			da.InsertCommand.Parameters.Add("TSCreazione",     OleDbType.DBTimeStamp, 0, "TSCreazione");
			da.InsertCommand.Parameters.Add("TSDownload",      OleDbType.DBTimeStamp, 0, "TSDownload");
			da.InsertCommand.Parameters.Add("TSInvio",         OleDbType.DBTimeStamp, 0, "TSInvio");
			da.InsertCommand.Parameters.Add("TSPubblicazione", OleDbType.DBTimeStamp, 0, "TSPubblicazione");
			da.InsertCommand.Parameters.Add("TSRicevuto",      OleDbType.DBTimeStamp, 0, "TSRicevuto");
			da.InsertCommand.Parameters.Add("IdReportGroup",   OleDbType.VarWChar, 32, "IdReportGroup");
			da.InsertCommand.Parameters.Add("Note",            OleDbType.VarWChar, 255, "Note");

			da.UpdateCommand.CommandText = @"
				UPDATE cv.ReportCV 
				SET 
					FormatoReport = ?, 
					IdReport = HEXTORAW(?), 
					IdSessione = HEXTORAW(?), 
					IdSocieta = HEXTORAW(?),
					NomeReport = ?, 
					RawReport = ?,	
					TipoReport = ?, 
					TSCreazione = ?, " + 
				(updateTSDownload ? "TSDownload = ?, " : "") + @"
					TSInvio = ?, 
					TSPubblicazione = ?, 
					TSRicevuto = ?,
					IdReportGroup = HEXTORAW(?),
					Note = ?
			WHERE IdReport = HEXTORAW(?)";
			da.UpdateCommand.Parameters.Add("FormatoReport",   OleDbType.VarWChar,   10, "FormatoReport");
			da.UpdateCommand.Parameters.Add("IdReport",        OleDbType.VarWChar,   32, "IdReport");
			da.UpdateCommand.Parameters.Add("IdSessione",      OleDbType.VarWChar,   32, "IdSessione");
			da.UpdateCommand.Parameters.Add("IdSocieta",       OleDbType.VarWChar,   32, "IdSocieta");
			da.UpdateCommand.Parameters.Add("NomeReport",      OleDbType.VarWChar,   255, "NomeReport");
			da.UpdateCommand.Parameters.Add("RawReport",       OleDbType.LongVarBinary, 100*1000*1000, "RawReport");
			da.UpdateCommand.Parameters.Add("TipoReport",      OleDbType.VarWChar,   10, "TipoReport");
			da.UpdateCommand.Parameters.Add("TSCreazione",     OleDbType.DBTimeStamp, 0, "TSCreazione");
			if (updateTSDownload)
				da.UpdateCommand.Parameters.Add("TSDownload",  OleDbType.DBTimeStamp, 0, "TSDownload");
			da.UpdateCommand.Parameters.Add("TSInvio",         OleDbType.DBTimeStamp, 0, "TSInvio");
			da.UpdateCommand.Parameters.Add("TSPubblicazione", OleDbType.DBTimeStamp, 0, "TSPubblicazione");
			da.UpdateCommand.Parameters.Add("TSRicevuto",      OleDbType.DBTimeStamp, 0, "TSRicevuto");
			da.UpdateCommand.Parameters.Add("IdReportGroup",   OleDbType.VarWChar,   32, "IdReportGroup");
			da.UpdateCommand.Parameters.Add("Note",            OleDbType.VarWChar,  255, "Note");
			ParOriginal(da.UpdateCommand,                      OleDbType.VarWChar,   32, "IdReport");

			da.DeleteCommand.CommandText = "DELETE FROM cv.ReportCV WHERE IdReport = HEXTORAW(?)";
			ParOriginal(da.DeleteCommand, OleDbType.VarWChar, 32, "IdReport");
 
			return da;
		}

	}
}


