using System;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Societa : CVRemotingBase, ISocieta
	{
		public Societa()
		{
		}
		public string GetABISocieta(string IdSocieta)
		{
			return "ABI12345";
		}
	}
}
