using System;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminCertificatiVerdi.
	/// </summary>
	internal class DLAdminCertificatoVerde : DLAdminBase
	{
		public DLAdminCertificatoVerde(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		protected OleDbDataAdapter GetDataAdapter()
		{
			return GetDataAdapter(null, (OleDbParameter [])null);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			// Query di SELECT per il Data Adapter
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				// N.B. Lo spazio alla fine della stringa e' MOLTO IMPORTANTE non toglierlo!!!!!
				string sqlCmd = "SELECT " + 
					"RAWTOHEX(IdCertificatoVerde) IdCertificatoVerde, " + 
					"AnnoRiferimento, " +
					"Qty, " +
					"QtyImpegnata, " +
					"DataOraCreazione, " +
					"RAWTOHEX(IdSessione) IdSessione, " + 
					"RAWTOHEX(IdSocieta) IdSocieta " + 
					"FROM CV.CertificatiVerdi CertificatiVerdi ";

				if (sql != null && sql.Length > 0)
					sqlCmd += sql;

				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// INSERT
			if (true)
			{
				//OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Update", m_Transaction.Connection, m_Transaction);
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText =	@"
					INSERT INTO CV.CertificatiVerdi (
					IdCertificatoVerde, 
					AnnoRiferimento, 
					Qty, 
					QtyImpegnata, 
					DataOraCreazione, 
					IdSessione, 
					IdSocieta 
					) VALUES ( HEXTORAW(?), ?, ?, 0, SYSDATE, HEXTORAW(?), HEXTORAW(?) )
				";

				cmd.Parameters.Add(new OleDbParameter("IdCertificatoVerde",             OleDbType.VarChar,      32, "IdCertificatoVerde"));
				cmd.Parameters.Add(new OleDbParameter("AnnoRiferimento",	            OleDbType.VarChar,       4, "AnnoRiferimento"));				
				cmd.Parameters.Add(new OleDbParameter("Qty",							OleDbType.Decimal,       0, "Qty"));
				
				cmd.Parameters.Add(new OleDbParameter("IdSessione",		                OleDbType.VarChar,      32, "IdSessione"));
				cmd.Parameters.Add(new OleDbParameter("IdSocieta",		                OleDbType.VarChar,      32, "IdSocieta"));
				

				da.InsertCommand = cmd;
			}

			// UPDATE
			// da verificare se necessaria

			// DELETE
			// da verificare se necessaria
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText =	@"
					DELETE FROM CV.CertificatiVerdi
					WHERE IdCertificatoVerde = HEXTORAW(?)
				";

				cmd.Parameters.Add(new OleDbParameter("IdCertificatoVerde", OleDbType.VarChar, 32, "IdCertificatoVerde"));

				da.DeleteCommand = cmd;
			}

			da.MissingSchemaAction = MissingSchemaAction.Error;
			return da;
		}

		public void Update(DataSet ds)
		{
			OleDbDataAdapter da = GetDataAdapter();
			da.Update(ds, "CertificatiVerdi");
		}

		public DataSet GetDataSet()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("CertificatiVerdi");

			DataColumn c;
			c = dt.Columns.Add("IdCertificatoVerde", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = true;

			c = dt.Columns.Add("AnnoRiferimento", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 4;
			c.Unique = false;

			c = dt.Columns.Add("Qty", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("QtyImpegnata", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("DataOraCreazione", typeof(DateTime));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("IdSessione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("IdSocieta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;


			dt.PrimaryKey = new DataColumn[] { dt.Columns["IdCertificatoVerde"] };

			return ds;
		}

		public void SalvaConto(string IdSessione, string NumeroConto, string RagioneSociale)
		{
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandType = CommandType.Text;
				cmd.CommandText = "INSERT INTO CV.NonIscritti ( " +
					"IdNonIscritto, " +
					"IdSessione, " +
					"NumeroConto, " +
					"RagioneSociale) " +
					"VALUES (newid(), HEXTORAW(?), ?, ?)";

				cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
				cmd.Parameters.Add("NumeroConto", OleDbType.VarChar).Value = NumeroConto;
				cmd.Parameters.Add("RagioneSociale", OleDbType.VarChar).Value = RagioneSociale;
				cmd.ExecuteNonQuery();
			}
		}

		public void UpdateOrInsertNonIscritti(string IdSessione, string NumeroConto, string RagioneSociale)
		{
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText =	"UPDATE CV.NonIscritti SET " +
					"RagioneSociale = ? " +
					"WHERE IdSessione = ? and NumeroConto=?";
				cmd.Parameters.Add("RagioneSociale", RagioneSociale);
				cmd.Parameters.Add("IdSessione", IdSessione);
				cmd.Parameters.Add("NumeroConto", NumeroConto);

				int d = cmd.ExecuteNonQuery();

				Debug.Assert(d == 0 || d == 1);

				if (d != 0)
					return;
			}

			SalvaConto(IdSessione, NumeroConto, RagioneSociale);
		}




		public void CancellaSocietaDaNonIscritti(string IdSessione, string NumeroConto)
		{
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandType = CommandType.Text;
				cmd.CommandText = "DELETE FROM CV.NonIscritti WHERE IdSessione=HEXTORAW(?) AND NumeroConto=?";
				cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
				cmd.Parameters.Add("NumeroConto", OleDbType.VarChar).Value = NumeroConto;
				cmd.ExecuteNonQuery();
			}
		}

		public void CancellaNonIscrittiDellaSessione(string IdSessione)
		{
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandType = CommandType.Text;
				cmd.CommandText = "DELETE FROM CV.NonIscritti WHERE IdSessione=HEXTORAW(?)";
				cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
				cmd.ExecuteNonQuery();
			}
		}


		public void CancellaCVDellaSessione(string IdSessione)
		{
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandType = CommandType.Text;
				cmd.CommandText = "DELETE FROM CV.CertificatiVerdi WHERE IdSessione=HEXTORAW(?)";
				cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
				cmd.ExecuteNonQuery();
			}
		}

#if VECCHIO_MWCERTIFICATO //Stefano
		public DataSet RetrieveMwCertificato()
		{
			string sql = "ORDER BY Anno DESC";
			OleDbDataAdapter da = GetDataAdapterMwCertificato(sql, (OleDbParameter [])null);
			DataSet ds = DataSet_MwCertificato();
			da.Fill(ds, "MwCertificato");
			return ds;
		}


		protected OleDbDataAdapter GetDataAdapterMwCertificato(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			// Query di SELECT per il Data Adapter
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				// N.B. Lo spazio alla fine della stringa e' MOLTO IMPORTANTE non toglierlo!!!!!
				
				/*cento*/ //Stefano StePuntoAperto
				//Questa select non puo` piu` essere formulata !
				//Come risolviamo l'informazione degli anni disponibili ?
				string sqlCmd = "SELECT " + 
								"Anno, " + 
								"QtyMwh " +
								"FROM CV.MWCERTIFICATO ";

				if (sql != null && sql.Length > 0)
					sqlCmd += sql;

				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// INSERT
			if (true)
			{
				//OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Update", m_Transaction.Connection, m_Transaction);
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);

				/*cento*/ //Stefano StePuntoAperto
				//Questa operazione non puo` piu` essere formulata su una tabella che non esistera` piu`.
				cmd.CommandText =	"INSERT INTO CV.MWCERTIFICATO ( " +
									"Anno, " +
									"QtyMwh " +
									") VALUES (?, ?)";

				cmd.Parameters.Add(new OleDbParameter("Anno",	OleDbType.VarChar,      4, "Anno"));
				cmd.Parameters.Add(new OleDbParameter("QtyMwh",	OleDbType.Decimal,      0, "QtyMwh"));
				da.InsertCommand = cmd;
			}

			// UPDATE
			if (true)
			{  // StePuntoAperto
				//OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Update", m_Transaction.Connection, m_Transaction);
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText =	"UPDATE CV.MWCERTIFICATO SET " +
									"Anno = ?, " +
									"QtyMwh = ? " +
									"WHERE Anno = ?";
				cmd.Parameters.Add(new OleDbParameter("Anno",	OleDbType.VarChar,      4, "Anno"));
				cmd.Parameters.Add(new OleDbParameter("QtyMwh",	OleDbType.Decimal,      0, "QtyMwh"));
				cmd.Parameters.Add(new OleDbParameter("Original_Anno",	OleDbType.VarChar,      4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Anno", System.Data.DataRowVersion.Original, null));
				da.UpdateCommand = cmd;
			}

			// DELETE
			if (true)
			{
				// StePuntoAperto
				//OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Update", m_Transaction.Connection, m_Transaction);
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText =	"DELETE FROM CV.MWCERTIFICATO " +
									"WHERE Anno = ?";
				cmd.Parameters.Add(new OleDbParameter("Anno",	OleDbType.VarChar,      4, "Anno"));
				da.DeleteCommand = cmd;
			}

			da.MissingSchemaAction = MissingSchemaAction.Error;
			return da;
		}

		public void UpdateMwCertificato(DataSet ds)
		{
			OleDbDataAdapter da = GetDataAdapterMwCertificato(null, (OleDbParameter [])null);
			da.Update(ds, "MwCertificato");
		}

		private DataSet DataSet_MwCertificato()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("MwCertificato");

			DataColumn c;
			c = dt.Columns.Add("Anno", typeof(string));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("QtyMwh", typeof(decimal)); //Qui si puo` lasciare invariato.
			c.AllowDBNull = false;
			c.Unique = false;

			dt.PrimaryKey = new DataColumn[] { dt.Columns["Anno"] };
			return ds;

		}
#endif


		public DataSet GetCertificatiVerdiBySessione(string IdSessione)
		{
			DataSet ds = GetDataSet();

			OleDbParameter [] p = new OleDbParameter[1];
			p[0] = new OleDbParameter("IdSessione", OleDbType.VarChar);
			p[0].Value = IdSessione;

			OleDbDataAdapter da = GetDataAdapter("WHERE IdSessione = HEXTORAW(?)", p);
			da.Fill(ds, "CertificatiVerdi");
			return ds;
		}
	}
}
