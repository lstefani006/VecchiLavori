using System;
using System.Data;
using System.Diagnostics;

namespace CV.Admin
{
	/// <summary>
	/// 
	/// </summary>
	public class BLAdminRichieste : CVRemotingBase, IBLAdminRichieste
	{
		public BLAdminRichieste()
		{
		}

		public void Update(DataSet ds)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					this.Update(dbTran, ds);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal void Update(IDbTransaction dbTran, DataSet ds)
		{
			DLAdminRichieste dl = new DLAdminRichieste(dbTran);
			dl.Update(ds);
			return;
		}

		public DataSet Search()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DataSet dsSocieta = this._Search(tr);
					DataSet dsUtenti  = this._SearchUtenti(tr);

					DataTable dtUtenti  = dsUtenti.Tables[0].Copy();
					DataTable dtSocieta = dsSocieta.Tables[0];

					// Aggiungo la tabelle delle richieste di registrazione degli
					// Utenti al DataSet delle Societa'
					dsSocieta.Tables.Add(dtUtenti);

					// Creo la relazione tra le due tabelle [RichiesteSocieta, RichiesteUtenti]
					DataColumn richiestaSocietaCol = dsSocieta.Tables[0].Columns["IdRichiestaRegSoc"];
					DataColumn richiestaUtentiCol  = dtUtenti.Columns["IdRichiestaRegSoc"]; 
					DataRelation relSocietaUtenti  = new DataRelation("relSocietaUtenti", richiestaSocietaCol, richiestaUtentiCol);

					dsSocieta.Relations.Add(relSocietaUtenti);

					tr.Commit();

#if DEBUG
					dsSocieta.WriteXml(@"c:\cv_richieste.xml");
#endif
					return dsSocieta;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}

		public DataSet _Search(IDbTransaction tr)
		{
			DLAdminRichieste dl = new DLAdminRichieste(tr);
			return dl.Search("");
		}

		public DataSet _SearchUtenti(IDbTransaction tr)
		{
			DLAdminRichieste dl = new DLAdminRichieste(tr);
			return dl.SearchUtenti("");
		}
	}
}
