using System;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;


namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminSessione.
	/// </summary>
	internal class DLAdminSessione : DLAdminBase
	{
		public DLAdminSessione(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		static public bool ContrattaCVAnnoMin(int Month, out int AnnoMin, out int AnnoMax)
		{
			string min = System.Configuration.ConfigurationSettings.AppSettings["ContrattaCVAnnoMin"];
			string max = System.Configuration.ConfigurationSettings.AppSettings["ContrattaCVAnnoMax"];
			DateTime dt = DateTime.Now ;
			try
			{
				int n = Convert.ToInt16(min);
				AnnoMin = dt.AddYears(n).Year ;
			}
			catch(Exception ex)
			{
				AnnoMin = dt.AddYears(-1).Year ;
			}
			try
			{
				int n = Convert.ToInt16(max);
				AnnoMax = dt.AddYears(n).Year ;
			}
			catch(Exception ex)
			{
				AnnoMax = dt.AddYears(+1).Year ;
			}

			string s = System.Configuration.ConfigurationSettings.AppSettings["ContrattaCVAnnoMin.Range"];
			if (s == null)
				return Month >= 1 && Month <= 10;

			string []a = s.Split(' ', ',', ':', '-');
			if (a.Length < 2)
				return Month >= 1 && Month <= 10;

			int inizio = int.Parse(a[0]);
			int fine   = int.Parse(a[1]);

			return Month >= inizio && Month <= fine;
		}

		// OK
		public DataSet GetBookAcquisto(string IdSessione, string AnnoRiferimento)
		{
			string strSqlQuery = "SELECT SUM(QtyRichiesta) AS QtyRichiesta, " + 
				"SUM(QtyResidua) AS QtyResidua, " + 
				"AnnoRiferimento, PrezzoUnitario " +
				"FROM CV.OfferteAcquisto " +
				"WHERE IdSessione = HEXTORAW(?) " +
				"AND AnnoRiferimento LIKE ? " +
				"AND QtyResidua <> 0 " +
				"AND PrezzoUnitario <> 0 " +
				"AND Compatibile <> 0 " +
				"GROUP BY PrezzoUnitario, AnnoRiferimento " +
				"ORDER BY PrezzoUnitario DESC";

			// LIKE
			AnnoRiferimento += "%";
			
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsBookAcquisto");
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
				selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
				da.Fill(ds, "BookAcquisto");
				return ds;
			}
		}

		// OK
		public DataSet GetBookVendita(string IdSessione, string AnnoRiferimento)
		{
			string strSqlQuery = "SELECT SUM(QtyOfferta) AS QtyOfferta, " + 
				"SUM(QtyResidua) AS QtyResidua, " + 
				"AnnoRiferimento, PrezzoUnitario " +
				"FROM CV.OfferteVendita " +
				"WHERE  IdSessione = HEXTORAW(?) " +
				"AND AnnoRiferimento LIKE ? " +
				"AND QtyResidua <> 0 " +
				"AND PrezzoUnitario <> 0 " +
				"AND Compatibile <> 0 " +
				"GROUP BY PrezzoUnitario, AnnoRiferimento " +
				"ORDER BY PrezzoUnitario ASC";
			
			// LIKE
			AnnoRiferimento += "%";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsBookVendita");
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
				selectCMD.Parameters.Add("@AnnoRiferimento", OleDbType.VarChar, 4).Value = AnnoRiferimento;
				da.Fill(ds, "BookVendita");
				return ds;
			}
		}


		// OK
		public DataSet GetCurrentWebSession()
		{
			string sqlWhere = null;

			if (sqlWhere == null)
			{
				using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
				{
					cmd.CommandText = "SELECT COUNT(*) FROM cv.Sessioni " +
						" WHERE DataOraApertura <= SYSDATE " + 
						" AND DataOraChiusura >= SYSDATE " +
						" AND StatoSessione = 'Aperta' ";

					int rows = (int)(decimal)cmd.ExecuteScalar();
					if (rows > 0)
					{
						sqlWhere =
							"WHERE DataOraApertura <= SYSDATE " +
							"AND DataOraChiusura >= SYSDATE " +
							"AND StatoSessione = 'Aperta' ";
					}
				}
			}

			if (sqlWhere == null)
			{
				using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
				{
					cmd.CommandText = "SELECT COUNT(*) FROM cv.Sessioni " +
                      "WHERE DataOraApertura <= SYSDATE " +
                      "AND DataOraChiusura >= SYSDATE " +
                      "AND StatoSessione = 'Sospesa'";

					int rows = (int)(decimal)cmd.ExecuteScalar();
					if (rows > 0)
					{
						sqlWhere =
							"WHERE DataOraApertura <= SYSDATE " +
							"AND DataOraChiusura >= SYSDATE " +
							"AND StatoSessione = 'Sospesa' ";
					}
				}
			}

			if (sqlWhere == null)
			{
				using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
				{
					cmd.CommandText = "SELECT COUNT(*) FROM cv.Sessioni " +
						"WHERE DataOraApertura < SYSDATE " +
						"AND DataOraChiusura < SYSDATE " +
						"AND StatoSessione = 'Terminata'";

					int rows = (int)(decimal)cmd.ExecuteScalar();
					if (rows > 0)
					{
						sqlWhere =
							"WHERE DataOraApertura < SYSDATE " +
							"AND DataOraChiusura < SYSDATE " +
							"AND StatoSessione = 'Terminata' ";
					}
				}
			}

			if (sqlWhere == null)
			{
				sqlWhere = " WHERE (DataOraApertura < SYSDATE " +
					" AND DataOraChiusura < SYSDATE) " +
					" OR StatoSessione = 'Abortita' " +
					" ORDER BY DataOraChiusura DESC ";
 			}

			string sqlCmd = "SELECT " + 
					"RAWTOHEX(IdSessione) AS IdSessione, " +
					"Titolo, " + 
					"DataOraApertura, " + 
					"DataOraChiusura, " +
					"PrezzoRiferimentoAnnoPrec10, " +
					"PrezzoRiferimentoAnnoPrec09, " +
					"PrezzoRiferimentoAnnoPrec08, " +
					"PrezzoRiferimentoAnnoPrec07, " +
					"PrezzoRiferimentoAnnoPrec06, " +
					"PrezzoRiferimentoAnnoPrec05, " +
					"PrezzoRiferimentoAnnoPrec04, " +
					"PrezzoRiferimentoAnnoPrec03, " +
					"PrezzoRiferimentoAnnoPrec02, " +
					"PrezzoRiferimentoAnnoPrec, " +
					"PrezzoRiferimentoAnnoCorr, " +
					"PrezzoRiferimentoAnnoSucc, " +
					"PrezzoRiferimentoAnnoSucc02, " +
					"PrezzoRiferimentoAnnoSucc03, " +
					"PrezzoRiferimentoAnnoSucc04, " +
					"PrezzoRiferimentoAnnoSucc05, " +
					"PrezzoRiferimentoAnnoSucc06, " +
					"PrezzoRiferimentoAnnoSucc07, " +
					"PrezzoRiferimentoAnnoSucc08, " +
					"PrezzoRiferimentoAnnoSucc09, " +
					"PrezzoRiferimentoAnnoSucc10, " + 
					"PrezzoConvenzionale, " + 
					"DataOraCreazione, " + 
					"DataOraModifica, " + 
					"StatoSessione " +
					"FROM CV.Sessioni " + sqlWhere;

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = DataSet_Sessioni();
				da.SelectCommand = new OleDbCommand(sqlCmd, m_Transaction.Connection, m_Transaction);
				da.Fill(ds, "Sessioni");
				return ds;
			}


//			string sqlCmd;
//			using (OleDbCommand cmd = new OleDbCommand("CV.sp_GetCurrentWebSession", m_Transaction.Connection, m_Transaction))
//			{
//				cmd.CommandType = CommandType.StoredProcedure;
//
//				// notare che retval e' il nome di una var. di output della stored procedure
//
//				// N.B. Non e' possibile inserire un valore maggiore di 4000 per un VarChar!!!!!!!!!!!!!!!
//				OleDbParameter ret = new OleDbParameter("@retval", OleDbType.VarChar, 4000, ParameterDirection.Output, false, ((System.Byte)(0)),((System.Byte)(0)),"",DataRowVersion.Default, null);
//				cmd.Parameters.Add(ret);
//				cmd.ExecuteNonQuery();
//				sqlCmd = cmd.Parameters["@retval"].Value.ToString();
//			}
//
//			using (OleDbDataAdapter da = new OleDbDataAdapter())
//			{
//				DataSet ds = DataSet_Sessioni();
//				da.SelectCommand = new OleDbCommand(sqlCmd, m_Transaction.Connection, m_Transaction);
//				da.Fill(ds, "Sessioni");
//				return ds;
//			}
		}


		// OK
		public bool IsEnabled(string IdSessione)
		{
			// Nella SELECT ho inserito anche la SYSDATE in modo da non dover 
			// effettuare un'altra SELECT per recuperare la data di sistema
			string strSqlQuery = "SELECT SYSDATE DataCorrente, " + 
				"DataOraApertura, DataOraChiusura, StatoSessione " +
				"FROM cv.Sessioni WHERE IdSessione = HEXTORAW(?)";

			using (OleDbCommand cmd = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction))
			{
				cmd.Parameters.Add("@IdSessione", OleDbType.VarChar).Value = IdSessione;
				using (OleDbDataReader dr = cmd.ExecuteReader())
				{
					if (dr.Read())
					{
						DateTime currentDate = (DateTime)dr["DataCorrente"];
						DateTime dataOraApertura = (DateTime)dr["DataOraApertura"];
						DateTime dataOraChiusura = (DateTime)dr["DataOraChiusura"];
						string strStatoSessione = (string)dr["StatoSessione"];

						dr.Close();

						if ((dataOraApertura <= currentDate) &&
							(dataOraChiusura >= currentDate) &&
							(strStatoSessione.Trim() != "Sospesa") &&
							(strStatoSessione.Trim() != "Abortita"))
						{
							return true;
						}
						else
						{
							return false;
						}
					}
				}
			}
			return false;
		}


		// OK
		/*
		public void	Delete(string IdSessione)
		{
			// creo una riga "finta" con la chiave giusta
			DataSet ds = new DataSet();
			DateTime dt = new DateTime(2000,1,1,1,1,1,1);
			ds.Sessioni.AddSessioniRow(IdSessione, "titolo",dt,dt,0,0,0,0,dt,dt,"Aperta");
			ds.AcceptChanges(); //simulo una lettura da DB
			ds.Sessioni.FindByIdSessione(IdSessione).Delete(); // cancello la riga nel ds

			GetDataAdapter().Update(ds); // effettuo la cancellazione nel DB
		}
		*/

		
		// OK
//		public string Insert(InfoSessione infoS)
//		{
//			using (OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Add", m_Transaction.Connection, m_Transaction))
//			{
//				cmd.CommandType = CommandType.StoredProcedure;
//
//				// Titolo (input)
//				OleDbParameter parTitolo = new OleDbParameter("@Titolo", OleDbType.VarChar);
//				parTitolo.Direction = ParameterDirection.Input;
//				parTitolo.IsNullable = false;
//				parTitolo.Value = infoS.Titolo;
//				cmd.Parameters.Add(parTitolo);
//
//				// Data Ora Apertura (input)
//				OleDbParameter parDataOraApertura = new OleDbParameter("@DataOraApertura", OleDbType.DBTimeStamp);
//				parDataOraApertura.Direction = ParameterDirection.Input;
//				parDataOraApertura.IsNullable = false;
//				parDataOraApertura.Value = infoS.DataOraApertura;
//				cmd.Parameters.Add(parDataOraApertura);
//
//				// Data Ora Chiusura (input)
//				OleDbParameter parDataOraChiusura = new OleDbParameter("@DataOraChiusura", OleDbType.DBTimeStamp);
//				parDataOraChiusura.Direction = ParameterDirection.Input;
//				parDataOraChiusura.IsNullable = false;
//				parDataOraChiusura.Value = infoS.DataOraChiusura;
//				cmd.Parameters.Add(parDataOraChiusura);
//
//				// Prezzo Convenzionale (input)
//				OleDbParameter parPrezzoConvenzionale = new OleDbParameter("@PrezzoConvenzionale", OleDbType.Currency);
//				parPrezzoConvenzionale.Direction = ParameterDirection.Input;
//				parPrezzoConvenzionale.IsNullable = false;
//				parPrezzoConvenzionale.Value = infoS.PrezzoConvenzionale;
//				cmd.Parameters.Add(parPrezzoConvenzionale);
//			
//				// Prezzo Riferimento Anno Precedente (input)
//				OleDbParameter parPrezzoRifAnnoPrec = new OleDbParameter("@PrezzoRifAnnoPrec", OleDbType.Currency);
//				parPrezzoRifAnnoPrec.Direction = ParameterDirection.Input;
//				parPrezzoRifAnnoPrec.IsNullable = false;
//				parPrezzoRifAnnoPrec.Value = infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrec;
//				cmd.Parameters.Add(parPrezzoRifAnnoPrec);
//
//				// Prezzo Riferimento Anno Corrente (input)
//				OleDbParameter parPrezzoRifAnnoCorr = new OleDbParameter("@PrezzoRifAnnoCorr", OleDbType.Currency);
//				parPrezzoRifAnnoCorr.Direction = ParameterDirection.Input;
//				parPrezzoRifAnnoCorr.IsNullable = false;
//				parPrezzoRifAnnoCorr.Value = infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorr;
//				cmd.Parameters.Add(parPrezzoRifAnnoCorr);
//
//				// Prezzo Riferimento Anno Successivo (input)
//				OleDbParameter parPrezzoRifAnnoSucc = new OleDbParameter("@PrezzoRifAnnoSucc", OleDbType.Currency);
//				parPrezzoRifAnnoSucc.Direction = ParameterDirection.Input;
//				parPrezzoRifAnnoSucc.IsNullable = false;
//				parPrezzoRifAnnoSucc.Value = infoS.InfoPrezzi.PrezzoRiferimentoAnnoSucc;
//				cmd.Parameters.Add(parPrezzoRifAnnoSucc);
//
//				// ID Sessione (output)
//				OleDbParameter parIDSessione = new OleDbParameter("@IdSessione", OleDbType.VarChar);
//				parIDSessione.Direction = ParameterDirection.Output;
//				parIDSessione.IsNullable = false;
//				cmd.Parameters.Add(parIDSessione);
//
//				cmd.ExecuteNonQuery();
//
//				return (string)cmd.Parameters["@IdSessione"].Value;
//			}
//		}

		// OK
		public DataSet Retrieve(string Titolo, string StatoSessione)
		{
			OleDbParameter [] pars = new OleDbParameter[2];
			pars[0] = new OleDbParameter("Titolo", OleDbType.VarChar);
			pars[0].Value = Titolo + "%";

			pars[1] = new OleDbParameter("StatoSessione", OleDbType.VarChar);
			pars[1].Value = StatoSessione + "%";

			using (OleDbDataAdapter da = GetDataAdapter("WHERE Titolo LIKE ? AND StatoSessione LIKE ? ORDER BY Titolo", pars))
			{
				DataSet ds = DataSet_Sessioni();
				da.Fill(ds, "Sessioni");
				return ds;
			}

			/*
			string sqlSelect = "SELECT " +
				"RAWTOHEX(IdSessione) AS IdSessione, " +
				"Titolo, " +
				"DataOraApertura, " +
				"DataOraChiusura, " +
				"PrezzoRiferimentoAnnoPrec, " +
				"PrezzoRiferimentoAnnoCorr, " + 
				"PrezzoRiferimentoAnnoSucc, " +
				"PrezzoConvenzionale, " + 
				"DataOraCreazione, " +
				"DataOraModifica, " + 
				"StatoSessione " + 
				"FROM CV.Sessioni " +
				"WHERE Titolo LIKE ? " +
				"AND StatoSessione LIKE ? " + 
				"ORDER BY Titolo";

			// a causa del LIKE:
			Titolo += "%";
			StatoSessione += "%";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				da.SelectCommand = new OleDbCommand(sqlSelect, m_Transaction.Connection, m_Transaction);
				da.SelectCommand.Parameters.Add("Titolo",        OleDbType.VarChar).Value = Titolo;
				da.SelectCommand.Parameters.Add("StatoSessione", OleDbType.VarChar).Value = StatoSessione;

				DataSet ds = new DataSet();
				da.Fill(ds, "Sessioni");
				return ds;
			}
			*/
		}
		
		
		// OK
		public DataSet RetrieveActive(string IdSessione)
		{
			OleDbParameter par = new OleDbParameter("Titolo", OleDbType.VarChar);
			par.Value = IdSessione;

			string sql;
			sql = "WHERE IdSessione = HEXTORAW(?) AND StatoSessione IN ('In Attesa', 'Predisposta', 'Aperta')";

			using (OleDbDataAdapter da = GetDataAdapter(sql, par))
			{
				DataSet ds = DataSet_Sessioni();
				da.Fill(ds, "Sessioni");
				return ds;
			}
			/*
			OleDbParameter[] pars = new OleDbParameter[1];
			pars[0] = new OleDbParameter("IdSessione", OleDbType.VarChar);
			pars[0].Value = IdSessione;
			return Retrieve(
				"WHERE IdSessione  = HEXTORAW(?) " +
				"AND StatoSessione IN ('In Attesa', 'Predisposta', 'Aperta')",
				pars,
				null);
			*/
		}

		// OK
		public PrezziRiferimento RetrievePrezzoRiferimento(string IdSessione, int AnnoRif)
		{
			string sql = "SELECT NVL(SUM(CV.Transazioni.Qtycertificati * CV.Transazioni.PrezzoUnitario) / SUM(CV.Transazioni.Qtycertificati), 0) " +
				"FROM CV.OfferteVendita, CV.Transazioni " +
				"WHERE CV.OfferteVendita.IdSessione = HEXTORAW(?) " +
				"AND CV.OfferteVendita.IdOffertaVendita = CV.Transazioni.IdOffertaVendita " +
				"AND CV.OfferteVendita.AnnoRiferimento = ?";

			PrezziRiferimento pr = new PrezziRiferimento();

			for (int y = -10; y <= +10; ++y)
			{
				OleDbCommand cmd = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
				cmd.Parameters.Add("@IdSessione", OleDbType.VarChar).Value = IdSessione;
				cmd.Parameters.Add("@AnnoRif", OleDbType.VarChar).Value = (AnnoRif + y).ToString();

				using (OleDbDataReader dr = cmd.ExecuteReader())
				{
					while (dr.Read())
					{
						decimal nn = 0;
						if (dr.IsDBNull(0))
							nn = 0;
						else
							nn = (decimal)dr[0];

						if (y == -10)
							pr.PrezzoRiferimentoAnnoPrec10 = nn;
						else if (y == -9)
							pr.PrezzoRiferimentoAnnoPrec09 = nn;
						else if (y == -8)
							pr.PrezzoRiferimentoAnnoPrec08 = nn;
						else if (y == -7)
							pr.PrezzoRiferimentoAnnoPrec07 = nn;
						else if (y == -6)
							pr.PrezzoRiferimentoAnnoPrec06 = nn;
						else if (y == -5)
							pr.PrezzoRiferimentoAnnoPrec05 = nn;
						else if (y == -4)
							pr.PrezzoRiferimentoAnnoPrec04 = nn;
						else if (y == -3)
							pr.PrezzoRiferimentoAnnoPrec03 = nn;
						else if (y == -2)
							pr.PrezzoRiferimentoAnnoPrec02 = nn;
						else if (y == -1)
							pr.PrezzoRiferimentoAnnoPrec = nn;
						else if (y == 0)
							pr.PrezzoRiferimentoAnnoCorr = nn;
						else if (y == +1)
							pr.PrezzoRiferimentoAnnoSucc = nn;
						else if (y == +2)
							pr.PrezzoRiferimentoAnnoSucc02 = nn;
						else if (y == +3)
							pr.PrezzoRiferimentoAnnoSucc03 = nn;
						else if (y == +4)
							pr.PrezzoRiferimentoAnnoSucc04 = nn;
						else if (y == +5)
							pr.PrezzoRiferimentoAnnoSucc05 = nn;
						else if (y == +6)
							pr.PrezzoRiferimentoAnnoSucc06 = nn;
						else if (y == +7)
							pr.PrezzoRiferimentoAnnoSucc07 = nn;
						else if (y == +8)
							pr.PrezzoRiferimentoAnnoSucc08 = nn;
						else if (y == +9)
							pr.PrezzoRiferimentoAnnoSucc09 = nn;
						else if (y == +10)
							pr.PrezzoRiferimentoAnnoSucc10 = nn;

						break;
					}
				}
			}
			return pr;
		}

		
		// OK
		public DataSet RetrieveByIdSessione(string IdSessione)
		{
			OleDbParameter par = new OleDbParameter("IdSessione", OleDbType.VarChar);
			par.Value = IdSessione;

			string sql = "WHERE IdSessione = HEXTORAW(?)";

			using (OleDbDataAdapter da = GetDataAdapter(sql, par))
			{
				DataSet ds = DataSet_Sessioni();
				da.Fill(ds, "Sessioni");
				return ds;
			}
		}


		// OK
		public DataSet ClearGrid()
		{
			DataSet ds = DataSet_Sessioni();
			return ds;
		}
		
		

		// OK
		public void Update(DataSet ds)
		{
			OleDbDataAdapter da = GetDataAdapter();

//			DiagnosticHelper.DataSetDump("DLAdminSessione prima dell'Update", ds);
			da.Update(ds, "Sessioni");
//			DiagnosticHelper.DataSetDump("DLAdminSessione dopo l'Update", ds);
		}


		public void UpdateToPredisposta(string IdSessione)
		{
//			OleDbCommand cmd = new OleDbCommand("CV.sp_Sess_UpdateToPredisposta", m_Transaction.Connection, m_Transaction);
//			cmd.CommandType = CommandType.StoredProcedure;
//			cmd.Parameters.Add("@IdSessione", IdSessione);
//			cmd.ExecuteNonQuery();

			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = "UPDATE cv.Sessioni SET StatoSessione = 'Predisposta' WHERE IdSessione = HEXTORAW(?) " ;
				cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
				cmd.ExecuteNonQuery();
			}
		}
		
		/*
		public InfoSessione GetInfo(string Titolo, string Stato)
		{
			string strSqlQuery = "SELECT RAWTOHEX(IdSessione) IdSessione, " + 
				"Titolo, DataOraApertura, DataOraChiusura, " + 
				"PrezzoRiferimentoAnnoPrec, " + 
				"PrezzoRiferimentoAnnoCorr, " + 
				"PrezzoRiferimentoAnnoSucc, " + 
				"PrezzoConvenzionale, " + 
				"DataOraCreazione, " + 
				"DataOraModifica, " + 
				"StatoSessione " +
				"FROM CV.Sessioni Sessioni " +
				"WHERE  Titolo LIKE ? " + 
				"AND StatoSessione LIKE ?";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsInfoSessione");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@Titolo", OleDbType.VarChar, 255).Value = Titolo;
					selectCMD.Parameters.Add("@StatoSessione", OleDbType.VarChar, 255).Value = Stato;
					da.Fill(ds, "InfoSessione");
					DataTable dt = ds.Tables["InfoSessione"];
					InfoSessione infoS = new InfoSessione();
					if (dt.Rows.Count != 0)
					{
						// Prelevo le informazioni della Sessione

						// ID Sessione
						if (!dt.Rows[0].IsNull("IdSessione"))
						{
							infoS.IdSessione = dt.Rows[0].IsNull("IdSessione").ToString();
							infoS.IdSessioneIsNull = false;
						}
						else
						{
							infoS.IdSessione = "";
							infoS.IdSessioneIsNull = true;
						}

						// Titolo
						infoS.Titolo = Titolo;
						infoS.TitoloIsNull = false;
						
						// Data Ora Apertura
						if (!dt.Rows[0].IsNull("DataOraApertura"))
						{
							infoS.DataOraApertura = (DateTime)dt.Rows[0]["DataOraApertura"];
							infoS.DataOraAperturaIsNull = false;
						}
						else
						{
							infoS.DataOraAperturaIsNull = true;
						}

						// Data Ora Chiusura
						if (!dt.Rows[0].IsNull("DataOraChiusura"))
						{
							infoS.DataOraChiusura = (DateTime)dt.Rows[0]["DataOraChiusura"];
							infoS.DataOraChiusuraIsNull = false;
						}
						else
						{
							infoS.DataOraChiusuraIsNull = true;
						}

						// Prezzo Riferimento Anno Precedente
						if (!dt.Rows[0].IsNull("PrezzoRiferimentoAnnoPrec"))
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrec = (decimal)dt.Rows[0]["PrezzoRiferimentoAnnoPrec"];
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrecIsNull = false;
						}
						else
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrec = 0M;
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrecIsNull = true;
						}

						// Prezzo Riferimento Anno Corrente
						if (!dt.Rows[0].IsNull("PrezzoRiferimentoAnnoCorr"))
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorr = (decimal)dt.Rows[0]["PrezzoRiferimentoAnnoCorr"];
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorrIsNull = false;
						}
						else
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorr = 0M;
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorrIsNull = true;
						}
						// Prezzo Riferimento Anno Successivo
						if (!dt.Rows[0].IsNull("PrezzoRiferimentoAnnoSucc"))
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoSucc = (decimal)dt.Rows[0]["PrezzoRiferimentoAnnoSucc"];
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoSuccIsNull = false;
						}
						else
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoSucc = 0M;
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoSuccIsNull = true;
						}
						// Prezzo Convenzionale
						if (!dt.Rows[0].IsNull("PrezzoConvenzionale"))
						{
							infoS.PrezzoConvenzionale = (decimal)dt.Rows[0]["PrezzoConvenzionale"];
							infoS.PrezzoConvenzionaleIsNull = false;
						}
						else
						{
							infoS.PrezzoConvenzionale = 0M;
							infoS.PrezzoConvenzionaleIsNull = true;
						}

						// Data/Ora Creazione
						if (!dt.Rows[0].IsNull("DataOraCreazione"))
						{
							infoS.DataOraCreazione = (DateTime)dt.Rows[0]["DataOraCreazione"];
							infoS.DataOraCreazioneIsNull = false;
						}
						else
						{
							infoS.DataOraCreazioneIsNull = true;
						}

						// Data/Ora Modifica
						if (!dt.Rows[0].IsNull("DataOraModifica"))
						{
							infoS.DataOraModifica = (DateTime)dt.Rows[0]["DataOraModifica"];
							infoS.DataOraModificaIsNull = false;
						}
						else
						{
							infoS.DataOraModificaIsNull = true;
						}

						// Stato Sessione
						infoS.StatoSessione = Stato;
						infoS.StatoSessioneIsNull = false;
					}					
					return infoS;
				}
			}
		}

		public InfoSessione GetInfoByID(string IdSessione)
		{
			string strSqlQuery = "SELECT RAWTOHEX(IdSessione) AS IdSessione, " + 
				"Titolo, DataOraApertura, DataOraChiusura, " +
				"PrezzoRiferimentoAnnoPrec, " + 
				"PrezzoRiferimentoAnnoCorr, " + 
				"PrezzoRiferimentoAnnoSucc, " +
				"PrezzoConvenzionale, DataOraCreazione, " + 
				"DataOraModifica, StatoSessione " +
				"FROM CV.Sessioni " +
				"WHERE IdSessione = HEXTORAW(?)";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = new DataSet("dsInfoSessione");
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					da.SelectCommand = selectCMD;
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
					da.Fill(ds, "InfoSessione");
					DataTable dt = ds.Tables["InfoSessione"];
					InfoSessione infoS = new InfoSessione();
					if (dt.Rows.Count != 0)
					{
						// Prelevo le informazioni della Sessione

						// ID Sessione
						infoS.IdSessione = IdSessione;
						infoS.IdSessioneIsNull = false;

						// Titolo
						if (!dt.Rows[0].IsNull("Titolo"))
						{
							infoS.Titolo = dt.Rows[0]["Titolo"].ToString();
							infoS.TitoloIsNull = false;
						}
						else
						{
							infoS.Titolo = "";
							infoS.TitoloIsNull = true;
						}
						// Data Ora Apertura
						if (!dt.Rows[0].IsNull("DataOraApertura"))
						{
							infoS.DataOraApertura = (DateTime)dt.Rows[0]["DataOraApertura"];
							infoS.DataOraAperturaIsNull = false;
						}
						else
						{
							infoS.DataOraAperturaIsNull = true;
						}

						// Data Ora Chiusura
						if (!dt.Rows[0].IsNull("DataOraChiusura"))
						{
							infoS.DataOraChiusura = (DateTime)dt.Rows[0]["DataOraChiusura"];
							infoS.DataOraChiusuraIsNull = false;
						}
						else
						{
							infoS.DataOraChiusuraIsNull = true;
						}

						// Prezzo Riferimento Anno Precedente
						if (!dt.Rows[0].IsNull("PrezzoRiferimentoAnnoPrec"))
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrec = (decimal)dt.Rows[0]["PrezzoRiferimentoAnnoPrec"];
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrecIsNull = false;
						}
						else
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrec = 0M;
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoPrecIsNull = true;
						}

						// Prezzo Riferimento Anno Corrente
						if (!dt.Rows[0].IsNull("PrezzoRiferimentoAnnoCorr"))
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorr = (decimal)dt.Rows[0]["PrezzoRiferimentoAnnoCorr"];
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorrIsNull = false;
						}
						else
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorr = 0M;
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoCorrIsNull = true;
						}
						// Prezzo Riferimento Anno Successivo
						if (!dt.Rows[0].IsNull("PrezzoRiferimentoAnnoSucc"))
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoSucc = (decimal)dt.Rows[0]["PrezzoRiferimentoAnnoSucc"];
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoSuccIsNull = false;
						}
						else
						{
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoSucc = 0M;
							infoS.InfoPrezzi.PrezzoRiferimentoAnnoSuccIsNull = true;
						}
						// Prezzo Convenzionale
						if (!dt.Rows[0].IsNull("PrezzoConvenzionale"))
						{
							infoS.PrezzoConvenzionale = (decimal)dt.Rows[0]["PrezzoConvenzionale"];
							infoS.PrezzoConvenzionaleIsNull = false;
						}
						else
						{
							infoS.PrezzoConvenzionale = 0M;
							infoS.PrezzoConvenzionaleIsNull = true;
						}

						// Data/Ora Creazione
						if (!dt.Rows[0].IsNull("DataOraCreazione"))
						{
							infoS.DataOraCreazione = (DateTime)dt.Rows[0]["DataOraCreazione"];
							infoS.DataOraCreazioneIsNull = false;
						}
						else
						{
							infoS.DataOraCreazioneIsNull = true;
						}

						// Data/Ora Modifica
						if (!dt.Rows[0].IsNull("DataOraModifica"))
						{
							infoS.DataOraModifica = (DateTime)dt.Rows[0]["DataOraModifica"];
							infoS.DataOraModificaIsNull = false;
						}
						else
						{
							infoS.DataOraModificaIsNull = true;
						}

						// Stato Sessione
						if (!dt.Rows[0].IsNull("StatoSessione"))
						{
							infoS.StatoSessione = dt.Rows[0]["StatoSessione"].ToString();
							infoS.StatoSessioneIsNull = false;
						}
						else
						{
							infoS.StatoSessione = "";
							infoS.StatoSessioneIsNull = true;
						}
					}					
					return infoS;
				}
			}
		}
		*/

		/*
		public DataSet Retrieve(string sqlWhere, OleDbParameter [] parsWhere, string sqlOther)
		{
			string sql = "SELECT " +
				"RAWTOHEX(IdSessione) AS IdSessione, " +
				"Titolo, " +
				"DataOraApertura, " +
				"DataOraChiusura, " +
				"PrezzoRiferimentoAnnoPrec, " +
				"PrezzoRiferimentoAnnoCorr, " + 
				"PrezzoRiferimentoAnnoSucc, " +
				"PrezzoConvenzionale, " + 
				"DataOraCreazione, " +
				"DataOraModifica, " + 
				"StatoSessione " + 
				"FROM CV.Sessioni ";

			if (sqlWhere != null && sqlWhere.Length > 0)
				sql += "WHERE " + sqlWhere + " ";

			if (sqlOther != null && sqlOther.Length > 0)
				sql += sqlOther;


			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				da.SelectCommand = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						da.SelectCommand.Parameters.Add(p);

				DataSet ds = new DataSet();
				da.Fill(ds);
				return ds;
			}
		}
		*/

		protected OleDbDataAdapter GetDataAdapter()
		{
			return GetDataAdapter(null, (OleDbParameter [])null);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere)
		{
			OleDbParameter [] pars = new OleDbParameter [1];
			pars[0] = parWhere;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere1, OleDbParameter parWhere2)
		{
			OleDbParameter [] pars = new OleDbParameter [2];
			pars[0] = parWhere1;
			pars[1] = parWhere2;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				string sqlCmd = "SELECT " +
					"RAWTOHEX(IdSessione) AS IdSessione, " + 
					"Titolo, " +
					"DataOraApertura, " +
					"DataOraChiusura, " + 
					"PrezzoRiferimentoAnnoPrec10, " +
					"PrezzoRiferimentoAnnoPrec09, " +
					"PrezzoRiferimentoAnnoPrec08, " +
					"PrezzoRiferimentoAnnoPrec07, " +
					"PrezzoRiferimentoAnnoPrec06, " +
					"PrezzoRiferimentoAnnoPrec05, " +
					"PrezzoRiferimentoAnnoPrec04, " +
					"PrezzoRiferimentoAnnoPrec03, " +
					"PrezzoRiferimentoAnnoPrec02, " +
					"PrezzoRiferimentoAnnoPrec, " +
					"PrezzoRiferimentoAnnoCorr, " +
					"PrezzoRiferimentoAnnoSucc, " +
					"PrezzoRiferimentoAnnoSucc02, " +
					"PrezzoRiferimentoAnnoSucc03, " +
					"PrezzoRiferimentoAnnoSucc04, " +
					"PrezzoRiferimentoAnnoSucc05, " +
					"PrezzoRiferimentoAnnoSucc06, " +
					"PrezzoRiferimentoAnnoSucc07, " +
					"PrezzoRiferimentoAnnoSucc08, " +
					"PrezzoRiferimentoAnnoSucc09, " +
					"PrezzoRiferimentoAnnoSucc10, " + 
					"PrezzoConvenzionale, " + 
					"DataOraCreazione, " + 
					"DataOraModifica, " + 
					"StatoSessione " +
					"FROM CV.Sessioni ";

				if (sql != null && sql.Length > 0)
					sqlCmd += sql;

				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// insert
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText = "INSERT INTO CV.SESSIONI (" +
					"IdSessione, " +
					"Titolo, " +
					"DataOraApertura, " +
					"DataOraChiusura, " +
					"PrezzoRiferimentoAnnoPrec10, " +
					"PrezzoRiferimentoAnnoPrec09, " +
					"PrezzoRiferimentoAnnoPrec08, " +
					"PrezzoRiferimentoAnnoPrec07, " +
					"PrezzoRiferimentoAnnoPrec06, " +
					"PrezzoRiferimentoAnnoPrec05, " +
					"PrezzoRiferimentoAnnoPrec04, " +
					"PrezzoRiferimentoAnnoPrec03, " +
					"PrezzoRiferimentoAnnoPrec02, " +
					"PrezzoRiferimentoAnnoPrec, " +
					"PrezzoRiferimentoAnnoCorr, " +
					"PrezzoRiferimentoAnnoSucc, " +
					"PrezzoRiferimentoAnnoSucc02, " +
					"PrezzoRiferimentoAnnoSucc03, " +
					"PrezzoRiferimentoAnnoSucc04, " +
					"PrezzoRiferimentoAnnoSucc05, " +
					"PrezzoRiferimentoAnnoSucc06, " +
					"PrezzoRiferimentoAnnoSucc07, " +
					"PrezzoRiferimentoAnnoSucc08, " +
					"PrezzoRiferimentoAnnoSucc09, " +
					"PrezzoRiferimentoAnnoSucc10, " +
					"PrezzoConvenzionale, " +
					"DataOraCreazione, " +
					"DataOraModifica, " +
					"StatoSessione" +
					") VALUES (HEXTORAW(?), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

				cmd.Parameters.Add(new OleDbParameter("IdSessione",                OleDbType.VarChar,       32, "IdSessione"));
				cmd.Parameters.Add(new OleDbParameter("Titolo",                    OleDbType.VarChar,      255, "Titolo"));
				cmd.Parameters.Add(new OleDbParameter("DataOraApertura",           OleDbType.DBTimeStamp,    0, "DataOraApertura"));
				cmd.Parameters.Add(new OleDbParameter("DataOraChiusura",           OleDbType.DBTimeStamp,    0, "DataOraChiusura"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec10", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec10", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec09", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec09", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec08", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec08", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec07", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec07", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec06", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec06", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec05", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec05", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec04", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec04", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec03", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec03", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec02", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec02", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoPrec", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoCorr", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoCorr", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc02", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc02", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc03", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc03", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc04", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc04", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc05", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc05", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc06", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc06", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc07", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc07", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc08", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc08", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc09", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc09", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc10", OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoRiferimentoAnnoSucc10", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionale",       OleDbType.Decimal,        0, ParameterDirection.Input, false, ((System.Byte)(19)), ((System.Byte)(4)), "PrezzoConvenzionale", DataRowVersion.Current, null));
				cmd.Parameters.Add(new OleDbParameter("DataOraCreazione",          OleDbType.DBTimeStamp,    0, "DataOraCreazione"));
				cmd.Parameters.Add(new OleDbParameter("DataOraModifica",           OleDbType.DBTimeStamp,    0, "DataOraModifica"));
				cmd.Parameters.Add(new OleDbParameter("StatoSessione",             OleDbType.VarChar,      255, "StatoSessione"));

				da.InsertCommand = cmd;
			}
//			if (true)
//			{
//				OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Add", m_Transaction.Connection, m_Transaction);
//				cmd.CommandType = CommandType.StoredProcedure;
//
//				OleDbParameter p = new OleDbParameter("@Titolo", OleDbType.VarChar);
//				p.SourceColumn = "Titolo";
//				p.SourceVersion = DataRowVersion.Current;
//				cmd.Parameters.Add(p);
//
//				p = new OleDbParameter("@DataOraApertura", OleDbType.DBTimeStamp);
//				p.SourceColumn = "DataOraApertura";
//				p.SourceVersion = DataRowVersion.Current;
//				cmd.Parameters.Add(p);
//
//				p = new OleDbParameter("@DataOraChiusura", OleDbType.DBTimeStamp);
//				p.SourceColumn = "DataOraChiusura";
//				p.SourceVersion = DataRowVersion.Current;
//				cmd.Parameters.Add(p);
//
//				p = new OleDbParameter("@PrezzoConvenzionale", OleDbType.Currency);
//				p.SourceColumn = "PrezzoConvenzionale";
//				p.SourceVersion = DataRowVersion.Current;
//				cmd.Parameters.Add(p);
//		
//				p = new OleDbParameter("@PrezzoRifAnnoPrec", OleDbType.Currency);
//				p.SourceColumn = "PrezzoRiferimentoAnnoPrec";
//				p.SourceVersion = DataRowVersion.Current;
//				cmd.Parameters.Add(p);
//
//				p = new OleDbParameter("@PrezzoRifAnnoCorr", OleDbType.Currency);
//				p.SourceColumn = "PrezzoRiferimentoAnnoCorr";
//				p.SourceVersion = DataRowVersion.Current;
//				cmd.Parameters.Add(p);
//
//				p = new OleDbParameter("@PrezzoRifAnnoSucc", OleDbType.Currency);
//				p.SourceColumn = "PrezzoRiferimentoAnnoSucc";
//				p.SourceVersion = DataRowVersion.Current;
//				cmd.Parameters.Add(p);
//
//				p = new OleDbParameter("@IdSessione", OleDbType.VarChar, 32);
//				p.Direction = ParameterDirection.Output;
//				p.IsNullable = false;
//				p.SourceColumn = "IdSessione";
//				cmd.Parameters.Add(p);
//
//				da.InsertCommand = cmd;
//			}

			// update
			if (true)
			{
//				//OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Update", m_Transaction.Connection, m_Transaction);
//				//cmd.CommandType = CommandType.StoredProcedure;
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText = "UPDATE CV.SESSIONI SET " +
					"Titolo = ?, " + 
					"DataOraApertura = ?, " +
					"DataOraChiusura = ?, " +
					"PrezzoRiferimentoAnnoPrec10 = ?, " +
					"PrezzoRiferimentoAnnoPrec09 = ?, " +
					"PrezzoRiferimentoAnnoPrec08 = ?, " +
					"PrezzoRiferimentoAnnoPrec07 = ?, " +
					"PrezzoRiferimentoAnnoPrec06 = ?, " +
					"PrezzoRiferimentoAnnoPrec05 = ?, " +
					"PrezzoRiferimentoAnnoPrec04 = ?, " +
					"PrezzoRiferimentoAnnoPrec03 = ?, " +
					"PrezzoRiferimentoAnnoPrec02 = ?, " +
					"PrezzoRiferimentoAnnoPrec = ?, " +
					"PrezzoRiferimentoAnnoCorr = ?, " +
					"PrezzoRiferimentoAnnoSucc = ?, " +
					"PrezzoRiferimentoAnnoSucc02 = ?, " +
					"PrezzoRiferimentoAnnoSucc03 = ?, " +
					"PrezzoRiferimentoAnnoSucc04 = ?, " +
					"PrezzoRiferimentoAnnoSucc05 = ?, " +
					"PrezzoRiferimentoAnnoSucc06 = ?, " +
					"PrezzoRiferimentoAnnoSucc07 = ?, " +
					"PrezzoRiferimentoAnnoSucc08 = ?, " +
					"PrezzoRiferimentoAnnoSucc09 = ?, " +
					"PrezzoRiferimentoAnnoSucc10 = ?, " +
					"PrezzoConvenzionale = ?, " +
					"StatoSessione = ? " + 
					"WHERE IdSessione = HEXTORAW(?)";

				cmd.Parameters.Add(new OleDbParameter("Titolo",                    OleDbType.VarChar,     255, "Titolo"));
				cmd.Parameters.Add(new OleDbParameter("DataOraApertura",           OleDbType.DBTimeStamp,   0, "DataOraApertura"));
				cmd.Parameters.Add(new OleDbParameter("DataOraChiusura",           OleDbType.DBTimeStamp,   0, "DataOraChiusura"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec10",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec10"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec09",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec09"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec08",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec08"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec07",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec07"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec06",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec06"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec05",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec05"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec04",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec04"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec03",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec03"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec02",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec02"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoPrec", OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoPrec"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoCorr", OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoCorr"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc", OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc02",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc02"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc03",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc03"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc04",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc04"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc05",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc05"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc06",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc06"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc07",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc07"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc08",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc08"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc09",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc09"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoRiferimentoAnnoSucc10",OleDbType.Decimal,       0, "PrezzoRiferimentoAnnoSucc10"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionale",       OleDbType.Decimal,       0, "PrezzoConvenzionale"));
				cmd.Parameters.Add(new OleDbParameter("StatoSessione",             OleDbType.VarChar,     255, "StatoSessione"));
				cmd.Parameters.Add(new OleDbParameter("IdSessione",                OleDbType.VarChar,      32, "IdSessione"));


				//cmd.Parameters.Add(new OleDbParameter("DataOraCreazione",          OleDbType.DBTimeStamp,   0, "DataOraCreazione"));

				// se fosse fatta bene la stored procedure avremmo la data di modifica da aggiornare.
				//OleDbParameter p = new OleDbParameter("DataOraModifica",           OleDbType.DBTimeStamp,   0, "DataOraModifica");
				//p.Direction = ParameterDirection.Output;
				//cmd.Parameters.Add(p);


				da.UpdateCommand = cmd;
			}

			// delete
			if (true)
			{
				//OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Delete", m_Transaction.Connection, m_Transaction);
				//cmd.CommandType = CommandType.StoredProcedure;

//				OleDbParameter p = new OleDbParameter("@IdSessione", OleDbType.VarChar);
//				p.SourceColumn = "IdSessione";
//				p.SourceVersion = DataRowVersion.Original;
//				cmd.Parameters.Add(p);

				OleDbCommand cmd = new OleDbCommand("DELETE FROM CV.SESSIONI WHERE IdSessione = HEXTORAW(?)", m_Transaction.Connection, m_Transaction);
				cmd.CommandType = CommandType.Text;

				OleDbParameter p = new OleDbParameter("IdSessione", OleDbType.VarChar);
				p.SourceColumn = "IdSessione";
				p.SourceVersion = DataRowVersion.Original;
				cmd.Parameters.Add(p);

				da.DeleteCommand = cmd;
			}

			// Determines the action that occurs when a mapping is missing from a source table or a source column
			//da.MissingMappingAction = MissingMappingAction.Error; questo da' sempre errore
			//da.MissingMappingAction = MissingMappingAction.Ignore; questo non da' errore ma ritorna una lista vuota

			// Determines the action to take when existing DataSet schema does not match incoming data.
			da.MissingSchemaAction = MissingSchemaAction.Error;

			return da;
		}

		public static DataSet DataSet_Sessioni()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("Sessioni");

			DataColumn c;
			c = dt.Columns.Add("IdSessione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = true;

			c = dt.Columns.Add("Titolo", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;  // TODO LEO con true si pianta a causa di titoli uguali tipo aaa e AAA (constraints violato)
			c.DefaultValue = "Titolo";

			c = dt.Columns.Add("DataOraApertura", typeof(DateTime));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("DataOraChiusura", typeof(DateTime));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec10", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec09", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec08", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec07", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec06", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec05", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec04", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec03", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec02", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoPrec", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoCorr", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc02", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc03", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc04", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc05", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc06", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc07", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc08", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc09", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoRiferimentoAnnoSucc10", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoConvenzionale", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("DataOraCreazione", typeof(DateTime));
			c.AllowDBNull = false;
//			c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("DataOraModifica", typeof(DateTime));
			c.AllowDBNull = false;
//			c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("StatoSessione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("DataCorrispettivo", typeof(DateTime));
			c.AllowDBNull = true;

			dt.PrimaryKey = new DataColumn[] { dt.Columns["IdSessione"] };

			return ds;

		}
	}
}
