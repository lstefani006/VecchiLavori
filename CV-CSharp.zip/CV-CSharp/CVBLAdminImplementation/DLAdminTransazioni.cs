using System;
using System.Data;
using System.Data.OleDb;
using System.Text;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminTransazioni.
	/// </summary>
	internal class DLAdminTransazioni : DLAdminBase
	{
		public DLAdminTransazioni(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public DataSet Ricerca(string RagioneSociale, string IdSessione)
		{
			RagioneSociale += "%";
			
			string strSqlQuery =	"SELECT RAWTOHEX(T.IdTransazione) AS IdTransazione, " +
				"A.RagioneSociale AS Acquirente, " +
				"A.ABI AS AcquirentiABI, " +
				"A.CAB AS AcquirentiCAB, " +
				"A.CC AS AcquirentiCC, " +
				"A.AnnoRiferimento AS AnnoRiferimento, " +
				"RAWTOHEX(A.IdSocieta) AS IdSocietaAcq, " +
				"V.RagioneSociale AS Venditore, " +
				"V.ABI AS VenditoriABI, " +
				"V.CAB AS VenditoriCAB, " +
				"V.CC AS VenditoriCC, " +
				"A.CodiceConto AS CodiceContoAcquirente, " +
				"V.CodiceConto AS CodiceContoVenditore, " +
				"RAWTOHEX(T.IdOffertaAcquisto) AS IdOffertaAcquisto, " +
				"RAWTOHEX(T.IdOffertaVendita) AS IdOffertaVendita, " +
				"T.QtyCertificati AS QtyCertificati, " +
				"T.PrezzoUnitario AS PrezzoUnitario, " +
				//"(T.QtyCertificati *  T.PrezzoUnitario * 100 ) AS ControValore, " + // /*cento*/ TODO modificare 100 con la tabella dei MW
				"(T.QtyCertificati *  T.PrezzoUnitario * " + DLAdminBase.MWhPerCV.ToString()  + @" ) AS ControValore, " + //Stefano
				"T.DataOraOperazione AS DataOraOperazione, " +
				"T.StatoTransazione AS StatoTransazione, " +
				"BudgetsA.Importo AS ImportoA, " +
				"BudgetsV.Importo AS ImportoV, " +
				"BudgetsA.PrezzoConvenzionaleUtente AS PrezzoConvenzionaleUtenteA, " +
				"BudgetsV.PrezzoConvenzionaleUtente AS PrezzoConvenzionaleUtenteV, " +
				"BudgetsA.PrezzoConvenzionaleUtenteMw AS PConvenzionaleUtenteMwA, " +
				"BudgetsV.PrezzoConvenzionaleUtenteMw AS PConvenzionaleUtenteMwV, " +
				"UtentiA.Nominativo AS NominativoA, " +
				"UtentiV.Nominativo AS NominativoV  " +
				"FROM CV.Acquirenti A, CV.Venditori V, CV.Transazioni T, " +
				"     CV.Budgets BudgetsV, CV.Budgets BudgetsA, " +
				"     US.Utenti UtentiA, US.Utenti UtentiV " + 
				"WHERE	A.IdOffertaAcquisto = T.IdOffertaAcquisto " +
				"		AND V.IdOffertaVendita = T.IdOffertaVendita " +
				"		AND A.IdSocieta = BudgetsA.IdSocieta " +
				"		AND V.IdSocieta = BudgetsV.IdSocieta " +
				"		AND A.IdSessione = HEXTORAW(?) " +
				"		AND (A.RagioneSociale LIKE ? " +
				"       OR V.RagioneSociale LIKE ?) " +
				"		AND BudgetsV.IdSessione = HEXTORAW(?) " +
				"		AND BudgetsA.IdSessione = HEXTORAW(?) " +
				"       AND UtentiA.IdUtente = A.IdUtente " +
				"       AND UtentiV.IdUtente = V.IdUtente ";
			OleDbDataAdapter da = new OleDbDataAdapter(strSqlQuery, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("RagioneSociale", OleDbType.VarChar).Value = RagioneSociale;
			da.SelectCommand.Parameters.Add("RagioneSociale", OleDbType.VarChar).Value = RagioneSociale;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;

			DataSet ds = new DataSet();
			// Costruisco la Tabella che conterra' il risultato della Query
			DataTable dt = ds.Tables.Add("Transazioni");

			DataColumn pk = dt.Columns.Add("IdTransazione", typeof(string));
			pk.AllowDBNull = false;
			pk.MaxLength = 32;

			DataColumn c;
			c = dt.Columns.Add("Acquirente", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("AcquirentiABI", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("AcquirentiCAB", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("AcquirentiCC", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("AnnoRiferimento", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("IdSocietaAcq", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("Venditore", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("VenditoriABI", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("VenditoriCAB", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("VenditoriCC", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("CodiceContoAcquirente", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("CodiceContoVenditore", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("IdOffertaAcquisto", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("IdOffertaVendita", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("QtyCertificati", typeof(decimal));
			c.AllowDBNull = false;

			c = dt.Columns.Add("PrezzoUnitario", typeof(decimal));
			c.AllowDBNull = false;

			c = dt.Columns.Add("ControValore", typeof(decimal));
			c.AllowDBNull = false;

			c = dt.Columns.Add("DataOraOperazione", typeof(DateTime));
			c.AllowDBNull = false;

			c = dt.Columns.Add("StatoTransazione", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("ImportoA", typeof(decimal));
			c.AllowDBNull = false;
			
			c = dt.Columns.Add("ImportoV", typeof(decimal));
			c.AllowDBNull = false;

			c = dt.Columns.Add("PrezzoConvenzionaleUtenteA", typeof(decimal));
			c.AllowDBNull = false;

			c = dt.Columns.Add("PrezzoConvenzionaleUtenteV", typeof(decimal));
			c.AllowDBNull = false;

			c = dt.Columns.Add("PConvenzionaleUtenteMwA", typeof(decimal));
			c.AllowDBNull = false;

			c = dt.Columns.Add("PConvenzionaleUtenteMwV", typeof(decimal));
			c.AllowDBNull = false;

			c = dt.Columns.Add("FileExportBanca", typeof(string));
			c.AllowDBNull = true;

			c = dt.Columns.Add("Causale", typeof(string));
			c.AllowDBNull = true;

			c = dt.Columns.Add("PagabileDaGME", typeof(string));
			c.AllowDBNull = true;


			c = dt.Columns.Add("NominativoA", typeof(string));
			c.AllowDBNull = true;

			c = dt.Columns.Add("NominativoV", typeof(string));
			c.AllowDBNull = true;


			dt.PrimaryKey = new DataColumn [] { pk };

			da.Fill(ds, "Transazioni");
			return ds;
		}

		public void UpdateStatoTransazione(DataSet ds)
		{
			string sql = "UPDATE cv.Transazioni SET " + 
						 "StatoTransazione = ?, " + 
						 "PagabileDaGME = ?, " + 
						 "FileExportBanca = ?, " + 
						 "Causale = ? " + 
						 "WHERE IdTransazione = HEXTORAW(?)";
		
			OleDbDataAdapter da = new OleDbDataAdapter();
			OleDbCommand cmd = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
		
			cmd.Parameters.Add(new OleDbParameter("StatoTransazione",	OleDbType.VarChar,	   255, "StatoTransazione"));
			cmd.Parameters.Add(new OleDbParameter("PagabileDaGME",		OleDbType.Char,			 2, "PagabileDaGME"));
			cmd.Parameters.Add(new OleDbParameter("FileExportBanca",	OleDbType.VarChar,	   255, "FileExportBanca"));
			cmd.Parameters.Add(new OleDbParameter("Causale",			OleDbType.VarChar,     255, "Causale"));
			cmd.Parameters.Add(new OleDbParameter("Original_IDTRANSAZIONE", OleDbType.VarChar, 32, ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IDTRANSAZIONE", DataRowVersion.Original, null));

			da.UpdateCommand = cmd;
			da.Update(ds, "Transazioni");
		}

		public DataSet RicercaRecordDaEsportareFileXml(string IdSessione)
		{	
			string sql =
				"SELECT " +
				"RAWTOHEX(TRANSAZIONI.IDTRANSAZIONE)                             As IdTransazione, " +
				"TRANSAZIONI.DATAORAOPERAZIONE                                   As DataOraTransazione, " +
				//"(TRANSAZIONI.QTYCERTIFICATI * TRANSAZIONI.PREZZOUNITARIO * 100) AS ImportoTransazione, " + //Stefano TODO modificare con tabella MW 
				"(TRANSAZIONI.QTYCERTIFICATI * TRANSAZIONI.PREZZOUNITARIO * " + DLAdminBase.MWhPerCV.ToString() + @") AS ImportoTransazione, " + //Stefano
				"SOCIETA_ACQUIRENTE.CODICECONTO                                  As Acquirente_CC, " +
				"SOCIETA_VENDITORE.ABI                                           As Venditore_ABI, " +
				"SOCIETA_VENDITORE.CAB                                           As Venditore_CAB, " +
				"SOCIETA_VENDITORE.CC                                            As Venditore_CC " +
				"FROM " +
				"cv.TRANSAZIONI, " +
				"cv.OFFERTEACQUISTO, " +
				"cv.OFFERTEVENDITA, " +
				"US.UTENTI UTENTE_ACQUIRENTE, " +
				"US.UTENTI UTENTE_VENDITORE, " +
				"US.SOCIETA SOCIETA_ACQUIRENTE, " +
				"US.SOCIETA SOCIETA_VENDITORE " +
				"WHERE " +
				"     (OFFERTEACQUISTO.IDSESSIONE    = HEXTORAW(?))" +
				" AND (OFFERTEACQUISTO.IDSESSIONE    = OFFERTEVENDITA.IDSESSIONE)" +
				" AND (TRANSAZIONI.IDOFFERTAACQUISTO = OFFERTEACQUISTO.IDOFFERTAACQUISTO)" +
				" AND (TRANSAZIONI.IDOFFERTAVENDITA  = OFFERTEVENDITA.IDOFFERTAVENDITA)" +
				" AND (OFFERTEACQUISTO.IDUTENTE      = UTENTE_ACQUIRENTE.IDUTENTE)" +
				" AND (OFFERTEVENDITA.IDUTENTE       = UTENTE_VENDITORE.IDUTENTE)" +
				" AND (UTENTE_VENDITORE.IDSOCIETA    = SOCIETA_VENDITORE.IDSOCIETA)" +
				" AND (UTENTE_ACQUIRENTE.IDSOCIETA   = SOCIETA_ACQUIRENTE.IDSOCIETA)" +
				" AND (TRANSAZIONI.STATOTRANSAZIONE  = 'Valida')" +
				" AND (TRANSAZIONI.PAGABILEDAGME     = 'SI')" +
				" AND (TRANSAZIONI.FILEEXPORTBANCA IS NULL) " +
				"ORDER BY " +
//				"UTENTE_ACQUIRENTE.IDUTENTE, " +
//				"UTENTE_VENDITORE.IDUTENTE, " +
				"UTENTE_ACQUIRENTE.IDSOCIETA, " +
				"UTENTE_VENDITORE.IDSOCIETA, " +
				"TRANSAZIONI.DATAORAOPERAZIONE ";

			OleDbDataAdapter da = new OleDbDataAdapter(sql, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;

			DataSet ds = new DataSet();
			DataTable dt = ds.Tables.Add("TransazioniDaEsportare");

			DataColumn pk = dt.Columns.Add("IdTransazione", typeof(string));
			pk.AllowDBNull = false;
			pk.MaxLength = 32;

			DataColumn c;
			c = dt.Columns.Add("DataOraTransazione", typeof(DateTime));
			c.AllowDBNull = false;

			c = dt.Columns.Add("ImportoTransazione", typeof(decimal));
			c.AllowDBNull = false;
			
			c = dt.Columns.Add("Acquirente_CC", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("Venditore_ABI", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("Venditore_CAB", typeof(string));
			c.AllowDBNull = false;

			c = dt.Columns.Add("Venditore_CC", typeof(string));
			c.AllowDBNull = false;

			dt.PrimaryKey = new DataColumn [] { pk };
			da.Fill(ds, "TransazioniDaEsportare");
			return ds;
		}

		public void AssociaFileEtCausale(string IdTransazione, string NomeFileXml, string Causale)
		{
			using(OleDbCommand cmd = new OleDbCommand(
					  "UPDATE cv.Transazioni SET FileExportBanca=?, Causale=? WHERE IdTransazione=HEXTORAW(?)",
					  m_Transaction.Connection,
					  m_Transaction))
			{
				cmd.Parameters.Add("FileExportBanca", OleDbType.VarChar).Value = NomeFileXml;
				cmd.Parameters.Add("Causale", OleDbType.VarChar).Value = Causale;
				cmd.Parameters.Add("IdTransazione", OleDbType.VarChar).Value = IdTransazione;

				cmd.ExecuteNonQuery();
			}
		}


		public DataSet ListaOperazioniAcquistoPerAnno(DataSet ds, string IdSessione, string IdSocietaAcquirente)
		{
			string q;
			q = "SELECT AnnoRiferimento, RAWTOHEX(IDSessione) AS IdSessione, QTot, PMedioA, CTVCoperto, CTVNonCoperto, " +
				" CTVTot, RagioneSocialeAcquirente, RAWTOHEX(IDSocietaAcquirente) AS IdSocietaAcquirente " +
				" FROM  cv.RiepilogoOpAcquistoPerAnno " + 
				" WHERE IDSessione = HEXTORAW(?) " +
				" AND IdSocietaAcquirente = HEXTORAW(?) " +
				" ORDER BY AnnoRiferimento";

			OleDbDataAdapter da = new OleDbDataAdapter(q, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSocieta",  OleDbType.VarChar).Value = IdSocietaAcquirente;

			if (ds == null)
				ds = new DataSet();

			if (ds.Tables.Contains("OperazioniAcquistoPerAnno") == false)
			{
				DataTable dt = ds.Tables.Add("OperazioniAcquistoPerAnno");

				dt.Columns.Add("AnnoRiferimento", typeof(string));
				dt.Columns.Add("IdSessione", typeof(string));
				dt.Columns.Add("QTot", typeof(decimal));
				dt.Columns.Add("PMedioA", typeof(decimal));
				dt.Columns.Add("CTVCoperto", typeof(decimal));
				dt.Columns.Add("CTVNonCoperto", typeof(decimal));
				dt.Columns.Add("CTVTot", typeof(decimal));
				dt.Columns.Add("RagioneSocialeAcquirente", typeof(string));
				dt.Columns.Add("IdSocietaAcquirente", typeof(string));
			}

			da.Fill(ds, "OperazioniAcquistoPerAnno");

			return ds;
		}

		public DataSet ListaOperazioniAcquistoPerVenditore(DataSet ds, string IdSessione, string IdSocietaAcquirente)
		{
			string q = 
				"SELECT RagioneSocialeVenditore, CTVDaPagare, RAWTOHEX(IDSessione) AS IdSessione, " +
				" RAWTOHEX(IDSocietaAcquirente) AS IdSocietaAcquirente " +
				" FROM cv.RiepilogoOpAcquistoPerVend " +						// STE_PROBLEMA_VIEW
				" WHERE IdSessione = HEXTORAW(?) " +
				" AND IdSocietaAcquirente = HEXTORAW(?) " +
				" AND CtvDaPagare <> 0 " +
				" ORDER BY RagioneSocialeVenditore";

			OleDbDataAdapter da = new OleDbDataAdapter(q, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSocieta",  OleDbType.VarChar).Value = IdSocietaAcquirente;

			if (ds == null)
				ds = new DataSet();

			if (ds.Tables.Contains("OperazioniAcquistoPerVenditore") == false)
			{
				DataTable dt = ds.Tables.Add("OperazioniAcquistoPerVenditore");

				dt.Columns.Add("RagioneSocialeVenditore", typeof(string));
				dt.Columns.Add("CTVDaPagare", typeof(decimal));
				dt.Columns.Add("IdSessione", typeof(string));
				dt.Columns.Add("IdSocietaAcquirente", typeof(string));
			}


			da.Fill(ds, "OperazioniAcquistoPerVenditore");

//#if DEBUG
//			if (ds.Tables[0].Rows.Count == 0)
//			{
//				DataTable dt = ds.Tables[0];
//				dt.Rows.Add(new object [] {"RagioneSocialeVenditore", 12222m, "IdSessione", "IdSocietaAcquirente"});
//			}
//#endif
			return ds;
		}

		public DataSet ListaOperazioniVenditaPerAnno(DataSet ds, string IdSessione, string IdSocietaVenditore)
		{
			string q;
			q = "SELECT AnnoRiferimento, RAWTOHEX(IDSessione) AS IdSessione, QTot, PMedioV, CTVCoperto, " +
				"CTVNonCoperto, CTVTot, RAWTOHEX(IDSocietaVenditore) AS IdSocietaVenditore " +
				"FROM cv.RiepilogoOpVenditaPerAnno " +					// STE_PROBLEMA_VIEW
				"WHERE IdSessione = HEXTORAW(?) " +
				"AND IdSocietaVenditore = HEXTORAW(?) " +
				"ORDER BY AnnoRiferimento";

			OleDbDataAdapter da = new OleDbDataAdapter(q, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSocieta",  OleDbType.VarChar).Value = IdSocietaVenditore;

			if (ds == null)
				ds = new DataSet();

			if (ds.Tables.Contains("OperazioniVenditaPerAnno") == false)
			{
				DataTable dt = ds.Tables.Add("OperazioniVenditaPerAnno");

				dt.Columns.Add("AnnoRiferimento", typeof(string));
				dt.Columns.Add("IdSessione", typeof(string));
				dt.Columns.Add("QTot", typeof(decimal));
				dt.Columns.Add("PMedioV", typeof(decimal));
				dt.Columns.Add("CTVCoperto", typeof(decimal));
				dt.Columns.Add("CTVNonCoperto", typeof(decimal));
				dt.Columns.Add("CTVTot", typeof(decimal));
				dt.Columns.Add("IdSocietaVenditore", typeof(string));
			}
			da.Fill(ds, "OperazioniVenditaPerAnno");

//#if DEBUG
//			if (ds.Tables[0].Rows.Count == 0)
//			{
//				DataTable dt = ds.Tables[0];
//				dt.Rows.Add(new object [] {"1999", "IdSessione", 12345.67m, 3231.33m, 1233.44m, 231231.444m, 222m, "IdSocietaVenditore"});
//			}
//#endif

			return ds;
		}
		public DataSet ListaOperazioniVenditaPerAcquirente(DataSet ds, string IdSessione, string IdSocietaVenditore)
		{
			string q;
			q = "SELECT RagioneSocialeAcquirente, CTVDaRicevere, RAWTOHEX(IDSessione) AS IdSessione, " +
				"RAWTOHEX(IDSocietaVenditore) AS IdSocietaVenditore " +
				"FROM cv.RiepilogoOpVenditaPerAcq " +						// STE_PROBLEMA_VIEW
				"WHERE IdSessione = HEXTORAW(?) " +
				"AND IdSocietaVenditore = HEXTORAW(?) " +
				"AND CtvDaRicevere <> 0 " +
				"ORDER BY RagioneSocialeAcquirente";

			OleDbDataAdapter da = new OleDbDataAdapter(q, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSocieta",  OleDbType.VarChar).Value = IdSocietaVenditore;

			if (ds == null)
				ds = new DataSet();

			if (ds.Tables.Contains("OperazioniVenditaPerAcquirente") == false)
			{
				DataTable dt = ds.Tables.Add("OperazioniVenditaPerAcquirente");

				dt.Columns.Add("RagioneSocialeAcquirente", typeof(string));
				dt.Columns.Add("CTVDaRicevere", typeof(decimal));
				dt.Columns.Add("IdSessione", typeof(string));
				dt.Columns.Add("IdSocietaVenditore", typeof(string));
			}
			da.Fill(ds, "OperazioniVenditaPerAcquirente");

//#if DEBUG
//			if (ds.Tables[0].Rows.Count == 0)
//			{
//				DataTable dt = ds.Tables[0];
//				dt.Rows.Add(new object [] {"RagioneSocialeAcquirente", 12345m, "IdSessione" ,"IdSocietaVenditore"});
//			}
//#endif
			return ds;
		}


		public DataSet DettagliAcquisti(DataSet ds, string IdSessione, string IdSocietaAcquirente)
		{
			string q;
			q = "SELECT RAWTOHEX(IDTransazione) AS IdTransazione, RAWTOHEX(IDOffertaAcquisto) AS IdOffertaAcquisto, " +
				"DataOraOperazione, AnnoRiferimento, QtyEseguita, PrezzoEseguito, RagioneSocialeVenditore, " +
				"CTV, ABI, CAB, CC, StatoTransazione, RAWTOHEX(IDSessione) AS IdSessione, " +
				"RagioneSocialeAcquirente, CTVDeposito, CTVNonDeposito, RAWTOHEX(IDSocietaAcquirente) AS " +
				"IDSocietaAcquirente " +
				"FROM cv.DettagliTransazioniAcq " +						// STE_PROBLEMA_VIEW
				"WHERE IdSessione = HEXTORAW(?) " +
				"AND IdSocietaAcquirente = HEXTORAW(?) " +
				"ORDER BY RagioneSocialeVenditore ";

			OleDbDataAdapter da = new OleDbDataAdapter(q, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSocieta",  OleDbType.VarChar).Value = IdSocietaAcquirente;

			if (ds == null)
				ds = new DataSet();

			if (ds.Tables.Contains("DettagliAcquisti") == false)
			{
				DataTable dt = ds.Tables.Add("DettagliAcquisti");

				dt.Columns.Add("IdTransazione", typeof(string));
				dt.Columns.Add("IdOffertaAcquisto", typeof(string));
				dt.Columns.Add("DataOraOperazione", typeof(DateTime));
				dt.Columns.Add("AnnoRiferimento", typeof(string));
				dt.Columns.Add("QtyEseguita", typeof(decimal));
				dt.Columns.Add("PrezzoEseguito", typeof(decimal));
				dt.Columns.Add("RagioneSocialeVenditore", typeof(string));
				dt.Columns.Add("CTV", typeof(decimal));
				dt.Columns.Add("ABI", typeof(string));
				dt.Columns.Add("CAB", typeof(string));
				dt.Columns.Add("CC", typeof(string));
				dt.Columns.Add("StatoTransazione", typeof(string));
				dt.Columns.Add("IdSessione", typeof(string));
				dt.Columns.Add("RagioneSocialeAcquirente", typeof(string));
				dt.Columns.Add("CTVDeposito", typeof(decimal));
				dt.Columns.Add("CTVNonDeposito", typeof(decimal));
				dt.Columns.Add("IdSocietaAcquirente", typeof(string));
			}
			da.Fill(ds, "DettagliAcquisti");

//#if DEBUG
//			if (ds.Tables[0].Rows.Count == 0)
//			{
//				DataTable dt = ds.Tables[0];
//				dt.Rows.Add(new object [] {
//					"IdTransazione", "IdOffertaAcquisto", DateTime.Now, 
//				/*cento*/	"1999", 100m, 1000m, "RagioneSocialeVenditore", 10000m, "ABI", "CAB", "CC", "StatoTransazione",
//					"IdSessione", "RagioneSocialeAcquirente", 2000m, 1000m, "IdSocietaAcquirente"});
//			}
//#endif

			return ds;
		}
		public DataSet DettagliVendite(DataSet ds, string IdSessione, string IdSocietaVenditore)
		{
			string q; 
			q = "SELECT RAWTOHEX(IDTransazione) AS IdTransazione, RAWTOHEX(IdOffertaVendita) AS IdOffertaVendita, " + 
				"DataOraOperazione, AnnoRiferimento, QtyEseguita, PrezzoEseguito, CTV, " +
				"CTVDeposito, CTVNonDeposito, RagioneSocialeAcquirente, " +
				"RAWTOHEX(IDSocietaVenditore) AS IdSocietaVenditore, " +
				"RAWTOHEX(IDSessione) AS IdSessione, StatoTransazione, " +
				"RagioneSocialeVenditore, PartitaIVAAcquirente " +
				"FROM cv.DettagliTransazioniVenditore " +							// STE_PROBLEMA_VIEW
				"WHERE IDSessione = HEXTORAW(?) " +
				"AND IdSocietaVenditore = HEXTORAW(?) " +
				"ORDER BY RagioneSocialeAcquirente";

			OleDbDataAdapter da = new OleDbDataAdapter(q, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSocieta",  OleDbType.VarChar).Value = IdSocietaVenditore;

			if (ds == null)
				ds = new DataSet();

			if (ds.Tables.Contains("DettagliVendite") == false)
			{
				DataTable dt = ds.Tables.Add("DettagliVendite");

				dt.Columns.Add("IdTransazione", typeof(string));
				dt.Columns.Add("IdOffertaVendita", typeof(string));
				dt.Columns.Add("DataOraOperazione", typeof(DateTime));
				dt.Columns.Add("AnnoRiferimento", typeof(string));
				dt.Columns.Add("QtyEseguita", typeof(decimal));
				dt.Columns.Add("PrezzoEseguito", typeof(decimal));
				dt.Columns.Add("CTV", typeof(decimal));
				dt.Columns.Add("CTVDeposito", typeof(decimal));
				dt.Columns.Add("CTVNonDeposito", typeof(decimal));
				dt.Columns.Add("RagioneSocialeAcquirente", typeof(string));
				dt.Columns.Add("IdSocietaVenditore", typeof(string));
				dt.Columns.Add("IdSessione", typeof(string));
				dt.Columns.Add("StatoTransazione", typeof(string));
				dt.Columns.Add("RagioneSocialeVenditore", typeof(string));
			}
			da.Fill(ds, "DettagliVendite");


//#if DEBUG
//			if (ds.Tables[0].Rows.Count == 0)
//			{
//				DataTable dt = ds.Tables[0];
//				dt.Rows.Add(new object [] 
//				{
//					"IdTransazione", "IdOffertaVendita", DateTime.Now,
//					"1999", 123m, 324.43m, 123456.55m, 234m, 3232m, "RagioneSocialeAcquirente",
//					"IdSocietaVenditore", "IdSessione", "StatoTransazione", "RagioneSocialeVenditore"});
//			}
//#endif
			return ds;
		}


		public DataSet RetrievePagamenti(string IdSessione)
		{
			string s =
				"SELECT RagioneSocialeAcquirente, RagioneSocialeVenditore, ABI, CAB, CC, " + 
				"       SUM(AmmDaPag)   AS TotAmmDaPag,   " +
				"       SUM(PagGMESosp) AS TotPagGMESosp, " +
				"       SUM(PagOper)    AS TotPagOper     " +
				"FROM   (SELECT SUM(CtvDeposito) AS AmmDaPag, 0 AS PagGMESosp, 0 AS PagOper, RagioneSocialeVenditore, " +
				"               RagioneSocialeAcquirente, ABI, CAB, CC " +
				"        FROM   cv.DettagliTransazioniAcq " +				// STE_PROBLEMA_VIEW
				"        WHERE  (IdSessione = HEXTORAW(?) ) " +
				"               AND (CtvNonDeposito = 0) " +
				"        GROUP BY RagioneSocialeAcquirente, RagioneSocialeVenditore, ABI, CAB, CC " +
				"        UNION " +
				"        SELECT 0 AS AmmDaPag, SUM(CtvDeposito) AS PagGMESosp, 0 AS PagOper, RagioneSocialeVenditore, " +
				"               RagioneSocialeAcquirente, ABI, CAB, CC " +
				"        FROM  cv.DettagliTransazioniAcq " +					// STE_PROBLEMA_VIEW
				"        WHERE (IdSessione = HEXTORAW(?) ) " +
				"              AND (CtvNonDeposito <> 0) " +
				"        GROUP BY RagioneSocialeAcquirente, RagioneSocialeVenditore, ABI, CAB, CC " +
				"        UNION " +
				"        SELECT 0 AS AmmDaPag, 0 AS PagGMESosp, SUM(CtvNonDeposito) AS PagOper, RagioneSocialeVenditore, " +
				"               RagioneSocialeAcquirente, ABI, CAB, CC " +
				"        FROM cv.DettagliTransazioniAcq " +					// STE_PROBLEMA_VIEW
				"        WHERE (IdSessione = HEXTORAW(?) ) " +
				"              AND (CtvNonDeposito <> 0) " +
				"        GROUP BY RagioneSocialeAcquirente, RagioneSocialeVenditore, ABI, CAB, CC " +
				"        ) " +
				"GROUP BY RagioneSocialeAcquirente, RagioneSocialeVenditore, ABI, CAB, CC " +
				"ORDER BY RagioneSocialeAcquirente DESC";


			OleDbDataAdapter da = new OleDbDataAdapter();
			da.SelectCommand = new OleDbCommand(s, m_Transaction.Connection, m_Transaction);
			da.SelectCommand.Parameters.Add("IdSessione1", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSessione2", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSessione3", OleDbType.VarChar).Value = IdSessione;

			DataSet ds = new DataSet();
			if (ds.Tables.Contains("Pagamenti") == false)
			{
				DataTable dt = ds.Tables.Add("Pagamenti");
				dt.Columns.Add("RagioneSocialeAcquirente", typeof(string));
				dt.Columns.Add("RagioneSocialeVenditore",  typeof(string));
				dt.Columns.Add("ABI",                      typeof(string));
				dt.Columns.Add("CAB",                      typeof(string));
				dt.Columns.Add("CC",                       typeof(string));
				dt.Columns.Add("TotAmmDaPag",              typeof(decimal));
				dt.Columns.Add("TotPagGMESosp",            typeof(decimal));
				dt.Columns.Add("TotPagOper",               typeof(decimal));
			}

			da.Fill(ds, "Pagamenti");


//#if DEBUG
//			if (ds.Tables[0].Rows.Count == 0)
//			{
//				DataTable dt = ds.Tables[0];
//				dt.Rows.Add(new object [] {"RagioneSocialeAcquirente", "RagioneSocialeAcquirente","ABI","CAB","CC",1000.33m, 2000.33m, 3000.44m });
//				dt.Rows.Add(new object [] {"RagioneSocialeAcquirente", "RagioneSocialeAcquirente","ABI","CAB","CC",1000.33m, 2000.33m, 3000.44m });
//				dt.Rows.Add(new object [] {"RagioneSocialeAcquirente2","RagioneSocialeAcquirente","ABI","CAB","CC",1000.33m, 2000.33m, 3000.44m });
//			}
//#endif

			return ds;
		}

	}
}