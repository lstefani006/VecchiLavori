using System;
using System.Data;
using System.Diagnostics;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for BLAdminLogOfferte.
	/// </summary>
	public class BLAdminLogOfferte : CVRemotingBase, IBLAdminLogOfferte
	{
		public BLAdminLogOfferte()
		{
		}

		public DataSet RetrieveAcquisto(string IdSessione, string RagioneSociale, string Anno, string CodiceConto)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminLogOfferte dl = new DLAdminLogOfferte(tr);
					DataSet ds = dl.RetrieveAcquisto(IdSessione, RagioneSociale, Anno, CodiceConto);
					tr.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
		public DataSet RetrieveVendita (string IdSessione, string RagioneSociale, string Anno, string CodiceConto)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminLogOfferte dl = new DLAdminLogOfferte(tr);
					DataSet ds = dl.RetrieveVendita(IdSessione, RagioneSociale, Anno, CodiceConto);
					tr.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
	}
}
