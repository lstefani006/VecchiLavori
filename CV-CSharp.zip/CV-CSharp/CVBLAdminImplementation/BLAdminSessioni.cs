using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for BLAdminSessioni.
	/// </summary>
	public class BLAdminSessioni : CVRemotingBase, IBLAdminSessioni
	{
		public BLAdminSessioni()
		{
		}

		public DataSet GetLst()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLAdminSessioni dl = new DLAdminSessioni(dbTran);
					DataSet ds = dl.GetLista();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetListaFiltrata()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLAdminSessioni dl = new DLAdminSessioni(dbTran);
					DataSet ds = dl.GetListaFiltrata();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public ReportSessioni VerifyStatus()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLAdminSessioni dl = new DLAdminSessioni(dbTran);
					ReportSessioni rs = dl.VerifyStatus();
					dbTran.Commit();
					return rs;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet CalcolaCorrispettivi(string[] IdSessioni)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLAdminSessioni dl = new DLAdminSessioni(dbTran);
					DataSet ds = dl.CalcolaCorrispettivi(IdSessioni);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
	}
}
