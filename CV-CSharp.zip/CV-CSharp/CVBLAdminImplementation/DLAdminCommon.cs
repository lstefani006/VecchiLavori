using System;
using System.Data;
using System.Text;
using System.IO;
using System.Data.OleDb;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminCommon.
	/// </summary>
	internal class DLAdminCommon
	{
		public DLAdminCommon()
		{
		}
		private static string GetConnectionString()
		{
			string strConnectionString = System.Configuration.ConfigurationSettings.AppSettings["ConnectionStringAdmin"];
			return strConnectionString;

		}
		static public IDbConnection GetDBConnection()
		{
			string strConnectionString = GetConnectionString();
			return new OleDbConnection(strConnectionString);
		}

		static public DateTime GetDBSystemDate(IDbTransaction dbTran)
		{
			string strDateQry = "SELECT SYSDATE FROM DUAL";
			using (OleDbCommand cmd = new OleDbCommand(strDateQry, (OleDbConnection)dbTran.Connection, (OleDbTransaction)dbTran))
			{
				return (DateTime)cmd.ExecuteScalar();
			}
		}


		/// <summary>
		/// ritorna un nuovo uid in formato stringa di 32 char esadecimale
		/// </summary>
		/// <param name="cn"></param>
		/// <returns></returns>
		static public string NewId(IDbConnection cn, IDbTransaction tr)
		{
//			string strDateQry = "SELECT RAWTOHEX(SYS_GUID()) FROM DUAL";
//			using (OleDbCommand cmd = new OleDbCommand(strDateQry, (OleDbConnection)cn, (OleDbTransaction)tr))
//			{
//				return (string)cmd.ExecuteScalar();
//			}

			Guid g = Guid.NewGuid();
			return g.ToString("N").ToUpper();
		}

		static public bool ContrattaCVAnnoPrecedente(int Month)
		{
			string s = System.Configuration.ConfigurationSettings.AppSettings["ContrattaCVAnnoMin.Range"];
			if (s == null)
				return Month >= 1 && Month <= 10;

			string []a = s.Split(' ', ',', ':', '-');
			if (a.Length < 2)
				return Month >= 1 && Month <= 10;

			int inizio = int.Parse(a[0]);
			int fine   = int.Parse(a[1]);

			return Month >= inizio && Month <= fine;
		}


//		/// <summary>
//		/// ritorna un nuovo id in formato byte[16]
//		/// </summary>
//		/// <param name="cn"></param>
//		/// <returns></returns>
//		static public byte[] NewRawId(IDbConnection cn)
//		{
//			string strDateQry = "SELECT SYS_GUID() FROM DUAL";
//			using (OleDbCommand cmd = new OleDbCommand(strDateQry, (OleDbConnection)cn))
//			{
//				return (byte[])cmd.ExecuteScalar();
//			}
//		}

	}
}
