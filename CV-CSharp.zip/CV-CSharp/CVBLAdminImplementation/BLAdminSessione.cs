using System;
using System.Data;
using System.Diagnostics;

namespace CV.Admin
{
	/*
	public class RowException : Exception
	{
		public RowException(string m)
			: base(m)
		{
		}
	}
	*/
	/// <summary>
	/// Summary description for BLAdminSessione.
	/// </summary>
	public class BLAdminSessione : CVRemotingBase, IBLAdminSessione
	{
		public BLAdminSessione()
		{
		}

		public bool ContrattaCVAnnoMin(int Month, out int AnnoMin, out int AnnoMax)
		{
			return DLAdminSessione.ContrattaCVAnnoMin(Month, out AnnoMin, out AnnoMax);
		}

		public DataSet GetBookAcquisto(IDbTransaction tr, string IdSessione, string AnnoRiferimento)
		{
			DLAdminSessione dl = new DLAdminSessione(tr);
			return dl.GetBookAcquisto(IdSessione, AnnoRiferimento);
		}
		public DataSet GetBookAcquisto(string IdSessione, string AnnoRiferimento)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DataSet ds = this.GetBookAcquisto(tr, IdSessione, AnnoRiferimento);
					tr.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}

		// //////////////////////////////////////////////////////////////////////////
		public DataSet GetBookVendita(IDbTransaction tr, string IdSessione, string AnnoRiferimento)
		{
			DLAdminSessione dl = new DLAdminSessione(tr);
			return dl.GetBookVendita(IdSessione, AnnoRiferimento);
		}
		public DataSet GetBookVendita(string IdSessione, string AnnoRiferimento)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.GetBookVendita(dbTran, IdSessione, AnnoRiferimento);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		// ///////////////////////////////////////////////////////////////
		public DataSet GetCurrentWebSession(IDbTransaction tr)
		{
			DLAdminSessione dl = new DLAdminSessione(tr);
			return dl.GetCurrentWebSession();
		}
		public DataSet GetCurrentWebSession()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.GetCurrentWebSession(dbTran);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		// ///////////////////////////////////////////////////////////////
		public bool	IsEnabled(IDbTransaction tr,  string IdSessione)
		{
			DLAdminSessione dl = new DLAdminSessione(tr);
			return dl.IsEnabled(IdSessione);
		}
		public bool	IsEnabled(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					bool isSessionEnabled = this.IsEnabled(dbTran, IdSessione);
					dbTran.Commit();
					return isSessionEnabled;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		// ///////////////////////////////////////////////////////////////
		public DataSet Retrieve(IDbTransaction tr, string IdSessione, string Titolo, string StatoSessione)
		{
			DLAdminSessione dl = new DLAdminSessione(tr);

			DataSet ds;
			if (IdSessione == "")
				ds = dl.Retrieve(Titolo, StatoSessione);
			else
				ds = dl.RetrieveByIdSessione(IdSessione);

			return ds;
		}

		public DataSet Retrieve(string IdSessione, string Titolo, string StatoSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.Retrieve(dbTran, IdSessione, Titolo, StatoSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		// ///////////////////////////////////////////////////////////////
		public DataSet RetrieveActive(IDbTransaction tr, string IdSessione)
		{
			DLAdminSessione dl = new DLAdminSessione(tr);
			return dl.RetrieveActive(IdSessione);
		}
		public DataSet RetrieveActive(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.RetrieveActive(dbTran, IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		// ///////////////////////////////////////////////////////////////
		public DataSet ClearGrid()
		{
			return new DataSet();
		}



		// ///////////////////////////////////////////////////////////////
		public string IsPossibleToSetTo(IDbTransaction tr, string IdSessione, string StatoProposta)
		{
			DLAdminSessione dlSessione = new DLAdminSessione(tr);

			DataSet ds = dlSessione.RetrieveByIdSessione(IdSessione);
			if (ds.Tables["Sessioni"].Rows.Count != 1)
				return "Sessione non trovata";

			DataRow sessione = null;
			foreach (DataRow r in ds.Tables["Sessioni"].Rows)
			{
				if ((string)r["StatoSessione"] == StatoProposta)
					return null;

				sessione = r;
				break;
			}


			BLAdminCommon cmn = new BLAdminCommon();
			DateTime adesso = cmn.GetDBSystemDate(tr); 



			DLAdminSessioni dlSessioni = new DLAdminSessioni(tr);
			ReportSessioni rp = dlSessioni.VerifyStatus();

			switch ((string)sessione["StatoSessione"])
			{
				case "In Attesa":
				{
					switch (StatoProposta)
					{
						case "Predisposta":
							if (rp.NumPredisposte == 0)
								return null;
							else
								return "Impossibile effettuare l'import del file XML in quanto\nesiste gi� una sessione in stato Predisposta.";
						default:
							return "Una sessione in attesa pu� modificare il suo stato solo nel momento in cui viene effettuato l'import del file XML.";
					}
				}

				case "Predisposta":
				{
					switch (StatoProposta)
					{
						case "In Attesa":
							return null;

						case "Aperta":
							if (rp.NumAperte == 0 && rp.NumSospese == 0 && rp.NumTerminate == 0)
							{
								BLAdminBudget blBudget = new BLAdminBudget();
								DataSet dsBudget = blBudget.Retrieve(String.Empty, IdSessione);
								DataTable dtBudget = dsBudget.Tables["Budgets"];
								if (dtBudget.Rows.Count == 0)
									return "Aprire prima la maschera dei budgets!";

								DataRow drBudget = dtBudget.Rows[0];
								if (drBudget.IsNull("SaldoSessionePrecedente"))
									return "Aprire prima la maschera dei budgets!";

								return null;
							}
							else
								return "Impossibile modificare la sessione in quanto\nne esiste gi� una in stato o Aperta o Sospesa o Terminata.";

						default:
							return "Una sessione Predisposta pu� passare solo in uno stato di Aperta.";
					}
				}

				case "Aperta":
				{
					switch (StatoProposta)
					{
						case "Sospesa":
							return null;

						case "Terminata":
							if (adesso < (DateTime)sessione["DataOraChiusura"])
								return "Impossibile terminare la sessione in quanto la data attuale � ancora minore a quella di chiusura.";
									else
								return null;
                       
						default:
							return "Una sessione Aperta pu� passare solo in uno stato di Sospesa o Terminata.";
					}
				}

				case "Sospesa":
				{
					switch (StatoProposta)
					{
						case "Aperta":
							return null;

						//case "Abortita":
							//return "Ok";

						case "Terminata":
							if (adesso < (DateTime)sessione["DataOraChiusura"])
								return "Impossibile terminare la sessione in quanto la data attuale � ancora minore a quella di chiusura.";
							else
								return null;

						default:
							return "Una sessione Sospesa pu� passare solo in uno stato di Aperta o Terminata.";
					}
				}

				case "Terminata":
				{
					switch (StatoProposta)
					{
						case "Chiusa":
							return null;

						default:
							return "Una sessione Terminata pu� passare solo in uno stato di Chiusa.";
					}
				}

				//case "Abortita", "Chiusa":
				//	return "Una sessione se Abortita o Chiusa non pu� passare in altro stato.";

				case "Chiusa":
					return "Una sessione se Chiusa non pu� passare in altro stato.";
			}
			return null;
		}
		public string IsPossibleToSetTo(string IdSessione, string StatoProposta)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					string s = this.IsPossibleToSetTo(dbTran, IdSessione, StatoProposta);
					dbTran.Commit();
					return s;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		// ///////////////////////////////////////////////////////////////
		public PrezziRiferimento RetrievePrezzoRiferimento(IDbTransaction tr, string IdSessione)
		{
			DLAdminSessione dl = new DLAdminSessione(tr);

			// TODO LEO che sciocchezza.... forse bisogna far arrivare l'anno in cui si lavora
			// piuttosto l'anno corrente (della serie se lavora il 31.12.20XY per una sessione
			// del 20XY+1 perche deve ragionare con l'anno vecchio ?)
			int y = DLAdminCommon.GetDBSystemDate(tr).Year;
			return dl.RetrievePrezzoRiferimento(IdSessione, y);
		}
		public PrezziRiferimento RetrievePrezzoRiferimento(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					PrezziRiferimento pr = this.RetrievePrezzoRiferimento(dbTran, IdSessione);
					dbTran.Commit();
					return pr;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		// //////////////////////////////////////////////////////////////////
		public void Update(IDbTransaction tr, DataSet ds, out string messagioErrore)
		{
			messagioErrore = null;

			// prima controllo le operazioni che vuole fare nel ds passato
			DataTable dt = ds.Tables["Sessioni"];
			foreach (DataRow dr in dt.Rows)
			{
				switch (dr.RowState)
				{
					case DataRowState.Added:
					{
						// non bisogna fare niente sulle sessioni nuove
						break;
					}

					case DataRowState.Deleted:
					{
						// qui bisogna prima cancellare l'eventuale Budget
						if (true)
						{
							BLAdminBudget budget = new BLAdminBudget();

							string IdSessione = (string) dr["IdSessione", DataRowVersion.Original];
							string StatoSessione = (string) dr["StatoSessione", DataRowVersion.Original];
							if (StatoSessione != "In Attesa")
							{
								messagioErrore = "e' possibile modificare solo sessioni in stato 'In Attesa'";
								return;
							}

							budget.DeleteSessione(tr, IdSessione);
						}

						// poi i non iscritti e i CV
						if (true)
						{
							DLAdminCertificatoVerde cv = new DLAdminCertificatoVerde(tr);
							string IdSessione = (string) dr["IdSessione", DataRowVersion.Original];
							cv.CancellaNonIscrittiDellaSessione(IdSessione);
							cv.CancellaCVDellaSessione(IdSessione);
						}

						break;
					}

					case DataRowState.Modified:
					{
						// qui bisogna controllare prima un eventuale cambio di stato
						string msg = this.IsPossibleToSetTo(tr, (string)dr["IdSessione"], (string)dr["StatoSessione"]);
						if (msg != null)
						{
							// non e' possibile cambiare stato
							messagioErrore = msg;
							return;
						}
						break;
					}

					default:
						Debug.Assert(false, "Ti sei dimenticato di fare GetChanges?");
						break;
				}
			}

			// eseguo qui le modifiche alla tabella sessioni

			// TODO cosa fare con l'errore? ora viene fuori una eccezione
			DLAdminSessione dl = new DLAdminSessione(tr);
			dl.Update(ds);
		}
		public DataSet Update(DataSet ds, out string messaggioErrore)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminSessione dl = new DLAdminSessione(tr);
					this.Update(tr, ds, out messaggioErrore);
					if (messaggioErrore == null)
						tr.Commit();
					else
						tr.Rollback();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
	}
}
