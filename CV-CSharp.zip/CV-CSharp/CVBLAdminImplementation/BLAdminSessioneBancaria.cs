using System;
using System.Data;
using System.Data.OleDb;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Text;
using System.IO;
using System.Configuration;
using System.Diagnostics;

using CBI;
using CVCommon;
using CVBLAdminImplementation;

namespace CV.Admin
{
	/// <summary>
	/// Quella classe funge da wrapper a SessioneBancaria e gestisce
	/// le transazioni.
	/// </summary>
	public class BLAdminSessioneBancaria : CVRemotingBase, IBLAdminSessioneBancaria
	{
		public BLAdminSessioneBancaria()
		{
		}

		/// <summary>
		/// Ritorna null se e` possibile creare una sessione bancaria.
		/// != null se o esiste gia` o non esiste ma la sessione non e` in stato Terminata
		/// </summary>
		/// <param name="IdSessione"></param>
		/// <returns></returns>
		public string SessioneBancaria_CreazionePossibile(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string r = sb.SessioneBancaria_CreazionePossibile();
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		/// <summary>
		/// ritorna se esiste il record della sessione bancaria.
		/// </summary>
		/// <param name="IdSessione"></param>
		/// <returns></returns>
		public bool SessioneBancaria_Esiste(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					bool r = sb.SessioneBancaria_Esiste();
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public bool SessioneBancaria_Aperta(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					bool r = sb.SessioneBancaria_Aperta();
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public DataSet SessioneBancaria_Crea(string IdSessione, ref DateTime TSUltimaModifica, DateTime ValutaGP, DateTime ValutaPP, out string msg)
		{
			msg = string.Empty;

			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DateTime TSCreazione = DateTime.Now;

					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					msg = sb.SessioneBancaria_Crea(ref TSUltimaModifica, TSCreazione, ValutaGP, ValutaPP);
					DataSet ds = sb.CreateClientDataSet(ref TSUltimaModifica);
					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public DataSet SessioneBancaria_Dati(string IdSessione, ref DateTime TSUltimaModifica)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					DataSet ds = sb.CreateClientDataSet(ref TSUltimaModifica);
					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public string SessioneBancaria_Cancella(string IdSessione, ref DateTime TSUltimaModifica)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string msg = sb.SessioneBancaria_Cancella(ref TSUltimaModifica);
					tr.Commit();
					return msg;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public DataSet SessioneBancaria_Chiudi(string IdSessione, ref DateTime TSUltimaModifica, DateTime TSValuta, out string msg)
		{
			msg = string.Empty;

			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);

					msg = sb.SessioneBancaria_Chiudi(ref TSUltimaModifica, TSValuta);
					DataSet ds = sb.CreateClientDataSet(ref TSUltimaModifica);
					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public string SessioneBancaria_ReportApertura(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string msg = sb.SessioneBancaria_ReportApertura();
					tr.Commit();
					return msg;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}
		}
		public string SessioneBancaria_ReportStato(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string msg = sb.SessioneBancaria_ReportStato();
					tr.Commit();
					return msg;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}
		}
		public string SessioneBancaria_ReportChiusura(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string msg = sb.SessioneBancaria_ReportChiusura();
					tr.Commit();
					return msg;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}
		}


		
		public bool IstruzioniDiPagamento_DaGenerare(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					bool r = sb.IstruzioniDiPagamento_DaGenerare();
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public string IstruzioniDiPagamento_Genera(string IdSessione, ref DateTime TSUltimaModifica)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string r = sb.IstruzioniDiPagamento_Genera(
						ref TSUltimaModifica,
						GetFileNameCompletePath(ConfigurationSettings.AppSettings["XIP.xslt"]));
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public DataSet IstruzioniDiPagamento_Pubblica(string IdSessione, ref DateTime TSUltimaModifica, out string msg)
		{
			msg = string.Empty;

			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					msg = sb.IstruzioniDiPagamento_Pubblica(ref TSUltimaModifica);
					DataSet ds = sb.CreateClientDataSet(ref TSUltimaModifica);
					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public string IstruzioniDiPagamento_Visualizza(string IdSessione, string TipoReport)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string r = sb.IstruzioniDiPagamento_Visualizza(TipoReport);
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}
		public DataSet IstruzioniDiPagamento_CancellaUltimo(string IdSessione, ref DateTime TSUltimaModifica, out string msg)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					DataSet ds = sb.IstruzioniDiPagamento_CancellaUltimo(ref TSUltimaModifica, out msg);
					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

	
		
		public string  OrdinePagamentoSanPaolo_CreaNuovo(string IdSessione, ref DateTime TSUltimaModifica)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);

					string r = sb.OrdinePagamentoSanPaolo_CreaNuovo(
						ref TSUltimaModifica,
						GetFileNameCompletePath(ConfigurationSettings.AppSettings["XSP.xslt"]));

					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public DataSet OrdinePagamentoSanPaolo_Lista_SP_CBISP(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);

					DataSet r = sb.OrdinePagamentoSanPaolo_Lista_SP_CBISP();
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public string  OrdinePagamentoSanPaolo_Visualizza(string IdSessione, string IdReport)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);

					string r = sb.OrdinePagamentoSanPaolo_Visualizza(IdReport);
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public string OrdinePagamentoSanPaolo_CBI_DaInviare(string IdSessione, out DateTime TSCreazione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);

					string r = sb.OrdinePagamentoSanPaolo_CBI_DaInviare(out TSCreazione);
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public DataSet OrdinePagamentoSanPaolo_InviaUltimo(string IdSessione, ref DateTime TSUltimaModifica, DateTime TSInvio, out string msg)
		{
			msg = string.Empty;
			 
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);

					msg = sb.OrdinePagamentoSanPaolo_InviaUltimo(ref TSUltimaModifica, TSInvio);
					DataSet ds = sb.CreateClientDataSet(ref TSUltimaModifica);

					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public string  OrdinePagamentoSanPaolo_CancellaUltimo(string IdSessione, ref DateTime TSUltimaModifica)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string r = sb.OrdinePagamentoSanPaolo_CancellaUltimo(ref TSUltimaModifica);
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}

		public string  OrdinePagamentoSanPaolo_VisualizzaUltimoSP(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					string r = sb.OrdinePagamentoSanPaolo_VisualizzaUltimoSP();
					tr.Commit();
					return r;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}


		
		public DataSet MovPP_Perfezionato(string IdSessione, ref DateTime TSUltimaModifica, string IdMovPP, string trbanPerfezionateString, DateTime TSPerfezionato, DateTime ValutaGP2, out string msg)
		{
			msg = string.Empty;
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					StringCollection trbanPerfezionateList = new StringCollection();
					if (trbanPerfezionateString != null)
					{
						string [] al = trbanPerfezionateString.Split(new char [] { '\n' });
						trbanPerfezionateList.AddRange(al);
					}
	
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					msg = sb.MovPP_Perfezionato(ref TSUltimaModifica, IdMovPP, trbanPerfezionateList, TSPerfezionato, ValutaGP2);
					DataSet ds = sb.CreateClientDataSet(ref TSUltimaModifica);
					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}
	
		public DataSet MovPP_PerfezionamentoErrato(string IdSessione, ref DateTime TSUltimaModifica, string IdMovPP, out string msg)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					msg = sb.MovPP_PerfezionamentoErrato(ref TSUltimaModifica, IdMovPP);
					DataSet ds = sb.CreateClientDataSet(ref TSUltimaModifica);
					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}
	


		public DataSet Residui_Calcola(string IdSessione, ref DateTime TSUltimaModifica, DateTime valutaRestituzioneResiduo, out string msg)
		{
			msg = string.Empty;

			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					SessioneBancaria sb = new SessioneBancaria(tr as OleDbTransaction, IdSessione, true);
					int numeroPenali = sb.Residui_Calcola(ref TSUltimaModifica, valutaRestituzioneResiduo);
					DataSet ds = sb.CreateClientDataSet(ref TSUltimaModifica);

					if (numeroPenali == 0)
						msg = "Non sono stati creati movimenti di restituzione!";
					else
						msg = string.Format("Sono stati creati {0} movimenti di restituzione", numeroPenali);

					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}		
		}	
	}

	/// <summary>
	/// Questa classe e` il cuore della gestione bancaria.
	/// Funziona in maniera "rigida": a prescindere dalla funzione
	/// che andro` a fare (ossia il metodo che chiamero`) il costruttore
	/// si carica tutti i dati necessari in memoria (nel data set).
	/// Poi il metodo potra modificarli o no e salvarli.
	/// 
	/// Questa classe salva nel DB (fa del insert,update, ecc) ma non si cura
	/// di gestire la transazione.
	/// 
	/// La gestione della coerenza dei dati e` altrettanto rigida:
	/// due o piu` operatori possono consultare ma solo uno puo` modificare.
	/// Alla prima lettura dei dati (all'apertura della maschera della sessione bancaria)
	/// il chiamante (cioe` la maschera) si memorizza SessioneBancaria.TSUltimaModifica
	/// Quando un operatore vuole modificare i dati comunica come argomento la sua TSUltimaModifica.
	/// La procedura ri-legge SessioneBancaria.TSUltimaModifica e la confronta con TSUltimaModifica
	/// del chiamante: se sono diversi significa che un altro operatore ha modificato
	/// i dati.... l'operazione che vado a fare e` (con tutta probabilita`) inconsistente (per lo
	/// meno l'operatore vede dati non aggiornati). Se le date sono uguali, si aggiorna il DB e viene
	/// ritornato al cliente la nuova TSUltimaModifica.
	/// Questo meccanismo e` applicato SEMPRE e non si fa neanche un tentativo per vedere se la tale 
	/// funzione e` compatibile con le modifiche fatte da un'altra. 
	/// 
	/// Come detto i dati sono caricati nel costruttore e potenzialmente modificati dai metodi.
	/// I dati sono caricati for update... in modo da garantire la coerenza tra il costruttore
	/// e i metodi (ORacle non fa lock in lettura come SQL server).
	/// La classe funziona bene anche chiamando un metodo dopo l'altro nella stessa istanzia,
	/// anche se lo scopo del tutto (grazie alla modalita` single call della BL)
	/// non e` quello di mantenere lo stato ma e` quello di ricaricarlo ad ogni chiamata della BL.
	/// Questo approccio e` "pesante" dal punto di vista del DB (dato che carico sempre tutto)
	/// ma e` scalabile. Inoltre bisogna tenere conto che la sessione bancaria verra` utilizzata
	/// a "sistema fermo" (senza mercato, altri operatori di BackOffice ecc).
	/// La chiave di letttura delle scelte progettuale e`: dato che la sessione bancaria
	/// e` abbastanza delicata e "difficile", meglio piantare dei paletti, magari un po' rigidi,
	/// che garantiscano la coerenza dei dati SEMPRE (trattiamo soldi e tanti!!).
	/// </summary>
	public class SessioneBancaria
	{
		public SessioneBancaria(OleDbTransaction tr, string IdSessione, bool ForUpdate)
		{
			this.df = new DLAdminSessioneBancaria(tr, IdSessione, ForUpdate);
			this.ds = new dsGestioneBancaria();
			this.df.Fill(this.ds); // carico TUTTI i dati dal DB

			// dato che lavoro in una determinata sessione mi memorizzo il record
			// delle sessione corrente (per comodita')
			this.sessione = this.ds.Sessioni.FindByIdSessione(IdSessione);
			if (this.sessione == null)
				throw new ApplicationException(string.Format("Non riesco a trovare la Sessione per l'IdSessione {0}", IdSessione));

			// da utilizzare tutte le volte che si scrivono date ecc. in stringhe
			// destinate all'utente. (se sta roba gira in un server ci puoi giurare
			// che la lingua del server non e' IT-it ma FR-fr oppure En-Nz)
			cultureInfo = new CultureInfo("it-IT", false);
			if (cultureInfo.NumberFormat.CurrencySymbol != "�")
				cultureInfo.NumberFormat.CurrencySymbol = "�";

		}

		readonly private dsGestioneBancaria ds;
		readonly private DLAdminSessioneBancaria df;
		readonly private dsGestioneBancaria.SessioniRow sessione;
		readonly private CultureInfo cultureInfo;

		/// <summary>
		/// Questa funzione ritorna le due tabelle cosi` come sono utilizzate dalla maschera lato BackOffice.
		/// </summary>
		/// <returns></returns>
		public DataSet CreateClientDataSet(ref DateTime TSUltimaModifica)
		{
			// creo il ds
			DataSet dsClient = new DataSet();

			DataTable dtMovimentiBancari = dsClient.Tables.Add("MovimentiBancari");
			dtMovimentiBancari.Columns.Add("IdMovimentoBancario",       typeof(string));
			dtMovimentiBancari.Columns.Add("IdSocietaSrc",              typeof(string));
			dtMovimentiBancari.Columns.Add("IdSocietaDst",              typeof(string));
			dtMovimentiBancari.Columns.Add("SocietaSrc_RagioneSociale", typeof(string));
			dtMovimentiBancari.Columns.Add("SocietaSrc_CodiceConto",    typeof(string));
			dtMovimentiBancari.Columns.Add("SocietaDst_RagioneSociale", typeof(string));
			dtMovimentiBancari.Columns.Add("SocietaDst_CodiceConto",    typeof(string));
			dtMovimentiBancari.Columns.Add("TipoMovimento",             typeof(string));
			dtMovimentiBancari.Columns.Add("Importo",                   typeof(decimal));
			dtMovimentiBancari.Columns.Add("Valuta",                    typeof(DateTime));
			dtMovimentiBancari.Columns.Add("Causale",                   typeof(string));
			dtMovimentiBancari.Columns.Add("TSSottomesso",              typeof(DateTime));
			dtMovimentiBancari.Columns.Add("TSPerfezionato",            typeof(DateTime));
			dtMovimentiBancari.PrimaryKey = new DataColumn[1] { dtMovimentiBancari.Columns["IdMovimentoBancario"] };

			DataTable dtTransazioni = dsClient.Tables.Add("Transazioni");
			dtTransazioni.Columns.Add("IdTransazione",       typeof(string));
			dtTransazioni.Columns.Add("IdMovGP",             typeof(string));
			dtTransazioni.Columns.Add("IdMovPP",             typeof(string));
			dtTransazioni.Columns.Add("IdMovPenale",         typeof(string));
			dtTransazioni.Columns.Add("AnnoRiferimento",     typeof(string));
			dtTransazioni.Columns.Add("NumeroCV",            typeof(decimal));
			dtTransazioni.Columns.Add("Prezzo",              typeof(decimal));
			dtTransazioni.Columns.Add("PrezzoNonCoperto",    typeof(decimal));
			dtTransazioni.Columns.Add("PrezzoCoperto",       typeof(decimal));
			dtTransazioni.Columns.Add("PrezzoUnitario",      typeof(decimal));
			dtTransazioni.Columns.Add("StatoTransazione",    typeof(string));
			dtTransazioni.Columns.Add("DaPerfezionare",      typeof(bool)).AllowDBNull = false;
			dtTransazioni.PrimaryKey = new DataColumn[1] { dtTransazioni.Columns["IdTransazione"] };

			// seconda parte: le riempo

			foreach (dsGestioneBancaria.MovimentiBancariRow mov in ds.MovimentiBancari)
			{
				// 1) righe dei movimenti
				DataRow r = dtMovimentiBancari.NewRow();
				for (int c = 0; c < dtMovimentiBancari.Columns.Count; c++)
				{
					DataColumn col_dst = dtMovimentiBancari.Columns[c];
					DataColumn col_src = ds.MovimentiBancari.Columns[col_dst.ColumnName];
					if (mov.IsNull(col_src))
						r[col_dst] = Convert.DBNull;
					else
						r[col_dst] = mov[col_src];
				}
				dtMovimentiBancari.Rows.Add(r);

			}

			foreach (dsGestioneBancaria.TrBanRow trBan in ds.TrBan)
			{
				dsGestioneBancaria.TransazioniRow tr = trBan.TransazioniRow;

				dtTransazioni.Rows.Add(new object [] {
														 trBan.IdTransazione, 
														 trBan.IsIdMovGPNull() ? Convert.DBNull : trBan.IdMovGP,
														 trBan.IsIdMovPPNull() ? Convert.DBNull : trBan.IdMovPP,
														 trBan.IsIdMovPenaleNull() ? Convert.DBNull : trBan.IdMovPenale,
														 tr.AnnoRiferimento,
														 tr.QtyCertificati,
														 trBan.ImportoMovGP + trBan.ImportoMovPP,
														 trBan.ImportoMovPP,
														 trBan.ImportoMovGP,
														 tr.PrezzoUnitario,
														 tr.StatoTransazione,
														 false
													 } );
			}

			foreach (dsGestioneBancaria.SessioniBancarieRow s in ds.SessioniBancarie)
			{
				TSUltimaModifica = s.TSUltimaModifica;
				break;
			}

#if DEBUG
			dsClient.WriteXml(@"c:\ds_client.xml");
			dsClient.WriteXmlSchema(@"c:\ds_client_schema.xml");
#endif

			return dsClient;
		}


		/// <summary>
		/// Determina se esiste la sessione bancaria per la sessione corrente.
		/// Se non esiste e` necessario chiamare <code>SessioneBancaria_Crea</code>
		/// per iniziare una nuova sessione bancaria.
		/// </summary>
		/// <returns></returns>
		public bool SessioneBancaria_Esiste()
		{
			dsGestioneBancaria.SessioniBancarieRow sessioneBancaria = null;

			sessioneBancaria = ds.SessioniBancarie.FindByIdSessione(sessione.IdSessione);
			if (sessioneBancaria == null)
				return false;
			else
				return true;
		}

		/// <summary>
		/// Funzione che riporta se la sessione bancaria e` aperta o chiusa.
		/// </summary>
		/// <returns></returns>
		public bool SessioneBancaria_Aperta()
		{
			dsGestioneBancaria.SessioniBancarieRow sessioneBancaria = null;

			sessioneBancaria = ds.SessioniBancarie.FindByIdSessione(sessione.IdSessione);
			Debug.Assert(sessioneBancaria != null);
			if (sessioneBancaria == null)
				return false;

			return sessioneBancaria.IsTSChiusuraNull() == true;
		}

		public string SessioneBancaria_Cancella(ref DateTime TSUltimaModifica)
		{
			dsGestioneBancaria.SessioniBancarieRow sessioneBancaria = null;
			sessioneBancaria = ds.SessioniBancarie.FindByIdSessione(sessione.IdSessione);
			if (sessioneBancaria == null)
				return "Non esiste la sessione bancaria da cancellare";

#if !DEBUG  // in debug permetto la cancellazione, in release no
			if (sessioneBancaria.IsTSChiusuraNull() == false)
				return "Non si puo` cancellare una sessione bancaria 'chiusa'";
#endif

			string IdSessione = sessione.IdSessione;

			foreach (dsGestioneBancaria.TransazioniRow tr in ds.Transazioni)
			{
				tr.StatoTransazione = "Da Validare";
				tr.SetCausaleNull();
				tr.SetFileExportBancaNull();
				tr.SetPagabileDaGmeNull();
			}

			foreach (dsGestioneBancaria.BudgetsRow b in ds.Budgets)
				if (b.IdSessione == IdSessione)
					b.SetIdMovResiduoNull();

			df.Update(ds, ref TSUltimaModifica);

			foreach (dsGestioneBancaria.TrBanRow trban in ds.TrBan)
				if (trban.IdSessione == IdSessione)
					trban.Delete();

			foreach (dsGestioneBancaria.MovimentiBancariRow m in ds.MovimentiBancari)
				if (m.IdSessione == IdSessione)
					m.Delete();

			foreach (dsGestioneBancaria.SessioniBancarieRow s in ds.SessioniBancarie)
				if (s.IdSessione == IdSessione)
					s.Delete();

			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
				if (r.IdSessione == IdSessione)
					r.Delete();

			df.Update(ds, ref TSUltimaModifica);

			return string.Empty;
		}

		public string SessioneBancaria_ReportApertura()
		{
			DataRow [] r = ds.ReportCV.Select("TipoReport='INISB'");
			if (r.Length == 1)
				return Encoding.UTF8.GetString(((dsGestioneBancaria.ReportCVRow)r[0]).RawReport);
			return null;
		}


		public string SessioneBancaria_ReportStato()
		{
			return SessioneBancaria_ReportStato(false);
		}
		/// <summary>
		/// Crea il report di stato o il report di chiusura.
		/// Se esiste il report di chiusura nella tabella reportCV lo si ritorna immediatamente,
		/// altrimenti e` un report di stato vero e proprio --> lo genero ogni volta
		/// </summary>
		/// <param name="OnChiusuraBancaria"></param>
		/// <returns></returns>
		private string SessioneBancaria_ReportStato(bool OnChiusuraBancaria)
		{
			// prima guardo se il report di chiusura e` stato gia` generato (lo si fa solo in chiusura)
			// --> in questo modo ho congelato la situazione dei saldi.
			string rrr = SessioneBancaria_ReportChiusura();
			if (rrr != null)
				return rrr;

			StringWriter sw = new StringWriter();

			sw.WriteLine("<html style='FONT: messagebox'>");
			sw.WriteLine("<head>");
			sw.WriteLine("<META http-equiv='Content-Type' content='text/html; charset=utf-8'>");
			if (OnChiusuraBancaria)
				sw.WriteLine("<title>Rapporto finale della sessione bancaria</title>");
			else
				sw.WriteLine("<title>Rapporto di stato della sessione bancaria</title>");
			sw.WriteLine("</head>");
			sw.WriteLine("<body>");

			if (true)
			{
				sw.WriteLine("<b>Dati della sessione:</b><br/>");
				sw.WriteLine("Titolo sessione {0}.<br>", ds.Sessioni[0].Titolo);
				sw.WriteLine("Data ora apertura {0}.<br>", Converter.DateTimeToStringDateTime(ds.Sessioni[0].DataOraApertura));
				sw.WriteLine("<br/>");
			}

			bool bEsisteSessioneBancaria = false;
			bool bSessioneBancariaChiusa = false;
			if (true)
			{
				sw.WriteLine("<b>Dati della sessione bancaria:</b><br/>");
				if (this.SessioneBancaria_Esiste())
				{
					bEsisteSessioneBancaria = true;

					sw.Write("Sessione bancaria aperta il {0} ", Converter.DateTimeToStringDateTime(ds.SessioniBancarie[0].TSApertura));
					if (ds.SessioniBancarie[0].IsTSChiusuraNull() == false)
					{
						bSessioneBancariaChiusa = true;
						sw.Write("e chiusa il {0}.", Converter.DateTimeToStringDateTime(ds.SessioniBancarie[0].TSChiusura));
					}
					else
					{
						bSessioneBancariaChiusa = false;
						sw.Write(". Sessione bancaria in corso.");
					}
					sw.WriteLine("<br/>");
				}
				else
				{
					sw.WriteLine("Sessione bancaria non creata per questa sessione di mercato.<br/>");
				}
				sw.WriteLine("<br/>");
			}

			if (bEsisteSessioneBancaria)
			{
				sw.WriteLine("<b>Istruzioni di pagamento:</b><br/>");

				if (OnChiusuraBancaria == false)
				{
					switch (this.IstruzioniDiPagamento_GetStatus())
					{
						case SessioneBancaria.IP_Status.NonEsiste:
							sw.WriteLine("Istruzioni di pagamento ancora <font color='red'>da generare</font>.<br/>");
							break;
						case SessioneBancaria.IP_Status.EsisteDaPubblicare:
							sw.WriteLine("Istruzioni di pagamento generate <font color='red'>da pubblicare</font>.<br/>");
							break;
						case SessioneBancaria.IP_Status.EsisteGiaPubblicata:
							sw.WriteLine("Istruzioni di pagamento generate e pubblicate.<br/>");
							break;
					}
				}
				else
				{
					switch (this.IstruzioniDiPagamento_GetStatus())
					{
						case SessioneBancaria.IP_Status.NonEsiste:
							sw.WriteLine("Istruzioni di pagamento ancora da generare</font>.<br/>");
							break;
						case SessioneBancaria.IP_Status.EsisteDaPubblicare:
							sw.WriteLine("Istruzioni di pagamento generate da pubblicare</font>.<br/>");
							break;
						case SessioneBancaria.IP_Status.EsisteGiaPubblicata:
							sw.WriteLine("Istruzioni di pagamento generate e pubblicate.<br/>");
							break;
					}
				}
				sw.WriteLine("<br/>");
			}

			// Ordini di pagamento al san paolo.
			if (bEsisteSessioneBancaria)
			{
				sw.WriteLine("<b>Ordini di pagamento:</b><br/>");
				if (this.OrdinePagamentoSanPaolo_EsisteUltimoDaValidareInviare())
				{
					sw.WriteLine("Ordine di pagamento generato <font color='red'>da inviare</font> al San Paolo.<br/>");
				}
				else if (this.OrdinePagamentoSanPaolo_NecessarioCreareNuovo())
				{
					sw.WriteLine("E` necessario <font color='red'>creare un nuovo ordine di pagamento</font> in quando esistono movimenti GP da notificare alla banca.<br>");
				}

				if (true)
				{
					int n = 0;
					foreach (dsGestioneBancaria.ReportCVRow rr in ds.ReportCV)
						if (rr.TipoReport == "CBISP" && rr.IsTSInvioNull() == false)
							n++;
					sw.WriteLine("Inviati {0} ordini di pagamento al San. Paolo<br/>", n);
					sw.WriteLine("<br/>");
				}
			}

			// Residui.
			if (bEsisteSessioneBancaria)
			{
				sw.WriteLine("<b>Movimenti di restituzione residuo:</b><br/>");
				int numeroMovimentiResiduo = 0;
				foreach (dsGestioneBancaria.BudgetsRow budget in ds.Budgets)
				{
					if (budget.IsIdMovResiduoNull() == false)
						numeroMovimentiResiduo += 1;
				}

				if (numeroMovimentiResiduo == 0)
					sw.WriteLine("Non sono stati generati movimenti restituzione residuo.<br/>");
				else
					sw.WriteLine("Sono stati generati {0} movimenti restituzione residuo.<br/>", numeroMovimentiResiduo);
				sw.WriteLine("<br/>");


				if (OnChiusuraBancaria == false)
				{
					int numeroMovResiduiPagabili = this.Residui_Calcola_Pagabili(false);
					if (numeroMovResiduiPagabili == 0)
					{
						sw.WriteLine("Nel prossimo ordine di pagamento al San Paolo non saranno inclusi movimenti per la restituzione del residuo.");
					}
					else if (numeroMovResiduiPagabili == 1)
					{
						sw.WriteLine("<font color='red'>Nel prossimo ordine di pagamento al San Paolo sara` possibile effettuare 1 movimento per la restituzione del residuo.</font>");
					}
					else
					{
						sw.WriteLine("<font color='red'>Nel prossimo ordine di pagamento al San Paolo sara` possibile effettuare {0} movimenti per la restituzione residui.</font>", numeroMovResiduiPagabili);
					}

					sw.WriteLine("<br/>");
					sw.WriteLine("(la previsione puo` cambiare a fronte di un perfezionamento di un movimento PP)");
					sw.WriteLine("<br/>");
					sw.WriteLine("<br/>");
				}
			}

			// Movimenti PP da Perfezionare
			if (bEsisteSessioneBancaria)
			{
				sw.WriteLine("<b>Movimenti PP:</b><br/>");
				int numeroMovimentiDaPerfezionare = 0;
				int numeroMovimentiInadempienti = 0;

				foreach (dsGestioneBancaria.MovimentiBancariRow movPP in ds.MovimentiBancari)
				{
					if (movPP.TipoMovimento != "PP")
						continue;

					if (movPP.IsTSPerfezionatoNull() == false)
						continue;

					// ho un PP non perfezionato.
					// Forse e` stato gia` considerato nel pagamento della penale.

					// trovo le transazioni associate.
					dsGestioneBancaria.TrBanRow [] trbanPPList;
					trbanPPList = movPP.GetTrBanRowsByMovimentiBancari_TrBan_PP();
					Debug.Assert(trbanPPList.Length > 0);
					if (trbanPPList.Length == 0)
						continue; // non dovrebbe mai capitare

					// Trovo il numero di movimenti effettivamente ancora da perfezionare

					foreach (dsGestioneBancaria.TrBanRow trbanPP in trbanPPList)
					{
						dsGestioneBancaria.TransazioniRow transazione = trbanPP.TransazioniRow;
						if (transazione.StatoTransazione == "Non Valida")
						{
							numeroMovimentiDaPerfezionare += 1;
						}
						else if (transazione.StatoTransazione == "Inadempiente")
						{
							numeroMovimentiInadempienti += 1;
						}

						break; // devono essere tutte uguali le transazioni appartenenti al movimento.
					}
				}

				if (OnChiusuraBancaria)
				{
					if (numeroMovimentiInadempienti == 0)
						sw.WriteLine("Non esistono movimenti PP inadempienti.<br/>");
					else if (numeroMovimentiInadempienti == 1)
						sw.WriteLine("Esiste un movimento PP inadempiente.<br/>");
					else
						sw.WriteLine("Esistono {0} movimenti PP inadempienti.<br/>", numeroMovimentiInadempienti);
					sw.WriteLine("<br/>");
				}
				else
				{
					if (numeroMovimentiDaPerfezionare == 0)
						sw.WriteLine("Non esistono movimenti PP da perfezionare.<br/>");
					else if (numeroMovimentiDaPerfezionare == 1)
						sw.WriteLine("Esiste <font color='red'>un movimento PP da perfezionare</font>.<br/>");
					else
						sw.WriteLine("Esistono <font color='red'>{0} movimenti PP da perfezionare</font>.<br/>", numeroMovimentiDaPerfezionare);

					sw.WriteLine("<br/>");
				}
			}

			// Movimenti.
			if (true)
			{
				sw.WriteLine("<b>Dettaglio movimenti:</b><br/>");
//					sw.WriteLine("<table style=\"FONT-SIZE: x-small; FONT-FAMILY: 'Lucida Sans Unicode', Sans-Serif; BORDER-COLLAPSE:collapse; HEIGHT:23px\" border='2'>");
				sw.WriteLine("<table style=\"FONT: messagebox; BORDER-COLLAPSE:collapse; HEIGHT:23px\" border='2'>");
				sw.WriteLine("<tr>");
				sw.WriteLine("<td><b>Rag.soc. ordin.</b></td>");
				sw.WriteLine("<td><b>Cod.conto</b></td>");
				sw.WriteLine("<td><b>Rag.soc. benefic.</b></td>");
				sw.WriteLine("<td><b>Cod.conto</b></td>");
				sw.WriteLine("<td><b>Tipo</b></td>");
				sw.WriteLine("<td><b>Importo</b></td>");
				sw.WriteLine("<td><b>Valuta</b></td>");
				sw.WriteLine("<td><b>Causale</b></td>");
				sw.WriteLine("<td><b>Sottomesso</b></td>");
				sw.WriteLine("<td><b>Perfezionato</b></td>");
				sw.WriteLine("</tr>");

				DataRow [] lst = ds.MovimentiBancari.Select(null, "SocietaSrc_RagioneSociale, SocietaDst_RagioneSociale");
				int nr = 0;
				foreach (dsGestioneBancaria.MovimentiBancariRow m in lst)
				{
					if (++nr % 2 == 0)
						sw.WriteLine("<tr>");
					else
						sw.WriteLine("<tr bgcolor='whitesmoke'>");
					sw.WriteLine("<td>{0}</td>", m.SocietaSrc_RagioneSociale);
					sw.WriteLine("<td>{0}</td>", m.SocietaSrc_CodiceConto);
					sw.WriteLine("<td>{0}</td>", m.SocietaDst_RagioneSociale);
					sw.WriteLine("<td>{0}</td>", m.SocietaDst_CodiceConto);
					sw.WriteLine("<td>{0}</td>", m.TipoMovimento);
					sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.DecimalToCurrencyString(m, "Importo"));

					if (m.IsValutaNull() == false)
						sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.DateTimeToStringDate(m.Valuta));
					else
						sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", "");

					sw.WriteLine("<td>{0}</td>", m.Causale);

					if (m.IsTSSottomessoNull() == false)
						sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.DateTimeToStringDateTime(m.TSSottomesso));
					else
						sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", "");
			
					if (m.IsTSPerfezionatoNull() == false)
						sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.DateTimeToStringDateTime(m.TSPerfezionato));
					else
						sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", "");

					sw.WriteLine("</tr>");
				}
				sw.WriteLine("</table><br/>");
			}

			if (bSessioneBancariaChiusa)
			{
				sw.WriteLine("<br/>");

				sw.WriteLine("<b>Saldo delle societa` dopo la eventuale restituzione del residuo:</b><br/>");
				sw.WriteLine("<table style=\"FONT: messagebox; BORDER-COLLAPSE:collapse; HEIGHT:23px\" border='2'>");
				sw.WriteLine("<tr>");
				sw.WriteLine("<td><b>Ragione sociale</b></td>");
				sw.WriteLine("<td><b>Codice conto</b></td>");
				sw.WriteLine("<td><b>Saldo della sessione</b></td>");
				sw.WriteLine("</tr>");

				DataRow [] lst = ds.Societa.Select(null, "RagioneSociale");
				int nr = 0;
				foreach (dsGestioneBancaria.SocietaRow drSocieta in lst)
				{
					if (++nr % 2 == 0)
						sw.WriteLine("<tr>");
					else
						sw.WriteLine("<tr bgcolor='whitesmoke'>");
					sw.WriteLine("<td>{0}</td>", Converter.StringToString(drSocieta,"RagioneSociale"));
					sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.StringToString(drSocieta, "CodiceConto"));
					sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.DecimalToCurrencyString(drSocieta, "Saldo"));
					sw.WriteLine("</tr>");
				}

				sw.WriteLine("</table><br>");
			}

			sw.WriteLine("</body>");
			sw.WriteLine("</html>");
			sw.Flush();

			return sw.GetStringBuilder().ToString();
		}

		public string SessioneBancaria_ReportChiusura()
		{
			DataRow [] r = ds.ReportCV.Select("TipoReport='ENDSB'");
			if (r.Length == 1)
				return Encoding.UTF8.GetString(((dsGestioneBancaria.ReportCVRow)r[0]).RawReport);

			return null;
		}


		#region CreazioneSessioneBancaria
		public string SessioneBancaria_CreazionePossibile()
		{
#if !DEBUG
			if (sessione.StatoSessione != "Terminata")
				return "La sessione non e` in stato 'Terminata'";
#endif

			if (ds.SessioniBancarie.Count > 0)
				return "Esiste gia` una sessione bancaria";

			foreach (dsGestioneBancaria.TransazioniRow tr in ds.Transazioni)
				if (tr.StatoTransazione != "Da Validare")
					return "Esiste una o piu` transazione CV in stato diverso da 'Da Validare'.";

			return null;
		}

		/// <summary>
		/// Crea la sessione bancaria per la sessione.
		/// </summary>
		public string SessioneBancaria_Crea(ref DateTime TSUltimaModifica, DateTime TSCreazione, DateTime ValutaGP, DateTime ValutaPP)
		{
#if !DEBUG
			if (sessione.StatoSessione != "Terminata")
				return "La sessione non e` in stato 'Terminata'";
#endif
			if (ds.SessioniBancarie.Count > 0)
				return "La sessione bancaria esiste gia`";

			// creo il record della sessione bancaria.
			dsGestioneBancaria.SessioniBancarieRow sb = ds.SessioniBancarie.NewSessioniBancarieRow();
			sb.IdSessione = sessione.IdSessione;
			sb.TSApertura = TSCreazione;
			ds.SessioniBancarie.AddSessioniBancarieRow(sb);

			// calcolo per ogni societa' acquirente se e' coperta o no
			SortedList coperturaBudgetPerSocieta = new SortedList(); // key=IdSocietaAcq, value=bool (coperto/non coperto)
			if (true)
			{
				CalcoloCoperturaSocietaAcquirente calcCop = new CalcoloCoperturaSocietaAcquirente(ds, sessione, coperturaBudgetPerSocieta);
				calcCop.Loop();
			}

			// qui accorpo le transazioni, creo AccorpamentiCV, TrCV_AccorpamentiCV, MovimentiBancari
			if (true)
			{
				AccorpamentoCV acc = new AccorpamentoCV(cultureInfo, ds, sessione, coperturaBudgetPerSocieta, ValutaGP, ValutaPP);
				acc.Loop();
			}

			df.Update(ds, ref TSUltimaModifica);

			try
			{
				SessioneBancaria_CreaReportApertura(ref TSUltimaModifica, TSCreazione);
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore nella creazione del report di apertura");
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
			}

			return string.Empty;
		}
		public class CalcoloCoperturaSocietaAcquirente : CollectionGrouper
		{
			public CalcoloCoperturaSocietaAcquirente(dsGestioneBancaria ds, dsGestioneBancaria.SessioniRow sessione, SortedList coperturaBudgetPerSocieta)
				: base(ds.Transazioni)
			{
				this.sessione = sessione;
				this.ds = ds;
				this.coperturaBudgetPerSocieta = coperturaBudgetPerSocieta;
			}

			// variabili comuni a tutti i gruppi
			readonly dsGestioneBancaria ds;
			readonly dsGestioneBancaria.SessioniRow sessione;
			readonly SortedList coperturaBudgetPerSocieta;  // lista da riempire

			// variabili di gruppo
			decimal spesaSocAcq = 0m;

			// order by IdSocietaAcq
			public override int Compare(object a, object b)
			{
				// soliti confronti necessari per Compare
				if (a == null && b == null) return  0;
				if (a != null && b == null) return  1;
				if (a == null && b != null) return -1;
				dsGestioneBancaria.TransazioniRow ta = (dsGestioneBancaria.TransazioniRow)a;
				dsGestioneBancaria.TransazioniRow tb = (dsGestioneBancaria.TransazioniRow)b;
				return string.Compare(ta.IdSocietaAcq, tb.IdSocietaAcq);
			}

			public override bool CheckBreak(object prev_item, object current_item)
			{
				dsGestioneBancaria.TransazioniRow prev_trcv    = (dsGestioneBancaria.TransazioniRow)prev_item;
				dsGestioneBancaria.TransazioniRow current_trcv = (dsGestioneBancaria.TransazioniRow)current_item;

				return prev_trcv.IdSocietaAcq != current_trcv.IdSocietaAcq;
			}
			public override void OnFirstItem(object item)
			{
				spesaSocAcq = 0m;
			}
			public override void OnItem(object item)
			{
				dsGestioneBancaria.TransazioniRow trcv = (dsGestioneBancaria.TransazioniRow)item;
				//decimal numMWhPerCV = ds.MwCertficato.FindByAnno(trcv.AnnoRiferimento).QtyMWh; //Stefano
				spesaSocAcq += trcv.PrezzoUnitario * trcv.QtyCertificati * DLAdminBase.MWhPerCV; //Stefano OK
			}
			public override void OnLastItem(object item)
			{
				dsGestioneBancaria.TransazioniRow trcv = (dsGestioneBancaria.TransazioniRow)item;
				dsGestioneBancaria.BudgetsRow budget = ds.Budgets.FindByIdSessioneIdSocieta(sessione.IdSessione, trcv.IdSocietaAcq);
				if (budget.Importo >= spesaSocAcq)
					coperturaBudgetPerSocieta.Add(trcv.IdSocietaAcq, true);
				else
					coperturaBudgetPerSocieta.Add(trcv.IdSocietaAcq, false);
			}
		}

		public class AccorpamentoCV : CollectionGrouper
		{
			// variabili utilizzate per tutti gli item
			readonly SortedList         coperturaBudgetPerSocieta;
			readonly dsGestioneBancaria ds;
			readonly dsGestioneBancaria.SessioniRow sessione;
			readonly CultureInfo cultureInfo;
			readonly DateTime ValutaGP;
			readonly DateTime ValutaPP;


			// variabile utilizzate dal gruppo
			dsGestioneBancaria.BudgetsRow budgetSocietaAcq = null;
			dsGestioneBancaria.SocietaRow societaAcq;
			dsGestioneBancaria.SocietaRow societaVnd;

			bool copertaSocietaAcq = false;
			decimal spesaMovGP1 = 0m;
			decimal spesaMovPP  = 0m;
			decimal spesaMovGP2 = 0m;
			ArrayList trbnList = null;

			public AccorpamentoCV(CultureInfo cultureInfo, dsGestioneBancaria ds, dsGestioneBancaria.SessioniRow sessione, SortedList coperturaBudgetPerSocieta, DateTime ValutaGP, DateTime ValutaPP)
				: base(ds.Transazioni)
			{
				this.cultureInfo = cultureInfo;
				this.coperturaBudgetPerSocieta = coperturaBudgetPerSocieta;
				this.ds = ds;
				this.sessione = sessione;
				this.ValutaGP = ValutaGP;
				this.ValutaPP = ValutaPP;
			}

			// order by IdSocietaAcq,IdSocietaVen
			public override int Compare(object a, object b)
			{
				// soliti confronti necessari per Compare
				if (a == null && b == null) return 0;
				if (a != null && b == null) return 1;
				if (a == null && b != null) return -1;

				dsGestioneBancaria.TransazioniRow ta = (dsGestioneBancaria.TransazioniRow)a;
				dsGestioneBancaria.TransazioniRow tb = (dsGestioneBancaria.TransazioniRow)b;

				int c = string.Compare(ta.IdSocietaAcq, tb.IdSocietaAcq);
				if (c != 0)
					return c;
				return string.Compare(ta.IdSocietaVen, tb.IdSocietaVen);
			}

			public override bool CheckBreak(object prev_item, object current_item)
			{
				dsGestioneBancaria.TransazioniRow prev_trcv    = (dsGestioneBancaria.TransazioniRow)prev_item;
				dsGestioneBancaria.TransazioniRow current_trcv = (dsGestioneBancaria.TransazioniRow)current_item;

				// finche' acquirente/venditore sono gli stessi sono nello stesso gruppo.
				return !(prev_trcv.IdSocietaAcq == current_trcv.IdSocietaAcq &&
					prev_trcv.IdSocietaVen == current_trcv.IdSocietaVen);
			}
			public override void OnFirstItem(object item)
			{
				dsGestioneBancaria.TransazioniRow trcv = (dsGestioneBancaria.TransazioniRow)item;

				budgetSocietaAcq = ds.Budgets.FindByIdSessioneIdSocieta(sessione.IdSessione, trcv.IdSocietaAcq);
				copertaSocietaAcq = (bool)coperturaBudgetPerSocieta[trcv.IdSocietaAcq];

				societaAcq = ds.Societa.FindByIdSocieta(trcv.IdSocietaAcq);
				societaVnd = ds.Societa.FindByIdSocieta(trcv.IdSocietaVen);

				spesaMovGP1 = 0m; // spesa interamente coperta delle Tr inizialmente valide
				spesaMovPP  = 0m; // quota non coperta delle tr inizialmente Non Valide.
				spesaMovGP2 = 0m; // quota coperta dell tr inizialmente Non Valide

				trbnList = new ArrayList(); // lista vuota
			}
			public override void OnItem(object item)
			{
				dsGestioneBancaria.TransazioniRow trcv = (dsGestioneBancaria.TransazioniRow)item;

				dsGestioneBancaria.TrBanRow trbn = ds.TrBan.NewTrBanRow();
				trbn.IdSessione = sessione.IdSessione;
				trbn.IdTransazione = trcv.IdTransazione;
				trbnList.Add(trbn); // aggiungo la TrBan alla lista.

				//decimal numMWhPerCV = ds.MwCertficato.FindByAnno(trcv.AnnoRiferimento).QtyMWh; //Stefano
				
				if (copertaSocietaAcq ||
					trcv.PrezzoUnitario <= budgetSocietaAcq.PrezzoConvenzionaleUtenteMw)
				{
					trcv.StatoTransazione = "Valida";
					trcv.PagabileDaGme = "SI";
					trcv.SetCausaleNull();
					trcv.SetFileExportBancaNull();

					trbn.ImportoMovGP = trcv.QtyCertificati * trcv.PrezzoUnitario * DLAdminBase.MWhPerCV; //Stefano
					trbn.ImportoMovPP = 0m;

					spesaMovGP1 += trbn.ImportoMovGP;
				}
				else
				{
					trcv.StatoTransazione = "Non Valida";
					trcv.SetPagabileDaGmeNull();
					trcv.SetCausaleNull();
					trcv.SetFileExportBancaNull();

					decimal spesaEffettivaCV     = trcv.QtyCertificati * trcv.PrezzoUnitario * DLAdminBase.MWhPerCV;
					decimal spesaConvenzionaleCV = trcv.QtyCertificati * budgetSocietaAcq.PrezzoConvenzionaleUtenteMw * DLAdminBase.MWhPerCV;

					trbn.ImportoMovPP = spesaEffettivaCV - spesaConvenzionaleCV;
					trbn.ImportoMovGP = spesaConvenzionaleCV;

					spesaMovPP += trbn.ImportoMovPP;
					spesaMovGP2 += trbn.ImportoMovGP;
				}
			}
			public override void OnLastItem(object item)
			{
				dsGestioneBancaria.TransazioniRow trcv = (dsGestioneBancaria.TransazioniRow)item;

				if (spesaMovGP1 > 0m)
				{
					dsGestioneBancaria.MovimentiBancariRow mov = ds.MovimentiBancari.NewMovimentiBancariRow();
					mov.IdMovimentoBancario = NewGuid;
					mov.IdSessione = sessione.IdSessione;
					mov.TipoMovimento = "GP";
					mov.IdSocietaSrc = trcv.IdSocietaAcq;
					mov.IdSocietaDst = trcv.IdSocietaVen;
					mov.Importo = spesaMovGP1;
					mov.Valuta = ValutaGP;
					mov.Causale = string.Format(
						"MCV {0}: Pagamento CV.",
						sessione.DataOraApertura.ToString("d", cultureInfo));
					mov.SetNoteNull();
					mov.SetTSSottomessoNull();
					mov.SetTSPerfezionatoNull();
					mov.SocietaSrc_RagioneSociale = societaAcq.RagioneSociale;
					mov.SocietaSrc_CodiceConto    = societaAcq.CodiceConto;
					mov.SocietaDst_RagioneSociale = societaVnd.RagioneSociale;
					mov.SocietaDst_CodiceConto    = societaVnd.CodiceConto;
					Debug.Assert(ds.Budgets.FindByIdSessioneIdSocieta(sessione.IdSessione, mov.IdSocietaSrc).IsIdMovResiduoNull() == true);
					ds.MovimentiBancari.AddMovimentiBancariRow(mov);

					foreach (dsGestioneBancaria.TrBanRow trbn in trbnList)
					{
						if (trbn.ImportoMovPP == 0m) // non ha quota PP --> e` sicuramente Valida
						{
							trbn.IdMovGP = mov.IdMovimentoBancario;
							trbn.SetIdMovPPNull();
							trbn.SetIdMovPenaleNull();
						}
					}
				}
				if (spesaMovPP > 0m)
				{
					dsGestioneBancaria.MovimentiBancariRow mov = ds.MovimentiBancari.NewMovimentiBancariRow();
					mov.IdMovimentoBancario = NewGuid;
					mov.IdSessione = sessione.IdSessione;
					mov.TipoMovimento = "PP";
					mov.IdSocietaSrc = trcv.IdSocietaAcq;
					mov.IdSocietaDst = trcv.IdSocietaVen;
					mov.Importo = spesaMovPP;
					mov.Valuta = ValutaPP;
					mov.Causale = string.Format(
						"MCV {0}: Pagamento CV quota non coperta.",
						sessione.DataOraApertura.ToString("d", cultureInfo));
					mov.SetNoteNull();
					mov.SetTSSottomessoNull();
					mov.SetTSPerfezionatoNull();
					mov.SocietaSrc_RagioneSociale = societaAcq.RagioneSociale;
					mov.SocietaSrc_CodiceConto    = societaAcq.CodiceConto;
					mov.SocietaDst_RagioneSociale = societaVnd.RagioneSociale;
					mov.SocietaDst_CodiceConto    = societaVnd.CodiceConto;
					Debug.Assert(ds.Budgets.FindByIdSessioneIdSocieta(sessione.IdSessione, mov.IdSocietaSrc).IsIdMovResiduoNull() == true);
					ds.MovimentiBancari.AddMovimentiBancariRow(mov);

					foreach (dsGestioneBancaria.TrBanRow trbn in trbnList)
					{
						if (trbn.ImportoMovPP > 0m) // ha quota PP --> e` sicuramente Non Valida
						{
							trbn.SetIdMovGPNull();
							trbn.IdMovPP = mov.IdMovimentoBancario;
							trbn.SetIdMovPenaleNull();
						}
					}
				}

				foreach (dsGestioneBancaria.TrBanRow trbn in trbnList)
				{
					ds.TrBan.AddTrBanRow(trbn);
				}
			}
		}

		void SessioneBancaria_CreaReportApertura(ref DateTime TSUltimaModifica, DateTime TSApertura)
		{
			StringWriter sw = new StringWriter();

			sw.WriteLine("<html style='FONT: messagebox'>");
			sw.WriteLine("<head>");
			sw.WriteLine("<META http-equiv='Content-Type' content='text/html; charset=utf-8'>");
			sw.WriteLine("<title>Sessione bancaria: report di apertura.</title>");
			sw.WriteLine("</head>");
			sw.WriteLine("<body>");

			if (true)
			{
				sw.WriteLine("<b>Dati della sessione:</b><br/>");
				sw.WriteLine("Titolo sessione {0}.<br>", ds.Sessioni[0].Titolo);
				sw.WriteLine("Data ora apertura {0}.<br>", Converter.DateTimeToStringDateTime(ds.Sessioni[0].DataOraApertura));
				sw.WriteLine("<br/>");
			}

			if (true)
			{
				sw.WriteLine("<br/>");

				sw.WriteLine("<b>Budget per societa`:</b><br/>");
				sw.WriteLine("<table style=\"FONT: messagebox; BORDER-COLLAPSE:collapse; HEIGHT:23px\" border='2'>");
				sw.WriteLine("<tr>");
				sw.WriteLine("<td><b>Ragione sociale</b></td>");
				sw.WriteLine("<td><b>Codice conto</b></td>");
				sw.WriteLine("<td><b>Saldo sessione precedente</b></td>");
				sw.WriteLine("<td><b>Movimenti per la sessione</b></td>");
				sw.WriteLine("<td><b>Totale budget per la sessione</b></td>");
				sw.WriteLine("<td><b>Modalita` di restituzione</b></td>");
				sw.WriteLine("</tr>");

				DataRow [] lst = ds.Societa.Select(null, "RagioneSociale");
				int nr = 0;
				foreach (dsGestioneBancaria.SocietaRow drSocieta in lst)
				{
					dsGestioneBancaria.BudgetsRow budget = ds.Budgets.FindByIdSessioneIdSocieta(ds.Sessioni[0].IdSessione, drSocieta.IdSocieta); 
					if (budget == null)
						continue;

					if (++nr % 2 == 0)
						sw.WriteLine("<tr>");
					else
						sw.WriteLine("<tr bgcolor='whitesmoke'>");

					decimal saldo     = drSocieta.IsSaldoNull() ? 0m : drSocieta.Saldo;
					decimal importo   = budget.Importo;
					decimal movimenti = importo - saldo;
					decimal residuo   = budget.IsResiduoNull() ? 0m : budget.Residuo;

					sw.WriteLine("<td>{0}</td>", drSocieta.RagioneSociale);
					sw.WriteLine("<td>{0}</td>", drSocieta.CodiceConto);
					sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.DecimalToCurrencyString(saldo));
					sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.DecimalToCurrencyString(movimenti));
					sw.WriteLine("<td style=\"TEXT-ALIGN:right\">{0}</td>", Converter.DecimalToCurrencyString(importo));
					if (residuo < 0)
						sw.WriteLine("<td>{0}</td>", "nessuna restituzione");
					else if (residuo == 0)
						sw.WriteLine("<td>{0}</td>", "restituzione di tutto il budget");
					else
						sw.WriteLine("<td>rimanenza al max di {0}</td>", Converter.DecimalToCurrencyString(residuo));

																			  

					sw.WriteLine("</tr>");
				}

				sw.WriteLine("</table><br>");
			}

			sw.WriteLine("</body>");
			sw.WriteLine("</html>");
			sw.Flush();

			string rpt = sw.GetStringBuilder().ToString();

			if (true)
			{
				dsGestioneBancaria.ReportCVRow rp = ds.ReportCV.NewReportCVRow();
				rp.IdReport = NewGuid;
				rp.IdReportGroup = rp.IdReport;
				rp.TipoReport = "INISB";
				rp.FormatoReport = "html";
				rp.NomeReport = string.Format(
					"Mercato CV del {0}: report di apertura bancaria.", 
					sessione.DataOraApertura.ToString("d", cultureInfo));
				rp.TSCreazione = TSApertura;
				rp.SetTSPubblicazioneNull();
				rp.SetTSDownloadNull();
				rp.SetTSInvioNull();
				rp.SetTSRicevutoNull();
				rp.IdSessione = sessione.IdSessione;
				rp.SetIdSocietaNull();
				rp.RawReport = Encoding.UTF8.GetBytes(rpt);
				ds.ReportCV.AddReportCVRow(rp);

				df.Update(ds, ref TSUltimaModifica);
			}
		}

		#endregion

		#region MovPP_Perfezionato
		/// <summary>
		/// Metodo da chiamare quando movimento PP e' perfezionato
		/// </summary>
		/// <param name="tr"></param>
		/// <param name="ds"></param>
		/// <param name="IdMovB"></param>
		/// <param name="tsPerfezionato"></param>
		public string MovPP_Perfezionato(ref DateTime TSUltimaModifica, string IdMovPP, StringCollection trbanPerfezionateList, DateTime TSPerfezionato, DateTime ValutaGP2)
		{
			// 1. carico il movimento e lo setto perfezionato
			dsGestioneBancaria.MovimentiBancariRow movPP = ds.MovimentiBancari.FindByIdMovimentoBancario(IdMovPP);
			if (movPP == null)
				throw new ApplicationException(string.Format("non trovo il movimento PP {0}", IdMovPP));
			Debug.Assert(movPP.TipoMovimento == "PP");

			if (movPP.IsTSSottomessoNull() == true)
				return "Il movimento non puo` essere perfezionato in quanto non sono state pubblicate le istruzioni di pagamento";

			if (movPP.IsTSPerfezionatoNull() == false)
				return "Il movimento e` gia` perfezionato";

			// come lista delle transazioni da perfezionare accetto sia 
			// null        --> tutte le transazioni del movimento
			// lista vuota --> tutte le transazioni del movimento
			// lista con almeno 1 item --> perfeziono solo le tr nella lista
			if (trbanPerfezionateList.Count == 0)
				trbanPerfezionateList = null;

			// 2. Trovo la ragione sociale
			string RagSocAcquirente = ds.Societa.FindByIdSocieta(movPP.IdSocietaSrc).RagioneSociale;


			// 3. Ritrovo le tr associate al movimento e calcolo la quota GP2 e dell'eventuale nuovo movimento PP
			decimal ImportoMovGP = 0m;
			decimal ImportoMovPP = 0m;
			decimal ImportoMovPPNew = 0m;
			dsGestioneBancaria.TrBanRow [] trbnPPList;
			if (true)
			{
				trbnPPList = movPP.GetTrBanRowsByMovimentiBancari_TrBan_PP();

				// controllo che le Tr nella trbanPerfezionateList siano effettivamente in trbnPPList
				if (trbanPerfezionateList != null)
				{
					foreach (string IdTransazione in trbanPerfezionateList)
					{
						bool found = false;
						foreach (dsGestioneBancaria.TrBanRow trbn in trbnPPList)
						{
							if (trbn.IdTransazione == IdTransazione)
							{
								found = true;
								break;
							}
						}

						if (!found)
							throw new ApplicationException("Transazione da perfezionata non trovata");
					}
				}

				// calcolo l'importo scoperto che e` stato perfezionato
				foreach (dsGestioneBancaria.TrBanRow trbn in trbnPPList)
				{
					if (trbanPerfezionateList == null || trbanPerfezionateList.Contains(trbn.IdTransazione))
					{
						// trban perfezionata
						ImportoMovPP += trbn.ImportoMovPP;  // importo non coperto
						ImportoMovGP += trbn.ImportoMovGP;  // importo coperto --> da mettere nel GP2
					}
					else
					{
						// trban non perfezionata --> andra` nel nuovo movimento PP
						ImportoMovPPNew += trbn.ImportoMovPP;
					}
				}
			}

			// 3.5 Aggiusto l'importo in caso di Perfezionamento parziale.
			Debug.Assert(Math.Abs(movPP.Importo - (ImportoMovPP + ImportoMovPPNew)) < 0.01m);
			movPP.TSPerfezionato = TSPerfezionato; // qui finalmente perfeziono il movimento indicato
			if (ImportoMovPPNew > 0m)
				movPP.Importo = ImportoMovPP; // il movimento e` perfezionato in parte --> devo aggiornare l'importo.

			// 4. Creo un nuovo movimento GP
			dsGestioneBancaria.MovimentiBancariRow movGP = ds.MovimentiBancari.NewMovimentiBancariRow();
			movGP.IdMovimentoBancario = NewGuid;
			movGP.IdSessione = sessione.IdSessione;
			movGP.TipoMovimento = "GP";
			movGP.IdSocietaSrc = movPP.IdSocietaSrc;
			movGP.IdSocietaDst = movPP.IdSocietaDst;
			movGP.Importo = ImportoMovGP;
			movGP.Valuta = ValutaGP2;
			movGP.Causale = string.Format(
				"MCV {0}: Pagamento CV quota coperta.", 
				sessione.DataOraApertura.ToString("d", cultureInfo));
			Debug.Assert(movGP.Causale.Length <= 50);
			movGP.SetNoteNull();
			movGP.SetTSSottomessoNull();
			movGP.SetTSPerfezionatoNull();
			movGP.SocietaSrc_RagioneSociale = movPP.SocietaSrc_RagioneSociale;
			movGP.SocietaSrc_CodiceConto    = movPP.SocietaSrc_CodiceConto;
			movGP.SocietaDst_RagioneSociale = movPP.SocietaDst_RagioneSociale;
			movGP.SocietaDst_CodiceConto    = movPP.SocietaDst_CodiceConto;
			Debug.Assert(ds.Budgets.FindByIdSessioneIdSocieta(sessione.IdSessione, movGP.IdSocietaSrc).IsIdMovResiduoNull() == true);
			ds.MovimentiBancari.AddMovimentiBancariRow(movGP);

			// 5. Assegno a tutte le transazioni il nuovo movimento GP
			foreach (dsGestioneBancaria.TrBanRow trbn in trbnPPList)
			{
				if (trbanPerfezionateList == null || trbanPerfezionateList.Contains(trbn.IdTransazione))
				{
					trbn.IdMovGP = movGP.IdMovimentoBancario;

					// "blocco" la transazione
					trbn.TransazioniRow.PagabileDaGme = "SI";
					trbn.TransazioniRow.Causale = movGP.IdMovimentoBancario.Substring(0, 25);
					trbn.TransazioniRow.StatoTransazione = "Valida";
				}
			}

			// 6. Se e` il caso creo il nuovo movimento PP che contiene le transazioni non sbloccate
			if (ImportoMovPPNew > 0m)
			{
				dsGestioneBancaria.MovimentiBancariRow movPPNew = ds.MovimentiBancari.NewMovimentiBancariRow();
				movPPNew.IdMovimentoBancario = NewGuid;
				movPPNew.IdSessione = sessione.IdSessione;
				movPPNew.TipoMovimento = "PP";
				movPPNew.IdSocietaSrc = movPP.IdSocietaSrc;
				movPPNew.IdSocietaDst = movPP.IdSocietaDst;
				movPPNew.Importo = ImportoMovPPNew;
				movPPNew.Valuta = movPP.Valuta;
				movPPNew.Causale = movPP.Causale;
				movPPNew.SetNoteNull();
				movPPNew.SetTSSottomessoNull(); // questo movimento non e` ancora "descritto" nelle IP.
				movPPNew.SetTSPerfezionatoNull();
				movPPNew.SocietaSrc_RagioneSociale = movPP.SocietaSrc_RagioneSociale;
				movPPNew.SocietaSrc_CodiceConto    = movPP.SocietaSrc_CodiceConto;
				movPPNew.SocietaDst_RagioneSociale = movPP.SocietaDst_RagioneSociale;
				movPPNew.SocietaDst_CodiceConto    = movPP.SocietaDst_CodiceConto;
				movPPNew.TSSottomesso              = movPP.TSSottomesso;
				ds.MovimentiBancari.AddMovimentiBancariRow(movPPNew);

				foreach (dsGestioneBancaria.TrBanRow trbn in trbnPPList)
				{
					Debug.Assert(trbanPerfezionateList != null);
					if (trbanPerfezionateList.Contains(trbn.IdTransazione) == false)
						trbn.IdMovPP = movPPNew.IdMovimentoBancario; // lo associo alle tr escluse da questo perfezionamento
				}
			}

			df.Update(ds, ref TSUltimaModifica);

			return "Perfezionamento effettuato con successo";
		}
		/// <summary>
		/// Funzione per "ritornare indietro" quando si perfeziona un movimento.
		/// Dovrebbe essere una funzionalita` usata raramente (tendenzialmente su errore operatore)
		/// e dunque non va tanto per il sottile.
		/// Si potrebbero riaccorpare i movimenti, ma avere movimenti
		/// non riaccorpati non fa danni: semplicemente le transazioni saranno
		/// associate a mov PP e poi GP distinti anche se Src e Dest sono uguali.
		/// Non esiste la possibilita` togliere in perfezionamento
		/// solo ad alcune transazioni perfezionate di un movimento: non e` un problema
		/// neanche questo dato che poi` l'operatore le potra` riperfezionare per transazione.
		/// </summary>
		/// <param name="IdMovB"></param>
		public string MovPP_PerfezionamentoErrato(ref DateTime TSUltimaModifica, string IdMovPP)
		{
			// 1. precondizioni
			if (ds.SessioniBancarie[0].IsTSChiusuraNull() == false)
				return "Non e' possibile cambiare lo stato ad un movimento dopo la chiusura bancaria.";

			foreach (dsGestioneBancaria.TrBanRow trbn in ds.TrBan)
			{
				if (trbn.IsIdMovPenaleNull() == false)
					return "Non e` possibile cambiare lo stato ad un movimento dopo il calcolo delle penali.";
			}

			foreach (dsGestioneBancaria.BudgetsRow budget in ds.Budgets)
			{
				if (budget.IsIdMovResiduoNull() == false)
					return "Non e` possibile cambiare lo stato ad un movimento dopo il calcolo dei residui.";
			}


			// se esiste un Ordine di pagamento da inviare puo` essere che questo contenga il movimento
			// GP conseguente.... morale se esiste deve cancellarlo per fare undo del perfezionamento.
			if (OrdinePagamentoSanPaolo_EsisteUltimoDaValidareInviare())
			{
				return "Non e` possibile cambiare lo stato di un movimento se esiste un ordine di pagamento da inviare";
			}

			// 2. carico il movimento e lo setto perfezionato
			dsGestioneBancaria.MovimentiBancariRow movPP = ds.MovimentiBancari.FindByIdMovimentoBancario(IdMovPP);
			if (movPP == null)
				throw new ApplicationException(string.Format("non trovo il movimento PP {0}", IdMovPP));

			Debug.Assert(movPP.TipoMovimento == "PP");
			if (movPP.TipoMovimento != "PP")
				return "Il movimento non e` di tipo PP (Privato-Privato)";
			if (movPP.IsTSPerfezionatoNull() == true)
				return "Il movimento non e` ancora perfezionato";

			// 3. trovo le transazioni associate al movimento PP
			dsGestioneBancaria.TrBanRow [] trbnList;
			trbnList = movPP.GetTrBanRowsByMovimentiBancari_TrBan_PP();

			// 4. trovo il mov GP associato.
			dsGestioneBancaria.MovimentiBancariRow movGP = null;
			if (true)
			{
				// non si puo' annullare un perfezionamento se il GP relativo e` gia` partito.
				foreach (dsGestioneBancaria.TrBanRow trbn in trbnList)
				{
					Debug.Assert(trbn.IsIdMovGPNull() == false); // il movimento GP ci deve essere

					if (movGP == null)
						movGP = trbn.MovimentiBancariRowByMovimentiBancari_TrBan_GP;
					else
						Debug.Assert(movGP == trbn.MovimentiBancariRowByMovimentiBancari_TrBan_GP);

					if (movGP.IsTSSottomessoNull() == false)
					{
						return "Non e` possibile cambiare stato al movimento dato che e` stato gia` inviato l'ordine di " +
							"pagamento per la parte coperta";
					}
#if !DEBUG
					break; // in release e` inutile continuare tanto il movimento sara` sempre lo stesso.
#endif

				}
			}

			// cominciamo a smontare i passi fatti in MovPP_Perfezionato.
			foreach (dsGestioneBancaria.TrBanRow trbn in trbnList)
			{
				trbn.SetIdMovGPNull(); // tolgo il mov GP

				dsGestioneBancaria.TransazioniRow trC = trbn.TransazioniRow;
				trC.SetPagabileDaGmeNull();
				trC.SetCausaleNull();
				trC.StatoTransazione = "Non Valida";
			}
			movPP.SetTSPerfezionatoNull();
			movGP.Delete(); // cancello il movimento GP

			df.Update(ds, ref TSUltimaModifica);

			return string.Empty;
		}
		#endregion

		#region IstruzioniDiPagamento
		/// <summary>
		/// Funzione che determina se in questa sessione bisogna ancora generare le istruzioni di pagamento
		/// </summary>
		/// <returns></returns>
		public bool IstruzioniDiPagamento_DaGenerare()
		{
			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
				if (r.TipoReport == "XIP")
					return false;
			return true;
		}

		/// <summary>
		/// Funzione che genera le istruzioni di pagamento.
		/// Non devono essere presenti per questa sessione altr istruzioni di pagamento.
		/// I report generati sono 
		/// a) un XIP: report XML non pubblicabile che riporta tutti i dati necessari alla publlicazione
		/// b) un IP: report che contiene tutte le societa`
		/// c) "n" report uno per societa'
		/// Tutti i report sono memorizzati nel DB.
		/// Tutti hanno la stessa data di crezione.
		/// Tutti non sono ancora pubblicati (solo i report (c) potranno essere pubblicati)
		/// </summary>
		/// <param name="TSCreazione">Data di creazione dei report</param>
		/// <param name="xsltFile">il file XSLT utilizzato per convertire XIP in IP</param>
		/// <returns><code>null</code> se e' andato tutto bene o una stringa di errore</returns>
		public string IstruzioniDiPagamento_Genera(ref DateTime TSUltimaModifica, string xsltFile)
		{
			DateTime TSCreazione = DateTime.Now;

			// controllo se posso generare un XIP
			if (IstruzioniDiPagamento_DaGenerare() == false)
				return "Esiste gia` un'istruzione di pagamento per questa sessione.";

			// colleziono tutti i movimenti privati non sottomessi (della sessione corrente)
			ArrayList ppRows = new ArrayList();
			foreach (dsGestioneBancaria.MovimentiBancariRow m in ds.MovimentiBancari)
				if (m.TipoMovimento == "PP" && m.IsTSSottomessoNull() == true)
					ppRows.Add(m);

			// Versione che genera sempre le XIP (ma soprattuto genera i Report conferme acquisti/vendita.)
			//if (ppRows.Count == 0)
			//	return "Non esistono movimenti privati nella sessione\ndunque non e` necessario generare un ordine di pagamento";

			string xml; // tutto il report XIP
			StringCollection societaAcqList; // le societa` che devono versare soldi tramite movimenti PP
			if (true)
			{
				XmlIstruzioniPagamentoGrouper xg = new XmlIstruzioniPagamentoGrouper(ppRows, sessione, TSCreazione);
				xg.Loop();
				xml = xg.ResultXml;
				societaAcqList = xg.SocietaAcqList;
				xg = null;
			}

			// memorizzo il tutto nel DB

			// a) il report in formato XML ==> XIP
			string IdReportGroup = NewGuid;
			if (true)
			{
				dsGestioneBancaria.ReportCVRow rpXIP = ds.ReportCV.NewReportCVRow();
				rpXIP.IdReport = IdReportGroup;
				rpXIP.IdReportGroup = IdReportGroup;
				rpXIP.TipoReport = "XIP";
				rpXIP.FormatoReport = "xml";
				rpXIP.NomeReport = string.Format(
					"Mercato CV del {0}: Istruzioni di pagamento per tutte le societa`", 
					sessione.DataOraApertura.ToString("d", cultureInfo));
				rpXIP.TSCreazione = TSCreazione;
				rpXIP.SetTSPubblicazioneNull();
				rpXIP.SetTSDownloadNull();
				rpXIP.SetTSInvioNull();
				rpXIP.SetTSRicevutoNull();
				rpXIP.IdSessione = sessione.IdSessione;
				rpXIP.SetIdSocietaNull();
				rpXIP.RawReport = Encoding.UTF8.GetBytes(xml);
				ds.ReportCV.AddReportCVRow(rpXIP);
			}

			// b) i report per societa' in formato HTML ==> IP
			//    e il report sempre in HTML che contiene tutte le societa`
			if (true)
			{
#if DEBUG
				using(StreamWriter ee = new StreamWriter(@"c:\ip.xml"))
				{
					ee.Write(xml);
				}
#endif
				StringReader sr = new StringReader(xml);
				XPathDocument xip = new XPathDocument(sr);

				XslTransform xtr = new XslTransform();
				xtr.Load(xsltFile);

				foreach (dsGestioneBancaria.BudgetsRow budget in ds.Budgets)
				{
					string IdSocieta = budget.SocietaRow.IdSocieta;

					XsltArgumentList xarg = new XsltArgumentList();
					xarg.AddExtensionObject("urn:urnSelectedSocieta", IdSocieta);

					XPathNavigator xnav = xip.CreateNavigator();

					// creo uno stream in memoria
					MemoryStream memoryStream = new MemoryStream();
					// qui creo un writer di stream che scrive nello stream 
					// di default in UTF8 senza preambolo 
					StreamWriter memoryStreamWriter = new StreamWriter(memoryStream);
					// a questo punto la trasformazione scrive nello stream
					xtr.Transform(xnav, xarg, memoryStreamWriter, null);
					memoryStreamWriter.Flush();
					// mi faccio dare il buffer di memoria dello stream e lo converto in stringa
					string xmlSoc = Encoding.UTF8.GetString(memoryStream.ToArray());


					dsGestioneBancaria.ReportCVRow rpIP = ds.ReportCV.NewReportCVRow();
					rpIP.IdReport = NewGuid;
					rpIP.IdReportGroup = IdReportGroup;
					rpIP.TipoReport = "IP";
					rpIP.FormatoReport = "html";
					rpIP.NomeReport = string.Format(
						"Mercato CV del {0}: Istruzioni di pagamento per la societa` {1}", 
						sessione.DataOraApertura.ToString("d", cultureInfo),
						ds.Societa.FindByIdSocieta(IdSocieta).RagioneSociale);
					rpIP.TSCreazione = TSCreazione;
					rpIP.SetTSPubblicazioneNull();
					rpIP.SetTSDownloadNull();
					rpIP.SetTSInvioNull();
					rpIP.SetTSRicevutoNull();
					rpIP.IdSessione = sessione.IdSessione;
					rpIP.IdSocieta = IdSocieta;
					rpIP.RawReport = Encoding.UTF8.GetBytes(xmlSoc);
					ds.ReportCV.AddReportCVRow(rpIP);
				}

				if (true)
				{
					XPathNavigator xnav = xip.CreateNavigator();

					MemoryStream memoryStream = new MemoryStream();
					StreamWriter memoryStreamWriter = new StreamWriter(memoryStream);
					xtr.Transform(xnav, null, memoryStreamWriter, null);
					memoryStreamWriter.Flush();
					string xmlAllSoc = Encoding.UTF8.GetString(memoryStream.ToArray());

					dsGestioneBancaria.ReportCVRow rpIP = ds.ReportCV.NewReportCVRow();
					rpIP.IdReport = NewGuid;
					rpIP.IdReportGroup = IdReportGroup;
					rpIP.TipoReport = "IP";
					rpIP.FormatoReport = "html";
					rpIP.NomeReport = string.Format(
						"Mercato CV del {0}: Istruzioni di pagamento per tutte la societa`", 
						sessione.DataOraApertura.ToString("d", cultureInfo));
					rpIP.TSCreazione = TSCreazione;
					rpIP.SetTSPubblicazioneNull();
					rpIP.SetTSDownloadNull();
					rpIP.SetTSInvioNull();
					rpIP.SetTSRicevutoNull();
					rpIP.IdSessione = sessione.IdSessione;
					rpIP.SetIdSocietaNull();
					rpIP.RawReport = Encoding.UTF8.GetBytes(xmlAllSoc);
					ds.ReportCV.AddReportCVRow(rpIP);
				}
			}

			// TODO generare e salvare in reportCV il Report.Acquisti e Vendite.
			// Attenzione solo il DataSet contiene i dati aggiornati del DB.
			// Il DB potrebbe essere non aggiornato.

			df.Update(ds, ref TSUltimaModifica);


			// generazione dei Report conferme acquisti/vendita.
			if (true)
			{
				BLAdminConferme blConferme = new BLAdminConferme();

				// vendite
				if (true)
				{
					StringWriter sw = new StringWriter();
					blConferme.ConfermeVendite(this.df.Transaction, sw, this.sessione.IdSessione);
					string rcv = sw.GetStringBuilder().ToString();

					dsGestioneBancaria.ReportCVRow rpC = ds.ReportCV.NewReportCVRow();
					rpC.IdReport = NewGuid;
					rpC.IdReportGroup = IdReportGroup;
					rpC.TipoReport = "CV";
					rpC.FormatoReport = "html";
					rpC.NomeReport = string.Format(
						"Mercato CV del {0}: Comferme vendite.", 
						sessione.DataOraApertura.ToString("d", cultureInfo));
					rpC.TSCreazione = TSCreazione;
					rpC.SetTSPubblicazioneNull();
					rpC.SetTSDownloadNull();
					rpC.SetTSInvioNull();
					rpC.SetTSRicevutoNull();
					rpC.IdSessione = sessione.IdSessione;
					rpC.SetIdSocietaNull();
					rpC.RawReport = Encoding.UTF8.GetBytes(rcv);
					ds.ReportCV.AddReportCVRow(rpC);
					df.Update(ds, ref TSUltimaModifica);
				}

				foreach (dsGestioneBancaria.BudgetsRow budget in ds.Budgets)
				{
					string IdSocieta = budget.SocietaRow.IdSocieta;

					StringWriter sw = new StringWriter();
					blConferme.ConfermeVendite(this.df.Transaction, sw, this.sessione.IdSessione, IdSocieta);
					string rcv = sw.GetStringBuilder().ToString();

					dsGestioneBancaria.ReportCVRow rpC = ds.ReportCV.NewReportCVRow();
					rpC.IdReport = NewGuid;
					rpC.IdReportGroup = IdReportGroup;
					rpC.TipoReport = "CV";
					rpC.FormatoReport = "html";
					rpC.NomeReport = string.Format(
						"Mercato CV del {0}: Comferme vendita per la societa` {1}", 
						sessione.DataOraApertura.ToString("d", cultureInfo),
						budget.SocietaRow.RagioneSociale);
					rpC.TSCreazione = TSCreazione;
					rpC.SetTSPubblicazioneNull();
					rpC.SetTSDownloadNull();
					rpC.SetTSInvioNull();
					rpC.SetTSRicevutoNull();
					rpC.IdSessione = sessione.IdSessione;
					rpC.IdSocieta = IdSocieta;
					rpC.RawReport = Encoding.UTF8.GetBytes(rcv);
					ds.ReportCV.AddReportCVRow(rpC);
					df.Update(ds, ref TSUltimaModifica);
				}


				// Acquisti
				if (true)
				{
					StringWriter sw = new StringWriter();
					blConferme.ConfermeAcquisti(this.df.Transaction, sw, this.sessione.IdSessione);
					string rcv = sw.GetStringBuilder().ToString();

					dsGestioneBancaria.ReportCVRow rpC = ds.ReportCV.NewReportCVRow();
					rpC.IdReport = NewGuid;
					rpC.IdReportGroup = IdReportGroup;
					rpC.TipoReport = "CA";
					rpC.FormatoReport = "html";
					rpC.NomeReport = string.Format(
						"Mercato CV del {0}: Comferme acquisti.", sessione.DataOraApertura.ToString("d", cultureInfo));
					rpC.TSCreazione = TSCreazione;
					rpC.SetTSPubblicazioneNull();
					rpC.SetTSDownloadNull();
					rpC.SetTSInvioNull();
					rpC.SetTSRicevutoNull();
					rpC.IdSessione = sessione.IdSessione;
					rpC.SetIdSocietaNull();
					rpC.RawReport = Encoding.UTF8.GetBytes(rcv);
					ds.ReportCV.AddReportCVRow(rpC);
					df.Update(ds, ref TSUltimaModifica);
				}

				foreach (dsGestioneBancaria.BudgetsRow budget in ds.Budgets)
				{
					string IdSocieta = budget.SocietaRow.IdSocieta;

					StringWriter sw = new StringWriter();
					blConferme.ConfermeAcquisti(this.df.Transaction, sw, this.sessione.IdSessione, IdSocieta);
					string rcv = sw.GetStringBuilder().ToString();

					dsGestioneBancaria.ReportCVRow rpC = ds.ReportCV.NewReportCVRow();
					rpC.IdReport = NewGuid;
					rpC.IdReportGroup = IdReportGroup;
					rpC.TipoReport = "CA";
					rpC.FormatoReport = "html";
					rpC.NomeReport = string.Format(
						"Mercato CV del {0}: Comferme acquisti per la societa` {1}", 
						sessione.DataOraApertura.ToString("d", cultureInfo),
						budget.SocietaRow.RagioneSociale);
					rpC.TSCreazione = TSCreazione;
					rpC.SetTSPubblicazioneNull();
					rpC.SetTSDownloadNull();
					rpC.SetTSInvioNull();
					rpC.SetTSRicevutoNull();
					rpC.IdSessione = sessione.IdSessione;
					rpC.IdSocieta = IdSocieta;
					rpC.RawReport = Encoding.UTF8.GetBytes(rcv);
					ds.ReportCV.AddReportCVRow(rpC);
					df.Update(ds, ref TSUltimaModifica);
				}


			}

			return string.Empty;
		}
		public class XmlIstruzioniPagamentoGrouper : CollectionGrouper
		{
			public XmlIstruzioniPagamentoGrouper(ArrayList ar, dsGestioneBancaria.SessioniRow sessione, DateTime TSCreazione)
				: base(ar)
			{
				this.sessione = sessione;
				this.TSCreazione = TSCreazione;
			}

			readonly dsGestioneBancaria.SessioniRow sessione;
			readonly DateTime TSCreazione;
			readonly StringCollection IdSocietaAcqList = new StringCollection();

			MemoryStream memoryStream = null;  // lo stream in cui si scrive in UTF8
			XmlTextWriter x = null;

			public string ResultXml { get { return Encoding.UTF8.GetString(Result); } }
			public byte [] Result { get { return memoryStream.ToArray(); } }
			public StringCollection SocietaAcqList { get { return IdSocietaAcqList; } }


			public override void OnStartLoop()
			{
				memoryStream = new MemoryStream();
				StreamWriter memoryStreamWriter = new StreamWriter(memoryStream);
				//x = new XmlTextWriter(memoryStream, null); 
				x = new XmlTextWriter(memoryStreamWriter); 

				x.Formatting = Formatting.Indented;
				x.WriteStartDocument();
				x.WriteStartElement("IstruzioniDiPagamento");

				// questa data sara' la data di creazione anche per gli altri documenti IP.
				x.WriteAttributeString("TSCreazione", XmlConvert.ToString(TSCreazione));

				x.WriteStartElement("Sessione");
				x.WriteAttributeString("IdSessione", sessione.IdSessione);
				x.WriteAttributeString("Titolo", sessione.Titolo);
				x.WriteAttributeString("DataOraApertura", XmlConvert.ToString(sessione.DataOraApertura));
				x.WriteAttributeString("DataOraChiusura", XmlConvert.ToString(sessione.DataOraChiusura));
				x.WriteEndElement();
			}

			public override int Compare(object a, object b)
			{
				// soliti confronti necessari per Compare
				if (a == null && b == null) return 0;
				if (a != null && b == null) return 1;
				if (a == null && b != null) return -1;

				dsGestioneBancaria.MovimentiBancariRow ma = (dsGestioneBancaria.MovimentiBancariRow)a;
				dsGestioneBancaria.MovimentiBancariRow mb = (dsGestioneBancaria.MovimentiBancariRow)b;

				int c = string.Compare(ma.IdSocietaSrc, mb.IdSocietaSrc);
				if (c != 0)
					return c;
				return string.Compare(ma.IdSocietaDst, mb.IdSocietaDst);
			}

			public override bool CheckBreak(object prev_item, object current_item)
			{
				dsGestioneBancaria.MovimentiBancariRow prev_mov    = (dsGestioneBancaria.MovimentiBancariRow)prev_item;
				dsGestioneBancaria.MovimentiBancariRow current_mov = (dsGestioneBancaria.MovimentiBancariRow)current_item;
				return prev_mov.IdSocietaSrc != current_mov.IdSocietaSrc;
			}
			public override void OnFirstItem(object item)
			{
				dsGestioneBancaria.MovimentiBancariRow mov = (dsGestioneBancaria.MovimentiBancariRow)item;

				x.WriteStartElement("IstruzioneDiPagamento");
				x.WriteAttributeString("IdSocietaAcq", mov.IdSocietaSrc);

				dsGestioneBancaria.SocietaRow societaAcq = mov.SocietaRowBySocietaMovimentiBancariSrc;
				//				x.WriteAttributeString("RagioneSociale", societaAcq.RagioneSociale);
				//				x.WriteAttributeString("CodiceConto", societaAcq.CodiceConto);
				XmlSocietaWriter(x, null, societaAcq); // scrivo gli attributi nel nodo x della societa acq

				IdSocietaAcqList.Add(societaAcq.IdSocieta);
			}
			public override void OnItem(object item)
			{
				dsGestioneBancaria.MovimentiBancariRow mov = (dsGestioneBancaria.MovimentiBancariRow)item;

				x.WriteStartElement("Movimento");
				if (true)
				{
					x.WriteAttributeString("IdMovimento", mov.IdMovimentoBancario);
					x.WriteAttributeString("Importo", XmlConvert.ToString(mov.Importo));
					x.WriteAttributeString("Causale", mov.Causale);
					x.WriteAttributeString("Valuta", XmlConvert.ToString(mov.Valuta, "yyyy-MM-dd"));

					dsGestioneBancaria.SocietaRow societaVnd = mov.SocietaRowBySocietaMovimentiBancariDst;

					XmlSocietaWriter(x, null, societaVnd);
				}

				x.WriteEndElement();
			}
			public override void OnLastItem(object item)
			{
				x.WriteEndElement();
			}
			public override void OnEndLoop()
			{
				x.WriteEndElement(); // IstruzioneDiPagamento
				x.WriteEndDocument();
				x.Flush();
				x.Close();

				// memoryStreamWriter.Flush();
			}
		}



		public enum IP_Status
		{
			NonEsiste,
			EsisteDaPubblicare,
			EsisteGiaPubblicata
		}
		/// <summary>
		/// Ritorna true se ci sono istruzioni di pagamento gia` generate e pronte per essere pubblicate
		/// </summary>
		/// <returns></returns>
		public IP_Status IstruzioniDiPagamento_GetStatus()
		{
#if DEBUG
			if (true)
			{
				int n = 0;
				foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
					if (r.TipoReport == "XIP") n++;
				Debug.Assert(n <= 1);
				if (n > 1)
					throw new ApplicationException("Ci sono piu' di 1 XIP per la sessione");
			}
#endif

			string IdReportGroup = null;

			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
			{
				if (r.TipoReport == "XIP")
				{
					IdReportGroup = r.IdReportGroup;
					break;
				}
			}

			if (IdReportGroup == null)
				return IP_Status.NonEsiste;

			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
			{
				if (r.TipoReport == "IP" && r.IdReportGroup == IdReportGroup && r.IsIdSocietaNull() == false)
				{
					if (r.IsTSPubblicazioneNull() == true)
						return IP_Status.EsisteDaPubblicare;

					// esiste ma e` gia` pubblicato.
					return IP_Status.EsisteGiaPubblicata;
				}
			}

			// non esiste proprio
			return IP_Status.NonEsiste;
		}

		public string IstruzioniDiPagamento_Visualizza(string TipoReport)
		{
			IP_Status ips = IstruzioniDiPagamento_GetStatus();
			if (ips == IP_Status.NonEsiste)
				return null;

			// trovo il report 
			foreach (dsGestioneBancaria.ReportCVRow ip in ds.ReportCV)
				if (ip.TipoReport == TipoReport && ip.IsIdSocietaNull())
					return Encoding.UTF8.GetString(ip.RawReport);

			return null;
		}

		/// <summary>
		/// Pubblica le istruzioni di pagamento precedentemente generate.
		/// </summary>
		/// <param name="TSPubblicazione"></param>
		/// <returns></returns>
		public string IstruzioniDiPagamento_Pubblica(ref DateTime TSUltimaModifica)
		{
			DateTime TSPubblicazione = DateTime.Now;

			IP_Status ips = IstruzioniDiPagamento_GetStatus();
			if (ips == IP_Status.EsisteGiaPubblicata)
			{
				return "Le istruzioni di pagamento sono state gia` pubblicate.";
			}
			else if (ips == IP_Status.NonEsiste)
			{
				return "Non esiste un istruzione di pagamento da pubblicare per questa sessione.";
			}
			else if (ips != IP_Status.EsisteDaPubblicare)
			{
				Debug.Assert(false);
				return ips.ToString();
			}

			// trovo il report XIP
			dsGestioneBancaria.ReportCVRow xipReport = null;
			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
			{
				if (r.TipoReport == "XIP")
				{
					xipReport = r;
					break;
				}
			}
			Debug.Assert(xipReport != null);
			if (xipReport == null)
				return "Non esiste un istruzione di pagamento da pubblicare per questa sessione.";

			// scrivo la data di pubblicazione per i report IP con la stessa data di pubblicazione
			foreach (dsGestioneBancaria.ReportCVRow ip in ds.ReportCV)
			{
				if ((ip.TipoReport == "IP"||ip.TipoReport == "CA"||ip.TipoReport == "CV") && ip.IdReportGroup == xipReport.IdReportGroup)
				{
					// solo i report per societa' devono essere pubblicati
					if (ip.IsIdSocietaNull() == false)
						ip.TSPubblicazione = TSPubblicazione; // qui li "pubblico"
				}
			}

			// apro xip (ossia l'xml padre di tutti i documenti) e leggo tutti i movimenti 
			// per aggiornare la tabella dei MovimentiCV
			if (true)
			{
				string xml = Encoding.UTF8.GetString(xipReport.RawReport);
				using (StringReader sr = new StringReader(xml))
				{
					XmlTextReader xr = new XmlTextReader(sr);
					while (xr.Read())
					{
						if (xr.NodeType == XmlNodeType.Element && xr.Name == "Movimento")
						{
							// aggiorno la data di sottomissione
							string IdMovimento = xr.GetAttribute("IdMovimento");

							dsGestioneBancaria.MovimentiBancariRow mov;
							mov = ds.MovimentiBancari.FindByIdMovimentoBancario(IdMovimento);

							Debug.Assert(mov.TipoMovimento == "PP");
							Debug.Assert(mov.IsTSSottomessoNull() == true);

							mov.TSSottomesso = TSPubblicazione;
						}
					}
					xr.Close();
					sr.Close();
				}
			}


			df.Update(ds, ref TSUltimaModifica);
			return string.Empty;
		}

		/// <summary>
		/// Cancella l'ultima istruzione di pagamento generata se
		/// a) non e' ancora pubblicata oppure
		/// b) se e' pubblicata ma non ancora downloadata
		/// </summary>
		/// <returns></returns>
		public DataSet IstruzioniDiPagamento_CancellaUltimo(ref DateTime TSUltimaModifica, out string msg)
		{
			msg = string.Empty;

			// posso cancellare gli IP/XIP purche` 
			// a) non siano gia' stati pubblicati
			// b) OPPURE non siano gia' stati downlodati
			// c) OPPURE non sia stato gia` perfezionato qualche movimento

			// NB. Il fatto che le IP NON siano state scaricate non
			// implica che qualche transazione possa andare in stato perfezionato
			// (es. le IP le hanno spedite via mail).
			// Se pero` le IP sono state downlodate, la cancellazione e' proibita
			// perche` solo la societa` puo` averlo fatto.

			// trovo il report XIP
			dsGestioneBancaria.ReportCVRow xipReport = null;
			if (true)
			{
				foreach (dsGestioneBancaria.ReportCVRow rp in ds.ReportCV)
				{
					if (rp.TipoReport == "XIP")
					{
						xipReport = rp;
						break;
					}
				}
				if (xipReport == null)
				{
					msg = "Non ci sono istruzioni di pagamento da cancellare";
					return this.CreateClientDataSet(ref TSUltimaModifica);
				}
			}

			// giro su tutti i report IP per capire se sono stati pubblicati e se si se sono stati downlodati
			bool pubblicati = false;
			bool downloadati = false;
			foreach (dsGestioneBancaria.ReportCVRow ipReport in ds.ReportCV)
			{
				if ((ipReport.TipoReport == "IP" || ipReport.TipoReport == "CV" || ipReport.TipoReport == "CA")&&
					ipReport.IdReportGroup == xipReport.IdReportGroup &&
					ipReport.IsIdSocietaNull() == false)
				{
					// sono report IP per societa`

					if (ipReport.IsTSPubblicazioneNull() == false)
						pubblicati = true;

					if (ipReport.IsTSDownloadNull() == false)
						downloadati = true;
				}
			}

			if (pubblicati == true && downloadati == true)
			{
				msg = "Non e` possibile cancellare le istruzioni di pagamento in quanto una o piu` societa`" +
					" hanno gia` scaricato le stesse dal sito Web";
				return this.CreateClientDataSet(ref TSUltimaModifica);
			}


			// se esiste un movimento PP perfezionato
			// esco con errore.
			if (true)
			{
				string xml = Encoding.UTF8.GetString(xipReport.RawReport);
				using(StringReader sr = new StringReader(xml))
				{
					XmlTextReader xr = new XmlTextReader(sr);
					while (xr.Read())
					{
						if (xr.NodeType == XmlNodeType.Element && xr.Name == "Movimento")
						{
							// aggiorno la data di sottomissione a NULL
							string IdMovimento = xr.GetAttribute("IdMovimento");

							dsGestioneBancaria.MovimentiBancariRow movPP;

							movPP = ds.MovimentiBancari.FindByIdMovimentoBancario(IdMovimento);
							Debug.Assert(movPP.TipoMovimento == "PP");

							if (movPP.IsTSPerfezionatoNull() == false)
							{
								xr.Close();
								sr.Close();

								msg = "Non e` possibile cancellare le istruzioni di pagamento in quanto\n" +
									" sono stati gia` perfezionati uno o piu` movimenti";
								return this.CreateClientDataSet(ref TSUltimaModifica);
							}
						}
					}
					xr.Close();
					sr.Close();
				}
			}

			// da qui in poi modifico il DB

			// finalmente aggiorno lo stato dei movimenti
			if (true)
			{
				string xml = Encoding.UTF8.GetString(xipReport.RawReport);
				using(StringReader sr = new StringReader(xml))
				{
					XmlTextReader xr = new XmlTextReader(sr);
					while (xr.Read())
					{
						if (xr.NodeType == XmlNodeType.Element && xr.Name == "Movimento")
						{
							// aggiorno la data di sottomissione a NULL
							string IdMovimento = xr.GetAttribute("IdMovimento");

							dsGestioneBancaria.MovimentiBancariRow movPP;

							movPP = ds.MovimentiBancari.FindByIdMovimentoBancario(IdMovimento);
							Debug.Assert(movPP.TipoMovimento == "PP");
							movPP.SetTSSottomessoNull();
						}
					}
					xr.Close();
					sr.Close();
				}
			}

			// cancello i tutti i report coinvolti (XIP e IP e CA,CV) dal DB
			if (true)
			{
				string IdReportGroup = xipReport.IdReportGroup;

				foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
					if (r.IdReportGroup == IdReportGroup)
						r.Delete();
			}


			df.Update(ds, ref TSUltimaModifica);

			msg = string.Empty;
			return this.CreateClientDataSet(ref TSUltimaModifica);
		}
		#endregion

		#region OrdinePagamentoSanPaolo
		public DataSet OrdinePagamentoSanPaolo_Lista_SP_CBISP()
		{
			DataSet dsSP = new DataSet();
			DataTable dtSP = dsSP.Tables.Add("ListaSP");

			dtSP.Columns.Add("IDReport",    typeof(string)).AllowDBNull = false;
			dtSP.Columns.Add("NomeReport",  typeof(string)).AllowDBNull = false;
			dtSP.Columns.Add("TSCreazione", typeof(DateTime)).AllowDBNull = false;
			dtSP.Columns.Add("TSInvio",     typeof(DateTime)).AllowDBNull = true;
			dtSP.Columns.Add("TipoReport",  typeof(string)).AllowDBNull = false;
			
			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
			{
				if (r.TipoReport == "SP" || r.TipoReport == "CBISP")
				{
					DataRow sp = dtSP.NewRow();
					sp["IDReport"] = r.IdReport;
					sp["NomeReport"] = r.NomeReport;
					sp["TSCreazione"] = r.TSCreazione;
					if (r.IsTSInvioNull())
						sp["TSInvio"] = System.Convert.DBNull;
					else
						sp["TSInvio"] = r.TSInvio;
					sp["TipoReport"] = r.TipoReport;
					dtSP.Rows.Add(sp);
				}
			}
			return dsSP;
		}
		private dsGestioneBancaria.ReportCVRow OrdinePagamentoSanPaolo_TrovaUltimoXSP()
		{
			dsGestioneBancaria.ReportCVRow rLast = null;
			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
			{
				if (r.TipoReport == "XSP")
				{
					if (rLast == null)
						rLast = r;
					else if (r.TSCreazione > rLast.TSCreazione)
						rLast = r;
				}
			}
			return rLast;
		}
		private dsGestioneBancaria.ReportCVRow OrdinePagamentoSanPaolo_TrovaUltimoCBI()
		{
			dsGestioneBancaria.ReportCVRow xsp = OrdinePagamentoSanPaolo_TrovaUltimoXSP();
			if (xsp == null)
				return null;

			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
				if (r.TipoReport == "CBISP" && xsp.IdReportGroup == r.IdReportGroup)
					return r;
			return null;
		}

		private dsGestioneBancaria.ReportCVRow OrdinePagamentoSanPaolo_TrovaUltimoSP()
		{
			dsGestioneBancaria.ReportCVRow xsp = OrdinePagamentoSanPaolo_TrovaUltimoXSP();
			if (xsp == null)
				return null;

			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
				if (r.TipoReport == "SP" && xsp.IdReportGroup == r.IdReportGroup)
					return r;
			return null;
		}

		private bool OrdinePagamentoSanPaolo_EsisteUltimoDaValidareInviare()
		{
			dsGestioneBancaria.ReportCVRow cbi = OrdinePagamentoSanPaolo_TrovaUltimoCBI();
			if (cbi == null)
				return false;
			if (cbi.IsTSInvioNull() == true)
				return true;
			return false;
		}
		public string OrdinePagamentoSanPaolo_CBI_DaInviare(out DateTime TSCreazione)
		{
			TSCreazione = DateTime.MinValue;
			dsGestioneBancaria.ReportCVRow cbi = OrdinePagamentoSanPaolo_TrovaUltimoCBI();
			if (cbi == null)
				return null;
			if (cbi.IsTSInvioNull() == false)
				return null;

			TSCreazione = cbi.TSCreazione;
			return Encoding.ASCII.GetString(cbi.RawReport);
		}
		public string OrdinePagamentoSanPaolo_SP_DaValidare()
		{
			dsGestioneBancaria.ReportCVRow cbi = OrdinePagamentoSanPaolo_TrovaUltimoCBI();
			if (cbi == null)
				return null;
			if (cbi.IsTSInvioNull() == false)
				return null;

			dsGestioneBancaria.ReportCVRow sp = OrdinePagamentoSanPaolo_TrovaUltimoSP();
			Debug.Assert(sp != null);
			if (sp == null) return null;
			return Encoding.UTF8.GetString(sp.RawReport);
		}

		public string OrdinePagamentoSanPaolo_VisualizzaUltimoSP()
		{
			dsGestioneBancaria.ReportCVRow sp = OrdinePagamentoSanPaolo_TrovaUltimoSP();
			if (sp == null)
				return null;

			return Encoding.UTF8.GetString(sp.RawReport);
		}
		public string OrdinePagamentoSanPaolo_Visualizza(string IdReport)
		{
			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
				if (r.IdReport == IdReport)
					return Encoding.UTF8.GetString(r.RawReport);

			return null;
		}

		class OrdinaPerSocAcqSocVnd : IComparer
		{
			#region IComparer Members

			public int Compare(object a, object b)
			{
				// soliti confronti necessari per Compare
				if (a == null && b == null) return 0;
				if (a != null && b == null) return 1;
				if (a == null && b != null) return -1;

				dsGestioneBancaria.MovimentiBancariRow ma = (dsGestioneBancaria.MovimentiBancariRow)a;
				dsGestioneBancaria.MovimentiBancariRow mb = (dsGestioneBancaria.MovimentiBancariRow)b;

				int c = string.Compare(ma.IdSocietaSrc, mb.IdSocietaSrc);
				if (c != 0)
					return c;
				return string.Compare(ma.IdSocietaDst, mb.IdSocietaDst);
			}

			#endregion
		}

		public class CBIGrouper : CollectionGrouper
		{
			public CBIGrouper(ArrayList ar, CBIWriter cbiWriter)
				: base(ar)
			{
				_cbiWriter = cbiWriter;
			}

			// dati costanti
			readonly CBIWriter _cbiWriter;

			// dati per il raggruppamento
			CBI.CBIDisposizione _a;

			public override void OnStartLoop()
			{
			}

			public override int Compare(object a, object b)
			{
				// soliti confronti necessari per Compare
				if (a == null && b == null) return 0;
				if (a != null && b == null) return 1;
				if (a == null && b != null) return -1;

				CBI.CBIDisposizione ma = (CBI.CBIDisposizione)a;
				CBI.CBIDisposizione mb = (CBI.CBIDisposizione)b;

				// ordino per destrinatario/causale
				int c;
				c = string.Compare(ma._10_abi_destinatario, mb._10_abi_destinatario);
				if (c != 0) return c;

				c = string.Compare(ma._10_cab_destinatario, mb._10_cab_destinatario);
				if (c != 0) return c;

				c = string.Compare(ma._10_cc_destinatario, mb._10_cc_destinatario);
				if (c != 0) return c;

				// a parita` di destinatario per causale
				return string.Compare(ma._50_causale, mb._50_causale);
			}

			public override bool CheckBreak(object a, object b)
			{
				CBI.CBIDisposizione ma = (CBI.CBIDisposizione)a;
				CBI.CBIDisposizione mb = (CBI.CBIDisposizione)b;

				if (ma._10_abi_destinatario != mb._10_abi_destinatario) return true;
				if (ma._10_cab_destinatario != mb._10_cab_destinatario) return true;
				if (ma._10_cc_destinatario  != mb._10_cc_destinatario ) return true;

				// qui posso fare il raggruppamento

				// raggruppo i pagamenti CV
				// Attenzione qui dipende da quello che e` stato scritto in causale!!!
				// Dunque: 
				// a) le penali sono raggruppate
				// b) la restituzione residuo e` sempre 1 per sessione --> non si raggruppa
				// c) il pagamento CV e` raggruppato
				// Queste causali sono raggruppate!
				// "MCV {0}: Pagamento CV."
				// "MCV {0}: Pagamento CV quota non coperta."
				// "MCV {0}: Pagamento CV quota coperta."
				// --> la parte comune e` "Pagamento CV"
				if (ma._50_causale.IndexOf("Pagamento CV") >= 0 &&
					mb._50_causale.IndexOf("Pagamento CV") >= 0)
					return false;

				return ma._50_causale != mb._50_causale;

			}
			public override void OnFirstItem(object item)
			{
				_a = (CBI.CBIDisposizione)item;

				// la causale potrebbe essere 
				// "MCV {0}: Pagamento CV."
				// "MCV {0}: Pagamento CV quota non coperta."
				// "MCV {0}: Pagamento CV quota coperta."
				// In questi tre casi la riduco a 
				// "MCV {0}: Pagamento CV."

				// Attenzione non posso scrive un'altra causale diversa dalla
				// "MCV {0}: Pagamento CV." perche altrimenti non si raggruppa
				int p = _a._50_causale.IndexOf("Pagamento CV");
				if (p >= 0)
					_a._50_causale = _a._50_causale.Substring(0, p) + "Pagamento CV.";
			}
			public override void OnItem(object item)
			{
				CBI.CBIDisposizione disposizione = (CBI.CBIDisposizione)item;

				if (_a != disposizione)
					_a._10_importo += disposizione._10_importo; 
			}
			public override void OnLastItem(object item)
			{
//				CBI.CBIDisposizione a = (CBI.CBIDisposizione)item;
//				_cbiWriter.ScriviDisposizione(a);
				_cbiWriter.ScriviDisposizione(_a);
			}
			public override void OnEndLoop()
			{
			}
		}



		public string OrdinePagamentoSanPaolo_CreaNuovo(ref DateTime TSUltimaModifica, string xsltFile)
		{
			DateTime TSCreazione = DateTime.Now;

			// string xml = null;
			int numeroMovimenti = 0;

			// controllo se esiste un precedente ordine di pagamento non inviato.
			// Se si bisogna
			// a) inviarlo al san paolo prima di generne un altro
			// b) cancellarlo, in modo che il prossimo GeneraOrdinePagamentoSanPaolo contenga tutti i movimenti comandato nel cancellato
			if (OrdinePagamentoSanPaolo_EsisteUltimoDaValidareInviare())
				return "Non e` possibile generare un ordine di pagamento quando esiste un precedente ordine non inviato";

			// per evitare problemi controllo che i dati necessari al CBI ci siano 
			// e se si siano il formato corretto.
			if (true)
			{
				foreach (dsGestioneBancaria.MovimentiBancariRow m in ds.MovimentiBancari)
				{
					if (m.TipoMovimento == "GP" && m.IsTSSottomessoNull() == true)
					{
						dsGestioneBancaria.SocietaRow socDst = m.SocietaRowBySocietaMovimentiBancariDst;

						if (true)
						{
							string abi = socDst.ABI;
							if (abi.Length > 5)
								return string.Format("La societa` {0} ha un codice ABI di lunghezza errata", socDst.RagioneSociale);
							foreach (char c in abi)
								if (c < '0' || c > '9')
									return string.Format("La societa` {0} ha un codice ABI che non contiene solo numeri", socDst.RagioneSociale);
						}

						if (true)
						{
							string cab = socDst.CAB;
							if (cab.Length > 5)
								return string.Format("La societa` {0} ha un codice CAB di lunghezza errata", socDst.RagioneSociale);
							foreach (char c in cab)
								if (c < '0' || c > '9')
									return string.Format("La societa` {0} ha un codice CAB che non contiene solo numeri", socDst.RagioneSociale);
						}

					}
				}
			}

			// calcolo i residui per le societa che non hanno pendenze
			// qui si possono aggiungere movimenti GP
			// Residui_Calcola(TSValutaResidui, false);
			// NOTA BENE non si fa piu' qui.... lo si fa in maniera esplicita con un bottone.
			
			// cerco tutti i movimenti di tipo GP con TSSottomesso NULL
			// ordinati per IdSocietaSrc, IdSocietaDst
			// notare che ci possono essere piu` movimenti GP non sottomessi tra 2 societa`.
			dsGestioneBancaria.MovimentiBancariRow [] gpRows;
			if (true)
			{
				ArrayList ar = new ArrayList();
				if (true)
				{
					foreach (dsGestioneBancaria.MovimentiBancariRow m in ds.MovimentiBancari)
						if (m.TipoMovimento == "GP" && m.IsTSSottomessoNull() == true)
							ar.Add(m);

					ar.Sort(new OrdinaPerSocAcqSocVnd());
				}

				if (ar.Count > 0)
				{
					numeroMovimenti = ar.Count;
					gpRows = new dsGestioneBancaria.MovimentiBancariRow[numeroMovimenti];
					for (int n = 0; n < ar.Count; ++n)
						gpRows[n] = (dsGestioneBancaria.MovimentiBancariRow)(ar[n]);
				}
				else
				{
					numeroMovimenti = 0;
					return "Non esistono movimenti GP non sottomessi da inviare al San Paolo";
				}
			}


		
			// da questi costruisco il file dei pagamenti.
			// genero un file XML che POI dovra' essere tradotto in CBI o XML per sanpaolo.
			// Questo file verra' salvato in ReportCV in modo 
			// che in seguito il BackOffice lo valida e lo invia --> TSInviato assegnato

			string xml = null;
			string IdReportGroup = NewGuid;
			if (true)
			{
				MemoryStream memoryStream = new MemoryStream();
				XmlTextWriter x = new XmlTextWriter(memoryStream, null); 
				x.Formatting = Formatting.Indented;
				x.WriteStartDocument();
				x.WriteStartElement("OrdiniDiPagamento");

				// questa data sara' la data di creazione del report.
				x.WriteAttributeString("TSCreazione", XmlConvert.ToString(TSCreazione));

				// come al solito un preambolo sulla sessione.
				x.WriteStartElement("Sessione");
				x.WriteAttributeString("IdSessione", sessione.IdSessione);
				x.WriteAttributeString("Titolo", sessione.Titolo);
				x.WriteAttributeString("DataOraApertura", XmlConvert.ToString(sessione.DataOraApertura));
				x.WriteAttributeString("DataOraChiusura", XmlConvert.ToString(sessione.DataOraChiusura));
				x.WriteEndElement(); // Sessione

				// Loop per i movimenti da ordinare al San Paolo.
				foreach (dsGestioneBancaria.MovimentiBancariRow mov in gpRows)
				{
					x.WriteStartElement("Movimento");
					if (true)
					{
						string strValuta = XmlConvert.ToString(mov.Valuta, "yyyy-MM-dd");

						x.WriteElementString("IdMovimento",        mov.IdMovimentoBancario);
						x.WriteElementString("Importo",            XmlConvert.ToString(mov.Importo));
						x.WriteElementString("Valuta",             strValuta);
						x.WriteElementString("Causale",            mov.Causale);

						XmlSocietaWriter(x, "SocietaSrc",   mov.SocietaRowBySocietaMovimentiBancariSrc);
						XmlSocietaWriter(x, "SocietaDst",   mov.SocietaRowBySocietaMovimentiBancariDst);
					}
					x.WriteEndElement();
				}

				x.WriteEndElement(); // OrdiniDiPagamento
				x.WriteEndDocument();
				x.Flush();
				x.Close();

				// qui ho l'xml finale.
				xml = Encoding.UTF8.GetString(memoryStream.ToArray()); 
#if DEBUG
				if (true)
				{
					FileStream fs = File.Create(@"c:\xsp.xml");
					using (StreamWriter sw = new StreamWriter(fs))
					{
						sw.Write(xml);
					}
					fs.Close();
				}
#endif

				// qui lo salvo nel DB
				dsGestioneBancaria.ReportCVRow rpXSP = ds.ReportCV.NewReportCVRow();
				rpXSP.IdReport = IdReportGroup;
				rpXSP.IdReportGroup = IdReportGroup;
				rpXSP.TipoReport = "XSP";
				rpXSP.FormatoReport = "xml";
				rpXSP.NomeReport = "Ordine di pagamento";
				rpXSP.NomeReport = string.Format(
					"Mercato CV del {0}: Ordine di pagamento emesso il {1}", 
					sessione.DataOraApertura.ToString("d", cultureInfo),
					TSCreazione.ToString("G", cultureInfo));
				rpXSP.TSCreazione = TSCreazione;
				rpXSP.SetTSPubblicazioneNull();
				rpXSP.SetTSDownloadNull();
				rpXSP.SetTSInvioNull();
				rpXSP.SetTSRicevutoNull();
				rpXSP.IdSessione = sessione.IdSessione;
				rpXSP.SetIdSocietaNull();
				rpXSP.RawReport = Encoding.UTF8.GetBytes(xml);
				ds.ReportCV.AddReportCVRow(rpXSP);
			}

			// qui genero il CBI per il San Paolo.
			if (true)
			{
				// roba per leggere.
				XmlDocument xmlOP = new XmlDocument();
				xmlOP.LoadXml(xml);

				// roba per scrivere.
				CBIWriter cbiWriter = new CBIWriter(); // CBIWrite scrive in ASCII

				CBIHeader cbiHeader = new CBIHeader();
				cbiHeader._PC_mittente       = ConfigurationSettings.AppSettings["CBIWriter.PC.mittente"]; // 8R698
				cbiHeader._PC_ricevente      = ConfigurationSettings.AppSettings["CBIWriter.PC.ricevente"]; // 01025
				cbiHeader._PC_data_creazione = TSCreazione;
				cbiHeader._PC_nome_supporto  = IdReportGroup;
				cbiHeader._PC_campo_a_disposizione = null;

				StringWriter sw = new StringWriter();
				cbiWriter.Open(sw, cbiHeader);

				bool bAccorpaMovimentiCBI = true;
				if (bAccorpaMovimentiCBI == false)
				{
					// Versione originale: tanti movimenti CBI quanti sono i movimenti nell'XML

					XmlNodeList xmlMovimenti = xmlOP.SelectNodes("//Movimento");
					foreach (XmlNode xmlMovimento in xmlMovimenti)
					{
						CBIDisposizione disposizione = new CBIDisposizione();

						XmlNode socSrc = xmlMovimento.SelectSingleNode("./SocietaSrc");
						XmlNode socDst = xmlMovimento.SelectSingleNode("./SocietaDst");

						string importo  = xmlMovimento.SelectSingleNode("./Importo").InnerText;
						string valuta   = xmlMovimento.SelectSingleNode("./Valuta").InnerText;
						string causale  = xmlMovimento.SelectSingleNode("./Causale").InnerText;

						disposizione._10_data_esecuzione_disposizione = DateTime.MinValue; // e` come null
						disposizione._10_data_valuta_beneficiario     = XmlConvert.ToDateTime(valuta);
						disposizione._10_importo                      = XmlConvert.ToDecimal(importo);
						disposizione._10_abi_ordinante                = ConfigurationSettings.AppSettings["CBIWriter.10.Ordinante.ABI"]; // 01025
						disposizione._10_cab_ordinante                = ConfigurationSettings.AppSettings["CBIWriter.10.Ordinante.CAB"]; // 03236
						disposizione._10_cc_ordinante                 = ConfigurationSettings.AppSettings["CBIWriter.10.Ordinante.CC"]; // 100000002087
						disposizione._10_abi_destinatario             = socDst.Attributes["ABI"].Value;
						disposizione._10_cab_destinatario             = socDst.Attributes["CAB"].Value;
						disposizione._10_cc_destinatario              = socDst.Attributes["CC"].Value;
						disposizione._10_codice_azienda               = ConfigurationSettings.AppSettings["CBIWriter.PC.mittente"];

						// la ragione sociale la TRONCO
						disposizione._20_ragione_sociale_ordinante    = ConfigurationSettings.AppSettings["CBIWriter.20.Ordinante.RagioneSociale"]; // "GESTORE DEL MERCATO ELETTRICO"
						if (disposizione._20_ragione_sociale_ordinante.Length > 90)
							disposizione._20_ragione_sociale_ordinante = disposizione._20_ragione_sociale_ordinante.Substring(0, 90);

						disposizione._20_indirizzo_ordinante          = ConfigurationSettings.AppSettings["CBIWriter.20.Ordinante.Indirizzo"]; // "VLE MARESCIALLO PILSUDSKI,92"
						disposizione._20_localita_ordinante           = ConfigurationSettings.AppSettings["CBIWriter.20.Ordinante.Localita"]; // "ROMA"
						disposizione._20_piva_ordinante               = ConfigurationSettings.AppSettings["CBIWriter.20.Ordinante.PartitaIVA"]; // "06208031002"

						disposizione._30_ragione_sociale_beneficiario = socDst.Attributes["RagioneSociale"].Value;

						disposizione._50_causale                      = causale;
						if (disposizione._50_causale.Length > 90)
							disposizione._50_causale = disposizione._50_causale.Substring(0, 90);

						cbiWriter.ScriviDisposizione(disposizione);
					}
				}
				else
				{
					// Versione nuova: si accorpano i mov. per i pagamento CV.
					ArrayList ar = new ArrayList();

					XmlNodeList xmlMovimenti = xmlOP.SelectNodes("//Movimento");
					foreach (XmlNode xmlMovimento in xmlMovimenti)
					{
						CBIDisposizione disposizione = new CBIDisposizione();

						XmlNode socSrc = xmlMovimento.SelectSingleNode("./SocietaSrc");
						XmlNode socDst = xmlMovimento.SelectSingleNode("./SocietaDst");

						string importo  = xmlMovimento.SelectSingleNode("./Importo").InnerText;
						string valuta   = xmlMovimento.SelectSingleNode("./Valuta").InnerText;
						string causale  = xmlMovimento.SelectSingleNode("./Causale").InnerText;

						disposizione._10_data_esecuzione_disposizione = DateTime.MinValue; // e` come null
						disposizione._10_data_valuta_beneficiario     = XmlConvert.ToDateTime(valuta);
						disposizione._10_importo                      = XmlConvert.ToDecimal(importo);
						disposizione._10_abi_ordinante                = ConfigurationSettings.AppSettings["CBIWriter.10.Ordinante.ABI"]; // 01025
						disposizione._10_cab_ordinante                = ConfigurationSettings.AppSettings["CBIWriter.10.Ordinante.CAB"]; // 03236
						disposizione._10_cc_ordinante                 = ConfigurationSettings.AppSettings["CBIWriter.10.Ordinante.CC"]; // 100000002087
						disposizione._10_abi_destinatario             = socDst.Attributes["ABI"].Value;
						disposizione._10_cab_destinatario             = socDst.Attributes["CAB"].Value;
						disposizione._10_cc_destinatario              = socDst.Attributes["CC"].Value;
						disposizione._10_codice_azienda               = ConfigurationSettings.AppSettings["CBIWriter.PC.mittente"];

						// la ragione sociale la TRONCO
						disposizione._20_ragione_sociale_ordinante    = ConfigurationSettings.AppSettings["CBIWriter.20.Ordinante.RagioneSociale"]; // "GESTORE DEL MERCATO ELETTRICO"
						if (disposizione._20_ragione_sociale_ordinante.Length > 90)
							disposizione._20_ragione_sociale_ordinante = disposizione._20_ragione_sociale_ordinante.Substring(0, 90);

						disposizione._20_indirizzo_ordinante          = ConfigurationSettings.AppSettings["CBIWriter.20.Ordinante.Indirizzo"]; // "VLE MARESCIALLO PILSUDSKI,92"
						disposizione._20_localita_ordinante           = ConfigurationSettings.AppSettings["CBIWriter.20.Ordinante.Localita"]; // "ROMA"
						disposizione._20_piva_ordinante               = ConfigurationSettings.AppSettings["CBIWriter.20.Ordinante.PartitaIVA"]; // "06208031002"

						disposizione._30_ragione_sociale_beneficiario = socDst.Attributes["RagioneSociale"].Value;

						disposizione._50_causale                      = causale;
						if (disposizione._50_causale.Length > 90)
							disposizione._50_causale = disposizione._50_causale.Substring(0, 90);

						// accumulo tutte le disposizioni nell'array
						ar.Add(disposizione);
					}


					// qui raggruppo per beneficiario/causale
					CBIGrouper cbig = new CBIGrouper(ar, cbiWriter);
					cbig.Loop();
				}


				cbiWriter.Close();

				string cbi = sw.GetStringBuilder().ToString();
#if DEBUG
				if (true)
				{
					using (FileStream fs = File.Create(@"c:\sp.cbi"))
					{
						using (StreamWriter sw2 = new StreamWriter(fs))
						{
							sw2.Write(cbi);
						}
						fs.Close();
					}
				}
#endif

				dsGestioneBancaria.ReportCVRow rpCBISP = ds.ReportCV.NewReportCVRow();
				rpCBISP.IdReport = NewGuid;
				rpCBISP.IdReportGroup = IdReportGroup;
				rpCBISP.TipoReport = "CBISP";
				rpCBISP.FormatoReport = "cbi";
				rpCBISP.NomeReport = string.Format(
					"Mercato CV del {0}: Ordine di pagamento in formato CBI emesso il {1}", 
					sessione.DataOraApertura.ToString("d", cultureInfo),
					TSCreazione.ToString("G", cultureInfo));
				rpCBISP.TSCreazione = TSCreazione;
				rpCBISP.SetTSPubblicazioneNull();
				rpCBISP.SetTSDownloadNull();
				rpCBISP.SetTSInvioNull();
				rpCBISP.SetTSRicevutoNull();
				rpCBISP.IdSessione = sessione.IdSessione;
				rpCBISP.SetIdSocietaNull();
				rpCBISP.RawReport = Encoding.ASCII.GetBytes(cbi);
				ds.ReportCV.AddReportCVRow(rpCBISP);
			}

			// qui genero il report che verra' visualizzato dal back office.
			if (true)
			{
				StringReader sr = new StringReader(xml);
				XPathDocument xsp = new XPathDocument(sr);
				XPathNavigator xnav = xsp.CreateNavigator();

				XslTransform xtr = new XslTransform();
				xtr.Load(xsltFile);
	

				MemoryStream memoryStream = new MemoryStream();
				StreamWriter memoryStreamWriter = new StreamWriter(memoryStream);
				xtr.Transform(xnav, null, memoryStreamWriter, null);
				memoryStreamWriter.Flush();
				string op = Encoding.UTF8.GetString(memoryStream.ToArray());

				dsGestioneBancaria.ReportCVRow rpSP = ds.ReportCV.NewReportCVRow();
				rpSP.IdReport = NewGuid;
				rpSP.IdReportGroup = IdReportGroup;
				rpSP.TipoReport = "SP";
				rpSP.FormatoReport = "html";
				rpSP.NomeReport = string.Format(
					"Mercato CV del {0}: Ordine di pagamento emesso il {1} in formato HTML", 
					sessione.DataOraApertura.ToString("d", cultureInfo),
					TSCreazione.ToString("G", cultureInfo));  // G ==> 08/17/2000 16:32:02
				rpSP.TSCreazione = TSCreazione;
				rpSP.SetTSPubblicazioneNull();
				rpSP.SetTSDownloadNull();
				rpSP.SetTSInvioNull();
				rpSP.SetTSRicevutoNull();
				rpSP.IdSessione = sessione.IdSessione;
				rpSP.SetIdSocietaNull();
				rpSP.RawReport = Encoding.UTF8.GetBytes(op);
				ds.ReportCV.AddReportCVRow(rpSP);
			}

			df.Update(ds, ref TSUltimaModifica);

			return string.Format("Ordine di pagamento generato con successo.\nIl nuovo ordine contiene {0} movimenti.", numeroMovimenti);
		}

		/// <summary>
		/// Questa funzione indica al sistema che l'ordine di pagamento al SanPaolo
		/// E` STATO GIA` INVIATO. 
		/// Non si puo` tornare indietro !!!!.
		/// </summary>
		/// <param name="TSInvio"></param>
		/// <returns></returns>
		public string OrdinePagamentoSanPaolo_InviaUltimo(ref DateTime TSUltimaModifica, DateTime TSInvio)
		{
			// carico il report XSP piu' recente.
			// (ci possono essere anche ordini di pagamento piu' vecchi).
			dsGestioneBancaria.ReportCVRow xspRecord;
			if (true)
			{
				xspRecord = OrdinePagamentoSanPaolo_TrovaUltimoXSP();
				if (xspRecord == null)
					return "Non ci sono ordini di pagamento da inviare";


				if (OrdinePagamentoSanPaolo_TrovaUltimoCBI().IsTSInvioNull() == false)
					return "L'ultimo ordine di pagamento e' stato gia' inviato";
			}

			// leggo l'XML per ottenere i movimenti comandati e con questi 
			//        a) metto TSInvio nel movimento
			//        b) le transazioni CV relative (se il movimento e' riconducibile a transazioni CV)
			//           acquisiscono FileExportBanca = mov.IdMovimentoBancario.
			if (true)
			{
				// ottengo l'xml dell'ordine di pagamento.
				string xml = Encoding.UTF8.GetString(xspRecord.RawReport);
				XmlDocument xmlSP = new XmlDocument();

				xmlSP.LoadXml(xml); // carico l'xml nel DOM
				XmlNodeList xmlMovimenti = xmlSP.SelectNodes("//Movimento");
				foreach (XmlNode xmlMovimento in xmlMovimenti) // cerco i movimenti
				{
					string IdMovimento = xmlMovimento.SelectSingleNode("./IdMovimento").InnerText;

					dsGestioneBancaria.MovimentiBancariRow mov;
					mov = ds.MovimentiBancari.FindByIdMovimentoBancario(IdMovimento);

					Debug.Assert(mov.TipoMovimento == "GP");
					Debug.Assert(mov.IsTSSottomessoNull() == true);
					Debug.Assert(mov.IsTSPerfezionatoNull() == true);

					// aggiorno il DB per quel movimento
					mov.TSSottomesso   = TSInvio;
					mov.TSPerfezionato = TSInvio;

					// vado a ritroso per valorizzare le transazioni
					// qualora il movimento sia dovuto al pagamento delle transazioni CV
					// questo pezzo di codice serve per compatibilita' con il passato

					dsGestioneBancaria.TrBanRow [] trbnList;

					trbnList = mov.GetTrBanRowsByMovimentiBancari_TrBan_GP();
					foreach (dsGestioneBancaria.TrBanRow trbn in trbnList)
					{
						dsGestioneBancaria.TransazioniRow trCV = trbn.TransazioniRow;
						trCV.FileExportBanca = mov.IdMovimentoBancario;
					}

					trbnList = mov.GetTrBanRowsByMovimentiBancari_TrBan_PP();
					foreach (dsGestioneBancaria.TrBanRow trbn in trbnList)
					{
						dsGestioneBancaria.TransazioniRow trCV = trbn.TransazioniRow;
						trCV.FileExportBanca = mov.IdMovimentoBancario;
					}
				}
			}

			// finalmente scrivo nel DB che il report e` stato inviato.
			xspRecord.TSInvio = TSInvio;

			// qui aggiorno anche la data di invio del CBI
			OrdinePagamentoSanPaolo_TrovaUltimoCBI().TSInvio = xspRecord.TSInvio;

			// qui salvo nel db
			df.Update(ds, ref TSUltimaModifica);

			return string.Empty;
		}

		public string OrdinePagamentoSanPaolo_CancellaUltimo(ref DateTime TSUltimaModifica)
		{
			dsGestioneBancaria.ReportCVRow xspReport;
			if (true)
			{
				xspReport = OrdinePagamentoSanPaolo_TrovaUltimoXSP();
				if (xspReport == null)
					return "Non esiste un ordine di pagamento da cancellare.";

				if (xspReport.IsTSInvioNull() == false)
					return "L'utimo ordine di pagamento e` stato gia` inviato";
			}

			string IdReportGroup = xspReport.IdReportGroup;

			// qui cancello tutti i documenti con lo stesso IdReportGroup
			foreach (dsGestioneBancaria.ReportCVRow r in ds.ReportCV)
				if (r.IdReportGroup == IdReportGroup) 
					r.Delete();

			df.Update(ds, ref TSUltimaModifica);

			return string.Empty;
		}

		public bool   OrdinePagamentoSanPaolo_NecessarioCreareNuovo()
		{
			// cerco tutti i movimenti di tipo GP con TSSottomesso NULL
			foreach (dsGestioneBancaria.MovimentiBancariRow mov in ds.MovimentiBancari)
			{
				if (mov.TipoMovimento == "GP" && mov.IsTSSottomessoNull() == true)
					return true;
			}
			return false;
		}
		#endregion

		#region Penali & Residui

		public class Penali_CalcolaImporto
		{
			public Penali_CalcolaImporto(dsGestioneBancaria ds)
			{
				// calcolo il minimo prezzo per CV di tutte le transazioni
				// effettuate nella sessione
				_minPrezzoPerCV = decimal.MaxValue;
				foreach (dsGestioneBancaria.TrBanRow tr in ds.TrBan)
				{
					// prezzo della transazione annullata
					decimal prezzoTr = tr.ImportoMovGP + tr.ImportoMovPP;

					// prezzo per CV della transazione annullata
					decimal prezzoCV = prezzoTr / tr.TransazioniRow.QtyCertificati;

					_minPrezzoPerCV = Math.Min(_minPrezzoPerCV, prezzoCV);
				}

				// in sessioni il Prezzoconvenzionale e` per CV
				_prezzoConvenzionaleGmePerCV = ds.Sessioni[0].PrezzoConvenzionale;

				string s = ConfigurationSettings.AppSettings["NuovoCalcoloPenali"];
				if (s != null)
				{
					s = s.ToUpper();
					if (s.StartsWith("S") || s.StartsWith("Y"))
						this._nuovoCalcoloPenale = true;
				}
			}
			public decimal CalcolaImporto(dsGestioneBancaria.TrBanRow trAnnullata)
			{
				if (_nuovoCalcoloPenale == false)
				{
					decimal qtyCertificatiInadempienti = trAnnullata.TransazioniRow.QtyCertificati;

					decimal prezzoTrAnnullata = trAnnullata.ImportoMovGP + trAnnullata.ImportoMovPP;
					decimal prezzoTrAnnullataPerCV  = prezzoTrAnnullata / qtyCertificatiInadempienti;

					decimal penalePerCV = Math.Min(_prezzoConvenzionaleGmePerCV, 2 * (prezzoTrAnnullataPerCV - _minPrezzoPerCV));

					decimal penalePerTransazioneAnnullata = qtyCertificatiInadempienti * penalePerCV;
					return penalePerTransazioneAnnullata;
				}
				else
				{
					decimal qtyCertificatiInadempienti = trAnnullata.TransazioniRow.QtyCertificati;
					return _prezzoConvenzionaleGmePerCV * qtyCertificatiInadempienti;
				}
			}

			readonly decimal _minPrezzoPerCV;
			readonly decimal _prezzoConvenzionaleGmePerCV;
			readonly bool    _nuovoCalcoloPenale;
		}
		public void Penali_Calcola(DateTime TSValutaPenali)
		{
			Penali_CalcolaImporto calcoloPenale = new Penali_CalcolaImporto(ds);

			bool bContinue = false;
			do
			{
				bContinue = false; // se esco per qualche motivo non devo ancora
				// girare nel do...while.

				foreach (dsGestioneBancaria.MovimentiBancariRow movPP in ds.MovimentiBancari)
				{
					if (movPP.TipoMovimento != "PP")
						continue;

					if (movPP.IsTSPerfezionatoNull() == false)
						continue;

					// ho un PP non perfezionato.
					// Forse e` stato gia` considerato nel pagamento della penale.

					// trovo le transazioni associate.
					dsGestioneBancaria.TrBanRow [] trbanPPList;
					trbanPPList = movPP.GetTrBanRowsByMovimentiBancari_TrBan_PP();
					Debug.Assert(trbanPPList.Length > 0);
					if (trbanPPList.Length == 0)
						continue; // non dovrebbe mai capitare

					// scandisco le transazioni per conteggiare
					// l'ammontare della penale (se la trans. e` in stato Non Valida).
					decimal numeroCVInadempienti = 0m;
					decimal penale = 0m;
					foreach (dsGestioneBancaria.TrBanRow trbanPP in trbanPPList)
					{
						dsGestioneBancaria.TransazioniRow transazione = trbanPP.TransazioniRow;

						Debug.Assert(trbanPP.IdMovPP == movPP.IdMovimentoBancario);
						Debug.Assert(trbanPP.ImportoMovPP > 0); // era scoperto
						Debug.Assert(transazione != null);
						Debug.Assert(transazione.StatoTransazione=="Non Valida" || transazione.StatoTransazione=="Inadempiente");

						// qui ho
						// 1) o una transazione in stato Non Valida senza mov penale --> da elaborare 
						// 2) o una transazione in stato Inadempiente probabilmente con il mov penale --> gia` elaborata

						if (transazione.StatoTransazione == "Non Valida")
						{
							// e' una transazione soggetta a penale.

							// non ho ancora conteggiato la penale per questo movimento
							// la transazione va in stato Inadempiente
							transazione.StatoTransazione = "Inadempiente";

							// devo accumulare la QtyCertificati per IdSocietaSrc/IdSocietaDst
							// a fronte di questa posso calcolare la penale e inserire il movimento.
							numeroCVInadempienti += transazione.QtyCertificati;
							penale += calcoloPenale.CalcolaImporto(trbanPP);
						}

						// alla fine sono sicuro di avere una transazione Inadempiente
						// (a prescindere se dovra` o no effetivamente pagare penale).
						Debug.Assert(transazione.StatoTransazione=="Inadempiente");
					}

					if (numeroCVInadempienti == 0m)  // puo` capitare se per il mov. si e` gia` conteggiata la penale
						continue;

					// se sono qui ho trovato un mov PP che deve pagare penale...
					// puo` capitare per le strane regole del calcolo delle penali che
					// la penale sia zero.... non creo il movimento.
					if (penale == 0m)
						continue;

					dsGestioneBancaria.SocietaRow societaAcq = ds.Societa.FindByIdSocieta(movPP.IdSocietaSrc);

					dsGestioneBancaria.MovimentiBancariRow movPenale = ds.MovimentiBancari.NewMovimentiBancariRow();
					movPenale.IdMovimentoBancario = NewGuid;
					movPenale.IdSessione = sessione.IdSessione;
					movPenale.TipoMovimento = "GP";
					movPenale.IdSocietaSrc = movPP.IdSocietaSrc;
					movPenale.IdSocietaDst = movPP.IdSocietaDst;
					movPenale.Importo = penale;
					movPenale.Valuta = TSValutaPenali;
					movPenale.Causale = string.Format(
						"MCV {0}: Pagamento penale.", 
						sessione.DataOraApertura.ToString("d", cultureInfo));
					Debug.Assert(movPenale.Causale.Length <= 50);
					movPenale.SetNoteNull();
					movPenale.SetTSSottomessoNull();
					movPenale.SetTSPerfezionatoNull();
					movPenale.SocietaSrc_RagioneSociale = movPP.SocietaSrc_RagioneSociale;
					movPenale.SocietaSrc_CodiceConto    = movPP.SocietaSrc_CodiceConto;
					movPenale.SocietaDst_RagioneSociale = movPP.SocietaDst_RagioneSociale;
					movPenale.SocietaDst_CodiceConto    = movPP.SocietaDst_CodiceConto;
					ds.MovimentiBancari.AddMovimentiBancariRow(movPenale);

					// ora che ho il movimento di penale lo associo alle transazioni.
					foreach (dsGestioneBancaria.TrBanRow trbanPP in trbanPPList)
					{
#if DEBUG
						dsGestioneBancaria.TransazioniRow transazione = trbanPP.TransazioniRow;
						Debug.Assert(trbanPP.IsIdMovPenaleNull());
						Debug.Assert(trbanPP.ImportoMovPP > 0); // era scoperto
						Debug.Assert(transazione != null);
						Debug.Assert(transazione.StatoTransazione=="Inadempiente");
#endif

						trbanPP.IdMovPenale = movPenale.IdMovimentoBancario;
					}

					// qui si potrebbe:
					// a) cancellare il movimento PP
					// b) tenerlo
					// noi lo manteniamo.

					// qui devo uscire perche` ho inserito un record quando stavo facendo un loop
					// nella collezione
					bContinue = true; // continuo a cercare nella tabella
					break;
				}
			} while (bContinue);
		}

		/// <summary>
		/// Crea i movimenti per la restituzione dei residui.
		/// Opera solo quando la sessione e` ancora aperta.
		/// </summary>
		/// <param name="valutaRestituzioneResiduo"></param>
		public int Residui_Calcola(ref DateTime TSUltimaModifica, DateTime valutaRestituzioneResiduo)
		{
			int movCreati = Residui_Calcola(valutaRestituzioneResiduo, false);
			df.Update(ds, ref TSUltimaModifica);
			return movCreati;
		}
		private int Residui_Calcola(DateTime valutaRestituzioneResiduo, bool Chiusura)
		{
			int movCreati = 0;

			Debug.WriteLine("Residui_Calcola");

			foreach (dsGestioneBancaria.BudgetsRow budget in ds.Budgets)
			{
				Debug.Write("\n");
				Debug.Write(ds.Societa.FindByIdSocieta(budget.IdSocieta).IdSocieta);
				Debug.Write(": ");
				Debug.Write(ds.Societa.FindByIdSocieta(budget.IdSocieta).RagioneSociale);
				Debug.Write(" Importo = " + budget.Importo.ToString());
				Debug.Write(" Residuo = " + budget.Residuo.ToString());

				if (budget.IsIdMovResiduoNull() == false)
					continue; // e' stato gia' conteggiato il residuo per questa societa`

				if (budget.Importo <= 0m)
					continue; // non ha soldi: certo non gli restituisco niente ==> continuo

				if (budget.IsResiduoNull())
					budget.Residuo = 0m;

				if (budget.Residuo < 0) // modalita` di gestione residuo.
					continue; // <0 indica un residuo nel conto infinito --> non vuole la resituzione

				if (Chiusura == false)
				{
					// Non si sta facendo la chiusura....

					// Prima di conteggiare il residuo
					// verifico se la societa' ha movimenti PP in sospeso (non pagati).
					// Se ne ha anche uno solo, potenzialmente puo` pagare penale e
					// dunque devo aspettare la chiusura prima di restituire il residuo
					bool PagamentiInSospeso = false;
					foreach (dsGestioneBancaria.MovimentiBancariRow mov in ds.MovimentiBancari)
					{
						if (mov.IdSocietaSrc != budget.IdSocieta) continue;
						if (mov.TipoMovimento != "PP") continue;

						// ho un movimento PP: questo puo` essere
						// a) non perfezionato
						// b) gia` perfezionato ma con GP non sottomesso.
						// c) gia` perfezionato ma con GP sottomesso. --> solo questo garantisce che non si puo` tornare indietro.

						if (mov.IsTSPerfezionatoNull() == true)
						{
							// PP non perfezionato
							PagamentiInSospeso = true;
							break;
						}
						else
						{
							// PP perfezionato

							// trovo il mov GP associato.
							dsGestioneBancaria.TrBanRow [] trList; 
							trList = mov.GetTrBanRowsByMovimentiBancari_TrBan_PP();
							Debug.Assert(trList.Length > 0);
							Debug.Assert(trList[0].IsImportoMovGPNull() == false);

							dsGestioneBancaria.MovimentiBancariRow movGP = trList[0].MovimentiBancariRowByMovimentiBancari_TrBan_GP;
							if (movGP.IsTSSottomessoNull() == true)
							{
								// GP non sottomesso
								PagamentiInSospeso = true;
								break;
							}

							// GP sottomesso --> non e` in sospeso.
							// NB. dato che un ordine al san paolo e` definitivo (non si puo` tornare indietro)
							// sono certo che le transazioni coinvolte siano perfezionate in maniera
							// definitiva.
						}
					}

					if (PagamentiInSospeso)
						continue; // ==> continuo con un'altra societa`
				}

				// sommo gli importi di tutti i movimenti GP della societa`.
				// Notare che conto TUTTI i movimenti GP della sessione
				// ossia 
				// a) pagamenti di CV
				// b) pagamenti di penali
				// I conti si fanno per Sessione.
				// I movimenti di restituzione del residuo DEVE essere l'ultimo
				// movimento GP per quella societa'
				// ANCHE quelli non ancora spediti.....
				decimal importoTotaleGP = 0m;
				foreach (dsGestioneBancaria.MovimentiBancariRow mov in ds.MovimentiBancari)
					if (mov.TipoMovimento == "GP" && mov.IdSocietaSrc == budget.IdSocieta)
						importoTotaleGP += mov.Importo;

				// avevo all'inizio tot, ho speso tot, mi rimane:
				decimal importoRestituibileMassimo = budget.Importo - importoTotaleGP;

				// determino quanto restituire.
				decimal importoRestituito = 0m;

				if (budget.Residuo < 0m) // < 0 indica un numero grandissimo ==> voglio conservare tutto il residuo
				{
					// Non restituire il residuo.
					importoRestituito = 0;
				}
				else if (budget.Residuo == 0m) // non voglio residuo nel conto.
				{
					// Restituzione di tutto il residuo.
					importoRestituito = importoRestituibileMassimo;
				}
				else
				{
					// Il massimo residuo consentito nel budget e' in budget.Residuo

					if (budget.Residuo >= importoRestituibileMassimo)
						importoRestituito = 0m;
					else
						importoRestituito = importoRestituibileMassimo - budget.Residuo;
				}

				// devo restituire qualcosa ?
				if (importoRestituito == 0m)
					continue;

				dsGestioneBancaria.SocietaRow societaResiduo = budget.SocietaRow;

				// creo il movimento del residuo.

				dsGestioneBancaria.MovimentiBancariRow movResiduo = ds.MovimentiBancari.NewMovimentiBancariRow();
				movResiduo.IdMovimentoBancario = NewGuid;
				movResiduo.IdSessione = sessione.IdSessione;
				movResiduo.TipoMovimento = "GP";
				movResiduo.IdSocietaSrc = budget.IdSocieta;
				movResiduo.IdSocietaDst = budget.IdSocieta;
				movResiduo.Importo = importoRestituito;
				movResiduo.Valuta = valutaRestituzioneResiduo;
				movResiduo.Causale = string.Format(
					"MCV {0}: Restituzione deposito.", 
					sessione.DataOraApertura.ToString("d", cultureInfo));
				Debug.Assert(movResiduo.Causale.Length <= 50);
				Debug.Assert(ds.Budgets.FindByIdSessioneIdSocieta(sessione.IdSessione, movResiduo.IdSocietaSrc).IsIdMovResiduoNull() == true);
				movResiduo.SetNoteNull();
				movResiduo.SetTSSottomessoNull();
				movResiduo.SetTSPerfezionatoNull();
				movResiduo.SocietaSrc_RagioneSociale = societaResiduo.RagioneSociale;
				movResiduo.SocietaSrc_CodiceConto    = societaResiduo.CodiceConto;
				movResiduo.SocietaDst_RagioneSociale = societaResiduo.RagioneSociale;
				movResiduo.SocietaDst_CodiceConto    = societaResiduo.CodiceConto;

				ds.MovimentiBancari.AddMovimentiBancariRow(movResiduo);
				movCreati++;

				budget.IdMovResiduo = movResiduo.IdMovimentoBancario;
			}

			return movCreati;
		}


		private int Residui_Calcola_Pagabili(bool Chiusura)
		{
			int movCreati = 0;

			Debug.WriteLine("Residui_Calcola_Pagabili");

			foreach (dsGestioneBancaria.BudgetsRow budget in ds.Budgets)
			{
				Debug.Write("\n");
				Debug.Write(ds.Societa.FindByIdSocieta(budget.IdSocieta).IdSocieta);
				Debug.Write(": ");
				Debug.Write(ds.Societa.FindByIdSocieta(budget.IdSocieta).RagioneSociale);
				Debug.Write(" Importo = " + budget.Importo.ToString());
				Debug.Write(" Residuo = " + budget.Residuo.ToString());

				if (budget.IsIdMovResiduoNull() == false)
					continue; // e' stato gia' conteggiato il residuo per questa societa`

				if (budget.Importo <= 0m)
					continue; // non ha soldi: certo non gli restituisco niente ==> continuo

				decimal budget_Residuo;

				// se il budget.Residuo NON e` valorizzato lo considero come 0m
				if (budget.IsResiduoNull())
					budget_Residuo = 0m;
				else
					budget_Residuo = budget.Residuo;

				if (budget_Residuo < 0) // modalita` di gestione residuo.
					continue; // <0 indica un residuo nel conto infinito --> non vuole la resituzione

				if (Chiusura == false)
				{
					// Non si sta facendo la chiusura....

					// Prima di conteggiare il residuo
					// verifico se la societa' ha movimenti PP in sospeso (non pagati).
					// Se ne ha anche uno solo, potenzialmente puo` pagare penale e
					// dunque devo aspettare la chiusura prima di restituire il residuo
					bool PagamentiInSospeso = false;
					foreach (dsGestioneBancaria.MovimentiBancariRow mov in ds.MovimentiBancari)
					{
						if (mov.IdSocietaSrc != budget.IdSocieta) continue;
						if (mov.TipoMovimento != "PP") continue;

						// ho un movimento PP: questo puo` essere
						// a) non perfezionato
						// b) gia` perfezionato ma con GP non sottomesso.
						// c) gia` perfezionato ma con GP sottomesso. --> solo questo garantisce che non si puo` tornare indietro.

						if (mov.IsTSPerfezionatoNull() == true)
						{
							// PP non perfezionato
							PagamentiInSospeso = true;
							break;
						}
						else
						{
							// PP perfezionato

							// trovo il mov GP associato.
							dsGestioneBancaria.TrBanRow [] trList; 
							trList = mov.GetTrBanRowsByMovimentiBancari_TrBan_PP();
							Debug.Assert(trList.Length > 0);
							Debug.Assert(trList[0].IsImportoMovGPNull() == false);

							dsGestioneBancaria.MovimentiBancariRow movGP = trList[0].MovimentiBancariRowByMovimentiBancari_TrBan_GP;
							if (movGP.IsTSSottomessoNull() == true)
							{
								// GP non sottomesso
								PagamentiInSospeso = true;
								break;
							}

							// GP sottomesso --> non e` in sospeso.
							// NB. dato che un ordine al san paolo e` definitivo (non si puo` tornare indietro)
							// sono certo che le transazioni coinvolte siano perfezionate in maniera
							// definitiva.
						}
					}

					if (PagamentiInSospeso)
						continue; // ==> continuo con un'altra societa`
				}

				// sommo gli importi di tutti i movimenti GP della societa`.
				// Notare che conto TUTTI i movimenti GP della sessione
				// ossia 
				// a) pagamenti di CV
				// b) pagamenti di penali
				// I conti si fanno per Sessione.
				// I movimenti di restituzione del residuo DEVE essere l'ultimo
				// movimento GP per quella societa'
				// ANCHE quelli non ancora spediti.....
				decimal importoTotaleGP = 0m;
				foreach (dsGestioneBancaria.MovimentiBancariRow mov in ds.MovimentiBancari)
					if (mov.TipoMovimento == "GP" && mov.IdSocietaSrc == budget.IdSocieta)
						importoTotaleGP += mov.Importo;

				// avevo all'inizio tot, ho speso tot, mi rimane:
				decimal importoRestituibileMassimo = budget.Importo - importoTotaleGP;

				// determino quanto restituire.
				decimal importoRestituito = 0m;

				if (budget_Residuo < 0m) // < 0 indica un numero grandissimo ==> voglio conservare tutto il residuo
				{
					// Non restituire il residuo.
					importoRestituito = 0;
				}
				else if (budget_Residuo == 0m) // non voglio residuo nel conto.
				{
					// Restituzione di tutto il residuo.
					importoRestituito = importoRestituibileMassimo;
				}
				else
				{
					// Il massimo residuo consentito nel budget e' in budget.Residuo

					if (budget_Residuo >= importoRestituibileMassimo)
						importoRestituito = 0m;
					else
						importoRestituito = importoRestituibileMassimo - budget_Residuo;
				}

				// devo restituire qualcosa ?
				if (importoRestituito == 0m)
					continue;

				movCreati++;
			}

			return movCreati;
		}


		#endregion

		#region ChiusuraBancaria
		public void SessioneBancaria_CalcolaSaldoFinale()
		{
			foreach (dsGestioneBancaria.BudgetsRow budget in ds.Budgets)
			{
				// sommo gli importi di tutti i movimenti GP della societa`.
				decimal importoTotaleGP = 0m;
				foreach (dsGestioneBancaria.MovimentiBancariRow mov in ds.MovimentiBancari)
				{
					if (mov.IdSocietaSrc != budget.IdSocieta) continue;
					if (mov.TipoMovimento != "GP") continue;

					Debug.Assert(mov.IsTSSottomessoNull() == false); // tutti i mov. GP devono essere sottomessi/perfezionati
					Debug.Assert(mov.IsTSPerfezionatoNull() == false); // tutti i mov. GP devono essere sottomessi/perfezionati

					importoTotaleGP += mov.Importo;
				}

				decimal saldo = budget.Importo - importoTotaleGP;
				Debug.Assert(saldo >= 0); // non si puo` mai andare sotto.
				if (saldo < 0)
					saldo = 0m; // comunque in release metto un tappo.

				budget.SocietaRow.Saldo = saldo;
			}
		}

		public string SessioneBancaria_Chiudi(ref DateTime TSUltimaModifica, DateTime TSValuta)
		{
			// la chiusura comporta il calcolo delle penali
			// che potenzialmente mettono nuovi movimenti GP
			Penali_Calcola(TSValuta);
			// DOPO le penali i residui; true --> sono in chiusura
			Residui_Calcola(TSValuta, true);

			df.Update(ds, ref TSUltimaModifica);

			// ATTENZIONE:
			// Il movimenti GP devono uscire per forza prima di chiudere la sessione.
			// Il mov. PP inadempienti potrebbero anche non avere il movimento di penale
			// (in quanto se la penale viene zero in movimento GP di penale non viene descritto)
			// Tutte le transazioni o sono in stato Valida o sono in stato Inadempiente.


			// a questo punto tutti i movimenti GP sono stati creati nel DB
			// per cui le due funzioni sotto sono "attendibili"
			bool necessarioNuovoSP = OrdinePagamentoSanPaolo_NecessarioCreareNuovo();
			bool necessarioInvioUltimoSP = OrdinePagamentoSanPaolo_EsisteUltimoDaValidareInviare();

			if (necessarioInvioUltimoSP && necessarioNuovoSP)
				return "Prima della chiusura e` necessario inviare l'ultimo ordine di pagamento generato.\n" +
					"Ci sono comunque dei movimenti non ancora descritti in questo ordine che richiederanno\n" +
					"la generazione di un ulteriore ordine di pagamento";

			if (necessarioInvioUltimoSP)
				return "Prima della chiusura e` necessario inviare l'ultimo ordine di pagamento generato.";

			if (necessarioNuovoSP)
				return "Prima di chiudere la sessione e' necessario creare ed inviare un nuovo ordine di pagamento";

			// qui ogni societa` potrebbe avere un residuo..... (nonostante la funzione Residui_Calcola)
			// aggiorno il Saldo della societa`
			// Notare che questa NON genera movimenti, ma aggiorna solo il saldo per societa`
			SessioneBancaria_CalcolaSaldoFinale();

			// alla fine di tutto mettiamo la data di fine sessione.
			DateTime TSChiusuraBancaria = DateTime.Now;
			ds.SessioniBancarie.FindByIdSessione(sessione.IdSessione).TSChiusura = TSChiusuraBancaria;

			df.Update(ds, ref TSUltimaModifica);

			// genero il report di chiusura bancaria.
			// Da qui legge i saldi delle societa.
			try
			{
				// qui creo il report di chiusura
				string rptChiusura = this.SessioneBancaria_ReportStato(true);

				// qui lo memorizzo
				dsGestioneBancaria.ReportCVRow rpChiusura = ds.ReportCV.NewReportCVRow();
				rpChiusura.IdReport = NewGuid;
				rpChiusura.IdReportGroup = rpChiusura.IdReport;
				rpChiusura.TipoReport = "ENDSB";
				rpChiusura.FormatoReport = "html";
				rpChiusura.NomeReport = string.Format(
					"Mercato CV del {0}: report di chiusura bancaria.", 
					sessione.DataOraApertura.ToString("d", cultureInfo));
				rpChiusura.TSCreazione = TSChiusuraBancaria;
				rpChiusura.SetTSPubblicazioneNull();
				rpChiusura.SetTSDownloadNull();
				rpChiusura.SetTSInvioNull();
				rpChiusura.SetTSRicevutoNull();
				rpChiusura.IdSessione = sessione.IdSessione;
				rpChiusura.SetIdSocietaNull();
				rpChiusura.RawReport = Encoding.UTF8.GetBytes(rptChiusura);
				ds.ReportCV.AddReportCVRow(rpChiusura);

				df.Update(ds, ref TSUltimaModifica);
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Errore nella creazione del report di chiusura");
				Trace.WriteLine(ex.Message);
				Trace.WriteLine(ex.StackTrace);
			}

			return string.Empty;
		}

		#endregion

		#region Utilities
		static void XmlSocietaWriter(XmlTextWriter x, string xmlNodeName, dsGestioneBancaria.SocietaRow soc)
		{
			string n = string.Empty; // usato per i campi null

			if (xmlNodeName != null)
				x.WriteStartElement(xmlNodeName);

			if (true)
			{
				x.WriteAttributeString("IdSocieta",            soc.IdSocieta);
				x.WriteAttributeString("RagioneSociale",       soc.IsRagioneSocialeNull () ? n : soc.RagioneSociale);
				x.WriteAttributeString("ABI",                  soc.IsABINull() ? n : soc.ABI);
				x.WriteAttributeString("CAB",                  soc.IsCABNull() ? n : soc.CAB);
				x.WriteAttributeString("CC",                   soc.IsCCNull() ?  n : soc.CC);
				x.WriteAttributeString("ChiaveContoProprieta", soc.IsChiaveContoProprietaNull() ? n : soc.ChiaveContoProprieta);
				x.WriteAttributeString("CodiceConto",          soc.IsCodiceContoNull() ? n : soc.CodiceConto);
				x.WriteAttributeString("CodiceFiscale",        soc.IsCodiceFiscaleNull() ? n : soc.CodiceFiscale);
				x.WriteAttributeString("PartitaIVA",           soc.IsPartitaIVANull() ? n : soc.PartitaIVA);
				x.WriteAttributeString("Indirizzo",            soc.IsIndirizzoNull() ? n : soc.Indirizzo);
				x.WriteAttributeString("Citta",                soc.IsCittaNull () ? n : soc.Citta);
			}

			if (xmlNodeName != null)
				x.WriteEndElement();
		}

		static public string NewGuid
		{
			get { return Guid.NewGuid().ToString("N").ToUpper(); }
		}
#endregion
	}

}

