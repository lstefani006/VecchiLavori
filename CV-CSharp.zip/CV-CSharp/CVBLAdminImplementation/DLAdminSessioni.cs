using System;
using System.Data;
using System.Data.OleDb;
using System.Xml;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminSessioni.
	/// </summary>
	internal class DLAdminSessioni : DLAdminBase
	{
		public DLAdminSessioni(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public DataSet GetLista()
		{
			string strSqlQuery = "SELECT RAWTOHEX(IdSessione) AS IdSessione, " + 
								 "Titolo, " +
								 "DataOraApertura, DataOraChiusura, " +
								 "PrezzoRiferimentoAnnoPrec, " + 
								 "PrezzoRiferimentoAnnoCorr, " + 
								 "PrezzoRiferimentoAnnoSucc, " +
								 "PrezzoConvenzionale, " +
								 "DataOraCreazione, " + 
								 "DataOraModifica, " +
								 "StatoSessione, " +
								 "DataCorrispettivo " +	
								 "FROM CV.Sessioni " +
								 "ORDER BY DataOraCreazione DESC";
			
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = DLAdminSessione.DataSet_Sessioni();
				da.SelectCommand = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.Fill(ds, "Sessioni");
				return ds;
			}
		}

		public DataSet GetListaFiltrata()
		{
			string strSqlQuery = "SELECT RAWTOHEX(IdSessione) AS IdSessione, " + 
								 "Titolo, DataOraApertura, DataOraChiusura, " + 
								 "PrezzoRiferimentoAnnoPrec, PrezzoRiferimentoAnnoCorr, " + 
								 "PrezzoRiferimentoAnnoSucc, PrezzoConvenzionale, " + 
								 "DataOraCreazione, DataOraModifica, StatoSessione, DataCorrispettivo " +
								 "FROM CV.Sessioni Sessioni " +
								 "WHERE StatoSessione IN ('In Attesa','Predisposta','Aperta') " +
								 "ORDER BY Titolo";
			
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				DataSet ds = DLAdminSessione.DataSet_Sessioni();
				OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				da.Fill(ds, "Sessioni");
				return ds;
			}
		}

		public ReportSessioni VerifyStatus()
		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_Sessioni_VerifyStatus", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// # Sessioni Predisposte (output)
//			OleDbParameter parNumSessioniPredisposte = new OleDbParameter("@NumPredisposte", OleDbType.Decimal);
//			parNumSessioniPredisposte.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parNumSessioniPredisposte);
//
//			// # Sessioni Aperte (output)
//			OleDbParameter parNumSessioniAperte = new OleDbParameter("@NumAperte", OleDbType.Decimal);
//			parNumSessioniAperte.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parNumSessioniAperte);
//
//			// # Sessioni Sospese (output)
//			OleDbParameter parNumSessioniSospese = new OleDbParameter("@NumSospese", OleDbType.Decimal);
//			parNumSessioniSospese.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parNumSessioniSospese);
//
//			// # Sessioni Terminate (output)
//			OleDbParameter parNumSessioniTerminate = new OleDbParameter("@NumTerminate", OleDbType.Decimal);
//			parNumSessioniTerminate.Direction = ParameterDirection.Output;
//			callspCMD.Parameters.Add(parNumSessioniTerminate);
//
//			callspCMD.ExecuteNonQuery();
//
//			ReportSessioni rs = new ReportSessioni();
//
//			rs.NumPredisposte = (decimal)callspCMD.Parameters["@NumPredisposte"].Value;
//			rs.NumAperte = (decimal)callspCMD.Parameters["@NumAperte"].Value;
//			rs.NumSospese = (decimal)callspCMD.Parameters["@NumSospese"].Value;
//			rs.NumTerminate = (decimal)callspCMD.Parameters["@NumTerminate"].Value;
//			return rs;

		
			ReportSessioni rs = new ReportSessioni();

			using(OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = "SELECT Count(*) FROM cv.Sessioni WHERE StatoSessione = 'Predisposta'";
				rs.NumPredisposte = (decimal) cmd.ExecuteScalar();
			}
			using(OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = "SELECT Count(*) FROM cv.Sessioni WHERE StatoSessione = 'Aperta'";
				rs.NumAperte = (decimal) cmd.ExecuteScalar();
			}
			using(OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = "SELECT Count(*) FROM cv.Sessioni WHERE StatoSessione = 'Sospesa'";
				rs.NumSospese = (decimal) cmd.ExecuteScalar();
			}
			using(OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = "SELECT Count(*) FROM cv.Sessioni WHERE StatoSessione = 'Terminata'";
				rs.NumTerminate = (decimal) cmd.ExecuteScalar();
			}

			return rs;

		}

		public DataSet CalcolaCorrispettivi(string[] IdSessioni)
		{
			DataSet ds = new DataSet();
			DataRow row ;
			DataTable dt = new DataTable("Corrispettivi");
			dt.Columns.Add(new DataColumn("IdSessione", typeof(string)));
			dt.Columns.Add(new DataColumn("IdSocieta", typeof(string)));
			dt.Columns.Add(new DataColumn("Titolo", typeof(string)));
			dt.Columns.Add(new DataColumn("RagioneSociale", typeof(string)));
			dt.Columns.Add(new DataColumn("CodiceConto", typeof(string)));
			dt.Columns.Add(new DataColumn("DataOraApertura", typeof(DateTime)));
			dt.Columns.Add(new DataColumn("Corrispettivo", typeof(decimal)));
			dt.Columns.Add(new DataColumn("QtyCertificati", typeof(decimal)));
			dt.Columns.Add(new DataColumn("QtyCertificatiInadempienti", typeof(decimal)));
			dt.Columns.Add(new DataColumn("StatoTransazione", typeof(string)));

			decimal EuroXCertA = XmlConvert.ToDecimal(System.Configuration.ConfigurationSettings.AppSettings["EuroXCertificatoAcquistato"]);
			decimal EuroXCertV = XmlConvert.ToDecimal(System.Configuration.ConfigurationSettings.AppSettings["EuroXCertificatoVenduto"]);
			decimal EuroXCertAcqInadempiente = XmlConvert.ToDecimal(System.Configuration.ConfigurationSettings.AppSettings["EuroXCertificatoXAcquirenteInadempiente"]);

			string strSqlQuery = "" ;
			DataSet dsAcquisti = new DataSet();
			DataSet dsVendite = new DataSet();
			DataSet dsUnione = new DataSet();
			DataTable dtTemp = new DataTable("Corrispettivi");
			dtTemp.Columns.Add(new DataColumn("IdSessione", typeof(string)));
			dtTemp.Columns.Add(new DataColumn("IdSocieta", typeof(string)));
			dtTemp.Columns.Add(new DataColumn("Titolo", typeof(string)));
			dtTemp.Columns.Add(new DataColumn("RagioneSociale", typeof(string)));
			dtTemp.Columns.Add(new DataColumn("CodiceConto", typeof(string)));
			dtTemp.Columns.Add(new DataColumn("DataOraApertura", typeof(DateTime)));
			dtTemp.Columns.Add(new DataColumn("Corrispettivo", typeof(decimal)));
			dtTemp.Columns.Add(new DataColumn("QtyCertificati", typeof(decimal)));
			dtTemp.Columns.Add(new DataColumn("QtyCertificatiInadempienti", typeof(decimal)));
			dtTemp.Columns.Add(new DataColumn("StatoTransazione", typeof(string)));

			for (int i=0; i<IdSessioni.Length; i++)
			{
				strSqlQuery = "SELECT T.QtyCertificati AS QtyCertificati, T.StatoTransazione AS StatoTransazione, " + 
					"RAWTOHEX(S.IdSessione) AS IdSessione, S.Titolo AS Titolo, " + 
					"S.DataOraApertura AS DataOraApertura, RAWTOHEX(Sc.IdSocieta) AS IdSocieta, " + 
					"Sc.RagioneSociale AS RagioneSociale, Sc.CodiceConto AS CodiceConto " + 
					"FROM CV.Transazioni T, CV.OfferteAcquisto A, CV.Sessioni S, US.Utenti U, US.Societa Sc " +
					"WHERE S.IdSessione = HEXTORAW(?) " +
					"and T.IdOffertaAcquisto = A.IdOffertaAcquisto and " +
					"A.IdSessione = S.IdSessione and A.IdUtente = U.IdUtente and U.IdSocieta = Sc.IdSocieta ORDER BY Sc.CodiceConto FOR UPDATE";
			
				using (OleDbDataAdapter da = new OleDbDataAdapter())
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessioni[i];
					da.SelectCommand = selectCMD;
					da.Fill(dsAcquisti, "Corrispettivi");
				}

				strSqlQuery = "SELECT T.QtyCertificati AS QtyCertificati, T.StatoTransazione AS StatoTransazione, " + 
					"RAWTOHEX(S.IdSessione) AS IdSessione, S.Titolo AS Titolo, " + 
					"S.DataOraApertura AS DataOraApertura, RAWTOHEX(Sc.IdSocieta) AS IdSocieta, " + 
					"Sc.RagioneSociale AS RagioneSociale, Sc.CodiceConto AS CodiceConto " + 
					"FROM CV.Transazioni T, CV.OfferteVendita V, CV.Sessioni S, US.Utenti U, US.Societa Sc " +
					"WHERE S.IdSessione = HEXTORAW(?) " +
					"and T.IdOffertaVendita = V.IdOffertaVendita and " +
					"V.IdSessione = S.IdSessione and V.IdUtente = U.IdUtente and U.IdSocieta = Sc.IdSocieta ORDER BY Sc.CodiceConto FOR UPDATE";
			
				using (OleDbDataAdapter da = new OleDbDataAdapter())
				{
					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessioni[i];
					da.SelectCommand = selectCMD;
					da.Fill(dsVendite, "Corrispettivi");
				}

				foreach (DataRow r in dsAcquisti.Tables[0].Rows)
				{
					row = dtTemp.NewRow();
					row["IdSessione"] = (string)r["IdSessione"] ;
					row["IdSocieta"] =  (string)r["IdSocieta"] ;
					row["Titolo"] = (string)r["Titolo"] ;
					row["RagioneSociale"] = (string)r["RagioneSociale"] ;
					row["CodiceConto"] = (string)r["CodiceConto"] ;
					row["DataOraApertura"] = (DateTime)r["DataOraApertura"] ;
					if (r["StatoTransazione"].ToString() != "Inadempiente")
					{
						row["Corrispettivo"] = (decimal)r["QtyCertificati"] *  EuroXCertA ;
						row["QtyCertificati"] = (decimal)r["QtyCertificati"];
						row["QtyCertificatiInadempienti"] = 0m ;
					}
					else
					{
						row["Corrispettivo"] = (decimal)r["QtyCertificati"] *  EuroXCertAcqInadempiente ;
						row["QtyCertificati"] = 0m ;
						row["QtyCertificatiInadempienti"] = (decimal)r["QtyCertificati"];
					}
					
					dtTemp.Rows.Add(row);
				}
				foreach (DataRow r in dsVendite.Tables[0].Rows)
				{
					row = dtTemp.NewRow();
					row["IdSessione"] = (string)r["IdSessione"] ;
					row["IdSocieta"] =  (string)r["IdSocieta"] ;
					row["Titolo"] = (string)r["Titolo"] ;
					row["RagioneSociale"] = (string)r["RagioneSociale"] ;
					row["CodiceConto"] = (string)r["CodiceConto"] ;
					row["DataOraApertura"] = (DateTime)r["DataOraApertura"] ;
					if (r["StatoTransazione"].ToString() != "Inadempiente")
					{
						row["Corrispettivo"] = (decimal)r["QtyCertificati"] *  EuroXCertV ;
						row["QtyCertificati"] = (decimal)r["QtyCertificati"];
						row["QtyCertificatiInadempienti"] = 0m ;
					}
					else
					{
						row["Corrispettivo"] = 0m ;
						row["QtyCertificati"] = 0m ;
						row["QtyCertificatiInadempienti"] = (decimal)r["QtyCertificati"];
					}
					
					dtTemp.Rows.Add(row);
				}
				dsUnione.Tables.Add(dtTemp);

				// Ordino per CodiceConto l'unione degli Acquisti e delle Vendite
				DataRow[] dr = dsUnione.Tables[0].Select("", "CodiceConto");

				string CConto = "" ;
				foreach(DataRow r in dr)
				{
					if ( CConto != (string)r["CodiceConto"])
					{
						row = dt.NewRow();
						row["IdSessione"] = (string)r["IdSessione"] ;
						row["IdSocieta"] =  (string)r["IdSocieta"] ;
						row["Titolo"] = (string)r["Titolo"] ;
						row["RagioneSociale"] = (string)r["RagioneSociale"] ;
						row["CodiceConto"] = (string)r["CodiceConto"] ;
						row["DataOraApertura"] = (DateTime)r["DataOraApertura"] ;
						row["Corrispettivo"] = (decimal)r["Corrispettivo"] ;
						row["QtyCertificati"] = (decimal)r["QtyCertificati"];
						row["QtyCertificatiInadempienti"] = (decimal)r["QtyCertificatiInadempienti"];
						dt.Rows.Add(row);
					}
					else
					{
						dt.Rows[dt.Rows.Count-1]["Corrispettivo"] = (decimal)dt.Rows[dt.Rows.Count-1]["Corrispettivo"] + (decimal)r["Corrispettivo"] ;
						dt.Rows[dt.Rows.Count-1]["QtyCertificati"] = (decimal)dt.Rows[dt.Rows.Count-1]["QtyCertificati"] + (decimal)r["QtyCertificati"] ;
						dt.Rows[dt.Rows.Count-1]["QtyCertificatiInadempienti"] = (decimal)dt.Rows[dt.Rows.Count-1]["QtyCertificatiInadempienti"] + (decimal)r["QtyCertificatiInadempienti"] ;
					}
					CConto = (string)r["CodiceConto"] ;
				}

				dsAcquisti = new DataSet() ;
				dsVendite = new DataSet() ;
				dsUnione = new DataSet() ;
				dtTemp = new DataTable("Corrispettivi");
				dtTemp.Columns.Add(new DataColumn("IdSessione", typeof(string)));
				dtTemp.Columns.Add(new DataColumn("IdSocieta", typeof(string)));
				dtTemp.Columns.Add(new DataColumn("Titolo", typeof(string)));
				dtTemp.Columns.Add(new DataColumn("RagioneSociale", typeof(string)));
				dtTemp.Columns.Add(new DataColumn("CodiceConto", typeof(string)));
				dtTemp.Columns.Add(new DataColumn("DataOraApertura", typeof(DateTime)));
				dtTemp.Columns.Add(new DataColumn("Corrispettivo", typeof(decimal)));
				dtTemp.Columns.Add(new DataColumn("QtyCertificati", typeof(decimal)));
				dtTemp.Columns.Add(new DataColumn("QtyCertificatiInadempienti", typeof(decimal)));
			}

			ds.Tables.Add(dt);

			// Marco con la data attuale le Sessioni per cui ho calcolato i relativi Corrispettivi
			using (OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction))
			{
				cmd.CommandText = "UPDATE CV.Sessioni SET " +
					"DataCorrispettivo = ? " +
					"WHERE IdSessione = HEXTORAW(?) " ;
			
				CV.Admin.BLAdminCommon dbcomm = new CV.Admin.BLAdminCommon() ;
				DateTime TimeStamp = dbcomm.GetDBSystemDate();
				for (int i=0; i<IdSessioni.Length; i++)
				{
					cmd.Parameters.Clear();
					cmd.Parameters.Add("@DataCorrispettivo", OleDbType.Date).Value = TimeStamp ;
					cmd.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessioni[i];
					cmd.ExecuteNonQuery();
				}
			}

			// Restituisco il DataSet con i Corrispettivi
			return ds;
		}
	}
}
