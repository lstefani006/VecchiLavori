using System;
using System.Data;
using System.Diagnostics;
using System.Configuration;
using System.Globalization;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for BLAdminConferme.
	/// </summary>
	public class BLAdminConferme : CVRemotingBase, IBLAdminConferme
	{
		public BLAdminConferme()
		{
		}

		public string ConfermeAcquisti(DataSet dsSessione, DataSet dsBudget, string IdSocieta, string RagioneSociale, string PartitaIVA)
		{
			StringWriter sw = new StringWriter();
			ConfermeAcquisti(sw, dsSessione, dsBudget, IdSocieta, RagioneSociale, PartitaIVA);
			sw.Flush();
			return sw.GetStringBuilder().ToString();
		}

		public string ConfermeVenditori(DataSet dsSessione, string IdSocieta, string RagioneSociale, string PartitaIVA)
		{
			StringWriter sw = new StringWriter();
			ConfermeVenditori(sw, dsSessione, IdSocieta, RagioneSociale, PartitaIVA);
			sw.Flush();
			return sw.GetStringBuilder().ToString();
		}

		public void ConfermeAcquisti(IDbTransaction tr, TextWriter StreamOut, string IdSessione, string IdSocieta)
		{
			BLAdminSessione blsess = new BLAdminSessione();
			DataSet dsSessione = blsess.Retrieve(tr, IdSessione, "", "");

			BLAdminBudget blbudget = new BLAdminBudget();
			DataSet dsBudget = blbudget.Get(tr, IdSocieta, IdSessione);

			BLAdminSocieta blsoc = new BLAdminSocieta();
			DataSet dsSoc = blsoc.Retrieve_Parameters(tr, "RagioneSociale_CodiceConto");
			DataRow[] r = dsSoc.Tables[0].Select("IdSocieta = '" + IdSocieta + "'");
			string RagioneSociale = (string)r[0]["RagioneSociale"] ;
			string PartitaIVA = (string)r[0]["PartitaIVA"] ;
			ConfermeAcquisti(StreamOut, dsSessione, dsBudget, IdSocieta, RagioneSociale, PartitaIVA);
		}
			
		public void ConfermeVendite(IDbTransaction tr, TextWriter StreamOut, string IdSessione, string IdSocieta)
		{
			BLAdminSessione blsess = new BLAdminSessione();
			DataSet dsSessione = blsess.Retrieve(tr, IdSessione, "", "");

			BLAdminSocieta blsoc = new BLAdminSocieta();
			DataSet dsSoc = blsoc.Retrieve_Parameters(tr, "RagioneSociale_CodiceConto");
			DataRow[] r = dsSoc.Tables[0].Select("IdSocieta = '" + IdSocieta + "'");
			string RagioneSociale = (string)r[0]["RagioneSociale"] ;
			string PartitaIVA = (string)r[0]["PartitaIVA"] ;
			ConfermeVenditori(StreamOut, dsSessione, IdSocieta, RagioneSociale, PartitaIVA);
		}

		public void GeneraBodyHtmlAcq(TextWriter StreamOut, DataSet dsSessione, DataSet dsBudget, string IdSessione, string IdSocieta, string RagioneSociale, string PartitaIVA)
		{
			string Titolo =            (string)   dsSessione.Tables[0].Rows[0]["Titolo"];
			DateTime DataOraApertura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraApertura"];
			DateTime DataOraChiusura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraChiusura"];

			if (true)
			{
				StreamOut.WriteLine("<br><br>");
				StreamOut.WriteLine(
					"TITOLO SESSIONE: " + Titolo +
					" DATA ORA APERTURA: " + Converter.DateTimeToStringDateTime(DataOraApertura) +
					" DATA ORA CHIUSURA: " + Converter.DateTimeToStringDateTime(DataOraChiusura) + "<br><br>");
			}
			
			// 'Tabella relativa al Budgets dell'acquirente
			if (true)
			{
				DataRow drBudget = dsBudget.Tables[0].Rows[0];

				StreamOut.WriteLine("<table style='BORDER-COLLAPSE:collapse; HEIGHT:23px' border='2'>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Acquirente</b></td>");
				StreamOut.WriteLine("<td>" + RagioneSociale + "</td>");
				StreamOut.WriteLine("<td><b>Prezzo Convenzionale per certificato</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drBudget, "PrezzoConvenzionaleUtente") + "</td>");
				StreamOut.WriteLine("</tr>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td>  </td>");
				StreamOut.WriteLine("<td>  </td>");
				StreamOut.WriteLine("<td><b>Deposito in conto prezzo</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drBudget, "Importo") + "</td>");
				StreamOut.WriteLine("</tr>");
				StreamOut.WriteLine("</table><br>");
			}

			StreamOut.WriteLine("<b>Riepilogo delle operazioni di acquisto eseguite:</b>");

			BLAdminTransazioni bl = new BLAdminTransazioni();
			DataSet dsTransazioniPerAnno = null;
			DataTable dtTransazioniPerAnno = null;
			try
			{
				dsTransazioniPerAnno = bl.ListaOperazioniAcquistoPerAnno(IdSessione, IdSocieta);
				dtTransazioniPerAnno = dsTransazioniPerAnno.Tables[0];
			}
			catch (Exception e)
			{
				throw new Exception("Errore nel caricamento delle transazioni dal DB! Errore: " + e.Message);
			}

			// '-------------------------------------------------------------------------------
			// 'Visualizzaione delle Transazioni raggruppate per anno
			if (true)
			{
				StreamOut.WriteLine("<table style='BORDER-COLLAPSE:collapse; HEIGHT:23px' border='2'>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Anno Riferimento</b></td>");
				StreamOut.WriteLine("<td><b>Quantità TOT.</b></td>");
				StreamOut.WriteLine("<td><b>Prezzo Medio Acquisti</b></td>");
				StreamOut.WriteLine("<td><b>CTV coperto da deposito</b></td>");
				StreamOut.WriteLine("<td><b>CTV non coperto da deposito</b></td>");
				StreamOut.WriteLine("<td><b>CTV TOT.</b></td>");
				StreamOut.WriteLine("</tr>");

				decimal QTot = 0m;
				decimal CtvCopertoTot = 0m;
				decimal CtvNonCopertoTot = 0m;
				decimal CtvTotale = 0m;

				foreach (DataRow drTransazioniPerAnno in dtTransazioniPerAnno.Rows)
				{
					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td>" + Converter.StringToString(drTransazioniPerAnno, "AnnoRiferimento") + "</td>");
					StreamOut.WriteLine("<td>" + Converter.DecimalToIntegerString(drTransazioniPerAnno, "QTot") + "</td>");
					QTot += (decimal)drTransazioniPerAnno["QTot"];
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString((decimal)drTransazioniPerAnno["PMedioA"] + 0.001m) + "</td>");
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVCoperto") + "</td>");
					CtvCopertoTot += (decimal)drTransazioniPerAnno["CTVCoperto"];
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVNonCoperto") + "</td>");
					CtvNonCopertoTot += (decimal)drTransazioniPerAnno["CTVNonCoperto"];
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVTot") + "</td>");
					CtvTotale += (decimal)drTransazioniPerAnno["CTVTot"];
					StreamOut.WriteLine("</tr>");
				}
				
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>TOTALE</b></td>");
				StreamOut.WriteLine("<td><b>" + Converter.DecimalToIntegerString(QTot) + "</b></td>");
				StreamOut.WriteLine("<td><b>  </b></td>");
				StreamOut.WriteLine("<td><b>" + Converter.DecimalToCurrencyString(CtvCopertoTot) + "</b></td>");
				StreamOut.WriteLine("<td><b>" + Converter.DecimalToCurrencyString(CtvNonCopertoTot) + "</b></td>");
				StreamOut.WriteLine("<td><b>" + Converter.DecimalToCurrencyString(CtvTotale) + "</b></td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("</table><br>");
			}


			// '--------------------------------------------------------------------------------
			// 'Transazioni raggruppate per venditore

			DataSet dsTransazioniPerVenditore = null;
			try
			{
				dsTransazioniPerVenditore = bl.ListaOperazioniAcquistoPerVenditore(IdSessione, IdSocieta);
			}
			catch (Exception e)
			{
				throw new Exception("Errore nel caricamento delle transazioni dal DB! Errore: " + e.Message);
			}
			DataTable dtTransazioniPerVenditore = dsTransazioniPerVenditore.Tables[0];

			if (true)
			{
				StreamOut.WriteLine("<table style='BORDER-COLLAPSE:collapse; HEIGHT:23px' border='2'>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Acquirente</b></td>");
				StreamOut.WriteLine("<td><b>Venditore</b></td>");
				StreamOut.WriteLine("<td><b>CTV da pagare</b></td>");
				StreamOut.WriteLine("</tr>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td>" + RagioneSociale + "</td>");
				StreamOut.WriteLine("<td></td>");
				StreamOut.WriteLine("<td></td>");
				StreamOut.WriteLine("</tr>");

				foreach (DataRow drTransazioniPerVenditore in dtTransazioniPerVenditore.Rows)
				{
					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td></td>");
					StreamOut.WriteLine("<td>" + Converter.StringToString(drTransazioniPerVenditore,"RagioneSocialeVenditore") + "</td>");
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drTransazioniPerVenditore, "CTVDaPagare") + "</td>");
					StreamOut.WriteLine("</tr>");
				}

				StreamOut.WriteLine("</table><br>");
			}

			StreamOut.WriteLine("<b>Dettaglio delle singole operazioni:</b>");

			// '--------------------------------------------------------------------------------
			// 'Dettaglio delle Transazioni
			DataSet dsDettaglioTransazioni = null;
			try
			{
				dsDettaglioTransazioni = bl.DettagliAcquisti(IdSessione, IdSocieta);
			}
			catch (Exception e)
			{
				throw new Exception("Errore nel caricamento dei dettagli delle transazioni dal DB! Errore: " + e.Message);
			}
			DataTable dtDettaglioTransazioni = dsDettaglioTransazioni.Tables[0];

			if (dtDettaglioTransazioni.Rows.Count == 0)
			{
				StreamOut.WriteLine("<br><b>Non ci sono operazioni!</b><br>");
			}

			foreach (DataRow drDettaglioTransazioni in dtDettaglioTransazioni.Rows)
			{
				StreamOut.WriteLine("<table style='BORDER-COLLAPSE:collapse; HEIGHT:23px' border='2'>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>IdTransazione</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "IdTransazione") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>IdOffertaAcquisto</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "IdOffertaAcquisto") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Data Ora Operazione</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DateTimeToStringDateTime(drDettaglioTransazioni, "DataOraOperazione") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Anno Riferimento</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "AnnoRiferimento") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Quantità eseguita</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToIntegerString(drDettaglioTransazioni, "QtyEseguita") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Prezzo eseguito</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drDettaglioTransazioni, "PrezzoEseguito") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Controvalore</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTV") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Controvalore coperto da deposito</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTVDeposito") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Ragione Sociale Venditore</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "RagioneSocialeVenditore") + "</td>");
				//				if ((decimal)drDettaglioTransazioni["CTVNonDeposito"] == 0m)
				//				{
				//					StreamOut.WriteLine("<td></td>");
				//				}
				//				else
				//				{
				//					StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "RagioneSocialeVenditore") + "</td>");
				//				}				
				StreamOut.WriteLine("</tr>");

				if ((decimal)drDettaglioTransazioni["CTVNonDeposito"] == 0m)
				{
					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td><b>ABI</b></td>");
					StreamOut.WriteLine("<td></td>");
					StreamOut.WriteLine("</tr>");

					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td><b>CAB</b></td>");
					StreamOut.WriteLine("<td></td>");
					StreamOut.WriteLine("</tr>");

					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td><b>CC</b></td>");
					StreamOut.WriteLine("<td></td>");
					StreamOut.WriteLine("</tr>");
				}
				else
				{
					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td><b>ABI</b></td>");
					StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "ABI") + "</td>");
					StreamOut.WriteLine("</tr>");

					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td><b>CAB</b></td>");
					StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "CAB") + "</td>");
					StreamOut.WriteLine("</tr>");

					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td><b>CC</b></td>");
					StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "CC") + "</td>");
					StreamOut.WriteLine("</tr>");
				}

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Controvalore non coperto da deposito</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTVNonDeposito") + "</td>");
				StreamOut.WriteLine("</tr>");
				
				StreamOut.WriteLine("</table><br>");
			}
		}

		public void GeneraBodyHtmlVen(TextWriter StreamOut, DataSet dsSessione, string IdSessione, string IdSocieta, string RagioneSociale, string PartitaIVA)
		{
			string Titolo =            (string)   dsSessione.Tables[0].Rows[0]["Titolo"];
			DateTime DataOraApertura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraApertura"];
			DateTime DataOraChiusura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraChiusura"];

			if (true)
			{
				StreamOut.WriteLine("<br><br>");
				StreamOut.WriteLine(
					"TITOLO SESSIONE: " + Titolo +
					" DATA ORA APERTURA: " + Converter.DateTimeToStringDateTime(DataOraApertura) +
					" DATA ORA CHIUSURA: " + Converter.DateTimeToStringDateTime(DataOraChiusura) + "<br><br>");
			}

			// 'Tabella relativa al venditore
			if (true)
			{
				StreamOut.WriteLine("<table style='BORDER-COLLAPSE:collapse; HEIGHT:23px' border='2'>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Venditore</b></td>");
				StreamOut.WriteLine("<td>" + RagioneSociale + "</td>");
				StreamOut.WriteLine("</tr>");
				StreamOut.WriteLine("</table><br>");
			}

			StreamOut.WriteLine("<b>Riepilogo delle operazioni di vendita eseguite:</b>");
			
			// TODO versione bloccante
			BLAdminTransazioni bl = null;
			DataSet dsTransazioniPerAnno = null;
			DataTable dtTransazioniPerAnno = null;
			try
			{
				bl = new BLAdminTransazioni();
				dsTransazioniPerAnno = bl.ListaOperazioniVenditaPerAnno(IdSessione, IdSocieta);
				dtTransazioniPerAnno = dsTransazioniPerAnno.Tables[0];
			}
			catch (Exception e)
			{
				throw new Exception("Errore nel caricamento delle transazioni dal DB! Errore: " + e.Message);
			}

			// '-------------------------------------------------------------------------------
			// 'Visualizzaione delle Transazioni raggruppate per anno
			if (true)
			{
				StreamOut.WriteLine("<table style='BORDER-COLLAPSE:collapse; HEIGHT:23px' border='2'>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Anno Riferimento</b></td>");
				StreamOut.WriteLine("<td><b>Quantità TOT.</b></td>");
				StreamOut.WriteLine("<td><b>Prezzo Medio Vendita</b></td>");
				StreamOut.WriteLine("<td><b>CTV coperto da deposito</b></td>");
				StreamOut.WriteLine("<td><b>CTV non coperto da deposito</b></td>");
				StreamOut.WriteLine("<td><b>CTV TOT.</b></td>");
				StreamOut.WriteLine("</tr>");
				
				decimal QTot = 0m;
				decimal CtvCopertoTot = 0m;
				decimal CtvNonCopertoTot = 0m;
				decimal CtvTotale = 0m;

				foreach (DataRow drTransazioniPerAnno in dtTransazioniPerAnno.Rows)
				{
					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td>" + Converter.StringToString(drTransazioniPerAnno, "AnnoRiferimento") + "</td>");
					StreamOut.WriteLine("<td>" + Converter.DecimalToIntegerString(drTransazioniPerAnno, "QTot") + "</td>");
					QTot += (decimal)drTransazioniPerAnno["QTot"];
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString((decimal)drTransazioniPerAnno["PMedioV"] + 0.001m) + "</td>");
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVCoperto") + "</td>");
					CtvCopertoTot += (decimal)drTransazioniPerAnno["CTVCoperto"];
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVNonCoperto") + "</td>");
					CtvNonCopertoTot += (decimal)drTransazioniPerAnno["CTVNonCoperto"];
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drTransazioniPerAnno, "CTVTot") + "</td>");
					CtvTotale += (decimal)drTransazioniPerAnno["CTVTot"];
					StreamOut.WriteLine("</tr>");
				}

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>TOTALE</b></td>");
				StreamOut.WriteLine("<td><b>" + Converter.DecimalToIntegerString(QTot) + "</b></td>");
				StreamOut.WriteLine("<td><b>  </b></td>");
				StreamOut.WriteLine("<td><b>" + Converter.DecimalToCurrencyString(CtvCopertoTot) + "</b></td>");
				StreamOut.WriteLine("<td><b>" + Converter.DecimalToCurrencyString(CtvNonCopertoTot) + "</b></td>");
				StreamOut.WriteLine("<td><b>" + Converter.DecimalToCurrencyString(CtvTotale) + "</b></td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("</table><br>");
			}

			// '--------------------------------------------------------------------------------
			// 'Transazioni raggruppate per Acquirente

			DataSet   dsTransazioniPerAcquirente = bl.ListaOperazioniVenditaPerAcquirente(IdSessione, IdSocieta);
			DataTable dtTransazioniPerAcquirente = dsTransazioniPerAcquirente.Tables[0];

			if (true)
			{
				StreamOut.WriteLine("<table style='BORDER-COLLAPSE:collapse; HEIGHT:23px' border='2'>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Venditore</b></td>");
				StreamOut.WriteLine("<td><b>Acquirente</b></td>");
				StreamOut.WriteLine("<td><b>CTV da ricevere</b></td>");
				StreamOut.WriteLine("</tr>");
				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td>" + RagioneSociale + "</td>");
				StreamOut.WriteLine("<td></td>");
				StreamOut.WriteLine("<td></td>");
				StreamOut.WriteLine("</tr>");

				foreach (DataRow drTransazioniPerAcquirente in dtTransazioniPerAcquirente.Rows)
				{
					StreamOut.WriteLine("<tr>");
					StreamOut.WriteLine("<td></td>");
					StreamOut.WriteLine("<td>" + Converter.StringToString(drTransazioniPerAcquirente, "RagioneSocialeAcquirente") + "</td>");
					StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drTransazioniPerAcquirente, "CTVDaRicevere") + "</td>");
					StreamOut.WriteLine("</tr>");
				}

				StreamOut.WriteLine("</table><br>");
			}

			StreamOut.WriteLine("<b>Dettaglio delle singole operazioni:</b>");

			// '--------------------------------------------------------------------------------
			// 'Dettaglio delle Transazioni
			DataSet dsDettaglioTransazioni = bl.DettagliVendite(IdSessione, IdSocieta);
			DataTable dtDettaglioTransazioni = dsDettaglioTransazioni.Tables[0];

			if (dtDettaglioTransazioni.Rows.Count == 0)
			{
				StreamOut.WriteLine("<br><b>Non ci sono operazioni!</b><br>");
			}

			foreach (DataRow drDettaglioTransazioni in dtDettaglioTransazioni.Rows)
			{			
				StreamOut.WriteLine("<table style='BORDER-COLLAPSE:collapse; HEIGHT:23px' border='2'>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>IdTransazione</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "IdTransazione") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>IdOffertaVendita</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "IdOffertaVendita") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Data Ora Operazione</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DateTimeToStringDateTime(drDettaglioTransazioni, "DataOraOperazione") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Anno Riferimento</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "AnnoRiferimento") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Quantità eseguita</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToIntegerString(drDettaglioTransazioni, "QtyEseguita") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Prezzo eseguito</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drDettaglioTransazioni, "PrezzoEseguito") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Controvalore</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTV") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Controvalore coperto da deposito</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTVDeposito") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Controvalore non coperto da deposito</b></td>");
				StreamOut.WriteLine("<td>" + Converter.DecimalToCurrencyString(drDettaglioTransazioni, "CTVNonDeposito") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Ragione Sociale Acquirente</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "RagioneSocialeAcquirente") + "</td>");
				//				if ((decimal)drDettaglioTransazioni["CTVNonDeposito"] == 0m)
				//				{
				//					StreamOut.WriteLine("<td></td>");
				//				}
				//				else
				//				{
				//					StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "RagioneSocialeAcquirente") + "</td>");
				//				}				
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("<tr>");
				StreamOut.WriteLine("<td><b>Partita IVA Acquirente</b></td>");
				StreamOut.WriteLine("<td>" + Converter.StringToString(drDettaglioTransazioni, "PartitaIVAAcquirente") + "</td>");
				StreamOut.WriteLine("</tr>");

				StreamOut.WriteLine("</table><br>");
			}
		}

		public void ConfermeAcquisti(IDbTransaction tr, TextWriter StreamOut, string IdSessione)
		{
			StreamOut.WriteLine("<html>");
			StreamOut.WriteLine("<head>");
			StreamOut.WriteLine("<META http-equiv='Content-Type' content='text/html; charset=utf-8'>");
			StreamOut.WriteLine("<title>Conferma Acquirenti</title>");
			StreamOut.WriteLine("</head>");
			StreamOut.WriteLine("<body>");
			StreamOut.WriteLine("<IMG HEIGHT='110px' WIDTH='200px' SRC='gme_logo.jpg'>");
			StreamOut.WriteLine("<h2>CONFERMA ACQUIRENTI</h2><br><br>");
			
			BLAdminSessione blsess = new BLAdminSessione();
			DataSet dsSessione = blsess.Retrieve(tr, IdSessione, "", "");

			BLAdminSocieta blsoc = new BLAdminSocieta();
			DataSet dsSoc = blsoc.Retrieve_Parameters(tr, "RagioneSociale_CodiceConto");
			
			string RagioneSociale = "" ;
			string PartitaIVA = "" ;
			string IdSocieta = "" ;
			BLAdminBudget blbudget = null ;
			DataSet dsBudget = null ;
			foreach(DataRow r in dsSoc.Tables[0].Rows)
			{
				RagioneSociale = (string)r["RagioneSociale"] ;
				PartitaIVA = (string)r["PartitaIVA"] ;
				IdSocieta = (string)r["IdSocieta"] ;

				blbudget = new BLAdminBudget();
				dsBudget = blbudget.Get(tr, IdSocieta, IdSessione);
				if (dsBudget.Tables[0].Rows.Count == 0)
					continue;


				// Genera parte html relativa alla societa corrente
				GeneraBodyHtmlAcq(StreamOut, dsSessione, dsBudget, IdSessione, IdSocieta, RagioneSociale, PartitaIVA);
				// Fine generazione parte html relativa alla societa corrente
			}

			StreamOut.WriteLine("</body>");
			StreamOut.WriteLine("</html>");
		}
		
		public void ConfermeVendite(IDbTransaction tr, TextWriter StreamOut, string IdSessione)
		{
			StreamOut.WriteLine("<html>");
			StreamOut.WriteLine("<head>");
			StreamOut.WriteLine("<META http-equiv='Content-Type' content='text/html; charset=utf-8'>");
			StreamOut.WriteLine("<title>Conferma Venditori</title>");
			StreamOut.WriteLine("</head>");
			StreamOut.WriteLine("<body>");
			StreamOut.WriteLine("<IMG HEIGHT='110px' WIDTH='200px' SRC='gme_logo.jpg'>");
			StreamOut.WriteLine("<h2>CONFERMA VENDITORI</h2><br><br>");
			
			BLAdminSessione blsess = new BLAdminSessione();
			DataSet dsSessione = blsess.Retrieve(tr, IdSessione, "", "");

			BLAdminSocieta blsoc = new BLAdminSocieta();
			DataSet dsSoc = blsoc.Retrieve_Parameters(tr, "RagioneSociale_CodiceConto");
			
			string RagioneSociale = "" ;
			string PartitaIVA = "" ;
			string IdSocieta = "" ;
			foreach(DataRow r in dsSoc.Tables[0].Rows)
			{
				RagioneSociale = (string)r["RagioneSociale"] ;
				PartitaIVA = (string)r["PartitaIVA"] ;
				IdSocieta = (string)r["IdSocieta"] ;

				// Genera parte html relativa alla societa corrente
				GeneraBodyHtmlVen(StreamOut, dsSessione, IdSessione, IdSocieta, RagioneSociale, PartitaIVA);
				// Fine generazione parte html relativa alla societa corrente
			}

			StreamOut.WriteLine("</body>");
			StreamOut.WriteLine("</html>");
		}

		public void ConfermeVenditori(TextWriter StreamOut, DataSet dsSessione, string IdSocieta, string RagioneSociale, string PartitaIVA)
		{
			string IdSessione =        (string)   dsSessione.Tables[0].Rows[0]["IdSessione"];
			string Titolo =            (string)   dsSessione.Tables[0].Rows[0]["Titolo"];
			DateTime DataOraApertura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraApertura"];
			DateTime DataOraChiusura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraChiusura"];

			StreamOut.WriteLine("<html>");
			StreamOut.WriteLine("<head>");
			StreamOut.WriteLine("<META http-equiv='Content-Type' content='text/html; charset=utf-8'>");
			StreamOut.WriteLine("<title>Conferma Venditori</title>");
			StreamOut.WriteLine("</head>");
			StreamOut.WriteLine("<body>");
			StreamOut.WriteLine("<IMG HEIGHT='110px' WIDTH='200px' SRC='gme_logo.jpg'>");
			StreamOut.WriteLine("<h2>CONFERMA VENDITORI</h2><br><br>");

			GeneraBodyHtmlVen(StreamOut, dsSessione, IdSessione, IdSocieta, RagioneSociale, PartitaIVA);

			StreamOut.WriteLine("</body>");
			StreamOut.WriteLine("</html>");
		}

		public void ConfermeAcquisti(TextWriter StreamOut, DataSet dsSessione, DataSet dsBudget, string IdSocieta, string RagioneSociale, string PartitaIVA)
		{
			string IdSessione =        (string)   dsSessione.Tables[0].Rows[0]["IdSessione"];
			string Titolo =            (string)   dsSessione.Tables[0].Rows[0]["Titolo"];
			DateTime DataOraApertura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraApertura"];
			DateTime DataOraChiusura = (DateTime) dsSessione.Tables[0].Rows[0]["DataOraChiusura"];

			StreamOut.WriteLine("<html>");
			StreamOut.WriteLine("<head>");
			StreamOut.WriteLine("<META http-equiv='Content-Type' content='text/html; charset=utf-8'>");
			StreamOut.WriteLine("<title>Conferma Acquirenti</title>");
			StreamOut.WriteLine("</head>");
			StreamOut.WriteLine("<body>");
			StreamOut.WriteLine("<IMG HEIGHT='110px' WIDTH='200px' SRC='gme_logo.jpg'>");
			StreamOut.WriteLine("<h2>CONFERMA ACQUIRENTI</h2><br><br>");

			GeneraBodyHtmlAcq(StreamOut, dsSessione, dsBudget, IdSessione, IdSocieta, RagioneSociale, PartitaIVA);

			StreamOut.WriteLine("</body>");
			StreamOut.WriteLine("</html>");
		}
	}
}
