using System;
using System.Data;
using System.Xml;
using System.Text;
using System.IO;
using System.Data.OleDb;
using System.Diagnostics;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for BLAdminCertificatiVerdi.
	/// </summary>
	public class BLAdminCertificatiVerdi : CVRemotingBase, IBLAdminCertificatiVerdi
	{
		public BLAdminCertificatiVerdi()
		{
		}

		/// <summary>
		/// A partire da un IdSesione e da una stringa in formato xml
		/// importa uno o pi� certificati verdi su db - restituisce una
		/// stringa in formato xml nella quale sono segnati i numero di record 
		/// processati, caricati e scartati e il contenuto dei record scartati
		/// (se ce ne sono stati) in caso di errore viene sollevata un'eccezione
		/// lasciata da gestire al chiamante
		/// </summary>
		public string ImportData( string IdSessione, string inXmlStream )
		{
			
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();


				try
				{
					// questo il formato xml dello stream in ingresso
					// <INVIO_ECV>
					// <CONTO NUMERO_CONTO="000002210/02/2003 08:00:00A241515D_TIT" RAG_SOCIALE="324" NUMERO_CV="200" ANNO_VALIDITA="2002" />
					// ...
					// </INVIO_ECV>
					XmlDocument XmlDocIn = new XmlDocument();
					XmlDocument XmlDocOut = new XmlDocument();
					

					XmlDocOut.AppendChild( XmlDocOut.CreateElement("INVIO_ECV") );

					XmlDocOut.InsertBefore( 
						XmlDocOut.CreateXmlDeclaration("1.0", "UTF-8", null), 
						XmlDocOut.DocumentElement );
					
					
					XmlDocIn.LoadXml(inXmlStream);

					DLAdminCertificatoVerde cv = new DLAdminCertificatoVerde(dbTran);
					DataSet dsCertificatiVerdi   = cv.GetCertificatiVerdiBySessione(IdSessione);
					DataTable dtCertificatiVerdi = dsCertificatiVerdi.Tables["CertificatiVerdi"];

					XmlNodeList nodeList =  XmlDocIn.GetElementsByTagName("CONTO");
					
					long recAdded = 0, recRead = 0, recDiscarded = 0;
					string IdSocieta = "";
					string Prev_NumeroConto = "";

					// per ogni elemento <CONTO>
					for(int idx = 0; idx < nodeList.Count; idx++)
					{
						// recupero NUMERO_CONTO, RAG_SOCIALE, NUMERO_CV, ANNO_VALIDITA
						XmlAttributeCollection attrColl = nodeList.Item(idx).Attributes;
						
						string NumeroConto = ((XmlAttribute)attrColl.GetNamedItem("NUMERO_CONTO")).Value;
						string RagioneSociale = ((XmlAttribute)attrColl.GetNamedItem("RAG_SOCIALE")).Value;
						string NumeroCertificati = ((XmlAttribute)attrColl.GetNamedItem("NUMERO_CV")).Value;
						string AnnoValidita = ((XmlAttribute)attrColl.GetNamedItem("ANNO_VALIDITA")).Value;

						recRead++;
					
						// NumeroConto e` del tipo 000000110/02/2003 08:00:00A241515D_TIT
						// per ragioni sconosciute si considerano solo i primi 7 caratteri
						// (0000001 ossia si toglie il 10 finale)
						// per poi togliere gli zeri in testa (TrimStart)
						// per ottenere il nostro CodiceConto

						// DLAdminSocieta soc = new DLAdminSocieta(dbTran);
						//char [] par = new Char[1];
						//par[0] = '0';
						//DataSet dsSocieta = soc.RetrieveByCodiceConto(NumeroConto.Substring(0, 7).TrimStart(par));
						if (NumeroConto != Prev_NumeroConto)
						{
							// il numero conto e` cambiato dalla precedente riga --> sono in un'altra societa
						
							IdSocieta = null;

							char [] par = new char[1];
							par[0] = '0';
							string nc = NumeroConto.Substring(0, 7).TrimStart(par);

							using (OleDbCommand cmd = new OleDbCommand("", (OleDbConnection)dbTran.Connection, (OleDbTransaction)dbTran))
							{
								cmd.CommandType = CommandType.Text;
								cmd.CommandText = "select RAWTOHEX(IdSocieta) from US.SOCIETA where CodiceConto=? ";
								cmd.Parameters.Add("CodiceConto", OleDbType.VarChar).Value = nc;
								using(OleDbDataReader rd = cmd.ExecuteReader())
								{
									// ne devo leggere uno solo!!
									while (rd.Read())
										IdSocieta = (string)rd[0];
								}
							}
						}

						Debug.WriteLine(string.Format("{0}/{1} {2} - {3}", idx, nodeList.Count, NumeroConto, IdSocieta));

						// verifico se esiste una Societ� dato il NUMERO_CONTO
						// if( dsSocieta.Tables["Societa"].Rows.Count > 0 )
						if (IdSocieta != null)
						{
							// IdSocieta = dsSocieta.Tables["Societa"].Rows[0]["IdSocieta"].ToString();

							if (Prev_NumeroConto != NumeroConto)
							{
								// qui si fa update del campo ChiaveContoProprieta della societa` IdSocieta
								// soc.UpdChiaveCodiceConto(IdSocieta, NumeroConto);
								using (OleDbCommand cmd = new OleDbCommand("", (OleDbConnection)dbTran.Connection, (OleDbTransaction)dbTran))
								{
									cmd.CommandType = CommandType.Text;
									cmd.CommandText = "UPDATE US.SOCIETA SET ChiaveContoProprieta=? where IdSocieta=HEXTORAW(?)";
									cmd.Parameters.Add("ChiaveContoProprieta", OleDbType.VarChar).Value = NumeroConto;
									cmd.Parameters.Add("IdSocieta", OleDbType.VarChar).Value = IdSocieta;
									cmd.ExecuteNonQuery();
								}

								// qui cancello la societa` dalla tabella dei NonIscritti
								// qualora fosse gia` qui per questa sessione
								// fa una DELETE diretta
								cv.CancellaSocietaDaNonIscritti(IdSessione, NumeroConto);
							}


							// aggiungo il CertificatoVerde utilizzando l'IdSocieta recuperato precedentemente

							// qui e` un po' stupido: prima cancello poi riscrivo.
							// In condizioni normali ossia al primo import del file per la sessione
							// non c'e` niente da cancellare per la sessione
							DataRow [] drCV = dtCertificatiVerdi.Select("IdSocieta = '" + IdSocieta + "' AND AnnoRiferimento = '" + AnnoValidita + "'");
							for (int rr = 0 ; rr < drCV.Length; rr++)
								drCV[rr].Delete();


							//BLAdminCommon cmn = new BLAdminCommon();
							DataRow drCertificatiVerdi = dtCertificatiVerdi.NewRow();
							drCertificatiVerdi["IdCertificatoVerde"] = DLAdminCommon.NewId(cn,dbTran);
							drCertificatiVerdi["AnnoRiferimento"] = AnnoValidita;
							drCertificatiVerdi["Qty"] = NumeroCertificati;
							drCertificatiVerdi["QtyImpegnata"] = 0m;
							drCertificatiVerdi["DataOraCreazione"] = DateTime.Now;
							drCertificatiVerdi["IdSessione"] = IdSessione;
							drCertificatiVerdi["IdSocieta"] = IdSocieta;
							dtCertificatiVerdi.Rows.Add(drCertificatiVerdi);

							recAdded++;
						}
						else
						{
							// inserisco l'elemento CONTO tra quelli scartati
							XmlNode newItem = XmlDocOut.ImportNode( nodeList.Item(idx), true );
							XmlDocOut.DocumentElement.AppendChild( newItem );

							if (Prev_NumeroConto != NumeroConto)
							{
								// qui cancello la societa` dalla tabella dei NonIscritti...
								// al massimo non esiste.
								// cv.CancellaSocietaDaNonIscritti(IdSessione, NumeroConto);
							
								// per poi rimetterla nella tabella
								// cv.SalvaConto(IdSessione, NumeroConto, RagioneSociale);
								cv.UpdateOrInsertNonIscritti(IdSessione, NumeroConto, RagioneSociale);
							}
							
							recDiscarded++;
						}

						// ricordo il record precedente per il prossimo record.
						Prev_NumeroConto = NumeroConto;
					}

					if( recAdded > 0 )
					{
						cv.Update(dsCertificatiVerdi);

						// aggiorno a predisposta la sessione
						DLAdminSessione sessione = new DLAdminSessione(dbTran);
						sessione.UpdateToPredisposta(IdSessione);
					}

					// aggiungo un elemento con tre attributi relativi al risultato
					XmlElement resNode = XmlDocOut.CreateElement("RESULT");

					XmlAttribute attr = XmlDocOut.CreateAttribute("REC_READ");
					attr.Value = XmlConvert.ToString(recRead);
					resNode.Attributes.Append( attr );

					attr = XmlDocOut.CreateAttribute("REC_ADDED");
					attr.Value = XmlConvert.ToString(recAdded);
					resNode.Attributes.Append( attr );

					attr = XmlDocOut.CreateAttribute("REC_DISCARDED");
					attr.Value = XmlConvert.ToString(recDiscarded);
					resNode.Attributes.Append( attr );
				
					XmlDocOut.DocumentElement.AppendChild( resNode );


					dbTran.Commit();
					
					// restituisco il documento in uscita come stringa
					return XmlDocOut.InnerXml;
				}
				catch(XmlException xmlex)
				{
					dbTran.Rollback();
					throw new Exception(xmlex.Message + "Linea: " + xmlex.LineNumber, xmlex.InnerException);
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}

			}
			
		}

	
		public DataSet GetExportData(IDbTransaction tr, string IdSessione)
		{
			BLAdminTransazione bl = new BLAdminTransazione();
			DataSet ds = bl.ExportXMLTransazioni(tr, IdSessione);
			DataSet ds1 = bl.ContiDaSbloccare(tr, IdSessione);

			ds.Tables.Add(ds1.Tables[0].Copy());

			return ds;
		}
		public DataSet GetExportData(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DataSet ds = this.GetExportData(tr, IdSessione);
					tr.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
	}
}
