using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for BLAdminCertificatoVerde.
	/// </summary>
	public class BLAdminCertificatoVerde : CVRemotingBase, IBLAdminCertificatoVerde
	{
		public BLAdminCertificatoVerde()
		{
		}

		public void Update(DataSet ds)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					Update(dbTran, ds);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public void Update(IDbTransaction dbTran, DataSet ds)
		{
			DLAdminCertificatoVerde dl = new DLAdminCertificatoVerde(dbTran);
			dl.Update(ds);
			return;
		}

#if VECCHIO_MWCERTIFICATO //Stefano
		public DataSet RetrieveMwCertificato()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _RetrieveMwCertificato(dbTran);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet _RetrieveMwCertificato(IDbTransaction tr)
		{
			DLAdminCertificatoVerde dl = new DLAdminCertificatoVerde(tr);
			return dl.RetrieveMwCertificato();
		}

		public void UpdateMwCertificato(DataSet ds)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					_UpdateMwCertificato(dbTran, ds);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		
		public void _UpdateMwCertificato(IDbTransaction tr, DataSet ds)
		{
			DLAdminCertificatoVerde dl = new DLAdminCertificatoVerde(tr);
			dl.UpdateMwCertificato(ds);
			return;
		}
#endif
	}
}
