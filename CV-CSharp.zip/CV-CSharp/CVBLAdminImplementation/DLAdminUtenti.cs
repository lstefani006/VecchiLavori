using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminUtenti.
	/// </summary>
	internal class DLAdminUtenti : DLAdminBase
	{
		public DLAdminUtenti(IDbTransaction dbTransaction) : base(dbTransaction)
		{
		}

		public bool Login(string User, string Pwd, string TipoUtente)
		{
			Pwd = Encrypt(Pwd);

			OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
			cmd.CommandText = 
				"SELECT COUNT(*) " + 
				"FROM US.Utenti " +
				"WHERE Nominativo=? " +
				"AND DN=? " +  // OK Crypt
				"AND StatoUtente='Valido' " +
				"AND TipoUtente=? ";

			cmd.Parameters.Add("Nominativo", OleDbType.VarChar).Value = User;
			cmd.Parameters.Add("DN", OleDbType.VarChar).Value = Pwd; // OK Crypt
			cmd.Parameters.Add("TipoUtente", OleDbType.VarChar).Value = TipoUtente;

			if ((decimal)cmd.ExecuteScalar() == 0m)
				return false;

			return true;
		}

		public bool Login(string DN, string TipoUtente) // OK Crypt
		{
			DN = Encrypt(DN); // OK Crypt

			OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
			cmd.CommandText = 
				"SELECT COUNT(*) " + 
				"FROM US.Utenti " +
				"WHERE DN=? " + // OK Crypt
				"AND StatoUtente='Valido' " + 
				"AND TipoUtente=?";

			cmd.Parameters.Add("DN", OleDbType.VarChar).Value = DN; // OK Crypt
			cmd.Parameters.Add("TipoUtente", OleDbType.VarChar).Value = TipoUtente; // OK Crypt

			if ((decimal)cmd.ExecuteScalar() == 0m)
				return false;

			return true;
		}

		public DataSet Retrieve(string Nominativo, string CodiceFiscale)
		{
			OleDbDataAdapter da = null;
			if ((Nominativo == String.Empty) && (CodiceFiscale == String.Empty))
			{
				da = GetDataAdapter();
			}
			else if (Nominativo == String.Empty)
			{
				OleDbParameter par = new OleDbParameter("CodiceFiscale", OleDbType.VarChar);
				par.Value = CodiceFiscale;

				string sql = "WHERE CodiceFiscale = ?";
				da = GetDataAdapter(sql, par);
			}
			else if (CodiceFiscale == String.Empty)
			{
				OleDbParameter par = new OleDbParameter("Nominativo", OleDbType.VarChar);
				par.Value = Nominativo;

				string sql = "WHERE Nominativo = ?";
				da = GetDataAdapter(sql, par);
			}
			else
			{
				OleDbParameter [] pars = new OleDbParameter[2];
				pars[0] = new OleDbParameter("CodiceFiscale", OleDbType.VarChar);
				pars[0].Value = CodiceFiscale;

				pars[1] = new OleDbParameter("Nominativo", OleDbType.VarChar);
				pars[1].Value = Nominativo;

				string sql = "WHERE CodiceFiscale = ? AND Nominativo = ?";
				da = GetDataAdapter(sql, pars);
			}

			DataSet ds = DataSet_Utenti();
			da.Fill(ds, "Utenti");

			if (MustCrypt)
			{
				foreach (DataRow dr in ds.Tables["Utenti"].Rows)
				{
					string DN = (string)dr["DN"]; // OK Crypt
					dr["DN"] = Decrypt(DN); // OK Crypt
				}
				ds.AcceptChanges();
			}
			da.Dispose();
			return ds;
		}

		private OleDbDataAdapter GetDataAdapter()
		{
			return GetDataAdapter(null, (OleDbParameter [])null);
		}

		private OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere)
		{
			OleDbParameter [] pars = new OleDbParameter [1];
			pars[0] = parWhere;
			return GetDataAdapter(sql, pars);
		}

		private OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere1, OleDbParameter parWhere2)
		{
			OleDbParameter [] pars = new OleDbParameter [2];
			pars[0] = parWhere1;
			pars[1] = parWhere2;
			return GetDataAdapter(sql, pars);
		}

		private OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			// Query di SELECT per il Data Adapter
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				// N.B. Lo spazio alla fine della stringa e' MOLTO IMPORTANTE non toglierlo!!!!!
				string sqlCmd = @"
					SELECT 
						RAWTOHEX(IdUtente)    AS IdUtente,
						U.Nominativo          AS Nominativo,
						U.CodiceFiscale       AS CodiceFiscale,
						U.Telefono            AS Telefono,
						U.Fax                 AS Fax,
						U.Email               AS Email,
						U.DN                  AS DN, 
						U.DataOraInserimento  AS DataOraInserimento,
						U.DataOraModifica     AS DataOraModifica,
						RAWTOHEX(U.IdSocieta) AS IdSocieta,
						RAWTOHEX(U.IdRichiestaRegUtente) AS IdRichiestaRegUtente,
						U.TipoUtente          AS TipoUtente,
						U.StatoUtente         AS StatoUtente,
						S.RagioneSociale      AS RagioneSociale,
						S.CodiceConto         AS CodiceConto
					FROM US.Utenti U, US.Societa S "; 

				if (sql != null && sql.Length > 0)
				{
					sqlCmd += sql;
					sqlCmd += " AND U.IdSocieta = S.IdSocieta ";
				}
				else
				{
					sqlCmd += " WHERE U.IdSocieta = S.IdSocieta ";
				}


				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// Update
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				string sqlCmd = "UPDATE US.Utenti SET " +
					"Nominativo = ?, " +
					"CodiceFiscale = ?, " +
					"Telefono = ?, " +
					"FAX = ?, " +
					"Email = ?, " +
					//								"DN = ?, " +  // OK cript non si fa mai l'update del DN
					"DataOraInserimento = ?, " +
					"DataOraModifica = ?, " +
					"TipoUtente = ?, " +
					"StatoUtente = ? " +
					"WHERE IdUtente = HEXTORAW(?)";

				cmd.CommandText = sqlCmd;
				cmd.Parameters.Add(new OleDbParameter("Nominativo",			OleDbType.VarChar,		255,	"Nominativo"));
				cmd.Parameters.Add(new OleDbParameter("CodiceFiscale",		OleDbType.VarChar,		255,	"CodiceFiscale"));
				cmd.Parameters.Add(new OleDbParameter("Telefono",			OleDbType.VarChar,		255,	"Telefono"));
				cmd.Parameters.Add(new OleDbParameter("Fax",				OleDbType.VarChar,		255,	"Fax"));
				cmd.Parameters.Add(new OleDbParameter("Email",				OleDbType.VarChar,		255,	"Email"));
				//				cmd.Parameters.Add(new OleDbParameter("DN",					OleDbType.VarChar,		1023,	"DN")); // OK cript
				cmd.Parameters.Add(new OleDbParameter("DataOraInserimento",	OleDbType.DBTimeStamp,	0,		"DataOraInserimento"));
				cmd.Parameters.Add(new OleDbParameter("DataOraModifica",	OleDbType.DBTimeStamp,  0,		"DataOraModifica"));
				cmd.Parameters.Add(new OleDbParameter("TipoUtente",			OleDbType.VarChar,		255,	"TipoUtente"));
				cmd.Parameters.Add(new OleDbParameter("StatoUtente",		OleDbType.VarChar,		255,	"StatoUtente"));
				cmd.Parameters.Add(new OleDbParameter("IdUtente",			OleDbType.VarChar,		32,		"IdUtente"));
				da.UpdateCommand = cmd;
			}

			// con questa impostazione si arrabbia se il DataSet non contiene tutte le colonne necessarie
			da.MissingSchemaAction = MissingSchemaAction.Error;
			return da;
		}
		/*
		private OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			// Query di SELECT per il Data Adapter
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				// N.B. Lo spazio alla fine della stringa e' MOLTO IMPORTANTE non toglierlo!!!!!
				string sqlCmd = "SELECT RAWTOHEX(IdUtente) AS IdUtente, " +
								"Nominativo, " +
								"CodiceFiscale,  " +
								"Telefono, " +
								"Fax, " +
								"Email, " +
								"DN, " +  // OK Crypt -> 
								"DataOraInserimento, " +
								"DataOraModifica, " +
								"RAWTOHEX(IdSocieta) AS IdSocieta, " +
								"RAWTOHEX(IdRichiestaRegUtente) AS IdRichiestaRegUtente, " +
								"TipoUtente, " +
								"StatoUtente " +
								"FROM US.Utenti "; 

				if (sql != null && sql.Length > 0)
					sqlCmd += sql;

				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// Update
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				string sqlCmd = "UPDATE US.Utenti SET " +
								"Nominativo = ?, " +
								"CodiceFiscale = ?, " +
								"Telefono = ?, " +
								"FAX = ?, " +
								"Email = ?, " +
//								"DN = ?, " +  // OK cript non si fa mai l'update del DN
								"DataOraInserimento = ?, " +
								"DataOraModifica = ?, " +
								"TipoUtente = ?, " +
								"StatoUtente = ? " +
								"WHERE IdUtente = HEXTORAW(?)";

				cmd.CommandText = sqlCmd;
				cmd.Parameters.Add(new OleDbParameter("Nominativo",			OleDbType.VarChar,		255,	"Nominativo"));
				cmd.Parameters.Add(new OleDbParameter("CodiceFiscale",		OleDbType.VarChar,		255,	"CodiceFiscale"));
				cmd.Parameters.Add(new OleDbParameter("Telefono",			OleDbType.VarChar,		255,	"Telefono"));
				cmd.Parameters.Add(new OleDbParameter("Fax",				OleDbType.VarChar,		255,	"Fax"));
				cmd.Parameters.Add(new OleDbParameter("Email",				OleDbType.VarChar,		255,	"Email"));
//				cmd.Parameters.Add(new OleDbParameter("DN",					OleDbType.VarChar,		1023,	"DN")); // OK cript
				cmd.Parameters.Add(new OleDbParameter("DataOraInserimento",	OleDbType.DBTimeStamp,	0,		"DataOraInserimento"));
				cmd.Parameters.Add(new OleDbParameter("DataOraModifica",	OleDbType.DBTimeStamp,  0,		"DataOraModifica"));
				cmd.Parameters.Add(new OleDbParameter("TipoUtente",			OleDbType.VarChar,		255,	"TipoUtente"));
				cmd.Parameters.Add(new OleDbParameter("StatoUtente",		OleDbType.VarChar,		255,	"StatoUtente"));
				cmd.Parameters.Add(new OleDbParameter("IdUtente",			OleDbType.VarChar,		32,		"IdUtente"));
				da.UpdateCommand = cmd;
			}

			// TODO: (Flavio) Query di INSERT, DELETE per la classe AdminUtenti
			da.MissingSchemaAction = MissingSchemaAction.Error;
			return da;
		}
		*/

		public void Update(DataSet ds, string IdUtente, string nominativo)
		{
			OleDbDataAdapter da = GetDataAdapter();
			da.Update(ds, "Utenti"); // qui fa solo UPDATE (comando sql) che NON aggiorna il DN ==> non lo scrive in chiaro

			if (nominativo != "")
			{
				// Riporto la modifica nello storico
				AggiungiInStorico(IdUtente, nominativo);
				AggiornaRicRegUte(IdUtente, nominativo);
			}
		}

		public string Valida(string IdSocietaParent, string IdRichiestaRegUtente, string nominativo)
		{
			DLAdminRichieste dlRichieste = new DLAdminRichieste(m_Transaction);
			// Recupero il record relativo alla Richiesta di registrazione Societa' 
			// che voglio validare...
			DataSet ds = dlRichieste.SearchUtenti(IdRichiestaRegUtente);
			if (ds == null)
				return null;

			DataTable dtRichiesteUtente = ds.Tables[0];
			if (dtRichiesteUtente.Rows.Count == 0)
			{
				return null;
			}

			string newGuid = Guid.NewGuid().ToString("N").ToUpper();

			// questo DN e' in chiaro (SearchUtenti lo ritorna in chiaro)
			string DN = (string)dtRichiesteUtente.Rows[0]["DN"]; // OK Crypt

			// qui lo cripto per inserirlo nella tabella degli utenti
			DN = Encrypt(DN); // OK Crypt

			string sqlInsert = "INSERT INTO US.Utenti " +
								"(IdUtente, " +
								"Nominativo, " +
								"CodiceFiscale, " +
								"Telefono, " +
								"Fax, " +
								"Email, " +
								"DN, " +  // OK cript - qui arriva da RichiestaRegUtente
								"IdSocieta, " +
								"IdRichiestaRegUtente, " +
								"TipoUtente, " +
								"StatoUtente) " +
								"VALUES " +
								"(HEXTORAW(?), ?,	?, ?, ?, ?,	?, HEXTORAW(?),	HEXTORAW(?), ?,	'Valido')";

			OleDbCommand cmd = new OleDbCommand(sqlInsert, m_Transaction.Connection, m_Transaction);
			cmd.Parameters.Add("IdUtente",					OleDbType.VarChar).Value = newGuid;
			cmd.Parameters.Add("Nominativo",				OleDbType.VarChar).Value = dtRichiesteUtente.Rows[0]["Nominativo"].ToString();
			cmd.Parameters.Add("CodiceFiscale",				OleDbType.VarChar).Value = dtRichiesteUtente.Rows[0]["CodiceFiscale"].ToString();
			cmd.Parameters.Add("Telefono",					OleDbType.VarChar).Value = dtRichiesteUtente.Rows[0]["Telefono"].ToString();
			cmd.Parameters.Add("Fax",						OleDbType.VarChar).Value = dtRichiesteUtente.Rows[0]["Fax"].ToString();
			cmd.Parameters.Add("Email",						OleDbType.VarChar).Value = dtRichiesteUtente.Rows[0]["Email"].ToString();
			cmd.Parameters.Add("DN",						OleDbType.VarChar).Value = DN; // OK crypt
			cmd.Parameters.Add("IdSocieta",					OleDbType.VarChar).Value = IdSocietaParent;
			cmd.Parameters.Add("IdRichiestaRegUtente",		OleDbType.VarChar).Value = IdRichiestaRegUtente;
			cmd.Parameters.Add("TipoUtente",				OleDbType.VarChar).Value = dtRichiesteUtente.Rows[0]["TipoUtente"].ToString();
			cmd.ExecuteNonQuery();
	
			// Riporto la modifica nello storico se nominativo != ""
			if (nominativo != "")
			{
				AggiungiInStorico(newGuid, nominativo);
			}

			// Aggiorno lo stato della Richiesta di registrazione
			string sqlUpdate =	"UPDATE US.RichiesteRegUtenti " +
								"SET StatoRichiesta = 'Valida' " +
								"WHERE IdRichiestaRegUtente = HEXTORAW(?)";

			OleDbCommand cmdUpdate = new OleDbCommand(sqlUpdate, m_Transaction.Connection, m_Transaction);
			cmdUpdate.Parameters.Add("IdRichiestaRegUtente",	OleDbType.VarChar).Value = IdRichiestaRegUtente;
			cmdUpdate.ExecuteNonQuery();

			return newGuid;
		}

		public DataSet GetLstStorico()
		{
			string sqlSelect = @"SELECT RAWTOHEX(IdUtente) as IdUtente,
										TSModifica,
										Nominativo,
										CodiceFiscale,
										Telefono,
										Fax,
										Email,
										DN,
										DataOraInserimento, 
										DataOraModifica,
										RAWTOHEX(IdSocieta) AS IdSocieta, 
										RAWTOHEX(IdRichiestaRegUtente) AS IdRichiestaRegUtente, 
										TipoUtente,
										StatoUtente,
										AutoreModifica 
										FROM US.StoricoUtenti 
										ORDER BY TSModifica DESC
			" ;

			using (OleDbDataAdapter da = new OleDbDataAdapter(sqlSelect, m_Transaction.Connection))
			{
				da.SelectCommand.Transaction = m_Transaction;

				DataSet ds = new DataSet();
				DataTable dt = ds.Tables.Add("Utenti");
				dt.Columns.Add("IdUtente", typeof(string));
				dt.Columns.Add("TSModifica", typeof(DateTime));
				dt.Columns.Add("Nominativo", typeof(string));
				dt.Columns.Add("CodiceFiscale", typeof(string));
				dt.Columns.Add("Telefono", typeof(string));
				dt.Columns.Add("Fax", typeof(string));
				dt.Columns.Add("Email", typeof(string));
				dt.Columns.Add("DN", typeof(string));
				dt.Columns.Add("DataOraInserimento", typeof(DateTime));
				dt.Columns.Add("DataOraModifica", typeof(DateTime));
				dt.Columns.Add("IdSocieta", typeof(string));
				dt.Columns.Add("IdRichiestaRegUtente", typeof(string));
				dt.Columns.Add("TipoUtente", typeof(string));
				dt.Columns.Add("StatoUtente", typeof(string));
				dt.Columns.Add("AutoreModifica", typeof(string));
				da.Fill(ds, "Utenti");
				return ds;
			}
		}

		public void AggiungiInStorico(string IdUtente, string nominativo)
		{
			OleDbDataAdapter da = null ;
			OleDbParameter par = new OleDbParameter("IdUtente", OleDbType.VarChar);
			par.Value = IdUtente;

			string sql = "WHERE IdUtente = HEXTORAW(?) ";
			da = GetDataAdapter(sql, par);

			DataSet ds = DataSet_Utenti();
			da.Fill(ds, "Utenti");

			if (ds == null)
			{
				throw new Exception("Errore nella 'Get' dell'utente da tracciare sullo storico.");
			}

			if (ds.Tables[0].Rows.Count == 0)
			{
				throw new Exception("Utente da tracciare sullo storico non trovato.");
			}

			string sqlInsert = "INSERT INTO US.StoricoUtenti " +
				"(IdUtente, " +
				"Nominativo, " +
				"CodiceFiscale, " +
				"Telefono, " +
				"Fax, " +
				"Email, " +
				"DN, " +  // OK cript - qui arriva da RichiestaRegUtente
				"IdSocieta, " +
				"IdRichiestaRegUtente, " +
				"TipoUtente, " +
				"DataOraInserimento, " +
				"DataOraModifica, " +
				"StatoUtente, AutoreModifica) " +
				"VALUES " +
				"(HEXTORAW(?), ?, ?, ?, ?, ?, ?, HEXTORAW(?), HEXTORAW(?), ?, ?, ?, ?, ?)";

			OleDbCommand cmd = new OleDbCommand(sqlInsert, m_Transaction.Connection, m_Transaction);
			cmd.Parameters.Add("IdUtente",					OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["IdUtente"].ToString();
			cmd.Parameters.Add("Nominativo",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Nominativo"].ToString();
			cmd.Parameters.Add("CodiceFiscale",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CodiceFiscale"].ToString();
			cmd.Parameters.Add("Telefono",					OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Telefono"].ToString();
			cmd.Parameters.Add("Fax",						OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Fax"].ToString();
			cmd.Parameters.Add("Email",						OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Email"].ToString();
			cmd.Parameters.Add("DN",						OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["DN"].ToString();
			cmd.Parameters.Add("IdSocieta",					OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["IdSocieta"].ToString();
			cmd.Parameters.Add("IdRichiestaRegUtente",		OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["IdRichiestaRegUtente"].ToString();
			cmd.Parameters.Add("TipoUtente",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["TipoUtente"].ToString();
			cmd.Parameters.Add("DataOraInserimento",		OleDbType.DBTimeStamp).Value = (DateTime)ds.Tables[0].Rows[0]["DataOraInserimento"];
			cmd.Parameters.Add("DataOraModifica",			OleDbType.DBTimeStamp).Value = (DateTime)ds.Tables[0].Rows[0]["DataOraModifica"];
			cmd.Parameters.Add("StatoUtente",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["StatoUtente"].ToString();
			cmd.Parameters.Add("AutoreModifica",			OleDbType.VarChar).Value = nominativo;
			cmd.ExecuteNonQuery();
		}

		public void AggiornaRicRegUte(string IdUtente, string nominativo)
		{
			OleDbDataAdapter da = null ;
			OleDbParameter par = new OleDbParameter("IdUtente", OleDbType.VarChar);
			par.Value = IdUtente;

			string sql = "WHERE IdUtente = HEXTORAW(?) ";
			da = GetDataAdapter(sql, par);

			DataSet ds = DataSet_Utenti();
			da.Fill(ds, "Utenti");

			if (ds == null)
			{
				throw new Exception("Errore nella 'Get' dell'utente da tracciare sullo storico.");
			}

			if (ds.Tables[0].Rows.Count == 0)
			{
				throw new Exception("Utente da tracciare sullo storico non trovato.");
			}

			string sqlInsert = "UPDATE US.RichiesteRegUtenti SET " +
				"Nominativo = ?, " +
				"CodiceFiscale = ?, " +
				"Telefono = ?, " +
				"Fax = ?, " +
				"Email = ?, " +
				"DN = ?, " + 
				"TipoUtente = ? " +
				"WHERE IdRichiestaRegUtente = HEXTORAW(?)";

			OleDbCommand cmd = new OleDbCommand(sqlInsert, m_Transaction.Connection, m_Transaction);
			cmd.Parameters.Add("Nominativo",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Nominativo"].ToString();
			cmd.Parameters.Add("CodiceFiscale",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CodiceFiscale"].ToString();
			cmd.Parameters.Add("Telefono",					OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Telefono"].ToString();
			cmd.Parameters.Add("Fax",						OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Fax"].ToString();
			cmd.Parameters.Add("Email",						OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Email"].ToString();
			cmd.Parameters.Add("DN",						OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["DN"].ToString();
			cmd.Parameters.Add("TipoUtente",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["TipoUtente"].ToString();
			cmd.Parameters.Add("IdRichiestaRegUtente",		OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["IdRichiestaRegUtente"].ToString();
			cmd.ExecuteNonQuery();
		}

		public static DataSet DataSet_Utenti()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("Utenti");

			DataColumn c;
			c = dt.Columns.Add("IdUtente", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("Nominativo", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("CodiceFiscale", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Telefono", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("FAX", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Email", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("DN", typeof(string)); // OK Crypt
			c.MaxLength = 1023;
			c.AllowDBNull = false;
			c.Unique = true;

			c = dt.Columns.Add("DataOraInserimento", typeof(DateTime));
			c.AllowDBNull = false;
//			c.DefaultValue = new DateTime(1900,1,1);
			c.Unique = false;

			c = dt.Columns.Add("DataOraModifica", typeof(DateTime));
			c.AllowDBNull = false;
//			c.DefaultValue = new DateTime(1900,1,1);
			c.Unique = false;

			c = dt.Columns.Add("IdSocieta", typeof(string));
			c.MaxLength = 32;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("IdRichiestaRegUtente", typeof(string));
			c.MaxLength = 32;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("TipoUtente", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("StatoUtente", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("RagioneSociale", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("CodiceConto", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			dt.PrimaryKey = new DataColumn[] {	dt.Columns["IdUtente"]};
			return ds;
		}
	}
}
