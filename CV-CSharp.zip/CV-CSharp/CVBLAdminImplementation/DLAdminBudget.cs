using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminBudget.
	/// </summary>
	internal class DLAdminBudget : DLAdminBase
	{
		public DLAdminBudget(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public void Delete(string IdSocieta, string IdSessione)
		{
			string strSqlQuery = "DELETE FROM CV.Budgets " +
								 "WHERE IdSocieta = HEXTORAW(?) " +
								 "AND IdSessione = HEXTORAW(?)";

			using (OleDbCommand deleteCMD = new OleDbCommand(strSqlQuery, (OleDbConnection)m_Transaction.Connection, m_Transaction))
			{
				deleteCMD.Parameters.Add("@IdSocieta", OleDbType.VarChar, 32).Value = IdSocieta;
				deleteCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
				deleteCMD.ExecuteNonQuery();
			}
		}

		public void DeleteSessione(string IdSessione)
		{
			string strSqlQuery = "DELETE FROM CV.Budgets " +
								 "WHERE IdSessione = HEXTORAW(?)";

			using (OleDbCommand deleteCMD = new OleDbCommand(strSqlQuery, (OleDbConnection)m_Transaction.Connection, m_Transaction))
			{
				deleteCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
				deleteCMD.ExecuteNonQuery();
			}

//			OleDbCommand cmd = new OleDbCommand("CV.sp_Budget_Delete_Sessione", m_Transaction.Connection, m_Transaction);
//			cmd.CommandType = CommandType.StoredProcedure;
//			cmd.Parameters.Add("@IdSocieta", OleDbType.VarChar).Value = IdSessione;
//			cmd.ExecuteNonQuery();
		}

		public void Insert(DataSet ds)
		{
			OleDbDataAdapter da = GetDataAdapter();
			da.Update(ds, "Budgets");
		}

//		public void Insert(InfoBudget infoB)
//		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.sp_Budget_Add", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// ID Societa (input)
//			OleDbParameter parIdSocieta = new OleDbParameter("@IdSocieta", OleDbType.VarChar, 32);
//			parIdSocieta.Direction = ParameterDirection.Input;
//			parIdSocieta.IsNullable = false;
//			parIdSocieta.Value = infoB.IdSocieta;
//			callspCMD.Parameters.Add(parIdSocieta);
//
//			// ID Sessione (input)
//			OleDbParameter parIdSessione = new OleDbParameter("@IdSessione", OleDbType.VarChar, 32);
//			parIdSessione.Direction = ParameterDirection.Input;
//			parIdSessione.IsNullable = false;
//			parIdSessione.Value = infoB.IdSessione;
//			callspCMD.Parameters.Add(parIdSessione);
//
//			// Importo (input)
//			OleDbParameter parImporto = new OleDbParameter("@Importo", OleDbType.Decimal);
//			parImporto.Direction = ParameterDirection.Input;
//			parImporto.IsNullable = false;
//			parImporto.Value = infoB.Importo;
//			callspCMD.Parameters.Add(parImporto);
//
//			// Prezzo Convenzionale Utente (input)
//			OleDbParameter parPrezzoConvUtente = new OleDbParameter("@PrezzoConvUtente", OleDbType.Decimal);
//			parPrezzoConvUtente.Direction = ParameterDirection.Input;
//			parPrezzoConvUtente.IsNullable = false;
//			parPrezzoConvUtente.Value = infoB.PrezzoConvenzionaleUtente;
//			callspCMD.Parameters.Add(parPrezzoConvUtente);
//
//			// Prezzo Convenzionale Utente Mw (input)
//			OleDbParameter parPrezzoConvUtenteMw = new OleDbParameter("@PrezzoConvUtenteMw", OleDbType.Decimal);
//			parPrezzoConvUtenteMw.Direction = ParameterDirection.Input;
//			parPrezzoConvUtenteMw.IsNullable = false;
//			parPrezzoConvUtenteMw.Value = infoB.PrezzoConvenzionaleUtenteMw;
//			callspCMD.Parameters.Add(parPrezzoConvUtenteMw);
//
//			// Quantita' Massima (input)
//			OleDbParameter parQtyMAX = new OleDbParameter("@QtyMAX", OleDbType.Decimal);
//			parQtyMAX.Direction = ParameterDirection.Input;
//			parQtyMAX.IsNullable = false;
//			parQtyMAX.Value = infoB.QuantitaMAX;
//			callspCMD.Parameters.Add(parQtyMAX);
//
//			callspCMD.ExecuteNonQuery();
//		}


//		public void Update(InfoBudget infoB)
//		{
//			OleDbCommand callspCMD = new OleDbCommand("CV.SP_BUDGET_UPDATE", m_Transaction.Connection, m_Transaction);
//			callspCMD.CommandType = CommandType.StoredProcedure;
//
//			// ID Societa (input)
//			OleDbParameter parIdSocieta = new OleDbParameter("@IdSocieta", OleDbType.VarChar, 32);
//			parIdSocieta.Direction = ParameterDirection.Input;
//			parIdSocieta.IsNullable = false;
//			parIdSocieta.Value = infoB.IdSocieta;
//			callspCMD.Parameters.Add(parIdSocieta);
//
//			// ID Sessione (input)
//			OleDbParameter parIdSessione = new OleDbParameter("@IdSessione", OleDbType.VarChar, 32);
//			parIdSessione.Direction = ParameterDirection.Input;
//			parIdSessione.IsNullable = false;
//			parIdSessione.Value = infoB.IdSessione;
//			callspCMD.Parameters.Add(parIdSessione);
//
//			// Importo (input)
//			OleDbParameter parImporto = new OleDbParameter("@Importo", OleDbType.Decimal);
//			parImporto.Direction = ParameterDirection.Input;
//			parImporto.IsNullable = false;
//			parImporto.Value = infoB.Importo;
//			callspCMD.Parameters.Add(parImporto);
//
//			// Prezzo Convenzionale Utente (input)
//			OleDbParameter parPrezzoConvUtente = new OleDbParameter("@PrezzoConvUtente", OleDbType.Decimal);
//			parPrezzoConvUtente.Direction = ParameterDirection.Input;
//			parPrezzoConvUtente.IsNullable = false;
//			parPrezzoConvUtente.Value = infoB.PrezzoConvenzionaleUtente;
//			callspCMD.Parameters.Add(parPrezzoConvUtente);
//
//			// Prezzo Convenzionale Utente Mw (input)
//			OleDbParameter parPrezzoConvUtenteMw = new OleDbParameter("@PrezzoConvUtenteMw", OleDbType.Decimal);
//			parPrezzoConvUtenteMw.Direction = ParameterDirection.Input;
//			parPrezzoConvUtenteMw.IsNullable = false;
//			parPrezzoConvUtenteMw.Value = infoB.PrezzoConvenzionaleUtenteMw;
//			callspCMD.Parameters.Add(parPrezzoConvUtenteMw);
//
//			// Quantita' Massima (input)
//			OleDbParameter parQtyMAX = new OleDbParameter("@QtyMAX", OleDbType.Decimal);
//			parQtyMAX.Direction = ParameterDirection.Input;
//			parQtyMAX.IsNullable = false;
//			parQtyMAX.Value = infoB.QuantitaMAX;
//			callspCMD.Parameters.Add(parQtyMAX);
//
//			callspCMD.ExecuteNonQuery();
//		}

		public void Update(DataSet ds)
		{
			OleDbDataAdapter da = GetDataAdapter();
			da.Update(ds, "Budgets");
		}

		protected OleDbDataAdapter GetDataAdapter()
		{
			return GetDataAdapter(null, (OleDbParameter [])null);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere)
		{
			OleDbParameter [] pars = new OleDbParameter [1];
			pars[0] = parWhere;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere1, OleDbParameter parWhere2)
		{
			OleDbParameter [] pars = new OleDbParameter [2];
			pars[0] = parWhere1;
			pars[1] = parWhere2;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			// Query di SELECT per il Data Adapter
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				// N.B. Lo spazio alla fine della stringa e' MOLTO IMPORTANTE non toglierlo!!!!!
				string sqlCmd = @"
					SELECT 
						RAWTOHEX(IdSocieta) IdSocieta,
						RAWTOHEX(IdSessione) IdSessione,
						Importo, 
						ImportoProposto, 
						PrezzoConvenzionaleUtente, 
						PrezzoConvenzionaleUtenteMw, 
						QtyMax, 
						QtyImpegnata, 
						DataOraCreazione, 
						Residuo, 
						SaldoProposto, 
						SaldoSessionePrecedente 
					FROM CV.Budgets ";

				if (sql != null && sql.Length > 0)
					sqlCmd += sql;

				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// INSERT
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText =	"INSERT INTO CV.Budgets (" +
					"Importo, " +
					"ImportoProposto, " +
					"SaldoProposto, " +
					"Residuo, " +
					"IdMovResiduo, " +
					"PrezzoConvenzionaleUtente, " +
					"PrezzoConvenzionaleUtenteMw, " +
					"QtyMax, " +
					"QtyImpegnata, " +
					"DataOraCreazione, " +
					"IdSessione, " +
					"IdSocieta, SaldoSessionePrecedente" +
					") VALUES (?, ?, ?, ?, null, ?, ?, ?, ?, SYSDATE, HEXTORAW(?), HEXTORAW(?), ?)";

				cmd.Parameters.Add(new OleDbParameter("Importo",						OleDbType.Decimal,		 0, "Importo"));
				cmd.Parameters.Add(new OleDbParameter("ImportoProposto",				OleDbType.Decimal,		 0, "ImportoProposto"));
				cmd.Parameters.Add(new OleDbParameter("SaldoProposto",					OleDbType.Decimal,		 0, "SaldoProposto"));
				cmd.Parameters.Add(new OleDbParameter("Residuo",						OleDbType.Decimal,       0, "Residuo"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionaleUtente",		OleDbType.Decimal,		 0, "PrezzoConvenzionaleUtente"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionaleUtenteMw",	OleDbType.Decimal,		 0, "PrezzoConvenzionaleUtenteMw"));
				cmd.Parameters.Add(new OleDbParameter("QtyMax",							OleDbType.Decimal,       0, "QtyMax"));
				cmd.Parameters.Add(new OleDbParameter("QtyImpegnata",					OleDbType.Decimal,       0, "QtyImpegnata"));
				cmd.Parameters.Add(new OleDbParameter("IdSessione",		                OleDbType.VarChar,      32, "IdSessione"));
				cmd.Parameters.Add(new OleDbParameter("IdSocieta",		                OleDbType.VarChar,      32, "IdSocieta"));
				cmd.Parameters.Add(new OleDbParameter("SaldoSessionePrecedente",		OleDbType.Decimal,		 0, "SaldoSessionePrecedente"));

				da.InsertCommand = cmd;
			}

			// UPDATE
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText = "UPDATE CV.Budgets SET " +
					"Importo = ?, " +
					"ImportoProposto = ?, " +
					"SaldoProposto = ?, " +
					"Residuo = ?, " +
					"PrezzoConvenzionaleUtente = ?, " +
					"PrezzoConvenzionaleUtenteMw = ?, " +
					"QtyMax = ?, " +
					"QtyImpegnata = ?, " +
					"SaldoSessionePrecedente = ? " + 
					"WHERE IdSessione = HEXTORAW(?) " +
					"AND IdSocieta = HEXTORAW(?)";
					
				cmd.Parameters.Add(new OleDbParameter("Importo",						OleDbType.Decimal,		 0, "Importo"));
				cmd.Parameters.Add(new OleDbParameter("ImportoProposto",				OleDbType.Decimal,		 0, "ImportoProposto"));
				cmd.Parameters.Add(new OleDbParameter("SaldoProposto",					OleDbType.Decimal,		 0, "SaldoProposto"));
				cmd.Parameters.Add(new OleDbParameter("Residuo",						OleDbType.Decimal,       0, "Residuo"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionaleUtente",		OleDbType.Decimal,		 0, "PrezzoConvenzionaleUtente"));
				cmd.Parameters.Add(new OleDbParameter("PrezzoConvenzionaleUtenteMw",	OleDbType.Decimal,		 0, "PrezzoConvenzionaleUtenteMw"));
				cmd.Parameters.Add(new OleDbParameter("QtyMax",							OleDbType.Decimal,       0, "QtyMax"));
				cmd.Parameters.Add(new OleDbParameter("QtyImpegnata",					OleDbType.Decimal,       0, "QtyImpegnata"));
				cmd.Parameters.Add(new OleDbParameter("SaldoSessionePrecedente",		OleDbType.Decimal,		 0, "SaldoSessionePrecedente"));
				cmd.Parameters.Add(new OleDbParameter("IdSessione",		                OleDbType.VarChar,      32, "IdSessione"));
				cmd.Parameters.Add(new OleDbParameter("IdSocieta",		                OleDbType.VarChar,      32, "IdSocieta"));

				da.UpdateCommand = cmd;
			}

			// DELETE
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("DELETE FROM CV.BUDGETS WHERE IdSessione = HEXTORAW(?) AND IdSocieta = HEXTORAW(?)", m_Transaction.Connection, m_Transaction);
				cmd.CommandType = CommandType.Text;

				OleDbParameter IdSessionePar = new OleDbParameter("IdSessione", OleDbType.VarChar);
				IdSessionePar.SourceColumn = "IdSessione";
				IdSessionePar.SourceVersion = DataRowVersion.Original;
				cmd.Parameters.Add(IdSessionePar);

				OleDbParameter IdSocietaPar = new OleDbParameter("IdSocieta", OleDbType.VarChar);
				IdSocietaPar.SourceColumn = "IdSocieta";
				IdSocietaPar.SourceVersion = DataRowVersion.Original;
				cmd.Parameters.Add(IdSocietaPar);

				da.DeleteCommand = cmd;
			}

			da.MissingSchemaAction = MissingSchemaAction.Error;
			return da;
		}

		public DataSet Get(string IdSessione, string IdSocieta)
		{
			OleDbDataAdapter da = null;
			OleDbParameter [] pars = new OleDbParameter[2];
			if ((IdSessione == String.Empty) && (IdSocieta == String.Empty))
			{
				da = GetDataAdapter();
			}
			else if (IdSocieta == String.Empty)
			{
				pars[0] = new OleDbParameter("IdSessione", OleDbType.VarChar);
				pars[0].Value = IdSessione;
				da = GetDataAdapter("WHERE IdSessione = HEXTORAW(?) ", pars[0]);
			}
			else if (IdSessione == String.Empty)
			{
				pars[0] = new OleDbParameter("IdSocieta", OleDbType.VarChar);
				pars[0].Value = IdSocieta;
				da = GetDataAdapter("WHERE IdSocieta = HEXTORAW(?) ", pars[0]);
			}
			else
			{
				pars[0] = new OleDbParameter("IdSocieta", OleDbType.VarChar);
				pars[0].Value = IdSocieta;
				pars[1] = new OleDbParameter("IdSessione", OleDbType.VarChar);
				pars[1].Value = IdSessione;
				da = GetDataAdapter("WHERE IdSocieta = HEXTORAW(?) AND IdSessione = HEXTORAW(?) ", pars);
			}

			using (da)
			{
				DataSet ds = DataSet_Budget();
				da.Fill(ds, "Budgets");
				return ds;
			}
		}

		public static DataSet DataSet_Budget()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("Budgets");

			DataColumn c;
			c = dt.Columns.Add("IdSessione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("IdSocieta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("Importo", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("ImportoProposto", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoConvenzionaleUtente", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PrezzoConvenzionaleUtenteMw", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("QtyMax", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("QtyImpegnata", typeof(Decimal));
			c.AllowDBNull = false;
			c.Unique = false;
			c.DefaultValue = 0M;

			c = dt.Columns.Add("DataOraCreazione", typeof(DateTime));
			c.AllowDBNull = false;
//OK		c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("Residuo", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("SaldoProposto", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("SaldoSessionePrecedente", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;
			c.DefaultValue = DBNull.Value;
	
			dt.PrimaryKey = new DataColumn[] {	dt.Columns["IdSocieta"], 
												dt.Columns["IdSessione"]
											 };
			return ds;

		}

//		public InfoBudget Get(string IdSessione, string IdSocieta)
//		{
//			string strSqlQuery = "SELECT RAWTOHEX(IdSocieta) IdSocieta, " + 
//								 "RAWTOHEX(IdSessione) IdSessione, " + 
//								 "Importo, " + 
//								 "PrezzoConvenzionaleUtente, " + 
//								 "PrezzoConvenzionaleUtenteMw, " + 
//								 "QtyMax, " + 
//								 "QtyImpegnata, " + 
//								 "DataOraCreazione " +
//								 "FROM CV.Budgets " +
//								 "WHERE  IdSocieta = HEXTORAW(?) " +
//								 "AND IdSessione = HEXTORAW(?)";
//
//			using (OleDbDataAdapter da = new OleDbDataAdapter())
//			{
//				DataSet ds = new DataSet("dsInfoBudget");
//				{
//					OleDbCommand selectCMD = new OleDbCommand(strSqlQuery, m_Transaction.Connection, m_Transaction);
//					da.SelectCommand = selectCMD;
//					selectCMD.Parameters.Add("@IdSocieta", OleDbType.VarChar, 32).Value = IdSocieta;
//					selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;					
//					da.Fill(ds, "InfoBudget");
//					DataTable dt = ds.Tables["InfoBudget"];
//					InfoBudget infoB = new InfoBudget();
//					infoB.IdSocieta = IdSocieta;
//					infoB.IdSessione = IdSessione;
//					if (dt.Rows.Count == 1)
//					{
//						if (!dt.Rows[0].IsNull("Importo"))
//						{
//							infoB.Importo = (decimal)dt.Rows[0]["Importo"];	
//							infoB.ImportoIsNull = false;
//						}
//						else
//						{
//							infoB.Importo = 0M;	
//							infoB.ImportoIsNull = true;
//						}
//
//						if (!dt.Rows[0].IsNull("PrezzoConvenzionaleUtente"))
//						{
//							infoB.PrezzoConvenzionaleUtente = (decimal)dt.Rows[0]["PrezzoConvenzionaleUtente"];	
//							infoB.PrezzoConvenzionaleUtenteIsNull = false;
//						}
//						else
//						{
//							infoB.PrezzoConvenzionaleUtente = 0M;	
//							infoB.PrezzoConvenzionaleUtenteIsNull = true;
//						}
//
//						if (!dt.Rows[0].IsNull("PrezzoConvenzionaleUtenteMw"))
//						{
//							infoB.PrezzoConvenzionaleUtenteMw = (decimal)dt.Rows[0]["PrezzoConvenzionaleUtenteMw"];	
//							infoB.PrezzoConvenzionaleUtenteMwIsNull = false;
//						}
//						else
//						{
//							infoB.PrezzoConvenzionaleUtenteMw = 0M;	
//							infoB.PrezzoConvenzionaleUtenteMwIsNull = true;
//						}
//
//						if (!dt.Rows[0].IsNull("QtyMax"))
//						{
//							infoB.QuantitaMAX = (decimal)dt.Rows[0]["QtyMax"];	
//							infoB.QuantitaMAXIsNull = false;
//						}
//						else
//						{
//							infoB.QuantitaMAX = 0M;	
//							infoB.QuantitaMAXIsNull = true;
//						}
//
//						if (!dt.Rows[0].IsNull("DataOraCreazione"))
//						{
//							infoB.DataOraCreazione = (DateTime)dt.Rows[0]["DataOraCreazione"];	
//							infoB.DataOraCreazioneIsNull = false;
//						}
//						else
//						{
//							infoB.DataOraCreazioneIsNull = true;
//						}
//					}
//
//					return infoB;
//				}
//			}
//		}



		public static DataSet DataSet_BudgetSessionePrecedente()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("BudgetSessionePrecedente");

			DataColumn c;
			c = dt.Columns.Add("IdSessione", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;

			c = dt.Columns.Add("IdSocieta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;

			c = dt.Columns.Add("DataOraApertura", typeof(DateTime));
			c.AllowDBNull = false;

			c = dt.Columns.Add("Residuo", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;
	
			dt.PrimaryKey = new DataColumn[]
			{
				dt.Columns["IdSocieta"], 
				dt.Columns["IdSessione"]
			};

			return ds;
		}

		internal DataSet GetBudgetSessionePrecedente(string IdSessione)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText = @"
					select
						RawToHex(S.IdSessione) IdSessione,
						RawToHex(B.IdSocieta)  IdSocieta,
						S.DataOraApertura      DataOraApertura,
						B.Residuo              Residuo 
					from
						cv.sessioni S,
						cv.budgets  B
					where
						S.IdSessione = B.IdSessione
						and S.dataOraApertura in
						(
							select
								max(SPrecedente.dataOraApertura)
							from
								cv.sessioni SPrecedente,
								cv.sessioni SAttuale
							where
								SPrecedente.dataOraApertura < SAttuale.dataOraApertura
								and SAttuale.IdSessione = HexToRaw(?)
						)
				";
				cmd.Parameters.Add("IdSessione", IdSessione);
				da.SelectCommand = cmd;
			}

			DataSet ds = DataSet_BudgetSessionePrecedente();
			da.Fill(ds, "BudgetSessionePrecedente");
			return ds;
		}


		/// <summary>
		/// Ritorna un DataSet che contiene: IdSessione, StatoSessione, DataOraApertura delle sessioni
		/// precedenti alla sessione <code>IdSessione</code>
		/// </summary>
		/// <param name="IdSessione">sessione</param>
		/// <returns>un data set delle sessioni precedenti</returns>
		public DataSet GetStatoSessioneSessioniPrecedenti(string IdSessione)
		{
			OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
			cmd.CommandText = @"
				select 
					RawToHex(S.IdSessione) as IdSessione,
					S.DataOraApertura,
					S.StatoSessione
				from
					cv.sessioni S
				where
					S.DataOraApertura <=
					(
						select
							max(SPrecedente.DataOraApertura)
						from
							cv.sessioni SPrecedente,
							cv.sessioni SAttuale
						where
							SPrecedente.DataOraApertura < SAttuale.DataOraApertura
							and SAttuale.IdSessione = HexToRaw(?)
					)
				order by S.dataOraApertura desc
			";
			cmd.Parameters.Add("IdSessione", IdSessione);

			OleDbDataAdapter da = new OleDbDataAdapter(cmd);

			DataSet ds = new DataSet();
			DataTable dt = ds.Tables.Add("SessioniPrecedenti");

			DataColumn c;

			c = dt.Columns.Add("IdSessione", typeof(string));
			c.AllowDBNull = false;
			c.Unique = true;
			c.MaxLength = 32;

			c = dt.Columns.Add("DataOraApertura", typeof(DateTime));
			c.AllowDBNull = false;

			c = dt.Columns.Add("StatoSessione", typeof(string));
			c.AllowDBNull = false;

			dt.PrimaryKey = new DataColumn[]
			{
				dt.Columns["IdSessione"]
			};

			da.Fill(dt);

			return ds;
		}
	}
}
