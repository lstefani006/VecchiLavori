using System;
using System.Data;
using System.Data.OleDb;
using System.Text;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminTransazione.
	/// </summary>
	internal class DLAdminTransazione : DLAdminBase
	{
		public DLAdminTransazione(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public int NumeroTransazioniValide(string IdSessione)
		{
			string sql;
			sql = "SELECT COUNT(*)" +
				"FROM " + 
				"  cv.Transazioni    T, " + 
				"  cv.OfferteVendita O " +
				"WHERE T.IdOffertaVendita = O.IdOffertaVendita " +
				"  AND O.IdSessione = HEXTORAW(?) " +
				"  AND T.StatoTransazione = 'Valida' " +
				"  AND T.DataOraExportXML IS NULL";

			OleDbCommand cmd = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
			cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			object num = cmd.ExecuteScalar();
			int n = Convert.ToInt32(num);
			return n;
		}


		public DataSet TransazioniValide(string IdSessione)
		{
			// la sp originale si chiama sp_Transazione_Validate
			string sql;

			sql = "SELECT " +
				" RAWTOHEX(T.IDTransazione)     AS IDTransazione, " +
				" T.QtyCertificati              AS QtyCertificati," + 
			    " T.PrezzoUnitario              AS PrezzoUnitario," +
				" T.DataOraOperazione           AS DataOraOperazione, " +
				" T.DataOraExportXML            AS DataOraExportXML, " + 
			    " T.StatoTransazione            AS StatoTransazione, " +
			    " RAWTOHEX(T.IDOffertaAcquisto) AS IDOffertaAcquisto, " + 
			    " RAWTOHEX(T.IDOffertaVendita)  AS IDOffertaVendita, " + 
			    " O.QtyOfferta                  AS QtyOfferta, " + 
				" O.QtyResidua                  AS QtyResidua, " +
				" O.AnnoRiferimento             AS AnnoRiferimento, " + 
				" O.PrezzoUnitario              AS PrezzoUnitario, " + 
			    " O.DataOraCreazione            AS DataOraCreazione, " +
				" O.DataOraModifica             AS DataOraModifica, " +
				" O.Compatibile                 AS Compatibile, " + 
			    " RAWTOHEX(O.IDSessione)        AS IDSessione, " + 
				" O.StatoOfferta                AS StatoOfferta, " + 
			    " RAWTOHEX(O.IDUtente)          AS IDUtente " +
				"FROM " + 
				"  cv.Transazioni T, " + 
				"  cv.OfferteVendita O " +
				"WHERE T.IdOffertaVendita = O.IdOffertaVendita " +
				"  AND O.IdSessione = HEXTORAW(?) " +
				"  AND T.StatoTransazione = 'Valida' " +
				"  AND T.DataOraExportXML IS NULL";

			OleDbDataAdapter da = new OleDbDataAdapter(sql, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;


			DataSet ds = new DataSet();
			DataTable dt = ds.Tables.Add("TransazioniValide");

			DataColumn p, c;
			p = dt.Columns.Add("IDTransazione",     typeof(string));
			c = dt.Columns.Add("QtyCertificati",    typeof(decimal));
			c = dt.Columns.Add("PrezzoUnitario",    typeof(decimal));
			c = dt.Columns.Add("DataOraOperazione", typeof(DateTime));
			c = dt.Columns.Add("DataOraExportXML",  typeof(DateTime));
			c = dt.Columns.Add("StatoTransazione",  typeof(string));
			c = dt.Columns.Add("IDOffertaAcquisto", typeof(string));
			c = dt.Columns.Add("IDOffertaVendita",  typeof(string));
			c = dt.Columns.Add("QtyOfferta",        typeof(decimal));
			c = dt.Columns.Add("QtyResidua",        typeof(decimal));
			c = dt.Columns.Add("AnnoRiferimento",   typeof(string));
			c = dt.Columns.Add("PrezzoUnitario",    typeof(decimal));
			c = dt.Columns.Add("DataOraCreazione",  typeof(DateTime));
			c = dt.Columns.Add("DataOraModifica",   typeof(DateTime));
			c = dt.Columns.Add("Compatibile",       typeof(decimal));
			c = dt.Columns.Add("IDSessione",        typeof(string));
			c = dt.Columns.Add("StatoOfferta",      typeof(string));
			c = dt.Columns.Add("IDUtente",          typeof(string));

			dt.PrimaryKey = new DataColumn [] { p };
			da.Fill(ds, "TransazioniValide");
			return ds;
		}


		public DataSet ContiDaSbloccare(string IdSessione)
		{
			string s;

			bool flg = true;
			if (flg)
			{
				s = " SELECT chiavecontoproprieta, '1' as qualequery " +
					" FROM cv.ContiValidi_Trs " +
					" WHERE  IdSessione = HEXTORAW(?) " +
					"    AND chiavecontoproprieta IS NOT NULL AND numero_conto NOT IN " +
					"       (SELECT numero_conto FROM cv.ContiNonValidi_Trs where IdSessione = HEXTORAW(?) ) " +
					" UNION " +
					" SELECT chiavecontoproprieta, '2' as qualequery " +
					" FROM US.Societa Societa " +
					" WHERE  chiavecontoproprieta IS NOT NULL AND codiceconto NOT IN " +
					"    (SELECT DISTINCT S1.CodiceConto AS NUMERO_CONTO " +
					"     FROM   US.Utenti U1, US.Societa S1, CV.OfferteAcquisto O1, CV.Transazioni T1 " +
					"     WHERE  U1.IdSocieta = S1.IdSocieta " +
					"        AND U1.IdUtente = O1.IdUtente " +
					"        AND O1.IdOffertaAcquisto = T1.IdOffertaAcquisto " +
					"        AND O1.IdSessione = HEXTORAW(?) " +
					"     UNION " +
					"     SELECT DISTINCT S2.CodiceConto AS NUMERO_CONTO " +
					"     FROM   US.Utenti U2, US.Societa S2, CV.OfferteVendita O2, CV.Transazioni T2 " +
					"     WHERE  U2.IdSocieta = S2.IdSocieta  " +
					"        AND U2.IdUtente = O2.IdUtente " +
					"        AND O2.IdOffertaVendita = T2.IdOffertaVendita " +
					"        AND O2.IdSessione = HEXTORAW(?) " +
					"     ) " +
					" UNION " +
					" SELECT DISTINCT numeroconto AS chiavecontoproprieta, '3' as qualequery " +  // Leo ho aggiunto as chiavecontoproprieta
					" FROM   cv.NonIscritti " +
					" WHERE  IdSessione = HEXTORAW(?) AND DataOraInvio IS NULL AND numeroconto IS NOT NULL";
			}
			else
			{
				s = " SELECT chiavecontoproprieta, '1' as qualequery " +
					" FROM cv.ContiValidi_Trs " +
					" WHERE  IdSessione = HEXTORAW(?) " +
					"    AND numero_conto NOT IN " +
					"       (SELECT numero_conto FROM cv.ContiNonValidi_Trs where IdSessione = HEXTORAW(?) ) " +
					" UNION " +
					" SELECT chiavecontoproprieta, '2' as qualequery " +
					" FROM US.Societa Societa " +
					" WHERE  codiceconto NOT IN " +
					"    (SELECT DISTINCT S1.CodiceConto AS NUMERO_CONTO " +
					"     FROM   US.Utenti U1, US.Societa S1, CV.OfferteAcquisto O1, CV.Transazioni T1 " +
					"     WHERE  U1.IdSocieta = S1.IdSocieta " +
					"        AND U1.IdUtente = O1.IdUtente " +
					"        AND O1.IdOffertaAcquisto = T1.IdOffertaAcquisto " +
					"        AND O1.IdSessione = HEXTORAW(?) " +
					"     UNION " +
					"     SELECT DISTINCT S2.CodiceConto AS NUMERO_CONTO " +
					"     FROM   US.Utenti U2, US.Societa S2, CV.OfferteVendita O2, CV.Transazioni T2 " +
					"     WHERE  U2.IdSocieta = S2.IdSocieta  " +
					"        AND U2.IdUtente = O2.IdUtente " +
					"        AND O2.IdOffertaVendita = T2.IdOffertaVendita " +
					"        AND O2.IdSessione = HEXTORAW(?) " +
					"     ) " +
					" UNION " +
					" SELECT DISTINCT numeroconto AS chiavecontoproprieta, '3' as qualequery " +  // Leo ho aggiunto as chiavecontoproprieta
					" FROM   cv.NonIscritti " +
					" WHERE  IdSessione = HEXTORAW(?) AND DataOraInvio IS NULL";
			}

  
			OleDbDataAdapter da = new OleDbDataAdapter(s, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;

			DataSet ds = new DataSet();
			DataTable dt = ds.Tables.Add("ContiDaSbloccare");
			dt.Columns.Add("chiavecontoproprieta", typeof(string));
			dt.Columns.Add("qualequery", typeof(string));
			da.Fill(ds, "ContiDaSbloccare");
			return ds;
		}


		public DataSet ExportXMLTransazioni(string IdSessione)
		{
			// sp_Export_XML_File

			string s;
		    s = "SELECT RAWTOHEX(ET.IDTransazione) AS IDTransazione, " +
              "       ET.QtyCertificati            AS QtyCertificati, " +
              "       ET.PrezzoUnitario            AS PrezzoUnitario, " +
              "       ET.DataOraOperazione         AS DataOraOperazione, " +
              "       ET.StatoTransazione          AS StatoTransazione, " +
              "       ET.AnnoRiferimento           AS AnnoRiferimento, " +
              "       RAWTOHEX(ET.IdSessione)      AS IDSessione, " +
              "       ET.Venditore                 AS Venditore, " +
              "       ET.Conto_Destinazione        AS Conto_Destinazione, " +
              "       ET.Acquirente                AS Acquirente, " +
              "       ET.Conto_Origine             AS Conto_Origine " +
              "FROM cv.ElencoTransazioni ET WHERE idSessione = HEXTORAW(?)";

			OleDbDataAdapter da = new OleDbDataAdapter(s, m_Transaction.Connection);
			da.SelectCommand.Transaction = m_Transaction;
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;

			DataSet ds = new DataSet();
			DataTable dt = ds.Tables.Add("TransazioniValide");

			dt.Columns.Add("IDTransazione",      typeof(string));
			dt.Columns.Add("QtyCertificati",     typeof(decimal));
			dt.Columns.Add("PrezzoUnitario",     typeof(decimal));
			dt.Columns.Add("DataOraOperazione",  typeof(DateTime));
			dt.Columns.Add("StatoTransazione",   typeof(string));
			dt.Columns.Add("AnnoRiferimento",    typeof(string));
			dt.Columns.Add("IDSessione",         typeof(string));
			dt.Columns.Add("Venditore",          typeof(string));
			dt.Columns.Add("Conto_Destinazione", typeof(string));
			dt.Columns.Add("Acquirente",         typeof(string));
			dt.Columns.Add("Conto_Origine",      typeof(string));

			da.Fill(ds, "TransazioniValide");
			return ds;
		}



		public void Insert_DataExportXML(string IdSessione, DataSet ds, DateTime DataOraExportXML)
		{
			foreach (DataRow dr in ds.Tables["TransazioniValide"].Rows)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);

//				cmd.CommandType = CommandType.StoredProcedure;
//				cmd.CommandText = "CV.SP_EXPORT_XML_UPD";
//				cmd.Parameters.Add("IN_IDTRANSAZIONE", OleDbType.VarChar).Value = dr["IDTransazione"] ;
//				cmd.Parameters.Add("IN_DATAORAEXPORTXML", OleDbType.DBTimeStamp).Value = DataOraExportXML;
//				cmd.ExecuteNonQuery();

				cmd.CommandText = "UPDATE CV.Transazioni SET DataOraExportXML = ? WHERE IdTransazione = HEXTORAW(?)";
				cmd.Parameters.Add("DataOraExportXML", OleDbType.DBTimeStamp).Value = DataOraExportXML;
				cmd.Parameters.Add("IdTransazione", OleDbType.VarChar).Value = dr["IDTransazione"];
				cmd.ExecuteNonQuery();
			}

			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);

//				cmd.CommandType = CommandType.StoredProcedure;
//				cmd.CommandText = "CV.SP_NONISCRITTO_UPD";
//				cmd.Parameters.Add("IN_IDSESSIONE", OleDbType.VarChar).Value = IdSessione;
//				cmd.ExecuteNonQuery();

				cmd.CommandText = "UPDATE cv.NonIscritti SET DataOraInvio = SYSDATE WHERE idSessione = HEXTORAW(?)";
				cmd.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;
				cmd.ExecuteNonQuery();
			}
		}

	}
}
