using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Xml ;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminBase.
	/// </summary>
	internal class DLAdminBase
	{
		public static decimal MWhPerCVletto = -1;
		public static decimal MWhPerCV
		{
			get
			{	
				// Verifico se MWhPerCV non sia mai stata valorizzata
				if (MWhPerCVletto < 0)
				{
					using (IDbConnection cn = DLAdminCommon.GetDBConnection())
					{
						string strSqlQuery = @"SELECT VALORE FROM MCVSYS.PARAMETRI WHERE (IDPARAMETRO = 'MWhPerCV')";
						cn.Open();
						IDbTransaction dbTran = cn.BeginTransaction() ;
						using (OleDbDataAdapter da = new OleDbDataAdapter())
						{
							DataSet ds = new DataSet("dsParametri");
							OleDbCommand selectCMD = new OleDbCommand(strSqlQuery,(OleDbConnection)cn,(OleDbTransaction) dbTran );
							da.SelectCommand = selectCMD;
							da.Fill(ds, "Parametri");
							DataTable dt = ds.Tables["Parametri"];
							if (dt.Rows.Count != 0)
								if (!dt.Rows[0].IsNull("Valore"))
									MWhPerCVletto = XmlConvert.ToDecimal((string)dt.Rows[0]["Valore"]);
						}
						cn.Close();
					}
				}
				//Se il valore contenuto e` valido lo ritorno, altrimenti.... 50! 
				if (MWhPerCVletto >= 0)
					return MWhPerCVletto ; 
				else
					return 50 ; //debuggare!!
			}
		}

		/// <summary>
		/// Variabile contenente l'oggetto Transazione corrente.
		/// Tutte le Classi che derivano da questa DEVONO avere un oggetto Transazione
		/// in modo da poter effettuare le query in modo sicuro.
		/// </summary>
		protected OleDbTransaction m_Transaction = null;

		/// <summary>
		/// Costruttore della classe base per il DL.
		/// </summary>
		/// <param name="dbTransaction">
		/// Parametro contenente la transazione attiva sul DataBase
		/// </param>
		public DLAdminBase(IDbTransaction dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}
		/// <summary>
		/// Funzione che permette di recuperare la data di sistema del DataBase
		/// utile a tutte le classi del DL.
		/// </summary>
		/// <returns>La Data di sistema del DataBase</returns>
		public DateTime GetDBSystemDate()
		{
			return DLAdminCommon.GetDBSystemDate(m_Transaction);
		}


		public static bool MustCrypt
		{
			get { return DoCrypt(); }
		}
		public static string Encrypt(string s)
		{
			if (DoCrypt())
				return _sa.Encrypt(s);
			return s;
		}
		public static string Decrypt(string s)
		{
			if (DoCrypt())
				return _sa.Decrypt(s);
			return s;
		}
		static private bool DoCrypt()
		{
			if (_bFirstTime == false)
				return _sa != null;

			_bFirstTime = false;

			string s = ConfigurationSettings.AppSettings["Login.Crypt.Password"];
			if (s != null)
			{
				s = s.ToLower();
				if (s == "true" || s == "yes" || s == "si" || s == "1")
					_sa = new CVCommon.SimmetricEncryptDecrypt(new System.Security.Cryptography.RijndaelManaged(), 256, "apotoliga");
			}
			return _sa != null;
		}
		private static bool _bFirstTime = true;
		private static CVCommon.SimmetricEncryptDecrypt _sa = null;
	}
}
