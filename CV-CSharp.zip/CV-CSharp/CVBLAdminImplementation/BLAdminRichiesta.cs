using System;
using System.Data;
using System.Diagnostics;

namespace CV.Admin
{
	/// <summary>
	/// 
	/// </summary>
	public class BLAdminRichiesta : CVRemotingBase, IBLAdminRichiesta
	{
		public BLAdminRichiesta()
		{
		}

		public void UpdateNota(string IdRichiestaRegSoc, string Nota)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					_UpdateNota(tr, IdRichiestaRegSoc, Nota);
					tr.Commit();
					return;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
		
		public void _UpdateNota(IDbTransaction tr, string IdRichiestaRegSoc, string Nota)
		{
			DLAdminRichiesta dl = new DLAdminRichiesta(tr);
			dl.UpdateNota(IdRichiestaRegSoc, Nota);
			return;
		}


		public string IsReqSocietaValidated(string IdRichiestaRegSoc)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					string IdSocieta = _IsReqSocietaValidated(tr, IdRichiestaRegSoc);
					tr.Commit();
					return IdSocieta;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}

		public string _IsReqSocietaValidated(IDbTransaction tr, string IdRichiestaRegSoc)
		{
			DLAdminRichiesta dl = new DLAdminRichiesta(tr);
			return dl.IsReqSocietaValidated(IdRichiestaRegSoc);
		}

	}
}
