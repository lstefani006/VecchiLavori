using System;
using System.Data;
using System.Xml;
using System.Text;
using System.IO;
using System.Globalization;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for BLAdminTransazioni.
	/// </summary>
	public class BLAdminTransazioni : CVRemotingBase, IBLAdminTransazioni
	{
		public BLAdminTransazioni()
		{
		}

		public DataSet Ricerca(string RagioneSociale, string IdSessione, string TipoRicerca)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _Ricerca(dbTran, RagioneSociale, IdSessione, TipoRicerca);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal DataSet _Ricerca(IDbTransaction dbTran, string RagioneSociale, string IdSessione, string TipoRicerca)
		{
			DLAdminTransazioni dl = new DLAdminTransazioni(dbTran);
			DataSet ds = null;
			switch (TipoRicerca)
			{
				case "T":
					ds = dl.Ricerca(RagioneSociale, IdSessione);
				break;
				default:
					ds = null;
				break;
			}
			return ds;
		}

		public string GeneraFileXmlPerPagamenti(string IdSessione, string NomeFileXml, string IdFileXml)
		{
			// genera il file per i pagamenti
			// I pagamenti vengono accorpati per 
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					StringWriter sw = new StringWriter();
					XmlTextWriter tw = new XmlTextWriter(sw);
					tw.Formatting = Formatting.Indented;
					tw.WriteStartDocument();
					tw.WriteStartElement("TransazioniBancarie");

					// questa ritorna le transazioni da pagare ordinate
					// per societa' che vende, societa' che acquista
					// Richiede transazioni in stato Valida e 
					// pagabili dal GME e   (PagabileDaGme='SI')
					// non ancora esportate (FileExportBanca is NULL)
					DLAdminTransazioni dl = new DLAdminTransazioni(tr);
					DataSet ds = dl.RicercaRecordDaEsportareFileXml(IdSessione);

					string Acquirente_CC_Last = null;
					string Venditore_CC_Last = null;
					string Venditore_ABI_Last = null;
					string Venditore_CAB_Last = null;
					DateTime DataOraTransazione_Last= new DateTime(200,1,1,1,1,1); // un valore a caso

					int ProgrCausale = 1;
					decimal ImportoTransazione = 0m;

					// NB Acquirente_CC e' il CodiceConto e non e' roba del ABI/CAB/CC

					bool bFirst = true;
					foreach (DataRow dr in ds.Tables["TransazioniDaEsportare"].Rows)
					{
						if (bFirst)
						{
							bFirst = false; 
							ProgrCausale = 1;
							ImportoTransazione = 0m;

							Acquirente_CC_Last = (string)dr["Acquirente_CC"];
							Venditore_CC_Last = (string)dr["Venditore_CC"];
							Venditore_ABI_Last = (string)dr["Venditore_ABI"];
							Venditore_CAB_Last = (string)dr["Venditore_CAB"];
							DataOraTransazione_Last = (DateTime)dr["DataOraTransazione"];
						}

						// if per determinare la rottura del raggruppamento
						if (Acquirente_CC_Last != (string)dr["Acquirente_CC"] || 
							Venditore_CC_Last != (string)dr["Venditore_CC"] ||
							Venditore_ABI_Last != (string)dr["Venditore_ABI"] ||
							Venditore_CAB_Last != (string)dr["Venditore_CAB"])
						{
							// chiudo il gruppo precedente.
							AddTransazioneBancariaToXml(tw, 
								ImportoTransazione, 
								DataOraTransazione_Last, // questa sara' la valuta
								Acquirente_CC_Last, 
								Venditore_CC_Last, 
								Venditore_ABI_Last, 
								Venditore_CAB_Last, 
								IdFileXml + "-" + ProgrCausale.ToString());

							// mi preparo per il prossimo gruppo
							ImportoTransazione = 0;
							ProgrCausale = ProgrCausale + 1;

							Acquirente_CC_Last = (string)dr["Acquirente_CC"];
							Venditore_CC_Last = (string)dr["Venditore_CC"];
							Venditore_ABI_Last = (string)dr["Venditore_ABI"];
							Venditore_CAB_Last = (string)dr["Venditore_CAB"];
							DataOraTransazione_Last = (DateTime)dr["DataOraTransazione"];
						}

						// associo ad ogni transazione la causale
						string Causale = IdFileXml + "-" + ProgrCausale.ToString();
						dl.AssociaFileEtCausale((string)dr["IdTransazione"], NomeFileXml, Causale);

						ImportoTransazione += (Decimal)dr["ImportoTransazione"];
					}

					// qui potrebbe esserci un gruppo da terminare... me ne accorgo dall'importo
					if (ImportoTransazione != 0m)
					{
						string Causale = IdFileXml + "-" + ProgrCausale.ToString();
						AddTransazioneBancariaToXml(tw, 
							ImportoTransazione, 
							DataOraTransazione_Last, // questa sara' la valuta
							Acquirente_CC_Last, 
							Venditore_CC_Last, 
							Venditore_ABI_Last, 
							Venditore_CAB_Last, 
							Causale);
					}

					tr.Commit();

					// se tutto e' andato bene... ossia se la transazione database
					// e' completata ritorno l'xml generato.


					tw.WriteEndElement();
					tw.WriteEndDocument();
					tw.Flush();
					tw.Close();

					string xml = sw.ToString();
					return xml;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}


		public void AddTransazioneBancariaToXml(
			XmlTextWriter tw, decimal Importo, DateTime valuta, string ccAcquirente, 
			string ccVenditore, string ABIVenditore, string CABVenditore, string causale)
		{
			string strImporto = Importo.ToString("F2", CultureInfo.InvariantCulture);
			string strValuta = XmlConvert.ToString(valuta, "yyyy-MM-dd");

			tw.WriteStartElement("Transazione");
			if (true)
			{
				tw.WriteElementString("Importo",               strImporto);
				tw.WriteElementString("Valuta",                strValuta);
				tw.WriteElementString("ContoCodiceAcquirente", ccAcquirente);
				tw.WriteElementString("ContoCodiceVenditore",  ccVenditore);
				tw.WriteElementString("ABIVenditore",          ABIVenditore);
				tw.WriteElementString("CABVenditore",          CABVenditore);
				tw.WriteElementString("CausaleTransazione",    causale);
			}
			tw.WriteEndElement();
		}


		public DataSet ListaOperazioniAcquistoPerVenditore(string IdSessione, string IdSocietaAcquirente)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminTransazioni dl = new DLAdminTransazioni(tr);
					return dl.ListaOperazioniAcquistoPerVenditore(null, IdSessione, IdSocietaAcquirente);
				}
				catch (Exception ex)
				{
					tr.Rollback();
					throw ex;
				}
			}
		}
		public DataSet ListaOperazioniAcquistoPerAnno(string IdSessione, string IdSocietaAcquirente)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminTransazioni dl = new DLAdminTransazioni(tr);
					return dl.ListaOperazioniAcquistoPerAnno(null, IdSessione, IdSocietaAcquirente);
				}
				catch (Exception ex)
				{
					tr.Rollback();
					throw ex;
				}
			}
		}

		public DataSet ListaOperazioniVenditaPerAcquirente(string IdSessione, string IdSocietaVenditore)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminTransazioni dl = new DLAdminTransazioni(tr);
					return dl.ListaOperazioniVenditaPerAcquirente(null, IdSessione, IdSocietaVenditore);
				}
				catch (Exception ex)
				{
					tr.Rollback();
					throw ex;
				}
			}
		}

		public DataSet ListaOperazioniVenditaPerAnno(string IdSessione, string IdSocietaVenditore)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminTransazioni dl = new DLAdminTransazioni(tr);
					return dl.ListaOperazioniVenditaPerAnno(null, IdSessione, IdSocietaVenditore);
				}
				catch (Exception ex)
				{
					tr.Rollback();
					throw ex;
				}
			}
		}


		public DataSet DettagliAcquisti(string IdSessione, string IdSocietaAcquirente)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminTransazioni dl = new DLAdminTransazioni(tr);
					return dl.DettagliAcquisti(null, IdSessione, IdSocietaAcquirente);
				}
				catch (Exception ex)
				{
					tr.Rollback();
					throw ex;
				}
			}
		}
		public DataSet DettagliVendite(string IdSessione, string IdSocietaVenditore)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminTransazioni dl = new DLAdminTransazioni(tr);
					return dl.DettagliVendite(null, IdSessione, IdSocietaVenditore);
				}
				catch (Exception ex)
				{
					tr.Rollback();
					throw ex;
				}
			}
		}

		public void UpdateStatoTransazione(DataSet ds)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					_UpdateStatoTransazione(tr, ds);
					tr.Commit();
				}
				catch (Exception ex)
				{
					tr.Rollback();
					throw ex;
				}
			}
		}

		internal void _UpdateStatoTransazione(IDbTransaction dbTran, DataSet ds)
		{
			DLAdminTransazioni dl = new DLAdminTransazioni(dbTran);
			dl.UpdateStatoTransazione(ds);
		}


		public DataSet RetreivePagamenti(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminTransazioni dl = new DLAdminTransazioni(tr);
					DataSet ds = dl.RetrievePagamenti(IdSessione);
					tr.Commit();
					return ds;
				}
				catch (Exception ex)
				{
					tr.Rollback();
					throw ex;
				}
			}
		}


	}
}
