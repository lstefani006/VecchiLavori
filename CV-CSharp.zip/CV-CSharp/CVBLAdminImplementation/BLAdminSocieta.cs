using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class BLAdminSocieta : CVRemotingBase, IBLAdminSocieta
	{
		public BLAdminSocieta()
		{
		}
		
		public DataSet GetBankAccount(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _GetBankAccount(dbTran, IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal DataSet _GetBankAccount(IDbTransaction tr, string IdSessione)
		{
			DLAdminSocieta dl = new DLAdminSocieta(tr);
			return dl.GetBankAccount(IdSessione);
		}

		public DataSet GetCertificates(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _GetCertificates(dbTran, IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal DataSet _GetCertificates(IDbTransaction tr, string IdSessione)
		{
			DLAdminSocieta dl = new DLAdminSocieta(tr);
			return dl.GetCertificates(IdSessione);
		}

		public DataSet GetLista(string RagioneSociale)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLAdminSocieta dl = new DLAdminSocieta(dbTran);
					DataSet ds = dl.GetListaByRagioneSociale(RagioneSociale);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetLstStorico()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLAdminSocieta dl = new DLAdminSocieta(dbTran);
					DataSet ds = dl.GetLstStorico();
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet GetTotaleAcquisti(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DLAdminSocieta dl = new DLAdminSocieta(dbTran);
					DataSet ds = dl.GetTotaleAcquisti(IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet RetrieveByCodiceConto(IDbTransaction tr, string CodiceConto)
		{
			DLAdminSocieta dl = new DLAdminSocieta(tr);
			return dl.RetrieveByCodiceConto(CodiceConto);
		}

		public DataSet RetrieveByCodiceConto(string CodiceConto)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.RetrieveByCodiceConto(dbTran, CodiceConto);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		public DataSet Retrieve_Parameters(IDbTransaction tr, string TipoParametro)
		{
			DLAdminSocieta dl = new DLAdminSocieta(tr);
			return dl.Retrieve_Parameters(TipoParametro);
		}
		public DataSet Retrieve_Parameters(string TipoParametro)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.Retrieve_Parameters(dbTran, TipoParametro);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet Retrieve_SocietaUtenti()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this._Retrieve_SocietaUtenti(dbTran);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet _Retrieve_SocietaUtenti(IDbTransaction tr)
		{
			// Recupero prima la lista delle Societa'....
			DLAdminSocieta dlSocieta = new DLAdminSocieta(tr);
			DataSet dsSocieta = dlSocieta.GetListaByIdSocieta(null);

			// e poi la lista degli utenti
			DLAdminUtenti dlUtenti = new DLAdminUtenti(tr);
			DataSet dsUtenti = dlUtenti.Retrieve("", "");

			DataTable dtUtenti = dsUtenti.Tables[0].Copy();
			DataTable dtSocieta = dsSocieta.Tables[0];
			// Creo una copia della tabella in quanto NON si puo' aggiungere
			// ad un DataSet una tabella appartenente ad un altro Dataset.
			dsSocieta.Tables.Add(dtUtenti);
			
			// Creo la relazione tra le due tabelle [Societa, Budget]
			DataColumn societaCol = dtSocieta.Columns["IdSocieta"];
			DataColumn utentiCol = dtUtenti.Columns["IdSocieta"];
			DataRelation relSocietaUtenti = new DataRelation("relSocietaUtenti", societaCol, utentiCol);
			// Aggiungo la Relazione al DataSet
			dsSocieta.Relations.Add(relSocietaUtenti);

//			DataRelation relUtentiSocieta = new DataRelation("relUtentiSocieta", utentiCol, societaCol);
//			dsSocieta.Relations.Add(relUtentiSocieta);

					
			return dsSocieta;
		}

		public void	Update(DataSet ds, string IdSocieta, string nominativo)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					this._Update(dbTran, ds, IdSocieta, nominativo);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public void	_Update(IDbTransaction tr, DataSet ds, string IdSocieta, string nominativo)
		{
			DLAdminSocieta dl = new DLAdminSocieta(tr);
			dl.Update(ds, IdSocieta, nominativo);
		}

		public string Valida(string IdRichiestaRegSoc, string nominativo)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					string IdSocieta = this._Valida(dbTran, IdRichiestaRegSoc, nominativo);
					dbTran.Commit();
					return IdSocieta;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public string _Valida(IDbTransaction tr, string IdRichiestaRegSoc, string nominativo)
		{
			DLAdminSocieta dl = new DLAdminSocieta(tr);
			return dl.Valida(IdRichiestaRegSoc, nominativo);
		}

		public void InizializzaStorico()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					this._InizializzaStorico(dbTran);
					dbTran.Commit();
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public void _InizializzaStorico(IDbTransaction tr)
		{
			DLAdminSocieta dl = new DLAdminSocieta(tr);
			dl.InizializzaStorico();
		}
	}
}
