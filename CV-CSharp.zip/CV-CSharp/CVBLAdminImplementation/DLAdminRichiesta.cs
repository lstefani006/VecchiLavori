using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Admin
{
	/// <summary>
	/// 
	/// </summary>
	internal class DLAdminRichiesta : DLAdminBase
	{
		public DLAdminRichiesta(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public void UpdateNota(string IdRichiestaRegSoc, string Nota)
		{
			string sqlUpdate =	"UPDATE US.RichiesteRegSoc " +
								"SET Nota = ? " +
								"WHERE IdRichiestaRegSoc = HEXTORAW(?)";

			OleDbCommand cmdUpdate = new OleDbCommand(sqlUpdate, m_Transaction.Connection, m_Transaction);

			// Aggiungo i parametri della Query
			cmdUpdate.Parameters.Add("Nota",				OleDbType.VarChar).Value = Nota;
			cmdUpdate.Parameters.Add("IdRichiestaRegSoc",	OleDbType.VarChar).Value = IdRichiestaRegSoc;

			// Eseguo la Query
			cmdUpdate.ExecuteNonQuery();
		}

		public string IsReqSocietaValidated(string IdRichiestaRegSoc)
		{
			string sql = "SELECT RAWTOHEX(IdSocieta) FROM US.SOCIETA WHERE IdRichiestaRegSoc = HEXTORAW(?)";

			OleDbCommand cmd = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
			// Aggiungo i parametri della Query
			cmd.Parameters.Add("IdRichiestaRegSoc",	OleDbType.VarChar).Value = IdRichiestaRegSoc;
			// Eseguo la Query
			object obj = cmd.ExecuteScalar();
			if (obj == null)
				return null;
			else if (obj is string)
				return cmd.ExecuteScalar().ToString();
			else
				return null;
		}
	}
}
