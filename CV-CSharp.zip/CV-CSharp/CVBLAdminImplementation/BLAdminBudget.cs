using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for BLAdminBudget.
	/// </summary>
	public class BLAdminBudget : CVRemotingBase, IBLAdminBudget
	{
		public BLAdminBudget()
		{
		}

		public decimal MWhPerCV
		{
			get
			{
				return DLAdminBase.MWhPerCV;
			}
		}

		public void Delete(string IdSocieta, string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					this.Delete(dbTran, IdSocieta, IdSessione);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal void Delete(IDbTransaction dbTran, string IdSocieta, string IdSessione)
		{
			DLAdminBudget dl = new DLAdminBudget(dbTran);
			dl.Delete(IdSocieta, IdSessione);
			return;
		}

		public void DeleteSessione(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					this.DeleteSessione(dbTran, IdSessione);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal void DeleteSessione(IDbTransaction dbTran, string IdSessione)
		{
			DLAdminBudget dl = new DLAdminBudget(dbTran);
			dl.DeleteSessione(IdSessione);
		}

		public void Insert(DataSet ds)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					this.Insert(dbTran, ds);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal void Insert(IDbTransaction dbTran, DataSet ds)
		{
			DLAdminBudget dl = new DLAdminBudget(dbTran);
			dl.Insert(ds);
			return;
		}


		public void Update(DataSet ds)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					this.Update(dbTran, ds);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		internal void Update(IDbTransaction dbTran, DataSet ds)
		{
			DLAdminBudget dl = new DLAdminBudget(dbTran);
			dl.Update(ds);
			DLAdminSocieta dlSoc = new DLAdminSocieta(dbTran);
			dlSoc.Update(ds, "", "");
			return;
		}

		public DataSet Retrieve(string IdSocieta, string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					// Creo un unico DataSet contenente sia i dati delle societa
					// sia i loro dati di budget.

					// Qui carico il budget (IdSocieta puo' essere "" o null ==> tutte le societa)
					DataSet dsBudget = this.Get(dbTran, IdSocieta, IdSessione);

					// Qui carico i dati della societa (o di tutte)
					DLAdminSocieta dlSocieta = new DLAdminSocieta(dbTran);
					DataSet dsSocieta = dlSocieta.GetListaByIdSocieta(IdSocieta);

					DataTable dtSocieta = dsSocieta.Tables[0].Copy();

					// Creo una copia della tabella in quanto NON si puo' aggiungere
					// ad un DataSet una tabella appartenente ad un altro Dataset.					
					dsBudget.Tables.Add(dtSocieta);
				
					// Creo la relazione tra le due tabelle [Societa, Budget]
					DataTable dtBudget = dsBudget.Tables[0];
					DataColumn societaCol = dtSocieta.Columns["IdSocieta"];
					DataColumn budgetCol = dsBudget.Tables["Budgets"].Columns["IdSocieta"];
					DataRelation relSocietaBudget = new DataRelation("relSocietaBudget", societaCol, budgetCol);
					dsBudget.Relations.Add(relSocietaBudget);
					
					dbTran.Commit();
					return dsBudget;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		internal DataSet Get(IDbTransaction dbTran, string IdSocieta, string IdSessione)
		{
			DLAdminBudget dl = new DLAdminBudget(dbTran);
			DataSet ds = dl.Get(IdSessione, IdSocieta);
			return ds;
		}

		public DataSet GetBudgetSessionePrecedente(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DataSet ds = GetBudgetSessionePrecedente(tr, IdSessione);
					tr.Commit();
					return ds;
				}
				catch(Exception)
				{
					tr.Rollback();
					throw;
				}
			}
		}
		internal DataSet GetBudgetSessionePrecedente(IDbTransaction dbTran, string IdSessione)
		{
			DLAdminBudget dl = new DLAdminBudget(dbTran);
			DataSet ds = dl.GetBudgetSessionePrecedente(IdSessione);
			return ds;
		}


		/// <summary>
		/// Ritorna un DataSet che contiene: IdSessione, StatoSessione, DataOraApertura delle sessioni
		/// precedenti alla sessione <code>IdSessione</code>
		/// </summary>
		/// <param name="IdSessione">sessione</param>
		/// <returns>un data set delle sessioni precedenti</returns>
		public DataSet GetStatoSessioneSessionePrecedenti(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminBudget dl = new DLAdminBudget(tr);
					DataSet ds = dl.GetStatoSessioneSessioniPrecedenti(IdSessione);
					tr.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
	}
}
