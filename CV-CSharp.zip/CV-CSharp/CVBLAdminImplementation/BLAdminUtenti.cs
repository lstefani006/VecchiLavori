using System;
using System.Data;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for BLAdminUtenti.
	/// </summary>
	public class BLAdminUtenti : CVRemotingBase, IBLAdminUtenti
	{
		public BLAdminUtenti()
		{
		}

		public void Update(DataSet ds, string IdUtente, string nominativo)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					_Update(dbTran, ds, IdUtente, nominativo);
					dbTran.Commit();
					return;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public void _Update(IDbTransaction tr, DataSet ds, string IdUtente, string nominativo)
		{
			DLAdminUtenti dl = new DLAdminUtenti(tr);
			dl.Update(ds, IdUtente, nominativo);
			return;
		}

		public DataSet Retrieve(string Nominativo, string CodiceFiscale)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _Retrieve(dbTran, Nominativo, CodiceFiscale);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet _Retrieve(IDbTransaction tr, string Nominativo, string CodiceFiscale)
		{
			DLAdminUtenti dl = new DLAdminUtenti(tr);
			return dl.Retrieve(Nominativo, CodiceFiscale);
		}

		public DataSet GetLstStorico()
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = _GetLstStorico(dbTran);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public DataSet _GetLstStorico(IDbTransaction tr)
		{
			DLAdminUtenti dl = new DLAdminUtenti(tr);
			return dl.GetLstStorico();
		}

		public string Valida(string IdSocietaParent, string IdRichiestaRegUtente, string nominativo)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					string IdUtente = _Valida(dbTran, IdSocietaParent, IdRichiestaRegUtente, nominativo);
					dbTran.Commit();
					return IdUtente;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		public string _Valida(IDbTransaction tr, string IdSocietaParent, string IdRichiestaRegUtente, string nominativo)
		{
			DLAdminUtenti dl = new DLAdminUtenti(tr);
			return dl.Valida(IdSocietaParent, IdRichiestaRegUtente, nominativo);
		}

		public bool Login(string User, string Pwd, string DN, string TipoUtente)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					DLAdminUtenti dl = new DLAdminUtenti(tr);

					bool b;
					if (DN != null && DN != "")
					{
						// login con il certificato: mi passo il DN
						b = dl.Login(DN, TipoUtente);
					}
					else if (User != null && Pwd != null)
					{
						// login con login/pwd
						b = dl.Login(User, Pwd, TipoUtente);
					}
					else
						b = false;

					tr.Commit();
					return b;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
	}
}
