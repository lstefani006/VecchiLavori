using System;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;
using System.Windows.Forms;  // utilizzato solo per ConvertEventArgs

namespace CV.Admin
{
	internal class Converter
	{
		static private CultureInfo ci = null;

		public static CultureInfo DefaultCultureInfo 
		{ 
			get { ReadCulture(); return ci; } 
		}

		private static void ReadCulture()
		{
			if (ci == null)
			{
				bool bUseOverride = false;

				string strUseOverride = "False" ;
				if (strUseOverride != null)
				{
					strUseOverride = strUseOverride.ToLower();
					if (strUseOverride == "true" ||
						strUseOverride == "yes" || 
						strUseOverride == "si" || 
						strUseOverride == "1")
					{
						bUseOverride = true;
					}
				}


				ci = new CultureInfo("it-IT", bUseOverride);
				if (ci.NumberFormat.CurrencySymbol != "�")
					ci.NumberFormat.CurrencySymbol = "�";
			}
		}

		/// <summary>
		/// Conversione da un decimal che rappresenta un currency ad una stringa
		/// rispettando il formato italiano di default (non quello utente).
		/// Il formato dovrebbe essere �1.234,56
		/// </summary>
		/// <param name="d">la quantita' di euro da convertire</param>
		/// <returns>la stringa in euro</returns>
		public static string DecimalToCurrencyString(decimal d)
		{
			ReadCulture();
			return d.ToString("c", ci.NumberFormat);
		}
		/// <summary>
		/// Conversione da decima a string in formato currency
		/// Da usare nell'evento Format
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="cevent"></param>
		public static void DecimalToCurrencyString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(string))
			{
				decimal d = ((decimal) cevent.Value);
				cevent.Value = Converter.DecimalToCurrencyString(d);
			}
		}
		/// <summary>
		/// Converte un decimal in una stringa in formato currency
		/// partendo da un DataRow e una colonna. Se il valore e' null
		/// viene ritornata  ""
		/// </summary>
		/// <param name="dr">il data row da cui prelevare il valore da convertire</param>
		/// <param name="columnName">la colonna nel data row da leggere</param>
		/// <returns>la stringa in formato currency</returns>
		public static string DecimalToCurrencyString(DataRow dr, string columnName)
		{
			if (dr.IsNull(columnName))
				return "";

			return DecimalToCurrencyString((decimal)dr[columnName]);
		}
		
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////


		/// <summary>
		/// parsifica la stringa in ingresso per ottere un decimal
		/// La stringa deve essere in formato �1.234,56
		/// In caso di errore di formattazione viene lanciata una eccezione
		/// </summary>
		/// <param name="s">stringa da convertire</param>
		/// <returns>il numero convertito</returns>
		public static decimal CurrencyStringToDecimal(string s)
		{
			ReadCulture();

			// faccio due volte parse per ottenere il giusto numero di cifre significative
			// anche nel decimal e non solo nella stringa che lo rappresenta.
			decimal r = decimal.Parse(s, NumberStyles.Currency, ci.NumberFormat);
			string g = DecimalToCurrencyString(r);
			return decimal.Parse(g, NumberStyles.Currency, ci.NumberFormat);
		}
		/// <summary>
		/// parsifica la stringa in ingresso per ottere un decimal
		/// La stringa deve essere in formato �1.234,56
		/// </summary>
		/// <param name="s">la stringa da convertire</param>
		/// <param name="d">il numero convertito</param>
		/// <returns>true se la conversione e' avvenuta con successo</returns>
		public static bool CurrencyStringToDecimal(string s, out decimal d)
		{
			try
			{
				d = CurrencyStringToDecimal(s);
				return true;
			}
			catch (Exception)
			{
				d = 0m;
				return false;
			}
		}
		/// <summary>
		/// Prende un decimal e lo stampa su stringa in formato currency
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="cevent"></param>
		public static void CurrencyStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(decimal))
				cevent.Value = Converter.CurrencyStringToDecimal(cevent.Value.ToString());
		}

		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////

		/// <summary>
		/// Conversione da numero (non valuta!!) a stringa nel formato
		/// italiano 1.234,56
		/// </summary>
		/// <param name="d">numero da formtattare</param>
		/// <returns>stringa formattata</returns>
		public static string DecimalToNumberString(decimal d)
		{
			ReadCulture();
			return d.ToString("n", ci.NumberFormat);
		}
		public static string DecimalToNumberString(DataRow dr, string columnName)
		{
			ReadCulture();
			if (dr.IsNull(columnName))
				return "";
			return DecimalToNumberString((decimal)dr[columnName]);
		}
		public static void DecimalToNumberString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(string))
			{
				decimal d = ((decimal) cevent.Value);
				cevent.Value = Converter.DecimalToNumberString(d);
			}
		}
		/// <summary>
		/// parsifica la stringa in ingresso per ottere un decimal
		/// La stringa deve essere in formato 1.234,56
		/// In caso di errore di formattazione viene lanciata una eccezione
		/// </summary>
		/// <param name="s">stringa da convertire</param>
		/// <returns>il numero</returns>
		public static decimal NumberStringToDecimal(string s)
		{
			ReadCulture();
			decimal d = decimal.Parse(s, NumberStyles.Number, ci.NumberFormat);
			string g = DecimalToNumberString(d);
			return decimal.Parse(g, NumberStyles.Number, ci.NumberFormat);
		}
		/// <summary>
		/// parsifica la stringa in ingresso per ottere un decimal
		/// La stringa deve essere in formato 1.234,56
		/// </summary>
		/// <param name="s">la stringa da convertire</param>
		/// <param name="d">il numero convertito</param>
		/// <returns>true se la conversione e' avvenuta con successo</returns>
		public static bool NumberStringToDecimal(string s, out decimal d)
		{
			try
			{
				d = NumberStringToDecimal(s);
				return true;
			}
			catch (Exception)
			{
				d = 0m;
				return false;
			}
		}
		public static void NumberStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(decimal))
			{
				string s = (string)cevent.Value;
				cevent.Value = Converter.NumberStringToDecimal(s);
			}
		}
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////

		/// <summary>
		/// Conversione da numero (non valuta!!) a stringa nel formato
		/// italiano 1.234.333  (senza parte decimale!!!!)
		/// </summary>
		/// <param name="d">numero da formtattare</param>
		/// <returns>stringa formattata</returns>
		public static string DecimalToIntegerString(decimal d)
		{
			ReadCulture();
			return d.ToString("#,#0", ci.NumberFormat);
		}
		public static string DecimalToIntegerString(DataRow dr, string columnName)
		{
			if (dr.IsNull(columnName))
				return "";

			return DecimalToIntegerString((decimal)dr[columnName]);
		}
		public static void DecimalToIntegerString(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(string))
			{
				decimal d = ((decimal) cevent.Value);
				cevent.Value = Converter.DecimalToIntegerString(d);
			}
		}
		public static decimal IntegerStringToDecimal(string s)
		{
			ReadCulture();
			if (s.IndexOf(ci.NumberFormat.NumberDecimalSeparator) != -1)
				throw new FormatException("non si accetta il punto decimale"); 
			return decimal.Parse(s, NumberStyles.Number, ci.NumberFormat);
		}
		public static void IntegerStringToDecimal(object sender, ConvertEventArgs cevent)
		{
			if (cevent.DesiredType == typeof(decimal))
			{
				string s = (string)cevent.Value;
				cevent.Value = Converter.IntegerStringToDecimal(s);
			}
		}
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////

		public static string StringToString(DataRow dr, string columnName)
		{
			ReadCulture();

			if (dr.IsNull(columnName))
				return "";

			return (string)dr[columnName];
		}

		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////
		// /////////////////////////////////////////////////////////////////////////

		/// <summary>
		/// converte la data nel formato "g" che dovrebbe essere in italiano 23/1/2003 15:33:59
		/// </summary>
		/// <param name="dt"></param>
		/// <returns></returns>
		public static string DateTimeToStringDateTime(DateTime dt)
		{
			ReadCulture();
			return dt.ToString("g", ci.DateTimeFormat);
		}
		/// <summary>
		/// converte la data nel formato "g" che dovrebbe essere in italiano 23/1/2003 15:33:59.
		/// Valori DbNull sono convertiti in ""
		/// </summary>
		/// <param name="dr">DataRow da cui estrarre il campo</param>
		/// <param name="columnName">colonna del data row</param>
		/// <returns></returns>
		public static string DateTimeToStringDateTime(DataRow dr, string columnName)
		{
			ReadCulture();

			if (dr.IsNull(columnName))
				return "";

			return DateTimeToStringDateTime((DateTime)dr[columnName]);
		}
		/// <summary>
		/// Converte il DateTime nella sola data formato 21/1/2004
		/// </summary>
		/// <param name="dt"></param>
		/// <returns></returns>
		public static string DateTimeToStringDate(DateTime dt)
		{
			ReadCulture();
			return dt.ToString("d", ci.DateTimeFormat);
		}
	}
}
