using System;
using System.Data;
using System.Xml;
using System.Text;
using System.IO;

namespace CV.Admin
{
	public class BLAdminTransazione : CVRemotingBase, IBLAdminTransazione
	{
		public BLAdminTransazione()
		{
		}

		/////////////////////////////////////////////////////////////////////
		/// <summary>
		/// </summary>
		/// <param name="tr"></param>
		/// <param name="IdSessione"></param>
		/// <returns></returns>
		public DataSet TransazioniValide(IDbTransaction tr, string IdSessione)
		{
			DLAdminTransazione dl = new DLAdminTransazione(tr);
			return dl.TransazioniValide(IdSessione);
		}
		public DataSet TransazioniValide(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.TransazioniValide(dbTran, IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		/////////////////////////////////////////////////////////////////////
		public int NumeroTransazioniValide(IDbTransaction tr, string IdSessione)
		{
			DLAdminTransazione dl = new DLAdminTransazione(tr);
			return dl.NumeroTransazioniValide(IdSessione);
		}
		public int NumeroTransazioniValide(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					int n = this.NumeroTransazioniValide(dbTran, IdSessione);
					dbTran.Commit();
					return n;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}


		/////////////////////////////////////////////////////////////////////

		public DataSet ContiDaSbloccare(IDbTransaction tr, string IdSessione)
		{
			DLAdminTransazione dl = new DLAdminTransazione(tr);
			return dl.ContiDaSbloccare(IdSessione);
		}
		public DataSet ContiDaSbloccare(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.ContiDaSbloccare(dbTran, IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}

		/////////////////////////////////////////////////////////////////////

		public DataSet ExportXMLTransazioni(IDbTransaction tr, string IdSessione)
		{
			DLAdminTransazione dl = new DLAdminTransazione(tr);
			return dl.ExportXMLTransazioni(IdSessione);
		}
		public DataSet ExportXMLTransazioni(string IdSessione)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction dbTran = cn.BeginTransaction();
				try
				{
					DataSet ds = this.ExportXMLTransazioni(dbTran, IdSessione);
					dbTran.Commit();
					return ds;
				}
				catch(Exception exc)
				{
					dbTran.Rollback();
					throw exc;
				}
			}
		}
		/////////////////////////////////////////////////////////////////////
		public void Insert_DataExportXML(IDbTransaction tr, string IdSessione, DataSet ds, DateTime DataOraExportXML)
		{
			DLAdminTransazione dl = new DLAdminTransazione(tr);
			dl.Insert_DataExportXML(IdSessione, ds, DataOraExportXML);
		}
		public void Insert_DataExportXML(string IdSessione, DataSet ds, DateTime DataOraExportXML)
		{
			using (IDbConnection cn = DLAdminCommon.GetDBConnection())
			{
				cn.Open();
				IDbTransaction tr = cn.BeginTransaction();
				try
				{
					this.Insert_DataExportXML(tr, IdSessione, ds, DataOraExportXML);
					tr.Commit();
					return;
				}
				catch(Exception exc)
				{
					tr.Rollback();
					throw exc;
				}
			}
		}
		/////////////////////////////////////////////////////////////////////
	}
}
