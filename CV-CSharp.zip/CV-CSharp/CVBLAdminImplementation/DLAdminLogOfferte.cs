using System;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;


namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminSessione.
	/// </summary>
	internal class DLAdminLogOfferte : DLAdminBase
	{
		public DLAdminLogOfferte(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public DataSet RetrieveAcquisto(string IdSessione, string RagioneSociale, string Anno, string CodiceConto)
		{
			string q;
			q = "SELECT RAWTOHEX(L.IdLog) AS IdLog, " + 
				"L.TipoOperazione, " + 
				"S.RagioneSociale, " +
				"S.CodiceConto, " +
				"RAWTOHEX(L.IdOffertaAcquisto) AS IdOffertaAcquisto, " + 
				"L.QtyRichiesta, " +
				"L.QtyResidua, " + 
				"L.AnnoRiferimento, " + 
				"L.PrezzoUnitario, " + 
				"L.DataOraCreazione, " +
				"L.DataOraModifica, " +
				"RAWTOHEX(L.IdSessione) AS IdSessione, " + 
				"RAWTOHEX(L.IdUtente) AS IdUtente " +
				"FROM cv.LogOfferteAcquisto L, us.Utenti U, us.Societa S " +
				"WHERE L.IdUtente = U.IdUtente " +
				"  AND U.IdSocieta = S.IdSocieta " +
				"  AND L.IdSessione = HEXTORAW(?) ";


			OleDbDataAdapter da = new OleDbDataAdapter();
			da.SelectCommand = new OleDbCommand();
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;

			if (RagioneSociale != null && RagioneSociale.Length > 0)
			{
				q += "  AND S.RagioneSociale LIKE ? ";
				da.SelectCommand.Parameters.Add("RagioneSociale", OleDbType.VarChar).Value = "%" + RagioneSociale + "%";
			}

			if (Anno != null && Anno.Length > 0)
			{
				q += "  AND L.AnnoRiferimento = ? ";
				da.SelectCommand.Parameters.Add("Anno", OleDbType.VarChar).Value = Anno;
			}

			if (CodiceConto != null && CodiceConto.Length > 0)
			{
				q += "  AND S.CodiceConto LIKE ? ";
				da.SelectCommand.Parameters.Add("CodiceConto", OleDbType.VarChar).Value = "%" + CodiceConto + "%";
			}
			
			da.SelectCommand.CommandText = q + "ORDER BY L.DataOraModifica ASC";
			da.SelectCommand.Connection = m_Transaction.Connection;
			da.SelectCommand.Transaction = m_Transaction;

			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("RetrieveAcquisto");
			dt.Columns.Add("IdLog", typeof(string));
			dt.Columns.Add("TipoOperazione", typeof(string));
			dt.Columns.Add("RagioneSociale", typeof(string));
			dt.Columns.Add("CodiceConto", typeof(string));
			dt.Columns.Add("IdOffertaAcquisto", typeof(string));
			dt.Columns.Add("QtyRichiesta", typeof(decimal));
			dt.Columns.Add("QtyResidua", typeof(decimal));
			dt.Columns.Add("AnnoRiferimento", typeof(string));
			dt.Columns.Add("PrezzoUnitario", typeof(decimal));
			dt.Columns.Add("DataOraCreazione", typeof(DateTime));
			dt.Columns.Add("DataOraModifica", typeof(DateTime));
			dt.Columns.Add("IdSessione", typeof(string));
			dt.Columns.Add("IdUtente", typeof(string));

			da.Fill(ds, "RetrieveAcquisto");
			return ds;
		}
		public DataSet RetrieveVendita (string IdSessione, string RagioneSociale, string Anno, string CodiceConto)
		{
			string q;
			q = "SELECT RAWTOHEX(L.IdLog) AS IdLog, L.TipoOperazione, S.RagioneSociale, " +
				"S.CodiceConto, " +
				"RAWTOHEX(L.IdOffertaVendita) AS IdOffertaVendita, L.QtyOfferta, " +
				"L.QtyResidua, L.AnnoRiferimento, L.PrezzoUnitario, L.DataOraCreazione, " +
				"L.DataOraModifica, RAWTOHEX(L.IdSessione) AS IdSessione, RAWTOHEX(L.IdUtente) AS IdUtente " +
				"FROM cv.LogOfferteVendita L, us.Utenti U, us.Societa S " +
				"WHERE L.IdUtente = U.IdUtente " +
				"  AND U.IdSocieta = S.IdSocieta " +
				"  AND L.IdSessione = HEXTORAW(?) ";

			OleDbDataAdapter da = new OleDbDataAdapter();
			da.SelectCommand = new OleDbCommand();
			da.SelectCommand.Parameters.Add("IdSessione", OleDbType.VarChar).Value = IdSessione;

			if (RagioneSociale != null && RagioneSociale.Length > 0)
			{
				q += "  AND S.RagioneSociale LIKE ? ";
				da.SelectCommand.Parameters.Add("RagioneSociale", OleDbType.VarChar).Value = "%" + RagioneSociale + "%";
			}

			if (Anno != null && Anno.Length > 0)
			{
				q += "  AND L.AnnoRiferimento = ? ";
				da.SelectCommand.Parameters.Add("Anno", OleDbType.VarChar).Value = Anno;
			}

			if (CodiceConto != null && CodiceConto.Length > 0)
			{
				q += "  AND S.CodiceConto LIKE ? ";
				da.SelectCommand.Parameters.Add("CodiceConto", OleDbType.VarChar).Value = "%" + CodiceConto + "%";
			}

			da.SelectCommand.CommandText = q + "ORDER BY L.DataOraModifica ASC";
			da.SelectCommand.Connection = m_Transaction.Connection;
			da.SelectCommand.Transaction = m_Transaction;

			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("RetrieveVendita");
			dt.Columns.Add("IdLog", typeof(string));
			dt.Columns.Add("TipoOperazione", typeof(string));
			dt.Columns.Add("RagioneSociale", typeof(string));
			dt.Columns.Add("CodiceConto", typeof(string));
			dt.Columns.Add("IdOffertaVendita", typeof(string));
			dt.Columns.Add("QtyOfferta", typeof(decimal));
			dt.Columns.Add("QtyResidua", typeof(decimal));
			dt.Columns.Add("AnnoRiferimento", typeof(string));
			dt.Columns.Add("PrezzoUnitario", typeof(decimal));
			dt.Columns.Add("DataOraCreazione", typeof(DateTime));
			dt.Columns.Add("DataOraModifica", typeof(DateTime));
			dt.Columns.Add("IdSessione", typeof(string));
			dt.Columns.Add("IdUtente", typeof(string));

			da.Fill(ds, "RetrieveVendita");
			return ds;
		}

	}
}
