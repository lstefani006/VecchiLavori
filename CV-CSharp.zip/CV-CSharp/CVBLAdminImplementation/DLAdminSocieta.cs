using System;
using System.Data;
using System.Data.OleDb;

namespace CV.Admin
{
	/// <summary>
	/// Summary description for DLAdminSocieta.
	/// </summary>
	internal class DLAdminSocieta : DLAdminBase
	{
		public DLAdminSocieta(IDbTransaction dbTransaction) : base(dbTransaction)
		{
			m_Transaction = (OleDbTransaction)dbTransaction;
		}

		public DataSet GetBankAccount(string IdSessione)
		{
			string sql = "SELECT S.RagioneSociale, " +
						 "RAWTOHEX(S.IdSocieta) AS IdSocieta, " +
						 "B.Importo, " + 
						 "B.PrezzoConvenzionaleUtenteMw, " + 
						 "B.QtyMax, " + 
						 "B.QtyImpegnata, " +
						 "(B.QtyMax - B.QtyImpegnata) AS QtyDisponibile " +
						 "FROM US.Societa S, CV.Budgets B " +
						 "WHERE B.IdSocieta  = S.IdSocieta " +
						 "AND B.IdSessione = HEXTORAW(?)";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
				DataSet ds = new DataSet("dsBankAccount");
				da.Fill(ds, "BankAccount");
				return ds;
			}
		}

		public DataSet GetCertificates(string IdSessione)
		{
			string sql = "SELECT RAWTOHEX(S.IdSocieta) AS IdSocieta, " + 
						 "C.IdCertificatoVerde, " + 
						 "C.AnnoRiferimento, " + 
						 "C.QtyImpegnata, " + 
						 "C.Qty, " +  
						 "(C.Qty - C.QtyImpegnata) AS QtyDisponibile " +
						 "FROM CV.CertificatiVerdi C, US.Societa S " +
						 "WHERE S.IdSocieta = C.IdSocieta AND " + 
						 "C.IdSessione = HEXTORAW(?) " +
						 "ORDER BY C.AnnoRiferimento DESC";

			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
				DataSet ds = new DataSet("dsCertificates");
				da.Fill(ds, "Certificate");
				return ds;
			}
		}

		public DataSet GetListaByRagioneSociale(string RagioneSociale)
		{
			OleDbDataAdapter da = null;

			if (RagioneSociale != null && RagioneSociale.Length > 0)
			{
				RagioneSociale += "%";
				OleDbParameter par = new OleDbParameter("RagioneSociale", OleDbType.VarChar);
				par.Value = RagioneSociale;
				string sql = "WHERE RagioneSociale LIKE ? ORDER BY RagioneSociale";

				da = GetDataAdapter(sql, par);
			}
			else
			{
				da = GetDataAdapter();
				da.SelectCommand.CommandText += " ORDER BY RagioneSociale";
			}

			DataSet ds = DataSet_Societa();
			da.Fill(ds, "Societa");
			return ds;
		}

		/// <summary>
		/// Ottiene i dati della societa passata come parametro.
		/// Se IdSocieta e' "" o null ritorna tutte le societa
		/// </summary>
		/// <param name="IdSocieta"></param>
		/// <returns></returns>
		public DataSet GetListaByIdSocieta(string IdSocieta)
		{
			OleDbDataAdapter da = null;

			if (IdSocieta != null && IdSocieta.Length > 0)
			{
				OleDbParameter par = new OleDbParameter("IdSocieta", OleDbType.VarChar);
				par.Value = IdSocieta;

				da = GetDataAdapter("WHERE IdSocieta = HEXTORAW(?)", par);
			}
			else
			{
				da = GetDataAdapter();
				da.SelectCommand.CommandText += " ORDER BY RagioneSociale";
			}

			using (da)
			{
				DataSet ds = DataSet_Societa();
				da.Fill(ds, "Societa");
				return ds;
			}
		}


		public DataSet GetTotaleAcquisti(string IdSessione)
		{
//			/*cento*/  Stefano: query originaria...
//			string sql = @"
//				SELECT RAWTOHEX(S.IdSocieta) AS IdSocieta, 
//					s.ragionesociale RagioneSociale, 
//					SUM(T.QtyCertificati * T.PrezzoUnitario * 100 /*cento*/) TotaleAcquisti 
//					FROM cv.OfferteAcquisto O, US.Utenti U, US.Societa S, cv.Transazioni T 
//					WHERE O.IdUtente = U.IdUtente 
//					AND U.IdSocieta = S.IdSocieta 
//					AND T.IdOffertaAcquisto = O.IdOffertaAcquisto 
//					AND O.IdSessione = HEXTORAW(?)
//					GROUP BY S.idsocieta, S.ragionesociale
//				";

			//Stefano la select e` stata modificata !! V E R I F I C A R E !!
			string sql = @"
				SELECT RAWTOHEX(S.IdSocieta) AS IdSocieta, 
					s.ragionesociale RagioneSociale, 
					SUM(T.QtyCertificati * T.PrezzoUnitario * "
				   + DLAdminBase.MWhPerCV.ToString() + 
					@") TotaleAcquisti 
					FROM cv.OfferteAcquisto O, US.Utenti U, US.Societa S, cv.Transazioni T 
					WHERE O.IdUtente = U.IdUtente 
					AND U.IdSocieta = S.IdSocieta 
					AND T.IdOffertaAcquisto = O.IdOffertaAcquisto 
					AND O.IdSessione = HEXTORAW(?)
					GROUP BY S.idsocieta, S.ragionesociale
				";
			using (OleDbDataAdapter da = new OleDbDataAdapter())
			{
				OleDbCommand selectCMD = new OleDbCommand(sql, m_Transaction.Connection, m_Transaction);
				da.SelectCommand = selectCMD;
				selectCMD.Parameters.Add("@IdSessione", OleDbType.VarChar, 32).Value = IdSessione;
				DataSet ds = new DataSet("dsTotaleAcquisti");
				da.Fill(ds, "TotaleAcquisti");
				return ds;
			}
		}

		public DataSet RetrieveByCodiceConto(string CodiceConto)
		{
			OleDbParameter par = new OleDbParameter("CodiceConto", OleDbType.VarChar);
			par.Value = CodiceConto;

			string sql = "WHERE CodiceConto=?";
			using (OleDbDataAdapter da = GetDataAdapter(sql, par))
			{
				DataSet ds = DataSet_Societa();
				da.Fill(ds, "Societa");
				return ds;
			}
		}

		public void UpdChiaveCodiceConto(string IdSocieta, string NumeroConto)
		{
			OleDbParameter par = new OleDbParameter("IdSocieta", OleDbType.VarChar);
			par.Value = IdSocieta;

			string sql = "WHERE IdSocieta = HEXTORAW(?)";

			using (OleDbDataAdapter da = GetDataAdapter(sql, par))
			{
				DataSet ds = DataSet_Societa();
				da.Fill(ds, "Societa");

				ds.Tables["Societa"].Rows[0]["ChiaveContoProprieta"] = NumeroConto;

				this.Update(ds, "", "");

				return;
			}
		}


		public DataSet Retrieve_Parameters(string TipoParametro)
		{
			switch (TipoParametro)
			{
			case "RagioneSociale":
				using (OleDbDataAdapter da = new OleDbDataAdapter("select RagioneSociale, RAWTOHEX(IdSocieta) as IdSocieta from us.Societa", m_Transaction.Connection))
				{
					da.SelectCommand.Transaction = m_Transaction;

					DataSet ds = new DataSet();
					DataTable dt = ds.Tables.Add("Societa_RagioneSociale");
					dt.Columns.Add("RagioneSociale", typeof(string));
					dt.Columns.Add("IdSocieta", typeof(string));
					da.Fill(ds, "Societa_RagioneSociale");
					return ds;
				}

			case "RagioneSociale_CodiceConto":
				using (OleDbDataAdapter da = new OleDbDataAdapter("select PartitaIVA, RagioneSociale, CodiceConto, RAWTOHEX(IdSocieta) as IdSocieta from us.Societa", m_Transaction.Connection))
				{
					da.SelectCommand.Transaction = m_Transaction;

					DataSet ds = new DataSet();
					DataTable dt = ds.Tables.Add("Societa_RagioneSociale_CodiceConto");
					dt.Columns.Add("PartitaIVA", typeof(string));
					dt.Columns.Add("RagioneSociale", typeof(string));
					dt.Columns.Add("CodiceConto", typeof(string));
					dt.Columns.Add("IdSocieta", typeof(string));
					da.Fill(ds, "Societa_RagioneSociale_CodiceConto");
					return ds;
				}
			default:
				throw new Exception("TipoParametro non implementato");
			}
		}

		protected OleDbDataAdapter GetDataAdapter()
		{
			return GetDataAdapter(null, (OleDbParameter [])null);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere)
		{
			OleDbParameter [] pars = new OleDbParameter [1];
			pars[0] = parWhere;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter parWhere1, OleDbParameter parWhere2)
		{
			OleDbParameter [] pars = new OleDbParameter [2];
			pars[0] = parWhere1;
			pars[1] = parWhere2;
			return GetDataAdapter(sql, pars);
		}

		protected OleDbDataAdapter GetDataAdapter(string sql, OleDbParameter [] parsWhere)
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			// Query di SELECT per il Data Adapter
			if (true)
			{
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				// N.B. Lo spazio alla fine della stringa e' MOLTO IMPORTANTE non toglierlo!!!!!
				string sqlCmd = "SELECT RAWTOHEX(IdSocieta) AS IdSocieta, " +
								"RagioneSociale AS RagioneSociale, " +
								"Indirizzo AS Indirizzo,  " +
								"Citta AS Citta, " +
								"CAP AS CAP, " +
								"Nazione AS Nazione, " +
								"CodiceFiscale AS CodiceFiscale, " +
								"PartitaIVA AS PartitaIVA, " +
								"Telefono AS Telefono, " +
								"Fax AS Fax, " +
								"Email AS Email, " +
								"ABI AS ABI, " +
								"CAB AS CAB, " +
								"CC AS CC, " +
								"ReferenteAmministr AS ReferenteAmministr, " +
								"SedeAmministrativa AS SedeAmministrativa, " +
								"CodiceConto AS CodiceConto, " +
								"DataOraInserimento AS DataOraInserimento, " +
								"DataOraModifica AS DataOraModifica, " +
								"RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc, " +
								"ChiaveContoProprieta AS ChiaveContoProprieta, " +
								"Saldo AS Saldo " +
								"FROM US.Societa "; 

				if (sql != null && sql.Length > 0)
					sqlCmd += sql;

				cmd.CommandText = sqlCmd;

				if (parsWhere != null)
					foreach (OleDbParameter p in parsWhere)
						cmd.Parameters.Add(p);

				da.SelectCommand = cmd;
			}

			// update
			if (true)
			{
//				//OleDbCommand cmd = new OleDbCommand("CV.sp_Sessione_Update", m_Transaction.Connection, m_Transaction);
//				//cmd.CommandType = CommandType.StoredProcedure;
				OleDbCommand cmd = new OleDbCommand("", m_Transaction.Connection, m_Transaction);
				cmd.CommandText =	"UPDATE US.Societa SET " +
									"Indirizzo = ?, " +
									"Citta = ?, " +
									"CAP = ?, " +
									"Nazione = ?, " +
									"Telefono = ?, " +
									"Fax = ?, " +
									"Email = ?, " +
									"CodiceConto = ?, " +
									"ABI = ?, " +
									"CAB = ?, " +
									"CC = ?, " +
									"ReferenteAmministr = ?, " +
									"SedeAmministrativa = ?, " +
									"RagioneSociale = ?, " +
									"CodiceFiscale = ?, " +
									"PartitaIVA = ?, " +
									"ChiaveContoProprieta = ?, " +
									"Saldo = ? " +
									"WHERE IdSocieta = HEXTORAW(?)";
					
				cmd.Parameters.Add(new OleDbParameter("Indirizzo",						OleDbType.VarChar,	255, "Indirizzo"));
				cmd.Parameters.Add(new OleDbParameter("Citta",							OleDbType.VarChar,	255, "Citta"));
				cmd.Parameters.Add(new OleDbParameter("CAP",							OleDbType.VarChar,	255, "CAP"));
				cmd.Parameters.Add(new OleDbParameter("Nazione",						OleDbType.VarChar,  255, "Nazione"));
				cmd.Parameters.Add(new OleDbParameter("Telefono",						OleDbType.VarChar,  255, "Telefono"));
				cmd.Parameters.Add(new OleDbParameter("Fax",							OleDbType.VarChar,  255, "Fax"));
				cmd.Parameters.Add(new OleDbParameter("Email",							OleDbType.VarChar,  255, "Email"));
				cmd.Parameters.Add(new OleDbParameter("CodiceConto",					OleDbType.VarChar,  255, "CodiceConto"));
				cmd.Parameters.Add(new OleDbParameter("ABI",							OleDbType.VarChar,  255, "ABI"));
				cmd.Parameters.Add(new OleDbParameter("CAB",							OleDbType.VarChar,  255, "CAB"));
				cmd.Parameters.Add(new OleDbParameter("CC",								OleDbType.VarChar,  255, "CC"));
				cmd.Parameters.Add(new OleDbParameter("ReferenteAmministr",				OleDbType.VarChar,  100, "ReferenteAmministr"));
				cmd.Parameters.Add(new OleDbParameter("SedeAmministrativa",				OleDbType.VarChar,  100, "SedeAmministrativa"));
				cmd.Parameters.Add(new OleDbParameter("RagioneSociale",					OleDbType.VarChar,  255, "RagioneSociale"));
				cmd.Parameters.Add(new OleDbParameter("CodiceFiscale",					OleDbType.VarChar,	16,	 "CodiceFiscale"));
				cmd.Parameters.Add(new OleDbParameter("PartitaIVA",						OleDbType.VarChar,	11,	 "PartitaIVA"));
				cmd.Parameters.Add(new OleDbParameter("ChiaveContoProprieta",			OleDbType.VarChar,  255, "ChiaveContoProprieta"));
				cmd.Parameters.Add(new OleDbParameter("Saldo",							OleDbType.Decimal,	0,	 "Saldo"));		
				cmd.Parameters.Add(new OleDbParameter("IdSocieta",		                OleDbType.VarChar,   32, "IdSocieta"));

				da.UpdateCommand = cmd;
			}
			// TODO: (Flavio) Query di INSERT, UPDATE, DELETE per la classe AdminSocieta
			da.MissingSchemaAction = MissingSchemaAction.Error;
			return da;
		}

		public string Valida(string IdRichiestaRegSoc, string nominativo)
		{
			DLAdminRichieste dlRichieste = new DLAdminRichieste(m_Transaction);
			// Recupero il record relativo alla Richiesta di registrazione Societa' 
			// che voglio validare...
			DataSet ds = dlRichieste.Search(IdRichiestaRegSoc);
			if (ds == null)
				return null;

			DataTable dtRichiesteSoc = ds.Tables[0];
			if (dtRichiesteSoc.Rows.Count == 0)
			{
				return null;
			}

			string newGuid = Guid.NewGuid().ToString("N").ToUpper();
			// Effettuo la registrazione della Societa'
			string sqlInsert =	"INSERT INTO US.Societa " +
				"(IdSocieta, " +
				"RagioneSociale, " +
				"Indirizzo, " +
				"Citta, " +
				"CAP, " +
				"Nazione, " +
				"CodiceFiscale, " +
				"PartitaIVA, " +
				"Telefono, " +
				"Fax, " +
				"Email, " +
				"ABI, " +
				"CAB, " +
				"CC, " +
				"ReferenteAmministr, " +
				"SedeAmministrativa, " +
				"CodiceConto, " +
				"IdRichiestaRegSoc) " +
				"VALUES " +
				"(HEXTORAW(?), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, HEXTORAW(?))";
										
			OleDbCommand cmd = new OleDbCommand(sqlInsert, m_Transaction.Connection, m_Transaction);
			cmd.Parameters.Add("IdSocieta",			OleDbType.VarChar).Value = newGuid;
			cmd.Parameters.Add("RagioneSociale",	OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["RagioneSociale"].ToString();
			cmd.Parameters.Add("Indirizzo",			OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["Indirizzo"].ToString();
			cmd.Parameters.Add("Citta",				OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["Citta"].ToString();
			cmd.Parameters.Add("CAP",				OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["CAP"].ToString();
			cmd.Parameters.Add("Nazione",			OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["Nazione"].ToString();
			cmd.Parameters.Add("CodiceFiscale",		OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["CodiceFiscale"].ToString();
			cmd.Parameters.Add("PartitaIVA",		OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["PartitaIVA"].ToString();
			cmd.Parameters.Add("Telefono",			OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["Telefono"].ToString();
			cmd.Parameters.Add("Fax",				OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["Fax"].ToString();
			cmd.Parameters.Add("Email",				OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["Email"].ToString();
			cmd.Parameters.Add("ABI",				OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["ABI"].ToString();
			cmd.Parameters.Add("CAB",				OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["CAB"].ToString();
			cmd.Parameters.Add("CC",				OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["CC"].ToString();
			cmd.Parameters.Add("ReferenteAmministr",OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["ReferenteAmministr"].ToString();
			cmd.Parameters.Add("SedeAmministrativa",OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["SedeAmministrativa"].ToString();
			cmd.Parameters.Add("CodiceConto",		OleDbType.VarChar).Value = dtRichiesteSoc.Rows[0]["CodiceConto"].ToString();
			cmd.Parameters.Add("IdRichiestaRegSoc",	OleDbType.VarChar).Value = IdRichiestaRegSoc ;
			cmd.ExecuteNonQuery();

			// Riporto la modifica nello storico se nominativo != ""
			if (nominativo != "")
			{
				AggiungiInStorico(newGuid, nominativo);
			}
	
			// Aggiorno lo stato della Richiesta di registrazione
			string sqlUpdate =	"UPDATE US.RichiesteRegSoc " +
				"SET StatoRichiesta = 'Valida' " +
				"WHERE IdRichiestaRegSoc = HEXTORAW(?)";

			OleDbCommand cmdUpdate = new OleDbCommand(sqlUpdate, m_Transaction.Connection, m_Transaction);
			cmdUpdate.Parameters.Add("IdRichiestaRegSoc",	OleDbType.VarChar).Value = IdRichiestaRegSoc;
			cmdUpdate.ExecuteNonQuery();

			return newGuid;			
		}

		public void Update(DataSet ds, string IdSocieta, string nominativo)
		{
			OleDbDataAdapter da = GetDataAdapter();
			da.Update(ds, "Societa");

			if (nominativo != "")
			{
				// Riporto la modifica nello storico
				AggiungiInStorico(IdSocieta, nominativo);
				AggiornaRicRegSoc(IdSocieta, nominativo);
			}
		}

		public void AggiornaRicRegSoc(string IdSocieta, string nominativo)
		{
			// Recupero il record relativo all IdSocieta
			DataSet ds = GetListaByIdSocieta(IdSocieta);
			if (ds == null)
			{
				throw new Exception("Errore nella 'Get' della societa da tracciare sullo storico non trovata.");
			}

			if (ds.Tables[0].Rows.Count == 0)
			{
				throw new Exception("Societa da tracciare sullo storico non trovata.");
			}

			string sqlInsert =	"UPDATE US.RichiesteRegSoc SET " +
				"RagioneSociale = ?, " +
				"Indirizzo = ?, " +
				"Citta = ?, " +
				"CAP = ?, " +
				"Nazione = ?, " +
				"CodiceFiscale = ?, " +
				"PartitaIVA = ?, " +
				"Telefono = ?, " +
				"Fax = ?, " +
				"Email = ?, " +
				"ABI = ?, " +
				"CAB = ?, " +
				"CC = ?, " +
				"ReferenteAmministr = ?, " +
				"SedeAmministrativa = ?, " +
				"CodiceConto = ? " +
				"WHERE IdRichiestaRegSoc = HEXTORAW(?)";
										
			OleDbCommand cmd = new OleDbCommand(sqlInsert, m_Transaction.Connection, m_Transaction);
			cmd.Parameters.Add("RagioneSociale",	OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["RagioneSociale"].ToString();
			cmd.Parameters.Add("Indirizzo",			OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Indirizzo"].ToString();
			cmd.Parameters.Add("Citta",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Citta"].ToString();
			cmd.Parameters.Add("CAP",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CAP"].ToString();
			cmd.Parameters.Add("Nazione",			OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Nazione"].ToString();
			cmd.Parameters.Add("CodiceFiscale",		OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CodiceFiscale"].ToString();
			cmd.Parameters.Add("PartitaIVA",		OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["PartitaIVA"].ToString();
			cmd.Parameters.Add("Telefono",			OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Telefono"].ToString();
			cmd.Parameters.Add("Fax",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Fax"].ToString();
			cmd.Parameters.Add("Email",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Email"].ToString();
			cmd.Parameters.Add("ABI",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["ABI"].ToString();
			cmd.Parameters.Add("CAB",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CAB"].ToString();
			cmd.Parameters.Add("CC",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CC"].ToString();
			cmd.Parameters.Add("ReferenteAmministr",OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["ReferenteAmministr"].ToString();
			cmd.Parameters.Add("SedeAmministrativa",OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["SedeAmministrativa"].ToString();
			cmd.Parameters.Add("CodiceConto",		OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CodiceConto"].ToString();
			cmd.Parameters.Add("IdRichiestaRegSoc",	OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["IdRichiestaRegSoc"].ToString() ;

			cmd.ExecuteNonQuery();
		}

		public DataSet IdSocietaStorico()
		{
			using (OleDbDataAdapter da = new OleDbDataAdapter("select RAWTOHEX(IdSocieta) as IdSocieta from us.StoricoSocieta", m_Transaction.Connection))
			{
				da.SelectCommand.Transaction = m_Transaction;

				DataSet ds = new DataSet();
				DataTable dt = ds.Tables.Add("Societa");
				dt.Columns.Add("IdSocieta", typeof(string));
				da.Fill(ds, "Societa");
				return ds;
			}
		}

		public DataSet GetLstStorico()
		{
			string sqlSelect = @"SELECT RAWTOHEX(IdSocieta) as IdSocieta,
										TSModifica,
										RagioneSociale,
										Indirizzo,
										Citta,
										CAP,
										Nazione,
										CodiceFiscale,
										PartitaIVA,
										Telefono,
										Fax,
										Email,
										ABI,
										CAB,
										CC,
										ReferenteAmministr,
										SedeAmministrativa, 
										CodiceConto, 
										DataOraInserimento, 
										DataOraModifica, 
										RAWTOHEX(IdRichiestaRegSoc) AS IdRichiestaRegSoc, 
										ChiaveContoProprieta,
										AutoreModifica 
										FROM US.StoricoSocieta 
										ORDER BY TSModifica DESC
			" ;

			using (OleDbDataAdapter da = new OleDbDataAdapter(sqlSelect, m_Transaction.Connection))
			{
				da.SelectCommand.Transaction = m_Transaction;

				DataSet ds = new DataSet();
				DataTable dt = ds.Tables.Add("Societa");
				dt.Columns.Add("IdSocieta", typeof(string));
				dt.Columns.Add("TSModifica", typeof(DateTime));
				dt.Columns.Add("RagioneSociale", typeof(string));
				dt.Columns.Add("Indirizzo", typeof(string));
				dt.Columns.Add("Citta", typeof(string));
				dt.Columns.Add("CAP", typeof(string));
				dt.Columns.Add("Nazione", typeof(string));
				dt.Columns.Add("CodiceFiscale", typeof(string));
				dt.Columns.Add("PartitaIVA", typeof(string));
				dt.Columns.Add("Telefono", typeof(string));
				dt.Columns.Add("Fax", typeof(string));
				dt.Columns.Add("Email", typeof(string));
				dt.Columns.Add("ABI", typeof(string));
				dt.Columns.Add("CAB", typeof(string));
				dt.Columns.Add("CC", typeof(string));
				dt.Columns.Add("ReferenteAmministr", typeof(string));
				dt.Columns.Add("SedeAmministrativa", typeof(string));
				dt.Columns.Add("CodiceConto", typeof(string));
				dt.Columns.Add("DataOraInserimento", typeof(DateTime));
				dt.Columns.Add("DataOraModifica", typeof(DateTime));
				dt.Columns.Add("IdRichiestaRegSoc", typeof(string));
				dt.Columns.Add("ChiaveContoProprieta", typeof(string));
				dt.Columns.Add("AutoreModifica", typeof(string));
				da.Fill(ds, "Societa");
				return ds;
			}
		}

		public DataSet IdUtenteStorico()
		{
			using (OleDbDataAdapter da = new OleDbDataAdapter("select RAWTOHEX(IdUtente) as IdUtente from us.StoricoUtenti", m_Transaction.Connection))
			{
				da.SelectCommand.Transaction = m_Transaction;

				DataSet ds = new DataSet();
				DataTable dt = ds.Tables.Add("Utenti");
				dt.Columns.Add("IdUtenti", typeof(string));
				da.Fill(ds, "Utenti");
				return ds;
			}
		}

		public DataSet IdUtentiLista()
		{
			using (OleDbDataAdapter da = new OleDbDataAdapter("select RAWTOHEX(IdUtente) as IdUtente from us.Utenti", m_Transaction.Connection))
			{
				da.SelectCommand.Transaction = m_Transaction;

				DataSet ds = new DataSet();
				DataTable dt = ds.Tables.Add("Utenti");
				dt.Columns.Add("IdUtenti", typeof(string));
				da.Fill(ds, "Utenti");
				return ds;
			}
		}

		public void InizializzaStorico()
		{
			DataSet dsStorico = IdSocietaStorico() ;
			if ((dsStorico == null) || (dsStorico.Tables[0].Rows.Count == 0))
			{
				// Se lo storico e' vuoto lo inizializzo
				DataSet dsSocieta = GetListaByIdSocieta("");
				foreach (DataRow r in dsSocieta.Tables[0].Rows)
				{
					AggiungiInStorico((string)r["IdSocieta"], "");
				}
			}

			DataSet ds = IdUtenteStorico() ;
			if ((ds == null) || (ds.Tables[0].Rows.Count == 0))
			{
				// Se lo storico e' vuoto lo inizializzo
				DataSet dsUtenti = IdUtentiLista();
				foreach (DataRow r in dsUtenti.Tables[0].Rows)
				{
					DLAdminUtenti dlUtenti = new DLAdminUtenti(m_Transaction);
					dlUtenti.AggiungiInStorico((string)r["IdUtente"], "");
				}
			}
		}

		public void AggiungiInStorico(string IdSocieta, string nominativo)
		{
			// Recupero il record relativo all IdSocieta
			DataSet ds = GetListaByIdSocieta(IdSocieta);
			if (ds == null)
			{
				throw new Exception("Errore nella 'Get' della societa da tracciare sullo storico.");
			}

			if (ds.Tables[0].Rows.Count == 0)
			{
				throw new Exception("Societa da tracciare sullo storico non trovata.");
			}

			string sqlInsert =	"INSERT INTO US.StoricoSocieta " +
				"(IdSocieta, " +
				"RagioneSociale, " +
				"Indirizzo, " +
				"Citta, " +
				"CAP, " +
				"Nazione, " +
				"CodiceFiscale, " +
				"PartitaIVA, " +
				"Telefono, " +
				"Fax, " +
				"Email, " +
				"ABI, " +
				"CAB, " +
				"CC, " +
				"ReferenteAmministr, " +
				"SedeAmministrativa, " +
				"CodiceConto, " +
				"DataOraInserimento, " +
				"DataOraModifica, " +
				"ChiaveContoProprieta, " +
				"AutoreModifica, " +
				"IdRichiestaRegSoc) " +
				"VALUES " +
				"(HEXTORAW(?), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, HEXTORAW(?))";
										
			OleDbCommand cmd = new OleDbCommand(sqlInsert, m_Transaction.Connection, m_Transaction);
			cmd.Parameters.Add("IdSocieta",			OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["IdSocieta"].ToString() ;
			cmd.Parameters.Add("RagioneSociale",	OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["RagioneSociale"].ToString();
			cmd.Parameters.Add("Indirizzo",			OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Indirizzo"].ToString();
			cmd.Parameters.Add("Citta",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Citta"].ToString();
			cmd.Parameters.Add("CAP",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CAP"].ToString();
			cmd.Parameters.Add("Nazione",			OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Nazione"].ToString();
			cmd.Parameters.Add("CodiceFiscale",		OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CodiceFiscale"].ToString();
			cmd.Parameters.Add("PartitaIVA",		OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["PartitaIVA"].ToString();
			cmd.Parameters.Add("Telefono",			OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Telefono"].ToString();
			cmd.Parameters.Add("Fax",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Fax"].ToString();
			cmd.Parameters.Add("Email",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["Email"].ToString();
			cmd.Parameters.Add("ABI",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["ABI"].ToString();
			cmd.Parameters.Add("CAB",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CAB"].ToString();
			cmd.Parameters.Add("CC",				OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CC"].ToString();
			cmd.Parameters.Add("ReferenteAmministr",OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["ReferenteAmministr"].ToString();
			cmd.Parameters.Add("SedeAmministrativa",OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["SedeAmministrativa"].ToString();
			cmd.Parameters.Add("CodiceConto",		OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["CodiceConto"].ToString();
			cmd.Parameters.Add("DataOraInserimento",OleDbType.DBTimeStamp).Value = (DateTime)ds.Tables[0].Rows[0]["DataOraInserimento"];
			cmd.Parameters.Add("DataOraModifica",	OleDbType.DBTimeStamp).Value = (DateTime)ds.Tables[0].Rows[0]["DataOraModifica"];
			cmd.Parameters.Add("ChiaveContoProprieta",OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["ChiaveContoProprieta"].ToString();
			cmd.Parameters.Add("AutoreModifica",	OleDbType.VarChar).Value = nominativo ;
			cmd.Parameters.Add("IdRichiestaRegSoc",	OleDbType.VarChar).Value = ds.Tables[0].Rows[0]["IdRichiestaRegSoc"].ToString() ;
			cmd.ExecuteNonQuery();
		}

		public static DataSet DataSet_Societa()
		{
			DataSet ds = new DataSet();

			DataTable dt = ds.Tables.Add("Societa");

			DataColumn c;
			c = dt.Columns.Add("IdSocieta", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("RagioneSociale", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 255;
			c.Unique = false;

			c = dt.Columns.Add("Indirizzo", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Citta", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("CAP", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Nazione", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("CodiceFiscale", typeof(string));
			c.MaxLength = 16;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("PartitaIVA", typeof(string));
			c.MaxLength = 11;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Telefono", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("FAX", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("Email", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("ABI", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("CAB", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("CC", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;

			c = dt.Columns.Add("ReferenteAmministr", typeof(string));
			c.MaxLength = 100;
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("SedeAmministrativa", typeof(string));
			c.MaxLength = 100;
			c.AllowDBNull = true;
			c.Unique = false;

			c = dt.Columns.Add("CodiceConto", typeof(string));
			c.MaxLength = 255;
			c.AllowDBNull = false;
			c.Unique = false;
			
			c = dt.Columns.Add("DataOraInserimento", typeof(DateTime));
			c.AllowDBNull = false;
//			c.DefaultValue = new DateTime(1900,1,1);

			c = dt.Columns.Add("DataOraModifica", typeof(DateTime));
			c.AllowDBNull = false;
//			c.DefaultValue = new DateTime(1900,1,1);
	
			c = dt.Columns.Add("IdRichiestaRegSoc", typeof(string));
			c.AllowDBNull = false;
			c.MaxLength = 32;
			c.Unique = false;

			c = dt.Columns.Add("Saldo", typeof(Decimal));
			c.AllowDBNull = true;
			c.Unique = false;
			
			c = dt.Columns.Add("ChiaveContoProprieta", typeof(string));
			c.AllowDBNull = true;
			c.MaxLength = 255;
			c.Unique = false;

			dt.PrimaryKey = new DataColumn[] {	dt.Columns["IdSocieta"]};
			return ds;

		}
	}
}
