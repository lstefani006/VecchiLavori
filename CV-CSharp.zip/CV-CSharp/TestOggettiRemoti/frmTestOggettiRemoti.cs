using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CV;
using CV.Op;
using CV.Admin;
using System.Runtime.Remoting;

namespace TestOggettiRemoti
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Button btnCallMethod;
		private System.Windows.Forms.Button btnCallABISocieta;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button btnGetBankAccount;
		private System.Windows.Forms.Button btnCallCertificates;
		private System.Windows.Forms.DataGrid dgResult;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button btnBookData;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.button1 = new System.Windows.Forms.Button();
			this.btnCallABISocieta = new System.Windows.Forms.Button();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.button2 = new System.Windows.Forms.Button();
			this.dgResult = new System.Windows.Forms.DataGrid();
			this.btnCallCertificates = new System.Windows.Forms.Button();
			this.btnGetBankAccount = new System.Windows.Forms.Button();
			this.btnCallMethod = new System.Windows.Forms.Button();
			this.btnBookData = new System.Windows.Forms.Button();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgResult)).BeginInit();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.tabPage1,
																					  this.tabPage2});
			this.tabControl1.Location = new System.Drawing.Point(8, 8);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(672, 336);
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.button1,
																				   this.btnCallABISocieta});
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(576, 310);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Admin";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(144, 16);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(120, 32);
			this.button1.TabIndex = 1;
			this.button1.Text = "Call Web Service";
			this.button1.Click += new System.EventHandler(this.button1_Click_1);
			// 
			// btnCallABISocieta
			// 
			this.btnCallABISocieta.Location = new System.Drawing.Point(8, 16);
			this.btnCallABISocieta.Name = "btnCallABISocieta";
			this.btnCallABISocieta.Size = new System.Drawing.Size(128, 32);
			this.btnCallABISocieta.TabIndex = 0;
			this.btnCallABISocieta.Text = "Call GetABISocieta";
			this.btnCallABISocieta.Click += new System.EventHandler(this.btnCallABISocieta_Click);
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.btnBookData,
																				   this.button2,
																				   this.dgResult,
																				   this.btnCallCertificates,
																				   this.btnGetBankAccount,
																				   this.btnCallMethod});
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(664, 310);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Op";
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(376, 16);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(112, 32);
			this.button2.TabIndex = 4;
			this.button2.Text = "Is PIN Valid";
			this.button2.Click += new System.EventHandler(this.button2_Click_1);
			// 
			// dgResult
			// 
			this.dgResult.DataMember = "";
			this.dgResult.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgResult.Location = new System.Drawing.Point(8, 64);
			this.dgResult.Name = "dgResult";
			this.dgResult.Size = new System.Drawing.Size(560, 240);
			this.dgResult.TabIndex = 3;
			// 
			// btnCallCertificates
			// 
			this.btnCallCertificates.Location = new System.Drawing.Point(256, 16);
			this.btnCallCertificates.Name = "btnCallCertificates";
			this.btnCallCertificates.Size = new System.Drawing.Size(112, 32);
			this.btnCallCertificates.TabIndex = 2;
			this.btnCallCertificates.Text = "Call GetCertificates";
			this.btnCallCertificates.Click += new System.EventHandler(this.btnCallCertificates_Click);
			// 
			// btnGetBankAccount
			// 
			this.btnGetBankAccount.Location = new System.Drawing.Point(144, 16);
			this.btnGetBankAccount.Name = "btnGetBankAccount";
			this.btnGetBankAccount.Size = new System.Drawing.Size(104, 32);
			this.btnGetBankAccount.TabIndex = 1;
			this.btnGetBankAccount.Text = "Call GetBankAccount";
			this.btnGetBankAccount.Click += new System.EventHandler(this.button2_Click);
			// 
			// btnCallMethod
			// 
			this.btnCallMethod.Location = new System.Drawing.Point(8, 16);
			this.btnCallMethod.Name = "btnCallMethod";
			this.btnCallMethod.Size = new System.Drawing.Size(128, 32);
			this.btnCallMethod.TabIndex = 0;
			this.btnCallMethod.Text = "Call GetInfo Sessione";
			this.btnCallMethod.Click += new System.EventHandler(this.button1_Click);
			// 
			// btnBookData
			// 
			this.btnBookData.Location = new System.Drawing.Point(496, 16);
			this.btnBookData.Name = "btnBookData";
			this.btnBookData.Size = new System.Drawing.Size(128, 32);
			this.btnBookData.TabIndex = 5;
			this.btnBookData.Text = "Call GetBookData";
			this.btnBookData.Click += new System.EventHandler(this.btnBookData_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(688, 349);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tabControl1});
			this.Name = "Form1";
			this.Text = "Test Oggetti Remoti";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgResult)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			try
			{
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			RemotingConfiguration.Configure(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
		}

		private void btnCallABISocieta_Click(object sender, System.EventArgs e)
		{
			IBLAdminSocieta societa;
			try
			{
				societa = (IBLAdminSocieta)RemotingHelper.GetRemoteObject(typeof(IBLAdminSocieta));
//				MessageBox.Show(societa.GetABISocieta("Prova"));
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void button1_Click_1(object sender, System.EventArgs e)
		{
			myWebService.MainMenu webService;
			webService = new myWebService.MainMenu();
 
			MessageBox.Show(webService.GetMainMenu());
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			IBLOPSocieta societa;
			try
			{
				societa = (IBLOPSocieta)RemotingHelper.GetRemoteObject(typeof(IBLOPSocieta));
				BankAccount ba = societa.GetBankAccount("JVMX7ZHHC8GC4QQC", "A2AD016CB3F943A3B8D26FBB0992F563");
				MessageBox.Show(ba.Importo.ToString());
				string ragSociale = societa.GetRagioneSociale("B551850E187440E18B68717D51477F32");
				MessageBox.Show(ragSociale);
				
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnCallCertificates_Click(object sender, System.EventArgs e)
		{
			//IBLOPSocieta societa;
			//IBLOPSessione sessione;
			IBLOPOffertaVendita oVendita;
			//IBLOPTransazioni	oTran;
			try
			{
//				societa = (IBLOPSocieta)RemotingHelper.GetRemoteObject(typeof(IBLOPSocieta));
//				DataSet ds = societa.GetCertificates("JVMX7ZHHC8GC4QQC", "A2AD016CB3F943A3B8D26FBB0992F563");
				
//				sessione = (IBLOPSessione)RemotingHelper.GetRemoteObject(typeof(IBLOPSessione));
//				DataSet ds = sessione.GetCurrentWebSession();

				oVendita = (IBLOPOffertaVendita)RemotingHelper.GetRemoteObject(typeof(IBLOPOffertaVendita));
				oVendita.Modifica("ED9E072EE1E047CBB2D9977E8C9D54CA", 58.88M, 2M, 2M, @"MIIQNQYJKoZIhvcNAQcCoIIQJjCCECICAQExDjAMBggqhkiG9w0CBQUAMIINcQYJKoZIhvcNAQcBoIINYgSCDV4wgg1aBgkqhkiG9w0BBwKggg1LMIINRwIBATEOMAwGCCqGSIb3DQIFBQAwgggsBgkqhkiG9w0BBwGggggdBIIIGQ0KPERJViBpZD1kaXZNZXNzYWdlIG5hbWU9ImRpdk1lc3NhZ2UiPjxUQUJMRSBpZD1UYWJDb25mZXJtYSBzdHlsZT0iV0lEVEg6IDc1JSIgY2VsbFNwYWNpbmc9MSBjZWxsUGFkZGluZz0xIGJvcmRlcj0wPg0KPFRCT0RZPg0KPFRSIGNsYXNzPVRhYkRlc2NyaXppb25pQWx0Pg0KPFREIGNvbFNwYW49Mj5NV2gvQ2VydGlmaWNhdG88L1REPg0KPFREIGNvbFNwYW49Mz5FU1RSRU1JIERFTEwnT1JESU5FPC9URD48L1RSPg0KPFRSPg0KPFREIGNvbFNwYW49Mj4NCjxUQUJMRSBpZD1UYWJDZXJ0aWZpY2F0aTIgc3R5bGU9IkJPUkRFUi1UT1AtV0lEVEg6IDBweDsgQk9SREVSLUxFRlQtV0lEVEg6IDBweDsgQk9SREVSLUJPVFRPTS1XSURUSDogMHB4OyBXSURUSDogMTAwJTsgSEVJR0hUOiAxMDAlOyBCT1JERVItUklHSFQtV0lEVEg6IDBweCIgY2VsbFNwYWNpbmc9MSBjZWxsUGFkZGluZz0xIGJvcmRlcj0wPg0KPFRCT0RZPg0KPFRSIGNsYXNzPVRhYkRlc2NyaXppb25pQWx0Pg0KPFREPkFubm88L1REPg0KPFREPk1XaDwvVEQ+PC9UUj4NCjxUUiBjbGFzcz1UYWJEZXNjcml6aW9uaT4NCjxURD4yMDAyPC9URD4NCjxURD4xMDA8L1REPjwvVFI+DQo8VFIgY2xhc3M9VGFiRGVzY3Jpemlvbmk+DQo8VEQ+MjAwMzwvVEQ+DQo8VEQ+MTAwPC9URD48L1RSPg0KPFRSIGNsYXNzPVRhYkRlc2NyaXppb25pPg0KPFREPjIwMDQ8L1REPg0KPFREPjEwMDwvVEQ+PC9UUj48L1RCT0RZPjwvVEFCTEU+PC9URD4NCjxURCBjb2xTcGFuPTM+DQo8VEFCTEUgaWQ9VGFibGUyIHN0eWxlPSJCT1JERVItVE9QLVdJRFRIOiAwcHg7IEJPUkRFUi1MRUZULVdJRFRIOiAwcHg7IEJPUkRFUi1CT1RUT00tV0lEVEg6IDBweDsgV0lEVEg6IDEwMCU7IEhFSUdIVDogMTAwJTsgQk9SREVSLVJJR0hULVdJRFRIOiAwcHgiIGNlbGxTcGFjaW5nPTEgY2VsbFBhZGRpbmc9MSBib3JkZXI9MD4NCjxUQk9EWT4NCjxUUiBjbGFzcz1UYWJEZXNjcml6aW9uaUFsdD4NCjxURCBjbGFzcz1UYWJEZXNjcml6aW9uaT5UaXBvIE9wZXJhemlvbmU8L1REPg0KPFREIGNsYXNzPVRhYkRlc2NyaXppb25pIGNvbFNwYW49Mj48U1BBTiBpZD1DVGlwb09wZXJhemlvbmU+VmVuZGl0YTwvU1BBTj48L1REPjwvVFI+DQo8VFIgY2xhc3M9VGFiRGVzY3Jpemlvbmk+DQo8VEQ+QW5ubzwvVEQ+DQo8VEQ+PFNQQU4gaWQ9Q0Fubm9SaWZlcmltZW50bz4yMDAyPC9TUEFOPjwvVEQ+PC9UUj4NCjxUUiBjbGFzcz1UYWJEZXNjcml6aW9uaT4NCjxURD5RdWFudGl0YScgQ2VydGlmaWNhdGk8L1REPg0KPFREPjxTUEFOIGlkPUNRdHk+MjwvU1BBTj48L1REPjwvVFI+DQo8VFIgY2xhc3M9VGFiRGVzY3Jpemlvbmk+DQo8VEQ+UXVhbnRpdGEnI" + 
								  "EVzZWd1a" + 
								  "XRhPC9URD4NCjxURD48U1BBTiBpZD1DUXR5RXNlZ3VpdGE+MDwvU1BBTj48L1REPjwvVFI+DQo8VFIgY2xhc3M9VGFiRGVzY3Jpemlvbmk+DQo8VEQ+UXVhbnRpdGEnIFJlc2lkdWE8L1REPg0KPFREPjxTUEFOIGlkPUNRdHlSZXNpZHVhPjI8L1NQQU4+PC9URD48L1RSPg0KPFRSIGNsYXNzPVRhYkRlc2NyaXppb25pPg0KPFREPlByZXp6byBVbml0YXJpbzwvVEQ+DQo8VEQ+PFNQQU4gaWQ9Q1ByZXp6b1VuaXRhcmlvPkNvbiBsaW1pdGUgZGkgcHJlenpvIIAgNTgsODg8L1NQQU4+PC9URD48L1RSPg0KPFRSIGNsYXNzPVRhYkRlc2NyaXppb25pPg0KPFREPkNvbnRyb3ZhbG9yZTwvVEQ+DQo8VEQ+PFNQQU4gaWQ9Q29udHJvdmFsb3JlPoAgMTEuNzc2LDAwPC9TUEFOPjwvVEQ+PC9UUj4NCjxUUiBjbGFzcz1UYWJEZXNjcml6aW9uaT4NCjxURD48L1REPg0KPFREPg0KPFAgYWxpZ249Y2VudGVyPjxJTlBVVCBjbGFzcz1CdXR0b25Gb250IHR5cGU9c3VibWl0IHZhbHVlPUNvbmZlcm1hIG5hbWU9Y21kQ29uZnJtPiZuYnNwOyZuYnNwOyZuYnNwOzxJTlBVVCBsYW5ndWFnZT1qYXZhc2NyaXB0IGNsYXNzPUJ1dHRvbkZvbnQgb25jbGljaz0icmV0dXJuIGNtZEFubnVsbGFfb25jbGljaygpOyAiIHR5cGU9YnV0dG9uIHZhbHVlPUFubnVsbGEgbmFtZT1jbWRBbm51bGxhPiA8L1A+PC9URD48L1RSPjwvVEJPRFk+PC9UQUJMRT48L1REPjwvVFI+PC9UQk9EWT48L1RBQkxFPjwvRElWPqCCA/UwggPxMIIDWqADAgECAhBnu9zQzwJfI9xiqQ1EqfolMA0GCSqGSIb3DQEBBQUAMEoxHDAaBgNVBAoTE1RydXN0IEl0YWxpYSBTLnAuQS4xHTAbBgNVBAMTFFRJIEZpcm1hIERpZ2l0YWxlIENBMQswCQYDVQQGEwJJVDAeFw0wMzA0MDkwMDAwMDBaFw0wNDA0MDgyMzU5NTlaMIH1MTQwMgYDVQQDEytHaWFjaGVyby9GYWJyaXppby9HQ0hGUlo2OEEyN0Q5NjlLLzEwMDAyMDcwMTwwOgYDVQQNEzNDPUdpYWNoZXJvL049RmFicml6aW8vRD0yNy0wMS0xOTY4L1I9UHJvamVjdCBMZWFkZXIxKTAnBgkqhkiG9w0BCQEWGmZhYnJpemlvLmdpYWNoZXJvQGVsc2FnLml0MRwwGgYDVQQKFBNUcnVzdCBJdGFsaWEgUy5wLkEuMRgwFgYDVQQLFA9UcnVzdCBJdGFsaWEgRkQxDzANBgNVBAcTBkdlbm92YTELMAkGA1UEBhMCSVQwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAJn68fqHmojjJKAn6m+TB3ySC50elSLDTYLAI6mASXbUA1/59BoP0qeFPH/fIMQe9ovSHJv+fSrxEJocbx38Oh8z/GemCfT2Q9LIq+8zwThromKupv5Gu//9mt0RK3tJNSaf6keZMfVoy8ugkACatgHHfv6vzZMazH4brOZX1rrtAgMBAAGjggEqMIIBJjBRBgNVHSAESjBIMEYGBysGAQQBxTEwOzA5BggrBgEFBQcCARYtaHR0cHM6Ly9maXJtYWRpZ2l0YWxlLnRydXN0aXRhbGlhLml0L3JwYS5odG1sMFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9vbnNpdGVjcmwudHJ1c3RpdGFsaWEuaXQvVHJ1c3RJdGFsaWFTcEFUcnVzdEl0YWxpYUZEL0xhdGVzdENSTC5jcmwwDgYDVR0PAQH/BAQDAgZAMB8GA1UdIwQYMBaAFBbKPJyrBufzifKouaM" + 
								  "5BwvylWQHMB0GA1UdDgQWBBRu2SMElYroXpE2hHBMqHf8ySmGNTAlBgNVHREEHjAcgRpmYWJyaXppby5naWFjaGVyb0BlbHNhZy5pdDANBgkqhkiG9w0BAQUFAAOBgQAw/l6NBmByARZAS3c5No6mLWXpsf2zUzEPXeDRsjYNRoYNig9Qe66yPBfJOwgetAcmHMqOToO/dB/9c+F75eJjM+U1agSxfQi2V12xeSzsBuOr+gSJnLSvBZqe8MyyzGQe0KpxNrhBGD/5CIO9AR490TYXX0msTGc8JJ+KIYJMuDGCAQcwggEDAgEBMF4wSjEcMBoGA1UEChMTVHJ1c3QgSXRhbGlhIFMucC5BLjEdMBsGA1UEAxMUVEkgRmlybWEgRGlnaXRhbGUgQ0ExCzAJBgNVBAYTAklUAhBnu9zQzwJfI9xiqQ1EqfolMAwGCCqGSIb3DQIFBQAwDQYJKoZIhvcNAQEBBQAEgYAZZIUg2xNjfFlQUSB1+QhupemrOTWAfH8y9phL91USWamjUhM47Vu2snOqxa2fha5DT1S/huqXlI0GnWWFV0yj8ifW4OIj4d/2sCdLeYvJ2LBskQWE8GjTcZT9irPOeJQPzGfk5wsqI4UCQvfaZvAQKt+5h/Z4THM8/rIobjJtpKCCAXAwggFsMIIBFqADAgECAgQAvGFCMA0GCSqGSIb3DQEBBAUAMBYxFDASBgNVBAMTC1Jvb3QgQWdlbmN5MB4XDTAzMDUxNTEwMjU1OVoXDTM5MTIzMTIzNTk1OVowFzEVMBMGA1UEAxMMR01FIFRFU1QgTkVUMFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAL/Fs66lsV+EeaxXzhJV4HGO5iEn0989oxZwLjPOmpyFEriBCvY8dng+IkJd7fs0bgUXf4eX53Xj3X6XbRhGaY0CAwEAAaNLMEkwRwYDVR0BBEAwPoAQEuQJLQYdHU8AjWEh3BZkY6EYMBYxFDASBgNVBAMTC1Jvb3QgQWdlbmN5ghAGN2wAqgBkihHPuNSqXDX0MA0GCSqGSIb3DQEBBAUAA0EAY9nTqG3vmNUZCkCDLZtcWaAQvW0A0V518ZugkTGA5FcfC1swhWPoEwfwnooCHNcCHBC2hHK3RflC5ukwNLWLgjGCASIwggEeAgEBMB4wFjEUMBIGA1UEAxMLUm9vdCBBZ2VuY3kCBAC8YUIwDAYIKoZIhvcNAgUFAKBZMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTAzMDUxNTExNDYzOVowHwYJKoZIhvcNAQkEMRIEELEuOv0B2xPAAil81xt4Mu8wDQYJKoZIhvcNAQEBBQAEgYBKkQKahOZ3RBmxEzEZYd+DzH26ZSSSkrw1U9oNCGe3a3JiNDSzZ+IQT8ADsJm6MIVlBz1zbvzPLrSDBdhvU4LZonBuQstkN6JNJfAIetBcNA2ZVpv+GWNKn/9lxCbMmidZLNyE1ep/XgZvGNsuMlGRar88041lz40HvHwlqVUUdQ"); 
//				oTran = (IBLOPTransazioni)RemotingHelper.GetRemoteObject(typeof(IBLOPTransazioni));
//				DataSet ds = oTran.GetTransazioniVendita("30099DF3044941B0BB7C1766BA0A9389", "17C07A92814E41D197AB9214462BF3CC");
//				dgResult.DataSource = ds;

			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void button2_Click_1(object sender, System.EventArgs e)
		{
			IBLOPUtente utente;

			try
			{
				IBLOPMercato mercato;

				mercato = (IBLOPMercato)RemotingHelper.GetRemoteObject(typeof(IBLOPMercato));
				DataSet ds = mercato.GetBookAcquisto("A2AD016CB3F943A3B8D26FBB0992F563","2003");
				dgResult.DataSource = ds;
				utente = (IBLOPUtente)RemotingHelper.GetRemoteObject(typeof(IBLOPUtente));

				bool flag = utente.IsPINValid("JVMX7ZHHC8GC4QQC");
				if (flag)
					MessageBox.Show("PIN JVMX7ZHHC8GC4QQC presente");
				else
					MessageBox.Show("PIN JVMX7ZHHC8GC4QQC assente");

				InfoUtente info = utente.GetIdUtente("JVMX7ZHHC8GC4QQC");
				string result = "IdUtente = " + info.IdUtente + "\n";
				MessageBox.Show(result);
			}
			catch(Exception exc)
			{
				MessageBox.Show(exc.Message);
			}
		}

		private void btnBookData_Click(object sender, System.EventArgs e)
		{
			IBLOPTransazioni oTransazione;
			IBLOPCommon	oCommon;
			try
			{
				oTransazione = (IBLOPTransazioni)RemotingHelper.GetRemoteObject(typeof(IBLOPTransazioni));
				BookData bd = oTransazione.GetBookData("A2AD016CB3F943A3B8D26FBB0992F563", "2003");
				MessageBox.Show(bd.PrezzoMAX.ToString());

				oCommon = (IBLOPCommon)RemotingHelper.GetRemoteObject(typeof(IBLOPCommon));
				MessageBox.Show(oCommon.GetDBSystemDate().ToString());
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}
}
