select
	S.IdSessione,
	S.DataOraApertura,
	rawToHex(B.IdSocieta),
	B.residuo
from
	cv.sessioni S,
	cv.budgets  B
where 
	S.IdSessione = B.IdSessione
	and S.dataOraApertura in
	(
		select
			max(SPrecedente.dataOraApertura)
		from
			cv.sessioni SPrecedente,
			cv.sessioni SAttuale
		where  
			SPrecedente.dataOraApertura < SAttuale.dataOraApertura
			and SAttuale.IdSessione = HexToRaw('C848358A20084943A4C2BF665BC833FC')
	);
