using System;
using System.IO;
using System.Runtime.Remoting;

namespace CV
{
	/// <summary>
	/// Class base per tutti le classi da remotizzare nel progetto.
	/// Attualmente non crea valore aggiunto ma potrebbe essere
	/// utile per aggiungere metodi dati comuni alle classe remote.
	/// </summary>
	public class CVRemotingBase : MarshalByRefObject 
	{
		public CVRemotingBase()
		{
		}


		/// <summary>
		/// ritorna il nome del file se il file esiste nella directory corrente, 
		/// o se il fileName ha gia` un path.
		/// Ritorna il file completo di path se esiste nella directory dell'appDomain chiamante,
		/// e in c:\
		/// Se non trova il file ritorna fileName senza modifica
		/// </summary>
		/// <param name="fileName"></param>
		/// <returns></returns>
		public static string GetFileNameCompletePath(string fileName)
		{
			try
			{
				if (File.Exists(fileName))
					return fileName;
			}
			catch (Exception)
			{
			}

			try
			{
				string s = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + fileName;
				if (File.Exists(s))
					return s;
			}
			catch (Exception)
			{
			}

			try
			{
				string s = @"c:\" + fileName;
				if (File.Exists(s))
					return s;
			}
			catch (Exception)
			{
			}

			return fileName;
		}
	}
}
