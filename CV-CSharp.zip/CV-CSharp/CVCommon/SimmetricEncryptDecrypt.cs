using System;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace CVCommon
{
	/// <summary>
	/// Summary description for SimmetricEncryptDecrypt.
	/// </summary>
	public class SimmetricEncryptDecrypt
	{
		/// <summary>
		/// Motore per cryptare/decryptare delle stringhe.
		/// Si usa un algoritmo simmetrico.
		/// </summary>
		/// <param name="sa">provider di cript</param>param>
		/// <param name="keyBitSize">numero di bit per la chiave</param>
		/// <param name="pwd">la password per criptare/decriptare</param>
		public SimmetricEncryptDecrypt(SymmetricAlgorithm sa, int keyBitSize, string pwd)
		{
			_sa = sa;

			// il CBC (Cipher Block Chaining) specifica come il testo da cryptare
			// viene trattato prima di criptarlo:
			// nel CBC ogni blocco di testo in chiaro viene messo in XOR
			// con il precedente blocco criptato prima di essere criptato a sua volta.
			// Il primo blocco di testo in chiaro da criptare ha bisogno di un array della stessa dimensione
			// del blocco da utilizzare per la stessa operazione di XOR (dato che non
			// esiste ancora un blocco gia' criptato): questo blocco e' chiamato IV (Initialization Vector)
			_sa.Mode = CipherMode.CBC;

			// La chiave, a seconda del tipo di algoritmo, deve avere una lunghezza predeterminato
			// dalle caratteristice dell'algoritmo
			// La chiave viene ottenuta partendo dalla password. La password puo'
			// essere in unicode (char > 256) ma il valore della chiave viene determinato solo
			// con il byte meno significativo del carattere
			// L'eventuale padding (se la pwd e' troppo corta) e' del tutto arbitrario

			// controllo il key size proposto
			bool bKeyAllowed = false;
			for (int i = 0; i < _sa.LegalKeySizes.Length; ++i)
			{
				int m = _sa.LegalKeySizes[i].MinSize;
				int M = _sa.LegalKeySizes[i].MaxSize;
				int s = _sa.LegalKeySizes[i].SkipSize;

				for (int b = m; b <= M; b += s)
					if (b == keyBitSize)
					{
						bKeyAllowed = true;
						break;
					}
				if (bKeyAllowed)
					break;
			}

			if (bKeyAllowed == false)
				throw new Exception("Invalid keyBitSize for this provider");

			_key = new byte [keyBitSize / 8];
			for (int ks = 0; ks < _key.Length; ++ks)
				if (ks < pwd.Length)
					_key[ks] = (byte)pwd[ks];  // in questo modo la pwd puo' essere anche unicode
				else
					_key[ks] = (byte)ks;

			// computo l'IV partendo dalla chiave (e dunque dalla password)
			// utilizzando un criterio del tutto arbitrario
			// Dato che l'IV dipende solo dalla password e' sufficiente 
			// per decriptare e per decriptare solo la password
			_IV = new byte [_sa.BlockSize / 8];
			for (int bs = 0; bs < _IV.Length; ++bs)
				if (bs < _key.Length)
					_IV[bs] = (byte)(_key[bs] ^ 0x3A);
				else
					_IV[bs] = (byte)(bs ^ 0x3B);
		}

		/// <summary>
		/// Motore per cryptare/decryptare delle stringhe.
		/// Si usa un algoritomo simmetrico specificato
		/// La chiave ha come dimensione il massimo consentito dal provider
		/// </summary>
		/// <param name="sa">provider da utilizzare</param>
		/// <param name="pwd">password</param>
		public SimmetricEncryptDecrypt(SymmetricAlgorithm sa, string pwd)
			: this(sa, sa.LegalKeySizes[0].MaxSize, pwd) // a insindacabile giudizio si prende il max
		{
		}

		/// <summary>
		/// Motore per cryptare/decryptare delle stringhe.
		/// Si usa l'algoritomo simmetrico RijndaelManaged
		/// La chiave ha come dimensione il massimo consentito dal provider
		/// </summary>
		/// <param name="pwd"></param>
		public SimmetricEncryptDecrypt(string pwd)
			: this(new RijndaelManaged(), pwd) // a insindacabile giudizio si usa RijndaelManaged
		{
		}

		/// <summary>
		/// Fa il cript di un array di byte ritornando l'array criptato
		/// </summary>
		/// <param name="dataToEncrypt">array da criptare</param>
		/// <returns>array criptato</returns>
		public byte [] Encrypt(byte [] dataToEncrypt)
		{
			ICryptoTransform enc = _sa.CreateEncryptor(_key, _IV);
			MemoryStream ms = new MemoryStream();
			CryptoStream encStream = new CryptoStream(ms, enc, CryptoStreamMode.Write);
			encStream.Write(dataToEncrypt, 0, dataToEncrypt.Length);
			encStream.FlushFinalBlock();
			encStream.Close();
			return ms.ToArray();
		}


		/// <summary>
		/// Decripta un array di bytes cryptati.
		/// Ritorna null in caso di errore (Es. pwd sbagliata)
		/// </summary>
		/// <param name="dataToDecrypt"></param>
		/// <returns>l'array in chiaro</returns>
		public byte [] Decrypt(byte [] dataToDecrypt)
		{
			try
			{
				MemoryStream ms = new MemoryStream();
				ICryptoTransform dec = _sa.CreateDecryptor(_key, _IV);
				CryptoStream decStream = new CryptoStream(ms, dec, CryptoStreamMode.Write);
				decStream.Write(dataToDecrypt, 0, dataToDecrypt.Length);
				decStream.FlushFinalBlock();
				decStream.Close();
				return ms.ToArray();
			}
			catch(CryptographicException ex)
			{
				Debug.WriteLine(ex.Message);
				return null;
			}
		}


		/// <summary>
		/// Fa l'encript della stringa e ritorna la stringa cryptata espressa in base 64.
		/// La stringa in ingresso puo' contenere qualunque carattere unicode
		/// </summary>
		/// <param name="strToEncrypt">stringa da criptare</param>
		/// <returns>stringa cryptata in base 64</returns>
		public string Encrypt(string strToEncrypt)
		{
			byte [] dataClear = Encoding.Unicode.GetBytes(strToEncrypt);
			byte [] dataCrypted = Encrypt(dataClear);
			return Convert.ToBase64String(dataCrypted);
		}


		/// <summary>
		/// Decripta una stringa espressa in base 64
		/// </summary>
		/// <param name="strToDecrypt">stringa criptata in base 64</param>
		/// <returns>la stringa in chiaro, null in caso di errore (es pwd errata)</returns>
		public string Decrypt(string strToDecrypt)
		{
			byte [] dataToDecrypt = Convert.FromBase64String(strToDecrypt);
			byte [] dataClear = Decrypt(dataToDecrypt);
			if (dataClear == null)
				return null;
			return Encoding.Unicode.GetString(dataClear);
		}

		private SymmetricAlgorithm _sa;
		private byte [] _key;
		private byte [] _IV;
	}
}
