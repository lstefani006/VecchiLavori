using System;
using System.Data;
using System.Diagnostics;

namespace CV
{
	/// <summary>
	/// Classe (statica) per fare il dump di un DataSet/DataTable/DataRow
	/// </summary>
	public class DiagnosticHelper
	{
		[Conditional("DEBUG")]
		private static void DataSetDump(DataRow dr, DataColumn dc, DataRowVersion vr)
		{
			if (dr.HasVersion(vr))
			{
				if (dr.IsNull(dc, vr))
					Debug.WriteLine(vr.ToString() + " value = <NULL>");
				else
					Debug.WriteLine(vr.ToString() + " value = " + dr[dc, vr].ToString());
			}
		}

		[Conditional("DEBUG")]
		public static void DataSetDump(string msg, DataRow dr)
		{
			if (msg != null)
				Debug.WriteLine(msg);
			Debug.WriteLine("RowState " + dr.RowState.ToString());
			Debug.Indent();
					
			foreach (DataColumn dc in dr.Table.Columns)
			{
				Debug.WriteLine("Colonna " + dc.ColumnName);
				Debug.Indent();

				DataSetDump(dr, dc, DataRowVersion.Current);
				DataSetDump(dr, dc, DataRowVersion.Original);
				DataSetDump(dr, dc, DataRowVersion.Proposed);
				DataSetDump(dr, dc, DataRowVersion.Default);

				Debug.Unindent();
			}

			if (dr.HasErrors)
			{
				Debug.WriteLine("Errore nella riga");
				Debug.Indent();

				if (dr.RowError != null)
					Debug.WriteLine("RowError = "  + dr.RowError);

				DataColumn [] dcerr = dr.GetColumnsInError();
				foreach (DataColumn dce in dcerr)
					Debug.WriteLine(dce.ColumnName + " " + dr.GetColumnError(dce));

				Debug.Unindent();
			}
			Debug.Unindent();
		}

		[Conditional("DEBUG")]
		public static void DataSetDump(string msg, DataTable dt)
		{
			if (msg != null)
				Debug.WriteLine(msg);
			Debug.WriteLine("DataTable " + dt.TableName);
			Debug.Indent();

			foreach (DataRow dr in dt.Rows)
				DataSetDump(null, dr);

			Debug.Unindent();
		}


		[Conditional("DEBUG")]
		public static void DataSetDump(string msg, DataSet ds)
		{
			if (msg != null)
				Debug.WriteLine(msg);

			Debug.WriteLine("DataSetDump " + ds.DataSetName);
			Debug.Indent();

			foreach (DataTable dt in ds.Tables)
				DataSetDump(null, dt);

			Debug.Unindent();
		}
	}
}