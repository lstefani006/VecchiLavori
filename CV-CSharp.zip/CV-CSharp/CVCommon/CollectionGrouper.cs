using System;
using System.Collections;

namespace CVCommon
{
	/// <summary>
	/// helper class per iterare in una collezione ordinata
	/// secondo il paradigma dei gruppi/rotture.
	/// </summary>
	public abstract class CollectionGrouper : IComparer
	{
		public CollectionGrouper(IEnumerable coll)
		{
			_en = coll.GetEnumerator();
		}
		public CollectionGrouper()
		{
			_en = null;
			// in costruttore della classe derivata deve valorizzare _coll
		}
		public CollectionGrouper(IEnumerator en)
		{
			_en = en;
		}

		/* Implementazioni minima - fare ^C ^V
			class MyCollectionGrouper : CollectionGrouper
			{
				public MyCollectionGrouper(IEnumerable coll)
					: base(coll)
				{
				}
		
				// variabili globali al loop.
			
				// variabili da utilizzare per gruppo.	
			
		
				public override int Compare(object a, object b)
				{
					// soliti confronti necessari per Compare
					if (a == null && b == null) return 0;
					if (a != null && b == null) return 1;
					if (a == null && b != null) return -1;
				}
		
				public override bool CheckBreak(object prev_item, object current_item)
				{
					return true;
				}
				public overide void OnStartLoop()
				{
				}
				public override void OnFirstItem(object item)
				{
				}
				public override void OnItem(object item)
				{
				}
				public override void OnLastItem(object item)
				{
				}
				public overide void OnEndLoop()
				{
				}
			}
			*/

		/// <summary>
		/// Funzioni per fare il sort della collezione per ottenere una
		/// collezione orginata secondo i criteri utili per l'accorpamento
		/// </summary>
		/// <param name="a"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		public abstract int Compare(object a, object b);

		/// <summary>
		/// Metodo per determinare se c'e' una rottura.
		/// Ritorna true se c'e' una rottura tra l'item precedente e l'item corrente
		/// </summary>
		/// <param name="prev_item">item precedente</param>
		/// <param name="current_item">item corrente</param>
		/// <returns>true se c'e la rottura</returns>
		public abstract bool CheckBreak(object prev_item, object current_item);

		/// <summary>
		/// prima di iniziare ad iterare <c>Loop</c> chiama <code>OnStartLoop</code>
		/// </summary>
		public virtual void OnStartLoop() {}

		/// <summary>
		/// Chiamata nel primo item di un gruppo.
		/// Chiamata prima di <c>OnItem</c> dello stesso item.
		/// </summary>
		/// <param name="item">item corrente</param>
		public abstract void OnFirstItem(object item);
		/// <summary>
		/// Chiamata per ogni item del gruppo
		/// (compresi il primo e l'ultimo item di un gruppo)
		/// </summary>
		/// <param name="item">item corrente</param>
		public abstract void OnItem(object item);
		/// <summary>
		/// Chiamata sull'ultimo item di un gruppo.
		/// Chiamata dopo <code>OnItem</code> dell'ultimo item.
		/// </summary>
		/// <param name="item">item corrente</param>
		public abstract void OnLastItem(object item);

		/// <summary>
		/// Quando in <code>Loop</code> non ci sono piu' elementi viene chiamato OnEndLoop
		/// </summary>
		public virtual void OnEndLoop() {}


		/// <summary>
		/// funzione che esegue il loop negli item e chiama
		/// <c>OnFirstItem</c>,<c>OnItem</c>,<c>OnLastItem</c>
		/// </summary>
		public void Loop()
		{
			ArrayList ar = new ArrayList();
			while (_en.MoveNext())
				ar.Add(_en.Current);
			ar.Sort(this);

			OnStartLoop();

			object prev_item = null;
			foreach (object current_item in ar)
			{
				if (prev_item != null && CheckBreak(prev_item, current_item))
				{
					OnLastItem(prev_item);
					OnFirstItem(current_item);
				}
				else if (prev_item == null)
				{
					OnFirstItem(current_item);
				}

				OnItem(current_item);

				prev_item = current_item;
			}

			if (prev_item != null)
				OnLastItem(prev_item);

			OnEndLoop();
		}

		protected IEnumerator _en;
		protected bool _doSort = false;
	}
}
