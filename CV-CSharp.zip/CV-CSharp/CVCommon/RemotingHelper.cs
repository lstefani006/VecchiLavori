using System;
using System.Collections;
using System.Runtime.Remoting;

namespace CV
{
	/// <summary>
	/// Classe che si occupa di mappare i tipi esportati dall'assembly CVBLOpInterface
	/// in tipi concreti da istanziare.
	/// In pratica i tipi concreti sono descritti nel file di configurazione di ogni cliente:
	/// Es:
	/// <wellknown 
	///     type="CV.Admin.IBLAdminSocieta, CVBLAdminInterface" 
	///     url="http://localhost:5678/CVWebServer/CVAdminSocietaURI.rem" />
	/// A fronte di un tipo "CV.Admin.IBLAdminSocieta" implementato nell'assembly CVBLAdminInterface
	/// e' necessario invocare l'url sopra.
	/// 
	/// Il vantaggio di quest'approccio e' che il codice del client non deve conoscere (compilare)
	/// le classi che implementano quell'interfaccia se non nel file di configurazione.
	/// Lo svantaggio che puo' esistere nel server solo una implementazione concreta dell'-
	/// interfaccia.
	/// </summary>
	public class RemotingHelper
	{
		/// <summary>
		/// Chiamare questo metodo per instanziare una classe remota che implementa
		/// l'interfaccia passata per parametro.
		/// </summary>
		/// <param name="type">L'interfaccia implementata dall'oggetto remoto</param>
		/// <returns>L'oggetto concreto che implementa quell'interfaccia nel server</returns>
		public static object GetRemoteObject(Type type)
		{
			WellKnownClientTypeEntry entry;
			if (_wellKnownTypes == null)   
				InitTypeCache();

			entry = (WellKnownClientTypeEntry)_wellKnownTypes[type];
			if (entry == null)
				throw new RemotingException("Type not found!");

			return Activator.GetObject(entry.ObjectType, entry.ObjectUrl);
		}
		#region Implementazione
		private static void InitTypeCache()
		{
			_wellKnownTypes = new Hashtable();
			foreach (WellKnownClientTypeEntry entry in RemotingConfiguration.GetRegisteredWellKnownClientTypes())
			{
				if (entry.ObjectType == null)
					throw new RemotingException("A configured type could not be found. Please check spelling");
				else
					_wellKnownTypes.Add(entry.ObjectType, entry);
			}
		}
		private static IDictionary _wellKnownTypes = null;
		#endregion
	}
}
