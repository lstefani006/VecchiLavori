using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;

namespace CVAdminHost
{
	/// <summary>
	/// Summary description for DownloadWait.
	/// </summary>
	public class DownloadWait : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCancella;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Timers.Timer timer;
		private bool _cancelled = false;
		private Thread _th = null;

		public DownloadWait(Thread th)
		{
			InitializeComponent();

			_th = th;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnCancella = new System.Windows.Forms.Button();
			this.timer = new System.Timers.Timer();
			((System.ComponentModel.ISupportInitialize)(this.timer)).BeginInit();
			this.SuspendLayout();
			// 
			// btnCancella
			// 
			this.btnCancella.Location = new System.Drawing.Point(64, 8);
			this.btnCancella.Name = "btnCancella";
			this.btnCancella.Size = new System.Drawing.Size(80, 23);
			this.btnCancella.TabIndex = 0;
			this.btnCancella.Text = "Cancella";
			this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
			// 
			// timer
			// 
			this.timer.Enabled = true;
			this.timer.Interval = 300;
			this.timer.SynchronizingObject = this;
			this.timer.Elapsed += new System.Timers.ElapsedEventHandler(this.timer_Elapsed);
			// 
			// DownloadWait
			// 
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(202, 37);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnCancella});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.MaximizeBox = false;
			this.Name = "DownloadWait";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Connessione al server in corso....";
			((System.ComponentModel.ISupportInitialize)(this.timer)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void btnCancella_Click(object sender, System.EventArgs e)
		{
			if (_th.IsAlive)
			{
				_th.Abort();
				_cancelled = true;
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
			else
			{
				_cancelled = false;
				this.DialogResult = DialogResult.OK;
				this.Close();
			}
		}

		private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			if (_th.IsAlive == false)
			{
				_cancelled = false;
				this.DialogResult = DialogResult.OK;
				this.Close();
			}
		}

		public bool Cancelled { get { return _cancelled; } }
	}
}
