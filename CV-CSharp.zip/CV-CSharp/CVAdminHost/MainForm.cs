using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Reflection;
using System.IO;
using System.Runtime.Remoting;
using System.Diagnostics;
using System.Threading;
using System.Net;
using System.Text;
using System.Configuration;

namespace CVAdminHost
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private Assembly _ass = null;
		private string CVAdminURL = ConfigurationSettings.AppSettings["CVAdminWebServerURL"];


		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			// CheckConfigFile();
			RemotingConfiguration.Configure(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);

			string Proxy_User   = System.Configuration.ConfigurationSettings.AppSettings["Proxy_User"];
			string Proxy_Pwd    = System.Configuration.ConfigurationSettings.AppSettings["Proxy_Pwd"];
			string Proxy_Domain = System.Configuration.ConfigurationSettings.AppSettings["Proxy_Domain"];

			if (Proxy_User != null    && Proxy_Pwd != null && 
				Proxy_User.Length > 0 && Proxy_Pwd.Length > 0)
			{
				NetworkCredential nc = new NetworkCredential(Proxy_User, Proxy_Pwd);
				if (Proxy_Domain != null && Proxy_Domain.Length > 0)
					nc.Domain = Proxy_Domain;

				GlobalProxySelection.Select.Credentials = nc;
			}
			else
				GlobalProxySelection.Select.Credentials = CredentialCache.DefaultCredentials;

			Application.Run(new MainForm());
		}


		public MainForm()
		{
			if (CVAdminURL == null)
			{
				MessageBox.Show("Il file di configurazione non contiene la chiave CVAdminWebServerURL", "Errore grave", MessageBoxButtons.OK, MessageBoxIcon.Stop);
				return;
			}

			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(976, 517);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.Text = "Amministrazione del Mercato dei Certificati Verdi";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.MainForm_Load);

		}
		#endregion

		#region Download e scarico dell'assembly + lancio della funzione Run dell'assembly
		private void MainForm_Load(object sender, System.EventArgs e)
		{
			// lancio un thread per downlodare l'assembly
			Thread th = new Thread(new ThreadStart(QueryAssembly));
			th.Start();

			// Aspetto che il thread finisca.
			// La finestra scompare quando il thread ha finito
			// Se si preme il tasto cancel il thread viene terminato
			DownloadWait dw = new DownloadWait(th);
			dw.ShowDialog(this);

			if (dw.Cancelled)
				MessageBox.Show(
					"Operazione abortita dall'operatore.\n" + 
					"Il programma non puo' operare senza il completamento della fase di download",
					"Errore", 
					MessageBoxButtons.OK, MessageBoxIcon.Stop);

			if (dw.Cancelled == true || _ass == null)
				this.Close();
		}

		// funzione chiamata nel thread di download
		void QueryAssembly()
		{
			string strFase = null;

			try
			{
				Thread.Sleep(1000); // aspetto un po'

				// scarico anche il file di configurazione della DLL
				// (non uso .config perche' non e' abilitato il download di file .config da IIS)
				string CVAdmin_MainXml = null;
				strFase = "Download del file di configurazione";
				using (WebClient wc = new WebClient())
				{
					byte [] data = wc.DownloadData(CVAdminURL + "/CVAdmin_Main.xml");
					CVAdmin_MainXml = Encoding.ASCII.GetString(data);

					// per test
					// byte [] data2 = wc.DownloadData(CVAdminURL + "/CVAdmin_Main.dll");
				}

				// scarico il file dell'assembly che si andra' a usare
				strFase = "Download del codice";

				string CVAdminPath = CVAdminURL;

				// la voce CVAdminPath consente di utilizzare una dll locale (-->debuggabile)
				if (ConfigurationSettings.AppSettings["CVAdminPath"] != null)
					CVAdminPath = ConfigurationSettings.AppSettings["CVAdminPath"];

				_ass = Assembly.LoadFrom(CVAdminPath + "/CVAdmin_Main.dll");

				// se sono qui il download e' finito
				this.Invoke(new GotAssemblyDelegate(GotAssembly), new object [] { null,  null, CVAdmin_MainXml });
			}
			catch (Exception e)
			{
				// ho finito il download ma e' andato male
				// ==> spedisco l'eccezione rilevata al thread della finestra principale
				_ass = null;
				this.Invoke(new GotAssemblyDelegate(GotAssembly), new object [] { e, strFase, null });
			}
		}

		delegate void GotAssemblyDelegate(Exception ex, string strFase, string CVAdmin_MainXml);
		void GotAssembly(Exception ex, string strFase, string CVAdmin_MainXml)
		{
			if (ex != null)
			{
				// ricerco nell'exception chain se e' stato interrotto il thread
				// con un Abort. Se si, evidentemente e' stato premuto cancel
				// e dunque non si deve presentare il messaggio di errore.
				bool bAbort = false;
				for (Exception ei = ex; ei != null ; ei = ei.InnerException)
				{
					if (ei is System.Threading.ThreadAbortException)
					{
						bAbort = true;
						break;
					}
				}

				if (bAbort == false)
				{
					string msg = "Errore di collegamento al sito remoto.\n";
					msg += "Verificare la connessione ad Internet.\n\n";
					if (strFase != null)
						msg += "Fase: " + strFase + "\n";
					msg += ex.Message;

					MessageBox.Show(
						msg, 
						"Errore fatale",
						MessageBoxButtons.OK, MessageBoxIcon.Stop);

					Trace.WriteLine("Eccezione dal server (GotAssembly)");
					Trace.Indent();
					Trace.WriteLine(ex.Message);
					Trace.WriteLine(ex.StackTrace);
					Trace.Unindent();
				}

				// esco senza lanciare l'assembly (dato che non esiste proprio)
				return;
			}

			// il download e' terminato con successo

			Debug.Assert(_ass != null);
		
			Cursor.Current = Cursors.WaitCursor;
			try
			{
				Type ty = _ass.GetType("CVAdmin_Main.MainFormRunner");
				ConstructorInfo ci = ty.GetConstructor(new Type[] {});
				object obj = ci.Invoke(new object [] {});
				ty.InvokeMember("Run", BindingFlags.Public|BindingFlags.InvokeMethod|BindingFlags.Instance, null, obj, new object [] {this, CVAdmin_MainXml});
			}
			catch (Exception e)
			{
				Cursor.Current = Cursors.Default;
				MessageBox.Show("Errore di collegamento al sito remoto.\n" +
					e.Message + "\n" + e.StackTrace, "Errore grave",MessageBoxButtons.OK, MessageBoxIcon.Stop);
			}
			finally
			{
				Cursor.Current = Cursors.Default;
			}
		}
		#endregion


	}
}
