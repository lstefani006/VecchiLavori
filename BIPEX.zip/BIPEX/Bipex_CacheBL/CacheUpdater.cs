using System;
using System.ComponentModel;
using Bipex_BLInterface;
using Bipex_Cache;
using GME.BL;

namespace Bipex_CacheBL
{

	[RemotableServer("Bipex_CacheServer", "CacheUpdater.rem")]
	public class CacheUpdater : BLBase, Bipex_BLInterface.ICacheUpdater
	{
		#region Costruttori ecc ecc

		private Container components = null;

		public CacheUpdater(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public CacheUpdater()
		{
			InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#endregion

		#region ICacheUpdater Members

		public void OnAbbinamento(string contratto)
		{
			Console.WriteLine("OnAbbinamento {0}", contratto);
			BipexCachePublisher.G.OnAbbinamento(contratto);
		}

		public void OnSessioneMercato()
		{
			Console.WriteLine("OnSessioneMercato");
			BipexCachePublisher.G.OnSessioneMercato();
		}

		#endregion
	}
}
