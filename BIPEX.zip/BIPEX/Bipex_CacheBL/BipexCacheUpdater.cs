using System;
using System.Collections;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Bipex_BLInterface;
using Delta;
using GME;
using GME.BL;
using GME.Utility;
using SPDriver;
//using SPDriver;

namespace Bipex_Cache
{
	/// <summary>
	/// classe che contiene subject e subSubject
	/// Implmenta IComparable per essere sortata/ordinata, messa in una lista ecc.
	/// </summary>
	public class CacheKey : IComparable
	{
		public readonly string _subject;
		public readonly string _subSubject;

		public CacheKey(string subject, string subSubject)
		{
			this._subject = subject;
			this._subSubject = subSubject;
		}

		public int CompareTo(object obj)
		{
			CacheKey a = this;
			CacheKey b = (CacheKey) obj;

			if (a == null && b == null) return 0;
			if (a == null && b != null) return +1;
			if (a != null && b == null) return -1;

			int c = string.Compare(a._subject, b._subject);
			if (c != 0) return c;

			return string.Compare(a._subSubject, b._subSubject);
		}

		public string Subject
		{
			get { return _subject; }
		}

		public string SubSubject
		{
			get { return _subSubject; }
		}
	}

	#region CachePair

	/// <summary>
	/// classe che associa una CacheKey con l'item in cache.
	/// </summary>
	public class CachePair : IComparable
	{
		public CachePair(string subject, string subSubject, Facade_DRList drl)
		{
			this._ck = new CacheKey(subject, subSubject);
			this._DrlItem = drl;
		}

		public string Subject
		{
			get { return _ck.Subject; }
		}

		public string SubSubject
		{
			get { return _ck.SubSubject; }
		}

		public byte[] StreamedItem
		{
			get { return CompactFormatter.WriteObject(_DrlItem.DRList, CompressionType.None); }
		}

		int IComparable.CompareTo(object y)
		{
			return _ck.CompareTo(((CachePair) y)._ck);
		}

		/// <summary>
		/// Confronto da DataRecordList (utilizzando la versione streamata)
		/// </summary>
		/// <param name="cb"></param>
		/// <returns></returns>
		public bool UpdateIfItemIsDifferent(CachePair cb)
		{
			byte[] a = this.StreamedItem;
			byte[] b = cb.StreamedItem;

			int sza = a.Length;
			int szb = b.Length;

			if (sza != szb) goto different;

			for (int i = 0; i < sza; ++i)
				if (a[i] != b[i])
					goto different;

			return false;

			different:
			this._DrlItem = cb._DrlItem;
			return true;
		}

		private CacheKey _ck;
		private Facade_DRList _DrlItem;


		public bool OnTimer(DateTime ts)
		{
			return _DrlItem.OnTimer(ts);
		}

		public void Dump(TextWriter tw)
		{
			_DrlItem.Dump(tw);
		}
	}

	#endregion

	public class UniqueArrayList
	{
		public UniqueArrayList(Type ty)
		{
			_ty = ty;
			if (_ty == null)
				throw new ArgumentNullException("ty", "il tipo e` obbligatorio");
		}


		private ArrayList _a = new ArrayList();
		private Type _ty;

		/// <summary>
		/// Aggiunge un elemento alla lista.
		/// Se l'elemento e` gia` nella lista lo sostituisce
		/// </summary>
		/// <param name="v">elemento da inserire. Se implementare IComparable.</param>
		public void Add(IComparable v)
		{
			if (v != null)
			{
				if (v.GetType() != _ty)
					throw new ArgumentException("UniqueArrayList.Add - item inserito del tipo errato", "v");
			}

			for (int i = 0; i < _a.Count; ++i)
			{
				if (_a[i] == null)
					continue;

				if (v.CompareTo(_a[i]) == 0)
				{
					_a[i] = v;
					return;
				}
			}

			for (int i = 0; i < _a.Count; ++i)
			{
				if (_a[i] == null)
				{
					_a[i] = v;
					return;
				}
			}

			_a.Add(v);
		}

		public void AddRange(IList a)
		{
			foreach (IComparable v in a)
				Add(v);
		}

		public IComparable this[int i]
		{
			get { return (IComparable) _a[i]; }
			set
			{
				if (value != null && value.GetType() != _ty)
					throw new ArgumentException("l'elemento inserito non e` del tipo corretto");
				_a[i] = value;
			}
		}

		public int Count
		{
			get { return _a.Count; }
		}

		public Array ToTypedArray()
		{
			if (_ty == null)
				throw new ArgumentNullException("", "non e` stato specificato il tipo nell costruttore della classe UniqueArrayList");
			return _a.ToArray(_ty);
		}

		public IEnumerator GetEnumerator()
		{
			return _a.GetEnumerator();
		}
	}


	/// <summary>
	/// Cache lato Bipex_Cache[Server/Service]
	/// </summary>
	public class BipexCacheAS
	{
		public BipexCacheAS()
		{
			_h = new SortedList();
		}

		/// <summary>
		/// sincronizzazione: carica dal db e si sincronizza chiamando Load_xyz che chiama UpdateItem
		/// </summary>
		/// <returns></returns>
		public void InitCache()
		{
			try
			{
				this.Load_MarketSession();
				this.Load_BookRiassuntivo();

				ContrattoPair[] contractList = Load_ListaContratti();
				foreach (ContrattoPair cp in contractList)
				{
					this.Load_BookSingoloContratto(cp.Contratto);
					this.Load_Offerta(cp.Contratto);
				}

				Load_DailyActivity();
				Load_DailyActivityLog();
				Load_OpenOrders();
				Load_SaldoFisico();

				// simulo un evento di timer per 
				// azzerare i bit del trend
				UpdateFromTimerEvent(DBNow);

				Dump(Console.Out);
			}
			catch (Exception ex)
			{
				Log.smError(ex, "InitCache");
			}
		}

		#region DBNow

		private static bool DBNowFirst = true;
		private static DateTime FirstTime;
		private static TimeSpan deltaTime;
		private static object dateLock = new object();

		/// <summary>
		/// Ora del DB. 
		/// La prima volta si richiede l'ora al DB. 
		/// Le successive volte si ottiene l'ora per differenza tra l'ora di questo server
		/// e l'ora del DB.
		/// La differenza viene utilizzata al piu` per un ora, poi si richiede l'ora al server
		/// </summary>
		public static DateTime DBNow
		{
			get
			{
				lock (dateLock)
				{
					if (DBNowFirst)
					{
						DateTime tsDBNow;

						// tiro giu` l'ora dal DB
						try
						{
							using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
							{
								SqlDateTime t = new SqlDateTime();
								cn.Open();
								SPDriver.OraCorrente.Execute(cn, ref t);
								tsDBNow = t.Value;
							}

							DBNowFirst = false;
						}
						catch
						{
							tsDBNow = DateTime.Now;
						}

						FirstTime = DateTime.Now;
						deltaTime = tsDBNow - FirstTime;

						return tsDBNow;
					}
					else
					{
						if ((DateTime.Now - FirstTime).TotalHours >= 1)
							DBNowFirst = false;
						return DateTime.Now + deltaTime;
					}
				}
			}
		}

		public void Dump(TextWriter tw)
		{
			lock (this)
			{
				for (int i = 0; i < _h.Count; i++)
				{
					CachePair c = (CachePair) _h.GetKey(i);
					c.Dump(tw);
				}
			}
		}

		#endregion

		internal CachePair[] UpdateFromTimerEvent(DateTime tsNow)
		{
			lock (this)
			{
				UniqueArrayList a = new UniqueArrayList(typeof (CachePair));

				for (int i = 0; i < _h.Count; i++)
				{
					CachePair c = (CachePair) _h.GetKey(i);

					if (c.OnTimer(tsNow))
						a.Add(c);
				}

				// qui anche se tolgo qualche abbonamento non costringo di rifare la query....
				// i dati non sono mica cambiati.
				// Al prossimo evento la query tirera` su solo gli abbonamenti giusti.
				this.SaldoFisico_UnSubscribe(tsNow);

				return (CachePair[]) a.ToTypedArray();
			}
		}

		/// <summary>
		/// Funzione che determina su di un evento di abbinamento
		/// quale eventi in coda mettere.
		/// </summary>
		/// <param name="contratto"></param>
		/// <returns></returns>
		private static void CacheListToUpdateFromAbbinamento(UniqueArrayList r, string contratto)
		{
			r.Add(new CacheKey(OffertaDR.SubjectType, contratto));
			r.Add(new CacheKey(BookSingoloContrattoDR.SubjectType, contratto));
			r.Add(new CacheKey(BookRiassuntivoDR.SubjectType, BookRiassuntivoDR.SubjectSubType));
			r.Add(new CacheKey(MarketSessionDR.SubjectType, MarketSessionDR.SubjectSubType));
			r.Add(new CacheKey(DailyActivityDR.SubjectType, DailyActivityDR.SubjectSubType));
			r.Add(new CacheKey(DailyActivityLogDR.SubjectType, DailyActivityLogDR.SubjectSubType));
			r.Add(new CacheKey(OpenOrderDR.SubjectType, OpenOrderDR.SubjectSubType));
			r.Add(new CacheKey(SaldoFisicoDR.SubjectType, SaldoFisicoDR.SubjectSubType));
		}

		/// <summary>
		/// Funzione che determina su di un evento di sessione o altro
		/// quale eventi in coda mettere.
		/// </summary>
		/// <returns></returns>
		private static void CacheListToUpdateFromSessione(ContrattoPair[] cp, UniqueArrayList r)
		{
			foreach (ContrattoPair contratto in cp)
			{
				r.Add(new CacheKey(OffertaDR.SubjectType, contratto.Contratto));
				r.Add(new CacheKey(BookSingoloContrattoDR.SubjectType, contratto.Contratto));
			}

			r.Add(new CacheKey(BookRiassuntivoDR.SubjectType, BookRiassuntivoDR.SubjectSubType));
			r.Add(new CacheKey(MarketSessionDR.SubjectType, MarketSessionDR.SubjectSubType));
			r.Add(new CacheKey(DailyActivityDR.SubjectType, DailyActivityDR.SubjectSubType));
			r.Add(new CacheKey(DailyActivityLogDR.SubjectType, DailyActivityLogDR.SubjectSubType));
			r.Add(new CacheKey(OpenOrderDR.SubjectType, OpenOrderDR.SubjectSubType));
			r.Add(new CacheKey(SaldoFisicoDR.SubjectType, SaldoFisicoDR.SubjectSubType));
		}


		internal static CacheKey[] CreateCacheKeyListToUpdate(QueueItem[] qiList, ContrattoPair[] cp)
		{
			UniqueArrayList rCacheKey = new UniqueArrayList(typeof (CacheKey));

			foreach (QueueItem qi in qiList)
			{
				switch (qi.EventType)
				{
				case QueueItem.QueueItemType.EventoSuAbbinamentoContratto:
					CacheListToUpdateFromAbbinamento(rCacheKey, qi.NomeContratto);
					break;
				case QueueItem.QueueItemType.EventoSuSessione:
					CacheListToUpdateFromSessione(cp, rCacheKey);
					break;
				default:
					Debug.Assert(false);
					break;
				}
			}

			// qui ho costruito una lista con CacheKey non duplicati.
			// Notare che la lista contiene tutti e solo i CacheKey da tirare su.
			// Non contiene elementi inutili
			return (CacheKey[]) rCacheKey.ToTypedArray();
		}

		internal CachePair[] UpdateFromDBEvent(CacheKey[] cacheKeyList)
		{
			ArrayList rCachePair = new ArrayList();

			foreach (CacheKey ck in cacheKeyList)
			{
				CachePair cp = null;

				switch (ck.Subject)
				{
				case BookRiassuntivoDR.SubjectType:
					cp = Load_BookRiassuntivo();
					break;
				case BookSingoloContrattoDR.SubjectType:
					cp = Load_BookSingoloContratto(ck.SubSubject);
					break;

				case DailyActivityDR.SubjectType:
					cp = Load_DailyActivity();
					break;

				case DailyActivityLogDR.SubjectType:
					cp = Load_DailyActivityLog();
					break;


				case MarketSessionDR.SubjectType:
					cp = Load_MarketSession();
					break;

				case OffertaDR.SubjectType:
					cp = Load_Offerta(ck.SubSubject);
					break;

				case OpenOrderDR.SubjectType:
					cp = Load_OpenOrders();
					break;

				case SaldoFisicoDR.SubjectType:
					cp = Load_SaldoFisico();
					break;

				default:
					throw new ArgumentException("e.subject - valore sconosciuto", "e");
				}
				if (cp != null)
					rCachePair.Add(cp);
			}
			return (CachePair[]) rCachePair.ToArray(typeof (CachePair));
		}

		/// <summary>
		/// Ritorna un'array con tutti gli item presenti i cache
		/// Sincronizzazione: usa regione critica.
		/// </summary>
		/// <returns></returns>
		internal CachePair[] GetAllCachedItems()
		{
			lock (this)
			{
				ArrayList r = new ArrayList();

				for (int i = 0; i < _h.Count; i++)
					r.Add(_h.GetKey(i));

				return (CachePair[]) r.ToArray(typeof (CachePair));
			}
		}

		#region Load_xyz

		private CachePair Load_Offerta(string contratto)
		{
			Facade_OffertaDR f = new Facade_OffertaDR();
			f.Load(contratto);

			CachePair b = this.UpdateItem(OffertaDR.SubjectType, contratto, f);
			return b;
		}

		private CachePair Load_BookSingoloContratto(string Contratto)
		{
			Facade_BookSingoloContrattoDR f = new Facade_BookSingoloContrattoDR();
			f.Load(Contratto);
			CachePair b = this.UpdateItem(BookSingoloContrattoDR.SubjectType, Contratto, f);
			return b;
		}

		private CachePair Load_BookRiassuntivo()
		{
			Facade_BookRiassuntivoDR f = new Facade_BookRiassuntivoDR();
			f.Load(null);
			CachePair b = this.UpdateItem(BookRiassuntivoDR.SubjectType, BookRiassuntivoDR.SubjectSubType, f);
			return b;
		}

		private CachePair Load_MarketSession()
		{
			Facade_MarketSessionDR f = new Facade_MarketSessionDR();
			f.Load(null);
			CachePair b = this.UpdateItem(MarketSessionDR.SubjectType, MarketSessionDR.SubjectSubType, f);
			return b;
		}

		private CachePair Load_DailyActivity()
		{
			Facade_DailyActivityDR f = new Facade_DailyActivityDR();
			f.Load(null);
			CachePair b = this.UpdateItem(DailyActivityDR.SubjectType, DailyActivityDR.SubjectSubType, f);
			return b;
		}

		private CachePair Load_DailyActivityLog()
		{
			Facade_DailyActivityLogDR f = new Facade_DailyActivityLogDR();
			f.Load(null);
			CachePair b = this.UpdateItem(DailyActivityLogDR.SubjectType, DailyActivityLogDR.SubjectSubType, f);
			return b;
		}


		private CachePair Load_OpenOrders()
		{
			Facade_OpenOrderDR f = new Facade_OpenOrderDR();
			f.Load(null);
			CachePair b = this.UpdateItem(OpenOrderDR.SubjectType, OpenOrderDR.SubjectSubType, f);
			return b;
		}

		private CachePair Load_SaldoFisico()
		{
//			string xml = "";
//			xml += "<SF>";
//			xml += "<R Op='OP1' Data='20051001' />";
//			xml += "<R Op='OP2' Data='20051002' />";
//			xml += "</SF>";

			StringBuilder xml = new StringBuilder();
			lock (_subscribeSaldoFisico)
			{
				xml.Append("<SF>");
				foreach (Subscribe_SaldoFisico_Data sfd in _subscribeSaldoFisico)
					xml.AppendFormat("<R Op='{0}' Data='{1:yyyy}{1:MM}{1:dd}' />", sfd.CodiceOperatore, sfd.DataDelivery);
				xml.Append("</SF>");
			}


			Facade_SaldoFisicoDR f = new Facade_SaldoFisicoDR();
			f.Load(xml.ToString());
			CachePair b = this.UpdateItem(SaldoFisicoDR.SubjectType, SaldoFisicoDR.SubjectSubType, f);
			return b;
		}


		private ArrayList _subscribeSaldoFisico = new ArrayList();

		public bool SaldoFisico_Subscribe(Subscribe_SaldoFisico_Data[] sfdList, DateTime ts)
		{
			bool modificato = false;
			lock (_subscribeSaldoFisico)
			{
				foreach (Subscribe_SaldoFisico_Data sfd in sfdList)
				{
					sfd.DataDelivery = sfd.DataDelivery.Date; // per evitare problemi
					modificato = modificato || SaldoFisico_Subscribe(sfd, ts);
				}
			}
			return modificato;
		}
		private bool SaldoFisico_Subscribe(Subscribe_SaldoFisico_Data sfd, DateTime ts)
		{
			foreach (Subscribe_SaldoFisico_Data s in _subscribeSaldoFisico)
			{
				if (s.CodiceOperatore == sfd.CodiceOperatore &&
					s.DataDelivery == sfd.DataDelivery)
				{
					s.LastSubscribe = ts;
					return false;
				}
			}

			sfd.LastSubscribe = ts;
			_subscribeSaldoFisico.Add(sfd);
			return true;
		}

		public void SaldoFisico_UnSubscribe(DateTime ts)
		{
			lock (_subscribeSaldoFisico)
			{
				for (int s = _subscribeSaldoFisico.Count - 1; s >= 0; --s)
				{
					Subscribe_SaldoFisico_Data sfd = (Subscribe_SaldoFisico_Data) _subscribeSaldoFisico[s];
					if (sfd.LastSubscribe.AddSeconds(30) < ts)
						_subscribeSaldoFisico.RemoveAt(s);
				}
			}
		}

		#endregion

		#region Load_ListaContratti

		public class ContrattoPair
		{
			public string Contratto;
			public int IdContratto;
		}

		internal static ContrattoPair[] Load_ListaContratti()
		{
			ArrayList a = new ArrayList();
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();
					using (SessioneCorrente_ListaContratti rd = new SessioneCorrente_ListaContratti(cn))
					{
						rd.dummy = -1;

						ArrayList q = rd.ExecuteReader(typeof(SPDriver.ListaContrattiRow));

						foreach  (SPDriver.ListaContrattiRow rq in q)
						{
							ContrattoPair c = new ContrattoPair();

							c.IdContratto = rq.nnIdContratto;
							c.Contratto = rq.nnNomeContratto;
							a.Add(c);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Load_BookSingoloContratto");
				throw;
			}

			return (ContrattoPair[]) a.ToArray(typeof (ContrattoPair));
		}

		#endregion

		//////////////////////////////////////////////////////////
		private CachePair UpdateItem(string subject, string subSubject, Facade_DRList a)
		{
			lock (this)
			{
				if (subSubject == null) subSubject = string.Empty;

				CachePair cNew = new CachePair(subject, subSubject, a);

				int i = _h.IndexOfKey(cNew);
				if (i < 0)
				{
					// e` nuova nella cache --> l'item e` stato aggiornato
					_h.Add(cNew, null);
					return cNew;
				}
				else
				{
					// esiste nella cache --> controllo se e` cambiato il contenuto
					CachePair cCurrent = (CachePair) (_h.GetKey(i));

					if (cCurrent.UpdateIfItemIsDifferent(cNew))
						return cCurrent;
					else
						return null;
				}
			}
		}


		private SortedList _h;
	}


	/// <summary>
	/// Server tcp in listen su Bipex_CacheServer.
	/// Bil_BLWS avvisa BipexCachePublisher che il book e` cambiato.
	/// BipexCachePublisher aggiorna il book e avvisa tutti i suoi subscribers
	/// ossia Bipex_ControlWS
	/// </summary>
	public class BipexCachePublisher
	{
		private static BipexCachePublisher _S;

		private Thread _thTcpServer;
		private Thread _thTimer;

		private ArrayList _clientList = null;
		private BipexCacheAS _srcCache;

		private QueueEvents _queuedEvents = new QueueEvents();

		public static BipexCachePublisher G
		{
			get { return _S; }
		}

		public BipexCachePublisher(BipexCacheAS srcCache)
		{
			if (_S != null)
				throw new ApplicationException("BipexCachePublisher gia` partito");
			_S = this;

			_srcCache = srcCache;

			_thTcpServer = new Thread(new ThreadStart(this.ThreadTcpSever));
			_thTcpServer.IsBackground = true;
			_thTcpServer.Start();

			if (true)
			{
				_thTimer = new Thread(new ThreadStart(this.ThreadTimer));
				_thTimer.IsBackground = true;
				_thTimer.Start();
			}
		}

		public void Stop()
		{
			_thTcpServer.Abort();
		}

		private void ThreadTcpSever()
		{
			TcpListener server = null;
			for (;; )
			{
				try
				{
					_clientList = new ArrayList();

					string hostName = AppSettings.ToString("BipexCacheUpdater_Hostname", "127.0.0.1");
					int port = AppSettings.ToInt32("BipexCacheUpdater_Port", 7258);

					IPAddress localAddr = IPAddress.Parse(hostName);
					server = new TcpListener(localAddr, port);

					server.Start();

					for (;; )
					{
						TcpClient client = server.AcceptTcpClient();
						lock (this) NewClient(client);
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("Th {0}", ex.Message);

					lock (this) CloseAllClients();

					if (server != null) server.Stop();

					Log.smError(ex);
				}

				Thread.Sleep(1000);
			}
		}

		private void ThreadTimer()
		{
			BipexCacheAS.ContrattoPair[] contractList = BipexCacheAS.Load_ListaContratti();

			int nColpi = 0;

			if (Facade_DRList.timeOut == 0)
				LeggiParametri(out Facade_DRList.timeOut);

			for (;; )
			{
				Thread.Sleep(500);

				// ogni minuto vado a rileggere il timeout del semaforo rosso verde
				// cosi` se cambia il valore da DB....
				nColpi += 1;
				if (nColpi > 120)
				{
					nColpi = 0;
					LeggiParametri(out Facade_DRList.timeOut);
				}

				DateTime dbTS = BipexCacheAS.DBNow;

				// consumo gli eventi in coda
				QueueItem[] e = _queuedEvents.GetEvents();
				if (e.Length > 0)
					Console.WriteLine("{0}, Eventi in coda da servire: {1}", dbTS, e.Length);
				//else
				//	Console.WriteLine("{0}, Nessun evento in coda", dbTS);

				// in <e> gli eventi NON sono duplicati
				// ma ci possono essere eventi "inutili"
				// p.es un evento di sessione + un evento di abbinamento
				// l'evento di sessione costringe a ricaricare tutto dal DB

				// qui trovo la lista delle chiavi della cache da caricare dal DB
				// Questa lista NON e` mai ridondante, ossia non si caricano due
				// volte gli item in cache
				CacheKey[] ckList = BipexCacheAS.CreateCacheKeyListToUpdate(e, contractList);
				if (ckList.Length > 0)
					Console.WriteLine("Tipi record da caricare dal DB: {0}", ckList.Length);


				UniqueArrayList modifiedCacheItems = new UniqueArrayList(typeof (CachePair));

				CachePair[] cp;

				// qui ricarico i dati dal DB.
				// in mod ottengo i DR effettivamente aggiornati
				cp = _srcCache.UpdateFromDBEvent(ckList);
				modifiedCacheItems.AddRange(cp);
				if (cp.Length > 0)
					Console.WriteLine("Tipi record aggiornati dal DB: {0}", cp.Length);
				//else
				//	Console.WriteLine("Nessun tipo record aggiornato dal DB");


				// qui aggiorno i record in funzione del tempo che e` passato.
				cp = _srcCache.UpdateFromTimerEvent(dbTS);
				modifiedCacheItems.AddRange(cp);
				if (cp.Length > 0)
					Console.WriteLine("Tipi record aggiornati dal timer: {0}", cp.Length);
				//else
				//	Console.WriteLine("Nessun tipo record aggiornato dal timer");


				// qui in <mod> ho tutti i CachePair NON duplicati

				// qui aggiorno i clienti
				foreach (CachePair c in modifiedCacheItems)
				{
					Console.Write("Invio il record modificato ");
					c.Dump(Console.Out);
					UpdateClientsCache(c);
				}

				if (modifiedCacheItems.Count > 0)
				{
					Console.WriteLine("{0} CacheItem inviati/o agli abbonati", modifiedCacheItems.Count);
					// _srcCache.Dump(Console.Out);
				}
				else
				{
					//Console.WriteLine("Nessun CacheItem inviato agli abbonati");
				}
			}
		}

		private void LeggiParametri(out int timeoutRossoVerde)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					SqlInt32 TimeoutRossoVerde = new SqlInt32();
					SPDriver.LeggiParametri.Execute(cn, ref TimeoutRossoVerde);
					timeoutRossoVerde = TimeoutRossoVerde.Value;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				timeoutRossoVerde = 30;
			}
		}

		private void CloseAllClients()
		{
			for (int i = 0; i < _clientList.Count; i++)
				CloseClient(i);
		}

		private void CloseClient(TcpClient c)
		{
			for (int i = 0; i < _clientList.Count; i++)
			{
				if (_clientList[i] == c)
				{
					CloseClient(i);
					break;
				}
			}
		}

		private void CloseClient(int i)
		{
			TcpClient c = (TcpClient) _clientList[i];
			if (c == null) return;
			try
			{
				c.Close();
			}
			catch
			{}
			this._clientList[i] = null;
		}


		private void NewClient(TcpClient client)
		{
			if (true)
			{
				int i;
				for (i = 0; i < _clientList.Count; i++)
				{
					if (_clientList[i] == null)
					{
						_clientList[i] = client;
						break;
					}
				}

				if (i == _clientList.Count)
					_clientList.Add(client);
			}

			// qui devo sparargli indietro tutta la cache corrente.
			UpdateClientCacheItems(client);
		}

		public void OnAbbinamento(string contratto)
		{
			QueueItem qi = new QueueItem(QueueItem.QueueItemType.EventoSuAbbinamentoContratto, contratto);
			_queuedEvents.Add(qi);
		}

		public void OnSessioneMercato()
		{
			QueueItem qi = new QueueItem(QueueItem.QueueItemType.EventoSuSessione, null);
			_queuedEvents.Add(qi);
		}


		public void Subscribe_SaldoFisico(Subscribe_SaldoFisico_Data[] s)
		{
			bool modificato = _srcCache.SaldoFisico_Subscribe(s, BipexCacheAS.DBNow);
			if (modificato)
			{
				QueueItem qi = new QueueItem(QueueItem.QueueItemType.EventoSuSessione, null);
				_queuedEvents.Add(qi);
			}
		}


		public class QueueEvents
		{
			private Queue _q = new Queue();

			public void Add(QueueItem qi)
			{
				lock (this)
				{
					_q.Enqueue(qi);
				}
			}

			/// <summary>
			/// Gli eventi NON sono duplicati
			/// </summary>
			/// <returns></returns>
			public QueueItem[] GetEvents()
			{
				UniqueArrayList a = new UniqueArrayList(typeof (QueueItem));

				lock (this)
				{
					for (int i = 0; i < _q.Count; ++i)
					{
						QueueItem e = (QueueItem) _q.Dequeue();
						a.Add(e); // aggiunge ma non duplica.
					}
				}

				return (QueueItem[]) a.ToTypedArray();
			}
		}


		/// <summary>
		/// Aggiorna l'item della cache.
		/// </summary>
		/// <param name="cp"></param>
		public void UpdateClientsCache(CachePair cp)
		{
			lock (this)
			{
				for (int i = 0; i < _clientList.Count; i++)
				{
					TcpClient client = (TcpClient) this._clientList[i];
					if (client == null)
						continue;

					try
					{
						UpdateClientCache(client, cp);
					}
					catch (Exception ex)
					{
						Console.WriteLine("UpdateClientsCache {0} {1}", ex.Message, ex.StackTrace);
						CloseClient(i);
					}
				}
			}
		}

		// private static void UpdateClientCache(TcpClient client, string SubjectType, string SubjectSubType, byte[] m)
		private static void UpdateClientCache(TcpClient client, CachePair cp)
		{
			NetworkStream stream = client.GetStream();

			BinaryWriter bw = new BinaryWriter(stream);
			bw.Write(cp.Subject);
			bw.Write(cp.SubSubject);
			bw.Write(cp.StreamedItem.Length);
			bw.Write(cp.StreamedItem);
			bw.Flush();
			stream.Flush();

			BinaryReader br = new BinaryReader(stream, Encoding.UTF8);
			int len = br.ReadInt32();
			if (len != cp.StreamedItem.Length)
				throw new ApplicationException("Frame TCP error");
		}

		private void UpdateClientCacheItems(TcpClient client)
		{
			CachePair[] f = _srcCache.GetAllCachedItems();
			foreach (CachePair p in f)
			{
				try
				{
					UpdateClientCache(client, p);
				}
				catch (Exception ex)
				{
					Console.WriteLine("UpdateClientCacheItems {0}", ex.Message);

					CloseClient(client);
					break;
				}
			}
		}
	}


	//////////////////////////////////////////////////////////
	//// Facade delle liste di DR
	public abstract class Facade_DRList
	{
		public DataRecordList DRList
		{
			get { return _drl; }
		}

		public abstract bool OnTimer(DateTime tsNow);
		public abstract void Load(string contesto);


		public virtual void Dump(TextWriter tw)
		{
			string mm = string.Format("{0} : trovati {1} record", GetType().Name, _drl.Count);
			tw.WriteLine(mm);
		}

		protected DataRecordList _drl;
		public static int timeOut = 0;
	}

	public class Facade_OffertaDR : Facade_DRList
	{
		private static DataRecordReader _drr = null;
		private static string _contratto = null;

		static Facade_OffertaDR()
		{
			_drr = new DataRecordReader(typeof (OffertaDR));
		}

		public override void Dump(TextWriter tw)
		{
			string mm = string.Format("{0} - {1}: trovati {2} record", GetType().Name, _contratto, _drl.Count);
			tw.WriteLine(mm);
		}


		public override void Load(string contratto)
		{
			_contratto = contratto;
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();

					using (SessioneCorrente_Offerta rd = new SessioneCorrente_Offerta(cn))
					{
						rd.Contratto = contratto;
						_drl = _drr.Read(rd.ExecuteReader());
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Facade_OffertaDR.Load");
				throw;
			}
		}


		public override bool OnTimer(DateTime tsNow)
		{
			bool cambiato = false;

			foreach (OffertaDR dr in DRList)
			{
				if ( /*dr.IsNotNull("Indicators")*/true) // Indicators non e` nullabile in OffertaDR
				{
					OffertaDR.Indicator oldIndicator = dr.Indicators;

					if (dr.PosizioneBook == 1) //LEO TODO VERIFICARE se il primo ha 0 o 1 di posizione
					{
						if (dr.IsNull("IndicatorAskChangeTS") || (tsNow - dr.IndicatorAskChangeTS).TotalSeconds > timeOut)
							dr.SetBestAskTrendStopped();

						if (dr.IsNull("IndicatorBidChangeTS") || (tsNow - dr.IndicatorBidChangeTS).TotalSeconds > timeOut)
							dr.SetBestBidTrendStopped();
					}
					else
					{
						dr.SetBestAskTrendStopped();
						dr.SetBestBidTrendStopped();
					}

					if (oldIndicator != dr.Indicators)
						cambiato = true;
				}
			}

			return cambiato;
		}

	}

	public class Facade_BookRiassuntivoDR : Facade_DRList
	{
		public override bool OnTimer(DateTime tsNow)
		{
			bool cambiato = false;

			foreach (BookRiassuntivoDR dr in DRList)
			{
				if (dr.IsNotNull("Indicators"))
				{
					BookRiassuntivoDR.Indicator oldIndicator = dr.Indicators;

					if (dr.IsNull("IndicatorAskChangeTS") || (tsNow - dr.IndicatorAskChangeTS).TotalSeconds > timeOut)
						dr.SetBestAskTrendStopped();

					if (dr.IsNull("IndicatorBidChangeTS") || (tsNow - dr.IndicatorBidChangeTS).TotalSeconds > timeOut)
						dr.SetBestBidTrendStopped();

					if (oldIndicator != dr.Indicators)
						cambiato = true;
				}
			}

			return cambiato;
		}

		private static DataRecordReader _drr = null;

		static Facade_BookRiassuntivoDR()
		{
			_drr = new DataRecordReader(typeof (BookRiassuntivoDR));
		}

		public override void Load(string contratto)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();
					using (SessioneCorrente_BookRiassuntivo rd = new SessioneCorrente_BookRiassuntivo(cn))
					{
						rd.dummy = -1;
						_drl = _drr.Read(rd.ExecuteReader());
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Facade_BookRiassuntivoDR.Load");
				throw;
			}
		}
	}

	public class Facade_BookSingoloContrattoDR : Facade_DRList
	{
		public override bool OnTimer(DateTime tsNow)
		{
			return false;
		}

		private static DataRecordReader _drr = null;
		private string _contratto = null;

		static Facade_BookSingoloContrattoDR()
		{
			_drr = new DataRecordReader(typeof (BookSingoloContrattoDR));
		}

		public override void Dump(TextWriter tw)
		{
			string mm = string.Format("{0} - {1}: trovati {2} record", GetType().Name, _contratto, _drl.Count);
			tw.WriteLine(mm);
		}

		public override void Load(string contratto)
		{
			_contratto = contratto;
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();
					using (SessioneCorrente_BookSingoloContratto rd = new SessioneCorrente_BookSingoloContratto(cn))
					{
						rd.Contratto = contratto;
						_drl = _drr.Read(rd.ExecuteReader());
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Facade_BookSingoloContrattoDR.Load");
				throw;
			}
		}

	}

	public class Facade_DailyActivityDR : Facade_DRList
	{
		public override bool OnTimer(DateTime tsNow)
		{
			return false;
		}

		private static DataRecordReader _drr = null;

		static Facade_DailyActivityDR()
		{
			_drr = new DataRecordReader(typeof (DailyActivityDR));
		}

		public override void Load(string contratto)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();
					using (SessioneCorrente_DailyActivity rd = new SessioneCorrente_DailyActivity(cn))
					{
						rd.dummy = -1;
						_drl = _drr.Read(rd.ExecuteReader());
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Facade_DailyActivityDR.Load");
				throw;
			}
		}

	}

	public class Facade_DailyActivityLogDR : Facade_DRList
	{
		public override bool OnTimer(DateTime tsNow)
		{
			return false;
		}

		private static DataRecordReader _drr = null;

		static Facade_DailyActivityLogDR()
		{
			_drr = new DataRecordReader(typeof (DailyActivityLogDR));
		}

		public override void Load(string contratto)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();
					using (SessioneCorrente_DailyActivityLog rd = new SessioneCorrente_DailyActivityLog(cn))
					{
						rd.lastDailyActivity = SqlInt32.Null;
						_drl = _drr.Read(rd.ExecuteReader());
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Facade_DailyActivityLogDR.Load");
				throw;
			}
		}
	}

	public class Facade_MarketSessionDR : Facade_DRList
	{
		public override bool OnTimer(DateTime tsNow)
		{
			return false;
		}

		private static DataRecordReader _drr = null;

		static Facade_MarketSessionDR()
		{
			_drr = new DataRecordReader(typeof (MarketSessionDR));
		}

		public override void Dump(TextWriter tw)
		{
			string mm = string.Format("{0}: trovati {1} record", GetType().Name, _drl.Count);
			tw.WriteLine(mm);
			if (_drl.Count > 0)
				tw.WriteLine("\tStatoSessione = {0}", ((MarketSessionDR) _drl[0]).StatoSessione);
		}


		public override void Load(string contratto)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();
					using (SessioneCorrente_MarketSession rd = new SessioneCorrente_MarketSession(cn))
					{
						rd.dummy = -1;
						_drl = _drr.Read(rd.ExecuteReader());
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Load_MarketSession");
				throw;
			}
		}
	}

	public class Facade_OpenOrderDR : Facade_DRList
	{
		public override bool OnTimer(DateTime tsNow)
		{
			return false;
		}

		private static DataRecordReader _drr = null;

		static Facade_OpenOrderDR()
		{
			_drr = new DataRecordReader(typeof (OpenOrderDR));
		}

		public override void Load(string contratto)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();
					using (SessioneCorrente_OpenOrders rd = new SessioneCorrente_OpenOrders(cn))
					{
						rd.dummy = -1;
						_drl = _drr.Read(rd.ExecuteReader());
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Load_OpenOrders");
				throw;
			}
		}
	}

	public class Facade_SaldoFisicoDR : Facade_DRList
	{
		public override bool OnTimer(DateTime tsNow)
		{
			return false;
		}

		private static DataRecordReader _drr = null;

		static Facade_SaldoFisicoDR()
		{
			_drr = new DataRecordReader(typeof (SaldoFisicoDR));
		}

		public override void Load(string xml)
		{
//			string xml = "";
//			xml += "<SF>";
//			xml += "<R Op='OP1' Data='20051001' />";
//			xml += "<R Op='OP2' Data='20051002' />";
//			xml += "</SF>";

			try
			{
				using (SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring))
				{
					cn.Open();
					using (SessioneCorrente_SaldoFisico rd = new SessioneCorrente_SaldoFisico(cn))
					{
						rd.s = xml;
						_drl = _drr.Read(rd.ExecuteReader());
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				Log.smError(ex, "Load_SaldoFisico");
				throw;
			}
		}
	}

	//////////////////////////////////////////////////////////
	public class QueueItem : IComparable
	{
		public enum QueueItemType
		{
			EventoSuAbbinamentoContratto,
			EventoSuSessione
		}

		public QueueItem(QueueItemType ty, object context)
		{
			_ty = ty;
			_context = context;
		}

		private QueueItemType _ty;
		private object _context;

		public QueueItemType EventType
		{
			get { return _ty; }
		}

		public string NomeContratto
		{
			get
			{
				Debug.Assert(_ty == QueueItemType.EventoSuAbbinamentoContratto);
				return (string) _context;
			}
		}

		public int CompareTo(object obj)
		{
			// this > obj --> +1
			// this = obj -->  0
			// this < obj --> -1

			QueueItem a = this;
			QueueItem b = (QueueItem) obj;

			if (a == null && b == null) return 0;
			if (a == null && b != null) return +1;
			if (a != null && b == null) return -1;

			const QueueItemType evAbb = QueueItemType.EventoSuAbbinamentoContratto;
			const QueueItemType evSess = QueueItemType.EventoSuSessione;

			if (a.EventType == evAbb && b.EventType == evAbb)
				return string.Compare(a.NomeContratto, b.NomeContratto);

			if (a.EventType == evSess && b.EventType == evAbb)
				return +1;

			if (a.EventType == evAbb && b.EventType == evSess)
				return -1;

			return 0;
		}
	}
}