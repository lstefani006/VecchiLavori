using System;
using System.ComponentModel;
using Bipex_BLInterface;
using Bipex_Cache;
using GME.BL;

namespace Bipex_CacheBL
{

	[RemotableServer("Bipex_CacheServer", "Subscribe.rem")]
	public class Subscribe : BLBase, Bipex_BLInterface.ISubscribe
	{
		#region Costruttori ecc ecc

		private Container components = null;

		public Subscribe(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public Subscribe()
		{
			InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#endregion

		public void Subscribe_SaldoFisico(Subscribe_SaldoFisico_Data[] s)
		{
			BipexCachePublisher.G.Subscribe_SaldoFisico(s);
		}
	}
}
