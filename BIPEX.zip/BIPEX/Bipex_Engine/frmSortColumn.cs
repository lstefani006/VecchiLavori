using System.Windows.Forms;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmBookSortColumn.
	/// </summary>
	public class frmSortColumn : System.Windows.Forms.Form
	{

		private DataGridTableStyle dgtsCurrentStyle;
		private string[] HeaderTexts;
		private int[] iDataGridPosition;
		public bool bRC = false;

		private System.Windows.Forms.ListBox lbColumnList;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnUp;
		private System.Windows.Forms.Button btnDown;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSortColumn(DataGridTableStyle adgts, string[] aht, ref int[] adgpos)
		{
			dgtsCurrentStyle = adgts;
			HeaderTexts = aht;
			iDataGridPosition = adgpos;

			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSortColumn));
			this.lbColumnList = new System.Windows.Forms.ListBox();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnUp = new System.Windows.Forms.Button();
			this.btnDown = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lbColumnList
			// 
			this.lbColumnList.Location = new System.Drawing.Point(8, 8);
			this.lbColumnList.Name = "lbColumnList";
			this.lbColumnList.Size = new System.Drawing.Size(200, 225);
			this.lbColumnList.TabIndex = 0;
			this.lbColumnList.SelectedIndexChanged += new System.EventHandler(this.lbColumnList_SelectedIndexChanged);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
			this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCancel.Location = new System.Drawing.Point(149, 264);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(80, 32);
			this.btnCancel.TabIndex = 4;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnOK
			// 
			this.btnOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnOK.Image = ((System.Drawing.Image)(resources.GetObject("btnOK.Image")));
			this.btnOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnOK.Location = new System.Drawing.Point(64, 264);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(80, 32);
			this.btnOK.TabIndex = 3;
			this.btnOK.Text = "&OK";
			this.btnOK.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnUp
			// 
			this.btnUp.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnUp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnUp.Image = ((System.Drawing.Image)(resources.GetObject("btnUp.Image")));
			this.btnUp.Location = new System.Drawing.Point(216, 76);
			this.btnUp.Name = "btnUp";
			this.btnUp.Size = new System.Drawing.Size(48, 40);
			this.btnUp.TabIndex = 1;
			this.btnUp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
			// 
			// btnDown
			// 
			this.btnDown.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnDown.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnDown.Image = ((System.Drawing.Image)(resources.GetObject("btnDown.Image")));
			this.btnDown.Location = new System.Drawing.Point(216, 120);
			this.btnDown.Name = "btnDown";
			this.btnDown.Size = new System.Drawing.Size(48, 40);
			this.btnDown.TabIndex = 2;
			this.btnDown.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
			// 
			// frmSortColumn
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(292, 302);
			this.Controls.Add(this.btnDown);
			this.Controls.Add(this.btnUp);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.lbColumnList);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmSortColumn";
			this.Text = "Main Book Sort";
			this.Load += new System.EventHandler(this.frmSortColumn_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmSortColumn_Load(object sender, System.EventArgs e)
		{
			foreach (DataGridColumnStyle tmpDGCS in dgtsCurrentStyle.GridColumnStyles)
				lbColumnList.Items.Add(tmpDGCS.HeaderText);

			if (lbColumnList.Items.Count > 0)
				lbColumnList.SelectedItem = lbColumnList.Items[0];
		}

		private void lbColumnList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (lbColumnList.SelectedIndex == 0)
			{
				this.btnUp.Enabled = false;
				this.btnDown.Enabled = true;
			}
			else
			if (lbColumnList.SelectedIndex+1 == lbColumnList.Items.Count)
			{
				this.btnUp.Enabled = true;
				this.btnDown.Enabled = false;
			}
			else
			{
				this.btnUp.Enabled = true;
				this.btnDown.Enabled = true;
			}
		}

		private void btnUp_Click(object sender, System.EventArgs e)
		{
			int i = lbColumnList.SelectedIndex;
			object tmp = lbColumnList.Items[i];
			lbColumnList.Items[i] = lbColumnList.Items[i-1];
			lbColumnList.Items[i-1] = tmp;
			lbColumnList.SelectedItem = lbColumnList.Items[i-1];
		}

		private void btnDown_Click(object sender, System.EventArgs e)
		{
			int i = lbColumnList.SelectedIndex;
			object tmp = lbColumnList.Items[i];
			lbColumnList.Items[i] = lbColumnList.Items[i+1];
			lbColumnList.Items[i+1] = tmp;
			lbColumnList.SelectedItem = lbColumnList.Items[i+1];
		}

		private void btnOK_Click(object sender, System.EventArgs e)
		{

			iDataGridPosition[(int)frmBook.enPosColonneDG.Contract] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.Contract]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.Hours] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.Hours]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.BidPrice] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.BidPrice]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.BidQty] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.BidQty]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.AskPrice] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.AskPrice]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.AskQty] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.AskQty]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.LastPrice] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.LastPrice]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.LastQty] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.LastQty]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.LastTime] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.LastTime]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.MaxPrice] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.MaxPrice]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.MinPrice] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.MinPrice]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.Volume] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.Volume]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.ConvPrice] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.ConvPrice]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.OffPrice] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.OffPrice]);
			iDataGridPosition[(int)frmBook.enPosColonneDG.RefPrice] = lbColumnList.FindStringExact(HeaderTexts[(int)frmBook.enPosColonneDS.RefPrice]);

			bRC = true;
			this.Close();
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

	}
}
