#define OLD_VERSION // LEO togliere ... ora dovrebbe funzionare con tutti i tipi di proxy.
#if !OLD_VERSION
using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace NetworkSaver
{
	public class ProxyDiscover
	{
		public delegate void TestInternetConnectionEventDelegate(string msg);
		public static event TestInternetConnectionEventDelegate TestInternetConnectionEvent;


		public static string Proxy_User = null;
		public static string Proxy_Pwd = null;
		public static string Proxy_Domain = null;


		/// <summary>
		/// Stato del tentativo di connessione.
		/// </summary>
		public enum TestInternetConnectionStatus
		{
			/// <summary>
			/// connessione effettuata: superati i problemi di proxy/autenticazione proxy
			/// </summary>
			Connected,
			/// <summary>
			/// connessione effettuata ma manca l'autenticazione al proxy
			/// </summary>
			ProxyAuthenticationFailed,

			/// <summary>
			/// Connessione fallita: potrebbe essere per l'errata configurazione del proxy
			/// </summary>
			Error,

			/// <summary>
			/// L'utente si e` stufato di testare il proxy
			/// </summary>
			UserCancelled,
		}

		public class SetupProxyResult
		{
			public readonly TestInternetConnectionStatus Status;
			public readonly string Proxy_User;
			public readonly string Proxy_Pwd;
			public readonly string Proxy_Domain;

			public SetupProxyResult(TestInternetConnectionStatus Status)
				: this(Status, null)
			{
			}


			public SetupProxyResult(TestInternetConnectionStatus Status, ICredentials cred)
			{
				this.Status = Status;

				if (this.Status == TestInternetConnectionStatus.Connected)
				{
					NetworkCredential nc = cred as NetworkCredential;
					if (nc != null)
					{
						this.Proxy_User = nc.UserName;
						this.Proxy_Pwd = nc.Password;
						this.Proxy_Domain = nc.Domain;

						DESPassword des = new DESPassword("LAKUDJEU");
						Proxy_Pwd = des.Encrypt(Proxy_Pwd);
					}
				}
			}
		}


		private static TestInternetConnectionStatus TestInternetConnection(string url)
		{
			try
			{
				HttpWebRequest w = (HttpWebRequest) WebRequest.Create(url);
				w.Timeout = 5000;
				HttpWebResponse response = (HttpWebResponse) w.GetResponse();

				// Get the stream associated with the response.
				Stream receiveStream = response.GetResponseStream();

				// Pipes the stream to a higher level stream reader with the required encoding format. 
				StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);

				response.Close();
				readStream.Close();

				Log("TestInternetConnection: success");

				return TestInternetConnectionStatus.Connected;
			}
			catch (WebException e)
			{
				Log(string.Format("TestInternetConnection - WebException.Status {0}: {1}", e.Status, e.Message));

				// Display any errors. In particular, display any protocol-related error. 
				if (e.Status == WebExceptionStatus.ProtocolError)
				{
					HttpWebResponse hresp = (HttpWebResponse) e.Response;

					Log(string.Format("TestInternetConnection - Response.StatusCode {0}: {1}", hresp.StatusCode, hresp.StatusDescription));

					if (hresp.StatusCode == HttpStatusCode.ProxyAuthenticationRequired)
						return TestInternetConnectionStatus.ProxyAuthenticationFailed;
				}

				return TestInternetConnectionStatus.Error;
			}
			catch (Exception)
			{
				return TestInternetConnectionStatus.Error;
			}
		}

		private static ICredentials SetupProxyCredentials()
		{
			Proxy_User = ConfigurationSettings.AppSettings["Proxy_User"];
			Proxy_Pwd = ConfigurationSettings.AppSettings["Proxy_Pwd"];
			Proxy_Domain = ConfigurationSettings.AppSettings["Proxy_Domain"];

			if (Proxy_User == null) Proxy_User = string.Empty;
			if (Proxy_Pwd == null) Proxy_Pwd = string.Empty;
			if (Proxy_Domain == null) Proxy_Domain = string.Empty;

			if (Proxy_Pwd.Length > 0)
			{
				DESPassword des = new DESPassword("LAKUDJEU");
				Proxy_Pwd = des.Decrypt(Proxy_Pwd);
			}

			if (Proxy_User.Length > 0)
			{
				NetworkCredential nc = new NetworkCredential(Proxy_User, Proxy_Pwd);
				if (Proxy_Domain.Length > 0)
					nc.Domain = Proxy_Domain;

				return nc;
			}
			else
				return CredentialCache.DefaultCredentials;
		}


		/// <summary>
		/// Imposta il proxy per far uscire il programma dalla rete
		/// </summary>
		/// <param name="url">url da raggiungere</param>
		/// <returns>lo stato della connessione</returns>
		public static SetupProxyResult SetupProxy(string url)
		{
			try
			{
				// qui leggo le credenziali
				// Le ottengo o dal file di configurazione o
				// dalle DefaultCredentials.
				ICredentials proxyCredentials = SetupProxyCredentials();
				// le assegno al proxy di default.
				// Questo puo` essere gia` impostato a livello di file di configurazione,
				// oppure e un proxy vuoto.
				GlobalProxySelection.Select.Credentials = proxyCredentials;

				// 1) provo con le impostazioni del file di configurazione
				// o, sel nel file non esiste sezione per il proxy, con il proxy vuoto.
				TestInternetConnectionStatus tc = TestInternetConnection(url);
				if (tc == TestInternetConnectionStatus.Connected)
					return new SetupProxyResult(tc, GlobalProxySelection.Select.Credentials);

				if (tc == TestInternetConnectionStatus.ProxyAuthenticationFailed)
				{
					tc = AskCredentialsAndTestConnection(url);
					return new SetupProxyResult(tc, GlobalProxySelection.Select.Credentials);
				}

				// 2) Cerco di leggere le impostazioni del proxy da IE anche quelle dinamiche
				WebProxy wb = WinHttp.GetDynamicProxy(url);
				if (wb != null)
				{
					GlobalProxySelection.Select = wb;
					GlobalProxySelection.Select.Credentials = proxyCredentials;

					tc = TestInternetConnection(url);
					if (tc == TestInternetConnectionStatus.Connected)
						return new SetupProxyResult(tc, GlobalProxySelection.Select.Credentials);

					if (tc == TestInternetConnectionStatus.ProxyAuthenticationFailed)
					{
						tc = AskCredentialsAndTestConnection(url);
						return new SetupProxyResult(tc, GlobalProxySelection.Select.Credentials);
					}
				}

				// 3) sono alla frutta: provo con le impostazioni statiche di IE
				if (true)
				{
					// si assegna il proxy che dovrebbe funzionare a meno che 
					// IE sia impostato per leggere dinamicamente il proxy.
					GlobalProxySelection.Select = WebProxy.GetDefaultProxy();
					// ri-assegnamo le credenziali.
					GlobalProxySelection.Select.Credentials = proxyCredentials;

					tc = TestInternetConnection(url);
					if (tc == TestInternetConnectionStatus.Connected)
						return new SetupProxyResult(tc, GlobalProxySelection.Select.Credentials);
 
					if (tc == TestInternetConnectionStatus.ProxyAuthenticationFailed)
					{
						tc = AskCredentialsAndTestConnection(url);
						return new SetupProxyResult(tc, GlobalProxySelection.Select.Credentials);
					}
				}
			}
			catch (Exception)
			{
#if DEBUG
				throw;
#endif
			}

			return new SetupProxyResult(TestInternetConnectionStatus.Error);
		}

		private static TestInternetConnectionStatus AskCredentialsAndTestConnection(string url)
		{
			ICredentials proxyCredentials;
			// qui protrebbe andare ancora male: es le mie credenziali per 
			// bucare il proxy potrebbero essere errate rispetto a IE
			// in questo caso in automatico non si rieste a fare niente.
			for (;;)
			{
				proxyCredentials = AskCredentials();
				if (proxyCredentials == null)
					return TestInternetConnectionStatus.UserCancelled;
				
				GlobalProxySelection.Select.Credentials = proxyCredentials;

				TestInternetConnectionStatus tc = TestInternetConnection(url);

				if (tc == TestInternetConnectionStatus.Connected)
					return tc;

				if (tc == TestInternetConnectionStatus.Error)
					return tc;

				MessageBox.Show("Proxy authentication failure.", "Network communication error.");
			}
		}

		public delegate ICredentials AskCredentialsFormDelegate();
		public static AskCredentialsFormDelegate AskCredentialsForm;

		private static ICredentials AskCredentials()
		{
			if (AskCredentialsForm != null)
				return AskCredentialsForm();

			/*
			frmLogin.rcFrmLogin r = new frmLogin.rcFrmLogin();
			frmLogin f = new frmLogin(frmLogin.enDialogMode.LoginUserPasswordNotVisibleDomain, ref r);
			f.ShowDialog();
	
			if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
			{
				NetworkCredential nc =  new NetworkCredential(r.user, r.password);
				if (r.domain != null && r.domain.Length > 0)
					nc.Domain = r.domain;
				return nc;
			}
			*/

			return null;
		}


		internal static void Log(string msg)
		{
			try
			{
				if (TestInternetConnectionEvent != null)
					TestInternetConnectionEvent(msg);
			}
			catch
			{
			}
		}


	}


	public class WinHttp
	{
		private WinHttp() {}

		#region Funzioni/Strutture WinHttp

		/// <summary>
		/// The WinHttpOpen function initializes an application's use of the WinHTTP functions and returns a WinHTTP-session handle.
		/// </summary>
		/// <param name="pwszUserAgent">[in] Pointer to a string variable that contains the name of the application or entity calling the WinHTTP functions. This name is used as the user agent in the HTTP protocol.</param>
		/// <param name="dwAccessType">[in] Type of access required. This can be one of the following values: Value Meaning WINHTTP_ACCESS_TYPE_NO_PROXY, WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_ACCESS_TYPE_NAMED_PROXY</param>
		/// <param name="pwszProxyName">[in] Pointer to a string variable that contains the name of the proxy server to use when proxy access is specified by setting dwAccessType to WINHTTP_ACCESS_TYPE_NAMED_PROXY. The WinHTTP functions recognize only CERN type proxies for HTTP. If dwAccessType is not set to WINHTTP_ACCESS_TYPE_NAMED_PROXY, this parameter must be set to WINHTTP_NO_PROXY_NAME.</param>
		/// <param name="pwszProxyBypass">[in] Pointer to a string variable that contains an optional list of host names or Internet Protocol (IP) addresses, or both, that should not be routed through the proxy when dwAccessType is set to WINHTTP_ACCESS_TYPE_NAMED_PROXY. The list can contain wildcards. Do not use an empty string, because the WinHttpOpen function uses it as the proxy bypass list. If this parameter specifies the local macro as the only entry, this function bypasses any host name that does not contain a period. If dwAccessType is not set to WINHTTP_ACCESS_TYPE_NAMED_PROXY, this parameter must be set to WINHTTP_NO_PROXY_BYPASS.</param>
		/// <param name="dwFlags">[in] Unsigned long integer value that contains the flags that indicate various options affecting the behavior of this function. This parameter can have the following value: WINHTTP_FLAG_ASYNC</param>
		/// <returns>Returns a valid session handle if successful, or NULL if not. </returns>
		[DllImport("winhttp.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		public static extern IntPtr WinHttpOpen(
			string pwszUserAgent,
			uint dwAccessType,
			IntPtr pwszProxyName,
			IntPtr pwszProxyBypass,
			uint dwFlags
			);

		public static readonly uint WINHTTP_ACCESS_TYPE_DEFAULT_PROXY = 0;
		public static readonly uint WINHTTP_ACCESS_TYPE_NO_PROXY = 1;
		public static readonly uint WINHTTP_ACCESS_TYPE_NAMED_PROXY = 3;


		[DllImport("winhttp.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		public static extern bool WinHttpCloseHandle(IntPtr hInternet);

		[DllImport("winhttp.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		public static extern bool WinHttpGetProxyForUrl(
			IntPtr hSession,
			string lpcwszUrl,
			ref WINHTTP_AUTOPROXY_OPTIONS pAutoProxyOptions,
			ref WINHTTP_PROXY_INFO pProxyInfo
			);

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
			public struct WINHTTP_AUTOPROXY_OPTIONS
		{
			[MarshalAs(UnmanagedType.U4)] public int dwFlags;
			[MarshalAs(UnmanagedType.U4)] public int dwAutoDetectFlags;
			public string lpszAutoConfigUrl;
			public IntPtr lpvReserved;
			[MarshalAs(UnmanagedType.U4)] public int dwReserved;
			public bool fAutoLoginIfChallenged;
		}

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
			public struct WINHTTP_PROXY_INFO
		{
			[MarshalAs(UnmanagedType.U4)] public int dwAccessType;
			public string lpszProxy;
			public string lpszProxyBypass;
		}

		public static readonly IntPtr WINHTTP_NO_PROXY_NAME = IntPtr.Zero;
		public static readonly IntPtr WINHTTP_NO_PROXY_BYPASS = IntPtr.Zero;


		public static readonly int WINHTTP_AUTOPROXY_AUTO_DETECT = 0x00000001;
		public static readonly int WINHTTP_AUTOPROXY_CONFIG_URL = 0x00000002;
		public static readonly int WINHTTP_AUTOPROXY_RUN_INPROCESS = 0x00010000;
		public static readonly int WINHTTP_AUTOPROXY_RUN_OUTPROCESS_ONLY = 0x00020000;
		public static readonly int WINHTTP_AUTO_DETECT_TYPE_DHCP = 0x00000001;
		public static readonly int WINHTTP_AUTO_DETECT_TYPE_DNS_A = 0x00000002;


		/// <summary>
		/// The WinHttpGetIEProxyConfigForCurrentUser function obtains the Internet Explorer proxy configuration for the current user.
		/// </summary>
		/// <remarks>In Internet Explorer, the proxy settings are found on the Connections tab of the Tools / Internet Options menu option. 
		/// Proxy settings are configured on a per-connection basis; that is, the proxy settings for a LAN connection are separate from those for a dial-up or VPN connection. 
		/// WinHttpGetIEProxyConfigForCurrentUser returns the proxy settings for the current active connection.
		/// This function is useful in client applications running in network environments in which the Web Proxy Auto-Discovery (WPAD) protocol 
		/// is not implemented (meaning that no Proxy Auto-Configuration file is available). 
		/// If a PAC file is not available, then the WinHttpGetProxyForUrl function fails. 
		/// The WinHttpGetIEProxyConfigForCurrentUser function can be used as a fall-back mechanism to discover a workable proxy configuration 
		/// by retrieving the user�s proxy configuration in Internet Explorer.
		/// This function should not be used in a service process that does not impersonate a logged-on user.
		/// </remarks>
		/// <param name="ProxyConfig">[in, out] On input, is a pointer to a WINHTTP_CURRENT_USER_IE_PROXY_CONFIG structure. On output, the structure contains the Internet Explorer proxy settings for the current active network connection (for example, LAN, dial-up, or VPN connection).</param>
		/// <returns></returns>
		[DllImport("winhttp.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		public static extern bool WinHttpGetIEProxyConfigForCurrentUser(
			ref WINHTTP_CURRENT_USER_IE_PROXY_CONFIG ProxyConfig
			);

		/// <summary>
		/// The WINHTTP_CURRENT_USER_IE_PROXY_CONFIG structure contains the Internet Explorer proxy configuration information.
		/// </summary>
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
			public struct WINHTTP_CURRENT_USER_IE_PROXY_CONFIG
		{
			/// <summary>
			/// If TRUE, indicates that the Internet Explorer proxy configuration for the current user specifies "automatically detect settings"
			/// </summary>
			public bool fAutoDetect;

			/// <summary>
			/// Pointer to a null-terminated Unicode string that contains the auto-configuration URL if the Internet Explorer proxy configuration for the current user specifies "Use automatic proxy configuration"
			/// </summary>
			public string lpszAutoConfigUrl;

			/// <summary>
			/// Pointer to a null-terminated Unicode string that contains the proxy URL if the Internet Explorer proxy configuration for the current user specifies "use a proxy server"
			/// </summary>
			public string lpszProxy;

			/// <summary>
			/// Pointer to a null-terminated Unicode string that contains the optional proxy by-pass server list.
			/// </summary>
			public string lpszProxyBypass;
		}

		#endregion

		#region Codici di Errore

		/// <summary>
		/// Returned by WinHttpGetProxyForUrl when a proxy for the specified URL cannot be located. 
		/// </summary>
		public const int ERROR_WINHTTP_AUTO_PROXY_SERVICE_ERROR = 12178;

		/// <summary>
		/// Returned by WinHttpDetectAutoProxyConfigUrl if WinHTTP was unable to discover the URL of the Proxy Auto-Configuration (PAC) file. 
		/// </summary>
		public const int ERROR_WINHTTP_AUTODETECTION_FAILED = 12180;

		/// <summary
		/// An error occurred executing the script code in the Proxy Auto-Configuration (PAC) file. 
		/// </summary>
		public const int ERROR_WINHTTP_BAD_AUTO_PROXY_SCRIPT = 12166;

		/// <summary>
		/// Returned by the HttpRequest object if a specified option cannot be requested after the Open method has been called. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CALL_AFTER_OPEN = 12103;

		/// <summary>
		/// Returned by the HttpRequest object if a requested operation cannot be performed after calling the Send method. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CALL_AFTER_SEND = 12102;

		/// <summary>
		/// Returned by the HttpRequest object if a requested operation cannot be performed before calling the Open method. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CALL_BEFORE_OPEN = 12100;

		/// <summary>
		/// Returned by the HttpRequest object if a requested operation cannot be performed before calling the Send method. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CALL_BEFORE_SEND = 12101;

		/// <summary>
		/// Returned if connection to the server failed. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CONNECT = 12029;

		/// <summary>
		/// Returned by WinHttpReceiveResponse when an overflow condition is encountered in the course of parsing chunked encoding. 
		/// </summary>
		public const int ERROR_WINHTTP_CHUNKED_ENCODING_HEADER_SIZE_OVERFLOW = 12183;

		/// <summary>
		/// Returned by WinHttpReceiveResponse when the server requests client authentication. 
		/// </summary>
		public const int ERROR_WINHTTP_CLIENT_AUTH_CERT_NEEDED = 12044;

		/// <summary>
		/// The connection with the server has been reset or terminated, or an incompatible SSL protocol was encountered. For example, WinHTTP version 5.1 does not support SSL2 unless the client specifically enables it. 
		/// </summary>
		public const int ERROR_WINHTTP_CONNECTION_ERROR = 12030;

		/// <summary>
		/// Obsolete; no longer used. 
		/// </summary>
		public const int ERROR_WINHTTP_HEADER_ALREADY_EXISTS = 12155;

		/// <summary>
		/// Returned by WinHttpReceiveResponse when a larger number of headers were present in a response than WinHTTP could receive. 
		/// </summary>
		public const int ERROR_WINHTTP_HEADER_COUNT_EXCEEDED = 12181;

		/// <summary>
		/// The requested header could not be located. 
		/// </summary>
		public const int ERROR_WINHTTP_HEADER_NOT_FOUND = 12150;

		/// <summary>
		/// Returned by WinHttpReceiveResponse when the size of headers received exceeds the limit for the request handle. 
		/// </summary>
		public const int ERROR_WINHTTP_HEADER_SIZE_OVERFLOW = 12182;

		/// <summary>
		/// The requested operation cannot be carried out because the handle supplied is not in the correct state. 
		/// </summary>
		public const int ERROR_WINHTTP_INCORRECT_HANDLE_STATE = 12019;

		/// <summary>
		/// The type of handle supplied is incorrect for this operation. 
		/// </summary>
		public const int ERROR_WINHTTP_INCORRECT_HANDLE_TYPE = 12018;

		/// <summary>
		/// An internal error has occurred. 
		/// </summary>
		public const int ERROR_WINHTTP_INTERNAL_ERROR = 12004;

		/// <summary>
		/// A request to WinHttpQueryOption or WinHttpSetOption specified an invalid option value. 
		/// </summary>
		public const int ERROR_WINHTTP_INVALID_OPTION = 12009;

		/// <summary>
		/// Obsolete; no longer used. 
		/// </summary>
		public const int ERROR_WINHTTP_INVALID_QUERY_REQUEST = 12154;

		/// <summary>
		/// The server response could not be parsed. 
		/// </summary>
		public const int ERROR_WINHTTP_INVALID_SERVER_RESPONSE = 12152;

		/// <summary>
		/// The URL is invalid. 
		/// </summary>
		public const int ERROR_WINHTTP_INVALID_URL = 12005;

		/// <summary>
		/// The login attempt failed. When this error is encountered, the request handle should be closed with WinHttpCloseHandle. A new request handle must be created before retrying the function that originally produced this error. 
		/// </summary>
		public const int ERROR_WINHTTP_LOGIN_FAILURE = 12015;

		/// <summary>
		/// The server name could not be resolved. 
		/// </summary>
		public const int ERROR_WINHTTP_NAME_NOT_RESOLVED = 12007;

		/// <summary>
		/// Obsolete; no longer used. 
		/// </summary>
		public const int ERROR_WINHTTP_NOT_INITIALIZED = 12172;

		/// <summary>
		/// The operation was canceled, usually because the handle on which the request was operating was closed before the operation completed. 
		/// </summary>
		public const int ERROR_WINHTTP_OPERATION_CANCELLED = 12017;

		/// <summary>
		/// The requested option cannot be set, only queried. 
		/// </summary>
		public const int ERROR_WINHTTP_OPTION_NOT_SETTABLE = 12011;

		/// <summary>
		/// Obsolete; no longer used. 
		/// </summary>
		public const int ERROR_WINHTTP_OUT_OF_HANDLES = 12001;

		/// <summary>
		/// Returned by WinHttpSendRequest on Windows Server 2003 family if an HTTP status code of 407 is returned, which indicates that proxy authentication is required. This error was added to handle the case where the client is trying to establish an SSL connection to a target server via a proxy server, but the proxy server requires authentication. 
		/// This error is not returned on Windows XP SP1 and Windows 2000 SP3, which leaves the client unaware that the SSL connection failed. In this case, a subsequent call to WinHttpWriteData to send some POST data, or to WinHttpReceiveResponse to get the response, fails with an INCORRECT_HANDLE_STATE error.
		/// </summary>
		public const int ERROR_WINHTTP_PROXY_AUTH_REQUIRED = 12185;

		/// <summary>
		/// The redirection failed because either the scheme changed or all attempts made to redirect failed (default is five attempts). 
		/// </summary>
		public const int ERROR_WINHTTP_REDIRECT_FAILED = 12156;

		/// <summary>
		/// The WinHTTP function failed. The desired function can be retried on the same request handle. 
		/// </summary>
		public const int ERROR_WINHTTP_RESEND_REQUEST = 12032;

		/// <summary>
		/// Returned when an incoming response exceeds an internal WinHTTP size limit. 
		/// </summary>
		public const int ERROR_WINHTTP_RESPONSE_DRAIN_OVERFLOW = 12184;

		/// <summary>
		/// Returned when a certificate's CN name does not match the passed value (equivalent to a CERT_E_CN_NO_MATCH error). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_CN_INVALID = 12038;

		/// <summary>
		/// Indicates that a required certificate is not within its validity period when verifying against the current system clock or the timestamp in the signed file, or that the validity periods of the certification chain do not nest correctly (equivalent to a CERT_E_EXPIRED or a CERT_E_VALIDITYPERIODNESTING error). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_DATE_INVALID = 12037;

		/// <summary>
		/// Indicates that revocation could not be checked because the revocation server was offline (equivalent to CRYPT_E_REVOCATION_OFFLINE). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_REV_FAILED = 12057;

		/// <summary>
		/// Indicates that a certificate has been revoked (equivalent to CRYPT_E_REVOKED). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_REVOKED = 12170;

		/// <summary>
		/// Indicates that a certificate is not valid for the requested usage (equivalent to CERT_E_WRONG_USAGE). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_WRONG_USAGE = 12179;

		/// <summary>
		/// Indicates that an error occurred having to do with a secure channel (equivalent to error codes that begin with "SEC_E_" and "SEC_I_" listed in the winerror.h header file ). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CHANNEL_ERROR = 12157;

		/// <summary>
		/// One or more errors were found in the Secure Sockets Layer (SSL) certificate sent by the server. To determine what type of error was encountered, check for a WINHTTP_CALLBACK_STATUS_SECURE_FAILURE notification in a status callback function. For more information, see WINHTTP_STATUS_CALLBACK. 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_FAILURE = 12175;

		/// <summary>
		/// Indicates that a certificate chain was processed but terminated in a root certificate that is not trusted by the trust provider (equivalent to CERT_E_UNTRUSTEDROOT). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_INVALID_CA = 12045;

		/// <summary>
		/// Indicates that a certificate is invalid (equivalent to errors such as CERT_E_ROLE, CERT_E_PATHLENCONST, CERT_E_CRITICAL, CERT_E_PURPOSE, CERT_E_ISSUERCHAINING, CERT_E_MALFORMED and CERT_E_CHAINING). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_INVALID_CERT = 12169;

		/// <summary>
		/// The WinHTTP function support is being shut down or unloaded. 
		/// </summary>
		public const int ERROR_WINHTTP_SHUTDOWN = 12012;

		/// <summary>
		/// The request has timed out. 
		/// </summary>
		public const int ERROR_WINHTTP_TIMEOUT = 12002;

		/// <summary>
		/// The PAC file could not be downloaded. For example, the server referenced by the PAC URL may not have been reachable, or the server returned a 404 NOT FOUND response. 
		/// </summary>
		public const int ERROR_WINHTTP_UNABLE_TO_DOWNLOAD_SCRIPT = 12167;

		/// <summary>
		/// The URL specified a scheme other than "http:" or "https:". 
		/// </summary>
		public const int ERROR_WINHTTP_UNRECOGNIZED_SCHEME = 12006;
		/*
			ERROR_NOT_ENOUGH_MEMORY 
			Not enough memory was available to complete the requested operation. (Windows error code) 
			ERROR_INSUFFICIENT_BUFFER 
			The size of the buffer supplied to a function was insufficient to contain the returned data. The number of bytes required is usually returned in the buffer size parameter. See the specific function for details. (Windows error code) 
			ERROR_INVALID_HANDLE 
			The handle that was passed to the application programming interface (API) has been either invalidated or closed. (Windows error code) 
			ERROR_NO_MORE_FILES 
			No more files have been found. (Windows error code) 
			ERROR_NO_MORE_ITEMS 
			No more items have been found. (Windows error code) 
			ERROR_NOT_SUPPORTED 
			The required protocol stack is not loaded and the application cannot start WinSock. 
			*/

		#endregion

		public class ProxyInfo
		{
			public bool active;
			public string proxy;
			public string proxyBypass;
		}


		/// <summary>
		/// Prova a costruire un Proxy leggendo le impostazioni da IE.
		/// Se IE e` impostato con un proxy dinamico (script .pac)
		/// la funzione si collega al sito per determinare l'effettivo
		/// proxy da usare.
		/// Se la funzione NON riesce a determinare il proxy ritorna null.
		/// Se ci riesce ritorna il proxy.
		/// Notare che non bastano le informazioni del Proxy per connettersi al WEB:
		/// Bisogna poi agganciare al GlobalProxySelection anche le credenziali per l'accesso in rete.
		/// Questa funzione usa WinHttp.
		/// </summary>
		/// <param name="Url">l'url da raggiungere</param>
		/// <returns>il proxy da usare per raggiungere l'url</returns>
		public static WebProxy GetDynamicProxy(string Url)
		{
			try
			{
				WINHTTP_AUTOPROXY_OPTIONS AutoProxyOptions = new WINHTTP_AUTOPROXY_OPTIONS();
				AutoProxyOptions.fAutoLoginIfChallenged = true;

				bool fDoAutoProxy = false;

				// Check IE's proxy configuration
				WINHTTP_CURRENT_USER_IE_PROXY_CONFIG IEProxyConfig = new WINHTTP_CURRENT_USER_IE_PROXY_CONFIG();
				IEProxyConfig.fAutoDetect = false;
				bool result = WinHttpGetIEProxyConfigForCurrentUser(ref IEProxyConfig);
				if (result)
				{
					// if IE is configured to auto-detect, then we will too
					if (IEProxyConfig.fAutoDetect)
					{
						AutoProxyOptions.dwFlags = WINHTTP_AUTOPROXY_AUTO_DETECT;
						AutoProxyOptions.dwAutoDetectFlags = WINHTTP_AUTO_DETECT_TYPE_DHCP | WINHTTP_AUTO_DETECT_TYPE_DNS_A;
						fDoAutoProxy = true;
					}

					// if IE is configured to use an auto-config script, then we will use it too 
					if (IEProxyConfig.lpszAutoConfigUrl != null)
					{
						AutoProxyOptions.dwFlags = AutoProxyOptions.dwFlags | WINHTTP_AUTOPROXY_CONFIG_URL;
						AutoProxyOptions.lpszAutoConfigUrl = IEProxyConfig.lpszAutoConfigUrl;
						fDoAutoProxy = true;
					}
				}
				else
				{
					// if the IE proxy config is not available, then we will try auto-detection 
					AutoProxyOptions.dwFlags = WINHTTP_AUTOPROXY_AUTO_DETECT;
					AutoProxyOptions.dwAutoDetectFlags = WINHTTP_AUTO_DETECT_TYPE_DHCP | WINHTTP_AUTO_DETECT_TYPE_DNS_A;
					fDoAutoProxy = true;
				}

				string ProxyString = null;

				if (fDoAutoProxy)
				{
					// Need to create a temporary WinHttp session handle 
					// Note: performance of this GetProxyInfoForUrl function can be 
					// improved by saving this hSession handle across calls 
					// instead of creating a new handle each time 
					IntPtr hSession = IntPtr.Zero;

					try
					{
						hSession = WinHttpOpen(null, 1, IntPtr.Zero, IntPtr.Zero, 0);

						WINHTTP_PROXY_INFO WinHttpProxyInfo = new WINHTTP_PROXY_INFO();

						if (WinHttpGetProxyForUrl(hSession, Url, ref AutoProxyOptions, ref WinHttpProxyInfo))
						{
							ProxyString = WinHttpProxyInfo.lpszProxy;
							// ignore WinHttpProxyInfo.lpszProxyBypass, it will not be set 
						}
						else
						{
							int e = Marshal.GetLastWin32Error();
							string msg;
							switch (e)
							{
								case ERROR_WINHTTP_AUTODETECTION_FAILED:
									msg = "Returned by WinHttpDetectAutoProxyConfigUrl if WinHTTP was unable to discover the URL of the Proxy Auto-Configuration (PAC) file";
									break;
								case ERROR_WINHTTP_AUTO_PROXY_SERVICE_ERROR:
									msg = "Returned by WinHttpGetProxyForUrl when a proxy for the specified URL cannot be located. ";
									break;
								case ERROR_WINHTTP_BAD_AUTO_PROXY_SCRIPT:
									msg = "An error occurred executing the script code in the Proxy Auto-Configuration (PAC) file. ";
									break;
								case ERROR_WINHTTP_INCORRECT_HANDLE_TYPE:
									msg = "The type of handle supplied is incorrect for this operation.  ";
									break;
								case ERROR_WINHTTP_INTERNAL_ERROR:
									msg = "An internal error has occurred.  ";
									break;
								case ERROR_WINHTTP_INVALID_URL:
									msg = "The URL is invalid.  ";
									break;
								case ERROR_WINHTTP_LOGIN_FAILURE:
									msg = "The login attempt failed. When this error is encountered, close the request handle with WinHttpCloseHandle. A new request handle must be created before retrying the function that originally produced this error.  ";
									break;
								case ERROR_WINHTTP_OPERATION_CANCELLED:
									msg = "The operation was canceled, usually because the handle on which the request was operating was closed before the operation completed.  ";
									break;
								case ERROR_WINHTTP_UNABLE_TO_DOWNLOAD_SCRIPT:
									msg = "The PAC file could not be downloaded. For example, the server referenced by the PAC URL may not have been reachable, or the server returned a 404 NOT FOUND response.  ";
									break;
								case ERROR_WINHTTP_UNRECOGNIZED_SCHEME:
									msg = "The URL of the PAC file specified a scheme other than \"http:\" or \"https:\".  ";
									break;
									//case WinHttp.ERROR_NOT_ENOUGH_MEMORY: msg = "Not enough memory "; break;
								default:
									msg = e.ToString();
									break;

							}
							ProxyDiscover.Log(msg);
						}
					}
					finally
					{
						if (hSession != IntPtr.Zero)
							WinHttpCloseHandle(hSession);
					}
				}


				// If we don't have a proxy server from WinHttpGetProxyForUrl, 
				// then pick one up from the IE proxy config (if given) 
				if (ProxyString == null)
					ProxyString = IEProxyConfig.lpszProxy;


				ProxyInfo ret = new ProxyInfo();


				// If there's a proxy string, convert it to a Basic string 
				if (ProxyString != null)
				{
					ret.proxy = ProxyString;
					ret.active = true;
				}


				// Pick up any bypass string from the IEProxyConfig 
				if (IEProxyConfig.lpszProxyBypass != null)
					ret.proxyBypass = IEProxyConfig.lpszProxyBypass;

				/*
					Con Automatically detect settings
					e Use automatic configuration script impostata ad un server con file .pac
					si ha
						ret.active = true;
						ret.proxy = "172.19.0.32:80"
						ret.proxyBypass = null
					
				
					con Use proxy server for your LAN (this settings will not apply to dial-up or VPN connections)
					si ha
						ret.active = true;
						ret.proxy = "msproxy.elsag.it:80"
						ret.proxyBypass = "*.elsag.it;192.168.200.*;<local>"
				
					*/

				WebProxy webProxy = null;

				if (ret.active)
				{
					webProxy = new WebProxy();

					string url = null;
					int port = -1;

					if (true)
					{
						string[] s = ret.proxy.Split(':');
						if (s.Length >= 1)
							url = s[0];
						if (s.Length >= 2)
							port = int.Parse(s[1]);
					}

					webProxy = new WebProxy(url, port);


					if (ret.proxyBypass != null)
					{
						string[] by = ret.proxyBypass.Split(';');
						ArrayList a = new ArrayList();
						for (int i = 0; i < by.Length; ++i)
						{
							string s = by[i];
							if (s != "<local>")
							{
								s = s.Replace("*", "[a-zA-Z0-9_]+");
								s = s.Replace(".", "\\.");
								a.Add(s);
							}
						}

						webProxy.BypassList = (string[]) a.ToArray(typeof (string));
					}
				}

				return webProxy;
			}
			catch
			{
				return null;
			}

		}
	}

	public class DESPassword
	{
		private readonly DESCryptoServiceProvider _des;
		private readonly byte[] _key;

		/// <summary>
		/// Costruttore di default. 
		/// Imposta la chiave di codifica/decodifica, la modalita` di cifra
		/// e il paddingMode di default.
		/// </summary>
		public DESPassword(string secretKey)
		{
			_des = new DESCryptoServiceProvider();

			_key = Encoding.UTF8.GetBytes(secretKey);
			_des.Mode = CipherMode.ECB;
			_des.Padding = PaddingMode.Zeros;
		}

		/// <summary>
		/// Codifica una stringa con l'algoritmo DES.
		/// </summary>
		/// <param name="stringToEncrypt">La stringa da codificare</param>
		/// <returns>La stringa codificata in formato esadecimale</returns>
		public string Encrypt (string stringToEncrypt)
		{
			byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream (ms, _des.CreateEncryptor(_key, null), CryptoStreamMode.Write);
			cs.Write(inputByteArray, 0, inputByteArray.Length );
			cs.FlushFinalBlock();
			return ConvertBinaryToHexString(ms.ToArray());
		}

		/// <summary>
		/// Decodifica una stringa con l'algoritmo DES, togliendo eventuali caratteri '\0' di
		/// padding
		/// </summary>
		/// <param name="stringToDecrypt">La stringa da decodificare in formato esadecimale</param>
		/// <returns>La stringa decodificata</returns>
		public string Decrypt (string stringToDecrypt)
		{
			byte[] inputByteArray = ConvertHexStringToBinary(stringToDecrypt);
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream (ms, _des.CreateDecryptor(_key, null), CryptoStreamMode.Write);
			cs.Write(inputByteArray, 0, inputByteArray.Length );
			cs.FlushFinalBlock();
			string sz = Encoding.UTF8.GetString(ms.ToArray());
			//
			// rimuove i caratteri '\0' dalla stringa 
			// L'encrypt e' fatto di solito con carattere '\0' di padding, e il decrypt
			// ritorna una stringa con gli stessi caratteri '\0' di padding, che ovviamente
			// e' meglio rimuovere 
			//
			string szTrimmed =  sz.TrimEnd('\0');
			return szTrimmed;

		}

	
		protected static string ConvertBinaryToHexString (byte[] bData)
		{
			StringBuilder sHex = new StringBuilder(2 * bData.Length);
			for (int i=0; i<bData.Length; i++)
				sHex.AppendFormat("{0:X2}", bData[i]);
			return sHex.ToString();
		}

		protected static byte[] ConvertHexStringToBinary (string sData)
		{
			int iByte = sData.Length/2;
			byte [] bytevar = new byte[iByte];
			for (int i=0; i<iByte; i++)
				bytevar[i] = Convert.ToByte(sData.Substring(i*2,  2), 16);
			return bytevar;
		}
	}

}

#else

using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace NetworkSaver
{
	public class ProxyDiscover
	{
		public delegate void TestInternetConnectionEventDelegate(string msg);
		public static event TestInternetConnectionEventDelegate TestInternetConnectionEvent;

		/// <summary>
		/// Stato del tentativo di connessione.
		/// </summary>
		public enum TestInternetConnectionStatus
		{
			/// <summary>
			/// connessione effettuata: superati i problemi di proxy/autenticazione proxy
			/// </summary>
			Connected,
			/// <summary>
			/// connessione effettuata ma manca l'autenticazione al proxy
			/// </summary>
			ProxyAuthenticationFailed,

			/// <summary>
			/// Connessione fallita: potrebbe essere per l'errata configurazione del proxy
			/// </summary>
			Error,
		}


		private static TestInternetConnectionStatus TestInternetConnection(string url)
		{
			try
			{
				HttpWebRequest w = (HttpWebRequest) WebRequest.Create(url);
				HttpWebResponse response = (HttpWebResponse) w.GetResponse();

				// Get the stream associated with the response.
				Stream receiveStream = response.GetResponseStream();

				// Pipes the stream to a higher level stream reader with the required encoding format. 
				StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8);

				response.Close();
				readStream.Close();

				Log("TestInternetConnection: success");

				return TestInternetConnectionStatus.Connected;
			}
			catch (WebException e)
			{
				Log(string.Format("TestInternetConnection - WebException.Status {0}: {1}", e.Status, e.Message));

				// Display any errors. In particular, display any protocol-related error. 
				if (e.Status == WebExceptionStatus.ProtocolError)
				{
					HttpWebResponse hresp = (HttpWebResponse) e.Response;

					Log(string.Format("TestInternetConnection - Response.StatusCode {0}: {1}", hresp.StatusCode, hresp.StatusDescription));

					if (hresp.StatusCode == HttpStatusCode.ProxyAuthenticationRequired)
						return TestInternetConnectionStatus.ProxyAuthenticationFailed;
				}

				return TestInternetConnectionStatus.Error;
			}
			catch (Exception)
			{
				return TestInternetConnectionStatus.Error;
			}
		}

		private static ICredentials SetupProxyCredentials()
		{
			string Proxy_User = ConfigurationSettings.AppSettings["Proxy_User"];
			string Proxy_Pwd = ConfigurationSettings.AppSettings["Proxy_Pwd"];
			string Proxy_Domain = ConfigurationSettings.AppSettings["Proxy_Domain"];

			if (Proxy_User == null)   Proxy_User = string.Empty;
			if (Proxy_Pwd == null)    Proxy_Pwd = string.Empty;
			if (Proxy_Domain == null) Proxy_Domain = string.Empty;

			if (Proxy_User.Length > 0 && Proxy_Pwd.Length > 0)
			{
				NetworkCredential nc = new NetworkCredential(Proxy_User, Proxy_Pwd);
				if (Proxy_Domain.Length > 0)
					nc.Domain = Proxy_Domain;

				return nc;
			}
			else
				return CredentialCache.DefaultCredentials;
		}


		/// <summary>
		/// Imposta il GlobalProxySelection in modo da far uscire l'applicativo
		/// in internet.
		/// Le credenziali per il proxy sono prese dal CredentialCache.DefaultCredentials o
		/// dal file di configurazione voci Proxy_*.
		/// </summary>
		/// <param name="url">url dell'applicazione da raggiungere</param>
		/// <returns>lo stato di connessione</returns>
		public static TestInternetConnectionStatus SetupProxy(string url)
		{
			// magari e` gia` tutto configurato correttamente
			// anche senza settare le credenziali
			TestInternetConnectionStatus tc = TestInternetConnection(url);
			if (tc == TestInternetConnectionStatus.Connected)
				return tc;


			// per prima cosa si leggono le impostazioni dal file di configurazione
			// per le credenziali di accesso al proxy.
			ICredentials proxyCredentials = SetupProxyCredentials();

			// si assegna il proxy che dovrebbe funzionare a meno che 
			// IE sia impostato per leggere dinamicamente il proxy.
			GlobalProxySelection.Select = WebProxy.GetDefaultProxy();

			// assegnamo le credenziali.
			GlobalProxySelection.Select.Credentials = proxyCredentials;

			// primo test: puo` fallire
			// 1) perche` non trova il proxy
			// 2) perche` non ha le credenziali di accesso al proxy giuste
			// 3) per un errore che non si riesce a "domare"
			tc = TestInternetConnection(url);

			if (tc == TestInternetConnectionStatus.Connected)
				return tc;

			if (tc == TestInternetConnectionStatus.ProxyAuthenticationFailed)
			{
				// e` gia` buono il proxy risponde buttandoci fuori: 
				// Mancano le credenziali.
				return tc;
			}


			// non sono riuscito a connettermi.... provo un WinHttp
			// qui provo a usare le funzioni WinHttp per uscire in internet
			// se va tutto bene mi ritorna un altro proxy
			WebProxy wb = WinHttp.GetDynamicProxy(url);
			if (wb != null)
			{
				// abbiamo un proxy ( dinamico ti rendi conto del miracolo ? ) 
				// riassegnamo il malloppo e ci riproviamo.

				GlobalProxySelection.Select = wb;
				GlobalProxySelection.Select.Credentials = proxyCredentials;

				tc = TestInternetConnection(url);
				// qui protrebbe andare ancora male: es le mie credenziali per 
				// bucare il proxy potrebbero essere errate rispetto a IE
				// in questo caso in automatico non si rieste a fare niente.
			}

			return tc;
		}


		internal static void Log(string msg)
		{
			try
			{
				if (TestInternetConnectionEvent != null)
					TestInternetConnectionEvent(msg);
			}
			catch
			{
			}
		}


	}


	public class WinHttp
	{
		private WinHttp() {}

		#region Funzioni/Strutture WinHttp

		/// <summary>
		/// The WinHttpOpen function initializes an application's use of the WinHTTP functions and returns a WinHTTP-session handle.
		/// </summary>
		/// <param name="pwszUserAgent">[in] Pointer to a string variable that contains the name of the application or entity calling the WinHTTP functions. This name is used as the user agent in the HTTP protocol.</param>
		/// <param name="dwAccessType">[in] Type of access required. This can be one of the following values: Value Meaning WINHTTP_ACCESS_TYPE_NO_PROXY, WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_ACCESS_TYPE_NAMED_PROXY</param>
		/// <param name="pwszProxyName">[in] Pointer to a string variable that contains the name of the proxy server to use when proxy access is specified by setting dwAccessType to WINHTTP_ACCESS_TYPE_NAMED_PROXY. The WinHTTP functions recognize only CERN type proxies for HTTP. If dwAccessType is not set to WINHTTP_ACCESS_TYPE_NAMED_PROXY, this parameter must be set to WINHTTP_NO_PROXY_NAME.</param>
		/// <param name="pwszProxyBypass">[in] Pointer to a string variable that contains an optional list of host names or Internet Protocol (IP) addresses, or both, that should not be routed through the proxy when dwAccessType is set to WINHTTP_ACCESS_TYPE_NAMED_PROXY. The list can contain wildcards. Do not use an empty string, because the WinHttpOpen function uses it as the proxy bypass list. If this parameter specifies the local macro as the only entry, this function bypasses any host name that does not contain a period. If dwAccessType is not set to WINHTTP_ACCESS_TYPE_NAMED_PROXY, this parameter must be set to WINHTTP_NO_PROXY_BYPASS.</param>
		/// <param name="dwFlags">[in] Unsigned long integer value that contains the flags that indicate various options affecting the behavior of this function. This parameter can have the following value: WINHTTP_FLAG_ASYNC</param>
		/// <returns>Returns a valid session handle if successful, or NULL if not. </returns>
		[DllImport("winhttp.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		public static extern IntPtr WinHttpOpen(
			string pwszUserAgent,
			uint dwAccessType,
			IntPtr pwszProxyName,
			IntPtr pwszProxyBypass,
			uint dwFlags
			);

		public static readonly uint WINHTTP_ACCESS_TYPE_DEFAULT_PROXY = 0;
		public static readonly uint WINHTTP_ACCESS_TYPE_NO_PROXY = 1;
		public static readonly uint WINHTTP_ACCESS_TYPE_NAMED_PROXY = 3;


		[DllImport("winhttp.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		public static extern bool WinHttpCloseHandle(IntPtr hInternet);

		[DllImport("winhttp.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		public static extern bool WinHttpGetProxyForUrl(
			IntPtr hSession,
			string lpcwszUrl,
			ref WINHTTP_AUTOPROXY_OPTIONS pAutoProxyOptions,
			ref WINHTTP_PROXY_INFO pProxyInfo
			);

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
			public struct WINHTTP_AUTOPROXY_OPTIONS
		{
			[MarshalAs(UnmanagedType.U4)] public int dwFlags;
			[MarshalAs(UnmanagedType.U4)] public int dwAutoDetectFlags;
			public string lpszAutoConfigUrl;
			public IntPtr lpvReserved;
			[MarshalAs(UnmanagedType.U4)] public int dwReserved;
			public bool fAutoLoginIfChallenged;
		}

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
			public struct WINHTTP_PROXY_INFO
		{
			[MarshalAs(UnmanagedType.U4)] public int dwAccessType;
			public string lpszProxy;
			public string lpszProxyBypass;
		}

		public static readonly IntPtr WINHTTP_NO_PROXY_NAME = IntPtr.Zero;
		public static readonly IntPtr WINHTTP_NO_PROXY_BYPASS = IntPtr.Zero;


		public static readonly int WINHTTP_AUTOPROXY_AUTO_DETECT = 0x00000001;
		public static readonly int WINHTTP_AUTOPROXY_CONFIG_URL = 0x00000002;
		public static readonly int WINHTTP_AUTOPROXY_RUN_INPROCESS = 0x00010000;
		public static readonly int WINHTTP_AUTOPROXY_RUN_OUTPROCESS_ONLY = 0x00020000;
		public static readonly int WINHTTP_AUTO_DETECT_TYPE_DHCP = 0x00000001;
		public static readonly int WINHTTP_AUTO_DETECT_TYPE_DNS_A = 0x00000002;


		/// <summary>
		/// The WinHttpGetIEProxyConfigForCurrentUser function obtains the Internet Explorer proxy configuration for the current user.
		/// </summary>
		/// <remarks>In Internet Explorer, the proxy settings are found on the Connections tab of the Tools / Internet Options menu option. 
		/// Proxy settings are configured on a per-connection basis; that is, the proxy settings for a LAN connection are separate from those for a dial-up or VPN connection. 
		/// WinHttpGetIEProxyConfigForCurrentUser returns the proxy settings for the current active connection.
		/// This function is useful in client applications running in network environments in which the Web Proxy Auto-Discovery (WPAD) protocol 
		/// is not implemented (meaning that no Proxy Auto-Configuration file is available). 
		/// If a PAC file is not available, then the WinHttpGetProxyForUrl function fails. 
		/// The WinHttpGetIEProxyConfigForCurrentUser function can be used as a fall-back mechanism to discover a workable proxy configuration 
		/// by retrieving the user�s proxy configuration in Internet Explorer.
		/// This function should not be used in a service process that does not impersonate a logged-on user.
		/// </remarks>
		/// <param name="ProxyConfig">[in, out] On input, is a pointer to a WINHTTP_CURRENT_USER_IE_PROXY_CONFIG structure. On output, the structure contains the Internet Explorer proxy settings for the current active network connection (for example, LAN, dial-up, or VPN connection).</param>
		/// <returns></returns>
		[DllImport("winhttp.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		public static extern bool WinHttpGetIEProxyConfigForCurrentUser(
			ref WINHTTP_CURRENT_USER_IE_PROXY_CONFIG ProxyConfig
			);

		/// <summary>
		/// The WINHTTP_CURRENT_USER_IE_PROXY_CONFIG structure contains the Internet Explorer proxy configuration information.
		/// </summary>
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
			public struct WINHTTP_CURRENT_USER_IE_PROXY_CONFIG
		{
			/// <summary>
			/// If TRUE, indicates that the Internet Explorer proxy configuration for the current user specifies "automatically detect settings"
			/// </summary>
			public bool fAutoDetect;

			/// <summary>
			/// Pointer to a null-terminated Unicode string that contains the auto-configuration URL if the Internet Explorer proxy configuration for the current user specifies "Use automatic proxy configuration"
			/// </summary>
			public string lpszAutoConfigUrl;

			/// <summary>
			/// Pointer to a null-terminated Unicode string that contains the proxy URL if the Internet Explorer proxy configuration for the current user specifies "use a proxy server"
			/// </summary>
			public string lpszProxy;

			/// <summary>
			/// Pointer to a null-terminated Unicode string that contains the optional proxy by-pass server list.
			/// </summary>
			public string lpszProxyBypass;
		}

		#endregion

		#region Codici di Errore

		/// <summary>
		/// Returned by WinHttpGetProxyForUrl when a proxy for the specified URL cannot be located. 
		/// </summary>
		public const int ERROR_WINHTTP_AUTO_PROXY_SERVICE_ERROR = 12178;

		/// <summary>
		/// Returned by WinHttpDetectAutoProxyConfigUrl if WinHTTP was unable to discover the URL of the Proxy Auto-Configuration (PAC) file. 
		/// </summary>
		public const int ERROR_WINHTTP_AUTODETECTION_FAILED = 12180;

		/// <summary
		/// An error occurred executing the script code in the Proxy Auto-Configuration (PAC) file. 
		/// </summary>
		public const int ERROR_WINHTTP_BAD_AUTO_PROXY_SCRIPT = 12166;

		/// <summary>
		/// Returned by the HttpRequest object if a specified option cannot be requested after the Open method has been called. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CALL_AFTER_OPEN = 12103;

		/// <summary>
		/// Returned by the HttpRequest object if a requested operation cannot be performed after calling the Send method. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CALL_AFTER_SEND = 12102;

		/// <summary>
		/// Returned by the HttpRequest object if a requested operation cannot be performed before calling the Open method. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CALL_BEFORE_OPEN = 12100;

		/// <summary>
		/// Returned by the HttpRequest object if a requested operation cannot be performed before calling the Send method. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CALL_BEFORE_SEND = 12101;

		/// <summary>
		/// Returned if connection to the server failed. 
		/// </summary>
		public const int ERROR_WINHTTP_CANNOT_CONNECT = 12029;

		/// <summary>
		/// Returned by WinHttpReceiveResponse when an overflow condition is encountered in the course of parsing chunked encoding. 
		/// </summary>
		public const int ERROR_WINHTTP_CHUNKED_ENCODING_HEADER_SIZE_OVERFLOW = 12183;

		/// <summary>
		/// Returned by WinHttpReceiveResponse when the server requests client authentication. 
		/// </summary>
		public const int ERROR_WINHTTP_CLIENT_AUTH_CERT_NEEDED = 12044;

		/// <summary>
		/// The connection with the server has been reset or terminated, or an incompatible SSL protocol was encountered. For example, WinHTTP version 5.1 does not support SSL2 unless the client specifically enables it. 
		/// </summary>
		public const int ERROR_WINHTTP_CONNECTION_ERROR = 12030;

		/// <summary>
		/// Obsolete; no longer used. 
		/// </summary>
		public const int ERROR_WINHTTP_HEADER_ALREADY_EXISTS = 12155;

		/// <summary>
		/// Returned by WinHttpReceiveResponse when a larger number of headers were present in a response than WinHTTP could receive. 
		/// </summary>
		public const int ERROR_WINHTTP_HEADER_COUNT_EXCEEDED = 12181;

		/// <summary>
		/// The requested header could not be located. 
		/// </summary>
		public const int ERROR_WINHTTP_HEADER_NOT_FOUND = 12150;

		/// <summary>
		/// Returned by WinHttpReceiveResponse when the size of headers received exceeds the limit for the request handle. 
		/// </summary>
		public const int ERROR_WINHTTP_HEADER_SIZE_OVERFLOW = 12182;

		/// <summary>
		/// The requested operation cannot be carried out because the handle supplied is not in the correct state. 
		/// </summary>
		public const int ERROR_WINHTTP_INCORRECT_HANDLE_STATE = 12019;

		/// <summary>
		/// The type of handle supplied is incorrect for this operation. 
		/// </summary>
		public const int ERROR_WINHTTP_INCORRECT_HANDLE_TYPE = 12018;

		/// <summary>
		/// An internal error has occurred. 
		/// </summary>
		public const int ERROR_WINHTTP_INTERNAL_ERROR = 12004;

		/// <summary>
		/// A request to WinHttpQueryOption or WinHttpSetOption specified an invalid option value. 
		/// </summary>
		public const int ERROR_WINHTTP_INVALID_OPTION = 12009;

		/// <summary>
		/// Obsolete; no longer used. 
		/// </summary>
		public const int ERROR_WINHTTP_INVALID_QUERY_REQUEST = 12154;

		/// <summary>
		/// The server response could not be parsed. 
		/// </summary>
		public const int ERROR_WINHTTP_INVALID_SERVER_RESPONSE = 12152;

		/// <summary>
		/// The URL is invalid. 
		/// </summary>
		public const int ERROR_WINHTTP_INVALID_URL = 12005;

		/// <summary>
		/// The login attempt failed. When this error is encountered, the request handle should be closed with WinHttpCloseHandle. A new request handle must be created before retrying the function that originally produced this error. 
		/// </summary>
		public const int ERROR_WINHTTP_LOGIN_FAILURE = 12015;

		/// <summary>
		/// The server name could not be resolved. 
		/// </summary>
		public const int ERROR_WINHTTP_NAME_NOT_RESOLVED = 12007;

		/// <summary>
		/// Obsolete; no longer used. 
		/// </summary>
		public const int ERROR_WINHTTP_NOT_INITIALIZED = 12172;

		/// <summary>
		/// The operation was canceled, usually because the handle on which the request was operating was closed before the operation completed. 
		/// </summary>
		public const int ERROR_WINHTTP_OPERATION_CANCELLED = 12017;

		/// <summary>
		/// The requested option cannot be set, only queried. 
		/// </summary>
		public const int ERROR_WINHTTP_OPTION_NOT_SETTABLE = 12011;

		/// <summary>
		/// Obsolete; no longer used. 
		/// </summary>
		public const int ERROR_WINHTTP_OUT_OF_HANDLES = 12001;

		/// <summary>
		/// Returned by WinHttpSendRequest on Windows Server 2003 family if an HTTP status code of 407 is returned, which indicates that proxy authentication is required. This error was added to handle the case where the client is trying to establish an SSL connection to a target server via a proxy server, but the proxy server requires authentication. 
		/// This error is not returned on Windows XP SP1 and Windows 2000 SP3, which leaves the client unaware that the SSL connection failed. In this case, a subsequent call to WinHttpWriteData to send some POST data, or to WinHttpReceiveResponse to get the response, fails with an INCORRECT_HANDLE_STATE error.
		/// </summary>
		public const int ERROR_WINHTTP_PROXY_AUTH_REQUIRED = 12185;

		/// <summary>
		/// The redirection failed because either the scheme changed or all attempts made to redirect failed (default is five attempts). 
		/// </summary>
		public const int ERROR_WINHTTP_REDIRECT_FAILED = 12156;

		/// <summary>
		/// The WinHTTP function failed. The desired function can be retried on the same request handle. 
		/// </summary>
		public const int ERROR_WINHTTP_RESEND_REQUEST = 12032;

		/// <summary>
		/// Returned when an incoming response exceeds an internal WinHTTP size limit. 
		/// </summary>
		public const int ERROR_WINHTTP_RESPONSE_DRAIN_OVERFLOW = 12184;

		/// <summary>
		/// Returned when a certificate's CN name does not match the passed value (equivalent to a CERT_E_CN_NO_MATCH error). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_CN_INVALID = 12038;

		/// <summary>
		/// Indicates that a required certificate is not within its validity period when verifying against the current system clock or the timestamp in the signed file, or that the validity periods of the certification chain do not nest correctly (equivalent to a CERT_E_EXPIRED or a CERT_E_VALIDITYPERIODNESTING error). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_DATE_INVALID = 12037;

		/// <summary>
		/// Indicates that revocation could not be checked because the revocation server was offline (equivalent to CRYPT_E_REVOCATION_OFFLINE). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_REV_FAILED = 12057;

		/// <summary>
		/// Indicates that a certificate has been revoked (equivalent to CRYPT_E_REVOKED). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_REVOKED = 12170;

		/// <summary>
		/// Indicates that a certificate is not valid for the requested usage (equivalent to CERT_E_WRONG_USAGE). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CERT_WRONG_USAGE = 12179;

		/// <summary>
		/// Indicates that an error occurred having to do with a secure channel (equivalent to error codes that begin with "SEC_E_" and "SEC_I_" listed in the winerror.h header file ). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_CHANNEL_ERROR = 12157;

		/// <summary>
		/// One or more errors were found in the Secure Sockets Layer (SSL) certificate sent by the server. To determine what type of error was encountered, check for a WINHTTP_CALLBACK_STATUS_SECURE_FAILURE notification in a status callback function. For more information, see WINHTTP_STATUS_CALLBACK. 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_FAILURE = 12175;

		/// <summary>
		/// Indicates that a certificate chain was processed but terminated in a root certificate that is not trusted by the trust provider (equivalent to CERT_E_UNTRUSTEDROOT). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_INVALID_CA = 12045;

		/// <summary>
		/// Indicates that a certificate is invalid (equivalent to errors such as CERT_E_ROLE, CERT_E_PATHLENCONST, CERT_E_CRITICAL, CERT_E_PURPOSE, CERT_E_ISSUERCHAINING, CERT_E_MALFORMED and CERT_E_CHAINING). 
		/// </summary>
		public const int ERROR_WINHTTP_SECURE_INVALID_CERT = 12169;

		/// <summary>
		/// The WinHTTP function support is being shut down or unloaded. 
		/// </summary>
		public const int ERROR_WINHTTP_SHUTDOWN = 12012;

		/// <summary>
		/// The request has timed out. 
		/// </summary>
		public const int ERROR_WINHTTP_TIMEOUT = 12002;

		/// <summary>
		/// The PAC file could not be downloaded. For example, the server referenced by the PAC URL may not have been reachable, or the server returned a 404 NOT FOUND response. 
		/// </summary>
		public const int ERROR_WINHTTP_UNABLE_TO_DOWNLOAD_SCRIPT = 12167;

		/// <summary>
		/// The URL specified a scheme other than "http:" or "https:". 
		/// </summary>
		public const int ERROR_WINHTTP_UNRECOGNIZED_SCHEME = 12006;
		/*
			ERROR_NOT_ENOUGH_MEMORY 
			Not enough memory was available to complete the requested operation. (Windows error code) 
			ERROR_INSUFFICIENT_BUFFER 
			The size of the buffer supplied to a function was insufficient to contain the returned data. The number of bytes required is usually returned in the buffer size parameter. See the specific function for details. (Windows error code) 
			ERROR_INVALID_HANDLE 
			The handle that was passed to the application programming interface (API) has been either invalidated or closed. (Windows error code) 
			ERROR_NO_MORE_FILES 
			No more files have been found. (Windows error code) 
			ERROR_NO_MORE_ITEMS 
			No more items have been found. (Windows error code) 
			ERROR_NOT_SUPPORTED 
			The required protocol stack is not loaded and the application cannot start WinSock. 
			*/

		#endregion

		public class ProxyInfo
		{
			public bool active;
			public string proxy;
			public string proxyBypass;
		}


		/// <summary>
		/// Prova a costruire un Proxy leggendo le impostazioni da IE.
		/// Se IE e` impostato con un proxy dinamico (script .pac)
		/// la funzione si collega al sito per determinare l'effettivo
		/// proxy da usare.
		/// Se la funzione NON riesce a determinare il proxy ritorna null.
		/// Se ci riesce ritorna il proxy.
		/// Notare che non bastano le informazioni del Proxy per connettersi al WEB:
		/// Bisogna poi agganciare al GlobalProxySelection anche le credenziali per l'accesso in rete.
		/// Questa funzione usa WinHttp.
		/// </summary>
		/// <param name="Url">l'url da raggiungere</param>
		/// <returns>il proxy da usare per raggiungere l'url</returns>
		public static WebProxy GetDynamicProxy(string Url)
		{
			try
			{
				WINHTTP_AUTOPROXY_OPTIONS AutoProxyOptions = new WINHTTP_AUTOPROXY_OPTIONS();
				AutoProxyOptions.fAutoLoginIfChallenged = true;

				bool fDoAutoProxy = false;

				// Check IE's proxy configuration
				WINHTTP_CURRENT_USER_IE_PROXY_CONFIG IEProxyConfig = new WINHTTP_CURRENT_USER_IE_PROXY_CONFIG();
				IEProxyConfig.fAutoDetect = false;
				bool result = WinHttpGetIEProxyConfigForCurrentUser(ref IEProxyConfig);
				if (result)
				{
					// if IE is configured to auto-detect, then we will too
					if (IEProxyConfig.fAutoDetect)
					{
						AutoProxyOptions.dwFlags = WINHTTP_AUTOPROXY_AUTO_DETECT;
						AutoProxyOptions.dwAutoDetectFlags = WINHTTP_AUTO_DETECT_TYPE_DHCP | WINHTTP_AUTO_DETECT_TYPE_DNS_A;
						fDoAutoProxy = true;
					}

					// if IE is configured to use an auto-config script, then we will use it too 
					if (IEProxyConfig.lpszAutoConfigUrl != null)
					{
						AutoProxyOptions.dwFlags = AutoProxyOptions.dwFlags | WINHTTP_AUTOPROXY_CONFIG_URL;
						AutoProxyOptions.lpszAutoConfigUrl = IEProxyConfig.lpszAutoConfigUrl;
						fDoAutoProxy = true;
					}
				}
				else
				{
					// if the IE proxy config is not available, then we will try auto-detection 
					AutoProxyOptions.dwFlags = WINHTTP_AUTOPROXY_AUTO_DETECT;
					AutoProxyOptions.dwAutoDetectFlags = WINHTTP_AUTO_DETECT_TYPE_DHCP | WINHTTP_AUTO_DETECT_TYPE_DNS_A;
					fDoAutoProxy = true;
				}

				string ProxyString = null;

				if (fDoAutoProxy)
				{
					// Need to create a temporary WinHttp session handle 
					// Note: performance of this GetProxyInfoForUrl function can be 
					// improved by saving this hSession handle across calls 
					// instead of creating a new handle each time 
					IntPtr hSession = IntPtr.Zero;

					try
					{
						hSession = WinHttpOpen(null, 1, IntPtr.Zero, IntPtr.Zero, 0);

						WINHTTP_PROXY_INFO WinHttpProxyInfo = new WINHTTP_PROXY_INFO();

						if (WinHttpGetProxyForUrl(hSession, Url, ref AutoProxyOptions, ref WinHttpProxyInfo))
						{
							ProxyString = WinHttpProxyInfo.lpszProxy;
							// ignore WinHttpProxyInfo.lpszProxyBypass, it will not be set 
						}
						else
						{
							int e = Marshal.GetLastWin32Error();
							string msg;
							switch (e)
							{
								case ERROR_WINHTTP_AUTODETECTION_FAILED:
									msg = "Returned by WinHttpDetectAutoProxyConfigUrl if WinHTTP was unable to discover the URL of the Proxy Auto-Configuration (PAC) file";
									break;
								case ERROR_WINHTTP_AUTO_PROXY_SERVICE_ERROR:
									msg = "Returned by WinHttpGetProxyForUrl when a proxy for the specified URL cannot be located. ";
									break;
								case ERROR_WINHTTP_BAD_AUTO_PROXY_SCRIPT:
									msg = "An error occurred executing the script code in the Proxy Auto-Configuration (PAC) file. ";
									break;
								case ERROR_WINHTTP_INCORRECT_HANDLE_TYPE:
									msg = "The type of handle supplied is incorrect for this operation.  ";
									break;
								case ERROR_WINHTTP_INTERNAL_ERROR:
									msg = "An internal error has occurred.  ";
									break;
								case ERROR_WINHTTP_INVALID_URL:
									msg = "The URL is invalid.  ";
									break;
								case ERROR_WINHTTP_LOGIN_FAILURE:
									msg = "The login attempt failed. When this error is encountered, close the request handle with WinHttpCloseHandle. A new request handle must be created before retrying the function that originally produced this error.  ";
									break;
								case ERROR_WINHTTP_OPERATION_CANCELLED:
									msg = "The operation was canceled, usually because the handle on which the request was operating was closed before the operation completed.  ";
									break;
								case ERROR_WINHTTP_UNABLE_TO_DOWNLOAD_SCRIPT:
									msg = "The PAC file could not be downloaded. For example, the server referenced by the PAC URL may not have been reachable, or the server returned a 404 NOT FOUND response.  ";
									break;
								case ERROR_WINHTTP_UNRECOGNIZED_SCHEME:
									msg = "The URL of the PAC file specified a scheme other than \"http:\" or \"https:\".  ";
									break;
									//case WinHttp.ERROR_NOT_ENOUGH_MEMORY: msg = "Not enough memory "; break;
								default:
									msg = e.ToString();
									break;

							}
							ProxyDiscover.Log(msg);
						}
					}
					finally
					{
						if (hSession != IntPtr.Zero)
							WinHttpCloseHandle(hSession);
					}
				}


				// If we don't have a proxy server from WinHttpGetProxyForUrl, 
				// then pick one up from the IE proxy config (if given) 
				if (ProxyString == null)
					ProxyString = IEProxyConfig.lpszProxy;


				ProxyInfo ret = new ProxyInfo();


				// If there's a proxy string, convert it to a Basic string 
				if (ProxyString != null)
				{
					ret.proxy = ProxyString;
					ret.active = true;
				}


				// Pick up any bypass string from the IEProxyConfig 
				if (IEProxyConfig.lpszProxyBypass != null)
					ret.proxyBypass = IEProxyConfig.lpszProxyBypass;

				/*
					Con Automatically detect settings
					e Use automatic configuration script impostata ad un server con file .pac
					si ha
						ret.active = true;
						ret.proxy = "172.19.0.32:80"
						ret.proxyBypass = null
					
				
					con Use proxy server for your LAN (this settings will not apply to dial-up or VPN connections)
					si ha
						ret.active = true;
						ret.proxy = "msproxy.elsag.it:80"
						ret.proxyBypass = "*.elsag.it;192.168.200.*;<local>"
				
					*/

				WebProxy webProxy = null;

				if (ret.active)
				{
					webProxy = new WebProxy();

					string url = null;
					int port = -1;

					if (true)
					{
						string[] s = ret.proxy.Split(':');
						if (s.Length >= 1)
							url = s[0];
						if (s.Length >= 2)
							port = int.Parse(s[1]);
					}

					webProxy = new WebProxy(url, port);


					if (ret.proxyBypass != null)
					{
						string[] by = ret.proxyBypass.Split(';');
						ArrayList a = new ArrayList();
						for (int i = 0; i < by.Length; ++i)
						{
							string s = by[i];
							if (s != "<local>")
							{
								s = s.Replace("*", "[a-zA-Z0-9_]+");
								s = s.Replace(".", "\\.");
								a.Add(s);
							}
						}

						webProxy.BypassList = (string[]) a.ToArray(typeof (string));
					}
				}

				return webProxy;
			}
			catch
			{
				return null;
			}

		}
	}

	public class DESPassword
	{
		private readonly DESCryptoServiceProvider _des;
		private readonly byte[] _key;

		/// <summary>
		/// Costruttore di default. 
		/// Imposta la chiave di codifica/decodifica, la modalita` di cifra
		/// e il paddingMode di default.
		/// </summary>
		public DESPassword(string secretKey)
		{
			_des = new DESCryptoServiceProvider();

			_key = Encoding.UTF8.GetBytes(secretKey);
			_des.Mode = CipherMode.ECB;
			_des.Padding = PaddingMode.Zeros;
		}

		/// <summary>
		/// Codifica una stringa con l'algoritmo DES.
		/// </summary>
		/// <param name="stringToEncrypt">La stringa da codificare</param>
		/// <returns>La stringa codificata in formato esadecimale</returns>
		public string Encrypt (string stringToEncrypt)
		{
			byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream (ms, _des.CreateEncryptor(_key, null), CryptoStreamMode.Write);
			cs.Write(inputByteArray, 0, inputByteArray.Length);
			cs.FlushFinalBlock();
			return ConvertBinaryToHexString(ms.ToArray());
		}

		/// <summary>
		/// Decodifica una stringa con l'algoritmo DES, togliendo eventuali caratteri '\0' di
		/// padding
		/// </summary>
		/// <param name="stringToDecrypt">La stringa da decodificare in formato esadecimale</param>
		/// <returns>La stringa decodificata</returns>
		public string Decrypt (string stringToDecrypt)
		{
			byte[] inputByteArray = ConvertHexStringToBinary(stringToDecrypt);
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream (ms, _des.CreateDecryptor(_key, null), CryptoStreamMode.Write);
			cs.Write(inputByteArray, 0, inputByteArray.Length );
			cs.FlushFinalBlock();
			string sz = Encoding.UTF8.GetString(ms.ToArray());
			//
			// rimuove i caratteri '\0' dalla stringa 
			// L'encrypt e' fatto di solito con carattere '\0' di padding, e il decrypt
			// ritorna una stringa con gli stessi caratteri '\0' di padding, che ovviamente
			// e' meglio rimuovere 
			//
			string szTrimmed =  sz.TrimEnd('\0');
			return szTrimmed;

		}

	
		protected static string ConvertBinaryToHexString (byte[] bData)
		{
			StringBuilder sHex = new StringBuilder(2 * bData.Length);
			for (int i=0; i<bData.Length; i++)
				sHex.AppendFormat("{0:X2}", bData[i]);
			return sHex.ToString();
		}

		protected static byte[] ConvertHexStringToBinary (string sData)
		{
			int iByte = sData.Length/2;
			byte [] bytevar = new byte[iByte];
			for (int i=0; i<iByte; i++)
				bytevar[i] = Convert.ToByte(sData.Substring(i*2,  2), 16);
			return bytevar;
		}
	}

}
#endif