using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using GME.Remoting;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmWelcome.
	/// </summary>
	public class frmWelcome : System.Windows.Forms.Form
	{
		/// <summary>
		/// Oggetti BL utilizzati dal form
		/// </summary>
		IDailyComunications BLMainObj = (IDailyComunications) RemotingHelper.GetObject(typeof(IDailyComunications));

		private EngineMainForm.TradingSessionParameters tspParams;

		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.RichTextBox rtbMessages;
		private System.Windows.Forms.Button btnSaveMessages;
		private System.Windows.Forms.Button btnShowComm;
		private System.Windows.Forms.SaveFileDialog dlgSaveAsRTF;
		private System.Windows.Forms.Label lbCommunications;
		private System.Windows.Forms.Label lbToday;
		private System.Windows.Forms.TextBox tbToday;

		/// <summary>
		/// 
		/// </summary>
		public frmWelcome(EngineMainForm.TradingSessionParameters atsp)
		{
			tspParams = atsp;
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmWelcome));
			this.btnCancel = new System.Windows.Forms.Button();
			this.rtbMessages = new System.Windows.Forms.RichTextBox();
			this.dlgSaveAsRTF = new System.Windows.Forms.SaveFileDialog();
			this.btnSaveMessages = new System.Windows.Forms.Button();
			this.btnShowComm = new System.Windows.Forms.Button();
			this.lbCommunications = new System.Windows.Forms.Label();
			this.tbToday = new System.Windows.Forms.TextBox();
			this.lbToday = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
			this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCancel.Location = new System.Drawing.Point(368, 240);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(104, 32);
			this.btnCancel.TabIndex = 6;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// rtbMessages
			// 
			this.rtbMessages.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.rtbMessages.Location = new System.Drawing.Point(8, 64);
			this.rtbMessages.Name = "rtbMessages";
			this.rtbMessages.ReadOnly = true;
			this.rtbMessages.Size = new System.Drawing.Size(584, 144);
			this.rtbMessages.TabIndex = 2;
			this.rtbMessages.Text = "<You Have No Messages>";
			// 
			// btnSaveMessages
			// 
			this.btnSaveMessages.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnSaveMessages.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnSaveMessages.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveMessages.Image")));
			this.btnSaveMessages.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSaveMessages.Location = new System.Drawing.Point(136, 240);
			this.btnSaveMessages.Name = "btnSaveMessages";
			this.btnSaveMessages.Size = new System.Drawing.Size(104, 32);
			this.btnSaveMessages.TabIndex = 4;
			this.btnSaveMessages.Text = "&Save Message";
			this.btnSaveMessages.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSaveMessages.Click += new System.EventHandler(this.btnSaveMessages_Click);
			// 
			// btnShowComm
			// 
			this.btnShowComm.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnShowComm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnShowComm.Image = ((System.Drawing.Image)(resources.GetObject("btnShowComm.Image")));
			this.btnShowComm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnShowComm.Location = new System.Drawing.Point(248, 240);
			this.btnShowComm.Name = "btnShowComm";
			this.btnShowComm.Size = new System.Drawing.Size(112, 32);
			this.btnShowComm.TabIndex = 5;
			this.btnShowComm.Text = "&Communications";
			this.btnShowComm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnShowComm.Click += new System.EventHandler(this.btnShowComm_Click);
			// 
			// lbCommunications
			// 
			this.lbCommunications.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbCommunications.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lbCommunications.Location = new System.Drawing.Point(8, 216);
			this.lbCommunications.Name = "lbCommunications";
			this.lbCommunications.Size = new System.Drawing.Size(584, 23);
			this.lbCommunications.TabIndex = 3;
			this.lbCommunications.Text = "<No Daily Communications from BIPEX>";
			this.lbCommunications.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// tbToday
			// 
			this.tbToday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbToday.Location = new System.Drawing.Point(248, 8);
			this.tbToday.Name = "tbToday";
			this.tbToday.ReadOnly = true;
			this.tbToday.Size = new System.Drawing.Size(176, 26);
			this.tbToday.TabIndex = 1;
			this.tbToday.Text = "";
			// 
			// lbToday
			// 
			this.lbToday.Location = new System.Drawing.Point(184, 8);
			this.lbToday.Name = "lbToday";
			this.lbToday.Size = new System.Drawing.Size(60, 23);
			this.lbToday.TabIndex = 8;
			this.lbToday.Text = "Today is:";
			this.lbToday.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// frmWelcome
			// 
			this.AcceptButton = this.btnCancel;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(600, 278);
			this.Controls.Add(this.lbToday);
			this.Controls.Add(this.tbToday);
			this.Controls.Add(this.lbCommunications);
			this.Controls.Add(this.btnShowComm);
			this.Controls.Add(this.btnSaveMessages);
			this.Controls.Add(this.rtbMessages);
			this.Controls.Add(this.btnCancel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Name = "frmWelcome";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Welcome, <USER>";
			this.Load += new System.EventHandler(this.frmWelcome_Load);
			this.Activated += new System.EventHandler(this.frmWelcome_Activated);
			this.ResumeLayout(false);

		}
		#endregion

		private bool bLoaded = false;
		private void frmWelcome_Load(object sender, System.EventArgs e)
		{
			this.Text = "Welcome, " + tspParams.ActiveUser;
			tbToday.Text = DateTime.Today.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture);

			byte[] tmpMessage = BLMainObj.WelcomeMessage(DateTime.Now);
			if (tmpMessage != null)
			{
				this.rtbMessages.LoadFile(new MemoryStream(tmpMessage), RichTextBoxStreamType.RichText);
			}

			if (BLMainObj.GetDailyComunicationsCount(DateTime.Now) > 0)
			{
				this.lbCommunications.Visible = true;
				this.lbCommunications.Text = string.Format("<{0} New Daily Communications from BIPEX>", BLMainObj.GetDailyComunicationsCount(DateTime.Now));
				this.lbCommunications.ForeColor = Color.Red;
				this.btnShowComm.Enabled = true;
			}
			else
			{
				this.lbCommunications.Visible = false;
				this.btnShowComm.Enabled = false;
			}

		}

		private void frmWelcome_Activated(object sender, System.EventArgs e)
		{
			if (!bLoaded)
			{
				bLoaded = true;
				this.btnCancel.Focus();
			}
		}

		private void btnSaveMessages_Click(object sender, System.EventArgs e)
		{
			dlgSaveAsRTF.CreatePrompt = true;
			dlgSaveAsRTF.DefaultExt = "rtf";
			dlgSaveAsRTF.Filter = "rtf files (*.rtf)|*.rtf|All files (*.*)|*.*";
			dlgSaveAsRTF.FilterIndex = 1;
			dlgSaveAsRTF.RestoreDirectory = true;
			dlgSaveAsRTF.OverwritePrompt = true;
			dlgSaveAsRTF.Title = "Save Message";
			if (dlgSaveAsRTF.ShowDialog() == DialogResult.OK && dlgSaveAsRTF.FileName.Length > 0)
			{
				try
				{
					// Save the contents of the RichTextBox into the file.
					this.rtbMessages.SaveFile(dlgSaveAsRTF.FileName, RichTextBoxStreamType.RichText);
				}
				catch (Exception ex)
				{
					MessageBox.Show(this.Owner, String.Format(BipexResourceManager.GetResourceString("MSG_CANNOTWRITEONFILE"), ex.ToString()), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				}
			}
		}

		private void btnShowComm_Click(object sender, System.EventArgs e)
		{
			frmShowCommunications frmsc = new frmShowCommunications(tspParams);
			frmsc.ShowDialog();
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

	}
}
