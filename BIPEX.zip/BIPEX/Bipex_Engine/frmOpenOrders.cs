using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using Delta;
using GME.Remoting;
using SPDriver;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmOpenOrders.
	/// </summary>
	public class frmOpenOrders : System.Windows.Forms.Form, IDocumentStreamerViewer
	{
		private int[] iDataGridPosition = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};

		/// <summary>
		/// Oggetti BL utilizzati dal form
		/// </summary>
		ISessioneMercato BLMainObj = (ISessioneMercato) RemotingHelper.GetObject(typeof(ISessioneMercato));

		private frmOfferta frmOf;

		// =================================
		// Nomi delle Colonne nel DataSource
		// =================================
		// !!!ATTENZIONE!!! 
		// Questi nomi DEVONO ESSERE GLI STESSI delle colonne contenute nel DataSource
		// (che sara' un DataTable all'interno di un DataSet) dal quale si alimenta il DataGrid!!!
		// ========================================

		public string[] MappingNames =
			{
				"IdOfferta",
				"Contratto",
				"CodiceOperatore",
				"CodiceUtente",
				"TSCreazione",
				"TSAbbinamento",
				"Ask",
				"OffertaAMercato",
				"PrezzoRichiesto",
				"QtyRichiesta",
				"NoteOfferta",
				"PrezzoResiduo",
				"QtyResidua",
				"OperatoreOTC",
				"CodiceOTC",
				"StatoOfferta"
			};
		
		public string[] HeaderTexts =
			{
				"Offer ID",
				"Contract",
				"Bid Op./",
				"User",
				"Insert Time",
				"Book Time",
				"Bid/Ask",
				"Mkt/Lmt",
				"Init.Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Init.Qty",
				"Notes",
				"Act.Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Act.Qty",
				"OTC Operator",
				"OTC Code",
				"Status"
			};

		// ======================================
		// Posizioni delle Colonne nel DataSource
		// ======================================
		// !!!ATTENZIONE!!! 
		// Questa lista DEVE ESSERE NELLO STESSO ORDINE delle colonne contenute 
		// nelle strutture MappingNames, HeaderTexts
		// =============================================
		public enum enPosColonneDS
		{
			IdOfferta = 0,
			Contratto,
			CodiceOperatore,
			CodiceUtente,
			TSCreazione,
			TSAbbinamento,
			Ask,
			OffertaAMercato,
			PrezzoRichiesto,
			QtyRichiesta,
			NoteOfferta,
			PrezzoResiduo,
			QtyResidua,
			OperatoreOTC,
			CodiceOTC,
			StatoOfferta,
			_TUTTI_
		} ;

		// ====================================
		// Posizioni delle Colonne nel DataGrid
		// ====================================
		// !!!ATTENZIONE!!!
		// L'ordine con il quale le colonne compaiono in questa lista � l'ordine
		// delle colonne visualizzate nel DataGrid. Per cambiare quindi quest'ordine
		// � sufficiente alterare l'ordine di questo Enum. Il Tag _TUTTI_ deve rimanere
		// SEMPRE E COMUNQUE in fondo!!!
		// !!!ATTENZIONE!!!
		// La lista pu� contenere UN SOTTOINSIEME delle colonne del DataSource, le
		// colonne contenute saranno le uniche che compariranno nel DataGrid.
		// !!!ATTENZIONE!!!
		// Nei metodi di Handling di PBs che reperiscono dati dal DataGrid, sono
		// estraibili dal DataGrid stesso SOLO LE COLONNE PRESENTI IN QUESTA LISTA!!!
		// ==============================================
		public enum enPosColonneDG
		{
			// Colonne VISIBILI
			Contratto = 0,
			TSCreazione,
			TSAbbinamento,
			Ask,
			OffertaAMercato,
			StatoOfferta,
			PrezzoRichiesto,
			QtyRichiesta,
			PrezzoResiduo,
			QtyResidua,
			CodiceOTC,
			OperatoreOTC,
			CodiceOperatore,
			CodiceUtente,
			IdOfferta,
			// Colonne NASCOSTE
			NoteOfferta,
			_TUTTI_
		} ;

		private System.Windows.Forms.DataGrid dgOpenOrders;
		private DataSet dsOpenOrders;

		private System.Windows.Forms.ContextMenu cmMainDG;

		// Il Currency Mgr serve a tenere memoria dello stato del datagrid
		// con riferimento alle righe visibili, ad esempio in base al filtro
		// attivo.
		// Per cui, tutte le volte che si altera la composizione del dataview
		// in termini di righe contenute, ad es. applicando un filtro, si deve
		// AGGIORNARE la proprieta' BindingContext del DataView...
		private CurrencyManager _cmMainDG;
		private DataRow _dr = null; 

		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmOpenOrders()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmMainDG = new System.Windows.Forms.ContextMenu();
			this.dgOpenOrders = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dgOpenOrders)).BeginInit();
			this.SuspendLayout();
			// 
			// dgOpenOrders
			// 
			this.dgOpenOrders.AlternatingBackColor = System.Drawing.SystemColors.ControlLight;
			this.dgOpenOrders.CaptionVisible = false;
			this.dgOpenOrders.DataMember = "";
			this.dgOpenOrders.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgOpenOrders.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgOpenOrders.Location = new System.Drawing.Point(0, 0);
			this.dgOpenOrders.Name = "dgOpenOrders";
			this.dgOpenOrders.ParentRowsVisible = false;
			this.dgOpenOrders.ReadOnly = true;
			this.dgOpenOrders.SelectionBackColor = System.Drawing.SystemColors.ControlDark;
			this.dgOpenOrders.Size = new System.Drawing.Size(704, 226);
			this.dgOpenOrders.TabIndex = 1;
			this.dgOpenOrders.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgOpenOrders_MouseDown);
			this.dgOpenOrders.DoubleClick += new System.EventHandler(this.dgOpenOrders_DoubleClick);
			// 
			// frmOpenOrders
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(704, 226);
			this.Controls.Add(this.dgOpenOrders);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmOpenOrders";
			this.Text = "Open Orders";
			this.Load += new System.EventHandler(this.frmOpenOrders_Load);
			this.VisibleChanged += new System.EventHandler(this.frmOpenOrders_VisibleChanged);
			((System.ComponentModel.ISupportInitialize)(this.dgOpenOrders)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		DataRecordList _drlOO;
		volatile BipexSubject _sOO;
		volatile bool _Visible = false;

		private void frmOpenOrders_Load(object sender, System.EventArgs e)
		{
			cmMainDG = new ContextMenu();
			cmMainDG.MenuItems.Add("Modify", new EventHandler(cmMainDG_Modify_Clicked));
			cmMainDG.MenuItems.Add("Revoke", new EventHandler(cmMainDG_Revoke_Clicked));
			cmMainDG.MenuItems.Add("Hide", new EventHandler(cmMainDG_Hide_Clicked));
			cmMainDG.MenuItems.Add("Reveal", new EventHandler(cmMainDG_Reveal_Clicked));
			cmMainDG.MenuItems.Add("Revoke ALL", new EventHandler(cmMainDG_RevokeALL_Clicked));
			cmMainDG.MenuItems.Add("Hide ALL", new EventHandler(cmMainDG_HideALL_Clicked));
			cmMainDG.MenuItems.Add("Reveal ALL", new EventHandler(cmMainDG_RevealALL_Clicked));

			dgOpenOrders.ContextMenu = cmMainDG;

			// Pulisco il DataGrid e lo ricostruisco in base al contenuto del DataSet...
			dgOpenOrders.DataSource = null;

			OpenOrders_Load();

			if (dsOpenOrders != null)
				BindDataGrid(dgOpenOrders, dsOpenOrders);
		
			_Visible = this.Visible;		
		}

		private void OpenOrders_Load()
		{
			dsOpenOrders = new DataSet();

			_drlOO = new DataRecordList();
			_drlOO.Version = 0;

			_sOO = new BipexSubject();
			_sOO.DataDiMercato = DateTime.Now.Date;
			_sOO.SubjectType = "OO";
			_sOO.SubjectSubType = string.Empty;

			_sOO.Version = _drlOO.Version;

			DataSetMerger.CreateTable(dsOpenOrders, "OO", typeof(OpenOrderDR));
		}

		public void SetFilterOnCurrentOperator()
		{
			if (_sOO != null)
			{
				if (EngineMainForm._tspParams.LoginActive)
				{
					BipexFilterPerOperatoreUtente filter = new BipexFilterPerOperatoreUtente(
						EngineMainForm._tspParams.ActiveOperatorCode,
						EngineMainForm._tspParams.ActiveUserCode);
					_sOO.Filter = filter;
					_sOO.Version = 0;
					_drlOO.Version = 0;
				}
			}
		}

		public void ResetFilterOnCurrentOperator()
		{
			if (_sOO != null)
			{
				_sOO.Filter = null;
				_sOO.Version = 0;
				_drlOO.Version = 0;
			}
		}

		private void BindDataGrid(DataGrid dg, DataSet ds)
		{
			if (ds != null)
				SetDataGridTableStyles(dg, "OO");

			FillDataGrid(dg, ds);
		
		}

		private void SetDataGridTableStyles(DataGrid dg, string sMappingName)
		{
			dg.TableStyles.Clear();

			DataGridTableStyle dgsBook = new DataGridTableStyle();

			// !!!ATTENZIONE!!!
			// WORKAROUND PER RISOLUZIONE PROBLEMA
			// SE SI RIDEFINISCE UN PROPRIO TABLESTYLE 
			// PER VISUALIZZARE UN DATATABLE,
			// OCCORRE RIASSEGNARE ESPLICITAMENTE I COLORI!!!,
			// altrimenti ad esempio impostazioni come l'alternate
			// color vanno perdute...
			dgsBook.AlternatingBackColor = BipexFormSettings.AlternatingBackColor;
			dgsBook.BackColor = BipexFormSettings.BackColor;
			dgsBook.ForeColor = BipexFormSettings.ForeColor;
			dgsBook.GridLineColor = BipexFormSettings.GridLineColor;
			dgsBook.HeaderBackColor = BipexFormSettings.HeaderBackColor;
			dgsBook.HeaderForeColor = BipexFormSettings.HeaderForeColor;
			dgsBook.LinkColor = BipexFormSettings.LinkColor;
			dgsBook.SelectionBackColor = BipexFormSettings.SelectionBackColor;
			dgsBook.SelectionForeColor = BipexFormSettings.SelectionForeColor;

			// Il DataGrid NON E' SORTABILE DALL'UTENTE...
			dgsBook.AllowSorting = false;
			dgsBook.RowHeadersVisible = false;

			dgsBook.MappingName = sMappingName;

			DataGridOpenOrdersAlignedTextBoxColumn[] dgcBook = new DataGridOpenOrdersAlignedTextBoxColumn[(int) enPosColonneDG._TUTTI_];
			for (int i = 0; i < dgcBook.Length; ++i)
				dgcBook[i] = new DataGridOpenOrdersAlignedTextBoxColumn();
			int index = 0;

			index = iDataGridPosition[(int) enPosColonneDG.Contratto];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.Contratto];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.Contratto];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 110;

			index = iDataGridPosition[(int) enPosColonneDG.TSCreazione];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.TSCreazione];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.TSCreazione];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForTimeWithAMPM;
			dgcBook[index].Width = 80;

			index = iDataGridPosition[(int) enPosColonneDG.TSAbbinamento];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.TSAbbinamento];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.TSAbbinamento];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForTimeWithAMPM;
			dgcBook[index].Width = 80;

			index = iDataGridPosition[(int) enPosColonneDG.PrezzoRichiesto];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.PrezzoRichiesto];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.PrezzoRichiesto];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].Width = 75;

			index = iDataGridPosition[(int) enPosColonneDG.QtyRichiesta];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.QtyRichiesta];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.QtyRichiesta];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].Width = 50;

			index = iDataGridPosition[(int) enPosColonneDG.PrezzoResiduo];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.PrezzoResiduo];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.PrezzoResiduo];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].Width = 75;

			index = iDataGridPosition[(int) enPosColonneDG.QtyResidua];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.QtyResidua];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.QtyResidua];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].Width = 50;

			index = iDataGridPosition[(int) enPosColonneDG.CodiceOTC];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.CodiceOTC];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.CodiceOTC];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 110;

			index = iDataGridPosition[(int) enPosColonneDG.OperatoreOTC];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.OperatoreOTC];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.OperatoreOTC];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 110;

			index = iDataGridPosition[(int) enPosColonneDG.CodiceOperatore];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.CodiceOperatore];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.CodiceOperatore];
			dgcBook[index].Alignment = HorizontalAlignment.Right; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 60;

			index = iDataGridPosition[(int) enPosColonneDG.CodiceUtente];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.CodiceUtente];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.CodiceUtente];
			dgcBook[index].Alignment = HorizontalAlignment.Left; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			index = iDataGridPosition[(int) enPosColonneDG.IdOfferta];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.IdOfferta];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.IdOfferta];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 110;

			index = iDataGridPosition[(int) enPosColonneDG.Ask];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.Ask];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.Ask];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			index = iDataGridPosition[(int) enPosColonneDG.OffertaAMercato];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.OffertaAMercato];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.OffertaAMercato];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			index = iDataGridPosition[(int) enPosColonneDG.StatoOfferta];
			dgcBook[index] = new DataGridOpenOrdersAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.StatoOfferta];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.StatoOfferta];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			dgsBook.GridColumnStyles.AddRange(dgcBook);
			dg.TableStyles.Add(dgsBook);

		}

		public void FillDataGrid(DataGrid dg, DataSet ds)
		{
			DataView dv = new DataView(ds.Tables[0]);

			dv.AllowDelete = false;
			dv.AllowEdit = false;
			dv.AllowNew = false;
			dv.Sort = MappingNames[(int) enPosColonneDS.IdOfferta] + " DESC";

			//Imposto il colore delle righe pari a un colore leggermente
			//piu` scuro di quello utilizzato per le righe dispari.
			int piuScuro = 10;
			int R = dg.BackColor.R - piuScuro;
			int G = dg.BackColor.G - piuScuro;
			int B = dg.BackColor.B - piuScuro;
			if (R < 0) R = 10;
			if (G < 0) G = 10;
			if (B < 0) B = 10;
			Color colore = Color.FromArgb(R, G, B);
			dg.AlternatingBackColor = colore;

			//dg.TableStyles.Clear();
			//dg.TableStyles.IsReadOnly = true;
			//dg.TableStyles.Add(stile);
			dg.AllowNavigation = false;

			dg.DataSource = dv;

			_cmMainDG = (CurrencyManager)this.BindingContext[dv];
			_cmMainDG.CurrentChanged += new EventHandler(_cmMainDG_CurrentChanged);
			dv.ListChanged += new ListChangedEventHandler(_cmMainDG_ListChanged);

			return;
		}

		public void _cmMainDG_CurrentChanged(object sender, EventArgs e)
		{
			try
			{
				DataRow dr = GetOffertaCorrente();
				if (_dr == null || _dr != dr)
				{
					_dr = dr;

					// DA FARE MB
					// DA FARE MB
					// DA FARE MB

					// Se c'� da consuntivare a qualche altro form il fatto che �
					// cambiata l'offerta selezionata in questo form, qui � il
					// posto per farlo (copiare gestione dal Book Riassuntivo)
					// SendOffertaRowChanged(dr);
				}
			}
			catch
			{
			}
		}
		private void _cmMainDG_ListChanged(object sender, ListChangedEventArgs e)
		{
			if (_cmMainDG.Position == 0)
			{
				try
				{
					DataRow dr = GetOffertaCorrente();
					// L'update in BackGround del DataSet associato al DataGrid
					// causa MOLTISSIMI eventi di tipo ListChanged, invio la
					// notifica del cambio di riga selezionata solo quando cio'
					// si verifica effettivamente...
					if (_dr == null || _dr != dr)
					{
						_dr = dr;

						// DA FARE MB
						// DA FARE MB
						// DA FARE MB

						// Se c'� da consuntivare a qualche altro form il fatto che �
						// cambiata l'offerta selezionata in questo form, qui � il
						// posto per farlo (copiare gestione dal Book Riassuntivo)
						// SendOffertaRowChanged(dr);
					}
				}
				catch
				{
				}
			}
		}

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			//			if (this.InvokeRequired)
			//			{
			//				GetBipexSubjectDelegate d = new GetBipexSubjectDelegate(GetBipexSubject);
			//				return (BipexSubject[]) this.Invoke(d);
			//			}
			//			else
			//			{
			//				if (this.Visible)
			//					return new BipexSubject[] {_sOO };
			//				else
			//					return new BipexSubject[0];
			//			}

			if (this._Visible)
				return new BipexSubject[] {_sOO };
			else
				return new BipexSubject[0];
		}

		private delegate void OnBipexResponseDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponseDelegate d = new OnBipexResponseDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_sOO.SubjectType == req[0].SubjectType &&
					_sOO.SubjectSubType == req[0].SubjectSubType)
				{
					_drlOO.Merge(resp[0]);
					_sOO.Version = _drlOO.Version;
					DataSetMerger.Merge(this.dsOpenOrders.Tables["OO"], _drlOO, typeof(OpenOrderDR));
				}
			}
		}

		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

		private DataRow GetOffertaCorrente()
		{
			if (_cmMainDG.Count == 0)
				return null;
			DataView dv = (DataView)_cmMainDG.List;
			if (dv.Count == 0)
				return null;
			DataRow dr = dv[_cmMainDG.Position].Row;
			return dr;
		}

		public void cmMainDG_Modify_Clicked(object sender, EventArgs e)
		{
			if (dgOpenOrders.CurrentRowIndex != -1)
			{
				DataRow dr = GetOffertaCorrente();
				if (dr == null)
					return;

				if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
				{
					DatiOfferta tmpDO;
					tmpDO = BLMainObj.GetOfferta(Convert.ToInt32(dr[MappingNames[(int) enPosColonneDS.IdOfferta]]));
					// Si possono MODIFICARE le Offerte che si trovano nello stato di Nascosta, Valida.
					if (tmpDO.nuStatoOfferta == Offerta_Stato.Nascosta || tmpDO.nuStatoOfferta == Offerta_Stato.Valida)
					{
						DatiContratto tmpDC;
						tmpDC = BLMainObj.GetContratto(dr[MappingNames[(int) enPosColonneDS.Contratto]].ToString());
						dgBook_HandleOfferta(tmpDO, tmpDC, frmOfferta.enFormMode.MODIFY);
					}
					else
					{
						MessageBox.Show(this.Owner, String.Format(BipexResourceManager.GetResourceString("MSG_CURRENTOFFERSTATUSNOTVALID"), tmpDO.nuStatoOfferta.ToString()), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						return;
					}
				}
				else
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
		}

		public void cmMainDG_Revoke_Clicked(object sender, EventArgs e)
		{
			if (dgOpenOrders.CurrentRowIndex != -1)
			{
				DataRow dr = GetOffertaCorrente();
				if (dr == null)
					return;

				if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
				{
					DatiOfferta tmpDO;
					tmpDO = BLMainObj.GetOfferta(Convert.ToInt32(dr[MappingNames[(int) enPosColonneDS.IdOfferta]]));
					// Si possono REVOCARE le Offerte che si trovano nello stato di Nascosta, Valida.
					if (tmpDO.nuStatoOfferta == Offerta_Stato.Nascosta || tmpDO.nuStatoOfferta == Offerta_Stato.Valida)
					{
						DatiContratto tmpDC;
						tmpDC = BLMainObj.GetContratto(dr[MappingNames[(int) enPosColonneDS.Contratto]].ToString());
						dgBook_HandleOfferta(tmpDO, tmpDC, frmOfferta.enFormMode.REVOKE);
					}
					else
					{
						MessageBox.Show(this.Owner, String.Format(BipexResourceManager.GetResourceString("MSG_CURRENTOFFERSTATUSNOTVALID"), tmpDO.nuStatoOfferta.ToString()), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						return;
					}
				}
				else
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
		}

		public void cmMainDG_Hide_Clicked(object sender, EventArgs e)
		{
			if (dgOpenOrders.CurrentRowIndex != -1)
			{
				DataRow dr = GetOffertaCorrente();
				if (dr == null)
					return;

				if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
				{
					DatiOfferta tmpDO;
					tmpDO = BLMainObj.GetOfferta(Convert.ToInt32(dr[MappingNames[(int) enPosColonneDS.IdOfferta]]));
					// Si possono SOSPENDERE (CIOE' NASCONDERE) le Offerte che si trovano nello stato di Valida.
					if (tmpDO.nuStatoOfferta == Offerta_Stato.Valida)
					{
						DatiContratto tmpDC;
						tmpDC = BLMainObj.GetContratto(dr[MappingNames[(int) enPosColonneDS.Contratto]].ToString());
						dgBook_HandleOfferta(tmpDO, tmpDC, frmOfferta.enFormMode.HIDE);
					}
					else
					{
						MessageBox.Show(this.Owner, String.Format(BipexResourceManager.GetResourceString("MSG_CURRENTOFFERSTATUSNOTVALID"), tmpDO.nuStatoOfferta.ToString()), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						return;
					}
				}
				else
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
		}

		public void cmMainDG_Reveal_Clicked(object sender, EventArgs e)
		{
			if (dgOpenOrders.CurrentRowIndex != -1)
			{
				DataRow dr = GetOffertaCorrente();
				if (dr == null)
					return;

				if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
				{
					DatiOfferta tmpDO;
					tmpDO = BLMainObj.GetOfferta(Convert.ToInt32(dr[MappingNames[(int) enPosColonneDS.IdOfferta]]));
					// Si possono RIVELARE le Offerte che si trovano nello stato di Nascosta.
					if (tmpDO.nuStatoOfferta == Offerta_Stato.Nascosta)
					{
						DatiContratto tmpDC;
						tmpDC = BLMainObj.GetContratto(dr[MappingNames[(int) enPosColonneDS.Contratto]].ToString());
						dgBook_HandleOfferta(tmpDO, tmpDC, frmOfferta.enFormMode.REVEAL);
					}
					else
					{
						MessageBox.Show(this.Owner, String.Format(BipexResourceManager.GetResourceString("MSG_CURRENTOFFERSTATUSNOTVALID"), tmpDO.nuStatoOfferta.ToString()), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						return;
					}
				}
				else
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
		}

		public void cmMainDG_RevokeALL_Clicked(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		public void cmMainDG_HideALL_Clicked(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		public void cmMainDG_RevealALL_Clicked(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		private void dgBook_HandleOfferta(DatiOfferta tmpDO, DatiContratto tmpDC, frmOfferta.enFormMode formMode)
		{

			frmOf = new frmOfferta(tmpDO, tmpDC, formMode);

			// ATTENZIONE!!!
			// ATTENZIONE!!!
			// ATTENZIONE!!!
			// Per ora NO offerte nella taskbar...
			frmOf.ShowInTaskbar = false;

			// Mi dichiaro come owner della finestra figlia che ospita l'offerta,
			// questo fa si' che TUTTE le finestre modeless di offerta restano
			// in primo piano, NON SOLO l'ultima che si genera...
			this.AddOwnedForm(frmOf);
			frmOf.Show();

			// ATTENZIONE!!!
			// ATTENZIONE!!!
			// ATTENZIONE!!!
			// NON E' NECESSARIO RICHIAMARE LA REMOVEOWNEDFORM QUANDO SI FA LA
			// CLOSE DEL PNL FIGLIO, LA REMOVE VIENE FATTA AUTOMATICAMENTE DAL
			// FRAMEWORK...

			return;
		
		}

		private void dgOpenOrders_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			DataGrid.HitTestInfo ht = dgOpenOrders.HitTest(e.X, e.Y);

			// Deseleziono righe eventualmente selezionate in questo momento
			// (anche selezioni multiple) ed imposto come selezionata la riga corrente
			if (ht.Type == DataGrid.HitTestType.Cell || ht.Type == DataGrid.HitTestType.RowHeader)
			{
				if (_cmMainDG.Count == 0)
					return;
				DataView dv = (DataView)_cmMainDG.List;
				if (dv.Count == 0)
					return;

				for (int i = 0; i < dv.Count; ++i)
					if (dgOpenOrders.IsSelected(i))
						dgOpenOrders.UnSelect(i);

				// LACCHEZZO IGNOBILE
				// LACCHEZZO IGNOBILE
				// LACCHEZZO IGNOBILE
				// LA RIGA VIENE SELEZIONATA, A FRONTE DEL RIGHT CLICK, SE E SOLO SE 
				// IL RIGHT CLICK PROVOCA UN CELL CHANGED!!! MA SE IL LEFT CLICK 
				// PRECEDENTE SULLA RIGA, PER MOTIVI DI IMPLEMENTAZIONE DEL LEFT CLICK, 
				// NON SELEZIONA LA RIGA, ECCO CHE IL RIGHT CLICK SULLA STESSA CELLA 
				// NON GENERA L'EVENTO DI CELL CHANGED!!! NEL MODO QUI SOTTO INVECE 
				// IO GENERO SEMPRE E COMUNQUE UN CELL CHANGED...
				int ColumnAlternate = 0;
				if (ht.Column > 0)
					ColumnAlternate = ht.Column - 1;
				else
					ColumnAlternate = 1;

				dgOpenOrders.CurrentCell = new DataGridCell(ht.Row, ColumnAlternate);
				dgOpenOrders.CurrentCell = new DataGridCell(ht.Row, ht.Column);

				dgOpenOrders.CurrentRowIndex = ht.Row;

			}

			// Menu` contestuale: qui lo si puo' abilitare o meno testando
			// le condizioni che ci interessano sulla riga selezionata oppure
			// comporlo in modo DINAMICO in funzione delle caratteristiche della
			// riga selezionata...
			bool b = true;
			if (b)
				dgOpenOrders.ContextMenu = this.cmMainDG;
			else
				dgOpenOrders.ContextMenu = null;

		}

		private void dgOpenOrders_DoubleClick(object sender, System.EventArgs e)
		{
			// Doppio Click sul DataGrid: 
			// Pannello di dettaglio dell'offerta, come popup modale, in modalit� MODIFICA DELL'OFFERTA...

			if (dgOpenOrders.CurrentRowIndex != -1)
			{
				DataRow dr = GetOffertaCorrente();
				if (dr == null)
					return;

				if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
				{
					DatiOfferta tmpDO;
					tmpDO = BLMainObj.GetOfferta(Convert.ToInt32(dr[MappingNames[(int) enPosColonneDS.IdOfferta]]));
					// Si possono MODIFICARE le Offerte che si trovano nello stato di Nascosta, Valida.
					if (tmpDO.nuStatoOfferta == Offerta_Stato.Nascosta || tmpDO.nuStatoOfferta == Offerta_Stato.Valida)
					{
						DatiContratto tmpDC;
						tmpDC = BLMainObj.GetContratto(dr[MappingNames[(int) enPosColonneDS.Contratto]].ToString());
						dgBook_HandleOfferta(tmpDO, tmpDC, frmOfferta.enFormMode.MODIFY);
					}
					else
					{
						MessageBox.Show(this.Owner, String.Format(BipexResourceManager.GetResourceString("MSG_CURRENTOFFERSTATUSNOTVALID"), tmpDO.nuStatoOfferta.ToString()), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						return;
					}
				}
				else
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
		}

		private void frmOpenOrders_VisibleChanged(object sender, System.EventArgs e)
		{
			_Visible = this.Visible;		
		}

		/// <summary>
		/// La classe consente di gestire l'allineamento separato tra l'header text
		/// di una colonna ed i dati contenuti nelle celle nella colonna stessa
		/// 
		/// Derivando da questa classe si ottiene che:
		/// 
		/// -	La proprieta' standard Alignment serve a gestire l'allineamento
		///		dell'header (ATTENZIONE: HorizontalAlignment.Right CAUSA UN CLIPPING
		///		DELL'HEADER TEXT e quindi e' meglio non usarlo!);
		///	-	La proprieta' custom DataAlignment serve a gestire l'allineamento
		///		del dato nella cella.
		/// </summary>
		private class DataGridOpenOrdersAlignedTextBoxColumn : DataGridTextBoxColumn
		{
			private static Brush _fblu = new SolidBrush(Color.Blue);
			private static Brush _fbianco = new SolidBrush(Color.White);
			private static Brush _bblu = new SolidBrush(Color.Blue);
			private static Brush _frosso = new SolidBrush(Color.Red);
			private static Brush _fverde = new SolidBrush(Color.Green);

			/// <summary>
			/// I tipi di evidenziazione ammessi
			/// </summary>
			public enum HighLightType
			{
				BackGround = 0,
				Foreground
			}

			private HighLightType highlightType;
			protected bool bColorSetInDerivedClass = false;
			private HorizontalAlignment dataAlignment = HorizontalAlignment.Center;

			public DataGridOpenOrdersAlignedTextBoxColumn()
			{
				highlightType = HighLightType.BackGround;
			}

			/// <summary>
			/// La proprieta' serve a gestire l'allineamento del dato nella cella.
			/// </summary>
			public HorizontalAlignment DataAlignment
			{
				get { return this.dataAlignment; }
				set { this.dataAlignment = value; }
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
				int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// !!!ATTENZIONE!!!
				// WORKAROUND PER RISOLUZIONE PROBLEMA
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// (per default, il click sulla barra a sz delle celle fa il paint mentre
				// il click sulle celle stesse non fa il paint!!!)

				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum & !bColorSetInDerivedClass)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				// Questa e' la riga corrente...
				DataRow dr = ((DataView) cm.List)[rowNum].Row;

				// ...e questi sono i valori delle celle della riga corrente...
				string strCellText = "";
				
				if (dr[this.MappingName] != System.Convert.DBNull)
				{
					// Converto il valore in stringa per poterlo riscrivere, devo
					// tenere conto dell'attributo di formattazione eventualmente
					// impostato dall'utente del datagrid...

					if (this.MappingName == "PrezzoResiduo")
					{
						strCellText = FormatObjectAsString(dr[this.MappingName], this.Format);

						switch (highlightType)
						{
							case HighLightType.BackGround:
								myForeBrush = _fbianco;
								myBackBrush = _bblu;
								break;
							case HighLightType.Foreground:
								myForeBrush = _fblu;
								myBackBrush = backBrush;
								break;
						}
						
					}
					else
						if (this.MappingName == "StatoOfferta")
					{
						if (dr[this.MappingName].ToString() == "0")
						{
							strCellText = FormatObjectAsString("Revoked", this.Format);
							myForeBrush = _frosso;
						}
						else
							if (dr[this.MappingName].ToString() == "1")
						{
							strCellText = FormatObjectAsString("Hidden", this.Format);
							myForeBrush = _frosso;
						}
						else
							if (dr[this.MappingName].ToString() == "2")
						{
							strCellText = FormatObjectAsString("Valid", this.Format);
							myForeBrush = _fverde;
						}
						else
							strCellText = FormatObjectAsString("??????", this.Format);
					}
					else
						if (this.MappingName == "Ask")
					{
						if (dr[this.MappingName].ToString() == "True")
							strCellText = FormatObjectAsString("Ask", this.Format);
						else
							if (dr[this.MappingName].ToString() == "False")
							strCellText = FormatObjectAsString("Bid", this.Format);
						else
							strCellText = FormatObjectAsString("???", this.Format);
					}
					else
						if (this.MappingName == "OffertaAMercato")
					{
						if (dr[this.MappingName].ToString() == "True")
							strCellText = FormatObjectAsString("Mkt", this.Format);
						else
							if (dr[this.MappingName].ToString() == "False")
							strCellText = FormatObjectAsString("Lmt", this.Format);
						else
							strCellText = FormatObjectAsString("???", this.Format);
					}
					else
						strCellText = FormatObjectAsString(dr[this.MappingName], this.Format);
				}

				// Determino l'allineamento in funzione della property impostata dall'utente della classe
				StringFormat stringFormat = new StringFormat();
				switch (DataAlignment)
				{
					case HorizontalAlignment.Center:
						stringFormat.Alignment = StringAlignment.Center;
						break;
					case HorizontalAlignment.Left:
						stringFormat.Alignment = StringAlignment.Near;
						break;
					case HorizontalAlignment.Right:
						stringFormat.Alignment = StringAlignment.Far;
						break;
				}

				// Disegno BackGround sul rect da refreshare...
				g.FillRectangle(myBackBrush, bounds);
				// Calcolo nuovo rect...
				RectangleF CellBounds = new RectangleF(bounds.Left, bounds.Top + 3, bounds.Width, bounds.Height);
				// Refresh del contenuto della cella...
				g.DrawString(strCellText, this.DataGridTableStyle.DataGrid.Font, myForeBrush, CellBounds, stringFormat);

			}

			private int SelectedRow = -1;

			protected override void Edit(CurrencyManager source, int rowNum, Rectangle bounds, bool readOnly, string instantText, bool cellIsVisible)
			{
				// Per evitare crash testare che ci sia una selezione valida
				// prima di fare la deselezione...
				if (SelectedRow > -1 && SelectedRow < source.List.Count + 1)
					this.DataGridTableStyle.DataGrid.UnSelect(SelectedRow);
			}

			protected string FormatObjectAsString(object o, string Format)
			{
				if (o.GetType() == typeof (DateTime))
				{
					DateTime tmp = Convert.ToDateTime(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (double))
				{
					double tmp = Convert.ToDouble(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (decimal))
				{
					decimal tmp = Convert.ToDecimal(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (short))
				{
					short tmp = Convert.ToInt16(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (int))
				{
					int tmp = Convert.ToInt32(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (long))
				{
					long tmp = Convert.ToInt64(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else
				{
					// Type non gestito con formattazione specifica, richiamo il metodo
					// standard di conversione in stringa...
					return o.ToString();
				}
			}
		}
	
	}
}
