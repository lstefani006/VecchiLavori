using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using Crownwood.Magic.Common;
using Crownwood.Magic.Docking;
using Crownwood.Magic.Menus;
using Delta;
using GME.Utility;
using NetworkSaver;
using TabControl = Crownwood.Magic.Controls.TabControl;
using TabPage = Crownwood.Magic.Controls.TabPage;

namespace Bipex_Engine
{

	/// <summary>
	/// Summary description for EngineMainForm.
	/// </summary>
	public class EngineMainForm : Form, IDocumentStreamerViewer
	{

		// Le distinte tipologie di TabPage presenti nel Main Form, in base a tale
		// tipologia viene costruito il Title ed il FullTitle del content...
		public static readonly string TabPageGeneric = "TabPageGeneric";
		public static readonly string TabPageContractData = "TabPageContractData";
		public static readonly string TabPageOperatorUserData = "TabPageOperatorUserData";

		public enum CommStatus
		{
			Starting = 0,
			NoCommunication,
			RequestSent,
			ResponseReceived
		}
		public enum RefreshStatus
		{
			On = 0,
			Off
		}

		public class TradingSessionParameters
		{
			CultureInfo BIPEXCultureForCurrencySymbol;

			private CommStatus commstatus;
			private RefreshStatus refreshstatus;
			private MarketSessionDR.eStatoSessione bipexmktcurrsessstatus;

			private bool loginActive;
			private String currentContract;

			private DatiUtente utente;

			public TradingSessionParameters()
			{

				BIPEXCultureForCurrencySymbol = new CultureInfo("it-it");

				commstatus = CommStatus.Starting;
				refreshstatus = RefreshStatus.Off;
				bipexmktcurrsessstatus = MarketSessionDR.eStatoSessione.NUOVA;
				loginActive = false;
				currentContract = string.Empty;
				utente = null;
			}

			/// <summary>
			/// 
			/// </summary>
			public string BIPEXCurrencySymbol
			{
				get 
				{ return (this.BIPEXCultureForCurrencySymbol.NumberFormat.CurrencySymbol); }
			}

			/// <summary>
			/// 
			/// </summary>
			public CommStatus enCommStatus
			{
				get 
				{ return this.commstatus; }
				set 
				{ this.commstatus = value; }
			}

			/// <summary>
			/// 
			/// </summary>
			public RefreshStatus enRefreshStatus
			{
				get 
				{ return this.refreshstatus; }
				set 
				{ this.refreshstatus = value; }
			}

			/// <summary>
			/// 
			/// </summary>
			public MarketSessionDR.eStatoSessione enBipexMktCurrSessStatus
			{
				get 
				{ return this.bipexmktcurrsessstatus; }
				set 
				{ this.bipexmktcurrsessstatus = value; }
			}

			/// <summary>
			/// 
			/// </summary>
			public bool LoginActive 
			{
				get 
				{ return this.loginActive; }
				set 
				{ this.loginActive = value; }
			}

			public string CurrentContract
			{
				get 
				{ return this.currentContract; }
				set 
				{ this.currentContract = value; }
			}

			public string ActiveUser
			{
				get 
				{ return (this.utente.Nome + " " + this.utente.Cognome + " (" + this.utente.Codice + ")"); }
			}

			public string ActiveUserCode
			{
				get 
				{ return (this.utente.Codice); }
			}

			public string ActiveOperator
			{
				// DA FARE MB
				// DA FARE MB
				// DA FARE MB
				// Un utente potrebbe essere associato a piu' operatori... in versione demo si
				// approssima il concetto, l'utente e' associato ad un solo operatore che e'
				// il primo operatore...
				// Andr� cambiata tutta la logica quando arriver� il BL VERO della gestione Login...
				// Andr� cambiata tutta la logica quando arriver� il BL VERO della gestione Login...
				// Andr� cambiata tutta la logica quando arriver� il BL VERO della gestione Login...
				get 
				{ return (this.utente.Operatore[0].RagioneSociale); }
			}

			public string ActiveOperatorCode
			{
				// DA FARE MB
				// DA FARE MB
				// DA FARE MB
				// Un utente potrebbe essere associato a piu' operatori... in versione demo si
				// approssima il concetto, l'utente e' associato ad un solo operatore che e'
				// il primo operatore...
				// Andr� cambiata tutta la logica quando arriver� il BL VERO della gestione Login...
				// Andr� cambiata tutta la logica quando arriver� il BL VERO della gestione Login...
				// Andr� cambiata tutta la logica quando arriver� il BL VERO della gestione Login...
				get 
				{ return (this.utente.Operatore[0].Codice); }
			}

			public string ActiveRole
			{
				get 
				{ return this.utente.Ruolo; }
			}

			public void LoginToBipex(frmLogin.rcFrmLogin rcl)
			{
				LoginActive = true;
				utente = rcl.utente;
			}
			public void LogoffFromBipex()
			{
				LoginActive = false;
				utente = null;
			}
		}

		// La struttura che tiene memoria dei dati della Sessione di Trading � public static 
		// dato che i dati (ad es. quelli di login) servono ai forms figli
		public static TradingSessionParameters _tspParams = new TradingSessionParameters();
		
		protected VisualStyle _style;
		protected DockingManager _manager;
		protected StatusBar _statusBar;
		protected StatusBarPanel _sbpCommunication;
		protected StatusBarPanel _sbpRefresh;
		protected StatusBarPanel _sbpBipexMktCurrSess;

		protected MenuCommand _menuMain;
		private const string _sLoginToBipex = "&Login to Bipex";
		private const string _sShowWelcome = "Show Welcome Page";
		private const string _sLogoffFromBipex = "Logoff from Bipe&x";
		protected MenuCommand _menuFile;

		protected MenuCommand _menuBookTrading;
		private const string _sBuyCurrentContract = "&Buy Current Contract";
		private const string _sSellCurrentContract = "&Sell Current Contract";

		protected MenuCommand _menuBookLayout;
		protected MenuCommand _menuOpenOrders;
		protected MenuCommand _menuSaldoFisico;
		protected MenuCommand _menuReport;

		private string _sThisFormTitle;

		protected bool _allowContextMenu = true;
		protected bool _customContextMenu = false;
		protected int _ignoreClose = 1;
		private IContainer components;

		private string _stpBInitialTitle;

		private Crownwood.Magic.Controls.TabControl _tcTopRightFrame;
		private Crownwood.Magic.Controls.TabControl _tcLeftFrame;
		private Content _coLeftFrame;
		private Crownwood.Magic.Controls.TabControl _tcBottomFrame;
		private Content _coBottomFrame;

		private frmBookSingoloContratto _frmBookSingoloContratto;
		private Crownwood.Magic.Controls.TabPage _tpBookSingoloContratto;
		private frmBook _frmBook;
		private Crownwood.Magic.Controls.TabPage _tpBookRiassuntivo;
		private frmQuadroComandi _frmQuadroComandi;
		private Crownwood.Magic.Controls.TabPage _tpQuadroComandi;
		private frmFasiNegoziazione _frmFasiNegoziazione;
		private Crownwood.Magic.Controls.TabPage _tpFasiNegoziazione;
		private frmDettagliContratto _frmDettagliContratto;
		private Crownwood.Magic.Controls.TabPage _tpDettagliContratto;
		private frmDailyActivity _frmDailyActivity;
		private Crownwood.Magic.Controls.TabPage _tpDailyActivity;
		private frmOpenOrders _frmOpenOrders;
		private Crownwood.Magic.Controls.TabPage _tpOpenOrders;
		private frmSaldoFisico _frmSaldoFisico;
		private Crownwood.Magic.Controls.TabPage _tpSaldoFisico;
		private frmCalendarioDelivery _frmCalendarioDelivery;
		private Crownwood.Magic.Controls.TabPage _tpCalendarioDelivery;
		private RichTextBox _frmNotes;
		private Crownwood.Magic.Controls.TabPage _tpNotes;

		private System.Windows.Forms.NotifyIcon _niCommFrozen;
		private System.Windows.Forms.NotifyIcon _niCommOK;
		private System.Windows.Forms.NotifyIcon _niCommKO;
		private System.Windows.Forms.NotifyIcon _niCommPending;
		private System.Windows.Forms.Timer checkCommStatusTimer;
		private System.Windows.Forms.NotifyIcon _niMarketOpen;
		private System.Windows.Forms.NotifyIcon _niMarketClosed;
		private System.Windows.Forms.NotifyIcon _niMarketSuspended;

		private DocumentStreamer _documentStreamer = new DocumentStreamer();

		[STAThread]
		public static void Main(string[] args)
		{
			if (!CheckArgs(args))
				return;

			#if !DEBUG
						try
						{
							StartApp();
						}
						catch (Exception e)
						{
							MessageBox.Show(e.Message);
						}
			#else
					StartApp();
			#endif
		}

		private static void StartApp()
		{

			// La culture che pilota il reperimento delle risorse a runtime da un file di risorse
			// esterno � CurrentUICulture (propriet� di Thread.CurrentThread).
			//
			// Se imposto CurrentUICulture = "it-it", le risorse vengono reperite
			// dal file Bipex_Engine.it.resx;
			// Se imposto CurrentUICulture = "en-US", le risorse vengono reperite
			// dal file Bipex_Engine.en.resx;
			// Se non faccio alcuna impostazione di CurrentUICulture, le risorse vengono reperite
			// in base alla impostazione di default di CurrentUICulture che viene inizializzato in
			// base ai Regional Settings del Running Computer, etc...
			
			// Thread.CurrentThread.CurrentUICulture = new CultureInfo("it-it");
			Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");

			Thread.CurrentThread.CurrentCulture = new CultureInfo("it-it");

			// !!!ATTENZIONE!!! I valori di AMDesignator e PMDesignator per la lingua italiana sono BLANK. Perci�
			// se si vuole che una stringa di formato data/ora personalizzato utilizzata con una cultureinfo
			// italiana visualizzi le stringhe "AM" e "PM" occorre sovrascrivere i valori di default delle propriet�
			// qui sotto (i valori espliciti "AM" e "PM" li prendo dalle propriet� di CultureInfo.InvariantCulture
			// cos� evito di inserirli "hardcoded"...
			Thread.CurrentThread.CurrentCulture.DateTimeFormat.AMDesignator = CultureInfo.InvariantCulture.DateTimeFormat.AMDesignator;
			Thread.CurrentThread.CurrentCulture.DateTimeFormat.PMDesignator = CultureInfo.InvariantCulture.DateTimeFormat.PMDesignator;

			// MessageBox.Show("Hi, CurrentUICulture is "+Thread.CurrentThread.CurrentUICulture.DisplayName);
			// MessageBox.Show("Hi, CurrentCulture is "+Thread.CurrentThread.CurrentCulture.DisplayName);

			try
			{
				BipexResourceManager.LoadResourceManager("Bipex_Engine.Bipex_Engine");
			}
			catch
			{
				// Qui NON SI PUO' usare BipexResourceManager.GetResourceString perche' il file delle risorse NON E' CARICATO!!!
				MessageBox.Show("ERROR LOADING RESOURCE MANAGER (CurrentIUCulture is <"+Thread.CurrentThread.CurrentUICulture.DisplayName+">)");
				return;
			}
			
			// MessageBox.Show("Will get resources from "+BipexResourceManager.rmMgr.BaseName);
			// MessageBox.Show("Value for key MSG_BUYPLACEASKPLACE is "+BipexResourceManager.rmMgr.GetString("MSG_BUYPLACEASKPLACE"));

			string Url = AppSettings.ToString("Bipex_ControlWS_Url");
			ProxyDiscover.TestInternetConnectionStatus tc;
			tc = NetworkSaver.ProxyDiscover.SetupProxy(Url);
			if (tc != ProxyDiscover.TestInternetConnectionStatus.Connected)
			{
				MessageBox.Show(BipexResourceManager.GetResourceString("MSG_GENERALNETWORKERROR"));
				return;
			}

			string cf = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
			RemConfig.ClientConfig(cf, typeof (IEcho).Assembly);

			Application.EnableVisualStyles();
			Application.DoEvents();
			Application.Run(new EngineMainForm());

		}

		private static bool CheckArgs(string[] args)
		{
			if (args.Length == 0)
			{
				// Qui NON SI PUO' usare BipexResourceManager.GetResourceString perche' il file delle risorse NON E' CARICATO!!!
				MessageBox.Show("YOU MUST RUN Bipex_Host.\nYOU CANNOT RUN Bipex_Engine DIRECTLY !", "Warning");
				return false;
			}

			try
			{
				string s = args[0];

				if (s != "ASTROLABIO")
				{
					int a = int.Parse(s.Substring(0, 5), NumberStyles.HexNumber);
					int b = int.Parse(s.Substring(5, 5), NumberStyles.HexNumber);
					int c = int.Parse(s.Substring(10, 5), NumberStyles.HexNumber);
					if ((a ^ b) != c)
					{
						// Qui NON SI PUO' usare BipexResourceManager.GetResourceString perche' il file delle risorse NON E' CARICATO!!!
						MessageBox.Show("YOU MUST RUN Bipex_Host.\nYOU CANNOT RUN Bipex_Engine DIRECTLY !", "Warning");
						return false;
					}
				}
			}
			catch
			{
				// Qui NON SI PUO' usare BipexResourceManager.GetResourceString perche' il file delle risorse NON E' CARICATO!!!
				MessageBox.Show("YOU MUST RUN Bipex_Host.\nYOU CANNOT RUN Bipex_Engine DIRECTLY !", "Warning");
				return false;
			}

			return true;
		}

		public EngineMainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// Memorizzo il Title del form stabilito a design time perche'
			// a run time lo devo concatenare con altre info...
			_sThisFormTitle = this.Text;

			_style = VisualStyle.IDE;
			// BorderStyle bs = (_style == VisualStyle.Plain) ? BorderStyle.None : BorderStyle.FixedSingle;

			// Create the object that manages the docking state
			_manager = new DockingManager(this, _style);

			// Notifications
			_manager.ContextMenu += new DockingManager.ContextMenuHandler(OnContextMenu);
			_manager.ContentHiding += new DockingManager.ContentHidingHandler(OnContentHiding);
			_manager.TabControlCreated += new DockingManager.TabControlCreatedHandler(OnTabControlCreated);

			// =================================================================================
			// Creo i TabControls, ci aggiungo i TabPages assegnati a ciascuno di essi,
			// ed infine aggiungo i TabControls al Docking Mgr...
			
			// =================================================================================
			// Top Right Frame: Book Riassuntivo (in PRIMO PIANO), Quadro Comandi, Fasi di Negoziazione

			CreateTopRightFrame();

			// =================================================================================
			// Left Frame: Single Contract Book

			CreateLeftFrame();
			
			// =================================================================================
			// Bottom Frame: Contract Detail (in PRIMO PIANO), Calendario Delivery

			CreateBottomFrame();

			// =================================================================================

			// !!!ATTENZIONE!!! VINCOLO ALLA SEQUENZA DI CREAZIONE DEL FORM!!! I menu' vanno
			// creati DOPO i forms, e quindi dopo le tabpages, i tabcontrols, etc..., perche'
			// fanno riferimento agli handlers dei form stessi che quindi DEVONO esistere!!!
			CreateMenus();

			// =================================================================================

			// Create and setup the StatusBar object
			_statusBar = new StatusBar();
			_statusBar.Dock = DockStyle.Bottom;
			_statusBar.ShowPanels = true;

			// Status Bar per lo stato della comunicazione
			_sbpCommunication = new StatusBarPanel();
			_sbpCommunication.Alignment = HorizontalAlignment.Left;
			_sbpCommunication.AutoSize = StatusBarPanelAutoSize.Spring;
			_sbpCommunication.BorderStyle = StatusBarPanelBorderStyle.Raised;
			_statusBar.Panels.Add(_sbpCommunication);

			// Status Bar per lo stato del refresh, pilotato dall'operatore
			_sbpRefresh = new StatusBarPanel();
			_sbpRefresh.Alignment = HorizontalAlignment.Left;
			_sbpRefresh.AutoSize = StatusBarPanelAutoSize.Spring;
			_sbpRefresh.BorderStyle = StatusBarPanelBorderStyle.Raised;
			_statusBar.Panels.Add(_sbpRefresh);

			// Inserisco delle status bar "filler" per ottenere un miglior
			// posizionamento di quelle effettivamente presenti (a sx)
			// StatusBarPanel spbDummy1 = new StatusBarPanel();
			// spbDummy1.AutoSize = StatusBarPanelAutoSize.Spring;
			// _statusBar.Panels.Add(spbDummy1);
			// StatusBarPanel spbDummy2 = new StatusBarPanel();
			// spbDummy2.AutoSize = StatusBarPanelAutoSize.Spring;
			// _statusBar.Panels.Add(spbDummy2);
			// StatusBarPanel spbDummy3 = new StatusBarPanel();
			// spbDummy3.AutoSize = StatusBarPanelAutoSize.Spring;
			// _statusBar.Panels.Add(spbDummy3);
			// StatusBarPanel spbDummy4 = new StatusBarPanel();
			// spbDummy4.AutoSize = StatusBarPanelAutoSize.Spring;
			// _statusBar.Panels.Add(spbDummy4);
			// StatusBarPanel spbDummy5 = new StatusBarPanel();
			// spbDummy5.AutoSize = StatusBarPanelAutoSize.Spring;
			// _statusBar.Panels.Add(spbDummy5);

			// Status Bar per lo stato della sessione di mercato
			_sbpBipexMktCurrSess = new StatusBarPanel();
			_sbpBipexMktCurrSess.Alignment = HorizontalAlignment.Right;
			_sbpBipexMktCurrSess.AutoSize = StatusBarPanelAutoSize.Spring;
			_sbpBipexMktCurrSess.BorderStyle = StatusBarPanelBorderStyle.Raised;
			_statusBar.Panels.Add(_sbpBipexMktCurrSess);

			Controls.Add(_statusBar);

			SetStatusBarOnCommStatusChanged("");
			SetStatusBarOnRefreshStatusChanged();
			SetStatusBarOnBipexMktCurrSessStatusChanged();

			// Ensure that docking occurs after the menu control and status bar controls
			_manager.OuterControl = _statusBar;

			// In questo momento NON C'E' un login attivo (TradingSessionParameters = VUOTO),
			// faccio le impostazioni iniziali...
			SetRefreshStatusOnTradingSessionParameters();
			SetFormControlsOnTradingSessionParameters();

			// DA FARE MB
			// DA FARE MB
			// DA FARE MB
			// PRIMA O POI ANDRA' CAPITO COME FUNZIONANO QUESTI METODI...
			//_manager.SaveCustomConfig += new DockingManager.SaveCustomConfigHandler(OnSaveConfig);
			//_manager.LoadCustomConfig += new DockingManager.LoadCustomConfigHandler(OnLoadConfig);
			//
			// La logica "standard" di Save si � intanto capito che non si pu� utilizzare 
			// in quanto � basata sui content titles che noi modifichiamo dinamicamente
			// in base alla frame attiva... vedere il contenuto del file qui sotto...
			//
			// if (File.Exists("C:\\MICHELE\\TMP\\EngineMainForm.xml"))
			//		_manager.LoadConfigFromFile("C:\\MICHELE\\TMP\\EngineMainForm.xml");

		}

		private void CreateTopRightFrame()
		{

			_tcTopRightFrame = new Crownwood.Magic.Controls.TabControl();

			_frmBook = new frmBook();
			_tpBookRiassuntivo = new TabPage(_frmBook.Text, _frmBook);
			_tpBookRiassuntivo.Tag = EngineMainForm.TabPageGeneric;

			_stpBInitialTitle = _tpBookRiassuntivo.Title;
			_tpBookRiassuntivo.Selected = true;	// in PRIMO PIANO

			_tcTopRightFrame.TabPages.Add(_tpBookRiassuntivo);

			_frmQuadroComandi = new frmQuadroComandi();
			_tpQuadroComandi = new TabPage(_frmQuadroComandi.Text, _frmQuadroComandi);
			_tpQuadroComandi.Tag = EngineMainForm.TabPageGeneric;
			
			_tcTopRightFrame.TabPages.Add(_tpQuadroComandi);

			_frmFasiNegoziazione = new frmFasiNegoziazione();
			_tpFasiNegoziazione = new TabPage(_frmFasiNegoziazione.Text, _frmFasiNegoziazione);
			_tpFasiNegoziazione.Tag = EngineMainForm.TabPageGeneric;
			
			_tcTopRightFrame.TabPages.Add(_tpFasiNegoziazione);

			// MultiDocument: Tabs delle singole TabPages IN ALTO
			_tcTopRightFrame.Appearance = Crownwood.Magic.Controls.TabControl.VisualAppearance.MultiDocument;

			_tcTopRightFrame.Dock = DockStyle.Fill;
			_tcTopRightFrame.Style = _style;
			_tcTopRightFrame.IDEPixelBorder = true;

			// Eventi a gestire per il TabControl
			_tcTopRightFrame.SelectionChanged += new EventHandler(On_tcTopRightFrame_SelectionChanged);

			Controls.Add(_tcTopRightFrame);

			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// faccio la impostazione iniziale...
			SetTRFContentFullTitleOnTRFCurrentForm();

			// Reduce the amount of flicker that occurs when windows are redocked within
			// the container. As this prevents unsightly backcolors being drawn in the
			// WM_ERASEBACKGROUND that seems to occur.
			SetStyle(ControlStyles.DoubleBuffer, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);

			// Con questa impostazione di fatto la Top Right Frame 
			// (quella che contiene il book) NON E' MAI DOCKABLE!!!
			_manager.InnerControl = _tcTopRightFrame;

		}

		private void CreateLeftFrame()
		{
			int iWidth = 0;
			int iHeight = 0;

			_tcLeftFrame = new TabControl();
			
			_frmBookSingoloContratto = new frmBookSingoloContratto();
			// Ogni volta che aggiungo un form al tab control prendo le sue
			// dimensioni per dimensionare il tab control, alla fine delle add
			// delle singole tabpages, in base al form piu' grande che deve
			// contenere...
			if (_frmBookSingoloContratto.Size.Width > iWidth)
				iWidth = _frmBookSingoloContratto.Size.Width;
			if (_frmBookSingoloContratto.Size.Height > iHeight)
				iHeight = _frmBookSingoloContratto.Size.Height;

			_tpBookSingoloContratto = new TabPage(_frmBookSingoloContratto.Text, _frmBookSingoloContratto);
			_tpBookSingoloContratto.Tag = EngineMainForm.TabPageContractData;

			_tpBookSingoloContratto.Selected = true;	// in PRIMO PIANO
			_tcLeftFrame.TabPages.Add(_tpBookSingoloContratto);

			// MultiDocument: Tabs delle singole TabPages IN ALTO
			_tcLeftFrame.Appearance = Crownwood.Magic.Controls.TabControl.VisualAppearance.MultiDocument;
			_tcLeftFrame.ShowClose = true;

			// Dato che questa frame contiene UNA SOLA TABPAGE, 
			// non faccio vedere il Tab di Scelta per risparmiare spazio...

			_tcLeftFrame.HideTabsMode = Crownwood.Magic.Controls.TabControl.HideTabsModes.HideAlways;

			// Eventi a gestire per il TabControl
			_tcLeftFrame.ClosePressed += new EventHandler(On_tcLeftFrame_ClosePressed);
			_tcLeftFrame.SelectionChanged += new EventHandler(On_tcLeftFrame_SelectionChanged);
			
			Controls.Add(_tcLeftFrame);
			_coLeftFrame = _manager.Contents.Add(_tcLeftFrame);

			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// faccio la impostazione iniziale...
			SetLFContentFullTitleOnLFCurrentForm();

			// DisplaySize del Left Frame impostata in base alla size dei forms
			// contenuti, Width e Height - 5% perche' il bordo del form non e'
			// contenuto nella TabPage...
			_coLeftFrame.DisplaySize = new Size(iWidth * 95 / 100, iHeight * 95 / 100);
			_manager.AddContentWithState(_coLeftFrame, State.DockLeft);
			
		}

		private void CreateBottomFrame()
		{
			int iWidth = 0;
			int iHeight = 0;

			_tcBottomFrame = new TabControl();
			
			_frmDailyActivity = new frmDailyActivity();
			// Ogni volta che aggiungo un form al tab control prendo le sue
			// dimensioni per dimensionare il tab control, alla fine delle add
			// delle singole tabpages, in base al form piu' grande che deve
			// contenere...
			if (_frmDailyActivity.Size.Width > iWidth)
				iWidth = _frmDailyActivity.Size.Width;
			if (_frmDailyActivity.Size.Height > iHeight)
				iHeight = _frmDailyActivity.Size.Height;

			_tpDailyActivity = new TabPage(_frmDailyActivity.Text, _frmDailyActivity);
			_tpDailyActivity.Tag = EngineMainForm.TabPageOperatorUserData;

			_tpDailyActivity.Selected = true;	// in PRIMO PIANO
			_tcBottomFrame.TabPages.Add(_tpDailyActivity);

			_frmOpenOrders = new frmOpenOrders();
			if (_frmOpenOrders.Size.Width > iWidth)
				iWidth = _frmOpenOrders.Size.Width;
			if (_frmOpenOrders.Size.Height > iHeight)
				iHeight = _frmOpenOrders.Size.Height;

			_tpOpenOrders = new TabPage(_frmOpenOrders.Text, _frmOpenOrders);
			_tpOpenOrders.Tag = EngineMainForm.TabPageOperatorUserData;

			_tpOpenOrders.Selected = true;	// in PRIMO PIANO
			_tcBottomFrame.TabPages.Add(_tpOpenOrders);

			_frmSaldoFisico = new frmSaldoFisico();
			if (_frmSaldoFisico.Size.Width > iWidth)
				iWidth = _frmSaldoFisico.Size.Width;
			if (_frmSaldoFisico.Size.Height > iHeight)
				iHeight = _frmSaldoFisico.Size.Height;

			_tpSaldoFisico = new TabPage(_frmSaldoFisico.Text, _frmSaldoFisico);
			_tpSaldoFisico.Tag = EngineMainForm.TabPageOperatorUserData;

			_tpSaldoFisico.Selected = true;	// in PRIMO PIANO
			_tcBottomFrame.TabPages.Add(_tpSaldoFisico);
			
			_frmDettagliContratto = new frmDettagliContratto();
			if (_frmDettagliContratto.Size.Width > iWidth)
				iWidth = _frmDettagliContratto.Size.Width;
			if (_frmDettagliContratto.Size.Height > iHeight)
				iHeight = _frmDettagliContratto.Size.Height;

			/*
			 * RIUNIONE TELEFONICA LEO-MICHELE 12.10.2005 POM.
			 * DATO CHE PER ORA IL FORM E' VUOTO PERCHE' NON SI SA COSA METTERCI, LA TABPAGE NON LA SI CREA E
			 * NON LA SI AGGIUNGE AL TAB CONTROL...
			 * 
			_tpDettagliContratto = new TabPage(_frmDettagliContratto.Text, _frmDettagliContratto);
			_tpDettagliContratto.Tag = EngineMainForm.TabPageContractData;

			_tpDettagliContratto.Selected = true;	// in PRIMO PIANO
			_tcBottomFrame.TabPages.Add(_tpDettagliContratto);
			*/

			_frmCalendarioDelivery = new frmCalendarioDelivery();
			if (_frmCalendarioDelivery.Size.Width > iWidth)
				iWidth = _frmCalendarioDelivery.Size.Width;
			if (_frmCalendarioDelivery.Size.Height > iHeight)
				iHeight = _frmCalendarioDelivery.Size.Height;

			_tpCalendarioDelivery = new TabPage(_frmCalendarioDelivery.Text, _frmCalendarioDelivery);
			_tpCalendarioDelivery.Tag = EngineMainForm.TabPageContractData;

			_tpCalendarioDelivery.Selected = true;	// in PRIMO PIANO
			_tcBottomFrame.TabPages.Add(_tpCalendarioDelivery);

			_frmNotes = new RichTextBox();
			_frmNotes.Text = "<<You can write Your Note here>>";
			_tpNotes = new TabPage("Notes", _frmNotes);
			_tpNotes.Tag = EngineMainForm.TabPageGeneric;

			_tpNotes.Selected = true;	// in PRIMO PIANO
			_tcBottomFrame.TabPages.Add(_tpNotes);

			_tpDailyActivity.Selected = true;	// in PRIMO PIANO

			// MultiForm: Tabs delle singole TabPages IN BASSO
			_tcBottomFrame.Appearance = Crownwood.Magic.Controls.TabControl.VisualAppearance.MultiForm;
			_tcBottomFrame.ShowClose = false;

			// Eventi a gestire per il TabControl
			_tcBottomFrame.ClosePressed += new EventHandler(On_tcBottomFrame_ClosePressed);
			_tcBottomFrame.SelectionChanged += new EventHandler(On_tcBottomFrame_SelectionChanged);
			
			Controls.Add(_tcBottomFrame);
			_coBottomFrame = _manager.Contents.Add(_tcBottomFrame);
			
			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// faccio la impostazione iniziale...
			SetBFContentFullTitleOnBFCurrentForm();

			// DisplaySize del Bottom Frame impostata in base alla size dei forms
			// contenuti, Width e Height - 5% perche' il bordo del form non e'
			// contenuto nella TabPage...
			_coBottomFrame.DisplaySize = new Size(iWidth * 95 / 100, iHeight * 95 / 100);
			_manager.AddContentWithState(_coBottomFrame, State.DockBottom);

		}

		private void CreateMenus()
		{
			MenuControl topMenu = new MenuControl();
			topMenu.Style = _style;
			topMenu.MultiLine = false;

			_menuMain = new MenuCommand("Main");
			_menuFile = new MenuCommand("File");
			_menuBookTrading = new MenuCommand("Main Book Trading");
			_menuBookLayout = new MenuCommand("Main Book Layout");
			_menuOpenOrders = new MenuCommand("Open Orders Actions");
			_menuSaldoFisico = new MenuCommand("Physical Balance Actions");
			_menuReport = new MenuCommand("Report");
			
			topMenu.MenuCommands.AddRange(new MenuCommand[] {_menuMain, _menuFile, _menuBookTrading, _menuBookLayout, _menuOpenOrders, _menuSaldoFisico, _menuReport});

			MenuCommand topMainC1 = new MenuCommand(_sLoginToBipex, new EventHandler(this.OnLoginToBipex));
			topMainC1.Shortcut = Shortcut.CtrlL;
			_menuMain.MenuCommands.Add(topMainC1);
			MenuCommand topMainC2 = new MenuCommand(_sShowWelcome, new EventHandler(this.OnShowWelcome));
			_menuMain.MenuCommands.Add(topMainC2);
			MenuCommand topMainC3 = new MenuCommand(_sLogoffFromBipex, new EventHandler(this.OnLogoffFromBipex));
			topMainC3.Shortcut = Shortcut.CtrlX;
			_menuMain.MenuCommands.Add(topMainC3);

			MenuCommand topFileC1 = new MenuCommand("Open Notes", new EventHandler(this.OnOpenNotes));
			_menuFile.MenuCommands.Add(topFileC1);
			MenuCommand topFileC2 = new MenuCommand("Save Notes", new EventHandler(this.OnSaveNotes));
			_menuFile.MenuCommands.Add(topFileC2);

			MenuCommand topBookTradingC1 = new MenuCommand(_sBuyCurrentContract, new EventHandler(this._frmBook.cmMainDG_Buy_Clicked));
			topBookTradingC1.Shortcut = Shortcut.CtrlB;
			_menuBookTrading.MenuCommands.Add(topBookTradingC1);
			MenuCommand topBookTradingC2 = new MenuCommand(_sSellCurrentContract, new EventHandler(this._frmBook.cmMainDG_Sell_Clicked));
			topBookTradingC2.Shortcut = Shortcut.CtrlS;
			_menuBookTrading.MenuCommands.Add(topBookTradingC2);
			MenuCommand topBookTradingC3 = new MenuCommand("&Help", new EventHandler(this._frmBook.cmMainDG_Help_Clicked));
			topBookTradingC3.Shortcut = Shortcut.CtrlH;
			_menuBookTrading.MenuCommands.Add(topBookTradingC3);

			MenuCommand topBookLayoutC1 = new MenuCommand("Sort", new EventHandler(this._frmBook.btnColPos_Click));
			_menuBookLayout.MenuCommands.Add(topBookLayoutC1);
			MenuCommand topBookLayoutC2 = new MenuCommand("Filter", new EventHandler(this.OnBookFilter));
			_menuBookLayout.MenuCommands.Add(topBookLayoutC2);
			MenuCommand topBookLayoutC3 = new MenuCommand("Zoom+", new EventHandler(this._frmBook.btnFontPIU_Click));
			_menuBookLayout.MenuCommands.Add(topBookLayoutC3);
			MenuCommand topBookLayoutC4 = new MenuCommand("Zoom-", new EventHandler(this._frmBook.btnFontMENO_Click));
			_menuBookLayout.MenuCommands.Add(topBookLayoutC4);
			MenuCommand topBookLayoutC5 = new MenuCommand("Refresh ON", new EventHandler(this.OnRefreshON));
			_menuBookLayout.MenuCommands.Add(topBookLayoutC5);
			MenuCommand topBookLayoutC6 = new MenuCommand("Refresh OFF", new EventHandler(this.OnRefreshOFF));
			_menuBookLayout.MenuCommands.Add(topBookLayoutC6);

			MenuCommand topOpenOrdersC1 = new MenuCommand("Modify", new EventHandler(this._frmOpenOrders.cmMainDG_Modify_Clicked));
			_menuOpenOrders.MenuCommands.Add(topOpenOrdersC1);
			MenuCommand topOpenOrdersC2 = new MenuCommand("Revoke", new EventHandler(this._frmOpenOrders.cmMainDG_Revoke_Clicked));
			_menuOpenOrders.MenuCommands.Add(topOpenOrdersC2);
			MenuCommand topOpenOrdersC3 = new MenuCommand("Hide", new EventHandler(this._frmOpenOrders.cmMainDG_Hide_Clicked));
			_menuOpenOrders.MenuCommands.Add(topOpenOrdersC3);
			MenuCommand topOpenOrdersC4 = new MenuCommand("Reveal", new EventHandler(this._frmOpenOrders.cmMainDG_Reveal_Clicked));
			_menuOpenOrders.MenuCommands.Add(topOpenOrdersC4);
			MenuCommand topOpenOrdersC5 = new MenuCommand("Revoke ALL", new EventHandler(this._frmOpenOrders.cmMainDG_RevokeALL_Clicked));
			_menuOpenOrders.MenuCommands.Add(topOpenOrdersC5);
			MenuCommand topOpenOrdersC6 = new MenuCommand("Hide ALL", new EventHandler(this._frmOpenOrders.cmMainDG_HideALL_Clicked));
			_menuOpenOrders.MenuCommands.Add(topOpenOrdersC6);
			MenuCommand topOpenOrdersC7 = new MenuCommand("Reveal ALL", new EventHandler(this._frmOpenOrders.cmMainDG_RevealALL_Clicked));
			_menuOpenOrders.MenuCommands.Add(topOpenOrdersC7);
			
			MenuCommand topSaldoFisicoC1 = new MenuCommand("Change Reference Date", new EventHandler(this._frmSaldoFisico.cmMainDG_ChangeReferenceDate_Clicked));
			_menuSaldoFisico.MenuCommands.Add(topSaldoFisicoC1);
			MenuCommand topSaldoFisicoC2 = new MenuCommand("Show Unit Detail", new EventHandler(this._frmSaldoFisico.cmMainDG_ShowUnitDetail_Clicked));
			_menuSaldoFisico.MenuCommands.Add(topSaldoFisicoC2);
			MenuCommand topSaldoFisicoC3 = new MenuCommand("Hide Unit Detail", new EventHandler(this._frmSaldoFisico.cmMainDG_HideUnitDetail_Clicked));
			_menuSaldoFisico.MenuCommands.Add(topSaldoFisicoC3);

			MenuCommand topReportC1 = new MenuCommand("Session History", new EventHandler(this.OnRptSessionHistory));
			_menuReport.MenuCommands.Add(topReportC1);
			MenuCommand topReportC2 = new MenuCommand("Price History", new EventHandler(this.OnRptPriceHistory));
			_menuReport.MenuCommands.Add(topReportC2);
			MenuCommand topReportC3 = new MenuCommand("Single Contract Price History", new EventHandler(this.OnRptSingleContractPriceHistory));
			_menuReport.MenuCommands.Add(topReportC3);
			MenuCommand topReportC4 = new MenuCommand("Single Contract Price Trend", new EventHandler(this.OnRptSingleContractPriceTrend));
			_menuReport.MenuCommands.Add(topReportC4);

			topMenu.Dock = DockStyle.Top;

			topMenu.Selected += new CommandHandler(OnSelected);
			topMenu.Deselected += new CommandHandler(OnDeselected);

			Controls.Add(topMenu);

		}

		/// <summary>
		/// Imposta icona e testo della status bar apposita in funzione dello 
		/// stato della comunicazione 
		/// </summary>
		/// <param name="UserMessage">Un messaggio "User Specific" che viene 
		/// CONCATENATO, senza blanks intermedi (che sono quindi a carico
		/// del chiamante), allo Status Bar Text DOPO il testo standard
		/// previsto in funzione dello stato della comunicazione</param>
		private void SetStatusBarOnCommStatusChanged(string UserMessage)
		{
			switch (_tspParams.enCommStatus)
			{
				case CommStatus.Starting:
					_sbpCommunication.Text = "Starting..."+UserMessage;
					_sbpCommunication.Icon = this._niCommKO.Icon;
					break;
				case CommStatus.NoCommunication:
					_sbpCommunication.Text = "No Communication"+UserMessage;
					_sbpCommunication.Icon = this._niCommKO.Icon;
					break;
				case CommStatus.RequestSent:
					_sbpCommunication.Text = "Request Sent"+UserMessage;
					_sbpCommunication.Icon = this._niCommPending.Icon;
					break;
				case CommStatus.ResponseReceived:
					_sbpCommunication.Text = "Response Acquired"+UserMessage;
					_sbpCommunication.Icon = this._niCommOK.Icon;
					break;
			}
		}

		/// <summary>
		/// Imposta icona e testo della status bar apposita in funzione dello 
		/// stato del refresh richiesto dall'operatore
		/// </summary>
		private void SetStatusBarOnRefreshStatusChanged()
		{
			if (_tspParams.enRefreshStatus == RefreshStatus.Off)
			{
				_sbpRefresh.Text = "Refresh is OFF";
				_sbpRefresh.Icon = this._niCommFrozen.Icon;
			}
			else
			{
				_sbpRefresh.Text = "Refresh is ON";
				_sbpRefresh.Icon = this._niCommOK.Icon;
			}
		}

		/// <summary>
		/// Imposta icona e testo della status bar apposita
		/// in funzione dello stato della sessione di mercato
		/// </summary>
		private void SetStatusBarOnBipexMktCurrSessStatusChanged()
		{
			switch (_tspParams.enBipexMktCurrSessStatus)
			{
				case MarketSessionDR.eStatoSessione.APERTA:
					_sbpBipexMktCurrSess.Text = "BIPEX Market - Current Session is OPEN";
					_sbpBipexMktCurrSess.Icon = this._niMarketOpen.Icon;
					break;
				case MarketSessionDR.eStatoSessione.SOSPESA:
					_sbpBipexMktCurrSess.Text = "BIPEX Market - Current Session is SUSPENDED";
					_sbpBipexMktCurrSess.Icon = this._niMarketSuspended.Icon;
					break;
				case MarketSessionDR.eStatoSessione.NUOVA:
				case MarketSessionDR.eStatoSessione.PREDISPOSTA:
				case MarketSessionDR.eStatoSessione.TERMINATA:
				case MarketSessionDR.eStatoSessione.CHIUSA:
					_sbpBipexMktCurrSess.Text = "BIPEX Market - Current Session is CLOSED";
					_sbpBipexMktCurrSess.Icon = this._niMarketClosed.Icon;
					break;
			}
		}
		
		/// <summary>
		/// Imposta lo stato del refresh in funzione della presenza o meno
		/// di un login attivo
		/// </summary>
		private void SetRefreshStatusOnTradingSessionParameters()
		{
			// Il refresh e' attivo se c'e' un login attivo...
			if (EngineMainForm._tspParams.LoginActive)
			{
				this._documentStreamer.Refresh = true;
				_tspParams.enRefreshStatus = RefreshStatus.On;
				SetStatusBarOnRefreshStatusChanged();
			}
			else
			{
				this._documentStreamer.Refresh = false;
				_tspParams.enRefreshStatus = RefreshStatus.Off;
				SetStatusBarOnRefreshStatusChanged();
			}
		}

		/// <summary>
		/// Imposta lo stato di tutti i controlli della form 
		/// in funzione della presenza o meno di un login attivo
		/// </summary>
		private void SetFormControlsOnTradingSessionParameters()
		{
			if (!EngineMainForm._tspParams.LoginActive)
			{
				this.Text = _sThisFormTitle + " - Current User is <NONE>";

				this._menuMain.MenuCommands[_sLoginToBipex].Enabled = true;
				this._menuMain.MenuCommands[_sShowWelcome].Enabled = false;
				this._menuMain.MenuCommands[_sLogoffFromBipex].Enabled = false;
				
				this._menuFile.Enabled = false;
				
				this._menuBookTrading.Enabled = false;
				this._menuBookTrading.MenuCommands[_sBuyCurrentContract].Enabled = false;
				this._menuBookTrading.MenuCommands[_sSellCurrentContract].Enabled = false;
				
				this._menuBookLayout.Enabled = false;
				this._menuOpenOrders.Enabled = false;
				this._menuSaldoFisico.Enabled = false;
				this._menuReport.Enabled = false;

				this._tcTopRightFrame.Enabled = false;
				this._tcLeftFrame.Enabled = false;
				this._tcBottomFrame.Enabled = false;

				// Non c'e' un Login attivo, RIMUOVO A PRESCINDERE tutte le tabpages
				// la cui presenza e' condizionata dal ruolo dell'utente collegato...

				if (_tcTopRightFrame.TabPages.Contains(_tpQuadroComandi))
					_tcTopRightFrame.TabPages.Remove(_tpQuadroComandi);
				if (_tcTopRightFrame.TabPages.Contains(_tpFasiNegoziazione))
					_tcTopRightFrame.TabPages.Remove(_tpFasiNegoziazione);
			}
			else
			{
				this.Text = _sThisFormTitle + " - Current User is " + EngineMainForm._tspParams.ActiveUser + " (" + EngineMainForm._tspParams.ActiveRole + ")";

				this._menuMain.MenuCommands[_sLoginToBipex].Enabled = false;
				this._menuMain.MenuCommands[_sShowWelcome].Enabled = true;
				this._menuMain.MenuCommands[_sLogoffFromBipex].Enabled = true;

				this._menuFile.Enabled = true;

				this._menuBookTrading.Enabled = true;
				this._menuBookTrading.MenuCommands[_sBuyCurrentContract].Enabled = true;
				this._menuBookTrading.MenuCommands[_sSellCurrentContract].Enabled = true;

				this._menuBookLayout.Enabled = true;
				this._menuOpenOrders.Enabled = true;
				this._menuSaldoFisico.Enabled = true;
				this._menuReport.Enabled = true;

				this._tcTopRightFrame.Enabled = true;
				this._tcLeftFrame.Enabled = true;
				this._tcBottomFrame.Enabled = true;

				// C'e' un login attivo, aggiungo dinamicamente le tabpages
				// in base al ruolo dell'utente collegato

				if (EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorFull)
				{
					if (!_tcTopRightFrame.TabPages.Contains(_tpQuadroComandi))
						_tcTopRightFrame.TabPages.Add(_tpQuadroComandi);

					if (!_tcTopRightFrame.TabPages.Contains(_tpFasiNegoziazione))
						_tcTopRightFrame.TabPages.Add(_tpFasiNegoziazione);

				}
				if (EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorAccountant)
				{
					if (!_tcTopRightFrame.TabPages.Contains(_tpQuadroComandi))
						_tcTopRightFrame.TabPages.Add(_tpQuadroComandi);

					if (_tcTopRightFrame.TabPages.Contains(_tpFasiNegoziazione))
						_tcTopRightFrame.TabPages.Remove(_tpFasiNegoziazione);

				}
				else
					if (EngineMainForm._tspParams.ActiveRole == Ruolo.UserFull ||
					EngineMainForm._tspParams.ActiveRole == Ruolo.UserViewer)
				{
					if (_tcTopRightFrame.TabPages.Contains(_tpQuadroComandi))
						_tcTopRightFrame.TabPages.Remove(_tpQuadroComandi);

					if (!_tcTopRightFrame.TabPages.Contains(_tpFasiNegoziazione))
						_tcTopRightFrame.TabPages.Add(_tpFasiNegoziazione);
				}
			
			}

			// Imposto lo stato dei menu bar in alto in base alle tabpages selezionate
			// nei rispettivi tabcontrols...
			SetMenuOnTopRightFrameSelectionChanged();
			SetMenuOnLeftFrameSelectionChanged();
			SetMenuOnBottomFrameSelectionChanged();
		
		}

		private void SetMenuOnTopRightFrameSelectionChanged()
		{
			// Abilito o meno gli items dei menu command a seconda della TabPage
			// selezionata...
			if (!EngineMainForm._tspParams.LoginActive)
			{
				this._menuBookTrading.Enabled = false;
				this._menuBookLayout.Enabled = false;
			}
			else
			{
				if (this._tcTopRightFrame.SelectedTab.Title == this._tpBookRiassuntivo.Title)
				{
					this._menuBookTrading.Enabled = true;
					this._menuBookLayout.Enabled = true;
				}
				else
				{
					this._menuBookTrading.Enabled = false;
					this._menuBookLayout.Enabled = false;
				}
			}
		}

		private void SetMenuOnLeftFrameSelectionChanged()
		{
			// Per ora questa frame ha un solo form e non prevede gestione
			// dinamica dei menu' in base al form selezionato...
		}
		
		private void SetMenuOnBottomFrameSelectionChanged()
		{
			// Abilito o meno gli items dei menu command a seconda della TabPage
			// selezionata...
			if (!EngineMainForm._tspParams.LoginActive)
			{
				this._menuOpenOrders.Enabled = false;
				this._menuSaldoFisico.Enabled = false;
			}
			else
			{
				if (this._tcBottomFrame.SelectedTab.Title == this._tpOpenOrders.Title)
				{
					this._menuOpenOrders.Enabled = true;
				}
				else
				{
					this._menuOpenOrders.Enabled = false;
				}
				if (this._tcBottomFrame.SelectedTab.Title == this._tpSaldoFisico.Title)
				{
					this._menuSaldoFisico.Enabled = true;
				}
				else
				{
					this._menuSaldoFisico.Enabled = false;
				}
			}
		}

		/// <summary>
		/// Avverte i Forms figli che hanno bisogno di saperlo che c'� un nuovo Login...
		/// </summary>
		private void NotifyLoginStatusToChildForms()
		{
			_frmDailyActivity.SetFilterOnCurrentOperator();
			_frmOpenOrders.SetFilterOnCurrentOperator();
			// Per quanto riguarda il form del Saldo Fisico, quando cambia l'operatore
			// collegato, se reimposta anche la data di riferimento 
			// per il form corrente (che visualizza il Saldo Fisico riferito ad una certa data)
			_frmSaldoFisico.SetFilterOnCurrentOperator();
			_frmSaldoFisico.SetCurrentSFDate(DateTime.Today);
		}

		/// <summary>
		/// Avverte i Forms figli che hanno bisogno di saperlo che NON c'� un Login ATTIVO...
		/// </summary>
		private void NotifyLogoffStatusToChildForms()
		{
			_frmDailyActivity.ResetFilterOnCurrentOperator();
			_frmOpenOrders.ResetFilterOnCurrentOperator();
			// Per quanto riguarda il form del Saldo Fisico, quando cambia l'operatore
			// collegato, se reimposta anche la data di riferimento 
			// per il form corrente (che visualizza il Saldo Fisico riferito ad una certa data)
			_frmSaldoFisico.ResetFilterOnCurrentOperator();
			_frmSaldoFisico.ResetCurrentSFDate();
		}

		/// <summary>
		/// Aggiorna il  titolo del content in funzione del titolo della
		/// tab page selezionata ed in funzione di contratto / operatore corrente
		/// </summary>
		private void SetTRFContentFullTitleOnTRFCurrentForm()
		{
			// !!! ATTENZIONE !!! Per ora questa frame non prevede gestione del content...
			// !!! ATTENZIONE !!! Per ora questa frame non prevede gestione del content...
			// !!! ATTENZIONE !!! Per ora questa frame non prevede gestione del content...
		}

		/// <summary>
		/// Aggiorna il  titolo del content in funzione del titolo della
		/// tab page selezionata ed in funzione di contratto / operatore corrente
		/// </summary>
		private void SetLFContentFullTitleOnLFCurrentForm()
		{
			if (this._tcLeftFrame.SelectedTab.Tag.ToString() == EngineMainForm.TabPageContractData && _tspParams.LoginActive)
			{
				_coLeftFrame.Title = this._tcLeftFrame.SelectedTab.Title + " " + _tspParams.CurrentContract;
				_coLeftFrame.FullTitle = this._tcLeftFrame.SelectedTab.Title + " " + _tspParams.CurrentContract;
			}
			else
				if (this._tcLeftFrame.SelectedTab.Tag.ToString() == EngineMainForm.TabPageOperatorUserData && _tspParams.LoginActive)
				{
					_coLeftFrame.Title = this._tcLeftFrame.SelectedTab.Title + " " + _tspParams.ActiveOperator + " / " + _tspParams.ActiveUser;
					_coLeftFrame.FullTitle = this._tcLeftFrame.SelectedTab.Title + " " + _tspParams.ActiveOperator + " / " + _tspParams.ActiveUser;
				}
				else
				{
					_coLeftFrame.Title = this._tcLeftFrame.SelectedTab.Title;
					_coLeftFrame.FullTitle = this._tcLeftFrame.SelectedTab.Title;
				}
		}

		/// <summary>
		/// Aggiorna il  titolo del content in funzione del titolo della
		/// tab page selezionata ed in funzione di contratto / operatore corrente
		/// </summary>
		private void SetBFContentFullTitleOnBFCurrentForm()
		{
			if (this._tcBottomFrame.SelectedTab.Tag.ToString() == EngineMainForm.TabPageContractData && _tspParams.LoginActive)
			{
				_coBottomFrame.Title = this._tcBottomFrame.SelectedTab.Title + " " + _tspParams.CurrentContract;
				_coBottomFrame.FullTitle = this._tcBottomFrame.SelectedTab.Title + " " + _tspParams.CurrentContract;
			}
			else
				if (this._tcBottomFrame.SelectedTab.Tag.ToString() == EngineMainForm.TabPageOperatorUserData && _tspParams.LoginActive)
				{
					_coBottomFrame.Title = this._tcBottomFrame.SelectedTab.Title + " " + _tspParams.ActiveOperator + " / " + _tspParams.ActiveUser;
					_coBottomFrame.FullTitle = this._tcBottomFrame.SelectedTab.Title + " " + _tspParams.ActiveOperator + " / " + _tspParams.ActiveUser;
				}
				else
				{
					_coBottomFrame.Title = this._tcBottomFrame.SelectedTab.Title;
					_coBottomFrame.FullTitle = this._tcBottomFrame.SelectedTab.Title;
				}
		}
		
		#region Handlers DockingManager

		protected void OnContextMenu(PopupMenu pm, CancelEventArgs cea)
		{
			// Show the PopupMenu be cancelled and not shown?
			if (!_allowContextMenu)
				cea.Cancel = true;
			else
			{
				if (_customContextMenu)
				{
					// Remove the Show All and Hide All commands
					pm.MenuCommands.Remove(pm.MenuCommands["Show All"]);
					pm.MenuCommands.Remove(pm.MenuCommands["Hide All"]);

					// Add a custom item at the start
					pm.MenuCommands.Insert(0, (new MenuCommand("Custom 1")));
					pm.MenuCommands.Insert(1, (new MenuCommand("-")));

					// Add a couple of custom commands at the end
					pm.MenuCommands.Add(new MenuCommand("Custom 2"));
					pm.MenuCommands.Add(new MenuCommand("Custom 3"));
				}
			}
		}

		protected void OnContentHiding(Content c, CancelEventArgs cea)
		{
			switch (_ignoreClose)
			{
				case 0:
					// Allow all, do nothing
					break;
				case 1:
					// Ignore all, cancel
					cea.Cancel = true;
					break;
				case 2:
					// Ignore Panels
					cea.Cancel = c.Control is Panel;
					break;
				case 3:
					// Ignore Forms
					cea.Cancel = c.Control is Form;
					break;
				case 4:
					// Ignore RichTextBox
					cea.Cancel = c.Control is RichTextBox;
					break;
			}
		}

		protected void OnTabControlCreated(TabControl tabControl)
		{
			// tabControl.PositionTop = !_tabsBottom;
			// tabControl.Appearance = _tabAppearance;
		}

		private void On_tcLeftFrame_ClosePressed(object sender, EventArgs e)
		{
			foreach(Content tmpc in _manager.Contents)
				if (tmpc.Title == _coLeftFrame.Title)
				{
					_manager.Contents.Remove(tmpc);
					break;
				}
		}

		private void On_tcTopRightFrame_SelectionChanged(object sender, EventArgs e)
		{
			SetMenuOnTopRightFrameSelectionChanged();
			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// per cui in questo caso (e' cambiata la form selezionata) lo devo aggiornare!!!
			SetTRFContentFullTitleOnTRFCurrentForm();
		}

		private void On_tcLeftFrame_SelectionChanged(object sender, EventArgs e)
		{
			SetMenuOnLeftFrameSelectionChanged();
			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// per cui in questo caso (e' cambiata la form selezionata) lo devo aggiornare!!!
			SetLFContentFullTitleOnLFCurrentForm();
		}

		private void On_tcBottomFrame_SelectionChanged(object sender, EventArgs e)
		{
			SetMenuOnBottomFrameSelectionChanged();
			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// per cui in questo caso (e' cambiata la form selezionata) lo devo aggiornare!!!
			SetBFContentFullTitleOnBFCurrentForm();
		}

		private void On_tcBottomFrame_ClosePressed(object sender, EventArgs e)
		{
			foreach(Content tmpc in _manager.Contents)
				if (tmpc.Title == _coBottomFrame.Title)
				{
					_manager.Contents.Remove(tmpc);
					break;
				}
		}

		#endregion

		DataRecordList _drlMS;
		volatile BipexSubject _sMS;

		private void EngineMainForm_Load(object sender, System.EventArgs e)
		{
			_drlMS = new DataRecordList();
			_drlMS.Version = 0;

			_sMS = new BipexSubject();
			_sMS.DataDiMercato = DateTime.Now.Date;
			_sMS.SubjectType = "MS";
			_sMS.SubjectSubType = string.Empty;
			_sMS.Version = _drlMS.Version;

			this._documentStreamer.StartUpdate();
			this._documentStreamer.Request  += new Bipex_Engine.DocumentStreamer.RequestDelegate(_documentStreamer_Request);
			this._documentStreamer.Response += new Bipex_Engine.DocumentStreamer.ResponseDelegate(_documentStreamer_Response);

			this._documentStreamer.AddView(this);

			this._documentStreamer.AddView(this._frmBook);
			this._documentStreamer.AddView(this._frmQuadroComandi);
			this._documentStreamer.AddView(this._frmFasiNegoziazione);
			this._documentStreamer.AddView(this._frmBookSingoloContratto);
			this._documentStreamer.AddView(this._frmDailyActivity);
			this._documentStreamer.AddView(this._frmOpenOrders);
			this._documentStreamer.AddView(this._frmSaldoFisico);

			this._frmBook.BookRiassuntivoRowChanged += new Bipex_Engine.frmBook.BookRiassuntivoRowChangedDelegate(frmBR_BookRiassuntivoRowChanged);

			// Al primo caricamento del form, se non c'e' un login attivo,
			// forzo l'emissione del form di login anche senza la richiesta
			// dell'operatore...
			if (!_tspParams.LoginActive)
				this.OnLoginToBipex(sender, e);
		}

		private void EngineMainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{			
			// DA FARE MB
			// DA FARE MB
			// DA FARE MB
			// La logica "standard" di Save si � intanto capito che non si pu� utilizzare 
			// in quanto � basata sui content titles che noi modifichiamo dinamicamente
			// in base alla frame attiva... vedere il contenuto del file qui sotto...
			//
			// _manager.SaveConfigToFile("C:\\MICHELE\\TMP\\EngineMainForm.xml");
		}

		private void OnLoginToBipex(object sender, EventArgs e)
		{
			frmLogin.rcFrmLogin rcl = new frmLogin.rcFrmLogin();
			frmLogin frml = new frmLogin(frmLogin.enDialogMode.LoginUserPasswordNotVisible, ref rcl);
			if (frml.ShowDialog() == DialogResult.OK)
			{

				// Memorizzo nella mia struttura di prm di sessione il fatto
				// che ora c'e' un login attivo...
				_tspParams.LoginToBipex(rcl);

				// Saluto il nuovo utente...
				OnShowWelcome(sender, e);
				
				SetRefreshStatusOnTradingSessionParameters();
				SetFormControlsOnTradingSessionParameters();

				// Avverte i Forms figli che hanno bisogno di saperlo che c'� un nuovo Login...
				NotifyLoginStatusToChildForms();

				// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
				// per cui in questo caso (e' cambiato l'operatore) lo devo aggiornare!!!
				SetTRFContentFullTitleOnTRFCurrentForm();
				// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
				// per cui in questo caso (e' cambiato l'operatore) lo devo aggiornare!!!
				SetLFContentFullTitleOnLFCurrentForm();
				// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
				// per cui in questo caso (e' cambiato l'operatore) lo devo aggiornare!!!
				SetBFContentFullTitleOnBFCurrentForm();

			}
		}

		private void OnLogoffFromBipex(object sender, EventArgs e)
		{
			// Memorizzo nella mia struttura di prm di sessione il fatto
			// che NON c'e' un login attivo...
			_tspParams.LogoffFromBipex();

			SetRefreshStatusOnTradingSessionParameters();
			SetFormControlsOnTradingSessionParameters();

			// Avverte i Forms figli che hanno bisogno di saperlo che NON c'� un Login ATTIVO...
			NotifyLogoffStatusToChildForms();

			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// per cui in questo caso (e' cambiato l'operatore) lo devo aggiornare!!!
			SetTRFContentFullTitleOnTRFCurrentForm();
			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// per cui in questo caso (e' cambiato l'operatore) lo devo aggiornare!!!
			SetLFContentFullTitleOnLFCurrentForm();
			// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
			// per cui in questo caso (e' cambiato l'operatore) lo devo aggiornare!!!
			SetBFContentFullTitleOnBFCurrentForm();

		}

		private void OnShowWelcome(object sender, EventArgs e)
		{
			frmWelcome frmw = new frmWelcome(_tspParams);
			frmw.ShowDialog();
		}

		private void OnOpenNotes(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		private void OnSaveNotes(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		private void OnBookFilter(object sender, EventArgs e)
		{
			_frmBook.btnFilterOnCat_Click(sender, e);

			if (_frmBook.dvFilter.bAtLeastOneIsFiltered())
				_tpBookRiassuntivo.Title = _stpBInitialTitle + " (Filtered)";
			else
				_tpBookRiassuntivo.Title = _stpBInitialTitle;

		}

		private void OnRefreshON(object sender, EventArgs e)
		{
			_documentStreamer.Refresh = true;
			_tspParams.enRefreshStatus = RefreshStatus.On;
			SetStatusBarOnRefreshStatusChanged();
		}

		private void OnRefreshOFF(object sender, EventArgs e)
		{
			_documentStreamer.Refresh = false;
			_tspParams.enRefreshStatus = RefreshStatus.Off;
			SetStatusBarOnRefreshStatusChanged();
		}

		private void OnRptSessionHistory(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		private void OnRptPriceHistory(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		private void OnRptSingleContractPriceHistory(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		private void OnRptSingleContractPriceTrend(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		private void OnDeselected(MenuCommand item)
		{
		}

		private void OnSelected(MenuCommand item)
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(EngineMainForm));
			this._niCommFrozen = new System.Windows.Forms.NotifyIcon(this.components);
			this._niCommOK = new System.Windows.Forms.NotifyIcon(this.components);
			this._niCommKO = new System.Windows.Forms.NotifyIcon(this.components);
			this._niCommPending = new System.Windows.Forms.NotifyIcon(this.components);
			this.checkCommStatusTimer = new System.Windows.Forms.Timer(this.components);
			this._niMarketOpen = new System.Windows.Forms.NotifyIcon(this.components);
			this._niMarketClosed = new System.Windows.Forms.NotifyIcon(this.components);
			this._niMarketSuspended = new System.Windows.Forms.NotifyIcon(this.components);
			// 
			// _niCommFrozen
			// 
			this._niCommFrozen.Icon = ((System.Drawing.Icon)(resources.GetObject("_niCommFrozen.Icon")));
			this._niCommFrozen.Text = "";
			// 
			// _niCommOK
			// 
			this._niCommOK.Icon = ((System.Drawing.Icon)(resources.GetObject("_niCommOK.Icon")));
			this._niCommOK.Text = "";
			// 
			// _niCommKO
			// 
			this._niCommKO.Icon = ((System.Drawing.Icon)(resources.GetObject("_niCommKO.Icon")));
			this._niCommKO.Text = "";
			// 
			// _niCommPending
			// 
			this._niCommPending.Icon = ((System.Drawing.Icon)(resources.GetObject("_niCommPending.Icon")));
			this._niCommPending.Text = "";
			// 
			// checkCommStatusTimer
			// 
			this.checkCommStatusTimer.Interval = 1000;
			this.checkCommStatusTimer.Tick += new System.EventHandler(this.checkCommStatusTimer_Tick);
			// 
			// _niMarketOpen
			// 
			this._niMarketOpen.Icon = ((System.Drawing.Icon)(resources.GetObject("_niMarketOpen.Icon")));
			this._niMarketOpen.Text = "";
			// 
			// _niMarketClosed
			// 
			this._niMarketClosed.Icon = ((System.Drawing.Icon)(resources.GetObject("_niMarketClosed.Icon")));
			this._niMarketClosed.Text = "";
			// 
			// _niMarketSuspended
			// 
			this._niMarketSuspended.Icon = ((System.Drawing.Icon)(resources.GetObject("_niMarketSuspended.Icon")));
			this._niMarketSuspended.Text = "";
			// 
			// EngineMainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(816, 389);
			this.Name = "EngineMainForm";
			this.Text = "BIPEX - Prototype V 1.0";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Closing += new System.ComponentModel.CancelEventHandler(this.EngineMainForm_Closing);
			this.Load += new System.EventHandler(this.EngineMainForm_Load);

		}

		#endregion

		private void checkCommStatusTimer_Tick(object sender, System.EventArgs e)
		{
			_tspParams.enCommStatus = CommStatus.NoCommunication;
			SetStatusBarOnCommStatusChanged("");
		}

		DateTime _startRequest;
		private void _documentStreamer_Request()
		{
			if (this.InvokeRequired)
			{
				this.BeginInvoke(new MethodInvoker(_documentStreamer_Request));
				//this.Invoke(new MethodInvoker(_documentStreamer_Request));
				return;
			}

			_tspParams.enCommStatus = CommStatus.RequestSent;
			SetStatusBarOnCommStatusChanged("");

			this.checkCommStatusTimer.Interval = 30000;
			this.checkCommStatusTimer.Enabled = true;
			this.checkCommStatusTimer.Stop();
			this.checkCommStatusTimer.Start();

			_startRequest = DateTime.Now;
		}

		private void _documentStreamer_Response()
		{
			if (this.InvokeRequired)
			{
				//this.Invoke(new MethodInvoker(_documentStreamer_Response));
				this.BeginInvoke(new MethodInvoker(_documentStreamer_Response));
				return;
			}

			TimeSpan elapsed = DateTime.Now - _startRequest;

			_tspParams.enCommStatus = CommStatus.ResponseReceived;
			SetStatusBarOnCommStatusChanged(string.Format(" ( {0} Ms.)", elapsed.TotalMilliseconds.ToString("####0,0")));
		}

		private void frmBR_BookRiassuntivoRowChanged(string Contract)
		{
			if (_tpBookSingoloContratto != null && _tpBookSingoloContratto.Visible)
			{
				_tspParams.CurrentContract = Contract;

				// Informo TUTTI i Forms di TUTTE le frames del mio layout 
				// che sono "per contratto" che il contratto selezionato 
				// e' appunto cambiato, cosi' da mantenerli sincroni
				// con il contratto selezionato nel book...

				_frmBookSingoloContratto.SetCurrentContract(_tspParams.CurrentContract);
				_frmCalendarioDelivery.SetCurrentContract(_tspParams.CurrentContract);
				_frmDettagliContratto.SetCurrentContract(_tspParams.CurrentContract);

				// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
				// per cui in questo caso (e' cambiato il contratto) lo devo aggiornare!!!
				SetTRFContentFullTitleOnTRFCurrentForm();
				// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
				// per cui in questo caso (e' cambiato il contratto) lo devo aggiornare!!!
				SetLFContentFullTitleOnLFCurrentForm();
				// Il content full title e' funzione SIA della form selezionata SIA di contratto / operatore corrente,
				// per cui in questo caso (e' cambiato il contratto) lo devo aggiornare!!!
				SetBFContentFullTitleOnBFCurrentForm();
			}
		}

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			if (this.InvokeRequired)
			{
				GetBipexSubjectDelegate d = new GetBipexSubjectDelegate(GetBipexSubject);
				return (BipexSubject[]) this.Invoke(d);
			}
			else
			{
				if (this.Visible)
					return new BipexSubject[] {_sMS };
				else
					return new BipexSubject[0];
			}
		}

		private delegate void OnBipexResponseDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponseDelegate d = new OnBipexResponseDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_sMS.SubjectType == req[0].SubjectType &&
					_sMS.SubjectSubType == req[0].SubjectSubType)
				{
					_drlMS.Merge(resp[0]);
					_sMS.Version = _drlMS.Version;

					if (_drlMS.Count > 0)
					{
						MarketSessionDR dr = (MarketSessionDR) _drlMS[0];

						// Se sono qui mi � arrivato un DataRecordList NUOVO...

						_tspParams.enBipexMktCurrSessStatus = dr.StatoSessione;
						SetFormControlsOnTradingSessionParameters();
						SetStatusBarOnBipexMktCurrSessStatusChanged();

					}
					
				}
			}
		}

		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

	}

}