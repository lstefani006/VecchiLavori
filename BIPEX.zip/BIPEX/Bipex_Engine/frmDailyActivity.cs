using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using Bipex_BLInterface;
using Delta;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmDailyActivity.
	/// </summary>
	public class frmDailyActivity : System.Windows.Forms.Form, IDocumentStreamerViewer
	{
		private int[] iDataGridPositionDA = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
		private int[] iDataGridPositionDL = {0, 1, 2, 3, 4};

		// =================================
		// Nomi delle Colonne nel DataSource
		// =================================
		// !!!ATTENZIONE!!! 
		// Questi nomi DEVONO ESSERE GLI STESSI delle colonne contenute nel DataSource
		// (che sara' un DataTable all'interno di un DataSet) dal quale si alimenta il DataGrid!!!
		// ========================================

		public string[] MappingNamesDA =
			{
				"IdAbbinamento",
				"BidIdOfferta",
				"AskIdOfferta",
				"Contratto",
				"BidCodiceOperatore",
				"AskCodiceOperatore",
				"BidCodiceUtente",
				"AskCodiceUtente",
				"TSAbbinamento",
				"Price",
				"Qty",
				"CodiceOTC",
				"OperatoreOTC"
			};

		public string[] MappingNamesDL =
			{
				"IdDailyActivity",
				"ActivityTS",
				"Msg",
				"Price",
				"Qty"
			};

		public string[] HeaderTextsDA =
			{
				"Match ID",
				"Bid ID",
				"Ask ID",
				"Contract",
				"Bid Op./",
				"Ask Op./",
				"User",
				"User",
				"Book Time",
				"Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Qty",
				"OTC Code",
				"OTC Operator"
			};

		public string[] HeaderTextsDL =
			{
				"Act. ID",
				"Time",
				"Activity Description",
				"Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Qty"
			};

		// ======================================
		// Posizioni delle Colonne nel DataSource
		// ======================================
		// !!!ATTENZIONE!!! 
		// Questa lista DEVE ESSERE NELLO STESSO ORDINE delle colonne contenute 
		// nelle strutture MappingNames, HeaderTexts
		// =============================================
		public enum enPosColonneDSDA
		{
			IdAbbinamento = 0,
			BidIdOfferta,
			AskIdOfferta,
			Contratto,
			BidCodiceOperatore,
			AskCodiceOperatore,
			BidCodiceUtente,
			AskCodiceUtente,
			TSAbbinamento,
			Price,
			Qty,
			CodiceOTC,
			OperatoreOTC,
			_TUTTI_
		} ;
		public enum enPosColonneDSDL
		{
			IdDailyActivity = 0,
			ActivityTS,
			Msg,
			Price,
			Qty,
			_TUTTI_
		} ;

		// ====================================
		// Posizioni delle Colonne nel DataGrid
		// ====================================
		// !!!ATTENZIONE!!!
		// L'ordine con il quale le colonne compaiono in questa lista � l'ordine
		// delle colonne visualizzate nel DataGrid. Per cambiare quindi quest'ordine
		// � sufficiente alterare l'ordine di questo Enum. Il Tag _TUTTI_ deve rimanere
		// SEMPRE E COMUNQUE in fondo!!!
		// !!!ATTENZIONE!!!
		// La lista pu� contenere UN SOTTOINSIEME delle colonne del DataSource, le
		// colonne contenute saranno le uniche che compariranno nel DataGrid.
		// !!!ATTENZIONE!!!
		// Nei metodi di Handling di PBs che reperiscono dati dal DataGrid, sono
		// estraibili dal DataGrid stesso SOLO LE COLONNE PRESENTI IN QUESTA LISTA!!!
		// ==============================================
		public enum enPosColonneDGDA
		{
			// Colonne VISIBILI
			Contratto = 0,
			TSAbbinamento,
			Price,
			Qty,
			CodiceOTC,
			OperatoreOTC,
			BidIdOfferta,
			BidCodiceOperatore,
			BidCodiceUtente,
			AskIdOfferta,
			AskCodiceOperatore,
			AskCodiceUtente,
			IdAbbinamento,
			// Colonne NASCOSTE
			_TUTTI_
		} ;
		public enum enPosColonneDGDL
		{
			// Colonne VISIBILI
			ActivityTS = 0,
			Msg,
			IdDailyActivity,
			// Colonne NASCOSTE
			Price,
			Qty,
			_TUTTI_
		} ;

		private System.Windows.Forms.DataGrid dgDailyActivity;
		private System.Windows.Forms.DataGrid dgDailyActivityLog;
		
		private System.Data.DataSet dsDailyActivity;
		private System.Data.DataSet dsDailyActivityLog; 

		private System.Windows.Forms.Splitter spDailyActivity;

		// Il Currency Mgr serve a tenere memoria dello stato del datagrid
		// con riferimento alle righe visibili, ad esempio in base al filtro
		// attivo.
		// Per cui, tutte le volte che si altera la composizione del dataview
		// in termini di righe contenute, ad es. applicando un filtro, si deve
		// AGGIORNARE la proprieta' BindingContext del DataView...
		private CurrencyManager _cmMainDG;
		private DataRow _dr = null;
		
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmDailyActivity()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.dgDailyActivity = new System.Windows.Forms.DataGrid();
			this.dsDailyActivity = new System.Data.DataSet();
			this.spDailyActivity = new System.Windows.Forms.Splitter();
			this.dsDailyActivityLog = new System.Data.DataSet();
			this.dgDailyActivityLog = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dgDailyActivity)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dsDailyActivity)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dsDailyActivityLog)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgDailyActivityLog)).BeginInit();
			this.SuspendLayout();
			// 
			// dgDailyActivity
			// 
			this.dgDailyActivity.AlternatingBackColor = System.Drawing.SystemColors.ControlLight;
			this.dgDailyActivity.CaptionVisible = false;
			this.dgDailyActivity.DataMember = "";
			this.dgDailyActivity.DataSource = this.dsDailyActivity;
			this.dgDailyActivity.Dock = System.Windows.Forms.DockStyle.Left;
			this.dgDailyActivity.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgDailyActivity.Location = new System.Drawing.Point(0, 0);
			this.dgDailyActivity.Name = "dgDailyActivity";
			this.dgDailyActivity.ReadOnly = true;
			this.dgDailyActivity.RowHeaderWidth = 15;
			this.dgDailyActivity.SelectionBackColor = System.Drawing.SystemColors.ControlDark;
			this.dgDailyActivity.Size = new System.Drawing.Size(448, 226);
			this.dgDailyActivity.TabIndex = 0;
			// 
			// dsDailyActivity
			// 
			this.dsDailyActivity.DataSetName = "NewDataSet";
			this.dsDailyActivity.Locale = new System.Globalization.CultureInfo("it-IT");
			// 
			// spDailyActivity
			// 
			this.spDailyActivity.Location = new System.Drawing.Point(448, 0);
			this.spDailyActivity.Name = "spDailyActivity";
			this.spDailyActivity.Size = new System.Drawing.Size(6, 226);
			this.spDailyActivity.TabIndex = 1;
			this.spDailyActivity.TabStop = false;
			// 
			// dsDailyActivityLog
			// 
			this.dsDailyActivityLog.DataSetName = "NewDataSet";
			this.dsDailyActivityLog.Locale = new System.Globalization.CultureInfo("it-IT");
			// 
			// dgDailyActivityLog
			// 
			this.dgDailyActivityLog.AlternatingBackColor = System.Drawing.SystemColors.ControlLight;
			this.dgDailyActivityLog.CaptionVisible = false;
			this.dgDailyActivityLog.DataMember = "";
			this.dgDailyActivityLog.DataSource = this.dsDailyActivityLog;
			this.dgDailyActivityLog.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgDailyActivityLog.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgDailyActivityLog.Location = new System.Drawing.Point(454, 0);
			this.dgDailyActivityLog.Name = "dgDailyActivityLog";
			this.dgDailyActivityLog.ReadOnly = true;
			this.dgDailyActivityLog.RowHeaderWidth = 15;
			this.dgDailyActivityLog.SelectionBackColor = System.Drawing.SystemColors.ControlDark;
			this.dgDailyActivityLog.Size = new System.Drawing.Size(250, 226);
			this.dgDailyActivityLog.TabIndex = 2;
			// 
			// frmDailyActivity
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(704, 226);
			this.Controls.Add(this.dgDailyActivityLog);
			this.Controls.Add(this.spDailyActivity);
			this.Controls.Add(this.dgDailyActivity);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmDailyActivity";
			this.Text = "Daily Activity";
			this.Load += new System.EventHandler(this.frmDailyActivity_Load);
			this.VisibleChanged += new System.EventHandler(this.frmDailyActivity_VisibleChanged);
			((System.ComponentModel.ISupportInitialize)(this.dgDailyActivity)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dsDailyActivity)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dsDailyActivityLog)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgDailyActivityLog)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		DataRecordList _drlDA;
		volatile BipexSubject _sDA;

		DataRecordList _drlDL;
		volatile BipexSubject _sDL;
		
		volatile bool _Visible = false;



		private void frmDailyActivity_Load(object sender, System.EventArgs e)
		{

			// Pulisco il DataGrid e lo ricostruisco in base al contenuto del DataSet...
			dgDailyActivity.DataSource = null;
		
			DailyActivity_Load();

			if (dsDailyActivity != null)
				BindDataGridDA(dgDailyActivity, dsDailyActivity);
		
			if (dsDailyActivityLog != null)
				BindDataGridDL(dgDailyActivityLog, dsDailyActivityLog);
		
			_Visible = this.Visible;		
		}

		private void DailyActivity_Load()
		{
			dsDailyActivity = new DataSet();
			dsDailyActivityLog = new DataSet();

			_drlDA = new DataRecordList();
			_drlDA.Version = 0;

			_drlDL = new DataRecordList();
			_drlDL.Version = 0;

			_sDA = new BipexSubject();
			_sDA.DataDiMercato = DateTime.Now.Date;
			_sDA.SubjectType = "DA";
			_sDA.SubjectSubType = string.Empty;
			_sDA.Version = _drlDA.Version;

			_sDL = new BipexSubject();
			_sDL.DataDiMercato = DateTime.Now.Date;
			_sDL.SubjectType = "DL";
			_sDL.SubjectSubType = string.Empty;
			_sDL.Version = _drlDL.Version;

			DataSetMerger.CreateTable(dsDailyActivity, "DA", typeof(DailyActivityDR));
			DataSetMerger.CreateTable(dsDailyActivityLog, "DL", typeof(DailyActivityLogDR));
		}

		public void SetFilterOnCurrentOperator()
		{
			if (_sDA != null)
			{
				if (EngineMainForm._tspParams.LoginActive)
				{
					BipexFilterPerOperatoreUtente filter = new BipexFilterPerOperatoreUtente(
						EngineMainForm._tspParams.ActiveOperatorCode,
						EngineMainForm._tspParams.ActiveUserCode);
					_sDA.Filter = filter;
					_sDA.Version = 0;
					_drlDA.Version = 0;
				}
			}
			if (_sDL != null)
			{
				if (EngineMainForm._tspParams.LoginActive)
				{
					BipexFilterPerOperatoreUtente filter = new BipexFilterPerOperatoreUtente(
						EngineMainForm._tspParams.ActiveOperatorCode,
						EngineMainForm._tspParams.ActiveUserCode);
					_sDL.Filter = filter;
					_sDL.Version = 0;
					_drlDL.Version = 0;
				}
			}
		}

		public void ResetFilterOnCurrentOperator()
		{
			if (_sDA != null)
			{
				_sDA.Filter = null;
				_sDA.Version = 0;
				_drlDA.Version = 0;
			}
			if (_sDL != null)
			{
				_sDL.Filter = null;
				_sDL.Version = 0;
				_drlDL.Version = 0;
			}
		}

		private void BindDataGridDA(DataGrid dg, DataSet ds)
		{
			if (ds != null)
				SetDataGridTableStylesDA(dg, "DA");

			FillDataGridDA(dg, ds);
		
		}

		private void BindDataGridDL(DataGrid dg, DataSet ds)
		{
			if (ds != null)
				SetDataGridTableStylesDL(dg, "DL");

			FillDataGridDL(dg, ds);
		
		}

		private void SetDataGridTableStylesDA(DataGrid dg, string sMappingName)
		{
			dg.TableStyles.Clear();

			DataGridTableStyle dgsBook = new DataGridTableStyle();

			// !!!ATTENZIONE!!!
			// WORKAROUND PER RISOLUZIONE PROBLEMA
			// SE SI RIDEFINISCE UN PROPRIO TABLESTYLE 
			// PER VISUALIZZARE UN DATATABLE,
			// OCCORRE RIASSEGNARE ESPLICITAMENTE I COLORI!!!,
			// altrimenti ad esempio impostazioni come l'alternate
			// color vanno perdute...
			dgsBook.AlternatingBackColor = BipexFormSettings.AlternatingBackColor;
			dgsBook.BackColor = BipexFormSettings.BackColor;
			dgsBook.ForeColor = BipexFormSettings.ForeColor;
			dgsBook.GridLineColor = BipexFormSettings.GridLineColor;
			dgsBook.HeaderBackColor = BipexFormSettings.HeaderBackColor;
			dgsBook.HeaderForeColor = BipexFormSettings.HeaderForeColor;
			dgsBook.LinkColor = BipexFormSettings.LinkColor;
			dgsBook.SelectionBackColor = BipexFormSettings.SelectionBackColor;
			dgsBook.SelectionForeColor = BipexFormSettings.SelectionForeColor;

			// Il DataGrid NON E' SORTABILE DALL'UTENTE...
			dgsBook.AllowSorting = false;
			dgsBook.RowHeadersVisible = false;

			dgsBook.MappingName = sMappingName;

			DataGridAlignedTextBoxColumn[] dgcBook = new DataGridAlignedTextBoxColumn[(int) enPosColonneDGDA._TUTTI_];
			for (int i = 0; i < dgcBook.Length; ++i)
				dgcBook[i] = new DataGridAlignedTextBoxColumn();
			int index = 0;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.IdAbbinamento];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.IdAbbinamento];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.IdAbbinamento];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 110;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.BidIdOfferta];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.BidIdOfferta];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.BidIdOfferta];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.AskIdOfferta];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.AskIdOfferta];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.AskIdOfferta];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.Contratto];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.Contratto];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.Contratto];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 110;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.TSAbbinamento];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.TSAbbinamento];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.TSAbbinamento];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForTimeWithAMPM;
			dgcBook[index].Width = 80;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.Price];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.Price];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.Price];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].Width = 75;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.Qty];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.Qty];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.Qty];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].Width = 50;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.CodiceOTC];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.CodiceOTC];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.CodiceOTC];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 110;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.OperatoreOTC];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.OperatoreOTC];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.OperatoreOTC];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 110;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.BidCodiceOperatore];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.BidCodiceOperatore];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.BidCodiceOperatore];
			dgcBook[index].Alignment = HorizontalAlignment.Right; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 60;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.BidCodiceUtente];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.BidCodiceUtente];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.BidCodiceUtente];
			dgcBook[index].Alignment = HorizontalAlignment.Left; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.AskCodiceOperatore];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.AskCodiceOperatore];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.AskCodiceOperatore];
			dgcBook[index].Alignment = HorizontalAlignment.Right; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 60;

			index = iDataGridPositionDA[(int) enPosColonneDGDA.AskCodiceUtente];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDA[(int) enPosColonneDSDA.AskCodiceUtente];
			dgcBook[index].HeaderText = HeaderTextsDA[(int) enPosColonneDSDA.AskCodiceUtente];
			dgcBook[index].Alignment = HorizontalAlignment.Left; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			dgsBook.GridColumnStyles.AddRange(dgcBook);
			dg.TableStyles.Add(dgsBook);

		}

		private void SetDataGridTableStylesDL(DataGrid dg, string sMappingName)
		{
			dg.TableStyles.Clear();

			DataGridTableStyle dgsBook = new DataGridTableStyle();

			// !!!ATTENZIONE!!!
			// WORKAROUND PER RISOLUZIONE PROBLEMA
			// SE SI RIDEFINISCE UN PROPRIO TABLESTYLE 
			// PER VISUALIZZARE UN DLTATABLE,
			// OCCORRE RIASSEGNARE ESPLICITAMENTE I COLORI!!!,
			// altrimenti ad esempio impostazioni come l'alternate
			// color vanno perdute...
			dgsBook.AlternatingBackColor = BipexFormSettings.AlternatingBackColor;
			dgsBook.BackColor = BipexFormSettings.BackColor;
			dgsBook.ForeColor = BipexFormSettings.ForeColor;
			dgsBook.GridLineColor = BipexFormSettings.GridLineColor;
			dgsBook.HeaderBackColor = BipexFormSettings.HeaderBackColor;
			dgsBook.HeaderForeColor = BipexFormSettings.HeaderForeColor;
			dgsBook.LinkColor = BipexFormSettings.LinkColor;
			dgsBook.SelectionBackColor = BipexFormSettings.SelectionBackColor;
			dgsBook.SelectionForeColor = BipexFormSettings.SelectionForeColor;

			// Il DataGrid NON E' SORTABILE DALL'UTENTE...
			dgsBook.AllowSorting = false;
			dgsBook.RowHeadersVisible = false;

			dgsBook.MappingName = sMappingName;

			DataGridAlignedTextBoxColumn[] dgcBook = new DataGridAlignedTextBoxColumn[(int) enPosColonneDGDL._TUTTI_];
			for (int i = 0; i < dgcBook.Length; ++i)
				dgcBook[i] = new DataGridAlignedTextBoxColumn();
			int index = 0;

			index = iDataGridPositionDL[(int) enPosColonneDGDL.IdDailyActivity];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDL[(int) enPosColonneDSDL.IdDailyActivity];
			dgcBook[index].HeaderText = HeaderTextsDL[(int) enPosColonneDSDL.IdDailyActivity];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 50;

			index = iDataGridPositionDL[(int) enPosColonneDGDL.ActivityTS];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDL[(int) enPosColonneDSDL.ActivityTS];
			dgcBook[index].HeaderText = HeaderTextsDL[(int) enPosColonneDSDL.ActivityTS];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForTimeWithAMPM;
			dgcBook[index].Width = 80;

			index = iDataGridPositionDL[(int) enPosColonneDGDL.Msg];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDL[(int) enPosColonneDSDL.Msg];
			dgcBook[index].HeaderText = HeaderTextsDL[(int) enPosColonneDSDL.Msg];
			dgcBook[index].Alignment = HorizontalAlignment.Left; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 500;

			/*
			index = iDataGridPositionDL[(int) enPosColonneDGDL.Price];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDL[(int) enPosColonneDSDL.Price];
			dgcBook[index].HeaderText = HeaderTextsDL[(int) enPosColonneDSDL.Price];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].Width = 75;
			*/

			/*
			index = iDataGridPositionDL[(int) enPosColonneDGDL.Qty];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNamesDL[(int) enPosColonneDSDL.Qty];
			dgcBook[index].HeaderText = HeaderTextsDL[(int) enPosColonneDSDL.Qty];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].Width = 50;
			*/

			dgsBook.GridColumnStyles.AddRange(dgcBook);
			dg.TableStyles.Add(dgsBook);

		}

		public void FillDataGridDA(DataGrid dg, DataSet ds)
		{
			DataView dv = new DataView(ds.Tables[0]);

			dv.AllowDelete = false;
			dv.AllowEdit = false;
			dv.AllowNew = false;
			
			dv.Sort = MappingNamesDA[(int) enPosColonneDSDA.IdAbbinamento] + " DESC";

			//Imposto il colore delle righe pari a un colore leggermente
			//piu` scuro di quello utilizzato per le righe dispari.
			int piuScuro = 10;
			int R = dg.BackColor.R - piuScuro;
			int G = dg.BackColor.G - piuScuro;
			int B = dg.BackColor.B - piuScuro;
			if (R < 0) R = 10;
			if (G < 0) G = 10;
			if (B < 0) B = 10;
			Color colore = Color.FromArgb(R, G, B);
			dg.AlternatingBackColor = colore;

			//dg.TableStyles.Clear();
			//dg.TableStyles.IsReadOnly = true;
			//dg.TableStyles.Add(stile);
			dg.AllowNavigation = false;

			dg.DataSource = dv;

			_cmMainDG = (CurrencyManager)this.BindingContext[dv];
			_cmMainDG.CurrentChanged += new EventHandler(_cmMainDG_CurrentChanged);
			dv.ListChanged += new ListChangedEventHandler(_cmMainDG_ListChanged);

			return;
		}

		public void FillDataGridDL(DataGrid dg, DataSet ds)
		{
			DataView dv = new DataView(ds.Tables[0]);

			dv.AllowDelete = false;
			dv.AllowEdit = false;
			dv.AllowNew = false;
			dv.Sort = MappingNamesDL[(int) enPosColonneDSDL.IdDailyActivity] + " DESC";

			//Imposto il colore delle righe pari a un colore leggermente
			//piu` scuro di quello utilizzato per le righe dispari.
			int piuScuro = 10;
			int R = dg.BackColor.R - piuScuro;
			int G = dg.BackColor.G - piuScuro;
			int B = dg.BackColor.B - piuScuro;
			if (R < 0) R = 10;
			if (G < 0) G = 10;
			if (B < 0) B = 10;
			Color colore = Color.FromArgb(R, G, B);
			dg.AlternatingBackColor = colore;

			//dg.TableStyles.Clear();
			//dg.TableStyles.IsReadOnly = true;
			//dg.TableStyles.Add(stile);
			dg.AllowNavigation = false;

			dg.DataSource = dv;

			return;
		}

		public void _cmMainDG_CurrentChanged(object sender, EventArgs e)
		{
			try
			{
				DataRow dr = GetAbbinamentoCorrente();
				if (_dr == null || _dr != dr)
				{
					_dr = dr;

					// DA FARE MB
					// DA FARE MB
					// DA FARE MB

					// Se c'� da consuntivare a qualche altro form il fatto che �
					// cambiato l'abbinamento selezionato (DATAGRID di sx di questo form), qui � il
					// posto per farlo (copiare gestione dal Book Riassuntivo)
					// SendOffertaRowChanged(dr);
				}
			}
			catch
			{
			}
		}
		private void _cmMainDG_ListChanged(object sender, ListChangedEventArgs e)
		{
			if (_cmMainDG.Position == 0)
			{
				try
				{
					DataRow dr = GetAbbinamentoCorrente();
					// L'update in BackGround del DataSet associato al DataGrid
					// causa MOLTISSIMI eventi di tipo ListChanged, invio la
					// notifica del cambio di riga selezionata solo quando cio'
					// si verifica effettivamente...
					if (_dr == null || _dr != dr)
					{
						_dr = dr;

						// DA FARE MB
						// DA FARE MB
						// DA FARE MB

						// Se c'� da consuntivare a qualche altro form il fatto che �
						// cambiato l'abbinamento selezionato (DATAGRID di sx di questo form), qui � il
						// posto per farlo (copiare gestione dal Book Riassuntivo)
						// SendOffertaRowChanged(dr);
					}
				}
				catch
				{
				}
			}
		}

		private DataRow GetAbbinamentoCorrente()
		{
			if (_cmMainDG.Count == 0)
				return null;
			DataView dv = (DataView)_cmMainDG.List;
			if (dv.Count == 0)
				return null;
			DataRow dr = dv[_cmMainDG.Position].Row;
			return dr;
		}

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			//			if (this.InvokeRequired)
			//			{
			//				GetBipexSubjectDelegate d = new GetBipexSubjectDelegate(GetBipexSubject);
			//				return (BipexSubject[]) this.Invoke(d);
			//			}
			//			else
			//			{
			//				if (this.Visible)
			//					return new BipexSubject[] {_sDA };
			//				else
			//					return new BipexSubject[0];
			//			}

			if (this._Visible)
				return new BipexSubject[] { _sDA, _sDL };
			else
				return new BipexSubject[0];
		}

		private delegate void OnBipexResponseDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponseDelegate d = new OnBipexResponseDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_sDA.SubjectType == req[0].SubjectType &&
					_sDA.SubjectSubType == req[0].SubjectSubType)
				{
					_drlDA.Merge(resp[0]);
					_sDA.Version = _drlDA.Version;
					DataSetMerger.Merge(this.dsDailyActivity.Tables["DA"], _drlDA, typeof(DailyActivityDR));
				}
				if (_sDL.SubjectType == req[1].SubjectType &&
					_sDL.SubjectSubType == req[1].SubjectSubType)
				{
					_drlDL.Merge(resp[1]);
					_sDL.Version = _drlDL.Version;
					DataSetMerger.Merge(this.dsDailyActivityLog.Tables["DL"], _drlDL, typeof(DailyActivityLogDR));
				}
			}
		}

		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

		private void frmDailyActivity_VisibleChanged(object sender, System.EventArgs e)
		{
			_Visible = this.Visible;		
		}
		
		/// <summary>
		/// La classe consente di gestire l'allineamento separato tra l'header text
		/// di una colonna ed i dati contenuti nelle celle nella colonna stessa
		/// 
		/// Derivando da questa classe si ottiene che:
		/// 
		/// -	La proprieta' standard Alignment serve a gestire l'allineamento
		///		dell'header (ATTENZIONE: HorizontalAlignment.Right CAUSA UN CLIPPING
		///		DELL'HEADER TEXT e quindi e' meglio non usarlo!);
		///	-	La proprieta' custom DataAlignment serve a gestire l'allineamento
		///		del dato nella cella.
		/// </summary>
		private class DataGridAlignedTextBoxColumn : DataGridTextBoxColumn
		{
			protected bool bColorSetInDerivedClass = false;
			private HorizontalAlignment dataAlignment = HorizontalAlignment.Center;

			/// <summary>
			/// La proprieta' serve a gestire l'allineamento del dato nella cella.
			/// </summary>
			public HorizontalAlignment DataAlignment
			{
				get { return this.dataAlignment; }
				set { this.dataAlignment = value; }
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
				int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				try
				{
					// !!!ATTENZIONE!!!
					// WORKAROUND PER RISOLUZIONE PROBLEMA
					// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
					// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
					// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
					// (per default, il click sulla barra a sz delle celle fa il paint mentre
					// il click sulle celle stesse non fa il paint!!!)

					// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
					Brush myBackBrush;
					Brush myForeBrush;
					if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum & !bColorSetInDerivedClass)
					{
						// Sono sulla riga selezionata, la dovrei evidenziare...
						myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
						myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
					}
					else
					{
						myBackBrush = backBrush;
						myForeBrush = foreBrush;
					}

					// Questa e' la riga corrente...
					DataRow dr = ((DataView) cm.List)[rowNum].Row;

					// ...e questi sono i valori delle celle della riga corrente...
					string strCellText = "";
					if (dr[this.MappingName] != System.Convert.DBNull)
					{
						// QUI CI VUOLE UNA LOGICA DEL TIPO:
						// SE ADMINISTRATOR FAI VEDERE TUTTO SENZA PROBLEMI
						// SE NON ADMINISTRATOR FAI VEDERE SOLO ME STESSO E HIDE DELLA CONTROPARTE
						// (COLLOQUIO TELEFONICO MICHELE-LEO 20.09.05 POM.)

						/*
						 * questa e' la lista di colonne per le quali fare il filtering...
						 * 
						"BidIdOfferta",
						"AskIdOfferta",
						"BidCodiceOperatore",
						"AskCodiceOperatore",
						"BidCodiceUtente",
						"AskCodiceUtente",
						*/

						// Converto il valore in stringa per poterlo riscrivere, devo
						// tenere conto dell'attributo di formattazione eventualmente
						// impostato dall'utente del datagrid...
						strCellText = FormatObjectAsString(dr[this.MappingName], this.Format);

						if (this.MappingName == "BidIdOfferta" || this.MappingName == "BidCodiceOperatore" || this.MappingName == "BidCodiceUtente")
						{
							if (EngineMainForm._tspParams.LoginActive)
							{
								if (EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorFull || EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorAccountant)
								{
									// IO sono amministratore, vedo tutto...
								}
								else
								{
									if (EngineMainForm._tspParams.ActiveOperatorCode == FormatObjectAsString(dr["BidCodiceOperatore"], BipexFormSettings.FmtForGenericString))
									{
										// IO NON sono amministratore e sono colui che ha fatto il Bid, vedo SOLO i dati di Bid...
									}
									else
										if (EngineMainForm._tspParams.ActiveOperatorCode == FormatObjectAsString(dr["AskCodiceOperatore"], BipexFormSettings.FmtForGenericString))
									{
										// IO NON sono amministratore e sono colui che ha fatto l'Ask, vedo SOLO i dati di Ask...
										strCellText = "*****";
									}
								}
							}
						}
						else
							if (this.MappingName == "AskIdOfferta" || this.MappingName == "AskCodiceOperatore" || this.MappingName == "AskCodiceUtente")
						{
							if (EngineMainForm._tspParams.LoginActive)
							{
								if (EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorFull || EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorAccountant)
								{
									// IO sono amministratore, vedo tutto...
								}
								else
								{
									if (EngineMainForm._tspParams.ActiveOperatorCode == FormatObjectAsString(dr["BidCodiceOperatore"], BipexFormSettings.FmtForGenericString))
									{
										// IO NON sono amministratore e sono colui che ha fatto il Bid, vedo SOLO i dati di Bid...
										strCellText = "*****";
									}
									else
										if (EngineMainForm._tspParams.ActiveOperatorCode == FormatObjectAsString(dr["AskCodiceOperatore"], BipexFormSettings.FmtForGenericString))
									{
										// IO NON sono amministratore e sono colui che ha fatto l'Ask, vedo SOLO i dati di Ask...
									}
								}
							}
						}
						else
							if (this.MappingName == "Msg")
						{
							try
							{
								XmlDocument doc = new XmlDocument();
								doc.LoadXml(strCellText);
								XmlElement xeMsg = (XmlElement) doc.DocumentElement.SelectSingleNode(Thread.CurrentThread.CurrentUICulture.TwoLetterISOLanguageName);

								// ci possono essere piu` nodi di tipo <op>
								// faccio un loop per scovarli tutti.
								foreach (XmlNode xnOperatorCode in xeMsg.SelectNodes("op"))
								{
									if (EngineMainForm._tspParams.LoginActive)
									{
										if (EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorFull || EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorAccountant)
										{
											// IO sono amministratore, vedo tutto...
										}
										else
										{
											if (EngineMainForm._tspParams.ActiveOperatorCode == xnOperatorCode.InnerText)
											{
												// IO NON sono amministratore e sono l'op del msg di cui sopra, vedo i dati...
											}
											else
											{
												// IO NON sono amministratore e NON l'op del msg di cui sopra, NASCONDO i dati...
												xnOperatorCode.InnerText = "*****";
											}
										}
									}
								}

								foreach (XmlNode xnUserCode in xeMsg.SelectNodes("usr"))
								{
									if (EngineMainForm._tspParams.LoginActive)
									{
										if (EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorFull || EngineMainForm._tspParams.ActiveRole == Ruolo.AdministratorAccountant)
											continue;// IO sono amministratore, vedo tutto...


										bool sicurezzaPerOperatore = false;
										if (sicurezzaPerOperatore)
										{
											if (EngineMainForm._tspParams.ActiveUserCode != xnUserCode.InnerText)
												xnUserCode.InnerText = "*****";
										}
										else
										{
											if (xnUserCode.Attributes["op"] != null)
											{
												if (xnUserCode.Attributes["op"].Value != EngineMainForm._tspParams.ActiveOperatorCode)
													xnUserCode.InnerText = "*****";
											}
										}
									}
								}

						
								// un po' di programmazione difensiva: se i nodi non esistono
								// non mi schianto.
								XmlNode xnPrice = xeMsg.SelectSingleNode("Price");
								if (xnPrice != null)
									xnPrice.InnerText = FormatObjectAsString(dr[xnPrice.Name], BipexFormSettings.FmtForPrice) + " " + EngineMainForm._tspParams.BIPEXCurrencySymbol;

								XmlNode xnQty = xeMsg.SelectSingleNode("Qty");
								if (xnQty != null)
									xnQty.InnerText = FormatObjectAsString(dr[xnQty.Name], BipexFormSettings.FmtForQty);
						
								strCellText = xeMsg.InnerText;
							}
							catch (Exception ex)
							{
								// se capita una eccezione, molto probabilmenteil formato XML e` errato.
								// E` un peccato far piantare l'applicazione... si sceglie dunque
								// di far vedere a video la stringa che e` arrivata.
							}
						}

					}
					
					// Determino l'allineamento in funzione della property impostata dall'utente della classe
					StringFormat stringFormat = new StringFormat();
					switch (DataAlignment)
					{
						case HorizontalAlignment.Center:
							stringFormat.Alignment = StringAlignment.Center;
							break;
						case HorizontalAlignment.Left:
							stringFormat.Alignment = StringAlignment.Near;
							break;
						case HorizontalAlignment.Right:
							stringFormat.Alignment = StringAlignment.Far;
							break;
					}

					// Disegno BackGround sul rect da refreshare...
					g.FillRectangle(myBackBrush, bounds);
					// Calcolo nuovo rect...
					RectangleF CellBounds = new RectangleF(bounds.Left, bounds.Top + 3, bounds.Width, bounds.Height);
					// Refresh del contenuto della cella...
					g.DrawString(strCellText, this.DataGridTableStyle.DataGrid.Font, myForeBrush, CellBounds, stringFormat);
				}
				catch (Exception ex)
				{
					string g2 = ex.Message;	
					g2 = g2.ToLower();
				}

			}

			private int SelectedRow = -1;

			protected override void Edit(CurrencyManager source, int rowNum, Rectangle bounds, bool readOnly, string instantText, bool cellIsVisible)
			{
				// Per evitare crash testare che ci sia una selezione valida
				// prima di fare la deselezione...
				if (SelectedRow > -1 && SelectedRow < source.List.Count + 1)
					this.DataGridTableStyle.DataGrid.UnSelect(SelectedRow);
			}

			protected string FormatObjectAsString(object o, string Format)
			{
				if (o.GetType() == typeof (DateTime))
				{
					DateTime tmp = Convert.ToDateTime(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (double))
				{
					double tmp = Convert.ToDouble(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (decimal))
				{
					decimal tmp = Convert.ToDecimal(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (short))
				{
					short tmp = Convert.ToInt16(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (int))
				{
					int tmp = Convert.ToInt32(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (long))
				{
					long tmp = Convert.ToInt64(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else
				{
					// Type non gestito con formattazione specifica, richiamo il metodo
					// standard di conversione in stringa...
					return o.ToString();
				}
			}
		}
	
	}
}
