using System;
using System.Reflection;
using System.Resources;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per BipexResourceManager.
	/// </summary>
	public class BipexResourceManager
	{
		public BipexResourceManager()
		{
			//
			// TODO: aggiungere qui la logica del costruttore
			//
		}

		private static ResourceManager rmMgr;

		/// <summary>
		/// Istanzia il Resource Manager
		/// le risorse vengono ricercate nell'assembly corrente per cui i files .resx
		/// delle risorse devono essere stati imbeddati nell'assembly corrente
		/// </summary>
		/// <param name="baseName"></param>
		public static void LoadResourceManager(string baseName)
		{
			rmMgr = new ResourceManager(baseName, Assembly.GetExecutingAssembly());
		}
		/// <summary>
		/// Restituisce la stringa associata al nome ricevuto come argomento
		/// </summary>
		/// <param name="name"></param>
		/// <returns></returns>
		public static string GetResourceString(string name)
		{
			if (rmMgr == null)
				return "*** RESOURCE MANAGER ERROR *** RESOURCE MANAGER NOT LOADED ***";
			else
			{
				try
				{
					return rmMgr.GetString(name);
				}
				catch
				{
					return "*** RESOURCE MANAGER ERROR *** MESSAGE <"+name+"> NOT FOUND IN <"+rmMgr.BaseName+"> ***";
				}
			}
		}

	}
}
