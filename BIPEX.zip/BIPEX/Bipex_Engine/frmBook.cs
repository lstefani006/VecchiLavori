using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using Bipex_BLInterface;
using Delta;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmBook.
	/// </summary>
	public class frmBook : Form, IDocumentStreamerViewer
	{
		private int[] iDataGridPosition = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};

		private frmSortColumn frmSC;
		private frmBookFilterOnCategory frmBFOC;
		private frmOfferta frmOf;

		public class FilterOnCategory
		{
			public bool bDailyBaseLoad;
			public bool bWeeklyBaseLoad;
			public bool bMonthlyBaseLoad;
			public bool bDailyPeak;
			public bool bWeeklyPeak;
			public bool bMonthlyPeak;
			public bool bDailyOffPeak;
			public bool bWeeklyOffPeak;
			public bool bMonthlyOffPeak;

			public FilterOnCategory()
			{
			bDailyBaseLoad = true;
			bWeeklyBaseLoad = true;
			bMonthlyBaseLoad = true;
			bDailyPeak = true;
			bWeeklyPeak = true;
			bMonthlyPeak = true;
			bDailyOffPeak = true;
			bWeeklyOffPeak = true;
			bMonthlyOffPeak = true;
			}

			public bool bAtLeastOneIsVisible()
			{
				return(bDailyBaseLoad || bWeeklyBaseLoad || bMonthlyBaseLoad ||
						bDailyPeak || bWeeklyPeak || bMonthlyPeak ||
						bDailyOffPeak || bWeeklyOffPeak ||bMonthlyOffPeak);
			}
			public bool bAtLeastOneIsFiltered()
			{
				return(! bDailyBaseLoad || ! bWeeklyBaseLoad || ! bMonthlyBaseLoad ||
						! bDailyPeak || ! bWeeklyPeak || ! bMonthlyPeak ||
						! bDailyOffPeak || ! bWeeklyOffPeak || ! bMonthlyOffPeak);
			}

		};

		// =================================
		// Nomi delle Colonne nel DataSource
		// =================================
		// !!!ATTENZIONE!!! 
		// Questi nomi DEVONO ESSERE GLI STESSI delle colonne contenute nel DataSource
		// (che sara' un DataTable all'interno di un DataSet) dal quale si alimenta il DataGrid!!!
		// ========================================
		public string[] MappingNames =
			{
				"Contract",
				"Hours",

				"BidPrice",
				"BidQty",
				"BidOperator",

				"AskPrice",
				"AskQty",
				"AskOperator",

				"LastPrice",
				"LastQty",
				"LastTime",

				"MaxPrice",
				"MinPrice",

				"Volume",
				"ConvPrice",
				"OffPrice",
				"RefPrice"
			};

		public string[] HeaderTexts =
			{
				"Contract",
				"Hours",

				"Bid Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Bid Qty",
				"Bid Operator",
				"Ask Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Ask Qty",
				"Ask Operator",

				"Last Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Last Qty",
				"Last Time",

				"Max Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Min Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",

				"Volume",
				"Cnv.Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Off.Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")",
				"Ref.Price ("+EngineMainForm._tspParams.BIPEXCurrencySymbol+")"
			};

		public int[] InitialWidths =
			{
				110,
				40,

				75,
				50,
				150,
				75,
				50,
				150,

				75,
				50,
				80,

				75,
				75,

				50,
				75,
				75,
				75
			};

		// ======================================
		// Posizioni delle Colonne nel DataSource
		// ======================================
		// !!!ATTENZIONE!!! 
		// Questa lista DEVE ESSERE NELLO STESSO ORDINE delle colonne contenute 
		// nelle strutture MappingNames, HeaderTexts, InitialWidths
		// =============================================
		public enum enPosColonneDS
		{
			Contract = 0,
			Hours,
			BidPrice,
			BidQty,
			BidOperator,
			AskPrice,
			AskQty,
			AskOperator,
			LastPrice,
			LastQty,
			LastTime,
			MaxPrice,
			MinPrice,
			Volume,
			ConvPrice,
			OffPrice,
			RefPrice,
			_TUTTI_
		} ;

		// ====================================
		// Posizioni delle Colonne nel DataGrid
		// ====================================
		// !!!ATTENZIONE!!!
		// L'ordine con il quale le colonne compaiono in questa lista � l'ordine
		// delle colonne visualizzate nel DataGrid. Per cambiare quindi quest'ordine
		// � sufficiente alterare l'ordine di questo Enum. Il Tag _TUTTI_ deve rimanere
		// SEMPRE E COMUNQUE in fondo!!!
		// !!!ATTENZIONE!!!
		// La lista pu� contenere UN SOTTOINSIEME delle colonne del DataSource, le
		// colonne contenute saranno le uniche che compariranno nel DataGrid.
		// !!!ATTENZIONE!!!
		// Nei metodi di Handling di PBs che reperiscono dati dal DataGrid, sono
		// estraibili dal DataGrid stesso SOLO LE COLONNE PRESENTI IN QUESTA LISTA!!!
		// ==============================================
		public enum enPosColonneDG
		{
			Contract = 0,
			Hours,

			// Nuovo Ordine delle colonne stabilito dopo DEMO Bipex in Enel del 03.10.2005
			BidQty,
			BidPrice,
			AskPrice,
			AskQty,
			
			LastPrice,
			LastQty,
			LastTime,
			MaxPrice,
			MinPrice,
			Volume,
			ConvPrice,
			OffPrice,
			RefPrice,
			_TUTTI_
		} ;

		private DataSet dsMainDG = null;
		private DataGrid dgBook;
		private ContextMenu cmMainDG;
		private System.Windows.Forms.Timer tmBookRefresh;
		private System.ComponentModel.IContainer components;

		// Il Currency Mgr serve a tenere memoria dello stato del datagrid
		// con riferimento alle righe visibili, ad esempio in base al filtro
		// attivo.
		// Per cui, tutte le volte che si altera la composizione del dataview
		// in termini di righe contenute, ad es. applicando un filtro, si deve
		// AGGIORNARE la proprieta' BindingContext del DataView...
		private CurrencyManager _cmMainDG;

		private string _sThisFormTitle;
		public FilterOnCategory dvFilter = new FilterOnCategory();

		private DataRow _dr = null; 
		public delegate void BookRiassuntivoRowChangedDelegate(string Contract);
		public event BookRiassuntivoRowChangedDelegate BookRiassuntivoRowChanged;

		public frmBook()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			// Memorizzo il Title del form stabilito a design time perche'
			// a run time lo devo concatenare con altre info...
			_sThisFormTitle = this.Text;

		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Codice generato da Progettazione Windows Form

		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.dgBook = new System.Windows.Forms.DataGrid();
			this.cmMainDG = new System.Windows.Forms.ContextMenu();
			this.tmBookRefresh = new System.Windows.Forms.Timer(this.components);
			((System.ComponentModel.ISupportInitialize)(this.dgBook)).BeginInit();
			this.SuspendLayout();
			// 
			// dgBook
			// 
			this.dgBook.AlternatingBackColor = System.Drawing.SystemColors.ControlLight;
			this.dgBook.CaptionVisible = false;
			this.dgBook.DataMember = "";
			this.dgBook.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgBook.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgBook.Location = new System.Drawing.Point(0, 0);
			this.dgBook.Name = "dgBook";
			this.dgBook.ParentRowsVisible = false;
			this.dgBook.ReadOnly = true;
			this.dgBook.SelectionBackColor = System.Drawing.SystemColors.ControlDark;
			this.dgBook.Size = new System.Drawing.Size(962, 638);
			this.dgBook.TabIndex = 1;
			this.dgBook.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgBook_MouseDown);
			// 
			// tmBookRefresh
			// 
			this.tmBookRefresh.Interval = 1000;
			this.tmBookRefresh.Tick += new System.EventHandler(this.tmBookRefresh_Tick);
			// 
			// frmBook
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(962, 638);
			this.Controls.Add(this.dgBook);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Name = "frmBook";
			this.Text = "Main Book";
			this.Load += new System.EventHandler(this.frmBook_Load);
			this.VisibleChanged += new System.EventHandler(this.frmBook_VisibleChanged);
			((System.ComponentModel.ISupportInitialize)(this.dgBook)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		DataRecordList _drlBR;
		volatile BipexSubject _sBR;
		volatile bool _Visible = false;

		private void frmBook_Load(object sender, EventArgs e)
		{
			cmMainDG = new ContextMenu();
			cmMainDG.MenuItems.Add("&Buy", new EventHandler(cmMainDG_Buy_Clicked));
			cmMainDG.MenuItems.Add("&Sell", new EventHandler(cmMainDG_Sell_Clicked));
			cmMainDG.MenuItems.Add("&Help", new EventHandler(cmMainDG_Help_Clicked));

			dgBook.ContextMenu = cmMainDG;

			// Pulisco il DataGrid e lo ricostruisco in base al contenuto del DataSet...
			dgBook.DataSource = null;

			BookRiassuntivo_Load();

			if (dsMainDG != null)
				BindDataGrid(dgBook, dsMainDG);

			_Visible = this.Visible;		
		}

		private void BookRiassuntivo_Load()
		{
			dsMainDG = new DataSet();

			_drlBR = new DataRecordList();
			_drlBR.Version = 0;

			_sBR = new BipexSubject();
			_sBR.DataDiMercato = DateTime.Now.Date;
			_sBR.SubjectType = "BR";
			_sBR.SubjectSubType = string.Empty;
			_sBR.Version = _drlBR.Version;

			DataSetMerger.CreateTable(dsMainDG, "BR", typeof(BookRiassuntivoDR));

		}

		private void BindDataGrid(DataGrid dg, DataSet ds)
		{
			if (ds != null)
				SetDataGridTableStyles(dg, "BR");

			FillDataGrid(dg, ds, dvFilter);
			
			SetTitleOnFilterOnCategory(dvFilter);
		}

		private void SetTitleOnFilterOnCategory(FilterOnCategory dvFilter)
		{
			if (dvFilter.bAtLeastOneIsFiltered())
				this.Text = _sThisFormTitle + " (Filtered)";
			else
				this.Text = _sThisFormTitle;
		}

		private void SetDataGridTableStyles(DataGrid dg, string sMappingName)
		{
			dg.TableStyles.Clear();

			DataGridTableStyle dgsBook = new DataGridTableStyle();

			// !!!ATTENZIONE!!!
			// WORKAROUND PER RISOLUZIONE PROBLEMA
			// SE SI RIDEFINISCE UN PROPRIO TABLESTYLE 
			// PER VISUALIZZARE UN DATATABLE,
			// OCCORRE RIASSEGNARE ESPLICITAMENTE I COLORI!!!,
			// altrimenti ad esempio impostazioni come l'alternate
			// color vanno perdute...
			dgsBook.AlternatingBackColor = BipexFormSettings.AlternatingBackColor;
			dgsBook.BackColor = BipexFormSettings.BackColor;
			dgsBook.ForeColor = BipexFormSettings.ForeColor;
			dgsBook.GridLineColor = BipexFormSettings.GridLineColor;
			dgsBook.HeaderBackColor = BipexFormSettings.HeaderBackColor;
			dgsBook.HeaderForeColor = BipexFormSettings.HeaderForeColor;
			dgsBook.LinkColor = BipexFormSettings.LinkColor;
			dgsBook.SelectionBackColor = BipexFormSettings.SelectionBackColor;
			dgsBook.SelectionForeColor = BipexFormSettings.SelectionForeColor;

			dgsBook.AllowSorting = true;
			dgsBook.RowHeadersVisible = false;

			dgsBook.MappingName = sMappingName;

			DataGridAlignedTextBoxColumn[] dgcBook = new DataGridAlignedTextBoxColumn[(int) enPosColonneDG._TUTTI_];
			for (int i = 0; i < dgcBook.Length; ++i)
				dgcBook[i] = new DataGridAlignedTextBoxColumn();
			int index = 0;

			index = iDataGridPosition[(int) enPosColonneDG.Contract];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.Contract];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.Contract];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.Contract];

			index = iDataGridPosition[(int) enPosColonneDG.Hours];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.Hours];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.Hours];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.Hours];

			index = iDataGridPosition[(int) enPosColonneDG.BidPrice];
			dgcBook[index] = new DataGridBestPriceTextBoxColumn(MappingNames[(int) enPosColonneDS.BidOperator], "Bid", DataGridBestPriceTextBoxColumn.HighLightType.BackGround);
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.BidPrice];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.BidPrice];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.BidPrice];

			index = iDataGridPosition[(int) enPosColonneDG.BidQty];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.BidQty];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.BidQty];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.BidQty];

			index = iDataGridPosition[(int) enPosColonneDG.AskPrice];
			dgcBook[index] = new DataGridBestPriceTextBoxColumn(MappingNames[(int) enPosColonneDS.AskOperator], "Ask", DataGridBestPriceTextBoxColumn.HighLightType.BackGround);
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.AskPrice];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.AskPrice];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.AskPrice];

			index = iDataGridPosition[(int) enPosColonneDG.AskQty];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.AskQty];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.AskQty];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.AskQty];

			index = iDataGridPosition[(int) enPosColonneDG.LastPrice];
			dgcBook[index] = new DataGridLastAbbTextBoxColumn(DataGridLastAbbTextBoxColumn.HighLightType.BackGround);
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.LastPrice];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.LastPrice];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.LastPrice];

			index = iDataGridPosition[(int) enPosColonneDG.LastQty];
			dgcBook[index] = new DataGridLastAbbTextBoxColumn(DataGridLastAbbTextBoxColumn.HighLightType.BackGround);
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.LastQty];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.LastQty];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.LastQty];

			index = iDataGridPosition[(int) enPosColonneDG.LastTime];
			dgcBook[index] = new DataGridLastAbbTextBoxColumn(DataGridLastAbbTextBoxColumn.HighLightType.BackGround);
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.LastTime];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.LastTime];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForTimeWithAMPM;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.LastTime];

			index = iDataGridPosition[(int) enPosColonneDG.MaxPrice];
			dgcBook[index] = new DataGridMaxMinPriceTextBoxColumn("Max", DataGridMaxMinPriceTextBoxColumn.HighLightType.BackGround);
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.MaxPrice];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.MaxPrice];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.MaxPrice];

			index = iDataGridPosition[(int) enPosColonneDG.MinPrice];
			dgcBook[index] = new DataGridMaxMinPriceTextBoxColumn("Min", DataGridMaxMinPriceTextBoxColumn.HighLightType.BackGround);
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.MinPrice];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.MinPrice];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.MinPrice];

			index = iDataGridPosition[(int) enPosColonneDG.Volume];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.Volume];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.Volume];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.Volume];

			index = iDataGridPosition[(int) enPosColonneDG.ConvPrice];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.ConvPrice];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.ConvPrice];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.ConvPrice];

			index = iDataGridPosition[(int) enPosColonneDG.OffPrice];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.OffPrice];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.OffPrice];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.OffPrice];

			index = iDataGridPosition[(int) enPosColonneDG.RefPrice];
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = MappingNames[(int) enPosColonneDS.RefPrice];
			dgcBook[index].HeaderText = HeaderTexts[(int) enPosColonneDS.RefPrice];
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].ColumnIsVisible = true;
			dgcBook[index].Width = InitialWidths[(int) enPosColonneDS.RefPrice];

			dgsBook.GridColumnStyles.AddRange(dgcBook);
			dg.TableStyles.Add(dgsBook);

		}

		public void FillDataGrid(DataGrid dg, DataSet ds, FilterOnCategory dvFilter)
		{
			DataView dv = new DataView(ds.Tables[0]);

			// In base alla struttura filtro ricevuta costruisco la stringa di
			// filtro da applicare al dataview...

			string tmpMappingName = MappingNames[(int) enPosColonneDS.Contract];
			string tmpFilter = string.Empty;
			if (dvFilter.bDailyBaseLoad)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'D*' AND " + tmpMappingName + " LIKE '*BSLD*')");
			}
			if (dvFilter.bDailyOffPeak)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'D*' AND " + tmpMappingName + " LIKE '*OFPK*')");
			}
			if (dvFilter.bDailyPeak)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'D*' AND " + tmpMappingName + " LIKE '*PEAK*')");
			}
			if (dvFilter.bWeeklyBaseLoad)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'W*' AND " + tmpMappingName + " LIKE '*BSLD*')");
			}
			if (dvFilter.bWeeklyOffPeak)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'W*' AND " + tmpMappingName + " LIKE '*OFPK*')");
			}
			if (dvFilter.bWeeklyPeak)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'W*' AND " + tmpMappingName + " LIKE '*PEAK*')");
			}
			if (dvFilter.bMonthlyBaseLoad)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'M*' AND " + tmpMappingName + " LIKE '*BSLD*')");
			}
			if (dvFilter.bMonthlyOffPeak)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'M*' AND " + tmpMappingName + " LIKE '*OFPK*')");
			}
			if (dvFilter.bMonthlyPeak)
			{
				if (tmpFilter != string.Empty) tmpFilter += " OR ";
				tmpFilter += ("(" + tmpMappingName + " LIKE 'M*' AND " + tmpMappingName + " LIKE '*PEAK*')");
			}
			
			dv.RowFilter = tmpFilter;

			dv.AllowDelete = false;
			dv.AllowEdit = false;
			dv.AllowNew = false;

			//Imposto il colore delle righe pari a un colore leggermente
			//piu` scuro di quello utilizzato per le righe dispari.
			int piuScuro = 10;
			int R = dg.BackColor.R - piuScuro;
			int G = dg.BackColor.G - piuScuro;
			int B = dg.BackColor.B - piuScuro;
			if (R < 0) R = 10;
			if (G < 0) G = 10;
			if (B < 0) B = 10;
			Color colore = Color.FromArgb(R, G, B);
			dg.AlternatingBackColor = colore;

			//dg.TableStyles.Clear();
			//dg.TableStyles.IsReadOnly = true;
			//dg.TableStyles.Add(stile);
			dg.AllowNavigation = false;

			dg.DataSource = dv;

			_cmMainDG = (CurrencyManager)this.BindingContext[dv];
			_cmMainDG.CurrentChanged += new EventHandler(_cmMainDG_CurrentChanged);
			dv.ListChanged += new ListChangedEventHandler(_cmMainDG_ListChanged);

			return;
		}

		public void _cmMainDG_CurrentChanged(object sender, EventArgs e)
		{
			try
			{
				DataRow dr = GetContrattoCorrente();
				if (_dr == null || _dr != dr)
				{
					_dr = dr;
					SendBookRiassuntivoRowChanged(dr);
				}
			}
			catch
			{
			}
		}
		private void _cmMainDG_ListChanged(object sender, ListChangedEventArgs e)
		{
			if (_cmMainDG.Position == 0)
			{
				try
				{
					DataRow dr = GetContrattoCorrente();
					// L'update in BackGround del DataSet associato al DataGrid
					// causa MOLTISSIMI eventi di tipo ListChanged, invio la
					// notifica del cambio di riga selezionata solo quando cio'
					// si verifica effettivamente...
					if (_dr == null || _dr != dr)
					{
						_dr = dr;
						SendBookRiassuntivoRowChanged(dr);
					}
				}
				catch
				{
				}
			}
		}

		private DataRow GetContrattoCorrente()
		{
			if (_cmMainDG.Count == 0)
				return null;
			DataView dv = (DataView)_cmMainDG.List;
			if (dv.Count == 0)
				return null;
			DataRow dr = dv[_cmMainDG.Position].Row;
			return dr;
		}

		public void SendBookRiassuntivoRowChanged(DataRow dr)
		{
			string tmp = dr[MappingNames[(int) frmBook.enPosColonneDS.Contract]].ToString();
			if (BookRiassuntivoRowChanged != null)
			{
				BookRiassuntivoRowChanged(tmp);
			}
		}

		public void btnStart_Click(object sender, EventArgs e)
		{
			tmBookRefresh.Enabled = true;
		}

		public void btnStop_Click(object sender, EventArgs e)
		{
			tmBookRefresh.Enabled = false;
		}

		public void cmMainDG_Help_Clicked(object sender, EventArgs e)
		{
			if (dgBook.CurrentRowIndex != -1)
			{
				string ContractID = dgBook[dgBook.CurrentRowIndex, 0].ToString();
				MessageBox.Show(this.Owner, "HELP ON <" + ContractID + ">.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
		}

		public void cmMainDG_Buy_Clicked(object sender, EventArgs e)
		{
			if (dgBook.CurrentRowIndex != -1)
			{
				DataRow dr = GetContrattoCorrente();
				if (dr == null)
					return;

				if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
				{
					dgBook_HandleOfferta(dr, "A");
				}
				else
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
		}

		public void cmMainDG_Sell_Clicked(object sender, EventArgs e)
		{
			if (dgBook.CurrentRowIndex != -1)
			{
				DataRow dr = GetContrattoCorrente();
				if (dr == null)
					return;

				if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
				{
					dgBook_HandleOfferta(dr, "V");
				}
				else
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
		}

		private void dgBook_MouseDown(object sender, MouseEventArgs e)
		{
			DataGrid.HitTestInfo ht = dgBook.HitTest(e.X, e.Y);

			// Deseleziono righe eventualmente selezionate in questo momento
			// (anche selezioni multiple) ed imposto come selezionata la riga corrente
			if (ht.Type == DataGrid.HitTestType.Cell || ht.Type == DataGrid.HitTestType.RowHeader)
			{
				if (_cmMainDG.Count == 0)
					return;
				DataView dv = (DataView)_cmMainDG.List;
				if (dv.Count == 0)
					return;

				for (int i = 0; i < dv.Count; ++i)
					if (dgBook.IsSelected(i))
						dgBook.UnSelect(i);

				// LACCHEZZO IGNOBILE
				// LACCHEZZO IGNOBILE
				// LACCHEZZO IGNOBILE
				// LA RIGA VIENE SELEZIONATA, A FRONTE DEL RIGHT CLICK, SE E SOLO SE 
				// IL RIGHT CLICK PROVOCA UN CELL CHANGED!!! MA SE IL LEFT CLICK 
				// PRECEDENTE SULLA RIGA, PER MOTIVI DI IMPLEMENTAZIONE DEL LEFT CLICK, 
				// NON SELEZIONA LA RIGA, ECCO CHE IL RIGHT CLICK SULLA STESSA CELLA 
				// NON GENERA L'EVENTO DI CELL CHANGED!!! NEL MODO QUI SOTTO INVECE 
				// IO GENERO SEMPRE E COMUNQUE UN CELL CHANGED...
				int ColumnAlternate = 0;
				if (ht.Column > 0)
					ColumnAlternate = ht.Column - 1;
				else
					ColumnAlternate = 1;

				dgBook.CurrentCell = new DataGridCell(ht.Row, ColumnAlternate);
				dgBook.CurrentCell = new DataGridCell(ht.Row, ht.Column);

				dgBook.CurrentRowIndex = ht.Row;

			}

			if (e.Button == MouseButtons.Left && e.Clicks == 2)
			{
				if (ht.Type == DataGrid.HitTestType.ColumnHeader || ht.Type == DataGrid.HitTestType.ColumnResize)
				{
					// Se sono qui uno ha fatto doppio clic sulla riga di intestazione del datagrid...
				}
				else
					if (ht.Type == DataGrid.HitTestType.Cell)
				{
					// Se sono qui uno ha fatto doppio clic sulla riga di intestazione del datagrid...

					// Doppio Click sulle Colonne ASK >> Popup di Acquisto
					// Doppio Click sulle Colonne BID >> Popup di Vendita
					if (dgBook.CurrentRowIndex != -1)
					{

						DataRow dr = GetContrattoCorrente();
						if (dr == null)
							return;

						string tmpName = dgBook.TableStyles[0].GridColumnStyles[this.dgBook.CurrentCell.ColumnNumber].MappingName;
						if (tmpName == MappingNames[(int) enPosColonneDS.AskPrice] || tmpName == MappingNames[(int) enPosColonneDS.AskQty])
						{
							if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
							{
								dgBook_HandleOfferta(dr, "A");
							}
							else
							{
								MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
								return;
							}
						}
						else
							if (tmpName == MappingNames[(int) enPosColonneDS.BidPrice] || tmpName == MappingNames[(int) enPosColonneDS.BidQty])
							{
								if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.APERTA)
								{
									dgBook_HandleOfferta(dr, "V");
								}
								else
								{
									MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
									return;
								}
							}
							else
							{
								MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_BUYPLACEASKPLACE"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
								return;
							}
					}
					else
					{
						MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_PLACECURSORONAVALIDROW"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						return;
					}
					return;
				}
			}

			// Menu` contestuale: qui lo si puo' abilitare o meno testando
			// le condizioni che ci interessano sulla riga selezionata oppure
			// comporlo in modo DINAMICO in funzione delle caratteristiche della
			// riga selezionata...
			bool b = true;
			if (b)
				dgBook.ContextMenu = this.cmMainDG;
			else
				dgBook.ContextMenu = null;

		}

		public void btnFontPIU_Click(object sender, EventArgs e)
		{
			if (this.dgBook.Font.Size < BipexFormSettings.ChangeFontMaxSize)
			{
				Font newFont = new Font(this.dgBook.Font.FontFamily.Name, this.dgBook.Font.Size + BipexFormSettings.ChangeFontIncrement, this.dgBook.Font.Style);
				this.dgBook.Font = newFont;
			}
		}

		public void btnFontMENO_Click(object sender, EventArgs e)
		{
			if (this.dgBook.Font.Size > BipexFormSettings.ChangeFontMinSize)
			{
				Font newFont = new Font(this.dgBook.Font.FontFamily.Name, this.dgBook.Font.Size - BipexFormSettings.ChangeFontIncrement, this.dgBook.Font.Style);
				this.dgBook.Font = newFont;
			}
		}

		public void btnColPos_Click(object sender, EventArgs e)
		{
			if (frmSC != null)
				frmSC.Dispose();

			for (int i = 0; i < this.dgBook.TableStyles[0].GridColumnStyles.Count; i++)
				iDataGridPosition[i] = i;

			frmSC = new frmSortColumn(this.dgBook.TableStyles[0], HeaderTexts, ref iDataGridPosition);
			frmSC.ShowDialog(this);
			if (frmSC.bRC)
			{
				// E' cambiata la posizione delle colonne...
				if (dsMainDG != null)
					BindDataGrid(dgBook, dsMainDG);
			}

		}

		public void btnFilterOnCat_Click(object sender, System.EventArgs e)
		{
			if (frmBFOC != null)
				frmBFOC.Dispose();

			frmBFOC = new frmBookFilterOnCategory(ref dvFilter);
			frmBFOC.ShowDialog(this);
			if (frmBFOC.bRC)
			{
				// Sono cambiati i filtri sulle righe...
				if (dsMainDG != null)
					BindDataGrid(dgBook, dsMainDG);
			}
		}

		private void tmBookRefresh_Tick(object sender, System.EventArgs e)
		{
		}

		private void dgBook_HandleOfferta(DataRow dr, string tipo)
		{

			frmOf = new frmOfferta(dr, MappingNames, tipo);

			// ATTENZIONE!!!
			// ATTENZIONE!!!
			// ATTENZIONE!!!
			// Per ora NO offerte nella taskbar...
			frmOf.ShowInTaskbar = false;

			// Mi dichiaro come owner della finestra figlia che ospita l'offerta,
			// questo fa si' che TUTTE le finestre modeless di offerta restano
			// in primo piano, NON SOLO l'ultima che si genera...
			this.AddOwnedForm(frmOf);
			frmOf.Show();

			// ATTENZIONE!!!
			// ATTENZIONE!!!
			// ATTENZIONE!!!
			// NON E' NECESSARIO RICHIAMARE LA REMOVEOWNEDFORM QUANDO SI FA LA
			// CLOSE DEL PNL FIGLIO, LA REMOVE VIENE FATTA AUTOMATICAMENTE DAL
			// FRAMEWORK...

			return;
		
		}

		/// <summary>
		/// La classe incapsula il comportamento grafico delle colonne "Best Bid/Ask"
		/// del form e cioe':
		/// Vengono evidenziate in blu, per un intervallo di tempo predefinito,
		/// le celle relative a offerte inserite da un utente dell'operatore collegato.
		/// Qualora le offerte non siano state inserite da un utente 
		/// dell'operatore collegato:
		///		Vengono evidenziate in rosso, per un intervallo di tempo predefinito,
		///		le OFFERTE con prezzo in DISCESA;
		///		Vengono evidenziate in verde, per un intervallo di tempo predefinito,
		///		le OFFERTE con prezzo in SALITA.
		/// </summary>
		private class DataGridBestPriceTextBoxColumn : DataGridAlignedTextBoxColumn
		{
			private static Brush _fnero = new SolidBrush(Color.Black);
			private static Brush _fblu = new SolidBrush(Color.Blue);
			private static Brush _fbianco = new SolidBrush(Color.White);
			private static Brush _bblu = new SolidBrush(Color.Blue);
			private static Brush _frosso = new SolidBrush(Color.Red);
			private static Brush _brosso = new SolidBrush(Color.LightCoral);
			private static Brush _fverde = new SolidBrush(Color.Green);
			private static Brush _bverde = new SolidBrush(Color.LightGreen);

			/// <summary>
			/// I tipi di evidenziazione ammessi
			/// </summary>
			public enum HighLightType
			{
				BackGround = 0,
				Foreground
			}

			private string bestUserColumn;
			private string columnType;
			private HighLightType highlightType;

			public DataGridBestPriceTextBoxColumn(string aBestUserColumn, string aColumnType, HighLightType aType)
			{
				// La classe derivata si occupa della gestione dei colori di BG e FG
				// per cui cio' non deve essere fatto nella classe base...
				bColorSetInDerivedClass = true;

				bestUserColumn = aBestUserColumn;
				columnType = aColumnType;
				highlightType = aType;
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
			                              int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				try
				{
					// Questa e' la riga corrente...
					DataRow dr = ((DataView) cm.List)[rowNum].Row;

					// ...e questi sono i valori delle celle della riga corrente...
					bool bUserIsME = false;
					if (dr[bestUserColumn] != System.Convert.DBNull)
					{
						if (EngineMainForm._tspParams.LoginActive)
							bUserIsME = ((string) dr[bestUserColumn] == EngineMainForm._tspParams.ActiveOperatorCode);
					}
					string sTrend = "Fermo";
					if (dr["Indicators"] != System.Convert.DBNull)
					{
						if (columnType == "Bid")
						{
							if (BookRiassuntivoDR.IsBestBidTrendUP((BookRiassuntivoDR.Indicator) dr["Indicators"]))
								sTrend = "Su";
							else
								if (BookRiassuntivoDR.IsBestBidTrendDown((BookRiassuntivoDR.Indicator) dr["Indicators"]))
								sTrend = "Giu";
						}
						else
							if (columnType == "Ask")
						{
							if (BookRiassuntivoDR.IsBestAskTrendUP((BookRiassuntivoDR.Indicator) dr["Indicators"]))
								sTrend = "Su";
							else
								if (BookRiassuntivoDR.IsBestAskTrendDown((BookRiassuntivoDR.Indicator) dr["Indicators"]))
								sTrend = "Giu";
						}
					}

					if (bUserIsME)
					{
						// L'offerta e' MIA
						switch (highlightType)
						{
						case HighLightType.BackGround:
							myForeBrush = _fbianco;
							myBackBrush = _bblu;
							break;
						case HighLightType.Foreground:
							myForeBrush = _fblu;
							myBackBrush = backBrush;
							break;
						}
					}
					else
					{
						// L'offerta NON e' MIA
						switch (sTrend)
						{
						case "Fermo":
							break;
						case "Giu":
							{
								switch (highlightType)
								{
								case HighLightType.BackGround:
									myForeBrush = _fnero;
									myBackBrush = _brosso;
									break;
								case HighLightType.Foreground:
									myForeBrush = _frosso;
									myBackBrush = backBrush;
									break;
								}
								break;
							}
						case "Su":
							{
								switch (highlightType)
								{
								case HighLightType.BackGround:
									myForeBrush = _fnero;
									myBackBrush = _bverde;
									break;
								case HighLightType.Foreground:
									myForeBrush = _fverde;
									myBackBrush = backBrush;
									break;
								}
							}
							break;
						}
					}
				}
				catch
				{
					Debug.Assert(false);
				}

				base.Paint(g, bounds, cm, rowNum, myBackBrush, myForeBrush, alignToRight);
			}

		}

		/// <summary>
		/// La classe incapsula il comportamento grafico delle colonne della
		/// sezione "Ultimo Abbinamento" del form e cioe':
		/// Vengono evidenziate in grigio, per un intervallo di tempo predefinito,
		/// le celle relative a Contratti OTC.
		/// </summary>
		private class DataGridLastAbbTextBoxColumn : DataGridAlignedTextBoxColumn
		{
			private static Brush _fbianco = new SolidBrush(Color.White);
			private static Brush _fgrigio = new SolidBrush(Color.Gray);
			private static Brush _bgrigio = new SolidBrush(Color.Gray);

			/// <summary>
			/// I tipi di evidenziazione ammessi
			/// </summary>
			public enum HighLightType
			{
				BackGround = 0,
				Foreground
			}

			private HighLightType highlightType;

			public DataGridLastAbbTextBoxColumn(HighLightType type)
			{
				// La classe derivata si occupa della gestione dei colori di BG e FG
				// per cui cio' non deve essere fatto nella classe base...
				bColorSetInDerivedClass = true;

				highlightType = type;
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
			                              int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				try
				{
					// Questa e' la riga corrente...
					DataRow dr = ((DataView) cm.List)[rowNum].Row;

					// ...e questi sono i valori delle celle della riga corrente...
					bool bOffertaIsOTC = false;
					if (dr["Indicators"] != System.Convert.DBNull)
					{
						// Il NUOVO metodo NON STATICO IsLastAbbIsOTC non e' piu' utilizzabile in questo
						// contesto per cui occorre ripetere qui "fuori" dal metodo la logica
						// contenuta nel metodo stesso (che e' questa qui sotto)...
						/*
						if (IsNull("LastIsOTC"))
							return false;
						return LastIsOTC == "S";
						*/

						if (!(dr.IsNull("LastIsOTC")))
							if (FormatObjectAsString(dr["LastIsOTC"], BipexFormSettings.FmtForGenericString)  == "S")
							{
								bOffertaIsOTC = true;
							}
					}

					if (bOffertaIsOTC)
					{
						// L'offerta e' OTC
						switch (highlightType)
						{
						case HighLightType.BackGround:
							myForeBrush = _fbianco;
							myBackBrush = _bgrigio;
							break;
						case HighLightType.Foreground:
							myForeBrush = _fgrigio;
							myBackBrush = backBrush;
							break;
						}
					}

					bItalic = bOffertaIsOTC;

				}
				catch
				{
					Debug.Assert(false);
				}

				base.Paint(g, bounds, cm, rowNum, myBackBrush, myForeBrush, alignToRight);
			}

		}

		/// <summary>
		/// La classe incapsula il comportamento grafico delle colonne del
		/// tipo "Max Price", "Min Price" del form e cioe':
		/// Vengono evidenziate in giallo, per un intervallo di tempo predefinito,
		/// le celle per le quali il prezzo massimo e' uguale a quello
		/// dell'ultimo abbinamento
		/// </summary>
		private class DataGridMaxMinPriceTextBoxColumn : DataGridAlignedTextBoxColumn
		{
			private static Brush _fnero = new SolidBrush(Color.Black);
			private static Brush _fgiallo = new SolidBrush(Color.Yellow);
			private static Brush _bgiallo = new SolidBrush(Color.Yellow);

			/// <summary>
			/// I tipi di evidenziazione ammessi
			/// </summary>
			public enum HighLightType
			{
				BackGround = 0,
				Foreground
			}

			private string columnType;
			private HighLightType highlightType;

			public DataGridMaxMinPriceTextBoxColumn(string aColumnType, HighLightType type)
			{
				// La classe derivata si occupa della gestione dei colori di BG e FG
				// per cui cio' non deve essere fatto nella classe base...
				bColorSetInDerivedClass = true;

				columnType = aColumnType;
				highlightType = type;
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
			                              int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				try
				{
					// Questa e' la riga corrente...
					DataRow dr = ((DataView) cm.List)[rowNum].Row;

					// ...e questi sono i valori delle celle della riga corrente...
					bool bMatchLastAbb = false;
					if (dr["Indicators"] != System.Convert.DBNull)
					{
						// Il NUOVO metodo NON STATICO IsMaxPriceIsLastAbb non e' piu' utilizzabile in questo
						// contesto per cui occorre ripetere qui "fuori" dal metodo la logica
						// contenuta nel metodo stesso (che e' questa qui sotto)...
						/*
						if (IsNull("LastPrice") || IsNull("MaxPrice")) return false;
						return LastPrice == MaxPrice;
						*/

						if (columnType == "Max")
						{
							if (!(dr.IsNull("LastPrice")) && !(dr.IsNull("MaxPrice")))
							{
								double tmpLP = Convert.ToDouble(dr["LastPrice"], Thread.CurrentThread.CurrentCulture);
								double tmpMP = Convert.ToDouble(dr["MaxPrice"], Thread.CurrentThread.CurrentCulture);
								if (tmpLP == tmpMP)
									bMatchLastAbb = true;
							}
						}
						else
							if (columnType == "Min")
							{
								if (!(dr.IsNull("LastPrice")) && !(dr.IsNull("MinPrice")))
								{
									double tmpLP = Convert.ToDouble(dr["LastPrice"], Thread.CurrentThread.CurrentCulture);
									double tmpMP = Convert.ToDouble(dr["MinPrice"], Thread.CurrentThread.CurrentCulture);
									if (tmpLP == tmpMP)
										bMatchLastAbb = true;
								}
							}

					}

					if (bMatchLastAbb)
					{
						// Il prezzo della cella corrente e' da evidenziare...
						switch (highlightType)
						{
						case HighLightType.BackGround:
							myForeBrush = _fnero;
							myBackBrush = _bgiallo;
							break;
						case HighLightType.Foreground:
							myForeBrush = _fgiallo;
							myBackBrush = backBrush;
							break;
						}
					}

				}
				catch
				{
					Debug.Assert(false);
				}

				base.Paint(g, bounds, cm, rowNum, myBackBrush, myForeBrush, alignToRight);
			}

		}

		/// <summary>
		/// La classe consente di gestire l'allineamento separato tra l'header text
		/// di una colonna ed i dati contenuti nelle celle nella colonna stessa
		/// 
		/// Derivando da questa classe si ottiene che:
		/// 
		/// -	La proprieta' standard Alignment serve a gestire l'allineamento
		///		dell'header (ATTENZIONE: HorizontalAlignment.Right CAUSA UN CLIPPING
		///		DELL'HEADER TEXT e quindi e' meglio non usarlo!);
		///	-	La proprieta' custom DataAlignment serve a gestire l'allineamento
		///		del dato nella cella.
		/// </summary>
		private class DataGridAlignedTextBoxColumn : DataGridTextBoxColumn
		{
			protected bool bColorSetInDerivedClass = false;
			protected bool bItalic = false;
			protected bool bUnderline = false;
			private HorizontalAlignment dataAlignment = HorizontalAlignment.Center;
			private bool columnIsVisible = true;

			/// <summary>
			/// La proprieta' serve a gestire l'allineamento del dato nella cella.
			/// </summary>
			public HorizontalAlignment DataAlignment
			{
				get { return this.dataAlignment; }
				set { this.dataAlignment = value; }
			}

			/// <summary>
			/// La proprieta' serve a gestire lo stato di visibile/invisibile della colonna.
			/// </summary>
			public bool ColumnIsVisible
			{
				get { return this.columnIsVisible; }
				set { this.columnIsVisible = value; }
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
			                              int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// !!!ATTENZIONE!!!
				// WORKAROUND PER RISOLUZIONE PROBLEMA
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// (per default, il click sulla barra a sz delle celle fa il paint mentre
				// il click sulle celle stesse non fa il paint!!!)

				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum & !bColorSetInDerivedClass)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				// Questa e' la riga corrente...
				DataRow dr = ((DataView) cm.List)[rowNum].Row;

				// ...e questi sono i valori delle celle della riga corrente...
				string strCellText = "";
				if (dr[this.MappingName] != System.Convert.DBNull)
					// Converto il valore in stringa per poterlo riscrivere, devo
					// tenere conto dell'attributo di formattazione eventualmente
					// impostato dall'utente del datagrid...
					strCellText = FormatObjectAsString(dr[this.MappingName], this.Format);

				// Determino l'allineamento in funzione della property impostata dall'utente della classe
				StringFormat stringFormat = new StringFormat();
				switch (DataAlignment)
				{
				case HorizontalAlignment.Center:
					stringFormat.Alignment = StringAlignment.Center;
					break;
				case HorizontalAlignment.Left:
					stringFormat.Alignment = StringAlignment.Near;
					break;
				case HorizontalAlignment.Right:
					stringFormat.Alignment = StringAlignment.Far;
					break;
				}

				// Disegno BackGround sul rect da refreshare...
				g.FillRectangle(myBackBrush, bounds);
				// Calcolo nuovo rect...
				RectangleF CellBounds = new RectangleF(bounds.Left, bounds.Top + 3, bounds.Width, bounds.Height);

				// Refresh del contenuto della cella...
				if (bItalic && bUnderline)
				{
					System.Drawing.Font tmpFont = new Font(this.DataGridTableStyle.DataGrid.Font, FontStyle.Italic | FontStyle.Underline);
					g.DrawString(strCellText, tmpFont, myForeBrush, CellBounds, stringFormat);
				}
				else
					if (bItalic)
				{
					System.Drawing.Font tmpFont = new Font(this.DataGridTableStyle.DataGrid.Font, FontStyle.Italic);
					g.DrawString(strCellText, tmpFont, myForeBrush, CellBounds, stringFormat);
				}
				else
					if (bUnderline)
				{
					System.Drawing.Font tmpFont = new Font(this.DataGridTableStyle.DataGrid.Font, FontStyle.Underline);
					g.DrawString(strCellText, tmpFont, myForeBrush, CellBounds, stringFormat);
				}
				else
					g.DrawString(strCellText, this.DataGridTableStyle.DataGrid.Font, myForeBrush, CellBounds, stringFormat);

			}

			private int SelectedRow = -1;

			protected override void Edit(CurrencyManager source, int rowNum, Rectangle bounds, bool readOnly, string instantText, bool cellIsVisible)
			{
				// Per evitare crash testare che ci sia una selezione valida
				// prima di fare la deselezione...
				if (SelectedRow > -1 && SelectedRow < source.List.Count + 1)
					this.DataGridTableStyle.DataGrid.UnSelect(SelectedRow);
			}

			protected string FormatObjectAsString(object o, string Format)
			{
				if (o.GetType() == typeof (DateTime))
				{
					DateTime tmp = Convert.ToDateTime(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (double))
				{
					double tmp = Convert.ToDouble(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (decimal))
				{
					decimal tmp = Convert.ToDecimal(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (short))
				{
					short tmp = Convert.ToInt16(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (int))
				{
					int tmp = Convert.ToInt32(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (long))
				{
					long tmp = Convert.ToInt64(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else
				{
					// Type non gestito con formattazione specifica, richiamo il metodo
					// standard di conversione in stringa...
					return o.ToString();
				}
			}
		}

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			//			if (this.InvokeRequired)
			//			{
			//				GetBipexSubjectDelegate d = new GetBipexSubjectDelegate(GetBipexSubject);
			//				return (BipexSubject[]) this.Invoke(d);
			//			}
			//			else
			//			{
			//				if (this.Visible)
			//					return new BipexSubject[] {_sBR };
			//				else
			//					return new BipexSubject[0];
			//			}

			if (this._Visible)
				return new BipexSubject[] {_sBR };
			else
				return new BipexSubject[0];
		}

		private delegate void OnBipexResponseDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponseDelegate d = new OnBipexResponseDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_sBR.SubjectType == req[0].SubjectType &&
					_sBR.SubjectSubType == req[0].SubjectSubType)
				{
					_drlBR.Merge(resp[0]);
					_sBR.Version = _drlBR.Version;
					DataSetMerger.Merge(dsMainDG.Tables[0], _drlBR, typeof(BookRiassuntivoDR));
				}
			}
		}

		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

		private void frmBook_VisibleChanged(object sender, System.EventArgs e)
		{
			_Visible = this.Visible;		
		}

	}
}