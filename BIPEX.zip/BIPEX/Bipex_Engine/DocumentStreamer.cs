using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using Delta;
using GME.Remoting;

namespace Bipex_Engine
{
	public interface IDocumentStreamerViewer
	{
		BipexSubject [] GetBipexSubject();
		void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp);
		void OnError(string errorMessage);
	}

	public class DocumentStreamer
	{
		ArrayList _DocumentViewerList = new ArrayList();
		Thread _th;
		volatile bool _RefreshOn = true;

		public delegate void ErrorDelegate(string msg);
		public event ErrorDelegate Error;

		public delegate void RequestDelegate();
		public event RequestDelegate Request;

		public delegate void ResponseDelegate();
		public event ResponseDelegate Response;

		public bool Refresh
		{
			get { return _RefreshOn; }
			set { _RefreshOn = value; }
		}


		public void AddView(IDocumentStreamerViewer streamerViewer)
		{
			lock (this)
			{
				_DocumentViewerList.Add(streamerViewer);

				Form f = streamerViewer as Form;
				if (f != null)
					f.Closing += new CancelEventHandler(OnFormClosing);
			}
		}

		public void RemoveView(IDocumentStreamerViewer streamerViewer)
		{
			lock (this)
			{
				for (int i = 0; i < _DocumentViewerList.Count; ++i)
				{
					if (_DocumentViewerList[i] == streamerViewer)
					{
						_DocumentViewerList.RemoveAt(i);

						Form f = streamerViewer as Form;
						if (f != null)
							f.Closing -= new CancelEventHandler(OnFormClosing);
						break;
					}
				}
			}
		}

		private void OnFormClosing(object o, CancelEventArgs e)
		{
			lock (this)
			{
				IDocumentStreamerViewer streamerViewer = o as IDocumentStreamerViewer;
				RemoveView(streamerViewer);
			}
		}

		private bool Exists(IDocumentStreamerViewer streamerViewer)
		{
			lock (this)
			{
				for (int i = 0; i < _DocumentViewerList.Count; ++i)
				{
					if (_DocumentViewerList[i] == streamerViewer)
						return true;
				}
				return false;
			}
		}

		public void StartUpdate()
		{
			_th = new Thread(new ThreadStart(UpdateLoop));
			_th.IsBackground = true;
			_th.Start();
		}

		private void UpdateLoop()
		{
			Thread.Sleep(1000);
			for (;;)
			{
				try
				{
					lock(this)
					{
						if (this.Request != null)  this.Request();
					}
					
					if (_RefreshOn)
						Update();

					lock (this)
					{
						if (this.Response != null)  this.Response();
					}
				}
				catch (Exception e)
				{
					Debug.WriteLine(e.Message);
					Debug.WriteLine(e.StackTrace);

					if (Error != null)
						Error(e.Message);
				}
				Thread.Sleep(1000);
			}
		}


		private void Update()
		{
			RequestOfBipexSubjects req = new RequestOfBipexSubjects();


			IDocumentStreamerViewer [] requestingViewer;
			lock (this)
			{
				ArrayList ar = new ArrayList();
				foreach (IDocumentStreamerViewer v in _DocumentViewerList)
				{
					BipexSubject [] s = v.GetBipexSubject();
					foreach (BipexSubject bs in s)
					{
						req.Add(bs);
						ar.Add(v);
					}
				}
				requestingViewer = (IDocumentStreamerViewer[]) ar.ToArray(typeof(IDocumentStreamerViewer));
			}

			ResponseOfBipexSubjects resp;
			if (true)
			{
				byte [] bReq = CompactFormatter.WriteObject(req, CompressionType.None);
				IMarketDataProvider mp = (IMarketDataProvider) RemotingHelper.GetObject(typeof (IMarketDataProvider));
				byte [] bRsp = mp.GetLastMarketDataVersion(bReq);
				resp = (ResponseOfBipexSubjects) CompactFormatter.ReadObject(bRsp);
				Debug.WriteLine(string.Format("Scarico {0} bytes", bRsp.Length));
			}


			lock (this)
			{
				ArrayList respCurrentViewer = new ArrayList();
				ArrayList reqCurrentViewer = new ArrayList();

				for (int i = 0; i < resp.Count; ++i)
				{
					IDocumentStreamerViewer vCurrent = requestingViewer[i];
					if (!this.Exists(vCurrent))
						continue;  // potrebbe non esistere piu` se la form e` stata chiusa

					reqCurrentViewer.Add(req[i]);
					respCurrentViewer.Add(resp[i]);

					// lettura anticipata
					IDocumentStreamerViewer vNext = null;
					if (i + 1 < resp.Count)
						vNext = requestingViewer[i + 1];

					if (vNext == null || vNext != vCurrent)
					{
						// rottura
						DataRecordList [] viewResponce = (DataRecordList[]) respCurrentViewer.ToArray(typeof(DataRecordList));
						BipexSubject [] viewRequest = (BipexSubject[]) reqCurrentViewer.ToArray(typeof(BipexSubject));
						vCurrent.OnBipexResponse(viewRequest, viewResponce);
						respCurrentViewer.Clear();
						reqCurrentViewer.Clear();
					}
				}
			}
		}
	}
}