using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using Delta;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmFasiNegoziazione.
	/// </summary>
	public class frmFasiNegoziazione : System.Windows.Forms.Form, IDocumentStreamerViewer
	{
		private System.Windows.Forms.Label lbMarketOpen;
		private System.Windows.Forms.Label lbMarketClose;
		private System.Windows.Forms.Label lbSFData;
		private System.Windows.Forms.Label lbSFDataSTATUS;
		private System.Windows.Forms.Label lbToday;
		private System.Windows.Forms.TextBox tbToday;
		private System.Windows.Forms.TextBox tbMarketOpenTime;
		private System.Windows.Forms.TextBox tbMarketCloseTime;
		private System.Windows.Forms.Label lbMarketDate;
		private System.Windows.Forms.TextBox tbMarketDate;
		private System.Windows.Forms.Label lbDPData;
		private System.Windows.Forms.Label lbDPDataSTATUS;
		private System.Windows.Forms.Label lbMSData;
		private System.Windows.Forms.Label lbDPDTA;
		private System.Windows.Forms.Label lbBDPC;
		private System.Windows.Forms.Label lbIDPC;
		private System.Windows.Forms.Label lbMSDataSTATUS;
		private System.Windows.Forms.Label lbBDPCSTATUS;
		private System.Windows.Forms.Label lbIDPCSTATUS;
		private System.Windows.Forms.TextBox tbDPDT;
		private System.Windows.Forms.Label lbBDPCDTA;
		private System.Windows.Forms.Label lbSFDTA;
		private System.Windows.Forms.Label lbIDPCDTA;
		private System.Windows.Forms.Label lbDBDTA;
		private System.Windows.Forms.TextBox tbBDPCDT;
		private System.Windows.Forms.TextBox tbIDPCDT;
		private System.Windows.Forms.TextBox tbDBDT;
		private System.Windows.Forms.TextBox tbSFDT;
		private System.Windows.Forms.Label lbMSDTA;
		private System.Windows.Forms.TextBox tbMSDT;
		private System.Windows.Forms.Label lbDB;
		private System.Windows.Forms.Label lbDBSTATUS;
		private System.Windows.Forms.Label lbMarketStatus;
		private System.Windows.Forms.TextBox tbMarketStatus;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmFasiNegoziazione()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.lbMarketOpen = new System.Windows.Forms.Label();
			this.lbMarketClose = new System.Windows.Forms.Label();
			this.lbMSData = new System.Windows.Forms.Label();
			this.lbSFData = new System.Windows.Forms.Label();
			this.lbDPDTA = new System.Windows.Forms.Label();
			this.lbBDPC = new System.Windows.Forms.Label();
			this.lbIDPC = new System.Windows.Forms.Label();
			this.lbDB = new System.Windows.Forms.Label();
			this.lbMSDataSTATUS = new System.Windows.Forms.Label();
			this.lbSFDataSTATUS = new System.Windows.Forms.Label();
			this.lbBDPCSTATUS = new System.Windows.Forms.Label();
			this.lbIDPCSTATUS = new System.Windows.Forms.Label();
			this.lbDBSTATUS = new System.Windows.Forms.Label();
			this.lbToday = new System.Windows.Forms.Label();
			this.tbToday = new System.Windows.Forms.TextBox();
			this.tbDPDT = new System.Windows.Forms.TextBox();
			this.tbMarketOpenTime = new System.Windows.Forms.TextBox();
			this.tbMarketCloseTime = new System.Windows.Forms.TextBox();
			this.lbMarketDate = new System.Windows.Forms.Label();
			this.tbMarketDate = new System.Windows.Forms.TextBox();
			this.lbDPData = new System.Windows.Forms.Label();
			this.lbDPDataSTATUS = new System.Windows.Forms.Label();
			this.lbBDPCDTA = new System.Windows.Forms.Label();
			this.lbSFDTA = new System.Windows.Forms.Label();
			this.lbIDPCDTA = new System.Windows.Forms.Label();
			this.lbDBDTA = new System.Windows.Forms.Label();
			this.tbBDPCDT = new System.Windows.Forms.TextBox();
			this.tbIDPCDT = new System.Windows.Forms.TextBox();
			this.tbDBDT = new System.Windows.Forms.TextBox();
			this.tbSFDT = new System.Windows.Forms.TextBox();
			this.lbMSDTA = new System.Windows.Forms.Label();
			this.tbMSDT = new System.Windows.Forms.TextBox();
			this.lbMarketStatus = new System.Windows.Forms.Label();
			this.tbMarketStatus = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// lbMarketOpen
			// 
			this.lbMarketOpen.Location = new System.Drawing.Point(16, 88);
			this.lbMarketOpen.Name = "lbMarketOpen";
			this.lbMarketOpen.Size = new System.Drawing.Size(296, 23);
			this.lbMarketOpen.TabIndex = 4;
			this.lbMarketOpen.Text = "BIPEX Market is Open from:";
			this.lbMarketOpen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbMarketOpen.Click += new System.EventHandler(this.lbMarketOpen_Click);
			// 
			// lbMarketClose
			// 
			this.lbMarketClose.Location = new System.Drawing.Point(431, 88);
			this.lbMarketClose.Name = "lbMarketClose";
			this.lbMarketClose.Size = new System.Drawing.Size(24, 23);
			this.lbMarketClose.TabIndex = 6;
			this.lbMarketClose.Text = "to:";
			this.lbMarketClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbMSData
			// 
			this.lbMSData.Location = new System.Drawing.Point(16, 208);
			this.lbMSData.Name = "lbMSData";
			this.lbMSData.Size = new System.Drawing.Size(296, 23);
			this.lbMSData.TabIndex = 10;
			this.lbMSData.Text = "Market Session Data is:";
			this.lbMSData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbMSData.Click += new System.EventHandler(this.lbMarketSessionData_Click);
			// 
			// lbSFData
			// 
			this.lbSFData.Location = new System.Drawing.Point(16, 240);
			this.lbSFData.Name = "lbSFData";
			this.lbSFData.Size = new System.Drawing.Size(296, 23);
			this.lbSFData.TabIndex = 14;
			this.lbSFData.Text = "Physical Balance Data is:";
			this.lbSFData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbSFData.Click += new System.EventHandler(this.lbSFData_Click);
			// 
			// lbDPDTA
			// 
			this.lbDPDTA.Location = new System.Drawing.Point(472, 272);
			this.lbDPDTA.Name = "lbDPDTA";
			this.lbDPDTA.Size = new System.Drawing.Size(152, 23);
			this.lbDPDTA.TabIndex = 20;
			this.lbDPDTA.Text = "(Data will be available from:)";
			this.lbDPDTA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbDPDTA.Click += new System.EventHandler(this.lbDeliveryProgram_Click);
			// 
			// lbBDPC
			// 
			this.lbBDPC.Location = new System.Drawing.Point(16, 304);
			this.lbBDPC.Name = "lbBDPC";
			this.lbBDPC.Size = new System.Drawing.Size(296, 23);
			this.lbBDPC.TabIndex = 22;
			this.lbBDPC.Text = "BIPEX Delivery Program Confirmation is:";
			this.lbBDPC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbIDPC
			// 
			this.lbIDPC.Location = new System.Drawing.Point(16, 336);
			this.lbIDPC.Name = "lbIDPC";
			this.lbIDPC.Size = new System.Drawing.Size(296, 23);
			this.lbIDPC.TabIndex = 26;
			this.lbIDPC.Text = "IPEX Delivery Program Confirmation is:";
			this.lbIDPC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbIDPC.Click += new System.EventHandler(this.lbIPEXProgramConfirm_Click);
			// 
			// lbDB
			// 
			this.lbDB.Location = new System.Drawing.Point(16, 368);
			this.lbDB.Name = "lbDB";
			this.lbDB.Size = new System.Drawing.Size(296, 23);
			this.lbDB.TabIndex = 30;
			this.lbDB.Text = "Daily Settlement Data is:";
			this.lbDB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbDB.Click += new System.EventHandler(this.lbDailyBalance_Click);
			// 
			// lbMSDataSTATUS
			// 
			this.lbMSDataSTATUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbMSDataSTATUS.ForeColor = System.Drawing.Color.Red;
			this.lbMSDataSTATUS.Location = new System.Drawing.Point(312, 208);
			this.lbMSDataSTATUS.Name = "lbMSDataSTATUS";
			this.lbMSDataSTATUS.Size = new System.Drawing.Size(160, 23);
			this.lbMSDataSTATUS.TabIndex = 11;
			this.lbMSDataSTATUS.Text = "NOT AVAILABLE";
			this.lbMSDataSTATUS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbSFDataSTATUS
			// 
			this.lbSFDataSTATUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbSFDataSTATUS.ForeColor = System.Drawing.Color.Red;
			this.lbSFDataSTATUS.Location = new System.Drawing.Point(312, 240);
			this.lbSFDataSTATUS.Name = "lbSFDataSTATUS";
			this.lbSFDataSTATUS.Size = new System.Drawing.Size(160, 23);
			this.lbSFDataSTATUS.TabIndex = 15;
			this.lbSFDataSTATUS.Text = "NOT AVAILABLE";
			this.lbSFDataSTATUS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbBDPCSTATUS
			// 
			this.lbBDPCSTATUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbBDPCSTATUS.ForeColor = System.Drawing.Color.Red;
			this.lbBDPCSTATUS.Location = new System.Drawing.Point(312, 304);
			this.lbBDPCSTATUS.Name = "lbBDPCSTATUS";
			this.lbBDPCSTATUS.Size = new System.Drawing.Size(160, 23);
			this.lbBDPCSTATUS.TabIndex = 23;
			this.lbBDPCSTATUS.Text = "NOT AVAILABLE";
			this.lbBDPCSTATUS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbIDPCSTATUS
			// 
			this.lbIDPCSTATUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbIDPCSTATUS.ForeColor = System.Drawing.Color.Red;
			this.lbIDPCSTATUS.Location = new System.Drawing.Point(312, 336);
			this.lbIDPCSTATUS.Name = "lbIDPCSTATUS";
			this.lbIDPCSTATUS.Size = new System.Drawing.Size(160, 23);
			this.lbIDPCSTATUS.TabIndex = 27;
			this.lbIDPCSTATUS.Text = "NOT AVAILABLE";
			this.lbIDPCSTATUS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbDBSTATUS
			// 
			this.lbDBSTATUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbDBSTATUS.ForeColor = System.Drawing.Color.Red;
			this.lbDBSTATUS.Location = new System.Drawing.Point(312, 368);
			this.lbDBSTATUS.Name = "lbDBSTATUS";
			this.lbDBSTATUS.Size = new System.Drawing.Size(160, 23);
			this.lbDBSTATUS.TabIndex = 31;
			this.lbDBSTATUS.Text = "NOT AVAILABLE";
			this.lbDBSTATUS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbToday
			// 
			this.lbToday.Location = new System.Drawing.Point(16, 24);
			this.lbToday.Name = "lbToday";
			this.lbToday.Size = new System.Drawing.Size(296, 23);
			this.lbToday.TabIndex = 0;
			this.lbToday.Text = "Today is:";
			this.lbToday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// tbToday
			// 
			this.tbToday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbToday.Location = new System.Drawing.Point(312, 22);
			this.tbToday.Name = "tbToday";
			this.tbToday.ReadOnly = true;
			this.tbToday.Size = new System.Drawing.Size(176, 26);
			this.tbToday.TabIndex = 1;
			this.tbToday.Text = "";
			// 
			// tbDPDT
			// 
			this.tbDPDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbDPDT.Location = new System.Drawing.Point(616, 272);
			this.tbDPDT.Name = "tbDPDT";
			this.tbDPDT.ReadOnly = true;
			this.tbDPDT.Size = new System.Drawing.Size(176, 26);
			this.tbDPDT.TabIndex = 21;
			this.tbDPDT.Text = "";
			// 
			// tbMarketOpenTime
			// 
			this.tbMarketOpenTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbMarketOpenTime.Location = new System.Drawing.Point(312, 88);
			this.tbMarketOpenTime.Name = "tbMarketOpenTime";
			this.tbMarketOpenTime.ReadOnly = true;
			this.tbMarketOpenTime.Size = new System.Drawing.Size(119, 26);
			this.tbMarketOpenTime.TabIndex = 5;
			this.tbMarketOpenTime.Text = "";
			// 
			// tbMarketCloseTime
			// 
			this.tbMarketCloseTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbMarketCloseTime.Location = new System.Drawing.Point(455, 88);
			this.tbMarketCloseTime.Name = "tbMarketCloseTime";
			this.tbMarketCloseTime.ReadOnly = true;
			this.tbMarketCloseTime.Size = new System.Drawing.Size(120, 26);
			this.tbMarketCloseTime.TabIndex = 7;
			this.tbMarketCloseTime.Text = "";
			// 
			// lbMarketDate
			// 
			this.lbMarketDate.Location = new System.Drawing.Point(16, 56);
			this.lbMarketDate.Name = "lbMarketDate";
			this.lbMarketDate.Size = new System.Drawing.Size(296, 23);
			this.lbMarketDate.TabIndex = 2;
			this.lbMarketDate.Text = "BIPEX Market REFERENCE DATE is (HIDDEN):";
			this.lbMarketDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbMarketDate.Visible = false;
			// 
			// tbMarketDate
			// 
			this.tbMarketDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbMarketDate.Location = new System.Drawing.Point(312, 56);
			this.tbMarketDate.Name = "tbMarketDate";
			this.tbMarketDate.ReadOnly = true;
			this.tbMarketDate.Size = new System.Drawing.Size(176, 26);
			this.tbMarketDate.TabIndex = 3;
			this.tbMarketDate.Text = "";
			this.tbMarketDate.Visible = false;
			// 
			// lbDPData
			// 
			this.lbDPData.Location = new System.Drawing.Point(16, 272);
			this.lbDPData.Name = "lbDPData";
			this.lbDPData.Size = new System.Drawing.Size(296, 23);
			this.lbDPData.TabIndex = 18;
			this.lbDPData.Text = "Delivery Program Data is:";
			this.lbDPData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbDPDataSTATUS
			// 
			this.lbDPDataSTATUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbDPDataSTATUS.ForeColor = System.Drawing.Color.Red;
			this.lbDPDataSTATUS.Location = new System.Drawing.Point(312, 272);
			this.lbDPDataSTATUS.Name = "lbDPDataSTATUS";
			this.lbDPDataSTATUS.Size = new System.Drawing.Size(160, 23);
			this.lbDPDataSTATUS.TabIndex = 19;
			this.lbDPDataSTATUS.Text = "NOT AVAILABLE";
			this.lbDPDataSTATUS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbBDPCDTA
			// 
			this.lbBDPCDTA.Location = new System.Drawing.Point(472, 304);
			this.lbBDPCDTA.Name = "lbBDPCDTA";
			this.lbBDPCDTA.Size = new System.Drawing.Size(152, 23);
			this.lbBDPCDTA.TabIndex = 24;
			this.lbBDPCDTA.Text = "(Data will be available from:)";
			this.lbBDPCDTA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbSFDTA
			// 
			this.lbSFDTA.Location = new System.Drawing.Point(472, 240);
			this.lbSFDTA.Name = "lbSFDTA";
			this.lbSFDTA.Size = new System.Drawing.Size(152, 23);
			this.lbSFDTA.TabIndex = 16;
			this.lbSFDTA.Text = "(Data will be available from:)";
			this.lbSFDTA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbIDPCDTA
			// 
			this.lbIDPCDTA.Location = new System.Drawing.Point(472, 336);
			this.lbIDPCDTA.Name = "lbIDPCDTA";
			this.lbIDPCDTA.Size = new System.Drawing.Size(152, 23);
			this.lbIDPCDTA.TabIndex = 28;
			this.lbIDPCDTA.Text = "(Data will be available from:)";
			this.lbIDPCDTA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lbDBDTA
			// 
			this.lbDBDTA.Location = new System.Drawing.Point(472, 368);
			this.lbDBDTA.Name = "lbDBDTA";
			this.lbDBDTA.Size = new System.Drawing.Size(152, 23);
			this.lbDBDTA.TabIndex = 32;
			this.lbDBDTA.Text = "(Data will be available from:)";
			this.lbDBDTA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// tbBDPCDT
			// 
			this.tbBDPCDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbBDPCDT.Location = new System.Drawing.Point(616, 304);
			this.tbBDPCDT.Name = "tbBDPCDT";
			this.tbBDPCDT.ReadOnly = true;
			this.tbBDPCDT.Size = new System.Drawing.Size(176, 26);
			this.tbBDPCDT.TabIndex = 25;
			this.tbBDPCDT.Text = "";
			// 
			// tbIDPCDT
			// 
			this.tbIDPCDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbIDPCDT.Location = new System.Drawing.Point(616, 336);
			this.tbIDPCDT.Name = "tbIDPCDT";
			this.tbIDPCDT.ReadOnly = true;
			this.tbIDPCDT.Size = new System.Drawing.Size(176, 26);
			this.tbIDPCDT.TabIndex = 29;
			this.tbIDPCDT.Text = "";
			// 
			// tbDBDT
			// 
			this.tbDBDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbDBDT.Location = new System.Drawing.Point(616, 368);
			this.tbDBDT.Name = "tbDBDT";
			this.tbDBDT.ReadOnly = true;
			this.tbDBDT.Size = new System.Drawing.Size(176, 26);
			this.tbDBDT.TabIndex = 33;
			this.tbDBDT.Text = "";
			// 
			// tbSFDT
			// 
			this.tbSFDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbSFDT.Location = new System.Drawing.Point(616, 240);
			this.tbSFDT.Name = "tbSFDT";
			this.tbSFDT.ReadOnly = true;
			this.tbSFDT.Size = new System.Drawing.Size(176, 26);
			this.tbSFDT.TabIndex = 17;
			this.tbSFDT.Text = "";
			// 
			// lbMSDTA
			// 
			this.lbMSDTA.Location = new System.Drawing.Point(472, 208);
			this.lbMSDTA.Name = "lbMSDTA";
			this.lbMSDTA.Size = new System.Drawing.Size(152, 23);
			this.lbMSDTA.TabIndex = 12;
			this.lbMSDTA.Text = "(Data will be available from:)";
			this.lbMSDTA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// tbMSDT
			// 
			this.tbMSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbMSDT.Location = new System.Drawing.Point(616, 208);
			this.tbMSDT.Name = "tbMSDT";
			this.tbMSDT.ReadOnly = true;
			this.tbMSDT.Size = new System.Drawing.Size(176, 26);
			this.tbMSDT.TabIndex = 13;
			this.tbMSDT.Text = "";
			// 
			// lbMarketStatus
			// 
			this.lbMarketStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbMarketStatus.Location = new System.Drawing.Point(16, 144);
			this.lbMarketStatus.Name = "lbMarketStatus";
			this.lbMarketStatus.Size = new System.Drawing.Size(296, 23);
			this.lbMarketStatus.TabIndex = 8;
			this.lbMarketStatus.Text = "BIPEX Market - Current Session is:";
			this.lbMarketStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// tbMarketStatus
			// 
			this.tbMarketStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbMarketStatus.Location = new System.Drawing.Point(312, 144);
			this.tbMarketStatus.Name = "tbMarketStatus";
			this.tbMarketStatus.ReadOnly = true;
			this.tbMarketStatus.Size = new System.Drawing.Size(176, 26);
			this.tbMarketStatus.TabIndex = 9;
			this.tbMarketStatus.Text = "";
			// 
			// frmFasiNegoziazione
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(962, 638);
			this.Controls.Add(this.tbMarketStatus);
			this.Controls.Add(this.tbMSDT);
			this.Controls.Add(this.tbSFDT);
			this.Controls.Add(this.tbDBDT);
			this.Controls.Add(this.tbIDPCDT);
			this.Controls.Add(this.tbBDPCDT);
			this.Controls.Add(this.tbMarketDate);
			this.Controls.Add(this.tbMarketCloseTime);
			this.Controls.Add(this.tbMarketOpenTime);
			this.Controls.Add(this.tbDPDT);
			this.Controls.Add(this.tbToday);
			this.Controls.Add(this.lbMarketStatus);
			this.Controls.Add(this.lbMSDTA);
			this.Controls.Add(this.lbDBDTA);
			this.Controls.Add(this.lbIDPCDTA);
			this.Controls.Add(this.lbSFDTA);
			this.Controls.Add(this.lbBDPCDTA);
			this.Controls.Add(this.lbDPDataSTATUS);
			this.Controls.Add(this.lbDPData);
			this.Controls.Add(this.lbMarketDate);
			this.Controls.Add(this.lbToday);
			this.Controls.Add(this.lbDBSTATUS);
			this.Controls.Add(this.lbIDPCSTATUS);
			this.Controls.Add(this.lbBDPCSTATUS);
			this.Controls.Add(this.lbSFDataSTATUS);
			this.Controls.Add(this.lbMSDataSTATUS);
			this.Controls.Add(this.lbDB);
			this.Controls.Add(this.lbIDPC);
			this.Controls.Add(this.lbBDPC);
			this.Controls.Add(this.lbDPDTA);
			this.Controls.Add(this.lbSFData);
			this.Controls.Add(this.lbMSData);
			this.Controls.Add(this.lbMarketClose);
			this.Controls.Add(this.lbMarketOpen);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Name = "frmFasiNegoziazione";
			this.Text = "Market Sessions";
			this.Load += new System.EventHandler(this.frmFasiNegoziazione_Load);
			this.VisibleChanged += new System.EventHandler(this.frmFasiNegoziazione_VisibleChanged);
			this.ResumeLayout(false);

		}
		#endregion

		DataRecordList _drlMS;
		volatile BipexSubject _sMS;
		volatile bool _Visible = false;

		private void frmFasiNegoziazione_Load(object sender, System.EventArgs e)
		{
			_drlMS = new DataRecordList();
			_drlMS.Version = 0;

			_sMS = new BipexSubject();
			_sMS.DataDiMercato = DateTime.Now.Date;
			_sMS.SubjectType = "MS";
			_sMS.SubjectSubType = string.Empty;
			_sMS.Version = _drlMS.Version;

			tbToday.Text = DateTime.Today.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture);

			_Visible = this.Visible;		
		}

		private void lbIPEXProgramConfirm_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lbSFData_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lbDailyBalance_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lbMarketOpen_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lbDeliveryProgram_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lbMarketSessionData_Click(object sender, System.EventArgs e)
		{
		
		}

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			//			if (this.InvokeRequired)
			//			{
			//				GetBipexSubjectDelegate d = new GetBipexSubjectDelegate(GetBipexSubject);
			//				return (BipexSubject[]) this.Invoke(d);
			//			}
			//			else
			//			{
			//				if (this.Visible)
			//					return new BipexSubject[] {_sMS };
			//				else
			//					return new BipexSubject[0];
			//			}

			if (this._Visible)
				return new BipexSubject[] {_sMS };
			else
				return new BipexSubject[0];
		}

		private delegate void OnBipexResponseDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponseDelegate d = new OnBipexResponseDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_sMS.SubjectType == req[0].SubjectType &&
					_sMS.SubjectSubType == req[0].SubjectSubType)
				{
					_drlMS.Merge(resp[0]);
					_sMS.Version = _drlMS.Version;

					if (_drlMS.Count > 0)
					{
						MarketSessionDR dr = (MarketSessionDR) _drlMS[0];

						// Se sono qui mi � arrivato un DataRecordList NUOVO, devo aggiornare i
						// campi a video (move dalla struttura MarketSessionDR >> ai campi a video)

						tbMarketDate.Text = dr.DataMercato.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture);
						tbMarketOpenTime.Text = dr.TSAperturaSessione.ToString(BipexFormSettings.FmtForTimeWithAMPM, Thread.CurrentThread.CurrentCulture);
						tbMarketCloseTime.Text = dr.TSChiusuraSessione.ToString(BipexFormSettings.FmtForTimeWithAMPM, Thread.CurrentThread.CurrentCulture);

						this.tbMarketStatus.Text = dr.StatoSessione.ToString();

						if ((dr.DatiDisponibili & MarketSessionDR.datiDisponilbili.DatiChiusura) > 0)
						{
							lbMSDataSTATUS.Text = "AVAILABLE";
							lbMSDataSTATUS.ForeColor = Color.Green;
						}
						else
						{
							lbMSDataSTATUS.Text = "NOT AVAILABLE";
							lbMSDataSTATUS.ForeColor = Color.Red;
						}
						this.tbMSDT.Text = dr.TSDatiChiusura.ToString(BipexFormSettings.FmtForTimeWithAMPM, Thread.CurrentThread.CurrentCulture);

						if ((dr.DatiDisponibili & MarketSessionDR.datiDisponilbili.SaldoFisico) > 0)
						{
							lbSFDataSTATUS.Text = "AVAILABLE";
							lbSFDataSTATUS.ForeColor = Color.Green;
						}
						else
						{
							lbSFDataSTATUS.Text = "NOT AVAILABLE";
							lbSFDataSTATUS.ForeColor = Color.Red;
						}
						this.tbSFDT.Text = dr.TSSaldoFisico.ToString(BipexFormSettings.FmtForTimeWithAMPM, Thread.CurrentThread.CurrentCulture);

						if ((dr.DatiDisponibili & MarketSessionDR.datiDisponilbili.PresentazioneProgrammi) > 0)
						{
							lbDPDataSTATUS.Text = "AVAILABLE";
							lbDPDataSTATUS.ForeColor = Color.Green;
						}
						else
						{
							lbDPDataSTATUS.Text = "NOT AVAILABLE";
							lbDPDataSTATUS.ForeColor = Color.Red;
						}
						this.tbDPDT.Text = dr.TSPresentazioneProgrammi.ToString(BipexFormSettings.FmtForTimeWithAMPM, Thread.CurrentThread.CurrentCulture);

						if ((dr.DatiDisponibili & MarketSessionDR.datiDisponilbili.ConfermaProgrammiDaBIPEX) > 0)
						{
							lbBDPCSTATUS.Text = "AVAILABLE";
							lbBDPCSTATUS.ForeColor = Color.Green;
						}
						else
						{
							lbBDPCSTATUS.Text = "NOT AVAILABLE";
							lbBDPCSTATUS.ForeColor = Color.Red;
						}
						this.tbBDPCDT.Text = dr.TSConfermaProgrammiDaBIPEX.ToString(BipexFormSettings.FmtForTimeWithAMPM, Thread.CurrentThread.CurrentCulture);

						if ((dr.DatiDisponibili & MarketSessionDR.datiDisponilbili.ConfermaProgrammiDaIPEX) > 0)
						{
							lbIDPCSTATUS.Text = "AVAILABLE";
							lbIDPCSTATUS.ForeColor = Color.Green;
						}
						else
						{
							lbIDPCSTATUS.Text = "NOT AVAILABLE";
							lbIDPCSTATUS.ForeColor = Color.Red;
						}
						this.tbIDPCDT.Text = dr.TSConfermaProgrammiDaIPEX.ToString(BipexFormSettings.FmtForTimeWithAMPM, Thread.CurrentThread.CurrentCulture);

						if ((dr.DatiDisponibili & MarketSessionDR.datiDisponilbili.DisponibilitaLiquidazioneGiornaliera) > 0)
						{
							lbDBSTATUS.Text = "AVAILABLE";
							lbDBSTATUS.ForeColor = Color.Green;
						}
						else
						{
							lbDBSTATUS.Text = "NOT AVAILABLE";
							lbDBSTATUS.ForeColor = Color.Red;
						}
						this.tbDBDT.Text = dr.TSDisponibilitaLiquidazioneGiornaliera.ToString(BipexFormSettings.FmtForTimeWithAMPM, Thread.CurrentThread.CurrentCulture);

					}
					
				}
			}
		}

		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

		private void frmFasiNegoziazione_VisibleChanged(object sender, System.EventArgs e)
		{
			_Visible = this.Visible;		
		}

	}
}
