using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using Delta;
using GME.Remoting;
using SPDriver;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmSaldoFisico.
	/// </summary>
	public class frmSaldoFisico : System.Windows.Forms.Form, IDocumentStreamerViewer
	{
		private int[] iDataGridPosition = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};

		private frmSaldoFisicoSetSFDate frmSFSFD;
		private DateTime _SFReferenceDate = DateTime.Today; 

		private System.Windows.Forms.DataGrid dgSaldoFisico;
		private DataSet dsSaldoFisico;

		private System.Windows.Forms.ContextMenu cmMainDG;
		private System.Windows.Forms.ContextMenu cmSFDateDG;

		// Il Currency Mgr serve a tenere memoria dello stato del datagrid
		// con riferimento alle righe visibili, ad esempio in base al filtro
		// attivo.
		// Per cui, tutte le volte che si altera la composizione del dataview
		// in termini di righe contenute, ad es. applicando un filtro, si deve
		// AGGIORNARE la proprieta' BindingContext del DataView...
		private CurrencyManager _cmMainDG;
		private DataRow _dr = null;
		private System.Windows.Forms.TextBox tbSFDate;
		private System.Windows.Forms.Label lbSFDate; 

		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSaldoFisico()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.dgSaldoFisico = new System.Windows.Forms.DataGrid();
			this.tbSFDate = new System.Windows.Forms.TextBox();
			this.lbSFDate = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dgSaldoFisico)).BeginInit();
			this.SuspendLayout();
			// 
			// dgSaldoFisico
			// 
			this.dgSaldoFisico.AlternatingBackColor = System.Drawing.SystemColors.ControlLight;
			this.dgSaldoFisico.CaptionVisible = false;
			this.dgSaldoFisico.DataMember = "";
			this.dgSaldoFisico.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgSaldoFisico.Location = new System.Drawing.Point(0, 32);
			this.dgSaldoFisico.Name = "dgSaldoFisico";
			this.dgSaldoFisico.ParentRowsVisible = false;
			this.dgSaldoFisico.ReadOnly = true;
			this.dgSaldoFisico.SelectionBackColor = System.Drawing.SystemColors.ControlDark;
			this.dgSaldoFisico.Size = new System.Drawing.Size(994, 192);
			this.dgSaldoFisico.TabIndex = 2;
			this.dgSaldoFisico.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgSaldoFisico_MouseDown);
			this.dgSaldoFisico.DoubleClick += new System.EventHandler(this.dgSaldoFisico_DoubleClick);
			// 
			// tbSFDate
			// 
			this.tbSFDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbSFDate.Location = new System.Drawing.Point(216, 2);
			this.tbSFDate.Name = "tbSFDate";
			this.tbSFDate.ReadOnly = true;
			this.tbSFDate.Size = new System.Drawing.Size(176, 26);
			this.tbSFDate.TabIndex = 1;
			this.tbSFDate.Text = "";
			this.tbSFDate.Visible = false;
			this.tbSFDate.DoubleClick += new System.EventHandler(this.tbSFDate_DoubleClick);
			// 
			// lbSFDate
			// 
			this.lbSFDate.Location = new System.Drawing.Point(0, 4);
			this.lbSFDate.Name = "lbSFDate";
			this.lbSFDate.Size = new System.Drawing.Size(212, 23);
			this.lbSFDate.TabIndex = 0;
			this.lbSFDate.Text = "Physical Balance REFERENCE DATE is:";
			this.lbSFDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// frmSaldoFisico
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(994, 226);
			this.Controls.Add(this.tbSFDate);
			this.Controls.Add(this.lbSFDate);
			this.Controls.Add(this.dgSaldoFisico);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmSaldoFisico";
			this.Text = "Physical Balance";
			this.Load += new System.EventHandler(this.frmSaldoFisico_Load);
			this.VisibleChanged += new System.EventHandler(this.frmSaldoFisico_VisibleChanged);
			((System.ComponentModel.ISupportInitialize)(this.dgSaldoFisico)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		DataRecordList _drlSF;
		volatile BipexSubject _sSF;
		volatile bool _Visible = false;

		private void frmSaldoFisico_Load(object sender, System.EventArgs e)
		{
			cmMainDG = new ContextMenu();
			cmMainDG.MenuItems.Add("Change Reference Date", new EventHandler(cmMainDG_ChangeReferenceDate_Clicked));
			cmMainDG.MenuItems.Add("Show Unit Detail", new EventHandler(cmMainDG_ShowUnitDetail_Clicked));
			cmMainDG.MenuItems.Add("Hide Unit Detail", new EventHandler(cmMainDG_HideUnitDetail_Clicked));
			dgSaldoFisico.ContextMenu = cmMainDG;
		
			cmSFDateDG = new ContextMenu();
			cmSFDateDG.MenuItems.Add("Change Reference Date", new EventHandler(cmMainDG_ChangeReferenceDate_Clicked));
			tbSFDate.ContextMenu = cmSFDateDG;

			dgSaldoFisico.ContextMenu = cmMainDG;

			// Pulisco il DataGrid e lo ricostruisco in base al contenuto del DataSet...
			dgSaldoFisico.DataSource = null;

			SaldoFisico_Load();

			if (dsSaldoFisico != null)
				BindDataGrid(dgSaldoFisico, dsSaldoFisico);
					
			_Visible = this.Visible;		
		}

		private void SaldoFisico_Load()
		{
			dsSaldoFisico = new DataSet();

			_drlSF = new DataRecordList();
			_drlSF.Version = 0;

			_sSF = new BipexSubject();
			_sSF.DataDiMercato = DateTime.Now.Date;
			_sSF.SubjectType = SaldoFisicoDR.SubjectType;
			_sSF.SubjectSubType = SaldoFisicoDR.SubjectSubType;
			_sSF.Version = _drlSF.Version;

			DataSetMerger.CreateTable(dsSaldoFisico, "SF", typeof(SaldoFisicoDR));

		}

		public void SetFilterOnCurrentOperator()
		{
			if (_sSF != null)
			{
				if (EngineMainForm._tspParams.LoginActive)
				{
					BipexFilter_SaldoFisico filter = new BipexFilter_SaldoFisico(
						EngineMainForm._tspParams.ActiveOperatorCode
						);
					_sSF.Filter = filter;
					_sSF.Version = 0;
					_drlSF.Version = 0;
				}
			}
		}

		public void ResetFilterOnCurrentOperator()
		{
			if (_sSF != null)
			{
				_sSF.Filter = null;
				_sSF.Version = 0;
				_drlSF.Version = 0;
			}
		}

		/// <summary>
		/// Imposta la data ricevuta come argomento come data di riferimento 
		/// per il form correnet (Saldo Fisico)
		/// </summary>
		/// <param name="aSFReferenceDate"></param>
		public void SetCurrentSFDate(DateTime aSFReferenceDate)
		{
		
			_SFReferenceDate = aSFReferenceDate;
			this.tbSFDate.Text = _SFReferenceDate.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture);

			this.lbSFDate.Visible = true;
			this.tbSFDate.Visible = true;

			_sSF.Subscribe = new BipexSubscribeList();
			BipexSubscribe_SaldoFisico subscribe = new BipexSubscribe_SaldoFisico();
			subscribe.CodiceOperatore = EngineMainForm._tspParams.ActiveOperatorCode;
			subscribe.DataDelivery = _SFReferenceDate;
			_sSF.Subscribe.Add(subscribe);
		
		}

		public void ResetCurrentSFDate()
		{
			this.lbSFDate.Visible = false;
			this.tbSFDate.Visible = false;

			// (Colloquio Telefonico con Leo 06.10.2005)
			// Dice Leo che la unsubscribe non � necessaria...
			// questo perch� il DR di risposta mi restituisce Tutte le Reference Date richieste
			// da tutti gli utenti dell'operatore... le devo filtrare io dal DR che mi arriva
			// in risposta...

		}

		private void BindDataGrid(DataGrid dg, DataSet ds)
		{
			if (ds != null)
				SetDataGridTableStyles(dg, "SF");

			FillDataGrid(dg, ds);
		
		}

		private void SetDataGridTableStyles(DataGrid dg, string sMappingName)
		{
			dg.TableStyles.Clear();

			DataGridTableStyle dgsBook = new DataGridTableStyle();

			// !!!ATTENZIONE!!!
			// WORKAROUND PER RISOLUZIONE PROBLEMA
			// SE SI RIDEFINISCE UN PROPRIO TABLESTYLE 
			// PER VISUALIZZARE UN DATATABLE,
			// OCCORRE RIASSEGNARE ESPLICITAMENTE I COLORI!!!,
			// altrimenti ad esempio impostazioni come l'alternate
			// color vanno perdute...
			dgsBook.AlternatingBackColor = BipexFormSettings.AlternatingBackColor;
			dgsBook.BackColor = BipexFormSettings.BackColor;
			dgsBook.ForeColor = BipexFormSettings.ForeColor;
			dgsBook.GridLineColor = BipexFormSettings.GridLineColor;
			dgsBook.HeaderBackColor = BipexFormSettings.HeaderBackColor;
			dgsBook.HeaderForeColor = BipexFormSettings.HeaderForeColor;
			dgsBook.LinkColor = BipexFormSettings.LinkColor;
			dgsBook.SelectionBackColor = BipexFormSettings.SelectionBackColor;
			dgsBook.SelectionForeColor = BipexFormSettings.SelectionForeColor;

			// Il DataGrid NON E' SORTABILE DALL'UTENTE...
			dgsBook.AllowSorting = false;
			dgsBook.RowHeadersVisible = false;

			dgsBook.MappingName = sMappingName;

			DataGridAlignedTextBoxColumn[] dgcBook = new DataGridAlignedTextBoxColumn[28];
			for (int i = 0; i < dgcBook.Length; ++i)
				dgcBook[i] = new DataGridAlignedTextBoxColumn();
			int index = 0;

			index = 0;
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = "Immissione";
			dgcBook[index].HeaderText = "Total Immission";
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].Width = 100;

			index = 1;
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = "Prelievo";
			dgcBook[index].HeaderText = "Total WithDraw";
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].Width = 100;

			for (int i = 1; i<=24; i++)
			{
				index = i+1;
				dgcBook[index] = new DataGridSFDayColumn(i);
				dgcBook[index].MappingName = "H"+i.ToString("00");
				dgcBook[index].HeaderText = i.ToString("00");
				dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
				dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
				dgcBook[index].Format = "G";
				dgcBook[index].Width = 25;
			}

			dgsBook.GridColumnStyles.AddRange(dgcBook);
			dg.TableStyles.Add(dgsBook);
		}

		public void FillDataGrid(DataGrid dg, DataSet ds)
		{
			DataView dv = new DataView(ds.Tables[0]);

			dv.AllowDelete = false;
			dv.AllowEdit = false;
			dv.AllowNew = false;

			//Imposto il colore delle righe pari a un colore leggermente
			//piu` scuro di quello utilizzato per le righe dispari.
			int piuScuro = 10;
			int R = dg.BackColor.R - piuScuro;
			int G = dg.BackColor.G - piuScuro;
			int B = dg.BackColor.B - piuScuro;
			if (R < 0) R = 10;
			if (G < 0) G = 10;
			if (B < 0) B = 10;
			Color colore = Color.FromArgb(R, G, B);
			dg.AlternatingBackColor = colore;

			//dg.TableStyles.Clear();
			//dg.TableStyles.IsReadOnly = true;
			//dg.TableStyles.Add(stile);
			dg.AllowNavigation = false;

			dg.DataSource = dv;

			_cmMainDG = (CurrencyManager)this.BindingContext[dv];
			_cmMainDG.CurrentChanged += new EventHandler(_cmMainDG_CurrentChanged);
			dv.ListChanged += new ListChangedEventHandler(_cmMainDG_ListChanged);

			return;
		}

		public void _cmMainDG_CurrentChanged(object sender, EventArgs e)
		{
			try
			{
				DataRow dr = GetSaldoFisicoRigaCorrente();
				if (_dr == null || _dr != dr)
				{
					_dr = dr;

					// DA FARE MB
					// DA FARE MB
					// DA FARE MB

					// Se c'� da consuntivare a qualche altro form il fatto che �
					// cambiata la selezione in questo form, qui � il
					// posto per farlo (copiare gestione dal Book Riassuntivo)
					// SendSaldoFisicoRowChanged(dr);
				}
			}
			catch
			{
			}
		}
		private void _cmMainDG_ListChanged(object sender, ListChangedEventArgs e)
		{
			if (_cmMainDG.Position == 0)
			{
				try
				{
					DataRow dr = GetSaldoFisicoRigaCorrente();
					// L'update in BackGround del DataSet associato al DataGrid
					// causa MOLTISSIMI eventi di tipo ListChanged, invio la
					// notifica del cambio di riga selezionata solo quando cio'
					// si verifica effettivamente...
					if (_dr == null || _dr != dr)
					{
						_dr = dr;

						// DA FARE MB
						// DA FARE MB
						// DA FARE MB

						// Se c'� da consuntivare a qualche altro form il fatto che �
						// cambiata la selezione in questo form, qui � il
						// posto per farlo (copiare gestione dal Book Riassuntivo)
						// SendSaldoFisicoRowChanged(dr);
					}
				}
				catch
				{
				}
			}
		}

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			if (this._Visible)
				return new BipexSubject[] {_sSF };
			else
				return new BipexSubject[0];
		}

		private delegate void OnBipexResponseDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponseDelegate d = new OnBipexResponseDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_sSF.SubjectType == req[0].SubjectType &&
					_sSF.SubjectSubType == req[0].SubjectSubType)
				{
					_drlSF.Merge(resp[0]);
					_sSF.Version = _drlSF.Version;

					// Il DRList di risposta mi restituisce TUTTE le Reference Date richieste
					// da tutti gli utenti dell'operatore in tutte le sessioni client attive... 
					// potenzialmente quindi in questo DR ci possono essere dati che non mi
					// interessano... devo filtrare e scartare i DR che si riferiscono a date
					// DIFFERENTI dalla mia Reference Date...

					DataRecordList tmpDRLofCurrReferenceDate = new DataRecordList();
					foreach (DataRecord tmpDR in _drlSF)
					{
						if (((SaldoFisicoDR)tmpDR).DataDelivery == this._SFReferenceDate)
							tmpDRLofCurrReferenceDate.Add(tmpDR);
					}

					DataSetMerger.Merge(this.dsSaldoFisico.Tables["SF"], tmpDRLofCurrReferenceDate, typeof(SaldoFisicoDR));
				}
			}
		}

		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

		private DataRow GetSaldoFisicoRigaCorrente()
		{
			if (_cmMainDG.Count == 0)
				return null;
			DataView dv = (DataView)_cmMainDG.List;
			if (dv.Count == 0)
				return null;
			DataRow dr = dv[_cmMainDG.Position].Row;
			return dr;
		}
		
		public void cmMainDG_ChangeReferenceDate_Clicked(object sender, EventArgs e)
		{
			if (frmSFSFD != null)
				frmSFSFD.Dispose();

			DateTime tmpSFDate = _SFReferenceDate;
			frmSFSFD = new frmSaldoFisicoSetSFDate(tmpSFDate);
			frmSFSFD.ShowDialog(this);
			if (frmSFSFD.bRC)
			{
				// E' stata impostata una nuova reference date...
				SetCurrentSFDate(frmSFSFD._SFReferenceDate);
			}
		}

		public void cmMainDG_ShowUnitDetail_Clicked(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		public void cmMainDG_HideUnitDetail_Clicked(object sender, EventArgs e)
		{
			MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_NOTIMPLEMENTED"));
		}

		private void dgSaldoFisico_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			DataGrid.HitTestInfo ht = dgSaldoFisico.HitTest(e.X, e.Y);

			// Deseleziono righe eventualmente selezionate in questo momento
			// (anche selezioni multiple) ed imposto come selezionata la riga corrente
			if (ht.Type == DataGrid.HitTestType.Cell || ht.Type == DataGrid.HitTestType.RowHeader)
			{
				if (_cmMainDG.Count == 0)
					return;
				DataView dv = (DataView)_cmMainDG.List;
				if (dv.Count == 0)
					return;

				for (int i = 0; i < dv.Count; ++i)
					if (dgSaldoFisico.IsSelected(i))
						dgSaldoFisico.UnSelect(i);

				// LACCHEZZO IGNOBILE
				// LACCHEZZO IGNOBILE
				// LACCHEZZO IGNOBILE
				// LA RIGA VIENE SELEZIONATA, A FRONTE DEL RIGHT CLICK, SE E SOLO SE 
				// IL RIGHT CLICK PROVOCA UN CELL CHANGED!!! MA SE IL LEFT CLICK 
				// PRECEDENTE SULLA RIGA, PER MOTIVI DI IMPLEMENTAZIONE DEL LEFT CLICK, 
				// NON SELEZIONA LA RIGA, ECCO CHE IL RIGHT CLICK SULLA STESSA CELLA 
				// NON GENERA L'EVENTO DI CELL CHANGED!!! NEL MODO QUI SOTTO INVECE 
				// IO GENERO SEMPRE E COMUNQUE UN CELL CHANGED...
				int ColumnAlternate = 0;
				if (ht.Column > 0)
					ColumnAlternate = ht.Column - 1;
				else
					ColumnAlternate = 1;

				dgSaldoFisico.CurrentCell = new DataGridCell(ht.Row, ColumnAlternate);
				dgSaldoFisico.CurrentCell = new DataGridCell(ht.Row, ht.Column);

				dgSaldoFisico.CurrentRowIndex = ht.Row;

			}

			// Menu` contestuale: qui lo si puo' abilitare o meno testando
			// le condizioni che ci interessano sulla riga selezionata oppure
			// comporlo in modo DINAMICO in funzione delle caratteristiche della
			// riga selezionata...
			bool b = true;
			if (b)
				dgSaldoFisico.ContextMenu = this.cmMainDG;
			else
				dgSaldoFisico.ContextMenu = null;

		}

		private void dgSaldoFisico_DoubleClick(object sender, System.EventArgs e)
		{
			// Doppio Click sul DataGrid: per ora anch'esso causa il data entry della reference date... 

			if (frmSFSFD != null)
				frmSFSFD.Dispose();

			DateTime tmpSFDate = _SFReferenceDate;
			frmSFSFD = new frmSaldoFisicoSetSFDate(tmpSFDate);
			frmSFSFD.ShowDialog(this);
			if (frmSFSFD.bRC)
			{
				// E' stata impostata una nuova reference date...
				SetCurrentSFDate(frmSFSFD._SFReferenceDate);
			}
		}

		private void frmSaldoFisico_VisibleChanged(object sender, System.EventArgs e)
		{
			_Visible = this.Visible;		
		}

		private void tbSFDate_DoubleClick(object sender, System.EventArgs e)
		{
			if (frmSFSFD != null)
				frmSFSFD.Dispose();

			DateTime tmpSFDate = _SFReferenceDate;
			frmSFSFD = new frmSaldoFisicoSetSFDate(tmpSFDate);
			frmSFSFD.ShowDialog(this);
			if (frmSFSFD.bRC)
			{
				// E' stata impostata una nuova reference date...
				SetCurrentSFDate(frmSFSFD._SFReferenceDate);
			}
		}

		/// <summary>
		/// La classe incapsula il comportamento grafico delle colonne del
		/// tipo "Saldo Fisico" (bg scuro se il giorno contiene una quantit�)
		/// </summary>
		private class DataGridSFDayColumn : DataGridAlignedTextBoxColumn
		{
			private static Brush _bgrigio = new SolidBrush(Color.Gray);
			private static Brush _bbianco = new SolidBrush(Color.White);

			// L'indice che rappresenta il giorno...
			private int iDay;

			public DataGridSFDayColumn(int i)
			{
				// La classe derivata si occupa della gestione dei colori di BG e FG
				// per cui cio' non deve essere fatto nella classe base...
				bColorSetInDerivedClass = true;

				iDay = i;
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
				int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				try
				{
					// Questa e' la riga corrente...
					DataRow dr = ((DataView) cm.List)[rowNum].Row;

					// ...e questi sono i valori delle celle della riga corrente...

					if (dr["H"+iDay.ToString("00")].ToString() != "0")
					{
						myBackBrush = _bgrigio;
					}

				}
				catch
				{
					Debug.Assert(false);
				}

				base.Paint(g, bounds, cm, rowNum, myBackBrush, myForeBrush, alignToRight);
			}

		}

		/// <summary>
		/// La classe consente di gestire l'allineamento separato tra l'header text
		/// di una colonna ed i dati contenuti nelle celle nella colonna stessa
		/// 
		/// Derivando da questa classe si ottiene che:
		/// 
		/// -	La proprieta' standard Alignment serve a gestire l'allineamento
		///		dell'header (ATTENZIONE: HorizontalAlignment.Right CAUSA UN CLIPPING
		///		DELL'HEADER TEXT e quindi e' meglio non usarlo!);
		///	-	La proprieta' custom DataAlignment serve a gestire l'allineamento
		///		del dato nella cella.
		/// </summary>
		private class DataGridAlignedTextBoxColumn : DataGridTextBoxColumn
		{
			protected bool bColorSetInDerivedClass = false;
			private HorizontalAlignment dataAlignment = HorizontalAlignment.Center;

			/// <summary>
			/// La proprieta' serve a gestire l'allineamento del dato nella cella.
			/// </summary>
			public HorizontalAlignment DataAlignment
			{
				get { return this.dataAlignment; }
				set { this.dataAlignment = value; }
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
				int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// !!!ATTENZIONE!!!
				// WORKAROUND PER RISOLUZIONE PROBLEMA
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// (per default, il click sulla barra a sz delle celle fa il paint mentre
				// il click sulle celle stesse non fa il paint!!!)

				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum & !bColorSetInDerivedClass)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				// Questa e' la riga corrente...
				DataRow dr = ((DataView) cm.List)[rowNum].Row;

				// ...e questi sono i valori delle celle della riga corrente...
				string strCellText = "";
				if (dr[this.MappingName] != System.Convert.DBNull)
				{
					// Converto il valore in stringa per poterlo riscrivere, devo
					// tenere conto dell'attributo di formattazione eventualmente
					// impostato dall'utente del datagrid...
					strCellText = FormatObjectAsString(dr[this.MappingName], this.Format);
				}
					
				// Determino l'allineamento in funzione della property impostata dall'utente della classe
				StringFormat stringFormat = new StringFormat();
				switch (DataAlignment)
				{
					case HorizontalAlignment.Center:
						stringFormat.Alignment = StringAlignment.Center;
						break;
					case HorizontalAlignment.Left:
						stringFormat.Alignment = StringAlignment.Near;
						break;
					case HorizontalAlignment.Right:
						stringFormat.Alignment = StringAlignment.Far;
						break;
				}

				// Disegno BackGround sul rect da refreshare...
				g.FillRectangle(myBackBrush, bounds);
				// Calcolo nuovo rect...
				RectangleF CellBounds = new RectangleF(bounds.Left, bounds.Top + 3, bounds.Width, bounds.Height);
				// Refresh del contenuto della cella...
				g.DrawString(strCellText, this.DataGridTableStyle.DataGrid.Font, myForeBrush, CellBounds, stringFormat);

			}

			private int SelectedRow = -1;

			protected override void Edit(CurrencyManager source, int rowNum, Rectangle bounds, bool readOnly, string instantText, bool cellIsVisible)
			{
				// Per evitare crash testare che ci sia una selezione valida
				// prima di fare la deselezione...
				if (SelectedRow > -1 && SelectedRow < source.List.Count + 1)
					this.DataGridTableStyle.DataGrid.UnSelect(SelectedRow);
			}

			protected string FormatObjectAsString(object o, string Format)
			{
				if (o.GetType() == typeof (DateTime))
				{
					DateTime tmp = Convert.ToDateTime(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (double))
				{
					double tmp = Convert.ToDouble(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (decimal))
				{
					decimal tmp = Convert.ToDecimal(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (short))
				{
					short tmp = Convert.ToInt16(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (int))
				{
					int tmp = Convert.ToInt32(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (long))
				{
					long tmp = Convert.ToInt64(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else
				{
					// Type non gestito con formattazione specifica, richiamo il metodo
					// standard di conversione in stringa...
					return o.ToString();
				}
			}
		}
	
	}
}
