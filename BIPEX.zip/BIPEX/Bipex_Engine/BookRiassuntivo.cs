using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Windows.Forms;
using Bipex_BLInterface;
using Delta;
using GME.Remoting;

namespace Bipex_Engine
{
	/// <summary>
	/// Summary description for BookRiassuntivo.
	/// </summary>
	public class BookRiassuntivo : Form, IDocumentStreamerViewer
	{
		private DataGrid dgBookRiassuntivo;
		private System.Windows.Forms.Timer timer1;
		private System.ComponentModel.IContainer components;

		public BookRiassuntivo()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.dgBookRiassuntivo = new System.Windows.Forms.DataGrid();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			((System.ComponentModel.ISupportInitialize)(this.dgBookRiassuntivo)).BeginInit();
			this.SuspendLayout();
			// 
			// dgBookRiassuntivo
			// 
			this.dgBookRiassuntivo.CaptionVisible = false;
			this.dgBookRiassuntivo.DataMember = "";
			this.dgBookRiassuntivo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgBookRiassuntivo.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgBookRiassuntivo.Location = new System.Drawing.Point(0, 0);
			this.dgBookRiassuntivo.Name = "dgBookRiassuntivo";
			this.dgBookRiassuntivo.Size = new System.Drawing.Size(672, 273);
			this.dgBookRiassuntivo.TabIndex = 0;
			// 
			// timer1
			// 
			this.timer1.Interval = 1000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// BookRiassuntivo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 273);
			this.Controls.Add(this.dgBookRiassuntivo);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Name = "BookRiassuntivo";
			this.Text = "BookRiassuntivo";
			this.Load += new System.EventHandler(this.BookRiassuntivo_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgBookRiassuntivo)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		DataRecordList _v1BR;
		DataSet _ds;


		BipexSubject _Subject;

		private void BookRiassuntivo_Load(object sender, EventArgs e)
		{
			_v1BR = new DataRecordList();
			_v1BR.Version = 0;

			_Subject = new BipexSubject();
			_Subject.DataDiMercato = DateTime.Now.Date;
			_Subject.SubjectType = "BR";
			_Subject.SubjectSubType = string.Empty;
			_Subject.Version = _v1BR.Version;

			_ds = new DataSet();
			DataSetMerger.CreateTable(_ds, "BR", typeof(BookRiassuntivoDR));

			dgBookRiassuntivo.ReadOnly = true;
			dgBookRiassuntivo.DataSource = _ds;
			dgBookRiassuntivo.DataMember = "BR";

			// timer1.Enabled = true;

		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
//			try
//			{
//				timer1.Enabled = false;
//
//				if (this.Visible)
//				{
//
//					RequestOfBipexSubjects req = new RequestOfBipexSubjects();
//					req.Add(_Subject);
//
//					byte [] bReq = CompactFormatter.WriteObject(req, CompressionType.None);
//
//					IMarketDataProvider mp = (IMarketDataProvider) RemotingHelper.GetObject(typeof (IMarketDataProvider));
//
//					byte [] bRsp = mp.GetLastMarketDataVersion(bReq);
//					Debug.WriteLine(string.Format("Scarico {0} bytes", bRsp.Length));
//
//
//					ResponseOfBipexSubjects resp = (ResponseOfBipexSubjects) CompactFormatter.ReadObject(bRsp);
//
//					DataRecordList delta = resp[0];
//
//					_v1BR.Merge(delta);
//					_Subject.Version = _v1BR.Version;
//					DataSetMerger.Merge(_ds.Tables[0], _v1BR, typeof(BookRiassuntivoDR));
//				}
//				timer1.Enabled = true;
//			}
//			catch (Exception ex)
//			{
//				MessageBox.Show(this.Owner, ex.Message);
//			}
		}

		#region IDocumentStreamerViewer Members

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			if (this.InvokeRequired)
			{
				GetBipexSubjectDelegate d = new GetBipexSubjectDelegate(GetBipexSubject);
				return (BipexSubject[]) this.Invoke(d);
			}
			else
			{
				if (this.Visible)
					return new BipexSubject[] {_Subject };
				else
					return new BipexSubject[0];
			}
		}

		private delegate void OnBipexResponseDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponseDelegate d = new OnBipexResponseDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_Subject.SubjectType == req[0].SubjectType &&
					_Subject.SubjectSubType == req[0].SubjectSubType)
				{
					_v1BR.Merge(resp[0]);
					_Subject.Version = _v1BR.Version;
					DataSetMerger.Merge(_ds.Tables[0], _v1BR, typeof(BookRiassuntivoDR));
				}
			}
		}

		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

		#endregion

	}
}