using System.Windows.Forms;
using Bipex_BLInterface;
using GME.Remoting;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmLogin.
	/// </summary>
	public class frmLogin : System.Windows.Forms.Form
	{
		/// <summary>
		/// Oggetti BL utilizzati dal form
		/// </summary>
		ILogin BLMainObj = (ILogin) RemotingHelper.GetObject(typeof(ILogin));

		public enum enDialogMode
		{
			LoginUserPasswordVisible = 0,
			LoginUserPasswordNotVisible
		};

		public class rcFrmLogin
		{
			public DatiUtente utente;
		};

		private enDialogMode enDM;
		private rcFrmLogin rcFrm;

		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Label lbUser;
		private System.Windows.Forms.Label lbPassword;
		private System.Windows.Forms.TextBox tbUser;
		private System.Windows.Forms.TextBox tbPassword;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Form di Login
		/// </summary>
		/// <param name="aenDM">enDialogMode</param>
		public frmLogin(enDialogMode aenDM, ref rcFrmLogin arcFrm)
		{
			enDM = aenDM;
			rcFrm = arcFrm;
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLogin));
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.lbUser = new System.Windows.Forms.Label();
			this.lbPassword = new System.Windows.Forms.Label();
			this.tbUser = new System.Windows.Forms.TextBox();
			this.tbPassword = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
			this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCancel.Location = new System.Drawing.Point(150, 104);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(80, 32);
			this.btnCancel.TabIndex = 7;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnOK
			// 
			this.btnOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnOK.Image = ((System.Drawing.Image)(resources.GetObject("btnOK.Image")));
			this.btnOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnOK.Location = new System.Drawing.Point(62, 104);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(80, 32);
			this.btnOK.TabIndex = 6;
			this.btnOK.Text = "&OK";
			this.btnOK.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// lbUser
			// 
			this.lbUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbUser.Location = new System.Drawing.Point(48, 8);
			this.lbUser.Name = "lbUser";
			this.lbUser.Size = new System.Drawing.Size(64, 20);
			this.lbUser.TabIndex = 0;
			this.lbUser.Text = "User:";
			this.lbUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lbPassword
			// 
			this.lbPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbPassword.Location = new System.Drawing.Point(48, 32);
			this.lbPassword.Name = "lbPassword";
			this.lbPassword.Size = new System.Drawing.Size(64, 20);
			this.lbPassword.TabIndex = 2;
			this.lbPassword.Text = "Password:";
			this.lbPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tbUser
			// 
			this.tbUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbUser.Location = new System.Drawing.Point(112, 8);
			this.tbUser.Name = "tbUser";
			this.tbUser.Size = new System.Drawing.Size(128, 20);
			this.tbUser.TabIndex = 1;
			this.tbUser.Text = "";
			this.tbUser.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUser_KeyPress);
			// 
			// tbPassword
			// 
			this.tbPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbPassword.Location = new System.Drawing.Point(112, 32);
			this.tbPassword.Name = "tbPassword";
			this.tbPassword.Size = new System.Drawing.Size(128, 20);
			this.tbPassword.TabIndex = 3;
			this.tbPassword.Text = "";
			this.tbPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPassword_KeyPress);
			// 
			// frmLogin
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(292, 142);
			this.Controls.Add(this.tbPassword);
			this.Controls.Add(this.tbUser);
			this.Controls.Add(this.lbPassword);
			this.Controls.Add(this.lbUser);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmLogin";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Login to BIPEX";
			this.Load += new System.EventHandler(this.frmLogin_Load);
			this.Activated += new System.EventHandler(this.frmLogin_Activated);
			this.ResumeLayout(false);

		}
		#endregion

		private bool bLoaded = false;
		private void frmLogin_Load(object sender, System.EventArgs e)
		{
			switch (enDM)
			{
				case enDialogMode.LoginUserPasswordVisible:
					// this.tbPassword.PasswordChar;
					break;
				case enDialogMode.LoginUserPasswordNotVisible:
					this.tbPassword.PasswordChar = '*';
					break;
			}
		}

		private void frmLogin_Activated(object sender, System.EventArgs e)
		{
			if (!bLoaded)
			{
				bLoaded = true;
				this.tbUser.Focus();
			}
		}

		private void btnOK_Click(object sender, System.EventArgs e)
		{
			if (this.tbUser.Text == string.Empty)
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_TYPEAVALIDUSER"), BipexResourceManager.GetResourceString("MSG_EMPTYFIELDNOTALLOWED"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.tbUser.Focus();
				return;
			}
			if (this.tbPassword.Text == string.Empty)
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_TYPEAVALIDPASSWORD"), BipexResourceManager.GetResourceString("MSG_EMPTYFIELDNOTALLOWED"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.tbPassword.Focus();
				return;
			}

			DatiUtente tmpBLObj = BLMainObj.CheckLogin(this.tbUser.Text, this.tbPassword.Text);
			if (tmpBLObj != null)
			{
				rcFrm.utente = tmpBLObj;

				this.DialogResult = DialogResult.OK;
				this.Close();
			}
			else
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_USERPASSWORDUNKNOWN"), BipexResourceManager.GetResourceString("MSG_LOGINNOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.tbUser.Focus();
				return;
			}
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void tbUser_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			// Si accettano tutti i caratteri...
			if (!(char.IsLetter(e.KeyChar) || char.IsDigit(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSeparator(e.KeyChar) || char.IsControl(e.KeyChar)))
				e.Handled = true;
		}

		private void tbPassword_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			// Si accettano tutti i caratteri...
			if (!(char.IsLetter(e.KeyChar) || char.IsDigit(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSeparator(e.KeyChar) || char.IsControl(e.KeyChar)))
				e.Handled = true;
		}

	}
}
