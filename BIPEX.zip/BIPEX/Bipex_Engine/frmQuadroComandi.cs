using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Bipex_BLInterface;
using Delta;
using GME.Remoting;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmQuadroComandi.
	/// </summary>
	public class frmQuadroComandi : System.Windows.Forms.Form, IDocumentStreamerViewer
	{
		/// <summary>
		/// Oggetti BL utilizzati dal form
		/// </summary>
		ISessioneMercato BLMainObj = (ISessioneMercato) RemotingHelper.GetObject(typeof(ISessioneMercato));

		private System.Windows.Forms.Button btnCurrSessOpen;
		private System.Windows.Forms.Button btnCurrSessSuspend;
		private System.Windows.Forms.Button btnCurrSessReactivate;
		private System.Windows.Forms.GroupBox groupBox1;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TextBox tbMarketStatus;
		private System.Windows.Forms.Label lbMarketStatus;
		private System.Windows.Forms.Button btnCurrSessTerminate;

		private MarketSessionDR.eStatoSessione enBipexMktCurrSessStatus;

		public frmQuadroComandi()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			enBipexMktCurrSessStatus = MarketSessionDR.eStatoSessione.NUOVA;
			SetDialogCtrlOnBipexMktCurrSessStatusChanged();

		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmQuadroComandi));
			this.btnCurrSessOpen = new System.Windows.Forms.Button();
			this.btnCurrSessTerminate = new System.Windows.Forms.Button();
			this.btnCurrSessSuspend = new System.Windows.Forms.Button();
			this.btnCurrSessReactivate = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tbMarketStatus = new System.Windows.Forms.TextBox();
			this.lbMarketStatus = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnCurrSessOpen
			// 
			this.btnCurrSessOpen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCurrSessOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnCurrSessOpen.Image = ((System.Drawing.Image)(resources.GetObject("btnCurrSessOpen.Image")));
			this.btnCurrSessOpen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCurrSessOpen.Location = new System.Drawing.Point(24, 120);
			this.btnCurrSessOpen.Name = "btnCurrSessOpen";
			this.btnCurrSessOpen.Size = new System.Drawing.Size(136, 56);
			this.btnCurrSessOpen.TabIndex = 2;
			this.btnCurrSessOpen.Text = "Open";
			this.btnCurrSessOpen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCurrSessOpen.Click += new System.EventHandler(this.btnCurrSessOpen_Click);
			// 
			// btnCurrSessTerminate
			// 
			this.btnCurrSessTerminate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCurrSessTerminate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnCurrSessTerminate.Image = ((System.Drawing.Image)(resources.GetObject("btnCurrSessTerminate.Image")));
			this.btnCurrSessTerminate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCurrSessTerminate.Location = new System.Drawing.Point(472, 120);
			this.btnCurrSessTerminate.Name = "btnCurrSessTerminate";
			this.btnCurrSessTerminate.Size = new System.Drawing.Size(136, 56);
			this.btnCurrSessTerminate.TabIndex = 5;
			this.btnCurrSessTerminate.Text = "Terminate";
			this.btnCurrSessTerminate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCurrSessTerminate.Click += new System.EventHandler(this.btnCurrSessTerminate_Click);
			// 
			// btnCurrSessSuspend
			// 
			this.btnCurrSessSuspend.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCurrSessSuspend.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnCurrSessSuspend.Image = ((System.Drawing.Image)(resources.GetObject("btnCurrSessSuspend.Image")));
			this.btnCurrSessSuspend.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCurrSessSuspend.Location = new System.Drawing.Point(176, 120);
			this.btnCurrSessSuspend.Name = "btnCurrSessSuspend";
			this.btnCurrSessSuspend.Size = new System.Drawing.Size(136, 56);
			this.btnCurrSessSuspend.TabIndex = 3;
			this.btnCurrSessSuspend.Text = "Suspend";
			this.btnCurrSessSuspend.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCurrSessSuspend.Click += new System.EventHandler(this.btnCurrSessSuspend_Click);
			// 
			// btnCurrSessReactivate
			// 
			this.btnCurrSessReactivate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCurrSessReactivate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnCurrSessReactivate.Image = ((System.Drawing.Image)(resources.GetObject("btnCurrSessReactivate.Image")));
			this.btnCurrSessReactivate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCurrSessReactivate.Location = new System.Drawing.Point(320, 120);
			this.btnCurrSessReactivate.Name = "btnCurrSessReactivate";
			this.btnCurrSessReactivate.Size = new System.Drawing.Size(136, 56);
			this.btnCurrSessReactivate.TabIndex = 4;
			this.btnCurrSessReactivate.Text = "Reactivate";
			this.btnCurrSessReactivate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCurrSessReactivate.Click += new System.EventHandler(this.btnCurrSessReactivate_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tbMarketStatus);
			this.groupBox1.Controls.Add(this.lbMarketStatus);
			this.groupBox1.Controls.Add(this.btnCurrSessTerminate);
			this.groupBox1.Controls.Add(this.btnCurrSessReactivate);
			this.groupBox1.Controls.Add(this.btnCurrSessSuspend);
			this.groupBox1.Controls.Add(this.btnCurrSessOpen);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(16, 16);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(632, 224);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "BIPEX Market - Current Session Management";
			// 
			// tbMarketStatus
			// 
			this.tbMarketStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbMarketStatus.Location = new System.Drawing.Point(356, 56);
			this.tbMarketStatus.Name = "tbMarketStatus";
			this.tbMarketStatus.ReadOnly = true;
			this.tbMarketStatus.Size = new System.Drawing.Size(176, 26);
			this.tbMarketStatus.TabIndex = 1;
			this.tbMarketStatus.Text = "";
			// 
			// lbMarketStatus
			// 
			this.lbMarketStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbMarketStatus.Location = new System.Drawing.Point(60, 56);
			this.lbMarketStatus.Name = "lbMarketStatus";
			this.lbMarketStatus.Size = new System.Drawing.Size(296, 23);
			this.lbMarketStatus.TabIndex = 0;
			this.lbMarketStatus.Text = "BIPEX Market - Current Session is:";
			this.lbMarketStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// frmQuadroComandi
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(962, 638);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Name = "frmQuadroComandi";
			this.Text = "Command Console";
			this.Load += new System.EventHandler(this.frmQuadroComandi_Load);
			this.VisibleChanged += new System.EventHandler(this.frmQuadroComandi_VisibleChanged);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		DataRecordList _drlMS;
		volatile BipexSubject _sMS;
		volatile bool _Visible = false;

		private void frmQuadroComandi_Load(object sender, System.EventArgs e)
		{
			_drlMS = new DataRecordList();
			_drlMS.Version = 0;

			_sMS = new BipexSubject();
			_sMS.DataDiMercato = DateTime.Now.Date;
			_sMS.SubjectType = "MS";
			_sMS.SubjectSubType = string.Empty;
			_sMS.Version = _drlMS.Version;

			_Visible = this.Visible;		
		}

		/// <summary>
		/// Imposta icona e testo della status bar apposita
		/// in funzione dello stato della sessione di mercato
		/// </summary>
		private void SetDialogCtrlOnBipexMktCurrSessStatusChanged()
		{
			switch (enBipexMktCurrSessStatus)
			{
				case MarketSessionDR.eStatoSessione.NUOVA:
				case MarketSessionDR.eStatoSessione.CHIUSA:
					// Se la sessione � NUOVA, CHIUSA, l'Amministratore NON PUO' 
					// FARE NULLA (da questi stati si esce secondo una logica interna a Bipex)
					this.btnCurrSessOpen.Enabled = false;
					this.btnCurrSessSuspend.Enabled = false;
					this.btnCurrSessReactivate.Enabled = false;
					this.btnCurrSessTerminate.Enabled = false;
					break;
				case MarketSessionDR.eStatoSessione.PREDISPOSTA:
					// Se la sessione � PREDISPOSTA l'Amministratore la pu� APRIRE...
					this.btnCurrSessOpen.Enabled = true;
					this.btnCurrSessSuspend.Enabled = false;
					this.btnCurrSessReactivate.Enabled = false;
					this.btnCurrSessTerminate.Enabled = false;
					this.btnCurrSessOpen.Focus();
					break;
				case MarketSessionDR.eStatoSessione.APERTA:
					// Se la sessione � APERTA l'Amministratore la pu� SOSPENDERE oppure TERMINARE...
					this.btnCurrSessOpen.Enabled = false;
					this.btnCurrSessSuspend.Enabled = true;
					this.btnCurrSessReactivate.Enabled = false;
					this.btnCurrSessTerminate.Enabled = true;
					this.btnCurrSessTerminate.Focus();
					break;
				case MarketSessionDR.eStatoSessione.SOSPESA:
					// Se la sessione � SOSPESA l'Amministratore la pu� RIATTIVARE oppure TERMINARE...
					this.btnCurrSessOpen.Enabled = false;
					this.btnCurrSessSuspend.Enabled = false;
					this.btnCurrSessReactivate.Enabled = true;
					this.btnCurrSessTerminate.Enabled = true;
					this.btnCurrSessReactivate.Focus();
					break;
				case MarketSessionDR.eStatoSessione.TERMINATA:
					// Se la sessione � TERMINATA l'Amministratore la pu� RIAPRIRE (RECOVERY ACTION)...
					this.btnCurrSessOpen.Enabled = true;
					this.btnCurrSessSuspend.Enabled = false;
					this.btnCurrSessReactivate.Enabled = false;
					this.btnCurrSessTerminate.Enabled = false;
					this.btnCurrSessOpen.Focus();
					break;
			}
		}
		
		private void btnCurrSessOpen_Click(object sender, System.EventArgs e)
		{
			string msgErrore = "";
			DialogResult dr = MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CONFIRMSESSOPEN"), BipexResourceManager.GetResourceString("MSG_POPUPCONFIRMTITLE"), MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
			if (dr == DialogResult.OK)
			{
				if (EngineMainForm._tspParams.enBipexMktCurrSessStatus == MarketSessionDR.eStatoSessione.TERMINATA)
				{
					// La Transizione di Stato da Terminata a Aperta e' una forzatura...
					if (!BLMainObj.CurrentSessionOpen(/* procedura forzata = */ true, out msgErrore))
					{
						MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "<" + msgErrore + ">", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						return;
					}
				}
				else
				{
					// Le altre Transizioni di Stato (da XXXXX a Aperta) NON SONO forzature...
					if (!BLMainObj.CurrentSessionOpen(/* procedura forzata = */ false, out msgErrore))
					{
						MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "<" + msgErrore + ">", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						return;
					}
				}
			}
		}

		private void btnCurrSessSuspend_Click(object sender, System.EventArgs e)
		{
			string msgErrore = "";
			DialogResult dr = MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CONFIRMSESSSUSPEND"), BipexResourceManager.GetResourceString("MSG_POPUPCONFIRMTITLE"), MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
			if (dr == DialogResult.OK)
			{
				if (!BLMainObj.CurrentSessionSuspend(/* procedura forzata = */ false, out msgErrore))
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "<" + msgErrore + ">", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
		}

		private void btnCurrSessReactivate_Click(object sender, System.EventArgs e)
		{
			string msgErrore = "";
			DialogResult dr = MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CONFIRMSESSREACTIVATE"), BipexResourceManager.GetResourceString("MSG_POPUPCONFIRMTITLE"), MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
			if (dr == DialogResult.OK)
			{
				if (!BLMainObj.CurrentSessionReactivate(/* procedura forzata = */ false, out msgErrore))
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "<" + msgErrore + ">", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
		}

		private void btnCurrSessTerminate_Click(object sender, System.EventArgs e)
		{
			string msgErrore = "";
			DialogResult dr = MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CONFIRMSESSTERMINATE"), BipexResourceManager.GetResourceString("MSG_POPUPCONFIRMTITLE"), MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
			if (dr == DialogResult.OK)
			{
				if (!BLMainObj.CurrentSessionTerminate(/* procedura forzata = */ true, out msgErrore))
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CURRENTSESSIONSTATUSNOTVALID"), "<" + msgErrore + ">", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
		}

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			//			if (this.InvokeRequired)
			//			{
			//				GetBipexSubjectDelegate d = new GetBipexSubjectDelegate(GetBipexSubject);
			//				return (BipexSubject[]) this.Invoke(d);
			//			}
			//			else
			//			{
			//				if (this.Visible)
			//					return new BipexSubject[] {_sMS };
			//				else
			//					return new BipexSubject[0];
			//			}

			if (this._Visible)
				return new BipexSubject[] {_sMS };
			else
				return new BipexSubject[0];
		}

		private delegate void OnBipexResponseDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponseDelegate d = new OnBipexResponseDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_sMS.SubjectType == req[0].SubjectType &&
					_sMS.SubjectSubType == req[0].SubjectSubType)
				{
					_drlMS.Merge(resp[0]);
					_sMS.Version = _drlMS.Version;

					if (_drlMS.Count > 0)
					{
						MarketSessionDR dr = (MarketSessionDR) _drlMS[0];

						// Se sono qui mi � arrivato un DataRecordList NUOVO...

						this.tbMarketStatus.Text = dr.StatoSessione.ToString();

						enBipexMktCurrSessStatus = dr.StatoSessione;
						SetDialogCtrlOnBipexMktCurrSessStatusChanged();

					}
					
				}
			}
		}

		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

		private void frmQuadroComandi_VisibleChanged(object sender, System.EventArgs e)
		{
			_Visible = this.Visible;		
		}

	}
}
