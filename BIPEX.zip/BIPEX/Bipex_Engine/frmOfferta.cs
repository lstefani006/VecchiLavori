using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using Bipex.Messaging.Offerte;
using Bipex_BLInterface;
using GME.Remoting;
using GME.Utility;
using SPDriver;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmOfferta.
	/// </summary>
	public class frmOfferta : Form
	{
		/// <summary>
		/// Oggetti BL utilizzati dal form
		/// </summary>
		IOfferta BLMainObj = (IOfferta) RemotingHelper.GetObject(typeof(IOfferta));
		ISessioneMercato BLSessioneMercatoObj = (ISessioneMercato) RemotingHelper.GetObject(typeof(ISessioneMercato));

		/// <summary>
		/// Modalit� di attivazione del Form
		/// </summary>
		public enum enFormMode
		{
			/// <summary>
			/// Questa modalita' serve a piazzare una NUOVA offerta.
			/// </summary>
			NEW = 0,
			/// <summary>
			/// Questa modalit� serve a MODIFICARE l'offerta ricevuta
			/// come argomento... NON si possono piazzare NUOVE offerte.
			/// </summary>
			MODIFY,
			REVOKE,
			HIDE,
			REVEAL
		}

		private System.Windows.Forms.Label lbQty;
		private System.Windows.Forms.Label lbPrice;
		private System.Windows.Forms.Label lbTotal;
		private System.Windows.Forms.Label lbWarranty;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Label lbContract;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public static readonly string sNotesInitialValue = "<<You can write Your Note/Tag here>>";

		private System.Windows.Forms.TextBox tbQty;
		private System.Windows.Forms.TextBox tbPrice;
		private System.Windows.Forms.TextBox tbTotal;
		private System.Windows.Forms.TextBox tbWarranty;
		private System.Windows.Forms.GroupBox gbBuySell;
		private System.Windows.Forms.CheckBox cbBuy;
		private System.Windows.Forms.CheckBox cbSell;
		private System.Windows.Forms.TextBox tbContract;
		private System.Windows.Forms.TextBox tbNotes;
		private System.Windows.Forms.GroupBox gbOfferType;
		private System.Windows.Forms.CheckBox cbPriceLimit;
		private System.Windows.Forms.CheckBox cbPriceMarket;

		private DataRow drContractList;
		private string[] MappingNamesContractList;
		private string tipo;
		private short sContractHours = 0;

		DatiOfferta DO;
		DatiContratto DC;
		private System.Windows.Forms.CheckBox cbIsOTC;
		private System.Windows.Forms.GroupBox gbOTC;
		private System.Windows.Forms.ComboBox cbOTCOperator;
		private System.Windows.Forms.TextBox tbOTCCode;
		private System.Windows.Forms.Label lbOTCOperator;
		private System.Windows.Forms.Label lbOTCCode;
		private System.Windows.Forms.TextBox tbHours;
		
		private enFormMode formMode;

		public frmOfferta(DatiOfferta aDO, DatiContratto aDC, enFormMode aFormMode)
		{
			DO = aDO;
			DC = aDC;

			formMode = aFormMode;
			sContractHours = Convert.ToInt16(DC.nnOreFornituraFeriali + DC.nnOreFornituraFestive);

			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		public frmOfferta(DataRow adrContractList, string[] aMappingNamesContractList, string aTipo)
		{
			drContractList = adrContractList;
			MappingNamesContractList = aMappingNamesContractList;
			tipo = aTipo;
			
			formMode = enFormMode.NEW;
			sContractHours = Convert.ToInt16(drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.Hours]]);

			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmOfferta));
			this.tbQty = new System.Windows.Forms.TextBox();
			this.tbPrice = new System.Windows.Forms.TextBox();
			this.tbTotal = new System.Windows.Forms.TextBox();
			this.tbWarranty = new System.Windows.Forms.TextBox();
			this.lbQty = new System.Windows.Forms.Label();
			this.lbPrice = new System.Windows.Forms.Label();
			this.lbTotal = new System.Windows.Forms.Label();
			this.lbWarranty = new System.Windows.Forms.Label();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.lbContract = new System.Windows.Forms.Label();
			this.gbBuySell = new System.Windows.Forms.GroupBox();
			this.cbBuy = new System.Windows.Forms.CheckBox();
			this.cbSell = new System.Windows.Forms.CheckBox();
			this.tbContract = new System.Windows.Forms.TextBox();
			this.tbNotes = new System.Windows.Forms.TextBox();
			this.gbOfferType = new System.Windows.Forms.GroupBox();
			this.cbPriceMarket = new System.Windows.Forms.CheckBox();
			this.cbPriceLimit = new System.Windows.Forms.CheckBox();
			this.cbIsOTC = new System.Windows.Forms.CheckBox();
			this.gbOTC = new System.Windows.Forms.GroupBox();
			this.tbOTCCode = new System.Windows.Forms.TextBox();
			this.cbOTCOperator = new System.Windows.Forms.ComboBox();
			this.lbOTCCode = new System.Windows.Forms.Label();
			this.lbOTCOperator = new System.Windows.Forms.Label();
			this.tbHours = new System.Windows.Forms.TextBox();
			this.gbBuySell.SuspendLayout();
			this.gbOfferType.SuspendLayout();
			this.gbOTC.SuspendLayout();
			this.SuspendLayout();
			// 
			// tbQty
			// 
			this.tbQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbQty.Location = new System.Drawing.Point(200, 136);
			this.tbQty.Name = "tbQty";
			this.tbQty.TabIndex = 5;
			this.tbQty.Text = "0";
			this.tbQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbQty_KeyPress);
			this.tbQty.TextChanged += new System.EventHandler(this.tbQty_TextChanged);
			// 
			// tbPrice
			// 
			this.tbPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbPrice.Location = new System.Drawing.Point(192, 16);
			this.tbPrice.Name = "tbPrice";
			this.tbPrice.TabIndex = 1;
			this.tbPrice.Text = "0";
			this.tbPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPrice_KeyPress);
			this.tbPrice.TextChanged += new System.EventHandler(this.tbPrice_TextChanged);
			// 
			// tbTotal
			// 
			this.tbTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbTotal.Location = new System.Drawing.Point(88, 86);
			this.tbTotal.Name = "tbTotal";
			this.tbTotal.ReadOnly = true;
			this.tbTotal.TabIndex = 5;
			this.tbTotal.TabStop = false;
			this.tbTotal.Text = "";
			// 
			// tbWarranty
			// 
			this.tbWarranty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbWarranty.Location = new System.Drawing.Point(264, 86);
			this.tbWarranty.Name = "tbWarranty";
			this.tbWarranty.ReadOnly = true;
			this.tbWarranty.TabIndex = 7;
			this.tbWarranty.TabStop = false;
			this.tbWarranty.Text = "";
			// 
			// lbQty
			// 
			this.lbQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbQty.Location = new System.Drawing.Point(64, 136);
			this.lbQty.Name = "lbQty";
			this.lbQty.Size = new System.Drawing.Size(128, 23);
			this.lbQty.TabIndex = 4;
			this.lbQty.Text = "Quantity";
			this.lbQty.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lbPrice
			// 
			this.lbPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbPrice.Location = new System.Drawing.Point(56, 16);
			this.lbPrice.Name = "lbPrice";
			this.lbPrice.Size = new System.Drawing.Size(128, 23);
			this.lbPrice.TabIndex = 0;
			this.lbPrice.Text = "Unit Price (� / MWh)";
			this.lbPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lbTotal
			// 
			this.lbTotal.Location = new System.Drawing.Point(8, 80);
			this.lbTotal.Name = "lbTotal";
			this.lbTotal.Size = new System.Drawing.Size(70, 32);
			this.lbTotal.TabIndex = 4;
			this.lbTotal.Text = "Total Amount (�)";
			this.lbTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lbWarranty
			// 
			this.lbWarranty.Location = new System.Drawing.Point(192, 80);
			this.lbWarranty.Name = "lbWarranty";
			this.lbWarranty.Size = new System.Drawing.Size(70, 32);
			this.lbWarranty.TabIndex = 6;
			this.lbWarranty.Text = "Total Warranty (�)";
			this.lbWarranty.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
			this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCancel.Location = new System.Drawing.Point(199, 450);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(80, 32);
			this.btnCancel.TabIndex = 10;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnOK
			// 
			this.btnOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnOK.Image = ((System.Drawing.Image)(resources.GetObject("btnOK.Image")));
			this.btnOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnOK.Location = new System.Drawing.Point(111, 450);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(80, 32);
			this.btnOK.TabIndex = 9;
			this.btnOK.Text = "&OK";
			this.btnOK.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// lbContract
			// 
			this.lbContract.Location = new System.Drawing.Point(72, 72);
			this.lbContract.Name = "lbContract";
			this.lbContract.Size = new System.Drawing.Size(240, 23);
			this.lbContract.TabIndex = 1;
			this.lbContract.Text = "on Contract (Contract ID / Total Hours):";
			this.lbContract.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// gbBuySell
			// 
			this.gbBuySell.Controls.Add(this.cbBuy);
			this.gbBuySell.Controls.Add(this.cbSell);
			this.gbBuySell.Location = new System.Drawing.Point(112, 0);
			this.gbBuySell.Name = "gbBuySell";
			this.gbBuySell.Size = new System.Drawing.Size(160, 72);
			this.gbBuySell.TabIndex = 0;
			this.gbBuySell.TabStop = false;
			// 
			// cbBuy
			// 
			this.cbBuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cbBuy.Location = new System.Drawing.Point(48, 16);
			this.cbBuy.Name = "cbBuy";
			this.cbBuy.Size = new System.Drawing.Size(72, 24);
			this.cbBuy.TabIndex = 0;
			this.cbBuy.Text = "BUY";
			this.cbBuy.CheckedChanged += new System.EventHandler(this.cbBuy_CheckedChanged);
			// 
			// cbSell
			// 
			this.cbSell.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cbSell.Location = new System.Drawing.Point(48, 40);
			this.cbSell.Name = "cbSell";
			this.cbSell.Size = new System.Drawing.Size(72, 24);
			this.cbSell.TabIndex = 1;
			this.cbSell.Text = "SELL";
			this.cbSell.CheckedChanged += new System.EventHandler(this.cbSell_CheckedChanged);
			// 
			// tbContract
			// 
			this.tbContract.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbContract.Location = new System.Drawing.Point(8, 96);
			this.tbContract.Name = "tbContract";
			this.tbContract.ReadOnly = true;
			this.tbContract.Size = new System.Drawing.Size(312, 26);
			this.tbContract.TabIndex = 2;
			this.tbContract.TabStop = false;
			this.tbContract.Text = "tbContract";
			this.tbContract.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// tbNotes
			// 
			this.tbNotes.Location = new System.Drawing.Point(8, 392);
			this.tbNotes.Multiline = true;
			this.tbNotes.Name = "tbNotes";
			this.tbNotes.Size = new System.Drawing.Size(368, 48);
			this.tbNotes.TabIndex = 8;
			this.tbNotes.Text = "";
			// 
			// gbOfferType
			// 
			this.gbOfferType.Controls.Add(this.cbPriceMarket);
			this.gbOfferType.Controls.Add(this.cbPriceLimit);
			this.gbOfferType.Controls.Add(this.lbPrice);
			this.gbOfferType.Controls.Add(this.tbPrice);
			this.gbOfferType.Controls.Add(this.tbWarranty);
			this.gbOfferType.Controls.Add(this.lbWarranty);
			this.gbOfferType.Controls.Add(this.tbTotal);
			this.gbOfferType.Controls.Add(this.lbTotal);
			this.gbOfferType.Location = new System.Drawing.Point(8, 168);
			this.gbOfferType.Name = "gbOfferType";
			this.gbOfferType.Size = new System.Drawing.Size(368, 120);
			this.gbOfferType.TabIndex = 6;
			this.gbOfferType.TabStop = false;
			// 
			// cbPriceMarket
			// 
			this.cbPriceMarket.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cbPriceMarket.Location = new System.Drawing.Point(192, 48);
			this.cbPriceMarket.Name = "cbPriceMarket";
			this.cbPriceMarket.TabIndex = 3;
			this.cbPriceMarket.Text = "Market Offer";
			this.cbPriceMarket.CheckedChanged += new System.EventHandler(this.cbPriceMarket_CheckedChanged);
			// 
			// cbPriceLimit
			// 
			this.cbPriceLimit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cbPriceLimit.Location = new System.Drawing.Point(64, 48);
			this.cbPriceLimit.Name = "cbPriceLimit";
			this.cbPriceLimit.Size = new System.Drawing.Size(112, 24);
			this.cbPriceLimit.TabIndex = 2;
			this.cbPriceLimit.Text = "Price Limit Offer";
			this.cbPriceLimit.CheckedChanged += new System.EventHandler(this.cbPriceLimit_CheckedChanged);
			// 
			// cbIsOTC
			// 
			this.cbIsOTC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cbIsOTC.Location = new System.Drawing.Point(8, 24);
			this.cbIsOTC.Name = "cbIsOTC";
			this.cbIsOTC.Size = new System.Drawing.Size(56, 40);
			this.cbIsOTC.TabIndex = 0;
			this.cbIsOTC.Text = "OTC Offer";
			this.cbIsOTC.CheckedChanged += new System.EventHandler(this.cbIsOTC_CheckedChanged);
			// 
			// gbOTC
			// 
			this.gbOTC.Controls.Add(this.cbIsOTC);
			this.gbOTC.Controls.Add(this.tbOTCCode);
			this.gbOTC.Controls.Add(this.cbOTCOperator);
			this.gbOTC.Controls.Add(this.lbOTCCode);
			this.gbOTC.Controls.Add(this.lbOTCOperator);
			this.gbOTC.Location = new System.Drawing.Point(8, 296);
			this.gbOTC.Name = "gbOTC";
			this.gbOTC.Size = new System.Drawing.Size(368, 88);
			this.gbOTC.TabIndex = 7;
			this.gbOTC.TabStop = false;
			// 
			// tbOTCCode
			// 
			this.tbOTCCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbOTCCode.Location = new System.Drawing.Point(144, 48);
			this.tbOTCCode.Name = "tbOTCCode";
			this.tbOTCCode.Size = new System.Drawing.Size(216, 26);
			this.tbOTCCode.TabIndex = 4;
			this.tbOTCCode.Text = "";
			// 
			// cbOTCOperator
			// 
			this.cbOTCOperator.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cbOTCOperator.Location = new System.Drawing.Point(144, 16);
			this.cbOTCOperator.Name = "cbOTCOperator";
			this.cbOTCOperator.Size = new System.Drawing.Size(216, 28);
			this.cbOTCOperator.TabIndex = 2;
			// 
			// lbOTCCode
			// 
			this.lbOTCCode.Location = new System.Drawing.Point(64, 48);
			this.lbOTCCode.Name = "lbOTCCode";
			this.lbOTCCode.Size = new System.Drawing.Size(75, 23);
			this.lbOTCCode.TabIndex = 3;
			this.lbOTCCode.Text = "Match Code:";
			this.lbOTCCode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lbOTCOperator
			// 
			this.lbOTCOperator.Location = new System.Drawing.Point(64, 19);
			this.lbOTCOperator.Name = "lbOTCOperator";
			this.lbOTCOperator.Size = new System.Drawing.Size(75, 23);
			this.lbOTCOperator.TabIndex = 1;
			this.lbOTCOperator.Text = "For:";
			this.lbOTCOperator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tbHours
			// 
			this.tbHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbHours.Location = new System.Drawing.Point(320, 96);
			this.tbHours.Name = "tbHours";
			this.tbHours.ReadOnly = true;
			this.tbHours.Size = new System.Drawing.Size(63, 26);
			this.tbHours.TabIndex = 3;
			this.tbHours.TabStop = false;
			this.tbHours.Text = "tbHours";
			this.tbHours.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// frmOfferta
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(386, 488);
			this.Controls.Add(this.tbHours);
			this.Controls.Add(this.gbOTC);
			this.Controls.Add(this.gbOfferType);
			this.Controls.Add(this.tbNotes);
			this.Controls.Add(this.tbQty);
			this.Controls.Add(this.tbContract);
			this.Controls.Add(this.gbBuySell);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.lbContract);
			this.Controls.Add(this.lbQty);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmOfferta";
			this.Text = "Offer";
			this.Load += new System.EventHandler(this.frmOfferta_Load);
			this.Activated += new System.EventHandler(this.frmOfferta_Activated);
			this.gbBuySell.ResumeLayout(false);
			this.gbOfferType.ResumeLayout(false);
			this.gbOTC.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private bool bLoaded = false;
		private void frmOfferta_Load(object sender, System.EventArgs e)
		{

			this.cbOTCOperator.Items.Clear();
			OperatoreOTC[] tmpOPList = BLSessioneMercatoObj.GetListaOperatoriOTC(EngineMainForm._tspParams.ActiveOperatorCode);
			foreach(OperatoreOTC tmpOP in tmpOPList)
				cbOTCOperator.Items.Add(tmpOP);

			switch (formMode)
			{
				case enFormMode.NEW:
				{
					this.cbBuy.Enabled = true;
					this.cbSell.Enabled = true;
					this.tbQty.Enabled = true;
					this.tbPrice.Enabled = true;
					this.cbPriceLimit.Enabled = true;
					this.cbPriceMarket.Enabled = true;
					this.lbTotal.Visible = true;
					this.tbTotal.Visible = true;
					this.lbWarranty.Visible = true;
					this.tbWarranty.Visible = true;

					this.cbIsOTC.Enabled = true;
					this.cbOTCOperator.Enabled = true;
					this.tbOTCCode.Enabled = true;

					this.tbNotes.Enabled = true;

					this.Text = formMode.ToString() + " Offer on " + drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.Contract]].ToString();

					this.tbContract.Text = drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.Contract]].ToString();
					this.tbHours.Text = this.sContractHours.ToString();

					if (tipo == "A")
					{
						this.cbBuy.Checked = true;
						this.cbSell.Checked = false;

						// Prendo la quantita' dall'attuale valore del'offerta di vendita,
						// se quest'ultima non e' presente imposto come default la quantita' uguale a 1.
						string tmpQty = FormatObjectAsString(drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.AskQty]], BipexFormSettings.FmtForQty);
						if (tmpQty == "")
							tmpQty = "1";

						// Prendo il prezzo dall'attuale valore del'offerta di vendita,
						// se quest'ultima non e' presente prendo il prezzo dal prezzo
						// di riferimento della sess. precedente, se quest'ultimo non e'
						// presente, imposto come default il prezzo in base ad una costante...
						string tmpPrice = FormatObjectAsString(drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.AskPrice]], BipexFormSettings.FmtForPrice);
						if (tmpPrice == "")
							tmpPrice = FormatObjectAsString(drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.RefPrice]], BipexFormSettings.FmtForPrice);
						if (tmpPrice == "")
						{
							double dPrice;
							if (this.tbContract.Text.LastIndexOf("BSLD") != -1)
							{
								dPrice = 50;
								tmpPrice = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
							}
							else
								if (this.tbContract.Text.LastIndexOf("OFPK") != -1)
							{
								dPrice = 35;
								tmpPrice = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
							}
							else
								if (this.tbContract.Text.LastIndexOf("PEAK") != -1)
							{
								dPrice = 65;
								tmpPrice = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
							}
							else
							{
								dPrice = 50;
								tmpPrice = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
							}
						}

						this.tbQty.Text = tmpQty;
						this.tbPrice.Text = tmpPrice;
					}
					else
					{
						this.cbBuy.Checked = false;
						this.cbSell.Checked = true;

						// Prendo la quantita' dall'attuale valore del'offerta di acquisto,
						// se quest'ultima non e' presente imposto come default la quantita' uguale a 1.
						string tmpQty = FormatObjectAsString(drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.BidQty]], BipexFormSettings.FmtForQty);
						if (tmpQty == "")
							tmpQty = "1";

						// Prendo il prezzo dall'attuale valore del'offerta di acquisto,
						// se quest'ultima non e' presente prendo il prezzo dal prezzo
						// di riferimento della sess. precedente, se quest'ultimo non e'
						// presente, imposto come default il prezzo in base ad una costante...
						string tmpPrice = FormatObjectAsString(drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.BidPrice]], BipexFormSettings.FmtForPrice);
						if (tmpPrice == "")
							tmpPrice = FormatObjectAsString(drContractList[MappingNamesContractList[(int) frmBook.enPosColonneDS.RefPrice]], BipexFormSettings.FmtForPrice);
						if (tmpPrice == "")
						{
							double dPrice;
							if (this.tbContract.Text.LastIndexOf("BSLD") != -1)
							{
								dPrice = 50;
								tmpPrice = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
							}
							else
								if (this.tbContract.Text.LastIndexOf("OFPK") != -1)
							{
								dPrice = 35;
								tmpPrice = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
							}
							else
								if (this.tbContract.Text.LastIndexOf("PEAK") != -1)
							{
								dPrice = 65;
								tmpPrice = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
							}
							else
							{
								dPrice = 50;
								tmpPrice = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
							}
						}

						this.tbQty.Text = tmpQty;
						this.tbPrice.Text = tmpPrice;
			
					}

					this.cbPriceLimit.Checked = true;
					this.cbPriceMarket.Checked = false;

					// Per default una nuova offerta NON � OTC...
					this.cbIsOTC.Checked = false;
					this.cbOTCOperator.SelectedIndex = 0;
					this.cbOTCOperator.Enabled = false;
					this.tbOTCCode.Text = "";
					this.tbOTCCode.Enabled = false;
					
					this.tbNotes.Text = frmOfferta.sNotesInitialValue;

					break;
				}
				case enFormMode.MODIFY:
				{
					// In fase di modifica di un'offerta si pu� modificarne il prezzo, la quantit�,
					// le note, ma NON SI PUO' MODIFICARE il tipo dell'offerta stessa in relazione
					// al prezzo, vale a dire se era un'offerta con limite di prezzo oppure un'offerta
					// a mercato... questo si stabilisce in fase di presentazione iniziale e poi non
					// si pu� cambiare... se si � sbagliato si deve revocare l'offerta e ripresentarla...
					this.cbBuy.Enabled = false;
					this.cbSell.Enabled = false;
					this.tbQty.Enabled = true;
					this.tbPrice.Enabled = true;
					this.cbPriceLimit.Enabled = false;
					this.cbPriceMarket.Enabled = false;
					this.lbTotal.Visible = true;
					this.tbTotal.Visible = true;
					this.lbWarranty.Visible = true;
					this.tbWarranty.Visible = true;

					this.cbIsOTC.Enabled = false;
					this.cbOTCOperator.Enabled = false;
					this.tbOTCCode.Enabled = false;

					this.tbNotes.Enabled = true;

					this.Text = formMode.ToString() + " Offer " + DO.nnIdOfferta.ToString() + " on " + DC.nnNomeContratto;

					this.tbContract.Text = DC.nnNomeContratto;
					this.tbHours.Text = this.sContractHours.ToString();

					if (DO.nuTipoOfferta == Offerta_Tipo.Acquisto)
					{
						this.cbBuy.Checked = true;
						this.cbSell.Checked = false;
					}
					else
					{
						this.cbBuy.Checked = false;
						this.cbSell.Checked = true;
					}

					this.tbQty.Text = DO.nnQtyResidua.ToString(BipexFormSettings.FmtForQty, Thread.CurrentThread.CurrentCulture);
					this.tbPrice.Text = DO.nnPrezzo.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);

					if (DO.nnOffertaAMercato)
					{
						this.cbPriceMarket.Checked = true;
						this.cbPriceLimit.Checked = false;
					}
					else
					{
						this.cbPriceMarket.Checked = false;
						this.cbPriceLimit.Checked = true;
					}

					if (DO.nnOperatoreOTC != string.Empty)
					{
						// In fase di modifica di un'offerta OTC si fa vedere l'operatore ed il codice
						// ma non si consente la modifica, per modificare un'offerta OTC la si deve
						// revocare e ricreare da zero...
						this.cbIsOTC.Checked = true;

						bool bFound = false;
						foreach (object tmp in this.cbOTCOperator.Items)
						{
							if (((OperatoreOTC)tmp).nnCodiceOperatore == DO.nnOperatoreOTC)
							{
								this.cbOTCOperator.SelectedItem = tmp;
								bFound = true;
								break;
							}
						}
						if (!bFound)
						{
							throw (new Exception(String.Format(BipexResourceManager.GetResourceString("MSG_OPERATORUNKNOWN"), DO.nnCodiceOTC)));
						}


						this.tbOTCCode.Text = DO.nnCodiceOTC;

					}
					else
					{
						this.cbIsOTC.Checked = false;
						this.cbOTCOperator.SelectedIndex = 0;
						this.tbOTCCode.Text = "";
					}
					this.cbIsOTC.Enabled = false;
					this.cbOTCOperator.Enabled = false;
					this.tbOTCCode.Enabled = false;
					
					this.tbNotes.Text = DO.nnNote;

					break;
				}
				case enFormMode.REVOKE:
				case enFormMode.HIDE:
				case enFormMode.REVEAL:
				{
					this.cbBuy.Enabled = false;
					this.cbSell.Enabled = false;
					this.tbQty.Enabled = false;
					this.tbPrice.Enabled = false;
					this.cbPriceLimit.Enabled = false;
					this.cbPriceMarket.Enabled = false;
					this.lbTotal.Visible = false;
					this.tbTotal.Visible = false;
					this.lbWarranty.Visible = false;
					this.tbWarranty.Visible = false;

					this.cbIsOTC.Enabled = false;
					this.cbOTCOperator.Enabled = false;
					this.tbOTCCode.Enabled = false;

					this.tbNotes.Enabled = true;

					this.Text = formMode.ToString() + " Offer " + DO.nnIdOfferta.ToString() + " on " + DC.nnNomeContratto;

					this.tbContract.Text = DC.nnNomeContratto;
					this.tbHours.Text = this.sContractHours.ToString();

					if (DO.nuTipoOfferta == Offerta_Tipo.Acquisto)
					{
						this.cbBuy.Checked = true;
						this.cbSell.Checked = false;
					}
					else
					{
						this.cbBuy.Checked = false;
						this.cbSell.Checked = true;
					}

					this.tbQty.Text = DO.nnQtyResidua.ToString(BipexFormSettings.FmtForQty, Thread.CurrentThread.CurrentCulture);
					this.tbPrice.Text = DO.nnPrezzo.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);

					if (DO.nnOffertaAMercato)
					{
						this.cbPriceMarket.Checked = true;
						this.cbPriceLimit.Checked = false;
					}
					else
					{
						this.cbPriceMarket.Checked = false;
						this.cbPriceLimit.Checked = true;
					}

					if (DO.nnOperatoreOTC != string.Empty)
					{
						// In fase di revoke / hide / reveal si fa vedere l'operatore ed il codice
						// ma non si consente la modifica, per modificare un'offerta OTC la si deve
						// revocare e ricreare da zero...
						this.cbIsOTC.Checked = true;

						bool bFound = false;
						foreach (object tmp in this.cbOTCOperator.Items)
						{
							if (((OperatoreOTC)tmp).nnCodiceOperatore == DO.nnOperatoreOTC)
							{
								this.cbOTCOperator.SelectedItem = tmp;
								bFound = true;
								break;
							}
						}
						if (!bFound)
						{
							throw (new Exception(String.Format(BipexResourceManager.GetResourceString("MSG_OPERATORUNKNOWN"), DO.nnCodiceOTC)));
						}


						this.tbOTCCode.Text = DO.nnCodiceOTC;

					}
					else
					{
						this.cbIsOTC.Checked = false;
						this.cbOTCOperator.SelectedIndex = 0;
						this.tbOTCCode.Text = "";
					}
					this.cbIsOTC.Enabled = false;
					this.cbOTCOperator.Enabled = false;
					this.tbOTCCode.Enabled = false;
					
					this.tbNotes.Text = DO.nnNote;

					break;
				}
			}
			
		}

		private void frmOfferta_Activated(object sender, System.EventArgs e)
		{
			if (!bLoaded)
			{
				bLoaded = true;
				this.tbQty.Focus();
			}
		}

		private void tbQty_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			// Non si accettano caratteri alfabetici
			if (!(char.IsNumber(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSeparator(e.KeyChar) || char.IsControl(e.KeyChar)))
				e.Handled = true;
		}

		private void tbPrice_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			// Non si accettano caratteri alfabetici
			if (!(char.IsNumber(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSeparator(e.KeyChar) || char.IsControl(e.KeyChar)))
				e.Handled = true;
		}

		private void tbQty_TextChanged(object sender, System.EventArgs e)
		{
			ResetTotalOnQtyOrPriceChange();
		}

		private void tbPrice_TextChanged(object sender, System.EventArgs e)
		{
			ResetTotalOnQtyOrPriceChange();
		}

		private void ResetTotalOnQtyOrPriceChange()
		{
			// Sono cambiati il prezzo oppure la quantita', ricalcolo il totale...
			try
			{

				// Totale = Qty * Prezzo Orario * Numero di Ore del Contratto
				int qty = Convert.ToInt32(this.tbQty.Text, Thread.CurrentThread.CurrentCulture);
				double price = Convert.ToDouble(this.tbPrice.Text, Thread.CurrentThread.CurrentCulture);

				double total = qty * price * sContractHours;
				this.tbTotal.Text = total.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);

				// Garanzia = PER ORA, PER LA DEMO, e' SEMPRE uguale al 20% del Totale di cui sopra...
				double warranty = total / 5;
				this.tbWarranty.Text = warranty.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
			}
			catch
			{
			}
		}

		protected string FormatObjectAsString(object o, string Format)
		{
			if (o.GetType() == typeof (DateTime))
			{
				DateTime tmp = Convert.ToDateTime(o, Thread.CurrentThread.CurrentCulture);
				return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
			}
			else if (o.GetType() == typeof (double))
			{
				double tmp = Convert.ToDouble(o, Thread.CurrentThread.CurrentCulture);
				return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
			}
			else if (o.GetType() == typeof (decimal))
			{
				decimal tmp = Convert.ToDecimal(o, Thread.CurrentThread.CurrentCulture);
				return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
			}
			if (o.GetType() == typeof (short))
			{
				short tmp = Convert.ToInt16(o, Thread.CurrentThread.CurrentCulture);
				return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
			}
			if (o.GetType() == typeof (int))
			{
				int tmp = Convert.ToInt32(o, Thread.CurrentThread.CurrentCulture);
				return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
			}
			if (o.GetType() == typeof (long))
			{
				long tmp = Convert.ToInt64(o, Thread.CurrentThread.CurrentCulture);
				return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
			}
			else
			{
				// Type non gestito con formattazione specifica, richiamo il metodo
				// standard di conversione in stringa...
				return o.ToString();
			}
		}

		private void btnOK_Click(object sender, System.EventArgs e)
		{
			// Verifiche sintattiche sui campi di input prima di procedere...

			// Almeno uno deve essere selezionato...
			if (!this.cbBuy.Checked && !this.cbSell.Checked)
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CHOOSEAVALIDOFFERTYPE"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.cbBuy.Focus();
				return;
			}

			int qty;
			try
			{
				qty = Convert.ToInt32(this.tbQty.Text, Thread.CurrentThread.CurrentCulture);
				if (qty == 0)
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_TYPEAVALIDQUANTITY"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
					this.tbQty.Focus();
					return;
				}
			}
			catch
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_TYPEAVALIDQUANTITY"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.tbQty.Focus();
				return;
			}

			double price;
			try
			{
				price = Convert.ToDouble(this.tbPrice.Text, Thread.CurrentThread.CurrentCulture);
			}
			catch
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_TYPEAVALIDPRICE"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.tbPrice.Focus();
				return;
			}

			if (!this.cbPriceLimit.Checked && !this.cbPriceMarket.Checked)
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CHOOSEAVALIDPRICETYPE"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.cbPriceLimit.Focus();
				return;
			}
			
			bool bPriceLimit = this.cbPriceLimit.Checked;
			bool bPriceMarket = this.cbPriceMarket.Checked;
			if (bPriceLimit && price == 0)
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_TYPEAVALIDPRICE"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.tbPrice.Focus();
				return;
			}
			if (bPriceMarket && price > 0)
			{
				MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_MARKETOFFERPRICEZERO"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.tbPrice.Focus();
				return;
			}

			if (cbIsOTC.Checked)
			{
				// Se l'offerta � OTC, sia l'operatore sia il codice di abbinamento sono campi obbligatori...
				if (this.cbOTCOperator.SelectedIndex == -1)
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_CHOOSEAVALIDOPERATOR"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
					this.cbOTCOperator.Focus();
					return;
				}
				if (this.tbOTCCode.Text == string.Empty)
				{
					MessageBox.Show(this.Owner, BipexResourceManager.GetResourceString("MSG_TYPEAVALIDMATCHCODE"), BipexResourceManager.GetResourceString("MSG_OFFERDATANOTVALID"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
					this.tbOTCCode.Focus();
					return;
				}
			}

			// Chiedere conferma!!!

			string sOp = "";
			if (this.cbBuy.Checked)
				sOp = this.cbBuy.Text;
			else
				if (this.cbSell.Checked)
				sOp = this.cbSell.Text;

			DialogResult dr = MessageBox.Show(
				this.Owner, 
				String.Format(BipexResourceManager.GetResourceString("MSG_OFFERCONFIRMATIONTEXT"), 
					formMode.ToString(),
					sOp,
					this.tbContract.Text,
					this.tbQty.Text,
					this.tbPrice.Text),
				String.Format(BipexResourceManager.GetResourceString("MSG_OFFERCONFIRMATIONTITLE"), 
					this.Text),
				MessageBoxButtons.OKCancel, 
				MessageBoxIcon.Question);

			if (dr == DialogResult.OK)
			{
				// QUI occorre GENERARE L'XML / XSD con la nuova offerta ed inviarlo al metodo preposto del BL...

				// La modalit� � SINCRONA (quindi CLESSIDRA e tutto bloccato sino a quando non arriva la risposta del BL)
				Cursor.Current = Cursors.WaitCursor;

				try
				{
			
					MessaggioIn m = new MessaggioIn();

					m.DataOraMessaggio = DateTime.Now;
					m.CodiceMessaggioIn = Guid.NewGuid().ToString("N");
					m.Versione = tipoVersione.Item10;

					m.Testata = new TestataMessaggioIn();
					m.Testata.Destinatario = new Destinatario();
					m.Testata.Mittente = new MittenteRichiesta();

					m.Testata.Mittente.CodiceOperatore = EngineMainForm._tspParams.ActiveOperatorCode;
					m.Testata.Mittente.CodiceUtente = EngineMainForm._tspParams.ActiveUserCode;

					m.Testata.Destinatario.CodiceOperatore = "IDBIPEX";

					m.TransazioneIn = new TransazioneIn[1];

					m.TransazioneIn[0] = new TransazioneIn();
					m.TransazioneIn[0].CodiceTransazioneIn = Guid.NewGuid().ToString("N");

					switch (formMode)
					{
						case enFormMode.NEW:
						{
							RichiestaNuovaOfferta rq = new RichiestaNuovaOfferta();
							m.TransazioneIn[0].Item = rq;

							if (cbIsOTC.Checked)
							{
								rq.CodiceOTC = tbOTCCode.Text;
								rq.OperatoreOTC = ((OperatoreOTC)cbOTCOperator.SelectedItem).nnCodiceOperatore;
							}
							else
							{
								rq.CodiceOTC = string.Empty;
								rq.OperatoreOTC = string.Empty;
							}

							if (this.cbBuy.Checked)
								rq.TipoOfferta = tipoTipoOfferta.Acquisto;
							else
								rq.TipoOfferta = tipoTipoOfferta.Vendita;

							rq.Contratto = this.tbContract.Text;
							rq.Quantita = Convert.ToInt32(this.tbQty.Text);
							rq.PrezzoUnitario = Convert.ToDecimal(this.tbPrice.Text);

							if (this.tbNotes.Text == frmOfferta.sNotesInitialValue)
								// Se l'operatore non ha variato il valore iniziale del campo note, non invio
								// a BIPEX questo valore come nota ma invio stringa vuota...
								rq.NoteOfferta = string.Empty;
							else
								rq.NoteOfferta = this.tbNotes.Text;
						}
							break;
						case enFormMode.MODIFY:
						{
							RichiestaModificaOfferta rq = new RichiestaModificaOfferta();
							m.TransazioneIn[0].Item = rq;

							rq.IdOfferta = DO.nnIdOfferta.ToString();
							rq.Quantita = Convert.ToInt32(this.tbQty.Text);
							rq.PrezzoUnitario = Convert.ToDecimal(this.tbPrice.Text);
							rq.NoteOfferta = this.tbNotes.Text;
						}
							break;
						case enFormMode.REVOKE:
						{
							RichiestaRevocaOfferta rq = new RichiestaRevocaOfferta();
							m.TransazioneIn[0].Item = rq;

							rq.IdOfferta = DO.nnIdOfferta.ToString();
							rq.NoteOfferta = this.tbNotes.Text;
						}
							break;
						case enFormMode.HIDE:
						{
							RichiestaSospendiOfferta rq = new RichiestaSospendiOfferta();
							m.TransazioneIn[0].Item = rq;

							rq.IdOfferta = DO.nnIdOfferta.ToString();
							rq.NoteOfferta = this.tbNotes.Text;
						}
							break;
						case enFormMode.REVEAL:
						{
							RichiestaRivelaOfferta rq = new RichiestaRivelaOfferta();
							m.TransazioneIn[0].Item = rq;

							rq.IdOfferta = DO.nnIdOfferta.ToString();
							rq.NoteOfferta = this.tbNotes.Text;
						}
							break;
					}

					MemoryStream msRich = new MemoryStream();
					XmlTextWriter xw = new XmlTextWriter(msRich, Encoding.UTF8);
					xw.Indentation = 1;
					xw.IndentChar = '\t';
					xw.Formatting = Formatting.Indented;
					xw.Namespaces = true;
					XmlSerializer xs = new XmlSerializer(typeof(MessaggioIn));
					xs.Serialize(xw, m);
					xw.Close();

					byte [] bMessaggioRichiesta = msRich.ToArray();

					byte [] bMessaggioRisposta = BLMainObj.ElaboraRichiesta(
						EngineMainForm._tspParams.ActiveOperatorCode,
						EngineMainForm._tspParams.ActiveUserCode,
						bMessaggioRichiesta);

					/*
					if (true)
					{
						string tmp = Encoding.UTF8.GetString(bMessaggioRisposta);
						MessageBox.Show(tmp);
					}
					*/

					string fileSchema = AppSettings.ToString("Bipex_Offerte.xsd", AppDomain.CurrentDomain.SetupInformation.ApplicationBase + @"Bipex_Offerte.xsd");

					MessageBoxIcon mbIcon = MessageBoxIcon.Asterisk;
					string sTestataMessaggio = "";
					string sMessaggioRisposta = "";

					ElaboraRisposta(fileSchema, bMessaggioRisposta, ref mbIcon, ref sTestataMessaggio, ref sMessaggioRisposta);
					
					MessageBox.Show(this.Owner, sMessaggioRisposta, sTestataMessaggio, MessageBoxButtons.OK, mbIcon);

				}
				catch (Exception exc)
				{
					MessageBox.Show(
						this.Owner, 
						String.Format(BipexResourceManager.GetResourceString("MSG_OFFERNOTCONFIRMED"), 
							sOp, 
							this.tbContract.Text, 
							exc.ToString()),
						BipexResourceManager.GetResourceString("MSG_POPUPWARNINGTITLE"),
						MessageBoxButtons.OK, MessageBoxIcon.Warning);
				}
				finally
				{
					Cursor.Current = Cursors.Default;
				}

				
				this.Close();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="fileSchema"></param>
		/// <param name="byteReq"></param>
		/// <param name="mbIcon"></param>
		/// <param name="sTestataMessaggio"></param>
		/// <param name="sMessaggioRisposta"></param>
		private void ElaboraRisposta(string fileSchema, byte[] byteReq, ref MessageBoxIcon mbIcon, ref string sTestataMessaggio, ref string sMessaggioRisposta)
		{
			string sIdOfferta;
			tipoStatoTransazione enStatoElab;
			tipoStatoAbbinamento enStatoAbb;
			tipoStatoPostAbbinamento enStatoPostAbb;

			XmlSchemaCollection sc = new XmlSchemaCollection();
			sc.Add(null, fileSchema);

			StreamReader sr = new StreamReader(new MemoryStream(byteReq), Encoding.UTF8);
			XmlValidatingReader xv = new XmlValidatingReader(new XmlTextReader(sr));

			xv.ValidationType = ValidationType.Schema;
			xv.Schemas.Add(sc);
			xv.ValidationEventHandler += new ValidationEventHandler(xr_ValidationEventHandler);

			if (true)
			{
				// Create an XmlAttributes to override the default root element.
				XmlAttributes myXmlAttributes = new XmlAttributes();

				// Create an XmlRootAttribute overloaded constructer 
				//and set its namespace.
				XmlRootAttribute myXmlRootAttribute = new XmlRootAttribute("Testata");
				myXmlRootAttribute.Namespace = "urn:XML-Bipex";

				// Set the XmlRoot property to the XmlRoot object.
				myXmlAttributes.XmlRoot = myXmlRootAttribute;
				XmlAttributeOverrides myXmlAttributeOverrides = new XmlAttributeOverrides();
   
				/* Add the XmlAttributes object to the 
				XmlAttributeOverrides object. */
				myXmlAttributeOverrides.Add(typeof(TestataMessaggioOut), myXmlAttributes);
			}

			XmlSerializer xsRisposta = new XmlSerializer(typeof (TransazioneOut));

			object elMessaggioOut = xv.NameTable.Add(typeof(MessaggioOut).Name);
			object elTransazioneOut = xv.NameTable.Add(typeof(TransazioneOut).Name);

			try
			{
				while (xv.Read())
				{
					if (xv.NodeType == XmlNodeType.Element)
					{
						object el = xv.Name;
						if (el == elMessaggioOut)
						{
							/*
							xv.GetAttribute("IdMessaggioOut");
							XmlConvert.ToDateTime(xv.GetAttribute("DataOraMessaggio"));
							xv.GetAttribute("Versione");
							*/
						}
						else if (el == elTransazioneOut)
						{
					
							TransazioneOut r = (TransazioneOut) xsRisposta.Deserialize(xv);

							enStatoElab = r.StatoTransazione;

							switch (enStatoElab)
							{
								case tipoStatoTransazione.TransazioneIn_Accettata:
								{
									// Operazioni di NEW, MODIFY, REVEAL, restituiscono enStatoElab, sIdOfferta, enStatoAbb, enStatoPostAbb
									// Operazioni di REVOKE, SUSPEND, restituiscono SOLO enStatoElab, sIdOfferta

									switch (formMode)
									{
										case enFormMode.NEW:
										{
											sIdOfferta = ((RispostaNuovaOfferta)r.Items[0]).IdOfferta;
											enStatoAbb = ((RispostaNuovaOfferta)r.Items[0]).StatoAbbinamento;
											enStatoPostAbb = ((RispostaNuovaOfferta)r.Items[0]).StatoPostAbbinamento;

											mbIcon = MessageBoxIcon.Information;
											sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPINFORMATIONTITLE");
											
											sMessaggioRisposta = String.Format(BipexResourceManager.GetResourceString("MSG_OFFERACCEPTED"), 
												formMode.ToString(), this.tbContract.Text, sIdOfferta)+"\n";

											if (enStatoAbb == tipoStatoAbbinamento.OffertaNonAbbinata)
												if (enStatoPostAbb == tipoStatoPostAbbinamento.OffertaCompatibile)
												{
													sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERCOMPATIBLE")+"\n");
												}
												else
												{
													mbIcon = MessageBoxIcon.Warning;
													sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPWARNINGTITLE");
													sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERNOTCOMPATIBLE")+"\n");
												}
											else
												if (enStatoAbb == tipoStatoAbbinamento.OffertaTotalmenteAbbinata)
												sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERTOTALLYMATCHED")+"\n");
											else
												if (enStatoAbb == tipoStatoAbbinamento.OffertaParzialmenteAbbinata)
												sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERPARTIALLYMATCHED")+"\n");

											break;
										}
										case enFormMode.MODIFY:
										{
											sIdOfferta = ((RispostaModificaOfferta)r.Items[0]).IdOfferta;
											enStatoAbb = ((RispostaModificaOfferta)r.Items[0]).StatoAbbinamento;
											enStatoPostAbb = ((RispostaModificaOfferta)r.Items[0]).StatoPostAbbinamento;

											mbIcon = MessageBoxIcon.Information;
											sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPINFORMATIONTITLE");

											sMessaggioRisposta = String.Format(BipexResourceManager.GetResourceString("MSG_OFFERACCEPTED"), 
												formMode.ToString(), this.tbContract.Text, sIdOfferta)+"\n";

											if (enStatoAbb == tipoStatoAbbinamento.OffertaNonAbbinata)
												if (enStatoPostAbb == tipoStatoPostAbbinamento.OffertaCompatibile)
												{
													sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERCOMPATIBLE")+"\n");
												}
												else
												{
													mbIcon = MessageBoxIcon.Warning;
													sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPWARNINGTITLE");
													sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERNOTCOMPATIBLE")+"\n");
												}
											else
												if (enStatoAbb == tipoStatoAbbinamento.OffertaTotalmenteAbbinata)
												sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERTOTALLYMATCHED")+"\n");
											else
												if (enStatoAbb == tipoStatoAbbinamento.OffertaParzialmenteAbbinata)
												sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERPARTIALLYMATCHED")+"\n");

											break;
										}
										case enFormMode.REVOKE:
										{
											sIdOfferta = ((RispostaRevocaOfferta)r.Items[0]).IdOfferta;

											mbIcon = MessageBoxIcon.Information;
											sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPINFORMATIONTITLE");

											sMessaggioRisposta = String.Format(BipexResourceManager.GetResourceString("MSG_OFFERACCEPTED"), 
												formMode.ToString(), this.tbContract.Text, sIdOfferta)+"\n";

											break;
										}
										case enFormMode.HIDE:
										{
											sIdOfferta = ((RispostaSospendiOfferta)r.Items[0]).IdOfferta;

											mbIcon = MessageBoxIcon.Information;
											sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPINFORMATIONTITLE");

											sMessaggioRisposta = String.Format(BipexResourceManager.GetResourceString("MSG_OFFERACCEPTED"), 
												formMode.ToString(), this.tbContract.Text, sIdOfferta)+"\n";

											break;
										}
										case enFormMode.REVEAL:
										{
											sIdOfferta = ((RispostaRivelaOfferta)r.Items[0]).IdOfferta;
											enStatoAbb = ((RispostaRivelaOfferta)r.Items[0]).StatoAbbinamento;
											enStatoPostAbb = ((RispostaRivelaOfferta)r.Items[0]).StatoPostAbbinamento;

											mbIcon = MessageBoxIcon.Information;
											sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPINFORMATIONTITLE");

											sMessaggioRisposta = String.Format(BipexResourceManager.GetResourceString("MSG_OFFERACCEPTED"), 
												formMode.ToString(), this.tbContract.Text, sIdOfferta)+"\n";

											if (enStatoAbb == tipoStatoAbbinamento.OffertaNonAbbinata)
												if (enStatoPostAbb == tipoStatoPostAbbinamento.OffertaCompatibile)
												{
													sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERCOMPATIBLE")+"\n");
												}
												else
												{
													mbIcon = MessageBoxIcon.Warning;
													sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPWARNINGTITLE");
													sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERNOTCOMPATIBLE")+"\n");
												}
											else
												if (enStatoAbb == tipoStatoAbbinamento.OffertaTotalmenteAbbinata)
												sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERTOTALLYMATCHED")+"\n");
											else
												if (enStatoAbb == tipoStatoAbbinamento.OffertaParzialmenteAbbinata)
												sMessaggioRisposta += (BipexResourceManager.GetResourceString("MSG_OFFERPARTIALLYMATCHED")+"\n");

											break;
										}
									}
									break;
								}
								case tipoStatoTransazione.TransazioneIn_Rigettata:
								{
									mbIcon = MessageBoxIcon.Warning;
									sTestataMessaggio = BipexResourceManager.GetResourceString("MSG_POPUPWARNINGTITLE");

									short RC = Convert.ToInt16(((ErroreRichiesta)r.Items[0]).Codice);

									/* Ecco la Lista fornita da P.Muscar� (12.10.2005 Pom.)
									
									01         Offerta_Nuova: Operatore non abilitato al mercato
									02         Offerta_Nuova: Prezzo unitario < 0
									03         Offerta_Nuova: Prezzo unitario fuori range
									04         Offerta_Nuova: Sessione non aperta
									05         Offerta_Nuova: Quantita richiesta <= 0
									06         Offerta_Nuova: OffertaOTC incongruente
									07         Offerta_Nuova: Offerta OTC gia presente
									08         Offerta_Nuova: Offerta OTC con prezzo unitario = 0
									09         Offerta_Nuova: Prezzo di riferimento non trovato
									24         Offerta_Nuova: Offerta OTC con diverso prezzo e/o quantita''.
									10         Offerta_Modifica: Sessione non aperta
									11         Offerta_Modifica: Offerta inesistente o non modificabile
									12         Offerta_Modifica: l''offerta non puo'' diventare a mercato
									13         Offerta_Modifica: l''offerta deve rimanere a mercato
									14         Offerta_Modifica: Prezzo unitario < 0
									15         Offerta_Modifica: Qty richiesta < 0
									20         Offerta_Modifica: Nome Contratto non trovato.
									16         Offerta_Revoca: Offerta inesistente o non revocabile
									17         Offerta_Revoca: Sessione non aperta
									22         Offerta_Revoca: Nome Contratto non trovato.
									18         Offerta_Nascondi: Offerta inesistente o non revocabile
									19         Offerta_Nascondi: Sessione non aperta
									21         Offerta_Nascondi: Nome Contratto non trovato.
									23         Offerta_Rivela: Nome Contratto non trovato.
									25         Offerta_Rivela: Offerta inesistente o non revocabile
									26         Offerta_Rivela: Sessione non aperta
									
									*/

									string sReasonAsText = BipexResourceManager.GetResourceString("MSG_OFFEROPERATIONREJECTED"+RC.ToString("00"));
									sMessaggioRisposta = String.Format(BipexResourceManager.GetResourceString("MSG_OFFERREJECTED")+"\n", 
										formMode.ToString(), this.tbContract.Text, sReasonAsText, RC.ToString("00"));
									
									break;
								}
							}

							// Per uscire subito dal while di lettura degli elements... dato che dopo avere
							// incontrato il tag Risposta non mi interessa il resto del contenuto...
							break;
						}
					}
				}
			}
			catch (Exception excp)
			{
				// cosi` esco subito dal Deserialize
				throw excp;
			}
		}

		private void xr_ValidationEventHandler(object v, ValidationEventArgs e)
		{
			Exception excp = new Exception("Eccezione Catturata da ValidationEventHandler, Message <" + e.Message + ">");
			// cosi` esco subito dal Deserialize
			throw excp;
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void cbBuy_CheckedChanged(object sender, System.EventArgs e)
		{
			// Toggle...
			if (this.cbBuy.Checked)
				this.cbSell.Checked = false;
		}

		private void cbSell_CheckedChanged(object sender, System.EventArgs e)
		{
			// Toggle...
			if (this.cbSell.Checked == true)
				this.cbBuy.Checked = false;
		}

		// Le Offerte a Mercato devono essere SUBITO SODDISFATTE, almeno parzialmente.
		// Se su di un contratto si tenta di piazzare una offerta a mercato e non ci sono
		// offerte reciproche, l'offerta � dichiarata NON COMPATIBILE e non � inserita nel
		// Book.
		// Una offerta PARZIALMENTE SODDISFATTA rimane nel Book con un prezzo uguale a
		// quello del parziale abbinamento.
		// Per cui una offerta nata come offerta a mercato ma PARZIALMENTE SODDISFATTA 
		// si trova nel Book con un prezzo uguale a quello del parziale abbinamento e per
		// gli eventuali abbinamenti successivi � da considerarsi a tutti gli effetti
		// una offerta con Limite di Prezzo e non pi� una offerta a Mercato
		// (Il Flag per� risponder� SEMPRE E COMUNQUE Offerta a Mercato = true)
		
		private void cbPriceLimit_CheckedChanged(object sender, System.EventArgs e)
		{
			// Toggle...
			if (this.cbPriceLimit.Checked == true)
				this.cbPriceMarket.Checked = false;

			if (this.cbPriceMarket.Checked == true)
			{
				double dPrice = 0;
				this.tbPrice.Text = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
				ResetTotalOnQtyOrPriceChange();
			}
		}

		private void cbPriceMarket_CheckedChanged(object sender, System.EventArgs e)
		{
			// Toggle...
			if (this.cbPriceMarket.Checked == true)
				this.cbPriceLimit.Checked = false;

			if (this.cbPriceMarket.Checked == true)
			{
				double dPrice = 0;
				this.tbPrice.Text = dPrice.ToString(BipexFormSettings.FmtForPrice, Thread.CurrentThread.CurrentCulture);
				ResetTotalOnQtyOrPriceChange();
			}
		}

		private void cbIsOTC_CheckedChanged(object sender, System.EventArgs e)
		{
			if (this.cbIsOTC.Checked)
			{
				this.cbOTCOperator.Enabled = true;
				this.tbOTCCode.Enabled = true;
			}
			else
			{
				this.cbOTCOperator.SelectedIndex = 0;
				this.cbOTCOperator.Enabled = false;
				this.tbOTCCode.Text = "";
				this.tbOTCCode.Enabled = false;
			}
		}

	}
}
