using System.Drawing;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per BipexFormSettings.
	/// </summary>
	public class BipexFormSettings
	{
		public BipexFormSettings()
		{
			//
			// TODO: aggiungere qui la logica del costruttore
			//
		}
		
		public static readonly string FmtForPrice = "#,###,##0.00";
		public static readonly string FmtForQty = "#,##0";

		public static readonly string FmtForTime = "hh:mm:ss";
		public static readonly string FmtForDate = "d";
		public static readonly string FmtForDateWithDayOfWeek = "dd/MM/yyyy dddd";
		public static readonly string FmtForTimeWithAMPM = "hh:mm:ss tt";

		public static readonly string FmtForGenericString = "G";

		public static readonly float ChangeFontIncrement = 1;
		public static readonly float ChangeFontMinSize = 5;
		public static readonly float ChangeFontMaxSize = 100;

		public static Color AlternatingBackColor = Color.FromKnownColor(KnownColor.ControlLight);
		public static Color BackColor = Color.FromKnownColor(KnownColor.Window);
		public static Color ForeColor = Color.FromKnownColor(KnownColor.WindowText);
		public static Color GridLineColor = Color.FromKnownColor(KnownColor.Control);
		public static Color HeaderBackColor = Color.FromKnownColor(KnownColor.Control);
		public static Color HeaderForeColor = Color.FromKnownColor(KnownColor.ControlText);
		public static Color LinkColor = Color.FromKnownColor(KnownColor.HotTrack);
		public static Color SelectionBackColor = Color.FromKnownColor(KnownColor.ControlDark);
		public static Color SelectionForeColor = Color.FromKnownColor(KnownColor.ActiveCaptionText);

	}
}
