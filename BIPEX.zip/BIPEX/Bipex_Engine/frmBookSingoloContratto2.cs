using System;
using System.Collections;
using System.Data;
using System.Drawing;
using System.ComponentModel;
using System.Drawing.Design;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using Delta;

namespace Bipex_Engine
{
	/// <summary>
	/// Summary description for frmBookSingoloContratto.
	/// </summary>
	public class frmBookSingoloContratto : System.Windows.Forms.Form, IDocumentStreamerViewer
	{
		private System.Windows.Forms.Splitter split;
		private System.Windows.Forms.DataGrid dgBook;
		private System.Data.DataSet dsBookSingolo;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		DataRecordList _bs;
		DataRecordList _of;

		BipexSubject _sBS;
		BipexSubject _sOF;
		private System.Windows.Forms.ListBox lbTestataContratto;

		string _sThisFormTitle = string.Empty;

		public frmBookSingoloContratto()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lbTestataContratto = new System.Windows.Forms.ListBox();
			this.split = new System.Windows.Forms.Splitter();
			this.dgBook = new System.Windows.Forms.DataGrid();
			this.dsBookSingolo = new System.Data.DataSet();
			((System.ComponentModel.ISupportInitialize)(this.dgBook)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dsBookSingolo)).BeginInit();
			this.SuspendLayout();
			// 
			// lbTestataContratto
			// 
			this.lbTestataContratto.CausesValidation = false;
			this.lbTestataContratto.Dock = System.Windows.Forms.DockStyle.Top;
			this.lbTestataContratto.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.lbTestataContratto.Location = new System.Drawing.Point(0, 0);
			this.lbTestataContratto.Name = "lbTestataContratto";
			this.lbTestataContratto.Size = new System.Drawing.Size(229, 368);
			this.lbTestataContratto.TabIndex = 0;
			this.lbTestataContratto.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.lbTestataContratto_MeasureItem);
			this.lbTestataContratto.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lbTestataContratto_DrawItem);
			// 
			// split
			// 
			this.split.Cursor = System.Windows.Forms.Cursors.HSplit;
			this.split.Dock = System.Windows.Forms.DockStyle.Top;
			this.split.Location = new System.Drawing.Point(0, 368);
			this.split.Name = "split";
			this.split.Size = new System.Drawing.Size(229, 3);
			this.split.TabIndex = 1;
			this.split.TabStop = false;
			this.split.Visible = false;
			// 
			// dgBook
			// 
			this.dgBook.AlternatingBackColor = System.Drawing.SystemColors.ControlLight;
			this.dgBook.CaptionVisible = false;
			this.dgBook.DataMember = "";
			this.dgBook.DataSource = this.dsBookSingolo;
			this.dgBook.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgBook.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgBook.Location = new System.Drawing.Point(0, 371);
			this.dgBook.Name = "dgBook";
			this.dgBook.ReadOnly = true;
			this.dgBook.RowHeaderWidth = 15;
			this.dgBook.SelectionBackColor = System.Drawing.SystemColors.ControlDark;
			this.dgBook.Size = new System.Drawing.Size(229, 79);
			this.dgBook.TabIndex = 2;
			// 
			// dsBookSingolo
			// 
			this.dsBookSingolo.DataSetName = "NewDataSet";
			this.dsBookSingolo.Locale = new System.Globalization.CultureInfo("it-IT");
			// 
			// frmBookSingoloContratto
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(229, 450);
			this.Controls.Add(this.dgBook);
			this.Controls.Add(this.split);
			this.Controls.Add(this.lbTestataContratto);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmBookSingoloContratto";
			this.Text = "Book";
			this.Load += new System.EventHandler(this.frmBookSingoloContratto2_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgBook)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dsBookSingolo)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frmBookSingoloContratto2_Load(object sender, System.EventArgs e)
		{
			// Memorizzo il Title del form stabilito a design time perche'
			// a run time lo devo concatenare con altre info...
			_sThisFormTitle = this.Text;

			DataSetMerger.CreateTable(dsBookSingolo, "OF", typeof(OffertaDR));

			ChangeContract(string.Empty);

			SetDataGridTableStyles(this.dgBook, "OF");

			this.dgBook.DataSource = dsBookSingolo;
			this.dgBook.DataMember = "OF";
		}

		private void ChangeContract(string contract)
		{
			_bs = new DataRecordList();
			_of = new DataRecordList();

			_sBS = new BipexSubject();
			_sOF = new BipexSubject();

			_sBS.SubjectType = "BS";
			_sBS.SubjectSubType = contract;
			_sBS.Version = _bs.Version;
			_sBS.DataDiMercato = DateTime.Now.Date;

			_sOF.SubjectType = "OF";
			_sOF.SubjectSubType = contract;
			_sOF.Version = _bs.Version;
			_sOF.DataDiMercato = DateTime.Now.Date;

			DataTable tOF = dsBookSingolo.Tables["OF"];
			tOF.Rows.Clear();

			this.Text = string.Format(_sThisFormTitle, contract);
		}

		#region IDocumentStreamerViewer Members

		private delegate BipexSubject [] GetBipexSubjectDelegate();
		public BipexSubject [] GetBipexSubject()
		{
			if (this.InvokeRequired)
			{
				GetBipexSubjectDelegate d = new GetBipexSubjectDelegate(GetBipexSubject);
				return (BipexSubject[]) this.Invoke(d);
			}
			else
			{
				if (this.Visible && _sBS != null && _sBS.SubjectSubType.Length > 0)
					return new BipexSubject[] {_sBS, _sOF };
				else
					return new BipexSubject[0];
			}
		}

		private delegate void OnBipexResponceDelegate(BipexSubject [] req, DataRecordList [] resp);
		public void OnBipexResponse(BipexSubject [] req, DataRecordList [] resp)
		{
			if (this.InvokeRequired)
			{
				OnBipexResponceDelegate d = new OnBipexResponceDelegate(OnBipexResponse);
				BeginInvoke(d, new object[] { req, resp });
			}
			else
			{
				if (_sBS.SubjectType == req[0].SubjectType &&
					_sBS.SubjectSubType == req[0].SubjectSubType)
				{
					_bs.Merge(resp[0]);
					_sBS.Version = _bs.Version;

					if (_bs.Count > 0)
					{
						BookSingoloContrattoDR dr = (BookSingoloContrattoDR) _bs[0];
						this.Text = string.Format(_sThisFormTitle, dr.Contract);
						UpdateTestaContrattoItem(lbTestataContratto.Items, dr);
					}
				}

				if (_sOF.SubjectType == req[1].SubjectType &&
					_sOF.SubjectSubType == req[1].SubjectSubType)
				{
					_of.Merge(resp[1]);
					_sOF.Version = _of.Version;
					DataSetMerger.Merge(this.dsBookSingolo.Tables["OF"], _of, typeof(OffertaDR));

					if (this.dgBook.Visible == false)
					{
						this.dgBook.Show();	
						this.lbTestataContratto.Show();	
						this.split.Show();
					}
				}
			}
		}

		private void UpdateTestaContrattoItem(ListBox.ObjectCollection a, BookSingoloContrattoDR drBS)
		{
			if (a.Count == 0)
			{
				object [] ro = new object[17];
				for (int k = 0; k < 17; ++k) ro[k] = string.Empty;
 				a.AddRange(ro);
			}

			int i = 0;
			SetString(a, i++, "General");
			SetString(a, i++, string.Format("\tContract\t{0}",      drBS.Contract));
			SetString(a, i++, string.Format("\tHours\t{0}",         drBS.Hours.ToString(BipexFormSettings.FmtForQty)));
			SetString(a, i++, string.Format("\tTrading from\t{0}",  drBS.TradingFrom.ToString(BipexFormSettings.FmtForDate)));

			SetString(a, i++, string.Format("\tTrading to\t{0}",    drBS.TradingTo.ToString(BipexFormSettings.FmtForDate)));
			SetString(a, i++, string.Format("\tDelivery from\t{0}", drBS.DeliveryFrom.ToString(BipexFormSettings.FmtForDate)));
			SetString(a, i++, string.Format("\tDelivery to\t{0}",   drBS.DeliveryTo.ToString(BipexFormSettings.FmtForDate)));

			SetString(a, i++, "Trading");
			if (drBS.IsNotNull("LastPrice"))
			{
				SetString(a, i++, string.Format("\tLast Price\t{0}",    drBS.LastPrice.ToString(BipexFormSettings.FmtForPrice)));
				SetString(a, i++, string.Format("\tLast Qty\t{0}",      drBS.LastQty.ToString(BipexFormSettings.FmtForQty)));
				SetString(a, i++, string.Format("\tLast Time\t{0}",     drBS.LastTime.ToString(BipexFormSettings.FmtForTime)));

				SetString(a, i++, string.Format("\tMax Price\t{0}",     drBS.MaxPrice.ToString(BipexFormSettings.FmtForPrice)));
				SetString(a, i++, string.Format("\tMin Price\t{0}",     drBS.MinPrice.ToString(BipexFormSettings.FmtForPrice)));

				SetString(a, i++, string.Format("\tVolume\t{0}",        drBS.Volume.ToString(BipexFormSettings.FmtForQty)));

				SetString(a, i++, string.Format("\tConv Price\t{0}",   drBS.ConvPrice.ToString(BipexFormSettings.FmtForPrice)));
				SetString(a, i++, string.Format("\tOff Price\t{0}",    drBS.OffPrice.ToString(BipexFormSettings.FmtForPrice)));
				SetString(a, i++, string.Format("\tRef Price\t{0}",    drBS.RefPrice.ToString(BipexFormSettings.FmtForPrice)));

			}
			else
			{
				SetString(a, i++, string.Format("\tLast Price\t{0}",    " "));
				SetString(a, i++, string.Format("\tLast Qty\t{0}",      " "));
				SetString(a, i++, string.Format("\tLast Time\t{0}",     " "));

				SetString(a, i++, string.Format("\tMax Price\t{0}",     " "));
				SetString(a, i++, string.Format("\tMin Price\t{0}",     " "));

				SetString(a, i++, string.Format("\tVolume\t{0}",        " "));

				SetString(a, i++, string.Format("\tConv Price\t{0}",   " "));
				SetString(a, i++, string.Format("\tOff Price\t{0}",    " "));
				SetString(a, i++, string.Format("\tRef Price\t{0}",    " "));
			}
		}

		private void SetString(ListBox.ObjectCollection a, int i, string newString)
		{
			if (a[i].ToString() != newString)
				a[i] = newString;
		}


		private delegate void OnTxErrorDelegate(string errorMessage);
		public void OnError(string errorMessage)
		{
			if (this.InvokeRequired)
			{
				OnTxErrorDelegate d = new OnTxErrorDelegate(OnError);
				this.BeginInvoke(d, new object[] { errorMessage });
			}
			else
			{
				// qui fare qualunque cosa: basta che non sia bloccante.
			}
		}

		#endregion

		private static void SetDataGridTableStyles(DataGrid dg, string sMappingName)
		{
			dg.TableStyles.Clear();

			DataGridTableStyle dgsBook = new DataGridTableStyle();

			// !!!ATTENZIONE!!!
			// WORKAROUND PER RISOLUZIONE PROBLEMA
			// SE SI RIDEFINISCE UN PROPRIO TABLESTYLE 
			// PER VISUALIZZARE UN DATATABLE,
			// OCCORRE RIASSEGNARE ESPLICITAMENTE I COLORI!!!,
			// altrimenti ad esempio impostazioni come l'alternate
			// color vanno perdute...
			dgsBook.AlternatingBackColor = BipexFormSettings.AlternatingBackColor;
			dgsBook.BackColor = BipexFormSettings.BackColor;
			dgsBook.ForeColor = BipexFormSettings.ForeColor;
			dgsBook.GridLineColor = BipexFormSettings.GridLineColor;
			dgsBook.HeaderBackColor = BipexFormSettings.HeaderBackColor;
			dgsBook.HeaderForeColor = BipexFormSettings.HeaderForeColor;
			dgsBook.LinkColor = BipexFormSettings.LinkColor;
			dgsBook.SelectionBackColor = BipexFormSettings.SelectionBackColor;
			dgsBook.SelectionForeColor = BipexFormSettings.SelectionForeColor;

			dgsBook.AllowSorting = false;
			dgsBook.RowHeadersVisible = false;

			dgsBook.MappingName = sMappingName;

			DataGridAlignedTextBoxColumn[] dgcBook = new DataGridAlignedTextBoxColumn[4];
			for (int i = 0; i < dgcBook.Length; ++i)
				dgcBook[i] = new DataGridAlignedTextBoxColumn();
			
			int index = 0;

			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = "BidPrice";
			dgcBook[index].HeaderText = "Bid Price";
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].Width = 60;
			index += 1;

			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = "BidQty";
			dgcBook[index].HeaderText = "Bid Qty";
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].Width = 50;
			index += 1;

			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = "AskQty";
			dgcBook[index].HeaderText = "Ask Qty";
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForQty;
			dgcBook[index].Width = 50;
			index += 1;

			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = "AskPrice";
			dgcBook[index].HeaderText = "Ask Price";
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Right; // Data Alignment
			dgcBook[index].Format = BipexFormSettings.FmtForPrice;
			dgcBook[index].Width = 60;
			index += 1;

			dgsBook.GridColumnStyles.AddRange(dgcBook);
			dg.TableStyles.Add(dgsBook);
		}

		private class DataGridAlignedTextBoxColumn : DataGridTextBoxColumn
		{
			protected bool bColorSetInDerivedClass = false;
			private HorizontalAlignment dataAlignment = HorizontalAlignment.Center;

			/// <summary>
			/// La proprieta' serve a gestire l'allineamento del dato nella cella.
			/// </summary>
			public HorizontalAlignment DataAlignment
			{
				get { return this.dataAlignment; }
				set { this.dataAlignment = value; }
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
				int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// !!!ATTENZIONE!!!
				// WORKAROUND PER RISOLUZIONE PROBLEMA
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// (per default, il click sulla barra a sz delle celle fa il paint mentre
				// il click sulle celle stesse non fa il paint!!!)

				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum & !bColorSetInDerivedClass)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				// Questa e' la riga corrente...
				DataRow dr = ((DataView) cm.List)[rowNum].Row;

				// ...e questi sono i valori delle celle della riga corrente...
				string strCellText = "";
				if (dr[this.MappingName] != System.Convert.DBNull)
					// Converto il valore in stringa per poterlo riscrivere, devo
					// tenere conto dell'attributo di formattazione eventualmente
					// impostato dall'utente del datagrid...
					strCellText = FormatObjectAsString(dr[this.MappingName], this.Format);

				// Determino l'allineamento in funzione della property impostata dall'utente della classe
				StringFormat stringFormat = new StringFormat();
				switch (DataAlignment)
				{
					case HorizontalAlignment.Center:
						stringFormat.Alignment = StringAlignment.Center;
						break;
					case HorizontalAlignment.Left:
						stringFormat.Alignment = StringAlignment.Near;
						break;
					case HorizontalAlignment.Right:
						stringFormat.Alignment = StringAlignment.Far;
						break;
				}

				// Disegno BackGround sul rect da refreshare...
				g.FillRectangle(myBackBrush, bounds);
				// Calcolo nuovo rect...
				RectangleF CellBounds = new RectangleF(bounds.Left, bounds.Top + 3, bounds.Width, bounds.Height);
				// Refresh del contenuto della cella...
				g.DrawString(strCellText, this.DataGridTableStyle.DataGrid.Font, myForeBrush, CellBounds, stringFormat);

			}

			private int SelectedRow = -1;

			protected override void Edit(CurrencyManager source, int rowNum, Rectangle bounds, bool readOnly, string instantText, bool cellIsVisible)
			{
				// Per evitare crash testare che ci sia una selezione valida
				// prima di fare la deselezione...
				if (SelectedRow > -1 && SelectedRow < source.List.Count + 1)
					this.DataGridTableStyle.DataGrid.UnSelect(SelectedRow);
				SelectedRow = rowNum;
				this.DataGridTableStyle.DataGrid.Select(SelectedRow);
			}

			private string FormatObjectAsString(object o, string Format)
			{
				if (o.GetType() == typeof (DateTime))
				{
					DateTime tmp = Convert.ToDateTime(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format);
				}
				else if (o.GetType() == typeof (double))
				{
					double tmp = Convert.ToDouble(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format);
				}
				else if (o.GetType() == typeof (decimal))
				{
					decimal tmp = Convert.ToDecimal(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format);
				}
				if (o.GetType() == typeof (short))
				{
					short tmp = Convert.ToInt16(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format);
				}
				if (o.GetType() == typeof (int))
				{
					int tmp = Convert.ToInt32(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format);
				}
				if (o.GetType() == typeof (long))
				{
					long tmp = Convert.ToInt64(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format);
				}
				else
				{
					// Type non gestito con formattazione specifica, richiamo il metodo
					// standard di conversione in stringa...
					return o.ToString();
				}
			}
		}



		public void SetCurrentContract(string contract)
		{
			this.ChangeContract(contract);

			this.dgBook.Hide();	
			this.lbTestataContratto.Hide();	
			this.split.Hide();
		}

		int lbTestataContratto_xValue = 0;

		private void lbTestataContratto_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
		{
			ListBox lb = (ListBox) sender;

			if ((e.Index & 1) > 0)
			{
				Brush brush = new SolidBrush(this.dgBook.AlternatingBackColor);
				e.Graphics.FillRectangle(brush, e.Bounds);
				brush.Dispose();
			}
			else
			{
				Brush brush = new SolidBrush(this.dgBook.BackColor);
				e.Graphics.FillRectangle(brush, e.Bounds);
				brush.Dispose();
			}

			int xStart = 15;


			// Create a new Brush and initialize to a Black colored brush by default.
			Brush textBrush = Brushes.Black;

			using (StringFormat sf = new StringFormat())
			{
				sf.Alignment = StringAlignment.Near;
				sf.LineAlignment = StringAlignment.Center;

				string s = lb.Items[e.Index].ToString();
				if (s.Length > 0 && s[0] != '\t')
				{
					int raggio = 3;
					Rectangle rectPallino = new Rectangle(e.Bounds.X + xStart/2 - raggio,  e.Bounds.Y + e.Bounds.Height / 2 - raggio, 2*raggio, 2*raggio+1);
					e.Graphics.FillRectangle(Brushes.Black, rectPallino) ;

					Rectangle rDescr = new Rectangle(e.Bounds.X + xStart, e.Bounds.Y, e.Bounds.Width,  e.Bounds.Height );

					e.Graphics.DrawString(s, e.Font, Brushes.Blue, rDescr, sf);
				}
				else
				{
					string [] ss = s.Split('\t');

					string descr = ss[1];
					string val = ss[2];

					Rectangle rDescr = new Rectangle(e.Bounds.X + xStart, e.Bounds.Y, e.Bounds.Width,  e.Bounds.Height);
					e.Graphics.DrawString(descr, e.Font, textBrush, rDescr, sf);

					if (lbTestataContratto_xValue == 0)
					{
						int m = lbTestataContratto_CalculateXStart(e.Graphics, e.Font, sf);
						lbTestataContratto_xValue = xStart + m + 5;
					}

			
					using (Font f = new Font(e.Font.FontFamily, e.Font.Size, FontStyle.Bold, e.Font.Unit))
					{
						Rectangle rValue = new Rectangle(e.Bounds.X + lbTestataContratto_xValue, e.Bounds.Y, e.Bounds.Width,  e.Bounds.Height);

						// sf.Alignment = StringAlignment.Far;
						e.Graphics.DrawString(val, f, textBrush, rValue, sf);
					}
				}
			}

			if (((e.State & DrawItemState.Focus) == DrawItemState.Focus) && 
				((e.State & DrawItemState.NoFocusRect) != DrawItemState.NoFocusRect))
			{
				ControlPaint.DrawFocusRectangle(e.Graphics, e.Bounds, Color.Black, Color.White);
			}
		}

		private int lbTestataContratto_CalculateXStart(Graphics gr, Font f, StringFormat sf)
		{
			int r = 0;
			foreach (string s in lbTestataContratto.Items)
			{
				if (s.Length > 0 && s[0] != '\t')
					continue;

				string [] ss = s.Split('\t');

				string descr = ss[1];

				SizeF sz = gr.MeasureString(descr, f, 0, sf);
				r = Math.Max(r, (int)sz.Width);
			}

			return r;
		}

		private void lbTestataContratto_MeasureItem(object sender, System.Windows.Forms.MeasureItemEventArgs e)
		{
			// Cast the sender object back to ListBox type.
			ListBox theListBox = (ListBox) sender;

			// Get the string contained in each item.
			string s = (string) theListBox.Items[e.Index];

			if (s.Length > 0 && s[0] != '\t')
				e.ItemHeight += 15; // header
			else
				e.ItemHeight += 5;	// descr - valore
		}
	}
}
