using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using GME.Remoting;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmShowCommunications.
	/// </summary>
	public class frmShowCommunications : System.Windows.Forms.Form
	{
		/// <summary>
		/// Oggetti BL utilizzati dal form
		/// </summary>
		IDailyComunications BLMainObj = (IDailyComunications) RemotingHelper.GetObject(typeof(IDailyComunications));

		private EngineMainForm.TradingSessionParameters tspParams;

		private int iCurrentCommunication;
		private System.Windows.Forms.RichTextBox rtbComm;
		private System.Windows.Forms.Button btnSaveComm;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.SaveFileDialog dlgSaveAsRTF;
		private System.Windows.Forms.Button btnPrevComm;
		private System.Windows.Forms.Button btnNextComm;
		private System.Windows.Forms.TextBox tbToday;
		private System.Windows.Forms.Label lbToday;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmShowCommunications(EngineMainForm.TradingSessionParameters atsp)
		{
			tspParams = atsp;
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmShowCommunications));
			this.rtbComm = new System.Windows.Forms.RichTextBox();
			this.btnSaveComm = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.dlgSaveAsRTF = new System.Windows.Forms.SaveFileDialog();
			this.btnPrevComm = new System.Windows.Forms.Button();
			this.btnNextComm = new System.Windows.Forms.Button();
			this.tbToday = new System.Windows.Forms.TextBox();
			this.lbToday = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// rtbComm
			// 
			this.rtbComm.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.rtbComm.Location = new System.Drawing.Point(8, 64);
			this.rtbComm.Name = "rtbComm";
			this.rtbComm.ReadOnly = true;
			this.rtbComm.Size = new System.Drawing.Size(584, 168);
			this.rtbComm.TabIndex = 2;
			this.rtbComm.Text = "<You Have No Communications from BIPEX>";
			// 
			// btnSaveComm
			// 
			this.btnSaveComm.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnSaveComm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnSaveComm.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveComm.Image")));
			this.btnSaveComm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSaveComm.Location = new System.Drawing.Point(304, 240);
			this.btnSaveComm.Name = "btnSaveComm";
			this.btnSaveComm.Size = new System.Drawing.Size(112, 32);
			this.btnSaveComm.TabIndex = 5;
			this.btnSaveComm.Text = "&Save Comm.";
			this.btnSaveComm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSaveComm.Click += new System.EventHandler(this.btnSaveComm_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
			this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCancel.Location = new System.Drawing.Point(424, 240);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(112, 32);
			this.btnCancel.TabIndex = 6;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnPrevComm
			// 
			this.btnPrevComm.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnPrevComm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnPrevComm.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevComm.Image")));
			this.btnPrevComm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPrevComm.Location = new System.Drawing.Point(64, 240);
			this.btnPrevComm.Name = "btnPrevComm";
			this.btnPrevComm.Size = new System.Drawing.Size(112, 32);
			this.btnPrevComm.TabIndex = 3;
			this.btnPrevComm.Text = "&Prev. Comm.";
			this.btnPrevComm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnPrevComm.Click += new System.EventHandler(this.btnPrevComm_Click);
			// 
			// btnNextComm
			// 
			this.btnNextComm.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnNextComm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnNextComm.Image = ((System.Drawing.Image)(resources.GetObject("btnNextComm.Image")));
			this.btnNextComm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnNextComm.Location = new System.Drawing.Point(184, 240);
			this.btnNextComm.Name = "btnNextComm";
			this.btnNextComm.Size = new System.Drawing.Size(112, 32);
			this.btnNextComm.TabIndex = 4;
			this.btnNextComm.Text = "&Next Comm.";
			this.btnNextComm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnNextComm.Click += new System.EventHandler(this.btnNextComm_Click);
			// 
			// tbToday
			// 
			this.tbToday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tbToday.Location = new System.Drawing.Point(248, 8);
			this.tbToday.Name = "tbToday";
			this.tbToday.ReadOnly = true;
			this.tbToday.Size = new System.Drawing.Size(176, 26);
			this.tbToday.TabIndex = 1;
			this.tbToday.Text = "";
			// 
			// lbToday
			// 
			this.lbToday.Location = new System.Drawing.Point(184, 8);
			this.lbToday.Name = "lbToday";
			this.lbToday.Size = new System.Drawing.Size(60, 23);
			this.lbToday.TabIndex = 7;
			this.lbToday.Text = "Today is:";
			this.lbToday.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// frmShowCommunications
			// 
			this.AcceptButton = this.btnCancel;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(600, 278);
			this.Controls.Add(this.lbToday);
			this.Controls.Add(this.tbToday);
			this.Controls.Add(this.btnNextComm);
			this.Controls.Add(this.btnPrevComm);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnSaveComm);
			this.Controls.Add(this.rtbComm);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Name = "frmShowCommunications";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Communications from BIPEX";
			this.Load += new System.EventHandler(this.frmShowCommunications_Load);
			this.Activated += new System.EventHandler(this.frmShowCommunications_Activated);
			this.ResumeLayout(false);

		}
		#endregion

		private bool bLoaded = false;
		private void frmShowCommunications_Load(object sender, System.EventArgs e)
		{
			tbToday.Text = DateTime.Today.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture);

			// Se siamo su questo form c'� almeno una comunicazione per l'utente
			// attivo (l'indice parte da 1)...

			iCurrentCommunication = 1;
			ShowCommunication(iCurrentCommunication);
		
		}

		/// <summary>
		/// Visualizza la comunicazione corrente della lista, abilita / disabilita i PBs
		/// di scorrimento della lista stessa in funzione dell'indice della comunicazione corrente 
		/// nella lista stessa
		/// </summary>
		private void ShowCommunication(int i)
		{
			if (i <= BLMainObj.GetDailyComunicationsCount(DateTime.Now))
			{
				byte[] tmpMessage = BLMainObj.GetDailyComunication(DateTime.Now, i);
				if (tmpMessage != null)
				{
					this.rtbComm.LoadFile(new MemoryStream(tmpMessage), RichTextBoxStreamType.RichText);
				}

				if (i+1 <= BLMainObj.GetDailyComunicationsCount(DateTime.Now))
					this.btnNextComm.Enabled = true;
				else
					this.btnNextComm.Enabled = false;

				if (i > 1)
					this.btnPrevComm.Enabled = true;
				else
					this.btnPrevComm.Enabled = false;
			
			}
		}

		private void frmShowCommunications_Activated(object sender, System.EventArgs e)
		{
			if (!bLoaded)
			{
				bLoaded = true;
				this.btnCancel.Focus();
			}
		}

		private void btnPrevComm_Click(object sender, System.EventArgs e)
		{
			iCurrentCommunication--;
			ShowCommunication(iCurrentCommunication);
		}

		private void btnNextComm_Click(object sender, System.EventArgs e)
		{
			iCurrentCommunication++;
			ShowCommunication(iCurrentCommunication);
		}

		private void btnSaveComm_Click(object sender, System.EventArgs e)
		{
			dlgSaveAsRTF.CreatePrompt = true;
			dlgSaveAsRTF.DefaultExt = "rtf";
			dlgSaveAsRTF.Filter = "rtf files (*.rtf)|*.rtf|All files (*.*)|*.*";
			dlgSaveAsRTF.FilterIndex = 1;
			dlgSaveAsRTF.RestoreDirectory = true;
			dlgSaveAsRTF.OverwritePrompt = true;
			dlgSaveAsRTF.Title = "Save Message";
			if (dlgSaveAsRTF.ShowDialog() == DialogResult.OK && dlgSaveAsRTF.FileName.Length > 0)
			{
				try
				{
					// Save the contents of the RichTextBox into the file.
					this.rtbComm.SaveFile(dlgSaveAsRTF.FileName, RichTextBoxStreamType.RichText);
				}
				catch (Exception ex)
				{
					MessageBox.Show(this.Owner, String.Format(BipexResourceManager.GetResourceString("MSG_CANNOTWRITEONFILE"), ex.ToString()), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				}
			}
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

	}
}
