using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using Bipex_BLInterface;
using GME.Remoting;
using SPDriver;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmCalendarioDelivery.
	/// </summary>
	public class frmCalendarioDelivery : System.Windows.Forms.Form
	{
		/// <summary>
		/// Oggetti BL utilizzati dal form
		/// </summary>
		ISessioneMercato BLMainObj = (ISessioneMercato) RemotingHelper.GetObject(typeof(ISessioneMercato));
		
		private DataSet dsMainDG = null;
		private System.Windows.Forms.DataGrid dgCalendarioDelivery;
		private string _sThisFormTitle;

		private string _DataInizioOraLegaleAsString;
		private string _DataFineOraLegaleAsString;

		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmCalendarioDelivery()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			// Memorizzo il Title del form stabilito a design time perche'
			// a run time lo devo concatenare con altre info...
			_sThisFormTitle = this.Text;

			// IMPOSTO GIORNI DI ENTRATA IN VIGORE / TERMINE DEL PERIODO DELL'ORA LEGALE NELLE VAR.MEMBRO
			// CHE MI SERVIRANNO PER DISEGNARE LA COLONNA 25...
			DaylightTime dlt = System.TimeZone.CurrentTimeZone.GetDaylightChanges(System.DateTime.Today.Year);
			_DataInizioOraLegaleAsString = dlt.Start.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture);
			_DataFineOraLegaleAsString = dlt.End.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture);

		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.dgCalendarioDelivery = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dgCalendarioDelivery)).BeginInit();
			this.SuspendLayout();
			// 
			// dgCalendarioDelivery
			// 
			this.dgCalendarioDelivery.AlternatingBackColor = System.Drawing.SystemColors.ControlLight;
			this.dgCalendarioDelivery.CaptionVisible = false;
			this.dgCalendarioDelivery.DataMember = "";
			this.dgCalendarioDelivery.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgCalendarioDelivery.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgCalendarioDelivery.Location = new System.Drawing.Point(0, 0);
			this.dgCalendarioDelivery.Name = "dgCalendarioDelivery";
			this.dgCalendarioDelivery.ParentRowsVisible = false;
			this.dgCalendarioDelivery.ReadOnly = true;
			this.dgCalendarioDelivery.SelectionBackColor = System.Drawing.SystemColors.ControlDark;
			this.dgCalendarioDelivery.Size = new System.Drawing.Size(704, 150);
			this.dgCalendarioDelivery.TabIndex = 2;
			this.dgCalendarioDelivery.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgCalendarioDelivery_MouseDown);
			// 
			// frmCalendarioDelivery
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(704, 150);
			this.Controls.Add(this.dgCalendarioDelivery);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmCalendarioDelivery";
			this.Text = "Delivery Calendar";
			this.Load += new System.EventHandler(this.frmCalendarioDelivery_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgCalendarioDelivery)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frmCalendarioDelivery_Load(object sender, System.EventArgs e)
		{
			// Pulisco il DataGrid e lo ricostruisco in base al contenuto del DataSet...
			dgCalendarioDelivery.DataSource = null;
		}

		public void SetCurrentContract(string contract)
		{
			this.Text = _sThisFormTitle + " " + contract;

			DatiOreFornitura[] tmpDOF = BLMainObj.GetOreFornitura(contract);
			CalendarioDelivery_Load(tmpDOF);

			if (dsMainDG != null)
				BindDataGrid(dgCalendarioDelivery, dsMainDG);

		}

		private void CalendarioDelivery_Load(DatiOreFornitura[] tmpDOF)
		{
			dsMainDG = new DataSet();

			// Definisco le colonne del DT che poi aggiungo al DS...
			DataTable tmpDT = new DataTable("CD");
			tmpDT.Columns.Add("ContractDate", typeof(String));
			tmpDT.Columns.Add("ContractType", typeof(String));

			for (int i = 1; i<=25; i++)
				tmpDT.Columns.Add(i.ToString("Hour00"), typeof(String));

			// Aggiungo le righe...
			DataRow tmpDR;

			foreach(DatiOreFornitura tmpCurrDOF in tmpDOF)
			{
				tmpDR = tmpDT.NewRow();

				tmpDR["ContractDate"] = tmpCurrDOF.nnDataDelivery.ToString(BipexFormSettings.FmtForDateWithDayOfWeek, Thread.CurrentThread.CurrentCulture);
				tmpDR["ContractType"] = tmpCurrDOF.nnFestivoFeriale;

				// SE NEL SET DELLE RIGHE VISUALIZZATE CADE UNO DEI DUE GIORNI DI ENTRATA IN VIGORE / TERMINE
				// DEL PERIODO DELL'ORA LEGALE, ECCO CHE OCCORRE PASSARE ALLA VISUALIZZAZIONE SU 25 COLONNE
				// MENTRE IN TUTTI GLI ALTRI CASI VA BENE SU 24...

				if (tmpCurrDOF.nnDataDelivery.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture) == _DataInizioOraLegaleAsString ||
					tmpCurrDOF.nnDataDelivery.ToString(BipexFormSettings.FmtForDate, Thread.CurrentThread.CurrentCulture) == _DataFineOraLegaleAsString)
				{
					for (int i = 1; i<=25; i++)
						tmpDR[i.ToString("Hour00")] = tmpCurrDOF.nnH.Substring(i-1,1);
				}
				else
				{
					for (int i = 1; i<=24; i++)
						tmpDR[i.ToString("Hour00")] = tmpCurrDOF.nnH.Substring(i-1,1);

					int j=25;
					tmpDR[j.ToString("Hour00")] = "n/a";
				}

				tmpDT.Rows.Add(tmpDR);
			}

			dsMainDG.Tables.Add(tmpDT);

		}

		private void BindDataGrid(DataGrid dg, DataSet ds)
		{
			if (ds != null)
				SetDataGridTableStyles(dg, "CD");

			FillDataGrid(dg, ds);
		
		}

		private void SetDataGridTableStyles(DataGrid dg, string sMappingName)
		{
			dg.TableStyles.Clear();

			DataGridTableStyle dgsBook = new DataGridTableStyle();

			// !!!ATTENZIONE!!!
			// WORKAROUND PER RISOLUZIONE PROBLEMA
			// SE SI RIDEFINISCE UN PROPRIO TABLESTYLE 
			// PER VISUALIZZARE UN DATATABLE,
			// OCCORRE RIASSEGNARE ESPLICITAMENTE I COLORI!!!,
			// altrimenti ad esempio impostazioni come l'alternate
			// color vanno perdute...
			dgsBook.AlternatingBackColor = BipexFormSettings.AlternatingBackColor;
			dgsBook.BackColor = BipexFormSettings.BackColor;
			dgsBook.ForeColor = BipexFormSettings.ForeColor;
			dgsBook.GridLineColor = BipexFormSettings.GridLineColor;
			dgsBook.HeaderBackColor = BipexFormSettings.HeaderBackColor;
			dgsBook.HeaderForeColor = BipexFormSettings.HeaderForeColor;
			dgsBook.LinkColor = BipexFormSettings.LinkColor;
			dgsBook.SelectionBackColor = BipexFormSettings.SelectionBackColor;
			dgsBook.SelectionForeColor = BipexFormSettings.SelectionForeColor;

			// Il DataGrid NON E' SORTABILE DALL'UTENTE...
			dgsBook.AllowSorting = false;
			dgsBook.RowHeadersVisible = false;

			dgsBook.MappingName = sMappingName;

			DataGridAlignedTextBoxColumn[] dgcBook = new DataGridAlignedTextBoxColumn[28];
			for (int i = 0; i < dgcBook.Length; ++i)
				dgcBook[i] = new DataGridAlignedTextBoxColumn();
			int index = 0;

			index = 0;
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = "ContractDate";
			dgcBook[index].HeaderText = "";
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Left; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 150;

			index = 1;
			dgcBook[index] = new DataGridAlignedTextBoxColumn();
			dgcBook[index].MappingName = "ContractType";
			dgcBook[index].HeaderText = "";
			dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
			dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
			dgcBook[index].Format = "G";
			dgcBook[index].Width = 30;

			for (int i = 1; i<=25; i++)
			{
				index = i+1;
				dgcBook[index] = new DataGridDeliveryDayColumn(i);
				dgcBook[index].MappingName = i.ToString("Hour00");
				dgcBook[index].HeaderText = i.ToString("00");
				dgcBook[index].Alignment = HorizontalAlignment.Center; // Header Alignment
				dgcBook[index].DataAlignment = HorizontalAlignment.Center; // Data Alignment
				dgcBook[index].Format = "G";
				dgcBook[index].Width = 25;
			}

			dgsBook.GridColumnStyles.AddRange(dgcBook);
			dg.TableStyles.Add(dgsBook);
		}

		public void FillDataGrid(DataGrid dg, DataSet ds)
		{
			DataView dv = new DataView(ds.Tables[0]);

			dv.AllowDelete = false;
			dv.AllowEdit = false;
			dv.AllowNew = false;

			//Imposto il colore delle righe pari a un colore leggermente
			//piu` scuro di quello utilizzato per le righe dispari.
			int piuScuro = 10;
			int R = dg.BackColor.R - piuScuro;
			int G = dg.BackColor.G - piuScuro;
			int B = dg.BackColor.B - piuScuro;
			if (R < 0) R = 10;
			if (G < 0) G = 10;
			if (B < 0) B = 10;
			Color colore = Color.FromArgb(R, G, B);
			dg.AlternatingBackColor = colore;

			//dg.TableStyles.Clear();
			//dg.TableStyles.IsReadOnly = true;
			//dg.TableStyles.Add(stile);
			dg.AllowNavigation = false;

			dg.DataSource = dv;

		}

		/// <summary>
		/// Per impedire la resize delle colonne skippo tutti gli eventi di mouse down
		/// che mi arrivano sull'area di intestazione...
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void dgCalendarioDelivery_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			DataGrid.HitTestInfo ht = dgCalendarioDelivery.HitTest(e.X, e.Y);
			if (ht.Type == DataGrid.HitTestType.ColumnHeader || ht.Type == DataGrid.HitTestType.ColumnResize)
			{
				return;
			}
		}

		/// <summary>
		/// La classe incapsula il comportamento grafico delle colonne del
		/// tipo "Delivery Day"
		/// (bg scuro se il giorno � di fornitura, bg chiaro se il giorno
		/// non � di fornitura)
		/// </summary>
		private class DataGridDeliveryDayColumn : DataGridAlignedTextBoxColumn
		{
			private static Brush _bgrigio = new SolidBrush(Color.Gray);
			private static Brush _bbianco = new SolidBrush(Color.White);

			// L'indice che rappresenta il giorno...
			private int iDay;

			public DataGridDeliveryDayColumn(int i)
			{
				// La classe derivata si occupa della gestione dei colori di BG e FG
				// per cui cio' non deve essere fatto nella classe base...
				bColorSetInDerivedClass = true;

				iDay = i;
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
				int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				try
				{
					// Questa e' la riga corrente...
					DataRow dr = ((DataView) cm.List)[rowNum].Row;

					// ...e questi sono i valori delle celle della riga corrente...

					// La colonna derivata che disegna il background nero/bianco basa il suo
					// funzionamento sulla presenza o meno del valore "1" in corrispondenza
					// delle ore del giorno in cui c'� delivery e " " in assenza di delivery... 
					// se si cambia questo assunto occorre correggere ANCHE il metodo paint 
					// nella classe derivata!

					if (dr[iDay.ToString("Hour00")].ToString() == "1")
					{
						myBackBrush = myForeBrush = _bgrigio;
					}
					else if (dr[iDay.ToString("Hour00")].ToString() == " ")
						{
							myBackBrush = myForeBrush = _bbianco;
						}

				}
				catch
				{
					Debug.Assert(false);
				}

				base.Paint(g, bounds, cm, rowNum, myBackBrush, myForeBrush, alignToRight);
			}

		}

		/// <summary>
		/// La classe consente di gestire l'allineamento separato tra l'header text
		/// di una colonna ed i dati contenuti nelle celle nella colonna stessa
		/// 
		/// Derivando da questa classe si ottiene che:
		/// 
		/// -	La proprieta' standard Alignment serve a gestire l'allineamento
		///		dell'header (ATTENZIONE: HorizontalAlignment.Right CAUSA UN CLIPPING
		///		DELL'HEADER TEXT e quindi e' meglio non usarlo!);
		///	-	La proprieta' custom DataAlignment serve a gestire l'allineamento
		///		del dato nella cella.
		/// </summary>
		private class DataGridAlignedTextBoxColumn : DataGridTextBoxColumn
		{
			protected bool bColorSetInDerivedClass = false;
			private HorizontalAlignment dataAlignment = HorizontalAlignment.Center;

			/// <summary>
			/// La proprieta' serve a gestire l'allineamento del dato nella cella.
			/// </summary>
			public HorizontalAlignment DataAlignment
			{
				get { return this.dataAlignment; }
				set { this.dataAlignment = value; }
			}

			protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager cm,
				int rowNum, Brush backBrush, Brush foreBrush, bool alignToRight)
			{
				// !!!ATTENZIONE!!!
				// WORKAROUND PER RISOLUZIONE PROBLEMA
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// Questo codice e' quello che Fa il Paint della riga Selezionata!!!
				// (per default, il click sulla barra a sz delle celle fa il paint mentre
				// il click sulle celle stesse non fa il paint!!!)

				// L'evento di Paint(..) viene scatenato per tutte le celle della colonna...
				Brush myBackBrush;
				Brush myForeBrush;
				if (this.DataGridTableStyle.DataGrid.CurrentRowIndex == rowNum & !bColorSetInDerivedClass)
				{
					// Sono sulla riga selezionata, la dovrei evidenziare...
					myBackBrush = new SolidBrush(this.DataGridTableStyle.SelectionBackColor);
					myForeBrush = new SolidBrush(this.DataGridTableStyle.SelectionForeColor);
				}
				else
				{
					myBackBrush = backBrush;
					myForeBrush = foreBrush;
				}

				// Questa e' la riga corrente...
				DataRow dr = ((DataView) cm.List)[rowNum].Row;

				// ...e questi sono i valori delle celle della riga corrente...
				string strCellText = "";
				if (dr[this.MappingName] != System.Convert.DBNull)
					// Converto il valore in stringa per poterlo riscrivere, devo
					// tenere conto dell'attributo di formattazione eventualmente
					// impostato dall'utente del datagrid...
					strCellText = FormatObjectAsString(dr[this.MappingName], this.Format);

				// Determino l'allineamento in funzione della property impostata dall'utente della classe
				StringFormat stringFormat = new StringFormat();
				switch (DataAlignment)
				{
					case HorizontalAlignment.Center:
						stringFormat.Alignment = StringAlignment.Center;
						break;
					case HorizontalAlignment.Left:
						stringFormat.Alignment = StringAlignment.Near;
						break;
					case HorizontalAlignment.Right:
						stringFormat.Alignment = StringAlignment.Far;
						break;
				}

				// Disegno BackGround sul rect da refreshare...
				g.FillRectangle(myBackBrush, bounds);
				// Calcolo nuovo rect...
				RectangleF CellBounds = new RectangleF(bounds.Left, bounds.Top + 3, bounds.Width, bounds.Height);
				// Refresh del contenuto della cella...
				g.DrawString(strCellText, this.DataGridTableStyle.DataGrid.Font, myForeBrush, CellBounds, stringFormat);

			}

			private int SelectedRow = -1;

			protected override void Edit(CurrencyManager source, int rowNum, Rectangle bounds, bool readOnly, string instantText, bool cellIsVisible)
			{
				// Per evitare crash testare che ci sia una selezione valida
				// prima di fare la deselezione...
				if (SelectedRow > -1 && SelectedRow < source.List.Count + 1)
					this.DataGridTableStyle.DataGrid.UnSelect(SelectedRow);
			}

			protected string FormatObjectAsString(object o, string Format)
			{
				if (o.GetType() == typeof (DateTime))
				{
					DateTime tmp = Convert.ToDateTime(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (double))
				{
					double tmp = Convert.ToDouble(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else if (o.GetType() == typeof (decimal))
				{
					decimal tmp = Convert.ToDecimal(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (short))
				{
					short tmp = Convert.ToInt16(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (int))
				{
					int tmp = Convert.ToInt32(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				if (o.GetType() == typeof (long))
				{
					long tmp = Convert.ToInt64(o, Thread.CurrentThread.CurrentCulture);
					return tmp.ToString(Format, Thread.CurrentThread.CurrentCulture);
				}
				else
				{
					// Type non gestito con formattazione specifica, richiamo il metodo
					// standard di conversione in stringa...
					return o.ToString();
				}
			}
		}

	}
}
