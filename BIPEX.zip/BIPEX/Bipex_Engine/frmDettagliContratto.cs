using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmDettagliContratto.
	/// </summary>
	public class frmDettagliContratto : System.Windows.Forms.Form
	{
		private string _sThisFormTitle;

		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmDettagliContratto()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			// Memorizzo il Title del form stabilito a design time perche'
			// a run time lo devo concatenare con altre info...
			_sThisFormTitle = this.Text;

		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// frmDettagliContratto
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(704, 150);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmDettagliContratto";
			this.Text = "Contract Detail";
			this.Load += new System.EventHandler(this.frmDettagliContratto_Load);

		}
		#endregion

		private void frmDettagliContratto_Load(object sender, System.EventArgs e)
		{

			ChangeContract(string.Empty);

		}

		public void SetCurrentContract(string contract)
		{
			this.ChangeContract(contract);
		}

		private void ChangeContract(string contract)
		{
			this.Text = _sThisFormTitle + " " + contract;
		}

	}
}
