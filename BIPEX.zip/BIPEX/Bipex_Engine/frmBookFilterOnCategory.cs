
namespace Bipex_Engine
{
	/// <summary>
	/// Descrizione di riepilogo per frmBookFilterOnCategory.
	/// </summary>
	public class frmBookFilterOnCategory : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.CheckBox cbDBSLD;
		private System.Windows.Forms.CheckBox cbWBSLD;
		private System.Windows.Forms.CheckBox cbDPEAK;
		private System.Windows.Forms.CheckBox cbMBSLD;
		private System.Windows.Forms.CheckBox cbMPEAK;
		private System.Windows.Forms.CheckBox cbWPEAK;
		private System.Windows.Forms.CheckBox cbWOFPK;
		private System.Windows.Forms.CheckBox cbDOFPK;
		private System.Windows.Forms.CheckBox cbMOFPK;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private frmBook.FilterOnCategory dvFilter;
		private System.Windows.Forms.Label lbD;
		private System.Windows.Forms.Label lbW;
		private System.Windows.Forms.Label lbM;
		private System.Windows.Forms.Label lbBSLD;
		private System.Windows.Forms.Label lbPEAK;
		private System.Windows.Forms.Label lbOFPK;
		private System.Windows.Forms.Label lbInfo;
		public bool bRC = false;
		
		public frmBookFilterOnCategory(ref frmBook.FilterOnCategory advf)
		{
			dvFilter = advf;
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBookFilterOnCategory));
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.cbDBSLD = new System.Windows.Forms.CheckBox();
			this.lbD = new System.Windows.Forms.Label();
			this.lbW = new System.Windows.Forms.Label();
			this.lbM = new System.Windows.Forms.Label();
			this.lbBSLD = new System.Windows.Forms.Label();
			this.lbPEAK = new System.Windows.Forms.Label();
			this.lbOFPK = new System.Windows.Forms.Label();
			this.cbWBSLD = new System.Windows.Forms.CheckBox();
			this.cbDPEAK = new System.Windows.Forms.CheckBox();
			this.cbMBSLD = new System.Windows.Forms.CheckBox();
			this.cbMPEAK = new System.Windows.Forms.CheckBox();
			this.cbWPEAK = new System.Windows.Forms.CheckBox();
			this.cbWOFPK = new System.Windows.Forms.CheckBox();
			this.cbDOFPK = new System.Windows.Forms.CheckBox();
			this.cbMOFPK = new System.Windows.Forms.CheckBox();
			this.lbInfo = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
			this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCancel.Location = new System.Drawing.Point(149, 264);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(80, 32);
			this.btnCancel.TabIndex = 16;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnOK
			// 
			this.btnOK.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnOK.Image = ((System.Drawing.Image)(resources.GetObject("btnOK.Image")));
			this.btnOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnOK.Location = new System.Drawing.Point(64, 264);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(80, 32);
			this.btnOK.TabIndex = 15;
			this.btnOK.Text = "&OK";
			this.btnOK.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// cbDBSLD
			// 
			this.cbDBSLD.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbDBSLD.Location = new System.Drawing.Point(104, 64);
			this.cbDBSLD.Name = "cbDBSLD";
			this.cbDBSLD.Size = new System.Drawing.Size(24, 24);
			this.cbDBSLD.TabIndex = 4;
			this.cbDBSLD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbDBSLD.CheckedChanged += new System.EventHandler(this.cbDBSLD_CheckedChanged);
			// 
			// lbD
			// 
			this.lbD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbD.Location = new System.Drawing.Point(88, 32);
			this.lbD.Name = "lbD";
			this.lbD.Size = new System.Drawing.Size(56, 16);
			this.lbD.TabIndex = 0;
			this.lbD.Text = "Day";
			this.lbD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lbD.DoubleClick += new System.EventHandler(this.lbD_DoubleClick);
			// 
			// lbW
			// 
			this.lbW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbW.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbW.Location = new System.Drawing.Point(152, 32);
			this.lbW.Name = "lbW";
			this.lbW.Size = new System.Drawing.Size(56, 16);
			this.lbW.TabIndex = 1;
			this.lbW.Text = "Week";
			this.lbW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lbW.DoubleClick += new System.EventHandler(this.lbW_DoubleClick);
			// 
			// lbM
			// 
			this.lbM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbM.Location = new System.Drawing.Point(216, 32);
			this.lbM.Name = "lbM";
			this.lbM.Size = new System.Drawing.Size(56, 16);
			this.lbM.TabIndex = 2;
			this.lbM.Text = "Month";
			this.lbM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lbM.DoubleClick += new System.EventHandler(this.lbM_DoubleClick);
			// 
			// lbBSLD
			// 
			this.lbBSLD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbBSLD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbBSLD.Location = new System.Drawing.Point(16, 72);
			this.lbBSLD.Name = "lbBSLD";
			this.lbBSLD.Size = new System.Drawing.Size(70, 16);
			this.lbBSLD.TabIndex = 3;
			this.lbBSLD.Text = "BaseLoad";
			this.lbBSLD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.lbBSLD.DoubleClick += new System.EventHandler(this.lbBSLD_DoubleClick);
			// 
			// lbPEAK
			// 
			this.lbPEAK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbPEAK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbPEAK.Location = new System.Drawing.Point(16, 108);
			this.lbPEAK.Name = "lbPEAK";
			this.lbPEAK.Size = new System.Drawing.Size(70, 16);
			this.lbPEAK.TabIndex = 7;
			this.lbPEAK.Text = "Peak";
			this.lbPEAK.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.lbPEAK.DoubleClick += new System.EventHandler(this.lbPEAK_DoubleClick);
			// 
			// lbOFPK
			// 
			this.lbOFPK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbOFPK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbOFPK.Location = new System.Drawing.Point(16, 152);
			this.lbOFPK.Name = "lbOFPK";
			this.lbOFPK.Size = new System.Drawing.Size(70, 16);
			this.lbOFPK.TabIndex = 11;
			this.lbOFPK.Text = "OffPeak";
			this.lbOFPK.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.lbOFPK.DoubleClick += new System.EventHandler(this.lbOFPK_DoubleClick);
			// 
			// cbWBSLD
			// 
			this.cbWBSLD.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbWBSLD.Location = new System.Drawing.Point(168, 64);
			this.cbWBSLD.Name = "cbWBSLD";
			this.cbWBSLD.Size = new System.Drawing.Size(24, 24);
			this.cbWBSLD.TabIndex = 5;
			this.cbWBSLD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbWBSLD.CheckedChanged += new System.EventHandler(this.cbWBSLD_CheckedChanged);
			// 
			// cbDPEAK
			// 
			this.cbDPEAK.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbDPEAK.Location = new System.Drawing.Point(104, 104);
			this.cbDPEAK.Name = "cbDPEAK";
			this.cbDPEAK.Size = new System.Drawing.Size(24, 24);
			this.cbDPEAK.TabIndex = 8;
			this.cbDPEAK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbDPEAK.CheckedChanged += new System.EventHandler(this.cbDPEAK_CheckedChanged);
			// 
			// cbMBSLD
			// 
			this.cbMBSLD.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbMBSLD.Location = new System.Drawing.Point(232, 64);
			this.cbMBSLD.Name = "cbMBSLD";
			this.cbMBSLD.Size = new System.Drawing.Size(24, 24);
			this.cbMBSLD.TabIndex = 6;
			this.cbMBSLD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbMBSLD.CheckedChanged += new System.EventHandler(this.cbMBSLD_CheckedChanged);
			// 
			// cbMPEAK
			// 
			this.cbMPEAK.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbMPEAK.Location = new System.Drawing.Point(232, 104);
			this.cbMPEAK.Name = "cbMPEAK";
			this.cbMPEAK.Size = new System.Drawing.Size(24, 24);
			this.cbMPEAK.TabIndex = 10;
			this.cbMPEAK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbMPEAK.CheckedChanged += new System.EventHandler(this.cbMPEAK_CheckedChanged);
			// 
			// cbWPEAK
			// 
			this.cbWPEAK.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbWPEAK.Location = new System.Drawing.Point(168, 104);
			this.cbWPEAK.Name = "cbWPEAK";
			this.cbWPEAK.Size = new System.Drawing.Size(24, 24);
			this.cbWPEAK.TabIndex = 9;
			this.cbWPEAK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbWPEAK.CheckedChanged += new System.EventHandler(this.cbWPEAK_CheckedChanged);
			// 
			// cbWOFPK
			// 
			this.cbWOFPK.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbWOFPK.Location = new System.Drawing.Point(168, 144);
			this.cbWOFPK.Name = "cbWOFPK";
			this.cbWOFPK.Size = new System.Drawing.Size(24, 24);
			this.cbWOFPK.TabIndex = 13;
			this.cbWOFPK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbWOFPK.CheckedChanged += new System.EventHandler(this.cbWOFPK_CheckedChanged);
			// 
			// cbDOFPK
			// 
			this.cbDOFPK.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbDOFPK.Location = new System.Drawing.Point(104, 144);
			this.cbDOFPK.Name = "cbDOFPK";
			this.cbDOFPK.Size = new System.Drawing.Size(24, 24);
			this.cbDOFPK.TabIndex = 12;
			this.cbDOFPK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbDOFPK.CheckedChanged += new System.EventHandler(this.cbDOFPK_CheckedChanged);
			// 
			// cbMOFPK
			// 
			this.cbMOFPK.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbMOFPK.Location = new System.Drawing.Point(232, 144);
			this.cbMOFPK.Name = "cbMOFPK";
			this.cbMOFPK.Size = new System.Drawing.Size(24, 24);
			this.cbMOFPK.TabIndex = 14;
			this.cbMOFPK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbMOFPK.CheckedChanged += new System.EventHandler(this.cbMOFPK_CheckedChanged);
			// 
			// lbInfo
			// 
			this.lbInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbInfo.Location = new System.Drawing.Point(24, 192);
			this.lbInfo.Name = "lbInfo";
			this.lbInfo.Size = new System.Drawing.Size(240, 40);
			this.lbInfo.TabIndex = 17;
			this.lbInfo.Text = "Note: Double Click on a Label Toggles ALL Row/Column, based on first element valu" +
				"e";
			this.lbInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmBookFilterOnCategory
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(292, 302);
			this.Controls.Add(this.lbInfo);
			this.Controls.Add(this.cbMOFPK);
			this.Controls.Add(this.cbDOFPK);
			this.Controls.Add(this.cbWOFPK);
			this.Controls.Add(this.cbWPEAK);
			this.Controls.Add(this.cbMPEAK);
			this.Controls.Add(this.cbMBSLD);
			this.Controls.Add(this.cbDPEAK);
			this.Controls.Add(this.cbWBSLD);
			this.Controls.Add(this.lbOFPK);
			this.Controls.Add(this.lbPEAK);
			this.Controls.Add(this.lbBSLD);
			this.Controls.Add(this.lbM);
			this.Controls.Add(this.lbW);
			this.Controls.Add(this.lbD);
			this.Controls.Add(this.cbDBSLD);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmBookFilterOnCategory";
			this.Text = "Main Book Filter";
			this.Load += new System.EventHandler(this.frmBookFilterOnCategory_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmBookFilterOnCategory_Load(object sender, System.EventArgs e)
		{
			this.cbDBSLD.Checked = dvFilter.bDailyBaseLoad;
			this.cbDOFPK.Checked = dvFilter.bDailyOffPeak;
			this.cbDPEAK.Checked = dvFilter.bDailyPeak;
			this.cbWBSLD.Checked = dvFilter.bWeeklyBaseLoad;
			this.cbWOFPK.Checked = dvFilter.bWeeklyOffPeak;
			this.cbWPEAK.Checked = dvFilter.bWeeklyPeak;
			this.cbMBSLD.Checked = dvFilter.bMonthlyBaseLoad;
			this.cbMOFPK.Checked = dvFilter.bMonthlyOffPeak;
			this.cbMPEAK.Checked = dvFilter.bMonthlyPeak;
		}

		private void btnOK_Click(object sender, System.EventArgs e)
		{
			dvFilter.bDailyBaseLoad		= this.cbDBSLD.Checked;
			dvFilter.bDailyOffPeak		= this.cbDOFPK.Checked;
			dvFilter.bDailyPeak			= this.cbDPEAK.Checked;
			dvFilter.bWeeklyBaseLoad	= this.cbWBSLD.Checked;
			dvFilter.bWeeklyOffPeak		= this.cbWOFPK.Checked;
			dvFilter.bWeeklyPeak		= this.cbWPEAK.Checked;
			dvFilter.bMonthlyBaseLoad	= this.cbMBSLD.Checked;
			dvFilter.bMonthlyOffPeak	= this.cbMOFPK.Checked;
			dvFilter.bMonthlyPeak		= this.cbMPEAK.Checked;

			bRC = true;
			this.Close();

		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void cbDBSLD_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void cbWBSLD_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void cbMBSLD_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void cbDPEAK_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void cbWPEAK_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void cbMPEAK_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void cbDOFPK_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void cbWOFPK_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void cbMOFPK_CheckedChanged(object sender, System.EventArgs e)
		{
			SetPBsOnCBSelection();
		}

		private void SetPBsOnCBSelection()
		{
			// Il PB Cancel e' sempre attivo, il PB OK e' attivo SOLO SE c'e'
			// ALMENO un CB selezionato!!!

			btnCancel.Enabled = true;
			if (
				this.cbDBSLD.Checked || 
				this.cbDOFPK.Checked || 
				this.cbDPEAK.Checked || 
				this.cbWBSLD.Checked ||
				this.cbWOFPK.Checked || 
				this.cbWPEAK.Checked || 
				this.cbMBSLD.Checked ||
				this.cbMOFPK.Checked ||
				this.cbMPEAK.Checked 
				)
				this.btnOK.Enabled = true;
			else
				this.btnOK.Enabled = false;

		}

		private void lbD_DoubleClick(object sender, System.EventArgs e)
		{
			if (this.cbDBSLD.Checked == true)
			{
				this.cbDBSLD.Checked = false;
				this.cbDOFPK.Checked = false;
				this.cbDPEAK.Checked = false;
			}
			else
			{
				this.cbDBSLD.Checked = true;
				this.cbDOFPK.Checked = true;
				this.cbDPEAK.Checked = true;
			}
		}

		private void lbW_DoubleClick(object sender, System.EventArgs e)
		{
			if (this.cbWBSLD.Checked == true)
			{
				this.cbWBSLD.Checked = false;
				this.cbWOFPK.Checked = false;
				this.cbWPEAK.Checked = false;
			}
			else
			{
				this.cbWBSLD.Checked = true;
				this.cbWOFPK.Checked = true;
				this.cbWPEAK.Checked = true;
			}
		}

		private void lbM_DoubleClick(object sender, System.EventArgs e)
		{
			if (this.cbMBSLD.Checked == true)
			{
				this.cbMBSLD.Checked = false;
				this.cbMOFPK.Checked = false;
				this.cbMPEAK.Checked = false;
			}
			else
			{
				this.cbMBSLD.Checked = true;
				this.cbMOFPK.Checked = true;
				this.cbMPEAK.Checked = true;
			}
		}

		private void lbBSLD_DoubleClick(object sender, System.EventArgs e)
		{
			if (this.cbDBSLD.Checked == true)
			{
				this.cbDBSLD.Checked = false;
				this.cbWBSLD.Checked = false;
				this.cbMBSLD.Checked = false;
			}
			else
			{
				this.cbDBSLD.Checked = true;
				this.cbWBSLD.Checked = true;
				this.cbMBSLD.Checked = true;
			}
		}

		private void lbPEAK_DoubleClick(object sender, System.EventArgs e)
		{
			if (this.cbDPEAK.Checked == true)
			{
				this.cbDPEAK.Checked = false;
				this.cbWPEAK.Checked = false;
				this.cbMPEAK.Checked = false;
			}
			else
			{
				this.cbDPEAK.Checked = true;
				this.cbWPEAK.Checked = true;
				this.cbMPEAK.Checked = true;
			}
		}

		private void lbOFPK_DoubleClick(object sender, System.EventArgs e)
		{
			if (this.cbDOFPK.Checked == true)
			{
				this.cbDOFPK.Checked = false;
				this.cbWOFPK.Checked = false;
				this.cbMOFPK.Checked = false;
			}
			else
			{
				this.cbDOFPK.Checked = true;
				this.cbWOFPK.Checked = true;
				this.cbMOFPK.Checked = true;
			}
		}

	}
}
