using System;
using System.Collections;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Threading;
using System.Web;
using System.Web.SessionState;
using Bipex_BL;
using Bipex_BLInterface;
using GME;
using GME.BL;

namespace Bipex_BLWS 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{
			try
			{
				SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring);
				cn.Open();
				cn.Close();
			}
			catch (Exception ex)
			{
				string g = ex.Message;
				g = g.ToLower();
			}




			string blConfig = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "BL.config";
			RemConfig.ServerConfig(blConfig, typeof (Echo).Assembly);
			RemConfig.ClientConfig(blConfig, typeof(IEcho).Assembly);

			SmTraceListener.TraceWriter = new SmTraceListener.TraceWriterDelegate(LogServer.WriteMessage);
			Log.smTraceIf(Log.smLogSwitch.TraceInfo, "Bipex_BLWS Application_Start");

			AppDomain.CurrentDomain.UnhandledException +=new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);

			/*
			Thread.Sleep(1000*15);
			try
			{
				ICacheUpdater cc = (ICacheUpdater) GME.Remoting.RemotingHelper.GetObject(typeof(ICacheUpdater));
				cc.OnAbbinamento("dld");
			}
			catch (Exception ex)
			{
				Log.smError(ex);
			}
			*/
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{

		}

 
		protected void Session_Start(Object sender, EventArgs e)
		{
			Log.smTraceIf(Log.smLogSwitch.TraceInfo, "Bipex_BLWS Session_Start");
		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_Error(Object sender, EventArgs e)
		{
			try
			{
				Exception ex = Server.GetLastError();
				Log.smError(ex);
			}
			catch
			{
			}
		}

		protected void Session_End(Object sender, EventArgs e)
		{
			Log.smTraceIf(Log.smLogSwitch.TraceInfo, "Bipex_BLWS Session_End");

		}

		protected void Application_End(Object sender, EventArgs e)
		{
			Log.smTraceIf(Log.smLogSwitch.TraceInfo, "Bipex_BLWS Application_End");
		}
			
		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
		}
		#endregion
	}
}

