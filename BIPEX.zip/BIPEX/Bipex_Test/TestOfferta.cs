using System;
using System.IO;
using System.Text;
using System.Xml;
using Bipex_BLInterface;
using GME.Remoting;

public class TestOfferta
{
	public static void Test(string fileName)
	{
		// --- Inizio Prova
		try
		{
			IOfferta c = (IOfferta) RemotingHelper.GetObject(typeof (IOfferta));

			if (!File.Exists(fileName))
			{
				Console.WriteLine("Il file {0} non esiste.", fileName);
				Environment.Exit(1);
			}
			StreamReader sr = new StreamReader(fileName);
			string g = sr.ReadToEnd();
			byte[] msgXml = Encoding.UTF8.GetBytes(g);
			sr.Close();

			XmlDocument d = new XmlDocument();
			d.LoadXml(g);

			XmlNamespaceManager nsmgr = new XmlNamespaceManager(d.NameTable);
			nsmgr.AddNamespace("x", "urn:XML-Bipex");

			string op = d.DocumentElement.SelectSingleNode("./x:Testata/x:Mittente/x:CodiceOperatore", nsmgr).InnerText;
			string ut = d.DocumentElement.SelectSingleNode("./x:Testata/x:Mittente/x:CodiceUtente", nsmgr).InnerText;

			byte[] respXml;
			respXml = c.ElaboraRichiesta(op, ut, msgXml);

			string x = Encoding.UTF8.GetString(respXml);
			Console.WriteLine("{0}", x);
			Console.ReadLine();
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
			Console.ReadLine();
		}
		// --- Fine Prova

//		MessaggioRichiesta m = new MessaggioRichiesta();
//	
//		m.DataOraMessaggio = DateTime.Now;
//		m.IdMessaggio = Guid.NewGuid().ToString("N");
//		m.Versione = tipoVersione.Item10;
//	
//		m.Testata = new TestataRichiesta();
//		m.Testata.Destinatario = new Destinatario();
//		m.Testata.Mittente = new MittenteRichiesta();
//	
//		m.Testata.Mittente.CodiceOperatore = "1";
//		m.Testata.Mittente.CodiceUtente = "1";
//	
//		m.Testata.Destinatario.CodiceOperatore = "IDBIPEX";
//	
//		m.Richiesta = new Richiesta[1];
//	
//		m.Richiesta[0] = new Richiesta();
//		m.Richiesta[0].IdRichiesta = Guid.NewGuid().ToString("N");
//	
//		// qui varia in funzione del tipo di richiesta
//		if (true)
//		{
//			RichiestaNuovaOfferta rq = new RichiestaNuovaOfferta();
//			m.Richiesta[0].Item = rq;
//
//			// Per ora il form non gestisce offerte OTC...
//			rq.CodiceOTC = string.Empty;
//			rq.OperatoreOTC = string.Empty;
//
//			if (true)
//				rq.TipoOfferta = tipoTipoOfferta.Acquisto;
//			else
//				rq.TipoOfferta = tipoTipoOfferta.Vendita;
//
//			rq.Contratto = "W-OFPK-05-Jul-11";
//			rq.Quantita = 10;
//			rq.PrezzoUnitario = 52.3m;
//
//			rq.NoteOfferta = string.Empty;
//		}
//
//		if (false)
//		{
//				
//			RichiestaModificaOfferta rq = new RichiestaModificaOfferta();
//			m.Richiesta[0].Item = rq;
//
//			// Per ora il form non gestisce offerte OTC...
//
//			rq.IdOfferta = "10";
//			rq.Quantita = 10;
//			rq.PrezzoUnitario = 52.3m;
//			rq.NoteOfferta = string.Empty;
//		}
//
//		try
//		{
//
//			IOfferta c = (IOfferta) GME.Remoting.RemotingHelper.GetObject(typeof(Bipex_BLInterface.IOfferta));
//
//			MemoryStream msRich = new MemoryStream();
//
//			XmlTextWriter xw = new XmlTextWriter(msRich, Encoding.UTF8);
//			xw.Indentation = 1;
//			xw.IndentChar = '\t';
//			xw.Formatting = Formatting.Indented;
//			xw.Namespaces = true;
//			
//			XmlSerializer xs = new XmlSerializer(typeof(MessaggioRichiesta));
//			xs.Serialize(xw, m);
//			
//			xw.Close();
//
//			byte [] msgXml = msRich.ToArray();
//
//			byte [] respXml;
//			respXml = c.ElaboraRichiesta("1", "1", msgXml);
//
//			string x = Encoding.UTF8.GetString(respXml);
//			Console.WriteLine("{0}", x);
//		}
//		catch (Exception ex)
//		{
//			Console.WriteLine(ex.Message);				
//		}			

	}
}