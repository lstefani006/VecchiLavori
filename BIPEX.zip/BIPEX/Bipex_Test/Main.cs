using System;
using System.IO;
using System.Runtime.Remoting;
using Bipex_BLInterface;
using GME.Remoting;
using SPDriver;

namespace Bipex_Test
{
	internal class _
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		private static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			// RemotingConfiguration.Configure(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);

			string cf = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
			RemConfig.ClientConfig(cf, typeof (IEcho).Assembly);


			if (args.Length < 1)
			{
				Console.WriteLine("{0}", "uso Bipex_Text [-o][-a]");
				Environment.Exit(1);
			}

			switch (args[0])
			{
			case "-o":
				String fileName = args[1];
				if (!File.Exists(fileName)) 
				{
					Console.WriteLine("Il file {0} non esiste.",fileName);
					Environment.Exit(1);
				}
				TestOfferta.Test(fileName);

				break;

			case "-a":
				try
				{
					ICacheUpdater c = (ICacheUpdater) RemotingHelper.GetObject(typeof (ICacheUpdater));
					if (args.Length == 2)
					{
						String nomeContratto = args[1];
						if (nomeContratto.Length == 0)
							c.OnAbbinamento("W-OFPK-05-Jul-11");
						else
							c.OnAbbinamento(nomeContratto);
					}
					else
					{
						c.OnSessioneMercato();
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine(ex.Message);

				}
				break;

				case "-t":
				{
					ISessioneMercato sm = (ISessioneMercato) RemotingHelper.GetObject(typeof(ISessioneMercato));
					DatiOfferta o = sm.GetOfferta(243);
					
					DatiOreFornitura [] of = sm.GetOreFornitura(o.nnNomeContratto);

					sm.GetSessione();
					sm.GetSessioneContratto(o.nnNomeContratto);
					sm.GetContratto(o.nnNomeContratto);
				}
					break;

			default:
				Console.WriteLine("{0}", "opzione errata");
				break;

			}
		}

	}
}