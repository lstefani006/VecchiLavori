using System;
using System.ComponentModel;
using System.IO;
using System.Web.Services;
using System.Web.Services.Protocols;
using GME;

namespace Bipex_ControlWS
{
	/// <summary>
	/// Summary description for Deploy.
	/// </summary>
	[WebService(Namespace="http://mercatoelettrico.org/Bipex_ControlWS/Deploy")]
	public class Deploy : WSBase
	{
		public Deploy()
		{
			InitializeComponent();
		}

		#region Component Designer generated code

		//Required by the Web Services Designer 
		private IContainer components = null;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#endregion

		[WebMethod(EnableSession=true)]
		[SoapHeader("authHeader")]
		public void Ping()
		{
			base.CheckAuth();

			try
			{
			}
			catch (Exception ex)
			{
				smError(ex);
			}
		}


		[WebMethod(EnableSession=true)]
		[SoapHeader("authHeader")]
		public byte[] DownloadFile(string fn, DateTime tsLastWriteTime, out DateTime tsServerTime)
		{
			base.CheckAuth();

			try
			{
				string p = Server.MapPath("./Bipex_Engine");

				string pathFn = p + "/" + fn;

				tsServerTime = DateTime.MinValue;

				if (File.Exists(pathFn))
				{
					// se il file nella directory Bipex_Engine
					// e` piu` vecchio del file che hanno nel computer remoto
					// non ritorno niente.
					tsServerTime = File.GetLastWriteTime(pathFn);
					if (tsServerTime == tsLastWriteTime)
						return null;
				}
				else 
					return null;

				using (FileStream f = File.OpenRead(pathFn))
				{
					byte[] r = new byte[f.Length];
					f.Read(r, 0, (int) f.Length);
					return r;
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}
	}
}