using System;
using System.ComponentModel;
using System.Web;
using Bipex_BL;
using Bipex_BLInterface;
using GME;
using GME.Net;
using GME.Remoting;
using GME.Web;

namespace Bipex_ControlWS
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : HttpApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private IContainer components = null;

		public Global()
		{
			InitializeComponent();
		}

		protected void Application_Start(Object sender, EventArgs e)
		{
			Bipex_BL.Common.RootPath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
			string blConfig = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "BL.config";

			
			RemConfig.ServerConfig(blConfig, typeof (Echo).Assembly);
			RemConfig.ClientConfig(blConfig, typeof(IEcho).Assembly);

			WSClient.SetCertificatePolicy(new CustomCertificatePolicy.ServerCertificateProblemsDelegate(CertificateError));

			SmTraceListener.TraceWriter = new SmTraceListener.TraceWriterDelegate(WriteMessage);
			WriteMessage("Bipex_ControlWS Application_Start diretto");
			Log.smTraceIf(Log.smLogSwitch.TraceInfo, "Bipex_ControlWS Application_Start tramite log");

			// sottoscrivo questo applicativo in modo da ricevere gli aggiornamenti della cache 
			// da Bipex_CacheServer
			BipexCacheSubscriber.Start();
		}

        private static void WriteMessage(string msg)
		{
			try
			{
				ILogServer l = (ILogServer) RemotingHelper.GetObject(typeof (ILogServer));
				l.Write(msg);
			}
			catch (Exception ex)
			{
				ex = ex;
			}
		}

		private static void CertificateError(string url, int problem, string msg)
		{
			string s = string.Format("url='{0}' problem='{1}' msg='{2}'", url, problem, msg);
			Log.smTraceIf(Log.smLogSwitch.TraceError, s);
		}

		protected void Session_Start(Object sender, EventArgs e)
		{
			Log.smTraceIf(Log.smLogSwitch.TraceInfo, "Bipex_ControlWS Sessione_Start");
		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{
		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{
		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{
		}

		protected void Application_Error(Object sender, EventArgs e)
		{
			try
			{
				Exception ex = Server.GetLastError();
				Log.smError(ex);
			}
			catch
			{
			}
		}

		protected void Session_End(Object sender, EventArgs e)
		{
			Log.smTraceIf(Log.smLogSwitch.TraceInfo, "Bipex_ControlWS Sessione_End");
		}

		protected void Application_End(Object sender, EventArgs e)
		{
			Log.smTraceIf(Log.smLogSwitch.TraceInfo, "Bipex_ControlWS Application_End");
		}

		#region Web Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new Container();
		}

		#endregion
	}
}