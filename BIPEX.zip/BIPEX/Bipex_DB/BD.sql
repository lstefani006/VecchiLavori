/****** Object:  Database Bipex    Script Date: 20/10/2005 16.31.51 ******/
CREATE DATABASE [Bipex]  ON (NAME = N'Bipex_Data', FILENAME = N'D:\Bipex_DB\Bipex_Data.MDF' , SIZE = 25, FILEGROWTH = 10%) LOG ON (NAME = N'Bipex_Log', FILENAME = N'D:\Bipex_DB\Bipex_Log.LDF' , SIZE = 1, FILEGROWTH = 10%)
 COLLATE SQL_Latin1_General_CP1_CI_AS
GO

exec sp_dboption N'Bipex', N'autoclose', N'false'
GO

exec sp_dboption N'Bipex', N'bulkcopy', N'false'
GO

exec sp_dboption N'Bipex', N'trunc. log', N'true'
GO

exec sp_dboption N'Bipex', N'torn page detection', N'true'
GO

exec sp_dboption N'Bipex', N'read only', N'false'
GO

exec sp_dboption N'Bipex', N'dbo use', N'false'
GO

exec sp_dboption N'Bipex', N'single', N'false'
GO

exec sp_dboption N'Bipex', N'autoshrink', N'true'
GO

exec sp_dboption N'Bipex', N'ANSI null default', N'false'
GO

exec sp_dboption N'Bipex', N'recursive triggers', N'false'
GO

exec sp_dboption N'Bipex', N'ANSI nulls', N'false'
GO

exec sp_dboption N'Bipex', N'concat null yields null', N'false'
GO

exec sp_dboption N'Bipex', N'cursor close on commit', N'false'
GO

exec sp_dboption N'Bipex', N'default to local cursor', N'false'
GO

exec sp_dboption N'Bipex', N'quoted identifier', N'false'
GO

exec sp_dboption N'Bipex', N'ANSI warnings', N'false'
GO

exec sp_dboption N'Bipex', N'auto create statistics', N'true'
GO

exec sp_dboption N'Bipex', N'auto update statistics', N'true'
GO

if( ( (@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 724) ) or ( (@@microsoftversion / power(2, 24) = 7) and (@@microsoftversion & 0xffff >= 1082) ) )
	exec sp_dboption N'Bipex', N'db chaining', N'false'
GO

use [Bipex]
GO

/****** Object:  Login bil_dbo    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'bil_dbo')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'Prova1', @loginlang = N'Italiano'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'bil_dbo', null, @logindb, @loginlang
END
GO

/****** Object:  Login bil_user    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'bil_user')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'Bilaterali_ROMA5', @loginlang = N'Italiano'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'bil_user', null, @logindb, @loginlang
END
GO

/****** Object:  Login bipex_user    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'bipex_user')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'Bipex', @loginlang = N'Italiano'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'bipex_user', null, @logindb, @loginlang
END
GO

/****** Object:  Login distributor_admin    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'distributor_admin')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'master', @loginlang = N'us_english'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'distributor_admin', null, @logindb, @loginlang
END
GO

/****** Object:  Login MeRT_User    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'MeRT_User')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'master', @loginlang = N'us_english'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'MeRT_User', null, @logindb, @loginlang
END
GO

/****** Object:  Login piovra_dbo    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'piovra_dbo')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'Piovra', @loginlang = N'Italiano'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'piovra_dbo', null, @logindb, @loginlang
END
GO

/****** Object:  Login piovra_user    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'piovra_user')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'Piovra', @loginlang = N'Italiano'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'piovra_user', null, @logindb, @loginlang
END
GO

/****** Object:  Login RegTEE_dbo    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'RegTEE_dbo')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'TEE_Registro', @loginlang = N'Italiano'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'RegTEE_dbo', null, @logindb, @loginlang
END
GO

/****** Object:  Login RegTEE_user    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from master.dbo.syslogins where loginname = N'RegTEE_user')
BEGIN
	declare @logindb nvarchar(132), @loginlang nvarchar(132) select @logindb = N'TEE_Registro', @loginlang = N'Italiano'
	if @logindb is null or not exists (select * from master.dbo.sysdatabases where name = @logindb)
		select @logindb = N'master'
	if @loginlang is null or (not exists (select * from master.dbo.syslanguages where name = @loginlang) and @loginlang <> N'us_english')
		select @loginlang = @@language
	exec sp_addlogin N'RegTEE_user', null, @logindb, @loginlang
END
GO

/****** Object:  Login distributor_admin    Script Date: 20/10/2005 16.31.51 ******/
exec sp_addsrvrolemember N'distributor_admin', sysadmin
GO

/****** Object:  User bipex_user    Script Date: 20/10/2005 16.31.51 ******/
if not exists (select * from dbo.sysusers where name = N'bipex_user' and uid < 16382)
	EXEC sp_grantdbaccess N'bipex_user', N'bipex_user'
GO

/****** Object:  User dbo    Script Date: 20/10/2005 16.31.51 ******/
/****** Object:  User bipex_user    Script Date: 20/10/2005 16.31.51 ******/
exec sp_addrolemember N'db_datareader', N'bipex_user'
GO

/****** Object:  User bipex_user    Script Date: 20/10/2005 16.31.51 ******/
exec sp_addrolemember N'db_datawriter', N'bipex_user'
GO

/****** Object:  User Defined Datatype tipoCodiceMessaggio    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoCodiceMessaggio', N'varchar (32)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoCodiceOperatore    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoCodiceOperatore', N'varchar (8)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoCodiceTransazione    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoCodiceTransazione', N'varchar (32)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoCodiceUtente    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoCodiceUtente', N'varchar (8)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoCompressione    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoCompressione', N'varchar (8)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoEncoding    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoEncoding', N'varchar (16)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoNomeContratto    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoNomeContratto', N'nvarchar (30)', N'not null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoNomeFile    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoNomeFile', N'nvarchar (512)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoStatoTransazione    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoStatoTransazione', N'varchar (32)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoTipoTransazione    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoTipoTransazione', N'varchar (32)', N'null'
GO

setuser
GO

/****** Object:  User Defined Datatype tipoVersione    Script Date: 20/10/2005 16.31.58 ******/
setuser
GO

EXEC sp_addtype N'tipoVersione', N'varchar (5)', N'null'
GO

setuser
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  User Defined Function dbo.ComponeDataOra    Script Date: 20/10/2005 16.32.06 ******/
create function ComponeDataOra (@data datetime, @ora datetime)
returns datetime
as
begin
	declare @ris datetime

	-- Scompone in interi
	declare @aa int, @mm int, @gg int, @h int, @m int, @s int
	set @aa = datepart(year, @data)
	set @mm = datepart(month, @data)
	set @gg = datepart(day, @data)
	set @h = datepart(hour, @ora)
	set @m = datepart(minute, @ora)
	set @s = datepart(second, @ora)
	--

	-- Compone una stringa in ODBC canonico 
	-- ovvero yyyy-mm-dd hh:mi:ss
	declare @odbcTime varchar(20)
	set @odbcTime =  convert(varchar(10), @aa) + '-' + convert(varchar(10), @mm) + '-' +  convert(varchar(10), @gg) + ' ' + convert(varchar(10), @h) + ':' + convert(varchar(10),@m) + ':' + convert(varchar(10),@s)
	--

	-- Converte utilizzando ODBC canonico(yyyy-mm-dd hh:mi:ss)
	-- ovvero codice '120'
	set @ris = convert(datetime, @odbcTime, 120)
	-- 

	--
	return(@ris)
end


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  User Defined Function dbo.GetHourNum    Script Date: 20/10/2005 16.32.06 ******/
CREATE FUNCTION [dbo].[GetHourNum] (@DataProgramma as smalldatetime)  
RETURNS int  AS  
BEGIN 
declare @oraMax int,
	@Month int,
	@WeekDay int,
	@NextDate smalldatetime,
	@NextDateMonth int,
	@LastDayOfWeek int


set @LastDayOfWeek= 8-@@datefirst
set @Month= DATEPART(month,@DataProgramma)
set @WeekDay= DATEPART(weekday,@DataProgramma)
set @NextDate= @DataProgramma + 7
set @NextDateMonth= DATEPART(month,@NextDate)
set @oraMax = 24
-- se e` Marzo, e` Domenica e Domenica prossima e` gia` Aprile
if (@Month = 3  and @WeekDay = @LastDayOfWeek and @NextDateMonth = 4)
begin
	set @oraMax = 23
end

-- se e` Ottobre, e` Domenica e Domenica prossima e` gia` Novembre
if (@Month=10 and @WeekDay = @LastDayOfWeek and @NextDateMonth = 11)
begin
	set @oraMax = 25
end
return(@oraMax)
END




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[GetHourNum]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[GetHourNum]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  User Defined Function dbo.GetTipoGiorno    Script Date: 20/10/2005 16.32.06 ******/


CREATE    function GetTipoGiorno(@d datetime)
returns varchar(4)
as
begin
	-- usato anche nella sp GetOreDiFornitura
	-- Restituisce "FER" oppure "FEST"

	declare @w int
	set @w = (DATEPART(weekday, @d) + @@datefirst) % 7


	--
	declare @ris varchar(4)
	if ( @w = 1 or @w = 0 )
		set @ris = 'FEST'
	else
		set @ris = 'FER'
	return(@ris)
	--
end






GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  User Defined Function dbo.MeseUltimaDomenica    Script Date: 20/10/2005 16.32.06 ******/



CREATE       function MeseUltimaDomenica(@data datetime)
returns char(1)
as
begin
	-- Restituisce:
	-- "*" (Normale)
	-- "M" (Ultima Domenica di Marzo)
	-- "O" (Ultima Domenica di Ottobre)

	-- Domenica se @w = 1
	declare @w int
	set @w = (DATEPART(weekday, @data) + @@datefirst) % 7
	-- 

	-- Se Marzo(3) e Domenica(1) e (day>=25) allora M
	if ( (DATEPART(month, @data)=3)   and
	     (@w = 1) and
	     (DATEPART(day, @data)>=25) )
	begin
		return('M')
	end

	-- Se Ottobre(10) e Domenica(1) e (day>=25) allora O
	if ( (DATEPART(month, @data)=10)   and
	     (@w = 1) and
	     (DATEPART(day, @data)>=25) )
	begin
		return ('O')
	end

	-- Altrimenti
	return('*')
	--
end




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Table [dbo].[Contratto]    Script Date: 20/10/2005 16.31.58 ******/
CREATE TABLE [dbo].[Contratto] (
	[IdContratto] [int] IDENTITY (1, 1) NOT NULL ,
	[NomeContratto] [tipoNomeContratto] NOT NULL ,
	[CodiceProfilo] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DescrizioneContratto] [nvarchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CodiceZonaRiferimento] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DataInizioTrading] [smalldatetime] NOT NULL ,
	[DataFineTrading] [smalldatetime] NOT NULL ,
	[DataInizioDelivery] [smalldatetime] NOT NULL ,
	[DataFineDelivery] [smalldatetime] NOT NULL ,
	[DurataDelivery] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OreFornituraFeriali] [int] NOT NULL ,
	[OreFornituraFestive] [int] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[DailyActivityLog]    Script Date: 20/10/2005 16.31.59 ******/
CREATE TABLE [dbo].[DailyActivityLog] (
	[IdSessioneMercato] [int] NOT NULL ,
	[IdDailyActivity] [int] IDENTITY (1, 1) NOT NULL ,
	[ActivityTS] [datetime] NOT NULL ,
	[ActivityCode] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IdOfferta] [int] NULL ,
	[IdAbbinamento] [int] NULL ,
	[CodiceOperatore] [tipoCodiceOperatore] NULL ,
	[Qty] [int] NULL ,
	[Prezzo] [float] NULL ,
	[Msg] [nvarchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[DataDelivery]    Script Date: 20/10/2005 16.31.59 ******/
CREATE TABLE [dbo].[DataDelivery] (
	[DataDelivery] [smalldatetime] NOT NULL ,
	[TipoGiorno] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[MeseUltimaDomenica] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[ErroriMessaggi]    Script Date: 20/10/2005 16.31.59 ******/
CREATE TABLE [dbo].[ErroriMessaggi] (
	[ErroreCode] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Message] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[MessaggioIn]    Script Date: 20/10/2005 16.31.59 ******/
CREATE TABLE [dbo].[MessaggioIn] (
	[IdMessaggioIn] [int] IDENTITY (1, 1) NOT NULL ,
	[CodiceMessaggioIn] [tipoCodiceMessaggio] NOT NULL ,
	[CodiceOperatoreIn] [tipoCodiceOperatore] NOT NULL ,
	[CodiceUtenteIn] [tipoCodiceUtente] NOT NULL ,
	[NomeFileIn] [tipoNomeFile] NOT NULL ,
	[FirmatoInIngresso] [bit] NOT NULL ,
	[Encoding] [tipoEncoding] NOT NULL ,
	[Versione] [tipoVersione] NOT NULL ,
	[BlobMessaggio] [image] NOT NULL ,
	[DataOraMessaggio] [datetime] NOT NULL ,
	[Compresso] [tipoCompressione] NOT NULL ,
	[Controfirmato] [bit] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[MessaggioOut]    Script Date: 20/10/2005 16.31.59 ******/
CREATE TABLE [dbo].[MessaggioOut] (
	[IdMessaggioOut] [int] IDENTITY (1, 1) NOT NULL ,
	[CodiceMessaggioOut] [tipoCodiceMessaggio] NOT NULL ,
	[CodiceOperatoreOut] [tipoCodiceOperatore] NOT NULL ,
	[NomeFileOut] [tipoNomeFile] NOT NULL ,
	[Compresso] [tipoCompressione] NOT NULL ,
	[FirmatoInUscita] [bit] NOT NULL ,
	[Encoding] [tipoEncoding] NOT NULL ,
	[DataOraMessaggio] [datetime] NOT NULL ,
	[Versione] [tipoVersione] NOT NULL ,
	[BlobMessaggio] [image] NOT NULL ,
	[IdMessaggioIn] [int] NULL ,
	[DataOraDownload] [datetime] NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Operatore]    Script Date: 20/10/2005 16.31.59 ******/
CREATE TABLE [dbo].[Operatore] (
	[CodiceOperatore] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[RagioneSociale] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[AbilitazioneMercato] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[AbilitazioneDelivery] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Parametri]    Script Date: 20/10/2005 16.32.00 ******/
CREATE TABLE [dbo].[Parametri] (
	[Codice] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Descrizione] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ValoreFloat] [float] NULL ,
	[ValoreInt] [int] NULL ,
	[ValoreVarchar] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ValoreDateTime] [datetime] NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[ProfiloOrario]    Script Date: 20/10/2005 16.32.00 ******/
CREATE TABLE [dbo].[ProfiloOrario] (
	[CodiceProfilo] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TipoGiorno] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[MeseUltimaDomenica] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DescrizioneProfilo] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Cancellato] [bit] NOT NULL ,
	[H01] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H02] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H03] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H04] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H05] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H06] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H07] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H08] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H09] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H10] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H11] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H12] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H13] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H14] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H15] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H16] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H17] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H18] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H19] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H20] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H21] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H22] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H23] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H24] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[H25] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SaldoFisico]    Script Date: 20/10/2005 16.32.00 ******/
CREATE TABLE [dbo].[SaldoFisico] (
	[CodiceOperatore] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DataDelivery] [smalldatetime] NOT NULL ,
	[Immissione] [int] NOT NULL ,
	[Prelievo] [int] NOT NULL ,
	[H01] [int] NOT NULL ,
	[H02] [int] NOT NULL ,
	[H03] [int] NOT NULL ,
	[H04] [int] NOT NULL ,
	[H05] [int] NOT NULL ,
	[H06] [int] NOT NULL ,
	[H07] [int] NOT NULL ,
	[H08] [int] NOT NULL ,
	[H09] [int] NOT NULL ,
	[H10] [int] NOT NULL ,
	[H11] [int] NOT NULL ,
	[H12] [int] NOT NULL ,
	[H13] [int] NOT NULL ,
	[H14] [int] NOT NULL ,
	[H15] [int] NOT NULL ,
	[H16] [int] NOT NULL ,
	[H17] [int] NOT NULL ,
	[H18] [int] NOT NULL ,
	[H19] [int] NOT NULL ,
	[H20] [int] NOT NULL ,
	[H21] [int] NOT NULL ,
	[H22] [int] NOT NULL ,
	[H23] [int] NOT NULL ,
	[H24] [int] NOT NULL ,
	[H25] [int] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SessioneMercato]    Script Date: 20/10/2005 16.32.01 ******/
CREATE TABLE [dbo].[SessioneMercato] (
	[IdSessioneMercato] [int] IDENTITY (1, 1) NOT NULL ,
	[DataMercato] [datetime] NOT NULL ,
	[TSAperturaSessione] [datetime] NULL ,
	[TSChiusuraSessione] [datetime] NULL ,
	[StatoSessione] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[NoteSessione] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SmLog]    Script Date: 20/10/2005 16.32.01 ******/
CREATE TABLE [dbo].[SmLog] (
	[SmId] [int] IDENTITY (1, 1) NOT NULL ,
	[SmCategory] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	[SmMessage] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	[SmApplication] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CS_AS NULL ,
	[SmTS] [datetime] NULL ,
	[SmExMessage] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CS_AS NULL ,
	[SmXmlMessage] [image] NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[TipoTransazione]    Script Date: 20/10/2005 16.32.01 ******/
CREATE TABLE [dbo].[TipoTransazione] (
	[TipoTransazione] [tipoTipoTransazione] NOT NULL ,
	[DescrizioneTipoTransazione] [nvarchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[TraceMsg]    Script Date: 20/10/2005 16.32.01 ******/
CREATE TABLE [dbo].[TraceMsg] (
	[IdMsg] [int] IDENTITY (1, 1) NOT NULL ,
	[Msg] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Utente]    Script Date: 20/10/2005 16.32.01 ******/
CREATE TABLE [dbo].[Utente] (
	[CodiceUtente] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Nome] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Cognome] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Offerta]    Script Date: 20/10/2005 16.32.02 ******/
CREATE TABLE [dbo].[Offerta] (
	[IdSessioneMercato] [int] NOT NULL ,
	[IdContratto] [int] NOT NULL ,
	[IdOfferta] [int] IDENTITY (1, 1) NOT NULL ,
	[CodiceUtente] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CodiceOperatore] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TipoOfferta] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TSCreazione] [datetime] NOT NULL ,
	[TSAbbinamento] [datetime] NOT NULL ,
	[OffertaAMercato] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PrezzoUnitario] [float] NOT NULL ,
	[QtyRichiesta] [int] NOT NULL ,
	[QtyResidua] [int] NOT NULL ,
	[StatoOfferta] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Compatibile] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[NoteOfferta] [nvarchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[OperatoreOTC] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CodiceOTC] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SessioneMercatoContratto]    Script Date: 20/10/2005 16.32.02 ******/
CREATE TABLE [dbo].[SessioneMercatoContratto] (
	[IdSessioneMercato] [int] NOT NULL ,
	[IdContratto] [int] NOT NULL ,
	[LastPrice] [float] NULL ,
	[LastTime] [datetime] NULL ,
	[LastQty] [int] NULL ,
	[LastIsOTC] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[MaxPrice] [float] NULL ,
	[MinPrice] [float] NULL ,
	[Volume] [int] NULL ,
	[ConvPrice] [float] NULL ,
	[OffPrice] [float] NULL ,
	[RefPrice] [float] NULL ,
	[BidIdOfferta] [int] NULL ,
	[BidPrice] [float] NULL ,
	[BidQty] [int] NULL ,
	[BidCodiceOperatore] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[BidTS] [datetime] NULL ,
	[AskIdOfferta] [int] NULL ,
	[AskPrice] [float] NULL ,
	[AskQty] [int] NULL ,
	[AskCodiceOperatore] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[AskTS] [datetime] NULL ,
	[Indicators] [tinyint] NOT NULL ,
	[IndicatorBidChangeTS] [datetime] NULL ,
	[IndicatorAskChangeTS] [datetime] NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SessioneMercatoProfiloOrario]    Script Date: 20/10/2005 16.32.03 ******/
CREATE TABLE [dbo].[SessioneMercatoProfiloOrario] (
	[IdSessioneMercato] [int] NOT NULL ,
	[CodiceProfilo] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TipoGiorno] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[MeseUltimaDomenica] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[DescrizioneProfilo] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H01] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H02] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H03] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H04] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H05] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H06] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H07] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H08] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H09] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H10] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H11] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H12] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H13] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H14] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H15] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H16] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H17] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H18] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H19] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H20] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H21] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H22] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H23] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H24] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[H25] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[TransazioneIn]    Script Date: 20/10/2005 16.32.03 ******/
CREATE TABLE [dbo].[TransazioneIn] (
	[IdMessaggioIn] [int] NOT NULL ,
	[ProgressivoTransazioneIn] [int] NOT NULL ,
	[CodiceTransazioneIn] [tipoCodiceTransazione] NOT NULL ,
	[TipoTransazione] [tipoTipoTransazione] NOT NULL ,
	[BlobTransazione] [image] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Abbinamento]    Script Date: 20/10/2005 16.32.03 ******/
CREATE TABLE [dbo].[Abbinamento] (
	[IdSessioneMercato] [int] NOT NULL ,
	[IdContratto] [int] NOT NULL ,
	[IdAbbinamento] [int] IDENTITY (1, 1) NOT NULL ,
	[IdOffertaAcquisto] [int] NOT NULL ,
	[IdOffertaVendita] [int] NOT NULL ,
	[PrezzoUnitario] [float] NOT NULL ,
	[QtyAbbinata] [int] NOT NULL ,
	[TSAbbinamento] [datetime] NOT NULL ,
	[TSOAAbbinamento] [datetime] NOT NULL ,
	[TSOVAbbinamento] [datetime] NOT NULL ,
	[AbbinamentoCausatoDa] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[TransazioneOut]    Script Date: 20/10/2005 16.32.04 ******/
CREATE TABLE [dbo].[TransazioneOut] (
	[IdMessaggioOut] [int] NOT NULL ,
	[ProgressivoTransazioneOut] [int] NOT NULL ,
	[CodiceTransazioneOut] [tipoCodiceTransazione] NOT NULL ,
	[TipoTransazione] [tipoTipoTransazione] NOT NULL ,
	[IdMessagionIn] [int] NULL ,
	[ProgressivoTransazioneIn] [int] NULL ,
	[StatoTransazione] [tipoStatoTransazione] NULL ,
	[BlobTransazione] [image] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[OffertaTransazioneOut]    Script Date: 20/10/2005 16.32.04 ******/
CREATE TABLE [dbo].[OffertaTransazioneOut] (
	[IdSessioneMercato] [int] NOT NULL ,
	[IdContratto] [int] NOT NULL ,
	[IdOfferta] [int] NOT NULL ,
	[IdMessaggioOut] [int] NOT NULL ,
	[ProgressivoTransazioneOut] [int] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Contratto] WITH NOCHECK ADD 
	CONSTRAINT [PK_Contratto] PRIMARY KEY  CLUSTERED 
	(
		[IdContratto]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[DailyActivityLog] WITH NOCHECK ADD 
	CONSTRAINT [PK_DailyActivity] PRIMARY KEY  CLUSTERED 
	(
		[IdSessioneMercato],
		[IdDailyActivity]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[DataDelivery] WITH NOCHECK ADD 
	CONSTRAINT [PK_DataDelivery] PRIMARY KEY  CLUSTERED 
	(
		[DataDelivery]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[MessaggioIn] WITH NOCHECK ADD 
	CONSTRAINT [PK_MessaggioIn] PRIMARY KEY  CLUSTERED 
	(
		[IdMessaggioIn]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[MessaggioOut] WITH NOCHECK ADD 
	CONSTRAINT [PK_MessaggioOut] PRIMARY KEY  CLUSTERED 
	(
		[IdMessaggioOut]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Operatore] WITH NOCHECK ADD 
	CONSTRAINT [PK_Operatore] PRIMARY KEY  CLUSTERED 
	(
		[CodiceOperatore]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Parametri] WITH NOCHECK ADD 
	CONSTRAINT [PK_Parametri] PRIMARY KEY  CLUSTERED 
	(
		[Codice]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ProfiloOrario] WITH NOCHECK ADD 
	CONSTRAINT [PK_ProfiloOrario] PRIMARY KEY  CLUSTERED 
	(
		[CodiceProfilo],
		[TipoGiorno],
		[MeseUltimaDomenica]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SaldoFisico] WITH NOCHECK ADD 
	CONSTRAINT [PK_SaldoFisico] PRIMARY KEY  CLUSTERED 
	(
		[CodiceOperatore],
		[DataDelivery]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SessioneMercato] WITH NOCHECK ADD 
	CONSTRAINT [PK_SessioneMercato] PRIMARY KEY  CLUSTERED 
	(
		[IdSessioneMercato]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[TipoTransazione] WITH NOCHECK ADD 
	CONSTRAINT [PK_TipoTransazione] PRIMARY KEY  CLUSTERED 
	(
		[TipoTransazione]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Utente] WITH NOCHECK ADD 
	CONSTRAINT [PK_Utente] PRIMARY KEY  CLUSTERED 
	(
		[CodiceUtente]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Offerta] WITH NOCHECK ADD 
	CONSTRAINT [PK_Offerta] PRIMARY KEY  CLUSTERED 
	(
		[IdSessioneMercato],
		[IdContratto],
		[IdOfferta]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SessioneMercatoContratto] WITH NOCHECK ADD 
	CONSTRAINT [PK_SessioneMercatoContratto] PRIMARY KEY  CLUSTERED 
	(
		[IdSessioneMercato],
		[IdContratto]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SessioneMercatoProfiloOrario] WITH NOCHECK ADD 
	CONSTRAINT [PK_SessioneMercatoProfiloOrario] PRIMARY KEY  CLUSTERED 
	(
		[IdSessioneMercato],
		[CodiceProfilo],
		[TipoGiorno],
		[MeseUltimaDomenica]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[TransazioneIn] WITH NOCHECK ADD 
	CONSTRAINT [PK_TransazioneIn] PRIMARY KEY  CLUSTERED 
	(
		[IdMessaggioIn],
		[ProgressivoTransazioneIn]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Abbinamento] WITH NOCHECK ADD 
	CONSTRAINT [PK_Abbinamento] PRIMARY KEY  CLUSTERED 
	(
		[IdSessioneMercato],
		[IdContratto],
		[IdAbbinamento]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[TransazioneOut] WITH NOCHECK ADD 
	CONSTRAINT [PK_TransazioneOut] PRIMARY KEY  CLUSTERED 
	(
		[IdMessaggioOut],
		[ProgressivoTransazioneOut]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[OffertaTransazioneOut] WITH NOCHECK ADD 
	CONSTRAINT [PK_OffertaTransazioneOut] PRIMARY KEY  CLUSTERED 
	(
		[IdSessioneMercato],
		[IdContratto],
		[IdOfferta],
		[IdMessaggioOut],
		[ProgressivoTransazioneOut]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Contratto] ADD 
	CONSTRAINT [DF_Contratto_DescrizioneContratto] DEFAULT ('') FOR [DescrizioneContratto],
	CONSTRAINT [DF_Contratto_CodiceZonaRiferimento] DEFAULT ('NAT') FOR [CodiceZonaRiferimento],
	CONSTRAINT [CK_Contratto_DurataContratto] CHECK ([DurataDelivery] = 'M' or ([DurataDelivery] = 'W' or [DurataDelivery] = 'D'))
GO

ALTER TABLE [dbo].[Operatore] ADD 
	CONSTRAINT [DF_Operatore_AbilitazioneMercato] DEFAULT ('S') FOR [AbilitazioneMercato],
	CONSTRAINT [DF_Operatore_AbilitazioneDelivery] DEFAULT ('S') FOR [AbilitazioneDelivery],
	CONSTRAINT [CK_Operatore_AbilitazioneDelivery] CHECK ([AbilitazioneDelivery] = 'N' or [AbilitazioneDelivery] = 'S'),
	CONSTRAINT [CK_Operatore_AbilitazioneMercato] CHECK ([AbilitazioneMercato] = 'N' or [AbilitazioneMercato] = 'S')
GO

ALTER TABLE [dbo].[ProfiloOrario] ADD 
	CONSTRAINT [DF_ProfiloOrario_CodiceProfilo] DEFAULT ('FER') FOR [CodiceProfilo],
	CONSTRAINT [DF_ProfiloOrario_OraLegale] DEFAULT ('*') FOR [MeseUltimaDomenica],
	CONSTRAINT [DF_ProfiloOrario_Cancellato] DEFAULT (0) FOR [Cancellato],
	CONSTRAINT [DF_ProfiloOrario_H01] DEFAULT (' ') FOR [H01],
	CONSTRAINT [DF_ProfiloOrario_H02] DEFAULT (' ') FOR [H02],
	CONSTRAINT [DF_ProfiloOrario_H03] DEFAULT (' ') FOR [H03],
	CONSTRAINT [DF_ProfiloOrario_H04] DEFAULT (' ') FOR [H04],
	CONSTRAINT [DF_ProfiloOrario_H05] DEFAULT (' ') FOR [H05],
	CONSTRAINT [DF_ProfiloOrario_H06] DEFAULT (' ') FOR [H06],
	CONSTRAINT [DF_ProfiloOrario_H07] DEFAULT (' ') FOR [H07],
	CONSTRAINT [DF_ProfiloOrario_H08] DEFAULT (' ') FOR [H08],
	CONSTRAINT [DF_ProfiloOrario_H09] DEFAULT (' ') FOR [H09],
	CONSTRAINT [DF_ProfiloOrario_H10] DEFAULT (' ') FOR [H10],
	CONSTRAINT [DF_ProfiloOrario_H11] DEFAULT (' ') FOR [H11],
	CONSTRAINT [DF_ProfiloOrario_H12] DEFAULT (' ') FOR [H12],
	CONSTRAINT [DF_ProfiloOrario_H13] DEFAULT (' ') FOR [H13],
	CONSTRAINT [DF_ProfiloOrario_H14] DEFAULT (' ') FOR [H14],
	CONSTRAINT [DF_ProfiloOrario_H15] DEFAULT (' ') FOR [H15],
	CONSTRAINT [DF_ProfiloOrario_H16] DEFAULT (' ') FOR [H16],
	CONSTRAINT [DF_ProfiloOrario_H17] DEFAULT (' ') FOR [H17],
	CONSTRAINT [DF_ProfiloOrario_H18] DEFAULT (' ') FOR [H18],
	CONSTRAINT [DF_ProfiloOrario_H19] DEFAULT (' ') FOR [H19],
	CONSTRAINT [DF_ProfiloOrario_H20] DEFAULT (' ') FOR [H20],
	CONSTRAINT [DF_ProfiloOrario_H21] DEFAULT (' ') FOR [H21],
	CONSTRAINT [DF_ProfiloOrario_H22] DEFAULT (' ') FOR [H22],
	CONSTRAINT [DF_ProfiloOrario_H23] DEFAULT (' ') FOR [H23],
	CONSTRAINT [DF_ProfiloOrario_H24] DEFAULT (' ') FOR [H24],
	CONSTRAINT [DF_ProfiloOrario_H25] DEFAULT (' ') FOR [H25],
	CONSTRAINT [CK_ProfiloOrario_CodiceProfilo] CHECK ([CodiceProfilo] = 'OFPK' or ([CodiceProfilo] = 'PEAK' or [CodiceProfilo] = 'BSLD')),
	CONSTRAINT [CK_ProfiloOrario_MeseUltimaDomenica] CHECK ([MeseUltimaDomenica] = 'M' or ([MeseUltimaDomenica] = 'O' or [MeseUltimaDomenica] = '*')),
	CONSTRAINT [CK_ProfiloOrario_TipoGiorno] CHECK ([TipoGiorno] = 'FEST' or [TipoGiorno] = 'FER')
GO

ALTER TABLE [dbo].[SaldoFisico] ADD 
	CONSTRAINT [DF_SaldoFisico_Immissione] DEFAULT (0) FOR [Immissione],
	CONSTRAINT [DF_SaldoFisico_Prelievo] DEFAULT (0) FOR [Prelievo],
	CONSTRAINT [DF_SaldoFisico_H01] DEFAULT (0) FOR [H01],
	CONSTRAINT [DF_SaldoFisico_H02] DEFAULT (0) FOR [H02],
	CONSTRAINT [DF_SaldoFisico_H03] DEFAULT (0) FOR [H03],
	CONSTRAINT [DF_SaldoFisico_H04] DEFAULT (0) FOR [H04],
	CONSTRAINT [DF_SaldoFisico_H05] DEFAULT (0) FOR [H05],
	CONSTRAINT [DF_SaldoFisico_H06] DEFAULT (0) FOR [H06],
	CONSTRAINT [DF_SaldoFisico_H07] DEFAULT (0) FOR [H07],
	CONSTRAINT [DF_SaldoFisico_H08] DEFAULT (0) FOR [H08],
	CONSTRAINT [DF_SaldoFisico_H09] DEFAULT (0) FOR [H09],
	CONSTRAINT [DF_SaldoFisico_H10] DEFAULT (0) FOR [H10],
	CONSTRAINT [DF_SaldoFisico_H11] DEFAULT (0) FOR [H11],
	CONSTRAINT [DF_SaldoFisico_H12] DEFAULT (0) FOR [H12],
	CONSTRAINT [DF_SaldoFisico_H13] DEFAULT (0) FOR [H13],
	CONSTRAINT [DF_SaldoFisico_H14] DEFAULT (0) FOR [H14],
	CONSTRAINT [DF_SaldoFisico_H15] DEFAULT (0) FOR [H15],
	CONSTRAINT [DF_SaldoFisico_H16] DEFAULT (0) FOR [H16],
	CONSTRAINT [DF_SaldoFisico_H17] DEFAULT (0) FOR [H17],
	CONSTRAINT [DF_SaldoFisico_H18] DEFAULT (0) FOR [H18],
	CONSTRAINT [DF_SaldoFisico_H19] DEFAULT (0) FOR [H19],
	CONSTRAINT [DF_SaldoFisico_H20] DEFAULT (0) FOR [H20],
	CONSTRAINT [DF_SaldoFisico_H21] DEFAULT (0) FOR [H21],
	CONSTRAINT [DF_SaldoFisico_H22] DEFAULT (0) FOR [H22],
	CONSTRAINT [DF_SaldoFisico_H23] DEFAULT (0) FOR [H23],
	CONSTRAINT [DF_SaldoFisico_H24] DEFAULT (0) FOR [H24],
	CONSTRAINT [DF_SaldoFisico_H25] DEFAULT (0) FOR [H25]
GO

ALTER TABLE [dbo].[SessioneMercato] ADD 
	CONSTRAINT [DF_SessioneMercato_StatoSessione] DEFAULT ('PREDIPOSTA') FOR [StatoSessione],
	CONSTRAINT [CK_SessioneMercato] CHECK ([StatoSessione] = 'TERMINATA' or [StatoSessione] = 'NUOVA' or [StatoSessione] = 'SOSPESA' or ([StatoSessione] = 'PREDISPOSTA' or ([StatoSessione] = 'CHIUSA' or [StatoSessione] = 'APERTA') or ([StatoSessione] = 'CHIUSA' or [StatoSessione] = 'APERTA' or [StatoSessione] = 'FALLITA')))
GO

 CREATE  INDEX [IX_SessioneMercato] ON [dbo].[SessioneMercato]([StatoSessione]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Offerta] ADD 
	CONSTRAINT [DF_Offerta_TSCreazione] DEFAULT (getdate()) FOR [TSCreazione],
	CONSTRAINT [DF_Offerta_StatoOfferta] DEFAULT ('VA') FOR [StatoOfferta],
	CONSTRAINT [DF_Offerta_Compatibile] DEFAULT ('S') FOR [Compatibile],
	CONSTRAINT [DF_Offerta_NoteOfferta] DEFAULT ('') FOR [NoteOfferta],
	CONSTRAINT [DF_Offerta_OperatoreOTC] DEFAULT ('') FOR [OperatoreOTC],
	CONSTRAINT [DF_Offerta_CodiceOTC] DEFAULT ('') FOR [CodiceOTC],
	CONSTRAINT [CK_Offerta_Compatibile] CHECK ([Compatibile] = 'N' or [Compatibile] = 'S'),
	CONSTRAINT [CK_Offerta_OffertaAMercato] CHECK ([OffertaAMercato] = 'N' or [OffertaAMercato] = 'S'),
	CONSTRAINT [CK_Offerta_StatoOfferta] CHECK ([StatoOfferta] = 'RM' or [StatoOfferta] = 'NA' or [StatoOfferta] = 'VA'),
	CONSTRAINT [CK_Offerta_TipoOfferta] CHECK ([TipoOfferta] = 'V' or [TipoOfferta] = 'A')
GO

ALTER TABLE [dbo].[SessioneMercatoContratto] ADD 
	CONSTRAINT [DF_SessioneMercatoContratto_Indicators] DEFAULT (0) FOR [Indicators],
	CONSTRAINT [CK_SessioneMercatoContratto_LastIsOTC] CHECK ([LastIsOTC] = 'N' or [LastIsOTC] = 'S')
GO

ALTER TABLE [dbo].[SessioneMercatoProfiloOrario] ADD 
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H01] DEFAULT (' ') FOR [H01],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H02] DEFAULT (' ') FOR [H02],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H03] DEFAULT (' ') FOR [H03],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H04] DEFAULT (' ') FOR [H04],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H05] DEFAULT (' ') FOR [H05],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H06] DEFAULT (' ') FOR [H06],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H07] DEFAULT (' ') FOR [H07],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H08] DEFAULT (' ') FOR [H08],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H09] DEFAULT (' ') FOR [H09],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H10] DEFAULT (' ') FOR [H10],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H11] DEFAULT (' ') FOR [H11],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H12] DEFAULT (' ') FOR [H12],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H13] DEFAULT (' ') FOR [H13],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H14] DEFAULT (' ') FOR [H14],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H15] DEFAULT (' ') FOR [H15],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H16] DEFAULT (' ') FOR [H16],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H17] DEFAULT (' ') FOR [H17],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H18] DEFAULT (' ') FOR [H18],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H19] DEFAULT (' ') FOR [H19],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H20] DEFAULT (' ') FOR [H20],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H21] DEFAULT (' ') FOR [H21],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H22] DEFAULT (' ') FOR [H22],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H23] DEFAULT (' ') FOR [H23],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H24] DEFAULT (' ') FOR [H24],
	CONSTRAINT [DF_SessioneMercatoProfiloOrario_H25] DEFAULT (' ') FOR [H25]
GO

ALTER TABLE [dbo].[Abbinamento] ADD 
	CONSTRAINT [DF_Abbinamento_TSAbbinamento] DEFAULT (getdate()) FOR [TSAbbinamento],
	CONSTRAINT [CK_Abbinamento_AbbinamentoCausatoDa] CHECK ([AbbinamentoCausatoDa] = 'V' or [AbbinamentoCausatoDa] = 'A')
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[MessaggioIn]  TO [bipex_user]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[MessaggioOut]  TO [bipex_user]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[TipoTransazione]  TO [bipex_user]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[TransazioneIn]  TO [bipex_user]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[TransazioneOut]  TO [bipex_user]
GO

ALTER TABLE [dbo].[Offerta] ADD 
	CONSTRAINT [FK_Offerta_Contratto] FOREIGN KEY 
	(
		[IdContratto]
	) REFERENCES [dbo].[Contratto] (
		[IdContratto]
	),
	CONSTRAINT [FK_Offerta_Operatore] FOREIGN KEY 
	(
		[CodiceOperatore]
	) REFERENCES [dbo].[Operatore] (
		[CodiceOperatore]
	),
	CONSTRAINT [FK_Offerta_SessioneMercato] FOREIGN KEY 
	(
		[IdSessioneMercato]
	) REFERENCES [dbo].[SessioneMercato] (
		[IdSessioneMercato]
	),
	CONSTRAINT [FK_Offerta_Utente] FOREIGN KEY 
	(
		[CodiceUtente]
	) REFERENCES [dbo].[Utente] (
		[CodiceUtente]
	)
GO

ALTER TABLE [dbo].[SessioneMercatoContratto] ADD 
	CONSTRAINT [FK_SessioneMercatoContratto_Contratto] FOREIGN KEY 
	(
		[IdContratto]
	) REFERENCES [dbo].[Contratto] (
		[IdContratto]
	),
	CONSTRAINT [FK_SessioneMercatoContratto_SessioneMercato] FOREIGN KEY 
	(
		[IdSessioneMercato]
	) REFERENCES [dbo].[SessioneMercato] (
		[IdSessioneMercato]
	)
GO

ALTER TABLE [dbo].[SessioneMercatoProfiloOrario] ADD 
	CONSTRAINT [FK_SessioneMercatoProfiloOrario_ProfiloOrario] FOREIGN KEY 
	(
		[CodiceProfilo],
		[TipoGiorno],
		[MeseUltimaDomenica]
	) REFERENCES [dbo].[ProfiloOrario] (
		[CodiceProfilo],
		[TipoGiorno],
		[MeseUltimaDomenica]
	),
	CONSTRAINT [FK_SessioneMercatoProfiloOrario_SessioneMercato] FOREIGN KEY 
	(
		[IdSessioneMercato]
	) REFERENCES [dbo].[SessioneMercato] (
		[IdSessioneMercato]
	)
GO

ALTER TABLE [dbo].[TransazioneIn] ADD 
	CONSTRAINT [FK_TransazioneIn_MessaggioIn] FOREIGN KEY 
	(
		[IdMessaggioIn]
	) REFERENCES [dbo].[MessaggioIn] (
		[IdMessaggioIn]
	),
	CONSTRAINT [FK_TransazioneIn_TipoTransazione] FOREIGN KEY 
	(
		[TipoTransazione]
	) REFERENCES [dbo].[TipoTransazione] (
		[TipoTransazione]
	)
GO

ALTER TABLE [dbo].[Abbinamento] ADD 
	CONSTRAINT [FK_Abbinamento_Offerta_Acquisto] FOREIGN KEY 
	(
		[IdSessioneMercato],
		[IdContratto],
		[IdOffertaAcquisto]
	) REFERENCES [dbo].[Offerta] (
		[IdSessioneMercato],
		[IdContratto],
		[IdOfferta]
	),
	CONSTRAINT [FK_Abbinamento_Offerta_Vendita] FOREIGN KEY 
	(
		[IdSessioneMercato],
		[IdContratto],
		[IdOffertaVendita]
	) REFERENCES [dbo].[Offerta] (
		[IdSessioneMercato],
		[IdContratto],
		[IdOfferta]
	)
GO

ALTER TABLE [dbo].[TransazioneOut] ADD 
	CONSTRAINT [FK_TransazioneOut_MessaggioOut] FOREIGN KEY 
	(
		[IdMessaggioOut]
	) REFERENCES [dbo].[MessaggioOut] (
		[IdMessaggioOut]
	),
	CONSTRAINT [FK_TransazioneOut_TipoTransazione] FOREIGN KEY 
	(
		[TipoTransazione]
	) REFERENCES [dbo].[TipoTransazione] (
		[TipoTransazione]
	),
	CONSTRAINT [FK_TransazioneOut_TransazioneIn] FOREIGN KEY 
	(
		[IdMessagionIn],
		[ProgressivoTransazioneIn]
	) REFERENCES [dbo].[TransazioneIn] (
		[IdMessaggioIn],
		[ProgressivoTransazioneIn]
	)
GO

ALTER TABLE [dbo].[OffertaTransazioneOut] ADD 
	CONSTRAINT [FK_OffertaTransazioneOut_Offerta] FOREIGN KEY 
	(
		[IdSessioneMercato],
		[IdContratto],
		[IdOfferta]
	) REFERENCES [dbo].[Offerta] (
		[IdSessioneMercato],
		[IdContratto],
		[IdOfferta]
	),
	CONSTRAINT [FK_OffertaTransazioneOut_TransazioneOut] FOREIGN KEY 
	(
		[IdMessaggioOut],
		[ProgressivoTransazioneOut]
	) REFERENCES [dbo].[TransazioneOut] (
		[IdMessaggioOut],
		[ProgressivoTransazioneOut]
	)
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  View dbo.OffertaAcquistoBook    Script Date: 20/10/2005 16.32.04 ******/
CREATE VIEW dbo.OffertaAcquistoBook
AS
SELECT     *
FROM         dbo.Offerta
WHERE     (TipoOfferta = 'A') AND (StatoOfferta = 'VA') AND (Compatibile = 'S') AND (QtyResidua > 0)



GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  SELECT  ON [dbo].[OffertaAcquistoBook]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  View dbo.OffertaVenditaBook    Script Date: 20/10/2005 16.32.04 ******/
CREATE VIEW dbo.OffertaVenditaBook
AS
SELECT     *
FROM         dbo.Offerta
WHERE     (TipoOfferta = 'V') AND (StatoOfferta = 'VA') AND (Compatibile = 'S') AND (QtyResidua > 0)



GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  SELECT  ON [dbo].[OffertaVenditaBook]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.Gest_CheckSaldoFisico    Script Date: 20/10/2005 16.32.04 ******/



CREATE        PROCEDURE dbo.Gest_CheckSaldoFisico
AS

-- Inizio crea una tabella in memoria di come dovrebbe essere il saldofisico (#sf)

if Object_Id('tempdb..#sf') is Not Null drop table #sf
create table #sf
(
	CodiceOperatore varchar(8) /*tipoCodiceOperatore*/ NOT null, 
	DataDelivery smalldatetime not null,
	Immissione int not null,
	Prelievo int not null,
	H01 int NOT NULL ,
	H02 int NOT NULL ,
	H03 int NOT NULL ,
	H04 int NOT NULL ,
	H05 int NOT NULL ,
	H06 int NOT NULL ,
	H07 int NOT NULL ,
	H08 int NOT NULL ,
	H09 int NOT NULL ,
	H10 int NOT NULL ,
	H11 int NOT NULL ,
	H12 int NOT NULL ,
	H13 int NOT NULL ,
	H14 int NOT NULL ,
	H15 int NOT NULL ,
	H16 int NOT NULL ,
	H17 int NOT NULL ,
	H18 int NOT NULL ,
	H19 int NOT NULL ,
	H20 int NOT NULL ,
	H21 int NOT NULL ,
	H22 int NOT NULL ,
	H23 int NOT NULL ,
	H24 int NOT NULL ,
	H25 int NOT NULL, 
	CONSTRAINT PK PRIMARY KEY CLUSTERED (CodiceOperatore, DataDelivery)
)

-- Fine crea una tabella in memoria di come dovrebbe essere il saldofisico

-- Inizio riempie la tabella in memoria saldofisico

insert into #sf
--
	select
	CodiceOperatore,
	DataDelivery,
	Immissione= sum(Immissione),
	Prelievo  = sum(Prelievo),
	H01 = sum(H01),
	H02 = sum(H02),
	H03 = sum(H03),
	H04 = sum(H04),
	H05 = sum(H05),
	H06 = sum(H06),
	H07 = sum(H07),
	H08 = sum(H08),
	H09 = sum(H09),
	H10 = sum(H10),
	H11 = sum(H11),
	H12 = sum(H12),
	H13 = sum(H13),
	H14 = sum(H14),
	H15 = sum(H15),
	H16 = sum(H16),
	H17 = sum(H17),
	H18 = sum(H18),
	H19 = sum(H19),
	H20 = sum(H20),
	H21 = sum(H21),
	H22 = sum(H22),
	H23 = sum(H23),
	H24 = sum(H24),
	H25 = sum(H25)
	from 
	(
		select
		CodiceOperatore  = OV.CodiceOperatore,
		DataDelivery = T.DataDelivery,
		-- OPSF.K,
		H01 = sum(case PO.H01 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H02 = sum(case PO.H02 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H03 = sum(case PO.H03 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H04 = sum(case PO.H04 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H05 = sum(case PO.H05 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H06 = sum(case PO.H06 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H07 = sum(case PO.H07 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H08 = sum(case PO.H08 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H09 = sum(case PO.H09 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H10 = sum(case PO.H10 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H11 = sum(case PO.H11 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H12 = sum(case PO.H12 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H13 = sum(case PO.H13 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H14 = sum(case PO.H14 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H15 = sum(case PO.H15 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H16 = sum(case PO.H16 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H17 = sum(case PO.H17 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H18 = sum(case PO.H18 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H19 = sum(case PO.H19 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H20 = sum(case PO.H20 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H21 = sum(case PO.H21 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H22 = sum(case PO.H22 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H23 = sum(case PO.H23 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H24 = sum(case PO.H24 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H25 = sum(case PO.H25 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),

		Immissione =
			sum(case PO.H01 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H02 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H03 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H04 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H05 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H06 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H07 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H08 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H09 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H10 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H11 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H12 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H13 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H14 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H15 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H16 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H17 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H18 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H19 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H20 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H21 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H22 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H23 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H24 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H25 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),

		Prelievo = 0

	
		from Abbinamento AB

		-- Prova Filtro x Sessione FALLITA
		inner join SessioneMercato SM 
		on SM.IdSessioneMercato = AB.IdSessioneMercato
	
		inner join Contratto C
		on C.IdContratto = AB.IdContratto
	
		inner join DataDelivery T
		on C.DataInizioDelivery <= T.DataDelivery and T.DataDelivery <= c.DataFineDelivery

		inner join SessioneMercatoProfiloOrario PO
		on  PO.IdSessioneMercato = AB.IdSessioneMercato
		and PO.CodiceProfilo = C.CodiceProfilo
		and PO.TipoGiorno = T.TipoGiorno
		and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
	
		inner join Offerta OV
		on OV.IdOfferta = AB.IdOffertaVendita
	
		cross join
		(
			select 1 K
		) OPSF
		where
		1=1
		and (SM.StatoSessione <> 'FALLITA')
	
		group by OV.CodiceOperatore, T.DataDelivery, OPSF.K
	
	union
	
		select
		CodiceOperatore  = OA.CodiceOperatore,
		DataDelivery = T.DataDelivery,
		-- OPSF.K,
		H01 = sum(case PO.H01 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H02 = sum(case PO.H02 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H03 = sum(case PO.H03 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H04 = sum(case PO.H04 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H05 = sum(case PO.H05 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H06 = sum(case PO.H06 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H07 = sum(case PO.H07 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H08 = sum(case PO.H08 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H09 = sum(case PO.H09 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H10 = sum(case PO.H10 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H11 = sum(case PO.H11 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H12 = sum(case PO.H12 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H13 = sum(case PO.H13 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H14 = sum(case PO.H14 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H15 = sum(case PO.H15 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H16 = sum(case PO.H16 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H17 = sum(case PO.H17 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H18 = sum(case PO.H18 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H19 = sum(case PO.H19 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H20 = sum(case PO.H20 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H21 = sum(case PO.H21 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H22 = sum(case PO.H22 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H23 = sum(case PO.H23 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H24 = sum(case PO.H24 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H25 = sum(case PO.H25 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),

		Immissione = 0,
		Prelievo =
			sum(case PO.H01 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H02 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H03 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H04 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H05 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H06 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H07 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H08 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H09 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H10 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H11 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H12 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H13 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H14 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H15 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H16 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H17 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H18 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H19 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H20 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H21 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H22 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H23 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H24 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H25 when '1' then OPSF.K*AB.QtyAbbinata else 0 end)

	
		from Abbinamento AB

		-- Prova Filtro x Sessione FALLITA
		inner join SessioneMercato SM 
		on SM.IdSessioneMercato = AB.IdSessioneMercato
	
		inner join Contratto C
		on C.IdContratto = AB.IdContratto
	
		inner join DataDelivery T
		on C.DataInizioDelivery <= T.DataDelivery and T.DataDelivery <= c.DataFineDelivery

		inner join SessioneMercatoProfiloOrario PO
		on 1=1
		and PO.IdSessioneMercato = AB.IdSessioneMercato
		and PO.CodiceProfilo = C.CodiceProfilo

		and PO.TipoGiorno = T.TipoGiorno
		and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
	
	 	inner join Offerta OA
	 	on OA.IdOfferta = AB.IdOffertaAcquisto
	
		cross join
		(
			select -1 K
		) OPSF
		where
		1=1
		and (SM.StatoSessione <> 'FALLITA')
	
		group by OA.CodiceOperatore, T.DataDelivery, OPSF.K
	) W
	group by W.CodiceOperatore, W.DataDelivery
	
-- Fine riempie la tabella in memoria saldofisico (#sf)

-- Test #sf
-- select * from #sf
-- select * from SaldoFisico

-- Verifica eventuale mancanza di righe in table SaldoFisico
-- SELECT *
-- FROM #sf
-- WHERE not exists
-- (
-- 	select * from SaldoFisico
-- )
--

-- Verifica eventuale ridondanza di righe in table SaldoFisico
-- SELECT *
-- FROM SaldoFisico
-- WHERE not exists
-- (
-- 	select * from #sf
-- )
--

-- Inizio confronta valori in table SaldoFisico (tramite checksum)

select 
CodiceOperatore = Attuale.CodiceOperatore,
DataDelivery = Attuale.DataDelivery,
DH01 = Attuale.H01 - Calcolata.H01, DH02 = Attuale.H02 - Calcolata.H02,
DH03 = Attuale.H03 - Calcolata.H03, DH04 = Attuale.H04 - Calcolata.H04,
DH05 = Attuale.H05 - Calcolata.H05, DH06 = Attuale.H06 - Calcolata.H06,
DH07 = Attuale.H07 - Calcolata.H07, DH08 = Attuale.H08 - Calcolata.H08,
DH09 = Attuale.H09 - Calcolata.H09, DH10 = Attuale.H10 - Calcolata.H10,
DH11 = Attuale.H11 - Calcolata.H11, DH12 = Attuale.H12 - Calcolata.H12,
DH13 = Attuale.H13 - Calcolata.H13, DH14 = Attuale.H14 - Calcolata.H14,
DH15 = Attuale.H15 - Calcolata.H15, DH16 = Attuale.H16 - Calcolata.H16,
DH17 = Attuale.H17 - Calcolata.H17, DH18 = Attuale.H18 - Calcolata.H18,
DH19 = Attuale.H19 - Calcolata.H19, DH20 = Attuale.H20 - Calcolata.H20,
DH21 = Attuale.H21 - Calcolata.H21, DH22 = Attuale.H22 - Calcolata.H22,
DH23 = Attuale.H23 - Calcolata.H23, DH24 = Attuale.H24 - Calcolata.H24,
DH25 = Attuale.H25 - Calcolata.H25
from
SaldoFisico Attuale
inner join #sf Calcolata
on 
    Attuale.CodiceOperatore  = Calcolata.CodiceOperatore
and Attuale.DataDelivery = Calcolata.DataDelivery
where
(
Calcolata.H01 + Calcolata.H02 + Calcolata.H03 +
Calcolata.H04 + Calcolata.H05 + Calcolata.H06 +
Calcolata.H07 + Calcolata.H08 + Calcolata.H09 +
Calcolata.H10 + Calcolata.H11 + Calcolata.H12 +
Calcolata.H13 + Calcolata.H14 + Calcolata.H15 +
Calcolata.H16 + Calcolata.H17 + Calcolata.H18 +
Calcolata.H19 + Calcolata.H20 + Calcolata.H21 +
Calcolata.H22 + Calcolata.H23 + Calcolata.H24 +
Calcolata.H25
) <> (
Attuale.H01 + Attuale.H02 + Attuale.H03 +
Attuale.H04 + Attuale.H05 + Attuale.H06 +
Attuale.H07 + Attuale.H08 + Attuale.H09 +
Attuale.H10 + Attuale.H11 + Attuale.H12 +
Attuale.H13 + Attuale.H14 + Attuale.H15 +
Attuale.H16 + Attuale.H17 + Attuale.H18 +
Attuale.H19 + Attuale.H20 + Attuale.H21 +
Attuale.H22 + Attuale.H23 + Attuale.H24 +
Attuale.H25
)

-- Fine confronta valori in table SaldoFisico (tramite checksum)




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.OraCorrente    Script Date: 20/10/2005 16.32.04 ******/
CREATE PROCEDURE dbo.OraCorrente
	@tsNow as datetime out
AS

set @tsNow = getdate()

return
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[OraCorrente]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SmLog_Insert    Script Date: 20/10/2005 16.32.04 ******/
------------------------------------------------------------------------------------------------------------------------
-- Date Created: marted� 28 giugno 2005
-- Created By:   Generated by CodeSmith
------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].SmLog_Insert
	@SmCategory varchar(32),
	@SmMessage varchar(256),
	@SmApplication varchar(256),
	@SmTS datetime,
	@SmExMessage varchar(1024),
	@SmXmlMessage image,

	@OutSmId int out
AS

-- THIS STORED PROCEDURE NEEDS TO BE MANUALLY COMPLETED
-- MULITPLE PRIMARY KEY MEMBERS OR NON-GUID/INT PRIMARY KEY

INSERT INTO [dbo].[SmLog] (
	[SmCategory],
	[SmMessage],
	[SmApplication],
	[SmTS],
	[SmExMessage],
	[SmXmlMessage]
) VALUES (
	@SmCategory,
	@SmMessage,
	@SmApplication,
	@SmTS,
	@SmExMessage,
	@SmXmlMessage
)

set @OutSmId = @@identity


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SmLog_Insert]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.AggiornaSaldoFisico    Script Date: 20/10/2005 16.32.04 ******/

CREATE  PROCEDURE dbo.AggiornaSaldoFisico
	@IdSessioneMercato int,
	@IdContratto int,
	@CodiceOperatoreA varchar(8), -- tipoCodiceOperatore
	@CodiceOperatoreV varchar(8), -- tipoCodiceOperatore
	@Qty int
AS

--set @IdContratto = 114	-- D BSLD
--set @CodiceOperatoreA ='1'
--set @CodiceOperatoreV ='2'
--set @Qty=5


declare @di datetime
declare @df datetime
declare @CodiceProfilo varchar(20)

select
@di = DataInizioDelivery,
@df = DataFineDelivery,
@CodiceProfilo=CodiceProfilo
from 
Contratto
where
IdContratto=@IdContratto


if Object_Id('tempdb..#sf') is Not Null drop table #sf
create table #sf
(
	CodiceOperatore /*tipoCodiceOperatore*/varchar(8) NOT null,
	DataDelivery smalldatetime not null,
	TotQty int NOT NULL,
	H01 int NOT NULL,
	H02 int NOT NULL,
	H03 int NOT NULL,
	H04 int NOT NULL,
	H05 int NOT NULL,
	H06 int NOT NULL,
	H07 int NOT NULL,
	H08 int NOT NULL,
	H09 int NOT NULL,
	H10 int NOT NULL,
	H11 int NOT NULL,
	H12 int NOT NULL,
	H13 int NOT NULL,
	H14 int NOT NULL,
	H15 int NOT NULL,
	H16 int NOT NULL,
	H17 int NOT NULL,
	H18 int NOT NULL,
	H19 int NOT NULL,
	H20 int NOT NULL,
	H21 int NOT NULL,
	H22 int NOT NULL,
	H23 int NOT NULL,
	H24 int NOT NULL,
	H25 int NOT NULL, 
	CONSTRAINT PK PRIMARY KEY CLUSTERED (CodiceOperatore, DataDelivery)
)


insert into #sf
	select
	CodiceOperatore  = OPSF.OP,
	DataDelivery = T.DataDelivery,

	TotQty = 
		case PO.H01 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H02 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H03 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H04 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H05 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H06 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H07 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H08 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H09 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H10 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H11 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H12 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H13 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H14 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H15 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H16 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H17 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H18 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H19 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H20 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H21 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H22 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H23 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H24 when '1' then OPSF.K*@Qty else 0 end +
		case PO.H25 when '1' then OPSF.K*@Qty else 0 end,

	H01 = case PO.H01 when '1' then OPSF.K*@Qty else 0 end,
	H02 = case PO.H02 when '1' then OPSF.K*@Qty else 0 end,
	H03 = case PO.H03 when '1' then OPSF.K*@Qty else 0 end,
	H04 = case PO.H04 when '1' then OPSF.K*@Qty else 0 end,
	H05 = case PO.H05 when '1' then OPSF.K*@Qty else 0 end,
	H06 = case PO.H06 when '1' then OPSF.K*@Qty else 0 end,
	H07 = case PO.H07 when '1' then OPSF.K*@Qty else 0 end,
	H08 = case PO.H08 when '1' then OPSF.K*@Qty else 0 end,
	H09 = case PO.H09 when '1' then OPSF.K*@Qty else 0 end,
	H10 = case PO.H10 when '1' then OPSF.K*@Qty else 0 end,
	H11 = case PO.H11 when '1' then OPSF.K*@Qty else 0 end,
	H12 = case PO.H12 when '1' then OPSF.K*@Qty else 0 end,
	H13 = case PO.H13 when '1' then OPSF.K*@Qty else 0 end,
	H14 = case PO.H14 when '1' then OPSF.K*@Qty else 0 end,
	H15 = case PO.H15 when '1' then OPSF.K*@Qty else 0 end,
	H16 = case PO.H16 when '1' then OPSF.K*@Qty else 0 end,
	H17 = case PO.H17 when '1' then OPSF.K*@Qty else 0 end,
	H18 = case PO.H18 when '1' then OPSF.K*@Qty else 0 end,
	H19 = case PO.H19 when '1' then OPSF.K*@Qty else 0 end,
	H20 = case PO.H20 when '1' then OPSF.K*@Qty else 0 end,
	H21 = case PO.H21 when '1' then OPSF.K*@Qty else 0 end,
	H22 = case PO.H22 when '1' then OPSF.K*@Qty else 0 end,
	H23 = case PO.H23 when '1' then OPSF.K*@Qty else 0 end,
	H24 = case PO.H24 when '1' then OPSF.K*@Qty else 0 end,
	H25 = case PO.H25 when '1' then OPSF.K*@Qty else 0 end

	from DataDelivery T
	inner join SessioneMercatoProfiloOrario PO
	on  PO.IdSessioneMercato = @IdSessioneMercato
	and PO.CodiceProfilo = @CodiceProfilo
	and PO.TipoGiorno = T.TipoGiorno
	and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
	cross join
	(
		-- l'op che vende  Immette energia --> +1
		-- l'op che compra Preleva energia --> -1
		select @CodiceOperatoreA OP, -1 K  union
		select @CodiceOperatoreV OP, +1 K
	) OPSF
	where
	@di <= T.DataDelivery and T.DataDelivery <= @df

----------------------------------------------


update 
SaldoFisico
set 
Immissione = SF.Immissione + case when Q.TotQty > 0 then Q.TotQty else 0 end,
Prelievo   = SF.Prelievo   + case when Q.TotQty < 0 then Q.TotQty else 0 end,
H01 = SF.H01 + Q.H01,
H02 = SF.H02 + Q.H02,
H03 = SF.H03 + Q.H03,
H04 = SF.H04 + Q.H04,
H05 = SF.H05 + Q.H05,
H06 = SF.H06 + Q.H06,
H07 = SF.H07 + Q.H07,
H08 = SF.H08 + Q.H08,
H09 = SF.H09 + Q.H09,
H10 = SF.H10 + Q.H10,
H11 = SF.H11 + Q.H11,
H12 = SF.H12 + Q.H12,
H13 = SF.H13 + Q.H13,
H14 = SF.H14 + Q.H14,
H15 = SF.H15 + Q.H15,
H16 = SF.H16 + Q.H16,
H17 = SF.H17 + Q.H17,
H18 = SF.H18 + Q.H18,
H19 = SF.H19 + Q.H19,
H20 = SF.H20 + Q.H20,
H21 = SF.H21 + Q.H21,
H22 = SF.H22 + Q.H22,
H23 = SF.H23 + Q.H23,
H24 = SF.H24 + Q.H24,
H25 = SF.H25 + Q.H25
from SaldoFisico SF
join #sf Q
on Q.DataDelivery = SF.DataDelivery
AND SF.CodiceOperatore = Q.CodiceOperatore

--------------------------

insert into
SaldoFisico
	select
	SF.CodiceOperatore,
	SF.DataDelivery,
	Immissione = case when SF.TotQty > 0 then SF.TotQty else 0 end,
	Prelievo   = case when SF.TotQty < 0 then SF.TotQty else 0 end,
	SF.H01,
	SF.H02,
	SF.H03,
	SF.H04,
	SF.H05,
	SF.H06,
	SF.H07,
	SF.H08,
	SF.H09,
	SF.H10,
	SF.H11,
	SF.H12,
	SF.H13,
	SF.H14,
	SF.H15,
	SF.H16,
	SF.H17,
	SF.H18,
	SF.H19,
	SF.H20,
	SF.H21,
	SF.H22,
	SF.H23,
	SF.H24,
	SF.H25

	from #sf SF
	where not exists 
	(
		select 
		* 
		from SaldoFisico SFold
		where 
		SFold.CodiceOperatore = SF.CodiceOperatore
		and SFold.DataDelivery = SF.DataDelivery
	)



--delete from saldoFisico
--select * from SaldoFisico

/*
Versione che non usa la tabella temporanea

declare @di datetime
declare @df datetime
declare @CodiceProfilo varchar(20)

select
@di = DataInizioDelivery,
@df = DataFineDelivery,
@CodiceProfilo=CodiceProfilo
from 
Contratto
where
IdContratto=@IdContratto

update 
SaldoFisico
set 
H01 = SF.H01 + Q.H01,
H02 = SF.H02 + Q.H02,
H03 = SF.H03 + Q.H03,
H04 = SF.H04 + Q.H04,
H05 = SF.H05 + Q.H05,
H06 = SF.H06 + Q.H06,
H07 = SF.H07 + Q.H07,
H08 = SF.H08 + Q.H08,
H09 = SF.H09 + Q.H09,
H10 = SF.H10 + Q.H10,
H11 = SF.H11 + Q.H11,
H12 = SF.H12 + Q.H12,
H13 = SF.H13 + Q.H13,
H14 = SF.H14 + Q.H14,
H15 = SF.H15 + Q.H15,
H16 = SF.H16 + Q.H16,
H17 = SF.H17 + Q.H17,
H18 = SF.H18 + Q.H18,
H19 = SF.H19 + Q.H19,
H20 = SF.H20 + Q.H20,
H21 = SF.H21 + Q.H21,
H22 = SF.H22 + Q.H22,
H23 = SF.H23 + Q.H23,
H24 = SF.H24 + Q.H24,
H25 = SF.H25 + Q.H25
from SaldoFisico SF
join 
(
	select
	CodiceOperatore  = OPSF.OP,
	DataDelivery = T.DataDelivery,
	H01 = case PO.H01 when '1' then OPSF.K*@Qty else 0 end,
	H02 = case PO.H02 when '1' then OPSF.K*@Qty else 0 end,
	H03 = case PO.H03 when '1' then OPSF.K*@Qty else 0 end,
	H04 = case PO.H04 when '1' then OPSF.K*@Qty else 0 end,
	H05 = case PO.H05 when '1' then OPSF.K*@Qty else 0 end,
	H06 = case PO.H06 when '1' then OPSF.K*@Qty else 0 end,
	H07 = case PO.H07 when '1' then OPSF.K*@Qty else 0 end,
	H08 = case PO.H08 when '1' then OPSF.K*@Qty else 0 end,
	H09 = case PO.H09 when '1' then OPSF.K*@Qty else 0 end,
	H10 = case PO.H10 when '1' then OPSF.K*@Qty else 0 end,
	H11 = case PO.H11 when '1' then OPSF.K*@Qty else 0 end,
	H12 = case PO.H12 when '1' then OPSF.K*@Qty else 0 end,
	H13 = case PO.H13 when '1' then OPSF.K*@Qty else 0 end,
	H14 = case PO.H14 when '1' then OPSF.K*@Qty else 0 end,
	H15 = case PO.H15 when '1' then OPSF.K*@Qty else 0 end,
	H16 = case PO.H16 when '1' then OPSF.K*@Qty else 0 end,
	H17 = case PO.H17 when '1' then OPSF.K*@Qty else 0 end,
	H18 = case PO.H18 when '1' then OPSF.K*@Qty else 0 end,
	H19 = case PO.H19 when '1' then OPSF.K*@Qty else 0 end,
	H20 = case PO.H20 when '1' then OPSF.K*@Qty else 0 end,
	H21 = case PO.H21 when '1' then OPSF.K*@Qty else 0 end,
	H22 = case PO.H22 when '1' then OPSF.K*@Qty else 0 end,
	H23 = case PO.H23 when '1' then OPSF.K*@Qty else 0 end,
	H24 = case PO.H24 when '1' then OPSF.K*@Qty else 0 end,
	H25 = case PO.H25 when '1' then OPSF.K*@Qty else 0 end
	from DataDelivery T
	inner join ProfiloOrario PO
	on  PO.CodiceProfilo = @CodiceProfilo
	and PO.TipoGiorno = T.TipoGiorno
	and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
	cross join
	(
		select @CodiceOperatoreA OP,  1 K  union
		select @CodiceOperatoreV OP, -1 K
	) OPSF
	where
	@di <= T.DataDelivery and T.DataDelivery <= @df
) Q
on 
Q.DataDelivery = SF.DataDelivery
AND SF.CodiceOperatore = Q.CodiceOperatore

--------------------------

insert into
SaldoFisico
	select
	CodiceOperatore  = OPSF.OP,
	DataDelivery = T.DataDelivery,
	H01 = case PO.H01 when '1' then OPSF.K*@Qty else 0 end,
	H02 = case PO.H02 when '1' then OPSF.K*@Qty else 0 end,
	H03 = case PO.H03 when '1' then OPSF.K*@Qty else 0 end,
	H04 = case PO.H04 when '1' then OPSF.K*@Qty else 0 end,
	H05 = case PO.H05 when '1' then OPSF.K*@Qty else 0 end,
	H06 = case PO.H06 when '1' then OPSF.K*@Qty else 0 end,
	H07 = case PO.H07 when '1' then OPSF.K*@Qty else 0 end,
	H08 = case PO.H08 when '1' then OPSF.K*@Qty else 0 end,
	H09 = case PO.H09 when '1' then OPSF.K*@Qty else 0 end,
	H10 = case PO.H10 when '1' then OPSF.K*@Qty else 0 end,
	H11 = case PO.H11 when '1' then OPSF.K*@Qty else 0 end,
	H12 = case PO.H12 when '1' then OPSF.K*@Qty else 0 end,
	H13 = case PO.H13 when '1' then OPSF.K*@Qty else 0 end,
	H14 = case PO.H14 when '1' then OPSF.K*@Qty else 0 end,
	H15 = case PO.H15 when '1' then OPSF.K*@Qty else 0 end,
	H16 = case PO.H16 when '1' then OPSF.K*@Qty else 0 end,
	H17 = case PO.H17 when '1' then OPSF.K*@Qty else 0 end,
	H18 = case PO.H18 when '1' then OPSF.K*@Qty else 0 end,
	H19 = case PO.H19 when '1' then OPSF.K*@Qty else 0 end,
	H20 = case PO.H20 when '1' then OPSF.K*@Qty else 0 end,
	H21 = case PO.H21 when '1' then OPSF.K*@Qty else 0 end,
	H22 = case PO.H22 when '1' then OPSF.K*@Qty else 0 end,
	H23 = case PO.H23 when '1' then OPSF.K*@Qty else 0 end,
	H24 = case PO.H24 when '1' then OPSF.K*@Qty else 0 end,
	H25 = case PO.H25 when '1' then OPSF.K*@Qty else 0 end
	from DataDelivery T
	inner join ProfiloOrario PO
	on  PO.CodiceProfilo = @CodiceProfilo
	and PO.TipoGiorno = T.TipoGiorno
	and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
	cross join
	(
		select @CodiceOperatoreA OP,  1 K  union
		select @CodiceOperatoreV OP, -1 K
	) OPSF
	where
	@di <= T.DataDelivery and T.DataDelivery <= @df
	and not exists 
	(
		select * from SaldoFisico SFold
		where 
		SFold.CodiceOperatore = OPSF.OP
		and SFold.DataDelivery = T.DataDelivery
	)

*/

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[AggiornaSaldoFisico]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.AggiornaTabellaDataDelivery    Script Date: 20/10/2005 16.32.04 ******/

CREATE PROCEDURE dbo.AggiornaTabellaDataDelivery 
	@dummy int = -1
AS

declare @diC datetime
declare @dfC datetime

select
@diC = min(DataInizioDelivery),
@dfC = max(DataFineDelivery)
from 
Contratto

declare @diD datetime
declare @dfD datetime
select
@diD = min(DataDelivery),
@dfD = max(DataDelivery)
from 
DataDelivery

if (@diD is null)
begin
	insert into DataDelivery
	exec ListaDateTraDiDf  @diC, @dfC
end
else
begin
	declare @tmp datetime

 	if (@dfC > @dfD)
	begin
		set @tmp = DateAdd(day, 1, @dfD)
 		insert into DataDelivery
 		exec ListaDateTraDiDf @tmp, @dfC
	end
 	if (@diC < @diD)
	begin
		set @tmp = DateDiff(day, 1, @diD)
 		insert into DataDelivery
 		exec ListaDateTraDiDf @diC, @tmp
	end
end

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[AggiornaTabellaDataDelivery]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.DailyActivityLog_Insert    Script Date: 20/10/2005 16.32.04 ******/

CREATE  PROCEDURE dbo.DailyActivityLog_Insert

	@IdSessioneMercato int,
	@ActivityCode      varchar(20),
	@Msg               nvarchar(1024),
	@ActivityTS        datetime = null, 
	@IdOfferta         int = null,
	@IdAbbinamento     int = null,
	@CodiceOperatore   tipoCodiceOperatore = null,
	@Qty		   int = null,
	@Prezzo		   float = null,	

	@IdActivity        int out

as

if @ActivityTS is null
	set @ActivityTS = getdate()
	

INSERT INTO 
[dbo].[DailyActivityLog]
(
	IdSessioneMercato, 
	ActivityTS, 
	ActivityCode, 
	IdOfferta, 
	IdAbbinamento, 
	CodiceOperatore,
	Qty,
	Prezzo,
	Msg
)
VALUES
(
	@IdSessioneMercato,
	@ActivityTS, 
	@ActivityCode, 
	@IdOfferta, 
	@IdAbbinamento, 
	@CodiceOperatore,
	@Qty,
	@Prezzo,
	@Msg
)

set @IdActivity = @@Identity
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[DailyActivityLog_Insert]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Gest_AggiornaOreFornituraContratto    Script Date: 20/10/2005 16.32.04 ******/

CREATE   PROC dbo.Gest_AggiornaOreFornituraContratto
	@DataDelivery datetime
AS

update Contratto
set 
OreFornituraFeriali = SSS.OreFer,
OreFornituraFestive = SSS.OreFest
from Contratto C1
join 
(
	select
	GG.IdContratto,

 	OreFest = max(case GG.TipoGiorno when 'FEST' then GG.TotOre else 0 end) ,
 	OreFer  = max(case GG.TipoGiorno when 'FER'  then GG.TotOre else 0 end) 

	from
	(
		select
			C.IdContratto,
			T.TipoGiorno,
			sum(  case H01 when '1' then 1 else 0 end
			+ case H02 when '1' then 1 else 0 end
			+ case H03 when '1' then 1 else 0 end
			+ case H04 when '1' then 1 else 0 end
			+ case H05 when '1' then 1 else 0 end
			+ case H06 when '1' then 1 else 0 end
			+ case H07 when '1' then 1 else 0 end
			+ case H08 when '1' then 1 else 0 end
			+ case H09 when '1' then 1 else 0 end
			+ case H10 when '1' then 1 else 0 end
			+ case H11 when '1' then 1 else 0 end
			+ case H12 when '1' then 1 else 0 end
			+ case H13 when '1' then 1 else 0 end
			+ case H14 when '1' then 1 else 0 end
			+ case H15 when '1' then 1 else 0 end
			+ case H16 when '1' then 1 else 0 end
			+ case H17 when '1' then 1 else 0 end
			+ case H18 when '1' then 1 else 0 end
			+ case H19 when '1' then 1 else 0 end
			+ case H20 when '1' then 1 else 0 end
			+ case H21 when '1' then 1 else 0 end
			+ case H22 when '1' then 1 else 0 end
			+ case H23 when '1' then 1 else 0 end
			+ case H24 when '1' then 1 else 0 end
			+ case H25 when '1' then 1 else 0 end) TotOre
		
		from Contratto C
		inner join DataDelivery T
		on C.DataInizioDelivery <= T.DataDelivery and T.DataDelivery <= C.DataFineDelivery
		inner join ProfiloOrario PO
		on  PO.CodiceProfilo = C.CodiceProfilo
		and PO.TipoGiorno = T.TipoGiorno
		and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
		group by C.IdContratto,T.TipoGiorno
	) GG
	group by GG.IdContratto
) SSS
on SSS.IdContratto=C1.IdContratto
where
(C1.DataInizioTrading > @DataDelivery)


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[Gest_AggiornaOreFornituraContratto]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.GetDatiContratto    Script Date: 20/10/2005 16.32.04 ******/
CREATE PROCEDURE dbo.GetDatiContratto
	@NomeContratto tipoNomeContratto
as

select
NomeContratto,
IdContratto,
DataInizioTrading,
DataFineTrading,
DataInizioDelivery,
DataFineDelivery,
CodiceProfilo,
DescrizioneContratto,
CodiceZonaRiferimento,
DurataDelivery,
OreFornituraFeriali,
OreFornituraFestive
from Contratto
where
NomeContratto = @Nomecontratto
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[GetDatiContratto]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.GetDatiSessione    Script Date: 20/10/2005 16.32.04 ******/
CREATE PROCEDURE [dbo].[GetDatiSessione] 
	@dummy int
AS

select
S.*,
P.ValoreFloat DeltaScartoSuRefPrice

from SessioneMercato S

inner join Parametri P
on P.Codice = 'OffertePercPrezzoRif'

where
S.StatoSessione in ( 'PREDISPOSTA', 'APERTA', 'SOSPESA', 'TERMINATA' )
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[GetDatiSessione]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.GetDatiSessioneContratto    Script Date: 20/10/2005 16.32.04 ******/
CREATE PROCEDURE dbo.GetDatiSessioneContratto
	@NomeContratto tipoNomeContratto
as

/*
public string    NomeContratto;
public int       BidIdOfferta;
public double    BidPrice;
public int       BidQty;
public string    BidCodiceOperatore;
public DateTime  BidTS;

public int       AskIdOfferta;
public double    AskPrice;
public int       AskQty;
public string    AskOperator;
public DateTime  AskTS;

public double    LastPrice;
public int       LastQty;
public DateTime  LastTime;

public double    RefPrice;
public double    ConvPrice;
public double    OffPrice;
*/

declare @nullDate datetime
set @nullDate = convert(datetime, '19000101', 112)


select
NomeContratto,

BidIdOfferta,
isnull(BidPrice,0)             BidPrice,
isnull(BidQty,0)               BidQty,
isnull(BidCodiceOperatore,'')  BidCodiceOperatore,
isnull(BidTS, @nullDate)       BidTS,

AskIdOfferta,
isnull(AskPrice, 0)            AskPrice,
isnull(AskQty, 0)              AskQty,
isnull(AskCodiceOperatore, '') AskCodiceOperatore,
isnull(AskTS, @nullDate)       AskTS,

LastPrice,
LastQty,
LastTime,

RefPrice,
ConvPrice,
OffPrice


from SessioneMercatoContratto SMC

inner join SessioneMercato SM
on SM.IdSessioneMercato = SMC.IdSessioneMercato

inner join Contratto C
on C.IdContratto = SMC.IdContratto

where 
1=1
and SM.StatoSessione in ( 'PREDISPOSTA', 'APERTA', 'SOSPESA', 'TERMINATA' )
and C.NomeContratto = @NomeContratto
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[GetDatiSessioneContratto]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.GetListaOperatoriOTC    Script Date: 20/10/2005 16.32.04 ******/
CREATE PROCEDURE dbo.GetListaOperatoriOTC
	@codiceOperatore tipoCodiceOperatore
AS

select
CodiceOperatore,
RagioneSociale
from
Operatore
where
CodiceOperatore <> @codiceOperatore
and AbilitazioneMercato='S'
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[GetListaOperatoriOTC]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.LeggiParametri    Script Date: 20/10/2005 16.32.04 ******/
CREATE PROCEDURE dbo.LeggiParametri 
	@TimeoutRossoVerde int out
AS

select 
@TimeoutRossoVerde = ValoreInt
from
Parametri
where
Codice = 'TimeoutVerdiRossi'
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[LeggiParametri]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.ListaDateTraDiDf    Script Date: 20/10/2005 16.32.05 ******/



CREATE   PROCEDURE dbo.ListaDateTraDiDf
	@di as smalldatetime, 
	@df as smalldatetime
AS

declare @TipoGiorno varchar(4)
declare @MeseUltimaDomenica char(1)


create table #t
(
	d smalldatetime,
	TipoGiorno varchar(4),
	MeseUltimaDomenica char(1)
)



while (@di <= @df)
begin
-- 	set @TipoGiorno = [BIPEX].[dbo].[GetTipoGiorno](@di)
-- 	set @MeseUltimaDomenica = [BIPEX].[dbo].[MeseUltimaDomenica](@di)
	set @TipoGiorno = [dbo].[GetTipoGiorno](@di)
	set @MeseUltimaDomenica = [dbo].[MeseUltimaDomenica](@di)

	insert into #t (d, TipoGiorno, MeseUltimaDomenica) values (@di, @TipoGiorno, @MeseUltimaDomenica)
	set @di = dateadd(day, 1, @di)
end

select *
from #t
order by d





GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ListaDateTraDiDf]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Log_SaldoFisico    Script Date: 20/10/2005 16.32.05 ******/


CREATE    PROC Log_SaldoFisico
	@CodiceOperatore varchar(8),
	@DataInizioPeriodo datetime,
	@DataFinePeriodo datetime
AS

--
print 'CodiceOperatore = ' + @CodiceOperatore
print 'Inizio periodo = ' + convert(varchar(20),@DataInizioPeriodo)
print 'Fine periodo = ' + convert(varchar(20),@DataFinePeriodo)
print ''
--

select
SF.CodiceOperatore as CodiceOperatore,					-- CodiceOperatore
convert(varchar(10),DATEPART(d, SF.DataDelivery)) + '-' + 
convert(varchar(10),DATEPART(m, SF.DataDelivery)) + '-' + 
convert(char(10),DATEPART(yy, SF.DataDelivery)) as DataDelivery,	-- DataDelivery
SF.Immissione as Immissione,						-- Immissione
SF.Prelievo as Prelievo,						-- Prelievo
SF.H01 as Hour1,SF.H02 as Hour2,SF.H03 as Hour3,SF.H04 as Hour4,	-- Hour1..Hour25
SF.H05 as Hour5,SF.H06 as Hour6,SF.H07 as Hour7,SF.H08 as Hour8,	
SF.H09 as Hour9,SF.H10 as Hour10,SF.H11 as Hour11,SF.H12 as Hour12,	
SF.H13 as Hour13,SF.H14 as Hour14,SF.H15 as Hour15,SF.H16 as Hour16,	
SF.H17 as Hour17,SF.H18 as Hour18,SF.H19 as Hour19,SF.H20 as Hour20,	
SF.H21 as Hour21,SF.H22 as Hour22,SF.H23 as Hour23,SF.H24 as Hour24,
SF.H25 as Hour25	

from 
SaldoFisico SF

where
((SF.CodiceOperatore = @CodiceOperatore ) or (@CodiceOperatore is null))
and (@DataInizioPeriodo <= SF.DataDelivery) and (SF.DataDelivery <= @DataFinePeriodo)

order by
SF.DataDelivery asc,	-- ieri..oggi..domani
SF.CodiceOperatore asc	-- 101..102..103



GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.MessaggioIn_Insert    Script Date: 20/10/2005 16.32.05 ******/
CREATE PROCEDURE [dbo].MessaggioIn_Insert
	@CodiceMessaggioIn tipoCodiceMessaggio,
	@CodiceOperatoreIn tipoCodiceOperatore,
	@CodiceUtenteIn tipoCodiceUtente,
	@NomeFileIn tipoNomeFile,
	@FirmatoInIngresso bit,
	@Encoding tipoEncoding,
	@Versione tipoVersione,
	@BlobMessaggio image,
	@DataOraMessaggio datetime,
	@Compresso tipoCompressione,
	@Controfirmato bit,
	@IdMessaggioIn int OUTPUT
AS

INSERT INTO [dbo].[MessaggioIn] (
	[CodiceMessaggioIn],
	[CodiceOperatoreIn],
	[CodiceUtenteIn],
	[NomeFileIn],
	[FirmatoInIngresso],
	[Encoding],
	[Versione],
	[BlobMessaggio],
	[DataOraMessaggio],
	[Compresso],
	[Controfirmato]
) VALUES (
	@CodiceMessaggioIn,
	@CodiceOperatoreIn,
	@CodiceUtenteIn,
	@NomeFileIn,
	@FirmatoInIngresso,
	@Encoding,
	@Versione,
	@BlobMessaggio,
	@DataOraMessaggio,
	@Compresso,
	@Controfirmato
)

SET @IdMessaggioIn = @@IDENTITY


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[MessaggioIn_Insert]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.MessaggioOut_Insert    Script Date: 20/10/2005 16.32.05 ******/
CREATE PROCEDURE [dbo].MessaggioOut_Insert
	@CodiceMessaggioOut tipoCodiceMessaggio,
	@CodiceOperatoreOut tipoCodiceOperatore,
	@NomeFileOut tipoNomeFile,
	@Compresso tipoCompressione,
	@FirmatoInUscita bit,
	@Encoding tipoEncoding,
	@DataOraMessaggio datetime,
	@Versione tipoVersione,
	@BlobMessaggio image,
	@IdMessaggioIn int,
	@DataOraDownload datetime,
	@IdMessaggioOut int OUTPUT
AS

INSERT INTO [dbo].[MessaggioOut] (
	[CodiceMessaggioOut],
	[CodiceOperatoreOut],
	[NomeFileOut],
	[Compresso],
	[FirmatoInUscita],
	[Encoding],
	[DataOraMessaggio],
	[Versione],
	[BlobMessaggio],
	[IdMessaggioIn],
	[DataOraDownload]
) VALUES (
	@CodiceMessaggioOut,
	@CodiceOperatoreOut,
	@NomeFileOut,
	@Compresso,
	@FirmatoInUscita,
	@Encoding,
	@DataOraMessaggio,
	@Versione,
	@BlobMessaggio,
	@IdMessaggioIn,
	@DataOraDownload
)

SET @IdMessaggioOut = @@IDENTITY


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[MessaggioOut_Insert]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.MyTraceAdd    Script Date: 20/10/2005 16.32.05 ******/
CREATE procedure dbo.MyTraceAdd
	@Msg varchar(500)
as
begin
	-- return
	insert TraceMsg (Msg)
	values (@Msg)
end

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[MyTraceAdd]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.MyTraceClean    Script Date: 20/10/2005 16.32.05 ******/


CREATE   procedure dbo.MyTraceClean
as
begin
	-- return
	delete From TraceMsg
	dbcc checkident('TraceMsg', RESEED, 0)

	Print ' ---'
	Print 'Tutti i messaggi di trace sono stati cancellati.'
	Print ' ---'
end



GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.MyTraceView    Script Date: 20/10/2005 16.32.05 ******/


CREATE  procedure dbo.MyTraceView
as
begin
	-- return

	Print ' --- Inizio Elenco Messaggi di Trace'
	Print ' '
	select * from TraceMsg
	Print ' --- Fine Elenco Messaggi di Trace'
end



GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.Offerta_Lock    Script Date: 20/10/2005 16.32.05 ******/


CREATE   PROCEDURE dbo.Offerta_Lock
	@Contratto tipoNomeContratto = NULL
as

declare @IdSessioneMercato int

select 
@IdSessioneMercato = IdSessioneMercato
from
SessioneMercato
with (updlock)
where
StatoSessione in ('APERTA','SOSPESA','TERMINATA','PREDISPOSTA')
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[Offerta_Lock]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_BookSingoloContratto    Script Date: 20/10/2005 16.32.05 ******/

CREATE  PROCEDURE dbo.SessioneCorrente_BookSingoloContratto 
	@Contratto tipoNomeContratto
AS

/*
		[DR(DRE.PrimaryKey)] public string   Contract;
		[DR]                 public short    Hours;
		[DR]                 public DateTime TradingFrom;
		[DR]                 public DateTime TradingTo;
		[DR]                 public DateTime DeliveryFrom;
		[DR]                 public DateTime DeliveryTo;

		[DR(DRE.Nullable)]   public double   LastPrice;
		[DR(DRE.Nullable)]   public int      LastQty;
		[DR(DRE.Nullable)]   public DateTime LastTime;
		[DR(DRE.Nullable)]   public bool     LastIsOTC;

		[DR(DRE.Nullable)]   public double   MaxPrice;
		[DR(DRE.Nullable)]   public bool     MaxPriceEqLastAbb;

		[DR(DRE.Nullable)]   public double   MinPrice;
		[DR(DRE.Nullable)]   public bool     MinPriceEqLastAbb;

		[DR(DRE.Nullable)]   public int      Volume;
		[DR(DRE.Nullable)]   public double   ConvPrice;
		[DR(DRE.Nullable)]   public double   OffPrice;
		[DR(DRE.Nullable)]   public double   RefPrice;
*/

select
--S.DataMercato,
--S.StatoSessione,

C.NomeContratto Contract,
C.OreFornituraFeriali +  C.OreFornituraFestive Hours,
C.DataInizioTrading  TradingFrom,
C.DataFineTrading    TradingTo,
C.DataInizioDelivery DeliveryFrom,
C.DataFineDelivery   DeliveryTo,

SMC.LastPrice,
SMC.LastQty,
SMC.LastTime,
SMC.LastIsOTC,

SMC.MaxPrice,
--0   MaxPriceEqLastAbb,
SMC.MinPrice,
--0   MinPriceEqLastAbb,

SMC.Volume,
SMC.ConvPrice,
SMC.OffPrice,
SMC.RefPrice,

SMC.Indicators,
SMC.IndicatorAskChangeTS,
SMC.IndicatorBidChangeTS


from SessioneMercatoContratto SMC

inner join SessioneMercato S
on S.IdSessioneMercato = SMC.IdSessioneMercato

inner join Contratto C
on C.IdContratto = SMC.IdContratto

where

( S.StatoSessione = 'PREDISPOSTA' or S.StatoSessione = 'APERTA' or S.StatoSessione = 'SOSPESA' )
and C.NomeContratto = @Contratto
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_BookSingoloContratto]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_CambiaStato    Script Date: 20/10/2005 16.32.05 ******/




CREATE    PROCEDURE SessioneCorrente_CambiaStato 
	@NuovoStato varchar(16),
	@ProceduraForzata int,
	@rc int out,
	@MsgErrore varchar(80) out
AS

declare @VecchioStato varchar(16)
declare @IdSessioneMercato integer
declare @DataMercato datetime



-- cerco la sessione di mercato corrente.
select
@IdSessioneMercato = IdSessioneMercato,
@VecchioStato = S.StatoSessione,
@DataMercato = S.DataMercato
from
dbo.SessioneMercato S
where 
S.StatoSessione in ('PREDISPOSTA', 'APERTA', 'SOSPESA', 'TERMINATA' )


if @IdSessioneMercato is null
begin
	set @rc = 0
	set @MsgErrore = 'Non esiste sessione corrente'
	return 0
end


if @ProceduraForzata = 0
begin

	if @VecchioStato = 'PREDISPOSTA'
	begin
		if @NuovoStato <> 'APERTA' 
		begin
			set @rc = 0
			set @MsgErrore = 'Non si puo` andare dallo stato ' + @VecchioStato + ' allo stato ' + @NuovoStato
			return
		end
	end
	
	if @VecchioStato = 'APERTA'
	begin
		if @NuovoStato <> 'SOSPESA' and @NuovoStato <> 'TERMINATA'
		begin
			set @rc = 0
			set @MsgErrore = 'Non si puo` andare dallo stato ' + @VecchioStato + ' allo stato ' + @NuovoStato
			return
		end
	end
	
	if @VecchioStato = 'SOSPESA'
	begin
		if @NuovoStato <> 'APERTA' and @NuovoStato <> 'TERMINATA'
		begin
			set @rc = 0
			set @MsgErrore = 'Non si puo` andare dallo stato ' + @VecchioStato + ' allo stato ' + @NuovoStato
			return
		end
	end
	
	if @VecchioStato = 'TERMINATA'
	begin
		if @NuovoStato <> 'CHIUSA' and @NuovoStato <> 'FALLITA'
		begin
			set @rc = 0
			set @MsgErrore = 'Non si puo` andare dallo stato ' + @VecchioStato + ' allo stato ' + @NuovoStato
			return
		end
	end
end


update 
dbo.SessioneMercato
set
StatoSessione = @NuovoStato
where
IdSessioneMercato = @IdSessioneMercato

if @VecchioStato = 'TERMINATA' and @NuovoStato = 'CHIUSA'
begin
	-- TODO qui fare le operazioni di chiusura
	-- magari chiamando una sp apposita
	print 'TODO'
end

if @VecchioStato = 'TERMINATA' and @NuovoStato = 'FALLITA'
begin
	-- TODO qui fare le operazioni relative al passaggio allo stato di FALLITA
	-- magari chiamando una sp apposita

	-- exec Gest_RiallineaSaldoFisico

	print 'TODO'
end


set @rc = 1
set @MsgErrore = ''

return 0



GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_CambiaStato]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_DailyActivityLog    Script Date: 20/10/2005 16.32.05 ******/
CREATE  PROCEDURE dbo.SessioneCorrente_DailyActivityLog
	@lastDailyActivity int 
AS

SET NOCOUNT OFF

select


DL.IdSessioneMercato, 
DL.IdDailyActivity, 
DL.ActivityTS, 
DL.ActivityCode, 
DL.IdOfferta, 
DL.IdAbbinamento, 
DL.CodiceOperatore, 
DL.Qty, 
DL.Prezzo Price, 
DL.Msg 


from
DailyActivityLog DL

inner join SessioneMercato S
on S.IdSessioneMercato = DL.IdSessioneMercato

where
S.StatoSessione in ('APERTA', 'TERMINATA', 'SOSPESA', 'PREDISPOSTA')
and (DL.IdDailyActivity > @lastDailyActivity or @lastDailyActivity is null)

order by DL.IdDailyActivity


RETURN
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_DailyActivityLog]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_ListaContratti    Script Date: 20/10/2005 16.32.05 ******/
CREATE PROCEDURE [dbo].[SessioneCorrente_ListaContratti]
	@dummy int
as

select
C.IdContratto,
C.NomeContratto

from 
dbo.SessioneMercatoContratto SMC

inner join Contratto C
on C.IdContratto = SMC.IdContratto

inner join dbo.SessioneMercato S
on S.IdSessioneMercato = SMC.IdSessioneMercato

where 
(S.StatoSessione='APERTA' or S.StatoSessione='PREDISPOSTA')
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_ListaContratti]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_MarketSession    Script Date: 20/10/2005 16.32.05 ******/
CREATE PROCEDURE dbo.SessioneCorrente_MarketSession
	@dummy int
AS

SELECT 
[IdSessioneMercato], 
[DataMercato], 
[TSAperturaSessione], 
[TSChiusuraSessione], 
[StatoSessione], 
[NoteSessione],
0 [DatiDisponibili],
PM.ValoreFloat OffertePercPrezzoRif
FROM 
[SessioneMercato]
inner join Parametri PM
on PM.Codice = 'OffertePercPrezzoRif'
where
StatoSessione in ('APERTA', 'SOSPESA', 'PREDISPOSTA', 'TERMINATA')
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_MarketSession]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_SaldoFisico    Script Date: 20/10/2005 16.32.05 ******/

CREATE  PROCEDURE dbo.SessioneCorrente_SaldoFisico
	@s varchar (2000)
AS

--set @s = '<SF>'
--set @s = @s + ' <R Op="OP1" Data="20051001" />'
--set @s = @s + ' <R Op="OP2" Data="20051002" />'
--set @s = @s + '</SF>'

declare @h int
exec sp_xml_preparedocument @h output, @s

select
r.Op CodiceOperatore,
Convert(datetime, R.Data, 112) DataDelivery,
isnull(SF.Immissione,0) Immissione,
isnull(SF.Prelievo,0)   Prelievo,

isnull(SF.H01,0) H01,
isnull(SF.H01,0) H02,
isnull(SF.H01,0) H03,
isnull(SF.H01,0) H04,
isnull(SF.H01,0) H05,
isnull(SF.H01,0) H06,
isnull(SF.H01,0) H07,
isnull(SF.H01,0) H08,
isnull(SF.H01,0) H09,
isnull(SF.H01,0) H10,

isnull(SF.H01,0) H11,
isnull(SF.H01,0) H12,
isnull(SF.H01,0) H13,
isnull(SF.H01,0) H14,
isnull(SF.H01,0) H15,
isnull(SF.H01,0) H16,
isnull(SF.H01,0) H17,
isnull(SF.H01,0) H18,
isnull(SF.H01,0) H19,
isnull(SF.H01,0) H20,

isnull(SF.H01,0) H21,
isnull(SF.H01,0) H22,
isnull(SF.H01,0) H23,
isnull(SF.H01,0) H24,
isnull(SF.H01,0) H25

from dbo.SaldoFisico SF
right outer join 
(
	select *
	from
	OpenXml(@h, 'SF/R', 1)
	with (
		Op varchar(8),		-- tipoCodiceOperatore
		Data varchar(8))
) R
on	SF.CodiceOperatore = R.Op
and SF.DataDelivery = Convert(datetime, R.Data, 112)
	

exec sp_xml_removedocument @h

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_SaldoFisico]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.SessioneMercato_CreaNuova    Script Date: 20/10/2005 16.32.05 ******/


CREATE   procedure dbo.SessioneMercato_CreaNuova
	@d datetime,
	@IdNuovaSessione int output
as

--
begin	-- Procedura
--

-- Legge TSAperturaSessione (datetime)
declare @TSAperturaSessione datetime
select 
@TSAperturaSessione = ValoreDateTime
from 
Parametri 
where 
Codice = 'TSAperturaSessione'	
--

-- Legge TSChiusuraSessione (datetime)
declare @TSChiusuraSessione datetime
select 
@TSChiusuraSessione = ValoreDateTime
from 
Parametri 
where 
Codice = 'TSChiusuraSessione'	
--

--
-- set @TSAperturaSessione =  Bipex.dbo.ComponeDataOra(@d, @TSAperturaSessione)
-- set @TSChiusuraSessione =  Bipex.dbo.ComponeDataOra(@d, @TSChiusuraSessione)
set @TSAperturaSessione =  dbo.ComponeDataOra(@d, @TSAperturaSessione)
set @TSChiusuraSessione =  dbo.ComponeDataOra(@d, @TSChiusuraSessione)
--

-- Inizio Inserimento della nuova sessione
insert into SessioneMercato(

	DataMercato,
	TSAperturaSessione,
	TSChiusuraSessione,
	StatoSessione,
	NoteSessione)

values(
	@d,
	@TSAperturaSessione,
	@TSChiusuraSessione,
	'NUOVA',
	'')
-- Fine Inserimento della nuova sessione

-- Memo id della sessione appena inserita
set @IdNuovaSessione = @@IDENTITY
--
-- Fine Associazioni dei contratti con la nuova sessione


--
end		-- Procedura
--

--- Fine Create
---


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneMercato_CreaNuova]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.CancellaOfferteAbbinamentiContratto    Script Date: 20/10/2005 16.32.05 ******/



CREATE   procedure dbo.CancellaOfferteAbbinamentiContratto
	@NomeContratto tipoNomeContratto
as

begin

-- NOTA BENE:
-- QUESTA SP E' STATA INSERITA SOLO PER TEST

-- Inizio Cerca IdContratto
declare @memoIdCOntratto int

select top 1
@memoIdContratto = idContratto
from
contratto
where
nomeContratto = @NomeContratto
-- Inizio Cerca IdContratto

-- Inizio Se non trovato IdContratto
if @@rowcount <> 1
begin
	return
end
-- Fine Se non trovato IdContratto

-- Inizio Cancella Abbinamenti
delete from Abbinamento
where
IdContratto = @memoIdContratto

delete from Offerta
where
IdContratto = @memoIdContratto

-- Forse sarebbe opportuno azzerare SessioneMercatoContratto
   -- ???

-- Fine Cancella Abbinamenti

end
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[CancellaOfferteAbbinamentiContratto]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Contratto_AggiornaOreFornituraContrattiNoDelivery    Script Date: 20/10/2005 16.32.05 ******/


CREATE    PROC dbo.Contratto_AggiornaOreFornituraContrattiNoDelivery
	@dummy int = -1
AS

update Contratto
set 
OreFornituraFeriali = SSS.OreFer,
OreFornituraFestive = SSS.OreFest
from Contratto C1
join 
(
	select
	GG.IdContratto,

 	OreFest = max(case GG.TipoGiorno when 'FEST' then GG.TotOre else 0 end) ,
 	OreFer  = max(case GG.TipoGiorno when 'FER'  then GG.TotOre else 0 end) 

	from
	(
		select
			C.IdContratto,
			T.TipoGiorno,
			sum(  case H01 when '1' then 1 else 0 end
			+ case H02 when '1' then 1 else 0 end
			+ case H03 when '1' then 1 else 0 end
			+ case H04 when '1' then 1 else 0 end
			+ case H05 when '1' then 1 else 0 end
			+ case H06 when '1' then 1 else 0 end
			+ case H07 when '1' then 1 else 0 end
			+ case H08 when '1' then 1 else 0 end
			+ case H09 when '1' then 1 else 0 end
			+ case H10 when '1' then 1 else 0 end
			+ case H11 when '1' then 1 else 0 end
			+ case H12 when '1' then 1 else 0 end
			+ case H13 when '1' then 1 else 0 end
			+ case H14 when '1' then 1 else 0 end
			+ case H15 when '1' then 1 else 0 end
			+ case H16 when '1' then 1 else 0 end
			+ case H17 when '1' then 1 else 0 end
			+ case H18 when '1' then 1 else 0 end
			+ case H19 when '1' then 1 else 0 end
			+ case H20 when '1' then 1 else 0 end
			+ case H21 when '1' then 1 else 0 end
			+ case H22 when '1' then 1 else 0 end
			+ case H23 when '1' then 1 else 0 end
			+ case H24 when '1' then 1 else 0 end
			+ case H25 when '1' then 1 else 0 end) TotOre
		
		from Contratto C
		inner join DataDelivery T
		on C.DataInizioDelivery <= T.DataDelivery and T.DataDelivery <= C.DataFineDelivery
		inner join ProfiloOrario PO
		on  PO.CodiceProfilo = C.CodiceProfilo
		and PO.TipoGiorno = T.TipoGiorno
		and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
		group by C.IdContratto,T.TipoGiorno
	) GG
	group by GG.IdContratto
) SSS
on SSS.IdContratto=C1.IdContratto
where
not exists (
	select 'True' 
	from SessioneMercatoContratto smc
	where smc.IdContratto =  C1.IdContratto )

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.GetDatiOfferta    Script Date: 20/10/2005 16.32.05 ******/
CREATE PROCEDURE dbo.GetDatiOfferta
	@IdOfferta int
AS

select 
 O.IdOfferta
,C.NomeContratto  NomeContratto
,O.CodiceUtente
,O.TSCreazione
,case O.TipoOfferta 
	when 'A' then 'Acquisto' 
	when 'V' then 'Vendita' 
 end [TipoOfferta]

,case O.StatoOfferta   
	when 'VA' then 'Valida'
	when 'RM' then 'Revocata'
	when 'NA' then 'Nascosta'
 end [StatoOfferta]


,O.QtyRichiesta   QtyIniziale
,O.QtyResidua 
,O.TSAbbinamento  TSPrioritaAbbinamento
,O.NoteOfferta    Note
,O.OperatoreOTC
,O.CodiceOTC
,O.Compatibile
,O.PrezzoUnitario Prezzo

, case when Compatibile='S' and QtyResidua > 0 and StatoOfferta='VA' then 1 else 0 end [OffertaNelBook]

, O.OffertaAMercato OffertaAMercato

 
from Offerta O
inner join Contratto C
on C.IdContratto = O.IdContratto
where IdOfferta = @IdOfferta
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[GetDatiOfferta]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.GetOreDiFornitura    Script Date: 20/10/2005 16.32.05 ******/



CREATE     PROCEDURE dbo.GetOreDiFornitura 
	@NomeContratto tipoNomecontratto
as

-- Inizio Legge di data inizio e data fine delivery contratto
declare @IdContratto 	int
declare @di          	datetime
declare @df          	datetime
declare @CodiceProfilo  varchar(20)
declare @DurataDelivery varchar(10)

select 
@IdContratto 	= IdContratto,
@CodiceProfilo 	= CodiceProfilo,
@di 		= DataInizioDelivery,
@df 		= DataFineDelivery,
@DurataDelivery = DurataDelivery
from 
Contratto
where 
NomeContratto 	= @NomeContratto
-- Fine Legge di data inizio e data fine delivery contratto

-- Inizio ricava IdSessioneMercato
-- (Cerca nella tabella SessioneMercato SM - la sessione che non e' ne 'NUOVA' ne 'CHIUSA' ne 'FALLITA')
declare @IdSessioneMercato int
select top 1
@IdSessioneMercato = IdSessioneMercato
from
SessioneMercato SM
where
1=1
and (SM.StatoSessione <> 'NUOVA')
and (SM.StatoSessione <> 'CHIUSA')
and (SM.StatoSessione <> 'FALLITA')

if (@IdSessioneMercato is null)
begin	
	-- Non esiste una sessione nello stato opportuno
	return		
end
-- Fine ricava IdSessioneMercato

-- Inizio seleziona tutti i profili di contratto
select 
T.DataDelivery,
case T.TipoGiorno when 'FEST' then 'H' else 'W' end FestivoFeriale,
-- P.H01,P.H02,P.H03,P.H04,P.H05,P.H06,P.H07,P.H08,P.H09,P.H10,P.H11,P.H12,P.H13,P.H14,P.H15,P.H16,P.H17,P.H18,P.H19,P.H20,P.H21,P.H22,P.H23,P.H24,P.H25
H = isnull(H01+H02+H03+H04+H05+H06+H07+H08+H09+H10+H11+H12+H13+H14+H15+H16+H17+H18+H19+H20+H21+H22+H23+H24+H25, '                         ')
from
DataDelivery T
inner join SessioneMercatoProfiloOrario P
on 
1=1
and (T.TipoGiorno = P.TipoGiorno)
and (T.MeseUltimaDomenica = P.MeseUltimaDomenica)
where
1=1
and (P.IdSessioneMercato = @IdSessioneMercato)
and (P.CodiceProfilo = @CodiceProfilo)
and (@di <= T.DataDelivery and T.DataDelivery <= @df)
-- Fine seleziona tutti i profili di contratto
	
-- end	-- Fine Procedura

--- Fine Create




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[GetOreDiFornitura]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_BookRiassuntivo    Script Date: 20/10/2005 16.32.05 ******/


CREATE   PROCEDURE dbo.SessioneCorrente_BookRiassuntivo 
	@dummy int
AS

select
--S.DataMercato,
--S.StatoSessione,

C.NomeContratto Contract,
Hours = C.OreFornituraFeriali + C.OreFornituraFestive,

SMC.BidIdOfferta,
SMC.BidPrice,
SMC.BidQty,
SMC.BidCodiceOperatore BidOperator,
SMC.BidTS,

SMC.AskIdOfferta,
SMC.AskPrice,
SMC.AskQty,
SMC.AskCodiceOperatore AskOperator,
SMC.AskTS,


SMC.LastPrice,
SMC.LastTime,
SMC.LastQty,
SMC.LastIsOTC,

SMC.MaxPrice,
SMC.MinPrice,

SMC.Volume,
SMC.ConvPrice,
SMC.OffPrice,
SMC.RefPrice,

SMC.Indicators,

SMC.IndicatorAskChangeTS,
SMC.IndicatorBidChangeTS


from SessioneMercatoContratto SMC

inner join SessioneMercato S
on S.IdSessioneMercato = SMC.IdSessioneMercato

inner join Contratto C
on C.IdContratto = SMC.IdContratto

where
( S.StatoSessione = 'PREDISPOSTA' or S.StatoSessione = 'APERTA' or S.StatoSessione = 'SOSPESA' )

order by 
	case C.DurataDelivery
	when 'D' then 1
	when 'W' then 2
	when 'M' then 3 end,
	C.CodiceProfilo,
	C.DataInizioDelivery


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_BookRiassuntivo]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_DailyActivity    Script Date: 20/10/2005 16.32.05 ******/

CREATE  PROCEDURE dbo.SessioneCorrente_DailyActivity
	@dummy int
AS
/*
sp chiamata per ottenere la lista degli abbinamenti di una sessione
di mercato.
*/

SET NOCOUNT OFF

select

AB.IdAbbinamento,

OA.IdOfferta BidIdOfferta,
OV.IdOfferta AskIdOfferta,

C.NomeContratto Contratto,

OA.CodiceOperatore BidCodiceOperatore,
OV.CodiceOperatore AskCodiceOperatore,

OA.CodiceUtente BidCodiceUtente,
OV.CodiceUtente AskCodiceUtente,

AB.TSAbbinamento,
AB.PrezzoUnitario Price,
AB.QtyAbbinata Qty,

OV.CodiceOTC,
OV.OperatoreOTC
	
from
Abbinamento AB

inner join Offerta OA
on  OA.IdSessioneMercato = AB.IdSessioneMercato
and OA.IdContratto = AB.IdContratto
and OA.IdOfferta = AB.IdOffertaAcquisto

inner join Offerta OV
on  OV.IdSessioneMercato = AB.IdSessioneMercato
and OV.IdContratto = AB.IdContratto
and OV.IdOfferta = AB.IdOffertaVendita

inner join Contratto C
on AB.IdContratto = C.IdContratto

inner join SessioneMercato S
on S.IdSessioneMercato = AB.IdSessioneMercato

where
S.StatoSessione in ('APERTA', 'TERMINATA', 'SOSPESA')

order by AB.TSAbbinamento desc

RETURN

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_DailyActivity]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_Offerta    Script Date: 20/10/2005 16.32.05 ******/

CREATE  PROCEDURE dbo.SessioneCorrente_Offerta 
	@Contratto tipoNomecontratto
AS


set nocount on

/* determino la sessione di mercato corrente */
declare @IdSessioneMercato int
select
@IdSessioneMercato = IdSessioneMercato
from SessioneMercato
where
StatoSessione='APERTA' or StatoSessione='SOSPESA'
/* 
se non esiste sessione aperta 
@IdSessioneMercato rimane null
e dunque le altre select non ritornano record
--> book vuoto
*/

declare @IdContratto int
select
@IdContratto = IdContratto
from Contratto
where NomeContratto = @Contratto


if Object_Id('tempdb..#tmp_OA') is Not Null drop table #tmp_OA
if Object_Id('tempdb..#tmp_OV') is Not Null drop table #tmp_OV

CREATE TABLE #tmp_OA
(
	PosizioneBook int identity primary key,
	IdOfferta int,
	Price float,
	Qty int,
	Operator varchar(8),		-- tipoCodiceOperatore
	OTCOperator varchar(8),		-- tipoCodiceOperatore
	OTCCode varchar(32)
)
CREATE TABLE #tmp_OV
(
	PosizioneBook int identity primary key,
	IdOfferta int,
	Price float,
	Qty int,
	Operator varchar(8),		-- tipoCodiceOperatore
	OTCOperator varchar(8),		-- tipoCodiceOperatore
	OTCCode varchar(32)
)


INSERT into #tmp_OA
(
	IdOfferta,
	Price,
	Qty,
	Operator,
	OTCOperator,
	OTCCode
)
	select
	IdOfferta       IdOfferta,
	PrezzoUnitario  Prezzo,
	QtyResidua      Qty,
	CodiceOperatore Operator,
	OperatoreOTC,
	CodiceOTC
	
	from
	OffertaAcquistoBook
	where
	    IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto
	order by
	PrezzoUnitario desc,
	TSAbbinamento asc

INSERT into #tmp_OV
(
	IdOfferta,
	Price,
	Qty,
	Operator,
	OTCOperator,
	OTCCode
)
	select
	IdOfferta,
	PrezzoUnitario Prezzo,
	QtyResidua Qty,
	CodiceOperatore,
	OperatoreOTC,
	CodiceOTC
	from
	OffertaVenditaBook
	where
	    IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto
	order by
	PrezzoUnitario asc,
	TSAbbinamento asc


set nocount off


declare @Indicators tinyint
declare @IndicatorAskChangeTS datetime
declare @IndicatorBidChangeTS datetime

select 
@Indicators = Indicators,
@IndicatorBidChangeTS = IndicatorBidChangeTS,
@IndicatorAskChangeTS = IndicatorAskChangeTS
from SessioneMercatoContratto
where
IdContratto = @IdContratto
and IdSessioneMercato = @IdSessioneMercato



select

PosizioneBook = isNull(Bid.PosizioneBook ,Ask.PosizioneBook),

Bid.IdOfferta   BidIdOfferta,
Bid.Price       BidPrice,
Bid.Qty         BidQty,
Bid.Operator    BidOperator,
Bid.OTCOperator BidOTCOperator,
Bid.OTCCode     BidOTCCode,

Ask.IdOfferta   AskIdOfferta,
Ask.Price       AskPrice,
Ask.Qty         AskQty,
Ask.Operator    AskOperator,
Ask.OTCOperator AskOTCOperator,
Ask.OTCCode     AskOTCCode,

case isNull(Bid.PosizioneBook,Ask.PosizioneBook) when 1 then @Indicators else 0 end Indicators,

@IndicatorBidChangeTS IndicatorBidChangeTS,
@IndicatorAskChangeTS IndicatorAskChangeTS

from #tmp_OA Bid
full outer join #tmp_OV Ask
on Bid.PosizioneBook = Ask.PosizioneBook

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_Offerta]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneCorrente_OpenOrders    Script Date: 20/10/2005 16.32.05 ******/
CREATE PROCEDURE dbo.SessioneCorrente_OpenOrders
	@dummy int
AS
	/*
	sp chiamata per ottenere le offerte ancora attive nel book
	o le offerte sospese.
	
	Se la sessione non e` aperta non ci sono offerte attive nel book.
	*/
	SET NOCOUNT OFF


	select 
	O.IdOfferta,
	C.NomeContratto Contratto,
	O.CodiceOperatore,
	O.CodiceUtente,
	O.TSCreazione,
	O.TSAbbinamento,

	case O.TipoOfferta when 'V' then 1 else 0 end Ask,
	case O.OffertaAMercato when 'S' then 0 else O.PrezzoUnitario end PrezzoRichiesto,
	O.QtyRichiesta,
	O.NoteOfferta,

	PrezzoUnitario        PrezzoResiduo,
	O.QtyResidua          QtyResidua,

	O.OperatoreOTC,
	O.CodiceOTC,

	O.StatoOfferta,
	case O.OffertaAMercato when 'S' then 1 else 0 end OffertaAMercato
	
	from 
	Offerta O
	
	inner join Contratto C
	on C.IdContratto = O.IdContratto

	inner join Operatore OP
	on OP.CodiceOperatore = O.CodiceOperatore

	inner join SessioneMercato SM
	on SM.IdSessioneMercato = O.IdSessioneMercato
	
	where 
	1=1
	and O.StatoOfferta in ('VA', 'NA')
	and O.Compatibile = 'S'
	and O.QtyResidua > 0
	and OP.AbilitazioneMercato = 'S'
	and SM.StatoSessione in ('APERTA' , 'SOSPESA')
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneCorrente_OpenOrders]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.SessioneMercato_StoricizzaProfiloOrario    Script Date: 20/10/2005 16.32.05 ******/

CREATE   PROCEDURE SessioneMercato_StoricizzaProfiloOrario
	@IdSessioneMercato int
AS

-- Cancello eventuale profilo precedente
-- relativo alla stessa sessione
delete from
SessioneMercatoProfiloOrario
where
IdSessioneMercato = @IdSessioneMercato
--

-- Inserisco profilo orario
-- relativo alla sessione
insert into
SessioneMercatoProfiloOrario
(
	IdSessioneMercato,
	CodiceProfilo,
	TipoGiorno,
	MeseUltimaDomenica,
	DescrizioneProfilo,
	H01, H02, H03, H04, H05, H06, H07, H08, H09, H10,
	H11, H12, H13, H14, H15, H16, H17, H18, H19, H20,
	H21, H22, H23, H24
)
	select 
	@IdSessioneMercato IdSessioneMercato,
	PO.CodiceProfilo,
	PO.TipoGiorno,
	PO.MeseUltimaDomenica,
	PO.DescrizioneProfilo,
	PO.H01, PO.H02, PO.H03, PO.H04, PO.H05, PO.H06, PO.H07, PO.H08, PO.H09, PO.H10,
	PO.H11, PO.H12, PO.H13, PO.H14, PO.H15, PO.H16, PO.H17, PO.H18, PO.H19, PO.H20,
	PO.H21, PO.H22, PO.H23, PO.H24
	from
	ProfiloOrario PO
	-- copio anche i profili con Cancellato=0 perche` pottrebbe capitare che un contratto in trading
	-- utilizzi anche un profilo con flag Cancellato=0.
	-- Cancellato=0 indica che non sara` possibile referenziare un nuovo contratto a quel profilo.
	-- CANCELLATO where PO.Cancellato = 0
--
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.TransazioneIn_Insert    Script Date: 20/10/2005 16.32.05 ******/
CREATE PROCEDURE [dbo].TransazioneIn_Insert
	@IdMessaggioIn int,
	@ProgressivoTransazioneIn int,
	@CodiceTransazioneIn tipoCodiceTransazione,
	@TipoTransazione tipoTipoTransazione,
	@BlobTransazione image
AS


INSERT INTO [dbo].[TransazioneIn] 
(
	[IdMessaggioIn],
	[ProgressivoTransazioneIn],
	[CodiceTransazioneIn],
	[TipoTransazione],
	[BlobTransazione]
)
VALUES
(
	@IdMessaggioIn,
	@ProgressivoTransazioneIn,
	@CodiceTransazioneIn,
	@TipoTransazione,
	@BlobTransazione
)

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[TransazioneIn_Insert]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.AbbinamentoOffertaAcquisto    Script Date: 20/10/2005 16.32.05 ******/

---
--- Inizio Create
CREATE                    procedure dbo.AbbinamentoOffertaAcquisto
	@IdOffertaAcquisto int,
	@StatoAbbinamento varchar(2) output
as

--
begin	-- Procedura
--

-- Leggo campi relativi all'offerta di acquisto in questione
-- Di cui e' noto @IdOffertaAcquisto
Declare
@IdSessioneMercato int,
@IdContratto int,
@OACodiceOperatore varchar(8), 	-- tipoCodiceOperatore
@OffertaAMercato char(1),
@OAPrezzoUnitario float,
@OAQtyRes int,
@OAOperatoreOTC varchar(8),	-- tipoCodiceOperatore
@OACodiceOTC varchar(32),
@OATSAbbinamento datetime,
@NomeContratto tipoNomecontratto


declare @IdAbbinamento int
declare @DailyMsg nvarchar(1024)
declare @IdActivity int


select top 1
@IdSessioneMercato= Offerta.IdSessioneMercato,
@IdContratto      = Offerta.IdContratto,
@OACodiceOperatore= Offerta.CodiceOperatore,
@OffertaAMercato  = Offerta.OffertaAMercato,
@OAPrezzoUnitario = Offerta.PrezzoUnitario,
@OAQtyRes         = Offerta.QtyResidua,
@OAOperatoreOTC   = Offerta.OperatoreOTC, -- Eventuale Offerta di acquisto OTC (da scartare)
@OACodiceOTC      = Offerta.CodiceOTC,	      -- Eventuale Offerta di acquisto OTC (da scartare)	
@OATSAbbinamento  = Offerta.TSAbbinamento,
@NomeContratto    = Contratto.NomeContratto
from Offerta
inner join Contratto
on Contratto.IdContratto = Offerta.IdContratto
where
IdOfferta = @IdOffertaAcquisto
--

-- Se Offerta di Acquisto OTC richiama la procedura OTC
if ((LEN(@OAOperatoreOTC) > 0) OR (LEN(@OACodiceOTC) > 0))
BEGIN
	exec AbbinamentoOffertaAcquistoOTC @IdOffertaAcquisto, @StatoAbbinamento output
-- 	set @StatoAbbinamento = 'NN'
	return		
END
--

-- Inizio gestione di una eventuale OFFERTA DI ACQUISTO A MERCATO.

-- Le proposte senza limite di prezzo hanno priorita' massima di prezzo.
-- Quindi si cerca il miglior prezzo fra le offerte di vendita
-- (ovvero quella con il prezzo inferiore) e lo si assegna alla offerta di acquisto corrente.
-- Se il miglior prezzo di vendita e' stato emesso dall'operatore stesso
-- allora trattasi di offerta non compatibile ed esce dal book,
-- lo stesso se non esiste alcuna offerta di vendita emessa da altri operatori.
-- Nota: Nel caso sia presente nelle offerte di vendita una offerta dello stesso
-- operatore, ma non la migliore, la selezione automatica del prezzo pone lo stesso
-- al di sotto del prezzo compatibile e quindi non rende l'offerta di acquisto
-- incompatibile anche se l'abbinamento e' parziale (QtyResidua>0)

declare @PrezzoAcquistoOffertaAMercato float
declare @MemoOVCodiceOperatore varchar(8) -- tipoCodiceOperatore
if (@OffertaAMercato = 'S')
begin
	-- 
	select top 1
	@PrezzoAcquistoOffertaAMercato = OV.PrezzoUnitario,
	@MemoOVCodiceOperatore = OV.CodiceOperatore
	from 
	OffertaVenditaBook OV
	inner join Operatore OP				-- Verifica Operatore Abilitato
	on  OP.CodiceOperatore = OV.CodiceOperatore	-- Verifica Operatore Abilitato
	where
	1=1
	and OV.IdSessioneMercato = @IdSessioneMercato	--
	and OV.IdContratto = @IdContratto		--
	and LEN(OV.OperatoreOTC)=0			-- Esclude OTC
	and LEN(OV.CodiceOTC)=0				-- Esclude OTC
	and OP.AbilitazioneMercato = 'S'		-- Verifica Operatore Abilitato
	order by
	OV.PrezzoUnitario asc,	-- 100..101..102
	OV.TSAbbinamento asc	-- ieri..oggi..domani
	-- 

	-- Se non esiste alcun miglior prezzo oppure 
	-- il miglior prezzo appartiene allo stesso operatore dell'offerta di acquisto
	if (@PrezzoAcquistoOffertaAMercato is null) or (@MemoOVCodiceOperatore=@OACodiceOperatore)
	begin
		-- non esiste nessuna offerta accettabile di vendita nel book
		-- quindi l'offerta di acquisto a mercato deve uscire dal book
		-- ed e` marcata come non compatibile
		update 
		Offerta
		set
		Compatibile = 'N'
		where
		IdSessioneMercato = @IdSessioneMercato
		and IdContratto = @IdContratto
		and IdOfferta = @IdOffertaAcquisto
		
		set @StatoAbbinamento = 'NN'
		return		
	end
	begin
		-- d'ora in poi il prezzo dell'offerta di acquisto a mercato
		-- assume il prezzo piu` vantaggioso nel book di vendita
		set @OAPrezzoUnitario = @PrezzoAcquistoOffertaAMercato
	end
	-- 
end

-- Fine gestione di una eventuale OFFERTA DI ACQUISTO A MERCATO.


-- Inizio gestione di un eventuale prezzo compatibile
-- Nota: non verifico se operatore Offerta di Acquisto abilitato perche'
--       gia' controllato dalla validazione.
declare @PrezzoCompatibile as float
declare @OAQtyResOriginale int
set @OAQtyResOriginale = @OAQtyRes

select 
@PrezzoCompatibile = min (OV.PrezzoUnitario)
from
OffertaVenditaBook OV
where
1=1
and OV.IdSessioneMercato = @IdSessioneMercato	--
and OV.IdContratto = @IdContratto		--
and LEN(OV.OperatoreOTC)=0			-- Esclude OTC
and LEN(OV.CodiceOTC)=0				-- Esclude OTC
and OV.PrezzoUnitario <= @OAPrezzoUnitario
and OV.CodiceOperatore = @OACodiceOperatore	-- Stesso Operatore

/*
Se esiste almeno una offerta di vendita da parte dello stesso operatore
che ha un prezzo minore o uguale al prezzo di acquisto (se piu' di una prende quella a prezzo minore).
Assume come prezzo compatibile il prezzo di vendida della suddetta e 
inizializza l'offerta di acquisto a non compatibile (deve uscire dal book alla fine di questo giro di abbinamenti)

Se non ne esiste nessuna assume come prezzo compatibile infinito
(1e10 ovvero, in relazione al prezzo compatibile, considera tutte le offerte di vendita)
e inizializza l'offerta di acquisto a compatibile.
*/

declare @Compatibile as char(1)
set @Compatibile = 'N'
if (@PrezzoCompatibile is null)
begin
	set @PrezzoCompatibile = 1e10
	set @Compatibile = 'S'  -- l'offerta potra` rimanere nel book per la quantita` residua
end

-- Fine gestione Di un eventuale prezzo compatibile

-- Inizio gestione ricerca abbinamenti sulle righe delle offerte di vendita

declare OVAbbinabili cursor keyset for
	select
	OV.IdOfferta,
	OV.QtyResidua,
	OV.PrezzoUnitario,
	OV.CodiceOperatore,
	OV.TSAbbinamento
	from 
	Offerta OV
	inner join Operatore OP				-- Verifica Operatore Abilitato
	on  OP.CodiceOperatore = OV.CodiceOperatore	-- Verifica Operatore Abilitato
	where
	1=1
	and (OV.TipoOfferta = 'V') 			--
	and (OV.StatoOfferta = 'VA') 			--
	and (OV.Compatibile = 'S') 			--
	and (OV.QtyResidua > 0)				--
	and OV.IdSessioneMercato = @IdSessioneMercato	--
	and OV.IdContratto = @IdContratto		--
	and LEN(OV.OperatoreOTC)=0			-- Esclude OTC
	and LEN(OV.CodiceOTC)=0				-- Esclude OTC
	and OP.AbilitazioneMercato = 'S'		-- Verifica Operatore Abilitato
	and OV.PrezzoUnitario <= @OAPrezzoUnitario
	and OV.PrezzoUnitario < @PrezzoCompatibile	--
	and OV.CodiceOperatore != @OACodiceOperatore   	-- probabilamente non serve.
	order by
	OV.PrezzoUnitario asc,				-- 100..101..102
	OV.TSAbbinamento asc				-- ieri..oggi..domani

declare @IdOffertaAbbinabile int
declare @QtyResiduaAbbinabile int
declare @PrezzoUnitarioAbbinabile float
declare @OVCodiceOperatore varchar(8)  -- tipoCodiceOperatore
declare @OVTSAbbinamento datetime

open OVAbbinabili
fetch next from OVAbbinabili into @IdOffertaAbbinabile, @QtyResiduaAbbinabile, @PrezzoUnitarioAbbinabile, @OVCodiceOperatore, @OVTSAbbinamento
while (@@FETCH_STATUS = 0)
begin
	-- Se tutta la quantita' acquistata esce
	if (@OAQtyRes = 0) break
		
	-- Abbina il piu' possibile della quantita da comprare :-)
	declare @QtyAbbinata int
	set @QtyAbbinata = @OAQtyRes
	if (@QtyAbbinata > @QtyResiduaAbbinabile) set @QtyAbbinata = @QtyResiduaAbbinabile

	set @OAQtyRes = @OAQtyRes - @QtyAbbinata

	-- Aggiorna la quantita' residua dell' Offerta di vendita
	-- N.B. Sulla riga corrente del cursore
	update 
	Offerta
	set
	QtyResidua = QtyResidua - @QtyAbbinata
	where
	current of OVAbbinabili
	--
	
	--
	declare @TSAbbinamento as datetime
	set @TSAbbinamento = getdate()
	--

	-- Inserisce Abbinamento
	-- al prezzo dell'offerta di vendita trovata.
	insert into Abbinamento
	(
		IdSessioneMercato, 	--
		IdContratto, 		--
		IdOffertaAcquisto, 
		IdOffertaVendita, 
		PrezzoUnitario, 
		QtyAbbinata,
		TSAbbinamento,
		TSOAAbbinamento,	-- Nuovi Campi
		TSOVAbbinamento,	-- Nuovi Campi
		AbbinamentoCausatoDa	-- Nuovi Campi
	)
	values 
	(
		@IdSessioneMercato,		--
		@IdContratto, 			--
		@IdOffertaAcquisto, 
		@IdOffertaAbbinabile, 
		@PrezzoUnitarioAbbinabile, 
		@QtyAbbinata,
		@TSAbbinamento,
		@OATSAbbinamento,
		@OVTSAbbinamento,
		'A'
	)
	set @IdAbbinamento = @@Identity
	--

	-- Aggiorna Saldo Fisico in AbbinamentoOffertaAcquisto
	exec AggiornaSaldoFisico @IdSessioneMercato, @IdContratto, @OACodiceOperatore, @OVCodiceOperatore, @QtyAbbinata
	--

	set @DailyMsg = 
		'<msg>'

		+ '<it>'
		+ '<op>' + @OACodiceOperatore + '</op> (offerId=' +cast(@IdOffertaAcquisto   as nvarchar(20)) + ') ha comprato da '
		+ '<op>' + @OVCodiceOperatore + '</op> (offerId=' +cast(@IdOffertaAbbinabile as nvarchar(20)) + ') '
		+ '<Qty/> ' + @NomeContratto 
		+ ' a <Price/>' 
		+ '</it>'

		+ '<en>'
		+ '<op>' + @OACodiceOperatore + '</op> (offerId=' +cast(@IdOffertaAcquisto   as nvarchar(20)) + ') has bought from '
		+ '<op>' + @OVCodiceOperatore + '</op> (offerId=' +cast(@IdOffertaAbbinabile as nvarchar(20)) + ') '
		+ '<Qty/> ' + @NomeContratto 
		+ ' at <Price/>' 
		+ '</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@IdSessioneMercato, 
		'ABB', 
		@DailyMsg, 
		@TSAbbinamento, 
		null, 		-- Non e' una offerta
		@IdAbbinamento, 
		null,		-- Interessa tutti
		@QtyAbbinata,
		@PrezzoUnitarioAbbinabile,	
		@IdActivity OUTPUT 

	-- INIZIO AGGIORNA SESSIONEMERCATOCONTRATTO

	update 
	SessioneMercatoContratto
	set
	LastPrice = @PrezzoUnitarioAbbinabile, 
	LastTime = @TSAbbinamento, 
	LastQty = @QtyAbbinata,
	LastisOTC = 'N',
	MaxPrice = (CASE
		   WHEN @PrezzoUnitarioAbbinabile> IsNull(MaxPrice,0) 
			THEN @PrezzoUnitarioAbbinabile 
			else MaxPrice
		   END),
	MinPrice = (CASE
		   WHEN @PrezzoUnitarioAbbinabile < IsNull(MinPrice,1e50) 
			THEN @PrezzoUnitarioAbbinabile
			else MinPrice
		   END),
	Volume = ISNULL(Volume,0) + @QtyAbbinata
	where
	1=1
	and IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto

	if (@@ROWCOUNT = 0)
	begin
	   exec MyTraceAdd 'AbbinamentoOffertaAcquisto: Fallito Update SessioneMercatoContratto.'
	end

	-- FINE AGGIORNA SESSIONEMERCATOCONTRATTO
	
	fetch next from OVAbbinabili into @IdOffertaAbbinabile, @QtyResiduaAbbinabile, @PrezzoUnitarioAbbinabile, @OVCodiceOperatore, @OVTSAbbinamento
end

close OVAbbinabili
deallocate OVAbbinabili

-- Fine gestione ricerca abbinamenti sulle righe delle offerte di vendita

-- Qualora fosse stata dichiarata una incompatibilita'
-- all'inizio della procedura, in presenza di un prezzo compatibile,
-- adesso possiamo rendere l'offerta di acquisto compatibili, visto che
-- l'abbiamo esaurita completamente, SOLO IN QUESTO CASO.
if (@OAQtyRes = 0)
	set @Compatibile = 'S'
--


-- Inizio Aggiorna Offerta di acquisto (Quantita' residua e compatibilita')

if (@OffertaAMercato = 'S')
begin
	-- Se offerta a mercato inserisce prezzo unitario
	-- da utilizzarsi eventualmente per abbinamenti successivi
	-- Nota: Rimane in ogni caso traccia del fatto che l'offerta
	-- e' partita senza limite di prezzo nel campo OffertaAMercato='S'.
	update 
	Offerta
	set
	QtyResidua = @OAQtyRes, 
	Compatibile = @Compatibile, 
	PrezzoUnitario = @PrezzoAcquistoOffertaAMercato
	where
	IdSessioneMercato = @IdSessioneMercato	--
	and IdContratto = @IdContratto		--
	and IdOfferta = @IdOffertaAcquisto	--
end
else
begin
	-- Se offerta con prezzo iniziale NON MODIFICA prezzo unitario
	update 
	Offerta
	set
	QtyResidua = @OAQtyRes, 
	Compatibile = @Compatibile
	where
	IdSessioneMercato = @IdSessioneMercato	--
	and IdContratto = @IdContratto		--
	and IdOfferta = @IdOffertaAcquisto	--
end

-- Fine Aggiorna Offerta di ascquisto (Quantita' residua e compatibilita')

-- Inizio confezione stringa di esito della stored

/*
Make Variabile di stato abbinamento
	Primo carattere di StatoAbbinamento
		N Non abbinata
		T Abbinata totalmente
		P Abbinata parzialmente
	Secondo carattere di StatoAbbinamento
		C compatibile --> rimane attiva nel book
		N non compatibile --> viene tolta dal book
*/

if (@OAQtyRes = @OAQtyResOriginale) set @StatoAbbinamento = 'N'
else if (@OAQtyRes = 0) set @StatoAbbinamento = 'T'
else set @StatoAbbinamento = 'P'

if (@Compatibile = 'S' and @OAQtyRes > 0) 
	set @StatoAbbinamento = @StatoAbbinamento + 'C'
else
	set @StatoAbbinamento = @StatoAbbinamento + 'N'

-- Fine confezione stringa di esito della stored

--
end	-- Procedura
--

--- Fine Create

---

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[AbbinamentoOffertaAcquisto]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.AbbinamentoOffertaAcquistoOTC    Script Date: 20/10/2005 16.32.06 ******/



--- Inizio Create
CREATE     procedure dbo.AbbinamentoOffertaAcquistoOTC
	@IdOffertaAcquisto int,
	@StatoAbbinamento varchar(2) output
as

--
begin	-- Procedura
--

-- Leggo campi relativi all'offerta di acquisto in questione
-- Di cui e' noto @IdOffertaAcquisto
Declare
@IdSessioneMercato int,
@IdContratto int,
@OACodiceOperatore varchar(8), -- tipoCodiceOperatore
@OffertaAMercato char(1),
@OAPrezzoUnitario float,
@OAQtyRes int,
@OAOperatoreOTC varchar(8),	-- tipoCodiceOperatore
@OACodiceOTC varchar(32),
@OATSAbbinamento datetime,
@NomeContratto tipoNomecontratto

declare @IdAbbinamento int
declare @DailyMsg nvarchar(1024)
declare @IdActivity int

select top 1
@IdSessioneMercato=	Offerta.IdSessioneMercato,
@IdContratto=		Offerta.IdContratto,
@OACodiceOperatore=	Offerta.CodiceOperatore,
@OffertaAMercato=	Offerta.OffertaAMercato,
@OAPrezzoUnitario=	Offerta.PrezzoUnitario,
@OAQtyRes=		Offerta.QtyResidua,
@OAOperatoreOTC=	Offerta.OperatoreOTC,	 -- Eventuale Offerta di acquisto OTC
@OACodiceOTC=		Offerta.CodiceOTC,	 -- Eventuale Offerta di acquisto OTC
@OATSAbbinamento=	Offerta.TSAbbinamento,
@NomeContratto= 	Contratto.NomeContratto
from Offerta
inner join Contratto
on Contratto.IdContratto = Offerta.IdContratto
where
IdOfferta = @IdOffertaAcquisto
--

-- Se Offerta di Acquisto NON OTC esce dalla procedura (non dovrebbe avvenire)
if ((LEN(@OAOperatoreOTC) = 0) OR (LEN(@OACodiceOTC) = 0))
begin
	set @StatoAbbinamento = 'NN'
	return		
end
--

-- Verifica altre condizioni di incompatibilita' dell'offerta di acquisto OTC
-- Se Offerta a mercato e/o prezzo unitario = 0 e/o Qty = 0
-- segna l'offerta di ACQUISTO come NON COMPATIBILE (non dovrebbe avvenire).
if (@OffertaAMercato = 'S') OR (@OAPrezzoUnitario = 0) OR (@OAQtyRes = 0)
begin
	-- NON COMPATIBILE
	update 
	Offerta
	set
	Compatibile = 'N'
	where
	1=1
	and IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto
	and IdOfferta = @IdOffertaAcquisto
	
	set @StatoAbbinamento = 'NN'
	return		
	--
end
--

-- Ricerca eventuale offerta di vendita corrispondente
Declare
@OVIdOfferta int,
@OVQtyResidua int,
@OVPrezzoUnitario float,
@OVCodiceOperatore varchar(8), -- tipoCodiceOperatore
@OVTSAbbinamento datetime

select
@OVIdOfferta=IdOfferta,
@OVQtyResidua=QtyResidua,
@OVPrezzoUnitario=PrezzoUnitario,
@OVCodiceOperatore=OV.CodiceOperatore,
@OVTSAbbinamento=OV.TSAbbinamento
from
OffertaVenditaBook OV
inner join Operatore OP				-- Verifica Operatore Abilitato
on  OP.CodiceOperatore = @OAOperatoreOTC	-- Verifica Operatore Abilitato
where
1=1
and OV.IdSessioneMercato = @IdSessioneMercato	--
and OV.IdContratto = @IdContratto		--
and OV.OffertaAMercato <> 'S'			--
and OV.PrezzoUnitario > 0			--
and OV.CodiceOperatore = @OAOperatoreOTC	-- Controparte OTC dichiarata nell'off. di acquisto
and OV.CodiceOTC = @OACodiceOTC			-- Stesso Codice OTC
and OP.AbilitazioneMercato = 'S'		-- Verifica Operatore Abilitato

if @@RowCount > 1
begin
	if @@trancount > 0 rollback
	RaisError('AbbinamentoOffertaAcquistoOTC: trovate offerte di vendita multiple', 16, 1) with seterror
	return
end


-- Se non esiste l'offerta corrispondente 
-- Non effettua abbinamento ed esce
if (@OVIdOfferta is null)
begin	
       	-- set @StatoAbbinamento = 'NN'
       	set @StatoAbbinamento = 'NC'
	return		
end

-- Se esiste l'offerta corrispondente ma Qty e/o Prezzo diversi
-- non abbina e segna l'offerta di ACQUISTO come NON COMPATIBILE
if (@OAQtyRes <> @OVQtyResidua) OR (@OAPrezzoUnitario <> @OVPrezzoUnitario)
begin

	-- NON COMPATIBILE
	update 
	Offerta
	set
	Compatibile = 'N'
	where
	1=1
	and IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto
	and IdOfferta = @IdOffertaAcquisto
	--
	
	--
	set @StatoAbbinamento = 'NN'
	return		
	--
end
--

-- Azzera le quantita' residue nelle Offerte di vendita/acquisto
update 
Offerta
set
QtyResidua = 0
where

1=1

and IdSessioneMercato = @IdSessioneMercato	--
and IdContratto = @IdContratto			--
and (IdOfferta = @OVIdOfferta or IdOfferta = @IdOffertaAcquisto)
--

--
declare @TSAbbinamento as datetime
set @TSAbbinamento = getdate()
--

-- Inserisce Abbinamento
insert into Abbinamento
(
	IdSessioneMercato, 	--
	IdContratto, 		--
	IdOffertaAcquisto, 
	IdOffertaVendita, 
	PrezzoUnitario, 
	QtyAbbinata,
	TSAbbinamento,
	TSOAAbbinamento,	-- Nuovi Campi
	TSOVAbbinamento,	-- Nuovi Campi
	AbbinamentoCausatoDa	-- Nuovi Campi
)
values 
(

	@IdSessioneMercato,	--

	@IdContratto, 		--
	@IdOffertaAcquisto, 
	@OVIdOfferta, 
	@OVPrezzoUnitario, 
	@OVQtyResidua,
	@TSAbbinamento,
	@OATSAbbinamento,
	@OVTSAbbinamento,
	'A'
)
set @IdAbbinamento = @@Identity
--

-- Aggiorna Saldo Fisico in AbbinamentoOffertaAcquistoOTC
exec AggiornaSaldoFisico @IdSessioneMercato, @IdContratto, @OACodiceOperatore, OVCodiceOperatore, @OVQtyResidua
--

set @DailyMsg = 
	'<msg>'

	+ '<it>'
	+ '<op>' + @OACodiceOperatore + '</op> (offerId=' +cast(@IdOffertaAcquisto   as nvarchar(20)) + ') ha comprato da '
	+ '<op>' + @OVCodiceOperatore + '</op> (offerId=' +cast(@OVIdOfferta as nvarchar(20)) + ') '
	+ '<Qty/> ' + @NomeContratto 
	+ ' a <Price/>' 
	+ '</it>'

	+ '<en>'
	+ '<op>' + @OACodiceOperatore + '</op> (offerId=' +cast(@IdOffertaAcquisto   as nvarchar(20)) + ') has bought from '
	+ '<op>' + @OVCodiceOperatore + '</op> (offerId=' +cast(@OVIdOfferta as nvarchar(20)) + ') '
	+ '<Qty/> ' + @NomeContratto 
	+ ' at <Price/>' 
	+ '</en></msg>'

EXEC [dbo].[DailyActivityLog_Insert] 
	@IdSessioneMercato, 
	'ABB', 
	@DailyMsg, 
	@TSAbbinamento, 
	null, 		-- Non e' una offerta
	@IdAbbinamento, 
	null,		-- Interessa tutti
	@OVQtyResidua,
	@OVPrezzoUnitario,	
	@IdActivity OUTPUT 

-- INIZIO AGGIORNA SESSIONEMERCATOCONTRATTO

update 
SessioneMercatoContratto
set
LastPrice = @OVPrezzoUnitario, 
LastTime = @TSAbbinamento, 
MaxPrice = (CASE
	   WHEN @OVPrezzoUnitario> IsNull(MaxPrice,0) 
	    	THEN @OVPrezzoUnitario 
		else MaxPrice
	   END),
MinPrice = (CASE
	   WHEN @OVPrezzoUnitario < IsNull(MinPrice,1e50) 
		THEN @OVPrezzoUnitario
		else MinPrice
	   END),
Volume = ISNULL(Volume,0) + @OVQtyResidua,
LastQty = @OVQtyResidua,
LastisOTC = 'S'
where
1=1
and IdSessioneMercato = @IdSessioneMercato
and IdContratto = @IdContratto

if (@@ROWCOUNT = 0)
begin
   exec MyTraceAdd 'AbbinamentoOffertaAcquistoOTC: Fallito Update SessioneMercatoContratto.'
end

-- FINE AGGIORNA SESSIONEMERCATOCONTRATTO


-- T Abbinata totalmente
-- C compatibile (ovvero rimane attiva nel book)
set @StatoAbbinamento = 'T'
set @StatoAbbinamento = @StatoAbbinamento + 'N'
--

--
end	-- Procedura
--

--- Fine Create




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[AbbinamentoOffertaAcquistoOTC]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.AbbinamentoOffertaVendita    Script Date: 20/10/2005 16.32.06 ******/


---

--- Inizio Create

CREATE       procedure dbo.AbbinamentoOffertaVendita
	@IdOffertaVendita int,
	@StatoAbbinamento varchar(2) output
as

--
begin	-- Procedura
--

-- Leggo campi relativi all'offerta di vendita in questione
-- Di cui e' noto @IdOffertaVendita
Declare
@IdSessioneMercato int,
@IdContratto int,
@OVCodiceOperatore varchar(8),  -- tipoCodiceOperatore
@OffertaAMercato char(1),
@OVPrezzoUnitario float,
@OVQtyRes int,
@OVOperatoreOTC varchar(8),	-- tipoCodiceOperatore
@OVCodiceOTC varchar(32),
@OVTSAbbinamento datetime,
@NomeContratto tipoNomecontratto

declare @IdAbbinamento int
declare @DailyMsg nvarchar(1024)
declare @IdActivity int

select top 1
@IdSessioneMercato=	Offerta.IdSessioneMercato,
@IdContratto=		Offerta.IdContratto,
@OVCodiceOperatore=	Offerta.CodiceOperatore,
@OffertaAMercato=	Offerta.OffertaAMercato,
@OVPrezzoUnitario=	Offerta.PrezzoUnitario,
@OVQtyRes=		Offerta.QtyResidua,
@OVOperatoreOTC=	Offerta.OperatoreOTC,	 -- Eventuale Offerta di vendita OTC (da scartare)
@OVCodiceOTC=		Offerta.CodiceOTC,	 -- Eventuale Offerta di vendita OTC (da scartare)	
@OVTSAbbinamento=	Offerta.TSAbbinamento,
@NomeContratto= 	Contratto.NomeContratto
from Offerta
inner join Contratto
on Contratto.IdContratto = Offerta.IdContratto
where
IdOfferta = @IdOffertaVendita
--

-- Se Offerta di Vendita OTC esce dalla procedura (Non dovrebbe avvenire)
if ((LEN(@OVOperatoreOTC) > 0) OR (LEN(@OVCodiceOTC) > 0))
BEGIN
-- 	set @StatoAbbinamento = 'NN'
	exec AbbinamentoOffertaVenditaOTC @IdOffertaVendita, @StatoAbbinamento output
	return		
END
--

-- Inizio gestione di una eventuale OFFERTA DI VENDITA A MERCATO.

-- Le proposte senza limite di prezzo hanno priorita' massima di prezzo.
-- Quindi si cerca il miglior prezzo fra le offerte di acquisto
-- (ovvero quella con il prezzo maggiore) e lo si assegna alla offerta di vendita corrente.
-- Se il miglior prezzo di acquisto e' stato emesso dall'operatore stesso
-- allora trattasi di offerta non compatibile ed esce dal book,
-- lo stesso se non esiste alcuna offerta di acquisto emessa da altri operatori.
-- Nota: Nel caso sia presente nelle offerte di acquisto una offerta dello stesso
-- operatore, ma non la migliore, la selezione automatica del prezzo pone lo stesso
-- al di sotto del prezzo compatibile e quindi non rende l'offerta di vendita
-- incompatibile anche se l'abbinamento e' parziale (QtyResidua>0)

declare @PrezzoVenditaOffertaAMercato float
declare @MemoOACodiceOperatore varchar(8)  -- tipoCodiceOperatore
if (@OffertaAMercato = 'S')
begin
	-- 
	select top 1
	@PrezzoVenditaOffertaAMercato = OA.PrezzoUnitario,
	@MemoOACodiceOperatore = OA.CodiceOperatore
	from 
	OffertaAcquistoBook OA
	inner join Operatore OP				-- Verifica Operatore Abilitato
	on  OP.CodiceOperatore = OA.CodiceOperatore	-- Verifica Operatore Abilitato
	where
	1=1	
	and OA.IdSessioneMercato = @IdSessioneMercato	--
	and OA.IdContratto = @IdContratto		--
	and LEN(OA.OperatoreOTC)=0			-- Esclude OTC
	and LEN(OA.CodiceOTC)=0				-- Esclude OTC
	and OP.AbilitazioneMercato = 'S'		-- Verifica Operatore Abilitato
	order by
	OA.PrezzoUnitario desc,	-- 102..101..100
	OA.TSAbbinamento asc	-- ieri..oggi..domani
	-- 

	-- Se non esiste alcun miglior prezzo oppure 
	-- il miglior prezzo appartiene allo stesso operatore dell'offerta di vendita
	if (@PrezzoVenditaOffertaAMercato is null) or (@MemoOACodiceOperatore=@OVCodiceOperatore)
	begin
		-- non esiste nessuna offerta accettabile di acquisto nel book
		-- quindi l'offerta di vendita a mercato deve uscire dal book
		-- ed e` marcata come non compatibile
		update 
		Offerta
		set
		Compatibile = 'N'
		where
		IdSessioneMercato = @IdSessioneMercato
		and IdContratto = @IdContratto
		and IdOfferta = @IdOffertaVendita
		
		set @StatoAbbinamento = 'NN'
		return		
	end
	begin
		-- d'ora in poi il prezzo dell'offerta di vendita a mercato
		-- assume il prezzo piu` vantaggioso nel book di acquisto
		set @OVPrezzoUnitario = @PrezzoVenditaOffertaAMercato
	end
	-- 
end

-- Fine gestione di una eventuale OFFERTA DI VENDITA A MERCATO.


-- Inizio gestione di un eventuale prezzo compatibile
-- Nota: non verifico se operatore Offerta di Vendita abilitato perche'
--       gia' controllato dalla validazione.


declare @PrezzoCompatibile as float
declare @OVQtyResOriginale int
set @OVQtyResOriginale = @OVQtyRes

select 
@PrezzoCompatibile = max (OA.PrezzoUnitario)
from
OffertaAcquistoBook OA
where
1=1
and OA.IdSessioneMercato = @IdSessioneMercato	--
and OA.IdContratto = @IdContratto		--
and LEN(OA.OperatoreOTC)=0			-- Esclude OTC
and LEN(OA.CodiceOTC)=0				-- Esclude OTC
and OA.PrezzoUnitario >= @OVPrezzoUnitario
and OA.CodiceOperatore = @OVCodiceOperatore		-- Stesso operatore

/*
Se esiste almeno una offerta di acquisto da parte dello stesso operatore
che ha un prezzo maggiore o uguale al prezzo di vendita (se piu' di una prende quella a prezzo maggiore).
Assume come prezzo compatibile il prezzo di acquisto della suddetta e 
inizializza l'offerta di vendita a non compatibile (deve uscire dal book alla fine di questo giro di abbinamenti)

Se non ne esiste nessuna assume come prezzo compatibile zero
(ovvero, in relazione al prezzo compatibile, considera tutte le offerte di acquisto)
e inizializza l'offerta di vendita a compatibile.
*/

declare @Compatibile as char(1)
set @Compatibile = 'N'
if (@PrezzoCompatibile is null)
begin
	set @PrezzoCompatibile = 0
	set @Compatibile = 'S'  -- l'offerta potra` rimanere nel book per la quantita` residua
end

-- Fine gestione Di un eventuale prezzo compatibile

-- Inizio gestione ricerca abbinamenti sulle righe delle offerte di acquisto

declare OAAbbinabili cursor keyset for
	select
	OA.IdOfferta,
	OA.QtyResidua,
	OA.PrezzoUnitario,
	OA.CodiceOperatore,
	OA.TSAbbinamento
	from 
	Offerta OA
	inner join Operatore OP				-- Verifica Operatore Abilitato
	on  OP.CodiceOperatore = OA.CodiceOperatore	-- Verifica Operatore Abilitato
	where
	1=1
	and (OA.TipoOfferta = 'A') 			--
	and (OA.StatoOfferta = 'VA') 			--
	and (OA.Compatibile = 'S') 			--
	and (OA.QtyResidua > 0)				--
	and OA.IdSessioneMercato = @IdSessioneMercato	--
	and OA.IdContratto = @IdContratto		--
	and LEN(OA.OperatoreOTC)=0			-- Esclude OTC
	and LEN(OA.CodiceOTC)=0				-- Esclude OTC
	and OP.AbilitazioneMercato = 'S'		-- Verifica Operatore Abilitato
	and OA.PrezzoUnitario >= @OVPrezzoUnitario
	and OA.PrezzoUnitario > @PrezzoCompatibile	--
	and OA.CodiceOperatore != @OVCodiceOperatore   	-- probabilamente non serve.
	order by
	OA.PrezzoUnitario desc,				-- 102..101..100
	OA.TSAbbinamento asc				-- ieri..oggi..domani

declare @IdOffertaAbbinabile int
declare @QtyResiduaAbbinabile int
declare @PrezzoUnitarioAbbinabile float
declare @OACodiceOperatore varchar(8) -- tipoCodiceOperatore
declare @OATSAbbinamento datetime

open OAAbbinabili
fetch next from OAAbbinabili into @IdOffertaAbbinabile, @QtyResiduaAbbinabile, @PrezzoUnitarioAbbinabile, @OACodiceOperatore, @OATSAbbinamento
while (@@FETCH_STATUS = 0)
begin
	-- Se tutta la quantita' acquistata esce
	if (@OVQtyRes = 0) break
		
	-- Abbina il piu' possibile della quantita da comprare :-)
	declare @QtyAbbinata int
	set @QtyAbbinata = @OVQtyRes
	if (@QtyAbbinata > @QtyResiduaAbbinabile) set @QtyAbbinata = @QtyResiduaAbbinabile

	set @OVQtyRes = @OVQtyRes - @QtyAbbinata

	-- Aggiorna la quantita' residua dell' Offerta di acquisto
	-- N.B. Sulla riga corrente del cursore
	update 
	Offerta
	set
	QtyResidua = QtyResidua - @QtyAbbinata
	where
	current of OAAbbinabili
	--
	
	--
	declare @TSAbbinamento as datetime
	set @TSAbbinamento = getdate()
	--

	-- Inserisce Abbinamento
	-- al prezzo dell'offerta di acquisto trovata.
	insert into Abbinamento
	(
		IdSessioneMercato, 	--
		IdContratto, 		--
		IdOffertaAcquisto, 
		IdOffertaVendita, 
		PrezzoUnitario, 
		QtyAbbinata,
		TSAbbinamento,
		TSOAAbbinamento,	-- Nuovi Campi
		TSOVAbbinamento,	-- Nuovi Campi
		AbbinamentoCausatoDa	-- Nuovi Campi
	)
	values 
	(
		@IdSessioneMercato,		--
		@IdContratto, 			--
		@IdOffertaAbbinabile, 
		@IdOffertaVendita, 
		@PrezzoUnitarioAbbinabile, 
		@QtyAbbinata,

		@TSAbbinamento,
		@OATSAbbinamento,
		@OVTSAbbinamento,
		'V'
	)

	set @IdAbbinamento = @@Identity
	--

	-- Aggiorna Saldo Fisico AbbinamentoOffertaVendita
	exec AggiornaSaldoFisico @IdSessioneMercato, @IdContratto, @OACodiceOperatore, @OVCodiceOperatore, @QtyAbbinata
	--

	--
	set @DailyMsg = 
		'<msg>'
		+ '<it>'
		+ '<op>' + @OVCodiceOperatore + '</op> (offerId=' +cast(@IdOffertaVendita   as nvarchar(20)) + ') ha venduto a '
		+ '<op>' + @OACodiceOperatore + '</op> (offerId=' +cast(@IdOffertaAbbinabile as nvarchar(20)) + ') '
		+ '<Qty/> ' + @NomeContratto 
		+ ' a <Price/>' 
		+ '</it>'

		+ '<en>'
		+ '<op>' + @OVCodiceOperatore + '</op> (offerId=' +cast(@IdOffertaVendita   as nvarchar(20)) + ') has selled to '
		+ '<op>' + @OACodiceOperatore + '</op> (offerId=' +cast(@IdOffertaAbbinabile as nvarchar(20)) + ') '
		+ '<Qty/> ' + @NomeContratto 
		+ ' at <Price/>' 
		+ '</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@IdSessioneMercato, 
		'ABB', 
		@DailyMsg, 
		@TSAbbinamento, 
		null, 		-- Non e' una offerta
		@IdAbbinamento, 
		null,		-- Interessa tutti
		@QtyAbbinata,
		@PrezzoUnitarioAbbinabile,	
		@IdActivity OUTPUT 
	--

	-- INIZIO AGGIORNA SESSIONEMERCATOCONTRATTO

	update 

	SessioneMercatoContratto
	set
	LastPrice = @PrezzoUnitarioAbbinabile, 
	LastTime = @TSAbbinamento, 
	LastQty = @QtyAbbinata,
	LastisOTC = 'N',
	MaxPrice = (CASE
		   WHEN @PrezzoUnitarioAbbinabile> IsNull(MaxPrice,0) 
			THEN @PrezzoUnitarioAbbinabile 
			else MaxPrice
		   END),
	MinPrice = (CASE
		   WHEN @PrezzoUnitarioAbbinabile < IsNull(MinPrice,1e50) 
			THEN @PrezzoUnitarioAbbinabile
			else MinPrice
		   END),
	Volume = ISNULL(Volume,0) + @QtyAbbinata
	where
	1=1
	and IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto

	if (@@ROWCOUNT = 0)
	begin
	   exec MyTraceAdd 'AbbinamentoOffertaVendita: Fallito Update SessioneMercatoContratto.'
	end

	-- FINE AGGIORNA SESSIONEMERCATOCONTRATTO
	
	fetch next from OAAbbinabili into @IdOffertaAbbinabile, @QtyResiduaAbbinabile, @PrezzoUnitarioAbbinabile, @OACodiceOperatore, @OATSAbbinamento
end

close OAAbbinabili
deallocate OAAbbinabili

-- Fine gestione ricerca abbinamenti sulle righe delle offerte di acquisto

-- Qualora fosse stata dichiarata una incompatibilita'
-- all'inizio della procedura, in presenza di un prezzo compatibile,
-- adesso possiamo rendere l'offerta di vendita compatibili, visto che
-- l'abbiamo esaurita completamente, SOLO IN QUESTO CASO.
if (@OVQtyRes = 0)
	set @Compatibile = 'S'
--

-- Inizio Aggiorna Offerta di vendita (Quantita' residua e compatibilita')

if (@OffertaAMercato = 'S')
begin
	-- Se offerta a mercato inserisce prezzo unitario
	-- da utilizzarsi eventualmente per abbinamenti successivi
	-- Nota: Rimane in ogni caso traccia del fatto che l'offerta
	-- e' partita senza limite di prezzo nel campo OffertaAMercato='S'.
	update 
	Offerta
	set
	QtyResidua = @OVQtyRes, Compatibile = @Compatibile, PrezzoUnitario = @PrezzoVenditaOffertaAMercato
	where
	IdSessioneMercato = @IdSessioneMercato	--
	and IdContratto = @IdContratto		--
	and IdOfferta = @IdOffertaVendita	--
end
else
begin
	-- Se offerta con prezzo iniziale NON MODIFICA prezzo unitario
	update 
	Offerta
	set
	QtyResidua = @OVQtyRes, Compatibile = @Compatibile
	where
	IdSessioneMercato = @IdSessioneMercato	--
	and IdContratto = @IdContratto		--
	and IdOfferta = @IdOffertaVendita	--
end

-- Fine Aggiorna Offerta di vendita (Quantita' residua e compatibilita')

-- Inizio confezione stringa di esito della stored

/*
Make Variabile di stato abbinamento
	Primo carattere di StatoAbbinamento
		N Non abbinata
		T Abbinata totalmente
		P Abbinata parzialmente
	Secondo carattere di StatoAbbinamento
		C compatibile --> rimane attiva nel book
		N non compatibile --> viene tolta dal book
*/

if (@OVQtyRes = @OVQtyResOriginale) set @StatoAbbinamento = 'N'
else if (@OVQtyRes = 0) set @StatoAbbinamento = 'T'
else set @StatoAbbinamento = 'P'

if (@Compatibile = 'S' and @OVQtyRes > 0) 
	set @StatoAbbinamento = @StatoAbbinamento + 'C'
else
	set @StatoAbbinamento = @StatoAbbinamento + 'N'

-- Fine confezione stringa di esito della stored

--
end	-- Procedura
--

--- Fine Create

---

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[AbbinamentoOffertaVendita]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.AbbinamentoOffertaVenditaOTC    Script Date: 20/10/2005 16.32.06 ******/



---

--- Inizio Create

CREATE      procedure dbo.AbbinamentoOffertaVenditaOTC
	@IdOffertaVendita int,
	@StatoAbbinamento varchar(2) output
as

--
begin	-- Procedura
--

-- Leggo campi relativi all'offerta di vendita in questione
-- Di cui e' noto @IdOffertaVendita
Declare
@IdSessioneMercato int,
@IdContratto int,
@OVCodiceOperatore varchar(8),  -- tipoCodiceOperatore
@OffertaAMercato char(1),
@OVPrezzoUnitario float,
@OVQtyRes int,
@OVOperatoreOTC varchar(8),	-- tipoCodiceOperatore
@OVCodiceOTC varchar(32),
@OVTSAbbinamento datetime,
@NomeContratto tipoNomecontratto

declare @IdAbbinamento int
declare @DailyMsg nvarchar(1024)
declare @IdActivity int

select top 1
@IdSessioneMercato=	Offerta.IdSessioneMercato,
@IdContratto=		Offerta.IdContratto,
@OVCodiceOperatore=	Offerta.CodiceOperatore,
@OffertaAMercato=	Offerta.OffertaAMercato,
@OVPrezzoUnitario=	Offerta.PrezzoUnitario,
@OVQtyRes=		Offerta.QtyResidua,
@OVOperatoreOTC=	Offerta.OperatoreOTC, 	-- Eventuale Offerta di vendita OTC
@OVCodiceOTC=		Offerta.CodiceOTC,	-- Eventuale Offerta di vendita OTC
@OVTSAbbinamento=	Offerta.TSAbbinamento,
@NomeContratto= 	Contratto.NomeContratto
from Offerta
inner join Contratto
on Contratto.IdContratto = Offerta.IdContratto
where
IdOfferta = @IdOffertaVendita
--

-- Se Offerta di Vendita NON OTC esce dalla procedura (non dovrebbe avvenire)
if ((LEN(@OVOperatoreOTC) = 0) OR (LEN(@OVCodiceOTC) = 0))
begin
	set @StatoAbbinamento = 'NN'
	return		
end
--

-- Verifica altre condizioni di incompatibilita' dell'offerta di vendita OTC
-- Se Offerta a mercato e/o prezzo unitario = 0 e/o Qty = 0
-- segna l'offerta di VENDITA come NON COMPATIBILE (non dovrebbe avvenire).
if (@OffertaAMercato = 'S') OR (@OVPrezzoUnitario = 0) OR (@OVQtyRes = 0)
begin
	-- NON COMPATIBILE
	update 
	Offerta
	set
	Compatibile = 'N'
	where
	1=1
	and IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto
	and IdOfferta = @IdOffertaVendita
	
	set @StatoAbbinamento = 'NN'
	return		
	--
end
--

-- Ricerca eventuale offerta di acquisto corrispondente
Declare
@OAIdOfferta int,
@OAQtyResidua int,
@OAPrezzoUnitario float,
@OACodiceOperatore varchar(8), -- tipoCodiceOperatore
@OATSAbbinamento datetime

select
@OAIdOfferta=IdOfferta,
@OAQtyResidua=QtyResidua,
@OAPrezzoUnitario=PrezzoUnitario,
@OACodiceOperatore=OA.CodiceOperatore,
@OATSAbbinamento=OA.TSAbbinamento 

from
OffertaAcquistoBook OA
inner join Operatore OP				-- Verifica Operatore Abilitato
on  OP.CodiceOperatore = @OVOperatoreOTC	-- Verifica Operatore Abilitato
where
1=1
and OA.IdSessioneMercato = @IdSessioneMercato	--
and OA.IdContratto = @IdContratto		--
and OA.OffertaAMercato <> 'S'			--
and OA.PrezzoUnitario > 0			--
and OA.CodiceOperatore = @OVOperatoreOTC	-- Controparte OTC dichiarata nell'off. di vendita
and OA.CodiceOTC = @OVCodiceOTC			-- Stesso Codice OTC
and OP.AbilitazioneMercato = 'S'		-- Verifica Operatore Abilitato

if @@RowCount > 1
begin
	if @@trancount > 0 rollback
	RaisError('AbbinamentoOffertaVenditaOTC: trovate offerte di acquisto multiple', 16, 1) with seterror
	return
end


-- Se non esiste l'offerta corrispondente 
-- Non effettua abbinamento ed esce
if (@OAIdOfferta is null)
begin
       	-- set @StatoAbbinamento = 'NN'
       	set @StatoAbbinamento = 'NC'
	return		
end

-- Se esiste l'offerta corrispondente ma Qty e/o Prezzo diversi
-- non abbina e segna l'offerta di VENDITA come NON COMPATIBILE
if (@OVQtyRes <> @OAQtyResidua) OR (@OVPrezzoUnitario <> @OAPrezzoUnitario)
begin
	-- NON COMPATIBILE
	update 
	Offerta
	set
	Compatibile = 'N'
	where
	1=1
	and IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto
	and IdOfferta = @IdOffertaVendita
	--
	
	--
	set @StatoAbbinamento = 'NN'
	return		
	--
end
--

-- Azzera le quantita' residue nell'Offerte di vendita/acquisto
update 
Offerta
set
QtyResidua = 0
where
1=1
and IdSessioneMercato = @IdSessioneMercato	--
and IdContratto = @IdContratto			--
and IdOfferta = @OAIdOfferta
and (IdOfferta = @OAIdOfferta or IdOfferta = @IdOffertaVendita)
--

--
declare @TSAbbinamento as datetime
set @TSAbbinamento = getdate()
--

-- Inserisce Abbinamento
insert into Abbinamento
(
	IdSessioneMercato, 	--
	IdContratto, 		--
	IdOffertaAcquisto, 
	IdOffertaVendita, 
	PrezzoUnitario, 
	QtyAbbinata,
	TSAbbinamento,
	TSOAAbbinamento,	-- Nuovi Campi
	TSOVAbbinamento,	-- Nuovi Campi
	AbbinamentoCausatoDa	-- Nuovi Campi
)
values 
(
	@IdSessioneMercato,	--
	@IdContratto, 		--
	@OAIdOfferta,
	@IdOffertaVendita, 		
	@OAPrezzoUnitario, 
	@OAQtyResidua,
	@TSAbbinamento,
	@OATSAbbinamento,
	@OVTSAbbinamento,
	'V'
)
set @IdAbbinamento = @@Identity
--

-- Aggiorna Saldo Fisico AbbinamentoOffertaVenditaOTC
exec AggiornaSaldoFisico @IdSessioneMercato, @IdContratto, @OACodiceOperatore, @OVCodiceOperatore, @OAQtyResidua
--

--
set @DailyMsg = 
	'<msg>'
	+ '<it>'
	+ '<op>' + @OVCodiceOperatore + '</op> (offerId=' +cast(@IdOffertaVendita   as nvarchar(20)) + ') ha venduto a '
	+ '<op>' + @OACodiceOperatore + '</op> (offerId=' +cast(@OAIdOfferta as nvarchar(20)) + ') '
	+ '<Qty/> ' + @NomeContratto 
	+ ' a <Price/>' 
	+ '</it>'

	+ '<en>'
	+ '<op>' + @OVCodiceOperatore + '</op> (offerId=' +cast(@IdOffertaVendita   as nvarchar(20)) + ') has selled to '
	+ '<op>' + @OACodiceOperatore + '</op> (offerId=' +cast(@OAIdOfferta as nvarchar(20)) + ') '
	+ '<Qty/> ' + @NomeContratto 
	+ ' at <Price/>' 
	+ '</en>'
	+ '</msg>'

EXEC [dbo].[DailyActivityLog_Insert] 
	@IdSessioneMercato, 
	'ABB', 
	@DailyMsg, 
	@TSAbbinamento, 
	null, 		-- Non e' una offerta
	@IdAbbinamento, 
	null,		-- Interessa tutti
	@OAQtyResidua,
	@OAPrezzoUnitario,	
	@IdActivity OUTPUT 
--

-- INIZIO AGGIORNA SESSIONEMERCATOCONTRATTO

update 
SessioneMercatoContratto
set
LastPrice = @OAPrezzoUnitario, 
LastTime = @TSAbbinamento, 
MaxPrice = (CASE
	   WHEN @OAPrezzoUnitario> IsNull(MaxPrice,0) 
	    	THEN @OAPrezzoUnitario 
		else MaxPrice
	   END),
MinPrice = (CASE
	   WHEN @OAPrezzoUnitario < IsNull(MinPrice,1e50) 
		THEN @OAPrezzoUnitario
		else MinPrice
	   END),
Volume = Volume + ISNULL(Volume,0),
LastQty = @OAQtyResidua,
LastisOTC = 'S'
where
1=1
and IdSessioneMercato = @IdSessioneMercato
and IdContratto = @IdContratto

if (@@ROWCOUNT = 0)
begin
   exec MyTraceAdd 'AbbinamentoOffertaVenditaOTC: Fallito Update SessioneMercatoContratto.'
end

-- FINE AGGIORNA SESSIONEMERCATOCONTRATTO


-- T Abbinata totalmente
-- C compatibile (ovvero rimane attiva nel book)
set @StatoAbbinamento = 'T'
set @StatoAbbinamento = @StatoAbbinamento + 'N'
--

--
end	-- Procedura
--

--- Fine Create

---




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[AbbinamentoOffertaVenditaOTC]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.AggiornaBookRiassuntivoAskBid    Script Date: 20/10/2005 16.32.06 ******/


CREATE   PROCEDURE [dbo].[AggiornaBookRiassuntivoAskBid] 
	@IdSessioneMercato int,
	@Idcontratto int
AS


declare @AskIdOfferta int
declare @AskPrice float
declare @AskQty int
declare @AskCodiceOperatore varchar(8)	-- tipoCodiceOperatore
declare @AskTS datetime

declare @BidIdOfferta int
declare @BidPrice float
declare @BidQty int
declare @BidCodiceOperatore varchar(8)	-- tipoCodiceOperatore
declare @BidTS datetime

EXEC MyTraceAdd 'AggiornaBookRiassuntivoAskBid: Start'

--- sezione Ask = Vendita
select
Top 1
@AskIdOfferta       = IdOfferta,
@AskPrice           = PrezzoUnitario,
@AskQty             = QtyResidua,
@AskCodiceOperatore = CodiceOperatore,
@AskTS              = TSAbbinamento
from
OffertaVenditaBook
where
1=1
and IdSessioneMercato = @IdSessioneMercato
and IdContratto = @IdContratto
order by
PrezzoUnitario asc,
TSAbbinamento asc

--- sezione Bid = Acquisto
select
Top 1
@BidIdOfferta       = IdOfferta,
@BidPrice           = PrezzoUnitario,
@BidQty             = QtyResidua,
@BidCodiceOperatore = CodiceOperatore,
@BidTS              = TSAbbinamento

from
OffertaAcquistoBook
where
1=1
and IdSessioneMercato = @IdSessioneMercato
and IdContratto = @IdContratto
order by
PrezzoUnitario desc,
TSAbbinamento asc


-- determino i precedenti prezzi di ask e bid
declare @PrevAskPrice float
declare @PrevBidPrice float
declare @PrevIndicators tinyint


select
@PrevIndicators=isnull(Indicators, 0),
@PrevAskPrice=isnull(AskPrice, @AskPrice),
@PrevBidPrice=isnull(BidPrice, @BidPrice)
from 
SessioneMercatoContratto
where
1=1
and IdSessioneMercato = @IdSessioneMercato
and IdContratto       = @IdContratto


-- @Indicators sara` diverso solo se il Ask o Bid Prezzo cambia
-- altrimenti rimane uguale al precedente update
-- In pratica i bit degli Indicators cambiano SOLO
-- se la migliore offerta Ask/Bid nel book cambia il prezzo rispetto alla precedente
-- Se il prezzo NON cambia il bit NON viene toccato
-- Se il prezzo SALE setto il bit di salita e resetto il bit di discesa
-- Le specifiche impongono di resettare questi bit dopo <n> secondi.
-- Il db non viene interrogato in polling ma su evento, quindi non e` in grado
-- di resettare i bit di trend dei prezzi.
-- E` il server della cache che si occupa di azzerare i bit quando e` passato il timeout
declare @Indicators tinyint
set @Indicators = @PrevIndicators

-- questi sono a NULL
-- se si verifica un cambiamento nel BidPrice o nel AskPrice
-- assegno a ciascuno la data corrente
declare @IndicatorBidChangeTS datetime
declare @IndicatorAskChangeTS datetime
set @IndicatorBidChangeTS = null
set @IndicatorAskChangeTS = null

if (@BidPrice > @PrevBidPrice)
begin
	-- setto il bit 1 e resetto il bit 2
	set @Indicators = (@Indicators | 1) & (255 - 2)
	set @IndicatorBidChangeTS = getdate()
end

if (@BidPrice < @PrevBidPrice) 
begin
	-- setto il bit 2 e resetto il bit 1
	set @Indicators = (@Indicators | 2) & (255 - 1)
	set @IndicatorBidChangeTS = getdate()
end

if (@AskPrice > @PrevAskPrice) 
begin
	-- setto il bit 4 e resetto il bit 8
	set @Indicators = (@Indicators | 4) & (255 - 8)
	set @IndicatorAskChangeTS = getdate()
end

if (@AskPrice < @PrevAskPrice) 
begin
	-- setto il bit 8 e resetto il bit 4
	set @Indicators = (@Indicators | 8) & (255 - 4)
	set @IndicatorAskChangeTS = getdate()
end

--declare @mm varchar(512)
--set @mm = convert(varchar(10), @PrevIndicators) + ' ' + convert(varchar(10), @Indicators)
--exec MyTraceAdd @mm
--set @mm = convert(varchar(10), @PrevBidPrice) + ' ' + convert(varchar(10), @BidPrice)
--exec MyTraceAdd @mm
--set @mm = convert(varchar(10), @PrevAskPrice) + ' ' + convert(varchar(10), @AskPrice)
--exec MyTraceAdd @mm

update 
SessioneMercatoContratto
set
AskIdOfferta       = @AskIdOfferta,
AskPrice           = @AskPrice,
AskQty             = @AskQty,
AskCodiceOperatore = @AskCodiceOperatore,
AskTS              = @AskTS,

BidIdOfferta       = @BidIdOfferta,
BidPrice           = @BidPrice,
BidQty             = @BidQty,
BidCodiceOperatore = @BidCodiceOperatore,
BidTS              = @BidTS,

Indicators         = @Indicators,

-- se @IndicatorBidChangeTS e` null non modifico il TS, altrimenti lo modifio
IndicatorBidChangeTS = IsNull(@IndicatorBidChangeTS,IndicatorBidChangeTS),
IndicatorAskChangeTS = IsNull(@IndicatorAskChangeTS,IndicatorAskChangeTS)


where
1=1
and IdSessioneMercato = @IdSessioneMercato
and IdContratto = @IdContratto

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[AggiornaBookRiassuntivoAskBid]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.CancellaContrattoD    Script Date: 20/10/2005 16.32.06 ******/


CREATE  procedure dbo.CancellaContrattoD
as
begin
	-- NOTA BENE:
	-- QUESTA SP E' STATA INSERITA SOLO PER TEST
	declare @RC int
	declare @NomeContratto tipoNomeContratto
	set @nomeContratto = 'D-BSLD-05-Jun-13'
	exec @RC = [CancellaOfferteAbbinamentiContratto] @NomeContratto 
end

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[CancellaContrattoD]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.CancellaContrattoW    Script Date: 20/10/2005 16.32.06 ******/


CREATE  procedure dbo.CancellaContrattoW
as
begin
	-- NOTA BENE:
	-- QUESTA SP E' STATA INSERITA SOLO PER TEST
	declare @RC int
	declare @NomeContratto tipoNomeContratto
	set @nomeContratto = 'W-OFPK-05-Jul-11'
	exec @RC = [CancellaOfferteAbbinamentiContratto] @NomeContratto 
end

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[CancellaContrattoW]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.Gest_RiallineaSaldoFisico    Script Date: 20/10/2005 16.32.06 ******/


CREATE   PROCEDURE dbo.Gest_RiallineaSaldoFisico
AS


delete from SaldoFisico

insert into SaldoFisico

	select
	CodiceOperatore,
	DataDelivery,
	Immissione= sum(Immissione),
	Prelievo  = sum(Prelievo),
	H01 = sum(H01),
	H02 = sum(H02),
	H03 = sum(H03),
	H04 = sum(H04),
	H05 = sum(H05),
	H06 = sum(H06),
	H07 = sum(H07),
	H08 = sum(H08),
	H09 = sum(H09),
	H10 = sum(H10),
	H11 = sum(H11),
	H12 = sum(H12),
	H13 = sum(H13),
	H14 = sum(H14),
	H15 = sum(H15),
	H16 = sum(H16),
	H17 = sum(H17),
	H18 = sum(H18),
	H19 = sum(H19),
	H20 = sum(H20),
	H21 = sum(H21),
	H22 = sum(H22),
	H23 = sum(H23),
	H24 = sum(H24),
	H25 = sum(H25)
	from 
	(
		select
		CodiceOperatore  = OV.CodiceOperatore,
		DataDelivery = T.DataDelivery,
		-- OPSF.K,
		H01 = sum(case PO.H01 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H02 = sum(case PO.H02 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H03 = sum(case PO.H03 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H04 = sum(case PO.H04 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H05 = sum(case PO.H05 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H06 = sum(case PO.H06 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H07 = sum(case PO.H07 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H08 = sum(case PO.H08 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H09 = sum(case PO.H09 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H10 = sum(case PO.H10 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H11 = sum(case PO.H11 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H12 = sum(case PO.H12 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H13 = sum(case PO.H13 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H14 = sum(case PO.H14 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H15 = sum(case PO.H15 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H16 = sum(case PO.H16 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H17 = sum(case PO.H17 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H18 = sum(case PO.H18 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H19 = sum(case PO.H19 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H20 = sum(case PO.H20 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H21 = sum(case PO.H21 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H22 = sum(case PO.H22 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H23 = sum(case PO.H23 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H24 = sum(case PO.H24 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H25 = sum(case PO.H25 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),

		Immissione =
			sum(case PO.H01 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H02 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H03 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H04 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H05 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H06 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H07 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H08 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H09 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H10 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H11 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H12 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H13 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H14 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H15 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H16 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H17 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H18 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H19 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H20 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H21 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H22 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H23 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H24 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H25 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),

		Prelievo = 0

	
		from Abbinamento AB
	
		-- Prova Filtro x Sessione FALLITA
		inner join SessioneMercato SM 
		on SM.IdSessioneMercato = AB.IdSessioneMercato
		-- and (SM.StatoSessione <> 'FALLITA')

		inner join Contratto C
		on C.IdContratto = AB.IdContratto
	
		inner join DataDelivery T
		on C.DataInizioDelivery <= T.DataDelivery and T.DataDelivery <= c.DataFineDelivery

		inner join SessioneMercatoProfiloOrario PO
		on  PO.IdSessioneMercato = AB.IdSessioneMercato
		and PO.CodiceProfilo = C.CodiceProfilo
		and PO.TipoGiorno = T.TipoGiorno
		and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
	
		inner join Offerta OV
		on OV.IdOfferta = AB.IdOffertaVendita
	
		cross join
		(
			select 1 K
		) OPSF
		where
		1=1
		and (SM.StatoSessione <> 'FALLITA')
	
		group by OV.CodiceOperatore, T.DataDelivery, OPSF.K
	
	union
	
		select
		CodiceOperatore  = OA.CodiceOperatore,
		DataDelivery = T.DataDelivery,
		-- OPSF.K,
		H01 = sum(case PO.H01 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H02 = sum(case PO.H02 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H03 = sum(case PO.H03 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H04 = sum(case PO.H04 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H05 = sum(case PO.H05 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H06 = sum(case PO.H06 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H07 = sum(case PO.H07 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H08 = sum(case PO.H08 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H09 = sum(case PO.H09 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H10 = sum(case PO.H10 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H11 = sum(case PO.H11 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H12 = sum(case PO.H12 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H13 = sum(case PO.H13 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H14 = sum(case PO.H14 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H15 = sum(case PO.H15 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H16 = sum(case PO.H16 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H17 = sum(case PO.H17 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H18 = sum(case PO.H18 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H19 = sum(case PO.H19 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H20 = sum(case PO.H20 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H21 = sum(case PO.H21 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H22 = sum(case PO.H22 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H23 = sum(case PO.H23 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H24 = sum(case PO.H24 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),
		H25 = sum(case PO.H25 when '1' then OPSF.K*AB.QtyAbbinata else 0 end),

		Immissione = 0,
		Prelievo =
			sum(case PO.H01 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H02 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H03 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H04 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H05 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H06 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H07 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H08 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H09 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H10 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H11 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H12 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H13 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H14 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H15 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H16 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H17 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H18 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H19 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H20 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H21 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H22 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H23 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H24 when '1' then OPSF.K*AB.QtyAbbinata else 0 end) +
			sum(case PO.H25 when '1' then OPSF.K*AB.QtyAbbinata else 0 end)

	
		from Abbinamento AB

		-- Prova Filtro x Sessione FALLITA
		inner join SessioneMercato SM 
		on SM.IdSessioneMercato = AB.IdSessioneMercato
		-- and (SM.StatoSessione <> 'FALLITA')
	
		inner join Contratto C
		on C.IdContratto = AB.IdContratto
	
		inner join DataDelivery T
		on C.DataInizioDelivery <= T.DataDelivery and T.DataDelivery <= c.DataFineDelivery

		inner join SessioneMercatoProfiloOrario PO
		on 1=1
		and PO.IdSessioneMercato = AB.IdSessioneMercato
		and PO.CodiceProfilo = C.CodiceProfilo

		and PO.TipoGiorno = T.TipoGiorno
		and PO.MeseUltimaDomenica = T.MeseUltimaDomenica
	
	 	inner join Offerta OA
	 	on OA.IdOfferta = AB.IdOffertaAcquisto
	
		cross join
		(
			select -1 K
		) OPSF
		where
		1=1
		and (SM.StatoSessione <> 'FALLITA')
	
		group by OA.CodiceOperatore, T.DataDelivery, OPSF.K
	) W
	group by W.CodiceOperatore, W.DataDelivery



-- select * from SaldoFisico


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[Gest_RiallineaSaldoFisico]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Log_ContrattiAbbinatiPerDataDelivery    Script Date: 20/10/2005 16.32.06 ******/


CREATE    PROC Log_ContrattiAbbinatiPerDataDelivery
	@CodiceOperatore varchar(8),
	@DataInizioAbbinamento datetime,
	@DataFineAbbinamento datetime
AS

--
print 'CodiceOperatore = ' + @CodiceOperatore
print 'Data di Inizio Abbinamento = ' + convert(varchar(20),@DataInizioAbbinamento)
print 'Data di Fine Abbinamento = ' + convert(varchar(20),@DataFineAbbinamento)
print ''
--

select
O.CodiceOperatore as CodiceOperatore,							 -- CodiceOperatore
A.IdAbbinamento as ContractId,								 -- ContractId
A.TSAbbinamento as DayMatched,				 				 -- DayMatched
C.NomeContratto as Product,								 -- Product
C.OreFornituraFeriali + C.OreFornituraFestive as Hours,					 -- Hours
case O.TipoOfferta when 'A' then 'Buy' else 'Sell' end BuySell, 			 -- BuySell 
A.QtyAbbinata as Qty,									 -- Qty
A.PrezzoUnitario*(case O.TipoOfferta when 'A' then -1 else 1 end) as Price,		 -- Price
A.PrezzoUnitario*A.QtyAbbinata*(case O.TipoOfferta when 'A' then -1 else 1 end) as Total -- Total

from 
Abbinamento A

-- Prova Filtro x Sessione FALLITA
inner join SessioneMercato SM 
on SM.IdSessioneMercato = A.IdSessioneMercato
and (SM.StatoSessione <> 'FALLITA')

inner join Offerta O
on (O.IdOfferta = A.IdOffertaAcquisto) 
or (O.IdOfferta = A.IdOffertaVendita)

inner join Contratto C
on (A.IdContratto = C.IdContratto)

where
((O.CodiceOperatore = @CodiceOperatore) or (@CodiceOperatore is null))
and (	(year(A.TSAbbinamento) > year(@DataInizioAbbinamento))
	or (	year(A.TSAbbinamento) = year(@DataInizioAbbinamento)
		and month(A.TSAbbinamento) > month(@DataInizioAbbinamento)
	)
	or (	month(A.TSAbbinamento) = month(@DataInizioAbbinamento)
		and day(A.TSAbbinamento) > day(@DataInizioAbbinamento)
	)
)
and (	(year(A.TSAbbinamento) < year(@DataFineAbbinamento))
	or (	year(A.TSAbbinamento) = year(@DataFineAbbinamento)
		and month(A.TSAbbinamento) < month(@DataFineAbbinamento)
	)
	or (	month(A.TSAbbinamento) = month(@DataFineAbbinamento)
		and day(A.TSAbbinamento) < day(@DataFineAbbinamento)
	)
)

order by
A.TSAbbinamento asc,	-- ieri..oggi..domani
O.CodiceOperatore asc	-- 101..102..103


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Log_ContrattiAbbinatiPerDataTrading    Script Date: 20/10/2005 16.32.06 ******/



CREATE     PROC Log_ContrattiAbbinatiPerDataTrading
	@CodiceOperatore varchar(8),
	@DataInizioFornitura datetime,
	@DataFineFornitura datetime
AS

--
print 'CodiceOperatore = ' + @CodiceOperatore
print 'Inizio periodo di fornitura = ' + convert(varchar(20),@DataInizioFornitura)
print 'Fine periodo di fornitura = ' + convert(varchar(20),@DataFineFornitura)
print ''
--

select
O.CodiceOperatore as CodiceOperatore,							 -- CodiceOperatore
A.IdAbbinamento as ContractId,								 -- ContractId
A.TSAbbinamento as DayMatched,				 				 -- DayMatched
C.NomeContratto as Product,								 -- Product
C.OreFornituraFeriali + C.OreFornituraFestive as Hours,					 -- Hours
case O.TipoOfferta when 'A' then 'Buy' else 'Sell' end BuySell, 			 -- BuySell 
A.QtyAbbinata as Qty,									 -- Qty
A.PrezzoUnitario*(case O.TipoOfferta when 'A' then -1 else 1 end) as Price,		 -- Price
A.PrezzoUnitario*A.QtyAbbinata*(case O.TipoOfferta when 'A' then -1 else 1 end) as Total -- Total

from 
Abbinamento A

-- Prova Filtro x Sessione FALLITA
inner join SessioneMercato SM 
on SM.IdSessioneMercato = A.IdSessioneMercato
and (SM.StatoSessione <> 'FALLITA')

inner join Offerta O
on (O.IdOfferta = A.IdOffertaAcquisto) 
or (O.IdOfferta = A.IdOffertaVendita)

inner join Contratto C
on (A.IdContratto = C.IdContratto)

where
((O.CodiceOperatore = @CodiceOperatore) or (@CodiceOperatore is null))
and (@DataFineFornitura >= C.DataInizioDelivery)
and (@DataInizioFornitura <= C.DataFineDelivery)

order by
A.TSAbbinamento asc,	-- ieri..oggi..domani
O.CodiceOperatore asc	-- 101..102..103




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.SessioneNuova_Predisposta    Script Date: 20/10/2005 16.32.06 ******/

CREATE  PROCEDURE SessioneNuova_Predisposta
	@IdSessioneMercato int,
	@rc int out,
	@MsgErrore varchar(80) out
AS

if exists (select * from SessioneMercato where StatoSessione in ('PREDISPOSTA', 'APERTA', 'SOSPESA', 'TERMINATA' ))
begin
	set @rc = 0
	set @MsgErrore = 'Non e` possibile predisporre la sessione perche` esiste gia` la sessione corrente'
	return
end


declare @VecchioStato varchar(16)
declare @DataMercato datetime

select 
@VecchioStato = StatoSessione,
@DataMercato = DataMercato
from
dbo.SessioneMercato
where
IdSessioneMercato = @IdSessioneMercato

if @VecchioStato is null or @VecchioStato <> 'NUOVA'
begin
	set @rc = 0
	set @MsgErrore = 'Non e` possibile predisporre la sessione passata non e` in stato NUOVA'
	return
end


update 
dbo.SessioneMercato
set
StatoSessione = 'PREDISPOSTA'
where
IdSessioneMercato = @IdSessioneMercato


EXEC SessioneMercato_StoricizzaProfiloOrario @IdSessioneMercato


-- Inizio Associazioni dei contratti con la sessione predisposta
-- Ovvero: ogni contratto gia' esistente in cui la finestra temporale
-- di trading 'contiene' la DataMercato viene associato alla sessione
-- appena creata (utilizzando la tabella SessioneMercatoContratto)

delete from SessioneMercatoContratto
where IdSessioneMercato = @IdSessioneMercato

insert into SessioneMercatoContratto (
	IdSessioneMercato,
	IdContratto)

	select
	@IdSessioneMercato IdSessioneMercato, 
	C.IdContratto
	from 
	Contratto C
	where
	(C.DataInizioTrading <= @DataMercato) and (@DataMercato <= C.DataFineTrading)

-- Fine Associazioni dei contratti con la nuova sessione

set @rc = 1
set @MsgErrore = ''

return 0

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SessioneNuova_Predisposta]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

/****** Object:  Stored Procedure dbo.TransazioneOut_Insert    Script Date: 20/10/2005 16.32.06 ******/
CREATE PROCEDURE [dbo].TransazioneOut_Insert
	@IdMessaggioOut int,
	@ProgressivoTransazioneOut int,
	@CodiceTransazioneOut tipoCodiceTransazione,
	@TipoTransazione tipoTipoTransazione,
	@IdMessagionIn int,
	@ProgressivoTransazioneIn int,
	@StatoTransazione tipoStatoTransazione,
	@BlobTransazione image
AS

INSERT INTO [dbo].[TransazioneOut] 
(
	[IdMessaggioOut],
	[ProgressivoTransazioneOut],
	[CodiceTransazioneOut],
	[TipoTransazione],
	[IdMessagionIn],
	[ProgressivoTransazioneIn],
	[StatoTransazione],
	[BlobTransazione]
) VALUES (
	@IdMessaggioOut,
	@ProgressivoTransazioneOut,
	@CodiceTransazioneOut,
	@TipoTransazione,
	@IdMessagionIn,
	@ProgressivoTransazioneIn,
	@StatoTransazione,
	@BlobTransazione
)

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[TransazioneOut_Insert]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Offerta_Modifica    Script Date: 20/10/2005 16.32.06 ******/



CREATE     procedure dbo.Offerta_Modifica
	@IdOfferta int,
	@QtyRichiesta int,
	@PrezzoUnitario float,
	@NoteOfferta nvarchar(80),
	@ErroreCode varchar(5) output,			-- Valorizzato solo in caso di errore
	@ErroreDescription varchar(256) output,		-- Valorizzato solo in caso di errore
	@StatoAbbinamento varchar(2) output,		-- Valorizzato sono se nessun errore
	@DataElaborazione datetime output,
	@NomeContratto tipoNomeContratto output		--
as

--
-- begin  -- Procedura
--

--
declare @IdActivity int
declare @DailyMsg nvarchar(1024)
--

-- Aggiorna DataElaborazione
set @DataElaborazione = getdate()
--

--
declare @IdContratto int	
--

-- Recupero NomeContratto (da restituire insieme alla data elaborazione)
select
@NomeContratto = C.NomeContratto,
@IdContratto   = C.IdContratto		--
from 
Offerta O
inner join Contratto C
on O.IdContratto = C.IdContratto
where
O.IdOfferta = @IdOfferta

if @@RowCount = 0
begin
	set @ErroreCode = '20'
	set @ErroreDescription = 'Offerta_Modifica: Nome Contratto non trovato.'

	-- ??? 	Mancano diverse informazioni.
	-- 	Propongo un DailyActivityLog.. piu' essenziale.
	--	Il problema maggiore e' che manca anche l'operatore.
	--	Forse trattasi di errore di sistema?

	return
end
--

-- INIZIO VALIDAZIONE

-- L'offerta deve esistere, deve essere nello stato "attivo" o "nascosto",
-- deve essere compatibile, deve essere nel book.
-- L'operatore deve essere abilitato.

declare @OldPrezzoUnitario float(8)
declare @OldQtyResidua int
declare @OLdIdSessioneMercato int
declare @OldOffertaAMercato char(1)
declare @OldTSAbbinamento datetime
declare @OldStatoOfferta char(2)
declare @OldTipoOfferta char(1)
declare @OldCompatibile char(1)

declare @OldCodiceOperatore varchar(8)

select 	
@OldIdSessioneMercato = 	Offerta.IdSessioneMercato,	
@OldPrezzoUnitario = 		Offerta.PrezzoUnitario,
@OldQtyResidua = 		Offerta.QtyResidua,
@OldOffertaAMercato = 		Offerta.OffertaAMercato,
@OldTSAbbinamento = 		Offerta.TSAbbinamento,
@OldStatoOfferta = 		Offerta.StatoOfferta,
@OldTipoOfferta = 		Offerta.TipoOfferta,
@OldCompatibile = 		Offerta.Compatibile,
@OldCodiceOperatore =		Offerta.CodiceOperatore
from 	
Offerta
inner join Operatore OP					-- Verifica Operatore Abilitato
on  OP.CodiceOperatore = Offerta.CodiceOperatore	-- Verifica Operatore Abilitato
where  	
1=1
and Offerta.IdOfferta = @IdOfferta
and ((Offerta.StatoOfferta = 'VA') or (Offerta.StatoOfferta = 'NA'))	--
and Offerta.Compatibile = 'S'						--
and Offerta.QtyResidua > 0						--
and OP.AbilitazioneMercato = 'S'				-- Verifica Operatore Abilitato

if @@RowCount = 0
begin
	set @ErroreCode = '11'
	set @ErroreDescription = 'Offerta_Modifica:Offerta inesistente o non modificabile'

	-- ??? 	Mancano diverse informazioni.
	-- 	Propongo un DailyActivityLog.. piu' essenziale.
	--	Il problema maggiore e' che manca anche l'operatore.
	--	Forse trattasi di errore di sistema?

	return
end
--

--
declare @BuyOrSellIt nvarchar(20)
declare @BuyOrSellEn nvarchar(20)

if (@OldTipoOfferta = 'V')
begin
	set @BuyOrSellIt = 'vendita'
	set @BuyOrSellEn = 'sell'
end
else
begin
	set @BuyOrSellIt = 'acquisto'
	set @BuyOrSellEn = 'buy'
end
--

-- La Sessione deve essere aperta
if NOT EXISTS(
	select 	
	StatoSessione 
	from 	
	SessioneMercato SM
	where  	
	1=1 
	and SM.IdSessioneMercato = @OldIdSessioneMercato
	and SM.StatoSessione = 'APERTA') 
begin
	set @ErroreCode = '4'
	set @ErroreDescription = 'Offerta_Modifica:Sessione non aperta'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Modifica offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - La sessione non e'' aperta.</it>'

		+ '<en>Modify ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @NomeContratto
		+ ' at <Price/>'
		+ ' : Refused - Session is not open.</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@OldIdSessioneMercato, 
		'OFF_MODIFICA', 
		@DailyMsg, 
		null, 		-- Default
		@IdOfferta, 
		Null, 		-- Non e' un abbinamento
		@OldCodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- PrezzoUnitario deve essere in ogni caso >= 0
if (@PrezzoUnitario < 0)
begin
	set @ErroreCode = '14'
	set @ErroreDescription = 'Offerta_Modifica: Prezzo unitario < 0'
	
	set @DailyMsg = 
		'<msg>'
		+ '<it>Modifica offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - Prezzo minore di zero.</it>'

		+ '<en>Modify ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @NomeContratto
		+ ' at <Price/>'
		+ ' : Refused - Price is less then zero.</en>'
		+ '</msg>'

	EXEC [dbo].[DailyActivityLog_Insert] 
		@OldIdSessioneMercato, 
		'OFF_MODIFICA', 
		@DailyMsg, 
		null, 		-- Default
		@IdOfferta, 
		Null, 		-- Non e' un abbinamento
		@OldCodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- QtyResidua deve essere in ogni caso >= 0
if (@QtyRichiesta < 0)
begin
	set @ErroreCode = '15'
	set @ErroreDescription = 'Offerta_Modifica: Qty richiesta < 0'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Modifica offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - La quantita'' richiesta deve essere maggiore di zero.</it>'

		+ '<en>Modify ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @NomeContratto
		+ ' at <Price/>'
		+ ' : Refused - Qty is less or equal then zero.</en>'
		+ '</msg>'

	EXEC [dbo].[DailyActivityLog_Insert] 
		@OldIdSessioneMercato, 
		'OFF_MODIFICA', 
		@DailyMsg, 
		null, 		-- Default
		@IdOfferta, 
		Null, 		-- Non e' un abbinamento
		@OldCodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- L'offerta "nata" a mercato deve rimanere tale
if (@PrezzoUnitario=0) and (@OldOffertaAMercato <> 'S')
begin 
	set @ErroreCode = '13'
	set @ErroreDescription = 'Offerta_Modifica:l''offerta deve rimanere a mercato'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Modifica offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - L''offerta deve rimanere a mercato.</it>'

		+ '<en>Modify ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @NomeContratto
		+ ' at <Price/>'
		+ ' : Refused - Must be a market offer.</en>'
		+ '</msg>'

	EXEC [dbo].[DailyActivityLog_Insert] 
		@OldIdSessioneMercato, 
		'OFF_MODIFICA', 
		@DailyMsg, 
		null, 		-- Default
		@IdOfferta, 
		Null, 		-- Non e' un abbinamento
		@OldCodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- L'offerta "nata" non a mercato deve rimanere tale
if (@PrezzoUnitario>0) and (@OldOffertaAMercato <> 'N')
begin 
	set @ErroreCode = '12'
	set @ErroreDescription = 'Offerta_Modifica:l''offerta non puo'' diventare a mercato'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Modifica offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - L''offerta non puo'' diventare a mercato.</it>'

		+ '<en>Modify ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @NomeContratto
		+ ' at <Price/>'
		+ ' : Refused - Must be a price limit offer.</en>'
		+ '</msg>'

	EXEC [dbo].[DailyActivityLog_Insert] 
		@OldIdSessioneMercato, 
		'OFF_MODIFICA', 
		@DailyMsg, 
		null, 		-- Default
		@IdOfferta, 
		Null, 		-- Non e' un abbinamento
		@OldCodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- FINE VALIDAZIONE

-- INIZIO UPDATE

-- Eventuale perdita della priorita' temporale
declare @TSAbbinamentoMemo datetime
begin
	-- Quantita' aumentata oppure prezzo modificato
	if ((@QtyRichiesta>@OldQtyResidua) or (@PrezzoUnitario<>@OldPrezzoUnitario))
	begin
		set @TSAbbinamentoMemo = getdate()
	end
	else
	begin
		set @TSAbbinamentoMemo = @OldTSAbbinamento
	end
end

-- Memo nuovi valori di prezzo, quantita' e note
declare @PrezzoUnitarioMemo float(8)
set @PrezzoUnitarioMemo = @PrezzoUnitario

declare @QtyResiduaMemo int
set @QtyResiduaMemo = @QtyRichiesta
declare @NoteOffertaMemo nvarchar(80)
set @NoteOffertaMemo = @NoteOfferta

update 
Offerta
set
PrezzoUnitario=@PrezzoUnitarioMemo, 
QtyResidua=@QtyResiduaMemo, 
TSAbbinamento=@TSAbbinamentoMemo, 
NoteOfferta=@NoteOffertaMemo
where
IdOfferta = @IdOfferta

-- FINE UPDATE

--
set @DailyMsg = 
	'<msg>'
	+ '<it>Modifica offerta di ' + @BuyOrSellIt + ' da ' 
	+ '<op>' + @OldCodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' a <Price/>'
	+ ' : Accettata.</it>'

	+ '<en>Modify ' + @BuyOrSellEn + ' offer from '
	+ '<op>' + @OldCodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' ' + @NomeContratto
	+ ' at <Price/>'
	+ ' : Accepted.</en>'
	+ '</msg>'

EXEC [dbo].[DailyActivityLog_Insert] 
	@OldIdSessioneMercato, 
	'OFF_MODIFICA', 
	@DailyMsg, 
	@TSAbbinamentoMemo, 
	@IdOfferta, 
	Null, -- Non e' un abbinamento
	Null, -- Interessa a tutti gli operatori
	@QtyRichiesta,
	@PrezzoUnitario,
	@IdActivity OUTPUT 
--

-- INIZIO RICALCOLA ABBINAMENTI

-- L'abbinamento deve essere ricalcolato solo se l'offerta si trova nello stato di "valida"
-- e non di "sospesa" o "revocata"

if (@OldStatoOfferta = 'VA')
begin
	if (@OldTipoOfferta = 'V')
		exec AbbinamentoOffertaVendita @IdOfferta, @StatoAbbinamento output	-- Offerta di vendita
	else
		exec AbbinamentoOffertaAcquisto @IdOfferta, @StatoAbbinamento output	-- Offerta di acquisto
end
else
begin
	-- Rimane il vecchio stato di compatibilita' con abbinamento 'N' (non effettuato)
	declare @memComp char(1)
	if (@OldCompatibile = 'S')
		set @memComp = 'C'
	else
		set @memComp = 'N'
		
	set @StatoAbbinamento = 'N' + @memComp
	-- 
end

-- FINE RICALCOLA ABBINAMENTI

-- Aggiorna la migliore offerta di acquisto e la migliore offerta di vendita
-- nella tabella SessioneMercatoContratto
exec AggiornaBookRiassuntivoAskBid @OldIdSessioneMercato, @IdContratto
--

--
-- end	-- Procedura
--




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[Offerta_Modifica]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Offerta_Nascondi    Script Date: 20/10/2005 16.32.06 ******/




CREATE        procedure dbo.Offerta_Nascondi
	@IdOfferta int,
	@NoteOfferta nvarchar(80),
	@ErroreCode varchar(5) output,			-- Valorizzato solo in caso di errore
	@ErroreDescription varchar(256) output,		-- Valorizzato solo in caso di errore
	@DataElaborazione datetime output,
	@NomeContratto tipoNomeContratto output		--
as

--
-- begin  -- Procedura
--

--
declare @IdActivity int
declare @DailyMsg nvarchar(1024)
--

-- Aggiorna DataElaborazione
set @DataElaborazione = getdate()
--

--
declare @IdContratto int	
declare @TipoOfferta char(1)
declare @QtyRichiesta int
declare @PrezzoUnitario float
--

-- Recupero NomeContratto (da restituire insieme alla data elaborazione)
select
@NomeContratto=	C.NomeContratto,
@IdContratto =	C.IdContratto,		--
@TipoOfferta =	O.TipoOfferta,
@QtyRichiesta =	O.QtyRichiesta,
@PrezzoUnitario = O.PrezzoUnitario

from 
Offerta O
inner join Contratto C
on O.IdContratto = C.IdContratto
where
O.IdOfferta = @IdOfferta

if @@RowCount = 0
begin
	set @ErroreCode = '21'
	set @ErroreDescription = 'Offerta_Nascondi: Nome Contratto non trovato.'

	-- ??? 	Mancano diverse informazioni.
	-- 	Propongo un DailyActivityLog.. piu' essenziale.
	--	Il problema maggiore e' che manca anche l'operatore.
	--	Forse trattasi di errore di sistema?

	return
end
--

-- INIZIO VALIDAZIONE

-- L'offerta deve esistere, deve essere nello stato "attivo",
-- deve essere compatibile, deve essere nel book.
-- L'operatore deve essere abilitato.

declare @OLdIdSessioneMercato int
declare @OldCodiceOperatore varchar(8)

select 	
@OldIdSessioneMercato =	Offerta.IdSessioneMercato,
@OldCodiceOperatore =	Offerta.CodiceOperatore
from 	
Offerta
inner join Operatore OP					-- Verifica Operatore Abilitato
on  OP.CodiceOperatore = Offerta.CodiceOperatore	-- Verifica Operatore Abilitato
where  	
1=1
and Offerta.IdOfferta = @IdOfferta
and (Offerta.StatoOfferta = 'VA')				--
and Offerta.Compatibile = 'S'					--
and Offerta.QtyResidua > 0					--
and OP.AbilitazioneMercato = 'S'				-- Verifica Operatore Abilitato

if @@RowCount = 0
begin
	set @ErroreCode = '18'
	set @ErroreDescription = 'Offerta_Nascondi:Offerta inesistente o non revocabile'

	-- ??? 	Mancano diverse informazioni.
	-- 	Propongo un DailyActivityLog.. piu' essenziale.
	--	Il problema maggiore e' che manca anche l'operatore.
	--	Forse trattasi di errore di sistema?

	return
end
--

--
declare @BuyOrSellIt nvarchar(20)
declare @BuyOrSellEn nvarchar(20)

if (@TipoOfferta = 'V')
begin
	set @BuyOrSellIt = 'vendita'
	set @BuyOrSellEn = 'sell'
end
else
begin
	set @BuyOrSellIt = 'acquisto'
	set @BuyOrSellEn = 'buy'
end
--


-- La Sessione deve essere aperta
if NOT EXISTS(
	select 	
	StatoSessione 
	from 	
	SessioneMercato SM
	where  	
	1=1 
	and SM.IdSessioneMercato = @OldIdSessioneMercato
	and SM.StatoSessione = 'APERTA') 
begin
	set @ErroreCode = '19'
	set @ErroreDescription = 'Offerta_Nascondi:Sessione non aperta'

	set @DailyMsg = 
		'<msg>'
		+ '<it></it>'
		+ '<en>Hide ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @NomeContratto
		+ ' at <Price/>'
		+ ' : Refused - Session is not open.</en></msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@OldIdSessioneMercato, 
		'OFF_NASCONDI', 
		@DailyMsg, 
		null, 
		@IdOfferta, 
		Null, 
		@OldCodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- FINE VALIDAZIONE

-- INIZIO UPDATE

update 
Offerta
set
StatoOfferta='NA',
NoteOfferta=@NoteOfferta
where
IdOfferta = @IdOfferta

-- FINE UPDATE

--
set @DailyMsg = 
	'<msg>'
	+ '<it>Nascondi offerta di ' + @BuyOrSellIt + ' da ' 
	+ '<op>' + @OldCodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' a <Price/>'
	+ ' : Accettata.</it>'

	+ '<en>Hide ' + @BuyOrSellEn + ' offer from '
	+ '<op>' + @OldCodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' ' + @NomeContratto
	+ ' at <Price/>'
	+ ' : Accepted.</en>'
	+ '</msg>'

EXEC [dbo].[DailyActivityLog_Insert] 
	@OldIdSessioneMercato, 
	'OFF_NASCONDI', 
	@DailyMsg, 
	null,		-- Default 
	@IdOfferta, 
	Null, 		-- Non e' un abbinamento
	Null, 		-- Interessa a tutti gli operatori
	@QtyRichiesta,
	@PrezzoUnitario,
	@IdActivity OUTPUT 
--

-- Aggiorna la migliore offerta di acquisto e la migliore offerta di vendita
-- nella tabella SessioneMercatoContratto
exec AggiornaBookRiassuntivoAskBid @OldIdSessioneMercato, @IdContratto
--

--
-- end	-- Procedura
--




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[Offerta_Nascondi]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Offerta_Nuova    Script Date: 20/10/2005 16.32.06 ******/



CREATE     procedure dbo.Offerta_Nuova
	@Contratto tipoNomeContratto,
	@TipoOfferta char(1),				-- V/A
	@QtyRichiesta int,
	@PrezzoUnitario float,
	@NoteOfferta nvarchar(80),
	@OperatoreOTC varchar(8),	-- tipoCodiceOperatore
	@CodiceOTC varchar(32),
	@CodiceOperatore varchar(8),    -- tipoCodiceOperatore
	@CodiceUtente varchar(8),       -- tipoCodiceUtente
	@ErroreCode varchar(5) output,			-- Valorizzato solo in caso di errore
	@ErroreDescription varchar(256) output,		-- Valorizzato solo in caso di errore
	@StatoAbbinamento varchar(2) output,		-- Valorizzato sono se nessun errore
	@IdNuovaOfferta int output,
	@DataElaborazione datetime output
as

declare @IdActivity int
declare @DailyMsg nvarchar(1024)

declare @BuyOrSellIt nvarchar(20)
declare @BuyOrSellEn nvarchar(20)

if (@TipoOfferta = 'V')
begin
	set @BuyOrSellIt = 'vendita'
	set @BuyOrSellEn = 'sell'
end
else
begin
	set @BuyOrSellIt = 'acquisto'
	set @BuyOrSellEn = 'buy'
end


--
-- begin  -- Procedura
--

-- Aggiorna DataElaborazione
set @DataElaborazione = getdate()
--

--
declare @IdSessioneMercato int
declare @IdContratto int
--

--
select
@IdSessioneMercato = IdSessioneMercato
from 	
SessioneMercato SM
where  	
1=1 
and SM.StatoSessione = 'APERTA'
--

-- INIZIO VALIDAZIONE

-- La Sessione deve essere aperta
if @@rowcount <> 1
begin
	set @ErroreCode = '4'
	set @ErroreDescription = 'Offerta_Nuova:Sessione non aperta'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - La sessione non e'' aperta.</it>'

		+ '<en>New ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Refused - Session is not open.</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@IdSessioneMercato, 
		'OFF_NUOVA', 
		@DailyMsg, 
		null, -- Default
		@IdNuovaOfferta, 
		Null, -- Non e' un abbinamento
		@CodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT

	return
end

select
@IdContratto = IdContratto
from Contratto
where
NomeContratto = @Contratto

if @@rowcount <> 1
begin
	set @ErroreCode = '-4'
	set @ErroreDescription = 'Offerta_Nuova:Contratto non trovato'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - Contratto inesistente.</it>'

		+ '<en>New ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @Contratto
		+ ' at <Price/>' 
		+ ' : Refused - Contract not found.</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@IdSessioneMercato, 
		'OFF_NUOVA', 
		@DailyMsg, 
		null, 		-- Default
		@IdNuovaOfferta, 
		Null, 		-- Non e' un abbinamento
		@CodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,	
		@IdActivity OUTPUT 

	return
end




-- L'operatore non deve essere sospeso dal mercato
if NOT EXISTS(
	select
	AbilitazioneMercato
	from 
	Operatore OP
	where  	
	1=1 
	and OP.CodiceOperatore = @CodiceOperatore
	and OP.AbilitazioneMercato = 'S') 
begin
	set @ErroreCode = '1'
	set @ErroreDescription = 'Offerta_Nuova:Operatore non abilitato al mercato'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - Operatore non abilitato al trading.</it>'

		+ '<en>New ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @Contratto
		+ ' at <Price/>' 
		+ ' : Refused - Operator is not enable for trading.</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@IdSessioneMercato, 
		'OFF_NUOVA', 
		@DailyMsg, 
		null, 			-- Default
		@IdNuovaOfferta, 
		Null, 			-- Non e' un abbinamento
		@CodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,	
		@IdActivity OUTPUT 

	return
end

-- Prezzo maggiore (con limite di prezzo) o uguale (a mercato) a zero
if (@PrezzoUnitario<0)
begin
	set @ErroreCode = '2'
	set @ErroreDescription = 'Offerta_Nuova:Prezzo unitario < 0'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - Il prezzo e'' minore di zero.</it>'

		+ '<en>New ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @Contratto
		+ ' at <Price/>'
		+ ' : Refused - Price is less then zero.</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@IdSessioneMercato, 
		'OFF_NUOVA', 
		@DailyMsg, 
		null, 			-- Default
		@IdNuovaOfferta, 
		Null, 			-- Non e' un abbinamento
		@CodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- Quantita' richiesta maggiore di zero
if (@QtyRichiesta<=0)
begin
	set @ErroreCode = '5'
	set @ErroreDescription = 'Offerta_Nuova:Quantita richiesta <= 0'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - La quantita'' deve essere maggiore di zero.</it>'

		+ '<en>New ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @CodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @Contratto
		+ ' at <Price/>'
		+ ' : Refused - Qty is less or equal then zero.</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@IdSessioneMercato, 
		'OFF_NUOVA', 
		@DailyMsg, 
		null, 			-- Default
		@IdNuovaOfferta, 
		Null, 			-- Non e' un abbinamento
		@CodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- Se non a mercato (prezzo maggiore di zero) non deve eccedere in piu'
-- o in meno del x% del prezzo di riferimento della sessione del giorno precedente.
if (@PrezzoUnitario>0)
begin
	-- Legge OffertePercPrezzoRiferimento (x%)
	declare @OffertePercPrezzoRiferimento float
	select 
	@OffertePercPrezzoRiferimento = ValoreFloat
	from 
	Parametri 
	where 
	Codice = 'OffertePercPrezzoRif'	

	-- Il prezzo di riferimento viene preso dalla tabella SessioneMercatoContratto
	-- altre SP inseriranno questo campo nella suddetta tabella
	declare @PrezzoRif float
	select 
	@PrezzoRif = RefPrice
	from
	SessioneMercatoContratto
	where
	1=1 
	and IdSessioneMercato = @IdSessioneMercato
	and IdContratto = @IdContratto

	-- Verifico la presenza del prezzo di riferimento
	if (@PrezzoRif = 0)
	begin
		set @ErroreCode = '9'
		set @ErroreDescription = 'Offerta_Nuova:Prezzo di riferimento non trovato'

		-- non e` un errore applicativo ? --> forse bisogna fare raise error
		set @DailyMsg = 
			'<msg>'
			+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' at <Price/>'
			+ ' : Rifiutata - Prezzo di riferimento non trovato.</it>'

			+ '<en>New ' + @BuyOrSellEn + ' offer from '
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' ' + @Contratto
			+ ' at <Price/>'
			+ ' : Refused - Ref price not found.</en>'
			+ '</msg>'
		
		EXEC [dbo].[DailyActivityLog_Insert] 
			@IdSessioneMercato, 
			'OFF_NUOVA', 
			@DailyMsg, 
			null, 			-- Default
			@IdNuovaOfferta, 
			Null, 			-- Non e'' un abbinamento
			@CodiceOperatore,
			@QtyRichiesta,
			@PrezzoUnitario,
			@IdActivity OUTPUT 


		return
	end

	-- Calcola soglia minima e soglia massima del limite di prezzo
	declare @PrezzoMinimo float
	set @PrezzoMinimo = @PrezzoRif - ((@PrezzoRif*@OffertePercPrezzoRiferimento)/100)
	declare @PrezzoMassimo float
	set @PrezzoMassimo = @PrezzoRif + ((@PrezzoRif*@OffertePercPrezzoRiferimento)/100)

	-- Verifica che il limite di prezzo non sia fuori range
	if (@PrezzoUnitario>@PrezzoMassimo) or (@PrezzoUnitario<@PrezzoMinimo)
	begin
		set @ErroreCode = '3'
		set @ErroreDescription = 'Offerta_Nuova:Prezzo unitario fuori range'

		set @DailyMsg = 
			'<msg>'
			+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' at <Price/>'
			+ ' : Rifiutata - Prezzo unitario fuori range.</it>'

			+ '<en>New ' + @BuyOrSellEn + ' offer from '
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' ' + @Contratto
			+ ' at <Price/>'
			+ ' : Refused - Price is out of range.</en>'
			+ '</msg>'
		
		EXEC [dbo].[DailyActivityLog_Insert] 
			@IdSessioneMercato, 
			'OFF_NUOVA', 
			@DailyMsg, 
			null, 			-- Default
			@IdNuovaOfferta, 
			Null, 			-- Non e' un abbinamento
			@CodiceOperatore,
			@QtyRichiesta,
			@PrezzoUnitario,
			@IdActivity OUTPUT 


		return
	end
end

-- Se offerta OTC
-- Non deve esistere una offerta OTC con lo stesso codiceOTC dello stesso operatore 
-- per la sessione corrente.
-- Il prezzo unitario non puo' essere zero (per OTC le offerte a mercato non hanno senso)
if ((LEN(@OperatoreOTC) > 0) OR (LEN(@CodiceOTC) > 0))
begin


	if ((LEN(@OperatoreOTC) = 0) OR (LEN(@CodiceOTC) = 0))
	begin
		set @ErroreCode = '6'
		set @ErroreDescription = 'Offerta_Nuova:OffertaOTC incongruente'

		set @DailyMsg = 
			'<msg>'
			+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' at <Price/>'
			+ ' : Rifiutata - OTC senza controparte e codice.</it>'

			+ '<en>New ' + @BuyOrSellEn + ' offer from '
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' ' + @Contratto
			+ ' at <Price/>'
			+ ' : Refused - OTC offer without code or counterpart operator.</en>'
			+ '</msg>'
		
		EXEC [dbo].[DailyActivityLog_Insert] 
			@IdSessioneMercato, 
			'OFF_NUOVA', 
			@DailyMsg, 
			null, 			-- Default
			@IdNuovaOfferta, 
			Null, 			-- Non e' un abbinamento
			@CodiceOperatore,
			@QtyRichiesta,
			@PrezzoUnitario,
			@IdActivity OUTPUT 

		return
	end

	-- Eventuale presenza dello stesso codice OTC
	if EXISTS(
		select 
		CodiceOTC 
		from 
		Offerta
		where  	    
		1=1 
		and CodiceOperatore = @CodiceOperatore
	  	and CodiceOTC = @CodiceOTC
		and OperatoreOTC = @OperatoreOTC		
		and IdSessioneMercato=@IdSessioneMercato
		and StatoOfferta <> 'RM'			-- Offerta non cancellata

		and Compatibile = 'S'			
		and QtyResidua > 0				
		and IdContratto = @IdContratto)
	begin
		set @ErroreCode = '7'
		set @ErroreDescription = 'Offerta_Nuova:Offerta OTC gia presente'


		set @DailyMsg = 
			'<msg>'
			+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' at <Price/>'
			+ ' : Rifiutata - Offerta OTC gia'' presente.</it>'

			+ '<en>New ' + @BuyOrSellEn + ' offer from '
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' ' + @Contratto
			+ ' at <Price/>'
			+ ' : Refused - OTC offer already placed from counterpart.</en>'
			+ '</msg>'
		
		EXEC [dbo].[DailyActivityLog_Insert] 
			@IdSessioneMercato, 
			'OFF_NUOVA', 
			@DailyMsg, 
			null, 			-- Default
			@IdNuovaOfferta, 
			Null, 			-- Non e' un abbinamento
			@CodiceOperatore,
			@QtyRichiesta,
			@PrezzoUnitario,
			@IdActivity OUTPUT 

		return
	end

	-- Prezzo unitario uguale a zero
	if (@PrezzoUnitario=0)
	begin
		set @ErroreCode = '8'
		set @ErroreDescription = 'Offerta_Nuova:Offerta OTC con prezzo unitario = 0'


		set @DailyMsg = 
			'<msg>'
			+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' at <Price/>'
			+ ' : Rifiutata - Offerta OTC deve avere prezzo maggiore di zero.</it>'

			+ '<en>New ' + @BuyOrSellEn + ' offer from '
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' ' + @Contratto
			+ ' at <Price/>'
			+ ' : Refused - OTC must be a limit price offer.</en>'
			+ '</msg>'
		
		EXEC [dbo].[DailyActivityLog_Insert] 
			@IdSessioneMercato, 
			'OFF_NUOVA', 
			@DailyMsg, 
			null, 		-- Default
			@IdNuovaOfferta, 
			Null, 		-- Non e' un abbinamento
			@CodiceOperatore,
			@QtyRichiesta,
			@PrezzoUnitario,
			@IdActivity OUTPUT 

		return
	end

	-- Stabilisce il tipo offerta della controparte da ricercare (Vendita oppure Acquisto)
	Declare @ControparteTipoOfferta char(1)
	set @ControparteTipoOfferta =
		case @TipoOfferta 
			when 'V' then 'A' 
			when 'A' then 'V'
		end
	--
	
	-- Inizio Ricerca e test sull'eventuale offerta della controparte OTC
	Declare @ControparteIdOfferta int,
		@ControparteQtyResidua int,
		@ContropartePrezzoUnitario float
	
	select
	@ControparteIdOfferta=IdOfferta,
	@ControparteQtyResidua=QtyResidua,
	@ContropartePrezzoUnitario=PrezzoUnitario
	from
	Offerta CNTR
	inner join Operatore OP				-- Verifica Operatore Abilitato
	on  OP.CodiceOperatore = @OperatoreOTC		-- Verifica Operatore Abilitato
	where
	1=1
	and CNTR.TipoOfferta = @ControparteTipoOfferta	--
	and CNTR.StatoOfferta = 'VA'			--
	and CNTR.Compatibile = 'S'			--
	and CNTR.QtyResidua > 0				--
	and CNTR.IdSessioneMercato = @IdSessioneMercato	--
	and CNTR.IdContratto = @IdContratto		--
	and CNTR.OffertaAMercato <> 'S'			--
	and CNTR.PrezzoUnitario > 0			--
	and CNTR.CodiceOperatore = @OperatoreOTC	-- Controparte OTC dichiarata nell'off.
	and CNTR.CodiceOTC = @CodiceOTC			-- Stesso Codice OTC
	and OP.AbilitazioneMercato = 'S'		-- Verifica Operatore Abilitato

	if @@RowCount > 1
	begin
		if @@trancount > 0 rollback
		RaisError('Offerta_Nuova: trovate offerte di vendita multiple', 16, 1) with seterror
		return
	end

	-- Se esiste l'offerta corrispondente ma Qty e/o Prezzo diversi errore
	if (@ControparteIdOfferta is not null)
	   and ((@QtyRichiesta <> @ControparteQtyResidua) OR (@PrezzoUnitario <> @ContropartePrezzoUnitario))
	begin
		set @ErroreCode = '24'
		set @ErroreDescription = 'Offerta_Nuova: Offerta OTC con diverso prezzo e/o quantita''.'

		set @DailyMsg = 
			'<msg>'
			+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' at <Price/>'
			+ ' : Rifiutata - Offerte OTC con prezzi diversi.</it>'

			+ '<en>New ' + @BuyOrSellEn + ' offer from '
			+ '<op>' + @CodiceOperatore + '</op>'
			+ ' : <Qty/>'
			+ ' ' + @Contratto
			+ ' at <Price/>'
			+ ' : Refused - OTC offer mismatch.</en>'
			+ '</msg>'
		
		EXEC [dbo].[DailyActivityLog_Insert] 
			@IdSessioneMercato, 
			'OFF_NUOVA', 
			@DailyMsg, 
			null, 			-- Default
			@IdNuovaOfferta, 
			Null, 			-- Non e' un abbinamento
			@CodiceOperatore,
			@QtyRichiesta,
			@PrezzoUnitario,
			@IdActivity OUTPUT 


		return
	end
	
	-- Fine Ricerca e test sull'eventuale offerta della controparte OTC

end

-- FINE VALIDAZIONE


-- INIZIO INSERIMENTO

-- Calcola se offerta a mercato
declare @OffertaAMercato char(1)
if (@PrezzoUnitario>0)
	set @OffertaAMercato = 'N'
else
	set @OffertaAMercato = 'S'
--

-- Calcola TSCreazione e TSAbbinamento(iniziale)
declare @TSCreazione datetime
set @TSCreazione = getdate()
--

--
INSERT INTO Offerta(
	IdSessioneMercato,
	IdContratto,
	-- Identity IdOfferta,
	CodiceUtente,
	CodiceOperatore,
	TipoOfferta,
	TSCreazione,
	TSAbbinamento,
	OffertaAMercato,
	PrezzoUnitario,
	QtyRichiesta,
	QtyResidua,
	StatoOfferta,
	Compatibile,
	NoteOfferta,
	OperatoreOTC,
	CodiceOTC)
VALUES(
	@IdSessioneMercato, 	-- IdSessioneMercato
	@IdContratto, 		-- IdContratto
	-- Identity, 		-- IdOfferta
	@CodiceUtente, 		-- CodiceUtente
	@CodiceOperatore, 	-- CodiceOperatore
	@TipoOfferta, 		-- TipoOfferta		-- 'V' / 'A'
	@TSCreazione, 		-- TSCreazione		-- Inizialmente creazione e abbinamento hanno la stessa data
	@TSCreazione,		-- TSAbbinamento	-- Inizialmente creazione e abbinamento hanno la stessa data
	@OffertaAMercato, 	-- OffertaAMercato	-- 'S' / 'N'
	@PrezzoUnitario,	-- PrezzoUnitario	-- >= 0
	@QtyRichiesta, 		-- QtyRichiesta		-- Inizialmente QtyRichiesta e QtyResidua hanno lo stesso valore
	@QtyRichiesta, 		-- QtyResidua		-- Inizialmente QtyRichiesta e QtyResidua hanno lo stesso valore

	'VA', 			-- StatoOfferta		-- 'VA' / 'NA' / 'RM'
	'S', 			-- Compatibile		-- 'S' / 'N'
	@NoteOfferta, 		-- NoteOfferta
	@OperatoreOTC, 		-- OperatoreOTC
	@CodiceOTC) 		-- CodiceOTC
--

-- Memo id dell'offerta appena inserita
SET @IdNuovaOfferta = @@IDENTITY
--

-- FINE INSERIMENTO

set @DailyMsg = 
	'<msg>'
	+ '<it>Nuova offerta di ' + @BuyOrSellIt + ' da ' 
	+ '<op>' + @CodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' a <Price/>'
	+ ' : Accettata.</it>'

	+ '<en>New ' + @BuyOrSellEn + ' offer from '
	+ '<op>' + @CodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' ' + @Contratto
	+ ' at <Price/>'
	+ ' : Accepted.</en>'
	+ '</msg>'

EXEC [dbo].[DailyActivityLog_Insert] 
	@IdSessioneMercato, 
	'OFF_NUOVA', 
	@DailyMsg, 
	@TSCreazione, 
	@IdNuovaOfferta, 
	Null, -- Non e' un abbinamento
	Null, -- Interessa a tutti gli operatori
	@QtyRichiesta,
	@PrezzoUnitario,
	@IdActivity OUTPUT 

-- INIZIO RICALCOLA ABBINAMENTI
	
if (@TipoOfferta = 'V')
	exec AbbinamentoOffertaVendita @IdNuovaOfferta, @StatoAbbinamento output
else
	exec AbbinamentoOffertaAcquisto @IdNuovaOfferta, @StatoAbbinamento output

-- FINE RICALCOLA ABBINAMENTI


-- Aggiorna la migliore offerta di acquisto e la migliore offerta di vendita
-- nella tabella SessioneMercatoContratto
exec AggiornaBookRiassuntivoAskBid @IdSessioneMercato, @IdContratto
--

--
-- end	-- Procedura
--

--- Fine Create

---


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[Offerta_Nuova]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Offerta_Revoca    Script Date: 20/10/2005 16.32.06 ******/






CREATE        procedure dbo.Offerta_Revoca
	@IdOfferta int,
	@NoteOfferta nvarchar(80),
	@ErroreCode varchar(5) output,			-- Valorizzato solo in caso di errore
	@ErroreDescription varchar(256) output,		-- Valorizzato solo in caso di errore
	@DataElaborazione datetime output,
	@NomeContratto tipoNomeContratto output		--
as

--
-- begin  -- Procedura
--

--
declare @IdActivity int
declare @DailyMsg nvarchar(1024)
--

-- Aggiorna DataElaborazione
set @DataElaborazione = getdate()
--

--
declare @IdContratto int	
declare @TipoOfferta char(1)
declare @QtyRichiesta int
declare @PrezzoUnitario float
--

-- Recupero NomeContratto (da restituire insieme alla data elaborazione)
select
@NomeContratto = C.NomeContratto,
@IdContratto   = C.IdContratto,		--
@TipoOfferta =	O.TipoOfferta,
@QtyRichiesta =	O.QtyRichiesta,
@PrezzoUnitario = O.PrezzoUnitario

from 
Offerta O
inner join Contratto C
on O.IdContratto = C.IdContratto
where
O.IdOfferta = @IdOfferta

if @@RowCount = 0
begin
 	set @ErroreCode = '22'
 	set @ErroreDescription = 'Offerta_Revoca: Nome Contratto non trovato.'

	-- ??? 	Mancano diverse informazioni.
	-- 	Propongo un DailyActivityLog.. piu' essenziale.
	--	Il problema maggiore e' che manca anche l'operatore.
	--	Forse trattasi di errore di sistema?

	return
end
--

-- INIZIO VALIDAZIONE

-- L'offerta deve esistere, deve essere nello stato "attivo" o "nascosto",
-- deve essere compatibile, deve essere nel book.
-- L'operatore deve essere abilitato.

declare @OLdIdSessioneMercato int
declare @OldCodiceOperatore varchar(8)

select 	
@OldIdSessioneMercato = Offerta.IdSessioneMercato,
@OldCodiceOperatore = Offerta.CodiceOperatore
from 	
Offerta
inner join Operatore OP					-- Verifica Operatore Abilitato
on  OP.CodiceOperatore = Offerta.CodiceOperatore	-- Verifica Operatore Abilitato
where  	
1=1
and Offerta.IdOfferta = @IdOfferta
and ((Offerta.StatoOfferta = 'VA') or (Offerta.StatoOfferta = 'NA'))	--
and Offerta.Compatibile = 'S'						--
and Offerta.QtyResidua > 0						--
and OP.AbilitazioneMercato = 'S'				-- Verifica Operatore Abilitato

if @@RowCount = 0
begin
	set @ErroreCode = '16'
	set @ErroreDescription = 'Offerta_Revoca:Offerta inesistente o non revocabile'

	-- ??? 	Mancano diverse informazioni.
	-- 	Propongo un DailyActivityLog.. piu' essenziale.
	--	Il problema maggiore e' che manca anche l'operatore.
	--	Forse trattasi di errore di sistema?

	return
end
--

--
declare @BuyOrSellIt nvarchar(20)
declare @BuyOrSellEn nvarchar(20)

if (@TipoOfferta = 'V')
begin
	set @BuyOrSellIt = 'vendita'
	set @BuyOrSellEn = 'sell'
end
else
begin
	set @BuyOrSellIt = 'acquisto'
	set @BuyOrSellEn = 'buy'
end
--


-- La Sessione deve essere aperta
if NOT EXISTS(
	select 	
	StatoSessione 
	from 	
	SessioneMercato SM
	where  	
	1=1 
	and SM.IdSessioneMercato = @OldIdSessioneMercato
	and SM.StatoSessione = 'APERTA') 
begin
	set @ErroreCode = '17'
	set @ErroreDescription = 'Offerta_Revoca:Sessione non aperta'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Revoca offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - La sessione non e'' aperta.</it>'

		+ '<en>Revoke ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @NomeContratto
		+ ' at <Price/>'
		+ ' : Refused - Session is not open.</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@OldIdSessioneMercato, 
		'OFF_REVOCA', 
		@DailyMsg, 
		null, 		-- Default
		@IdOfferta, 
		Null, 		-- Non e' un abbinamento
		@OldCodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end

-- FINE VALIDAZIONE

-- INIZIO UPDATE

update 
Offerta
set
StatoOfferta='RM',
NoteOfferta=@NoteOfferta
where
IdOfferta = @IdOfferta

-- FINE UPDATE

--
set @DailyMsg = 
	'<msg>'
	+ '<it>Revoca offerta di ' + @BuyOrSellIt + ' da ' 
	+ '<op>' + @OldCodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' a <Price/>'
	+ ' : Accettata.</it>'

	+ '<en>Revoke ' + @BuyOrSellEn + ' offer from '
	+ '<op>' + @OldCodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' ' + @NomeContratto
	+ ' at <Price/>'
	+ ' : Accepted.</en>'
	+ '</msg>'

EXEC [dbo].[DailyActivityLog_Insert] 
	@OldIdSessioneMercato, 
	'OFF_REVOCA', 
	@DailyMsg, 
	null,			-- Default 
	@IdOfferta, 
	Null, 			-- Non e' un abbinamento
	Null, 			-- Interessa a tutti gli operatori
	@QtyRichiesta,
	@PrezzoUnitario,
	@IdActivity OUTPUT 
--

-- Aggiorna la migliore offerta di acquisto e la migliore offerta di vendita
-- nella tabella SessioneMercatoContratto
exec dbo.AggiornaBookRiassuntivoAskBid @OldIdSessioneMercato, @IdContratto
--

--
-- end	-- Procedura
--






GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[Offerta_Revoca]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Stored Procedure dbo.Offerta_Rivela    Script Date: 20/10/2005 16.32.06 ******/




CREATE      procedure dbo.Offerta_Rivela
	@IdOfferta int,
	@NoteOfferta nvarchar(80),
	@ErroreCode varchar(5) output,			-- Valorizzato solo in caso di errore
	@ErroreDescription varchar(256) output,		-- Valorizzato solo in caso di errore
	@StatoAbbinamento varchar(2) output,		-- Valorizzato sono se nessun errore
	@DataElaborazione datetime output,
	@NomeContratto tipoNomeContratto output		--
as

--
-- begin  -- Procedura
--

--
declare @IdActivity int
declare @DailyMsg nvarchar(1024)
--

-- Aggiorna DataElaborazione
set @DataElaborazione = getdate()
--

--
declare @IdContratto int	
declare @TipoOfferta char(1)
declare @QtyRichiesta int
declare @PrezzoUnitario float
--

-- Recupero NomeContratto (da restituire insieme alla data elaborazione)
select
@NomeContratto = C.NomeContratto,
@IdContratto   = C.IdContratto,		--
@TipoOfferta =	O.TipoOfferta,
@QtyRichiesta =	O.QtyRichiesta,
@PrezzoUnitario = O.PrezzoUnitario

from 
Offerta O
inner join Contratto C
on O.IdContratto = C.IdContratto
where
O.IdOfferta = @IdOfferta

if @@RowCount = 0
begin
	set @ErroreCode = '23'
	set @ErroreDescription = 'Offerta_Rivela: Nome Contratto non trovato.'

	-- ??? 	Mancano diverse informazioni.
	-- 	Propongo un DailyActivityLog.. piu' essenziale.
	--	Il problema maggiore e' che manca anche l'operatore.
	--	Forse trattasi di errore di sistema?

	return
end
--

-- INIZIO VALIDAZIONE

-- L'offerta deve esistere, deve essere nello stato "attivo",
-- deve essere compatibile, deve essere nel book.
-- L'operatore deve essere abilitato.

declare @OLdIdSessioneMercato int
declare @OldTipoOfferta char(1)
declare @OldCodiceOperatore varchar(8)

select 	
@OldIdSessioneMercato = Offerta.IdSessioneMercato,	
@OldTipoOfferta = Offerta.TipoOfferta,
@OldCodiceOperatore = Offerta.CodiceOperatore

from 	
Offerta
inner join Operatore OP					-- Verifica Operatore Abilitato
on  OP.CodiceOperatore = Offerta.CodiceOperatore	-- Verifica Operatore Abilitato
where  	
1=1
and Offerta.IdOfferta = @IdOfferta
and (Offerta.StatoOfferta = 'NA')				--
and Offerta.Compatibile = 'S'					--
and Offerta.QtyResidua > 0					--
and OP.AbilitazioneMercato = 'S'				-- Verifica Operatore Abilitato

if @@RowCount = 0
begin
	set @ErroreCode = '25'
	set @ErroreDescription = 'Offerta_Rivela:Offerta inesistente o non revocabile'

	-- ??? 	Mancano diverse informazioni.
	-- 	Propongo un DailyActivityLog.. piu' essenziale.
	--	Il problema maggiore e' che manca anche l'operatore.
	--	Forse trattasi di errore di sistema?

	return
end
--

--
declare @BuyOrSellIt nvarchar(20)
declare @BuyOrSellEn nvarchar(20)

if (@TipoOfferta = 'V')
begin
	set @BuyOrSellIt = 'vendita'
	set @BuyOrSellEn = 'sell'
end
else
begin
	set @BuyOrSellIt = 'acquisto'
	set @BuyOrSellEn = 'buy'
end
--

-- La Sessione deve essere aperta
if NOT EXISTS(
	select 	
	StatoSessione 
	from 	
	SessioneMercato SM
	where  	
	1=1 
	and SM.IdSessioneMercato = @OldIdSessioneMercato
	and SM.StatoSessione = 'APERTA') 
begin
	set @ErroreCode = '26'
	set @ErroreDescription = 'Offerta_Rivela:Sessione non aperta'

	set @DailyMsg = 
		'<msg>'
		+ '<it>Rivela offerta di ' + @BuyOrSellIt + ' da ' 
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' at <Price/>'
		+ ' : Rifiutata - La sessione non e'' aperta.</it>'

		+ '<en>Reveal ' + @BuyOrSellEn + ' offer from '
		+ '<op>' + @OldCodiceOperatore + '</op>'
		+ ' : <Qty/>'
		+ ' ' + @NomeContratto
		+ ' at <Price/>'
		+ ' : Refused - Session is not open.</en>'
		+ '</msg>'
	
	EXEC [dbo].[DailyActivityLog_Insert] 
		@OldIdSessioneMercato, 
		'OFF_RIVELA', 
		@DailyMsg, 
		null, 		-- Default
		@IdOfferta, 
		Null, 		-- Non e' un abbinamento
		@OldCodiceOperatore,
		@QtyRichiesta,
		@PrezzoUnitario,
		@IdActivity OUTPUT 

	return
end


-- FINE VALIDAZIONE

-- INIZIO UPDATE

update 
Offerta
set
StatoOfferta='VA',
TSAbbinamento=getdate(),
NoteOfferta=@NoteOfferta
where
IdOfferta = @IdOfferta

-- FINE UPDATE

--
set @DailyMsg = 
	'<msg>'
	+ '<it>Rivela offerta di ' + @BuyOrSellIt + ' da ' 
	+ '<op>' + @OldCodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' a <Price/>'
	+ ' : Accettata.</it>'

	+ '<en>Reveal ' + @BuyOrSellEn + ' offer from '
	+ '<op>' + @OldCodiceOperatore + '</op>'
	+ ' : <Qty/>'
	+ ' ' + @NomeContratto
	+ ' at <Price/>'
	+ ' : Accepted.</en>'
	+ '</msg>'

EXEC [dbo].[DailyActivityLog_Insert] 
	@OldIdSessioneMercato, 
	'OFF_RIVELA', 
	@DailyMsg, 
	null, 		-- Default
	@IdOfferta, 	
	Null, 		-- Non e' un abbinamento
	Null, 		-- Interessa a tutti gli operatori
	@QtyRichiesta,
	@PrezzoUnitario,
	@IdActivity OUTPUT 
--

-- INIZIO RICALCOLA ABBINAMENTI

if (@OldTipoOfferta = 'V')
	exec AbbinamentoOffertaVendita @IdOfferta, @StatoAbbinamento output	-- Offerta di vendita
else
	exec AbbinamentoOffertaAcquisto @IdOfferta, @StatoAbbinamento output	-- Offerta di acquisto

-- FINE RICALCOLA ABBINAMENTI

-- Aggiorna la migliore offerta di acquisto e la migliore offerta di vendita
-- nella tabella SessioneMercatoContratto
exec dbo.AggiornaBookRiassuntivoAskBid @OldIdSessioneMercato, @IdContratto
--

--
-- end	-- Procedura
--





GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[Offerta_Rivela]  TO [bipex_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Trigger dbo.tr_Contratto_Insert    Script Date: 20/10/2005 16.32.06 ******/
CREATE TRIGGER tr_Contratto_Insert ON [dbo].[Contratto] 
FOR INSERT
AS

exec AggiornaTabellaDataDelivery

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Trigger dbo.tr_Contratto_Update    Script Date: 20/10/2005 16.32.06 ******/

CREATE  TRIGGER tr_Contratto_Update ON [dbo].[Contratto] 
FOR UPDATE
AS

-- Accetta la modifica solo se contratto non ancora in Delivery
if exists(
	select 'True'
	from Inserted i
  	inner join SessioneMercatoContratto smc
  	on i.IdContratto = smc.IdContratto
)
begin
	-- Rifiuta la modifica
	raiserror ('Contratto gia'' in delivery.', 16, 1)
	rollback transaction
	return
end
--

-- Aggiorna tabella DataDelivery solo se serve
if exists (
	select 'True'
	from Inserted i
	inner join Deleted d
	on i.IdContratto = d.IdContratto
	where 
	i.DataInizioDelivery <> d.DataInizioDelivery or
	i.DataFineDelivery <> d.DataFineDelivery
)
begin
	exec AggiornaTabellaDataDelivery
end
--


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

/****** Object:  Trigger dbo.tr_ProfiloOrario_Update    Script Date: 20/10/2005 16.32.06 ******/



CREATE     TRIGGER tr_ProfiloOrario_Update ON [dbo].[ProfiloOrario] 
FOR UPDATE
AS

-- Aggiorna le ore fornitura contratti solo per i contratti
-- non ancora inseriti nella SessioneMercatoContratto
exec Contratto_AggiornaOreFornituraContrattiNoDelivery
--




GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


exec sp_addextendedproperty N'MS_Description', null, N'user', N'dbo', N'table', N'Contratto', N'column', N'DescrizioneContratto'


GO


exec sp_addextendedproperty N'MS_Description', N'chiave dell''offerta se pertinente', N'user', N'dbo', N'table', N'DailyActivityLog', N'column', N'IdOfferta'
GO
exec sp_addextendedproperty N'MS_Description', N'chiave dell''abbinamento se pertinente', N'user', N'dbo', N'table', N'DailyActivityLog', N'column', N'IdAbbinamento'
GO
exec sp_addextendedproperty N'MS_Description', N'Operatore interessato alla notifica.null --> tutti interessati', N'user', N'dbo', N'table', N'DailyActivityLog', N'column', N'CodiceOperatore'


GO


exec sp_addextendedproperty N'MS_Description', N'Lo stato cambia a fronte delle azioni dell''operatore di mercato e non sull''abbinamento', N'user', N'dbo', N'table', N'Offerta', N'column', N'StatoOfferta'


GO

