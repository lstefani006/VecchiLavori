SET LANGUAGE us_english
go

if Object_Id('tempdb..#TN') is Not Null drop table #TN
go
create table #TN
(
	Codice varchar(50) not null,
	Descrizione varchar(256) not null,
	ValoreFloat float null,
	ValoreInt int null,
	ValoreVarchar varchar(256) null,
	ValoreDateTime datetime null
)

INSERT INTO #TN
(
	Codice,
	Descrizione,
	ValoreFloat,
	ValoreInt,
	ValoreVarchar,
	ValoreDateTime
)
select 
	'OffertePercPrezzoRif' Codice,
	'Percentuale di scostamento del prezzo di riferimento' Descrizione,
	5 ValoreFloat,
	null ValoreInt,
	null ValoreVarchar,
	null ValoreDateTime

union select 
	'TimeoutVerdiRossi' Codice,
	'Numero di secondi prima che un offerta rossa/verde diventi grigia' Descrizione,
	null ValoreFloat,
	30 ValoreInt,
	null ValoreVarchar,
	null ValoreDateTime

union select 
	'TSAperturaSessione' Codice,
	'Orario di apertura della sessione' Descrizione,
	null ValoreFloat,
	null ValoreInt,
	null ValoreVarchar,
	convert(datetime, '1899-12-30 10:00:00.000', 121) ValoreDateTime

union select 
	'TSChiusuraSessione' Codice,
	'Orario di chiusura della sessione' Descrizione,
	null ValoreFloat,
	null ValoreInt,
	null ValoreVarchar,
	convert(datetime, '1899-12-30 16:00:00.000', 121) ValoreDateTime



update [dbo].[Parametri] 
set
Descrizione = #TN.Descrizione,
ValoreFloat = #TN.ValoreFloat,
ValoreInt = #TN.ValoreInt,
ValoreVarchar = #TN.ValoreVarchar,
ValoreDateTime = #TN.ValoreDateTime

from #TN
inner join [dbo].[Parametri] TV
on
TV.Codice = #TN.Codice


INSERT INTO [dbo].[Parametri] 
(
	Codice,
	Descrizione,
	ValoreFloat,
	ValoreInt,
	ValoreVarchar,
	ValoreDateTime
)
	select 
	*
	from #TN
	where not exists
	(
		select * from [dbo].[Parametri] TV
		where
		TV.Codice = #TN.Codice
	)

----------------------------------------------------------------------------
----------------------------------------------------------------------------


if Object_Id('tempdb..#TN') is Not Null drop table #TN
go
create table #TN
(
	-- tipoTipoTransazione
	TipoTransazione varchar(32) not null,
	DescrizioneTipoTransazione nvarchar(256) null
)

INSERT INTO #TN
(
	TipoTransazione,
	DescrizioneTipoTransazione
)
select 
	'ErroreRichiesta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RichiestaModificaOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RichiestaNuovaOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RichiestaRevocaOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RichiestaRivelaOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RichiestaSospendiOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RispostaModificaOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RispostaNuovaOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RispostaRevocaOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RispostaRivelaOfferta' TipoTransazione,
	null DescrizioneTipoTransazione

union select 
	'RispostaSospendiOfferta' TipoTransazione,
	null DescrizioneTipoTransazione



update [dbo].[TipoTransazione] 
set
DescrizioneTipoTransazione = #TN.DescrizioneTipoTransazione

from #TN
inner join [dbo].[TipoTransazione] TV
on
TV.TipoTransazione = #TN.TipoTransazione


INSERT INTO [dbo].[TipoTransazione] 
(
	TipoTransazione,
	DescrizioneTipoTransazione
)
	select 
	*
	from #TN
	where not exists
	(
		select * from [dbo].[TipoTransazione] TV
		where
		TV.TipoTransazione = #TN.TipoTransazione
	)

----------------------------------------------------------------------------
----------------------------------------------------------------------------


if Object_Id('tempdb..#TN') is Not Null drop table #TN
go

DBCC CHECKIDENT ('[dbo].[Offerta]', RESEED, 1)
SET IDENTITY_INSERT [dbo].[Offerta] ON

create table #TN
(
	IdSessioneMercato int not null,
	IdContratto int not null,
	IdOfferta int not null,
	CodiceUtente varchar(8) not null,
	CodiceOperatore varchar(8) not null,
	TipoOfferta char(1) not null,
	TSCreazione datetime not null,
	TSAbbinamento datetime not null,
	OffertaAMercato char(1) not null,
	PrezzoUnitario float not null,
	QtyRichiesta int not null,
	QtyResidua int not null,
	StatoOfferta char(2) not null,
	Compatibile char(1) not null,
	NoteOfferta nvarchar(80) not null,
	OperatoreOTC varchar(8) not null,
	CodiceOTC varchar(32) not null
)

INSERT INTO #TN
(
	IdSessioneMercato,
	IdContratto,
	IdOfferta,
	CodiceUtente,
	CodiceOperatore,
	TipoOfferta,
	TSCreazione,
	TSAbbinamento,
	OffertaAMercato,
	PrezzoUnitario,
	QtyRichiesta,
	QtyResidua,
	StatoOfferta,
	Compatibile,
	NoteOfferta,
	OperatoreOTC,
	CodiceOTC
)
select 
	1 IdSessioneMercato,
	105 IdContratto,
	632 IdOfferta,
	'2' CodiceUtente,
	'2' CodiceOperatore,
	'V' TipoOfferta,
	convert(datetime, '2005-10-20 11:59:52.550', 121) TSCreazione,
	convert(datetime, '2005-10-20 11:59:52.550', 121) TSAbbinamento,
	'N' OffertaAMercato,
	53 PrezzoUnitario,
	1 QtyRichiesta,
	0 QtyResidua,
	'VA' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	105 IdContratto,
	633 IdOfferta,
	'1' CodiceUtente,
	'1' CodiceOperatore,
	'A' TipoOfferta,
	convert(datetime, '2005-10-20 12:00:04.160', 121) TSCreazione,
	convert(datetime, '2005-10-20 12:00:04.160', 121) TSAbbinamento,
	'N' OffertaAMercato,
	53 PrezzoUnitario,
	1 QtyRichiesta,
	0 QtyResidua,
	'VA' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	105 IdContratto,
	634 IdOfferta,
	'2' CodiceUtente,
	'2' CodiceOperatore,
	'V' TipoOfferta,
	convert(datetime, '2005-10-20 12:01:32.373', 121) TSCreazione,
	convert(datetime, '2005-10-20 12:01:32.373', 121) TSAbbinamento,
	'N' OffertaAMercato,
	54 PrezzoUnitario,
	7 QtyRichiesta,
	0 QtyResidua,
	'VA' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	105 IdContratto,
	635 IdOfferta,
	'1' CodiceUtente,
	'1' CodiceOperatore,
	'A' TipoOfferta,
	convert(datetime, '2005-10-20 12:01:46.860', 121) TSCreazione,
	convert(datetime, '2005-10-20 12:01:46.860', 121) TSAbbinamento,
	'N' OffertaAMercato,
	54 PrezzoUnitario,
	3 QtyRichiesta,
	0 QtyResidua,
	'VA' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	105 IdContratto,
	636 IdOfferta,
	'1' CodiceUtente,
	'1' CodiceOperatore,
	'A' TipoOfferta,
	convert(datetime, '2005-10-20 13:51:11.787', 121) TSCreazione,
	convert(datetime, '2005-10-20 13:51:11.787', 121) TSAbbinamento,
	'N' OffertaAMercato,
	54 PrezzoUnitario,
	7 QtyRichiesta,
	3 QtyResidua,
	'RM' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	105 IdContratto,
	639 IdOfferta,
	'1' CodiceUtente,
	'1' CodiceOperatore,
	'A' TipoOfferta,
	convert(datetime, '2005-10-20 15:15:51.747', 121) TSCreazione,
	convert(datetime, '2005-10-20 15:15:51.747', 121) TSAbbinamento,
	'N' OffertaAMercato,
	53.15 PrezzoUnitario,
	7 QtyRichiesta,
	7 QtyResidua,
	'VA' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	107 IdContratto,
	637 IdOfferta,
	'1' CodiceUtente,
	'1' CodiceOperatore,
	'V' TipoOfferta,
	convert(datetime, '2005-10-20 13:56:08.240', 121) TSCreazione,
	convert(datetime, '2005-10-20 13:56:08.240', 121) TSAbbinamento,
	'N' OffertaAMercato,
	53 PrezzoUnitario,
	1 QtyRichiesta,
	1 QtyResidua,
	'VA' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	107 IdContratto,
	638 IdOfferta,
	'1' CodiceUtente,
	'1' CodiceOperatore,
	'A' TipoOfferta,
	convert(datetime, '2005-10-20 15:15:30.340', 121) TSCreazione,
	convert(datetime, '2005-10-20 15:15:30.340', 121) TSAbbinamento,
	'N' OffertaAMercato,
	53 PrezzoUnitario,
	1 QtyRichiesta,
	1 QtyResidua,
	'VA' StatoOfferta,
	'N' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	111 IdContratto,
	641 IdOfferta,
	'1' CodiceUtente,
	'1' CodiceOperatore,
	'V' TipoOfferta,
	convert(datetime, '2005-10-20 16:20:13.080', 121) TSCreazione,
	convert(datetime, '2005-10-20 16:23:12.160', 121) TSAbbinamento,
	'N' OffertaAMercato,
	53 PrezzoUnitario,
	1 QtyRichiesta,
	1 QtyResidua,
	'VA' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC

union select 
	1 IdSessioneMercato,
	122 IdContratto,
	640 IdOfferta,
	'1' CodiceUtente,
	'1' CodiceOperatore,
	'V' TipoOfferta,
	convert(datetime, '2005-10-20 15:20:35.650', 121) TSCreazione,
	convert(datetime, '2005-10-20 15:20:35.650', 121) TSAbbinamento,
	'N' OffertaAMercato,
	53 PrezzoUnitario,
	1 QtyRichiesta,
	1 QtyResidua,
	'RM' StatoOfferta,
	'S' Compatibile,
	'' NoteOfferta,
	'' OperatoreOTC,
	'' CodiceOTC



update [dbo].[Offerta] 
set
CodiceUtente = #TN.CodiceUtente,
CodiceOperatore = #TN.CodiceOperatore,
TipoOfferta = #TN.TipoOfferta,
TSCreazione = #TN.TSCreazione,
TSAbbinamento = #TN.TSAbbinamento,
OffertaAMercato = #TN.OffertaAMercato,
PrezzoUnitario = #TN.PrezzoUnitario,
QtyRichiesta = #TN.QtyRichiesta,
QtyResidua = #TN.QtyResidua,
StatoOfferta = #TN.StatoOfferta,
Compatibile = #TN.Compatibile,
NoteOfferta = #TN.NoteOfferta,
OperatoreOTC = #TN.OperatoreOTC,
CodiceOTC = #TN.CodiceOTC

from #TN
inner join [dbo].[Offerta] TV
on
TV.IdSessioneMercato = #TN.IdSessioneMercato
and TV.IdContratto = #TN.IdContratto
and TV.IdOfferta = #TN.IdOfferta


INSERT INTO [dbo].[Offerta] 
(
	IdSessioneMercato,
	IdContratto,
	IdOfferta,
	CodiceUtente,
	CodiceOperatore,
	TipoOfferta,
	TSCreazione,
	TSAbbinamento,
	OffertaAMercato,
	PrezzoUnitario,
	QtyRichiesta,
	QtyResidua,
	StatoOfferta,
	Compatibile,
	NoteOfferta,
	OperatoreOTC,
	CodiceOTC
)
	select 
	*
	from #TN
	where not exists
	(
		select * from [dbo].[Offerta] TV
		where
		TV.IdSessioneMercato = #TN.IdSessioneMercato
		and TV.IdContratto = #TN.IdContratto
		and TV.IdOfferta = #TN.IdOfferta
	)

SET IDENTITY_INSERT [dbo].[Offerta] OFF

----------------------------------------------------------------------------
----------------------------------------------------------------------------

