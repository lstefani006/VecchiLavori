using System;
using System.Diagnostics;
using Bipex_BLInterface;
using Bipex_Cache;
using Bipex_CacheBL;

namespace Bipex_CacheServer
{
	class Bipex_CacheServer
	{
		[MTAThread]
		static void Main(string[] args)
		{
			// carico la cache coi i dati della sessione corrente
			BipexCacheAS c = new BipexCacheAS();
			c.InitCache();

			// faccio partire il server che pubblica i dati.
			BipexCachePublisher s = new BipexCachePublisher(c);
			Debug.Assert(s == BipexCachePublisher.G);


			// qui faccio partire il remoting --> sono in listen sugli eventi di aggiornamento
			string blConfig = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
			RemConfig.ServerConfig(blConfig, typeof (CacheUpdater).Assembly);


			Console.WriteLine("Server started");
			Console.ReadLine();


			s.Stop();
		}


	}
}
