using System;
using System.Threading;
using Bipex_BLInterface;
using Delta;

//namespace Bipex_BL
//{
//	public class BookRiassuntivoSimulator
//	{
//		Thread _th;
//
//		public BookRiassuntivoSimulator()
//		{
//			_th = new Thread(new ThreadStart(Aggiorna));
//			_th.IsBackground = true;
//			_th.Start();
//		}
//
//		private void Aggiorna()
//		{
//			Random r = new Random();
//
//			for (;;)
//			{
//				Thread.Sleep(1 * 5000);
//
//				DataRecordList v2;
//				if (true)
//				{
//					DataRecordList v1 = BipexCache.G.GetLastVersion("BR", "");
//					v2 = v1.DeepClone();
//
//					// ATTENZIONE!!!
//					// ATTENZIONE!!!
//					// ATTENZIONE!!!
//					// DeepClone NON COPIA gli attributi che non sono da
//					// trasportare, se questi ultimi servono, vanno copiati a mano!!!
//					for (int k = 0; k < v1.Count; k++)
//					{
//						BookRiassuntivoDR dr1 = (BookRiassuntivoDR)v1[k];
//						BookRiassuntivoDR dr2 = (BookRiassuntivoDR)v2[k];
//						dr2.BidTS = dr1.BidTS;
//						dr2.AskTS = dr1.AskTS;
//					}
//				}
//
//				BookRiassuntivoDR dr;
//				dr = GeneraBid(r, v2);
//
//				BookPerTitoloAggiorna(dr);
//
//				dr = GeneraAsk(r, v2);
//
//				BookPerTitoloAggiorna(dr);
//
//				ResetBidAsk(v2);
//
//				// Obsoleto... cambiata generazione Caselle GIALLE dopo DEMO Vers.002.002
//				// del 20.07.2005
//				//
//				// ToggleLastAbb(r, v2);
//				
//				v2.Version = 0; // cosi` si accoda
//				BipexCache.G.Update("BR", "", v2);
//			}
//		}
//
//		private BookRiassuntivoDR GeneraBid(Random r, DataRecordList v2)
//		{
//			// questa e' la riga da cambiare...
//			int i = r.Next(0, v2.Count);
//			BookRiassuntivoDR dr = (BookRiassuntivoDR) v2[i];
//
//			// ==============================
//			// GENERA UNA OFFERTA DI ACQUISTO
//			// ==============================
//
//			double tmpIncrPrezzo = r.Next(0, 100);
//			tmpIncrPrezzo = tmpIncrPrezzo/100;
//			int tmpIncrQta = r.Next(0, 4);
//
//			// Se il prezzo e' nullo, non ho MAI piazzato un'offerta...
//			if (dr.IsNull("BidPrice"))
//			{
//				dr.SetNotNull("BidPrice");
//
//				if (dr.Contract.LastIndexOf("BSLD") != -1)
//					dr.BidPrice = 50;
//				else
//					if (dr.Contract.LastIndexOf("OFPK") != -1)
//					dr.BidPrice = 35;
//				else
//					if (dr.Contract.LastIndexOf("PEAK") != -1)
//					dr.BidPrice = 65;
//				else
//					dr.BidPrice = 50;
//
//				dr.SetNotNull("BidQty");
//				dr.BidQty = 5;
//				dr.SetNotNull("BidOperator");
//				dr.BidOperator = "NOTME";
//			}
//			if (dr.IsNull("AskPrice"))
//			{
//				dr.SetNotNull("AskPrice");
//
//				if (dr.Contract.LastIndexOf("BSLD") != -1)
//					dr.AskPrice = 50;
//				else
//					if (dr.Contract.LastIndexOf("OFPK") != -1)
//					dr.AskPrice = 35;
//				else
//					if (dr.Contract.LastIndexOf("PEAK") != -1)
//					dr.AskPrice = 65;
//				else
//					dr.AskPrice = 50;
//
//				dr.SetNotNull("AskQty");
//				dr.AskQty = 5;
//				dr.SetNotNull("AskOperator");
//				dr.AskOperator = "NOTME";
//			}
//
//			dr.SetNotNull("LastPrice");
//			dr.SetNotNull("LastQty");
//			dr.SetNotNull("LastTime");
//			dr.SetNotNull("MaxPrice");
//			dr.SetNotNull("MinPrice");
//
//			if (dr.IsNull("Indicators"))
//			{
//				dr.SetNotNull("Indicators");
//				dr.Indicators = BookRiassuntivoDR.Indicator.None;
//			}
//
//			// 50% offerta va su, 50% offerta va giu
//			if (Convert.ToBoolean(r.Next(0, 2)))
//			{
//				dr.BidPrice += tmpIncrPrezzo;
//				dr.BidQty += tmpIncrQta;
//				dr.SetBestBidTrendUP();
//			}
//			else
//			{
//				dr.BidPrice -= tmpIncrPrezzo;
//				if (dr.BidQty > tmpIncrQta) dr.BidQty -= tmpIncrQta;
//				dr.SetBestBidTrendDown();
//			}
//
//			dr.BidTS = DateTime.Now;
//
//			// DOPO la generazione dell'offerta di ACQUISTO
//			// reimposto gli altri valori con un valore "finto" ma congruente...
//			dr.AskPrice = dr.BidPrice + 1.55;
//			
//			// A questo punto ho generato Bid/Ask in modo coerente.
//
//			// QUESTO SERVE A GENERARE MAX/MIN/GIALLO SECONDO LE RICHIESTE DELLA DEMO V.002.002
//			if ((BookRiassuntivoDR.IsMaxPriceIsLastAbb(dr.Indicators)) ||
//				(BookRiassuntivoDR.IsMinPriceIsLastAbb(dr.Indicators)))
//			{
//				// Se uno dei due GIALLI � gi� attivo, lo spengo...
//				dr.SetMaxPriceIsNotLastAbb();
//				dr.SetMinPriceIsNotLastAbb();
//				dr.MaxPrice = dr.AskPrice - 0.15;
//				dr.MinPrice = dr.BidPrice + 0.15;
//			}
//			else
//			{
//				// Se nessuno dei due GIALLI � attivo, lo accendo se...
//				int imaxmin = Convert.ToInt16(r.Next(0, 10));
//				if (imaxmin == 0)
//				{
//					// 20% Max = Ask, Max Giallo...
//					dr.SetMaxPriceIsLastAbb();
//					dr.MaxPrice = dr.AskPrice;
//					dr.MinPrice = dr.BidPrice + 0.15;
//				}
//				else
//					if (imaxmin == 1)
//				{
//					// 20% Min = Bid, Min Giallo...
//					dr.SetMinPriceIsLastAbb();
//					dr.MaxPrice = dr.AskPrice - 0.15;
//					dr.MinPrice = dr.BidPrice;
//				}
//				else
//				{
//					// 60% Max/Min valori intermedi...
//					dr.MaxPrice = dr.AskPrice - 0.15;
//					dr.MinPrice = dr.BidPrice + 0.15;
//				}
//			}
//
//			dr.LastPrice = dr.BidPrice + 0.85;
//			dr.LastQty = dr.BidQty;
//			dr.LastTime = dr.BidTS;
//
//			// 20% offerta fatta da me, 80% offerta fatta da altri
//			if (!Convert.ToBoolean(r.Next(0, 5)))
//				dr.BidOperator = "ME";
//			else
//				dr.BidOperator = "NOTME";
//
//			// 20% offerta OTC, 80% offerta NO OTC
//			if (!Convert.ToBoolean(r.Next(0, 5)))
//				dr.SetLastAbbIsOTC();
//			else
//				dr.SetLastAbbIsNotOTC();
//
//			// Se e' la prima volta che passo sulla riga (Volume = Null), imposto
//			// con i valori dell'offerta appena generata i campi rimanenti...
//			if (dr.IsNull("Volume"))
//			{
//				dr.SetNotNull("Volume");
//				dr.SetNotNull("ConvPrice");
//				dr.SetNotNull("OffPrice");
//				dr.SetNotNull("RefPrice");
//
//				dr.Volume = dr.BidQty * 3;
//				dr.ConvPrice = dr.LastPrice;
//				dr.OffPrice = dr.LastPrice;
//				dr.RefPrice = dr.LastPrice;
//
//			}
//
//			return dr;
//		}
//
//		private BookRiassuntivoDR GeneraAsk(Random r, DataRecordList v2)
//		{
//			// questa e' la riga da cambiare...
//			int i = r.Next(0, v2.Count);
//			BookRiassuntivoDR dr = (BookRiassuntivoDR) v2[i];
//
//			// =============================
//			// GENERA UNA OFFERTA DI VENDITA
//			// =============================
//
//			double tmpIncrPrezzo = r.Next(0, 100);
//			tmpIncrPrezzo = tmpIncrPrezzo/100;
//			int tmpIncrQta = r.Next(0, 4);
//
//			// Se il prezzo e' nullo, non ho MAI piazzato un'offerta...
//			if (dr.IsNull("BidPrice"))
//			{
//				dr.SetNotNull("BidPrice");
//
//				if (dr.Contract.LastIndexOf("BSLD") != -1)
//					dr.BidPrice = 50;
//				else
//					if (dr.Contract.LastIndexOf("OFPK") != -1)
//					dr.BidPrice = 35;
//				else
//					if (dr.Contract.LastIndexOf("PEAK") != -1)
//					dr.BidPrice = 65;
//				else
//					dr.BidPrice = 50;
//
//				dr.SetNotNull("BidQty");
//				dr.BidQty = 5;
//				dr.SetNotNull("BidOperator");
//				dr.BidOperator = "NOTME";
//			}
//			if (dr.IsNull("AskPrice"))
//			{
//				dr.SetNotNull("AskPrice");
//
//				if (dr.Contract.LastIndexOf("BSLD") != -1)
//					dr.AskPrice = 50;
//				else
//					if (dr.Contract.LastIndexOf("OFPK") != -1)
//					dr.AskPrice = 35;
//				else
//					if (dr.Contract.LastIndexOf("PEAK") != -1)
//					dr.AskPrice = 65;
//				else
//					dr.AskPrice = 50;
//
//				dr.SetNotNull("AskQty");
//				dr.AskQty = 5;
//				dr.SetNotNull("AskOperator");
//				dr.AskOperator = "NOTME";
//			}
//
//			dr.SetNotNull("LastPrice");
//			dr.SetNotNull("LastQty");
//			dr.SetNotNull("LastTime");
//			dr.SetNotNull("MaxPrice");
//			dr.SetNotNull("MinPrice");
//
//			if (dr.IsNull("Indicators"))
//			{
//				dr.SetNotNull("Indicators");
//				dr.Indicators = BookRiassuntivoDR.Indicator.None;
//			}
//
//			// 50% offerta va su, 50% offerta va giu
//			if (Convert.ToBoolean(r.Next(0, 2)))
//			{
//				dr.AskPrice += tmpIncrPrezzo;
//				dr.AskQty += tmpIncrQta;
//				dr.SetBestAskTrendUP();
//			}
//			else
//			{
//				dr.AskPrice -= tmpIncrPrezzo;
//				if (dr.AskQty > tmpIncrQta) dr.AskQty -= tmpIncrQta;
//				dr.SetBestAskTrendDown();
//			}
//
//			dr.AskTS = DateTime.Now;
//
//			// DOPO la generazione dell'offerta di VENDITA
//			// reimposto gli altri valori con un valore "finto" ma congruente...
//			dr.BidPrice = dr.AskPrice - 1.55;
//			
//			// A questo punto ho generato Bid/Ask in modo coerente.
//
//			// QUESTO SERVE A GENERARE MAX/MIN/GIALLO SECONDO LE RICHIESTE DELLA DEMO V.002.002
//			if ((BookRiassuntivoDR.IsMaxPriceIsLastAbb(dr.Indicators)) ||
//				(BookRiassuntivoDR.IsMinPriceIsLastAbb(dr.Indicators)))
//			{
//				// Se uno dei due GIALLI � gi� attivo, lo spengo...
//				dr.SetMaxPriceIsNotLastAbb();
//				dr.SetMinPriceIsNotLastAbb();
//				dr.MaxPrice = dr.AskPrice - 0.15;
//				dr.MinPrice = dr.BidPrice + 0.15;
//			}
//			else
//			{
//				// Se nessuno dei due GIALLI � attivo, lo accendo se...
//				int imaxmin = Convert.ToInt16(r.Next(0, 5));
//				if (imaxmin == 0)
//				{
//					// 20% Max = Ask, Max Giallo...
//					dr.SetMaxPriceIsLastAbb();
//					dr.MaxPrice = dr.AskPrice;
//					dr.MinPrice = dr.BidPrice + 0.15;
//				}
//				else
//					if (imaxmin == 1)
//				{
//					// 20% Min = Bid, Min Giallo...
//					dr.SetMinPriceIsLastAbb();
//					dr.MaxPrice = dr.AskPrice - 0.15;
//					dr.MinPrice = dr.BidPrice;
//				}
//				else
//				{
//					// 60% Max/Min valori intermedi...
//					dr.MaxPrice = dr.AskPrice - 0.15;
//					dr.MinPrice = dr.BidPrice + 0.15;
//				}
//			}
//
//			dr.LastPrice = dr.AskPrice - 0.85;
//			dr.LastQty = dr.BidQty;
//			dr.LastTime = dr.BidTS;
//
//			// 20% offerta fatta da me, 80% offerta fatta da altri
//			if (!Convert.ToBoolean(r.Next(0, 5)))
//				dr.AskOperator = "ME";
//			else
//				dr.AskOperator = "NOTME";
//
//			// 20% offerta OTC, 80% offerta NO OTC
//			if (!Convert.ToBoolean(r.Next(0, 5)))
//				dr.SetLastAbbIsOTC();
//			else
//				dr.SetLastAbbIsNotOTC();
//
//			// Se e' la prima volta che passo sulla riga (Volume = Null), imposto
//			// con i valori dell'offerta appena generata i campi rimanenti...
//			if (dr.IsNull("Volume"))
//			{
//				dr.SetNotNull("Volume");
//				dr.SetNotNull("ConvPrice");
//				dr.SetNotNull("OffPrice");
//				dr.SetNotNull("RefPrice");
//
//				dr.Volume = dr.AskQty * 3;
//				dr.ConvPrice = dr.LastPrice;
//				dr.OffPrice = dr.LastPrice;
//				dr.RefPrice = dr.LastPrice;
//			}
//
//			return dr;
//		}
//
//		private void ResetBidAsk(DataRecordList v2)
//		{
//			foreach (BookRiassuntivoDR dr in v2)
//			{
//				// Se il prezzo e' nullo, non ho MAI piazzato un'offerta...
//				if (!dr.IsNull("BidPrice"))
//				{
//					// Tengo le segnalazioni di trend dei prezzi accese per 15 secondi...
//					if (DateTime.Now.AddSeconds(-15) > dr.BidTS)
//						dr.SetBestBidTrendStopped();
//				}
//				// Se il prezzo e' nullo, non ho MAI piazzato un'offerta...
//				if (!dr.IsNull("AskPrice"))
//				{
//					// Tengo le segnalazioni di trend dei prezzi accese per 15 secondi...
//					if (DateTime.Now.AddSeconds(-15) > dr.AskTS)
//						dr.SetBestAskTrendStopped();
//				}
//			}
//		}
//
//		private void ToggleLastAbb(Random r, DataRecordList v2)
//		{
//			// questa e' la riga da cambiare...
//			int i = r.Next(0, v2.Count);
//			BookRiassuntivoDR dr = (BookRiassuntivoDR) v2[i];
//
//			// Se non ho MAI movimentato la riga con offerte, NON e' da fare
//			// la gestione min / max
//			if (dr.IsNull("BidPrice") && dr.IsNull("AskPrice"))
//				return;
//
//			if (dr.IsNull("Indicators"))
//			{
//				dr.SetNotNull("Indicators");
//				dr.Indicators = BookRiassuntivoDR.Indicator.None;
//			}
//
//			// Se sono attivi tutti e due, li spengo...
//			if ((BookRiassuntivoDR.IsMaxPriceIsLastAbb(dr.Indicators)) &&
//				(BookRiassuntivoDR.IsMinPriceIsLastAbb(dr.Indicators)))
//			{
//				dr.SetMaxPriceIsNotLastAbb();
//				dr.SetMinPriceIsNotLastAbb();
//			}
//			
//			if (Convert.ToBoolean(r.Next(0, 2)))
//			{
//				if (BookRiassuntivoDR.IsMaxPriceIsLastAbb(dr.Indicators))
//					dr.SetMaxPriceIsNotLastAbb();
//				else
//					dr.SetMaxPriceIsLastAbb();
//			}
//			else
//			{
//				if (BookRiassuntivoDR.IsMinPriceIsLastAbb(dr.Indicators))
//					dr.SetMinPriceIsNotLastAbb();
//				else
//					dr.SetMinPriceIsLastAbb();
//			}
//
//		}
//
//
//		// /////////////////////////////////////////////////////////////
//		private void BookPerTitoloAggiorna(BookRiassuntivoDR drRiassuntivo)
//		{
//			DataRecordList listaDrSingoloV1 = BipexCache.G.GetLastVersion("BS", drRiassuntivo.Contract);
//
//			DataRecordList listaDrSingoloV2 = listaDrSingoloV1.DeepClone();
//			listaDrSingoloV2.Version = 0;
//
//			BookSingoloContrattoDR drSingolo = (BookSingoloContrattoDR) listaDrSingoloV2[0];
//
//			drSingolo.SetNotNull("LastPrice");
//			drSingolo.SetNotNull("LastQty");
//			drSingolo.SetNotNull("LastTime");
//			drSingolo.SetNotNull("LastIsOTC");
//
//			drSingolo.SetNotNull("MaxPrice");
//			drSingolo.SetNotNull("MaxPriceEqLastAbb");
//			drSingolo.SetNotNull("MinPrice");
//			drSingolo.SetNotNull("MinPriceEqLastAbb");
//
//			drSingolo.SetNotNull("Volume");
//			drSingolo.SetNotNull("ConvPrice");
//			drSingolo.SetNotNull("OffPrice");
//			drSingolo.SetNotNull("RefPrice");
//
//			drSingolo.LastPrice = drRiassuntivo.LastPrice;
//			drSingolo.LastQty = drRiassuntivo.LastQty;
//			drSingolo.LastTime = drRiassuntivo.LastTime;
//			drSingolo.LastIsOTC = BookRiassuntivoDR.IsLastAbbIsOTC(drRiassuntivo.Indicators);
//
//			drSingolo.MaxPrice = drRiassuntivo.MaxPrice;
//			drSingolo.MaxPriceEqLastAbb = BookRiassuntivoDR.IsMaxPriceIsLastAbb(drRiassuntivo.Indicators);
//			
//			drSingolo.MinPrice = drRiassuntivo.MinPrice;
//			drSingolo.MinPriceEqLastAbb = BookRiassuntivoDR.IsMinPriceIsLastAbb(drRiassuntivo.Indicators);
//
//			drSingolo.Volume = drRiassuntivo.Volume;
//			drSingolo.ConvPrice = drRiassuntivo.ConvPrice;
//			drSingolo.OffPrice = drRiassuntivo.OffPrice;
//			drSingolo.RefPrice = drRiassuntivo.RefPrice;
//
//			listaDrSingoloV2.Version = 0; // cosi` si accoda
//			BipexCache.G.Update("BS", drRiassuntivo.Contract, listaDrSingoloV2);
//		}
//	}
//}