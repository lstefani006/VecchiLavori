using System;

namespace Bipex_BL
{
	/// <summary>
	/// Summary description for Common.
	/// </summary>
	public class Common
	{
		public static string RootPath;
	}
}
