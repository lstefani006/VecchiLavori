using System;
using System.ComponentModel;
using Bipex_BLInterface;
using GME.BL;

namespace Bipex_BL
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	[RemotableServer("Bipex_ControlWS", "Login.rem")]
	public class Login : BLBase, ILogin
	{
		#region Costruttori ecc ecc

		private Container components = null;

		public Login(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public Login()
		{
			InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#endregion

		/// <summary>
		/// Controllo delle credenziali d'ingresso.
		/// </summary>
		/// <param name="login"></param>
		/// <param name="pwd"></param>
		/// <returns>null se login fail</returns>
		public DatiUtente CheckLogin(string login, string pwd)
		{
			string[] function = new string[]
				{
					DirittoFunzionale.Ctrl_DefinizioneAnagrafiche,
					DirittoFunzionale.Ctrl_DefinizioneContratti,
					DirittoFunzionale.Ctrl_Settlement,
					DirittoFunzionale.Mkt_Reports,
					DirittoFunzionale.Mkt_PresentazioneOfferte,
					DirittoFunzionale.Mkt_PresentazioneProgrammi,
				};

			if (login == "1" && pwd == "1")
			{
				DatiOperatore op = new DatiOperatore();
				op.Codice = "1";
				op.Descrizione = "BiPower Ltd. (Trading Conto Terzi)";
				op.RagioneSociale = "BiPower Ltd.";

				DatiUtente ut = new DatiUtente();
				ut.Codice = "1";
				ut.Nome = "Mario";
				ut.Cognome = "Rossi";
				ut.DirittoFunzionale = function;
				ut.Operatore = new DatiOperatore[] {op};
				ut.Ruolo = Ruolo.AdministratorFull;

				ut.Token = CreateLoginToken();

				return ut;
			}

			if (login == "2" && pwd == "2")
			{
				DatiOperatore op = new DatiOperatore();
				op.Codice = "2";
				op.Descrizione = "Minerva Energia e Consociate";
				op.RagioneSociale = "Minerva Energia S.p.A.";

				DatiUtente ut = new DatiUtente();
				ut.Codice = "2";
				ut.Nome = "Giuseppe";
				ut.Cognome = "Bianchi";
				ut.DirittoFunzionale = function;
				ut.Operatore = new DatiOperatore[] {op};
				ut.Ruolo = Ruolo.UserFull;

				ut.Token = CreateLoginToken();

				return ut;
			}

			if (login == "3" && pwd == "3")
			{
				DatiOperatore op = new DatiOperatore();
				op.Codice = "3";
				op.Descrizione = "PowerMarket & Associati S.p.A.";
				op.RagioneSociale = "PowerMarket & Associati S.p.A.";

				DatiUtente ut = new DatiUtente();
				ut.Codice = "3";
				ut.Nome = "Luca";
				ut.Cognome = "Verdi";
				ut.DirittoFunzionale = function;
				ut.Operatore = new DatiOperatore[] {op};
				ut.Ruolo = Ruolo.UserFull;

				ut.Token = CreateLoginToken();

				return ut;
			}

			return null;
		}

		static Random r = new Random();
		private static int CreateLoginToken()
		{
			return r.Next();
		}
	}
}