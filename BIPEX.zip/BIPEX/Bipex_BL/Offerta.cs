using System;
using System.Collections;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using Bipex.Messaging.Offerte;
using Bipex_BLInterface;
using GME.BL;
using GME.Utility;
using SPDriver;

namespace Bipex_BL
{
	/// <summary>
	/// Summary description for MarketDataProvider.
	/// </summary>
	[RemotableServer("Bipex_BLWS", "Offerta.rem")]
	public class Offerta : BLBase, IOfferta
	{
		#region Costruttori ecc ecc

		private Container components = null;

		public Offerta(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public Offerta()
		{
			InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#endregion

		private MessaggioIn _req = null;
		private bool _ErroreValidazione = false;
		private MessaggioOut _rsp;
		private string _codiceOperatoreCanale;
		private string _codiceUtenteCanale;


		private static XmlSerializer _xsTransazioneIn = new XmlSerializer(typeof (TransazioneIn));
		private static XmlSerializer _xsTransazioneOut = new XmlSerializer(typeof (TransazioneOut));

		private static XmlSerializer _xsMessaggioOut = new XmlSerializer(typeof (MessaggioOut));

		private static XmlSerializer _xsTestataMessaggioIn = null;

		static Offerta()
		{
			if (_xsTestataMessaggioIn == null)
			{
				// Create an XmlAttributes to override the default root element.
				XmlAttributes xmlAttributes = new XmlAttributes();

				// Create an XmlRootAttribute overloaded constructer 
				// and set its namespace.
				XmlRootAttribute rootAttribute = new XmlRootAttribute("Testata");
				rootAttribute.Namespace = "urn:XML-Bipex";

				// Set the XmlRoot property to the XmlRoot object.
				xmlAttributes.XmlRoot = rootAttribute;
				XmlAttributeOverrides attributeOverrides = new XmlAttributeOverrides();
   
				// Add the XmlAttributes object to the 
				// XmlAttributeOverrides object.
				attributeOverrides.Add(typeof(TestataMessaggioIn), xmlAttributes);

				// Create the Serializer, and return it.
				_xsTestataMessaggioIn = new XmlSerializer(typeof (TestataMessaggioIn), attributeOverrides);
			}

		}



		/// <summary>
		/// Elabora un RequestOfBipexSubjects per ottenere un ResponseOfBipexSubjects.
		/// I dati sono in byte[] sia in ingresso che in uscita.
		/// </summary>
		/// <param name="codiceOperatoreCanale">operatore come risulta dal canale</param>
		/// <param name="codiceUtenteCanale">utente come risulta dal canale</param>
		/// <param name="byteReq">richiesta</param>
		/// <returns>risposta</returns>
		public byte[] ElaboraRichiesta(string codiceOperatoreCanale, string codiceUtenteCanale, byte[] byteReq)
		{
			_codiceOperatoreCanale = codiceOperatoreCanale;
			_codiceUtenteCanale = codiceUtenteCanale;

			try
			{
				using (SqlConnection cn = new SqlConnection(SqlConnectionstring))
				{
					SqlTransaction tr = null;
					try
					{
						cn.Open();

						tr = cn.BeginTransaction();

						Offerta_Lock.Execute(tr, SqlString.Null);

#if DEBUG
						//string g = Encoding.UTF8.GetString(byteReq);
						// Debug.WriteLine(g);
#endif


						string fileSchema = AppSettings.ToString("Bipex_Offerte.xsd", AppDomain.CurrentDomain.SetupInformation.ApplicationBase + @"Bipex_Data\XmlFileSchemas\Bipex_Offerte.xsd");


						// questa funzione legge dal byteReq e valorizza il campo _req
						LeggiMessaggioRichiesta(fileSchema, byteReq);


						// se _rsp e` gia` valorizzato significa che c'e` stato un errore di validazione/struttura.
						// --> abbiamo gia` una risposta negativa.
						if (_rsp == null)
							ElaboraRichiesta(tr); // questo produce la _rsp

						// scrivo _rsp
						byte [] byteResp = ScriviMessaggioRisposta();


						bool bStore = false;
						if (bStore)
						{
							SqlInt32 IdMessaggioIn;
							StoreMessaggioIn(tr, byteReq, out IdMessaggioIn);
							StoreMessaggioOut(tr, IdMessaggioIn.Value,  byteResp);
						}

						tr.Commit();
						tr = null;

						return byteResp;
					}
					finally
					{
						if (tr != null)
							tr.Rollback();
					}
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}

		private void LeggiMessaggioRichiesta(string fileSchema, byte[] byteReq)
		{
			XmlSchemaCollection sc = new XmlSchemaCollection();
			sc.Add(null, fileSchema);

			StreamReader sr = new StreamReader(new MemoryStream(byteReq), Encoding.UTF8);
			XmlValidatingReader xv = new XmlValidatingReader(new XmlTextReader(sr));

			xv.ValidationType = ValidationType.Schema;
			xv.Schemas.Add(sc);
			xv.ValidationEventHandler += new ValidationEventHandler(xr_ValidationEventHandler);

			object elMessaggioIn = xv.NameTable.Add(typeof(MessaggioIn).Name);
			object elTestata = xv.NameTable.Add("Testata");
			object elTransazioneIn = xv.NameTable.Add(typeof(TransazioneIn).Name);


			try
			{
				ArrayList rq = new ArrayList();

				while (!_ErroreValidazione && xv.Read())
				{
					if (xv.NodeType == XmlNodeType.Element)
					{
						object el = xv.Name;
						if (el == elMessaggioIn)
						{
							_req = new MessaggioIn();
							_req.CodiceMessaggioIn = xv.GetAttribute("IdMessaggioIn");
							_req.DataOraMessaggio = XmlConvert.ToDateTime(xv.GetAttribute("DataOraMessaggio"));
							_req.Versione = tipoVersione.Item10;
						}
						else if (el == elTestata)
						{
							_req.Testata = (TestataMessaggioIn) _xsTestataMessaggioIn.Deserialize(xv);

							if (string.Compare(_req.Testata.Mittente.CodiceOperatore, _codiceOperatoreCanale, true) != 0)
								throw new ChannelSenderMismatch("Il codice operatore indicato nel file non corrisponde all'operatore che ha inviato il messaggio");

							if (string.Compare(_req.Testata.Mittente.CodiceUtente, _codiceUtenteCanale, true) != 0)
								throw new ChannelSenderMismatch("Il codice utente indicato nel file non corrisponde all'utente che ha inviato il messaggio");

						}
						else if (el == elTransazioneIn)
						{
							TransazioneIn r = (TransazioneIn) _xsTransazioneIn.Deserialize(xv);
							rq.Add(r);
						}
					}
				}

				_req.TransazioneIn = (TransazioneIn[]) rq.ToArray(typeof (TransazioneIn));
			}
			catch (Exception ex)
			{
				// qui costruisco _rsp
				BuildErrorMessage("-5", ex.Message);
			}
		}

		public class ChannelSenderMismatch : Exception
		{
			public ChannelSenderMismatch(string m)
				: base(m)
			{
			}
		}

		private byte[] ScriviMessaggioRisposta()
		{
			MemoryStream ms = new MemoryStream();
			XmlTextWriter xw = new XmlTextWriter(ms, Encoding.UTF8);
			xw.Indentation = 1;
			xw.IndentChar = '\t';
			xw.Formatting = Formatting.Indented;
			xw.Namespaces = true;
			_xsMessaggioOut.Serialize(xw, _rsp);
			xw.Flush();
			xw.Close();

			byte[] byteRsp = ms.ToArray();
			return byteRsp;
		}

		private void xr_ValidationEventHandler(object v, ValidationEventArgs e)
		{
			if (_rsp != null)
				return;

			if (e.Severity == XmlSeverityType.Error)
			{
				_ErroreValidazione = true;
				BuildErrorMessage("-3", e.Exception.LineNumber.ToString() + ": " + e.Message);
			}
		}

		/// <summary>
		/// Genera il messaggio di risposta in caso di errore grave ossia di validazione
		/// o di operatore/utente di canale diverso da quello che risulta nel messaggio.
		/// La risposta va sempre all'operatore di canale.
		/// Questa funzione e` chiama
		/// </summary>
		/// <param name="errorCode"></param>
		/// <param name="errorDescr"></param>
		private void BuildErrorMessage(string errorCode, string errorDescr)
		{
			_rsp = new MessaggioOut();
			_rsp.CodiceMessaggioOut = Guid.NewGuid().ToString("N");
			_rsp.DataOraMessaggio = DateTime.Now;

			if (_req != null && _req.CodiceMessaggioIn != null)
				_rsp.CodiceMessaggioRef = _req.CodiceMessaggioIn;
			else
				_rsp.CodiceMessaggioRef = "?";
			_rsp.Versione = tipoVersione.Item10;

			_rsp.Testata = new TestataMessaggioOut();
			_rsp.Testata.Destinatario = new Destinatario();
			_rsp.Testata.Destinatario.CodiceOperatore = _codiceOperatoreCanale;

			_rsp.Testata.Mittente = new MittenteRisposta();
			_rsp.Testata.Mittente.CodiceOperatore = "BIPEX";

			if (errorCode != null && errorDescr != null)
			{
				_rsp.Items = new object[1];

				ErroreMessaggio e = new ErroreMessaggio();
				e.Codice = errorCode;
				e.Descrizione = errorDescr;

				_rsp.Items[0] = e;
			}
		}



		private void StoreMessaggioIn(SqlTransaction tr, byte[] byteReq, out SqlInt32 IdMessaggioIn)
		{
			string codiceOperatore = _req.Testata.Mittente.CodiceOperatore;
			string codiceUtente    = _req.Testata.Mittente.CodiceUtente;

			IdMessaggioIn = new SqlInt32();

			string CodiceMessaggioIn = "OFF";
			string compresso = "";
			bool controfirmato = false;
			string nomeFileIn = "OffertaIn";
			bool firmatoInIngresso = false;
			MessaggioIn_Insert.Execute(tr,CodiceMessaggioIn, codiceOperatore, codiceUtente,nomeFileIn, 
				firmatoInIngresso, "UTF8", "1.0", byteReq, DateTime.Now, compresso, controfirmato, ref IdMessaggioIn);


			MemoryStream ms = new MemoryStream();
			int progressivoTransazioneIn = 0;

			foreach (TransazioneIn transazioneIn in _req.TransazioneIn)
			{
				ms.Position = 0;

				_xsTransazioneIn.Serialize(ms, transazioneIn);
				ms.Flush();
				byte [] a = ms.ToArray();

				string TipoTransazione = transazioneIn.Item.GetType().Name;

				TransazioneIn_Insert.Execute(tr, IdMessaggioIn, progressivoTransazioneIn, 
					transazioneIn.CodiceTransazioneIn, TipoTransazione, a);

				progressivoTransazioneIn++;
			}
		}

		private void StoreMessaggioOut(SqlTransaction tr, int IdMessaggioIn, byte [] byteResp)
		{
			string codiceOperatore = _req.Testata.Mittente.CodiceOperatore;

			SqlInt32 IdMessaggioOut = new SqlInt32();
			string CodiceMessaggioOut = "OFF";
			string compresso = "";
			bool firmatoInUscita = false;
			SqlDateTime DataOraDownload = SqlDateTime.Null;
			string nomeFileOut = "OffertaOut";
			MessaggioOut_Insert.Execute(tr,
				CodiceMessaggioOut, codiceOperatore, nomeFileOut, compresso, firmatoInUscita, "UTF8",
				DateTime.Now, "1.0", byteResp, IdMessaggioIn, DataOraDownload, ref IdMessaggioOut);

			MemoryStream ms = new MemoryStream();

			for (int rspIndex = 0; rspIndex < _rsp.Items.Length; rspIndex++)
			{
				ms.Position = 0;

				object r = _rsp.Items[rspIndex];

				// la risposta contiene 
				// <n> ErroreMessaggio oppure
				// <n> TransazioneOut
				Debug.Assert(
					r.GetType() == typeof(ErroreMessaggio) ||
					r.GetType() == typeof(TransazioneOut));

				int progressivoTransazioneIn = rspIndex;

				if (r is TransazioneOut)
				{
					TransazioneOut transazioneOut = (TransazioneOut) r;

					/*
					transazioneOut.Items e` del tipo

			        typeof(RispostaSospendiOfferta) ---> di questa un solo item
					typeof(RispostaRevocaOfferta)
					typeof(RispostaModificaOfferta)
					typeof(RispostaRivelaOfferta)
					typeof(RispostaNuovaOfferta)
					typeof(ErroreRichiesta)         ---> di questa ci puo` essere piu` di un item
					*/

					_xsTransazioneOut.Serialize(ms, transazioneOut);
					ms.Flush();
					byte [] a = ms.ToArray();
					TransazioneOut_Insert.Execute(tr, IdMessaggioOut, rspIndex, 
						transazioneOut.CodiceTransazioneRef,
						transazioneOut.Items[0].GetType().Name,
						IdMessaggioIn,
						progressivoTransazioneIn,
						transazioneOut.StatoTransazione.ToString(),
						a);
				}
				else if (r is ErroreMessaggio)
				{
					// i messaggi di errore globale NON devono essere messi in TransazioneOut
				}
				else 
					Debug.Assert(false);
			}
			
		}

		/////////////////////

		private void ElaboraRichiesta(SqlTransaction tr)
		{
			_rsp = new MessaggioOut();
			_rsp.CodiceMessaggioOut = Guid.NewGuid().ToString("N");
			_rsp.CodiceMessaggioRef = _req.CodiceMessaggioIn;
			_rsp.DataOraMessaggio = DateTime.Now;
			_rsp.Versione = tipoVersione.Item10;
			_rsp.Testata = new TestataMessaggioOut();
			_rsp.Testata.Destinatario = new Destinatario();
			_rsp.Testata.Destinatario.CodiceOperatore = _req.Testata.Mittente.CodiceOperatore;
			_rsp.Testata.Mittente = new MittenteRisposta();
			_rsp.Testata.Mittente.CodiceOperatore = "BIPEX";


			ArrayList a = new ArrayList();


			ICacheUpdater cu = (ICacheUpdater) GME.Remoting.RemotingHelper.GetObject(typeof(ICacheUpdater));

			foreach (TransazioneIn req in _req.TransazioneIn)
			{
				string bookModificato;
				TransazioneOut rsp = ElaboraRichiesta(tr, req, out bookModificato);

				a.Add(rsp);

				if (bookModificato != null)
				{
					Debug.WriteLine("BookModificato.", bookModificato);

					try
					{
						cu.OnAbbinamento(bookModificato);
					}
					catch (Exception ex)
					{
						GME.Log.smError(ex);
					}
				}
			}

			_rsp.Items = a.ToArray();
		}

		private TransazioneOut ElaboraRichiesta(SqlTransaction tr, TransazioneIn req, out string bookModificato)
		{
			Type tipoRichiesta = req.Item.GetType();
			     if (tipoRichiesta == typeof (RichiestaNuovaOfferta))    return Elabora_RichiestaNuovaOfferta(tr, req, (RichiestaNuovaOfferta) req.Item, out bookModificato);
			else if (tipoRichiesta == typeof (RichiestaModificaOfferta)) return Elabora_RichiestaModificaOfferta(tr, req, (RichiestaModificaOfferta) req.Item, out bookModificato);
			else if (tipoRichiesta == typeof (RichiestaRevocaOfferta))   return Elabora_RichiestaRevocaOfferta(tr, req, (RichiestaRevocaOfferta) req.Item, out bookModificato);
			else if (tipoRichiesta == typeof (RichiestaSospendiOfferta)) return Elabora_RichiestaSospendiOfferta(tr, req, (RichiestaSospendiOfferta) req.Item, out bookModificato);
			else if (tipoRichiesta == typeof (RichiestaRivelaOfferta))   return Elabora_RichiestaRivelaOfferta(tr, req, (RichiestaRivelaOfferta) req.Item, out bookModificato);
			else throw new ApplicationException("ElaboraRichiesta: tipo Rchiesta non supportato " + tipoRichiesta.ToString());
		}


		private TransazioneOut Elabora_RichiestaNuovaOfferta(SqlTransaction tr, TransazioneIn req, RichiestaNuovaOfferta ri, out string bookModificato)
		{
			try
			{
				SqlString errorCode = new SqlString();
				SqlString errorDescr = new SqlString();
				SqlString statoAbbinamento = new SqlString();
				SqlInt32 idOfferta = new SqlInt32();
				SqlDateTime dataOraEsecuzione = new SqlDateTime();

				if (ri.NoteOfferta == null) ri.NoteOfferta = "";
				if (ri.CodiceOTC == null) ri.CodiceOTC = "";
				if (ri.OperatoreOTC == null) ri.OperatoreOTC = "";


				Offerta_Nuova.Execute(tr,
				                      ri.Contratto,
				                      ri.TipoOfferta.ToString().Substring(0, 1),
				                      ri.Quantita,
				                      (double)ri.PrezzoUnitario,
				                      ri.NoteOfferta,
				                      ri.OperatoreOTC,
				                      ri.CodiceOTC,
				                      _req.Testata.Mittente.CodiceOperatore,
				                      _req.Testata.Mittente.CodiceUtente,
				                      ref errorCode,
				                      ref errorDescr,
				                      ref statoAbbinamento,
				                      ref idOfferta,
									  ref dataOraEsecuzione);

				TransazioneOut rsp = new TransazioneOut();
				rsp.CodiceTransazioneOut = Guid.NewGuid().ToString("N");
				rsp.CodiceTransazioneRef = req.CodiceTransazioneIn;
				rsp.DataOraElaborazione = dataOraEsecuzione.Value;

				if (errorCode.IsNull || errorCode.Value.Length == 0)
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Accettata;

					rsp.Items = new object[1];
					RispostaNuovaOfferta rs = new RispostaNuovaOfferta();
					rsp.Items[0] = rs;
					rs.IdOfferta = XmlConvert.ToString(idOfferta.Value);

					ConvertiStatoAbbinamento(statoAbbinamento.Value,
					                         out rs.StatoAbbinamento,
					                         out rs.StatoPostAbbinamento);

					bookModificato = ri.Contratto;
				}
				else
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Rigettata;

					rsp.Items = new object[1];
					ErroreRichiesta er = new ErroreRichiesta();
					rsp.Items[0] = er;
					er.Codice = errorCode.Value;
					er.Descrizione = errorDescr.Value;

					bookModificato = null;
				}


				return rsp;
			}
			catch (Exception e)
			{
				smError(e, "Elabora_RichiestaNuovaOfferta");
				throw;
			}
		}

		private TransazioneOut Elabora_RichiestaModificaOfferta(SqlTransaction tr, TransazioneIn req, RichiestaModificaOfferta ri, out string bookModificato)
		{
			try
			{
				SqlString errorCode = new SqlString();
				SqlString errorDescr = new SqlString();
				SqlString statoAbbinamento = new SqlString();
				SqlInt32 idOfferta = new SqlInt32();
				SqlDateTime dataOraEsecuzione = new SqlDateTime();
				SqlString nomeContratto = new SqlString();

				if (ri.NoteOfferta == null) ri.NoteOfferta = "";
				idOfferta = SqlInt32.Parse(ri.IdOfferta);

				Offerta_Modifica.Execute(tr, 
					idOfferta,
					_req.Testata.Mittente.CodiceOperatore,
					_req.Testata.Mittente.CodiceUtente,
					ri.Quantita,
					(double)ri.PrezzoUnitario,
					ri.NoteOfferta, 
					ref errorCode,
					ref errorDescr,
					ref statoAbbinamento,
					ref dataOraEsecuzione,
					ref nomeContratto);

				TransazioneOut rsp = new TransazioneOut();
				rsp.CodiceTransazioneOut = req.CodiceTransazioneIn;
				rsp.DataOraElaborazione = dataOraEsecuzione.Value;

				if (errorCode.IsNull || errorCode.Value.Length == 0)
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Accettata;

					rsp.Items = new object[1];
					RispostaModificaOfferta rs = new RispostaModificaOfferta();
					rsp.Items[0] = rs;
					rs.IdOfferta = XmlConvert.ToString(idOfferta.Value);

					ConvertiStatoAbbinamento(statoAbbinamento.Value,
						out rs.StatoAbbinamento,
						out rs.StatoPostAbbinamento);

					bookModificato = nomeContratto.Value;
				}
				else
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Rigettata;

					rsp.Items = new object[1];
					ErroreRichiesta er = new ErroreRichiesta();
					rsp.Items[0] = er;
					er.Codice = errorCode.Value;
					er.Descrizione = errorDescr.Value;

					bookModificato = null;
				}

				return rsp;
			}
			catch (Exception e)
			{
				smError(e, "Elabora_RichiestaModificaOfferta");
				throw;
			}
		}

		private TransazioneOut Elabora_RichiestaRevocaOfferta(SqlTransaction tr, TransazioneIn req, RichiestaRevocaOfferta ri, out string bookModificato)
		{
			try
			{
				SqlString errorCode = new SqlString();
				SqlString errorDescr = new SqlString();
				SqlInt32 idOfferta = new SqlInt32();
				SqlDateTime dataOraEsecuzione = new SqlDateTime();
				SqlString nomeContratto = new SqlString();

				if (ri.NoteOfferta == null) ri.NoteOfferta = "";
				idOfferta = SqlInt32.Parse(ri.IdOfferta);

				Offerta_Revoca.Execute(tr,
					idOfferta,
					_req.Testata.Mittente.CodiceOperatore,
					_req.Testata.Mittente.CodiceUtente,
					ri.NoteOfferta,
					ref errorCode,
					ref errorDescr,
					ref dataOraEsecuzione,
					ref nomeContratto);

				TransazioneOut rsp = new TransazioneOut();
				rsp.CodiceTransazioneOut = Guid.NewGuid().ToString("N");
				rsp.CodiceTransazioneRef = req.CodiceTransazioneIn;
				rsp.DataOraElaborazione = dataOraEsecuzione.Value;

				if (errorCode.IsNull || errorCode.Value.Length == 0)
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Accettata;

					rsp.Items = new object[1];
					RispostaRevocaOfferta rs = new RispostaRevocaOfferta();
					rsp.Items[0] = rs;
					rs.IdOfferta = XmlConvert.ToString(idOfferta.Value);

					bookModificato = nomeContratto.Value;
				}
				else
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Rigettata;

					rsp.Items = new object[1];
					ErroreRichiesta er = new ErroreRichiesta();
					rsp.Items[0] = er;
					er.Codice = errorCode.Value;
					er.Descrizione = errorDescr.Value;

					bookModificato = null;
				}

				return rsp;
			}
			catch (Exception e)
			{
				smError(e, "Elabora_RichiestaRevocaOfferta");
				throw;
			}
		}

		private TransazioneOut Elabora_RichiestaSospendiOfferta(SqlTransaction tr, TransazioneIn req, RichiestaSospendiOfferta ri, out string bookModificato)
		{
			try
			{
				SqlString errorCode = new SqlString();
				SqlString errorDescr = new SqlString();
				SqlInt32 idOfferta = new SqlInt32();
				SqlDateTime dataOraEsecuzione = new SqlDateTime();
				SqlString nomeContratto = new SqlString();

				if (ri.NoteOfferta == null) ri.NoteOfferta = "";
				idOfferta = SqlInt32.Parse(ri.IdOfferta);

				Offerta_Nascondi.Execute(tr,
					idOfferta,
					_req.Testata.Mittente.CodiceOperatore,
					_req.Testata.Mittente.CodiceUtente,
					ri.NoteOfferta,
					ref errorCode,
					ref errorDescr,
					ref dataOraEsecuzione,
					ref nomeContratto);

				TransazioneOut rsp = new TransazioneOut();
				rsp.CodiceTransazioneOut = Guid.NewGuid().ToString("N");
				rsp.CodiceTransazioneRef = req.CodiceTransazioneIn;
				rsp.DataOraElaborazione = dataOraEsecuzione.Value;

				if (errorCode.IsNull || errorCode.Value.Length == 0)
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Accettata;

					rsp.Items = new object[1];
					RispostaSospendiOfferta rs = new RispostaSospendiOfferta();
					rsp.Items[0] = rs;
					rs.IdOfferta = XmlConvert.ToString(idOfferta.Value);

					bookModificato = nomeContratto.Value;
				}
				else
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Rigettata;

					rsp.Items = new object[1];
					ErroreRichiesta er = new ErroreRichiesta();
					rsp.Items[0] = er;
					er.Codice = errorCode.Value;
					er.Descrizione = errorDescr.Value;

					bookModificato = null;
				}

				return rsp;
			}
			catch (Exception e)
			{
				smError(e, "Elabora_RichiestaSospendiOfferta");
				throw;
			}
		}

		private TransazioneOut Elabora_RichiestaRivelaOfferta(SqlTransaction tr, TransazioneIn req, RichiestaRivelaOfferta ri, out string bookModificato)
		{
			try
			{
				SqlString errorCode = new SqlString();
				SqlString errorDescr = new SqlString();
				SqlString statoAbbinamento = new SqlString();
				SqlInt32 idOfferta = new SqlInt32();
				SqlDateTime dataOraEsecuzione = new SqlDateTime();
				SqlString nomeContratto = new SqlString();

				if (ri.NoteOfferta == null) ri.NoteOfferta = "";
				idOfferta = SqlInt32.Parse(ri.IdOfferta);

				Offerta_Rivela.Execute(tr, 
					idOfferta,
					_req.Testata.Mittente.CodiceOperatore,
					_req.Testata.Mittente.CodiceUtente,
					ri.NoteOfferta,
					ref errorCode,
					ref errorDescr,
					ref statoAbbinamento, 
					ref dataOraEsecuzione,
					ref nomeContratto);

				TransazioneOut rsp = new TransazioneOut();
				rsp.CodiceTransazioneOut = Guid.NewGuid().ToString("N");
				rsp.CodiceTransazioneRef = req.CodiceTransazioneIn;
				rsp.DataOraElaborazione = dataOraEsecuzione.Value;

				if (errorCode.IsNull || errorCode.Value.Length == 0)
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Accettata;

					rsp.Items = new object[1];
					RispostaRivelaOfferta rs = new RispostaRivelaOfferta();
					rsp.Items[0] = rs;
					rs.IdOfferta = XmlConvert.ToString(idOfferta.Value);

					ConvertiStatoAbbinamento(statoAbbinamento.Value,
						out rs.StatoAbbinamento,
						out rs.StatoPostAbbinamento);

					bookModificato = nomeContratto.Value;
				}
				else
				{
					rsp.StatoTransazione = tipoStatoTransazione.TransazioneIn_Rigettata;

					rsp.Items = new object[1];
					ErroreRichiesta er = new ErroreRichiesta();
					rsp.Items[0] = er;
					er.Codice = errorCode.Value;
					er.Descrizione = errorDescr.Value;

					bookModificato = null;
				}

				return rsp;
			}
			catch (Exception e)
			{
				smError(e, "Elabora_RichiestaRivelaOfferta");
				throw;
			}
		}

		private static void ConvertiStatoAbbinamento(string sa, out tipoStatoAbbinamento a, out tipoStatoPostAbbinamento b)
		{
			if (sa.Length != 2)
				throw new ArgumentException("StatoAbbinamento non ha il formato corretto", "sa");

			switch (sa[0])
			{
			case 'N':
				a = tipoStatoAbbinamento.OffertaNonAbbinata;
				break;

			case 'P':
				a = tipoStatoAbbinamento.OffertaParzialmenteAbbinata;
				break;

			case 'T':
				a = tipoStatoAbbinamento.OffertaTotalmenteAbbinata;
				break;

			default:
				throw new ArgumentException("StatoAbbinamento(1) non ha il formato corretto", "sa");
			}

			switch (sa[1])
			{
			case 'C':
				b = tipoStatoPostAbbinamento.OffertaCompatibile;
				break;
			case 'N':
				b = tipoStatoPostAbbinamento.OffertaNonCompatibile;
				break;

			default:
				throw new ArgumentException("StatoAbbinamento(2) non ha il formato corretto", "sa");
			}

		}
	}
}