using System;
using System.ComponentModel;
using Bipex_BLInterface;
using GME.BL;

namespace Bipex_BL
{
	[RemotableServer("Bipex_BLWS", "Echo.rem")]
	public class Echo : BLBase, IEcho
	{
		#region Contruttori

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;

		public Echo(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public Echo()
		{
			InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#endregion

		public string Ping(string msg)
		{
			try
			{
				return msg;
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}
	}
}