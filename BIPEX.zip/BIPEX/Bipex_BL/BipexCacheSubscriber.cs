using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Delta;
using GME;
using GME.Utility;

namespace Bipex_BL
{
	/// <summary>
	/// Classe per sottoscrivere gli eventi di aggiornamento della cache.
	/// Deve essere lanciata in BLControl_WS
	/// </summary>
	public class BipexCacheSubscriber
	{
		private static BipexCacheSubscriber _S;
		private static Thread _T;

		public static void Start()
		{
			if (_S != null)
				throw new ApplicationException("Thread gia` partito");

			_S = new BipexCacheSubscriber();
			_T = new Thread(new ThreadStart(_S.Th));
			_T.IsBackground = true;
			_T.Start();
		}


		private void Th()
		{
#if DEBUG
			Thread.Sleep(1000 * 10);
#endif
			for (;;)
			{
				try
				{
					string hostName = AppSettings.ToString("BipexCacheUpdater_Hostname", "127.0.0.1");
					int port = AppSettings.ToInt32("BipexCacheUpdater_Port", 7258);


					TcpClient c = new TcpClient();
					c.Connect(hostName, port);

					NetworkStream ns = c.GetStream();


					for (;;)
					{
						BinaryReader br = new BinaryReader(ns, Encoding.UTF8);
						string SubjectType = br.ReadString();
						string SubjectSubType = br.ReadString();
						int len = br.ReadInt32();
						byte[] m = br.ReadBytes(len);

						// rispondo un ACK
						BinaryWriter bw = new BinaryWriter(ns, Encoding.UTF8);
						bw.Write(len);
						bw.Flush();
						ns.Flush();

						DataRecordList drl = (DataRecordList) CompactFormatter.ReadObject(m);
						drl.Version = 0;
						BipexCache.G.Update(SubjectType, SubjectSubType, drl);
					}
				}
				catch (Exception ex)
				{
					Log.smError(ex);
				}

				Thread.Sleep(1000 * 2);
			}
		}
	}
}