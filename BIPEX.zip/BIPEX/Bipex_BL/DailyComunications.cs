using System;
using System.Collections;
using System.ComponentModel;
using System.IO;
using Bipex_BLInterface;
using GME.BL;
using GME.Utility;

namespace Bipex_BL
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	[RemotableServer("Bipex_ControlWS", "DailyComunications.rem")]
	public class DailyComunications : BLBase, IDailyComunications
	{
		#region Costruttori ecc ecc

		private Container components = null;

		public DailyComunications(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public DailyComunications()
		{
			InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#endregion

		/// <summary>
		/// Ritorna il messaggio di benvenuto da presentare agli utenti di Bipex quando lanciano il programma
		/// </summary>
		/// <param name="dt"></param>
		/// <returns>null se non esiste comunicazione del giorno</returns>
		public byte[] WelcomeMessage(DateTime dt)
		{
			try
			{
				string file = Path.Combine(CommunicationDir, WelcomeMessageFileName(dt));
				if (!File.Exists(file))
				{
					file = Path.Combine(CommunicationDir, DefaultWelcomeMessageFileName);
					if (!File.Exists(file))
						return null;
				}

				using (FileStream fs = File.OpenRead(file))
				{
					byte[] r = new byte[fs.Length];
					fs.Read(r, 0, r.Length);
					return r;
				}
			}
			catch (Exception e)
			{
				smError(e);
				throw;
			}
		}

		private static string CommunicationDir
		{
			get
			{
				string root = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
				string d = AppSettings.ToString("DailyMessages", "Bipex_Data\\DailyMessages");
				string dir = Path.Combine(root, d);
				return dir;
			}
		}

		private static string ComunicationFileName(DateTime dt, int index)
		{
			string cs = AppSettings.ToString("ComunicationsSuffix", "-C");

			string file = dt.ToString("yyyy-MM-dd") + cs + index.ToString("00") + ".rtf";
			return file;
		}

		private static string DefaultWelcomeMessageFileName
		{
			get
			{
				string wm = AppSettings.ToString("DefaultWelcomeMessage", "WM.rtf");
				return wm;
			}
		}

		private static string WelcomeMessageFileName(DateTime dt)
		{
			string wm = AppSettings.ToString("WelcomeMessageSuffix", "-WM");
			string file = dt.ToString("yyyy-MM-dd") + wm + ".rtf";
			return file;
		}

		/// <summary>
		/// Ritorna il numero di comunicazioni del giorno (escluso il messaggio di benvenuto)
		/// </summary>
		/// <returns></returns>
		public int GetDailyComunicationsCount(DateTime dt)
		{
			try
			{
				for (int index = 1; index <= 99; ++index)
				{
					string file = Path.Combine(CommunicationDir, ComunicationFileName(dt, index));
					if (!File.Exists(file))
						return index - 1;
				}
				return 0;
			}
			catch (Exception e)
			{
				smError(e);
				throw;
			}
		}

		/// <summary>
		/// Ritorna l'i-esima comunicazione del giorno
		/// </summary>
		/// <param name="dt"></param>
		/// <param name="index"></param>
		/// <returns>null se non esiste la comunicazione i-esima</returns>
		public byte[] GetDailyComunication(DateTime dt, int index)
		{
			try
			{
				string file = Path.Combine(CommunicationDir, ComunicationFileName(dt, index));
				if (!File.Exists(file))
					return null;

				using (FileStream fs = File.OpenRead(file))
				{
					byte[] r = new byte[fs.Length];
					fs.Read(r, 0, r.Length);
					return r;
				}
			}
			catch (Exception e)
			{
				smError(e);
				throw;
			}
		}
	}
}