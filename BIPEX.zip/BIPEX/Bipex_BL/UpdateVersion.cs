using System;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using Bipex_BLInterface;
using GME.BL;

namespace Bipex_BL
{
	/// <summary>
	/// Summary description for UpdateVersion.
	/// </summary>
	/// 
	[RemotableServer("Bipex_ControlWS", "UpdateVersion.rem")]
	public class UpdateVersion : BLBase, IUpdateVersion
	{
		#region Costruttori ecc ecc 

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;

		public UpdateVersion(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public UpdateVersion()
		{
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#endregion

		public IUpdateVersion_EngineEntry[] GetLastEngineFileList()
		{
			try
			{
				IUpdateVersion_EngineEntry[] r;

				string root = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
				r = IUpdateVersion_EngineEntry.GetLastEngineFileList(Path.Combine(root, "Bipex_Engine"));
				return r;
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}

		public bool CheckForUpdate(IUpdateVersion_EngineEntry[] clientEngineFileList)
		{
			try
			{
				IUpdateVersion_EngineEntry[] serverEngineFileList = GetLastEngineFileList();

				bool needUpdate = IUpdateVersion_EngineEntry.CheckForUpdate(serverEngineFileList, clientEngineFileList);
				return needUpdate;
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}
	}
}