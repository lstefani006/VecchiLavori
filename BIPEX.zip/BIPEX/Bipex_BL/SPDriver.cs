using System; 
using System.Data; 
using System.Data.SqlClient; 
using System.Data.SqlTypes; 
namespace SPDriver 
{ 
	public class Offerta_Lock
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlString _Contratto = SqlString.Null;
		protected bool _ContrattoSet = false;
		#endregion

		#region Public Properties

		public SqlString Contratto
		{
			get { return _Contratto; }
			set 
			{
				_Contratto = value;
				_ContrattoSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[Offerta_Lock]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmContratto = cmd.Parameters.Add("@Contratto", SqlDbType.NVarChar);
			prmContratto.IsNullable = true;
			prmContratto.Size = 30;
			prmContratto.Direction = ParameterDirection.Input;
			if (this._ContrattoSet == true)
				prmContratto.Value = this.Contratto;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlString Contratto)
		{
			Offerta_Lock runner = new Offerta_Lock();
			runner.Contratto = Contratto;

			runner.Execute(cn);


		}

		public static void Execute(
				SqlTransaction tr,
				SqlString Contratto)
		{
			Offerta_Lock runner = new Offerta_Lock();
			runner.Contratto = Contratto;

			runner.Execute(tr.Connection, tr);

		}

		#endregion

	}
	public class Offerta_Modifica
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlInt32 _IdOfferta = SqlInt32.Null;
		protected bool _IdOffertaSet = false;
		protected SqlString _CodiceOperatore = SqlString.Null;
		protected bool _CodiceOperatoreSet = false;
		protected SqlString _CodiceUtente = SqlString.Null;
		protected bool _CodiceUtenteSet = false;
		protected SqlInt32 _QtyRichiesta = SqlInt32.Null;
		protected bool _QtyRichiestaSet = false;
		protected SqlDouble _PrezzoUnitario = SqlDouble.Null;
		protected bool _PrezzoUnitarioSet = false;
		protected SqlString _NoteOfferta = SqlString.Null;
		protected bool _NoteOffertaSet = false;
		protected SqlString _ErroreCode = SqlString.Null;
		protected bool _ErroreCodeSet = false;
		protected SqlString _ErroreDescription = SqlString.Null;
		protected bool _ErroreDescriptionSet = false;
		protected SqlString _StatoAbbinamento = SqlString.Null;
		protected bool _StatoAbbinamentoSet = false;
		protected SqlDateTime _DataElaborazione = SqlDateTime.Null;
		protected bool _DataElaborazioneSet = false;
		protected SqlString _NomeContratto = SqlString.Null;
		protected bool _NomeContrattoSet = false;
		#endregion

		#region Public Properties

		public SqlInt32 IdOfferta
		{
			get { return _IdOfferta; }
			set 
			{
				_IdOfferta = value;
				_IdOffertaSet = true;
			}
		}

		public SqlString CodiceOperatore
		{
			get { return _CodiceOperatore; }
			set 
			{
				_CodiceOperatore = value;
				_CodiceOperatoreSet = true;
			}
		}

		public SqlString CodiceUtente
		{
			get { return _CodiceUtente; }
			set 
			{
				_CodiceUtente = value;
				_CodiceUtenteSet = true;
			}
		}

		public SqlInt32 QtyRichiesta
		{
			get { return _QtyRichiesta; }
			set 
			{
				_QtyRichiesta = value;
				_QtyRichiestaSet = true;
			}
		}

		public SqlDouble PrezzoUnitario
		{
			get { return _PrezzoUnitario; }
			set 
			{
				_PrezzoUnitario = value;
				_PrezzoUnitarioSet = true;
			}
		}

		public SqlString NoteOfferta
		{
			get { return _NoteOfferta; }
			set 
			{
				_NoteOfferta = value;
				_NoteOffertaSet = true;
			}
		}

		public SqlString ErroreCode
		{
			get { return _ErroreCode; }
			set 
			{
				_ErroreCode = value;
				_ErroreCodeSet = true;
			}
		}

		public SqlString ErroreDescription
		{
			get { return _ErroreDescription; }
			set 
			{
				_ErroreDescription = value;
				_ErroreDescriptionSet = true;
			}
		}

		public SqlString StatoAbbinamento
		{
			get { return _StatoAbbinamento; }
			set 
			{
				_StatoAbbinamento = value;
				_StatoAbbinamentoSet = true;
			}
		}

		public SqlDateTime DataElaborazione
		{
			get { return _DataElaborazione; }
			set 
			{
				_DataElaborazione = value;
				_DataElaborazioneSet = true;
			}
		}

		public SqlString NomeContratto
		{
			get { return _NomeContratto; }
			set 
			{
				_NomeContratto = value;
				_NomeContrattoSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[Offerta_Modifica]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmIdOfferta = cmd.Parameters.Add("@IdOfferta", SqlDbType.Int);
			prmIdOfferta.IsNullable = true;
			prmIdOfferta.Direction = ParameterDirection.Input;
			if (this._IdOffertaSet == true)
				prmIdOfferta.Value = this.IdOfferta;

			SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
			prmCodiceOperatore.IsNullable = true;
			prmCodiceOperatore.Size = 8;
			prmCodiceOperatore.Direction = ParameterDirection.Input;
			if (this._CodiceOperatoreSet == true)
				prmCodiceOperatore.Value = this.CodiceOperatore;

			SqlParameter prmCodiceUtente = cmd.Parameters.Add("@CodiceUtente", SqlDbType.VarChar);
			prmCodiceUtente.IsNullable = true;
			prmCodiceUtente.Size = 8;
			prmCodiceUtente.Direction = ParameterDirection.Input;
			if (this._CodiceUtenteSet == true)
				prmCodiceUtente.Value = this.CodiceUtente;

			SqlParameter prmQtyRichiesta = cmd.Parameters.Add("@QtyRichiesta", SqlDbType.Int);
			prmQtyRichiesta.IsNullable = true;
			prmQtyRichiesta.Direction = ParameterDirection.Input;
			if (this._QtyRichiestaSet == true)
				prmQtyRichiesta.Value = this.QtyRichiesta;

			SqlParameter prmPrezzoUnitario = cmd.Parameters.Add("@PrezzoUnitario", SqlDbType.Float);
			prmPrezzoUnitario.IsNullable = true;
			prmPrezzoUnitario.Direction = ParameterDirection.Input;
			if (this._PrezzoUnitarioSet == true)
				prmPrezzoUnitario.Value = this.PrezzoUnitario;

			SqlParameter prmNoteOfferta = cmd.Parameters.Add("@NoteOfferta", SqlDbType.NVarChar);
			prmNoteOfferta.IsNullable = true;
			prmNoteOfferta.Size = 80;
			prmNoteOfferta.Direction = ParameterDirection.Input;
			if (this._NoteOffertaSet == true)
				prmNoteOfferta.Value = this.NoteOfferta;

			SqlParameter prmErroreCode = cmd.Parameters.Add("@ErroreCode", SqlDbType.VarChar);
			prmErroreCode.IsNullable = true;
			prmErroreCode.Size = 5;
			if (this._ErroreCodeSet)
				prmErroreCode.Direction = ParameterDirection.InputOutput;
			else
				prmErroreCode.Direction = ParameterDirection.Output;
			if (this._ErroreCodeSet)
				prmErroreCode.Value = this.ErroreCode;

			SqlParameter prmErroreDescription = cmd.Parameters.Add("@ErroreDescription", SqlDbType.VarChar);
			prmErroreDescription.IsNullable = true;
			prmErroreDescription.Size = 256;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Direction = ParameterDirection.InputOutput;
			else
				prmErroreDescription.Direction = ParameterDirection.Output;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Value = this.ErroreDescription;

			SqlParameter prmStatoAbbinamento = cmd.Parameters.Add("@StatoAbbinamento", SqlDbType.VarChar);
			prmStatoAbbinamento.IsNullable = true;
			prmStatoAbbinamento.Size = 2;
			if (this._StatoAbbinamentoSet)
				prmStatoAbbinamento.Direction = ParameterDirection.InputOutput;
			else
				prmStatoAbbinamento.Direction = ParameterDirection.Output;
			if (this._StatoAbbinamentoSet)
				prmStatoAbbinamento.Value = this.StatoAbbinamento;

			SqlParameter prmDataElaborazione = cmd.Parameters.Add("@DataElaborazione", SqlDbType.DateTime);
			prmDataElaborazione.IsNullable = true;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Direction = ParameterDirection.InputOutput;
			else
				prmDataElaborazione.Direction = ParameterDirection.Output;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Value = this.DataElaborazione;

			SqlParameter prmNomeContratto = cmd.Parameters.Add("@NomeContratto", SqlDbType.NVarChar);
			prmNomeContratto.IsNullable = true;
			prmNomeContratto.Size = 30;
			if (this._NomeContrattoSet)
				prmNomeContratto.Direction = ParameterDirection.InputOutput;
			else
				prmNomeContratto.Direction = ParameterDirection.Output;
			if (this._NomeContrattoSet)
				prmNomeContratto.Value = this.NomeContratto;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmErroreCode = cmd.Parameters["@ErroreCode"];
			if (prmErroreCode != null && prmErroreCode.Value != null)
			{
				if (prmErroreCode.Value is SqlString)
					this.ErroreCode = (SqlString)prmErroreCode.Value;
				else
				{
					if (prmErroreCode.Value != DBNull.Value)
						this.ErroreCode = new SqlString((string)prmErroreCode.Value);
					else
						this.ErroreCode = SqlString.Null;
				}
			}

			SqlParameter prmErroreDescription = cmd.Parameters["@ErroreDescription"];
			if (prmErroreDescription != null && prmErroreDescription.Value != null)
			{
				if (prmErroreDescription.Value is SqlString)
					this.ErroreDescription = (SqlString)prmErroreDescription.Value;
				else
				{
					if (prmErroreDescription.Value != DBNull.Value)
						this.ErroreDescription = new SqlString((string)prmErroreDescription.Value);
					else
						this.ErroreDescription = SqlString.Null;
				}
			}

			SqlParameter prmStatoAbbinamento = cmd.Parameters["@StatoAbbinamento"];
			if (prmStatoAbbinamento != null && prmStatoAbbinamento.Value != null)
			{
				if (prmStatoAbbinamento.Value is SqlString)
					this.StatoAbbinamento = (SqlString)prmStatoAbbinamento.Value;
				else
				{
					if (prmStatoAbbinamento.Value != DBNull.Value)
						this.StatoAbbinamento = new SqlString((string)prmStatoAbbinamento.Value);
					else
						this.StatoAbbinamento = SqlString.Null;
				}
			}

			SqlParameter prmDataElaborazione = cmd.Parameters["@DataElaborazione"];
			if (prmDataElaborazione != null && prmDataElaborazione.Value != null)
			{
				if (prmDataElaborazione.Value is SqlDateTime)
					this.DataElaborazione = (SqlDateTime)prmDataElaborazione.Value;
				else
				{
					if (prmDataElaborazione.Value != DBNull.Value)
						this.DataElaborazione = new SqlDateTime((DateTime)prmDataElaborazione.Value);
					else
						this.DataElaborazione = SqlDateTime.Null;
				}
			}

			SqlParameter prmNomeContratto = cmd.Parameters["@NomeContratto"];
			if (prmNomeContratto != null && prmNomeContratto.Value != null)
			{
				if (prmNomeContratto.Value is SqlString)
					this.NomeContratto = (SqlString)prmNomeContratto.Value;
				else
				{
					if (prmNomeContratto.Value != DBNull.Value)
						this.NomeContratto = new SqlString((string)prmNomeContratto.Value);
					else
						this.NomeContratto = SqlString.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlInt32 IdOfferta,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				SqlInt32 QtyRichiesta,
				SqlDouble PrezzoUnitario,
				SqlString NoteOfferta,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlString StatoAbbinamento,
				ref SqlDateTime DataElaborazione,
				ref SqlString NomeContratto)
		{
			Offerta_Modifica runner = new Offerta_Modifica();
			runner.IdOfferta = IdOfferta;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.QtyRichiesta = QtyRichiesta;
			runner.PrezzoUnitario = PrezzoUnitario;
			runner.NoteOfferta = NoteOfferta;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.StatoAbbinamento = StatoAbbinamento;
			runner.DataElaborazione = DataElaborazione;
			runner.NomeContratto = NomeContratto;

			runner.Execute(cn);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			StatoAbbinamento = runner.StatoAbbinamento;
			DataElaborazione = runner.DataElaborazione;
			NomeContratto = runner.NomeContratto;

		}

		public static void Execute(
				SqlTransaction tr,
				SqlInt32 IdOfferta,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				SqlInt32 QtyRichiesta,
				SqlDouble PrezzoUnitario,
				SqlString NoteOfferta,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlString StatoAbbinamento,
				ref SqlDateTime DataElaborazione,
				ref SqlString NomeContratto)
		{
			Offerta_Modifica runner = new Offerta_Modifica();
			runner.IdOfferta = IdOfferta;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.QtyRichiesta = QtyRichiesta;
			runner.PrezzoUnitario = PrezzoUnitario;
			runner.NoteOfferta = NoteOfferta;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.StatoAbbinamento = StatoAbbinamento;
			runner.DataElaborazione = DataElaborazione;
			runner.NomeContratto = NomeContratto;

			runner.Execute(tr.Connection, tr);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			StatoAbbinamento = runner.StatoAbbinamento;
			DataElaborazione = runner.DataElaborazione;
			NomeContratto = runner.NomeContratto;
		}

		#endregion

	}
	public class Offerta_Nascondi
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlInt32 _IdOfferta = SqlInt32.Null;
		protected bool _IdOffertaSet = false;
		protected SqlString _CodiceOperatore = SqlString.Null;
		protected bool _CodiceOperatoreSet = false;
		protected SqlString _CodiceUtente = SqlString.Null;
		protected bool _CodiceUtenteSet = false;
		protected SqlString _NoteOfferta = SqlString.Null;
		protected bool _NoteOffertaSet = false;
		protected SqlString _ErroreCode = SqlString.Null;
		protected bool _ErroreCodeSet = false;
		protected SqlString _ErroreDescription = SqlString.Null;
		protected bool _ErroreDescriptionSet = false;
		protected SqlDateTime _DataElaborazione = SqlDateTime.Null;
		protected bool _DataElaborazioneSet = false;
		protected SqlString _NomeContratto = SqlString.Null;
		protected bool _NomeContrattoSet = false;
		#endregion

		#region Public Properties

		public SqlInt32 IdOfferta
		{
			get { return _IdOfferta; }
			set 
			{
				_IdOfferta = value;
				_IdOffertaSet = true;
			}
		}

		public SqlString CodiceOperatore
		{
			get { return _CodiceOperatore; }
			set 
			{
				_CodiceOperatore = value;
				_CodiceOperatoreSet = true;
			}
		}

		public SqlString CodiceUtente
		{
			get { return _CodiceUtente; }
			set 
			{
				_CodiceUtente = value;
				_CodiceUtenteSet = true;
			}
		}

		public SqlString NoteOfferta
		{
			get { return _NoteOfferta; }
			set 
			{
				_NoteOfferta = value;
				_NoteOffertaSet = true;
			}
		}

		public SqlString ErroreCode
		{
			get { return _ErroreCode; }
			set 
			{
				_ErroreCode = value;
				_ErroreCodeSet = true;
			}
		}

		public SqlString ErroreDescription
		{
			get { return _ErroreDescription; }
			set 
			{
				_ErroreDescription = value;
				_ErroreDescriptionSet = true;
			}
		}

		public SqlDateTime DataElaborazione
		{
			get { return _DataElaborazione; }
			set 
			{
				_DataElaborazione = value;
				_DataElaborazioneSet = true;
			}
		}

		public SqlString NomeContratto
		{
			get { return _NomeContratto; }
			set 
			{
				_NomeContratto = value;
				_NomeContrattoSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[Offerta_Nascondi]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmIdOfferta = cmd.Parameters.Add("@IdOfferta", SqlDbType.Int);
			prmIdOfferta.IsNullable = true;
			prmIdOfferta.Direction = ParameterDirection.Input;
			if (this._IdOffertaSet == true)
				prmIdOfferta.Value = this.IdOfferta;

			SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
			prmCodiceOperatore.IsNullable = true;
			prmCodiceOperatore.Size = 8;
			prmCodiceOperatore.Direction = ParameterDirection.Input;
			if (this._CodiceOperatoreSet == true)
				prmCodiceOperatore.Value = this.CodiceOperatore;

			SqlParameter prmCodiceUtente = cmd.Parameters.Add("@CodiceUtente", SqlDbType.VarChar);
			prmCodiceUtente.IsNullable = true;
			prmCodiceUtente.Size = 8;
			prmCodiceUtente.Direction = ParameterDirection.Input;
			if (this._CodiceUtenteSet == true)
				prmCodiceUtente.Value = this.CodiceUtente;

			SqlParameter prmNoteOfferta = cmd.Parameters.Add("@NoteOfferta", SqlDbType.NVarChar);
			prmNoteOfferta.IsNullable = true;
			prmNoteOfferta.Size = 80;
			prmNoteOfferta.Direction = ParameterDirection.Input;
			if (this._NoteOffertaSet == true)
				prmNoteOfferta.Value = this.NoteOfferta;

			SqlParameter prmErroreCode = cmd.Parameters.Add("@ErroreCode", SqlDbType.VarChar);
			prmErroreCode.IsNullable = true;
			prmErroreCode.Size = 5;
			if (this._ErroreCodeSet)
				prmErroreCode.Direction = ParameterDirection.InputOutput;
			else
				prmErroreCode.Direction = ParameterDirection.Output;
			if (this._ErroreCodeSet)
				prmErroreCode.Value = this.ErroreCode;

			SqlParameter prmErroreDescription = cmd.Parameters.Add("@ErroreDescription", SqlDbType.VarChar);
			prmErroreDescription.IsNullable = true;
			prmErroreDescription.Size = 256;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Direction = ParameterDirection.InputOutput;
			else
				prmErroreDescription.Direction = ParameterDirection.Output;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Value = this.ErroreDescription;

			SqlParameter prmDataElaborazione = cmd.Parameters.Add("@DataElaborazione", SqlDbType.DateTime);
			prmDataElaborazione.IsNullable = true;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Direction = ParameterDirection.InputOutput;
			else
				prmDataElaborazione.Direction = ParameterDirection.Output;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Value = this.DataElaborazione;

			SqlParameter prmNomeContratto = cmd.Parameters.Add("@NomeContratto", SqlDbType.NVarChar);
			prmNomeContratto.IsNullable = true;
			prmNomeContratto.Size = 30;
			if (this._NomeContrattoSet)
				prmNomeContratto.Direction = ParameterDirection.InputOutput;
			else
				prmNomeContratto.Direction = ParameterDirection.Output;
			if (this._NomeContrattoSet)
				prmNomeContratto.Value = this.NomeContratto;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmErroreCode = cmd.Parameters["@ErroreCode"];
			if (prmErroreCode != null && prmErroreCode.Value != null)
			{
				if (prmErroreCode.Value is SqlString)
					this.ErroreCode = (SqlString)prmErroreCode.Value;
				else
				{
					if (prmErroreCode.Value != DBNull.Value)
						this.ErroreCode = new SqlString((string)prmErroreCode.Value);
					else
						this.ErroreCode = SqlString.Null;
				}
			}

			SqlParameter prmErroreDescription = cmd.Parameters["@ErroreDescription"];
			if (prmErroreDescription != null && prmErroreDescription.Value != null)
			{
				if (prmErroreDescription.Value is SqlString)
					this.ErroreDescription = (SqlString)prmErroreDescription.Value;
				else
				{
					if (prmErroreDescription.Value != DBNull.Value)
						this.ErroreDescription = new SqlString((string)prmErroreDescription.Value);
					else
						this.ErroreDescription = SqlString.Null;
				}
			}

			SqlParameter prmDataElaborazione = cmd.Parameters["@DataElaborazione"];
			if (prmDataElaborazione != null && prmDataElaborazione.Value != null)
			{
				if (prmDataElaborazione.Value is SqlDateTime)
					this.DataElaborazione = (SqlDateTime)prmDataElaborazione.Value;
				else
				{
					if (prmDataElaborazione.Value != DBNull.Value)
						this.DataElaborazione = new SqlDateTime((DateTime)prmDataElaborazione.Value);
					else
						this.DataElaborazione = SqlDateTime.Null;
				}
			}

			SqlParameter prmNomeContratto = cmd.Parameters["@NomeContratto"];
			if (prmNomeContratto != null && prmNomeContratto.Value != null)
			{
				if (prmNomeContratto.Value is SqlString)
					this.NomeContratto = (SqlString)prmNomeContratto.Value;
				else
				{
					if (prmNomeContratto.Value != DBNull.Value)
						this.NomeContratto = new SqlString((string)prmNomeContratto.Value);
					else
						this.NomeContratto = SqlString.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlInt32 IdOfferta,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				SqlString NoteOfferta,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlDateTime DataElaborazione,
				ref SqlString NomeContratto)
		{
			Offerta_Nascondi runner = new Offerta_Nascondi();
			runner.IdOfferta = IdOfferta;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.NoteOfferta = NoteOfferta;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.DataElaborazione = DataElaborazione;
			runner.NomeContratto = NomeContratto;

			runner.Execute(cn);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			DataElaborazione = runner.DataElaborazione;
			NomeContratto = runner.NomeContratto;

		}

		public static void Execute(
				SqlTransaction tr,
				SqlInt32 IdOfferta,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				SqlString NoteOfferta,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlDateTime DataElaborazione,
				ref SqlString NomeContratto)
		{
			Offerta_Nascondi runner = new Offerta_Nascondi();
			runner.IdOfferta = IdOfferta;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.NoteOfferta = NoteOfferta;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.DataElaborazione = DataElaborazione;
			runner.NomeContratto = NomeContratto;

			runner.Execute(tr.Connection, tr);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			DataElaborazione = runner.DataElaborazione;
			NomeContratto = runner.NomeContratto;
		}

		#endregion

	}
	public class Offerta_Nuova
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlString _Contratto = SqlString.Null;
		protected bool _ContrattoSet = false;
		protected SqlString _TipoOfferta = SqlString.Null;
		protected bool _TipoOffertaSet = false;
		protected SqlInt32 _QtyRichiesta = SqlInt32.Null;
		protected bool _QtyRichiestaSet = false;
		protected SqlDouble _PrezzoUnitario = SqlDouble.Null;
		protected bool _PrezzoUnitarioSet = false;
		protected SqlString _NoteOfferta = SqlString.Null;
		protected bool _NoteOffertaSet = false;
		protected SqlString _OperatoreOTC = SqlString.Null;
		protected bool _OperatoreOTCSet = false;
		protected SqlString _CodiceOTC = SqlString.Null;
		protected bool _CodiceOTCSet = false;
		protected SqlString _CodiceOperatore = SqlString.Null;
		protected bool _CodiceOperatoreSet = false;
		protected SqlString _CodiceUtente = SqlString.Null;
		protected bool _CodiceUtenteSet = false;
		protected SqlString _ErroreCode = SqlString.Null;
		protected bool _ErroreCodeSet = false;
		protected SqlString _ErroreDescription = SqlString.Null;
		protected bool _ErroreDescriptionSet = false;
		protected SqlString _StatoAbbinamento = SqlString.Null;
		protected bool _StatoAbbinamentoSet = false;
		protected SqlInt32 _IdNuovaOfferta = SqlInt32.Null;
		protected bool _IdNuovaOffertaSet = false;
		protected SqlDateTime _DataElaborazione = SqlDateTime.Null;
		protected bool _DataElaborazioneSet = false;
		#endregion

		#region Public Properties

		public SqlString Contratto
		{
			get { return _Contratto; }
			set 
			{
				_Contratto = value;
				_ContrattoSet = true;
			}
		}

		public SqlString TipoOfferta
		{
			get { return _TipoOfferta; }
			set 
			{
				_TipoOfferta = value;
				_TipoOffertaSet = true;
			}
		}

		public SqlInt32 QtyRichiesta
		{
			get { return _QtyRichiesta; }
			set 
			{
				_QtyRichiesta = value;
				_QtyRichiestaSet = true;
			}
		}

		public SqlDouble PrezzoUnitario
		{
			get { return _PrezzoUnitario; }
			set 
			{
				_PrezzoUnitario = value;
				_PrezzoUnitarioSet = true;
			}
		}

		public SqlString NoteOfferta
		{
			get { return _NoteOfferta; }
			set 
			{
				_NoteOfferta = value;
				_NoteOffertaSet = true;
			}
		}

		public SqlString OperatoreOTC
		{
			get { return _OperatoreOTC; }
			set 
			{
				_OperatoreOTC = value;
				_OperatoreOTCSet = true;
			}
		}

		public SqlString CodiceOTC
		{
			get { return _CodiceOTC; }
			set 
			{
				_CodiceOTC = value;
				_CodiceOTCSet = true;
			}
		}

		public SqlString CodiceOperatore
		{
			get { return _CodiceOperatore; }
			set 
			{
				_CodiceOperatore = value;
				_CodiceOperatoreSet = true;
			}
		}

		public SqlString CodiceUtente
		{
			get { return _CodiceUtente; }
			set 
			{
				_CodiceUtente = value;
				_CodiceUtenteSet = true;
			}
		}

		public SqlString ErroreCode
		{
			get { return _ErroreCode; }
			set 
			{
				_ErroreCode = value;
				_ErroreCodeSet = true;
			}
		}

		public SqlString ErroreDescription
		{
			get { return _ErroreDescription; }
			set 
			{
				_ErroreDescription = value;
				_ErroreDescriptionSet = true;
			}
		}

		public SqlString StatoAbbinamento
		{
			get { return _StatoAbbinamento; }
			set 
			{
				_StatoAbbinamento = value;
				_StatoAbbinamentoSet = true;
			}
		}

		public SqlInt32 IdNuovaOfferta
		{
			get { return _IdNuovaOfferta; }
			set 
			{
				_IdNuovaOfferta = value;
				_IdNuovaOffertaSet = true;
			}
		}

		public SqlDateTime DataElaborazione
		{
			get { return _DataElaborazione; }
			set 
			{
				_DataElaborazione = value;
				_DataElaborazioneSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[Offerta_Nuova]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmContratto = cmd.Parameters.Add("@Contratto", SqlDbType.NVarChar);
			prmContratto.IsNullable = true;
			prmContratto.Size = 30;
			prmContratto.Direction = ParameterDirection.Input;
			if (this._ContrattoSet == true)
				prmContratto.Value = this.Contratto;

			SqlParameter prmTipoOfferta = cmd.Parameters.Add("@TipoOfferta", SqlDbType.Char);
			prmTipoOfferta.IsNullable = true;
			prmTipoOfferta.Size = 1;
			prmTipoOfferta.Direction = ParameterDirection.Input;
			if (this._TipoOffertaSet == true)
				prmTipoOfferta.Value = this.TipoOfferta;

			SqlParameter prmQtyRichiesta = cmd.Parameters.Add("@QtyRichiesta", SqlDbType.Int);
			prmQtyRichiesta.IsNullable = true;
			prmQtyRichiesta.Direction = ParameterDirection.Input;
			if (this._QtyRichiestaSet == true)
				prmQtyRichiesta.Value = this.QtyRichiesta;

			SqlParameter prmPrezzoUnitario = cmd.Parameters.Add("@PrezzoUnitario", SqlDbType.Float);
			prmPrezzoUnitario.IsNullable = true;
			prmPrezzoUnitario.Direction = ParameterDirection.Input;
			if (this._PrezzoUnitarioSet == true)
				prmPrezzoUnitario.Value = this.PrezzoUnitario;

			SqlParameter prmNoteOfferta = cmd.Parameters.Add("@NoteOfferta", SqlDbType.NVarChar);
			prmNoteOfferta.IsNullable = true;
			prmNoteOfferta.Size = 80;
			prmNoteOfferta.Direction = ParameterDirection.Input;
			if (this._NoteOffertaSet == true)
				prmNoteOfferta.Value = this.NoteOfferta;

			SqlParameter prmOperatoreOTC = cmd.Parameters.Add("@OperatoreOTC", SqlDbType.VarChar);
			prmOperatoreOTC.IsNullable = true;
			prmOperatoreOTC.Size = 8;
			prmOperatoreOTC.Direction = ParameterDirection.Input;
			if (this._OperatoreOTCSet == true)
				prmOperatoreOTC.Value = this.OperatoreOTC;

			SqlParameter prmCodiceOTC = cmd.Parameters.Add("@CodiceOTC", SqlDbType.VarChar);
			prmCodiceOTC.IsNullable = true;
			prmCodiceOTC.Size = 32;
			prmCodiceOTC.Direction = ParameterDirection.Input;
			if (this._CodiceOTCSet == true)
				prmCodiceOTC.Value = this.CodiceOTC;

			SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
			prmCodiceOperatore.IsNullable = true;
			prmCodiceOperatore.Size = 8;
			prmCodiceOperatore.Direction = ParameterDirection.Input;
			if (this._CodiceOperatoreSet == true)
				prmCodiceOperatore.Value = this.CodiceOperatore;

			SqlParameter prmCodiceUtente = cmd.Parameters.Add("@CodiceUtente", SqlDbType.VarChar);
			prmCodiceUtente.IsNullable = true;
			prmCodiceUtente.Size = 8;
			prmCodiceUtente.Direction = ParameterDirection.Input;
			if (this._CodiceUtenteSet == true)
				prmCodiceUtente.Value = this.CodiceUtente;

			SqlParameter prmErroreCode = cmd.Parameters.Add("@ErroreCode", SqlDbType.VarChar);
			prmErroreCode.IsNullable = true;
			prmErroreCode.Size = 5;
			if (this._ErroreCodeSet)
				prmErroreCode.Direction = ParameterDirection.InputOutput;
			else
				prmErroreCode.Direction = ParameterDirection.Output;
			if (this._ErroreCodeSet)
				prmErroreCode.Value = this.ErroreCode;

			SqlParameter prmErroreDescription = cmd.Parameters.Add("@ErroreDescription", SqlDbType.VarChar);
			prmErroreDescription.IsNullable = true;
			prmErroreDescription.Size = 256;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Direction = ParameterDirection.InputOutput;
			else
				prmErroreDescription.Direction = ParameterDirection.Output;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Value = this.ErroreDescription;

			SqlParameter prmStatoAbbinamento = cmd.Parameters.Add("@StatoAbbinamento", SqlDbType.VarChar);
			prmStatoAbbinamento.IsNullable = true;
			prmStatoAbbinamento.Size = 2;
			if (this._StatoAbbinamentoSet)
				prmStatoAbbinamento.Direction = ParameterDirection.InputOutput;
			else
				prmStatoAbbinamento.Direction = ParameterDirection.Output;
			if (this._StatoAbbinamentoSet)
				prmStatoAbbinamento.Value = this.StatoAbbinamento;

			SqlParameter prmIdNuovaOfferta = cmd.Parameters.Add("@IdNuovaOfferta", SqlDbType.Int);
			prmIdNuovaOfferta.IsNullable = true;
			if (this._IdNuovaOffertaSet)
				prmIdNuovaOfferta.Direction = ParameterDirection.InputOutput;
			else
				prmIdNuovaOfferta.Direction = ParameterDirection.Output;
			if (this._IdNuovaOffertaSet)
				prmIdNuovaOfferta.Value = this.IdNuovaOfferta;

			SqlParameter prmDataElaborazione = cmd.Parameters.Add("@DataElaborazione", SqlDbType.DateTime);
			prmDataElaborazione.IsNullable = true;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Direction = ParameterDirection.InputOutput;
			else
				prmDataElaborazione.Direction = ParameterDirection.Output;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Value = this.DataElaborazione;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmErroreCode = cmd.Parameters["@ErroreCode"];
			if (prmErroreCode != null && prmErroreCode.Value != null)
			{
				if (prmErroreCode.Value is SqlString)
					this.ErroreCode = (SqlString)prmErroreCode.Value;
				else
				{
					if (prmErroreCode.Value != DBNull.Value)
						this.ErroreCode = new SqlString((string)prmErroreCode.Value);
					else
						this.ErroreCode = SqlString.Null;
				}
			}

			SqlParameter prmErroreDescription = cmd.Parameters["@ErroreDescription"];
			if (prmErroreDescription != null && prmErroreDescription.Value != null)
			{
				if (prmErroreDescription.Value is SqlString)
					this.ErroreDescription = (SqlString)prmErroreDescription.Value;
				else
				{
					if (prmErroreDescription.Value != DBNull.Value)
						this.ErroreDescription = new SqlString((string)prmErroreDescription.Value);
					else
						this.ErroreDescription = SqlString.Null;
				}
			}

			SqlParameter prmStatoAbbinamento = cmd.Parameters["@StatoAbbinamento"];
			if (prmStatoAbbinamento != null && prmStatoAbbinamento.Value != null)
			{
				if (prmStatoAbbinamento.Value is SqlString)
					this.StatoAbbinamento = (SqlString)prmStatoAbbinamento.Value;
				else
				{
					if (prmStatoAbbinamento.Value != DBNull.Value)
						this.StatoAbbinamento = new SqlString((string)prmStatoAbbinamento.Value);
					else
						this.StatoAbbinamento = SqlString.Null;
				}
			}

			SqlParameter prmIdNuovaOfferta = cmd.Parameters["@IdNuovaOfferta"];
			if (prmIdNuovaOfferta != null && prmIdNuovaOfferta.Value != null)
			{
				if (prmIdNuovaOfferta.Value is SqlInt32)
					this.IdNuovaOfferta = (SqlInt32)prmIdNuovaOfferta.Value;
				else
				{
					if (prmIdNuovaOfferta.Value != DBNull.Value)
						this.IdNuovaOfferta = new SqlInt32((int)prmIdNuovaOfferta.Value);
					else
						this.IdNuovaOfferta = SqlInt32.Null;
				}
			}

			SqlParameter prmDataElaborazione = cmd.Parameters["@DataElaborazione"];
			if (prmDataElaborazione != null && prmDataElaborazione.Value != null)
			{
				if (prmDataElaborazione.Value is SqlDateTime)
					this.DataElaborazione = (SqlDateTime)prmDataElaborazione.Value;
				else
				{
					if (prmDataElaborazione.Value != DBNull.Value)
						this.DataElaborazione = new SqlDateTime((DateTime)prmDataElaborazione.Value);
					else
						this.DataElaborazione = SqlDateTime.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlString Contratto,
				SqlString TipoOfferta,
				SqlInt32 QtyRichiesta,
				SqlDouble PrezzoUnitario,
				SqlString NoteOfferta,
				SqlString OperatoreOTC,
				SqlString CodiceOTC,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlString StatoAbbinamento,
				ref SqlInt32 IdNuovaOfferta,
				ref SqlDateTime DataElaborazione)
		{
			Offerta_Nuova runner = new Offerta_Nuova();
			runner.Contratto = Contratto;
			runner.TipoOfferta = TipoOfferta;
			runner.QtyRichiesta = QtyRichiesta;
			runner.PrezzoUnitario = PrezzoUnitario;
			runner.NoteOfferta = NoteOfferta;
			runner.OperatoreOTC = OperatoreOTC;
			runner.CodiceOTC = CodiceOTC;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.StatoAbbinamento = StatoAbbinamento;
			runner.IdNuovaOfferta = IdNuovaOfferta;
			runner.DataElaborazione = DataElaborazione;

			runner.Execute(cn);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			StatoAbbinamento = runner.StatoAbbinamento;
			IdNuovaOfferta = runner.IdNuovaOfferta;
			DataElaborazione = runner.DataElaborazione;

		}

		public static void Execute(
				SqlTransaction tr,
				SqlString Contratto,
				SqlString TipoOfferta,
				SqlInt32 QtyRichiesta,
				SqlDouble PrezzoUnitario,
				SqlString NoteOfferta,
				SqlString OperatoreOTC,
				SqlString CodiceOTC,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlString StatoAbbinamento,
				ref SqlInt32 IdNuovaOfferta,
				ref SqlDateTime DataElaborazione)
		{
			Offerta_Nuova runner = new Offerta_Nuova();
			runner.Contratto = Contratto;
			runner.TipoOfferta = TipoOfferta;
			runner.QtyRichiesta = QtyRichiesta;
			runner.PrezzoUnitario = PrezzoUnitario;
			runner.NoteOfferta = NoteOfferta;
			runner.OperatoreOTC = OperatoreOTC;
			runner.CodiceOTC = CodiceOTC;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.StatoAbbinamento = StatoAbbinamento;
			runner.IdNuovaOfferta = IdNuovaOfferta;
			runner.DataElaborazione = DataElaborazione;

			runner.Execute(tr.Connection, tr);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			StatoAbbinamento = runner.StatoAbbinamento;
			IdNuovaOfferta = runner.IdNuovaOfferta;
			DataElaborazione = runner.DataElaborazione;
		}

		#endregion

	}
	public class Offerta_Revoca
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlInt32 _IdOfferta = SqlInt32.Null;
		protected bool _IdOffertaSet = false;
		protected SqlString _CodiceOperatore = SqlString.Null;
		protected bool _CodiceOperatoreSet = false;
		protected SqlString _CodiceUtente = SqlString.Null;
		protected bool _CodiceUtenteSet = false;
		protected SqlString _NoteOfferta = SqlString.Null;
		protected bool _NoteOffertaSet = false;
		protected SqlString _ErroreCode = SqlString.Null;
		protected bool _ErroreCodeSet = false;
		protected SqlString _ErroreDescription = SqlString.Null;
		protected bool _ErroreDescriptionSet = false;
		protected SqlDateTime _DataElaborazione = SqlDateTime.Null;
		protected bool _DataElaborazioneSet = false;
		protected SqlString _NomeContratto = SqlString.Null;
		protected bool _NomeContrattoSet = false;
		#endregion

		#region Public Properties

		public SqlInt32 IdOfferta
		{
			get { return _IdOfferta; }
			set 
			{
				_IdOfferta = value;
				_IdOffertaSet = true;
			}
		}

		public SqlString CodiceOperatore
		{
			get { return _CodiceOperatore; }
			set 
			{
				_CodiceOperatore = value;
				_CodiceOperatoreSet = true;
			}
		}

		public SqlString CodiceUtente
		{
			get { return _CodiceUtente; }
			set 
			{
				_CodiceUtente = value;
				_CodiceUtenteSet = true;
			}
		}

		public SqlString NoteOfferta
		{
			get { return _NoteOfferta; }
			set 
			{
				_NoteOfferta = value;
				_NoteOffertaSet = true;
			}
		}

		public SqlString ErroreCode
		{
			get { return _ErroreCode; }
			set 
			{
				_ErroreCode = value;
				_ErroreCodeSet = true;
			}
		}

		public SqlString ErroreDescription
		{
			get { return _ErroreDescription; }
			set 
			{
				_ErroreDescription = value;
				_ErroreDescriptionSet = true;
			}
		}

		public SqlDateTime DataElaborazione
		{
			get { return _DataElaborazione; }
			set 
			{
				_DataElaborazione = value;
				_DataElaborazioneSet = true;
			}
		}

		public SqlString NomeContratto
		{
			get { return _NomeContratto; }
			set 
			{
				_NomeContratto = value;
				_NomeContrattoSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[Offerta_Revoca]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmIdOfferta = cmd.Parameters.Add("@IdOfferta", SqlDbType.Int);
			prmIdOfferta.IsNullable = true;
			prmIdOfferta.Direction = ParameterDirection.Input;
			if (this._IdOffertaSet == true)
				prmIdOfferta.Value = this.IdOfferta;

			SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
			prmCodiceOperatore.IsNullable = true;
			prmCodiceOperatore.Size = 8;
			prmCodiceOperatore.Direction = ParameterDirection.Input;
			if (this._CodiceOperatoreSet == true)
				prmCodiceOperatore.Value = this.CodiceOperatore;

			SqlParameter prmCodiceUtente = cmd.Parameters.Add("@CodiceUtente", SqlDbType.VarChar);
			prmCodiceUtente.IsNullable = true;
			prmCodiceUtente.Size = 8;
			prmCodiceUtente.Direction = ParameterDirection.Input;
			if (this._CodiceUtenteSet == true)
				prmCodiceUtente.Value = this.CodiceUtente;

			SqlParameter prmNoteOfferta = cmd.Parameters.Add("@NoteOfferta", SqlDbType.NVarChar);
			prmNoteOfferta.IsNullable = true;
			prmNoteOfferta.Size = 80;
			prmNoteOfferta.Direction = ParameterDirection.Input;
			if (this._NoteOffertaSet == true)
				prmNoteOfferta.Value = this.NoteOfferta;

			SqlParameter prmErroreCode = cmd.Parameters.Add("@ErroreCode", SqlDbType.VarChar);
			prmErroreCode.IsNullable = true;
			prmErroreCode.Size = 5;
			if (this._ErroreCodeSet)
				prmErroreCode.Direction = ParameterDirection.InputOutput;
			else
				prmErroreCode.Direction = ParameterDirection.Output;
			if (this._ErroreCodeSet)
				prmErroreCode.Value = this.ErroreCode;

			SqlParameter prmErroreDescription = cmd.Parameters.Add("@ErroreDescription", SqlDbType.VarChar);
			prmErroreDescription.IsNullable = true;
			prmErroreDescription.Size = 256;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Direction = ParameterDirection.InputOutput;
			else
				prmErroreDescription.Direction = ParameterDirection.Output;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Value = this.ErroreDescription;

			SqlParameter prmDataElaborazione = cmd.Parameters.Add("@DataElaborazione", SqlDbType.DateTime);
			prmDataElaborazione.IsNullable = true;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Direction = ParameterDirection.InputOutput;
			else
				prmDataElaborazione.Direction = ParameterDirection.Output;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Value = this.DataElaborazione;

			SqlParameter prmNomeContratto = cmd.Parameters.Add("@NomeContratto", SqlDbType.NVarChar);
			prmNomeContratto.IsNullable = true;
			prmNomeContratto.Size = 30;
			if (this._NomeContrattoSet)
				prmNomeContratto.Direction = ParameterDirection.InputOutput;
			else
				prmNomeContratto.Direction = ParameterDirection.Output;
			if (this._NomeContrattoSet)
				prmNomeContratto.Value = this.NomeContratto;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmErroreCode = cmd.Parameters["@ErroreCode"];
			if (prmErroreCode != null && prmErroreCode.Value != null)
			{
				if (prmErroreCode.Value is SqlString)
					this.ErroreCode = (SqlString)prmErroreCode.Value;
				else
				{
					if (prmErroreCode.Value != DBNull.Value)
						this.ErroreCode = new SqlString((string)prmErroreCode.Value);
					else
						this.ErroreCode = SqlString.Null;
				}
			}

			SqlParameter prmErroreDescription = cmd.Parameters["@ErroreDescription"];
			if (prmErroreDescription != null && prmErroreDescription.Value != null)
			{
				if (prmErroreDescription.Value is SqlString)
					this.ErroreDescription = (SqlString)prmErroreDescription.Value;
				else
				{
					if (prmErroreDescription.Value != DBNull.Value)
						this.ErroreDescription = new SqlString((string)prmErroreDescription.Value);
					else
						this.ErroreDescription = SqlString.Null;
				}
			}

			SqlParameter prmDataElaborazione = cmd.Parameters["@DataElaborazione"];
			if (prmDataElaborazione != null && prmDataElaborazione.Value != null)
			{
				if (prmDataElaborazione.Value is SqlDateTime)
					this.DataElaborazione = (SqlDateTime)prmDataElaborazione.Value;
				else
				{
					if (prmDataElaborazione.Value != DBNull.Value)
						this.DataElaborazione = new SqlDateTime((DateTime)prmDataElaborazione.Value);
					else
						this.DataElaborazione = SqlDateTime.Null;
				}
			}

			SqlParameter prmNomeContratto = cmd.Parameters["@NomeContratto"];
			if (prmNomeContratto != null && prmNomeContratto.Value != null)
			{
				if (prmNomeContratto.Value is SqlString)
					this.NomeContratto = (SqlString)prmNomeContratto.Value;
				else
				{
					if (prmNomeContratto.Value != DBNull.Value)
						this.NomeContratto = new SqlString((string)prmNomeContratto.Value);
					else
						this.NomeContratto = SqlString.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlInt32 IdOfferta,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				SqlString NoteOfferta,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlDateTime DataElaborazione,
				ref SqlString NomeContratto)
		{
			Offerta_Revoca runner = new Offerta_Revoca();
			runner.IdOfferta = IdOfferta;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.NoteOfferta = NoteOfferta;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.DataElaborazione = DataElaborazione;
			runner.NomeContratto = NomeContratto;

			runner.Execute(cn);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			DataElaborazione = runner.DataElaborazione;
			NomeContratto = runner.NomeContratto;

		}

		public static void Execute(
				SqlTransaction tr,
				SqlInt32 IdOfferta,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				SqlString NoteOfferta,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlDateTime DataElaborazione,
				ref SqlString NomeContratto)
		{
			Offerta_Revoca runner = new Offerta_Revoca();
			runner.IdOfferta = IdOfferta;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.NoteOfferta = NoteOfferta;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.DataElaborazione = DataElaborazione;
			runner.NomeContratto = NomeContratto;

			runner.Execute(tr.Connection, tr);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			DataElaborazione = runner.DataElaborazione;
			NomeContratto = runner.NomeContratto;
		}

		#endregion

	}
	public class Offerta_Rivela
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlInt32 _IdOfferta = SqlInt32.Null;
		protected bool _IdOffertaSet = false;
		protected SqlString _CodiceOperatore = SqlString.Null;
		protected bool _CodiceOperatoreSet = false;
		protected SqlString _CodiceUtente = SqlString.Null;
		protected bool _CodiceUtenteSet = false;
		protected SqlString _NoteOfferta = SqlString.Null;
		protected bool _NoteOffertaSet = false;
		protected SqlString _ErroreCode = SqlString.Null;
		protected bool _ErroreCodeSet = false;
		protected SqlString _ErroreDescription = SqlString.Null;
		protected bool _ErroreDescriptionSet = false;
		protected SqlString _StatoAbbinamento = SqlString.Null;
		protected bool _StatoAbbinamentoSet = false;
		protected SqlDateTime _DataElaborazione = SqlDateTime.Null;
		protected bool _DataElaborazioneSet = false;
		protected SqlString _NomeContratto = SqlString.Null;
		protected bool _NomeContrattoSet = false;
		#endregion

		#region Public Properties

		public SqlInt32 IdOfferta
		{
			get { return _IdOfferta; }
			set 
			{
				_IdOfferta = value;
				_IdOffertaSet = true;
			}
		}

		public SqlString CodiceOperatore
		{
			get { return _CodiceOperatore; }
			set 
			{
				_CodiceOperatore = value;
				_CodiceOperatoreSet = true;
			}
		}

		public SqlString CodiceUtente
		{
			get { return _CodiceUtente; }
			set 
			{
				_CodiceUtente = value;
				_CodiceUtenteSet = true;
			}
		}

		public SqlString NoteOfferta
		{
			get { return _NoteOfferta; }
			set 
			{
				_NoteOfferta = value;
				_NoteOffertaSet = true;
			}
		}

		public SqlString ErroreCode
		{
			get { return _ErroreCode; }
			set 
			{
				_ErroreCode = value;
				_ErroreCodeSet = true;
			}
		}

		public SqlString ErroreDescription
		{
			get { return _ErroreDescription; }
			set 
			{
				_ErroreDescription = value;
				_ErroreDescriptionSet = true;
			}
		}

		public SqlString StatoAbbinamento
		{
			get { return _StatoAbbinamento; }
			set 
			{
				_StatoAbbinamento = value;
				_StatoAbbinamentoSet = true;
			}
		}

		public SqlDateTime DataElaborazione
		{
			get { return _DataElaborazione; }
			set 
			{
				_DataElaborazione = value;
				_DataElaborazioneSet = true;
			}
		}

		public SqlString NomeContratto
		{
			get { return _NomeContratto; }
			set 
			{
				_NomeContratto = value;
				_NomeContrattoSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[Offerta_Rivela]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmIdOfferta = cmd.Parameters.Add("@IdOfferta", SqlDbType.Int);
			prmIdOfferta.IsNullable = true;
			prmIdOfferta.Direction = ParameterDirection.Input;
			if (this._IdOffertaSet == true)
				prmIdOfferta.Value = this.IdOfferta;

			SqlParameter prmCodiceOperatore = cmd.Parameters.Add("@CodiceOperatore", SqlDbType.VarChar);
			prmCodiceOperatore.IsNullable = true;
			prmCodiceOperatore.Size = 8;
			prmCodiceOperatore.Direction = ParameterDirection.Input;
			if (this._CodiceOperatoreSet == true)
				prmCodiceOperatore.Value = this.CodiceOperatore;

			SqlParameter prmCodiceUtente = cmd.Parameters.Add("@CodiceUtente", SqlDbType.VarChar);
			prmCodiceUtente.IsNullable = true;
			prmCodiceUtente.Size = 8;
			prmCodiceUtente.Direction = ParameterDirection.Input;
			if (this._CodiceUtenteSet == true)
				prmCodiceUtente.Value = this.CodiceUtente;

			SqlParameter prmNoteOfferta = cmd.Parameters.Add("@NoteOfferta", SqlDbType.NVarChar);
			prmNoteOfferta.IsNullable = true;
			prmNoteOfferta.Size = 80;
			prmNoteOfferta.Direction = ParameterDirection.Input;
			if (this._NoteOffertaSet == true)
				prmNoteOfferta.Value = this.NoteOfferta;

			SqlParameter prmErroreCode = cmd.Parameters.Add("@ErroreCode", SqlDbType.VarChar);
			prmErroreCode.IsNullable = true;
			prmErroreCode.Size = 5;
			if (this._ErroreCodeSet)
				prmErroreCode.Direction = ParameterDirection.InputOutput;
			else
				prmErroreCode.Direction = ParameterDirection.Output;
			if (this._ErroreCodeSet)
				prmErroreCode.Value = this.ErroreCode;

			SqlParameter prmErroreDescription = cmd.Parameters.Add("@ErroreDescription", SqlDbType.VarChar);
			prmErroreDescription.IsNullable = true;
			prmErroreDescription.Size = 256;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Direction = ParameterDirection.InputOutput;
			else
				prmErroreDescription.Direction = ParameterDirection.Output;
			if (this._ErroreDescriptionSet)
				prmErroreDescription.Value = this.ErroreDescription;

			SqlParameter prmStatoAbbinamento = cmd.Parameters.Add("@StatoAbbinamento", SqlDbType.VarChar);
			prmStatoAbbinamento.IsNullable = true;
			prmStatoAbbinamento.Size = 2;
			if (this._StatoAbbinamentoSet)
				prmStatoAbbinamento.Direction = ParameterDirection.InputOutput;
			else
				prmStatoAbbinamento.Direction = ParameterDirection.Output;
			if (this._StatoAbbinamentoSet)
				prmStatoAbbinamento.Value = this.StatoAbbinamento;

			SqlParameter prmDataElaborazione = cmd.Parameters.Add("@DataElaborazione", SqlDbType.DateTime);
			prmDataElaborazione.IsNullable = true;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Direction = ParameterDirection.InputOutput;
			else
				prmDataElaborazione.Direction = ParameterDirection.Output;
			if (this._DataElaborazioneSet)
				prmDataElaborazione.Value = this.DataElaborazione;

			SqlParameter prmNomeContratto = cmd.Parameters.Add("@NomeContratto", SqlDbType.NVarChar);
			prmNomeContratto.IsNullable = true;
			prmNomeContratto.Size = 30;
			if (this._NomeContrattoSet)
				prmNomeContratto.Direction = ParameterDirection.InputOutput;
			else
				prmNomeContratto.Direction = ParameterDirection.Output;
			if (this._NomeContrattoSet)
				prmNomeContratto.Value = this.NomeContratto;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmErroreCode = cmd.Parameters["@ErroreCode"];
			if (prmErroreCode != null && prmErroreCode.Value != null)
			{
				if (prmErroreCode.Value is SqlString)
					this.ErroreCode = (SqlString)prmErroreCode.Value;
				else
				{
					if (prmErroreCode.Value != DBNull.Value)
						this.ErroreCode = new SqlString((string)prmErroreCode.Value);
					else
						this.ErroreCode = SqlString.Null;
				}
			}

			SqlParameter prmErroreDescription = cmd.Parameters["@ErroreDescription"];
			if (prmErroreDescription != null && prmErroreDescription.Value != null)
			{
				if (prmErroreDescription.Value is SqlString)
					this.ErroreDescription = (SqlString)prmErroreDescription.Value;
				else
				{
					if (prmErroreDescription.Value != DBNull.Value)
						this.ErroreDescription = new SqlString((string)prmErroreDescription.Value);
					else
						this.ErroreDescription = SqlString.Null;
				}
			}

			SqlParameter prmStatoAbbinamento = cmd.Parameters["@StatoAbbinamento"];
			if (prmStatoAbbinamento != null && prmStatoAbbinamento.Value != null)
			{
				if (prmStatoAbbinamento.Value is SqlString)
					this.StatoAbbinamento = (SqlString)prmStatoAbbinamento.Value;
				else
				{
					if (prmStatoAbbinamento.Value != DBNull.Value)
						this.StatoAbbinamento = new SqlString((string)prmStatoAbbinamento.Value);
					else
						this.StatoAbbinamento = SqlString.Null;
				}
			}

			SqlParameter prmDataElaborazione = cmd.Parameters["@DataElaborazione"];
			if (prmDataElaborazione != null && prmDataElaborazione.Value != null)
			{
				if (prmDataElaborazione.Value is SqlDateTime)
					this.DataElaborazione = (SqlDateTime)prmDataElaborazione.Value;
				else
				{
					if (prmDataElaborazione.Value != DBNull.Value)
						this.DataElaborazione = new SqlDateTime((DateTime)prmDataElaborazione.Value);
					else
						this.DataElaborazione = SqlDateTime.Null;
				}
			}

			SqlParameter prmNomeContratto = cmd.Parameters["@NomeContratto"];
			if (prmNomeContratto != null && prmNomeContratto.Value != null)
			{
				if (prmNomeContratto.Value is SqlString)
					this.NomeContratto = (SqlString)prmNomeContratto.Value;
				else
				{
					if (prmNomeContratto.Value != DBNull.Value)
						this.NomeContratto = new SqlString((string)prmNomeContratto.Value);
					else
						this.NomeContratto = SqlString.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlInt32 IdOfferta,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				SqlString NoteOfferta,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlString StatoAbbinamento,
				ref SqlDateTime DataElaborazione,
				ref SqlString NomeContratto)
		{
			Offerta_Rivela runner = new Offerta_Rivela();
			runner.IdOfferta = IdOfferta;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.NoteOfferta = NoteOfferta;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.StatoAbbinamento = StatoAbbinamento;
			runner.DataElaborazione = DataElaborazione;
			runner.NomeContratto = NomeContratto;

			runner.Execute(cn);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			StatoAbbinamento = runner.StatoAbbinamento;
			DataElaborazione = runner.DataElaborazione;
			NomeContratto = runner.NomeContratto;

		}

		public static void Execute(
				SqlTransaction tr,
				SqlInt32 IdOfferta,
				SqlString CodiceOperatore,
				SqlString CodiceUtente,
				SqlString NoteOfferta,
				ref SqlString ErroreCode,
				ref SqlString ErroreDescription,
				ref SqlString StatoAbbinamento,
				ref SqlDateTime DataElaborazione,
				ref SqlString NomeContratto)
		{
			Offerta_Rivela runner = new Offerta_Rivela();
			runner.IdOfferta = IdOfferta;
			runner.CodiceOperatore = CodiceOperatore;
			runner.CodiceUtente = CodiceUtente;
			runner.NoteOfferta = NoteOfferta;
			runner.ErroreCode = ErroreCode;
			runner.ErroreDescription = ErroreDescription;
			runner.StatoAbbinamento = StatoAbbinamento;
			runner.DataElaborazione = DataElaborazione;
			runner.NomeContratto = NomeContratto;

			runner.Execute(tr.Connection, tr);

			ErroreCode = runner.ErroreCode;
			ErroreDescription = runner.ErroreDescription;
			StatoAbbinamento = runner.StatoAbbinamento;
			DataElaborazione = runner.DataElaborazione;
			NomeContratto = runner.NomeContratto;
		}

		#endregion

	}
	public class OraCorrente
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlDateTime _tsNow = SqlDateTime.Null;
		protected bool _tsNowSet = false;
		#endregion

		#region Public Properties

		public SqlDateTime tsNow
		{
			get { return _tsNow; }
			set 
			{
				_tsNow = value;
				_tsNowSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[OraCorrente]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmtsNow = cmd.Parameters.Add("@tsNow", SqlDbType.DateTime);
			prmtsNow.IsNullable = true;
			if (this._tsNowSet)
				prmtsNow.Direction = ParameterDirection.InputOutput;
			else
				prmtsNow.Direction = ParameterDirection.Output;
			if (this._tsNowSet)
				prmtsNow.Value = this.tsNow;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmtsNow = cmd.Parameters["@tsNow"];
			if (prmtsNow != null && prmtsNow.Value != null)
			{
				if (prmtsNow.Value is SqlDateTime)
					this.tsNow = (SqlDateTime)prmtsNow.Value;
				else
				{
					if (prmtsNow.Value != DBNull.Value)
						this.tsNow = new SqlDateTime((DateTime)prmtsNow.Value);
					else
						this.tsNow = SqlDateTime.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				ref SqlDateTime tsNow)
		{
			OraCorrente runner = new OraCorrente();
			runner.tsNow = tsNow;

			runner.Execute(cn);

			tsNow = runner.tsNow;

		}

		public static void Execute(
				SqlTransaction tr,
				ref SqlDateTime tsNow)
		{
			OraCorrente runner = new OraCorrente();
			runner.tsNow = tsNow;

			runner.Execute(tr.Connection, tr);

			tsNow = runner.tsNow;
		}

		#endregion

	}
	public class SessioneCorrente_CambiaStato
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlString _NuovoStato = SqlString.Null;
		protected bool _NuovoStatoSet = false;
		protected SqlInt32 _ProceduraForzata = SqlInt32.Null;
		protected bool _ProceduraForzataSet = false;
		protected SqlInt32 _rc = SqlInt32.Null;
		protected bool _rcSet = false;
		protected SqlString _MsgErrore = SqlString.Null;
		protected bool _MsgErroreSet = false;
		#endregion

		#region Public Properties

		public SqlString NuovoStato
		{
			get { return _NuovoStato; }
			set 
			{
				_NuovoStato = value;
				_NuovoStatoSet = true;
			}
		}

		public SqlInt32 ProceduraForzata
		{
			get { return _ProceduraForzata; }
			set 
			{
				_ProceduraForzata = value;
				_ProceduraForzataSet = true;
			}
		}

		public SqlInt32 rc
		{
			get { return _rc; }
			set 
			{
				_rc = value;
				_rcSet = true;
			}
		}

		public SqlString MsgErrore
		{
			get { return _MsgErrore; }
			set 
			{
				_MsgErrore = value;
				_MsgErroreSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[SessioneCorrente_CambiaStato]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmNuovoStato = cmd.Parameters.Add("@NuovoStato", SqlDbType.VarChar);
			prmNuovoStato.IsNullable = true;
			prmNuovoStato.Size = 16;
			prmNuovoStato.Direction = ParameterDirection.Input;
			if (this._NuovoStatoSet == true)
				prmNuovoStato.Value = this.NuovoStato;

			SqlParameter prmProceduraForzata = cmd.Parameters.Add("@ProceduraForzata", SqlDbType.Int);
			prmProceduraForzata.IsNullable = true;
			prmProceduraForzata.Direction = ParameterDirection.Input;
			if (this._ProceduraForzataSet == true)
				prmProceduraForzata.Value = this.ProceduraForzata;

			SqlParameter prmrc = cmd.Parameters.Add("@rc", SqlDbType.Int);
			prmrc.IsNullable = true;
			if (this._rcSet)
				prmrc.Direction = ParameterDirection.InputOutput;
			else
				prmrc.Direction = ParameterDirection.Output;
			if (this._rcSet)
				prmrc.Value = this.rc;

			SqlParameter prmMsgErrore = cmd.Parameters.Add("@MsgErrore", SqlDbType.VarChar);
			prmMsgErrore.IsNullable = true;
			prmMsgErrore.Size = 80;
			if (this._MsgErroreSet)
				prmMsgErrore.Direction = ParameterDirection.InputOutput;
			else
				prmMsgErrore.Direction = ParameterDirection.Output;
			if (this._MsgErroreSet)
				prmMsgErrore.Value = this.MsgErrore;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmrc = cmd.Parameters["@rc"];
			if (prmrc != null && prmrc.Value != null)
			{
				if (prmrc.Value is SqlInt32)
					this.rc = (SqlInt32)prmrc.Value;
				else
				{
					if (prmrc.Value != DBNull.Value)
						this.rc = new SqlInt32((int)prmrc.Value);
					else
						this.rc = SqlInt32.Null;
				}
			}

			SqlParameter prmMsgErrore = cmd.Parameters["@MsgErrore"];
			if (prmMsgErrore != null && prmMsgErrore.Value != null)
			{
				if (prmMsgErrore.Value is SqlString)
					this.MsgErrore = (SqlString)prmMsgErrore.Value;
				else
				{
					if (prmMsgErrore.Value != DBNull.Value)
						this.MsgErrore = new SqlString((string)prmMsgErrore.Value);
					else
						this.MsgErrore = SqlString.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlString NuovoStato,
				SqlInt32 ProceduraForzata,
				ref SqlInt32 rc,
				ref SqlString MsgErrore)
		{
			SessioneCorrente_CambiaStato runner = new SessioneCorrente_CambiaStato();
			runner.NuovoStato = NuovoStato;
			runner.ProceduraForzata = ProceduraForzata;
			runner.rc = rc;
			runner.MsgErrore = MsgErrore;

			runner.Execute(cn);

			rc = runner.rc;
			MsgErrore = runner.MsgErrore;

		}

		public static void Execute(
				SqlTransaction tr,
				SqlString NuovoStato,
				SqlInt32 ProceduraForzata,
				ref SqlInt32 rc,
				ref SqlString MsgErrore)
		{
			SessioneCorrente_CambiaStato runner = new SessioneCorrente_CambiaStato();
			runner.NuovoStato = NuovoStato;
			runner.ProceduraForzata = ProceduraForzata;
			runner.rc = rc;
			runner.MsgErrore = MsgErrore;

			runner.Execute(tr.Connection, tr);

			rc = runner.rc;
			MsgErrore = runner.MsgErrore;
		}

		#endregion

	}
	public class LeggiParametri
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlInt32 _TimeoutRossoVerde = SqlInt32.Null;
		protected bool _TimeoutRossoVerdeSet = false;
		#endregion

		#region Public Properties

		public SqlInt32 TimeoutRossoVerde
		{
			get { return _TimeoutRossoVerde; }
			set 
			{
				_TimeoutRossoVerde = value;
				_TimeoutRossoVerdeSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[LeggiParametri]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmTimeoutRossoVerde = cmd.Parameters.Add("@TimeoutRossoVerde", SqlDbType.Int);
			prmTimeoutRossoVerde.IsNullable = true;
			if (this._TimeoutRossoVerdeSet)
				prmTimeoutRossoVerde.Direction = ParameterDirection.InputOutput;
			else
				prmTimeoutRossoVerde.Direction = ParameterDirection.Output;
			if (this._TimeoutRossoVerdeSet)
				prmTimeoutRossoVerde.Value = this.TimeoutRossoVerde;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmTimeoutRossoVerde = cmd.Parameters["@TimeoutRossoVerde"];
			if (prmTimeoutRossoVerde != null && prmTimeoutRossoVerde.Value != null)
			{
				if (prmTimeoutRossoVerde.Value is SqlInt32)
					this.TimeoutRossoVerde = (SqlInt32)prmTimeoutRossoVerde.Value;
				else
				{
					if (prmTimeoutRossoVerde.Value != DBNull.Value)
						this.TimeoutRossoVerde = new SqlInt32((int)prmTimeoutRossoVerde.Value);
					else
						this.TimeoutRossoVerde = SqlInt32.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				ref SqlInt32 TimeoutRossoVerde)
		{
			LeggiParametri runner = new LeggiParametri();
			runner.TimeoutRossoVerde = TimeoutRossoVerde;

			runner.Execute(cn);

			TimeoutRossoVerde = runner.TimeoutRossoVerde;

		}

		public static void Execute(
				SqlTransaction tr,
				ref SqlInt32 TimeoutRossoVerde)
		{
			LeggiParametri runner = new LeggiParametri();
			runner.TimeoutRossoVerde = TimeoutRossoVerde;

			runner.Execute(tr.Connection, tr);

			TimeoutRossoVerde = runner.TimeoutRossoVerde;
		}

		#endregion

	}
	public class MessaggioIn_Insert
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlString _CodiceMessaggioIn = SqlString.Null;
		protected bool _CodiceMessaggioInSet = false;
		protected SqlString _CodiceOperatoreIn = SqlString.Null;
		protected bool _CodiceOperatoreInSet = false;
		protected SqlString _CodiceUtenteIn = SqlString.Null;
		protected bool _CodiceUtenteInSet = false;
		protected SqlString _NomeFileIn = SqlString.Null;
		protected bool _NomeFileInSet = false;
		protected SqlBoolean _FirmatoInIngresso = SqlBoolean.Null;
		protected bool _FirmatoInIngressoSet = false;
		protected SqlString _Encoding = SqlString.Null;
		protected bool _EncodingSet = false;
		protected SqlString _Versione = SqlString.Null;
		protected bool _VersioneSet = false;
		protected SqlBinary _BlobMessaggio = SqlBinary.Null;
		protected bool _BlobMessaggioSet = false;
		protected SqlDateTime _DataOraMessaggio = SqlDateTime.Null;
		protected bool _DataOraMessaggioSet = false;
		protected SqlString _Compresso = SqlString.Null;
		protected bool _CompressoSet = false;
		protected SqlBoolean _Controfirmato = SqlBoolean.Null;
		protected bool _ControfirmatoSet = false;
		protected SqlInt32 _IdMessaggioIn = SqlInt32.Null;
		protected bool _IdMessaggioInSet = false;
		#endregion

		#region Public Properties

		public SqlString CodiceMessaggioIn
		{
			get { return _CodiceMessaggioIn; }
			set 
			{
				_CodiceMessaggioIn = value;
				_CodiceMessaggioInSet = true;
			}
		}

		public SqlString CodiceOperatoreIn
		{
			get { return _CodiceOperatoreIn; }
			set 
			{
				_CodiceOperatoreIn = value;
				_CodiceOperatoreInSet = true;
			}
		}

		public SqlString CodiceUtenteIn
		{
			get { return _CodiceUtenteIn; }
			set 
			{
				_CodiceUtenteIn = value;
				_CodiceUtenteInSet = true;
			}
		}

		public SqlString NomeFileIn
		{
			get { return _NomeFileIn; }
			set 
			{
				_NomeFileIn = value;
				_NomeFileInSet = true;
			}
		}

		public SqlBoolean FirmatoInIngresso
		{
			get { return _FirmatoInIngresso; }
			set 
			{
				_FirmatoInIngresso = value;
				_FirmatoInIngressoSet = true;
			}
		}

		public SqlString Encoding
		{
			get { return _Encoding; }
			set 
			{
				_Encoding = value;
				_EncodingSet = true;
			}
		}

		public SqlString Versione
		{
			get { return _Versione; }
			set 
			{
				_Versione = value;
				_VersioneSet = true;
			}
		}

		public SqlBinary BlobMessaggio
		{
			get { return _BlobMessaggio; }
			set 
			{
				_BlobMessaggio = value;
				_BlobMessaggioSet = true;
			}
		}

		public SqlDateTime DataOraMessaggio
		{
			get { return _DataOraMessaggio; }
			set 
			{
				_DataOraMessaggio = value;
				_DataOraMessaggioSet = true;
			}
		}

		public SqlString Compresso
		{
			get { return _Compresso; }
			set 
			{
				_Compresso = value;
				_CompressoSet = true;
			}
		}

		public SqlBoolean Controfirmato
		{
			get { return _Controfirmato; }
			set 
			{
				_Controfirmato = value;
				_ControfirmatoSet = true;
			}
		}

		public SqlInt32 IdMessaggioIn
		{
			get { return _IdMessaggioIn; }
			set 
			{
				_IdMessaggioIn = value;
				_IdMessaggioInSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[MessaggioIn_Insert]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmCodiceMessaggioIn = cmd.Parameters.Add("@CodiceMessaggioIn", SqlDbType.VarChar);
			prmCodiceMessaggioIn.IsNullable = true;
			prmCodiceMessaggioIn.Size = 32;
			prmCodiceMessaggioIn.Direction = ParameterDirection.Input;
			if (this._CodiceMessaggioInSet == true)
				prmCodiceMessaggioIn.Value = this.CodiceMessaggioIn;

			SqlParameter prmCodiceOperatoreIn = cmd.Parameters.Add("@CodiceOperatoreIn", SqlDbType.VarChar);
			prmCodiceOperatoreIn.IsNullable = true;
			prmCodiceOperatoreIn.Size = 8;
			prmCodiceOperatoreIn.Direction = ParameterDirection.Input;
			if (this._CodiceOperatoreInSet == true)
				prmCodiceOperatoreIn.Value = this.CodiceOperatoreIn;

			SqlParameter prmCodiceUtenteIn = cmd.Parameters.Add("@CodiceUtenteIn", SqlDbType.VarChar);
			prmCodiceUtenteIn.IsNullable = true;
			prmCodiceUtenteIn.Size = 8;
			prmCodiceUtenteIn.Direction = ParameterDirection.Input;
			if (this._CodiceUtenteInSet == true)
				prmCodiceUtenteIn.Value = this.CodiceUtenteIn;

			SqlParameter prmNomeFileIn = cmd.Parameters.Add("@NomeFileIn", SqlDbType.NVarChar);
			prmNomeFileIn.IsNullable = true;
			prmNomeFileIn.Size = 512;
			prmNomeFileIn.Direction = ParameterDirection.Input;
			if (this._NomeFileInSet == true)
				prmNomeFileIn.Value = this.NomeFileIn;

			SqlParameter prmFirmatoInIngresso = cmd.Parameters.Add("@FirmatoInIngresso", SqlDbType.Bit);
			prmFirmatoInIngresso.IsNullable = true;
			prmFirmatoInIngresso.Direction = ParameterDirection.Input;
			if (this._FirmatoInIngressoSet == true)
				prmFirmatoInIngresso.Value = this.FirmatoInIngresso;

			SqlParameter prmEncoding = cmd.Parameters.Add("@Encoding", SqlDbType.VarChar);
			prmEncoding.IsNullable = true;
			prmEncoding.Size = 16;
			prmEncoding.Direction = ParameterDirection.Input;
			if (this._EncodingSet == true)
				prmEncoding.Value = this.Encoding;

			SqlParameter prmVersione = cmd.Parameters.Add("@Versione", SqlDbType.VarChar);
			prmVersione.IsNullable = true;
			prmVersione.Size = 5;
			prmVersione.Direction = ParameterDirection.Input;
			if (this._VersioneSet == true)
				prmVersione.Value = this.Versione;

			SqlParameter prmBlobMessaggio = cmd.Parameters.Add("@BlobMessaggio", SqlDbType.VarBinary);
			prmBlobMessaggio.IsNullable = true;
			prmBlobMessaggio.Size = 2147483647;
			prmBlobMessaggio.Direction = ParameterDirection.Input;
			if (this._BlobMessaggioSet == true)
				prmBlobMessaggio.Value = this.BlobMessaggio;

			SqlParameter prmDataOraMessaggio = cmd.Parameters.Add("@DataOraMessaggio", SqlDbType.DateTime);
			prmDataOraMessaggio.IsNullable = true;
			prmDataOraMessaggio.Direction = ParameterDirection.Input;
			if (this._DataOraMessaggioSet == true)
				prmDataOraMessaggio.Value = this.DataOraMessaggio;

			SqlParameter prmCompresso = cmd.Parameters.Add("@Compresso", SqlDbType.VarChar);
			prmCompresso.IsNullable = true;
			prmCompresso.Size = 8;
			prmCompresso.Direction = ParameterDirection.Input;
			if (this._CompressoSet == true)
				prmCompresso.Value = this.Compresso;

			SqlParameter prmControfirmato = cmd.Parameters.Add("@Controfirmato", SqlDbType.Bit);
			prmControfirmato.IsNullable = true;
			prmControfirmato.Direction = ParameterDirection.Input;
			if (this._ControfirmatoSet == true)
				prmControfirmato.Value = this.Controfirmato;

			SqlParameter prmIdMessaggioIn = cmd.Parameters.Add("@IdMessaggioIn", SqlDbType.Int);
			prmIdMessaggioIn.IsNullable = true;
			if (this._IdMessaggioInSet)
				prmIdMessaggioIn.Direction = ParameterDirection.InputOutput;
			else
				prmIdMessaggioIn.Direction = ParameterDirection.Output;
			if (this._IdMessaggioInSet)
				prmIdMessaggioIn.Value = this.IdMessaggioIn;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmIdMessaggioIn = cmd.Parameters["@IdMessaggioIn"];
			if (prmIdMessaggioIn != null && prmIdMessaggioIn.Value != null)
			{
				if (prmIdMessaggioIn.Value is SqlInt32)
					this.IdMessaggioIn = (SqlInt32)prmIdMessaggioIn.Value;
				else
				{
					if (prmIdMessaggioIn.Value != DBNull.Value)
						this.IdMessaggioIn = new SqlInt32((int)prmIdMessaggioIn.Value);
					else
						this.IdMessaggioIn = SqlInt32.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlString CodiceMessaggioIn,
				SqlString CodiceOperatoreIn,
				SqlString CodiceUtenteIn,
				SqlString NomeFileIn,
				SqlBoolean FirmatoInIngresso,
				SqlString Encoding,
				SqlString Versione,
				SqlBinary BlobMessaggio,
				SqlDateTime DataOraMessaggio,
				SqlString Compresso,
				SqlBoolean Controfirmato,
				ref SqlInt32 IdMessaggioIn)
		{
			MessaggioIn_Insert runner = new MessaggioIn_Insert();
			runner.CodiceMessaggioIn = CodiceMessaggioIn;
			runner.CodiceOperatoreIn = CodiceOperatoreIn;
			runner.CodiceUtenteIn = CodiceUtenteIn;
			runner.NomeFileIn = NomeFileIn;
			runner.FirmatoInIngresso = FirmatoInIngresso;
			runner.Encoding = Encoding;
			runner.Versione = Versione;
			runner.BlobMessaggio = BlobMessaggio;
			runner.DataOraMessaggio = DataOraMessaggio;
			runner.Compresso = Compresso;
			runner.Controfirmato = Controfirmato;
			runner.IdMessaggioIn = IdMessaggioIn;

			runner.Execute(cn);

			IdMessaggioIn = runner.IdMessaggioIn;

		}

		public static void Execute(
				SqlTransaction tr,
				SqlString CodiceMessaggioIn,
				SqlString CodiceOperatoreIn,
				SqlString CodiceUtenteIn,
				SqlString NomeFileIn,
				SqlBoolean FirmatoInIngresso,
				SqlString Encoding,
				SqlString Versione,
				SqlBinary BlobMessaggio,
				SqlDateTime DataOraMessaggio,
				SqlString Compresso,
				SqlBoolean Controfirmato,
				ref SqlInt32 IdMessaggioIn)
		{
			MessaggioIn_Insert runner = new MessaggioIn_Insert();
			runner.CodiceMessaggioIn = CodiceMessaggioIn;
			runner.CodiceOperatoreIn = CodiceOperatoreIn;
			runner.CodiceUtenteIn = CodiceUtenteIn;
			runner.NomeFileIn = NomeFileIn;
			runner.FirmatoInIngresso = FirmatoInIngresso;
			runner.Encoding = Encoding;
			runner.Versione = Versione;
			runner.BlobMessaggio = BlobMessaggio;
			runner.DataOraMessaggio = DataOraMessaggio;
			runner.Compresso = Compresso;
			runner.Controfirmato = Controfirmato;
			runner.IdMessaggioIn = IdMessaggioIn;

			runner.Execute(tr.Connection, tr);

			IdMessaggioIn = runner.IdMessaggioIn;
		}

		#endregion

	}
	public class MessaggioOut_Insert
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlString _CodiceMessaggioOut = SqlString.Null;
		protected bool _CodiceMessaggioOutSet = false;
		protected SqlString _CodiceOperatoreOut = SqlString.Null;
		protected bool _CodiceOperatoreOutSet = false;
		protected SqlString _NomeFileOut = SqlString.Null;
		protected bool _NomeFileOutSet = false;
		protected SqlString _Compresso = SqlString.Null;
		protected bool _CompressoSet = false;
		protected SqlBoolean _FirmatoInUscita = SqlBoolean.Null;
		protected bool _FirmatoInUscitaSet = false;
		protected SqlString _Encoding = SqlString.Null;
		protected bool _EncodingSet = false;
		protected SqlDateTime _DataOraMessaggio = SqlDateTime.Null;
		protected bool _DataOraMessaggioSet = false;
		protected SqlString _Versione = SqlString.Null;
		protected bool _VersioneSet = false;
		protected SqlBinary _BlobMessaggio = SqlBinary.Null;
		protected bool _BlobMessaggioSet = false;
		protected SqlInt32 _IdMessaggioIn = SqlInt32.Null;
		protected bool _IdMessaggioInSet = false;
		protected SqlDateTime _DataOraDownload = SqlDateTime.Null;
		protected bool _DataOraDownloadSet = false;
		protected SqlInt32 _IdMessaggioOut = SqlInt32.Null;
		protected bool _IdMessaggioOutSet = false;
		#endregion

		#region Public Properties

		public SqlString CodiceMessaggioOut
		{
			get { return _CodiceMessaggioOut; }
			set 
			{
				_CodiceMessaggioOut = value;
				_CodiceMessaggioOutSet = true;
			}
		}

		public SqlString CodiceOperatoreOut
		{
			get { return _CodiceOperatoreOut; }
			set 
			{
				_CodiceOperatoreOut = value;
				_CodiceOperatoreOutSet = true;
			}
		}

		public SqlString NomeFileOut
		{
			get { return _NomeFileOut; }
			set 
			{
				_NomeFileOut = value;
				_NomeFileOutSet = true;
			}
		}

		public SqlString Compresso
		{
			get { return _Compresso; }
			set 
			{
				_Compresso = value;
				_CompressoSet = true;
			}
		}

		public SqlBoolean FirmatoInUscita
		{
			get { return _FirmatoInUscita; }
			set 
			{
				_FirmatoInUscita = value;
				_FirmatoInUscitaSet = true;
			}
		}

		public SqlString Encoding
		{
			get { return _Encoding; }
			set 
			{
				_Encoding = value;
				_EncodingSet = true;
			}
		}

		public SqlDateTime DataOraMessaggio
		{
			get { return _DataOraMessaggio; }
			set 
			{
				_DataOraMessaggio = value;
				_DataOraMessaggioSet = true;
			}
		}

		public SqlString Versione
		{
			get { return _Versione; }
			set 
			{
				_Versione = value;
				_VersioneSet = true;
			}
		}

		public SqlBinary BlobMessaggio
		{
			get { return _BlobMessaggio; }
			set 
			{
				_BlobMessaggio = value;
				_BlobMessaggioSet = true;
			}
		}

		public SqlInt32 IdMessaggioIn
		{
			get { return _IdMessaggioIn; }
			set 
			{
				_IdMessaggioIn = value;
				_IdMessaggioInSet = true;
			}
		}

		public SqlDateTime DataOraDownload
		{
			get { return _DataOraDownload; }
			set 
			{
				_DataOraDownload = value;
				_DataOraDownloadSet = true;
			}
		}

		public SqlInt32 IdMessaggioOut
		{
			get { return _IdMessaggioOut; }
			set 
			{
				_IdMessaggioOut = value;
				_IdMessaggioOutSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[MessaggioOut_Insert]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmCodiceMessaggioOut = cmd.Parameters.Add("@CodiceMessaggioOut", SqlDbType.VarChar);
			prmCodiceMessaggioOut.IsNullable = true;
			prmCodiceMessaggioOut.Size = 32;
			prmCodiceMessaggioOut.Direction = ParameterDirection.Input;
			if (this._CodiceMessaggioOutSet == true)
				prmCodiceMessaggioOut.Value = this.CodiceMessaggioOut;

			SqlParameter prmCodiceOperatoreOut = cmd.Parameters.Add("@CodiceOperatoreOut", SqlDbType.VarChar);
			prmCodiceOperatoreOut.IsNullable = true;
			prmCodiceOperatoreOut.Size = 8;
			prmCodiceOperatoreOut.Direction = ParameterDirection.Input;
			if (this._CodiceOperatoreOutSet == true)
				prmCodiceOperatoreOut.Value = this.CodiceOperatoreOut;

			SqlParameter prmNomeFileOut = cmd.Parameters.Add("@NomeFileOut", SqlDbType.NVarChar);
			prmNomeFileOut.IsNullable = true;
			prmNomeFileOut.Size = 512;
			prmNomeFileOut.Direction = ParameterDirection.Input;
			if (this._NomeFileOutSet == true)
				prmNomeFileOut.Value = this.NomeFileOut;

			SqlParameter prmCompresso = cmd.Parameters.Add("@Compresso", SqlDbType.VarChar);
			prmCompresso.IsNullable = true;
			prmCompresso.Size = 8;
			prmCompresso.Direction = ParameterDirection.Input;
			if (this._CompressoSet == true)
				prmCompresso.Value = this.Compresso;

			SqlParameter prmFirmatoInUscita = cmd.Parameters.Add("@FirmatoInUscita", SqlDbType.Bit);
			prmFirmatoInUscita.IsNullable = true;
			prmFirmatoInUscita.Direction = ParameterDirection.Input;
			if (this._FirmatoInUscitaSet == true)
				prmFirmatoInUscita.Value = this.FirmatoInUscita;

			SqlParameter prmEncoding = cmd.Parameters.Add("@Encoding", SqlDbType.VarChar);
			prmEncoding.IsNullable = true;
			prmEncoding.Size = 16;
			prmEncoding.Direction = ParameterDirection.Input;
			if (this._EncodingSet == true)
				prmEncoding.Value = this.Encoding;

			SqlParameter prmDataOraMessaggio = cmd.Parameters.Add("@DataOraMessaggio", SqlDbType.DateTime);
			prmDataOraMessaggio.IsNullable = true;
			prmDataOraMessaggio.Direction = ParameterDirection.Input;
			if (this._DataOraMessaggioSet == true)
				prmDataOraMessaggio.Value = this.DataOraMessaggio;

			SqlParameter prmVersione = cmd.Parameters.Add("@Versione", SqlDbType.VarChar);
			prmVersione.IsNullable = true;
			prmVersione.Size = 5;
			prmVersione.Direction = ParameterDirection.Input;
			if (this._VersioneSet == true)
				prmVersione.Value = this.Versione;

			SqlParameter prmBlobMessaggio = cmd.Parameters.Add("@BlobMessaggio", SqlDbType.VarBinary);
			prmBlobMessaggio.IsNullable = true;
			prmBlobMessaggio.Size = 2147483647;
			prmBlobMessaggio.Direction = ParameterDirection.Input;
			if (this._BlobMessaggioSet == true)
				prmBlobMessaggio.Value = this.BlobMessaggio;

			SqlParameter prmIdMessaggioIn = cmd.Parameters.Add("@IdMessaggioIn", SqlDbType.Int);
			prmIdMessaggioIn.IsNullable = true;
			prmIdMessaggioIn.Direction = ParameterDirection.Input;
			if (this._IdMessaggioInSet == true)
				prmIdMessaggioIn.Value = this.IdMessaggioIn;

			SqlParameter prmDataOraDownload = cmd.Parameters.Add("@DataOraDownload", SqlDbType.DateTime);
			prmDataOraDownload.IsNullable = true;
			prmDataOraDownload.Direction = ParameterDirection.Input;
			if (this._DataOraDownloadSet == true)
				prmDataOraDownload.Value = this.DataOraDownload;

			SqlParameter prmIdMessaggioOut = cmd.Parameters.Add("@IdMessaggioOut", SqlDbType.Int);
			prmIdMessaggioOut.IsNullable = true;
			if (this._IdMessaggioOutSet)
				prmIdMessaggioOut.Direction = ParameterDirection.InputOutput;
			else
				prmIdMessaggioOut.Direction = ParameterDirection.Output;
			if (this._IdMessaggioOutSet)
				prmIdMessaggioOut.Value = this.IdMessaggioOut;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;

			SqlParameter prmIdMessaggioOut = cmd.Parameters["@IdMessaggioOut"];
			if (prmIdMessaggioOut != null && prmIdMessaggioOut.Value != null)
			{
				if (prmIdMessaggioOut.Value is SqlInt32)
					this.IdMessaggioOut = (SqlInt32)prmIdMessaggioOut.Value;
				else
				{
					if (prmIdMessaggioOut.Value != DBNull.Value)
						this.IdMessaggioOut = new SqlInt32((int)prmIdMessaggioOut.Value);
					else
						this.IdMessaggioOut = SqlInt32.Null;
				}
			}
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlString CodiceMessaggioOut,
				SqlString CodiceOperatoreOut,
				SqlString NomeFileOut,
				SqlString Compresso,
				SqlBoolean FirmatoInUscita,
				SqlString Encoding,
				SqlDateTime DataOraMessaggio,
				SqlString Versione,
				SqlBinary BlobMessaggio,
				SqlInt32 IdMessaggioIn,
				SqlDateTime DataOraDownload,
				ref SqlInt32 IdMessaggioOut)
		{
			MessaggioOut_Insert runner = new MessaggioOut_Insert();
			runner.CodiceMessaggioOut = CodiceMessaggioOut;
			runner.CodiceOperatoreOut = CodiceOperatoreOut;
			runner.NomeFileOut = NomeFileOut;
			runner.Compresso = Compresso;
			runner.FirmatoInUscita = FirmatoInUscita;
			runner.Encoding = Encoding;
			runner.DataOraMessaggio = DataOraMessaggio;
			runner.Versione = Versione;
			runner.BlobMessaggio = BlobMessaggio;
			runner.IdMessaggioIn = IdMessaggioIn;
			runner.DataOraDownload = DataOraDownload;
			runner.IdMessaggioOut = IdMessaggioOut;

			runner.Execute(cn);

			IdMessaggioOut = runner.IdMessaggioOut;

		}

		public static void Execute(
				SqlTransaction tr,
				SqlString CodiceMessaggioOut,
				SqlString CodiceOperatoreOut,
				SqlString NomeFileOut,
				SqlString Compresso,
				SqlBoolean FirmatoInUscita,
				SqlString Encoding,
				SqlDateTime DataOraMessaggio,
				SqlString Versione,
				SqlBinary BlobMessaggio,
				SqlInt32 IdMessaggioIn,
				SqlDateTime DataOraDownload,
				ref SqlInt32 IdMessaggioOut)
		{
			MessaggioOut_Insert runner = new MessaggioOut_Insert();
			runner.CodiceMessaggioOut = CodiceMessaggioOut;
			runner.CodiceOperatoreOut = CodiceOperatoreOut;
			runner.NomeFileOut = NomeFileOut;
			runner.Compresso = Compresso;
			runner.FirmatoInUscita = FirmatoInUscita;
			runner.Encoding = Encoding;
			runner.DataOraMessaggio = DataOraMessaggio;
			runner.Versione = Versione;
			runner.BlobMessaggio = BlobMessaggio;
			runner.IdMessaggioIn = IdMessaggioIn;
			runner.DataOraDownload = DataOraDownload;
			runner.IdMessaggioOut = IdMessaggioOut;

			runner.Execute(tr.Connection, tr);

			IdMessaggioOut = runner.IdMessaggioOut;
		}

		#endregion

	}
	public class TransazioneIn_Insert
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlInt32 _IdMessaggioIn = SqlInt32.Null;
		protected bool _IdMessaggioInSet = false;
		protected SqlInt32 _ProgressivoTransazioneIn = SqlInt32.Null;
		protected bool _ProgressivoTransazioneInSet = false;
		protected SqlString _CodiceTransazioneIn = SqlString.Null;
		protected bool _CodiceTransazioneInSet = false;
		protected SqlString _TipoTransazione = SqlString.Null;
		protected bool _TipoTransazioneSet = false;
		protected SqlBinary _BlobTransazione = SqlBinary.Null;
		protected bool _BlobTransazioneSet = false;
		#endregion

		#region Public Properties

		public SqlInt32 IdMessaggioIn
		{
			get { return _IdMessaggioIn; }
			set 
			{
				_IdMessaggioIn = value;
				_IdMessaggioInSet = true;
			}
		}

		public SqlInt32 ProgressivoTransazioneIn
		{
			get { return _ProgressivoTransazioneIn; }
			set 
			{
				_ProgressivoTransazioneIn = value;
				_ProgressivoTransazioneInSet = true;
			}
		}

		public SqlString CodiceTransazioneIn
		{
			get { return _CodiceTransazioneIn; }
			set 
			{
				_CodiceTransazioneIn = value;
				_CodiceTransazioneInSet = true;
			}
		}

		public SqlString TipoTransazione
		{
			get { return _TipoTransazione; }
			set 
			{
				_TipoTransazione = value;
				_TipoTransazioneSet = true;
			}
		}

		public SqlBinary BlobTransazione
		{
			get { return _BlobTransazione; }
			set 
			{
				_BlobTransazione = value;
				_BlobTransazioneSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[TransazioneIn_Insert]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmIdMessaggioIn = cmd.Parameters.Add("@IdMessaggioIn", SqlDbType.Int);
			prmIdMessaggioIn.IsNullable = true;
			prmIdMessaggioIn.Direction = ParameterDirection.Input;
			if (this._IdMessaggioInSet == true)
				prmIdMessaggioIn.Value = this.IdMessaggioIn;

			SqlParameter prmProgressivoTransazioneIn = cmd.Parameters.Add("@ProgressivoTransazioneIn", SqlDbType.Int);
			prmProgressivoTransazioneIn.IsNullable = true;
			prmProgressivoTransazioneIn.Direction = ParameterDirection.Input;
			if (this._ProgressivoTransazioneInSet == true)
				prmProgressivoTransazioneIn.Value = this.ProgressivoTransazioneIn;

			SqlParameter prmCodiceTransazioneIn = cmd.Parameters.Add("@CodiceTransazioneIn", SqlDbType.VarChar);
			prmCodiceTransazioneIn.IsNullable = true;
			prmCodiceTransazioneIn.Size = 32;
			prmCodiceTransazioneIn.Direction = ParameterDirection.Input;
			if (this._CodiceTransazioneInSet == true)
				prmCodiceTransazioneIn.Value = this.CodiceTransazioneIn;

			SqlParameter prmTipoTransazione = cmd.Parameters.Add("@TipoTransazione", SqlDbType.VarChar);
			prmTipoTransazione.IsNullable = true;
			prmTipoTransazione.Size = 32;
			prmTipoTransazione.Direction = ParameterDirection.Input;
			if (this._TipoTransazioneSet == true)
				prmTipoTransazione.Value = this.TipoTransazione;

			SqlParameter prmBlobTransazione = cmd.Parameters.Add("@BlobTransazione", SqlDbType.VarBinary);
			prmBlobTransazione.IsNullable = true;
			prmBlobTransazione.Size = 2147483647;
			prmBlobTransazione.Direction = ParameterDirection.Input;
			if (this._BlobTransazioneSet == true)
				prmBlobTransazione.Value = this.BlobTransazione;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlInt32 IdMessaggioIn,
				SqlInt32 ProgressivoTransazioneIn,
				SqlString CodiceTransazioneIn,
				SqlString TipoTransazione,
				SqlBinary BlobTransazione)
		{
			TransazioneIn_Insert runner = new TransazioneIn_Insert();
			runner.IdMessaggioIn = IdMessaggioIn;
			runner.ProgressivoTransazioneIn = ProgressivoTransazioneIn;
			runner.CodiceTransazioneIn = CodiceTransazioneIn;
			runner.TipoTransazione = TipoTransazione;
			runner.BlobTransazione = BlobTransazione;

			runner.Execute(cn);


		}

		public static void Execute(
				SqlTransaction tr,
				SqlInt32 IdMessaggioIn,
				SqlInt32 ProgressivoTransazioneIn,
				SqlString CodiceTransazioneIn,
				SqlString TipoTransazione,
				SqlBinary BlobTransazione)
		{
			TransazioneIn_Insert runner = new TransazioneIn_Insert();
			runner.IdMessaggioIn = IdMessaggioIn;
			runner.ProgressivoTransazioneIn = ProgressivoTransazioneIn;
			runner.CodiceTransazioneIn = CodiceTransazioneIn;
			runner.TipoTransazione = TipoTransazione;
			runner.BlobTransazione = BlobTransazione;

			runner.Execute(tr.Connection, tr);

		}

		#endregion

	}
	public class TransazioneOut_Insert
	{
		#region Member variables
		protected int _returnValue = 0;
		protected SqlInt32 _IdMessaggioOut = SqlInt32.Null;
		protected bool _IdMessaggioOutSet = false;
		protected SqlInt32 _ProgressivoTransazioneOut = SqlInt32.Null;
		protected bool _ProgressivoTransazioneOutSet = false;
		protected SqlString _CodiceTransazioneOut = SqlString.Null;
		protected bool _CodiceTransazioneOutSet = false;
		protected SqlString _TipoTransazione = SqlString.Null;
		protected bool _TipoTransazioneSet = false;
		protected SqlInt32 _IdMessagionIn = SqlInt32.Null;
		protected bool _IdMessagionInSet = false;
		protected SqlInt32 _ProgressivoTransazioneIn = SqlInt32.Null;
		protected bool _ProgressivoTransazioneInSet = false;
		protected SqlString _StatoTransazione = SqlString.Null;
		protected bool _StatoTransazioneSet = false;
		protected SqlBinary _BlobTransazione = SqlBinary.Null;
		protected bool _BlobTransazioneSet = false;
		#endregion

		#region Public Properties

		public SqlInt32 IdMessaggioOut
		{
			get { return _IdMessaggioOut; }
			set 
			{
				_IdMessaggioOut = value;
				_IdMessaggioOutSet = true;
			}
		}

		public SqlInt32 ProgressivoTransazioneOut
		{
			get { return _ProgressivoTransazioneOut; }
			set 
			{
				_ProgressivoTransazioneOut = value;
				_ProgressivoTransazioneOutSet = true;
			}
		}

		public SqlString CodiceTransazioneOut
		{
			get { return _CodiceTransazioneOut; }
			set 
			{
				_CodiceTransazioneOut = value;
				_CodiceTransazioneOutSet = true;
			}
		}

		public SqlString TipoTransazione
		{
			get { return _TipoTransazione; }
			set 
			{
				_TipoTransazione = value;
				_TipoTransazioneSet = true;
			}
		}

		public SqlInt32 IdMessagionIn
		{
			get { return _IdMessagionIn; }
			set 
			{
				_IdMessagionIn = value;
				_IdMessagionInSet = true;
			}
		}

		public SqlInt32 ProgressivoTransazioneIn
		{
			get { return _ProgressivoTransazioneIn; }
			set 
			{
				_ProgressivoTransazioneIn = value;
				_ProgressivoTransazioneInSet = true;
			}
		}

		public SqlString StatoTransazione
		{
			get { return _StatoTransazione; }
			set 
			{
				_StatoTransazione = value;
				_StatoTransazioneSet = true;
			}
		}

		public SqlBinary BlobTransazione
		{
			get { return _BlobTransazione; }
			set 
			{
				_BlobTransazione = value;
				_BlobTransazioneSet = true;
			}
		}
		#endregion

		public SqlCommand CreateCommand(SqlConnection cn, SqlTransaction tr)
		{
			SqlCommand cmd = cn.CreateCommand();
			cmd.Transaction = tr;

			cmd.CommandText = "[dbo].[TransazioneOut_Insert]";
			cmd.CommandType = CommandType.StoredProcedure;

			SqlParameter prmRETURN_VALUE = cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			prmRETURN_VALUE.IsNullable = true;
			prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			SqlParameter prmIdMessaggioOut = cmd.Parameters.Add("@IdMessaggioOut", SqlDbType.Int);
			prmIdMessaggioOut.IsNullable = true;
			prmIdMessaggioOut.Direction = ParameterDirection.Input;
			if (this._IdMessaggioOutSet == true)
				prmIdMessaggioOut.Value = this.IdMessaggioOut;

			SqlParameter prmProgressivoTransazioneOut = cmd.Parameters.Add("@ProgressivoTransazioneOut", SqlDbType.Int);
			prmProgressivoTransazioneOut.IsNullable = true;
			prmProgressivoTransazioneOut.Direction = ParameterDirection.Input;
			if (this._ProgressivoTransazioneOutSet == true)
				prmProgressivoTransazioneOut.Value = this.ProgressivoTransazioneOut;

			SqlParameter prmCodiceTransazioneOut = cmd.Parameters.Add("@CodiceTransazioneOut", SqlDbType.VarChar);
			prmCodiceTransazioneOut.IsNullable = true;
			prmCodiceTransazioneOut.Size = 32;
			prmCodiceTransazioneOut.Direction = ParameterDirection.Input;
			if (this._CodiceTransazioneOutSet == true)
				prmCodiceTransazioneOut.Value = this.CodiceTransazioneOut;

			SqlParameter prmTipoTransazione = cmd.Parameters.Add("@TipoTransazione", SqlDbType.VarChar);
			prmTipoTransazione.IsNullable = true;
			prmTipoTransazione.Size = 32;
			prmTipoTransazione.Direction = ParameterDirection.Input;
			if (this._TipoTransazioneSet == true)
				prmTipoTransazione.Value = this.TipoTransazione;

			SqlParameter prmIdMessagionIn = cmd.Parameters.Add("@IdMessagionIn", SqlDbType.Int);
			prmIdMessagionIn.IsNullable = true;
			prmIdMessagionIn.Direction = ParameterDirection.Input;
			if (this._IdMessagionInSet == true)
				prmIdMessagionIn.Value = this.IdMessagionIn;

			SqlParameter prmProgressivoTransazioneIn = cmd.Parameters.Add("@ProgressivoTransazioneIn", SqlDbType.Int);
			prmProgressivoTransazioneIn.IsNullable = true;
			prmProgressivoTransazioneIn.Direction = ParameterDirection.Input;
			if (this._ProgressivoTransazioneInSet == true)
				prmProgressivoTransazioneIn.Value = this.ProgressivoTransazioneIn;

			SqlParameter prmStatoTransazione = cmd.Parameters.Add("@StatoTransazione", SqlDbType.VarChar);
			prmStatoTransazione.IsNullable = true;
			prmStatoTransazione.Size = 32;
			prmStatoTransazione.Direction = ParameterDirection.Input;
			if (this._StatoTransazioneSet == true)
				prmStatoTransazione.Value = this.StatoTransazione;

			SqlParameter prmBlobTransazione = cmd.Parameters.Add("@BlobTransazione", SqlDbType.VarBinary);
			prmBlobTransazione.IsNullable = true;
			prmBlobTransazione.Size = 2147483647;
			prmBlobTransazione.Direction = ParameterDirection.Input;
			if (this._BlobTransazioneSet == true)
				prmBlobTransazione.Value = this.BlobTransazione;


			return cmd;
		}

		public void ReadOutput(SqlCommand cmd)
		{
			SqlParameter prmRETURN_VALUE = cmd.Parameters["@RETURN_VALUE"];
			if (prmRETURN_VALUE.Value != null && prmRETURN_VALUE.Value != DBNull.Value)
				_returnValue = (int)prmRETURN_VALUE.Value;
		}


		#region Execute Region
		public void Execute(SqlConnection cn)
		{
			SqlTransaction tr = null;
			Execute(cn, tr);
		}

		public void Execute(SqlConnection cn, SqlTransaction tr)
		{
			bool cnOpenedLocally = false;

			SqlCommand cmd = null;

			try
			{
				cmd = this.CreateCommand(cn, tr);

				if (tr == null && cn.State == ConnectionState.Closed)
				{
					cn.Open();
					cnOpenedLocally = true;
				}

				cmd.ExecuteNonQuery();

				ReadOutput(cmd);
			}
			finally
			{
				cmd.Connection = null;
				cmd.Dispose();
				if (cnOpenedLocally && cn.State == ConnectionState.Open)
					cn.Close();
			}

		}


		public static void Execute(
				SqlConnection cn,
				SqlInt32 IdMessaggioOut,
				SqlInt32 ProgressivoTransazioneOut,
				SqlString CodiceTransazioneOut,
				SqlString TipoTransazione,
				SqlInt32 IdMessagionIn,
				SqlInt32 ProgressivoTransazioneIn,
				SqlString StatoTransazione,
				SqlBinary BlobTransazione)
		{
			TransazioneOut_Insert runner = new TransazioneOut_Insert();
			runner.IdMessaggioOut = IdMessaggioOut;
			runner.ProgressivoTransazioneOut = ProgressivoTransazioneOut;
			runner.CodiceTransazioneOut = CodiceTransazioneOut;
			runner.TipoTransazione = TipoTransazione;
			runner.IdMessagionIn = IdMessagionIn;
			runner.ProgressivoTransazioneIn = ProgressivoTransazioneIn;
			runner.StatoTransazione = StatoTransazione;
			runner.BlobTransazione = BlobTransazione;

			runner.Execute(cn);


		}

		public static void Execute(
				SqlTransaction tr,
				SqlInt32 IdMessaggioOut,
				SqlInt32 ProgressivoTransazioneOut,
				SqlString CodiceTransazioneOut,
				SqlString TipoTransazione,
				SqlInt32 IdMessagionIn,
				SqlInt32 ProgressivoTransazioneIn,
				SqlString StatoTransazione,
				SqlBinary BlobTransazione)
		{
			TransazioneOut_Insert runner = new TransazioneOut_Insert();
			runner.IdMessaggioOut = IdMessaggioOut;
			runner.ProgressivoTransazioneOut = ProgressivoTransazioneOut;
			runner.CodiceTransazioneOut = CodiceTransazioneOut;
			runner.TipoTransazione = TipoTransazione;
			runner.IdMessagionIn = IdMessagionIn;
			runner.ProgressivoTransazioneIn = ProgressivoTransazioneIn;
			runner.StatoTransazione = StatoTransazione;
			runner.BlobTransazione = BlobTransazione;

			runner.Execute(tr.Connection, tr);

		}

		#endregion

	}
}

