using System;
using System.Collections;
using System.Data;
using System.Reflection;

namespace Bipex_BL
{
	/// <summary>
	/// Summary description for RecordReader.
	/// </summary>
	public class RecordReader
	{
		readonly private Type            _recordType;
		readonly private ConstructorInfo _ci;
		readonly private IDataReader     _rd;
		private FieldData[]              _fd;
		private MethodInfo               _rowRead;

		public static ArrayList Read(Type recordType, IDataReader rd)
		{
			RecordReader r = new RecordReader(recordType, rd);
			return r.Read();
		}

		public static object ReadOne(Type recordType, IDataReader rd)
		{
			RecordReader r = new RecordReader(recordType, rd);
			return r.ReadOne();
		}

		public RecordReader(Type recordType, IDataReader rd)
		{
			this._rd = rd;
			this._recordType = recordType;

			if (!recordType.IsClass)
				throw new ArgumentNullException("recordType", "deve essere una classe!");

			this._ci = this._recordType.GetConstructor(new Type[] {});
			if (this._ci == null)
				throw new ArgumentException("recordType", "RecordReader: il costruttore deve essere senza parametri");

			_rowRead = recordType.GetMethod("Read", new Type[] { typeof(IDataReader) });

			if (_rowRead == null)
				ReadMetadata();
		}

		public class FieldData
		{
			public FieldData(Type ty, string member)
			{
				_member = member;
				_className = ty.Name;

				MemberInfo miValue = null;
				MemberInfo miNull = null;

				MemberInfo[] mi = ty.GetMember(member, BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly | BindingFlags.ExactBinding);
				if (mi.Length == 0)
				{
					mi = ty.GetMember("nn" + member, BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly | BindingFlags.ExactBinding);
					if (mi.Length > 0)
						member = "nn" + member;
					else
					{
						mi = ty.GetMember("nu" + member, BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly | BindingFlags.ExactBinding);
						if (mi.Length > 0)
							member = "nu" + member;
						else
							return;
					}
				}

				_member = member; // qui aggiorno _member per includere <nn> o <nu>

				miValue = mi[0];

				mi = ty.GetMember(member + "Null", BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly | BindingFlags.ExactBinding);
				if (mi.Length > 0)
					miNull = (FieldInfo) mi[0];

				if (miValue is FieldInfo) 
					this.fValue = (FieldInfo) miValue;
				else
					this.pValue = (PropertyInfo) miValue;

				if (miNull is FieldInfo) 
					this.fNull = (FieldInfo) miNull;
				else
					this.pNull = (PropertyInfo) miNull;
			}

			readonly string _member;
			readonly string _className;

			readonly FieldInfo fValue;
			readonly FieldInfo fNull;

			readonly PropertyInfo pValue;
			readonly PropertyInfo pNull;

			virtual public void SetNull(object r, bool n)
			{
				if (fNull == null && pNull == null)
					throw new ApplicationException(string.Format("RecordReader: Il campo '{0}' della classe '{1}' e` non nullabile", _member, _className));

				if (fNull != null)
					fNull.SetValue(r, true);
				else
					pNull.SetValue(r, true, null);
			}
			public void SetNull(object r) { SetNull(r, true); }
			public void SetNotNull(object r) { SetNull(r, false); }

			public bool IsNull(object r)
			{
				if (fNull != null) return (bool) fNull.GetValue(r);
				if (pNull != null) return (bool) pNull.GetValue(r, null);
				return false;
			}
			public bool IsNotNull(object r)
			{
				return ! IsNull(r);
			}
			public bool IsNullable()
			{
				return fNull != null || pNull != null;
			}

			virtual public void SetValue(object r, object v)
			{
				if (fValue == null && pValue == null) return;

				if (this.IsNullable())
					this.SetNotNull(r);

				if (fNull != null || pNull != null)
					this.SetNull(false);

				if (fValue != null) 
					Assign(r, fValue, v);
				else
					Assign(r, pValue, v);
			}

			private static void Assign(object r, FieldInfo c, object dbValue)
			{
				Type colType = c.FieldType;
				Type dbType = dbValue.GetType();

				if (colType.IsEnum)
				{
					if (dbValue is string)
					{
						// qui ho una stringa da convertire nell'enum
						object v = Enum.Parse(c.FieldType, (string) dbValue, true);
						c.SetValue(r, v);
					}
					else
					{
						// qui ho un numero da convertire nell'enum
						object v = Enum.Parse(c.FieldType, dbValue.ToString(), true);
						c.SetValue(r, v);
					}
				}
				else if (colType == typeof (Double))
				{
					object v = Convert.ToDouble(dbValue);
					c.SetValue(r, v);
				}
				else if (colType == typeof (bool))
				{
					if (dbType == typeof (string))
					{
						string v = ((string) dbValue).ToLower();
						bool b = v == "s" || v == "y" || v == "si" || v == "yes";
						c.SetValue(r, b);
					}
					else if (dbType == typeof (int) || dbType == typeof (short) || dbType == typeof (decimal))
					{
						int v = Convert.ToInt32(dbValue);
						c.SetValue(r, v != 0);
					}
					else
						c.SetValue(r, dbValue);
				}
				else
				{
					object v = dbValue;
					if (colType != dbType) v = Convert.ChangeType(dbValue, colType);
					c.SetValue(r, v);
				}
			}

			private static void Assign(object r, PropertyInfo c, object dbValue)
			{
				Type colType = c.PropertyType;
				Type dbType = dbValue.GetType();

				if (colType.IsEnum)
				{
					if (dbValue is string)
					{
						// qui ho una stringa da convertire nell'enum
						object v = Enum.Parse(colType, (string) dbValue, true);
						c.SetValue(r, v, null);
					}
					else
					{
						// qui ho un numero da convertire nell'enum
						object v = Enum.Parse(colType, dbValue.ToString(), true);
						c.SetValue(r, v, null);
					}
				}
				else if (colType == typeof (Double))
				{
					object v = Convert.ToDouble(dbValue);
					c.SetValue(r, v, null);
				}
				else if (colType == typeof (bool))
				{
					if (dbType == typeof (string))
					{
						string v = ((string) dbValue).ToLower();
						bool b = v == "s" || v == "y" || v == "si" || v == "yes";
						c.SetValue(r, b, null);
					}
					else if (dbType == typeof (int) || dbType == typeof (short) || dbType == typeof (decimal))
					{
						int v = Convert.ToInt32(dbValue);
						c.SetValue(r, v != 0, null);
					}
					else
						c.SetValue(r, dbValue, null);
				}
				else
				{
					object v = dbValue;
					if (colType != dbType) v = Convert.ChangeType(dbValue, colType);
					c.SetValue(r, v, null);
				}
			}
		}


		public void ReadMetadata()
		{
			ArrayList fd = new ArrayList();

			for (int i = 0; i < _rd.FieldCount; ++i)
			{
				string dbColName = _rd.GetName(i);

				FieldData f = new FieldData(_recordType, dbColName);
				fd.Add(f);
			}
			_fd = (FieldData[]) fd.ToArray(typeof(FieldData));
		}

		public void SetFieldData(string dbColName, FieldData fd)
		{
			for (int i = 0; i < _rd.FieldCount; ++i)
			{
				if (dbColName == _rd.GetName(i))
				{
					_fd[i] = fd;
					return;
				}
			}

			throw new ArgumentException(
				string.Format("RecordReader.SetFieldData : non esiste il campo '{0}' nel IDataRecordReader", dbColName), "dbColName");
		}

		public ArrayList Read()
		{
			ArrayList ret = new ArrayList();

			while (_rd.Read())
			{
				object r = _ci.Invoke(null);
				ReadRow(r);
				ret.Add(r);
			}
			return ret;
		}

		public object ReadOne()
		{
			if (!_rd.Read())
				throw new ApplicationException("RecordReader.ReadOne: IDataRecordReader non ha righe da leggere");

			object r = _ci.Invoke(null);
			ReadRow(r);

			if (_rd.Read())
				throw new ApplicationException("RecordReader.ReadOne: IDataRecordReader non ritorna una sola riga");

			return r;
		}

		private void ReadRow(object r)
		{
			if (_rowRead != null)
			{
				_rowRead.Invoke(r, new object[] {_rd });
			}
			else
			{
				for (int f = 0; f < _rd.FieldCount; ++f)
				{
					FieldData fm = _fd[f];
				
					bool colNull = _rd.IsDBNull(f);
					if (colNull)
					{
						fm.SetNull(r);
					}
					else
					{
						object colValue = _rd.GetValue(f);
						fm.SetValue(r, colValue);
					}
				}
			}
		}
	}
}
