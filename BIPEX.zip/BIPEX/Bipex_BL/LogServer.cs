using System.ComponentModel;
using System.Data.SqlClient;
using System.Runtime.Remoting.Messaging;
using Bipex_BLInterface;
using GME;
using GME.BL;

namespace Bipex_BL
{
	[RemotableServer("Bipex_BLWS", "LogServer.rem")]
	public class LogServer : BLBase, ILogServer
	{
		#region Costruttore

		private Container components = null;

		public LogServer(IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public LogServer()
		{
			InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#endregion

		/// <summary>
		/// Funzione chiamata dagli altri moduli per fare logging nel DB
		/// </summary>
		/// <param name="msg">il messaggio da salvare nel DB</param>
		//[OneWay]
		public void Write(string msg)
		{
			WriteMessage(msg);}

		/// <summary>
		/// Funzione chiamata del server di remoting che fa da host a LogServer
		/// per 
		/// </summary>
		/// <param name="msg"></param>
		public static void WriteMessage(string msg)
		{
			SqlConnection cn = new SqlConnection(BLBase.SqlConnectionstring);
			try
			{
				SmLogServer.WriteMessage(msg, cn);
			}
			finally
			{
				cn.Dispose();
			}
		}

	}
}