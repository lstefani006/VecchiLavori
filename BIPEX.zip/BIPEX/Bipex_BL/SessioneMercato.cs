using System;
using System.Collections;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Bipex_BLInterface;
using GME.BL;
using GME.Remoting;
using SPDriver;

namespace Bipex_BL
{
	/// <summary>
	/// Summary description for SessioneMercato.
	/// </summary>
	[RemotableServer("Bipex_BLWS", "SessioneMercato.rem")]
	public class SessioneMercato : BLBase, ISessioneMercato
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;

		public SessioneMercato(IContainer container)
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			container.Add(this);
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public SessioneMercato()
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		/// <summary>
		/// - Transisce lo stato della Sessione da Predisposta a Aperta. 
		/// Fallisce (*) quando lo stato della Sessione e' diverso da Predisposta;
		/// </summary>
		/// <returns></returns>
		public bool CurrentSessionOpen(bool proceduraForzata, out string msgErrore)
		{
			return CambiaStato("APERTA", out msgErrore, proceduraForzata);
		}

		/// <summary>
		///  - Transisce lo stato della Sessione da Aperta a Sospesa. 
		///  Fallisce (*) quando lo stato della Sessione e' diverso da Aperta;
		/// </summary>
		/// <returns></returns>
		public bool CurrentSessionSuspend(bool proceduraForzata, out string msgErrore)
		{
			return CambiaStato("SOSPESA", out msgErrore, proceduraForzata);
		}

		/// <summary>
		///  - Transisce lo stato della Sessione da Sospesa a Aperta. 
		///  Fallisce (*) quando lo stato della Sessione e' diverso da Sospesa;
		/// </summary>
		/// <returns></returns>
		public bool CurrentSessionReactivate(bool proceduraForzata, out string msgErrore)
		{
			return CambiaStato("APERTA", out msgErrore, proceduraForzata);
		}

		/// <summary>
		/// - Transisce lo stato della Sessione da Aperta a Terminata. 
		/// Fallisce (*) quando lo stato della Sessione e' diverso da Aperta;
		/// </summary>
		/// <returns></returns>
		public bool CurrentSessionTerminate(bool proceduraForzata, out string msgErrore)
		{
			return CambiaStato("TERMINATA", out msgErrore, proceduraForzata);
		}

		public DatiOfferta GetOfferta(int idOfferta)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(SqlConnectionstring))
				{
					cn.Open();
					using (GetDatiOfferta rd = new GetDatiOfferta(cn))
					{
						rd.IdOfferta = idOfferta;
						DatiOfferta r = (DatiOfferta) RecordReader.ReadOne(typeof (DatiOfferta), rd.ExecuteReader());
						return r;
					}
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}

		public DatiContratto GetContratto(string nomeContratto)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(SqlConnectionstring))
				{
					cn.Open();
					using (GetDatiContratto rd = new GetDatiContratto(cn))
					{
						rd.NomeContratto = nomeContratto;
						ArrayList rr = RecordReader.Read(typeof (DatiContratto), rd.ExecuteReader());
						if (rr.Count == 1)
							return (DatiContratto) rr[0];
						else
							return null;
					}
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}

		public DatiSessioneContratto GetSessioneContratto(string nomeContratto)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(SqlConnectionstring))
				{
					cn.Open();
					using (GetDatiSessioneContratto rd = new GetDatiSessioneContratto(cn))
					{
						rd.NomeContratto = nomeContratto;
						ArrayList rr = RecordReader.Read(typeof (DatiSessioneContratto), rd.ExecuteReader());
						if (rr.Count == 1)
							return (DatiSessioneContratto) rr[0];
						else
							return null;
					}
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}

		}

		public DatiSessione GetSessione()
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(SqlConnectionstring))
				{
					cn.Open();
					using (GetDatiSessione rd = new GetDatiSessione(cn))
					{
						rd.dummy = -1;
						ArrayList rr = RecordReader.Read(typeof (DatiSessione), rd.ExecuteReader());
						if (rr.Count == 1)
							return (DatiSessione) rr[0];
						else
							return null;
					}
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}

		}

		public DatiOreFornitura[] GetOreFornitura(string nomeContratto)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(SqlConnectionstring))
				{
					cn.Open();
					using (GetOreDiFornitura rd = new GetOreDiFornitura(cn))
					{
						rd.NomeContratto = nomeContratto;
						ArrayList rr = RecordReader.Read(typeof (DatiOreFornitura), rd.ExecuteReader());
						return (DatiOreFornitura[]) rr.ToArray(typeof (DatiOreFornitura));
					}
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}

		}


		private bool CambiaStato(string nuovoStato, out string msgErrore, bool proceduraForzata)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(SqlConnectionstring))
				{
					SqlInt32 rc = new SqlInt32();
					SqlString m = new SqlString();
					SessioneCorrente_CambiaStato.Execute(cn, nuovoStato, proceduraForzata ? 1 : 0, ref rc, ref m);

					msgErrore = m.Value;

					try
					{
						ICacheUpdater cu = (ICacheUpdater) RemotingHelper.GetObject(typeof (ICacheUpdater));
						cu.OnSessioneMercato();
					}
					catch (Exception ex)
					{
						smError(ex);
					}


					return rc.Value > 0;
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}

		}

		public OperatoreOTC[] GetListaOperatoriOTC(string codiceOperatore)
		{
			try
			{
				using (SqlConnection cn = new SqlConnection(SqlConnectionstring))
				{
					cn.Open();
					using (GetListaOperatoriOTC rd = new GetListaOperatoriOTC(cn))
					{
						rd.codiceOperatore = codiceOperatore;
						ArrayList rr = RecordReader.Read(typeof (OperatoreOTC), rd.ExecuteReader());
						return (OperatoreOTC[]) rr.ToArray(typeof (OperatoreOTC));
					}
				}
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}

		}
	}
}