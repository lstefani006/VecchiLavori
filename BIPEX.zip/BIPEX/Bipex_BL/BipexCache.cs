using System;
using System.Collections;
using System.Diagnostics;
using Bipex_BLInterface;
using Delta;
using GME.Utility;

namespace Bipex_BL
{
	public delegate void BipexCacheUpdatedDelegate(string SubjectType, string SubjectSubType, DataRecordList v2);

	/// <summary>
	/// Classe lato server che implementa la cache dell'ultimo book riassuntivo, book singolo contratto ecc.
	/// La chiave e` SubjectType - BR BO
	/// La sottochiave e` l'indentificatore del contratto (tipicamente)
	/// Ogni chiave/sottochiave corrisponde ad una lista di informazioni omogenee storicizzate per versione.
	/// Ogni cliente richiede l'ultima versione speificando chiave/sottochiave e la versione attualmente
	/// in suo possesso. <c>BipexCache</c> ritorna l'ultima versione eventualmente come differenza
	/// tra l'ultima e quella del cliente.
	/// Nel server esiste una sola istanza di <c>BipexCache</c> assegnabile con <paramref name='G'/>.
	/// La cache deve essere precaricata con tutte le coppie chiave/sottochiave.
	/// </summary>
	public class BipexCache
	{
		public static BipexCache G
		{
			get 
			{ 
				if (_g == null) 
					_g = new BipexCache(); 
				return _g; }
		}
		private static BipexCache _g = null;
		private BipexCache()
		{
			// this._dataDiMercato = DateTime.Now.Date;
			this._listBySubjectType = new ListBySubjectType();
		}

		////////////////////
		

		public event BipexCacheUpdatedDelegate BipexCacheUpdated;

		public ResponseOfBipexSubjects Elabora(RequestOfBipexSubjects req)
		{
			lock (this)
			{
				ResponseOfBipexSubjects resp = new ResponseOfBipexSubjects();

				for (int i = 0; i < req.Count; ++i)
				{
					DataRecordList v = Elabora(req[i]);
					resp.Add(v);
				}

				return resp;
			}
		}

		private DataRecordList Elabora(BipexSubject bs)
		{
			if (bs.Subscribe != null)
			{
				ArrayList sbList = new ArrayList();
				foreach (BipexSubscribe subscribe in bs.Subscribe)
				{
					if (subscribe is BipexSubscribe_SaldoFisico)
					{
						BipexSubscribe_SaldoFisico fs = (BipexSubscribe_SaldoFisico)subscribe;

						Subscribe_SaldoFisico_Data sfd = new Subscribe_SaldoFisico_Data();
						sfd.CodiceOperatore = fs.CodiceOperatore;
						sfd.DataDelivery = fs.DataDelivery;

						sbList.Add(sfd);
					}
				}

				try
				{
					ISubscribe sb= (ISubscribe) GME.Remoting.RemotingHelper.GetObject(typeof(ISubscribe));
					Subscribe_SaldoFisico_Data [] sfd = (Subscribe_SaldoFisico_Data[]) sbList.ToArray(typeof(Subscribe_SaldoFisico_Data));
					sb.Subscribe_SaldoFisico(sfd);

				}
				catch (Exception ex)
				{
					GME.Log.smError(ex);
				}
			}



// TODO togliere le date
//			if (bs.DataDiMercato.Date != _dataDiMercato)
//				return null;
			Debug.WriteLine(string.Format("{0}, {1}", bs.SubjectType, bs.SubjectSubType));

			ListBySubjectSubType listBySubjectSubType = _listBySubjectType[bs.SubjectType];
			if (listBySubjectSubType == null)
				throw new ApplicationException("ListBySubjectSubType non presente");

			ListByVersion listByVersion = listBySubjectSubType[bs.SubjectSubType];
			if (listByVersion == null)
				throw new ApplicationException("ListByVersion non presente");

			DataRecordList r = Elabora(bs, listByVersion);



			return r;
		}

		private static DataRecordList Elabora(BipexSubject bs, ListByVersion listByVersion)
		{
			DataRecordList V1 = listByVersion.GetVersion(bs.Version);
			DataRecordList V2 = listByVersion.GetLastVersion();


			if (V2 == null)
			{
				// mi richiede un informazione non ancora disponibile....
			}


			if (V1 == null)
			{
				// non esiste la versione v1 --> ritorno l'ultima
				// anche se v2 non esiste ancora/piu`
				V2 = ElaboraFiltro(V2, bs.Filter);
				return V2;
			}

			// esistono entrambi le versioni

			// filtro i record delle due versioni ... ottengo 2 liste con meno record
			V1 = ElaboraFiltro(V1, bs.Filter);
			V2 = ElaboraFiltro(V2, bs.Filter);

			// faccio il delta
			DataRecordList r = DataRecordList.BestDiff(V2, V1);

			return r;
		}

		private static DataRecordList ElaboraFiltro(DataRecordList v, BipexSubjectFilter f)
		{
			if (f == null)
				return v;
			return f.Filter(v);
		}

		public void Update(string SubjectType, string SubjectSubType, DataRecordList v2)
		{
			lock (this)
			{
				ListBySubjectSubType listBySubjectSubType = _listBySubjectType[SubjectType];
				if (listBySubjectSubType == null)
				{
					// throw new ApplicationException("Aggiorna: SubjectType " + SubjectType + " non trovato");

					listBySubjectSubType = new ListBySubjectSubType();
					_listBySubjectType.Add(SubjectType, listBySubjectSubType);
				}

				ListByVersion listByVersion = listBySubjectSubType[SubjectSubType];
				if (listByVersion == null)
				{
					listByVersion = new ListByVersion();
					listBySubjectSubType.Add(SubjectSubType, listByVersion);
				}

				listBySubjectSubType[SubjectSubType].Add(v2);
			}

			if (this.BipexCacheUpdated != null)
				this.BipexCacheUpdated(SubjectType, SubjectSubType, v2);
		}

		public DataRecordList GetLastVersion(string SubjectType, string SubjectSubType)
		{
			lock (this)
			{
				ListBySubjectSubType listBySubjectSubType = _listBySubjectType[SubjectType];
				if (listBySubjectSubType == null)
					throw new ApplicationException("SubjectType non torvato");

				ListByVersion listByVersion = listBySubjectSubType[SubjectSubType];
				DataRecordList dataRecordList = listByVersion.GetLastVersion();
				if (dataRecordList == null)
					throw new ApplicationException("Versione non trovata.");
				return dataRecordList;
			}
		}

		public void SetMaxNumberOfVersionsInCache(int max)
		{
			ListByVersion.SetMaxNumberOfVersionsInCache(max);
		}

		ListBySubjectType _listBySubjectType;
		//DateTime _dataDiMercato;
	}


	public class ListBySubjectType
	{
		SortedList _s = new SortedList();

		public ListBySubjectSubType this [string Type]
		{
			get { return (ListBySubjectSubType) _s[Type]; }
		}

		public void Add(string Type, ListBySubjectSubType lbt)
		{
			Debug.Assert(_s.IndexOfKey(Type) < 0);
			_s.Add(Type,  lbt);
		}

		public int Count { get { return _s.Count; } }
		public string GetSubjectType(int i)
		{
			return (string)_s.GetKey(i);
		}
		public ListBySubjectSubType GetListBySubjectSubType(int i)
		{
			return (ListBySubjectSubType) _s.GetByIndex(i);
		}
	}


	public class ListBySubjectSubType
	{
		SortedList _s = new SortedList();

		public ListByVersion this [string SubType]
		{
			get { return (ListByVersion) _s[SubType]; }
		}

		public void Add(string SubType, ListByVersion lbv)
		{
			Debug.Assert(_s.IndexOfKey(SubType) < 0);
			_s.Add(SubType,  lbv);
		}

		public int Count { get { return _s.Count; } }
		public string GetSubjectSubType(int i)
		{
			return (string)_s.GetKey(i);
		}
		public ListByVersion GetListByVersion(int i)
		{
			return (ListByVersion) _s.GetByIndex(i);
		}
	}

	public class ListByVersion
	{
		ArrayList ar = new ArrayList();
		static int MaxNumberOfVersionsInCache = 100;

		static public void SetMaxNumberOfVersionsInCache(int max)
		{
			MaxNumberOfVersionsInCache = max;
		}

		private int Count { get { return ar.Count; } }
		private DataRecordList this [int i] { get { return (DataRecordList) ar[i]; } }

		/// <summary>
		/// Ritorna l'ultima versione, null se non esiste
		/// </summary>
		/// <returns></returns>
		public DataRecordList GetLastVersion()
		{
			if (Count == 0)
				return null;

			return this[Count - 1];
		}

		/// <summary>
		/// Ritorna la versione indicata come parametro
		/// </summary>
		/// <param name="Version"></param>
		/// <returns></returns>
		public DataRecordList GetVersion(int Version)
		{
			for (int i = 0; i < this.Count; ++i)
			{
				if (this[i].Version == Version)
				{
					return this[i];
				}
			}

			return null;
		}

		/// <summary>
		/// Aggiunge una nuova versione alla lista delle versioni disponibili.
		/// Se la versione di <paramref name='vl'/> e` zero si intende che la stessa venga inserita
		/// nella lista come versione piu` recente.
		/// </summary>
		/// <param name="vl"></param>
		public void Add(DataRecordList vl)
		{
			if (this.Count > MaxNumberOfVersionsInCache)
			{
				this.ar.RemoveAt(0);
			}

			if (vl.Version != 0)
				throw new ApplicationException("la versione inserita non ha versione zero");

			int nextVersion = 1;
			if (this.Count > 0)
				nextVersion = this[this.Count - 1].Version + 1;

			vl.Version = nextVersion;
			ar.Add(vl);
		}

		public void AddEmptySubject(DataRecordList vl)
		{
			Debug.Assert(this.Count == 0);

			ar.Add(vl);
		}

		/// <summary>
		/// svuota la cache
		/// </summary>
		public void Reset()
		{
			ar = new ArrayList();
		}

	}
}