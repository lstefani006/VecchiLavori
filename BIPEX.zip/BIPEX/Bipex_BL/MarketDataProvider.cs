using System;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Bipex_BLInterface;
using Delta;
using GME.BL;
using SPDriver;

namespace Bipex_BL
{
	/// <summary>
	/// Summary description for MarketDataProvider.
	/// </summary>
	[RemotableServer("Bipex_ControlWS", "MarketDataProvider.rem")]
	public class MarketDataProvider : BLBase, IMarketDataProvider
	{
		#region Costruttori ecc ecc
		private System.ComponentModel.Container components = null;

		public MarketDataProvider(System.ComponentModel.IContainer container)
		{
			container.Add(this);
			InitializeComponent();
		}

		public MarketDataProvider()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		#endregion

		/// <summary>
		/// Elabora un RequestOfBipexSubjects per ottenere un ResponseOfBipexSubjects.
		/// I dati sono in byte[] sia in ingresso che in uscita.
		/// </summary>
		/// <param name="rq">richiesta</param>
		/// <returns>risposta</returns>
		public byte [] GetLastMarketDataVersion(byte [] rq)
		{
			try
			{
				ICompactSerializable icsRq = CompactFormatter.ReadObject(rq);
				RequestOfBipexSubjects request = (RequestOfBipexSubjects) icsRq;

				ResponseOfBipexSubjects resp = Elabora(request);

				return CompactFormatter.WriteObject(resp, CompressionType.Best);
			}
			catch (Exception ex)
			{
				smError(ex);
				throw;
			}
		}

		private ResponseOfBipexSubjects Elabora(RequestOfBipexSubjects request)
		{
			ResponseOfBipexSubjects r = BipexCache.G.Elabora(request);
			return r;
		}

		public void SetMaxNumberOfVersionsInCache(int max)
		{
			BipexCache.G.SetMaxNumberOfVersionsInCache(max);
		}


	}
}
