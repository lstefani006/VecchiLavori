using System; 
using System.Data; 
using System.Data.SqlClient; 
using System.Data.SqlTypes; 
using System.Collections;
using System.Reflection;

namespace SPDriver 
{
	#region RecordReaderBase

	public class RecordReaderBase : IDisposable
	{
		protected SqlCommand _cmd = null;
		protected SqlDataReader _reader = null;

		protected RecordReaderBase(SqlConnection cn)
		{
			_cmd = new SqlCommand();
			_cmd.CommandType = CommandType.StoredProcedure;
			_cmd.Connection = cn;
		}

		public void CloseReader()
		{
			if (_reader != null && !_reader.IsClosed)
			{
				_reader.Close();
				_reader = null;
			}
		}

		public void Close()
		{
			CloseReader();

			if (_cmd != null)
			{
				_cmd.Dispose();
				_cmd = null;
			}
		}

		public void Dispose()
		{
			Close();
		}

		public SqlDataReader ExecuteReader()
		{
			SqlTransaction tr = null;
			return ExecuteReader(tr);
		}

		public SqlDataReader ExecuteReader(SqlTransaction tr)
		{
			if (_cmd.Connection.State == ConnectionState.Closed)
				_cmd.Connection.Open();

			_cmd.Transaction = tr;
			_reader = _cmd.ExecuteReader();
			return _reader;
		}

		public ArrayList ExecuteReader(Type recordType)
		{
			SqlTransaction tr = null;
			ArrayList r = ExecuteReader(tr, recordType);
			return r;
		}

		public ArrayList[] ExecuteReader(params Type[] recordTypeList)
		{
			SqlTransaction tr = null;
			ArrayList[] r = ExecuteReader(tr, recordTypeList);
			return r;
		}

		public ArrayList[] ExecuteReader(SqlTransaction tr, params Type[] recordTypeList)
		{
			try
			{
				if (tr == null)
					ExecuteReader();
				else
					ExecuteReader(tr);

				ArrayList[] ret = new ArrayList[recordTypeList.Length];

				object[] idr = new object[1];
				idr[0] = (IDataReader) _reader;


				for (int recordTypeIndex = 0; recordTypeIndex < recordTypeList.Length; ++recordTypeIndex)
				{
					Type recordType = recordTypeList[recordTypeIndex];

					if (!recordType.IsClass)
						throw new ArgumentNullException("recordType", "deve essere una classe!");

					ConstructorInfo ci = recordType.GetConstructor(new Type[] {});
					if (ci == null)
						throw new ArgumentException("recordType",
								string.Format("{0}.ExecuteReader: {1} deve avere un costruttore senza parametri", this.GetType().Name, recordType.Name));

					MethodInfo mi = recordType.GetMethod("Read", new Type[] {typeof (IDataReader)});
					if (mi == null)
						throw new ArgumentException("recordType", 
								string.Format("{0}.ExecuteReader: {1} deve implementare Read(IDataReader rd)", this.GetType().Name, recordType.Name));

					ArrayList r = new ArrayList();

					while (_reader.Read())
					{
						object record = ci.Invoke(null);
						mi.Invoke(record, idr);
						r.Add(record);
					}
					ret[recordTypeIndex] = r;

					if (!_reader.NextResult())
						break;
				}

				return ret;
			}
			finally
			{
				CloseReader();
			}
		}

		public ArrayList ExecuteReader(SqlTransaction tr, Type recordType)
		{
			try
			{
				if (tr == null)
					ExecuteReader();
				else
					ExecuteReader(tr);

				object[] idr = new object[1];
				idr[0] = (IDataReader) _reader;


				if (!recordType.IsClass)
					throw new ArgumentNullException("recordType", "deve essere una classe!");

				ConstructorInfo ci = recordType.GetConstructor(new Type[] {});
				if (ci == null)
					throw new ArgumentException("recordType",
						string.Format("{0}.ExecuteReader: {1} deve avere un costruttore senza parametri", this.GetType().Name, recordType.Name));

				MethodInfo mi = recordType.GetMethod("Read", new Type[] {typeof (IDataReader)});
				if (mi == null)
					throw new ArgumentException("recordType", 
						string.Format("{0}.ExecuteReader: {1} deve implementare Read(IDataReader rd)", this.GetType().Name, recordType.Name));

				ArrayList r = new ArrayList();

				while (_reader.Read())
				{
					object record = ci.Invoke(null);
					mi.Invoke(record, idr);
					r.Add(record);
				}

				return r;
			}
			finally
			{
				CloseReader();
			}
		}

	}
	#endregion


	public class SessioneCorrente_Offerta : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmContratto;

		public SessioneCorrente_Offerta(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_Offerta]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmContratto = _cmd.Parameters.Add("@Contratto", SqlDbType.NVarChar);
			_prmContratto.Size = 30;
			_prmContratto.IsNullable = true;
			_prmContratto.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlString Contratto
		{
			get
			{
				if (_prmContratto.Value != null)
				{
					if (_prmContratto.Value == DBNull.Value) return SqlString.Null;
					if (_prmContratto.Value is SqlString) return (SqlString) _prmContratto.Value; 
				}
			   	return new SqlString((string)_prmContratto.Value); 
			}
			set
			{
				_prmContratto.Value = value; 
			}
		}

	}

	public class SessioneCorrente_BookRiassuntivo : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmdummy;

		public SessioneCorrente_BookRiassuntivo(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_BookRiassuntivo]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmdummy = _cmd.Parameters.Add("@dummy", SqlDbType.Int);
			_prmdummy.IsNullable = true;
			_prmdummy.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlInt32 dummy
		{
			get
			{
				if (_prmdummy.Value != null)
				{
					if (_prmdummy.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmdummy.Value is SqlInt32) return (SqlInt32) _prmdummy.Value; 
				}
			   	return new SqlInt32((int)_prmdummy.Value); 
			}
			set
			{
				_prmdummy.Value = value; 
			}
		}

	}

	public class SessioneCorrente_BookSingoloContratto : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmContratto;

		public SessioneCorrente_BookSingoloContratto(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_BookSingoloContratto]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmContratto = _cmd.Parameters.Add("@Contratto", SqlDbType.NVarChar);
			_prmContratto.Size = 30;
			_prmContratto.IsNullable = true;
			_prmContratto.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlString Contratto
		{
			get
			{
				if (_prmContratto.Value != null)
				{
					if (_prmContratto.Value == DBNull.Value) return SqlString.Null;
					if (_prmContratto.Value is SqlString) return (SqlString) _prmContratto.Value; 
				}
			   	return new SqlString((string)_prmContratto.Value); 
			}
			set
			{
				_prmContratto.Value = value; 
			}
		}

	}

	public class SessioneCorrente_DailyActivity : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmdummy;

		public SessioneCorrente_DailyActivity(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_DailyActivity]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmdummy = _cmd.Parameters.Add("@dummy", SqlDbType.Int);
			_prmdummy.IsNullable = true;
			_prmdummy.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlInt32 dummy
		{
			get
			{
				if (_prmdummy.Value != null)
				{
					if (_prmdummy.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmdummy.Value is SqlInt32) return (SqlInt32) _prmdummy.Value; 
				}
			   	return new SqlInt32((int)_prmdummy.Value); 
			}
			set
			{
				_prmdummy.Value = value; 
			}
		}

	}

	public class SessioneCorrente_DailyActivityLog : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmlastDailyActivity;

		public SessioneCorrente_DailyActivityLog(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_DailyActivityLog]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmlastDailyActivity = _cmd.Parameters.Add("@lastDailyActivity", SqlDbType.Int);
			_prmlastDailyActivity.IsNullable = true;
			_prmlastDailyActivity.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlInt32 lastDailyActivity
		{
			get
			{
				if (_prmlastDailyActivity.Value != null)
				{
					if (_prmlastDailyActivity.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmlastDailyActivity.Value is SqlInt32) return (SqlInt32) _prmlastDailyActivity.Value; 
				}
			   	return new SqlInt32((int)_prmlastDailyActivity.Value); 
			}
			set
			{
				_prmlastDailyActivity.Value = value; 
			}
		}

	}

	public class SessioneCorrente_MarketSession : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmdummy;

		public SessioneCorrente_MarketSession(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_MarketSession]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmdummy = _cmd.Parameters.Add("@dummy", SqlDbType.Int);
			_prmdummy.IsNullable = true;
			_prmdummy.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlInt32 dummy
		{
			get
			{
				if (_prmdummy.Value != null)
				{
					if (_prmdummy.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmdummy.Value is SqlInt32) return (SqlInt32) _prmdummy.Value; 
				}
			   	return new SqlInt32((int)_prmdummy.Value); 
			}
			set
			{
				_prmdummy.Value = value; 
			}
		}

	}

	public class SessioneCorrente_OpenOrders : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmdummy;

		public SessioneCorrente_OpenOrders(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_OpenOrders]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmdummy = _cmd.Parameters.Add("@dummy", SqlDbType.Int);
			_prmdummy.IsNullable = true;
			_prmdummy.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlInt32 dummy
		{
			get
			{
				if (_prmdummy.Value != null)
				{
					if (_prmdummy.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmdummy.Value is SqlInt32) return (SqlInt32) _prmdummy.Value; 
				}
			   	return new SqlInt32((int)_prmdummy.Value); 
			}
			set
			{
				_prmdummy.Value = value; 
			}
		}

	}

	public class SessioneCorrente_SaldoFisico : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prms;

		public SessioneCorrente_SaldoFisico(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_SaldoFisico]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prms = _cmd.Parameters.Add("@s", SqlDbType.VarChar);
			_prms.Size = 2000;
			_prms.IsNullable = true;
			_prms.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlString s
		{
			get
			{
				if (_prms.Value != null)
				{
					if (_prms.Value == DBNull.Value) return SqlString.Null;
					if (_prms.Value is SqlString) return (SqlString) _prms.Value; 
				}
			   	return new SqlString((string)_prms.Value); 
			}
			set
			{
				_prms.Value = value; 
			}
		}

	}

	public class SessioneCorrente_ListaContratti : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmdummy;

		public SessioneCorrente_ListaContratti(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[SessioneCorrente_ListaContratti]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmdummy = _cmd.Parameters.Add("@dummy", SqlDbType.Int);
			_prmdummy.IsNullable = true;
			_prmdummy.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlInt32 dummy
		{
			get
			{
				if (_prmdummy.Value != null)
				{
					if (_prmdummy.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmdummy.Value is SqlInt32) return (SqlInt32) _prmdummy.Value; 
				}
			   	return new SqlInt32((int)_prmdummy.Value); 
			}
			set
			{
				_prmdummy.Value = value; 
			}
		}

	}

	public class GetDatiContratto : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmNomeContratto;

		public GetDatiContratto(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[GetDatiContratto]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmNomeContratto = _cmd.Parameters.Add("@NomeContratto", SqlDbType.NVarChar);
			_prmNomeContratto.Size = 30;
			_prmNomeContratto.IsNullable = true;
			_prmNomeContratto.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlString NomeContratto
		{
			get
			{
				if (_prmNomeContratto.Value != null)
				{
					if (_prmNomeContratto.Value == DBNull.Value) return SqlString.Null;
					if (_prmNomeContratto.Value is SqlString) return (SqlString) _prmNomeContratto.Value; 
				}
			   	return new SqlString((string)_prmNomeContratto.Value); 
			}
			set
			{
				_prmNomeContratto.Value = value; 
			}
		}

	}

	public class GetDatiOfferta : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmIdOfferta;

		public GetDatiOfferta(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[GetDatiOfferta]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmIdOfferta = _cmd.Parameters.Add("@IdOfferta", SqlDbType.Int);
			_prmIdOfferta.IsNullable = true;
			_prmIdOfferta.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlInt32 IdOfferta
		{
			get
			{
				if (_prmIdOfferta.Value != null)
				{
					if (_prmIdOfferta.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmIdOfferta.Value is SqlInt32) return (SqlInt32) _prmIdOfferta.Value; 
				}
			   	return new SqlInt32((int)_prmIdOfferta.Value); 
			}
			set
			{
				_prmIdOfferta.Value = value; 
			}
		}

	}

	public class GetDatiSessioneContratto : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmNomeContratto;

		public GetDatiSessioneContratto(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[GetDatiSessioneContratto]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmNomeContratto = _cmd.Parameters.Add("@NomeContratto", SqlDbType.NVarChar);
			_prmNomeContratto.Size = 30;
			_prmNomeContratto.IsNullable = true;
			_prmNomeContratto.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlString NomeContratto
		{
			get
			{
				if (_prmNomeContratto.Value != null)
				{
					if (_prmNomeContratto.Value == DBNull.Value) return SqlString.Null;
					if (_prmNomeContratto.Value is SqlString) return (SqlString) _prmNomeContratto.Value; 
				}
			   	return new SqlString((string)_prmNomeContratto.Value); 
			}
			set
			{
				_prmNomeContratto.Value = value; 
			}
		}

	}

	public class GetDatiSessione : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmdummy;

		public GetDatiSessione(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[GetDatiSessione]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmdummy = _cmd.Parameters.Add("@dummy", SqlDbType.Int);
			_prmdummy.IsNullable = true;
			_prmdummy.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlInt32 dummy
		{
			get
			{
				if (_prmdummy.Value != null)
				{
					if (_prmdummy.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmdummy.Value is SqlInt32) return (SqlInt32) _prmdummy.Value; 
				}
			   	return new SqlInt32((int)_prmdummy.Value); 
			}
			set
			{
				_prmdummy.Value = value; 
			}
		}

	}

	public class GetOreDiFornitura : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmNomeContratto;

		public GetOreDiFornitura(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[GetOreDiFornitura]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmNomeContratto = _cmd.Parameters.Add("@NomeContratto", SqlDbType.NVarChar);
			_prmNomeContratto.Size = 30;
			_prmNomeContratto.IsNullable = true;
			_prmNomeContratto.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlString NomeContratto
		{
			get
			{
				if (_prmNomeContratto.Value != null)
				{
					if (_prmNomeContratto.Value == DBNull.Value) return SqlString.Null;
					if (_prmNomeContratto.Value is SqlString) return (SqlString) _prmNomeContratto.Value; 
				}
			   	return new SqlString((string)_prmNomeContratto.Value); 
			}
			set
			{
				_prmNomeContratto.Value = value; 
			}
		}

	}

	public class GetListaOperatoriOTC : RecordReaderBase
	{
		private SqlParameter _prmRETURN_VALUE;
		private SqlParameter _prmcodiceOperatore;

		public GetListaOperatoriOTC(SqlConnection cn)
			: base(cn)
		{
			_cmd.CommandText = "[dbo].[GetListaOperatoriOTC]";

			_prmRETURN_VALUE = _cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
			_prmRETURN_VALUE.IsNullable = true;
			_prmRETURN_VALUE.Direction = ParameterDirection.ReturnValue;

			_prmcodiceOperatore = _cmd.Parameters.Add("@codiceOperatore", SqlDbType.VarChar);
			_prmcodiceOperatore.Size = 8;
			_prmcodiceOperatore.IsNullable = true;
			_prmcodiceOperatore.Direction = ParameterDirection.Input;
		}


		public SqlInt32 RETURN_VALUE
		{
			get
			{
				if (_prmRETURN_VALUE.Value != null)
				{
					if (_prmRETURN_VALUE.Value == DBNull.Value) return SqlInt32.Null;
					if (_prmRETURN_VALUE.Value is SqlInt32) return (SqlInt32) _prmRETURN_VALUE.Value; 
				}
			   	return new SqlInt32((int)_prmRETURN_VALUE.Value); 
			}
		}

		public SqlString codiceOperatore
		{
			get
			{
				if (_prmcodiceOperatore.Value != null)
				{
					if (_prmcodiceOperatore.Value == DBNull.Value) return SqlString.Null;
					if (_prmcodiceOperatore.Value is SqlString) return (SqlString) _prmcodiceOperatore.Value; 
				}
			   	return new SqlString((string)_prmcodiceOperatore.Value); 
			}
			set
			{
				_prmcodiceOperatore.Value = value; 
			}
		}

	}
}

