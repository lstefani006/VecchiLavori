using System.Runtime.Remoting.Messaging;

namespace Bipex_BLInterface
{
	[RemotableClient("Bipex_BLWS", "LogServer.rem")]
	public interface ILogServer
	{
		void Write(string msg);
	}
}