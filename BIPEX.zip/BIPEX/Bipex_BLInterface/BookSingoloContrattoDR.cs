using System;
using System.Diagnostics;
using Delta;

namespace Bipex_BLInterface
{
	/// <summary>
	/// SubjectType="BS"
	/// SubjectSubType=Contract
	/// </summary>
	public class BookSingoloContrattoDR : DataRecord 
	{
		public const string SubjectType = "BS";
		public const string SubjectSubType = null; // significa che bisogna iterare tutti i contratti


		[DR(DRE.PrimaryKey)] public string   Contract;
		[DR]                 public short    Hours;
		[DR]                 public DateTime TradingFrom;
		[DR]                 public DateTime TradingTo;
		[DR]                 public DateTime DeliveryFrom;
		[DR]                 public DateTime DeliveryTo;

		[DR(DRE.Nullable)]   public double   LastPrice;
		[DR(DRE.Nullable)]   public int      LastQty;
		[DR(DRE.Nullable)]   public DateTime LastTime;
		[DR(DRE.Nullable)]   public bool     LastIsOTC;

		[DR(DRE.Nullable)]   public double   MaxPrice;

		[DR(DRE.Nullable)]   public double   MinPrice;

		[DR(DRE.Nullable)]   public int      Volume;
		[DR(DRE.Nullable)]   public double   ConvPrice;
		[DR(DRE.Nullable)]   public double   OffPrice;
		[DR(DRE.Nullable)]   public double   RefPrice;

		public bool MaxPriceEqLastAbb
		{
			get
			{
				if (IsNull("MaxPrice") || IsNull("LastPrice")) return false;
				return MaxPrice == LastPrice;
			}
		}
		public bool MinPriceEqLastAbb
		{
			get 
			{
				if (IsNull("MinPrice") || IsNull("LastPrice")) return false;
				return MinPrice == LastPrice;
			}
	}


		public BookSingoloContrattoDR()
		{
			foreach (CompactFormatterData c in CFT.Nullable)
				this.SetNull(c);
		}
	}

	/// <summary>
	/// SubjectType="OF"
	/// SubjectSubType=Contract
	/// </summary>
	public class OffertaDR : DataRecord
	{
		public const string SubjectType = "OF";
		public const string SubjectSubType = null; // significa che bisogna iterare tutti i contratti

		[Flags] public enum Indicator : byte 
		{
			None = 0,

			// bit 0/1
			BestBidTrendUP    =  (1 << 0),
			BestBidTrendDown  =  (1 << 1),

			// bit 2/3
			BestAskTrendUP    =  (1 << 2),
			BestAskTrendDown  =  (1 << 3),
		}

		public static bool IsBestBidTrendUP(Indicator i)    { return (i & Indicator.BestBidTrendUP)   > 0; } 
		public static bool IsBestBidTrendDown(Indicator i)  { return (i & Indicator.BestBidTrendDown) > 0; }
		public static bool IsBestAskTrendUP(Indicator i)    { return (i & Indicator.BestAskTrendUP)   > 0; }
		public static bool IsBestAskTrendDown(Indicator i)  { return (i & Indicator.BestAskTrendDown) > 0; }

		// Servono per simulazione...
//		public void SetBestBidTrendUP()    
//		{ 
//			Indicators |= Indicator.BestBidTrendUP; 
//			Indicators &= ~Indicator.BestBidTrendDown; 
//		} 
//		public void SetBestBidTrendDown()  
//		{ 
//			Indicators &= ~Indicator.BestBidTrendUP; 
//			Indicators |= Indicator.BestBidTrendDown; 
//		}
		public void SetBestBidTrendStopped()  
		{ 
			Indicators &= ~Indicator.BestBidTrendUP; 
			Indicators &= ~Indicator.BestBidTrendDown; 
		}
//		public void SetBestAskTrendUP()    
//		{ 
//			Indicators |= Indicator.BestAskTrendUP; 
//			Indicators &= ~Indicator.BestAskTrendDown; 
//		}
//		public void SetBestAskTrendDown()  
//		{ 
//			Indicators &= ~Indicator.BestAskTrendUP;
//			Indicators |= Indicator.BestAskTrendDown; 
//		}
		public void SetBestAskTrendStopped()  
		{ 
			Indicators &= ~Indicator.BestAskTrendUP;
			Indicators &= ~Indicator.BestAskTrendDown; 
		}

		[DR(DRE.PrimaryKey)] public int		  PosizioneBook;


		[DR(DRE.Nullable)]   public int 	  BidIdOfferta;
		[DR(DRE.Nullable)]   public double	  BidPrice;
		[DR(DRE.Nullable)]   public int		  BidQty;
		[DR(DRE.Nullable)]   public DateTime  BidTime;
		[DR(DRE.Nullable)]   public string	  BidOperator = string.Empty;
		[DR(DRE.Nullable)]   public string    BidOTCOperator = string.Empty;
		[DR(DRE.Nullable)]   public string    BidOTCCode = string.Empty;

		[DR(DRE.Nullable)]   public int 	  AskIdOfferta;
		[DR(DRE.Nullable)]   public double	  AskPrice;
		[DR(DRE.Nullable)]   public int		  AskQty;
		[DR(DRE.Nullable)]   public DateTime  AskTime;
		[DR(DRE.Nullable)]   public string	  AskOperator = string.Empty;
		[DR(DRE.Nullable)]   public string    AskOTCOperator = string.Empty;
		[DR(DRE.Nullable)]   public string    AskOTCCode = string.Empty;

		[DR]                 public Indicator Indicators = Indicator.None;
		[DR(DRE.Nullable)]   public DateTime  IndicatorBidChangeTS;
		[DR(DRE.Nullable)]   public DateTime  IndicatorAskChangeTS;

		public OffertaDR()
		{
			foreach (CompactFormatterData c in CFT.Nullable)
				this.SetNull(c);
		}

		public OffertaDR(int posizioneBook, int bidIdOfferta, int askIdOfferta)
		{
			this.PosizioneBook = posizioneBook;

			this.Indicators = Indicator.None;

			// lato Bid
			bool BidNull = bidIdOfferta < 0;
			this.SetOffertaNull("Bid", BidNull);
			if (!BidNull)
				this.BidIdOfferta = bidIdOfferta;

			// lato Ask
			bool AskNull = askIdOfferta < 0;
			this.SetOffertaNull("Ask", AskNull);
			if (!AskNull)
				this.AskIdOfferta = askIdOfferta;
		}

		void SetOffertaNull(string tipoOfferta, bool v)
		{
			Debug.Assert(tipoOfferta == "Ask" || tipoOfferta == "Bid");

			this.SetNull(tipoOfferta + "IdOfferta", v);
			this.SetNull(tipoOfferta + "Price",     v);
			this.SetNull(tipoOfferta + "Qty",       v);
			this.SetNull(tipoOfferta + "Operator",  v);

			// si suppone che NON sia OTC
			this.SetNull(tipoOfferta + "OTCOperator", true);
			this.SetNull(tipoOfferta + "OTCCode",     true);
		}
	}
}
