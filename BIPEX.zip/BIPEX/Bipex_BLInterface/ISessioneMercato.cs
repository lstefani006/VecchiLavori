using System;
using System.IO;
using SPDriver;

namespace Bipex_BLInterface
{
	[RemotableClient("Bipex_BLWS", "SessioneMercato.rem")]
	public interface ISessioneMercato
	{
		/// <summary>
		/// - Transisce lo stato della Sessione da Predisposta a Aperta. 
		/// Fallisce (*) quando lo stato della Sessione e' diverso da Predisposta;
		/// </summary>
		/// <returns></returns>
		bool CurrentSessionOpen(bool proceduraForzata, out string msgErrore);

		
		/// <summary>
		///  - Transisce lo stato della Sessione da Aperta a Sospesa. 
		///  Fallisce (*) quando lo stato della Sessione e' diverso da Aperta;
		/// </summary>
		/// <returns></returns>
		bool CurrentSessionSuspend(bool proceduraForzata, out string msgErrore);

		/// <summary>
		///  - Transisce lo stato della Sessione da Sospesa a Aperta. 
		///  Fallisce (*) quando lo stato della Sessione e' diverso da Sospesa;
		/// </summary>
		/// <returns></returns>
		bool CurrentSessionReactivate(bool proceduraForzata, out string msgErrore);
		
	
		/// <summary>
		/// - Transisce lo stato della Sessione da Aperta a Terminata. 
		/// Fallisce (*) quando lo stato della Sessione e' diverso da Aperta;
		/// </summary>
		/// <returns></returns>
		bool CurrentSessionTerminate (bool proceduraForzata, out string msgErrore);



		DatiOfferta GetOfferta(int idOfferta);
		DatiContratto GetContratto(string nomeContratto);
		DatiSessioneContratto GetSessioneContratto(string nomeContratto);
		DatiSessione GetSessione();
		DatiOreFornitura [] GetOreFornitura(string nomeContratto);

		OperatoreOTC [] GetListaOperatoriOTC(string codiceOperatore);

	}



	/*
	[Serializable]
	public class DatiOfferta
	{
		public int           IdOfferta;
		public string        NomeContratto;

		public string        CodiceUtente;
		public DateTime      TSCreazione;
		public Offerta_Tipo  TipoOfferta;

		public bool          OffertaNelBook;
		public Offerta_Stato StatoOfferta;

		public int           QuantitaIniziale;
		public int           QuantitaResidua;

		public double        Prezzo;

		public DateTime      TSPrioritaAbbinamento;
		public string        Note;

		public string        OperatoreOTC;
		public string        CodiceOTC;
	}
	*/
	/*
	[Serializable]
	public class DatiContratto
	{
		public string    NomeContratto;
		public int       IdContratto;
		public DateTime  DataInizioTrading;
		public DateTime  DataFineTrading;
		public DateTime  DataInizioDelivery;
		public DateTime  DataFineDelivery;
		public string    CodiceProfilo;
		public string    DescrizioneContratto;
		public string    CodiceZonaRiferimento;
		public string    DurataDelivery;

		public int       OreFornituraFeriali;
		public int       OreFornituraFestive;
	}
	*/
	/*
	[Serializable]
	public class DatiSessioneContratto
	{
		public string    NomeContratto;

		public bool      BidIdOffertaNull;
		public int       BidIdOfferta;
		public double    BidPrice;
		public int       BidQty;
		public string    BidCodiceOperatore;
		public DateTime  BidTS;

		public bool      AskIdOffertaNull;
		public int       AskIdOfferta;
		public double    AskPrice;
		public int       AskQty;
		public string    AskCodiceOperatore;
		public DateTime  AskTS;

		public bool      LastPriceNull;
		public double    LastPrice;
		public int       LastQty;
		public DateTime  LastTime;

		public bool      RefPriceNull;
		public double    RefPrice;

		public bool      ConvPriceNull;
		public double    ConvPrice;

		public bool      OffPriceNull;
		public double    OffPrice;
	}
	*/
	/*
	[Serializable]
	public class DatiSessione
	{
		public int      IdSessioneMercato;
		public DateTime DataMercato;

		public bool     TSAperturaMercatoNull;
		public DateTime TSAperturaMercato;
		public bool     TSChiusuraMercatoNull;
		public DateTime TSChiusuraMercato;

		public string   StatoSessione;
		public string   NoteSessione;
		public double   DeltaScartoSuRefPrice;
	}
	*/
}