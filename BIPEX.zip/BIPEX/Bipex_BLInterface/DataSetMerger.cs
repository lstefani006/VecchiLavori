using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Reflection;

namespace Delta
{
	public class DataSetMerger
	{
		private DataSetMerger()
		{
		}

		public static DataTable CreateTable(DataSet ds, string tableName, Type versionableType)
		{
			CompactFormatterType cft = DataRecord.GetCFT(versionableType);

			DataTable td = ds.Tables.Add(tableName);

			ArrayList pk = new ArrayList();

			foreach (CompactFormatterData f in cft.Visible)
			{
				DataColumn col = new DataColumn();
				col.ColumnName = f.DataName;
				col.DataType = f.DataType;
				col.AllowDBNull = f.IsNullable;
				col.ReadOnly = f.IsPrimaryKey;

				td.Columns.Add(col);

				if (f.IsPrimaryKey)
					pk.Add(col);
			}

			td.PrimaryKey = (DataColumn [])pk.ToArray(typeof(DataColumn));
			return td;
		}


		private static void CopyPK(DataRecord dest, DataRow src, CompactFormatterType cft)
		{
			DataTable dt = src.Table;

			foreach (DataColumn col in dt.PrimaryKey)
			{
				bool found = false;
				foreach (CompactFormatterData c in cft.PK)
				{
					if (c.DataName == col.ColumnName)
					{
						c.SetValue(dest, src[col]);
						found = true;
						break;
					}
				}
				Debug.Assert(found, "Non trovo la chiave nel DR");
			}
		}


		public static void Merge(DataTable dt, DataRecordList v2, Type typeV2)
		{
			CompactFormatterType cft = DataRecord.GetCFT(typeV2);

			// dt.AcceptChanges();

			bool changed = false;

			foreach (DataRecord u in v2)
			{
				u.AssertIsDeltaVersion(false);

				object [] pkv = cft.ReadPrimaryKey(u);

				DataRow dr = dt.Rows.Find(pkv);
				if (dr == null)
				{
					object [] v = cft.ReadVisible(u);
					dt.Rows.Add(v);
					changed = true;
				}
				else
				{
					// 1) guardo se esiste la maschera dei Serializzabili/nullati
					// 2) se esiste leggo il valore nella classe derivata, se non esiste la creo a tutti 1

					// qui copio i valori se serializzati.
					// ossia se cambiati

					foreach (CompactFormatterData c in cft.Visible)
					{
						//Debug.Assert(u.IsSerialized(c));

						if (c.IsPrimaryKey) continue;

						object v = DBNull.Value;

						if (c.IsNullable == false || u.IsNotNull(c))
							v = c.GetValue(u);

						if (!dr[c.DataName].Equals(v))
						{
							dr[c.DataName] = v;
							changed = true;
						}
					}
				}
			}

			ConstructorInfo ci = typeV2.GetConstructor(new Type[0]);
			DataRecord f = (DataRecord)ci.Invoke(new object[0]);

			for (;; )
			{
				bool removed = false;

				foreach (DataRow dr in dt.Rows)
				{
					CopyPK(f, dr, cft);

					if (v2.FindByKey(f) < 0)
					{
						dt.Rows.Remove(dr);
						removed = true;
						changed = true;
						break;
					}
				}

				if (!removed)
					break;
			}

			changed = changed;

//			if (changed)
//				dt.AcceptChanges();
		}

	}
}