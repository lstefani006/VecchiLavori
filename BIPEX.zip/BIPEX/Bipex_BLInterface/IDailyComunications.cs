using System;

namespace Bipex_BLInterface
{
	[RemotableClient("Bipex_ControlWS", "DailyComunications.rem")]
	public interface IDailyComunications
	{
		/// <summary>
		/// Ritorna il messaggio di benvenuto da presentare agli utenti di Bipex quando lanciano il programma
		/// </summary>
		/// <param name="dt"></param>
		/// <returns>null se non esiste comunicazione del giorno</returns>
		byte [] WelcomeMessage(DateTime dt);

		/// <summary>
		/// Ritorna il numero di comunicazioni del giorno (escluso il messaggio di benvenuto)
		/// </summary>
		/// <returns></returns>
		int GetDailyComunicationsCount(DateTime dt);

		/// <summary>
		/// Ritorna l'i-esima comunicazione del giorn
		/// </summary>
		/// <param name="dt"></param>
		/// <param name="index">l'indice parte da 1</param>
		/// <returns>null se non esiste la comunicazione i-esima</returns>
		byte [] GetDailyComunication(DateTime dt, int index);
	}
}
