using System;
using System.Diagnostics;
using Delta;

namespace Bipex_BLInterface
{
	//////////////////////////////////////////////////////////////////////

	/// <summary>
	/// SubjectType="OO" 
	/// SubjectSubType=""
	/// 
	/// Lista delle offerte attive nel book o le offerte sospese
	/// L'operatore normale vede solo le sue offerte
	/// L'amministratore vede le offerte di tutti
	/// </summary>
	public class OpenOrderDR : DataRecord
	{
		public const string SubjectType = "OO";
		public const string SubjectSubType = "";

		/// <summary>
		/// stato delle offerte negli open orders
		/// </summary>
		public enum statoOfferta : byte 
		{
			/// <summary>
			/// cancellata dall'utente
			/// (una offerta nel book non puo` mai essere RM)
			/// </summary>
			RM,

			/// <summary>
			/// nascosta (ritirata)
			/// (una offerta nel book non puo` mai essere RJ, ma negli OpenOrders le offerte NA compaiono per essere poi Rivelate)
			/// </summary>
			NA,

			/// <summary>
			/// Valida ossia in contrattazione nel book
			/// </summary>
			VA
		}


		[DR(DRE.PrimaryKey)] public int          IdOfferta;
		[DR]                 public string       Contratto;
		[DR]                 public string       CodiceOperatore;  // l'op che ha sottomesso l'offerta
		[DR]                 public string       CodiceUtente;     // utente che ha sottomesso l'offerta
		[DR]                 public DateTime     TSCreazione;      // data/ora di creazione dell'offerta
		[DR]                 public DateTime     TSAbbinamento;    // data/ora utilizzata per l'ordinamento nel book

		[DR]                 public bool         Ask;              // true=Ask, false=Bid
		[DR]                 public double       PrezzoRichiesto;  // prezzo iniziale (zero per le offerte senza prezzo)
		[DR]                 public int          QtyRichiesta;     // quantita` iniziale
		[DR]                 public string       NoteOfferta = string.Empty;

		[DR]                 public double       PrezzoResiduo;    // puo` essere PrezzoRichiesto!=PrezzoResiduo se PrezzoRichiesto=zero
		[DR]                 public int          QtyResidua;       // quantita` residua nel book (QtyResidua <= QtyRichiesta)

		[DR]                 public string       OperatoreOTC = string.Empty;
		[DR]                 public string       CodiceOTC = string.Empty;

		/// <summary>
		/// Qui e` valorizzato solo o VA o NA
		/// </summary>
		[DR]                 public statoOfferta StatoOfferta = statoOfferta.VA;

		[DR]                 public bool         OffertaAMercato;


		public OpenOrderDR() {}
	}
}