using System;
using Delta;

namespace Bipex_BLInterface
{
	/// <summary>
	/// SubjectType="MS" 
	/// SubjectSubType= ""
	/// 
	/// </summary>
	public class MarketSessionDR : DataRecord
	{
		public const string SubjectType = "MS";
		public const string SubjectSubType = "";

		public enum eStatoSessione
		{
			NUOVA,
			PREDISPOSTA,
			APERTA,
			SOSPESA,
			TERMINATA,
			CHIUSA

			/* NUOVA o CHIUSA possono essere multiple... gli altri stati appartengono SOLA ad una sessione in tutta la tabella 
			 * ossia solo una sessione di mercato puo` avere lo stato in PREDISPOSTA, APERTA, SOSPESA, TERMINATA
			 */
		}

		[Flags] public enum datiDisponilbili : byte
		{
			DatiChiusura = 1,
			SaldoFisico = 2,
			PresentazioneProgrammi = 4,
			ConfermaProgrammiDaBIPEX = 8,
			ConfermaProgrammiDaIPEX = 16,
			DisponibilitaLiquidazioneGiornaliera = 32,
		}

		[DR(DRE.PrimaryKey)] public int IdSessioneMercato;
		[DR] public DateTime DataMercato;
		[DR] public DateTime TSAperturaSessione;
		[DR] public DateTime TSChiusuraSessione;
		[DR] public eStatoSessione StatoSessione;
		[DR] public string NoteSessione;

		// se nono null --> Non disponibili
		// se sono !=   --> DataOra in cui i dati saranno/sono diventati disponibili
		[DR(DRE.Nullable)] public DateTime TSDatiChiusura;
		[DR(DRE.Nullable)] public DateTime TSSaldoFisico;
		[DR(DRE.Nullable)] public DateTime TSPresentazioneProgrammi;
		[DR(DRE.Nullable)] public DateTime TSConfermaProgrammiDaBIPEX;
		[DR(DRE.Nullable)] public DateTime TSConfermaProgrammiDaIPEX;
		[DR(DRE.Nullable)] public DateTime TSDisponibilitaLiquidazioneGiornaliera;

		// qui si capisce se i dati sono disponibili
		[DR] public datiDisponilbili DatiDisponibili;

		[DR] public double OffertePercPrezzoRif;

		public MarketSessionDR() {}
	}
}