using System;
using System.IO;

namespace Bipex_BLInterface
{
	[RemotableClient("Bipex_ControlWS", "UpdateVersion.rem")]
	public interface IUpdateVersion
	{
		IUpdateVersion_EngineEntry [] GetLastEngineFileList();
		bool CheckForUpdate(IUpdateVersion_EngineEntry [] clientEngineFileList);
	}

	[Serializable]
	public class IUpdateVersion_EngineEntry
	{
		public string FileName;
		public DateTime LastWriteTime;


		public static IUpdateVersion_EngineEntry[] GetLastEngineFileList(string exePath)
		{
			string[] fn = Directory.GetFileSystemEntries(exePath);
			IUpdateVersion_EngineEntry[] r = new IUpdateVersion_EngineEntry[fn.Length];
			for (int i = 0; i < r.Length; ++i)
			{
				r[i] = new IUpdateVersion_EngineEntry();
				r[i].FileName = Path.GetFileName(fn[i]) ;
				r[i].LastWriteTime = File.GetLastWriteTime(fn[i]);
			}

			return r;
		}

		/// <summary>
		/// ritorna true se le due liste sono uguali.
		/// </summary>
		/// <param name="serverEntries"></param>
		/// <param name="clientEntries"></param>
		/// <returns></returns>
		public static bool CheckForUpdate(IUpdateVersion_EngineEntry[] serverEntries, IUpdateVersion_EngineEntry[] clientEntries)
		{
			// tutte le entry del server devono essere in client.
			// il client al contrario puo` avere qualche file in piu`.

			foreach (IUpdateVersion_EngineEntry se in serverEntries)
			{
				bool bFound = false;

				foreach (IUpdateVersion_EngineEntry ce in clientEntries)
				{
					if (se.IsEqual(ce))
					{
						bFound = true;
						break;
					}
				}
				if (bFound == false)
					return true;
			}

			return false;
		}

		public bool IsEqual(IUpdateVersion_EngineEntry aa)
		{
			if (aa == null)
				return false;

			if (aa.FileName == this.FileName && aa.LastWriteTime == this.LastWriteTime)
				return true;

			return false;
		}
	}
}