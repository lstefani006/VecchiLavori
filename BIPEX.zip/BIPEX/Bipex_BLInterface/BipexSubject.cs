using System;
using System.Collections;
using Delta;

namespace Bipex_BLInterface
{

	/// <summary>
	/// classe astratta che indica i filtro da impiegare
	/// quando si richiede un <c>VersionableSubject</c>
	/// </summary>
	public abstract class BipexSubjectFilter : ICompactSerializable
	{
		public abstract void Serialize(CompactFormatter cs);

		/// <summary>
		/// Filtra la lista in ingresso per ottenere
		/// una lista in uscita filtrata secondo il criterio implementato nella classe derivata.
		/// </summary>
		/// <param name="lst">lista da filtrare</param>
		/// <returns>lista filtrata</returns>
		public abstract DataRecordList Filter(DataRecordList lst);
	}

	/// <summary>
	/// oggetto che rappresenta un "soggetto dati" di bipex ossia le coordinate che individuano
	/// un insieme di dati per argomento: "BookRiassuntivo", "BookPerTitolo" memorizzato in <c>SubjectType</c>.
	/// Ogni tipo ha un sottotipo opzionale che lo affina es per BookPerTitolo il titolo.
	/// Ogni aoggetto dati e` definito anche dalla Versione.
	/// Un soggetto dati puo` essere un sottoinsieme del soggetto dati originale: il sottoinsieme viene
	/// ottenuto applicando un filtro.
	/// </summary>
	public class BipexSubject : ICompactSerializable 
	{
		public DateTime           DataDiMercato;
		public string             SubjectType = string.Empty;    // es BR book riassuntivo o BT book di un titolo
		public string             SubjectSubType = string.Empty; // es "BL 34w" se SubjectType=BT
		public int                Version = 0;
		public BipexSubjectFilter Filter; // eventuale filtro per ricevere solo dati filtrati
		public BipexSubscribeList Subscribe; // sottocrizione a richiesta di dati.

		/// <summary>
		/// funzione che scrive o legge un oggetto dallo stream <c>CompactFormatter</c>
		/// </summary>
		/// <param name="cf">lo stream da cui leggere o scrivere</param>
		public void Serialize(CompactFormatter cf)
		{
			cf.Serialize(ref DataDiMercato);
			cf.Serialize(ref SubjectType);
			cf.Serialize(ref SubjectSubType);
			cf.Serialize(ref Version);
			Filter = (BipexSubjectFilter) cf.Serialize(Filter);
			Subscribe = (BipexSubscribeList) cf.Serialize(Subscribe);
		}
	}

	public class BipexSubscribe : ICompactSerializable
	{
		public virtual void Serialize(CompactFormatter cs)
		{
		}
	}

	public class BipexSubscribeList : ICompactSerializable
	{
		protected ArrayList ar = new ArrayList();

		public void Serialize(CompactFormatter cs)
		{
			cs.Serialize(ref ar);
		}

		/// <summary>
		/// Numero di<c>VersionableSubject</c> che compongono questa richiesta
		/// </summary>
		public int Count
		{
			get { return ar.Count; }
		}

		/// <summary>
		/// Indexer per accedere alla richiesta <c>i</c>-esima
		/// </summary>
		public BipexSubscribe this [int i]
		{
			get { return (BipexSubscribe) ar[i]; }
			set { ar[i] = value; }
		}

		public IEnumerator GetEnumerator()
		{
			return ar.GetEnumerator();
		}

		/// <summary>
		/// Funzione per aggiungere un <c>BipexSubscribe</c> alla richiesta corrente.
		/// </summary>
		/// <param name="v">soggetto da aggiungere alla richiesta</param>
		public void Add(BipexSubscribe v)
		{
			ar.Add(v);
		}

		/// <summary>
		/// Rimuove tutti gli elementi dalla lista
		/// </summary>
		public void Clear()
		{
			ar.Clear();
		}
	}

	/// <summary>
	/// Una <c>RequestOfVersionableSubjects</c> e` una lista di richieste per soggetto
	/// al server. Ogni item della lista specifica un <c>BipexSubject</c>
	/// </summary>
	public class RequestOfBipexSubjects : ICompactSerializable
	{
		protected ArrayList ar = new ArrayList();

		public void Serialize(CompactFormatter cs)
		{
			cs.Serialize(ref ar);
		}

		/// <summary>
		/// Numero di<c>VersionableSubject</c> che compongono questa richiesta
		/// </summary>
		public int Count
		{
			get { return ar.Count; }
		}

		/// <summary>
		/// Indexer per accedere alla richiesta <c>i</c>-esima
		/// </summary>
		public BipexSubject this [int i]
		{
			get { return (BipexSubject) ar[i]; }
			set { ar[i] = value; }
		}

		public IEnumerator GetEnumerator()
		{
			return ar.GetEnumerator();
		}

		/// <summary>
		/// Funzione per aggiungere un <c>VersionableSubject</c> alla richiesta corrente.
		/// </summary>
		/// <param name="v">soggetto da aggiungere alla richiesta</param>
		public void Add(BipexSubject v)
		{
			ar.Add(v);
		}
	}

	/// <summary>
	/// Risposta ad un <c>RequestOfBipexSubjects</c>.
	/// La risposta e` un insieme di <c>BestVersionableList</c> messi nell'ordine della richiesta.
	/// </summary>
	public class ResponseOfBipexSubjects : ICompactSerializable
	{
		protected ArrayList ar = new ArrayList();

		public void Serialize(CompactFormatter cs)
		{
			cs.Serialize(ref ar);
		}

		public int Count
		{
			get { return ar.Count; }
		}

		public DataRecordList this [int i]
		{
			get { return (DataRecordList) ar[i]; }
			set { ar[i] = value; }
		}

		public IEnumerator GetEnumerator()
		{
			return ar.GetEnumerator();
		}

		public void Add(DataRecordList v)
		{
			ar.Add(v);
		}
	}
}
