using System;
using Delta;

namespace Bipex_BLInterface
{
	/// <summary>
	/// SubjectType="SF" 
	/// SubjectSubType=""
	/// 
	/// Con un filtro l'Engine puo` chiedere solo le i record di un operatore.
	/// </summary>
	public class SaldoFisicoDR : DataRecord
	{
		public const string SubjectType = "SF";
		public const string SubjectSubType = "";

		[DR(DRE.PrimaryKey)] public string       CodiceOperatore;
		[DR(DRE.PrimaryKey)] public DateTime     DataDelivery;

		[DR]                 public int          Immissione;
		[DR]                 public int          Prelievo;

		[DR]                 public int          H01;
		[DR]                 public int          H02;
		[DR]                 public int          H03;
		[DR]                 public int          H04;
		[DR]                 public int          H05;
		[DR]                 public int          H06;
		[DR]                 public int          H07;
		[DR]                 public int          H08;
		[DR]                 public int          H09;
		[DR]                 public int          H10;

		[DR]                 public int          H11;
		[DR]                 public int          H12;
		[DR]                 public int          H13;
		[DR]                 public int          H14;
		[DR]                 public int          H15;
		[DR]                 public int          H16;
		[DR]                 public int          H17;
		[DR]                 public int          H18;
		[DR]                 public int          H19;
		[DR]                 public int          H20;

		[DR]                 public int          H21;
		[DR]                 public int          H22;
		[DR]                 public int          H23;
		[DR]                 public int          H24;
		[DR]                 public int          H25;

		public SaldoFisicoDR() {}
	}

	public class BipexSubscribe_SaldoFisico : BipexSubscribe
	{
		public BipexSubscribe_SaldoFisico() {}

		public override void Serialize(CompactFormatter cs)
		{
			base.Serialize(cs);
			cs.Serialize(ref CodiceOperatore);
			cs.Serialize(ref DataDelivery);
		}

		public string CodiceOperatore;
		public DateTime DataDelivery;
	}



	public class BipexFilter_SaldoFisico : BipexSubjectFilter
	{
		string _codiceOperatore;

		public BipexFilter_SaldoFisico()
		{
		}

		public BipexFilter_SaldoFisico(string operatore)
		{
			_codiceOperatore = operatore;

			if (_codiceOperatore == null)
				_codiceOperatore = String.Empty;

		}
		public override void Serialize(CompactFormatter cs)
		{
			cs.Serialize(ref _codiceOperatore);
		}

		/// <summary>
		/// Filtra la lista in ingresso per ottenere
		/// una lista in uscita filtrata secondo il criterio.
		/// </summary>
		/// <param name="lst">lista da filtrare</param>
		/// <returns>lista filtrata</returns>
		public override DataRecordList Filter(DataRecordList lst)
		{
			if (lst.Count == 0)
				return lst;

			if (lst[0].GetType() == typeof(SaldoFisicoDR))
			{
				DataRecordList r = new DataRecordList();
				foreach (SaldoFisicoDR dr in lst)
				{
					if (dr.CodiceOperatore == _codiceOperatore)
					{
						r.Add(dr);
					}
				}
				r.Version = lst.Version;
				return r;
			}
			else
				return lst;
		}
	}
}