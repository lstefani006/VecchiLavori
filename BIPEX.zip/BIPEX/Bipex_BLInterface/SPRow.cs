using System; 
using System.Data; 
using Bipex_BLInterface; 
namespace SPDriver 
{ 
// i campi hanno prefisso 
// nn    se Non sono Nullabili 
// nu    se sono NUllabili 

	[Serializable] 
	public class DatiContratto
	{
		public String   nnNomeContratto;
		public Int32    nnIdContratto;
		public DateTime nnDataInizioTrading;
		public DateTime nnDataFineTrading;
		public DateTime nnDataInizioDelivery;
		public DateTime nnDataFineDelivery;
		public String   nnCodiceProfilo;
		public String   nnDescrizioneContratto;
		public String   nnCodiceZonaRiferimento;
		public String   nnDurataDelivery;
		public Int32    nnOreFornituraFeriali;
		public Int32    nnOreFornituraFestive;

		public void Read(IDataReader rd)
		{
			this.nnNomeContratto = rd.GetString(0);
			this.nnIdContratto = rd.GetInt32(1);
			this.nnDataInizioTrading = rd.GetDateTime(2);
			this.nnDataFineTrading = rd.GetDateTime(3);
			this.nnDataInizioDelivery = rd.GetDateTime(4);
			this.nnDataFineDelivery = rd.GetDateTime(5);
			this.nnCodiceProfilo = rd.GetString(6);
			this.nnDescrizioneContratto = rd.GetString(7);
			this.nnCodiceZonaRiferimento = rd.GetString(8);
			this.nnDurataDelivery = rd.GetString(9);
			this.nnOreFornituraFeriali = rd.GetInt32(10);
			this.nnOreFornituraFestive = rd.GetInt32(11);
		}
	}

	[Serializable] 
	public class DatiOfferta
	{
		public Int32         nnIdOfferta;
		public String        nnNomeContratto;
		public String        nnCodiceUtente;
		public DateTime      nnTSCreazione;
		public Offerta_Tipo  nuTipoOfferta;
		public bool          nuTipoOffertaNull;
		public Offerta_Stato nuStatoOfferta;
		public bool          nuStatoOffertaNull;
		public Int32         nnQtyIniziale;
		public Int32         nnQtyResidua;
		public DateTime      nnTSPrioritaAbbinamento;
		public String        nnNote;
		public String        nnOperatoreOTC;
		public String        nnCodiceOTC;
		public String        nnCompatibile;
		public Double        nnPrezzo;
		public bool          nnOffertaNelBook;
		public bool          nnOffertaAMercato;

		public void Read(IDataReader rd)
		{
			this.nnIdOfferta = rd.GetInt32(0);
			this.nnNomeContratto = rd.GetString(1);
			this.nnCodiceUtente = rd.GetString(2);
			this.nnTSCreazione = rd.GetDateTime(3);
			this.nuTipoOffertaNull = rd.IsDBNull(4);
			if (!this.nuTipoOffertaNull) this.nuTipoOfferta = (Offerta_Tipo)Enum.Parse(typeof(Offerta_Tipo), rd.GetString(4), true);
			this.nuStatoOffertaNull = rd.IsDBNull(5);
			if (!this.nuStatoOffertaNull) this.nuStatoOfferta = (Offerta_Stato)Enum.Parse(typeof(Offerta_Stato), rd.GetString(5), true);
			this.nnQtyIniziale = rd.GetInt32(6);
			this.nnQtyResidua = rd.GetInt32(7);
			this.nnTSPrioritaAbbinamento = rd.GetDateTime(8);
			this.nnNote = rd.GetString(9);
			this.nnOperatoreOTC = rd.GetString(10);
			this.nnCodiceOTC = rd.GetString(11);
			this.nnCompatibile = rd.GetString(12);
			this.nnPrezzo = rd.GetDouble(13);
			this.nnOffertaNelBook = rd.GetInt32(14) > 0;
			this.nnOffertaAMercato = rd.GetString(15) == "S";
		}
	}

	[Serializable] 
	public class DatiSessione
	{
		public Int32    nnIdSessioneMercato;
		public DateTime nnDataMercato;
		public DateTime nuTSAperturaSessione;
		public bool     nuTSAperturaSessioneNull;
		public DateTime nuTSChiusuraSessione;
		public bool     nuTSChiusuraSessioneNull;
		public String   nnStatoSessione;
		public String   nnNoteSessione;
		public Double   nuDeltaScartoSuRefPrice;
		public bool     nuDeltaScartoSuRefPriceNull;

		public void Read(IDataReader rd)
		{
			this.nnIdSessioneMercato = rd.GetInt32(0);
			this.nnDataMercato = rd.GetDateTime(1);
			this.nuTSAperturaSessioneNull = rd.IsDBNull(2);
			if (!this.nuTSAperturaSessioneNull) this.nuTSAperturaSessione = rd.GetDateTime(2);
			this.nuTSChiusuraSessioneNull = rd.IsDBNull(3);
			if (!this.nuTSChiusuraSessioneNull) this.nuTSChiusuraSessione = rd.GetDateTime(3);
			this.nnStatoSessione = rd.GetString(4);
			this.nnNoteSessione = rd.GetString(5);
			this.nuDeltaScartoSuRefPriceNull = rd.IsDBNull(6);
			if (!this.nuDeltaScartoSuRefPriceNull) this.nuDeltaScartoSuRefPrice = rd.GetDouble(6);
		}
	}

	[Serializable] 
	public class DatiSessioneContratto
	{
		public String   nnNomeContratto;
		public Int32    nuBidIdOfferta;
		public bool     nuBidIdOffertaNull;
		public Double   nnBidPrice;
		public Int32    nnBidQty;
		public String   nnBidCodiceOperatore;
		public DateTime nuBidTS;
		public bool     nuBidTSNull;
		public Int32    nuAskIdOfferta;
		public bool     nuAskIdOffertaNull;
		public Double   nnAskPrice;
		public Int32    nnAskQty;
		public String   nnAskCodiceOperatore;
		public DateTime nuAskTS;
		public bool     nuAskTSNull;
		public Double   nuLastPrice;
		public bool     nuLastPriceNull;
		public Int32    nuLastQty;
		public bool     nuLastQtyNull;
		public DateTime nuLastTime;
		public bool     nuLastTimeNull;
		public Double   nuRefPrice;
		public bool     nuRefPriceNull;
		public Double   nuConvPrice;
		public bool     nuConvPriceNull;
		public Double   nuOffPrice;
		public bool     nuOffPriceNull;

		public void Read(IDataReader rd)
		{
			this.nnNomeContratto = rd.GetString(0);
			this.nuBidIdOffertaNull = rd.IsDBNull(1);
			if (!this.nuBidIdOffertaNull) this.nuBidIdOfferta = rd.GetInt32(1);
			this.nnBidPrice = rd.GetDouble(2);
			this.nnBidQty = rd.GetInt32(3);
			this.nnBidCodiceOperatore = rd.GetString(4);
			this.nuBidTSNull = rd.IsDBNull(5);
			if (!this.nuBidTSNull) this.nuBidTS = rd.GetDateTime(5);
			this.nuAskIdOffertaNull = rd.IsDBNull(6);
			if (!this.nuAskIdOffertaNull) this.nuAskIdOfferta = rd.GetInt32(6);
			this.nnAskPrice = rd.GetDouble(7);
			this.nnAskQty = rd.GetInt32(8);
			this.nnAskCodiceOperatore = rd.GetString(9);
			this.nuAskTSNull = rd.IsDBNull(10);
			if (!this.nuAskTSNull) this.nuAskTS = rd.GetDateTime(10);
			this.nuLastPriceNull = rd.IsDBNull(11);
			if (!this.nuLastPriceNull) this.nuLastPrice = rd.GetDouble(11);
			this.nuLastQtyNull = rd.IsDBNull(12);
			if (!this.nuLastQtyNull) this.nuLastQty = rd.GetInt32(12);
			this.nuLastTimeNull = rd.IsDBNull(13);
			if (!this.nuLastTimeNull) this.nuLastTime = rd.GetDateTime(13);
			this.nuRefPriceNull = rd.IsDBNull(14);
			if (!this.nuRefPriceNull) this.nuRefPrice = rd.GetDouble(14);
			this.nuConvPriceNull = rd.IsDBNull(15);
			if (!this.nuConvPriceNull) this.nuConvPrice = rd.GetDouble(15);
			this.nuOffPriceNull = rd.IsDBNull(16);
			if (!this.nuOffPriceNull) this.nuOffPrice = rd.GetDouble(16);
		}
	}

	[Serializable] 
	public class DatiOreFornitura
	{
		public DateTime nnDataDelivery;
		public String   nnFestivoFeriale;
		public String   nnH;

		public void Read(IDataReader rd)
		{
			this.nnDataDelivery = rd.GetDateTime(0);
			this.nnFestivoFeriale = rd.GetString(1);
			this.nnH = rd.GetString(2);
		}
	}

	[Serializable] 
	public class OperatoreOTC
	{

		public override string ToString()
		{
			return nnRagioneSociale;
		}
	
		public String nnCodiceOperatore;
		public String nnRagioneSociale;

		public void Read(IDataReader rd)
		{
			this.nnCodiceOperatore = rd.GetString(0);
			this.nnRagioneSociale = rd.GetString(1);
		}
	}

	[Serializable] 
	public class ListaContrattiRow
	{
		public Int32  nnIdContratto;
		public String nnNomeContratto;

		public void Read(IDataReader rd)
		{
			this.nnIdContratto = rd.GetInt32(0);
			this.nnNomeContratto = rd.GetString(1);
		}
	}
}
