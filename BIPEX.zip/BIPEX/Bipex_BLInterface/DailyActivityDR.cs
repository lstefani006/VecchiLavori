using System;
using Delta;

namespace Bipex_BLInterface
{
	/// <summary>
	/// SubjectType="DA" 
	/// SubjectSubType=""
	/// 
	/// Con un filtro l'Engine puo` chiedere solo le i record di un operatore.
	/// Lista delle offerte abbinate (Daily Activity)
	/// L'amministratore vede tutto.
	/// I comuni mortali vedono solo le proprie offerte.
	/// 
	/// Il codice di visualizzazione non deve visualizzare i dati della controparte
	/// </summary>
	public class DailyActivityDR : DataRecord
	{
		public const string SubjectType = "DA";
		public const string SubjectSubType = "";

		[DR(DRE.PrimaryKey)] public int          IdAbbinamento;
		[DR]                 public int          BidIdOfferta;     // offerta che ha originato l'abbinamento
		[DR]                 public int          AskIdOfferta;     // offerta che ha originato l'abbinamento

		[DR]                 public string       Contratto=string.Empty;     // contratto associato all'offerta

		[DR]                 public string       BidCodiceOperatore=string.Empty;  // operatore che ha sottomesso l'offerta
		[DR]                 public string       AskCodiceOperatore=string.Empty;  // operatore che ha sottomesso l'offerta

		[DR]                 public string       BidCodiceUtente=string.Empty;  // utente che ha sottomesso l'offerta
		[DR]                 public string       AskCodiceUtente=string.Empty;  // utente che ha sottomesso l'offerta

		[DR]                 public DateTime     TSAbbinamento; // data/ora dell'abbinamento.

		[DR]                 public double       Price;         // prezzo abbinamento
		[DR]                 public int          Qty;           // quantita` abbinata

		[DR]                 public string       CodiceOTC = string.Empty;
		[DR]                 public string       OperatoreOTC = string.Empty;

		public DailyActivityDR() {}
	}

	public class BipexFilterPerOperatoreUtente : BipexSubjectFilter
	{
		string _codiceOperatore;
		string _codiceUtente;

		public BipexFilterPerOperatoreUtente()
		{
		}

		public BipexFilterPerOperatoreUtente(string operatore, string utente)
		{
			_codiceOperatore = operatore;
			_codiceUtente = utente;

			if (_codiceOperatore == null)
				_codiceOperatore = String.Empty;
			if (_codiceUtente == null)
				_codiceUtente = String.Empty;

		}
		public override void Serialize(CompactFormatter cs)
		{
			cs.Serialize(ref _codiceOperatore);
			cs.Serialize(ref _codiceUtente);
		}

		/// <summary>
		/// Filtra la lista in ingresso per ottenere
		/// una lista in uscita filtrata secondo il criterio.
		/// </summary>
		/// <param name="lst">lista da filtrare</param>
		/// <returns>lista filtrata</returns>
		public override DataRecordList Filter(DataRecordList lst)
		{
			if (lst.Count == 0)
				return lst;

			if (lst[0].GetType() == typeof(DailyActivityDR))
			{
				DataRecordList r = new DataRecordList();
				foreach (DailyActivityDR dr in lst)
				{
					string op = (_codiceOperatore.Length == 0) ? dr.BidCodiceOperatore : _codiceOperatore;
					string ut = (_codiceUtente.Length == 0) ? dr.BidCodiceUtente : _codiceUtente;

					if ((dr.BidCodiceOperatore == op ||
						dr.AskCodiceOperatore == op) &&
						(dr.BidCodiceUtente == ut ||
						dr.AskCodiceUtente == ut))
					{
						r.Add(dr);
					}
				}
				r.Version = lst.Version;
				return r;
			}
			else if (lst[0].GetType() == typeof(OpenOrderDR))
			{
				DataRecordList r = new DataRecordList();
				foreach (OpenOrderDR dr in lst)
				{
					if (dr.CodiceOperatore == _codiceOperatore && dr.CodiceUtente == _codiceUtente)
					{
						r.Add(dr);
					}
				}
				r.Version = lst.Version;
				return r;
			}
			else if (lst[0].GetType() == typeof(DailyActivityLogDR))
			{

				DataRecordList r = new DataRecordList();
				foreach (DailyActivityLogDR dr in lst)
				{
					if (dr.IsNull("CodiceOperatore"))
					{
						r.Add(dr);
					}
					else if (dr.CodiceOperatore == _codiceOperatore)
					{
						if (dr.IsNull("CodiceUtente") || dr.CodiceUtente == _codiceUtente)
							r.Add(dr);
					}
				}

				r.Version = lst.Version;
				return r;
			}
			else
				return lst;
		}
	}


	public class DailyActivityLogDR : DataRecord
	{
		public const string SubjectType = "DL";
		public const string SubjectSubType = "";

		[DR(DRE.PrimaryKey)] public int          IdDailyActivity;
		[DR]                 public DateTime     ActivityTS;
		[DR]                 public string       ActivityCode;
		[DR]                 public string       Msg;
		[DR(DRE.Nullable)]   public int          IdOfferta;    
		[DR(DRE.Nullable)]   public int          IdAbbinamento;
		[DR(DRE.Nullable)]   public string       CodiceOperatore;
		[DR(DRE.Nullable)]   public string       CodiceUtente;
		[DR(DRE.Nullable)]   public double       Price;
		[DR(DRE.Nullable)]   public int          Qty;

		public DailyActivityLogDR() {}
	}
}