using System;

namespace Bipex_BLInterface
{
	[RemotableClient("Bipex_ControlWS", "Login.rem")]
	public interface ILogin
	{
		/// <summary>
		/// Controllo delle credenziali d'ingresso.
		/// </summary>
		/// <param name="login"></param>
		/// <param name="pwd"></param>
		/// <returns>null se login fail</returns>
		DatiUtente CheckLogin(string login, string pwd);
	}

	[Serializable]
	public class DatiUtente
	{
		public string Codice;
		public string Nome;
		public string Cognome;
		public string Ruolo;

		public string Descrizione;
		public DatiOperatore [] Operatore;
		public string [] DirittoFunzionale;

		public int Token;
	}

	[Serializable]
	public class DatiOperatore
	{
		public string Codice;
		public string Descrizione;
		public string RagioneSociale;
	}

	public class Ruolo
	{
		private Ruolo() {}
		public static readonly string AdministratorFull = "Administrator/Full";
		public static readonly string AdministratorAccountant = "Administrator/Accountant";
		public static readonly string UserFull = "User/Full";
		public static readonly string UserViewer = "User/Viewer";
		
	}

	public class DirittoFunzionale
	{
		private DirittoFunzionale() {}

		public static readonly string Ctrl_DefinizioneAnagrafiche = "Ctrl_DefinizioneAnagrafiche";
		public static readonly string Ctrl_DefinizioneContratti   = "Ctrl_DefinizioneContratti";
		public static readonly string Ctrl_Settlement             = "Ctrl_Settlement";
		public static readonly string Mkt_Reports                 = "Ctrl_Settlement";
		public static readonly string Mkt_PresentazioneOfferte    = "Mkt_PresentazioneOfferte";
		public static readonly string Mkt_PresentazioneProgrammi  = "Mkt_PresentazioneProgrammi";
	}


}
