namespace Bipex_BLInterface
{
	[RemotableClient("Bipex_BLWS", "Echo.rem")]
	public interface IEcho
	{
		string Ping(string msg);
	}
}