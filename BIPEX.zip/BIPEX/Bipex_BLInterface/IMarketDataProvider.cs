using Delta;

namespace Bipex_BLInterface
{
	[RemotableClient("Bipex_ControlWS", "MarketDataProvider.rem")]
	public interface IMarketDataProvider
	{
		/// <summary>
		/// Richiede la versione piu` aggiornata dei dati di mercato.
		/// In <paramref name='rq'/> e` stream-ato un oggetto che indica quali SubjectType/SubjectSubType
		/// sono richiesti.
		/// La risposta e` stream-ata e ritorna i dati richiesti tipicamente per differenza.
		/// </summary>
		/// <param name="rq">la lista dei dati da richiedere</param>
		/// <returns>la lista dei dati richiesti</returns>
		byte[] GetLastMarketDataVersion(byte[] rq);

		/// <summary>
		/// Impsta la profondita` della cache.
		/// In generale questo numero dovrebbe essere abbastanza grande da soddisfare le richieste
		/// dei clienti piu` lenti ma non troppo grande per evitare di mantenere in memoria
		/// troppa roba.
		/// </summary>
		/// <param name="max">il nuovo valore</param>
		void SetMaxNumberOfVersionsInCache(int max);
	}
}