namespace Bipex_BLInterface
{
	/// <summary>
	/// Summary description for CacheUpdater.
	/// </summary>
	[RemotableClient("Bipex_CacheServer", "CacheUpdater.rem")]
	public interface ICacheUpdater
	{
		void OnAbbinamento(string contratto);
		void OnSessioneMercato();
	}
}