using System;
using Delta;

namespace Bipex_BLInterface
{
	public enum Offerta_Tipo
	{
		Acquisto, 
		Vendita
	}
	public enum Offerta_Stato
	{
		Valida,
		Nascosta,
		Revocata
	}



	[RemotableClient("Bipex_BLWS", "Offerta.rem")]
	public interface IOfferta
	{
		/// <summary>
		/// Prende in ingresso un file in xml che contiene le attivita` 
		/// dell'operatore sulle offerte.
		/// In uscita viene prodotto il file di risposta.
		/// </summary>
		/// <param name="codiceOperatore">operatore come risulta dal canale</param>
		/// <param name="codiceUtente">utente come risulta dal canale</param>
		/// <param name="xml">file xml streamato in UFT8</param>
		/// <returns></returns>
		byte [] ElaboraRichiesta(string codiceOperatore, string codiceUtente, byte [] xml);


	}

}