using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using System.Text;

namespace Delta
{
	[Flags]
	public enum DRE
	{
		// campo nullabile. Implicitamente e` un campo valore.
		Nullable = 1,

		// campo non visibile, ossia non esportato nel DataTable. Implicitamente e` un campo valore
		NotVisible = 2,

		// campo PK, non puo` essere Nullable e implicitamente e` Visible. Non e` un valore
		PrimaryKey = 4,
	}

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class DRAttribute : Attribute
	{
		public DRAttribute()
		{
			_visible = true;
			_nullable = false;
			_pk = false;
		}

		public DRAttribute(DRE f)
		{
			_nullable = (f & DRE.Nullable) > 0;
			_pk = (f & DRE.PrimaryKey) > 0;
			_visible = (f & DRE.NotVisible) == 0;

			if (_pk)
			{
				_nullable = false;
				_visible = true;
			}
		}

		public bool IsPrimaryKey
		{
			get { return _pk; }
		}

		public bool IsNullable
		{
			get { return _nullable; }
		}

		public bool IsVisible
		{
			get { return _visible; }
		}

		private bool _pk;
		private bool _nullable;
		private bool _visible;
	}

	/// <summary>
	/// classe astratta che gli oggetti devono implementare per essere
	/// condivisi da client e server.
	/// Gli oggetti devono avere una chive primaria che NON puo` essere modificata.
	/// La chiave primaria e` utilizzata per riconcigliare un oggetto sia nel client
	/// che nel server.
	/// I valori sono tutti i campi dell'oggetto che non sono chiave primaria.
	/// </summary>
	public class DataRecord : ICompactSerializable
	{
		protected DataRecord()
		{
			_M = new Mask();
			_M.SetBitSize(CFT.MaskSize() + 1); // +1 e` per sapere se e` Delta o no
			SetSM(this, CFT, true);
			SetNM(this, CFT, false);
			SetDeltaVersion(false);
		}

		public bool IsDeltaVersion
		{
			get { return _M[CFT.MaskSize()]; }
		}

		private void SetDeltaVersion(bool v)
		{
			_M[CFT.MaskSize()] = v;
		}

		/// <summary>
		/// Indica se due <c>DataRecord</c> hanno la stessa chiave
		/// </summary>
		/// <param name="a">l'oggetto con cui confrontare l'oggetto <c>this</c></param>
		/// <returns>true se hanno la stessa chiave</returns>
		public virtual bool HasSameKey(DataRecord a)
		{
			foreach (CompactFormatterData c in CFT.PK)
			{
				Debug.Assert(c.IsNullable == false);

				object v1 = c.GetValue(this);
				object v2 = c.GetValue(a);

				if (v1.Equals(v2) == false)
					return false;
			}
			return true;
		}

		/// <summary>
		/// Indica se due record hanno gli stessi valori (campi non chiave).
		/// Per definizione devono avere la stessa chiave.
		/// </summary>
		/// <param name="obj2"></param>
		/// <returns></returns>
		public virtual bool HasSameValues(DataRecord obj2)
		{
			DataRecord obj1 = this;

			obj1.AssertIsDeltaVersion(false);
			obj2.AssertIsDeltaVersion(false);


			bool eq = CompareNM(obj1, obj2, CFT);
			if (!eq) return false;

			foreach (CompactFormatterData c in CFT.Value)
			{
				Debug.Assert(c.IsPrimaryKey == false);

				if (c.IsNullable)
				{
					bool n1 = obj1.IsNull(c);
					bool n2 = obj2.IsNull(c);

					if (n1 && n2) continue; // entrambi null --> sono uguali
					if (n1 || n2) return false; // uno dei due true l'altro false --> sono diversi
				}

				object v1 = c.GetValue(obj1);
				object v2 = c.GetValue(obj2);

				if (v1 == null && v2 == null) continue;

				if (v1 == null && v2 != null) return false;
				if (v1 != null && v2 == null) return false;

				if (v1.Equals(v2) == false)
					return false;
			}
			return true;
		}


		private static void CopyField(DataRecord dst, DataRecord src, CompactFormatterData c)
		{
			// LEO TODO copia classi ?
			object v = c.GetValue(src);
			c.SetValue(dst, v);
		}

		/// <summary>
		/// Copia in <c>this</c> il valori dal record <c>src</c>
		/// </summary>
		/// <param name="src">il record da cui copiare i valori</param>
		private void CopyValues(DataRecord src)
		{
			src.AssertIsDeltaVersion(false);
			this.AssertIsDeltaVersion(false);

			CopySM(this, src, CFT);
			CopyNM(this, src, CFT);

			foreach (CompactFormatterData c in CFT.Value)
				CopyField(this, src, c);
		}

		private void CopyDeltaValues(DataRecord src)
		{
			src.AssertIsDeltaVersion(true);
			this.AssertIsDeltaVersion(false);

			CopyNM(this, src, CFT);

			foreach (CompactFormatterData c in CFT.Value)
			{
				if (src._M[c.SMPosition] && c.IsNullable && src.IsNull(c))
					Debug.Assert(false, "SM e` true ma il campo e` NULL");

				if (src._M[c.SMPosition])
				{
					CopyField(this, src, c);
					this._M[c.SMPosition] = true;
				}

			}
		}

		public virtual void Merge(DataRecord src)
		{
			if (src.IsDeltaVersion)
				CopyDeltaValues(src);
			else
				CopyValues(src);
		}


		/// <summary>
		/// Crea una copia dell'oggetto corrente. La copia non avra` nessun puntatore in comune
		/// con l'oggetto corrente, solo i valori sono uguali.
		/// </summary>
		/// <returns>l'oggetto clonato</returns>
		public DataRecord DeepClone()
		{
			this.AssertIsDeltaVersion(false);

			ConstructorInfo ci = this.GetType().GetConstructor(new Type[0]);
			DataRecord r = (DataRecord) ci.Invoke(new object[0]);

			CopyNM(r, this, CFT);
			CopySM(r, this, CFT);

			foreach (CompactFormatterData c in CFT.All)
				CopyField(r, this, c);

			return r;
		}

		public DataRecord DeepCloneWithPrimaryKeyOnly()
		{
			this.AssertIsDeltaVersion(false);

			ConstructorInfo ci = this.GetType().GetConstructor(new Type[0]);
			DataRecord r = (DataRecord) ci.Invoke(new object[0]);

			CopyNM(r, this, CFT);
			SetSM(r, CFT, false);

			foreach (CompactFormatterData c in CFT.PK)
				CopyField(r, this, c);

			return r;
		}

		/// <summary>
		/// Valorizza la maschera che descrive quali campi dell'oggetto saranno serializzati
		/// </summary>
		/// <param name="originalObject">oggetto di riferimento per la differenza</param>
		/// <returns></returns>
		public DataRecord DeepCloneDelta(DataRecord originalObject)
		{
			this.AssertIsDeltaVersion(false);
			originalObject.AssertIsDeltaVersion(false);

			ConstructorInfo ci = this.GetType().GetConstructor(new Type[0]);
			DataRecord r = (DataRecord) ci.Invoke(new object[0]);

			// non copio SM perche` MakeDelta lo valorizzera` opportunamente
			CopyNM(r, this, CFT);

			foreach (CompactFormatterData c in CFT.All)
				CopyField(r, this, c);

			r.AssertIsDeltaVersion(false);

			r.MakeDelta(originalObject);

			r.AssertIsDeltaVersion(true);
			return r;
		}


		private void MakeDelta(DataRecord v1)
		{
			this.SetDeltaVersion(true);

			SetSM(this, CFT, false);


			// e ora i valori
			foreach (CompactFormatterData c in CFT.Value)
			{
				if (c.IsNullable)
				{
					bool nv2 = this.IsNull(c);
					bool nv1 = v1.IsNull(c);

					// sono entrambi nulli --> non serializzo il valore.
					if (nv2 == true && nv1 == true)
					{
						this._M[c.SMPosition] = false;
					}
					else if (nv2 == false && nv1 == false)
					{
						// sono entrambi not null... decido sul valore se trasferire
						object cv1 = c.GetValue(this);
						object cv2 = c.GetValue(v1);

						bool eq = cv1.Equals(cv2);
						this._M[c.SMPosition] = !eq;
					}
					else if (nv2 == false && nv1 == true)
					{
						// se la nuova versione e` not null --> serializzo il nuovo valore
						this._M[c.SMPosition] = true;
					}
					else if (nv2 == true && nv1 == false)
					{
						// se la nuova versione e` null --> non serializzo
						this._M[c.SMPosition] = false;
					}
				}
				else
				{
					object cv1 = c.GetValue(this);
					object cv2 = c.GetValue(v1);

					bool eq = cv1.Equals(cv2);
					this._M[c.SMPosition] = !eq;
				}
			}
		}

		/// <summary>
		/// Funzione per serializzare l'oggetto
		/// </summary>
		/// <param name="cf"></param>
		public virtual void Serialize(CompactFormatter cf)
		{
			_M.Serialize(cf); // qui serializzo TUTTO: la maschera dei NULL, SM (maschera di serializzazione) e Delta

			foreach (CompactFormatterData c in CFT.All)
			{
				if (c.IsValue)
				{
					if (c.IsNullable)
						if (IsNull(c))
							Debug.Assert(_M[c.SMPosition] == false, "I valori NULL non si serializzano");
				}

				if (c.IsPrimaryKey || _M[c.SMPosition])
				{
					if (cf.IsWriting)
					{
						object v = c.GetValue(this);
						cf.WriteType(c.DataType, v);
					}
					else
					{
						object v = cf.ReadType(c.DataType);
						c.SetValue(this, v);
					}
				}
			}
		}


		[Conditional("DEBUG")]
		public void AssertIsDeltaVersion(bool v)
		{
			Debug.Assert(IsDeltaVersion == v);
		}

		public bool IsNull(string DataName)
		{
			return IsNull(CFT[DataName]);
		}

		public bool IsNotNull(string DataName)
		{
			return !IsNull(CFT[DataName]);
		}

		public bool IsNull(CompactFormatterData c)
		{
			if (!c.IsNullable) throw new ApplicationException(c.DataName + ": Campo non nullabile");
			return _M.Get(c.NMPosition);
		}

		public bool IsNotNull(CompactFormatterData c)
		{
			return !IsNull(c);
		}


		public void SetNull(string DataName)
		{
			SetNull(CFT[DataName], true);
		}

		public void SetNotNull(string DataName)
		{
			SetNull(CFT[DataName], false);
		}

		public void SetNull(string DataName, bool v)
		{
			SetNull(CFT[DataName], v);
		}

		public void SetNull(CompactFormatterData c)
		{
			SetNull(c, true);
		}

		public void SetNotNull(CompactFormatterData c)
		{
			SetNull(c, false);
		}

		public object GetValue(string DataName)
		{
			return CFT[DataName].GetValue(this);
		}
		public object GetValue(CompactFormatterData c)
		{
			return c.GetValue(this);
		}


		public void SetNull(CompactFormatterData c, bool v)
		{
			AssertIsDeltaVersion(false);

			if (!c.IsNullable) throw new ApplicationException(c.DataName + ": Campo non nullabile");
			_M[c.NMPosition] = v;
			_M[c.SMPosition] = !v;
		}

		public CompactFormatterType CFT
		{
			get
			{
				if (_cft == null)
				{
					Type classType = this.GetType();
					_cft = GetCFT(classType);
				}
				return _cft;
			}
		}

		private CompactFormatterType _cft;

		public static CompactFormatterType GetCFT(Type classType)
		{
			if (h.ContainsKey(classType.FullName))
				return (CompactFormatterType) h[classType.FullName];

			CompactFormatterType cft = new CompactFormatterType(classType);
			h[classType.FullName] = cft;
			return cft;
		}

		private Mask _M;
		private static Hashtable h = new Hashtable();

		private static void CopyNM(DataRecord dst, DataRecord src, CompactFormatterType cft)
		{
			int start;
			int end;
			cft.NMSize(out start, out end);
			for (int i = start; i < end; ++i)
				dst._M[i] = src._M[i];
		}

		private static void CopySM(DataRecord dst, DataRecord src, CompactFormatterType cft)
		{
			int start;
			int end;
			cft.SMSize(out start, out end);
			for (int i = start; i < end; ++i)
				dst._M[i] = src._M[i];
		}

		private static bool CompareNM(DataRecord a, DataRecord b, CompactFormatterType cft)
		{
			int start;
			int end;
			cft.NMSize(out start, out end);
			for (int i = start; i < end; ++i)
				if (a._M[i] != b._M[i])
					return false;
			return true;
		}

		private static void SetNM(DataRecord c, CompactFormatterType cft, bool v)
		{
			int start;
			int end;
			cft.NMSize(out start, out end);
			for (int i = start; i < end; ++i)
				c._M[i] = v;
		}

		private static void SetSM(DataRecord c, CompactFormatterType cft, bool v)
		{
			int start;
			int end;
			cft.SMSize(out start, out end);
			for (int i = start; i < end; ++i)
				c._M[i] = v;
		}

	}


	[Serializable]
	public class DataRecordList : ICompactSerializable
	{
		public DataRecordList()
		{
			_list = new ArrayList();
			_version = 0;
		}

		public int Count
		{
			get { return _list.Count; }
		}

		public DataRecord this[int i]
		{
			get { return (DataRecord) _list[i]; }
			set { _list[i] = value; }
		}

		public IEnumerator GetEnumerator()
		{
			return _list.GetEnumerator();
		}

		public void Add(DataRecord v)
		{
			_list.Add(v);
		}

		public void Remove(DataRecord v)
		{
			int k = this.FindByKey(v);
			if (k >= 0)
				this._list.RemoveAt(k);
		}

		public void RemoveAt(int k)
		{
			this._list.RemoveAt(k);
		}

		public int Version
		{
			get { return _version; }
			set { _version = value; }
		}

		public virtual DataRecordList DeepClone()
		{
			// diabolico costruttore virtuale
			Type t = this.GetType();
			ConstructorInfo ci = t.GetConstructor(new Type[] {});
			DataRecordList r = (DataRecordList) ci.Invoke(new object[] {});

			foreach (DataRecord v in this)
				r.Add(v.DeepClone());

			r.Version = this.Version;
			return r;
		}

		public void Serialize(CompactFormatter cf)
		{
			if (cf.IsWriting)
			{
				cf.WriteInt32(_version);

				Type ty = GetItemType(); // puo` ritornare null
				cf.WriteType(ty); // puo` accettare null

				WriteList(cf, _list);
				if (_list == null)
				{
					WriteList(cf, _inserted);
					WriteList(cf, _updated);
					WriteList(cf, _deleted);
				}
			}
			else
			{
				_version = cf.ReadInt32();

				Type ty = cf.ReadType();

				_list = ReadList(cf, ty);
				if (_list == null)
				{
					_inserted = ReadList(cf, ty);
					_updated = ReadList(cf, ty);
					_deleted = ReadList(cf, ty);
				}
			}
		}

		private Type GetItemType()
		{
			if (_list != null && _list.Count > 0) return _list[0].GetType();
			if (_inserted != null && _inserted.Count > 0) return _inserted[0].GetType();
			if (_updated != null && _updated.Count > 0) return _updated[0].GetType();
			if (_deleted != null && _deleted.Count > 0) return _deleted[0].GetType();
			return null;
		}

		private static void WriteList(CompactFormatter cf, ArrayList a)
		{
			if (a == null)
			{
				int sz = -1;
				cf.WriteInt32(sz);
				return;
			}

			cf.WriteInt32(a.Count);
			for (int i = 0; i < a.Count; ++i)
			{
				DataRecord dr = (DataRecord) a[i];
				dr.Serialize(cf);
			}
		}

		private static ArrayList ReadList(CompactFormatter cf, Type ty)
		{
			int sz = cf.ReadInt32();
			if (sz == -1)
				return null;

			ArrayList a = new ArrayList();

			if (sz > 0)
			{
				ConstructorInfo ci = ty.GetConstructor(new Type[0]);

				for (int i = 0; i < sz; ++i)
				{
					DataRecord dr = (DataRecord) ci.Invoke(new object[0]);
					dr.Serialize(cf);
					a.Add(dr);
				}
			}

			return a;
		}


		public void Merge(DataRecordList src)
		{
			this.AssertDeltaVersion(false);

			if (src.IsDeltaList == false)
			{
				_list.Clear();
				foreach (DataRecord v in src)
				{
					v.AssertIsDeltaVersion(false);
					DataRecord vc = v.DeepClone();
					vc.AssertIsDeltaVersion(false);
					_list.Add(vc);
				}
				_version = src.Version;
			}
			else
			{
				foreach (DataRecord uSrc in src._updated)
				{
					int k = FindByKey(uSrc);
					if (k == -1) throw new ApplicationException("record not found");
					DataRecord v = (DataRecord) _list[k];

					v.AssertIsDeltaVersion(false);
					uSrc.AssertIsDeltaVersion(true);

					v.Merge(uSrc);
				}
				foreach (DataRecord dSrc in src._deleted)
				{
					int k = FindByKey(dSrc);
					if (k == -1) throw new ApplicationException("record not found");
					_list.RemoveAt(k);
				}
				foreach (DataRecord iSrc in src._inserted)
				{
					iSrc.AssertIsDeltaVersion(false);
					DataRecord v = iSrc.DeepClone();
					_list.Add(v);
				}
				_version = src.Version;
			}
		}

		public int FindByKey(DataRecord k)
		{
			for (int i = 0; i < _list.Count; ++i)
			{
				DataRecord v = (DataRecord) _list[i];
				if (k.HasSameKey(v))
					return i;
			}
			return -1;
		}


		public static DataRecordList operator -(DataRecordList v2, DataRecordList v1)
		{
			return BestDiff(v2, v1);
		}

		public static DataRecordList operator +(DataRecordList v1, DataRecordList v2)
		{
			v1.AssertDeltaVersion(false);

			DataRecordList nv1 = v1.DeepClone();
			nv1.Merge(v2);
			return nv1;
		}

		[Conditional("DEBUG")]
		private void AssertDeltaVersion(bool v)
		{
			Debug.Assert(IsDeltaList == v);
			if (v == false)
			{
				foreach (DataRecord r in this)
					r.AssertIsDeltaVersion(v);
			}
			else
			{
				foreach (DataRecord r in _updated)
					r.AssertIsDeltaVersion(v);
			}
		}


		public static DataRecordList Diff(DataRecordList v2, DataRecordList v1)
		{
			v2.AssertDeltaVersion(false);
			v1.AssertDeltaVersion(false);

			if (v2.Version < v1.Version)
				throw new ApplicationException("la versione v2 non deve essere piu` vecchia della versione v1");

			DataRecordList delta = new DataRecordList();
			delta._version = v2.Version;
			delta._list = null;
			delta._inserted = new ArrayList();
			delta._updated = new ArrayList();
			delta._deleted = new ArrayList();
			Debug.Assert(delta.IsDeltaList);

			if (v2.Version == v1.Version)
				return delta;

			foreach (DataRecord r2 in v2)
			{
				// cerco il record r2 in v1.
				int k = v1.FindByKey(r2);
				if (k >= 0)
				{
					if (r2.HasSameValues(v1[k]) == false)
					{
						DataRecord t = r2.DeepCloneDelta(v1[k]);
						// il record in v2 esiste in v1 ma e` cambiato.
						t.AssertIsDeltaVersion(true);
						delta._updated.Add(t);
					}
				}
				else
				{
					// il record in v2 non esiste in v1
					delta._inserted.Add(r2.DeepClone());
					r2.AssertIsDeltaVersion(false);
				}
			}

			// in v1 ci possono essere record cancellati in v2
			foreach (DataRecord r1 in v1)
			{
				int k = v2.FindByKey(r1);
				if (k < 0)
				{
					// il record in v1 non esiste piu` in v2
					DataRecord t = r1.DeepCloneWithPrimaryKeyOnly();
					t.AssertIsDeltaVersion(false);
					delta._deleted.Add(t);
				}
			}


			return delta;
		}


		public static DataRecordList BestDiff(DataRecordList v2, DataRecordList v1)
		{
			DataRecordList delta = Diff(v2, v1);

//			// l'unica concessione che si fa alle performance e` non comprimere
//			CompressionType ct = CompressionType.None;
//
//			byte [] bDelta = CompactFormatter.WriteObject(delta, ct);
//			byte [] bv2 = CompactFormatter.WriteObject(v2, ct);
//
//			if (bDelta.Length < bv2.Length)
//				return delta;
//			else
//				return v2;

			long lenDelta = CompactFormatter.GetSerializeObejctStreamLen(delta);
			long lenV2 = CompactFormatter.GetSerializeObejctStreamLen(v2);
			if (lenDelta < lenV2)
				return delta;
			else
				return v2;
		}


		public bool IsDeltaList
		{
			get { return _inserted != null; }
		}

		protected int _version;
		protected ArrayList _list;
		protected ArrayList _inserted;
		protected ArrayList _deleted;
		protected ArrayList _updated;
	}

	internal struct Mask
	{
		private byte[] _m;
		private int _bitCount;

		public void SetBitSize(int n)
		{
			_bitCount = n;

			int sz = n/8;
			if ((n%8) > 0)
				sz += 1;
			_m = new byte[sz];
		}

		public string S
		{
			get
			{
				if (BitCount == 0) return "";
				StringBuilder s = new StringBuilder();
				for (int i = 0; i < BitCount; ++i)
					s.Append(Get(i) ? "1" : "0");
				return s.ToString();
			}
		}

		public int BitCount
		{
			get { return _bitCount; }
		}

		public void Serialize(CompactFormatter cf)
		{
			cf.Serialize(ref _bitCount);
			cf.Serialize(ref _m);
		}

		public void SetAll()
		{
			for (int i = 0; i < BitCount; ++i) Set(i);
		}

		public void SetBitSize(int n, bool defaultValue)
		{
			SetBitSize(n);
			if (defaultValue)
				SetAll();
			else
				ResetAll();
		}

		public void ResetAll()
		{
			for (int i = 0; i < BitCount; ++i) Reset(i);
		}

		public bool this[int b]
		{
			get { return Get(b); }
			set { Set(b, value); }
		}

		public void Set(int b)
		{
			Debug.Assert(b >= 0 && b < _bitCount);
			_m[b/8] |= (byte) (1 << (b%8));
		}

		public void Reset(int b)
		{
			Debug.Assert(b >= 0 && b < _bitCount);
			_m[b/8] &= (byte) (~(1 << (b%8)));
		}

		public bool Get(int b)
		{
			Debug.Assert(b >= 0 && b < _bitCount);
			return (_m[b/8] & ((byte) (1 << (b%8)))) > 0;
		}

		public void Set(int b, bool v)
		{
			if (v) Set(b);
			else Reset(b);
		}


		public static bool operator !=(Mask a, Mask b)
		{
			return !(a == b);
		}

		public static bool operator ==(Mask a, Mask b)
		{
			Debug.Assert(a.BitCount == b.BitCount);

			for (int i = 0; i < a.BitCount; ++i)
				if (a.Get(i) != b.Get(i))
					return false;
			return true;
		}

		public override int GetHashCode()
		{
			if (_m == null)
				return 0;
			return _m.GetHashCode();
		}

		public override bool Equals(object obj)
		{
			Mask b = (Mask) obj;

			Debug.Assert(BitCount == b.BitCount);

			for (int i = 0; i < BitCount; ++i)
				if (Get(i) != b.Get(i))
					return false;

			return true;
		}

		public void CopyValue(Mask v)
		{
			if (v._m == null)
			{
				this._m = null;
				return;
			}

			this._bitCount = v._bitCount;
			if (this._m.Length != v._m.Length)
				this._m = new byte[v._m.Length];

			for (int i = 0; i < BitCount; ++i)
				this[i] = v[i];
		}

	}


	public class CompactFormatterType
	{
		private CompactFormatterData[] _cfd;

		private CompactFormatterData[] _PK;
		private CompactFormatterData[] _Nullable;
		private CompactFormatterData[] _Visible;
		private CompactFormatterData[] _Value;

		public CompactFormatterType(Type classType)
		{
			_cfd = ExtractFieldInfo(classType);

			int totPK = 0;
			int totNullable = 0;
			int totVisible = 0;
			int totValue = 0;

			for (int i = 0; i < _cfd.Length; ++i)
			{
				CompactFormatterData c = _cfd[i];

				if (c.IsPrimaryKey)
					totPK += 1;

				if (c.IsNullable)
					totNullable += 1;

				if (c.IsPrimaryKey || c.IsVisible)
					totVisible += 1;

				if (c.IsPrimaryKey == false)
					totValue += 1;
			}

			ArrayList pkList = new ArrayList();
			ArrayList nullableList = new ArrayList();
			ArrayList visibleList = new ArrayList();
			ArrayList valueList = new ArrayList();

			for (int i = 0; i < _cfd.Length; ++i)
			{
				CompactFormatterData c = _cfd[i];

				if (c.IsPrimaryKey)
					pkList.Add(c);

				if (c.IsNullable)
					nullableList.Add(c);

				if (c.IsPrimaryKey || c.IsVisible)
					visibleList.Add(c);

				if (c.IsPrimaryKey == false)
					valueList.Add(c);
			}

			_PK = (CompactFormatterData[]) pkList.ToArray(typeof (CompactFormatterData));
			_Nullable = (CompactFormatterData[]) nullableList.ToArray(typeof (CompactFormatterData));
			_Visible = (CompactFormatterData[]) visibleList.ToArray(typeof (CompactFormatterData));
			_Value = (CompactFormatterData[]) valueList.ToArray(typeof (CompactFormatterData));

			int ni = this.Value.Length;
			int si = 0;
			foreach (CompactFormatterData c in this.Value)
			{
				if (c.IsNullable)
					c.SetPosition(ni++, si);
				else
					c.SetPosition(-1, si);
				si += 1;
			}
			Debug.Assert(si == this.Value.Length);
			Debug.Assert(ni == this.MaskSize());
		}

		public int MaskSize()
		{
			return this.Value.Length + this.Nullable.Length;
		}

		public void SMSize(out int start, out int end)
		{
			start = 0;
			end = this.Value.Length;
		}

		public void NMSize(out int start, out int end)
		{
			start = this.Value.Length;
			end = this.Value.Length + this.Nullable.Length;
		}


		public CompactFormatterData this[string DataName]
		{
			get
			{
				for (int i = 0; i < _cfd.Length; ++i)
					if (_cfd[i].DataName == DataName)
						return _cfd[i];

				throw new ArgumentOutOfRangeException("DataName", "campo non trovato nella classe <"+DataName+">: nome errato ?");
			}
		}


		public CompactFormatterData[] All
		{
			get { return _cfd; }
		}

		public CompactFormatterData[] PK
		{
			get { return _PK; }
		}

		public CompactFormatterData[] Nullable
		{
			get { return _Nullable; }
		}

		public CompactFormatterData[] Visible
		{
			get { return _Visible; }
		}

		public CompactFormatterData[] Value
		{
			get { return _Value; }
		}


		private static CompactFormatterData[] ExtractFieldInfo(Type classType)
		{
			//			if (typeof(BusinnesBase).IsAssignableFrom(classType))
			//				throw new ArgumentException("la classe deve derivate da Versionable", "classType");

			ArrayList ret = new ArrayList();

			// trovo i membri field e property publici con attributo CS
			MemberInfo[] mbiList = classType.GetMembers(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly);
			foreach (MemberInfo mbi in mbiList)
			{
				if (mbi.MemberType != MemberTypes.Field && mbi.MemberType != MemberTypes.Property)
					continue;

				if (mbi.IsDefined(typeof (DRAttribute), false) == false)
					continue;

				DRAttribute attr = (DRAttribute) mbi.GetCustomAttributes(typeof (DRAttribute), false)[0];

				if (mbi.MemberType == MemberTypes.Field)
				{
					FieldInfo fi = (FieldInfo) mbi;
					if (fi.IsInitOnly)
						throw new ArgumentException("il campo della classe � read-only", fi.Name);

					ret.Add(new CompactFormatterField((FieldInfo) mbi, attr.IsPrimaryKey, attr.IsNullable, attr.IsVisible));
				}
				else if (mbi.MemberType == MemberTypes.Property)
				{
					PropertyInfo pi = (PropertyInfo) mbi;
					if (pi.GetIndexParameters().Length > 0)
						throw new ArgumentException("la property non pu� avere parametri: ", pi.Name);

					if (pi.CanRead && pi.CanWrite == false)
						throw new ArgumentException("il campo della classe � read-only", pi.Name);

					ret.Add(new CompactFormatterProperty(pi, attr.IsPrimaryKey, attr.IsNullable, attr.IsVisible));
				}
			}
			return (CompactFormatterData[]) ret.ToArray(typeof (CompactFormatterData));
		}


		public object[] ReadPrimaryKey(DataRecord v)
		{
			ArrayList ar = new ArrayList();

			foreach (CompactFormatterData c in this.PK)
			{
				object pki = c.GetValue(v);
				ar.Add(pki);
			}

			return ar.ToArray();
		}


		public object[] ReadVisible(DataRecord v)
		{
			ArrayList ar = new ArrayList();

			foreach (CompactFormatterData c in this.Visible)
			{
				if (c.IsNullable == false || v.IsNull(c) == false)
				{
					object pki = c.GetValue(v);
					ar.Add(pki);
				}
				else
				{
					ar.Add(DBNull.Value);
				}
			}

			return ar.ToArray();
		}

	}

	public abstract class CompactFormatterData
	{
		public CompactFormatterData(bool pk, bool nullable, bool visible)
		{
			IsPrimaryKey = pk;
			IsNullable = nullable;
			IsVisible = visible;
		}

		public abstract object GetValue(object obj);
		public abstract void SetValue(object obj, object v);
		public abstract Type DataType { get; }
		public abstract string DataName { get; }
		public readonly bool IsPrimaryKey;

		public bool IsValue
		{
			get { return !IsPrimaryKey; }
		}

		public readonly bool IsNullable;
		public readonly bool IsVisible;

		public int NMPosition
		{
			get
			{
				Debug.Assert(_NMPosition != -1);
				return _NMPosition;
			}
		}

		public int SMPosition
		{
			get
			{
				Debug.Assert(_SMPosition != -1);
				return _SMPosition;
			}
		}

		private int _NMPosition = -1;
		private int _SMPosition = -1;

		public void SetPosition(int nm, int sm)
		{
			_NMPosition = nm;
			_SMPosition = sm;
		}
	}

	public class CompactFormatterField : CompactFormatterData
	{
		public CompactFormatterField(FieldInfo fi, bool pk, bool nullable, bool visible)
			: base(pk, nullable, visible)
		{
			_fi = fi;
		}

		public override object GetValue(object obj)
		{
			return _fi.GetValue(obj);
		}

		public override void SetValue(object obj, object v)
		{
			_fi.SetValue(obj, v);
		}

		public override Type DataType
		{
			get { return _fi.FieldType; }
		}

		public override string DataName
		{
			get { return _fi.Name; }
		}

		private FieldInfo _fi;
	}

	public class CompactFormatterProperty : CompactFormatterData
	{
		public CompactFormatterProperty(PropertyInfo pi, bool pk, bool nullable, bool visible)
			: base(pk, nullable, visible)
		{
			_pi = pi;
		}

		public override object GetValue(object obj)
		{
			return _pi.GetValue(obj, null);
		}

		public override void SetValue(object obj, object v)
		{
			_pi.SetValue(obj, v, null);
		}

		public override Type DataType
		{
			get { return _pi.PropertyType; }
		}

		public override string DataName
		{
			get { return _pi.Name; }
		}

		private PropertyInfo _pi;
	}


	public class DataRecordReader
	{
		public static DataRecordList Read(Type recordType, IDataReader rd)
		{
			DataRecordReader r = new DataRecordReader(recordType);
			return r.Read(rd);
		}

		public DataRecordReader(Type recordType)
		{
			if (!recordType.IsClass)
				throw new ArgumentNullException("recordType", "deve essere una classe!");

			if (typeof (DataRecord).IsAssignableFrom(recordType) == false)
				throw new ArgumentNullException("recordType", "deve derivare da DataRecord");

			this._ci = recordType.GetConstructor(new Type[] {});
			if (this._ci == null)
				throw new ArgumentException("recordType", "il costruttore deve essere senza parametri");

			this._cft = DataRecord.GetCFT(recordType);

			this._colNameMap = new Hashtable();
			foreach (CompactFormatterData c in _cft.All)
				this._colNameMap[c.DataName] = c.DataName;
		}

		public void MapColName(string dbName, CompactFormatterData fi)
		{
			_colNameMap[dbName] = fi.DataName;
		}


		private CompactFormatterData[] PrepareDb2ColMap(IDataReader rd)
		{
			CompactFormatterData[] db2colMap = new CompactFormatterData[rd.FieldCount];

			bool found = false;
			for (int f = 0; f < rd.FieldCount; ++f)
			{
				string dbName = rd.GetName(f);
				string colName = (string) _colNameMap[dbName];

				foreach (CompactFormatterData c in _cft.All)
				{
					if (c.DataName == colName)
					{
						db2colMap[f] = c;
						found = true;
						break;
					}
				}
			}
			if (!found)
			{
#if DEBUG
				Debugger.Break();
#endif
			}

			return db2colMap;
		}

		public DataRecordList Read(IDataReader rd)
		{
			DataRecordList ret = new DataRecordList();
			CompactFormatterData[] db2colMap = PrepareDb2ColMap(rd);

			while (rd.Read())
			{
				// instanzio il record
				DataRecord r = (DataRecord) _ci.Invoke(null);

				// metto a null tutti i campi nullabili
				foreach (CompactFormatterData c in _cft.Nullable)
					r.SetNull(c);

				// valorizzo campo per campo
				int nf = rd.FieldCount;
				for (int f = 0; f < nf; ++f)
				{
					CompactFormatterData c = db2colMap[f];
					if (c == null)
						continue; // il campo nel reader non ha un campo di ugual nome nel record

					// gestione null
					bool colNull = rd.IsDBNull(f);
					if (c.IsNullable)
						r.SetNull(c, colNull);
					else
					{
						if (colNull)
							throw new ApplicationException(string.Format("tb '{0}': col '{1}' not null", r.GetType().Name, c.DataName));
					}

					// gestione valore.
					if (colNull == false)
						AssignCol(r, c, rd[f]);
				}

				ret.Add(r);
			}
			return ret;
		}

		private static void AssignCol(DataRecord r, CompactFormatterData c, object dbValue)
		{
			Type colType = c.DataType;
			Type dbType = dbValue.GetType();

			if (colType.IsEnum)
			{
				if (dbValue is string)
				{
					// qui ho una stringa da convertire nell'enum
					object v = Enum.Parse(c.DataType, (string) dbValue, true);
					c.SetValue(r, v);
				}
				else
				{
					// qui ho un numero da convertire nell'enum
					object v = Enum.Parse(c.DataType, dbValue.ToString(), true);
					c.SetValue(r, v);
				}
			}
			else if (colType == typeof (Double))
			{
				object v = Convert.ToDouble(dbValue);
				c.SetValue(r, v);
			}
			else if (colType == typeof (bool))
			{
				if (dbType == typeof (string))
				{
					string v = ((string) dbValue).ToLower();
					bool b = v == "s" || v == "y" || v == "si" || v == "yes";
					c.SetValue(r, b);
				}
				else if (dbType == typeof (int) || dbType == typeof (short) || dbType == typeof (decimal))
				{
					int v = Convert.ToInt32(dbValue);
					c.SetValue(r, v != 0);
				}
				else
					c.SetValue(r, dbValue);
			}
			else
			{
				object v = dbValue;
				if (colType != dbType) v = Convert.ChangeType(dbValue, colType);
				c.SetValue(r, v);
			}
		}

		private CompactFormatterType _cft;
		private ConstructorInfo _ci;
		private Hashtable _colNameMap;
	}
}