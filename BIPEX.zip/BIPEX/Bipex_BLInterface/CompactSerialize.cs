using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Text;

#if !NOZIP
using ICSharpCode.SharpZipLib.BZip2;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Zip;
#endif

namespace Delta
{
	/// <summary>
	/// Interfaccia che un oggetto deve esporre per essere serializzabile in un stream
	/// </summary>
	public interface ICompactSerializable
	{
		/// <summary>
		/// funzione che scrive o legge un oggetto dallo stream <c>CompactFormatter</c>
		/// </summary>
		/// <param name="cf">lo stream da cui leggere o scrivere</param>
		void Serialize(CompactFormatter cf);
	}

	/// <summary>
	/// Tipo di compressione da usare quando si comprime o si decomprime un oggetto da un stream
	/// </summary>
	public enum CompressionType
	{
		/// <summary>
		/// Nessuna compressione
		/// </summary>
		None = 0,
		GZip = 1,
		BZip2 = 2,
		Zip = 3,
		/// <summary>
		/// Compressione migliore
		/// </summary>
		Best = 4
	}

	/// <summary>
	/// Stream su cui leggere o scrivere oggetti serializzati
	/// </summary>
	public class CompactFormatter
	{
		#region Data
		private bool _isWriting = false;
		private BinaryWriter _bw = null;
		private BinaryReader _br = null;
		private ArrayList _serialized = new ArrayList();
		private TypeList _typeList = new TypeList();
		#endregion

		#region Costruttore
		/// <summary>
		/// Costruisce un <c>CompactFormatter</c> che scrivera` o leggera` da <c>s</c>
		/// secondo il parametro <c>forWrite</c>
		/// </summary>
		/// <param name="s">lo stream </param>
		/// <param name="forWrite"></param>
		public CompactFormatter(Stream s, bool forWrite)
		{
			_serialized.Add(null); // zero tra i gia` serializzati indica un null ref

			_typeList.Add(typeof(CompactSerializableArrayList));

			_isWriting = forWrite;
			if (_isWriting)
				_bw = new BinaryWriter(s, Encoding.UTF8);
			else
				_br = new BinaryReader(s, Encoding.UTF8);
		}

		#endregion 

		#region Read Write Object
		/// <summary>
		/// Scrive un oggetto in uno stream e lo ritorna in un byte array
		/// </summary>
		/// <remarks>N.B. nello stream viene riportato il metodo di compressione None in 
		/// modo che <c>ReadObject</c> possa leggere utilizzando il corretto formato</remarks>
		/// <param name="v">l'oggetto da serializzare</param>
		/// <returns>lo stream di byte in cui l'oggetto e` serializzato</returns>
		private static byte[] WriteObject(ICompactSerializable v)
		{
			MemoryStream ms = new MemoryStream();
			CompactFormatter csw = new CompactFormatter(ms, true);
			csw.Serialize(v);
			csw.Flush();
			return ms.ToArray();
		}

		public static long GetSerializeObejctStreamLen(ICompactSerializable v)
		{
			NullStream s = new NullStream();
			CompactFormatter csw = new CompactFormatter(s, true);
			csw.Serialize(v);
			csw.Flush();
			return s.Position;
		}



		/// <summary>
		/// scrive un oggetto in uno stream comprimendolo con il metodo indicato da <c>ct</c>
		/// </summary>
		/// <remarks>Se <c>ct</c> e` <c>None</c> non si comprime.
		/// Se <c>ct</c> e` Best la funzione sceglie il miglior alogoritmo di compressione.
		/// Altrimenti la funzione usa la compressione indicata.
		/// N.B. la funzione scrive nello stream il metodo di compressione usato
		/// </remarks>
		/// <param name="v">l'oggetto da serializzare</param>
		/// <param name="ct">il metodo di compressione</param>
		/// <returns>lo strem di byte</returns>
		public static byte [] WriteObject(ICompactSerializable v, CompressionType ct)
		{
			byte[] bNone = WriteObject(v);

			byte [] bz = new byte[1 + bNone.Length];
			bz[0] = (byte) CompressionType.None;
			Array.Copy(bNone, 0, bz, 1, bNone.Length);

			if (ct == CompressionType.None)
				return bz;

			CompressionType cMin;
			CompressionType cMax;

			if (ct == CompressionType.Best)
			{
				cMin = CompressionType.None + 1;
				cMax = CompressionType.Best - 1;
			}
			else
			{
				cMin = ct;
				cMax = ct;
			}

#if !NOZIP

			for (CompressionType cc = cMin; cc <= cMax; cc++)
			{
				Stream z = null;
				MemoryStream msZipped = new MemoryStream();

				switch (cc)
				{
				case CompressionType.BZip2:
					z = new BZip2OutputStream(msZipped);
					break;

				case CompressionType.GZip:
					z = new GZipOutputStream(msZipped);
					break;

				case CompressionType.Zip:
					{
						ZipOutputStream zip = new ZipOutputStream(msZipped);
						zip.PutNextEntry(new ZipEntry("z"));
						z = zip;
						break;
					}
				}

				z.Write(bNone, 0, bNone.Length);
				z.Close();

				byte[] bzi = msZipped.ToArray();

				if (bzi.Length < bz.Length - 1)
				{
					bz = new byte[1 + bzi.Length];
					bz[0] = (byte) cc;
					Array.Copy(bzi, 0, bz, 1, bzi.Length);
				}
			}
#endif
			return bz;
		}


		/// <summary>
		/// Legge dallo stream di dati <c>b</c> un oggetto derivato da <c>ICompactSerializable</c>
		/// </summary>
		/// <param name="b">lo stream da cui leggere</param>
		/// <returns>l'oggetto letto</returns>
		public static ICompactSerializable ReadObject(byte[] b)
		{
			MemoryStream msZipped = new MemoryStream(b, 1, b.Length - 1, false);

			Stream z = null;
			switch ((CompressionType) b[0])
			{
			case CompressionType.None:
				z = msZipped;
				break;
#if !NOZIP
			case CompressionType.GZip:
				z = new GZipInputStream(msZipped);
				break;
			case CompressionType.BZip2:
				z = new BZip2InputStream(msZipped);
				break;
			case CompressionType.Zip:
				{
					ZipInputStream zip = new ZipInputStream(msZipped);
					zip.GetNextEntry();
					z = zip;
					break;
				}
#endif			
			}

			CompactFormatter csr = new CompactFormatter(z, false);
			ICompactSerializable r = null;
			r = csr.Serialize(r);
			return r;
		}
		#endregion


		/// <summary>
		/// indica se sto leggendo o scrivendo dal <c>CompactFormatter</c>
		/// </summary>
		public bool IsWriting { get { return _isWriting; } }

		#region Serialize by ref

		public void Serialize(ref System.Byte a)
		{
			if (IsWriting)
				WriteByte(a);
			else
				a = ReadByte();
		}

		public void Serialize(ref System.Boolean a)
		{
			if (IsWriting)
				WriteBoolean(a);
			else
				a = ReadBoolean();
		}
		public void Serialize(ref System.Char a)
		{
			if (IsWriting)
				WriteChar(a);
			else
				a = ReadChar();
		}

		public void Serialize(ref System.Int16 a)
		{
			if (IsWriting)
				WriteInt16(a);
			else
				a = ReadInt16();
		}
		public void Serialize(ref System.Int32 a)
		{
			if (IsWriting)
				WriteInt32(a);
			else
				a = ReadInt32();
		}

		public void Serialize(ref System.Int64 a)
		{
			if (IsWriting)
				WriteInt64(a);
			else
				a = ReadInt64();
		}

		public void Serialize(ref System.UInt16 a)
		{
			if (IsWriting)
				WriteUInt16(a) ;
			else
				a = ReadUInt16();
		}
		public void Serialize(ref System.UInt32 a)
		{
			if (IsWriting)
				WriteUInt32(a) ;
			else
				a = ReadUInt32();
		}
		public void Serialize(ref System.UInt64 a)
		{
			if (IsWriting)
				WriteUInt64(a);
			else
				a = ReadUInt64();
		}

		public void Serialize(ref System.Single a)
		{
			if (IsWriting)
				WriteSingle(a) ;
			else
				a = ReadSingle();
		}
		public void Serialize(ref System.Double a)
		{
			if (IsWriting)
				WriteDouble(a) ;
			else
				a = ReadDouble();
		}

		public void Serialize(ref System.Decimal a)
		{
			if (IsWriting)
				WriteDecimal(a);
			else
				a = ReadDecimal();
		}

		public void Serialize(ref System.DateTime a)
		{
			if (IsWriting)
				WriteDateTime(a);
			else
				a = ReadDateTime();
		}

		public void Serialize(ref System.String a)
		{
			if (IsWriting)
				WriteString(a);
			else
				a = ReadString();
		}

		public void Serialize(ref ICompactSerializable[] a)
		{
			if (IsWriting)
				WriteICompactSerializableArray(a);
			else
				a = ReadICompactSerializableArray();
		}

		/// <summary>
		/// Serializza un ArrayList che contiene solo elementi <c>ICompactSerializable</c>
		/// </summary>
		/// <param name="a"></param>
		public void Serialize(ref ArrayList a)
		{
			if (IsWriting)
				WriteArrayList(a);
			else
				a = ReadArrayList();
		}

		public void Serialize(ref System.String [] a)
		{
			if (IsWriting)
				WriteStringArray(a);
			else
				a = ReadStringArray();
		}

		public void Serialize(ref System.Byte [] a)
		{
			if (IsWriting)
				WriteByteArray(a);
			else
				a = ReadByteArray();
		}

		public void Serialize(ref System.Int32 [] a)
		{
			if (IsWriting)
				WriteInt32Array(a);
			else
				a = ReadInt32Array();
		}


		/// <summary>
		/// Serializza un qualunque oggetto derivato da <c>ICompactSerializable</c>
		/// </summary>
		/// <remarks>L'oggetto deve implementare il costruttore di default (senza parametri)
		/// e il metodo <c>ICompactSerializable.Serialize</c>
		/// </remarks>
		/// <param name="a"></param>
		/// <returns></returns>
		public ICompactSerializable Serialize(ICompactSerializable a)
		{
			if (IsWriting)
				WriteICompactSerializable(a);
			else
				a = ReadICompactSerializable();
			return a;
		}

		#endregion

		#region Read/Write<Type>()
		public System.Boolean ReadBoolean() { return _br.ReadBoolean(); }
		public System.Byte ReadByte() { return _br.ReadByte(); }
		public System.SByte ReadSByte() { return _br.ReadSByte(); }
		public void WriteBoolean(System.Boolean v) { _bw.Write(v); }
		public void WriteByte(System.Byte v) { _bw.Write(v); }
		public void WriteSByte(System.SByte v) { _bw.Write(v); }

		public System.Int16 ReadInt16() { return _br.ReadInt16(); }
		public System.Int32 ReadInt32() 
		{
			byte ba = _br.ReadByte();
			if (ba == 0xff)
				return _br.ReadInt32();
			else if (ba == 0xfe)
				return -1;
			else
				return ba;
		}
		public System.Int64 ReadInt64() { return _br.ReadInt64(); }
		public void WriteInt16(System.Int16 v) { _bw.Write(v); }
		public void WriteInt32(System.Int32 v)
		{
			if (v >= 0 && v < 0xfe)
			{
				byte ba = (byte)v;
				_bw.Write(ba);
			}
			else if (v == -1)
			{
				byte ba = (byte)0xfe;
				_bw.Write(ba);
			}
			else
			{
				_bw.Write((byte)0xff);
				_bw.Write(v);
			}
		}
		public void WriteInt64(System.Int64 v) { _bw.Write(v); }

		public System.UInt16 ReadUInt16() { return _br.ReadUInt16(); }
		public System.UInt32 ReadUInt32() { return _br.ReadUInt32(); }
		public System.UInt64 ReadUInt64() { return _br.ReadUInt64(); }
		public void WriteUInt16(System.UInt16 v) { _bw.Write(v); }
		public void WriteUInt32(System.UInt32 v) { _bw.Write(v); }
		public void WriteUInt64(System.UInt64 v) { _bw.Write(v); }

		public System.Single ReadSingle() { return _br.ReadSingle(); }
		public System.Double ReadDouble() { return _br.ReadDouble(); }
		public System.Decimal ReadDecimal() { return _br.ReadDecimal(); }
		public void WriteSingle(System.Single v) { _bw.Write(v); }
		public void WriteDouble(System.Double v) { _bw.Write(v); }
		public void WriteDecimal(System.Decimal v) { _bw.Write(v); }

		public System.Char ReadChar() { return _br.ReadChar(); }
		public void WriteChar(System.Char v) { _bw.Write(v); }

		public System.String ReadString() 
		{
			int n = _br.ReadByte();
			if (n == 0xff)
				return null;
			else
			{
				if (n == 0xfe)
					n = _br.ReadInt32();

				byte[] b;
				if (n > 0) 
					b = _br.ReadBytes(n);
				else 
					b = new byte[0];

				return Encoding.UTF8.GetString(b);
			}
		}
		public void WriteString(System.String v) 
		{
			if (v == null)
				_bw.Write((byte) 0xff); // puntatore null
			else
			{
				byte[] b = Encoding.UTF8.GetBytes(v);
				int n = b.Length;
				if (n >= 0xfe)
				{
					_bw.Write((byte) 0xfe); // la lunghezza a 4 byte
					_bw.Write(n);
				}
				else
				{
					_bw.Write((byte) n);
				}
				_bw.Write(b, 0, n);
			}
		}


		public System.DateTime ReadDateTime() { long t = _br.ReadInt64(); return new DateTime(t); }
		public void WriteDateTime(System.DateTime v) { _bw.Write(v.Ticks); }

		public Type ReadType()
		{
			byte s = _br.ReadByte();
			if (s == 1)
			{
				string typeName = _br.ReadString();
				if (typeName == string.Empty)
					return null;
				return _typeList.Add(typeName).Type;
			}
			else if (s == 2)
			{
				int typeIndex = _br.ReadInt32();
				return _typeList.GetTypeByIndex(typeIndex);
			}
			else
				throw new ArgumentOutOfRangeException("ReadType: wrong byte");
		}
		public void WriteType(Type ty)
		{
			if (ty == null)
			{
				_bw.Write((byte)1);
				_bw.Write(string.Empty);
				return;
			}

			string typeName = TypeList.GetTypeName(ty);

			int k = this._typeList.IndexOfTypeName(typeName);
			if (k < 0)
			{
				// il tipo e` nuovo --> lo scrivo come stringa
				_bw.Write((byte) 1);
				_bw.Write(typeName);

				_typeList.Add(typeName); // notare che in _typeName in valore non serve in scrittura.
			}
			else
			{
				// il tipo e` gia` stato serializzato --> lo scrivo come indice
				_bw.Write((byte) 2);
				_bw.Write(k);
			}
		}


		public System.String [] ReadStringArray()
		{
			int sz = ReadInt32();
			if (sz == -1)
				return null;
			else
			{
				String [] a = new string[sz];
				for (int i = 0; i < sz; ++i)
					a[i] = ReadString();
				return a;
			}
		}
		public void WriteStringArray(System.String [] v)
		{
			if (v == null)
			{
				WriteInt32(-1);
			}
			else
			{
				int sz = v.Length;
				WriteInt32(sz);
				for (int i = 0; i < sz; ++i)
					WriteString(v[i]);
			}
		}


		public System.Byte [] ReadByteArray()
		{
			int sz = ReadInt32();
			if (sz == -1)
				return null;
			else
			{
				byte [] a = new byte[sz];
				for (int i = 0; i < sz; ++i)
					a[i] = ReadByte();
				return a;
			}
		}
		public void WriteByteArray(System.Byte [] v)
		{
			if (v == null)
			{
				WriteInt32(-1);
			}
			else
			{
				int sz = v.Length;
				WriteInt32(sz);
				for (int i = 0; i < sz; ++i)
					WriteByte(v[i]);
			}
		}


		public System.Int32 [] ReadInt32Array()
		{
			int sz = ReadInt32();
			if (sz == -1)
				return null;
			else
			{
				System.Int32 [] a = new System.Int32[sz];
				for (int i = 0; i < sz; ++i)
					a[i] = ReadInt32();
				return a;
			}
		}
		public void WriteInt32Array(System.Int32 [] v)
		{
			if (v == null)
			{
				WriteInt32(-1);
			}
			else
			{
				int sz = v.Length;
				WriteInt32(sz);
				for (int i = 0; i < sz; ++i)
					WriteInt32(v[i]);
			}
		}



		public ICompactSerializable ReadICompactSerializable()
		{
			byte s = _br.ReadByte();

			if (s == 0)
			{
				int t = _br.ReadInt32();
				return (ICompactSerializable) _serialized[t];
			}
			else
			{
				ConstructorInfo ci = null;

				if (s == 1)
				{
					string typeName = _br.ReadString();
					ci = _typeList.Add(typeName).ConstructorInfo;
				}
				else if (s == 2)
				{
					int k = _br.ReadInt32();
					ci = this._typeList.GetConstructorInfoByIndex(k);
				}
				else
					throw new ArgumentOutOfRangeException("s");

				ICompactSerializable a = (ICompactSerializable) ci.Invoke(new object[] {});
				_serialized.Add(a);
				a.Serialize(this);

				return a;
			}
		}
		public void WriteICompactSerializable(ICompactSerializable v)
		{
			int t = SearchSerialized(v);
			if (t >= 0)
			{
				// l'oggetto e` stato gia` serializzato --> memorizzo l'indice
				_bw.Write((byte) 0);
				_bw.Write(t);
			}
			else
			{
				// l'oggetto non e` mai stato serializzato
				Type ty = v.GetType();
				string typeName = TypeList.GetTypeName(ty);

				int k = this._typeList.IndexOfTypeName(typeName);
				if (k < 0)
				{
					// il tipo e` nuovo --> lo scrivo come stringa
					_bw.Write((byte) 1);
					_bw.Write(typeName);

					ConstructorInfo ci = _typeList.Add(typeName).ConstructorInfo;
					// qui controllo che esista il costruttore di default...
					if (ci == null)
						throw new ApplicationException(typeName + " non ha il costruttore senza parametri");
				}
				else
				{
					// il tipo e` gia` stato serializzato --> lo scrivo come indice
					_bw.Write((byte) 2);
					_bw.Write(k);
				}

				_serialized.Add(v);
				v.Serialize(this);
			}
		}


		public void WriteICompactSerializableArray(ICompactSerializable [] v)
		{
			if (v == null)
			{
				WriteInt32(-1);
			}
			else
			{
				int sz = v.Length;
				WriteInt32(sz);
				for (int i = 0; i < sz; ++i)
					WriteICompactSerializable(v[i]) ;
			}
		}

		public ICompactSerializable [] ReadICompactSerializableArray()
		{
			int sz = ReadInt32();
			if (sz == -1)
				return null;
			else
			{
				ICompactSerializable [] a = new ICompactSerializable[sz];
				for (int i = 0; i < sz; ++i)
					a[i] = ReadICompactSerializable();
				return a;
			}
		}


		public void WriteArrayList(ArrayList v)
		{
			if (v == null)
			{
				WriteInt32(-1);
			}
			else
			{
				int sz = v.Count;
				WriteInt32(sz);
				for (int i = 0; i < sz; ++i)
					WriteICompactSerializable((ICompactSerializable) v[i]) ;
			}
		}

		public ArrayList ReadArrayList()
		{
			int sz = ReadInt32();
			if (sz == -1)
				return null;
			else
			{
				ArrayList a = new ArrayList();
				for (int i = 0; i < sz; ++i)
					a.Add(ReadICompactSerializable());
				return a;
			}
		}

		#endregion

		#region ReadType/WriteType
		public object ReadType(Type ty)
		{
			TypeCode tt = Type.GetTypeCode(ty);

			if (ty.IsEnum)
			{
				switch (tt)
				{
					case TypeCode.SByte:  return Enum.ToObject(ty, ReadSByte());
					case TypeCode.Byte:   return Enum.ToObject(ty, ReadByte());
					case TypeCode.Int16:  return Enum.ToObject(ty, ReadInt16());
					case TypeCode.UInt16: return Enum.ToObject(ty, ReadUInt16());
					case TypeCode.Int32:  return Enum.ToObject(ty, ReadInt32());
					case TypeCode.UInt32: return Enum.ToObject(ty, ReadUInt32());
					case TypeCode.Int64:  return Enum.ToObject(ty, ReadInt64());
					case TypeCode.UInt64: return Enum.ToObject(ty, ReadUInt64());
					default: throw new ApplicationException(ty.Name + " : tipo non gestito");
				}
			}

			switch (tt)
			{
			case TypeCode.Empty:    break;
			case TypeCode.Object:   break;
			case TypeCode.DBNull:   break;
			case TypeCode.Boolean:  return ReadBoolean();
			case TypeCode.Char:     return ReadChar();
			case TypeCode.SByte:    return ReadSByte();
			case TypeCode.Byte:     return ReadByte();
			case TypeCode.Int16:    return ReadInt16();
			case TypeCode.UInt16:   return ReadUInt16();
			case TypeCode.Int32:    return ReadInt32();
			case TypeCode.UInt32:   return ReadUInt32();
			case TypeCode.Int64:    return ReadInt64();
			case TypeCode.UInt64:   return ReadUInt64();
			case TypeCode.Single:   return ReadSingle();
			case TypeCode.Double:   return ReadDouble();
			case TypeCode.Decimal:  return ReadDecimal();
			case TypeCode.DateTime: return ReadDateTime();
			case TypeCode.String:   return ReadString();
			}


			if (ty == typeof(String[])) { return ReadStringArray(); }
			if (ty == typeof(Byte[]))   { return ReadByteArray(); }
			if (ty == typeof(Int32[]))  { return ReadInt32Array(); }

			if (typeof(ICompactSerializable).IsAssignableFrom(ty)) return ReadICompactSerializable();

			if (ty == typeof(ICompactSerializable [])) { return ReadICompactSerializableArray(); }
			if (ty == typeof(ArrayList)) { return ReadArrayList(); }

			throw new ApplicationException(ty.Name + " : tipo non gestito");
		}

		public void WriteType(Type ty, object v)
		{
			TypeCode tt = Type.GetTypeCode(ty); // gli Enum ritornano direttamente il tipo intero
			switch (tt)
			{
			case TypeCode.Empty:    break;
			case TypeCode.Object:   break;
			case TypeCode.DBNull:   break;
			case TypeCode.Boolean:  WriteBoolean((Boolean)v); return;
			case TypeCode.Char:     WriteChar((Char)v); return;
			case TypeCode.SByte:    WriteSByte((SByte)v); return;
			case TypeCode.Byte:     WriteByte((Byte)v); return;
			case TypeCode.Int16:    WriteInt16((Int16)v); return;
			case TypeCode.UInt16:   WriteUInt16((UInt16)v); return;
			case TypeCode.Int32:    WriteInt32((Int32)v); return;
			case TypeCode.UInt32:   WriteUInt32((UInt32)v); return;
			case TypeCode.Int64:    WriteInt64((Int64)v); return;
			case TypeCode.UInt64:   WriteUInt64((UInt64)v); return;
			case TypeCode.Single:   WriteSingle((Single)v); return;
			case TypeCode.Double:   WriteDouble((Double)v); return;
			case TypeCode.Decimal:  WriteDecimal((Decimal)v); return;
			case TypeCode.DateTime: WriteDateTime((DateTime)v); return;
			case TypeCode.String:   WriteString((String)v); return;
			}

			if (ty == typeof(String[])) { WriteStringArray((String[])v); return; }
			if (ty == typeof(Byte[]))   { WriteByteArray((Byte[])v); return; }
			if (ty == typeof(Int32[]))  { WriteInt32Array((Int32[])v); return; }

			if (typeof(ICompactSerializable).IsAssignableFrom(ty)) { WriteICompactSerializable((ICompactSerializable)v); return; }

			if (ty == typeof(ICompactSerializable [])) { WriteICompactSerializableArray((ICompactSerializable[]) v); }
			if (ty == typeof(ArrayList)) { WriteArrayList((ArrayList) v); }

			throw new ApplicationException(ty.Name + " : tipo non gestito");
		}
		#endregion

		private int SearchSerialized(ICompactSerializable a)
		{
			for (int i = 0; i < _serialized.Count; ++i)
				if (_serialized[i] == a)
					return i;
			return -1;
		}

		public void Flush()
		{
			if (_bw != null)
				_bw.Flush();
		}

	}



	public class TypeList
	{
		SortedList s = new SortedList();

		public class TypeConstructorInfoPair
		{
			public TypeConstructorInfoPair(Type ty, ConstructorInfo ci)
			{
				_ty = ty;
				_ci = ci;
			}
			Type _ty;
			ConstructorInfo _ci;

			public Type Type { get { return _ty; }}
			public ConstructorInfo ConstructorInfo { get { return _ci; }}
		}

		public static string GetTypeName(Type ty)
		{
			string typeName = ty.AssemblyQualifiedName;
			typeName = typeName.Substring(0, typeName.IndexOf(", Version"));
			return typeName;			
		}

		public TypeConstructorInfoPair Add(Type ty)
		{
			string typeName = GetTypeName(ty);

			TypeConstructorInfoPair p = new TypeConstructorInfoPair(ty, ty.GetConstructor(new Type[] {}));
			s.Add(typeName, p);
			return p;
		}
		public TypeConstructorInfoPair Add(string typeName) { return this.Add(Type.GetType(typeName)); }

		public int IndexOfTypeName(string typeName) { return s.IndexOfKey(typeName); }
		public int IndexOfType(Type ty)
		{
			string typeName = GetTypeName(ty);
			return s.IndexOfKey(typeName);
		}

		public ConstructorInfo GetConstructorInfoByIndex(int k)
		{
			TypeConstructorInfoPair p = (TypeConstructorInfoPair) s.GetByIndex(k);
			return p.ConstructorInfo;
		}
		public Type GetTypeByIndex(int k)
		{
			TypeConstructorInfoPair p = (TypeConstructorInfoPair) s.GetByIndex(k);
			return p.Type;
		}

		public TypeConstructorInfoPair GetTypeConstructorInfoPairByIndex(int k)
		{
			TypeConstructorInfoPair p = (TypeConstructorInfoPair) s.GetByIndex(k);
			return p;
		}
	}

	public class NullStream : Stream
	{
		long p = 0;

		public override void Flush() {}
		public override long Seek(long offset, SeekOrigin origin) { throw new NotImplementedException(); }
		public override void SetLength(long value) { throw new NotImplementedException(); }
		public override int Read(byte[] buffer, int offset, int count) {  throw new NotImplementedException(); }
		public override void Write(byte[] buffer, int offset, int count) { p += count; }
		public override bool CanRead { get { return false; } }
		public override bool CanSeek { get { return false; } }
		public override bool CanWrite {  get { return true; } }
		public override long Length { get { return p; } }
		public override long Position
		{
			get { return p; }
			set { throw new NotImplementedException(); }
		}
	}


	// esempio di implementazione
	[Serializable]
	public class CompactSerializableArrayList : ArrayList, ICompactSerializable
	{
		public void Serialize(CompactFormatter cf)
		{
			if (cf.IsWriting)
			{
				cf.WriteArrayList(this);
			}
			else
			{
				ArrayList a = cf.ReadArrayList();
				this.Clear();
				this.AddRange(a);
			}
		}
	}
}