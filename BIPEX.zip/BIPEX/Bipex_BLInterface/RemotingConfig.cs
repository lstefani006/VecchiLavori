using System;
using System.Reflection;
using System.Runtime.Remoting;
using RemOpBasedChannel;

namespace Bipex_BLInterface
{
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface)]
	public class RemotableClientAttribute : Attribute
	{
		public RemotableClientAttribute(string serverName, string uri)
		{
			if (serverName == null || serverName.Length == 0)
				throw new ArgumentNullException("serverName");
			if (uri == null || uri.Length == 0)
				throw new ArgumentNullException("uri");

			_serverName = serverName;
			_uri = uri;
		}

		private string _serverName;
		private string _uri;

		public string ServerName
		{
			get { return _serverName; }
		}

		public string Uri
		{
			get { return _uri; }
		}
	}

	[AttributeUsage(AttributeTargets.Class)]
	public class RemotableServerAttribute : Attribute
	{
		public RemotableServerAttribute(string serverName, string uri)
		{
			if (serverName == null || serverName.Length == 0)
				throw new ArgumentNullException("serverName");
			if (uri == null || uri.Length == 0)
				throw new ArgumentNullException("uri");

			_serverName = serverName;
			_uri = uri;
		}

		public WellKnownObjectMode Activation = WellKnownObjectMode.SingleCall;

		private string _serverName;
		private string _uri;

		public string ServerName
		{
			get { return _serverName; }
		}
		public string Uri
		{
			get { return _uri; }
		}

	}

	public class RemConfig
	{
		public static string ClientConfigURI = "remop://{0}/{1}"; // uri per i clienti

		private static bool RemotingConfiguration_Config_Called = false;

		public static void ClientConfig(string blConfig, Assembly ass)
		{
			if (!RemotingConfiguration_Config_Called)
			{
				RemotingConfiguration.Configure(blConfig);
				RemotingConfiguration_Config_Called = true;
			}

			// se sono anche server nodeName e` != ""
			// se sono SOLO cliente nodeName == ""
			string nodeName = RemOpChannel.ServerName;
			if (nodeName == null) nodeName = string.Empty;

			foreach (Type t in ass.GetExportedTypes())
			{
				// gia` configurato ?
				if (RemotingConfiguration.IsWellKnownClientType(t) != null)
					continue;

				object[] ta = t.GetCustomAttributes(typeof (RemotableClientAttribute), true);
				foreach (RemotableClientAttribute rca in ta)
				{
					// se l'oggetto e` esposto da un Server diverso dal mio nodeName
					// allora il mio nodeName e` un client
					// altrimenti non posso essere server e client contemporaneamente
					if (nodeName != rca.ServerName)
					{
						string uri = string.Format(ClientConfigURI, rca.ServerName, rca.Uri);
						RemotingConfiguration.RegisterWellKnownClientType(t, uri);
					}
				}
			}
		}


		public static void ServerConfig(string blConfig, Assembly ass)
		{
			if (!RemotingConfiguration_Config_Called)
			{
				RemotingConfiguration.Configure(blConfig);
				RemotingConfiguration_Config_Called = true;
			}

			string serverName = RemOpChannel.ServerName;

			foreach (Type t in ass.GetExportedTypes())
			{
				// gia configurato ?
				if (RemotingConfiguration.IsRemotelyActivatedClientType(t) != null)
					continue;

				object[] ta = t.GetCustomAttributes(typeof (RemotableServerAttribute), true);
				foreach (RemotableServerAttribute rsa in ta)
				{
					// se l'oggetto indica che deve essere hostato da questo server
					// allora lo registro.
					if (rsa.ServerName == serverName)
					{
						RemotingConfiguration.RegisterWellKnownServiceType(t, rsa.Uri, rsa.Activation);
					}
				}
			}
		}
	}
}