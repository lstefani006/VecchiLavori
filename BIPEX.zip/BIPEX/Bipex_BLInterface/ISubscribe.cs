using System;

namespace Bipex_BLInterface
{
	/// <summary>
	/// Interfaccia utilizzata da Bipex_ControlWS quando riceve una richiesta BipexSubject con
	/// componente Subscribe valorizzato, ossia quando riceve una richiesta di abbonamento per il saldo fisico
	/// </summary>
	[RemotableClient("Bipex_CacheServer", "Subscribe.rem")]
	public interface ISubscribe
	{
		void Subscribe_SaldoFisico(Subscribe_SaldoFisico_Data [] s);
	}

	[Serializable]
	public class Subscribe_SaldoFisico_Data
	{
		public string CodiceOperatore;
		public DateTime DataDelivery;

		public DateTime LastSubscribe = DateTime.MinValue; // non valorizzare dal client.. usato dalla internamente dalla Cache
	}
}