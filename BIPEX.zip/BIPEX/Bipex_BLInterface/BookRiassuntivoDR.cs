using System;
using Delta;

namespace Bipex_BLInterface
{

	/// <summary>
	/// SubjectType="BR"
	/// SubjectSubType=""
	/// </summary>
	public class BookRiassuntivoDR : DataRecord 
	{
		public const string SubjectType = "BR";
		public const string SubjectSubType = "";

		[Flags] public enum Indicator : byte 
		{
			None = 0,

			// bit 0/1
			BestBidTrendUP    =  (1 << 0), // 1
			BestBidTrendDown  =  (1 << 1), // 2

			// bit 2/3
			BestAskTrendUP    =  (1 << 2), // 4
			BestAskTrendDown  =  (1 << 3), // 8
		}

		public static bool IsBestBidTrendUP(Indicator i)    { return (i & Indicator.BestBidTrendUP)   > 0; } 
		public static bool IsBestBidTrendDown(Indicator i)  { return (i & Indicator.BestBidTrendDown) > 0; }
		public static bool IsBestAskTrendUP(Indicator i)    { return (i & Indicator.BestAskTrendUP)   > 0; }
		public static bool IsBestAskTrendDown(Indicator i)  { return (i & Indicator.BestAskTrendDown) > 0; }

		public bool IsMaxPriceIsLastAbb()
		{
			if (IsNull("LastPrice") || IsNull("MaxPrice")) return false;
			return LastPrice == MaxPrice;
		}
		public bool IsMinPriceIsLastAbb()
		{
			if (IsNull("LastPrice") || IsNull("MinPrice")) return false;
			return LastPrice == MinPrice;
		}

		public bool IsLastAbbIsOTC()
		{
			if (IsNull("LastIsOTC"))
				return false;
			return LastIsOTC == "S";
		}


//		// Servono per simulazione...
//		public void SetBestBidTrendUP()    
//		{ 
//			Indicators |= Indicator.BestBidTrendUP; 
//			Indicators &= ~Indicator.BestBidTrendDown; 
//		} 
//		public void SetBestBidTrendDown()  
//		{ 
//			Indicators &= ~Indicator.BestBidTrendUP; 
//			Indicators |= Indicator.BestBidTrendDown; 
//		}
		public void SetBestBidTrendStopped()  
		{ 
			Indicators &= ~Indicator.BestBidTrendUP; 
			Indicators &= ~Indicator.BestBidTrendDown; 
		}
//		public void SetBestAskTrendUP()    
//		{ 
//			Indicators |= Indicator.BestAskTrendUP; 
//			Indicators &= ~Indicator.BestAskTrendDown; 
//		}
//		public void SetBestAskTrendDown()  
//		{ 
//			Indicators &= ~Indicator.BestAskTrendUP;
//			Indicators |= Indicator.BestAskTrendDown; 
//		}
		public void SetBestAskTrendStopped()  
		{ 
			Indicators &= ~Indicator.BestAskTrendUP;
			Indicators &= ~Indicator.BestAskTrendDown; 
		}
//		public void SetLastAbbIsOTC()      
//		{ 
//			Indicators |= Indicator.LastAbbIsOTC; 
//		}
//		public void SetLastAbbIsNotOTC()   
//		{ 
//			Indicators &= ~Indicator.LastAbbIsOTC; 
//		}
//		public void SetMaxPriceIsLastAbb() 
//		{ 
//			Indicators |= Indicator.MaxPriceIsLastAbb; 
//		}
//		public void SetMaxPriceIsNotLastAbb() 
//		{ 
//			Indicators &= ~Indicator.MaxPriceIsLastAbb; 
//		}
//		public void SetMinPriceIsLastAbb() 
//		{ 
//			Indicators |= Indicator.MinPriceIsLastAbb; 
//		}
//		public void SetMinPriceIsNotLastAbb() 
//		{ 
//			Indicators &= ~Indicator.MinPriceIsLastAbb; 
//		}

		[DR(DRE.PrimaryKey)] public string    Contract = string.Empty;
		[DR]                 public int       Hours;

		[DR(DRE.Nullable)]   public int       BidIdOfferta;
		[DR(DRE.Nullable)]   public double    BidPrice;
		[DR(DRE.Nullable)]   public int       BidQty;
		[DR(DRE.Nullable)]   public string    BidOperator = string.Empty;
		[DR(DRE.Nullable)]   public DateTime  BidTS;

		[DR(DRE.Nullable)]   public int       AskIdOfferta;
		[DR(DRE.Nullable)]   public double    AskPrice;
		[DR(DRE.Nullable)]   public int       AskQty;
		[DR(DRE.Nullable)]   public string    AskOperator = string.Empty;
        [DR(DRE.Nullable)]   public DateTime  AskTS;

		[DR(DRE.Nullable)]   public int       LastQty;
		[DR(DRE.Nullable)]   public double    LastPrice;
		[DR(DRE.Nullable)]   public DateTime  LastTime;
		[DR(DRE.Nullable)]   public string    LastIsOTC;

		// prezzo massimo di abbinamento nella giornata
		[DR(DRE.Nullable)]   public double    MaxPrice;
		// prezzo minimo di abbinamento nella giornata
		[DR(DRE.Nullable)]   public double    MinPrice;
		[DR(DRE.Nullable)]   public int       Volume;
		[DR(DRE.Nullable)]   public double    ConvPrice;
		[DR(DRE.Nullable)]   public double    OffPrice;
		[DR(DRE.Nullable)]   public double    RefPrice;
		[DR(DRE.Nullable)]   public Indicator Indicators = Indicator.None;

		[DR(DRE.Nullable)]   public DateTime  IndicatorBidChangeTS;
		[DR(DRE.Nullable)]   public DateTime  IndicatorAskChangeTS;


		public BookRiassuntivoDR()
		{
			// LEO TODO che roba e`
			SetNull("BidPrice");
			BidTS = System.DateTime.Now;
			SetNull("AskPrice");
			AskTS = System.DateTime.Now;
		}

		public BookRiassuntivoDR(string contract, int hours)
		{
			this.Contract = contract;
			this.Hours = hours;

			foreach (CompactFormatterData c in CFT.Value)
			{
				if (c.IsNullable)
					SetNull(c, true);
			}
		}

	}
}