using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Text;

namespace Host.Security
{
	/// <summary>
	/// Classe da utilizzare per il download della CRL
	/// </summary>
	public class CryptCRL
	{
		/// <summary>
		/// tipo di download della CRL: dalla cache, dalla rete, da entrambi
		/// </summary>
		public enum CrlDownloadType
		{
			CacheCrlDownloadOnly,
			NetworkCrlDownloadOnly,
			CacheOrNetworkCrlDownload
		};

		/// <summary>
		/// Codice che indica il motivo per cui un certificato e` nella CRL
		/// </summary>
		public enum CrlReasonCode
		{
			unspecified = 0,
			keyCompromise = 1,
			cACompromise = 2,
			affiliationChanged = 3,
			superseded = 4,
			cessationOfOperation = 5,
			certificateHold = 6,
			removeFromCRL = 8
		};

		/// <summary>
		/// Singola entry nella CRL
		/// </summary>
		public class CRLEntry
		{
			public byte[] SerialNumber { get { return serialNumber; } }
			public DateTime RevocationDate { get { return revocationDate; } }
			public CrlReasonCode Reason { get { return reason; } }

			#region Implementation

			private byte[] serialNumber;
			private CrlReasonCode reason;
			private DateTime revocationDate;

			internal byte[] _SerialNumber { set { serialNumber = value; } }
			internal DateTime _RevocationDate { set { revocationDate = value; } }
			internal CrlReasonCode _Reason { set { reason = value; } }
			#endregion
		}

		/// <summary>
		///   Costruttore di default (non genera eccezioni)
		/// </summary>
		public CryptCRL()
		{
			SetDefault();
		}

		/// <summary>
		/// si connette al <paramref name="urlDistPoint"/> e download la CRL
		/// </summary>
		/// <param name="urlDistPoint">punto di ditribuzione</param>
		/// <param name="cDownload">tipo di downlaod</param>
		/// <param name="secTmo">timeout di connessione in secondi</param>
		public CryptCRL(string urlDistPoint, CrlDownloadType cDownload, int secTmo)
		{
			Connect(urlDistPoint, cDownload, secTmo);
		}

		/// <summary>
		/// Si connette al punto di distribuzione e downloada la CRL
		/// </summary>
		/// <param name="urlDistPoint"></param>
		/// <param name="cDownload">tipo di download</param>
		/// <param name="secTmo">secondi di timeout per la connessione</param>
		public void Connect(string urlDistPoint, CrlDownloadType cDownload, int secTmo)
		{
			SetDefault();
			uint dwFlags = 0;
			IntPtr pCRLContext;

			unsafe
			{
				void* q;
				IntPtr hp = new IntPtr(&q);
				bool bRes = false;
				int timeout = 0;

				switch (cDownload)
				{
					case CrlDownloadType.CacheCrlDownloadOnly:
						dwFlags = WinCapi.CRYPT_CACHE_ONLY_RETRIEVAL;
						break;
					case CrlDownloadType.NetworkCrlDownloadOnly:
						dwFlags = WinCapi.CRYPT_WIRE_ONLY_RETRIEVAL;
						timeout = 1000 * secTmo;
						break;
					case CrlDownloadType.CacheOrNetworkCrlDownload:
						// prova prima a downloadare CRL con Cache: se non esiste
						dwFlags = WinCapi.CRYPT_CACHE_ONLY_RETRIEVAL;
						timeout = 1000 * secTmo;
						break;
				}
				bRes = WinCapi.CryptRetrieveObjectByUrlW(urlDistPoint, WinCapi.CONTEXT_OID_CRL,
																		dwFlags,
																		(uint)timeout, hp,
																		IntPtr.Zero,
																		IntPtr.Zero,
																		IntPtr.Zero,
																		IntPtr.Zero);
				if (bRes == false)
				{
					//
					// Download non OK su Cached CRL ... prova con Network
					//
					if (cDownload == CrlDownloadType.CacheOrNetworkCrlDownload)
					{
						dwFlags = WinCapi.CRYPT_WIRE_ONLY_RETRIEVAL;
						bRes = WinCapi.CryptRetrieveObjectByUrlW(urlDistPoint, WinCapi.CONTEXT_OID_CRL,
							dwFlags,
							(uint)timeout, hp,
							IntPtr.Zero,
							IntPtr.Zero,
							IntPtr.Zero,
							IntPtr.Zero);
					}
				}
				else
				{
					//
					// Download OK su Cached CRL ... nel caso  controlla che non sia scaduta 
					// altrimenti prova il download da rete
					//
					if (cDownload == CrlDownloadType.CacheOrNetworkCrlDownload)
					{
						IntPtr crlContext = new IntPtr(q);
						DateTime currentCRLTime;
						DateTime nextCRLTime;
						InnerGetCRLDataTimeOnly(crlContext, out currentCRLTime, out nextCRLTime);
						DateTime localTime = DateTime.Now;

						if ((localTime < currentCRLTime) || (localTime > nextCRLTime))
						{

							//
							// rilascia la vecchia CRL che e' scaduta 
							//
							bRes = WinCapi.CertFreeCRLContext(crlContext);
							if (bRes == false)
								throw new CertException("CertFreeCRLContext");

							//
							//	Cached CRL scaduta: download CRL da rete
							//
							dwFlags = WinCapi.CRYPT_WIRE_ONLY_RETRIEVAL;
							bRes = WinCapi.CryptRetrieveObjectByUrlW(urlDistPoint, WinCapi.CONTEXT_OID_CRL,
								dwFlags,
								(uint)timeout, hp,
								IntPtr.Zero,
								IntPtr.Zero,
								IntPtr.Zero,
								IntPtr.Zero);

						}
					}
				}

				if (bRes == false)
					throw new CertException("CryptRetrieveObjectByUrlW failure for URL:" + urlDistPoint);

				pCRLContext = new IntPtr(q);

				if (pCRLContext == IntPtr.Zero)
					throw new CertException("CryptRetrieveObjectByUrlW failure: invalid pointer");

				//
				// Carica i dati su variabili membro in modo da poter liberare in modo sicuro
				// il pointer 
				//
				try
				{
					BuildFromContext(pCRLContext);
				}
				catch (CertException cEx)
				{
					SetDefault();
					Close(ref pCRLContext);
					throw cEx;
				}
				catch (Exception nEx)
				{
					SetDefault();
					Close(ref pCRLContext);
					throw nEx;
				}
				Close(ref pCRLContext);
			}
		}


		/// <summary>
		///    GetCRLIssuerName: ottiene l'issuer di una CRL (estraendolo dai dati della CRL)
		///    in formato X.500 (CN= .... OU= ...) comma separated
		/// </summary>
		/// <returns></returns>
		public string GetCRLIssuerName()
		{
			return _crlIssuer;
		}

		/// <summary>
		/// ritorna la data di inizio e fine validita`
		/// </summary>
		/// <param name="thisUpdate">inizio validita`</param>
		/// <param name="_nextUpdate">fine validita`</param>
		public void GetCRLDataTimeOnly(out DateTime thisUpdate, out DateTime nextUpdate)
		{
			thisUpdate = _thisUpdate;
			nextUpdate = _nextUpdate;
		}

		public byte[] EncodeCRLContext()
		{
			return _crlRawData;
		}

		/// <summary>
		/// ritorna la data di inizio e fine validita` e la lista delle entry della CRL
		/// </summary>
		/// <param name="thisUpdate">inizio validita`</param>
		/// <param name="nextUpdate">fine validita`</param>
		/// <param name="crlEntries">CRL in uscita</param>
		public void GetAllCRLData(out DateTime thisUpdate, out DateTime nextUpdate, out CRLEntry[] crlEntries)
		{
			thisUpdate = _thisUpdate;
			nextUpdate = _nextUpdate;
			crlEntries = _crlList;
		}

		/// <summary>
		/// Data in cui e` stata prodotta la CRL
		/// </summary>
		/// <value></value>
		public DateTime ThisUpdate { get { return _thisUpdate; } }

		/// <summary>
		/// Data di scadenza della CRL
		/// </summary>
		/// <value></value>
		public DateTime NextUpdate { get { return _nextUpdate; } }

		/// <summary>
		/// Lista delle entry della CRL
		/// </summary>
		/// <value></value>
		public CRLEntry[] CRL { get { return _crlList; } }



		#region Implementation
		private CRLEntry[] _crlList;
		private string _crlIssuer;
		private DateTime _thisUpdate;
		private DateTime _nextUpdate;
		private byte[] _crlRawData;
		internal void SetDefault()
		{
			_crlList = null;
			_crlIssuer = string.Empty;
			_thisUpdate = DateTime.MinValue;
			_nextUpdate = DateTime.MinValue;
			_crlRawData = null;
		}



		/// <summary>
		///		CryptCRL(): costruttore che utilizza un byte array
		///     con il content della CRL (utilizza una funzione simile a
		///     CertCreateCertificateContext per il certificato)
		/// </summary>
		/// <param name="crlData"></param>
		internal CryptCRL(byte[] crlData)
		{
			IntPtr pCRLContext;
			SetDefault();
			pCRLContext = WinCapi.CertCreateCRLContext(
				WinCapi.X509_ASN_ENCODING,
				crlData,
				(uint)crlData.Length);

			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CertCreateCRLContext: cannot create from bytearray");

			try
			{
				BuildFromContext(pCRLContext);
			}
			catch (CertException cEx)
			{
				SetDefault();
				Close(ref pCRLContext);
				throw cEx;
			}
			catch (Exception nEx)
			{
				SetDefault();
				Close(ref pCRLContext);
				throw nEx;
			}
			Close(ref pCRLContext);
		}



		/// <summary>
		///   BuildFromContext: carica CRL a partire dal contesto
		/// </summary>
		/// <param name="pCRLContext"></param>
		internal void BuildFromContext(IntPtr pCRLContext)
		{
			loadAllCRLData(pCRLContext, true, out _thisUpdate, out _nextUpdate, out _crlList);
			_crlIssuer = loadCRLIssuerName(pCRLContext);
			_crlRawData = EncodeCRLContext(pCRLContext);
		}



		private static void InnerGetCRLDataTimeOnly(IntPtr crlContext, out DateTime currentTime, out DateTime nextTime)
		{
			if (crlContext == IntPtr.Zero)
				throw new CertException("CryptCRL.InnerGetCRLDataTimeOnly called with a closed CRL Context");

			WinCapi.CRL_CONTEXT Crl = new WinCapi.CRL_CONTEXT();
			Crl = (WinCapi.CRL_CONTEXT)Marshal.PtrToStructure(crlContext, typeof(WinCapi.CRL_CONTEXT));

			IntPtr CRLINFO = Crl.pCrlInfo;
			WinCapi.CRL_INFO CrlInfo = new WinCapi.CRL_INFO();
			CrlInfo = (WinCapi.CRL_INFO)Marshal.PtrToStructure(CRLINFO, typeof(WinCapi.CRL_INFO));

			currentTime = DateTime.FromFileTime(CrlInfo.ThisUpdate);
			nextTime = DateTime.FromFileTime(CrlInfo.NextUpdate);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		internal byte[] EncodeCRLContext(IntPtr pCRLContext)
		{

			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CryptCRL.EncodeCRLContext called with a closed CRL Context");

			unsafe
			{

				WinCapi.CRL_CONTEXT Crl = new WinCapi.CRL_CONTEXT();
				Crl = (WinCapi.CRL_CONTEXT)Marshal.PtrToStructure(pCRLContext, typeof(WinCapi.CRL_CONTEXT));

				uint cbEncoded = 0;
				bool bRes = WinCapi.CryptEncodeObject(WinCapi.X509_ASN_ENCODING,
					WinCapi.X509_CERT_CRL_TO_BE_SIGNED,
					Crl.pCrlInfo,
					IntPtr.Zero,
					ref cbEncoded
					);

				byte[] cbContent = new byte[Crl.cbCrlEncoded];
				GCHandle hh = GCHandle.Alloc(cbContent, GCHandleType.Pinned);
				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(cbContent, 0);

				bRes = WinCapi.CryptEncodeObject(WinCapi.X509_ASN_ENCODING,
					WinCapi.X509_CERT_CRL_TO_BE_SIGNED,
					Crl.pCrlInfo,
					ptOutBuffer,
					ref cbEncoded
					);
				hh.Free();
				if (bRes == false)
				{
					throw new CertException("CryptCRL.EncodeCRLContext error getting bytearray");
				}
				if (cbEncoded != cbContent.Length)
				{
					byte[] rb = new byte[cbEncoded];
					for (int i = 0; i < cbEncoded; ++i)
						rb[i] = cbContent[i];
					cbContent = rb;
				}
				return cbContent;
			}
		}

		/// <summary>
		///		VerifyCRLSignature: controlla che la firma della CRL scaricata sia corretta in base
		///			al certificato dell'issuer il cui context e' fornito in input (DA VERIFICARE) 
		///			non e' detto che il certificato dell'issuer della CRL sia su uno degli store della
		///			macchina su cui gira ... potrebbe essere su file o byte array  
		/// </summary>
		/// <returns></returns>
		internal bool VerifyCRLSignature(IntPtr pCertContext)
		{
			IntPtr pCRLContext;
			if ((_crlRawData == null) || (_crlRawData.Length == 0))
				throw new CertException("CryptCRL.VerifyCRLSignature called with a CRL not loaded");

			pCRLContext = WinCapi.CertCreateCRLContext(
				WinCapi.X509_ASN_ENCODING,
				_crlRawData,
				(uint)_crlRawData.Length);

			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CryptCRL.VerifyCRLSignature called with a null CRL Context");

			bool bRes = WinCapi.CryptVerifyCertificateSignatureEx(
									IntPtr.Zero,
									WinCapi.X509_ASN_ENCODING,
									WinCapi.CRYPT_VERIFY_CERT_SIGN_SUBJECT_CRL,
									pCRLContext,
									WinCapi.CRYPT_VERIFY_CERT_SIGN_ISSUER_CERT,  // CRYPT_VERIFY_CERT_SIGN_ISSUER_CERT se certificato
				pCertContext,								 // pCertContext	
				0,
									IntPtr.Zero);

			Close(ref pCRLContext);
			return bRes;
		}



		internal static string loadCRLIssuerName(IntPtr pCRLContext)
		{
			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CryptCRL.GetCRLIssuerName called with a closed CRL Context");

			unsafe
			{
				void* pCRL = pCRLContext.ToPointer();
				WinCapi.CRL_CONTEXT* pCrl = (WinCapi.CRL_CONTEXT*)pCRL;


				IntPtr CRLINFO = pCrl->pCrlInfo;
				WinCapi.CRL_INFO CrlInfo = new WinCapi.CRL_INFO();
				CrlInfo = (WinCapi.CRL_INFO)Marshal.PtrToStructure(CRLINFO, typeof(WinCapi.CRL_INFO));

				uint cbSize;
				string issuer;
				void* pIssuerBlob = &CrlInfo.Issuer;

				IntPtr pIntIssuer = new IntPtr(pIssuerBlob);

				//
				// ritorna size dell'issuer in formato X.500
				//
				cbSize = WinCapi.CertNameToStrA(WinCapi.MY_ENCODING_TYPE,
							pIntIssuer,
							WinCapi.CERT_X500_NAME_STR,
							IntPtr.Zero,
							0);

				byte[] Issuer = new byte[cbSize];
				GCHandle hh = GCHandle.Alloc(Issuer, GCHandleType.Pinned);
				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(Issuer, 0);

				for (int i = 0; i < cbSize; i++)
					Issuer[i] = 0;
				//
				// ottiene issuer in formato X.500
				//
				cbSize = WinCapi.CertNameToStrA(WinCapi.MY_ENCODING_TYPE,
							pIntIssuer,
							WinCapi.CERT_X500_NAME_STR,
							ptOutBuffer,
							cbSize);
				hh.Free();
				issuer = Encoding.ASCII.GetString(Issuer, 0, (int)cbSize);
				return issuer;
			}
		}

		internal static void loadAllCRLData(IntPtr pCRLContext, bool bGetCRLExtension, out DateTime thisUpdate, out DateTime nextUpdate, out CRLEntry[] crlEntries)
		{
			crlEntries = null;
			thisUpdate = new DateTime();
			nextUpdate = new DateTime();

			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CryptCRL.GetCRLData called with a closed CRL Context");

			unsafe
			{
				void* pCRL = pCRLContext.ToPointer();
				WinCapi.CRL_CONTEXT* pCrl = (WinCapi.CRL_CONTEXT*)pCRL;


				IntPtr CRLINFO = pCrl->pCrlInfo;
				WinCapi.CRL_INFO CrlInfo = new WinCapi.CRL_INFO();
				CrlInfo = (WinCapi.CRL_INFO)Marshal.PtrToStructure(CRLINFO, typeof(WinCapi.CRL_INFO));


				thisUpdate = DateTime.FromFileTime(CrlInfo.ThisUpdate);
				nextUpdate = DateTime.FromFileTime(CrlInfo.NextUpdate);

				uint nCRLEntries = CrlInfo.cCRLEntry;
				crlEntries = new CRLEntry[nCRLEntries];

				//
				// Per la scansione dell'array di strutture ...
				//
				for (int i = 0; i < nCRLEntries; i++)
				{
					void* currArrPtr = (void*)((int)(CrlInfo.rgCRLEntry).ToPointer() + i * sizeof(WinCapi.CRL_ENTRY));
					WinCapi.CRL_ENTRY CrlEntry = new WinCapi.CRL_ENTRY();
					CrlEntry = (WinCapi.CRL_ENTRY)Marshal.PtrToStructure(new IntPtr(currArrPtr), typeof(WinCapi.CRL_ENTRY));

					crlEntries[i] = new CRLEntry();
					crlEntries[i]._RevocationDate = DateTime.FromFileTime(CrlEntry.RevocationDate);

					//
					// scansione dei serial number ... forse c'e' un modo migliore per farlo
					//
					crlEntries[i]._SerialNumber = new byte[CrlEntry.SerialNumber.cbData];
					for (int j = 0; j < CrlEntry.SerialNumber.cbData; j++)
					{
						void* currArrSerNumPtr = (void*)((int)(CrlEntry.SerialNumber.pbData).ToPointer() + j * sizeof(byte));
						crlEntries[i].SerialNumber[j] = Marshal.ReadByte(new IntPtr(currArrSerNumPtr));
					}

					//
					// questo da' un carico ulteriore al parse della CRL: magari si puo' evitare 
					// visto che da quello che si vede tutti i certificati scaricati da TrustItalia
					// e molti di quelli GRTN/Actalis non hanno Extension (cioe' CrlEntry.cExtension = 0)
					//
					if (bGetCRLExtension)
					{
						if (CrlEntry.cExtension > 0)
						{
							for (int l = 0; l < CrlEntry.cExtension; l++)
							{
								void* currArrExt = (void*)((int)(CrlEntry.rgExtension).ToPointer() + l * sizeof(WinCapi.CERT_EXTENSION));
								WinCapi.CERT_EXTENSION CertExt = new WinCapi.CERT_EXTENSION();
								CertExt = (WinCapi.CERT_EXTENSION)Marshal.PtrToStructure(new IntPtr(currArrExt), typeof(WinCapi.CERT_EXTENSION));
								string szObjId = Marshal.PtrToStringAnsi(CertExt.pszObjId);

								if (szObjId == WinCapi.szOID_CRL_REASON_CODE)
								{
									int reason;
									uint cbBytes = 4;
									bool res = WinCapi.CryptDecodeObject(WinCapi.MY_ENCODING_TYPE,
										szObjId,
										CertExt.Value.pbData,
										CertExt.Value.cbData,
										0,
										out reason,
										ref cbBytes);

									if (res == false)
										throw new CertException("CryptCRL.GetCRLData cannot decode CRL extension");

									if (Enum.IsDefined(typeof(CrlReasonCode), reason))
										crlEntries[i]._Reason = (CrlReasonCode)reason;
									else
										crlEntries[i]._Reason = CrlReasonCode.unspecified;
									break;
								}
							}
						}
						else
						{
							crlEntries[i]._Reason = CrlReasonCode.unspecified;
						}
					}
					else
						crlEntries[i]._Reason = CrlReasonCode.unspecified;
				}
			}
		}

		internal static void Close(ref IntPtr pCRLContext)
		{
			bool r;
			if (pCRLContext != IntPtr.Zero)
			{
				r = WinCapi.CertFreeCRLContext(pCRLContext);
				if (r == false)
					throw new CertException("CertFreeCRLContext");
				pCRLContext = IntPtr.Zero;
			}
		}
		#endregion
	}
}
