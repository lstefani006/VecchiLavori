using System;
using System.Web.Services.Protocols;
using System.Web;
using System.Configuration;
using System.Collections.Specialized;
using System.Security.Cryptography.X509Certificates;

namespace Host.Web.ServerSecurity
{
	/// <summary>
	/// interfaccia da derivare in una classe per ottenere una strategia
	/// di authenticazione custom
	/// </summary>
	public interface IAuthenticate
	{
		void CheckClientCertificate(System.Web.HttpRequest request);
		void CheckUserPassword(WSAuthHeader authHeader);
	}

	/// <summary>
	/// Eccezione lanciata quando l'autenticazione fallisce
	/// </summary>
	public class AuthenticationException : ApplicationException
	{
		public AuthenticationException(string msg) : base(msg) {}
	}


	/// <summary>
	/// Summary description for WSServerCheckAuth.
	/// </summary>
	public class WSServerCheckAuth
	{
		/// <summary>
		///	CheckAuth: se il certificato e' presente controlla l'autenticazione su certificato
		///	altrimenti controlla username e password.
		/// Da chiamare come prima funzione di ogni metodo esposto dal WebService.
		/// <code>Host.Web.ServerSecurity.WSServerCheckAuth.CheckAuth(Context.Request, authHeader);</code>
		/// </summary>
		/// <param name="request"></param>
		/// <param name="authHeader"></param>
		public static void CheckAuth(System.Web.HttpRequest request, WSAuthHeader authHeader)
		{
			if (request.ClientCertificate.IsPresent)
				_IAuthenticate.CheckClientCertificate(request);
			else
				_IAuthenticate.CheckUserPassword(authHeader);
		}

		/// <summary>
		/// property che consente di impostare una strategia custom per l'autenticazione
		/// sia con login/password che con i certificati digitali lato cliente.
		/// </summary>
		/// <value></value>
		public static IAuthenticate Authenticate
		{
			get { return _IAuthenticate; }
			set { _IAuthenticate = value; }
		}

		#region Implementation
		static private IAuthenticate _IAuthenticate = new AppConfigAuthenticate();

		internal class AppConfigAuthenticate : IAuthenticate
		{
			void IAuthenticate.CheckClientCertificate(System.Web.HttpRequest request)
			{
				WSServerCheckCertificate.CheckClientCertificate(request);
			}

			void IAuthenticate.CheckUserPassword(WSAuthHeader authHeader)
			{
				WSServerCheckUserPassword.CheckUserPassword(authHeader);
			}
		}

		#endregion
	}
}
