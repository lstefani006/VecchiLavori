using System;
using System.Web.Services.Protocols;
using System.Configuration;
using System.Collections.Specialized;

using Host.Security;

namespace Host.Web
{
	/// <summary>
	/// Classe da inserire nel soap header dei web service
	/// per consentire l'autenticazione con login/password
	/// </summary>
	public class WSAuthHeader : SoapHeader
	{
		public string Username;
		public string Password;
	}
}

namespace Host.Web.ClientSecurity
{
	/// <summary>
	/// Classe da utilizzare lato cliente di un WebService
	/// </summary>
	public class WSClient
	{
		public delegate void TraceDelegate(string msg);

		/// <summary>
		/// Funzione da chiamare nel Main dell'applicazione cliente dei WebServices.
		/// Predispone il cliente in modo da consentirgli di operare con WS che hanno
		/// problemi nel loro certificato SSL.
		/// Inoltre permette di agganciare un delegate per effettuare i trace
		/// degli eventuali problemi riscontrati dal a causa del certifcato SSL del server.
		/// </summary>
		/// <param name="traceDelegate">funzione che riceve il trace degli eventi</param>
		public static void SetCertificatePolicy(TraceDelegate traceDelegate)
		{
			s_traceDelegate = traceDelegate;
			System.Net.ServicePointManager.CertificatePolicy = new TrustAllCertificatePolicy();
		}

		#region Implementation


		public static void Setup(SoapHttpClientProtocol ws, ref string username, ref string password, string configName, NameValueCollection nvc)
		{
			string Url = nvc[configName + "_Url"];
			string WSServer = nvc[configName + "_WSServer"];
			if (WSServer == null)
				WSServer = configName;

			//ws.Credentials=System.Net.CredentialCache.DefaultCredentials;			

			string ProxyUser = nvc[WSServer + "_ProxyUser"];
			string ProxyPwd = nvc[WSServer + "_ProxyPwd"];
			string ProxyDomain = nvc[WSServer + "_ProxyDomain"];
			string CertProblems = nvc[WSServer + "_CertProblems"];
			string CertIssuer = nvc[WSServer + "_Certificate_Issuer"];
			string CertSN = nvc[WSServer + "_Certificate_SN"];
			string CertPIN = nvc[WSServer + "_Certificate_PIN"];
			string CertLocation = nvc[WSServer + "_Certificate_Location"];
			string CertUseMachineKeySet = nvc[WSServer + "_Certificate_MachineKeySet"];
			string UserName = nvc[WSServer + "_UserName"];
			string Password = nvc[WSServer + "_Password"];

			bool bUseMachineKeySet = false;
			if (CertUseMachineKeySet != null && CertUseMachineKeySet != string.Empty)
			{
				CertUseMachineKeySet = CertUseMachineKeySet.ToLower();
				if (CertUseMachineKeySet == "1" ||
					CertUseMachineKeySet == "si" ||
					CertUseMachineKeySet == "yes" ||
					CertUseMachineKeySet == "true")
					bUseMachineKeySet = true;
			}

			if (ProxyDomain == null || ProxyDomain == String.Empty)
				ProxyDomain = null;
			if (ProxyUser == null || ProxyUser == String.Empty)
				ProxyUser = null;

			if (ProxyUser != null && ProxyDomain != null)
				ws.Credentials = new System.Net.NetworkCredential(ProxyUser, ProxyPwd, ProxyDomain);

			if (Url == null)
				TraceCertificateProblems(string.Format("Voce di configurazione '{0}' mancante", WSServer + "_Url"));

			SetClientCertificate(ws, CertIssuer, CertSN, CertPIN, CertLocation, bUseMachineKeySet);

			ws.Url = Url;
			username = UserName;
			password = Password;

			if (CertProblems != null)
			{
				lock (s_CertificateProblems)
				{
					if (s_CertificateProblems.ContainsKey(Url) == false)
						s_CertificateProblems.Add(Url, CertProblems);
				}
			}
		}



		const string CurrentUserLocation = "CurrentUser";
		const string LocalMachineLocation = "LocalMachine";

		internal static void SetClientCertificate(SoapHttpClientProtocol ws,
			string CertIssuer, string CertSN, string CertPIN,
			string CertLocation, bool bUseMachineKeySet)
		{
			bool bStoreFound = true;
			bool bCertificateFound = false;
			CertX509Ex cert = null;

			//
			// Controlla preventivamente se Issuer/SN sono nulli
			//
			if (CertIssuer == null || CertSN == null)
				return;
			//
			// Controlla preventivamente se Issuer/SN sono stringhe vuote
			//
			if (CertIssuer == string.Empty || CertSN == string.Empty)
				return;

			try
			{
				//
				// cerca il certificato nello store CurrentUser o LocalMachine che
				// fa match con Issuer/SerialNumber
				//
				using (CertStore cs = new CertStore())
				{
					if (CertLocation == CurrentUserLocation)
						cs.OpenUserStore();
					else if (CertLocation == LocalMachineLocation)
						cs.OpenLocalMachineStore();
					else
						bStoreFound = false;

					if (bStoreFound)
					{
						int nCertificatesInStore = cs.CountCertificatesInStore;
						for (int index = 0; index < nCertificatesInStore; index++)
						{
							cert = cs.CertGetCertificateInStoreByIndex(index);
							if (cert != null)
							{
								if (cert.GetIssuerName() == CertIssuer &&
									cert.GetSerialNumberString() == CertSN)
								{
									bCertificateFound = true;
									break;
								}
							}
						}
					}
				}

				//
				// Certificato trovato: setta PIN eventuale e aggiungi certificato 
				// al set di client certificates per l'accesso al WebService
				//
				if (bCertificateFound)
				{
					cert.SetPin(CertPIN, bUseMachineKeySet);
					ws.ClientCertificates.Add(cert);
				}
			}
			catch (CertException cExc)
			{
				TraceCertificateProblems(string.Format("Errore su certificat settando client certificate; Msg = {0} Win32Error = {1:X} Win32Msg={2}", cExc.Message, cExc.Win32Error, cExc.Win32Msg));
			}
			catch (Exception exc)
			{
				TraceCertificateProblems(string.Format("Errore generico settando client certificate; Msg = {0}", exc.Message));
			}
		}



		private static StringDictionary s_CertificateProblems = new StringDictionary();
		private static TraceDelegate s_traceDelegate;

		internal static string GetAllowedCertificateProblems(string Url)
		{
			lock (s_CertificateProblems)
			{
				if (s_CertificateProblems.ContainsKey(Url) == false)
					return null;
				else
					return s_CertificateProblems[Url];
			}
		}

		internal static void TraceCertificateProblems(string s)
		{
			try
			{
				if (s_traceDelegate != null)
					s_traceDelegate(s);
			}
			catch
			{
			}
		}

		#endregion

	}


	public enum CertificateProblem : long
	{
		CertEXPIRED = 0x800B0101,
		CertVALIDITYPERIODNESTING = 0x800B0102,
		CertROLE = 0x800B0103,
		CertPATHLENCONST = 0x800B0104,
		CertCRITICAL = 0x800B0105,
		CertPURPOSE = 0x800B0106,
		CertISSUERCHAINING = 0x800B0107,
		CertMALFORMED = 0x800B0108,
		CertUNTRUSTEDROOT = 0x800B0109,
		CertCHAINING = 0x800B010A,
		CertREVOKED = 0x800B010C,
		CertUNTRUSTEDTESTROOT = 0x800B010D,
		CertREVOCATION_FAILURE = 0x800B010E,
		CertCN_NO_MATCH = 0x800B010F,
		CertWRONG_USAGE = 0x800B0110,
		CertUNTRUSTEDCA = 0x800B0112,
	}

	class TrustAllCertificatePolicy : System.Net.ICertificatePolicy
	{
		bool System.Net.ICertificatePolicy.CheckValidationResult(System.Net.ServicePoint srvPoint, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Net.WebRequest request, int certificateProblem)
		{
			string cps = null;

			//
			// La classe intercetta anche l'errore con nessun problema sul certificato
			//
			if (certificateProblem == 0)
			{
				return true;
			}

			if (Enum.IsDefined(typeof(CertificateProblem), (long)(uint)certificateProblem))
			{
				CertificateProblem cp = (CertificateProblem)(long)(uint)certificateProblem;
				cps = cp.ToString();
			}

			string cpa = WSClient.GetAllowedCertificateProblems(request.RequestUri.AbsoluteUri);
			if (cpa == null)
				return false;

			char[] cc = new char[2];
			cc[0] = ',';
			cc[1] = ' ';

			foreach (string s in cpa.Split(cc))
			{
				if (cps != null && cps == s)
					return true;
				if (s == "*")
					return true;
				if (s.ToUpper() == ((uint)certificateProblem).ToString("X"))
					return true;
			}

			if (cps == null)
				WSClient.TraceCertificateProblems(string.Format("ERRORE: il server remoto ha un 'certificateProblem' = {0:X}", (uint)certificateProblem));
			else
				WSClient.TraceCertificateProblems(string.Format("ERRORE: il server remoto ha un 'certificateProblem' = {0:X}: {1}", (uint)certificateProblem, cps));
			return false;
		}

	}


}
