using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Text;
using System.ComponentModel;

namespace Host.Security
{
	public class CertException : Exception
	{
		public CertException(string msg) 
			: base(msg)
		{
			_Win32Error = Marshal.GetLastWin32Error();
			_Win32Ex = new Win32Exception(_Win32Error);
		}
		public CertException(string msg, int dwError)
			: base(msg)
		{
			_Win32Error = dwError;
			_Win32Ex = new Win32Exception(dwError);
		}

		public int Win32Error { get { return _Win32Error; } }
		public string Win32Msg { get { return _Win32Ex.Message; } }
		public Win32Exception Win32Ex { get { return _Win32Ex; } }

		readonly private int _Win32Error;
		readonly private Win32Exception _Win32Ex;
	}


	/// <summary>
	/// Classe che estende la X509Certificate del framework
	/// </summary>
	public class CertX509Ex : X509Certificate
	{
		/// <summary>
		/// CreateFromCertFile(): copertura dell'analogo metodo di X509Certificate
		/// </summary>
		/// <param name="filename">file in cui e` descritto il certificato</param>
		/// <returns></returns>
		public static new CertX509Ex CreateFromCertFile(string filename)
		{
			CertX509Ex xcEx = null;
			X509Certificate xc = X509Certificate.CreateFromCertFile(filename);
			if (xc != null)
			{
				byte[] rawCertData = xc.GetRawCertData();
				xcEx = new CertX509Ex(rawCertData);
			}
			return xcEx;
		}

		/// <summary>
		///		CreateFromSignedFile: copertura dell'analogo metodo di X509Certificate
		/// </summary>
		/// <param name="filename"></param>
		/// <returns></returns>
		public static new CertX509Ex CreateFromSignedFile(string filename)
		{
			CertX509Ex xcEx = null;
			X509Certificate xc = X509Certificate.CreateFromSignedFile(filename);
			if (xc != null)
			{
				byte[] rawCertData = xc.GetRawCertData();
				xcEx = new CertX509Ex(rawCertData);
			}
			return xcEx;
		}

		public string ContainerName { get { return _szContainerName; } }

		/// <summary>
		/// Supporto fisico del token
		/// </summary>
		public string ProviderName { get { return _szProvName; } }

		/// <summary>
		/// Data di scadenza del certificato
		/// </summary>
		public DateTime ExpirationDate { get { return DateTime.FromFileTime((long)_expirationDate); } }
		public DateTime EffectiveDate { get { return DateTime.FromFileTime((long)_effectiveDate); } }

		/// <summary>
		/// Ritorna true se il certificato specifica una KeyUsage
		/// </summary>
		public bool IsKeyUsageSupported { get { return _keyUsageSupported; } }

		/// <summary>
		/// Ritorna true se il certificato supporta il non ripudio
		/// (firma e controfirma digitale di documenti)
		/// </summary>
		public bool IsNonRepudiationCertificate
		{
			get
			{
				// dopo vari contrasti si e` sancito 
				// che se il certificato non supporta il KeyUsage
				// allora il certificato e` di non ripudio
				//Debug.Assert(_keyUsageSupported);
				if (!_keyUsageSupported)
					return true;

				return (_keyUsage & WinCapi.CERT_NON_REPUDIATION_KEY_USAGE) != 0;
			}
		}

		/// <summary>
		/// Ritorna true se il certificato supporta la CERT_DIGITAL_SIGNATURE_KEY_USAGE
		/// (autenticazione)
		/// </summary>
		public bool IsDigitaleSignatureCertificate
		{
			get
			{
				if (!_keyUsageSupported)
					return true;
				return (_keyUsage & WinCapi.CERT_DIGITAL_SIGNATURE_KEY_USAGE) != 0;
			}
		}

		/// <summary>
		/// lista dei punti di distribuzione del certificato
		/// </summary>
		public string[] DistributionPointList { get { return _distributionPointList; } }

		/// <summary>
		/// funzione per settare il pin del certificato
		/// </summary>
		public void SetPin(string pin, bool bUseMachineKeySet)
		{
			SetPin(pin, ProviderName, bUseMachineKeySet);
		}
		/// <summary>
		/// funzione per settare il pin del certificato
		/// </summary>
		public void SetPin(string pin, string sProviderName, bool bUseMachineKeySet)
		{
			string ProviderName;
			if (sProviderName != null)
				ProviderName = sProviderName;
			else
				ProviderName = _szProvName;

			unsafe
			{
				int r;

				void* q;
				IntPtr hp = new IntPtr(&q);

				uint dwFlag;
				if (bUseMachineKeySet)
				{
					dwFlag = WinCapi.CRYPT_MACHINE_KEYSET;
				}
				else
				{
					dwFlag = 0;
				}
				r = WinCapi.CryptAcquireContext(hp, _szContainerName, ProviderName, WinCapi.PROV_RSA_FULL, dwFlag);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					throw new CertException("CryptAcquireContext failure", dwError);
				}
				IntPtr hCryptProv = new IntPtr(q);


				void* ptCryptKey;
				IntPtr hCryptKeyPtr = new IntPtr(&ptCryptKey);
				r = WinCapi.CryptGetUserKey(hCryptProv, WinCapi.AT_SIGNATURE, hCryptKeyPtr);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CryptReleaseContext(hCryptProv, 0);
					throw new CertException("CryptGetUserKey failure", dwError);
				}
				IntPtr hCryptKey = new IntPtr(ptCryptKey);

				// converto il pin in caratteri ascii ed eseguo setPin se il pin non e' vuoto
				if (pin != null)
				{
					if (pin.Length > 0)
					{
						byte[] pinToSet = new byte[pin.Length + 1];
						for (int i = 0; i < pin.Length; ++i)
							pinToSet[i] = (byte)pin[i];
						pinToSet[pin.Length] = 0;
						r = WinCapi.CryptSetProvParam(hCryptProv, WinCapi.PP_SIGNATURE_PIN, pinToSet, 0);
						if (r == 0)
						{
							int dwError = Marshal.GetLastWin32Error();
							WinCapi.CryptDestroyKey(hCryptKey);
							WinCapi.CryptReleaseContext(hCryptProv, 0);
							throw new CertException("CryptSetProvParam failure", dwError);
						}
					}
				}

				r = WinCapi.CryptDestroyKey(hCryptKey);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CryptReleaseContext(hCryptProv, 0);
					throw new CertException("CryptDestroyKey failure", dwError);
				}

				r = WinCapi.CryptReleaseContext(hCryptProv, 0);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					throw new CertException("CryptReleaseContext failure", dwError);
				}
			}
		}


		/// <summary>
		/// firma digitale di un documento
		/// </summary>
		/// <param name="inBuffer">documento in ingresso</param>
		/// <returns>documento firmato</returns>
		public byte[] Sign(byte[] inBuffer)
		{
			IntPtr pCertContext = WinCapi.CertCreateCertificateContext(WinCapi.MY_ENCODING_TYPE, _rawCertData, (uint)_rawCertData.Length);
			if (pCertContext == IntPtr.Zero)
				throw new CertException("CertCreateCertificateContext");

			unsafe
			{
				WinCapi.CRYPT_SIGN_MESSAGE_PARA SignMessagePara = new WinCapi.CRYPT_SIGN_MESSAGE_PARA();

				void* ww = pCertContext.ToPointer();
				SignMessagePara.cbSize = 68; // sizeof(WinCapi.CRYPT_SIGN_MESSAGE_PARA);
				SignMessagePara.HashAlgorithm.pszObjId = WinCapi.szOID_OIWSEC_sha1;
				SignMessagePara.pSigningCert = pCertContext;
				SignMessagePara.dwMsgEncodingType = WinCapi.MY_ENCODING_TYPE;
				SignMessagePara.cMsgCert = 1;
				SignMessagePara.rgpMsgCert = new IntPtr(&ww); // &pSignerCert;


				GCHandle hv = GCHandle.Alloc(inBuffer, GCHandleType.Pinned);
				void* v = Marshal.UnsafeAddrOfPinnedArrayElement(inBuffer, 0).ToPointer();
				IntPtr rgpbToBeSigned = new IntPtr(&v); // in ingresso per motivi strani vuole un array di puntatori, di cui noi usiamo solo il primo

				uint[] rgcbToBeSigned = new uint[1]; // lunghezza del primo ed unico buffer da firmare
				rgcbToBeSigned[0] = (uint)inBuffer.Length;

				uint cbEncodedBlob = 0;
				int r = WinCapi.CryptSignMessage(
					ref SignMessagePara,
					0,
					1,
					rgpbToBeSigned,
					rgcbToBeSigned,
					IntPtr.Zero,
					ref cbEncodedBlob);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					hv.Free();
					Close(ref pCertContext);
					throw new CertException("CryptSignMessage", dwError);
				}
				// qui mi ha ritornato lo spazio massimo necessario per la firma

				byte[] outBuffer = new byte[cbEncodedBlob];
				GCHandle hh = GCHandle.Alloc(outBuffer, GCHandleType.Pinned);

				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(outBuffer, 0);

				r = WinCapi.CryptSignMessage(
					ref SignMessagePara,
					0,
					1,
					rgpbToBeSigned,
					rgcbToBeSigned,
					ptOutBuffer,
					ref cbEncodedBlob);
				hh.Free();
				hv.Free();
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					Close(ref pCertContext);
					throw new CertException("CryptSignMessage", dwError);
				}
				byte[] rb = new byte[cbEncodedBlob];
				for (int i = 0; i < cbEncodedBlob; ++i)
					rb[i] = outBuffer[i];


				Close(ref pCertContext);
				return rb;
			}
		}

		/// <summary>
		/// controfirma digitale
		/// </summary>
		/// <param name="inBuffer">documento da controfirmare</param>
		/// <returns>documento controfirmato</returns>
		public byte[] SignWithTimeStamp(byte[] inBuffer)
		{
			IntPtr pCertContext = WinCapi.CertCreateCertificateContext(WinCapi.MY_ENCODING_TYPE, _rawCertData, (uint)_rawCertData.Length);
			if (pCertContext == IntPtr.Zero)
				throw new CertException("CertCreateCertificateContext");


			byte[] EncTimeStamp;
			EncTimeStamp = EncodeActualFileTime();

			unsafe
			{
				WinCapi.CRYPT_SIGN_MESSAGE_PARA SignMessagePara = new WinCapi.CRYPT_SIGN_MESSAGE_PARA();

				WinCapi.CRYPT_ATTR_BLOB[] cablob = new WinCapi.CRYPT_ATTR_BLOB[1];
				WinCapi.CRYPT_ATTRIBUTE[] ca = new WinCapi.CRYPT_ATTRIBUTE[1];

				//
				// Pinned byteArray contenente timeStamp
				//
				GCHandle hEncTs = GCHandle.Alloc(EncTimeStamp, GCHandleType.Pinned);
				void* vEncTs = Marshal.UnsafeAddrOfPinnedArrayElement(EncTimeStamp, 0).ToPointer();

				cablob[0] = new WinCapi.CRYPT_ATTR_BLOB();
				cablob[0].cbData = (uint)EncTimeStamp.Length;
				cablob[0].pbData = new IntPtr(vEncTs);

				ca[0] = new WinCapi.CRYPT_ATTRIBUTE();

				//
				// Devo allocare al di fuori la stringa contenente l'identificatore RSA del signing time
				// perche' altrimenti non riesco ad eseguire il pinning
				//
				ca[0].pszObjId = Marshal.StringToHGlobalAnsi(WinCapi.szOID_RSA_signingTime);

				ca[0].cValue = 1;

				//
				// Pinned byteArray contenente blob attributi (CaBlob)
				//
				GCHandle hCaBlob = GCHandle.Alloc(cablob, GCHandleType.Pinned);
				void* vCaBlob = Marshal.UnsafeAddrOfPinnedArrayElement(cablob, 0).ToPointer();
				ca[0].rgValue = new IntPtr(vCaBlob);



				//
				// Pinned byteArray contenente attributi
				//
				GCHandle hCa = GCHandle.Alloc(ca, GCHandleType.Pinned);
				void* vCa = Marshal.UnsafeAddrOfPinnedArrayElement(ca, 0).ToPointer();


				void* ww = pCertContext.ToPointer();
				SignMessagePara.cbSize = 68; // sizeof(WinCapi.CRYPT_SIGN_MESSAGE_PARA);
				SignMessagePara.HashAlgorithm.pszObjId = WinCapi.szOID_OIWSEC_sha1;
				SignMessagePara.pSigningCert = pCertContext;
				SignMessagePara.dwMsgEncodingType = WinCapi.MY_ENCODING_TYPE;
				SignMessagePara.cMsgCert = 1;
				SignMessagePara.rgpMsgCert = new IntPtr(&ww); // &pSignerCert;

				//
				// Aggiungo attributo per il timestamp
				//
				SignMessagePara.cAuthAttr = 1;
				SignMessagePara.rgAuthAttr = new IntPtr(vCa);


				GCHandle hv = GCHandle.Alloc(inBuffer, GCHandleType.Pinned);
				void* v = Marshal.UnsafeAddrOfPinnedArrayElement(inBuffer, 0).ToPointer();
				IntPtr rgpbToBeSigned = new IntPtr(&v); // in ingresso per motivi strani vuole un array di puntatori, di cui noi usiamo solo il primo

				uint[] rgcbToBeSigned = new uint[1]; // lunghezza del primo ed unico buffer da firmare
				rgcbToBeSigned[0] = (uint)inBuffer.Length;

				uint cbEncodedBlob = 0;
				int r = WinCapi.CryptSignMessage(
					ref SignMessagePara,
					0,
					1,
					rgpbToBeSigned,
					rgcbToBeSigned,
					IntPtr.Zero,
					ref cbEncodedBlob);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					Marshal.FreeHGlobal(ca[0].pszObjId); // dealloco stringa con identificatore timestamp
					hEncTs.Free();						 // pinned bytearray con timestamp
					hCaBlob.Free();						 // pinned bytearray dei blob degli attributi
					hCa.Free();							 // pinned bytearray degli attributi
					hv.Free();
					Close(ref pCertContext);
					throw new CertException("CryptSignMessage", dwError);
				}
				// qui mi ha ritornato lo spazio massimo necessario per la firma

				byte[] outBuffer = new byte[cbEncodedBlob];
				GCHandle hh = GCHandle.Alloc(outBuffer, GCHandleType.Pinned);

				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(outBuffer, 0);

				r = WinCapi.CryptSignMessage(
					ref SignMessagePara,
					0,
					1,
					rgpbToBeSigned,
					rgcbToBeSigned,
					ptOutBuffer,
					ref cbEncodedBlob);

				Marshal.FreeHGlobal(ca[0].pszObjId); // dealloco stringa con identificatore timestamp
				hEncTs.Free();						 // pinned bytearray con timestamp
				hCaBlob.Free();						 // pinned bytearray dei blob degli attributi
				hCa.Free();							 // pinned bytearray degli attributi
				hh.Free();
				hv.Free();
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					Close(ref pCertContext);
					throw new CertException("CryptSignMessage", dwError);
				}

				byte[] rb = new byte[cbEncodedBlob];
				for (int i = 0; i < cbEncodedBlob; ++i)
					rb[i] = outBuffer[i];

				Close(ref pCertContext);
				return rb;
			}
		}


		/*
		/// <summary>
		/// 
		/// </summary>
		/// <param name="bUseMachineKeySet"></param>
		/// <param name="ProviderName"></param>
		/// 
		public void GenerateKeyContainer(bool bUseMachineKeySet)
		{
			GenerateKeyContainer(bUseMachineKeySet, _szContainerName, _szProvName);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="bUseMachineKeySet"></param>
		/// <param name="ProviderName"></param>
		public void DeleteKeyContainer(bool bUseMachineKeySet)
		{
			DeleteKeyContainer(bUseMachineKeySet, _szContainerName, _szProvName);
		}

		/// <summary>
		///		GenerateKeyContainer
		/// </summary>
		/// <param name="bUseMachineKeySet"></param>
		/// <param name="ContainerName"></param>
		/// <param name="ProviderName"></param>
		static public void GenerateKeyContainer(bool bUseMachineKeySet, string ContainerName, string ProviderName)
		{
			unsafe
			{
				int r;
				void* q;
				IntPtr hp = new IntPtr(&q);

				uint dwFlag;
				if (bUseMachineKeySet)
				{
					dwFlag = WinCapi.CRYPT_MACHINE_KEYSET | WinCapi.CRYPT_NEWKEYSET;
				}
				else
				{
					dwFlag = WinCapi.CRYPT_NEWKEYSET;
				}
				r = WinCapi.CryptAcquireContext(hp, ContainerName, ProviderName, WinCapi.PROV_RSA_FULL,
					dwFlag);
				if (r == 0)
					throw new CertException("CryptAcquireContext GenerateKeyContainer failure");

				IntPtr hCryptProv = new IntPtr(q);


				//
				// Genera una chiave di tipo AT_SIGNATURE RSA 1024 bit
				//
				void* ptCryptKey;
				IntPtr hCryptKeyPtr = new IntPtr(&ptCryptKey);
				bool bRes;
				bRes = WinCapi.CryptGenKey(hCryptProv, WinCapi.AT_SIGNATURE, WinCapi.RSA1024BIT_KEY | WinCapi.CRYPT_EXPORTABLE, hCryptKeyPtr);
				if (bRes == false)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CryptReleaseContext(hCryptProv, 0);
					throw new CertException("CryptGenKey  GenerateKeyContainer failure", dwError);
				}
				IntPtr hCryptKey = new IntPtr(ptCryptKey);

				r = WinCapi.CryptDestroyKey(hCryptKey);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CryptReleaseContext(hCryptProv, 0);
					throw new CertException("CryptDestroyKey GenerateKeyContainer failure", dwError);
				}

				r = WinCapi.CryptReleaseContext(hCryptProv, 0);
				if (r == 0)
					throw new CertException("CryptReleaseContext GenerateKeyContainer failure");
			}
		}

		/// <summary>
		///		DeleteKeyContainer
		/// </summary>
		/// <param name="bUseMachineKeySet"></param>
		/// <param name="ContainerName"></param>
		/// <param name="ProviderName"></param>
		static public void DeleteKeyContainer(bool bUseMachineKeySet, string ContainerName, string ProviderName)
		{
			unsafe
			{
				int r;
				void* q;
				IntPtr hp = new IntPtr(&q);

				uint dwFlag;
				if (bUseMachineKeySet)
				{
					dwFlag = WinCapi.CRYPT_MACHINE_KEYSET | WinCapi.CRYPT_DELETEKEYSET;
				}
				else
				{
					dwFlag = WinCapi.CRYPT_DELETEKEYSET;
				}
				r = WinCapi.CryptAcquireContext(hp, ContainerName, ProviderName, WinCapi.PROV_RSA_FULL,
					dwFlag);
				if (r == 0)
					throw new CertException("CryptAcquireContext DeleteKeyContainer failure");
			}
		}
		*/

		#region Implementation
		//
		// membro riportato da X509Certificate
		//
		private byte[] _rawCertData;

		//
		// membri calcolati ex-novo da pCertContext
		// dal costruttore
		//
		private Int64 _effectiveDate;
		private Int64 _expirationDate;
		private bool _keyUsageSupported;
		private ushort _keyUsage;
		private uint _certCurrentUserErrorStatus;
		private uint _certCurrentUserInfoStatus;
		private uint _certLocalMachineErrorStatus;
		private uint _certLocalMachineInfoStatus;
		private string[] _distributionPointList;
		private string _szContainerName;
		private string _szProvName;
		private string _certName;

		internal void InternalSet(IntPtr pCertContext)
		{
			_rawCertData = base.GetRawCertData();
			_effectiveDate = 0;
			try
			{
				_effectiveDate = loadEffectiveDate(pCertContext);
			}
			catch
			{
				_effectiveDate = 0;
			}

			_expirationDate = 0;
			try
			{
				_expirationDate = loadExpirationDate(pCertContext);
			}
			catch
			{
				_expirationDate = 0;
			}


			_keyUsageSupported = false;
			_keyUsage = 0;
			try
			{
				GetKeyUsage(pCertContext, out _keyUsageSupported, out _keyUsage);
			}
			catch
			{
				_keyUsageSupported = false;
				_keyUsage = 0;
			}

			_certCurrentUserErrorStatus = 0;
			_certCurrentUserInfoStatus = 0;
			try
			{
				GetChainStatus(pCertContext, false, out _certCurrentUserErrorStatus, out _certCurrentUserInfoStatus);
			}
			catch
			{
				_certCurrentUserErrorStatus = 0;
				_certCurrentUserInfoStatus = 0;
			}

			_certLocalMachineErrorStatus = 0;
			_certLocalMachineInfoStatus = 0;
			try
			{
				GetChainStatus(pCertContext, true, out _certLocalMachineErrorStatus, out _certLocalMachineInfoStatus);
			}
			catch
			{
				_certLocalMachineErrorStatus = 0;
				_certLocalMachineInfoStatus = 0;
			}

			_distributionPointList = null;
			try
			{
				_distributionPointList = GetDistributionPointList(pCertContext);
			}
			catch
			{
				_distributionPointList = null;
			}

			_szContainerName = "";
			_szProvName = "";
			try
			{
				GetContextProperty(pCertContext, out _szContainerName, out _szProvName);
			}
			catch
			{
				_szContainerName = "";
				_szProvName = "";
			}


			try
			{
				_certName = CertGetNameString(pCertContext);
			}
			catch
			{
			}

		}

		internal CertX509Ex(IntPtr pCertContext)
			: base(pCertContext)
		{
			InternalSet(pCertContext);
		}

		internal CertX509Ex(byte[] c)
			: base(c)
		{
			IntPtr pCertContext = WinCapi.CertCreateCertificateContext(WinCapi.MY_ENCODING_TYPE, c, (uint)c.Length);
			if (pCertContext == IntPtr.Zero)
				throw new CertException("CertCreateCertificateContext");

			InternalSet(pCertContext);
			Close(ref pCertContext);
		}

		internal void Close(ref IntPtr pCertContext)
		{
			int r;
			if (pCertContext != IntPtr.Zero)
			{
				r = WinCapi.CertFreeCertificateContext(pCertContext);
				if (r == 0)
					throw new CertException("CertFreeCertificateContext");
				pCertContext = IntPtr.Zero;
			}
		}

		internal string CertGetNameString(IntPtr pCertContext)
		{
			string CN = "";
			unsafe
			{
				int cbNameLen = WinCapi.CertGetNameStringA(pCertContext, WinCapi.CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, IntPtr.Zero, IntPtr.Zero, 0);
				if (cbNameLen == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CertFreeCertificateContext(pCertContext);
					throw new CertException("CertGetNameStringA", dwError);
				}

				byte* pp = stackalloc byte[cbNameLen + 1];
				cbNameLen = WinCapi.CertGetNameStringA(pCertContext, WinCapi.CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, IntPtr.Zero, new IntPtr(pp), (uint)cbNameLen + 1);
				if (cbNameLen == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CertFreeCertificateContext(pCertContext);
					throw new CertException("CertGetNameStringA", dwError);
				}

				CN = Marshal.PtrToStringAnsi(new IntPtr(pp));
			}
			return CN;
		}

		internal Int64 loadEffectiveDate(IntPtr pCertContext)
		{
			unsafe
			{
				WinCapi.CERT_CONTEXT* p = (WinCapi.CERT_CONTEXT*)pCertContext.ToPointer();
				WinCapi.CERT_INFO* ci = (WinCapi.CERT_INFO*)p->pCertInfo.ToPointer();

				Int64 ft = ((Int64)ci->NotBefore.dwLowDateTime) | (((Int64)ci->NotBefore.dwHighDateTime) << 32);
				return ft;
			}
		}

		internal Int64 loadExpirationDate(IntPtr pCertContext)
		{
			unsafe
			{
				WinCapi.CERT_CONTEXT* p = (WinCapi.CERT_CONTEXT*)pCertContext.ToPointer();

				WinCapi.CERT_INFO* ci = (WinCapi.CERT_INFO*)p->pCertInfo.ToPointer();

				Int64 ft = ((Int64)ci->NotAfter.dwLowDateTime) | (((Int64)ci->NotAfter.dwHighDateTime) << 32);
				return ft;
			}
		}

		internal void GetKeyUsage(IntPtr pCertContext, out bool keyUsageSupported, out ushort keyUsage)
		{
			unsafe
			{
				WinCapi.CERT_CONTEXT* pcc = (WinCapi.CERT_CONTEXT*)pCertContext.ToPointer();

				keyUsage = 0;
				keyUsageSupported = true;

				int r = WinCapi.CertGetIntendedKeyUsage(WinCapi.PKCS_7_ASN_ENCODING | WinCapi.X509_ASN_ENCODING, pcc->pCertInfo, out keyUsage, sizeof(ushort));
				if (r == 0 && Marshal.GetLastWin32Error() != 0)
				{
					// errore di tipo generale ( GetLastWin32Error() != 0 )
					keyUsageSupported = false;
				}
				if (r == 0)
				{
					// qui indica che il keyUsage non e` supportato
					// ma non e` un errore.

					// KeyUsage non supportato.
					keyUsageSupported = false;
				}
			}
		}


		internal void GetChainStatus(IntPtr pCertContext, bool bLocalMachine, out uint CertErrorStatus, out uint CertInfoStatus)
		{
			unsafe
			{
				WinCapi.CERT_CHAIN_CONTEXT ChainContext = new WinCapi.CERT_CHAIN_CONTEXT();

				IntPtr hChainContext = IntPtr.Zero;
				WinCapi.CERT_CHAIN_PARA ChainPara = new WinCapi.CERT_CHAIN_PARA();
				WinCapi.CERT_ENHKEY_USAGE EnhkeyUsage = new WinCapi.CERT_ENHKEY_USAGE();
				WinCapi.CERT_USAGE_MATCH CertUsage = new WinCapi.CERT_USAGE_MATCH();

				EnhkeyUsage.cUsageIdentifier = 0;
				EnhkeyUsage.rgpszUsageIdentifier = IntPtr.Zero;
				CertUsage.dwType = WinCapi.USAGE_MATCH_TYPE_AND;        // AND logic
				CertUsage.Usage = EnhkeyUsage;
				ChainPara.cbSize = (uint)sizeof(WinCapi.CERT_CHAIN_PARA);
				ChainPara.RequestedUsage = CertUsage;
				bool bResult = false;
				uint hChainEngine;

				//
				// usa catena di trust su Current User o Local Machine
				//
				if (bLocalMachine)
					hChainEngine = WinCapi.HCCE_LOCAL_MACHINE;
				else
					hChainEngine = WinCapi.HCCE_CURRENT_USER;


				// builds a certificate chain context starting from an end certificate and going back
				bResult = WinCapi.CertGetCertificateChain(
					hChainEngine,    // Use the Local Machine chain engine.
					pCertContext,	 // Pointer to the end certificate.
					IntPtr.Zero,     // Use the default time.
					IntPtr.Zero,     // Search no additional stores.
					ref ChainPara,   // Use AND logic, and enhanced key usage
					0,
					IntPtr.Zero,             // Currently reserved.
					out hChainContext);       // Return a pointer to the chain created.

				if (bResult == false)
					throw new CertException("CertX509Ex.GetCertificateChain Error");


				WinCapi.CERT_CHAIN_CONTEXT* pChainContext = (WinCapi.CERT_CHAIN_CONTEXT*)hChainContext.ToPointer();
				CertErrorStatus = pChainContext->TrustStatus.dwErrorStatus;
				CertInfoStatus = pChainContext->TrustStatus.dwInfoStatus;

				//
				//
				WinCapi.CertFreeCertificateChain(hChainContext);
			}
		}

		//
		// Dal certificato ottiene la lista degli indirizzi (URL HTTP o LDAP) (Certificate Distribution Points)
		// da cui scaricare le CRL
		//
		internal string[] GetDistributionPointList(IntPtr pCertContext)
		{
			uint dwFlags, cbUrlArray;
			bool r;
			string[] szDistributionPoints = null;

			unsafe
			{
				cbUrlArray = 0;
				dwFlags = WinCapi.CRYPT_GET_URL_FROM_PROPERTY | WinCapi.CRYPT_GET_URL_FROM_EXTENSION;
				r = WinCapi.CryptGetObjectUrl(WinCapi.URL_OID_CERTIFICATE_CRL_DIST_POINT,
					pCertContext,
					dwFlags,
					IntPtr.Zero,
					ref cbUrlArray,
					IntPtr.Zero,
					IntPtr.Zero,
					IntPtr.Zero);
				if (r == false)
				{

					//
					// in caso di certificati senza CDP ritorna stringa nulla
					//
					uint dwLastError = (uint)Marshal.GetLastWin32Error();
					if (dwLastError == WinCapi.HERROR_OBJECT_NOT_PRESENT)
					{
						return szDistributionPoints;
					}
					else
						throw new CertException("CertX509Ex.GetDistributionPointList error getting Distribution Point dimension", (int)dwLastError);
				}

				byte* p = stackalloc byte[(int)cbUrlArray];

				r = WinCapi.CryptGetObjectUrl(WinCapi.URL_OID_CERTIFICATE_CRL_DIST_POINT,
					pCertContext,
					dwFlags,
					new IntPtr(p),
					ref cbUrlArray,
					IntPtr.Zero,
					IntPtr.Zero,
					IntPtr.Zero);
				if (r == false)
				{
					throw new CertException("CertX509Ex.GetDistributionPointList error getting Distribution Point byte");
				}

				WinCapi.CRYPT_URL_ARRAY* urlArr = (WinCapi.CRYPT_URL_ARRAY*)p;

				uint nDistrPoints = urlArr->cUrl;
				szDistributionPoints = new string[nDistrPoints];
				void* current;

				//
				// Questa aritmetica dei puntatori e' per ottenere le stringhe dall'array ...
				// urlArr->rgwszUrl e' un array di stringhe unicode 
				//
				for (int i = 0; i < nDistrPoints; i++)
				{
					void* currArrPtr = (void*)((int)(urlArr->rgwszUrl).ToPointer() + i * sizeof(uint));
					current = (void*)Marshal.ReadIntPtr(new IntPtr(currArrPtr)).ToPointer();
					IntPtr ptrCurrent = new IntPtr(current);
					szDistributionPoints[i] = Marshal.PtrToStringUni(ptrCurrent);
				}
			}
			return szDistributionPoints;
		}

		internal void GetContextProperty(IntPtr pCertContext, out string pwszContainerName, out string pwszProvName)
		{
			unsafe
			{
				uint keyProvInfoLen = 0;
				int r = WinCapi.CertGetCertificateContextProperty(pCertContext, WinCapi.CERT_KEY_PROV_INFO_PROP_ID, IntPtr.Zero, ref keyProvInfoLen);
				if (r == 0)
					throw new CertException("CertGetCertificateContextProperty");

				byte* p = stackalloc byte[(int)keyProvInfoLen];
				r = WinCapi.CertGetCertificateContextProperty(pCertContext, WinCapi.CERT_KEY_PROV_INFO_PROP_ID, new IntPtr(p), ref keyProvInfoLen);
				if (r == 0)
					throw new CertException("CertGetCertificateContextProperty");

				WinCapi.CRYPT_KEY_PROV_INFO* ki = (WinCapi.CRYPT_KEY_PROV_INFO*)p;

				pwszContainerName = Marshal.PtrToStringUni(ki->pwszContainerName);
				pwszProvName = Marshal.PtrToStringUni(ki->pwszProvName);
			}
		}



		//
		// restituisce un byteArray con il valore del tempo attuale 
		// RSA-Encoded
		//
		internal byte[] EncodeActualFileTime()
		{
			bool bResult = true;
			byte[] EncFileTime;

			DateTime now = DateTime.Now;
			long fTime = now.ToFileTime();
			uint OutDataLen = 0;

			bResult = WinCapi.CryptEncodeObject(
				WinCapi.MY_ENCODING_TYPE,
				WinCapi.szOID_RSA_signingTime,
				ref fTime,
				IntPtr.Zero,
				ref OutDataLen);
			if (bResult == false)
			{
				throw new CertException("CryptEncodeFileTimeObject");
			}

			unsafe
			{
				byte[] r = new byte[OutDataLen];
				GCHandle rh = GCHandle.Alloc(r, GCHandleType.Pinned);
				void* ptr = Marshal.UnsafeAddrOfPinnedArrayElement(r, 0).ToPointer();

				bResult = WinCapi.CryptEncodeObject(
					WinCapi.MY_ENCODING_TYPE,
					WinCapi.szOID_RSA_signingTime,
					ref fTime,
					new IntPtr(ptr),
					ref OutDataLen);
				rh.Free();
				if (bResult == false)
				{
					throw new CertException("CryptEncodeFileTimeObject");
				}

				if (OutDataLen != r.Length)
				{
					byte[] rg = new byte[OutDataLen];
					for (int i = 0; i < OutDataLen; ++i)
						rg[i] = r[i];
					r = rg;
				}
				EncFileTime = r;
			}
			return EncFileTime;
		}

		internal void GetChainStatus(bool bLocalMachine, out uint CertErrorStatus, out uint CertInfoStatus)
		{
			if (bLocalMachine)
			{
				CertErrorStatus = _certLocalMachineErrorStatus;
				CertInfoStatus = _certLocalMachineInfoStatus;
			}
			else
			{
				CertErrorStatus = _certCurrentUserErrorStatus;
				CertInfoStatus = _certCurrentUserInfoStatus;
			}
		}

		#endregion
	}
}
