using System;
using System.IO;
using System.Xml;

namespace Bipex_Host
{
	public class AppConfigUpdater
	{
		private string innerSystemNet = null;

		private string RemoteHost;

		public void ReadAppConfig(string fileName, string configDestinationUrl)
		{
			XmlDocument d = new XmlDocument();
			d.Load(fileName);

			XmlElement root = d.DocumentElement;

			XmlNode sn = root.SelectSingleNode("system.net");
			if (sn != null)
				innerSystemNet = sn.InnerXml;

			sn = root.SelectSingleNode(string.Format("appSettings/add[@key='{0}']", configDestinationUrl));
			if (sn != null)
			{
				RemoteHost = sn.Attributes["value"].Value;
				Uri u = new Uri(RemoteHost);
				RemoteHost = u.Host;
			}
		}

		public void UpdateAppConfig(string fileName, string Proxy_User, string Proxy_Pwd, string Proxy_Domain)
		{
			XmlDocument d = new XmlDocument();
			d.Load(fileName);

			XmlElement root = d.DocumentElement;

			XmlNode sn = root.SelectSingleNode("system.net");
			if (sn == null)
			{
				XmlNode n = d.CreateNode(XmlNodeType.Element, "system.net", string.Empty);
				n.InnerXml = innerSystemNet;
				root.AppendChild(n);
			}

			if (Proxy_User != null && Proxy_User.Length > 0)
				CreateProxyEntry("Proxy_User", Proxy_User, d);

			if (Proxy_Pwd != null && Proxy_Pwd.Length > 0)
				CreateProxyEntry("Proxy_Pwd", Proxy_Pwd, d);

			if (Proxy_Domain != null && Proxy_Domain.Length > 0)
				CreateProxyEntry("Proxy_Domain", Proxy_Domain, d);

			d.Save(fileName);

			if (RemoteHost != null)
				UpdageRemoteAddress(fileName, RemoteHost);
		}

		private static void CreateProxyEntry(string tag, string value, XmlDocument d)
		{
			XmlElement root = d.DocumentElement;

			XmlNode sn;
			sn = root.SelectSingleNode(string.Format("appSettings/add[@key='{0}']", tag));
			if (sn != null)
				sn.ParentNode.RemoveChild(sn);

			XmlNode n = d.CreateNode(XmlNodeType.Element, "add", string.Empty);

			XmlAttribute a = d.CreateAttribute("key");
			a.Value = tag;
			n.Attributes.Append(a);

			a = d.CreateAttribute("value");
			a.Value = value;
			n.Attributes.Append(a);

			root.SelectSingleNode("appSettings").AppendChild(n);
		}

		private static void UpdageRemoteAddress(string fileName, string remoteHost)
		{
			string contenutoFile = null;
			using (StreamReader www = File.OpenText(fileName))
			{
				contenutoFile = www.ReadToEnd();
				contenutoFile = contenutoFile.Replace("localhost", remoteHost);
			}

			using (StreamWriter www = File.CreateText(fileName))
			{
				www.Write(contenutoFile);
			}
		}
	}

}