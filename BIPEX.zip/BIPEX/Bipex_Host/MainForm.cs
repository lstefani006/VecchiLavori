using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using Bipex_Engine.Bipex_ControlWS;
using Host.Web.ClientSecurity;
using NetworkSaver;
using Timer = System.Windows.Forms.Timer;

namespace Bipex_Host
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : Form
	{
		private static readonly string ApplicationName = "Bipex_Engine";
		private Timer tmrDeploy;
		private static string BipexEngineDir;

		[STAThread]
		private static void Main()
		{
			BipexEngineDir = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
			BipexEngineDir = Path.Combine(BipexEngineDir, ApplicationName);
			if (Directory.Exists(BipexEngineDir) == false)
				Directory.CreateDirectory(BipexEngineDir);


			bool continua = CheckAndKillOldEngine();
			if (!continua)
				return;

			Application.Run(new MainForm());
		}


		private static bool CheckAndKillOldEngine()
		{
			Process[] pList = Process.GetProcessesByName(ApplicationName);
			foreach (Process p in pList)
			{
				DialogResult r = MessageBox.Show(ApplicationName + " IS RUNNING.\nCLOSE APPLICATION BEFORE CONNECTING TO SERVER AGAIN.\nCONFIRM CLOSE APPLICATION ?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
				if (r == DialogResult.Cancel)
					return false;

				p.CloseMainWindow();

				for (int n = 0; n < 10; n++)
				{
					Thread.Sleep(1000);
					p.Refresh();

					if (p.HasExited)
						break;
				}

				if (!p.HasExited)
				{
					r = MessageBox.Show(ApplicationName + " IS NOT RESPONDING.\nCONFIRM CLOSE APPLICATION ?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
					if (r == DialogResult.Cancel)
						return false;
					p.Kill();
				}
			}

			return true;
		}


		public MainForm()
		{
			InitializeComponent();
		}

		private Button btnCancella;
		private Label lblProgress;
		private ProgressBar pbDownloadPrg;
		private Label lblTitle;
		private ListBox lbEvents;
		private Timer tmrStart;

		private Thread _th = null;
		private IContainer components = null;
		private ProxyDiscover.SetupProxyResult _proxyResult;

		#region Windows Form Designer generated code

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}


		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.btnCancella = new System.Windows.Forms.Button();
			this.lblProgress = new System.Windows.Forms.Label();
			this.lblTitle = new System.Windows.Forms.Label();
			this.pbDownloadPrg = new System.Windows.Forms.ProgressBar();
			this.lbEvents = new System.Windows.Forms.ListBox();
			this.tmrStart = new System.Windows.Forms.Timer(this.components);
			this.tmrDeploy = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// btnCancella
			// 
			this.btnCancella.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancella.Location = new System.Drawing.Point(320, 167);
			this.btnCancella.Name = "btnCancella";
			this.btnCancella.TabIndex = 0;
			this.btnCancella.Text = "Cancella";
			this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
			// 
			// lblProgress
			// 
			this.lblProgress.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblProgress.Location = new System.Drawing.Point(8, 167);
			this.lblProgress.Name = "lblProgress";
			this.lblProgress.Size = new System.Drawing.Size(296, 23);
			this.lblProgress.TabIndex = 1;
			// 
			// lblTitle
			// 
			this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTitle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte) (0)));
			this.lblTitle.Location = new System.Drawing.Point(8, 8);
			this.lblTitle.Name = "lblTitle";
			this.lblTitle.Size = new System.Drawing.Size(384, 23);
			this.lblTitle.TabIndex = 2;
			this.lblTitle.Text = "BipexControl";
			this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pbDownloadPrg
			// 
			this.pbDownloadPrg.Location = new System.Drawing.Point(8, 136);
			this.pbDownloadPrg.Maximum = 8;
			this.pbDownloadPrg.Minimum = 1;
			this.pbDownloadPrg.Name = "pbDownloadPrg";
			this.pbDownloadPrg.Size = new System.Drawing.Size(296, 16);
			this.pbDownloadPrg.TabIndex = 3;
			this.pbDownloadPrg.Value = 1;
			// 
			// lbEvents
			// 
			this.lbEvents.Location = new System.Drawing.Point(8, 40);
			this.lbEvents.Name = "lbEvents";
			this.lbEvents.Size = new System.Drawing.Size(384, 82);
			this.lbEvents.TabIndex = 4;
			// 
			// tmrStart
			// 
			this.tmrStart.Interval = 1000;
			this.tmrStart.Tick += new System.EventHandler(this.tmrStart_Tick);
			// 
			// tmrDeploy
			// 
			this.tmrDeploy.Interval = 1000;
			this.tmrDeploy.Tick += new System.EventHandler(this.tmrDeploy_Tick);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(400, 196);
			this.Controls.Add(this.lbEvents);
			this.Controls.Add(this.pbDownloadPrg);
			this.Controls.Add(this.lblTitle);
			this.Controls.Add(this.lblProgress);
			this.Controls.Add(this.btnCancella);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Downloading....";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.ResumeLayout(false);

		}

		#endregion

		#region Gestione della progress bar

		private delegate void ProgressDelegate(string strMsg);

		private ProgressDelegate m_ProgressDelegate;

		private void Progress(string strMsg)
		{
			try
			{
				if (this.InvokeRequired)
				{
					// this.Invoke(m_ProgressDelegate, new object[] {strMsg});
					this.BeginInvoke(m_ProgressDelegate, new object[] {strMsg});
					return;
				}

				lblProgress.Text = strMsg;
				lblProgress.Invalidate();
				lblProgress.Update();
			}
			catch
			{
			}
		}

		private delegate void SetNumberOfFilesToDownloadDelegate(int n);

		private SetNumberOfFilesToDownloadDelegate m_SetNumberOfFilesToDownloadDelegate;

		private void SetNumberOfFilesToDownload(int n)
		{
			if (InvokeRequired)
			{
				// this.Invoke(m_SetNumberOfFilesToDownloadDelegate, new object[] {n});
				this.BeginInvoke(m_SetNumberOfFilesToDownloadDelegate, new object[] {n});
				return;

			}
			if (n < 0)
				pbDownloadPrg.Maximum = -n;
			else
				pbDownloadPrg.Value = n;

			pbDownloadPrg.Invalidate();
			pbDownloadPrg.Update();

		}

		#endregion

		private void MainForm_Load(object sender, EventArgs e)
		{
			m_ProgressDelegate = new ProgressDelegate(this.Progress);
			m_GotAssemblyDelegate = new GotAssemblyDelegate(this.GotAssembly);
			m_SetNumberOfFilesToDownloadDelegate = new SetNumberOfFilesToDownloadDelegate(this.SetNumberOfFilesToDownload);


			ProxyDiscover.TestInternetConnectionEvent += new ProxyDiscover.TestInternetConnectionEventDelegate(ProxyDiscover_TestInternetConnectionEvent);
			ProxyDiscover.AskCredentialsForm = new ProxyDiscover.AskCredentialsFormDelegate(this.AskCredentials);

			this.tmrStart.Enabled = true;
		}

		private void tmrStart_Tick(object sender, EventArgs e)
		{
			this.tmrStart.Enabled = false;

			_proxyResult = CheckProxy();

			if (_proxyResult.Status == ProxyDiscover.TestInternetConnectionStatus.UserCancelled)
			{
				Application.Exit();
				return;
			}

			if (_proxyResult.Status == ProxyDiscover.TestInternetConnectionStatus.Error)
			{
				MessageBox.Show("General network error. Please, check your network configuration.");
				Application.Exit();
				return;
			}

			_th = new Thread(new ThreadStart(QueryAssembly));
			_th.IsBackground = true;
			_th.Start();
		}

		private static ProxyDiscover.SetupProxyResult CheckProxy()
		{
			string Url = ConfigurationSettings.AppSettings["Bipex_ControlWS_Deploy_Url"];

			ProxyDiscover.SetupProxyResult proxyResult;
			proxyResult = ProxyDiscover.SetupProxy(Url);

			return proxyResult;
		}


		public ICredentials AskCredentials()
		{
			frmLogin.rcFrmLogin r = new frmLogin.rcFrmLogin();
			frmLogin f = new frmLogin(frmLogin.enDialogMode.LoginUserPasswordNotVisibleDomain, ref r);
			f.Text = "Proxy credentials.";
			f.ShowDialog();

			if (f.DialogResult == DialogResult.OK)
			{
				NetworkCredential nc = new NetworkCredential(r.user, r.password);
				if (r.domain != null && r.domain.Length > 0)
					nc.Domain = r.domain;
				return nc;
			}


			return null;
		}

		private void btnCancella_Click(object sender, EventArgs e)
		{
			if (_th.IsAlive)
			{
				_th.Abort();

				MessageBox.Show(
					"Operation ABORTED by User.\n" +
						"Application CANNOT RUN Until Download has Ended.",
					"Error",
					MessageBoxButtons.OK, MessageBoxIcon.Stop);

				this.Close();
			}
			else
			{
				this.Close();
			}
		}


		// funzione chiamata nel thread di download
		private void QueryAssembly()
		{
			try
			{
				Deploy ws = new Deploy();
				ws.WSAuthHeaderValue = new WSAuthHeader();
				WSClient.Setup(ws, ref ws.WSAuthHeaderValue.Username, ref ws.WSAuthHeaderValue.Password, "Bipex_ControlWS_Deploy", ConfigurationSettings.AppSettings);


				// per prima cosa faccio il download del file di configurazione dell'engine.
				// puo` essere un .xml o un .config
				string fileNameExeConfig = BipexEngineDir + @"\" + ApplicationName + ".exe.config";
				if (true)
				{
					string fileNameExeConfigSenzaPath = Path.GetFileName(fileNameExeConfig);
					DateTime tsFileServerTime;
					byte[] data = ws.DownloadFile(fileNameExeConfigSenzaPath, DateTime.MinValue, out tsFileServerTime);

					// e lo scrivo aggiorno sempre nel file system
					using (FileStream www = File.Create(fileNameExeConfig))
					{
						www.Write(data, 0, data.Length);
						www.Close();
					}
				}

				// determino la lista dei file da downloadare
				ArrayList filesToDownload = new ArrayList();
				if (true)
				{
					XmlDocument xd = new XmlDocument();
					xd.Load(fileNameExeConfig);
					XmlNodeList nl = xd.DocumentElement.SelectNodes("./appSettings/add");

					foreach (XmlNode nn in nl)
					{
						string key = nn.Attributes.GetNamedItem("key").Value;
						if (key.StartsWith("Engine.Deploy_"))
						{
							string v = nn.Attributes.GetNamedItem("value").Value;
							filesToDownload.Add(v);
						}
					}
				}


				SetNumberOfFilesToDownload(-filesToDownload.Count);
				int nnn = 1;
				foreach (string fileToDownload in filesToDownload)
				{
					if (fileToDownload == fileNameExeConfig)
						continue;

					this.Progress(fileToDownload);
					this.ProxyDiscover_TestInternetConnectionEvent(fileToDownload);

					DateTime tsLastWriteTime = DateTime.MinValue;
					if (File.Exists(BipexEngineDir + @"\" + fileToDownload))
						tsLastWriteTime = File.GetLastWriteTime(BipexEngineDir + @"\" + fileToDownload);

					DateTime tsFileServerTime;
					byte[] data = ws.DownloadFile(fileToDownload, tsLastWriteTime, out tsFileServerTime);

					if (data == null)
					{
						this.Progress(fileToDownload + ": yet updated");
#if ! DEBUG
						Thread.Sleep(300); // per dare il tempo all'utente di contemplare le scritte
#endif
						continue;
					}

					string dir = Path.GetDirectoryName(BipexEngineDir + @"\" + fileToDownload);
					if (!Directory.Exists(dir))
						Directory.CreateDirectory(dir);

					using (FileStream fs = File.Create(BipexEngineDir + @"\" + fileToDownload))
					{
						fs.Write(data, 0, data.Length);
						fs.Close();
					}
					File.SetLastWriteTime(BipexEngineDir + @"\" + fileToDownload, tsFileServerTime);

					this.Progress(fileToDownload + ": updated");

					this.SetNumberOfFilesToDownload(nnn++);

#if ! DEBUG
					Thread.Sleep(300); // per dare il tempo all'utente di contemplare le scritte
#endif
				}


				// aggiorno il file .exe.config dell'engine per includere
				// il nome reale del "Bipex_ControlWS_Deploy_Url"
				// tutta l'element system.net del'Bipex_Host.exe.config
				// le entry di autenticazione del proxy determinate da ProxyDiscover
				if (true)
				{
					AppConfigUpdater up = new AppConfigUpdater();
					up.ReadAppConfig(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile,
					                 "Bipex_ControlWS_Deploy_Url");
					up.UpdateAppConfig(fileNameExeConfig,
					                   _proxyResult.Proxy_User,
					                   _proxyResult.Proxy_Pwd,
					                   _proxyResult.Proxy_Domain);
				}

				this.Progress("Deploy successfully");

				// se sono qui il download e' finito
#if ! DEBUG
				Thread.Sleep(1000); // do un po' di respiro al loop dei messaggi.
#endif
				this.GotAssembly(null);
			}
			catch (Exception ex)
			{
				// ho finito il download ma e' andato male
				// ==> spedisco l'eccezione rilevata al thread della finestra principale
				this.GotAssembly(ex);
			}
		}

		internal delegate void GotAssemblyDelegate(Exception ex);

		private GotAssemblyDelegate m_GotAssemblyDelegate;

		private void GotAssembly(Exception ex)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(m_GotAssemblyDelegate, new object[] {ex});
				return;
			}

			if (ex == null)
			{
				// download terminato con successo.
				tmrDeploy.Enabled = true;
				return;
			}

			Debug.Assert(ex != null);

			// ricerco nell'exception chain se e' stato interrotto il thread
			// con un Abort. Se si, evidentemente e' stato premuto cancel
			// e dunque non si deve presentare il messaggio di errore.
			bool bAbort = false;
			for (Exception ei = ex; ei != null; ei = ei.InnerException)
			{
				if (ei is ThreadAbortException)
				{
					bAbort = true;
					break;
				}
			}

			if (bAbort == false)
			{
				string msg = "Communication Error while connecting to Remote Site.\n";
				msg += "Check Internet Connection.\n\n";
				msg += ex.Message;

				MessageBox.Show(
					msg,
					"FATAL Error",
					MessageBoxButtons.OK, MessageBoxIcon.Stop);
			}

		}

		private delegate void LogDelegate(string msg);

		private void ProxyDiscover_TestInternetConnectionEvent(string msg)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(new LogDelegate(ProxyDiscover_TestInternetConnectionEvent), new object[] {msg});
				return;
			}
			lbEvents.Items.Add(msg);
		}

		private void tmrDeploy_Tick(object sender, EventArgs e)
		{
			tmrDeploy.Enabled = false;
			if (RunDowloadedAssembly())
				this.Close();
		}


		private static bool RunDowloadedAssembly()
		{
			string ass_exe = BipexEngineDir + @"\" + ApplicationName + ".exe";
			try
			{
				Process processEngine = new Process();

				processEngine.StartInfo.FileName = ass_exe;
				processEngine.StartInfo.CreateNoWindow = true;
				// processEngine.StartInfo.WindowStyle = ProcessWindowStyle.Maximized;
				processEngine.StartInfo.WorkingDirectory = Path.GetDirectoryName(BipexEngineDir);

				// brillante (si fa per dire) codice per generare un numero esadecimale di 15cifre
				// composto da 3 numeri di 5 cifre, con il terzo lo xor dei primi due.
				// Tutto questo per fare in modo che l'engine lanciato possa "capire"
				// di essere stato lanciato dall'host.
				// In questo modo si costringe l'utente del programma di lanciare l'host per lanciare l'engine
				Random r = new Random();
				int a = r.Next(0x80000, 0xFffff); // Max value escluso
				int b = r.Next(0x80000, 0xFffff); // Max value escluso
				int c = a ^ b;

				string args = string.Format("{0:X5}{1:X5}{2:X5}", a, b, c);
				processEngine.StartInfo.Arguments = args;

				processEngine.Start();

				// non funziona e non si sa perche`
				// while (processEngine.Responding == false)
				//	Application.DoEvents();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "FATAL Error");
				return false;
			}

			return true;
		}


	}
}