//*******************************************************************
//              Exception routines for C++              
//*******************************************************************

#ifndef __EXHANDLE_HPP
#define __EXHANDLE_HPP

#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifndef WINDOWS
// Versione DOS 
#include <setjmp.h>
#else
// Versione WINDOWS 
#if !defined(__WINDOWS_H) && !defined(__INC_WINDOWS)
#include <windows.h>
#endif

#endif

#ifndef forever
#define forever for (;;)
#endif

class exception
{
public:
	exception(const char *pchMsg) { m_pchMsg = pchMsg; }
	int operator == (const exception &ex) const { return this == &ex; }
	virtual const char * Msg() const;
	
protected:
	const char *m_pchMsg;
	static char m_achMsg[];				/* used by Msg()  */

private:
	exception(const exception &ex);			/* cannot be used */
	void operator = (const char *pchMsg);	/* cannot be used */
};

extern const exception *theException;	/* the trowned exception */
extern const exception AllExceptions;	/* "AllExcpetions"       */
extern const exception OutOfMemory;		/* "Out of memory"       */
extern const exception FileNotFound;	/* "File not found"      */
extern const exception Eof;				/* "End of file"         */

/*
#define throw(exception)     ExHandle::Throw    (__FILE__, __LINE__, exception)
#define terminate(exception) ExHandle::Terminate(__FILE__, __LINE__, exception)
*/
#define throw(exception)     ExHandle::Throw    (0, 0, exception)
#define terminate(exception) ExHandle::Terminate(0, 0, exception)

struct ExHandle
{
	ExHandle();
	~ExHandle();

	static ExHandle   *Top;
	static const char *ExFile;
	static int         ExLine;

	static void Throw(const char *, int, const exception &);
	static void Throw(const char *, int, const exception *);
	static void Terminate(const char *, int, const exception *);

	ExHandle *Previous;

	enum State { OnTry = 0, OnThrow, OnCatch } flag;

	int bFinally;

#ifdef WINDOWS
	CATCHBUF jb;
#else
	jmp_buf jb;
#endif

};



/* flag = 0 quando entro nel blocco di try; se tutto ok chiamo il distrutto-
 *          re di _jbr e non chiamo throw per il prossimo blocco
 * flag = 1 quando faccio un longjmp ossia ho un'eccezione; se la presente
 *          eccezione non e` catturata in questo blocco di try il distrutto-
 *          re di _jbr la passera` al blocco di try immediatamente annidato
 * flag = 2 quando catturo un'eccezione; in questo caso alla fine del catch
 *          eseguo _jbr.~ExHandle::ExHandle() e questo non rilancia l'ec-
 *          cezione al blocco di try immediatamente annidato (se esiste)
 */

#ifdef WINDOWS
#define setjmp(a)    ::Catch(a)
#define longjmp(a,b) ::Throw(a,b)
#endif

extern const bool bFalse;

#define try														\
do																\
{																\
	ExHandle _jbr;												\
	_jbr.flag = (ExHandle::State) setjmp(_jbr.jb); 				\
	if (_jbr.flag == ExHandle::OnTry)							\
		/* stmt; se ho un throw _jbr.flag == OnThrow */
#define finally													\
	if ((_jbr.flag == ExHandle::OnTry ||						\
	     _jbr.flag == ExHandle::OnThrow) &&						\
		 (_jbr.bFinally = 1) == 1)								\
		/* stmt; */
#define catch(e)												\
	if (_jbr.flag == ExHandle::OnThrow &&  						\
	    (AllExceptions == e || *theException == e) && 			\
	    ((_jbr.flag = ExHandle::OnCatch) == ExHandle::OnCatch))	\
		/* stmt; */

#define end_catch												\
} while (bFalse)

#endif	// EXHANDLE_HPP
