#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__SET[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__SET
#endif


ImplementObject(Set, Slist);
ImplementPersistent(Set);

void Set::Put(Object &a)
{
	if (Search(a) == 0)
		Slist::AddTail(a);
}

void Set::Put(Object *ptObj)
{
	Put(*ptObj);
}

Object * Set::Get()		// return and remove item in set
{
	return Slist::GetHead();
}

const Object * Set::Search(const Object &a) const
{
	return Slist::Search(a);
}

const Object * Set::Search(bool (*ptTest)(const Object *pObj, void *pVoid), void *pVoid, int Ignore) const
{
	return Slist::Search(ptTest, pVoid, Ignore);
}


bool Set::isEqual(const Object &a) const
{
	return Slist::isEqual(a);
}

/*
void Set::printOn(ostream &s) const
{
	s << isA() << ":";
	Slist::printOn(s);
}
*/

//***************************************************************


void Set::Serialize(Persistent &p)
{
	Assert(this);

	Slist::Serialize(p);
}
