#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <io.h>
#include <malloc.h>
#include <stdarg.h>

#include "regexp.h"

char b[100];
void print(regexp FAR *, const char *);

int RedirettoSuFile = 0;

void main(int ac, char *av[])
{
	{
	char b[100]; char out1[100]; int out2;
	strcpy(b, "\tleo_Nard32Do(30) ");
	int r = rsscanf(b, "^[ \t]*([a-zA-Z0-9_]+)[ \t]*\\(([0-9]+)\\)[ \t]*$", "%s %d", (char FAR *)out1, (int FAR *)&out2);
	printf("risultato %d => \"%s\"  \"%d\"\n", r, out1, out2);
        }


    regexp FAR *pt;
    FILE *fin;
    int i;
    int wordSearch = 0;

    char *prgName = av[0];

    if (!isatty(fileno(stdout)))
	RedirettoSuFile = 1;

    while (ac >= 2 && av[1][0] == '-')
    {
	if (av[1][1] == 'w')
	{
	    wordSearch++;
	    av++;
	    ac--;
	}
	else
	{
	    fprintf(stderr, "Unrecognised option '%c'.\n", av[1][1]);
	    ac = 1;
	}
    }

    if (ac < 3)
    {
	fprintf(stderr, "Use: %s [-w] reg-expr file ...\n", strlwr(prgName));
	fprintf(stderr, "\t-w\tword search\n");
	exit(1);
    }

    if (!wordSearch)
	pt = regcomp(av[1]);
    else
	pt = regcomp("[a-zA-Z_][a-zA-Z0-9_]*");

    if (pt == 0)
    {
	fprintf(stderr, "wrong reg-expr\n");
	exit(1);
    }
    fprintf(stderr, "reg-expr \"%s\"\n", av[1]);

    for (i = 2; i < ac; i++)
    {
	fin = fopen(av[i], "r");
	if (fin == 0)
	{
	    perror(prgName);
	    continue;
	}

	while (fgets(b, 100, fin))
	{
	    const char FAR *start = b;
	    do
	    {
		int r = regexec(pt, start);
		if (r)
		{
		    if (!wordSearch)
		    {
			print(pt, b);
			start = pt->endp[0];
		    }
		    else
		    if (_fstrncmp(pt->startp[0], av[1], strlen(av[1])) == 0 &&
			pt->startp[0] + strlen(av[1]) == pt->endp[0])
		    {
			print(pt, b);
			start = pt->endp[0];
		    }
		    else
			start = pt->endp[0];
		}
		else
		    start = 0;
	    }
	    while (start && start < b + strlen(b));
	}
	fclose(fin);
    }

    if (!RedirettoSuFile)
    {
	// lowvideo();
	putch('\r');
	putch('\n');
	clreol();
    }
    else
	putchar('\n');

    regfree(pt);

    exit(0);
}

void print(regexp FAR *re, const char *pt)
{
    while (*pt)
    {
	if (!RedirettoSuFile && pt == re->startp[0])
	    /*highvideo()*/;
	if (!RedirettoSuFile && pt == re->endp[0])
	    /*lowvideo()*/;

	if (*pt == '\t')
	    if (!RedirettoSuFile)
		putch(' ');
	    else
		putchar(' ');
	else
	if (*pt != '\n')
	    if (!RedirettoSuFile)
		putch(*pt);
	    else
		putchar(*pt);
	pt++;
    }
    if (!RedirettoSuFile)
    {
	clreol();
	putch('\r');
	putch('\n');
    }
    else
	putchar('\n');
}


