#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "regexp.h"

#ifndef CHARBITS
#define	UCHARAT(p)	((int)*(unsigned char *)(p))
#else
#define	UCHARAT(p)	((int)*(p)&CHARBITS)
#endif

#define FAIL(msg) { regerror(msg); return; }

/*
 - regsub - perform substitutions after a regexp match
 */
void _export FAR PASCAL regsub(regexp * prog, const char *source, char *dest)
{
    const char *src;
    char *dst;
    char c;
    int no;
    int len;

    if (prog == NULL || source == NULL || dest == NULL)
	FAIL("NULL parm to regsub");
    if (UCHARAT(prog->program) != (unsigned char) REG_MAGIC)
	FAIL("damaged regexp fed to regsub");

    src = source;
    dst = dest;
    while ((c = *src++) != '\0')
    {
	if (c == '&')
	    no = 0;
	else
	if (c == '\\' && '0' <= *src && *src <= '9')
	    no = *src++ - '0';
	else
	    no = -1;

	if (no < 0)		/* Ordinary character. */
	    *dst++ = c;
	else
	if (prog->startp[no] != NULL && prog->endp[no] != NULL)
	{
	    len = (int)(prog->endp[no] - prog->startp[no]);
	    strncpy(dst, prog->startp[no], len);
	    dst += len;
	    /* strncpy hit NUL? */
	    if (len != 0 && *(dst - 1) == '\0')
		FAIL("damaged mch string");
	}
    }
    *dst++ = '\0';
}
