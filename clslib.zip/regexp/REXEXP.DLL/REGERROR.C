#include <windows.h>
#include <stdlib.h>

void _export FAR PASCAL regerror(const char *s)
{
	char b[100];
	wsprintf(b, "regexp: %s", s);
	MessageBox(0, s, "Error", MB_OK);
	FatalAppExit(0, "Errore in RegExp.dll");
}
