#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "regexp.h"

int _export FAR rsscanf(const char *b, const char *ptRegExp, const char *fmt,...)
{
    size_t sz = 0;
    int i;
    char *ptT = 0, *ptTbase = 0;
    va_list argptr;

    struct regexp *pt = regcomp(ptRegExp);
    int r = regexec(pt, b);
    if (r == 0)
	return 0;

    for (i = 1; i < NSUBEXP && pt->startp[i] && pt->endp[i]; i++)
	sz += (size_t) (pt->endp[i] - pt->startp[i]) + 1;

    ptTbase = ptT = (char *) malloc(sz);
    *ptT = 0;

    for (i = 1; i < NSUBEXP && pt->startp[i] && pt->endp[i]; i++)
    {
	sz = (size_t) (pt->endp[i] - pt->startp[i]);
	strncpy(ptT, pt->startp[i], sz);
	ptT += sz;
	*ptT++ = ' ';
    }
    *ptT = 0;

    va_start(argptr, fmt);
    i = vsscanf(ptTbase, fmt, argptr);
    va_end(argptr);

    free(ptTbase);
    regfree(pt);

    return i;
}
