#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__OBJECT[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__OBJECT
#endif


//////////////////////////////////////////////////////////
// Object members
//

classType Object::isA(classType ct) const
{
	if (ct == typeid(Object))
		return ct;
	return typeid(void);
}

ImplementAbstractPersistent(Object);

Object * Object::StaticCreateObject()
{
	return NULL;
}

///////////////////////////////////////////////////////
// Memory management
//
static bool S_ObjectOnFreeStore = false;

void * Object::operator new(size_t sz)
{
	Assert(S_ObjectOnFreeStore == false);

	void *pt = ::new char [sz];			// se capita un eccezione di memoria
										// finita ObjectOnFreeStore e` ancora 
										// false
	S_ObjectOnFreeStore = true;
	
	return pt;
}

void Object::operator delete(void * pt)
{
	if (pt == 0)
		return;
		
	if (((Object *)pt)->IsOnFreeStore() == false)
		Error("Object::operator delete() called for "
			  "static or automatic Object at %Fp", pt);
	
	::delete(pt);
}

bool Object::IsOnFreeStore() const
{
	if (this == 0)
		return false;
	return bool(m_Flag & 1);
}

//////////////////////////////////////////////////////////////
// Constructors & Destructors
//
Object::Object()
{
	m_Flag = 0;
	if (S_ObjectOnFreeStore)
		m_Flag = 1;
	
	S_ObjectOnFreeStore = false;

	DbObj.Add(this);
}

Object::~Object()
{
	Assert(this);
	if (m_Flag >> 1)
		Error ("Object::~Object() called for shared Object at %Fp (%s)", this, isA().name());
	
	DbObj.Kill(this);
}


/////////////////////////////////////////////////////////////////
// Shared object management
//
int Object::IncOwners() const
{
	if (this == 0)
		return -1;
	((Object *)this)->m_Flag += 2;
	return int(m_Flag >> 1);
}

int Object::DecOwners() const
{
	if (this == 0)
		return -1;
	if ((m_Flag >> 1) == 0)
		Error("Object::DecOwners() < 0 at %Fp (%s)", this, isA().name());
	((Object *)this)->m_Flag -= 2;
	return int(m_Flag >> 1);
}

int Object::DecOwners(Object *&ptObject)
{
	Assert(this == ptObject);

	if (this == 0)
		return -1;

    int n = DecOwners();
	if (n == 0 && IsOnFreeStore() == true)
		Delete this;
	ptObject = 0;
	return n;
}

int Object::GetOwners() const
{
	if (this == 0)
		return -1;
	return int(m_Flag >> 1);
}

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
// stampa di Object e operatori di eguaglianza
bool Object::isEqual(const Object &) const
{
	return false;
}

int operator == (const Object & a, const Object & b)
{
	if (&a == 0 && &b == 0)
		return true;
	if (&a == 0 || &b == 0)
		return false;
	return a.isEqual(b);
}

int operator != (const Object & a, const Object & b)
{
	if (&a == 0 && &b == 0)
		return false;
	if (&a == 0 || &b == 0)
		return true;
	return ! a.isEqual(b);
}


//////////////////////////////////////////////////////////////////
//  Persistent Object member
//
void Object::Serialize(Persistent &)
{
	Assert(this);
}

/////////////////////////////////////////////////////////////////
// IteratorData  Iterator 
IteratorData::IteratorData() {}
IteratorData::~IteratorData() {}
Iterator::Iterator(const Object *o) { itd = o->InitIterator() ; }
Iterator::Iterator(const Object &o) { itd = o.InitIterator() ; }
Iterator::~Iterator() { Delete itd ; }
const Object * Iterator::operator ()() { return itd -> GetNext() ; }


/////////////////////////////////////////////////////////////////
// Iterator members
//
ImplementObject(Iterator, Object);


class ObjectIterator : public IteratorData
{
public:
	ObjectIterator(const Object *o) { m_obj = o; }
	virtual ~ObjectIterator() {}
	virtual const Object * GetNext();
private:
	const Object *m_obj;
};

const Object * ObjectIterator::GetNext()
{
	Assert(this);
	if (m_obj == 0)
		return 0;
	const Object *tmp = m_obj;
	m_obj = 0;
	return tmp;
}

IteratorData * Object::InitIterator() const
{
	Assert(this);
	return new ObjectIterator(this);
}

