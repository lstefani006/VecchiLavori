#ifndef __NEW_HPP
#define __NEW_HPP

#include <stddef.h>

typedef unsigned char uchar;
typedef unsigned int  uint;
typedef unsigned long ulong;


void *operator new (size_t sz);
void operator delete (void *pt);

// ReNew reallocs free store areas from operator new
void *ReNew(void *pt, size_t new_sz);


#ifdef DEBUGNEW
// New chiama new con le informazioni di debug
// Delete chiama delete con le informazioni di debug 
//
void *operator new (size_t, const char *, int, int isObj);
void operator delete (void *);
#define New new(__THIS_FILE__, __LINE__, 0)

extern const char *__new_file;
extern int __new_line;
extern int __new_flag;
#define Delete __new_file = __THIS_FILE__, __new_line = __LINE__, \
			   __new_flag = 1, delete

void *__new_ReNew(const char *, int, void *, size_t);
#define ReNew(type, pt, sz) (type *)__new_ReNew(__THIS_FILE__, __LINE__, pt, sizeof(type) * sz)

void Dump();

#else

void *__new_ReNew(void *, size_t);
#define New    new
#define Delete delete
#define ReNew(type, pt, sz)  (type *)__new_ReNew(pt, sizeof(type) * sz)

#endif
#endif
