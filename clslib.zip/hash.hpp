#ifndef __HASH_HPP
#define __HASH_HPP

#ifndef __OBJECT_HPP
#include <Object.hpp>
#endif


unsigned default_Hash(const char *, int);
typedef unsigned (* HASHFUNC)(const char *, int);

class Hash : public Object
{
public :
	DeclareObject(Hash);
	DeclarePersistent(Hash);

	Hash();
	Hash(const Hash &);
	Hash(int /*= 20 */, HASHFUNC /*= default_Hash*/);
	~Hash() { Cleanup(); }
	
	virtual bool isEqual(const Object &) const { return false; }

	
	Object *Insert(const char *, Object *);
	Object *Insert(const char *, Object &);
	Object *Lookup(const char *) const;
	int Remove(const char *);
	void Cleanup();
	
	void HashReport();
	size_t nOfItems() const;

	virtual class IteratorData *InitIterator() const;
	
private :
	friend class HashIterator;
	class Hashitem
	{
		friend class Hash;
		friend class HashIterator;
		friend void Hash_report(Hash &);
		Hashitem *next;
		Object *obj;
		char name[1];   /* actual length unknown */
	};
	Hashitem **table;
	int tabsize;
	HASHFUNC Hashfunc;
	int item_inserted;

	void operator = (const Hash &);
};

#endif
