

#include <clslib.hpp>


void main()
{
	LinkObj<String> dd;

	Persistent p("leo.dat", Persistent::Out);

	Serialize(p, dd);
}