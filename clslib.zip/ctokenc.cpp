#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <fstream.h>

#ifndef __CTOKENC_HPP
#include <ctokenc.hpp>
#endif
#ifndef __HASH_HPP
#include <Hash.hpp>
#endif
#ifndef __ERROR_HPP
#include <Error.hpp>
#endif


ImplementObject(cToken, Object);


void cToken::printOn(ostream & s) const
{
	if (*token != '\n')
	{
		s << "line " << linenu << ' ';
		if (tt < 10)
			s << ' ';
		s << int(tt) << ' ' << token;
	}
}


cToken::cToken()
{
	tt = None;
	token = 0;
	linenu = 1;
}

cToken::cToken(const char *s, TokenType t, unsigned ln)
{
	tt = t;
	token = s;
	linenu = ln;
}

void cToken::operator = (const cToken & tk)
{
	if (token)
		Delete (char *) token;
	token = strdup(tk.token);
	tt = tk.tt;
	linenu = tk.linenu;
}


//***********************************************************************


// Queste variabili possono essere static in quanto sono usate soltanto per la
// durata della chiamata dell'operatore >>
char cTokenIstream::c;
char cTokenIstream::l;


void cTokenIstream::next()
{
	c = get();
	l = (c == EOF) ? EOF : peek();
}

cTokenIstream::cTokenIstream()
{
	linenu = 0;
	state = Cr;	// all'inizio del file puo` esserci # 
}

cTokenIstream::cTokenIstream(istream & s)
{
	linenu = 1;
	state = Cr;	// all'inizio del file puo` esserci # 
	istream_withassign::operator = (s);
}

cTokenIstream & cTokenIstream::operator = (cTokenIstream & s)
{
	linenu = s.linenu;
	state = s.state;
	istream_withassign::operator = (s.rdbuf());
	return *this;
}

cTokenIstream & cTokenIstream::operator = (streambuf *sb)
{
	linenu = 1;
	state = Cr;	// all'inizio del file puo` esserci # 
	istream_withassign::operator = (sb);
	return *this;
}

cTokenIstream & cTokenIstream::operator = (istream & s)
{
	linenu = 1;
	state = Cr;	// all'inizio del file puo` esserci # 
	istream_withassign::operator = (s);
	return *this;
}

//****************************************************************

class buffctoken
{
public:
	buffctoken(size_t sz = 5);
	~buffctoken();
	void reset();			// per riusare il buffer

	void put(char);			// per scrivere nel buffer
	void put(const char *);		// per scrivere nel buffer
	operator const char * ();	// per leggere dal buffer
					// come una stringa
private:
	char *base;			// l'inizio del buffer
	char *pt;			// dove si scrive
	char *end;			// la fine del buffer

	void resize(size_t minsz = 0);	// setta la nuova dimensione
					// minsz e` il minimo aumento della
					// dimensione del buffer
};

buffctoken::buffctoken(size_t sz)
{
	base = pt = New char [sz];
	end = base + sz;
	memset(base, 0, sz);
}

buffctoken::~buffctoken()
{
	if (base)
		Delete base;
	base = end = pt = 0;
}

inline void buffctoken::reset()
{
	memset(base, 0, size_t(end - base));
	pt = base;
}

inline void buffctoken::put(char c)
{
	if (pt >= end)
		resize();
	*pt++ = c;
}

void buffctoken::put(const char *str)
{
	size_t sl = strlen(str);
	if (pt + sl >= end - 1)
		resize(sl);
	memcpy(pt, str, sl);
	pt += sl;
}

buffctoken::operator const char * ()
{
	put('\0');
	return base;
}

void buffctoken::resize(size_t minsz)
{
	size_t oldsz = size_t(pt - base);
	size_t newsz = 2 * oldsz;

	if (newsz < oldsz + minsz)
		newsz = oldsz + minsz;

	char *ptnew = New char [newsz];
	memcpy(ptnew, base, oldsz);
	memset(ptnew + oldsz, 0, newsz - oldsz);
	Delete base;
	base = ptnew;
	pt = ptnew + oldsz;
	end = ptnew + newsz;
}


static buffctoken buff;


//****************************************************************************


class CtokenHash
{
public:
	CtokenHash();
	void Insert(const char *pt, cToken *k) { tb.Insert(pt, k); }
	cToken *Lookup(const char *pt) { return (cToken *) tb.Lookup(pt); }
	void HashReport() { tb.HashReport(); }
private:
	Hash tb;

	CtokenHash(const CtokenHash &);
};

struct KeywordType
{
	const char *str;
	cToken::TokenType code;
};

static KeywordType far keyword[] = {
	"{",		 (cToken::TokenType) '{',
	"}",		 (cToken::TokenType) '}',
	"*",		 (cToken::TokenType) '*',
	";",		 (cToken::TokenType) ';',
	"[",		 (cToken::TokenType) '[',
	"]",		 (cToken::TokenType) ']',
	"asm",       cToken::Asm,
	"auto",      cToken::Auto,
	"break",     cToken::Break,
	"case",      cToken::Case,
	"catch",     cToken::Catch,
	"char",      cToken::Char,
	"class",     cToken::Class,
	"const",     cToken::Const,
	"continue",  cToken::Continue,
	"default",   cToken::Default,
	"delete",    cToken::_Delete,
	"do",        cToken::Do,
	"double",    cToken::Double,
	"else",      cToken::Else,
	"enum",      cToken::Enum,
	"extern",    cToken::Extern,
	"float",     cToken::Float,
	"for",       cToken::For,
	"friend",    cToken::Friend,
	"goto",      cToken::Goto,
	"if",        cToken::If,
	"inline",    cToken::Inline,
	"int",       cToken::Int,
	"long",      cToken::Long,
	"new",       cToken::_New,
	"operator",  cToken::Operator,
	"private",   cToken::Private,
	"protected", cToken::Protected,
	"public",    cToken::Public,
	"register",  cToken::Register,
	"return",    cToken::Return,
	"short",     cToken::Short,
	"signed",    cToken::Signed,
	"sizeof",    cToken::Sizeof,
	"static",    cToken::Static,
	"struct",    cToken::Struct,
	"switch",    cToken::Switch,
	"template",  cToken::Template,
	"this",      cToken::This,
	"throw",     cToken::Throw,
	"try",       cToken::Try,
	"typedef",   cToken::Typedef,
	"union",     cToken::Union,
	"unsigned",  cToken::Unsigned,
	"virtual",   cToken::Virtual,
	"void",      cToken::Void,
	"volatile",  cToken::Volatile,
	"while",     cToken::While,

	// direttive preprocessore 
	"#include",  cToken::PreProc,
	"#line",     cToken::PreProc,
	"#define",   cToken::PreProc,
	"#undef",    cToken::PreProc,
	"#if",       cToken::PreProc,
	"#ifdef",    cToken::PreProc,
	"#ifndef",   cToken::PreProc,
	"#else",     cToken::PreProc,
	"#elif",     cToken::PreProc,
	"#endif",    cToken::PreProc,
	"#pragma",   cToken::PreProc,
	"#error",    cToken::PreProc,
	"#",         cToken::PreProc,		// tipo # 10 l.c 

	// MSDOS keywords 
	"cdecl",     cToken::Cdecl,
	"_export",   cToken::_Export,
	"far",       cToken::Far,
	"huge",      cToken::Huge,
	"interrupt", cToken::Interrupt,
	"_loadds",   cToken::_Loadds,
	"near",      cToken::Near,
	"pascal",    cToken::Pascal,
	"_saveregs", cToken::_Saveregs,
	"_seg",      cToken::_Seg,
	0
};

CtokenHash::CtokenHash()
{
	for (KeywordType *ptk = keyword ; ptk->str ; ptk++)
		Insert(ptk->str, New cToken(ptk->str, ptk->code));

	// serve per caricare typedef gia` definiti ecc
	char *pt = getenv("CTOKENC");
	if (pt == 0)
		pt = "ctokenc.tbl";

	ifstream fin(pt);
	if (!fin)
		return;

	forever
	{
		char b[80];
		fin >> b;
		if (!fin)
			break;
		if (b[0] == '#')
			continue;

		pt = strchr(b, ':');
		if (pt == 0)
		{
			Insert(b,
				New cToken(strdup(b), cToken::NewType));
		}
		else
		{
			*pt = 0;
			cToken *ct = Lookup(pt + 1);
			if (ct == 0)
				throw ("unknown keyword");

			Insert(b,
				New cToken(strdup(b), ct->getTokenType()));
		}
	}

#if 0
	HashReport();		// report uso sym-table
#endif
}

#if 1
CtokenHash tb;
#endif


//****************************************************************************

void cTokenIstream::Add(cToken *tk)
{
	tb.Insert(tk->Get(), tk);
}


void cTokenIstream::identificatore()
{
	buff.put(c);

	while (isalnum(l) || l == '_')
	{
		next();
		buff.put(c);
	}
}

void cTokenIstream::numero_esa()
{
	buff.put(c);		// lo 0

	next();
	buff.put(c);		// la x o X

	if (! isdigit(l))
	{
		throw ("bad formed 0x number");
		clear(rdstate() | ios::badbit);
		return;
	}

	while (isdigit(l))
	{
		next();
		buff.put(c);
	}

	if (l == 'u' || l == 'U' || l == 'l' || l == 'L')
	{
		next();
		buff.put(c);
	}
}

void cTokenIstream::numero_ottale()
{
	buff.put(c);

	while (isdigit(l))
	{
		if (l >= '8')
		{
			throw ("bad formed octal number");
			clear(rdstate() | ios::badbit);
			return;
		}
		next();
		buff.put(c);
	}

	if (l == 'u' || l == 'U' || l == 'l' || l == 'L')
	{
		next();
		buff.put(c);
	}
}


void cTokenIstream::numero_intero_o_double()
{
	buff.put(c);
	while (isdigit(l))
	{
		next();
		buff.put(c);
	}

	if (l == '.')
	{
		do
		{
			next();
			buff.put(c);
		} while (isdigit(l));
	}

	if (l == 'e' || l == 'E')
	{
		next();
		buff.put(c);

		if (l == '+' || l == '-')
		{
			next();
			buff.put(c);
		}

		if (! isdigit(l))
		{
			throw ("bad formed double number");
			clear(rdstate() | ios::badbit);
			return;
		}

		do
		{
			next();
			buff.put(c);
		} while (isdigit(l));

		if (l == 'f' || l == 'F')
		{
			// numero reale tipo float 
			next();
			buff.put(c);
		}
	}
}

void cTokenIstream::numero_double()
{
	numero_intero_o_double();
}

void cTokenIstream::commento_c()
{
	buff.put(c);		// metto / 
	next();
	buff.put(c);		// metto * 

	next();

	while (!(c == '*' && l == '/'))
	{
		if (c == EOF)
		{
			throw ("eof in /* */ comment");
			clear(rdstate() | ios::badbit);
			return;
		}
		else
		if (c == '\n')
			++linenu;
		buff.put(c);
		next();
	}

	buff.put(c);		// metto * 
	next();
	buff.put(c);		// metto / 

	return;
}

void cTokenIstream::commento_cpp()
{
	buff.put(c);		// metto il primo / 
	next();
	buff.put(c);		// metto il secondo / 

	while (l != '\n' && l != EOF)
	{
		next();
		buff.put(c);
	}
}

void cTokenIstream::carattere()
{
	buff.put(c);		// metto il primo ' 

	if (l != '\\')
	{
		// costante carattere del tipo 'x' 
		next();
		buff.put(c);

	}
	else
	{
		next();		// c lo salva carattere_backslash 
		carattere_backslash();
	}

	if (l != '\'')
		goto err;
	next();
	buff.put(c);
	return;
err:
	throw ("invalid constant character");
}

void cTokenIstream::carattere_backslash()
{
	buff.put(c);		// metto il \ 

	if (isdigit(l))
	{
		// costante di tipo ottale tipo \012 
		int n = 1;
		int v;

		next();
		buff.put(c);
		v = c - '0';

		while (isdigit(l))
		{
			if (l >= '8')
				goto err;
			next();
			buff.put(c);
			v = v * 8 + c - '0';
			n++;

		}
		if (n > 3 || v > 255)
			goto err;
	}
	else
	{
		// costante del tipo \n 
		next();
		buff.put(c);
	}
	return;

err:
	throw ("invalid constant character");
}

void cTokenIstream::stringa()
{
	buff.put(c);		// metto il primo " 

	while (l != '"' && l != EOF && l != '\n')
	{
		if (l != '\\')
		{
			next();
			buff.put(c);
		}
		else
		{
			next();
			if (l == '\n')
			{
				// non devo memorizzare niente 
				++linenu;
				next();
			}
			else
			{
				// devo salvare c il carattere_backslash 
				carattere_backslash();
			}
		}
	}

	if (l == EOF)
		throw ("Eof in string");
	if (l == '\n')
		throw ("Return in string");

	next();		// metto il secondo " 
	buff.put(c);
}


cTokenIstream & cTokenIstream::operator >> (cToken & tk)
{
	unsigned currentlinenu;

GoAgain:
	buff.reset();		// buff e` statico --> devo usarlo
				// solo qui e non fargli memorizzare niente
				// della precedente chiamata
	next();
	currentlinenu = linenu;

	if (c == EOF)
	{
		state = None;
		linenu = 0;
		clear(rdstate() | ios::eofbit | ios::failbit);
		return *this;
	}
	else
	if (isalpha(c) || c == '_')
	{
		state = None;
		identificatore();
		const char *pt = buff;

		// guardo se e` una parola chiave
		cToken *ptk = tb.Lookup(pt);
		if (ptk)
		{
			tk = *ptk;
			tk.linenu = currentlinenu;
		}
		else
		{
			if (tk.token)
				Delete (char *) tk.token;

			tk.token = strdup(pt);
			tk.tt = cToken::Iden;
			tk.linenu = currentlinenu;
		}
		return *this;
	}
	else
	if (c == ' ' || c == '\t')
	{
		if (state != Cr)
			state = None;

		while (l == ' ' || l == '\t')
			next();
		goto GoAgain;
	}
	else
	if (c == '\n')
	{
		state = Cr;
		linenu++;
		goto GoAgain;
	}
	else
	if (c == '0' && (l == 'x' || l == 'X'))
	{
		state = None;
		numero_esa();
	}
	else
	if (c == '0' && !(l == '.' || l == 'e' || l == 'E'))
	{
		state = None;
		numero_ottale();
	}
	else
	if (isdigit(c))
	{
		state = None;
		numero_intero_o_double();
	}
	else
	if (c == '.' && isdigit(l))
	{
		state = None;
		numero_double();
	}
	else
	if (c == '/' && l == '*')
	{
		state = None;
		commento_c();
	}
	else
	if (c == '/' && l == '/')
	{
		state = None;
		commento_cpp();
	}
	else
	if (c == '\'')
	{
		state = None;
		carattere();
	}
	else
	if (c == '"')
	{
		state = None;
		stringa();
	}
	else
	if (c == '!')
	{
		// possibili ! !=
		state = None;
		buff.put(c);
		if (l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '%')
	{
		// possibili % %=
		state = None;
		buff.put(c);
		if (l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '&')
	{
		// possibili & && &=
		state = None;
		buff.put(c);
		if (l == '&' || l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '(' || c == ')' ||
	    c == '[' || c == ']' ||
	    c == '{' || c == '}')
	{
		state = None;
		buff.put(c);
	}
	else
	if (c == '*')
	{
		// possibili * *=
		state = None;
		buff.put(c);
		if (l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '+')
	{
		// possibili + ++ +=
		state = None;
		buff.put(c);
		if (l == '+' || l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == ',')
	{
		// possibili ,
		state = None;
		buff.put(c);
	}
	else
	if (c == '-')
	{
		// possibili - -- -= -> ->*
		state = None;
		buff.put(c);
		if (l == '-' || l == '=' || l == '>')
		{
			next();
			buff.put(c);
			if (c == '>' && l == '*')
			{
				next();
				buff.put(c);
			}
		}
	}
	else
	if (c == '.')
	{
		// possibili . .*
		state = None;
		buff.put(c);
		if (l == '*')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '/')
	{
		// possibili /  /=
		state = None;
		buff.put(c);
		if (l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == ':')
	{
		// possibili:::
		state = None;
		buff.put(c);
		if (l == ':')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '<')
	{
		// possibili < << <<= <=
		state = None;
		buff.put(c);
		if (l == '<')
		{
			next();
			buff.put(c);
			if (l == '=')
			{
				next();
				buff.put(c);
			}
		}
		else
		if (l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '=')
	{
		// possibili = ==
		state = None;
		buff.put(c);
		if (l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '>')
	{
		// possibili > >= >> >>=
		state = None;
		buff.put(c);
		if (l == '=')
		{
			next();
			buff.put(c);
		}
		else
		if (l == '>')
		{
			next();
			buff.put(c);
			if (l == '=')
			{
				next();
				buff.put(c);
			}
		}
	}
	else
	if (c == '?' || c == '~' || c == ';')
	{
		// possibili ? ~;
		state = None;
		buff.put(c);
	}
	else
	if (c == '^')
	{
		// possibili ^ ^=
		state = None;
		buff.put(c);
		if (l == '=')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '|')
	{
		// possibili | |= ||
		state = None;
		buff.put(c);
		if (l == '=' || l == '|')
		{
			next();
			buff.put(c);
		}
	}
	else
	if (c == '#' && state == Cr)
	{
		// direttiva preprocessore
		state = None;
		buff.put(c);
		forever
		{
			if (c != '\\' && l == '\n')
				break;
			if (l == EOF)
				break;
			next();
			buff.put(c);
		}
	}
#if 0
	// gli operatori # e ## sono permessi solo nelle definizioni di macro
	else
	if (c == '#' && l == '#')
	{
		// concatenazione token
		buff.put(c);
		next();
		buff.put(c);
	}
	else
	if (c == '#')
	{
		// string-ize operator
		buff.put(c);
	}
#endif
	else
	{
		state = None;
		clear(rdstate() | ios::failbit);
		throw ("unknown C token");
		return *this;
	}

	if (tk.token)
		Delete (char *) tk.token;

	tk.token = strdup(buff);
	tk.tt = cToken::None;
	tk.linenu = currentlinenu;

	cToken *ptk = tb.Lookup(tk.token);
	if (ptk)
	{
		tk = *ptk;
		tk.linenu = currentlinenu;
	}
	
	return *this;
}

#if 0

void main(int ac, char *av[])
{
	cToken tk;
	ifstream fin;
	cTokenIstream cstream;

	if (ac == 2)
	{
		fin.open(av[1]);
		if (!fin)
			Error("file not found %s", av[1]);
		cstream = fin;
	}
	else
		cstream = cin;

	while (cstream >> tk)
		cout << tk << '\n';
}

#endif
