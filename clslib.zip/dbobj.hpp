#ifndef __DBOBJ_HPP
#define __DBOBJ_HPP

class aDbObj
{
public:
	void Search(classType, Slist &SlistOut);
	void Search(bool (*)(const Object *, void *), void *pVoid, Slist &SlistOut);
	void Search(classType, bool (*)(const Object *, void *), void *pVoid, Slist &SlistOut);

private:
	friend class Object;

#ifdef __DBOBJ_CPP
public:
#endif

	aDbObj();
	~aDbObj();

	void Add(const void *);
	void Kill(const void *);


	uint         m_unSize;
	const void **m_ppObject;
};

extern aDbObj DbObj;		/* il data base di tutti gli oggetti esistenti */

#endif
