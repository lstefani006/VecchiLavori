#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#include <stdlib.h>

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__EXHANDLE[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__EXHANDLE
#endif

char exception::m_achMsg[500];

const exception *theException = 0;
const exception AllExceptions("AllExcpetions");
const exception OutOfMemory  ("Out of memory");
const exception FileNotFound ("File not found");
const exception Eof          ("End of file");

const char * exception::Msg() const
{
	strcpy(m_achMsg, m_pchMsg);
	return m_achMsg;
}



ExHandle   *ExHandle::Top    = 0;
const char *ExHandle::ExFile = 0;
int         ExHandle::ExLine = 0;

ExHandle::ExHandle()
{
	theException = 0;
	Previous     = Top;
	Top          = this;
	flag         = OnTry;
	bFinally     = 0;
}

ExHandle::~ExHandle()
{
	Assert(Top == this);	/* wrong try block */

	Top = Previous;			/* dealloco questo blocco di try */
	
	/* Controllo se e` stata acchiappata un'eccezione nel blocco appena deallocato */
	/* se no faccio throw nel blocco di try immediatamente annidato */
	if (flag == OnThrow)	/* nessun catch */
		Throw(ExFile, ExLine, theException);
}


void ExHandle::Throw(const char *file, int line, const exception *ex)
{
	
	ExFile = file;
	ExLine = line;
	
	theException = ex;

	if (Top == 0)
		Terminate(file, line, ex);

	if (Top->flag == OnCatch ||
		Top->flag == OnTry && Top->bFinally)
	{
		// ho <ri>lanciato un'eccezione dentro un blocco di catch o di finally
        // dealloco il blocco di try piu` annidato e poi faccio longjmp
		Top = Top->Previous;
        if (Top == 0)
			Terminate(file, line, ex);
	}

	longjmp(Top->jb, int(OnThrow));
}

void ExHandle::Throw(const char *file, int line, const exception &ex)
{
	Throw(file, line, &ex);
}


void ExHandle::Terminate(const char *file, int line, const exception *ex)
{
	if (file == 0)
		file = "Unknown";
	__file = file;
	__line = line;
	__error("- Unhandled exception: %s", ex->Msg());
}

