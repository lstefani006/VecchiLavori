#include <RegExp.hpp>
#include <regexp\regexp.h>


exception RegExpr::SyntaxError("Syntax error in regular expression");


RegExpr::RegExpr(const char *pchRegExpr)
{
	m_ptRegExpr = regcomp(pchRegExpr);
	if (m_ptRegExpr == 0)
		throw(SyntaxError);
}


RegExpr::~RegExpr()
{
	regfree(m_ptRegExpr);
}


bool RegExpr::Match(const char *pchString) const
{
	int r = regexec(m_ptRegExpr, pchString);

	if (r == 0)
		return false;
	else
		return true;
}


void RegExpr::SubMatch(int nSub, const char *&rpchStart, const char *&rpchEnd) const
{
	Assert(m_ptRegExpr);
	Assert(nSub < NSUBEXP);

	rpchStart = m_ptRegExpr->startp[nSub];
	rpchEnd =   m_ptRegExpr->endp[nSub];
}


void RegExpr::Substitute(const char *pchSub, char *pchDest) const
{
	regsub(m_ptRegExpr, pchSub, pchDest);
}


RegExpr rgFileName("[-_a-zA-Z0-9]+");
