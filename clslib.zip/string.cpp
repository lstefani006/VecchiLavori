#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#include <stdarg.h>

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__STRING[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__STRING
#endif


ImplementObject(String, Object);
ImplementPersistent(String);

String::String()
{
	m_ptChar = New char [1];
	m_ptChar[0] = 0;
}

String::String(size_t sz)
{
	if (sz <= 0)
		sz = 1;
	m_ptChar = New char [sz];
	m_ptChar[0] = 0;
}

String::String(const char *s)
{
	size_t sz = (s == 0) ? 1 : strlen(s) + 1;
	m_ptChar = New char [sz] ;
	m_ptChar[0] = 0;
	if (s != 0)
		strcpy(m_ptChar, s);
}

String::String(const String &s)
{
	m_ptChar = New char [s.Len() + 1];
	strcpy(m_ptChar, s.m_ptChar);
}

String::String(int n, const char *fmt)
{
	char b[100];
    sprintf(b, fmt, n);
	m_ptChar = New char [strlen(b) + 1] ;
	strcpy(m_ptChar, b);
}

String::~String()
{
	Delete m_ptChar;
	m_ptChar = 0;
}

bool String::isEqual(const Object &obj) const
{
	if (obj.isA() != typeid(String))
		return false;
	return bool(strcmp(m_ptChar, ((String *) &obj)->m_ptChar) == 0);
}

/*
void String::printOn(ostream &s) const 
{
	s << m_ptChar;
}
*/

String & String::operator = (const String &s)
{
	if (s.m_ptChar == m_ptChar)
		return *this;
	Delete m_ptChar;
	m_ptChar = New char [s.Len() + 1];
	strcpy(m_ptChar, s.m_ptChar);
	return *this;
}

String & String::operator = (const char *s)
{
	if (m_ptChar == s)
		return *this;
	Delete m_ptChar;
	m_ptChar = New char[strlen(s) + 1];
	strcpy(m_ptChar, s);
	return *this;
}

int operator == (const String &a, const String &b)
{
	return strcmp(a.m_ptChar, b.m_ptChar) == 0;
}
int operator == (const String &a, const char *b)
{
	return strcmp(a.m_ptChar, b) == 0;
}
int operator == (const char *a, const String &b)
{
	return strcmp(a, b.m_ptChar) == 0;
}

int operator != (const String &a, const String &b)
{
	return strcmp(a.m_ptChar, b.m_ptChar) != 0;
}
int operator != (const String &a, const char *b)
{
	return strcmp(a.m_ptChar, b) != 0;
}
int operator != (const char *a, const String &b)
{
	return strcmp(a, b.m_ptChar) != 0;
}

int operator >  (const String &a, const String &b)
{
	return strcmp(a.m_ptChar, b.m_ptChar) > 0;
}
int operator > (const String &a, const char *b)
{
	return strcmp(a.m_ptChar, b) > 0;
}
int operator > (const char *a, const String &b)
{
	return strcmp(a, b.m_ptChar) > 0;
}

int operator <  (const String &a, const String &b)
{
	return strcmp(a.m_ptChar, b.m_ptChar) < 0;
}
int operator < (const String &a, const char *b)
{
	return strcmp(a.m_ptChar, b) < 0;
}
int operator < (const char *a, const String &b)
{
	return strcmp(a, b.m_ptChar) < 0;
}

int operator >= (const String &a, const String &b)
{
	return strcmp(a.m_ptChar, b.m_ptChar) >= 0;
}
int operator >= (const String &a, const char *b)
{
	return strcmp(a.m_ptChar, b) >= 0;
}
int operator >= (const char *a, const String &b)
{
	return strcmp(a, b.m_ptChar) >= 0;
}

int operator <= (const String &a, const String &b)
{
	return strcmp(a.m_ptChar, b.m_ptChar) <= 0;
}
int operator <= (const String &a, const char *b)
{
	return strcmp(a.m_ptChar, b) <= 0;
}
int operator <= (const char *a, const String &b)
{
	return strcmp(a, b.m_ptChar) <= 0;
}

String operator + (const String &a, const String &b)
{
	String s(a.Len() + b.Len() + 1);
	strcpy(s.m_ptChar, a.m_ptChar) ;
	strcat(s.m_ptChar, b.m_ptChar) ;
	return s ;
}

String operator + (const String &a, const char *pch)
{
	String s(a.Len() + strlen(pch) + 1);
	strcpy(s.m_ptChar, a.m_ptChar) ;
	strcat(s.m_ptChar, pch) ;
	return s ;
}


void String::operator += (const char *pch)
{
	char *pchNew = New char [Len() + strlen(pch) + 1];
	strcpy(pchNew, m_ptChar);
	strcat(pchNew, pch);

	Delete m_ptChar;
	m_ptChar = pchNew;
}

void String::operator += (const String &a)
{
	operator += (a.m_ptChar);
}

void String::Lower()
{
#ifdef WINDOWS
	AnsiLower(m_ptChar);
#else
	strlwr(m_ptChar);
#endif
}

void String::Upper()
{
#ifdef WINDOWS
	AnsiUpper(m_ptChar);
#else
	strupr(m_ptChar);
#endif
}


String Fmt(const char *pcFmt, ...)
{
	char *pc = New char [2048];

	va_list argptr;
	va_start(argptr, pcFmt);
	vsprintf(pc, pcFmt, argptr);
	va_end(argptr);

	String str(pc);

	Delete pc;

	 return str;
}

String operator + (const char *pch, const String &b)
{
	String s(strlen(pch) + b.Len() + 1);
	strcpy(s.m_ptChar, pch) ;
	strcat(s.m_ptChar, b.m_ptChar) ;
	return s ;
}


String String::Sub(int a, int b) const
{
	if (b == -1)
		b = a;

	int len = Len();
	Assert(a >= 0 && a < len);
	Assert(b >= 0 && b < len);
	Assert(a <= b);

	String r(b - a + 2);
	strncpy(r.m_ptChar, m_ptChar + a, b - a + 1);
	r.m_ptChar[b - a] = 0;

	return r;
}

/*****************************************************************/


void String::Serialize(Persistent &p)
{
	Object::Serialize(p);

	if (p.Dir() == Persistent::Out)
	{
		uint un = Len();
		if (un < 0xff)
		{
			uchar uch = (uchar)un;
			::Serialize(p, uch);
		}
		else
		{
			uchar uch = 0xff;
			::Serialize(p, uch);
			::Serialize(p, un);
		}
		if (un > 0u)
			p.Write(m_ptChar, un);
	}
	else
	{
		uint un;
		uchar uch;
		::Serialize(p, uch);

		if (uch == 0xff)
			::Serialize(p, un);
		else
			un = uch;

		Delete m_ptChar;
		m_ptChar = New char [un + 1];
		if (un > 0)
			p.Read(m_ptChar, un);
		m_ptChar[un] = 0;
	}
}


//////////////////////////////////////////////////////////////

const char   acEmpty[] = "";
const String strEmpty(acEmpty);


String operator || (const String &a, const String &b)
{
	if (a.Len() != 0)
		return a;
	else
		return b;
}
