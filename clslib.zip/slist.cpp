#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__SLIST[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__SLIST
#endif

ImplementObject(Slist, Object);
ImplementPersistent(Slist);

inline Slist::slink::slink(Object & a)
{
	e = &a;
	next = 0;
}

Slist::Slist()
{
	last = 0;
}

Slist::Slist(Object & a)
{
	a.IncOwners();
	last = New slink(a);
	last->next = last;
}

Slist::Slist(const Slist &s)
{
	last = 0;

	Iterator it(s);
	Object *ptObj;

	while ((ptObj = (Object *)it()) != 0)
		AddTail(*ptObj);
}

Slist::~Slist()
{
	Clear();
}

void Slist::Clear()
{
	slink * l = last;
	if (l == 0)
		return;
	do
	{
		slink * ll = l;
		l = l->next;
		ll->e->DecOwners(ll->e);
		Delete ll;
	} while (l != last);
	last = 0;            // put back in initial state
}

void Slist::AddHead(Object *a)
{
	AddHead(*a);
}

void Slist::AddTail(Object *a)
{
	AddTail(*a);
}

void Slist::AddHead(Object & a)
{
	a.IncOwners();
	slink * t = New slink(a);
	if (last)
	{         // list already exists
		t->next = last->next;
		last->next = t; // a becomes New head of list
	}
	else
	{
		last = t;       // New first item
		last->next = last;
	}
}


void Slist::AddTail(Object & a)
{
	a.IncOwners();
	slink * t = New slink(a);
	if (last)
	{
		t->next = last->next; // put a at head of list
		last = last->next = t;// then move tail pointer
	}
	else
	{
		last = t;       // New first item
		last->next = last;
	}
}

Object * Slist::GetHead()
{
	if (last == 0)
		return 0;
	slink * f = last->next;
	Object * r = f->e;
	if (f == last)
		last = 0;
	else
		last->next = f->next;
	Delete f;
	r->DecOwners();
	return r;
}

Object * Slist::Remove(const Object *ptObj)
{
	if (last == 0)
	{
    	// lista vuota
		return 0;
    }

	if (last->next == last)
	{
		// un solo elemento nella lista
		if (last->e == ptObj)
		{
			Delete last;
			last = 0;

			ptObj->DecOwners();
        	return (Object *)ptObj;
		}
		else
        	return 0;
	}

	slink *pt = last;

	do
	{
		if (pt->next->e == ptObj)
		{
			slink *s = pt->next;
			pt->next = pt->next->next;

			if (last == s)
            	last = pt;

			Delete s;
        	
        	ptObj->DecOwners();
			return (Object *)ptObj;
		}
		pt = pt->next;

	}
	while (pt != last);

	return 0;
}


const Object * Slist::Search(const Object &a) const
{
	Iterator it(this);
	const Object *b;
	while ((b = it()) != NULL)
		if (&a == b)
			return b;
	return 0;
}

const Object * Slist::Search(bool (*ptTest)(const Object *, void *), void *pVoid, int Ignore) const
{
	Iterator it(this);
	const Object *b;

	while ((b = it()) != 0)
		if (ptTest(b, pVoid) == true)
			if (Ignore == 0)
				return b;
			else
				Ignore--;
	return 0;
}





size_t Slist::nOfItems() const
{
	size_t n = 0;
	Iterator it(this);

	while (it())
		++n;
	return n;
}

Slist & Slist::operator = (const Slist &s)
{
	if (this == &s)
		return *this;

	Clear();
	
	Iterator it(s);
	Object *ptObj;

	while ((ptObj = (Object *)it()) != 0)
		AddTail(*ptObj);
	return *this;
}

/////////////////////////////////////////////////////////////

bool Slist::isEqual(const Object & obj) const
{
	if (obj.isA() != typeid(Slist))
		return false;
	
	Iterator ita((Slist &) obj);
	Iterator itb(this);

	forever
	{
		const Object * a = ita();
		const Object * b = itb();

		if (a == 0 && b == 0)
			return true;

		if (a == 0 || b == 0)
			return false;

		if (a != b)
			return false;
	}
}

/*
void Slist::printOn(ostream & s) const
{
	const Object * pt;
	Iterator it(this);

	s << "Slist {\n";
	while ((pt = it()) != 0)
		s << '\t' << *pt << '\n';
	s << "}\n";
}
*/

//******************************************************************

class SlistIterator : public IteratorData
{
public:
	SlistIterator(const Slist *);
	virtual ~SlistIterator() {}
	virtual const Object * GetNext();
private:
	Slist::slink * ce;
	const Slist * cs;
};

SlistIterator::SlistIterator(const Slist * s)
{
	cs = s;
	ce = 0;
}

const Object * SlistIterator::GetNext()
{
	if (cs->last == 0)
		return 0;
	if (ce == 0)
	{
		ce = cs->last->next;
		return ce->e;
	}
	else if (ce == cs->last)
	{
		ce = 0;
		return 0;
	}
	else
	{
		ce = ce->next;
		return ce->e;
	}
}


IteratorData * Slist::InitIterator() const
{
	return New SlistIterator(this);
}


//***************************************************************


void Slist::Serialize(Persistent &p)
{
	Assert(this);

	int len;
	
	Object::Serialize(p);

	if (p.Dir() == Persistent::Out)
	{
		len = nOfItems();
		::Serialize(p, len);

		Object *pt;
		Iterator it(this);

		while ((pt = (Object *) it()) != NULL)
			::Serialize(p, pt);
	}
	else
	{
		Clear();
		::Serialize(p, len);
		for (int i = 0; i < len; i++)
		{
			Object *pt = NULL;
			::Serialize(p, pt);
			AddTail(*pt);
		}
	}
}

