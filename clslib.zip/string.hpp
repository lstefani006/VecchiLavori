#ifndef __STRING_HPP
#define __STRING_HPP

#ifndef __OBJECT_HPP
#include <Object.hpp>
#endif
#include <string.h>

class String : public Object
{
public:
	DeclareObject(String);
	DeclarePersistent(String);

	String();
	String(const char *);
	String(const String &);
	String(int n, const char *fmt);

	~String();

	String & operator = (const String &);
	String & operator = (const char *);

	bool isEqual(const Object &) const;
	
	char & operator [] (size_t i) { return m_ptChar[i]; }
	operator const char *() const { return m_ptChar; }
	size_t Len() const { return strlen(m_ptChar); }
    bool isEmpty() const { return bool(strlen(m_ptChar) == 0); }

	void Lower();
	void Upper();

	friend int operator == (const String &, const String &);
	friend int operator == (const String &, const char *);
	friend int operator == (const char *, const String &);
	
	friend int operator != (const String &, const String &);
	friend int operator != (const String &, const char *);
	friend int operator != (const char *, const String &);

	friend int operator >  (const String &, const String &);
	friend int operator >  (const String &, const char *);
	friend int operator >  (const char *, const String &);

	friend int operator <  (const String &, const String &);
	friend int operator <  (const String &, const char *);
	friend int operator <  (const char *, const String &);

	friend int operator >= (const String &, const String &);
	friend int operator >= (const String &, const char *);
	friend int operator >= (const char *, const String &);

	friend int operator <= (const String &, const String &);
	friend int operator <= (const String &, const char *);
	friend int operator <= (const char *, const String &);
	
	friend String operator + (const String &, const String &);
	friend String operator + (const String &, const char *);
	friend String operator + (const char *, const String &);

	void operator += (const String &);
	void operator += (const char *);

	String Sub(int a, int b = -1) const;

protected:
	char *m_ptChar;
	
private:
	String(size_t);
};

String Fmt(const char *pcFmt, ...);		/* come in printf */

extern const char   acEmpty[];
extern const String strEmpty;


/*
 * ritorna la stringa "a" se "a" non e` vuota,
 * altrimenti ritorna "b"
 */
String operator || (const String &a, const String &b);

#endif
