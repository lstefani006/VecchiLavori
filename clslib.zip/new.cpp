#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#include <stddef.h>
#include <new.h>

#ifdef WINDOWS
#include <windowsx.h>
#endif

#if defined(MALLOC) || !defined(WINDOWS)
#include <stdlib.h>
#endif

/*
#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__NEW[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__NEW
#endif
*/


#ifdef DEBUGNEW
const char *__new_file = 0;
int __new_line = 0;
// __new_flag e` true se sto chiamando delete con fName line ecc
int __new_flag = 0;
#endif

//////////////////////////////////////////////////////////////////////
// funzioni per la gesttione della memoria. Interfaccia indipendente
// tra MSDOS e WINDOWS
//
inline static void *AllocMem(size_t sz)
{
#if defined(WINDOWS) && !defined(MALLOC)
	void *pt = GlobalAllocPtr(GHND, sz);
#else
	void *pt = malloc(sz);
#endif
	
	if (pt == 0)
		throw (OutOfMemory);

	return pt;
}

inline static void FreeMem(void *pt)
{
	if (pt == 0)
    	return;

#if defined(WINDOWS) && !defined(MALLOC)
	GlobalFreePtr(pt);
#else
	free(pt);
#endif
}

inline static void *ReAllocMem(void *pt, size_t sz)
{
#if defined(WINDOWS) && !defined(MALLOC)
	pt = GlobalReAllocPtr(pt, sz, GMEM_ZEROINIT);
#else
	pt = realloc(pt, sz);
#endif
	if (pt == 0)
		throw (OutOfMemory);
	return pt;
}

/////////////////////////////////////////////////////////////////////
// Funzioni standard C++
//
void *operator new (size_t sz)
{
	return AllocMem(sz);
}

#ifndef DEBUGNEW
void operator delete (void *pt)
{
	FreeMem(pt);
}

// ReNew puo` reallocare un blocco ottenuto con New
//
void *__new_ReNew(void *pt, size_t sz)
{
	return ReAllocMem(pt, sz);
}
#endif

/////////////////////////////////////////////////////////////////////
// Funzioni per controllare l'allocazione della memoria:
//	memorizza la posizione nel sorgente della chiamata New
//	e controlla che il blocco deallocato con Delete sia stato
//	allocato con New
#ifdef DEBUGNEW

struct MemInfo
{
	const char *fileName;
	int Line;
	size_t sz;
	const void *Block;
	int isObject;

	static MemInfo *Last;
	MemInfo *Previous;

	MemInfo(const void *pt, const char *fName, int nLine, int szBlock, int isObj);
	~MemInfo();

	static MemInfo * isPtHeap(const void *);
	static void Dump();
};

MemInfo *MemInfo::Last = 0;

MemInfo::MemInfo(const void *pt, const char *fName, int nLine, int szBlock, int isObj)
{
	Previous = Last;
	Last = this;
	
	fileName = fName;
	Line = nLine;
	sz = szBlock;
	Block = pt;
	isObject = isObj;
}

MemInfo::~MemInfo()
{
	MemInfo *ptMem = Last;

	if (ptMem == 0)
		Error("Last == 0");
	if (ptMem == this)
	{
		Last = Previous;
		return;
	}

	while (ptMem->Previous)
	{
		if (ptMem->Previous == this)
		{
			ptMem->Previous = ptMem->Previous->Previous;
			return;
		}
		ptMem = ptMem->Previous;
	}

	Error("MemInfo not found in list");
}

void Dump() { MemInfo::Dump(); }

void MemInfo::Dump()
{
	MemInfo *ptMem = Last;

	while (ptMem)
	{
		ptMem = ptMem->Previous;
	}
}

MemInfo * MemInfo::isPtHeap(const void *pt)
{
	MemInfo *ptMem = Last;

	while(ptMem)
	{
		if (ptMem->Block == pt)
        	return ptMem;
		ptMem = ptMem->Previous;
	}
	return 0;
}


///////////////////////////////////////////////////////////////////
// funzioni stardard C++ con gestione delle informazioni di debug
//
void *operator new (size_t sz, const char *fName, int line, int isObj)
{
	void *pt = AllocMem(sz);
	new MemInfo(pt, fName, line, sz, isObj);
	return pt;
}

void operator delete (void *pt)
{
	if (pt == 0)
		return;
		
	if (__new_flag)
    {
		__new_flag = 0;

		MemInfo *ptMem = MemInfo::Last;

		// scandisco la lista dei blocchi allocati per trovare questo pt
		while (ptMem)
		{
			if (ptMem->Block == pt)
        	{
				delete ptMem;		// trovato
	            break;
    	    }
			ptMem = ptMem->Previous;	// cerco il prossimo
		}

		if (ptMem == 0)
			__error("Trying to deallocate wrong heap area: %Fp", pt);
	}
	
	FreeMem(pt);
}


void *__new_ReNew(const char *file, int line, void *pt, size_t sz)
{
	MemInfo *ptMem = MemInfo::isPtHeap(pt);
	if (ptMem == 0)
		__error("%s(%d) - trying to ReNew a wrong heap area: %Fp", file, line, pt);

	if (ptMem->isObject)
		__error("trying to ReNew an Object heap area");
		 
	void *ptRealloc = ReAllocMem(pt, sz);
	ptMem->Block = ptRealloc;
	ptMem->sz = sz;
	ptMem->fileName = file;
    ptMem->Line = line;
    return ptRealloc;
}
#endif
