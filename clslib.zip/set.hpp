#ifndef __SET_HPP
#define __SET_HPP

#ifndef __SLIST_HPP
#include <Slist.hpp>
#endif

class Set : public Slist
{
public:
	DeclareObject(Set);
	DeclarePersistent(Set);
	
	Set() {}
	Set(const Set &r) : Slist(r) {}
	~Set() {}
	
	void Put(Object &);            // add item in set
	void Put(Object *);            // add item in set

	Object *Get();                 // return and remove item in set
	const Object * Search(const Object &) const;    // search for the Obj
	const Object * Search(bool (*ptTest)(const Object *pObj, void *pVoid), void *pVoid, int Ignore = 0) const;

	virtual bool isEqual(const Object &) const;

	friend Set & operator + (const Set &, const Set &); // union
	bool isEmpty() { return bool(nOfItems() == 0); }

private:
	void AddHead(Object &);           // add at head of list
	void AddTail(Object &);           // add at tail of list
	Object * GetHead();               // return and remove head of list
};

#endif
