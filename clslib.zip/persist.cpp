#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__PERSIST[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__PERSIST
#endif


char WrongObject[] = "Wrong type of Object";

exception Persistent_OpenError("Open error");
exception Persistent_WriteError("Write error");
exception Persistent_ParsingError("Parsing error");

const char *Persistent::m_ptError = 0;
const ulong Persistent::m_ulVersion = 0ul;

Persistent::Persistent(const char *fName, Type InOut, ulong ulUserFlag)
{
	m_ptError = 0;

	m_file = fopen(fName, InOut == In ? "rb" : "wb");
	if (m_file == 0)
		throw (Persistent_OpenError);

	m_Direzione = InOut;

    // lista dei nomi delle classi che sono stati salvati/caricati
    m_szRefObj = 128;
	m_ptRefObj = New Object *[m_szRefObj];
    m_topRefObj = 0;

	// lista degli oggetti condivisi
	m_szClassName = 256;
	m_ptClassName = New char *[m_szClassName];
	m_topClassName = 0;


	// controllo dell'header del file
	char *ptHeader = "Leo (C)";
	if (m_Direzione == Out)
		Write(ptHeader, strlen(ptHeader));
	else
	{
		char b[20];
		Read(b, strlen(ptHeader));
		if (strncmp(ptHeader, b, strlen(ptHeader)) != 0)
		{
			Persistent::m_ptError = "wrong \"type\"";
			throw (Persistent_ParsingError);
		}
	}

	// controllo della versione
	m_ulReadVersion = m_ulVersion;
	::Serialize(*this, m_ulReadVersion);
	m_ulUserFlag = ulUserFlag;
	::Serialize(*this, m_ulUserFlag);
}

Persistent::~Persistent()
{
	if (m_file)
    	fclose(m_file);
	Delete m_ptRefObj;
	Delete m_ptClassName;
}

void Persistent::Write(const void *ptBuff, size_t sz)
{
	int nr = fwrite(ptBuff, sz, 1, m_file);
	if (nr < 1)
    	throw (Persistent_WriteError);
}

void Persistent::Read(void *ptBuff, size_t sz)
{
	int nr = fread(ptBuff, sz, 1, m_file);
    if (nr < 1)
    {
		Persistent::m_ptError = "EOF reached";
		throw (Persistent_ParsingError);
    }
}



///////////////////////////////////////////////////////////////////

void Serialize(Persistent &p, Object *&prObj)
{
	if (p.Dir() == Persistent::Out)
		Write(p, prObj);
	else
		Read(p, prObj);
}

void Serialize(Persistent &p, unsigned char *pt, int sz)
{
	if (p.Dir() == Persistent::Out)
		p.Write(pt, sizeof (*pt) * sz);
	else
		p.Read(pt, sizeof (*pt) * sz);
}

void Serialize(Persistent &p, char *pt, int sz)
{
	if (p.Dir() == Persistent::Out)
		p.Write(pt, sizeof (*pt) * sz);
	else
		p.Read(pt, sizeof (*pt) * sz);
}

void Serialize(Persistent &p, int *pt, int sz)
{
	if (p.Dir() == Persistent::Out)
		p.Write(pt, sizeof (*pt) * sz);
	else
		p.Read(pt, sizeof (*pt) * sz);
}

void Serialize(Persistent &p, unsigned int *pt, int sz)
{
	if (p.Dir() == Persistent::Out)
		p.Write(pt, sizeof (*pt) * sz);
	else
		p.Read(pt, sizeof (*pt) * sz);
}

void Serialize(Persistent &p, long *pt, int sz)
{
	if (p.Dir() == Persistent::Out)
		p.Write(pt, sizeof (*pt) * sz);
	else
		p.Read(pt, sizeof (*pt) * sz);
}

void Serialize(Persistent &p, unsigned long *pt, int sz)
{
	if (p.Dir() == Persistent::Out)
		p.Write(pt, sizeof (*pt) * sz);
	else
		p.Read(pt, sizeof (*pt) * sz);
}

void Serialize(Persistent &p, float *pt, int sz)
{
	if (p.Dir() == Persistent::Out)
		p.Write(pt, sizeof (*pt) * sz);
	else
		p.Read(pt, sizeof (*pt) * sz);
}

void Serialize(Persistent &p, double *pt, int sz)
{
	if (p.Dir() == Persistent::Out)
		p.Write(pt, sizeof (*pt) * sz);
	else
		p.Read(pt, sizeof (*pt) * sz);
}

void Serialize(Persistent &p, bool *pt, int sz)
{
	for (int i = 0; i < sz; i++) 
	{
		if (p.Dir() == Persistent::Out)
		{
			char c = (char) pt[i];
			p.Write(&c, sizeof(c));
		}
		else
		{
			char c;
			p.Read(&c, sizeof(c));
			pt[i] = (bool) c;
		}
	}
}

/////////////////////////////////////////////////////////////////////

void Serialize(Persistent &p, unsigned char &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, char &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, int &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, unsigned int &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, long &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, unsigned long &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, float &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, double &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, bool &a)
{
	Serialize(p, &a, 1);
}

void Serialize(Persistent &p, char *pt)
{
	do
		Serialize(p, *pt);
	while (*pt++);
}

/////////////////////////////////////////////////////////////////////

struct PersistentTable
{
	const char *className;
	Object * (*classCstr)();

	PersistentTable *Previous;
	static PersistentTable *Last;

	PersistentTable(const char *, Object * (*)());

	static PersistentTable * Search(const char *Name);
};

PersistentTable *PersistentTable::Last = 0;

PersistentTable::PersistentTable(const char *Name,
								 Object * (*Cstr)())
{
	if (Search(Name))
		Error("class \"%s\" yet registered", Name);
		
	className = Name;
	classCstr = Cstr;

	Previous = Last;
	Last = this;
}

PersistentTable * PersistentTable::Search(const char *Name)
{
	PersistentTable *pt = Last;

	while (pt)
	{
		if (strcmp(pt->className, Name) == 0)
			return pt;
		pt = pt->Previous;
	}
	return 0;
}

RegisterPersistent::RegisterPersistent(
	const typeinfo &t,
	Object * (*classCstr)())
{
	New PersistentTable(t.name(), classCstr);
}

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////

#define nullObject   '0'
#define sharedObject 's'
#define normalObject 'n'

void Write(Persistent &p, const Object *ptObj)
{
	char c;
	
	if (ptObj == 0)
	{
		c = nullObject;
        ::Serialize(p, c);
		return;
	}

	PersistentTable *ptObjectRef = PersistentTable::Search(ptObj->isA().name());
	if (ptObjectRef == 0)
	{
		Persistent::m_ptError = "trying to serialize a non persistent object";
		throw (Persistent_ParsingError);
	}

	if (ptObj->GetOwners() >= 1)
	{
		for (int i = 0; i < p.m_topRefObj; i++)
			if (p.m_ptRefObj[i] == ptObj)
			{
				c = sharedObject;
				::Serialize(p, c);
				::Serialize(p, i);
				return;
			}
	}
	
	if (p.m_topRefObj >= p.m_szRefObj)
	{
		p.m_szRefObj *= 2;
		p.m_ptRefObj = ReNew(Object *, p.m_ptRefObj, p.m_szRefObj);
	}

	c = normalObject;
	::Serialize(p, c);

	for (int i = 0; i < p.m_topClassName; i++)
		if (strcmp(ptObj->isA().name(), p.m_ptClassName[i]) == 0)
			break;

	if (i < p.m_topClassName)
	{
    	c = 0;
		::Serialize(p, c);
		::Serialize(p, i);
    }
	else
	{
    	c = 1;
    	::Serialize(p, c);
		::Serialize(p, (char *) ptObj->isA().name());

		if (p.m_topClassName >= p.m_szClassName)
		{
			p.m_szClassName *= 2;
			p.m_ptClassName = ReNew(char *, p.m_ptClassName, p.m_szClassName);
		}
		p.m_ptClassName[p.m_topClassName++] = (char *) ptObj->isA().name();
	}

	p.m_ptRefObj[p.m_topRefObj++] = (Object *) ptObj;

	((Object *)ptObj)->Serialize(p);
	return;
}

void Read(Persistent &p, Object * &ptObj)
{
	Assert(ptObj == 0);

	char c;
    ::Serialize(p, c);

	if (c == nullObject)
	{
		ptObj = 0;
		return;
	}

	if (c == sharedObject)
	{
		int r;
		::Serialize(p, r);
		if (r < 0 || r >= p.m_topRefObj)
		{
			Persistent::m_ptError = "wrong reference number";
            throw (Persistent_ParsingError);
		}
		ptObj = p.m_ptRefObj[r];
		if (ptObj == 0)
		{
			Persistent::m_ptError = "ptReference == 0";
            throw (Persistent_ParsingError);
		}
		return;
	}

	if (c != normalObject)
	{
    	Persistent::m_ptError = "wrong \"type\"";
		throw (Persistent_ParsingError);
    }

	PersistentTable *ptObjectTable;

	::Serialize(p, c);
	if (c == 0)
	{
		int i;
		::Serialize(p, i);
		ptObjectTable = PersistentTable::Search(p.m_ptClassName[i]);
	}
	else
	{
		char Name[50];
		::Serialize(p, Name);
		ptObjectTable = PersistentTable::Search(Name);

		if (ptObjectTable)
		{
			if (p.m_topClassName >= p.m_szClassName)
			{
				p.m_szClassName *= 2;
				p.m_ptClassName = ReNew(char *, p.m_ptClassName, p.m_szClassName);
			}
			p.m_ptClassName[p.m_topClassName++] = (char *)(ptObjectTable->className);
		}
	}
	
	if (ptObjectTable == 0)
	{
		Persistent::m_ptError = "wrong className";
		throw (Persistent_ParsingError);
	}

	ptObj = (ptObjectTable->classCstr)();		// qui creo l'oggetto
	if (ptObj == 0)
	{
		Persistent::m_ptError = "trying to create an abstract class";
		throw (Persistent_ParsingError);
	}

	if (p.m_topRefObj >= p.m_szRefObj)
	{
		p.m_szRefObj *= 2;
		p.m_ptRefObj = ReNew(Object *, p.m_ptRefObj, p.m_szRefObj);
	}

	p.m_ptRefObj[p.m_topRefObj++] = ptObj;

	bool bOk = true;
	try
	{ 
		ptObj->Serialize(p);				// qui lo inizializzo
	}
	catch(Persistent_ParsingError)
	{
    	bOk = false;
	}
	end_catch;

	if (bOk == false)
    {
		Delete ptObj;						// se succede qualche cosa dealloco la memoria
		ptObj = 0;
		throw(Persistent_ParsingError);
	}
	return;
}
