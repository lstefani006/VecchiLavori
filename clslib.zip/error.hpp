#ifndef __ERROR_HPP
#define __ERROR_HPP

extern const char *__file;
extern int __line;

#define __THIS_FILE__ __FILE__

#define Error __file = __THIS_FILE__, __line = __LINE__, __error
int __error(const char *fmt, ...);

#define Debug __file = __THIS_FILE__, __line = __LINE__, __debug

extern uint CurrentDebugLevel;
int __debug(uint uLevel, const char *pchFmt, ...);

#ifdef DEBUG
extern char far __AssertionFailed[];	// = "Assertion failed \"%s\""
extern const bool bFalse;		// always false
#define Assert(e)													\
	do																\
	{                          										\
		static char far __AssertMsg[] = #e;							\
		if ((e) == 0)							                    \
		{															\
			__file = __THIS_FILE__;									\
			__line = __LINE__;										\
			__error(__AssertionFailed, __AssertMsg);				\
		}															\
    }																\
	while(bFalse)
#else
#define Assert(e) ((void)(e))
#endif


extern void (*ptDebugProc)(const char *, const char *);

#endif
