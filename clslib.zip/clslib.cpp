#define __DBOBJ_CPP		/* per generare il DbObj globale */

#include <ClsLib.hpp>

#include <exhandle.cpp>
#include <new.cpp>
#include <error.cpp>
#include <dbobj.cpp>
#include <object.cpp>
#include <persist.cpp>
#include <flist.cpp>
#include <hash.cpp>
#include <set.cpp>
#include <slist.cpp>
#include <string.cpp>
#include <time.cpp>
#include <parmodif.cpp>
#include <regexp.cpp>
