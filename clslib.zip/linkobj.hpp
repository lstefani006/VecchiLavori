#ifndef __LINKOBJ_HPP
#define __LINKOBJ_HPP

#include <typeinfo.h>

template <class t>
class LinkObj
{
public:																		
	LinkObj() { m_pObj = NULL; }		  
	LinkObj(const LinkObj &r); 						  
	LinkObj(t *pObj);             						  
	 ~LinkObj();                   						  

	void operator = (const LinkObj &r);					  
	void operator = (const t *pObj);							  
																		  
	operator const void * () const   { return m_pObj; }  
	t *&       p()            		 { return m_pObj; }	  
	t *        p() const      		 { return m_pObj; }	  
	t *        operator -> () 		 { return m_pObj; }	  
	const t *  operator -> () const  { return m_pObj; }  
	t *        Release();										  

	friend void Serialize(Persistent &p, LinkObj<t> *&);
																		  
	void Unref()
	{
		if (m_pObj->DecOwners() == 0 && m_pObj->IsOnFreeStore() == true)
			Delete m_pObj;
		m_pObj = NULL;
	}
protected:															  
	t *m_pObj;														  
};

template <class t>
LinkObj<t>::LinkObj(const LinkObj<t> &r) { (m_pObj = r.m_pObj)->IncOwners(); }																			

template <class t>
LinkObj<t>::LinkObj(t *pObj) { (m_pObj = pObj)->IncOwners(); }			

template <class t>
LinkObj<t>::~LinkObj() { Unref(); }

template <class t>
void LinkObj<t>::operator = (const LinkObj<t> &r)			
{																			
	if (&r != this)
	{
		Unref();
		m_pObj = r.m_pObj;
		m_pObj->IncOwners();
	}
}																			

template <class t>
void LinkObj<t>::operator = (const t *pObj)					
{																			
	if (m_pObj != pObj)		
	{										
		Unref();
		m_pObj = (t *)pObj;
		m_pObj->IncOwners();
	}
}																			

template <class t>
t * LinkObj<t>::Release() { m_pObj->DecOwners(); return m_pObj; }

       
template <class t>
void Serialize(Persistent &p, LinkObj<t> &lObj)
{																
	if (p.Dir() == Persistent::Out)								
		Write(p, lObj.p());
	else														
	{															
		Object *ptObj = NULL;
		Read(p, ptObj);
		lObj = dynamic_cast<t *>(ptObj);
		if (lObj == NULL)
		{															
			Delete ptObj;											
			Persistent::m_ptError = WrongObject;                    
			throw (Persistent_ParsingError);						
		}															
	}															
}

#endif // __LINKOBJ_HPP
