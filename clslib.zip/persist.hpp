#ifndef __PERSIST_HPP
#define __PERSIST_HPP

#include <stdio.h>
#ifndef __EXHANDLE_HPP
#include <ExHandle.hpp>
#endif

class Object;

class Persistent
{
public:
	enum Type { In, Out };
	Persistent(const char *, Type, ulong ulUserFlag = 0ul);
	~Persistent();
	
	void Write(const void *, size_t);
	void Read(void *, size_t);

	Type Dir() { return m_Direzione; }

	static const char *m_ptError;
	static const ulong m_ulVersion;		/* la versione attuale */

	ulong m_ulUserFlag;          		/* variabile usabile dall'utente */

	ulong Version() const { return m_ulReadVersion; }

private:
	ulong m_ulReadVersion;
	Type m_Direzione;
	FILE *m_file;

	Object **m_ptRefObj;
	int m_szRefObj;
	int m_topRefObj;

	char **m_ptClassName;
	int m_szClassName;
	int m_topClassName;

	friend void Write(Persistent &, const Object *);
	friend void Read (Persistent &, Object *&);
};

class RegisterPersistent
{
public:
	RegisterPersistent(const typeinfo &, Object * (*)());
};     

extern char WrongObject[];

/////////////////////////////////////////////////////////////////////
#define DeclarePersistent(className)								\
	void Serialize(Persistent &)									\


/////////////////////////////////////////////////////////////////////
#define ImplementAbstractPersistent(className)						\
	static RegisterPersistent className##Reg(				        \
		typeid(className),       									\
		className::StaticCreateObject								\
	);

#define ImplementPersistent(className)								\
	ImplementAbstractPersistent(className)							\
	

/////////////////////////////////////////////////////////////////////

void Serialize(Persistent &p, Object *&);

void Serialize(Persistent &p, unsigned char &uc);
void Serialize(Persistent &p, char &c);
void Serialize(Persistent &p, int &n);
void Serialize(Persistent &p, unsigned int &n);
void Serialize(Persistent &p, long &l);
void Serialize(Persistent &p, unsigned long &ul);
void Serialize(Persistent &p, float &f);
void Serialize(Persistent &p, double &d);
void Serialize(Persistent &p, bool &b);
void Serialize(Persistent &p, char *pt);	// only for 0 terminated strings

void Serialize(Persistent &p, unsigned char *uc, int sz);
void Serialize(Persistent &p, char *c,           int sz);
void Serialize(Persistent &p, int *n,            int sz);
void Serialize(Persistent &p, unsigned int *n,   int sz);
void Serialize(Persistent &p, long *l,           int sz);
void Serialize(Persistent &p, unsigned long *ul, int sz);
void Serialize(Persistent &p, float *f,          int sz);
void Serialize(Persistent &p, double *d,         int sz);
void Serialize(Persistent &p, bool *b,           int sz);


extern exception Persistent_OpenError;
extern exception Persistent_WriteError;
extern exception Persistent_ParsingError;

#endif
