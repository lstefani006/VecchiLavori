#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#include <stdarg.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>

/*
#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__ERROR[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__ERROR
#endif
*/


const char *__file;
int __line;
uint CurrentDebugLevel = 0x0;

const bool bFalse = false;
char  __AssertionFailed[] = "Assertion failed \"%s\"";

void (*ptDebugProc)(const char *, const char *) = 0;

static void writeFile(const char *str)
{
	char *fileName = getenv("CLS_DEBUG");
	if (fileName == 0)
		fileName = "debug.log";
	
	static int yetOpened = 0;
	if (yetOpened == 0)
		unlink(fileName);

	FILE *handle = fopen(fileName, "a");
	if (handle == 0)
		return;
	
	yetOpened = 1;

	fprintf(handle, "%s", str);
	fclose(handle);
}

#ifndef WINDOWS

// Versione per DOS 

int __error(const char *fmt, ...)
{
	va_list argptr;
	char buff[512];
	char *pt = buff;

	va_start(argptr, fmt);
	pt += sprintf(pt, "Error(%s : %d) ", __file, __line);
	pt += vsprintf(pt, fmt, argptr);
	pt += sprintf(pt, "\n");
	va_end(argptr);

	write(2, buff, size_t(pt - buff));
	writeFile(buff);
    writeFile("\n");
	exit(1);
	return 0;
}


int __debug(uint level, const char *fmt, ...)
{
	va_list argptr;
	char buff[512];
	char *pt = buff;

	if (CurrentDebugLevel == 0xffff)
		return 0;

	va_start(argptr, fmt);
	pt += sprintf(pt, "Debug(%s : %d) ", __file, __line);
	pt += vsprintf(pt, fmt, argptr);
	pt += sprintf(pt, "\n");
	va_end(argptr);

	write(2, buff, size_t(pt - buff));
	
	if (level < CurrentDebugLevel)
		return 0;
	
	writeFile(buff);
    writeFile("\n");
	return 0;
}

#else

// Versione per WINDOWS 

#ifndef __WINDOWS_H
#if !defined(__WINDOWS_H) && !defined(__INC_WINDOWS)
#include <windows.h>
#endif
#endif

int __error(const char *fmt, ...)
{
	va_list argptr;
	char buff[512];
	char title[100];
	char *pt = buff;

	sprintf(title, "Error(%s:%d)", __file, __line);
	writeFile(title);
    writeFile(":");
	
	va_start(argptr, fmt);
	pt += vsprintf(pt, fmt, argptr);
	va_end(argptr);

	writeFile(buff);
    writeFile("\n");
	MessageBox(0, buff, title, MB_OK | MB_ICONSTOP);
	FatalAppExit(0, "Errore nell'applicazione");
	return 0;
}


int __debug(uint level, const char *fmt, ...)
{
	va_list argptr;
	char title[100];
	char buff[512];
	char *pt = buff;
	
	if (CurrentDebugLevel == 0xffff)
		return 0;
	
	sprintf(title, "Debug(%s:%d)", __file, __line);
    writeFile(title);

	va_start(argptr, fmt);
	pt += vsprintf(pt, fmt, argptr);
	va_end(argptr);

	writeFile(buff);
    writeFile("\n");
	
	if (level < CurrentDebugLevel)
		return 0;
		
	if (ptDebugProc == 0)
		MessageBox(0, buff, title, MB_OK | MB_ICONINFORMATION);
	else
		ptDebugProc(title, buff); 
	return 0;
}

#endif

