#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__FLIST[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__FLIST
#endif


ImplementObject(Flist, Object);
ImplementPersistent(Flist);

Flist::Flist()
{
	m_pT = New LinkObj<Object> [10];
	m_nBase = 0;
	m_nTop = 0;
	m_nEnd = 10;
}

Flist::Flist(const Flist &s)
{
	m_pT = New LinkObj<Object> [10];
	m_nBase = 0;
	m_nTop = 0;
	m_nEnd = 10;
	
	for (int i = 0; i < s.m_nTop; i++)
		Append(s[i].p());
}

Flist::Flist(Object *pObj)
{
	m_pT = New LinkObj<Object> [10];
	m_nBase = 0;
	m_nTop = 0;
	m_nEnd = 10;
	
	Append(pObj);
}

Flist::~Flist()
{
	Assert(this);
	
	Clear();
	Delete [] m_pT;
}


bool Flist::isEqual(const Object &obj) const
{
	if (obj.isA() != typeid(Flist))
		return false;

	const Flist *fl = dynamic_cast<const Flist *>(&obj);

	if (fl->m_nTop != m_nTop)
		return false;

	for (size_t i = 0 ; i < m_nTop ; i++)
		if (! m_pT[i]->isEqual(*(fl->m_pT[i].p())))
			return false;

	return true;
}

/*
void Flist::printOn(ostream &s) const
{
	Assert(this);
	
	size_t n = nOfItems();

	s << "Flist\n{\n";

	for (size_t i = 0 ; i < n ; n++)
		s << '\t' << *base[i] << '\n';
	s << "}\n";
}
*/



void Flist::Clear()
{
	Assert(this);
	
	for (int i = 0; i < m_nTop; i++)
		m_pT[i] = NULL;

	m_nTop = 0;
}

void Flist::Append(Object *pObj)
{
	Assert(this);
	
	if (m_nTop == m_nEnd)
		Resize();
		
	m_pT[m_nTop++] = pObj;
}

void Flist::Resize(int sz)
{
	Assert(this);
	
	if (sz == -1)
		sz = 2 * m_nEnd;

	LinkObj<Object> *newBase = New LinkObj<Object> [sz];

	for (int i = 0; i < m_nTop && i < sz; i++)
		m_pT[i] = newBase[i];
		
	Delete [] m_pT;
	m_pT = newBase;
	m_nEnd = sz;
}


Flist & Flist::operator = (const Flist &s)
{
	if (this == &s)
		return *this;

	Clear();

	for (int i = 0; i < s.m_nTop; i++)
		Append(s.m_pT[i].p());

	m_nTop = s.m_nTop;
	return *this;
}


//******************************************************************

class FlistIterator : public IteratorData
{
public:
	FlistIterator(const Flist *);
	virtual ~FlistIterator() {}
	virtual const Object * GetNext();
private:
	size_t index;
	const Flist *ptFlist;
};

FlistIterator::FlistIterator(const Flist *s)
{
	ptFlist = s;
	index = 0;
}

const Object * FlistIterator::GetNext()
{
	if (index >= ptFlist->nOfItems())
		return NULL;
	return ptFlist->m_pT[index++].p();
}


IteratorData * Flist::InitIterator() const
{
	return New FlistIterator(this);
}



//**************************************************************


void Flist::Serialize(Persistent &p)
{
	Assert(this);
	
	Object::Serialize(p);

	::Serialize(p, m_nTop);

	if (p.Dir() == Persistent::In)
		Resize(m_nTop);

	for (int i = 0; i < m_nTop; i++)
		::Serialize(p, m_pT[i]);
}
