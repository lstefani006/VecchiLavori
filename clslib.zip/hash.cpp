#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__HASH[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__HASH
#endif

ImplementObject(Hash, Object);
ImplementPersistent(Hash);

Hash::Hash()
{
	size_t sz = 20;
	HASHFUNC foo = default_Hash;
	table = New Hashitem *[sz];
	memset(table, 0, sz * sizeof(Hashitem *));
	tabsize = sz;
	Hashfunc = foo;
	item_inserted = 0;
}


Hash::Hash(int sz, HASHFUNC foo)
{
	table = New Hashitem *[sz];
	memset(table, 0, sz * sizeof(Hashitem *));
	tabsize = sz;
	Hashfunc = foo;
	item_inserted = 0;
}


Object *Hash::Insert(const char *item, Object &data)
{
	return Insert(item, & data);
}

Object *Hash::Insert(const char *item, Object *data)
{
	unsigned hv;
	int len;
	Hashitem *np;

	++item_inserted;
	
	data->IncOwners();
	
	if (item == 0)
		return 0;
	len = strlen(item);
	hv = (*Hashfunc)(item, tabsize);		// get Hash #

	if (table[ hv ])
	{
		np = table[ hv ];			// chain exists
		forever
		{
			if (strcmp(np->name, item) == 0)
				return np->obj;
			if (np->next == 0)
				break;
			np = np->next;			// hop along chain
		}
		np->next = (Hashitem *) New char[ sizeof(Hashitem) + len ];
		np = np->next;
		np->obj = data;
		strcpy(np->name, item);		// fill it in
		np->next = 0;
	}
	else
	{					// no chain
		table[ hv ] = (Hashitem *) New char[ sizeof(Hashitem) + len ];
		// allocate first item of chain
		np = table[ hv ];
		np->obj = data;
		strcpy(np->name, item);
		np->next = 0;                   // copy in information
	}
	return 0;
}


int Hash::Remove(const char *item)
{
	unsigned hv;
	Hashitem *np, *last;

	--item_inserted;
	
	if (item == 0)
		throw("Hash::remove() called with null pointer");

	hv = (*Hashfunc)(item,tabsize);
	np = table[ hv ];
	if (np == 0)
		return -1;       // no such item
	if (np->next == 0)
	{
		// only item on this chain
		np->obj->DecOwners(np->obj);
		Delete np;
		table[ hv ] = 0;
		return 0;
	}
	else
	if (strcmp(item, np->name) == 0)
	{
		// first item on chain matches
		np->obj->DecOwners(np->obj);

		table[hv] = np->next;
		Delete np;
		return 0;
	}
	else
	{                            // must look along chain
		for (; np;)
		{
			last = np;
			np = np->next;
			if (strcmp(item,np->name) == 0)
			{	// match found
				np->obj->DecOwners(np->obj);
				last->next = np->next;      // link it out
				Delete np;
				return 0;
			}
		}
		return -1;
	}
}

Object *Hash::Lookup(const char *p) const
{
	unsigned hv = (* Hashfunc)(p, tabsize);
	for (Hashitem *np = table[hv]; np; np = np->next)
		if (strcmp(np->name, p) == 0)
			return np->obj;
	return 0;
}

size_t Hash::nOfItems() const
{
	size_t n = 0;
	Iterator it(this);

	while (it())
		++n;
	return n;
}

void Hash::Cleanup()
{
	Hashitem *p, *q;
	for (int i = 0; i < tabsize; ++i)
	{
		for (p = table[i]; p; p = q)
		{
			q = p->next;
			p->obj->DecOwners(p->obj);


			Delete p;
		}
	}
	Delete table;
	table = 0;
	tabsize =0;

    // questo e` in pratica il costruttore di default
	size_t sz = 20;
	HASHFUNC foo = default_Hash;
	table = New Hashitem *[ sz ];
	memset(table, 0, sz * sizeof(Hashitem *));
	tabsize = sz;
	Hashfunc = foo;
	item_inserted = 0;
}


/*************************************************************************/

class HashIterator : public IteratorData
{
public :
	HashIterator(const Hash *);
	virtual ~HashIterator() {}
	virtual const Object *GetNext();
	const Object *GetNext(const char *&key);
private :
	const Hash *ht;
	int i;
	const Hash::Hashitem *np;

};

HashIterator::HashIterator(const Hash *a)
{
	ht = a;
	for (i = 0; i < ht->tabsize; ++i)
	{
		if (ht->table[i] == 0)
			continue;
		np = ht->table[i];
		if (np) return;
	}
	np = 0;
}

const Object *HashIterator::GetNext()
{
	if (np == 0) return 0;
	
	const Hash::Hashitem *tmp = np;
	np = np -> next;
	
	if (np == 0)
	{
		i++;
		while (i < ht->tabsize)
		{
			np = ht -> table[i];
			if (np)
				return tmp->obj;
			i++;
		}
		np = 0;
	}
	return tmp->obj;
}

const Object *HashIterator::GetNext(const char *&Key)
{
	Key = 0;
	if (np == 0) return 0;
	
	const Hash::Hashitem *tmp = np;
	np = np -> next;
	
	if (np == 0)
	{
		i++;
		while (i < ht->tabsize)
		{
			np = ht -> table[i];
			if (np)
			{
				Key = tmp->name;
				return tmp->obj;
			}
			i++;
		}
		np = 0;
	}
	Key = tmp->name;
	return tmp->obj;
}

IteratorData *Hash::InitIterator() const
{
	return New HashIterator(this);
}


/*
void Hash::HashReport()
{
	int *freq = New int [tabsize];
	for (int i = 0; i < tabsize; ++i)
	{
		freq[ i ] = 0;
		Hashitem *np = table[i];
		for (int n = 0; np;)
		{
			++n;
			np = np->next;
		}
		freq[i] = n;
		cout << i << " - ";
		if (n)
		{
			np = table[i];
			for (n = 0; np;)
			{
				cout << np->name << ' ';
				np = np->next;
			}
		}
		cout << '\n';
	}
	cout << '\n';
	for (i = 0; i < tabsize; ++i)
		cout << i << ' ' << freq[i] << '\n';

	double d = 0.0;
	for (i = 0; i < tabsize; ++i)
		d += freq[i] * (freq[i] + 1.0) / 2.0;

	double n = item_inserted / (2.0 * tabsize) * (item_inserted + 2.0 * tabsize - 1.0);

	cout << "rapporto " << d/n << "\n\n";
}
*/

#if 0
static unsigned rtab[] = {
	7092, 5393, 1741, 4217, 8537, 3043, 5931, 9660, 5143, 1161,
	3498, 1563, 4308, 6730, 2102, 1535, 7973, 3797, 6688, 2813,
	9165, 3116, 9907, 1224, 5662, 2614
};
unsigned default_Hash(const char *w, int modulo)
{
	const char *p;
	unsigned x, y = 0;

	x = strlen(w) - 1;
	for (p = w + x; p >= w; --p)
	{
		// effect outcome as broadly as possible
		y += rtab[ unsigned(*p - 'a') % 
		           (sizeof rtab / sizeof(unsigned)) ];
		y += x * (*p);          // make it depend on order
		--x;
	}
	return y % modulo;
}
#endif

#if 0
unsigned default_Hash(const char *w, int modulo)
{
	unsigned y = 0;

	while (*w) y = (y << 1) ^ *w++;
	y %= modulo;
	return y;
}
#endif

#if 1
/* Dragon book */
unsigned default_Hash(const char *p, int modulo)
{
	unsigned long h = 0, g;
	while (*p)
	{
		h = (h << 4) + *p++;
		if ((g = h & 0xf0000000ul) != 0ul)
		{
			h = h ^ (g >> 24);
			h = h ^ g;
		}
	}
	return int(unsigned(h) % unsigned(modulo));
}
#endif


/*****************************************************************/


void Hash::Serialize(Persistent &p)
{
	Assert(this);

	Object::Serialize(p);

	if (p.Dir() == Persistent::Out)
	{
		int len = nOfItems();
		::Serialize(p, len);

		Object *pt;
		const char *Name;
		HashIterator it(this);

		while ((pt = (Object *)it.GetNext(Name)) != NULL)
		{
			int NameLen = strlen(Name);
			::Serialize(p, NameLen);
			p.Write(Name, NameLen);
			::Serialize(p, pt);
		}
	}
	else
	{
		int len;
		::Serialize(p, len);

		for (int i = 0; i < len; i++)
		{
			int NameLen;
			char *Name;
			Object *pt = 0;

			::Serialize(p, NameLen);
			Name = New char [NameLen + 1];
			p.Read(Name, NameLen);
			Name[NameLen] = 0;

			::Serialize(p, pt);
			
			Insert(Name, pt);
			Delete Name;
		}
	}
}


Hash::Hash(const Hash &r)
{
	size_t sz = 20;
	HASHFUNC foo = default_Hash;
	table = New Hashitem *[sz];
	memset(table, 0, sz * sizeof(Hashitem *));
	tabsize = sz;
	Hashfunc = foo;
	item_inserted = 0;

	
	const Object *pt;
	const char *Name;
	HashIterator it(&r);

	while ((pt = it.GetNext(Name)) != 0)
		Insert(Name, (Object *)pt);
}

