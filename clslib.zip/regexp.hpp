#ifndef __REGEXP_HPP
#define __REGEXP_HPP

#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif



class RegExpr
{
public:
	RegExpr(const char *pchRegExpr) /* throw(SyntaxError) */;
	~RegExpr();

	bool Match(const char *pchMatch) const;
	void SubMatch(int nSub, const char *&rpchStart, const char *&rpchEnd) const;
	void Substitute(const char *pchSub, char *pchDest) const;

	static exception SyntaxError;

protected:
	struct regexp *m_ptRegExpr;
};


extern RegExpr rgFileName;	/* [-_a-zA-Z0-9]+ */

/*
 * es:
 *	RegExpr rgNum("[0-9]+-([0-9]+)");
 *  if (rgNum.Match("Leo 24-6-64"))
 *	{
 *		const char *pchStart = 0, *pchEnd = 0;
 *		rgNum.SubMatch(0, pchStart, pchEnd);	// trova tutto "24-6"
 *		rgNum.SubMatch(1, pchStart, pchEnd);	// trova il primo () "6"
 *	}
 */


#endif
