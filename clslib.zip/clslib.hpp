#ifndef __CLSLIB_HPP
#define __CLSLIB_HPP

#pragma warning(disable:4505)	    // toglie il warning "unreferenced local function has been removed"

#ifndef __NEW_HPP
#include <new.hpp>
#endif
#ifndef __OBJECT_HPP
#include <object.hpp>
#endif
#ifndef __ERROR_HPP
#include <error.hpp>
#endif
#ifndef __PERSIST_HPP
#include <persist.hpp>
#endif
//#ifndef __ASSOC_HPP
//#include <assoc.hpp>
//#endif
#ifndef __STRING_HPP
#include <string.hpp>
#endif
#ifndef __EXHANDLE_HPP
#include <exhandle.hpp>
#endif
#ifndef __FLIST_HPP
#include <flist.hpp>
#endif
#ifndef __HASH_HPP
#include <hash.hpp>
#endif
#ifndef __SET_HPP
#include <set.hpp>
#endif
#ifndef __SLIST_HPP
#include <slist.hpp>
#endif
#ifndef __DBOBJ_HPP
#include <DbObj.hpp>
#endif
#ifndef __TIME_HPP
#include <time.hpp>
#endif

#ifndef __LINKOBJ_HPP
#include <LinkObj.hpp>
#endif

// #pragma hdrstop

/*
smartpt.hpp
dynarr.hpp
ctokenc.hpp
*/


#endif
