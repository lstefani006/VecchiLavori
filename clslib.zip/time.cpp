#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__TIME[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__TIME
#endif

ImplementObject(TimeHHMM, Object);
ImplementPersistent(TimeHHMM);

TimeHHMM::TimeHHMM() : m_HH(0), m_MM(0) {}
TimeHHMM::TimeHHMM(int h, int m) : m_HH(uchar(h)), m_MM(uchar(m)) {}
TimeHHMM::~TimeHHMM() {}
TimeHHMM::TimeHHMM(const TimeHHMM &t)
{
	m_HH = t.m_HH;
	m_MM = t.m_MM;
}

void TimeHHMM::operator = (const TimeHHMM &t)
{
	m_HH = t.m_HH;
	m_MM = t.m_MM;
}

void TimeHHMM::Serialize(Persistent &p)
{
	Assert(this);

	::Serialize(p, m_HH);
	::Serialize(p, m_MM);
}


int TimeHHMM::Compare(const TimeHHMM &t) const
{
	unsigned a = (unsigned(  m_HH) << 8) |   m_MM;
	unsigned b = (unsigned(t.m_HH) << 8) | t.m_MM;

	if (a > b)
		return 1;
	if (a < b)
		return -1;
	return 0;
}

/*
void TimeHHMM::printOn(ostream &s) const
{
	s << m_HH << ":" << m_MM;
}
*/


bool TimeHHMM::isEqual(const Object &refObj) const
{
	if (refObj.isA() != typeid(TimeHHMM))
		return false;

	return bool(Compare(*((TimeHHMM *) &refObj)) == 0);
}



bool operator > (const TimeHHMM &a, const TimeHHMM &b)
{
	return bool(a.Compare(b) > 0);
}

bool operator < (const TimeHHMM &a, const TimeHHMM &b)
{
	return bool(a.Compare(b) < 0);
}

bool operator >= (const TimeHHMM &a, const TimeHHMM &b)
{
	return bool(a.Compare(b) >= 0);
}

bool operator <= (const TimeHHMM &a, const TimeHHMM &b)
{
	return bool(a.Compare(b) <= 0);
}

bool operator == (const TimeHHMM &a, const TimeHHMM &b)
{
	return bool(a.Compare(b) == 0);
}

bool operator != (const TimeHHMM &a, const TimeHHMM &b)
{
	return bool(a.Compare(b) != 0);
}



//////////////////////////////////////////////////////////////////////////////

ImplementObject(ElapsedTime, Object);
ImplementPersistent(ElapsedTime);

ElapsedTime::ElapsedTime() : m_sec(0ul) {}
ElapsedTime::ElapsedTime(const ElapsedTime &t) : m_sec(t.m_sec) {}
ElapsedTime::ElapsedTime(ulong h, ulong m, ulong s)
{
	m_sec = h * 3600l + m * 60l + s;
}
ElapsedTime::ElapsedTime(ulong s)
{
	m_sec = s;
}


ElapsedTime::~ElapsedTime()
{
}

void ElapsedTime::operator = (const ElapsedTime &t)
{
	m_sec = t.m_sec;
}

void ElapsedTime::operator = (ulong ulSec)
{
	m_sec = ulSec;
}

void ElapsedTime::Serialize(Persistent &p)
{
	Object::Serialize(p);
	::Serialize(p, m_sec);
}

unsigned long ElapsedTime::GetSec() const { return m_sec; }

void ElapsedTime::Write(char *b) const
{
	ulong d =  m_sec / (3600ul * 24ul);
	ulong h = (m_sec % (3600ul * 24ul))/ 3600ul;
	ulong m = (m_sec % 3600ul) / 60ul;
	ulong s =  m_sec % 60ul;

		  if (d == 0ul && h == 0ul && m == 0ul) sprintf(b, "%lus", s);
	else if (d == 0ul && h == 0ul && s == 0ul) sprintf(b, "%lum", m);
	else if (d == 0ul && m == 0ul && s == 0ul) sprintf(b, "%luh", h);
	else if (h == 0ul && m == 0ul && s == 0ul) sprintf(b, "%lud", d);
	else if (d == 0ul && h == 0ul)             sprintf(b, "%lum:%02lus", m, s);
	else if (d == 0ul && s == 0ul)             sprintf(b, "%luh:%02lum", h, m);
	else if (m == 0ul && s == 0ul)             sprintf(b, "%lud:%luh", d, h);
	else if (d == 0ul) 						   sprintf(b, "%luh:%02lum:%02lus", h, m, s);
	else                                       sprintf(b, "%lud:%luh:%02lum:%02lus", d, h, m, s);
}


bool ElapsedTime::Read(const char *b)
{
	ulong n1, n2, n3, n4;
	int r;
	char t[4];
	
	// 3d:12h:34m:32s
	r = sscanf (b, "%lu%[dD]%lu%[hH]:%lu%[mM]:%lu%[sS]", &n4, t, &n1, t, &n2, t, &n3, t);
	if (r == 6) { m_sec = n4 * (3600ul * 24ul) + n1 * 3600l + n2 * 60l + n3; return true; }

	// 12h:34m:32s
	r = sscanf (b, "%lu%[hH]:%lu%[mM]:%lu%[sS]", &n1, t, &n2, t, &n3, t);
	if (r == 6) { m_sec = n1 * 3600l + n2 * 60l + n3; return true; }

	// 12:34:32
	r = sscanf (b, "%lu:%lu:%lu", &n1, &n2, &n3);
	if (r == 3) { m_sec = n1 * 3600l + n2 * 60l + n3; return true; }

	// 12d:03h
	r = sscanf (b, "%lu%[dD]:%lu%[hH]", &n1, t, &n2, t);
	if (r == 4) { m_sec = n1 * (3600ul * 24ul) + n2 * 3600ul; return true; }

	// 12h:34m
	r = sscanf (b, "%lu%[hH]:%lu%[mM]", &n1, t, &n2, t);
	if (r == 4) { m_sec = n1 * 3600l + n2 * 60l; return true; }
	
	// 12m:34s
	r = sscanf (b, "%lu%[mM]:%lu%[sS]", &n1, t, &n2, t);
	if (r == 4) { m_sec = n1 * 60l + n2; return true; }

	// 12:34
	r = sscanf (b, "%lu:%lu", &n1, &n2);
	if (r == 2) { m_sec = n1 * 3600l + n2 * 60l; return true; }

	// 12d
	r = sscanf (b, "%lu%[dD]", &n1, t);
	if (r == 2) { m_sec = n1 * (3600ul * 24ul); return true; }

	// 12h
	r = sscanf (b, "%lu%[hH]", &n1, t);
	if (r == 2) { m_sec = n1 * 3600l; return true; }
	
	// 12m
	r = sscanf (b, "%lu%[mM]", &n1, t);
	if (r == 2) { m_sec = n1 * 60l; return true; }
	
	// 12s
	r = sscanf (b, "%lu%[sS]", &n1, t);
	if (r == 2) { m_sec = n1; return true; }

	return false;
}
