#ifndef __OBJECT_HPP
#include <object.hpp>
#endif

class cToken;

class cTokenIstream : public istream_withassign
{
public:
	enum cTokenIstreamState { None, Cr };
	
	cTokenIstream();
	cTokenIstream(istream &);
	
	cTokenIstream & operator = (cTokenIstream &);
	cTokenIstream & operator = (streambuf *);
	cTokenIstream & operator = (istream &);
	
	cTokenIstream & operator >> (cToken &);

	void Add(cToken *);

protected:
	static char c;		// possono essere statici in quanto 
	static char l;		// non danno side effects	    
	unsigned linenu;
	cTokenIstreamState state;
	
	void next();		// legge in c il prossimo char e in l
				// il look hahead
private:
	void identificatore();
	void numero_esa();
	void numero_ottale();
	void numero_double();
	void numero_intero_o_double();
	void commento_c();
	void commento_cpp();
	void carattere();
	void carattere_backslash();
	void stringa();
};

class cToken : public Object
{
public:
	DeclareObject(cToken);
	bool isEqual(const Object &) const { return false; }
	
	enum TokenType {
		None = 256,
		PreProc,
		NewType,
		BinOp,
		UnOp,

		Asm,
		Auto,
		Break,
		Case,
		Catch,
		Char,
		Class,
		Const,
		Continue,
		Default,
		_Delete,
		Do,
		Double,
		Else,
		Enum,
		Extern,
		Float,
		For,
		Friend,
		Goto,
		Iden,
		If,
		Inline,
		Int,
		Long,
		_New,
		Operator,
		Private,
		Protected,
		Public,
		Register,
		Return,
		Short,
		Signed,
		Sizeof,
		Static,
		Struct,
		Switch,
		Template,
		This,
		Throw,
		Try,
		Typedef,
		Union,
		Unsigned,
		Virtual,
		Void,
		Volatile,
		While,

		// MSDOS keywords 
		Cdecl,
		_Export,
		Far,
		Huge,
		Interrupt,
		_Loadds,
		Near,
		Pascal,
		_Saveregs,
		_Seg
	};

	void printOn(ostream &) const;

	cToken();
	cToken(const char *s, TokenType t, unsigned ln = 0);
	void operator = (const cToken & tk);

	TokenType getTokenType() const { return tt; }
	const char *Get() { return token; }

	friend cTokenIstream & cTokenIstream::operator >> (cToken &);

private:
	const char *token;
	TokenType tt;
	unsigned linenu;

	cToken(const cToken &);			// cannot be used
};
