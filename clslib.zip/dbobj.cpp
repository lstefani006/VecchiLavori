#define __DBOBJ_CPP

#ifndef __CLSLIB_HPP
#include <ClsLib.hpp>
#endif

#ifdef DEBUG
#undef __THIS_FILE__
static const char far __THIS_FILE__DBOBJ[] = __FILE__;
#define __THIS_FILE__ __THIS_FILE__DBOBJ
#endif


aDbObj::aDbObj()
{
	if (m_unSize != 0u)
		return;
		
	//m_unSize = 10007u;     MP 22/05 raggiunto il limite
	//m_unSize = 13333u;       // MP 21/7 ragginto il limite
	m_unSize = 15001u;       // proviamo cos�

    //m_unSize = 11000u;
	m_ppObject = (const void **) New void * [m_unSize];

	for (uint i = 0; i < m_unSize; i++)
		m_ppObject[i] = 0;
}

aDbObj::~aDbObj()
{
	/* bisogna non cancellare l'array in quanto non e` affatto garantito che
       questo sia l'ultimo distruttore invocato
	Delete (void **) m_ppObject;
	m_ppObject = 0;
    */
}

/* Gestione con hash */
inline static uint hash_pObject(const void *w, uint unModulo)
{
	/*
	uint y = 0;
	for (size_t i = 0; i < sizeof(const char *); i++)
		y = (y << 1) ^ *w++;
    */
	return uint(ulong(w) % ulong(unModulo));
}

void aDbObj::Add(const void *pObject)
{
	if (m_unSize == 0u)
	{
		/* e` il costruttore di aDbObj */


		//m_unSize = 10007u;   MP 22/05 raggiunto il limite
		//m_unSize = 13333u;     // MP proviamo cos�
		m_unSize = 15001u;     // MP proviamo cos�


		m_ppObject = (const void **) New void * [m_unSize];

		for (uint i = 0; i < m_unSize; i++)
			m_ppObject[i] = 0;
	}
	
	unsigned nHash = hash_pObject(pObject, m_unSize);
	unsigned i = nHash;

	forever
	{
		if (m_ppObject[i] == 0)
		{
			m_ppObject[i] = pObject;
			return;
		}

		i++;
		if (i == m_unSize)
			i = 0;
		else
		if (i == nHash)
			Error("aDbObj::Add(const Object *): table full");
	}
}


void aDbObj::Kill(const void *pObject)
{
	unsigned nHash = hash_pObject(pObject, m_unSize);

	unsigned i = nHash;

	forever
	{
		if (m_ppObject[i] == pObject)
		{
			m_ppObject[i] = 0;
			return;
		}

		i++;
		if (i == m_unSize)
			i = 0;
		else
		if (i == nHash)
			Error("aDbObj::Kill(const Object *): object %p not found, pObject");
	}
}

void aDbObj::Search(classType ct, Slist &SlistOut)
{
	const Object **ppObject    = (const Object **)m_ppObject;
	const Object **ppObjectEnd = (const Object **)(m_ppObject + m_unSize);

	while (ppObject < ppObjectEnd)
	{
		if (*ppObject != 0 && ppObject[0]->isA(ct) != typeid(void))
			SlistOut.AddTail((Object *)*ppObject);
		++ppObject;
	}
}

void aDbObj::Search(bool (*pFun)(const Object *, void *), void *pVoid, Slist &SlistOut)
{
	const Object **ppObject    = (const Object **)m_ppObject;
	const Object **ppObjectEnd = (const Object **)(m_ppObject + m_unSize);

	while (ppObject < ppObjectEnd)
	{
		if (*ppObject != 0 && pFun(*ppObject, pVoid) == true)
			SlistOut.AddTail((Object *)*ppObject);
		++ppObject;
	}
}

void aDbObj::Search(classType ct, bool (*pFun)(const Object *, void *), void *pVoid, Slist &SlistOut)
{
	const Object **ppObject    = (const Object **)m_ppObject;
	const Object **ppObjectEnd = (const Object **)(m_ppObject + m_unSize);

	while (ppObject < ppObjectEnd)
	{
		if (*ppObject != 0 &&
		    ppObject[0]->isA(ct) != typeid(void) &&
		    pFun(*ppObject, pVoid) == true)
			SlistOut.AddTail((Object *)*ppObject);
		++ppObject;
	}
}

aDbObj DbObj;		/* il data base di tutti gli oggetti esistenti */

