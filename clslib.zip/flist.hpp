#ifndef __FLIST_HPP
#define __FLIST_HPP

#include <Object.hpp>
#include <LinkObj.hpp>

class Flist : public Object
{
public:
	DeclareObject(Flist);
	DeclarePersistent(Flist);
	
	Flist();
	Flist(const Flist &);
	Flist(Object *);
	~Flist();				           // destroy Objects inside
	void Clear();			           // destroy Objects inside
	Flist & operator = (const Flist &);

	virtual bool isEqual(const Object &) const;

	void Append(Object *);             // add at tail of list
	LinkObj<Object> Get();             // return and remove head of list
	
	LinkObj<Object> Search(const Object &) const;
	size_t nOfItems() const { return size_t(m_nTop - m_nBase) ; }
	LinkObj<Object> operator [] (int i) const { return m_pT[i] ; }

	virtual class IteratorData * InitIterator() const;

protected:
	friend class FlistIterator;
	LinkObj<Object> *m_pT;
	int              m_nBase;
	int              m_nTop;
	int              m_nEnd;
	
	void Resize(int sz = -1);
};

#endif
