#ifndef __OBJECT_HPP
#define __OBJECT_HPP

#include <stddef.h>
#include <New.hpp>

#include <typeinfo.h>


enum bool { false = 0, true = 1 };

typedef const typeinfo &classType;

// declaration of management members
#define DeclareObject(className)											\
	static Object * StaticCreateObject() { return new className; }			\
	virtual className * CloneObject() const { return new className(*this); }\
	virtual className * CreateObject() const { return new className; }		\
	int DecOwners(className *&pt);									        \
	int DecOwners() const;													\
	virtual classType isA() const;                                          \
	virtual classType isA(classType) const                                  \

#define DeclareAbstractObject(className)									\
	static Object * StaticCreateObject() { return NULL; }					\
	virtual className * CloneObject() const { return NULL; }                \
	virtual className * CreateObject() const { return NULL; }				\
	int DecOwners(className *&pt);									        \
	int DecOwners() const;													\
	virtual classType isA() const;                                          \
	virtual classType isA(classType) const


#define ImplementObject(className, baseClass)								\
	int className::DecOwners(className *&pt) {								\
		return Object::DecOwners((Object *&)pt);							\
	}																		\
	int className::DecOwners() const { return Object::DecOwners(); }		\
	classType className::isA() const { return typeid(className); }         	\
	classType className::isA(classType aType) const							\
	{															        	\
		if (typeid(className) == aType)                                 	\
			return aType;													\
		return baseClass::isA(aType);                                   	\
	}


class Object
{
public:
	///////////////////////////////////////////////////////////
	// Constructors Destructors and heap operators
	void * operator new (size_t);
	void   operator delete(void *);
	
	Object();
	virtual ~Object();
	
    static Object * StaticCreateObject();
	virtual Object * CloneObject() const { return NULL; }
	virtual Object * CreateObject() const { return NULL; }

	 ///////////////////////////////////////////////////////////
	 // Generic Object properties
	virtual classType isA() const = 0;
	virtual classType isA(classType) const = 0;
	virtual bool isEqual(const Object &) const;
	virtual class IteratorData *InitIterator() const;


	/////////////////////////////////////////////////////////////
	// Shared Object handlers
	// these function are 'const' even if they modify 'NumOwners'
	// in this way you can use them with 'const Object's
	int IncOwners() const;
	int DecOwners() const;
	int DecOwners(Object *&);			// delete this if possible
	int GetOwners() const;
	bool IsOnFreeStore() const;
	

	//////////////////////////////////////////////////////////
	 // Persistent Object handlers
	friend class Persistent;
	virtual void Serialize(Persistent &);

private:
	unsigned m_Flag;
	
	// Cannot be used
	Object(const Object &);
	Object & operator = (const Object &);
};

#ifndef __PERSIST_HPP
#include <Persist.hpp>
#endif


#define Assign(a , b) { (a)->DecOwners(a); (a) = (b); (a)->IncOwners(); }


int operator == (const Object & a, const Object & b);
int operator != (const Object & a, const Object & b);


//****************************************************************************
//                                                                            
//              Iterator for generic Objects                              
//                                                                            
//****************************************************************************

class IteratorData
{
public:
	IteratorData();
	virtual const Object * GetNext() = 0;
	virtual ~IteratorData();
};

class Iterator : public Object
{
public:
	DeclareObject(Iterator);

	Iterator(const Object *o);
	Iterator(const Object &o);
	~Iterator();
	const Object * operator ()();

private:
	Iterator() {}
	Iterator(const Iterator &) {}			// non si puo` usare
	void operator = (const Iterator &);
	IteratorData *itd;
};

#endif
