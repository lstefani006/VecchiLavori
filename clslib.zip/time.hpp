#ifndef __TIME_HPP
#define __TIME_HPP

#include <ClsLib.hpp>

class TimeHHMM : public Object
{
public:
	DeclareObject(TimeHHMM);
	DeclarePersistent(TimeHHMM);

	TimeHHMM();
	TimeHHMM(const TimeHHMM &);
    TimeHHMM(int h, int m);
	~TimeHHMM();
	
	void operator = (const TimeHHMM &t);

	bool isEqual(const Object &) const;
	int Compare(const TimeHHMM &) const;
	
	int GetHH() const { return m_HH; }
	int GetMM() const { return m_MM; }

	friend bool operator >  (const TimeHHMM &a, const TimeHHMM &b);
    friend bool operator <  (const TimeHHMM &a, const TimeHHMM &b);
	friend bool operator >= (const TimeHHMM &a, const TimeHHMM &b);
    friend bool operator <= (const TimeHHMM &a, const TimeHHMM &b);
	friend bool operator == (const TimeHHMM &a, const TimeHHMM &b);
    friend bool operator != (const TimeHHMM &a, const TimeHHMM &b);

protected:
	unsigned char m_HH;
    unsigned char m_MM;
};



////////////////////////////////////////////////////////////////////////////////

class ElapsedTime : public Object
{
public:
	DeclareObject(ElapsedTime);
	DeclarePersistent(ElapsedTime);

	ElapsedTime();
	ElapsedTime(const ElapsedTime &);
	ElapsedTime(ulong h, ulong m, ulong s);
	ElapsedTime(ulong s);
	~ElapsedTime();
	void operator = (const ElapsedTime &);
	void operator = (ulong s);

	bool Read(const char *txt);		// read from txt; return false on error
	void Write(char *txt) const;	// write m_sec into txt string

	ulong GetSec() const;

protected:
	ulong m_sec;
};

#endif
