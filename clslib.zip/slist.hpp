#ifndef __SLIST_HPP
#define __SLIST_HPP

#ifndef __OBJECT_HPP
#include <Object.hpp>
#endif

class Slist : public Object
{
public:
	DeclareObject(Slist);
	DeclarePersistent(Slist);

	Slist();
	Slist(const Slist &);
	Slist(Object &);
	void Clear();                       // remove all links
	~Slist();			               // destroy Objects inside
	Slist & operator = (const Slist &);

	virtual bool isEqual(const Object &) const;

	void AddHead(Object &);           // add at head of list
	void AddTail(Object &);           // add at tail of list

	void AddHead(Object *a);
	void AddTail(Object *a);

	Object * GetHead();               // return and remove head of list
	Object * Remove(const Object *);


	const Object * Search(const Object &) const;    // search for Obj
	const Object * Search(bool (*ptTest)(const Object *pObj, void *pVoid), void *pVoid, int Ignore = 0) const;
	size_t nOfItems() const;

	virtual class IteratorData * InitIterator() const;

protected:
	class slink
	{
		friend class Slist;            // Members must be accessible to Slist
		friend class SlistIterator;    // and to the iterator
		slink * next;
		Object * e;
		slink(Object & a);
	};

	friend class SlistIterator;
	slink * last;                      // last->next is head of list
};


#endif
