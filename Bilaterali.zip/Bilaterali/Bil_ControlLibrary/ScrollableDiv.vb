Imports System.ComponentModel
Imports System.Web.UI

<DefaultProperty("Text"), ToolboxData("<{0}:ScrollableDiv runat=server></{0}:ScrollableDiv>")> _
Public Class ScrollableDiv
	Inherits System.Web.UI.WebControls.Panel

	Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
		Dim scrollPos As String = "0"

		MyBase.OnPreRender(e)
		If Page.IsPostBack Then scrollPos = Page.Request(ClientID & "ScrollPos")
		Page.RegisterHiddenField(ClientID & "ScrollPos", scrollPos)
	End Sub

	Dim _BehaviorFile As String
	<Bindable(True), Category("Behavior")> _
	Public Property BehaviorFile() As String
		Get
			Return _BehaviorFile
		End Get
		Set(ByVal Value As String)
			_BehaviorFile = Value
		End Set
	End Property

	Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
		output.AddStyleAttribute("OVERFLOW", "scroll")
		output.AddStyleAttribute("BEHAVIOR", "url('" & _BehaviorFile & "')")
		output.AddStyleAttribute("vertical-align", "top")
		MyBase.Render(output)
	End Sub

End Class
