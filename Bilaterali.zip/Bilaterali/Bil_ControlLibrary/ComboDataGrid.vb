Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls

<ToolboxData("<{0}:ComboDataGrid runat=server></{0}:ComboDataGrid>")> _
Public Class ComboDataGrid
    Inherits System.Web.UI.WebControls.DataGrid

    Sub New()
        MyBase.New()
        MyBase.Width = New Unit(100, UnitType.Percentage)
        MyBase.Height = New Unit(0, UnitType.Percentage)

        Me.HeaderStyle.CssClass = "Bil_DataGrid_Header"
        Me.ItemStyle.CssClass = "Bil_DataGrid_Item"
        Me.PagerStyle.CssClass = "Bil_DataGrid_Pager"
        Me.FooterStyle.CssClass = "Bil_DataGrid_Footer"
        Me.AlternatingItemStyle.CssClass = "Bil_DataGrid_Alternating"
        Me.EditItemStyle.CssClass = "Bil_DataGrid_Edit"
        Me.SelectedItemStyle.CssClass = "Bil_DataGrid_Selected"
    End Sub


    Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
        Dim scrollPos As String = "0"
        Dim selIdx As Integer = Me.SelectedIndex

        MyBase.OnPreRender(e)
        If Page.IsPostBack Then
            scrollPos = Page.Request(ClientID & "ScrollPos")
            selIdx = Integer.Parse(Page.Request(ClientID & "SelIdx"))
            If selIdx <> MyBase.SelectedIndex Then
                selIdx = MyBase.SelectedIndex
            End If
        End If

        Dim s As String = String.Empty
        Dim nl As String = Environment.NewLine
        s += "<SCRIPT>" + nl
        s += "var oBody	=	document.body;" + nl
        s += "var oFrame =	parent.document.all('embeddedFrame');" + nl
        s += "function resizeFrame()" + nl
        s += "{" + nl
        s += "  if (oFrame != null && oBody != null)" + nl
        s += "  {" + nl
        s += "      if (oFrame.runtimeStyle.height != oBody.scrollHeight + (oBody.offsetHeight -" + nl
        s += "								oBody.clientHeight) + 20)" + nl
        s += "      {" + nl
        s += " 	        oFrame.runtimeStyle.height = oBody.scrollHeight + (oBody.offsetHeight -" + nl
        s += "			    					oBody.clientHeight) + 20;" + nl
        s += "      }" + nl
        s += "  }" + nl
        s += "}" + nl
        s += "</SCRIPT>"

        Page.RegisterStartupScript("ComboDataGrid_StartupScript", s)

        Page.RegisterHiddenField(ClientID & "ScrollPos", scrollPos)
        Page.RegisterHiddenField(ClientID & "SelIdx", selIdx.ToString)

    End Sub

    Dim _sp As String
    <Bindable(True), Category("Apparence")> _
    Public Property BehaviorFile() As String
        Get
            Return _sp
        End Get
        Set(ByVal Value As String)
            _sp = Value
        End Set
    End Property


    <Bindable(True), Category("Apparence")> _
    Public Overrides Property Width() As Unit
        Get
            Return w
        End Get
        Set(ByVal Value As Unit)
            w = Value
        End Set
    End Property

    <Bindable(True), Category("Apparence")> _
    Public Overrides Property Height() As Unit
        Get
            Return h
        End Get
        Set(ByVal Value As Unit)
            h = Value
        End Set
    End Property

    Protected w As New Unit(100)
    Protected h As New Unit(100)

    Protected _btnSize As New Unit(17)
    <Bindable(True), Category("Apparence")> _
    Public Property btnSize() As Unit
        Get
            Return _btnSize
        End Get
        Set(ByVal Value As Unit)
            _btnSize = Value
        End Set
    End Property

    Protected _GridVisible As Boolean = False
    <Bindable(True), Category("Apparence")> _
    Public Property GridVisible() As Boolean
        Get
            Return _GridVisible
        End Get
        Set(ByVal Value As Boolean)
            _GridVisible = Value
        End Set
    End Property

    Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
        If _sp Is Nothing Then
            output.WriteLine("BehaviorFile not set")
            Return
        End If

        Dim originalStyle As String = MyBase.Attributes("style")

        Dim ss() As String = originalStyle.Split(New [Char]() {";"c, ":"c})

        Dim dgStyle As String = ""

        ' Costruiamo lo style per il DIV
        For i As Int32 = 0 To ss.Length - 1 Step 2
            Select Case ss(i).Trim(" "c).ToUpper()
                Case "LEFT"
                    output.AddStyleAttribute("LEFT", ss(i + 1))
                Case "POSITION"
                    output.AddStyleAttribute("POSITION", ss(i + 1))
                Case "TOP"
                    output.AddStyleAttribute("TOP", ss(i + 1))
                Case "Z-INDEX"
                    output.AddStyleAttribute("Z-INDEX", ss(i + 1))
                Case " "
                Case Else
                    'dgStyle &= ss(i)
                    'If (i + 1 < ss.Length - 1) Then dgStyle &= ": " & ss(i + 1) & ";"
            End Select
        Next

        output.AddStyleAttribute("WIDTH", (Me.Width.Value - _btnSize.Value).ToString() + "px")
        output.AddStyleAttribute("HEIGHT", "_btnSize.Valuepx")
        output.AddStyleAttribute("vertical-align", "top")
        output.AddStyleAttribute("BORDER-RIGHT", "white thin inset")
        output.AddStyleAttribute("BORDER-TOP", "white thin inset")
        output.AddStyleAttribute("BORDER-LEFT", "white thin inset")
        output.AddStyleAttribute("BORDER-BOTTOM", "white thin inset")
        output.AddStyleAttribute("OVERFLOW", "hidden")
        output.AddStyleAttribute("VISIBILITY", "visible")
        output.AddAttribute("ID", MyBase.ID + "_Selected")
        output.RenderBeginTag(HtmlTextWriterTag.Div)
        output.RenderEndTag()

        ' Costruiamo lo style per l'immagine che funge da bottone
        For i As Int32 = 0 To ss.Length - 1 Step 2
            Select Case ss(i).Trim(" "c).ToUpper()
                Case "LEFT"
                    Dim l As Integer
                    l = Integer.Parse(ss(i + 1).Replace("px", ""))
                    l = l + Integer.Parse((Me.Width.Value - _btnSize.Value).ToString())
                    output.AddStyleAttribute("LEFT", l.ToString())
                Case "POSITION"
                    output.AddStyleAttribute("POSITION", ss(i + 1))
                Case "TOP"
                    output.AddStyleAttribute("TOP", ss(i + 1))
                Case "Z-INDEX"
                    output.AddStyleAttribute("Z-INDEX", ss(i + 1))
                Case " "
                Case Else
                    'dgStyle &= ss(i)
                    'If (i + 1 < ss.Length - 1) Then dgStyle &= ": " & ss(i + 1) & ";"
            End Select
        Next

        'output.AddStyleAttribute("WIDTH", _btnSize.Value.ToString + "px")
        'output.AddStyleAttribute("HEIGHT", _btnSize.Value.ToString + "px")
        output.AddAttribute("onclick", "var selId = document.getElementById('" + ClientID + "SelIdx').value; var divCont = document.getElementById('" + MyBase.ID + "_Cont'); if (divCont.style.visibility == 'hidden') { divCont.style.visibility = 'visible'; divCont.style.display = 'block'; document.getElementById('" + MyBase.ID + "').rows[selId].scrollIntoView(); divCont.style.zIndex = 9999; window.event.srcElement.src = '../../Common/cmbDGarwup.gif'; } else { divCont.style.visibility = 'hidden'; divCont.style.display = 'none';divCont.style.zIndex = 1; window.event.srcElement.src = '../../Common/cmbDGarwdn.gif'; } resizeFrame();")
        output.AddAttribute("ID", MyBase.ID + "_Img")
        output.AddAttribute("SRC", "../../Common/cmbDGarwdn.gif")
        output.AddAttribute("NAME", "cmbDG_BtnImg")
        output.RenderBeginTag(HtmlTextWriterTag.Img)
        output.RenderEndTag()

        For i As Int32 = 0 To ss.Length - 1 Step 2
            Select Case ss(i).Trim(" "c).ToUpper()
                Case "LEFT"
                    dgStyle &= "LEFT: 0px;"
                    output.AddStyleAttribute("LEFT", ss(i + 1))
                Case "POSITION"
                    dgStyle &= "POSITION: absolute;"
                    output.AddStyleAttribute("POSITION", ss(i + 1))
                Case "TOP"
                    dgStyle &= "TOP: 0px;"
                    Dim l As Integer
                    l = Integer.Parse(ss(i + 1).Replace("px", ""))
                    l = l + Integer.Parse(_btnSize.Value.ToString)
                    output.AddStyleAttribute("TOP", l.ToString() + "px")
                Case "Z-INDEX"
                    dgStyle &= ss(i) & ": " & ss(i + 1) & ";"
                    output.AddStyleAttribute("Z-INDEX", ss(i + 1))
                Case " "
                Case Else
                    dgStyle &= ss(i)
                    If (i + 1 < ss.Length - 1) Then dgStyle &= ": " & ss(i + 1) & ";"
            End Select
        Next

        output.AddStyleAttribute("OVERFLOW", "scroll")
        output.AddStyleAttribute("WIDTH", Me.Width.ToString())
        output.AddStyleAttribute("HEIGHT", Me.Height.ToString())
        output.AddStyleAttribute("vertical-align", "top")
        output.AddStyleAttribute("BEHAVIOR", "url('" & _sp & "')")
        output.AddStyleAttribute("BORDER", "black 1px solid")
        If Not Me.Site Is Nothing AndAlso Me.Site.DesignMode Then
            output.AddStyleAttribute("VISIBILITY", "visible")
            If (GridVisible) Then
                output.AddStyleAttribute("DISPLAY", "block")
            Else
                output.AddStyleAttribute("DISPLAY", "none")
            End If
        Else
            output.AddStyleAttribute("VISIBILITY", "hidden")
            output.AddStyleAttribute("Z-INDEX", "1")
        End If
        output.AddAttribute("ID", MyBase.ID + "_Cont")

        output.AddAttribute("persistID", ClientID & "ScrollPos")
        output.AddAttribute("selectedID", ClientID & "SelIdx")

        output.RenderBeginTag("DIV")

        MyBase.Attributes("style") = dgStyle
        MyBase.ShowHeader = False

        output.Indent += 1
        MyBase.Render(output)
        output.Indent -= 1

        MyBase.Attributes("style") = originalStyle

        output.RenderEndTag()

    End Sub

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        MyBase.OnLoad(e)

    End Sub
End Class
