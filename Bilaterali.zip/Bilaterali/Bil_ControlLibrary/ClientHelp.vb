Imports System.ComponentModel
Imports System.Web.UI
Imports System.Data
Imports System.Globalization

<DefaultProperty("Text"), ToolboxData("<{0}:ClientHelp runat=server></{0}:ClientHelp>")> _
Public Class ClientHelp
    Inherits System.Web.UI.WebControls.WebControl

	Dim _alertText As String
    Dim _confirmText As String
    Dim _eventTarget As String
    Dim _eventArgument As String
    Dim _titleText As String
    Dim _userInfo As String
	Dim _mustSave As Boolean = False
    Dim _dataSource As New DataSet

    <Bindable(True), Category("Appearance"), DefaultValue("")> Property AlertText() As String
        Get
            If (_alertText Is Nothing) Then Return String.Empty
            Return _alertText
        End Get

        Set(ByVal Value As String)
            _alertText = Value
        End Set
    End Property
    <Bindable(True), Category("Appearance"), DefaultValue("")> Property ConfirmText() As String
        Get
            If (_confirmText Is Nothing) Then Return String.Empty
            Return _confirmText
        End Get

        Set(ByVal Value As String)
            _confirmText = Value
        End Set
    End Property
    <Bindable(True), Category("Appearance"), DefaultValue("")> Property EventTarget() As String
        Get
            If (_eventTarget Is Nothing) Then Return String.Empty
            Return _eventTarget
        End Get

        Set(ByVal Value As String)
            _eventTarget = Value
        End Set
    End Property
    <Bindable(True), Category("Appearance"), DefaultValue("")> Property EventArgument() As String
        Get
            If (_eventArgument Is Nothing) Then Return String.Empty
            Return _eventArgument
        End Get

        Set(ByVal Value As String)
            _eventArgument = Value
        End Set
    End Property
	<Bindable(True), Category("Appearance"), DefaultValue("")> Property TitleText() As String
		' il titolo della maschera deve essere memorizzato tra i postback --> lo metto nel viewstate
		Get
			Dim o As Object = ViewState.Item("CH_TitleText")
			If o Is Nothing Then Return String.Empty
			Return DirectCast(o, String)
		End Get

		Set(ByVal Value As String)
			viewstate.Item("CH_TitleText") = Value
		End Set
	End Property
	<Bindable(True), Category("Appearance"), DefaultValue("")> Property DataSource() As DataSet
		Get
			If (_dataSource Is Nothing) Then Return Nothing
			Return _dataSource
		End Get

		Set(ByVal Value As DataSet)
			_dataSource = Value
		End Set
	End Property

	<Bindable(True), Category("Appearance"), DefaultValue("")> Property MustSave() As Boolean
		Get
			If Not _dataSource Is Nothing AndAlso _dataSource.HasChanges Then Return True
			Return _mustSave
		End Get

		Set(ByVal Value As Boolean)
			_mustSave = Value
		End Set
	End Property

	<Bindable(True), Category("Appearance"), DefaultValue("")> Property MustSaveMessage() As String
		Get
			If Not ViewState("CH_mustSaveMessage") Is Nothing Then
				Return DirectCast(ViewState("CH_mustSaveMessage"), String)
			End If

			Dim msg As String
			If (CultureInfo.CurrentCulture.Name.ToUpper() = "IT-IT") Then
				msg = "Alcune modifiche non sono state salvate: sei sicuro di voler cambiare pagina ?"
			Else
				msg = "Some changes are not saved: do you really want to leave this page ?"
			End If
			Return msg
		End Get

		Set(ByVal Value As String)
			ViewState("CH_mustSaveMessage") = Value
		End Set
	End Property

	Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
		MyBase.OnPreRender(e)

		Dim nl As String = Environment.NewLine

		If (Not Page.IsStartupScriptRegistered("ClientHelp_StartupScript")) Then

			If Not Page.Session("IdUtente") Is Nothing Then

				Dim today As DateTime = DateTime.Now
				If Not Page.Session("LoginTime") Is Nothing Then
					today = DirectCast(Page.Session("LoginTime"), DateTime)
				End If

				Dim tupdate As DateTime = DateTime.Now
				If Not Page.Session("LastUpdate") Is Nothing Then
					tupdate = DirectCast(Page.Session("LastUpdate"), DateTime)
				End If


				If (CultureInfo.CurrentCulture.Name.ToUpper() = "IT-IT") Then
					_userInfo = "Id. Utente: " + Page.Session("IdUtente").ToString + " / Id. Operatore: " + Page.Session("IdOperatore").ToString + "\n\r"
					_userInfo += "Oggi e` " + today.ToLongDateString + "\n\r"
					_userInfo += "Ultimo Aggiornamento: " + tupdate.ToLongTimeString
				Else
					_userInfo = "User Id: " + Page.Session("IdUtente").ToString + " Operator Id: " + Page.Session("IdOperatore").ToString + "\n\r"
					_userInfo += "Today is " + today.ToLongDateString + "\n\r"
					_userInfo += "Last Update: " + tupdate.ToLongTimeString
				End If
			Else
				_userInfo = String.Empty
			End If

			Dim s As String = String.Empty
			s += "<SCRIPT>" + nl
			s += "var timer;" + nl
			s += "var oBody	=	document.body;" + nl
			s += "var oFrame =	parent.document.all('embeddedFrame');" + nl
			s += "function do_Alert()" + nl
			s += "{" + nl
			s += "  clearTimeout(timer);" + nl
			s += "  alert(document.getElementById('CH_alertHidden').value);" + nl
			s += "}" + nl
			s += "function do_PostBack()" + nl
			s += "{" + nl
			s += "  clearTimeout(timer);" + nl
			s += "  __doPostBack(document.getElementById('CH_eventTarget').value,document.getElementById('CH_eventArgument').value);" + nl
			s += "}" + nl
			s += "if (document.getElementById('CH_alertHidden') != null && document.getElementById('CH_alertHidden').value != '')" + nl
			s += "{" + nl
			s += "  timer=setTimeout('do_Alert();', 10);" + nl
			s += "}" + nl
			s += "if (document.getElementById('CH_confirmHidden') != null && document.getElementById('CH_confirmHidden').value != '')" + nl
			s += "{" + nl
			s += "	if (confirm(document.getElementById('CH_confirmHidden').value))" + nl
			s += "  {" + nl
			s += "      timer = setTimeout('do_PostBack();', 10);" + nl
			s += "  }" + nl
			s += "}" + nl
			s += "if (oFrame != null && oBody != null)" + nl
			s += "{" + nl
			s += "  if (oFrame.runtimeStyle.height != oBody.scrollHeight + (oBody.offsetHeight -" + nl
			s += "								oBody.clientHeight) + 20)" + nl
			s += "  {" + nl
			s += " 	    oFrame.runtimeStyle.height = oBody.scrollHeight + (oBody.offsetHeight -" + nl
			s += "								oBody.clientHeight) + 20;" + nl
			s += "  }" + nl
			's += "  if (oFrame.runtimeStyle.width != oBody.scrollWidth + (oBody.offsetWidth -" + nl
			's += "								oBody.clientWidth))" + nl
			's += "  {" + nl
			's += " 	    oFrame.runtimeStyle.width = oBody.scrollWidth + (oBody.offsetWidth -" + nl
			's += "								oBody.clientWidth);" + nl
			's += "  }" + nl
			s += "}" + nl
			s += "if (parent != null && parent.document != null && parent.document.all('divUser') != null)" + nl
			s += "{" + nl
			s += "  parent.document.all('divUser').innerText='" + _userInfo + "';" + nl
			s += "  parent.document.all('divUser').style.display='block';" + nl
			s += "  parent.document.all('divTitle').innerText=document.getElementById('CH_titleHidden').value;" + nl
			s += "	parent.document.all('divTitle').style.display='block';" + nl
			s += "}" + nl
			s += "else " + nl
			s += "{" + nl
			s += "  if (document.all('divUser') != null)" + nl
			s += "  {" + nl
			s += "      document.all('divUser').innerText='" + _userInfo + "';" + nl
			s += "      document.all('divUser').style.display='block';" + nl
			s += "      document.all('divTitle').innerText=document.getElementById('CH_titleHidden').value;" + nl
			s += "	    document.all('divTitle').style.display='block';" + nl
			s += "  }" + nl
			s += "}" + nl
			's += "alert('titolo:' + document.getElementById('CH_titleHidden').value);"
			s += "</SCRIPT>" + nl

			Page.RegisterStartupScript("ClientHelp_StartupScript", s)

			Page.RegisterHiddenField("CH_alertHidden", AlertText)
			Page.RegisterHiddenField("CH_confirmHidden", ConfirmText)
			Page.RegisterHiddenField("CH_eventTarget", EventTarget)
			Page.RegisterHiddenField("CH_eventArgument", EventArgument)
			Page.RegisterHiddenField("CH_titleHidden", TitleText)
			Page.RegisterHiddenField("CH_mustSave", MustSave.ToString)
			Page.RegisterHiddenField("CH_mustSaveMessage", MustSaveMessage)

			'Page.RegisterHiddenField("CH_innerText", _innerText.ToString)

			' funzioni lato clienti da chiamare quando 
			' 1) bisogna abbandonare la pagina senza modifiche: il bottone deve chiamare prima della submit CheckMustSave
			' 2) si fanno delle modifiche alla pagina che non generano eventi di submit --> dico coumnque
			'    che la pagina e` da salvare. Poi o un bottone lato cliente (1) o il menu` chiederanno se bisogna abbandonare la pagina
			Dim sss As String = ""
			sss += "<SCRIPT>" + nl
			sss += "function CheckMustSave()" + nl
			sss += "{ " + nl
			sss += "	var chms = document.getElementById('CH_mustSave');" + nl
			sss += "	if (chms != null && chms.value == 'True') " + nl
			sss += "	{ " + nl
			sss += "		var chmsg = document.getElementById('CH_mustSaveMessage');" + nl
			sss += "		var message;" + nl
			sss += "		if (chmsg != null && chmsg.value != null) " + nl
			sss += "			message = chmsg.value; " + nl
			sss += "		else " + nl
			sss += "			message = '" + Me.MustSaveMessage + "';" + nl
			sss += "		return confirm(message);" + nl
			sss += "	}" + nl
			sss += "	return true;" + nl
			sss += "}" + nl
			sss += nl
			sss += "function SetMustSave()" + nl
			sss += "{ " + nl
			sss += "	var chms = document.getElementById('CH_mustSave');" + nl
			sss += "	if (chms != null)" + nl
			sss += "		chms.value = 'True';" + nl
			sss += "}" + nl
			sss += "</SCRIPT>" + nl
			Page.RegisterClientScriptBlock("ClientHelp_CheckSetMustSave", sss)
		End If

	End Sub


	Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
		If Not Me.Site Is Nothing AndAlso Me.Site.DesignMode Then
			output.Write("[ClientHelp (visible when DesignMode is '" & Me.Site.DesignMode.ToString & "')]")
		End If
	End Sub

	Public Sub New()
		'
	End Sub

	' bisogna fare MOLTA attenzione:
	' CH_mustSave puo` essere stato modificato lato cliente.
	' Quando arrivo qui leggo il valore lato cliente e lo memorizzo in MustSave
	' Poi forse a fronte di questo evento verra` chiamata una callback:
	' 1) si fa save --> bisogna resettare MustSave; al prossimo evento nella pagina non dovro` piu` salvare
	' 2) non si fa save --> MustSave NON viene toccato (es qualche evento di pagina per aprire dettagli);
	'    mantengo il flag (dato che poi faccio il render per rimettere nell'hidden il valore di MustSave)
	Private Sub ClientHelp_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		If Page.IsPostBack AndAlso MustSave = False Then
			If (Page.Request.Form.Item("CH_mustSave") = "True") Then
				MustSave = True
			End If
		End If
	End Sub
End Class
