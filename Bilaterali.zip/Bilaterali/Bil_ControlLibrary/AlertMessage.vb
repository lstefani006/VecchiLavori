Imports System.ComponentModel
Imports System.Web.UI

<DefaultProperty("Text"), ToolboxData("<{0}:AlertMessage runat=server></{0}:AlertMessage>")> _
Public Class AlertMessage
	Inherits System.Web.UI.WebControls.WebControl

	Dim _alertText As String

	<Bindable(True), Category("Appearance"), DefaultValue("")> Property AlertText() As String
		Get
			If (_alertText Is Nothing) Then Return String.Empty
			Return _alertText
		End Get

		Set(ByVal Value As String)
			_alertText = Value
		End Set
	End Property

	Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
		MyBase.OnPreRender(e)

		If (Not Page.IsStartupScriptRegistered("AlertMessage_script")) Then
			Dim nl = Environment.NewLine

			Dim s As String = String.Empty
			s += "<SCRIPT>" + nl
			s += "if (document.getElementById('AlertMessage_hidden') != null && document.getElementById('AlertMessage_hidden').value != '')" + nl
			s += "{" + nl
			s += "	alert(document.getElementById('AlertMessage_hidden').value);" + nl
			s += "}" + nl
			s += "</SCRIPT>" + nl

			Page.RegisterStartupScript("AlertMessage_script", s)
			Page.RegisterHiddenField("AlertMessage_hidden", _alertText)
		End If

	End Sub


	Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
		If Not Me.Site Is Nothing AndAlso Me.Site.DesignMode Then
			output.Write("[AlertText (poi vado via)]")
		End If
	End Sub

End Class
