Imports System.ComponentModel
Imports System.Web.UI
Imports System.Globalization

<DefaultProperty("Text"), ToolboxData("<{0}:PopupCalendar runat=server></{0}:PopupCalendar>")> _
Public Class PopupCalendar
	Inherits System.Web.UI.WebControls.WebControl



	Dim _IdText As String
	<Bindable(True), Category("Settings"), DefaultValue("")> Property IDText() As String
		Get
			Return _IdText
		End Get

		Set(ByVal Value As String)
			_IdText = Value
		End Set
	End Property

	Dim _IdAnchor As String
	<Bindable(True), Category("Settings"), DefaultValue("")> Property IDAnchor() As String
		Get
			Return _IdAnchor
		End Get

		Set(ByVal Value As String)
			_IdAnchor = Value
		End Set
	End Property


	Dim _bUseDiv As Boolean
	<Bindable(True), Category("Settings"), DefaultValue("False")> Property UseDIV() As Boolean
		Get
			Return _bUseDiv
		End Get

		Set(ByVal Value As Boolean)
			_bUseDiv = Value
		End Set
	End Property

	Dim _pathCalendar As String
	<Bindable(True), Category("Settings"), DefaultValue("False")> Property PathPopupCalendar() As String
		Get
			Return _pathCalendar
		End Get

		Set(ByVal Value As String)
			_pathCalendar = Value
		End Set
	End Property


	Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)

		If Not Me.Page.IsClientScriptBlockRegistered("PopupCalendar_scripts") Then
			Dim nl As String = Environment.NewLine

			Dim s As String = String.Empty
			If _pathCalendar Is Nothing Then
				s += "<SCRIPT language=""JavaScript"" src=""PopupCalendar/PopupCalendar.js""></SCRIPT>" + nl
			Else
				s += "<SCRIPT language=""JavaScript"" src=""" + _pathCalendar + "/PopupCalendar.js""></SCRIPT>" + nl
			End If

			s += "<SCRIPT language=""javascript"" >" + nl
			If _bUseDiv Then
				s += "var cal = new CalendarPopup('PopupCalendar_Div');" + nl
			Else
				s += "var cal = new CalendarPopup();" + nl
			End If

			If (CultureInfo.CurrentCulture.Name.ToUpper() = "IT-IT") Then
				s += "cal.setWeekStartDay(1); // week is Monday - Saturday" + nl
				s += "cal.setMonthNames(""Gennaio"", ""Febbraio"", ""Marzo"", ""Aprile"", ""Maggio"", ""Giugno"", ""Luglio"", ""Agosto"", ""Settembre"", ""Ottobre"", ""Novembre"", ""Dicembre"");" + nl
				s += "cal.setDayHeaders(""D"",""L"",""M"", ""m"", ""G"", ""V"", ""S"");" + nl
				s += "cal.setTodayText(""Oggi"");" + nl
			End If
			s += "cal.showNavigationDropdowns();" + nl
			s += "cal.setCssPrefix('PopupCalendar');" + nl
			s += "</SCRIPT>"

			Page.RegisterClientScriptBlock("PopupCalendar_scripts", s)
		End If




			'If Not Me.Page.IsClientScriptBlockRegistered("PopupCalendar_scripts") Then
			'          Dim nl As String = Environment.NewLine

			'	Dim s As String = String.Empty
			'	If _pathCalendar Is Nothing Then
			'		s += "<SCRIPT language=""JavaScript"" src=""PopupCalendar/PopupCalendar.js""></SCRIPT>" + nl
			'	Else
			'		s += "<SCRIPT language=""JavaScript"" src=""" + _pathCalendar + "/PopupCalendar.js""></SCRIPT>" + nl
			'	End If
			'	s += "<SCRIPT language=""javascript"" >" + nl
			'	s += "document.write(getCalendarStyles());" + nl
			'	s += "function PopupCalendar_OnClick(cal, elementID, anchor)" + nl
			'	s += "{" + nl
			'	s += "	var n = 'PopupCalendar_div';" + nl
			'	s += "	if (document.getElementById(n) == null)" + nl
			'	s += "	{" + nl
			'	s += "		var db = document.body;" + nl
			'	s += "		var dd = document.createElement(""<DIV ID="" + n + "" STYLE='Z-INDEX:999;position:absolute;visibility:hidden;background-color:white;layer-background-color:white;'></DIV>"");" + nl
			'	s += "		document.body.appendChild(dd);" + nl
			'	s += "	}" + nl
			'	s += nl
			'	s += "	if (cal == null)" + nl
			'	s += "	{" + nl
			'	s += "		cal = new CalendarPopup(n);" + nl
			'	s += "	}" + nl
			'	s += "	cal.showNavigationDropdowns();" + nl

			'	If (CultureInfo.CurrentCulture.Name.ToUpper() = "IT-IT") Then
			'		s += "	cal.setWeekStartDay(1); // week is Monday - Saturday" + nl
			'		s += "	cal.setMonthNames(""Gennaio"", ""Febbraio"", ""Marzo"", ""Aprile"", ""Maggio"", ""Giugno"", ""Luglio"", ""Agosto"", ""Settembre"", ""Ottobre"", ""Novembre"", ""Dicembre"");" + nl
			'		s += "	cal.setDayHeaders(""D"",""L"",""M"", ""m"", ""G"", ""V"", ""S"");" + nl
			'		s += "	cal.setTodayText(""Oggi"");" + nl
			'		s += "	var dateFormat = 'd/M/y';" + nl
			'	Else
			'		s += "	var dateFormat = 'M/d/y';" + nl
			'	End If

			'	s += "	var e = document.getElementById(elementID);" + nl
			'	s += "	cal.select(e, anchor, dateFormat);" + nl
			'	s += "	return cal;" + nl
			'	s += "}" + nl
			'	s += "</SCRIPT>"

			'	Page.RegisterClientScriptBlock("PopupCalendar_scripts", s)
			'End If
	End Sub


	Protected Overrides Sub Render(ByVal w As System.Web.UI.HtmlTextWriter)

		If (_IdText Is Nothing) Then
			w.WriteLine("Insert ID Text")
			Return
		End If

		' <A HREF="#" NAME="anchor1x" ID="anchor1x" onClick="cal.select(document.forms[0].date1x,'anchor1x','d/M/y'); return false;"><img src="SmallCalendar.gif" border="0"/></A>
		w.AddAttribute("HREF", "#")
		w.AddAttribute("NAME", Me.ClientID)
		w.AddAttribute("ID", Me.ClientID)

		' testo da cui prendere/settare la data nel calendario (vuole il puntatore al testo)
		Dim e As String = String.Format("document.getElementById('{0}')", _IdText)
		' controllo a cui ancorarsi (vuole una stringa)
		Dim a As String = _IdText
		If Not _IdAnchor Is Nothing AndAlso _IdAnchor <> String.Empty Then
			a = _IdAnchor
		End If

		Dim s As String
		If (CultureInfo.CurrentCulture.Name.ToUpper() = "IT-IT") Then
			s = String.Format("cal.select({0}, '{1}', 'd/M/y'); return false;", e, a)
		Else
			s = String.Format("cal.select({0}, '{1}', 'M/d/y'); return false;", e, a)
		End If
		w.AddAttribute("onClick", s)

		Me.AddAttributesToRender(w)
		w.RenderBeginTag("A")
		If (True) Then
			'<img src="SmallCalendar.gif" border="0"/>
			If (_pathCalendar Is Nothing) Then
				w.AddAttribute("src", "PopupCalendar/PopupCalendar.gif")
			Else
				w.AddAttribute("src", Me._pathCalendar + "/PopupCalendar.gif")
			End If
			w.AddAttribute("border", "0")
			w.RenderBeginTag("IMG")
			w.RenderEndTag()
		End If
		w.RenderEndTag()


		'	Dim cal As String = "cal_" + Me.ClientID
		'	w.WriteLine("<SCRIPT LANGUAGE=""JavaScript"">")
		'	If (_bUseDiv = False) Then
		'		w.WriteLine("var " + cal + " = new CalendarPopup();")
		'	Else
		'		w.WriteLine("var " + cal + " = null;")
		'	End If


		'	w.WriteLine("</SCRIPT>")


		'	' <A HREF="#" NAME="anchor1x" ID="anchor1x" onClick="cal.select(document.forms[0].date1x,'anchor1x','d/M/y'); return false;"><img src="SmallCalendar.gif" border="0"/></A>
		'	w.AddAttribute("HREF", "#")
		'	w.AddAttribute("NAME", Me.ClientID)
		'	w.AddAttribute("ID", Me.ClientID)
		'	'		w.AddAttribute("onClick", cal + ".select(document.forms[0]." + _IdText + ",'" + Me.ClientID + "','d/M/y'); return false;")
		'	w.AddAttribute("onClick", cal + " = PopupCalendar_OnClick(" + cal + ", '" + _IdText + "' , '" + Me.ClientID + "'); return false;")
		'	Me.AddAttributesToRender(w)
		'	w.RenderBeginTag("A")
		'	If (True) Then
		'		'<img src="SmallCalendar.gif" border="0"/>
		'		If (_pathCalendar Is Nothing) Then
		'			w.AddAttribute("src", "PopupCalendar/PopupCalendar.gif")
		'		Else
		'			w.AddAttribute("src", Me._pathCalendar + "/PopupCalendar.gif")
		'		End If
		'		w.AddAttribute("border", "0")
		'		w.RenderBeginTag("IMG")
		'		w.RenderEndTag()
		'	End If
		'	w.RenderEndTag()
	End Sub

End Class

