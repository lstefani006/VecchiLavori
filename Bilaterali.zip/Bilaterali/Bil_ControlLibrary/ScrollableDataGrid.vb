Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls

<ToolboxData("<{0}:ScrollableDataGrid runat=server></{0}:ScrollableDataGrid>")> _
Public Class ScrollableDataGrid
    Inherits System.Web.UI.WebControls.DataGrid

    Sub New()
        MyBase.New()
        MyBase.Width = New Unit(100, UnitType.Percentage)
        MyBase.Height = New Unit(0, UnitType.Percentage)

        Me.HeaderStyle.CssClass = "Bil_DataGrid_Header"
        Me.ItemStyle.CssClass = "Bil_DataGrid_Item"
        Me.PagerStyle.CssClass = "Bil_DataGrid_Pager"
        Me.FooterStyle.CssClass = "Bil_DataGrid_Footer"
        Me.AlternatingItemStyle.CssClass = "Bil_DataGrid_Alternating"
        Me.EditItemStyle.CssClass = "Bil_DataGrid_Edit"
        Me.SelectedItemStyle.CssClass = "Bil_DataGrid_Selected"
    End Sub


    Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
        Dim scrollPos As String = "0"

        MyBase.OnPreRender(e)
        If Page.IsPostBack Then scrollPos = Page.Request(ClientID & "ScrollPos")
        Page.RegisterHiddenField(ClientID & "ScrollPos", scrollPos)

        'Dim sc As String = _
        '"<script language=""javascript""><!-- " & _
        '"function elementLoad() { " & _
        '"element.scrollTop = element.document.all[persistID].value; " & _
        '"element.attachEvent(""onscroll"", saveScroll)" & _
        '"} " & _
        '"function saveScroll() { " & _
        '"element.document.all[persistID].value =  event.srcElement.scrollTop; }" & _
        '" --> </script>"
        'If Not Me.Page.IsClientScriptBlockRegistered("ScrollableDataGrid_scripts") Then
        '    Page.RegisterClientScriptBlock("ScrollableDataGrid_scripts", sc)
		'End If

        'If (Me.EnableViewState = False) Then
        '	Page.RegisterHiddenField(ClientID & "_EditItemIndex", Me.EditItemIndex.ToString())
        '	Page.RegisterHiddenField(ClientID & "_CurrentPageIndex", Me.CurrentPageIndex.ToString())

        '	If (TypeOf Me.DataSource Is DataView) Then
        '		Dim dv As DataView = DirectCast(Me.DataSource, DataView)
        '		Page.RegisterHiddenField(ClientID & "_Sort", dv.Sort)
        '	End If

        'End If

	End Sub

    Dim _sp As String
    <Bindable(True), Category("Apparence")> _
    Public Property BehaviorFile() As String
        Get
            Return _sp
        End Get
        Set(ByVal Value As String)
            _sp = Value
        End Set
    End Property


    <Bindable(True), Category("Apparence")> _
    Public Overrides Property Width() As Unit
        Get
            Return w
        End Get
        Set(ByVal Value As Unit)
            w = Value
        End Set
    End Property

    <Bindable(True), Category("Apparence")> _
    Public Overrides Property Height() As Unit
        Get
            Return h
        End Get
        Set(ByVal Value As Unit)
            h = Value
        End Set
    End Property

    Protected w As New Unit(100)
    Protected h As New Unit(100)

	Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
		If _sp Is Nothing Then
			output.WriteLine("BehaviorFile not set")
			Return
		End If

        ' Create elements


        '' Get column widths
        'Dim rgWidths(Me.Columns.Count) As Double
        'Dim iCol As Integer
        'For iCol = 0 To Me.Columns.Count
        '    rgWidths(iCol) = Me.Columns(iCol).ItemStyle.Width.Value
        'Next

        Dim originalStyle As String = MyBase.Attributes("style")

        Dim ss() As String = originalStyle.Split(New [Char]() {";"c, ":"c})

        Dim dgStyle As String = ""
        For i As Int32 = 0 To ss.Length - 1 Step 2
            Select Case ss(i).Trim(" "c).ToUpper()
                Case "LEFT"
                    dgStyle &= "LEFT: 0px;"
                    output.AddStyleAttribute("LEFT", ss(i + 1))
                Case "POSITION"
                    dgStyle &= "POSITION: absolute;"
                    output.AddStyleAttribute("POSITION", ss(i + 1))
                Case "TOP"
                    dgStyle &= "TOP: 0px;"
                    output.AddStyleAttribute("TOP", ss(i + 1))
                Case "Z-INDEX"
                    dgStyle &= ss(i) & ": " & ss(i + 1) & ";"
                    output.AddStyleAttribute("Z-INDEX", ss(i + 1))
                Case " "
                Case Else
                    dgStyle &= ss(i)
                    If (i + 1 < ss.Length - 1) Then dgStyle &= ": " & ss(i + 1) & ";"
            End Select
        Next

        'output.AddStyleAttribute("OVERFLOW-Y", "scroll")
        output.AddStyleAttribute("OVERFLOW", "scroll")
        output.AddStyleAttribute("WIDTH", Me.Width.ToString())
        output.AddStyleAttribute("HEIGHT", Me.Height.ToString())
        output.AddStyleAttribute("vertical-align", "top")
        output.AddStyleAttribute("BEHAVIOR", "url('" & _sp & "')")
        output.AddStyleAttribute("BORDER", "black 1px solid")

        output.AddAttribute("persistID", ClientID & "ScrollPos")

        output.RenderBeginTag("DIV")

        MyBase.Attributes("style") = dgStyle

        output.Indent += 1
        MyBase.Render(output)
        output.Indent -= 1

        MyBase.Attributes("style") = originalStyle

        output.RenderEndTag()

    End Sub

	Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        MyBase.OnLoad(e)
        'If (Me.EnableViewState = False) Then

        '	If (Page.IsPostBack) Then
        '		Me.EditItemIndex = Integer.Parse(Page.Request(ClientID & "_EditItemIndex"))
        '		Page.RegisterHiddenField(ClientID & "_EditItemIndex", Me.EditItemIndex.ToString())

        '		Me.CurrentPageIndex = Integer.Parse(Page.Request(ClientID & "_CurrentPageIndex"))
        '		Page.RegisterHiddenField(ClientID & "_CurrentPageIndex", Me.CurrentPageIndex.ToString())


        '		If (TypeOf Me.DataSource Is DataView) Then
        '			Dim dv As DataView = DirectCast(Me.DataSource, DataView)
        '			dv.Sort = Page.Request(ClientID & "_Sort")
        '		End If
        '	End If
        'End If

	End Sub
End Class
