use Bilaterali

declare @Operatore as varchar(16),
	@di as datetime,
	@df as datetime

set @Operatore = 'IDAU'
set @di = '11/24/2004'
set @df = '11/24/2004'

-- SELECT *, 
-- ISNULL(T.TotaleUnita, 0) AS TotaleUnitaContratto, 
-- ISNULL(T.TotaleUnita, 0) AS TotaleUnitaContratto 
-- FROM 
-- (
SELECT *, 0 as TotaleUnitaContratto, 0 as TotaleUnitaContratto
FROM dbo.Bil_ContrattoOperatore 
WHERE (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDCCedente = @Operatore) 
AND (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) 
AND (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) 
OR (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) 
AND (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) 
AND (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDCAcquirente = @Operatore) 
OR (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) 
AND (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) 
AND (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDC = @Operatore)
--)C 
-- LEFT OUTER JOIN 
-- (
-- SELECT Contratto.IdContratto, COUNT(*) TotaleUnita 
-- FROM dbo.tab_UnitaContratto(@di) UnitaContratto, Contratto 
-- WHERE Contratto.IdContratto = UnitaContratto.IdContratto 
-- AND (Contratto.CodiceOperatoreSDCCedente = @Operatore 
-- AND UnitaContratto.UnitaAssegnataOpCedente = 1 
-- OR Contratto.CodiceOperatoreSDCAcquirente = @Operatore 
-- AND UnitaContratto.UnitaAssegnataOpAcquirente = 1) 
-- GROUP BY Contratto.IdContratto
-- ) T 
-- ON T.IdContratto = C.IdContratto 
-- WHERE (1 = 1)

--', N'@Operatore nvarchar(4000),@di datetime,@df datetime', @Operatore = N'IDAU', @di = 'dic  1 2004 12:00:00:000AM', @df = 'dic  1 2004 12:00:00:000AM'

