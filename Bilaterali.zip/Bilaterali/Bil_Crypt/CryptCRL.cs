using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Text;

namespace CertPInvokeLib
{
	/// <summary>
	/// Summary description for CryptCRL.
	/// </summary>
	public class CryptCRL
	{

		public enum CrlDownloadType  
		{
			CacheCrlDownloadOnly,
			NetworkCrlDownloadOnly,
			CacheOrNetworkCrlDownload
		};

		public enum CrlReasonCode
		{
			unspecified   = 0,
			keyCompromise = 1,
			cACompromise  = 2,
		    affiliationChanged = 3,
			superseded		= 4,
		    cessationOfOperation = 5,
		    certificateHold = 6,
			removeFromCRL = 8
		};

		public class CRLEntry
		{
			public byte [] serialNumber;
			public DateTime revocationDate;
			public CrlReasonCode reason;
		} 

		private CRLEntry [] crlData;
		private string crlIssuer;
		private DateTime crlCurrentTime;
		private DateTime crlNextTime;
		private byte [] crlRawData;
 

		internal void SetDefault()
		{
			crlData = null;
			crlIssuer = "";
			crlCurrentTime = DateTime.MinValue;
			crlNextTime = DateTime.MinValue;
			crlRawData = null;
		}

		/// <summary>
		///   Costruttore di default (non genera eccezioni)
		/// </summary>
		public CryptCRL()
		{
			SetDefault();
		}


		/// <summary>
		///		CryptCRL(): costruttore che utilizza un byte array
		///     con il content della CRL (utilizza una funzione simile a
		///     CertCreateCertificateContext per il certificato)
		/// </summary>
		/// <param name="crlData"></param>
		public CryptCRL(byte [] crlData)
		{
			IntPtr pCRLContext;
			SetDefault();
			pCRLContext = WinCapi.CertCreateCRLContext(
				WinCapi.X509_ASN_ENCODING,
				crlData,
				(uint) crlData.Length);

			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CertCreateCRLContext: cannot create from bytearray");

			try
			{
				BuildFromContext(pCRLContext);
			}
			catch (CertException cEx)
			{
				SetDefault();
				Close(ref pCRLContext);
				throw cEx;
			}
			catch (Exception nEx)
			{
				SetDefault();
				Close(ref pCRLContext);
				throw nEx;
			}
			Close(ref pCRLContext);
		}

		/// <summary>
		///   BuildFromContext: carica CRL a partire dal contesto
		/// </summary>
		/// <param name="pCRLContext"></param>
		internal void BuildFromContext(IntPtr pCRLContext)
		{
			loadAllCRLData(pCRLContext, true, out crlCurrentTime, out crlNextTime, out crlData);
			crlIssuer = loadCRLIssuerName(pCRLContext);
			crlRawData = EncodeCRLContext(pCRLContext);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="urlDistPoint"></param>
		/// <param name="cDownload"></param>
		/// <param name="secTmo"></param>
		public CryptCRL(string urlDistPoint, CrlDownloadType cDownload, int secTmo)
		{
			Connect(urlDistPoint, cDownload, secTmo);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="urlDistPoint"></param>
		/// <param name="cDownload"></param>
		/// <param name="secTmo"></param>
		public void Connect(string urlDistPoint, CrlDownloadType cDownload, int secTmo)
		{
			SetDefault();
			uint dwFlags =0;
			IntPtr pCRLContext;

			unsafe
			{
				void *q;
				IntPtr hp = new IntPtr(&q);
				bool bRes = false;
				int timeout = 0;

				switch (cDownload)
				{
					case CrlDownloadType.CacheCrlDownloadOnly:
						dwFlags = WinCapi.CRYPT_CACHE_ONLY_RETRIEVAL;
						break;
					case CrlDownloadType.NetworkCrlDownloadOnly:
						dwFlags = WinCapi.CRYPT_WIRE_ONLY_RETRIEVAL;
						timeout = 1000 *  secTmo;
						break;
					case CrlDownloadType.CacheOrNetworkCrlDownload:
						dwFlags = WinCapi.CRYPT_CACHE_ONLY_RETRIEVAL;  // prova prima a downloadare CRL con Cache: se non esiste
						timeout = 1000 *  secTmo;
						break;
				}
				bRes = WinCapi.CryptRetrieveObjectByUrlW(urlDistPoint,  WinCapi.CONTEXT_OID_CRL,
																		dwFlags, 
																		(uint)timeout, hp, 
																		IntPtr.Zero, 
																		IntPtr.Zero, 
																		IntPtr.Zero, 
																		IntPtr.Zero);
				if (bRes == false)
				{
					//
					// Download non OK su Cached CRL ... prova con Network
					//
					if (cDownload == CrlDownloadType.CacheOrNetworkCrlDownload)
					{
						dwFlags = WinCapi.CRYPT_WIRE_ONLY_RETRIEVAL;
						bRes = WinCapi.CryptRetrieveObjectByUrlW(urlDistPoint,  WinCapi.CONTEXT_OID_CRL,
							dwFlags, 
							(uint)timeout, hp, 
							IntPtr.Zero, 
							IntPtr.Zero, 
							IntPtr.Zero, 
							IntPtr.Zero);
					}
				}
				else
				{
					//
					// Download OK su Cached CRL ... nel caso  controlla che non sia scaduta 
					// altrimenti prova il download da rete
					//
					if (cDownload == CrlDownloadType.CacheOrNetworkCrlDownload)
					{
						IntPtr crlContext = new IntPtr(q);
						DateTime currentCRLTime;
						DateTime nextCRLTime;
						InnerGetCRLDataTimeOnly(crlContext, out currentCRLTime, out nextCRLTime);
						DateTime localTime = DateTime.Now;

						if ((localTime <currentCRLTime) || (localTime > nextCRLTime))
						{

							//
							// rilascia la vecchia CRL che e' scaduta 
							//
							bRes = WinCapi.CertFreeCRLContext(crlContext);
							if (bRes == false)
								throw new CertException("CertFreeCRLContext");

							//
							//	Cached CRL scaduta: download CRL da rete
							//
							dwFlags = WinCapi.CRYPT_WIRE_ONLY_RETRIEVAL;
							bRes = WinCapi.CryptRetrieveObjectByUrlW(urlDistPoint,  WinCapi.CONTEXT_OID_CRL,
								dwFlags, 
								(uint)timeout, hp, 
								IntPtr.Zero, 
								IntPtr.Zero, 
								IntPtr.Zero, 
								IntPtr.Zero);

						}
					}
				}

				if (bRes == false)
					throw new CertException("CryptRetrieveObjectByUrlW failure for URL:" + urlDistPoint);

				pCRLContext = new IntPtr(q);

				if (pCRLContext == IntPtr.Zero)
					throw new CertException("CryptRetrieveObjectByUrlW failure: invalid pointer");

				//
				// Carica i dati su variabili membro in modo da poter liberare in modo sicuro
				// il pointer 
				//
				try
				{
					BuildFromContext(pCRLContext);
				}
				catch (CertException cEx)
				{
					SetDefault();
					Close(ref pCRLContext);
					throw cEx;
				}
				catch (Exception nEx)
				{
					SetDefault();
					Close(ref pCRLContext);
					throw nEx;
				}
				Close(ref pCRLContext);
			}
		}

		private void InnerGetCRLDataTimeOnly(IntPtr crlContext, out DateTime currentTime, out DateTime nextTime)
		{
			if (crlContext == IntPtr.Zero)
				throw new CertException("CryptCRL.InnerGetCRLDataTimeOnly called with a closed CRL Context");
		
			WinCapi.CRL_CONTEXT Crl = new WinCapi.CRL_CONTEXT();
			Crl = (WinCapi.CRL_CONTEXT) Marshal.PtrToStructure(crlContext, typeof(WinCapi.CRL_CONTEXT));
			
			IntPtr CRLINFO = Crl.pCrlInfo;
			WinCapi.CRL_INFO CrlInfo = new WinCapi.CRL_INFO();
			CrlInfo = (WinCapi.CRL_INFO) Marshal.PtrToStructure(CRLINFO, typeof(WinCapi.CRL_INFO));

			currentTime = DateTime.FromFileTime(CrlInfo.ThisUpdate);
			nextTime = DateTime.FromFileTime(CrlInfo.NextUpdate);
		}


		public void GetCRLDataTimeOnly(out DateTime currentTime, out DateTime nextTime)
		{
			currentTime = crlCurrentTime;
			nextTime = crlNextTime;
		}


		public byte [] EncodeCRLContext()
		{
			return crlRawData;
		}
		

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		internal byte [] EncodeCRLContext(IntPtr pCRLContext)
		{

			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CryptCRL.EncodeCRLContext called with a closed CRL Context");

			unsafe
			{

				WinCapi.CRL_CONTEXT Crl = new WinCapi.CRL_CONTEXT();
				Crl = (WinCapi.CRL_CONTEXT) Marshal.PtrToStructure(pCRLContext, typeof(WinCapi.CRL_CONTEXT));

				uint cbEncoded =0;
				bool bRes = WinCapi.CryptEncodeObject(WinCapi.X509_ASN_ENCODING,
					WinCapi.X509_CERT_CRL_TO_BE_SIGNED,
					Crl.pCrlInfo,
					IntPtr.Zero,
					ref cbEncoded
					);

				byte [] cbContent = new byte[Crl.cbCrlEncoded];
				GCHandle hh = GCHandle.Alloc(cbContent, GCHandleType.Pinned);
				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(cbContent, 0);

				bRes = WinCapi.CryptEncodeObject(WinCapi.X509_ASN_ENCODING,
					WinCapi.X509_CERT_CRL_TO_BE_SIGNED,
					Crl.pCrlInfo,
					ptOutBuffer,
					ref cbEncoded
					);
				hh.Free();
				if (bRes == false)
				{
					throw new CertException("CryptCRL.EncodeCRLContext error getting bytearray");
				}
				if (cbEncoded != cbContent.Length)
				{
					byte [] rb = new byte [cbEncoded];
					for (int i = 0; i < cbEncoded; ++i)
						rb[i] = cbContent[i];
					cbContent = rb;
				}
				return cbContent;
			}
		}

		


		/// <summary>
		///		VerifyCRLSignature: controlla che la firma della CRL scaricata sia corretta in base
		///			al certificato dell'issuer il cui context e' fornito in input (DA VERIFICARE) 
		///			non e' detto che il certificato dell'issuer della CRL sia su uno degli store della
		///			macchina su cui gira ... potrebbe essere su file o byte array  
		/// </summary>
		/// <returns></returns>
		public bool VerifyCRLSignature(IntPtr pCertContext)
		{
			IntPtr pCRLContext;
			if ((crlRawData == null) || (crlRawData.Length == 0))
				throw new CertException("CryptCRL.VerifyCRLSignature called with a CRL not loaded");
			
			pCRLContext = WinCapi.CertCreateCRLContext(
				WinCapi.X509_ASN_ENCODING,
				crlRawData,
				(uint) crlRawData.Length);

			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CryptCRL.VerifyCRLSignature called with a null CRL Context");

			bool bRes = WinCapi.CryptVerifyCertificateSignatureEx(
									IntPtr.Zero,
									WinCapi.X509_ASN_ENCODING,
									WinCapi.CRYPT_VERIFY_CERT_SIGN_SUBJECT_CRL,
									pCRLContext,
									WinCapi.CRYPT_VERIFY_CERT_SIGN_ISSUER_CERT,  // CRYPT_VERIFY_CERT_SIGN_ISSUER_CERT se certificato
									pCertContext,								 // pCertContext	
									0,
									IntPtr.Zero);

			Close(ref pCRLContext);
			return bRes;
		}

		public string GetCRLIssuerName()
		{
			return crlIssuer;
		}
		

		/// <summary>
		///    GetCRLIssuerName: ottiene l'issuer di una CRL (estraendolo dai dati della CRL)
		///    in formato X.500 (CN= .... OU= ...) comma separated
		/// </summary>
		/// <returns></returns>

		internal string loadCRLIssuerName(IntPtr pCRLContext)
		{
			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CryptCRL.GetCRLIssuerName called with a closed CRL Context");

			unsafe
			{
				void *pCRL = pCRLContext.ToPointer();
				WinCapi.CRL_CONTEXT *pCrl = (WinCapi.CRL_CONTEXT *) pCRL;
			

				IntPtr CRLINFO = pCrl->pCrlInfo;
				WinCapi.CRL_INFO CrlInfo = new WinCapi.CRL_INFO();
				CrlInfo = (WinCapi.CRL_INFO) Marshal.PtrToStructure(CRLINFO, typeof(WinCapi.CRL_INFO));

				uint cbSize;
				string issuer;
				void *pIssuerBlob = &CrlInfo.Issuer;

				IntPtr pIntIssuer = new IntPtr(pIssuerBlob);

				//
				// ritorna size dell'issuer in formato X.500
				//
				cbSize = WinCapi.CertNameToStrA(WinCapi.MY_ENCODING_TYPE,
							pIntIssuer,
							WinCapi.CERT_X500_NAME_STR,
							IntPtr.Zero,
							0);

				byte [] Issuer = new byte[cbSize];
				GCHandle hh = GCHandle.Alloc(Issuer, GCHandleType.Pinned);
				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(Issuer, 0);

				for (int i=0; i< cbSize; i++)
					Issuer[i] = 0;
				//
				// ottiene issuer in formato X.500
				//
				cbSize = WinCapi.CertNameToStrA(WinCapi.MY_ENCODING_TYPE,
							pIntIssuer,
							WinCapi.CERT_X500_NAME_STR,
							ptOutBuffer,
							cbSize);
				hh.Free();
				issuer = Encoding.ASCII.GetString(Issuer,0, (int) cbSize);
				return issuer;
			}
		}


		public void GetAllCRLData(bool bGetCRLExtension, out DateTime currentTime, out DateTime nextTime, out CRLEntry [] crlEntries)
		{
			currentTime = crlCurrentTime;
		    nextTime	= crlNextTime;
			crlEntries = crlData;
			if (bGetCRLExtension == false)
			{
				//
				// resetta a 0 tutti i reason code
				//
				if ((crlEntries != null) && (crlEntries.Length>0))
				{
					int i;
					for (i=0; i<crlEntries.Length; i++)
						crlEntries[i].reason = 0;
				}
			}
		}

		/// <summary>
		///		
		/// </summary>
		/// <param name="bGetCRLExtension"></param>
		/// <param name="currentTime"></param>
		/// <param name="nextTime"></param>
		/// <param name="crlEntries"></param>
		internal void loadAllCRLData(IntPtr pCRLContext, bool bGetCRLExtension, out DateTime currentTime, out DateTime nextTime, out CRLEntry [] crlEntries)
		{
			crlEntries = null;
			currentTime = new DateTime();
			nextTime = new DateTime();
			
			if (pCRLContext == IntPtr.Zero)
				throw new CertException("CryptCRL.GetCRLData called with a closed CRL Context");

			unsafe
			{
				void *pCRL = pCRLContext.ToPointer();
				WinCapi.CRL_CONTEXT *pCrl = (WinCapi.CRL_CONTEXT *) pCRL;
			

				IntPtr CRLINFO = pCrl->pCrlInfo;
				WinCapi.CRL_INFO CrlInfo = new WinCapi.CRL_INFO();
				CrlInfo = (WinCapi.CRL_INFO) Marshal.PtrToStructure(CRLINFO, typeof(WinCapi.CRL_INFO));


			    currentTime = DateTime.FromFileTime(CrlInfo.ThisUpdate);
				nextTime = DateTime.FromFileTime(CrlInfo.NextUpdate);

				uint nCRLEntries = CrlInfo.cCRLEntry;
				crlEntries = new CRLEntry[nCRLEntries];

				//
				// Per la scansione dell'array di strutture ...
				//
				for (int i=0; i< nCRLEntries; i++)
				{
					void *currArrPtr = (void *)((int)(CrlInfo.rgCRLEntry).ToPointer() + i * sizeof(WinCapi.CRL_ENTRY));
					WinCapi.CRL_ENTRY CrlEntry = new WinCapi.CRL_ENTRY();
					CrlEntry = (WinCapi.CRL_ENTRY) Marshal.PtrToStructure(new IntPtr(currArrPtr), typeof(WinCapi.CRL_ENTRY));

					crlEntries[i] = new CRLEntry();
					crlEntries[i].revocationDate = DateTime.FromFileTime(CrlEntry.RevocationDate);

					//
					// scansione dei serial number ... forse c'e' un modo migliore per farlo
					//
					crlEntries[i].serialNumber = new byte[CrlEntry.SerialNumber.cbData];
					for (int j=0; j<CrlEntry.SerialNumber.cbData; j++)
					{
						void *currArrSerNumPtr = (void *)((int)(CrlEntry.SerialNumber.pbData).ToPointer() + j * sizeof(byte));
						crlEntries[i].serialNumber[j] = Marshal.ReadByte(new IntPtr(currArrSerNumPtr));
					}

					//
					// questo da' un carico ulteriore al parse della CRL: magari si puo' evitare 
					// visto che da quello che si vede tutti i certificati scaricati da TrustItalia
					// e molti di quelli GRTN/Actalis non hanno Extension (cioe' CrlEntry.cExtension = 0)
					//
					if (bGetCRLExtension)
					{
						if (CrlEntry.cExtension>0)
						{
							for (int l=0; l<CrlEntry.cExtension; l++)
							{
								void *currArrExt = (void *)((int)(CrlEntry.rgExtension).ToPointer() + l * sizeof(WinCapi.CERT_EXTENSION));
								WinCapi.CERT_EXTENSION CertExt = new WinCapi.CERT_EXTENSION();
								CertExt = (WinCapi.CERT_EXTENSION) Marshal.PtrToStructure(new IntPtr(currArrExt), typeof(WinCapi.CERT_EXTENSION));
								string szObjId = Marshal.PtrToStringAnsi(CertExt.pszObjId);

								if (szObjId == WinCapi.szOID_CRL_REASON_CODE)
								{
									int reason;
									uint cbBytes = 4;
									bool res = WinCapi.CryptDecodeObject(WinCapi.MY_ENCODING_TYPE, 
										szObjId,
										CertExt.Value.pbData,
										CertExt.Value.cbData, 
										0, 
										out reason, 
										ref cbBytes);

									if (res == false)
										throw new CertException("CryptCRL.GetCRLData cannot decode CRL extension");

									if (Enum.IsDefined(typeof(CrlReasonCode), reason))
										crlEntries[i].reason = (CrlReasonCode) reason;
									else
										crlEntries[i].reason = CrlReasonCode.unspecified;
									break;
								}
							}
						}
						else
						{
							crlEntries[i].reason = CrlReasonCode.unspecified;
						}
					}
					else
						crlEntries[i].reason = CrlReasonCode.unspecified;
				}
			}
		}

		internal void Close(ref IntPtr pCRLContext)
		{
			bool r;
			if (pCRLContext != IntPtr.Zero)
			{
				r = WinCapi.CertFreeCRLContext(pCRLContext);
				if (r == false)
					throw new CertException("CertFreeCRLContext");
				pCRLContext = IntPtr.Zero;
			}
		}
	}
}
