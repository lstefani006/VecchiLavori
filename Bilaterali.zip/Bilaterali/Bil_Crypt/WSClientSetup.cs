using System;
using System.Web.Services.Protocols;
using System.Configuration;
using System.Collections.Specialized;

namespace Bil_Crypt
{
	/// <summary>
	/// Summary description for WSClientSetup.
	/// </summary>
	public class WSClient
	{
		const string CurrentUserLocation =	"CurrentUser";
		const string LocalMachineLocation = "LocalMachine";

		public static void SetCertificatePolicy(TraceDelegate traceDelegate)
		{
			s_traceDelegate = traceDelegate;
			System.Net.ServicePointManager.CertificatePolicy = new TrustAllCertificatePolicy();
		}

		internal static void SetClientCertificate(SoapHttpClientProtocol ws, string CertIssuer, string CertSN, string CertPIN,
													string CertLocation, bool bUseMachineKeySet)
		{
			bool bStoreFound = true;
			bool bCertificateFound = false;
			CertPInvokeLib.CertX509Ex cert = null;
		
			//
			// Controlla preventivamente se Issuer/SN sono nulli
			//
			if ((CertIssuer == null) || (CertSN == null))
				return;
			//
			// Controlla preventivamente se Issuer/SN sono stringhe vuote
			//
			if ((CertIssuer == string.Empty) || (CertSN == string.Empty))
				return;

			try
			{
				//
				// cerca il certificato nello store CurrentUser o LocalMachine che
				// fa match con Issuer/SerialNumber
				//
				using (CertPInvokeLib.CertStore cs = new CertPInvokeLib.CertStore())
				{
					if (CertLocation == CurrentUserLocation)
						cs.OpenUserStore();
					else
						if (CertLocation == LocalMachineLocation)
						cs.OpenLocalMachineStore();
					else
						bStoreFound = false;

					if (bStoreFound)
					{
						int nCertificatesInStore = cs.CountCertificatesInStore();
						int index;
						for (index = 0; index<nCertificatesInStore; index++)
						{
							cert = cs.CertGetCertificateInStoreById(index);
							if (cert != null)
							{
								if ((cert.GetIssuerName() == CertIssuer) && 
									(cert.GetSerialNumberString() == CertSN))
								{
									bCertificateFound = true;
									break;
								}
								// cert.Dispose();
							}
						}
					}
				}

				//
				// Certificato trovato: setta PIN eventuale e aggiungi certificato 
				// al set di client certificates per l'accesso al WebService
				//
				if (bCertificateFound)
				{
					cert.SetPin(CertPIN, null, bUseMachineKeySet);
					ws.ClientCertificates.Add(cert);
				}
			}
			catch(CertPInvokeLib.CertException cExc)
			{
				TraceCertificateProblems(string.Format("Errore su certificat settando client certificate; Msg = {0} Win32Error = {1:X} Win32Msg={2}", cExc.Message, cExc.Win32Error, cExc.Win32Msg));
			}
			catch(Exception exc)
			{
				TraceCertificateProblems(string.Format("Errore generico settando client certificate; Msg = {0}", exc.Message));
			}
			finally
			{
				if (cert != null)
				{
					//cert.Dispose();
				}
			}
		}

		//
		// Client Setup per i web services che non usano authentication SoapHeader oppure 
		// che usano username/password non derivabili da configName
		//
		public static void SetupNoAuthHeader(SoapHttpClientProtocol ws, string configName)
		{
			string dummyUser, dummyPassword;
			dummyUser = "";
			dummyPassword = "";
			Setup(ws, ref dummyUser, ref dummyPassword, configName);
		}

		//
		// Client Setup per i web services che usano authentication SoapHeader
		//
		public static void Setup(SoapHttpClientProtocol ws, ref string username, ref string password, string configName)
		{
			string Url					= ConfigurationSettings.AppSettings[configName + "_Url"];
			string ProxyUser			= ConfigurationSettings.AppSettings[configName + "_ProxyUser"];
			string ProxyPwd				= ConfigurationSettings.AppSettings[configName + "_ProxyPwd"];
			string ProxyDomain			= ConfigurationSettings.AppSettings[configName + "_ProxyDomain"];
			string CertProblems			= ConfigurationSettings.AppSettings[configName + "_CertProblems"];
			string CertIssuer			= ConfigurationSettings.AppSettings[configName + "_Certificate_Issuer"];
			string CertSN				= ConfigurationSettings.AppSettings[configName + "_Certificate_SN"];
			string CertPIN				= ConfigurationSettings.AppSettings[configName + "_Certificate_PIN"];
			string CertLocation			= ConfigurationSettings.AppSettings[configName + "_Certificate_Location"];
			string CertUseMachineKeySet	= ConfigurationSettings.AppSettings[configName + "_Certificate_MachineKeySet"];
			string UserName				= ConfigurationSettings.AppSettings[configName + "_UserName"];
			string Password				= ConfigurationSettings.AppSettings[configName + "_Password"];


			bool bUseMachineKeySet = false;
			if ((CertUseMachineKeySet != null) && (CertUseMachineKeySet != string.Empty))
			{
				CertUseMachineKeySet = CertUseMachineKeySet.ToLower();
				if ((CertUseMachineKeySet == "1") || (CertUseMachineKeySet == "si") || (CertUseMachineKeySet=="yes") || (CertUseMachineKeySet=="true"))
					bUseMachineKeySet = true;
			}
					

			if (ProxyDomain == null || ProxyDomain == String.Empty) ProxyDomain = null;
			if (ProxyUser == null || ProxyUser == String.Empty) ProxyUser = null;

			if (ProxyUser != null && ProxyDomain != null)
				ws.Credentials = new System.Net.NetworkCredential(ProxyUser, ProxyPwd, ProxyDomain);

			if (Url == null)
				TraceCertificateProblems(string.Format("Voce di configurazione '{0}' mancante", configName + "_Url"));

			SetClientCertificate(ws, CertIssuer, CertSN, CertPIN, CertLocation, bUseMachineKeySet);

			ws.Url = Url;
			username = UserName;
			password = Password;

			if (CertProblems != null)
			{
				lock(s_CertificateProblems)
				{
					if (s_CertificateProblems.ContainsKey(Url) == false)
						s_CertificateProblems.Add(Url, CertProblems);
				}
			}
		}

		public delegate void TraceDelegate(string msg);

		private static StringDictionary s_CertificateProblems = new StringDictionary();
		private static TraceDelegate s_traceDelegate;

		internal static string GetAllowedCertificateProblems(string Url)
		{
			lock(s_CertificateProblems)
			{
				if (s_CertificateProblems.ContainsKey(Url) == false)
					return null;
				else
					return s_CertificateProblems[Url];
			}
		}

		internal static void TraceCertificateProblems(string s)
		{
			try
			{
				if (s_traceDelegate != null)
					s_traceDelegate(s);
			}
			catch
			{
			}
		}

	}


	public enum CertificateProblem : long
	{
		CertEXPIRED = 0x800B0101,
		CertVALIDITYPERIODNESTING = 0x800B0102,
		CertROLE = 0x800B0103,
		CertPATHLENCONST = 0x800B0104,
		CertCRITICAL = 0x800B0105,
		CertPURPOSE = 0x800B0106,
		CertISSUERCHAINING = 0x800B0107,
		CertMALFORMED = 0x800B0108,
		CertUNTRUSTEDROOT = 0x800B0109,
		CertCHAINING = 0x800B010A,
		CertREVOKED = 0x800B010C,
		CertUNTRUSTEDTESTROOT = 0x800B010D,
		CertREVOCATION_FAILURE = 0x800B010E,
		CertCN_NO_MATCH = 0x800B010F,
		CertWRONG_USAGE = 0x800B0110,
		CertUNTRUSTEDCA = 0x800B0112,
	}

	class TrustAllCertificatePolicy : System.Net.ICertificatePolicy
	{
		bool System.Net.ICertificatePolicy.CheckValidationResult(System.Net.ServicePoint srvPoint, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Net.WebRequest request, int certificateProblem)
		{
			string cps = null;

			//
			// La classe intercetta anche l'errore con nessun problema sul certificato
			//
			if (certificateProblem == 0)
			{
				 return true;
			}

			if (Enum.IsDefined(typeof(CertificateProblem), (long)(uint)certificateProblem))
			{
				CertificateProblem cp = (CertificateProblem)(long)(uint)certificateProblem;
				cps = cp.ToString();
			}

			string cpa = WSClient.GetAllowedCertificateProblems(request.RequestUri.AbsoluteUri);
			if (cpa == null)
				return false;

			char [] cc = new char[2];
			cc[0] = ',';
			cc[1] = ' ';

			foreach(string s in cpa.Split(cc))
			{
				if (cps !=  null && cps == s) return true;
				if (s == "*") return true;
				if (s.ToUpper() == ((uint)certificateProblem).ToString("X")) return true;
			}

			if (cps == null)
				WSClient.TraceCertificateProblems(string.Format("ERRORE: il server remoto ha un 'certificateProblem' = {0:X}", (uint)certificateProblem));
			else
				WSClient.TraceCertificateProblems(string.Format("ERRORE: il server remoto ha un 'certificateProblem' = {0:X}: {1}", (uint)certificateProblem, cps));
			return false;
		}
	}

	
}
