using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Specialized;


namespace Bil_Crypt
{
	/// <summary>
	/// Summary description for CertificateManager.
	/// </summary>
	public class CertificateManager : System.ComponentModel.Component
	{
		private System.Data.SqlClient.SqlConnection _cn;
		private System.Data.SqlClient.SqlDataAdapter daCertificateList;
		private System.Data.SqlClient.SqlDataAdapter daCertificateDistributionPoints;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand2;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand2;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand2;
		private System.Data.SqlClient.SqlDataAdapter daCertificateRevokationList;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand3;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand3;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand3;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand3;
		private System.Data.SqlClient.SqlDataAdapter daGetCertificateData;
		private System.Data.SqlClient.SqlDataAdapter daCertificateCA;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand5;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand4;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand2;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand4;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand4;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand6;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand5;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand4;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand5;
		private System.Data.SqlClient.SqlDataAdapter daCertificateListAll;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CertificateManager(System.ComponentModel.IContainer container)
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			container.Add(this);
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

		}

		public CertificateManager()
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			string s = ConfigurationSettings.AppSettings["Certificate_SqlConnectionString"];
			if (s == null)
				s = ConfigurationSettings.AppSettings["SqlConnectionString"];
			_cn.ConnectionString = s;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		public void StoreCertificate(CertPInvokeLib.CertX509Ex c, string codiceUtenteSDC, bool bAbilitaCertificatoUtente)
		{
			SqlTransaction tr = null;
			try
			{
				_cn.Open();
				tr = _cn.BeginTransaction();

				StoreCertificate(tr, c, codiceUtenteSDC, bAbilitaCertificatoUtente);

				tr.Commit();
			}
			catch (Exception ex)
			{
				if (tr != null)
					tr.Rollback();
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}
		}

		public void StoreCertificate(SqlTransaction tr, CertPInvokeLib.CertX509Ex c, string codiceUtenteSDC, bool bAbilitaCertificatoUtente)
		{
			DS_Certificate ds = new DS_Certificate();

			SetTransaction(this.daCertificateDistributionPoints, tr);
			SetTransaction(this.daCertificateList,tr );
			SetTransaction(this.daCertificateCA, tr);

			string issuer = c.GetIssuerName();
			string sn = c.GetSerialNumberString();
			string subject = c.GetName();

			this.daCertificateList.SelectCommand.Parameters["@Issuer"].Value = issuer;
			this.daCertificateList.SelectCommand.Parameters["@SerialNumber"].Value = sn;
			this.daCertificateList.SelectCommand.Parameters["@CodiceUtenteSDC"].Value = codiceUtenteSDC;
			daCertificateList.Fill(ds.Certificate_List);

			DS_Certificate.Certificate_ListRow drCertificateList;
			drCertificateList = ds.Certificate_List.FindByIssuerSerialNumberCodiceUtenteSDC(issuer, sn, codiceUtenteSDC);
			if (drCertificateList != null)
				return;

			//
			// In generale ci saranno poche CA ... carico tutte (altrimenti dovrei fare un
			// cmdSelect separato con parametro Issuer
			//
			//this.daCertificateCA.SelectCommand.Parameters["@Issuer"].Value = issuer;
			daCertificateCA.Fill(ds.Certificate_CA);

			this.daCertificateDistributionPoints.SelectCommand.Parameters["@Issuer"].Value = issuer;
			daCertificateDistributionPoints.Fill(ds.Certificate_DistributionPoints);


			DateTime tsScadenza = c.ExpirationDate;

			//
			// smalldatetime in SQLServer va solo fino a 6/6/2079
			//
			if (tsScadenza.Year>2078)
			{
				tsScadenza = new DateTime(2078, 1,1);
			}

			string forceAction = ConfigurationSettings.AppSettings["Certificate_DefaultForceAction"];
			if (forceAction == null)
				forceAction = ""; // controlli di default (i piu` restrittivi)

			//
			// Inserisce una nuova entry con CodiceUtenteSDC e Validita' settato a false
			//
			DS_Certificate.Certificate_ListRow drCL = ds.Certificate_List.NewCertificate_ListRow();
			drCL.Issuer = issuer;
			drCL.SerialNumber = sn;
			drCL.TSScadenza = tsScadenza;
			drCL.ForceAction = forceAction;
			drCL.Subject = subject;
			drCL.CodiceUtenteSDC = codiceUtenteSDC;
			drCL.Abilitato = bAbilitaCertificatoUtente;
			drCL.SetLastErrorNull();
			ds.Certificate_List.AddCertificate_ListRow(drCL);


			DS_Certificate.Certificate_CARow drCA;
			drCA = ds.Certificate_CA.FindByIssuer(issuer);
			if (drCA == null)
			{
				drCA = ds.Certificate_CA.NewCertificate_CARow();
				drCA.Issuer = issuer;
				drCA.Abilitata = false;
				drCA.SetChildOfNull();
				drCA.SetTSDownloadEffettivoNull();
				drCA.SetTSScadenzaNull();
				drCA.SetTSUltimoDownloadNull();
				ds.Certificate_CA.AddCertificate_CARow(drCA);
			}

	
			string [] dpl = c.GetDistributionPointList();
			
			//
			// (il metodo ritorna null se il certificato non ha CDP
			// CRL distribution points:
			//
			if (dpl == null)
			{
			}
			else
			{
				foreach (string dp in dpl)
				{
					DS_Certificate.Certificate_DistributionPointsRow drCertificateDistributionPoint;
					drCertificateDistributionPoint = ds.Certificate_DistributionPoints.FindByIssuerUrl(issuer, dp);
					if (drCertificateDistributionPoint == null)
					{
						drCertificateDistributionPoint = ds.Certificate_DistributionPoints.NewCertificate_DistributionPointsRow();
						drCertificateDistributionPoint.Issuer = issuer;
						drCertificateDistributionPoint.Url = dp;
					
						ds.Certificate_DistributionPoints.AddCertificate_DistributionPointsRow(drCertificateDistributionPoint);
					}
				}
			}


			daCertificateCA.Update(ds.Certificate_CA);
			daCertificateList.Update(ds.Certificate_List);
			daCertificateDistributionPoints.Update(ds.Certificate_DistributionPoints);
		}


		public void UpdadeCRL()
		{
			SqlTransaction tr = null;
			try
			{
				_cn.Open();
				tr = _cn.BeginTransaction();

				UpdadeCRL(tr);

				if (tr != null)
					tr.Commit();
			}
			catch (Exception ex)
			{
				if (tr != null)
					tr.Rollback();
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}
		}




		public void UpdadeCRL(SqlTransaction tr)
		{
			SetTransaction(this.daCertificateDistributionPoints, tr);
			SetTransaction(this.daCertificateRevokationList, tr);
			SetTransaction(this.daCertificateCA, tr);


			int timeOut = 30;
			if (true)
			{
				string s = ConfigurationSettings.AppSettings["Certificate_CRLDownloadTimeout"];
				try { timeOut = int.Parse(s); } catch {}
			}

			DS_Certificate ds = new DS_Certificate();
			daCertificateCA.Fill(ds.Certificate_CA);

			foreach (DS_Certificate.Certificate_CARow drCA in ds.Certificate_CA)
			{
				ds.Certificate_DistributionPoints.Clear();
				ds.Certificate_RevocationList.Clear();

				this.daCertificateDistributionPoints.SelectCommand.Parameters["@Issuer"].Value = drCA.Issuer;
				this.daCertificateDistributionPoints.Fill(ds.Certificate_DistributionPoints);

				this.daCertificateRevokationList.SelectCommand.Parameters["@Issuer"].Value = drCA.Issuer;
				this.daCertificateRevokationList.Fill(ds.Certificate_RevocationList);

				foreach (DS_Certificate.Certificate_DistributionPointsRow drDP in ds.Certificate_DistributionPoints)
				{
					DS_Certificate.Certificate_RevocationListDataTable dt = ds.Certificate_RevocationList;

					DateTime currentTime, nextTime = DateTime.MinValue;
					CertPInvokeLib.CryptCRL.CRLEntry [] crlEntries = null;

					bool bOk = false;
					try
					{
						string useWS = ConfigurationSettings.AppSettings["CRLDownload_useWS"];
						bool bUseWS = false;
						if ((useWS != null) && (useWS != string.Empty))
						{
							useWS = useWS.ToLower();
							if ((useWS == "1") || (useWS == "si") || (useWS=="yes") || (useWS=="true"))
								bUseWS = true;
						}
						if (bUseWS)
						{
							localhost.CRL w = new localhost.CRL();
							w.WSAuthHeaderValue = new localhost.WSAuthHeader();
                    		Bil_Crypt.WSClient.Setup(w, ref w.WSAuthHeaderValue.Username, ref w.WSAuthHeaderValue.Password, "Bil_MGPBridgeWS_CRL");

							currentTime = DateTime.MinValue;
							nextTime = DateTime.MinValue;
							localhost.CRLEntry[] r = w.Download(drDP.Url, timeOut, ref currentTime, ref nextTime);

							crlEntries = new CertPInvokeLib.CryptCRL.CRLEntry[r.Length];
							for (int i = 0; i < r.Length; ++i)
							{
								crlEntries[i] = new CertPInvokeLib.CryptCRL.CRLEntry();
								if (Enum.IsDefined(typeof(CertPInvokeLib.CryptCRL.CrlReasonCode), r[i].reason))
									crlEntries[i].reason = (CertPInvokeLib.CryptCRL.CrlReasonCode)r[i].reason;
								else
									crlEntries[i].reason = CertPInvokeLib.CryptCRL.CrlReasonCode.unspecified;
								crlEntries[i].revocationDate = r[i].revocationDate;
								crlEntries[i].serialNumber = r[i].serialNumber;
							}
							bOk = true;
						}
						else
						{
							CertPInvokeLib.CryptCRL d = new CertPInvokeLib.CryptCRL(drDP.Url, CertPInvokeLib.CryptCRL.CrlDownloadType.NetworkCrlDownloadOnly, timeOut);
							d.GetAllCRLData(true, out currentTime, out nextTime, out crlEntries);
							bOk = true;
						}
					}
					catch
					{
					}


					if (bOk)
					{
						DateTime tsDownload = DateTime.Now;

						for (int i = 0; i < crlEntries.Length; ++i)
						{

							string sn = string.Empty;
							for (int k=0;k<crlEntries[i].serialNumber.Length; k++)
							{
								sn += crlEntries[i].serialNumber[k].ToString("X2");
							}

							DS_Certificate.Certificate_RevocationListRow dr;
							dr = dt.FindByIssuerSerialNumber(drCA.Issuer, sn); 
							if (dr == null)
							{
								// non esiste --> inserisco la nuova entry.
								dr = dt.NewCertificate_RevocationListRow();
								dr.Issuer = drCA.Issuer;
								dr.SerialNumber = sn;
								dr.TSDownload = tsDownload;
								dr.TSRevoca = crlEntries[i].revocationDate;
								dr.ReasonCode = (int)crlEntries[i].reason;
								dt.AddCertificate_RevocationListRow(dr);
							}
						}

						drCA.TSUltimoDownload = tsDownload;
						drCA.TSScadenza = nextTime;
						drCA.TSDownloadEffettivo = tsDownload;
						break;
					}
					else
					{
						drCA.TSUltimoDownload = DateTime.Now;
					}
				}


				this.daCertificateRevokationList.Update(ds.Certificate_RevocationList);
				this.daCertificateDistributionPoints.Update(ds.Certificate_DistributionPoints);
			}
			this.daCertificateCA.Update(ds.Certificate_CA);
		}


		public void CheckCertificate(DateTime TSTarget)
		{
			DS_Certificate ds = new DS_Certificate();

			try
			{
				_cn.Open();

				daCertificateListAll.Fill(ds.Certificate_List);
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}

			foreach (DS_Certificate.Certificate_ListRow dr in ds.Certificate_List)
			{
				string s = CheckCertificate(dr.Issuer, dr.SerialNumber, dr.CodiceUtenteSDC, TSTarget, ControllaScadenzaCertificato.No);

				if (s == null || s == string.Empty)
					dr.SetLastErrorNull();
				else
					dr.LastError = s;
			}

			try
			{
				_cn.Open();
				daCertificateListAll.Update(ds.Certificate_List);
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}

		}



		public enum ControllaScadenzaCertificato
		{
			No, Si
		}


		public string CheckCertificate(string issuer, string serialNumber, string codiceUtenteSDC, DateTime TSTarget, ControllaScadenzaCertificato csc)
		{
			try
			{
				_cn.Open();

				DS_Certificate ds = new DS_Certificate();
				daGetCertificateData.SelectCommand.Parameters["@Issuer"].Value  = issuer;
				daGetCertificateData.SelectCommand.Parameters["@sn"].Value = serialNumber;
				daGetCertificateData.SelectCommand.Parameters["@CodiceUtenteSDC"].Value = codiceUtenteSDC;
				
				daGetCertificateData.Fill(ds.dbo_spGetCertificateData);

				if (ds.dbo_spGetCertificateData.Count == 0)
					return "C001: Certificato di firma non registrato nel sistema";
				
				DS_Certificate.dbo_spGetCertificateDataRow dr = ds.dbo_spGetCertificateData[0];

				if (dr.CertificatoAbilitato == false)
					return "C002: Certificato non abilitato";
			

				ForceAction [] fa = parseForceAction(dr.CertificatoForceAction);

				if (fa == null)
				 	throw new ApplicationException("formato ForceAction errato");
				/*
				 * Flag di forzatura (se un sertificato risulta es scaduto si puo` forzare
				 * a continuare con quel certificato con T)
				 * certificato scaduto      T
				 *							T<n>
				 * certificato revocato		C ok
				 * revocato con code		R<n>
				 * CRL scaduta				S ok
				 *							S<n>
				 * CRL non presente			P
				 * CRL non aggiornata		D
				 *							D<n>
				 * Certificato senza CDP    M
				 */
				ForceAction z;

				if (csc == ControllaScadenzaCertificato.Si && dr.TSScadenzaCertificato < TSTarget)
				{
					bool b = false;
					// il certificato e` scaduto.

					z = GetForceAction(fa, 'T');
					if (z != null)
					{
						b = true;

						if (z.numberPresent == true)
						{
							if (TimeSpan.FromTicks(TSTarget.Ticks - dr.TSScadenzaCertificato.Ticks).Days > z.number)
								return "C003: Certificato scaduto";
						}
					}

					if (b == false)
						return "C004: Certificato scaduto";
				}

				if (dr.IsssuerAbilitato == false)
				{
					// Issuer non e` presente nel DB
					// non esiste voce di forzatura in quanto se si vuole si abilita
					// l'entry nella Certificate_CA
					return "C006: Issuer non abilitato";
				}

				
				//
				// Certificato senza punti di distribuzione CRL
				//
				if (dr.NumeroPuntiDiDistribuzione == 0)
				{

					z = GetForceAction(fa, 'M');
					if (z != null)
						return "";
					else
						return "C016: Certificato con issuer senza CDP";
				}
			

				if (dr.IsTSUltimoDownloadConSuccessoNull())
				{
					// non ha mai scaricato la CRL

					bool b = false;
					z = GetForceAction(fa, 'P');
					if (z != null)
						b = true;

					if (b == false)
						return "C008: CRL non presente per l'issuer";
				}
				else
				{
					// CRL scaricata.... ma quando ?

					if (dr.TSScadenzaCRL < TSTarget)
					{
						// CRL scaduta.

						bool b = false;

						z = GetForceAction(fa, 'S');
						if (z != null)
						{
							b = true;
							if (z.numberPresent)
							{
								if (TimeSpan.FromTicks(TSTarget.Ticks - dr.TSScadenzaCRL.Ticks).Days > z.number)
									return "C010: CRL scaduta";
							}
						}

						if (b == false)
							return "C011: CRL scaduta";
					}

					if (dr.IsTSUltimoDownloadTentatoNull() == false && dr.TSUltimoDownloadTentato > dr.TSUltimoDownloadConSuccesso)
					{
						// ha provato a scaricare una CRL ma ha fallito
						// --> CRL non aggiornata

						bool b = false;
						z = GetForceAction(fa, 'D');
						if (z != null)
						{
							b = true;
							if (z.numberPresent)
							{
								if (TimeSpan.FromTicks(dr.TSUltimoDownloadTentato.Ticks - dr.TSUltimoDownloadConSuccesso.Ticks).Days > z.number)
									return "C012: CRL non abbanstanza fresca";
							}
						}

						if (b == false)
							return "C014: CRL non abbanstanza fresca";
					}


					if (dr.IsCRLTSRevocaNull() == false)
					{
						z = null;
						while ((z = GetForceAction(fa, 'R', z)) != null)
						{
							if (z.numberPresent && dr.IsCRLReasonCodeNull() == false && dr.CRLReasonCode == z.number)
								break;
						}

						if (z == null)
							z = GetForceAction(fa, 'C');

						if (z == null)
							return "C015: certificato revocato";
					}
				}

			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.Message);
				throw;
			}
			finally
			{
				if (_cn.State == ConnectionState.Open)
					_cn.Close();
			}

			return "";
		}

		class ForceAction
		{
			public char opz;
			public bool numberPresent;
			public int number;
		}

		private ForceAction GetForceAction(ForceAction[] fa, char opz)
		{
			if (fa != null)
			{
				for (int i = 0; i < fa.Length; ++i)
					if (fa[i].opz == opz)
						return fa[i];
			}
			return null;
		}

		private ForceAction GetForceAction(ForceAction[] fa, char opz, ForceAction previous)
		{
			if (fa != null)
			{
				for (int i = 0; i < fa.Length; ++i)
				{
					if (fa[i].opz == opz && previous == null)
						return fa[i];

					if (fa[i].opz == opz && fa[i] == previous)
						previous = null;
				}
			}
			return null;
		}


		private static ForceAction[] parseForceAction(string fa)
		{
			ArrayList aa = new ArrayList();
			int i;
			for (i = 0; i < fa.Length;)
			{
				ForceAction a = new ForceAction();

				a.opz = fa[i];
				a.numberPresent = false;
				aa.Add(a);
		
				++i;
		
				if (i == fa.Length) break;
				if (fa[i] == '<')
				{
					++i;
					int n = 0;
					for (;;)
					{
						if (i >= fa.Length) break;
						if (fa[i] == '>') { a.numberPresent = true; a.number = n; ++i; break; }
						if (!char.IsDigit(fa[i])) break;
						n = n * 10 + (fa[i] - '0');
						++i;
					}
				}
			}
			if (i == fa.Length)
			{
				ForceAction [] r = new ForceAction[aa.Count];
				for (int j=0; j<aa.Count; j++)
				{
					r[j] = (ForceAction) aa[j];
				}
				return r;
			}
			else
				return null;
		}

		protected static void SetTransaction(SqlDataAdapter da, SqlTransaction tr)
		{
			if (da.SelectCommand != null) da.SelectCommand.Transaction = tr;
			if (da.InsertCommand != null) da.InsertCommand.Transaction = tr;
			if (da.DeleteCommand != null) da.DeleteCommand.Transaction = tr;
			if (da.UpdateCommand != null) da.UpdateCommand.Transaction = tr;
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this._cn = new System.Data.SqlClient.SqlConnection();
			this.daCertificateList = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.daCertificateDistributionPoints = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			this.daCertificateRevokationList = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			this.daGetCertificateData = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			this.daCertificateCA = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand4 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand5 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand6 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand5 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand4 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand5 = new System.Data.SqlClient.SqlCommand();
			this.daCertificateListAll = new System.Data.SqlClient.SqlDataAdapter();
			// 
			// _cn
			// 
			this._cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" +
				"st security info=False;initial catalog=Bilaterali";
			// 
			// daCertificateList
			// 
			this.daCertificateList.DeleteCommand = this.sqlDeleteCommand1;
			this.daCertificateList.InsertCommand = this.sqlInsertCommand1;
			this.daCertificateList.SelectCommand = this.sqlSelectCommand1;
			this.daCertificateList.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										new System.Data.Common.DataTableMapping("Table", "Certificate_List", new System.Data.Common.DataColumnMapping[] {
																																																							new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
																																																							new System.Data.Common.DataColumnMapping("SerialNumber", "SerialNumber"),
																																																							new System.Data.Common.DataColumnMapping("TSScadenza", "TSScadenza"),
																																																							new System.Data.Common.DataColumnMapping("ForceAction", "ForceAction"),
																																																							new System.Data.Common.DataColumnMapping("Subject", "Subject"),
																																																							new System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"),
																																																							new System.Data.Common.DataColumnMapping("Abilitato", "Abilitato")})});
			this.daCertificateList.UpdateCommand = this.sqlUpdateCommand1;
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = @"DELETE FROM dbo.Certificate_List WHERE (CodiceUtenteSDC = @Original_CodiceUtenteSDC) AND (Issuer = @Original_Issuer) AND (SerialNumber = @Original_SerialNumber) AND (Abilitato = @Original_Abilitato) AND (ForceAction = @Original_ForceAction) AND (Subject = @Original_Subject OR @Original_Subject IS NULL AND Subject IS NULL) AND (TSScadenza = @Original_TSScadenza)";
			this.sqlDeleteCommand1.Connection = this._cn;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Abilitato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Abilitato", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ForceAction", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ForceAction", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Subject", System.Data.SqlDbType.VarChar, 512, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Subject", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSScadenza", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSScadenza", System.Data.DataRowVersion.Original, null));
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO dbo.Certificate_List(Issuer, SerialNumber, TSScadenza, ForceAction, Subject, CodiceUtenteSDC, Abilitato) VALUES (@Issuer, @SerialNumber, @TSScadenza, @ForceAction, @Subject, @CodiceUtenteSDC, @Abilitato); SELECT Issuer, SerialNumber, TSScadenza, ForceAction, Subject, CodiceUtenteSDC, Abilitato FROM dbo.Certificate_List WHERE (CodiceUtenteSDC = @CodiceUtenteSDC) AND (Issuer = @Issuer) AND (SerialNumber = @SerialNumber)";
			this.sqlInsertCommand1.Connection = this._cn;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 64, "ForceAction"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 512, "Subject"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"));
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT Issuer, SerialNumber, TSScadenza, ForceAction, Subject, CodiceUtenteSDC, A" +
				"bilitato, LastError FROM dbo.Certificate_List WHERE (Issuer = @Issuer) AND (Seri" +
				"alNumber = @SerialNumber) AND (CodiceUtenteSDC = @CodiceUtenteSDC)";
			this.sqlSelectCommand1.Connection = this._cn;
			this.sqlSelectCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlSelectCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"));
			this.sqlSelectCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"));
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = @"UPDATE dbo.Certificate_List SET Issuer = @Issuer, SerialNumber = @SerialNumber, TSScadenza = @TSScadenza, ForceAction = @ForceAction, Subject = @Subject, CodiceUtenteSDC = @CodiceUtenteSDC, Abilitato = @Abilitato WHERE (CodiceUtenteSDC = @Original_CodiceUtenteSDC) AND (Issuer = @Original_Issuer) AND (SerialNumber = @Original_SerialNumber) AND (Abilitato = @Original_Abilitato) AND (ForceAction = @Original_ForceAction) AND (Subject = @Original_Subject OR @Original_Subject IS NULL AND Subject IS NULL) AND (TSScadenza = @Original_TSScadenza); SELECT Issuer, SerialNumber, TSScadenza, ForceAction, Subject, CodiceUtenteSDC, Abilitato FROM dbo.Certificate_List WHERE (CodiceUtenteSDC = @CodiceUtenteSDC) AND (Issuer = @Issuer) AND (SerialNumber = @SerialNumber)";
			this.sqlUpdateCommand1.Connection = this._cn;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 64, "ForceAction"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 512, "Subject"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Abilitato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Abilitato", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ForceAction", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ForceAction", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Subject", System.Data.SqlDbType.VarChar, 512, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Subject", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSScadenza", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSScadenza", System.Data.DataRowVersion.Original, null));
			// 
			// daCertificateDistributionPoints
			// 
			this.daCertificateDistributionPoints.DeleteCommand = this.sqlDeleteCommand2;
			this.daCertificateDistributionPoints.InsertCommand = this.sqlInsertCommand2;
			this.daCertificateDistributionPoints.SelectCommand = this.sqlSelectCommand2;
			this.daCertificateDistributionPoints.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																													  new System.Data.Common.DataTableMapping("Table", "Certificate_DistributionPoints", new System.Data.Common.DataColumnMapping[] {
																																																														new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
																																																														new System.Data.Common.DataColumnMapping("Url", "Url"),
																																																														new System.Data.Common.DataColumnMapping("TSDownloadEffettivo", "TSDownloadEffettivo"),
																																																														new System.Data.Common.DataColumnMapping("TSScadenza", "TSScadenza"),
																																																														new System.Data.Common.DataColumnMapping("TSUltimoDownload", "TSUltimoDownload")})});
			// 
			// sqlDeleteCommand2
			// 
			this.sqlDeleteCommand2.CommandText = "DELETE FROM dbo.Certificate_DistributionPoints WHERE (Issuer = @Original_Issuer) " +
				"AND (Url = @Original_Url)";
			this.sqlDeleteCommand2.Connection = this._cn;
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Url", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Url", System.Data.DataRowVersion.Original, null));
			// 
			// sqlInsertCommand2
			// 
			this.sqlInsertCommand2.CommandText = "INSERT INTO dbo.Certificate_DistributionPoints (Issuer, Url) VALUES (@Issuer, @Ur" +
				"l)";
			this.sqlInsertCommand2.Connection = this._cn;
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Url", System.Data.SqlDbType.VarChar, 256, "Url"));
			// 
			// sqlSelectCommand2
			// 
			this.sqlSelectCommand2.CommandText = "SELECT Issuer, Url FROM dbo.Certificate_DistributionPoints WHERE (Issuer = @Issue" +
				"r)";
			this.sqlSelectCommand2.Connection = this._cn;
			this.sqlSelectCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			// 
			// daCertificateRevokationList
			// 
			this.daCertificateRevokationList.DeleteCommand = this.sqlDeleteCommand3;
			this.daCertificateRevokationList.InsertCommand = this.sqlInsertCommand3;
			this.daCertificateRevokationList.SelectCommand = this.sqlSelectCommand3;
			this.daCertificateRevokationList.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																												  new System.Data.Common.DataTableMapping("Table", "Certificate_RevocationList", new System.Data.Common.DataColumnMapping[] {
																																																												new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
																																																												new System.Data.Common.DataColumnMapping("SerialNumber", "SerialNumber"),
																																																												new System.Data.Common.DataColumnMapping("ReasonCode", "ReasonCode"),
																																																												new System.Data.Common.DataColumnMapping("TSRevoca", "TSRevoca"),
																																																												new System.Data.Common.DataColumnMapping("TSDownload", "TSDownload")})});
			this.daCertificateRevokationList.UpdateCommand = this.sqlUpdateCommand3;
			// 
			// sqlDeleteCommand3
			// 
			this.sqlDeleteCommand3.CommandText = "DELETE FROM dbo.Certificate_RevocationList WHERE (Issuer = @Original_Issuer) AND " +
				"(SerialNumber = @Original_SerialNumber)";
			this.sqlDeleteCommand3.Connection = this._cn;
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
			// 
			// sqlInsertCommand3
			// 
			this.sqlInsertCommand3.CommandText = "INSERT INTO dbo.Certificate_RevocationList(Issuer, SerialNumber, ReasonCode, TSRe" +
				"voca, TSDownload) VALUES (@Issuer, @SerialNumber, @ReasonCode, @TSRevoca, @TSDow" +
				"nload)";
			this.sqlInsertCommand3.Connection = this._cn;
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ReasonCode", System.Data.SqlDbType.Int, 4, "ReasonCode"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSRevoca", System.Data.SqlDbType.DateTime, 4, "TSRevoca"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSDownload", System.Data.SqlDbType.DateTime, 4, "TSDownload"));
			// 
			// sqlSelectCommand3
			// 
			this.sqlSelectCommand3.CommandText = "SELECT Issuer, SerialNumber, ReasonCode, TSRevoca, TSDownload FROM dbo.Certificat" +
				"e_RevocationList WHERE (Issuer = @Issuer)";
			this.sqlSelectCommand3.Connection = this._cn;
			this.sqlSelectCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			// 
			// sqlUpdateCommand3
			// 
			this.sqlUpdateCommand3.CommandText = "UPDATE dbo.Certificate_RevocationList SET Issuer = @Issuer, SerialNumber = @Seria" +
				"lNumber, ReasonCode = @ReasonCode, TSRevoca = @TSRevoca, TSDownload = @TSDownloa" +
				"d WHERE (Issuer = @Original_Issuer) AND (SerialNumber = @Original_SerialNumber)";
			this.sqlUpdateCommand3.Connection = this._cn;
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ReasonCode", System.Data.SqlDbType.Int, 4, "ReasonCode"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSRevoca", System.Data.SqlDbType.DateTime, 4, "TSRevoca"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSDownload", System.Data.SqlDbType.DateTime, 4, "TSDownload"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
			// 
			// daGetCertificateData
			// 
			this.daGetCertificateData.SelectCommand = this.sqlSelectCommand4;
			this.daGetCertificateData.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										   new System.Data.Common.DataTableMapping("Table", "dbo_spGetCertificateData", new System.Data.Common.DataColumnMapping[] {
																																																									   new System.Data.Common.DataColumnMapping("CertificatoForceAction", "CertificatoForceAction"),
																																																									   new System.Data.Common.DataColumnMapping("TSScadenzaCertificato", "TSScadenzaCertificato"),
																																																									   new System.Data.Common.DataColumnMapping("CertificatoAbilitato", "CertificatoAbilitato"),
																																																									   new System.Data.Common.DataColumnMapping("TSScadenzaCRL", "TSScadenzaCRL"),
																																																									   new System.Data.Common.DataColumnMapping("TSUltimoDownloadConSuccesso", "TSUltimoDownloadConSuccesso"),
																																																									   new System.Data.Common.DataColumnMapping("TSUltimoDownloadTentato", "TSUltimoDownloadTentato"),
																																																									   new System.Data.Common.DataColumnMapping("CRLReasonCode", "CRLReasonCode"),
																																																									   new System.Data.Common.DataColumnMapping("CRLTSRevoca", "CRLTSRevoca"),
																																																									   new System.Data.Common.DataColumnMapping("TSUltimoDownloadRevocaDelCertificato", "TSUltimoDownloadRevocaDelCertificato"),
																																																									   new System.Data.Common.DataColumnMapping("IsssuerAbilitato", "IsssuerAbilitato")})});
			// 
			// sqlSelectCommand4
			// 
			this.sqlSelectCommand4.CommandText = "dbo.[spGetCertificateData]";
			this.sqlSelectCommand4.CommandType = System.Data.CommandType.StoredProcedure;
			this.sqlSelectCommand4.Connection = this._cn;
			this.sqlSelectCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlSelectCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256));
			this.sqlSelectCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@sn", System.Data.SqlDbType.VarChar, 64));
			this.sqlSelectCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16));
			// 
			// daCertificateCA
			// 
			this.daCertificateCA.DeleteCommand = this.sqlDeleteCommand4;
			this.daCertificateCA.InsertCommand = this.sqlInsertCommand4;
			this.daCertificateCA.SelectCommand = this.sqlSelectCommand5;
			this.daCertificateCA.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									  new System.Data.Common.DataTableMapping("Table", "Certificate_CA", new System.Data.Common.DataColumnMapping[] {
																																																						new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
																																																						new System.Data.Common.DataColumnMapping("Abilitata", "Abilitata"),
																																																						new System.Data.Common.DataColumnMapping("ChildOf", "ChildOf"),
																																																						new System.Data.Common.DataColumnMapping("TSDownloadEffettivo", "TSDownloadEffettivo"),
																																																						new System.Data.Common.DataColumnMapping("TSScadenza", "TSScadenza"),
																																																						new System.Data.Common.DataColumnMapping("TSUltimoDownload", "TSUltimoDownload")})});
			this.daCertificateCA.UpdateCommand = this.sqlUpdateCommand2;
			// 
			// sqlDeleteCommand4
			// 
			this.sqlDeleteCommand4.CommandText = "DELETE FROM dbo.Certificate_CA WHERE (Issuer = @Original_Issuer)";
			this.sqlDeleteCommand4.Connection = this._cn;
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			// 
			// sqlInsertCommand4
			// 
			this.sqlInsertCommand4.CommandText = "INSERT INTO dbo.Certificate_CA(Issuer, Abilitata, ChildOf, TSDownloadEffettivo, T" +
				"SScadenza, TSUltimoDownload) VALUES (@Issuer, @Abilitata, @ChildOf, @TSDownloadE" +
				"ffettivo, @TSScadenza, @TSUltimoDownload)";
			this.sqlInsertCommand4.Connection = this._cn;
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ChildOf", System.Data.SqlDbType.VarChar, 256, "ChildOf"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSDownloadEffettivo", System.Data.SqlDbType.DateTime, 4, "TSDownloadEffettivo"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSUltimoDownload", System.Data.SqlDbType.DateTime, 4, "TSUltimoDownload"));
			// 
			// sqlSelectCommand5
			// 
			this.sqlSelectCommand5.CommandText = "SELECT Issuer, Abilitata, ChildOf, TSDownloadEffettivo, TSScadenza, TSUltimoDownl" +
				"oad FROM dbo.Certificate_CA";
			this.sqlSelectCommand5.Connection = this._cn;
			// 
			// sqlUpdateCommand2
			// 
			this.sqlUpdateCommand2.CommandText = "UPDATE dbo.Certificate_CA SET Issuer = @Issuer, Abilitata = @Abilitata, ChildOf =" +
				" @ChildOf, TSDownloadEffettivo = @TSDownloadEffettivo, TSScadenza = @TSScadenza," +
				" TSUltimoDownload = @TSUltimoDownload WHERE (Issuer = @Original_Issuer)";
			this.sqlUpdateCommand2.Connection = this._cn;
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ChildOf", System.Data.SqlDbType.VarChar, 256, "ChildOf"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSDownloadEffettivo", System.Data.SqlDbType.DateTime, 4, "TSDownloadEffettivo"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSUltimoDownload", System.Data.SqlDbType.DateTime, 4, "TSUltimoDownload"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			// 
			// sqlSelectCommand6
			// 
			this.sqlSelectCommand6.CommandText = "SELECT Issuer, SerialNumber, CodiceUtenteSDC, TSScadenza, ForceAction, Subject, A" +
				"bilitato, LastError FROM dbo.Certificate_List";
			this.sqlSelectCommand6.Connection = this._cn;
			// 
			// sqlInsertCommand5
			// 
			this.sqlInsertCommand5.CommandText = @"INSERT INTO dbo.Certificate_List(Issuer, SerialNumber, CodiceUtenteSDC, TSScadenza, ForceAction, Subject, Abilitato, LastError) VALUES (@Issuer, @SerialNumber, @CodiceUtenteSDC, @TSScadenza, @ForceAction, @Subject, @Abilitato, @LastError); SELECT Issuer, SerialNumber, CodiceUtenteSDC, TSScadenza, ForceAction, Subject, Abilitato, LastError FROM dbo.Certificate_List WHERE (CodiceUtenteSDC = @CodiceUtenteSDC) AND (Issuer = @Issuer) AND (SerialNumber = @SerialNumber)";
			this.sqlInsertCommand5.Connection = this._cn;
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 64, "ForceAction"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 512, "Subject"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastError", System.Data.SqlDbType.VarChar, 256, "LastError"));
			// 
			// sqlUpdateCommand4
			// 
			this.sqlUpdateCommand4.CommandText = @"UPDATE dbo.Certificate_List SET Issuer = @Issuer, SerialNumber = @SerialNumber, CodiceUtenteSDC = @CodiceUtenteSDC, TSScadenza = @TSScadenza, ForceAction = @ForceAction, Subject = @Subject, Abilitato = @Abilitato, LastError = @LastError WHERE (CodiceUtenteSDC = @Original_CodiceUtenteSDC) AND (Issuer = @Original_Issuer) AND (SerialNumber = @Original_SerialNumber) AND (Abilitato = @Original_Abilitato) AND (ForceAction = @Original_ForceAction) AND (LastError = @Original_LastError OR @Original_LastError IS NULL AND LastError IS NULL) AND (Subject = @Original_Subject OR @Original_Subject IS NULL AND Subject IS NULL) AND (TSScadenza = @Original_TSScadenza); SELECT Issuer, SerialNumber, CodiceUtenteSDC, TSScadenza, ForceAction, Subject, Abilitato, LastError FROM dbo.Certificate_List WHERE (CodiceUtenteSDC = @CodiceUtenteSDC) AND (Issuer = @Issuer) AND (SerialNumber = @SerialNumber)";
			this.sqlUpdateCommand4.Connection = this._cn;
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 64, "ForceAction"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 512, "Subject"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastError", System.Data.SqlDbType.VarChar, 256, "LastError"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Abilitato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Abilitato", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ForceAction", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ForceAction", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_LastError", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastError", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Subject", System.Data.SqlDbType.VarChar, 512, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Subject", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSScadenza", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSScadenza", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand5
			// 
			this.sqlDeleteCommand5.CommandText = @"DELETE FROM dbo.Certificate_List WHERE (CodiceUtenteSDC = @Original_CodiceUtenteSDC) AND (Issuer = @Original_Issuer) AND (SerialNumber = @Original_SerialNumber) AND (Abilitato = @Original_Abilitato) AND (ForceAction = @Original_ForceAction) AND (LastError = @Original_LastError OR @Original_LastError IS NULL AND LastError IS NULL) AND (Subject = @Original_Subject OR @Original_Subject IS NULL AND Subject IS NULL) AND (TSScadenza = @Original_TSScadenza)";
			this.sqlDeleteCommand5.Connection = this._cn;
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Issuer", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SerialNumber", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Abilitato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Abilitato", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ForceAction", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ForceAction", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_LastError", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastError", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Subject", System.Data.SqlDbType.VarChar, 512, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Subject", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSScadenza", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSScadenza", System.Data.DataRowVersion.Original, null));
			// 
			// daCertificateListAll
			// 
			this.daCertificateListAll.DeleteCommand = this.sqlDeleteCommand5;
			this.daCertificateListAll.InsertCommand = this.sqlInsertCommand5;
			this.daCertificateListAll.SelectCommand = this.sqlSelectCommand6;
			this.daCertificateListAll.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										   new System.Data.Common.DataTableMapping("Table", "Certificate_List", new System.Data.Common.DataColumnMapping[] {
																																																							   new System.Data.Common.DataColumnMapping("Issuer", "Issuer"),
																																																							   new System.Data.Common.DataColumnMapping("SerialNumber", "SerialNumber"),
																																																							   new System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"),
																																																							   new System.Data.Common.DataColumnMapping("TSScadenza", "TSScadenza"),
																																																							   new System.Data.Common.DataColumnMapping("ForceAction", "ForceAction"),
																																																							   new System.Data.Common.DataColumnMapping("Subject", "Subject"),
																																																							   new System.Data.Common.DataColumnMapping("Abilitato", "Abilitato"),
																																																							   new System.Data.Common.DataColumnMapping("LastError", "LastError")})});
			this.daCertificateListAll.UpdateCommand = this.sqlUpdateCommand4;

		}
		#endregion
	}
}
