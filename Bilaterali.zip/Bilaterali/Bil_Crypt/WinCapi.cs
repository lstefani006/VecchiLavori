using System;
using System.Runtime.InteropServices;
using System.Text;


using DWORD = System.UInt32;
using BOOL = System.Boolean;
using HCRYPTMSG = System.IntPtr;
using PCCERT_CONTEXT = System.IntPtr;
using HCRYPTPROV = System.IntPtr;
using PFN_CRYPT_GET_SIGNER_CERTIFICATE = System.IntPtr;
using ALG_ID = System.UInt32;


class WinCapi
{


	public const uint AT_KEYEXCHANGE = 1;
	public const uint AT_SIGNATURE = 2;

	public const uint PROV_RSA_FULL = 1;
	public const uint PP_SIGNATURE_PIN = 33;

	public const string MY = "MY";
	public const int CERT_COMPARE_NAME_STR_W = 8;
	public const int CERT_COMPARE_SHIFT      = 16;
	public const int CERT_INFO_SUBJECT_FLAG  = 7;
	public const int CERT_FIND_SUBJECT_STR_W = CERT_COMPARE_NAME_STR_W << CERT_COMPARE_SHIFT | CERT_INFO_SUBJECT_FLAG;

	public const uint PKCS_7_ASN_ENCODING   = 0x00010000;
	public const uint X509_ASN_ENCODING     = 0x00000001;
	public const uint MY_ENCODING_TYPE = PKCS_7_ASN_ENCODING | X509_ASN_ENCODING;

	public const int CERT_STORE_PROV_SYSTEM = 10;

	public const int CERT_SYSTEM_STORE_CURRENT_USER_ID = 1;
	public const int CERT_SYSTEM_STORE_LOCAL_MACHINE_ID = 2;
	public const uint HCCE_CURRENT_USER = 0;
	public const uint HCCE_LOCAL_MACHINE = 1;


	public const int CERT_STORE_NO_CRYPT_RELEASE_FLAG		= 0x00000001;
	public const int CERT_STORE_SET_LOCALIZED_NAME_FLAG	= 0x00000002;
	public const int CERT_STORE_DEFER_CLOSE_UNTIL_LAST_FREE_FLAG = 0x00000004;
	public const int CERT_STORE_DELETE_FLAG                      = 0x00000010;
	public const int CERT_STORE_UNSAFE_PHYSICAL_FLAG             = 0x00000020;
	public const int CERT_STORE_SHARE_STORE_FLAG                 = 0x00000040;
	public const int CERT_STORE_SHARE_CONTEXT_FLAG               = 0x00000080;
	public const int CERT_STORE_MANIFOLD_FLAG                    = 0x00000100;
	public const int CERT_STORE_ENUM_ARCHIVED_FLAG               = 0x00000200;
	public const int CERT_STORE_UPDATE_KEYID_FLAG                = 0x00000400;
	public const int CERT_STORE_BACKUP_RESTORE_FLAG              = 0x00000800;
	public const int CERT_STORE_READONLY_FLAG                    = 0x00008000;
	public const int CERT_STORE_OPEN_EXISTING_FLAG               = 0x00004000;
	public const int CERT_STORE_CREATE_NEW_FLAG                  = 0x00002000;
	public const int CERT_STORE_MAXIMUM_ALLOWED_FLAG             = 0x00001000;


	public const int CERT_SYSTEM_STORE_LOCATION_SHIFT = 16;
	public const int CERT_SYSTEM_STORE_CURRENT_USER = (CERT_SYSTEM_STORE_CURRENT_USER_ID << CERT_SYSTEM_STORE_LOCATION_SHIFT);
	public const int CERT_SYSTEM_STORE_LOCAL_MACHINE = (CERT_SYSTEM_STORE_LOCAL_MACHINE_ID << CERT_SYSTEM_STORE_LOCATION_SHIFT);


	public const int CERT_KEY_PROV_INFO_PROP_ID = 2;


	//
	// Vari tipi di algoritmi di firma/hashing
	//
	public const string szOID_RSA			=     "1.2.840.113549";
	public const string szOID_PKCS          =    "1.2.840.113549.1";
	public const string szOID_RSA_HASH      =    "1.2.840.113549.2";
	public const string szOID_RSA_ENCRYPT   =    "1.2.840.113549.3";

	public const string szOID_PKCS_1         =   "1.2.840.113549.1.1";
	public const string szOID_PKCS_2         =   "1.2.840.113549.1.2";
	public const string szOID_PKCS_3         =   "1.2.840.113549.1.3";
	public const string szOID_PKCS_4         =   "1.2.840.113549.1.4";
	public const string szOID_PKCS_5         =   "1.2.840.113549.1.5";
	public const string szOID_PKCS_6         =   "1.2.840.113549.1.6";
	public const string szOID_PKCS_7         =   "1.2.840.113549.1.7";
	public const string szOID_PKCS_8         =   "1.2.840.113549.1.8";
	public const string szOID_PKCS_9         =   "1.2.840.113549.1.9";
	public const string szOID_PKCS_10        =   "1.2.840.113549.1.10";
	public const string szOID_PKCS_12        =   "1.2.840.113549.1.12";

	public const string szOID_RSA_RSA          = "1.2.840.113549.1.1.1";
	public const string szOID_RSA_MD2RSA       = "1.2.840.113549.1.1.2";
	public const string szOID_RSA_MD4RSA       = "1.2.840.113549.1.1.3";
	public const string szOID_RSA_MD5RSA       = "1.2.840.113549.1.1.4";
	public const string szOID_RSA_SHA1RSA      = "1.2.840.113549.1.1.5";
	public const string szOID_RSA_SETOAEP_RSA  = "1.2.840.113549.1.1.6";

	public const string szOID_RSA_DH             = "1.2.840.113549.1.3.1";

	public const string szOID_RSA_data           = "1.2.840.113549.1.7.1";
	public const string szOID_RSA_signedData     = "1.2.840.113549.1.7.2";
	public const string szOID_RSA_envelopedData  = "1.2.840.113549.1.7.3";
	public const string szOID_RSA_signEnvData    = "1.2.840.113549.1.7.4";
	public const string szOID_RSA_digestedData   = "1.2.840.113549.1.7.5";
	public const string szOID_RSA_hashedData     = "1.2.840.113549.1.7.5";
	public const string szOID_RSA_encryptedData  = "1.2.840.113549.1.7.6";

	public const string szOID_RSA_emailAddr      = "1.2.840.113549.1.9.1";
	public const string szOID_RSA_unstructName   = "1.2.840.113549.1.9.2";
	public const string szOID_RSA_contentType    = "1.2.840.113549.1.9.3";
	public const string szOID_RSA_messageDigest  = "1.2.840.113549.1.9.4";
	public const string szOID_RSA_signingTime    = "1.2.840.113549.1.9.5";
	public const string szOID_RSA_counterSign    = "1.2.840.113549.1.9.6";
	public const string szOID_RSA_challengePwd   = "1.2.840.113549.1.9.7";
	public const string szOID_RSA_unstructAddr   = "1.2.840.113549.1.9.8";
	public const string szOID_RSA_extCertAttrs   = "1.2.840.113549.1.9.9";
	public const string szOID_RSA_certExtensions = "1.2.840.113549.1.9.14";
	public const string szOID_RSA_SMIMECapabilities = "1.2.840.113549.1.9.15";
	public const string szOID_RSA_preferSignedData  = "1.2.840.113549.1.9.15.1";

	public const string szOID_RSA_SMIMEalg            =  "1.2.840.113549.1.9.16.3";
	public const string szOID_RSA_SMIMEalgESDH        =  "1.2.840.113549.1.9.16.3.5";
	public const string szOID_RSA_SMIMEalgCMS3DESwrap =  "1.2.840.113549.1.9.16.3.6";
	public const string szOID_RSA_SMIMEalgCMSRC2wrap  =  "1.2.840.113549.1.9.16.3.7";

	public const string szOID_RSA_MD2            = "1.2.840.113549.2.2";
	public const string szOID_RSA_MD4            = "1.2.840.113549.2.4";
	public const string szOID_RSA_MD5            = "1.2.840.113549.2.5";

	public const string szOID_RSA_RC2CBC         = "1.2.840.113549.3.2";
	public const string szOID_RSA_RC4            = "1.2.840.113549.3.4";
	public const string szOID_RSA_DES_EDE3_CBC   = "1.2.840.113549.3.7";
	public const string szOID_RSA_RC5_CBCPad     = "1.2.840.113549.3.9";


	public const string szOID_ANSI_X942       =  "1.2.840.10046";
	public const string szOID_ANSI_X942_DH    =  "1.2.840.10046.2.1";

	public const string szOID_X957            =  "1.2.840.10040";
	public const string szOID_X957_DSA        =  "1.2.840.10040.4.1";
	public const string szOID_X957_SHA1DSA    =  "1.2.840.10040.4.3";

	// ITU-T UsefulDefinitions
	public const string szOID_DS              =  "2.5";
	public const string szOID_DSALG           =  "2.5.8";
	public const string szOID_DSALG_CRPT      =  "2.5.8.1";
	public const string szOID_DSALG_HASH      =  "2.5.8.2";

	public const string szOID_DSALG_SIGN      =  "2.5.8.3";
	public const string szOID_DSALG_RSA       =  "2.5.8.1.1";
	// NIST OSE Implementors' Workshop (OIW)
	// http://nemo.ncsl.nist.gov/oiw/agreements/stable/OSI/12s_9506.w51
	// http://nemo.ncsl.nist.gov/oiw/agreements/working/OSI/12w_9503.w51
	public const string szOID_OIW             =  "1.3.14";
	// NIST OSE Implementors' Workshop (OIW) Security SIG algorithm identifiers
	public const string szOID_OIWSEC          =  "1.3.14.3.2";
	public const string szOID_OIWSEC_md4RSA   =  "1.3.14.3.2.2";
	public const string szOID_OIWSEC_md5RSA   =  "1.3.14.3.2.3";
	public const string szOID_OIWSEC_md4RSA2  =  "1.3.14.3.2.4";
	public const string szOID_OIWSEC_desECB   =  "1.3.14.3.2.6";
	public const string szOID_OIWSEC_desCBC   =  "1.3.14.3.2.7";
	public const string szOID_OIWSEC_desOFB   =  "1.3.14.3.2.8";
	public const string szOID_OIWSEC_desCFB   =  "1.3.14.3.2.9";
	public const string szOID_OIWSEC_desMAC   =  "1.3.14.3.2.10";
	public const string szOID_OIWSEC_rsaSign  =  "1.3.14.3.2.11";
	public const string szOID_OIWSEC_dsa      =  "1.3.14.3.2.12";
	public const string szOID_OIWSEC_shaDSA   =  "1.3.14.3.2.13";
	public const string szOID_OIWSEC_mdc2RSA  =  "1.3.14.3.2.14";
	public const string szOID_OIWSEC_shaRSA   =  "1.3.14.3.2.15";
	public const string szOID_OIWSEC_dhCommMod = "1.3.14.3.2.16";
	public const string szOID_OIWSEC_desEDE    = "1.3.14.3.2.17";
	public const string szOID_OIWSEC_sha       = "1.3.14.3.2.18";
	public const string szOID_OIWSEC_mdc2      = "1.3.14.3.2.19";
	public const string szOID_OIWSEC_dsaComm   = "1.3.14.3.2.20";
	public const string szOID_OIWSEC_dsaCommSHA = "1.3.14.3.2.21";
	public const string szOID_OIWSEC_rsaXchg   = "1.3.14.3.2.22";
	public const string szOID_OIWSEC_keyHashSeal = "1.3.14.3.2.23";
	public const string szOID_OIWSEC_md2RSASign  = "1.3.14.3.2.24";
	public const string szOID_OIWSEC_md5RSASign  = "1.3.14.3.2.25";
	public const string szOID_OIWSEC_sha1      = "1.3.14.3.2.26";
	public const string szOID_OIWSEC_dsaSHA1   = "1.3.14.3.2.27";
	public const string szOID_OIWSEC_dsaCommSHA1 = "1.3.14.3.2.28";
	public const string szOID_OIWSEC_sha1RSASign = "1.3.14.3.2.29";
	// NIST OSE Implementors' Workshop (OIW) Directory SIG algorithm identifiers
	public const string szOID_OIWDIR          =  "1.3.14.7.2";
	public const string szOID_OIWDIR_CRPT     =  "1.3.14.7.2.1";
	public const string szOID_OIWDIR_HASH     =  "1.3.14.7.2.2";
	public const string szOID_OIWDIR_SIGN     =  "1.3.14.7.2.3";
	public const string szOID_OIWDIR_md2      =  "1.3.14.7.2.2.1";
	public const string szOID_OIWDIR_md2RSA   =  "1.3.14.7.2.3.1";


	// INFOSEC Algorithms
	// joint-iso-ccitt(2) country(16) us(840) organization(1) us-government(101) dod(2) id-infosec(1)
	public const string szOID_INFOSEC                        = "2.16.840.1.101.2.1";
	public const string szOID_INFOSEC_sdnsSignature          = "2.16.840.1.101.2.1.1.1";
	public const string szOID_INFOSEC_mosaicSignature        = "2.16.840.1.101.2.1.1.2";
	public const string szOID_INFOSEC_sdnsConfidentiality    = "2.16.840.1.101.2.1.1.3";
	public const string szOID_INFOSEC_mosaicConfidentiality  = "2.16.840.1.101.2.1.1.4";
	public const string szOID_INFOSEC_sdnsIntegrity          = "2.16.840.1.101.2.1.1.5";
	public const string szOID_INFOSEC_mosaicIntegrity        = "2.16.840.1.101.2.1.1.6";
	public const string szOID_INFOSEC_sdnsTokenProtection    = "2.16.840.1.101.2.1.1.7";
	public const string szOID_INFOSEC_mosaicTokenProtection  = "2.16.840.1.101.2.1.1.8";
	public const string szOID_INFOSEC_sdnsKeyManagement      = "2.16.840.1.101.2.1.1.9";
	public const string szOID_INFOSEC_mosaicKeyManagement    = "2.16.840.1.101.2.1.1.10";
	public const string szOID_INFOSEC_sdnsKMandSig           = "2.16.840.1.101.2.1.1.11";
	public const string szOID_INFOSEC_mosaicKMandSig         = "2.16.840.1.101.2.1.1.12";
	public const string szOID_INFOSEC_SuiteASignature        = "2.16.840.1.101.2.1.1.13";
	public const string szOID_INFOSEC_SuiteAConfidentiality  = "2.16.840.1.101.2.1.1.14";
	public const string szOID_INFOSEC_SuiteAIntegrity        = "2.16.840.1.101.2.1.1.15";
	public const string szOID_INFOSEC_SuiteATokenProtection  = "2.16.840.1.101.2.1.1.16";
	public const string szOID_INFOSEC_SuiteAKeyManagement    = "2.16.840.1.101.2.1.1.17";
	public const string szOID_INFOSEC_SuiteAKMandSig         = "2.16.840.1.101.2.1.1.18";
	public const string szOID_INFOSEC_mosaicUpdatedSig       = "2.16.840.1.101.2.1.1.19";
	public const string szOID_INFOSEC_mosaicKMandUpdSig      = "2.16.840.1.101.2.1.1.20";
	public const string szOID_INFOSEC_mosaicUpdatedInteg    = "2.16.840.1.101.2.1.1.21";



	//
	// Extension object identifiers
	//
	public const string szOID_AUTHORITY_KEY_IDENTIFIER  = "2.5.29.1";
	public const string szOID_KEY_ATTRIBUTES            = "2.5.29.2";
	public const string szOID_CERT_POLICIES_95          = "2.5.29.3";
	public const string szOID_KEY_USAGE_RESTRICTION     = "2.5.29.4";
	public const string szOID_SUBJECT_ALT_NAME          = "2.5.29.7";
	public const string szOID_ISSUER_ALT_NAME           = "2.5.29.8";
	public const string szOID_BASIC_CONSTRAINTS         = "2.5.29.10";
	public const string szOID_KEY_USAGE                 = "2.5.29.15";
	public const string szOID_PRIVATEKEY_USAGE_PERIOD   = "2.5.29.16";
	public const string szOID_BASIC_CONSTRAINTS2        = "2.5.29.19";

	public const string szOID_CERT_POLICIES             = "2.5.29.32";
	public const string szOID_ANY_CERT_POLICY           = "2.5.29.32.0";

	public const string szOID_AUTHORITY_KEY_IDENTIFIER2 = "2.5.29.35";
	public const string szOID_SUBJECT_KEY_IDENTIFIER    = "2.5.29.14";
	public const string szOID_SUBJECT_ALT_NAME2         = "2.5.29.17";
	public const string szOID_ISSUER_ALT_NAME2          = "2.5.29.18";
	public const string szOID_CRL_REASON_CODE           = "2.5.29.21";
	public const string szOID_REASON_CODE_HOLD          = "2.5.29.23";
	public const string szOID_CRL_DIST_POINTS           = "2.5.29.31";
	public const string szOID_ENHANCED_KEY_USAGE        = "2.5.29.37";
	public const string szOID_CRL_NUMBER                = "2.5.29.20";
	public const string szOID_DELTA_CRL_INDICATOR       = "2.5.29.27";
	public const string szOID_ISSUING_DIST_POINT        = "2.5.29.28";
	public const string szOID_FRESHEST_CRL              = "2.5.29.46";
	public const string szOID_NAME_CONSTRAINTS          = "2.5.29.30";
	public const string szOID_POLICY_MAPPINGS           = "2.5.29.33";
	public const string szOID_LEGACY_POLICY_MAPPINGS    = "2.5.29.5";
	public const string szOID_POLICY_CONSTRAINTS        = "2.5.29.36";
	public const string szOID_RENEWAL_CERTIFICATE        =   "1.3.6.1.4.1.311.13.1";
	public const string szOID_ENROLLMENT_NAME_VALUE_PAIR =   "1.3.6.1.4.1.311.13.2.1";
	public const string szOID_ENROLLMENT_CSP_PROVIDER    =   "1.3.6.1.4.1.311.13.2.2";
	public const string szOID_OS_VERSION                 =   "1.3.6.1.4.1.311.13.2.3";
	public const string szOID_ENROLLMENT_AGENT        =      "1.3.6.1.4.1.311.20.2.1";
	public const string szOID_PKIX                    =  "1.3.6.1.5.5.7";
	public const string szOID_PKIX_PE                 =  "1.3.6.1.5.5.7.1";
	public const string szOID_AUTHORITY_INFO_ACCESS   =  "1.3.6.1.5.5.7.1.1";
	public const string szOID_CERT_EXTENSIONS         =  "1.3.6.1.4.1.311.2.1.14";
	public const string szOID_NEXT_UPDATE_LOCATION    =  "1.3.6.1.4.1.311.10.2";
	public const string szOID_REMOVE_CERTIFICATE      =  "1.3.6.1.4.1.311.10.8.1";
	public const string szOID_CROSS_CERT_DIST_POINTS  =  "1.3.6.1.4.1.311.10.9.1";
	public const string szOID_CTL                     =  "1.3.6.1.4.1.311.10.1";
	public const string szOID_SORTED_CTL              =  "1.3.6.1.4.1.311.10.1.1";
	public const string szOID_SERIALIZED              =  "1.3.6.1.4.1.311.10.3.3.1";
	public const string szOID_NT_PRINCIPAL_NAME       =  "1.3.6.1.4.1.311.20.2.3";
	public const string szOID_PRODUCT_UPDATE          =  "1.3.6.1.4.1.311.31.1";
	public const string szOID_ANY_APPLICATION_POLICY  =  "1.3.6.1.4.1.311.10.12.1";
	public const string szOID_AUTO_ENROLL_CTL_USAGE   =  "1.3.6.1.4.1.311.20.1";
	public const string szOID_ENROLL_CERTTYPE_EXTENSION = "1.3.6.1.4.1.311.20.2";
	public const string szOID_CERT_MANIFOLD           =  "1.3.6.1.4.1.311.20.3";
	public const string szOID_CERTSRV_CA_VERSION      =  "1.3.6.1.4.1.311.21.1";
	public const string szOID_CERTSRV_PREVIOUS_CERT_HASH  =  "1.3.6.1.4.1.311.21.2";
	public const string szOID_CRL_VIRTUAL_BASE        =  "1.3.6.1.4.1.311.21.3";
	public const string szOID_CRL_NEXT_PUBLISH        =  "1.3.6.1.4.1.311.21.4";
	public const string szOID_KP_CA_EXCHANGE          =  "1.3.6.1.4.1.311.21.5";
	public const string szOID_KP_KEY_RECOVERY_AGENT   =  "1.3.6.1.4.1.311.21.6";
	public const string szOID_CERTIFICATE_TEMPLATE    =  "1.3.6.1.4.1.311.21.7";
	public const string szOID_ENTERPRISE_OID_ROOT     =  "1.3.6.1.4.1.311.21.8";
	public const string szOID_RDN_DUMMY_SIGNER        =  "1.3.6.1.4.1.311.21.9";
	public const string szOID_APPLICATION_CERT_POLICIES  =   "1.3.6.1.4.1.311.21.10";
	public const string szOID_APPLICATION_POLICY_MAPPINGS =  "1.3.6.1.4.1.311.21.11";
	public const string szOID_APPLICATION_POLICY_CONSTRAINTS  =  "1.3.6.1.4.1.311.21.12";
	public const string szOID_ARCHIVED_KEY_ATTR        =        "1.3.6.1.4.1.311.21.13";
	public const string szOID_CRL_SELF_CDP             =        "1.3.6.1.4.1.311.21.14";
	public const string szOID_REQUIRE_CERT_CHAIN_POLICY   =     "1.3.6.1.4.1.311.21.15";
	public const string szOID_ARCHIVED_KEY_CERT_HASH      =     "1.3.6.1.4.1.311.21.16";
	public const string szOID_ISSUED_CERT_HASH            =     "1.3.6.1.4.1.311.21.17";
	public const string szOID_DS_EMAIL_REPLICATION        =     "1.3.6.1.4.1.311.21.19";
	public const string szOID_REQUEST_CLIENT_INFO         =     "1.3.6.1.4.1.311.21.20";
	public const string szOID_ENCRYPTED_KEY_HASH          =     "1.3.6.1.4.1.311.21.21";
	public const string szOID_CERTSRV_CROSSCA_VERSION     =     "1.3.6.1.4.1.311.21.22";
	public const string szOID_NTDS_REPLICATION    =  "1.3.6.1.4.1.311.25.1";
	public const string szOID_SUBJECT_DIR_ATTRS     =    "2.5.29.9";
	public const string szOID_PKIX_KP               =    "1.3.6.1.5.5.7.3";
	public const string szOID_PKIX_KP_SERVER_AUTH    =   "1.3.6.1.5.5.7.3.1";
	public const string szOID_PKIX_KP_CLIENT_AUTH    =   "1.3.6.1.5.5.7.3.2";
	public const string szOID_PKIX_KP_CODE_SIGNING   =   "1.3.6.1.5.5.7.3.3";
	public const string szOID_PKIX_KP_EMAIL_PROTECTION  = "1.3.6.1.5.5.7.3.4";
	public const string szOID_PKIX_KP_IPSEC_END_SYSTEM = "1.3.6.1.5.5.7.3.5";
	public const string szOID_PKIX_KP_IPSEC_TUNNEL    =  "1.3.6.1.5.5.7.3.6";
	public const string szOID_PKIX_KP_IPSEC_USER    =    "1.3.6.1.5.5.7.3.7";
	public const string szOID_PKIX_KP_TIMESTAMP_SIGNING = "1.3.6.1.5.5.7.3.8";
	public const string szOID_IPSEC_KP_IKE_INTERMEDIATE  = "1.3.6.1.5.5.8.2.2";
	public const string szOID_KP_CTL_USAGE_SIGNING    =  "1.3.6.1.4.1.311.10.3.1";
	public const string szOID_KP_TIME_STAMP_SIGNING   =  "1.3.6.1.4.1.311.10.3.2";
	public const string szOID_SERVER_GATED_CRYPTO     =  "1.3.6.1.4.1.311.10.3.3";
	public const string szOID_SGC_NETSCAPE            =  "2.16.840.1.113730.4.1";
	public const string szOID_KP_EFS                  =  "1.3.6.1.4.1.311.10.3.4";
	public const string szOID_EFS_RECOVERY            =  "1.3.6.1.4.1.311.10.3.4.1";
	public const string szOID_WHQL_CRYPTO             =  "1.3.6.1.4.1.311.10.3.5";
	public const string szOID_NT5_CRYPTO              =  "1.3.6.1.4.1.311.10.3.6";
	public const string szOID_OEM_WHQL_CRYPTO         =  "1.3.6.1.4.1.311.10.3.7";
	public const string szOID_EMBEDDED_NT_CRYPTO      =  "1.3.6.1.4.1.311.10.3.8";
	public const string szOID_ROOT_LIST_SIGNER     =  "1.3.6.1.4.1.311.10.3.9";
	public const string szOID_KP_QUALIFIED_SUBORDINATION  =  "1.3.6.1.4.1.311.10.3.10";
	public const string szOID_KP_KEY_RECOVERY         =      "1.3.6.1.4.1.311.10.3.11";
	public const string szOID_KP_DOCUMENT_SIGNING      =     "1.3.6.1.4.1.311.10.3.12";
	public const string szOID_KP_LIFETIME_SIGNING       =    "1.3.6.1.4.1.311.10.3.13";
	public const string szOID_KP_MOBILE_DEVICE_SOFTWARE   =  "1.3.6.1.4.1.311.10.3.14";
	public const string szOID_DRM                    =   "1.3.6.1.4.1.311.10.5.1";
	public const string szOID_DRM_INDIVIDUALIZATION  = "1.3.6.1.4.1.311.10.5.2";
	public const string szOID_LICENSES                =  "1.3.6.1.4.1.311.10.6.1";
	public const string szOID_LICENSE_SERVER          =  "1.3.6.1.4.1.311.10.6.2";
	public const string szOID_KP_SMARTCARD_LOGON      =  "1.3.6.1.4.1.311.20.2.2";
	public const string szOID_YESNO_TRUST_ATTR        =  "1.3.6.1.4.1.311.10.4.1";
	public const string szOID_PKIX_POLICY_QUALIFIER_CPS           =    "1.3.6.1.5.5.7.2.1";
	public const string szOID_PKIX_POLICY_QUALIFIER_USERNOTICE    =    "1.3.6.1.5.5.7.2.2";
	public const string szOID_CERT_POLICIES_95_QUALIFIER1        =     "2.16.840.1.113733.1.7.1.1";


	
	public const uint CERT_NAME_SIMPLE_DISPLAY_TYPE = 4;

	public const uint CERT_SIMPLE_NAME_STR			=  1;
	public const uint CERT_OID_NAME_STR				=  2;
	public const uint CERT_X500_NAME_STR			=  3;

	//+-------------------------------------------------------------------------
	//  Certificate name string type flags OR'ed with the above types
	//--------------------------------------------------------------------------
	public const uint CERT_NAME_STR_SEMICOLON_FLAG    = 0x40000000;
	public const uint CERT_NAME_STR_NO_PLUS_FLAG      = 0x20000000;
	public const uint CERT_NAME_STR_NO_QUOTING_FLAG   = 0x10000000;
	public const uint CERT_NAME_STR_CRLF_FLAG         = 0x08000000;
	public const uint CERT_NAME_STR_COMMA_FLAG        = 0x04000000;
	public const uint CERT_NAME_STR_REVERSE_FLAG      = 0x02000000;

	public const uint CERT_NAME_STR_DISABLE_IE4_UTF8_FLAG     = 0x00010000;
	public const uint CERT_NAME_STR_ENABLE_T61_UNICODE_FLAG   = 0x00020000;
	public const uint CERT_NAME_STR_ENABLE_UTF8_UNICODE_FLAG  = 0x00040000;



	// Byte[0]
	public const ushort CERT_DIGITAL_SIGNATURE_KEY_USAGE     = 0x80;
	public const ushort CERT_NON_REPUDIATION_KEY_USAGE       = 0x40;
	public const ushort CERT_KEY_ENCIPHERMENT_KEY_USAGE      = 0x20;
	public const ushort CERT_DATA_ENCIPHERMENT_KEY_USAGE     = 0x10;
	public const ushort CERT_KEY_AGREEMENT_KEY_USAGE         = 0x08;
	public const ushort CERT_KEY_CERT_SIGN_KEY_USAGE         = 0x04;
	public const ushort CERT_OFFLINE_CRL_SIGN_KEY_USAGE      = 0x02;
	public const ushort CERT_CRL_SIGN_KEY_USAGE              = 0x02;
	public const ushort CERT_ENCIPHER_ONLY_KEY_USAGE         = 0x01;
	// Byte[1]
	public const ushort CERT_DECIPHER_ONLY_KEY_USAGE         = 0x80 << 8;

 

	//
	// Usati in CryptMsgGetParam
	//
	public const uint CMSG_TYPE_PARAM                        = 1;
	public const uint CMSG_CONTENT_PARAM                     = 2;
	public const uint CMSG_BARE_CONTENT_PARAM                = 3;
	public const uint CMSG_INNER_CONTENT_TYPE_PARAM          = 4;
	public const uint CMSG_SIGNER_COUNT_PARAM                = 5;
	public const uint CMSG_SIGNER_INFO_PARAM                 = 6;
	public const uint CMSG_SIGNER_CERT_INFO_PARAM            = 7;
	public const uint CMSG_SIGNER_HASH_ALGORITHM_PARAM       = 8;
	public const uint CMSG_SIGNER_AUTH_ATTR_PARAM            = 9;
	public const uint CMSG_SIGNER_UNAUTH_ATTR_PARAM          = 10;
	public const uint CMSG_CERT_COUNT_PARAM                  = 11;
	public const uint CMSG_CERT_PARAM                        = 12;
	public const uint CMSG_CRL_COUNT_PARAM                   = 13;
	public const uint CMSG_CRL_PARAM                         = 14;
	public const uint CMSG_ENVELOPE_ALGORITHM_PARAM          = 15;
	public const uint CMSG_RECIPIENT_COUNT_PARAM             = 17;
	public const uint CMSG_RECIPIENT_INDEX_PARAM             = 18;
	public const uint CMSG_RECIPIENT_INFO_PARAM              = 19;
	public const uint CMSG_HASH_ALGORITHM_PARAM              = 20;
	public const uint CMSG_HASH_DATA_PARAM                   = 21;
	public const uint CMSG_COMPUTED_HASH_PARAM               = 22;
	public const uint CMSG_ENCRYPT_PARAM                     = 26;
	public const uint CMSG_ENCRYPTED_DIGEST                  = 27;
	public const uint CMSG_ENCODED_SIGNER                    = 28;
	public const uint CMSG_ENCODED_MESSAGE                   = 29;
	public const uint CMSG_VERSION_PARAM                     = 30;
	public const uint CMSG_ATTR_CERT_COUNT_PARAM             = 31;
	public const uint CMSG_ATTR_CERT_PARAM                   = 32;
	public const uint CMSG_CMS_RECIPIENT_COUNT_PARAM         = 33;
	public const uint CMSG_CMS_RECIPIENT_INDEX_PARAM         = 34;
	public const uint CMSG_CMS_RECIPIENT_ENCRYPTED_KEY_INDEX_PARAM  = 35;
	public const uint CMSG_CMS_RECIPIENT_INFO_PARAM          = 36;
	public const uint CMSG_UNPROTECTED_ATTR_PARAM            = 37;
	public const uint CMSG_SIGNER_CERT_ID_PARAM              = 38;
	public const uint CMSG_CMS_SIGNER_INFO_PARAM             = 39;


	public const uint USAGE_MATCH_TYPE_AND					= 0x00000000;
	public const uint USAGE_MATCH_TYPE_OR					= 0x00000001;

	//
	// usato in CryptAcquireContext
	//
	public const uint CRYPT_VERIFYCONTEXT  =   0xF0000000;
	public const uint CRYPT_NEWKEYSET      =   0x00000008;
	public const uint CRYPT_DELETEKEYSET   =   0x00000010;
	public const uint CRYPT_MACHINE_KEYSET =   0x00000020;
	public const uint CRYPT_SILENT         =   0x00000040;


	//
	// errore CDP mancante sul certificato
	//
	public const uint HERROR_OBJECT_NOT_PRESENT = 0x80092004;

	//
	// Errori di stato sulla catena di trust
	// Si applicano ai certificati e alla catena di trust
	public enum CertTrustProblemsErrorStatus 
	{
		CERT_TRUST_NO_ERROR								= 0x00000000,
		CERT_TRUST_IS_NOT_TIME_VALID					= 0x00000001,
		CERT_TRUST_IS_NOT_TIME_NESTED					= 0x00000002,
		CERT_TRUST_IS_REVOKED							= 0x00000004,
		CERT_TRUST_IS_NOT_SIGNATURE_VALID				= 0x00000008,
		CERT_TRUST_IS_NOT_VALID_FOR_USAGE				= 0x00000010,
		CERT_TRUST_IS_UNTRUSTED_ROOT					= 0x00000020,
		CERT_TRUST_REVOCATION_STATUS_UNKNOWN			= 0x00000040,
		CERT_TRUST_IS_CYCLIC							= 0x00000080,
		CERT_TRUST_INVALID_EXTENSION					= 0x00000100,
		CERT_TRUST_INVALID_POLICY_CONSTRAINTS			= 0x00000200,
		CERT_TRUST_INVALID_BASIC_CONSTRAINTS			= 0x00000400,
		CERT_TRUST_INVALID_NAME_CONSTRAINTS				= 0x00000800,
		CERT_TRUST_HAS_NOT_SUPPORTED_NAME_CONSTRAINT	= 0x00001000,
		CERT_TRUST_HAS_NOT_DEFINED_NAME_CONSTRAINT		= 0x00002000,
		CERT_TRUST_HAS_NOT_PERMITTED_NAME_CONSTRAINT	= 0x00004000,
		CERT_TRUST_HAS_EXCLUDED_NAME_CONSTRAINT			= 0x00008000,
		CERT_TRUST_IS_OFFLINE_REVOCATION				= 0x01000000,
		CERT_TRUST_NO_ISSUANCE_CHAIN_POLICY				= 0x02000000,
		CERT_TRUST_IS_PARTIAL_CHAIN						= 0x00010000,
		CERT_TRUST_CTL_IS_NOT_TIME_VALID				= 0x00020000,
		CERT_TRUST_CTL_IS_NOT_SIGNATURE_VALID			= 0x00040000,
		CERT_TRUST_CTL_IS_NOT_VALID_FOR_USAGE			= 0x00080000,
	};

	//
	// Informazioni aggiuntive sugli errori di stato sulla catena di trust
	//
	public enum CertTrustProblemsInfoStatus 
	{
		CERT_TRUST_HAS_EXACT_MATCH_ISSUER				= 0x00000001,
		CERT_TRUST_HAS_KEY_MATCH_ISSUER					= 0x00000002,
		CERT_TRUST_HAS_NAME_MATCH_ISSUER				= 0x00000004,
		CERT_TRUST_IS_SELF_SIGNED						= 0x00000008,
		CERT_TRUST_HAS_PREFERRED_ISSUER					= 0x00000100,
		CERT_TRUST_HAS_ISSUANCE_CHAIN_POLICY			= 0x00000200,
		CERT_TRUST_HAS_VALID_NAME_CONSTRAINTS			= 0x00000400,
		CERT_TRUST_IS_COMPLEX_CHAIN						= 0x00010000
	};


		//
		// flags usati per CryptGenKey
		//
	 	public const uint CRYPT_EXPORTABLE   =    0x00000001;
	 	public const uint CRYPT_USER_PROTECTED =   0x00000002;
	 	public const uint CRYPT_CREATE_SALT  =     0x00000004;
	 	public const uint CRYPT_UPDATE_KEY   =     0x00000008;
	 	public const uint CRYPT_NO_SALT      =     0x00000010;
	 	public const uint CRYPT_PREGEN       =     0x00000040;
	 	public const uint CRYPT_RECIPIENT    =     0x00000010;
	 	public const uint CRYPT_INITIATOR    =     0x00000040;
	 	public const uint CRYPT_ONLINE       =     0x00000080;
	 	public const uint CRYPT_SF           =     0x00000100;
	 	public const uint CRYPT_CREATE_IV    =     0x00000200;
	 	public const uint CRYPT_KEK          =     0x00000400;
	 	public const uint CRYPT_DATA_KEY     =     0x00000800;
	 	public const uint CRYPT_VOLATILE     =     0x00001000;
	 	public const uint CRYPT_SGCKEY       =     0x00002000;
	 	public const uint CRYPT_ARCHIVABLE   =     0x00004000;
	 	public const uint RSA1024BIT_KEY     =     0x04000000;

		//
		// Usati per Certificate Distribution Points (CRL)
		//
	 	public const uint CRYPT_GET_URL_FROM_PROPERTY			= 0x00000001;
	 	public const uint CRYPT_GET_URL_FROM_EXTENSION			= 0x00000002;
	 	public const uint CRYPT_GET_URL_FROM_UNAUTH_ATTRIBUTE	= 0x00000004;
	 	public const uint CRYPT_GET_URL_FROM_AUTH_ATTRIBUTE		= 0x00000008;

		public const uint URL_OID_CERTIFICATE_ISSUER			= 1;
		public const uint URL_OID_CERTIFICATE_CRL_DIST_POINT	= 2;
		public const uint URL_OID_CTL_ISSUER					= 3;
		public const uint URL_OID_CTL_NEXT_UPDATE				= 4;
		public const uint URL_OID_CRL_ISSUER					= 5;
		public const uint URL_OID_CERTIFICATE_FRESHEST_CRL      = 6;
		public const uint URL_OID_CRL_FRESHEST_CRL				= 7;
		public const uint URL_OID_CROSS_CERT_DIST_POINT			= 8;

		//
		// Usati per il retrieve della CRL
		//
		public const uint CONTEXT_OID_CERTIFICATE		= 1;
		public const uint CONTEXT_OID_CRL				= 2;
		public const uint CONTEXT_OID_CTL				= 3;
		public const uint CONTEXT_OID_PKCS7				= 4;
		public const uint CONTEXT_OID_CAPI2_ANY			= 5;


		public const uint CRYPT_RETRIEVE_MULTIPLE_OBJECTS       =  0x00000001;
		public const uint CRYPT_CACHE_ONLY_RETRIEVAL            =  0x00000002;
		public const uint CRYPT_WIRE_ONLY_RETRIEVAL             =  0x00000004;
		public const uint CRYPT_DONT_CACHE_RESULT               =  0x00000008;
		public const uint CRYPT_ASYNC_RETRIEVAL                 =  0x00000010;
		public const uint CRYPT_STICKY_CACHE_RETRIEVAL          =  0x00001000;
		public const uint CRYPT_LDAP_SCOPE_BASE_ONLY_RETRIEVAL  =  0x00002000;
		public const uint CRYPT_OFFLINE_CHECK_RETRIEVAL         =  0x00004000;
		public const uint CRYPT_LDAP_INSERT_ENTRY_ATTRIBUTE     =  0x00008000;
		public const uint CRYPT_LDAP_SIGN_RETRIEVAL             =  0x00010000;
		public const uint CRYPT_NO_AUTH_RETRIEVAL               =  0x00020000;
		public const uint CRYPT_LDAP_AREC_EXCLUSIVE_RETRIEVAL   =  0x00040000;
		public const uint CRYPT_AIA_RETRIEVAL                   =  0x00080000;
		public const uint CRYPT_VERIFY_CONTEXT_SIGNATURE        =  0x00000020;
		public const uint CRYPT_VERIFY_DATA_HASH                =  0x00000040;
		public const uint CRYPT_KEEP_TIME_VALID                 =  0x00000080;
		public const uint CRYPT_DONT_VERIFY_SIGNATURE           =  0x00000100;
		public const uint CRYPT_DONT_CHECK_TIME_VALIDITY        =  0x00000200;
		public const uint CRYPT_CHECK_FRESHNESS_TIME_VALIDITY   =  0x00000400;
		public const uint CRYPT_ACCUMULATIVE_TIMEOUT            =  0x00000800;


		//
		// strutture per CryptEncodeObject/CryptDecodeObject
		//
		public const uint CRYPT_ENCODE_DECODE_NONE				= 0;
		public const uint X509_CERT								= 1;
		public const uint X509_CERT_TO_BE_SIGNED				= 2;
		public const uint X509_CERT_CRL_TO_BE_SIGNED			= 3;
		public const uint X509_CERT_REQUEST_TO_BE_SIGNED		= 4;
		public const uint X509_EXTENSIONS     					= 5;
		public const uint X509_NAME_VALUE              			= 6;
		public const uint X509_NAME                    			= 7;
		public const uint X509_PUBLIC_KEY_INFO         			= 8;
		public const uint X509_AUTHORITY_KEY_ID      			= 9;
		public const uint X509_KEY_ATTRIBUTES          			= 10;
		public const uint X509_KEY_USAGE_RESTRICTION   			= 11;
		public const uint X509_ALTERNATE_NAME            		= 12;
		public const uint X509_BASIC_CONSTRAINTS      			= 13;
		public const uint X509_KEY_USAGE                		= 14;
		public const uint X509_BASIC_CONSTRAINTS2        		= 15;
		public const uint X509_CERT_POLICIES          			= 16;
		public const uint PKCS_UTC_TIME               			= 17;
		public const uint PKCS_TIME_REQUEST           			= 18;
		public const uint RSA_CSP_PUBLICKEYBLOB         		= 19;
		public const uint X509_UNICODE_NAME          			= 20;
		public const uint X509_KEYGEN_REQUEST_TO_BE_SIGNED  	= 21;
		public const uint PKCS_ATTRIBUTE          				= 22;
		public const uint PKCS_CONTENT_INFO_SEQUENCE_OF_ANY  	= 23;
		public const uint X509_UNICODE_NAME_VALUE   			= 24;
		public const uint X509_ANY_STRING						= X509_NAME_VALUE;
		public const uint X509_UNICODE_ANY_STRING				= X509_UNICODE_NAME_VALUE;
		public const uint X509_OCTET_STRING         			= 25;
		public const uint X509_BITS               				= 26;
		public const uint X509_INTEGER               			= 27;
		public const uint X509_MULTI_BYTE_INTEGER     			= 28;
		public const uint X509_ENUMERATED            			= 29;
		public const uint X509_CHOICE_OF_TIME        			= 30;
		public const uint X509_AUTHORITY_KEY_ID2       			= 31;
		public const uint X509_AUTHORITY_INFO_ACCESS     		= 32;
		public const uint X509_CRL_REASON_CODE					= X509_ENUMERATED;
		public const uint PKCS_CONTENT_INFO          			= 33;
		public const uint X509_SEQUENCE_OF_ANY        			= 34;
		public const uint X509_CRL_DIST_POINTS       			= 35;
		public const uint X509_ENHANCED_KEY_USAGE     			= 36;
		public const uint PKCS_CTL                  			= 37;
		public const uint X509_MULTI_BYTE_UINT     				= 38;
		public const uint X509_DSS_PUBLICKEY					= X509_MULTI_BYTE_UINT;
		public const uint X509_DSS_PARAMETERS        			= 39;
		public const uint X509_DSS_SIGNATURE          			= 40;
		public const uint PKCS_RC2_CBC_PARAMETERS    			= 41;
		public const uint PKCS_SMIME_CAPABILITIES   			= 42;
		public const uint PKCS_RSA_PRIVATE_KEY       			= 43;
		public const uint PKCS_PRIVATE_KEY_INFO      			= 44;
		public const uint PKCS_ENCRYPTED_PRIVATE_KEY_INFO		= 45;
		public const uint X509_PKIX_POLICY_QUALIFIER_USERNOTICE =  46;
		public const uint X509_DH_PUBLICKEY						= X509_MULTI_BYTE_UINT;
		public const uint X509_DH_PARAMETERS   					= 47;
		public const uint PKCS_ATTRIBUTES        				= 48;
		public const uint PKCS_SORTED_CTL      					= 49;
		public const uint X942_DH_PARAMETERS       				= 50;
		public const uint X509_BITS_WITHOUT_TRAILING_ZEROES  	= 51;
		public const uint X942_OTHER_INFO       				= 52;
		public const uint X509_CERT_PAIR      					= 53;
		public const uint X509_ISSUING_DIST_POINT   			= 54;
		public const uint X509_NAME_CONSTRAINTS   				= 55;
		public const uint X509_POLICY_MAPPINGS    				= 56;
		public const uint X509_POLICY_CONSTRAINTS  				= 57;
		public const uint X509_CROSS_CERT_DIST_POINTS  			= 58;
		public const uint CMC_DATA                 				= 59;
		public const uint CMC_RESPONSE             				= 60;
		public const uint CMC_STATUS               				= 61;
		public const uint CMC_ADD_EXTENSIONS      				= 62;
		public const uint CMC_ADD_ATTRIBUTES      				= 63;
		public const uint X509_CERTIFICATE_TEMPLATE  			= 64;
		public const uint PKCS7_SIGNER_INFO   					= 500;
		public const uint CMS_SIGNER_INFO   					= 501;


		//
		// Usati da CryptVerifyCertificateSignatureEx
		//

		// pvSubject
		public const uint CRYPT_VERIFY_CERT_SIGN_SUBJECT_BLOB   = 1;
		public const uint CRYPT_VERIFY_CERT_SIGN_SUBJECT_CERT   = 2;
		public const uint CRYPT_VERIFY_CERT_SIGN_SUBJECT_CRL    = 3;

		// pvIssuer
		public const uint CRYPT_VERIFY_CERT_SIGN_ISSUER_PUBKEY  = 1;
		public const uint CRYPT_VERIFY_CERT_SIGN_ISSUER_CERT    = 2;
		public const uint CRYPT_VERIFY_CERT_SIGN_ISSUER_CHAIN   = 3;
		public const uint CRYPT_VERIFY_CERT_SIGN_ISSUER_NULL    = 4;
	

	//
	// Struct definition
	//

	[StructLayout(LayoutKind.Sequential)] public struct CRYPT_OBJID_BLOB 
	{
		public uint      cbData;
		public IntPtr    pbData;
	};
	[StructLayout(LayoutKind.Sequential)] public struct CRYPT_ATTR_BLOB 
	{
		public uint      cbData;
		public IntPtr    pbData;
	};



	[StructLayout(LayoutKind.Sequential/*, CharSet=CharSet.Ansi*/)] public struct CRYPT_ALGORITHM_IDENTIFIER 
	{
		public String              pszObjId;
		public CRYPT_OBJID_BLOB    Parameters;
	};
	[StructLayout(LayoutKind.Sequential)] public struct CRYPT_ALGORITHM_IDENTIFIER_2
	{
		public IntPtr              pszObjId;
		public CRYPT_OBJID_BLOB    Parameters;
	};


	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Ansi)]
		public struct CRYPT_SIGN_MESSAGE_PARA 
	{
		public int                        cbSize;
		public uint                       dwMsgEncodingType;
		public IntPtr                     pSigningCert;
		public CRYPT_ALGORITHM_IDENTIFIER HashAlgorithm;
		public IntPtr                     pvHashAuxInfo;
		public uint                       cMsgCert;
		public IntPtr                     rgpMsgCert;
		public uint                       cMsgCrl;
		public IntPtr                     rgpMsgCrl;
		public uint                       cAuthAttr;
		public IntPtr                     rgAuthAttr;
		public uint                       cUnauthAttr;
		public IntPtr                     rgUnauthAttr;
		public uint                       dwFlags;
		public uint                       dwInnerContentType;
	};



	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Ansi)]
		public struct CRYPT_ATTRIBUTE 
	{
		public	IntPtr		pszObjId;
		public	DWORD       cValue;
		public	IntPtr		rgValue;
	};


	/*
	typedef struct _CRYPT_ATTRIBUTES 
		{
			IN DWORD                cAttr;
			IN PCRYPT_ATTRIBUTE     rgAttr;
		} CRYPT_ATTRIBUTES, *PCRYPT_ATTRIBUTES;
	*/
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Ansi)]
		public struct CRYPT_ATTRIBUTES 
	{
		public DWORD             cAttr;
		public IntPtr			 rgAttr;
	}


	/*
			struct _CRYPT_KEY_PROV_INFO 
			{
				LPWSTR                  pwszContainerName;
				LPWSTR                  pwszProvName;
				DWORD                   dwProvType;
				DWORD                   dwFlags;
				DWORD                   cProvParam;
				PCRYPT_KEY_PROV_PARAM   rgProvParam;
				DWORD                   dwKeySpec;
			}
	*/
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
	public struct CRYPT_KEY_PROV_INFO 
	{
		public IntPtr        pwszContainerName;
		public IntPtr        pwszProvName;
		public uint          dwProvType;
		public uint          dwFlags;
		public uint          cProvParam;
		public IntPtr        rgProvParam;
		public uint          dwKeySpec;
	};


	/*
		struct CERT_CONTEXT
		{
				DWORD                   dwCertEncodingType;
				BYTE                    *pbCertEncoded;
				DWORD                   cbCertEncoded;
				PCERT_INFO              pCertInfo;
				HCERTSTORE              hCertStore;
		};
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CERT_CONTEXT 
	{
		public uint    dwCertEncodingType;
		public IntPtr  pbCertEncoded;
		public uint    cbCertEncoded;
		public IntPtr  pCertInfo;
		public IntPtr  hCertStore;
	};


	/*
			struct CERT_INFO {
				DWORD                       dwVersion;
				CRYPT_INTEGER_BLOB          SerialNumber;
				CRYPT_ALGORITHM_IDENTIFIER  SignatureAlgorithm;
				CERT_NAME_BLOB              Issuer;
				FILETIME                    NotBefore;
				FILETIME                    NotAfter;
				CERT_NAME_BLOB              Subject;
				CERT_PUBLIC_KEY_INFO        SubjectPublicKeyInfo;
				CRYPT_BIT_BLOB              IssuerUniqueId;
				CRYPT_BIT_BLOB              SubjectUniqueId;
				DWORD                       cExtension;
				PCERT_EXTENSION             rgExtension;
			};

			struct CRYPT_INTEGER_BLOB {
				DWORD   cbData;
				BYTE    *pbData;
			} 

			struct CRYPT_ALGORITHM_IDENTIFIER {
				LPSTR               pszObjId;
				CRYPT_OBJID_BLOB    Parameters;
			};

			typedef struct _FILETIME
			{
				DWORD dwLowDateTime;
				DWORD dwHighDateTime;
			} 	FILETIME;


			typedef struct _CERT_PUBLIC_KEY_INFO {
				CRYPT_ALGORITHM_IDENTIFIER    Algorithm;
				CRYPT_BIT_BLOB                PublicKey;
			} CERT_PUBLIC_KEY_INFO, *PCERT_PUBLIC_KEY_INFO;

			typedef struct _CRYPT_BIT_BLOB {
				DWORD   cbData;
				BYTE    *pbData;
				DWORD   cUnusedBits;
			} CRYPT_BIT_BLOB, *PCRYPT_BIT_BLOB;

			*/

	[StructLayout(LayoutKind.Sequential)] public struct CRYPT_INTEGER_BLOB
	{
		public uint    cbData;
		public IntPtr  pbData;
	};

	[StructLayout(LayoutKind.Sequential)] public struct CRYPT_DATA_BLOB
	{
		public uint    cbData;
		public IntPtr  pbData;
	};


	[StructLayout(LayoutKind.Sequential)] public struct CERT_NAME_BLOB
	{
		public uint    cbData;
		public IntPtr  pbData;
	};


	[StructLayout(LayoutKind.Sequential)] public struct FILETIME
	{
		public uint dwLowDateTime;
		public uint dwHighDateTime;
	};

	[StructLayout(LayoutKind.Sequential)] public struct CRYPT_BIT_BLOB 
	{
		public uint   cbData;
		public IntPtr pbData;
		public uint   cUnusedBits;
	};

	[StructLayout(LayoutKind.Sequential)] public struct CERT_PUBLIC_KEY_INFO 
	{
		public CRYPT_ALGORITHM_IDENTIFIER_2  Algorithm;
		public CRYPT_BIT_BLOB                PublicKey;
	};
	

	/*
	typedef struct _CERT_EXTENSION 
			{
				LPSTR               pszObjId;
				BOOL                fCritical;
				CRYPT_OBJID_BLOB    Value;
			} CERT_EXTENSION, *PCERT_EXTENSION;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CERT_EXTENSION 
	{
		public IntPtr			pszObjId;
		public BOOL				fCritical;
		public CRYPT_OBJID_BLOB	Value;
	}



	[StructLayout(LayoutKind.Sequential)] public struct CERT_INFO
	{
		public uint                         dwVersion;
		public CRYPT_INTEGER_BLOB           SerialNumber;
		public CRYPT_ALGORITHM_IDENTIFIER_2 SignatureAlgorithm;
		public CERT_NAME_BLOB               Issuer;
		public FILETIME                     NotBefore;
		public FILETIME                     NotAfter;
		public CERT_NAME_BLOB               Subject;
		public CERT_PUBLIC_KEY_INFO         SubjectPublicKeyInfo;
		public CRYPT_BIT_BLOB               IssuerUniqueId;
		public CRYPT_BIT_BLOB               SubjectUniqueId;
		public uint                         cExtension;
		public IntPtr/*PCERT_EXTENSION*/    rgExtension;
	};

	/*
	typedef struct _CRYPT_VERIFY_MESSAGE_PARA 
	{
		DWORD                               cbSize;
		DWORD                               dwMsgAndCertEncodingType;
		HCRYPTPROV                          hCryptProv;
		PFN_CRYPT_GET_SIGNER_CERTIFICATE    pfnGetSignerCertificate;
		void                                *pvGetArg;
	} CRYPT_VERIFY_MESSAGE_PARA, *PCRYPT_VERIFY_MESSAGE_PARA;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CRYPT_VERIFY_MESSAGE_PARA
	{
		public DWORD							cbSize;
		public DWORD							dwMsgAndCertEncodingType;
		public HCRYPTPROV						hCryptProv;
		public PFN_CRYPT_GET_SIGNER_CERTIFICATE pfnGetSignerCertificate;
		public IntPtr							pvGetArg;
	};

	/*
	typedef struct _CTL_USAGE 
			{
				DWORD               cUsageIdentifier;
				LPSTR               *rgpszUsageIdentifier;      // array of pszObjId
			} CTL_USAGE, *PCTL_USAGE,
	CERT_ENHKEY_USAGE, *PCERT_ENHKEY_USAGE;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CERT_ENHKEY_USAGE
	{
		public DWORD    cUsageIdentifier;
		public IntPtr	rgpszUsageIdentifier;      // array of pszObjId
	}

     /*
	typedef struct _CERT_USAGE_MATCH 
			{
				DWORD             dwType;
				CERT_ENHKEY_USAGE Usage;

			} CERT_USAGE_MATCH, *PCERT_USAGE_MATCH;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CERT_USAGE_MATCH
	{
		public DWORD  dwType;
		public CERT_ENHKEY_USAGE Usage;
	}






	/*
	typedef struct _CERT_CHAIN_PARA 
			{
				DWORD            cbSize;
				CERT_USAGE_MATCH RequestedUsage;
#ifdef CERT_CHAIN_PARA_HAS_EXTRA_FIELDS
				// Note, if you #define CERT_CHAIN_PARA_HAS_EXTRA_FIELDS, then, you
				// must zero all unused fields in this data structure.
				// More fields could be added in a future release.
				CERT_USAGE_MATCH RequestedIssuancePolicy;
				DWORD            dwUrlRetrievalTimeout;     // milliseconds
				BOOL             fCheckRevocationFreshnessTime;
				DWORD            dwRevocationFreshnessTime; // seconds
#endif
			} CERT_CHAIN_PARA, *PCERT_CHAIN_PARA;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CERT_CHAIN_PARA
	{
		public DWORD            cbSize;
		public CERT_USAGE_MATCH RequestedUsage;
	}

	/*
	typedef struct _CERT_TRUST_STATUS 
			{

				DWORD dwErrorStatus;
				DWORD dwInfoStatus;

			} CERT_TRUST_STATUS, *PCERT_TRUST_STATUS;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CERT_TRUST_STATUS
	{
		public DWORD dwErrorStatus;
		public DWORD dwInfoStatus;
	}

	/*
	struct _CERT_CHAIN_CONTEXT 
	{
		DWORD                   cbSize;
		CERT_TRUST_STATUS       TrustStatus;
		DWORD                   cChain;
		PCERT_SIMPLE_CHAIN*     rgpChain;

		// Following is returned when CERT_CHAIN_RETURN_LOWER_QUALITY_CONTEXTS
		// is set in dwFlags
		DWORD                   cLowerQualityChainContext;
		PCCERT_CHAIN_CONTEXT*   rgpLowerQualityChainContext;

		// fHasRevocationFreshnessTime is only set if we are able to retrieve
		// revocation information for all elements checked for revocation.
		// For a CRL its CurrentTime - ThisUpdate.
		//
		// dwRevocationFreshnessTime is the largest time across all elements
		// checked.
		BOOL                    fHasRevocationFreshnessTime;
		DWORD                   dwRevocationFreshnessTime;    // seconds
	};
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CERT_CHAIN_CONTEXT
	{
		public DWORD                   cbSize;
		public CERT_TRUST_STATUS	   TrustStatus;
		public DWORD                   cChain;
		public IntPtr				   rgpChain;
		public DWORD                   cLowerQualityChainContext;
		public IntPtr				   rgpLowerQualityChainContext;
		public BOOL                    fHasRevocationFreshnessTime;
		public DWORD                   dwRevocationFreshnessTime;
	}


	/*
  	typedef struct _CRYPT_URL_ARRAY 
	{
		DWORD   cUrl;
		LPWSTR* rgwszUrl;
	} CRYPT_URL_ARRAY, *PCRYPT_URL_ARRAY;
	*/
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] public struct CRYPT_URL_ARRAY
	{
		public uint cUrl;
		public IntPtr rgwszUrl;
	}



    /*
	typedef struct _CRYPT_URL_INFO 
			{
				DWORD   cbSize;

				// Seconds between syncs
				DWORD   dwSyncDeltaTime;

				// Returned URLs may be grouped. For instance, groups of cross cert
				// distribution points. Each distribution point may have multiple
				// URLs, (LDAP and HTTP scheme).
				DWORD   cGroup;
				DWORD   *rgcGroupEntry;
			} CRYPT_URL_INFO, *PCRYPT_URL_INFO;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CRYPT_URL_INFO 
	{
		public DWORD	cbSize;
		public DWORD	dwSyncDeltaTime;
		public DWORD	cGroup;
		public IntPtr	rgcGroupEntry;

	}


	/*
	typedef struct _CRL_CONTEXT 
			{
				DWORD                   dwCertEncodingType;
				BYTE                    *pbCrlEncoded;
				DWORD                   cbCrlEncoded;
				PCRL_INFO               pCrlInfo;
				HCERTSTORE              hCertStore;
			} CRL_CONTEXT, *PCRL_CONTEXT;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CRL_CONTEXT
	{
		public DWORD   dwCertEncodingType;
		public IntPtr  pbCrlEncoded;
		public DWORD   cbCrlEncoded;
		public IntPtr  pCrlInfo;
		public IntPtr  hCertStore;
	}

	/*
	typedef struct _CRL_INFO 
			{
				DWORD                       dwVersion;
				CRYPT_ALGORITHM_IDENTIFIER  SignatureAlgorithm;
				CERT_NAME_BLOB              Issuer;
				FILETIME                    ThisUpdate;
				FILETIME                    NextUpdate;
				DWORD                       cCRLEntry;
				PCRL_ENTRY                  rgCRLEntry;
				DWORD                       cExtension;
				PCERT_EXTENSION             rgExtension;
			} CRL_INFO, *PCRL_INFO;
	*/

	[StructLayout(LayoutKind.Sequential)] public struct CRL_INFO 
	{
		public	DWORD                       dwVersion;
		public	CRYPT_ALGORITHM_IDENTIFIER  SignatureAlgorithm;
		public 	CERT_NAME_BLOB              Issuer;
		public	long	                    ThisUpdate;
		public	long	                    NextUpdate;
		public	DWORD                       cCRLEntry;
		public	IntPtr						rgCRLEntry;
		public	DWORD                       cExtension;
		public	IntPtr						rgExtension;
	};


	/*
	typedef struct _CRL_ENTRY 
			{
				CRYPT_INTEGER_BLOB  SerialNumber;
				FILETIME            RevocationDate;
				DWORD               cExtension;
				PCERT_EXTENSION     rgExtension;
			} CRL_ENTRY, *PCRL_ENTRY;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CRL_ENTRY
	{
		public CRYPT_INTEGER_BLOB  SerialNumber;
		public long		           RevocationDate;
		public DWORD               cExtension;
		public IntPtr			   rgExtension;
	}

	/*
	typedef struct _CMSG_SIGNER_INFO 
	{
		DWORD                       dwVersion;
		CERT_NAME_BLOB              Issuer;
		CRYPT_INTEGER_BLOB          SerialNumber;
		CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
		CRYPT_ALGORITHM_IDENTIFIER  HashEncryptionAlgorithm;
		CRYPT_DATA_BLOB             EncryptedHash;
		CRYPT_ATTRIBUTES            AuthAttrs;
		CRYPT_ATTRIBUTES            UnauthAttrs;
	} CMSG_SIGNER_INFO, *PCMSG_SIGNER_INFO;
	*/
	[StructLayout(LayoutKind.Sequential)] public struct CMSG_SIGNER_INFO_1
	{
		public DWORD                       dwVersion;
		public CERT_NAME_BLOB              Issuer;
		public CRYPT_INTEGER_BLOB          SerialNumber;
		public CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
		public CRYPT_ALGORITHM_IDENTIFIER  HashEncryptionAlgorithm;
		public CRYPT_DATA_BLOB             EncryptedHash;
		public CRYPT_ATTRIBUTES            AuthAttrs;
		public CRYPT_ATTRIBUTES            UnauthAttrs;
	}

	[StructLayout(LayoutKind.Sequential)] public struct CMSG_SIGNER_INFO_2
	{
		public DWORD						dwVersion;
		public CERT_NAME_BLOB				Issuer;
		public CRYPT_INTEGER_BLOB			SerialNumber;
		public CRYPT_ALGORITHM_IDENTIFIER_2 HashAlgorithm;
		public CRYPT_ALGORITHM_IDENTIFIER_2 HashEncryptionAlgorithm;
		public CRYPT_DATA_BLOB				EncryptedHash;
		public CRYPT_ATTRIBUTES				AuthAttrs;
		public CRYPT_ATTRIBUTES				UnauthAttrs;
	}



	[DllImport("CRYPT32.DLL", EntryPoint="CertCloseStore", CharSet=CharSet.Auto, SetLastError=true)]
	public static extern int CertCloseStore(IntPtr storeProvider, int flags);

	[DllImport("CRYPT32.DLL", EntryPoint="CertEnumCertificatesInStore", CharSet=CharSet.Auto, SetLastError=true)]
	public static extern IntPtr CertEnumCertificatesInStore( IntPtr storeProvider, IntPtr prevCertContext);

	/*
			PCCERT_CONTEXT WINAPI CertFindCertificateInStore(
			HCERTSTORE hCertStore,
			DWORD dwCertEncodingType,
			DWORD dwFindFlags,
			DWORD dwFindType,
			const void* pvFindPara,
			PCCERT_CONTEXT pPrevCertContext
			);
			*/
	[DllImport("crypt32.dll", CharSet=CharSet.Auto, SetLastError=true)]
	public static extern IntPtr CertFindCertificateInStore(
		IntPtr hCertStore,
		uint dwCertEncodingType, 
		uint dwFindFlags, 
		uint dwFindType,
		string pszFindPara, 
		IntPtr pPrevCertCntxt);



	[DllImport("crypt32.dll")]
	public static extern int CertFreeCertificateContext(IntPtr hCertStore);

	[DllImport("CRYPT32.DLL", EntryPoint="CertOpenStore", CharSet=CharSet.Auto, SetLastError=true)]
	public static extern IntPtr CertOpenStoreStringPara( int storeProvider, int encodingType,
		int hcryptProv, int flags, String pvPara);


	[DllImport("CRYPT32.DLL", EntryPoint="CertOpenStore", CharSet=CharSet.Auto, SetLastError=true)]
	public static extern IntPtr CertOpenStoreIntPtrPara( int storeProvider, int encodingType,
		int hcryptProv, int flags, IntPtr pvPara);

	[DllImport("crypt32.dll", CharSet=CharSet.Auto, SetLastError=true)]
	public static extern IntPtr CertOpenSystemStore(IntPtr hCryptProv, string storename);

	/*
			[DllImport("CRYPT32.DLL", EntryPoint="CertOpenStore", CharSet=CharSet.Auto, SetLastError=true)]
			public static extern IntPtr CertOpenStoreStringPara( int storeProvider, int encodingType,
				int hcryptProv, int flags, String pvPara);


			[DllImport("CRYPT32.DLL", EntryPoint="CertOpenStore", CharSet=CharSet.Auto, SetLastError=true)]
			public static extern IntPtr CertOpenStoreIntPtrPara( int storeProvider, int encodingType,
				int hcryptProv, int flags, IntPtr pvPara);
			*/

	
	/*
			BOOL CryptSignMessage(
				IN PCRYPT_SIGN_MESSAGE_PARA pSignPara,
				IN BOOL fDetachedSignature,
				IN DWORD cToBeSigned,
				IN const BYTE *rgpbToBeSigned[],
				IN DWORD rgcbToBeSigned[],
				OUT BYTE *pbSignedBlob,
				IN OUT DWORD *pcbSignedBlob
				);
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern int CryptSignMessage(
		ref CRYPT_SIGN_MESSAGE_PARA SignMessagePara,
		int fDetachedSignature,
		uint cToBeSigned,
		IntPtr rgpbToBeSigned,
		uint [] rgcbToBeSigned,
		IntPtr pbSignedBlob,
		ref uint pcbSignedBlob);


	/*
		BOOL CertGetCertificateContextProperty(
				IN PCCERT_CONTEXT pCertContext,
				IN DWORD dwPropId,
				OUT void *pvData,
				IN OUT DWORD *pcbData
			  );
		*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern int CertGetCertificateContextProperty(
		IntPtr   pCertContext,
		uint     dwPropId,
		IntPtr   pvData,
		ref uint pcbData
		);

	/*
			[DllImport("crypt32.dll", SetLastError=true)]
			public static extern int CertGetCertificateContextProperty(
				IntPtr pCertContext,
				uint dwPropId,
				ref  CRYPT_KEY_PROV_INFO pvData,
				ref uint pcbData
				);
			*/

	/*
		BOOL  CryptAcquireContext(
			HCRYPTPROV* phProv,
			LPCTSTR pszContainer,
			LPCTSTR pszProvider,
			DWORD dwProvType,
			DWORD dwFlags
			);
	*/
	[DllImport("advapi32.dll", SetLastError=true)]
	public static extern int CryptAcquireContext(
		IntPtr phProv,
		string pszContainer,
		string pszProvider,
		uint dwProvType,
		uint dwFlags
		);

	/*
		BOOL WINAPI CryptGetUserKey(
			HCRYPTPROV hProv,
			DWORD dwKeySpec,
			HCRYPTKEY* phUserKey
			);
	*/
	[DllImport("advapi32.dll", SetLastError=true)]
	public static extern int CryptGetUserKey(
		IntPtr     hProv,
		uint       dwKeySpec,
		IntPtr     phUserKey
		);

	/*
			BOOL WINAPI CryptDestroyKey(
							HCRYPTKEY hKey
							);
			*/
	[DllImport("advapi32.dll", SetLastError=true)]
	public static extern int CryptDestroyKey(
		IntPtr     hProv
		);


	/*
			BOOL
				CryptSetProvParam(
					HCRYPTPROV hProv,
					DWORD dwParam,
					CONST BYTE *pbData,
					DWORD dwFlags
				);
			*/
	[DllImport("advapi32.dll", SetLastError=true)]
	public static extern int CryptSetProvParam(
		IntPtr hProv,
		uint dwParam,
		byte [] pbData,
		uint dwFlags
		);


	/*
				BOOL WINAPI CryptReleaseContext( 
				HCRYPTPROV hProv,
				DWORD dwFlags
				); 
			*/
	[DllImport("advapi32.dll", SetLastError=true)]
	public static extern int CryptReleaseContext(
		IntPtr hProv,
		uint dwFlags
		);


	/*
			BOOL WINAPI CertGetIntendedKeyUsage(
			DWORD dwCertEncodingType,
			PCERT_INFO pCertInfo,
			BYTE* pbKeyUsage,
			DWORD cbKeyUsage
			);
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern int CertGetIntendedKeyUsage(
		uint dwCertEncodingType,
		IntPtr pCertInfo,
		out ushort pbKeyUsage,
		uint cbKeyUsage // sempre 2 = sizeof(ushort)
		);



	/*
		DWORD
		CertGetNameStringW(
		IN PCCERT_CONTEXT pCertContext,
		IN DWORD dwType,
		IN DWORD dwFlags,
		IN void *pvTypePara,
		OUT OPTIONAL LPWSTR pszNameString,
		IN DWORD cchNameString
		);
	*/
	[DllImport("CRYPT32.DLL", EntryPoint="CertGetNameStringA")]
	public static extern int CertGetNameStringA(
		IntPtr pCertContext,
		uint dwType,
		uint dwFlags,
		IntPtr pvTypePara,
		IntPtr pszNameString,
		uint cchNameString
		);


	/*
	HCRYPTMSG
	CryptMsgOpenToDecode(
		IN DWORD dwMsgEncodingType,
		IN DWORD dwFlags,
		IN DWORD dwMsgType,
		IN HCRYPTPROV hCryptProv,
		IN OPTIONAL PCERT_INFO pRecipientInfo,
		IN OPTIONAL PCMSG_STREAM_INFO pStreamInfo
		);
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern HCRYPTMSG CryptMsgOpenToDecode(
		DWORD dwMsgEncodingType,
		DWORD dwFlags,
		DWORD dwMsgType,
		IntPtr hCryptProv,
		IntPtr pRecipientInfo,
		IntPtr pStreamInfo
	);

	/*
	BOOL
	CryptMsgUpdate(
		IN HCRYPTMSG hCryptMsg,
		IN const BYTE *pbData,
		IN DWORD cbData,
		IN BOOL fFinal
		);
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern BOOL CryptMsgUpdate(
		HCRYPTMSG hCryptMsg,
		byte [] pbData,
		DWORD cbData,
		BOOL fFinal
		);

	/*
		BOOL
		CryptMsgClose(IN HCRYPTMSG hCryptMsg);
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern BOOL CryptMsgClose(HCRYPTMSG hCryptMsg);

	/*
	BOOL
	CryptMsgGetParam(
		IN HCRYPTMSG hCryptMsg,
		IN DWORD dwParamType,
		IN DWORD dwIndex,
		OUT void *pvData,
		IN OUT DWORD *pcbData
		);
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern BOOL CryptMsgGetParam(
		HCRYPTMSG hCryptMsg,
		DWORD dwParamType,
		DWORD dwIndex,
		IntPtr pvData,
		out DWORD pcbData
		);


	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern BOOL CryptMsgGetParam(
		HCRYPTMSG hCryptMsg,
		DWORD dwParamType,
		DWORD dwIndex,
		out byte [] pvData,
		out DWORD pcbData
		);


	/*
	PCCERT_CONTEXT
	CertCreateCertificateContext(
		IN DWORD dwCertEncodingType,
		IN const BYTE *pbCertEncoded,
		IN DWORD cbCertEncoded
		);
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern PCCERT_CONTEXT CertCreateCertificateContext(
		DWORD dwCertEncodingType,
		byte [] pbCertEncoded,
		DWORD cbCertEncoded
	);


	/*
		BOOL CryptVerifyMessageSignature(
			IN PCRYPT_VERIFY_MESSAGE_PARA pVerifyPara,
			IN DWORD dwSignerIndex,
			IN const BYTE *pbSignedBlob,
			IN DWORD cbSignedBlob,
			OUT BYTE OPTIONAL *pbDecoded,
			IN OUT OPTIONAL DWORD *pcbDecoded,
			OUT OPTIONAL PCCERT_CONTEXT *ppSignerCert
		 );
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern BOOL CryptVerifyMessageSignature(
				ref CRYPT_VERIFY_MESSAGE_PARA pVerifyPara,
				DWORD dwSignerIndex,
				byte [] pbSignedBlob,
				DWORD cbSignedBlob,
				IntPtr pbDecoded,
				ref DWORD pcbDecoded,
				out IntPtr ppSignerCert
	);


   /*
		BOOL CertGetCertificateChain (
			IN OPTIONAL HCERTCHAINENGINE hChainEngine,
			IN PCCERT_CONTEXT pCertContext,
			IN OPTIONAL LPFILETIME pTime,
			IN OPTIONAL HCERTSTORE hAdditionalStore,
			IN PCERT_CHAIN_PARA pChainPara,
			IN DWORD dwFlags,
			IN LPVOID pvReserved,
			OUT PCCERT_CHAIN_CONTEXT* ppChainContext
	     );
    */
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern BOOL CertGetCertificateChain (
		   	uint hChainEngine,
			IntPtr pCertContext,
		    IntPtr pTime,
		    IntPtr hAdditionalStore,
		    ref CERT_CHAIN_PARA pChainPara,
		    DWORD dwFlags,
			IntPtr pvReserved,
		    out IntPtr ppChainContext
		);


	/*
	VOID CertFreeCertificateChain (
			IN PCCERT_CHAIN_CONTEXT pChainContext
		);
	*/
	[DllImport("crypt32.dll", SetLastError=true)]
	public static extern void CertFreeCertificateChain (
			IntPtr pChainContext
		);

	/*
	BOOL CryptEncodeObject(
			IN DWORD        dwCertEncodingType,
			IN LPCSTR       lpszStructType,    // in alcuni casi e' vista come uint
			IN const void   *pvStructInfo,
			OUT BYTE        *pbEncoded,
			IN OUT DWORD    *pcbEncoded
		);
	*/
	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL CryptEncodeObject(
		 DWORD  dwCertEncodingType,
		 string lpszStructType,
		 IntPtr	pvStructInfo,
		 IntPtr       pbEncoded,
		 ref DWORD    pcbEncoded
		 );

	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL CryptEncodeObject(
		DWORD  dwCertEncodingType,
		uint	lpszStructType,
		IntPtr		pvStructInfo,
		IntPtr       pbEncoded,
		ref DWORD    pcbEncoded
		);

	//
	// Specifica per encode di un oggetto di tipo long (FILETIME)
	//
	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL CryptEncodeObject(
		DWORD		  dwCertEncodingType,
		string		  lpszStructType,
		ref long	  pvStructInfo,
		IntPtr        pbEncoded,
		ref DWORD	  pcbEncoded
		);


	/*
	BOOL CryptDecodeObject(
			IN DWORD        dwCertEncodingType,
			IN LPCSTR       lpszStructType,
			IN const BYTE   *pbEncoded,
			IN DWORD        cbEncoded,
			IN DWORD        dwFlags,
			OUT void        *pvStructInfo,
			IN OUT DWORD	*pcbStructInfo
							   );    
	*/
	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL  CryptDecodeObject(
		DWORD        dwCertEncodingType,
		string		 lpszStructType,
		byte []		 pbEncoded,
		DWORD        cbEncoded,
		DWORD        dwFlags,
		IntPtr		 pvStructInfo,
		ref DWORD	 cbStructInfo
		);    

	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL  CryptDecodeObject(
		DWORD        dwCertEncodingType,
		uint		 lpszStructType,
		byte []		 pbEncoded,
		DWORD        cbEncoded,
		DWORD        dwFlags,
		IntPtr		 pvStructInfo,
		ref DWORD	 cbStructInfo
		);    


	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL  CryptDecodeObject(
		DWORD        dwCertEncodingType,
		string		 lpszStructType,
		IntPtr		 pbEncoded,
		DWORD        cbEncoded,
		DWORD        dwFlags,
		IntPtr		 pvStructInfo,
		ref DWORD	 cbStructInfo
		);    

	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL  CryptDecodeObject(
		DWORD        dwCertEncodingType,
		uint		 lpszStructType,
		IntPtr		 pbEncoded,
		DWORD        cbEncoded,
		DWORD        dwFlags,
		IntPtr		 pvStructInfo,
		ref DWORD	 cbStructInfo
		);    

	//
	// Specifica per Decode di un oggetto di tipo long (FILETIME)
	//
	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL  CryptDecodeObject(
		DWORD        dwCertEncodingType,
		string		 lpszStructType,
		byte []		 pbEncoded,
		DWORD        cbEncoded,
		DWORD        dwFlags,
		out long pvStructInfo,
		ref DWORD	 cbStructInfo
		);    
	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL  CryptDecodeObject(
		DWORD        dwCertEncodingType,
		string		 lpszStructType,
		IntPtr		 pbEncoded,
		DWORD        cbEncoded,
		DWORD        dwFlags,
		out long pvStructInfo,
		ref DWORD	 cbStructInfo
		);    

	//
	// Specifica per Decode di un oggetto di tipo int (CRL Extension enumeration values)
	//
	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL  CryptDecodeObject(
		DWORD        dwCertEncodingType,
		string		 lpszStructType,
		byte []		 pbEncoded,
		DWORD        cbEncoded,
		DWORD        dwFlags,
		out int		 pvStructInfo,
		ref DWORD	 cbStructInfo
		);    
	[DllImport("crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL  CryptDecodeObject(
		DWORD        dwCertEncodingType,
		string		 lpszStructType,
		IntPtr		 pbEncoded,
		DWORD        cbEncoded,
		DWORD        dwFlags,
		out int		 pvStructInfo,
		ref DWORD	 cbStructInfo
		);    


	/*
	BOOL
		WINAPI
		CryptGenKey(
			HCRYPTPROV hProv,
			ALG_ID Algid,
			DWORD dwFlags,
			HCRYPTKEY *phKey
			);
	*/
	[DllImport("advapi32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern BOOL CryptGenKey(
		IntPtr hProv,
		ALG_ID Algid,
		DWORD dwFlags,
		IntPtr   phUserKey
	);


	/*
	 *  Funzioni per CRL
	 * 
	 */

	/*
	BOOL CryptGetObjectUrl (
			IN LPCSTR pszUrlOid,
			IN LPVOID pvPara,
			IN DWORD dwFlags,
			OUT OPTIONAL PCRYPT_URL_ARRAY pUrlArray,
			IN OUT DWORD* pcbUrlArray,
			OUT OPTIONAL PCRYPT_URL_INFO pUrlInfo,
			IN OUT OPTIONAL DWORD* pcbUrlInfo,
			IN OPTIONAL LPVOID pvReserved
		);
	*/
	[DllImport("Cryptnet.dll", CharSet = CharSet.Unicode, SetLastError=true)]
	public static extern BOOL CryptGetObjectUrl(
				uint pszUrlOid,				// in realta' viene usato come uint 
				IntPtr pvPara,
				DWORD dwFlags,
				IntPtr pUrlArray,
				ref DWORD pcbUrlArray,
				IntPtr pUrlInfo,
				IntPtr pcbUrlInfo,
				IntPtr pvReserved
		);


	/*
	BOOL CryptRetrieveObjectByUrlW (
			IN LPCWSTR pszUrl,
			IN LPCSTR pszObjectOid,					// usato come uint in realta' 
			IN DWORD dwRetrievalFlags,
			IN DWORD dwTimeout,                     // milliseconds
			OUT LPVOID* ppvObject,
			IN HCRYPTASYNC hAsyncRetrieve,
			IN OPTIONAL PCRYPT_CREDENTIALS pCredentials,
			IN OPTIONAL LPVOID pvVerify,
			IN OPTIONAL PCRYPT_RETRIEVE_AUX_INFO pAuxInfo
		);
	*/
	[DllImport("Cryptnet.dll", CharSet = CharSet.Unicode, SetLastError=true)]
	public static extern BOOL CryptRetrieveObjectByUrlW (
			string pszUrl,
			uint pszObjectOid,
			DWORD dwRetrievalFlags,
			DWORD dwTimeout,						// milliseconds
			IntPtr ppvObject,
			IntPtr hAsyncRetrieve,
			IntPtr pCredentials,
			IntPtr pvVerify,
			IntPtr pAuxInfo
		);

	//
	// BOOL CertFreeCRLContext(IN PCCRL_CONTEXT pCrlContext);
	//
	[DllImport("Crypt32.dll", SetLastError=true)]
	public static extern BOOL CertFreeCRLContext(
			IntPtr pCrlContext
		);


	/*
	BOOL WINAPI CertSerializeCRLStoreElement(
					PCCRL_CONTEXT pCrlContext,
					DWORD dwFlags,
					BYTE* pbElement,
					DWORD* pcbElement
					);
	*/
	[DllImport("Crypt32.dll", SetLastError=true)]
	public static extern BOOL CertSerializeCRLStoreElement(
			IntPtr pCrlContext,
			DWORD dwFlags,
			IntPtr pbElement,
			ref DWORD cbElement
		);

	/*
	PCCRL_CONTEXT WINAPI CertCreateCRLContext(
					 DWORD dwCertEncodingType,
					 const BYTE* pbCrlEncoded,
					 DWORD cbCrlEncoded
				 );
	*/
	[DllImport("Crypt32.dll", SetLastError=true)]
	public static extern IntPtr CertCreateCRLContext(
				DWORD dwCertEncodingType,
				byte [] pbCrlEncoded,
				DWORD cbCrlEncoded
		);


	/*
	DWORD WINAPI CertNameToStr(
					 DWORD dwCertEncodingType,
					 PCERT_NAME_BLOB pName,
					 DWORD dwStrType,
					 LPTSTR psz,
					 DWORD csz
					 );
	*/
	[DllImport("Crypt32.dll", CharSet = CharSet.Ansi, SetLastError=true)]
	public static extern DWORD CertNameToStrA(
				DWORD dwCertEncodingType,
				IntPtr pName,
				DWORD dwStrType,
				IntPtr psz,
				DWORD csz
				);
	
	/*
	BOOL WINAPI CryptVerifyCertificateSignatureEx(
					HCRYPTPROV hCryptProv,
					DWORD dwCertEncodingType,
					DWORD dwSubjectType,
					void* pvSubject,
					DWORD dwIssuerType,
					void* pvIssuer,
					DWORD dwFlags,
					void* pvReserved
					);
	*/
	[DllImport("Crypt32.dll", SetLastError=true)]
	public static extern bool CryptVerifyCertificateSignatureEx(
					IntPtr	hCryptProv,
					DWORD	dwCertEncodingType,
					DWORD	dwSubjectType,
					IntPtr	pvSubject,
					DWORD	dwIssuerType,
					IntPtr	pvIssuer,
					DWORD	dwFlags,
					IntPtr	pvReserved
				);


}
