using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Text;
using System.ComponentModel;

namespace CertPInvokeLib
{
	public class CertException : Exception 
	{
		public CertException(string msg):base(msg)
		{
			//Msg = msg;
			Win32Error = Marshal.GetLastWin32Error();
			Win32Msg = GetWin32Message(Win32Error);
		}
		public CertException(string msg, int dwError):base(msg)
		{
			//Msg = msg;
			Win32Error = dwError;
			Win32Msg = GetWin32Message(Win32Error);
		}
		private string GetWin32Message(int dwError)
		{
			Win32Exception myEx=new Win32Exception(dwError);
			return myEx.Message;

		}

		//readonly public string Msg;
		readonly public int    Win32Error;
		readonly public string Win32Msg;
	}


	public class CertStore : IDisposable, IEnumerable
	{
		public void OpenUserStore()
		{
			_h = WinCapi.CertOpenStoreStringPara(
				WinCapi.CERT_STORE_PROV_SYSTEM,
				0,
				0,
				WinCapi.CERT_SYSTEM_STORE_CURRENT_USER,
				WinCapi.MY);
			if (_h == IntPtr.Zero)
				throw new CertException("CertOpenStoreStringPara");
		}

		public void OpenLocalMachineStore()
		{
			_h = WinCapi.CertOpenStoreStringPara(
				WinCapi.CERT_STORE_PROV_SYSTEM,
				0,
				0,
				WinCapi.CERT_SYSTEM_STORE_LOCAL_MACHINE,
				WinCapi.MY);
			if (_h == IntPtr.Zero)
				throw new CertException("CertOpenStoreStringPara");
		}

		public int CountCertificatesInStore()
		{
			int certIndex;
			IntPtr pCertContext = IntPtr.Zero;
			for (certIndex=0; ; certIndex++)
			{
				pCertContext = WinCapi.CertEnumCertificatesInStore(_h, pCertContext);
				if (pCertContext == IntPtr.Zero)
				{
					break;
				}
			}
			return certIndex;
		}

		public CertX509Ex CertGetCertificateInStoreById(int index)
		{
			int certIndex;
			CertX509Ex c = null;

			IntPtr pCertContext = IntPtr.Zero;
			for (certIndex=0; certIndex<=index; certIndex++)
			{
				pCertContext = WinCapi.CertEnumCertificatesInStore(_h, pCertContext);
				if (pCertContext == IntPtr.Zero)
				{
					break;
				}
			}
			if (pCertContext != IntPtr.Zero)
			{
				c = new CertX509Ex(pCertContext);
				WinCapi.CertFreeCertificateContext(pCertContext);
			}
			return c;
		}

		public CertX509Ex CertGetCertificateInStoreByIssuerSerialNumber(string Issuer,
																		string SerialNumberString)
		{
			int certIndex;
			CertX509Ex c = null;

			IntPtr pCertContext = IntPtr.Zero;
			
			for (certIndex=0; ; certIndex++)
			{
				pCertContext = WinCapi.CertEnumCertificatesInStore(_h, pCertContext);
				if (pCertContext == IntPtr.Zero)
				{
					break;
				}
				try
				{
					c = new CertX509Ex(pCertContext);
					if ((c.GetIssuerName() == Issuer) && (c.GetSerialNumberString() == SerialNumberString))
					{
						break;
					}
				}
				catch
				{
				}
			}
			if (pCertContext != IntPtr.Zero)
			{
				WinCapi.CertFreeCertificateContext(pCertContext);
				return c;
			}
			return null;
		}


		public CertX509Ex CertFindCertificateInStore(string certSubject)
		{
			IntPtr pCertContext = WinCapi.CertFindCertificateInStore(
				_h,
				WinCapi.MY_ENCODING_TYPE,
				0, 
				WinCapi.CERT_FIND_SUBJECT_STR_W,
				certSubject,
				IntPtr.Zero);
			if (pCertContext == IntPtr.Zero)
				throw new CertException("CertFindCertificateInStore");

			CertX509Ex cert = null;
		
			try
			{
				cert = new CertX509Ex(pCertContext);
			}
			catch 
			{
				WinCapi.CertFreeCertificateContext(pCertContext);
				throw;
			}

			//
			//
			WinCapi.CertFreeCertificateContext(pCertContext);
			return cert;
		}

		public void Close()
		{
			if (_h != IntPtr.Zero)
			{
				int r = WinCapi.CertCloseStore(_h, 0) ;
				if (r == 0)
					new CertException("CertCloseStore");
				_h = IntPtr.Zero;
			}
		}


		private ArrayList EnumCertificatesInStore()
		{
			ArrayList r = new ArrayList();

			IntPtr pCertContext = IntPtr.Zero;
			for (;;)
			{
				pCertContext = WinCapi.CertEnumCertificatesInStore(_h, pCertContext);
				if (pCertContext == IntPtr.Zero)
					break;

				CertX509Ex c = new CertX509Ex(pCertContext);

				r.Add(c);
			}
			return r;
		}
	

		private IntPtr _h;

		#region IDisposable Members

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}
		~CertStore()
		{
			Dispose(false);
		}

		bool disposed = false;
		private void Dispose(bool disposing)
		{
			if (!disposed)
			{
				if (disposing)
				{
					// managed resources
				}
				Close();
			}
			disposed = true;
		}
		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return new CertificateEnumerator(this.EnumCertificatesInStore());
		}

		public CertificateEnumerator GetEnumerator() 
		{
			return new CertificateEnumerator(this.EnumCertificatesInStore());
		}

		public class CertificateEnumerator : IEnumerator
		{
			public CertificateEnumerator(ArrayList r)
			{
				_r = r;
				_nIndex = -1;
			}

			ArrayList _r;
			int _nIndex;

			#region IEnumerator Members

			public void Reset()
			{
				_nIndex = -1;
			}

			object IEnumerator.Current
			{
				get { return _r[_nIndex]; }
			}
			
			public bool MoveNext()
			{
				_nIndex++;
				return _nIndex < _r.Count;
			}

			#endregion
		}


		#endregion
	}


	public class CertX509Ex : X509Certificate
	{
		//
		// membro riportato da X509Certificate
		//
		private byte[] rawCertData;

		//
		// membri calcolati ex-novo da pCertContext
		// dal costruttore
		//
		private Int64 effectiveDate;
		private Int64 expirationDate;
		private bool keyUsageSupported;
		private ushort keyUsage;
		private uint certCurrentUserErrorStatus;
		private uint certCurrentUserInfoStatus;
		private uint certLocalMachineErrorStatus;
		private uint certLocalMachineInfoStatus;
		private string [] distributionPointList;
		private string szContainerName;
		private string szProvName;
		private string certName;

		internal void InternalSet(IntPtr pCertContext)
		{
			rawCertData = base.GetRawCertData(); 
			effectiveDate = 0;
			try
			{
				effectiveDate = loadEffectiveDate(pCertContext);
			}
			catch
			{
				effectiveDate = 0;
			}

			expirationDate = 0;
			try
			{
				expirationDate = loadExpirationDate(pCertContext);
			}
			catch
			{
				expirationDate = 0;
			}


			keyUsageSupported = false;
			keyUsage = 0;
			try
			{
				GetKeyUsage(pCertContext, out keyUsageSupported, out keyUsage);
			}
			catch
			{
				keyUsageSupported = false;
				keyUsage = 0;
			}

			certCurrentUserErrorStatus = 0;
			certCurrentUserInfoStatus = 0;
			try
			{
				GetChainStatus(pCertContext, false, out certCurrentUserErrorStatus, out certCurrentUserInfoStatus);
			}
			catch
			{
				certCurrentUserErrorStatus = 0;
				certCurrentUserInfoStatus = 0;
			}

			certLocalMachineErrorStatus = 0;
			certLocalMachineInfoStatus = 0;
			try
			{
				GetChainStatus(pCertContext, true, out certLocalMachineErrorStatus, out certLocalMachineInfoStatus);
			}
			catch
			{
				certLocalMachineErrorStatus = 0;
				certLocalMachineInfoStatus = 0;
			}

			distributionPointList = null;
			try
			{
				distributionPointList = GetDistributionPointList(pCertContext);
			}
			catch
			{
				distributionPointList = null;
			}

			szContainerName = "";
			szProvName = "";
			try
			{
				GetContextProperty(pCertContext, out szContainerName, out szProvName);
			}
			catch
			{
				szContainerName = "";
				szProvName = "";
			}


			try
			{
				certName = CertGetNameString(pCertContext);
			}
			catch
			{
			}

		}

		/// <summary>
		///    CreateFromCertFile(): copertura dell'analogo metodo di X509Certificate
		/// </summary>
		/// <param name="filename"></param>
		/// <returns></returns>
		public static new CertX509Ex CreateFromCertFile(string filename)
		{
			CertX509Ex xcEx = null;
			X509Certificate xc = X509Certificate.CreateFromCertFile(filename);
			if (xc != null)
			{
				byte [] rawCertData = xc.GetRawCertData();
				xcEx = new CertX509Ex(rawCertData);
			}
			return xcEx;
		}

		/// <summary>
		///		CreateFromSignedFile: copertura dell'analogo metodo di X509Certificate
		/// </summary>
		/// <param name="filename"></param>
		/// <returns></returns>
		public static new CertX509Ex CreateFromSignedFile(string filename)
		{
			CertX509Ex xcEx = null;
			X509Certificate xc = X509Certificate.CreateFromSignedFile(filename);
			if (xc != null)
			{
				byte [] rawCertData = xc.GetRawCertData();
				xcEx = new CertX509Ex(rawCertData);
			}
			return xcEx;
		}

		public string GetContainerName()
		{
			return szContainerName;
		}

		public string GetProviderName()
		{
			return szProvName;
		}



		internal CertX509Ex(IntPtr pCertContext)
			: base(pCertContext)
		{
			InternalSet(pCertContext);
		}

		internal CertX509Ex(byte [] c)
			: base(c)
		{
			IntPtr pCertContext = WinCapi.CertCreateCertificateContext(WinCapi.MY_ENCODING_TYPE, c, (uint)c.Length);
			if (pCertContext == IntPtr.Zero)
				throw new CertException("CertCreateCertificateContext");

			InternalSet(pCertContext);
			Close(ref pCertContext);
		}

		internal void Close(ref IntPtr pCertContext)
		{
			int r;
			if (pCertContext != IntPtr.Zero)
			{
				r = WinCapi.CertFreeCertificateContext(pCertContext);
				if (r == 0)
					throw new CertException("CertFreeCertificateContext");
				pCertContext = IntPtr.Zero;
			}
		}

		internal string CertGetNameString(IntPtr pCertContext)
		{
			string CN = "";
			unsafe
			{
				int cbNameLen = WinCapi.CertGetNameStringA(pCertContext, WinCapi.CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, IntPtr.Zero, IntPtr.Zero, 0);
				if (cbNameLen == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CertFreeCertificateContext(pCertContext);
					throw new CertException("CertGetNameStringA", dwError);
				}

				byte *pp = stackalloc byte[cbNameLen + 1];
				cbNameLen = WinCapi.CertGetNameStringA(pCertContext, WinCapi.CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, IntPtr.Zero, new IntPtr(pp), (uint)cbNameLen+1);
				if (cbNameLen == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CertFreeCertificateContext(pCertContext);
					throw new CertException("CertGetNameStringA", dwError);
				}

				CN = Marshal.PtrToStringAnsi(new IntPtr(pp));
			}
			return CN;
		}

		internal Int64 loadEffectiveDate(IntPtr pCertContext)
		{
			unsafe
			{
				WinCapi.CERT_CONTEXT *p = (WinCapi.CERT_CONTEXT *)pCertContext.ToPointer();
				WinCapi.CERT_INFO *ci = (WinCapi.CERT_INFO *)p->pCertInfo.ToPointer();

				Int64 ft = ((Int64) ci->NotBefore.dwLowDateTime) | (((Int64)ci->NotBefore.dwHighDateTime) << 32);
				return ft;
			}
		}

		internal Int64 loadExpirationDate(IntPtr pCertContext)
		{
			unsafe
			{
				WinCapi.CERT_CONTEXT *p = (WinCapi.CERT_CONTEXT *)pCertContext.ToPointer();

				WinCapi.CERT_INFO *ci = (WinCapi.CERT_INFO *)p->pCertInfo.ToPointer();

				Int64 ft = ((Int64) ci->NotAfter.dwLowDateTime) | (((Int64)ci->NotAfter.dwHighDateTime) << 32);
				return ft;
			}
		}

		internal void GetKeyUsage(IntPtr pCertContext, out bool keyUsageSupported, out ushort keyUsage)
		{
			unsafe
			{
				WinCapi.CERT_CONTEXT *pcc = (WinCapi.CERT_CONTEXT *) pCertContext.ToPointer();

				keyUsage = 0;
				keyUsageSupported = true;

				int r = WinCapi.CertGetIntendedKeyUsage(WinCapi.PKCS_7_ASN_ENCODING | WinCapi.X509_ASN_ENCODING, pcc->pCertInfo, out keyUsage, sizeof(ushort));
				if (r == 0 && Marshal.GetLastWin32Error() != 0)
				{
					// errore di tipo generale ( GetLastWin32Error() != 0 )
					keyUsageSupported = false;
				}
				if (r == 0)
				{
					// qui indica che il keyUsage non e` supportato
					// ma non e` un errore.
							
					// KeyUsage non supportato.
					keyUsageSupported = false;
				}
			}
		}

		public DateTime ExpirationDate
		{
			get
			{
				return DateTime.FromFileTime((long)expirationDate);
			}
		}
		public DateTime EffectiveDate
		{
			get
			{
				return DateTime.FromFileTime((long)effectiveDate);
			}
		}
		public DateTime GetEffectiveDate()
		{
			return DateTime.FromFileTime((long)effectiveDate);
		}

		public DateTime GetExpirationDate()
		{
			return DateTime.FromFileTime((long)expirationDate);
		}

		

		/// <summary>
		/// Ritorna true se il certificato supporta la CERT_NON_REPUDIATION_KEY_USAGE
		/// (firma digitale)
		/// </summary>
		public bool IsKeyUsageSupported
		{
			get 
			{ 
				return keyUsageSupported; 
			}
		}

		public bool IsNonRepudiationCertificate
		{
			get 
			{
				// da colloqui con Nicolo` abbiamo desunto che se il certificato
				// non supporta il KeyUsage
				// noi desumiamo che il certificato possa fare il non ripudio
				//Debug.Assert(_keyUsageSupported);
				if (!keyUsageSupported) return true;
				return (keyUsage & WinCapi.CERT_NON_REPUDIATION_KEY_USAGE) != 0; 
			}
		}

		/// <summary>
		/// Ritorna true se il certificato supporta la CERT_DIGITAL_SIGNATURE_KEY_USAGE
		/// (autenticazione)
		/// </summary>
		public bool IsDigitaleSignatureCertificate
		{
			get 
			{
				// da colloqui con Nicolo` abbiamo desunto che se il certificato
				// non supporta il KeyUsage
				// noi desumiamo che il certificato possa fare l'autenticazione
				//Debug.Assert(_keyUsageSupported);
				if (!keyUsageSupported) return true;
				return (keyUsage & WinCapi.CERT_DIGITAL_SIGNATURE_KEY_USAGE) != 0; 
			}
		}

		internal void GetChainStatus(IntPtr pCertContext, bool bLocalMachine, out uint CertErrorStatus, out uint CertInfoStatus)
		{
			unsafe
			{
				WinCapi.CERT_CHAIN_CONTEXT		ChainContext = new WinCapi.CERT_CHAIN_CONTEXT();

				IntPtr							hChainContext = IntPtr.Zero;
				WinCapi.CERT_CHAIN_PARA         ChainPara = new WinCapi.CERT_CHAIN_PARA();
				WinCapi.CERT_ENHKEY_USAGE       EnhkeyUsage = new WinCapi.CERT_ENHKEY_USAGE();
				WinCapi.CERT_USAGE_MATCH        CertUsage = new WinCapi.CERT_USAGE_MATCH();
				
				EnhkeyUsage.cUsageIdentifier = 0;
				EnhkeyUsage.rgpszUsageIdentifier= IntPtr.Zero;
				CertUsage.dwType = WinCapi.USAGE_MATCH_TYPE_AND;        // AND logic
				CertUsage.Usage  = EnhkeyUsage;
				ChainPara.cbSize = (uint) sizeof(WinCapi.CERT_CHAIN_PARA);
				ChainPara.RequestedUsage=CertUsage; 
				bool bResult = false;
				uint hChainEngine;

				//
				// usa catena di trust su Current User o Local Machine
				//
				if (bLocalMachine)
					hChainEngine = WinCapi.HCCE_LOCAL_MACHINE;
				else
					hChainEngine = WinCapi.HCCE_CURRENT_USER;
			

				// builds a certificate chain context starting from an end certificate and going back
				bResult = WinCapi.CertGetCertificateChain(
					hChainEngine,    // Use the Local Machine chain engine.
					pCertContext,	 // Pointer to the end certificate.
					IntPtr.Zero,     // Use the default time.
					IntPtr.Zero,     // Search no additional stores.
					ref ChainPara,   // Use AND logic, and enhanced key usage
					0,
					IntPtr.Zero,             // Currently reserved.
					out hChainContext);       // Return a pointer to the chain created.

				if(bResult == false)
					throw new CertException("CertX509Ex.GetCertificateChain Error");
		

				WinCapi.CERT_CHAIN_CONTEXT	*pChainContext = (WinCapi.CERT_CHAIN_CONTEXT	*) hChainContext.ToPointer();
				CertErrorStatus = pChainContext->TrustStatus.dwErrorStatus;
				CertInfoStatus =  pChainContext->TrustStatus.dwInfoStatus;

				//
				//
				WinCapi.CertFreeCertificateChain(hChainContext);
			}
		}


		public string [] GetDistributionPointList()
		{
			return distributionPointList;
		}


		//
		// Dal certificato ottiene la lista degli indirizzi (URL HTTP o LDAP) (Certificate Distribution Points)
		// da cui scaricare le CRL
		//
		internal string [] GetDistributionPointList(IntPtr pCertContext)
		{
			uint     dwFlags, cbUrlArray;    
			bool     r;
			string [] szDistributionPoints = null;
			
			unsafe 
			{
				cbUrlArray = 0;
				dwFlags = WinCapi.CRYPT_GET_URL_FROM_PROPERTY | WinCapi.CRYPT_GET_URL_FROM_EXTENSION;    
				r = WinCapi.CryptGetObjectUrl(WinCapi.URL_OID_CERTIFICATE_CRL_DIST_POINT, 
					pCertContext, 
					dwFlags, 
					IntPtr.Zero, 
					ref cbUrlArray, 
					IntPtr.Zero,
					IntPtr.Zero, 
					IntPtr.Zero);    
				if (r == false)
				{

					//
					// in caso di certificati senza CDP ritorna stringa nulla
					//
					uint dwLastError = (uint) Marshal.GetLastWin32Error();
					if (dwLastError == WinCapi.HERROR_OBJECT_NOT_PRESENT)
					{
						return szDistributionPoints;
					}
					else
						throw new CertException("CertX509Ex.GetDistributionPointList error getting Distribution Point dimension", (int)dwLastError);
				}

				byte *p = stackalloc byte[(int)cbUrlArray];

				r = WinCapi.CryptGetObjectUrl(WinCapi.URL_OID_CERTIFICATE_CRL_DIST_POINT, 
					pCertContext, 
					dwFlags, 
					new IntPtr(p), 
					ref cbUrlArray, 
					IntPtr.Zero,
					IntPtr.Zero, 
					IntPtr.Zero);   
				if (r == false)
				{
					throw new CertException("CertX509Ex.GetDistributionPointList error getting Distribution Point byte");
				}
			
				WinCapi.CRYPT_URL_ARRAY *urlArr = (WinCapi.CRYPT_URL_ARRAY *)p;

				uint nDistrPoints = urlArr->cUrl;
				szDistributionPoints = new string[nDistrPoints];
				void *current;
			    
				//
				// Questa aritmetica dei puntatori e' per ottenere le stringhe dall'array ...
				// urlArr->rgwszUrl e' un array di stringhe unicode 
				//
				for (int i=0; i< nDistrPoints; i++)
				{
					void *currArrPtr = (void *)((int)(urlArr->rgwszUrl).ToPointer() + i * sizeof(uint));
					current = (void *)Marshal.ReadIntPtr( new IntPtr(currArrPtr)).ToPointer() ;
					IntPtr ptrCurrent = new IntPtr(current);
					szDistributionPoints[i] = Marshal.PtrToStringUni(ptrCurrent);
				}
			}
			return szDistributionPoints;
		}

		internal void GetContextProperty(IntPtr pCertContext, out string pwszContainerName, out string pwszProvName)
		{
			unsafe
			{
				uint keyProvInfoLen = 0;
				int r = WinCapi.CertGetCertificateContextProperty(pCertContext, WinCapi.CERT_KEY_PROV_INFO_PROP_ID, IntPtr.Zero, ref keyProvInfoLen);
				if (r == 0)
					throw new CertException("CertGetCertificateContextProperty");

				byte *p = stackalloc byte[(int)keyProvInfoLen];
				r = WinCapi.CertGetCertificateContextProperty(pCertContext, WinCapi.CERT_KEY_PROV_INFO_PROP_ID, new IntPtr(p), ref keyProvInfoLen);
				if (r == 0)
					throw new CertException("CertGetCertificateContextProperty");

				WinCapi.CRYPT_KEY_PROV_INFO *ki = (WinCapi.CRYPT_KEY_PROV_INFO *) p;

				pwszContainerName = Marshal.PtrToStringUni(ki->pwszContainerName);
				pwszProvName = Marshal.PtrToStringUni(ki->pwszProvName);
			}
		}

		public void GetChainStatus(bool bLocalMachine, out uint CertErrorStatus, out uint CertInfoStatus)
		{
			if (bLocalMachine)
			{
				CertErrorStatus = certLocalMachineErrorStatus;
				CertInfoStatus = certLocalMachineInfoStatus;
			}
			else
			{
				CertErrorStatus = certCurrentUserErrorStatus;
				CertInfoStatus = certCurrentUserInfoStatus;
			}
		}


		//
		// Firma PKCS7 senza timestamp
		//
		public byte [] Sign(byte [] inBuffer)
		{
			IntPtr pCertContext = WinCapi.CertCreateCertificateContext(WinCapi.MY_ENCODING_TYPE, rawCertData, (uint)rawCertData.Length);
			if (pCertContext == IntPtr.Zero)
				throw new CertException("CertCreateCertificateContext");

			unsafe
			{
				WinCapi.CRYPT_SIGN_MESSAGE_PARA SignMessagePara = new WinCapi.CRYPT_SIGN_MESSAGE_PARA();

				void *ww = pCertContext.ToPointer();
				SignMessagePara.cbSize = 68; // sizeof(WinCapi.CRYPT_SIGN_MESSAGE_PARA);
				SignMessagePara.HashAlgorithm.pszObjId = WinCapi.szOID_OIWSEC_sha1;
				SignMessagePara.pSigningCert = pCertContext;
				SignMessagePara.dwMsgEncodingType = WinCapi.MY_ENCODING_TYPE;
				SignMessagePara.cMsgCert = 1;
				SignMessagePara.rgpMsgCert = new IntPtr(&ww); // &pSignerCert;


				GCHandle hv = GCHandle.Alloc(inBuffer, GCHandleType.Pinned);
				void *v = Marshal.UnsafeAddrOfPinnedArrayElement(inBuffer, 0).ToPointer();
				IntPtr rgpbToBeSigned = new IntPtr(&v); // in ingresso per motivi strani vuole un array di puntatori, di cui noi usiamo solo il primo

				uint [] rgcbToBeSigned = new uint[1]; // lunghezza del primo ed unico buffer da firmare
				rgcbToBeSigned[0] = (uint)inBuffer.Length;

				uint cbEncodedBlob = 0;
				int r = WinCapi.CryptSignMessage(
					ref SignMessagePara,
					0,
					1,
					rgpbToBeSigned,
					rgcbToBeSigned,
					IntPtr.Zero,
					ref cbEncodedBlob);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					hv.Free();
					Close(ref pCertContext);
					throw new CertException("CryptSignMessage", dwError);
				}
				// qui mi ha ritornato lo spazio massimo necessario per la firma

				byte [] outBuffer = new byte[cbEncodedBlob];
				GCHandle hh = GCHandle.Alloc(outBuffer, GCHandleType.Pinned);

				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(outBuffer, 0);

				r = WinCapi.CryptSignMessage(
					ref SignMessagePara,
					0,
					1,
					rgpbToBeSigned,
					rgcbToBeSigned,
					ptOutBuffer,
					ref cbEncodedBlob);
				hh.Free();
				hv.Free();
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					Close(ref pCertContext);
					throw new CertException("CryptSignMessage", dwError);
				}
				byte [] rb = new byte [cbEncodedBlob];
				for (int i = 0; i < cbEncodedBlob; ++i)
					rb[i] = outBuffer[i];


				Close(ref pCertContext);
				return rb;
			}
		}


		//
		// restituisce un byteArray con il valore del tempo attuale 
		// RSA-Encoded
		//
		internal byte [] EncodeActualFileTime()
		{
			bool bResult = true;
			byte [] EncFileTime;

			DateTime now = DateTime.Now;
			long fTime = now.ToFileTime(); 
			uint OutDataLen= 0;

			bResult = WinCapi.CryptEncodeObject(
				WinCapi.MY_ENCODING_TYPE,
				WinCapi.szOID_RSA_signingTime,
				ref fTime,
				IntPtr.Zero,
				ref OutDataLen);
			if (bResult == false)
			{
				throw new CertException("CryptEncodeFileTimeObject");
			}

			unsafe 
			{
				byte [] r = new byte[OutDataLen];
				GCHandle rh = GCHandle.Alloc(r, GCHandleType.Pinned);
				void *ptr = Marshal.UnsafeAddrOfPinnedArrayElement(r, 0).ToPointer();

				bResult = WinCapi.CryptEncodeObject(
					WinCapi.MY_ENCODING_TYPE,
					WinCapi.szOID_RSA_signingTime,
					ref fTime,
					new IntPtr(ptr),
					ref OutDataLen);
				rh.Free();
				if (bResult == false)
				{
					throw new CertException("CryptEncodeFileTimeObject");
				}

				if (OutDataLen != r.Length)
				{
					byte [] rg = new byte [OutDataLen];
					for (int i = 0; i < OutDataLen; ++i)
						rg[i] = r[i];
					r = rg;
				}
				EncFileTime = r;
			}
			return EncFileTime;
		}


		//
		// Firma PKCS7 con TimeStamp
		//
		public byte [] SignWithTimeStamp(byte [] inBuffer)
		{
			IntPtr pCertContext = WinCapi.CertCreateCertificateContext(WinCapi.MY_ENCODING_TYPE, rawCertData, (uint)rawCertData.Length);
			if (pCertContext == IntPtr.Zero)
				throw new CertException("CertCreateCertificateContext");


			byte [] EncTimeStamp;
			EncTimeStamp = EncodeActualFileTime();
			
			unsafe
			{
				WinCapi.CRYPT_SIGN_MESSAGE_PARA SignMessagePara = new WinCapi.CRYPT_SIGN_MESSAGE_PARA();

				WinCapi.CRYPT_ATTR_BLOB [] cablob = new WinCapi.CRYPT_ATTR_BLOB[1];
				WinCapi.CRYPT_ATTRIBUTE [] ca = new WinCapi.CRYPT_ATTRIBUTE[1];

				//
				// Pinned byteArray contenente timeStamp
				//
				GCHandle hEncTs = GCHandle.Alloc(EncTimeStamp, GCHandleType.Pinned);
				void *vEncTs = Marshal.UnsafeAddrOfPinnedArrayElement(EncTimeStamp, 0).ToPointer();

				cablob[0] = new WinCapi.CRYPT_ATTR_BLOB();
				cablob[0].cbData = (uint)EncTimeStamp.Length;
				cablob[0].pbData = new IntPtr(vEncTs);

				ca[0] = new WinCapi.CRYPT_ATTRIBUTE();

				//
				// Devo allocare al di fuori la stringa contenente l'identificatore RSA del signing time
				// perche' altrimenti non riesco ad eseguire il pinning
				//
				ca[0].pszObjId = Marshal.StringToHGlobalAnsi(WinCapi.szOID_RSA_signingTime);
				
				ca[0].cValue = 1;

				//
				// Pinned byteArray contenente blob attributi (CaBlob)
				//
				GCHandle hCaBlob = GCHandle.Alloc(cablob, GCHandleType.Pinned);
				void *vCaBlob = Marshal.UnsafeAddrOfPinnedArrayElement(cablob, 0).ToPointer();
				ca[0].rgValue = new IntPtr(vCaBlob);



				//
				// Pinned byteArray contenente attributi
				//
				GCHandle hCa = GCHandle.Alloc(ca, GCHandleType.Pinned);
				void *vCa = Marshal.UnsafeAddrOfPinnedArrayElement(ca, 0).ToPointer();


				void *ww = pCertContext.ToPointer();
				SignMessagePara.cbSize = 68; // sizeof(WinCapi.CRYPT_SIGN_MESSAGE_PARA);
				SignMessagePara.HashAlgorithm.pszObjId = WinCapi.szOID_OIWSEC_sha1;
				SignMessagePara.pSigningCert = pCertContext;
				SignMessagePara.dwMsgEncodingType = WinCapi.MY_ENCODING_TYPE;
				SignMessagePara.cMsgCert = 1;
				SignMessagePara.rgpMsgCert = new IntPtr(&ww); // &pSignerCert;

				//
				// Aggiungo attributo per il timestamp
				//
				SignMessagePara.cAuthAttr = 1;
				SignMessagePara.rgAuthAttr = new IntPtr(vCa);


				GCHandle hv = GCHandle.Alloc(inBuffer, GCHandleType.Pinned);
				void *v = Marshal.UnsafeAddrOfPinnedArrayElement(inBuffer, 0).ToPointer();
				IntPtr rgpbToBeSigned = new IntPtr(&v); // in ingresso per motivi strani vuole un array di puntatori, di cui noi usiamo solo il primo

				uint [] rgcbToBeSigned = new uint[1]; // lunghezza del primo ed unico buffer da firmare
				rgcbToBeSigned[0] = (uint)inBuffer.Length;

				uint cbEncodedBlob = 0;
				int r = WinCapi.CryptSignMessage(
					ref SignMessagePara,
					0,
					1,
					rgpbToBeSigned,
					rgcbToBeSigned,
					IntPtr.Zero,
					ref cbEncodedBlob);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					Marshal.FreeHGlobal(ca[0].pszObjId); // dealloco stringa con identificatore timestamp
					hEncTs.Free();						 // pinned bytearray con timestamp
					hCaBlob.Free();						 // pinned bytearray dei blob degli attributi
					hCa.Free();							 // pinned bytearray degli attributi
					hv.Free();
					Close(ref pCertContext);
					throw new CertException("CryptSignMessage", dwError);
				}
				// qui mi ha ritornato lo spazio massimo necessario per la firma

				byte [] outBuffer = new byte[cbEncodedBlob];
				GCHandle hh = GCHandle.Alloc(outBuffer, GCHandleType.Pinned);

				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(outBuffer, 0);

				r = WinCapi.CryptSignMessage(
					ref SignMessagePara,
					0,
					1,
					rgpbToBeSigned,
					rgcbToBeSigned,
					ptOutBuffer,
					ref cbEncodedBlob);
				
				Marshal.FreeHGlobal(ca[0].pszObjId); // dealloco stringa con identificatore timestamp
				hEncTs.Free();						 // pinned bytearray con timestamp
				hCaBlob.Free();						 // pinned bytearray dei blob degli attributi
				hCa.Free();							 // pinned bytearray degli attributi
				hh.Free();
				hv.Free();
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					Close(ref pCertContext);
					throw new CertException("CryptSignMessage", dwError);
				}

				byte [] rb = new byte [cbEncodedBlob];
				for (int i = 0; i < cbEncodedBlob; ++i)
					rb[i] = outBuffer[i];

				Close(ref pCertContext);
				return rb;
			}
		}

		public void SetPin(string pin, string sProviderName, bool bUseMachineKeySet)
		{
			string ProviderName;
			if (sProviderName != null)
				ProviderName = sProviderName;
			else
				ProviderName = szProvName;

			unsafe
			{
				int r;

				void *q;
				IntPtr hp = new IntPtr(&q);

				uint dwFlag;
				if (bUseMachineKeySet)
				{
					dwFlag = WinCapi.CRYPT_MACHINE_KEYSET;
				}
				else
				{
					dwFlag = 0;
				}
				r = WinCapi.CryptAcquireContext(hp, szContainerName, ProviderName, WinCapi.PROV_RSA_FULL, dwFlag);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					throw new CertException("CryptAcquireContext failure", dwError);
				}
				IntPtr hCryptProv = new IntPtr(q);


				void *ptCryptKey;
				IntPtr hCryptKeyPtr = new IntPtr(&ptCryptKey);
				r = WinCapi.CryptGetUserKey(hCryptProv, WinCapi.AT_SIGNATURE, hCryptKeyPtr);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CryptReleaseContext(hCryptProv, 0);
					throw new CertException("CryptGetUserKey failure", dwError);
				}
				IntPtr hCryptKey = new IntPtr(ptCryptKey);

				// converto il pin in caratteri ascii ed eseguo setPin se il pin non e' vuoto
				if (pin != null)
				{
					if (pin.Length > 0 )
					{
						byte [] pinToSet = new byte [pin.Length + 1];
						for (int i = 0; i < pin.Length; ++i)
							pinToSet[i] = (byte)pin[i];
						pinToSet[pin.Length] = 0;
						r = WinCapi.CryptSetProvParam(hCryptProv, WinCapi.PP_SIGNATURE_PIN, pinToSet, 0);
						if (r == 0)
						{
							int dwError = Marshal.GetLastWin32Error();
							WinCapi.CryptDestroyKey(hCryptKey);
							WinCapi.CryptReleaseContext(hCryptProv, 0);
							throw new CertException("CryptSetProvParam failure", dwError);
						}
					}
				}

				r = WinCapi.CryptDestroyKey(hCryptKey);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CryptReleaseContext(hCryptProv, 0);
					throw new CertException("CryptDestroyKey failure", dwError);
				}

				r = WinCapi.CryptReleaseContext(hCryptProv, 0);
				if (r == 0)
				{
					int dwError = Marshal.GetLastWin32Error();
					throw new CertException("CryptReleaseContext failure", dwError);
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="bUseMachineKeySet"></param>
		/// <param name="ProviderName"></param>
		/// 
		public void GenerateKeyContainer(bool bUseMachineKeySet)
		{
			GenerateKeyContainer(bUseMachineKeySet, szContainerName, szProvName);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="bUseMachineKeySet"></param>
		/// <param name="ProviderName"></param>
		public void DeleteKeyContainer(bool bUseMachineKeySet)
		{
			DeleteKeyContainer(bUseMachineKeySet, szContainerName, szProvName);
		}


		/// <summary>
		///		GenerateKeyContainer
		/// </summary>
		/// <param name="bUseMachineKeySet"></param>
		/// <param name="ContainerName"></param>
		/// <param name="ProviderName"></param>
		static public void GenerateKeyContainer(bool bUseMachineKeySet, string ContainerName, string ProviderName)
		{
			unsafe
			{
				int r;
				void *q;
				IntPtr hp = new IntPtr(&q);

				uint dwFlag;
				if (bUseMachineKeySet)
				{
					dwFlag = WinCapi.CRYPT_MACHINE_KEYSET | WinCapi.CRYPT_NEWKEYSET;
				}
				else
				{
					dwFlag = WinCapi.CRYPT_NEWKEYSET;
				}
				r = WinCapi.CryptAcquireContext(hp, ContainerName, ProviderName, WinCapi.PROV_RSA_FULL, 
					dwFlag);
				if (r == 0)
					throw new CertException("CryptAcquireContext GenerateKeyContainer failure");

				IntPtr hCryptProv = new IntPtr(q);


				//
				// Genera una chiave di tipo AT_SIGNATURE RSA 1024 bit
				//
				void *ptCryptKey;
				IntPtr hCryptKeyPtr = new IntPtr(&ptCryptKey);
				bool bRes;
				bRes = WinCapi.CryptGenKey(hCryptProv, WinCapi.AT_SIGNATURE, WinCapi.RSA1024BIT_KEY | WinCapi.CRYPT_EXPORTABLE, hCryptKeyPtr);
				if (bRes == false)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CryptReleaseContext(hCryptProv, 0);
					throw new CertException("CryptGenKey  GenerateKeyContainer failure", dwError);
				}
				IntPtr hCryptKey = new IntPtr(ptCryptKey);

				r = WinCapi.CryptDestroyKey(hCryptKey);
				if (r ==0)
				{
					int dwError = Marshal.GetLastWin32Error();
					WinCapi.CryptReleaseContext(hCryptProv, 0);
					throw new CertException("CryptDestroyKey GenerateKeyContainer failure", dwError);
				}

				r = WinCapi.CryptReleaseContext(hCryptProv, 0);
				if (r == 0)
					throw new CertException("CryptReleaseContext GenerateKeyContainer failure");
			}
		}

		/// <summary>
		///		DeleteKeyContainer
		/// </summary>
		/// <param name="bUseMachineKeySet"></param>
		/// <param name="ContainerName"></param>
		/// <param name="ProviderName"></param>
		static public void DeleteKeyContainer(bool bUseMachineKeySet, string ContainerName, string ProviderName)
		{
			unsafe
			{
				int r;
				void *q;
				IntPtr hp = new IntPtr(&q);

				uint dwFlag;
				if (bUseMachineKeySet)
				{
					dwFlag = WinCapi.CRYPT_MACHINE_KEYSET | WinCapi.CRYPT_DELETEKEYSET;
				}
				else
				{
					dwFlag = WinCapi.CRYPT_DELETEKEYSET;
				}
				r = WinCapi.CryptAcquireContext(hp, ContainerName, ProviderName, WinCapi.PROV_RSA_FULL, 
					dwFlag);
				if (r == 0)
					throw new CertException("CryptAcquireContext DeleteKeyContainer failure");
			}
		}

	}
}
