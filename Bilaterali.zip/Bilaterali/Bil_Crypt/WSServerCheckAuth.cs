using System;
using System.Web.Services.Protocols;
using System.Web;
using System.Configuration;
using System.Collections.Specialized;
using System.Security.Cryptography.X509Certificates;

namespace Bil_Crypt
{
	/// <summary>
	/// Summary description for WSServerCheckAuth.
	/// </summary>
	public class WSServerCheckAuth
	{
		/// <summary>
		///		CheckAuth: se il certificato e' presente controlla l'autenticazione su certificato
		///		altrimenti controlla username e password 
		/// </summary>
		/// <param name="request"></param>
		/// <param name="authHeader"></param>
		public static void CheckAuth(System.Web.HttpRequest request, WSAuthHeader authHeader)
		{
			if (request.ClientCertificate.IsPresent)
				WSServerCheckCertificate.CheckClientCertificate(request);
			else
				WSServerCheckUserPassword.CheckUserPassword(authHeader);
		}
	}
}
