using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Text;

namespace CertPInvokeLib
{
	/// <summary>
	/// Summary description for CryptVerify.
	/// </summary>
	public class CryptVerify
	{
		private byte [] unsignedData;
		private CertX509Ex signedCertificate;
		private uint localMachineCertErrorStatus;
		private uint localMachineCertInfoStatus;
		private uint currentUserCertErrorStatus;
		private uint currentUserCertInfoStatus;
		private string hashAlgorithm;
        private string hashEncAlg;
		private byte [] hashData;
		private DateTime signedDateTime;
 
		internal void setDefault()
		{
			unsignedData = null;
			signedCertificate = null;
			localMachineCertErrorStatus = 0;
			localMachineCertInfoStatus = 0;
			currentUserCertErrorStatus = 0;
			currentUserCertInfoStatus = 0;
			hashAlgorithm = string.Empty;
			hashEncAlg = string.Empty;
			hashData = null;
			signedDateTime = DateTime.MinValue;
		}
 	
		//
		// costruttore di default (non genera eccezione)
		//
		public CryptVerify()
		{
			setDefault();
		}


		public void Load(byte [] PKCS7Data, bool bSignVerify)
		{
			IntPtr hMsg;
			setDefault();

			//
			// Se richiesto: verifica la firma prima di elaborare lo stream
			//
			if (bSignVerify == true)
			{
				if (Verify(PKCS7Data) == false)
					throw new CertException("CryptVerify:CryptVerify() Sign Verify FAIL ");
			}

			hMsg = WinCapi.CryptMsgOpenToDecode(
				WinCapi.MY_ENCODING_TYPE,      // Encoding type.
				0,                             // Flags.
				0,                             // Use the default message type. The message type is listed in the message header.
				IntPtr.Zero,			      // Cryptographic provider. Use NULL for the default provider.
				IntPtr.Zero,                  // Recipient information.
				IntPtr.Zero);                 // Stream information.

			if (hMsg == IntPtr.Zero)
				throw new CertException("CryptVerify:CryptMsgOpenToDecode");

			bool brc = WinCapi.CryptMsgUpdate(
				hMsg,                        // Handle to the message
				PKCS7Data,                   // Pointer to the encoded BLOB
				(uint)PKCS7Data.Length,      // Size of the encoded BLOB
				true);                       // Last call

			if (brc == false)
			{
				int dwError = Marshal.GetLastWin32Error();
				Close(ref hMsg);
				throw new CertException("CryptVerify:CryptMsgUpdate", dwError);
			}

			//
			// Dati strettamente necessari per la decodifica
			//
			try
			{
				// Carica il buffer unsigned
				unsignedData = loadUnsignedData(hMsg);
				// Carica il certificato embedded di firma
				signedCertificate = loadCertificate(hMsg);
				// Carica lo stato di trust del certificato embedded
				loadChainErrorStatus(signedCertificate);
				// Carica l'algoritmo di hashing
				hashAlgorithm = loadHashAlgorithm(hMsg);
				// Carica l'algoritmo di encryption
				hashEncAlg = loadHashEncriptionAlgorithm(hMsg);
				// Carica byte array contenenti hash
				hashData = loadHashData(hMsg);
			}
			catch(CertException cEx)
			{
				setDefault();
				Close(ref hMsg);
				throw cEx;
			}
			catch(Exception ex)
			{
				setDefault();
				Close(ref hMsg);
				throw ex;
			}
			
			//
			// Dati non strettamente necessari per la decodifica 
			// la firma puo' essere fatta con timestamp oppure no 
			//
			try
			{
				signedDateTime = loadSigningTime(hMsg);
			}
			catch
			{
				signedDateTime = DateTime.MinValue;
			}
			
			//
			//
			//
			Close(ref hMsg);
		}

		//
		// Costruttore (genera eccezione)
		//
		public CryptVerify(byte [] PKCS7Data, bool bSignVerify)
		{
			Load(PKCS7Data, bSignVerify);
		}

		public byte [] GetData()
		{
			return unsignedData;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		internal byte [] loadUnsignedData(IntPtr hMsg)
		{
			uint OutDataLen;
			if (hMsg == IntPtr.Zero)
				throw new CertException("CryptVerify.GetData called with a closed Message handle");

			bool brc = WinCapi.CryptMsgGetParam(
				hMsg,                          // Handle to the message
				WinCapi.CMSG_CONTENT_PARAM,    // Parameter type
				0,                             // Index
				IntPtr.Zero,
				out OutDataLen);                   // Size of the returned information.
			if (brc == false)
			{
				throw new CertException("CryptVerify:CryptMsgGetParam CMSG_CONTENT_PARAM");
			}
			unsafe
			{
				byte [] r = new byte[OutDataLen];
				GCHandle rh = GCHandle.Alloc(r, GCHandleType.Pinned);
				void *ptr = Marshal.UnsafeAddrOfPinnedArrayElement(r, 0).ToPointer();

				brc = WinCapi.CryptMsgGetParam(
					hMsg,                          // Handle to the message
					WinCapi.CMSG_CONTENT_PARAM,    // Parameter type
					0,                             // Index
					new IntPtr(ptr),
					out OutDataLen);               // Size of the returned information.
				rh.Free();
				if (brc == false)
				{
					throw new CertException("CryptVerify:CryptMsgGetParam CMSG_CONTENT_PARAM");
				}
				if (OutDataLen != r.Length)
				{
					byte [] rg = new byte [OutDataLen];
					for (int i = 0; i < OutDataLen; ++i)
						rg[i] = r[i];
					r = rg;
				}
				return r;
			}
		}


		public CertX509Ex GetCertificate()
		{
			return signedCertificate;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="PKCS7Data"></param>
		/// <returns></returns>
		internal CertX509Ex loadCertificate(IntPtr hMsg)
		{
			if (hMsg == IntPtr.Zero)
				throw new CertException("CryptVerify.GetCertificate called with a closed Message handle");
			uint OutDataLen;
			bool brc = WinCapi.CryptMsgGetParam(
				hMsg,                          // Handle to the message
				WinCapi.CMSG_CERT_PARAM,       // Parameter type
				0,                             // Index
				IntPtr.Zero,
				out OutDataLen);                   // Size of the returned information.
			if (brc == false)
			{
				throw new CertException("CryptVerify:GetCertificate CryptMsgGetParam CMSG_CERT_PARAM");
			}

			unsafe
			{
				byte [] r = new byte[OutDataLen];
				GCHandle rh = GCHandle.Alloc(r, GCHandleType.Pinned);
				void *ptr = Marshal.UnsafeAddrOfPinnedArrayElement(r, 0).ToPointer();

				brc = WinCapi.CryptMsgGetParam(
					hMsg,                          // Handle to the message
					WinCapi.CMSG_CERT_PARAM,       // Parameter type
					0,                             // Index
					new IntPtr(ptr),
					out OutDataLen);               // Size of the returned information.
				rh.Free();
				if (brc == false)
				{
					throw new CertException("CryptVerify:GetCertificate CryptMsgGetParam CMSG_CERT_PARAM");
				}

				if (OutDataLen != r.Length)
				{
					byte [] rg = new byte [OutDataLen];
					for (int i = 0; i < OutDataLen; ++i)
						rg[i] = r[i];
					r = rg;
				}
				CertX509Ex cc = new CertX509Ex(r);
				return cc;
			}
		}

		public bool GetChainErrorStatus(bool bLocalMachine, out string sErrorInfo)
		{
			sErrorInfo = string.Empty;
			if (bLocalMachine)
			{
				return formatChainErrorStatus(localMachineCertErrorStatus, localMachineCertInfoStatus, out sErrorInfo);		
			}
			else
			{
				return formatChainErrorStatus(currentUserCertErrorStatus, currentUserCertInfoStatus, out sErrorInfo);		
			}
		}

		internal void loadChainErrorStatus(CertX509Ex cert)
		{
			localMachineCertErrorStatus = 0;
		    localMachineCertInfoStatus = 0;
		    currentUserCertErrorStatus = 0;
		    currentUserCertInfoStatus = 0;
			loadChainErrorStatus(cert, true, out localMachineCertErrorStatus, out localMachineCertInfoStatus);
			loadChainErrorStatus(cert, false, out currentUserCertErrorStatus, out currentUserCertInfoStatus);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="bLocalMachine"></param>
		/// <param name="sErrorInfo"></param>
		/// <returns></returns>
		internal void loadChainErrorStatus(CertX509Ex cert, bool bLocalMachine, out uint CertErrorStatus, out uint CertInfoStatus)
		{
			if (cert == null)
				throw new CertException("CryptVerify.GetChainErrorStatus called with a null certificate");
			cert.GetChainStatus(bLocalMachine, out CertErrorStatus, out CertInfoStatus);
			return;
		}

		internal bool formatChainErrorStatus(uint CertErrorStatus, uint CertInfoStatus, out string sErrorInfo)
		{
			bool bAnyError  = false;
			StringBuilder sErr = new StringBuilder();
			StringBuilder sInfo = new StringBuilder();
			bool bResult = true;
			
			Type CertErrors = typeof(WinCapi.CertTrustProblemsErrorStatus);
			foreach (int cErr in Enum.GetValues(CertErrors))
			{
				if (((cErr & CertErrorStatus) == cErr) && (cErr != 0))
				{
					bAnyError = true;
					sErr.Append("GetChainErrorStatus Type = ");
					sErr.Append(Enum.GetName(CertErrors, cErr));
				}
			}
			Type CertInfos = typeof(WinCapi.CertTrustProblemsInfoStatus);
			foreach (int cErr in Enum.GetValues(CertInfos))
			{
				if (((cErr & CertInfoStatus) == cErr) && (cErr != 0))
				{
					sInfo.Append(" GetChainInfoStatus Type = ");
					sInfo.Append(Enum.GetName(CertInfos, cErr));
				}
			}

			if (bAnyError)
			{
				bResult = false;
				sErrorInfo = sErr.ToString() + sInfo.ToString();
			}
			else
			{
				bResult = true;
				sErrorInfo = Enum.GetName(CertErrors, WinCapi.CertTrustProblemsErrorStatus.CERT_TRUST_NO_ERROR);
			}
			return bResult;
		}



		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		internal WinCapi.CMSG_SIGNER_INFO_2 GetSignerInfo(IntPtr hMsg)
		{
			
			if (hMsg == IntPtr.Zero)
				throw new CertException("CryptVerify.GetSignerInfo called with a closed Message handle");

			uint cbSize = 0;
			bool b;
			b = WinCapi.CryptMsgGetParam(hMsg,    // Handle to the message
				WinCapi.CMSG_SIGNER_INFO_PARAM,    // Parameter type
				0,                     // Index
				IntPtr.Zero,
				out cbSize);     // Size of the returned information.
			if (b == false)
			{
				throw new CertException("CryptMsgGetParam CMSG_SIGNER_INFO_PARAM");	
			}

			byte [] pbContent = new byte[cbSize];
			GCHandle hh = GCHandle.Alloc(pbContent, GCHandleType.Pinned);
			IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(pbContent, 0);
			
			b = WinCapi.CryptMsgGetParam(hMsg,                  // Handle to the message
				WinCapi.CMSG_SIGNER_INFO_PARAM,    // Parameter type
				0,                     // Index
				ptOutBuffer,
				out cbSize);     // Size of the returned information.
			if (b == false)
			{
				throw new CertException("CryptMsgGetParam CMSG_SIGNER_INFO_PARAM");	
			}
			WinCapi.CMSG_SIGNER_INFO_2 cmsSignerInfo = new WinCapi.CMSG_SIGNER_INFO_2();
			cmsSignerInfo = (WinCapi.CMSG_SIGNER_INFO_2) Marshal.PtrToStructure(ptOutBuffer, typeof(WinCapi.CMSG_SIGNER_INFO_2));
			hh.Free();
			return cmsSignerInfo;
		}


		public string GetHashAlgorithm()
		{
			return hashAlgorithm;
		}

		/// <summary>
		///		loadHashAlgorithm: ritorna la stringa szOID dell'algoritmo di HASH utilizzato
		///		per la firma 
		/// </summary>
		/// <param name="PKCS7Data"></param>
		/// <returns></returns>
		internal string loadHashAlgorithm(IntPtr hMsg)
		{
			string HashAlgorithm = "";
			if (hMsg == IntPtr.Zero)
				throw new CertException("CryptVerify.GetHashAlgorithm called with a closed Message handle");

			WinCapi.CMSG_SIGNER_INFO_2 cmsSignerInfo = GetSignerInfo(hMsg);
			HashAlgorithm = Marshal.PtrToStringAnsi(cmsSignerInfo.HashAlgorithm.pszObjId);
			return HashAlgorithm;
		}


		public string GetHashEncriptionAlgorithm()
		{
			return hashEncAlg;
		}

		/// <summary>
		///		GetHashEncrytpionAlgorithm: ritorna la stringa szOID dell'algoritmo di Encryption HASH utilizzato
		///		per la firma 
		/// </summary>
		/// <returns></returns>
		internal string loadHashEncriptionAlgorithm(IntPtr hMsg)
		{
			string HashEncAlg = "";
			if (hMsg == IntPtr.Zero)
				throw new CertException("CryptVerify.GetHashEncryptionAlgorithm called with a closed Message handle");
			WinCapi.CMSG_SIGNER_INFO_2 cmsSignerInfo = GetSignerInfo(hMsg);
			HashEncAlg = Marshal.PtrToStringAnsi(cmsSignerInfo.HashEncryptionAlgorithm.pszObjId);
			return HashEncAlg;
		}


		public byte[] GetHashData()
		{
			return hashData;
		}
		

		/// <summary>
		///		GetHashData: ritorna l'HASH 
		/// </summary>
		/// <returns></returns>
		internal byte[] loadHashData(IntPtr hMsg)
		{
			byte [] HashData = null;
			if (hMsg == IntPtr.Zero)
				throw new CertException("CryptVerify.GetHashData called with a closed Message handle");

			WinCapi.CMSG_SIGNER_INFO_2 cmsSignerInfo = GetSignerInfo(hMsg);
			HashData = new byte[cmsSignerInfo.EncryptedHash.cbData];
			unsafe
			{
				for (int i=0; i<cmsSignerInfo.EncryptedHash.cbData; i++)
				{
					void *pByte = (void *)((int)cmsSignerInfo.EncryptedHash.pbData.ToPointer() + i);
					IntPtr pIntByte = new IntPtr(pByte);
					HashData[i] = Marshal.ReadByte(pIntByte);
				}
			}
			return HashData;
		}

		public DateTime GetSigningTime()
		{
			return signedDateTime;
		}

		/// <summary>
		///    GetSigningTime
		///		Ottiene il tempo di firma di uno stream PKCS7, nell'ipotesi che 
		///		lo stream PKCS7 sia firmato con aggiunta di timestamp (come nel caso
		///		della controfirma)
		/// </summary>
		/// <returns></returns>
		internal DateTime loadSigningTime(IntPtr hMsg)
		{
			if (hMsg == IntPtr.Zero)
				throw new CertException("CryptVerify.GetSigningTime called with a closed Message handle");

			DateTime signDt = new DateTime();
			uint OutDataLen;
			bool brc = WinCapi.CryptMsgGetParam(
				hMsg,								// Handle to the message
				WinCapi.CMSG_SIGNER_AUTH_ATTR_PARAM,        // Parameter type
				0,									// Index
				IntPtr.Zero,              
				out OutDataLen);                   // Size of the returned information.
			if (brc == false)
			{
				throw new CertException("CryptMsgGetParam CMSG_SIGNER_AUTH_ATTR_PARAM");
			}

			unsafe
			{
				byte *r = stackalloc byte[(int)OutDataLen + 1];
				
				brc = WinCapi.CryptMsgGetParam(
					hMsg,                          // Handle to the message
					WinCapi.CMSG_SIGNER_AUTH_ATTR_PARAM,       // Parameter type
					0,                             // Index
					new IntPtr(r),
					out OutDataLen);               // Size of the returned information.
				if (brc == false)
				{
					throw new CertException("CryptMsgGetParam CMSG_SIGNER_AUTH_ATTR_PARAM");
				}
				
				WinCapi.CRYPT_ATTRIBUTES *pAttr = (WinCapi.CRYPT_ATTRIBUTES *) r;
				bool bFoundSigningTimeAttribute = false;
				long lTime = 0;

				void *pRgAttr = pAttr->rgAttr.ToPointer();

				for (uint i=0; i<pAttr->cAttr; i++)
				{

					WinCapi.CRYPT_ATTRIBUTE *rgSingle = (WinCapi.CRYPT_ATTRIBUTE *)pRgAttr;
					
					string szOID = Marshal.PtrToStringAnsi(rgSingle->pszObjId);
					if (szOID == WinCapi.szOID_RSA_signingTime)
					{
						uint cblTime =sizeof(long);

						WinCapi.CRYPT_ATTR_BLOB *pCaBlob = (WinCapi.CRYPT_ATTR_BLOB *) rgSingle->rgValue.ToPointer();
					
						// decodes a structure of the type indicated by the lpszStructType parameter.
						brc=WinCapi.CryptDecodeObject(WinCapi.MY_ENCODING_TYPE,
							WinCapi.szOID_RSA_signingTime,
							pCaBlob->pbData,
							pCaBlob->cbData,
							0,
							out lTime,
							ref cblTime);
						if (brc == false)
						{
							throw new CertException("CryptDecodeObject szOID_RSA_signingTime");
						}
						else
						{
							bFoundSigningTimeAttribute = true;
							break;
						}
					}
					pRgAttr = (void *)((int)pRgAttr + sizeof(WinCapi.CRYPT_ATTRIBUTE));
				}
			
				if (bFoundSigningTimeAttribute)
				{
					signDt = new DateTime();
					signDt = DateTime.FromFileTime(lTime);
				}

			}
			return signDt;
		}

		/// <summary>
		///		Verify: verifica la firma in senso stretto
		/// </summary>
		/// <param name="PKCS7Data"></param>
		/// <returns></returns>
		static public bool Verify(byte [] PKCS7Data)
		{
			unsafe
			{
				WinCapi.CRYPT_VERIFY_MESSAGE_PARA VerifyMessagePara = new WinCapi.CRYPT_VERIFY_MESSAGE_PARA();
				VerifyMessagePara.cbSize = (uint) sizeof(WinCapi.CRYPT_VERIFY_MESSAGE_PARA);
				VerifyMessagePara.dwMsgAndCertEncodingType = WinCapi.MY_ENCODING_TYPE;
				VerifyMessagePara.hCryptProv	= IntPtr.Zero;
				VerifyMessagePara.pfnGetSignerCertificate = IntPtr.Zero;
				VerifyMessagePara.pvGetArg	 = IntPtr.Zero;
	
				IntPtr pSignerCert = IntPtr.Zero;
				uint cbDecodedBlob = 0; 
				bool r = WinCapi.CryptVerifyMessageSignature(ref VerifyMessagePara,
					0,
					PKCS7Data,
					(uint) PKCS7Data.Length,
					IntPtr.Zero,
					ref cbDecodedBlob,
					out pSignerCert);
				if (r == false)
					return r;

				byte [] outBuffer = new byte[cbDecodedBlob];
				GCHandle hh = GCHandle.Alloc(outBuffer, GCHandleType.Pinned);
				IntPtr ptOutBuffer = Marshal.UnsafeAddrOfPinnedArrayElement(outBuffer, 0);

				r = WinCapi.CryptVerifyMessageSignature(ref VerifyMessagePara,
					0,
					PKCS7Data,
					(uint) PKCS7Data.Length,
					ptOutBuffer,
					ref cbDecodedBlob,
					out  pSignerCert);
				hh.Free();
				return r;
			}
		}

		internal void Close(ref IntPtr hMsg)
		{
			bool r;
			if (hMsg != IntPtr.Zero)
			{
				r = WinCapi.CryptMsgClose(hMsg);
				if (r == false)
					throw new CertException("CryptVerify:Close CryptMsgClose");
				hMsg = IntPtr.Zero;
			}
		}
	}
}
