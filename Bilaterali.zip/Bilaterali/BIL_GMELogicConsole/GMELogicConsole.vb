Imports System
Imports System.Runtime.Remoting
Imports System.Runtime.Remoting.Channels
Imports System.Reflection
Imports Bil_GMELogic

Module GMELogicConsole

    Sub Main()
        Dim bLocal As Boolean
        bLocal = False
        If bLocal Then
            ' TestLocalDll()
            TestLocalDllDownloadOnly()
        Else
            Dim currentDomain As AppDomain = AppDomain.CurrentDomain
            RemotingConfiguration.Configure(currentDomain.SetupInformation.ConfigurationFile)

            Dim s As String
            Do
                Console.Write("Scrivi 'q' per terminare il server")
                s = Console.ReadLine()
                If s = "q" Or s = "Q" Then
                    Console.WriteLine("Server terminato da tastiera")
                    Exit Do
                End If
            Loop
        End If
    End Sub

    Sub TestLocalDllDownloadOnly()
        Dim c As FileLoadSave = New FileLoadSave
        Dim streamLength As Int32 = 10
        Dim indx As Int32 = 0
        Dim btStream(streamLength) As Byte
        Dim sDownloadFileName As String = "OutFile.in.xml"
        Dim bResult As Boolean
        Dim sFileName As String = "OutFile.out.xml"
        Dim sFileNameArray() As String
        Dim numberOfFiles As Integer


        bResult = c.GetNextFilesToDownload(sFileNameArray, numberOfFiles)
        If bResult Then
            Console.WriteLine("Download Result= OK")
        Else
            Console.WriteLine("Download Result= KO")
        End If


        bResult = c.DownloadFile(sFileName, btStream, streamLength)
        If bResult Then
            Console.WriteLine("Download Result= OK")
        Else
            Console.WriteLine("Download Result= KO")
        End If

        bResult = c.RemoveFirstFile()
        If bResult Then
            Console.WriteLine("Remove First File = OK")
        Else
            Console.WriteLine("Remove First File = KO")
        End If

    End Sub


    Sub TestLocalDll()
        Dim c As FileLoadSave = New FileLoadSave
        Dim bResult As Boolean
        Dim sFileName As String = "OutFile.out.xml"
        Dim sDownloadFileName As String = "OutFile.in.xml"
        Dim streamLength As Int32 = 10
        Dim indx As Int32 = 0
        Dim btStream(streamLength) As Byte
        '
        ' Esempio: riempie il file con tutti caratteri 'A'
        '
        For indx = 0 To streamLength - 1
            btStream(indx) = 65
        Next
        '
        ' Upload su file su directory sUploadDir
        '
        bResult = c.UploadFile(sFileName, btStream, streamLength)
        If bResult Then
            Console.WriteLine("Upload Result= OK ")
        Else
            Console.WriteLine("Upload Result= KO ")
        End If

        '
        ' Upload su file su directory sDownloadDir
        '
        ' Esempio: metti tutti 'B' su 
        '
        For indx = 0 To streamLength - 1
            btStream(indx) = btStream(indx) + 1
        Next

        bResult = c.UploadFile(sDownloadFileName, btStream, streamLength)
        If bResult Then
            Console.WriteLine("Upload Result= OK")
        Else
            Console.WriteLine("Upload Result= KO")
        End If

        '
        ' Download da file su directory sDownloadDir
        '
        bResult = c.DownloadFile(sFileName, btStream, streamLength)
        If bResult Then
            Console.WriteLine("Download Result= OK")
        Else
            Console.WriteLine("Download Result= KO")
        End If

        '
        ' RemoveFirstFile() file su directory sDownloadDir
        '
        bResult = c.RemoveFirstFile()
        If bResult Then
            Console.WriteLine("RemoveFirstFile Result= OK")
        Else
            Console.WriteLine("RemoveFirstFile Result= KO")
        End If
    End Sub

End Module
