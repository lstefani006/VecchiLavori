/* ------------------------------------------------------------------------------------------ 
 * Upgrade Database: script SQL per l'upgrade del Database in versione 2.3.0.1
 * ------------------------------------------------------------------------------------------ 
 */

use [Bilaterali]

DECLARE @Version AS VARCHAR(16)

SELECT @Version = Version 
FROM DBVersion
PRINT 'Il database e` in versione: ' + @Version

IF @Version <> '2.3.0.0'
	PRINT 'Il database non e` nella versione prevista !'




print 'Aggiornamento Stored Procedure [spGetOperatorListUnits].'

GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetOperatorListUnits]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[spGetOperatorListUnits]
GO

CREATE PROCEDURE dbo.spGetOperatorListUnits
	@dt as datetime
AS

select CodiceUnitaSDC, 
	NroOp,
	AbilitataRUP,
	AbilitataNAB,
	Abilitata,
	LstOp
from 
(
	select w.CodiceUnitaSDC, 
	w.CategoriaUnitaSDC,
	w.NroOp, 
	k.AbilitataRUP,
	k.AbilitataNAB,
	k.Abilitata,
	w.LstOp
	from 
	(
		select t.CodiceUnitaSDC, t.CategoriaUnitaSDC,
		count(t.CodiceOperatoreSDC)  NroOp, 
		dbo.GetOperatori(t.CodiceUnitaSDC, t.CategoriaUnitaSDC, @dt)  LstOp 
		from
		(
			select
			su.CodiceUnitaSDC, 
			ur.CodiceOperatoreSDC, 
			su.CategoriaUnitaSDC 
			from SDC_Unita su
			-- SCR Id267: tali condizioni non sono piu` filtri, 
			-- bensi` sono colonne esplicite sul report.
			-- left outer join Unita u
			-- on su.CodiceUnitaSDC = u.CodiceUnitaSDC 
			-- and su.CategoriaUnitaSDC = u.CategoriaUnitaSDC
			-- and u.StatoBilateraliUnita = 1
			-- and su.Abilitata = 1
			left outer join UnitRelate ur
			on su.CodiceUnitaSDC = ur.CodiceUnitaSDC 
			and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
			and @dt >= ur.DataInizioValidita
			and @dt <= ur.DataFineValidita
			and ur.Abilitata = 1
			-- SCR Id267: tali condizioni non sono piu` filtri, 
			-- bensi` sono colonne esplicite sul report.
			-- left outer join SDC_Unita_MarketInformation mi
			-- on su.CodiceUnitaSDC = mi.CodiceUnitaSDC 
			-- and su.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
			-- and mi.MarketCode = 'MGP'
			-- and mi.Eligibility = 'Able'
		) t 
		GROUP BY t.CodiceUnitaSDC, t.CategoriaUnitaSDC
	) w,
	(
		select 
		su.CodiceUnitaSDC,
		su.CategoriaUnitaSDC,
		case su.Abilitata 
		when 1 then 
			case mi.Eligibility 
			when 'Able' then  '1' 
			else	'0' 
			end
		else 
		'0' 
		end 'AbilitataRUP',
		case isnull(u.StatoBilateraliUnita, 0) when 1 then '1' else '0' end 'AbilitataNAB',
		case isnull(u.StatoBilateraliUnita, 0) & su.Abilitata when 1 then '1' else '0' end 'Abilitata'
		from SDC_Unita su
		left outer join Unita u
		on su.CodiceUnitaSDC = u.CodiceUnitaSDC 
		and su.CategoriaUnitaSDC = u.CategoriaUnitaSDC
		left outer join SDC_Unita_MarketInformation mi
		on su.CodiceUnitaSDC = mi.CodiceUnitaSDC 
		and su.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
		and mi.MarketCode = 'MGP'
		and mi.Eligibility = 'Able'
	) k
	where k.CodiceUnitaSDC = w.CodiceUnitaSDC 
	and k.CategoriaUnitaSDC = w.CategoriaUnitaSDC
) x
order by Abilitata desc, 
AbilitataRUP desc,
AbilitataNAB desc,
NroOp desc, 
CodiceUnitaSDC asc


GO


GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [bil_dbo]
GO


print 'UPDATE Version ON DBVersion'
UPDATE DBVersion SET Version = '2.3.0.1'

print 'UPDATE DBHistory'
INSERT INTO DBHistory (Version, Patch, UpgradeTS, Notes)
VALUES('2.3.0.1', NULL, getdate(), 'Upgrade alla Versione 2.3.0.1')

PRINT 'Il database e` aggiornato alla versione 2.3.0.1 !'

