SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO




ALTER   PROCEDURE [dbo].[spCalcolaBilanciamento]
	@DataProgramma smalldatetime,
	@SogliaSbilMWh float
AS

-- non si usa read uncommitted in quanto il bilanciamento 
-- viene lanciato dentro un batch (i dati quindi non cambiamo)
-- e comunque il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@DataProgramma smalldatetime,
-- 	@SogliaSbilMWh float
-- 
-- set @DataProgramma = '24/11/2004'
-- set @SogliaSbilMWh = 0.001
-- 
-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno
-- (tutti i programmi !! )

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.
-- POU.QtyMWhBilanciamento=null per tutti i programmi.

-- inizializzo i campi per la data
update ProgrammaOrario
set 
Bilanciato=null,
SbilanciamentoMWh=null,
SbilanciamentoMWhReale=null,
TSCalcoloBilanciamento=null
where DataProgramma = @DataProgramma

-- siccome calcolo il bilanciamento i dati del bilanciamento forzato devono essere resettati
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where DataProgramma = @DataProgramma
and not QtyMWhBilanciamento is null


-- qui indico che il bilanciamento per tutti i contratti e` stato fatto
-- e` da fare il taglio
update 
SessioneBilaterali
set
Bilanciamento=1,
Taglio=0
where DataProgramma=@DataProgramma




declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()


update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,

	case when Abs(round(Sum(Q.QtyMWh),3)) > @SogliaSbilMWh then 0 else 1 end Bilanciato,
	case when Abs(round(Sum(Q.QtyMWh),3)) > @SogliaSbilMWh then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on  PO.Idcontratto = POU.IdContratto
		and PO.DataProgramma = POU.DataProgramma
		and PO.PeriodoRilevante = POU.PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join  SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

		where
		POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
	) Q
	group by IdContratto, PeriodoRilevante
) W
on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER  PROCEDURE [dbo].[spCalcolaBilanciamentoPerOra]
	@DataProgramma smalldatetime,
	@SogliaSbilMWh float,
	@Ora tinyint,
	@UltimoBilanciamento bit
AS

-- non si usa read uncommitted in quanto il bilanciamento 
-- viene lanciato dentro un batch (i dati quindi non cambiamo)
-- e comunque il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@DataProgramma smalldatetime,
-- 	@SogliaSbilMWh float,
--	@Ora tinyint
-- 
-- set @DataProgramma = '24/11/2004'
-- set @SogliaSbilMWh = 0.001
-- set @Ora = 1
-- 
-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno
-- (tutti i programmi !! )

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.
-- POU.QtyMWhBilanciamento=null per tutti i programmi.

-- inizializzo i campi per la data
update ProgrammaOrario
set 
Bilanciato=null,
SbilanciamentoMWh=null,
SbilanciamentoMWhReale=null,
TSCalcoloBilanciamento=null
where 
    DataProgramma = @DataProgramma
and PeriodoRilevante = @Ora

-- siccome calcolo il bilanciamento i dati del bilanciamento forzato devono essere resettati
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where 
    DataProgramma = @DataProgramma
and PeriodoRilevante = @Ora
and not QtyMWhBilanciamento is null


-- qui indico che il bilanciamento per tutti i contratti e` stato fatto
-- e` da fare il taglio

if @UltimoBilanciamento = 1
begin
	update 
	SessioneBilaterali
	set
	Bilanciamento=1,
	Taglio=0
	where DataProgramma=@DataProgramma
end



declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()


update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,
	
	case when Abs(round(Sum(Q.QtyMWh),3)) > @SogliaSbilMWh then 0 else 1 end Bilanciato,
	case when Abs(round(Sum(Q.QtyMWh),3)) > @SogliaSbilMWh then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on  PO.Idcontratto = POU.IdContratto
		and PO.DataProgramma = POU.DataProgramma
		and PO.PeriodoRilevante = POU.PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on  CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on  UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

		where
		POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
		and POU.PeriodoRilevante = @Ora
	) Q
	group by IdContratto, PeriodoRilevante
) W
on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

