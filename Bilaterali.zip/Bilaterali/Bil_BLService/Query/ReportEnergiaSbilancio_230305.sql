alter procedure dbo.ReportEnergiaSbilancio
	@DataProgramma as datetime
as
	
--declare	@DataProgramma  datetime
--set @DataProgramma = '14/1/2005'

-- E` un report che puo` essere lanciato prima o dopo la lettura del mercato
-- Se siamo prima della lettura mercato la query deve utilizzare
-- lo stato corrente delle anagrafiche.
-- Se siamo a mercato letto, la query non deve utilizzare le informazioni
-- di attivazione ma solo partire dalle considerazioni sulla presenza o meno
-- della quantita` assegnata: vedi sotto per i particolari

set transaction isolation level read uncommitted

if Object_Id('tempdb..#Report1') is Not Null
	drop table #Report1

create table #Report1
(
	IdContratto      integer,
	DataProgramma    smalldatetime,
	PeriodoRilevante tinyint,
	QP float,
	QC float,
	QPT float,
	QCT float,
	QPMGP float,
	QCMGP float
)

-- controllo se e` stata effettuata la lettura del mercato
Declare @LetturaMGP int 
select @LetturaMGP=LetturaMGP from SessioneBilaterali
where DataProgramma=@DataProgramma
if @LetturaMGP is null 
	set @LetturaMGP=0

-- Print @LetturaMGP

if @LetturaMGP=1
begin
-- per individuare i record in POU in maniera "storica" ci possono essere piu` modi:
-- questo report pero` deve presentare anche le programmazioni che sono state 
-- effettuate e che non sono andate a mercato. 
-- Dunque non basta che la QtyMWhAssegnataMGP sia not null
-- dato che, per esempio, una quantita` tagliata a 0 non va a mercato e bisogna che comunque
-- dia il suo contributo per la quantita` programmata/tagliata.
-- Per risolvere qui il problema si usa PO.Bilanciato. 
-- Questo viene valorizzato nel calcolo del bilanciamento, e dunque, rispecchia 
-- le abilitazioni al momento dell'elaborazione. 
-- (in realta` e` null anche se tutte le unita` programmate nel contratto
--  sono disabilitate a causa della unit relate - caso remoto lo escludiamo)
-- Se e` null vuol dire che tutta quella programmazione si deve scartare, 
-- a causa dello stato del contratto o operatori, dalla data di fine ini/fine validita`
-- Se e` not null, alcune righe in POU potrebbero essere non valide a causa della unit-relate:
-- sono quelle che non hanno QtyMWhAssegnataMGP assegnata (o il corrispondente errore in POUE)
-- ci sono queste possibilita`:
-- una unita` ha QuantitaTagliata=0  e non e` andata a mercato 
--    --> non e` andata a mercato per la Qt=0 o forse per la UR modificata dopo il taglio (e` un po' remoto questo caso)
-- una unita` ha QuantitaTagliata!=0 e non e` andata a mercato 
--    --> e` disabilitata per la ur (e la ur e` stata modificata dopo il taglio -- caso remoto)
-- una unita` ha QuantitaTagliata=null e non e` andata a mercato
--    --> non e` andata a mercato perche` era esclusa dalla unit relate
-- Possiamo escludere che qualcuno sia intervenuto nella UR tra il taglio e la generazione delle offerte,
-- per cui 
-- 1) se ha QuantitaTagliata=0,    il record e` da considerare
-- 2) se ha QuantitaTagliata!=0,   il record e` da considerare (tanto poi non da` contributi)
-- 3) se ha QuantitaTagliata=null, il record e` da scartare    (e` fuori per la UR)
insert into #Report1
	select
	POU.IdContratto,
	POU.DataProgramma,
	POU.PeriodoRilevante,
	sum(QtyMWh * ProgrammatoDalCedente)                                         QP,
	sum(QtyMWh * -1 * (ProgrammatoDalCedente - 1))                              QC,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * ProgrammatoDalCedente)            QPT,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * -1 * (ProgrammatoDalCedente - 1)) QCT,
	sum(isnull(QtyMWhAssegnataMGP,0)  * ProgrammatoDalCedente)                  QPMGP,
	sum(isnull(QtyMWhAssegnataMGP,0)  * (-1) * (ProgrammatoDalCedente - 1))     QCMGP
	from
	ProgrammaOrarioPerUnita POU

	inner join ProgrammaOrario PO
	on  POU.DataProgramma     = PO.DataProgramma
	and POU.PeriodoRilevante  = PO.PeriodoRilevante
	and POU.IdContratto       = PO.IdContratto

	left outer join ProgrammaOrarioPerUnitaErrori POUE
	on  POU.DataProgramma     = POUE.DataProgramma
	and POU.PeriodoRilevante  = POUE.PeriodoRilevante
	and POU.IdContratto       = POUE.IdContratto
	and POU.CodiceUnitaSDC    = POUE.CodiceUnitaSDC
	and POU.CategoriaUnitaSDC = POUE.CategoriaUnitaSDC

	where
	POU.DataProgramma = @DataProgramma
	-- questo implica stato contratto abilitato e TrCN=1
	-- ma anche se tutte le unita programmate del contratto sono disabilitate a fronte dell'unit relate
	and PO.Bilanciato is not null
	and PO.ProgrammaOrarioValidato = 1
	and
	(
		-- e` andato a mercato --> lo conto
		QtyMWhAssegnataMGP is not null
		-- c'e` stato un errore --> lo conto
		or POUE.IdContratto is not null
		-- e` stato bilanciato --> lo conto
		or QtyMWhBilanciamento is not null
		-- so ho ricevuto il GMEReferenceNumber vuol dire che e` andato a mercato
		or GMEReferenceNumber is not null
		-- scarto quelli con QtyMWhBilanciamento is null
	)	
	and POU.ProgOrarioDellUnitaValidato=1

	group by POU.DataProgramma, POU.PeriodoRilevante, POU.IdContratto
	
	
	
select 
@DataProgramma DataProgramma,
C.CRN,
C.CodiceContratto,
C.CodiceOperatoreSDCCedente Cedente,
C.CodiceOperatoreSDCAcquirente Acquirente,
case (PO.GestioneTaglio) 
	when 'T' then 'Sempre'
	when 'C' then 'se cons. supera prod.'
	when 'P' then 'se prod. supera cons.'
	when 'M' then 'mai'
end 
GestioneTaglio,
PO.PeriodoRilevante Ora,
cast (R.QP as decimal(16,3))     QtyMWhProd,
cast (R.QC as decimal(16,3))     QtyMWhCons,
cast (R.QPT as decimal(16,3))    QtyMWhProdT,
cast (R.QCT as decimal(16,3))    QtyMWhConsT,
cast (R.QPMGP as decimal(16,3))  QtyMWhProdMGP,
cast (R.QCMGP as decimal(16,3))  QtyMWhConsMGP,
PO.Bilanciato Bilanciato,
cast(PO.SbilanciamentoMWh as decimal(16,3)) SbilanciamentoMWh
from ProgrammaOrario PO
inner join Contratto C
on PO.IdContratto = C.IdContratto
inner join #Report1 R
on  R.IdContratto   = PO.IdContratto
and R.DataProgramma = PO.DataProgramma
and R.PeriodoRilevante = PO.PeriodoRilevante
where
PO.DataProgramma = @DataProgramma
order by 
C.CRN, 
PO.PeriodoRilevante
	

end
else
begin

-- cerco i record partendo dallo stato attuale delle anagrafiche, contratti ecc.
insert into #Report1
	select
	POU.IdContratto,
	POU.DataProgramma,
	POU.PeriodoRilevante,
	sum(QtyMWh * ProgrammatoDalCedente) QP,
	sum(QtyMWh * -1 * (ProgrammatoDalCedente - 1)) QC,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * ProgrammatoDalCedente) QPT,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * -1 * (ProgrammatoDalCedente - 1)) QCT,
	sum(QtyMWhAssegnataMGP  * ProgrammatoDalCedente) QPMGP,
	sum(QtyMWhAssegnataMGP  * (-1) * (ProgrammatoDalCedente - 1)) QPMGC
	from
	ProgrammaOrarioPerUnita POU

	inner join Contratto CO
	on CO.IdContratto = POU.IdContratto
	and CO.TrCN = 1
	and CO.StatoContratto = 'Abilitato'
	
	inner join ProgrammaOrario PO
	on  PO.IdContratto = POU.IdContratto
	and PO.DataProgramma = POU.DataProgramma
	and PO.PeriodoRilevante = POU.PeriodoRilevante

	inner join UnitRelate UR
	on  UR.CodiceUnitaSDC    = POU.CodiceUnitaSDC
	and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC 
	and 
	(
		(POU.ProgrammatoDalCedente=1 and UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente)
		or
		(POU.ProgrammatoDalCedente=0 and UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente)
	)
	and UR.TrUC = 1
	and UR.DataInizioValidita <= @DataProgramma
	and UR.DataFineValidita   >= @DataProgramma
	and UR.Abilitata = 1
	
	where
	POU.DataProgramma = @DataProgramma
	and POU.PeriodoRilevante <= 25
	and POU.ProgOrarioDellUnitaValidato=1
	and PO.ProgrammaOrarioValidato = 1
	group by POU.DataProgramma, POU.PeriodoRilevante, POU.IdContratto
	
	
select 
@DataProgramma DataProgramma,
C.CRN,
C.CodiceContratto,
C.CodiceOperatoreSDCCedente Cedente,
C.CodiceOperatoreSDCAcquirente Acquirente,
case (C.GestioneTaglio) 
	when 'T' then 'Sempre'
	when 'C' then 'se cons. supera prod.'
	when 'P' then 'se prod. supera cons.'
	when 'M' then 'mai'
end 
GestioneTaglio,
PO.PeriodoRilevante Ora,
cast (R.QP as decimal(16,3))     QtyMWhProd,
cast (R.QC as decimal(16,3))     QtyMWhCons,
cast (R.QPT as decimal(16,3))    QtyMWhProdT,
cast (R.QCT as decimal(16,3))    QtyMWhConsT,
cast (R.QPMGP as decimal(16,3))  QtyMWhProdMGP,
cast (R.QCMGP as decimal(16,3))  QtyMWhConsMGP,
PO.Bilanciato Bilanciato,
cast(PO.SbilanciamentoMWh as decimal(16,3)) SbilanciamentoMWh
from ProgrammaOrario PO
inner join Contratto C
on PO.IdContratto = C.IdContratto
inner join #Report1 R
on  R.IdContratto   = PO.IdContratto
and R.DataProgramma = PO.DataProgramma
and R.PeriodoRilevante = PO.PeriodoRilevante
where
PO.DataProgramma = @DataProgramma
order by 
C.CRN, 
PO.PeriodoRilevante
	

end




drop table #Report1


RETURN
GO
