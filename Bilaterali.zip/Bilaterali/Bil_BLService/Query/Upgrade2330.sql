use bilaterali
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FileIO]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FileIO]
GO

CREATE TABLE [dbo].[FileIO] (
	[DataCreazione] [smalldatetime] NOT NULL ,
	[IdFile] [int] IDENTITY (1, 1) NOT NULL ,
	[TSInvio] [datetime] NOT NULL ,
	[InOut] [bit] NOT NULL ,
	[CodiceOperatoreSDC] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	[CodiceUtenteSDC] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	[CodiceTipoFile] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	[NomeFile] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	[DescrizioneFile] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CS_AS NULL ,
	[TSDownload] [datetime] NULL ,
	[ContenutoFile] [image] NULL ,
	[Zipped] [bit] NULL ,
	[Encoding] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CS_AS NULL ,
	[ContenutoFA] [image] NULL ,
	[ZippedFA] [bit] NULL ,
	[EncodingFA] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CS_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[FileIO] WITH NOCHECK ADD 
	CONSTRAINT [PK_FileIO] PRIMARY KEY  CLUSTERED 
	(
		[DataCreazione],
		[IdFile]
	)  ON [PRIMARY] 
GO

 CREATE  INDEX [IXFileImport] ON [dbo].[FileIO]([CodiceOperatoreSDC], [TSDownload]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[FileIO] ADD 
	CONSTRAINT [FK_FileIO_Operatori] FOREIGN KEY 
	(
		[CodiceOperatoreSDC]
	) REFERENCES [dbo].[Operatori] (
		[CodiceOperatoreSDC]
	),
	CONSTRAINT [FK_FileIO_Utenti] FOREIGN KEY 
	(
		[CodiceUtenteSDC]
	) REFERENCES [dbo].[Utenti] (
		[CodiceUtenteSDC]
	)
GO



BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
ALTER TABLE dbo.RelOperatoriUtenti ADD
	SuperUser bit NOT NULL CONSTRAINT DF_RelOperatoriUtenti_SuperUser DEFAULT 0
GO
COMMIT


--   marted� 8 novembre 2005 16.14.39

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
ALTER TABLE dbo.Utenti ADD
	SuperUser bit NOT NULL CONSTRAINT DF_Utenti_SuperUser DEFAULT 0
GO
COMMIT



-- Object:  View dbo.Bil_Utenti    Script Date: 01/04/2004 14.58.12 
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_Utenti]') )
drop view [dbo].[Bil_Utenti]
GO
CREATE VIEW dbo.Bil_Utenti
AS
SELECT     dbo.SDC_Utenti.CodiceUtenteSDC, dbo.SDC_Utenti.Nome, dbo.SDC_Utenti.Cognome, dbo.SDC_Utenti.Telefono, dbo.SDC_Utenti.Fax, 
                      dbo.SDC_Utenti.Email, dbo.SDC_Utenti.Abilitato, dbo.SDC_Utenti.CodiceFiscale, dbo.SDC_Utenti.ResponsabileAggiornamento, dbo.SDC_Utenti.DN, 
                      dbo.SDC_Utenti.Login, dbo.SDC_Utenti.Pwd, dbo.SDC_Utenti.Lingua, dbo.Utenti.StatoBilateraliUtente, dbo.Utenti.TSModifica,  dbo.Utenti.SuperUser, 
                      dbo.SDC_Utenti.Certificato, dbo.SDC_Utenti.CertificatoFirma
FROM         dbo.SDC_Utenti INNER JOIN
                      dbo.Utenti ON dbo.SDC_Utenti.CodiceUtenteSDC = dbo.Utenti.CodiceUtenteSDC
GO


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  SELECT  ON [dbo].[Bil_Utenti]  TO [public]
GO

GRANT  SELECT  ON [dbo].[Bil_Utenti]  TO [bil_dbo]
GO

GRANT  SELECT  ON [dbo].[Bil_Utenti]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

--   luned� 19 dicembre 2005 15.19.42

BEGIN TRANSACTION
ALTER TABLE dbo.XmlFileDaOperatori
	DROP CONSTRAINT Utenti_XmlFileDaOperatori_FK1
GO
COMMIT
BEGIN TRANSACTION
ALTER TABLE dbo.XmlFileDaOperatori
	DROP CONSTRAINT FK_XmlFileDaOperatori_Operatori
GO
COMMIT
BEGIN TRANSACTION
ALTER TABLE dbo.XmlFileDaOperatori
	DROP CONSTRAINT FK_XmlFileDaOperatori_FileOperatori
GO
COMMIT
BEGIN TRANSACTION
CREATE TABLE dbo.Tmp_XmlFileDaOperatori
	(
	IdFileXml int NOT NULL IDENTITY (1, 1),
	CodiceTipoFile varchar(16) NOT NULL,
	FileFirmato image NULL,
	TSInvio datetime NOT NULL,
	Zippato bit NULL,
	NomeFileUtente varchar(256) COLLATE SQL_Latin1_General_CP1_CS_AS NULL,
	CodiceUtenteSDC varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
	PathFileFirmato varchar(256) COLLATE SQL_Latin1_General_CP1_CS_AS NULL,
	CodiceOperatoreSDC varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
	TSModifica datetime NOT NULL,
	IdFileFA varchar(32) COLLATE SQL_Latin1_General_CP1_CS_AS NULL,
	Issuer varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SerialNumber varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_XmlFileDaOperatori ADD CONSTRAINT
	DF_XmlFileDaOperatori_CodiceTipoFile DEFAULT 'CN' FOR CodiceTipoFile
GO
SET IDENTITY_INSERT dbo.Tmp_XmlFileDaOperatori ON
GO
IF EXISTS(SELECT * FROM dbo.XmlFileDaOperatori)
	 EXEC('INSERT INTO dbo.Tmp_XmlFileDaOperatori (IdFileXml, FileFirmato, TSInvio, Zippato, NomeFileUtente, CodiceUtenteSDC, PathFileFirmato, CodiceOperatoreSDC, TSModifica, IdFileFA, Issuer, SerialNumber)
		SELECT IdFileXml, FileFirmato, TSInvio, Zippato, NomeFileUtente, CodiceUtenteSDC, PathFileFirmato, CodiceOperatoreSDC, TSModifica, IdFileFA, Issuer, SerialNumber FROM dbo.XmlFileDaOperatori TABLOCKX')
GO
SET IDENTITY_INSERT dbo.Tmp_XmlFileDaOperatori OFF
GO
DROP TABLE dbo.XmlFileDaOperatori
GO
EXECUTE sp_rename N'dbo.Tmp_XmlFileDaOperatori', N'XmlFileDaOperatori', 'OBJECT'
GO
ALTER TABLE dbo.XmlFileDaOperatori ADD CONSTRAINT
	XmlFileDaOperatori_PK PRIMARY KEY CLUSTERED 
	(
	IdFileXml
	) ON [PRIMARY]

GO
ALTER TABLE dbo.XmlFileDaOperatori WITH NOCHECK ADD CONSTRAINT
	FK_XmlFileDaOperatori_FileOperatori FOREIGN KEY
	(
	IdFileFA
	) REFERENCES dbo.FileOperatori
	(
	IdFile
	)
GO
ALTER TABLE dbo.XmlFileDaOperatori WITH NOCHECK ADD CONSTRAINT
	FK_XmlFileDaOperatori_Operatori FOREIGN KEY
	(
	CodiceOperatoreSDC
	) REFERENCES dbo.Operatori
	(
	CodiceOperatoreSDC
	)
GO
ALTER TABLE dbo.XmlFileDaOperatori WITH NOCHECK ADD CONSTRAINT
	Utenti_XmlFileDaOperatori_FK1 FOREIGN KEY
	(
	CodiceUtenteSDC
	) REFERENCES dbo.Utenti
	(
	CodiceUtenteSDC
	)
GO
COMMIT


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CheckLoginPwd]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[CheckLoginPwd]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetUnitaContratto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spBilGetUnitaContratto]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetListaSessioniNonChiuse]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetListaSessioniNonChiuse]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spListaOperatori]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spListaOperatori]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportUnitRelate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportUnitRelate]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportVenditeOpAcqIpexPerGiorno]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportVenditeOpAcqIpexPerGiorno]
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCorrispettivi]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportXmlCorrispettivi]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCorrispettivi2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportXmlCorrispettivi2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlTitolari]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportXmlTitolari]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlTitolari2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportXmlTitolari2]
GO

CREATE PROCEDURE dbo.CheckLoginPwd
-- declare
	@login as varchar(50),
	@pwd as varchar(50),
	@Admin as int
as 

-- sp per fare la login controllando login/pwd
-- si presuppone che l'utente, quando si loga, non faccia troppi errori.
-- 1) prima controllo login/pwd nella tabella degli utenti
-- 2) se non esiste metto @found=0 in modo da far uscire zero righe da tutte le altre query
-- 3) se esiste lascio @found =1 e proseguo con le altre query
-- 4) poi si procede con la relazione utenti/operatori
-- 5) e operatori
-- se in tutte queste ricerche, anche una sola ritorna zero righe, le successive ricerche, essendo condizionate a @found=1
-- ritorneranno zero righe.
-- Ruoli/Funzioni/RuoliFunzioni sono ritornati solo se l'operatore e` logato.
-- Per capire se un utente e` logato e` necessario verificare che le prime tre query riportino almeno un record


--set @login = 'ABIGNOTTI'
--set @pwd = 'watson'
--set @a = 0
--set @d = getdate()

declare @d datetime
set @d = getdate()

declare @ut varchar(16)
declare @found int


set @found = 1


SELECT 
@ut = UT.CodiceUtenteSDC
FROM dbo.Utenti UT
INNER JOIN dbo.SDC_Utenti SUT
ON UT.CodiceUtenteSDC = SUT.CodiceUtenteSDC 
WHERE 
(UT.StatoBilateraliUtente = 1) AND 
(SUT.Abilitato = 1)            and
(SUT.Login = @login)           and
(SUT.Pwd = @pwd)               and
(@found = 1)

if @found = 1 and @@rowcount = 0
	set @found = 0

SELECT 
UT.CodiceUtenteSDC, 
SUT.Certificato, 
SUT.Login, 
SUT.Pwd, 
SUT.Lingua 
FROM dbo.Utenti UT
INNER JOIN dbo.SDC_Utenti SUT
ON UT.CodiceUtenteSDC = SUT.CodiceUtenteSDC 
WHERE 
(UT.CodiceUtenteSDC = @ut) and
(@found = 1)

if @found = 1 and @@rowcount = 0
	set @found = 0


-- trovo tutti gli operatori che possono lavorare per l'utente
-- daRelOperatoriUtenti.SelectCommand.Parameters("@d").Value = DateTime.Now.Date
-- daRelOperatoriUtenti.SelectCommand.Parameters("@a").Value = (loginType = loginType.Admin)
-- daRelOperatoriUtenti.Fill(ds.RelOperatoriUtenti)
SELECT 
R.CodiceUtenteSDC, 
R.CodiceOperatoreSDC, 
R.TSIniValidita, 
R.TSEndValidita, 
R.CodiceRuolo, 
R.TSModifica, 
R.Amministratore 
FROM dbo.RelOperatoriUtenti R
WHERE 
(R.Abilitato = 1)       AND 
(R.TSIniValidita <= @d) AND 
(R.TSEndValidita >= @d) AND 
(R.Amministratore = @Admin) AND
(R.CodiceUtenteSDC = @ut) and
(@found = 1)

if @found = 1 and @@rowcount = 0
	set @found = 0



-- daOperatori.Fill(ds.Operatori)
SELECT 
OP.StatoBilateraliOperatore, 
SOP.Abilitato, 
OP.CodiceOperatoreSDC, 
OP.Amministratore, 
SOP.RagioneSociale 
FROM dbo.Operatori OP

INNER JOIN dbo.SDC_Operatori SOP on
(SOP.CodiceOperatoreSDC = OP.CodiceOperatoreSDC) and
(SOP.Abilitato = 1)

INNER JOIN dbo.RelOperatoriUtenti R on
(R.Abilitato = 1)         AND 
(R.TSIniValidita <= @d)   AND 
(R.TSEndValidita >= @d)   AND 
(R.Amministratore = @Admin)   and
(R.CodiceUtenteSDC = @ut) and
(R.CodiceOperatoreSDC = OP.CodiceOperatoreSDC) 

WHERE 
(OP.StatoBilateraliOperatore = 1) and
(@found = 1)

if @found = 1 and @@rowcount = 0
	set @found = 0


-- daRuoli.Fill(ds.Ruoli)
SELECT 
CodiceRuolo, 
DescrizioneRuolo, 
TSModifica 
FROM dbo.Ruoli
where
(@found = 1)
 
-- daFunzioni.Fill(ds.Funzioni)
SELECT 
CodiceFunzione, 
DescrizioneFunzione, 
TSModifica 
FROM dbo.Funzioni
where
(@found = 1)
 
-- daRuoliFunzioni.Fill(ds.RuoliFunzioni)
SELECT 
CodiceFunzione, 
CodiceRuolo, 
TSModifica 
FROM dbo.RuoliFunzioni
where
(@found = 1)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[CheckLoginPwd] TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[CheckLoginPwd]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



CREATE  PROCEDURE [dbo].[spBilGetUnitaContratto] 
@di		datetime = null,
@df		datetime = null,
@IdContratto 	int,
@InValidita	bit
AS

declare @tm 		datetime,
	@dtInizioVal	datetime,
	@dtFineVal 	datetime

select 	@dtInizioVal = DataInizioValidita,
	@dtFineVal = DataFineValidita
from Contratto
where IdContratto = @IdContratto

if @InValidita = 0 -- uso le date indicate se non sono nulle, se no uso le date inizio e fine validita` del contratto indicato
begin
	set	@dtInizioVal = isnull(@di, @dtInizioVal)
	set	@dtFineVal = isnull(@df, @dtFineVal)
end

set @tm = getdate()

SELECT     	BU.CodiceUnitaSDC,
		BU.CategoriaUnitaSDC,
		BU.NomeUnita,
		BU.TipoUnita,
		BU.SottotipoUnita,
		BU.CoefficientePerdita,
		BU.CodicePuntoDiScambioRilevanteSDC,
		BU.PotenzaMassimaMWh,
		BU.PotenzaMinimaMWh,
		BU.OrdineDiMerito,
		BU.CodiceOperatoreDiRiferimentoSDC,
		BU.Abilitata,
		BU.ResponsabileAggiornamento,
		BU.StatoBilateraliUnita,
		BU.Unita_TSModifica,
		BU.SDC_Unita_TSModifica,
		BU.CodiceZonaSDC,
		BU.UnbalancedParticipantNumber,
		BU.MgpEnabled,
		UC.IdContratto,
		UC.DataInizioValidita,
		UC.DataFineValidita,
	             UC.TSModifica,
		UC.DataInizioValiditaUnita, -- validita` dell'unita` nel contratto (unit relate)
		UC.DataFineValiditaUnita,  -- validita` dell'unita` nel contratto (unit relate)
		UC.UnitaDelContrattoValidata,
		UC.UnitaAssegnataOpCedente,
		UC.UnitaAssegnataOpAcquirente,
		UC.PrioritaBilanciamentoForzato,
		UC.TrCC,
		UC.TrUC,
		UC.VUC
FROM        Bil_Unita BU
INNER JOIN tab_UnitaContratto5(@dtInizioVal, @dtFineVal, @tm, @IdContratto) UC 
ON BU.CodiceUnitaSDC = UC.CodiceUnitaSDC AND
      BU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
WHERE UC.DataInizioValiditaUnita <=@dtFineVal and UC.DataFineValiditaUnita >=@dtInizioVal
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[spBilGetUnitaContratto]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spBilGetUnitaContratto]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



CREATE  PROCEDURE dbo.spGetListaSessioniNonChiuse
	@di as datetime,
	@df as datetime
AS


--declare @di as datetime
--declare @df as datetime
--set @di = '1/1/2005'
--set @df = '2/2/2005'


create table #tmp
(
	DataProgramma dateTime
)

declare @d as datetime
set @d = @di
while (@d <= @df)
begin
	insert #tmp (DataProgramma) values (@d)
	set @d = dateadd(day, 1, @d)
end


select 
DataProgramma
from #tmp
where DataProgramma not in 
(
	select DataProgramma 
	from SessioneBilaterali 
	where
	DataProgramma >= @di and
	DataProgramma <= @df and 
	DataChiusuraMGP is not null
)
order by DataProgramma

drop table #tmp

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


GRANT  EXECUTE  ON [dbo].[spGetListaSessioniNonChiuse]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spGetListaSessioniNonChiuse]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.spListaOperatori
as
-- set nocount

	select
	Codice      = '' ,
	Descrizione = ''

union

	select 
	Codice      = OP.CodiceOperatoreSDC,
	Descrizione = RagioneSociale + ' - ' + OP.CodiceOperatoreSDC
	from 
	Operatori OP
	
	inner join SDC_Operatori SO 
	on OP.CodiceOperatoreSDC = SO.CodiceOperatoreSDC
	
	where
	
	SO.Abilitato = 1
	and OP.StatoBilateraliOperatore = 1
	

order by Descrizione
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


GRANT  EXECUTE  ON [dbo].[spListaOperatori]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spListaOperatori]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.spReportUnitRelate 
	-- le ur valide per una data di flusso
	@dtFlusso datetime = null,
	
	-- le ur valide da una data di ricerca in poi
	@dtRicerca datetime = null,
	
	-- le ur di uno specifico operatore
	@op varchar(16) = null,
	
	-- le ur di uno specifica unita
	@un varchar(16) = null

AS

set nocount on

--set @op = 'GRTNCIP6'
--set @un = 'UC_DP0062_SUD'
--set @dtFlusso = '3/4/2005'

select 

CodiceUnita         = UR.CodiceUnitaSDC,
DescrUnita          = UN.NomeUnita,
TipoUnita           = UN.TipoUnita,
UnitaEstera         = case Z.Type when 'VIRT' then 1 else 0 end,
AbilitataMGP        = UR.VUC,
AbilitataBilaterali = UR.TrUC,
CodiceOpRif         = UN.CodiceOperatoreDiRiferimentoSDC,
DescrOpRif          = OPRIF.RagioneSociale,

CodiceOperatore     = UR.CodiceOperatoreSDC,
DescrOperatore      = OP.RagioneSociale,
DataInizioValidita  = UR.DataInizioValidita,
DataFineValidita    = UR.DataFineValidita,
AbilitataUR         = UR.Abilitata

from 
unitRelate UR

inner join SDC_Operatori OP
on OP.CodiceOperatoreSDC = UR.CodiceOperatoreSDC

inner join SDC_Unita UN
on UN.CodiceUnitaSDC = UR.CodiceUnitaSDC

inner join SDC_Operatori OPRIF
on OPRIF.CodiceOperatoreSDC = UN.CodiceOperatoreDiRiferimentoSDC

inner join SDC_PuntiDiScambioRilevanti PSR
on PSR.CodicePuntoDiScambioRilevanteSDC = UN.CodicePuntoDiScambioRilevanteSDC

inner join SDC_Zone Z
on Z.CodiceZonaSDC = PSR.CodiceZonaSDC

where 
	-- le UR che sono valide alla data di flusso @dtFlusso
    UR.DataInizioValidita <= coalesce(@dtFlusso, UR.DataInizioValidita)
and UR.DataFineValidita   >= coalesce(@dtFlusso, UR.DataFineValidita)

	-- le UR che sono valide a partire da una data
and UR.DataFineValidita   >= coalesce(@dtRicerca, UR.DataFineValidita)

and UR.CodiceOperatoreSDC = coalesce(@op, UR.CodiceOperatoreSDC)
and UN.CodiceUnitaSDC     = coalesce(@un, UN.CodiceUnitaSDC)

order by UR.CodiceUnitaSDC, 
-- UR.CodiceOperatoreSDC
OP.RagioneSociale
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



GRANT  EXECUTE  ON [dbo].[spReportUnitRelate]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spReportUnitRelate]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE dbo.spReportVenditeOpAcqIpexPerGiorno
	@di as datetime,
	@df as datetime
AS


set transaction isolation level read uncommitted

--declare @di as datetime
--declare @df as datetime
--set @di = '1/1/2005'
--set @df = '2/2/2005'

select DataProgramma
from SessioneBilaterali
where
DataProgramma >= @di and
DataProgramma <= @df and 
DataChiusuraMGP is null



select 
OP.CodiceOperatoreSDC CodiceOperatore,
OP.RagioneSociale     RagioneSociale,
PO.DataProgramma      Data,
sum(PO.SbilMGPalCP)   QuantitaVendute

from 
ProgrammaOrario PO

inner join Contratto C
on PO.IdContratto = C.IdContratto

inner join SDC_Operatori OP
on OP.CodiceOperatoreSDC = C.CodiceOperatoreSDCAcquirente

where 
PO.DataProgramma >= @di
and PO.DataProgramma <= @df
and PO.IsGMEOp = 1 -- qui considero i contratti per cui OpAcquirente e` IPEX
and PO.SbilMGPalCP is not null
and PO.SbilMGPalCP > 0

group by 
OP.CodiceOperatoreSDC,
OP.RagioneSociale,
PO.DataProgramma
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


GRANT  EXECUTE  ON [dbo].[spReportVenditeOpAcqIpexPerGiorno]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spReportVenditeOpAcqIpexPerGiorno]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE spReportXmlCorrispettivi
	@DataProgrammaMin as smalldatetime,
	@DataProgrammaMax as smalldatetime,
	@Transitorio as int
AS
-- vecchia versione non piu` usata


-- e` un report da fare A FINE MERCATO

-- le quantita` trattate sono correttamente roundate e i dati restituiti hanno
-- il corretto numero di digit significativi

-- ATTENZIONE:
-- alcune colonne di questa query escono castate a decimal(x, scale).
-- L'impostazione di scale viene usata per stabilire quante cifre decimali
-- sono necessarie nel report XML dei corrispettivi !!! (quando arriva l'SqlDecimal dal 
-- SqlDataReader leggo lo Scale per costruire al volo la maschera che verra`
-- utilizzata per il toString)
--
-- Notare che:
-- select cast(1.123456 as decimal(15,3)) ritorna 1.123
-- select round(cast(1.123456 as decimal(15,6)),3 ritorna 1.123000
-- 
-- Dunque quando si fanno i calcoli e` importante fare o cast o round
-- (es Qty * Prezzo) per ottenere un numero
-- e poi in uscita dalla query fare cast(xx, scale) con lo scale opportuno

select
POU.DataProgramma,
POU.CodiceOperatoreSDC,
POU.CRN,
POU.CodiceContratto,
POU.CodiceUnitaSDC,
POU.CategoriaUnitaSDC,
POU.PeriodoRilevante,
POU.TipoUnita,
cast(POU.PrezzoUnico  as decimal(19, 6)) as PrezzoUnico,   -- il prezzo unico  e` a 6 cifre
cast(POU.PrezzoZonale as decimal(19, 6)) as PrezzoZonale,  -- il prezzo zonale e` a 6 cifre
cast(QtyMGP as decimal(16,3)) Qty, -- la quantita` in MWh e` a 3 cifre

-- qui si ha:
-- QtyMGP>0 per P
-- QtyMGP<0 per C
-- QtyMGP>0 per M che producono
-- QtyMGP<0 per M che consumano

cast(
	case @Transitorio 
	when 1 then 
		-- caso per i programmi di sola produzione ossia con contratti sbilanciati ammessi
		case TipoUnita 
		when 'P' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2) 
		when 'C' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2)  
		when 'M' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2)  
		end
	else 
		-- caso per i programmi di produzione/consumo ossia con contratti bilanciati
		case TipoUnita 
		
		when 'P' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoZonale,6), 2)
		when 'C' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoUnico, 6), 2)
		when 'M' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoZonale,6), 2)
		end 
	end
	as decimal(16, 2)) Corr  -- gli euro dei corrispettivi escono in centesimi (e nel report XML Corrispettivi saranno a 2 cifre  - come sta scritto qui! se ci fosse un ,3 avremmo 3 cifre nel xml)

from 
(
select 
ProgrammaOrarioPerUnita.DataProgramma,
Contratto.CodiceOperatoreSDC,
Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita / SDC_Unita.CoefficientePerdita QtyMGP,
SDC_Unita.TipoUnita,
SDC_Unita.CoefficientePerdita KU, 
SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP,
SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,

PrezzoUnitario.Prezzo PrezzoUnico,
PrezzoZonale.Prezzo PrezzoZonale

from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

where 
not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
and ProgrammaOrarioPerUnita.DataProgramma >= @DataProgrammaMin
and ProgrammaOrarioPerUnita.DataProgramma <= @DataProgrammaMax
--and ProgrammaOrarioPerUnita.IdContratto = Contratto.IdContratto
) POU
order by 
POU.DataProgramma,
POU.CodiceOperatoreSDC,
POU.CRN,
POU.CodiceUnitaSDC,
POU.PeriodoRilevante

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.spReportXmlCorrispettivi2
@DataFlusso as datetime

AS

-- qui non si usa read uncommitted perche` si calcolano 
-- i soldi. Si preferisce usare dati consolidati


--declare @DataFlusso as smalldatetime
--set @DataFlusso = '1/1/2004'


-- Corrispettivi CCT/CSP per data
----------------------------------------------------------------------------
-- Siccome le formule sono complicate e "instabili"
-- si sceglie di fare calcoli e accorpamenti in C#
-- piuttosto che direttamente il SQL.
-- Questa scelta comporta che il codice in C# dovra` essere facilmente
-- upgradabile (ossia senza una distribuzione da fare)

----------------------------------------------------------------------------
-- Dopo non pochi travagli dovuti al fatto che le formule 
-- "standard" dei CCT e CSP non sono
-- corrette quando le unita` miste che consumano pagano il prezzo zonale,
-- B.D. ci comunica il 11/11/04 che, dato che i pompaggi non dovrebbero
-- essere usati in NAB, il problema non si pone.
-- 
-- Procediamo con le "solite" formule:
-- CCT = Sommatoria per le unita` che producono di (Qp(Pun-Pz)) ove Pz e` il prezzo
--       zonale della zona dove risiede l'unita` che produce Qp. Qp al clearing point.
--       Somm(Qp(Pun-Pz))
-- CSP = (Somm(Qc) - Somm(Qp))Pun
--       dato che Qc e` nel DB segnata la formula per noi e` 
--       (Somm(-Qc) - Somm(Qp))Pun   e con brillanti passaggi
--       (-Somm(Qc) - Somm(Qp))Pun   e ripetendo ancora
--       -(Somm(Q))Pun               dove Q e` indifferentemente unita di produzione/consumo al clearing point
--
-- Questa query riporta la lista delle unita` con quantita` associata (dunque che hanno visto il mercato).
-- Per ogni unita` si tenta di calcolare il contributo della stessa al CCT e al CSP.
-- Il CCT per unita` deve essere 0 per le unita` che consumano o Qp(Pun-Pz) per quelle che producono.
-- Il CSP per unita` deve essere -Q*Pun
--
--
-- Le formule definitive dovrebbero essere:
-- ipotesi iniziale la produzione si ripartisce in maniera proporzionale
-- alle unita` di consumo: ogni unita` di consumo viene rapportata ad una produzione
-- Qptot*Qc/Qctot (e` proporzionale al consumo dell'unita` diviso al consumo totale nel contratto)
--
-- Le formule riportate qui sotto tengono conto di possibili unita`
-- che consumano al prezzo zonale (e in generale sono valide per ogni unita` Qx che
-- ha associato un prezzo Px)
-- CCT = Sommp(Qp(Pun-Pp)) + Qptot(Sommc(Kc(Pc-Pun)))
-- CSP = Sommc(PcQc) - Sommp(QpPun) - Qptot(Sommc(Kc(Pc-Pun)))
-- dove:
-- Sommp = sommatoria per tutte le unita` che producono energia
-- Sommc = sommatoria per tutte le unita` che consumano energia
-- Qp    = quantita` energia prodotta
-- Qc    = quantita` energia consumata
-- Pp    = prezzo associato alla Qp
-- Pc    = prezzo associato alla Qc
-- Qptot = totale energia prodotta nel contratto
-- Kc    = Qc/Qctot --> indica la percentuale(/100) del consumo di quella unita per il contratto
-- Qctot = totale enbergia consumanta nel contratto
-- Notare che se Pc e` sempre Pun le formule si semplificano alle formule "storiche".
-- Se esiste una unita` di consumo con prezzo diverso da Pun interviene in entrambi le
-- formule un fattore per "bilanciare" il CCT e il CSP.
-- Notare infine che 
-- la formula del CCT e` scomponibile per unita` di produzione, nel senso che e` possibile
-- individuare un contributo per unita` di produzione al CCT.
-- CCTp = Qp(Pun-Pp) + Qp(Sommc(Kc(Pc-Pun)))   --> CCT per unita` di produzione
-- il CSP invece, mi sembra, non sia facilmente scomponibile per unita`, dato che dipende sia dalle
-- unita` che consumano che da quelle che producono: questa caratteristica rende il CSP non facilmente
-- giustificabile agli occhi dell'acquirente dato che vige il riserbo sulle unita` utilizzate dalla
-- controparte.
-- Dal punto del GRTN invece il CSP si puo` scomporre in:
-- CSPc = PcQc - Qptot(Sommc(Kc(Pc-Pun))) per le unita Qc
-- CSPp = QpPun                           per le unita Qp



select 
Contratto.CodiceOperatoreSDC             OpResp,
Contratto.CodiceOperatoreSDCAcquirente   OpAcq,
OpAcquirente.IsGMEOp                     OpAcqIsGmeOp,

Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

SDC_Unita.TipoUnita,
SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,

PrezzoUnitario.Prezzo PrezzoUnico,   
PrezzoZonale.Prezzo   PrezzoZonale,  

ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,
SDC_Unita.CoefficientePerdita                       KU,
SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita   KP

from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

inner join Operatori OpAcquirente
on Contratto.CodiceOperatoreSDCAcquirente = OpAcquirente.CodiceOperatoreSDC

where 
not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
and ProgrammaOrarioPerUnita.DataProgramma = @DataFlusso

order by 
Contratto.CRN,
ProgrammaOrarioPerUnita.PeriodoRilevante

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi2]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi2]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





CREATE PROCEDURE spReportXmlTitolari
	@DataProgramma as smalldatetime
AS
-- set @DataProgramma = '20/4/04'

-- codice per capire quante ore fa il giorno in ingresso: 23/24/25
declare @NextDateMonth as integer
declare @Ore as integer
set @NextDateMonth= DATEPART(month,@DataProgramma + 7)
set @Ore = 24
if (month(@DataProgramma) = 3  and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 4)
	set @Ore = 23
if (month(@DataProgramma) = 10 and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 11)
	set @Ore = 25


-- questa semplice select
-- ritorna per PeriodoRilevante/Contratto/Zona la somma dell'energia delle unita` (applicando i coeff. di perdita)
-- di tipo C, P ed M.
-- Inoltra ritorna 
-- Il codice del titolare (resp. partite economiche del contratto)
-- Il/i prezzi unico/zonali
-- Il periodo rilevante
-- l'IdContratto che si trova in PO.
--
-- Performance: agisce nell'ordine corretto aggregando solo alla fine e tramite indice
-- le tabelle PO e POU... meglio di cosi` non si puo`.
--

select
Z.CRN,                        -- varia per contratto
Z.CodiceOperatoreSDCTitolare, -- varia per contratto
Z.PeriodoRilevante,           -- varia per contratto/periodo rilevante
Z.CodiceZonaSDC,              -- varia per contratto/periodo rilevante/zona
Z.POIdContratto,              -- non varia per Contratto/Data/PR/Zona/TipoUnita --> posso usarla nel group by
Z.ProgrammaOrarioValidato,    -- come sopra
Z.PrezzoZonale,               -- varia per zona/periodo rilevante
Z.PrezzoUnico,                -- varia per periodo rilevante

sum(case Z.TipoUnita when 'P' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyP,
sum(case Z.TipoUnita when 'C' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyC,
sum(case Z.TipoUnita when 'M' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyM

from
(
	-- questa select produce record distinti
	-- per contratto/PeridoRilevante/Zona/TipoUnita
	-- se POIdContratto e` NULL significa che il contratto per quel PR non ha programmazione
	-- se POIdContratto <> NULL e ProgrammaOrarioValidato e` 1 significa che il contratto ha generato offerte
	-- se POIdContratto <> NULL e ProgrammaOrarioValidato e` 0 significa che il contratto e` stato disabilitato per generare offerte
	select
	UC.CRN,
	UC.CodiceOperatoreSDCTitolare,
	PR.PeriodoRilevante,
	UC.CodiceZonaSDC,
	UC.TipoUnita,
	PO.IdContratto POIdContratto,  -- non varia per Contratto/Data/PR/Zona/TipoUnita --> posso usarla nel group by
	PO.ProgrammaOrarioValidato,
	sum(round(IsNull(POU.QtyMWhAssegnataMGP,0) * UC.KP / UC.KU,3)) QtyMWhPerZonaTipoUnita, -- QtyMWh dopo i coeff di perdita
	PrezzoZonale.Prezzo   PrezzoZonale,
	PrezzoUnitario.Prezzo PrezzoUnico
	from 
	(
		-- ottengo quante ore ci sono nella data in ingresso (@DataProgramma)
		select 
		Ora PeriodoRilevante 
		from Ore
		where Ora <= @Ore
	) PR
	cross join -- prodotto cartesiano
	(
		-- questa select trova tutte i contratti/unita da programmare in un dato giorno
		-- Poi con un po' di join ritorna anche il TipoUnita, coeff/ perdita ecc.
		-- Incrociando poi i dati di questa select con la tabella PR
		-- si ottiene la lista dei contratti/unita/periodi_rilevanti da programmare
		select 
		Contratto.IdContratto,
		Contratto.CRN,
		Contratto.CodiceOperatoreSDC CodiceOperatoreSDCTitolare,
		UnitaContratto.CodiceUnitaSDC,
		UnitaContratto.CategoriaUnitaSDC,
		UnitaContratto.UnitaAssegnataOpAcquirente,
		UnitaContratto.UnitaAssegnataOpCedente,
		SDC_Unita.TipoUnita,
		SDC_Unita.CoefficientePerdita KU,
		SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP
		from Contratto
		inner join tab_UnitaContratto(@DataProgramma) UnitaContratto on 
			Contratto.StatoContratto='Abilitato'
			and Contratto.DataInizioValidita <= @DataProgramma
			and Contratto.DataFineValidita >= @DataProgramma
			and Contratto.TrCN = 1
			and Contratto.IdContratto = UnitaContratto.IdContratto
			and UnitaContratto.UnitaDelContrattoValidata = 1
			and UnitaContratto.TrCC = 1
			and UnitaContratto.TrUC = 1
			and UnitaContratto.DataInizioValidita <= @DataProgramma
			and UnitaContratto.DataFineValidita >= @DataProgramma
		inner join SDC_Unita on 
			SDC_Unita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC
			and SDC_Unita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC
		inner join SDC_PuntiDiScambioRilevanti on
			SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
	) UC
	inner join PrezzoZonale	on -- il prezzo zonale dipende dal PeriodoRilevante (non posso mettere questa join dentro UC)
		PrezzoZonale.Data = @DataProgramma
		and PrezzoZonale.PeriodoRilevante=PR.PeriodoRilevante
		and PrezzoZonale.CodiceZonaSDC = UC.CodiceZonaSDC
	inner join PrezzoUnitario on -- il prezzo unico dipende dal PeriodoRilevante (non posso mettere questa join dentro UC)
		PrezzoUnitario.Data = @DataProgramma
		and PrezzoUnitario.PeriodoRilevante=PR.PeriodoRilevante
	left outer join -- se non esistono i record in PO per il contratto/data/ora ritorna NULL
	(
		-- qui trovo tutti i PO a prescindere se sono o no validati.
		-- in questo modo se non esiste programmazione per un contratto/data/pr
		-- PO.IdContratto (dopo la left join) sara` NULL
		-- se invece esiste avro` PO.IdContratto<>NULL con PO.ProgrammaOrarioValidato 
		-- a 1 se il programma ha generato offerte o 0 altrimenti
		select
		IdContratto,
		PeriodoRilevante,
		ProgrammaOrarioValidato
		from
		ProgrammaOrario
		where 
		DataProgramma=@DataProgramma
	) PO
	on -- metto in relazione la chiave di PO con UC/PR (escludo DataProgramma dato che e` gia` filtrata)
		PO.IdContratto = UC.IdContratto
		and PO.PeriodoRilevante = PR.PeriodoRilevante
	left outer join -- se non esistono i record in POU per il contratto/data/ora/Unita ritorna NULL
	(
		-- qui trovo tutti i POU ma solo quelli validati
		-- e non QtyMWhAssegnataMGP valorizzata della data in ingresso.
		-- Se il record del un Contratto/Data/PR/Unita non esiste (perche` o non c'e` o non e` validato o non e` valorizzato)
		-- la left join produrra` tutti valori NULL
		select
		IdContratto,
		QtyMWhAssegnataMGP,
		ProgrammatoDalCedente,
		PeriodoRilevante,
		CodiceUnitaSDC,
		CategoriaUnitaSDC
		from 
		ProgrammaOrarioPerUnita
		where 
		DataProgramma=@DataProgramma
		and ProgOrarioDellUnitaValidato=1
		and not QtyMWhAssegnataMGP is null
	) POU
	on  -- metto in relazione la chiave di POU con UC/PR (escludo DataProgramma dato che e` gia` filtrata)
		POU.IdContratto = UC.IdContratto
		and POU.PeriodoRilevante = PR.PeriodoRilevante
		and POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
		and POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
	group by  -- aggrego per sommare le Qty per tipo unita / zona di un contratto/periodo_rilevante
	UC.CRN,                        -- varia per contratto
	UC.CodiceOperatoreSDCTitolare, -- varia per contratto
	PR.PeriodoRilevante,           -- varia per contratto/periodo rilevante
	UC.CodiceZonaSDC,              -- varia per contratto/periodo rilevante/zona
	UC.TipoUnita,                  -- varia per contratto/periodo rilevante/zona/tipounita
	PrezzoZonale.Prezzo,           -- varia per periodo rilevante/zona
	PrezzoUnitario.Prezzo,         -- varia per zona
	PO.IdContratto,                -- varia per contratto/periodo rilevante
	PO.ProgrammaOrarioValidato     -- varia per contratto/periodo rilevante
)Z
group by 
Z.CRN,                             -- varia per contratto
Z.CodiceOperatoreSDCTitolare,      -- varia per contratto
Z.PeriodoRilevante,                -- varia per contratto/periodo rilevante
Z.CodiceZonaSDC,                   -- varia per contratto/periodo rilevante/zona
Z.PrezzoZonale,                    -- varia per periodo rilevante/zona
Z.PrezzoUnico,                     -- varia per periodo rilevante
Z.POIdContratto,                   -- varia per contratto/periodo rilevante
Z.ProgrammaOrarioValidato          -- varia per contratto/periodo rilevante
order by
Z.CRN,
Z.PeriodoRilevante,
Z.CodiceZonaSDC


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE  PROCEDURE dbo.spReportXmlTitolari2
  	@DataFlusso as smalldatetime
AS

-- qui non usiamo read uncommitted in quanto 
-- i dati da visualizzare nel file XML sono "documenti"
-- e dato che l'elaboarazione e` in batch per cui non dovremmo mai incontrare 
-- dati bloccati in scrittura


-- declare @DataFlusso as datetime
-- set @DataFlusso = '25/11/04'

-- codice per capire quante ore fa il giorno in ingresso: 23/24/25
declare @NextDateMonth as integer
declare @Ore as integer
set @NextDateMonth= DATEPART(month,@DataFlusso + 7)
set @Ore = 24
if (month(@DataFlusso) = 3  and DATEPART(weekday,@DataFlusso) = 8-@@datefirst and @NextDateMonth = 4)
	set @Ore = 23
if (month(@DataFlusso) = 10 and DATEPART(weekday,@DataFlusso) = 8-@@datefirst and @NextDateMonth = 11)
	set @Ore = 25



select 
	PB1.IdContratto,
	PB1.CRN,
	PB1.CodiceOperatoreSDCTitolare,
	PB1.Ora PeriodoRilevante,

	PB2.CodiceZonaSDC,
	PB2.PrezzoZonale,
	PB2.PrezzoUnico,
	IsNull(PB2.Status, 'ProgramNotSent') Status,
	
	PB2.QtyP,
	PB2.QtyC,
	PB2.QtyMP,
	PB2.QtyMC

from
(
	select 
	Contratto.IdContratto,
	Contratto.CRN,
	Contratto.CodiceOperatoreSDC CodiceOperatoreSDCTitolare,
	Ore.Ora 
	from Contratto, Ore
	where
	Contratto.StatoContratto='Abilitato'
	and Contratto.DataInizioValidita <= @DataFlusso
	and Contratto.DataFineValidita >= @DataFlusso
	and Contratto.TrCN = 1
	and Ora <= @Ore
) PB1
left outer join
(
	select
	Q.IdContratto,
	Q.PeriodoRilevante,
	Q.CodiceZonaSDC,
	Q.PrezzoZonale,
	Q.PrezzoUnico,
	Q.Status,
	
	sum(case Q.TipoUnita when 'P'  then (Q.QtyMWhAssegnataMGP * Q.KP / Q.KU) else 0 end) QtyP,
	sum(case Q.TipoUnita when 'C'  then (Q.QtyMWhAssegnataMGP * Q.KP / Q.KU) else 0 end) QtyC,
	sum(case Q.TipoUnita when 'MP' then (Q.QtyMWhAssegnataMGP * Q.KP / Q.KU) else 0 end) QtyMP,
	sum(case Q.TipoUnita when 'MC' then (Q.QtyMWhAssegnataMGP * Q.KP / Q.KU) else 0 end) QtyMC
	
	from 
	(
		select
		POU.IdContratto, 
		POU.PeriodoRilevante,
		case 
			when PO.ProgrammaOrarioValidato is null then 'ProgramNotSent'
			when PO.ProgrammaOrarioValidato = 0 then     'ProgramRefused'
			else 'ProgramAccepted' 
		end Status,  -- varia per Contratto/periodoRilevante
	
		SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
		PrezzoZonale.Prezzo PrezzoZonale,   -- varia per Contratto/periodoRilevante/Zona
		PrezzoUnitario.Prezzo  PrezzoUnico, -- varia per Contratto/periodoRilevante
		
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP, -- varia per Contratto/periodoRilevante/unita`
		SDC_Unita.CoefficientePerdita KU, -- varia per Contratto/periodoRilevante/unita`
		case SDC_Unita.TipoUnita
			when 'P' then 'P'
			when 'C' then 'C'
			when 'M' then 
			case 
				when POU.ProgrammatoDalCedente=1 then 'MP'
				when POU.ProgrammatoDalCedente=0 then 'MC'
				else null
			end
		end TipoUnita, -- varia per Contratto/periodoRilevante/unita`
		
		POU.QtyMWhAssegnataMGP

		from ProgrammaOrarioPerUnita POU

		inner join ProgrammaOrario PO
		on	POU.PeriodoRilevante  = PO.PeriodoRilevante
		and POU.DataProgramma     = PO.DataProgramma
		and POU.IdContratto       = PO.IdContratto

		inner join SDC_Unita 
		on  SDC_Unita.CodiceUnitaSDC    = POU.CodiceUnitaSDC
		and SDC_Unita.CategoriaUnitaSDC = POU.CategoriaUnitaSDC

		inner join SDC_PuntiDiScambioRilevanti 
		on  SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
		
		inner join PrezzoZonale	
		on  PrezzoZonale.Data             = POU.DataProgramma
		and PrezzoZonale.PeriodoRilevante = POU.PeriodoRilevante
		and PrezzoZonale.CodiceZonaSDC    = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC
		
		inner join PrezzoUnitario 
		on  PrezzoUnitario.Data = POU.DataProgramma
		and PrezzoUnitario.PeriodoRilevante = POU.PeriodoRilevante

		where
		POU.DataProgramma = @DataFlusso
		and not POU.QtyMWhAssegnataMGP is null

	) Q
	group by
	Q.IdContratto,
	Q.PeriodoRilevante,
	Q.CodiceZonaSDC,
	Q.PrezzoZonale,
	Q.PrezzoUnico,
	Q.Status
) PB2
on 
PB1.IdContratto = PB2.IdContratto and
PB1.Ora         = PB2.PeriodoRilevante

order by
PB1.CRN,
PB1.PeriodoRilevante,
PB2.CodiceZonaSDC

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari2]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari2]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER  PROCEDURE [dbo].[spBilanciamentoForzato]
	@DataProgramma smalldatetime,
	@SogliaSbilMWh float,
	@AzzeraSbilanciamento bit = 1,
	@RicalcolaBilanciamento bit = 1
AS

-- stored procedure che calcola e memorizza il bilanciamento
-- dei programmi di un dato giorno


-- declare @DataProgramma          smalldatetime
-- declare @SogliaSbilMWh          float
-- declare @AzzeraSbilanciamento   bit
-- declare @RicalcolaBilanciamento bit
-- 
-- set @DataProgramma = '17/9/2004'
-- set @SogliaSbilMWh = 0.001
-- set @AzzeraSbilanciamento = 1
-- set @RicalcolaBilanciamento = 1

-- Nuova delibera
-- sto facendo il bilanciamento forzato.
-- congelo lo stato di GestioneTaglio, IsGMEOp
-- nella tabella PO in modo da avere la "storia" delle scelte effettuate in questa sp.
-- Lo faccio prima del loop con il cursore in quanto
-- devo congelare lo stato di GestioneTaglio, IsGMEOp
-- a prescindere se faccio il taglio forzato o no
--
-- NOTARE che
-- il bilanciamento forzato opera sui programmi con Bilanciato=0
-- nel rispetto dei criteri di flessibilita`: (T P C M opGME)
-- se il bilanciamento forzato non viene effettuato (il contratto es ammette pgm sbilanciati)
-- il campo Bilancito rimane ad 0
-- Dato che prima di iniziare il taglio viene chiamata
-- exec spCalcolaBilanciamento @DataProgramma, @SogliaSbilMWh
-- siamo sicuri che se Bilanciato e`
-- null: il programma NON deve andare a mercato
-- 1: il programma e' bilanciato all'origine
-- 0: il programma non e' bilanciato all'origine
-- Dopo il taglio che porta i programmi con Bilanciato=0 a Bilanciato=1
-- (se questi non hanno la flessibilita` di essere sbilanciati)
-- avremo un po' di programmi con bilanciato=1 e un po' con bilanciato=1
-- ENTRAMBI devono andare a mercato, ossia le offerte devono solo controllare bilanciato<>null

-- Variabile FLAG per verificare se ho tagliato almeno una unita` di un programma da bilanciare in maniera forzosa
declare @programmaBilanciato int 
set @programmaBilanciato = 0

update ProgrammaOrario
set
GestioneTaglio = Q.GestioneTaglio,
IsGMEOp        = Q.IsGMEOp
from ProgrammaOrario PO
inner join
(
	select
	Contratto.IdContratto        IdContratto,
	Contratto.GestioneTaglio     GestioneTaglio,
	IsNull(Operatori.IsGMEOp, 0) IsGMEOp
	from Contratto
	inner join Operatori
	on Contratto.CodiceOperatoreSDCAcquirente = Operatori.CodiceOperatoreSDC
) Q
on 
PO.IdContratto = Q.IdContratto
where 
DataProgramma = @DataProgramma
-- fine nuova delibera

-------------------------------------------------------------------------
-------------------------------------------------------------------------



declare @IdContratto Int
declare @PeriodoRilevante TinyInt
declare @CodiceUnitaSDC varchar(16)
declare @CategoriaUnitaSDC varchar(1)
declare @SbilanciamentoMWh float
declare @QtyMWh float
declare @KU float
declare @KP float
declare @QTogliere float

-- Inizio STR 270: si decide di utilizzare la soglia senza arrotondamento a 3 cifre
-- per non sbagliare metto a 3 cifre la soglia di sbilanciamento
--set @SogliaSbilMWh = round(@SogliaSbilMWh, 3)
-- Fine  STR 270 

-- aggiorno tutti i record di PO
-- per la data in questione.
-- In PO.Bilanciato si ha NULL se quella programmazione, per qualche motivo, non deve essere bilanciata
-- Bilanciato = 1 o Bilanciato = 0
exec spCalcolaBilanciamento @DataProgramma, @SogliaSbilMWh


-- str #272 
-- siccome il calcolo del bilanciamento
-- non annulla piu` il precedente bilanciamento forzato 
-- lo devo fare qui
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where DataProgramma = @DataProgramma
and not QtyMWhBilanciamento is null
-- end str #272

--* MODIFICHE per tagliare un programma quando possiede una unita` di consumo estera
--* Tutto cio` che e` racchiuso in --* indica che la modifica e` per includere queste unita`
--* 
--*---------------------------------------------------------------------
--* Determino i programmi da tagliare
--*---------------------------------------------------------------------
--* sezione per determinare quali contratti tagliare in funzione delle
--* programmazioni esistenti per la data/ora.
--* I contratti da tagliare OBBLIGATORIAMENTE sono
--* quelli che hanno programmato delle unita di consumo estere
--* ( e in futuro le miste )
if Object_Id('tempdb..#ProgrammiDaTagliare') is Not Null
	drop table #ProgrammiDaTagliare

create table #ProgrammiDaTagliare
(
	IdContratto int,
	DataProgramma smalldatetime,
	PeriodoRilevante TinyInt,
	Motivo varchar(10)
)
-- 'T' contratto da tagliare sempre
-- 'N' contratto con operatore acquirente non IPEX
-- 'V' programma con unita` di consumo estera
-- 'M' programma con unita` mista che consuma
-- 'P' programma con produzione maggiore del consumo e gestion 
-- 'C' programma con produzione maggiore del consumo


create unique clustered index #pkProgrammiDaTagliare on #ProgrammiDaTagliare
(
	IdContratto,
	DataProgramma,
	PeriodoRilevante
)

exec ProgrammiDaTagliare @DataProgramma
--* Fine


declare po_cursor cursor local for
	select 
	IdContratto, 
	PeriodoRilevante, 
	SbilanciamentoMWh 
	from 
	ProgrammaOrario
	where 
	Dataprogramma = @DataProgramma 
	and Bilanciato = 0 -- Notare che qui cerco solo i programmi non Bilanciati,
	-- dunque, quando ricerco i record in POU, non devo fare ulteriormente
	-- la join in PO per trovare se il record in e` PO.ProgrammaOrarioValidato
	-- (comunque per sicurezza lo sia fa)

open po_cursor
fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
while @@fetch_status = 0 
begin
	-- print 'IdContratto:' + cast(@IdContratto as varchar) + ' PeriodoRil.:' + str(@PeriodoRilevante)  + ' SbilMWh=' + str(@SbilanciamentoMWh)

	if @AzzeraSbilanciamento = 0
	begin
		-- ATTENZIONE: decurto lo SbilanciamentoMWh della soglia 
		-- (per Produzione tolgo, per Consumo aggiungo)
		-- in modo da ottenere un contratto bilanciato con sbilancio uguale a @SogliaSbilMWh
		-- E` OPINABILE
		if @SbilanciamentoMWh > 0
			set	@SbilanciamentoMWh = @SbilanciamentoMWh - @SogliaSbilMWh
		else
			set	@SbilanciamentoMWh = @SbilanciamentoMWh + @SogliaSbilMWh
	end

	set @programmaBilanciato = 0

	-- print ' SbilMWh(new)=' + str(@SbilanciamentoMWh)
	-- qui trovo la lista delle unita` da decurtare.
	-- L'ordine della select indica di decurtare partendo dall'invio
	-- di programma piu` recente e, a parita` di file, del progressivo piu` grande
	declare pou_cursor cursor local keyset for

		select 
		POU.CodiceUnitaSDC, 
		POU.CategoriaUnitaSDC, 
		POU.QtyMWh,
		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
		from 
		ProgrammaOrarioPerUnita POU

		inner join ProgrammaOrario PO
		on  PO.IdContratto             = POU.IdContratto
		and PO.DataProgramma           = POU.DataProgramma
		and PO.PeriodoRilevante        = POU.PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1

		inner join SDC_Unita
		on  POU.CodiceUnitaSDC    = SDC_Unita.CodiceUnitaSDC
		and POU.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC

		inner join SDC_PuntiDiScambioRilevanti
		on SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC

		inner join Contratto
		on Contratto.IdContratto         = POU.IdContratto
		and Contratto.StatoContratto     = 'Abilitato'
		and Contratto.TrCN               = 1 -- dipende dagli stati degli operatori tit/acq/ced
		and Contratto.DataInizioValidita <= @DataProgramma
		and Contratto.DataFineValidita   >= @DataProgramma

--* Questa parte e` commentata in quanto viene sostituita con la join in #ProgrammiDaTagliare
--*		-- Nuova delibera
--*		-- gli operatori acquirenti devono essere op gme per sopportare pgm sbilanciati
--*		inner join Operatori OPAcq
--*		on Contratto.CodiceOperatoreSDCAcquirente = OPAcq.CodiceOperatoreSDC
--*		and 
--*		(
--*			-- tagliare solo se:
--*			Contratto.GestioneTaglio = 'T' -- il taglio e` da fare sempre
--*			or 
--*			( Contratto.GestioneTaglio = 'P' and @SbilanciamentoMWh > 0 ) -- solo se Prod>Cons
--*			or 
--*			( Contratto.GestioneTaglio = 'C' and @SbilanciamentoMWh < 0 ) -- solo se Cons>Prod
--*			or
--*			( OPAcq.IsGMEOp = 0 or OPAcq.IsGMEOp is null ) -- se l'op non e` del GME
--*		)
--*		-- Fine nuova delibera

		inner join #ProgrammiDaTagliare PT
		on  PT.IdContratto      = POU.IdContratto
		and PT.DataProgramma    = POU.DataProgramma
		and PT.PeriodoRilevante = POU.PeriodoRilevante 
--* fine modifica

		inner join UnitRelate
		on 
		(
			(UnitRelate.CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCCedente    and POU.ProgrammatoDalCedente=1)
			or
			(UnitRelate.CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
		)
		and UnitRelate.CodiceUnitaSDC    = POU.CodiceUnitaSDC
		and UnitRelate.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and UnitRelate.Abilitata = 1  -- non cancellato logicamente
		and UnitRelate.TrUC = 1       -- dipende SOLO da Unita.StatoBilateraliUnita
		and UnitRelate.DataInizioValidita <= @DataProgramma
		and UnitRelate.DataFineValidita   >= @DataProgramma


		where 
		    POU.DataProgramma = @DataProgramma 
		and POU.IdContratto = @IdContratto
		and POU.PeriodoRilevante = @PeriodoRilevante
		and POU.ProgOrarioDellUnitaValidato = 1
		and sign(POU.QtyMWh) = sign(@SbilanciamentoMWh) -- le unita che causano lo sbilanciamento

		order by 
		POU.IdProgrammaXml desc,
		POU.ProgressivoNelProgramma desc

	open pou_cursor
	fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP

	while @@fetch_status = 0
	begin
		set @Qtogliere = round(@SbilanciamentoMWh * @KU / @KP, 3)

		-- ora questa quantita` puo` essere superiore in valore assoluto alla quantita'
		-- dell'unita --> posso azzerare l'unita corrente
		-- per poi riprovarci alla prossima
		If Abs(@Qtogliere) > Abs(@QtyMWh)
		begin
			-- posso togliere solo in parte lo sbilanciamento
			-- togliendo tutta la produzione dell'unita
			set @Qtogliere = @QtyMWh				   -- tolgo tutta la quantita disponibile
			set @SbilanciamentoMWh = @SbilanciamentoMWh - round(@Qtogliere * @KP / @KU, 3)
		end
		else
		begin
			-- qui ho tolto tutto lo sbilanciamento (per definizione)
			set @SbilanciamentoMWh = 0
		end 

		-- Inizio STR 270 - Calcolo la nuova quantita`, se e` minore in valore assoluto di epsilon, la metto a zero e sotto la assegno in ProgrammaOrarioPerUnita.
		-- Prima c'era solo questo update:
		--update 
		--ProgrammaOrarioPerUnita
		--set QtyMWhBilanciamento = @QtyMWh - @Qtogliere
		--where current of pou_cursor


		declare @NewQty float
		set @NewQty = @QtyMWh - @Qtogliere
			
		-- print 'Nuova Qty = ' + str(@QtyMWh - @Qtogliere)

		if Abs(@NewQty) < 0.0005 
		begin
			set @NewQty = 0
		end

		update 
		ProgrammaOrarioPerUnita
--		set QtyMWhBilanciamento = @QtyMWh - @Qtogliere
		set QtyMWhBilanciamento = @NewQty
		where current of pou_cursor

		-- se siamo arrivati qui abbiamo fatto almeno un taglio
		set @programmaBilanciato = @programmaBilanciato + 1
		

		-- Fine  STR 270

		-- esco se ho raggiunto la soglia di sbilanciamento max

		-- notare che:
		-- un contratto prima del calcolo del bilanciamento ha Bilanciato=NULL e SbilanciamentoMWh=NULL
		-- un contratto dopo il calcolo del bilanciamento se bilanciato in origine ha Bilanciato=1 e SbilanciamentoMWh=0
		-- un contratto non bilanciato in origine e prima dell'operazione di taglio ha Bilanciato=0 e SbilanciamentoMWh<>0
		-- un contratto non bilanciato in origine e dopo l'operazione di taglio ha Bilanciato=1 e SbilanciamentoMWh<>0
		-- un contratto che dopo ogni fase ha PO.Bilanciato=NULL indica che non e` valido.
--		Inizio STR 270 - Trattandosi di quantita` float devo controllare con fabs (a-b) < epsilon
--		If Abs(@SbilanciamentoMWh) <= @SogliaSbilMWh
		If Abs(@SbilanciamentoMWh) < 0.0005  --pb ls
--		Fine  STR 270 - Trattandosi di quantita` float devo controllare con fabs (a-b) < epsilon
		begin
			-- print 'Esco'
--			update ProgrammaOrario
--			set bilanciato = 1
--			where 
--			IdContratto = @IdContratto
--			and DataProgramma = @DataProgramma
--			and PeriodoRilevante = @PeriodoRilevante
			break
		end

		fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP
	end

	if (@programmaBilanciato > 0)
	begin
		update ProgrammaOrario
		set bilanciato = 1
		where 
		IdContratto = @IdContratto
		and DataProgramma = @DataProgramma
		and PeriodoRilevante = @PeriodoRilevante
	end

	close pou_cursor
	deallocate pou_cursor

	fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
end

close po_cursor
deallocate po_cursor


update 
SessioneBilaterali
set
Taglio=1
where DataProgramma=@DataProgramma


--*
if Object_Id('tempdb..#ProgrammiDaTagliare') is Not Null
	drop table #ProgrammiDaTagliare
--*
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER  PROCEDURE [dbo].[spBilanciamentoForzatoPerOra]
	@DataProgramma smalldatetime,
	@SogliaSbilMWh float,
	@Ora tinyint,
	@UltimoBilanciamento bit
AS

declare @AzzeraSbilanciamento   bit
declare @RicalcolaBilanciamento bit
set @AzzeraSbilanciamento = 1
set @RicalcolaBilanciamento = 1

declare @programmaBilanciato int
set @programmaBilanciato = 0


-- stored procedure che calcola e memorizza il bilanciamento
-- dei programmi di un dato giorno

-- declare @DataProgramma          smalldatetime
-- declare @SogliaSbilMWh          float
-- declare @AzzeraSbilanciamento   bit
-- declare @RicalcolaBilanciamento bit
-- 
-- set @DataProgramma = '17/9/2004'
-- set @SogliaSbilMWh = 0.001
-- set @AzzeraSbilanciamento = 1
-- set @RicalcolaBilanciamento = 1

-- Nuova delibera
-- sto facendo il bilanciamento forzato.
-- congelo lo stato di GestioneTaglio, IsGMEOp
-- nella tabella PO in modo da avere la "storia" delle scelte effettuate in questa sp.
-- Lo faccio prima del loop con il cursore in quanto
-- devo congelare lo stato di GestioneTaglio, IsGMEOp
-- a prescindere se faccio il taglio forzato o no
--
-- NOTARE che
-- il bilanciamento forzato opera sui programmi con Bilanciato=0
-- nel rispetto dei criteri di flessibilita`: (T P C M opGME)
-- se il bilanciamento forzato non viene effettuato (il contratto es ammette pgm sbilanciati)
-- il campo Bilancito rimane ad 0
-- Dato che prima di iniziare il taglio viene chiamata
-- exec spCalcolaBilanciamento @DataProgramma, @SogliaSbilMWh
-- siamo sicuri che se Bilanciato e`
-- null: il programma NON deve andare a mercato
-- 1: il programma e' bilanciato all'origine
-- 0: il programma non e' bilanciato all'origine
-- Dopo il taglio che porta i programmi con Bilanciato=0 a Bilanciato=1
-- (se questi non hanno la flessibilita` di essere sbilanciati)
-- avremo un po' di programmi con bilanciato=1 e un po' con bilanciato=1
-- ENTRAMBI devono andare a mercato, ossia le offerte devono solo controllare bilanciato<>null

update ProgrammaOrario
set
GestioneTaglio = Q.GestioneTaglio,
IsGMEOp        = Q.IsGMEOp
from ProgrammaOrario PO
inner join
(
	select
	Contratto.IdContratto        IdContratto,
	Contratto.GestioneTaglio     GestioneTaglio,
	IsNull(Operatori.IsGMEOp, 0) IsGMEOp
	from Contratto
	inner join Operatori
	on Contratto.CodiceOperatoreSDCAcquirente = Operatori.CodiceOperatoreSDC
) Q
on 
PO.IdContratto = Q.IdContratto
where 
    DataProgramma = @DataProgramma
and PeriodoRilevante = @Ora
-- fine nuova delibera

-------------------------------------------------------------------------
-------------------------------------------------------------------------



declare @IdContratto Int
declare @PeriodoRilevante TinyInt
declare @CodiceUnitaSDC varchar(16)
declare @CategoriaUnitaSDC varchar(1)
declare @SbilanciamentoMWh float
declare @QtyMWh float
declare @KU float
declare @KP float
declare @QTogliere float

-- Inizio STR 270: si decide di utilizzare la soglia senza arrotondamento a 3 cifre
-- per non sbagliare metto a 3 cifre la soglia di sbilanciamento
--set @SogliaSbilMWh = round(@SogliaSbilMWh, 3)
-- Fine STR 270

-- aggiorno tutti i record di PO
-- per la data in questione.
-- In PO.Bilanciato si ha NULL se quella programmazione, per qualche motivo, non deve essere bilanciata
-- Bilanciato = 1 o Bilanciato = 0
exec spCalcolaBilanciamentoPerOra @DataProgramma, @SogliaSbilMWh, @Ora, @UltimoBilanciamento


-- str #272
-- per prima cosa devo resettare tutti i valori 
-- del precedente bilanciamento forzato
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where 
DataProgramma = @DataProgramma
and PeriodoRilevante = @Ora
and not QtyMWhBilanciamento is null
-- fine str #272



--* MODIFICHE per tagliare un programma quando possiede una unita` di consumo estera
--* Tutto cio` che e` racchiuso in --* indica che la modifica e` per includere queste unita`
--* 
--*---------------------------------------------------------------------
--* Determino i programmi da tagliare
--*---------------------------------------------------------------------


--* sezione per determinare quali contratti tagliare in funzione delle
--* programmazioni esistenti per la data/ora.
--* I contratti da tagliare OBBLIGATORIAMENTE sono
--* quelli che hanno programmato delle unita di consumo estere
--* ( e in futuro le miste )
if Object_Id('tempdb..#ProgrammiDaTagliare') is Not Null
	drop table #ProgrammiDaTagliare

create table #ProgrammiDaTagliare
(
	IdContratto int,
	DataProgramma smalldatetime,
	PeriodoRilevante TinyInt,
	Motivo varchar(10)
)

create unique clustered index #pkProgrammiDaTagliare on #ProgrammiDaTagliare
(
	IdContratto,
	DataProgramma,
	PeriodoRilevante
)

exec ProgrammiDaTagliare @DataProgramma, @Ora
--* Fine



declare po_cursor cursor local for
	select 
	IdContratto, 
	PeriodoRilevante, 
	SbilanciamentoMWh 
	from 
	ProgrammaOrario
	where 
	Dataprogramma = @DataProgramma 
	and PeriodoRilevante = @Ora
	and Bilanciato = 0 -- Notare che qui cerco solo i programmi non Bilanciati,
	-- dunque, quando ricerco i record in POU, non devo fare ulteriormente
	-- la join in PO per trovare se il record in e` PO.ProgrammaOrarioValidato
	-- (comunque per sicurezza lo sia fa)

open po_cursor
fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
while @@fetch_status = 0 
begin
	-- print 'IdContratto:' + cast(@IdContratto as varchar) + ' PeriodoRil.:' + str(@PeriodoRilevante)  + ' SbilMWh=' + str(@SbilanciamentoMWh)

	if @AzzeraSbilanciamento = 0
	begin
		-- ATTENZIONE: decurto lo SbilanciamentoMWh della soglia 
		-- (per Produzione tolgo, per Consumo aggiungo)
		-- in modo da ottenere un contratto bilanciato con sbilancio uguale a @SogliaSbilMWh
		-- E` OPINABILE
		if @SbilanciamentoMWh > 0
			set @SbilanciamentoMWh = @SbilanciamentoMWh - @SogliaSbilMWh
		else
			set @SbilanciamentoMWh = @SbilanciamentoMWh + @SogliaSbilMWh
	end

	-- print ' SbilMWh(new)=' + str(@SbilanciamentoMWh)
	-- qui trovo la lista delle unita` da decurtare.
	-- L'ordine della select indica di decurtare partendo dall'invio
	-- di programma piu` recente e, a parita` di file, del progressivo piu` grande
	declare pou_cursor cursor local keyset for

		select 
		POU.CodiceUnitaSDC, 
		POU.CategoriaUnitaSDC, 
		POU.QtyMWh,
		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
		from 
		ProgrammaOrarioPerUnita POU

		inner join ProgrammaOrario PO
		on  PO.IdContratto = POU.IdContratto
		and PO.DataProgramma = POU.DataProgramma
		and PO.PeriodoRilevante = POU.PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1

		inner join SDC_Unita
		on  POU.CodiceUnitaSDC    = SDC_Unita.CodiceUnitaSDC
		and POU.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC

		inner join SDC_PuntiDiScambioRilevanti
		on SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC

		inner join Contratto
		on  Contratto.IdContratto = POU.IdContratto
		and Contratto.StatoContratto = 'Abilitato'
		and Contratto.TrCN = 1 -- dipende dagli stati degli operatori tit/acq/ced
		and Contratto.DataInizioValidita <= @DataProgramma
		and Contratto.DataFineValidita   >= @DataProgramma


--*		-- Nuova delibera
--*		-- gli operatori acquirenti devono essere op gme per sopportare pgm sbilanciati
--*		inner join Operatori OPAcq
--*		on Contratto.CodiceOperatoreSDCAcquirente = OPAcq.CodiceOperatoreSDC
--*		and 
--*		(
--*			-- tagliare solo se:
--*			Contratto.GestioneTaglio = 'T' -- il taglio e` da fare sempre
--*			or 
--*			( Contratto.GestioneTaglio = 'P' and @SbilanciamentoMWh > 0 ) -- solo se Prod>Cons
--*			or 
--*			( Contratto.GestioneTaglio = 'C' and @SbilanciamentoMWh < 0 ) -- solo se Cons>Prod
--*			or
--*			( OPAcq.IsGMEOp = 0 or OPAcq.IsGMEOp is null ) -- se l'op non e` del GME
--*		)
--*		-- Fine nuova delibera

		inner join #ProgrammiDaTagliare PT
		on  PT.IdContratto      = POU.IdContratto
		and PT.DataProgramma    = POU.DataProgramma
		and PT.PeriodoRilevante = POU.PeriodoRilevante 
--* fine modifica

		inner join UnitRelate
		on 
		(
			(UnitRelate.CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCCedente    and POU.ProgrammatoDalCedente=1)
			or
			(UnitRelate.CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
		)
		and UnitRelate.CodiceUnitaSDC    = POU.CodiceUnitaSDC
		and UnitRelate.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and UnitRelate.Abilitata = 1  -- non cancellato logicamente
		and UnitRelate.TrUC = 1       -- dipende SOLO da Unita.StatoBilateraliUnita
		and UnitRelate.DataInizioValidita <= @DataProgramma
		and UnitRelate.DataFineValidita   >= @DataProgramma


		where 
		    POU.DataProgramma    = @DataProgramma 
		and POU.IdContratto      = @IdContratto
		and POU.PeriodoRilevante = @PeriodoRilevante
		and POU.ProgOrarioDellUnitaValidato = 1
		and sign(POU.QtyMWh) = sign(@SbilanciamentoMWh) -- le unita che causano lo sbilanciamento

		order by 
		POU.IdProgrammaXml desc,
		POU.ProgressivoNelProgramma desc

	open pou_cursor
	fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP

	while @@fetch_status = 0
	begin
		set @Qtogliere = round(@SbilanciamentoMWh * @KU / @KP, 3)

		-- ora questa quantita` puo` essere superiore in valore assoluto alla quantita'
		-- dell'unita --> posso azzerare l'unita corrente
		-- per poi riprovarci alla prossima
		If Abs(@Qtogliere) > Abs(@QtyMWh)
		begin
			-- posso togliere solo in parte lo sbilanciamento
			-- togliendo tutta la produzione dell'unita
			set @Qtogliere = @QtyMWh				   -- tolgo tutta la quantita disponibile
			set @SbilanciamentoMWh = @SbilanciamentoMWh - round(@Qtogliere * @KP / @KU, 3)
		end
		else
		begin
			-- qui ho tolto tutto lo sbilanciamento (per definizione)
			set @SbilanciamentoMWh = 0
		end 

		-- Inizio STR 270 - vedi spBilanciamentoForzato, aggiunto calcolo della nuova quantita` e controllo se minore di epsilon
		-- Prima c'era solo l'update:
		--update 
		--ProgrammaOrarioPerUnita
		--set QtyMWhBilanciamento = @QtyMWh - @Qtogliere
		--where current of pou_cursor
		
		declare @NewQty float
		
		set @NewQty = @QtyMWh - @Qtogliere

		if Abs(@NewQty) < 0.0005
		begin
			set @NewQty = 0
		end

		-- print 'Nuova Qty = ' + str(@QtyMWh - @Qtogliere)

		update 
		ProgrammaOrarioPerUnita
		set QtyMWhBilanciamento = @NewQty
		--set QtyMWhBilanciamento = @QtyMWh - @Qtogliere
		where current of pou_cursor

		set @programmaBilanciato = @programmaBilanciato + 1
		-- Fine   STR 270

		-- esco se ho raggiunto la soglia di sbilanciamento max

		-- notare che:
		-- un contratto prima del calcolo del bilanciamento ha Bilanciato=NULL e SbilanciamentoMWh=NULL
		-- un contratto dopo il calcolo del bilanciamento se bilanciato in origine ha Bilanciato=1 e SbilanciamentoMWh=0
		-- un contratto non bilanciato in origine e prima dell'operazione di taglio ha Bilanciato=0 e SbilanciamentoMWh<>0
		-- un contratto non bilanciato in origine e dopo l'operazione di taglio ha Bilanciato=1 e SbilanciamentoMWh<>0
		-- un contratto che dopo ogni fase ha PO.Bilanciato=NULL indica che non e` valido.
		-- STR 270 - Modificato l'IF che segue, vedi spBilanciamentoForzato
		--If Abs(@SbilanciamentoMWh) <= @SogliaSbilMWh
		If Abs(@SbilanciamentoMWh) < 0.0005
		begin
			-- print 'Esco'
			
			break
		end

		fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP
	end
	
	-- Inizio   STR 270: spostato l'update da prima del break qui sotto, condizionato al contatore delle unita` taglaite
	if @programmaBilanciato > 0 
	begin
		update ProgrammaOrario
		set bilanciato = 1
		where 
		IdContratto = @IdContratto
		and DataProgramma = @DataProgramma
		and PeriodoRilevante = @PeriodoRilevante
	end
	-- Fine   STR 270


	close pou_cursor
	deallocate pou_cursor

	fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
end

close po_cursor
deallocate po_cursor


if @UltimoBilanciamento = 1
begin
	update 

	SessioneBilaterali
	set
	Taglio=1
	where DataProgramma=@DataProgramma
end

--*
if Object_Id('tempdb..#ProgrammiDaTagliare') is Not Null
	drop table #ProgrammiDaTagliare
--*
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



ALTER   PROCEDURE [dbo].[spBilGeneraBus]
	@DataProgramma 	smalldatetime,
	@CodiceOperatoreSDC varchar(16)
AS

-- Questa SP riporta i dati per il report BUS --> meglio farla 
-- lavorare con dati sicuri --> niente Read Uncommitted


-- declare	
-- 	@DataProgramma 	smalldatetime,
-- 	@CodiceOperatoreSDC varchar(16)
-- 
-- set @DataProgramma = '1/12/2004'
-- set @CodiceOperatoreSDC = 'IDGRTNCO'

-- La query e` diretta su POU senza tante complicazioni
-- tipo la validita dele contratto, abilitazioni ecc.
-- perche' se la QtyMWhAssegnataMGP e' valorizzata significa che
-- al momento dell'esecuzione del mercato quella programmazione era
-- valida --> il BUS deve essere generato
SELECT 
-- STR305/4702 SUM(POU.QtyMWhAssegnataMGP) as QtyMWhAssegnataMGP,
SUM(IsNull(POU.QtyMWhAssegnataMGP,0)) as QtyMWhAssegnataMGP,
POU.PeriodoRilevante as PeriodoRilevante,
POU.CodiceUnitaSDC as CodiceUnitaSDC
from
ProgrammaOrarioPerUnita POU
inner join Contratto CO
on
CO.IdContratto = POU.IdContratto
where
-- STR305/4702 POU.QtyMWhAssegnataMGP is not null and
POU.DataProgramma = @DataProgramma
and
(
	(POU.ProgrammatoDalCedente = 1 AND CO.CodiceOperatoreSDCCedente = @CodiceOperatoreSDC) 
	or 
	(POU.ProgrammatoDalCedente = 0 AND CO.CodiceOperatoreSDCAcquirente = @CodiceOperatoreSDC) 
)
GROUP BY 
POU.CodiceUnitaSDC, 
POU.PeriodoRilevante 
ORDER BY 
POU.CodiceUnitaSDC, 
POU.PeriodoRilevante
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER  PROCEDURE [dbo].[spBilGetListaContratti] 
@ricercaValidoDal as bit = 0,
@ricercaValidoAl As bit = 0,
@validoDal as datetime = null,
@validoAl As DateTime = null,
@codiceSDCTitolare as varchar(16) = null,
@ragioneSocialeTitolare as varchar(256) = null,
@statoContratto As varchar(32) = null,
@codiceContratto As varchar(50) =null,
@codiceContrattoGRTN As varchar(30) = null,
@codiceUnitaSDC as varchar(16) = null,
@codiceOpRifUnita  as varchar(16) = null,
@codiceOpCedente as varchar(16) = null,
@codiceOpAcquirente  as varchar(16) = null
AS


set nocount off;
declare @Q as nvarchar(4000),
	@df as datetime,
	@di as datetime

set @Q = ''
set @Q = @Q +  
'SELECT     C.*, 
T.IdContratto, ISNULL(T.TotaleUnita, 0) AS TotaleUnitaContratto, 
ISNULL(T.TotaleUnita, 0) AS UnitaContrattoValidate
FROM         
(
SELECT     *
FROM          dbo.Bil_ContrattoOperatore
WHERE      (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
(dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita))
) C LEFT OUTER JOIN
(
SELECT     IdContratto, COUNT(*) TotaleUnita
FROM          
(SELECT     
IdContratto, 
CodiceUnitaSDC, 
CategoriaUnitaSDC, 
TrCC, 
TrUC, 
VUC, 
SUM(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente, 
SUM(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
FROM          
(SELECT     
c.IdContratto, 
ur.CodiceUnitaSDC, 
ur.CategoriaUnitaSDC, 
ur.TrUC, 
ur.VUC, 
1 UnitaAssegnataOpCedente, 
0 UnitaAssegnataOpAcquirente, 
c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
FROM unitrelate ur 
INNER JOIN
contratto c ON c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente AND ur.TipoUnita IN (''P'', ''M'') 
AND (ur.DataInizioValidita <= c.DataFineValidita AND ur.DataFineValidita >= c.DataInizioValidita)
AND ur.Abilitata = 1 
UNION
SELECT     
c.IdContratto, 
ur.CodiceUnitaSDC, 
ur.CategoriaUnitaSDC, 
ur.TrUC, 
ur.VUC, 
0 UnitaAssegnataOpCedente, 
1 UnitaAssegnataOpAcquirente, 
c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
FROM         
unitrelate ur 
INNER JOIN
contratto c ON c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente AND ur.TipoUnita IN (''C'', ''M'') 
AND (ur.DataInizioValidita <= c.DataFineValidita AND ur.DataFineValidita >= c.DataInizioValidita)
AND ur.Abilitata = 1 
) w
GROUP BY IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC, TrUC, VUC, TrCC) Q
GROUP BY IdContratto) T ON C.IdContratto = T.IdContratto
WHERE     (1 = 1)'


if @ricercaValidoDal = 1 
	set @di = @validoDal
else
	set @di = null

if @ricercaValidoAl = 1 
	set @df = @validoAl
else
	set @df = null

if not @codiceSDCTitolare is null and len(@codiceSDCTitolare) > 0
	set @Q = @Q + ' AND CodiceOperatoreSDC LIKE ''' + @codiceSDCTitolare + ''''

if not @ragioneSocialeTitolare is null and len(@ragioneSocialeTitolare) > 0
	set @Q = @Q + ' AND Titolare_RagioneSociale LIKE ''' + @ragioneSocialeTitolare + ''''

if not @statoContratto is null and len(@statoContratto) > 0 
	set @Q = @Q + ' AND StatoContratto = ''' + @statoContratto + ''''

if not @codiceContratto is null and len(@codiceContratto) > 0 
	set @Q = @Q + ' AND CodiceContratto LIKE ''' + @CodiceContratto + ''''               

if not @codiceContrattoGRTN is null and len(@codiceContrattoGRTN) > 0 
	set @Q = @Q + ' AND CRN LIKE ''' + @codiceContrattoGRTN + ''''  

if @validoDal = @validoAl 
begin
	if not @codiceUnitaSDC is null and len(@codiceUnitaSDC) > 0
		set @Q = @Q +  ' and EXISTS ( 
		 select * 
		 from UnitRelate UR 
		 where UR.Abilitata = 1 
		 and UR.TrUC = 1 
		 and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita) 
		 and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita) 
		 and UR.CodiceUnitaSDC LIKE ''' +
		@codiceUnitaSDC  + '''  and 
		 (
		  (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and UR.TipoUnita <> ''P'')
		  or
		  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and UR.TipoUnita <> ''C'')
		 ) ) '
		 


	If not @codiceOpRifUnita is null and len(@codiceOpRifUnita) > 0
		set @Q = @Q +  ' and EXISTS ( 
		select *
		from SDC_Unita U 
		inner join UnitRelate UR
		on UR.CodiceUnitaSDC = U.CodiceUnitaSDC
		and UR.Abilitata = 1
		and UR.TrUC = 1
		and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita)
		and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita)
		and U.CodiceOperatoreDiRiferimentoSDC LIKE ''' +
		@codiceOpRifUnita + 
		''' where
		( (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> ''P'')
		or
		  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> ''C'') )
		)'
end

if not @codiceOpAcquirente is null and len(@codiceOpAcquirente) > 0
	set @Q = @Q +  ' AND CodiceOperatoreSDCAcquirente LIKE ''' + @codiceOpAcquirente + ''''

if not @codiceOpCedente is null and len(@codiceOpCedente) > 0
	set @Q = @Q +  ' AND CodiceOperatoreSDCCedente LIKE ''' + @codiceOpCedente + ''''

print @Q
--print @di
--print @df


exec sp_executesql @Q,
	N'@di datetime, @df datetime',
  	@di = @di,
  	@df = @df
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


ALTER  PROCEDURE [dbo].[spBilGetListaContrattiClient] 
@codiceSDCTitolare as varchar(16),
@ragioneSocialeTitolare as varchar(256),
@ricercaValidoDal as bit,
@validoDal as datetime,
@ricercaValidoAl As bit,
@validoAl As DateTime,
@statoContratto As varchar(32),
@codiceContratto As varchar(50),
@codiceContrattoGRTN As varchar(30),
@codiceUnitaSDC as varchar(16),
@codiceOpRifUnita  as varchar(16),
@codiceOpCedente as varchar(16),
@codiceOpAcquirente  as varchar(16),
@IdOperatoreLoggato as varchar(16)
AS


set nocount off;

declare @Q as nvarchar(4000),
	@df as datetime,
	@di as datetime,
	@operatore as varchar(16)

set @operatore = @IdOperatoreLoggato

set @Q = ''
set @Q = @Q +  
'SELECT     C.*, T.IdContratto, 
case when C.CodiceOperatoreSDCCedente = @Operatore and C.CodiceOperatoreSDCAcquirente = @Operatore
then isnull(UnAlCed,0) + isnull(UnAlAcq,0)  
when C.CodiceOperatoreSDCCedente = @Operatore
then isnull(UnAlCed,0)
when C.CodiceOperatoreSDCAcquirente = @Operatore
then isnull(UnAlAcq,0)
end TotaleUnitaContratto, 

case when C.CodiceOperatoreSDCCedente = @Operatore and C.CodiceOperatoreSDCAcquirente = @Operatore
then isnull(UnAlCed,0) + isnull(UnAlAcq,0)   
when C.CodiceOperatoreSDCCedente = @Operatore
then isnull(UnAlCed,0)
when C.CodiceOperatoreSDCAcquirente = @Operatore
then isnull(UnAlAcq,0)
end UnitaContrattoValidate
FROM         
(
SELECT     *
FROM          dbo.Bil_ContrattoOperatore
WHERE      (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDCCedente = @Operatore) AND 
      (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
      (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) OR
      (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
      (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) AND 
      (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDCAcquirente = @Operatore) OR
      (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
      (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) AND 
      (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDC = @Operatore)) 
C 
LEFT OUTER JOIN
(
SELECT     IdContratto, 
SUM(UnitaAssegnataOpCedente) UnAlCed,
SUM(UnitaAssegnataOpAcquirente) UnAlAcq
FROM          
(
	SELECT     
	IdContratto, 
	CodiceUnitaSDC, 
	CategoriaUnitaSDC, 
	TrCC, 
	TrUC, 
	VUC, 
	SUM(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente, 
	SUM(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
        FROM          
	(
		SELECT     
		c.IdContratto, 
		ur.CodiceUnitaSDC, 
		ur.CategoriaUnitaSDC, 
		ur.TrUC, 
		ur.VUC, 
		1 UnitaAssegnataOpCedente, 
                0 UnitaAssegnataOpAcquirente, 
		c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
                FROM          
		unitrelate ur INNER JOIN
                contratto c 
		ON c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
		AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
		AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente 
		AND ur.TipoUnita IN (''P'', ''M'') 
		AND (ur.DataInizioValidita <= c.DataFineValidita 
		AND ur.DataFineValidita >= c.DataInizioValidita) 
		AND ur.Abilitata = 1
            	UNION
                SELECT     
		c.IdContratto, 
		ur.CodiceUnitaSDC, 
		ur.CategoriaUnitaSDC, 
		ur.TrUC, 
		ur.VUC, 
		0 UnitaAssegnataOpCedente, 
                1 UnitaAssegnataOpAcquirente, 
		c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
                FROM         unitrelate ur 
		INNER JOIN
		contratto c 
		ON c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
		AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
		AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente 
		AND ur.TipoUnita IN (''C'', ''M'') 
		AND (ur.DataInizioValidita <= c.DataFineValidita 
		AND ur.DataFineValidita >= c.DataInizioValidita) 
		AND ur.Abilitata = 1
	) w
    	GROUP BY IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC, TrUC, VUC, TrCC
 ) Q
  GROUP BY IdContratto
) 
T ON C.IdContratto = T.IdContratto
 WHERE     (1 = 1)'

if @ricercaValidoDal = 1 
	set @di = @validoDal
else
	set @di = null
if @ricercaValidoAl = 1 
	set @di = @validoAl
else
	set @di = null

if not @codiceSDCTitolare is null and len(@codiceSDCTitolare) > 0
	set @Q = @Q + ' AND CodiceOperatoreSDC LIKE ''' + @codiceSDCTitolare + ''''

if not @ragioneSocialeTitolare is null and len(@ragioneSocialeTitolare) > 0
	set @Q = @Q + ' AND Titolare_RagioneSociale LIKE ''' + @ragioneSocialeTitolare + ''''

if not @statoContratto is null and len(@statoContratto) > 0 
	set @Q = @Q + ' AND StatoContratto = ''' + @statoContratto + ''''

if not @codiceContratto is null and len(@codiceContratto) > 0 
	set @Q = @Q + ' AND CodiceContratto LIKE ''' + @CodiceContratto + ''''               

if not @codiceContrattoGRTN is null and len(@codiceContrattoGRTN) > 0 
	set @Q = @Q + ' AND CRN LIKE ''' + @codiceContrattoGRTN + ''''  

if @validoDal = @validoAl 
begin
	if not @codiceUnitaSDC is null and len(@codiceUnitaSDC) > 0
		set @Q = @Q +  ' and EXISTS ( 
		 select * 
		 from UnitRelate UR 
		 where UR.Abilitata = 1 
		 and UR.TrUC = 1 
		 and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita) 
		 and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita) 
		 and UR.CodiceUnitaSDC LIKE  ''' + @codiceUnitaSDC  +
		 ''' and 
		 (
		  (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and UR.TipoUnita <> ''P'')
		  or
		  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and UR.TipoUnita <> ''C'')
		 ) ) '
		 


	If not @codiceOpRifUnita is null and len(@codiceOpRifUnita) > 0
		set @Q = @Q +  ' and EXISTS ( 
		select *
		from SDC_Unita U 
		inner join UnitRelate UR
		on UR.CodiceUnitaSDC = U.CodiceUnitaSDC
		and UR.Abilitata = 1
		and UR.TrUC = 1
		and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita)
		and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita)
		and U.CodiceOperatoreDiRiferimentoSDC LIKE ''' +
		@codiceOpRifUnita + ''' where
		( (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> ''P'')
		or
		  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> ''C'') )
		)'
end

if not @codiceOpAcquirente is null and len(@codiceOpAcquirente) > 0
	set @Q = @Q +  ' AND CodiceOperatoreSDCAcquirente LIKE ''' + @codiceOpAcquirente + ''''


if not @codiceOpCedente is null and len(@codiceOpCedente) > 0
	set @Q = @Q +  ' AND CodiceOperatoreSDCCedente LIKE ''' + @codiceOpCedente + ''''



--print @Q
exec sp_executesql @Q,
	N'@di datetime, @df datetime, @operatore varchar(16)',
  	@di = @di,
  	@df = @df,
	@operatore = @operatore
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


ALTER     PROCEDURE dbo.spBilGetProgrammazione23
	@DataProgramma smalldatetime,
	@CodiceOpAcq varchar(16) = null,
	@CodiceOpCed varchar(16) = null
AS

SET NOCOUNT ON;

set transaction isolation level read uncommitted

SELECT 
IdContratto, 
PeriodoRilevante, 
SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
INTO #tmpCO
FROM programmaorarioperunita
WHERE DataProgramma = @DataProgramma
AND ProgOrarioDellUnitaValidato=1
GROUP BY IdContratto, PeriodoRilevante

select
	PU.IdContratto,
		
  	sum(case PU.PeriodoRilevante when   1 then PU.TotUnitaAssCed else 0 end) 			C01,
  	sum(case PU.PeriodoRilevante when   2 then PU.TotUnitaAssCed else 0 end) 			C02,
  	sum(case PU.PeriodoRilevante when   3 then PU.TotUnitaAssCed else 0 end) 			C03,
  	sum(case PU.PeriodoRilevante when   4 then PU.TotUnitaAssCed else 0 end) 			C04,
  	sum(case PU.PeriodoRilevante when   5 then PU.TotUnitaAssCed else 0 end) 			C05,
	sum(case PU.PeriodoRilevante when   6 then PU.TotUnitaAssCed else 0 end) 			C06,
  	sum(case PU.PeriodoRilevante when   7 then PU.TotUnitaAssCed else 0 end) 			C07,
  	sum(case PU.PeriodoRilevante when   8 then PU.TotUnitaAssCed else 0 end) 			C08,
  	sum(case PU.PeriodoRilevante when   9 then PU.TotUnitaAssCed else 0 end) 			C09,
  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
  	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
  	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
 	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
  	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
  	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
  	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
  	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
  	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
  	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
  	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
  	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
  	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
--  	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,

  	sum(case PU.PeriodoRilevante when   1 then PU.TotUnitaAssAcq else 0 end) 			A01,
  	sum(case PU.PeriodoRilevante when   2 then PU.TotUnitaAssAcq else 0 end) 			A02,
  	sum(case PU.PeriodoRilevante when   3 then PU.TotUnitaAssAcq else 0 end) 			A03,
  	sum(case PU.PeriodoRilevante when   4 then PU.TotUnitaAssAcq else 0 end) 			A04,
  	sum(case PU.PeriodoRilevante when   5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
  	sum(case PU.PeriodoRilevante when   6 then PU.TotUnitaAssAcq else 0 end) 			A06,
  	sum(case PU.PeriodoRilevante when   7 then PU.TotUnitaAssAcq else 0 end) 			A07,
  	sum(case PU.PeriodoRilevante when   8 then PU.TotUnitaAssAcq else 0 end) 			A08,
  	sum(case PU.PeriodoRilevante when   9 then PU.TotUnitaAssAcq else 0 end) 			A09,
 	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
  	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
  	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
  	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
  	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
  	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
  	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
  	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
  	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
  	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
  	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
  	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
--   	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,

 	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end)				B01,
 	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end)				B02,
 	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end)				B03,
 	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end)				B04,
 	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end)				B05,
 	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) 			B06,
 	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) 			B07,
 	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) 			B08,
 	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) 			B09,
 	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) 			B10,
 	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) 			B11,
 	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) 			B12,
 	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) 			B13,
 	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) 			B14,
 	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) 			B15,
 	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) 			B16,
 	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) 			B17,
 	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) 			B18,
 	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) 			B19,
 	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) 			B20,
 	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) 			B21,
 	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) 			B22,
 	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) 			B23,
-- 	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) 			B24,
-- 	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) 			B25,

	PU.CRN,
	PU.CodiceContratto
FROM
(
	SELECT 
	CC.IdContratto, 
	Ore.Ora PeriodoRilevante,
	CC.CRN,
	CC.CodiceContratto,
	Sbilanciamento = case
		when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
		when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
		else
			case sign(PO.SbilanciamentoMWh) 
			when 1 then	 -- eccesso di produzione: 
				case CC.GestioneTaglio
				when 'T' then 5		-- taglia sempre, 'rosso'
				when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
				when 'C' then		-- solo se cons. maggiore prod.
	 				case CC.IsGMEOpAcquirente 
	 					when 1 then 4	-- 'blu'  
	 					when 0 then 3	-- 'arancione' 
	 				end 
				when 'M' then 
					case CC.IsGMEOpAcquirente 
						when 1 then 4   -- 'blu'
						when 0 then 3	-- 'arancione'
					end 
				end
			when -1 then 	-- eccesso di consumo: 
				case CC.GestioneTaglio
				when 'T' then 5		-- 'taglia sempre, rosso'
				when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
				when 'P' then		-- solo se prod. maggiore cons.
					case CC.IsGMEOpCedente
						when 1 then 4	-- 'blu'
						when 0 then 4	-- 'blu', caso praticamente impossibile 
					end 
				when 'M' then
					case CC.IsGMEOpCedente
						when 1 then 4	-- 'blu'
						when 0 then 4	-- 'blu', caso praticamente impossibile 
					end 
				end
			end
		end,
	TotUnitaAssCed = case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end , -- 0 rosso, 1 verde
	TotUnitaAssAcq = case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end 
	FROM
	(
		-- i contratti che dovrebbero essere programmati
		SELECT
		CO.IdContratto,
		CO.CRN,
		CO.CodiceContratto,
		CO.GestioneTaglio,
		OA.IsGMEOp IsGMEOpAcquirente,
		OC.IsGMEOp IsGMEOpCedente
		FROM 
		Contratto CO, 
		Operatori OA,
		Operatori OC
		WHERE   
		    CO.DataInizioValidita <= @DataProgramma
		AND CO.DataFineValidita   >= @DataProgramma
		AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
		AND CO.StatoContratto     = 'Abilitato'
		AND CO.TrCN               = 1
		AND CO.CodiceOperatoreSDCCedente    = COALESCE(@CodiceOpCed, CO.CodiceOperatoreSDCCedente)
		AND CO.CodiceOperatoreSDCAcquirente = COALESCE(@CodiceOpAcq, CO.CodiceOperatoreSDCAcquirente)
	) CC
	CROSS JOIN 
	(
		-- i contratti che dovrebbero essere programmati per 24 ore
		SELECT Ora 
		FROM Ore 
		WHERE Ore.Ora <= 23 -- 23 25
	) Ore
	LEFT OUTER JOIN ProgrammaOrario PO -- per contratto/ora mi tiro su i dati di PO
	ON  PO.IdContratto             = CC.IdContratto
	AND PO.PeriodoRilevante        = Ore.Ora
	AND PO.DataProgramma           = @DataProgramma
	AND PO.ProgrammaOrarioValidato = 1
	LEFT OUTER JOIN -- e per contratto/ora mi tiro su i dati riassuntivi di POU
	(
		SELECT 
		IdContratto, 
		PeriodoRilevante, 
		TotUnitaAssCed,
		TotUnitaAssAcq
		FROM #tmpCO
	) POU
	ON  PO.PeriodoRilevante = POU.PeriodoRilevante
	AND PO.IdContratto      = POU.IdContratto
) PU
GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto
ORDER BY PU.CRN

drop table #tmpCO

RETURN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER   PROCEDURE dbo.spBilGetProgrammazione24
	@DataProgramma datetime,
	@CodiceOpAcq varchar(16) = null,
	@CodiceOpCed varchar(16) = null
AS

SET NOCOUNT ON;

set transaction isolation level read uncommitted

SELECT 
IdContratto, 
PeriodoRilevante, 
SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
INTO #tmpCO
FROM programmaorarioperunita
WHERE DataProgramma = @DataProgramma
AND ProgOrarioDellUnitaValidato=1
GROUP BY IdContratto, PeriodoRilevante

select
	PU.IdContratto,
		
  	sum(case PU.PeriodoRilevante when   1 then PU.TotUnitaAssCed else 0 end) 			C01,
  	sum(case PU.PeriodoRilevante when   2 then PU.TotUnitaAssCed else 0 end) 			C02,
  	sum(case PU.PeriodoRilevante when   3 then PU.TotUnitaAssCed else 0 end) 			C03,
  	sum(case PU.PeriodoRilevante when   4 then PU.TotUnitaAssCed else 0 end) 			C04,
  	sum(case PU.PeriodoRilevante when   5 then PU.TotUnitaAssCed else 0 end) 			C05,
	sum(case PU.PeriodoRilevante when   6 then PU.TotUnitaAssCed else 0 end) 			C06,
  	sum(case PU.PeriodoRilevante when   7 then PU.TotUnitaAssCed else 0 end) 			C07,
  	sum(case PU.PeriodoRilevante when   8 then PU.TotUnitaAssCed else 0 end) 			C08,
  	sum(case PU.PeriodoRilevante when   9 then PU.TotUnitaAssCed else 0 end) 			C09,
  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
  	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
  	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
 	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
  	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
  	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
  	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
  	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
  	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
  	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
  	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
  	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
  	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
  	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,

  	sum(case PU.PeriodoRilevante when   1 then PU.TotUnitaAssAcq else 0 end) 			A01,
  	sum(case PU.PeriodoRilevante when   2 then PU.TotUnitaAssAcq else 0 end) 			A02,
  	sum(case PU.PeriodoRilevante when   3 then PU.TotUnitaAssAcq else 0 end) 			A03,
  	sum(case PU.PeriodoRilevante when   4 then PU.TotUnitaAssAcq else 0 end) 			A04,
  	sum(case PU.PeriodoRilevante when   5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
  	sum(case PU.PeriodoRilevante when   6 then PU.TotUnitaAssAcq else 0 end) 			A06,
  	sum(case PU.PeriodoRilevante when   7 then PU.TotUnitaAssAcq else 0 end) 			A07,
  	sum(case PU.PeriodoRilevante when   8 then PU.TotUnitaAssAcq else 0 end) 			A08,
  	sum(case PU.PeriodoRilevante when   9 then PU.TotUnitaAssAcq else 0 end) 			A09,
 	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
  	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
  	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
  	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
  	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
  	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
  	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
  	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
  	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
  	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
  	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
  	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
   	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,

 	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end)				B01,
 	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end)				B02,
 	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end)				B03,
 	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end)				B04,
 	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end)				B05,
 	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) 			B06,
 	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) 			B07,
 	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) 			B08,
 	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) 			B09,
 	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) 			B10,
 	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) 			B11,
 	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) 			B12,
 	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) 			B13,
 	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) 			B14,
 	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) 			B15,
 	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) 			B16,
 	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) 			B17,
 	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) 			B18,
 	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) 			B19,
 	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) 			B20,
 	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) 			B21,
 	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) 			B22,
 	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) 			B23,
 	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) 			B24,
-- 	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) 			B25,

	PU.CRN,
	PU.CodiceContratto
FROM
(
	SELECT 
	CC.IdContratto, 
	Ore.Ora PeriodoRilevante,
	CC.CRN,
	CC.CodiceContratto,
	Sbilanciamento = case
		when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
		when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
		else
			case sign(PO.SbilanciamentoMWh) 
			when 1 then	 -- eccesso di produzione: 
				case CC.GestioneTaglio
				when 'T' then 5		-- taglia sempre, 'rosso'
				when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
				when 'C' then		-- solo se cons. maggiore prod.
	 				case CC.IsGMEOpAcquirente 
	 					when 1 then 4	-- 'blu'  
	 					when 0 then 3	-- 'arancione' 
	 				end 
				when 'M' then 
					case CC.IsGMEOpAcquirente 
						when 1 then 4   -- 'blu'
						when 0 then 3	-- 'arancione'
					end 
				end
			when -1 then 	-- eccesso di consumo: 
				case CC.GestioneTaglio
				when 'T' then 5		-- 'taglia sempre, rosso'
				when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
				when 'P' then		-- solo se prod. maggiore cons.
					case CC.IsGMEOpCedente
						when 1 then 4	-- 'blu'
						when 0 then 4	-- 'blu', caso praticamente impossibile 
					end 
				when 'M' then
					case CC.IsGMEOpCedente
						when 1 then 4	-- 'blu'
						when 0 then 4	-- 'blu', caso praticamente impossibile 
					end 
				end
			end
		end,
	TotUnitaAssCed = case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end , -- 0 rosso, 1 verde
	TotUnitaAssAcq = case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end 
	FROM
	(
		-- i contratti che dovrebbero essere programmati
		SELECT
		CO.IdContratto,
		CO.CRN,
		CO.CodiceContratto,
		CO.GestioneTaglio,
		OA.IsGMEOp IsGMEOpAcquirente,
		OC.IsGMEOp IsGMEOpCedente
		FROM 
		Contratto CO, 
		Operatori OA,
		Operatori OC
		WHERE   
		    CO.DataInizioValidita <= @DataProgramma
		AND CO.DataFineValidita   >= @DataProgramma
		AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
		AND CO.StatoContratto     = 'Abilitato'
		AND CO.TrCN               = 1
		AND CO.CodiceOperatoreSDCCedente    = COALESCE(@CodiceOpCed, CO.CodiceOperatoreSDCCedente)
		AND CO.CodiceOperatoreSDCAcquirente = COALESCE(@CodiceOpAcq, CO.CodiceOperatoreSDCAcquirente)
	) CC
	CROSS JOIN 
	(
		-- i contratti che dovrebbero essere programmati per 24 ore
		SELECT Ora 
		FROM Ore 
		WHERE Ore.Ora <= 24 -- 23 25
	) Ore
	LEFT OUTER JOIN ProgrammaOrario PO -- per contratto/ora mi tiro su i dati di PO
	ON  PO.IdContratto             = CC.IdContratto
	AND PO.PeriodoRilevante        = Ore.Ora
	AND PO.DataProgramma           = @DataProgramma
	AND PO.ProgrammaOrarioValidato = 1
	LEFT OUTER JOIN -- e per contratto/ora mi tiro su i dati riassuntivi di POU
	(
		SELECT 
		IdContratto, 
		PeriodoRilevante, 
		TotUnitaAssCed,
		TotUnitaAssAcq
		FROM #tmpCO
	) POU
	ON  PO.PeriodoRilevante = POU.PeriodoRilevante
	AND PO.IdContratto      = POU.IdContratto
) PU
GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto
ORDER BY PU.CRN

drop table #tmpCO

RETURN


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER     PROCEDURE dbo.spBilGetProgrammazione25
	@DataProgramma datetime,
	@CodiceOpAcq varchar(16) = null,
	@CodiceOpCed varchar(16) = null
AS

SET NOCOUNT ON;

set transaction isolation level read uncommitted

SELECT 
IdContratto, 
PeriodoRilevante, 
SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
INTO #tmpCO
FROM programmaorarioperunita
WHERE DataProgramma = @DataProgramma
AND ProgOrarioDellUnitaValidato=1
GROUP BY IdContratto, PeriodoRilevante

select
	PU.IdContratto,
		
  	sum(case PU.PeriodoRilevante when   1 then PU.TotUnitaAssCed else 0 end) 			C01,
  	sum(case PU.PeriodoRilevante when   2 then PU.TotUnitaAssCed else 0 end) 			C02,
  	sum(case PU.PeriodoRilevante when   3 then PU.TotUnitaAssCed else 0 end) 			C03,
  	sum(case PU.PeriodoRilevante when   4 then PU.TotUnitaAssCed else 0 end) 			C04,
  	sum(case PU.PeriodoRilevante when   5 then PU.TotUnitaAssCed else 0 end) 			C05,
	sum(case PU.PeriodoRilevante when   6 then PU.TotUnitaAssCed else 0 end) 			C06,
  	sum(case PU.PeriodoRilevante when   7 then PU.TotUnitaAssCed else 0 end) 			C07,
  	sum(case PU.PeriodoRilevante when   8 then PU.TotUnitaAssCed else 0 end) 			C08,
  	sum(case PU.PeriodoRilevante when   9 then PU.TotUnitaAssCed else 0 end) 			C09,
  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
  	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
  	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
 	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
  	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
  	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
  	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
  	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
  	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
  	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
  	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
  	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
  	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
  	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,

  	sum(case PU.PeriodoRilevante when   1 then PU.TotUnitaAssAcq else 0 end) 			A01,
  	sum(case PU.PeriodoRilevante when   2 then PU.TotUnitaAssAcq else 0 end) 			A02,
  	sum(case PU.PeriodoRilevante when   3 then PU.TotUnitaAssAcq else 0 end) 			A03,
  	sum(case PU.PeriodoRilevante when   4 then PU.TotUnitaAssAcq else 0 end) 			A04,
  	sum(case PU.PeriodoRilevante when   5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
  	sum(case PU.PeriodoRilevante when   6 then PU.TotUnitaAssAcq else 0 end) 			A06,
  	sum(case PU.PeriodoRilevante when   7 then PU.TotUnitaAssAcq else 0 end) 			A07,
  	sum(case PU.PeriodoRilevante when   8 then PU.TotUnitaAssAcq else 0 end) 			A08,
  	sum(case PU.PeriodoRilevante when   9 then PU.TotUnitaAssAcq else 0 end) 			A09,
 	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
  	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
  	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
  	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
  	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
  	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
  	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
  	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
  	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
  	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
  	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
  	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
   	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,

 	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end)				B01,
 	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end)				B02,
 	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end)				B03,
 	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end)				B04,
 	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end)				B05,
 	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) 			B06,
 	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) 			B07,
 	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) 			B08,
 	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) 			B09,
 	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) 			B10,
 	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) 			B11,
 	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) 			B12,
 	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) 			B13,
 	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) 			B14,
 	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) 			B15,
 	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) 			B16,
 	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) 			B17,
 	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) 			B18,
 	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) 			B19,
 	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) 			B20,
 	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) 			B21,
 	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) 			B22,
 	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) 			B23,
 	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) 			B24,
 	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) 			B25,

	PU.CRN,
	PU.CodiceContratto
FROM
(
	SELECT 
	CC.IdContratto, 
	Ore.Ora PeriodoRilevante,
	CC.CRN,
	CC.CodiceContratto,
	Sbilanciamento = case
		when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
		when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
		else
			case sign(PO.SbilanciamentoMWh) 
			when 1 then	 -- eccesso di produzione: 
				case CC.GestioneTaglio
				when 'T' then 5		-- taglia sempre, 'rosso'
				when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
				when 'C' then		-- solo se cons. maggiore prod.
	 				case CC.IsGMEOpAcquirente 
	 					when 1 then 4	-- 'blu'  
	 					when 0 then 3	-- 'arancione' 
	 				end 
				when 'M' then 
					case CC.IsGMEOpAcquirente 
						when 1 then 4   -- 'blu'
						when 0 then 3	-- 'arancione'
					end 
				end
			when -1 then 	-- eccesso di consumo: 
				case CC.GestioneTaglio
				when 'T' then 5		-- 'taglia sempre, rosso'
				when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
				when 'P' then		-- solo se prod. maggiore cons.
					case CC.IsGMEOpCedente
						when 1 then 4	-- 'blu'
						when 0 then 4	-- 'blu', caso praticamente impossibile 
					end 
				when 'M' then
					case CC.IsGMEOpCedente
						when 1 then 4	-- 'blu'
						when 0 then 4	-- 'blu', caso praticamente impossibile 
					end 
				end
			end
		end,
	TotUnitaAssCed = case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end , -- 0 rosso, 1 verde
	TotUnitaAssAcq = case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end 
	FROM
	(
		-- i contratti che dovrebbero essere programmati
		SELECT
		CO.IdContratto,
		CO.CRN,
		CO.CodiceContratto,
		CO.GestioneTaglio,
		OA.IsGMEOp IsGMEOpAcquirente,
		OC.IsGMEOp IsGMEOpCedente
		FROM 
		Contratto CO, 
		Operatori OA,
		Operatori OC
		WHERE   
		    CO.DataInizioValidita <= @DataProgramma
		AND CO.DataFineValidita   >= @DataProgramma
		AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
		AND CO.StatoContratto     = 'Abilitato'
		AND CO.TrCN               = 1
		AND CO.CodiceOperatoreSDCCedente    = COALESCE(@CodiceOpCed, CO.CodiceOperatoreSDCCedente)
		AND CO.CodiceOperatoreSDCAcquirente = COALESCE(@CodiceOpAcq, CO.CodiceOperatoreSDCAcquirente)
	) CC
	CROSS JOIN 
	(
		-- i contratti che dovrebbero essere programmati per 24 ore
		SELECT Ora 
		FROM Ore 
		WHERE Ore.Ora <= 25 -- 23 25
	) Ore
	LEFT OUTER JOIN ProgrammaOrario PO -- per contratto/ora mi tiro su i dati di PO
	ON  PO.IdContratto             = CC.IdContratto
	AND PO.PeriodoRilevante        = Ore.Ora
	AND PO.DataProgramma           = @DataProgramma
	AND PO.ProgrammaOrarioValidato = 1
	LEFT OUTER JOIN -- e per contratto/ora mi tiro su i dati riassuntivi di POU
	(
		SELECT 
		IdContratto, 
		PeriodoRilevante, 
		TotUnitaAssCed,
		TotUnitaAssAcq
		FROM #tmpCO
	) POU
	ON  PO.PeriodoRilevante = POU.PeriodoRilevante
	AND PO.IdContratto      = POU.IdContratto
) PU
GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto
ORDER BY PU.CRN

drop table #tmpCO

RETURN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



ALTER     PROCEDURE [dbo].[spCalcolaBilanciamento]
	@DataProgramma smalldatetime,
	@SogliaSbilMWh float
AS

-- non si usa read uncommitted in quanto il bilanciamento 
-- viene lanciato dentro un batch (i dati quindi non cambiamo)
-- e comunque il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@DataProgramma smalldatetime,
-- 	@SogliaSbilMWh float
-- 
-- set @DataProgramma = '24/11/2004'
-- set @SogliaSbilMWh = 0.001
-- 
-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno
-- (tutti i programmi !! )

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.
-- POU.QtyMWhBilanciamento=null per tutti i programmi.

-- inizializzo i campi per la data
update ProgrammaOrario
set 
Bilanciato=null,
SbilanciamentoMWh=null,
SbilanciamentoMWhReale=null,
TSCalcoloBilanciamento=null
where DataProgramma = @DataProgramma

-- -- str #272 chiamata 4378
-- tolgo l'update in POU in modo da non compromettere 
-- i dati del precedente bilanciamento forzato
-- 
--	-- siccome calcolo il bilanciamento i dati del bilanciamento forzato devono essere resettati
--	update ProgrammaOrarioPerUnita
--	set 
--	QtyMWhBilanciamento=NULL
--	where DataProgramma = @DataProgramma
--	and not QtyMWhBilanciamento is null
-- fine str #272


-- Qui indico che il bilanciamento per tutti i contratti e` stato fatto
-- e` da fare il taglio
-- Controllo se esiste il record relativo al giorno richiesto.
-- Il pannello di controllo crea automaticamente il record quando si seleziona una data non
-- ancora inserita nel DB.
-- Se il controllo bilanciamento viene eseguito dal batch alle 2:30 di notte, puo` accedere
-- che il record NON esista ancora (es. sito di addestramento).
if not exists (select * from SessioneBilaterali where DataProgramma=@DataProgramma)
begin
    insert into SessioneBilaterali
    (DataProgramma, Bilanciamento, Taglio, Offerte, LetturaMGP, DataChiusuraMGP) 
    values (@DataProgramma, 0, 0, 0, 0, null)
end



-- qui indico che il bilanciamento per tutti i contratti e` stato fatto
-- e` da fare il taglio
update 
SessioneBilaterali
set
-- str #272
-- non resetto piu` il flag del bilanciamento forzato, prima lo facevo
-- Bilanciamento=1, Taglio=0
Bilanciamento=1
-- fine str #272
where DataProgramma=@DataProgramma



declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()

-- Inizio STR 270: la soglia di sbilanciamento puo` essere minore di circa 1 KWh e cio` indica che si richiede la precisione massima, ossia che il programma deve essere perfettamente bilanciato 
-- Se la soglia e` maggiore o uguale di 1 KWh significa che e` tollerato un programma sbilanciato di un valore pari al massimo alla soglia.
-- Se il programma e` sbilanciato di una quantita` uguale alla soglia il programma e` BILANCIATO.
if @SogliaSbilMWh < 0.00099999   ---- sta per 1 KWh
	set @SogliaSbilMWh = 0
else
	set @SogliaSbilMWh = round(@SogliaSbilMWh, 3)
-- Fine  STR 270

update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,

-- 	Inizio STR 270 - Un programma con sola produzione di 0,001 MWh risulta bilanciato: per correggere questo basterebbe aggiungere il >=,
--	pero` trattando float e` piu` corretto calcolare fabs (a-b) < epsilon, numero di precisione inferiore a 1 KWh
--	case when Abs(round(Sum(Q.QtyMWh),3)) > @SogliaSbilMWh then 0 else 1 end Bilanciato,
--	case when Abs(round(Sum(Q.QtyMWh),3)) > @SogliaSbilMWh then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
	
	case when Abs(Sum(Q.QtyMWh)) - @SogliaSbilMWh <  0.0005 then 1 else 0 end Bilanciato,
	case when Abs(Sum(Q.QtyMWh)) - @SogliaSbilMWh <  0.0005 then 0 else Sum(Q.QtyMWh) end BilMWh,

-- 	Fine  STR 270

	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on  PO.Idcontratto = POU.IdContratto
		and PO.DataProgramma = POU.DataProgramma
		and PO.PeriodoRilevante = POU.PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join  SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

		where
		POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
	) Q
	group by IdContratto, PeriodoRilevante
) W
on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




ALTER   PROCEDURE dbo.spCalcolaBilanciamentoPerContratto
	(
		@IdContratto int,
		@DataProgramma smalldatetime,
		@PeriodoRilevante tinyint,
	 	@SogliaSbilMWh float
	)

AS
-- non si usa read uncommitted in quanto
-- il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


	SET NOCOUNT ON
	
	select 
	IsNull(Sum(round(POU.QtyMWh * UC.KP / UC.KU, 3)), 0) SBilMWh
	from 
	(
		-- trovo tutte le unita per contratto valide 
		-- ossia quelle da programmare per la data in ingresso
		-- (TrCC e TrUC garantiscono che il contratto sia valido, le unita valide, gli operatori validi)
		select 
		UnitaContratto.CodiceUnitaSDC, 
		UnitaContratto.CategoriaUnitaSDC,
		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
		from 
		tab_UnitaContratto2(@DataProgramma, @IdContratto) UnitaContratto, 
		SDC_Unita, 
		SDC_PuntiDiScambioRilevanti,
		Contratto
		where 
		    UnitaContratto.IdContratto = @IdContratto
		and UnitaContratto.IdContratto = Contratto.IdContratto
		and Contratto.DataInizioValidita <= @DataProgramma
		and Contratto.DataFineValidita >= @DataProgramma
		and UnitaContratto.TrCC=1 
		and UnitaContratto.TrUC=1
		and UnitaContratto.UnitaDelContrattoValidata=1
		and UnitaContratto.DataInizioValidita <= @DataProgramma
		and UnitaContratto.DataFineValidita >= @DataProgramma
		and UnitaContratto.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
		and UnitaContratto.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
	) UC
	inner join
	(
		-- considero i POU validi del giorno per il contratto
		
		SELECT 
			POUI.CodiceUnitaSDC, 
			POUI.CategoriaUnitaSDC, 
			POUI.QtyMWh,
			POUI.IdContratto
		FROM
			(
				SELECT
					ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
					ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
					ProgrammaOrarioPerUnita.QtyMWh,
					ProgrammaOrarioPerUnita.IdContratto,
					ProgrammaOrarioPerUnita.DataProgramma,
					ProgrammaOrarioPerUnita.PeriodoRilevante
				FROM
					ProgrammaOrarioPerUnita
				WHERE
					ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
					and ProgrammaOrarioPerUnita.PeriodoRilevante=@PeriodoRilevante
					and ProgrammaOrarioPerUnita.IdContratto = @IdContratto
					and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
			) POUI
			INNER JOIN
			(
				SELECT 
					ProgrammaOrario.IdContratto,
					ProgrammaOrario.DataProgramma,
					ProgrammaOrario.PeriodoRilevante
				FROM ProgrammaOrario
				WHERE
						ProgrammaOrario.DataProgramma=@DataProgramma
						and ProgrammaOrario.PeriodoRilevante=@PeriodoRilevante
						and ProgrammaOrario.IdContratto= @IdContratto
						and ProgrammaOrario.ProgrammaOrarioValidato=1
			) POI
			ON
				POUI.IdContratto = POI.IdContratto 
				AND POUI.DataProgramma = POI.DataProgramma
				AND POUI.PeriodoRilevante = POI.PeriodoRilevante
	) POU
	ON
	    POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
	and POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO




ALTER    PROCEDURE [dbo].[spCalcolaBilanciamentoPerOra]
	@DataProgramma smalldatetime,
	@SogliaSbilMWh float,
	@Ora tinyint,
	@UltimoBilanciamento bit
AS

-- non si usa read uncommitted in quanto il bilanciamento 
-- viene lanciato dentro un batch (i dati quindi non cambiamo)
-- e comunque il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@DataProgramma smalldatetime,
-- 	@SogliaSbilMWh float,
--	@Ora tinyint
-- 
-- set @DataProgramma = '24/11/2004'
-- set @SogliaSbilMWh = 0.001
-- set @Ora = 1
-- 
-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno
-- (tutti i programmi !! )

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.
-- POU.QtyMWhBilanciamento=null per tutti i programmi.

-- inizializzo i campi per la data
update ProgrammaOrario
set 
Bilanciato=null,
SbilanciamentoMWh=null,
SbilanciamentoMWhReale=null,
TSCalcoloBilanciamento=null
where 
    DataProgramma = @DataProgramma
and PeriodoRilevante = @Ora

-- -- str #272 chiamata 4378
-- tolgo l'update in POU in modo da non compromettere 
-- i dati del precedente bilanciamento forzato
-- siccome calcolo il bilanciamento i dati del bilanciamento forzato devono essere resettati
--	update ProgrammaOrarioPerUnita
--	set 
--	QtyMWhBilanciamento=NULL
--	where 
--	    DataProgramma = @DataProgramma
--	and PeriodoRilevante = @Ora
--	and not QtyMWhBilanciamento is null
-- fine str #272


-- qui indico che il bilanciamento per tutti i contratti e` stato fatto
-- e` da fare il taglio

if @UltimoBilanciamento = 1
begin

	-- Qui indico che il bilanciamento per tutti i contratti e` stato fatto
	-- e` da fare il taglio
	-- Controllo se esiste il record relativo al giorno richiesto.
	-- Il pannello di controllo crea automaticamente il record quando si seleziona una data non
	-- ancora inserita nel DB.
	-- Se il controllo bilanciamento viene eseguito dal batch alle 2:30 di notte, puo` accedere
	-- che il record NON esista ancora (es. sito di addestramento).
	if not exists (select * from SessioneBilaterali where DataProgramma=@DataProgramma)
	begin
		insert into SessioneBilaterali
		(DataProgramma, Bilanciamento, Taglio, Offerte, LetturaMGP, DataChiusuraMGP) 
		values (@DataProgramma, 0, 0, 0, 0, null)
	end

	update 
	SessioneBilaterali
	set
	-- str #272
	-- Bilanciamento=1, Taglio=0
	Bilanciamento=1
	-- fine str #272
	where DataProgramma=@DataProgramma
end



declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()

-- Inizio STR 270: la soglia di sbilanciamento puo` essere minore di circa 1 KWh e cio` indica che si richiede la precisione massima, ossia che il programma deve essere perfettamente bilanciato 
-- Se la soglia e` maggiore o uguale di 1 KWh significa che e` tollerato un programma sbilanciato di un valore pari al massimo alla soglia.
-- Se il programma e` sbilanciato di una quantita` uguale alla soglia il programma e` BILANCIATO.
if @SogliaSbilMWh < 0.00099999   ---- sta per 1 KWh
	set @SogliaSbilMWh = 0
else
	set @SogliaSbilMWh = round(@SogliaSbilMWh, 3)
-- Fine  STR 270


update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,
	
-- 	Inizio STR 270 - Un programma con sola produzione di 0,001 MWh risulta bilanciato: per correggere questo basterebbe aggiungere il >=,
--	pero` trattando float e` piu` corretto calcolare fabs (a-b) < epsilon, numero di precisione inferiore a 1 KWh
--	case when Abs(round(Sum(Q.QtyMWh),3)) > @SogliaSbilMWh then 0 else 1 end Bilanciato,
--	case when Abs(round(Sum(Q.QtyMWh),3)) > @SogliaSbilMWh then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,

	case when Abs(Sum(Q.QtyMWh)) - @SogliaSbilMWh <  0.0005 then 1 else 0 end Bilanciato,
	case when Abs(Sum(Q.QtyMWh)) - @SogliaSbilMWh <  0.0005 then 0 else Sum(Q.QtyMWh) end BilMWh,


-- 	Fine  STR 270


	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on  PO.Idcontratto = POU.IdContratto
		and PO.DataProgramma = POU.DataProgramma
		and PO.PeriodoRilevante = POU.PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on  CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on  UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

		where
		POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
		and POU.PeriodoRilevante = @Ora
	) Q
	group by IdContratto, PeriodoRilevante
) W
on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



ALTER  PROCEDURE dbo.spChiudiMercato
	@d as datetime
AS

-- declare @d as datetime
-- set @d = '10/12/2004'

-- qui per evitare problemi cancello gli eventuali
-- SbilMGPalCP gia` valorizzati
-- (es ha chiuso e riaperto il mercato)
-- In realta` questa update e` solo per tranquillita` dato
-- che spRiapriMercato fa la stessa cosa.
update ProgrammaOrario
set SbilMGPalCP = NULL
where 
DataProgramma = @d
and SbilMGPalCP is not null


update ProgrammaOrario
-- questo round e` voluto per evitare di vedere cifre come 3E-16
set SbilMGPalCP = round(T.SbilMGPalCP, 5)
from ProgrammaOrario PO
inner join
(
	select 
	POU.IdContratto, 
	POU.DataProgramma,
	POU.PeriodoRilevante, 
	sum(QtyMWhAssegnataMGP * PR.CoefficienteDiPerdita / U.CoefficientePerdita) SbilMGPalCP
	from 
	ProgrammaOrarioPerUnita POU
	
	inner join SDC_Unita U
	on  U.CodiceUnitaSDC = POU.CodiceUnitaSDC
	and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
	
	inner join SDC_PuntiDiScambioRilevanti PR
	on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC
	
	where POU.DataProgramma = @d
	and   POU.QtyMWhAssegnataMGP is not null
	
	group by
	POU.IdContratto,
	POU.DataProgramma,
	POU.PeriodoRilevante
) T
on  PO.IdContratto      = T.IdContratto
and PO.DataProgramma    = T.DataProgramma
and PO.PeriodoRilevante = T.PeriodoRilevante
where PO.DataProgramma = @d


update SessioneBilaterali 
set 
DataChiusuraMGP=getdate()
where DataProgramma=@d
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------

ALTER  PROCEDURE [dbo].[spEseguiBilanciamentoPerContratto]
	@IdContratto int,
	@DataProgramma smalldatetime,
	@PeriodoRilevante tinyint,
	@SogliaSbilMWh float
AS


-- STR 251: correzione di questa logica, le programmazioni a zero non vengono piu` inserite 
-- nella ProgrammaOrarioPerUnita, con conseguente beneficio per gli indici di POU.
-- Lasciamo la Delete di POUE, anche se in realta` non dovrebbe mai cancellare nulla 
-- (POUE puo` essere compilata in fase di Lettura Mercato, quindi dopo)
-- CANCELLAZIONE DELLE PROGRAMMAZIONI A ZERO MWH
-- =============================================
-- Questo NON e' il posto migliore per fare le cancellazioni della programmazione a zero MWh.
-- Il posto migliore dovrebbe essere ElaborazioneProgrammiUtenti.
-- Per motivi di tempo e di rischio oggi 24/12/2004 preferisco mettere qui questa
-- operazione.
-- La metto qui dato che il bilanciamento per contratto avviene ad ogni invio
-- del programma.
-- E' sicuramente stupido inserire/modificare record a zero per poi cancellarli, ma
-- dato il carattere di emergenza della modifica questo e` il posto migliore.
-- Notare che su ROMA4 si hanno circa 628.000 record in POU di cui 222.000 a 0MWh ossia
-- il 35% !! --> le query dovrebbero andare almeno un po' piu' veloci.
-- Unico rischio che vedo e` la frammentazione dell'indice.... per ora ignoro.
-- 
-- Prima cerco le programmazioni a zero in POU
-- per cancellare gli eventuali record collegati in POUE
-- (che NON dovrebbero esserci... ma per tranquillita` referenziale lo faccio)
-- Poi cancello le programmazioni a zero in POU

-- delete ProgrammaOrarioPerUnitaErrori
-- from
-- (
-- 	select
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC
-- 	from 
-- 	ProgrammaOrarioperUnita 
-- 	where 
-- 	         IdContratto      = @IdContratto
-- 	and DataProgramma    = @DataProgramma
-- 	and PeriodoRilevante = @PeriodoRilevante
-- 	and QtyMWh=0
-- ) T
-- where
--       ProgrammaOrarioPerUnitaErrori.IdContratto       = T.IdContratto
-- and ProgrammaOrarioPerUnitaErrori.DataProgramma     = T.DataProgramma
-- and ProgrammaOrarioPerUnitaErrori.PeriodoRilevante  = T.PeriodoRilevante
-- and ProgrammaOrarioPerUnitaErrori.CodiceUnitaSDC    = T.CodiceUnitaSDC
-- and ProgrammaOrarioPerUnitaErrori.CategoriaUnitaSDC = T.CategoriaUnitaSDC


--delete ProgrammaOrarioPerUnita
--where 
--    IdContratto      = @IdContratto
--and DataProgramma    = @DataProgramma
--and PeriodoRilevante = @PeriodoRilevante
--and QtyMWh           = 0


-- FINE CANCELLAZIONE PROGRAMMAZIONI A 0 MWH
-- =========================================

--=============================================================================================================

-- non si usa read uncommitted in quanto
-- il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@IdContratto int,
-- 	@DataProgramma smalldatetime,
-- 	@PeriodoRilevante tinyint,
-- 	@SogliaSbilMWh float
-- 
-- set @IdContratto = 212
-- set @DataProgramma = '1/12/2004'
-- set @PeriodoRilevante = 1
-- set @SogliaSbilMWh = 0.001


-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno/ora

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o valido non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.


-- str #272
-- questa sp e` chiamata quando arriva un programma
-- il primo update azzera i dati di bilanciamento in PO per quel contratto
-- il secondo update i dati di bilanciamento forzato per quel contratto.
-- il terzo azzera le quantita` bilanciate in maniera forzata.
-- Ora, a fronte di un NUOVO programma questo comportamento
-- e` corretto.
-- Il problema e` che poi NAB non permette di effettuare il bilanciamento forzato per
-- contratto..... Ora si e` costretti a a rifare il bilanciamento forzato globale.
-- non mi sembra pero` un problema.
-- in pratica per str #272 lascio tutto inalterato.
-- fine str #272

-- per prima cosa azzero le informazioni in PO
update ProgrammaOrario
set 
Bilanciato=NULL,
SbilanciamentoMWh=NULL,
SbilanciamentoMWhReale=NULL,
TSCalcoloBilanciamento=NULL
from ProgrammaOrario
where
IdContratto = @IdContratto
and DataProgramma = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante

-- e conseguentemente in POU
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where DataProgramma = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante
and IdContratto = @IdContratto
and not QtyMWhBilanciamento is null

-- siccome sto facendo il calcolo del bilanciamento, potenzialmente
-- e` cambiato il bilanciamento e dunque potenzialemente
-- il taglio forzato e` da rifare.
update 
SessioneBilaterali
set
Taglio=0
where DataProgramma=@DataProgramma


declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()

update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,
	
	case when Abs(Sum(Q.QtyMWh)) > @SogliaSbilMWh then 0 else 1 end Bilanciato,
	case when Abs(Sum(Q.QtyMWh)) > @SogliaSbilMWh then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on
		POU.Idcontratto = PO.IdContratto
		and POU.DataProgramma = PO.DataProgramma
		and POU.PeriodoRilevante = PO.PeriodoRilevante
		and POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
		and POU.IdContratto = @IdContratto
		and POU.PeriodoRilevante = @PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join  SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

	) Q
	group by IdContratto, PeriodoRilevante

) W

on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



ALTER   PROCEDURE dbo.spGeneraOfferte
	@DataRicerca as smalldatetime,
	@OraRicerca as tinyint
AS

-- non si usa read uncommitted in quanto
-- la generazione delle offerte e` troppo delicata per farla su dati non sicuri


update ProgrammaOrario
set
GestioneTaglio = Q.GestioneTaglio,
IsGMEOp        = Q.IsGMEOp
from ProgrammaOrario PO
inner join
(
	select
	Contratto.IdContratto        IdContratto,
	Contratto.GestioneTaglio     GestioneTaglio,
	IsNull(Operatori.IsGMEOp, 0) IsGMEOp
	from Contratto
	inner join Operatori
	on Contratto.CodiceOperatoreSDCAcquirente = Operatori.CodiceOperatoreSDC
) Q
on 
PO.IdContratto = Q.IdContratto
where 
DataProgramma = @DataRicerca
and PeriodoRilevante = @OraRicerca

-- set @DataRicerca = '22/4/4'
-- set @OraRicerca = 2

DELETE FROM ProgrammaOrarioPerUnitaErrori
WHERE 
DataProgramma = @DataRicerca
AND PeriodoRilevante = @OraRicerca

UPDATE ProgrammaOrarioPerUnita
SET 
GMEReferenceNumber = NULL,
QtyMWhAssegnataMGP = NULL
WHERE
DataProgramma = @DataRicerca
AND PeriodoRilevante = @OraRicerca

-- genero le offerte (a parte LastError)
-- solo per i programmi che hanno PO.Bilanciato <> NULL

SELECT 
POU.IdContratto, 
POU.CategoriaUnitaSDC, 
POU.CodiceUnitaSDC, 
POU.QtyMWh, 
POU.QtyMWhBilanciamento,
CL.LastError

from 
ProgrammaOrarioPerUnita POU

inner join ProgrammaOrario PO
on  PO.IdContratto      = POU.IdContratto
and PO.DataProgramma    = POU.DataProgramma
and PO.PeriodoRilevante = POU.PeriodoRilevante
and PO.ProgrammaOrarioValidato = 1
and PO.Bilanciato is NOT NULL

inner join Contratto CO
on  CO.IdContratto = POU.IdContratto
and CO.StatoContratto = 'Abilitato'
and CO.DataInizioValidita <= @DataRicerca
and CO.DataFineValidita >= @DataRicerca
and CO.TrCN = 1

inner join XmlProgrammiUtenti XP
on XP.IdProgrammaXml = POU.IdProgrammaXml

inner join UnitRelate UR
on  
(
	(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente = 0)
	or
	(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente = 1)
)
and UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
and UR.DataInizioValidita <= @DataRicerca
and UR.DataFineValidita >= @DataRicerca
and UR.Abilitata = 1
and UR.TrUC = 1

left outer join Certificate_List CL
on  XP.CodiceUtenteSDC = CL.CodiceUtenteSDC
and XP.Issuer          = CL.Issuer
and XP.SerialNumber    = CL.SerialNumber


where
POU.DataProgramma = @DataRicerca
and POU.PeriodoRilevante = @OraRicerca
and POU.ProgOrarioDellUnitaValidato = 1
ORDER BY 
POU.IdProgrammaXml, 
POU.ProgressivoNelProgramma
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





ALTER  PROCEDURE dbo.spGeneraOfferte_PgmBilanciati 
	@DataRicerca as smalldatetime,
	@OraRicerca as tinyint
AS
-- set @DataRicerca = '22/4/4'
-- set @OraRicerca = 2


update ProgrammaOrario
set
GestioneTaglio = Q.GestioneTaglio,
IsGMEOp        = Q.IsGMEOp
from ProgrammaOrario PO
inner join
(
	select
	Contratto.IdContratto        IdContratto,
	Contratto.GestioneTaglio     GestioneTaglio,
	IsNull(Operatori.IsGMEOp, 0) IsGMEOp
	from Contratto
	inner join Operatori
	on Contratto.CodiceOperatoreSDCAcquirente = Operatori.CodiceOperatoreSDC
) Q
on 
PO.IdContratto = Q.IdContratto
where 
DataProgramma = @DataRicerca
and PeriodoRilevante = @OraRicerca


DELETE FROM ProgrammaOrarioPerUnitaErrori
WHERE 
DataProgramma = @DataRicerca
AND PeriodoRilevante = @OraRicerca

UPDATE ProgrammaOrarioPerUnita
SET 
GMEReferenceNumber = NULL,
QtyMWhAssegnataMGP = NULL
WHERE
DataProgramma = @DataRicerca
AND PeriodoRilevante = @OraRicerca

SELECT 
ProgrammaOrarioPerUnita.IdContratto, 
ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
ProgrammaOrarioPerUnita.QtyMWh, 
ProgrammaOrarioPerUnita.QtyMWhBilanciamento,
Certificate_List.LastError
FROM 
ProgrammaOrarioPerUnita 
INNER JOIN tab_UnitaContratto(@DataRicerca) UnitaContratto 
ON ProgrammaOrarioPerUnita.IdContratto = UnitaContratto.IdContratto 
AND ProgrammaOrarioPerUnita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC 
AND ProgrammaOrarioPerUnita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC 
INNER JOIN ProgrammaOrario 
ON ProgrammaOrarioPerUnita.IdContratto = ProgrammaOrario.IdContratto 
AND ProgrammaOrarioPerUnita.DataProgramma = ProgrammaOrario.DataProgramma 
AND ProgrammaOrarioPerUnita.PeriodoRilevante = ProgrammaOrario.PeriodoRilevante 
INNER JOIN Contratto
ON ProgrammaOrarioPerUnita.IdContratto = Contratto.IdContratto 

INNER JOIN XmlProgrammiUtenti
ON XmlProgrammiUtenti.IdProgrammaXml = ProgrammaOrarioPerUnita.IdProgrammaXml
LEFT OUTER JOIN Certificate_List
ON  XmlProgrammiUtenti.CodiceUtenteSDC = Certificate_List.CodiceUtenteSDC
AND XmlProgrammiUtenti.Issuer          = Certificate_List.Issuer
AND XmlProgrammiUtenti.SerialNumber    = Certificate_List.SerialNumber


WHERE 
ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca AND 
ProgrammaOrarioPerUnita.PeriodoRilevante = @OraRicerca AND
ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 AND 
ProgrammaOrario.ProgrammaOrarioValidato = 1 AND 
ProgrammaOrario.Bilanciato = 1 AND 
UnitaContratto.TrCC = 1 AND 
UnitaContratto.TrUC = 1 AND 
UnitaContratto.UnitaDelContrattoValidata = 1 AND 
UnitaContratto.DataInizioValidita <= @DataRicerca AND 
UnitaContratto.DataFineValidita >= @DataRicerca AND
Contratto.DataInizioValidita <= @DataRicerca AND 
Contratto.DataFineValidita >= @DataRicerca
ORDER BY 
ProgrammaOrarioPerUnita.IdProgrammaXml, 
ProgrammaOrarioPerUnita.ProgressivoNelProgramma
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





ALTER  PROCEDURE dbo.spGeneraOfferte_PgmNonBilanciati 
	@DataRicerca as smalldatetime,
	@OraRicerca as tinyint
AS
-- set @DataRicerca = '22/4/4'
-- set @OraRicerca = 2


update ProgrammaOrario
set
GestioneTaglio = Q.GestioneTaglio,
IsGMEOp        = Q.IsGMEOp
from ProgrammaOrario PO
inner join
(
	select
	Contratto.IdContratto        IdContratto,
	Contratto.GestioneTaglio     GestioneTaglio,
	IsNull(Operatori.IsGMEOp, 0) IsGMEOp
	from Contratto
	inner join Operatori
	on Contratto.CodiceOperatoreSDCAcquirente = Operatori.CodiceOperatoreSDC
) Q
on 
PO.IdContratto = Q.IdContratto
where 
DataProgramma = @DataRicerca
and PeriodoRilevante = @OraRicerca

DELETE FROM ProgrammaOrarioPerUnitaErrori
WHERE 
DataProgramma = @DataRicerca
AND PeriodoRilevante = @OraRicerca

UPDATE ProgrammaOrarioPerUnita
SET 
GMEReferenceNumber = NULL,
QtyMWhAssegnataMGP = NULL
WHERE
DataProgramma = @DataRicerca
AND PeriodoRilevante = @OraRicerca

SELECT 
ProgrammaOrarioPerUnita.IdContratto, 
ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
ProgrammaOrarioPerUnita.QtyMWh, 
ProgrammaOrarioPerUnita.QtyMWhBilanciamento,  -- per simmetria con ls spGeneraOfferte_PgmBilanciati
Certificate_List.LastError
FROM 
ProgrammaOrarioPerUnita 
INNER JOIN tab_UnitaContratto(@DataRicerca) UnitaContratto 
ON ProgrammaOrarioPerUnita.IdContratto = UnitaContratto.IdContratto 
AND ProgrammaOrarioPerUnita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC 
AND ProgrammaOrarioPerUnita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC 
INNER JOIN ProgrammaOrario 
ON ProgrammaOrarioPerUnita.IdContratto = ProgrammaOrario.IdContratto 
AND ProgrammaOrarioPerUnita.DataProgramma = ProgrammaOrario.DataProgramma 
AND ProgrammaOrarioPerUnita.PeriodoRilevante = ProgrammaOrario.PeriodoRilevante 
INNER JOIN Contratto
ON Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto

INNER JOIN XmlProgrammiUtenti
ON XmlProgrammiUtenti.IdProgrammaXml = ProgrammaOrarioPerUnita.IdProgrammaXml
LEFT OUTER JOIN Certificate_List
ON  XmlProgrammiUtenti.CodiceUtenteSDC = Certificate_List.CodiceUtenteSDC
AND XmlProgrammiUtenti.Issuer          = Certificate_List.Issuer
AND XmlProgrammiUtenti.SerialNumber    = Certificate_List.SerialNumber

WHERE 
ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca AND 
ProgrammaOrarioPerUnita.PeriodoRilevante = @OraRicerca AND
ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 AND 
ProgrammaOrario.ProgrammaOrarioValidato = 1 AND 
UnitaContratto.TrCC = 1 AND 
UnitaContratto.TrUC = 1 AND 
UnitaContratto.UnitaDelContrattoValidata = 1 AND 
UnitaContratto.DataInizioValidita <= @DataRicerca AND 
UnitaContratto.DataFineValidita >= @DataRicerca AND
Contratto.DataInizioValidita <= @DataRicerca AND 
Contratto.DataFineValidita >= @DataRicerca 
ORDER BY 
ProgrammaOrarioPerUnita.IdProgrammaXml, 
ProgrammaOrarioPerUnita.ProgressivoNelProgramma
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO




ALTER    PROCEDURE spGetOperatorListUnits
	@dt as datetime
AS

select CodiceUnitaSDC, 
	NroOp,
	AbilitataRUP,
	AbilitataNAB,
	Abilitata,
	LstOp
from 
(
	select w.CodiceUnitaSDC, 
	w.CategoriaUnitaSDC,
	w.NroOp, 
	k.AbilitataRUP,
	k.AbilitataNAB,
	k.Abilitata,
	w.LstOp
	from 
	(
		select t.CodiceUnitaSDC, t.CategoriaUnitaSDC,
		count(t.CodiceOperatoreSDC)  NroOp, 
		dbo.GetOperatori(t.CodiceUnitaSDC, t.CategoriaUnitaSDC, @dt)  LstOp 
		from
		(
			select
			su.CodiceUnitaSDC, 
			ur.CodiceOperatoreSDC, 
			su.CategoriaUnitaSDC 
			from SDC_Unita su
			-- SCR Id267: tali condizioni non sono piu` filtri, 
			-- bensi` sono colonne esplicite sul report.
			-- left outer join Unita u
			-- on su.CodiceUnitaSDC = u.CodiceUnitaSDC 
			-- and su.CategoriaUnitaSDC = u.CategoriaUnitaSDC
			-- and u.StatoBilateraliUnita = 1
			-- and su.Abilitata = 1
			left outer join UnitRelate ur
			on su.CodiceUnitaSDC = ur.CodiceUnitaSDC 
			and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
			and @dt >= ur.DataInizioValidita
			and @dt <= ur.DataFineValidita
			and ur.Abilitata = 1
			-- SCR Id267: tali condizioni non sono piu` filtri, 
			-- bensi` sono colonne esplicite sul report.
			-- left outer join SDC_Unita_MarketInformation mi
			-- on su.CodiceUnitaSDC = mi.CodiceUnitaSDC 
			-- and su.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
			-- and mi.MarketCode = 'MGP'
			-- and mi.Eligibility = 'Able'
		) t 
		GROUP BY t.CodiceUnitaSDC, t.CategoriaUnitaSDC
	) w,
	(
		select 
		su.CodiceUnitaSDC,
		su.CategoriaUnitaSDC,
		case su.Abilitata 
		when 1 then 
			case mi.Eligibility 
			when 'Able' then  '1' 
			else	'0' 
			end
		else 
		'0' 
		end 'AbilitataRUP',
		case isnull(u.StatoBilateraliUnita, 0) when 1 then '1' else '0' end 'AbilitataNAB',
		case isnull(u.StatoBilateraliUnita, 0) & su.Abilitata when 1 then '1' else '0' end 'Abilitata'
		from SDC_Unita su
		left outer join Unita u
		on su.CodiceUnitaSDC = u.CodiceUnitaSDC 
		and su.CategoriaUnitaSDC = u.CategoriaUnitaSDC
		left outer join SDC_Unita_MarketInformation mi
		on su.CodiceUnitaSDC = mi.CodiceUnitaSDC 
		and su.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
		and mi.MarketCode = 'MGP'
		and mi.Eligibility = 'Able'
	) k
	where k.CodiceUnitaSDC = w.CodiceUnitaSDC 
	and k.CategoriaUnitaSDC = w.CategoriaUnitaSDC
) x
order by Abilitata desc, 
AbilitataRUP desc,
AbilitataNAB desc,
NroOp desc, 
CodiceUnitaSDC asc


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



ALTER  PROCEDURE dbo.spReportVenditeOpAcqIpex
	@di as datetime,
	@df as datetime
AS
-- metodo di calcolo concordato per i CSP:
-- mail Mario Pession del 21/1/05 su risposta della mia del
-- 
--Ciao,
--Nel report 'Report vendite operatori acquirenti IPEX' sono riportati i campi
--NomeOperatore,
--CodiceOperatore, 
--QuantitaVenduteMWh,
--ControvaloreEuro,
--IvaEuro,
--TotaleVenditeEuro
--Il report viene richiesto per range di date e riporta una riga per operatore, 
--cumulando le quantit� vendute, il controvalore in euro ecc nel periodo.
--Vorrei che mi validassi le formule per ottenere queste quantit�:
--QuantitaVenduteMWh
--Round(Somm(Q), 3)
--Tutte le quantit� assegnate sono summate nel periodo e poi viene effettauto il round a 3 cifre
--ControvaloreEuro
--            Somm[round(Pun * Q, 2)]
--In pratica ogni offerta accettata viene moltiplicata per il Pun, 
-- il risultato viene arrotondato a 2 cifre (ai centesimi). Questo � il dovuto per offerta.
--La sommatoria si estende al dovuto per offerta accettata nel periodo.
--Notare che in un dato periodo si avr� QuantitaVenduteMWh*Pun diverso da ControvaloreEuro 
-- dato che arrotondare gli addendi � diverso da arrotondare la somma.
--IvaEuro
--            Round(ControvaloreEuro * Iva/100, 2)
--TotaleVenditeEuro
--            ControvaloreEuro + IvaEuro
--Notare che il computo dell�iva, impostato in questa maniera implica che
--TotaleVenditeEuro dal primo al 15 del mese + TotaleVenditeEuro da 16 a fine mese <> TotaleVenditeEuro di tutto il mese.
--
--La risposta di MP (21/1/05) e`
-- confermo le formule indicate. Per la precisione sottolineo che per offerta 
-- si intende in questo caso, lo sbilancio orario relativo 
-- ad un contratto il cui cedente sia operatore di mercato

--
--================================================================================
-- Devo dunque intendere che il singolo CSP che e` legato alla formula Summ(Q)*Pun
-- siano da calcolare non come Summ(round(Q*Pun),2) ma
-- round(Summ(Q)*Pun,2)
-- e la somma di piu` CSP
-- summ(round(Summ(Q)*Pun,2))
--================================
--
-- (la mia idea del modo di calcolare i CSP e` diversa: dato che corr tot=Summ(round(Q*Pun,2)) per offerta,
-- pensavo di usare la stessa anche nel delta(q)*pun..... 
-- la mail pero` dice il contrario e dopo un po' di prove con Mario, e` venuto fuori la formula confermata.

set transaction isolation level read uncommitted

--declare @di as datetime
--declare @df as datetime
declare @iva as decimal(15,2)

--set @di = '27/11/2004'
--set @df = '27/11/2004'
set @iva = 10
set @iva = @iva / 100

-- qui calcolo l'ammontare dell'iva
-- Faccio cosi` per evitare errori di arrotondamento
select
NomeOperatore,
CodiceOperatore,
QuantitaVenduteMWh,
ControvaloreEuro,
convert(decimal(15,2), round(ControvaloreEuro * @iva, 2, 1)) IvaEuro,
convert(decimal(15,2), ControvaloreEuro + convert(decimal(15,2), round(ControvaloreEuro * @iva, 2, 1))) TotaleVenditeEuro
from
(
	-- questa query ritorna per operatore acquirente
	-- la sommatoria delle Q al clearing point 
	-- e la sommatoria del Controvalore in Euro computando Pun*Q
	select
	OP.RagioneSociale                               NomeOperatore,
	CodiceOperatoreSDCAcquirente                    CodiceOperatore,
	convert(decimal(15,3), sum(R.QuantitaVendute))  QuantitaVenduteMWh,
	convert(decimal(15,2), sum(R.ControvaloreEuro)) ControvaloreEuro
	from
	(
		-- qui ottengo l'operatore acquirente associato,
		-- uno per riga di sotto.
		select
		C.CodiceOperatoreSDCAcquirente,
		T.*
		from
		(
			-- qui si ottiene Somm(Q) del contratto/data/ora non arrotondata.
			-- il controvalore round(Somm(Q)*Pun,2)
			select 
			PO.IdContratto, 
			PO.DataProgramma,
			PO.PeriodoRilevante, 
			PO.SbilMGPalCP QuantitaVendute,
			-- Nota del 7/Sett/2005
			-- Questa e` la formula del CSP valida ad oggi.
			-- E` errata... si spera che SbilMGPalCP sia a zero
			-- per evitare di evidenziare il problema
			convert(decimal(15,2), PU.Prezzo * SbilMGPalCP) ControvaloreEuro
			from 
			ProgrammaOrario PO
		
			inner join PrezzoUnitario PU
			on  PU.Data = PO.DataProgramma
			and PU.PeriodoRilevante = PO.PeriodoRilevante
		
			where 
			PO.DataProgramma >= @di
			and PO.DataProgramma <= @df
			and PO.IsGMEOp = 1 -- qui considero i contratti per cui OpAcquirente e` IPEX
			and PO.SbilMGPalCP is not null
			and PO.SbilMGPalCP > 0
		) T
		-- qui aggancio il contratto cosi` ottengo il codice dell'operatore acquirente
		inner join Contratto C
		on C.IdContratto = T.IdContratto
	) R
	-- qui aggancio l'operatore per ottenere la ragione sociale.
	inner join SDC_Operatori OP
	on OP.CodiceOperatoreSDC = R.CodiceOperatoreSDCAcquirente
	
	-- qui raggruppo per operatore
	group by OP.RagioneSociale, R.CodiceOperatoreSDCAcquirente
) Q
order by NomeOperatore
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




ALTER   PROCEDURE dbo.spRiapriMercato
	@d as datetime
AS

-- declare @d as datetime
-- set @d = '10/12/2004'

-- Se si riapre il mercato ci sara` qualche ragione.
-- Esempio si deve rigirare tutto.
-- Meglio dunque fare pulizia.
update ProgrammaOrario
set SbilMGPalCP = null
where 
DataProgramma = @d
and SbilMGPalCP is not null

update SessioneBilaterali 
set 
DataChiusuraMGP=null
where DataProgramma=@d


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE TRIGGER [trUtenti_OnInsert] ON [dbo].[Utenti] 
FOR INSERT
AS

declare	@CodiceUtenteSDC varchar(16),
	@StatoBilateraliUtente bit,
	@TSModifica datetime,
	@SuperUser bit,
	-- valori provenienti da inserted
	@CodiceOperatoreSDC varchar(16),
	@tsIni datetime,
	@tsEnd datetime,
	@CodiceRuolo varchar(32),
	@Amministratore bit,
	@Abilitato bit


select 	@CodiceUtenteSDC= CodiceUtenteSDC, 
	@StatoBilateraliUtente = StatoBilateraliUtente ,
	@TSModifica = TSModifica,
	@SuperUser = SuperUser 
from inserted

if @SuperUser = 1 
-- aggiungo nella relazione operatori utenti una riga di tipo utente (non amministratore) per ogni codice operatore 
begin
	set @tsIni = getdate()
	set @tsEnd = convert(datetime, '20301231', 112) 
	set @CodiceRuolo = "root"
	
	set @Amministratore = 0
	set @Abilitato = 1
	
	declare op_cursor cursor local for
	select CodiceOperatoreSDC
	from Operatori
	where Amministratore = 0 and 
		StatoBilateraliOperatore = 1
		and not exists 
		(
			select CodiceOperatoreSDC
			from RelOperatoriUtenti
			where CodiceUtenteSDC = @CodiceUtenteSDC
			and CodiceOperatoreSDC = Operatori.CodiceOperatoreSDC
		)
	
	open op_cursor
	
	fetch next from op_cursor into @CodiceOperatoreSDC
	while @@fetch_status = 0 
	begin

		insert into RelOperatoriUtenti
		(CodiceUtenteSDC, CodiceOperatoreSDC, Amministratore, Abilitato, TSIniValidita, TSEndValidita, CodiceRuolo, TSModifica, SuperUser)
		values(@CodiceUtenteSDC, @CodiceOperatoreSDC, @Amministratore, @Abilitato, @tsIni, @tsEnd, @CodiceRuolo, getdate(), @SuperUser)
		
		fetch next from op_cursor into @CodiceOperatoreSDC
	end
	
	close op_cursor
	deallocate op_cursor
end
else
begin
	-- Cancello dalla relazione operatori utenti le relazioni aggiunte dal trs (questo o quello sull'insert)
	-- Notare che nella relazione operatori utenti il bit SuperUser di default e` a zero, viene messo ad 1 solo quando viene inserito o modicato il bit SuperUser dell'utente, 
	-- quindi se esiste una relaizone con bit a uno e` stata messa tramite tr su insert/update utenti. Quando sugli utenti rimetto a 0 il bit posso cancellare le righe nella
	-- RelOperatoriUtenti con il bit a 1.
	delete from RelOperatoriUtenti
	where CodiceUtenteSDC = @CodiceUtenteSDC and SuperUser = 1
end



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TRIGGER [trUtenti_OnUpdate] ON [dbo].[Utenti] 
FOR UPDATE
AS

declare	@CodiceUtenteSDC varchar(16),
	@StatoBilateraliUtente bit,
	@TSModifica datetime,
	@SuperUser bit,
	-- valori provenienti da inserted
	@CodiceOperatoreSDC varchar(16),
	@tsIni datetime,
	@tsEnd datetime,
	@CodiceRuolo varchar(32),
	@Amministratore bit,
	@Abilitato bit


select 	@CodiceUtenteSDC= CodiceUtenteSDC, 
	@StatoBilateraliUtente = StatoBilateraliUtente ,
	@TSModifica = TSModifica,
	@SuperUser = SuperUser 
from inserted

if @SuperUser = 1 
-- aggiungo nella relazione operatori utenti una riga di tipo utente (non amministratore) per ogni codice operatore 
begin
	set @tsIni = getdate()
	set @tsEnd = convert(datetime, '20301231', 112) 
	set @CodiceRuolo = "root"
	
	set @Amministratore = 0
	set @Abilitato = 1
	
	declare op_cursor cursor local for
	select CodiceOperatoreSDC
	from Operatori
	where Amministratore = 0 and 
		StatoBilateraliOperatore = 1
		and not exists 
		(
			select CodiceOperatoreSDC
			from RelOperatoriUtenti
			where CodiceUtenteSDC = @CodiceUtenteSDC
			and CodiceOperatoreSDC = Operatori.CodiceOperatoreSDC
		)
	
	open op_cursor
	
	fetch next from op_cursor into @CodiceOperatoreSDC
	while @@fetch_status = 0 
	begin

		insert into RelOperatoriUtenti
		(CodiceUtenteSDC, CodiceOperatoreSDC, Amministratore, Abilitato, TSIniValidita, TSEndValidita, CodiceRuolo, TSModifica, SuperUser)
		values(@CodiceUtenteSDC, @CodiceOperatoreSDC, @Amministratore, @Abilitato, @tsIni, @tsEnd, @CodiceRuolo, getdate(), @SuperUser)
		
		fetch next from op_cursor into @CodiceOperatoreSDC
	end
	
	close op_cursor
	deallocate op_cursor
end
else
begin
	-- Cancello dalla relazione operatori utenti le relazioni aggiunte dal trs (questo o quello sull'insert)
	-- Notare che nella relazione operatori utenti il bit SuperUser di default e` a zero, viene messo ad 1 solo quando viene inserito o modicato il bit SuperUser dell'utente, 
	-- quindi se esiste una relaizone con bit a uno e` stata messa tramite trs su insert/update utenti. Quando sugli utenti rimetto a 0 il bit posso cancellare le righe nella
	-- RelOperatoriUtenti con il bit a 1.
	delete from RelOperatoriUtenti
	where CodiceUtenteSDC = @CodiceUtenteSDC and SuperUser = 1
end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


 



ALTER TRIGGER OnOperatoriInsert ON [dbo].[Operatori] 
FOR INSERT
AS



---- associo d'ufficio
---- ad agli utenti super-user il nuovo operatore

declare @CodiceUtenteSDC varchar(16)

declare @op as varchar(16)
select @op = inserted.CodiceOperatoreSDC from inserted

declare ut_cursor cursor local for
	select CodiceUtenteSDC
	from Utenti  WITH (UPDLOCK)
	where StatoBilateraliUtente = 1 and SuperUser = 1

open ut_cursor
	
fetch next from ut_cursor into @CodiceUtenteSDC
while @@fetch_status = 0 
begin
	-- cintura e bretelle ?
	if not exists
	(
		select 
		* 
		from
		RelOperatoriUtenti
		where 
		CodiceUtenteSDC = @op
		and CodiceUtenteSDC = @CodiceUtenteSDC
	)
	and exists
	(
		select 
		* 
		from
		Utenti
		where 
		CodiceUtenteSDC = @CodiceUtenteSDC
	)
	begin

		insert into RelOperatoriUtenti
		(
		CodiceUtenteSDC, 
		CodiceOperatoreSDC, 
		Amministratore, 
		Abilitato, 
		TSIniValidita, 
		TSEndValidita, 
		CodiceRuolo, 
		TSModifica,
		SuperUser
		)
		values
		(
		@CodiceUtenteSDC, 
		@op, 
		0, -- Amministratore
		1, -- Abilitato, 
		getdate(), 
		convert(datetime, '20301231', 112),
		'root', -- CodiceRuolo
		getdate(),
		1 --SuperUser
		)
	end
	fetch next from ut_cursor into @CodiceUtenteSDC
end

close ut_cursor
deallocate ut_cursor


-- chiamata 4499
---- associo d'ufficio
---- ad ATrebbi il nuovo operatore

--declare @op as varchar(16)
--select @op = inserted.CodiceOperatoreSDC from inserted

--if not exists
--(
--	select 
--	* 
--	from
--	RelOperatoriUtenti
--	where 
--	CodiceUtenteSDC = @op
--	and CodiceUtenteSDC = 'ATREBBI'
--)
--and exists
--(
--	select 
--	* 
--	from
--	Utenti
--	where 
--	CodiceUtenteSDC = 'ATREBBI'
--)
--begin
--
--	INSERT INTO RelOperatoriUtenti
--	(
--	CodiceUtenteSDC, 
--	CodiceOperatoreSDC, 
--	Amministratore, 
--	Abilitato, 
--	TSIniValidita, 
--	TSEndValidita, 
--	CodiceRuolo, 
--	TSModifica
--	)
--	VALUES 
--	(
--	'ATREBBI', 
--	@op, 
--	0, 
--	1, 
--	convert(datetime,convert(varchar,getdate(),112)), -- oggi
--	convert(datetime,convert(varchar,getdate(),112)) + 10000, -- tra 10000 giorni
--	'root', 
--	getdate()
--	)

--end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_FileMGP')
	DROP INDEX dbo.FileMGP.IX_FileMGP

 CREATE  INDEX [IX_FileMGP] ON [dbo].[FileMGP]([TSCreazione]) ON [PRIMARY]
GO

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_FileMGP_TSFlusso')
	DROP INDEX dbo.FileMGP.IX_FileMGP_TSFlusso
 CREATE  INDEX [IX_FileMGP_TSFlusso] ON [dbo].[FileMGP]([TSFlusso]) ON [PRIMARY]
GO

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_FileOperatoriPerAdmin')
	DROP INDEX dbo.FileOperatori.IX_FileOperatoriPerAdmin
 CREATE  INDEX [IX_FileOperatoriPerAdmin] ON [dbo].[FileOperatori]([TSCreazione], [TSDownload], [CodiceOperatoreSDC]) ON [PRIMARY]
GO


DROP INDEX dbo.FileOperatori.IX_FileOperatori
CREATE NONCLUSTERED INDEX IX_FileOperatori ON dbo.FileOperatori ( CodiceOperatoreSDC,TSCreazione ) 

DROP INDEX dbo.FileOperatori.IX_FileOperatori_1  
CREATE NONCLUSTERED INDEX IX_FileOperatori_1 ON dbo.FileOperatori ( CodiceTipoFile,NomeFile )


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SmallDateTimeFromYYMMDD]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[SmallDateTimeFromYYMMDD]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_UnitaContratto5]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[tab_UnitaContratto5]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE FUNCTION [dbo].[SmallDateTimeFromYYMMDD] (@s as varchar (6))  
RETURNS smalldatetime AS  
BEGIN 
	return convert(smalldatetime, @s, 112)
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[SmallDateTimeFromYYMMDD]  TO [bil_dbo]
GO

GRANT  EXECUTE  ON [dbo].[SmallDateTimeFromYYMMDD]  TO [bil_user]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE  function tab_UnitaContratto5(@di datetime, @df datetime, @TSModifica datetime, @IdContr  int)
returns @retUnitaContratto table (	
	IdContratto int NOT NULL ,
	CodiceUnitaSDC varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	CategoriaUnitaSDC varchar(1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
	DataInizioValidita smalldatetime ,
	DataFineValidita smalldatetime ,
	TSModifica datetime,
	DataInizioValiditaUnita smalldatetime ,
	DataFineValiditaUnita smalldatetime ,
	UnitaDelContrattoValidata bit ,
	UnitaAssegnataOpCedente bit ,
	UnitaAssegnataOpAcquirente bit ,
	PrioritaBilanciamentoForzato int ,
	TrCC bit,
	TrUC bit,
	VUC  bit)
as
begin
	declare	
		@IdContratto int,
		@CodiceUnitaSDC  varchar(16),
		@CategoriaUnitaSDC varchar(1),
		@DataInizioValidita smalldatetime,
		@DataFineValidita smalldatetime,
		@DataInizioValiditaUnita smalldatetime,
		@DataFineValiditaUnita smalldatetime,
		@UnitaDelContrattoValidata bit,
		@UnitaAssegnataOpCedente bit,
		@UnitaAssegnataOpAcquirente bit,
		@PrioritaBilanciamentoForzato int,
		@TrCC bit,
		@TrUC bit,
		@VUC bit

	declare unita_cursor cursor for
		
	select 
	@IdContr IdContratto,
	t.CodiceUnitaSDC,
	t.CategoriaUnitaSDC,
	@di DataInizioValidita,
	@df DataFineValidita,
	@TSModifica TSModifica,
	t.DataInizioValiditaUnita,
	t.DataFineValiditaUnita,
	1 UnitaDelContrattoValidata,
	t.UnitaAssegnataOpCedente,
	t.UnitaAssegnataOpAcquirente,
	0 PrioritaBilanciamentoForzato,
	t.TrCC,
	t.TrUC,
	t.VUC
	from 
	(
		select 
		CodiceUnitaSDC, 
		CategoriaUnitaSDC, 
		DataInizioValidita DataInizioValiditaUnita,
		DataFineValidita  DataFineValiditaUnita,
		TrCC,
		TrUC,
		VUC,
		sum(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,
		sum(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
		from 
		(
			select 
			ur.CodiceUnitaSDC, 
			ur.CategoriaUnitaSDC, 
			ur.DataInizioValidita,
			ur.DataFineValidita,
			ur.TrUC, 
			ur.VUC,
			1 UnitaAssegnataOpCedente, 
			0 UnitaAssegnataOpAcquirente,
			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC
			from unitrelate ur
			inner join 
			contratto c
			on
			c.IdContratto = @IdContr
			and c.DataInizioValidita <= @df and c.DataFineValidita >= @di
			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and ur.TipoUnita in ('P', 'M')
			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
			and ur.Abilitata = 1
		union
			select 
			ur.CodiceUnitaSDC, 
			ur.CategoriaUnitaSDC, 
			ur.DataInizioValidita,
			ur.DataFineValidita,
			ur.TrUC, 
			ur.VUC,
			0 UnitaAssegnataOpCedente, 
			1 UnitaAssegnataOpAcquirente,
			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC
			from unitrelate ur
			inner join 
			contratto c
			on
			c.IdContratto = @IdContr
			and c.DataInizioValidita <= @df and c.DataFineValidita >= @di
			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and ur.TipoUnita in ('C', 'M')
			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
			and ur.Abilitata = 1
	) u
	group by CodiceUnitaSDC, 
	CategoriaUnitaSDC,
	DataInizioValidita,
	DataFineValidita,
	TrUC,
	VUC,
	TrCC
	)
	t
	order by CodiceUnitaSDC, CategoriaUnitaSDC

	open unita_cursor
		-- Perform the first fetch.
	fetch next from unita_cursor into
		@IdContratto,
		@CodiceUnitaSDC,
		@CategoriaUnitaSDC,
		@DataInizioValidita ,
		@DataFineValidita ,
		@TSModifica,
		@DataInizioValiditaUnita ,
		@DataFineValiditaUnita ,
		@UnitaDelContrattoValidata,
		@UnitaAssegnataOpCedente,
		@UnitaAssegnataOpAcquirente,
		@PrioritaBilanciamentoForzato,
		@TrCC,
		@TrUC,
		@VUC

	

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	while @@FETCH_STATUS = 0
	begin
	-- Copy to the result of the function the required columns.
	insert @retUnitaContratto values(
		@IdContratto,
		@CodiceUnitaSDC,
		@CategoriaUnitaSDC,
		@DataInizioValidita ,
		@DataFineValidita ,
		@TSModifica,
		@DataInizioValiditaUnita ,
		@DataFineValiditaUnita ,
		@UnitaDelContrattoValidata ,
		@UnitaAssegnataOpCedente ,
		@UnitaAssegnataOpAcquirente ,
		@PrioritaBilanciamentoForzato ,
		@TrCC,
		@TrUC,
		@VUC)
	   -- This is executed as long as the previous fetch succeeds.
	   fetch next from unita_cursor  into
		@IdContratto,
		@CodiceUnitaSDC,
		@CategoriaUnitaSDC,
		@DataInizioValidita ,
		@DataFineValidita ,
		@TSModifica,
		@DataInizioValiditaUnita ,
		@DataFineValiditaUnita ,
		@UnitaDelContrattoValidata ,
		@UnitaAssegnataOpCedente ,
		@UnitaAssegnataOpAcquirente ,
		@PrioritaBilanciamentoForzato ,
		@TrCC,
		@TrUC,
		@VUC
	end
	close unita_cursor
	deallocate unita_cursor
	return
end









GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO






print 'UPDATE ReportQueries'

delete from ReportQueries


insert ReportQueries 
values ('SBIL', 'Report Sbilanciamento Orario', 
'<Report Descrizione="Report Sbilanciamento Orario">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportSbilanciamentoOrario"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	
	<out rptType="xls" rptLanguage="it-it">
		<col dbColName="DataProgramma"     rptWidth="1500" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto"   rptWidth="3000" rptColName="Codice Contratto" />
		<col dbColName="CRN"               rptWidth="2400" rptColName="CRN" />
		<col dbColName="Cedente"           rptWidth="2000" rptColName="Cedente"  />
		<col dbColName="Acquirente"        rptWidth="2000" rptColName="Acquirente"  />
		<col dbColName="Ora"               rptWidth="700"  rptColName="Ora"               rptNumberFormat="00" />
		<col dbColName="Bilanciato"        rptWidth="1000" rptColName="Bilanciato"        rptNumberFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptWidth="2000" rptColName="SbilanciamentoMWh" rptNumberFormat="#,##0.000" />
	</out>


</OutputFormat>
</Report>', 
'A')




insert into reportqueries
values ('CTRFLG', 'Gestione taglio su contratti', 
'<Report Descrizione="Report Gestione Taglio su Contratti">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportContrattiFlaggati"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti"   rptColName="NumContratti" />
	</out>
	

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>

	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="NumContratti" rptColName="Num. Contratti" />
	</out>


	<out rptType="xls">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio" rptWidth="4000"  />
		<col dbColName="NumContratti"   rptColName="Num. Contratti"  rptWidth="2500" rptNumberFormat="#,##0"/>
	</out>

</OutputFormat>
</Report>', 'A'
)

insert into reportqueries
values ('NRGSBILPGM', 'Energia di Sbilancio a Programma', 
'<Report Descrizione="Report Energia di Sbilancio">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaSbilancioProgramma"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
<Parameter Label="Soglia Sbilanciamento MWh:" Html="Text" ID="Soglia" NomeSql="@SogliaSbilMWh" TipoNET="double" TipoSql="float"/>   
<Parameter Label="CRN:" Html="Text" ID="CRN" NomeSql="@CRN" TipoNET="String" TipoSql="varchar(30)"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="Operatore" rptColName="Operatore_Resp"  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>



	<out rptType="xls">
		<col dbColName="Operatore"       rptWidth="2500" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptWidth="3500" rptColName="Codice Contratto" />
		<col dbColName="CRN"             rptWidth="3500" rptColName="CRN"  />
		<col dbColName="Cedente"         rptWidth="2500" rptColName="Cedente"  />
		<col dbColName="Acquirente"      rptWidth="2500" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio"  rptWidth="2500" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01"    rptWidth="1500" rptColName="SbilMWhOra01" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra02"    rptWidth="1500" rptColName="SbilMWhOra02" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra03"    rptWidth="1500" rptColName="SbilMWhOra03" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra04"    rptWidth="1500" rptColName="SbilMWhOra04" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra05"    rptWidth="1500" rptColName="SbilMWhOra05" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra06"    rptWidth="1500" rptColName="SbilMWhOra06" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra07"    rptWidth="1500" rptColName="SbilMWhOra07" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra08"    rptWidth="1500" rptColName="SbilMWhOra08" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra09"    rptWidth="1500" rptColName="SbilMWhOra09" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra10"    rptWidth="1500" rptColName="SbilMWhOra10" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra11"    rptWidth="1500" rptColName="SbilMWhOra11" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra12"    rptWidth="1500" rptColName="SbilMWhOra12" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra13"    rptWidth="1500" rptColName="SbilMWhOra13" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra14"    rptWidth="1500" rptColName="SbilMWhOra14" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra15"    rptWidth="1500" rptColName="SbilMWhOra15" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra16"    rptWidth="1500" rptColName="SbilMWhOra16" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra17"    rptWidth="1500" rptColName="SbilMWhOra17" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra18"    rptWidth="1500" rptColName="SbilMWhOra18" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra19"    rptWidth="1500" rptColName="SbilMWhOra19" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra20"    rptWidth="1500" rptColName="SbilMWhOra20" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra21"    rptWidth="1500" rptColName="SbilMWhOra21" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra22"    rptWidth="1500" rptColName="SbilMWhOra22" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra23"    rptWidth="1500" rptColName="SbilMWhOra23" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra24"    rptWidth="1500" rptColName="SbilMWhOra24" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra25"    rptWidth="1500" rptColName="SbilMWhOra25" rptNumberFormat="#,##0.000" />
	</out>


</OutputFormat>
</Report>',
'A'
)

insert into reportqueries
values ('NRGTAGLIO', 'Entita` Taglio sui Programmi non flaggati', 
'<Report Descrizione="Entita` Taglio sui Programmi non flaggati">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEntitaTaglio"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>

	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>


	<out rptType="xls">
		<col dbColName="CRN"                 rptWidth="3500" rptColName="CRN"  />
		<col dbColName="OperatoreCedente"    rptWidth="2500" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptWidth="2500" rptColName="Acquirente"  />
		<col dbColName="T1"                  rptWidth="1500" rptColName="TaglioOra1"  rptNumberFormat="#,##0.000" />
		<col dbColName="T2"                  rptWidth="1500" rptColName="TaglioOra2"  rptNumberFormat="#,##0.000" />
		<col dbColName="T3"                  rptWidth="1500" rptColName="TaglioOra3"  rptNumberFormat="#,##0.000" />
		<col dbColName="T4"                  rptWidth="1500" rptColName="TaglioOra4"  rptNumberFormat="#,##0.000" />
		<col dbColName="T5"                  rptWidth="1500" rptColName="TaglioOra5"  rptNumberFormat="#,##0.000" />
		<col dbColName="T6"                  rptWidth="1500" rptColName="TaglioOra6"  rptNumberFormat="#,##0.000" />
		<col dbColName="T7"                  rptWidth="1500" rptColName="TaglioOra7"  rptNumberFormat="#,##0.000" />
		<col dbColName="T8"                  rptWidth="1500" rptColName="TaglioOra8"  rptNumberFormat="#,##0.000" />
		<col dbColName="T9"                  rptWidth="1500" rptColName="TaglioOra9"  rptNumberFormat="#,##0.000" />
		<col dbColName="T10"                 rptWidth="1500" rptColName="TaglioOra10" rptNumberFormat="#,##0.000" />
		<col dbColName="T11"                 rptWidth="1500" rptColName="TaglioOra11" rptNumberFormat="#,##0.000" />
		<col dbColName="T12"                 rptWidth="1500" rptColName="TaglioOra12" rptNumberFormat="#,##0.000" />
		<col dbColName="T13"                 rptWidth="1500" rptColName="TaglioOra13" rptNumberFormat="#,##0.000" />
		<col dbColName="T14"                 rptWidth="1500" rptColName="TaglioOra14" rptNumberFormat="#,##0.000" />
		<col dbColName="T15"                 rptWidth="1500" rptColName="TaglioOra15" rptNumberFormat="#,##0.000" />
		<col dbColName="T16"                 rptWidth="1500" rptColName="TaglioOra16" rptNumberFormat="#,##0.000" />
		<col dbColName="T17"                 rptWidth="1500" rptColName="TaglioOra17" rptNumberFormat="#,##0.000" />
		<col dbColName="T18"                 rptWidth="1500" rptColName="TaglioOra18" rptNumberFormat="#,##0.000" />
		<col dbColName="T19"                 rptWidth="1500" rptColName="TaglioOra19" rptNumberFormat="#,##0.000" />
		<col dbColName="T20"                 rptWidth="1500" rptColName="TaglioOra20" rptNumberFormat="#,##0.000" />
		<col dbColName="T21"                 rptWidth="1500" rptColName="TaglioOra21" rptNumberFormat="#,##0.000" />
		<col dbColName="T22"                 rptWidth="1500" rptColName="TaglioOra22" rptNumberFormat="#,##0.000" />
		<col dbColName="T23"                 rptWidth="1500" rptColName="TaglioOra23" rptNumberFormat="#,##0.000" />
		<col dbColName="T24"                 rptWidth="1500" rptColName="TaglioOra24" rptNumberFormat="#,##0.000" />
		<col dbColName="T25"                 rptWidth="1500" rptColName="TaglioOra25" rptNumberFormat="#,##0.000" />
	</out>


</OutputFormat>
</Report>',
'A'
)

insert into reportqueries
values ('NRGCNTR', 'Energia Contratti Flaggati', 
'<Report Descrizione="Report Energia Contratti Flaggati">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaContrattiFlaggati"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>


	<out rptType="xls">
		<col dbColName="GestioneTaglio"   rptWidth="3500" rptColName="Gestione Taglio"     />
		<col dbColName="QtyMWhProduzione" rptWidth="2400" rptColName="QtyMWhProduzione"    rptNumberFormat="#,##0.000" />
		<col dbColName="QtyMWhProduzione" rptWidth="2400" rptColName="QtyMWhProduzioneMGP" rptNumberFormat="#,##0.000" />
		<col dbColName="QtyMWhConsumo"    rptWidth="2400" rptColName="QtyMWhConsumo"       rptNumberFormat="#,##0.000" />
		<col dbColName="QtyMWhConsumo"    rptWidth="2400" rptColName="QtyMWhConsumoMGP"    rptNumberFormat="#,##0.000" />
	</out>


</OutputFormat>
</Report>', 'A'
)

insert into ReportQueries 
values ('NRGSBIL', 'Energia di Sbilancio', 
'<Report Descrizione="Report Energia di Sbilancio">    
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaSbilancio"/>    
<InputParameters>     
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>     
</InputParameters>    
<OutputFormat>   
	<!--   
	supporta:  
		out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")   
		out/col[@rptColFormat=''000'']  - per formattare le singole colonne   
	-->   
	<out rptType="xml">    
		<col dbColName="DataProgramma" rptColName="DataFlusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />    
		<col dbColName="CRN" rptColName="CRN"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />  
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />      
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>
	<!--    supporta:   
		out[@rptLanguage=''zz-zz'']    
			- per formattare nella lingua di Excel (default it-it)   out[@rptSeparator='';'']       
			- per separare con , (in inglese) o con ; (in italiano) (default ; )   
		out/col[@rptColFormat=''000''] 
			- per formattare la singola colonna (default null)   
		out/col[@rptColQuote="''"]    
			- per ingannare Excel: non interpreta il campo come numerico (default non usare il quote)   
	-->   
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>     
	<!--   
	supporta:   
	out[@rptLanguage=''zz-zz'']    	- per impostare la lingua con cui si produce il file (default it-it).   
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)   
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)   
	-->   
	<out rptType="txt" rptLanguage="it-it" >    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />      
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out> 
	<!--    out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente   -->   
	<out rptType="html">    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="CRN"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>         



	<out rptType="xls">    
		<col dbColName="DataProgramma"     rptWidth="1500" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto"   rptWidth="3500" rptColName="Codice Contratto" />    
		<col dbColName="CRN"               rptWidth="3500" rptColName="CRN"  />    
		<col dbColName="Cedente"           rptWidth="2500" rptColName="Cedente"  />    
		<col dbColName="Acquirente"        rptWidth="2500" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio"    rptWidth="2000" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora"               rptWidth="1000" rptColName="Ora"                  rptNumberFormat="00" />    
		<col dbColName="QtyMWhProd"        rptWidth="2000" rptColName="QtyMWhProd"           rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhCons"        rptWidth="2000" rptColName="QtyMWhCons"           rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhProdT"       rptWidth="2000" rptColName="QtyMWhProdDopoTaglio" rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhConsT"       rptWidth="2000" rptColName="QtyMWhConsDopoTaglio" rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhProdMGP"     rptWidth="2000" rptColName="QtyMWhProdMGP"        rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhConsMGP"     rptWidth="2000" rptColName="QtyMWhConsMGP"        rptNumberFormat="#,##0.000" />    
		<col dbColName="SbilanciamentoMWh" rptWidth="2000" rptColName="SbilanciamentoMWh"    rptNumberFormat="#,##0.000" />   
	</out>         


	</OutputFormat>  
</Report>',
'A')



---------------------------------------------------------------------------------------


INSERT INTO DBVersion (Version) VALUES('2.3.3.0')

INSERT INTO DBHistory (Version, Patch, UpgradeTS, Notes)
VALUES('2.3.3.0', NULL, getdate(), 'Installazione Versione 2.3.3.0')
