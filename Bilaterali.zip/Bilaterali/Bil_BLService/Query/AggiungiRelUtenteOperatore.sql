-- lanciare SQL Query Analizer
-- connettersi al DB engine del PC in cui e` installato il DB
-- selezionare il DB piovra (tramite la combo-box nella tool bar)
-- e fare tanti INSERT INTO quante sono le relazioni utenti/operatori da
-- inserire.

-- Per inserire una relazione tra un utente e un operatore 
-- (entrambi gia` abiliatati nei bilaterali)
-- bisogna sostituire a 
-- @CodiceUtenteSDC il codice dell'utente es 'IDSTEFANI' (tutto maiuscolo)
-- @CodiceOperatoreSDC il codice dell'operatore es 'IDELSAG' (tutto maiuscolo)
-- la relazione varra` dal 1 gennaio 2004 al primo gennaio 2005
INSERT INTO RelOperatoriUtenti
(CodiceUtenteSDC, CodiceOperatoreSDC, Amministratore, Abilitato, TSIniValidita, TSEndValidita, CodiceRuolo, TSModifica)
VALUES
(@CodiceUtenteSDC, @CodiceOperatoreSDC, 0, 0, '1/1/2004', '1/1/2005', 'root', getdate())