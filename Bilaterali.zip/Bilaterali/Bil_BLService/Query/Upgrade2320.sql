BEGIN TRANSACTION

SET QUOTED_IDENTIFIER ON
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON

COMMIT
BEGIN TRANSACTION
ALTER TABLE dbo.SDC_Unita
	DROP CONSTRAINT FK_SDC_Unita_SDC_Operatori1
GO
COMMIT
BEGIN TRANSACTION
COMMIT

GO

------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCorrispettivi]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportXmlCorrispettivi]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCorrispettivi2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportXmlCorrispettivi2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlTitolari]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportXmlTitolari]
GO


------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spChiudiMercato]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[spChiudiMercato]
GO


CREATE PROCEDURE dbo.spChiudiMercato
	@d as datetime
AS

-- declare @d as datetime
-- set @d = '10/12/2004'

-- qui per evitare problemi cancello gli eventuali
-- SbilMGPalCP gia` valorizzati
-- (es ha chiuso e riaperto il mercato)
-- In realta` questa update e` solo per tranquillita` dato
-- che spRiapriMercato fa la stessa cosa.
update ProgrammaOrario
set SbilMGPalCP = NULL
where 
DataProgramma = @d
and SbilMGPalCP is not null


update ProgrammaOrario
-- questo round e` voluto per evitare di vedere cifre come 3E-16
set SbilMGPalCP = round(T.SbilMGPalCP, 5)
from ProgrammaOrario PO
inner join
(
	select 
	POU.IdContratto, 
	POU.DataProgramma,
	POU.PeriodoRilevante, 
	sum(QtyMWhAssegnataMGP * PR.CoefficienteDiPerdita / U.CoefficientePerdita) SbilMGPalCP
	from 
	ProgrammaOrarioPerUnita POU
	
	inner join SDC_Unita U
	on  U.CodiceUnitaSDC = POU.CodiceUnitaSDC
	and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
	
	inner join SDC_PuntiDiScambioRilevanti PR
	on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC
	
	where POU.DataProgramma = @d
	and   POU.QtyMWhAssegnataMGP is not null
	
	group by
	POU.IdContratto,
	POU.DataProgramma,
	POU.PeriodoRilevante
) T
on  PO.IdContratto      = T.IdContratto
and PO.DataProgramma    = T.DataProgramma
and PO.PeriodoRilevante = T.PeriodoRilevante
where PO.DataProgramma = @d


update SessioneBilaterali 
set 
DataChiusuraMGP=getdate()
where DataProgramma=@d

GO

GRANT  EXECUTE  ON [dbo].[spChiudiMercato]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spChiudiMercato]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spChiudiMercato]  TO [bil_dbo]
GO

------------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportCapacitaTrasporto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[spReportCapacitaTrasporto]
GO


CREATE   PROCEDURE [dbo].[spReportCapacitaTrasporto] 
	@DataProgrammaMin as smalldatetime,
 	@DataProgrammaMax as smalldatetime,
 	@Transitorio as int,
	@Operatore as varchar(16)
AS

set nocount on

--declare
--	@DataProgrammaMin as smalldatetime,
-- 	@DataProgrammaMax as smalldatetime,
--	@Operatore as varchar(16)

--set @DataProgrammaMin=convert(datetime, '20050408', 112)
--set @DataProgrammaMax=convert(datetime, '20050408', 112)
--set @Operatore=''

--questo report rischia di estrarre cosi' tanti dati da rendere necessario
--la read uncommitted
set transaction isolation level read uncommitted

select
X.CodiceOperatoreSDC,
O.RagioneSociale,
C.CRN,
C.CodiceContratto,
X.Corrispettivo

from
(
	select 
	CodiceOperatoreSDC,
	IdContratto,
	Corrispettivo = sum(T.Corr)

	from
	(
		select
		POU.CodiceOperatoreSDC,
		POU.IdContratto,
		Qty = cast(QtyMGP as decimal(16,3)),             -- la quantita` in MWh e` a 3 cifre
	
		Corr = cast(
			case when TipoUnita='C' and ZonaType<>'VIRT' then
				ROUND(-1 * QtyMGP * ROUND(PrezzoUnico,  6), 2)
			else
				ROUND(-1 * QtyMGP * ROUND(PrezzoZonale, 6), 2)
			end
			as decimal(16, 2))
		
		from 
		(
			select 
			C.CodiceOperatoreSDC,
			C.IdContratto,
			QtyMGP       = POU.QtyMWhAssegnataMGP * UZ.PSCoefficienteDiPerdita / UZ.CoefficientePerdita,
			UZ.TipoUnita,
			PrezzoUnico  = PrezzoUnitario.Prezzo,
			PrezzoZonale = PrezzoZonale.Prezzo,
			TipoZona ZonaType
			
			from 
			ProgrammaOrarioPerUnita POU
			
			inner join Contratto C
			on C.IdContratto = POU.IdContratto 
			
			inner join SDC_Unita_TipoZona UZ
			on  UZ.CodiceUnitaSDC    = POU.CodiceUnitaSDC
			and UZ.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
			
			inner join PrezzoUnitario
			on  PrezzoUnitario.Data             = POU.DataProgramma
			and PrezzoUnitario.PeriodoRilevante = POU.PeriodoRilevante
			
			inner join PrezzoZonale
			on  PrezzoZonale.Data             = POU.DataProgramma
			and PrezzoZonale.PeriodoRilevante = POU.PeriodoRilevante
			and PrezzoZonale.CodiceZonaSDC    = UZ.CodiceZonaSDC
	
			where 
			1=1
			and POU.QtyMWhAssegnataMGP is not null       -- e` un report da fare A FINE MERCATO
			and POU.DataProgramma >= @DataProgrammaMin
			and POU.DataProgramma <= @DataProgrammaMax
			and (C.CodiceOperatoreSDC = @Operatore or @Operatore = '')
		) POU
	) T
	group by 
	T.CodiceOperatoreSDC, 
	T.IdContratto
) X,
SDC_Operatori O,
Contratto C
where 
1=1
and X.CodiceOperatoreSDC = O.CodiceOperatoreSDC
and C.IdContratto = X.IdContratto
and (X.CodiceOperatoreSDC = @Operatore or @Operatore = '')

order by 
X.CodiceOperatoreSDC,
C.CRN


GO

GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [bil_dbo]
GO




------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCCT_C]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[spReportXmlCCT_C]
GO


CREATE PROCEDURE dbo.spReportXmlCCT_C
	@DataFlusso as datetime
-- sono i CCT per i cedenti.
-- ossia per le offerte con qty dopo mercato > 0
-- che per definizione sono a prezzo zonale
AS

--declare @DataFlusso as datetime
--set @DataFlusso = '17/3/2005'

declare @ErrorSave int
set @ErrorSave = 0


if Object_Id('tempdb..#t') is Not Null
	drop table #t

-- tabella che contiene i contratti per i quali, nella data di flusso/periodo rilevante,
-- si hanno una o piu` unita` di consumo estere oppure
-- una o piu` unita` mista che consuma
-- Queste unita` pagano il prezzo ZONALE.
-- Inoltre queste unita' dovrebbero appartenere tutte alla stessa zona.
create table #t
(
	IdContratto        int,
	DataProgramma      datetime,
	PeriodoRilevante   tinyint,
	PrezzoZonale       decimal(19,6),
	UnitaSuZoneDiverse varchar(1)
)
-- indice in #t.
-- Se esistono due unita` per lo stesso contratto
-- l'indice fa fallire la sp sul doppio inserimento
create unique clustered index #pkt on #t
(
	IdContratto,
	DataProgramma,
	PeriodoRilevante
)

insert into #t
(
	IdContratto,
	DataProgramma,
	PeriodoRilevante,
	PrezzoZonale,
	UnitaSuZoneDiverse
)
	select
	IdContratto, 
	DataProgramma, 
	PeriodoRilevante, 
	max(Prezzo) PrezzoZonale,
	UnitaSuZoneDiverse = case max(Prezzo) - min(Prezzo) when 0 then '' else 'S' end 
	from
	(
		select
		POU.IdContratto,
		POU.DataProgramma,
		POU.PeriodoRilevante,
		PZ.Prezzo
		
		from ProgrammaOrarioPerUnita POU
		
		inner join SDC_Unita_TipoZona U
		on  U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
	
		inner join PrezzoZonale PZ
		on PZ.CodiceZonaSDC = U.CodiceZonaSDC
		and PZ.Data = POU.DataProgramma
		and PZ.PeriodoRilevante = POU.PeriodoRilevante
		
		where 
		1=1
		and POU.DataProgramma=@DataFlusso
		and POU.QtyMWhAssegnataMGP < 0
		and 
		( 
			(U.TipoUnita = 'M') or (U.TipoUnita='C' and U.TipoZona='VIRT')
		)
	) T
	group by
	DataProgramma, PeriodoRilevante, IdContratto

-- select * from #t

-- questa e` la query da ritornare per i CCT.
-- Si cercano le unita di produzione (quantita` assegnata > 0)
-- si calcola la quantita` al CP
-- e si moltiplica per il prezzo - unico per i contratti "normali"
-- prezzo zonale dell'unita` di consumo estera per i contratti di export.
-- o per il contratti con unita` di consumo miste
select 
Contratto.CodiceOperatoreSDCCedente Op,
Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

convert(decimal(15,3), ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP 
	/ SDC_Unita.CoefficientePerdita * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita)
	QtyMWh,

convert(decimal(15,2), ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP 
	/ SDC_Unita.CoefficientePerdita * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita 
	-- applico il prezzo zonale dell'unita` di export/mista che consuma se esiste in #t, altrimenti
	-- il prezzo unico
	* (isnull(#t.PrezzoZonale, PrezzoUnitario.Prezzo) - PrezzoZonale.Prezzo))
	CCTOfferta

from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

-- vado a ricercare, se esiste, in #t il contratto:
-- se non esiste significa che devo applicare il PrezzoUnico
-- se esiste devo applicare il prezzo zonale per i contratti con unita di consumo estere o unita miste che consumano
-- (che e` estera)
left outer join #t
on  #t.IdContratto      = ProgrammaOrarioPerUnita.IdContratto
and #t.DataProgramma    = ProgrammaOrarioPerUnita.DataProgramma
and #t.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

where 
not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
and ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP > 0           -- solo unita` che producono
and ProgrammaOrarioPerUnita.DataProgramma = @DataFlusso

order by 
Contratto.CodiceOperatoreSDCCedente,
Contratto.CRN,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.PeriodoRilevante
GO


GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [bil_dbo]
GO





------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spRiapriMercato]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[spRiapriMercato]
GO


CREATE PROCEDURE dbo.spRiapriMercato
	@d as datetime
AS

update SessioneBilaterali 
set 
DataChiusuraMGP=null
where DataProgramma=@d

-- declare @d as datetime
-- set @d = '10/12/2004'

-- Se si riapre il mercato ci sara` qualche ragione.
-- Esempio si deve rigirare tutto.
-- Meglio dunque fare pulizia.
update ProgrammaOrario
set SbilMGPalCP = null
where 
DataProgramma = @d
and SbilMGPalCP is not null
GO

GRANT  EXECUTE  ON [dbo].[spRiapriMercato]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spRiapriMercato]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spRiapriMercato]  TO [bil_dbo]
GO


------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spUnitaConsumoEstere]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spUnitaConsumoEstere]
GO


CREATE PROCEDURE dbo.spUnitaConsumoEstere

as 
	select
	u.CodiceUnitaSDC,
	z.CodiceZonaSDC
	from sdc_unita u 
	inner join SDC_PuntiDiScambioRilevanti ps 
	on ps.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC 
	inner join sdc_zone z 
	on ps.CodiceZonaSDC = z.CodiceZonaSDC 
	where 
	u.TipoUnita='C'
	and z.type='VIRT'

GO


GRANT  EXECUTE  ON [dbo].[spUnitaConsumoEstere]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spUnitaConsumoEstere]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spUnitaConsumoEstere]  TO [bil_dbo]
GO




------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SDC_Unita_TipoZona]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[SDC_Unita_TipoZona]
GO


CREATE VIEW dbo.SDC_Unita_TipoZona
AS

SELECT
u.*, 
z.Type AS TipoZona,
z.CodiceZonaSDC,
ps.CoefficienteDiPerdita PSCoefficienteDiPerdita

FROM         
dbo.SDC_Unita u 

INNER JOIN dbo.SDC_PuntiDiScambioRilevanti ps 
ON ps.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC 

INNER JOIN dbo.SDC_Zone z 
ON ps.CodiceZonaSDC = z.CodiceZonaSDC

GO

GRANT  SELECT  ON [dbo].[SDC_Unita_TipoZona]  TO [public]
GO

------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------


print 'UPDATE Version ON DBVersion'
UPDATE DBVersion SET Version = '2.3.2.0'

print 'UPDATE DBHistory'
INSERT INTO DBHistory (Version, Patch, UpgradeTS, Notes)
VALUES('2.3.2.0', NULL, getdate(), 'Upgrade alla Versione 2.3.2.0')

PRINT 'Il database e` aggiornato alla versione 2.3.2.0 !'

