use [Bilaterali]
GO

alter table dbo.Operatori disable trigger all

INSERT INTO Ruoli (CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES ('root', 'root', getdate())
INSERT INTO Ruoli (CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES ('Fatt', 'Fatturazione', GETDATE())
INSERT INTO Ruoli (CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES ('OpEn', 'Operatore Energia', GETDATE())
INSERT INTO Ruoli (CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES ('OpAn', 'Operatore Anagrafica', GETDATE())

--Inserimento funzioni
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('FA', 'Fatturazione', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('GA', 'Gestione Anagrafica', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('GC', 'Gestione Contratti', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('PC', 'Pannello di Controllo', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('RP', 'Reportistica', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('root', 'root', getdate())

--Inserimento relazione ruoli funzioni
--Root Abilitato a tutte le funzioni
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('FA', 'root', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('GA', 'root', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('GC', 'root', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('PC', 'root', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('RP', 'root', GETDATE())
--Fatt Abilitato alle funzioni di Fatturazione e Reportistica
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('FA', 'Fatt', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('RP', 'Fatt', GETDATE())
--OpEn Abilitato alle funzioni di Pannello Controllo, Reportistica e Gestione Contratti
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('PC', 'OpEn', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('RP', 'OpEn', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('GC', 'OpEn', GETDATE()) 
--OpAn Abilitato alla funzione di Gestione Anagrafica
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('GA', 'OpAn', GETDATE())


-- script per inizializzare il DB NUOVO
-- con un operatore di default "root"
-- e con un utente di default "root" / "root"

-- creo operatore "root"
INSERT INTO SDC_Operatori
(
CodiceOperatoreSDC, 
RagioneSociale, 
Indirizzo1, 
Indirizzo2, 
Citta, 
Nazione, 
CodiceFiscale, 
PartitaIva, 
Fax, 
Email, 
ReferenteAmministrativo, 
SedeAmministrativa, 
Abilitato, 
TSModifica, 
ResponsabileAggiornamento
)
VALUES
('root', 'root', '', '', '', '', '', '', '', '', '', '', 1, getdate(), '')



-- lo associo ai bilaterali
INSERT INTO Operatori
(
CodiceOperatoreSDC, 
StatoBilateraliOperatore, 
TSModifica,
Amministratore
)
VALUES
('root', 1, getdate(), 1)

-- creo l'utente root / root
INSERT INTO SDC_Utenti
(
CodiceUtenteSDC, 
Nome, 
Cognome, 
Telefono, 
Fax, 
Email, 
DN, 
Abilitato, 
Login, 
Pwd, 
Lingua, 
CodiceFiscale, 
TSModifica, 
ResponsabileAggiornamento)
VALUES
('root', 'root', 'root', '', '', '', '', 1, 'root', 'root', 'IT-it', '', getdate(), '')

-- lo associo ai bilaterali
INSERT INTO Utenti
(
CodiceUtenteSDC, 
StatoBilateraliUtente, 
TSModifica
)
VALUES('root', 1, getdate())


-- l'utente root lavora per l'operatore root
INSERT INTO RelOperatoriUtenti
(
[CodiceUtenteSDC], 
[CodiceOperatoreSDC], 
[Amministratore], 
[Abilitato], 
[TSIniValidita], 
[TSEndValidita], 
[CodiceRuolo], 
[TSModifica]
)
VALUES (
'root', 
'root', 
1, 
1, 
convert(datetime,convert(varchar,getdate(),112)), -- oggi
convert(datetime,convert(varchar,getdate(),112)) + 10000, -- tra 10000 giorni
'root', 
getdate())

-- Riempio la tabella delle Ore
INSERT INTO Ore (Ora) VALUES (1)
INSERT INTO Ore (Ora) VALUES (2)
INSERT INTO Ore (Ora) VALUES (3)
INSERT INTO Ore (Ora) VALUES (4)
INSERT INTO Ore (Ora) VALUES (5)
INSERT INTO Ore (Ora) VALUES (6)
INSERT INTO Ore (Ora) VALUES (7)
INSERT INTO Ore (Ora) VALUES (8)
INSERT INTO Ore (Ora) VALUES (9)
INSERT INTO Ore (Ora) VALUES (10)
INSERT INTO Ore (Ora) VALUES (11)
INSERT INTO Ore (Ora) VALUES (12)
INSERT INTO Ore (Ora) VALUES (13)
INSERT INTO Ore (Ora) VALUES (14)
INSERT INTO Ore (Ora) VALUES (15)
INSERT INTO Ore (Ora) VALUES (16)
INSERT INTO Ore (Ora) VALUES (17)
INSERT INTO Ore (Ora) VALUES (18)
INSERT INTO Ore (Ora) VALUES (19)
INSERT INTO Ore (Ora) VALUES (20)
INSERT INTO Ore (Ora) VALUES (21)
INSERT INTO Ore (Ora) VALUES (22)
INSERT INTO Ore (Ora) VALUES (23)
INSERT INTO Ore (Ora) VALUES (24)
INSERT INTO Ore (Ora) VALUES (25)


print 'UPDATE ReportQueries'

delete from ReportQueries


insert ReportQueries 
values ('SBIL', 'Report Sbilanciamento Orario', 
'<Report Descrizione="Report Sbilanciamento Orario">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportSbilanciamentoOrario"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	
	<out rptType="xls" rptLanguage="it-it">
		<col dbColName="DataProgramma"     rptWidth="1500" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto"   rptWidth="3000" rptColName="Codice Contratto" />
		<col dbColName="CRN"               rptWidth="2400" rptColName="CRN" />
		<col dbColName="Cedente"           rptWidth="2000" rptColName="Cedente"  />
		<col dbColName="Acquirente"        rptWidth="2000" rptColName="Acquirente"  />
		<col dbColName="Ora"               rptWidth="700"  rptColName="Ora"               rptNumberFormat="00" />
		<col dbColName="Bilanciato"        rptWidth="1000" rptColName="Bilanciato"        rptNumberFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptWidth="2000" rptColName="SbilanciamentoMWh" rptNumberFormat="#,##0.000" />
	</out>


</OutputFormat>
</Report>', 
'A')




insert into reportqueries
values ('CTRFLG', 'Gestione taglio su contratti', 
'<Report Descrizione="Report Gestione Taglio su Contratti">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportContrattiFlaggati"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti"   rptColName="NumContratti" />
	</out>
	

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>

	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="NumContratti" rptColName="Num. Contratti" />
	</out>


	<out rptType="xls">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio" rptWidth="4000"  />
		<col dbColName="NumContratti"   rptColName="Num. Contratti"  rptWidth="2500" rptNumberFormat="#,##0"/>
	</out>

</OutputFormat>
</Report>', 'A'
)

insert into reportqueries
values ('NRGSBILPGM', 'Energia di Sbilancio a Programma', 
'<Report Descrizione="Report Energia di Sbilancio">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaSbilancioProgramma"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
<Parameter Label="Soglia Sbilanciamento MWh:" Html="Text" ID="Soglia" NomeSql="@SogliaSbilMWh" TipoNET="double" TipoSql="float"/>   
<Parameter Label="CRN:" Html="Text" ID="CRN" NomeSql="@CRN" TipoNET="String" TipoSql="varchar(30)"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="Operatore" rptColName="Operatore_Resp"  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>



	<out rptType="xls">
		<col dbColName="Operatore"       rptWidth="2500" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptWidth="3500" rptColName="Codice Contratto" />
		<col dbColName="CRN"             rptWidth="3500" rptColName="CRN"  />
		<col dbColName="Cedente"         rptWidth="2500" rptColName="Cedente"  />
		<col dbColName="Acquirente"      rptWidth="2500" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio"  rptWidth="2500" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01"    rptWidth="1500" rptColName="SbilMWhOra01" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra02"    rptWidth="1500" rptColName="SbilMWhOra02" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra03"    rptWidth="1500" rptColName="SbilMWhOra03" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra04"    rptWidth="1500" rptColName="SbilMWhOra04" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra05"    rptWidth="1500" rptColName="SbilMWhOra05" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra06"    rptWidth="1500" rptColName="SbilMWhOra06" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra07"    rptWidth="1500" rptColName="SbilMWhOra07" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra08"    rptWidth="1500" rptColName="SbilMWhOra08" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra09"    rptWidth="1500" rptColName="SbilMWhOra09" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra10"    rptWidth="1500" rptColName="SbilMWhOra10" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra11"    rptWidth="1500" rptColName="SbilMWhOra11" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra12"    rptWidth="1500" rptColName="SbilMWhOra12" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra13"    rptWidth="1500" rptColName="SbilMWhOra13" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra14"    rptWidth="1500" rptColName="SbilMWhOra14" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra15"    rptWidth="1500" rptColName="SbilMWhOra15" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra16"    rptWidth="1500" rptColName="SbilMWhOra16" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra17"    rptWidth="1500" rptColName="SbilMWhOra17" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra18"    rptWidth="1500" rptColName="SbilMWhOra18" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra19"    rptWidth="1500" rptColName="SbilMWhOra19" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra20"    rptWidth="1500" rptColName="SbilMWhOra20" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra21"    rptWidth="1500" rptColName="SbilMWhOra21" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra22"    rptWidth="1500" rptColName="SbilMWhOra22" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra23"    rptWidth="1500" rptColName="SbilMWhOra23" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra24"    rptWidth="1500" rptColName="SbilMWhOra24" rptNumberFormat="#,##0.000" />
		<col dbColName="SbilMWhOra25"    rptWidth="1500" rptColName="SbilMWhOra25" rptNumberFormat="#,##0.000" />
	</out>


</OutputFormat>
</Report>',
'A'
)

insert into reportqueries
values ('NRGTAGLIO', 'Entita` Taglio sui Programmi non flaggati', 
'<Report Descrizione="Entita` Taglio sui Programmi non flaggati">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEntitaTaglio"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>

	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>


	<out rptType="xls">
		<col dbColName="CRN"                 rptWidth="3500" rptColName="CRN"  />
		<col dbColName="OperatoreCedente"    rptWidth="2500" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptWidth="2500" rptColName="Acquirente"  />
		<col dbColName="T1"                  rptWidth="1500" rptColName="TaglioOra1"  rptNumberFormat="#,##0.000" />
		<col dbColName="T2"                  rptWidth="1500" rptColName="TaglioOra2"  rptNumberFormat="#,##0.000" />
		<col dbColName="T3"                  rptWidth="1500" rptColName="TaglioOra3"  rptNumberFormat="#,##0.000" />
		<col dbColName="T4"                  rptWidth="1500" rptColName="TaglioOra4"  rptNumberFormat="#,##0.000" />
		<col dbColName="T5"                  rptWidth="1500" rptColName="TaglioOra5"  rptNumberFormat="#,##0.000" />
		<col dbColName="T6"                  rptWidth="1500" rptColName="TaglioOra6"  rptNumberFormat="#,##0.000" />
		<col dbColName="T7"                  rptWidth="1500" rptColName="TaglioOra7"  rptNumberFormat="#,##0.000" />
		<col dbColName="T8"                  rptWidth="1500" rptColName="TaglioOra8"  rptNumberFormat="#,##0.000" />
		<col dbColName="T9"                  rptWidth="1500" rptColName="TaglioOra9"  rptNumberFormat="#,##0.000" />
		<col dbColName="T10"                 rptWidth="1500" rptColName="TaglioOra10" rptNumberFormat="#,##0.000" />
		<col dbColName="T11"                 rptWidth="1500" rptColName="TaglioOra11" rptNumberFormat="#,##0.000" />
		<col dbColName="T12"                 rptWidth="1500" rptColName="TaglioOra12" rptNumberFormat="#,##0.000" />
		<col dbColName="T13"                 rptWidth="1500" rptColName="TaglioOra13" rptNumberFormat="#,##0.000" />
		<col dbColName="T14"                 rptWidth="1500" rptColName="TaglioOra14" rptNumberFormat="#,##0.000" />
		<col dbColName="T15"                 rptWidth="1500" rptColName="TaglioOra15" rptNumberFormat="#,##0.000" />
		<col dbColName="T16"                 rptWidth="1500" rptColName="TaglioOra16" rptNumberFormat="#,##0.000" />
		<col dbColName="T17"                 rptWidth="1500" rptColName="TaglioOra17" rptNumberFormat="#,##0.000" />
		<col dbColName="T18"                 rptWidth="1500" rptColName="TaglioOra18" rptNumberFormat="#,##0.000" />
		<col dbColName="T19"                 rptWidth="1500" rptColName="TaglioOra19" rptNumberFormat="#,##0.000" />
		<col dbColName="T20"                 rptWidth="1500" rptColName="TaglioOra20" rptNumberFormat="#,##0.000" />
		<col dbColName="T21"                 rptWidth="1500" rptColName="TaglioOra21" rptNumberFormat="#,##0.000" />
		<col dbColName="T22"                 rptWidth="1500" rptColName="TaglioOra22" rptNumberFormat="#,##0.000" />
		<col dbColName="T23"                 rptWidth="1500" rptColName="TaglioOra23" rptNumberFormat="#,##0.000" />
		<col dbColName="T24"                 rptWidth="1500" rptColName="TaglioOra24" rptNumberFormat="#,##0.000" />
		<col dbColName="T25"                 rptWidth="1500" rptColName="TaglioOra25" rptNumberFormat="#,##0.000" />
	</out>


</OutputFormat>
</Report>',
'A'
)

insert into reportqueries
values ('NRGCNTR', 'Energia Contratti Flaggati', 
'<Report Descrizione="Report Energia Contratti Flaggati">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaContrattiFlaggati"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>


	<out rptType="xls">
		<col dbColName="GestioneTaglio"   rptWidth="3500" rptColName="Gestione Taglio"     />
		<col dbColName="QtyMWhProduzione" rptWidth="2400" rptColName="QtyMWhProduzione"    rptNumberFormat="#,##0.000" />
		<col dbColName="QtyMWhProduzione" rptWidth="2400" rptColName="QtyMWhProduzioneMGP" rptNumberFormat="#,##0.000" />
		<col dbColName="QtyMWhConsumo"    rptWidth="2400" rptColName="QtyMWhConsumo"       rptNumberFormat="#,##0.000" />
		<col dbColName="QtyMWhConsumo"    rptWidth="2400" rptColName="QtyMWhConsumoMGP"    rptNumberFormat="#,##0.000" />
	</out>


</OutputFormat>
</Report>', 'A'
)

insert into ReportQueries 
values ('NRGSBIL', 'Energia di Sbilancio', 
'<Report Descrizione="Report Energia di Sbilancio">    
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaSbilancio"/>    
<InputParameters>     
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>     
</InputParameters>    
<OutputFormat>   
	<!--   
	supporta:  
		out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")   
		out/col[@rptColFormat=''000'']  - per formattare le singole colonne   
	-->   
	<out rptType="xml">    
		<col dbColName="DataProgramma" rptColName="DataFlusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />    
		<col dbColName="CRN" rptColName="CRN"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />  
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />      
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>
	<!--    supporta:   
		out[@rptLanguage=''zz-zz'']    
			- per formattare nella lingua di Excel (default it-it)   out[@rptSeparator='';'']       
			- per separare con , (in inglese) o con ; (in italiano) (default ; )   
		out/col[@rptColFormat=''000''] 
			- per formattare la singola colonna (default null)   
		out/col[@rptColQuote="''"]    
			- per ingannare Excel: non interpreta il campo come numerico (default non usare il quote)   
	-->   
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>     
	<!--   
	supporta:   
	out[@rptLanguage=''zz-zz'']    	- per impostare la lingua con cui si produce il file (default it-it).   
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)   
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)   
	-->   
	<out rptType="txt" rptLanguage="it-it" >    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />      
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out> 
	<!--    out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente   -->   
	<out rptType="html">    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="CRN"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>         



	<out rptType="xls">    
		<col dbColName="DataProgramma"     rptWidth="1500" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto"   rptWidth="3500" rptColName="Codice Contratto" />    
		<col dbColName="CRN"               rptWidth="3500" rptColName="CRN"  />    
		<col dbColName="Cedente"           rptWidth="2500" rptColName="Cedente"  />    
		<col dbColName="Acquirente"        rptWidth="2500" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio"    rptWidth="2000" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora"               rptWidth="1000" rptColName="Ora"                  rptNumberFormat="00" />    
		<col dbColName="QtyMWhProd"        rptWidth="2000" rptColName="QtyMWhProd"           rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhCons"        rptWidth="2000" rptColName="QtyMWhCons"           rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhProdT"       rptWidth="2000" rptColName="QtyMWhProdDopoTaglio" rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhConsT"       rptWidth="2000" rptColName="QtyMWhConsDopoTaglio" rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhProdMGP"     rptWidth="2000" rptColName="QtyMWhProdMGP"        rptNumberFormat="#,##0.000" />    
		<col dbColName="QtyMWhConsMGP"     rptWidth="2000" rptColName="QtyMWhConsMGP"        rptNumberFormat="#,##0.000" />    
		<col dbColName="SbilanciamentoMWh" rptWidth="2000" rptColName="SbilanciamentoMWh"    rptNumberFormat="#,##0.000" />   
	</out>         


	</OutputFormat>  
</Report>',
'A')



alter table dbo.Operatori enable trigger all


