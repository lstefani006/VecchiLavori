-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
print 'Aggiornamento tabella Funzioni'

alter table Funzioni
	alter column DescrizioneFunzione varchar(256) 
	COLLATE SQL_Latin1_General_CP1_CS_AS not null

print 'Fine aggiornamento della tabella funzioni'

-----------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------

print 'Aggiornamento tab_ReportIndicatori'


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF
GO

ALTER function tab_ReportIndicatori(@di as smalldatetime, @df as smalldatetime)
returns @retIndicatori table (	
	DataProgramma smalldatetime NOT NULL ,
	QtyMWhP float NOT NULL ,
	QtyMwhBilP float NOT NULL,
	QtyMWhC float  NOT NULL,
	QtyMwhBilC float  NOT NULL,
	QtyMwhSell float NOT NULL,
	QtyMwhBuy float  NOT NULL,
	CoCut int NOT NULL,
	CoPgm int NOT NULL,
	CoEnabled int NOT NULL)
as
begin
	declare @DataProgramma smalldatetime,
		@QtyMWhP float,
		@QtyMwhBilP float,
		@QtyMWhC float,
		@QtyMwhBilC float,
		@QtyMwhSell float,
		@QtyMwhBuy float,
		@nCoCut int,
		@nCoPgm int,
		@nCoEnabled int
		

	declare ind_cursor cursor  for
	select nrg.DataProgramma, 
		nrg.QtyMWhP, 
		nrg.QtyMwhBilP,
		nrg.QtyMWhC,
		nrg.QtyMwhBilC,
		nrg.QtyMwhSell,
		nrg.QtyMwhBuy,
		cnt.nContrattiTagliati,
		cnt.nContrattiProgrammati,
		cnt.nContrattiAbilitati
		from 
		(
			select Sessioni.DataProgramma, 
			Quantita.QtyMWhP, Quantita.QtyMwhBilP,
			Quantita.QtyMWhC, Quantita.QtyMwhBilC,
			Quantita.QtyMwhSell, Quantita.QtyMwhBuy
			from SessioneBilaterali Sessioni
			left outer join
			(
					select DataProgramma, 
						sum(case ProgrammatoDalCedente when 1 then QtyMWh else 0 end) QtyMWhP, 
						sum(case ProgrammatoDalCedente when 1 then isnull(QtyMWhBilanciamento, QtyMWh) else 0 end) QtyMwhBilP, 
						sum(case ProgrammatoDalCedente when 1 then isnull(QtyMWhAssegnataMGP,0) else 0 end) QtyMwhSell, 
						sum(case ProgrammatoDalCedente when 0 then QtyMWh else 0 end ) QtyMWhC, 
						sum(case ProgrammatoDalCedente when 0 then isnull(QtyMWhBilanciamento, QtyMWh) else 0 end) QtyMwhBilC,
						sum(case ProgrammatoDalCedente when 0 then isnull(QtyMWhAssegnataMGP,0) else 0 end) QtyMwhBuy
					from ProgrammaOrarioPerUnita
					where ProgOrarioDellUnitaValidato = 1
						and DataProgramma >= @di and DataProgramma <= @df
					group by DataProgramma
			) Quantita
			on Sessioni.DataProgramma = Quantita.DataProgramma
		) nrg
		inner join 
		(
		select cp.DataProgramma, isnull(ct.nContrattiTagliati, 0) nContrattiTagliati, cp.nContrattiProgrammati, ca.nContrattiAbilitati
		from
		(
		select s.DataProgramma, count(*) nContrattiProgrammati
		from 
		(
		select  po.DataProgramma, po.IdContratto,  count(*) nOre
					from ProgrammaOrario po
					where DataProgramma >= @di and DataProgramma <= @df
					group by po.DataProgramma, po.IdContratto
		) w
		inner join SessioneBilaterali s 
		on s.DataProgramma = w.DataProgramma
		group by s.DataProgramma
		) cp
		inner join
		(
		select s.DataProgramma DataProgramma, count(*) nContrattiAbilitati
			from SessioneBilaterali s, Contratto ct
			where 	s.DataProgramma >= @di and s.DataProgramma <= @df
				and DataInizioValidita <= s.DataProgramma
				and ct.DataFineValidita >= s.DataProgramma
				and ct.StatoContratto = 'Abilitato'
				and ct.TrCN = 1
		group by s.DataProgramma
		) ca
		on cp.DataProgramma = ca.DataProgramma
		left outer join
		(
		select s.DataProgramma, count(*) nContrattiTagliati
		from 
		SessioneBilaterali s 
		inner join 
		(
		select  po.DataProgramma, po.IdContratto,  count(*) nOre
					from ProgrammaOrario po
					where po.DataProgramma >= @di and po.DataProgramma <= @df
						and po.Bilanciato = 1 
						and po.SbilanciamentoMWh <> 0
					-- identifica i contratto sbilanciati e successivamente tagliati
					group by po.DataProgramma, po.IdContratto
		) x
		on s.DataProgramma = x.DataProgramma
		and s.Taglio = 1
		group by s.DataProgramma
		) ct
		on ca.DataProgramma = ct.DataProgramma
		) cnt
		on nrg.DataProgramma = cnt.DataProgramma
		order by nrg.DataProgramma

	open ind_cursor
	-- Perform the first fetch.
	fetch next from ind_cursor into
		@DataProgramma,
		@QtyMWhP,
		@QtyMwhBilP,
		@QtyMWhC,
		@QtyMwhBilC,
		@QtyMwhSell,
		@QtyMwhBuy,
		@nCoCut,
		@nCoPgm,
		@nCoEnabled

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	while @@FETCH_STATUS = 0
	begin
	-- Copy to the result of the function the required columns.
	insert @retIndicatori values(
		@DataProgramma,
		@QtyMWhP,
		@QtyMwhBilP,
		@QtyMWhC,
		@QtyMwhBilC,
		@QtyMwhSell,
		@QtyMwhBuy,
		@nCoCut,
		@nCoPgm,
		@nCoEnabled)
	   -- This is executed as long as the previous fetch succeeds.
	  fetch next from ind_cursor into
		@DataProgramma,
		@QtyMWhP,
		@QtyMwhBilP,
		@QtyMWhC,
		@QtyMwhBilC,
		@QtyMwhSell,
		@QtyMwhBuy,
		@nCoCut,
		@nCoPgm,
		@nCoEnabled
	end
	close ind_cursor
	deallocate ind_cursor
	return
end
go


print 'Fine Aggiornamento tab_ReportIndicatori'
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------

print 'Aggiornamento Stored Procedure [spReportXmlCCT_C].'
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCCT_C]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[spReportXmlCCT_C]
GO

CREATE PROCEDURE dbo.spReportXmlCCT_C
	@DataFlusso as datetime
-- sono i CCT per i cedenti.
-- ossia per le offerte con qty dopo mercato > 0
-- che per definizione sono a prezzo zonale
AS

--declare @DataFlusso as datetime
--set @DataFlusso = '17/3/2005'

declare @ErrorSave int
set @ErrorSave = 0

if Object_Id('tempdb..#t') is Not Null
begin
	drop table #t
end

-- tabella che contiene i contratti per i quali, nella data di flusso/periodo rilevante,
-- si ha una unita` di consumo estera.
-- Nella tabella sono elencati i contratti e per data/ora l'unita di consumo estera,
-- la zona e il prezzo zonale dell'unita` di consumo.
-- Per le regole adottate nell'accettazione dei programmi un contratto ad una data/ora
-- se e` di export di energia, deve avere una sola unita` di consumo e questa deve
-- essere estera.
-- Dunque la tabella dovrebbe contenere per un contratto/data/ora una sola unita e prezzo.
-- Per forzare questo fatto creo un indice univoco su contratto/data/ora
-- se l'indice protesta per chiave duplicata vuol dire che c'e` un errore nell'accettazione
-- dei programmi.
-- NB: anche se la sp e` per data di flusso, la tabella #t contiene la DataProgramma. 
--     questa scelta e` stata effettuata per generalita`
create table #t
(
	IdContratto      int,
	DataProgramma    datetime,
	PeriodoRilevante tinyint,
	CodiceUnitaSDC   varchar(16),
	CodiceZonaSDC    varchar(16),
	PrezzoUcExport   decimal(19,6)
)
-- indice in #t.
-- Se esistono due unita` per lo stesso contratto
-- l'indice fa fallire la sp sul doppio inserimento
create unique clustered index #pkt on #t
(
	IdContratto,
	DataProgramma,
	PeriodoRilevante
)

-- qui inserisco nella tabella per i programmi di export energia,
-- il prezzo zonale per l'unita di export
insert into #t
(
	IdContratto,
	DataProgramma,
	PeriodoRilevante,
	CodiceUnitaSDC,
	CodiceZonaSDC,
	PrezzoUcExport
)
	select 
	pou.IdContratto, 
	pou.DataProgramma,
	pou.PeriodoRilevante,
	pou.CodiceUnitaSDC, 
	uExport.CodiceZonaSDC,
	pz.Prezzo PrezzoUcExport
	from
	ProgrammaOrarioPerUnita pou
	inner join 
	(
		-- lista delle unita` di consumo estere
		-- che sono presenti nelle anagrafiche
		select 
		u.CodiceUnitaSDC, 
		ps.CodiceZonaSDC
		from sdc_unita u 
		inner join SDC_PuntiDiScambioRilevanti ps 
		on ps.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC 
		inner join sdc_zone z 
		on ps.CodiceZonaSDC = z.CodiceZonaSDC 
		where
		u.TipoUnita = 'C' -- unita` di consumo
		and z.type = 'VIRT'  -- zone estere

	) uExport
	on pou.CodiceUnitaSDC   = uExport.CodiceUnitaSDC

	inner join PrezzoZonale pz
	on  pz.Data             = pou.DataProgramma 
	and pz.PeriodoRilevante = pou.PeriodoRilevante
	and pz.CodiceZonaSDC    = uExport.CodiceZonaSDC

	where
	pou.DataProgramma = @DataFlusso

set @ErrorSave = @@error
if @ErrorSave <> 0
begin
	raiserror('Unita` di consumo export duplicata nel contratto in ProgrammaOrarioPerUnita', 16, 1)
	return
end

-- select * from #t

-- questa e` la query da ritornare per i CCT.
-- Si cercano le unita di produzione (quantita` assegnata > 0)
-- si calcola la quantita` al CP
-- e si moltiplica per il prezzo - unico per i contratti "normali"
-- prezzo zonale dell'unita` di consumo estera per i contratti di export.
-- La 168 impone che un contratto di export abbia programmata una solo unita` di consumo
-- e che questa deve essere estera.
select 
Contratto.CodiceOperatoreSDCCedente Op,
Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

convert(decimal(15,3), ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP 
	/ SDC_Unita.CoefficientePerdita * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita)
	QtyMWh,

convert(decimal(15,2), ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP 
	/ SDC_Unita.CoefficientePerdita * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita 
	-- applico il prezzo zonale dell'unita` di export se esiste in #t, altrimenti
	-- il prezzo unico
	* (isnull(#t.PrezzoUcExport, PrezzoUnitario.Prezzo) - PrezzoZonale.Prezzo))
	CCTOfferta

from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

-- vado a ricercare, se esiste, in #t il contratto:
-- se non esiste significa che devo applicare il PrezzoUnico
-- se esiste devo applicare il prezzo zonale dell'unica unita` di consumo 
-- (che e` estera)
left outer join #t
on  #t.IdContratto      = ProgrammaOrarioPerUnita.IdContratto
and #t.DataProgramma    = ProgrammaOrarioPerUnita.DataProgramma
and #t.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

where 
not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
and ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP > 0           -- solo unita` che producono
and ProgrammaOrarioPerUnita.DataProgramma = @DataFlusso

order by 
Contratto.CodiceOperatoreSDCCedente,
Contratto.CRN,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.PeriodoRilevante

GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [bil_dbo]
GO

print 'Aggiornamento Stored Procedure [spReportXmlCCT_C] concluso.'
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------



print 'Aggiornamento spGetReportIndicatori'
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER  PROCEDURE spGetReportIndicatori
	@dtinizio as datetime,
	@dtfine as datetime
		
AS

set transaction isolation level read uncommitted

select DataProgramma, 
1 as CNT,
case CoEnabled
when 0 then 0
else
cast (round(cast(CoCut as decimal(12,2))/cast(CoEnabled as decimal(12,2)) * 100, 2) as decimal(12,2))
end NCT,
case CoEnabled
when 0 then 0
else
cast( round(cast(CoPgm as decimal(12,2))/cast(CoEnabled as decimal(12,2))*100, 2) as decimal(12,2))
end NCP,
case QtyMwhP
when 0 then 0
else
cast( round(ABS(  cast(QtyMwhP -QtyMwhBilP as decimal(12,2))/cast(QtyMwhP  as decimal(12,2)) )*100, 2) as decimal(12,2))
end ENMGPP,
case QtyMwhC
when 0 then 0
else
cast ( round(ABS(  cast(QtyMwhBilC - QtyMwhBilC as decimal(12,2))/cast(QtyMwhC  as decimal(12,2)) )*100, 2) as decimal(12,2))
end ENMGPC,
case cast(ABS(QtyMwhC) + ABS(QtyMwhP) as decimal(12,2))
when 0 then 0
else
cast ( 
	round ( 
		cast(   ABS(QtyMwhC) + ABS(QtyMwhP) - ABS(QtyMwhBilC) - ABS(QtyMwhBilP) as decimal(12,2)) / cast ( ABS(QtyMwhC) + ABS(QtyMwhP) as decimal(12,2)) *100, 2) 
 as decimal(12,2))
end ENMGPT
from tab_ReportIndicatori(@dtinizio, @dtfine)
where @dtinizio <= DataProgramma
and @dtfine >= DataProgramma
order by DataProgramma
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

print 'Fine Aggiornamento spGetReportIndicatori'

-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportEnergiaSbilancio]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[ReportEnergiaSbilancio]

go

create procedure dbo.ReportEnergiaSbilancio
	@DataProgramma as datetime
as
	
--declare	@DataProgramma  datetime
--set @DataProgramma = '14/1/2005'

-- E` un report che puo` essere lanciato prima o dopo la lettura del mercato
-- Se siamo prima della lettura mercato la query deve utilizzare
-- lo stato corrente delle anagrafiche.
-- Se siamo a mercato letto, la query non deve utilizzare le informazioni
-- di attivazione ma solo partire dalle considerazioni sulla presenza o meno
-- della quantita` assegnata: vedi sotto per i particolari

set transaction isolation level read uncommitted

if Object_Id('tempdb..#Report1') is Not Null
	drop table #Report1

create table #Report1
(
	IdContratto      integer,
	DataProgramma    smalldatetime,
	PeriodoRilevante tinyint,
	QP float,
	QC float,
	QPT float,
	QCT float,
	QPMGP float,
	QCMGP float
)

-- controllo se e` stata effettuata la lettura del mercato
Declare @LetturaMGP int 
select @LetturaMGP=LetturaMGP from SessioneBilaterali
where DataProgramma=@DataProgramma
if @LetturaMGP is null 
	set @LetturaMGP=0

-- Print @LetturaMGP

if @LetturaMGP=1
begin
-- per individuare i record in POU in maniera "storica" ci possono essere piu` modi:
-- questo report pero` deve presentare anche le programmazioni che sono state 
-- effettuate e che non sono andate a mercato. 
-- Dunque non basta che la QtyMWhAssegnataMGP sia not null
-- dato che, per esempio, una quantita` tagliata a 0 non va a mercato e bisogna che comunque
-- dia il suo contributo per la quantita` programmata/tagliata.
-- Per risolvere qui il problema si usa PO.Bilanciato. 
-- Questo viene valorizzato nel calcolo del bilanciamento, e dunque, rispecchia 
-- le abilitazioni al momento dell'elaborazione. 
-- (in realta` e` null anche se tutte le unita` programmate nel contratto
--  sono disabilitate a causa della unit relate - caso remoto lo escludiamo)
-- Se e` null vuol dire che tutta quella programmazione si deve scartare, 
-- a causa dello stato del contratto o operatori, dalla data di fine ini/fine validita`
-- Se e` not null, alcune righe in POU potrebbero essere non valide a causa della unit-relate:
-- sono quelle che non hanno QtyMWhAssegnataMGP assegnata (o il corrispondente errore in POUE)
-- ci sono queste possibilita`:
-- una unita` ha QuantitaTagliata=0  e non e` andata a mercato 
--    --> non e` andata a mercato per la Qt=0 o forse per la UR modificata dopo il taglio (e` un po' remoto questo caso)
-- una unita` ha QuantitaTagliata!=0 e non e` andata a mercato 
--    --> e` disabilitata per la ur (e la ur e` stata modificata dopo il taglio -- caso remoto)
-- una unita` ha QuantitaTagliata=null e non e` andata a mercato
--    --> non e` andata a mercato perche` era esclusa dalla unit relate
-- Possiamo escludere che qualcuno sia intervenuto nella UR tra il taglio e la generazione delle offerte,
-- per cui 
-- 1) se ha QuantitaTagliata=0,    il record e` da considerare
-- 2) se ha QuantitaTagliata!=0,   il record e` da considerare (tanto poi non da` contributi)
-- 3) se ha QuantitaTagliata=null, il record e` da scartare    (e` fuori per la UR)
insert into #Report1
	select
	POU.IdContratto,
	POU.DataProgramma,
	POU.PeriodoRilevante,
	sum(QtyMWh * ProgrammatoDalCedente)                                         QP,
	sum(QtyMWh * -1 * (ProgrammatoDalCedente - 1))                              QC,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * ProgrammatoDalCedente)            QPT,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * -1 * (ProgrammatoDalCedente - 1)) QCT,
	sum(isnull(QtyMWhAssegnataMGP,0)  * ProgrammatoDalCedente)                  QPMGP,
	sum(isnull(QtyMWhAssegnataMGP,0)  * (-1) * (ProgrammatoDalCedente - 1))     QCMGP
	from
	ProgrammaOrarioPerUnita POU

	inner join ProgrammaOrario PO
	on  POU.DataProgramma     = PO.DataProgramma
	and POU.PeriodoRilevante  = PO.PeriodoRilevante
	and POU.IdContratto       = PO.IdContratto

	left outer join ProgrammaOrarioPerUnitaErrori POUE
	on  POU.DataProgramma     = POUE.DataProgramma
	and POU.PeriodoRilevante  = POUE.PeriodoRilevante
	and POU.IdContratto       = POUE.IdContratto
	and POU.CodiceUnitaSDC    = POUE.CodiceUnitaSDC
	and POU.CategoriaUnitaSDC = POUE.CategoriaUnitaSDC

	where
	POU.DataProgramma = @DataProgramma
	-- questo implica stato contratto abilitato e TrCN=1
	-- ma anche se tutte le unita programmate del contratto sono disabilitate a fronte dell'unit relate
	and PO.Bilanciato is not null
	and PO.ProgrammaOrarioValidato = 1
	and
	(
		-- e` andato a mercato --> lo conto
		QtyMWhAssegnataMGP is not null
		-- c'e` stato un errore --> lo conto
		or POUE.IdContratto is not null
		-- e` stato bilanciato --> lo conto
		or QtyMWhBilanciamento is not null
		-- so ho ricevuto il GMEReferenceNumber vuol dire che e` andato a mercato
		or GMEReferenceNumber is not null
		-- scarto quelli con QtyMWhBilanciamento is null
	)	
	and POU.ProgOrarioDellUnitaValidato=1

	group by POU.DataProgramma, POU.PeriodoRilevante, POU.IdContratto
	
	
	
select 
@DataProgramma DataProgramma,
C.CRN,
C.CodiceContratto,
C.CodiceOperatoreSDCCedente Cedente,
C.CodiceOperatoreSDCAcquirente Acquirente,
case (PO.GestioneTaglio) 
	when 'T' then 'Sempre'
	when 'C' then 'se cons. supera prod.'
	when 'P' then 'se prod. supera cons.'
	when 'M' then 'mai'
end 
GestioneTaglio,
PO.PeriodoRilevante Ora,
cast (R.QP as decimal(16,3))     QtyMWhProd,
cast (R.QC as decimal(16,3))     QtyMWhCons,
cast (R.QPT as decimal(16,3))    QtyMWhProdT,
cast (R.QCT as decimal(16,3))    QtyMWhConsT,
cast (R.QPMGP as decimal(16,3))  QtyMWhProdMGP,
cast (R.QCMGP as decimal(16,3))  QtyMWhConsMGP,
PO.Bilanciato Bilanciato,
cast(PO.SbilanciamentoMWh as decimal(16,3)) SbilanciamentoMWh
from ProgrammaOrario PO
inner join Contratto C
on PO.IdContratto = C.IdContratto
inner join #Report1 R
on  R.IdContratto   = PO.IdContratto
and R.DataProgramma = PO.DataProgramma
and R.PeriodoRilevante = PO.PeriodoRilevante
where
PO.DataProgramma = @DataProgramma
order by 
C.CRN, 
PO.PeriodoRilevante
	

end
else
begin

-- cerco i record partendo dallo stato attuale delle anagrafiche, contratti ecc.
insert into #Report1
	select
	POU.IdContratto,
	POU.DataProgramma,
	POU.PeriodoRilevante,
	sum(QtyMWh * ProgrammatoDalCedente) QP,
	sum(QtyMWh * -1 * (ProgrammatoDalCedente - 1)) QC,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * ProgrammatoDalCedente) QPT,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * -1 * (ProgrammatoDalCedente - 1)) QCT,
	sum(QtyMWhAssegnataMGP  * ProgrammatoDalCedente) QPMGP,
	sum(QtyMWhAssegnataMGP  * (-1) * (ProgrammatoDalCedente - 1)) QPMGC
	from
	ProgrammaOrarioPerUnita POU

	inner join Contratto CO
	on CO.IdContratto = POU.IdContratto
	and CO.TrCN = 1
	and CO.StatoContratto = 'Abilitato'
	
	inner join ProgrammaOrario PO
	on  PO.IdContratto = POU.IdContratto
	and PO.DataProgramma = POU.DataProgramma
	and PO.PeriodoRilevante = POU.PeriodoRilevante

	inner join UnitRelate UR
	on  UR.CodiceUnitaSDC    = POU.CodiceUnitaSDC
	and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC 
	and 
	(
		(POU.ProgrammatoDalCedente=1 and UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente)
		or
		(POU.ProgrammatoDalCedente=0 and UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente)
	)
	and UR.TrUC = 1
	and UR.DataInizioValidita <= @DataProgramma
	and UR.DataFineValidita   >= @DataProgramma
	and UR.Abilitata = 1
	
	where
	POU.DataProgramma = @DataProgramma
	and POU.PeriodoRilevante <= 25
	and POU.ProgOrarioDellUnitaValidato=1
	and PO.ProgrammaOrarioValidato = 1
	group by POU.DataProgramma, POU.PeriodoRilevante, POU.IdContratto
	
	
select 
@DataProgramma DataProgramma,
C.CRN,
C.CodiceContratto,
C.CodiceOperatoreSDCCedente Cedente,
C.CodiceOperatoreSDCAcquirente Acquirente,
case (C.GestioneTaglio) 
	when 'T' then 'Sempre'
	when 'C' then 'se cons. supera prod.'
	when 'P' then 'se prod. supera cons.'
	when 'M' then 'mai'
end 
GestioneTaglio,
PO.PeriodoRilevante Ora,
cast (R.QP as decimal(16,3))     QtyMWhProd,
cast (R.QC as decimal(16,3))     QtyMWhCons,
cast (R.QPT as decimal(16,3))    QtyMWhProdT,
cast (R.QCT as decimal(16,3))    QtyMWhConsT,
cast (R.QPMGP as decimal(16,3))  QtyMWhProdMGP,
cast (R.QCMGP as decimal(16,3))  QtyMWhConsMGP,
PO.Bilanciato Bilanciato,
cast(PO.SbilanciamentoMWh as decimal(16,3)) SbilanciamentoMWh
from ProgrammaOrario PO
inner join Contratto C
on PO.IdContratto = C.IdContratto
inner join #Report1 R
on  R.IdContratto   = PO.IdContratto
and R.DataProgramma = PO.DataProgramma
and R.PeriodoRilevante = PO.PeriodoRilevante
where
PO.DataProgramma = @DataProgramma
order by 
C.CRN, 
PO.PeriodoRilevante

end

drop table #Report1

RETURN
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [bil_dbo]
GO


-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammazione24]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[spBilGetProgrammazione24]
	
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO
	
	
CREATE PROCEDURE dbo.spBilGetProgrammazione24
	@DataProgramma datetime
AS

SET NOCOUNT ON;

set transaction isolation level read uncommitted

select
	PU.IdContratto,
		
  	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end) 			C01,
  	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end) 			C02,
  	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end) 			C03,
  	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end) 			C04,
  	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end) 			C05,
	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end) 			C06,
  	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end) 			C07,
  	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end) 			C08,
  	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end) 			C09,
  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
  	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
  	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
 	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
  	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
  	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
  	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
  	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
  	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
  	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
  	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
  	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
  	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
  	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,

  	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end) 			A01,
  	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end) 			A02,
  	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end) 			A03,
  	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end) 			A04,
  	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
  	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end) 			A06,
  	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end) 			A07,
  	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end) 			A08,
  	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end) 			A09,
 	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
  	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
  	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
  	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
  	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
  	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
  	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
  	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
  	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
    sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
  	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
  	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
  	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
   	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,

 	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end) B01,
 	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end) B02,
 	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end) B03,
 	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end) B04,
 	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end) B05,
 	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) B06,
 	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) B07,
 	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) B08,
 	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) B09,
 	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) B10,
 	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) B11,
 	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) B12,
 	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) B13,
 	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) B14,
 	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) B15,
 	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) B16,
 	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) B17,
 	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) B18,
 	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) B19,
 	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) B20,
 	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) B21,
 	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) B22,
 	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) B23,
 	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) B24,
-- 	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) B25,

	PU.CRN,
	PU.CodiceContratto
FROM
(
	SELECT 
	CC.IdContratto, 
	Ore.Ora PeriodoRilevante,
	CC.CRN,
	CC.CodiceContratto,
	case
	when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
	when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
	else
		case sign(PO.SbilanciamentoMWh) 
		when 1 then	 -- eccesso di produzione: 
			case CC.GestioneTaglio
			when 'T' then 5		-- taglia sempre, 'rosso'
			when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
			when 'C' then		-- solo se cons. maggiore prod.
 				case CC.IsGMEOpAcquirente 
 					when 1 then 4	-- 'blu'  
 					when 0 then 3	-- 'arancione' 
 				end 
			when 'M' then 
				case CC.IsGMEOpAcquirente 
					when 1 then 4   -- 'blu'
					when 0 then 3	-- 'arancione'
				end 
			end
		when -1 then 	-- eccesso di consumo: 
			case CC.GestioneTaglio
			when 'T' then 5		-- 'taglia sempre, rosso'
			when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
			when 'P' then		-- solo se prod. maggiore cons.
				case CC.IsGMEOpCedente
					when 1 then 4	-- 'blu'
					when 0 then 4	-- 'blu', caso praticamente impossibile 
				end 
			when 'M' then
				case CC.IsGMEOpCedente
					when 1 then 4	-- 'blu'
					when 0 then 4	-- 'blu', caso praticamente impossibile 
				end 
			end
		end
	end Sbilanciamento,
	case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end TotUnitaAssCed, -- 0 rosso, 1 verde
	case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end TotUnitaAssAcq
	FROM 
	(
			SELECT 	CO.IdContratto,
				CO.CRN,
				CO.CodiceContratto,
				CO.GestioneTaglio,
				OA.IsGMEOp IsGMEOpAcquirente,
				OC.IsGMEOp IsGMEOpCedente
			FROM Contratto CO, 
				Operatori OA,
				Operatori OC
			WHERE   CO.DataInizioValidita <= @DataProgramma
				AND CO.DataFineValidita >= @DataProgramma
			 	AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
		 		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
				AND CO.StatoContratto='Abilitato'
				AND CO.TrCN = 1
	) CC
	CROSS JOIN 
	(
	SELECT Ora 
	FROM Ore 
	WHERE Ore.Ora <= 24
	) Ore
	LEFT OUTER JOIN ProgrammaOrario PO
	ON PO.IdContratto = CC.IdContratto
	AND PO.PeriodoRilevante = Ore.Ora
	AND PO.DataProgramma = @DataProgramma
	AND PO.ProgrammaOrarioValidato = 1
	LEFT OUTER JOIN (
		SELECT 
		IdContratto, 
		PeriodoRilevante, 
		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
		FROM programmaorarioperunita
		WHERE DataProgramma = @DataProgramma
		AND ProgOrarioDellUnitaValidato=1
		GROUP BY IdContratto, PeriodoRIlevante
	) POU
	ON PO.PeriodoRilevante = POU.PeriodoRilevante
	AND PO.IdContratto = POU.IdContratto
) PU
GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto
ORDER BY PU.CRN
RETURN
GO	

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione24]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione24]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione24]  TO [bil_dbo]
GO


-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------

ALTER PROCEDURE [dbo].[spEseguiBilanciamentoPerContratto]
	@IdContratto int,
	@DataProgramma smalldatetime,
	@PeriodoRilevante tinyint,
	@SogliaSbilMWh float
AS


-- STR 251: correzione di questa logica, le programmazioni a zero non vengono piu` inserite 
-- nella ProgrammaOrarioPerUnita, con conseguente beneficio per gli indici di POU.
-- Lasciamo la Delete di POUE, anche se in realta` non dovrebbe mai cancellare nulla 
-- (POUE puo` essere compilata in fase di Lettura Mercato, quindi dopo)
-- CANCELLAZIONE DELLE PROGRAMMAZIONI A ZERO MWH
-- =============================================
-- Questo NON e' il posto migliore per fare le cancellazioni della programmazione a zero MWh.
-- Il posto migliore dovrebbe essere ElaborazioneProgrammiUtenti.
-- Per motivi di tempo e di rischio oggi 24/12/2004 preferisco mettere qui questa
-- operazione.
-- La metto qui dato che il bilanciamento per contratto avviene ad ogni invio
-- del programma.
-- E' sicuramente stupido inserire/modificare record a zero per poi cancellarli, ma
-- dato il carattere di emergenza della modifica questo e` il posto migliore.
-- Notare che su ROMA4 si hanno circa 628.000 record in POU di cui 222.000 a 0MWh ossia
-- il 35% !! --> le query dovrebbero andare almeno un po' piu' veloci.
-- Unico rischio che vedo e` la frammentazione dell'indice.... per ora ignoro.
-- 
-- Prima cerco le programmazioni a zero in POU
-- per cancellare gli eventuali record collegati in POUE
-- (che NON dovrebbero esserci... ma per tranquillita` referenziale lo faccio)
-- Poi cancello le programmazioni a zero in POU

-- delete ProgrammaOrarioPerUnitaErrori
-- from
-- (
-- 	select
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC
-- 	from 
-- 	ProgrammaOrarioperUnita 
-- 	where 
-- 	         IdContratto      = @IdContratto
-- 	and DataProgramma    = @DataProgramma
-- 	and PeriodoRilevante = @PeriodoRilevante
-- 	and QtyMWh=0
-- ) T
-- where
--       ProgrammaOrarioPerUnitaErrori.IdContratto       = T.IdContratto
-- and ProgrammaOrarioPerUnitaErrori.DataProgramma     = T.DataProgramma
-- and ProgrammaOrarioPerUnitaErrori.PeriodoRilevante  = T.PeriodoRilevante
-- and ProgrammaOrarioPerUnitaErrori.CodiceUnitaSDC    = T.CodiceUnitaSDC
-- and ProgrammaOrarioPerUnitaErrori.CategoriaUnitaSDC = T.CategoriaUnitaSDC


--delete ProgrammaOrarioPerUnita
--where 
--    IdContratto      = @IdContratto
--and DataProgramma    = @DataProgramma
--and PeriodoRilevante = @PeriodoRilevante
--and QtyMWh           = 0


-- FINE CANCELLAZIONE PROGRAMMAZIONI A 0 MWH
-- =========================================

--=============================================================================================================

-- non si usa read uncommitted in quanto
-- il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@IdContratto int,
-- 	@DataProgramma smalldatetime,
-- 	@PeriodoRilevante tinyint,
-- 	@SogliaSbilMWh float
-- 
-- set @IdContratto = 212
-- set @DataProgramma = '1/12/2004'
-- set @PeriodoRilevante = 1
-- set @SogliaSbilMWh = 0.001


-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno/ora

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o valido non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.


-- str #272
-- questa sp e` chiamata quando arriva un programma
-- il primo update azzera i dati di bilanciamento in PO per quel contratto
-- il secondo update i dati di bilanciamento forzato per quel contratto.
-- il terzo azzera le quantita` bilanciate in maniera forzata.
-- Ora, a fronte di un NUOVO programma questo comportamento
-- e` corretto.
-- Il problema e` che poi NAB non permette di effettuare il bilanciamento forzato per
-- contratto..... Ora si e` costretti a a rifare il bilanciamento forzato globale.
-- non mi sembra pero` un problema.
-- in pratica per str #272 lascio tutto inalterato.
-- fine str #272

-- per prima cosa azzero le informazioni in PO
update ProgrammaOrario
set 
Bilanciato=NULL,
SbilanciamentoMWh=NULL,
SbilanciamentoMWhReale=NULL,
TSCalcoloBilanciamento=NULL
from ProgrammaOrario
where
IdContratto = @IdContratto
and DataProgramma = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante

-- e conseguentemente in POU
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where DataProgramma = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante
and IdContratto = @IdContratto
and not QtyMWhBilanciamento is null

-- siccome sto facendo il calcolo del bilanciamento, potenzialmente
-- e` cambiato il bilanciamento e dunque potenzialemente
-- il taglio forzato e` da rifare.
update 
SessioneBilaterali
set
Taglio=0
where DataProgramma=@DataProgramma


declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()

update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,
	
	case when Abs(Sum(Q.QtyMWh)) > @SogliaSbilMWh then 0 else 1 end Bilanciato,
	case when Abs(Sum(Q.QtyMWh)) > @SogliaSbilMWh then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on
		POU.Idcontratto = PO.IdContratto
		and POU.DataProgramma = PO.DataProgramma
		and POU.PeriodoRilevante = PO.PeriodoRilevante
		and POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
		and POU.IdContratto = @IdContratto
		and POU.PeriodoRilevante = @PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join  SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

	) Q
	group by IdContratto, PeriodoRilevante

) W

on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante
GO

-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
ALTER function tab_SbilanciamentoProgramma(@DataProgramma datetime, @SogliaSbilMWh as float, @CRN as varchar(30))
returns @retSbilanciamentoProgramma table (	
	Operatore  varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	CRN varchar(30) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	CodiceContratto varchar(50) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
	Cedente varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	Acquirente varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	GestioneTaglio varchar(100) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	SbilMWhOra01 float,
	SbilMWhOra02 float,
	SbilMWhOra03 float,
	SbilMWhOra04 float,
	SbilMWhOra05 float,
	SbilMWhOra06 float,
	SbilMWhOra07 float,
	SbilMWhOra08 float,
	SbilMWhOra09 float,
	SbilMWhOra10 float,
	SbilMWhOra11 float,
	SbilMWhOra12 float,
	SbilMWhOra13 float,
	SbilMWhOra14 float,
	SbilMWhOra15 float,
	SbilMWhOra16 float,
	SbilMWhOra17 float,
	SbilMWhOra18 float,
	SbilMWhOra19 float,
	SbilMWhOra20 float,
	SbilMWhOra21 float,
	SbilMWhOra22 float,
	SbilMWhOra23 float,
	SbilMWhOra24 float,
	SbilMWhOra25 float)
as

begin
declare	
	@Operatore  varchar(16) ,
	@CodiceContratto varchar(50),
	@Cedente varchar(16) ,
	@Acquirente varchar(16),
	@GestioneTaglio varchar(50),
	@SbilMWhOra01 float,
	@SbilMWhOra02 float,
	@SbilMWhOra03 float,
	@SbilMWhOra04 float,
	@SbilMWhOra05 float,
	@SbilMWhOra06 float,
	@SbilMWhOra07 float,
	@SbilMWhOra08 float,
	@SbilMWhOra09 float,
	@SbilMWhOra10 float,
	@SbilMWhOra11 float,
	@SbilMWhOra12 float,
	@SbilMWhOra13 float,
	@SbilMWhOra14 float,
	@SbilMWhOra15 float,
	@SbilMWhOra16 float,
	@SbilMWhOra17 float,
	@SbilMWhOra18 float,
	@SbilMWhOra19 float,
	@SbilMWhOra20 float,
	@SbilMWhOra21 float,
	@SbilMWhOra22 float,
	@SbilMWhOra23 float,
	@SbilMWhOra24 float,
	@SbilMWhOra25 float


declare	@numore as integer
exec @numore = GetHourNum @DataProgramma

declare
 	@SbilMWhTotOra01 float,
	@SbilMWhTotOra02 float,
	@SbilMWhTotOra03 float,
	@SbilMWhTotOra04 float,
	@SbilMWhTotOra05 float,
	@SbilMWhTotOra06 float,
	@SbilMWhTotOra07 float,
	@SbilMWhTotOra08 float,
	@SbilMWhTotOra09 float,
	@SbilMWhTotOra10 float,
	@SbilMWhTotOra11 float,
	@SbilMWhTotOra12 float,
	@SbilMWhTotOra13 float,
	@SbilMWhTotOra14 float,
	@SbilMWhTotOra15 float,
	@SbilMWhTotOra16 float,
	@SbilMWhTotOra17 float,
	@SbilMWhTotOra18 float,
	@SbilMWhTotOra19 float,
	@SbilMWhTotOra20 float,
	@SbilMWhTotOra21 float,
	@SbilMWhTotOra22 float,
	@SbilMWhTotOra23 float,
	@SbilMWhTotOra24 float,
	@SbilMWhTotOra25 float

 	set @SbilMWhTotOra01 = 0.0
	set @SbilMWhTotOra02 = 0.0
	set @SbilMWhTotOra03 = 0.0
	set @SbilMWhTotOra04 = 0.0
	set @SbilMWhTotOra05 = 0.0
	set @SbilMWhTotOra06 = 0.0
	set @SbilMWhTotOra07 = 0.0
	set @SbilMWhTotOra08 = 0.0
	set @SbilMWhTotOra09 = 0.0
	set @SbilMWhTotOra10 = 0.0
	set @SbilMWhTotOra11 = 0.0
	set @SbilMWhTotOra12 = 0.0
	set @SbilMWhTotOra13 = 0.0
	set @SbilMWhTotOra14 = 0.0
	set @SbilMWhTotOra15 = 0.0
	set @SbilMWhTotOra16 = 0.0
	set @SbilMWhTotOra17 = 0.0
	set @SbilMWhTotOra18 = 0.0
	set @SbilMWhTotOra19 = 0.0
	set @SbilMWhTotOra20 = 0.0
	set @SbilMWhTotOra21 = 0.0
	set @SbilMWhTotOra22 = 0.0
	set @SbilMWhTotOra23 = 0.0
	set @SbilMWhTotOra24 = 0.0
	set @SbilMWhTotOra25 = 0.0


declare @IdContratto as int

select @IdContratto = IdContratto 
from Contratto 
where CRN = @CRN

declare p_cursor cursor for
select
TTT.CodiceOperatoreSDC Operatore, 
TTT.CodiceContratto,
TTT.CodiceOperatoreSDCCedente Cedente,
TTT.CodiceOperatoreSDCAcquirente Acquirente,
case (TTT.GestioneTaglio) 
	when 'T' then 'Sempre'
	when 'C' then 'se cons. supera prod.'
	when 'P' then 'se prod. supera cons.'
	when 'M' then 'Mai'
end GestioneTaglio,
sum(case TTT.PeriodoRilevante when  1 then TTT.BilMWh else 0 end )SbilMWhOra01,
sum(case TTT.PeriodoRilevante when  2 then TTT.BilMWh else 0 end )SbilMWhOra02,
sum(case TTT.PeriodoRilevante when  3 then TTT.BilMWh else 0 end )SbilMWhOra03,
sum(case TTT.PeriodoRilevante when  4 then TTT.BilMWh else 0 end )SbilMWhOra04,
sum(case TTT.PeriodoRilevante when  5 then TTT.BilMWh else 0 end )SbilMWhOra05,
sum(case TTT.PeriodoRilevante when  6 then TTT.BilMWh else 0 end )SbilMWhOra06,
sum(case TTT.PeriodoRilevante when  7 then TTT.BilMWh else 0 end )SbilMWhOra07,
sum(case TTT.PeriodoRilevante when  8 then TTT.BilMWh else 0 end )SbilMWhOra08,
sum(case TTT.PeriodoRilevante when  9 then TTT.BilMWh else 0 end )SbilMWhOra09,
sum(case TTT.PeriodoRilevante when 10 then TTT.BilMWh else 0 end )SbilMWhOra10,
sum(case TTT.PeriodoRilevante when 11 then TTT.BilMWh else 0 end )SbilMWhOra11,
sum(case TTT.PeriodoRilevante when 12 then TTT.BilMWh else 0 end )SbilMWhOra12,
sum(case TTT.PeriodoRilevante when 13 then TTT.BilMWh else 0 end )SbilMWhOra13,
sum(case TTT.PeriodoRilevante when 14 then TTT.BilMWh else 0 end )SbilMWhOra14,
sum(case TTT.PeriodoRilevante when 15 then TTT.BilMWh else 0 end )SbilMWhOra15,
sum(case TTT.PeriodoRilevante when 16 then TTT.BilMWh else 0 end )SbilMWhOra16,
sum(case TTT.PeriodoRilevante when 17 then TTT.BilMWh else 0 end )SbilMWhOra17,
sum(case TTT.PeriodoRilevante when 18 then TTT.BilMWh else 0 end )SbilMWhOra18,
sum(case TTT.PeriodoRilevante when 19 then TTT.BilMWh else 0 end )SbilMWhOra19,
sum(case TTT.PeriodoRilevante when 20 then TTT.BilMWh else 0 end )SbilMWhOra20,
sum(case TTT.PeriodoRilevante when 21 then TTT.BilMWh else 0 end )SbilMWhOra21,
sum(case TTT.PeriodoRilevante when 22 then TTT.BilMWh else 0 end )SbilMWhOra22,
sum(case TTT.PeriodoRilevante when 23 then TTT.BilMWh else 0 end )SbilMWhOra23,
sum(case TTT.PeriodoRilevante when 24 then TTT.BilMWh else 0 end )SbilMWhOra24,
sum(case TTT.PeriodoRilevante when 25 then TTT.BilMWh else 0 end )SbilMWhOra25

from
(
	select
	C.CodiceOperatoreSDC, 
	C.CodiceContratto,
	C.CodiceOperatoreSDCCedente ,
	C.CodiceOperatoreSDCAcquirente ,
	C.GestioneTaglio,
	Q.PeriodoRilevante,
	Q.BilMWh

	from ProgrammaOrario PO 
	inner join Contratto C
	on PO.IdContratto = C.IdContratto
	inner join
	(
		select 
		POU.IdContratto, 
		@DataProgramma DataProgramma, 
		POU.PeriodoRilevante,
		case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > @SogliaSbilMWh then 0                                        else 1 end Bilanciato,
		case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > @SogliaSbilMWh then round(Sum(round(POU.QtyMWh * UC.KP / UC.KU,3)), 3) else 0 end BilMWh
		from 
		(
			select 
			u.IdContratto,
			u.CodiceUnitaSDC, 
			u.CategoriaUnitaSDC, 
			u.TrCC,
			u.TrUC,
			u.VUC,
			u.KU,
			u.KP,
			sum(u.UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,
			sum(u.UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
			from 
			(
	
				select 
				c.IdContratto,
				ur.CodiceUnitaSDC, 
				ur.CategoriaUnitaSDC, 
				ur.TrUC, 
				ur.VUC,
				1 UnitaAssegnataOpCedente, 
				0 UnitaAssegnataOpAcquirente,
				c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC,
				su.CoefficientePerdita KU,
				sp.CoefficienteDiPerdita KP
				from unitrelate ur
				inner join 
				contratto c
				on
				c.IdContratto = @IdContratto
				and c.DataInizioValidita <= @DataProgramma and c.DataFineValidita >= @DataProgramma
				and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and ur.TipoUnita in ('P', 'M')
				and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
				and ur.Abilitata = 1
				inner join SDC_Unita su
				on su.CodiceUnitaSDC = ur.CodiceUnitaSDC
				and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
				inner join SDC_PuntiDiScambioRilevanti sp
				on su.CodicePuntoDiScambioRilevanteSDC = sp.CodicePuntoDiScambioRilevanteSDC
			union
				select 
				c.IdContratto,
				ur.CodiceUnitaSDC, 
				ur.CategoriaUnitaSDC, 
				ur.TrUC, 
				ur.VUC,
				0 UnitaAssegnataOpCedente, 
				1 UnitaAssegnataOpAcquirente,
				c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC,
				su.CoefficientePerdita KU,
				sp.CoefficienteDiPerdita KP
				from unitrelate ur
				inner join 
				contratto c
				on c.DataInizioValidita <= @DataProgramma and c.DataFineValidita >= @DataProgramma
				and CRN = @CRN
				and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and ur.TipoUnita in ('C', 'M')
				and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
				and ur.Abilitata = 1
				inner join SDC_Unita su
				on su.CodiceUnitaSDC = ur.CodiceUnitaSDC
				and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
				inner join SDC_PuntiDiScambioRilevanti sp
				on su.CodicePuntoDiScambioRilevanteSDC = sp.CodicePuntoDiScambioRilevanteSDC
			) u
			group by IdContratto,
			CodiceUnitaSDC, 
			CategoriaUnitaSDC,
			TrUC,
			VUC,
			TrCC,
			KU,
			KP
	 	) UC
		inner join
		(
			-- considero i POU validi del giorno
			SELECT 
			ProgrammaOrarioPerUnita.IdContratto, 
			ProgrammaOrarioPerUnita.DataProgramma, 
			ProgrammaOrarioPerUnita.PeriodoRilevante, 
			ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
			ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
			ProgrammaOrarioPerUnita.QtyMWh
			FROM 
			ProgrammaOrarioPerUnita, 
			ProgrammaOrario,
			Contratto 
			where 
			ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
			and ProgrammaOrario.DataProgramma=@DataProgramma
			and ProgrammaOrario.PeriodoRilevante <= 25
			and Contratto.IdContratto = @IdContratto
			and Contratto.IdContratto = ProgrammaOrario.IdContratto
			and ProgrammaOrario.ProgrammaOrarioValidato=1
			and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
			and ProgrammaOrarioPerUnita.IdContratto=ProgrammaOrario.IdContratto
			and ProgrammaOrarioPerUnita.DataProgramma=ProgrammaOrario.DataProgramma
			and ProgrammaOrarioPerUnita.PeriodoRilevante <= 25
			and ProgrammaOrarioPerUnita.PeriodoRilevante=ProgrammaOrario.PeriodoRilevante
		) POU
		ON  POU.IdContratto = UC.IdContratto
		AND POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
		AND POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
		GROUP BY POU.IdContratto, POU.DataProgramma, POU.PeriodoRilevante
	) Q
	on 
	PO.IdContratto = Q.IdContratto
	and PO.DataProgramma = Q.DataProgramma
	and PO.PeriodoRilevante = Q.PeriodoRilevante
)
TTT
group by 
CodiceOperatoreSDC,
CodiceContratto,
CodiceOperatoreSDCCedente,
CodiceOperatoreSDCAcquirente,
GestioneTaglio
--order by C.CRN

open p_cursor
		-- Perform the first fetch.
fetch next from p_cursor into
		@Operatore,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25

	

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	while @@FETCH_STATUS = 0
	begin

		set @SbilMWhTotOra01 = @SbilMWhTotOra01 + @SbilMWhOra01
		set @SbilMWhTotOra02 = @SbilMWhTotOra02 + @SbilMWhOra02

		set @SbilMWhTotOra03 = @SbilMWhTotOra03 + @SbilMWhOra03
		set @SbilMWhTotOra04 = @SbilMWhTotOra04 + @SbilMWhOra04
		set @SbilMWhTotOra05 = @SbilMWhTotOra05 + @SbilMWhOra05
		set @SbilMWhTotOra06 = @SbilMWhTotOra06 + @SbilMWhOra06
		set @SbilMWhTotOra07 = @SbilMWhTotOra07 + @SbilMWhOra07
		set @SbilMWhTotOra08 = @SbilMWhTotOra08 + @SbilMWhOra08
		set @SbilMWhTotOra09 = @SbilMWhTotOra09 + @SbilMWhOra09
		set @SbilMWhTotOra10 = @SbilMWhTotOra10 + @SbilMWhOra10
		set @SbilMWhTotOra11 = @SbilMWhTotOra11 + @SbilMWhOra11
		set @SbilMWhTotOra12 = @SbilMWhTotOra12 + @SbilMWhOra12
		set @SbilMWhTotOra13 = @SbilMWhTotOra13 + @SbilMWhOra13
		set @SbilMWhTotOra14 = @SbilMWhTotOra14 + @SbilMWhOra14
		set @SbilMWhTotOra15 = @SbilMWhTotOra15 + @SbilMWhOra15
		set @SbilMWhTotOra16 = @SbilMWhTotOra16 + @SbilMWhOra16
		set @SbilMWhTotOra17 = @SbilMWhTotOra17 + @SbilMWhOra17
		set @SbilMWhTotOra18 = @SbilMWhTotOra18 + @SbilMWhOra18
		set @SbilMWhTotOra19 = @SbilMWhTotOra19 + @SbilMWhOra19
		set @SbilMWhTotOra20 = @SbilMWhTotOra20 + @SbilMWhOra20
		set @SbilMWhTotOra21 = @SbilMWhTotOra21 + @SbilMWhOra21
		set @SbilMWhTotOra22 = @SbilMWhTotOra22 + @SbilMWhOra22
		set @SbilMWhTotOra23 = @SbilMWhTotOra23 + @SbilMWhOra23
		set @SbilMWhTotOra24 = @SbilMWhTotOra24 + @SbilMWhOra24
		set @SbilMWhTotOra25 = @SbilMWhTotOra25 + @SbilMWhOra25
		
	-- Copy to the result of the function the required columns.
	insert @retSbilanciamentoProgramma values(
		@Operatore,
		@CRN,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25)
	   -- This is executed as long as the previous fetch succeeds.
	  fetch next from p_cursor into
		@Operatore,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25

	end
	close p_cursor
	deallocate p_cursor



	-- Copy to the result of the function the required columns.
	insert @retSbilanciamentoProgramma values(
		'',
		'',
		'', --convert(varchar, @DataProgramma, 105),
		'',
		'',
		'Totale Orario' ,
		@SbilMWhTotOra01,
		@SbilMWhTotOra02,
		@SbilMWhTotOra03,
		@SbilMWhTotOra04,
		@SbilMWhTotOra05,
		@SbilMWhTotOra06,
		@SbilMWhTotOra07,
		@SbilMWhTotOra08,
		@SbilMWhTotOra09,
		@SbilMWhTotOra10,
		@SbilMWhTotOra11,
		@SbilMWhTotOra12,
		@SbilMWhTotOra13,
		@SbilMWhTotOra14,
		@SbilMWhTotOra15,
		@SbilMWhTotOra16,
		@SbilMWhTotOra17,
		@SbilMWhTotOra18,
		@SbilMWhTotOra19,
		@SbilMWhTotOra20,
		@SbilMWhTotOra21,
		@SbilMWhTotOra22,
		@SbilMWhTotOra23,
		@SbilMWhTotOra24,
		@SbilMWhTotOra25)
return
	
end

GO

-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------



ALTER PROCEDURE [dbo].[spReportOffertePerContratto] 
@IdContratto as int,
@DataProgramma as datetime,
@ProgrammatoDalCedente as bit
AS


select 

PeriodoRilevante, 
CodiceUnitaSDC, 
CategoriaUnitaSDC, 
cast(QtyMWhAssegnataMGP as decimal(16,3)) as QtyMWhAssegnataMGP, 
cast(QtyMWh as decimal(16, 3)) as QtyMWh, 
cast(QtyMWhBilanciamento as decimal(16, 3)) as QtyMWhBilanciamento 

from ProgrammaOrarioPerUnita 

where 

IdContratto = @IdContratto 
and DataProgramma = @DataProgramma 
--and not QtyMWhAssegnataMGP is null 
and not GMEReferenceNumber is null
and ((@ProgrammatoDalCedente is null) or programmatoDalCedente = @ProgrammatoDalCedente)

order by 
CodiceUnitaSDC, 
CategoriaUnitaSDC, 
PeriodoRilevante 

GO




--======================================================================
--======================================================================
--======================================================================
--======================================================================

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


--======================================================================
--======================================================================
--======================================================================
--======================================================================


ALTER  PROCEDURE [dbo].[spReportQtaPgmTotPerOperatore] 
@d as datetime,
@op as varchar(16) = null
AS


-- -- declare @d datetime
-- -- declare @op varchar(16)
-- -- set @d  = '15/1/2005'
-- -- -- set @op = 'OETEISR'
-- -- set @op = null


-- cancello la tabella se esiste ancora.
-- In una sp NON DOVREBBE ESISTERE PIU' perche` le tabelle
-- locali vengono cancellate quando la sp e` finita
-- Serve invece a livello di testing quando si esegue la query
-- non da SP da QueryAnalyzer
if Object_Id('tempdb..#Quantita') is Not Null
	drop table #Quantita

-- creo una tabella che conterra` le quantita` per operatore.
-- poi quando l'avro` memorizzata faro le somme per ottenere
-- i totali direttamente qua dentro.
create table #Quantita
(
Ord         integer,    -- vale zero per gli operatori, 1 per i totali
Operatore   varchar(16), 
MWhProd     float, 
MWhBilProd  float, 
MWhOffProd  float, 
MWhCons     float, 
MWhBilCons  float, 
MWhOffCons  float 
)

-- determino se e` stato effettuato il taglio per questa data.
declare @LetturaMGP integer 
select 
@LetturaMGP=LetturaMGP 
from 
SessioneBilaterali 
where DataProgramma=@d
if @LetturaMGP is null 
	set @LetturaMGP=0
---------------------------------------------------

if @LetturaMGP = 1
begin

-- MERCATO GIA` GIRATO

-- QUARTO PASSO
-- metto i risultati delle quantita` per operatore
-- nella tabella temporanea
insert into #Quantita

	-- TERZO PASSO
	-- Sommo le quantita` per Operatore/Unita raggruppando per Operatore
	-- e scartando quelle unita` che non sono piu` validte 
	-- nella UnitRelate
	select
		0 Ord,
		U.Operatore, 
		sum(U.QtyMWhP) MWhProd,
		sum(U.QtyMWhBilanciamentoP) MWhBilProd,
		sum(U.QtyMWhAssegnataMGPP) MWhOffProd,
	
		sum(U.QtyMWhC) MWhCons,
		sum(U.QtyMWhBilanciamentoC) MWhBilCons,
		sum(U.QtyMWhAssegnataMGPC) MWhOffCons
	
	from
	(
		-- SECONDO PASSO
		-- date le programmazioni per unita, operatore su tutti i contratti,
		-- le raggruppo per operatore/utente, sommando la Qty delle unita
		-- presenti su piu` contratti.
		select 
			T.CodiceUnitaSDC,
			T.Operatore, 
	
			sum(ProgrammatoDalCedente * T.QtyMWh) QtyMWhP,
			sum(ProgrammatoDalCedente * T.QtyMWhBilanciamento) QtyMWhBilanciamentoP,
			sum(ProgrammatoDalCedente * T.QtyMWhAssegnataMGP)QtyMWhAssegnataMGPP,
	
			sum((1-ProgrammatoDalCedente) * T.QtyMWh) QtyMWhC,
			sum((1-ProgrammatoDalCedente) * T.QtyMWhBilanciamento) QtyMWhBilanciamentoC,
			sum((1-ProgrammatoDalCedente) * T.QtyMWhAssegnataMGP)QtyMWhAssegnataMGPC
	
		from
		(
				-- PRIMO PASSO
				select 
				ProgrammaOrarioPerUnita.ProgrammatoDalCedente,
				ProgrammaOrarioPerUnita.CodiceUnitaSDC,

				case ProgrammaOrarioPerUnita.ProgrammatoDalCedente 
				when 1 then Contratto.CodiceOperatoreSDCCedente 
				else        Contratto.CodiceOperatoreSDCAcquirente
				end Operatore, 

				ProgrammaOrarioPerUnita.QtyMWh,
				isnull(ProgrammaOrarioPerUnita.QtyMWhBilanciamento, ProgrammaOrarioPerUnita.QtyMWh) QtyMWhBilanciamento,
				ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP

				from ProgrammaOrarioPerUnita 
				
				inner join ProgrammaOrario 
				on  ProgrammaOrario.IdContratto      = ProgrammaOrarioPerUnita.IdContratto 
				and ProgrammaOrario.DataProgramma    = ProgrammaOrarioPerUnita.DataProgramma 
				and ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante 
				and not ProgrammaOrario.Bilanciato is null
				
				inner join Contratto 
				on  Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

				left outer join ProgrammaOrarioPerUnitaErrori 
				on  ProgrammaOrarioPerUnita.DataProgramma     = ProgrammaOrarioPerUnitaErrori.DataProgramma
				and ProgrammaOrarioPerUnita.PeriodoRilevante  = ProgrammaOrarioPerUnitaErrori.PeriodoRilevante
				and ProgrammaOrarioPerUnita.IdContratto       = ProgrammaOrarioPerUnitaErrori.IdContratto
				and ProgrammaOrarioPerUnita.CodiceUnitaSDC    = ProgrammaOrarioPerUnitaErrori.CodiceUnitaSDC
				and ProgrammaOrarioPerUnita.CategoriaUnitaSDC = ProgrammaOrarioPerUnitaErrori.CategoriaUnitaSDC
		
				where
				ProgrammaOrarioPerUnita.DataProgramma = @d 
				-- indica in contratto valido al momento della data di flusso
				and ProgrammaOrario.Bilanciato is not null
				and ProgrammaOrario.ProgrammaOrarioValidato = 1
				and
				(
					-- e` andato a mercato --> lo conto
					ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is not null
					-- c'e` stato un errore --> lo conto
					or ProgrammaOrarioPerUnitaErrori.IdContratto is not null
					-- e` stato bilanciato --> lo conto
					or ProgrammaOrarioPerUnita.QtyMWhBilanciamento is not null
					-- se ho ricevuto il GMEReferenceNumber vuol dire che e` andato a mercato
					or ProgrammaOrarioPerUnita.GMEReferenceNumber is not null
					-- scarto quelli con QtyMWhBilanciamento is null
				)	
				and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
		) T
		group by 
			T.CodiceUnitaSDC,
			T.Operatore
	) U
	group by U.Operatore

end

else

begin

-- MERCATO DA GIRARE

-- QUARTO PASSO
-- metto i risultati delle quantita` per operatore
-- nella tabella temporanea
insert into #Quantita
	-- TERZO PASSO
	-- Sommo le quantita` per Operatore/Unita raggruppando per Operatore
	-- e scartando quelle unita` che non sono piu` validte 
	-- nella UnitRelate
	select
		0 Ord,
		U.Operatore, 
		sum(U.QtyMWhP) MWhProd,
		sum(U.QtyMWhBilanciamentoP) MWhBilProd,
		sum(U.QtyMWhAssegnataMGPP) MWhOffProd,
	
		sum(U.QtyMWhC) MWhCons,
		sum(U.QtyMWhBilanciamentoC) MWhBilCons,
		sum(U.QtyMWhAssegnataMGPC) MWhOffCons
	
	from
	(
		-- SECONDO PASSO
		-- date le programmazioni per unita, operatore su tutti i contratti,
		-- le raggruppo per operatore/utente, sommando la Qty delle unita
		-- presenti su piu` contratti.
		select 
			T.CodiceUnitaSDC,
			T.Operatore, 
	
			sum(ProgrammatoDalCedente * T.QtyMWh) QtyMWhP,
			sum(ProgrammatoDalCedente * T.QtyMWhBilanciamento) QtyMWhBilanciamentoP,
			sum(ProgrammatoDalCedente * T.QtyMWhAssegnataMGP)QtyMWhAssegnataMGPP,
	
			sum((1-ProgrammatoDalCedente) * T.QtyMWh) QtyMWhC,
			sum((1-ProgrammatoDalCedente) * T.QtyMWhBilanciamento) QtyMWhBilanciamentoC,
			sum((1-ProgrammatoDalCedente) * T.QtyMWhAssegnataMGP)QtyMWhAssegnataMGPC
	
		from
		(
				-- PRIMO PASSO
				-- qui trovo tutte le programmazioni e l'operatore che le ha fatte
				-- sono tutti record validi. L'unico controllo ancora non fatto
				-- e` nella unit-relate
				-- Ritorno i record per Contratto/Unita/Operatore, in pratica una riga per POU
				select 
				ProgrammaOrarioPerUnita.ProgrammatoDalCedente,
				ProgrammaOrarioPerUnita.CodiceUnitaSDC,

				case ProgrammaOrarioPerUnita.ProgrammatoDalCedente 
					when 1 then Contratto.CodiceOperatoreSDCCedente 
					else        Contratto.CodiceOperatoreSDCAcquirente
				end Operatore, 

				ProgrammaOrarioPerUnita.QtyMWh,
				isnull(ProgrammaOrarioPerUnita.QtyMWhBilanciamento, ProgrammaOrarioPerUnita.QtyMWh) QtyMWhBilanciamento,
				ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP

				from ProgrammaOrarioPerUnita 
				
				inner join ProgrammaOrario 
				on  ProgrammaOrario.IdContratto      = ProgrammaOrarioPerUnita.IdContratto 
				and ProgrammaOrario.DataProgramma    = ProgrammaOrarioPerUnita.DataProgramma 
				and ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante 
				and ProgrammaOrario.ProgrammaOrarioValidato = 1 
				and not ProgrammaOrario.Bilanciato is null
				
				inner join Contratto 
				on  Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 
				and Contratto.StatoContratto = 'Abilitato' 
				and Contratto.TrCN = 1 
				and Contratto.DataInizioValidita <= @d 
				and Contratto.DataFineValidita >= @d 
		
				where
				    ProgrammaOrarioPerUnita.DataProgramma = @d 
				and ProgrammaOrarioPerUnita.PeriodoRilevante <= 25
				and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 
		) T
		group by 
			T.CodiceUnitaSDC,
			T.Operatore
	) U
	inner join UnitRelate UR
	on  UR.CodiceUnitaSDC = U.CodiceUnitaSDC
	and UR.CategoriaUnitaSDC = 'F'
	and UR.CodiceOperatoreSDC = U.Operatore
	and UR.DataInizioValidita <= @d
	and UR.DataFineValidita >= @d
	and UR.Abilitata = 1
	and UR.TrUC = 1
	
	group by U.Operatore

end


-- QUINTO PASSO
-- Sommo tutte le quantita` presenti nella tabella per ottenere i totali
-- metto Ord = 1
-- notare che si specifica l'operatore NON viene fatta la riga totali
insert into #Quantita
	select
	1                             Ord,
	'Totale:'                     Operatore, 
	round( sum(MWhProd),    3) as MWhProd, 
	round( sum(MWhBilProd), 3) as MWhBilProd, 
	round( sum(MWhOffProd), 3) as MWhOffProd, 
	round( sum(MWhCons),    3) as MWhCons, 
	round( sum(MWhBilCons), 3) as MWhBilCons, 
	round( sum(MWhOffCons), 3) as MWhOffCons 
	from #Quantita


-- SESTO PASSO
-- questi sono i risultati
-- faccio vedere i record per operatore prima e i totali poi.
select 
* 
from 
#Quantita
where (@op is null) or (@op = Operatore)
order by
Ord, Operatore

-- QUI NON CANCELLO LA TABELLA per evitare di non vedere l'execution plan.
-- comunque (in caso di test da Query Analyzer) all'inizio la ricancello se esiste.
-- In caso di SP questa tabella viene cancellata quando la SP esce.
-- 
-- drop table #Quantita

return 0
go



SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

--======================================================================
--======================================================================
--======================================================================
--======================================================================


ALTER   PROCEDURE [dbo].[spReportCapacitaTrasporto] 
	@DataProgrammaMin as smalldatetime,
 	@DataProgrammaMax as smalldatetime,
 	@Transitorio as int,
	@Operatore as varchar(16)
AS

--questo report rischia di estrarre cosi' tanti dati da rendere necessario
--la read uncommitted
set transaction isolation level read uncommitted

select X.CodiceOperatoreSDC,
O.RagioneSociale,
C.CRN,
C.CodiceContratto,
X.Corrispettivo

from
(

select 
CodiceOperatoreSDC,
IdContratto,
sum(T.Corr) Corrispettivo

from
(

select
POU.DataProgramma,
POU.CodiceOperatoreSDC,
POU.IdContratto,
POU.CodiceContratto,
POU.CodiceUnitaSDC,
POU.CategoriaUnitaSDC,
POU.PeriodoRilevante,
POU.TipoUnita,
cast(POU.PrezzoUnico  as decimal(19, 6)) as PrezzoUnico,   -- il prezzo unico  e` a 6 cifre
cast(POU.PrezzoZonale as decimal(19, 6)) as PrezzoZonale,  -- il prezzo zonale e` a 6 cifre
cast(QtyMGP as decimal(16,3)) Qty, -- la quantita` in MWh e` a 3 cifre

-- qui si ha:
-- QtyMGP>0 per P
-- QtyMGP<0 per C
-- QtyMGP>0 per M che producono
-- QtyMGP<0 per M che consumano

cast(
	-- caso per i programmi di produzione/consumo ossia con contratti bilanciati
	case TipoUnita 
	when 'P' then  ROUND(-1 * QtyMGP * ROUND(PrezzoZonale,6), 2)
	when 'C' then  ROUND(-1 * QtyMGP * ROUND(PrezzoUnico, 6), 2)
	when 'M' then  ROUND(-1 * QtyMGP * ROUND(PrezzoZonale,6), 2)
	end 

	as decimal(16, 2)) Corr  -- gli euro dei corrispettivi escono in centesimi (e nel report XML Corrispettivi saranno a 2 cifre  - come sta scritto qui! se ci fosse un ,3 avremmo 3 cifre nel xml)

from 
(
select 
ProgrammaOrarioPerUnita.DataProgramma,
Contratto.CodiceOperatoreSDC,
Contratto.IdContratto,
Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita / SDC_Unita.CoefficientePerdita QtyMGP,
SDC_Unita.TipoUnita,
SDC_Unita.CoefficientePerdita KU,
SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP,
SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
PrezzoUnitario.Prezzo PrezzoUnico,
PrezzoZonale.Prezzo PrezzoZonale

from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

 inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

 inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

where not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
and ProgrammaOrarioPerUnita.DataProgramma >= @DataProgrammaMin
and ProgrammaOrarioPerUnita.DataProgramma <= @DataProgrammaMax

and (Contratto.CodiceOperatoreSDC = @Operatore or @Operatore = '')
) POU

) T
group by 
T.CodiceOperatoreSDC, 
T.IdContratto
) X,
SDC_Operatori O,
Contratto C
 where X.CodiceOperatoreSDC = O.CodiceOperatoreSDC
and C.IdContratto = X.IdContratto
and (X.CodiceOperatoreSDC = @Operatore or @Operatore = '')

order by 
X.CodiceOperatoreSDC,
C.CRN



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



--======================================================================
--======================================================================
--======================================================================
--======================================================================

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[OnOperatoriInsert]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
drop trigger [dbo].[OnOperatoriInsert]
GO


CREATE TRIGGER OnOperatoriInsert ON [dbo].[Operatori] 
FOR INSERT
AS

-- associo d'ufficio
-- ad ATrebbi il nuovo operatore

declare @op as varchar(16)
select @op = inserted.CodiceOperatoreSDC from inserted

if not exists
(
	select 
	* 
	from
	RelOperatoriUtenti
	where 
	CodiceUtenteSDC = @op
	and CodiceUtenteSDC = 'ATREBBI'
)
and exists
(
	select 
	* 
	from
	Utenti
	where 
	CodiceUtenteSDC = 'ATREBBI'
)
begin

	INSERT INTO RelOperatoriUtenti
	(
	CodiceUtenteSDC, 
	CodiceOperatoreSDC, 
	Amministratore, 
	Abilitato, 
	TSIniValidita, 
	TSEndValidita, 
	CodiceRuolo, 
	TSModifica
	)
	VALUES 
	(
	'ATREBBI', 
	@op, 
	0, 
	1, 
	convert(datetime,convert(varchar,getdate(),112)), -- oggi
	convert(datetime,convert(varchar,getdate(),112)) + 10000, -- tra 10000 giorni
	'root', 
	getdate()
	)

end



go




-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------

----------------------------------------------------------------------------------
--Inizio script inserimento ruoli di default
--Inserimento ruoli
INSERT INTO Ruoli (CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES ('root', 'root', GETDATE())
INSERT INTO Ruoli (CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES ('Fatt', 'Fatturazione', GETDATE())
INSERT INTO Ruoli (CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES ('OpEn', 'Operatore Energia', GETDATE())
INSERT INTO Ruoli (CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES ('OpAn', 'Operatore Anagrafica', GETDATE())
--Inserimento funzioni
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('FA', 'Fatturazione', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('GA', 'Gestione Anagrafica', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('GC', 'Gestione Contratti', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('PC', 'Pannello di Controllo', GETDATE())
INSERT INTO Funzioni (CodiceFunzione, DescrizioneFunzione, TSModifica) VALUES ('RP', 'Reportistica', GETDATE())
--Inserimento relazione ruoli funzioni
--Root Abilitato a tutte le funzioni
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('FA', 'root', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('GA', 'root', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('GC', 'root', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('PC', 'root', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('RP', 'root', GETDATE())
--Fatt Abilitato alle funzioni di Fatturazione e Reportistica
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('FA', 'Fatt', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('RP', 'Fatt', GETDATE())
--OpEn Abilitato alle funzioni di Pannello Controllo, Reportistica e Gestione Contratti
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('PC', 'OpEn', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('RP', 'OpEn', GETDATE())
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('GC', 'OpEn', GETDATE()) 
--OpAn Abilitato alla funzione di Gestione Anagrafica
INSERT INTO RuoliFunzioni (CodiceFunzione, CodiceRuolo, TSModifica) VALUES ('GA', 'OpAn', GETDATE())




print 'UPDATE Version ON DBVersion'
UPDATE DBVersion SET Version = '2.3.1.0'

print 'UPDATE DBHistory'
INSERT INTO DBHistory (Version, Patch, UpgradeTS, Notes)
VALUES('2.3.1.0', NULL, getdate(), 'Upgrade alla Versione 2.3.1.0')




