CREATE PROCEDURE dbo.CambiaCodiceOperatore
	@OpV varchar(16),
	@OpN varchar(16)
AS

if @OpV = @OpN
begin
	raiserror('lanciare la SP con codici DIVERSI - gli spazi NON sono significativi', 1, 1)
	return 1
end

declare @e as int


set transaction isolation level serializable

begin tran

select * from sdc_operatori
where codiceoperatoresdc = @OpV

select * from operatori
where codiceoperatoresdc = @OpV

select * from sdc_unita
where CodiceOperatoreDiRiferimentoSDC = @OpV

--RelOperatoriUtenti
select * from RelOperatoriUtenti
where codiceoperatoresdc = @OpV

-- UnitRelate
select * from UnitRelate
where codiceoperatoresdc = @OpV

-- XmlFileDaOperatori
select * from XmlFileDaOperatori
where codiceoperatoresdc = @OpV

-- XmlProgrammiUtenti
select * from XmlProgrammiUtenti
where codiceoperatoresdc = @OpV

-- FileOperatori
select * from FileOperatori
where codiceoperatoresdc = @OpV

-- Contratto
select * from Contratto
where codiceoperatoresdc = @OpV


print 'insert sdc_operatori'
insert into sdc_operatori
(CodiceOperatoreSDC, RagioneSociale, Indirizzo1, Indirizzo2, Citta,
Nazione, CodiceFiscale, PartitaIva, Fax, Email, ReferenteAmministrativo,
SedeAmministrativa,
Abilitato, TSModifica, ResponsabileAggiornamento)
select @OpN as CodiceOperatoreSDC, RagioneSociale, Indirizzo1, Indirizzo2, Citta,
Nazione, CodiceFiscale, PartitaIva, Fax, Email, ReferenteAmministrativo,
SedeAmministrativa,
Abilitato, TSModifica, ResponsabileAggiornamento from sdc_operatori
where codiceoperatoresdc = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso inserire il record in sdc_operatori', 1, 1)
 	return @e
end


print 'insert operatori'

insert into operatori
(CodiceOperatoreSDC, StatoBilateraliOperatore,
TSModifica, Amministratore, IsGMEOp)
select @OpN as CodiceOperatoreSDC, StatoBilateraliOperatore,
TSModifica, Amministratore, IsGMEOp 
from operatori
where codiceoperatoresdc = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso inserire il record in operatori', 1, 1)
 	return @e
end

			
-- RelOperatoriUtenti
print 'RelOperatoriUtenti'
update 
RelOperatoriUtenti
set CodiceOperatoreSDC = @OpN
where CodiceOperatoreSDC = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in RelOperatoriUtenti', 1, 1)
 	return @e
end

		
-- UnitRelate
print 'UnitRelate'
update 
UnitRelate
set CodiceOperatoreSDC = @OpN
where CodiceOperatoreSDC = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in UnitRelate', 1, 1)
 	return @e
end
		
-- XmlFileDaOperatori
print 'XmlFileDaOperatori'
update 
XmlFileDaOperatori
set CodiceOperatoreSDC = @OpN
where CodiceOperatoreSDC = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in XmlFileDaOperatori', 1, 1)
 	return @e
end

		
-- XmlProgrammiUtenti
print 'XmlProgrammiUtenti'
update
XmlProgrammiUtenti
set CodiceOperatoreSDC = @OpN
where CodiceOperatoreSDC = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in XmlProgrammiUtenti', 1, 1)
 	return @e
end

		
-- FileOperatori
print 'FileOperatori'
update
FileOperatori
set CodiceOperatoreSDC = @OpN
where CodiceOperatoreSDC = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in FileOperatori', 1, 1)
 	return @e
end

		
-- SDC_Unita
print 'SDC_Unita'
update
SDC_Unita
set CodiceOperatoreDiRiferimentoSDC = @OpN
where CodiceOperatoreDiRiferimentoSDC = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in SDC_Unita', 1, 1)
 	return @e
end

		
-- Contratto
print 'Contratto 1'
update 
Contratto
set CodiceOperatoreSDC = @OpN
where CodiceOperatoreSDC = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in Contratto 1', 1, 1)
 	return @e
end


print 'Contratto 2'
update 
Contratto
set CodiceOperatoreSDCAcquirente = @OpN
where CodiceOperatoreSDCAcquirente = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in Contratto 2', 1, 1)
 	return @e
end

print 'Contratto 3'		
update 
Contratto
set CodiceOperatoreSDCCedente = @OpN
where CodiceOperatoreSDCCedente = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso updatare il record in Contratto 3', 1, 1)
 	return @e
end


print 'delete operatori'		

delete from operatori
where codiceoperatoresdc = @OpV

set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso cancellare il record in operatori', 1, 1)
 	return @e
end


print 'delete sdc_operatori'		
delete from sdc_operatori
where codiceoperatoresdc = @OpV
set @e = @@ERROR
if @e != 0
begin
	rollback
	raiserror('non posso cancellare il record in sdc_operatori', 1, 1)
 	return @e
end


commit

print 'cambio codice operatore effettuato'

return 0

