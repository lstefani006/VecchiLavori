/* ------------------------------------------------------------------------------------------ 
 * Upgrade Database: script SQL per l'upgrade del Database in versione 2.0.0.0
 * Versione Iniziale: 2.2.0.4
 * Versione Finale:   2.3.0.0
 * D.C.: 24/11/2004
 * U.M.: 02/02/2005
 * ------------------------------------------------------------------------------------------ 
*/

use [Bilaterali]

DECLARE @Version AS VARCHAR(16)

SELECT @Version = Version 
FROM DBVersion
PRINT 'Il database e` in versione: ' + @Version

IF @Version <> '2.2.0.4'
	PRINT 'Il database non e` nella versione prevista !'




print 'Modifica tabella [ProgrammaOrario].'
GO

ALTER TABLE [dbo].[ProgrammaOrario] ADD
	SbilMGPalCP float(53) NULL 
GO


print 'Aggiornamento tabella [ProgrammaOrario].'

print 'Aggiornamento Stored Procedure [spChiudiMercato].'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spChiudiMercato]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spChiudiMercato]
GO




CREATE PROCEDURE dbo.spChiudiMercato
	@d as datetime
AS

-- declare @d as datetime
-- set @d = '10/12/2004'

-- qui per evitare problemi cancello gli eventuali
-- SbilMGPalCP gia` valorizzati
-- (es ha chiuso e riaperto il mercato)
-- In realta` questa update e` solo per tranquillita` dato
-- che spRiapriMercato fa la stessa cosa.
update ProgrammaOrario
set SbilMGPalCP = NULL
where 
DataProgramma = @d
and SbilMGPalCP is not null


update ProgrammaOrario
-- questo round e` voluto per evitare di vedere cifre come 3E-16
set SbilMGPalCP = round(T.SbilMGPalCP, 5)
from ProgrammaOrario PO
inner join
(
	select 
	POU.IdContratto, 
	POU.DataProgramma,
	POU.PeriodoRilevante, 
	sum(QtyMWhAssegnataMGP * PR.CoefficienteDiPerdita / U.CoefficientePerdita) SbilMGPalCP
	from 
	ProgrammaOrarioPerUnita POU
	
	inner join SDC_Unita U
	on  U.CodiceUnitaSDC = POU.CodiceUnitaSDC
	and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
	
	inner join SDC_PuntiDiScambioRilevanti PR
	on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC
	
	where POU.DataProgramma = @d
	and   POU.QtyMWhAssegnataMGP is not null
	
	group by
	POU.IdContratto,
	POU.DataProgramma,
	POU.PeriodoRilevante
) T
on  PO.IdContratto      = T.IdContratto
and PO.DataProgramma    = T.DataProgramma
and PO.PeriodoRilevante = T.PeriodoRilevante
where PO.DataProgramma = @d
GO


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spChiudiMercato]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spChiudiMercato]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spChiudiMercato]  TO [bil_dbo]
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


print 'Aggiornamento Stored Procedure [spChiudiMercato] concluso.'


-- Lo scopo di questo script e`
-- 1) identificare la data flusso iniziale e finale
--    la data iniziale e` sicuramente 1/1/2005
--    la data di flusso finale viene valorizzata sull'ultima 
--    data di flusso che ha effettuato la lettura di mercato
-- 2) chiamare la sp di chiusura mercato per fare il lavoro di denormalizzazione su PO
--    giorno per giorno.

declare @di datetime
declare @df datetime

-- dal 1/1/2005
select @di = convert(datetime, '20050101', 112)

-- alla data di flusso maggiore per cui si e` effettuata la lettura del mercato
-- (uso la lettura perche` ogni tanto la chiusura se la dimenticano)
select @df = max(dataProgramma) 
from 
SessioneBilaterali
where
LetturaMgp = 1

declare @d as smalldatetime
set @d = @di

while @d <= @df
begin
	print @d

	-- qui chiudo il maniera forzata la sessione bilaterali per la data @d
	-- quando l'op si e` dimenticato della chiusura
	-- (solo se e` NULL la dataChiusuraMGP)
	-- per convenzione chiudo il tutto alle 23:59:59
	update SessioneBilaterali
	set
	DataChiusuraMGP = @d + convert(varchar, '23:59:59', 108)
	where 
	DataProgramma = @d
	and
	DataChiusuraMGP is null

	-- qui si esegue la chiusura mercato, ossia si valorizza il nuovo campo in PO.
	exec spChiudiMercato @d

	-- altro giro al successivo giorno
	set @d = 1 + @d
end



--
-- Rimuovo il report dai QuickReport
--

delete from ReportQueries where codiceReport='VEOPAQIPX'

print 'Aggiornamento Stored Procedure [spBilGetDettagliProgrammazioneOraria].'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetDettagliProgrammazioneOraria]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spBilGetDettagliProgrammazioneOraria]
GO



CREATE  PROCEDURE [dbo].[spBilGetDettagliProgrammazioneOraria]
	@IdContratto int,
	@PeriodoRilevante tinyint,
	@DataProgramma smalldatetime

AS

-- qui non si usa read uncommitted per evitare di fargli leggere dati incompleti

-- Codice utile per provare la query nell'SQL Analyzer
--declare @IdContratto int,
--	@PeriodoRilevante tinyint,
--	@DataProgramma smalldatetime

--set @IdContratto = 13
--set @PeriodoRilevante = 1
--set @DataProgramma = '04/20/2004'

SELECT 
POU2.CodiceUnitaSDC,
POU2.CategoriaUnitaSDC,
POU2.NomeUnita,
POU2.QtyMWh,
POU2.QtyMWhBilanciamento,
POU2.QtyMWhAssegnataMGP,
PSR.CoefficienteDiPerdita PSRPerdita,
POU2.CoefficientePerdita UnitaPerdita,
POU2.ProgOrarioDellUnitaValidato
FROM 
SDC_PuntiDiScambioRilevanti PSR
INNER JOIN
(
	SELECT 
	Unita.CoefficientePerdita,
	Unita.CodiceUnitaSDC,
	Unita.CategoriaUnitaSDC,
	Unita.NomeUnita,
	Unita.CodicePuntoDiScambioRilevanteSDC,
	POU.QtyMWh,
	POU.QtyMWhBilanciamento,
	POU.QtyMWhAssegnataMGP,
	POU.ProgOrarioDellUnitaValidato,
	POU.IdProgrammaXml, 
	POU.ProgressivoNelProgramma
	FROM
	(
		-- Prelevo tutte le unita del contratto valide ed abilitate
		SELECT 
		SDC_Unita.CoefficientePerdita,
		SDC_Unita.CodiceUnitaSDC,
		SDC_Unita.CategoriaUnitaSDC,
		SDC_Unita.NomeUnita,
		SDC_Unita.CodicePuntoDiScambioRilevanteSDC
		FROM SDC_Unita 
		INNER JOIN 
		(
			-- Prelevo tutte le unita del contratto che debbono essere programmate (sono piu` delle unita`  valide ed abilitate)
			SELECT 
			CodiceUnitaSDC,
			CategoriaUnitaSDC
			FROM tab_UnitaContratto2(@DataProgramma, @IdContratto) UnitaContratto
			WHERE IdContratto = @IdContratto
			AND UnitaDelContrattoValidata = 1
			AND TrCC = 1
			AND TrUC = 1
			AND UnitaContratto.DataInizioValidita <= @DataProgramma
			AND UnitaContratto.DataFineValidita >= @DataProgramma
		) UC
		ON SDC_Unita.CodiceUnitaSDC = UC.CodiceUnitaSDC
		AND SDC_Unita.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
	) Unita
	INNER JOIN
	(
		SELECT 
		CodiceUnitaSDC,
		CategoriaUnitaSDC,
		QtyMWh,
		QtyMWhBilanciamento,
		QtyMWhAssegnataMGP,
		ProgOrarioDellUnitaValidato,
		IdProgrammaXml, 
		ProgressivoNelProgramma
		FROM 
		ProgrammaOrarioPerUnita
		WHERE 
		DataProgramma = @DataProgramma AND
		PeriodoRilevante = @PeriodoRilevante AND
		IdContratto = @IdContratto	
	) POU
	ON  POU.CodiceUnitaSDC = Unita.CodiceUnitaSDC
	AND POU.CategoriaUnitaSDC = Unita.CategoriaUnitaSDC
) POU2
ON PSR.CodicePuntoDiScambioRilevanteSDC = POU2.CodicePuntoDiScambioRilevanteSDC

order by 
POU2.IdProgrammaXml, 
POU2.ProgressivoNelProgramma




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOraria]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOraria]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOraria]  TO [bil_dbo]
GO




SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [spBilGetDettagliProgrammazioneOraria] concluso.'



print 'Aggiornamento Stored Procedure [spBilGetDettagliProgrammazioneOrariaClient].'



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetDettagliProgrammazioneOrariaClient]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spBilGetDettagliProgrammazioneOrariaClient]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



CREATE  PROCEDURE [dbo].[spBilGetDettagliProgrammazioneOrariaClient]
	@IdContratto int,
	@PeriodoRilevante tinyint,
	@DataProgramma smalldatetime,
	@Operatore varchar(16)

AS

-- non utilizziamo read uncommitted per evitare di leggere dati incompleti

-- Codice utile per provare la query nell'SQL Analyzer
--declare @IdContratto int,
--	@PeriodoRilevante tinyint,
--	@DataProgramma smalldatetime,
--	@Operatore varchar(16)

--set @IdContratto = 13
--set @PeriodoRilevante = 1
--set @DataProgramma = '04/20/2004'
--set @Operatore = 'IDAU'

SELECT POU2.CodiceUnitaSDC,
	POU2.CategoriaUnitaSDC,
	POU2.NomeUnita,
	POU2.QtyMWh,
	POU2.QtyMWhBilanciamento,
	POU2.QtyMWhAssegnataMGP,
	PSR.CoefficienteDiPerdita PSRPerdita,
	POU2.CoefficientePerdita UnitaPerdita,
	POU2.ProgOrarioDellUnitaValidato
FROM SDC_PuntiDiScambioRilevanti PSR
INNER JOIN
(
	SELECT Unita.CoefficientePerdita,
		Unita.CodiceUnitaSDC,
		Unita.CategoriaUnitaSDC,
		Unita.NomeUnita,
		Unita.CodicePuntoDiScambioRilevanteSDC,
		POU.QtyMWh,
		POU.QtyMWhBilanciamento,
		POU.QtyMWhAssegnataMGP,
		POU.ProgOrarioDellUnitaValidato,
        POU.IdProgrammaXml,
        POU.ProgressivoNelProgramma

	FROM
	(
	-- Prelevo tutte le unita del contratto valide ed abilitate
	SELECT SDC_Unita.CoefficientePerdita,
		SDC_Unita.CodiceUnitaSDC,
		SDC_Unita.CategoriaUnitaSDC,
		SDC_Unita.NomeUnita,
		SDC_Unita.CodicePuntoDiScambioRilevanteSDC
	FROM SDC_Unita 
	INNER JOIN 
		(
		-- Prelevo tutte le unita del contratto valide ed abilitate
		SELECT CodiceUnitaSDC,
			CategoriaUnitaSDC
		FROM 	tab_UnitaContratto2(@DataProgramma, @IdContratto) UnitaContratto, 
			Contratto
		WHERE UnitaContratto.IdContratto = @IdContratto
		AND Contratto.IdContratto = @IdContratto
		AND UnitaDelContrattoValidata = 1
		AND UnitaContratto.DataInizioValidita <= @DataProgramma
		AND UnitaContratto.DataFineValidita >= @DataProgramma
		AND TrCC = 1
		AND TrUC = 1
		AND(UnitaAssegnataOpAcquirente = 1 AND CodiceOperatoreSDCAcquirente=@Operatore OR
			UnitaAssegnataOpCedente = 1 AND CodiceOperatoreSDCCedente=@Operatore)
		) UC
		
	ON SDC_Unita.CodiceUnitaSDC = UC.CodiceUnitaSDC
	AND SDC_Unita.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
	) Unita
	INNER JOIN
	(
		SELECT CodiceUnitaSDC,
			CategoriaUnitaSDC,
			QtyMWh,
			QtyMWhBilanciamento,
			QtyMWhAssegnataMGP,
			ProgOrarioDellUnitaValidato,
            IdProgrammaXml,
            ProgressivoNelProgramma
		FROM ProgrammaOrarioPerUnita
		WHERE DataProgramma = @DataProgramma AND
			PeriodoRilevante = @PeriodoRilevante AND
			IdContratto = @IdContratto
			
	) POU
	ON POU.CodiceUnitaSDC = Unita.CodiceUnitaSDC
	AND POU.CategoriaUnitaSDC = Unita.CategoriaUnitaSDC
) POU2
ON PSR.CodicePuntoDiScambioRilevanteSDC = POU2.CodicePuntoDiScambioRilevanteSDC
order by
POU2.IdProgrammaXml,
POU2.ProgressivoNelProgramma



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOrariaClient]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOrariaClient]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOrariaClient]  TO [bil_dbo]
GO




SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [spBilGetDettagliProgrammazioneOrariaClient] concluso.'



print 'Aggiornamento Stored Procedure [spRiapriMercato].'


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spRiapriMercato]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spRiapriMercato]
GO


CREATE PROCEDURE dbo.spRiapriMercato
	@d as datetime
AS

-- declare @d as datetime
-- set @d = '10/12/2004'

-- Se si riapre il mercato ci sara` qualche ragione.
-- Esempio si deve rigirare tutto.
-- Meglio dunque fare pulizia.
update ProgrammaOrario
set SbilMGPalCP = null
where 
DataProgramma = @d
and SbilMGPalCP is not null



GO


GRANT  EXECUTE  ON [dbo].[spRiapriMercato]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spRiapriMercato]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spRiapriMercato]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
print 'Aggiornamento Stored Procedure [spRiapriMercato] concluso.'

print 'Aggiornamento Stored Procedure [spEseguiBilanciamentoPerContratto]'
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spEseguiBilanciamentoPerContratto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spEseguiBilanciamentoPerContratto]
GO



CREATE   PROCEDURE [dbo].[spEseguiBilanciamentoPerContratto]
	@IdContratto int,
	@DataProgramma smalldatetime,
	@PeriodoRilevante tinyint,
	@SogliaSbilMWh float
AS


-- STR 251: correzione di questa logica, le programmazioni a zero non vengono piu` inserite 
-- nella ProgrammaOrarioPerUnita, con conseguente beneficio per gli indici di POU.
-- Lasciamo la Delete di POUE, anche se in realta` non dovrebbe mai cancellare nulla 
-- (POUE puo` essere compilata in fase di Lettura Mercato, quindi dopo)
-- CANCELLAZIONE DELLE PROGRAMMAZIONI A ZERO MWH
-- =============================================
-- Questo NON e' il posto migliore per fare le cancellazioni della programmazione a zero MWh.
-- Il posto migliore dovrebbe essere ElaborazioneProgrammiUtenti.
-- Per motivi di tempo e di rischio oggi 24/12/2004 preferisco mettere qui questa
-- operazione.
-- La metto qui dato che il bilanciamento per contratto avviene ad ogni invio
-- del programma.
-- E' sicuramente stupido inserire/modificare record a zero per poi cancellarli, ma
-- dato il carattere di emergenza della modifica questo e` il posto migliore.
-- Notare che su ROMA4 si hanno circa 628.000 record in POU di cui 222.000 a 0MWh ossia
-- il 35% !! --> le query dovrebbero andare almeno un po' piu' veloci.
-- Unico rischio che vedo e` la frammentazione dell'indice.... per ora ignoro.
-- 
-- Prima cerco le programmazioni a zero in POU
-- per cancellare gli eventuali record collegati in POUE
-- (che NON dovrebbero esserci... ma per tranquillita` referenziale lo faccio)
-- Poi cancello le programmazioni a zero in POU

-- delete ProgrammaOrarioPerUnitaErrori
-- from
-- (
-- 	select
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC
-- 	from 
-- 	ProgrammaOrarioperUnita 
-- 	where 
-- 	         IdContratto      = @IdContratto
-- 	and DataProgramma    = @DataProgramma
-- 	and PeriodoRilevante = @PeriodoRilevante
-- 	and QtyMWh=0
-- ) T
-- where
--       ProgrammaOrarioPerUnitaErrori.IdContratto       = T.IdContratto
-- and ProgrammaOrarioPerUnitaErrori.DataProgramma     = T.DataProgramma
-- and ProgrammaOrarioPerUnitaErrori.PeriodoRilevante  = T.PeriodoRilevante
-- and ProgrammaOrarioPerUnitaErrori.CodiceUnitaSDC    = T.CodiceUnitaSDC
-- and ProgrammaOrarioPerUnitaErrori.CategoriaUnitaSDC = T.CategoriaUnitaSDC


--delete ProgrammaOrarioPerUnita
--where 
--    IdContratto      = @IdContratto
--and DataProgramma    = @DataProgramma
--and PeriodoRilevante = @PeriodoRilevante
--and QtyMWh           = 0


-- FINE CANCELLAZIONE PROGRAMMAZIONI A 0 MWH
-- =========================================









--=============================================================================================================

-- non si usa read uncommitted in quanto
-- il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@IdContratto int,
-- 	@DataProgramma smalldatetime,
-- 	@PeriodoRilevante tinyint,
-- 	@SogliaSbilMWh float
-- 
-- set @IdContratto = 212
-- set @DataProgramma = '1/12/2004'
-- set @PeriodoRilevante = 1
-- set @SogliaSbilMWh = 0.001


-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno/ora

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o valido non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.


-- per prima cosa azzero le informazioni in PO
update ProgrammaOrario
set 
Bilanciato=NULL,
SbilanciamentoMWh=NULL,
SbilanciamentoMWhReale=NULL,
TSCalcoloBilanciamento=NULL
from ProgrammaOrario
where
IdContratto = @IdContratto
and DataProgramma = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante

-- e conseguentemente in POU
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where DataProgramma = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante
and IdContratto = @IdContratto
and not QtyMWhBilanciamento is null

-- siccome sto facendo il calcolo del bilanciamento, potenzialmente
-- e` cambiato il bilanciamento e dunque potenzialemente
-- il taglio forzato e` da rifare.
update 
SessioneBilaterali
set
Taglio=0
where DataProgramma=@DataProgramma


declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()

update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,
	
	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then 0 else 1 end Bilanciato,
	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on
		POU.Idcontratto = PO.IdContratto
		and POU.DataProgramma = PO.DataProgramma
		and POU.PeriodoRilevante = PO.PeriodoRilevante
		and POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
		and POU.IdContratto = @IdContratto
		and POU.PeriodoRilevante = @PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join  SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

	) Q
	group by IdContratto, PeriodoRilevante

) W

on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[spEseguiBilanciamentoPerContratto]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spEseguiBilanciamentoPerContratto]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spEseguiBilanciamentoPerContratto]  TO [bil_dbo]
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
print 'Aggiornamento Stored Procedure [spEseguiBilanciamentoPerContratto] concluso.'


print 'Aggiornamento Stored Procedure [spGeneraCSP_OFF].'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGeneraCSP_OFF]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGeneraCSP_OFF]
GO


CREATE PROCEDURE dbo.spGeneraCSP_OFF
	@di as datetime,
	@df as datetime
AS

-- set transaction isolation level read uncommitted

select
C.CodiceOperatoreSDCAcquirente OpAcqIpex,
C.CRN,
T.DataProgramma,
T.PeriodoRilevante, 
T.QuantitaVendute,
T.ControvaloreEuro,
T.PrezzoUnico
from
(
	select 
	PO.IdContratto, 
	PO.DataProgramma,
	PO.PeriodoRilevante, 
	convert(decimal(15,3), PO.SbilMGPalCP) QuantitaVendute,
	convert(decimal(15,2), PU.Prezzo * PO.SbilMGPalCP) ControvaloreEuro,
	convert(decimal(15,6), PU.Prezzo) PrezzoUnico
	from 
	ProgrammaOrario PO

	inner join PrezzoUnitario PU
	on  PU.Data = PO.DataProgramma
	and PU.PeriodoRilevante = PO.PeriodoRilevante

	where 
	    PO.DataProgramma >= @di
	and PO.DataProgramma <= @df
	and PO.IsGMEOp = 1 -- qui considero i contratti per cui OpAcquirente e` IPEX
	and PO.SbilMGPalCP is not null
	and PO.SbilMGPalCP > 0
) T
-- qui aggancio il contratto cosi` ottengo il codice dell'operatore acquirente
inner join Contratto C
on C.IdContratto = T.IdContratto

order by 
C.CodiceOperatoreSDCAcquirente,
C.CRN,
T.DataProgramma,
T.PeriodoRilevante

---------------------------------------------------------------------------------


GO

GRANT  EXECUTE  ON [dbo].[spGeneraCSP_OFF]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spGeneraCSP_OFF]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGeneraCSP_OFF]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [spGeneraCSP_OFF] concluso.'

print 'Aggiornamento Stored Procedure [spNuovoProgrammaNonIncrementale].'

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spNuovoProgrammaNonIncrementale]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spNuovoProgrammaNonIncrementale]
GO






CREATE  PROCEDURE dbo.spNuovoProgrammaNonIncrementale
(
	@IdContratto      int,
	@DataProgramma    smalldatetime,
	@PeriodoRilevante tinyint,
	@IsOpCedente      tinyint,
	@IsOpAcquirente   tinyint
)
AS

	SET NOCOUNT ON

	-- cancello i record di ProgrammaOrarioPerUnitaErrori
	-- cancello tutto
	delete from ProgrammaOrarioPerUnitaErrori 
	where 
	IdContratto = @IdContratto and
	DataProgramma = @DataProgramma and 
	PeriodoRilevante = @PeriodoRilevante

	-- cancello i record di ProgrammaOrarioPerUnita
	
	if @IsOpCedente = 1 and @IsOpAcquirente = 1
	begin
		-- cancello tutto
		delete from ProgrammaOrarioPerUnita 
		where 
		IdContratto = @IdContratto and
		DataProgramma = @DataProgramma and 
		PeriodoRilevante = @PeriodoRilevante
	end
	else if @IsOpCedente = 1
	begin
		-- cancello i programmi del cedente
		delete from ProgrammaOrarioPerUnita 
		where 
		IdContratto = @IdContratto and
		DataProgramma = @DataProgramma and 
		PeriodoRilevante = @PeriodoRilevante and
		ProgrammatoDalCedente = 1
	end
	else if @IsOpAcquirente = 1
	begin
		-- cancello i programmi dell'acquirente
		delete from ProgrammaOrarioPerUnita 
		where 
		IdContratto = @IdContratto and
		DataProgramma = @DataProgramma and 
		PeriodoRilevante = @PeriodoRilevante and
		ProgrammatoDalCedente = 0
	end
	
	-- cancello ProgrammaOrario SOLO se non esistono piu` righe in POU
	
	delete from ProgrammaOrario
	where 
	IdContratto = @IdContratto and
	DataProgramma = @DataProgramma and 
	PeriodoRilevante = @PeriodoRilevante and
	not exists
	(
		select 
		* 
		from 
		ProgrammaOrarioPerUnita
		where
		IdContratto=@IdContratto and
		DataProgramma=@DataProgramma and 
		PeriodoRilevante = @PeriodoRilevante
	)






GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spNuovoProgrammaNonIncrementale]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spNuovoProgrammaNonIncrementale]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spNuovoProgrammaNonIncrementale]  TO [bil_dbo]
GO




print 'Aggiornamento Stored Procedure [spNuovoProgrammaNonIncrementale] concluso.'

print 'Aggiornamento Stored Procedure [spReportCapacitaTrasporto].'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportCapacitaTrasporto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportCapacitaTrasporto]
GO





CREATE  PROCEDURE [dbo].[spReportCapacitaTrasporto] 
	@DataProgrammaMin as smalldatetime,
 	@DataProgrammaMax as smalldatetime,
 	@Transitorio as int,
	@Operatore as varchar(16)
AS

--questo report rischia di estrarre cosi' tanti dati da rendere necessario
--la read uncommitted
set transaction isolation level read uncommitted

select X.CodiceOperatoreSDC,
O.RagioneSociale,
C.CRN,
C.CodiceContratto,
X.Corrispettivo

from
(

select 
CodiceOperatoreSDC,
IdContratto,
sum(T.Corr) Corrispettivo

from
(

select
POU.DataProgramma,
POU.CodiceOperatoreSDC,
POU.IdContratto,
POU.CodiceContratto,
POU.CodiceUnitaSDC,
POU.CategoriaUnitaSDC,
POU.PeriodoRilevante,
POU.TipoUnita,
cast(POU.PrezzoUnico  as decimal(19, 6)) as PrezzoUnico,   -- il prezzo unico  e` a 6 cifre
cast(POU.PrezzoZonale as decimal(19, 6)) as PrezzoZonale,  -- il prezzo zonale e` a 6 cifre
cast(QtyMGP as decimal(16,3)) Qty, -- la quantita` in MWh e` a 3 cifre

-- qui si ha:
-- QtyMGP>0 per P
-- QtyMGP<0 per C
-- QtyMGP>0 per M che producono
-- QtyMGP<0 per M che consumano

cast(
	case @Transitorio 
	when 1 then 
		-- caso per i programmi di sola produzione ossia con contratti sbilanciati ammessi
		case TipoUnita 
		when 'P' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2) 
		when 'C' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2)  
		when 'M' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2)  
		end
	else 
		-- caso per i programmi di produzione/consumo ossia con contratti bilanciati
		case TipoUnita 
		
		when 'P' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoZonale,6), 2)
		when 'C' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoUnico, 6), 2)
		when 'M' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoZonale,6), 2)
		end 
	end
	as decimal(16, 2)) Corr  -- gli euro dei corrispettivi escono in centesimi (e nel report XML Corrispettivi saranno a 2 cifre  - come sta scritto qui! se ci fosse un ,3 avremmo 3 cifre nel xml)

from 
(
select 
ProgrammaOrarioPerUnita.DataProgramma,
Contratto.CodiceOperatoreSDC,
Contratto.IdContratto,
Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita / SDC_Unita.CoefficientePerdita QtyMGP,
SDC_Unita.TipoUnita,
SDC_Unita.CoefficientePerdita KU,
SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP,
SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
PrezzoUnitario.Prezzo PrezzoUnico,
PrezzoZonale.Prezzo PrezzoZonale

from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

 inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

 inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

where not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
and ProgrammaOrarioPerUnita.DataProgramma >= @DataProgrammaMin
and ProgrammaOrarioPerUnita.DataProgramma <= @DataProgrammaMax

and (Contratto.CodiceOperatoreSDC = @Operatore or @Operatore = '')
) POU

) T
group by 
T.CodiceOperatoreSDC, 
T.IdContratto
) X,
SDC_Operatori O,
Contratto C
 where X.CodiceOperatoreSDC = O.CodiceOperatoreSDC
and C.IdContratto = X.IdContratto
and (X.CodiceOperatoreSDC = @Operatore or @Operatore = '')

order by 
X.CodiceOperatoreSDC,
C.CRN


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO
print 'Aggiornamento Stored Procedure [spReportCapacitaTrasporto] concluso.'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

print 'Aggiornamento Stored Procedure [spReportDettaglioSbilanciDaProgrammiBilaterali]'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportDettaglioSbilanciDaProgrammiBilaterali]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportDettaglioSbilanciDaProgrammiBilaterali]
GO


CREATE PROCEDURE dbo.spReportDettaglioSbilanciDaProgrammiBilaterali
	@PartitaDettagliata varchar(50),
	@di as datetime,
	@df as datetime
AS

-- declare @PartitaDettagliata varchar(50)
-- set @PartitaDettagliata = 'TotVenditeGRTN'
-- set @PartitaDettagliata = 'TotAcquistiGRTN'
-- set @PartitaDettagliata = 'TotVenditeOperatori'

select
	U.RagioneSociale     NomeOperatore,
	T.CodiceOperatore    CodiceOperatore,
	'''' + T.CRN + ''''  CRNContratto,
	T.Ora,
	T.Data,
	T.Sbilancio,
	PU.Prezzo          PUN
from
(
	select 
	C.CRN,

	case @PartitaDettagliata
	when 'TotVenditeGRTN'      then C.CodiceOperatoreSDCAcquirente
	when 'TotAcquistiGRTN'     then C.CodiceOperatoreSDCCedente
	when 'TotVenditeOperatori' then C.CodiceOperatoreSDCAcquirente
	end CodiceOperatore,

	PO.PeriodoRilevante                     Ora,
	PO.DataProgramma                        Data,
	convert(decimal(15,3), PO.SbilMGPalCP)  Sbilancio
	from ProgrammaOrario PO
	inner join contratto C
	on C.IdContratto = PO.IdContratto
	where
	(
		   (@PartitaDettagliata = 'TotVenditeGRTN'      and PO.IsGMEOp = 0 and PO.SbilMGPalCP > 0)
		or (@PartitaDettagliata = 'TotAcquistiGRTN'                        and PO.SbilMGPalCP < 0)
		or (@PartitaDettagliata = 'TotVenditeOperatori' and PO.IsGMEOp = 1 and PO.SbilMGPalCP > 0)
	)
	and PO.DataProgramma >= @di
	and PO.DataProgramma <= @df
) T

inner join SDC_Operatori U
on    U.CodiceOperatoreSDC = T.CodiceOperatore

inner join PrezzoUnitario PU
on  PU.Data = T.Data
and PU.PeriodoRilevante = T.Ora 
	
order by
-- U.RagioneSociale,
T.CodiceOperatore,
T.Data,
T.Ora,
T.CRN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spReportDettaglioSbilanciDaProgrammiBilaterali]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportDettaglioSbilanciDaProgrammiBilaterali]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportDettaglioSbilanciDaProgrammiBilaterali]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

print 'Aggiornamento Stored Procedure [spReportDettaglioSbilanciDaProgrammiBilaterali] concluso.'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [spReportEnergiaPerZone].'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportEnergiaPerZone]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportEnergiaPerZone]
GO

CREATE PROCEDURE dbo.spReportEnergiaPerZone
	@di as datetime,
	@df as datetime
AS
set transaction isolation level read uncommitted


select pou.DataProgramma  DataFlusso, 
	c.CodiceContratto CodiceContratto,
	'''' + c.CRN + '''' CRN,
	c.CodiceOperatoreSDCCedente OpCedente,
	c.CodiceOperatoreSDCAcquirente OpAcquirente,
	case c.GestioneTaglio when 'T' then 'No' when 'C' then 'Si' else '' end Flag,
	pou.PeriodoRilevante 'Ora', 
	z.CodiceZonaSDC 'Zona',
	round(sum(case sign(pou.QtyMWh) when 1 then pou.QtyMWh else 0 end), 3) QtyProd, 
	round(sum(case sign(pou.QtyMWh) when -1 then pou.QtyMWh else 0 end), 3) QtyCons,
	round(sum(case sign(isnull(pou.QtyMWhBilanciamento, pou.QtyMWh)) when 1 then isnull(pou.QtyMWhBilanciamento, pou.QtyMWh) else 0 end), 3) 'QtyProdBal', 
	round(sum(case sign(isnull(pou.QtyMWhBilanciamento, pou.QtyMWh)) when -1 then isnull(pou.QtyMWhBilanciamento, pou.QtyMWh) else 0 end), 3) 'QtyConsBal',
	round(sum(case sign(isnull(pou.QtyMWhAssegnataMGP, 0)) when 1 then isnull(pou.QtyMWhAssegnataMGP, 0) else 0 end), 3) 'QtyProdMGP', 
	round(sum(case sign(isnull(pou.QtyMWhAssegnataMGP, 0)) when -1 then isnull(pou.QtyMWhAssegnataMGP, 0) else 0 end), 3) 'QtyConsMGP'

from 	
	-- sommare QtyMWh se diversa da zero e QtyMWhBilanciamento e` zero oppure GMEReferenceNumber not null
 	-- sommare QtyMWhBilanciamento se not null oppure null ma GMEReferenceNumber not null
	(
	select * 
	from programmaorarioperunita 
	where (not GMEReferenceNumber is null or QtyMWhBilanciamento = 0)
 	and DataProgramma >= @di
	and DataProgramma <= @df
 	and ProgOrarioDellUnitaValidato = 1
	)
	pou,
	sdc_unita u,
	sdc_puntidiscambiorilevanti p,
	sdc_zone z,
	contratto c

where 	c.IdContratto = pou.IdContratto
	and u.CodiceUnitaSDC = pou.CodiceUnitaSDC 
	and u.CategoriaUnitaSDC = pou.CategoriaUnitaSDC
	and u.CodicePuntoDiScambioRilevanteSDC = p.CodicePuntoDiScambioRilevanteSDC
	and z.CodiceZonaSDC = p.CodiceZonaSDC

group by pou.DataProgramma, 
	c.CodiceContratto, 
	c.CRN, 
	c.CodiceOperatoreSDCCedente, 
	c.CodiceOperatoreSDCAcquirente, 
	c.GestioneTaglio, 
	pou.PeriodoRilevante, 
	z.CodiceZonaSDC

order by c.CodiceContratto, 
	c.CodiceOperatoreSDCCedente, 
	c.CodiceOperatoreSDCAcquirente, 
	c.GestioneTaglio, 
	pou.PeriodoRilevante, 
	z.CodiceZonaSDC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spReportEnergiaPerZone]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportEnergiaPerZone]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportEnergiaPerZone]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
print 'Aggiornamento Stored Procedure [spReportEnergiaPerZone] concluso.'

print 'Aggiornamento Stored Procedure [spReportEnergiaPerZonePerOperatori].'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportEnergiaPerZonePerOperatori]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportEnergiaPerZonePerOperatori]
GO

CREATE PROCEDURE dbo.spReportEnergiaPerZonePerOperatori
	@di as datetime,
	@df as datetime,
	@op as varchar(8000)
AS
set transaction isolation level read uncommitted

-- cancello la tabella se esiste ancora.
-- In una sp NON DOVREBBE ESISTERE PIU' perche` le tabelle
-- locali vengono cancellate quando la sp e` finita
-- Serve invece a livello di testing quando si esegue la query
-- non da SP da QueryAnalyzer
if Object_Id('tempdb.#Operatori') is Not Null
	drop table #Operatori

-- creo una tabella che conterra` i codicei degli operatori,
create table #Operatori
(
CodiceOperatoreSDC   varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL 
)

declare @operatori as  varchar(8000),
	@operatore as varchar(16),
	@index as int,
	@len as int

set @operatori = @op

set @index = charindex(',', @operatori)
set @len = len(@operatori)

while @index > 0 
begin
	set @operatore = substring(@operatori, 0, @index)
	set @operatori = ltrim(substring(@operatori, @index+1, @len - @index))
	set @index = charindex(',', @operatori)
	
	set @len = len(@operatori)

	insert into #Operatori values (@operatore)
end
if @len > 0 
begin
	set @operatore = substring(@operatori, 0, @len+1)
	set @operatori = rtrim(ltrim(substring(@operatori, @index+1, @len - @index)))
	insert into #Operatori values  (@operatore)
end

--select * from #Operatori

select pou.DataProgramma 'DataFlusso', 
	c.CodiceContratto 'CodiceContratto',
	'''' + c.CRN + '''' CRN,
	c.CodiceOperatoreSDCCedente 'OpCedente',
	c.CodiceOperatoreSDCAcquirente 'OpAcquirente',
	case c.GestioneTaglio when 'T' then 'No' when 'C' then 'Si' else '' end 'Flag',
	pou.PeriodoRilevante 'Ora', 
	z.CodiceZonaSDC 'Zona',
	round(sum(case sign(pou.QtyMWh) when 1 then pou.QtyMWh else 0 end), 3) QtyProd, 
	round(sum(case sign(pou.QtyMWh) when -1 then pou.QtyMWh else 0 end), 3) QtyCons,
	round(sum(case sign(isnull(pou.QtyMWhBilanciamento, pou.QtyMWh)) when 1 then isnull(pou.QtyMWhBilanciamento, pou.QtyMWh) else 0 end), 3) 'QtyProdBal', 
	round(sum(case sign(isnull(pou.QtyMWhBilanciamento, pou.QtyMWh)) when -1 then isnull(pou.QtyMWhBilanciamento, pou.QtyMWh) else 0 end), 3) 'QtyConsBal',
	round(sum(case sign(isnull(pou.QtyMWhAssegnataMGP, 0)) when 1 then isnull(pou.QtyMWhAssegnataMGP, 0) else 0 end), 3) 'QtyProdMGP', 
	round(sum(case sign(isnull(pou.QtyMWhAssegnataMGP, 0)) when -1 then isnull(pou.QtyMWhAssegnataMGP, 0) else 0 end), 3) 'QtyConsMGP'

from 	(
	select * 
	from programmaorarioperunita 
	where (not GMEReferenceNumber is null or QtyMWhBilanciamento = 0)
 	and DataProgramma >= @di
	and DataProgramma <= @df
 	and ProgOrarioDellUnitaValidato = 1
	)
	pou,
	sdc_unita u,
	sdc_puntidiscambiorilevanti p,
	sdc_zone z,
	(
	select contratto.*
	from contratto, #Operatori
	where 	contratto.CodiceOperatoreSDCCedente = #Operatori.CodiceOperatoreSDC
		or 	
		contratto.CodiceOperatoreSDCAcquirente = #Operatori.CodiceOperatoreSDC
	) c

where 	-- sommare QtyMWh se diversa da zero e QtyMWhBilanciamento e` zero oppure GMEReferenceNumber not null
 	-- sommare QtyMWhBilanciamento se not null oppure null ma GMEReferenceNumber not null
	c.IdContratto = pou.IdContratto
	and u.CodiceUnitaSDC = pou.CodiceUnitaSDC 
	and u.CategoriaUnitaSDC = pou.CategoriaUnitaSDC
	and u.CodicePuntoDiScambioRilevanteSDC = p.CodicePuntoDiScambioRilevanteSDC
	and z.CodiceZonaSDC = p.CodiceZonaSDC


group by pou.DataProgramma, 
	c.CodiceContratto, 
	c.CRN, 
	c.CodiceOperatoreSDCCedente, 
	c.CodiceOperatoreSDCAcquirente, 
	c.GestioneTaglio, 
	pou.PeriodoRilevante, 
	z.CodiceZonaSDC

order by c.CodiceContratto, 
	c.CodiceOperatoreSDCCedente, 
	c.CodiceOperatoreSDCAcquirente, 
	c.GestioneTaglio, 
	pou.PeriodoRilevante, 
	z.CodiceZonaSDC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spReportEnergiaPerZonePerOperatori]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportEnergiaPerZonePerOperatori]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportEnergiaPerZonePerOperatori]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
print 'Aggiornamento Stored Procedure [spReportEnergiaPerZonePerOperatori] concluso.'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [spReportQtaPgmTotPerOperatore].'
--======================================================================
--======================================================================
--======================================================================
--======================================================================

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportQtaPgmTotPerOperatore ]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportQtaPgmTotPerOperatore ]
GO

CREATE PROCEDURE [dbo].[spReportQtaPgmTotPerOperatore] 
@d as datetime,
@op as varchar(16) = null
AS


-- cancello la tabella se esiste ancora.
-- In una sp NON DOVREBBE ESISTERE PIU' perche` le tabelle
-- locali vengono cancellate quando la sp e` finita
-- Serve invece a livello di testing quando si esegue la query
-- non da SP da QueryAnalyzer
if Object_Id('tempdb..#Quantita') is Not Null
	drop table #Quantita

-- creo una tabella che conterra` le quantita` per operatore.
-- poi quando l'avro` memorizzata faro le somme per ottenere
-- i totali direttamente qua dentro.
create table #Quantita
(
Ord         integer,    -- vale zero per gli operatori, 1 per i totali
Operatore   varchar(16), 
MWhProd     float, 
MWhBilProd  float, 
MWhOffProd  float, 
MWhCons     float, 
MWhBilCons  float, 
MWhOffCons  float 
)

-- determino se e` stato effettuato il taglio per questa data.
declare @TaglioEffettuato integer
select @TaglioEffettuato=Taglio from SessioneBilaterali where DataProgramma=@d

-- print @TaglioEffettuato

-- QUARTO PASSO
-- metto i risultati delle quantita` per operatore
-- nella tabella temporanea
insert into #Quantita
	-- TERZO PASSO
	-- Sommo le quantita` per Operatore/Unita raggruppando per Operatore
	-- e scartando quelle unita` che non sono piu` validte 
	-- nella UnitRelate
	select
		0 Ord,
		U.Operatore, 
		sum(U.QtyMWhP) MWhProd,
		sum(U.QtyMWhBilanciamentoP) MWhBilProd,
		sum(U.QtyMWhAssegnataMGPP) MWhOffProd,
	
		sum(U.QtyMWhC) MWhCons,
		sum(U.QtyMWhBilanciamentoC) MWhBilCons,
		sum(U.QtyMWhAssegnataMGPC) MWhOffCons
	
	from
	(
		-- SECONDO PASSO
		-- date le programmazioni per unita, operatore su tutti i contratti,
		-- le raggruppo per operatore/utente, sommando la Qty delle unita
		-- presenti su piu` contratti.
		select 
			T.CodiceUnitaSDC,
			T.Operatore, 
	
			sum(ProgrammatoDalCedente * T.QtyMWh) QtyMWhP,
			sum(ProgrammatoDalCedente * T.QtyMWhBilanciamento) QtyMWhBilanciamentoP,
			sum(ProgrammatoDalCedente * T.QtyMWhAssegnataMGP)QtyMWhAssegnataMGPP,
	
			sum((1-ProgrammatoDalCedente) * T.QtyMWh) QtyMWhC,
			sum((1-ProgrammatoDalCedente) * T.QtyMWhBilanciamento) QtyMWhBilanciamentoC,
			sum((1-ProgrammatoDalCedente) * T.QtyMWhAssegnataMGP)QtyMWhAssegnataMGPC
	
		from
		(
				-- PRIMO PASSO
				-- qui trovo tutte le programmazioni e l'operatore che le ha fatte
				-- sono tutti record validi. L'unico controllo ancora non fatto
				-- e` nella unit-relate
				-- Ritorno i record per Contratto/Unita/Operatore, in pratica una riga per POU
				select 
				ProgrammaOrarioPerUnita.ProgrammatoDalCedente,
				ProgrammaOrarioPerUnita.CodiceUnitaSDC,

				case ProgrammaOrarioPerUnita.ProgrammatoDalCedente 
					when 1 then Contratto.CodiceOperatoreSDCCedente 
					else        Contratto.CodiceOperatoreSDCAcquirente
				end Operatore, 

				ProgrammaOrarioPerUnita.QtyMWh,

				case @TaglioEffettuato
				when 1 then isnull(ProgrammaOrarioPerUnita.QtyMWhBilanciamento, ProgrammaOrarioPerUnita.QtyMWh)
				else null
				end QtyMWhBilanciamento,

				ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP
				from ProgrammaOrarioPerUnita 
				
				inner join ProgrammaOrario 
				on  ProgrammaOrario.IdContratto      = ProgrammaOrarioPerUnita.IdContratto 
				and ProgrammaOrario.DataProgramma    = ProgrammaOrarioPerUnita.DataProgramma 
				and ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante 
				and ProgrammaOrario.ProgrammaOrarioValidato = 1 
				and not ProgrammaOrario.Bilanciato is null
				
				inner join Contratto 
				on  Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 
				and Contratto.StatoContratto = 'Abilitato' 
				and Contratto.TrCN = 1 
				and Contratto.DataInizioValidita <= @d 
				and Contratto.DataFineValidita >= @d 
		
				where
				    ProgrammaOrarioPerUnita.DataProgramma = @d 
				and ProgrammaOrarioPerUnita.PeriodoRilevante <= 25
				and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 
		) T
		group by 
			T.CodiceUnitaSDC,
			T.Operatore
	) U
	inner join UnitRelate UR
	on  UR.CodiceUnitaSDC = U.CodiceUnitaSDC
	and UR.CategoriaUnitaSDC = 'F'
	and UR.CodiceOperatoreSDC = U.Operatore
	and UR.DataInizioValidita <= @d
	and UR.DataFineValidita >= @d
	and UR.Abilitata = 1
	and UR.TrUC = 1
	
	group by U.Operatore




-- QUINTO PASSO
-- Sommo tutte le quantita` presenti nella tabella per ottenere i totali
-- metto Ord = 1
insert into #Quantita
	select
	1                             Ord,
	'Totale:'                     Operatore, 
	round( sum(MWhProd),    3) as MWhProd, 
	round( sum(MWhBilProd), 3) as MWhBilProd, 
	round( sum(MWhOffProd), 3) as MWhOffProd, 
	round( sum(MWhCons),    3) as MWhCons, 
	round( sum(MWhBilCons), 3) as MWhBilCons, 
	round( sum(MWhOffCons), 3) as MWhOffCons 
	from #Quantita


-- SESTO PASSO
-- questi sono i risultati
-- faccio vedere i record per operatore prima e i totali poi.
select 
* 
from 
#Quantita
where (@op is null) or (@op = Operatore)
order by
Ord, Operatore

-- QUI NON CANCELLO LA TABELLA per evitare di non vedere l'execution plan.
-- comunque (in caso di test da Query Analyzer) all'inizio la ricancello se esiste.
-- In caso di SP questa tabella viene cancellata quando la SP esce.
-- 
-- drop table #Quantita

return 0


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

GRANT  EXECUTE  ON [dbo].[spReportQtaPgmTotPerOperatore]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportQtaPgmTotPerOperatore]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportQtaPgmTotPerOperatore]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [spReportQtaPgmTotPerOperatore] concluso.'

print 'Aggiornamento Stored Procedure [spReportTotaliSbilanciDaProgrammiBilaterali].'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportTotaliSbilanciDaProgrammiBilaterali]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportTotaliSbilanciDaProgrammiBilaterali]
GO


CREATE PROCEDURE spReportTotaliSbilanciDaProgrammiBilaterali 
	@di as datetime,
	@df as datetime

AS

select
	T.Ora,
	T.Data,
	convert(decimal(15,3), sum(TotVenditeGRTN))      TotVenditeGRTN,
	convert(decimal(15,3), sum(TotAcquistiGRTN))     TotAcquistiGRTN,
	convert(decimal(15,3), sum(TotVenditeOperatori)) TotVenditeOperatori,
	convert(decimal(15,3), sum(TotVenditeGRTN)) + 
	convert(decimal(15,3), sum(TotAcquistiGRTN)) + 
	convert(decimal(15,3), sum(TotVenditeOperatori)) SbilancioBilaterali,
	PU.Prezzo                                        PUN
from
(
	select 
	0                    Tipo,
	PeriodoRilevante     Ora,
	DataProgramma        Data,
	sum(SbilMGPalCP)     TotVenditeGRTN,
	0                    TotAcquistiGRTN,
	0                    TotVenditeOperatori
	from
	ProgrammaOrario
	where
 	IsGMEOp = 0
 	and SbilMGPalCP > 0 
	and DataProgramma >= @di 
	and DataProgramma <= @df
	group by
	DataProgramma,
	PeriodoRilevante
union
	select 
	1                    Tipo,
	PeriodoRilevante     Ora,
	DataProgramma        Data,
	0                    TotVenditeGRTN,
	sum(SbilMGPalCP)     TotAcquistiGRTN,
	0                    TotVenditeOperatori
	from
	ProgrammaOrario
	where
	SbilMGPalCP < 0 
	and DataProgramma >= @di 
	and DataProgramma <= @df
	group by
	DataProgramma,
	PeriodoRilevante
union
	select 
	2                    Tipo,
	PeriodoRilevante     Ora,
	DataProgramma        Data,
	0                    TotVenditeGRTN,
	0                    TotAcquistiGRTN,
	sum(SbilMGPalCP)    TotVenditeOperatori
	from
	ProgrammaOrario
	where
	IsGMEOp = 1
	and SbilMGPalCP > 0 
	and DataProgramma >= @di 
	and DataProgramma <= @df

	group by
	DataProgramma,
	PeriodoRilevante
) T
inner join PrezzoUnitario PU
on  PU.Data = T.Data
and PU.PeriodoRilevante = T.Ora 
group by
T.Data,
T.Ora,
PU.Prezzo
order by
T.Data,
T.Ora


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spReportTotaliSbilanciDaProgrammiBilaterali]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportTotaliSbilanciDaProgrammiBilaterali]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportTotaliSbilanciDaProgrammiBilaterali]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO
print 'Aggiornamento Stored Procedure [spReportTotaliSbilanciDaProgrammiBilaterali] concluso.'

print 'Aggiornamento Stored Procedure [spReportVenditeOpAcqIpex].'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportVenditeOpAcqIpex]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportVenditeOpAcqIpex]
GO


CREATE PROCEDURE dbo.spReportVenditeOpAcqIpex
	@di as datetime,
	@df as datetime
AS
-- metodo di calcolo concordato per i CSP:
-- mail Mario Pession del 21/1/05 su risposta della mia del
-- 
--Ciao,
--Nel report 'Report vendite operatori acquirenti IPEX' sono riportati i campi
--NomeOperatore,
--CodiceOperatore, 
--QuantitaVenduteMWh,
--ControvaloreEuro,
--IvaEuro,
--TotaleVenditeEuro
--Il report viene richiesto per range di date e riporta una riga per operatore, 
--cumulando le quantit� vendute, il controvalore in euro ecc nel periodo.
--Vorrei che mi validassi le formule per ottenere queste quantit�:
--QuantitaVenduteMWh
--Round(Somm(Q), 3)
--Tutte le quantit� assegnate sono summate nel periodo e poi viene effettauto il round a 3 cifre
--ControvaloreEuro
--            Somm[round(Pun * Q, 2)]
--In pratica ogni offerta accettata viene moltiplicata per il Pun, 
-- il risultato viene arrotondato a 2 cifre (ai centesimi). Questo � il dovuto per offerta.
--La sommatoria si estende al dovuto per offerta accettata nel periodo.
--Notare che in un dato periodo si avr� QuantitaVenduteMWh*Pun diverso da ControvaloreEuro 
-- dato che arrotondare gli addendi � diverso da arrotondare la somma.
--IvaEuro
--            Round(ControvaloreEuro * Iva/100, 2)
--TotaleVenditeEuro
--            ControvaloreEuro + IvaEuro
--Notare che il computo dell�iva, impostato in questa maniera implica che
--TotaleVenditeEuro dal primo al 15 del mese + TotaleVenditeEuro da 16 a fine mese <> TotaleVenditeEuro di tutto il mese.
--
--La risposta di MP (21/1/05) e`
-- confermo le formule indicate. Per la precisione sottolineo che per offerta 
-- si intende in questo caso, lo sbilancio orario relativo 
-- ad un contratto il cui cedente sia operatore di mercato

--
--================================================================================
-- Devo dunque intendere che il singolo CSP che e` legato alla formula Summ(Q)*Pun
-- siano da calcolare non come Summ(round(Q*Pun),2) ma
-- round(Summ(Q)*Pun,2)
-- e la somma di piu` CSP
-- summ(round(Summ(Q)*Pun,2))
--================================
--
-- (la mia idea del modo di calcolare i CSP e` diversa: dato che corr tot=Summ(round(Q*Pun,2)) per offerta,
-- pensavo di usare la stessa anche nel delta(q)*pun..... 
-- la mail pero` dice il contrario e dopo un po' di prove con Mario, e` venuto fuori la formula confermata.

set transaction isolation level read uncommitted

--declare @di as datetime
--declare @df as datetime
declare @iva as decimal(15,2)

--set @di = '27/11/2004'
--set @df = '27/11/2004'
set @iva = 10
set @iva = @iva / 100

-- qui calcolo l'ammontare dell'iva
-- Faccio cosi` per evitare errori di arrotondamento
select
NomeOperatore,
CodiceOperatore,
QuantitaVenduteMWh,
ControvaloreEuro,
convert(decimal(15,2), ControvaloreEuro * @iva) IvaEuro,
convert(decimal(15,2), ControvaloreEuro + convert(decimal(15,2), ControvaloreEuro * @iva)) TotaleVenditeEuro
from
(
	-- questa query ritorna per operatore acquirente
	-- la sommatoria delle Q al clearing point 
	-- e la sommatoria del Controvalore in Euro computando Pun*Q
	select
	OP.RagioneSociale                               NomeOperatore,
	CodiceOperatoreSDCAcquirente                    CodiceOperatore,
	convert(decimal(15,3), sum(R.QuantitaVendute))  QuantitaVenduteMWh,
	convert(decimal(15,2), sum(R.ControvaloreEuro)) ControvaloreEuro
	from
	(
		-- qui ottengo l'operatore acquirente associato,
		-- uno per riga di sotto.
		select
		C.CodiceOperatoreSDCAcquirente,
		T.*
		from
		(
			-- qui si ottiene Somm(Q) del contratto/data/ora non arrotondata.
			-- il controvalore round(Somm(Q)*Pun,2)
			select 
			PO.IdContratto, 
			PO.DataProgramma,
			PO.PeriodoRilevante, 
			PO.SbilMGPalCP QuantitaVendute,
			convert(decimal(15,2), PU.Prezzo * SbilMGPalCP) ControvaloreEuro
			from 
			ProgrammaOrario PO
		
			inner join PrezzoUnitario PU
			on  PU.Data = PO.DataProgramma
			and PU.PeriodoRilevante = PO.PeriodoRilevante
		
			where 
			PO.DataProgramma >= @di
			and PO.DataProgramma <= @df
			and PO.IsGMEOp = 1 -- qui considero i contratti per cui OpAcquirente e` IPEX
			and PO.SbilMGPalCP is not null
			and PO.SbilMGPalCP > 0
		) T
		-- qui aggancio il contratto cosi` ottengo il codice dell'operatore acquirente
		inner join Contratto C
		on C.IdContratto = T.IdContratto
	) R
	-- qui aggancio l'operatore per ottenere la ragione sociale.
	inner join SDC_Operatori OP
	on OP.CodiceOperatoreSDC = R.CodiceOperatoreSDCAcquirente
	
	-- qui raggruppo per operatore
	group by OP.RagioneSociale, R.CodiceOperatoreSDCAcquirente
) Q
order by NomeOperatore

GO

GRANT  EXECUTE  ON [dbo].[spReportVenditeOpAcqIpex]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportVenditeOpAcqIpex]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportVenditeOpAcqIpex]  TO [bil_dbo]
GO



SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

print 'Aggiornamento Stored Procedure [spReportVenditeOpAcqIpex] concluso.'

print 'Aggiornamento Stored Procedure [spReportXmlCCT_C].'
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCCT_C]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportXmlCCT_C]
GO


CREATE PROCEDURE dbo.spReportXmlCCT_C
	@DataFlusso as datetime
-- sono i CCT per i cedenti.
-- ossia per le offerte con qty dopo mercato > 0
-- che per definizione sono a prezzo zonale
AS

select 
Contratto.CodiceOperatoreSDCCedente Op,
Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

convert(decimal(15,3), ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP 
	/ SDC_Unita.CoefficientePerdita * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita)
	QtyMWh,

convert(decimal(15,2), ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP 
	/ SDC_Unita.CoefficientePerdita * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita 
	* (PrezzoUnitario.Prezzo - PrezzoZonale.Prezzo))
	CCTOfferta

from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

inner join Operatori OpAcquirente
on Contratto.CodiceOperatoreSDCAcquirente = OpAcquirente.CodiceOperatoreSDC

where 
not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
and ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP > 0           -- solo unita` che producono
and ProgrammaOrarioPerUnita.DataProgramma = @DataFlusso

order by 
Contratto.CodiceOperatoreSDCCedente,
Contratto.CRN,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.PeriodoRilevante

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportXmlCCT_C]  TO [bil_dbo]
GO

print 'Aggiornamento Stored Procedure [spReportXmlCCT_C] concluso.'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [spGetOperatorListUnits].'
GO

ALTER   PROCEDURE spGetOperatorListUnits
	--@CatUnitSDC as varchar,
	@dt as datetime
AS



select t.CodiceUnitaSDC, 
count(t.CodiceOperatoreSDC)  NroOp, 
dbo.GetOperatori(t.CodiceUnitaSDC, t.CategoriaUnitaSDC, @dt)  LstOp 
from
(
	select su.CodiceUnitaSDC, 
		ur.CodiceOperatoreSDC, 
		su.CategoriaUnitaSDC 
	from SDC_Unita su
	left outer join Unita u
	on su.CodiceUnitaSDC = u.CodiceUnitaSDC 
	and su.CategoriaUnitaSDC = u.CategoriaUnitaSDC
	and u.StatoBilateraliUnita = 1
	and su.Abilitata = 1
	left outer join
	UnitRelate ur
	on su.CodiceUnitaSDC = ur.CodiceUnitaSDC 
	and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
	and @dt >= ur.DataInizioValidita
	and @dt <= ur.DataFineValidita
	left outer join SDC_Unita_MarketInformation mi
	on su.CodiceUnitaSDC = mi.CodiceUnitaSDC 
	and su.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
	and mi.MarketCode = 'MGP'
	and mi.Eligibility = 'Able'
) t GROUP BY CodiceUnitaSDC, CategoriaUnitaSDC
 
order by NroOp desc, CodiceUnitaSDC

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
print 'Aggiornamento Stored Procedure [spGetOperatorListUnits] concluso.'
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [tab_SbilanciamentoProgramma].'
GO

ALTER function tab_SbilanciamentoProgramma(@DataProgramma datetime, @SogliaSbilMWh as float, @CRN as varchar(30))
returns @retSbilanciamentoProgramma table (	
	Operatore  varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	CRN varchar(30) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	CodiceContratto varchar(50) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
	Cedente varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	Acquirente varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	GestioneTaglio varchar(100) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	SbilMWhOra01 float,
	SbilMWhOra02 float,
	SbilMWhOra03 float,
	SbilMWhOra04 float,
	SbilMWhOra05 float,
	SbilMWhOra06 float,
	SbilMWhOra07 float,
	SbilMWhOra08 float,
	SbilMWhOra09 float,
	SbilMWhOra10 float,
	SbilMWhOra11 float,
	SbilMWhOra12 float,
	SbilMWhOra13 float,
	SbilMWhOra14 float,
	SbilMWhOra15 float,
	SbilMWhOra16 float,
	SbilMWhOra17 float,
	SbilMWhOra18 float,
	SbilMWhOra19 float,
	SbilMWhOra20 float,
	SbilMWhOra21 float,
	SbilMWhOra22 float,
	SbilMWhOra23 float,
	SbilMWhOra24 float,
	SbilMWhOra25 float)
as

begin
declare	
	@Operatore  varchar(16) ,
	@CodiceContratto varchar(50),
	@Cedente varchar(16) ,
	@Acquirente varchar(16),
	@GestioneTaglio varchar(50),
	@SbilMWhOra01 float,
	@SbilMWhOra02 float,
	@SbilMWhOra03 float,
	@SbilMWhOra04 float,
	@SbilMWhOra05 float,
	@SbilMWhOra06 float,
	@SbilMWhOra07 float,
	@SbilMWhOra08 float,
	@SbilMWhOra09 float,
	@SbilMWhOra10 float,
	@SbilMWhOra11 float,
	@SbilMWhOra12 float,
	@SbilMWhOra13 float,
	@SbilMWhOra14 float,
	@SbilMWhOra15 float,
	@SbilMWhOra16 float,
	@SbilMWhOra17 float,
	@SbilMWhOra18 float,
	@SbilMWhOra19 float,
	@SbilMWhOra20 float,
	@SbilMWhOra21 float,
	@SbilMWhOra22 float,
	@SbilMWhOra23 float,
	@SbilMWhOra24 float,
	@SbilMWhOra25 float


declare	@numore as integer
exec @numore = GetHourNum @DataProgramma

declare
 	@SbilMWhTotOra01 float,
	@SbilMWhTotOra02 float,
	@SbilMWhTotOra03 float,
	@SbilMWhTotOra04 float,
	@SbilMWhTotOra05 float,
	@SbilMWhTotOra06 float,
	@SbilMWhTotOra07 float,
	@SbilMWhTotOra08 float,
	@SbilMWhTotOra09 float,
	@SbilMWhTotOra10 float,
	@SbilMWhTotOra11 float,
	@SbilMWhTotOra12 float,
	@SbilMWhTotOra13 float,
	@SbilMWhTotOra14 float,
	@SbilMWhTotOra15 float,
	@SbilMWhTotOra16 float,
	@SbilMWhTotOra17 float,
	@SbilMWhTotOra18 float,
	@SbilMWhTotOra19 float,
	@SbilMWhTotOra20 float,
	@SbilMWhTotOra21 float,
	@SbilMWhTotOra22 float,
	@SbilMWhTotOra23 float,
	@SbilMWhTotOra24 float,
	@SbilMWhTotOra25 float

 	set @SbilMWhTotOra01 = 0.0
	set @SbilMWhTotOra02 = 0.0
	set @SbilMWhTotOra03 = 0.0
	set @SbilMWhTotOra04 = 0.0
	set @SbilMWhTotOra05 = 0.0
	set @SbilMWhTotOra06 = 0.0
	set @SbilMWhTotOra07 = 0.0
	set @SbilMWhTotOra08 = 0.0
	set @SbilMWhTotOra09 = 0.0
	set @SbilMWhTotOra10 = 0.0
	set @SbilMWhTotOra11 = 0.0
	set @SbilMWhTotOra12 = 0.0
	set @SbilMWhTotOra13 = 0.0
	set @SbilMWhTotOra14 = 0.0
	set @SbilMWhTotOra15 = 0.0
	set @SbilMWhTotOra16 = 0.0
	set @SbilMWhTotOra17 = 0.0
	set @SbilMWhTotOra18 = 0.0
	set @SbilMWhTotOra19 = 0.0
	set @SbilMWhTotOra20 = 0.0
	set @SbilMWhTotOra21 = 0.0
	set @SbilMWhTotOra22 = 0.0
	set @SbilMWhTotOra23 = 0.0
	set @SbilMWhTotOra24 = 0.0
	set @SbilMWhTotOra25 = 0.0


declare @IdContratto as int

select @IdContratto = IdContratto 
from Contratto 
where CRN = @CRN

declare p_cursor cursor for
select
TTT.CodiceOperatoreSDC Operatore, 
TTT.CodiceContratto,
TTT.CodiceOperatoreSDCCedente Cedente,
TTT.CodiceOperatoreSDCAcquirente Acquirente,
case (TTT.GestioneTaglio) 
	when 'T' then 'Sempre'
	when 'C' then 'se cons. supera prod.'
	when 'P' then 'se prod. supera cons.'
	when 'M' then 'Mai'
end GestioneTaglio,
sum(case TTT.PeriodoRilevante when  1 then TTT.BilMWh else 0 end )SbilMWhOra01,
sum(case TTT.PeriodoRilevante when  2 then TTT.BilMWh else 0 end )SbilMWhOra02,
sum(case TTT.PeriodoRilevante when  3 then TTT.BilMWh else 0 end )SbilMWhOra03,
sum(case TTT.PeriodoRilevante when  4 then TTT.BilMWh else 0 end )SbilMWhOra04,
sum(case TTT.PeriodoRilevante when  5 then TTT.BilMWh else 0 end )SbilMWhOra05,
sum(case TTT.PeriodoRilevante when  6 then TTT.BilMWh else 0 end )SbilMWhOra06,
sum(case TTT.PeriodoRilevante when  7 then TTT.BilMWh else 0 end )SbilMWhOra07,
sum(case TTT.PeriodoRilevante when  8 then TTT.BilMWh else 0 end )SbilMWhOra08,
sum(case TTT.PeriodoRilevante when  9 then TTT.BilMWh else 0 end )SbilMWhOra09,
sum(case TTT.PeriodoRilevante when 10 then TTT.BilMWh else 0 end )SbilMWhOra10,
sum(case TTT.PeriodoRilevante when 11 then TTT.BilMWh else 0 end )SbilMWhOra11,
sum(case TTT.PeriodoRilevante when 12 then TTT.BilMWh else 0 end )SbilMWhOra12,
sum(case TTT.PeriodoRilevante when 13 then TTT.BilMWh else 0 end )SbilMWhOra13,
sum(case TTT.PeriodoRilevante when 14 then TTT.BilMWh else 0 end )SbilMWhOra14,
sum(case TTT.PeriodoRilevante when 15 then TTT.BilMWh else 0 end )SbilMWhOra15,
sum(case TTT.PeriodoRilevante when 16 then TTT.BilMWh else 0 end )SbilMWhOra16,
sum(case TTT.PeriodoRilevante when 17 then TTT.BilMWh else 0 end )SbilMWhOra17,
sum(case TTT.PeriodoRilevante when 18 then TTT.BilMWh else 0 end )SbilMWhOra18,
sum(case TTT.PeriodoRilevante when 19 then TTT.BilMWh else 0 end )SbilMWhOra19,
sum(case TTT.PeriodoRilevante when 20 then TTT.BilMWh else 0 end )SbilMWhOra20,
sum(case TTT.PeriodoRilevante when 21 then TTT.BilMWh else 0 end )SbilMWhOra21,
sum(case TTT.PeriodoRilevante when 22 then TTT.BilMWh else 0 end )SbilMWhOra22,
sum(case TTT.PeriodoRilevante when 23 then TTT.BilMWh else 0 end )SbilMWhOra23,
sum(case TTT.PeriodoRilevante when 24 then TTT.BilMWh else 0 end )SbilMWhOra24,
sum(case TTT.PeriodoRilevante when 25 then TTT.BilMWh else 0 end )SbilMWhOra25

from
(
	select
	C.CodiceOperatoreSDC, 
	C.CodiceContratto,
	C.CodiceOperatoreSDCCedente ,
	C.CodiceOperatoreSDCAcquirente ,
	C.GestioneTaglio,
	Q.PeriodoRilevante,
	Q.BilMWh

	from ProgrammaOrario PO 
	inner join Contratto C
	on PO.IdContratto = C.IdContratto
	inner join
	(
		select 
		POU.IdContratto, 
		@DataProgramma DataProgramma, 
		POU.PeriodoRilevante,
		case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then 0                                        else 1 end Bilanciato,
		case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then round(Sum(round(POU.QtyMWh * UC.KP / UC.KU,3)), 3) else 0 end BilMWh
		from 
		(
			select 
			u.IdContratto,
			u.CodiceUnitaSDC, 
			u.CategoriaUnitaSDC, 
			u.TrCC,
			u.TrUC,
			u.VUC,
			u.KU,
			u.KP,
			sum(u.UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,
			sum(u.UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
			from 
			(
	
				select 
				c.IdContratto,
				ur.CodiceUnitaSDC, 
				ur.CategoriaUnitaSDC, 
				ur.TrUC, 
				ur.VUC,
				1 UnitaAssegnataOpCedente, 
				0 UnitaAssegnataOpAcquirente,
				c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC,
				su.CoefficientePerdita KU,
				sp.CoefficienteDiPerdita KP
				from unitrelate ur
				inner join 
				contratto c
				on
				c.IdContratto = @IdContratto
				and c.DataInizioValidita <= @DataProgramma and c.DataFineValidita >= @DataProgramma
				and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and ur.TipoUnita in ('P', 'M')
				and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
				and ur.Abilitata = 1
				inner join SDC_Unita su
				on su.CodiceUnitaSDC = ur.CodiceUnitaSDC
				and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
				inner join SDC_PuntiDiScambioRilevanti sp
				on su.CodicePuntoDiScambioRilevanteSDC = sp.CodicePuntoDiScambioRilevanteSDC
			union
				select 
				c.IdContratto,
				ur.CodiceUnitaSDC, 
				ur.CategoriaUnitaSDC, 
				ur.TrUC, 
				ur.VUC,
				0 UnitaAssegnataOpCedente, 
				1 UnitaAssegnataOpAcquirente,
				c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC,
				su.CoefficientePerdita KU,
				sp.CoefficienteDiPerdita KP
				from unitrelate ur
				inner join 
				contratto c
				on c.DataInizioValidita <= @DataProgramma and c.DataFineValidita >= @DataProgramma
				and CRN = @CRN
				and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and ur.TipoUnita in ('C', 'M')
				and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
				and ur.Abilitata = 1
				inner join SDC_Unita su
				on su.CodiceUnitaSDC = ur.CodiceUnitaSDC
				and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
				inner join SDC_PuntiDiScambioRilevanti sp
				on su.CodicePuntoDiScambioRilevanteSDC = sp.CodicePuntoDiScambioRilevanteSDC
			) u
			group by IdContratto,
			CodiceUnitaSDC, 
			CategoriaUnitaSDC,
			TrUC,
			VUC,
			TrCC,
			KU,
			KP
	 	) UC
		inner join
		(
			-- considero i POU validi del giorno
			SELECT 
			ProgrammaOrarioPerUnita.IdContratto, 
			ProgrammaOrarioPerUnita.DataProgramma, 
			ProgrammaOrarioPerUnita.PeriodoRilevante, 
			ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
			ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
			ProgrammaOrarioPerUnita.QtyMWh
			FROM 
			ProgrammaOrarioPerUnita, 
			ProgrammaOrario,
			Contratto 
			where 
			ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
			and ProgrammaOrario.DataProgramma=@DataProgramma
			and ProgrammaOrario.PeriodoRilevante <= 25
			and Contratto.IdContratto = @IdContratto
			and Contratto.IdContratto = ProgrammaOrario.IdContratto
			and ProgrammaOrario.ProgrammaOrarioValidato=1
			and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
			and ProgrammaOrarioPerUnita.IdContratto=ProgrammaOrario.IdContratto
			and ProgrammaOrarioPerUnita.DataProgramma=ProgrammaOrario.DataProgramma
			and ProgrammaOrarioPerUnita.PeriodoRilevante <= 25
			and ProgrammaOrarioPerUnita.PeriodoRilevante=ProgrammaOrario.PeriodoRilevante
		) POU
		ON  POU.IdContratto = UC.IdContratto
		AND POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
		AND POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
		GROUP BY POU.IdContratto, POU.DataProgramma, POU.PeriodoRilevante
	) Q
	on 
	PO.IdContratto = Q.IdContratto
	and PO.DataProgramma = Q.DataProgramma
	and PO.PeriodoRilevante = Q.PeriodoRilevante
)
TTT
group by 
CodiceOperatoreSDC,
CodiceContratto,
CodiceOperatoreSDCCedente,
CodiceOperatoreSDCAcquirente,
GestioneTaglio
--order by C.CRN

open p_cursor
		-- Perform the first fetch.
fetch next from p_cursor into
		@Operatore,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25

	

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	while @@FETCH_STATUS = 0
	begin

		set @SbilMWhTotOra01 = @SbilMWhTotOra01 + @SbilMWhOra01
		set @SbilMWhTotOra02 = @SbilMWhTotOra02 + @SbilMWhOra02

		set @SbilMWhTotOra03 = @SbilMWhTotOra03 + @SbilMWhOra03
		set @SbilMWhTotOra04 = @SbilMWhTotOra04 + @SbilMWhOra04
		set @SbilMWhTotOra05 = @SbilMWhTotOra05 + @SbilMWhOra05
		set @SbilMWhTotOra06 = @SbilMWhTotOra06 + @SbilMWhOra06
		set @SbilMWhTotOra07 = @SbilMWhTotOra07 + @SbilMWhOra07
		set @SbilMWhTotOra08 = @SbilMWhTotOra08 + @SbilMWhOra08
		set @SbilMWhTotOra09 = @SbilMWhTotOra09 + @SbilMWhOra09
		set @SbilMWhTotOra10 = @SbilMWhTotOra10 + @SbilMWhOra10
		set @SbilMWhTotOra11 = @SbilMWhTotOra11 + @SbilMWhOra11
		set @SbilMWhTotOra12 = @SbilMWhTotOra12 + @SbilMWhOra12
		set @SbilMWhTotOra13 = @SbilMWhTotOra13 + @SbilMWhOra13
		set @SbilMWhTotOra14 = @SbilMWhTotOra14 + @SbilMWhOra14
		set @SbilMWhTotOra15 = @SbilMWhTotOra15 + @SbilMWhOra15
		set @SbilMWhTotOra16 = @SbilMWhTotOra16 + @SbilMWhOra16
		set @SbilMWhTotOra17 = @SbilMWhTotOra17 + @SbilMWhOra17
		set @SbilMWhTotOra18 = @SbilMWhTotOra18 + @SbilMWhOra18
		set @SbilMWhTotOra19 = @SbilMWhTotOra19 + @SbilMWhOra19
		set @SbilMWhTotOra20 = @SbilMWhTotOra20 + @SbilMWhOra20
		set @SbilMWhTotOra21 = @SbilMWhTotOra21 + @SbilMWhOra21
		set @SbilMWhTotOra22 = @SbilMWhTotOra22 + @SbilMWhOra22
		set @SbilMWhTotOra23 = @SbilMWhTotOra23 + @SbilMWhOra23
		set @SbilMWhTotOra24 = @SbilMWhTotOra24 + @SbilMWhOra24
		set @SbilMWhTotOra25 = @SbilMWhTotOra25 + @SbilMWhOra25
		
	-- Copy to the result of the function the required columns.
	insert @retSbilanciamentoProgramma values(
		@Operatore,
		@CRN,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25)
	   -- This is executed as long as the previous fetch succeeds.
	  fetch next from p_cursor into
		@Operatore,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25

	end
	close p_cursor
	deallocate p_cursor



	-- Copy to the result of the function the required columns.
	insert @retSbilanciamentoProgramma values(
		'',
		'',
		'', --convert(varchar, @DataProgramma, 105),
		'',
		'',
		'Totale Orario' ,
		@SbilMWhTotOra01,
		@SbilMWhTotOra02,
		@SbilMWhTotOra03,
		@SbilMWhTotOra04,
		@SbilMWhTotOra05,
		@SbilMWhTotOra06,
		@SbilMWhTotOra07,
		@SbilMWhTotOra08,
		@SbilMWhTotOra09,
		@SbilMWhTotOra10,
		@SbilMWhTotOra11,
		@SbilMWhTotOra12,
		@SbilMWhTotOra13,
		@SbilMWhTotOra14,
		@SbilMWhTotOra15,
		@SbilMWhTotOra16,
		@SbilMWhTotOra17,
		@SbilMWhTotOra18,
		@SbilMWhTotOra19,
		@SbilMWhTotOra20,
		@SbilMWhTotOra21,
		@SbilMWhTotOra22,
		@SbilMWhTotOra23,
		@SbilMWhTotOra24,
		@SbilMWhTotOra25)
return
	
end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

print 'Aggiornamento Stored Procedure [tab_SbilanciamentoProgramma] concluso.'
GO



print 'Aggiornamento Stored Procedure [spGetProgrammiOperatori].'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetProgrammiOperatori]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetProgrammiOperatori]
GO

CREATE PROCEDURE dbo.spGetProgrammiOperatori
	@DataRicerca as datetime,
	@IdContratto as int,
	@OraRicerca as tinyint,
	@OpCedente as bit,
	@OpAcquirente as bit
AS
-- declare @DataRicerca as datetime,
-- 	@IdContratto as int,
-- 	@OraRicerca as tinyint,
-- 	@OpCedente as bit,
-- 	@OpAcquirente as bit
-- 
-- set @DataRicerca = '1/4/2005'
-- set @IdContratto = 294
-- set @OraRicerca = 2
-- set @OpCedente = 1 --'OESSIET'
-- set @OpAcquirente = 0 --'OEEPSNL'

if Object_Id('tempdb..#temp') is Not Null
	drop table #temp

create table #temp (ID int IDENTITY, 
			CRN varchar(30),
			CodiceUnitaSDC varchar(16),
			CategoriaUnitaSDC varchar(1),
			NomeUnita varchar(256),
			TipoUnita char(1),
			QtyMin float,
			QtyMax float,
			QtyMWh float,
			PrioritaBilanciamento int
			)

insert into #temp (
	CRN,
	CodiceUnitaSDC,
	CategoriaUnitaSDC,
	NomeUnita,
	TipoUnita,
	QtyMin,
	QtyMax,
	QtyMWh,
	PrioritaBilanciamento)
SELECT
Contratto.CRN,
UnitaContratto.CodiceUnitaSDC,
UnitaContratto.CategoriaUnitaSDC, 
SDC_Unita.NomeUnita,
SDC_Unita.TipoUnita, 
CASE TipoUnita
	WHEN 'P' THEN 0 
	WHEN 'C' THEN - SDC_Unita.PotenzaMassimaMWh 
	ELSE SDC_Unita.PotenzaMinimaMWh 
	END AS QtyMin, 
CASE TipoUnita 
	WHEN 'P' THEN SDC_Unita.PotenzaMassimaMWh 
	WHEN 'C' THEN 0   
	ELSE SDC_Unita.PotenzaMassimaMWh 
	END AS QtyMax, 
ProgrammaOrarioPerUnita.QtyMWh, 
isnull(ProgrammaOrarioPerUnita.ProgressivoNelProgramma, 999999) PrioritaBilanciamento
FROM tab_UnitaCOntratto2(@DataRicerca, @IdContratto) UnitaContratto 
INNER JOIN Contratto 
ON Contratto.IdContratto = UnitaContratto.IdContratto 
INNER JOIN SDC_Unita 
ON SDC_Unita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC 
AND SDC_Unita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC 
LEFT OUTER JOIN ProgrammaOrarioPerUnita 
ON ProgrammaOrarioPerUnita.IdContratto = UnitaContratto.IdContratto 
AND ProgrammaOrarioPerUnita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC 
AND ProgrammaOrarioPerUnita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC 
AND ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca 
AND ProgrammaOrarioPerUnita.PeriodoRilevante = @OraRicerca 
WHERE
(
(UnitaContratto.IdContratto = @IdContratto) 
AND (UnitaContratto.TrCC = 1) 
AND (UnitaContratto.TrUC = 1) 
AND (UnitaContratto.UnitaDelContrattoValidata = 1) 
AND (UnitaContratto.DataInizioValidita <= @DataRicerca)
AND (UnitaContratto.DataFineValidita >= @DataRicerca) 
AND (UnitaContratto.UnitaAssegnataOpCedente = @OpCedente) 
)
OR
(
(UnitaContratto.IdContratto = @IdContratto) 
AND (UnitaContratto.TrCC = 1) 
AND (UnitaContratto.TrUC = 1) 
AND (UnitaContratto.UnitaDelContrattoValidata = 1) 
AND (UnitaContratto.DataInizioValidita <= @DataRicerca)
AND (UnitaContratto.DataFineValidita >= @DataRicerca) 
AND (UnitaContratto.UnitaAssegnataOpAcquirente = @OpAcquirente) 
)
ORDER BY 
isnull(ProgrammaOrarioPerUnita.IdProgrammaXml, 999999999),
isnull(ProgrammaOrarioPerUnita.ProgressivoNelProgramma, 999999), 
UnitaContratto.CategoriaUnitaSDC, 
UnitaContratto.CodiceUnitaSDC

select 
CRN ,
CodiceUnitaSDC ,
CategoriaUnitaSDC ,
NomeUnita ,
TipoUnita ,
QtyMin ,
QtyMax ,
QtyMWh ,
PrioritaBilanciamento 
from #temp
order by ID


drop table #temp

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

GRANT  EXECUTE  ON [dbo].[spGetProgrammiOperatori]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spGetProgrammiOperatori]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGetProgrammiOperatori]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [spGetProgrammiOperatori] concluso.'





















print 'UPDATE Version ON DBVersion'
UPDATE DBVersion SET Version = '2.3.0.0'

print 'UPDATE DBHistory'
INSERT INTO DBHistory (Version, Patch, UpgradeTS, Notes)
VALUES('2.3.0.0', NULL, getdate(), 'Upgrade alla Versione 2.3.0.0')

print 'UPDATE ReportQueries'
delete ReportQueries

insert ReportQueries 
values ('SBIL', 'Report Sbilanciamento Orario', 
'<Report Descrizione="Report Sbilanciamento Orario">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportSbilanciamentoOrario"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>

</OutputFormat>
</Report>', 
'A')

insert into reportqueries
values ('CTRFLG', 'Gestione taglio su contratti', 
'<Report Descrizione="Report Gestione Taglio su Contratti">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportContrattiFlaggati"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>
	

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>

	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="NumContratti" rptColName="Num. Contratti" />
	</out>
</OutputFormat>
</Report>', 'A'
)

insert into reportqueries
values ('NRGSBILPGM', 'Energia di Sbilancio a Programma', 
'<Report Descrizione="Report Energia di Sbilancio">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaSbilancioProgramma"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
<Parameter Label="Soglia Sbilanciamento MWh:" Html="Text" ID="Soglia" NomeSql="@SogliaSbilMWh" TipoNET="double" TipoSql="float"/>   
<Parameter Label="CRN:" Html="Text" ID="CRN" NomeSql="@CRN" TipoNET="String" TipoSql="varchar(30)"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>

</OutputFormat>
</Report>',
'A'
)

insert into reportqueries
values ('NRGTAGLIO', 'Entita` Taglio sui Programmi non flaggati', 
'<Report Descrizione="Entita` Taglio sui Programmi non flaggati">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEntitaTaglio"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>

	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

</OutputFormat>
</Report>',
'A'
)

insert into reportqueries
values ('NRGCNTR', 'Energia Contratti Flaggati', 
'<Report Descrizione="Report Energia Contratti Flaggati">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaContrattiFlaggati"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

</OutputFormat>
</Report>', 'A'
)

insert into ReportQueries 
values ('NRGSBIL', 'Energia di Sbilancio', 
'<Report Descrizione="Report Energia di Sbilancio">    
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaSbilancio"/>    
<InputParameters>     
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>     
</InputParameters>    
<OutputFormat>   
	<!--   
	supporta:  
		out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")   
		out/col[@rptColFormat=''000'']  - per formattare le singole colonne   
	-->   
	<out rptType="xml">    
		<col dbColName="DataProgramma" rptColName="DataFlusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />    
		<col dbColName="CRN" rptColName="CRN"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />  
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />      
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>
	<!--    supporta:   
		out[@rptLanguage=''zz-zz'']    
			- per formattare nella lingua di Excel (default it-it)   out[@rptSeparator='';'']       
			- per separare con , (in inglese) o con ; (in italiano) (default ; )   
		out/col[@rptColFormat=''000''] 
			- per formattare la singola colonna (default null)   
		out/col[@rptColQuote="''"]    
			- per ingannare Excel: non interpreta il campo come numerico (default non usare il quote)   
	-->   
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>     
	<!--   
	supporta:   
	out[@rptLanguage=''zz-zz'']    	- per impostare la lingua con cui si produce il file (default it-it).   
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)   
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)   
	-->   
	<out rptType="txt" rptLanguage="it-it" >    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="''CRN''"  rptColQuote="''" />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out> 
	<!--    out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente   -->   
	<out rptType="html">    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="CRN"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>         
	</OutputFormat>  
</Report>',
'A')

GO


update 
reportqueries
set parametri = 
'<Report Descrizione="Report Sbilanciamento Orario">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportSbilanciamentoOrario"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>

</OutputFormat>
</Report>'
where codicereport = 'SBIL'


SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



PRINT 'Il database e` aggiornato alla versione 2.3.0.0 !'

