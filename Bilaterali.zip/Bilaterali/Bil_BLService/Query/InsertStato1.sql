-- DECLARE @DataRicerca smalldatetime
-- DECLARE @tmpIdentValue int

--
-- 30 Luglio 2004 = '7/30/4'
-- 31 Luglio 2004 = '7/31/4'
-- 1 Agosto 2004 = '8/1/4'
-- 4 Settembre 2004 = '9/4/4'
-- 10 Settembre 2004 = '9/10/4'
-- 11 Settembre 2004 = '9/11/4'
-- 12 Settembre 2004 = '9/12/4'
-- 13 Settembre 2004 = '9/13/4'
-- Set @DataRicerca  = '9/11/4'

--DataRicerca: @DataRicerca
--OriginalDB: DBOrigine
--DestinationDB: DBDestinazione


--Message: cancellazione tabella temporanea 
-- DROP TABLE #tmpValue;

--Message: disable trigger degli operatori
alter table DBDestinazione.dbo.Operatori disable trigger all


--Message: creazione tabella temporanea per uso generale
--TmoQuery: 45
CREATE TABLE #tmpValue (IdProgrammaXml INT NOT NULL);

--Message: Inserimento valori tabella temporanea
--TmoQuery: 45
INSERT INTO #tmpValue SELECT DISTINCT DBOrigine.dbo.ProgrammaOrarioPerUnita.IdProgrammaXml FROM DBOrigine.dbo.ProgrammaOrarioPerUnita WHERE DBOrigine.dbo.ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca;


--Message: Inserimento tabella PrezzoUnitario (Stato1 Data = @DataRicerca)
--TmoQuery: 45
INSERT DBDestinazione.dbo.PrezzoUnitario SELECT * FROM DBOrigine.dbo.PrezzoUnitario WHERE Data=@DataRicerca;

--Message: Inserimento tabella RichiestaCancellazione
--TmoQuery: 45
INSERT DBDestinazione.dbo.RichiestaCancellazione SELECT * FROM DBOrigine.dbo.RichiestaCancellazione;

--Message: Inserimento tabella BatchStatus (Questo dovrebbe far parte dello Stato1, e solo i dati con TSDataFlusso=null oppure = data prescelta
--TmoQuery: 45
INSERT DBDestinazione.dbo.BatchStatus SELECT * FROM DBOrigine.dbo.BatchStatus WHERE TSDataFlusso is NULL;
--TmoQuery: 45
INSERT DBDestinazione.dbo.BatchStatus SELECT * FROM DBOrigine.dbo.BatchStatus WHERE TSDataFlusso is NOT NULL AND TSDataFlusso=@DataRicerca;


--Message: Inserimento tabella Certificate_DistributionPoints
--TmoQuery: 45
INSERT DBDestinazione.dbo.Certificate_DistributionPoints SELECT * FROM DBOrigine.dbo.Certificate_DistributionPoints;

--Message: Inserimento tabella Certificate_List
--TmoQuery: 45
INSERT DBDestinazione.dbo.Certificate_List SELECT * FROM DBOrigine.dbo.Certificate_List;

--Message: Inserimento tabella Certificate_RevocationList
--TmoQuery: 45
INSERT DBDestinazione.dbo.Certificate_RevocationList SELECT * FROM DBOrigine.dbo.Certificate_RevocationList;

--Message: Inserimento tabella Certificate_CA
--TmoQuery: 45
INSERT DBDestinazione.dbo.Certificate_CA SELECT * FROM DBOrigine.dbo.Certificate_CA;

--Message: Inserimento tabella SessioneBilaterali (Stato1, DataProgramma = @DataRicerca)
--TmoQuery: 45
INSERT DBDestinazione.dbo.SessioneBilaterali SELECT * FROM DBOrigine.dbo.SessioneBilaterali WHERE DBOrigine.dbo.SessioneBilaterali.DataProgramma=@DataRicerca;

--Message: Inserimento tabella SmLog: puo' avere dimensioni elevate: per ora query commentata
-- INSERT DBDestinazione.dbo.SmLog SELECT * FROM DBOrigine.dbo.SmLog;

--Message: Inserimento tabella Ore
--TmoQuery: 45
INSERT DBDestinazione.dbo.Ore SELECT * FROM DBOrigine.dbo.Ore;

--Message: Inserimento tabella ReportQueries
--TmoQuery: 45
INSERT DBDestinazione.dbo.ReportQueries SELECT * FROM DBOrigine.dbo.ReportQueries;


--Message: Inserimento tabella FileMGP con TSFlusso determinata o senza TSFlusso (per compatibilita pregressa)
--TmoQuery: 45
INSERT DBDestinazione.dbo.FileMGP SELECT DBOrigine.dbo.FileMGP.* FROM DBOrigine.dbo.FileMGP WHERE TSFlusso IS NULL;
--TmoQuery: 45
INSERT DBDestinazione.dbo.FileMGP SELECT DBOrigine.dbo.FileMGP.* FROM DBOrigine.dbo.FileMGP WHERE (TSFlusso IS NOT NULL) AND (TSFlusso = @DataRicerca);

--TmoQuery: 45
INSERT DBDestinazione.dbo.FileIO SELECT DBOrigine.dbo.FileIO.* FROM DBOrigine.dbo.FileIO WHERE  convert(datetime, convert(varchar(16), TSInvio, 112), 112) = @DataRicerca;


--Message: Inserimento tabella Ruoli
--TmoQuery: 45
INSERT DBDestinazione.dbo.Ruoli SELECT * FROM DBOrigine.dbo.Ruoli;

--Message: Inserimento tabella SDC_Zone 
--TmoQuery: 45
INSERT DBDestinazione.dbo.SDC_Zone SELECT * FROM DBOrigine.dbo.SDC_Zone;

--Message: Inserimento PrezzoZonale (stato1) data = @DataRicerca
--TmoQuery: 45
INSERT DBDestinazione.dbo.PrezzoZonale SELECT * FROM DBOrigine.dbo.PrezzoZonale WHERE DBOrigine.dbo.PrezzoZonale.Data = @DataRicerca;


--Message: Inserimento tabella SDC_Utenti
--TmoQuery: 45
INSERT DBDestinazione.dbo.SDC_Utenti SELECT * FROM DBOrigine.dbo.SDC_Utenti;


--Message: Inserimento tabella Utenti
--TmoQuery: 45
INSERT DBDestinazione.dbo.Utenti SELECT * FROM DBOrigine.dbo.Utenti;


--Message: Inserimento tabella SDC_PuntiDiScambioRilevanti
--TmoQuery: 45
INSERT DBDestinazione.dbo.SDC_PuntiDiScambioRilevanti SELECT * FROM DBOrigine.dbo.SDC_PuntiDiScambioRilevanti;

--Message: Inserimento tabella SDC_Operatori
--TmoQuery: 45
INSERT DBDestinazione.dbo.SDC_Operatori SELECT * FROM DBOrigine.dbo.SDC_Operatori;

--Message: Inserimento tabella Operatori
--TmoQuery: 45
INSERT DBDestinazione.dbo.Operatori SELECT * FROM DBOrigine.dbo.Operatori;


--Message: Inserimento tabella FileOperatori di tipo FA
--TmoQuery: 45
INSERT INTO DBDestinazione.dbo.FileOperatori SELECT DBOrigine.dbo.FileOperatori.* FROM DBOrigine.dbo.FileOperatori INNER JOIN DBOrigine.dbo.XmlProgrammiUtenti ON DBOrigine.dbo.FileOperatori.IdFile = DBOrigine.dbo.XmlProgrammiUtenti.IdFileFA AND DBOrigine.dbo.FileOperatori.CodiceTipoFile = 'FA' INNER JOIN #tmpValue ON DBOrigine.dbo.XmlProgrammiUtenti.IdProgrammaXml = #tmpValue.IdProgrammaXml;


--Message: Inserimento tabella FileOperatori di tipo non FA con dataflusso determinata o senza dataflusso
--TmoQuery: 45
INSERT INTO DBDestinazione.dbo.FileOperatori SELECT DBOrigine.dbo.FileOperatori.* FROM DBOrigine.dbo.FileOperatori WHERE (CodiceTipoFile <> 'FA') AND (TSFlusso IS NULL);
--TmoQuery: 45
INSERT INTO DBDestinazione.dbo.FileOperatori SELECT DBOrigine.dbo.FileOperatori.* FROM DBOrigine.dbo.FileOperatori WHERE (CodiceTipoFile <> 'FA') AND (TSFlusso IS NOT NULL) AND (TSFlusso = @DataRicerca);


--Message: Inserimento tabella RelOperatoriUtenti
--TmoQuery: 45
INSERT DBDestinazione.dbo.RelOperatoriUtenti SELECT * FROM DBOrigine.dbo.RelOperatoriUtenti;


--Message: Inserimento tabella XmlProgrammiUtenti
--TmoQuery: 45
SET IDENTITY_INSERT DBDestinazione.dbo.XmlProgrammiUtenti ON; INSERT DBDestinazione.dbo.XmlProgrammiUtenti (IdProgrammaXml, ProgrammaFirmato, TSInvio, Zippato, NomeFileUtente, CodiceUtenteSDC, PathFileFirmato, CodiceOperatoreSDC, TSModifica, IdFileFA, Issuer, SerialNumber) SELECT p.IdProgrammaXml,p.ProgrammaFirmato,p.TSInvio,p.Zippato,p.NomeFileUtente,p.CodiceUtenteSDC,p.PathFileFirmato,p.CodiceOperatoreSDC,p.TSModifica,p.IdFileFA,p.Issuer,p.SerialNumber FROM DBOrigine.dbo.XmlProgrammiUtenti p INNER JOIN #tmpValue ON p.IdProgrammaXml = #tmpValue.IdProgrammaXml; SET IDENTITY_INSERT DBDestinazione.dbo.XmlProgrammiUtenti OFF;

--Message: Inserimento tabella XmlFileDaOperatori
--TmoQuery: 45
SET IDENTITY_INSERT DBDestinazione.dbo.XmlFileDaOperatori ON; INSERT DBDestinazione.dbo.XmlFileDaOperatori (IdFileXml, FileFirmato, TSInvio, Zippato, NomeFileUtente, CodiceUtenteSDC, PathFileFirmato, CodiceOperatoreSDC, TSModifica, IdFileFA, Issuer, SerialNumber) SELECT IdFileXml, FileFirmato, TSInvio, Zippato, NomeFileUtente, CodiceUtenteSDC, PathFileFirmato, CodiceOperatoreSDC, TSModifica, IdFileFA, Issuer, SerialNumber FROM DBOrigine.dbo.XmlFileDaOperatori; SET IDENTITY_INSERT DBDestinazione.dbo.XmlFileDaOperatori OFF;


--Message: Inserimento tabella Contratto
--TmoQuery: 45
SET IDENTITY_INSERT DBDestinazione.dbo.Contratto ON; INSERT DBDestinazione.dbo.Contratto (IdContratto, CodiceContratto, DataStipula, DataInizioValidita, DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN,GestioneTaglio) SELECT IdContratto, CodiceContratto, DataStipula, DataInizioValidita, DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC,  TSModifica, CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN, GestioneTaglio FROM DBOrigine.dbo.Contratto; SET IDENTITY_INSERT DBDestinazione.dbo.Contratto OFF;



--Message: Inserimento tabella SDC_Unita
--TmoQuery: 45
INSERT DBDestinazione.dbo.SDC_Unita SELECT * FROM DBOrigine.dbo.SDC_Unita;

--Message: Inserimento tabella Unita
--TmoQuery: 45
INSERT DBDestinazione.dbo.Unita SELECT * FROM DBOrigine.dbo.Unita;


--Message: Inserimento tabella UnitRelate
--TmoQuery: 45
INSERT DBDestinazione.dbo.UnitRelate SELECT * FROM DBOrigine.dbo.UnitRelate;

--Message: Inserimento tabella SDC_Unita_MarketInformation
--TmoQuery: 45
INSERT DBDestinazione.dbo.SDC_Unita_MarketInformation SELECT * FROM DBOrigine.dbo.SDC_Unita_MarketInformation;



--Message: Inserimento tabella ProgrammaOrario
--TmoQuery: 45
INSERT DBDestinazione.dbo.ProgrammaOrario SELECT * FROM DBOrigine.dbo.ProgrammaOrario WHERE DBOrigine.dbo.ProgrammaOrario.DataProgramma=@DataRicerca;

--Message: Inserimento tabella ProgrammaOrarioPerUnita
--TmoQuery: 45
INSERT DBDestinazione.dbo.ProgrammaOrarioPerUnita SELECT * FROM DBOrigine.dbo.ProgrammaOrarioPerUnita  WHERE DBOrigine.dbo.ProgrammaOrarioPerUnita.DataProgramma=@DataRicerca;

--Message: Inserimento tabella ProgrammaOrarioPerUnitaErrori (Stato1)
--TmoQuery: 45
INSERT DBDestinazione.dbo.ProgrammaOrarioPerUnitaErrori SELECT * FROM DBOrigine.dbo.ProgrammaOrarioPerUnitaErrori  WHERE DBOrigine.dbo.ProgrammaOrarioPerUnitaErrori.DataProgramma=@DataRicerca;


--Message: Inserimento tabella RichiestaCancellazione
--TmoQuery: 45
INSERT DBDestinazione.dbo.RichiestaCancellazione SELECT * FROM DBOrigine.dbo.RichiestaCancellazione;

--Message: Inserimento tabella Funzioni
--TmoQuery: 45
INSERT DBDestinazione.dbo.Funzioni SELECT * FROM DBOrigine.dbo.Funzioni;

--Message: Inserimento tabella RuoliFunzioni
--TmoQuery: 45
INSERT DBDestinazione.dbo.RuoliFunzioni SELECT * FROM DBOrigine.dbo.RuoliFunzioni;


--Message: cancellazione tabella temporanea 
--TmoQuery: 45
DROP TABLE #tmpValue;


--Message: Calcola valore SEED corrente su tabella Contratto original DB
--TmoQuery: 45
DECLARE @tmpIdentValue INT; SET @tmpIdentValue = IDENT_CURRENT('DBOrigine.dbo.Contratto'); DBCC CHECKIDENT("DBDestinazione.dbo.Contratto", RESEED, @tmpIdentValue);

--Message: Calcola valore SEED corrente su tabella XmlProgrammiUtenti original DB
--TmoQuery: 45
DECLARE @tmpIdentValue INT; SET @tmpIdentValue = IDENT_CURRENT('DBOrigine.dbo.XmlProgrammiUtenti');DBCC CHECKIDENT("DBDestinazione.dbo.XmlProgrammiUtenti", RESEED, @tmpIdentValue);

--Message: Calcola valore SEED corrente su tabella FileIO e imposta sul DB di destinazione
--TmoQuery: 45
DECLARE @tmpIdentValue INT; SET @tmpIdentValue = IDENT_CURRENT('DBOrigine.dbo.FileIO');DBCC CHECKIDENT("DBDestinazione.dbo.FileIO", RESEED, @tmpIdentValue);

--Message: Calcola valore SEED corrente su tabella XmlFileDaOperatori e imposta sul DB di destinazione
--TmoQuery: 45
DECLARE @tmpIdentValue INT; SET @tmpIdentValue = IDENT_CURRENT('DBOrigine.dbo.XmlFileDaOperatori');DBCC CHECKIDENT("DBDestinazione.dbo.XmlFileDaOperatori", RESEED, @tmpIdentValue);


--Message: enable trigger degli operatori
alter table DBDestinazione.dbo.Operatori enable trigger all



--Message: SHRINK del Database per ridurre le dimensioni del file, lasciando 25% di spazio libero
--TmoQuery: 45
USE DBDestinazione; DBCC SHRINKDATABASE ("DBDestinazione", 25);
