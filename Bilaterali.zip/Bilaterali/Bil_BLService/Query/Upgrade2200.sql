/* ------------------------------------------------------------------------------------------ 
 * Upgrade Database: script SQL per l'upgrade del Database in versione 2.0.0.0
 * Versione Iniziale: 2.2.0.1
 * Versione Finale:   2.2.0.4
 * D.C.: 24/11/2004
 * U.M.: 14/12/2004
 * ------------------------------------------------------------------------------------------ 
*/

use [Bilaterali]

DECLARE @Version AS VARCHAR(16)

SELECT @Version = Version 
FROM DBVersion
PRINT 'Il database e` in versione: ' + @Version

IF @Version <> '2.2.0.1'
	PRINT 'Il database non e` nella versione prevista !'

-- -- DROP TRIGGERS
-- print 'Begin: Drop Triggers'
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Contratto_OnUpdate]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[Contratto_OnUpdate]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Contratto_Insert]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[Contratto_Insert]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Operatori_OnUpdate]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[Operatori_OnUpdate]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SDC_Operatori_OnUpdate]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[SDC_Operatori_OnUpdate]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SDC_PuntiDiScambioRilevanti_Update]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[SDC_PuntiDiScambioRilevanti_Update]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SDC_Unita_OnUpdate_UR]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[SDC_Unita_OnUpdate_UR]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SDC_Unita_MarketInformationOnInsert_UR]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[SDC_Unita_MarketInformationOnInsert_UR]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SDC_Unita_MarketInformationOnUpdate_UR]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[SDC_Unita_MarketInformationOnUpdate_UR]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UnitRelate_Insert]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[UnitRelate_Insert]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UnitRelate_Update]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[UnitRelate_Update]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UnitRelate_Delete]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[UnitRelate_Delete]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Unita_OnUpdate_UR]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
-- drop trigger [dbo].[Unita_OnUpdate_UR]
-- GO
-- print 'End: Drop Triggers'
-- 
-- print 'Begin: Drop Functions'
-- -- DROP FUNCTIONS
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetHourNum]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[GetHourNum]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOperatori]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[GetOperatori]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UnitaContrattiOra]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[UnitaContrattiOra]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_ReportIndicatori]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[tab_ReportIndicatori]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_ReportSbilanciamentoOrario]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[tab_ReportSbilanciamentoOrario]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_SbilanciamentoProgramma]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[tab_SbilanciamentoProgramma]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_UnitaContratto]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[tab_UnitaContratto]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_UnitaContratto2]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[tab_UnitaContratto2]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_UnitaContratto3]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[tab_UnitaContratto3]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_UnitaContratto4]') and xtype in (N'FN', N'IF', N'TF'))
-- drop function [dbo].[tab_UnitaContratto4]
-- GO
-- 
-- print 'End: Drop Functions'
-- 
-- 
-- print 'Begin: Drop Procedures'
-- 
-- -- DROP PROCEDURES
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportContrattiFlaggati]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[ReportContrattiFlaggati]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportEnergiaContrattiFlaggati]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[ReportEnergiaContrattiFlaggati]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportEnergiaSbilancio]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[ReportEnergiaSbilancio]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportEnergiaSbilancioProgramma]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[ReportEnergiaSbilancioProgramma]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportEntitaTaglio]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[ReportEntitaTaglio]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSbilanciamentoOrario]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[ReportSbilanciamentoOrario]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilAddOperatori]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilAddOperatori]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilAddOperatoriFiltrati]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilAddOperatoriFiltrati]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilAddUnita]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilAddUnita]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilAddUnitaFiltrate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilAddUnitaFiltrate]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilAddUtentiFiltrati]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilAddUtentiFiltrati]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGeneraBus]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGeneraBus]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetContrattoByID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetContrattoByID]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetDettagliProgrammazioneOraria]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetDettagliProgrammazioneOraria]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetDettagliProgrammazioneOrariaClient]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetDettagliProgrammazioneOrariaClient]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetEnergiaGiornaliera]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetEnergiaGiornaliera]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetListaContratti]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetListaContratti]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetListaContrattiClient]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetListaContrattiClient]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammaOrarioContratto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetProgrammaOrarioContratto]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammaOrarioContrattoClient]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetProgrammaOrarioContrattoClient]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammazione23]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetProgrammazione23]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammazione24]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetProgrammazione24]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammazione25]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetProgrammazione25]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammazioneClient23]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetProgrammazioneClient23]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammazioneClient24]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetProgrammazioneClient24]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilGetProgrammazioneClient25]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilGetProgrammazioneClient25]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilUpdateFlagValidatoPO]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilUpdateFlagValidatoPO]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilUpdateFlagValidatoPOU]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilUpdateFlagValidatoPOU]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilanciamentoForzato]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spBilanciamentoForzato]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spCalcolaBilanciamento]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spCalcolaBilanciamento]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spCalcolaBilanciamentoPerContratto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spCalcolaBilanciamentoPerContratto]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spEseguiBilanciamentoPerContratto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spEseguiBilanciamentoPerContratto]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGeneraOfferte]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGeneraOfferte]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGeneraOfferte_PgmBilanciati]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGeneraOfferte_PgmBilanciati]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGeneraOfferte_PgmNonBilanciati]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGeneraOfferte_PgmNonBilanciati]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetCertificateData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetCertificateData]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetContrattiPerReportXmlProgrammi]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetContrattiPerReportXmlProgrammi]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetListUnitaDellOperatore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetListUnitaDellOperatore]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetNC]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetNC]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetNU_OverQty]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetNU_OverQty]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetOperatorListUnits]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetOperatorListUnits]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetOperatorUnitsType]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetOperatorUnitsType]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetProgrammiConCertificatoNonValido]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetProgrammiConCertificatoNonValido]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetReportIndicatori]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spGetReportIndicatori]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spListaContrattiPatch]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spListaContrattiPatch]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spNotificaStatoLetturaMGP]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spNotificaStatoLetturaMGP]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spNuovaTransProgramma]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spNuovaTransProgramma]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spNuovoProgrammaNonIncrementale]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spNuovoProgrammaNonIncrementale]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spOnProgrammaOperatore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spOnProgrammaOperatore]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportBilanciamento]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportBilanciamento]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportCapacitaTrasporto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportCapacitaTrasporto]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportGestioneTaglio_Contratti]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportGestioneTaglio_Contratti]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportSbilanciamentoOrario]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportSbilanciamentoOrario]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportStoricoProgrammi]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportStoricoProgrammi]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCorrispettivi]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportXmlCorrispettivi]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlCorrispettivi2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportXmlCorrispettivi2]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlProgrammi]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportXmlProgrammi]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlResponsabiliUnita]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportXmlResponsabiliUnita]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlTitolari]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportXmlTitolari]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportXmlTitolari2]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spReportXmlTitolari2]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spSessioneBilaterali_Fill]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spSessioneBilaterali_Fill]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spSetBilanciamentoTaglioDaRifare]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spSetBilanciamentoTaglioDaRifare]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spUnitRelateDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
-- drop procedure [dbo].[spUnitRelateDelete]
-- GO
-- 
-- print 'End: Drop Procedures'
-- 
-- print 'Begin: Drop Views'
-- -- DROP VIEWS
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_AnaUnita]') and OBJECTPROPERTY(id, N'IsView') = 1)
-- drop view [dbo].[Bil_AnaUnita]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_CoefficientiPerdita]') and OBJECTPROPERTY(id, N'IsView') = 1)
-- drop view [dbo].[Bil_CoefficientiPerdita]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_ContrattoOperatore]') and OBJECTPROPERTY(id, N'IsView') = 1)
-- drop view [dbo].[Bil_ContrattoOperatore]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_Operatori]') and OBJECTPROPERTY(id, N'IsView') = 1)
-- drop view [dbo].[Bil_Operatori]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_Unita]') and OBJECTPROPERTY(id, N'IsView') = 1)
-- drop view [dbo].[Bil_Unita]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_UnitaContratto_UnitRelate]') and OBJECTPROPERTY(id, N'IsView') = 1)
-- drop view [dbo].[Bil_UnitaContratto_UnitRelate]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_Utenti]') and OBJECTPROPERTY(id, N'IsView') = 1)
-- drop view [dbo].[Bil_Utenti]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Bil_UtentiOperatori]') and OBJECTPROPERTY(id, N'IsView') = 1)
-- drop view [dbo].[Bil_UtentiOperatori]
-- GO
-- 
-- print 'End: Drop Views'
-- 
-- 
-- BEGIN TRANSACTION
-- SET QUOTED_IDENTIFIER ON
-- SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
-- SET ARITHABORT ON
-- SET NUMERIC_ROUNDABORT OFF
-- SET CONCAT_NULL_YIELDS_NULL ON
-- SET ANSI_NULLS ON
-- SET ANSI_PADDING ON
-- SET ANSI_WARNINGS ON
-- COMMIT
-- 
-- print 'Begin: Modify PK/Indexes on SmLog'
-- -- MODIFICA INDICE SMLOG
-- BEGIN TRANSACTION
-- ALTER TABLE dbo.SmLog
-- 	DROP CONSTRAINT PK_SmLog
-- GO
-- ALTER TABLE dbo.SmLog ADD CONSTRAINT
-- 	PK_SmLog PRIMARY KEY NONCLUSTERED 
-- 	(
-- 	Id
-- 	) ON [PRIMARY]
-- 
-- GO
-- IF EXISTS (SELECT name FROM sysindexes
--          WHERE name = 'IX_SmLog')
--    DROP INDEX dbo.SmLog.IX_SmLog
-- 
-- GO
-- CREATE CLUSTERED INDEX IX_SmLog ON dbo.SmLog
-- 	(
-- 	SmTS DESC 
-- 	) ON [PRIMARY]
-- GO
-- COMMIT
-- 
-- print 'End: Modify PK/Indexes on SmLog'
-- 
-- 
-- SET ANSI_WARNINGS ON
-- 
-- 
-- -- MODIFICA CAMPO TIPOUNITA E INDICE UNIT_RELATE
-- BEGIN TRANSACTION
-- if not exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[UnitRelate]') and name = 'TipoUnita')
-- begin
-- print 'Begin: Modify UnitRelate Fields (TipoUnita)'
-- ALTER TABLE dbo.UnitRelate ADD
-- 	TipoUnita char(1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL CONSTRAINT DF_UnitRelate_TipoUnita DEFAULT 'Q'
-- end
-- print 'End: Modify UnitRelate Fields (TipoUnita)'
-- COMMIT
-- 
-- BEGIN TRANSACTION
-- print 'Begin: Modify UnitRelate Indexes'
-- IF EXISTS (SELECT name FROM sysindexes
--          WHERE name = 'IX_UnitRelate')
--    DROP INDEX dbo.UnitRelate.IX_UnitRelate
-- 
-- 
--  CREATE  INDEX [IX_UnitRelate] ON [dbo].[UnitRelate]([CodiceUnitaSDC], [CategoriaUnitaSDC], [CodiceOperatoreSDC], [DataInizioValidita], [DataFineValidita]) ON [PRIMARY]
-- COMMIT
-- print 'End: Modify UnitRelate Indexes'
-- 
-- -- MODIFICA CAMPO ReasonText di ProgrammaOrarioPerUnitaErrori
-- print 'Begin: Modify Field ReasonText ProgrammaOrarioPerUnitaErrori'
-- BEGIN TRANSACTION
-- ALTER TABLE dbo.ProgrammaOrarioPerUnitaErrori
-- 	DROP CONSTRAINT FK_ProgrammaOrarioPerUnitaErrori_ProgrammaOrarioPerUnita
-- GO
-- COMMIT
-- BEGIN TRANSACTION
-- ALTER TABLE dbo.ProgrammaOrarioPerUnitaErrori
-- 	DROP CONSTRAINT FK_ProgrammaOrarioPerUnitaErrori_FileMGP
-- GO
-- COMMIT
-- BEGIN TRANSACTION
-- CREATE TABLE dbo.Tmp_ProgrammaOrarioPerUnitaErrori
-- 	(
-- 	IdContratto int NOT NULL,
-- 	DataProgramma smalldatetime NOT NULL,
-- 	PeriodoRilevante tinyint NOT NULL,
-- 	CodiceUnitaSDC varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	CategoriaUnitaSDC varchar(1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	Origin varchar(2) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	ReasonCode varchar(15) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	ReasonText varchar(1024) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	IdFile char(32) COLLATE SQL_Latin1_General_CP1_CS_AS NULL
-- 	)  ON [PRIMARY]
-- GO
-- IF EXISTS(SELECT * FROM dbo.ProgrammaOrarioPerUnitaErrori)
-- 	 EXEC('INSERT INTO dbo.Tmp_ProgrammaOrarioPerUnitaErrori (IdContratto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUnitaSDC, Origin, ReasonCode, ReasonText, IdFile)
-- 		SELECT IdContratto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUnitaSDC, Origin, ReasonCode, ReasonText, IdFile FROM dbo.ProgrammaOrarioPerUnitaErrori TABLOCKX')
-- GO
-- DROP TABLE dbo.ProgrammaOrarioPerUnitaErrori
-- GO
-- EXECUTE sp_rename N'dbo.Tmp_ProgrammaOrarioPerUnitaErrori', N'ProgrammaOrarioPerUnitaErrori', 'OBJECT'
-- GO
-- ALTER TABLE dbo.ProgrammaOrarioPerUnitaErrori ADD CONSTRAINT
-- 	PK_ProgrammaOrarioPerUnitaErrori PRIMARY KEY CLUSTERED 
-- 	(
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC
-- 	) ON [PRIMARY]
-- 
-- GO
-- ALTER TABLE dbo.ProgrammaOrarioPerUnitaErrori WITH NOCHECK ADD CONSTRAINT
-- 	FK_ProgrammaOrarioPerUnitaErrori_FileMGP FOREIGN KEY
-- 	(
-- 	IdFile
-- 	) REFERENCES dbo.FileMGP
-- 	(
-- 	IdFile
-- 	)
-- GO
-- ALTER TABLE dbo.ProgrammaOrarioPerUnitaErrori WITH NOCHECK ADD CONSTRAINT
-- 	FK_ProgrammaOrarioPerUnitaErrori_ProgrammaOrarioPerUnita FOREIGN KEY
-- 	(
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC
-- 	) REFERENCES dbo.ProgrammaOrarioPerUnita
-- 	(
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC
-- 	)
-- GO
-- 
-- COMMIT
-- print 'End: Modify Field ReasonText ProgrammaOrarioPerUnitaErrori'
-- 
-- print 'Begin: Create Index on ProgrammaOrarioPerUnitaErrori'
-- 
--  CREATE  INDEX [IX_ProgrammaOrarioPerUnitaErrori] ON [dbo].[ProgrammaOrarioPerUnitaErrori]([DataProgramma], [PeriodoRilevante], [IdContratto], [CodiceUnitaSDC], [CategoriaUnitaSDC]) ON [PRIMARY]
-- GO
-- print 'End: Create Index on ProgrammaOrarioPerUnitaErrori'
-- 
-- print 'Begin: Create Table ReportQueries'
-- -- CANCELLO REPORTQUERIES E LA RICREO E POI LA RIEMPIO DOPO
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportQueries]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
-- drop table [dbo].[ReportQueries]
-- GO
-- 
-- 
-- CREATE TABLE [dbo].[ReportQueries] (
-- 	[CodiceReport] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	[Descrizione] [varchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
-- 	[Parametri] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
-- 	[Destinatario] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
-- ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
-- GO
-- 
-- 
-- ALTER TABLE [dbo].[ReportQueries] WITH NOCHECK ADD 
-- 	CONSTRAINT [PK_ReportQueries] PRIMARY KEY  CLUSTERED 
-- 	(
-- 		[CodiceReport]
-- 	)  ON [PRIMARY] 
-- GO
-- 
-- ALTER TABLE [dbo].[ReportQueries] WITH NOCHECK ADD 
-- 	CONSTRAINT [DF_ReportQueries_Destinatario] DEFAULT ('A') FOR [Destinatario],
-- 	CONSTRAINT [CK_ReportQueries] CHECK ([Destinatario] = 'A' or [Destinatario] = 'U' or [Destinatario] = 'E')
-- GO
-- print 'End: Create Table ReportQueries'
-- 
-- print 'Begin: Delete Table ErroriProgrammiUtenti'
-- -- CANCELLAZIONE TABELLE ErroriProgrammiUtenti SE ESISTONO
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ErroriPIPTransactionUtenti_XmlProgrammiUtenti]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
-- ALTER TABLE [dbo].[ErroriPIPTransactionUtenti] DROP CONSTRAINT FK_ErroriPIPTransactionUtenti_XmlProgrammiUtenti
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ErroriProgrammiUtenti_XmlProgrammiUtenti]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
-- ALTER TABLE [dbo].[ErroriProgrammiUtenti] DROP CONSTRAINT FK_ErroriProgrammiUtenti_XmlProgrammiUtenti
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ErroriPIPTransactionUtenti]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
-- drop table [dbo].[ErroriPIPTransactionUtenti]
-- GO
-- 
-- if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ErroriProgrammiUtenti]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
-- drop table [dbo].[ErroriProgrammiUtenti]
-- GO
-- print 'End: Delete Table ErroriProgrammiUtenti'
-- 
-- print 'Begin: Check Table XmlFileDaOperatori'
-- -- CREAZIONE XmlFileDaOperatori (SE NON ESISTE)
-- if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[XmlFileDaOperatori]') )
-- begin
-- print 'Begin: Create Table XmlFileDaOperatori'
-- BEGIN TRANSACTION
-- 	CREATE TABLE [dbo].[XmlFileDaOperatori] (
-- 		[IdFileXml] [int] IDENTITY (1, 1) NOT NULL ,
-- 		[FileFirmato] [image] NULL ,
-- 		[TSInvio] [datetime] NOT NULL ,
-- 		[Zippato] [bit] NULL ,
-- 		[NomeFileUtente] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CS_AS NULL ,
-- 		[CodiceUtenteSDC] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 		[PathFileFirmato] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CS_AS NULL ,
-- 		[CodiceOperatoreSDC] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 		[TSModifica] [datetime] NOT NULL ,
-- 		[IdFileFA] [varchar] (32) COLLATE SQL_Latin1_General_CP1_CS_AS NULL ,
-- 		[Issuer] [varchar] (256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
-- 		[SerialNumber] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
-- 		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
-- 
-- 
-- 	ALTER TABLE [dbo].[XmlFileDaOperatori] WITH NOCHECK ADD 
-- 		CONSTRAINT [XmlFileDaOperatori_PK] PRIMARY KEY  CLUSTERED 
-- 		(
-- 			[IdFileXml]
-- 		)  ON [PRIMARY] 
-- 
-- 	
-- 	ALTER TABLE [dbo].[XmlFileDaOperatori] ADD 
-- 		CONSTRAINT [FK_XmlFileDaOperatori_FileOperatori] FOREIGN KEY 
-- 		(
-- 			[IdFileFA]
-- 		) REFERENCES [dbo].[FileOperatori] (
-- 			[IdFile]
-- 		),
-- 		CONSTRAINT [FK_XmlFileDaOperatori_Operatori] FOREIGN KEY 
-- 		(
-- 			[CodiceOperatoreSDC]
-- 		) REFERENCES [dbo].[Operatori] (
-- 			[CodiceOperatoreSDC]
-- 		),
-- 		CONSTRAINT [Utenti_XmlFileDaOperatori_FK1] FOREIGN KEY 
-- 		(
-- 			[CodiceUtenteSDC]
-- 		) REFERENCES [dbo].[Utenti] (
-- 			[CodiceUtenteSDC]
-- 		)
-- 
-- COMMIT
-- print 'End: Create Table XmlFileDaOperatori'
-- end
-- 
-- -- MODIFICA A Certificate_List: se non esiste aggiungo campo TSCreazione
-- if not exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[Certificate_List]') and name = 'TSCreazione')
-- begin
-- 	print 'Begin: Alter Table Certificate_List'
-- 	ALTER TABLE dbo.Certificate_List ADD
-- 		TSCreazione smalldatetime NULL
-- 	 
-- 	
-- 	ALTER TABLE [dbo].[Certificate_List] WITH NOCHECK ADD 
-- 		CONSTRAINT [DF_Certificate_List_TSCreazione] DEFAULT (getdate()) FOR [TSCreazione]
-- 	print 'End: Alter Table Certificate_List'	
-- end 
-- 
-- -- MODIFICA Contratto: aggiunta campo GestioneTaglio
-- if not exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[Contratto]') and name = 'GestioneTaglio')
-- begin
-- 	print 'Begin: Alter Table Contratto'
-- 
-- 	ALTER TABLE dbo.Contratto ADD
-- 		GestioneTaglio char(1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL CONSTRAINT DF_Contratto_GestioneTaglio DEFAULT ('T')
-- 	print 'End: Alter Table Contratto'
-- end
-- go
-- if exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[Contratto]') and name = 'GestioneTaglio')
-- begin
-- 	print 'Begin: Add Check Constraint Contratto'
-- 	ALTER TABLE [dbo].[Contratto] WITH NOCHECK ADD 
-- 		CONSTRAINT [CK_Contratto_GestioneTaglio] CHECK ([GestioneTaglio] = 'M' or ([GestioneTaglio] = 'C' or ([GestioneTaglio] = 'P' or [GestioneTaglio] = 'T')))
-- 	print 'End: Add Check Constraint Contratto'
-- end
-- 
-- -- MODIFICA Operatori: aggiunta campo IsGMEOp
-- if not exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[Operatori]') and name = 'IsGMEOp')
-- begin
-- 	print 'Begin: Alter Table Operatori'
-- 	ALTER TABLE dbo.Operatori ADD
-- 		IsGMEOp bit NOT NULL CONSTRAINT DF_Operatori_IsGMEOp DEFAULT (0)
-- 	print 'End: Alter Table Operatori'
-- end
-- 
-- -- MODIFICA ProgrammaOrario: aggiunta campi GestioneTaglio, IsGMEOp, SbilanciamentoMWhReale
-- if not exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[ProgrammaOrario]') and name = 'GestioneTaglio') and
--    not exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[ProgrammaOrario]') and name = 'IsGMEOp') and
--    not exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[ProgrammaOrario]') and name = 'SbilanciamentoMWhReale') 
-- begin
-- 	print 'Begin: Alter Table ProgrammaOrario'
-- 	ALTER TABLE dbo.ProgrammaOrario ADD
-- 	GestioneTaglio char(1) COLLATE SQL_Latin1_General_CP1_CS_AS NULL,
-- 	IsGMEOp bit NULL,
-- 	SbilanciamentoMWhReale float(53) NULL
-- 	print 'End: Alter Table ProgrammaOrario'
-- end
-- GO
-- 
-- -- SESSIONE BILATERALI
-- if not exists (select * from dbo.syscolumns where id = object_id(N'[dbo].[SessioneBilaterali]') and name = 'DataChiusuraMGP') 
-- begin
-- BEGIN TRANSACTION
-- 	print 'Begin: Alter Table SessioneBilaterali'
-- 	ALTER TABLE dbo.SessioneBilaterali ADD
-- 		DataChiusuraMGP datetime NULL
-- 	COMMIT
-- 	print 'End: Alter Table SessioneBilaterali'
-- end
-- 
-- -- MODIFICA ALL'INDICE SU PROGRAMMAORARIO
-- print 'Begin: Modify Index ProgrammaOrarioPerUnita'
-- BEGIN TRANSACTION
-- 	
-- ALTER TABLE dbo.ProgrammaOrarioPerUnita
-- 	DROP CONSTRAINT FK_ProgrammaOrarioPerUnita_ProgrammaOrario
-- GO
-- ALTER TABLE dbo.ProgrammaOrario
-- 	DROP CONSTRAINT PK_ProgrammaOrario
-- GO
-- ALTER TABLE dbo.ProgrammaOrario ADD CONSTRAINT
-- 	PK_ProgrammaOrario PRIMARY KEY NONCLUSTERED 
-- 	(
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante
-- 	) ON [PRIMARY]
-- 
-- GO
-- CREATE CLUSTERED INDEX IX_ProgrammaOrario ON dbo.ProgrammaOrario
-- 	(
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	IdContratto
-- 	) ON [PRIMARY]
-- GO
-- 	
-- COMMIT
-- BEGIN TRANSACTION
-- ALTER TABLE dbo.ProgrammaOrarioPerUnita WITH NOCHECK ADD CONSTRAINT
-- 	FK_ProgrammaOrarioPerUnita_ProgrammaOrario FOREIGN KEY
-- 	(
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante
-- 	) REFERENCES dbo.ProgrammaOrario
-- 	(
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante
-- 	)
-- GO
-- COMMIT
-- print 'End: Modify Index ProgrammaOrarioPerUnita'
-- 
-- 
-- /* ---------------- Viste, Funzioni, Stored Procedure ------------------------- */
-- 
-- print 'Begin: Create Views'
-- GO
-- 
-- CREATE VIEW dbo.Bil_AnaUnita
-- AS
-- SELECT     	dbo.SDC_Unita.CodiceUnitaSDC, 
-- 		dbo.SDC_Unita.CategoriaUnitaSDC, 
-- 		dbo.SDC_Unita.NomeUnita, 
-- 		dbo.SDC_Unita.TipoUnita, 
--                 dbo.SDC_Unita.CoefficientePerdita, 
-- 		dbo.SDC_Unita.CodicePuntoDiScambioRilevanteSDC, 
-- 		dbo.SDC_Unita.PotenzaMassimaMWh, 
--                 dbo.SDC_Unita.PotenzaMinimaMWh, 
-- 		dbo.SDC_Unita.OrdineDiMerito, 
-- 		dbo.SDC_Unita.CodiceOperatoreDiRiferimentoSDC, 
-- 		dbo.SDC_Unita.Abilitata, 
--                 dbo.SDC_Unita.ResponsabileAggiornamento, 
-- 		dbo.Unita.StatoBilateraliUnita, 
-- 		dbo.Unita.TSModifica, 
--                 dbo.SDC_Unita.TSModifica AS SDC_Unita_TSModifica, 
-- 		dbo.SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
-- 		CASE ISNULL(dbo.SDC_Unita_MarketInformation.Eligibility, 'Able') WHEN 'Able' THEN 1 ELSE 0 END SDC_MI
-- FROM         dbo.Unita 
-- INNER JOIN   dbo.SDC_Unita ON dbo.Unita.CodiceUnitaSDC = dbo.SDC_Unita.CodiceUnitaSDC 
-- AND          dbo.Unita.CategoriaUnitaSDC = dbo.SDC_Unita.CategoriaUnitaSDC 
-- INNER JOIN   dbo.SDC_PuntiDiScambioRilevanti ON dbo.SDC_Unita.CodicePuntoDiScambioRilevanteSDC = dbo.SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- LEFT OUTER JOIN dbo.SDC_Unita_MarketInformation ON dbo.Unita.CodiceUnitaSDC  = dbo.SDC_Unita_MarketInformation.CodiceUnitaSDC
-- AND          dbo.Unita.CategoriaUnitaSDC = dbo.SDC_Unita_MarketInformation.CategoriaUnitaSDC 
-- AND	     dbo.SDC_Unita_MarketInformation.MarketCode = 'MGP'
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- CREATE VIEW dbo.Bil_CoefficientiPerdita
-- AS
-- SELECT     ISNULL(dbo.SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita, 0) AS PPDSR, dbo.SDC_Unita.CodiceUnitaSDC AS CodiceUnita, 
--                       dbo.SDC_Unita.CategoriaUnitaSDC AS Categoria, ISNULL(dbo.SDC_Unita.CoefficientePerdita, 1) AS PUNITA, dbo.Unita.StatoBilateraliUnita AS STATO, 
--                       dbo.SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita / dbo.SDC_Unita.CoefficientePerdita AS Rapporto
-- FROM         dbo.SDC_PuntiDiScambioRilevanti INNER JOIN
--                       dbo.SDC_Unita ON 
--                       dbo.SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = dbo.SDC_Unita.CodicePuntoDiScambioRilevanteSDC INNER JOIN
--                       dbo.Unita ON dbo.SDC_Unita.CodiceUnitaSDC = dbo.Unita.CodiceUnitaSDC AND 
--                       dbo.SDC_Unita.CategoriaUnitaSDC = dbo.Unita.CategoriaUnitaSDC
-- WHERE     (dbo.Unita.StatoBilateraliUnita = 1)
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- /****** Object:  View dbo.Bil_Operatori    Script Date: 01/04/2004 14.58.12 ******/
-- CREATE VIEW dbo.Bil_Operatori
-- AS
-- SELECT     dbo.Operatori.CodiceOperatoreSDC, dbo.Operatori.StatoBilateraliOperatore, dbo.Operatori.TSModifica AS Operatori_TSModifica, 
--                       dbo.SDC_Operatori.RagioneSociale, dbo.SDC_Operatori.Indirizzo1, dbo.SDC_Operatori.Indirizzo2, dbo.SDC_Operatori.Citta, 
--                       dbo.SDC_Operatori.Nazione, dbo.SDC_Operatori.CodiceFiscale, dbo.SDC_Operatori.PartitaIva, dbo.SDC_Operatori.Fax, dbo.SDC_Operatori.Email, 
--                       dbo.SDC_Operatori.ReferenteAmministrativo, dbo.SDC_Operatori.SedeAmministrativa, dbo.SDC_Operatori.Abilitato, 
--                       dbo.SDC_Operatori.TSModifica AS SDC_TSModifica, dbo.SDC_Operatori.ResponsabileAggiornamento, dbo.Operatori.Amministratore
-- FROM         dbo.Operatori INNER JOIN
--                       dbo.SDC_Operatori ON dbo.Operatori.CodiceOperatoreSDC = dbo.SDC_Operatori.CodiceOperatoreSDC
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- /****** Object:  View dbo.Bil_ContrattoOperatore    Script Date: 01/04/2004 14.58.12 ******/
-- 
-- CREATE VIEW dbo.Bil_ContrattoOperatore
-- AS
-- SELECT     dbo.Contratto.IdContratto, dbo.Contratto.CodiceContratto, dbo.Contratto.DataStipula, dbo.Contratto.DataInizioValidita, dbo.Contratto.DataFineValidita, dbo.Contratto.CRN, 
--                       dbo.Contratto.StatoContratto, dbo.Contratto.CodiceOperatoreSDC, dbo.Contratto.TSModifica, dbo.Contratto.CodiceOperatoreSDCAcquirente, 
--                       dbo.Contratto.CodiceOperatoreSDCCedente, dbo.Contratto.ProgrammazionePrivilegiata, dbo.Contratto.TrCN, 
-- 	         dbo.Contratto.GestioneTaglio, Titolare.RagioneSociale AS Titolare_RagioneSociale, 
--                       Titolare.StatoBilateraliOperatore AS Titolare_StatoBilateraliOperatore, Titolare.Abilitato AS Titolare_Abilitato, 
--                       Acquirente.RagioneSociale AS Acquirente_RagioneSociale, Acquirente.StatoBilateraliOperatore AS Acquirente_StatoBilateraliOperatore, 
--                       Acquirente.Abilitato AS Acquirente_Abilitato, Venditore.RagioneSociale AS Venditore_RagioneSociale, 
--                       Venditore.StatoBilateraliOperatore AS Venditore_StatoBilateraliOperatore, Venditore.Abilitato AS Venditore_Abilitato
-- FROM         dbo.Contratto INNER JOIN
--                       dbo.Bil_Operatori Titolare ON dbo.Contratto.CodiceOperatoreSDC = Titolare.CodiceOperatoreSDC LEFT OUTER JOIN
--                       dbo.Bil_Operatori Acquirente ON dbo.Contratto.CodiceOperatoreSDCAcquirente = Acquirente.CodiceOperatoreSDC LEFT OUTER JOIN
--                       dbo.Bil_Operatori Venditore ON dbo.Contratto.CodiceOperatoreSDCCedente = Venditore.CodiceOperatoreSDC
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- CREATE VIEW dbo.Bil_Unita
-- AS
-- SELECT     dbo.SDC_Unita.CodiceUnitaSDC, dbo.SDC_Unita.CategoriaUnitaSDC, dbo.SDC_Unita.NomeUnita, dbo.SDC_Unita.TipoUnita, 
--                       dbo.SDC_Unita.SottotipoUnita, dbo.SDC_Unita.CoefficientePerdita, dbo.SDC_Unita.CodicePuntoDiScambioRilevanteSDC, 
--                       dbo.SDC_Unita.PotenzaMassimaMWh, dbo.SDC_Unita.PotenzaMinimaMWh, dbo.SDC_Unita.OrdineDiMerito, 
--                       dbo.SDC_Unita.CodiceOperatoreDiRiferimentoSDC, dbo.SDC_Unita.Abilitata, dbo.SDC_Unita.ResponsabileAggiornamento, 
--                       dbo.Unita.StatoBilateraliUnita, dbo.Unita.TSModifica AS Unita_TSModifica, dbo.SDC_Unita.TSModifica AS SDC_Unita_TSModifica, 
--                       dbo.SDC_PuntiDiScambioRilevanti.CodiceZonaSDC, dbo.SDC_Unita.UnbalancedParticipantNumber, CASE ISNULL(SDC_MI.Eligibility, 'Able') 
--                       WHEN 'Able' THEN 1 ELSE 0 END MgpEnabled
-- FROM         dbo.Unita INNER JOIN
--                       dbo.SDC_Unita ON dbo.Unita.CodiceUnitaSDC = dbo.SDC_Unita.CodiceUnitaSDC AND 
--                       dbo.Unita.CategoriaUnitaSDC = dbo.SDC_Unita.CategoriaUnitaSDC INNER JOIN
--                       dbo.SDC_PuntiDiScambioRilevanti ON 
--                       dbo.SDC_Unita.CodicePuntoDiScambioRilevanteSDC = dbo.SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC LEFT OUTER JOIN
--                           (SELECT     CodiceUnitaSDC, CategoriaUnitaSDC, MarketCode, Eligibility
--                             FROM          dbo.SDC_Unita_MarketInformation
--                             WHERE      MarketCode = 'MGP') SDC_MI ON SDC_MI.CodiceUnitaSDC = dbo.SDC_Unita.CodiceUnitaSDC AND 
--                       SDC_MI.CategoriaUnitaSDC = dbo.SDC_Unita.CategoriaUnitaSDC
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE VIEW dbo.Bil_UnitaContratto_UnitRelate
-- AS
-- 
-- 
-- 
-- 
-- select IdContratto, 
--  	CodiceUnitaSDC,
--    	CategoriaUnitaSDC,
-- 	case isnull(DataInizioValiditaCedente, '') when '' then null 
-- 	else
--  		case sign(datediff(day, DataInizioValidita, DataInizioValiditaCedente)) 
--  		when 1 then DataInizioValiditaCedente
--  		when 0 then DataInizioValiditaCedente
--  		else DataInizioValidita
--  		end 
-- 	end DataInizioValiditaCedente,
-- 	case isnull(DataFineValiditaCedente, '') when '' then null 
-- 	else
-- 		case sign(datediff(day, DataFineValidita, DataFineValiditaCedente)) 
-- 		when 1 then DataFineValidita
-- 		when 0 then DataFineValidita
-- 		else DataFineValiditaCedente
-- 		end 
-- 	end DataFineValiditaCedente,
-- 	case isnull(DataInizioValiditaAcquirente, '') when '' then null 
-- 	else
-- 		case sign(datediff(day, DataInizioValidita, DataInizioValiditaAcquirente)) 
-- 		when 1 then DataInizioValiditaAcquirente
-- 		when 0 then DataInizioValiditaAcquirente
-- 		else DataInizioValidita
-- 		end 
-- 	end DataInizioValiditaAcquirente,
-- 	case isnull(DataFineValiditaAcquirente, '') when '' then null 
-- 	else
-- 		case sign(datediff(day, DataFineValidita, DataFineValiditaAcquirente)) 
-- 		when 1 then DataFineValidita
-- 		when 0 then DataFineValidita
-- 		else DataFineValiditaAcquirente
-- 		end 
-- 	end DataFineValiditaAcquirente,
-- 	TrCC,
--    	TrUC,
--    	VUC
-- from
-- (
-- select _ur.IdContratto, 
--  	_ur.CodiceUnitaSDC,
--    	_ur.CategoriaUnitaSDC,
--   	_ur.DataInizioValidita,
--     	_ur.DataFineValidita,
--    	_ur.TrCC,
--    	_ur.TrUC,
--    	_ur.VUC,
--  max(DataInizioValiditaCedente) DataInizioValiditaCedente,
--  max(DataFineValiditaCedente) DataFineValiditaCedente,
--  max(DataInizioValiditaAcquirente) DataInizioValiditaAcquirente,
--  max(DataFineValiditaAcquirente) DataFineValiditaAcquirente
-- from (
-- select 	 c.IdContratto,
-- 	c.DataInizioValidita,
--    	c.DataFineValidita,
-- 	ur.CodiceUnitaSDC,
--   	ur.CategoriaUnitaSDC,
-- 	case ur.CodiceOperatoreSDC when c.CodiceOperatoreSDCCedente then
-- 		ur.DataInizioValidita
-- 	else	null
-- 	end DataInizioValiditaCedente,
-- 	case ur.CodiceOperatoreSDC when c.CodiceOperatoreSDCCedente then
-- 		ur.DataFineValidita
-- 	else NULL
-- 	end DataFineValiditaCedente,
-- 	case ur.CodiceOperatoreSDC when c.CodiceOperatoreSDCAcquirente 
-- 	then
-- 		ur.DataInizioValidita
-- 	else NULL
-- 	end DataInizioValiditaAcquirente,
-- 	case ur.CodiceOperatoreSDC when c.CodiceOperatoreSDCAcquirente 
-- 	then
-- 		ur.DataFineValidita
-- 	else NULL
-- 	end DataFineValiditaAcquirente,
-- 	c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC,
-- 	ur.TrUC,
-- 	ur.VUC
-- from  contratto c, unitrelate ur, sdc_unita su
-- where 
-- su.CodiceUnitaSDC = ur.CodiceUnitaSDC and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC 
-- and
-- (
-- 	(ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and su.TipoUnita in ('P', 'M'))
-- or 
-- 	(ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and su.TipoUnita in ('C', 'M'))
-- )
-- and (ur.DataInizioValidita <= c.DataFineValidita
-- and ur.DataFineValidita >= c.DataInizioValidita)
-- and ur.Abilitata = 1
-- ) _ur
-- group by _ur.IdContratto,
-- 	_ur.CodiceUnitaSDC,
-- 	_ur.CategoriaUnitaSDC,
--   	_ur.DataInizioValidita,
--   	_ur.DataFineValidita,
-- 	_ur.TrCC,
--  	_ur.TrUC,
--  	_ur.VUC
-- ) uc
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- /****** Object:  View dbo.Bil_Utenti    Script Date: 01/04/2004 14.58.12 ******/
-- CREATE VIEW dbo.Bil_Utenti
-- AS
-- SELECT     dbo.SDC_Utenti.CodiceUtenteSDC, dbo.SDC_Utenti.Nome, dbo.SDC_Utenti.Cognome, dbo.SDC_Utenti.Telefono, dbo.SDC_Utenti.Fax, 
--                       dbo.SDC_Utenti.Email, dbo.SDC_Utenti.Abilitato, dbo.SDC_Utenti.CodiceFiscale, dbo.SDC_Utenti.ResponsabileAggiornamento, dbo.SDC_Utenti.DN, 
--                       dbo.SDC_Utenti.Login, dbo.SDC_Utenti.Pwd, dbo.SDC_Utenti.Lingua, dbo.Utenti.StatoBilateraliUtente, dbo.Utenti.TSModifica, 
--                       dbo.SDC_Utenti.Certificato, dbo.SDC_Utenti.CertificatoFirma
-- FROM         dbo.SDC_Utenti INNER JOIN
--                       dbo.Utenti ON dbo.SDC_Utenti.CodiceUtenteSDC = dbo.Utenti.CodiceUtenteSDC
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- /****** Object:  View dbo.Bil_UtentiOperatori    Script Date: 01/04/2004 14.58.12 ******/
-- 
-- CREATE VIEW dbo.Bil_UtentiOperatori
-- AS
-- SELECT     dbo.RelOperatoriUtenti.CodiceOperatoreSDC, dbo.SDC_Operatori.RagioneSociale, dbo.SDC_Operatori.Indirizzo1, dbo.SDC_Operatori.Indirizzo2, 
--                       dbo.SDC_Operatori.Citta, dbo.SDC_Operatori.Nazione, dbo.SDC_Operatori.CodiceFiscale, dbo.SDC_Operatori.PartitaIva, dbo.SDC_Operatori.Email, 
--                       dbo.SDC_Operatori.Fax, dbo.SDC_Operatori.ReferenteAmministrativo, dbo.SDC_Operatori.SedeAmministrativa, 
--                       dbo.SDC_Operatori.Abilitato AS SDC_Operatori_Abilitato, dbo.SDC_Operatori.TSModifica AS SDC_Operatori_TSModifica, 
--                       dbo.SDC_Operatori.ResponsabileAggiornamento, dbo.RelOperatoriUtenti.Abilitato, dbo.RelOperatoriUtenti.TSIniValidita, 
--                       dbo.RelOperatoriUtenti.CodiceRuolo, dbo.RelOperatoriUtenti.TSModifica, dbo.RelOperatoriUtenti.TSEndValidita, 
--                       dbo.RelOperatoriUtenti.CodiceUtenteSDC, dbo.RelOperatoriUtenti.Amministratore, 
--                       dbo.Operatori.StatoBilateraliOperatore AS SDC_Operatori_StatoBilateraliOperatore
-- FROM         dbo.SDC_Operatori INNER JOIN
--                       dbo.RelOperatoriUtenti ON dbo.SDC_Operatori.CodiceOperatoreSDC = dbo.RelOperatoriUtenti.CodiceOperatoreSDC INNER JOIN
--                       dbo.Operatori ON dbo.SDC_Operatori.CodiceOperatoreSDC = dbo.Operatori.CodiceOperatoreSDC AND 
--                       dbo.RelOperatoriUtenti.CodiceOperatoreSDC = dbo.Operatori.CodiceOperatoreSDC
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- -- PASSO 4 - CREATE FUNCTIONS E PROCEDURE
-- 
-- print 'Begin: Create Functions and Procedures'
-- GO
-- 
-- CREATE FUNCTION [dbo].[GetHourNum] (@DataProgramma as smalldatetime)  
-- RETURNS int  AS  
-- BEGIN 
-- declare @oraMax int,
-- 	@Month int,
-- 	@WeekDay int,
-- 	@NextDate smalldatetime,
-- 	@NextDateMonth int,
-- 	@LastDayOfWeek int
-- 
-- 
-- set @LastDayOfWeek= 8-@@datefirst
-- set @Month= DATEPART(month,@DataProgramma)
-- set @WeekDay= DATEPART(weekday,@DataProgramma)
-- set @NextDate= @DataProgramma + 7
-- set @NextDateMonth= DATEPART(month,@NextDate)
-- set @oraMax = 24
-- -- se e` Marzo, e` Domenica e Domenica prossima e` gia` Aprile
-- if (@Month = 3  and @WeekDay = @LastDayOfWeek and @NextDateMonth = 4)
-- begin
-- 	set @oraMax = 23
-- end
-- 
-- -- se e` Ottobre, e` Domenica e Domenica prossima e` gia` Novembre
-- if (@Month=10 and @WeekDay = @LastDayOfWeek and @NextDateMonth = 11)
-- begin
-- 	set @oraMax = 25
-- end
-- return(@oraMax)
-- END
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[GetHourNum]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[GetHourNum]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[GetHourNum]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- CREATE  PROCEDURE [dbo].[spCalcolaBilanciamento]
-- 	@DataProgramma smalldatetime,
-- 	@SogliaSbilMWh float
-- AS
-- 
-- -- non si usa read uncommitted in quanto il bilanciamento 
-- -- viene lanciato dentro un batch (i dati quindi non cambiamo)
-- -- e comunque il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri
-- 
-- 
-- -- declare
-- -- 	@DataProgramma smalldatetime,
-- -- 	@SogliaSbilMWh float
-- -- 
-- -- set @DataProgramma = '24/11/2004'
-- -- set @SogliaSbilMWh = 0.001
-- -- 
-- -- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno
-- -- (tutti i programmi !! )
-- 
-- -- all'uscita della sp avro`
-- -- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o non bilanciato.
-- -- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
-- --  (es contratto non valido, unita` non valide ecc)
-- -- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.
-- -- POU.QtyMWhBilanciamento=null per tutti i programmi.
-- 
-- -- inizializzo i campi per la data
-- update ProgrammaOrario
-- set 
-- Bilanciato=null,
-- SbilanciamentoMWh=null,
-- SbilanciamentoMWhReale=null,
-- TSCalcoloBilanciamento=null
-- where DataProgramma = @DataProgramma
-- 
-- -- siccome calcolo il bilanciamento i dati del bilanciamento forzato devono essere resettati
-- update ProgrammaOrarioPerUnita
-- set 
-- QtyMWhBilanciamento=NULL
-- where DataProgramma = @DataProgramma
-- and not QtyMWhBilanciamento is null
-- 
-- 
-- -- qui indico che il bilanciamento per tutti i contratti e` stato fatto
-- -- e` da fare il taglio
-- update 
-- SessioneBilaterali
-- set
-- Bilanciamento=1,
-- Taglio=0
-- where DataProgramma=@DataProgramma
-- 
-- 
-- 
-- 
-- declare @TSCalcoloBilanciamento as datetime
-- set @TSCalcoloBilanciamento = getdate()
-- 
-- 
-- update ProgrammaOrario
-- set 
-- Bilanciato=W.Bilanciato,
-- SbilanciamentoMWh=W.BilMWh,
-- SbilanciamentoMWhReale=W.BilMWhReale,
-- TSCalcoloBilanciamento=@TSCalcoloBilanciamento
-- from ProgrammaOrario PW
-- inner join
-- (
-- 	select
-- 	Q.IdContratto,
-- 	@DataProgramma DataProgramma,
-- 	Q.PeriodoRilevante,
-- 	
-- 	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then 0 else 1 end Bilanciato,
-- 	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
-- 	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
-- 	
-- 	from
-- 	(
-- 		select 
-- 		POU.IdContratto,
-- 		POU.PeriodoRilevante,
-- 		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
-- 		U.CoefficientePerdita KU,
-- 		PR.CoefficienteDiPerdita KP
-- 		
-- 		from ProgrammaOrarioPerUnita POU
-- 		inner join ProgrammaOrario PO
-- 		on  PO.Idcontratto = POU.IdContratto
-- 		and PO.DataProgramma = POU.DataProgramma
-- 		and PO.PeriodoRilevante = POU.PeriodoRilevante
-- 		and PO.ProgrammaOrarioValidato = 1
-- 		
-- 		inner join Contratto CO
-- 		on CO.IdContratto = POU.IdContratto
-- 		and CO.DataInizioValidita <= @DataProgramma
-- 		and CO.DataFineValidita >= @DataProgramma
-- 		and CO.StatoContratto = 'Abilitato'
-- 		and CO.TrCN = 1
-- 		
-- 		inner join UnitRelate UR
-- 		on UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
-- 		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
-- 		and 
-- 		(
-- 			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
-- 			or
-- 			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
-- 		)
-- 		and UR.DataInizioValidita <= @DataProgramma
-- 		and UR.DataFineValidita   >= @DataProgramma
-- 		and UR.Abilitata = 1
-- 		and UR.TrUC = 1
-- 		
-- 		inner join SDC_Unita U
-- 		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
-- 		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
-- 		
-- 		inner join  SDC_PuntiDiScambioRilevanti PR
-- 		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC
-- 
-- 		where
-- 		POU.ProgOrarioDellUnitaValidato = 1
-- 		and POU.DataProgramma = @DataProgramma
-- 	) Q
-- 	group by IdContratto, PeriodoRilevante
-- ) W
-- on  PW.IdContratto = W.IdContratto
-- and PW.DataProgramma = W.DataProgramma
-- and PW.PeriodoRilevante = W.PeriodoRilevante
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamento]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamento]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamento]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE dbo.ReportContrattiFlaggati
-- @DataProgramma as datetime
-- as 
-- 
-- -- NON si usa Read Uncommited dato che le modifiche a Contratto sono rare.
-- 
-- select  case t.flag 
-- 	when 'C' then 'Se consumo maggiore della produzione' 
-- 	when 'P' then 'Se produzione maggiore del consumo' 
--  	when 'T' then 'Sempre' 
--  	when 'M' then 'Mai'
--  	end GestioneTaglio, 
-- 	NumContratti
-- from (
-- select flags.Ord, flags.flag, isnull(c.NumContratti, 0) NumContratti
-- from 
-- (	select 0 ord, 'T' flag
-- 	union
-- 	select 1 ord, 'P' flag
-- 	union
-- 	select 2 ord, 'C' flag
-- 	union
-- 	select 3 ord, 'M' flag
-- ) flags
-- left outer join
-- (
-- select GestioneTaglio,
-- count(*) NumContratti 
-- from contratto
-- where contratto.DataInizioValidita <= @DataProgramma 
-- and contratto.DataFineValidita >= @DataProgramma
-- and contratto.StatoContratto = 'Abilitato'
-- and TrCN = 1
-- group by GestioneTaglio
-- ) c
-- on flags.flag = c.GestioneTaglio
-- ) t
-- order by t.Ord
-- 
-- 
-- return
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportContrattiFlaggati]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportContrattiFlaggati]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportContrattiFlaggati]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- CREATE   PROCEDURE dbo.ReportEnergiaContrattiFlaggati
-- 	(
-- 		@DataProgramma datetime
-- 	)
-- AS
-- 
-- -- e' un report che va in POU --> leggo senza aspettare le modifiche dei programmi
-- set transaction isolation level read uncommitted
-- 	
-- select case(GestioneTaglio)
-- 	when 'T' then 'Sempre'
-- 	when 'C' then 'Consumo supera Produzione'
-- 	when 'P' then  'Produzione supera Consumo'
-- 	when 'M' then 'Mai'
-- end GestioneTaglio,
-- 	round(sum(isnull(QtyMWhProd, 0)), 3) QtyMWhProduzione, 
-- 	round(sum(isnull(QtyMWhProdMGP, 0)), 3) QtyMWhProduzioneMGP, 
-- 	round(sum(isnull(QtyMWhCons, 0)), 3) QtyMWhConsumo,
-- 	round(sum(isnull(QtyMWhConsMGP, 0)), 3) QtyMWhConsumoMGP
-- from
-- (
-- select c.CodiceContratto, 
-- 	c.CRN,
-- 	c.CodiceOperatoreSDCCedente,
-- 	c.CodiceOperatoreSDCAcquirente,
-- 	c.GestioneTaglio, 
-- 	p.QtyMWhProd, 
-- 	p.QtyMWhProdMGP,
-- 	p.QtyMWhCons,
-- 	p.QtyMWhConsMGP
-- from
-- (
-- select * from
-- contratto 
-- where DataInizioValidita <= @DataProgramma 
-- and DataFineValidita >= @DataProgramma
-- and StatoContratto = 'Abilitato'
-- and TrCN = 1) 
-- c
-- left outer join
-- (
-- select po.IdContratto, 
-- 	po.PeriodoRilevante,
-- 	case pou.ProgrammatoDalCedente 
-- 	when 1 then
-- 		abs(sum(isnull(pou.QtyMWhBilanciamento, pou.QtyMwh))) 
-- 	else
-- 		0
-- 	end QtyMWhProd,
-- 	case pou.ProgrammatoDalCedente 
-- 	when 1 then
-- 		abs(sum(isnull(pou.QtyMWhAssegnataMGP, 0))) 
-- 	else
-- 		0
-- 	end QtyMWhProdMGP,
-- 	case pou.ProgrammatoDalCedente 
-- 	when 0 then
-- 		abs(sum(isnull(pou.QtyMWhBilanciamento, pou.QtyMwh))) 
-- 	else
-- 		0
-- 	end QtyMWhCons,
-- 	case pou.ProgrammatoDalCedente 
-- 	when 0 then
-- 		abs(sum(pou.QtyMWhAssegnataMGP)) 
-- 	else
-- 		0
-- 	end QtyMWhConsMGP
-- from programmaorario po, 
-- programmaorarioperunita pou
-- where po.DataProgramma = @DataProgramma
-- and pou.DataProgramma = @DataProgramma
-- and pou.PeriodoRilevante = po.PeriodoRilevante
-- group by po.IdContratto, po.PeriodoRilevante, pou.ProgrammatoDalCedente 
-- ) p
-- on c.IdContratto = p.IdContratto
-- ) t 
-- group by GestioneTaglio
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 	RETURN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaContrattiFlaggati]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaContrattiFlaggati]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaContrattiFlaggati]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE PROCEDURE dbo.ReportEnergiaSbilancio
-- 	@DataProgramma as datetime,
-- 	@SogliaSbilMWh as float
-- AS
-- 	
-- -- e' un report che va in POU --> leggo senza aspettare le modifiche dei programmi
-- set transaction isolation level read uncommitted
-- 
-- 
-- select @DataProgramma DataProgramma,
-- C.CRN,
-- C.CodiceContratto,
-- C.CodiceOperatoreSDCCedente Cedente,
-- C.CodiceOperatoreSDCAcquirente Acquirente,
-- case (C.GestioneTaglio) 
-- 	when 'T' then 'Sempre'
-- 	when 'C' then 'se cons. supera prod.'
-- 	when 'P' then 'se prod. supera cons.'
-- 	when 'M' then 'mai'
-- end 
-- GestioneTaglio,
-- Q.PeriodoRilevante Ora,
-- Q.QtyMWhProd,
-- Q.QtyMWhCons,
-- Q.QtyMWhProdMGP,
-- Q.QtyMWhConsMGP,
-- Q.Bilanciato Bilanciato,
-- Q.BilMWh SbilanciamentoMWh
-- from ProgrammaOrario PO 
-- inner join Contratto C
-- on PO.IdContratto = C.IdContratto
-- inner join
-- (
-- 	select 
-- 	POU.IdContratto, 
-- 	@DataProgramma DataProgramma, 
-- 	POU.PeriodoRilevante,
-- 	sum(POU.QtyMWhProd) QtyMWhProd, 
-- 	sum(POU.QtyMWhCons) QtyMWhCons,
-- 	sum(POU.QtyMWhProdMGP) QtyMWhProdMGP, 
-- 	sum(POU.QtyMWhConsMGP) QtyMWhConsMGP,
-- 	case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then 0                                        else 1 end Bilanciato,
-- 	case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then round(Sum(round(POU.QtyMWh * UC.KP / UC.KU,3)), 3) else 0 end BilMWh
-- 	from 
-- 	(
-- 		-- trovo tutte le unita per contratto valide 
-- 		-- (TrCC e TrUC garantiscono che il contratto sia valido, le unita valide, gli operatori validi)
-- 		select 
-- 		UnitaContratto.IdContratto, 
-- 		UnitaContratto.CodiceUnitaSDC, 
-- 		UnitaContratto.CategoriaUnitaSDC,
-- 		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
-- 		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
-- 		from 
-- 		tab_UnitaContratto(@DataProgramma) UnitaContratto, 
-- 		SDC_Unita, SDC_PuntiDiScambioRilevanti,
-- 		Contratto
-- 		where 
-- 		Contratto.IdContratto = UnitaContratto.IdContratto
-- 		and Contratto.DataInizioValidita <= @DataProgramma
-- 		and Contratto.DataFineValidita >= @DataProgramma
-- 		and UnitaContratto.TrCC=1 
-- 		and UnitaContratto.TrUC=1
-- 		and UnitaContratto.UnitaDelContrattoValidata=1
-- 		and UnitaContratto.DataInizioValidita <= @DataProgramma
-- 		and UnitaContratto.DataFineValidita >= @DataProgramma
-- 		and UnitaContratto.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
-- 		and UnitaContratto.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
-- 		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- 	) UC
-- 	inner join
-- 	(
-- 		-- considero i POU validi del giorno
-- 		SELECT 
-- 		ProgrammaOrarioPerUnita.IdContratto, 
-- 		ProgrammaOrarioPerUnita.DataProgramma, 
-- 		ProgrammaOrarioPerUnita.PeriodoRilevante, 
-- 		ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
-- 		ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
-- 		case ProgrammatoDalCedente when 1 then QtyMWh else 0 end QtyMWhProd,
-- 		case ProgrammatoDalCedente when 0 then QtyMWh else 0 end QtyMWhCons,
-- 		case ProgrammatoDalCedente when 1 then QtyMWhAssegnataMGP else 0 end QtyMWhProdMGP,
-- 		case ProgrammatoDalCedente when 0 then QtyMWhAssegnataMGP else 0 end QtyMWhConsMGP,
-- 		ProgrammaOrarioPerUnita.QtyMWh
-- 		FROM 
-- 		ProgrammaOrarioPerUnita, 
-- 		ProgrammaOrario
-- 		where 
-- 		ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
-- 		and ProgrammaOrario.DataProgramma=@DataProgramma
-- 		and ProgrammaOrario.ProgrammaOrarioValidato=1
-- 		and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
-- 		and ProgrammaOrarioPerUnita.IdContratto=ProgrammaOrario.IdContratto
-- 		and ProgrammaOrarioPerUnita.DataProgramma=ProgrammaOrario.DataProgramma
-- 		and ProgrammaOrarioPerUnita.PeriodoRilevante=ProgrammaOrario.PeriodoRilevante
-- 	) POU
-- 	ON  POU.IdContratto = UC.IdContratto
-- 	AND POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	AND POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- 	GROUP BY POU.IdContratto, POU.DataProgramma, POU.PeriodoRilevante
-- ) Q
-- on 
-- PO.IdContratto = Q.IdContratto
-- and PO.DataProgramma = Q.DataProgramma
-- and PO.PeriodoRilevante = Q.PeriodoRilevante
-- order by C.CRN, Q.PeriodoRilevante
-- 
-- RETURN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- CREATE  PROCEDURE dbo.ReportEnergiaSbilancioProgramma
-- 	@DataProgramma as datetime,
-- 	@SogliaSbilMWh as float,
-- 	@CRN as varchar(30)
-- AS
-- 
-- -- e' un report che va in POU --> leggo senza aspettare le modifiche dei programmi
-- set transaction isolation level read uncommitted
-- 
-- 
-- select
-- * 
-- from 
-- tab_SbilanciamentoProgramma (@DataProgramma, @SogliaSbilMWh, @CRN)
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancioProgramma]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancioProgramma]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancioProgramma]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE PROCEDURE dbo.ReportEntitaTaglio
--  	@DataProgramma as datetime
-- AS
-- 
-- -- e' un report che va in PO --> leggo senza aspettare le modifiche dei programmi
-- set transaction isolation level read uncommitted
-- 
-- 
-- --declare @DataProgramma as datetime
-- declare @numore as integer
-- 
-- --set @DataProgramma = '25/11/2004'
-- exec @numore = GetHourNum @DataProgramma
-- 
-- if @numore=23
-- begin
-- 	select
-- 	Q.CRN,
-- 	Q.OperatoreCedente,
-- 	Q.OperatoreAcquirente,
-- 	
-- 	case when Q.P1 =1 then T1  else NULL end T1,
-- 	case when Q.P2 =1 then T2  else NULL end T2,
-- 	case when Q.P3 =1 then T3  else NULL end T3,
-- 	case when Q.P4 =1 then T4  else NULL end T4,
-- 	case when Q.P5 =1 then T5  else NULL end T5,
-- 	case when Q.P6 =1 then T6  else NULL end T6,
-- 	case when Q.P7 =1 then T7  else NULL end T7,
-- 	case when Q.P8 =1 then T8  else NULL end T8,
-- 	case when Q.P9 =1 then T9  else NULL end T9,
-- 	case when Q.P10=1 then T10 else NULL end T10,
-- 	case when Q.P11=1 then T10 else NULL end T11,
-- 	case when Q.P12=1 then T10 else NULL end T12,
-- 	case when Q.P13=1 then T10 else NULL end T13,
-- 	case when Q.P14=1 then T10 else NULL end T14,
-- 	case when Q.P15=1 then T10 else NULL end T15,
-- 	case when Q.P16=1 then T10 else NULL end T16,
-- 	case when Q.P17=1 then T10 else NULL end T17,
-- 	case when Q.P18=1 then T10 else NULL end T18,
-- 	case when Q.P19=1 then T10 else NULL end T19,
-- 	case when Q.P20=1 then T10 else NULL end T20,
-- 	case when Q.P21=1 then T10 else NULL end T21,
-- 	case when Q.P22=1 then T10 else NULL end T22,
-- 	case when Q.P23=1 then T10 else NULL end T23
-- 		
-- 	from
-- 	(
-- 	select
-- 	R.CRN,
-- 	R.OperatoreCedente,
-- 	R.OperatoreAcquirente,
-- 	
-- 	sum(case when R.PeriodoRilevante=  1 then R.ProgrammaPresente else 0 end) P1,
-- 	sum(case when R.PeriodoRilevante=  2 then R.ProgrammaPresente else 0 end) P2,
-- 	sum(case when R.PeriodoRilevante=  3 then R.ProgrammaPresente else 0 end) P3,
-- 	sum(case when R.PeriodoRilevante=  4 then R.ProgrammaPresente else 0 end) P4,
-- 	sum(case when R.PeriodoRilevante=  5 then R.ProgrammaPresente else 0 end) P5,
-- 	sum(case when R.PeriodoRilevante=  6 then R.ProgrammaPresente else 0 end) P6,
-- 	sum(case when R.PeriodoRilevante=  7 then R.ProgrammaPresente else 0 end) P7,
-- 	sum(case when R.PeriodoRilevante=  8 then R.ProgrammaPresente else 0 end) P8,
-- 	sum(case when R.PeriodoRilevante=  9 then R.ProgrammaPresente else 0 end) P9,
-- 	sum(case when R.PeriodoRilevante= 10 then R.ProgrammaPresente else 0 end) P10,
-- 	sum(case when R.PeriodoRilevante= 11 then R.ProgrammaPresente else 0 end) P11,
-- 	sum(case when R.PeriodoRilevante= 12 then R.ProgrammaPresente else 0 end) P12,
-- 	sum(case when R.PeriodoRilevante= 13 then R.ProgrammaPresente else 0 end) P13,
-- 	sum(case when R.PeriodoRilevante= 14 then R.ProgrammaPresente else 0 end) P14,
-- 	sum(case when R.PeriodoRilevante= 15 then R.ProgrammaPresente else 0 end) P15,
-- 	sum(case when R.PeriodoRilevante= 16 then R.ProgrammaPresente else 0 end) P16,
-- 	sum(case when R.PeriodoRilevante= 17 then R.ProgrammaPresente else 0 end) P17,
-- 	sum(case when R.PeriodoRilevante= 18 then R.ProgrammaPresente else 0 end) P18,
-- 	sum(case when R.PeriodoRilevante= 19 then R.ProgrammaPresente else 0 end) P19,
-- 	sum(case when R.PeriodoRilevante= 20 then R.ProgrammaPresente else 0 end) P20,
-- 	sum(case when R.PeriodoRilevante= 21 then R.ProgrammaPresente else 0 end) P21,
-- 	sum(case when R.PeriodoRilevante= 22 then R.ProgrammaPresente else 0 end) P22,
-- 	sum(case when R.PeriodoRilevante= 23 then R.ProgrammaPresente else 0 end) P23,
-- 	
-- 	sum(case when R.PeriodoRilevante= 1 then IsNull(TaglioMWh, 0) else 0 end) T1,
-- 	sum(case when R.PeriodoRilevante= 2 then IsNull(TaglioMWh, 0) else 0 end) T2,
-- 	sum(case when R.PeriodoRilevante= 3 then IsNull(TaglioMWh, 0) else 0 end) T3,
-- 	sum(case when R.PeriodoRilevante= 4 then IsNull(TaglioMWh, 0) else 0 end) T4,
-- 	sum(case when R.PeriodoRilevante= 5 then IsNull(TaglioMWh, 0) else 0 end) T5,
-- 	sum(case when R.PeriodoRilevante= 6 then IsNull(TaglioMWh, 0) else 0 end) T6,
-- 	sum(case when R.PeriodoRilevante= 7 then IsNull(TaglioMWh, 0) else 0 end) T7,
-- 	sum(case when R.PeriodoRilevante= 8 then IsNull(TaglioMWh, 0) else 0 end) T8,
-- 	sum(case when R.PeriodoRilevante= 9 then IsNull(TaglioMWh, 0) else 0 end) T9,
-- 	sum(case when R.PeriodoRilevante=10 then IsNull(TaglioMWh, 0) else 0 end) T10,
-- 	sum(case when R.PeriodoRilevante=11 then IsNull(TaglioMWh, 0) else 0 end) T11,
-- 	sum(case when R.PeriodoRilevante=12 then IsNull(TaglioMWh, 0) else 0 end) T12,
-- 	sum(case when R.PeriodoRilevante=13 then IsNull(TaglioMWh, 0) else 0 end) T13,
-- 	sum(case when R.PeriodoRilevante=14 then IsNull(TaglioMWh, 0) else 0 end) T14,
-- 	sum(case when R.PeriodoRilevante=15 then IsNull(TaglioMWh, 0) else 0 end) T15,
-- 	sum(case when R.PeriodoRilevante=16 then IsNull(TaglioMWh, 0) else 0 end) T16,
-- 	sum(case when R.PeriodoRilevante=17 then IsNull(TaglioMWh, 0) else 0 end) T17,
-- 	sum(case when R.PeriodoRilevante=18 then IsNull(TaglioMWh, 0) else 0 end) T18,
-- 	sum(case when R.PeriodoRilevante=19 then IsNull(TaglioMWh, 0) else 0 end) T19,
-- 	sum(case when R.PeriodoRilevante=20 then IsNull(TaglioMWh, 0) else 0 end) T20,
-- 	sum(case when R.PeriodoRilevante=21 then IsNull(TaglioMWh, 0) else 0 end) T21,
-- 	sum(case when R.PeriodoRilevante=22 then IsNull(TaglioMWh, 0) else 0 end) T22,
-- 	sum(case when R.PeriodoRilevante=23 then IsNull(TaglioMWh, 0) else 0 end) T23
-- 	
-- 	from
-- 	(
-- 	select
-- 	CO.CRN                            CRN,
-- 	CO.CodiceOperatoreSDCCedente      OperatoreCedente,
-- 	CO.CodiceOperatoreSDCAcquirente   OperatoreAcquirente,
-- 	-- CO.GestioneTaglio,
-- 	-- OpAcq.IsGmeOp,
-- 	Ore.Ora                           PeriodoRilevante,
-- 	
-- 	case when PO.IdContratto is NULL then 0 else 1 end ProgrammaPresente,
-- 	
-- 	case OpAcq.IsGmeOp
-- 		when 0 then PO.SbilanciamentoMWhReale
-- 		else
-- 			case sign(PO.SbilanciamentoMWhReale)
-- 				when  0  then 0
-- 				when -1  then -- eccesso di consumo
-- 					case CO.GestioneTaglio
-- 					when 'T' then PO.SbilanciamentoMWhReale
-- 					when 'M' then 0
-- 					when 'C' then PO.SbilanciamentoMWhReale
-- 					when 'P' then 0
-- 					end
-- 				when 1   then -- eccesso di produzione
-- 					case CO.GestioneTaglio
-- 					when 'T' then PO.SbilanciamentoMWhReale
-- 					when 'M' then 0
-- 					when 'C' then 0
-- 					when 'P' then PO.SbilanciamentoMWhReale
-- 					end
-- 				end
-- 		end TaglioMWh
-- 	
-- 	from Contratto CO
-- 	cross join Ore
-- 	inner join Operatori OpAcq
-- 	on CO.CodiceOperatoreSDCAcquirente = OpAcq.CodiceOperatoreSDC
-- 	left outer join ProgrammaOrario PO
-- 	on  PO.IdContratto = CO.IdContratto
-- 	and PO.PeriodoRilevante = Ore.Ora
-- 	and PO.DataProgramma = @DataProgramma
-- 	and PO.ProgrammaOrarioValidato =1
-- 	where
-- 	CO.StatoContratto='Abilitato'
-- 	and CO.DataInizioValidita <= @DataProgramma
-- 	and CO.DataFineValidita >= @DataProgramma
-- 	and CO.TrCN = 1
-- 	and Ore.Ora <= @numore
-- 	) R
-- 	group by 
-- 	R.CRN,
-- 	R.OperatoreCedente,
-- 	R.OperatoreAcquirente
-- 	)
-- 	Q
-- 	order by
-- 	Q.CRN
-- 
-- end
-- else if @numore=24
-- begin
-- 	select
-- 	Q.CRN,
-- 	Q.OperatoreCedente,
-- 	Q.OperatoreAcquirente,
-- 	
-- 	case when Q.P1 =1 then T1  else NULL end T1,
-- 	case when Q.P2 =1 then T2  else NULL end T2,
-- 	case when Q.P3 =1 then T3  else NULL end T3,
-- 	case when Q.P4 =1 then T4  else NULL end T4,
-- 	case when Q.P5 =1 then T5  else NULL end T5,
-- 	case when Q.P6 =1 then T6  else NULL end T6,
-- 	case when Q.P7 =1 then T7  else NULL end T7,
-- 	case when Q.P8 =1 then T8  else NULL end T8,
-- 	case when Q.P9 =1 then T9  else NULL end T9,
-- 	case when Q.P10=1 then T10 else NULL end T10,
-- 	case when Q.P11=1 then T10 else NULL end T11,
-- 	case when Q.P12=1 then T10 else NULL end T12,
-- 	case when Q.P13=1 then T10 else NULL end T13,
-- 	case when Q.P14=1 then T10 else NULL end T14,
-- 	case when Q.P15=1 then T10 else NULL end T15,
-- 	case when Q.P16=1 then T10 else NULL end T16,
-- 	case when Q.P17=1 then T10 else NULL end T17,
-- 	case when Q.P18=1 then T10 else NULL end T18,
-- 	case when Q.P19=1 then T10 else NULL end T19,
-- 	case when Q.P20=1 then T10 else NULL end T20,
-- 	case when Q.P21=1 then T10 else NULL end T21,
-- 	case when Q.P22=1 then T10 else NULL end T22,
-- 	case when Q.P23=1 then T10 else NULL end T23,
-- 	case when Q.P24=1 then T10 else NULL end T24
-- 	
-- 	from
-- 	(
-- 	select
-- 	R.CRN,
-- 	R.OperatoreCedente,
-- 	R.OperatoreAcquirente,
-- 	
-- 	sum(case when R.PeriodoRilevante=  1 then R.ProgrammaPresente else 0 end) P1,
-- 	sum(case when R.PeriodoRilevante=  2 then R.ProgrammaPresente else 0 end) P2,
-- 	sum(case when R.PeriodoRilevante=  3 then R.ProgrammaPresente else 0 end) P3,
-- 	sum(case when R.PeriodoRilevante=  4 then R.ProgrammaPresente else 0 end) P4,
-- 	sum(case when R.PeriodoRilevante=  5 then R.ProgrammaPresente else 0 end) P5,
-- 	sum(case when R.PeriodoRilevante=  6 then R.ProgrammaPresente else 0 end) P6,
-- 	sum(case when R.PeriodoRilevante=  7 then R.ProgrammaPresente else 0 end) P7,
-- 	sum(case when R.PeriodoRilevante=  8 then R.ProgrammaPresente else 0 end) P8,
-- 	sum(case when R.PeriodoRilevante=  9 then R.ProgrammaPresente else 0 end) P9,
-- 	sum(case when R.PeriodoRilevante= 10 then R.ProgrammaPresente else 0 end) P10,
-- 	sum(case when R.PeriodoRilevante= 11 then R.ProgrammaPresente else 0 end) P11,
-- 	sum(case when R.PeriodoRilevante= 12 then R.ProgrammaPresente else 0 end) P12,
-- 	sum(case when R.PeriodoRilevante= 13 then R.ProgrammaPresente else 0 end) P13,
-- 	sum(case when R.PeriodoRilevante= 14 then R.ProgrammaPresente else 0 end) P14,
-- 	sum(case when R.PeriodoRilevante= 15 then R.ProgrammaPresente else 0 end) P15,
-- 	sum(case when R.PeriodoRilevante= 16 then R.ProgrammaPresente else 0 end) P16,
-- 	sum(case when R.PeriodoRilevante= 17 then R.ProgrammaPresente else 0 end) P17,
-- 	sum(case when R.PeriodoRilevante= 18 then R.ProgrammaPresente else 0 end) P18,
-- 	sum(case when R.PeriodoRilevante= 19 then R.ProgrammaPresente else 0 end) P19,
-- 	sum(case when R.PeriodoRilevante= 20 then R.ProgrammaPresente else 0 end) P20,
-- 	sum(case when R.PeriodoRilevante= 21 then R.ProgrammaPresente else 0 end) P21,
-- 	sum(case when R.PeriodoRilevante= 22 then R.ProgrammaPresente else 0 end) P22,
-- 	sum(case when R.PeriodoRilevante= 23 then R.ProgrammaPresente else 0 end) P23,
-- 	sum(case when R.PeriodoRilevante= 24 then R.ProgrammaPresente else 0 end) P24,
-- 	
-- 	sum(case when R.PeriodoRilevante= 1 then IsNull(TaglioMWh, 0) else 0 end) T1,
-- 	sum(case when R.PeriodoRilevante= 2 then IsNull(TaglioMWh, 0) else 0 end) T2,
-- 	sum(case when R.PeriodoRilevante= 3 then IsNull(TaglioMWh, 0) else 0 end) T3,
-- 	sum(case when R.PeriodoRilevante= 4 then IsNull(TaglioMWh, 0) else 0 end) T4,
-- 	sum(case when R.PeriodoRilevante= 5 then IsNull(TaglioMWh, 0) else 0 end) T5,
-- 	sum(case when R.PeriodoRilevante= 6 then IsNull(TaglioMWh, 0) else 0 end) T6,
-- 	sum(case when R.PeriodoRilevante= 7 then IsNull(TaglioMWh, 0) else 0 end) T7,
-- 	sum(case when R.PeriodoRilevante= 8 then IsNull(TaglioMWh, 0) else 0 end) T8,
-- 	sum(case when R.PeriodoRilevante= 9 then IsNull(TaglioMWh, 0) else 0 end) T9,
-- 	sum(case when R.PeriodoRilevante=10 then IsNull(TaglioMWh, 0) else 0 end) T10,
-- 	sum(case when R.PeriodoRilevante=11 then IsNull(TaglioMWh, 0) else 0 end) T11,
-- 	sum(case when R.PeriodoRilevante=12 then IsNull(TaglioMWh, 0) else 0 end) T12,
-- 	sum(case when R.PeriodoRilevante=13 then IsNull(TaglioMWh, 0) else 0 end) T13,
-- 	sum(case when R.PeriodoRilevante=14 then IsNull(TaglioMWh, 0) else 0 end) T14,
-- 	sum(case when R.PeriodoRilevante=15 then IsNull(TaglioMWh, 0) else 0 end) T15,
-- 	sum(case when R.PeriodoRilevante=16 then IsNull(TaglioMWh, 0) else 0 end) T16,
-- 	sum(case when R.PeriodoRilevante=17 then IsNull(TaglioMWh, 0) else 0 end) T17,
-- 	sum(case when R.PeriodoRilevante=18 then IsNull(TaglioMWh, 0) else 0 end) T18,
-- 	sum(case when R.PeriodoRilevante=19 then IsNull(TaglioMWh, 0) else 0 end) T19,
-- 	sum(case when R.PeriodoRilevante=20 then IsNull(TaglioMWh, 0) else 0 end) T20,
-- 	sum(case when R.PeriodoRilevante=21 then IsNull(TaglioMWh, 0) else 0 end) T21,
-- 	sum(case when R.PeriodoRilevante=22 then IsNull(TaglioMWh, 0) else 0 end) T22,
-- 	sum(case when R.PeriodoRilevante=23 then IsNull(TaglioMWh, 0) else 0 end) T23,
-- 	sum(case when R.PeriodoRilevante=24 then IsNull(TaglioMWh, 0) else 0 end) T24
-- 	
-- 	from
-- 	(
-- 	select
-- 	CO.CRN                            CRN,
-- 	CO.CodiceOperatoreSDCCedente      OperatoreCedente,
-- 	CO.CodiceOperatoreSDCAcquirente   OperatoreAcquirente,
-- 	-- CO.GestioneTaglio,
-- 	-- OpAcq.IsGmeOp,
-- 	Ore.Ora                           PeriodoRilevante,
-- 	
-- 	case when PO.IdContratto is NULL then 0 else 1 end ProgrammaPresente,
-- 	
-- 	case OpAcq.IsGmeOp
-- 		when 0 then PO.SbilanciamentoMWhReale
-- 		else
-- 			case sign(PO.SbilanciamentoMWhReale)
-- 				when  0  then 0
-- 				when -1  then -- eccesso di consumo
-- 					case CO.GestioneTaglio
-- 					when 'T' then PO.SbilanciamentoMWhReale
-- 					when 'M' then 0
-- 					when 'C' then PO.SbilanciamentoMWhReale
-- 					when 'P' then 0
-- 					end
-- 				when 1   then -- eccesso di produzione
-- 					case CO.GestioneTaglio
-- 					when 'T' then PO.SbilanciamentoMWhReale
-- 					when 'M' then 0
-- 					when 'C' then 0
-- 					when 'P' then PO.SbilanciamentoMWhReale
-- 					end
-- 				end
-- 		end TaglioMWh
-- 	
-- 	from Contratto CO
-- 	cross join Ore
-- 	inner join Operatori OpAcq
-- 	on CO.CodiceOperatoreSDCAcquirente = OpAcq.CodiceOperatoreSDC
-- 	left outer join ProgrammaOrario PO
-- 	on  PO.IdContratto = CO.IdContratto
-- 	and PO.PeriodoRilevante = Ore.Ora
-- 	and PO.DataProgramma = @DataProgramma
-- 	and PO.ProgrammaOrarioValidato =1
-- 	where
-- 	CO.StatoContratto='Abilitato'
-- 	and CO.DataInizioValidita <= @DataProgramma
-- 	and CO.DataFineValidita >= @DataProgramma
-- 	and CO.TrCN = 1
-- 	and Ore.Ora <= @numore
-- 	) R
-- 	group by 
-- 	R.CRN,
-- 	R.OperatoreCedente,
-- 	R.OperatoreAcquirente
-- 	)
-- 	Q
-- 	order by
-- 	Q.CRN
-- 
-- end
-- else
-- begin
-- 	select
-- 	Q.CRN,
-- 	Q.OperatoreCedente,
-- 	Q.OperatoreAcquirente,
-- 	
-- 	case when Q.P1 =1 then T1  else NULL end T1,
-- 	case when Q.P2 =1 then T2  else NULL end T2,
-- 	case when Q.P3 =1 then T3  else NULL end T3,
-- 	case when Q.P4 =1 then T4  else NULL end T4,
-- 	case when Q.P5 =1 then T5  else NULL end T5,
-- 	case when Q.P6 =1 then T6  else NULL end T6,
-- 	case when Q.P7 =1 then T7  else NULL end T7,
-- 	case when Q.P8 =1 then T8  else NULL end T8,
-- 	case when Q.P9 =1 then T9  else NULL end T9,
-- 	case when Q.P10=1 then T10 else NULL end T10,
-- 	case when Q.P11=1 then T10 else NULL end T11,
-- 	case when Q.P12=1 then T10 else NULL end T12,
-- 	case when Q.P13=1 then T10 else NULL end T13,
-- 	case when Q.P14=1 then T10 else NULL end T14,
-- 	case when Q.P15=1 then T10 else NULL end T15,
-- 	case when Q.P16=1 then T10 else NULL end T16,
-- 	case when Q.P17=1 then T10 else NULL end T17,
-- 	case when Q.P18=1 then T10 else NULL end T18,
-- 	case when Q.P19=1 then T10 else NULL end T19,
-- 	case when Q.P20=1 then T10 else NULL end T20,
-- 	case when Q.P21=1 then T10 else NULL end T21,
-- 	case when Q.P22=1 then T10 else NULL end T22,
-- 	case when Q.P23=1 then T10 else NULL end T23,
-- 	case when Q.P24=1 then T10 else NULL end T24,
-- 	case when Q.P25=1 then T10 else NULL end T25
-- 	
-- 	from
-- 	(
-- 	select
-- 	R.CRN,
-- 	R.OperatoreCedente,
-- 	R.OperatoreAcquirente,
-- 	
-- 	sum(case when R.PeriodoRilevante=  1 then R.ProgrammaPresente else 0 end) P1,
-- 	sum(case when R.PeriodoRilevante=  2 then R.ProgrammaPresente else 0 end) P2,
-- 	sum(case when R.PeriodoRilevante=  3 then R.ProgrammaPresente else 0 end) P3,
-- 	sum(case when R.PeriodoRilevante=  4 then R.ProgrammaPresente else 0 end) P4,
-- 	sum(case when R.PeriodoRilevante=  5 then R.ProgrammaPresente else 0 end) P5,
-- 	sum(case when R.PeriodoRilevante=  6 then R.ProgrammaPresente else 0 end) P6,
-- 	sum(case when R.PeriodoRilevante=  7 then R.ProgrammaPresente else 0 end) P7,
-- 	sum(case when R.PeriodoRilevante=  8 then R.ProgrammaPresente else 0 end) P8,
-- 	sum(case when R.PeriodoRilevante=  9 then R.ProgrammaPresente else 0 end) P9,
-- 	sum(case when R.PeriodoRilevante= 10 then R.ProgrammaPresente else 0 end) P10,
-- 	sum(case when R.PeriodoRilevante= 11 then R.ProgrammaPresente else 0 end) P11,
-- 	sum(case when R.PeriodoRilevante= 12 then R.ProgrammaPresente else 0 end) P12,
-- 	sum(case when R.PeriodoRilevante= 13 then R.ProgrammaPresente else 0 end) P13,
-- 	sum(case when R.PeriodoRilevante= 14 then R.ProgrammaPresente else 0 end) P14,
-- 	sum(case when R.PeriodoRilevante= 15 then R.ProgrammaPresente else 0 end) P15,
-- 	sum(case when R.PeriodoRilevante= 16 then R.ProgrammaPresente else 0 end) P16,
-- 	sum(case when R.PeriodoRilevante= 17 then R.ProgrammaPresente else 0 end) P17,
-- 	sum(case when R.PeriodoRilevante= 18 then R.ProgrammaPresente else 0 end) P18,
-- 	sum(case when R.PeriodoRilevante= 19 then R.ProgrammaPresente else 0 end) P19,
-- 	sum(case when R.PeriodoRilevante= 20 then R.ProgrammaPresente else 0 end) P20,
-- 	sum(case when R.PeriodoRilevante= 21 then R.ProgrammaPresente else 0 end) P21,
-- 	sum(case when R.PeriodoRilevante= 22 then R.ProgrammaPresente else 0 end) P22,
-- 	sum(case when R.PeriodoRilevante= 23 then R.ProgrammaPresente else 0 end) P23,
-- 	sum(case when R.PeriodoRilevante= 24 then R.ProgrammaPresente else 0 end) P24,
-- 	sum(case when R.PeriodoRilevante= 25 then R.ProgrammaPresente else 0 end) P25,
-- 	
-- 	sum(case when R.PeriodoRilevante= 1 then IsNull(TaglioMWh, 0) else 0 end) T1,
-- 	sum(case when R.PeriodoRilevante= 2 then IsNull(TaglioMWh, 0) else 0 end) T2,
-- 	sum(case when R.PeriodoRilevante= 3 then IsNull(TaglioMWh, 0) else 0 end) T3,
-- 	sum(case when R.PeriodoRilevante= 4 then IsNull(TaglioMWh, 0) else 0 end) T4,
-- 	sum(case when R.PeriodoRilevante= 5 then IsNull(TaglioMWh, 0) else 0 end) T5,
-- 	sum(case when R.PeriodoRilevante= 6 then IsNull(TaglioMWh, 0) else 0 end) T6,
-- 	sum(case when R.PeriodoRilevante= 7 then IsNull(TaglioMWh, 0) else 0 end) T7,
-- 	sum(case when R.PeriodoRilevante= 8 then IsNull(TaglioMWh, 0) else 0 end) T8,
-- 	sum(case when R.PeriodoRilevante= 9 then IsNull(TaglioMWh, 0) else 0 end) T9,
-- 	sum(case when R.PeriodoRilevante=10 then IsNull(TaglioMWh, 0) else 0 end) T10,
-- 	sum(case when R.PeriodoRilevante=11 then IsNull(TaglioMWh, 0) else 0 end) T11,
-- 	sum(case when R.PeriodoRilevante=12 then IsNull(TaglioMWh, 0) else 0 end) T12,
-- 	sum(case when R.PeriodoRilevante=13 then IsNull(TaglioMWh, 0) else 0 end) T13,
-- 	sum(case when R.PeriodoRilevante=14 then IsNull(TaglioMWh, 0) else 0 end) T14,
-- 	sum(case when R.PeriodoRilevante=15 then IsNull(TaglioMWh, 0) else 0 end) T15,
-- 	sum(case when R.PeriodoRilevante=16 then IsNull(TaglioMWh, 0) else 0 end) T16,
-- 	sum(case when R.PeriodoRilevante=17 then IsNull(TaglioMWh, 0) else 0 end) T17,
-- 	sum(case when R.PeriodoRilevante=18 then IsNull(TaglioMWh, 0) else 0 end) T18,
-- 	sum(case when R.PeriodoRilevante=19 then IsNull(TaglioMWh, 0) else 0 end) T19,
-- 	sum(case when R.PeriodoRilevante=20 then IsNull(TaglioMWh, 0) else 0 end) T20,
-- 	sum(case when R.PeriodoRilevante=21 then IsNull(TaglioMWh, 0) else 0 end) T21,
-- 	sum(case when R.PeriodoRilevante=22 then IsNull(TaglioMWh, 0) else 0 end) T22,
-- 	sum(case when R.PeriodoRilevante=23 then IsNull(TaglioMWh, 0) else 0 end) T23,
-- 	sum(case when R.PeriodoRilevante=24 then IsNull(TaglioMWh, 0) else 0 end) T24,
-- 	sum(case when R.PeriodoRilevante=25 then IsNull(TaglioMWh, 0) else 0 end) T25
-- 	
-- 	from
-- 	(
-- 	select
-- 	CO.CRN                            CRN,
-- 	CO.CodiceOperatoreSDCCedente      OperatoreCedente,
-- 	CO.CodiceOperatoreSDCAcquirente   OperatoreAcquirente,
-- 	-- CO.GestioneTaglio,
-- 	-- OpAcq.IsGmeOp,
-- 	Ore.Ora                           PeriodoRilevante,
-- 	
-- 	case when PO.IdContratto is NULL then 0 else 1 end ProgrammaPresente,
-- 	
-- 	case OpAcq.IsGmeOp
-- 		when 0 then PO.SbilanciamentoMWhReale
-- 		else
-- 			case sign(PO.SbilanciamentoMWhReale)
-- 				when  0  then 0
-- 				when -1  then -- eccesso di consumo
-- 					case CO.GestioneTaglio
-- 					when 'T' then PO.SbilanciamentoMWhReale
-- 					when 'M' then 0
-- 					when 'C' then PO.SbilanciamentoMWhReale
-- 					when 'P' then 0
-- 					end
-- 				when 1   then -- eccesso di produzione
-- 					case CO.GestioneTaglio
-- 					when 'T' then PO.SbilanciamentoMWhReale
-- 					when 'M' then 0
-- 					when 'C' then 0
-- 					when 'P' then PO.SbilanciamentoMWhReale
-- 					end
-- 				end
-- 		end TaglioMWh
-- 	
-- 	from Contratto CO
-- 	cross join Ore
-- 	inner join Operatori OpAcq
-- 	on CO.CodiceOperatoreSDCAcquirente = OpAcq.CodiceOperatoreSDC
-- 	left outer join ProgrammaOrario PO
-- 	on  PO.IdContratto = CO.IdContratto
-- 	and PO.PeriodoRilevante = Ore.Ora
-- 	and PO.DataProgramma = @DataProgramma
-- 	and PO.ProgrammaOrarioValidato =1
-- 	where
-- 	CO.StatoContratto='Abilitato'
-- 	and CO.DataInizioValidita <= @DataProgramma
-- 	and CO.DataFineValidita >= @DataProgramma
-- 	and CO.TrCN = 1
-- 	and Ore.Ora <= @numore
-- 	) R
-- 	group by 
-- 	R.CRN,
-- 	R.OperatoreCedente,
-- 	R.OperatoreAcquirente
-- 	)
-- 	Q
-- 	order by
-- 	Q.CRN
-- 
-- end
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEntitaTaglio]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEntitaTaglio]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportEntitaTaglio]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- CREATE     PROCEDURE dbo.ReportSbilanciamentoOrario
-- 	(
-- 		@DataProgramma datetime,
-- 		@SogliaSbilMWh as float = 0.0
-- 	)
-- 
-- AS
-- 
-- -- e' un report che va in POU --> leggo senza aspettare le modifiche dei programmi
-- set transaction isolation level read uncommitted
-- 
-- select @DataProgramma DataProgramma,
-- C.CRN,
-- C.CodiceContratto,
-- C.CodiceOperatoreSDCCedente Cedente,
-- C.CodiceOperatoreSDCAcquirente Acquirente,
-- Q.PeriodoRilevante Ora,
-- Q.Bilanciato Bilanciato,
-- --Q.OutQtyMWh,
-- Q.BilMWh SbilanciamentoMWh,
-- Q.QtyProdMWh,
-- Q.QtyConsMWh
-- from ProgrammaOrario PO 
-- inner join Contratto C
-- on PO.IdContratto = C.IdContratto
-- inner join
-- (
-- 	select 
-- 	POU.IdContratto, 
-- 	@DataProgramma DataProgramma, 
-- 	POU.PeriodoRilevante,
-- 	cast(sum(POU.QtyProdMWh) as decimal(12,3)) QtyProdMWh,
-- 	cast(sum(POU.QtyConsMWh) as decimal(12,3)) QtyConsMWh,
-- 
-- 	Abs(Sum(POU.QtyMWh * UC.KP / UC.KU)) OutQtyMWh,
-- 
-- 	case      when cast(Abs(Sum(POU.QtyMWh * UC.KP / UC.KU)) as decimal(12,3)) > @SogliaSbilMWh then 0                                        else 1 end Bilanciato,
-- 	cast(case when cast(Abs(Sum(POU.QtyMWh * UC.KP / UC.KU)) as decimal(12,3)) > @SogliaSbilMWh then 
--                            Sum(POU.QtyMWh * UC.KP / UC.KU) else 0 end as decimal(12,3)) BilMWh
-- -- 	case      when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then 0                                        else 1 end Bilanciato,
-- -- 	cast(case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then 
-- --                            Sum(round(POU.QtyMWh * UC.KP / UC.KU, 3)) else 0 end as decimal(12,3))  BilMWh
-- 	from 
-- 	(
-- 		-- trovo tutte le unita per contratto valide 
-- 		-- (TrCC e TrUC garantiscono che il contratto sia valido, le unita valide, gli operatori validi)
-- 		select 
-- 		UnitaContratto.IdContratto, 
-- 		UnitaContratto.CodiceUnitaSDC, 
-- 		UnitaContratto.CategoriaUnitaSDC,
-- 		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
-- 		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
-- 		from 
-- 		tab_UnitaContratto(@DataProgramma) UnitaContratto, 
-- 		SDC_Unita, SDC_PuntiDiScambioRilevanti,
-- 		Contratto
-- 		where 
-- 		Contratto.IdContratto = UnitaContratto.IdContratto
-- 		and Contratto.DataInizioValidita <= @DataProgramma
-- 		and Contratto.DataFineValidita >= @DataProgramma
-- 		and UnitaContratto.TrCC=1 
-- 		and UnitaContratto.TrUC=1
-- 		and UnitaContratto.UnitaDelContrattoValidata=1
-- 		and UnitaContratto.DataInizioValidita <= @DataProgramma
-- 		and UnitaContratto.DataFineValidita >= @DataProgramma
-- 		and UnitaContratto.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
-- 		and UnitaContratto.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
-- 		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- 	) UC
-- 	inner join
-- 	(
-- 		-- considero i POU validi del giorno
-- 		SELECT 
-- 		ProgrammaOrarioPerUnita.IdContratto, 
-- 		ProgrammaOrarioPerUnita.DataProgramma, 
-- 		ProgrammaOrarioPerUnita.PeriodoRilevante, 
-- 		ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
-- 		ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
-- 		case ProgrammaOrarioPerUnita.ProgrammatoDalCedente 
-- 		when 1 then ProgrammaOrarioPerUnita.QtyMWh 
-- 		else 0 
-- 		end QtyProdMWh,
-- 		case ProgrammaOrarioPerUnita.ProgrammatoDalCedente 
-- 		when 0 then ProgrammaOrarioPerUnita.QtyMWh 
-- 		else 0 
-- 		end QtyConsMWh,
-- 		ProgrammaOrarioPerUnita.QtyMWh
-- 		FROM 
-- 		ProgrammaOrarioPerUnita, 
-- 		ProgrammaOrario
-- 		where 
-- 		ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
-- 		and ProgrammaOrario.DataProgramma=@DataProgramma
-- 		and ProgrammaOrario.ProgrammaOrarioValidato=1
-- 		and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
-- 		and ProgrammaOrarioPerUnita.IdContratto=ProgrammaOrario.IdContratto
-- 		and ProgrammaOrarioPerUnita.DataProgramma=ProgrammaOrario.DataProgramma
-- 		and ProgrammaOrarioPerUnita.PeriodoRilevante=ProgrammaOrario.PeriodoRilevante
-- 	) POU
-- 	ON  POU.IdContratto = UC.IdContratto
-- 	AND POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	AND POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- 	GROUP BY POU.IdContratto, POU.DataProgramma, POU.PeriodoRilevante
-- ) Q
-- on 
-- PO.IdContratto = Q.IdContratto
-- and PO.DataProgramma = Q.DataProgramma
-- and PO.PeriodoRilevante = Q.PeriodoRilevante
-- ORDER BY 
-- C.CodiceContratto,
-- Q.PeriodoRilevante
-- 
-- RETURN
-- 
-- 
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportSbilanciamentoOrario]  TO [public]
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportSbilanciamentoOrario]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportSbilanciamentoOrario]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[ReportSbilanciamentoOrario]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE PROCEDURE [dbo].[spBilAddOperatori] 
-- AS
-- 
-- set nocount off;
-- 
-- insert into operatori (CodiceOperatoreSDC, StatoBilateraliOperatore, TSModifica, Amministratore)
-- select CodiceOperatoreSDC, 1 StatoBilateraliOperatore, getdate() TSModifica, 0 Amministratore
-- from sdc_operatori s
-- where not exists (select * from operatori o
-- 	where s.CodiceOperatoreSDC = o.CodiceOperatoreSDC)
--             and s.Abilitato = 1
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddOperatori]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddOperatori]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddOperatori]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE PROCEDURE [dbo].[spBilAddOperatoriFiltrati] 
-- @CodiceOperatoreSDC as varchar(16),
-- @Abilitazione as varchar(1),
-- @RagioneSociale as varchar(256)
-- AS
-- 
-- set nocount off;
-- 
-- if @CodiceOperatoreSDC is null and @Abilitazione is null and @RagioneSociale is null 
-- begin
-- 	insert into operatori (CodiceOperatoreSDC, StatoBilateraliOperatore, TSModifica, Amministratore)
-- 	select CodiceOperatoreSDC, 1 StatoBilateraliOperatore, getdate() TSModifica, 0 Amministratore
-- 	from sdc_operatori s
-- 	where not exists (select * from operatori o
-- 		where s.CodiceOperatoreSDC = o.CodiceOperatoreSDC)
-- 		and s.Abilitato = 1
-- 	return
-- end  
-- 
-- declare @SQLString1 nvarchar(1024),
-- 	@SQLString2 nvarchar(1024),
-- 	@WCString nvarchar(1024),
-- 	@Abilitato bit
-- 
-- /* Set column list. CHAR(13) is a carriage return, line feed.*/
-- set @SQLString2 = N'SELECT * ' + char(13)
-- /* Set FROM clause with carriage return, line feed. */
-- set @SQLString2 = @SQLString2 + N'FROM SDC_OPERATORI' + char(13)
-- 
-- -- CODICE OPERATORE
-- if not @CodiceOperatoreSDC is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + N'CodiceOperatoreSDC LIKE ''' + @CodiceOperatoreSDC + N'%'''
-- end 
-- 
-- -- ABILITATO
-- if not @Abilitazione is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + N'Abilitato = @Abilitato'
-- 	if @Abilitazione = '1'
-- 		set @Abilitato = 1
-- 	else
-- 		set @Abilitato = 0 	-- non aggiunge niente perche` si prendono sempre e solo gli operatori abilitati,
-- 					-- non si possono aggiungere a Utenti gli utenti SDC disabilitati
-- end 
-- 
-- --RAGIONE SOCIALE
-- if not @RagioneSociale is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + 'RagioneSociale LIKE ''' + @RagioneSociale + '%'''
-- end 
-- 
-- set @SQLString2 = @SQLString2 +'  WHERE Abilitato = 1 AND '
-- if len(@WCString) > 0 
-- 	set @SQLString2 = @SQLString2 + @WCString  + char(13)
-- 	
-- --print @WCString
-- --print @SQLString2
-- set @SQLString1 = N'insert into operatori (CodiceOperatoreSDC, StatoBilateraliOperatore, TSModifica, Amministratore)' + char(13)
-- set @SQLString1 = @SQLString1 + N'select CodiceOperatoreSDC, 1 StatoBilateraliOperatore, getdate() TSModifica, 0 Amministratore' + char(13)
-- set @SQLString1 = @SQLString1 + N'from (' + @SQLString2 + ')  s' + char(13)
-- set @SQLString1 = @SQLString1 + N'where not exists (select * from operatori o' + char(13)
-- set @SQLString1 = @SQLString1 + N'where s.CodiceOperatoreSDC = o.CodiceOperatoreSDC)' + char(13)
-- 
-- -- ABILITATO
-- if not @Abilitazione is null
-- begin
-- 	exec sp_executesql @SQLString1,
-- 		N'@Abilitato bit',
-- 	       	@Abilitato = @Abilitato
-- 	--print @SQLString1
-- 	--print @Abilitato
-- end 
-- else
-- begin
-- 	exec sp_executesql @SQLString1
-- 	--print @SQLString1
-- end
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddOperatoriFiltrati]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddOperatoriFiltrati]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddOperatoriFiltrati]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE PROCEDURE [dbo].[spBilAddUnita] 
-- AS
-- 
-- set nocount off;
-- 
-- insert into unita (CodiceUnitaSDC, CategoriaUnitaSDC, StatoBilateraliUnita, TSModifica)
-- select CodiceUnitaSDC, CategoriaUnitaSDC, 1 StatoBilateraliUnita, getdate() TSModifica
-- from sdc_unita s
-- where not exists (select * from unita u
-- 	where s.CodiceUnitaSDC = u.CodiceUnitaSDC and s.CategoriaUnitaSDC = u.CategoriaUnitaSDC)
-- 	and s.Abilitata = 1
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUnita]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUnita]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUnita]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE PROCEDURE [dbo].[spBilAddUnitaFiltrate] 
-- @CodiceUnitaSDC as varchar(16),
-- @NomeUnita as varchar(256),
-- @CodicePuntoDiScambioRilevanteSDC as varchar(16),
-- @CodiceOperatoreDiRiferimentoSDC as varchar(16),
-- @CodiceZonaSDC as varchar(10),
-- @TipoUnita as char(1)
-- AS
-- 
-- set nocount off;
-- 
-- if @CodiceUnitaSDC is null and @NomeUnita is null and @CodicePuntoDiScambioRilevanteSDC is null and @CodiceOperatoreDiRiferimentoSDC is null and @CodiceZonaSDC is null and @TipoUnita is null 
-- begin
-- 	insert into unita (CodiceUnitaSDC, CategoriaUnitaSDC, StatoBilateraliUnita, TSModifica)
-- 	select CodiceUnitaSDC, CategoriaUnitaSDC, 1 StatoBilateraliUnita, getdate() TSModifica
-- 	from sdc_unita s
-- 	where not exists (select * from unita u
-- 		where s.CodiceUnitaSDC = u.CodiceUnitaSDC and s.CategoriaUnitaSDC = u.CategoriaUnitaSDC)
-- 		and s.Abilitata = 1
-- 	return
-- end  
-- 
-- declare @SQLString1 nvarchar(1024),
-- 	@SQLString2 nvarchar(1024),
-- 	@WCString nvarchar(1024)
-- 
-- /* Set column list. CHAR(13) is a carriage return, line feed.*/
-- set @SQLString2 = N'SELECT  U.*, CodiceZonaSDC ' + char(13)
-- /* Set FROM clause with carriage return, line feed. */
-- set @SQLString2 = @SQLString2 + N'FROM SDC_UNITA U, SDC_PUNTIDISCAMBIORILEVANTI P' + char(13)
-- set @SQLString2 = @SQLString2 + N'WHERE U.Abilitata = 1 AND U.CodicePuntoDiScambioRilevanteSDC = P.CodicePuntoDiScambioRilevanteSDC '
-- 
-- -- CODICE UNITA
-- if not @CodiceUnitaSDC is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + N'U.CodiceUnitaSDC LIKE ''' + @CodiceUnitaSDC + N'%'''
-- end 
-- 
-- -- NOME UNITA
-- if not @NomeUnita is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + 'U.NomeUnita LIKE ''' + @NomeUnita + '%'''
-- end 
-- --PUNTO DI SCAMBIO RILEVANTE
-- if not @CodicePuntoDiScambioRilevanteSDC is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + 'U.CodicePuntoDiScambioRilevanteSDC LIKE ''' + @CodicePuntoDiScambioRilevanteSDC + ''''
-- end 
-- -- OPERATORE RESPONSABILE UNITA
-- if not @CodiceOperatoreDiRiferimentoSDC is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + 'U.CodiceOperatoreDiRiferimentoSDC LIKE ''' + @CodiceOperatoreDiRiferimentoSDC + '%'''
-- end 
-- --ZONA
-- if not @CodiceZonaSDC is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + 'P.CodiceZonaSDC LIKE ''' + @CodiceZonaSDC + '%''' -- la colonna proviene da SDC_PuntiDiScambioRilevante
-- end 
-- --TIPO UNITA
-- if not @TipoUnita is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + 'U.TipoUnita LIKE ''' + @TipoUnita + '%'''
-- end 
-- 
-- if len(@WCString) > 0 
-- 	--set @SQLString2 = @SQLString2 +'  WHERE ' + @WCString  + char(13)
-- 	set @SQLString2 = @SQLString2 + ' AND ' + @WCString  + char(13)
-- 
-- set @SQLString1 = N'insert into unita (CodiceUnitaSDC, CategoriaUnitaSDC, StatoBilateraliUnita, TSModifica)' + char(13)
-- set @SQLString1 = @SQLString1 + N'select CodiceUnitaSDC, CategoriaUnitaSDC, 1 StatoBilateraliUnita, getdate() TSModifica' + char(13)
-- set @SQLString1 = @SQLString1 + N'from (' + @SQLString2 + ')  s' + char(13)
-- set @SQLString1 = @SQLString1 + N'where not exists (select * from unita u' + char(13)
-- set @SQLString1 = @SQLString1 + N'where s.CodiceUnitaSDC = u.CodiceUnitaSDC and s.CategoriaUnitaSDC = u.CategoriaUnitaSDC)' + char(13)
-- 
-- --print @SQLString1
-- exec sp_executesql @SQLString1
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUnitaFiltrate]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUnitaFiltrate]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUnitaFiltrate]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE PROCEDURE [dbo].[spBilAddUtentiFiltrati] 
-- @CodiceUtenteSDC as varchar(16),
-- @Cognome as varchar(256),
-- @Abilitazione as varchar(1)
-- AS
-- 
-- set nocount off;
-- 
-- if @CodiceUtenteSDC is null and @Cognome is null and @Abilitazione is null  
-- begin
-- 	insert into utenti (CodiceUtenteSDC, StatoBilateraliUtente, TSModifica)
-- 	select CodiceUtenteSDC, 1 StatoBilateraliUtente, getdate() TSModifica
-- 	from sdc_utenti s
-- 	where not exists (select * from utenti u
-- 		where s.CodiceUtenteSDC = u.CodiceUtenteSDC)
-- 	and s.Abilitato = 0
-- 	return
-- 
-- end  
-- 
-- declare @SQLString1 nvarchar(1024),
-- 	@SQLString2 nvarchar(1024),
-- 	@WCString nvarchar(1024),
-- 	@Abilitato bit
-- 
-- /* Set column list. CHAR(13) is a carriage return, line feed.*/
-- set @SQLString2 = N'SELECT * ' + char(13)
-- /* Set FROM clause with carriage return, line feed. */
-- set @SQLString2 = @SQLString2 + N'FROM SDC_UTENTI' + char(13)
-- 
-- -- CODICE UTENTE
-- if not @CodiceUtenteSDC is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + N'CodiceUtenteSDC LIKE ''' + @CodiceUtenteSDC + N'%'''
-- end 
-- 
-- -- ABILITATO
-- if not @Abilitazione is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + N'Abilitato = @Abilitato'
-- 	if @Abilitazione = '1'
-- 		set @Abilitato = 1
-- 	else
-- 		set @Abilitato = 0
-- end 
-- 
-- --RAGIONE SOCIALE
-- if not @Cognome is null
-- begin
-- 	if len(@WCString) > 0 
-- 		set @WCString = @WCString + N' AND '
-- 	else
-- 		set @WCString = ''
-- 		
-- 	set @WCString = @WCString + 'Cognome LIKE ''' + @Cognome + '%'''
-- end 
-- 
-- set @SQLString2 = @SQLString2 +'  WHERE Abilitato = 1 AND '
-- if len(@WCString) > 0 
-- 	set @SQLString2 = @SQLString2 + @WCString  + char(13)
-- --print @WCString
-- --print @SQLString2
-- set @SQLString1 = N'insert into utenti (CodiceUtenteSDC, StatoBilateraliUtente, TSModifica)' + char(13)
-- set @SQLString1 = @SQLString1 + N'select CodiceUtenteSDC, 1 StatoBilateraliUtente, getdate() TSModifica' + char(13)
-- set @SQLString1 = @SQLString1 + N'from (' + @SQLString2 + ')  s' + char(13)
-- set @SQLString1 = @SQLString1 + N'where not exists (select * from utenti u' + char(13)
-- set @SQLString1 = @SQLString1 + N'where s.CodiceUtenteSDC = u.CodiceUtenteSDC)' + char(13)
-- 
-- -- ABILITATO
-- if not @Abilitazione is null
-- begin
-- 	exec sp_executesql @SQLString1,
-- 		N'@Abilitato bit',
-- 	       	@Abilitato = @Abilitato
-- 	--print @SQLString1
-- 	--print @Abilitato
-- end 
-- else
-- begin
-- 	exec sp_executesql @SQLString1
-- 	--print @SQLString1
-- end
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUtentiFiltrati]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUtentiFiltrati]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilAddUtentiFiltrati]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- CREATE  PROCEDURE [dbo].[spBilGeneraBus]
-- 	@DataProgramma 	smalldatetime,
-- 	@CodiceOperatoreSDC varchar(16)
-- AS
-- 
-- -- Questa SP riporta i dati per il report BUS --> meglio farla 
-- -- lavorare con dati sicuri --> niente Read Uncommitted
-- 
-- 
-- -- declare	
-- -- 	@DataProgramma 	smalldatetime,
-- -- 	@CodiceOperatoreSDC varchar(16)
-- -- 
-- -- set @DataProgramma = '1/12/2004'
-- -- set @CodiceOperatoreSDC = 'IDGRTNCO'
-- 
-- -- La query e` diretta su POU senza tante complicazioni
-- -- tipo la validita dele contratto, abilitazioni ecc.
-- -- perche' se la QtyMWhAssegnataMGP e' valorizzata significa che
-- -- al momento dell'esecuzione del mercato quella programmazione era
-- -- valida --> il BUS deve essere generato
-- SELECT 
-- SUM(POU.QtyMWhAssegnataMGP) as QtyMWhAssegnataMGP,
-- POU.PeriodoRilevante as PeriodoRilevante,
-- POU.CodiceUnitaSDC as CodiceUnitaSDC
-- from
-- ProgrammaOrarioPerUnita POU
-- inner join Contratto CO
-- on
-- CO.IdContratto = POU.IdContratto
-- where
-- POU.QtyMWhAssegnataMGP is not null
-- and POU.DataProgramma = @DataProgramma
-- and
-- (
-- 	(POU.ProgrammatoDalCedente = 1 AND CO.CodiceOperatoreSDCCedente = @CodiceOperatoreSDC) 
-- 	or 
-- 	(POU.ProgrammatoDalCedente = 0 AND CO.CodiceOperatoreSDCAcquirente = @CodiceOperatoreSDC) 
-- )
-- GROUP BY 
-- POU.CodiceUnitaSDC, 
-- POU.PeriodoRilevante 
-- ORDER BY 
-- POU.CodiceUnitaSDC, 
-- POU.PeriodoRilevante
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGeneraBus]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGeneraBus]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGeneraBus]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE PROCEDURE [dbo].[spBilGetContrattoByID] 
-- @Id as int
-- AS
-- 
-- 
-- set nocount off;
-- declare @Q as nvarchar(4000),
-- 	@di as datetime,
-- 	@df as datetime
-- 
-- set @df = null
-- set @di = null
-- 
-- set @Q = ''
-- set @Q = @Q +  
-- 'SELECT     C.*, 
-- T.IdContratto, ISNULL(T.TotaleUnita, 0) AS TotaleUnitaContratto, 
-- ISNULL(T.TotaleUnita, 0) AS UnitaContrattoValidate
-- FROM         
-- (
-- SELECT     *
-- FROM          dbo.Bil_ContrattoOperatore
-- WHERE      dbo.Bil_ContrattoOperatore.IdContratto = @IdContratto
-- AND (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
-- (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita))
-- ) C LEFT OUTER JOIN
-- (
-- SELECT     IdContratto, COUNT(*) TotaleUnita
-- FROM          
-- (SELECT     
-- IdContratto, 
-- CodiceUnitaSDC, 
-- CategoriaUnitaSDC, 
-- TrCC, 
-- TrUC, 
-- VUC, 
-- SUM(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente, 
-- SUM(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
-- FROM          
-- (SELECT     
-- c.IdContratto, 
-- ur.CodiceUnitaSDC, 
-- ur.CategoriaUnitaSDC, 
-- ur.TrUC, 
-- ur.VUC, 
-- 1 UnitaAssegnataOpCedente, 
-- 0 UnitaAssegnataOpAcquirente, 
-- c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
-- FROM unitrelate ur 
-- INNER JOIN
-- contratto c 
-- ON c.IdContratto = @IdContratto
-- AND c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
-- AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
-- AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente AND ur.TipoUnita IN (''P'', ''M'') 
-- AND (ur.DataInizioValidita <= c.DataFineValidita AND ur.DataFineValidita >= c.DataInizioValidita)
-- AND ur.Abilitata = 1 
-- UNION
-- SELECT     
-- c.IdContratto, 
-- ur.CodiceUnitaSDC, 
-- ur.CategoriaUnitaSDC, 
-- ur.TrUC, 
-- ur.VUC, 
-- 0 UnitaAssegnataOpCedente, 
-- 1 UnitaAssegnataOpAcquirente, 
-- c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
-- FROM         
-- unitrelate ur 
-- INNER JOIN
-- contratto c 
-- ON c.IdContratto = @IdContratto
-- AND c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
-- AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
-- AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente AND ur.TipoUnita IN (''C'', ''M'') 
-- AND (ur.DataInizioValidita <= c.DataFineValidita AND ur.DataFineValidita >= c.DataInizioValidita)
-- AND ur.Abilitata = 1 
-- ) w
-- GROUP BY IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC, TrUC, VUC, TrCC) Q
-- GROUP BY IdContratto) T ON C.IdContratto = T.IdContratto
-- WHERE     (1 = 1)'
-- 
-- exec sp_executesql @Q,
-- 	N'@IdContratto int, @di datetime, @df datetime',
--   	@IdContratto = @id,
-- 	@di = @di,
-- 	@df = @df
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetContrattoByID]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetContrattoByID]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetContrattoByID]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE PROCEDURE [dbo].[spBilGetDettagliProgrammazioneOraria]
-- 	@IdContratto int,
-- 	@PeriodoRilevante tinyint,
-- 	@DataProgramma smalldatetime
-- 
-- AS
-- 
-- -- qui non si usa read uncommitted per evitare di fargli leggere dati incompleti
-- 
-- -- Codice utile per provare la query nell'SQL Analyzer
-- --declare @IdContratto int,
-- --	@PeriodoRilevante tinyint,
-- --	@DataProgramma smalldatetime
-- 
-- --set @IdContratto = 13
-- --set @PeriodoRilevante = 1
-- --set @DataProgramma = '04/20/2004'
-- 
-- SELECT POU2.CodiceUnitaSDC,
-- 	POU2.CategoriaUnitaSDC,
-- 	POU2.NomeUnita,
-- 	POU2.QtyMWh,
-- 	POU2.QtyMWhBilanciamento,
-- 	POU2.QtyMWhAssegnataMGP,
-- 	PSR.CoefficienteDiPerdita PSRPerdita,
-- 	POU2.CoefficientePerdita UnitaPerdita,
-- 	POU2.ProgOrarioDellUnitaValidato
-- FROM SDC_PuntiDiScambioRilevanti PSR
-- INNER JOIN
-- (
-- 	SELECT Unita.CoefficientePerdita,
-- 		Unita.CodiceUnitaSDC,
-- 		Unita.CategoriaUnitaSDC,
-- 		Unita.NomeUnita,
-- 		Unita.CodicePuntoDiScambioRilevanteSDC,
-- 		POU.QtyMWh,
-- 		POU.QtyMWhBilanciamento,
-- 		POU.QtyMWhAssegnataMGP,
-- 		POU.ProgOrarioDellUnitaValidato
-- 	FROM
-- 	(
-- 	-- Prelevo tutte le unita del contratto valide ed abilitate
-- 	SELECT SDC_Unita.CoefficientePerdita,
-- 		SDC_Unita.CodiceUnitaSDC,
-- 		SDC_Unita.CategoriaUnitaSDC,
-- 		SDC_Unita.NomeUnita,
-- 		SDC_Unita.CodicePuntoDiScambioRilevanteSDC
-- 	FROM SDC_Unita 
-- 	INNER JOIN 
-- 		(
-- 		-- Prelevo tutte le unita del contratto che debbono essere programmate (sono piu` delle unita`  valide ed abilitate)
-- 		SELECT CodiceUnitaSDC,
-- 			CategoriaUnitaSDC
-- 		FROM tab_UnitaContratto2(@DataProgramma, @IdContratto) UnitaContratto
-- 		WHERE IdContratto = @IdContratto
-- 		AND UnitaDelContrattoValidata = 1
-- 		AND TrCC = 1
-- 		AND TrUC = 1
-- 		AND UnitaContratto.DataInizioValidita <= @DataProgramma
-- 		AND UnitaContratto.DataFineValidita >= @DataProgramma
-- 		) UC
-- 		
-- 	ON SDC_Unita.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	AND SDC_Unita.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- 	) Unita
-- 	INNER JOIN
-- 	(
-- 		SELECT CodiceUnitaSDC,
-- 			CategoriaUnitaSDC,
-- 			QtyMWh,
-- 			QtyMWhBilanciamento,
-- 			QtyMWhAssegnataMGP,
-- 			ProgOrarioDellUnitaValidato
-- 		FROM ProgrammaOrarioPerUnita
-- 		WHERE DataProgramma = @DataProgramma AND
-- 			PeriodoRilevante = @PeriodoRilevante AND
-- 			IdContratto = @IdContratto
-- 			
-- 	) POU
-- 	ON POU.CodiceUnitaSDC = Unita.CodiceUnitaSDC
-- 	AND POU.CategoriaUnitaSDC = Unita.CategoriaUnitaSDC
-- ) POU2
-- ON PSR.CodicePuntoDiScambioRilevanteSDC = POU2.CodicePuntoDiScambioRilevanteSDC
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOraria]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOraria]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOraria]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE PROCEDURE [dbo].[spBilGetDettagliProgrammazioneOrariaClient]
-- 	@IdContratto int,
-- 	@PeriodoRilevante tinyint,
-- 	@DataProgramma smalldatetime,
-- 	@Operatore varchar(16)
-- 
-- AS
-- 
-- -- non utilizziamo read uncommitted per evitare di leggere dati incompleti
-- 
-- -- Codice utile per provare la query nell'SQL Analyzer
-- --declare @IdContratto int,
-- --	@PeriodoRilevante tinyint,
-- --	@DataProgramma smalldatetime,
-- --	@Operatore varchar(16)
-- 
-- --set @IdContratto = 13
-- --set @PeriodoRilevante = 1
-- --set @DataProgramma = '04/20/2004'
-- --set @Operatore = 'IDAU'
-- 
-- SELECT POU2.CodiceUnitaSDC,
-- 	POU2.CategoriaUnitaSDC,
-- 	POU2.NomeUnita,
-- 	POU2.QtyMWh,
-- 	POU2.QtyMWhBilanciamento,
-- 	POU2.QtyMWhAssegnataMGP,
-- 	PSR.CoefficienteDiPerdita PSRPerdita,
-- 	POU2.CoefficientePerdita UnitaPerdita,
-- 	POU2.ProgOrarioDellUnitaValidato
-- FROM SDC_PuntiDiScambioRilevanti PSR
-- INNER JOIN
-- (
-- 	SELECT Unita.CoefficientePerdita,
-- 		Unita.CodiceUnitaSDC,
-- 		Unita.CategoriaUnitaSDC,
-- 		Unita.NomeUnita,
-- 		Unita.CodicePuntoDiScambioRilevanteSDC,
-- 		POU.QtyMWh,
-- 		POU.QtyMWhBilanciamento,
-- 		POU.QtyMWhAssegnataMGP,
-- 		POU.ProgOrarioDellUnitaValidato
-- 	FROM
-- 	(
-- 	-- Prelevo tutte le unita del contratto valide ed abilitate
-- 	SELECT SDC_Unita.CoefficientePerdita,
-- 		SDC_Unita.CodiceUnitaSDC,
-- 		SDC_Unita.CategoriaUnitaSDC,
-- 		SDC_Unita.NomeUnita,
-- 		SDC_Unita.CodicePuntoDiScambioRilevanteSDC
-- 	FROM SDC_Unita 
-- 	INNER JOIN 
-- 		(
-- 		-- Prelevo tutte le unita del contratto valide ed abilitate
-- 		SELECT CodiceUnitaSDC,
-- 			CategoriaUnitaSDC
-- 		FROM 	tab_UnitaContratto2(@DataProgramma, @IdContratto) UnitaContratto, 
-- 			Contratto
-- 		WHERE UnitaContratto.IdContratto = @IdContratto
-- 		AND Contratto.IdContratto = @IdContratto
-- 		AND UnitaDelContrattoValidata = 1
-- 		AND UnitaContratto.DataInizioValidita <= @DataProgramma
-- 		AND UnitaContratto.DataFineValidita >= @DataProgramma
-- 		AND TrCC = 1
-- 		AND TrUC = 1
-- 		AND(UnitaAssegnataOpAcquirente = 1 AND CodiceOperatoreSDCAcquirente=@Operatore OR
-- 			UnitaAssegnataOpCedente = 1 AND CodiceOperatoreSDCCedente=@Operatore)
-- 		) UC
-- 		
-- 	ON SDC_Unita.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	AND SDC_Unita.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- 	) Unita
-- 	INNER JOIN
-- 	(
-- 		SELECT CodiceUnitaSDC,
-- 			CategoriaUnitaSDC,
-- 			QtyMWh,
-- 			QtyMWhBilanciamento,
-- 			QtyMWhAssegnataMGP,
-- 			ProgOrarioDellUnitaValidato
-- 		FROM ProgrammaOrarioPerUnita
-- 		WHERE DataProgramma = @DataProgramma AND
-- 			PeriodoRilevante = @PeriodoRilevante AND
-- 			IdContratto = @IdContratto
-- 			
-- 	) POU
-- 	ON POU.CodiceUnitaSDC = Unita.CodiceUnitaSDC
-- 	AND POU.CategoriaUnitaSDC = Unita.CategoriaUnitaSDC
-- ) POU2
-- ON PSR.CodicePuntoDiScambioRilevanteSDC = POU2.CodicePuntoDiScambioRilevanteSDC
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOrariaClient]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOrariaClient]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetDettagliProgrammazioneOrariaClient]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE PROCEDURE [dbo].[spBilGetEnergiaGiornaliera] 
-- @DataProgramma as datetime
-- AS
-- 
-- -- si usa il read uncommitted per non bloccare la sp quando arriva un programma o arrivano i risultati
-- set transaction isolation level read uncommitted
-- 
-- declare @HourNum as integer
-- --set @DataProgramma = '09/28/2004'
-- exec @HourNum = GetHourNum @DataProgramma 
-- 
-- if @HourNum = 24 
-- begin
-- 	select m.CodiceZonaSDC, 
-- 		case m.ProgrammatoDalCedente when 1 then 'Produzione' when 0 then 'Consumo' else 'Delta' end MWh,  
-- 		isnull(d.QtyMWhOra1, 0) QtyMWhOra1,
-- 		isnull(d.QtyMWhOra2, 0) QtyMWhOra2,
-- 		isnull(d.QtyMWhOra3, 0) QtyMWhOra3,
-- 		isnull(d.QtyMWhOra4, 0) QtyMWhOra4,
-- 		isnull(d.QtyMWhOra5, 0) QtyMWhOra5,
-- 		isnull(d.QtyMWhOra6, 0) QtyMWhOra6,
-- 		isnull(d.QtyMWhOra7, 0) QtyMWhOra7,
-- 		isnull(d.QtyMWhOra8, 0) QtyMWhOra8,
-- 		isnull(d.QtyMWhOra9, 0) QtyMWhOra9,
-- 		isnull(d.QtyMWhOra10, 0) QtyMWhOra10,
-- 		isnull(d.QtyMWhOra11, 0) QtyMWhOra11,
-- 		isnull(d.QtyMWhOra12, 0) QtyMWhOra12,
-- 		isnull(d.QtyMWhOra13, 0) QtyMWhOra13,
-- 		isnull(d.QtyMWhOra14, 0) QtyMWhOra14,
-- 		isnull(d.QtyMWhOra15, 0) QtyMWhOra15,
-- 		isnull(d.QtyMWhOra16, 0) QtyMWhOra16,
-- 		isnull(d.QtyMWhOra17, 0) QtyMWhOra17,
-- 		isnull(d.QtyMWhOra18, 0) QtyMWhOra18,
-- 		isnull(d.QtyMWhOra19, 0) QtyMWhOra19,
-- 		isnull(d.QtyMWhOra20, 0) QtyMWhOra20,
-- 		isnull(d.QtyMWhOra21, 0) QtyMWhOra21,
-- 		isnull(d.QtyMWhOra22, 0) QtyMWhOra22,
-- 		isnull(d.QtyMWhOra23, 0) QtyMWhOra23,
-- 		isnull(d.QtyMWhOra24, 0) QtyMWhOra24
-- 	from
-- 	(
-- 		select z.CodiceZonaSDC, 
-- 		pcd.ProgrammatoDalCedente
-- 		from 
-- 		(
-- 			select 1 ProgrammatoDalCedente    -- Produzione
-- 			union 
-- 			select 0 ProgrammatoDalCedente    -- Consumo
-- 			union
-- 			select -1 ProgrammatoDalCedente    -- Delta = Produzione - Consumo
-- 		)
-- 		pcd, 
-- 		sdc_zone z
-- 		) m
-- 		left outer join
-- 		(
-- 		select CodiceZonaSDC, ProgrammatoDalCedente,
-- 			sum(QtyMWhOra1) QtyMWhOra1, sum(QtyMWhOra2) QtyMWhOra2, sum(QtyMWhOra3) QtyMWhOra3, sum(QtyMWhOra4) QtyMWhOra4, 
-- 			sum(QtyMWhOra5) QtyMWhOra5, sum(QtyMWhOra6) QtyMWhOra6, sum(QtyMWhOra7) QtyMWhOra7, sum(QtyMWhOra8) QtyMWhOra8, 
-- 			sum(QtyMWhOra9) QtyMWhOra9, sum(QtyMWhOra10) QtyMWhOra10, sum(QtyMWhOra11) QtyMWhOra11, sum(QtyMWhOra12) QtyMWhOra12, 
-- 			sum(QtyMWhOra13) QtyMWhOra13, sum(QtyMWhOra14) QtyMWhOra14, sum(QtyMWhOra15) QtyMWhOra15, sum(QtyMWhOra16) QtyMWhOra16, 
-- 			sum(QtyMWhOra17) QtyMWhOra17, sum(QtyMWhOra18) QtyMWhOra18, sum(QtyMWhOra19) QtyMWhOra19, sum(QtyMWhOra20) QtyMWhOra20, 
-- 			sum(QtyMWhOra21) QtyMWhOra21, sum(QtyMWhOra22) QtyMWhOra22, sum(QtyMWhOra23) QtyMWhOra23, sum(QtyMWhOra24) QtyMWhOra24
-- 		from 
-- 		(
-- 			select CodiceZonaSDC, ProgrammatoDalCedente,
-- 				case PeriodoRilevante when 1 then QtyMWh else 0 end QtyMWhOra1,
-- 				case PeriodoRilevante when 2 then QtyMWh else 0 end QtyMWhOra2,
-- 				case PeriodoRilevante when 3 then QtyMWh else 0 end QtyMWhOra3,
-- 				case PeriodoRilevante when 4 then QtyMWh else 0 end QtyMWhOra4,
-- 				case PeriodoRilevante when 5 then QtyMWh else 0 end QtyMWhOra5,
-- 				case PeriodoRilevante when 6 then QtyMWh else 0 end QtyMWhOra6,
-- 				case PeriodoRilevante when 7 then QtyMWh else 0 end QtyMWhOra7,
-- 				case PeriodoRilevante when 8 then QtyMWh else 0 end QtyMWhOra8,
-- 				case PeriodoRilevante when 9 then QtyMWh else 0 end QtyMWhOra9,
-- 				case PeriodoRilevante when 10 then QtyMWh else 0 end QtyMWhOra10,
-- 				case PeriodoRilevante when 11 then QtyMWh else 0 end QtyMWhOra11,
-- 				case PeriodoRilevante when 12 then QtyMWh else 0 end QtyMWhOra12,
-- 				case PeriodoRilevante when 13 then QtyMWh else 0 end QtyMWhOra13,
-- 				case PeriodoRilevante when 14 then QtyMWh else 0 end QtyMWhOra14,
-- 				case PeriodoRilevante when 15 then QtyMWh else 0 end QtyMWhOra15,
-- 				case PeriodoRilevante when 16 then QtyMWh else 0 end QtyMWhOra16,
-- 				case PeriodoRilevante when 17 then QtyMWh else 0 end QtyMWhOra17,
-- 				case PeriodoRilevante when 18 then QtyMWh else 0 end QtyMWhOra18,
-- 				case PeriodoRilevante when 19 then QtyMWh else 0 end QtyMWhOra19,
-- 				case PeriodoRilevante when 20 then QtyMWh else 0 end QtyMWhOra20,
-- 				case PeriodoRilevante when 21 then QtyMWh else 0 end QtyMWhOra21,
-- 				case PeriodoRilevante when 22 then QtyMWh else 0 end QtyMWhOra22,
-- 				case PeriodoRilevante when 23 then QtyMWh else 0 end QtyMWhOra23,
-- 				case PeriodoRilevante when 24 then QtyMWh else 0 end QtyMWhOra24
-- 			from
-- 			 (
-- 			select z.CodiceZonaSDC, po.DataProgramma, po.ProgrammatoDalCedente, po.PeriodoRilevante, abs(sum(po.QtyMWh)) QtyMWh
-- 			from 
-- 			programmaorarioperunita po, sdc_unita u, sdc_zone z, sdc_puntidiscambiorilevanti pu
-- 			where po.DataProgramma = @DataProgramma
-- 			and po.CodiceUnitaSDC = u.CodiceUnitaSDC
-- 			and po.CategoriaUnitaSDC = u.CategoriaUnitaSDC
-- 			and pu.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC
-- 			and z.CodiceZonaSDC = pu.CodiceZonaSDC
-- 			group by z.CodiceZonaSDC, po.DataProgramma, po.ProgrammatoDalCedente, po.PeriodoRilevante 
-- 			union
-- 			select z.CodiceZonaSDC, po.DataProgramma, -1 ProgrammatoDalCedente, po.PeriodoRilevante, abs(sum(po.QtyMWh)) QtyMWh
-- 			from programmaorarioperunita po, sdc_unita u, sdc_zone z, sdc_puntidiscambiorilevanti pu
-- 			where po.DataProgramma = @DataProgramma
-- 			and po.CodiceUnitaSDC = u.CodiceUnitaSDC
-- 			and po.CategoriaUnitaSDC = u.CategoriaUnitaSDC
-- 			and pu.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC
-- 			and z.CodiceZonaSDC = pu.CodiceZonaSDC
-- 			group by z.CodiceZonaSDC, po.DataProgramma, po.PeriodoRilevante 
-- 			) t
-- 		--where CodiceZonaSDC = 'NORD'
-- 		) x
-- 		group by CodiceZonaSDC, ProgrammatoDalCedente
-- 	) d
-- 	on m.CodiceZonaSDC = d.CodiceZonaSDC
-- 	and m.ProgrammatoDalCedente = d.ProgrammatoDalCedente
-- 	order by m.CodiceZonaSDC, m.ProgrammatoDalCedente desc
-- 
-- 	return
-- end
-- 
-- 
-- if @HourNum = 23  -- attivazione ora legale
-- begin
-- 	select m.CodiceZonaSDC, 
-- 		case m.ProgrammatoDalCedente when 1 then 'Produzione' when 0 then 'Consumo' else 'Delta' end MWh,  
-- 		isnull(d.QtyMWhOra1, 0) QtyMWhOra1,
-- 		isnull(d.QtyMWhOra2, 0) QtyMWhOra2,
-- 		isnull(d.QtyMWhOra3, 0) QtyMWhOra3,
-- 		isnull(d.QtyMWhOra4, 0) QtyMWhOra4,
-- 		isnull(d.QtyMWhOra5, 0) QtyMWhOra5,
-- 		isnull(d.QtyMWhOra6, 0) QtyMWhOra6,
-- 		isnull(d.QtyMWhOra7, 0) QtyMWhOra7,
-- 		isnull(d.QtyMWhOra8, 0) QtyMWhOra8,
-- 		isnull(d.QtyMWhOra9, 0) QtyMWhOra9,
-- 		isnull(d.QtyMWhOra10, 0) QtyMWhOra10,
-- 		isnull(d.QtyMWhOra11, 0) QtyMWhOra11,
-- 		isnull(d.QtyMWhOra12, 0) QtyMWhOra12,
-- 		isnull(d.QtyMWhOra13, 0) QtyMWhOra13,
-- 		isnull(d.QtyMWhOra14, 0) QtyMWhOra14,
-- 		isnull(d.QtyMWhOra15, 0) QtyMWhOra15,
-- 		isnull(d.QtyMWhOra16, 0) QtyMWhOra16,
-- 		isnull(d.QtyMWhOra17, 0) QtyMWhOra17,
-- 		isnull(d.QtyMWhOra18, 0) QtyMWhOra18,
-- 		isnull(d.QtyMWhOra19, 0) QtyMWhOra19,
-- 		isnull(d.QtyMWhOra20, 0) QtyMWhOra20,
-- 		isnull(d.QtyMWhOra21, 0) QtyMWhOra21,
-- 		isnull(d.QtyMWhOra22, 0) QtyMWhOra22,
-- 		isnull(d.QtyMWhOra23, 0) QtyMWhOra23
-- 	from
-- 	(
-- 		select z.CodiceZonaSDC, 
-- 		pcd.ProgrammatoDalCedente
-- 		from 
-- 		(
-- 			select 1 ProgrammatoDalCedente    -- Produzione
-- 			union 
-- 			select 0 ProgrammatoDalCedente    -- Consumo
-- 			union
-- 			select -1 ProgrammatoDalCedente    -- Delta = Produzione - Consumo
-- 		)
-- 		pcd, 
-- 		sdc_zone z
-- 		) m
-- 		left outer join
-- 		(
-- 		select CodiceZonaSDC, ProgrammatoDalCedente,
-- 			sum(QtyMWhOra1) QtyMWhOra1, sum(QtyMWhOra2) QtyMWhOra2, sum(QtyMWhOra3) QtyMWhOra3, sum(QtyMWhOra4) QtyMWhOra4, 
-- 			sum(QtyMWhOra5) QtyMWhOra5, sum(QtyMWhOra6) QtyMWhOra6, sum(QtyMWhOra7) QtyMWhOra7, sum(QtyMWhOra8) QtyMWhOra8, 
-- 			sum(QtyMWhOra9) QtyMWhOra9, sum(QtyMWhOra10) QtyMWhOra10, sum(QtyMWhOra11) QtyMWhOra11, sum(QtyMWhOra12) QtyMWhOra12, 
-- 			sum(QtyMWhOra13) QtyMWhOra13, sum(QtyMWhOra14) QtyMWhOra14, sum(QtyMWhOra15) QtyMWhOra15, sum(QtyMWhOra16) QtyMWhOra16, 
-- 			sum(QtyMWhOra17) QtyMWhOra17, sum(QtyMWhOra18) QtyMWhOra18, sum(QtyMWhOra19) QtyMWhOra19, sum(QtyMWhOra20) QtyMWhOra20, 
-- 			sum(QtyMWhOra21) QtyMWhOra21, sum(QtyMWhOra22) QtyMWhOra22, sum(QtyMWhOra23) QtyMWhOra23
-- 		from 
-- 		(
-- 			select CodiceZonaSDC, ProgrammatoDalCedente,
-- 				case PeriodoRilevante when 1 then QtyMWh else 0 end QtyMWhOra1,
-- 				case PeriodoRilevante when 2 then QtyMWh else 0 end QtyMWhOra2,
-- 				case PeriodoRilevante when 3 then QtyMWh else 0 end QtyMWhOra3,
-- 				case PeriodoRilevante when 4 then QtyMWh else 0 end QtyMWhOra4,
-- 				case PeriodoRilevante when 5 then QtyMWh else 0 end QtyMWhOra5,
-- 				case PeriodoRilevante when 6 then QtyMWh else 0 end QtyMWhOra6,
-- 				case PeriodoRilevante when 7 then QtyMWh else 0 end QtyMWhOra7,
-- 				case PeriodoRilevante when 8 then QtyMWh else 0 end QtyMWhOra8,
-- 				case PeriodoRilevante when 9 then QtyMWh else 0 end QtyMWhOra9,
-- 				case PeriodoRilevante when 10 then QtyMWh else 0 end QtyMWhOra10,
-- 				case PeriodoRilevante when 11 then QtyMWh else 0 end QtyMWhOra11,
-- 				case PeriodoRilevante when 12 then QtyMWh else 0 end QtyMWhOra12,
-- 				case PeriodoRilevante when 13 then QtyMWh else 0 end QtyMWhOra13,
-- 				case PeriodoRilevante when 14 then QtyMWh else 0 end QtyMWhOra14,
-- 				case PeriodoRilevante when 15 then QtyMWh else 0 end QtyMWhOra15,
-- 				case PeriodoRilevante when 16 then QtyMWh else 0 end QtyMWhOra16,
-- 				case PeriodoRilevante when 17 then QtyMWh else 0 end QtyMWhOra17,
-- 				case PeriodoRilevante when 18 then QtyMWh else 0 end QtyMWhOra18,
-- 				case PeriodoRilevante when 19 then QtyMWh else 0 end QtyMWhOra19,
-- 				case PeriodoRilevante when 20 then QtyMWh else 0 end QtyMWhOra20,
-- 				case PeriodoRilevante when 21 then QtyMWh else 0 end QtyMWhOra21,
-- 				case PeriodoRilevante when 22 then QtyMWh else 0 end QtyMWhOra22,
-- 				case PeriodoRilevante when 23 then QtyMWh else 0 end QtyMWhOra23
-- 			from
-- 			 (
-- 			select z.CodiceZonaSDC, po.DataProgramma, po.ProgrammatoDalCedente, po.PeriodoRilevante, abs(sum(po.QtyMWh)) QtyMWh
-- 			from 
-- 			programmaorarioperunita po, sdc_unita u, sdc_zone z, sdc_puntidiscambiorilevanti pu
-- 			where po.DataProgramma = @DataProgramma
-- 			and po.CodiceUnitaSDC = u.CodiceUnitaSDC
-- 			and po.CategoriaUnitaSDC = u.CategoriaUnitaSDC
-- 			and pu.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC
-- 			and z.CodiceZonaSDC = pu.CodiceZonaSDC
-- 			group by z.CodiceZonaSDC, po.DataProgramma, po.ProgrammatoDalCedente, po.PeriodoRilevante 
-- 			union
-- 			select z.CodiceZonaSDC, po.DataProgramma, -1 ProgrammatoDalCedente, po.PeriodoRilevante, abs(sum(po.QtyMWh)) QtyMWh
-- 			from programmaorarioperunita po, sdc_unita u, sdc_zone z, sdc_puntidiscambiorilevanti pu
-- 			where po.DataProgramma = @DataProgramma
-- 			and po.CodiceUnitaSDC = u.CodiceUnitaSDC
-- 			and po.CategoriaUnitaSDC = u.CategoriaUnitaSDC
-- 			and pu.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC
-- 			and z.CodiceZonaSDC = pu.CodiceZonaSDC
-- 			group by z.CodiceZonaSDC, po.DataProgramma, po.PeriodoRilevante 
-- 			) t
-- 		--where CodiceZonaSDC = 'NORD'
-- 		) x
-- 		group by CodiceZonaSDC, ProgrammatoDalCedente
-- 	) d
-- 	on m.CodiceZonaSDC = d.CodiceZonaSDC
-- 	and m.ProgrammatoDalCedente = d.ProgrammatoDalCedente
-- 	order by m.CodiceZonaSDC, m.ProgrammatoDalCedente desc
-- 
-- 	return
-- end
-- 
-- if @HourNum = 25  -- disattivazione ora legale
-- begin
-- 	select m.CodiceZonaSDC, 
-- 		case m.ProgrammatoDalCedente when 1 then 'Produzione' when 0 then 'Consumo' else 'Delta' end MWh,  
-- 		isnull(d.QtyMWhOra1, 0) QtyMWhOra1,
-- 		isnull(d.QtyMWhOra2, 0) QtyMWhOra2,
-- 		isnull(d.QtyMWhOra3, 0) QtyMWhOra3,
-- 		isnull(d.QtyMWhOra4, 0) QtyMWhOra4,
-- 		isnull(d.QtyMWhOra5, 0) QtyMWhOra5,
-- 		isnull(d.QtyMWhOra6, 0) QtyMWhOra6,
-- 		isnull(d.QtyMWhOra7, 0) QtyMWhOra7,
-- 		isnull(d.QtyMWhOra8, 0) QtyMWhOra8,
-- 		isnull(d.QtyMWhOra9, 0) QtyMWhOra9,
-- 		isnull(d.QtyMWhOra10, 0) QtyMWhOra10,
-- 		isnull(d.QtyMWhOra11, 0) QtyMWhOra11,
-- 		isnull(d.QtyMWhOra12, 0) QtyMWhOra12,
-- 		isnull(d.QtyMWhOra13, 0) QtyMWhOra13,
-- 		isnull(d.QtyMWhOra14, 0) QtyMWhOra14,
-- 		isnull(d.QtyMWhOra15, 0) QtyMWhOra15,
-- 		isnull(d.QtyMWhOra16, 0) QtyMWhOra16,
-- 		isnull(d.QtyMWhOra17, 0) QtyMWhOra17,
-- 		isnull(d.QtyMWhOra18, 0) QtyMWhOra18,
-- 		isnull(d.QtyMWhOra19, 0) QtyMWhOra19,
-- 		isnull(d.QtyMWhOra20, 0) QtyMWhOra20,
-- 		isnull(d.QtyMWhOra21, 0) QtyMWhOra21,
-- 		isnull(d.QtyMWhOra22, 0) QtyMWhOra22,
-- 		isnull(d.QtyMWhOra23, 0) QtyMWhOra23,
-- 		isnull(d.QtyMWhOra24, 0) QtyMWhOra24,
-- 		isnull(d.QtyMWhOra25, 0) QtyMWhOra25
-- 	from
-- 	(
-- 		select z.CodiceZonaSDC, 
-- 		pcd.ProgrammatoDalCedente
-- 		from 
-- 		(
-- 			select 1 ProgrammatoDalCedente    -- Produzione
-- 			union 
-- 			select 0 ProgrammatoDalCedente    -- Consumo
-- 			union
-- 			select -1 ProgrammatoDalCedente    -- Delta = Produzione - Consumo
-- 		)
-- 		pcd, 
-- 		sdc_zone z
-- 		) m
-- 		left outer join
-- 		(
-- 		select CodiceZonaSDC, ProgrammatoDalCedente,
-- 			sum(QtyMWhOra1) QtyMWhOra1, sum(QtyMWhOra2) QtyMWhOra2, sum(QtyMWhOra3) QtyMWhOra3, sum(QtyMWhOra4) QtyMWhOra4, 
-- 			sum(QtyMWhOra5) QtyMWhOra5, sum(QtyMWhOra6) QtyMWhOra6, sum(QtyMWhOra7) QtyMWhOra7, sum(QtyMWhOra8) QtyMWhOra8, 
-- 			sum(QtyMWhOra9) QtyMWhOra9, sum(QtyMWhOra10) QtyMWhOra10, sum(QtyMWhOra11) QtyMWhOra11, sum(QtyMWhOra12) QtyMWhOra12, 
-- 			sum(QtyMWhOra13) QtyMWhOra13, sum(QtyMWhOra14) QtyMWhOra14, sum(QtyMWhOra15) QtyMWhOra15, sum(QtyMWhOra16) QtyMWhOra16, 
-- 			sum(QtyMWhOra17) QtyMWhOra17, sum(QtyMWhOra18) QtyMWhOra18, sum(QtyMWhOra19) QtyMWhOra19, sum(QtyMWhOra20) QtyMWhOra20, 
-- 			sum(QtyMWhOra21) QtyMWhOra21, sum(QtyMWhOra22) QtyMWhOra22, sum(QtyMWhOra23) QtyMWhOra23, sum(QtyMWhOra24) QtyMWhOra24,
-- 			sum(QtyMWhOra25) QtyMWhOra25
-- 		from 
-- 		(
-- 			select CodiceZonaSDC, ProgrammatoDalCedente,
-- 				case PeriodoRilevante when 1 then QtyMWh else 0 end QtyMWhOra1,
-- 				case PeriodoRilevante when 2 then QtyMWh else 0 end QtyMWhOra2,
-- 				case PeriodoRilevante when 3 then QtyMWh else 0 end QtyMWhOra3,
-- 				case PeriodoRilevante when 4 then QtyMWh else 0 end QtyMWhOra4,
-- 				case PeriodoRilevante when 5 then QtyMWh else 0 end QtyMWhOra5,
-- 				case PeriodoRilevante when 6 then QtyMWh else 0 end QtyMWhOra6,
-- 				case PeriodoRilevante when 7 then QtyMWh else 0 end QtyMWhOra7,
-- 				case PeriodoRilevante when 8 then QtyMWh else 0 end QtyMWhOra8,
-- 				case PeriodoRilevante when 9 then QtyMWh else 0 end QtyMWhOra9,
-- 				case PeriodoRilevante when 10 then QtyMWh else 0 end QtyMWhOra10,
-- 				case PeriodoRilevante when 11 then QtyMWh else 0 end QtyMWhOra11,
-- 				case PeriodoRilevante when 12 then QtyMWh else 0 end QtyMWhOra12,
-- 				case PeriodoRilevante when 13 then QtyMWh else 0 end QtyMWhOra13,
-- 				case PeriodoRilevante when 14 then QtyMWh else 0 end QtyMWhOra14,
-- 				case PeriodoRilevante when 15 then QtyMWh else 0 end QtyMWhOra15,
-- 				case PeriodoRilevante when 16 then QtyMWh else 0 end QtyMWhOra16,
-- 				case PeriodoRilevante when 17 then QtyMWh else 0 end QtyMWhOra17,
-- 				case PeriodoRilevante when 18 then QtyMWh else 0 end QtyMWhOra18,
-- 				case PeriodoRilevante when 19 then QtyMWh else 0 end QtyMWhOra19,
-- 				case PeriodoRilevante when 20 then QtyMWh else 0 end QtyMWhOra20,
-- 				case PeriodoRilevante when 21 then QtyMWh else 0 end QtyMWhOra21,
-- 				case PeriodoRilevante when 22 then QtyMWh else 0 end QtyMWhOra22,
-- 				case PeriodoRilevante when 23 then QtyMWh else 0 end QtyMWhOra23,
-- 				case PeriodoRilevante when 24 then QtyMWh else 0 end QtyMWhOra24,
-- 				case PeriodoRilevante when 25 then QtyMWh else 0 end QtyMWhOra25
-- 			from
-- 			 (
-- 			select z.CodiceZonaSDC, po.DataProgramma, po.ProgrammatoDalCedente, po.PeriodoRilevante, abs(sum(po.QtyMWh)) QtyMWh
-- 			from 
-- 			programmaorarioperunita po, sdc_unita u, sdc_zone z, sdc_puntidiscambiorilevanti pu
-- 			where po.DataProgramma = @DataProgramma
-- 			and po.CodiceUnitaSDC = u.CodiceUnitaSDC
-- 			and po.CategoriaUnitaSDC = u.CategoriaUnitaSDC
-- 			and pu.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC
-- 			and z.CodiceZonaSDC = pu.CodiceZonaSDC
-- 			group by z.CodiceZonaSDC, po.DataProgramma, po.ProgrammatoDalCedente, po.PeriodoRilevante 
-- 			union
-- 			select z.CodiceZonaSDC, po.DataProgramma, -1 ProgrammatoDalCedente, po.PeriodoRilevante, abs(sum(po.QtyMWh)) QtyMWh
-- 			from programmaorarioperunita po, sdc_unita u, sdc_zone z, sdc_puntidiscambiorilevanti pu
-- 			where po.DataProgramma = @DataProgramma
-- 			and po.CodiceUnitaSDC = u.CodiceUnitaSDC
-- 			and po.CategoriaUnitaSDC = u.CategoriaUnitaSDC
-- 			and pu.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC
-- 			and z.CodiceZonaSDC = pu.CodiceZonaSDC
-- 			group by z.CodiceZonaSDC, po.DataProgramma, po.PeriodoRilevante 
-- 			) t
-- 		--where CodiceZonaSDC = 'NORD'
-- 		) x
-- 		group by CodiceZonaSDC, ProgrammatoDalCedente
-- 	) d
-- 	on m.CodiceZonaSDC = d.CodiceZonaSDC
-- 	and m.ProgrammatoDalCedente = d.ProgrammatoDalCedente
-- 	order by m.CodiceZonaSDC, m.ProgrammatoDalCedente desc
-- 
-- 	return
-- end
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetEnergiaGiornaliera]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetEnergiaGiornaliera]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetEnergiaGiornaliera]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE PROCEDURE [dbo].[spBilGetListaContratti] 
-- @ricercaValidoDal as bit = 0,
-- @ricercaValidoAl As bit = 0,
-- @validoDal as datetime = null,
-- @validoAl As DateTime = null,
-- @codiceSDCTitolare as varchar(16) = null,
-- @ragioneSocialeTitolare as varchar(256) = null,
-- @statoContratto As varchar(32) = null,
-- @codiceContratto As varchar(50) =null,
-- @codiceContrattoGRTN As varchar(30) = null,
-- @codiceUnitaSDC as varchar(16) = null,
-- @codiceOpRifUnita  as varchar(16) = null,
-- @codiceOpCedente as varchar(16) = null,
-- @codiceOpAcquirente  as varchar(16) = null
-- AS
-- 
-- 
-- set nocount off;
-- declare @Q as nvarchar(4000),
-- 	@df as datetime,
-- 	@di as datetime
-- 
-- set @Q = ''
-- set @Q = @Q +  
-- 'SELECT     C.*, 
-- T.IdContratto, ISNULL(T.TotaleUnita, 0) AS TotaleUnitaContratto, 
-- ISNULL(T.TotaleUnita, 0) AS UnitaContrattoValidate
-- FROM         
-- (
-- SELECT     *
-- FROM          dbo.Bil_ContrattoOperatore
-- WHERE      (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
-- (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita))
-- ) C LEFT OUTER JOIN
-- (
-- SELECT     IdContratto, COUNT(*) TotaleUnita
-- FROM          
-- (SELECT     
-- IdContratto, 
-- CodiceUnitaSDC, 
-- CategoriaUnitaSDC, 
-- TrCC, 
-- TrUC, 
-- VUC, 
-- SUM(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente, 
-- SUM(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
-- FROM          
-- (SELECT     
-- c.IdContratto, 
-- ur.CodiceUnitaSDC, 
-- ur.CategoriaUnitaSDC, 
-- ur.TrUC, 
-- ur.VUC, 
-- 1 UnitaAssegnataOpCedente, 
-- 0 UnitaAssegnataOpAcquirente, 
-- c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
-- FROM unitrelate ur 
-- INNER JOIN
-- contratto c ON c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
-- AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
-- AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente AND ur.TipoUnita IN (''P'', ''M'') 
-- AND (ur.DataInizioValidita <= c.DataFineValidita AND ur.DataFineValidita >= c.DataInizioValidita)
-- AND ur.Abilitata = 1 
-- UNION
-- SELECT     
-- c.IdContratto, 
-- ur.CodiceUnitaSDC, 
-- ur.CategoriaUnitaSDC, 
-- ur.TrUC, 
-- ur.VUC, 
-- 0 UnitaAssegnataOpCedente, 
-- 1 UnitaAssegnataOpAcquirente, 
-- c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
-- FROM         
-- unitrelate ur 
-- INNER JOIN
-- contratto c ON c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
-- AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
-- AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente AND ur.TipoUnita IN (''C'', ''M'') 
-- AND (ur.DataInizioValidita <= c.DataFineValidita AND ur.DataFineValidita >= c.DataInizioValidita)
-- AND ur.Abilitata = 1 
-- ) w
-- GROUP BY IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC, TrUC, VUC, TrCC) Q
-- GROUP BY IdContratto) T ON C.IdContratto = T.IdContratto
-- WHERE     (1 = 1)'
-- 
-- 
-- if @ricercaValidoDal = 1 
-- 	set @di = @validoDal
-- else
-- 	set @di = null
-- 
-- if @ricercaValidoAl = 1 
-- 	set @di = @validoAl
-- else
-- 	set @di = null
-- 
-- if not @codiceSDCTitolare is null and len(@codiceSDCTitolare) > 0
-- 	set @Q = @Q + ' AND CodiceOperatoreSDC LIKE ''' + @codiceSDCTitolare + ''''
-- 
-- if not @ragioneSocialeTitolare is null and len(@ragioneSocialeTitolare) > 0
-- 	set @Q = @Q + ' AND Titolare_RagioneSociale LIKE ''' + @ragioneSocialeTitolare + ''''
-- 
-- if not @statoContratto is null and len(@statoContratto) > 0 
-- 	set @Q = @Q + ' AND StatoContratto = ''' + @statoContratto + ''''
-- 
-- if not @codiceContratto is null and len(@codiceContratto) > 0 
-- 	set @Q = @Q + ' AND CodiceContratto LIKE ''' + @CodiceContratto + ''''               
-- 
-- if not @codiceContrattoGRTN is null and len(@codiceContrattoGRTN) > 0 
-- 	set @Q = @Q + ' AND CRN LIKE ''' + @codiceContrattoGRTN + ''''  
-- 
-- if @validoDal = @validoAl 
-- begin
-- 	if not @codiceUnitaSDC is null and len(@codiceUnitaSDC) > 0
-- 		set @Q = @Q +  ' and EXISTS ( 
-- 		 select * 
-- 		 from UnitRelate UR 
-- 		 where UR.Abilitata = 1 
-- 		 and UR.TrUC = 1 
-- 		 and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita) 
-- 		 and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita) 
-- 		 and UR.CodiceUnitaSDC LIKE ''' +
-- 		@codiceUnitaSDC  + '''  and 
-- 		 (
-- 		  (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and UR.TipoUnita <> ''P'')
-- 		  or
-- 		  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and UR.TipoUnita <> ''C'')
-- 		 ) ) '
-- 		 
-- 
-- 
-- 	If not @codiceOpRifUnita is null and len(@codiceOpRifUnita) > 0
-- 		set @Q = @Q +  ' and EXISTS ( 
-- 		select *
-- 		from SDC_Unita U 
-- 		inner join UnitRelate UR
-- 		on UR.CodiceUnitaSDC = U.CodiceUnitaSDC
-- 		and UR.Abilitata = 1
-- 		and UR.TrUC = 1
-- 		and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita)
-- 		and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita)
-- 		and U.CodiceOperatoreDiRiferimentoSDC LIKE ''' +
-- 		@codiceOpRifUnita + 
-- 		''' where
-- 		( (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> ''P'')
-- 		or
-- 		  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> ''C'') )
-- 		)'
-- end
-- 
-- if not @codiceOpAcquirente is null and len(@codiceOpAcquirente) > 0
-- 	set @Q = @Q +  ' AND CodiceOperatoreSDCAcquirente LIKE ''' + @codiceOpAcquirente + ''''
-- 
-- if not @codiceOpCedente is null and len(@codiceOpCedente) > 0
-- 	set @Q = @Q +  ' AND CodiceOperatoreSDCCedente LIKE ''' + @codiceOpCedente + ''''
-- 
-- exec sp_executesql @Q,
-- 	N'@di datetime, @df datetime',
--   	@di = @di,
--   	@df = @df
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetListaContratti]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetListaContratti]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetListaContratti]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE PROCEDURE [dbo].[spBilGetListaContrattiClient] 
-- @codiceSDCTitolare as varchar(16),
-- @ragioneSocialeTitolare as varchar(256),
-- @ricercaValidoDal as bit,
-- @validoDal as datetime,
-- @ricercaValidoAl As bit,
-- @validoAl As DateTime,
-- @statoContratto As varchar(32),
-- @codiceContratto As varchar(50),
-- @codiceContrattoGRTN As varchar(30),
-- @codiceUnitaSDC as varchar(16),
-- @codiceOpRifUnita  as varchar(16),
-- @codiceOpCedente as varchar(16),
-- @codiceOpAcquirente  as varchar(16),
-- @IdOperatoreLoggato as varchar(16)
-- AS
-- 
-- 
-- set nocount off;
-- 
-- declare @Q as nvarchar(4000),
-- 	@df as datetime,
-- 	@di as datetime,
-- 	@operatore as varchar(16)
-- 
-- set @operatore = @IdOperatoreLoggato
-- 
-- set @Q = ''
-- set @Q = @Q +  
-- 'SELECT     C.*, T.IdContratto, 
-- ISNULL(T.TotaleUnita, 0) AS TotaleUnitaContratto, 
-- ISNULL(T.TotaleUnita, 0) AS UnitaContrattoValidate
-- FROM         
-- (
-- SELECT     *
-- FROM          dbo.Bil_ContrattoOperatore
-- WHERE      (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDCCedente = @Operatore) AND 
--       (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
--       (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) OR
--       (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
--       (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) AND 
--       (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDCAcquirente = @Operatore) OR
--       (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) AND 
--       (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) AND 
--       (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDC = @Operatore)) 
-- C 
-- LEFT OUTER JOIN
-- (SELECT     IdContratto, 
-- COUNT(*) TotaleUnita
-- FROM          
-- (
-- 	SELECT     
-- 	IdContratto, 
-- 	CodiceUnitaSDC, 
-- 	CategoriaUnitaSDC, 
-- 	TrCC, 
-- 	TrUC, 
-- 	VUC, 
-- 	SUM(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente, 
-- 	SUM(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
--         FROM          
-- 	(
-- 		SELECT     
-- 		c.IdContratto, 
-- 		ur.CodiceUnitaSDC, 
-- 		ur.CategoriaUnitaSDC, 
-- 		ur.TrUC, 
-- 		ur.VUC, 
-- 		1 UnitaAssegnataOpCedente, 
--                 0 UnitaAssegnataOpAcquirente, 
-- 		c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
--                 FROM          
-- 		unitrelate ur INNER JOIN
--                 contratto c 
-- 		ON c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
-- 		AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
-- 		AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente 
-- 		AND ur.TipoUnita IN (''P'', ''M'') 
-- 		AND (ur.DataInizioValidita <= c.DataFineValidita 
-- 		AND ur.DataFineValidita >= c.DataInizioValidita) 
-- 		AND ur.Abilitata = 1
--             	UNION
--                 SELECT     
-- 		c.IdContratto, 
-- 		ur.CodiceUnitaSDC, 
-- 		ur.CategoriaUnitaSDC, 
-- 		ur.TrUC, 
-- 		ur.VUC, 
-- 		0 UnitaAssegnataOpCedente, 
--                 1 UnitaAssegnataOpAcquirente, 
-- 		c.TrCN & (CASE c.StatoContratto WHEN ''Abilitato'' THEN 1 ELSE 0 END) TrCC
--                 FROM         unitrelate ur 
-- 		INNER JOIN
-- 		contratto c 
-- 		ON c.DataInizioValidita <= ISNULL(@di, c.DataInizioValidita) 
-- 		AND c.DataFineValidita >= ISNULL(@df, c.DataFineValidita) 
-- 		AND ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente 
-- 		AND ur.TipoUnita IN (''C'', ''M'') 
-- 		AND (ur.DataInizioValidita <= c.DataFineValidita 
-- 		AND ur.DataFineValidita >= c.DataInizioValidita) 
-- 		AND ur.Abilitata = 1
-- 	) w
--     	GROUP BY IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC, TrUC, VUC, TrCC
-- ) Q
-- GROUP BY IdContratto) T ON C.IdContratto = T.IdContratto
-- WHERE     (1 = 1)'
-- 
-- if @ricercaValidoDal = 1 
-- 	set @di = @validoDal
-- else
-- 	set @di = null
-- if @ricercaValidoAl = 1 
-- 	set @di = @validoAl
-- else
-- 	set @di = null
-- 
-- if not @codiceSDCTitolare is null and len(@codiceSDCTitolare) > 0
-- 	set @Q = @Q + ' AND CodiceOperatoreSDC LIKE ''' + @codiceSDCTitolare + ''''
-- 
-- if not @ragioneSocialeTitolare is null and len(@ragioneSocialeTitolare) > 0
-- 	set @Q = @Q + ' AND Titolare_RagioneSociale LIKE ''' + @ragioneSocialeTitolare + ''''
-- 
-- if not @statoContratto is null and len(@statoContratto) > 0 
-- 	set @Q = @Q + ' AND StatoContratto = ''' + @statoContratto + ''''
-- 
-- if not @codiceContratto is null and len(@codiceContratto) > 0 
-- 	set @Q = @Q + ' AND CodiceContratto LIKE ''' + @CodiceContratto + ''''               
-- 
-- if not @codiceContrattoGRTN is null and len(@codiceContrattoGRTN) > 0 
-- 	set @Q = @Q + ' AND CRN LIKE ''' + @codiceContrattoGRTN + ''''  
-- 
-- if @validoDal = @validoAl 
-- begin
-- 	if not @codiceUnitaSDC is null and len(@codiceUnitaSDC) > 0
-- 		set @Q = @Q +  ' and EXISTS ( 
-- 		 select * 
-- 		 from UnitRelate UR 
-- 		 where UR.Abilitata = 1 
-- 		 and UR.TrUC = 1 
-- 		 and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita) 
-- 		 and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita) 
-- 		 and UR.CodiceUnitaSDC LIKE  ''' + @codiceUnitaSDC  +
-- 		 ''' and 
-- 		 (
-- 		  (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and UR.TipoUnita <> ''P'')
-- 		  or
-- 		  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and UR.TipoUnita <> ''C'')
-- 		 ) ) '
-- 		 
-- 
-- 
-- 	If not @codiceOpRifUnita is null and len(@codiceOpRifUnita) > 0
-- 		set @Q = @Q +  ' and EXISTS ( 
-- 		select *
-- 		from SDC_Unita U 
-- 		inner join UnitRelate UR
-- 		on UR.CodiceUnitaSDC = U.CodiceUnitaSDC
-- 		and UR.Abilitata = 1
-- 		and UR.TrUC = 1
-- 		and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita)
-- 		and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita)
-- 		and U.CodiceOperatoreDiRiferimentoSDC LIKE ''' +
-- 		@codiceOpRifUnita + ''' where
-- 		( (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> ''P'')
-- 		or
-- 		  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> ''C'') )
-- 		)'
-- end
-- 
-- if not @codiceOpAcquirente is null and len(@codiceOpAcquirente) > 0
-- 	set @Q = @Q +  ' AND CodiceOperatoreSDCAcquirente LIKE ''' + @codiceOpAcquirente + ''''
-- 
-- 
-- if not @codiceOpCedente is null and len(@codiceOpCedente) > 0
-- 	set @Q = @Q +  ' AND CodiceOperatoreSDCCedente LIKE ''' + @codiceOpCedente + ''''
-- 
-- 
-- 
-- --print @Q
-- exec sp_executesql @Q,
-- 	N'@di datetime, @df datetime, @operatore varchar(16)',
--   	@di = @di,
--   	@df = @df,
-- 	@operatore = @operatore
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetListaContrattiClient]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetListaContrattiClient]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetListaContrattiClient]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE  PROCEDURE spBilGetProgrammaOrarioContratto
-- 	@IdContratto 	int,
-- 	@DataProgramma 	smalldatetime,
-- 	@OraLimite		tinyint
-- AS
-- 
-- -- usiamo read uncommitted perche` i dati che si ritornano da questa query 
-- -- sono "accorpamenti"
-- set transaction isolation level read uncommitted
-- 
-- -- declare
-- -- 	@IdContratto 	int,
-- -- 	@DataProgramma 	smalldatetime,
-- -- 	@OraLimite		tinyint
-- -- 
-- -- select @IdContratto=210
-- -- select @DataProgramma='24/11/2004'
-- -- select @OraLimite=24
-- -- 
-- 
-- SELECT C.IdContratto, 
-- 	POC.Ora,
-- 	POC.TotUnitaDaProgrammareAcq,
-- 	POC.TotUnitaDaProgrammareCed,
-- 	POC.TotUnitaProgrammateDalCed,
-- 	POC.TotUnitaProgrammateDalAcq,
-- 	POC.TotaleUnitaProgrammate,
-- 	POC.TotUnitaProgrammateEtValidate,
-- 	POC.ProgrammaOrarioValidato,
--  	POC.Bilanciato,
--  	POC.SbilanciamentoMWh,
-- 	C.GestioneTaglio,
-- 	C.IsGMEOpAcquirente,
-- 	C.IsGMEOpCedente
-- FROM
-- (
-- SELECT CO.IdContratto,
-- 	CO.GestioneTaglio,
-- 	OA.IsGMEOp IsGMEOpAcquirente,
-- 	OC.IsGMEOp IsGMEOpCedente
-- FROM Contratto CO, 
-- 	Operatori OA,
-- 	Operatori OC
-- WHERE  CO.IdContratto = @IdContratto
-- 	AND CO.DataInizioValidita <= @DataProgramma
-- 	AND CO.DataFineValidita >= @DataProgramma
--  	AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
--  	AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
-- ) C
-- INNER JOIN 
-- (
-- SELECT UC.IdContratto,
-- 	UC.PeriodoRilevante as Ora,
-- 
-- 	SUM(CASE(UC.UnitaAssegnataOpAcquirente) WHEN 1 THEN 1 ELSE 0 END) TotUnitaDaProgrammareAcq,
-- 	SUM(CASE(UC.UnitaAssegnataOpCedente) WHEN 1 THEN 1 ELSE 0 END)    TotUnitaDaProgrammareCed,
-- 
-- 
-- 	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 0)) WHEN 1 THEN 1 ELSE 0 END) TotUnitaProgrammateDalCed,
-- 	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 1)) WHEN 0 THEN 1 ELSE 0 END) TotUnitaProgrammateDalAcq,
-- 	
-- 	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 0)) WHEN 1 THEN 1 ELSE 0 END) +
-- 	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 1)) WHEN 0 THEN 1 ELSE 0 END) TotaleUnitaProgrammate,
-- 	SUM(CASE(isnull(POU2.ProgOrarioDellUnitaValidato, 0)) WHEN 1 THEN 1 ELSE 0 END) TotUnitaProgrammateEtValidate,
-- 
-- 	PO2.ProgrammaOrarioValidato,
--  	PO2.Bilanciato,
--  	PO2.SbilanciamentoMWh
-- FROM
-- 	(
-- 		SELECT 
-- 		UC1.IdContratto, 
-- 		Ore.PR PeriodoRilevante,
-- 		UC1.UnitaAssegnataOpAcquirente,
-- 		UC1.UnitaAssegnataOpCedente,
-- 		UC1.CodiceUnitaSDC,
-- 		UC1.CategoriaUnitaSDC
-- 		FROM tab_UnitaContratto2(@DataProgramma, @IdContratto) UC1,
-- 			(
-- 			SELECT Ora PR
-- 			FROM Ore
-- 			WHERE Ora <= @OraLimite
-- 			) Ore
-- 		WHERE 	UC1.IdContratto = @IdContratto 
-- 			AND UC1.UnitaDelContrattoValidata = 1
-- 			AND UC1.TrCC = 1
-- 			AND UC1.TrUC = 1
-- 			AND UC1.DataInizioValidita <= @DataProgramma
-- 			AND UC1.DataFineValidita >= @DataProgramma
-- 	) UC
-- 	LEFT OUTER JOIN
-- 	(
-- 			SELECT
-- 			IdContratto,
-- 			DataProgramma,
-- 			PeriodoRilevante,
-- 			CodiceUnitaSDC,
-- 			CategoriaUnitaSDC,
-- 			ProgrammatoDalCedente,
-- 			ProgOrarioDellUnitaValidato
-- 			FROM ProgrammaOrarioPerUnita
-- 			WHERE IdContratto = @IdContratto AND
-- 				DataProgramma = @DataProgramma
-- 	)
-- 	POU2
-- 	ON POU2.IdContratto = UC.IdContratto
-- 	AND POU2.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	AND POU2.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- 	AND POU2.PeriodoRilevante = UC.PeriodoRilevante
-- 
-- 	LEFT OUTER JOIN
-- 	(
-- 		SELECT IdContratto,
-- 			DataProgramma,
-- 			PeriodoRilevante,
-- 			ProgrammaOrarioValidato,
-- 			Bilanciato,
-- 			SbilanciamentoMWh
-- 		FROM ProgrammaOrario 
-- 		WHERE IdCOntratto = @IdContratto AND
-- 			DataProgramma = @DataProgramma
-- 	) PO2
-- 	ON PO2.IdContratto = UC.IdContratto
-- 	AND PO2.PeriodoRilevante = UC.PeriodoRilevante
-- 
-- GROUP BY UC.IdContratto, 
-- 	UC.PeriodoRilevante,
-- 	po2.ProgrammaOrarioValidato,
--  	PO2.Bilanciato,
--  	PO2.SbilanciamentoMWh
-- ) POC
-- ON C.IdContratto = POC.IdContratto
-- order by
-- POC.Ora
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammaOrarioContratto]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammaOrarioContratto]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammaOrarioContratto]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE PROCEDURE spBilGetProgrammaOrarioContrattoClient
-- 	@IdContratto 		int,
-- 	@DataProgramma 	smalldatetime,
-- 	@OraLimite		tinyint,
-- 	@Operatore		varchar(16)
-- AS
-- 
-- -- usiamo read uncommitted perche` i dati che si ritornano da questa query 
-- -- sono "accorpamenti"
-- set transaction isolation level read uncommitted
-- 
-- 
-- -- declare @IdContratto int,
-- -- 	@Operatore varchar(16),
-- -- 	@DataProgramma smalldatetime,
-- -- 	@OraLimite tinyint
-- -- 
-- -- select @IdContratto=210
-- -- select @DataProgramma='24/11/2004'
-- -- select @Operatore='IDGRTNCO'
-- -- select @OraLimite=24
-- 
-- 
-- SELECT 
-- UC.IdContratto,
-- UC.PeriodoRilevante as Ora,
-- 
-- SUM(CASE(UC.AcqFlag) WHEN 1 THEN 1 ELSE NULL END) TotUnitaDaProgrammareAcq,
-- SUM(CASE(UC.CedFlag) WHEN 1 THEN 1 ELSE NULL END) TotUnitaDaProgrammareCed,
-- 
-- SUM(CASE UC.CedFlag 
-- 	WHEN 0 THEN NULL 
-- 	ELSE CASE isnull(POU2.ProgrammatoDalCedente, 0) WHEN 1 THEN 1 ELSE 0 END
-- 	END) TotUnitaProgrammateDalCed, 
-- 
-- SUM(CASE UC.AcqFlag
-- 	WHEN 0 THEN NULL
-- 	ELSE CASE(isnull(POU2.ProgrammatoDalCedente, 1) & UC.AcqFlag) WHEN 0 THEN 1 ELSE 0 END
-- 	END) TotUnitaProgrammateDalAcq,
-- 
-- NULL TotaleUnitaProgrammate,
-- NULL TotUnitaProgrammateEtValidate,
-- 
-- PO2.ProgrammaOrarioValidato,
-- PO2.Bilanciato,
-- PO2.SbilanciamentoMWh
-- FROM
-- (
-- 	SELECT 
-- 	UC2.IdContratto, 
-- 	Ore.Ora PeriodoRilevante,
-- 	UC2.UnitaAssegnataOpAcquirente,
-- 	UC2.UnitaAssegnataOpCedente,
-- 	UC2.CodiceUnitaSDC,
-- 	UC2.CategoriaUnitaSDC,
-- 	UC2.CodiceOperatoreSDCAcquirente,
-- 	UC2.CodiceOperatoreSDCCedente,
-- 	(UC2.UnitaAssegnataOpAcquirente & CASE WHEN UC2.CodiceOperatoreSDCAcquirente=@Operatore THEN 1 ELSE 0 END) AcqFlag,
-- 	(UC2.UnitaAssegnataOpCedente    & CASE WHEN UC2.CodiceOperatoreSDCCedente=@Operatore    THEN 1 ELSE 0 END) CedFlag
-- 	FROM	
-- 	(
-- 		select 
-- 		UC1.IdContratto,
-- 		UC1.CodiceOperatoreSDCAcquirente,
-- 		UC1.CodiceOperatoreSDCCedente,
-- 
-- 		UC1.CodiceUnitaSDC,
-- 		UC1.CategoriaUnitaSDC,
-- 		
-- 		sum(UC1.UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente,
-- 		sum(UC1.UnitaAssegnataOpCedente)    UnitaAssegnataOpCedente
-- 		
-- 		from
-- 		(
-- 			select
-- 			UC1_CO.IdContratto,
-- 			UC1_CO.CodiceOperatoreSDCAcquirente,
-- 			UC1_CO.CodiceOperatoreSDCCedente,
-- 			UC1_UR.CodiceUnitaSDC,
-- 			UC1_UR.CategoriaUnitaSDC,
-- 			
-- 			case when (UC1_CO.CodiceOperatoreSDCAcquirente = UC1_UR.CodiceOperatoreSDC) and (UC1_U.TipoUnita <> 'P') then 1 else 0 end UnitaAssegnataOpAcquirente,
-- 			case when (UC1_CO.CodiceOperatoreSDCCedente    = UC1_UR.CodiceOperatoreSDC) and (UC1_U.TipoUnita <> 'C') then 1 else 0 end UnitaAssegnataOpCedente
-- 			
-- 			from Contratto UC1_CO
-- 
-- 			inner join UnitRelate UC1_UR
-- 			on  UC1_UR.Abilitata = 1
--  			and UC1_UR.TrUC = 1
-- 			and UC1_UR.DataInizioValidita <= @DataProgramma
-- 			and UC1_UR.DataFineValidita >= @DataProgramma
-- 
-- 			inner join SDC_Unita UC1_U
-- 			on  UC1_UR.CodiceUnitaSDC = UC1_U.CodiceUnitaSDC
-- 			and UC1_UR.CategoriaUnitaSDC = UC1_U.CategoriaUnitaSDC
-- 		
-- 			where 
-- 			    UC1_CO.IdContratto = @IdContratto
-- 			and UC1_CO.DataInizioValidita <= @DataProgramma
-- 			AND UC1_CO.DataFineValidita >= @DataProgramma
-- 			AND UC1_CO.TrCN = 1
-- 			AND UC1_CO.StatoContratto = 'Abilitato'
-- 			and 
-- 			(
-- 				(UC1_CO.CodiceOperatoreSDCAcquirente = UC1_UR.CodiceOperatoreSDC and UC1_U.TipoUnita <> 'P' )
-- 			or
-- 				(UC1_CO.CodiceOperatoreSDCCedente    = UC1_UR.CodiceOperatoreSDC and UC1_U.TipoUnita <> 'C' )
-- 			)
-- 		) UC1
-- 		group by 
-- 		UC1.IdContratto,
-- 		UC1.CodiceOperatoreSDCAcquirente,
-- 		UC1.CodiceOperatoreSDCCedente,
-- 		UC1.CodiceUnitaSDC,
-- 		UC1.CategoriaUnitaSDC
-- 	) UC2
-- 	inner join Ore
-- 	on Ora <= @OraLimite
-- 	WHERE 
-- 	(UnitaAssegnataOpAcquirente = 1 AND CodiceOperatoreSDCAcquirente=@Operatore) 
-- 	OR
-- 	(UnitaAssegnataOpCedente = 1 AND CodiceOperatoreSDCCedente=@Operatore)
-- ) UC
-- LEFT OUTER JOIN
-- (
-- 	SELECT
-- 	IdContratto,
-- 	PeriodoRilevante,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC,
-- 	ProgrammatoDalCedente,
-- 	ProgOrarioDellUnitaValidato
-- 	FROM ProgrammaOrarioPerUnita
-- 	WHERE 
-- 	IdContratto = @IdContratto 
-- 	AND DataProgramma = @DataProgramma
-- )
-- POU2
-- ON POU2.IdContratto = UC.IdContratto
-- AND POU2.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- AND POU2.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- AND POU2.PeriodoRilevante = UC.PeriodoRilevante
-- 
-- LEFT OUTER JOIN
-- (
-- 	SELECT 
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	ProgrammaOrarioValidato,
-- 	Bilanciato,
-- 	SbilanciamentoMWh
-- 	FROM ProgrammaOrario 
-- 	WHERE 
-- 	IdCOntratto = @IdContratto
-- 	and DataProgramma = @DataProgramma
-- ) PO2
-- ON PO2.IdContratto = UC.IdContratto
-- AND PO2.PeriodoRilevante = UC.PeriodoRilevante
-- 
-- GROUP BY UC.IdContratto, 
-- 	UC.PeriodoRilevante,
-- 	po2.ProgrammaOrarioValidato,
--  	PO2.Bilanciato,
--  	PO2.SbilanciamentoMWh
-- order by
-- UC.PeriodoRilevante
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammaOrarioContrattoClient]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammaOrarioContrattoClient]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammaOrarioContrattoClient]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- 
-- CREATE   PROCEDURE dbo.spBilGetProgrammazione23
-- 	@DataProgramma smalldatetime
-- AS
-- 
-- -- usiamo read uncommitted perche` i dati che si ritornano da questa query 
-- -- sono "accorpamenti"
-- set transaction isolation level read uncommitted
-- 
-- 
-- select
-- 	PU.IdContratto,
-- 		
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end) 			C01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end) 			C02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end) 			C03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end) 			C04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end) 			C05,
-- 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end) 			C06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end) 			C07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end) 			C08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end) 			C09,
--   	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
--  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
--  	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
-- -- 	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
-- -- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,
-- 
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end) 			A01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end) 			A02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end) 			A03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end) 			A04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
--   	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end) 			A06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end) 			A07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end) 			A08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end) 			A09,
--  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
--   	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
--     sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
-- -- 	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
-- -- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25
-- 
--  	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end) B01,
--  	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end) B02,
--  	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end) B03,
--  	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end) B04,
--  	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end) B05,
--  	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) B06,
--  	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) B07,
--  	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) B08,
--  	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) B09,
--  	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) B10,
--  	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) B11,
--  	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) B12,
--  	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) B13,
--  	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) B14,
--  	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) B15,
--  	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) B16,
--  	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) B17,
--  	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) B18,
--  	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) B19,
--  	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) B20,
--  	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) B21,
--  	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) B22,
--  	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) B23,
-- -- 	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) B24,
-- -- 	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) B25,
-- 
-- 	PU.CRN,
-- 	PU.CodiceContratto
-- FROM
-- (
-- 	SELECT 
-- 	CC.IdContratto, 
-- 	Ore.Ora PeriodoRilevante,
-- 	CC.CRN,
-- 	CC.CodiceContratto,
-- 	case
-- 	when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
-- 	when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
-- 	else
-- 		case sign(PO.SbilanciamentoMWh) 
-- 		when 1 then	 -- eccesso di produzione: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- taglia sempre, 'rosso'
-- 			when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
-- 			when 'C' then		-- solo se cons. maggiore prod.
--  				case CC.IsGMEOpAcquirente 
--  					when 1 then 4	-- 'blu'  
--  					when 0 then 3	-- 'arancione' 
--  				end 
-- 			when 'M' then 
-- 				case CC.IsGMEOpAcquirente 
-- 					when 1 then 4   -- 'blu'
-- 					when 0 then 3	-- 'arancione'
-- 				end 
-- 			end
-- 		when -1 then 	-- eccesso di consumo: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- 'taglia sempre, rosso'
-- 			when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
-- 			when 'P' then		-- solo se prod. maggiore cons.
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			when 'M' then
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			end
-- 		end
-- 	end Sbilanciamento,
-- 	case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end TotUnitaAssCed, -- 0 rosso, 1 verde
-- 	case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end TotUnitaAssAcq
-- 	FROM 
-- 	(
-- 			SELECT 	CO.IdContratto,
-- 				CO.CRN,
-- 				CO.CodiceContratto,
-- 				CO.GestioneTaglio,
-- 				OA.IsGMEOp IsGMEOpAcquirente,
-- 				OC.IsGMEOp IsGMEOpCedente
-- 			FROM Contratto CO, 
-- 				Operatori OA,
-- 				Operatori OC
-- 			WHERE   CO.DataInizioValidita <= @DataProgramma
-- 			AND CO.DataFineValidita >= @DataProgramma
-- 		 	AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
-- 	 		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
-- 			AND CO.StatoContratto='Abilitato'
-- 			AND CO.TrCN = 1
-- 	) CC
-- 	CROSS JOIN 
-- 	(
-- 	SELECT Ora 
-- 	FROM Ore 
-- 	WHERE Ore.Ora <= 23
-- 	) Ore
-- 	LEFT OUTER JOIN ProgrammaOrario PO
-- 	ON PO.IdContratto = CC.IdContratto
-- 	AND PO.PeriodoRilevante = Ore.Ora
-- 	AND PO.DataProgramma = @DataProgramma
-- 	AND PO.ProgrammaOrarioValidato = 1
-- 	LEFT OUTER JOIN (
-- 		SELECT 
-- 		IdContratto, 
-- 		PeriodoRilevante, 
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
-- 		FROM programmaorarioperunita
-- 		WHERE DataProgramma = @DataProgramma
-- 		AND ProgOrarioDellUnitaValidato=1
-- 		GROUP BY IdContratto, PeriodoRIlevante
-- 	) POU
-- 	ON PO.PeriodoRilevante = POU.PeriodoRilevante
-- 	AND PO.IdContratto = POU.IdContratto
-- ) PU
-- GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto
-- ORDER BY PU.CRN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione23]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione23]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione23]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- 
-- CREATE   PROCEDURE  dbo.spBilGetProgrammazione24
-- 	@DataProgramma datetime --varchar(100) --smalldatetime
-- AS
-- --declare @DataProgramma smalldatetime
-- --set @DataProgramma = @DataProgramma2
-- --set @DataProgramma = convert(smalldatetime, @DataProgramma2, 105) --'07/05/2004' 105 = it-IT, 101 = en-US
-- SET NOCOUNT ON;
-- 
-- -- usiamo read uncommitted perche` i dati che si ritornano da questa query 
-- -- sono "accorpamenti"
-- set transaction isolation level read uncommitted
-- 
-- select
-- 	PU.IdContratto,
-- 		
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end) 			C01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end) 			C02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end) 			C03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end) 			C04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end) 			C05,
-- 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end) 			C06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end) 			C07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end) 			C08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end) 			C09,
--   	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
--  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
--  	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
--   	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
-- -- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,
-- 
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end) 			A01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end) 			A02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end) 			A03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end) 			A04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
--   	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end) 			A06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end) 			A07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end) 			A08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end) 			A09,
--  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
--   	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
--     sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
--    	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
-- -- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,
-- 
--  	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end) B01,
--  	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end) B02,
--  	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end) B03,
--  	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end) B04,
--  	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end) B05,
--  	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) B06,
--  	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) B07,
--  	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) B08,
--  	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) B09,
--  	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) B10,
--  	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) B11,
--  	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) B12,
--  	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) B13,
--  	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) B14,
--  	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) B15,
--  	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) B16,
--  	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) B17,
--  	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) B18,
--  	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) B19,
--  	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) B20,
--  	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) B21,
--  	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) B22,
--  	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) B23,
--  	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) B24,
-- -- 	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) B25,
-- 
-- 	PU.CRN,
-- 	PU.CodiceContratto
-- FROM
-- (
-- 	SELECT 
-- 	CC.IdContratto, 
-- 	Ore.Ora PeriodoRilevante,
-- 	CC.CRN,
-- 	CC.CodiceContratto,
-- 	case
-- 	when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
-- 	when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
-- 	else
-- 		case sign(PO.SbilanciamentoMWh) 
-- 		when 1 then	 -- eccesso di produzione: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- taglia sempre, 'rosso'
-- 			when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
-- 			when 'C' then		-- solo se cons. maggiore prod.
--  				case CC.IsGMEOpAcquirente 
--  					when 1 then 4	-- 'blu'  
--  					when 0 then 3	-- 'arancione' 
--  				end 
-- 			when 'M' then 
-- 				case CC.IsGMEOpAcquirente 
-- 					when 1 then 4   -- 'blu'
-- 					when 0 then 3	-- 'arancione'
-- 				end 
-- 			end
-- 		when -1 then 	-- eccesso di consumo: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- 'taglia sempre, rosso'
-- 			when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
-- 			when 'P' then		-- solo se prod. maggiore cons.
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			when 'M' then
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			end
-- 		end
-- 	end Sbilanciamento,
-- 	case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end TotUnitaAssCed, -- 0 rosso, 1 verde
-- 	case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end TotUnitaAssAcq
-- 	FROM 
-- 	(
-- 			SELECT 	CO.IdContratto,
-- 				CO.CRN,
-- 				CO.CodiceContratto,
-- 				CO.GestioneTaglio,
-- 				OA.IsGMEOp IsGMEOpAcquirente,
-- 				OC.IsGMEOp IsGMEOpCedente
-- 			FROM Contratto CO, 
-- 				Operatori OA,
-- 				Operatori OC
-- 			WHERE   CO.DataInizioValidita <= @DataProgramma
-- 				AND CO.DataFineValidita >= @DataProgramma
-- 			 	AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
-- 		 		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
-- 				AND CO.StatoContratto='Abilitato'
-- 				AND CO.TrCN = 1
-- 	) CC
-- 	CROSS JOIN 
-- 	(
-- 	SELECT Ora 
-- 	FROM Ore 
-- 	WHERE Ore.Ora <= 24
-- 	) Ore
-- 	LEFT OUTER JOIN ProgrammaOrario PO
-- 	ON PO.IdContratto = CC.IdContratto
-- 	AND PO.PeriodoRilevante = Ore.Ora
-- 	AND PO.DataProgramma = @DataProgramma
-- 	AND PO.ProgrammaOrarioValidato = 1
-- 	LEFT OUTER JOIN (
-- 		SELECT 
-- 		IdContratto, 
-- 		PeriodoRilevante, 
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
-- 		FROM programmaorarioperunita
-- 		WHERE DataProgramma = @DataProgramma
-- 		AND ProgOrarioDellUnitaValidato=1
-- 		GROUP BY IdContratto, PeriodoRIlevante
-- 	) POU
-- 	ON PO.PeriodoRilevante = POU.PeriodoRilevante
-- 	AND PO.IdContratto = POU.IdContratto
-- ) PU
-- GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto
-- ORDER BY PU.CRN
-- RETURN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione24]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione24]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione24]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- 
-- CREATE   PROCEDURE dbo.spBilGetProgrammazione25
-- 	@DataProgramma smalldatetime
-- AS
-- 
-- -- usiamo read uncommitted perche` i dati che si ritornano da questa query 
-- -- sono "accorpamenti"
-- set transaction isolation level read uncommitted
-- 
-- 
-- select
-- 	PU.IdContratto,
-- 		
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end) 			C01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end) 			C02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end) 			C03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end) 			C04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end) 			C05,
-- 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end) 			C06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end) 			C07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end) 			C08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end) 			C09,
--   	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
--  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
--  	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
--   	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
--  	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,
-- 
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end) 			A01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end) 			A02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end) 			A03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end) 			A04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
--   	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end) 			A06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end) 			A07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end) 			A08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end) 			A09,
--  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
--   	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
-- 
--     sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
--    	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
--  	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,
-- 
--  	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end) B01,
--  	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end) B02,
--  	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end) B03,
--  	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end) B04,
--  	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end) B05,
--  	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) B06,
--  	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) B07,
--  	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) B08,
--  	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) B09,
--  	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) B10,
--  	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) B11,
--  	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) B12,
--  	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) B13,
--  	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) B14,
--  	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) B15,
--  	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) B16,
--  	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) B17,
--  	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) B18,
--  	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) B19,
--  	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) B20,
--  	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) B21,
--  	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) B22,
--  	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) B23,
--  	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) B24,
--  	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) B25,
-- 
-- 	PU.CRN,
-- 	PU.CodiceContratto
-- FROM
-- (
-- 	SELECT 
-- 	CC.IdContratto, 
-- 	Ore.Ora PeriodoRilevante,
-- 	CC.CRN,
-- 	CC.CodiceContratto,
-- 	case
-- 	when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
-- 	when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
-- 	else
-- 		case sign(PO.SbilanciamentoMWh) 
-- 		when 1 then	 -- eccesso di produzione: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- taglia sempre, 'rosso'
-- 			when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
-- 			when 'C' then		-- solo se cons. maggiore prod.
--  				case CC.IsGMEOpAcquirente 
--  					when 1 then 4	-- 'blu'  
--  					when 0 then 3	-- 'arancione' 
--  				end 
-- 			when 'M' then 
-- 				case CC.IsGMEOpAcquirente 
-- 					when 1 then 4   -- 'blu'
-- 					when 0 then 3	-- 'arancione'
-- 				end 
-- 			end
-- 		when -1 then 	-- eccesso di consumo: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- 'taglia sempre, rosso'
-- 			when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
-- 			when 'P' then		-- solo se prod. maggiore cons.
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			when 'M' then
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			end
-- 		end
-- 	end Sbilanciamento,
-- 	case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end TotUnitaAssCed, -- 0 rosso, 1 verde
-- 	case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end TotUnitaAssAcq
-- 	FROM 
-- 	(
-- 			SELECT 	CO.IdContratto,
-- 				CO.CRN,
-- 				CO.CodiceContratto,
-- 				CO.GestioneTaglio,
-- 				OA.IsGMEOp IsGMEOpAcquirente,
-- 				OC.IsGMEOp IsGMEOpCedente
-- 			FROM Contratto CO, 
-- 				Operatori OA,
-- 				Operatori OC
-- 			WHERE   CO.DataInizioValidita <= @DataProgramma
-- 			AND CO.DataFineValidita >= @DataProgramma
-- 		 	AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
-- 	 		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
-- 			AND CO.StatoContratto='Abilitato'
-- 			AND CO.TrCN = 1
-- 
-- 	) CC
-- 	CROSS JOIN 
-- 	(
-- 	SELECT Ora 
-- 	FROM Ore 
-- 	WHERE Ore.Ora <= 25
-- 	) Ore
-- 	LEFT OUTER JOIN ProgrammaOrario PO
-- 	ON PO.IdContratto = CC.IdContratto
-- 	AND PO.PeriodoRilevante = Ore.Ora
-- 	AND PO.DataProgramma = @DataProgramma
-- 	LEFT OUTER JOIN (
-- 		SELECT 
-- 		IdContratto, 
-- 		PeriodoRilevante, 
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
-- 		FROM programmaorarioperunita
-- 		WHERE DataProgramma = @DataProgramma
-- 		AND ProgOrarioDellUnitaValidato=1
-- 		GROUP BY IdContratto, PeriodoRIlevante
-- 	) POU
-- 	ON PO.PeriodoRilevante = POU.PeriodoRilevante
-- 	AND PO.IdContratto = POU.IdContratto
-- ) PU
-- GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto
-- ORDER BY PU.CRN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione25]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione25]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazione25]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- 
-- CREATE   PROCEDURE dbo.spBilGetProgrammazioneClient23
-- 	 @DataProgramma smalldatetime,
-- 	@Operatore varchar(16)
-- AS
-- 
-- -- usiamo read uncommitted perche` i dati che si ritornano da questa query 
-- -- sono "accorpamenti"
-- set transaction isolation level read uncommitted
-- 
-- 
-- --declare @DataProgramma smalldatetime,
-- --	@Operatore varchar(16)
-- 
-- --select @DataProgramma = '04/20/2004'
-- --select @Operatore = 'IDGRTN'
-- 
-- --SELECT * FROM CONTRATTO WHERE (CodiceOperatoreSDCAcquirente=@Op OR
-- --				CodiceOperatoreSDCCedente=@Op)
-- 
-- select
-- 	PU.IdContratto,
-- 		
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end) 			C01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end) 			C02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end) 			C03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end) 			C04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end) 			C05,
-- 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end) 			C06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end) 			C07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end) 			C08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end) 			C09,
--   	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
--  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
--  	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
-- -- 	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
-- -- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,
-- 
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end) 			A01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end) 			A02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end) 			A03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end) 			A04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
--   	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end) 			A06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end) 			A07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end) 			A08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end) 			A09,
--  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
--   	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
-- 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
-- -- 	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
-- -- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,
-- 
--  	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end) B01,
--  	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end) B02,
--  	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end) B03,
--  	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end) B04,
--  	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end) B05,
--  	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) B06,
--  	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) B07,
--  	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) B08,
--  	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) B09,
--  	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) B10,
--  	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) B11,
--  	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) B12,
--  	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) B13,
--  	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) B14,
--  	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) B15,
--  	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) B16,
--  	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) B17,
--  	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) B18,
--  	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) B19,
--  	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) B20,
--  	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) B21,
--  	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) B22,
--  	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) B23,
-- -- 	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) B24,
-- -- 	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) B25,
-- 
-- 	PU.CRN,
-- 	PU.CodiceContratto,
-- 	PU.CodiceOperatoreSDCAcquirente Acquirente,
-- 	PU.CodiceOperatoreSDCCedente Cedente
-- FROM
-- (
-- 	SELECT 
-- 	CC.IdContratto, 
-- 	Ore.Ora PeriodoRilevante,
-- 	CC.CRN,
-- 	CC.CodiceContratto,
-- 	CC.CodiceOperatoreSDCAcquirente,
-- 	CC.CodiceOperatoreSDCCedente,
-- 	case
-- 	when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
-- 	when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
-- 	else
-- 		case sign(PO.SbilanciamentoMWh) 
-- 		when 1 then	 -- eccesso di produzione: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- taglia sempre, 'rosso'
-- 			when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
-- 			when 'C' then		-- solo se cons. maggiore prod.
--  				case CC.IsGMEOpAcquirente 
--  					when 1 then 4	-- 'blu'  
--  					when 0 then 3	-- 'arancione' 
--  				end 
-- 			when 'M' then 
-- 				case CC.IsGMEOpAcquirente 
-- 					when 1 then 4   -- 'blu'
-- 					when 0 then 3	-- 'arancione'
-- 				end 
-- 			end
-- 		when -1 then 	-- eccesso di consumo: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- 'taglia sempre, rosso'
-- 			when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
-- 			when 'P' then		-- solo se prod. maggiore cons.
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			when 'M' then
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			end
-- 		end
-- 	end Sbilanciamento,
-- 	case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end TotUnitaAssCed, -- 0 rosso, 1 verde
-- 	case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end TotUnitaAssAcq
-- 	FROM 
-- 	(
-- 			SELECT 	CO.IdContratto,
-- 				CO.CRN,
-- 				CO.CodiceContratto,
-- 				CO.GestioneTaglio,
-- 				CO.CodiceOperatoreSDCAcquirente,
-- 				OA.IsGMEOp IsGMEOpAcquirente,
-- 				CO.CodiceOperatoreSDCCedente,
-- 				OC.IsGMEOp IsGMEOpCedente
-- 			FROM Contratto CO, 
-- 				Operatori OA,
-- 				Operatori OC
-- 			WHERE   CO.DataInizioValidita <= @DataProgramma
-- 				AND CO.DataFineValidita >= @DataProgramma
-- 			 	AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
-- 		 		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
-- 				AND (CO.CodiceOperatoreSDCAcquirente=@Operatore OR CO.CodiceOperatoreSDCCedente=@Operatore)
-- 				AND CO.StatoContratto='Abilitato'
-- 				AND CO.TrCN = 1
-- 
-- 	) CC
-- 	CROSS JOIN 
-- 	(
-- 	SELECT Ora 
-- 	FROM Ore 
-- 	WHERE Ore.Ora <= 23
-- 	) Ore
-- 	LEFT OUTER JOIN ProgrammaOrario PO
-- 	ON PO.IdContratto = CC.IdContratto
-- 	AND PO.PeriodoRilevante = Ore.Ora
-- 	AND PO.DataProgramma = @DataProgramma
-- 	AND PO.ProgrammaOrarioValidato = 1
-- 	LEFT OUTER JOIN (
-- 		SELECT 
-- 		IdContratto, 
-- 		PeriodoRilevante, 
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
-- 		FROM programmaorarioperunita
-- 		WHERE DataProgramma = @DataProgramma
-- 		AND ProgOrarioDellUnitaValidato=1
-- 		GROUP BY IdContratto, PeriodoRIlevante
-- 	) POU
-- 	ON PO.PeriodoRilevante = POU.PeriodoRilevante
-- 	AND PO.IdContratto = POU.IdContratto
-- ) PU
-- GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto, PU.CodiceOperatoreSDCAcquirente, PU.CodiceOperatoreSDCCedente
-- ORDER BY PU.CRN
-- RETURN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient23]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient23]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient23]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- 
-- CREATE   PROCEDURE dbo.spBilGetProgrammazioneClient24
-- 	 @DataProgramma datetime,
-- 	@Operatore varchar(16)
-- AS
-- 
-- -- usiamo read uncommitted perche` i dati che si ritornano da questa query 
-- -- sono "accorpamenti"
-- set transaction isolation level read uncommitted
-- 
-- 
-- --declare @DataProgramma smalldatetime,
-- --	@Operatore varchar(16)
-- 
-- --select @DataProgramma = '04/20/2004'
-- --select @Operatore = 'IDGRTN'
-- 
-- --SELECT * FROM CONTRATTO WHERE (CodiceOperatoreSDCAcquirente=@Op OR
-- --				CodiceOperatoreSDCCedente=@Op)
-- 
-- SET NOCOUNT ON;
-- 
-- select
-- 	PU.IdContratto,
-- 		
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end) 			C01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end) 			C02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end) 			C03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end) 			C04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end) 			C05,
-- 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end) 			C06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end) 			C07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end) 			C08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end) 			C09,
--   	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
--  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
--  	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
--   	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
-- -- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,
-- 
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end) 			A01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end) 			A02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end) 			A03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end) 			A04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
--   	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end) 			A06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end) 			A07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end) 			A08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end) 			A09,
--  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
--   	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
-- 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
--    	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
-- -- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,
-- 
--  	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end) B01,
--  	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end) B02,
--  	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end) B03,
--  	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end) B04,
--  	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end) B05,
--  	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) B06,
--  	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) B07,
--  	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) B08,
--  	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) B09,
--  	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) B10,
--  	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) B11,
--  	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) B12,
--  	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) B13,
--  	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) B14,
--  	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) B15,
--  	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) B16,
--  	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) B17,
--  	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) B18,
--  	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) B19,
--  	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) B20,
--  	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) B21,
--  	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) B22,
--  	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) B23,
--  	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) B24,
-- -- 	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) B25,
-- 
-- 	PU.CRN,
-- 	PU.CodiceContratto,
-- 	PU.CodiceOperatoreSDCAcquirente Acquirente,
-- 	PU.CodiceOperatoreSDCCedente Cedente
-- FROM
-- (
-- 	SELECT 
-- 	CC.IdContratto, 
-- 	Ore.Ora PeriodoRilevante,
-- 	CC.CRN,
-- 	CC.CodiceContratto,
-- 	CC.CodiceOperatoreSDCAcquirente,
-- 	CC.CodiceOperatoreSDCCedente,
-- 	case
-- 	when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
-- 	when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
-- 	else
-- 		case sign(PO.SbilanciamentoMWh) 
-- 		when 1 then	 -- eccesso di produzione: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- taglia sempre, 'rosso'
-- 			when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
-- 			when 'C' then		-- solo se cons. maggiore prod.
--  				case CC.IsGMEOpAcquirente 
--  					when 1 then 4	-- 'blu'  
--  					when 0 then 3	-- 'arancione' 
--  				end 
-- 			when 'M' then 
-- 				case CC.IsGMEOpAcquirente 
-- 					when 1 then 4   -- 'blu'
-- 					when 0 then 3	-- 'arancione'
-- 				end 
-- 			end
-- 		when -1 then 	-- eccesso di consumo: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- 'taglia sempre, rosso'
-- 			when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
-- 			when 'P' then		-- solo se prod. maggiore cons.
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			when 'M' then
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			end
-- 		end
-- 	end Sbilanciamento,
-- 	case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end TotUnitaAssCed, -- 0 rosso, 1 verde
-- 	case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end TotUnitaAssAcq
-- 	FROM 
-- 	(
-- 			SELECT 	CO.IdContratto,
-- 			CO.CRN,
-- 			CO.CodiceContratto,
-- 			CO.GestioneTaglio,
-- 			CO.CodiceOperatoreSDCAcquirente,
-- 			OA.IsGMEOp IsGMEOpAcquirente,
-- 			CO.CodiceOperatoreSDCCedente,
-- 			OC.IsGMEOp IsGMEOpCedente
-- 			FROM Contratto CO, 
-- 			Operatori OA,
-- 			Operatori OC
-- 			WHERE   
-- 			CO.DataInizioValidita <= @DataProgramma
-- 			AND CO.DataFineValidita >= @DataProgramma
-- 		 	AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
-- 	 		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
-- 			AND (CO.CodiceOperatoreSDCAcquirente=@Operatore OR CO.CodiceOperatoreSDCCedente=@Operatore)
-- 			AND CO.StatoContratto='Abilitato'
-- 			AND CO.TrCN = 1
-- 	) CC
-- 	CROSS JOIN 
-- 	(
-- 	SELECT Ora 
-- 	FROM Ore 
-- 	WHERE Ore.Ora <= 24
-- 	) Ore
-- 	LEFT OUTER JOIN ProgrammaOrario PO
-- 	ON PO.IdContratto = CC.IdContratto
-- 	AND PO.PeriodoRilevante = Ore.Ora
-- 	AND PO.DataProgramma = @DataProgramma
-- 	AND PO.ProgrammaOrarioValidato = 1
-- 	LEFT OUTER JOIN (
-- 		SELECT 
-- 		IdContratto, 
-- 		PeriodoRilevante, 
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
-- 		FROM programmaorarioperunita
-- 		WHERE DataProgramma = @DataProgramma
-- 		AND ProgOrarioDellUnitaValidato=1
-- 		GROUP BY IdContratto, PeriodoRIlevante
-- 	) POU
-- 	ON PO.PeriodoRilevante = POU.PeriodoRilevante
-- 	AND PO.IdContratto = POU.IdContratto
-- ) PU
-- GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto, PU.CodiceOperatoreSDCAcquirente, PU.CodiceOperatoreSDCCedente
-- ORDER BY PU.CRN
-- RETURN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient24]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient24]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient24]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- 
-- CREATE   PROCEDURE dbo.spBilGetProgrammazioneClient25
-- 	 @DataProgramma smalldatetime,
-- 	@Operatore varchar(16)
-- AS
-- 
-- -- usiamo read uncommitted perche` i dati che si ritornano da questa query 
-- -- sono "accorpamenti"
-- set transaction isolation level read uncommitted
-- 
-- 
-- --declare @DataProgramma smalldatetime,
-- --	@Operatore varchar(16)
-- 
-- --select @DataProgramma = '04/20/2004'
-- --select @Operatore = 'IDGRTN'
-- 
-- --SELECT * FROM CONTRATTO WHERE (CodiceOperatoreSDCAcquirente=@Op OR
-- --				CodiceOperatoreSDCCedente=@Op)
-- 
-- select
-- 	PU.IdContratto,
-- 		
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end) 			C01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end) 			C02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end) 			C03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end) 			C04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end) 			C05,
-- 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end) 			C06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end) 			C07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end) 			C08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end) 			C09,
--   	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
--  	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18, 
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
--  	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
--   	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
--  	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,
-- 
--   	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end) 			A01,
--   	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end) 			A02,
--   	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end) 			A03,
--   	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end) 			A04,
--   	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end) 			A05, 
--   	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end) 			A06,
--   	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end) 			A07,
--   	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end) 			A08,
--   	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end) 			A09,
--  	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
--   	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
--   	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
--   	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
--   	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
--   	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
--   	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
--   	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
--   	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
--   	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
-- 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
--   	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
--   	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
--   	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
--    	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
--  	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,
-- 
--  	sum(case PU.PeriodoRilevante when  1 then PU.Sbilanciamento else 0 end) B01,
--  	sum(case PU.PeriodoRilevante when  2 then PU.Sbilanciamento else 0 end) B02,
--  	sum(case PU.PeriodoRilevante when  3 then PU.Sbilanciamento else 0 end) B03,
--  	sum(case PU.PeriodoRilevante when  4 then PU.Sbilanciamento else 0 end) B04,
--  	sum(case PU.PeriodoRilevante when  5 then PU.Sbilanciamento else 0 end) B05,
--  	sum(case PU.PeriodoRilevante when  6 then PU.Sbilanciamento else 0 end) B06,
--  	sum(case PU.PeriodoRilevante when  7 then PU.Sbilanciamento else 0 end) B07,
--  	sum(case PU.PeriodoRilevante when  8 then PU.Sbilanciamento else 0 end) B08,
--  	sum(case PU.PeriodoRilevante when  9 then PU.Sbilanciamento else 0 end) B09,
--  	sum(case PU.PeriodoRilevante when 10 then PU.Sbilanciamento else 0 end) B10,
--  	sum(case PU.PeriodoRilevante when 11 then PU.Sbilanciamento else 0 end) B11,
--  	sum(case PU.PeriodoRilevante when 12 then PU.Sbilanciamento else 0 end) B12,
--  	sum(case PU.PeriodoRilevante when 13 then PU.Sbilanciamento else 0 end) B13,
--  	sum(case PU.PeriodoRilevante when 14 then PU.Sbilanciamento else 0 end) B14,
--  	sum(case PU.PeriodoRilevante when 15 then PU.Sbilanciamento else 0 end) B15,
--  	sum(case PU.PeriodoRilevante when 16 then PU.Sbilanciamento else 0 end) B16,
--  	sum(case PU.PeriodoRilevante when 17 then PU.Sbilanciamento else 0 end) B17,
--  	sum(case PU.PeriodoRilevante when 18 then PU.Sbilanciamento else 0 end) B18,
--  	sum(case PU.PeriodoRilevante when 19 then PU.Sbilanciamento else 0 end) B19,
--  	sum(case PU.PeriodoRilevante when 20 then PU.Sbilanciamento else 0 end) B20,
--  	sum(case PU.PeriodoRilevante when 21 then PU.Sbilanciamento else 0 end) B21,
--  	sum(case PU.PeriodoRilevante when 22 then PU.Sbilanciamento else 0 end) B22,
--  	sum(case PU.PeriodoRilevante when 23 then PU.Sbilanciamento else 0 end) B23,
--  	sum(case PU.PeriodoRilevante when 24 then PU.Sbilanciamento else 0 end) B24,
--  	sum(case PU.PeriodoRilevante when 25 then PU.Sbilanciamento else 0 end) B25,
-- 
-- 	PU.CRN,
-- 	PU.CodiceContratto,
-- 	PU.CodiceOperatoreSDCAcquirente Acquirente,
-- 	PU.CodiceOperatoreSDCCedente Cedente
-- FROM
-- (
-- 	SELECT 
-- 	CC.IdContratto, 
-- 	Ore.Ora PeriodoRilevante,
-- 	CC.CRN,
-- 	CC.CodiceContratto,
-- 	CC.CodiceOperatoreSDCAcquirente,
-- 	CC.CodiceOperatoreSDCCedente,
-- 	case
-- 	when PO.SbilanciamentoMWh IS NULL            then 1    -- 'grigio': bilanciamento non ancora eseguito
-- 	when PO.SbilanciamentoMWh = 0                then 2    -- 'verde'  : bilanciato (all'origine)
-- 	else
-- 		case sign(PO.SbilanciamentoMWh) 
-- 		when 1 then	 -- eccesso di produzione: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- taglia sempre, 'rosso'
-- 			when 'P' then 5		-- solo se prod. maggiore cons., 'rosso'	  
-- 			when 'C' then		-- solo se cons. maggiore prod.
--  				case CC.IsGMEOpAcquirente 
--  					when 1 then 4	-- 'blu'  
--  					when 0 then 3	-- 'arancione' 
--  				end 
-- 			when 'M' then 
-- 				case CC.IsGMEOpAcquirente 
-- 					when 1 then 4   -- 'blu'
-- 					when 0 then 3	-- 'arancione'
-- 				end 
-- 			end
-- 		when -1 then 	-- eccesso di consumo: 
-- 			case CC.GestioneTaglio
-- 			when 'T' then 5		-- 'taglia sempre, rosso'
-- 			when 'C' then 5		-- 'solo se cons. maggiore prod., rosso'	
-- 			when 'P' then		-- solo se prod. maggiore cons.
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			when 'M' then
-- 				case CC.IsGMEOpCedente
-- 					when 1 then 4	-- 'blu'
-- 					when 0 then 4	-- 'blu', caso praticamente impossibile 
-- 				end 
-- 			end
-- 		end
-- 	end Sbilanciamento,
-- 	case isnull(POU.TotUnitaAssCed,0) when 0 then 0 else 1 end TotUnitaAssCed, -- 0 rosso, 1 verde
-- 	case isnull(POU.TotUnitaAssAcq,0) when 0 then 0 else 1 end TotUnitaAssAcq
-- 	FROM 
-- 	(
-- 			SELECT 	CO.IdContratto,
-- 				CO.CRN,
-- 				CO.CodiceContratto,
-- 				CO.GestioneTaglio,
-- 				CO.CodiceOperatoreSDCAcquirente,
-- 				OA.IsGMEOp IsGMEOpAcquirente,
-- 				CO.CodiceOperatoreSDCCedente,
-- 				OC.IsGMEOp IsGMEOpCedente
-- 			FROM Contratto CO, 
-- 				Operatori OA,
-- 				Operatori OC
-- 			WHERE   CO.DataInizioValidita <= @DataProgramma
-- 				AND CO.DataFineValidita >= @DataProgramma
-- 			 	AND OC.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente
-- 		 		AND OA.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente
-- 				AND (CO.CodiceOperatoreSDCAcquirente=@Operatore OR CO.CodiceOperatoreSDCCedente=@Operatore)
-- 				AND CO.StatoContratto='Abilitato'
-- 				AND CO.TrCN = 1
-- 	) CC
-- 	CROSS JOIN 
-- 	(
-- 	SELECT Ora 
-- 	FROM Ore 
-- 	WHERE Ore.Ora <= 25
-- 	) Ore
-- 	LEFT OUTER JOIN ProgrammaOrario PO
-- 	ON PO.IdContratto = CC.IdContratto
-- 	AND PO.PeriodoRilevante = Ore.Ora
-- 	AND PO.DataProgramma = @DataProgramma
-- 	AND PO.ProgrammaOrarioValidato = 1
-- 	LEFT OUTER JOIN (
-- 		SELECT 
-- 		IdContratto, 
-- 		PeriodoRilevante, 
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 0 ELSE 1 END) TotUnitaAssCed,
-- 		SUM (CASE ProgrammatoDalCedente WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq
-- 		FROM programmaorarioperunita
-- 		WHERE DataProgramma = @DataProgramma
-- 		AND ProgOrarioDellUnitaValidato=1
-- 		GROUP BY IdContratto, PeriodoRIlevante
-- 	) POU
-- 	ON PO.PeriodoRilevante = POU.PeriodoRilevante
-- 	AND PO.IdContratto = POU.IdContratto
-- ) PU
-- GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto, PU.CodiceOperatoreSDCAcquirente, PU.CodiceOperatoreSDCCedente
-- ORDER BY PU.CRN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient25]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient25]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilGetProgrammazioneClient25]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE spBilUpdateFlagValidatoPO
-- 	@IdContratto 		int,
-- 	@DataProgramma 	smalldatetime,
-- 	@PeriodoRilevante 	tinyint,
-- 	@Validato 		bit
-- 	
-- AS
-- 
-- BEGIN TRAN
-- 
-- UPDATE ProgrammaOrario 
-- SET ProgrammaOrarioValidato = @Validato, 
-- 	TSCalcoloBilanciamento = NULL, 
-- 	SbilanciamentoMWh = NULL, 
-- 	Bilanciato = NULL 
-- WHERE (IdContratto = @IdContratto) 
-- 	AND (DataProgramma = @DataProgramma) 
-- 	AND (PeriodoRilevante = @PeriodoRilevante)
-- 
-- IF @@ERROR <> 0
-- BEGIN
-- 	ROLLBACK TRAN
-- 	RETURN -1
-- END
-- 
-- UPDATE ProgrammaOrarioPerUnita
-- SET 
-- 	QtyMWhBilanciamento = NULL
-- WHERE  IdContratto = @IdContratto
-- AND DataProgramma = @DataProgramma
-- AND PeriodoRilevante = @PeriodoRilevante
-- 
-- IF @@ERROR <> 0
-- BEGIN
-- 	ROLLBACK TRAN
-- 	RETURN -1
-- END
-- 
-- COMMIT TRAN
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilUpdateFlagValidatoPO]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilUpdateFlagValidatoPO]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilUpdateFlagValidatoPO]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE spBilUpdateFlagValidatoPOU
-- 	@IdContratto 		int,
-- 	@DataProgramma 	smalldatetime,
-- 	@PeriodoRilevante 	tinyint,
-- 	@CodiceUnitaSDC 	varchar(16),
-- 	@CategoriaUnitaSDC 	varchar(1),
-- 	@Validato 		bit
-- 	
-- AS
-- 
-- BEGIN TRAN
-- 
-- UPDATE ProgrammaOrarioPerUnita 
-- SET ProgOrarioDellUnitaValidato = @Validato 
-- WHERE (CodiceUnitaSDC = @CodiceUnitaSDC) 
-- 	AND (CategoriaUnitaSDC = @CategoriaUnitaSDC) 
-- 	AND (IdContratto = @IdContratto) 
-- 	AND (DataProgramma = @DataProgramma) 
-- 	AND (PeriodoRilevante = @PeriodoRilevante)
-- 
-- IF @@ERROR <> 0
-- BEGIN
-- 	ROLLBACK TRAN
-- 	RETURN -1
-- END
-- 
-- UPDATE SessioneBilaterali
-- SET
-- 	Bilanciamento=0,
-- 	Taglio=0
-- WHERE DataProgramma = @DataProgramma
-- 
-- 
-- IF @@ERROR <> 0
-- BEGIN
-- 	ROLLBACK TRAN
-- 	RETURN -1
-- END
-- 
-- UPDATE ProgrammaOrario
-- SET 
-- 	TSCalcoloBilanciamento = NULL,
-- 	SbilanciamentoMWh = NULL,
-- 	Bilanciato = NULL
-- WHERE IdContratto = @IdContratto 
-- 	AND DataProgramma = @DataProgramma
-- 	AND PeriodoRilevante = @PeriodoRilevante
-- 
-- IF @@ERROR <> 0
-- BEGIN
-- 	ROLLBACK TRAN
-- 	RETURN -1
-- END
-- 
-- COMMIT TRAN
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilUpdateFlagValidatoPOU]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilUpdateFlagValidatoPOU]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilUpdateFlagValidatoPOU]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE  PROCEDURE [dbo].[spBilanciamentoForzato]
--  	@DataProgramma smalldatetime,
--  	@SogliaSbilMWh float,
-- 	@AzzeraSbilanciamento bit = 1,
-- 	@RicalcolaBilanciamento bit = 1
-- AS
-- 
-- -- stored procedure che calcola e memorizza il bilanciamento
-- -- dei programmi di un dato giorno
-- 
-- 
-- -- declare @DataProgramma          smalldatetime
-- -- declare @SogliaSbilMWh          float
-- -- declare @AzzeraSbilanciamento   bit
-- -- declare @RicalcolaBilanciamento bit
-- -- 
-- -- set @DataProgramma = '17/9/2004'
-- -- set @SogliaSbilMWh = 0.001
-- -- set @AzzeraSbilanciamento = 1
-- -- set @RicalcolaBilanciamento = 1
-- 
-- -- Nuova delibera
-- -- sto facendo il bilanciamento forzato.
-- -- congelo lo stato di GestioneTaglio, IsGMEOp
-- -- nella tabella PO in modo da avere la "storia" delle scelte effettuate in questa sp.
-- -- Lo faccio prima del loop con il cursore in quanto
-- -- devo congelare lo stato di GestioneTaglio, IsGMEOp
-- -- a prescindere se faccio il taglio forzato o no
-- --
-- -- NOTARE che
-- -- il bilanciamento forzato opera sui programmi con Bilanciato=0
-- -- nel rispetto dei criteri di flessibilita`: (T P C M opGME)
-- -- se il bilanciamento forzato non viene effettuato (il contratto es ammette pgm sbilanciati)
-- -- il campo Bilancito rimane ad 0
-- -- Dato che prima di iniziare il taglio viene chiamata
-- -- exec spCalcolaBilanciamento @DataProgramma, @SogliaSbilMWh
-- -- siamo sicuri che se Bilanciato e`
-- -- null: il programma NON deve andare a mercato
-- -- 1: il programma e' bilanciato all'origine
-- -- 0: il programma non e' bilanciato all'origine
-- -- Dopo il taglio che porta i programmi con Bilanciato=0 a Bilanciato=1
-- -- (se questi non hanno la flessibilita` di essere sbilanciati)
-- -- avremo un po' di programmi con bilanciato=1 e un po' con bilanciato=1
-- -- ENTRAMBI devono andare a mercato, ossia le offerte devono solo controllare bilanciato<>null
-- 
-- update ProgrammaOrario
-- set
-- GestioneTaglio = Q.GestioneTaglio,
-- IsGMEOp        = Q.IsGMEOp
-- from ProgrammaOrario PO
-- inner join
-- (
-- 	select
-- 	Contratto.IdContratto        IdContratto,
-- 	Contratto.GestioneTaglio     GestioneTaglio,
-- 	IsNull(Operatori.IsGMEOp, 0) IsGMEOp
-- 	from Contratto
-- 	inner join Operatori
-- 	on Contratto.CodiceOperatoreSDCAcquirente = Operatori.CodiceOperatoreSDC
-- ) Q
-- on 
-- PO.IdContratto = Q.IdContratto
-- where 
-- DataProgramma = @DataProgramma
-- -- fine nuova delibera
-- 
-- -------------------------------------------------------------------------
-- -------------------------------------------------------------------------
-- 
-- 
-- 
-- declare @IdContratto Int
-- declare @PeriodoRilevante TinyInt
-- declare @CodiceUnitaSDC varchar(16)
-- declare @CategoriaUnitaSDC varchar(1)
-- declare @SbilanciamentoMWh float
-- declare @QtyMWh float
-- declare @KU float
-- declare @KP float
-- declare @QTogliere float
-- 
-- -- per non sbagliare metto a 3 cifre la soglia di sbilanciamento
-- set @SogliaSbilMWh = round(@SogliaSbilMWh, 3)
-- 
-- -- aggiorno tutti i record di PO
-- -- per la data in questione.
-- -- In PO.Bilanciato si ha NULL se quella programmazione, per qualche motivo, non deve essere bilanciata
-- -- Bilanciato = 1 o Bilanciato = 0
-- exec spCalcolaBilanciamento @DataProgramma, @SogliaSbilMWh
-- 
-- declare po_cursor cursor local for
-- 	select 
-- 	IdContratto, 
-- 	PeriodoRilevante, 
-- 	SbilanciamentoMWh 
-- 	from 
-- 	ProgrammaOrario
-- 	where 
-- 	Dataprogramma = @DataProgramma 
-- 	and Bilanciato = 0 -- Notare che qui cerco solo i programmi non Bilanciati,
-- 	-- dunque, quando ricerco i record in POU, non devo fare ulteriormente
-- 	-- la join in PO per trovare se il record in e` PO.ProgrammaOrarioValidato
-- 	-- (comunque per sicurezza lo sia fa)
-- 
-- open po_cursor
-- fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
-- while @@fetch_status = 0 
-- begin
-- 	-- print 'IdContratto:' + cast(@IdContratto as varchar) + ' PeriodoRil.:' + str(@PeriodoRilevante)  + ' SbilMWh=' + str(@SbilanciamentoMWh)
-- 
-- 	if @AzzeraSbilanciamento = 0
-- 	begin
-- 		-- ATTENZIONE: decurto lo SbilanciamentoMWh della soglia 
-- 		-- (per Produzione tolgo, per Consumo aggiungo)
-- 		-- in modo da ottenere un contratto bilanciato con sbilancio uguale a @SogliaSbilMWh
-- 		-- E` OPINABILE
-- 		if @SbilanciamentoMWh > 0
-- 			set	@SbilanciamentoMWh = @SbilanciamentoMWh - @SogliaSbilMWh
-- 		else
-- 			set	@SbilanciamentoMWh = @SbilanciamentoMWh + @SogliaSbilMWh
-- 	end
-- 
-- 	-- print ' SbilMWh(new)=' + str(@SbilanciamentoMWh)
-- 	-- qui trovo la lista delle unita` da decurtare.
-- 	-- L'ordine della select indica di decurtare partendo dall'invio
-- 	-- di programma piu` recente e, a parita` di file, del progressivo piu` grande
--  	declare pou_cursor cursor local keyset for
-- 
--  		select 
-- 		POU.CodiceUnitaSDC, 
-- 		POU.CategoriaUnitaSDC, 
-- 		POU.QtyMWh,
-- 		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
-- 		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
-- 		from 
-- 		ProgrammaOrarioPerUnita POU
-- 
-- 		inner join ProgrammaOrario PO
-- 		on  PO.IdContratto = POU.IdContratto
-- 		and PO.DataProgramma = POU.DataProgramma
-- 		and PO.PeriodoRilevante = POU.PeriodoRilevante
-- 		and PO.ProgrammaOrarioValidato = 1
-- 
-- 		inner join SDC_Unita
-- 		on  POU.CodiceUnitaSDC    = SDC_Unita.CodiceUnitaSDC
-- 		and POU.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
-- 
--  		inner join SDC_PuntiDiScambioRilevanti
-- 		on SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- 
-- 		inner join Contratto
-- 		on Contratto.IdContratto = POU.IdContratto
-- 		and Contratto.StatoContratto = 'Abilitato'
-- 		and Contratto.TrCN = 1 -- dipende dagli stati degli operatori tit/acq/ced
-- 		and Contratto.DataInizioValidita <= @DataProgramma
-- 		and Contratto.DataFineValidita   >= @DataProgramma
-- 		-- Nuova delibera
-- 		-- gli operatori acquirenti devono essere op gme per sopportare pgm sbilanciati
-- 		inner join Operatori OPAcq
-- 		on Contratto.CodiceOperatoreSDCAcquirente = OPAcq.CodiceOperatoreSDC
-- 		and 
-- 		(
-- 			-- tagliare solo se:
-- 			Contratto.GestioneTaglio = 'T' -- il taglio e` da fare sempre
-- 			or 
-- 			( Contratto.GestioneTaglio = 'P' and @SbilanciamentoMWh > 0 ) -- solo se Prod>Cons
-- 			or 
-- 			( Contratto.GestioneTaglio = 'C' and @SbilanciamentoMWh < 0 ) -- solo se Cons>Prod
-- 			or
-- 			( OPAcq.IsGMEOp = 0 or OPAcq.IsGMEOp is null ) -- se l'op non e` del GME
-- 		)
-- 		-- Fine nuova delibera
-- 
-- 		inner join UnitRelate
-- 		on 
-- 		(
-- 			(UnitRelate.CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCCedente    and POU.ProgrammatoDalCedente=1)
-- 			or
-- 			(UnitRelate.CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
-- 		)
-- 		and UnitRelate.CodiceUnitaSDC    = POU.CodiceUnitaSDC
-- 		and UnitRelate.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
-- 		and UnitRelate.Abilitata = 1  -- non cancellato logicamente
--  		and UnitRelate.TrUC = 1       -- dipende SOLO da Unita.StatoBilateraliUnita
-- 		and UnitRelate.DataInizioValidita <= @DataProgramma
-- 		and UnitRelate.DataFineValidita   >= @DataProgramma
-- 
-- 
-- 		where 
-- 		    POU.DataProgramma = @DataProgramma 
-- 		and POU.IdContratto = @IdContratto
-- 		and POU.PeriodoRilevante = @PeriodoRilevante
-- 		and POU.ProgOrarioDellUnitaValidato = 1
-- 		and sign(POU.QtyMWh) = sign(@SbilanciamentoMWh) -- le unita che causano lo sbilanciamento
-- 
-- 		order by 
-- 		POU.IdProgrammaXml desc,
-- 		POU.ProgressivoNelProgramma desc
-- 
--  	open pou_cursor
--  	fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP
-- 
--  	while @@fetch_status = 0
--  	begin
-- 		set @Qtogliere = round(@SbilanciamentoMWh * @KU / @KP, 3)
-- 
-- 		-- ora questa quantita` puo` essere superiore in valore assoluto alla quantita'
-- 		-- dell'unita --> posso azzerare l'unita corrente
-- 		-- per poi riprovarci alla prossima
-- 		If Abs(@Qtogliere) > Abs(@QtyMWh)
-- 		begin
-- 			-- posso togliere solo in parte lo sbilanciamento
-- 			-- togliendo tutta la produzione dell'unita
-- 			set @Qtogliere = @QtyMWh				   -- tolgo tutta la quantita disponibile
-- 			set @SbilanciamentoMWh = @SbilanciamentoMWh - round(@Qtogliere * @KP / @KU, 3)
-- 		end
--  		else
-- 		begin
--  			-- qui ho tolto tutto lo sbilanciamento (per definizione)
--  			set @SbilanciamentoMWh = 0
--  		end 
-- 
-- 		-- print 'Nuova Qty = ' + str(@QtyMWh - @Qtogliere)
-- 
-- 		update 
-- 		ProgrammaOrarioPerUnita
-- 		set QtyMWhBilanciamento = @QtyMWh - @Qtogliere
-- 		where current of pou_cursor
-- 
-- 		-- esco se ho raggiunto la soglia di sbilanciamento max
-- 
-- 		-- notare che:
-- 		-- un contratto prima del calcolo del bilanciamento ha Bilanciato=NULL e SbilanciamentoMWh=NULL
-- 		-- un contratto dopo il calcolo del bilanciamento se bilanciato in origine ha Bilanciato=1 e SbilanciamentoMWh=0
-- 		-- un contratto non bilanciato in origine e prima dell'operazione di taglio ha Bilanciato=0 e SbilanciamentoMWh<>0
-- 		-- un contratto non bilanciato in origine e dopo l'operazione di taglio ha Bilanciato=1 e SbilanciamentoMWh<>0
-- 		-- un contratto che dopo ogni fase ha PO.Bilanciato=NULL indica che non e` valido.
-- 		If Abs(@SbilanciamentoMWh) <= @SogliaSbilMWh
-- 		begin
-- 			-- print 'Esco'
--  			update ProgrammaOrario
--  			set bilanciato = 1
--  			where 
-- 			IdContratto = @IdContratto
--  			and DataProgramma = @DataProgramma
-- 			and PeriodoRilevante = @PeriodoRilevante
-- 			break
-- 		end
-- 
--  		fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP
--  	end
--  	
--  	close pou_cursor
--  	deallocate pou_cursor
-- 
-- 	fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
-- end
-- 
-- close po_cursor
-- deallocate po_cursor
-- 
-- 
-- update 
-- SessioneBilaterali
-- set
-- Taglio=1
-- where DataProgramma=@DataProgramma
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilanciamentoForzato]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilanciamentoForzato]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spBilanciamentoForzato]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- CREATE  PROCEDURE dbo.spCalcolaBilanciamentoPerContratto
-- 	(
-- 		@IdContratto int,
-- 		@DataProgramma smalldatetime,
-- 		@PeriodoRilevante tinyint,
-- 	 	@SogliaSbilMWh float
-- 	)
-- 
-- AS
-- -- non si usa read uncommitted in quanto
-- -- il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri
-- 
-- 
-- 	SET NOCOUNT ON
-- 	
-- 	select 
-- 	IsNull(Sum(round(POU.QtyMWh * UC.KP / UC.KU, 3)), 0) SBilMWh
-- 	from 
-- 	(
-- 		-- trovo tutte le unita per contratto valide 
-- 		-- ossia quelle da programmare per la data in ingresso
-- 		-- (TrCC e TrUC garantiscono che il contratto sia valido, le unita valide, gli operatori validi)
-- 		select 
-- 		UnitaContratto.CodiceUnitaSDC, 
-- 		UnitaContratto.CategoriaUnitaSDC,
-- 		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
-- 		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
-- 		from 
-- 		tab_UnitaContratto2(@DataProgramma, @IdContratto) UnitaContratto, 
-- 		SDC_Unita, 
-- 		SDC_PuntiDiScambioRilevanti,
-- 		Contratto
-- 		where 
-- 		    UnitaContratto.IdContratto = @IdContratto
-- 		and UnitaContratto.IdContratto = Contratto.IdContratto
-- 		and Contratto.DataInizioValidita <= @DataProgramma
-- 		and Contratto.DataFineValidita >= @DataProgramma
-- 		and UnitaContratto.TrCC=1 
-- 		and UnitaContratto.TrUC=1
-- 		and UnitaContratto.UnitaDelContrattoValidata=1
-- 		and UnitaContratto.DataInizioValidita <= @DataProgramma
-- 		and UnitaContratto.DataFineValidita >= @DataProgramma
-- 		and UnitaContratto.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
-- 		and UnitaContratto.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
-- 		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- 	) UC
-- 	inner join
-- 	(
-- 		-- considero i POU validi del giorno per il contratto
-- 		
-- 		SELECT 
-- 			POUI.CodiceUnitaSDC, 
-- 			POUI.CategoriaUnitaSDC, 
-- 			POUI.QtyMWh,
-- 			POUI.IdContratto
-- 		FROM
-- 			(
-- 				SELECT
-- 					ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
-- 					ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
-- 					ProgrammaOrarioPerUnita.QtyMWh,
-- 					ProgrammaOrarioPerUnita.IdContratto,
-- 					ProgrammaOrarioPerUnita.DataProgramma,
-- 					ProgrammaOrarioPerUnita.PeriodoRilevante
-- 				FROM
-- 					ProgrammaOrarioPerUnita
-- 				WHERE
-- 					ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
-- 					and ProgrammaOrarioPerUnita.PeriodoRilevante=@PeriodoRilevante
-- 					and ProgrammaOrarioPerUnita.IdContratto = @IdContratto
-- 					and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
-- 			) POUI
-- 			INNER JOIN
-- 			(
-- 				SELECT 
-- 					ProgrammaOrario.IdContratto,
-- 					ProgrammaOrario.DataProgramma,
-- 					ProgrammaOrario.PeriodoRilevante
-- 				FROM ProgrammaOrario
-- 				WHERE
-- 						ProgrammaOrario.DataProgramma=@DataProgramma
-- 						and ProgrammaOrario.PeriodoRilevante=@PeriodoRilevante
-- 						and ProgrammaOrario.IdContratto= @IdContratto
-- 						and ProgrammaOrario.ProgrammaOrarioValidato=1
-- 			) POI
-- 			ON
-- 				POUI.IdContratto = POI.IdContratto 
-- 				AND POUI.DataProgramma = POI.DataProgramma
-- 				AND POUI.PeriodoRilevante = POI.PeriodoRilevante
-- 	) POU
-- 	ON
-- 	    POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	and POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerContratto]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerContratto]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerContratto]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE  PROCEDURE [dbo].[spEseguiBilanciamentoPerContratto]
-- 	@IdContratto int,
-- 	@DataProgramma smalldatetime,
-- 	@PeriodoRilevante tinyint,
-- 	@SogliaSbilMWh float
-- AS
-- 
-- -- non si usa read uncommitted in quanto
-- -- il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri
-- 
-- 
-- -- declare
-- -- 	@IdContratto int,
-- -- 	@DataProgramma smalldatetime,
-- -- 	@PeriodoRilevante tinyint,
-- -- 	@SogliaSbilMWh float
-- -- 
-- -- set @IdContratto = 212
-- -- set @DataProgramma = '1/12/2004'
-- -- set @PeriodoRilevante = 1
-- -- set @SogliaSbilMWh = 0.001
-- 
-- 
-- -- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno/ora
-- 
-- -- all'uscita della sp avro`
-- -- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o valido non bilanciato.
-- -- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
-- --  (es contratto non valido, unita` non valide ecc)
-- -- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.
-- 
-- 
-- -- per prima cosa azzero le informazioni in PO
-- update ProgrammaOrario
-- set 
-- Bilanciato=NULL,
-- SbilanciamentoMWh=NULL,
-- SbilanciamentoMWhReale=NULL,
-- TSCalcoloBilanciamento=NULL
-- from ProgrammaOrario
-- where
-- IdContratto = @IdContratto
-- and DataProgramma = @DataProgramma
-- and PeriodoRilevante = @PeriodoRilevante
-- 
-- -- e conseguentemente in POU
-- update ProgrammaOrarioPerUnita
-- set 
-- QtyMWhBilanciamento=NULL
-- where DataProgramma = @DataProgramma
-- and PeriodoRilevante = @PeriodoRilevante
-- and IdContratto = @IdContratto
-- and not QtyMWhBilanciamento is null
-- 
-- -- siccome sto facendo il calcolo del bilanciamento, potenzialmente
-- -- e` cambiato il bilanciamento e dunque potenzialemente
-- -- il taglio forzato e` da rifare.
-- update 
-- SessioneBilaterali
-- set
-- Taglio=0
-- where DataProgramma=@DataProgramma
-- 
-- 
-- declare @TSCalcoloBilanciamento as datetime
-- set @TSCalcoloBilanciamento = getdate()
-- 
-- update ProgrammaOrario
-- set 
-- Bilanciato=W.Bilanciato,
-- SbilanciamentoMWh=W.BilMWh,
-- SbilanciamentoMWhReale=W.BilMWhReale,
-- TSCalcoloBilanciamento=@TSCalcoloBilanciamento
-- from ProgrammaOrario PW
-- inner join
-- (
-- 	select
-- 	Q.IdContratto,
-- 	@DataProgramma DataProgramma,
-- 	Q.PeriodoRilevante,
-- 	
-- 	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then 0 else 1 end Bilanciato,
-- 	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
-- 	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
-- 	
-- 	from
-- 	(
-- 		select 
-- 		POU.IdContratto,
-- 		POU.PeriodoRilevante,
-- 		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
-- 		U.CoefficientePerdita KU,
-- 		PR.CoefficienteDiPerdita KP
-- 		
-- 		from ProgrammaOrarioPerUnita POU
-- 		inner join ProgrammaOrario PO
-- 		on
-- 		POU.Idcontratto = PO.IdContratto
-- 		and POU.DataProgramma = PO.DataProgramma
-- 		and POU.PeriodoRilevante = PO.PeriodoRilevante
-- 		and POU.ProgOrarioDellUnitaValidato = 1
-- 		and POU.DataProgramma = @DataProgramma
-- 		and POU.IdContratto = @IdContratto
-- 		and POU.PeriodoRilevante = @PeriodoRilevante
-- 		and PO.ProgrammaOrarioValidato = 1
-- 		
-- 		inner join Contratto CO
-- 		on CO.IdContratto = POU.IdContratto
-- 		and CO.DataInizioValidita <= @DataProgramma
-- 		and CO.DataFineValidita >= @DataProgramma
-- 		and CO.StatoContratto = 'Abilitato'
-- 		and CO.TrCN = 1
-- 		
-- 		inner join UnitRelate UR
-- 		on UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
-- 		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
-- 		and 
-- 		(
-- 			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
-- 			or
-- 			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
-- 		)
-- 		and UR.DataInizioValidita <= @DataProgramma
-- 		and UR.DataFineValidita   >= @DataProgramma
-- 		and UR.Abilitata = 1
-- 		and UR.TrUC = 1
-- 		
-- 		inner join SDC_Unita U
-- 		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
-- 		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
-- 		
-- 		inner join  SDC_PuntiDiScambioRilevanti PR
-- 		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC
-- 
-- 	) Q
-- 	group by IdContratto, PeriodoRilevante
-- 
-- ) W
-- 
-- on  PW.IdContratto = W.IdContratto
-- and PW.DataProgramma = W.DataProgramma
-- and PW.PeriodoRilevante = W.PeriodoRilevante
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spEseguiBilanciamentoPerContratto]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spEseguiBilanciamentoPerContratto]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spEseguiBilanciamentoPerContratto]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE  PROCEDURE dbo.spGeneraOfferte
-- 	@DataRicerca as smalldatetime,
-- 	@OraRicerca as tinyint
-- AS
-- 
-- -- non si usa read uncommitted in quanto
-- -- la generazione delle offerte e` troppo delicata per farla su dati non sicuri
-- 
-- 
-- -- set @DataRicerca = '22/4/4'
-- -- set @OraRicerca = 2
-- 
-- DELETE FROM ProgrammaOrarioPerUnitaErrori
-- WHERE 
-- DataProgramma = @DataRicerca
-- AND PeriodoRilevante = @OraRicerca
-- 
-- UPDATE ProgrammaOrarioPerUnita
-- SET 
-- GMEReferenceNumber = NULL,
-- QtyMWhAssegnataMGP = NULL
-- WHERE
-- DataProgramma = @DataRicerca
-- AND PeriodoRilevante = @OraRicerca
-- 
-- -- genero le offerte (a parte LastError)
-- -- solo per i programmi che hanno PO.Bilanciato <> NULL
-- 
-- SELECT 
-- POU.IdContratto, 
-- POU.CategoriaUnitaSDC, 
-- POU.CodiceUnitaSDC, 
-- POU.QtyMWh, 
-- POU.QtyMWhBilanciamento,
-- CL.LastError
-- 
-- from 
-- ProgrammaOrarioPerUnita POU
-- 
-- inner join ProgrammaOrario PO
-- on  PO.IdContratto      = POU.IdContratto
-- and PO.DataProgramma    = POU.DataProgramma
-- and PO.PeriodoRilevante = POU.PeriodoRilevante
-- and PO.ProgrammaOrarioValidato = 1
-- and PO.Bilanciato is NOT NULL
-- 
-- inner join Contratto CO
-- on  CO.IdContratto = POU.IdContratto
-- and CO.StatoContratto = 'Abilitato'
-- and CO.DataInizioValidita <= @DataRicerca
-- and CO.DataFineValidita >= @DataRicerca
-- and CO.TrCN = 1
-- 
-- inner join XmlProgrammiUtenti XP
-- on XP.IdProgrammaXml = POU.IdProgrammaXml
-- 
-- inner join UnitRelate UR
-- on  
-- (
-- 	(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente = 0)
-- 	or
-- 	(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente = 1)
-- )
-- and UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
-- and UR.DataInizioValidita <= @DataRicerca
-- and UR.DataFineValidita >= @DataRicerca
-- and UR.Abilitata = 1
-- and UR.TrUC = 1
-- 
-- left outer join Certificate_List CL
-- on  XP.CodiceUtenteSDC = CL.CodiceUtenteSDC
-- and XP.Issuer          = CL.Issuer
-- and XP.SerialNumber    = CL.SerialNumber
-- 
-- 
-- where
-- POU.DataProgramma = @DataRicerca
-- and POU.PeriodoRilevante = @OraRicerca
-- and POU.ProgOrarioDellUnitaValidato = 1
-- ORDER BY 
-- POU.IdProgrammaXml, 
-- POU.ProgressivoNelProgramma
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE dbo.spGeneraOfferte_PgmBilanciati 
-- 	@DataRicerca as smalldatetime,
-- 	@OraRicerca as tinyint
-- AS
-- -- set @DataRicerca = '22/4/4'
-- -- set @OraRicerca = 2
-- 
-- 
-- DELETE FROM ProgrammaOrarioPerUnitaErrori
-- WHERE 
-- DataProgramma = @DataRicerca
-- AND PeriodoRilevante = @OraRicerca
-- 
-- UPDATE ProgrammaOrarioPerUnita
-- SET 
-- GMEReferenceNumber = NULL,
-- QtyMWhAssegnataMGP = NULL
-- WHERE
-- DataProgramma = @DataRicerca
-- AND PeriodoRilevante = @OraRicerca
-- 
-- SELECT 
-- ProgrammaOrarioPerUnita.IdContratto, 
-- ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
-- ProgrammaOrarioPerUnita.QtyMWh, 
-- ProgrammaOrarioPerUnita.QtyMWhBilanciamento,
-- Certificate_List.LastError
-- FROM 
-- ProgrammaOrarioPerUnita 
-- INNER JOIN tab_UnitaContratto(@DataRicerca) UnitaContratto 
-- ON ProgrammaOrarioPerUnita.IdContratto = UnitaContratto.IdContratto 
-- AND ProgrammaOrarioPerUnita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC 
-- AND ProgrammaOrarioPerUnita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC 
-- INNER JOIN ProgrammaOrario 
-- ON ProgrammaOrarioPerUnita.IdContratto = ProgrammaOrario.IdContratto 
-- AND ProgrammaOrarioPerUnita.DataProgramma = ProgrammaOrario.DataProgramma 
-- AND ProgrammaOrarioPerUnita.PeriodoRilevante = ProgrammaOrario.PeriodoRilevante 
-- INNER JOIN Contratto
-- ON ProgrammaOrarioPerUnita.IdContratto = Contratto.IdContratto 
-- 
-- INNER JOIN XmlProgrammiUtenti
-- ON XmlProgrammiUtenti.IdProgrammaXml = ProgrammaOrarioPerUnita.IdProgrammaXml
-- LEFT OUTER JOIN Certificate_List
-- ON  XmlProgrammiUtenti.CodiceUtenteSDC = Certificate_List.CodiceUtenteSDC
-- AND XmlProgrammiUtenti.Issuer          = Certificate_List.Issuer
-- AND XmlProgrammiUtenti.SerialNumber    = Certificate_List.SerialNumber
-- 
-- 
-- WHERE 
-- ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca AND 
-- ProgrammaOrarioPerUnita.PeriodoRilevante = @OraRicerca AND
-- ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 AND 
-- ProgrammaOrario.ProgrammaOrarioValidato = 1 AND 
-- ProgrammaOrario.Bilanciato = 1 AND 
-- UnitaContratto.TrCC = 1 AND 
-- UnitaContratto.TrUC = 1 AND 
-- UnitaContratto.UnitaDelContrattoValidata = 1 AND 
-- UnitaContratto.DataInizioValidita <= @DataRicerca AND 
-- UnitaContratto.DataFineValidita >= @DataRicerca AND
-- Contratto.DataInizioValidita <= @DataRicerca AND 
-- Contratto.DataFineValidita >= @DataRicerca
-- ORDER BY 
-- ProgrammaOrarioPerUnita.IdProgrammaXml, 
-- ProgrammaOrarioPerUnita.ProgressivoNelProgramma
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte_PgmBilanciati]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte_PgmBilanciati]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte_PgmBilanciati]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE dbo.spGeneraOfferte_PgmNonBilanciati 
-- 	@DataRicerca as smalldatetime,
-- 	@OraRicerca as tinyint
-- AS
-- -- set @DataRicerca = '22/4/4'
-- -- set @OraRicerca = 2
-- 
-- DELETE FROM ProgrammaOrarioPerUnitaErrori
-- WHERE 
-- DataProgramma = @DataRicerca
-- AND PeriodoRilevante = @OraRicerca
-- 
-- UPDATE ProgrammaOrarioPerUnita
-- SET 
-- GMEReferenceNumber = NULL,
-- QtyMWhAssegnataMGP = NULL
-- WHERE
-- DataProgramma = @DataRicerca
-- AND PeriodoRilevante = @OraRicerca
-- 
-- SELECT 
-- ProgrammaOrarioPerUnita.IdContratto, 
-- ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
-- ProgrammaOrarioPerUnita.QtyMWh, 
-- ProgrammaOrarioPerUnita.QtyMWhBilanciamento,  -- per simmetria con ls spGeneraOfferte_PgmBilanciati
-- Certificate_List.LastError
-- FROM 
-- ProgrammaOrarioPerUnita 
-- INNER JOIN tab_UnitaContratto(@DataRicerca) UnitaContratto 
-- ON ProgrammaOrarioPerUnita.IdContratto = UnitaContratto.IdContratto 
-- AND ProgrammaOrarioPerUnita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC 
-- AND ProgrammaOrarioPerUnita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC 
-- INNER JOIN ProgrammaOrario 
-- ON ProgrammaOrarioPerUnita.IdContratto = ProgrammaOrario.IdContratto 
-- AND ProgrammaOrarioPerUnita.DataProgramma = ProgrammaOrario.DataProgramma 
-- AND ProgrammaOrarioPerUnita.PeriodoRilevante = ProgrammaOrario.PeriodoRilevante 
-- INNER JOIN Contratto
-- ON Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto
-- 
-- INNER JOIN XmlProgrammiUtenti
-- ON XmlProgrammiUtenti.IdProgrammaXml = ProgrammaOrarioPerUnita.IdProgrammaXml
-- LEFT OUTER JOIN Certificate_List
-- ON  XmlProgrammiUtenti.CodiceUtenteSDC = Certificate_List.CodiceUtenteSDC
-- AND XmlProgrammiUtenti.Issuer          = Certificate_List.Issuer
-- AND XmlProgrammiUtenti.SerialNumber    = Certificate_List.SerialNumber
-- 
-- WHERE 
-- ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca AND 
-- ProgrammaOrarioPerUnita.PeriodoRilevante = @OraRicerca AND
-- ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 AND 
-- ProgrammaOrario.ProgrammaOrarioValidato = 1 AND 
-- UnitaContratto.TrCC = 1 AND 
-- UnitaContratto.TrUC = 1 AND 
-- UnitaContratto.UnitaDelContrattoValidata = 1 AND 
-- UnitaContratto.DataInizioValidita <= @DataRicerca AND 
-- UnitaContratto.DataFineValidita >= @DataRicerca AND
-- Contratto.DataInizioValidita <= @DataRicerca AND 
-- Contratto.DataFineValidita >= @DataRicerca 
-- ORDER BY 
-- ProgrammaOrarioPerUnita.IdProgrammaXml, 
-- ProgrammaOrarioPerUnita.ProgressivoNelProgramma
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte_PgmNonBilanciati]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte_PgmNonBilanciati]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGeneraOfferte_PgmNonBilanciati]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- CREATE PROCEDURE spGetCertificateData 
-- 	@Issuer          varchar(256),
-- 	@sn              varchar(64),
-- 	@CodiceUtenteSDC varchar(16)
-- AS
-- 
-- select
-- CL.ForceAction         CertificatoForceAction,
-- CL.TSScadenza          TSScadenzaCertificato,
-- CL.Abilitato           CertificatoAbilitato,
-- CA.TSScadenza          TSScadenzaCRL,
-- CA.TSDownloadEffettivo TSUltimoDownloadConSuccesso,
-- CA.TSUltimoDownload    TSUltimoDownloadTentato,
-- CRL.ReasonCode         CRLReasonCode,
-- CRL.TSRevoca           CRLTSRevoca,
-- CRL.TSDownload         TSUltimoDownloadRevocaDelCertificato,
-- CA.Abilitata           IsssuerAbilitato,
-- IsNull(DP.NDP,0)       NumeroPuntiDiDistribuzione
-- 
-- from Certificate_List CL
-- 
-- left outer join
-- (
-- 	select Issuer, count(*) NDP from Certificate_DistributionPoints group by Issuer
-- ) DP
-- on CL.Issuer = DP.Issuer
-- 
-- inner join Certificate_CA CA
-- on CA.Issuer = CL.Issuer
-- 
-- left outer join Certificate_RevocationList CRL
-- on CRL.Issuer = CL.Issuer
-- and CRL.SerialNumber = CL.SerialNumber
-- 
-- 
-- 
-- where 
-- CL.SerialNumber = @sn
-- and CL.Issuer = @issuer
-- and CL.CodiceUtenteSDC = @CodiceUtenteSDC
-- 
-- 
-- -- select
-- -- CL.ForceAction     CertificatoForceAction,
-- -- CL.TSScadenza      TSScadenzaCertificato,
-- -- CDP.TSScadenza     TSScadenzaCRL,
-- -- CDP.TSMaxEffettivo TSUltimoDownloadConSuccesso,
-- -- CDP.TSMaxUltimo    TSUltimoDownloadTentato,
-- -- CRL.ReasonCode     CRLReasonCode,
-- -- CRL.TSRevoca       CRLTSRevoca,
-- -- CRL.TSDownload     TSUltimoDownloadRevocaDelCertificato,
-- -- CA.Abilitata       IsssuerAbilitato
-- -- from Certificate_List CL
-- -- 
-- -- inner join 
-- -- (
-- -- 	select 
-- -- 	   @issuer Issuer,
-- -- 	   a.TSScadenza,
-- -- 	   b.TSMaxEffettivo,
-- -- 	   c.TSMaxUltimo
-- -- 	from 
-- -- 	Certificate_DistributionPoints a,
-- -- 	(
-- -- 		select 
-- -- 			Issuer, 
-- -- 			max(TSDownloadEffettivo) TSMaxEffettivo
-- -- 		from Certificate_DistributionPoints
-- -- 		where
-- -- 			Issuer = @issuer
-- -- 		group by issuer
-- -- 	) b,
-- -- 	(
-- -- 		select 
-- -- 			Issuer, 
-- -- 			max(TSUltimoDownload) TSMaxUltimo
-- -- 		from Certificate_DistributionPoints
-- -- 		where
-- -- 			Issuer = @issuer
-- -- 		group by issuer
-- -- 	) c
-- -- 	where 
-- -- 	   a.Issuer = b.Issuer
-- -- 	   and a.Issuer = c.Issuer
-- -- 	   and a.TSDownloadEffettivo = b.TSMaxEffettivo
-- -- ) CDP
-- -- on CDP.Issuer = CL.Issuer
-- -- 
-- -- left outer join Certificate_RevocationList CRL
-- -- on CRL.Issuer = CL.Issuer
-- -- and CRL.SerialNumber = CL.SerialNumber
-- -- 
-- -- left outer join Certificate_CA CA
-- -- on CA.Issuer = CL.Issuer
-- -- 
-- -- where 
-- -- CL.SerialNumber = @sn
-- -- and CL.Issuer = @issuer
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetCertificateData]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetCertificateData]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetCertificateData]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- create procedure spGetContrattiPerReportXmlProgrammi
--  	@DataProgramma as smalldatetime
-- AS
-- 	select 
-- 	IdContratto
-- 	from Contratto
-- 	where
-- 	StatoContratto='Abilitato'
-- 	and DataInizioValidita <= @DataProgramma
-- 	and DataFineValidita >= @DataProgramma
-- 	and TrCN = 1
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetContrattiPerReportXmlProgrammi]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetContrattiPerReportXmlProgrammi]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetContrattiPerReportXmlProgrammi]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE PROCEDURE spGetListUnitaDellOperatore
-- 	@op as varchar(16),
-- 	@di as smalldatetime,
-- 	@df as smalldatetime
-- AS
-- 
-- -- set @di = getdate()
-- -- set @df = getdate()
-- -- set @op = 'OEESDSP'
-- 
-- -- New Version per Variante TREBBI - UnitRelate (Fase 2) - 09.09.2004
-- 
-- select 
-- SDC_Unita.*
-- from 
-- SDC_Unita
-- inner join Unita
-- on 
-- SDC_Unita.CodiceUnitaSDC = Unita.CodiceUnitaSDC
-- and SDC_Unita.CategoriaUnitaSDC = unita.CategoriaUnitaSDC
-- inner join UnitRelate
-- on 
-- SDC_Unita.CodiceUnitaSDC = UnitRelate.CodiceUnitaSDC
-- and SDC_Unita.CategoriaUnitaSDC = UnitRelate.CategoriaUnitaSDC
-- where 
-- -- SDC_Unita.Abilitata = 1      -- le unita` disabilitate dal RUC/RUP si devono comunque vedere
-- Unita.StatoBilateraliUnita = 1  -- le unita` devono pero` appartenere ai bilaterali
-- and UnitRelate.CodiceOperatoreSDC = @op
-- and (UnitRelate.DataInizioValidita <= @df and UnitRelate.DataFineValidita >= @di) -- unita` del contratto valide sempre nell'intervallo di ricerca
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetListUnitaDellOperatore]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetListUnitaDellOperatore]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetListUnitaDellOperatore]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE  PROCEDURE [dbo].[spGetNC] 
--   	@DataProgramma smalldatetime
-- AS
-- 
-- set transaction isolation level read uncommitted
-- 
-- -- declare @DataProgramma smalldatetime
-- -- set @DataProgramma = '26/11/2004'
-- 
-- declare @oraMax as int
-- -- ottengo il numero di ore del giorno
-- exec @oraMax=GetHourNum @DataProgramma
-- 
-- 
-- select
-- NC.Ora                       PeriodoRilevante,
-- NC.NC                        NC,
-- IsNull(NP.NP,0)              NCP,
-- NC.NC - IsNull(NP.NP,0)      NCD
-- 
-- from
-- (
-- 	select 
-- 	Ore.Ora,
-- 	Q.NC
-- 	from Ore
-- 	cross join
-- 	(
-- 		select 
-- 		count(*) NC
-- 		from Contratto
-- 		where
-- 		Contratto.StatoContratto='Abilitato'
-- 		and Contratto.DataInizioValidita <= @DataProgramma
-- 		and Contratto.DataFineValidita >= @DataProgramma
-- 		and Contratto.TrCN = 1
-- 	) Q
-- 	where
-- 	Ora <= @oraMax
-- ) NC
-- left outer join
-- (
-- 	select
-- 	PeriodoRilevante,
-- 	count(*) NP
-- 	from ProgrammaOrario PO
-- 	inner join Contratto CO
-- 	on CO.IdContratto = PO.IdContratto
-- 	and CO.StatoContratto='Abilitato'
-- 	and CO.DataInizioValidita <= @DataProgramma
-- 	and CO.DataFineValidita >= @DataProgramma
-- 	and CO.TrCN = 1
-- 	where
-- 	PO.DataProgramma=@DataProgramma
--     and PO.ProgrammaOrarioValidato = 1
-- 	group by
-- 	PeriodoRilevante
-- ) NP
-- on NC.Ora = NP.PeriodoRilevante
-- 
-- 
-- 
-- -- 
-- -- 
-- -- 
-- -- 
-- -- select timetable.Ora PeriodoRilevante, 
-- -- isnull(counters.NC, 0) NC, 
-- -- isnull(counters.NCP, 0) NCP,
-- -- isnull(counters.NCD, 0) NCD
-- -- from 
-- -- (
-- -- 	select Ora from Ore
-- -- 	where Ora <= @oraMax
-- -- ) timetable
-- -- left outer join
-- -- (
-- -- select PeriodoRilevante, count(IdContratto) NC, sum(Pgm) NCP, count(IdContratto)  - sum(Pgm)  NCD
-- -- from 
-- -- (
-- -- select IdContratto, PeriodoRilevante, 1 Pgm
-- --   from ProgrammaOrario
-- --   where DataProgramma = @DataProgramma
-- --     --and ProgrammaOrarioValidato = 1
-- --     and exists (select * from tab_UnitaContratto(@DataProgramma) UnitaContratto 
-- -- 		where UnitaContratto.IdContratto = IdContratto 
-- -- 			and UnitaContratto.UnitaDelContrattoValidata = 1
-- -- 			and UnitaContratto.TrCC = 1
-- -- 			and UnitaContratto.TrUC = 1
-- -- 			and UnitaContratto.DataInizioValidita <= @DataProgramma and DataFineValidita >= @DataProgramma)
-- -- union all
-- --  select IdContratto, Ora PeriodoRilevante, 0 Pgm
-- --   from Contratto, Ore
-- --  where DataInizioValidita <= @DataProgramma and DataFineValidita >= @DataProgramma
-- --   and TrCN = 1 
-- --   and StatoContratto = 'Abilitato'
-- --   and Ora <= @oraMax
-- --   and not exists (select IdContratto, PeriodoRilevante
-- --    from ProgrammaOrario
-- --    where DataProgramma = @DataProgramma 
-- -- 	and PeriodoRilevante = Ore.Ora 
-- -- 	and IdContratto = Contratto.IdContratto 
-- -- 	--and ProgrammaOrarioValidato = 1
-- -- 	and exists (select * from tab_UnitaContratto(@DataProgramma) UnitaContratto 
-- -- 		where UnitaContratto.IdContratto = IdContratto 
-- -- 			and UnitaContratto.UnitaDelContrattoValidata = 1
-- -- 			and UnitaContratto.TrCC = 1
-- -- 			and UnitaContratto.TrUC = 1
-- -- 			and UnitaContratto.DataInizioValidita <= @DataProgramma and DataFineValidita >= @DataProgramma)
-- -- )
-- --   and exists (select * from tab_UnitaContratto(@DataProgramma) UnitaContratto 
-- -- 		where UnitaContratto.IdContratto = IdContratto 
-- -- 			and UnitaContratto.UnitaDelContrattoValidata = 1
-- -- 			and UnitaContratto.TrCC = 1
-- -- 			and UnitaContratto.TrUC = 1
-- -- 			and UnitaContratto.DataInizioValidita <= @DataProgramma and DataFineValidita >= @DataProgramma)
-- -- ) tc
-- --  group by PeriodoRilevante
-- -- ) counters
-- -- on timetable.Ora = counters.PeriodoRilevante
-- --  order by PeriodoRilevante
-- -- 
-- -- GO
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetNC]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetNC]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetNC]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE PROCEDURE [dbo].[spGetNU_OverQty] 
--  	@DataProgramma smalldatetime,
-- 	@kPowerP as float,
-- 	@kPowerC as float,
-- 	@kPowerMp as float,
-- 	@kPowerMc as float
-- AS
-- 
-- set transaction isolation level read uncommitted
-- 
-- -- declare @DataProgramma smalldatetime,
-- --  	@kPowerP as float,
-- --  	@kPowerC as float,
-- --  	@kPowerMp as float,
-- --  	@kPowerMc as float
-- -- 
-- -- set @DataProgramma = '25/11/2004'
-- -- set @kPowerP = 1.5
-- -- set @kPowerC = 1.5
-- -- set @kPowerMp = 1.5
-- -- set @kPowerMc = 1.5
-- 
-- -- siccome la vera query comporta parecchie join e soprattutto
-- -- coinvolge tab_unitaContratto usiamo un metodo euristico per
-- -- fare la sp veloce.
-- -- 1) prima si vede senza alcun controllo di validita` del contrato, unita ecc
-- --    se esiste una o piu` unita` che sforano
-- -- 2) se il risultato e' 0 ritorniamo zero subito
-- -- 3) altrimenti facciamo la query lenta
-- 
-- 
-- declare @r as integer
-- 
-- set @r = 0
-- 
-- -- select 
-- --    @r = count(*)
-- -- from
-- --   sdc_unita su
-- -- inner join programmaorarioperunita pou
-- -- on
-- --  su.CodiceUnitaSDC = pou.CodiceUnitaSDC
-- --  and su.CategoriaUnitaSDC = pou.CategoriaUnitaSDC
-- -- where
-- -- 	pou.DataProgramma = @DataProgramma	
-- --	and 
-- --	( (su.TipoUnita = 'M' and pou.ProgrammatoDalCedente=1 and abs(pou.QtyMwh)>su.PotenzaMassimaMWh * @kPowerMp)
-- --	  or
-- --	  (su.TipoUnita = 'M' and pou.ProgrammatoDalCedente=0 and abs(pou.QtyMwh)>abs(su.PotenzaMinimaMWh * @kPowerMc))
-- -- 	  or 
-- --	  (su.TipoUnita = 'P' and pou.QtyMwh>su.PotenzaMassimaMWh * @kPowerP)
-- --	  or 
-- --	  (su.TipoUnita = 'C' and abs(pou.QtyMwh)>su.PotenzaMassimaMWh * @kPowerC)
-- --	)
-- -- group by
-- --  pou.PeriodoRilevante, pou.IdContratto 
-- 
-- if @r is null
-- begin
-- 	select 0 NU_OVER
-- end
-- else
-- if @r = 0
-- begin
-- 	select @r NU_OVER
-- end
-- else
-- begin
--       --set @r = -1
--       select @r NU_OVER
-- 
-- 
-- --==============================================================
-- --	select 
-- --	count(*) NU_OVER
-- --	from (
-- --		select pou.PeriodoRilevante, c.IdContratto, 
-- --		case su.TipoUnita
-- --		when 'M' then
-- --			case pou.ProgrammatoDalCedente 
-- --			when 1 then 'P'
-- --			else 'C'
-- --			end 
-- --		else
-- --			su.TipoUnita
-- --		end TipoUnita, 
-- --		case su.TipoUnita 
-- --		when 'M' then 
-- --			case pou.ProgrammatoDalCedente 
-- --			when 1 then su.PotenzaMassimaMWh
-- --			else -su.PotenzaMinimaMWh
-- --			end 
-- --		else
-- --		su.PotenzaMassimaMWh
-- --		end PotenzaMassimaMWh, 
-- --		case su.TipoUnita 
-- --		when 'M' then 0
-- --		else
-- --		su.PotenzaMinimaMWh
-- --		end PotenzaMinimaMWh,
-- --		case su.TipoUnita 
-- --		when 'M' then 
-- --			case pou.ProgrammatoDalCedente 
-- --			when 1 then su.PotenzaMassimaMWh * @kPowerMp
-- --			else -su.PotenzaMinimaMWh * @kPowerMc
-- --			end 
-- --		when 'P' then su.PotenzaMassimaMWh * @kPowerP
-- --		else su.PotenzaMassimaMWh * @kPowerC
-- --		end PotenzaMassimaMWhPlus, 
-- --		abs(pou.QtyMWh) QtyMWh
-- 	
-- --		from contratto c,
-- --		sdc_unita su, --unita u, 
-- --		tab_UnitaContratto(@DataProgramma) uc,
-- --		(
-- --			select IdContratto, 
-- --			PeriodoRilevante,
-- --			CodiceUnitasdc,
-- --			CategoriaUnitaSDC,
-- --			QtyMWh,
-- --			ProgrammatoDalCedente
-- --			from programmaorarioperunita
-- --			where dataprogramma = @DataProgramma
-- --		) pou
-- --		where pou.IdContratto = c.IdContratto
-- --		and c.TrCN = 1
-- --		and c.StatoContratto = 'Abilitato'
-- --		and c.DataInizioValidita <=  @DataProgramma and c.DataFineValidita >=  @DataProgramma
-- --		and su.CodiceUnitaSDC = pou.CodiceUnitaSDC
-- --		and su.CategoriaUnitaSDC = pou.CategoriaUnitaSDC
-- --		and uc.CodiceUnitaSDC = pou.CodiceUnitaSDC
-- --		and uc.CategoriaUnitaSDC = pou.CategoriaUnitaSDC
-- --		and uc.UnitaDelContrattoValidata = 1
-- --		and uc.TrCC = 1
-- --		and uc.TrUC = 1
-- --		and uc.DataInizioValidita <=  @DataProgramma and uc.DataFineValidita >=  @DataProgramma
-- --	) x
-- --	where 
-- --		QtyMWh > PotenzaMassimaMWhPlus 
-- end
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetNU_OverQty]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetNU_OverQty]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetNU_OverQty]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE PROCEDURE spGetOperatorListUnits
-- 	--@CatUnitSDC as varchar,
-- 	@dt as datetime
-- AS
-- select t.CodiceUnitaSDC, count(t.CodiceOperatoreSDC)  NroOp, dbo.GetOperatori(t.CodiceUnitaSDC, t.CategoriaUnitaSDC, @dt)  LstOp from
-- (
-- 	select CodiceUnitaSDC, CodiceOperatoreSDC, CategoriaUnitaSDC from UnitRelate
-- 	where 
-- --@CatUnitSDC = CategoriaUnitaSDC
-- 	--and 
-- 	@dt >= DataInizioValidita
-- 	and @dt <= DataFineValidita
-- 	--GROUP BY CodiceUnitaSDC, CategoriaUnitaSDC, CodiceOperatoreSDC
-- ) t GROUP BY CodiceUnitaSDC, CategoriaUnitaSDC
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE PROCEDURE spGetOperatorUnitsType
-- 	@dt as datetime
-- AS
-- select CodOp, sum(UP) UP, sum(UC) UC, sum(UM) UM
-- from
-- (
-- select CodOp,
-- case UnitType when 'P' then sum(IsNull(NoUnit, 0)) else 0 end UP,
-- case UnitType when 'C' then sum(IsNull(NoUnit, 0)) else 0 end UC,
-- case UnitType when 'M' then sum(IsNull(NoUnit, 0)) else 0 end UM
-- from (
-- select CodiceOperatoreSDC CodOp, TipoUnita UnitType, count(UnitRelate.CodiceUnitaSDC) NoUnit 
-- from UnitRelate
-- where @dt >= DataInizioValidita 
-- and @dt <= DataFineValidita
-- group by TipoUnita, CodiceOperatoreSDC 
-- ) t
-- group by CodOp, UnitType
-- ) x
-- group by CodOp
-- order by CodOp
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetOperatorUnitsType]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetOperatorUnitsType]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetOperatorUnitsType]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- CREATE PROCEDURE [dbo].[spGetProgrammiConCertificatoNonValido] 
-- 	@CodiceUtenteSDC as varchar(16),
-- 	@Issuer as varchar(256),
-- 	@SerialNumber as varchar(64),
-- 	@DataRicerca as smalldatetime
-- AS
-- -- set @DataRicerca = '6/24/04'
-- -- set @CodiceUtenteSDC = 'IDRAPTUS'
-- -- set @Issuer = 'CN=NAB_CERT'
-- -- set @SerialNumber = '5F764B1C73DDDD40B75B6505084EDF80'
-- 
-- select  IdProgrammaXml,
-- 	IdContratto,
-- 	DataStipula,
-- 	CRN,
-- 	DataInizioValidita,
-- 	DataFineValidita,
-- 	Responsabile,
-- 	CodiceOperatoreSDCCedente,
-- 	CodiceOperatoreSDCAcquirente,
-- 	Issuer,
-- 	SerialNumber,
-- 	Bilanciato
-- from 
-- (
-- select distinct
-- 	xpu.IdProgrammaXml,
-- 	pou.IdContratto,
-- 	c.DataStipula,
-- 	c.CRN,
-- 	c.DataInizioValidita,
-- 	c.DataFineValidita,
-- 	c.CodiceOperatoreSDC Responsabile, 
-- 	case pou.ProgrammatoDalCedente
-- 	when 1 then xpu.CodiceUtenteSDC
-- 	else c.CodiceOperatoreSDCCedente end as CodiceOperatoreSDCCedente,
-- 	case pou.ProgrammatoDalCedente
-- 	when 0 then xpu.CodiceUtenteSDC 
-- 	else c.CodiceOperatoreSDCAcquirente end as CodiceOperatoreSDCAcquirente,
-- 	xpu.Issuer, 
-- 	xpu.SerialNumber,
-- 	po.Bilanciato
-- 	--  pou.DataProgramma,
-- 	--  pou.PeriodoRilevante,
-- 	--  pou.CodiceUnitaSDc,
-- 	--  pou.CategoriaUnitaSDC
-- from 	XMLProgrammiUtenti xpu,
-- 	ProgrammaOrarioPerUnita pou, 
-- 	ProgrammaOrario po,
-- 	Contratto c,
-- 	tab_UnitaContratto(@DataRicerca) uc,
-- 	Certificate_List cl
-- where 
-- 	xpu.CodiceUtenteSDC = @CodiceUtenteSDC and 
-- 	xpu.Issuer = @Issuer and 
-- 	xpu.SerialNumber = @SerialNumber and 
-- 	xpu.IdProgrammaXml = pou.IdProgrammaXml and 
-- 	pou.DataProgramma = @DataRicerca and 
-- 	pou.ProgOrarioDellUnitaValidato = 1 and
-- 	po.IdContratto = pou.IdContratto and
-- 	po.DataProgramma = pou.DataProgramma and
-- 	po.PeriodoRilevante = pou.PeriodoRilevante and
-- 	po.ProgrammaOrarioValidato = 1 and
-- 	c.IdContratto = pou.IdContratto and
-- 	c.StatoContratto = 'Abilitato' and
-- 	c.TrCN = 1 and
-- 	pou.IdContratto = uc.IdContratto and 
-- 	pou.CodiceUnitaSDC = uc.CodiceUnitaSDC and 
-- 	pou.CategoriaUnitaSDC = uc.CategoriaUnitaSDC and
-- 	uc.TrCC = 1 and 
-- 	uc.TrUC = 1 and 
-- 	uc.UnitaDelContrattoValidata = 1 and 
-- 	xpu.CodiceUtenteSDC = cl.CodiceUtenteSDC and 
-- 	xpu.Issuer          = cl.Issuer and 
-- 	xpu.SerialNumber    = cl.SerialNumber and
-- 	uc.DataInizioValidita <= @DataRicerca and 
-- 	uc.DataFineValidita >= @DataRicerca and
-- 	uc.DataInizioValidita <= @DataRicerca and 
-- 	uc.DataFineValidita >= @DataRicerca
-- ) T
-- order by IdContratto, DataStipula
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetProgrammiConCertificatoNonValido]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetProgrammiConCertificatoNonValido]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetProgrammiConCertificatoNonValido]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE PROCEDURE spGetReportIndicatori
-- 	@dtinizio as datetime,
-- 	@dtfine as datetime
-- 		
-- AS
-- 
-- set transaction isolation level read uncommitted
-- 
-- select DataProgramma, 
-- 1 as CNT,
-- case CoEnabled
-- when 0 then null
-- else
-- cast (round(cast(CoCut as decimal(12,2))/cast(CoEnabled as decimal(12,2)) * 100, 2) as decimal(12,2))
-- end NCT,
-- case CoEnabled
-- when 0 then null
-- else
-- cast( round(cast(CoPgm as decimal(12,2))/cast(CoEnabled as decimal(12,2))*100, 2) as decimal(12,2))
-- end NCP,
-- case QtyMwhSell
-- when 0 then 0
-- else
-- cast( round(ABS(  cast(QtyMwhBilP as decimal(12,2))/cast(QtyMwhP  as decimal(12,2)) )*100, 2) as decimal(12,2))
-- end ENMGPP,
-- case QtyMwhBuy
-- when 0 then null
-- else
-- cast ( round(ABS(  cast(QtyMwhBilC as decimal(12,2))/cast(QtyMwhC  as decimal(12,2)) )*100, 2) as decimal(12,2))
-- end ENMGPC,
-- case (ABS(QtyMwhBilP) + ABS(QtyMwhBilC))
-- when 0 then 0
-- else
-- cast ( round(ABS(  cast(QtyMwhBilC + QtyMwhBilP as decimal(12,2))/cast(QtyMwhC + QtyMwhP as decimal(12,2)) )*100, 2) as decimal(12,2))
-- end ENMGPT
-- from tab_ReportIndicatori()
-- where @dtinizio <= DataProgramma
-- and @dtfine >= DataProgramma
-- order by DataProgramma
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetReportIndicatori]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetReportIndicatori]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spGetReportIndicatori]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE PROCEDURE [dbo].[spListaContrattiPatch]
-- @di as datetime,
-- @df as datetime,
-- @operatore as varchar(16) = ''
--  AS
-- 
-- if @operatore = '' 
-- begin
-- 
-- SELECT *, 0 as TotaleUnitaContratto, 0 as TotaleUnitaContratto FROM dbo.Bil_ContrattoOperatore 
-- WHERE (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) 
-- AND (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) 
-- 
-- end
-- else
-- begin
-- SELECT *, 0 as TotaleUnitaContratto, 0 as TotaleUnitaContratto
-- FROM dbo.Bil_ContrattoOperatore 
-- WHERE (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDCCedente = @Operatore) 
-- AND (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) 
-- AND (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) 
-- OR (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) 
-- AND (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) 
-- AND (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDCAcquirente = @operatore) 
-- OR (dbo.Bil_ContrattoOperatore.DataInizioValidita <= ISNULL(@df, dbo.Bil_ContrattoOperatore.DataInizioValidita)) 
-- AND (dbo.Bil_ContrattoOperatore.DataFineValidita >= ISNULL(@di, dbo.Bil_ContrattoOperatore.DataFineValidita)) 
-- AND (dbo.Bil_ContrattoOperatore.CodiceOperatoreSDC = @operatore)
-- 
-- end
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spListaContrattiPatch]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spListaContrattiPatch]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spListaContrattiPatch]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE spNotificaStatoLetturaMGP
-- 	@DataProgramma as smalldatetime,
-- 	@eseguito as bit
-- AS
-- 	update SessioneBilaterali
-- 	set LetturaMGP = @eseguito
-- 	where
-- 	DataProgramma = @DataProgramma
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNotificaStatoLetturaMGP]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNotificaStatoLetturaMGP]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNotificaStatoLetturaMGP]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE dbo.spNuovaTransProgramma
-- (
-- 	@IdContratto      int,
-- 	@DataProgramma    smalldatetime,
-- 	@PeriodoRilevante tinyint
-- )
-- AS
-- 	SET NOCOUNT ON
-- 	
-- 	delete from ProgrammaOrarioPerUnita 
-- 	where 
-- 	IdContratto=@IdContratto and
-- 	DataProgramma=@DataProgramma and 
-- 	PeriodoRilevante = @PeriodoRilevante
-- 	
-- 	delete from ProgrammaOrario
-- 	where 
-- 	IdContratto=@IdContratto and
-- 	DataProgramma=@DataProgramma and 
-- 	PeriodoRilevante = @PeriodoRilevante
-- 
-- 
-- 	update SessioneBilaterali
-- 	set
-- 	Bilanciamento=0,
-- 	Taglio=0
-- 	from SessioneBilaterali
-- 	where SessioneBilaterali.DataProgramma =@DataProgramma
-- 
-- 
-- 	
-- 	
-- 	RETURN
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNuovaTransProgramma]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNuovaTransProgramma]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNuovaTransProgramma]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE dbo.spNuovoProgrammaNonIncrementale
-- (
-- 	@IdContratto      int,
-- 	@DataProgramma    smalldatetime,
-- 	@PeriodoRilevante tinyint,
-- 	@IsOpCedente      tinyint,
-- 	@IsOpAcquirente   tinyint
-- )
-- AS
-- 
-- 	SET NOCOUNT ON
-- 	
-- 	-- cancello i record di ProgrammaOrarioPerUnita
-- 	
-- 	if @IsOpCedente = 1 and @IsOpAcquirente = 1
-- 	begin
-- 		-- cancello tutto
-- 		delete from ProgrammaOrarioPerUnita 
-- 		where 
-- 		IdContratto = @IdContratto and
-- 		DataProgramma = @DataProgramma and 
-- 		PeriodoRilevante = @PeriodoRilevante
-- 	end
-- 	else if @IsOpCedente = 1
-- 	begin
-- 		-- cancello i programmi del cedente
-- 		delete from ProgrammaOrarioPerUnita 
-- 		where 
-- 		IdContratto = @IdContratto and
-- 		DataProgramma = @DataProgramma and 
-- 		PeriodoRilevante = @PeriodoRilevante and
-- 		ProgrammatoDalCedente = 1
-- 	end
-- 	else if @IsOpAcquirente = 1
-- 	begin
-- 		-- cancello i programmi dell'acquirente
-- 		delete from ProgrammaOrarioPerUnita 
-- 		where 
-- 		IdContratto = @IdContratto and
-- 		DataProgramma = @DataProgramma and 
-- 		PeriodoRilevante = @PeriodoRilevante and
-- 		ProgrammatoDalCedente = 0
-- 	end
-- 	
-- 	-- cancello ProgrammaOrario SOLO se non esistono piu` righe in POU
-- 	
-- 	delete from ProgrammaOrario
-- 	where 
-- 	IdContratto = @IdContratto and
-- 	DataProgramma = @DataProgramma and 
-- 	PeriodoRilevante = @PeriodoRilevante and
-- 	not exists
-- 	(
-- 		select 
-- 		* 
-- 		from 
-- 		ProgrammaOrarioPerUnita
-- 		where
-- 		IdContratto=@IdContratto and
-- 		DataProgramma=@DataProgramma and 
-- 		PeriodoRilevante = @PeriodoRilevante
-- 	)
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNuovoProgrammaNonIncrementale]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNuovoProgrammaNonIncrementale]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spNuovoProgrammaNonIncrementale]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE spOnProgrammaOperatore 
-- 	@DataProgramma as smalldatetime
-- AS
-- 
-- 	update SessioneBilaterali
-- 	set
-- 	Taglio=0
-- 	from SessioneBilaterali
-- 	where SessioneBilaterali.DataProgramma =@DataProgramma
-- 
-- --	update ProgrammaOrario
-- --	set 
-- --	TSCalcoloBilanciamento = NULL,
-- --	SbilanciamentoMWh = NULL,
-- --	Bilanciato = NULL
-- --	from ProgrammaOrario 
-- --	on  ProgrammaOrario.IdContratto = inserted.IdContratto
-- --	and ProgrammaOrario.DataProgramma = inserted.DataProgramma
-- --	and ProgrammaOrario.PeriodoRilevante = inserted.PeriodoRilevante
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spOnProgrammaOperatore]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spOnProgrammaOperatore]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spOnProgrammaOperatore]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE  PROCEDURE spReportBilanciamento
-- 	@DataProgramma smalldatetime
-- AS
-- 
-- -- non si usa il read uncommitted in quanto e` un report che deve essere fatto con dati consolidati
-- --set transaction isolation level read uncommitted
-- 
-- -- declare @DataProgramma smalldatetime
-- -- set @DataProgramma = '24/11/2004'
-- 
-- declare @NextDateMonth as integer
-- declare @Ore as integer
-- 
-- set @NextDateMonth= DATEPART(month,@DataProgramma + 7)
-- set @Ore = 24
-- -- se e` Marzo, e` Domenica e Domenica prossima e` gia` Aprile
-- if (month(@DataProgramma) = 3  and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 4)
-- 	set @Ore = 23
-- 	
-- -- se e` Ottobre, e` Domenica e Domenica prossima e` gia` Novembre
-- if (month(@DataProgramma) = 10 and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 11)
-- 	set @Ore = 25
--  
-- SELECT
-- CN.IdContratto, 
-- CN.CRN,
-- CN.CodiceContratto,
-- CN.PeriodoRilevante,
-- CN.CodiceOperatoreSDCAcquirente,
-- CN.CodiceOperatoreSDCCedente,
-- PO.IdContratto  POIdContratto, -- questo e` NULL nel caso non esistesse la programmazione
-- PO.Bilanciato, -- questo puo` essere NULL, 0, 1
-- PO.SbilanciamentoMWh, -- anche questo puo` essere NULL
-- PO.SbilanciamentoMWhReale, -- anche questo puo` essere NULL
-- PO.ProgrammaOrarioValidato -- anche questo puo` essere NULL
-- FROM
-- (
-- 	SELECT 
-- 	Ore.Ora PeriodoRilevante,
-- 	Contratto.IdContratto, 
-- 	Contratto.CRN,
-- 	Contratto.CodiceContratto,
-- 	Contratto.CodiceOperatoreSDCAcquirente,
-- 	Contratto.CodiceOperatoreSDCCedente,
-- 	Contratto.CodiceOperatoreSDC CodiceOperatoreSDCTitolare
-- 	FROM 
-- 	Contratto, 
-- 	Ore
-- 	WHERE 
-- 	Contratto.StatoContratto='Abilitato'
-- 	AND Contratto.DataInizioValidita <= @DataProgramma
-- 	AND Contratto.DataFineValidita >= @DataProgramma
-- 	AND Contratto.TrCN = 1
-- 	AND Ore.Ora <= @Ore
-- -- 	AND EXISTS
-- -- 	(
-- -- 		select 
-- -- 		CodiceUnitaSDC, 
-- -- 		CategoriaUnitaSDC 
-- -- 		from 
-- -- 		tab_UnitaContratto(@DataProgramma) UnitaContratto
-- -- 		where
-- -- 		UnitaContratto.UnitaDelContrattoValidata = 1
-- -- 		AND UnitaContratto.TrCC = 1
-- -- 		AND UnitaContratto.TrUC = 1
-- -- 		AND UnitaContratto.DataInizioValidita <= @DataProgramma
-- -- 		AND UnitaContratto.DataFineValidita >= @DataProgramma
-- -- 		AND Contratto.IdContratto = UnitaContratto.IdContratto
-- -- 	)
-- ) CN
-- LEFT OUTER JOIN
-- (
-- 	SELECT
-- 	IdContratto,
-- 	DataProgramma,
-- 	PeriodoRilevante,
-- 	Bilanciato,
-- 	SbilanciamentoMWh,
-- 	SbilanciamentoMWhReale,
-- 	ProgrammaOrarioValidato
-- 	FROM
-- 	ProgrammaOrario
-- 	WHERE 
-- 	DataProgramma = @DataProgramma 
-- 	and ProgrammaOrarioValidato = 1
-- )
-- PO
-- ON  PO.IdContratto = CN.IdContratto
-- AND PO.PeriodoRilevante = CN.PeriodoRilevante
-- 
-- order by 
-- CN.IdContratto, 
-- CN.PeriodoRilevante
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportBilanciamento]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportBilanciamento]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportBilanciamento]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- CREATE PROCEDURE [dbo].[spReportCapacitaTrasporto] 
-- 	@DataProgrammaMin as smalldatetime,
--  	@DataProgrammaMax as smalldatetime,
--  	@Transitorio as int,
-- 	@Operatore as varchar(16)
-- AS
-- 
-- --questo report rischia di estrarre cosi' tanti dati da rendere necessario
-- --la read uncommitted
-- set transaction isolation level read uncommitted
-- 
-- select X.CodiceOperatoreSDC,
-- O.RagioneSociale,
-- C.CRN,
-- C.CodiceContratto,
-- X.Corrispettivo
-- 
-- from
-- (
-- 
-- select 
-- CodiceOperatoreSDC,
-- IdContratto,
-- sum(T.Corr) Corrispettivo
-- 
-- from
-- (
-- 
-- select
-- POU.DataProgramma,
-- POU.CodiceOperatoreSDC,
-- POU.IdContratto,
-- POU.CodiceContratto,
-- POU.CodiceUnitaSDC,
-- POU.CategoriaUnitaSDC,
-- POU.PeriodoRilevante,
-- POU.TipoUnita,
-- cast(POU.PrezzoUnico  as decimal(19, 6)) as PrezzoUnico,   -- il prezzo unico  e` a 6 cifre
-- cast(POU.PrezzoZonale as decimal(19, 6)) as PrezzoZonale,  -- il prezzo zonale e` a 6 cifre
-- cast(QtyMGP as decimal(16,3)) Qty, -- la quantita` in MWh e` a 3 cifre
-- 
-- -- qui si ha:
-- -- QtyMGP>0 per P
-- -- QtyMGP<0 per C
-- -- QtyMGP>0 per M che producono
-- -- QtyMGP<0 per M che consumano
-- 
-- cast(
-- 	case @Transitorio 
-- 	when 1 then 
-- 		-- caso per i programmi di sola produzione ossia con contratti sbilanciati ammessi
-- 		case TipoUnita 
-- 		when 'P' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2) 
-- 		when 'C' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2)  
-- 		when 'M' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2)  
-- 		end
-- 	else 
-- 		-- caso per i programmi di produzione/consumo ossia con contratti bilanciati
-- 		case TipoUnita 
-- 		
-- 		when 'P' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoZonale,6), 2)
-- 		when 'C' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoUnico, 6), 2)
-- 		when 'M' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoZonale,6), 2)
-- 		end 
-- 	end
-- 	as decimal(16, 2)) Corr  -- gli euro dei corrispettivi escono in centesimi (e nel report XML Corrispettivi saranno a 2 cifre  - come sta scritto qui! se ci fosse un ,3 avremmo 3 cifre nel xml)
-- 
-- from 
-- (
-- select 
-- ProgrammaOrarioPerUnita.DataProgramma,
-- Contratto.CodiceOperatoreSDC,
-- Contratto.IdContratto,
-- Contratto.CRN,
-- Contratto.CodiceContratto,
-- ProgrammaOrarioPerUnita.PeriodoRilevante,
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC,
-- ProgrammaOrarioPerUnita.CategoriaUnitaSDC,
-- 
-- ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita / SDC_Unita.CoefficientePerdita QtyMGP,
-- SDC_Unita.TipoUnita,
-- SDC_Unita.CoefficientePerdita KU,
-- SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP,
-- SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
-- PrezzoUnitario.Prezzo PrezzoUnico,
-- PrezzoZonale.Prezzo PrezzoZonale
-- 
-- from 
-- ProgrammaOrarioPerUnita
-- 
-- inner join Contratto
-- on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 
-- 
-- inner join SDC_Unita
-- on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
-- and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC
-- 
-- inner join SDC_PuntiDiScambioRilevanti
-- on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 
-- 
--  inner join PrezzoUnitario
-- on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
-- and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
-- 
--  inner join PrezzoZonale
-- on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
-- and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
-- and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC
-- 
-- where not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
-- and ProgrammaOrarioPerUnita.DataProgramma >= @DataProgrammaMin
-- and ProgrammaOrarioPerUnita.DataProgramma <= @DataProgrammaMax
-- ) POU
-- 
-- ) T
-- group by 
-- T.CodiceOperatoreSDC, 
-- T.IdContratto
-- ) X,
-- SDC_Operatori O,
-- Contratto C
--  where X.CodiceOperatoreSDC = O.CodiceOperatoreSDC
-- and C.IdContratto = X.IdContratto
-- and (X.CodiceOperatoreSDC = @Operatore or @Operatore = '')
-- 
-- order by 
-- X.CodiceOperatoreSDC,
-- C.CRN
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportCapacitaTrasporto]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE  PROCEDURE [dbo].[spReportGestioneTaglio_Contratti] 
-- @dt as datetime,
-- @StatoContratto as varchar(32) = null
-- AS
-- 
-- 
-- -- declare
-- -- @dt as datetime,
-- -- @StatoContratto as varchar(32)
-- -- set @dt = '24/11/2004'
-- -- set @StatoContratto = 'Abilitato'
-- 
-- -- e` un report riassuntivo --> posso leggere anche dati non affidabili
-- set transaction isolation level read uncommitted
-- 
-- 
-- if @StatoContratto is null
-- begin
-- select 
-- case GestioneTaglio 
-- 	when 'C' then 'Se consumo maggiore della produzione' 
-- 	when 'P' then 'Se produzione maggiore del consumo' 
-- 	when 'T' then 'Sempre' 
-- 	when 'M' then 'Mai'
-- 	end 'Gestione Taglio', 
-- case GestioneTaglio 
-- 	when 'C' then 2
-- 	when 'P' then 1 
-- 	when 'T' then 0
-- 	when 'M' then 3
-- 	end Ord,
-- count(contratto.IdContratto) 'N.roContratti',
-- sum(uc.NroUnita) 'N.ro Unit�'
-- from contratto,
-- (
-- -- 	select IdContratto, count(*) NroUnita
-- -- 	from tab_UnitaContratto(@dt)  
-- -- 	group by IdContratto
-- 
-- 	select CCC.IdContratto, count(CCC.CodiceUnitaSDC) NroUnita
-- 	from
-- 	(
-- 		select
-- 		CX.IdContratto,
-- 		CX.CodiceUnitaSDC,
-- 		sum(AssegnatoAcq) A,
-- 		sum(AssegnatoCed) B
-- 		from
-- 		(
-- 			select
-- 			CO.IdContratto,
-- 			UR.CodiceUnitaSDC,
-- 		
-- 			case when (CO.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> 'P') then 1 else 0 end AssegnatoAcq,
-- 			case when (CO.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> 'C') then 1 else 0 end AssegnatoCed
-- 			
-- 			from Contratto CO
-- 			inner join unitRelate UR
-- 			on UR.Abilitata = 1
-- 			and UR.TrUC = 1
-- 			and UR.DataInizioValidita <= @dt
-- 			and UR.DataFineValidita   >= @dt
-- 			inner join SDC_Unita U
-- 			on  U.CodiceUnitaSDC = UR.CodiceUnitaSDC
-- 			and U.CategoriaUnitaSDC = UR.CategoriaUnitaSDC
-- 			where
-- 			CO.DataInizioValidita <= @dt
-- 			and CO.DataFineValidita   >= @dt
-- 			and CO.TrCN = 1
-- 			and 
-- 			(
-- 				(CO.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> 'P')
-- 				or
-- 				(CO.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> 'C')
-- 			)
-- 		) CX
-- 		group by
-- 		CX.IdContratto,
-- 		CX.CodiceUnitaSDC
-- 	) CCC
-- 	group by CCC.IdContratto
-- ) uc
-- where contratto.IdContratto = uc.IdContratto
-- and contratto.DataInizioValidita <= @dt 
-- and contratto.DataFineValidita >= @dt
-- and TrCN = 1
--  group by GestioneTaglio
--  order by Ord
-- 
-- end
-- else
-- begin
-- 
-- select 
-- case GestioneTaglio 
-- 	when 'C' then 'Se consumo maggiore della produzione' 
-- 	when 'P' then 'Se produzione maggiore del consumo' 
-- 	when 'T' then 'Sempre' 
-- 	when 'M' then 'Mai'
-- 	end 'Gestione Taglio', 
-- case GestioneTaglio 
-- 	when 'C' then 2
-- 	when 'P' then 1 
-- 	when 'T' then 0
-- 	when 'M' then 3
-- 	end Ord,
-- count(contratto.IdContratto) 'N.roContratti',
-- sum(uc.NroUnita) 'N.ro Unit�'
-- from contratto,
-- (
-- -- select IdContratto, count(*) NroUnita
-- -- from tab_UnitaContratto(@dt)  
-- -- group by IdContratto
-- 	select CCC.IdContratto, count(CCC.CodiceUnitaSDC) NroUnita
-- 	from
-- 	(
-- 		select
-- 		CX.IdContratto,
-- 		CX.CodiceUnitaSDC,
-- 		sum(AssegnatoAcq) A,
-- 		sum(AssegnatoCed) B
-- 		from
-- 		(
-- 			select
-- 			CO.IdContratto,
-- 			UR.CodiceUnitaSDC,
-- 		
-- 			case when (CO.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> 'P') then 1 else 0 end AssegnatoAcq,
-- 			case when (CO.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> 'C') then 1 else 0 end AssegnatoCed
-- 			
-- 			from Contratto CO
-- 			inner join unitRelate UR
-- 			on UR.Abilitata = 1
-- 			and UR.TrUC = 1
-- 			and UR.DataInizioValidita <= @dt
-- 			and UR.DataFineValidita   >= @dt
-- 			inner join SDC_Unita U
-- 			on  U.CodiceUnitaSDC = UR.CodiceUnitaSDC
-- 			and U.CategoriaUnitaSDC = UR.CategoriaUnitaSDC
-- 			where
-- 			CO.DataInizioValidita <= @dt
-- 			and CO.DataFineValidita   >= @dt
-- 			and CO.TrCN = 1
-- 			and 
-- 			(
-- 				(CO.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> 'P')
-- 				or
-- 				(CO.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> 'C')
-- 			)
-- 		) CX
-- 		group by
-- 		CX.IdContratto,
-- 		CX.CodiceUnitaSDC
-- 	) CCC
-- 	group by CCC.IdContratto
-- ) uc
-- where contratto.IdContratto = uc.IdContratto
-- and contratto.DataInizioValidita <= @dt 
-- and contratto.DataFineValidita >= @dt
-- and contratto.StatoContratto = @StatoContratto
-- and TrCN = 1
-- group by GestioneTaglio
-- order by Ord
-- 
-- 
-- end
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportGestioneTaglio_Contratti]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportGestioneTaglio_Contratti]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportGestioneTaglio_Contratti]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE PROCEDURE [dbo].[spReportSbilanciamentoOrario]
-- @date as datetime,
-- @xml as bit = 0
--  AS
-- 
-- -- mi risulta che questa sp non e` usata
-- 
-- declare @SQLString as nvarchar(2048)
-- 
-- set @SQLString = N'select 	po.DataProgramma, '
-- set @SQLString = @SQLString + N''''''''' + c.CRN + '''''''' as CRN, '
-- set @SQLString = @SQLString + N'c.CodiceContratto as ''CodiceContratto'', ' 
-- set @SQLString = @SQLString + N'c.CodiceOperatoreSDCCedente as ''Cedente'', '
-- set @SQLString = @SQLString + N'	c.CodiceOperatoreSDCAcquirente as ''Acquirente'', '
-- set @SQLString = @SQLString + N'	po.PeriodoRilevante as Ora, '
-- set @SQLString = @SQLString + N'	cast(po.SbilanciamentoMWh as decimal(10,3)) as SbilanciamentoMWh '
-- set @SQLString = @SQLString + N'from programmaorario po, contratto c '
-- set @SQLString = @SQLString + N'where c.IdContratto = po.IdContratto '
-- set @SQLString = @SQLString + N'and po.DataProgramma = @dt '
-- set @SQLString = @SQLString + N'order by CRN, CodiceContratto, PeriodoRilevante '
-- 
-- if not (@xml is null or @xml = 0 )
-- 	set @SQLString = @SQLString + 'for XML AUTO'
-- 
-- print @SQLString
-- exec sp_executesql  @SQLString,
-- 	N'@dt datetime',
--           @dt = @date
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportSbilanciamentoOrario]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportSbilanciamentoOrario]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportSbilanciamentoOrario]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- CREATE PROCEDURE spReportStoricoProgrammi
-- 	@DataProgramma smalldatetime,
-- 	@Operatore varchar(16)
-- AS
-- 
-- -- la SP ha una query su dati che dovrebbero essere consolidati.
-- -- Uso la read unccommitted
-- set transaction isolation level read uncommitted
-- 
-- 
-- select 	CodiceOperatoreSDC,
-- 	RagioneSociale,
-- 	CRN,
-- 	CodiceContratto,
-- 	Ora,
-- 	CodiceUnitaSDC,
-- 	QtyMWh,
-- 	QtyMWhBilanciamento,
-- 	QtyMWhAssegnataMGP
-- from
-- (
-- select 
-- case (ProgrammaOrarioPerUnita.ProgrammatoDalCedente) 
-- when 1 then Contratto.CodiceOperatoreSDCCedente
-- else  Contratto.CodiceOperatoreSDCAcquirente
-- end CodiceOperatoreSDC,
-- 
-- case (ProgrammaOrarioPerUnita.ProgrammatoDalCedente) 
-- when 1 then (
-- select RagioneSociale from SDC_Operatori 
-- where CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCCedente
-- )
-- else (
-- select RagioneSociale from SDC_Operatori 
-- where CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCAcquirente
-- )
-- end RagioneSociale,
-- 
-- Contratto.CRN,
-- Contratto.CodiceContratto,
-- 
-- ProgrammaOrarioPerUnita.PeriodoRilevante Ora,
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC,
-- ProgrammaOrarioPerUnita.QtyMWh,
-- ProgrammaOrarioPerUnita.QtyMWhBilanciamento,
-- ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP
-- 
-- 
-- from ProgrammaOrarioPerUnita
-- 
-- inner join Contratto
-- 
-- on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 
-- 
-- where not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
-- and ProgrammaOrarioPerUnita.DataProgramma = @DataProgramma
-- ) X
-- where X.CodiceOperatoreSDC = @Operatore or @Operatore = ''
-- order by CodiceOperatoreSDC,
-- CRN,
-- Ora,
-- CodiceUnitaSDC
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportStoricoProgrammi]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportStoricoProgrammi]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportStoricoProgrammi]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE spReportXmlCorrispettivi
-- 	@DataProgrammaMin as smalldatetime,
-- 	@DataProgrammaMax as smalldatetime,
-- 	@Transitorio as int
-- AS
-- -- vecchia versione non piu` usata
-- 
-- 
-- -- e` un report da fare A FINE MERCATO
-- 
-- -- le quantita` trattate sono correttamente roundate e i dati restituiti hanno
-- -- il corretto numero di digit significativi
-- 
-- -- ATTENZIONE:
-- -- alcune colonne di questa query escono castate a decimal(x, scale).
-- -- L'impostazione di scale viene usata per stabilire quante cifre decimali
-- -- sono necessarie nel report XML dei corrispettivi !!! (quando arriva l'SqlDecimal dal 
-- -- SqlDataReader leggo lo Scale per costruire al volo la maschera che verra`
-- -- utilizzata per il toString)
-- --
-- -- Notare che:
-- -- select cast(1.123456 as decimal(15,3)) ritorna 1.123
-- -- select round(cast(1.123456 as decimal(15,6)),3 ritorna 1.123000
-- -- 
-- -- Dunque quando si fanno i calcoli e` importante fare o cast o round
-- -- (es Qty * Prezzo) per ottenere un numero
-- -- e poi in uscita dalla query fare cast(xx, scale) con lo scale opportuno
-- 
-- select
-- POU.DataProgramma,
-- POU.CodiceOperatoreSDC,
-- POU.CRN,
-- POU.CodiceContratto,
-- POU.CodiceUnitaSDC,
-- POU.CategoriaUnitaSDC,
-- POU.PeriodoRilevante,
-- POU.TipoUnita,
-- cast(POU.PrezzoUnico  as decimal(19, 6)) as PrezzoUnico,   -- il prezzo unico  e` a 6 cifre
-- cast(POU.PrezzoZonale as decimal(19, 6)) as PrezzoZonale,  -- il prezzo zonale e` a 6 cifre
-- cast(QtyMGP as decimal(16,3)) Qty, -- la quantita` in MWh e` a 3 cifre
-- 
-- -- qui si ha:
-- -- QtyMGP>0 per P
-- -- QtyMGP<0 per C
-- -- QtyMGP>0 per M che producono
-- -- QtyMGP<0 per M che consumano
-- 
-- cast(
-- 	case @Transitorio 
-- 	when 1 then 
-- 		-- caso per i programmi di sola produzione ossia con contratti sbilanciati ammessi
-- 		case TipoUnita 
-- 		when 'P' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2) 
-- 		when 'C' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2)  
-- 		when 'M' then  ROUND(-1 * ROUND(QtyMGP,3) * (ROUND(PrezzoZonale,6) - ROUND(PrezzoUnico,6)), 2)  
-- 		end
-- 	else 
-- 		-- caso per i programmi di produzione/consumo ossia con contratti bilanciati
-- 		case TipoUnita 
-- 		
-- 		when 'P' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoZonale,6), 2)
-- 		when 'C' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoUnico, 6), 2)
-- 		when 'M' then  ROUND(-1 * ROUND(QtyMGP,3) * ROUND(PrezzoZonale,6), 2)
-- 		end 
-- 	end
-- 	as decimal(16, 2)) Corr  -- gli euro dei corrispettivi escono in centesimi (e nel report XML Corrispettivi saranno a 2 cifre  - come sta scritto qui! se ci fosse un ,3 avremmo 3 cifre nel xml)
-- 
-- from 
-- (
-- select 
-- ProgrammaOrarioPerUnita.DataProgramma,
-- Contratto.CodiceOperatoreSDC,
-- Contratto.CRN,
-- Contratto.CodiceContratto,
-- ProgrammaOrarioPerUnita.PeriodoRilevante,
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC,
-- ProgrammaOrarioPerUnita.CategoriaUnitaSDC,
-- 
-- ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita / SDC_Unita.CoefficientePerdita QtyMGP,
-- SDC_Unita.TipoUnita,
-- SDC_Unita.CoefficientePerdita KU, 
-- SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP,
-- SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
-- 
-- PrezzoUnitario.Prezzo PrezzoUnico,
-- PrezzoZonale.Prezzo PrezzoZonale
-- 
-- from 
-- ProgrammaOrarioPerUnita
-- 
-- inner join Contratto
-- on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 
-- 
-- inner join SDC_Unita
-- on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
-- and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC
-- 
-- inner join SDC_PuntiDiScambioRilevanti
-- on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 
-- 
-- inner join PrezzoUnitario
-- on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
-- and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
-- 
-- inner join PrezzoZonale
-- on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
-- and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
-- and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC
-- 
-- where 
-- not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
-- and ProgrammaOrarioPerUnita.DataProgramma >= @DataProgrammaMin
-- and ProgrammaOrarioPerUnita.DataProgramma <= @DataProgrammaMax
-- --and ProgrammaOrarioPerUnita.IdContratto = Contratto.IdContratto
-- ) POU
-- order by 
-- POU.DataProgramma,
-- POU.CodiceOperatoreSDC,
-- POU.CRN,
-- POU.CodiceUnitaSDC,
-- POU.PeriodoRilevante
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE PROCEDURE dbo.spReportXmlCorrispettivi2
-- @DataFlusso as datetime
-- 
-- AS
-- 
-- -- qui non si usa read uncommitted perche` si calcolano 
-- -- i soldi. Si preferisce usare dati consolidati
-- 
-- 
-- --declare @DataFlusso as smalldatetime
-- --set @DataFlusso = '1/1/2004'
-- 
-- 
-- -- Corrispettivi CCT/CSP per data
-- ----------------------------------------------------------------------------
-- -- Siccome le formule sono complicate e "instabili"
-- -- si sceglie di fare calcoli e accorpamenti in C#
-- -- piuttosto che direttamente il SQL.
-- -- Questa scelta comporta che il codice in C# dovra` essere facilmente
-- -- upgradabile (ossia senza una distribuzione da fare)
-- 
-- ----------------------------------------------------------------------------
-- -- Dopo non pochi travagli dovuti al fatto che le formule 
-- -- "standard" dei CCT e CSP non sono
-- -- corrette quando le unita` miste che consumano pagano il prezzo zonale,
-- -- B.D. ci comunica il 11/11/04 che, dato che i pompaggi non dovrebbero
-- -- essere usati in NAB, il problema non si pone.
-- -- 
-- -- Procediamo con le "solite" formule:
-- -- CCT = Sommatoria per le unita` che producono di (Qp(Pun-Pz)) ove Pz e` il prezzo
-- --       zonale della zona dove risiede l'unita` che produce Qp. Qp al clearing point.
-- --       Somm(Qp(Pun-Pz))
-- -- CSP = (Somm(Qc) - Somm(Qp))Pun
-- --       dato che Qc e` nel DB segnata la formula per noi e` 
-- --       (Somm(-Qc) - Somm(Qp))Pun   e con brillanti passaggi
-- --       (-Somm(Qc) - Somm(Qp))Pun   e ripetendo ancora
-- --       -(Somm(Q))Pun               dove Q e` indifferentemente unita di produzione/consumo al clearing point
-- --
-- -- Questa query riporta la lista delle unita` con quantita` associata (dunque che hanno visto il mercato).
-- -- Per ogni unita` si tenta di calcolare il contributo della stessa al CCT e al CSP.
-- -- Il CCT per unita` deve essere 0 per le unita` che consumano o Qp(Pun-Pz) per quelle che producono.
-- -- Il CSP per unita` deve essere -Q*Pun
-- --
-- --
-- -- Le formule definitive dovrebbero essere:
-- -- ipotesi iniziale la produzione si ripartisce in maniera proporzionale
-- -- alle unita` di consumo: ogni unita` di consumo viene rapportata ad una produzione
-- -- Qptot*Qc/Qctot (e` proporzionale al consumo dell'unita` diviso al consumo totale nel contratto)
-- --
-- -- Le formule riportate qui sotto tengono conto di possibili unita`
-- -- che consumano al prezzo zonale (e in generale sono valide per ogni unita` Qx che
-- -- ha associato un prezzo Px)
-- -- CCT = Sommp(Qp(Pun-Pp)) + Qptot(Sommc(Kc(Pc-Pun)))
-- -- CSP = Sommc(PcQc) - Sommp(QpPun) - Qptot(Sommc(Kc(Pc-Pun)))
-- -- dove:
-- -- Sommp = sommatoria per tutte le unita` che producono energia
-- -- Sommc = sommatoria per tutte le unita` che consumano energia
-- -- Qp    = quantita` energia prodotta
-- -- Qc    = quantita` energia consumata
-- -- Pp    = prezzo associato alla Qp
-- -- Pc    = prezzo associato alla Qc
-- -- Qptot = totale energia prodotta nel contratto
-- -- Kc    = Qc/Qctot --> indica la percentuale(/100) del consumo di quella unita per il contratto
-- -- Qctot = totale enbergia consumanta nel contratto
-- -- Notare che se Pc e` sempre Pun le formule si semplificano alle formule "storiche".
-- -- Se esiste una unita` di consumo con prezzo diverso da Pun interviene in entrambi le
-- -- formule un fattore per "bilanciare" il CCT e il CSP.
-- -- Notare infine che 
-- -- la formula del CCT e` scomponibile per unita` di produzione, nel senso che e` possibile
-- -- individuare un contributo per unita` di produzione al CCT.
-- -- CCTp = Qp(Pun-Pp) + Qp(Sommc(Kc(Pc-Pun)))   --> CCT per unita` di produzione
-- -- il CSP invece, mi sembra, non sia facilmente scomponibile per unita`, dato che dipende sia dalle
-- -- unita` che consumano che da quelle che producono: questa caratteristica rende il CSP non facilmente
-- -- giustificabile agli occhi dell'acquirente dato che vige il riserbo sulle unita` utilizzate dalla
-- -- controparte.
-- -- Dal punto del GRTN invece il CSP si puo` scomporre in:
-- -- CSPc = PcQc - Qptot(Sommc(Kc(Pc-Pun))) per le unita Qc
-- -- CSPp = QpPun                           per le unita Qp
-- 
-- 
-- 
-- select 
-- Contratto.CodiceOperatoreSDC             OpResp,
-- Contratto.CodiceOperatoreSDCAcquirente   OpAcq,
-- OpAcquirente.IsGMEOp                     OpAcqIsGmeOp,
-- 
-- Contratto.CRN,
-- Contratto.CodiceContratto,
-- ProgrammaOrarioPerUnita.PeriodoRilevante,
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC,
-- ProgrammaOrarioPerUnita.CategoriaUnitaSDC,
-- 
-- SDC_Unita.TipoUnita,
-- SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
-- 
-- PrezzoUnitario.Prezzo PrezzoUnico,   
-- PrezzoZonale.Prezzo   PrezzoZonale,  
-- 
-- ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,
-- SDC_Unita.CoefficientePerdita                       KU,
-- SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita   KP
-- 
-- from 
-- ProgrammaOrarioPerUnita
-- 
-- inner join Contratto
-- on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 
-- 
-- inner join SDC_Unita
-- on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
-- and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC
-- 
-- inner join SDC_PuntiDiScambioRilevanti
-- on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 
-- 
-- inner join PrezzoUnitario
-- on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
-- and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
-- 
-- inner join PrezzoZonale
-- on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
-- and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
-- and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC
-- 
-- inner join Operatori OpAcquirente
-- on Contratto.CodiceOperatoreSDCAcquirente = OpAcquirente.CodiceOperatoreSDC
-- 
-- where 
-- not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
-- and ProgrammaOrarioPerUnita.DataProgramma = @DataFlusso
-- 
-- order by 
-- Contratto.CRN,
-- ProgrammaOrarioPerUnita.PeriodoRilevante
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi2]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi2]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlCorrispettivi2]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE  PROCEDURE dbo.spReportXmlProgrammi
-- 	@DataProgramma as smalldatetime,
-- 	@IdContratto as integer
-- AS
-- 
-- -- qui non usiamo read uncommitted in quanto 
-- -- i dati da visualizzare nel file XML sono "documenti"
-- -- e dato che l'elaboarazione e` in batch per cui non dovremmo mai incontrare 
-- -- dati bloccati in scrittura
-- 
-- -- declare
-- -- 	@DataProgramma as smalldatetime,
-- -- 	@IdContratto as integer
-- -- 
-- -- set @DataProgramma = '1/12/2004'
-- -- set @IdContratto = 212
-- 
-- 
-- declare @NextDateMonth as integer
-- declare @Ore as integer
-- set @NextDateMonth= DATEPART(month,@DataProgramma + 7)
-- set @Ore = 24
-- if (month(@DataProgramma) = 3  and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 4)
-- 	set @Ore = 23
-- if (month(@DataProgramma) = 10 and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 11)
-- 	set @Ore = 25
-- 
-- 
-- select 
-- PB1.Ora PeriodoRilevante,
-- PB1.IdContratto,
-- PB1.CRN,
-- PB1.CodiceOperatoreSDCAcquirente,
-- PB1.CodiceOperatoreSDCCedente,
-- 
-- PB2.CodiceUnitaSDC,
-- PB2.CategoriaUnitaSDC,
-- PB2.TipoUnita,
-- PB2.UnitaAssegnataOpAcquirente,
-- PB2.UnitaAssegnataOpCedente,
-- PB2.CodicePuntoDiScambioRilevanteSDC,
-- PB2.CodiceZonaSDC,
-- 
-- -- aggiunti per calcolare la quantita` assegnata al clearing point
-- PB2.KU KU,
-- PB2.KP KP,
-- 
-- PB2.IdContratto POIdContratto,
-- PB2.Bilanciato,
-- PB2.ProgrammaOrarioValidato,
-- PB2.SbilanciamentoMWh,
-- PB2.SbilanciamentoMWhReale,
-- 
-- PB2.IdContratto POUIdContratto,
-- PB2.QtyMWh,
-- PB2.QtyMWhBilanciamento,
-- PB2.QtyMWhAssegnataMGP,
-- PB2.ProgOrarioDellUnitaValidato,
-- PB2.ProgrammatoDalCedente,
-- PB2.IdProgrammaXml,
-- 
-- PB2.Origin,
-- PB2.ReasonCode,
-- PB2.ReasonText
-- 
-- from
-- (
-- 	select 
-- 	Contratto.IdContratto,
-- 	Contratto.CRN,
-- 	Contratto.CodiceOperatoreSDCAcquirente,
-- 	Contratto.CodiceOperatoreSDCCedente,
-- 	Ore.Ora
-- 	from Contratto, Ore
-- 	where
-- 	Contratto.IdContratto = @IdContratto
-- 	and Contratto.StatoContratto='Abilitato'
-- 	and Contratto.DataInizioValidita <= @DataProgramma
-- 	and Contratto.DataFineValidita >= @DataProgramma
-- 	and Contratto.TrCN = 1
-- 	and Ora <= @Ore
-- ) PB1
-- left outer join
-- (
-- select
-- PR.PeriodoRilevante,
-- 
-- UC.IdContratto,
-- UC.CRN,
-- UC.CodiceUnitaSDC,
-- UC.CategoriaUnitaSDC,
-- UC.TipoUnita,
-- UC.UnitaAssegnataOpAcquirente,
-- UC.UnitaAssegnataOpCedente,
-- UC.CodicePuntoDiScambioRilevanteSDC,
-- UC.CodiceZonaSDC,
-- 
-- -- aggiunti per calcolare la quantita` assegnata al clearing point
-- UC.KU KU,
-- UC.KP KP,
-- 
-- PO.IdContratto POIdContratto,
-- PO.Bilanciato,
-- PO.ProgrammaOrarioValidato,
-- PO.SbilanciamentoMWh,
-- PO.SbilanciamentoMWhReale,
-- 
-- POU.IdContratto POUIdContratto,
-- POU.QtyMWh,
-- POU.QtyMWhBilanciamento,
-- POU.QtyMWhAssegnataMGP,
-- POU.ProgOrarioDellUnitaValidato,
-- POU.ProgrammatoDalCedente,
-- POU.IdProgrammaXml,
-- 
-- POUE.Origin,
-- POUE.ReasonCode,
-- POUE.ReasonText
-- 
-- from 
-- (
-- 	select 
-- 	Ora PeriodoRilevante 
-- 	from Ore
-- 	where Ora <= @Ore
-- ) PR
-- inner join
-- (
-- 	select 
-- 	Contratto.IdContratto,
-- 	Contratto.CRN,
-- 	Contratto.CodiceOperatoreSDCAcquirente,
-- 	Contratto.CodiceOperatoreSDCCedente,
-- 	UnitaContratto.CodiceUnitaSDC,
-- 	UnitaContratto.CategoriaUnitaSDC,
-- 	UnitaContratto.UnitaAssegnataOpAcquirente,
-- 	UnitaContratto.UnitaAssegnataOpCedente,
-- 	
-- 	SDC_Unita.TipoUnita,
-- 	SDC_Unita.CodicePuntoDiScambioRilevanteSDC,
-- 	SDC_Unita.CoefficientePerdita KU,
-- 
-- 	SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
-- 	SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP
-- 	
-- 	from Contratto
-- 	inner join tab_UnitaContratto2(@DataProgramma, @IdContratto) UnitaContratto
-- 	on
-- 		Contratto.StatoContratto='Abilitato'
-- 		and Contratto.DataInizioValidita <= @DataProgramma
-- 		and Contratto.DataFineValidita >= @DataProgramma
-- 		and Contratto.TrCN = 1
-- 		and Contratto.IdContratto = UnitaContratto.IdContratto
-- 		and UnitaContratto.UnitaDelContrattoValidata = 1
-- 		and UnitaContratto.TrCC = 1
-- 		and UnitaContratto.TrUC = 1
-- 		and UnitaContratto.DataInizioValidita <= @DataProgramma
-- 		and UnitaContratto.DataFineValidita >= @DataProgramma
-- 	inner join SDC_Unita
-- 	on 
-- 		SDC_Unita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC
-- 		and SDC_Unita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC
-- 	inner join SDC_PuntiDiScambioRilevanti
-- 	on 
-- 		SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- 	where
-- 		Contratto.IdContratto = @IdContratto
-- 
-- ) UC
-- on
-- 	1=1
-- --LEFT OUTER JOIN
-- inner join
-- (
-- 	select
-- 	IdContratto,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC,
-- 	PeriodoRilevante,
-- 	QtyMWh,
-- 	QtyMWhBilanciamento,
-- 	QtyMWhAssegnataMGP,
-- 	ProgOrarioDellUnitaValidato,
-- 	ProgrammatoDalCedente,
-- 	IdProgrammaXml
-- 	from 
-- 	ProgrammaOrarioPerUnita
-- 	where 
-- 	DataProgramma=@DataProgramma
-- 	and IdContratto = @IdContratto
-- 
-- ) POU
-- on 
-- 	POU.IdContratto=UC.IdContratto
-- 	and POU.PeriodoRilevante=PR.PeriodoRilevante
-- 	and POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	and POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- 
-- --LEFT OUTER JOIN
-- inner join
-- (
-- 	select
-- 	IdContratto,
-- 	PeriodoRilevante,
-- 	Bilanciato,
-- 	ProgrammaOrarioValidato,
-- 	SbilanciamentoMWh,
-- 	SbilanciamentoMWhReale
-- 	from
-- 	ProgrammaOrario
-- 	where 
-- 	DataProgramma=@DataProgramma
-- 	and IdContratto = @IdContratto
-- ) PO
-- on
-- 	PO.IdContratto=UC.IdContratto
-- 	and PO.PeriodoRilevante=PR.PeriodoRilevante
-- 
-- LEFT OUTER JOIN -- e` giusto la left outer join: gli errori a fronte di una programmazione ci possono anche non essere
-- (
-- 	select
-- 	IdContratto,
-- 	PeriodoRilevante,
-- 	CodiceUnitaSDC,
-- 	CategoriaUnitaSDC,
-- 	Origin,
-- 	ReasonCode,
-- 	ReasonText
-- 	from 
-- 	ProgrammaOrarioPerUnitaErrori
-- 	where 
-- 	DataProgramma=@DataProgramma
-- 	and IdContratto = @IdContratto
-- ) POUE
-- on 
-- 	POUE.IdContratto=UC.IdContratto
-- 	and POUE.PeriodoRilevante=PR.PeriodoRilevante
-- 	and POUE.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	and POUE.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- )
-- PB2
-- 
-- on 
-- PB1.IdContratto = PB2.IdContratto and
-- PB1.Ora         = PB2.PeriodoRilevante
-- order by
-- PB1.CRN,
-- PB1.Ora,
-- PB2.ProgrammatoDalCedente
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlProgrammi]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlProgrammi]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlProgrammi]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE spReportXmlResponsabiliUnita
-- 	@DataProgramma as smalldatetime
-- AS
-- 
-- -- qui non usiamo read uncommitted in quanto 
-- -- i dati da visualizzare nel file XML sono "documenti"
-- -- e dato che l'elaboarazione e` in batch per cui non dovremmo mai incontrare 
-- -- dati bloccati in scrittura
-- 
-- 
-- -- questo e` un report a mercato chiuso!!!
-- -- non bisogna consultare i flag (TrCC ecc) 
-- -- l'unica informazione che vale e` che QtyMWhAssegnataMGP non sia NULL
-- --
-- 
-- select 
-- SDC_Unita.CodiceOperatoreDiRiferimentoSDC,
-- ProgrammaOrarioPerUnita.PeriodoRilevante,
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC,
-- ProgrammaOrarioPerUnita.CategoriaUnitaSDC,
-- sum(cast(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP as decimal(16,3))) QtyMWhTotale
-- from ProgrammaOrarioPerUnita
-- inner join SDC_Unita
-- on  SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
-- and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC
-- where 
-- ProgrammaOrarioPerUnita.DataProgramma = @DataProgramma
-- and not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null
-- group by
-- SDC_Unita.CodiceOperatoreDiRiferimentoSDC,
-- ProgrammaOrarioPerUnita.PeriodoRilevante,
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC,
-- ProgrammaOrarioPerUnita.CategoriaUnitaSDC
-- order by
-- SDC_Unita.CodiceOperatoreDiRiferimentoSDC,
-- ProgrammaOrarioPerUnita.PeriodoRilevante,
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC,
-- ProgrammaOrarioPerUnita.CategoriaUnitaSDC
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlResponsabiliUnita]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlResponsabiliUnita]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlResponsabiliUnita]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE spReportXmlTitolari
-- 	@DataProgramma as smalldatetime
-- AS
-- -- set @DataProgramma = '20/4/04'
-- 
-- -- codice per capire quante ore fa il giorno in ingresso: 23/24/25
-- declare @NextDateMonth as integer
-- declare @Ore as integer
-- set @NextDateMonth= DATEPART(month,@DataProgramma + 7)
-- set @Ore = 24
-- if (month(@DataProgramma) = 3  and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 4)
-- 	set @Ore = 23
-- if (month(@DataProgramma) = 10 and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 11)
-- 	set @Ore = 25
-- 
-- 
-- -- questa semplice select
-- -- ritorna per PeriodoRilevante/Contratto/Zona la somma dell'energia delle unita` (applicando i coeff. di perdita)
-- -- di tipo C, P ed M.
-- -- Inoltra ritorna 
-- -- Il codice del titolare (resp. partite economiche del contratto)
-- -- Il/i prezzi unico/zonali
-- -- Il periodo rilevante
-- -- l'IdContratto che si trova in PO.
-- --
-- -- Performance: agisce nell'ordine corretto aggregando solo alla fine e tramite indice
-- -- le tabelle PO e POU... meglio di cosi` non si puo`.
-- --
-- 
-- select
-- Z.CRN,                        -- varia per contratto
-- Z.CodiceOperatoreSDCTitolare, -- varia per contratto
-- Z.PeriodoRilevante,           -- varia per contratto/periodo rilevante
-- Z.CodiceZonaSDC,              -- varia per contratto/periodo rilevante/zona
-- Z.POIdContratto,              -- non varia per Contratto/Data/PR/Zona/TipoUnita --> posso usarla nel group by
-- Z.ProgrammaOrarioValidato,    -- come sopra
-- Z.PrezzoZonale,               -- varia per zona/periodo rilevante
-- Z.PrezzoUnico,                -- varia per periodo rilevante
-- 
-- sum(case Z.TipoUnita when 'P' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyP,
-- sum(case Z.TipoUnita when 'C' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyC,
-- sum(case Z.TipoUnita when 'M' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyM
-- 
-- from
-- (
-- 	-- questa select produce record distinti
-- 	-- per contratto/PeridoRilevante/Zona/TipoUnita
-- 	-- se POIdContratto e` NULL significa che il contratto per quel PR non ha programmazione
-- 	-- se POIdContratto <> NULL e ProgrammaOrarioValidato e` 1 significa che il contratto ha generato offerte
-- 	-- se POIdContratto <> NULL e ProgrammaOrarioValidato e` 0 significa che il contratto e` stato disabilitato per generare offerte
-- 	select
-- 	UC.CRN,
-- 	UC.CodiceOperatoreSDCTitolare,
-- 	PR.PeriodoRilevante,
-- 	UC.CodiceZonaSDC,
-- 	UC.TipoUnita,
-- 	PO.IdContratto POIdContratto,  -- non varia per Contratto/Data/PR/Zona/TipoUnita --> posso usarla nel group by
-- 	PO.ProgrammaOrarioValidato,
-- 	sum(round(IsNull(POU.QtyMWhAssegnataMGP,0) * UC.KP / UC.KU,3)) QtyMWhPerZonaTipoUnita, -- QtyMWh dopo i coeff di perdita
-- 	PrezzoZonale.Prezzo   PrezzoZonale,
-- 	PrezzoUnitario.Prezzo PrezzoUnico
-- 	from 
-- 	(
-- 		-- ottengo quante ore ci sono nella data in ingresso (@DataProgramma)
-- 		select 
-- 		Ora PeriodoRilevante 
-- 		from Ore
-- 		where Ora <= @Ore
-- 	) PR
-- 	cross join -- prodotto cartesiano
-- 	(
-- 		-- questa select trova tutte i contratti/unita da programmare in un dato giorno
-- 		-- Poi con un po' di join ritorna anche il TipoUnita, coeff/ perdita ecc.
-- 		-- Incrociando poi i dati di questa select con la tabella PR
-- 		-- si ottiene la lista dei contratti/unita/periodi_rilevanti da programmare
-- 		select 
-- 		Contratto.IdContratto,
-- 		Contratto.CRN,
-- 		Contratto.CodiceOperatoreSDC CodiceOperatoreSDCTitolare,
-- 		UnitaContratto.CodiceUnitaSDC,
-- 		UnitaContratto.CategoriaUnitaSDC,
-- 		UnitaContratto.UnitaAssegnataOpAcquirente,
-- 		UnitaContratto.UnitaAssegnataOpCedente,
-- 		SDC_Unita.TipoUnita,
-- 		SDC_Unita.CoefficientePerdita KU,
-- 		SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
-- 		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP
-- 		from Contratto
-- 		inner join tab_UnitaContratto(@DataProgramma) UnitaContratto on 
-- 			Contratto.StatoContratto='Abilitato'
-- 			and Contratto.DataInizioValidita <= @DataProgramma
-- 			and Contratto.DataFineValidita >= @DataProgramma
-- 			and Contratto.TrCN = 1
-- 			and Contratto.IdContratto = UnitaContratto.IdContratto
-- 			and UnitaContratto.UnitaDelContrattoValidata = 1
-- 			and UnitaContratto.TrCC = 1
-- 			and UnitaContratto.TrUC = 1
-- 			and UnitaContratto.DataInizioValidita <= @DataProgramma
-- 			and UnitaContratto.DataFineValidita >= @DataProgramma
-- 		inner join SDC_Unita on 
-- 			SDC_Unita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC
-- 			and SDC_Unita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC
-- 		inner join SDC_PuntiDiScambioRilevanti on
-- 			SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- 	) UC
-- 	inner join PrezzoZonale	on -- il prezzo zonale dipende dal PeriodoRilevante (non posso mettere questa join dentro UC)
-- 		PrezzoZonale.Data = @DataProgramma
-- 		and PrezzoZonale.PeriodoRilevante=PR.PeriodoRilevante
-- 		and PrezzoZonale.CodiceZonaSDC = UC.CodiceZonaSDC
-- 	inner join PrezzoUnitario on -- il prezzo unico dipende dal PeriodoRilevante (non posso mettere questa join dentro UC)
-- 		PrezzoUnitario.Data = @DataProgramma
-- 		and PrezzoUnitario.PeriodoRilevante=PR.PeriodoRilevante
-- 	left outer join -- se non esistono i record in PO per il contratto/data/ora ritorna NULL
-- 	(
-- 		-- qui trovo tutti i PO a prescindere se sono o no validati.
-- 		-- in questo modo se non esiste programmazione per un contratto/data/pr
-- 		-- PO.IdContratto (dopo la left join) sara` NULL
-- 		-- se invece esiste avro` PO.IdContratto<>NULL con PO.ProgrammaOrarioValidato 
-- 		-- a 1 se il programma ha generato offerte o 0 altrimenti
-- 		select
-- 		IdContratto,
-- 		PeriodoRilevante,
-- 		ProgrammaOrarioValidato
-- 		from
-- 		ProgrammaOrario
-- 		where 
-- 		DataProgramma=@DataProgramma
-- 	) PO
-- 	on -- metto in relazione la chiave di PO con UC/PR (escludo DataProgramma dato che e` gia` filtrata)
-- 		PO.IdContratto = UC.IdContratto
-- 		and PO.PeriodoRilevante = PR.PeriodoRilevante
-- 	left outer join -- se non esistono i record in POU per il contratto/data/ora/Unita ritorna NULL
-- 	(
-- 		-- qui trovo tutti i POU ma solo quelli validati
-- 		-- e non QtyMWhAssegnataMGP valorizzata della data in ingresso.
-- 		-- Se il record del un Contratto/Data/PR/Unita non esiste (perche` o non c'e` o non e` validato o non e` valorizzato)
-- 		-- la left join produrra` tutti valori NULL
-- 		select
-- 		IdContratto,
-- 		QtyMWhAssegnataMGP,
-- 		ProgrammatoDalCedente,
-- 		PeriodoRilevante,
-- 		CodiceUnitaSDC,
-- 		CategoriaUnitaSDC
-- 		from 
-- 		ProgrammaOrarioPerUnita
-- 		where 
-- 		DataProgramma=@DataProgramma
-- 		and ProgOrarioDellUnitaValidato=1
-- 		and not QtyMWhAssegnataMGP is null
-- 	) POU
-- 	on  -- metto in relazione la chiave di POU con UC/PR (escludo DataProgramma dato che e` gia` filtrata)
-- 		POU.IdContratto = UC.IdContratto
-- 		and POU.PeriodoRilevante = PR.PeriodoRilevante
-- 		and POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 		and POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- 	group by  -- aggrego per sommare le Qty per tipo unita / zona di un contratto/periodo_rilevante
-- 	UC.CRN,                        -- varia per contratto
-- 	UC.CodiceOperatoreSDCTitolare, -- varia per contratto
-- 	PR.PeriodoRilevante,           -- varia per contratto/periodo rilevante
-- 	UC.CodiceZonaSDC,              -- varia per contratto/periodo rilevante/zona
-- 	UC.TipoUnita,                  -- varia per contratto/periodo rilevante/zona/tipounita
-- 	PrezzoZonale.Prezzo,           -- varia per periodo rilevante/zona
-- 	PrezzoUnitario.Prezzo,         -- varia per zona
-- 	PO.IdContratto,                -- varia per contratto/periodo rilevante
-- 	PO.ProgrammaOrarioValidato     -- varia per contratto/periodo rilevante
-- )Z
-- group by 
-- Z.CRN,                             -- varia per contratto
-- Z.CodiceOperatoreSDCTitolare,      -- varia per contratto
-- Z.PeriodoRilevante,                -- varia per contratto/periodo rilevante
-- Z.CodiceZonaSDC,                   -- varia per contratto/periodo rilevante/zona
-- Z.PrezzoZonale,                    -- varia per periodo rilevante/zona
-- Z.PrezzoUnico,                     -- varia per periodo rilevante
-- Z.POIdContratto,                   -- varia per contratto/periodo rilevante
-- Z.ProgrammaOrarioValidato          -- varia per contratto/periodo rilevante
-- order by
-- Z.CRN,
-- Z.PeriodoRilevante,
-- Z.CodiceZonaSDC
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE  PROCEDURE dbo.spReportXmlTitolari2
--   	@DataFlusso as smalldatetime
-- AS
-- 
-- -- qui non usiamo read uncommitted in quanto 
-- -- i dati da visualizzare nel file XML sono "documenti"
-- -- e dato che l'elaboarazione e` in batch per cui non dovremmo mai incontrare 
-- -- dati bloccati in scrittura
-- 
-- 
-- -- declare @DataFlusso as datetime
-- -- set @DataFlusso = '25/11/04'
-- 
-- -- codice per capire quante ore fa il giorno in ingresso: 23/24/25
-- declare @NextDateMonth as integer
-- declare @Ore as integer
-- set @NextDateMonth= DATEPART(month,@DataFlusso + 7)
-- set @Ore = 24
-- if (month(@DataFlusso) = 3  and DATEPART(weekday,@DataFlusso) = 8-@@datefirst and @NextDateMonth = 4)
-- 	set @Ore = 23
-- if (month(@DataFlusso) = 10 and DATEPART(weekday,@DataFlusso) = 8-@@datefirst and @NextDateMonth = 11)
-- 	set @Ore = 25
-- 
-- 
-- 
-- select 
-- 	PB1.IdContratto,
-- 	PB1.CRN,
-- 	PB1.CodiceOperatoreSDCTitolare,
-- 	PB1.Ora PeriodoRilevante,
-- 
-- 	PB2.CodiceZonaSDC,
-- 	PB2.PrezzoZonale,
-- 	PB2.PrezzoUnico,
-- 	IsNull(PB2.Status, 'ProgramNotSent') Status,
-- 	
-- 	PB2.QtyP,
-- 	PB2.QtyC,
-- 	PB2.QtyMP,
-- 	PB2.QtyMC
-- 
-- from
-- (
-- 	select 
-- 	Contratto.IdContratto,
-- 	Contratto.CRN,
-- 	Contratto.CodiceOperatoreSDC CodiceOperatoreSDCTitolare,
-- 	Ore.Ora 
-- 	from Contratto, Ore
-- 	where
-- 	Contratto.StatoContratto='Abilitato'
-- 	and Contratto.DataInizioValidita <= @DataFlusso
-- 	and Contratto.DataFineValidita >= @DataFlusso
-- 	and Contratto.TrCN = 1
-- 	and Ora <= @Ore
-- ) PB1
-- left outer join
-- (
-- 	select
-- 	Q.IdContratto,
-- 	Q.PeriodoRilevante,
-- 	Q.CodiceZonaSDC,
-- 	Q.PrezzoZonale,
-- 	Q.PrezzoUnico,
-- 	Q.Status,
-- 	
-- 	sum(case Q.TipoUnita when 'P'  then (Q.QtyMWhAssegnataMGP * Q.KP / Q.KU) else 0 end) QtyP,
-- 	sum(case Q.TipoUnita when 'C'  then (Q.QtyMWhAssegnataMGP * Q.KP / Q.KU) else 0 end) QtyC,
-- 	sum(case Q.TipoUnita when 'MP' then (Q.QtyMWhAssegnataMGP * Q.KP / Q.KU) else 0 end) QtyMP,
-- 	sum(case Q.TipoUnita when 'MC' then (Q.QtyMWhAssegnataMGP * Q.KP / Q.KU) else 0 end) QtyMC
-- 	
-- 	from 
-- 	(
-- 		select
-- 		POU.IdContratto, 
-- 		POU.PeriodoRilevante,
-- 		case 
-- 			when PO.ProgrammaOrarioValidato is null then 'ProgramNotSent'
-- 			when PO.ProgrammaOrarioValidato = 0 then     'ProgramRefused'
-- 			else 'ProgramAccepted' 
-- 		end Status,  -- varia per Contratto/periodoRilevante
-- 	
-- 		SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
-- 		PrezzoZonale.Prezzo PrezzoZonale,   -- varia per Contratto/periodoRilevante/Zona
-- 		PrezzoUnitario.Prezzo  PrezzoUnico, -- varia per Contratto/periodoRilevante
-- 		
-- 		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP, -- varia per Contratto/periodoRilevante/unita`
-- 		SDC_Unita.CoefficientePerdita KU, -- varia per Contratto/periodoRilevante/unita`
-- 		case SDC_Unita.TipoUnita
-- 			when 'P' then 'P'
-- 			when 'C' then 'C'
-- 			when 'M' then 
-- 			case 
-- 				when POU.ProgrammatoDalCedente=1 then 'MP'
-- 				when POU.ProgrammatoDalCedente=0 then 'MC'
-- 				else null
-- 			end
-- 		end TipoUnita, -- varia per Contratto/periodoRilevante/unita`
-- 		
-- 		POU.QtyMWhAssegnataMGP
-- 
-- 		from ProgrammaOrarioPerUnita POU
-- 
-- 		inner join ProgrammaOrario PO
-- 		on	POU.PeriodoRilevante  = PO.PeriodoRilevante
-- 		and POU.DataProgramma     = PO.DataProgramma
-- 		and POU.IdContratto       = PO.IdContratto
-- 
-- 		inner join SDC_Unita 
-- 		on  SDC_Unita.CodiceUnitaSDC    = POU.CodiceUnitaSDC
-- 		and SDC_Unita.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
-- 
-- 		inner join SDC_PuntiDiScambioRilevanti 
-- 		on  SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- 		
-- 		inner join PrezzoZonale	
-- 		on  PrezzoZonale.Data             = POU.DataProgramma
-- 		and PrezzoZonale.PeriodoRilevante = POU.PeriodoRilevante
-- 		and PrezzoZonale.CodiceZonaSDC    = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC
-- 		
-- 		inner join PrezzoUnitario 
-- 		on  PrezzoUnitario.Data = POU.DataProgramma
-- 		and PrezzoUnitario.PeriodoRilevante = POU.PeriodoRilevante
-- 
-- 		where
-- 		POU.DataProgramma = @DataFlusso
-- 		and not POU.QtyMWhAssegnataMGP is null
-- 
-- 	) Q
-- 	group by
-- 	Q.IdContratto,
-- 	Q.PeriodoRilevante,
-- 	Q.CodiceZonaSDC,
-- 	Q.PrezzoZonale,
-- 	Q.PrezzoUnico,
-- 	Q.Status
-- ) PB2
-- on 
-- PB1.IdContratto = PB2.IdContratto and
-- PB1.Ora         = PB2.PeriodoRilevante
-- 
-- order by
-- PB1.CRN,
-- PB1.PeriodoRilevante,
-- PB2.CodiceZonaSDC
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari2]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari2]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spReportXmlTitolari2]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE PROCEDURE spSessioneBilaterali_Fill
-- 	@DataProgrammaMin as smalldatetime,
-- 	@DataProgrammaMax as smalldatetime = NULL
-- as 
-- 
-- if @DataProgrammaMax is null
-- 	set @DataProgrammaMax=365+@DataProgrammaMin
-- 
-- 	
-- declare @d as smalldatetime
-- set @d = @DataProgrammaMin
-- 
-- declare @ok as int
-- 
-- while @d <= @DataProgrammaMax
-- begin
-- 	-- notare che qui potrebbe dare dei record duplicati se vi sono buchi:
-- 	-- non e` un problema in quanto non si sovrascrivono i dati esistenti
-- 
-- 	select @ok = count(*) from SessioneBilaterali where DataProgramma=@d
-- 	if @ok = 0
-- 	begin
-- 		INSERT INTO SessioneBilaterali (DataProgramma, Bilanciamento) VALUES (@d, 1)
-- 	end
-- 	else
-- 	begin
-- 		update SessioneBilaterali set Bilanciamento = 1 where DataProgramma = @d and  Bilanciamento = 0
-- 	end
-- 	set @d = 1 + @d
-- end
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spSessioneBilaterali_Fill]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spSessioneBilaterali_Fill]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spSessioneBilaterali_Fill]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- create PROCEDURE dbo.spSetBilanciamentoTaglioDaRifare
-- (
-- 		@DataProgramma smalldatetime = null
-- )
-- AS
-- 	SET NOCOUNT ON
-- 	
-- 	-- Questo script viene chiamato quando interviene una modifica
-- 	-- nelle anagrafiche (==> una modifica in UnitaContratto o in SDC_Unita/SDC_PuntiDiScambioRilevanti relativamente ai coefficienti di perdita)
-- 	-- o in ProgrammaOrario/ProgrammaOrarioPerUnita
-- 	-- Lo scopo e` centralizzare in un solo punto (SessioneBilaterali.Bilanciamento/Taglio)
-- 	-- l'informazione che indica se e` necessario ri-effettuare il calcolo del bilanciamento / taglio
-- 
-- 	-- a) se @DataProgramma non e` specificata la variazione e` causata da una 
-- 	--    modifica dei dati anagrafici dei bilaterali.
-- 	-- b) se @DataProgramma e` specificata allora la variazione e` causata da una modifica 
-- 	--    in ProgrammaOrario/ProgrammaOrarioPerUnita
-- 	--
-- 	-- Nel caso (a) bisogna aggiornare tutti record di SessioneBilaterali dalla data di domani e successive
-- 	-- Nel caso (b) bisogna aggiornare solo il record di SessioneBilaterali della data specificata
-- 
-- 	-- 1) Notare che in (a) posso settare il bit di Bilanciato a zero anche se le offerte o il mercato
-- 	-- sono gia` girati. Non e` un problema in quanto cosi` le modifiche saranno operative anche nell'
-- 	-- eventualita` di far ri-girare il mercato per lo stesso giorno.
-- 
-- 	-- 2) Notare che questo codice gestisce il caso di non esistenza del record
-- 	-- della SessioneBilaterali. E` da definire se e come si potra` rilassare il vincolo
-- 	-- imponendo che, quando questo script viene chiamato, il record esista;
-- 	-- in maniera conservativa qui, dunque, viene creato il record.
-- 
-- 	-- simulo i parametri in ingresso
-- 	--set @DataProgramma = convert(datetime,convert(varchar,1+getdate(),112))
-- 
-- 	----------------------------------------------------------------------------------------------
-- 	----------------------------------------------------------------------------------------------
-- 	----------------------------------------------------------------------------------------------
-- 	declare @DataDomani smalldatetime
-- 	set @DataDomani=convert(datetime,convert(varchar,1+getdate(),112))
-- 
-- 	-- se la data in ingresso e` nulla prendo la data di domani
-- 	if @DataProgramma is null
-- 	begin
-- 		-- aggiornamento delle anagrafiche ==> devo aggiornare TUTTI i record SessioniBilaterali
-- 		-- a1) aggiorno i record DOPO DataDomani
-- 		set @DataProgramma=@DataDomani
-- 
-- 		update 
-- 		SessioneBilaterali
-- 		set 
-- 		Bilanciamento=0,
-- 		Taglio=0
-- 		where DataProgramma>@DataProgramma -- notare il >
-- 	end
-- 
-- 	-- aggiorno il record di Domani
-- 	update 
-- 	SessioneBilaterali
-- 	set 
-- 	Bilanciamento=0,
-- 	Taglio=0
-- 	where DataProgramma=@DataProgramma -- notare l'=
-- 
-- 	-- se non esiste lo creo (cosi` e` pronto per gli altri usi)
-- 	if @@rowcount=0
-- 	begin
-- 		-- vedi nota (1)
-- 		insert into SessioneBilaterali
-- 		(DataProgramma, Bilanciamento, Taglio)
-- 		values
-- 		(@DataProgramma, 0, 0)
-- 	end
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spSetBilanciamentoTaglioDaRifare]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spSetBilanciamentoTaglioDaRifare]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spSetBilanciamentoTaglioDaRifare]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- CREATE PROCEDURE [dbo].[spUnitRelateDelete] 
-- @CodiceOperatoreSDC varchar(16),
-- @CodiceUnitaSDC varchar(16),
-- @CategoriaUnitaSDC varchar(1)
-- AS
-- 
-- set nocount off;
-- 
-- begin transaction
-- 
-- delete UnitRelate 
-- 	where 	CodiceOperatoreSDC = @CodiceOperatoreSDC and 
-- 		CodiceUnitaSDC = @CodiceUnitaSDC and 
-- 		CategoriaUnitaSDC = @CategoriaUnitaSDC and 
-- 	not exists (	
-- 		select *
-- 		from ProgrammaOrarioPerUnita POU, SDC_Unita SU
-- 		where SU.CodiceUnitaSDC = POU.CodiceUnitaSDC and
-- 		SU.CategoriaUnitaSDC = POU.CategoriaUnitaSDC and 
-- 		POU.CodiceUnitaSDC = @CodiceUnitaSDC and 
-- 		POU.CategoriaUnitaSDC = @CategoriaUnitaSDC and
-- 		POU.IdContratto in (
-- 			select IdContratto 
-- 			from Contratto 
-- 			where CodiceOperatoreSDCAcquirente = @CodiceOperatoreSDC or CodiceOperatoreSDCCedente = @CodiceOperatoreSDC
-- 		) 
-- 		and (
-- 	 		POU.ProgrammatoDalCedente = 0 and SU.TipoUnita in ('M', 'C')
-- 	 		or
-- 			POU.ProgrammatoDalCedente = 1 and SU.TipoUnita in ('M', 'P')
-- 		)
-- 	)
-- 
-- if  @@ERROR <> 0
-- begin
-- 	rollback
-- 	return
-- end
-- 
-- 
-- if @@ROWCOUNT > 0
-- begin
-- 	commit
-- 	return
-- end
-- 
-- update UnitRelate
-- set Abilitata = 0 
-- where 	CodiceOperatoreSDC = @CodiceOperatoreSDC and 
-- 	CodiceUnitaSDC = @CodiceUnitaSDC and 
-- 	CategoriaUnitaSDC = @CategoriaUnitaSDC and
--  exists (	
-- 	select *
-- 	from ProgrammaOrarioPerUnita POU, SDC_Unita SU
-- 	where SU.CodiceUnitaSDC = POU.CodiceUnitaSDC and
-- 	SU.CategoriaUnitaSDC = POU.CategoriaUnitaSDC and 
-- 	POU.CodiceUnitaSDC = @CodiceUnitaSDC and 
-- 	POU.CategoriaUnitaSDC = @CategoriaUnitaSDC and
-- 	POU.IdContratto in (
-- 		select IdContratto 
-- 		from Contratto 
-- 		where CodiceOperatoreSDCAcquirente = @CodiceOperatoreSDC or CodiceOperatoreSDCCedente = @CodiceOperatoreSDC
-- 	) 
-- 	and (
--  		POU.ProgrammatoDalCedente = 0 and SU.TipoUnita in ('M', 'C')
--  		or
-- 		POU.ProgrammatoDalCedente = 1 and SU.TipoUnita in ('M', 'P')
-- 	)
-- )
-- if  @@ERROR <> 0
-- begin
-- 	rollback
-- 	return
-- end
-- 
-- commit
-- 
-- return
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spUnitRelateDelete]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spUnitRelateDelete]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[spUnitRelateDelete]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- CREATE                               function [dbo].[GetOperatori] (@CodiceUnitaSDC as varchar(16), @CategoriaUnitaSDC as varchar, @Data as datetime)  
-- returns varchar(255)  AS  
-- begin 
-- 
-- 	declare @lstOperatori varchar(255)
-- 	declare @CodiceOperSDC varchar(16)
-- 	declare @indice int
-- 
-- 	declare operator_cursor cursor for
-- 		select CodiceOperatoreSDC
-- 		from UnitRelate
-- 		where @CodiceUnitaSDC = CodiceUnitaSDC
-- 			and @CategoriaUnitaSDC = CategoriaUnitaSDC
-- 			and @Data >= DataInizioValidita
-- 			and @Data <= DataFineValidita
-- 		order by CodiceOperatoreSDC
-- 
-- 
-- 	open operator_cursor 
-- 	set @indice = 0
-- 	set @lstOperatori = ' '
-- 	fetch next from operator_cursor INTO @CodiceOperSDC
-- 	while @@FETCH_STATUS = 0
-- 	begin
-- 		set @lstOperatori = @CodiceOperSDC + ' ' + @lstOperatori
-- 		set @indice = @indice + 1
-- 		if @indice = 8 break
-- 		fetch next from operator_cursor INTO @CodiceOperSDC
-- 	end
-- 	
-- 	close operator_cursor
-- 	deallocate operator_cursor
-- 
-- 	return(@lstOperatori)
-- end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[GetOperatori]  TO [public]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[GetOperatori]  TO [bil_user]
-- GO
-- 
-- GRANT  EXECUTE  ON [dbo].[GetOperatori]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- /****** Object:  User Defined Function dbo.UnitaContrattiOra    Script Date: 12/05/2004 14.46.06 ******/
-- 
-- /****** Object:  User Defined Function dbo.UnitaContrattiOra    Script Date: 01/04/2004 14.58.12 ******/
-- CREATE function UnitaContrattiOra(@DATE datetime )
-- returns @retUnitaContrattiOra table (Ora int, 
--  	IdContratto char(32) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CodiceUnitaSDC varchar(256) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CategoriaUnitaSDC varchar(20) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	u_DataInizioValidita datetime ,
-- 	u_DataFineValidita datetime ,
-- 	u_TSModifica datetime,
-- 	UnitaDelContrattoValidata bit ,
-- 	UnitaAssegnataOpCedente bit ,
-- 	UnitaAssegnataOpAcquirente bit ,
-- 	PrioritaBilanciamentoForzato int ,
-- 	CodiceContratto varchar(50) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	c_DataInizioValidita datetime,
-- 	c_DataFineValidita datetime ,
-- 	CRN varchar(30) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	StatoContratto varchar(32) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CodiceOperatoreSDC varchar(256) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	c_TSModifica datetime,
-- 	CodiceOperatoreSDCAcquirente varchar(256)COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	CodiceOperatoreSDCCedente varchar (256)COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	ProgrammazionePrivilegiata bit ,
-- 	CoefficientePerdita float )
-- as
-- begin
-- 	declare @RowsAdded int,
-- 		@RowCount int,
-- 		@Month int,
-- 		@WeekDay int,
-- 		@NextDate datetime,
-- 		@NextDateMonth int,
-- 		@LastDayOfWeek int,
-- 		@IdContratto char(32),
-- 		@CodiceUnitaSDC  varchar(256),
-- 		@CategoriaUnitaSDC varchar(20),
-- 		@u_DataInizioValidita datetime ,
-- 		@u_DataFineValidita datetime ,
-- 		@u_TSModifica datetime,
-- 		@UnitaDelContrattoValidata bit ,
-- 		@UnitaAssegnataOpCedente bit ,
-- 		@UnitaAssegnataOpAcquirente bit ,
-- 		@PrioritaBilanciamentoForzato int ,
-- 		@CodiceContratto varchar(50) ,
-- 		@c_DataInizioValidita datetime,
-- 		@c_DataFineValidita datetime ,
-- 		@CRN varchar(30),
-- 		@StatoContratto varchar(32)  ,
-- 		@CodiceOperatoreSDC varchar(256) ,
-- 		@c_TSModifica datetime,
-- 		@CodiceOperatoreSDCAcquirente varchar(256) ,
-- 		@CodiceOperatoreSDCCedente varchar (256) ,
-- 		@ProgrammazionePrivilegiata bit ,
-- 		@CoefficientePerdita float 
-- 	
-- 	declare unita_cursor cursor for
-- 		select u.IdContratto,         
-- 			u.CodiceUnitaSDC,
-- 			u.CategoriaUnitaSDC,
-- 			u.DataInizioValidita u_DataInizioValidita,                                     
-- 			u.DataFineValidita u_DataFineValidita,                                   
-- 			u.TSModifica u_TSModifica,                                     
-- 			u.UnitaDelContrattoValidata,
-- 			u.UnitaAssegnataOpCedente,
-- 			u.UnitaAssegnataOpAcquirente,
-- 			u.PrioritaBilanciamentoForzato,
-- 			c.CodiceContratto,
-- 			c.DataInizioValidita c_DataInizioValidita,
-- 			c.DataFineValidita c_DataFineValidita,
-- 			c.CRN,
-- 			c.StatoContratto,
-- 			c.CodiceOperatoreSDC,
-- 			c.TSModifica c_TSModifica,
-- 			c.CodiceOperatoreSDCAcquirente,
-- 			c.CodiceOperatoreSDCCedente,
-- 			c.ProgrammazionePrivilegiata,
-- 			s.CoefficientePerdita
-- 		from Contratto c, 
-- 			UnitaContratto u,
-- 			SDC_Unita s,
-- 			unita a
-- 		where c.DataInizioValidita <= @DATE and @DATE <= c.DataFineValidita
-- 			and c.StatoContratto = 'Abilitato'
-- 			and u.UnitaDelContrattoValidata = 1
-- 			and u.IdContratto = c.IdContratto
-- 			and u.CodiceUnitaSDC = s.CodiceUnitaSDC
-- 			and u.CodiceUnitaSDC = a.CodiceUnitaSDC
-- 			and s.Abilitata = 1
-- 			and a.StatoBilateraliUnita = 1
-- 		order by c.IdContratto, u.CodiceUnitaSDC
-- 	
-- 	set @LastDayOfWeek= 8-@@datefirst
-- 	
-- 	set @Month= DATEPART(month,@DATE)
-- 	set @WeekDay= DATEPART(weekday,@DATE)
-- 	set @NextDate= @DATE + 7
-- 	set @NextDateMonth= DATEPART(month,@NextDate)
-- 	set @RowCount = 24
-- 	-- se e` Marzo, e` Domenica e Domenica prossima e` gia` Aprile
-- 	if (@Month = 3  and @WeekDay = @LastDayOfWeek and @NextDateMonth = 4)
-- 	begin
-- 		set @RowCount = 23
-- 	end
-- 	
-- 	-- se e` Ottobre, e` Domenica e Domenica prossima e` gia` Novembre
-- 	if (@Month=10 and @WeekDay = @LastDayOfWeek and @NextDateMonth = 11)
-- 	begin
-- 		set @RowCount = 25
-- 	end
-- 	-- Table variable to hold accumulated results
-- 	declare @hourcount table (rowid int primary key)
-- 	set @RowsAdded = @RowCount
-- 	
-- 	-- While new employees were added in the previous iteration
-- 	while @RowsAdded > 0
-- 	begin
-- 		insert @hourcount  values(@RowsAdded)
-- 		
-- 		set @RowsAdded = @RowsAdded - 1
-- 	end
-- 	
-- 	open unita_cursor
-- 	-- Perform the first fetch.
-- 	fetch next from unita_cursor into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@u_DataInizioValidita ,
-- 		@u_DataFineValidita ,
-- 		@u_TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@CodiceContratto,
-- 		@c_DataInizioValidita,
-- 		@c_DataFineValidita,
-- 		@CRN,
-- 		@StatoContratto,
-- 		@CodiceOperatoreSDC,
-- 		@c_TSModifica,
-- 		@CodiceOperatoreSDCAcquirente,
-- 		@CodiceOperatoreSDCCedente,
-- 		@ProgrammazionePrivilegiata,
-- 		@CoefficientePerdita
-- 	-- Copy to the result of the function the required columns.
-- 	insert @retUnitaContrattiOra
-- 	select rowid, 
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@u_DataInizioValidita ,
-- 		@u_DataFineValidita ,
-- 		@u_TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@CodiceContratto,
-- 		@c_DataInizioValidita,
-- 		@c_DataFineValidita,
-- 		@CRN,
-- 		@StatoContratto,
-- 		@CodiceOperatoreSDC,
-- 		@c_TSModifica,
-- 		@CodiceOperatoreSDCAcquirente,
-- 		@CodiceOperatoreSDCCedente,
-- 		@ProgrammazionePrivilegiata,
-- 		@CoefficientePerdita
-- 	from @hourcount
-- 	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
-- 	while @@FETCH_STATUS = 0
-- 	begin
-- 	   -- This is executed as long as the previous fetch succeeds.
-- 	   fetch next from unita_cursor  into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@u_DataInizioValidita ,
-- 		@u_DataFineValidita ,
-- 		@u_TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@CodiceContratto,
-- 		@c_DataInizioValidita,
-- 		@c_DataFineValidita,
-- 		@CRN,
-- 		@StatoContratto,
-- 		@CodiceOperatoreSDC,
-- 		@c_TSModifica,
-- 		@CodiceOperatoreSDCAcquirente,
-- 		@CodiceOperatoreSDCCedente,
-- 		@ProgrammazionePrivilegiata,
-- 		@CoefficientePerdita
-- 		insert @retUnitaContrattiOra
-- 		select rowid, 
-- 			@IdContratto,
-- 			@CodiceUnitaSDC,
-- 			@CategoriaUnitaSDC,
-- 			@u_DataInizioValidita ,
-- 			@u_DataFineValidita ,
-- 			@u_TSModifica,
-- 			@UnitaDelContrattoValidata ,
-- 			@UnitaAssegnataOpCedente ,
-- 			@UnitaAssegnataOpAcquirente ,
-- 			@PrioritaBilanciamentoForzato ,
-- 			@CodiceContratto,
-- 			@c_DataInizioValidita,
-- 			@c_DataFineValidita,
-- 			@CRN,
-- 			@StatoContratto,
-- 			@CodiceOperatoreSDC,
-- 			@c_TSModifica,
-- 			@CodiceOperatoreSDCAcquirente,
-- 			@CodiceOperatoreSDCCedente,
-- 			@ProgrammazionePrivilegiata,
-- 			@CoefficientePerdita
-- 		from @hourcount
-- 	end
-- 	close unita_cursor
-- 	deallocate unita_cursor
-- 	return
-- end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[UnitaContrattiOra]  TO [public]
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[UnitaContrattiOra]  TO [bil_user]
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[UnitaContrattiOra]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- CREATE   function tab_ReportIndicatori()
-- returns @retIndicatori table (	
-- 	DataProgramma smalldatetime NOT NULL ,
-- 	QtyMWhP float NOT NULL ,
-- 	QtyMwhBilP float NOT NULL,
-- 	QtyMWhC float  NOT NULL,
-- 	QtyMwhBilC float  NOT NULL,
-- 	QtyMwhSell float NOT NULL,
-- 	QtyMwhBuy float  NOT NULL,
-- 	CoCut int NOT NULL,
-- 	CoPgm int NOT NULL,
-- 	CoEnabled int NOT NULL)
-- as
-- begin
-- 	declare @DataProgramma smalldatetime,
-- 		@QtyMWhP float,
-- 		@QtyMwhBilP float,
-- 		@QtyMWhC float,
-- 		@QtyMwhBilC float,
-- 		@QtyMwhSell float,
-- 		@QtyMwhBuy float,
-- 		@nCoCut int,
-- 		@nCoPgm int,
-- 		@nCoEnabled int
-- 		
-- 
-- 	declare ind_cursor cursor  for
-- 		select nrg.DataProgramma, 
-- 		nrg.QtyMWhP, 
-- 		nrg.QtyMwhBilP,
-- 		nrg.QtyMWhC,
-- 		nrg.QtyMwhBilC,
-- 		nrg.QtyMwhSell,
-- 		nrg.QtyMwhBuy,
-- 		cnt.nContrattiTagliati,
-- 		cnt.nContrattiProgrammati,
-- 		cnt.nContrattiAbilitati
-- 		from 
-- 		(
-- 		select Sessioni.DataProgramma, 
-- 				Quantita.QtyMWhP, Quantita.QtyMwhBilP,
-- 				Quantita.QtyMWhC, Quantita.QtyMwhBilC,
-- 				Quantita.QtyMwhSell, Quantita.QtyMwhBuy
-- 				from SessioneBilaterali Sessioni
-- 				left outer join
-- 				(
-- 				select DataProgramma, 
-- 					sum(QtyMWhP) QtyMWhP, sum(QtyMwhBilP) QtyMwhBilP,
-- 					sum(QtyMWhC) QtyMWhC, sum(QtyMwhBilC) QtyMwhBilC,
-- 					sum(QtyMwhSell) QtyMwhSell, sum(QtyMwhBuy) QtyMwhBuy
-- 				from (
-- 					select po.DataProgramma, po.PeriodoRilevante, po.IdContratto, po.TSCalcoloBilanciamento,
-- 						po.Bilanciato, po.SbilanciamentoMWh,
-- 						pou.QtyMWhP, pou.QtyMwhBilP,
-- 						pou.QtyMWhC, pou.QtyMwhBilC,
-- 						case pou.QtyMwhBilP when null then pou.QtyMWhP else pou.QtyMwhBilP end QtyMwhSell,
-- 						case pou.QtyMwhBilC when null then pou.QtyMWhC else pou.QtyMwhBilC end QtyMwhBuy
-- 					 from 
-- 					(
-- 					select DataProgramma, PeriodoRilevante, IdContratto,
-- 						sum(QtyMWhP) QtyMWhP, sum(QtyMwhBilanciamentoP) QtyMwhBilP, 
-- 						sum(QtyMWhC) QtyMWhC, sum(QtyMwhBilanciamentoC) QtyMwhBilC
-- 					from
-- 					(
-- 						select DataProgramma, PeriodoRilevante, IdContratto, 
-- 							case ProgrammatoDalCedente when 1 then QtyMWh else 0 end QtyMWhP,
-- 							case ProgrammatoDalCedente when 1 then isnull(QtyMwhBilanciamento,0) else 0 end  QtyMwhBilanciamentoP,
-- 							case ProgrammatoDalCedente when 0 then QtyMWh else 0 end QtyMWhC,
-- 							case ProgrammatoDalCedente when 0 then isnull(QtyMwhBilanciamento,0) else 0 end  QtyMwhBilanciamentoC
-- 						from programmaorarioperunita 
-- 						) x
-- 					group by DataProgramma, PeriodoRilevante, IdContratto
-- 					) pou, programmaorario po
-- 					where po.DataProgramma = pou.DataProgramma
-- 					and po.PeriodoRilevante = pou.PeriodoRilevante
-- 					and po.IdContratto = pou.IdContratto
-- 				) m
-- 				group by DataProgramma
-- 			) Quantita
-- 			on Sessioni.DataProgramma = Quantita.DataProgramma
-- 		) nrg
-- 		inner join 
-- 		(
-- 		select cp.DataProgramma, isnull(ct.nContrattiTagliati, 0) nContrattiTagliati, cp.nContrattiProgrammati, ca.nContrattiAbilitati
-- 		from
-- 		(
-- 		select s.DataProgramma, count(*) nContrattiProgrammati
-- 		from 
-- 		(
-- 		select  po.DataProgramma, po.IdContratto,  count(*) nOre
-- 					from ProgrammaOrario po
-- 					group by po.DataProgramma, po.IdContratto
-- 		) w
-- 		inner join SessioneBilaterali s 
-- 		on s.DataProgramma = w.DataProgramma
-- 		group by s.DataProgramma
-- 		) cp
-- 		inner join
-- 		(
-- 		select s.DataProgramma DataProgramma, count(*) nContrattiAbilitati
-- 			from SessioneBilaterali s, Contratto ct
-- 			where DataInizioValidita <= s.DataProgramma
-- 				and ct.DataFineValidita >= s.DataProgramma
-- 				and ct.StatoContratto = 'Abilitato'
-- 				and ct.TrCn = 1
-- 		group by s.DataProgramma
-- 		) ca
-- 		on cp.DataProgramma = ca.DataProgramma
-- 		left outer join
-- 		(
-- 		select s.DataProgramma, count(*) nContrattiTagliati
-- 		from 
-- 		SessioneBilaterali s 
-- 		inner join 
-- 		(
-- 		select  po.DataProgramma, po.IdContratto,  count(*) nOre
-- 					from ProgrammaOrario po
-- 					where po.Bilanciato = 1 and po.SbilanciamentoMWh <> 0 -- identifica i contratto sbilanciati e successivamente tagliati
-- 					group by po.DataProgramma, po.IdContratto
-- 		) x
-- 		on s.DataProgramma = x.DataProgramma
-- 		group by s.DataProgramma
-- 		) ct
-- 		on ca.DataProgramma = ct.DataProgramma
-- 		) cnt
-- 		on nrg.DataProgramma = cnt.DataProgramma
-- 		order by nrg.DataProgramma
-- 
-- 	open ind_cursor
-- 	-- Perform the first fetch.
-- 	fetch next from ind_cursor into
-- 		@DataProgramma,
-- 		@QtyMWhP,
-- 		@QtyMwhBilP,
-- 		@QtyMWhC,
-- 		@QtyMwhBilC,
-- 		@QtyMwhSell,
-- 		@QtyMwhBuy,
-- 		@nCoCut,
-- 		@nCoPgm,
-- 		@nCoEnabled
-- 
-- 	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
-- 	while @@FETCH_STATUS = 0
-- 	begin
-- 	-- Copy to the result of the function the required columns.
-- 	insert @retIndicatori values(
-- 		@DataProgramma,
-- 		@QtyMWhP,
-- 		@QtyMwhBilP,
-- 		@QtyMWhC,
-- 		@QtyMwhBilC,
-- 		@QtyMwhSell,
-- 		@QtyMwhBuy,
-- 		@nCoCut,
-- 		@nCoPgm,
-- 		@nCoEnabled)
-- 	   -- This is executed as long as the previous fetch succeeds.
-- 	  fetch next from ind_cursor into
-- 		@DataProgramma,
-- 		@QtyMWhP,
-- 		@QtyMwhBilP,
-- 		@QtyMWhC,
-- 		@QtyMwhBilC,
-- 		@QtyMwhSell,
-- 		@QtyMwhBuy,
-- 		@nCoCut,
-- 		@nCoPgm,
-- 		@nCoEnabled
-- 	end
-- 	close ind_cursor
-- 	deallocate ind_cursor
-- 	return
-- end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_ReportIndicatori]  TO [public]
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_ReportIndicatori]  TO [bil_user]
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_ReportIndicatori]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE  function tab_ReportSbilanciamentoOrario(@DataFlusso datetime )
-- returns @retSbilanciamentoOrario table (	
-- 	DataProgramma smalldatetime,
-- 	Ora int,
-- 	Cedente  varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	Acuirente  varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CRN  varchar(30) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CodiceContratto  varchar(50) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	SbilanciamentoMWh float)
-- as
-- begin
-- 	declare 
-- 		@DataProgramma smalldatetime,
-- 		@Ora int,
-- 		@Cedente varchar(16),
-- 		@Acquirente varchar(16),
-- 		@CRN  varchar(30),
-- 		@CodiceContrattol  varchar(50),
-- 		@SbilanciamentoMWh float
-- 		
-- 
-- 	declare sbil_cursor cursor  for
-- 		select 	po.DataProgramma,
-- 			'''' + c.CRN + '''' as CRN, 
-- 			c.CodiceContratto as 'CodiceContratto', 
-- 			c.CodiceOperatoreSDCCedente as 'Cedente', 
-- 			c.CodiceOperatoreSDCAcquirente as 'Acquirente', 
-- 			po.PeriodoRilevante as Ora, 
-- 			cast(po.SbilanciamentoMWh as decimal(10,3)) as SbilanciamentoMWh
-- 		from programmaorario po, contratto c
-- 		where c.IdContratto = po.IdContratto
-- 		and po.DataProgramma = @DataFlusso
-- 		order by CRN, CodiceContratto, PeriodoRilevante
-- 
-- 	open sbil_cursor
-- 	-- Perform the first fetch.
-- 	fetch next from sbil_cursor into
-- 		@DataProgramma,
-- 		@Ora,
-- 		@Cedente,
-- 		@Acquirente,
-- 		@CRN,
-- 		@CodiceContrattol,
-- 		@SbilanciamentoMWh
-- 
-- 	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
-- 	while @@FETCH_STATUS = 0
-- 	begin
-- 		-- Copy to the result of the function the required columns.
-- 		insert @retSbilanciamentoOrario values(
-- 			@DataProgramma,
-- 			@Ora,
-- 			@Cedente,
-- 			@Acquirente,
-- 			@CRN,
-- 			@CodiceContrattol,
-- 			@SbilanciamentoMWh)
-- 		
-- 		-- This is executed as long as the previous fetch succeeds.
-- 		 fetch next from sbil_cursor into
-- 			@DataProgramma,
-- 			@Ora,
-- 			@Cedente,
-- 			@Acquirente,
-- 			@CRN,
-- 			@CodiceContrattol,
-- 			@SbilanciamentoMWh
-- 	end
-- 	close sbil_cursor
-- 	deallocate sbil_cursor
-- 	return
-- end
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_ReportSbilanciamentoOrario]  TO [public]
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_ReportSbilanciamentoOrario]  TO [bil_user]
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_ReportSbilanciamentoOrario]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE  function tab_SbilanciamentoProgramma(@DataProgramma datetime, @SogliaSbilMWh as float, @CRN as varchar(30))
-- returns @retSbilanciamentoProgramma table (	
-- 	Operatore  varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CRN varchar(30) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CodiceContratto varchar(50) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	Cedente varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	Acquirente varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	GestioneTaglio varchar(100) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	SbilMWhOra01 float,
-- 	SbilMWhOra02 float,
-- 	SbilMWhOra03 float,
-- 	SbilMWhOra04 float,
-- 	SbilMWhOra05 float,
-- 	SbilMWhOra06 float,
-- 	SbilMWhOra07 float,
-- 	SbilMWhOra08 float,
-- 	SbilMWhOra09 float,
-- 	SbilMWhOra10 float,
-- 	SbilMWhOra11 float,
-- 	SbilMWhOra12 float,
-- 	SbilMWhOra13 float,
-- 	SbilMWhOra14 float,
-- 	SbilMWhOra15 float,
-- 	SbilMWhOra16 float,
-- 	SbilMWhOra17 float,
-- 	SbilMWhOra18 float,
-- 	SbilMWhOra19 float,
-- 	SbilMWhOra20 float,
-- 	SbilMWhOra21 float,
-- 	SbilMWhOra22 float,
-- 	SbilMWhOra23 float,
-- 	SbilMWhOra24 float,
-- 	SbilMWhOra25 float)
-- as
-- 
-- begin
-- declare	
-- 	@Operatore  varchar(16) ,
-- 	@CodiceContratto varchar(50),
-- 	@Cedente varchar(16) ,
-- 	@Acquirente varchar(16),
-- 	@GestioneTaglio varchar(50),
-- 	@SbilMWhOra01 float,
-- 	@SbilMWhOra02 float,
-- 	@SbilMWhOra03 float,
-- 	@SbilMWhOra04 float,
-- 	@SbilMWhOra05 float,
-- 	@SbilMWhOra06 float,
-- 	@SbilMWhOra07 float,
-- 	@SbilMWhOra08 float,
-- 	@SbilMWhOra09 float,
-- 	@SbilMWhOra10 float,
-- 	@SbilMWhOra11 float,
-- 	@SbilMWhOra12 float,
-- 	@SbilMWhOra13 float,
-- 	@SbilMWhOra14 float,
-- 	@SbilMWhOra15 float,
-- 	@SbilMWhOra16 float,
-- 	@SbilMWhOra17 float,
-- 	@SbilMWhOra18 float,
-- 	@SbilMWhOra19 float,
-- 	@SbilMWhOra20 float,
-- 	@SbilMWhOra21 float,
-- 	@SbilMWhOra22 float,
-- 	@SbilMWhOra23 float,
-- 	@SbilMWhOra24 float,
-- 	@SbilMWhOra25 float
-- 
-- 
-- declare	@numore as integer
-- exec @numore = GetHourNum @DataProgramma
-- 
-- declare
--  	@SbilMWhTotOra01 float,
-- 	@SbilMWhTotOra02 float,
-- 	@SbilMWhTotOra03 float,
-- 	@SbilMWhTotOra04 float,
-- 	@SbilMWhTotOra05 float,
-- 	@SbilMWhTotOra06 float,
-- 	@SbilMWhTotOra07 float,
-- 	@SbilMWhTotOra08 float,
-- 	@SbilMWhTotOra09 float,
-- 	@SbilMWhTotOra10 float,
-- 	@SbilMWhTotOra11 float,
-- 	@SbilMWhTotOra12 float,
-- 	@SbilMWhTotOra13 float,
-- 	@SbilMWhTotOra14 float,
-- 	@SbilMWhTotOra15 float,
-- 	@SbilMWhTotOra16 float,
-- 	@SbilMWhTotOra17 float,
-- 	@SbilMWhTotOra18 float,
-- 	@SbilMWhTotOra19 float,
-- 	@SbilMWhTotOra20 float,
-- 	@SbilMWhTotOra21 float,
-- 	@SbilMWhTotOra22 float,
-- 	@SbilMWhTotOra23 float,
-- 	@SbilMWhTotOra24 float,
-- 	@SbilMWhTotOra25 float
-- 
--  	set @SbilMWhTotOra01 = 0.0
-- 	set @SbilMWhTotOra02 = 0.0
-- 	set @SbilMWhTotOra03 = 0.0
-- 	set @SbilMWhTotOra04 = 0.0
-- 	set @SbilMWhTotOra05 = 0.0
-- 	set @SbilMWhTotOra06 = 0.0
-- 	set @SbilMWhTotOra07 = 0.0
-- 	set @SbilMWhTotOra08 = 0.0
-- 	set @SbilMWhTotOra09 = 0.0
-- 	set @SbilMWhTotOra10 = 0.0
-- 	set @SbilMWhTotOra11 = 0.0
-- 	set @SbilMWhTotOra12 = 0.0
-- 	set @SbilMWhTotOra13 = 0.0
-- 	set @SbilMWhTotOra14 = 0.0
-- 	set @SbilMWhTotOra15 = 0.0
-- 	set @SbilMWhTotOra16 = 0.0
-- 	set @SbilMWhTotOra17 = 0.0
-- 	set @SbilMWhTotOra18 = 0.0
-- 	set @SbilMWhTotOra19 = 0.0
-- 	set @SbilMWhTotOra20 = 0.0
-- 	set @SbilMWhTotOra21 = 0.0
-- 	set @SbilMWhTotOra22 = 0.0
-- 	set @SbilMWhTotOra23 = 0.0
-- 	set @SbilMWhTotOra24 = 0.0
-- 	set @SbilMWhTotOra25 = 0.0
-- 
-- declare p_cursor cursor for
-- 
-- select --@DataProgramma DataProgramma,
-- C.CodiceOperatoreSDC Operatore, 
-- C.CodiceContratto,
-- C.CodiceOperatoreSDCCedente Cedente,
-- C.CodiceOperatoreSDCAcquirente Acquirente,
-- case (C.GestioneTaglio) 
-- 	when 'T' then 'Sempre'
-- 	when 'C' then 'se cons. supera prod.'
-- 	when 'P' then 'se prod. supera cons.'
-- 	when 'M' then 'mai'
-- end 
-- GestioneTaglio,
-- case Q.PeriodoRilevante when  1 then Q.BilMWh else 0 end SbilMWhOra01,
-- case Q.PeriodoRilevante when  2 then Q.BilMWh else 0 end SbilMWhOra02,
-- case Q.PeriodoRilevante when  3 then Q.BilMWh else 0 end SbilMWhOra03,
-- case Q.PeriodoRilevante when  4 then Q.BilMWh else 0 end SbilMWhOra04,
-- case Q.PeriodoRilevante when  5 then Q.BilMWh else 0 end SbilMWhOra05,
-- case Q.PeriodoRilevante when  6 then Q.BilMWh else 0 end SbilMWhOra06,
-- case Q.PeriodoRilevante when  7 then Q.BilMWh else 0 end SbilMWhOra07,
-- case Q.PeriodoRilevante when  8 then Q.BilMWh else 0 end SbilMWhOra08,
-- case Q.PeriodoRilevante when  9 then Q.BilMWh else 0 end SbilMWhOra09,
-- case Q.PeriodoRilevante when 10 then Q.BilMWh else 0 end SbilMWhOra10,
-- case Q.PeriodoRilevante when 11 then Q.BilMWh else 0 end SbilMWhOra11,
-- case Q.PeriodoRilevante when 12 then Q.BilMWh else 0 end SbilMWhOra12,
-- case Q.PeriodoRilevante when 13 then Q.BilMWh else 0 end SbilMWhOra13,
-- case Q.PeriodoRilevante when 14 then Q.BilMWh else 0 end SbilMWhOra14,
-- case Q.PeriodoRilevante when 15 then Q.BilMWh else 0 end SbilMWhOra15,
-- case Q.PeriodoRilevante when 16 then Q.BilMWh else 0 end SbilMWhOra16,
-- case Q.PeriodoRilevante when 17 then Q.BilMWh else 0 end SbilMWhOra17,
-- case Q.PeriodoRilevante when 18 then Q.BilMWh else 0 end SbilMWhOra18,
-- case Q.PeriodoRilevante when 19 then Q.BilMWh else 0 end SbilMWhOra19,
-- case Q.PeriodoRilevante when 20 then Q.BilMWh else 0 end SbilMWhOra20,
-- case Q.PeriodoRilevante when 21 then Q.BilMWh else 0 end SbilMWhOra21,
-- case Q.PeriodoRilevante when 22 then Q.BilMWh else 0 end SbilMWhOra22,
-- case Q.PeriodoRilevante when 23 then Q.BilMWh else 0 end SbilMWhOra23,
-- case Q.PeriodoRilevante when 24 then Q.BilMWh else 0 end SbilMWhOra24,
-- case Q.PeriodoRilevante when 25 then Q.BilMWh else 0 end SbilMWhOra25
-- from ProgrammaOrario PO 
-- inner join Contratto C
-- on PO.IdContratto = C.IdContratto
-- inner join
-- (
-- 	select 
-- 	POU.IdContratto, 
-- 	@DataProgramma DataProgramma, 
-- 	POU.PeriodoRilevante,
-- 	case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then 0                                        else 1 end Bilanciato,
-- 	case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then round(Sum(round(POU.QtyMWh * UC.KP / UC.KU,3)), 3) else 0 end BilMWh
-- 	from 
-- 	(
-- 		-- trovo tutte le unita per contratto valide 
-- 		-- (TrCC e TrUC garantiscono che il contratto sia valido, le unita valide, gli operatori validi)
-- 		select 
-- 		UnitaContratto.IdContratto, 
-- 		UnitaContratto.CodiceUnitaSDC, 
-- 		UnitaContratto.CategoriaUnitaSDC,
-- 		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
-- 		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
-- 		from 
-- 		tab_UnitaContratto(@DataProgramma) UnitaContratto, 
-- 		SDC_Unita, SDC_PuntiDiScambioRilevanti,
-- 		Contratto
-- 		where 
-- 		Contratto.IdContratto = UnitaContratto.IdContratto
-- 		and Contratto.DataInizioValidita <= @DataProgramma
-- 		and Contratto.DataFineValidita >= @DataProgramma
-- 		and UnitaContratto.TrCC=1 
-- 		and UnitaContratto.TrUC=1
-- 		and UnitaContratto.UnitaDelContrattoValidata=1
-- 		and UnitaContratto.DataInizioValidita <= @DataProgramma
-- 		and UnitaContratto.DataFineValidita >= @DataProgramma
-- 		and UnitaContratto.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
-- 		and UnitaContratto.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
-- 		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- 		and CRN = @CRN
-- 	) UC
-- 	inner join
-- 	(
-- 		-- considero i POU validi del giorno
-- 		SELECT 
-- 		ProgrammaOrarioPerUnita.IdContratto, 
-- 		ProgrammaOrarioPerUnita.DataProgramma, 
-- 		ProgrammaOrarioPerUnita.PeriodoRilevante, 
-- 		ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
-- 		ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
-- 		ProgrammaOrarioPerUnita.QtyMWh
-- 		FROM 
-- 		ProgrammaOrarioPerUnita, 
-- 		ProgrammaOrario
-- 		where 
-- 		ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
-- 		and ProgrammaOrario.DataProgramma=@DataProgramma
-- 		and ProgrammaOrario.ProgrammaOrarioValidato=1
-- 		and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
-- 		and ProgrammaOrarioPerUnita.IdContratto=ProgrammaOrario.IdContratto
-- 		and ProgrammaOrarioPerUnita.DataProgramma=ProgrammaOrario.DataProgramma
-- 		and ProgrammaOrarioPerUnita.PeriodoRilevante=ProgrammaOrario.PeriodoRilevante
-- 	) POU
-- 	ON  POU.IdContratto = UC.IdContratto
-- 	AND POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
-- 	AND POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
-- 	GROUP BY POU.IdContratto, POU.DataProgramma, POU.PeriodoRilevante
-- ) Q
-- on 
-- PO.IdContratto = Q.IdContratto
-- and PO.DataProgramma = Q.DataProgramma
-- and PO.PeriodoRilevante = Q.PeriodoRilevante
-- --order by C.CRN
-- 
-- 
-- open p_cursor
-- 		-- Perform the first fetch.
-- fetch next from p_cursor into
-- 		@Operatore,
-- 		@CodiceContratto,
-- 		@Cedente,
-- 		@Acquirente ,
-- 		@GestioneTaglio ,
-- 		@SbilMWhOra01,
-- 		@SbilMWhOra02,
-- 		@SbilMWhOra03,
-- 		@SbilMWhOra04,
-- 		@SbilMWhOra05,
-- 		@SbilMWhOra06,
-- 		@SbilMWhOra07,
-- 		@SbilMWhOra08,
-- 		@SbilMWhOra09,
-- 		@SbilMWhOra10,
-- 		@SbilMWhOra11,
-- 		@SbilMWhOra12,
-- 		@SbilMWhOra13,
-- 		@SbilMWhOra14,
-- 		@SbilMWhOra15,
-- 		@SbilMWhOra16,
-- 		@SbilMWhOra17,
-- 		@SbilMWhOra18,
-- 		@SbilMWhOra19,
-- 		@SbilMWhOra20,
-- 		@SbilMWhOra21,
-- 		@SbilMWhOra22,
-- 		@SbilMWhOra23,
-- 		@SbilMWhOra24,
-- 		@SbilMWhOra25
-- 
-- 	
-- 
-- 	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
-- 	while @@FETCH_STATUS = 0
-- 	begin
-- 		set @SbilMWhTotOra01 = @SbilMWhTotOra01 + @SbilMWhOra01
-- 		set @SbilMWhTotOra02 = @SbilMWhTotOra02 + @SbilMWhOra02
-- 		set @SbilMWhTotOra03 = @SbilMWhTotOra03 + @SbilMWhOra03
-- 		set @SbilMWhTotOra04 = @SbilMWhTotOra04 + @SbilMWhOra04
-- 		set @SbilMWhTotOra05 = @SbilMWhTotOra05 + @SbilMWhOra05
-- 		set @SbilMWhTotOra06 = @SbilMWhTotOra06 + @SbilMWhOra06
-- 		set @SbilMWhTotOra07 = @SbilMWhTotOra07 + @SbilMWhOra07
-- 		set @SbilMWhTotOra08 = @SbilMWhTotOra08 + @SbilMWhOra08
-- 		set @SbilMWhTotOra09 = @SbilMWhTotOra09 + @SbilMWhOra09
-- 		set @SbilMWhTotOra10 = @SbilMWhTotOra10 + @SbilMWhOra10
-- 		set @SbilMWhTotOra11 = @SbilMWhTotOra11 + @SbilMWhOra11
-- 		set @SbilMWhTotOra12 = @SbilMWhTotOra12 + @SbilMWhOra12
-- 		set @SbilMWhTotOra13 = @SbilMWhTotOra13 + @SbilMWhOra13
-- 		set @SbilMWhTotOra14 = @SbilMWhTotOra14 + @SbilMWhOra14
-- 		set @SbilMWhTotOra15 = @SbilMWhTotOra15 + @SbilMWhOra15
-- 		set @SbilMWhTotOra16 = @SbilMWhTotOra16 + @SbilMWhOra16
-- 		set @SbilMWhTotOra17 = @SbilMWhTotOra17 + @SbilMWhOra17
-- 		set @SbilMWhTotOra18 = @SbilMWhTotOra18 + @SbilMWhOra18
-- 		set @SbilMWhTotOra19 = @SbilMWhTotOra19 + @SbilMWhOra19
-- 		set @SbilMWhTotOra20 = @SbilMWhTotOra20 + @SbilMWhOra20
-- 		set @SbilMWhTotOra21 = @SbilMWhTotOra21 + @SbilMWhOra21
-- 		set @SbilMWhTotOra22 = @SbilMWhTotOra22 + @SbilMWhOra22
-- 		set @SbilMWhTotOra23 = @SbilMWhTotOra23 + @SbilMWhOra23
-- 		set @SbilMWhTotOra24 = @SbilMWhTotOra24 + @SbilMWhOra24
-- 		set @SbilMWhTotOra25 = @SbilMWhTotOra25 + @SbilMWhOra25
-- 		
-- 	-- Copy to the result of the function the required columns.
-- 	insert @retSbilanciamentoProgramma values(
-- 		@Operatore,
-- 		@CRN,
-- 		@CodiceContratto,
-- 		@Cedente,
-- 		@Acquirente ,
-- 		@GestioneTaglio ,
-- 		@SbilMWhOra01,
-- 		@SbilMWhOra02,
-- 		@SbilMWhOra03,
-- 		@SbilMWhOra04,
-- 		@SbilMWhOra05,
-- 		@SbilMWhOra06,
-- 		@SbilMWhOra07,
-- 		@SbilMWhOra08,
-- 		@SbilMWhOra09,
-- 		@SbilMWhOra10,
-- 		@SbilMWhOra11,
-- 		@SbilMWhOra12,
-- 		@SbilMWhOra13,
-- 		@SbilMWhOra14,
-- 		@SbilMWhOra15,
-- 		@SbilMWhOra16,
-- 		@SbilMWhOra17,
-- 		@SbilMWhOra18,
-- 		@SbilMWhOra19,
-- 		@SbilMWhOra20,
-- 		@SbilMWhOra21,
-- 		@SbilMWhOra22,
-- 		@SbilMWhOra23,
-- 		@SbilMWhOra24,
-- 		@SbilMWhOra25)
-- 	   -- This is executed as long as the previous fetch succeeds.
-- 	  fetch next from p_cursor into
-- 		@Operatore,
-- 		@CodiceContratto,
-- 		@Cedente,
-- 		@Acquirente ,
-- 		@GestioneTaglio ,
-- 		@SbilMWhOra01,
-- 		@SbilMWhOra02,
-- 		@SbilMWhOra03,
-- 		@SbilMWhOra04,
-- 		@SbilMWhOra05,
-- 		@SbilMWhOra06,
-- 		@SbilMWhOra07,
-- 		@SbilMWhOra08,
-- 		@SbilMWhOra09,
-- 		@SbilMWhOra10,
-- 		@SbilMWhOra11,
-- 		@SbilMWhOra12,
-- 		@SbilMWhOra13,
-- 		@SbilMWhOra14,
-- 		@SbilMWhOra15,
-- 		@SbilMWhOra16,
-- 		@SbilMWhOra17,
-- 		@SbilMWhOra18,
-- 		@SbilMWhOra19,
-- 		@SbilMWhOra20,
-- 		@SbilMWhOra21,
-- 		@SbilMWhOra22,
-- 		@SbilMWhOra23,
-- 		@SbilMWhOra24,
-- 		@SbilMWhOra25
-- 
-- 	end
-- 	close p_cursor
-- 	deallocate p_cursor
-- 
-- 
-- 
-- 	-- Copy to the result of the function the required columns.
-- 	insert @retSbilanciamentoProgramma values(
-- 		'Data ',
-- 		'',
-- 		convert(varchar, @DataProgramma, 105),
-- 		'',
-- 		'',
-- 		'Totale Orario' ,
-- 		@SbilMWhTotOra01,
-- 		@SbilMWhTotOra02,
-- 		@SbilMWhTotOra03,
-- 		@SbilMWhTotOra04,
-- 		@SbilMWhTotOra05,
-- 		@SbilMWhTotOra06,
-- 		@SbilMWhTotOra07,
-- 		@SbilMWhTotOra08,
-- 		@SbilMWhTotOra09,
-- 		@SbilMWhTotOra10,
-- 		@SbilMWhTotOra11,
-- 		@SbilMWhTotOra12,
-- 		@SbilMWhTotOra13,
-- 		@SbilMWhTotOra14,
-- 		@SbilMWhTotOra15,
-- 		@SbilMWhTotOra16,
-- 		@SbilMWhTotOra17,
-- 		@SbilMWhTotOra18,
-- 		@SbilMWhTotOra19,
-- 		@SbilMWhTotOra20,
-- 		@SbilMWhTotOra21,
-- 		@SbilMWhTotOra22,
-- 		@SbilMWhTotOra23,
-- 		@SbilMWhTotOra24,
-- 		@SbilMWhTotOra25)
-- return
-- 	
-- end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_SbilanciamentoProgramma]  TO [public]
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_SbilanciamentoProgramma]  TO [bil_user]
-- GO
-- 
-- GRANT  SELECT  ON [dbo].[tab_SbilanciamentoProgramma]  TO [bil_dbo]
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- 
-- 
-- 
-- CREATE  function tab_UnitaContratto(@DataFlusso datetime )
-- returns @retUnitaContratto table (	
-- 	IdContratto int NOT NULL ,
-- 	CodiceUnitaSDC varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CategoriaUnitaSDC varchar(1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	DataInizioValidita smalldatetime ,
-- 	DataFineValidita smalldatetime ,
-- 	TSModifica datetime,
-- 	UnitaDelContrattoValidata bit ,
-- 	UnitaAssegnataOpCedente bit ,
-- 	UnitaAssegnataOpAcquirente bit ,
-- 	PrioritaBilanciamentoForzato int ,
-- 	TrCC bit,
-- 	TrUC bit,
-- 	VUC  bit)
-- as
-- begin
-- 	declare	
-- 		@IdContratto int,
-- 		@CodiceUnitaSDC  varchar(16),
-- 		@CategoriaUnitaSDC varchar(1),
-- 		@DataInizioValidita smalldatetime,
-- 		@DataFineValidita smalldatetime,
-- 		@TSModifica datetime,
-- 		@UnitaDelContrattoValidata bit,
-- 		@UnitaAssegnataOpCedente bit,
-- 		@UnitaAssegnataOpAcquirente bit,
-- 		@PrioritaBilanciamentoForzato int,
-- 		@TrCC bit,
-- 		@TrUC bit,
-- 		@VUC bit
-- 	
-- 	declare unita_cursor cursor for
-- select  
-- 		IdContratto, 
-- 		CodiceUnitaSDC, 
-- 		CategoriaUnitaSDC, 
-- 		@DataFlusso DataInizioValidita,
-- 		@DataFlusso DataFineValidita,
-- 		@DataFlusso TSModifica,
-- 		1 UnitaDelContrattoValidata,
-- 		case when @DataFlusso between DataInizioValiditaCedente and DataFineValiditaCedente then 1
-- 		else 0 
-- 		end UnitaAssegnataOpCedente,
-- 		case when @DataFlusso between DataInizioValiditaAcquirente and DataFineValiditaAcquirente then 1
-- 		else 0 
-- 		end UnitaAssegnataOpAcquirente, 
-- 		0 PrioritaBilanciamentoForzato,
-- 		TrCC,
-- 		TrUC,
-- 		VUC
-- 	from (
-- 	select IdContratto, 
--  	CodiceUnitaSDC,
--    	CategoriaUnitaSDC,
-- 	case isnull(DataInizioValiditaCedente, '') when '' then null 
-- 	else
--  		case sign(datediff(day, DataInizioValidita, DataInizioValiditaCedente)) 
--  		when 1 then DataInizioValiditaCedente
--  		when 0 then DataInizioValiditaCedente
--  		else DataInizioValidita
--  		end 
-- 	end DataInizioValiditaCedente,
-- 	case isnull(DataFineValiditaCedente, '') when '' then null 
-- 	else
-- 		case sign(datediff(day, DataFineValidita, DataFineValiditaCedente)) 
-- 		when 1 then DataFineValidita
-- 		when 0 then DataFineValidita
-- 		else DataFineValiditaCedente
-- 		end 
-- 	end DataFineValiditaCedente,
-- 	case isnull(DataInizioValiditaAcquirente, '') when '' then null 
-- 	else
-- 		case sign(datediff(day, DataInizioValidita, DataInizioValiditaAcquirente)) 
-- 		when 1 then DataInizioValiditaAcquirente
-- 		when 0 then DataInizioValiditaAcquirente
-- 		else DataInizioValidita
-- 		end 
-- 	end DataInizioValiditaAcquirente,
-- 	case isnull(DataFineValiditaAcquirente, '') when '' then null 
-- 	else
-- 		case sign(datediff(day, DataFineValidita, DataFineValiditaAcquirente)) 
-- 		when 1 then DataFineValidita
-- 		when 0 then DataFineValidita
-- 		else DataFineValiditaAcquirente
-- 		end 
-- 	end DataFineValiditaAcquirente,
-- 	TrCC,
--    	TrUC,
--    	VUC
-- from
-- (
-- select _ur.IdContratto, 
--  	_ur.CodiceUnitaSDC,
--    	_ur.CategoriaUnitaSDC,
--   	_ur.DataInizioValidita,
--     	_ur.DataFineValidita,
--    	_ur.TrCC,
--    	_ur.TrUC,
--    	_ur.VUC,
--  max(DataInizioValiditaCedente) DataInizioValiditaCedente,
--  max(DataFineValiditaCedente) DataFineValiditaCedente,
--  max(DataInizioValiditaAcquirente) DataInizioValiditaAcquirente,
--  max(DataFineValiditaAcquirente) DataFineValiditaAcquirente
-- from (
-- select 	 c.IdContratto,
-- 	c.DataInizioValidita,
--    	c.DataFineValidita,
-- 	ur.CodiceUnitaSDC,
--   	ur.CategoriaUnitaSDC,
-- 	case ur.CodiceOperatoreSDC when c.CodiceOperatoreSDCCedente then
-- 		ur.DataInizioValidita
-- 	else	null
-- 	end DataInizioValiditaCedente,
-- 	case ur.CodiceOperatoreSDC when c.CodiceOperatoreSDCCedente then
-- 		ur.DataFineValidita
-- 	else NULL
-- 	end DataFineValiditaCedente,
-- 	case ur.CodiceOperatoreSDC when c.CodiceOperatoreSDCAcquirente 
-- 	then
-- 		ur.DataInizioValidita
-- 	else NULL
-- 	end DataInizioValiditaAcquirente,
-- 	case ur.CodiceOperatoreSDC when c.CodiceOperatoreSDCAcquirente 
-- 	then
-- 		ur.DataFineValidita
-- 	else NULL
-- 	end DataFineValiditaAcquirente,
-- 	c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC,
-- 	ur.TrUC,
-- 	ur.VUC
-- from unitrelate ur
-- 	inner join 
-- 	contratto c
-- 	on
-- c.DataInizioValidita <= @DataFlusso and c.DataFineValidita >= @DataFlusso
-- and 
-- (
-- 	(ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and ur.TipoUnita in ('P', 'M'))
-- or 
-- 	(ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and ur.TipoUnita in ('C', 'M'))
-- )
-- 	and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
-- 	and ur.Abilitata = 1
-- ) _ur
-- group by _ur.IdContratto,
-- 	_ur.CodiceUnitaSDC,
-- 	_ur.CategoriaUnitaSDC,
--   	_ur.DataInizioValidita,
--   	_ur.DataFineValidita,
-- 	_ur.TrCC,
--  	_ur.TrUC,
--  	_ur.VUC
-- ) uc
-- 		) bil_unitacontratto_unitrelate
-- 		where 		@DataFlusso between DataInizioValiditaCedente 	and DataFineValiditaCedente
-- 			or    	@DataFlusso between DataInizioValiditaAcquirente 	and DataFineValiditaAcquirente
-- 		order by IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC
-- 
-- 
-- 	open unita_cursor
-- 		-- Perform the first fetch.
-- 	fetch next from unita_cursor into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata,
-- 		@UnitaAssegnataOpCedente,
-- 		@UnitaAssegnataOpAcquirente,
-- 		@PrioritaBilanciamentoForzato,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC
-- 
-- 	
-- 
-- 	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
-- 	while @@FETCH_STATUS = 0
-- 	begin
-- 	-- Copy to the result of the function the required columns.
-- 	insert @retUnitaContratto values(
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC)
-- 	   -- This is executed as long as the previous fetch succeeds.
-- 	   fetch next from unita_cursor  into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC
-- 	end
-- 	close unita_cursor
-- 	deallocate unita_cursor
-- 	return
-- end
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE  function tab_UnitaContratto2(@DataRicerca datetime,@IdContr  int)
-- returns @retUnitaContratto table (	
-- 	IdContratto int NOT NULL ,
-- 	CodiceUnitaSDC varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CategoriaUnitaSDC varchar(1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	DataInizioValidita smalldatetime ,
-- 	DataFineValidita smalldatetime ,
-- 	TSModifica datetime,
-- 	UnitaDelContrattoValidata bit ,
-- 	UnitaAssegnataOpCedente bit ,
-- 	UnitaAssegnataOpAcquirente bit ,
-- 	PrioritaBilanciamentoForzato int ,
-- 	TrCC bit,
-- 	TrUC bit,
-- 	VUC  bit)
-- as
-- begin
-- 	declare	
-- 		@IdContratto int,
-- 		@CodiceUnitaSDC  varchar(16),
-- 		@CategoriaUnitaSDC varchar(1),
-- 		@DataInizioValidita smalldatetime,
-- 		@DataFineValidita smalldatetime,
-- 		@TSModifica datetime,
-- 		@UnitaDelContrattoValidata bit,
-- 		@UnitaAssegnataOpCedente bit,
-- 		@UnitaAssegnataOpAcquirente bit,
-- 		@PrioritaBilanciamentoForzato int,
-- 		@TrCC bit,
-- 		@TrUC bit,
-- 		@VUC bit
-- 	
-- 	declare unita_cursor cursor for
-- 		
-- 	select 
-- 	@IdContr IdContratto,
-- 	t.CodiceUnitaSDC,
-- 	t.CategoriaUnitaSDC,
-- 	@DataRicerca DataInizioValidita,
-- 	@DataRicerca DataFineValidita,
-- 	@DataRicerca TSModifica,
-- 	1 UnitaDelContrattoValidata,
-- 	t.UnitaAssegnataOpCedente,
-- 	t.UnitaAssegnataOpAcquirente,
-- 	0 PrioritaBilanciamentoForzato,
-- 	t.TrCC,
-- 	t.TrUC,
-- 	t.VUC
-- 	from 
-- 	(
-- 		select 
-- 		CodiceUnitaSDC, 
-- 		CategoriaUnitaSDC, 
-- 		TrCC,
-- 		TrUC,
-- 		VUC,
-- 		sum(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,
-- 		sum(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
-- 		from 
-- 		(
-- 			select 
-- 			ur.CodiceUnitaSDC, 
-- 			ur.CategoriaUnitaSDC, 
-- 			ur.TrUC, 
-- 			ur.VUC,
-- 			1 UnitaAssegnataOpCedente, 
-- 			0 UnitaAssegnataOpAcquirente,
-- 			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC
-- 			from unitrelate ur
-- 			inner join 
-- 			contratto c
-- 			on
-- 			c.IdContratto = @IdContr
-- 			and c.DataInizioValidita <= @DataRicerca and c.DataFineValidita >= @DataRicerca
-- 			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and ur.TipoUnita in ('P', 'M')
-- 			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
-- 			and ur.Abilitata = 1
-- 		union
-- 			select 
-- 			ur.CodiceUnitaSDC, 
-- 			ur.CategoriaUnitaSDC, 
-- 			ur.TrUC, 
-- 			ur.VUC,
-- 			0 UnitaAssegnataOpCedente, 
-- 			1 UnitaAssegnataOpAcquirente,
-- 			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC
-- 			from unitrelate ur
-- 			inner join 
-- 			contratto c
-- 			on
-- 			c.IdContratto = @IdContr
-- 			and c.DataInizioValidita <= @DataRicerca and c.DataFineValidita >= @DataRicerca
-- 			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and ur.TipoUnita in ('C', 'M')
-- 			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
-- 			and ur.Abilitata = 1
-- 	) u
-- 	group by CodiceUnitaSDC, 
-- 	CategoriaUnitaSDC,
-- 	TrUC,
-- 	VUC,
-- 	TrCC
-- 	)
-- 	t
-- 	order by CodiceUnitaSDC, CategoriaUnitaSDC
-- 
-- 	open unita_cursor
-- 		-- Perform the first fetch.
-- 	fetch next from unita_cursor into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata,
-- 		@UnitaAssegnataOpCedente,
-- 		@UnitaAssegnataOpAcquirente,
-- 		@PrioritaBilanciamentoForzato,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC
-- 
-- 	
-- 
-- 	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
-- 	while @@FETCH_STATUS = 0
-- 	begin
-- 	-- Copy to the result of the function the required columns.
-- 	insert @retUnitaContratto values(
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC)
-- 	   -- This is executed as long as the previous fetch succeeds.
-- 	   fetch next from unita_cursor  into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC
-- 	end
-- 	close unita_cursor
-- 	deallocate unita_cursor
-- 	return
-- end
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE  function tab_UnitaContratto3(@DataRicerca datetime,@Operatore  varchar(16))
-- returns @retUnitaContratto table (	
-- 	IdContratto int NOT NULL ,
-- 	CodiceUnitaSDC varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CategoriaUnitaSDC varchar(1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	DataInizioValidita smalldatetime ,
-- 	DataFineValidita smalldatetime ,
-- 	TSModifica datetime,
-- 	UnitaDelContrattoValidata bit ,
-- 	UnitaAssegnataOpCedente bit ,
-- 	UnitaAssegnataOpAcquirente bit ,
-- 	PrioritaBilanciamentoForzato int ,
-- 	TrCC bit,
-- 	TrUC bit,
-- 	VUC  bit)
-- as
-- begin
-- 	declare	
-- 		@IdContratto int,
-- 		@CodiceUnitaSDC  varchar(16),
-- 		@CategoriaUnitaSDC varchar(1),
-- 		@DataInizioValidita smalldatetime,
-- 		@DataFineValidita smalldatetime,
-- 		@TSModifica datetime,
-- 		@UnitaDelContrattoValidata bit,
-- 		@UnitaAssegnataOpCedente bit,
-- 		@UnitaAssegnataOpAcquirente bit,
-- 		@PrioritaBilanciamentoForzato int,
-- 		@TrCC bit,
-- 		@TrUC bit,
-- 		@VUC bit
-- 	
-- 	declare unita_cursor cursor for
-- 		
-- 	select 
-- 	t.IdContratto,
-- 	t.CodiceUnitaSDC,
-- 	t.CategoriaUnitaSDC,
-- 	@DataRicerca DataInizioValidita,
-- 	@DataRicerca DataFineValidita,
-- 	@DataRicerca TSModifica,
-- 	1 UnitaDelContrattoValidata,
-- 	t.UnitaAssegnataOpCedente,
-- 	t.UnitaAssegnataOpAcquirente,
-- 	0 PrioritaBilanciamentoForzato,
-- 	t.TrCC,
-- 	t.TrUC,
-- 	t.VUC
-- 	from 
-- 	(
-- 		select 
-- 		IdContratto,
-- 		CodiceUnitaSDC, 
-- 		CategoriaUnitaSDC, 
-- 		TrCC,
-- 		TrUC,
-- 		VUC,
-- 		sum(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,
-- 		sum(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
-- 		from 
-- 		(
--  			select 
-- 			c.IdContratto,
-- 			ur.CodiceUnitaSDC, 
-- 			ur.CategoriaUnitaSDC, 
-- 			ur.TrUC, 
-- 			ur.VUC,
-- 			1 UnitaAssegnataOpCedente, 
-- 			0 UnitaAssegnataOpAcquirente,
-- 			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC
-- 			from unitrelate ur
-- 			inner join 
-- 			contratto c
-- 			on
-- 			c.CodiceOperatoreSDCCedente = @Operatore
-- 			and c.DataInizioValidita <= @DataRicerca and c.DataFineValidita >= @DataRicerca
-- 			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and ur.TipoUnita in ('P', 'M')
-- 			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
-- 			and ur.Abilitata = 1
-- 		union
-- 			select 
-- 			c.IdContratto,
-- 			ur.CodiceUnitaSDC, 
-- 			ur.CategoriaUnitaSDC, 
-- 			ur.TrUC, 
-- 			ur.VUC,
-- 			0 UnitaAssegnataOpCedente, 
-- 			1 UnitaAssegnataOpAcquirente,
-- 			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC
-- 			from unitrelate ur
-- 			inner join 
-- 			contratto c
-- 			on
-- 			c.CodiceOperatoreSDCAcquirente = @Operatore
-- 			and c.DataInizioValidita <= @DataRicerca and c.DataFineValidita >= @DataRicerca
-- 			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and ur.TipoUnita in ('C', 'M')
-- 			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
-- 			and ur.Abilitata = 1
--  	) u
-- 	group by IdContratto,
-- 	CodiceUnitaSDC, 
-- 	CategoriaUnitaSDC,
-- 	TrUC,
-- 	VUC,
-- 	TrCC
--   	)
--   	t
--  	order by IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC
-- 	
-- 	
-- 	option (FORCE ORDER)
-- 	
-- 
-- 	open unita_cursor
-- 		-- Perform the first fetch.
-- 	fetch next from unita_cursor into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata,
-- 		@UnitaAssegnataOpCedente,
-- 		@UnitaAssegnataOpAcquirente,
-- 		@PrioritaBilanciamentoForzato,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC
-- 
-- 	
-- 
-- 	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
-- 	while @@FETCH_STATUS = 0
-- 	begin
-- 	-- Copy to the result of the function the required columns.
-- 	insert @retUnitaContratto values(
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC)
-- 	   -- This is executed as long as the previous fetch succeeds.
-- 	   fetch next from unita_cursor  into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC
-- 	end
-- 	close unita_cursor
-- 	deallocate unita_cursor
-- 	return
-- end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS OFF 
-- GO
-- 
-- CREATE  function tab_UnitaContratto4(@DataRicerca datetime,@CodiceUnita  varchar(16), @CategoriaUnita varchar(1))
-- returns @retUnitaContratto table (	
-- 	IdContratto int NOT NULL ,
-- 	CodiceUnitaSDC varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
-- 	CategoriaUnitaSDC varchar(1) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
-- 	DataInizioValidita smalldatetime ,
-- 	DataFineValidita smalldatetime ,
-- 	TSModifica datetime,
-- 	UnitaDelContrattoValidata bit ,
-- 	UnitaAssegnataOpCedente bit ,
-- 	UnitaAssegnataOpAcquirente bit ,
-- 	PrioritaBilanciamentoForzato int ,
-- 	TrCC bit,
-- 	TrUC bit,
-- 	VUC  bit)
-- as
-- begin
-- 	declare	
-- 		@IdContratto int,
-- 		@CodiceUnitaSDC  varchar(16),
-- 		@CategoriaUnitaSDC varchar(1),
-- 		@DataInizioValidita smalldatetime,
-- 		@DataFineValidita smalldatetime,
-- 		@TSModifica datetime,
-- 		@UnitaDelContrattoValidata bit,
-- 		@UnitaAssegnataOpCedente bit,
-- 		@UnitaAssegnataOpAcquirente bit,
-- 		@PrioritaBilanciamentoForzato int,
-- 		@TrCC bit,
-- 		@TrUC bit,
-- 		@VUC bit
-- 	
-- 	declare unita_cursor cursor for
-- 		
-- 	select 
-- 	t.IdContratto,
-- 	t.CodiceUnitaSDC,
-- 	t.CategoriaUnitaSDC,
-- 	@DataRicerca DataInizioValidita,
-- 	@DataRicerca DataFineValidita,
-- 	@DataRicerca TSModifica,
-- 	1 UnitaDelContrattoValidata,
-- 	t.UnitaAssegnataOpCedente,
-- 	t.UnitaAssegnataOpAcquirente,
-- 	0 PrioritaBilanciamentoForzato,
-- 	t.TrCC,
-- 	t.TrUC,
-- 	t.VUC
-- 	from 
-- 	(
-- 		select 
-- 		IdContratto,
-- 		CodiceUnitaSDC, 
-- 		CategoriaUnitaSDC, 
-- 		TrCC,
-- 		TrUC,
-- 		VUC,
-- 		sum(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,
-- 		sum(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
-- 		from 
-- 		(
--  			select 
-- 			c.IdContratto,
-- 			ur.CodiceOperatoreSDC,
-- 			ur.CodiceUnitaSDC, 
-- 			ur.CategoriaUnitaSDC, 
-- 			ur.TrUC, 
-- 			ur.VUC,
-- 			1 UnitaAssegnataOpCedente, 
-- 			0 UnitaAssegnataOpAcquirente,
-- 			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC
-- 			from unitrelate ur
-- 			inner join 
-- 			contratto c
-- 			on
-- 			ur.CodiceUnitaSDC = @CodiceUnita
-- 			and ur.CategoriaUnitaSDC = @CategoriaUnita
-- 			and c.DataInizioValidita <= @DataRicerca and c.DataFineValidita >= @DataRicerca
-- 			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and ur.TipoUnita in ('P', 'M')
-- 			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
-- 			and ur.Abilitata = 1
-- 		union
-- 			select 
-- 			c.IdContratto,
-- 			ur.CodiceOperatoreSDC,
-- 			ur.CodiceUnitaSDC, 
-- 			ur.CategoriaUnitaSDC, 
-- 			ur.TrUC, 
-- 			ur.VUC,
-- 			0 UnitaAssegnataOpCedente, 
-- 			1 UnitaAssegnataOpAcquirente,
-- 			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC
-- 			from unitrelate ur
-- 			inner join 
-- 			contratto c
-- 			on
-- 			ur.CodiceUnitaSDC = @CodiceUnita
-- 			and ur.CategoriaUnitaSDC = @CategoriaUnita
-- 			and c.DataInizioValidita <= @DataRicerca and c.DataFineValidita >= @DataRicerca
-- 			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and ur.TipoUnita in ('C', 'M')
-- 			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
-- 			and ur.Abilitata = 1
--   	) u
-- 	group by IdContratto,
-- 	CodiceUnitaSDC, 
-- 	CategoriaUnitaSDC,
-- 	TrUC,
-- 	VUC,
-- 	TrCC
--    	)
--    	t
--   	order by IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC
-- 	
-- 	
-- 	option (FORCE ORDER)
-- 
-- 	
-- 
-- 	open unita_cursor
-- 		-- Perform the first fetch.
-- 	fetch next from unita_cursor into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata,
-- 		@UnitaAssegnataOpCedente,
-- 		@UnitaAssegnataOpAcquirente,
-- 		@PrioritaBilanciamentoForzato,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC
-- 
-- 	
-- 
-- 	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
-- 	while @@FETCH_STATUS = 0
-- 
-- 	begin
-- 	-- Copy to the result of the function the required columns.
-- 	insert @retUnitaContratto values(
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC)
-- 	   -- This is executed as long as the previous fetch succeeds.
-- 	   fetch next from unita_cursor  into
-- 		@IdContratto,
-- 		@CodiceUnitaSDC,
-- 		@CategoriaUnitaSDC,
-- 		@DataInizioValidita ,
-- 		@DataFineValidita ,
-- 		@TSModifica,
-- 		@UnitaDelContrattoValidata ,
-- 		@UnitaAssegnataOpCedente ,
-- 		@UnitaAssegnataOpAcquirente ,
-- 		@PrioritaBilanciamentoForzato ,
-- 		@TrCC,
-- 		@TrUC,
-- 		@VUC
-- 	end
-- 	close unita_cursor
-- 	deallocate unita_cursor
-- 	return
-- end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- print 'Begin: Create Triggers'
-- GO
-- /****** Object:  Trigger dbo.Contratto_OnUpdate    Script Date: 01/04/2004 14.58.12 ******/
-- CREATE TRIGGER Contratto_OnUpdate ON dbo.Contratto 
-- FOR UPDATE
-- AS
-- 	--declare @Count int
-- 
-- 	--if update(StatoContratto) or update(TrCN)
-- 	--begin
-- 	--	--select @Count = count(*) from Inserted
-- 	--	--if @Count > 0
-- 	--	--begin
-- 	--		update UnitaContratto
-- 	--		set TrCC = i.TrCN & (case i.StatoContratto when 'Abilitato' then 1 else 0 end)
-- 	--		from inserted i
-- 	--		join UnitaContratto u 
-- 	--		on i.idcontratto = u.idcontratto
-- 
-- 	--		if @@error != 0
-- 	--			rollback tran
-- 	--	--end
-- 	--end
-- 
-- 
-- 	if update(CodiceOperatoreSDC) or update(CodiceOperatoreSDCCedente) or update(CodiceOperatoreSDCAcquirente)
-- 	begin
-- 		update Contratto
-- 		set
-- 			TrCN = oTitolare.StatoBilateraliOperatore & soTitolare.Abilitato & oCed.StatoBilateraliOperatore & soCed.Abilitato & oAcq.StatoBilateraliOperatore & soAcq.Abilitato
-- 		from Contratto cn
-- 		join Inserted i
-- 		on
-- 			i.IdContratto = cn.IdContratto
-- 		join Operatori oTitolare
-- 		on 
-- 			i.CodiceOperatoreSDC = oTitolare.CodiceOperatoreSDC
-- 		join SDC_Operatori soTitolare
-- 		on
-- 			i.CodiceOperatoreSDC = soTitolare.CodiceOperatoreSDC
-- 
-- 		join Operatori oCed
-- 		on 
-- 			i.CodiceOperatoreSDCCedente = oCed.CodiceOperatoreSDC
-- 		join SDC_Operatori soCed
-- 		on
-- 			i.CodiceOperatoreSDCCedente = soCed.CodiceOperatoreSDC
-- 
-- 		join Operatori oAcq
-- 		on 
-- 			i.CodiceOperatoreSDCAcquirente = oAcq.CodiceOperatoreSDC
-- 		join SDC_Operatori soAcq
-- 		on
-- 			i.CodiceOperatoreSDCAcquirente = soAcq.CodiceOperatoreSDC
-- 	end
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- /****** Object:  Trigger dbo.Contratto_Insert    Script Date: 01/04/2004 14.58.12 ******/
-- CREATE TRIGGER Contratto_Insert ON dbo.Contratto 
-- AFTER INSERT
-- AS
-- 	-- valorizzo TrCN record appena inserito in modo da 
-- 	-- rispecchiare lo stato di Operatori e SDC_Operatori
-- 	--declare @Count int
-- 
-- 	--select @Count = count(*) from Inserted
-- 	--if @Count > 0
-- 	--begin
-- 		update Contratto
-- 		set
-- 			TrCN = oTitolare.StatoBilateraliOperatore & soTitolare.Abilitato & oCed.StatoBilateraliOperatore & soCed.Abilitato & oAcq.StatoBilateraliOperatore & soAcq.Abilitato
-- 		from Contratto cn
-- 		join Inserted i
-- 		on
-- 			i.IdContratto = cn.IdContratto
-- 		join Operatori oTitolare
-- 		on 
-- 			i.CodiceOperatoreSDC = oTitolare.CodiceOperatoreSDC
-- 		join SDC_Operatori soTitolare
-- 		on
-- 			i.CodiceOperatoreSDC = soTitolare.CodiceOperatoreSDC
-- 
-- 		join Operatori oCed
-- 		on 
-- 			i.CodiceOperatoreSDCCedente = oCed.CodiceOperatoreSDC
-- 		join SDC_Operatori soCed
-- 		on
-- 			i.CodiceOperatoreSDCCedente = soCed.CodiceOperatoreSDC
-- 
-- 		join Operatori oAcq
-- 		on 
-- 			i.CodiceOperatoreSDCAcquirente = oAcq.CodiceOperatoreSDC
-- 		join SDC_Operatori soAcq
-- 		on
-- 			i.CodiceOperatoreSDCAcquirente = soAcq.CodiceOperatoreSDC
-- 
-- 		if @@error != 0
-- 			rollback tran
-- 	--end
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- /****** Object:  Trigger dbo.Operatori_OnUpdate    Script Date: 01/04/2004 14.58.12 ******/
-- CREATE TRIGGER Operatori_OnUpdate ON dbo.Operatori 
-- FOR UPDATE
-- AS
-- 	-- se cambia StatoBilateraliOperatore nella tabella Operatore
-- 	-- aggiorno TrCN nella tabella Contratto
-- 	-- NB: TrCN dipende comunque anche da SDC_Operatore.Abilitato
-- 
-- 	--declare @Count int
-- 
-- 	if update(StatoBilateraliOperatore)
-- 	begin
-- 		--select @Count = count(*) from Inserted
-- 		--if @Count > 0
-- 		--begin
-- 			update Contratto
-- 			set TrCN = i.StatoBilateraliOperatore & so.Abilitato
-- 			from Contratto cn
-- 			join  inserted i
-- 			on 
-- 				i.CodiceOperatoreSDC = cn.CodiceOperatoreSDC
-- 				or i.CodiceOperatoreSDC = cn.CodiceOperatoreSDCAcquirente
-- 				or i.CodiceOperatoreSDC = cn.CodiceOperatoreSDCCedente
-- 			join SDC_Operatori so
-- 			on
-- 				i.CodiceOperatoreSDC = so.CodiceOperatoreSDC
-- 
-- 			if @@error != 0
-- 				rollback tran
-- 		--end
-- 	end
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- 
-- /****** Object:  Trigger dbo.SDC_Operatori_OnUpdate    Script Date: 01/04/2004 14.58.12 ******/
-- CREATE TRIGGER SDC_Operatori_OnUpdate ON [dbo].[SDC_Operatori] 
-- FOR UPDATE
-- AS
-- 	-- se cambia StatoBilateraliOperatore nella tabella Operatore
-- 	-- aggiorno TrCN nella tabella Contratto
-- 	-- NB: TrCN dipende comunque anche da SDC_Operatore.Abilitato
-- 
-- 	--declare @Count int
-- 
-- 	if update(Abilitato)
-- 	begin
-- 		--select @Count = count(*) from Inserted
-- 		--if @Count > 0
-- 		--begin
-- 			update Contratto
-- 			set TrCN = o.StatoBilateraliOperatore & i.Abilitato
-- 			from Contratto c
-- 			join  inserted i
-- 			on 
-- 				i.CodiceOperatoreSDC = c.CodiceOperatoreSDC
-- 				or i.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente
-- 				or i.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente
-- 			join Operatori o
-- 			on
-- 				i.CodiceOperatoreSDC = o.CodiceOperatoreSDC
-- 
-- 			if @@error != 0
-- 				rollback tran
-- 		--end
-- 	end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- CREATE TRIGGER SDC_PuntiDiScambioRilevanti_Update ON [dbo].[SDC_PuntiDiScambioRilevanti] 
-- FOR UPDATE
-- AS
-- 	if update(CoefficienteDiPerdita)
-- 	begin
-- 		declare @DataDomani smalldatetime
-- 		set @DataDomani=convert(datetime,convert(varchar,1+getdate(),112))
-- 	
-- 		update 
-- 		SessioneBilaterali
-- 		set
-- 		Bilanciamento=0,
-- 		Taglio=0
-- 		from 
-- 		SessioneBilaterali
-- 		where 
-- 		SessioneBilaterali.DataProgramma>=@DataDomani
-- 
-- 		if @@error != 0
-- 			rollback tran
-- 	end
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- /****** Object:  Trigger dbo.SDC_Unita_OnUpdate_UR    Script Date: 30/07/2004 09.06.12 ******/
-- CREATE  TRIGGER SDC_Unita_OnUpdate_UR ON dbo.SDC_Unita 
-- FOR UPDATE
-- AS
-- 	-- Se cambia Abilitata nella tabella SDC_Unita
-- 	-- non aggiorno piu` TrUC nella tabella UnitaContratto
-- 	-- bensi` VUC.
-- 	-- NB: TrUC vale 1 per Default ed e` utilizzato da GeneraOfferte e dalla
-- 	-- funzione che accetta i programmi per cui d'ora in poi anche le unita`
-- 	-- "disabilitate" partecipano alla programmazione.
-- 	-- VUC dipende comunque anche da Unita.StatoBilateraliUnita
-- 
-- 	if update(Abilitata)
-- 	begin
-- 		-- notare che la join stretta su Unita e` corretta perche`
-- 		-- se esiste una unita in UnitaContratto da aggiornare
-- 		-- allora deve esistere anche in Unita
-- 		update UnitRelate
-- 		set VUC = un.StatoBilateraliUnita & i.Abilitata & case(ISNULL(mi.Eligibility, 'Able')) when 'Able' then 1 else 0 end
-- 		from UnitRelate ur 
-- 		join  inserted i
-- 		on 
-- 			i.CodiceUnitaSDC = ur.CodiceUnitaSDC
-- 			and i.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
-- 		join Unita un
-- 		on
-- 			i.CodiceUnitaSDC = un.CodiceUnitaSDC
-- 			and i.CategoriaUnitaSDC = un.CategoriaUnitaSDC
-- 		left outer join SDC_Unita_MarketInformation mi
-- 		on
-- 			i.CodiceUnitaSDC = mi.CodiceUnitaSDC
-- 			and i.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
-- 			and mi.MarketCode = 'MGP'
-- 
-- 
-- 		if @@error != 0
-- 			rollback tran
-- 	end
-- 
-- 
-- 	-- se e` cambiato il coefficiente di perdita
-- 	-- invalido tutti i bilanciamenti da domani in poi
-- 	if update(CoefficientePerdita)
-- 	begin
-- 		declare @DataDomani smalldatetime
-- 		set @DataDomani=convert(datetime,convert(varchar,1+getdate(),112))
-- 	
-- 		update 
-- 		SessioneBilaterali
-- 		set
-- 		Bilanciamento=0,
-- 		Taglio=0
-- 		from 
-- 		SessioneBilaterali
-- 		where 
-- 		SessioneBilaterali.DataProgramma>=@DataDomani
-- 
-- 		if @@error != 0
-- 			rollback tran
-- 	end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- CREATE  TRIGGER SDC_Unita_MarketInformationOnInsert_UR ON [dbo].[SDC_Unita_MarketInformation] 
-- AFTER INSERT
-- AS
-- 
-- 	update UnitRelate
-- 	set VUC = un.StatoBilateraliUnita & su.Abilitata & case(i.Eligibility) when 'Able' then 1 else 0 end
-- 	from UnitRelate ur
-- 	join  inserted i
-- 	on 
-- 		i.CodiceUnitaSDC = ur.CodiceUnitaSDC
-- 		and i.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
-- 		and i.MarketCode = 'MGP'
-- 	join SDC_Unita su
-- 	on
-- 		su.CodiceUnitaSDC = i.CodiceUnitaSDC
-- 		and su.CategoriaUnitaSDC = i.CategoriaUnitaSDC
-- 	join Unita un
-- 	on
-- 		i.CodiceUnitaSDC = un.CodiceUnitaSDC
-- 		and i.CategoriaUnitaSDC = un.CategoriaUnitaSDC
-- 
-- 
-- 	if @@error != 0
-- 		rollback tran
-- 
-- 	declare @DataDomani smalldatetime
-- 	set @DataDomani=convert(datetime,convert(varchar,1+getdate(),112))
-- 
-- 	update 
-- 	SessioneBilaterali
-- 	set
-- 	Bilanciamento=0,
-- 	Taglio=0
-- 	from 
-- 	SessioneBilaterali
-- 	where 
-- 	SessioneBilaterali.DataProgramma>=@DataDomani
-- 
-- 	if @@error != 0
-- 		rollback tran
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- 
-- 
-- CREATE TRIGGER SDC_Unita_MarketInformationOnUpdate_UR ON [dbo].[SDC_Unita_MarketInformation] 
-- FOR UPDATE
-- AS
-- if update(Eligibility)
-- 	begin
-- 		-- notare che la join stretta su Unita e` corretta perche`
-- 		-- se esiste una unita in UnitaContratto da aggiornare
-- 		-- allora deve esistere anche in Unita
-- 		update UnitRelate
-- 		set VUC = un.StatoBilateraliUnita & su.Abilitata & case(i.Eligibility) when 'Able' then 1 else 0 end
-- 		from UnitRelate ur
-- 		join  inserted i
-- 		on 
-- 			i.CodiceUnitaSDC = ur.CodiceUnitaSDC
-- 			and i.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
-- 			and i.MarketCode = 'MGP'
-- 		join SDC_Unita su
-- 		on
-- 			su.CodiceUnitaSDC = i.CodiceUnitaSDC
-- 			and su.CategoriaUnitaSDC = i.CategoriaUnitaSDC
-- 		join Unita un
-- 		on
-- 			i.CodiceUnitaSDC = un.CodiceUnitaSDC
-- 			and i.CategoriaUnitaSDC = un.CategoriaUnitaSDC
-- 
-- 
-- 		if @@error != 0
-- 			rollback tran
-- 
-- 		declare @DataDomani smalldatetime
-- 		set @DataDomani=convert(datetime,convert(varchar,1+getdate(),112))
-- 		
-- 		update 
-- 			SessioneBilaterali
-- 		set
-- 			Bilanciamento=0,
-- 			Taglio=0
-- 		from 
-- 			SessioneBilaterali
-- 		where 
-- 			SessioneBilaterali.DataProgramma>=@DataDomani
-- 		
-- 		if @@error != 0
-- 			rollback tran
-- 
-- 	end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- /****** Object:  Trigger dbo.UnitRelate_Insert    Script Date: 01/04/2004 14.58.12 ******/
-- CREATE  TRIGGER UnitRelate_Insert ON dbo.UnitRelate
-- AFTER INSERT
-- AS
-- 	-- valorizzo TrUC e VUC del record appena inserito in modo da 
-- 	-- rispecchiare lo stato delle Unita/SDC_Unita
-- 	--declare @Count int
-- 
-- 	update UnitRelate
-- 	set
-- 		VUC = un.StatoBilateraliUnita & su.Abilitata & case(ISNULL(mi.Eligibility, 'Able')) when 'Able' then 1 else 0 end,
-- 		TrUC = un.StatoBilateraliUnita,
-- 		TipoUnita = su.TipoUnita
-- 	from UnitRelate ur
-- 	join Inserted i
-- 	on
-- 		i.CodiceOperatoreSDC = ur.CodiceOperatoreSDC
-- 		and i.CodiceUnitaSDC = ur.CodiceUnitaSDC
-- 		and i.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
-- 	join Unita un
-- 	on 
-- 		i.CodiceUnitaSDC = un.CodiceUnitaSDC
-- 		and i.CategoriaUnitaSDC = un.CategoriaUnitaSDC
-- 	join SDC_Unita su
-- 	on
-- 		i.CodiceUnitaSDC = su.CodiceUnitaSDC
-- 		and i.CategoriaUnitaSDC = su.CategoriaUnitaSDC
-- 	left outer join SDC_Unita_MarketInformation mi
-- 	on
-- 		i.CodiceUnitaSDC = mi.CodiceUnitaSDC
-- 		and i.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
-- 		and mi.MarketCode = 'MGP'
-- 
-- 	if @@error != 0
-- 		rollback tran
-- 
-- 
-- 	-- una unita` e` stata inserita in un contratto...
-- 	-- non vado per il sottile e impongo
-- 	-- di rifare il bilanciamento da oggi in poi
-- 
-- 	declare @DataDomani smalldatetime
-- 	set @DataDomani=convert(datetime,convert(varchar,1+getdate(),112))
-- 
-- 	update 
-- 	SessioneBilaterali
-- 	set
-- 	Bilanciamento=0,
-- 	Taglio=0
-- 	from 
-- 	SessioneBilaterali
-- 	where 
-- 	SessioneBilaterali.DataProgramma>=@DataDomani
-- 
-- 	if @@error != 0
-- 		rollback tran
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE  TRIGGER UnitRelate_Update ON dbo.UnitRelate 
-- FOR UPDATE
-- AS
-- 	-- exec spSetBilanciamentoTaglioDaRifare
-- 
-- 	declare @DataDomani smalldatetime
-- 	set @DataDomani=convert(datetime,convert(varchar,1+getdate(),112))
-- 
-- 	update 
-- 	SessioneBilaterali
-- 	set
-- 	Bilanciamento=0,
-- 	Taglio=0
-- 	from 
-- 	SessioneBilaterali
-- 	where 
-- 	SessioneBilaterali.DataProgramma>=@DataDomani
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- CREATE  TRIGGER UnitRelate_Delete ON dbo.UnitRelate 
-- FOR DELETE
-- AS
-- 	if exists 
-- 	(
-- 		select *
-- 			from ProgrammaOrarioPerUnita POU, SDC_Unita SU, Deleted d
-- 			where SU.CodiceUnitaSDC = POU.CodiceUnitaSDC and
-- 			SU.CategoriaUnitaSDC = POU.CategoriaUnitaSDC and 
-- 			POU.CodiceUnitaSDC = d.CodiceUnitaSDC and 
-- 			POU.CategoriaUnitaSDC = d.CategoriaUnitaSDC and
-- 			POU.IdContratto in (
-- 				select IdContratto 
-- 				from Contratto 
-- 				where CodiceOperatoreSDCAcquirente = d.CodiceOperatoreSDC or CodiceOperatoreSDCCedente = d.CodiceOperatoreSDC
-- 			) 
-- 			and (
-- 	 			POU.ProgrammatoDalCedente = 0 and SU.TipoUnita in ('M', 'C')
-- 		 		or
-- 				POU.ProgrammatoDalCedente = 1 and SU.TipoUnita in ('M', 'P')
-- 			)
-- 	)
-- 	
-- 	begin
-- 		raiserror('Cancellazione fallita per unita` programmate in ProgrammaOrarioPerUnita !', 16, 1)
-- 		rollback tran
-- 	end
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- SET QUOTED_IDENTIFIER ON 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- 
-- /****** Object:  Trigger dbo.Unita_OnUpdate_UR    Script Date: 30/07/2004 09.21.12 ******/
-- CREATE TRIGGER Unita_OnUpdate_UR ON dbo.Unita 
-- FOR UPDATE
-- AS
-- 	-- se cambia StatoBilateraliUnita nella tabella Unita
-- 	-- aggiorno sia TrUC nella tabella UnitRelate
-- 	-- che VUC. Notare che e` l'unico bit di abilitazione che pilota TrUC 
-- 	-- e quindi ha effetto sulla attivita` proprie dei Bilaterali:
-- 	-- Accettazione Pgm Utente, Calc. Bil., Bil. Forz., Generazione Offerte per MGP,
-- 	-- XML Pgm Acq/Ced, XML Titolari, XML Bil., Programmazione Oraria, Report.
-- 	-- NB: TrUC di Default vale 1 ma eredita il valore di StatoBilateraliUnita,
-- 	-- mentre VUC dipende comunque anche da SDC_Unita.Abilitata
-- 
-- 	--declare @Count int
-- 
-- 	if update(StatoBilateraliUnita)
-- 	begin
-- 		--select @Count = count(*) from Inserted
-- 		--if @Count > 0
-- 		--begin
-- 			update UnitRelate
-- 			set 	TrUC =  i.StatoBilateraliUnita,
-- 				VUC = i.StatoBilateraliUnita & su.Abilitata & case(ISNULL(mi.Eligibility, 'Able')) when 'Able' then 1 else 0 end
-- 			from UnitRelate ur
-- 			join  inserted i
-- 			on 
-- 				i.CodiceUnitaSDC = ur.CodiceUnitaSDC
-- 				and i.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
-- 			join SDC_Unita su
-- 			on
-- 				i.CodiceUnitaSDC = su.CodiceUnitaSDC
-- 				and i.CategoriaUnitaSDC = su.CategoriaUnitaSDC
-- 			left outer join SDC_Unita_MarketInformation mi
-- 			on
-- 				i.CodiceUnitaSDC = mi.CodiceUnitaSDC
-- 				and i.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
-- 				and mi.MarketCode = 'MGP'
-- 
-- 			if @@error != 0
-- 				rollback tran
-- 		--end
-- 	end
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- GO
-- SET QUOTED_IDENTIFIER OFF 
-- GO
-- SET ANSI_NULLS ON 
-- GO
-- 
-- /* ---------------- Fine Viste, Funzioni, Stored Procedure ------------------------- */
-- print 'UPDATE TipoUnita ON UnitRelate'
-- UPDATE UnitRelate 
-- SET TipoUnita = SU.TipoUnita 
-- FROM SDC_Unita SU
-- WHERE SU.CodiceUnitaSDC = UnitRelate.CodiceUnitaSDC
-- AND SU.CategoriaUnitaSDC = UnitRelate.CategoriaUnitaSDC

print 'Aggiornamento Stored Procedure [ReportEnergiaContrattiFlaggati].'

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportEnergiaContrattiFlaggati]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportEnergiaContrattiFlaggati]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




CREATE   PROCEDURE dbo.ReportEnergiaContrattiFlaggati
	(
		@DataProgramma datetime
	)
AS

-- e' un report che va in POU --> leggo senza aspettare le modifiche dei programmi
set transaction isolation level read uncommitted
	
select case(GestioneTaglio)
	when 'T' then 'Sempre'
	when 'C' then 'Consumo supera Produzione'
	when 'P' then  'Produzione supera Consumo'
	when 'M' then 'Mai'
end GestioneTaglio,
	round(sum(isnull(QtyMWhProd, 0)), 3) QtyMWhProduzione, 
	round(sum(isnull(QtyMWhProdMGP, 0)), 3) QtyMWhProduzioneMGP, 
	round(sum(isnull(QtyMWhCons, 0)), 3) QtyMWhConsumo,
	round(sum(isnull(QtyMWhConsMGP, 0)), 3) QtyMWhConsumoMGP
from
(
select c.CodiceContratto, 
	c.CRN,
	c.CodiceOperatoreSDCCedente,
	c.CodiceOperatoreSDCAcquirente,
	c.GestioneTaglio, 
	p.QtyMWhProd, 
	p.QtyMWhProdMGP,
	p.QtyMWhCons,
	p.QtyMWhConsMGP
from
(
select * from
contratto 
where DataInizioValidita <= @DataProgramma 
and DataFineValidita >= @DataProgramma
and StatoContratto = 'Abilitato'
and TrCN = 1) 
c
left outer join
(
select po.IdContratto, 
	po.PeriodoRilevante,
	case pou.ProgrammatoDalCedente 
	when 1 then
		abs(sum(isnull(pou.QtyMWhBilanciamento, pou.QtyMwh))) 
	else
		0
	end QtyMWhProd,
	case pou.ProgrammatoDalCedente 
	when 1 then
		abs(sum(isnull(pou.QtyMWhAssegnataMGP, 0))) 
	else
		0
	end QtyMWhProdMGP,
	case pou.ProgrammatoDalCedente 
	when 0 then
		abs(sum(isnull(pou.QtyMWhBilanciamento, pou.QtyMwh))) 
	else
		0
	end QtyMWhCons,
	case pou.ProgrammatoDalCedente 
	when 0 then
		abs(sum(pou.QtyMWhAssegnataMGP)) 
	else
		0
	end QtyMWhConsMGP
from programmaorario po, 
programmaorarioperunita pou
where po.DataProgramma = @DataProgramma
and pou.DataProgramma = @DataProgramma
and po.PeriodoRilevante <= 25
and pou.PeriodoRilevante <= 25
and pou.PeriodoRilevante = po.PeriodoRilevante
group by po.IdContratto, po.PeriodoRilevante, pou.ProgrammatoDalCedente 
) p
on c.IdContratto = p.IdContratto
) t 
group by GestioneTaglio









	RETURN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaContrattiFlaggati]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaContrattiFlaggati]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaContrattiFlaggati]  TO [bil_dbo]
GO




SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

print 'Aggiornamento Stored Procedure [ReportEnergiaContrattiFlaggati] concluso.'


print 'Aggiornamento Stored Procedure [ReportEnergiaSbilancio].'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportEnergiaSbilancio]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportEnergiaSbilancio]
GO



CREATE  PROCEDURE dbo.ReportEnergiaSbilancio
	@DataProgramma as datetime
AS
	
-- e' un report che va in POU --> leggo senza aspettare le modifiche dei programmi
set transaction isolation level read uncommitted


create table #Report1
(
IdContratto      integer,
DataProgramma    smalldatetime,
PeriodoRilevante tinyint,
QP float,
QC float,
QPT float,
QCT float,
QPMGP float,
QCMGP float
)

insert into #Report1
	select
	POU.IdContratto,
	POU.DataProgramma,
	POU.PeriodoRilevante,
	sum(QtyMWh * ProgrammatoDalCedente) QP,
	sum(QtyMWh * -1 * (ProgrammatoDalCedente - 1)) QC,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * ProgrammatoDalCedente) QPT,
	sum(isnull(QtyMWhBilanciamento, QtyMWh) * -1 * (ProgrammatoDalCedente - 1)) QCT,
--	sum(isnull(QtyMWhAssegnataMGP, 0) * ProgrammatoDalCedente) QPMGP,
--	sum(isnull(QtyMWhAssegnataMGP, 0) * -1 * (ProgrammatoDalCedente - 1)) QPMGC
	sum(QtyMWhAssegnataMGP  * ProgrammatoDalCedente) QPMGP,
	sum(QtyMWhAssegnataMGP  * (-1) * (ProgrammatoDalCedente - 1)) QPMGC
	from
	ProgrammaOrarioPerUnita POU
	inner join Contratto CO
	on CO.IdContratto = POU.IdContratto
	and CO.TrCN = 1
	and CO.StatoContratto = 'Abilitato'
	inner join UnitRelate UR
	on  UR.CodiceUnitaSDC    = POU.CodiceUnitaSDC
	and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC 
	and 
	(
		(POU.ProgrammatoDalCedente=1 and UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente)
		or
		(POU.ProgrammatoDalCedente=0 and UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente)
	)
	and UR.TrUC = 1
	and UR.DataInizioValidita <= @DataProgramma
	and UR.DataFineValidita   >= @DataProgramma
	and UR.Abilitata = 1
	
	where
	POU.DataProgramma = @DataProgramma
	and POU.PeriodoRilevante <= 25
	and POU.ProgOrarioDellUnitaValidato=1
	group by POU.DataProgramma, POU.PeriodoRilevante, POU.IdContratto


-- select @DataProgramma DataProgramma,
-- C.CRN,
-- C.CodiceContratto,
-- C.CodiceOperatoreSDCCedente Cedente,
-- C.CodiceOperatoreSDCAcquirente Acquirente,
-- case (C.GestioneTaglio) 
-- 	when 'T' then 'Sempre'
-- 	when 'C' then 'se cons. supera prod.'
-- 	when 'P' then 'se prod. supera cons.'
-- 	when 'M' then 'mai'
-- end 
-- GestioneTaglio,
-- Q.PeriodoRilevante Ora,
-- Q.QtyMWhProd,
-- Q.QtyMWhCons,
-- Q.QtyMWhProdMGP,
-- Q.QtyMWhConsMGP,
-- Q.Bilanciato Bilanciato,
-- Q.BilMWh SbilanciamentoMWh


select 
@DataProgramma DataProgramma,
C.CRN,
C.CodiceContratto,
C.CodiceOperatoreSDCCedente Cedente,
C.CodiceOperatoreSDCAcquirente Acquirente,
--C.IdContratto,
case (C.GestioneTaglio) 
	when 'T' then 'Sempre'
	when 'C' then 'se cons. supera prod.'
	when 'P' then 'se prod. supera cons.'
	when 'M' then 'mai'
end 
GestioneTaglio,
PO.PeriodoRilevante Ora,

cast (R.QP as decimal(16,3))  QtyMWhProd,
cast (R.QC as decimal(16,3))   QtyMWhCons,
cast (R.QPT as decimal(16,3))  QtyMWhProdT,
cast (R.QCT as decimal(16,3))  QtyMWhConsT,
cast (R.QPMGP as decimal(16,3))  QtyMWhProdMGP,
cast (R.QCMGP as decimal(16,3))  QtyMWhConsMGP,

PO.Bilanciato Bilanciato,
cast(PO.SbilanciamentoMWh as decimal(16,3)) SbilanciamentoMWh

from ProgrammaOrario PO
inner join Contratto C
on PO.IdContratto = C.IdContratto
and C.StatoContratto = 'Abilitato'
and C.TrCN = 1
and C.DataInizioValidita <= @DataProgramma and C.DataFineValidita >= @DataProgramma

inner join #Report1 R
on  R.IdContratto   = PO.IdContratto
and R.DataProgramma = PO.DataProgramma
and R.PeriodoRilevante = PO.PeriodoRilevante

where
PO.DataProgramma = @DataProgramma
and PO.PeriodoRilevante <= 25
and PO.ProgrammaOrarioValidato = 1
and PO.Bilanciato is not null

order by 
C.CRN, 
PO.PeriodoRilevante


drop table #Report1

RETURN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[ReportEnergiaSbilancio]  TO [bil_dbo]
GO



print 'Aggiornamento Stored Procedure [ReportEnergiaSbilancio] concluso.'


-- [spGetProgrammiConCertificatoNonValido]
print 'Aggiornamento Stored Procedure [spGetProgrammiConCertificatoNonValido]'
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetProgrammiConCertificatoNonValido]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetProgrammiConCertificatoNonValido]
GO



CREATE PROCEDURE [dbo].[spGetProgrammiConCertificatoNonValido] 
	@CodiceUtenteSDC as varchar(16),
	@Issuer as varchar(256),
	@SerialNumber as varchar(64),
	@DataRicerca as smalldatetime
AS
-- set @DataRicerca = '12/16/04'
-- set @CodiceUtenteSDC = 'RENATOSANNA'
-- set @Issuer = 'CN=NAB_CERT'
-- set @SerialNumber = '5F764B1C73DDDD40B75B6505084EDF80'

-- Nuova versione del 14/01/2004 

select  IdProgrammaXml,
	IdContratto,
	DataStipula,
	CRN,
	DataInizioValidita,
	DataFineValidita,
	Responsabile,
	CodiceOperatoreSDCCedente,
	CodiceOperatoreSDCAcquirente,
	Issuer,
	SerialNumber,
	Bilanciato
from 
(
select distinct
	xpu.IdProgrammaXml,
	pou.IdContratto,
	c.DataStipula,
	c.CRN,
	c.DataInizioValidita,
	c.DataFineValidita,
	c.CodiceOperatoreSDC Responsabile, 
	case pou.ProgrammatoDalCedente
	when 1 then xpu.CodiceUtenteSDC
	else c.CodiceOperatoreSDCCedente end as CodiceOperatoreSDCCedente,
	case pou.ProgrammatoDalCedente
	when 0 then xpu.CodiceUtenteSDC 
	else c.CodiceOperatoreSDCAcquirente end as CodiceOperatoreSDCAcquirente,
	xpu.Issuer, 
	xpu.SerialNumber,
	po.Bilanciato
from 	XMLProgrammiUtenti xpu,
	ProgrammaOrarioPerUnita pou, 
	ProgrammaOrario po,
	(
		select IdContratto, 
			DataStipula, 
			CRN, 
			DataInizioValidita, 
			DataFineValidita,
			CodiceOperatoreSDC, 
			CodiceOperatoreSDCCedente,
			CodiceOperatoreSDCAcquirente
		from contratto
		where 
		DataInizioValidita <= @DataRicerca 
		and DataFineValidita >= @DataRicerca 
		and DataInizioValidita <= @DataRicerca 
		and DataFineValidita >= @DataRicerca
		and StatoContratto = 'Abilitato' 
		and TrCN = 1
		and CodiceOperatoreSDC in 
		(
			select CodiceOperatoreSDC from RelOperatoriUtenti
			where CodiceUtenteSDC = @CodiceUtenteSDC 
		)
		or 
		CodiceOperatoreSDCCedente in 
		(
			select CodiceOperatoreSDC from RelOperatoriUtenti
			where CodiceUtenteSDC = @CodiceUtenteSDC 
		)
		or
		CodiceOperatoreSDCAcquirente in 
		(
			select CodiceOperatoreSDC from RelOperatoriUtenti
			where CodiceUtenteSDC = @CodiceUtenteSDC 
		)
	) c,
	Certificate_List cl
where 
	xpu.CodiceUtenteSDC = @CodiceUtenteSDC and 
	xpu.Issuer = @Issuer and 
	xpu.SerialNumber = @SerialNumber and 
	xpu.IdProgrammaXml = pou.IdProgrammaXml and 
	pou.DataProgramma = @DataRicerca and 
	pou.ProgOrarioDellUnitaValidato = 1 and
	po.IdContratto = pou.IdContratto and
	po.DataProgramma = pou.DataProgramma and
	po.PeriodoRilevante = pou.PeriodoRilevante and
	po.ProgrammaOrarioValidato = 1 and
	c.IdContratto = pou.IdContratto and
	xpu.CodiceUtenteSDC = cl.CodiceUtenteSDC and 
	xpu.Issuer          = cl.Issuer and 
	xpu.SerialNumber    = cl.SerialNumber 
	
) T
order by IdContratto, DataStipula

--select  IdProgrammaXml,
---	IdContratto,
--	DataStipula,
--	CRN,
--	DataInizioValidita,
--	DataFineValidita,
--	Responsabile,
--	CodiceOperatoreSDCCedente,
--	CodiceOperatoreSDCAcquirente,
--	Issuer,
--	SerialNumber,
--	Bilanciato
--from 
--(
--select distinct
--	xpu.IdProgrammaXml,
--	pou.IdContratto,
--	c.DataStipula,
--	c.CRN,
--	c.DataInizioValidita,
--	c.DataFineValidita,
--	c.CodiceOperatoreSDC Responsabile, 
--	case pou.ProgrammatoDalCedente
--	when 1 then xpu.CodiceUtenteSDC
--	else c.CodiceOperatoreSDCCedente end as CodiceOperatoreSDCCedente,
--	case pou.ProgrammatoDalCedente
--	when 0 then xpu.CodiceUtenteSDC 
--	else c.CodiceOperatoreSDCAcquirente end as CodiceOperatoreSDCAcquirente,
--	xpu.Issuer, 
--	xpu.SerialNumber,
--	po.Bilanciato
--	--  pou.DataProgramma,
--	--  pou.PeriodoRilevante,
--	--  pou.CodiceUnitaSDc,
--	--  pou.CategoriaUnitaSDC
--from 	XMLProgrammiUtenti xpu,
--	ProgrammaOrarioPerUnita pou, 
--	ProgrammaOrario po,
--	Contratto c,
--	tab_UnitaContratto(@DataRicerca) uc,
--	Certificate_List cl
--where 
--	xpu.CodiceUtenteSDC = @CodiceUtenteSDC and 
--	xpu.Issuer = @Issuer and 
--	xpu.SerialNumber = @SerialNumber and 
--	xpu.IdProgrammaXml = pou.IdProgrammaXml and 
--	pou.DataProgramma = @DataRicerca and 
--	pou.ProgOrarioDellUnitaValidato = 1 and
--	po.IdContratto = pou.IdContratto and
--	po.DataProgramma = pou.DataProgramma and
--	po.PeriodoRilevante = pou.PeriodoRilevante and
--	po.ProgrammaOrarioValidato = 1 and
--	c.IdContratto = pou.IdContratto and
--	c.StatoContratto = 'Abilitato' and
--	c.TrCN = 1 and
--	pou.IdContratto = uc.IdContratto and 
--	pou.CodiceUnitaSDC = uc.CodiceUnitaSDC and 
--	pou.CategoriaUnitaSDC = uc.CategoriaUnitaSDC and
--	uc.TrCC = 1 and 
--	uc.TrUC = 1 and 
--	uc.UnitaDelContrattoValidata = 1 and 
--	xpu.CodiceUtenteSDC = cl.CodiceUtenteSDC and 
--	xpu.Issuer          = cl.Issuer and 
--	xpu.SerialNumber    = cl.SerialNumber and
--	uc.DataInizioValidita <= @DataRicerca and 
--	uc.DataFineValidita >= @DataRicerca and
--	uc.DataInizioValidita <= @DataRicerca and 
--	uc.DataFineValidita >= @DataRicerca
--) T
--order by IdContratto, DataStipula
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
print 'Aggiornamento Stored Procedure [spGetProgrammiConCertificatoNonValido] concluso.'


print 'Aggiornamento Stored Procedure [ReportSbilanciamentoOrario].'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportSbilanciamentoOrario]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ReportSbilanciamentoOrario]
GO

CREATE PROCEDURE dbo.ReportSbilanciamentoOrario
(
	@DataProgramma datetime
)
AS

-- e' un report che va in POU --> leggo senza aspettare le modifiche dei programmi
set transaction isolation level read uncommitted

--declare 
--@DataProgramma datetime
--set @DataProgramma = '15/12/2004'


--create table #Report1
--(
--IdContratto      integer,
--DataProgramma    smalldatetime,
--PeriodoRilevante tinyint,
--QP float,
--QC float
--)

--insert into #Report1
--	select
--	POU.IdContratto,
--	POU.DataProgramma,
--	POU.PeriodoRilevante,
--	sum(QtyMWh * ProgrammatoDalCedente) QP,
--	sum(QtyMWh * -1 * (ProgrammatoDalCedente - 1)) QC
--	from
--	ProgrammaOrarioPerUnita POU
--	inner join Contratto CO
--	on CO.IdContratto = POU.IdContratto
--	and CO.TrCN = 1
--	and CO.StatoContratto = 'Abilitato'
--	inner join UnitRelate UR
--	on  UR.CodiceUnitaSDC    = POU.CodiceUnitaSDC
--	and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC 
--	and 
--	(
--		(POU.ProgrammatoDalCedente=1 and UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente)
--		or
--		(POU.ProgrammatoDalCedente=0 and UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente)
--	)
--	and UR.TrUC = 1
--	and UR.DataInizioValidita <= @DataProgramma
--	and UR.DataFineValidita   >= @DataProgramma
--	and UR.Abilitata = 1
	
--	where
--	POU.DataProgramma = @DataProgramma
--	and POU.ProgOrarioDellUnitaValidato=1
--	group by POU.DataProgramma, POU.PeriodoRilevante, POU.IdContratto


select 
C.IdContratto,
PO.PeriodoRilevante,
@DataProgramma DataProgramma,
C.CRN,
C.CodiceContratto,
C.CodiceOperatoreSDCCedente Cedente,
C.CodiceOperatoreSDCAcquirente Acquirente,
PO.PeriodoRilevante Ora,
PO.Bilanciato Bilanciato,
PO.SbilanciamentoMWh--,

--R.QP   QtyProdMWh,
--R.QC   QtyConsMWh

from ProgrammaOrario PO
inner join Contratto C
on PO.IdContratto = C.IdContratto
and C.StatoContratto = 'Abilitato'
and C.TrCN = 1
and C.DataInizioValidita <= @DataProgramma and C.DataFineValidita >= @DataProgramma

--inner join #Report1 R
--on  R.IdContratto   = PO.IdContratto
--and R.DataProgramma = PO.DataProgramma
--and R.PeriodoRilevante = PO.PeriodoRilevante

where
PO.DataProgramma = @DataProgramma
and PO.ProgrammaOrarioValidato = 1
and PO.Bilanciato is not null

order by
C.CodiceContratto,
PO.PeriodoRilevante


--drop table #Report1
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ReportSbilanciamentoOrario]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[ReportSbilanciamentoOrario]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[ReportSbilanciamentoOrario]  TO [bil_dbo]
GO



print 'Aggiornamento Stored Procedure [ReportSbilanciamentoOrario] concluso.'

print 'Aggiornamento Stored Procedure [tab_SbilanciamentoProgramma].'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tab_SbilanciamentoProgramma]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[tab_SbilanciamentoProgramma]
GO






CREATE      function tab_SbilanciamentoProgramma(@DataProgramma datetime, @SogliaSbilMWh as float, @CRN as varchar(30))
returns @retSbilanciamentoProgramma table (	
	Operatore  varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	CRN varchar(30) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	CodiceContratto varchar(50) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL,
	Cedente varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	Acquirente varchar(16) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	GestioneTaglio varchar(100) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL ,
	SbilMWhOra01 float,
	SbilMWhOra02 float,
	SbilMWhOra03 float,
	SbilMWhOra04 float,
	SbilMWhOra05 float,
	SbilMWhOra06 float,
	SbilMWhOra07 float,
	SbilMWhOra08 float,
	SbilMWhOra09 float,
	SbilMWhOra10 float,
	SbilMWhOra11 float,
	SbilMWhOra12 float,
	SbilMWhOra13 float,
	SbilMWhOra14 float,
	SbilMWhOra15 float,
	SbilMWhOra16 float,
	SbilMWhOra17 float,
	SbilMWhOra18 float,
	SbilMWhOra19 float,
	SbilMWhOra20 float,
	SbilMWhOra21 float,
	SbilMWhOra22 float,
	SbilMWhOra23 float,
	SbilMWhOra24 float,
	SbilMWhOra25 float)
as

begin
declare	
	@Operatore  varchar(16) ,
	@CodiceContratto varchar(50),
	@Cedente varchar(16) ,
	@Acquirente varchar(16),
	@GestioneTaglio varchar(50),
	@SbilMWhOra01 float,
	@SbilMWhOra02 float,
	@SbilMWhOra03 float,
	@SbilMWhOra04 float,
	@SbilMWhOra05 float,
	@SbilMWhOra06 float,
	@SbilMWhOra07 float,
	@SbilMWhOra08 float,
	@SbilMWhOra09 float,
	@SbilMWhOra10 float,
	@SbilMWhOra11 float,
	@SbilMWhOra12 float,
	@SbilMWhOra13 float,
	@SbilMWhOra14 float,
	@SbilMWhOra15 float,
	@SbilMWhOra16 float,
	@SbilMWhOra17 float,
	@SbilMWhOra18 float,
	@SbilMWhOra19 float,
	@SbilMWhOra20 float,
	@SbilMWhOra21 float,
	@SbilMWhOra22 float,
	@SbilMWhOra23 float,
	@SbilMWhOra24 float,
	@SbilMWhOra25 float


declare	@numore as integer
exec @numore = GetHourNum @DataProgramma

declare
 	@SbilMWhTotOra01 float,
	@SbilMWhTotOra02 float,
	@SbilMWhTotOra03 float,
	@SbilMWhTotOra04 float,
	@SbilMWhTotOra05 float,
	@SbilMWhTotOra06 float,
	@SbilMWhTotOra07 float,
	@SbilMWhTotOra08 float,
	@SbilMWhTotOra09 float,
	@SbilMWhTotOra10 float,
	@SbilMWhTotOra11 float,
	@SbilMWhTotOra12 float,
	@SbilMWhTotOra13 float,
	@SbilMWhTotOra14 float,
	@SbilMWhTotOra15 float,
	@SbilMWhTotOra16 float,
	@SbilMWhTotOra17 float,
	@SbilMWhTotOra18 float,
	@SbilMWhTotOra19 float,
	@SbilMWhTotOra20 float,
	@SbilMWhTotOra21 float,
	@SbilMWhTotOra22 float,
	@SbilMWhTotOra23 float,
	@SbilMWhTotOra24 float,
	@SbilMWhTotOra25 float

 	set @SbilMWhTotOra01 = 0.0
	set @SbilMWhTotOra02 = 0.0
	set @SbilMWhTotOra03 = 0.0
	set @SbilMWhTotOra04 = 0.0
	set @SbilMWhTotOra05 = 0.0
	set @SbilMWhTotOra06 = 0.0
	set @SbilMWhTotOra07 = 0.0
	set @SbilMWhTotOra08 = 0.0
	set @SbilMWhTotOra09 = 0.0
	set @SbilMWhTotOra10 = 0.0
	set @SbilMWhTotOra11 = 0.0
	set @SbilMWhTotOra12 = 0.0
	set @SbilMWhTotOra13 = 0.0
	set @SbilMWhTotOra14 = 0.0
	set @SbilMWhTotOra15 = 0.0
	set @SbilMWhTotOra16 = 0.0
	set @SbilMWhTotOra17 = 0.0
	set @SbilMWhTotOra18 = 0.0
	set @SbilMWhTotOra19 = 0.0
	set @SbilMWhTotOra20 = 0.0
	set @SbilMWhTotOra21 = 0.0
	set @SbilMWhTotOra22 = 0.0
	set @SbilMWhTotOra23 = 0.0
	set @SbilMWhTotOra24 = 0.0
	set @SbilMWhTotOra25 = 0.0


declare @IdContratto as int

select @IdContratto = IdContratto 
from Contratto 
where CRN = @CRN

declare p_cursor cursor for
select --@DataProgramma DataProgramma,
C.CodiceOperatoreSDC Operatore, 
C.CodiceContratto,
C.CodiceOperatoreSDCCedente Cedente,
C.CodiceOperatoreSDCAcquirente Acquirente,
case (C.GestioneTaglio) 
	when 'T' then 'Sempre'
	when 'C' then 'se cons. supera prod.'
	when 'P' then 'se prod. supera cons.'
	when 'M' then 'Mai'
end 
GestioneTaglio,
case Q.PeriodoRilevante when  1 then Q.BilMWh else 0 end SbilMWhOra01,
case Q.PeriodoRilevante when  2 then Q.BilMWh else 0 end SbilMWhOra02,
case Q.PeriodoRilevante when  3 then Q.BilMWh else 0 end SbilMWhOra03,
case Q.PeriodoRilevante when  4 then Q.BilMWh else 0 end SbilMWhOra04,
case Q.PeriodoRilevante when  5 then Q.BilMWh else 0 end SbilMWhOra05,
case Q.PeriodoRilevante when  6 then Q.BilMWh else 0 end SbilMWhOra06,
case Q.PeriodoRilevante when  7 then Q.BilMWh else 0 end SbilMWhOra07,
case Q.PeriodoRilevante when  8 then Q.BilMWh else 0 end SbilMWhOra08,
case Q.PeriodoRilevante when  9 then Q.BilMWh else 0 end SbilMWhOra09,
case Q.PeriodoRilevante when 10 then Q.BilMWh else 0 end SbilMWhOra10,
case Q.PeriodoRilevante when 11 then Q.BilMWh else 0 end SbilMWhOra11,
case Q.PeriodoRilevante when 12 then Q.BilMWh else 0 end SbilMWhOra12,
case Q.PeriodoRilevante when 13 then Q.BilMWh else 0 end SbilMWhOra13,
case Q.PeriodoRilevante when 14 then Q.BilMWh else 0 end SbilMWhOra14,
case Q.PeriodoRilevante when 15 then Q.BilMWh else 0 end SbilMWhOra15,
case Q.PeriodoRilevante when 16 then Q.BilMWh else 0 end SbilMWhOra16,
case Q.PeriodoRilevante when 17 then Q.BilMWh else 0 end SbilMWhOra17,
case Q.PeriodoRilevante when 18 then Q.BilMWh else 0 end SbilMWhOra18,
case Q.PeriodoRilevante when 19 then Q.BilMWh else 0 end SbilMWhOra19,
case Q.PeriodoRilevante when 20 then Q.BilMWh else 0 end SbilMWhOra20,
case Q.PeriodoRilevante when 21 then Q.BilMWh else 0 end SbilMWhOra21,
case Q.PeriodoRilevante when 22 then Q.BilMWh else 0 end SbilMWhOra22,
case Q.PeriodoRilevante when 23 then Q.BilMWh else 0 end SbilMWhOra23,
case Q.PeriodoRilevante when 24 then Q.BilMWh else 0 end SbilMWhOra24,
case Q.PeriodoRilevante when 25 then Q.BilMWh else 0 end SbilMWhOra25
from ProgrammaOrario PO 
inner join Contratto C
on PO.IdContratto = C.IdContratto
inner join
(



	select 
	POU.IdContratto, 
	@DataProgramma DataProgramma, 
	POU.PeriodoRilevante,
	case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then 0                                        else 1 end Bilanciato,
	case when Abs(Sum(Round(POU.QtyMWh * UC.KP / UC.KU, 3))) > round(@SogliaSbilMWh,3) then round(Sum(round(POU.QtyMWh * UC.KP / UC.KU,3)), 3) else 0 end BilMWh
	from 
	(


		-- trovo tutte le unita per contratto valide 
		-- (TrCC e TrUC garantiscono che il contratto sia valido, le unita valide, gli operatori validi)
-- --		select 
-- --		UnitaContratto.IdContratto, 
-- --		UnitaContratto.CodiceUnitaSDC, 
-- --		UnitaContratto.CategoriaUnitaSDC,
-- --		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
-- --		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
-- --		from 
-- --		tab_UnitaContratto(@DataProgramma) UnitaContratto, 
-- --		SDC_Unita, SDC_PuntiDiScambioRilevanti,
-- --		Contratto
-- --		where 
-- --		Contratto.IdContratto = UnitaContratto.IdContratto
-- --		and Contratto.DataInizioValidita <= @DataProgramma
-- --		and Contratto.DataFineValidita >= @DataProgramma
-- --		and UnitaContratto.TrCC=1 
-- --		and UnitaContratto.TrUC=1
-- --		and UnitaContratto.UnitaDelContrattoValidata=1
-- --		and UnitaContratto.DataInizioValidita <= @DataProgramma
-- --		and UnitaContratto.DataFineValidita >= @DataProgramma
-- --		and UnitaContratto.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
-- --		and UnitaContratto.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
-- --		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
-- --		and CRN = @CRN
		
		select 
		u.IdContratto,
		u.CodiceUnitaSDC, 
		u.CategoriaUnitaSDC, 
		u.TrCC,
		u.TrUC,
		u.VUC,
		u.KU,
		u.KP,
		sum(u.UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,
		sum(u.UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente
		from 
		(

			select 
			c.IdContratto,
			ur.CodiceUnitaSDC, 
			ur.CategoriaUnitaSDC, 
			ur.TrUC, 
			ur.VUC,
			1 UnitaAssegnataOpCedente, 
			0 UnitaAssegnataOpAcquirente,
			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC,
			su.CoefficientePerdita KU,
			sp.CoefficienteDiPerdita KP
			from unitrelate ur
			inner join 
			contratto c
			on
			c.IdContratto = @IdContratto
			and c.DataInizioValidita <= @DataProgramma and c.DataFineValidita >= @DataProgramma
			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente and ur.TipoUnita in ('P', 'M')
			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
			and ur.Abilitata = 1
			inner join SDC_Unita su
			on su.CodiceUnitaSDC = ur.CodiceUnitaSDC
			and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
			inner join SDC_PuntiDiScambioRilevanti sp
			on su.CodicePuntoDiScambioRilevanteSDC = sp.CodicePuntoDiScambioRilevanteSDC
		union
			select 
			c.IdContratto,
			ur.CodiceUnitaSDC, 
			ur.CategoriaUnitaSDC, 
			ur.TrUC, 
			ur.VUC,
			0 UnitaAssegnataOpCedente, 
			1 UnitaAssegnataOpAcquirente,
			c.TrCN & (case c.StatoContratto  when  'Abilitato' then 1 else 0 end) TrCC,
			su.CoefficientePerdita KU,
			sp.CoefficienteDiPerdita KP
			from unitrelate ur
			inner join 
			contratto c
			on c.DataInizioValidita <= @DataProgramma and c.DataFineValidita >= @DataProgramma
			and CRN = @CRN
			and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente and ur.TipoUnita in ('C', 'M')
			and (ur.DataInizioValidita <= c.DataFineValidita and ur.DataFineValidita >= c.DataInizioValidita)
			and ur.Abilitata = 1
			inner join SDC_Unita su
			on su.CodiceUnitaSDC = ur.CodiceUnitaSDC
			and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
			inner join SDC_PuntiDiScambioRilevanti sp
			on su.CodicePuntoDiScambioRilevanteSDC = sp.CodicePuntoDiScambioRilevanteSDC
		) u
		group by IdContratto,
		CodiceUnitaSDC, 
		CategoriaUnitaSDC,
		TrUC,
		VUC,
		TrCC,
		KU,
		KP
 	) UC
	inner join
	(
		-- considero i POU validi del giorno
		SELECT 
		ProgrammaOrarioPerUnita.IdContratto, 
		ProgrammaOrarioPerUnita.DataProgramma, 
		ProgrammaOrarioPerUnita.PeriodoRilevante, 
		ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
		ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
		ProgrammaOrarioPerUnita.QtyMWh
		FROM 
		ProgrammaOrarioPerUnita, 
		ProgrammaOrario,
		Contratto 
		where 
		ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
		and ProgrammaOrario.DataProgramma=@DataProgramma
		and ProgrammaOrario.PeriodoRilevante <= 25
		and Contratto.IdContratto = @IdContratto
		and Contratto.IdContratto = ProgrammaOrario.IdContratto
		and ProgrammaOrario.ProgrammaOrarioValidato=1
		and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
		and ProgrammaOrarioPerUnita.IdContratto=ProgrammaOrario.IdContratto
		and ProgrammaOrarioPerUnita.DataProgramma=ProgrammaOrario.DataProgramma
		and ProgrammaOrarioPerUnita.PeriodoRilevante <= 25
		and ProgrammaOrarioPerUnita.PeriodoRilevante=ProgrammaOrario.PeriodoRilevante
	) POU
	ON  POU.IdContratto = UC.IdContratto
	AND POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
	AND POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
	GROUP BY POU.IdContratto, POU.DataProgramma, POU.PeriodoRilevante


) Q
on 
PO.IdContratto = Q.IdContratto
and PO.DataProgramma = Q.DataProgramma
and PO.PeriodoRilevante = Q.PeriodoRilevante
--order by C.CRN

open p_cursor
		-- Perform the first fetch.
fetch next from p_cursor into
		@Operatore,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25

	

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	while @@FETCH_STATUS = 0
	begin

		set @SbilMWhTotOra01 = @SbilMWhTotOra01 + @SbilMWhOra01
		set @SbilMWhTotOra02 = @SbilMWhTotOra02 + @SbilMWhOra02

		set @SbilMWhTotOra03 = @SbilMWhTotOra03 + @SbilMWhOra03
		set @SbilMWhTotOra04 = @SbilMWhTotOra04 + @SbilMWhOra04
		set @SbilMWhTotOra05 = @SbilMWhTotOra05 + @SbilMWhOra05
		set @SbilMWhTotOra06 = @SbilMWhTotOra06 + @SbilMWhOra06
		set @SbilMWhTotOra07 = @SbilMWhTotOra07 + @SbilMWhOra07
		set @SbilMWhTotOra08 = @SbilMWhTotOra08 + @SbilMWhOra08
		set @SbilMWhTotOra09 = @SbilMWhTotOra09 + @SbilMWhOra09
		set @SbilMWhTotOra10 = @SbilMWhTotOra10 + @SbilMWhOra10
		set @SbilMWhTotOra11 = @SbilMWhTotOra11 + @SbilMWhOra11
		set @SbilMWhTotOra12 = @SbilMWhTotOra12 + @SbilMWhOra12
		set @SbilMWhTotOra13 = @SbilMWhTotOra13 + @SbilMWhOra13
		set @SbilMWhTotOra14 = @SbilMWhTotOra14 + @SbilMWhOra14
		set @SbilMWhTotOra15 = @SbilMWhTotOra15 + @SbilMWhOra15
		set @SbilMWhTotOra16 = @SbilMWhTotOra16 + @SbilMWhOra16
		set @SbilMWhTotOra17 = @SbilMWhTotOra17 + @SbilMWhOra17
		set @SbilMWhTotOra18 = @SbilMWhTotOra18 + @SbilMWhOra18
		set @SbilMWhTotOra19 = @SbilMWhTotOra19 + @SbilMWhOra19
		set @SbilMWhTotOra20 = @SbilMWhTotOra20 + @SbilMWhOra20
		set @SbilMWhTotOra21 = @SbilMWhTotOra21 + @SbilMWhOra21
		set @SbilMWhTotOra22 = @SbilMWhTotOra22 + @SbilMWhOra22
		set @SbilMWhTotOra23 = @SbilMWhTotOra23 + @SbilMWhOra23
		set @SbilMWhTotOra24 = @SbilMWhTotOra24 + @SbilMWhOra24
		set @SbilMWhTotOra25 = @SbilMWhTotOra25 + @SbilMWhOra25
		
	-- Copy to the result of the function the required columns.
	insert @retSbilanciamentoProgramma values(
		@Operatore,
		@CRN,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25)
	   -- This is executed as long as the previous fetch succeeds.
	  fetch next from p_cursor into
		@Operatore,
		@CodiceContratto,
		@Cedente,
		@Acquirente ,
		@GestioneTaglio ,
		@SbilMWhOra01,
		@SbilMWhOra02,
		@SbilMWhOra03,
		@SbilMWhOra04,
		@SbilMWhOra05,
		@SbilMWhOra06,
		@SbilMWhOra07,
		@SbilMWhOra08,
		@SbilMWhOra09,
		@SbilMWhOra10,
		@SbilMWhOra11,
		@SbilMWhOra12,
		@SbilMWhOra13,
		@SbilMWhOra14,
		@SbilMWhOra15,
		@SbilMWhOra16,
		@SbilMWhOra17,
		@SbilMWhOra18,
		@SbilMWhOra19,
		@SbilMWhOra20,
		@SbilMWhOra21,
		@SbilMWhOra22,
		@SbilMWhOra23,
		@SbilMWhOra24,
		@SbilMWhOra25

	end
	close p_cursor
	deallocate p_cursor



	-- Copy to the result of the function the required columns.
	insert @retSbilanciamentoProgramma values(
		'',
		'',
		'', --convert(varchar, @DataProgramma, 105),
		'',
		'',
		'Totale Orario' ,
		@SbilMWhTotOra01,
		@SbilMWhTotOra02,
		@SbilMWhTotOra03,
		@SbilMWhTotOra04,
		@SbilMWhTotOra05,
		@SbilMWhTotOra06,
		@SbilMWhTotOra07,
		@SbilMWhTotOra08,
		@SbilMWhTotOra09,
		@SbilMWhTotOra10,
		@SbilMWhTotOra11,
		@SbilMWhTotOra12,
		@SbilMWhTotOra13,
		@SbilMWhTotOra14,
		@SbilMWhTotOra15,
		@SbilMWhTotOra16,
		@SbilMWhTotOra17,
		@SbilMWhTotOra18,
		@SbilMWhTotOra19,
		@SbilMWhTotOra20,
		@SbilMWhTotOra21,
		@SbilMWhTotOra22,
		@SbilMWhTotOra23,
		@SbilMWhTotOra24,
		@SbilMWhTotOra25)
return
	
end















GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  SELECT  ON [dbo].[tab_SbilanciamentoProgramma]  TO [public]
GO

GRANT  SELECT  ON [dbo].[tab_SbilanciamentoProgramma]  TO [bil_user]
GO

GRANT  SELECT  ON [dbo].[tab_SbilanciamentoProgramma]  TO [bil_dbo]
GO




print 'Aggiornamento Stored Procedure [tab_SbilanciamentoProgramma] concluso.'


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spBilanciamentoForzatoPerOra]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spBilanciamentoForzatoPerOra]
GO

CREATE PROCEDURE [dbo].[spBilanciamentoForzatoPerOra]
 	@DataProgramma smalldatetime,
 	@SogliaSbilMWh float,
	@Ora tinyint,
	@UltimoBilanciamento bit
AS

declare @AzzeraSbilanciamento   bit
declare @RicalcolaBilanciamento bit
set @AzzeraSbilanciamento = 1
set @RicalcolaBilanciamento = 1


-- stored procedure che calcola e memorizza il bilanciamento
-- dei programmi di un dato giorno

-- declare @DataProgramma          smalldatetime
-- declare @SogliaSbilMWh          float
-- declare @AzzeraSbilanciamento   bit
-- declare @RicalcolaBilanciamento bit
-- 
-- set @DataProgramma = '17/9/2004'
-- set @SogliaSbilMWh = 0.001
-- set @AzzeraSbilanciamento = 1
-- set @RicalcolaBilanciamento = 1

-- Nuova delibera
-- sto facendo il bilanciamento forzato.
-- congelo lo stato di GestioneTaglio, IsGMEOp
-- nella tabella PO in modo da avere la "storia" delle scelte effettuate in questa sp.
-- Lo faccio prima del loop con il cursore in quanto
-- devo congelare lo stato di GestioneTaglio, IsGMEOp
-- a prescindere se faccio il taglio forzato o no
--
-- NOTARE che
-- il bilanciamento forzato opera sui programmi con Bilanciato=0
-- nel rispetto dei criteri di flessibilita`: (T P C M opGME)
-- se il bilanciamento forzato non viene effettuato (il contratto es ammette pgm sbilanciati)
-- il campo Bilancito rimane ad 0
-- Dato che prima di iniziare il taglio viene chiamata
-- exec spCalcolaBilanciamento @DataProgramma, @SogliaSbilMWh
-- siamo sicuri che se Bilanciato e`
-- null: il programma NON deve andare a mercato
-- 1: il programma e' bilanciato all'origine
-- 0: il programma non e' bilanciato all'origine
-- Dopo il taglio che porta i programmi con Bilanciato=0 a Bilanciato=1
-- (se questi non hanno la flessibilita` di essere sbilanciati)
-- avremo un po' di programmi con bilanciato=1 e un po' con bilanciato=1
-- ENTRAMBI devono andare a mercato, ossia le offerte devono solo controllare bilanciato<>null

update ProgrammaOrario
set
GestioneTaglio = Q.GestioneTaglio,
IsGMEOp        = Q.IsGMEOp
from ProgrammaOrario PO
inner join
(
	select
	Contratto.IdContratto        IdContratto,
	Contratto.GestioneTaglio     GestioneTaglio,
	IsNull(Operatori.IsGMEOp, 0) IsGMEOp
	from Contratto
	inner join Operatori
	on Contratto.CodiceOperatoreSDCAcquirente = Operatori.CodiceOperatoreSDC
) Q
on 
PO.IdContratto = Q.IdContratto
where 
    DataProgramma = @DataProgramma
and PeriodoRilevante = @Ora
-- fine nuova delibera

-------------------------------------------------------------------------
-------------------------------------------------------------------------



declare @IdContratto Int
declare @PeriodoRilevante TinyInt
declare @CodiceUnitaSDC varchar(16)
declare @CategoriaUnitaSDC varchar(1)
declare @SbilanciamentoMWh float
declare @QtyMWh float
declare @KU float
declare @KP float
declare @QTogliere float

-- per non sbagliare metto a 3 cifre la soglia di sbilanciamento
set @SogliaSbilMWh = round(@SogliaSbilMWh, 3)

-- aggiorno tutti i record di PO
-- per la data in questione.
-- In PO.Bilanciato si ha NULL se quella programmazione, per qualche motivo, non deve essere bilanciata
-- Bilanciato = 1 o Bilanciato = 0
exec spCalcolaBilanciamentoPerOra @DataProgramma, @SogliaSbilMWh, @Ora, @UltimoBilanciamento

declare po_cursor cursor local for
	select 
	IdContratto, 
	PeriodoRilevante, 
	SbilanciamentoMWh 
	from 
	ProgrammaOrario
	where 
	Dataprogramma = @DataProgramma 
	and PeriodoRilevante = @Ora
	and Bilanciato = 0 -- Notare che qui cerco solo i programmi non Bilanciati,
	-- dunque, quando ricerco i record in POU, non devo fare ulteriormente
	-- la join in PO per trovare se il record in e` PO.ProgrammaOrarioValidato
	-- (comunque per sicurezza lo sia fa)

open po_cursor
fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
while @@fetch_status = 0 
begin
	-- print 'IdContratto:' + cast(@IdContratto as varchar) + ' PeriodoRil.:' + str(@PeriodoRilevante)  + ' SbilMWh=' + str(@SbilanciamentoMWh)

	if @AzzeraSbilanciamento = 0
	begin
		-- ATTENZIONE: decurto lo SbilanciamentoMWh della soglia 
		-- (per Produzione tolgo, per Consumo aggiungo)
		-- in modo da ottenere un contratto bilanciato con sbilancio uguale a @SogliaSbilMWh
		-- E` OPINABILE
		if @SbilanciamentoMWh > 0
			set	@SbilanciamentoMWh = @SbilanciamentoMWh - @SogliaSbilMWh
		else
			set	@SbilanciamentoMWh = @SbilanciamentoMWh + @SogliaSbilMWh
	end

	-- print ' SbilMWh(new)=' + str(@SbilanciamentoMWh)
	-- qui trovo la lista delle unita` da decurtare.
	-- L'ordine della select indica di decurtare partendo dall'invio
	-- di programma piu` recente e, a parita` di file, del progressivo piu` grande
 	declare pou_cursor cursor local keyset for

 		select 
		POU.CodiceUnitaSDC, 
		POU.CategoriaUnitaSDC, 
		POU.QtyMWh,
		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
		from 
		ProgrammaOrarioPerUnita POU

		inner join ProgrammaOrario PO
		on  PO.IdContratto = POU.IdContratto
		and PO.DataProgramma = POU.DataProgramma
		and PO.PeriodoRilevante = POU.PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1

		inner join SDC_Unita
		on  POU.CodiceUnitaSDC    = SDC_Unita.CodiceUnitaSDC
		and POU.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC

 		inner join SDC_PuntiDiScambioRilevanti
		on SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC

		inner join Contratto
		on  Contratto.IdContratto = POU.IdContratto
		and Contratto.StatoContratto = 'Abilitato'
		and Contratto.TrCN = 1 -- dipende dagli stati degli operatori tit/acq/ced
		and Contratto.DataInizioValidita <= @DataProgramma
		and Contratto.DataFineValidita   >= @DataProgramma
		-- Nuova delibera
		-- gli operatori acquirenti devono essere op gme per sopportare pgm sbilanciati
		inner join Operatori OPAcq
		on Contratto.CodiceOperatoreSDCAcquirente = OPAcq.CodiceOperatoreSDC
		and 
		(
			-- tagliare solo se:
			Contratto.GestioneTaglio = 'T' -- il taglio e` da fare sempre
			or 
			( Contratto.GestioneTaglio = 'P' and @SbilanciamentoMWh > 0 ) -- solo se Prod>Cons
			or 
			( Contratto.GestioneTaglio = 'C' and @SbilanciamentoMWh < 0 ) -- solo se Cons>Prod
			or
			( OPAcq.IsGMEOp = 0 or OPAcq.IsGMEOp is null ) -- se l'op non e` del GME
		)
		-- Fine nuova delibera

		inner join UnitRelate
		on 
		(
			(UnitRelate.CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCCedente    and POU.ProgrammatoDalCedente=1)
			or
			(UnitRelate.CodiceOperatoreSDC = Contratto.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
		)
		and UnitRelate.CodiceUnitaSDC    = POU.CodiceUnitaSDC
		and UnitRelate.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and UnitRelate.Abilitata = 1  -- non cancellato logicamente
 		and UnitRelate.TrUC = 1       -- dipende SOLO da Unita.StatoBilateraliUnita
		and UnitRelate.DataInizioValidita <= @DataProgramma
		and UnitRelate.DataFineValidita   >= @DataProgramma


		where 
		    POU.DataProgramma    = @DataProgramma 
		and POU.IdContratto      = @IdContratto
		and POU.PeriodoRilevante = @PeriodoRilevante
		and POU.ProgOrarioDellUnitaValidato = 1
		and sign(POU.QtyMWh) = sign(@SbilanciamentoMWh) -- le unita che causano lo sbilanciamento

		order by 
		POU.IdProgrammaXml desc,
		POU.ProgressivoNelProgramma desc

 	open pou_cursor
 	fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP

 	while @@fetch_status = 0
 	begin
		set @Qtogliere = round(@SbilanciamentoMWh * @KU / @KP, 3)

		-- ora questa quantita` puo` essere superiore in valore assoluto alla quantita'
		-- dell'unita --> posso azzerare l'unita corrente
		-- per poi riprovarci alla prossima
		If Abs(@Qtogliere) > Abs(@QtyMWh)
		begin
			-- posso togliere solo in parte lo sbilanciamento
			-- togliendo tutta la produzione dell'unita
			set @Qtogliere = @QtyMWh				   -- tolgo tutta la quantita disponibile
			set @SbilanciamentoMWh = @SbilanciamentoMWh - round(@Qtogliere * @KP / @KU, 3)
		end
 		else
		begin
 			-- qui ho tolto tutto lo sbilanciamento (per definizione)
 			set @SbilanciamentoMWh = 0
 		end 

		-- print 'Nuova Qty = ' + str(@QtyMWh - @Qtogliere)

		update 
		ProgrammaOrarioPerUnita
		set QtyMWhBilanciamento = @QtyMWh - @Qtogliere
		where current of pou_cursor

		-- esco se ho raggiunto la soglia di sbilanciamento max

		-- notare che:
		-- un contratto prima del calcolo del bilanciamento ha Bilanciato=NULL e SbilanciamentoMWh=NULL
		-- un contratto dopo il calcolo del bilanciamento se bilanciato in origine ha Bilanciato=1 e SbilanciamentoMWh=0
		-- un contratto non bilanciato in origine e prima dell'operazione di taglio ha Bilanciato=0 e SbilanciamentoMWh<>0
		-- un contratto non bilanciato in origine e dopo l'operazione di taglio ha Bilanciato=1 e SbilanciamentoMWh<>0
		-- un contratto che dopo ogni fase ha PO.Bilanciato=NULL indica che non e` valido.
		If Abs(@SbilanciamentoMWh) <= @SogliaSbilMWh
		begin
			-- print 'Esco'
 			update ProgrammaOrario
 			set bilanciato = 1
 			where 
			IdContratto = @IdContratto
 			and DataProgramma = @DataProgramma
			and PeriodoRilevante = @PeriodoRilevante
			break
		end

 		fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP
 	end
 	
 	close pou_cursor
 	deallocate pou_cursor

	fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
end

close po_cursor
deallocate po_cursor


if @UltimoBilanciamento = 1
begin
	update 
	SessioneBilaterali
	set
	Taglio=1
	where DataProgramma=@DataProgramma
end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spBilanciamentoForzatoPerOra]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spBilanciamentoForzatoPerOra]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spBilanciamentoForzatoPerOra]  TO [bil_dbo]
GO



SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spCalcolaBilanciamentoPerContratto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spCalcolaBilanciamentoPerContratto]
GO



CREATE  PROCEDURE dbo.spCalcolaBilanciamentoPerContratto
	(
		@IdContratto int,
		@DataProgramma smalldatetime,
		@PeriodoRilevante tinyint,
	 	@SogliaSbilMWh float
	)

AS
-- non si usa read uncommitted in quanto
-- il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


	SET NOCOUNT ON
	
	select 
	IsNull(Sum(round(POU.QtyMWh * UC.KP / UC.KU, 3)), 0) SBilMWh
	from 
	(
		-- trovo tutte le unita per contratto valide 
		-- ossia quelle da programmare per la data in ingresso
		-- (TrCC e TrUC garantiscono che il contratto sia valido, le unita valide, gli operatori validi)
		select 
		UnitaContratto.CodiceUnitaSDC, 
		UnitaContratto.CategoriaUnitaSDC,
		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
		from 
		tab_UnitaContratto2(@DataProgramma, @IdContratto) UnitaContratto, 
		SDC_Unita, 
		SDC_PuntiDiScambioRilevanti,
		Contratto
		where 
		    UnitaContratto.IdContratto = @IdContratto
		and UnitaContratto.IdContratto = Contratto.IdContratto
		and Contratto.DataInizioValidita <= @DataProgramma
		and Contratto.DataFineValidita >= @DataProgramma
		and UnitaContratto.TrCC=1 
		and UnitaContratto.TrUC=1
		and UnitaContratto.UnitaDelContrattoValidata=1
		and UnitaContratto.DataInizioValidita <= @DataProgramma
		and UnitaContratto.DataFineValidita >= @DataProgramma
		and UnitaContratto.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
		and UnitaContratto.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
	) UC
	inner join
	(
		-- considero i POU validi del giorno per il contratto
		
		SELECT 
			POUI.CodiceUnitaSDC, 
			POUI.CategoriaUnitaSDC, 
			POUI.QtyMWh,
			POUI.IdContratto
		FROM
			(
				SELECT
					ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
					ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
					ProgrammaOrarioPerUnita.QtyMWh,
					ProgrammaOrarioPerUnita.IdContratto,
					ProgrammaOrarioPerUnita.DataProgramma,
					ProgrammaOrarioPerUnita.PeriodoRilevante
				FROM
					ProgrammaOrarioPerUnita
				WHERE
					ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
					and ProgrammaOrarioPerUnita.PeriodoRilevante=@PeriodoRilevante
					and ProgrammaOrarioPerUnita.IdContratto = @IdContratto
					and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
			) POUI
			INNER JOIN
			(
				SELECT 
					ProgrammaOrario.IdContratto,
					ProgrammaOrario.DataProgramma,
					ProgrammaOrario.PeriodoRilevante
				FROM ProgrammaOrario
				WHERE
						ProgrammaOrario.DataProgramma=@DataProgramma
						and ProgrammaOrario.PeriodoRilevante=@PeriodoRilevante
						and ProgrammaOrario.IdContratto= @IdContratto
						and ProgrammaOrario.ProgrammaOrarioValidato=1
			) POI
			ON
				POUI.IdContratto = POI.IdContratto 
				AND POUI.DataProgramma = POI.DataProgramma
				AND POUI.PeriodoRilevante = POI.PeriodoRilevante
	) POU
	ON
	    POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
	and POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerContratto]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerContratto]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerContratto]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spCalcolaBilanciamentoPerOra]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spCalcolaBilanciamentoPerOra]
GO

CREATE PROCEDURE [dbo].[spCalcolaBilanciamentoPerOra]
	@DataProgramma smalldatetime,
	@SogliaSbilMWh float,
	@Ora tinyint,
	@UltimoBilanciamento bit
AS

-- non si usa read uncommitted in quanto il bilanciamento 
-- viene lanciato dentro un batch (i dati quindi non cambiamo)
-- e comunque il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@DataProgramma smalldatetime,
-- 	@SogliaSbilMWh float,
--	@Ora tinyint
-- 
-- set @DataProgramma = '24/11/2004'
-- set @SogliaSbilMWh = 0.001
-- set @Ora = 1
-- 
-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno
-- (tutti i programmi !! )

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.
-- POU.QtyMWhBilanciamento=null per tutti i programmi.

-- inizializzo i campi per la data
update ProgrammaOrario
set 
Bilanciato=null,
SbilanciamentoMWh=null,
SbilanciamentoMWhReale=null,
TSCalcoloBilanciamento=null
where 
    DataProgramma = @DataProgramma
and PeriodoRilevante = @Ora

-- siccome calcolo il bilanciamento i dati del bilanciamento forzato devono essere resettati
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where 
    DataProgramma = @DataProgramma
and PeriodoRilevante = @Ora
and not QtyMWhBilanciamento is null


-- qui indico che il bilanciamento per tutti i contratti e` stato fatto
-- e` da fare il taglio

if @UltimoBilanciamento = 1
begin
	update 
	SessioneBilaterali
	set
	Bilanciamento=1,
	Taglio=0
	where DataProgramma=@DataProgramma
end



declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()


update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,
	
	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then 0 else 1 end Bilanciato,
	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on  PO.Idcontratto = POU.IdContratto
		and PO.DataProgramma = POU.DataProgramma
		and PO.PeriodoRilevante = POU.PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on  CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on  UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

		where
		POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
		and POU.PeriodoRilevante = @Ora
	) Q
	group by IdContratto, PeriodoRilevante
) W
on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerOra]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerOra]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spCalcolaBilanciamentoPerOra]  TO [bil_dbo]
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetNC]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetNC]
GO




CREATE   PROCEDURE [dbo].[spGetNC] 
  	@DataProgramma smalldatetime
AS

set transaction isolation level read uncommitted

-- declare @DataProgramma smalldatetime
-- set @DataProgramma = '26/11/2004'

declare @oraMax as int
-- ottengo il numero di ore del giorno
exec @oraMax=GetHourNum @DataProgramma


select
NC.Ora                       PeriodoRilevante,
NC.NC                        NC,
IsNull(NP.NP,0)              NCP,
NC.NC - IsNull(NP.NP,0)      NCD

from
(
	select 
	Ore.Ora,
	Q.NC
	from Ore
	cross join
	(
		select 
		count(*) NC
		from Contratto
		where
		Contratto.StatoContratto='Abilitato'
		and Contratto.DataInizioValidita <= @DataProgramma
		and Contratto.DataFineValidita >= @DataProgramma
		and Contratto.TrCN = 1
	) Q
	where
	Ora <= @oraMax
) NC
left outer join
(
	select
	PeriodoRilevante,
	count(*) NP
	from ProgrammaOrario PO
	inner join Contratto CO
	on CO.IdContratto = PO.IdContratto
	and CO.StatoContratto='Abilitato'
	and CO.DataInizioValidita <= @DataProgramma
	and CO.DataFineValidita >= @DataProgramma
	and CO.TrCN = 1
	where
	PO.DataProgramma=@DataProgramma
    and PO.ProgrammaOrarioValidato = 1
	group by
	PeriodoRilevante
) NP
on NC.Ora = NP.PeriodoRilevante

order by NC.Ora asc

-- 
-- 
-- 
-- 
-- select timetable.Ora PeriodoRilevante, 
-- isnull(counters.NC, 0) NC, 
-- isnull(counters.NCP, 0) NCP,
-- isnull(counters.NCD, 0) NCD
-- from 
-- (
-- 	select Ora from Ore
-- 	where Ora <= @oraMax
-- ) timetable
-- left outer join
-- (
-- select PeriodoRilevante, count(IdContratto) NC, sum(Pgm) NCP, count(IdContratto)  - sum(Pgm)  NCD
-- from 
-- (
-- select IdContratto, PeriodoRilevante, 1 Pgm
--   from ProgrammaOrario
--   where DataProgramma = @DataProgramma
--     --and ProgrammaOrarioValidato = 1
--     and exists (select * from tab_UnitaContratto(@DataProgramma) UnitaContratto 
-- 		where UnitaContratto.IdContratto = IdContratto 
-- 			and UnitaContratto.UnitaDelContrattoValidata = 1
-- 			and UnitaContratto.TrCC = 1
-- 			and UnitaContratto.TrUC = 1
-- 			and UnitaContratto.DataInizioValidita <= @DataProgramma and DataFineValidita >= @DataProgramma)
-- union all
--  select IdContratto, Ora PeriodoRilevante, 0 Pgm
--   from Contratto, Ore
--  where DataInizioValidita <= @DataProgramma and DataFineValidita >= @DataProgramma
--   and TrCN = 1 
--   and StatoContratto = 'Abilitato'
--   and Ora <= @oraMax
--   and not exists (select IdContratto, PeriodoRilevante
--    from ProgrammaOrario
--    where DataProgramma = @DataProgramma 
-- 	and PeriodoRilevante = Ore.Ora 
-- 	and IdContratto = Contratto.IdContratto 
-- 	--and ProgrammaOrarioValidato = 1
-- 	and exists (select * from tab_UnitaContratto(@DataProgramma) UnitaContratto 
-- 		where UnitaContratto.IdContratto = IdContratto 
-- 			and UnitaContratto.UnitaDelContrattoValidata = 1
-- 			and UnitaContratto.TrCC = 1
-- 			and UnitaContratto.TrUC = 1
-- 			and UnitaContratto.DataInizioValidita <= @DataProgramma and DataFineValidita >= @DataProgramma)
-- )
--   and exists (select * from tab_UnitaContratto(@DataProgramma) UnitaContratto 
-- 		where UnitaContratto.IdContratto = IdContratto 
-- 			and UnitaContratto.UnitaDelContrattoValidata = 1
-- 			and UnitaContratto.TrCC = 1
-- 			and UnitaContratto.TrUC = 1
-- 			and UnitaContratto.DataInizioValidita <= @DataProgramma and DataFineValidita >= @DataProgramma)
-- ) tc
--  group by PeriodoRilevante
-- ) counters
-- on timetable.Ora = counters.PeriodoRilevante
--  order by PeriodoRilevante
-- 
-- GO


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spGetNC]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spGetNC]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGetNC]  TO [bil_dbo]
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetNumUnit_OverPgm]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetNumUnit_OverPgm]
GO


CREATE PROCEDURE [dbo].[spGetNumUnit_OverPgm] 
 	@DataProgramma smalldatetime,
	@kPowerP as float,
	@kPowerC as float,
	@kPowerMp as float,
	@kPowerMc as float
AS

set transaction isolation level read uncommitted

--declare @DataProgramma smalldatetime,
--  	@kPowerP as float,
--  	@kPowerC as float,
--  	@kPowerMp as float,
--  	@kPowerMc as float
 
-- set @DataProgramma = '12/15/2004'
-- set @kPowerP = 1.5
-- set @kPowerC = 1.5
-- set @kPowerMp = 1.5
-- set @kPowerMc = 1.5

declare @r as integer

set @r = 0

select
 	count(*) NU_OVER
from
(
select 
	case su.TipoUnita
	when 'M' then
		case pou.ProgrammatoDalCedente 
		when 1 then 'P'
		else 'C'
		end 
	else
		su.TipoUnita
	end TipoUnita, 
	case su.TipoUnita 
	when 'M' then 
		case pou.ProgrammatoDalCedente 
		when 1 then su.PotenzaMassimaMWh
		else -su.PotenzaMinimaMWh
		end 
	else
	su.PotenzaMassimaMWh
	end PotenzaMassimaMWh, 
	case su.TipoUnita 
	when 'M' then 0
	else
	su.PotenzaMinimaMWh
	end PotenzaMinimaMWh,
	case su.TipoUnita 
	when 'M' then 
		case pou.ProgrammatoDalCedente 
		when 1 then su.PotenzaMassimaMWh * @kPowerMp
		else -su.PotenzaMinimaMWh * @kPowerMc
		end 
	when 'P' then su.PotenzaMassimaMWh * @kPowerP
	else su.PotenzaMassimaMWh * @kPowerC
	end PotenzaMassimaMWhPlus, 
	abs(pou.QtyMWh) QtyMWh
from (
	SELECT     CodiceUnitaSDC, CategoriaUnitaSDC, ProgrammatoDalCedente, 
			case ProgrammatoDalCedente when 1 then MAX(QtyMWh) else MIN(QtyMWh) end AS QtyMWh
	FROM         ProgrammaOrarioPerUnita
	WHERE DataProgramma = @DataProgramma
	GROUP BY DataProgramma, CodiceUnitaSDC, CategoriaUnitaSDC, ProgrammatoDalCedente
	) pou
inner join sdc_unita su
on su.CodiceUnitaSDC = pou.CodiceUnitaSDC
and su.CategoriaUnitaSDC = pou.CategoriaUnitaSDC
) x
where 
QtyMWh > PotenzaMassimaMWhPlus
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spGetNumUnit_OverPgm]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spGetNumUnit_OverPgm]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGetNumUnit_OverPgm]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOperatori]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[GetOperatori]
GO




CREATE                               function [dbo].[GetOperatori] (@CodiceUnitaSDC as varchar(16), @CategoriaUnitaSDC as varchar, @Data as datetime)  
returns varchar(255)  AS  
begin 

	declare @lstOperatori varchar(255)
	declare @CodiceOperSDC varchar(16)
	declare @indice int

	declare operator_cursor cursor for
		select CodiceOperatoreSDC
		from UnitRelate
		where @CodiceUnitaSDC = CodiceUnitaSDC
			and @CategoriaUnitaSDC = CategoriaUnitaSDC
			and @Data >= DataInizioValidita
			and @Data <= DataFineValidita
		order by CodiceOperatoreSDC


	open operator_cursor 
	set @indice = 0
	set @lstOperatori = ' '
	fetch next from operator_cursor INTO @CodiceOperSDC
	while @@FETCH_STATUS = 0
	begin
		set @lstOperatori = @CodiceOperSDC + ' ' + @lstOperatori
		set @indice = @indice + 1
--		if @indice = 8 break
		fetch next from operator_cursor INTO @CodiceOperSDC
	end
	
	close operator_cursor
	deallocate operator_cursor

	return(@lstOperatori)
end














GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[GetOperatori]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[GetOperatori]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[GetOperatori]  TO [bil_dbo]
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetOperatorListUnits]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetOperatorListUnits]
GO


CREATE PROCEDURE spGetOperatorListUnits
	--@CatUnitSDC as varchar,
	@dt as datetime
AS

select t.CodiceUnitaSDC, 
count(t.CodiceOperatoreSDC)  NroOp, 
dbo.GetOperatori(t.CodiceUnitaSDC, t.CategoriaUnitaSDC, @dt)  LstOp 
from
(
	select su.CodiceUnitaSDC, 
		ur.CodiceOperatoreSDC, 
		su.CategoriaUnitaSDC 
	from SDC_Unita su
	left outer join Unita u
	on su.CodiceUnitaSDC = u.CodiceUnitaSDC 
	and su.CategoriaUnitaSDC = u.CategoriaUnitaSDC
	left outer join
	UnitRelate ur
	on su.CodiceUnitaSDC = ur.CodiceUnitaSDC 
	and su.CategoriaUnitaSDC = ur.CategoriaUnitaSDC
	left outer join SDC_Unita_MarketInformation mi
	on su.CodiceUnitaSDC = mi.CodiceUnitaSDC 
	and su.CategoriaUnitaSDC = mi.CategoriaUnitaSDC
	where @dt >= ur.DataInizioValidita
	and @dt <= ur.DataFineValidita
	and u.StatoBilateraliUnita = 1
	and su.Abilitata = 1
	and mi.MarketCode = 'MGP'
	and mi.Eligibility = 'Able'
) t GROUP BY CodiceUnitaSDC, CategoriaUnitaSDC
 
order by NroOp desc, CodiceUnitaSDC
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGetOperatorListUnits]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetOperatorUnitsType]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetOperatorUnitsType]
GO


CREATE PROCEDURE spGetOperatorUnitsType
	@dt as datetime
AS

select o.CodOp, s.RagioneSociale, o.UP, o.UC, o.UM
from
(
select CodOp, sum(UP) UP, sum(UC) UC, sum(UM) UM
from
(
select CodOp,
case UnitType when 'P' then sum(IsNull(NoUnit, 0)) else 0 end UP,
case UnitType when 'C' then sum(IsNull(NoUnit, 0)) else 0 end UC,
case UnitType when 'M' then sum(IsNull(NoUnit, 0)) else 0 end UM
from (
select CodiceOperatoreSDC CodOp, TipoUnita UnitType, count(UnitRelate.CodiceUnitaSDC) NoUnit 
from UnitRelate
where @dt >= DataInizioValidita 
and @dt <= DataFineValidita
group by TipoUnita, CodiceOperatoreSDC 
) t
group by CodOp, UnitType
) x
group by CodOp
) o
inner join SDC_Operatori s
on o.CodOp = s.CodiceOperatoreSDC
order by CodOp
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spGetOperatorUnitsType]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spGetOperatorUnitsType]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGetOperatorUnitsType]  TO [bil_dbo]
GO



print 'Aggiornamento Stored Procedure [spGetNumUnit_OverPgm].'
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetNumUnit_OverPgm]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetNumUnit_OverPgm]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


CREATE PROCEDURE [dbo].[spGetNumUnit_OverPgm] 
 	@DataProgramma smalldatetime,
	@kPowerP as float,
	@kPowerC as float,
	@kPowerMp as float,
	@kPowerMc as float
AS

set transaction isolation level read uncommitted

--declare @DataProgramma smalldatetime,
--  	@kPowerP as float,
--  	@kPowerC as float,
--  	@kPowerMp as float,
--  	@kPowerMc as float
 
-- set @DataProgramma = '12/15/2004'
-- set @kPowerP = 1.5
-- set @kPowerC = 1.5
-- set @kPowerMp = 1.5
-- set @kPowerMc = 1.5

declare @r as integer

set @r = 0

select
 	count(*) NU_OVER
from
(
select 
	case su.TipoUnita
	when 'M' then
		case pou.ProgrammatoDalCedente 
		when 1 then 'P'
		else 'C'
		end 
	else
		su.TipoUnita
	end TipoUnita, 
	case su.TipoUnita 
	when 'M' then 
		case pou.ProgrammatoDalCedente 
		when 1 then su.PotenzaMassimaMWh
		else -su.PotenzaMinimaMWh
		end 
	else
	su.PotenzaMassimaMWh
	end PotenzaMassimaMWh, 
	case su.TipoUnita 
	when 'M' then 0
	else
	su.PotenzaMinimaMWh
	end PotenzaMinimaMWh,
	case su.TipoUnita 
	when 'M' then 
		case pou.ProgrammatoDalCedente 
		when 1 then su.PotenzaMassimaMWh * @kPowerMp
		else -su.PotenzaMinimaMWh * @kPowerMc
		end 
	when 'P' then su.PotenzaMassimaMWh * @kPowerP
	else su.PotenzaMassimaMWh * @kPowerC
	end PotenzaMassimaMWhPlus, 
	abs(pou.QtyMWh) QtyMWh
from (
	SELECT     CodiceUnitaSDC, CategoriaUnitaSDC, ProgrammatoDalCedente, 
			case ProgrammatoDalCedente when 1 then MAX(QtyMWh) else MIN(QtyMWh) end AS QtyMWh
	FROM         ProgrammaOrarioPerUnita
	WHERE DataProgramma = @DataProgramma
	GROUP BY DataProgramma, CodiceUnitaSDC, CategoriaUnitaSDC, ProgrammatoDalCedente
	) pou
inner join sdc_unita su
on su.CodiceUnitaSDC = pou.CodiceUnitaSDC
and su.CategoriaUnitaSDC = pou.CategoriaUnitaSDC
) x
where 
QtyMWh > PotenzaMassimaMWhPlus
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

print 'Aggiornamento Stored Procedure [spGetNumUnit_OverPgm] concluso.'


print 'Aggiornamento Stored Procedure [spReportDettagliUnita].'
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportDettagliUnita]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportDettagliUnita]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE  PROCEDURE [dbo].[spReportDettagliUnita]
	@d 	smalldatetime
AS

set transaction isolation level read uncommitted

select 
S.CodiceUnitaSDC, 
replace(replace(S.NomeUnita, char(13), ''), char(10), ' ') as NomeUnita,
S.CodiceOperatoreDiRiferimentoSDC,
isnull(X.NC, 0) NC, 
isnull(X.NOP, 0) NOP, 
S.PotenzaMassimaMWh, 
S.PotenzaMinimaMWh  
from  SDC_Unita S  
left outer join  
(
select 
A.CodiceUnitaSDC, 
A.CategoriaUnitaSDC, 
A.NOP, 
B.NC
from
(  
select 
UR.CodiceUnitaSDC, 
UR.CategoriaUnitaSDC, 
count(UR.CodiceOperatoreSDC) NOP  
from  UnitRelate UR  
where ur.Abilitata = 1  
and ur.TrUC = 1  
and ur.DataInizioValidita <= @d 
and ur.DataFineValidita >= @d  
group by ur.CodiceUnitaSDC, 
ur.CategoriaUnitaSDC  
) A  
inner join 
(  
select 
CodiceUnitaSDC, 
CategoriaUnitaSDC, 
count(*) NC  
from  
(  
select  
IdContratto,  
CodiceUnitaSDC,  
CategoriaUnitaSDC,  
sum(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,  
sum(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente  
from  
(  
select  
c.IdContratto, 
ur.CodiceUnitaSDC,  
ur.CategoriaUnitaSDC,  
1 UnitaAssegnataOpCedente,  
0 UnitaAssegnataOpAcquirente  
from  UnitRelate ur  
inner join  Contratto c  
on  c.DataInizioValidita <= @d 
and c.DataFineValidita >= @d  
and c.StatoContratto = 'Abilitato'  
and c.TrCN = 1 
and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente 
and ur.TipoUnita in ('P', 'M')  
and (ur.DataInizioValidita <= c.DataFineValidita 
and ur.DataFineValidita >= c.DataInizioValidita)  
where ur.Abilitata = 1  and ur.TrUC = 1  

union  

select  
c.IdContratto,  
ur.CodiceUnitaSDC,  
ur.CategoriaUnitaSDC,  
0 UnitaAssegnataOpCedente,  
1 UnitaAssegnataOpAcquirente 
 from  UnitRelate ur  
inner join  Contratto c  
on  c.DataInizioValidita <= @d 
and c.DataFineValidita >= @d  
and c.StatoContratto = 'Abilitato'  
and c.TrCN = 1 
and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente
 and ur.TipoUnita in ('C', 'M')  
and (ur.DataInizioValidita <= c.DataFineValidita 
and ur.DataFineValidita >= c.DataInizioValidita)  
where ur.Abilitata = 1 
and ur.TrUC = 1 ) m  
group by IdContratto,  
CodiceUnitaSDC,  
CategoriaUnitaSDC 
) 
t  
group by CodiceUnitaSDC,  
CategoriaUnitaSDC  
) B 
on A.CodiceUnitaSDC = B.CodiceUnitaSDC  
and A.CategoriaUnitaSDC = B.CategoriaUnitaSDC  
) X
on S.CodiceUnitaSDC = X.CodiceUnitaSDC  
and S.CategoriaUnitaSDC = X.CategoriaUnitaSDC  
order by NC, NOP, S.CodiceUnitaSDC, S.CodiceOperatoreDiRiferimentoSDC

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spReportDettagliUnita]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportDettagliUnita]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportDettagliUnita]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

print 'Aggiornamento Stored Procedure [spReportDettagliUnita] concluso.'

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetProgrammiConCertificatoNonValido]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetProgrammiConCertificatoNonValido]
GO




CREATE PROCEDURE [dbo].[spGetProgrammiConCertificatoNonValido] 
	@CodiceUtenteSDC as varchar(16),
	@Issuer as varchar(256),
	@SerialNumber as varchar(64),
	@DataRicerca as smalldatetime
AS
-- set @DataRicerca = '6/24/04'
-- set @CodiceUtenteSDC = 'IDRAPTUS'
-- set @Issuer = 'CN=NAB_CERT'
-- set @SerialNumber = '5F764B1C73DDDD40B75B6505084EDF80'

-- Nuova versione del 14/01/2004 

select  IdProgrammaXml,
	IdContratto,
	DataStipula,
	CRN,
	DataInizioValidita,
	DataFineValidita,
	Responsabile,
	CodiceOperatoreSDCCedente,
	CodiceOperatoreSDCAcquirente,
	Issuer,
	SerialNumber,
	Bilanciato
from 
(
select distinct
	xpu.IdProgrammaXml,
	pou.IdContratto,
	c.DataStipula,
	c.CRN,
	c.DataInizioValidita,
	c.DataFineValidita,
	c.CodiceOperatoreSDC Responsabile, 
	case pou.ProgrammatoDalCedente
	when 1 then xpu.CodiceUtenteSDC
	else c.CodiceOperatoreSDCCedente end as CodiceOperatoreSDCCedente,
	case pou.ProgrammatoDalCedente
	when 0 then xpu.CodiceUtenteSDC 
	else c.CodiceOperatoreSDCAcquirente end as CodiceOperatoreSDCAcquirente,
	xpu.Issuer, 
	xpu.SerialNumber,
	po.Bilanciato
from 	XMLProgrammiUtenti xpu,
	ProgrammaOrarioPerUnita pou, 
	ProgrammaOrario po,
	(
		select IdContratto, 
			DataStipula, 
			CRN, 
			DataInizioValidita, 
			DataFineValidita,
			CodiceOperatoreSDC, 
			CodiceOperatoreSDCCedente,
			CodiceOperatoreSDCAcquirente
		from contratto
		where 
		DataInizioValidita <= @DataRicerca 
		and DataFineValidita >= @DataRicerca 
		and DataInizioValidita <= @DataRicerca 
		and DataFineValidita >= @DataRicerca
		and StatoContratto = 'Abilitato' 
		and TrCN = 1
		and CodiceOperatoreSDC in 
		(
			select CodiceOperatoreSDC from RelOperatoriUtenti
			where CodiceUtenteSDC = @CodiceUtenteSDC 
		)
		or 
		CodiceOperatoreSDCCedente in 
		(
			select CodiceOperatoreSDC from RelOperatoriUtenti
			where CodiceUtenteSDC = @CodiceUtenteSDC 
		)
		or
		CodiceOperatoreSDCAcquirente in 
		(
			select CodiceOperatoreSDC from RelOperatoriUtenti
			where CodiceUtenteSDC = @CodiceUtenteSDC 
		)
	) c,
	Certificate_List cl
where 
	xpu.CodiceUtenteSDC = @CodiceUtenteSDC and 
	xpu.Issuer = @Issuer and 
	xpu.SerialNumber = @SerialNumber and 
	xpu.IdProgrammaXml = pou.IdProgrammaXml and 
	pou.DataProgramma = @DataRicerca and 
	pou.ProgOrarioDellUnitaValidato = 1 and
	po.IdContratto = pou.IdContratto and
	po.DataProgramma = pou.DataProgramma and
	po.PeriodoRilevante = pou.PeriodoRilevante and
	po.ProgrammaOrarioValidato = 1 and
	c.IdContratto = pou.IdContratto and
	xpu.CodiceUtenteSDC = cl.CodiceUtenteSDC and 
	xpu.Issuer          = cl.Issuer and 
	xpu.SerialNumber    = cl.SerialNumber 
	
) T
order by IdContratto, DataStipula


--select  IdProgrammaXml,
---	IdContratto,
--	DataStipula,
--	CRN,
--	DataInizioValidita,
--	DataFineValidita,
--	Responsabile,
--	CodiceOperatoreSDCCedente,
--	CodiceOperatoreSDCAcquirente,
--	Issuer,
--	SerialNumber,
--	Bilanciato
--from 
--(
--select distinct
--	xpu.IdProgrammaXml,
--	pou.IdContratto,
--	c.DataStipula,
--	c.CRN,
--	c.DataInizioValidita,
--	c.DataFineValidita,
--	c.CodiceOperatoreSDC Responsabile, 
--	case pou.ProgrammatoDalCedente
--	when 1 then xpu.CodiceUtenteSDC
--	else c.CodiceOperatoreSDCCedente end as CodiceOperatoreSDCCedente,
--	case pou.ProgrammatoDalCedente
--	when 0 then xpu.CodiceUtenteSDC 
--	else c.CodiceOperatoreSDCAcquirente end as CodiceOperatoreSDCAcquirente,
--	xpu.Issuer, 
--	xpu.SerialNumber,
--	po.Bilanciato
--	--  pou.DataProgramma,
--	--  pou.PeriodoRilevante,
--	--  pou.CodiceUnitaSDc,
--	--  pou.CategoriaUnitaSDC
--from 	XMLProgrammiUtenti xpu,
--	ProgrammaOrarioPerUnita pou, 
--	ProgrammaOrario po,
--	Contratto c,
--	tab_UnitaContratto(@DataRicerca) uc,
--	Certificate_List cl
--where 
--	xpu.CodiceUtenteSDC = @CodiceUtenteSDC and 
--	xpu.Issuer = @Issuer and 
--	xpu.SerialNumber = @SerialNumber and 
--	xpu.IdProgrammaXml = pou.IdProgrammaXml and 
--	pou.DataProgramma = @DataRicerca and 
--	pou.ProgOrarioDellUnitaValidato = 1 and
--	po.IdContratto = pou.IdContratto and
--	po.DataProgramma = pou.DataProgramma and
--	po.PeriodoRilevante = pou.PeriodoRilevante and
--	po.ProgrammaOrarioValidato = 1 and
--	c.IdContratto = pou.IdContratto and
--	c.StatoContratto = 'Abilitato' and
--	c.TrCN = 1 and
--	pou.IdContratto = uc.IdContratto and 
--	pou.CodiceUnitaSDC = uc.CodiceUnitaSDC and 
--	pou.CategoriaUnitaSDC = uc.CategoriaUnitaSDC and
--	uc.TrCC = 1 and 
--	uc.TrUC = 1 and 
--	uc.UnitaDelContrattoValidata = 1 and 
--	xpu.CodiceUtenteSDC = cl.CodiceUtenteSDC and 
--	xpu.Issuer          = cl.Issuer and 
--	xpu.SerialNumber    = cl.SerialNumber and
--	uc.DataInizioValidita <= @DataRicerca and 
--	uc.DataFineValidita >= @DataRicerca and
--	uc.DataInizioValidita <= @DataRicerca and 
--	uc.DataFineValidita >= @DataRicerca
--) T
--order by IdContratto, DataStipula
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spGetProgrammiConCertificatoNonValido]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spGetProgrammiConCertificatoNonValido]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGetProgrammiConCertificatoNonValido]  TO [bil_dbo]
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spListaOfferte]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spListaOfferte]
GO

CREATE PROCEDURE [dbo].[spListaOfferte] 
	@dataFlusso as datetime,
	@ora as integer
AS

-- declare @dataFlusso as datetime
-- declare @ora as integer
-- set @dataFlusso = '15/12/2004'
-- set @ora = 1

select 
P.IdContratto,
P.CRN,
P.GMEReferenceNumber,
P.CodiceOperatore,
OP.RagioneSociale,
P.CodiceUnitaSDC

from 
(
	select
	POU.IdContratto,
	Contratto.CRN,
	CodiceUnitaSDC,

	case POU.ProgrammatoDalCedente 
		when 1 then Contratto.CodiceOperatoreSDCCedente 
		else Contratto.CodiceOperatoreSDCAcquirente 
	end CodiceOperatore,

	POU.GMEReferenceNumber

	from ProgrammaOrarioPerUnita POU
	inner join Contratto
	on Contratto.IdContratto = POU.IdContratto
	where 
	DataProgramma=@dataFlusso
	and PeriodoRilevante=@ora
	and POU.GMEReferenceNumber is not null
) P
inner join SDC_Operatori OP
on OP.CodiceOperatoreSDC = P.CodiceOperatore
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spListaOfferte]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spListaOfferte]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spListaOfferte]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportDettagliUnita]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportDettagliUnita]
GO

--use bilaterali

-- declare @d as datetime 
-- set @d = '12/15/2004'

CREATE  PROCEDURE spReportDettagliUnita
	@d 	smalldatetime
AS

set transaction isolation level read uncommitted

select 
S.CodiceUnitaSDC, 
replace(replace(S.NomeUnita, char(13), ''), char(10), ' ') as NomeUnita,
S.CodiceOperatoreDiRiferimentoSDC,
isnull(X.NC, 0) NC, 
isnull(X.NOP, 0) NOP, 
S.PotenzaMassimaMWh, 
S.PotenzaMinimaMWh  
from  SDC_Unita S  
left outer join  
(
select 
A.CodiceUnitaSDC, 
A.CategoriaUnitaSDC, 
A.NOP, 
B.NC
from
(  
select 
UR.CodiceUnitaSDC, 
UR.CategoriaUnitaSDC, 
count(UR.CodiceOperatoreSDC) NOP  
from  UnitRelate UR  
where ur.Abilitata = 1  
and ur.TrUC = 1  
and ur.DataInizioValidita <= @d 
and ur.DataFineValidita >= @d  
group by ur.CodiceUnitaSDC, 
ur.CategoriaUnitaSDC  
) A  
inner join 
(  
select 
CodiceUnitaSDC, 
CategoriaUnitaSDC, 
count(*) NC  
from  
(  
select  
IdContratto,  
CodiceUnitaSDC,  
CategoriaUnitaSDC,  
sum(UnitaAssegnataOpCedente) UnitaAssegnataOpCedente,  
sum(UnitaAssegnataOpAcquirente) UnitaAssegnataOpAcquirente  
from  
(  
select  
c.IdContratto, 
ur.CodiceUnitaSDC,  
ur.CategoriaUnitaSDC,  
1 UnitaAssegnataOpCedente,  
0 UnitaAssegnataOpAcquirente  
from  UnitRelate ur  
inner join  Contratto c  
on  c.DataInizioValidita <= @d 
and c.DataFineValidita >= @d  
and c.StatoContratto = 'Abilitato'  
and c.TrCN = 1 
and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCCedente 
and ur.TipoUnita in ('P', 'M')  
and (ur.DataInizioValidita <= c.DataFineValidita 
and ur.DataFineValidita >= c.DataInizioValidita)  
where ur.Abilitata = 1  and ur.TrUC = 1  

union  

select  
c.IdContratto,  
ur.CodiceUnitaSDC,  
ur.CategoriaUnitaSDC,  
0 UnitaAssegnataOpCedente,  
1 UnitaAssegnataOpAcquirente 
 from  UnitRelate ur  
inner join  Contratto c  
on  c.DataInizioValidita <= @d 
and c.DataFineValidita >= @d  
and c.StatoContratto = 'Abilitato'  
and c.TrCN = 1 
and ur.CodiceOperatoreSDC = c.CodiceOperatoreSDCAcquirente
 and ur.TipoUnita in ('C', 'M')  
and (ur.DataInizioValidita <= c.DataFineValidita 
and ur.DataFineValidita >= c.DataInizioValidita)  
where ur.Abilitata = 1 
and ur.TrUC = 1 ) m  
group by IdContratto,  
CodiceUnitaSDC,  
CategoriaUnitaSDC 
) 
t  
group by CodiceUnitaSDC,  
CategoriaUnitaSDC  
) B 
on A.CodiceUnitaSDC = B.CodiceUnitaSDC  
and A.CategoriaUnitaSDC = B.CategoriaUnitaSDC  
) X
on S.CodiceUnitaSDC = X.CodiceUnitaSDC  
and S.CategoriaUnitaSDC = X.CategoriaUnitaSDC  
order by NC, NOP, S.CodiceUnitaSDC, S.CodiceOperatoreDiRiferimentoSDC


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spReportDettagliUnita]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportDettagliUnita]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportDettagliUnita]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportOffertePerContratto]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportOffertePerContratto]
GO

CREATE PROCEDURE [dbo].[spReportOffertePerContratto] 
@IdContratto as int,
@DataProgramma as datetime,
@ProgrammatoDalCedente as bit
AS


select 

PeriodoRilevante, 
CodiceUnitaSDC, 
CategoriaUnitaSDC, 
cast(QtyMWhAssegnataMGP as decimal(16,3)) as QtyMWhAssegnataMGP, 
cast(QtyMWh as decimal(16, 3)) as QtyMWh, 
cast(QtyMWhBilanciamento as decimal(16, 3)) as QtyMWhBilanciamento 

from ProgrammaOrarioPerUnita 

where 

IdContratto = @IdContratto 
and DataProgramma = @DataProgramma 
--and not QtyMWhAssegnataMGP is null 
and not GMEReferenceNumber is null
and programmatoDalCedente = @ProgrammatoDalCedente

order by 
CodiceUnitaSDC, 
CategoriaUnitaSDC, 
PeriodoRilevante 


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spReportOffertePerContratto]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportOffertePerContratto]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportOffertePerContratto]  TO [bil_dbo]
GO

--======================================================================
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

--======================================================================
--======================================================================
--======================================================================
--======================================================================

ALTER PROCEDURE dbo.spReportQtaPgmTotPerOperatore 
@d as datetime,
@op as varchar(16) = null
AS

-- cancello la tabella se esiste ancora.
-- In una sp NON DOVREBBE ESISTERE PIU' perche` le tabelle
-- locali vengono cancellate quando la sp e` finita
-- Serve invece a livello di testing quando si esegue la query
-- non da SP da QueryAnalyzer
if Object_Id('tempdb..#Quantita') is Not Null
	drop table #Quantita

-- creo una tabella che conterra` le quantita` per operatore.
-- poi quando l'avro` memorizzata faro le somme per ottenere
-- i totali direttamente qua dentro.
create table #Quantita
(
Ord         integer,    -- vale zero per gli operatori, 1 per i totali
Operatore   varchar(16), 
MWhProd     float, 
MWhBilProd  float, 
MWhOffProd  float, 
MWhCons     float, 
MWhBilCons  float, 
MWhOffCons  float 
)

-- determino se e` stato effettuato il taglio per questa data.
declare @TaglioEffettuato integer
select @TaglioEffettuato=Taglio from SessioneBilaterali where DataProgramma=@d

-- print @TaglioEffettuato

-- QUARTO PASSO
-- metto i risultati delle quantita` per operatore
-- nella tabella temporanea
insert into #Quantita
	-- TERZO PASSO
	-- Sommo le quantita` per Operatore/Unita raggruppando per Operatore
	-- e scartando quelle unita` che non sono piu` validte 
	-- nella UnitRelate
	select
		0 Ord,
		U.Operatore, 
		sum(U.QtyMWhP) MWhProd,
		sum(U.QtyMWhBilanciamentoP) MWhBilProd,
		sum(U.QtyMWhAssegnataMGPP) MWhOffProd,
	
		sum(U.QtyMWhC) MWhCons,
		sum(U.QtyMWhBilanciamentoC) MWhBilCons,
		sum(U.QtyMWhAssegnataMGPC) MWhOffCons
	
	from
	(
		-- SECONDO PASSO
		-- date le programmazioni per unita, operatore su tutti i contratti,
		-- le raggruppo per operatore/utente, sommando la Qty delle unita
		-- presenti su piu` contratti.
		select 
			T.CodiceUnitaSDC,
			T.Operatore, 
	
			sum(ProgrammatoDalCedente * T.QtyMWh) QtyMWhP,
			sum(ProgrammatoDalCedente * T.QtyMWhBilanciamento) QtyMWhBilanciamentoP,
			sum(ProgrammatoDalCedente * T.QtyMWhAssegnataMGP)QtyMWhAssegnataMGPP,
	
			sum((1-ProgrammatoDalCedente) * T.QtyMWh) QtyMWhC,
			sum((1-ProgrammatoDalCedente) * T.QtyMWhBilanciamento) QtyMWhBilanciamentoC,
			sum((1-ProgrammatoDalCedente) * T.QtyMWhAssegnataMGP)QtyMWhAssegnataMGPC
	
		from
		(
				-- PRIMO PASSO
				-- qui trovo tutte le programmazioni e l'operatore che le ha fatte
				-- sono tutti record validi. L'unico controllo ancora non fatto
				-- e` nella unit-relate
				-- Ritorno i record per Contratto/Unita/Operatore, in pratica una riga per POU
				select 
				ProgrammaOrarioPerUnita.ProgrammatoDalCedente,
				ProgrammaOrarioPerUnita.CodiceUnitaSDC,

				case ProgrammaOrarioPerUnita.ProgrammatoDalCedente 
					when 1 then Contratto.CodiceOperatoreSDCCedente 
					else        Contratto.CodiceOperatoreSDCAcquirente
				end Operatore, 

				ProgrammaOrarioPerUnita.QtyMWh,

				case @TaglioEffettuato
				when 1 then isnull(ProgrammaOrarioPerUnita.QtyMWhBilanciamento, ProgrammaOrarioPerUnita.QtyMWh)
				else null
				end QtyMWhBilanciamento,

				ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP
				from ProgrammaOrarioPerUnita 
				
				inner join ProgrammaOrario 
				on  ProgrammaOrario.IdContratto      = ProgrammaOrarioPerUnita.IdContratto 
				and ProgrammaOrario.DataProgramma    = ProgrammaOrarioPerUnita.DataProgramma 
				and ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante 
				and ProgrammaOrario.ProgrammaOrarioValidato = 1 
				and not ProgrammaOrario.Bilanciato is null
				
				inner join Contratto 
				on  Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 
				and Contratto.StatoContratto = 'Abilitato' 
				and Contratto.TrCN = 1 
				and Contratto.DataInizioValidita <= @d 
				and Contratto.DataFineValidita >= @d 
		
				where
				    ProgrammaOrarioPerUnita.DataProgramma = @d 
				and ProgrammaOrarioPerUnita.PeriodoRilevante <= 25
				and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 
		) T
		group by 
			T.CodiceUnitaSDC,
			T.Operatore
	) U
	inner join UnitRelate UR
	on  UR.CodiceUnitaSDC = U.CodiceUnitaSDC
	and UR.CategoriaUnitaSDC = 'F'
	and UR.CodiceOperatoreSDC = U.Operatore
	and UR.DataInizioValidita <= @d
	and UR.DataFineValidita >= @d
	and UR.Abilitata = 1
	and UR.TrUC = 1
	
	group by U.Operatore




-- QUINTO PASSO
-- Sommo tutte le quantita` presenti nella tabella per ottenere i totali
-- metto Ord = 1
insert into #Quantita
	select
	1                             Ord,
	'Totale:'                     Operatore, 
	round( sum(MWhProd),    3) as MWhProd, 
	round( sum(MWhBilProd), 3) as MWhBilProd, 
	round( sum(MWhOffProd), 3) as MWhOffProd, 
	round( sum(MWhCons),    3) as MWhCons, 
	round( sum(MWhBilCons), 3) as MWhBilCons, 
	round( sum(MWhOffCons), 3) as MWhOffCons 
	from #Quantita


-- SESTO PASSO
-- questi sono i risultati
-- faccio vedere i record per operatore prima e i totali poi.
select 
* 
from 
#Quantita
where (@op is null) or (@op = Operatore)
order by
Ord, Operatore

-- QUI NON CANCELLO LA TABELLA per evitare di non vedere l'execution plan.
-- comunque (in caso di test da Query Analyzer) all'inizio la ricancello se esiste.
-- In caso di SP questa tabella viene cancellata quando la SP esce.
-- 
-- drop table #Quantita

return 0


--======================================================================
--======================================================================
--======================================================================
--======================================================================
--======================================================================


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spReportSituazioneProgrammi]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spReportSituazioneProgrammi]
GO


CREATE PROCEDURE [dbo].[spReportSituazioneProgrammi] 
@CodGRTN as varchar(30),
@CodiceContratto as varchar(50), 
@Operatore as varchar(16),
@DataInizio as datetime,
@DataFine as datetime, 
@DataInizioProgramma as datetime, 
@DataFineProgramma as datetime
AS

set transaction isolation level read uncommitted

declare @Q as nvarchar(4000)

set @Q = ''

set @Q = @Q + 
'SELECT 
cast(C.CRN as varchar(30)) AS CodiceGRTN, 
C.CodiceContratto AS CodiceMnemonico, 
C.DataInizioValidita AS DataInizioValidita, 
C.DataFineValidita AS DataFineValidita, 
C.StatoContratto AS Abilitato, 
C.CodiceOperatoreSDCAcquirente AS IdOperatoreAcq, 
C.CodiceOperatoreSDCCedente AS IdOperatoreCed,
NULL DataProgramma, 
''Non presente'' Presenza, 
NULL Bilanciato 
FROM dbo.Contratto C 

WHERE 

C.DataInizioValidita <= @DataFine And 
C.DataFineValidita >= @DataInizio And 

not exists 
( 
select * 
from dbo.ProgrammaOrario PO 
where 
PO.DataProgramma >= @DataInizioProgramma And PO.DataProgramma <= @DataFineProgramma 
and C.IdContratto = PO.IdContratto 
)  '

if not @CodGRTN is null  and len(@CodGRTN) > 0 
begin
	set @Q = @Q + 
 	' and C.CRN = @CodGRTN  '
end

if not @CodiceContratto is null and len(@CodiceContratto) > 0 
begin
	set @Q = @Q + 
 	' and C.CodiceContratto = @CodiceContratto   '
end

if not @Operatore is null  and len(@Operatore) > 0 
begin
	set @Q = @Q + 
 	' and (C.CodiceOperatoreSDCAcquirente = @Operatore Or C.CodiceOperatoreSDCCedente = @Operatore)    '
end

set @Q = @Q +
' union 

SELECT  
cast(CE.CRN as varchar(30)) AS CodiceGRTN, 
CE.CodiceContratto AS CodiceMnemonico, 
CE.DataInizioValidita AS DataInizioValidita, 
CE.DataFineValidita AS DataFineValidita, 
CE.StatoContratto AS Abilitato, 
CE.CodiceOperatoreSDCAcquirente AS IdOperatoreAcq, 
CE.CodiceOperatoreSDCCedente AS IdOperatoreCed, 
POE.DataProgramma AS DataProgramma, 
''Presente'' AS Presenza, 
case min (isnull(cast(POE.Bilanciato as int),0)) when 0 then ''Non bil.'' else ''Bilanciato'' end Bilanciato 
FROM dbo.Contratto CE 
inner JOIN dbo.ProgrammaOrario POE 
on CE.IdContratto = POE.IdContratto 
WHERE 

CE.DataInizioValidita <= @DataFine And 
CE.DataFineValidita >= @DataInizio And 
POE.DataProgramma >= @DataInizioProgramma And POE.DataProgramma <= @DataFineProgramma  '

if not @CodGRTN is null  and len(@CodGRTN) > 0 
begin
	set @Q = @Q + 
 	' and CE.CRN = @CodGRTN  '
end

if not @CodiceContratto is null  and len(@CodiceContratto) > 0 
begin
	set @Q = @Q + 
 	' and CE.CodiceContratto = @CodiceContratto   '
end

if not @Operatore is null and len(@Operatore) > 0 
begin
	set @Q = @Q + 
 	' and (CE.CodiceOperatoreSDCAcquirente = @Operatore Or CE.CodiceOperatoreSDCCedente = @Operatore)    '
end


set @Q = @Q + 
' group by CE.CRN, 
POE.DataProgramma, 
CE.CodiceContratto, 
CE.DataInizioValidita, 
CE.DataFineValidita, 
CE.StatoContratto, 
CE.CodiceOperatoreSDCAcquirente, 
CE.CodiceOperatoreSDCCedente 


order by Abilitato desc, Presenza, Bilanciato, CodiceGRTN '

exec sp_executesql @Q,
	N'@CodGRTN varchar(30), @CodiceContratto varchar(50), @Operatore varchar(16), @DataInizio datetime, @DataFine datetime, @DataInizioProgramma datetime, @DataFineProgramma datetime',
	@CodGRTN = @CodGRTN, 
	@CodiceContratto = @CodiceContratto, 
	@Operatore = @Operatore, 
	@DataInizio = @DataInizio, 
	@DataFine = @DataFine, 
	@DataInizioProgramma = @DataInizioProgramma, 
	@DataFineProgramma = @DataFineProgramma
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spReportSituazioneProgrammi]  TO [public]
GO

GRANT  EXECUTE  ON [dbo].[spReportSituazioneProgrammi]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spReportSituazioneProgrammi]  TO [bil_dbo]
GO



print 'UPDATE Version ON DBVersion'
UPDATE DBVersion SET Version = '2.2.0.4'

print 'UPDATE DBHistory'
INSERT INTO DBHistory (Version, Patch, UpgradeTS, Notes)
VALUES('2.2.0.4', NULL, getdate(), 'Upgrade alla Versione 2.2.0.4')

print 'UPDATE ReportQueries'
delete ReportQueries

insert ReportQueries 
values ('SBIL', 'Report Sbilanciamento Orario', 
'<Report Descrizione="Report Sbilanciamento Orario">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportSbilanciamentoOrario"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="''CRN''"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="DataProgramma" rptColName="Data" rptColFormat="dd/MM/yyyy"/>
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />
		<col dbColName="Bilanciato" rptColName="Bilanciato" rptColFormat="0" />
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat=".000" />
	</out>

</OutputFormat>
</Report>', 
'A')

insert into reportqueries
values ('CTRFLG', 'Gestione taglio su contratti', 
'<Report Descrizione="Report Gestione Taglio su Contratti">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportContrattiFlaggati"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>
	

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"/>
		<col dbColName="NumContratti" rptColName="NumContratti" />
	</out>

	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="NumContratti" rptColName="Num. Contratti" />
	</out>
</OutputFormat>
</Report>', 'A'
)

insert into reportqueries
values ('NRGSBILPGM', 'Energia di Sbilancio a Programma', 
'<Report Descrizione="Report Energia di Sbilancio">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaSbilancioProgramma"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
<Parameter Label="Soglia Sbilanciamento MWh:" Html="Text" ID="Soglia" NomeSql="@SogliaSbilMWh" TipoNET="double" TipoSql="float"/>   
<Parameter Label="CRN:" Html="Text" ID="CRN" NomeSql="@CRN" TipoNET="String" TipoSql="varchar(30)"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN" rptColQuote="''" />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="Operatore" rptColName="Operatore Resp."  />
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="Cedente" rptColName="Cedente"  />
		<col dbColName="Acquirente" rptColName="Acquirente"  />
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />
		<col dbColName="SbilMWhOra01" rptColName="SbilMWhOra01" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra02" rptColName="SbilMWhOra02" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra03" rptColName="SbilMWhOra03" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra04" rptColName="SbilMWhOra04" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra05" rptColName="SbilMWhOra05" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra06" rptColName="SbilMWhOra06" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra07" rptColName="SbilMWhOra07" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra08" rptColName="SbilMWhOra08" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra09" rptColName="SbilMWhOra09" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra10" rptColName="SbilMWhOra10" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra11" rptColName="SbilMWhOra11" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra12" rptColName="SbilMWhOra12" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra13" rptColName="SbilMWhOra13" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra14" rptColName="SbilMWhOra14" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra15" rptColName="SbilMWhOra15" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra16" rptColName="SbilMWhOra16" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra17" rptColName="SbilMWhOra17" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra18" rptColName="SbilMWhOra18" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra19" rptColName="SbilMWhOra19" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra20" rptColName="SbilMWhOra20" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra21" rptColName="SbilMWhOra21" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra22" rptColName="SbilMWhOra22" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra23" rptColName="SbilMWhOra23" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra24" rptColName="SbilMWhOra24" rptColFormat="0.000" />
		<col dbColName="SbilMWhOra25" rptColName="SbilMWhOra25" rptColFormat="0.000" />
	</out>

</OutputFormat>
</Report>',
'A'
)

insert into reportqueries
values ('NRGTAGLIO', 'Entita` Taglio sui Programmi non flaggati', 
'<Report Descrizione="Entita` Taglio sui Programmi non flaggati">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEntitaTaglio"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>

	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>
	
	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="CRN" rptColName="CRN"  />
		<col dbColName="OperatoreCedente" rptColName="Cedente"  />
		<col dbColName="OperatoreAcquirente" rptColName="Acquirente"  />
		<col dbColName="T1" rptColName="TaglioOra1" rptColFormat="0.000" />
		<col dbColName="T2" rptColName="TaglioOra2" rptColFormat="0.000" />
		<col dbColName="T3" rptColName="TaglioOra3" rptColFormat="0.000" />
		<col dbColName="T4" rptColName="TaglioOra4" rptColFormat="0.000" />
		<col dbColName="T5" rptColName="TaglioOra5" rptColFormat="0.000" />
		<col dbColName="T6" rptColName="TaglioOra6" rptColFormat="0.000" />
		<col dbColName="T7" rptColName="TaglioOra7" rptColFormat="0.000" />
		<col dbColName="T8" rptColName="TaglioOra8" rptColFormat="0.000" />
		<col dbColName="T9" rptColName="TaglioOra9" rptColFormat="0.000" />
		<col dbColName="T10" rptColName="TaglioOra10" rptColFormat="0.000" />
		<col dbColName="T11" rptColName="TaglioOra11" rptColFormat="0.000" />
		<col dbColName="T12" rptColName="TaglioOra12" rptColFormat="0.000" />
		<col dbColName="T13" rptColName="TaglioOra13" rptColFormat="0.000" />
		<col dbColName="T14" rptColName="TaglioOra14" rptColFormat="0.000" />
		<col dbColName="T15" rptColName="TaglioOra15" rptColFormat="0.000" />
		<col dbColName="T16" rptColName="TaglioOra16" rptColFormat="0.000" />
		<col dbColName="T17" rptColName="TaglioOra17" rptColFormat="0.000" />
		<col dbColName="T18" rptColName="TaglioOra18" rptColFormat="0.000" />
		<col dbColName="T19" rptColName="TaglioOra19" rptColFormat="0.000" />
		<col dbColName="T20" rptColName="TaglioOra20" rptColFormat="0.000" />
		<col dbColName="T21" rptColName="TaglioOra21" rptColFormat="0.000" />
		<col dbColName="T22" rptColName="TaglioOra22" rptColFormat="0.000" />
		<col dbColName="T23" rptColName="TaglioOra23" rptColFormat="0.000" />
		<col dbColName="T24" rptColName="TaglioOra24" rptColFormat="0.000" />
		<col dbColName="T25" rptColName="TaglioOra25" rptColFormat="0.000" />
	</out>

</OutputFormat>
</Report>',
'A'
)

insert into reportqueries
values ('NRGCNTR', 'Energia Contratti Flaggati', 
'<Report Descrizione="Report Energia Contratti Flaggati">  
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaContrattiFlaggati"/>  
<InputParameters>   
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>   
</InputParameters>  
<OutputFormat>
	<!--
	supporta:
	out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")
	out/col[@rptColFormat=''000'']  - per formattare le singole colonne
	-->
	<out rptType="xml">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!-- 
	supporta:
	out[@rptLanguage=''zz-zz'']    - per formattare nella lingua di Excel (default it-it)
	out[@rptSeparator='';'']       - per separare con , (in inglese) o con ; (in italiano) (default ; )
	out/col[@rptColFormat=''000''] - per formattare la singola colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (defualt non usare il quote)
	-->
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!--
	supporta:
	out[@rptLanguage=''zz-zz'']    - per impostare la lingua con cui si produce il file (default it-it).
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)
	-->
	<out rptType="txt" rptLanguage="it-it" >
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

	<!-- 
	out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente
	-->
	<out rptType="html">
		<col dbColName="GestioneTaglio" rptColName="Gestione Taglio"/>
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzione" />
		<col dbColName="QtyMWhProduzione" rptColName="QtyMWhProduzioneMGP" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumo" />
		<col dbColName="QtyMWhConsumo" rptColName="QtyMWhConsumoMGP" />
	</out>

</OutputFormat>
</Report>', 'A'
)

insert into ReportQueries 
values ('NRGSBIL', 'Energia di Sbilancio', 
'<Report Descrizione="Report Energia di Sbilancio">    
<ComandoSQL Tipo="StoredProcedure" Testo="ReportEnergiaSbilancio"/>    
<InputParameters>     
<Parameter Label="Data (GG/MM/AAAA):" Html="Text" ID="Data" NomeSql="@DataProgramma" TipoNET="DateTime" TipoSql="datetime"/>     
</InputParameters>    
<OutputFormat>   
	<!--   
	supporta:  
		out/col[@rptColLanguage='']   - per formattare nella lingua impostata; '' e` l''InvariantCulture (default "")   
		out/col[@rptColFormat=''000'']  - per formattare le singole colonne   
	-->   
	<out rptType="xml">    
		<col dbColName="DataProgramma" rptColName="DataFlusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice_Contratto" />    
		<col dbColName="CRN" rptColName="CRN"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />  
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />      
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>
	<!--    supporta:   
		out[@rptLanguage=''zz-zz'']    
			- per formattare nella lingua di Excel (default it-it)   out[@rptSeparator='';'']       
			- per separare con , (in inglese) o con ; (in italiano) (default ; )   
		out/col[@rptColFormat=''000''] 
			- per formattare la singola colonna (default null)   
		out/col[@rptColQuote="''"]    
			- per ingannare Excel: non interpreta il campo come numerico (default non usare il quote)   
	-->   
	<out rptType="csv" rptLanguage="it-it" rptSeparator=";">    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="''CRN''" rptColQuote="''" />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>     
	<!--   
	supporta:   
	out[@rptLanguage=''zz-zz'']    	- per impostare la lingua con cui si produce il file (default it-it).   
	out/col[@rptColFormat=''000''] - per impostare il formato della colonna (default null)   
	out/col[@rptColQuote="''"]    - per ingannare Excel: non interpreta il campo come numerico (default "" - niente quoting)   
	-->   
	<out rptType="txt" rptLanguage="it-it" >    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="''CRN''"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out> 
	<!--    out/col[@rptColFormat="000"] - per formattare le singole colonne secondo la lingua corrente   -->   
	<out rptType="html">    
		<col dbColName="DataProgramma" rptColName="Data di flusso" rptColFormat="dd/MM/yyyy"/>    
		<col dbColName="CodiceContratto" rptColName="Codice Contratto" />    
		<col dbColName="CRN" rptColName="CRN"  />    
		<col dbColName="Cedente" rptColName="Cedente"  />    
		<col dbColName="Acquirente" rptColName="Acquirente"  />    
		<col dbColName="GestioneTaglio" rptColName="GestioneTaglio"  />    
		<col dbColName="Ora" rptColName="Ora" rptColFormat="00" />    
		<col dbColName="QtyMWhProd" rptColName="QtyMWhProd" rptColFormat="0.000" />    
		<col dbColName="QtyMWhCons" rptColName="QtyMWhCons" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdT" rptColName="QtyMWhProdDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsT" rptColName="QtyMWhConsDopoTaglio" rptColFormat="0.000" />    
		<col dbColName="QtyMWhProdMGP" rptColName="QtyMWhProdMGP" rptColFormat="0.000" />    
		<col dbColName="QtyMWhConsMGP" rptColName="QtyMWhConsMGP" rptColFormat="0.000" />    
		<col dbColName="SbilanciamentoMWh" rptColName="SbilanciamentoMWh" rptColFormat="0.000" />   
	</out>         
	</OutputFormat>  
</Report>',
'A')

GO

--=============================================================================================
--=============================================================================================
--=============================================================================================
--=============================================================================================
ALTER PROCEDURE dbo.spEseguiBilanciamentoPerContratto
	@IdContratto int,
	@DataProgramma smalldatetime,
	@PeriodoRilevante tinyint,
	@SogliaSbilMWh float
AS

-- CANCELLAZIONE DELLE PROGRAMMAZIONI A ZERO MWH
-- =============================================
-- Questo NON e' il posto migliore per fare le cancellazioni della programmazione a zero MWh.
-- Il posto migliore dovrebbe essere ElaborazioneProgrammiUtenti.
-- Per motivi di tempo e di rischio oggi 24/12/2004 preferisco mettere qui questa
-- operazione.
-- La metto qui dato che il bilanciamento per contratto avviene ad ogni invio
-- del programma.
-- E' sicuramente stupido inserire/modificare record a zero per poi cancellarli, ma
-- dato il carattere di emergenza della modifica questo e` il posto migliore.
-- Notare che su ROMA4 si hanno circa 628.000 record in POU di cui 222.000 a 0MWh ossia
-- il 35% !! --> le query dovrebbero andare almeno un po' piu' veloci.
-- Unico rischio che vedo e` la frammentazione dell'indice.... per ora ignoro.
-- 
-- Prima cerco le programmazioni a zero in POU
-- per cancellare gli eventuali record collegati in POUE
-- (che NON dovrebbero esserci... ma per tranquillita` referenziale lo faccio)
-- Poi cancello le programmazioni a zero in POU

delete ProgrammaOrarioPerUnitaErrori
from
(
	select
	IdContratto,
	DataProgramma,
	PeriodoRilevante,
	CodiceUnitaSDC,
	CategoriaUnitaSDC
	from 
	ProgrammaOrarioperUnita 
	where 
	    IdContratto      = @IdContratto
	and DataProgramma    = @DataProgramma
	and PeriodoRilevante = @PeriodoRilevante
	and QtyMWh=0
) T
where
    ProgrammaOrarioPerUnitaErrori.IdContratto       = T.IdContratto
and ProgrammaOrarioPerUnitaErrori.DataProgramma     = T.DataProgramma
and ProgrammaOrarioPerUnitaErrori.PeriodoRilevante  = T.PeriodoRilevante
and ProgrammaOrarioPerUnitaErrori.CodiceUnitaSDC    = T.CodiceUnitaSDC
and ProgrammaOrarioPerUnitaErrori.CategoriaUnitaSDC = T.CategoriaUnitaSDC


delete ProgrammaOrarioPerUnita
where 
    IdContratto      = @IdContratto
and DataProgramma    = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante
and QtyMWh           = 0


-- FINE CANCELLAZIONE PROGRAMMAZIONI A 0 MWH
-- =========================================



--==============================================================================

-- non si usa read uncommitted in quanto
-- il calcolo del bilanciamento e` troppo delicato per farlo su dati non sicuri


-- declare
-- 	@IdContratto int,
-- 	@DataProgramma smalldatetime,
-- 	@PeriodoRilevante tinyint,
-- 	@SogliaSbilMWh float
-- 
-- set @IdContratto = 212
-- set @DataProgramma = '1/12/2004'
-- set @PeriodoRilevante = 1
-- set @SogliaSbilMWh = 0.001


-- stored procedure che calcola e memorizza il bilanciamento dei programmi di un dato giorno/ora

-- all'uscita della sp avro`
-- PO.Bilanciato = 1 oppure 0 se il programma e` valido e bilanciato o valido non bilanciato.
-- PO.Bilanciato = NULL se il programma, per qualche motivo non e` valido.
--  (es contratto non valido, unita` non valide ecc)
-- conseguentemente un programma con PO.Bilanciato=NULL non deve generare offerte.


-- per prima cosa azzero le informazioni in PO
update ProgrammaOrario
set 
Bilanciato=NULL,
SbilanciamentoMWh=NULL,
SbilanciamentoMWhReale=NULL,
TSCalcoloBilanciamento=NULL
from ProgrammaOrario
where
IdContratto = @IdContratto
and DataProgramma = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante

-- e conseguentemente in POU
update ProgrammaOrarioPerUnita
set 
QtyMWhBilanciamento=NULL
where DataProgramma = @DataProgramma
and PeriodoRilevante = @PeriodoRilevante
and IdContratto = @IdContratto
and not QtyMWhBilanciamento is null

-- siccome sto facendo il calcolo del bilanciamento, potenzialmente
-- e` cambiato il bilanciamento e dunque potenzialemente
-- il taglio forzato e` da rifare.
update 
SessioneBilaterali
set
Taglio=0
where DataProgramma=@DataProgramma


declare @TSCalcoloBilanciamento as datetime
set @TSCalcoloBilanciamento = getdate()

update ProgrammaOrario
set 
Bilanciato=W.Bilanciato,
SbilanciamentoMWh=W.BilMWh,
SbilanciamentoMWhReale=W.BilMWhReale,
TSCalcoloBilanciamento=@TSCalcoloBilanciamento
from ProgrammaOrario PW
inner join
(
	select
	Q.IdContratto,
	@DataProgramma DataProgramma,
	Q.PeriodoRilevante,
	
	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then 0 else 1 end Bilanciato,
	case when Abs(Sum(Q.QtyMWh)) > round(@SogliaSbilMWh,3) then cast(Sum(Q.QtyMWh) as decimal(16,3)) else 0 end BilMWh,
	cast(Sum(Q.QtyMWh) as decimal(16,3)) BilMWhReale
	
	from
	(
		select 
		POU.IdContratto,
		POU.PeriodoRilevante,
		round(POU.QtyMWh * PR.CoefficienteDiPerdita / U.CoefficientePerdita, 3) QtyMWh,
		U.CoefficientePerdita KU,
		PR.CoefficienteDiPerdita KP
		
		from ProgrammaOrarioPerUnita POU
		inner join ProgrammaOrario PO
		on
		POU.Idcontratto = PO.IdContratto
		and POU.DataProgramma = PO.DataProgramma
		and POU.PeriodoRilevante = PO.PeriodoRilevante
		and POU.ProgOrarioDellUnitaValidato = 1
		and POU.DataProgramma = @DataProgramma
		and POU.IdContratto = @IdContratto
		and POU.PeriodoRilevante = @PeriodoRilevante
		and PO.ProgrammaOrarioValidato = 1
		
		inner join Contratto CO
		on CO.IdContratto = POU.IdContratto
		and CO.DataInizioValidita <= @DataProgramma
		and CO.DataFineValidita >= @DataProgramma
		and CO.StatoContratto = 'Abilitato'
		and CO.TrCN = 1
		
		inner join UnitRelate UR
		on UR.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and UR.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		and 
		(
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCAcquirente and POU.ProgrammatoDalCedente=0)
			or
			(UR.CodiceOperatoreSDC = CO.CodiceOperatoreSDCCedente and POU.ProgrammatoDalCedente=1)
		)
		and UR.DataInizioValidita <= @DataProgramma
		and UR.DataFineValidita   >= @DataProgramma
		and UR.Abilitata = 1
		and UR.TrUC = 1
		
		inner join SDC_Unita U
		on U.CodiceUnitaSDC = POU.CodiceUnitaSDC
		and U.CategoriaUnitaSDC = POU.CategoriaUnitaSDC
		
		inner join  SDC_PuntiDiScambioRilevanti PR
		on U.CodicePuntoDiScambioRilevanteSDC = PR.CodicePuntoDiScambioRilevanteSDC

	) Q
	group by IdContratto, PeriodoRilevante

) W

on  PW.IdContratto = W.IdContratto
and PW.DataProgramma = W.DataProgramma
and PW.PeriodoRilevante = W.PeriodoRilevante

--=============================================================================================
--=============================================================================================
--=============================================================================================
--=============================================================================================



PRINT 'Il database e` aggiornato alla versione 2.2.0.4 !'


