/* ------------------------------------------------------------------------------------------ 
 * Upgrade Database: script SQL per mettere off-line il Database BilateraliVoid.
 * Versione Iniziale: 2.0.0.0 
 * Versione Finale:   2.0.0.1
 * D.C.: 07/10/2004 
 * Questo script deve essere lanciato come passo (3) per 
 * aggiornare il database BilateraliVoid, a seguito dell'aggiornamento del
 * database Bilaterali (vedi script Upgrade2001.sql per aggiornare il 
 * database dalla versione 2.0.0.0 alla 2.0.0.1.
 * La sequenza di comandi da eseguire in SQL Query Analyzer per eseguire 
 * l'aggiornamento e`:
 *	1) BilateraliVoid_Attach.sql
 *	2) Upgrade2001.sql
 *	3) BilateraliVoid_Detach.sql
 * ------------------------------------------------------------------------------------------ 
*/

USE Bilaterali

EXEC sp_detach_db BilateraliVoid
