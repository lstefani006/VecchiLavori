
set transaction isolation level read uncommitted

declare @di datetime
set @di = '1/1/2005'
declare @df datetime
set @df = '31/1/2005'

select
sum (CCTOfferta), DataProgramma
from
(
select 
Contratto.CodiceOperatoreSDCCedente Op,
Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

convert(decimal(15,3), ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP 
	/ SDC_Unita.CoefficientePerdita * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita)
	QtyMWh,

convert(decimal(15,2), ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP 
	/ SDC_Unita.CoefficientePerdita * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita 
	* (PrezzoUnitario.Prezzo - PrezzoZonale.Prezzo))
	CCTOfferta,

ProgrammaOrarioPerUnita.DataProgramma
from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

where 
not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null       -- e` un report da fare A FINE MERCATO
and ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP > 0           -- solo unita` che producono
and ProgrammaOrarioPerUnita.DataProgramma >= @di
and ProgrammaOrarioPerUnita.DataProgramma <= @df

--and Contratto.CodiceContratto like 'ESTERO%'
and  Contratto.CodiceOperatoreSDCCedente like 'IMPORT%'

-- order by 
-- Contratto.CodiceOperatoreSDCCedente,
-- Contratto.CRN,
-- ProgrammaOrarioPerUnita.CodiceUnitaSDC,
-- ProgrammaOrarioPerUnita.PeriodoRilevante
) T
group by DataProgramma