if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spGetNextMessage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spGetNextMessage]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spDownloadMessage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spDownloadMessage]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spForceDownloadMessage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spForceDownloadMessage]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [dbo].[spGetNextMessage] 
	 @IdOperatore varchar(16),
	 @Tutti integer,
	 @Top integer
AS

set transaction isolation level read uncommitted

declare @SQLString1 as nvarchar(1024)

set @SQLString1 = 'SELECT  top ' + cast(@Top as varchar) + 
	'IdFile, CodiceOperatoreSDC, TSDownload, TSCreazione, DescrizioneFile, Zipped, NomeFile, CodiceTipoFile
	FROM         dbo.FileOperatori
	where CodiceOperatoreSDC = @IdOperatore
		and (@Tutti = 1 or TSDownload is null)
		order by TSCreazione desc'

--exec sp_executesql 

exec sp_executesql @SQLString1,
		N'@IdOperatore varchar(16), @Tutti integer',
	       	@IdOperatore = @IdOperatore,
		@Tutti = @Tutti
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spGetNextMessage]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spGetNextMessage]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [dbo].[spDownloadMessage] 
@IdOperatore varchar(16)
AS

set transaction isolation level read uncommitted

declare @IdFile as varchar(32)

select top 1
@IdFile= IdFile
from dbo.FileOperatori
where CodiceOperatoreSDC = @IdOperatore
and TSDownload is null
order by TSCreazione desc

--print @IdFile

select 
NomeFile, Zipped, Encoding, ContenutoFile
from dbo.FileOperatori
where IdFile= @IdFile

update
dbo.FileOperatori
set TSDownload = getdate()
where IdFile= @IdFile
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spDownloadMessage]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spDownloadMessage]  TO [bil_dbo]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE [dbo].[spForceDownloadMessage] 
@IdFile varchar(32)
AS

set transaction isolation level read uncommitted

select 
NomeFile, Zipped, Encoding, ContenutoFile
from dbo.FileOperatori
where IdFile= @IdFile

update
dbo.FileOperatori
set TSDownload = getdate()
where IdFile= @IdFile
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[spForceDownloadMessage]  TO [bil_user]
GO

GRANT  EXECUTE  ON [dbo].[spForceDownloadMessage]  TO [bil_dbo]
GO

print 'UPDATE Version ON DBVersion'
UPDATE DBVersion SET Version = '2.3.1.1'

print 'UPDATE DBHistory'
INSERT INTO DBHistory (Version, Patch, UpgradeTS, Notes)
VALUES('2.3.1.1', NULL, getdate(), 'Upgrade alla Versione 2.3.1.1')
