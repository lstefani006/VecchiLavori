--
-- Script SQL di cancellazione globale totale dei dati dal database
--	(DISTRUTTIVO!!!!!!!)
--
-- Questo serve eventualmente per ottenere l'immagine dello stato 0:
--
--	  BilateraliVoid_Data.mdf ==> datafile 
--    BilateraliVoid_Log.ldf ==> log file
--
-- da un DB gia' riempito che ha un unico datafile (non piu' di un datafile
--  mdf).
--
-- NON vengono ripulite le tabelle utilizzate per il versioning del database:
--		DBHistory
--      DBPatch  
--      DBVersion  
-- NE' vengono aggiornate 
--
-- Lo script e' da eseguirsi con un utente amministratore SQL Server
-- perche' alla fine i datafiles vengono ridotti in size con l'istruzione:
--     DBCC SHRINKDATABASE (Bilaterali_Copy, 25)
--
-- Il DB utilizzato si chiama: 
--	   Bilaterali_Copy
--
USE BilateraliVoid

DELETE FROM PrezzoUnitario
DELETE FROM RichiestaCancellazione
DELETE FROM BatchStatus
DELETE FROM Certificate_DistributionPoints
DELETE FROM Certificate_List
DELETE FROM Certificate_RevocationList
DELETE FROM Certificate_CA
DELETE FROM SessioneBilaterali
DELETE FROM SmLog
DELETE FROM Ore
DELETE FROM ReportQueries

DELETE FROM RuoliFunzioni
DELETE FROM Funzioni

DELETE FROM RichiestaCancellazione

DELETE FROM ProgrammaOrarioPerUnitaErrori
DELETE FROM ProgrammaOrarioPerUnita
DELETE FROM ProgrammaOrario

DELETE FROM SDC_Unita_MarketInformation

DELETE FROM UnitRelate


DELETE FROM Unita
DELETE FROM SDC_Unita

DELETE FROM Contratto

DELETE FROM XmlProgrammiUtenti
DELETE FROM XmlFileDaOperatori
DELETE FROM RelOperatoriUtenti
DELETE FROM FileOperatori
DELETE FROM Operatori
DELETE FROM SDC_Operatori

DELETE FROM SDC_PuntiDiScambioRilevanti


DELETE FROM Utenti
DELETE FROM SDC_Utenti

DELETE FROM PrezzoZonale
DELETE FROM SDC_Zone

DELETE FROM Ruoli
DELETE FROM FileMGP

DBCC SHRINKDATABASE (BilateraliVoid, 2)

--
-- 
-- Commentare se NON si vuole utilizzare il DB ripulito per Stato 0 - Stato 1
-- Nell'esecuzione degli script Stato 0 - Stato 1 vengono SEMPRE controllati i nomi simbolici
-- del file dati e del file di log (il file dati deve chiamarsi BilateraliVoid_Data e il file
-- di log deve chiamarsi BilateraliVoid_Log)
--
-- Si suppone che il database che si vuole ripulire abbia come nomi simbolici originari:
--  Bilaterali      --> DataFile
--  Bilaterali_log  --> LogFile
ALTER DATABASE BilateraliVoid MODIFY FILE (NAME=Bilaterali, NEWNAME=BilateraliVoid_Data)
ALTER DATABASE BilateraliVoid MODIFY FILE (NAME=Bilaterali_Log, NEWNAME=BilateraliVoid_Log)
--