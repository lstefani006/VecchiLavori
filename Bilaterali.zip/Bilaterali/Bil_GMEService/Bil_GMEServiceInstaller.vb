Imports System.ComponentModel
Imports System.Configuration.Install

<RunInstaller(True)> Public Class Bil_GMEServiceInstaller
    Inherits System.Configuration.Install.Installer

#Region " Component Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Installer overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Bil_GMEInstaller As System.ServiceProcess.ServiceInstaller
    Friend WithEvents Bil_GMEServiceProcessInstaller As System.ServiceProcess.ServiceProcessInstaller
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Bil_GMEInstaller = New System.ServiceProcess.ServiceInstaller
        Me.Bil_GMEServiceProcessInstaller = New System.ServiceProcess.ServiceProcessInstaller
        '
        'Bil_GMEInstaller
        '
        Me.Bil_GMEInstaller.DisplayName = "Bil_GMEService"
        Me.Bil_GMEInstaller.ServiceName = "Bil_GMEService"
        Me.Bil_GMEInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic
        '
        'Bil_GMEServiceProcessInstaller
        '
        Me.Bil_GMEServiceProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalSystem
        Me.Bil_GMEServiceProcessInstaller.Password = Nothing
        Me.Bil_GMEServiceProcessInstaller.Username = Nothing
        '
        'Bil_GMEServiceInstaller
        '
        Me.Installers.AddRange(New System.Configuration.Install.Installer() {Me.Bil_GMEInstaller, Me.Bil_GMEServiceProcessInstaller})

    End Sub

#End Region

End Class
