Public Class AnaOperatoreSDC
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()
        'Non funziona comunque questo dovrebbe essere il funzionamento corretto!!
        ' Me.cnOperatoreSDC = CreateConnection()

        Me.cnOperatoreSDC.ConnectionString = GetConnectionString()
        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cnOperatoreSDC As System.Data.SqlClient.SqlConnection
	Friend WithEvents daOperatoriSDC As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents DsAnaOperatoriSDC As Bil.DsAnaOperatoriSDC
	Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cnOperatoreSDC = New System.Data.SqlClient.SqlConnection
		Me.daOperatoriSDC = New System.Data.SqlClient.SqlDataAdapter
		Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
		'
		'cnOperatoreSDC
		'
		Me.cnOperatoreSDC.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_user;data source=BILSVR1;persis" & _
		"t security info=False;initial catalog=Bilaterali"
		'
		'daOperatoriSDC
		'
		Me.daOperatoriSDC.SelectCommand = Me.SqlSelectCommand1
		Me.daOperatoriSDC.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Operatori", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("RagioneSociale", "RagioneSociale"), New System.Data.Common.DataColumnMapping("Indirizzo1", "Indirizzo1"), New System.Data.Common.DataColumnMapping("Indirizzo2", "Indirizzo2"), New System.Data.Common.DataColumnMapping("Citta", "Citta"), New System.Data.Common.DataColumnMapping("Nazione", "Nazione"), New System.Data.Common.DataColumnMapping("CodiceFiscale", "CodiceFiscale"), New System.Data.Common.DataColumnMapping("PartitaIva", "PartitaIva"), New System.Data.Common.DataColumnMapping("Fax", "Fax"), New System.Data.Common.DataColumnMapping("Email", "Email"), New System.Data.Common.DataColumnMapping("ReferenteAmministrativo", "ReferenteAmministrativo"), New System.Data.Common.DataColumnMapping("SedeAmministrativa", "SedeAmministrativa"), New System.Data.Common.DataColumnMapping("Abilitato", "Abilitato"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"), New System.Data.Common.DataColumnMapping("ResponsabileAggiornamento", "ResponsabileAggiornamento"), New System.Data.Common.DataColumnMapping("StatoBilateraliOperatore", "StatoBilateraliOperatore")})})
		'
		'SqlSelectCommand1
		'
		Me.SqlSelectCommand1.CommandText = "SELECT dbo.SDC_Operatori.CodiceOperatoreSDC, dbo.SDC_Operatori.RagioneSociale, db" & _
		"o.SDC_Operatori.Indirizzo1, dbo.SDC_Operatori.Indirizzo2, dbo.SDC_Operatori.Citt" & _
		"a, dbo.SDC_Operatori.Nazione, dbo.SDC_Operatori.CodiceFiscale, dbo.SDC_Operatori" & _
		".PartitaIva, dbo.SDC_Operatori.Fax, dbo.SDC_Operatori.Email, dbo.SDC_Operatori.R" & _
		"eferenteAmministrativo, dbo.SDC_Operatori.SedeAmministrativa, dbo.SDC_Operatori." & _
		"Abilitato, dbo.SDC_Operatori.TSModifica, dbo.SDC_Operatori.ResponsabileAggiornam" & _
		"ento, dbo.Operatori.StatoBilateraliOperatore FROM dbo.Operatori RIGHT OUTER JOIN" & _
		" dbo.SDC_Operatori ON dbo.Operatori.CodiceOperatoreSDC = dbo.SDC_Operatori.Codic" & _
		"eOperatoreSDC WHERE (dbo.Operatori.CodiceOperatoreSDC IS NULL)"
		Me.SqlSelectCommand1.Connection = Me.cnOperatoreSDC

	End Sub

#End Region
    Public Function GetList() As DsAnaOperatoriSDC
        Try
            Dim ds As New DsAnaOperatoriSDC
            Me.cnOperatoreSDC.Open()
            Me.daOperatoriSDC.Fill(ds, ds.Operatori.TableName)
            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
		Finally
			If cnOperatoreSDC.State = ConnectionState.Open Then cnOperatoreSDC.Close()
		End Try
	End Function


	Public Function GetListWithParametersSDC(ByVal strCodiceSDC As String, ByVal strRagioneSociale As String, ByVal strAbilitazione As String) As DsAnaOperatoriSDC
		Try

			Dim ds As New DsAnaOperatoriSDC
			Me.cnOperatoreSDC.Open()

			If strCodiceSDC.Length = 0 And strRagioneSociale.Length = 0 And _
						strAbilitazione = "entrambi" Then

				Me.daOperatoriSDC.Fill(ds, ds.Operatori.TableName)

			Else
				'Me.daUtentiSDC.SelectCommand.CommandText = Me.daUtentiSDC.SelectCommand.CommandText & " WHERE 1=1 "


				If strAbilitazione <> "entrambi" Then
					Dim abilitazione As Boolean
					If strAbilitazione = "abilitato" Then
						abilitazione = True
					Else
						abilitazione = False
					End If
					Me.daOperatoriSDC.SelectCommand.CommandText = Me.daOperatoriSDC.SelectCommand.CommandText & " AND abilitato =@abilitato"
					Me.daOperatoriSDC.SelectCommand.Parameters.Add("@abilitato", abilitazione)
				End If

				If strCodiceSDC.Length > 0 Then
					Me.daOperatoriSDC.SelectCommand.CommandText = Me.daOperatoriSDC.SelectCommand.CommandText & " AND SDC_Operatori.codiceOperatoreSDC like @codiceOperatoreSDC"
					Me.daOperatoriSDC.SelectCommand.Parameters.Add("@codiceOperatoreSDC", strCodiceSDC & "%")

				End If

				If strRagioneSociale.Length > 0 Then
					Me.daOperatoriSDC.SelectCommand.CommandText = Me.daOperatoriSDC.SelectCommand.CommandText & " AND RagioneSociale like @RagioneSociale"
					Me.daOperatoriSDC.SelectCommand.Parameters.Add("@RagioneSociale", strRagioneSociale & "%")

				End If

				Me.daOperatoriSDC.Fill(ds, ds.Operatori.TableName)

			End If

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cnOperatoreSDC.State = ConnectionState.Open Then cnOperatoreSDC.Close()
		End Try
	End Function

	Public Function GetSDC_OperatoriWithParameters(ByVal strCodiceSDC As String, ByVal strRagioneSociale As String, ByVal strAbilitazione As String) As DsAnaOperatoriSDC
		Try

			Dim ds As New DsAnaOperatoriSDC
			Me.cnOperatoreSDC.Open()

			Me.daOperatoriSDC.SelectCommand.CommandText = "SELECT * FROM SDC_Operatori WHERE 1 = 1 "

			If strCodiceSDC.Length = 0 And strRagioneSociale.Length = 0 And _
						strAbilitazione = "entrambi" Then

				Me.daOperatoriSDC.Fill(ds, ds.Operatori.TableName)

			Else

				If strAbilitazione <> "entrambi" Then
					Dim abilitazione As Boolean
					If strAbilitazione = "abilitato" Then
						abilitazione = True
					Else
						abilitazione = False
					End If
					Me.daOperatoriSDC.SelectCommand.CommandText = Me.daOperatoriSDC.SelectCommand.CommandText & " AND abilitato =@abilitato"
					Me.daOperatoriSDC.SelectCommand.Parameters.Add("@abilitato", abilitazione)
				End If

				If strCodiceSDC.Length > 0 Then
					Me.daOperatoriSDC.SelectCommand.CommandText = Me.daOperatoriSDC.SelectCommand.CommandText & " AND CodiceOperatoreSDC like @codiceOperatoreSDC"
					Me.daOperatoriSDC.SelectCommand.Parameters.Add("@codiceOperatoreSDC", strCodiceSDC & "%")

				End If

				If strRagioneSociale.Length > 0 Then
					Me.daOperatoriSDC.SelectCommand.CommandText = Me.daOperatoriSDC.SelectCommand.CommandText & " AND RagioneSociale like @RagioneSociale"
					Me.daOperatoriSDC.SelectCommand.Parameters.Add("@RagioneSociale", strRagioneSociale & "%")

				End If

				Me.daOperatoriSDC.Fill(ds, ds.Operatori.TableName)

			End If

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cnOperatoreSDC.State = ConnectionState.Open Then cnOperatoreSDC.Close()
		End Try
	End Function

	Public Function GetSDC_Operatori() As DsAnaOperatoriSDC
		Try
			Dim ds As New DsAnaOperatoriSDC
			Me.cnOperatoreSDC.Open()
			Me.daOperatoriSDC.SelectCommand.CommandText = "SELECT * FROM SDC_Operatori "
			Me.daOperatoriSDC.Fill(ds, ds.Operatori.TableName)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cnOperatoreSDC.State = ConnectionState.Open Then cnOperatoreSDC.Close()
		End Try
	End Function

	Public Function GetSDC_OperatoriBilateralisti() As DsAnaOperatoriSDC
		Try
			Dim ds As New DsAnaOperatoriSDC
			Me.cnOperatoreSDC.Open()
			Me.daOperatoriSDC.SelectCommand.CommandText = "SELECT * FROM SDC_Operatori inner join Operatori on SDC_Operatori.CodiceOperatoreSDC = Operatori.CodiceOperatoreSDC where Operatori.StatoBilateraliOperatore=1 and SDC_Operatori.Abilitato=1"
			Me.daOperatoriSDC.Fill(ds, ds.Operatori.TableName)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cnOperatoreSDC.State = ConnectionState.Open Then cnOperatoreSDC.Close()
		End Try
	End Function

	Public Function GetSDC_OperatoriBilateralisti_Filtered(ByVal strCodiceSDC As String, ByVal strRagioneSociale As String) As DsAnaOperatoriSDC
		Try
			Dim ds As New DsAnaOperatoriSDC
			Me.cnOperatoreSDC.Open()
			Me.daOperatoriSDC.SelectCommand.CommandText = "SELECT * FROM SDC_Operatori inner join Operatori on SDC_Operatori.CodiceOperatoreSDC = Operatori.CodiceOperatoreSDC where Operatori.StatoBilateraliOperatore=1 and SDC_Operatori.Abilitato=1"
			If strCodiceSDC.Length > 0 Then
				Me.daOperatoriSDC.SelectCommand.CommandText = Me.daOperatoriSDC.SelectCommand.CommandText & " AND SDC_Operatori.codiceOperatoreSDC like @codiceOperatoreSDC"
				Me.daOperatoriSDC.SelectCommand.Parameters.Add("@codiceOperatoreSDC", strCodiceSDC & "%")

			End If

			If strRagioneSociale.Length > 0 Then
				Me.daOperatoriSDC.SelectCommand.CommandText = Me.daOperatoriSDC.SelectCommand.CommandText & " AND RagioneSociale like @RagioneSociale"
				Me.daOperatoriSDC.SelectCommand.Parameters.Add("@RagioneSociale", strRagioneSociale & "%")

			End If

			Me.daOperatoriSDC.Fill(ds, ds.Operatori.TableName)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cnOperatoreSDC.State = ConnectionState.Open Then cnOperatoreSDC.Close()
		End Try
	End Function

End Class

