Public Class ChangePwd
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents da As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdate As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.da = New System.Data.SqlClient.SqlDataAdapter
        Me.cmdSelect = New System.Data.SqlClient.SqlCommand
        Me.cmdUpdate = New System.Data.SqlClient.SqlCommand
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=BIGNONEP;packet size=4096;user id=sa;data source=BILSVR1;persist s" & _
        "ecurity info=False;initial catalog=Bilaterali"
        '
        'da
        '
        Me.da.SelectCommand = Me.cmdSelect
        Me.da.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "SDC_Utenti", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Login", "Login"), New System.Data.Common.DataColumnMapping("Pwd", "Pwd"), New System.Data.Common.DataColumnMapping("Cognome", "Cognome"), New System.Data.Common.DataColumnMapping("Nome", "Nome"), New System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC")})})
        Me.da.UpdateCommand = Me.cmdUpdate
        '
        'cmdSelect
        '
        Me.cmdSelect.CommandText = "SELECT Login, Pwd, Cognome, Nome, CodiceUtenteSDC FROM SDC_Utenti WHERE (CodiceUt" & _
        "enteSDC = @CodiceUtenteSDC)"
        Me.cmdSelect.Connection = Me.cn
        Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
        '
        'cmdUpdate
        '
        Me.cmdUpdate.CommandText = "UPDATE SDC_Utenti SET Pwd = @Pwd WHERE (CodiceUtenteSDC = @Original_CodiceUtenteS" & _
        "DC)"
        Me.cmdUpdate.Connection = Me.cn
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Pwd", System.Data.SqlDbType.VarChar, 20, "Pwd"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))

    End Sub

#End Region

    Public Function getDatiUtente(ByVal CodiceUtenteSDC As String) As DataSet
        cn.ConnectionString = GetConnectionString()

        Dim ds As New DataSet
        Try
            cn.Open()
            da.SelectCommand.Parameters("@CodiceUtenteSDC").Value = CodiceUtenteSDC
            da.Fill(ds, "Utenti")
            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Function

    Public Sub updatePwd(ByVal NewPwd As String, ByVal CodiceUtenteSDC As String)
        cn.ConnectionString = GetConnectionString()

        Dim ds As New DataSet
        Try
            cn.Open()
            da.UpdateCommand.Parameters("@Pwd").Value = NewPwd
            da.UpdateCommand.Parameters("@Original_CodiceUtenteSDC").Value = CodiceUtenteSDC

            da.UpdateCommand.ExecuteNonQuery()

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Sub

End Class
