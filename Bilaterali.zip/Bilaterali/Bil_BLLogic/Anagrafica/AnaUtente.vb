Public Class AnaUtente
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()
        _cnAnaUtente.ConnectionString = GetConnectionString()
        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cnAnaUtente As System.Data.SqlClient.SqlConnection
    Friend WithEvents _daAnaUtente As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelectStartUtenti As System.Data.SqlClient.SqlCommand
    Friend WithEvents _dsUtenti As Bil.DSAnaUtenti
    Friend WithEvents _cmdUpdateUtenti As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdDeleteUtente As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdInsertUtente As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdImportUtentiFiltrati As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cnAnaUtente = New System.Data.SqlClient.SqlConnection
        Me._daAnaUtente = New System.Data.SqlClient.SqlDataAdapter
        Me._cmdDeleteUtente = New System.Data.SqlClient.SqlCommand
        Me._cmdInsertUtente = New System.Data.SqlClient.SqlCommand
        Me._cmdSelectStartUtenti = New System.Data.SqlClient.SqlCommand
        Me._cmdUpdateUtenti = New System.Data.SqlClient.SqlCommand
        Me._dsUtenti = New Bil.DSAnaUtenti
        Me._cmdImportUtentiFiltrati = New System.Data.SqlClient.SqlCommand
        CType(Me._dsUtenti, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cnAnaUtente
        '
        Me._cnAnaUtente.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_user;data source=BILSVR1;persis" & _
        "t security info=False;initial catalog=Bilaterali_ROMA5"
        '
        '_daAnaUtente
        '
        Me._daAnaUtente.DeleteCommand = Me._cmdDeleteUtente
        Me._daAnaUtente.InsertCommand = Me._cmdInsertUtente
        Me._daAnaUtente.SelectCommand = Me._cmdSelectStartUtenti
        Me._daAnaUtente.UpdateCommand = Me._cmdUpdateUtenti
        '
        '_cmdDeleteUtente
        '
        Me._cmdDeleteUtente.CommandText = "DELETE FROM dbo.Utenti WHERE (CodiceUtenteSDC = @CodiceUtenteSDC)"
        Me._cmdDeleteUtente.Connection = Me._cnAnaUtente
        Me._cmdDeleteUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        '_cmdInsertUtente
        '
        Me._cmdInsertUtente.CommandText = "INSERT INTO dbo.Utenti (CodiceUtenteSDC, StatoBilateraliUtente, TSModifica, Super" & _
        "User) VALUES (@CodiceUtenteSDC, @StatoBilateraliUtente, @TSModifica, @SuperUser)" & _
        ""
        Me._cmdInsertUtente.Connection = Me._cnAnaUtente
        Me._cmdInsertUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
        Me._cmdInsertUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoBilateraliUtente", System.Data.SqlDbType.Bit, 1, "StatoBilateraliUtente"))
        Me._cmdInsertUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me._cmdInsertUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SuperUser", System.Data.SqlDbType.Bit, 1, "SuperUser"))
        '
        '_cmdSelectStartUtenti
        '
        Me._cmdSelectStartUtenti.CommandText = "SELECT dbo.Bil_Utenti.* FROM dbo.Bil_Utenti"
        Me._cmdSelectStartUtenti.Connection = Me._cnAnaUtente
        '
        '_cmdUpdateUtenti
        '
        Me._cmdUpdateUtenti.CommandText = "UPDATE dbo.Utenti SET StatoBilateraliUtente = @StatoBilateraliUtente, TSModifica " & _
        "= @TSModifica, SuperUser = @SuperUser WHERE (CodiceUtenteSDC = @CodiceUtenteSDC)" & _
        ""
        Me._cmdUpdateUtenti.Connection = Me._cnAnaUtente
        Me._cmdUpdateUtenti.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoBilateraliUtente", System.Data.SqlDbType.Bit, 1, "StatoBilateraliUtente"))
        Me._cmdUpdateUtenti.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me._cmdUpdateUtenti.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SuperUser", System.Data.SqlDbType.Bit, 1, "SuperUser"))
        Me._cmdUpdateUtenti.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        '_dsUtenti
        '
        Me._dsUtenti.CaseSensitive = True
        Me._dsUtenti.DataSetName = "DSAnaUtenti"
        Me._dsUtenti.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        '_cmdImportUtentiFiltrati
        '
        Me._cmdImportUtentiFiltrati.CommandText = "dbo.[spBilAddUtentiFiltrati]"
        Me._cmdImportUtentiFiltrati.CommandType = System.Data.CommandType.StoredProcedure
        Me._cmdImportUtentiFiltrati.Connection = Me._cnAnaUtente
        Me._cmdImportUtentiFiltrati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        Me._cmdImportUtentiFiltrati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16))
        Me._cmdImportUtentiFiltrati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Cognome", System.Data.SqlDbType.VarChar, 256))
        Me._cmdImportUtentiFiltrati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitazione", System.Data.SqlDbType.VarChar, 1))
        CType(Me._dsUtenti, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region
    Public Function GetList() As Bil.DSAnaUtenti
        Dim ds As New DSAnaUtenti
        Try
            _cnAnaUtente.Open()
            _daAnaUtente.Fill(ds, ds.Utenti.TableName)
            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If _cnAnaUtente.State = ConnectionState.Open Then _cnAnaUtente.Close()

        End Try
    End Function

    Public Function GetListWithParametersBil(ByVal CodiceSDCBil As String, ByVal Cognome As String, ByVal Telefono As String, ByVal strAbilitazione As String) As DSAnaUtenti
        Try

            Dim ds As New DSAnaUtenti
			_cnAnaUtente.Open()

            If (CodiceSDCBil = String.Empty) AndAlso (Cognome = String.Empty) AndAlso _
                (Telefono = String.Empty) AndAlso (strAbilitazione = "entrambi") Then

                _daAnaUtente.Fill(ds, ds.Utenti.TableName)

            Else
                _daAnaUtente.SelectCommand.CommandText = _daAnaUtente.SelectCommand.CommandText & " WHERE 1=1 "


                If strAbilitazione <> "entrambi" Then
                    Dim abilitazione As Boolean
                    If strAbilitazione = "abilitato" Then
                        abilitazione = True
                    Else
                        abilitazione = False
                    End If

                    _daAnaUtente.SelectCommand.CommandText = _daAnaUtente.SelectCommand.CommandText & " AND StatoBilateraliUtente = @StatoBilateraliUtente"
                    _daAnaUtente.SelectCommand.Parameters.Add("@StatoBilateraliUtente", abilitazione)
                End If

                If (CodiceSDCBil.Length > 0) Then
                    _daAnaUtente.SelectCommand.CommandText = _daAnaUtente.SelectCommand.CommandText & " AND CodiceUtenteSDC like @CodiceUtenteSDC"
                    _daAnaUtente.SelectCommand.Parameters.Add("@CodiceUtenteSDC", CodiceSDCBil & "%")

                End If

                If (Cognome.Length > 0) Then
                    _daAnaUtente.SelectCommand.CommandText = _daAnaUtente.SelectCommand.CommandText & " AND Cognome like @Cognome"
                    _daAnaUtente.SelectCommand.Parameters.Add("@Cognome", Cognome & "%")

                End If

                If Telefono.Length > 0 Then
                    _daAnaUtente.SelectCommand.CommandText = _daAnaUtente.SelectCommand.CommandText & " AND Telefono like @Telefono"
                    _daAnaUtente.SelectCommand.Parameters.Add("@Telefono", Telefono & "%")

                End If

                _daAnaUtente.Fill(ds, ds.Utenti.TableName)

            End If

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If _cnAnaUtente.State = ConnectionState.Open Then _cnAnaUtente.Close()
		End Try

    End Function

    Public Sub SaveListDS(ByVal ds As DSAnaUtenti)
		Dim tr As System.Data.SqlClient.SqlTransaction

        Try
            _cnAnaUtente.Open()

			tr = _cnAnaUtente.BeginTransaction()

			SetTransaction(_daAnaUtente, tr)
			_daAnaUtente.Update(ds, ds.Utenti.TableName)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If _cnAnaUtente.State = ConnectionState.Open Then _cnAnaUtente.Close()
		End Try
	End Sub

	Public Function CanUpdate(ByVal ds As DSAnaUtenti) As Boolean
		Dim tr As System.Data.SqlClient.SqlTransaction

		Try
			_cnAnaUtente.Open()

			tr = _cnAnaUtente.BeginTransaction()
			SetTransaction(_daAnaUtente, tr)
			_daAnaUtente.Update(ds, ds.Utenti.TableName)

			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing

			Return True

		Catch sex As SqlClient.SqlException
			Return False

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If _cnAnaUtente.State = ConnectionState.Open Then _cnAnaUtente.Close()
		End Try
	End Function

	' STR # 132
	Public Sub ImportUtenti()
		Try
			_cnAnaUtente.ConnectionString = GetConnectionString()
			_cnAnaUtente.Open()

			_cmdImportUtentiFiltrati.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cnAnaUtente.Dispose()
		End Try
	End Sub
	' STR # 132
	Public Sub ImportUtentiFiltrati(ByVal CodiceUtenteSDC As String, ByVal CognomeSDC As String, ByVal Abilitazione As String)
		Try
			_cnAnaUtente.ConnectionString = GetConnectionString()
			_cnAnaUtente.Open()

			_cmdImportUtentiFiltrati.Parameters.Item("@CodiceUtenteSDC").Value = CodiceUtenteSDC
			_cmdImportUtentiFiltrati.Parameters.Item("@Cognome").Value = CognomeSDC

			If Abilitazione = "entrambi" Then
				_cmdImportUtentiFiltrati.Parameters.Item("@Abilitazione").Value = DBNull.Value
			ElseIf Abilitazione = "abilitato" Then
				_cmdImportUtentiFiltrati.Parameters.Item("@Abilitazione").Value = "1"
			Else
				_cmdImportUtentiFiltrati.Parameters.Item("@Abilitazione").Value = "0"
			End If

			_cmdImportUtentiFiltrati.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cnAnaUtente.Dispose()
		End Try
	End Sub

End Class
