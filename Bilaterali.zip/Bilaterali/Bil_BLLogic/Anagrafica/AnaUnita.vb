Imports System.Text
Public Class AnaUnita
    Inherits BilBLBase
#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        _cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _daUnita As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelectStarUnita As System.Data.SqlClient.SqlCommand
    Friend WithEvents _ds As Bil.DSAnaUnita
    Friend WithEvents _cmdUpdateUnita As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdInsertUnita As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdDeleteUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents _cmdImportUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdImportUnitaFiltrate As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me._cn = New System.Data.SqlClient.SqlConnection
		Me._daUnita = New System.Data.SqlClient.SqlDataAdapter
		Me._cmdDeleteUnita = New System.Data.SqlClient.SqlCommand
		Me._cmdInsertUnita = New System.Data.SqlClient.SqlCommand
		Me._cmdSelectStarUnita = New System.Data.SqlClient.SqlCommand
		Me._cmdUpdateUnita = New System.Data.SqlClient.SqlCommand
		Me._ds = New Bil.DSAnaUnita
		Me._cmdImportUnita = New System.Data.SqlClient.SqlCommand
		Me._cmdImportUnitaFiltrate = New System.Data.SqlClient.SqlCommand
		CType(Me._ds, System.ComponentModel.ISupportInitialize).BeginInit()
		'
		'_cn
		'
		Me._cn.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
		"rsist security info=False;initial catalog=Bilaterali"
		'
		'_daUnita
		'
		Me._daUnita.DeleteCommand = Me._cmdDeleteUnita
		Me._daUnita.InsertCommand = Me._cmdInsertUnita
		Me._daUnita.SelectCommand = Me._cmdSelectStarUnita
		Me._daUnita.UpdateCommand = Me._cmdUpdateUnita
		'
		'_cmdDeleteUnita
		'
		Me._cmdDeleteUnita.CommandText = "DELETE FROM dbo.Unita WHERE (CodiceUnitaSDC = @CodiceUnitaSDC) AND (CategoriaUnit" & _
		"aSDC = @CategoriaUnitaSDC)"
		Me._cmdDeleteUnita.Connection = Me._cn
		Me._cmdDeleteUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdDeleteUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'_cmdInsertUnita
		'
		Me._cmdInsertUnita.CommandText = "INSERT INTO dbo.Unita (CodiceUnitaSDC, CategoriaUnitaSDC, StatoBilateraliUnita, T" & _
		"SModifica) VALUES (@CodiceUnitaSDC, @CategoriaUnitaSDC, @StatoBilateraliUnita, @" & _
		"TSModifica)"
		Me._cmdInsertUnita.Connection = Me._cn
		Me._cmdInsertUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
		Me._cmdInsertUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
		Me._cmdInsertUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoBilateraliUnita", System.Data.SqlDbType.Bit, 1, "StatoBilateraliUnita"))
		Me._cmdInsertUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		'
		'_cmdSelectStarUnita
		'
		Me._cmdSelectStarUnita.CommandText = "SELECT dbo.Bil_AnaUnita.*, " & _
		"isnull(dbo.sdc_operatori.RagioneSociale, '') AS RagioneSocialeOperatoreDiRiferimentoSDC " & _
		"FROM dbo.Bil_AnaUnita " & _
		"left outer JOIN dbo.sdc_operatori " & _
		"ON dbo.sdc_operatori.CodiceOperatoreSDC = dbo.Bil_AnaUnita.CodiceOperatoreDiRiferimentoSDC"

		Me._cmdSelectStarUnita.Connection = Me._cn
		'
		'_cmdUpdateUnita
		'
		Me._cmdUpdateUnita.CommandText = "UPDATE dbo.Unita SET StatoBilateraliUnita = @StatoBilateraliUnita, TSModifica = @" & _
		"TSModifica WHERE (CategoriaUnitaSDC = @CategoriaUnita) AND (CodiceUnitaSDC = @Co" & _
		"diceUnitaSDC)"
		Me._cmdUpdateUnita.Connection = Me._cn
		Me._cmdUpdateUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoBilateraliUnita", System.Data.SqlDbType.Bit, 1, "StatoBilateraliUnita"))
		Me._cmdUpdateUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me._cmdUpdateUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnita", System.Data.SqlDbType.VarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdUpdateUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'_ds
		'
		Me._ds.CaseSensitive = True
		Me._ds.DataSetName = "DSAnaUnita"
		Me._ds.Locale = New System.Globalization.CultureInfo("it-IT")
		'
		'_cmdImportUnita
		'
		Me._cmdImportUnita.CommandText = "dbo.[spBilAddUnita]"
		Me._cmdImportUnita.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdImportUnita.Connection = Me._cn
		Me._cmdImportUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		'
		'_cmdImportUnitaFiltrate
		'
		Me._cmdImportUnitaFiltrate.CommandText = "dbo.[spBilAddUnitaFiltrate]"
		Me._cmdImportUnitaFiltrate.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdImportUnitaFiltrate.Connection = Me._cn
		Me._cmdImportUnitaFiltrate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdImportUnitaFiltrate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16))
		Me._cmdImportUnitaFiltrate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NomeUnita", System.Data.SqlDbType.VarChar, 256))
		Me._cmdImportUnitaFiltrate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16))
		Me._cmdImportUnitaFiltrate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreDiRiferimentoSDC", System.Data.SqlDbType.VarChar, 16))
		Me._cmdImportUnitaFiltrate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10))
		Me._cmdImportUnitaFiltrate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TipoUnita", System.Data.SqlDbType.VarChar, 1))
		CType(Me._ds, System.ComponentModel.ISupportInitialize).EndInit()

	End Sub

#End Region


	' CIAPS

    Public Function GetUnita() As DSAnaUnita
        Try
            _cn.Open()
            Dim ds As New DSAnaUnita
            _daUnita.Fill(ds, ds.AnaUnita.TableName)
            Return ds
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
    End Function

    Public Function GetUnita(ByVal Codice As String, _
                             ByVal Tipo As String, _
                             ByVal PSR As String, _
                             ByVal Zona As String, _
                             ByVal Descrizione As String, _
                             ByVal OperatoreResponsabile As String, _
                             ByVal RagioneSociale As String) As DSAnaUnita

        Try
            _cn.Open()
            Dim ds As New DSAnaUnita
            Dim qry As New StringBuilder
            Dim sAnd As String = " AND "
            ' CODICE
            If (Codice <> String.Empty) Then
                qry.Append(sAnd)
                qry.Append("CodiceUnitaSDC LIKE @CodiceUnitaSDC")
                _cmdSelectStarUnita.Parameters.Add("@CodiceUnitaSDC", Codice & "%")
            End If

            ' TIPO UNITA'
            If (Tipo <> String.Empty) Then
                qry.Append(sAnd)
                qry.Append("TipoUnita = @TipoUnita")
                _cmdSelectStarUnita.Parameters.Add("@TipoUnita", Tipo)
            End If

            ' PUNTO DI SCAMBIO RILEVANTE
            If (PSR <> String.Empty) Then
                qry.Append(sAnd)
                qry.Append("CodicePuntoDiScambioRilevanteSDC LIKE @PSR")
                _cmdSelectStarUnita.Parameters.Add("@PSR", PSR)
            End If

            ' ZONA
            If (Zona <> String.Empty) Then
                qry.Append(sAnd)
                qry.Append("CodiceZonaSDC LIKE @Zona")
                _cmdSelectStarUnita.Parameters.Add("@Zona", Zona)
            End If

            ' NOME UNITA'
            If (Descrizione <> String.Empty) Then
                qry.Append(sAnd)
                qry.Append("NomeUnita LIKE @NomeUnita")
                _cmdSelectStarUnita.Parameters.Add("@NomeUnita", Descrizione & "%")
            End If

            ' OPERATORE RESPONSABILE DELL'UNITA'
            If (OperatoreResponsabile <> String.Empty) Then
                qry.Append(sAnd)
                qry.Append("CodiceOperatoreDiRiferimentoSDC LIKE @CodiceOperatoreRif")
                _cmdSelectStarUnita.Parameters.Add("@CodiceOperatoreRif", OperatoreResponsabile & "%")
            End If

            ' RAGIONE SOCIALE OPERATORE RESPONSABILE DELL'UNITA'
            If (RagioneSociale <> String.Empty) Then
                qry.Append(sAnd)
                qry.Append("RagioneSociale LIKE @RagioneSociale")
                _cmdSelectStarUnita.Parameters.Add("@RagioneSociale", RagioneSociale & "%")
            End If

            If (qry.Length > 0) Then
                If (_cmdSelectStarUnita.CommandText.ToUpper().IndexOf("WHERE") < 0) Then
                    Dim s As String = qry.ToString()    ' la stringa costruita sopra
                    If s.StartsWith(sAnd) Then
                        s = s.Substring(sAnd.Length)
                    End If
                    _cmdSelectStarUnita.CommandText &= " WHERE " & s
                Else
                    _cmdSelectStarUnita.CommandText &= qry.ToString()
                End If
            End If
            _daUnita.Fill(ds, ds.AnaUnita.TableName)

            Return ds
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
    End Function

    Public Sub UpdateDataSet(ByVal ds As Bil.DSAnaUnita)
		Dim tr As System.Data.SqlClient.SqlTransaction

        Try
            _cn.Open()

			tr = _cn.BeginTransaction()
			SetTransaction(_daUnita, tr)
			_daUnita.Update(ds, ds.AnaUnita.TableName)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception

			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Sub

	' funzione che fa l'Update per vedere se il DB lo permette.
	' Poi COMUNQUE fa Rollback e 
	' ritorna True se si puo` updatare, false altrimenti.
	Public Function CanUpdate(ByVal ds As Bil.DSAnaUnita) As Boolean
		Dim tr As System.Data.SqlClient.SqlTransaction

		Try
            Me._cn.Open()

            tr = Me._cn.BeginTransaction()
			SetTransaction(_daUnita, tr)
			Me._daUnita.Update(ds, ds.AnaUnita.TableName)

			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing ' e` giusto ! e` per test

			Return True

		Catch sex As SqlClient.SqlException
			Return False

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try

	End Function

	Public Sub ImportUnita()
		Try
			_cn.ConnectionString = GetConnectionString()
			_cn.Open()

			_cmdImportUnita.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cn.Dispose()
		End Try
	End Sub

	Public Sub ImportUnitaFiltrate(ByVal CodiceUnitaSDC As String, ByVal NomeUnita As String, ByVal CodicePuntoDiScambioRilevanteSDC As String, ByVal CodiceOperatoreDiRiferimentoSDC As String, ByVal CodiceZonaSDC As String, ByVal TipoUnita As String)
		Try
			_cn.ConnectionString = GetConnectionString()
			_cn.Open()

			_cmdImportUnitaFiltrate.Parameters.Item("@CodiceUnitaSDC").Value = CodiceUnitaSDC
			_cmdImportUnitaFiltrate.Parameters.Item("@NomeUnita").Value = NomeUnita
			_cmdImportUnitaFiltrate.Parameters.Item("@CodicePuntoDiScambioRilevanteSDC").Value = CodicePuntoDiScambioRilevanteSDC
			_cmdImportUnitaFiltrate.Parameters.Item("@CodiceOperatoreDiRiferimentoSDC").Value = CodiceOperatoreDiRiferimentoSDC
			_cmdImportUnitaFiltrate.Parameters.Item("@CodiceZonaSDC").Value = CodiceZonaSDC
			_cmdImportUnitaFiltrate.Parameters.Item("@TipoUnita").Value = TipoUnita

			_cmdImportUnitaFiltrate.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cn.Dispose()
		End Try
	End Sub

End Class
