Imports System.Text

Public Class AnaOperatore
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        Me.cn.ConnectionString = GetConnectionString()
        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdSelect_Operatori As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdDelete_Operatori As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdate_Operatori As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdInsert_Operatori As System.Data.SqlClient.SqlCommand
    Friend WithEvents dsOperatori As Bil.DsAnaOperatori
    Friend WithEvents daOperatori As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelectOperatoriUtente As System.Data.SqlClient.SqlCommand
    Friend WithEvents daOperatoriUtente As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdUpdate_OperatoriUtente As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdDelete_OperatoriUtente As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdInsert_OperatoriUtente As System.Data.SqlClient.SqlCommand
    Friend WithEvents daRuoliOperatori As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelectRuoli As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdImportOperatori As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdImportOperatoriFiltrati As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdUpdateIsGMEOp As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.cmdSelect_Operatori = New System.Data.SqlClient.SqlCommand
		Me.cmdDelete_Operatori = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdate_Operatori = New System.Data.SqlClient.SqlCommand
		Me.cmdInsert_Operatori = New System.Data.SqlClient.SqlCommand
		Me.daOperatori = New System.Data.SqlClient.SqlDataAdapter
		Me.daOperatoriUtente = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdDelete_OperatoriUtente = New System.Data.SqlClient.SqlCommand
		Me.cmdInsert_OperatoriUtente = New System.Data.SqlClient.SqlCommand
		Me.cmdSelectOperatoriUtente = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdate_OperatoriUtente = New System.Data.SqlClient.SqlCommand
		Me.daRuoliOperatori = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSelectRuoli = New System.Data.SqlClient.SqlCommand
		Me._cmdImportOperatori = New System.Data.SqlClient.SqlCommand
		Me._cmdImportOperatoriFiltrati = New System.Data.SqlClient.SqlCommand
		Me._cmdUpdateIsGMEOp = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_user;data source=BILSVR1;persis" & _
		"t security info=False;initial catalog=Bilaterali"
		'
		'cmdSelect_Operatori
		'
		Me.cmdSelect_Operatori.CommandText = "SELECT dbo.SDC_Operatori.RagioneSociale, dbo.SDC_Operatori.Indirizzo1, dbo.SDC_Op" & _
		"eratori.Indirizzo2, dbo.SDC_Operatori.Citta, dbo.SDC_Operatori.Nazione, dbo.SDC_" & _
		"Operatori.CodiceFiscale, dbo.SDC_Operatori.PartitaIva, dbo.SDC_Operatori.Fax, db" & _
		"o.SDC_Operatori.Email, dbo.SDC_Operatori.ReferenteAmministrativo, dbo.SDC_Operat" & _
		"ori.SedeAmministrativa, dbo.SDC_Operatori.Abilitato, dbo.SDC_Operatori.Responsab" & _
		"ileAggiornamento, dbo.Operatori.StatoBilateraliOperatore, dbo.Operatori.TSModifi" & _
		"ca, dbo.Operatori.CodiceOperatoreSDC, dbo.Operatori.Amministratore, dbo.Operator" & _
		"i.IsGMEOp, ISNULL(NU.NroUnita, 0) AS NroUnita FROM dbo.Operatori INNER JOIN dbo." & _
		"SDC_Operatori ON dbo.Operatori.CodiceOperatoreSDC = dbo.SDC_Operatori.CodiceOper" & _
		"atoreSDC LEFT OUTER JOIN (SELECT CodiceOperatoreSDC, COUNT(*) NroUnita FROM dbo." & _
		"UnitRelate WHERE @dt >= DataInizioValidita AND @dt <= DataFineValidita GROUP BY " & _
		"CodiceOperatoreSDC) NU ON dbo.Operatori.CodiceOperatoreSDC = NU.CodiceOperatoreS" & _
		"DC"
		Me.cmdSelect_Operatori.Connection = Me.cn
		Me.cmdSelect_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@dt", System.Data.SqlDbType.DateTime))
		'
		'cmdDelete_Operatori
		'
		Me.cmdDelete_Operatori.CommandText = "DELETE FROM Operatori WHERE (CodiceOperatoreSDC = @CodiceOperatoreSDC)"
		Me.cmdDelete_Operatori.Connection = Me.cn
		Me.cmdDelete_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdUpdate_Operatori
		'
		Me.cmdUpdate_Operatori.CommandText = "UPDATE dbo.Operatori SET StatoBilateraliOperatore = @StatoBilateraliOperatore, TS" & _
		"Modifica = @TSModifica, Amministratore = @Amministratore WHERE (CodiceOperatoreS" & _
		"DC = @CodiceOperatoreSDC)"
		Me.cmdUpdate_Operatori.Connection = Me.cn
		Me.cmdUpdate_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoBilateraliOperatore", System.Data.SqlDbType.Bit, 1, "StatoBilateraliOperatore"))
		Me.cmdUpdate_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdUpdate_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Amministratore", System.Data.SqlDbType.Bit, 1, "Amministratore"))
		Me.cmdUpdate_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdInsert_Operatori
		'
		Me.cmdInsert_Operatori.CommandText = "INSERT INTO dbo.Operatori (CodiceOperatoreSDC, StatoBilateraliOperatore, TSModifi" & _
		"ca, Amministratore) VALUES (@CodiceOperatoreSDC, @StatoBilateraliOperatore, @TSM" & _
		"odifica, @Amministratore)"
		Me.cmdInsert_Operatori.Connection = Me.cn
		Me.cmdInsert_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me.cmdInsert_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoBilateraliOperatore", System.Data.SqlDbType.Bit, 1, "StatoBilateraliOperatore"))
		Me.cmdInsert_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdInsert_Operatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Amministratore", System.Data.SqlDbType.Bit, 1, "Amministratore"))
		'
		'daOperatori
		'
		Me.daOperatori.DeleteCommand = Me.cmdDelete_Operatori
		Me.daOperatori.InsertCommand = Me.cmdInsert_Operatori
		Me.daOperatori.SelectCommand = Me.cmdSelect_Operatori
		Me.daOperatori.UpdateCommand = Me.cmdUpdate_Operatori
		'
		'daOperatoriUtente
		'
		Me.daOperatoriUtente.DeleteCommand = Me.cmdDelete_OperatoriUtente
		Me.daOperatoriUtente.InsertCommand = Me.cmdInsert_OperatoriUtente
		Me.daOperatoriUtente.SelectCommand = Me.cmdSelectOperatoriUtente
		Me.daOperatoriUtente.UpdateCommand = Me.cmdUpdate_OperatoriUtente
		'
		'cmdDelete_OperatoriUtente
		'
		Me.cmdDelete_OperatoriUtente.CommandText = "DELETE FROM dbo.RelOperatoriUtenti WHERE (CodiceUtenteSDC = @CodiceUtenteSDC) AND" & _
		" (CodiceOperatoreSDC = @CodiceOPeratoreSDC) AND (Amministratore = @Amministrator" & _
		"e)"
		Me.cmdDelete_OperatoriUtente.Connection = Me.cn
		Me.cmdDelete_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDelete_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOPeratoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDelete_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Amministratore", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Amministratore", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdInsert_OperatoriUtente
		'
		Me.cmdInsert_OperatoriUtente.CommandText = "INSERT INTO dbo.RelOperatoriUtenti (CodiceUtenteSDC, CodiceOperatoreSDC, Abilitat" & _
		"o, TSIniValidita, TSEndValidita, CodiceRuolo, TSModifica, Amministratore) VALUES" & _
		" (@CodiceUtenteSDC, @CodiceOperatoreSDC, @Abilitato, @TSInValidita, @TSEndValidi" & _
		"ta, @CodiceRuolo, @TSModifica, @Amministratore)"
		Me.cmdInsert_OperatoriUtente.Connection = Me.cn
		Me.cmdInsert_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
		Me.cmdInsert_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me.cmdInsert_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"))
		Me.cmdInsert_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSInValidita", System.Data.SqlDbType.DateTime, 8, "TSIniValidita"))
		Me.cmdInsert_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSEndValidita", System.Data.SqlDbType.DateTime, 8, "TSEndValidita"))
		Me.cmdInsert_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceRuolo", System.Data.SqlDbType.VarChar, 32, "CodiceRuolo"))
		Me.cmdInsert_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdInsert_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Amministratore", System.Data.SqlDbType.Bit, 1, "Amministratore"))
		'
		'cmdSelectOperatoriUtente
		'
		Me.cmdSelectOperatoriUtente.CommandText = "SELECT dbo.Bil_UtentiOperatori.* FROM dbo.Bil_UtentiOperatori"
		Me.cmdSelectOperatoriUtente.Connection = Me.cn
		'
		'cmdUpdate_OperatoriUtente
		'
		Me.cmdUpdate_OperatoriUtente.CommandText = "UPDATE dbo.RelOperatoriUtenti SET Abilitato = @Abilitato, TSIniValidita = @TSInVa" & _
		"lidita, TSEndValidita = @TSEndValidita, TSModifica = @TSModifica, CodiceRuolo = " & _
		"@CodiceRuolo WHERE (CodiceOperatoreSDC = @CodiceOperatoreSDC) AND (CodiceUtenteS" & _
		"DC = @CodiceUtenteSDC) AND (Amministratore = @Amministratore)"
		Me.cmdUpdate_OperatoriUtente.Connection = Me.cn
		Me.cmdUpdate_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"))
		Me.cmdUpdate_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSInValidita", System.Data.SqlDbType.DateTime, 8, "TSIniValidita"))
		Me.cmdUpdate_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSEndValidita", System.Data.SqlDbType.DateTime, 8, "TSEndValidita"))
		Me.cmdUpdate_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdUpdate_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceRuolo", System.Data.SqlDbType.VarChar, 32, "CodiceRuolo"))
		Me.cmdUpdate_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdate_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdate_OperatoriUtente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Amministratore", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Amministratore", System.Data.DataRowVersion.Original, Nothing))
		'
		'daRuoliOperatori
		'
		Me.daRuoliOperatori.SelectCommand = Me.cmdSelectRuoli
		'
		'cmdSelectRuoli
		'
		Me.cmdSelectRuoli.CommandText = "SELECT CodiceRuolo, DescrizioneRuolo FROM dbo.Ruoli"
		Me.cmdSelectRuoli.Connection = Me.cn
		'
		'_cmdImportOperatori
		'
		Me._cmdImportOperatori.CommandText = "dbo.[spBilAddOperatori]"
		Me._cmdImportOperatori.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdImportOperatori.Connection = Me.cn
		Me._cmdImportOperatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		'
		'_cmdImportOperatoriFiltrati
		'
		Me._cmdImportOperatoriFiltrati.CommandText = "dbo.[spBilAddOperatoriFiltrati]"
		Me._cmdImportOperatoriFiltrati.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdImportOperatoriFiltrati.Connection = Me.cn
		Me._cmdImportOperatoriFiltrati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdImportOperatoriFiltrati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16))
		Me._cmdImportOperatoriFiltrati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitazione", System.Data.SqlDbType.VarChar, 1))
		Me._cmdImportOperatoriFiltrati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RagioneSociale", System.Data.SqlDbType.VarChar, 256))
		'
		'_cmdUpdateIsGMEOp
		'
		Me._cmdUpdateIsGMEOp.CommandText = "UPDATE dbo.Operatori SET IsGMEOp = @IsGMEOp WHERE (CodiceOperatoreSDC = @CodiceOp" & _
		"eratoreSDC)"
		Me._cmdUpdateIsGMEOp.Connection = Me.cn
		Me._cmdUpdateIsGMEOp.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IsGMEOp", System.Data.SqlDbType.Bit, 1, "IsGMEOp"))
		Me._cmdUpdateIsGMEOp.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))

	End Sub

#End Region

	' CIAPS

	Public Function GetList(ByVal dtFlusso As DateTime) As DsAnaOperatori
		' Controllo il parametro Data di Flusso
		If dtFlusso = dtFlusso.MinValue Then
			dtFlusso = DateTime.Today
		End If

		Dim ds As New DsAnaOperatori
		Try
			Me.cn.Open()
			Me.daOperatori.SelectCommand.Parameters("@dt").Value = dtFlusso
			Me.daOperatori.Fill(ds, ds.Operatori.TableName)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function
	Public Function GetListOperatoriUtente() As DSAnaOperatoriUtente

		Dim ds As New DSAnaOperatoriUtente
		Try
			Me.cn.Open()
			Me.daOperatoriUtente.Fill(ds, ds.OperatoriUtente.TableName)

			' Metto anche i ruoli all'interno dello stesso dataset
			Me.daRuoliOperatori.Fill(ds, ds.Ruoli.TableName)

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function
	Public Function GetListOperatoriNonRappresentati(ByVal idUtente As String) As DsAnaOperatori

		Dim ds As New DsAnaOperatori
		Try
			Me.cn.Open()
			Dim c As New StringBuilder
			c.Append(" AND dbo.Operatori.CodiceoperatoreSDC NOT IN (")
			c.Append("  SELECT CodiceOperatoreSDC ")
			c.Append("  FROM  dbo.RelOperatoriUtenti OU WHERE CodiceUtenteSDC = @CodiceUtente)")
			daOperatori.SelectCommand.CommandText &= c.ToString()
			daOperatori.SelectCommand.Parameters.Add("@CodiceUtente", idUtente)
			Me.daOperatori.Fill(ds, ds.Operatori.TableName)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function
	Public Sub SaveListaOperatoriUtente(ByVal ds As DSAnaOperatoriUtente)
		Dim tr As System.Data.SqlClient.SqlTransaction

		Try
			Me.cn.Open()

			tr = Me.cn.BeginTransaction()
			SetTransaction(daOperatoriUtente, tr)
			Me.daOperatoriUtente.Update(ds, ds.OperatoriUtente.TableName)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Sub
	Public Sub SaveListDS(ByVal ds As DsAnaOperatori)
		Dim tr As System.Data.SqlClient.SqlTransaction

		Try
			Me.cn.Open()

			tr = Me.cn.BeginTransaction()
			SetTransaction(daOperatori, tr)
			Me.daOperatori.Update(ds, ds.Operatori.TableName)
			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()

		End Try
	End Sub

	' funzione che fa l'Update per vedere se il DB lo permette.
	' Poi COMUNQUE fa Rollback e 
	' ritorna True se si puo` updatare, false altrimenti.
	Public Function CanUpdate(ByVal ds As DsAnaOperatori) As Boolean
		Dim tr As System.Data.SqlClient.SqlTransaction

		Try
			Me.cn.Open()

			tr = Me.cn.BeginTransaction()
			SetTransaction(daOperatori, tr)
			Me.daOperatori.Update(ds, ds.Operatori.TableName)

			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing

			Return True

		Catch sex As SqlClient.SqlException
			Return False

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	Public Function GetListWithParametersBil(ByVal strCodiceSDC As String, ByVal strRagioneSociale As String, ByVal strIndirizzo As String, ByVal strAbilitazione As String, ByVal dtFlusso As DateTime) As DsAnaOperatori
		' Controllo il parametro Data di Flusso
		If dtFlusso = dtFlusso.MinValue Then
			dtFlusso = DateTime.Today
		End If

		Try
			Dim ds As New DsAnaOperatori
			Me.cn.Open()

			Me.cmdSelect_Operatori.Parameters("@dt").Value = dtFlusso
			If strCodiceSDC.Length = 0 And strRagioneSociale.Length = 0 And _
			   strIndirizzo.Length = 0 And strAbilitazione = "entrambi" Then

				Me.daOperatori.Fill(ds, ds.Operatori.TableName)

			Else
				Me.daOperatori.SelectCommand.CommandText = Me.daOperatori.SelectCommand.CommandText & " WHERE 1=1 "


				If strAbilitazione <> "entrambi" Then
					Dim abilitazione As Boolean
					If strAbilitazione = "abilitato" Then
						abilitazione = True
					Else
						abilitazione = False
					End If

					Me.daOperatori.SelectCommand.CommandText = Me.daOperatori.SelectCommand.CommandText & " AND statobilateraliOperatore =@statobilateraliOperatore"
					Me.daOperatori.SelectCommand.Parameters.Add("@statobilateraliOperatore", abilitazione)
				End If

				If strCodiceSDC.Length > 0 Then
					Me.daOperatori.SelectCommand.CommandText = Me.daOperatori.SelectCommand.CommandText & " AND SDC_Operatori.codiceOperatoreSDC like @codiceOperatoreSDC"
					Me.daOperatori.SelectCommand.Parameters.Add("@codiceOperatoreSDC", strCodiceSDC & "%")

				End If

				If strRagioneSociale.Length > 0 Then
					Me.daOperatori.SelectCommand.CommandText = Me.daOperatori.SelectCommand.CommandText & " AND RagioneSociale like @RagioneSociale"
					Me.daOperatori.SelectCommand.Parameters.Add("@RagioneSociale", strRagioneSociale & "%")

				End If

				If strIndirizzo.Length > 0 Then
					'Me.daOperatori.SelectCommand.CommandText = Me.daOperatori.SelectCommand.CommandText & " AND Telefono like @Indirizzo"
					Me.daOperatori.SelectCommand.CommandText = Me.daOperatori.SelectCommand.CommandText & " AND ( Indirizzo1 like @Indirizzo1 OR Indirizzo2 like @Indirizzo2)"
					Me.daOperatori.SelectCommand.Parameters.Add("@Indirizzo1", strIndirizzo & "%")
					Me.daOperatori.SelectCommand.Parameters.Add("@Indirizzo2", strIndirizzo & "%")

				End If

				Me.daOperatori.Fill(ds, ds.Operatori.TableName)

			End If

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	Public Function GetRuoliOperatori() As DSAnaOperatoriUtente
		Try
			Dim ds As New DSAnaOperatoriUtente
			Me.cn.Open()
			Me.daRuoliOperatori.Fill(ds, ds.Ruoli.TableName)

			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Sub ImportOperatori()
		Try
			_cn.ConnectionString = GetConnectionString()
			_cn.Open()
			_cmdImportOperatori.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cn.Dispose()
		End Try
	End Sub

	Public Sub ImportOperatoriFiltrati(ByVal CodiceOperatoreSDC As String, ByVal Abilitazione As String, ByVal RagioneSociale As String)
		Try
			_cn.ConnectionString = GetConnectionString()
			_cn.Open()

			_cmdImportOperatoriFiltrati.Parameters.Item("@CodiceOperatoreSDC").Value = CodiceOperatoreSDC
			If Abilitazione = "entrambi" Then
				_cmdImportOperatoriFiltrati.Parameters.Item("@Abilitazione").Value = DBNull.Value
			ElseIf Abilitazione = "abilitato" Then
				_cmdImportOperatoriFiltrati.Parameters.Item("@Abilitazione").Value = "1"
			Else
				_cmdImportOperatoriFiltrati.Parameters.Item("@Abilitazione").Value = "0"
			End If

			_cmdImportOperatoriFiltrati.Parameters.Item("@RagioneSociale").Value = RagioneSociale
			_cmdImportOperatoriFiltrati.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cn.Dispose()
		End Try
	End Sub


	Public Sub AllineaAnagraficaOperatoriMercato(ByVal bSync As Boolean, ByVal runningOperator As String)
		Dim Data As DateTime = DateTime.Now.Date
		If bSync Then
			AllineaAnagraficaOperatoriMercatoWorker(Data)
		Else
			smTrace(String.Format("allOpGME: inizio allineamento anagrafica operatori del Mercato Elettrico {0}", Data))
			Dim st As New Object
			BatchSerializer.BS.AddBatch(AddressOf AnaOperatore.AllineaAnagraficaOperatoriMercatoAsync, st, "ALLOP", "Allineam. Anagrafica Operatori di Mercato", DateTime.MinValue, runningOperator)
		End If
	End Sub

	Private Shared Sub AllineaAnagraficaOperatoriMercatoAsync(ByVal obj As Object)
		' al momento obj non serve
		Dim data As DateTime = DateTime.Now
		Dim blAnaOp As AnaOperatore = New AnaOperatore
		blAnaOp.AllineaAnagraficaOperatoriMercatoWorker(data)
		blAnaOp.Dispose()
	End Sub

	Private Sub AllineaAnagraficaOperatoriMercatoWorker(ByVal dt As DateTime)
		' Creo un array bidimensionale contenente le coppie (CodiceOperatoreSDC, IsGMEOp) - 200 coppie
		Dim OperatoriME(0) As String
		Dim codiceOp As String

		Try
			' TODO: chiamo il metodo del WEB service preposto
			' e ottengo una lista di coppie (CodiceOperatoreSDC, IsGMEOp)
			' nella variabile OperatoriME
			Dim ws As New Bil.gmeBridge.BilMGPBridge
			ws.WSAuthHeaderValue = New Bil.gmeBridge.WSAuthHeader
			Bil_Crypt.WSClient.Setup(ws, ws.WSAuthHeaderValue.Username, ws.WSAuthHeaderValue.Password, "Bil_MGPBridgeWS")
			ws.OperatoriMEAttivi(OperatoriME)

			_cn.ConnectionString = GetConnectionString()
			_cn.Open()

			' Resetto tutti i bit a 0 (IsGMEOp = "false")
			Dim _cmdResetIsGMEOp As New SqlClient.SqlCommand
			_cmdResetIsGMEOp.Connection = _cn
			_cmdResetIsGMEOp.CommandText = "UPDATE Operatori SET IsGMEOp = 0"
			_cmdResetIsGMEOp.ExecuteNonQuery()

			Dim i As Integer
			For i = 0 To OperatoriME.Length - 1
				_cmdUpdateIsGMEOp.Parameters.Item("@CodiceOperatoreSDC").Value = OperatoriME(i)
				_cmdUpdateIsGMEOp.Parameters.Item("@IsGMEOp").Value = True
				_cmdUpdateIsGMEOp.ExecuteNonQuery()
			Next
		Catch ex As Exception
			' smError(ex)
			smError(ex, String.Format("allOpGME: attivita` fallita {0}", ex.Message))
			Throw
		Finally
			_cn.Dispose()
			smTrace(String.Format("allOpGME: attivita` completata"))
		End Try



	End Sub

End Class
