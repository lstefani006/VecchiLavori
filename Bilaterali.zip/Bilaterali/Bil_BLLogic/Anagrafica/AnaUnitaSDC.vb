Public Class AnaUnitaSDC
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        _cnUnitaSDC.ConnectionString = GetConnectionString()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cnUnitaSDC As System.Data.SqlClient.SqlConnection
    Friend WithEvents _da As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelectStarUnitaSDC As System.Data.SqlClient.SqlCommand
    Friend WithEvents _ds As Bil.DSAnaUnitaSDC
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me._cnUnitaSDC = New System.Data.SqlClient.SqlConnection
		Me._da = New System.Data.SqlClient.SqlDataAdapter
		Me._cmdSelectStarUnitaSDC = New System.Data.SqlClient.SqlCommand
		Me._ds = New Bil.DSAnaUnitaSDC
		CType(Me._ds, System.ComponentModel.ISupportInitialize).BeginInit()
		'
		'_cnUnitaSDC
		'
		Me._cnUnitaSDC.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=sa;data source=BILSVR1;persist " & _
		"security info=False;initial catalog=Bilaterali"
		'
		'_da
		'
		Me._da.SelectCommand = Me._cmdSelectStarUnitaSDC
		'
		'_cmdSelectStarUnitaSDC
		'
		Me._cmdSelectStarUnitaSDC.CommandText = "SELECT " & _
		"1 AS StatoBilateraliUnita, " & _
		"SDC_Unita.TSModifica AS TSModifica, " & _
		"SDC_Unita.CodiceUnitaSDC, " & _
		"SDC_Unita.CategoriaUnitaSDC, " & _
		"SDC_Unita.NomeUnita, " & _
		"SDC_Unita.TipoUnita, " & _
		"SDC_Unita.CoefficientePerdita, " & _
		"SDC_Unita.CodicePuntoDiScambioRilevanteSDC," & _
		"SDC_Unita.PotenzaMassimaMWh, " & _
		"SDC_Unita.PotenzaMinimaMWh, " & _
		"SDC_Unita.OrdineDiMerito, " & _
		"SDC_Unita.CodiceOperatoreDiRiferimentoSDC, " & _
		"isnull(SDC_Operatori.RagioneSociale, '') AS RagioneSocialeOperatoreDiRiferimentoSDC, " & _
		"SDC_Unita.Abilitata, " & _
		"SDC_Unita.TSModifica AS SDC_Unita_TSModifica, " & _
		"SDC_Unita.ResponsabileAggiornamento, " & _
		"SDC_PuntiDiScambioRilevanti.CodiceZonaSDC, " & _
		"CASE ISNULL(dbo.SDC_Unita_MarketInformation.Eligibility, 'Able') WHEN 'Able' THEN 1 ELSE 0 END AS SDC_MI " & _
		"FROM SDC_Unita " & _
		"INNER JOIN SDC_PuntiDiScambioRilevanti " & _
		"ON SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC " & _
		"LEFT OUTER JOIN SDC_Operatori " & _
		"ON SDC_Operatori.CodiceOperatoreSDC = SDC_Unita.CodiceOperatoreDiRiferimentoSDC " & _
		"LEFT OUTER JOIN Unita " & _
		"ON SDC_Unita.CodiceUnitaSDC = Unita.CodiceUnitaSDC " & _
		"AND SDC_Unita.CategoriaUnitaSDC = Unita.CategoriaUnitaSDC " & _
		"LEFT OUTER JOIN SDC_Unita_MarketInformation " & _
		"ON Unita.CodiceUnitaSDC = SDC_Unita_MarketInformation.CodiceUnitaSDC " & _
		"AND Unita.CategoriaUnitaSDC = SDC_Unita_MarketInformation.CategoriaUnitaSDC " & _
		"AND SDC_Unita_MarketInformation.MarketCode = 'MGP' " & _
		"WHERE (Unita.CodiceUnitaSDC IS NULL)"

		Me._cmdSelectStarUnitaSDC.Connection = Me._cnUnitaSDC
		'
		'_ds
		'
		Me._ds.CaseSensitive = True
		Me._ds.DataSetName = "DSAnaUnitaSDC"
		Me._ds.Locale = New System.Globalization.CultureInfo("it-IT")
		CType(Me._ds, System.ComponentModel.ISupportInitialize).EndInit()

	End Sub

#End Region

    Public Function GetUnitaSDC() As DSAnaUnitaSDC
        Try
            _cnUnitaSDC.Open()
            Dim ds As New DSAnaUnitaSDC
            _da.Fill(ds, ds.AnaUnitaSDC.TableName)
            Return ds
        Catch ex As Exception
            smError(ex)
            Throw
		Finally
			If _cnUnitaSDC.State = ConnectionState.Open Then _cnUnitaSDC.Close()
		End Try
    End Function
End Class
