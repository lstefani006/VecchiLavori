Public Class AnaUtenteSDC
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        _cnUtenteSDC.ConnectionString = GetConnectionString()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cnUtenteSDC As System.Data.SqlClient.SqlConnection
    Friend WithEvents _daUtentiSDC As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelectUtentiSDC As System.Data.SqlClient.SqlCommand
    Friend WithEvents _ds As Bil.DSAnaUtentiSDC
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cnUtenteSDC = New System.Data.SqlClient.SqlConnection
        Me._daUtentiSDC = New System.Data.SqlClient.SqlDataAdapter
        Me._cmdSelectUtentiSDC = New System.Data.SqlClient.SqlCommand
        Me._ds = New Bil.DSAnaUtentiSDC
        CType(Me._ds, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cnUtenteSDC
        '
        Me._cnUtenteSDC.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
        "rsist security info=False;initial catalog=Bilaterali"
        '
        '_daUtentiSDC
        '
        Me._daUtentiSDC.SelectCommand = Me._cmdSelectUtentiSDC
        '
        '_cmdSelectUtentiSDC
        '
        Me._cmdSelectUtentiSDC.CommandText = "SELECT dbo.Utenti.StatoBilateraliUtente, dbo.SDC_Utenti.* FROM dbo.SDC_Utenti LEF" & _
        "T OUTER JOIN dbo.Utenti ON dbo.SDC_Utenti.CodiceUtenteSDC = dbo.Utenti.CodiceUte" & _
        "nteSDC WHERE (dbo.Utenti.CodiceUtenteSDC IS NULL)"
        Me._cmdSelectUtentiSDC.Connection = Me._cnUtenteSDC
        '
        '_ds
        '
        Me._ds.DataSetName = "DSAnaUtentiSDC"
        Me._ds.Locale = New System.Globalization.CultureInfo("it-IT")
        CType(Me._ds, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region
    Public Function GetList() As Bil.DSAnaUtentiSDC
        Dim ds As New DSAnaUtentiSDC
        Try
            _cnUtenteSDC.Open()
            _daUtentiSDC.Fill(ds, ds.SDC_Utenti.TableName)
            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
		Finally
			If _cnUtenteSDC.State = ConnectionState.Open Then _cnUtenteSDC.Close()
		End Try
    End Function

    Public Function GetListWithParametersSDC(ByVal CodiceUtenteSDC As String, ByVal Cognome As String, ByVal strAbilitazione As String) As DSAnaUtentiSDC
        Try

            Dim ds As New DSAnaUtentiSDC
			_cnUtenteSDC.Open()

			If Not ((CodiceUtenteSDC = String.Empty) AndAlso (Cognome = String.Empty) AndAlso _
				(strAbilitazione = "entrambi")) Then

				If strAbilitazione <> "entrambi" Then
					Dim abilitazione As Integer
					If strAbilitazione = "abilitato" Then
						abilitazione = 1
					Else
						abilitazione = 0
					End If

					_daUtentiSDC.SelectCommand.CommandText += " AND SDC_Utenti.Abilitato = @Abilitato"
					_daUtentiSDC.SelectCommand.Parameters.Add("@Abilitato", abilitazione)
				End If

				If (Cognome.Length > 0) Then
					_daUtentiSDC.SelectCommand.CommandText += " AND Cognome like @Cognome"
					_daUtentiSDC.SelectCommand.Parameters.Add("@Cognome", Cognome & "%")

				End If

				If (CodiceUtenteSDC.Length > 0) Then
					_daUtentiSDC.SelectCommand.CommandText += " AND SDC_Utenti.CodiceUtenteSDC like @CodiceUtenteSDC"
					_daUtentiSDC.SelectCommand.Parameters.Add("@CodiceUtenteSDC", CodiceUtenteSDC & "%")

				End If

				' _daUtentiSDC.Fill(ds, ds.SDC_Utenti.TableName)

			End If
			_daUtentiSDC.Fill(ds, ds.SDC_Utenti.TableName)

			Return ds

		Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If _cnUtenteSDC.State = ConnectionState.Open Then _cnUtenteSDC.Close()
		End Try

    End Function

End Class
