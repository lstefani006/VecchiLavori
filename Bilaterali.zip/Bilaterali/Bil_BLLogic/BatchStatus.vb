Imports SystemMonitor
Imports System.Configuration
Imports System.Xml
Imports System.Xml.Schema
Imports System.Data.SqlClient
Public Class BatchStatus
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdUpdateStart As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdateEnd As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdInsertQueue As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdSelectBatchDelGiorno As System.Data.SqlClient.SqlCommand
    Friend WithEvents daBatchDelGiorno As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdDeleteBatchStatus As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdateProgress As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdSPGetNC As System.Data.SqlClient.SqlCommand
    Friend WithEvents daSPGetNC As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents daSPGetNUOverQty As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSPGetNUOverQty As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdSPGetNumUnit_OverPgm As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.cmdUpdateStart = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdateEnd = New System.Data.SqlClient.SqlCommand
		Me.cmdInsertQueue = New System.Data.SqlClient.SqlCommand
		Me.cmdSelectBatchDelGiorno = New System.Data.SqlClient.SqlCommand
		Me.daBatchDelGiorno = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdDeleteBatchStatus = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdateProgress = New System.Data.SqlClient.SqlCommand
		Me.cmdSPGetNC = New System.Data.SqlClient.SqlCommand
		Me.daSPGetNC = New System.Data.SqlClient.SqlDataAdapter
		Me.daSPGetNUOverQty = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSPGetNUOverQty = New System.Data.SqlClient.SqlCommand
		Me.cmdSPGetNumUnit_OverPgm = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=True;initial catalog=Bilaterali;password=bilaterali"
		'
		'cmdUpdateStart
		'
		Me.cmdUpdateStart.CommandText = "UPDATE dbo.BatchStatus SET Status = @Status, TSStart = GETDATE() WHERE (BatchId =" & _
		" @BatchId)"
		Me.cmdUpdateStart.Connection = Me.cn
		Me.cmdUpdateStart.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.VarChar, 1, "Status"))
		Me.cmdUpdateStart.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchId", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "BatchId", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdUpdateEnd
		'
		Me.cmdUpdateEnd.CommandText = "UPDATE dbo.BatchStatus SET TSEnd = GETDATE(), Status = @Status, TSModifica = GETD" & _
		"ATE() WHERE (BatchId = @BatchId)"
		Me.cmdUpdateEnd.Connection = Me.cn
		Me.cmdUpdateEnd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.VarChar, 1, "Status"))
		Me.cmdUpdateEnd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchId", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "BatchId", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdInsertQueue
		'
		Me.cmdInsertQueue.CommandText = "INSERT INTO dbo.BatchStatus (BatchId, Status, TSQueue, Description, BatchCode, TS" & _
		"DataFlusso) VALUES (@BatchId, @Status, @TSQueue, @Description, @BatchCode, @TSDa" & _
		"taFlusso)"
		Me.cmdInsertQueue.Connection = Me.cn
		Me.cmdInsertQueue.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchId", System.Data.SqlDbType.VarChar, 32, "BatchId"))
		Me.cmdInsertQueue.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.VarChar, 1, "Status"))
		Me.cmdInsertQueue.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSQueue", System.Data.SqlDbType.DateTime, 8, "TSQueue"))
		Me.cmdInsertQueue.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Description", System.Data.SqlDbType.VarChar, 256, "Description"))
		Me.cmdInsertQueue.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchCode", System.Data.SqlDbType.VarChar, 10, "BatchCode"))
		Me.cmdInsertQueue.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSDataFlusso", System.Data.SqlDbType.DateTime, 4, "TSDataFlusso"))
		'
		'cmdSelectBatchDelGiorno
		'
		Me.cmdSelectBatchDelGiorno.CommandText = "SELECT BatchId, Status, TSQueue, BatchCode, Description, TSStart, TSEnd, Progress" & _
		", TSModifica, TSDataFlusso FROM dbo.BatchStatus WHERE (TSDataFlusso = @d) OR (TS" & _
		"DataFlusso IS NULL) AND (CONVERT(datetime, CONVERT(varchar, TSQueue, 112)) = @q)" & _
		" ORDER BY TSQueue"
		Me.cmdSelectBatchDelGiorno.Connection = Me.cn
		Me.cmdSelectBatchDelGiorno.Parameters.Add(New System.Data.SqlClient.SqlParameter("@d", System.Data.SqlDbType.DateTime, 4, "TSDataFlusso"))
		Me.cmdSelectBatchDelGiorno.Parameters.Add(New System.Data.SqlClient.SqlParameter("@q", System.Data.SqlDbType.DateTime))
		'
		'daBatchDelGiorno
		'
		Me.daBatchDelGiorno.SelectCommand = Me.cmdSelectBatchDelGiorno
		'
		'cmdDeleteBatchStatus
		'
		Me.cmdDeleteBatchStatus.CommandText = "DELETE FROM dbo.BatchStatus WHERE (Status = 'E') OR (Status = 'A')"
		Me.cmdDeleteBatchStatus.Connection = Me.cn
		'
		'cmdUpdateProgress
		'
		Me.cmdUpdateProgress.CommandText = "UPDATE dbo.BatchStatus SET Progress = @Progress, TSModifica = GETDATE() WHERE (Ba" & _
		"tchId = @BatchId)"
		Me.cmdUpdateProgress.Connection = Me.cn
		Me.cmdUpdateProgress.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Progress", System.Data.SqlDbType.VarChar, 256, "Progress"))
		Me.cmdUpdateProgress.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchId", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "BatchId", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdSPGetNC
		'
		Me.cmdSPGetNC.CommandText = "dbo.[spGetNC]"
		Me.cmdSPGetNC.CommandType = System.Data.CommandType.StoredProcedure
		Me.cmdSPGetNC.Connection = Me.cn
		Me.cmdSPGetNC.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.cmdSPGetNC.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		'
		'daSPGetNC
		'
		Me.daSPGetNC.SelectCommand = Me.cmdSPGetNC
		'
		'daSPGetNUOverQty
		'
		Me.daSPGetNUOverQty.SelectCommand = Me.cmdSPGetNUOverQty
		'
		'cmdSPGetNUOverQty
		'
		Me.cmdSPGetNUOverQty.CommandText = "dbo.[spGetNU_OverQty]"
		Me.cmdSPGetNUOverQty.CommandType = System.Data.CommandType.StoredProcedure
		Me.cmdSPGetNUOverQty.Connection = Me.cn
		Me.cmdSPGetNUOverQty.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.cmdSPGetNUOverQty.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.cmdSPGetNUOverQty.Parameters.Add(New System.Data.SqlClient.SqlParameter("@kPowerP", System.Data.SqlDbType.Float, 8))
		Me.cmdSPGetNUOverQty.Parameters.Add(New System.Data.SqlClient.SqlParameter("@kPowerC", System.Data.SqlDbType.Float, 8))
		Me.cmdSPGetNUOverQty.Parameters.Add(New System.Data.SqlClient.SqlParameter("@kPowerMp", System.Data.SqlDbType.Float, 8))
		Me.cmdSPGetNUOverQty.Parameters.Add(New System.Data.SqlClient.SqlParameter("@kPowerMc", System.Data.SqlDbType.Float, 8))
		'
		'cmdSPGetNumUnit_OverPgm
		'
		Me.cmdSPGetNumUnit_OverPgm.CommandText = "dbo.[spGetNumUnit_OverPgm]"
		Me.cmdSPGetNumUnit_OverPgm.CommandType = System.Data.CommandType.StoredProcedure
		Me.cmdSPGetNumUnit_OverPgm.Connection = Me.cn
		Me.cmdSPGetNumUnit_OverPgm.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.cmdSPGetNumUnit_OverPgm.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.cmdSPGetNumUnit_OverPgm.Parameters.Add(New System.Data.SqlClient.SqlParameter("@kPowerP", System.Data.SqlDbType.Float, 8))
		Me.cmdSPGetNumUnit_OverPgm.Parameters.Add(New System.Data.SqlClient.SqlParameter("@kPowerC", System.Data.SqlDbType.Float, 8))
		Me.cmdSPGetNumUnit_OverPgm.Parameters.Add(New System.Data.SqlClient.SqlParameter("@kPowerMp", System.Data.SqlDbType.Float, 8))
		Me.cmdSPGetNumUnit_OverPgm.Parameters.Add(New System.Data.SqlClient.SqlParameter("@kPowerMc", System.Data.SqlDbType.Float, 8))

	End Sub

#End Region


    Public Function NewBatch(ByVal BatchCode As String, ByVal descr As String, ByVal tsDataFlusso As DateTime) As String
        cn.ConnectionString = MyBase.GetConnectionString
        Try
            cn.Open()

            Dim BatchId As String = MyBase.CreateNewId

            cmdInsertQueue.Parameters("@BatchId").Value = BatchId
            cmdInsertQueue.Parameters("@Status").Value = "Q"
            cmdInsertQueue.Parameters("@TSQueue").Value = DateTime.Now
            cmdInsertQueue.Parameters("@Description").Value = descr
            cmdInsertQueue.Parameters("@BatchCode").Value = BatchCode
            If tsDataFlusso = DateTime.MinValue Then
                cmdInsertQueue.Parameters("@TSDataFlusso").Value = System.DBNull.Value
            Else
                cmdInsertQueue.Parameters("@TSDataFlusso").Value = tsDataFlusso
            End If

            cmdInsertQueue.ExecuteNonQuery()

            Return BatchId

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Function


    Public Sub StartBatch(ByVal BatchId As String)
        cn.ConnectionString = MyBase.GetConnectionString
        Try
            cn.Open()
            Me.cmdUpdateStart.Parameters("@Status").Value = "R"
            Me.cmdUpdateStart.Parameters("@BatchId").Value = BatchId
            Me.cmdUpdateStart.ExecuteNonQuery()
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Sub

	Public Sub EndBatch(ByVal BatchId As String, ByVal aborted As Boolean)
		cn.ConnectionString = MyBase.GetConnectionString
		Try
			cn.Open()
			Dim status As String
			If aborted Then status = "A" Else status = "E"

			Me.cmdUpdateEnd.Parameters("@Status").Value = status
			Me.cmdUpdateEnd.Parameters("@BatchId").Value = BatchId

			Me.cmdUpdateEnd.ExecuteNonQuery()
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Sub

    Public Sub UpdateProgress(ByVal BatchId As String, ByVal Progress As String)

		cn.ConnectionString = MyBase.GetConnectionString

		SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, Progress)
        
        Try
            cn.Open()
            Me.cmdUpdateProgress.Parameters("@Progress").Value = Progress
            Me.cmdUpdateProgress.Parameters("@BatchId").Value = BatchId
            Me.cmdUpdateProgress.ExecuteNonQuery()
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Sub

    Public Function QueryBatchDelGiorno(ByVal d As DateTime) As DS_BatchStatus
        cn.ConnectionString = MyBase.GetConnectionString
        Dim bl As New Bil.Offerte

        Try
            cn.Open()
            Me.cmdSelectBatchDelGiorno.Parameters("@d").Value = d.Date
			'If bl.GeneraOfferteSoloPerIlGiornoDiDomani = False Then
			'    ' Addestramento: imposto la data di accodamento ad oggi
			'    Me.cmdSelectBatchDelGiorno.Parameters("@q").Value = System.DateTime.Today
			'Else    ' Operativita` normale
			'    Me.cmdSelectBatchDelGiorno.Parameters("@q").Value = d.AddDays(-1)
			'End If
			Me.cmdSelectBatchDelGiorno.Parameters("@q").Value = d.AddDays(-1)
			Dim ds As New DS_BatchStatus
            Me.daBatchDelGiorno.Fill(ds.BatchStatus)
            Return ds
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Function

    Public Sub DeleteBatchAE()
        cn.ConnectionString = MyBase.GetConnectionString
        Try
            cn.Open()
            cmdDeleteBatchStatus.ExecuteNonQuery()
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

    Public Function QueryWarnDelGiorno(ByVal d As DateTime) As DS_Warn
        Dim kPowerP As Double = 0   ' soglia da applicare per controllare che una unita` P non superi il max di produzione
        Dim kPowerC As Double = 0   ' soglia da applicare per controllare che una unita` C non superi il max di consumo
        Dim kPowerMp As Double = 0   ' soglia da applicare per controllare che una unita` M che produce non superi il max di produzione
        Dim kPowerMc As Double = 0   ' soglia da applicare per controllare che una unita` M che consuma non superi il max di consumo

        Try
            kPowerP = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerP"))
            kPowerC = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerC"))
            kPowerMp = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerMp"))
            kPowerMc = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerMc"))
        Catch ex As Exception
            smError("Mancano il coefficienti di soglia delle potenze max/min nel file di configurazione (kPowerP/kPowerC/kPowerMp/kPowerMc): il controllo sulla potenza non verra` effettuato")

            ' drastico ma efficace
            kPowerP = 0
            kPowerC = 0
            kPowerMp = 0
            kPowerMc = 0

            Return Nothing
        End Try

        cn.ConnectionString = MyBase.GetConnectionString

        Try
            cn.Open()
            Me.cmdSPGetNC.Parameters("@DataProgramma").Value = d.Date

            Dim ds As New DS_Warn

            Me.daSPGetNC.Fill(ds.NC_Pgm)

			'Me.cmdSPGetNUOverQty.Parameters("@DataProgramma").Value = d.Date
			'Me.cmdSPGetNUOverQty.Parameters("@kPowerP").Value = kPowerP
			'Me.cmdSPGetNUOverQty.Parameters("@kPowerC").Value = kPowerC
			'Me.cmdSPGetNUOverQty.Parameters("@kPowerMp").Value = kPowerMp
			'Me.cmdSPGetNUOverQty.Parameters("@kPowerMc").Value = kPowerMc

			'Me.daSPGetNUOverQty.Fill(ds.NU_OverPgm)

            Return ds
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Function

	Public Sub ControlloUnitaBatch(ByVal dataProgramma As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf ControlloUnitaAsync, dataProgramma, "CHKUNIT", "Controllo unit�", dataProgramma, runningOperator)
	End Sub

	Public Sub ControlloUnitaAsync(ByVal dataProgramma As Object)
		Dim bl As New BatchStatus
		bl.ControlloUnita(CType(dataProgramma, DateTime))
		bl.Dispose()
	End Sub

	Private Sub ControlloUnita(ByVal dataProgramma As DateTime)
		Try
			Dim kPowerP As Double = 0			' soglia da applicare per controllare che una unita` P non superi il max di produzione
			Dim kPowerC As Double = 0			' soglia da applicare per controllare che una unita` C non superi il max di consumo
			Dim kPowerMp As Double = 0			' soglia da applicare per controllare che una unita` M che produce non superi il max di produzione
			Dim kPowerMc As Double = 0			' soglia da applicare per controllare che una unita` M che consuma non superi il max di consumo

			Try
				kPowerP = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerP"))
				kPowerC = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerC"))
				kPowerMp = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerMp"))
				kPowerMc = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerMc"))
			Catch ex As Exception
				smError("Mancano il coefficienti di soglia delle potenze max/min nel file di configurazione (kPowerP/kPowerC/kPowerMp/kPowerMc): il controllo sulla potenza non verra` effettuato")

				' drastico ma efficace
				kPowerP = 0
				kPowerC = 0
				kPowerMp = 0
				kPowerMc = 0

				Return
			End Try

			Dim sBilCalcQueryTmo As String = "CalcolaBilanciamentoQueryTmo"
			smTrace("Controllo unit�: inizio attivita`")

			cn.ConnectionString = GetConnectionString()
			cn.Open()

			cmdSPGetNumUnit_OverPgm.Parameters("@DataProgramma").Value = dataProgramma
			cmdSPGetNumUnit_OverPgm.Parameters("@kPowerP").Value = kPowerP
			cmdSPGetNumUnit_OverPgm.Parameters("@kPowerC").Value = kPowerC
			cmdSPGetNumUnit_OverPgm.Parameters("@kPowerMp").Value = kPowerMp
			cmdSPGetNumUnit_OverPgm.Parameters("@kPowerMc").Value = kPowerMc
			'
			' Setta query timeout (default 45 secondi)
			'
			cmdSPGetNumUnit_OverPgm.CommandTimeout = AppSettingToInt32(sBilCalcQueryTmo, 45)
			'cmdSPGetNumUnit_OverPgm.ExecuteNonQuery()
			Dim da As New SqlDataAdapter
			da.SelectCommand = cmdSPGetNumUnit_OverPgm

			Dim ds As New DataSet
			da.Fill(ds)

			Dim h As Integer = 0
			Dim msg As String
			If Not ds Is Nothing AndAlso Not ds.Tables.Count = 0 AndAlso Not ds.Tables(0).Rows.Count = 0 Then
				h = Integer.Parse(ds.Tables(0).Rows(0).Item(0).ToString)
			End If

			If h = 0 Then
				msg = String.Format("Non ci sono unit� programmate oltre la potenza massima.")
			ElseIf h = 1 Then
				msg = String.Format("C'� {0} unit� programmata oltre la potenza massima.", h)
			Else
				msg = String.Format("Ci sono {0} unit� programmate oltre la potenza massima.", h)
			End If

			' aggiorno la situazione per questo batch
			BatchSerializer.SetProgressBatch(msg)

			smTrace("Controllo unit�: fine attivita`")

		Catch ex As Exception
			smError(ex, "Controllo unit�")
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Sub

	Public Function GetRefreshMode() As Boolean
		' STR 227 - Eliminazione Refresh
		Return AppSettingToBoolean("SetRefresh_String", False)
	End Function

End Class
