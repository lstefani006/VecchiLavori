Imports System.Data
Imports System.Data.SqlClient
Imports SystemMonitor
Imports System.Text
Imports System.Xml
Imports System.Xml.Schema
Imports System.Configuration
Imports System.IO
Imports System.Collections

Public Class MarketResult
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        _cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents _cmdSelectPrezziZonali As System.Data.SqlClient.SqlCommand
    Friend WithEvents _daPrezziZonali As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _dsPrezziZonali As Bil.DS_PrezziZonali
    Friend WithEvents _cmdSelectPrezziUnitari As System.Data.SqlClient.SqlCommand
    Friend WithEvents _daPrezziUnitari As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _dsPrezziUnitari As Bil.DS_PrezziUnitari
    Friend WithEvents _cmdUpdatePrezziZonali As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdInsertPrezzoZonale As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdUpdatePrezziUnitari As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdInsertPrezzoUnitario As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me._cmdSelectPrezziZonali = New System.Data.SqlClient.SqlCommand
        Me._daPrezziZonali = New System.Data.SqlClient.SqlDataAdapter
        Me._dsPrezziZonali = New Bil.DS_PrezziZonali
        Me._cmdSelectPrezziUnitari = New System.Data.SqlClient.SqlCommand
        Me._daPrezziUnitari = New System.Data.SqlClient.SqlDataAdapter
        Me._dsPrezziUnitari = New Bil.DS_PrezziUnitari
        Me._cmdUpdatePrezziZonali = New System.Data.SqlClient.SqlCommand
        Me._cmdInsertPrezzoZonale = New System.Data.SqlClient.SqlCommand
        Me._cmdUpdatePrezziUnitari = New System.Data.SqlClient.SqlCommand
        Me._cmdInsertPrezzoUnitario = New System.Data.SqlClient.SqlCommand
        CType(Me._dsPrezziZonali, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._dsPrezziUnitari, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
        "rsist security info=False;initial catalog=Bilaterali"
        '
        '_cmdSelectPrezziZonali
        '
        Me._cmdSelectPrezziZonali.CommandText = "SELECT dbo.PrezzoZonale.* FROM dbo.PrezzoZonale"
        Me._cmdSelectPrezziZonali.Connection = Me._cn
        '
        '_daPrezziZonali
        '
        Me._daPrezziZonali.InsertCommand = Me._cmdInsertPrezzoZonale
        Me._daPrezziZonali.SelectCommand = Me._cmdSelectPrezziZonali
        Me._daPrezziZonali.UpdateCommand = Me._cmdUpdatePrezziZonali
        '
        '_dsPrezziZonali
        '
        Me._dsPrezziZonali.DataSetName = "DS_PrezziZonali"
        Me._dsPrezziZonali.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        '_cmdSelectPrezziUnitari
        '
        Me._cmdSelectPrezziUnitari.CommandText = "SELECT dbo.PrezzoUnitario.* FROM dbo.PrezzoUnitario"
        Me._cmdSelectPrezziUnitari.Connection = Me._cn
        '
        '_daPrezziUnitari
        '
        Me._daPrezziUnitari.InsertCommand = Me._cmdInsertPrezzoUnitario
        Me._daPrezziUnitari.SelectCommand = Me._cmdSelectPrezziUnitari
        Me._daPrezziUnitari.UpdateCommand = Me._cmdUpdatePrezziUnitari
        '
        '_dsPrezziUnitari
        '
        Me._dsPrezziUnitari.DataSetName = "DS_PrezziUnitari"
        Me._dsPrezziUnitari.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        '_cmdUpdatePrezziZonali
        '
        Me._cmdUpdatePrezziZonali.CommandText = "UPDATE dbo.PrezzoZonale SET Prezzo = @Prezzo WHERE (PeriodoRilevante = @PeriodoRi" & _
        "levante) AND (CodiceZonaSDC = @CodiceZonaSDC) AND (Data = @Data)"
        Me._cmdUpdatePrezziZonali.Connection = Me._cn
		Me._cmdUpdatePrezziZonali.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Prezzo", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Input, False, CType(19, Byte), CType(6, Byte), "Prezzo", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdUpdatePrezziZonali.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdatePrezziZonali.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceZonaSDC", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdatePrezziZonali.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Data", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Data", System.Data.DataRowVersion.Original, Nothing))
        '
        '_cmdInsertPrezzoZonale
        '
        Me._cmdInsertPrezzoZonale.CommandText = "INSERT INTO dbo.PrezzoZonale (Data, CodiceZonaSDC, PeriodoRilevante, Prezzo) VALU" & _
        "ES (@Data, @CodiceZonaSDC, @PeriodoRilevante, @Prezzo)"
        Me._cmdInsertPrezzoZonale.Connection = Me._cn
        Me._cmdInsertPrezzoZonale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Data", System.Data.SqlDbType.DateTime, 8, "Data"))
        Me._cmdInsertPrezzoZonale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, "CodiceZonaSDC"))
		Me._cmdInsertPrezzoZonale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		Me._cmdInsertPrezzoZonale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Prezzo", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Input, False, CType(19, Byte), CType(6, Byte), "Prezzo", System.Data.DataRowVersion.Current, Nothing))
        '
        '_cmdUpdatePrezziUnitari
        '
        Me._cmdUpdatePrezziUnitari.CommandText = "UPDATE dbo.PrezzoUnitario SET Prezzo = @Prezzo WHERE (Data = @Data) AND (PeriodoR" & _
        "ilevante = @PeriodoRilevante)"
        Me._cmdUpdatePrezziUnitari.Connection = Me._cn
		Me._cmdUpdatePrezziUnitari.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Prezzo", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Input, False, CType(19, Byte), CType(6, Byte), "Prezzo", System.Data.DataRowVersion.Current, Nothing))
        Me._cmdUpdatePrezziUnitari.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Data", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Data", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdUpdatePrezziUnitari.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
        '
        '_cmdInsertPrezzoUnitario
        '
        Me._cmdInsertPrezzoUnitario.CommandText = "INSERT INTO dbo.PrezzoUnitario (Data, PeriodoRilevante, Prezzo) VALUES (@Data, @P" & _
        "eriodoRilevante, @Prezzo)"
        Me._cmdInsertPrezzoUnitario.Connection = Me._cn
        Me._cmdInsertPrezzoUnitario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Data", System.Data.SqlDbType.DateTime, 8, "Data"))
		Me._cmdInsertPrezzoUnitario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		Me._cmdInsertPrezzoUnitario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Prezzo", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Input, False, CType(19, Byte), CType(6, Byte), "Prezzo", System.Data.DataRowVersion.Current, Nothing))
        CType(Me._dsPrezziZonali, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._dsPrezziUnitari, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region

	'Private Function LeggiPrezziZonaliUnitari(ByVal MRXmlFileName As String, ByVal abyContentFile() As Byte) As Boolean
	'	Dim dataFlusso As DateTime
	'	Return LeggiPrezziZonaliUnitari(MRXmlFileName, abyContentFile, dataFlusso)
	'End Function

	Public Function LeggiPrezziZonaliUnitari(ByVal MRXmlFileName As String, ByVal abyContentFile() As Byte, ByRef dataFlusso As DateTime) As Boolean

		If AppSettingToBoolean("MR_Versione_10New", True) Then
			Dim bl As New MarketResult2
			Return bl.LeggiPrezziZonaliUnitari(MRXmlFileName, abyContentFile, dataFlusso)
		End If

		Return LeggiPrezziZonaliUnitariVecchioFormato(MRXmlFileName, abyContentFile, dataFlusso)
	End Function

	Public Function LeggiPrezziZonaliUnitariVecchioFormato(ByVal MRXmlFileName As String, ByVal abyContentFile() As Byte, ByRef dataFlusso As DateTime) As Boolean
		If abyContentFile Is Nothing Then Throw New ArgumentNullException("Errore contenuto del file uguale a Nothing")

		smTrace("LeggiPrezziZonaliUnitari - inizio attivita`")

		Try
			_cn.Open()

			Dim mr As New MRPrezzi(_cn, abyContentFile)
			With mr
				.DataAdapterPrezziZonali = _daPrezziZonali
				.DataAdapterPrezziUnitari = _daPrezziUnitari
			End With

			Dim ret As Boolean = mr.ParseXML(dataFlusso)

			smTrace("LeggiPrezziZonaliUnitari - fine attivita`")

			Return ret

		Catch ex As Exception
			smError(ex, "LeggiPrezziZonaliUnitari")
			Throw

		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function


#Region " Classe per il parsing del file XML dei prezzi zonali ed unitari "

	'========== CLASSE PER LA GESTIONE DEI DATI DAL FILE XML ===========
	Class MRPrezzi

		'================ CLASSE CONTENENTE I DATI DI UNA ZONA ==================
		Public Class Zona
			Implements IComparable, ICloneable

			' Codice Zona SDC
			Private _id As String
			' Data di riferimento
			Private _data As DateTime
			' Collezione dei SellPrices
			Private _htSellPrices As Hashtable
			' Collezione dei BuyPrices
			Private _htBuyPrices As Hashtable

			'===================== COSTRUTTORI ==================================
			Public Sub New()
				Me.New(String.Empty)
			End Sub

			Public Sub New(ByVal CodiceZona As String)
				Me.New(CodiceZona, New DateTime)
			End Sub
			Public Sub New(ByVal CodiceZona As String, ByVal Data As DateTime)
				Me._id = CodiceZona
				Me._data = Data

				Me._htBuyPrices = New Hashtable
				Me._htSellPrices = New Hashtable
			End Sub
			'===================== PROPRIETA' ==================================
			Public Property CodiceZona() As String
				Get
					Return Me._id
				End Get
				Set(ByVal Value As String)
					Me._id = Value
				End Set
			End Property
			Public Property DataRiferimento() As DateTime
				Get
					Return Me._data
				End Get
				Set(ByVal Value As DateTime)
					Me._data = Value
				End Set
			End Property
			Public ReadOnly Property BuyPriceCollection() As Hashtable
				Get
					Return Me._htBuyPrices
				End Get
			End Property

			Public ReadOnly Property SellPriceCollection() As Hashtable
				Get
					Return Me._htSellPrices
				End Get
			End Property
			'===================== FUNZIONI PRIVATE ==================================
			Friend Sub InitVars(ByVal zone As Zona)
				If Not (zone Is Nothing) Then
					Me._id = zone.CodiceZona
					Me._data = zone.DataRiferimento
					Me._htBuyPrices = DirectCast(zone.BuyPriceCollection.Clone(), Hashtable)
					Me._htSellPrices = DirectCast(zone.SellPriceCollection.Clone(), Hashtable)
				End If
			End Sub
			'===================== FUNZIONI PUBBLICHE ==================================
			Public Sub AddBuyPrice(ByVal ora As Byte, ByVal buyprice As Decimal)
				Debug.Assert(Not Me._htBuyPrices Is Nothing, "Errore HashTable buyprice uguale a Nothing")
				If Me._htBuyPrices Is Nothing Then Throw New ApplicationException("Errore HashTable buyprice uguale a Nothing")

				If (Me._htBuyPrices.Contains(ora)) Then
					Me._htBuyPrices(ora) = buyprice
				Else
					Me._htBuyPrices.Add(ora, buyprice)
				End If
			End Sub

			Public Sub AddSellPrice(ByVal ora As Byte, ByVal sellprice As Decimal)
				Debug.Assert(Not Me._htSellPrices Is Nothing, "Errore HashTable sellprice uguale a Nothing")
				If Me._htSellPrices Is Nothing Then Throw New ApplicationException("Errore HashTable sellprice uguale a Nothing")

				If (Me._htSellPrices.Contains(ora)) Then
					Me._htSellPrices(ora) = sellprice
				Else
					Me._htSellPrices.Add(ora, sellprice)
				End If
			End Sub

			' Non la uso per ora pero' se volessi verificare se i prezzi Unitari sono uguali
			' per ogni Zona lo posso fare
			Public Function CompareTo(ByVal obj As Object) As Integer Implements System.IComparable.CompareTo
				If obj Is Nothing Then Return 1

				If TypeOf obj Is Zona Then
					Dim tmp As Zona = DirectCast(obj, Zona)
					Dim localHashTableBuyPrice As Hashtable = tmp.BuyPriceCollection
					Dim buyprice1 As Decimal
					Dim buyprice2 As Decimal

					For Each hour As Byte In localHashTableBuyPrice.Keys
						buyprice1 = CType(Me._htBuyPrices(hour), Decimal)
						buyprice2 = CType(localHashTableBuyPrice(hour), Decimal)
						If buyprice1 < buyprice2 Then
							Return -1
						ElseIf buyprice1 > buyprice2 Then
							Return 1
						End If
					Next
					Return 0

				Else
					Throw New ArgumentException("L'oggetto non e' una Zona")
				End If
			End Function

			Public Function Clone() As Object Implements System.ICloneable.Clone
				Dim cln As New Zona
				cln.InitVars(Me)
				Return cln
			End Function
		End Class
		'===================== FINE CLASSE ZONA ===============================

		' Contenuto del file XML dei Prezzi Zonali ed Unitari
		Private _xmlContent() As Byte
		' Connessione al DB
		Private _conn As SqlConnection
		' Data Adapter PrezziZonali
		Private _daPrezziZonali As SqlDataAdapter
		' Data Adapter PrezziUnitari
		Private _daPrezziUnitari As SqlDataAdapter
		' Zona di riferimento (se si vuole effettuare un controllo sui prezzi Unitari)
		Private _refZone As Zona
		' Lista delle Zone valide (la lista contiene solo i Codici delle Zone)
		Private _alListaZone As ArrayList

		'===================== COSTRUTTORI ==================================
		Public Sub New(ByVal cn As SqlConnection, ByVal XmlContentFile() As Byte)
			Me._conn = cn
			Me._xmlContent = XmlContentFile
		End Sub

		'===================== PROPRIETA' ==================================
		Public Property ListaZone() As ArrayList
			Get
				Return Me._alListaZone
			End Get
			Set(ByVal Value As ArrayList)
				If Not (Value Is Nothing) Then
					Me._alListaZone = DirectCast(Value.Clone(), ArrayList)
				Else
					Me._alListaZone = Nothing
				End If
			End Set
		End Property

		Public Property Connection() As SqlConnection
			Get
				Return Me._conn
			End Get
			Set(ByVal Value As SqlConnection)
				Me._conn = Value
			End Set
		End Property

		Public Property DataAdapterPrezziZonali() As SqlDataAdapter
			Get
				Return Me._daPrezziZonali
			End Get
			Set(ByVal Value As SqlDataAdapter)
				Me._daPrezziZonali = Value

				If Not (Me._daPrezziZonali Is Nothing) Then
					Me._daPrezziZonali.SelectCommand.CommandText &= " WHERE Data = @DataRiferimento AND " & _
					   " CodiceZonaSDC = @CodiceZona "
					Me._daPrezziZonali.SelectCommand.Parameters.Add("@DataRiferimento", SqlDbType.DateTime)
					Me._daPrezziZonali.SelectCommand.Parameters.Add("@CodiceZona", SqlDbType.VarChar)
				End If
			End Set
		End Property

		Public Property DataAdapterPrezziUnitari() As SqlDataAdapter
			Get
				Return Me._daPrezziUnitari
			End Get
			Set(ByVal Value As SqlDataAdapter)
				Me._daPrezziUnitari = Value

				If Not (Me._daPrezziUnitari Is Nothing) Then
					Me._daPrezziUnitari.SelectCommand.CommandText &= " WHERE Data = @DataRiferimento"
					Me._daPrezziUnitari.SelectCommand.Parameters.Add("@DataRiferimento", SqlDbType.DateTime)
				End If
			End Set
		End Property

		'===================== FUNZIONI PRIVATE ==================================
		Private Sub ValidationEvent(ByVal sender As Object, ByVal e As ValidationEventArgs)
			SystemMonitor.SmLog.smError(e.Exception, e.Message)
			Throw New ApplicationException(e.Message)
		End Sub

		Private Function ConvertDateFromString(ByVal strData As String) As DateTime
			Debug.Assert(Not strData Is Nothing, "Data formato stringa da convertire uguale a Nothing")
			If strData Is Nothing Then Throw New ArgumentNullException("Data formato stringa da convertire uguale a Nothing")

			Try
				If Not strData Is Nothing Then
					Dim anno As Integer = Integer.Parse(strData.Substring(0, 4))
					Dim mese As Integer = Integer.Parse(strData.Substring(4, 2))
					Dim giorno As Integer = Integer.Parse(strData.Substring(6, 2))
					Dim d As New DateTime(anno, mese, giorno)
					Return d
				End If
			Catch ex As Exception
				SmLog.smError(ex, "Errore convertendo la stringa """ & strData & """ in DateTime")
				Throw
			End Try

		End Function

		Private Function IsValidZone(ByVal CodiceZona As String) As Boolean
			' Per adesso mi fido che le zone restituite dal file XML siano
			' presenti nel DataBase...
			If (False) Then
				Debug.Assert(Not Me._alListaZone Is Nothing, "Oggetto ListaZone uguale a Nothing")
				If Me._alListaZone Is Nothing Then Throw New ApplicationException("Oggetto ListaZone uguale a Nothing")
				If (Me._alListaZone.Contains(CodiceZona)) Then
					Return True
				Else
					Return False
				End If
			End If

			Return True
		End Function

		Private Sub SaveToDB(ByVal z As Zona)
			Dim tr As SqlTransaction = Nothing
			Try
				' Se si vuole usare le transazioni....
				'tr = Me._conn.BeginTransaction()

				SaveToDBPrezziZonali(tr, z)
				SaveToDBPrezziUnitari(tr, z)

				If Not (tr Is Nothing) Then tr.Commit()

			Catch ex As Exception
				SmLog.smError(ex)
				If Not (tr Is Nothing) Then tr.Rollback()
				Throw
			End Try
		End Sub

		Private Sub SaveToDBPrezziUnitari(ByVal tr As SqlTransaction, ByVal zn As Zona)
			Debug.Assert(Not zn Is Nothing, "Errore oggetto Zona uguale a Nothing")
			If (zn Is Nothing) Then Throw New ApplicationException("Errore oggetto Zona uguale a Nothing")

			Try
				' Prelevo i Prezzi Unitari per una certa Data
				Dim ds As DS_PrezziUnitari = GetDataSetPrezziUnitariPerData(zn.DataRiferimento)
				If (ds Is Nothing) Then Throw New ApplicationException("Errore Oggetto DataSet PrezziUnitari uguale a Nothing")

				Dim dtpu As DS_PrezziUnitari.PrezziUnitariDataTable = ds.PrezziUnitari
				If (dtpu Is Nothing) Then Throw New ApplicationException("Errore Oggetto DataTable PrezziUnitari uguale a Nothing")

				' Lista dei Prezzi Unitari
				Dim htBuyPrices As Hashtable = zn.BuyPriceCollection
				If (htBuyPrices Is Nothing) Then Throw New ApplicationException("Errore Oggetto HashTable BuyPrices uguale a Nothing")

				If Not (ds Is Nothing) Then
					For Each ora As Byte In htBuyPrices.Keys
						Dim drpu As DS_PrezziUnitari.PrezziUnitariRow = ds.PrezziUnitari.FindByDataPeriodoRilevante(zn.DataRiferimento, ora)
						If Not (drpu Is Nothing) Then
							' Esiste gia' la riga => la aggiorno
							drpu.Prezzo = DirectCast(htBuyPrices(ora), Decimal)
						Else
							' Non esiste => ne creo una nuova
							drpu = dtpu.NewPrezziUnitariRow()
							With drpu
								.Data = zn.DataRiferimento
								.PeriodoRilevante = ora
								.Prezzo = DirectCast(htBuyPrices(ora), Decimal)
							End With
							dtpu.AddPrezziUnitariRow(drpu)
						End If
					Next

					' Eventuale Transazione
					If Not tr Is Nothing Then
						Me._daPrezziUnitari.UpdateCommand.Transaction = tr
						Me._daPrezziUnitari.InsertCommand.Transaction = tr

					End If

					Me._daPrezziUnitari.Update(ds.PrezziUnitari)
				End If

			Catch ex As Exception
				SmLog.smError(ex)
				Throw
			End Try
		End Sub

		Private Sub SaveToDBPrezziZonali(ByVal tr As SqlTransaction, ByVal zn As Zona)
			Debug.Assert(Not zn Is Nothing, "Errore oggetto Zona uguale a Nothing")
			If (zn Is Nothing) Then Throw New ArgumentNullException("Errore oggetto Zona uguale a Nothing")

			Try
				' Prelevo la lista dei Prezzi Zonali per una certa Data e Zona
				Dim ds As DS_PrezziZonali = GetDataSetPrezziZonaliPerDataCodiceZona(zn.DataRiferimento, zn.CodiceZona)
				If (ds Is Nothing) Then Throw New ApplicationException("Errore Oggetto DataSet PrezziZonali uguale a Nothing")

				Dim dtpz As DS_PrezziZonali.PrezziZonaliDataTable = ds.PrezziZonali
				If (dtpz Is Nothing) Then Throw New ApplicationException("Errore Oggetto DataTable PrezziZonali uguale a Nothing")

				' Lista dei Prezzi Zonali
				Dim htSellPrices As Hashtable = zn.SellPriceCollection
				If (htSellPrices Is Nothing) Then Throw New ApplicationException("Errore Oggetto HashTable SellPrices uguale a Nothing")

				If Not (ds Is Nothing) Then
					For Each ora As Byte In htSellPrices.Keys
						Dim drpz As DS_PrezziZonali.PrezziZonaliRow = dtpz.FindByDataCodiceZonaSDCPeriodoRilevante(zn.DataRiferimento, zn.CodiceZona, ora)
						' Devo verificare se la riga esiste oppure no
						If Not (drpz Is Nothing) Then
							' Esiste => aggiorno i dati
							drpz.Prezzo = DirectCast(htSellPrices(ora), Decimal)
						Else
							' Non esiste => ne creo una nuova
							drpz = dtpz.NewPrezziZonaliRow()
							With drpz
								.Data = zn.DataRiferimento
								.CodiceZonaSDC = zn.CodiceZona
								.PeriodoRilevante = ora
								.Prezzo = DirectCast(htSellPrices(ora), Decimal)
							End With
							dtpz.Rows.Add(drpz)
						End If
					Next

					' Eventuale Transazione
					If Not (tr Is Nothing) Then
						Me._daPrezziZonali.UpdateCommand.Transaction = tr
						Me._daPrezziZonali.InsertCommand.Transaction = tr
					End If

					' Aggiorno il DataBase
					Me._daPrezziZonali.Update(ds.PrezziZonali)
				End If

			Catch ex As Exception
				SmLog.smError(ex)
				Throw
			End Try
		End Sub
		Private Sub MoveToNextZone(ByVal xr As XmlValidatingReader, ByVal elZone As Object)
			Debug.Assert(Not xr Is Nothing, "Errore oggetto XmlValidatingReader uguale a Nothing")
			If (xr Is Nothing) Then Throw New ArgumentNullException("Errore oggetto XmlValidatingReader uguale a Nothing")

			If xr.ReadState = ReadState.Interactive Then
				While (xr.Read())
					Dim xrn As Object = xr.Name
					Select Case xr.NodeType
						Case XmlNodeType.EndElement
							If xrn Is elZone Then
								Return
							End If
					End Select
				End While
			Else
				Return
			End If
		End Sub

		Private Sub CheckDBConn()
			Debug.Assert(Not Me._conn Is Nothing, "Errore oggetto Connection uguale a nothing")
			If Me._conn Is Nothing Then Throw New ApplicationException("Errore oggetto Connection uguale a nothing")

			If (Me._conn.State = ConnectionState.Closed) Then
				Throw New ApplicationException("Errore connessione al DataBase Closed")
			End If

			Debug.Assert(Not Me._daPrezziZonali Is Nothing, "Errore oggetto DataAdapter per i prezzi zonali uguale a Nothing")
			If (Me._daPrezziZonali Is Nothing) Then Throw New ApplicationException("Errore oggetto DataAdapter per i prezzi zonali uguale a Nothing")

			Debug.Assert(Not Me._daPrezziUnitari Is Nothing, "Errore oggetto DataAdapter per i prezzi unitari uguale a Nothing")
			If (Me._daPrezziUnitari Is Nothing) Then Throw New ApplicationException("Errore oggetto DataAdapter per i prezzi unitari uguale a Nothing")

		End Sub

		Private Function GetDataSetPrezziZonaliPerDataCodiceZona(ByVal data As DateTime, ByVal CodiceZona As String) As DS_PrezziZonali
			Try
				CheckDBConn()

				Dim ds As New DS_PrezziZonali
				Dim sqlSelect As SqlCommand = Me._daPrezziZonali.SelectCommand
				' I parametri li aggiungo quando passo all'oggetto il DataAdapter 
				' tramite la proprieta' in modo da inserirli una volta sola
				sqlSelect.Parameters("@DataRiferimento").Value = data
				sqlSelect.Parameters("@CodiceZona").Value = CodiceZona

				Me._daPrezziZonali.Fill(ds.PrezziZonali)
				Return ds
			Catch ex As Exception
				SmLog.smError(ex)
				Throw
			End Try
		End Function

		Private Function GetDataSetPrezziUnitariPerData(ByVal data As DateTime) As DS_PrezziUnitari
			Try
				CheckDBConn()

				Dim ds As New DS_PrezziUnitari
				Dim sqlSelect As SqlCommand = Me._daPrezziUnitari.SelectCommand
				' Il parametro lo aggiungo quando passo all'oggetto il DataAdapter 
				' tramite la proprieta' in modo da inserirlo una volta sola
				sqlSelect.Parameters("@DataRiferimento").Value = data

				Me._daPrezziUnitari.Fill(ds.PrezziUnitari)
				Return ds
			Catch ex As Exception
				SmLog.smError(ex)
				Throw
			End Try
		End Function
		'===================== FUNZIONI PUBBLICHE ==================================
		Public Function ParseXML(ByRef dataFlusso As DateTime) As Boolean
			Dim xr As XmlValidatingReader

			'=================== CONTROLLO SCHEMA PER IL FILE XML =============================================
			Try
				Dim fileSchema As String = BilBLBase.GetCompleteFileNameFromAppSettings("MR.PIPEDocument.xsd")
				If fileSchema Is Nothing Then
					SystemMonitor.SmLog.smError("""MR.PIPEDocument.xsd"" non e` presente nel file di configurazione")
					Return False
				End If

				Dim sc As XmlSchemaCollection = New XmlSchemaCollection
				sc.Add(Nothing, fileSchema)

				Dim textReader As XmlTextReader = New XmlTextReader(New MemoryStream(Me._xmlContent))
				textReader.WhitespaceHandling = WhitespaceHandling.None
				xr = New XmlValidatingReader(textReader)
				xr.ValidationType = ValidationType.Schema
				xr.Schemas.Add(sc)
				' Evento che gestisce gli errori di Validazione
				AddHandler xr.ValidationEventHandler, AddressOf Me.ValidationEvent

			Catch ex As Exception
				Debug.Assert(False, "File schema non trovato")				' se non trova il file degli schemi
				SystemMonitor.SmLog.smError(ex)
				Return False
			End Try

			'=================== PARSING FILE XML =============================================
			Try
				Dim cultureInfoIT As New System.Globalization.CultureInfo("it-IT")				  ' per leggere i double in italiano

				'======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
				Dim elDate As Object = xr.NameTable.Add("Date")
				Dim elZoneDetail As Object = xr.NameTable.Add("ZoneDetail")
				Dim elZone As Object = xr.NameTable.Add("Zone")
				Dim elBuyPrice As Object = xr.NameTable.Add("BuyPrice")
				Dim elSellPrice As Object = xr.NameTable.Add("SellPrice")

				Dim currentZone As Zona = Nothing
				Dim data As DateTime

				'============================== INIZIO PARSING DEL FILE XML =========================
				While (xr.Read())
					Dim xrn As Object = xr.Name

					Select Case xr.NodeType
						Case XmlNodeType.Element
							'============== DATE =====================
							If (xrn Is elDate) Then
								Dim xmlData As String = xr.ReadString()
								Debug.Assert(Not xmlData Is Nothing, "Errore Tag ""Date"" vuoto")
								If Not (xmlData Is Nothing) Then
									data = ConvertDateFromString(xmlData)
									dataFlusso = data
								Else
									Throw New ApplicationException("Errore Tag ""Date"" vuoto")
								End If
								'============== ZONE DETAIL =====================
								'ElseIf (xrn Is elZoneDetail) Then

								'============== ZONE =====================
							ElseIf (xrn Is elZone) Then
								Dim xmlZone As String = xr.ReadString()

								Debug.Assert(Not xmlZone Is Nothing, "Errore Tag ""Zone"" vuoto")
								If Not xmlZone Is Nothing Then
									If (xmlZone = "NAT") Then
										MoveToNextZone(xr, elZoneDetail)
									Else
										currentZone = New Zona(xmlZone, data)
									End If
								Else
									Throw New ApplicationException("Errore Tag ""Zone"" vuoto")
								End If
								'============== BUY PRICE =====================
							ElseIf (xrn Is elBuyPrice) Then
								Debug.Assert(Not currentZone Is Nothing, "Errore Oggetto Zona uguale a Nothing")
								If currentZone Is Nothing Then Throw New ApplicationException("Errore Oggetto Zona uguale a Nothing")
								Dim xmlHour As String = xr.GetAttribute("Hour")
								If xmlHour Is Nothing Then
									Throw New ApplicationException("Errore Attribute ""Hour"" vuoto")
								End If

								Dim ora As Byte
								Try
									ora = Byte.Parse(xmlHour)
								Catch ex As Exception
									SmLog.smError(ex, "Errore Attribute ""Hour"" non e' un intero")
									Throw
								End Try

								Debug.Assert(Not xmlHour Is Nothing, "Errore Attribute ""Hour"" vuoto")

								Dim xmlPrice As String = xr.ReadString()
								Debug.Assert(Not xmlPrice Is Nothing, "Errore Tag ""BuyPrice"" vuoto")

								Dim buyprice As Decimal
								Try
									buyprice = Decimal.Parse(xmlPrice, cultureInfoIT)
								Catch ex As Exception
									SmLog.smError(ex, "Errore Tag ""BuyPrice"" non e' un decimal")
									Throw
								End Try

								If Not xmlPrice Is Nothing Then
									currentZone.AddBuyPrice(ora, buyprice)
								Else
									Throw New ApplicationException("Errore Tag ""BuyPrice"" vuoto")
								End If
								'============== SELL PRICE =====================
							ElseIf (xrn Is elSellPrice) Then
								Debug.Assert(Not currentZone Is Nothing, "Errore Oggetto Zona uguale a Nothing")
								If currentZone Is Nothing Then Throw New ApplicationException("Errore Oggetto Zona uguale a Nothing")

								Dim xmlHour As String = xr.GetAttribute("Hour")
								If xmlHour Is Nothing Then
									Throw New ApplicationException("Errore Attribute ""Hour"" vuoto")
								End If

								Dim ora As Byte
								Try
									ora = Byte.Parse(xmlHour)
								Catch ex As Exception
									SmLog.smError(ex, "Errore Attribute ""Hour"" non e' un intero")
									Throw
								End Try

								Debug.Assert(Not xmlHour Is Nothing, "Errore Attribute ""Hour"" vuoto")

								Dim xmlPrice As String = xr.ReadString()
								Debug.Assert(Not xmlPrice Is Nothing, "Errore Tag ""SellPrice"" vuoto")

								Dim sellprice As Decimal
								Try
									sellprice = Decimal.Parse(xmlPrice, cultureInfoIT)
								Catch ex As Exception
									SmLog.smError(ex, "Errore Tag ""SellPrice"" non e' un decimal")
									Throw
								End Try

								If Not xmlPrice Is Nothing Then
									currentZone.AddSellPrice(ora, sellprice)
								Else
									Throw New ApplicationException("Errore Tag ""SellPrice"" vuoto")
								End If
							End If


						Case XmlNodeType.EndElement

							'============== END ZONE DETAIL =====================
							If (xrn Is elZoneDetail) Then
								Debug.Assert(Not currentZone Is Nothing, "Errore Oggetto Zona uguale a Nothing")
								If currentZone Is Nothing Then Throw New ApplicationException("Errore Oggetto Zona uguale a Nothing")

								Debug.Assert(currentZone.CodiceZona <> "NAT")
								' Se e' una Zona valida....per adesso la funzione restituisce sempre
								' true
								If (IsValidZone(currentZone.CodiceZona)) Then
									If (Me._refZone Is Nothing) Then
										' Setto la zona di riferimento per un eventuale
										' confronto dei prezzi unitari...
										' per adesso non serve ma l'ho implementata lo stesso
										Me._refZone = DirectCast(currentZone.Clone(), Zona)
									Else
										' Posso verificare che la currentZone abbia gli stessi
										' BuyPrices della zona di riferimento...ma non lo faccio
										' per ora

										'If (currentZone.CompareTo(Me._refZone) <> 0) Then
										'    ' Errore BuyPrices diversi
										'End If

									End If
									' Salvo sul DataBase i vari prezzi
									SaveToDB(currentZone)
									currentZone = Nothing

								End If
							End If
					End Select

				End While

				Return True
			Catch ex As Exception
				SmLog.smError(ex)
				Throw
			Finally
				If Not (xr Is Nothing) Then xr.Close()
			End Try
		End Function

	End Class

#End Region

End Class
