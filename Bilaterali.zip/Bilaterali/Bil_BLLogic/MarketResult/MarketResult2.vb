Imports System.Data
Imports System.Data.SqlClient
Imports SystemMonitor
Imports System.Text
Imports System.Xml
Imports System.Xml.Schema
Imports System.Configuration
Imports System.IO
Imports System.Collections

Public Class MarketResult2
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents daPrezzoUnitario As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents daPrezzoZonale As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand2 As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.daPrezzoUnitario = New System.Data.SqlClient.SqlDataAdapter
		Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
		Me.daPrezzoZonale = New System.Data.SqlClient.SqlDataAdapter
		Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand2 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand2 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand2 = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_user;data source=BILSVR1;pers" & _
		"ist security info=False;initial catalog=Bilaterali"
		'
		'daPrezzoUnitario
		'
		Me.daPrezzoUnitario.DeleteCommand = Me.SqlDeleteCommand1
		Me.daPrezzoUnitario.InsertCommand = Me.SqlInsertCommand1
		Me.daPrezzoUnitario.SelectCommand = Me.SqlSelectCommand1
		Me.daPrezzoUnitario.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "PrezzoUnitario", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Data", "Data"), New System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"), New System.Data.Common.DataColumnMapping("Prezzo", "Prezzo")})})
		Me.daPrezzoUnitario.UpdateCommand = Me.SqlUpdateCommand1
		'
		'SqlSelectCommand1
		'
		Me.SqlSelectCommand1.CommandText = "SELECT Data, PeriodoRilevante, Prezzo FROM dbo.PrezzoUnitario WHERE (Data = @data" & _
		"Flusso)"
		Me.SqlSelectCommand1.Connection = Me.cn
		Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@dataFlusso", System.Data.SqlDbType.DateTime, 8, "Data"))
		'
		'SqlInsertCommand1
		'
		Me.SqlInsertCommand1.CommandText = "INSERT INTO dbo.PrezzoUnitario(Data, PeriodoRilevante, Prezzo) VALUES (@Data, @Pe" & _
		"riodoRilevante, @Prezzo)"
		Me.SqlInsertCommand1.Connection = Me.cn
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Data", System.Data.SqlDbType.DateTime, 8, "Data"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.Int, 4, "PeriodoRilevante"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Prezzo", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Input, False, CType(19, Byte), CType(6, Byte), "Prezzo", System.Data.DataRowVersion.Current, Nothing))
		'
		'SqlUpdateCommand1
		'
		Me.SqlUpdateCommand1.CommandText = "UPDATE dbo.PrezzoUnitario SET Data = @Data, PeriodoRilevante = @PeriodoRilevante," & _
		" Prezzo = @Prezzo WHERE (Data = @Original_Data) AND (PeriodoRilevante = @Origina" & _
		"l_PeriodoRilevante)"
		Me.SqlUpdateCommand1.Connection = Me.cn
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Data", System.Data.SqlDbType.DateTime, 8, "Data"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.Int, 4, "PeriodoRilevante"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Prezzo", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Input, False, CType(19, Byte), CType(6, Byte), "Prezzo", System.Data.DataRowVersion.Current, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Data", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Data", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		'
		'SqlDeleteCommand1
		'
		Me.SqlDeleteCommand1.CommandText = "DELETE FROM dbo.PrezzoUnitario WHERE (Data = @Original_Data) AND (PeriodoRilevant" & _
		"e = @Original_PeriodoRilevante)"
		Me.SqlDeleteCommand1.Connection = Me.cn
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Data", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Data", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		'
		'daPrezzoZonale
		'
		Me.daPrezzoZonale.DeleteCommand = Me.SqlDeleteCommand2
		Me.daPrezzoZonale.InsertCommand = Me.SqlInsertCommand2
		Me.daPrezzoZonale.SelectCommand = Me.SqlSelectCommand2
		Me.daPrezzoZonale.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "PrezzoZonale", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Data", "Data"), New System.Data.Common.DataColumnMapping("CodiceZonaSDC", "CodiceZonaSDC"), New System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"), New System.Data.Common.DataColumnMapping("Prezzo", "Prezzo")})})
		Me.daPrezzoZonale.UpdateCommand = Me.SqlUpdateCommand2
		'
		'SqlSelectCommand2
		'
		Me.SqlSelectCommand2.CommandText = "SELECT Data, CodiceZonaSDC, PeriodoRilevante, Prezzo FROM dbo.PrezzoZonale WHERE " & _
		"(Data = @dataFlusso)"
		Me.SqlSelectCommand2.Connection = Me.cn
		Me.SqlSelectCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@dataFlusso", System.Data.SqlDbType.DateTime, 8, "Data"))
		'
		'SqlInsertCommand2
		'
		Me.SqlInsertCommand2.CommandText = "INSERT INTO dbo.PrezzoZonale(Data, CodiceZonaSDC, PeriodoRilevante, Prezzo) VALUE" & _
		"S (@Data, @CodiceZonaSDC, @PeriodoRilevante, @Prezzo)"
		Me.SqlInsertCommand2.Connection = Me.cn
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Data", System.Data.SqlDbType.DateTime, 8, "Data"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, "CodiceZonaSDC"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.Int, 4, "PeriodoRilevante"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Prezzo", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Input, False, CType(19, Byte), CType(6, Byte), "Prezzo", System.Data.DataRowVersion.Current, Nothing))
		'
		'SqlUpdateCommand2
		'
		Me.SqlUpdateCommand2.CommandText = "UPDATE dbo.PrezzoZonale SET Data = @Data, CodiceZonaSDC = @CodiceZonaSDC, Periodo" & _
		"Rilevante = @PeriodoRilevante, Prezzo = @Prezzo WHERE (CodiceZonaSDC = @Original" & _
		"_CodiceZonaSDC) AND (Data = @Original_Data) AND (PeriodoRilevante = @Original_Pe" & _
		"riodoRilevante)"
		Me.SqlUpdateCommand2.Connection = Me.cn
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Data", System.Data.SqlDbType.DateTime, 8, "Data"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, "CodiceZonaSDC"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.Int, 4, "PeriodoRilevante"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Prezzo", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Input, False, CType(19, Byte), CType(6, Byte), "Prezzo", System.Data.DataRowVersion.Current, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceZonaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Data", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Data", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		'
		'SqlDeleteCommand2
		'
		Me.SqlDeleteCommand2.CommandText = "DELETE FROM dbo.PrezzoZonale WHERE (CodiceZonaSDC = @Original_CodiceZonaSDC) AND " & _
		"(Data = @Original_Data) AND (PeriodoRilevante = @Original_PeriodoRilevante)"
		Me.SqlDeleteCommand2.Connection = Me.cn
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceZonaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Data", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Data", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))

	End Sub

#End Region

	Private ErroreValidazione As Boolean = False

	Public Function LeggiPrezziZonaliUnitari(ByVal MRXmlFileName As String, ByVal abyContentFile() As Byte, ByRef dataNelFile As DateTime) As Boolean

		cn.ConnectionString = GetConnectionString()

		Dim tr As SqlTransaction = Nothing

		BatchSerializer.SetProgressBatch("Lettura MR (nuovo formato) - inizio attivita`")

		ErroreValidazione = False


		Try
			cn.Open()

			tr = cn.BeginTransaction(IsolationLevel.ReadCommitted)


			Dim textReader As XmlTextReader = New XmlTextReader(New MemoryStream(abyContentFile))
			textReader.WhitespaceHandling = WhitespaceHandling.None

			Dim fileSchema As String = BilBLBase.GetCompleteFileNameFromAppSettings("MR2.PIPEDocument.xsd")

			Dim xvr As New XmlValidatingReader(textReader)
			xvr.ValidationType = ValidationType.Schema
			Dim sc As New XmlSchemaCollection
			sc.Add(Nothing, fileSchema)
			xvr.Schemas.Add(sc)
			AddHandler xvr.ValidationEventHandler, AddressOf ValidationEvent

			Dim xd As New XmlDocument
			xd.Load(xvr)

			Dim nsmgr As XmlNamespaceManager = New XmlNamespaceManager(xd.NameTable)
			nsmgr.AddNamespace("x", "urn:XML-PIPE")

			Dim listPIPTransaction As XmlNodeList
			listPIPTransaction = xd.DocumentElement.SelectNodes("./x:PIPTransaction", nsmgr)
			If listPIPTransaction.Count <> 1 Then
				Throw New ApplicationException("PIPTransaction: e` permessa una sola PIPTransaction")
			End If

			Dim listMarketResult As XmlNodeList
			listMarketResult = listPIPTransaction(0).SelectNodes("./x:MarketResult", nsmgr)

			Dim nodeMGPFound As Boolean = False

			For Each nodeMarketResult As XmlNode In listMarketResult

				Dim nodeMarket As XmlNode
				nodeMarket = nodeMarketResult.SelectSingleNode("./x:MarketDetail/x:Market", nsmgr)
				If nodeMarket.InnerText = "MGP" Then

					nodeMGPFound = True

					Dim data As DateTime
					If True Then
						Dim nodeDate As XmlNode
						nodeDate = nodeMarketResult.SelectSingleNode("./x:Date", nsmgr)
						If nodeDate Is Nothing Then
							Throw New ApplicationException("MarketResult/Date non presente")
						End If

						Dim anno As Integer = 0
						Dim mese As Integer = 0
						Dim giorno As Integer = 0

						anno = Integer.Parse(nodeDate.InnerText.Substring(0, 4))
						mese = Integer.Parse(nodeDate.InnerText.Substring(4, 2))
						giorno = Integer.Parse(nodeDate.InnerText.Substring(6, 2))

						data = New DateTime(anno, mese, giorno)
						dataNelFile = data

					End If

					SetTransaction(daPrezzoUnitario, tr)
					SetTransaction(daPrezzoZonale, tr)

					Dim ds As New DS_Prezzi2

					daPrezzoUnitario.SelectCommand.Parameters("@dataFlusso").Value = data
					daPrezzoZonale.SelectCommand.Parameters("@dataFlusso").Value = data

					daPrezzoUnitario.Fill(ds.PrezzoUnitario)
					daPrezzoZonale.Fill(ds.PrezzoZonale)



					Dim listZoneDetail As XmlNodeList
					listZoneDetail = nodeMarketResult.SelectNodes("./x:MarketDetail/x:ZoneDetail", nsmgr)

					For Each nodeZoneDetail As XmlNode In listZoneDetail

						Dim zone As String
						zone = nodeZoneDetail.SelectSingleNode("./x:Zone", nsmgr).InnerText

						Dim listInterval As XmlNodeList
						listInterval = nodeZoneDetail.SelectNodes("./x:Interval", nsmgr)
						For Each nodeInterval As XmlNode In listInterval

							Dim ora As Integer = Integer.Parse(nodeInterval.Attributes("Hour").InnerText)
							Dim strBuyPrice As String = nodeInterval.SelectSingleNode("./x:BuyPrice", nsmgr).InnerText
							Dim strSellPrice As String = nodeInterval.SelectSingleNode("./x:SellPrice", nsmgr).InnerText

							Dim BuyPrice As Decimal
							Dim SellPrice As Decimal

							BuyPrice = Decimal.Parse(strBuyPrice, New Globalization.CultureInfo("it-it"))
							SellPrice = Decimal.Parse(strSellPrice, New Globalization.CultureInfo("it-it"))


							Console.WriteLine("zona={0}, data={1}, ora={2} BuyPrice={3} SellPrice={4}", zone, data, ora, BuyPrice, SellPrice)

							Dim zonaUnica As String = AppSettingToString("CodiceZonaUnico", "NAT")

							If zone = zonaUnica Then

								Dim drPUFound As Boolean = True
								Dim drPU As DS_Prezzi2.PrezzoUnitarioRow
								drPU = ds.PrezzoUnitario.FindByDataPeriodoRilevante(data, ora)

								If drPU Is Nothing Then
									drPUFound = False
									drPU = ds.PrezzoUnitario.NewPrezzoUnitarioRow

									drPU.Data = data
									drPU.PeriodoRilevante = ora
								End If

								drPU.Prezzo = BuyPrice

								If drPUFound = False Then
									ds.PrezzoUnitario.AddPrezzoUnitarioRow(drPU)
								End If

							Else

								Dim drPZFound As Boolean = True
								Dim drPZ As DS_Prezzi2.PrezzoZonaleRow
								drPZ = ds.PrezzoZonale.FindByDataCodiceZonaSDCPeriodoRilevante(data, zone, ora)

								If drPZ Is Nothing Then
									drPZFound = False
									drPZ = ds.PrezzoZonale.NewPrezzoZonaleRow()

									drPZ.Data = data
									drPZ.PeriodoRilevante = ora
									drPZ.CodiceZonaSDC = zone
								End If

								drPZ.Prezzo = SellPrice


								If drPZFound = False Then
									ds.PrezzoZonale.AddPrezzoZonaleRow(drPZ)
								End If
							End If

						Next

					Next

					daPrezzoUnitario.Update(ds.PrezzoUnitario)
					daPrezzoZonale.Update(ds.PrezzoZonale)


					If Not tr Is Nothing Then tr.Commit() : tr = Nothing
					If cn.State = ConnectionState.Open Then cn.Close()

					BatchSerializer.SetProgressBatch("Lettura MR (nuovo formato) - attivita` terminata con successo")
					Return True

				End If
			Next

		Catch ex As Exception
			If ErroreValidazione = False Then
				smError(ex, "Lettura MR (nuovo formato) fallita")
				BatchSerializer.SetProgressBatch("Lettura MR (nuovo formato) - attivita` terminata con errore")
			End If
			Return False

		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try


	End Function


	'===================== FUNZIONI PRIVATE ==================================
	Private Sub ValidationEvent(ByVal sender As Object, ByVal e As ValidationEventArgs)
		smTrace(e.Exception, "Lettura MR (nuovo formato) " + e.Message)
		ErroreValidazione = True
		Throw New ApplicationException(e.Message)
	End Sub

End Class
