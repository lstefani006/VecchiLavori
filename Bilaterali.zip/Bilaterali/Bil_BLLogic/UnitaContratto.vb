Imports System.Text
Imports System.Data.SqlClient

Public Class UnitaContratto
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents cmdSelectUnitaContratto As System.Data.SqlClient.SqlCommand
	Friend WithEvents daUnitaContratto As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents _ds_UnitaContratto As Bil.DS_UnitaContratto
	Friend WithEvents cmdInsertUnitaContratto As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmsUpdateUnitacontratto As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdDeleteUnitaContratto As System.Data.SqlClient.SqlCommand
	Friend WithEvents daContratto As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdSelectContratto As System.Data.SqlClient.SqlCommand
    Friend WithEvents spBilGetUnitaContratto As System.Data.SqlClient.SqlCommand
    Friend WithEvents daUnitaContratto2 As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.cmdSelectUnitaContratto = New System.Data.SqlClient.SqlCommand
        Me.daUnitaContratto = New System.Data.SqlClient.SqlDataAdapter
        Me.cmdDeleteUnitaContratto = New System.Data.SqlClient.SqlCommand
        Me.cmdInsertUnitaContratto = New System.Data.SqlClient.SqlCommand
        Me.cmsUpdateUnitacontratto = New System.Data.SqlClient.SqlCommand
        Me._ds_UnitaContratto = New Bil.DS_UnitaContratto
        Me.daContratto = New System.Data.SqlClient.SqlDataAdapter
        Me.cmdSelectContratto = New System.Data.SqlClient.SqlCommand
        Me.spBilGetUnitaContratto = New System.Data.SqlClient.SqlCommand
        Me.daUnitaContratto2 = New System.Data.SqlClient.SqlDataAdapter
        CType(Me._ds_UnitaContratto, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_user;data source=BILSVR1;persis" & _
        "t security info=False;initial catalog=Bilaterali"
        '
        'cmdSelectUnitaContratto
        '
        Me.cmdSelectUnitaContratto.CommandText = "SELECT * FROM Bil_Unita INNER JOIN dbo.tab_UnitaContratto2(@DataRicerca,@IdContra" & _
        "tto) UnitaContratto  ON Bil_Unita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC" & _
        " AND Bil_Unita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC"
        Me.cmdSelectUnitaContratto.Connection = Me.cn
        Me.cmdSelectUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataRicerca", System.Data.SqlDbType.DateTime, 4, "DataRicerca"))
        '
        'daUnitaContratto
        '
        Me.daUnitaContratto.SelectCommand = Me.cmdSelectUnitaContratto
        '
        'cmdDeleteUnitaContratto
        '
        Me.cmdDeleteUnitaContratto.CommandText = "DELETE FROM dbo.UnitaContratto WHERE (IdContratto = @IdContratto) AND (CodiceUnit" & _
        "aSDC = @CodiceUnitaSDC) AND (CategoriaUnitaSDC = @CategoriaUnitaSDC)"
        Me.cmdDeleteUnitaContratto.Connection = Me.cn
        Me.cmdDeleteUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
        Me.cmdDeleteUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        Me.cmdDeleteUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmdInsertUnitaContratto
        '
        Me.cmdInsertUnitaContratto.CommandText = "INSERT INTO dbo.UnitaContratto (CodiceUnitaSDC, CategoriaUnitaSDC, DataInizioVali" & _
        "dita, IdContratto, DataFineValidita, TSModifica, UnitaDelContrattoValidata, Prio" & _
        "ritaBilanciamentoForzato, UnitaAssegnataOpAcquirente, UnitaAssegnataOpCedente) V" & _
        "ALUES (@CodiceUnitaSDC, @CategoriaUnitaSDC, @DataInizioValidita, @IdContratto, @" & _
        "DataFineValidita, @TSModifica, @UnitaDelContrattoValidata, @PrioritaBilanciament" & _
        "oForzato, @UnitaAssegnataOpAcquirente, @UnitaAssegnataOpCedente)"
        Me.cmdInsertUnitaContratto.Connection = Me.cn
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitaDelContrattoValidata", System.Data.SqlDbType.Bit, 1, "UnitaDelContrattoValidata"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PrioritaBilanciamentoForzato", System.Data.SqlDbType.Int, 4, "PrioritaBilanciamentoForzato"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitaAssegnataOpAcquirente", System.Data.SqlDbType.Bit, 1, "UnitaAssegnataOpAcquirente"))
        Me.cmdInsertUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitaAssegnataOpCedente", System.Data.SqlDbType.Bit, 1, "UnitaAssegnataOpCedente"))
        '
        'cmsUpdateUnitacontratto
        '
        Me.cmsUpdateUnitacontratto.CommandText = "UPDATE dbo.UnitaContratto SET DataInizioValidita = @DataInizioValidita, DataFineV" & _
        "alidita = @DataFineValidita, TSModifica = @TSModifica, UnitaDelContrattoValidata" & _
        " = @UnitaDelContrattoValidata, UnitaAssegnataOpCedente = @UnitaAssegnataOpCedent" & _
        "e, UnitaAssegnataOpAcquirente = @UnitaAssegnataOpAcquirente, PrioritaBilanciamen" & _
        "toForzato = @PrioritaBilanciamentoForzato WHERE (IdContratto = @IdContratto) AND" & _
        " (CodiceUnitaSDC = @CodiceUnitaSDC) AND (CategoriaUnitaSDC = @CategoriaUnitaSDC)" & _
        ""
        Me.cmsUpdateUnitacontratto.Connection = Me.cn
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitaDelContrattoValidata", System.Data.SqlDbType.Bit, 1, "UnitaDelContrattoValidata"))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitaAssegnataOpCedente", System.Data.SqlDbType.Bit, 1, "UnitaAssegnataOpCedente"))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitaAssegnataOpAcquirente", System.Data.SqlDbType.Bit, 1, "UnitaAssegnataOpAcquirente"))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PrioritaBilanciamentoForzato", System.Data.SqlDbType.Int, 4, "PrioritaBilanciamentoForzato"))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        Me.cmsUpdateUnitacontratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        '_ds_UnitaContratto
        '
        Me._ds_UnitaContratto.CaseSensitive = True
        Me._ds_UnitaContratto.DataSetName = "DS_UnitaContratto"
        Me._ds_UnitaContratto.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        'daContratto
        '
        Me.daContratto.SelectCommand = Me.cmdSelectContratto
        '
        'cmdSelectContratto
        '
        Me.cmdSelectContratto.CommandText = "SELECT dbo.Bil_ContrattoOperatore.* FROM dbo.Bil_ContrattoOperatore WHERE (IdCont" & _
        "ratto = @IdContratto)"
        Me.cmdSelectContratto.Connection = Me.cn
        Me.cmdSelectContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, ""))
        '
        'spBilGetUnitaContratto
        '
        Me.spBilGetUnitaContratto.CommandText = "dbo.[spBilGetUnitaContratto]"
        Me.spBilGetUnitaContratto.CommandType = System.Data.CommandType.StoredProcedure
        Me.spBilGetUnitaContratto.Connection = Me.cn
        Me.spBilGetUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        Me.spBilGetUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@di", System.Data.SqlDbType.DateTime, 8))
        Me.spBilGetUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@df", System.Data.SqlDbType.DateTime, 8))
        Me.spBilGetUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
        Me.spBilGetUnitaContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@InValidita", System.Data.SqlDbType.Bit, 1))
        '
        'daUnitaContratto2
        '
        Me.daUnitaContratto2.SelectCommand = Me.spBilGetUnitaContratto
        Me.daUnitaContratto2.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "UnitaContratto", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"), New System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"), New System.Data.Common.DataColumnMapping("NomeUnita", "NomeUnita"), New System.Data.Common.DataColumnMapping("TipoUnita", "TipoUnita"), New System.Data.Common.DataColumnMapping("SottotipoUnita", "SottotipoUnita"), New System.Data.Common.DataColumnMapping("CoefficientePerdita", "CoefficientePerdita"), New System.Data.Common.DataColumnMapping("CodicePuntoDiScambioRilevanteSDC", "CodicePuntoDiScambioRilevanteSDC"), New System.Data.Common.DataColumnMapping("PotenzaMassimaMWh", "PotenzaMassimaMWh"), New System.Data.Common.DataColumnMapping("PotenzaMinimaMWh", "PotenzaMinimaMWh"), New System.Data.Common.DataColumnMapping("OrdineDiMerito", "OrdineDiMerito"), New System.Data.Common.DataColumnMapping("CodiceOperatoreDiRiferimentoSDC", "CodiceOperatoreDiRiferimentoSDC"), New System.Data.Common.DataColumnMapping("Abilitata", "Abilitata"), New System.Data.Common.DataColumnMapping("ResponsabileAggiornamento", "ResponsabileAggiornamento"), New System.Data.Common.DataColumnMapping("StatoBilateraliUnita", "StatoBilateraliUnita"), New System.Data.Common.DataColumnMapping("Unita_TSModifica", "Unita_TSModifica"), New System.Data.Common.DataColumnMapping("SDC_Unita_TSModifica", "SDC_Unita_TSModifica"), New System.Data.Common.DataColumnMapping("CodiceZonaSDC", "CodiceZonaSDC"), New System.Data.Common.DataColumnMapping("UnbalancedParticipantNumber", "UnbalancedParticipantNumber"), New System.Data.Common.DataColumnMapping("MgpEnabled", "MgpEnabled"), New System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"), New System.Data.Common.DataColumnMapping("DataInizioValidita", "DataInizioValidita"), New System.Data.Common.DataColumnMapping("DataFineValidita", "DataFineValidita"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"), New System.Data.Common.DataColumnMapping("DataInizioValiditaUnita", "DataInizioValiditaUnita"), New System.Data.Common.DataColumnMapping("DataFineValiditaUnita", "DataFineValiditaUnita"), New System.Data.Common.DataColumnMapping("UnitaDelContrattoValidata", "UnitaDelContrattoValidata"), New System.Data.Common.DataColumnMapping("UnitaAssegnataOpCedente", "UnitaAssegnataOpCedente"), New System.Data.Common.DataColumnMapping("UnitaAssegnataOpAcquirente", "UnitaAssegnataOpAcquirente"), New System.Data.Common.DataColumnMapping("PrioritaBilanciamentoForzato", "PrioritaBilanciamentoForzato"), New System.Data.Common.DataColumnMapping("TrCC", "TrCC"), New System.Data.Common.DataColumnMapping("TrUC", "TrUC"), New System.Data.Common.DataColumnMapping("VUC", "VUC")})})
        CType(Me._ds_UnitaContratto, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region

	Public Function GetUnitaContratto(ByVal IdContratto As Integer, ByVal fillContratto As Boolean, ByVal DataRicerca As DateTime) As DS_UnitaContratto
		Dim ds As New DS_UnitaContratto
		_cn.ConnectionString = GetConnectionString()
		Try
			_cn.Open()
			cmdSelectUnitaContratto.Parameters("@DataRicerca").Value = DataRicerca
			If True Then
				Dim c As StringBuilder = New StringBuilder
				If IdContratto > 0 Then
					c.Append(" WHERE ")
					c.Append(_ds_UnitaContratto.UnitaContratto.IdContrattoColumn.ColumnName)
					c.Append(" = @IdContratto")
					cmdSelectUnitaContratto.Parameters.Add("@IdContratto", IdContratto)
				End If

				If (c.Length > 0) Then cmdSelectUnitaContratto.CommandText &= c.ToString()

				daUnitaContratto.Fill(ds.UnitaContratto)
			End If

			If fillContratto AndAlso IdContratto > 0 AndAlso DataRicerca.ToString <> String.Empty Then
				daContratto.SelectCommand.Parameters("@IdContratto").Value = IdContratto
				daContratto.Fill(ds.Contratto)
			End If

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function

	Public Sub SaveUnitaContratto(ByVal ds As DS_UnitaContratto)
		_cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction = Nothing
		Try
			_cn.Open()
			tr = _cn.BeginTransaction()
			SetTransaction(daUnitaContratto, tr)

			Dim tm As DateTime = DateTime.Now

			'For Each dr As DS_UnitaContratto.UnitaContrattoRow In ds.UnitaContratto.Rows
			'    If (dr.RowState = DataRowState.Modified Or dr.RowState = DataRowState.Added) Then
			'        dr.TSModifica = tm
			'    End If
			'Next


			daUnitaContratto.Update(ds.UnitaContratto)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Sub

	Public Function GetMAXPrioritaBilanciamento(ByVal idContratto As Integer, ByVal DataRicerca As DateTime) As Integer

		_cn.ConnectionString = GetConnectionString()
		Try
			_cn.Open()
			Dim query As String = "SELECT ISNULL(MAX(PrioritaBilanciamentoForzato), 0) FROM tab_UnitaContratto2(@DataRicerca,@IdContratto) WHERE IdContratto = @IdContratto"

			Dim cmd As New SqlCommand(query, _cn)
			cmd.Parameters.Add("@IdContratto", idContratto)
			cmd.Parameters.Add("@DataRicerca", DataRicerca)
			Return DirectCast(cmd.ExecuteScalar(), Integer)
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
    End Function

#Region " Funzioni aggiunte per nuova form UnitaContratto frmUnitaContratto3 Chiamata STG 5681 "
    Public Function GetUnitaContratto2(ByVal IdContratto As Integer, ByVal fillContratto As Boolean, ByVal InValidita As Boolean, ByVal DataInizioValidita As DateTime, ByVal DataFineValidita As DateTime) As DS_UnitaContratto2
        Dim ds As New DS_UnitaContratto2
        _cn.ConnectionString = GetConnectionString()
        Try
            _cn.Open()
            If InValidita = True Then
                spBilGetUnitaContratto.Parameters("@di").Value = DBNull.Value
                spBilGetUnitaContratto.Parameters("@df").Value = DBNull.Value
            Else
                spBilGetUnitaContratto.Parameters("@di").Value = DataInizioValidita
                spBilGetUnitaContratto.Parameters("@df").Value = DataFineValidita
            End If

            spBilGetUnitaContratto.Parameters("@IdContratto").Value = IdContratto
            spBilGetUnitaContratto.Parameters("@InValidita").Value = InValidita

            daUnitaContratto2.Fill(ds.UnitaContratto)

            If fillContratto AndAlso IdContratto > 0 Then
                daContratto.SelectCommand.Parameters("@IdContratto").Value = IdContratto
                daContratto.Fill(ds.Contratto)
            End If

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If _cn.State = ConnectionState.Open Then _cn.Close()
        End Try
    End Function
#End Region

End Class
