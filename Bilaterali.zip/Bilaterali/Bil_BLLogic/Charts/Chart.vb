Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Collections

Public Class Chart
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents da As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdQtyGiornoCedAcq As System.Data.SqlClient.SqlCommand
    Friend WithEvents daQtyGiornoCedAcq As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdQtyGiornoOraCedente As System.Data.SqlClient.SqlCommand
    Friend WithEvents daQtyGiornoOraCedente As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdQtyGiornoOraAcquirente As System.Data.SqlClient.SqlCommand
    Friend WithEvents daQtyGiornoOraAcquirente As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.cmdSelect = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
		Me.da = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdQtyGiornoCedAcq = New System.Data.SqlClient.SqlCommand
		Me.daQtyGiornoCedAcq = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdQtyGiornoOraCedente = New System.Data.SqlClient.SqlCommand
		Me.cmdQtyGiornoOraAcquirente = New System.Data.SqlClient.SqlCommand
		Me.daQtyGiornoOraCedente = New System.Data.SqlClient.SqlDataAdapter
		Me.daQtyGiornoOraAcquirente = New System.Data.SqlClient.SqlDataAdapter
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persis" & _
		"t security info=False;initial catalog=Bilaterali"
		'
		'da
		'
		Me.da.DeleteCommand = Me.SqlDeleteCommand1
		Me.da.InsertCommand = Me.SqlInsertCommand1
		Me.da.SelectCommand = Me.cmdSelect
		Me.da.UpdateCommand = Me.SqlUpdateCommand1
		'
		'cmdQtyGiornoCedAcq
		'
		Me.cmdQtyGiornoCedAcq.CommandText = "SELECT pou.PeriodoRilevante, ABS(SUM(CASE pou.ProgrammatoDalCedente WHEN 1 THEN p" & _
		"ou.QtyMWh ELSE 0 END)) AS QtyMWhCedente, ABS(SUM(CASE pou.ProgrammatoDalCedente " & _
		"WHEN 0 THEN pou.QtyMWh ELSE 0 END)) AS QtyMWhAcquirente FROM dbo.ProgrammaOrario" & _
		"PerUnita pou INNER JOIN (SELECT IdContratto FROM Contratto WHERE DataInizioValid" & _
		"ita <= @data AND DataFineValidita >= @data) C ON pou.IdContratto = C.IdContratto" & _
		" WHERE (pou.DataProgramma = @data) AND (pou.ProgOrarioDellUnitaValidato = 1) GRO" & _
		"UP BY pou.PeriodoRilevante ORDER BY pou.PeriodoRilevante"
		Me.cmdQtyGiornoCedAcq.Connection = Me.cn
		Me.cmdQtyGiornoCedAcq.Parameters.Add(New System.Data.SqlClient.SqlParameter("@data", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		'
		'daQtyGiornoCedAcq
		'
		Me.daQtyGiornoCedAcq.SelectCommand = Me.cmdQtyGiornoCedAcq
		'
		'cmdQtyGiornoOraCedente
		'
		Me.cmdQtyGiornoOraCedente.CommandText = "SELECT c.CodiceOperatoreSDCCedente AS CodiceOperatoreSDC, SUM(pou.QtyMWh) AS QtyM" & _
		"WhCedente, c.CodiceOperatoreSDCCedente FROM dbo.ProgrammaOrarioPerUnita pou INNE" & _
		"R JOIN (SELECT IdContratto, CodiceOperatoreSDCCedente FROM contratto WHERE DataI" & _
		"nizioValidita <= @data AND DataFineValidita >= @data AND TrCN = 1) c ON pou.IdCo" & _
		"ntratto = c.idcontratto WHERE (pou.DataProgramma = @data) AND (pou.PeriodoRileva" & _
		"nte = @ora) AND (pou.ProgrammatoDalCedente = 1) AND (pou.ProgOrarioDellUnitaVali" & _
		"dato = 1) GROUP BY c.CodiceOperatoreSDCCedente ORDER BY QtyMWhCedente DESC"
		Me.cmdQtyGiornoOraCedente.Connection = Me.cn
		Me.cmdQtyGiornoOraCedente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@data", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.cmdQtyGiornoOraCedente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ora", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		'
		'cmdQtyGiornoOraAcquirente
		'
		Me.cmdQtyGiornoOraAcquirente.CommandText = "select c.CodiceOperatoreSDCAcquirente CodiceOperatoreSDC, abs(sum(pou.QtyMWh)) Qt" & _
		"yMWhAcquirente, c.CodiceOperatoreSDCAcquirente from programmaorarioperunita pou," & _
		" (select IdContratto, CodiceOperatoreSDCAcquirente from contratto where DataIniz" & _
		"ioValidita <= @data and DataFineValidita >= @data and TrCN = 1) c where pou.data" & _
		"programma = @data and pou.periodorilevante = @ora and pou.ProgrammatoDalCedente " & _
		"= 0 and pou.ProgOrarioDellUnitaValidato = 1 and pou.idcontratto = c.idcontratto " & _
		"group by c.CodiceOperatoreSDCAcquirente order by QtyMWhAcquirente desc"
		Me.cmdQtyGiornoOraAcquirente.Connection = Me.cn
		Me.cmdQtyGiornoOraAcquirente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@data", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.cmdQtyGiornoOraAcquirente.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ora", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		'
		'daQtyGiornoOraCedente
		'
		Me.daQtyGiornoOraCedente.SelectCommand = Me.cmdQtyGiornoOraCedente
		'
		'daQtyGiornoOraAcquirente
		'
		Me.daQtyGiornoOraAcquirente.SelectCommand = Me.cmdQtyGiornoOraAcquirente

	End Sub

#End Region

    Public Function GetDSQtyGiornoCedAcq(ByVal Data As DateTime) As DataSet
        cn.ConnectionString = GetConnectionString()
        Try
            'cn.Open()

            'Dim sSql As String

            'sSql = "select pou.PeriodoRilevante, "
            'sSql = sSql + "abs(sum(case pou.ProgrammatoDalCedente when 1 then pou.QtyMWh else 0 end)) QtyMWhCedente, "
            'sSql = sSql + "abs(sum(case pou.ProgrammatoDalCedente when 0 then pou.QtyMWh else 0 end)) QtyMWhAcquirente "
            'sSql = sSql + "from ProgrammaOrarioPerUnita pou, "
			'sSql = sSql + "(select IdContratto, CodiceUnitaSDC, CategoriaUnitaSDC from tab_UnitaContratto(@Data) "
            'sSql = sSql + "where UnitaDelContrattoValidata = 1 "
            'sSql = sSql + "and TrCC = 1 "
            'sSql = sSql + "and TrUC = 1 "
            'sSql = sSql + "and DataInizioValidita <= @data "
            'sSql = sSql + "and DataFineValidita >= @data) uc "
            'sSql = sSql + "where pou.DataProgramma = @data "
            'sSql = sSql + "and pou.ProgOrarioDellUnitaValidato = 1 "
            'sSql = sSql + "and uc.IdContratto = pou.IdContratto "
            'sSql = sSql + "and uc.CodiceUnitaSDC = pou.CodiceUnitaSDC "
            'sSql = sSql + "and uc.CategoriaUnitaSDC = pou.CategoriaUnitaSDC "
            'sSql = sSql + "group by pou.PeriodoRilevante "
            'sSql = sSql + "order by pou.PeriodoRilevante"

            'cmdSelect.CommandText = sSql
            'cmdSelect.Connection = cn

            'cmdSelect.Parameters.Clear()
            'cmdSelect.Parameters.Add("@data", Data)

            'Dim ds As New DataSet
            'ds.Tables.Add("GetDSQtyGiornoCedAcq")
            'da.Fill(ds.Tables("GetDSQtyGiornoCedAcq"))

            'Return ds

            cmdQtyGiornoCedAcq.Parameters("@data").Value = Data
            cn.Open()
            Dim ds As New DS_QtyGiornoCedAcq
            daQtyGiornoCedAcq.Fill(ds.QtyGiornoCedAcq)
			Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            cn.Dispose()
        End Try
    End Function


    Public Function GetDSQtyGiornoOraCedente(ByVal Data As DateTime, ByVal Ora As Integer) As DataSet
        cn.ConnectionString = GetConnectionString()
        Try
            'cn.Open()

            'Dim sSql As String

            '' Produttori
            'sSql = "select c.CodiceOperatoreSDCCedente CodiceOperatoreSDC, sum(pou.QtyMWh) QtyMWhCedente,  c.CodiceOperatoreSDCCedente "
            'sSql = sSql + "from programmaorarioperunita pou, "
            'sSql = sSql + "(select IdContratto, CodiceOperatoreSDCCedente from contratto "
            'sSql = sSql + "where DataInizioValidita <= @data "
            'sSql = sSql + "and DataFineValidita >= @data "
            'sSql = sSql + "and TrCN = 1) c "
            'sSql = sSql + "where pou.dataprogramma = @data "
            'sSql = sSql + "and pou.periodorilevante = @ora "
            'sSql = sSql + "and pou.ProgrammatoDalCedente = 1 "
            'sSql = sSql + "and pou.ProgOrarioDellUnitaValidato = 1 "
            'sSql = sSql + "and pou.idcontratto = c.idcontratto "
            'sSql = sSql + "group by c.CodiceOperatoreSDCCedente "
            'sSql = sSql + "order by QtyMWhCedente desc"

            'cmdSelect.CommandText = sSql
            'cmdSelect.Connection = cn

            'cmdSelect.Parameters.Clear()
            'cmdSelect.Parameters.Add("@data", Data)
            'cmdSelect.Parameters.Add("@ora", Ora)

            'Dim ds As New DataSet
            'ds.Tables.Add("GetDSQtyGiornoOraCedente")
            'da.Fill(ds.Tables("GetDSQtyGiornoOraCedente"))

            'Return ds

            cmdQtyGiornoOraCedente.Parameters("@data").Value = Data
            cmdQtyGiornoOraCedente.Parameters("@ora").Value = Ora
            cn.Open()
            Dim ds As New DS_QtyGiornoOraCedente
            daQtyGiornoOraCedente.Fill(ds.QtyGiornoOraCedente)
			Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            cn.Dispose()
        End Try
    End Function

    Public Function GetDSQtyGiornoOraAcquirente(ByVal Data As DateTime, ByVal Ora As Integer) As DataSet
        cn.ConnectionString = GetConnectionString()
        Try
            'cn.Open()

            'Dim sSql As String

            '' Consumatori
            'sSql = "select c.CodiceOperatoreSDCAcquirente CodiceOperatoreSDC, sum(pou.QtyMWh) QtyMWhAcquirente, c.CodiceOperatoreSDCAcquirente "
            'sSql = sSql + "from programmaorarioperunita pou, "
            'sSql = sSql + "(select IdContratto, CodiceOperatoreSDCAcquirente from contratto "
            'sSql = sSql + "where DataInizioValidita <= @data "
            'sSql = sSql + "and DataFineValidita >= @data "
            'sSql = sSql + "and TrCN = 1) c "
            'sSql = sSql + "where pou.dataprogramma = @data "
            'sSql = sSql + "and pou.periodorilevante = @ora "
            'sSql = sSql + "and pou.ProgrammatoDalCedente = 0 "
            'sSql = sSql + "and pou.ProgOrarioDellUnitaValidato = 1 "
            'sSql = sSql + "and pou.idcontratto = c.idcontratto "
            'sSql = sSql + "group by c.CodiceOperatoreSDCAcquirente "
            'sSql = sSql + "order by QtyMWhAcquirente desc"

            'cmdSelect.CommandText = sSql
            'cmdSelect.Connection = cn

            'cmdSelect.Parameters.Clear()
            'cmdSelect.Parameters.Add("@data", Data)
            'cmdSelect.Parameters.Add("@ora", Ora)

            'Dim ds As New DataSet
            'ds.Tables.Add("GetDSQtyGiornoOraAcquirente")
            'da.Fill(ds.Tables("GetDSQtyGiornoOraAcquirente"))

            'Return ds

            cmdQtyGiornoOraAcquirente.Parameters("@data").Value = Data
            cmdQtyGiornoOraAcquirente.Parameters("@ora").Value = Ora
            cn.Open()
            Dim ds As New DS_QtyGiornoOraAcquirente
            daQtyGiornoOraAcquirente.Fill(ds.QtyGiornoOraAcquirente)
			Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            cn.Dispose()
        End Try
    End Function
End Class
