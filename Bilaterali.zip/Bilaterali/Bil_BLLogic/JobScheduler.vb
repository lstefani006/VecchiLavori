' STR 317 (chiaamata 5252)
' E` stato riscritta la routine che lancia i job a tempo.
' La precedente versione schedulava raffiche di job invece che uno solo.
' Questa versione dovrebbe essere resistente ai cambi dell'ora legale e alla correzione
' del clock di sistema fatta via internet o altro hd.
Imports System
Imports System.Collections
Imports System.Threading

' Classe che implementa un semplice schedluer che chiama job a a delle ore fisse nel giorno.
' La granularita` del timer che controlla se ci sono job da eseguire e` di un minuto; il thread
' si sveglia sempre all'inizio di ogni minuto (ossia al secondo zero)
' Dovrebbe essere resistente a
' 1) cambiamenti dell'ora legale
' 2) cambiamenti dell'orologio di sistema a fronte di aggiornamenti da internet ecc.
' Nel caso (1) e` garantito che i job da eseguire dalle 2 alle 3 di notte dell'ultima dom di ottobre
' siano eseguiti una sola volta e piu` precisamente nella prima ora 2/3
' Sempre nel capo (1) nell'ultima dom di marzo i job da eseguire dalle 2 alle 3 do notte vengono eseguiti tutti
' in successione all'istante 3:00:00 (che viene immediatamente in successione delle 1.59.59)
' Un job puo` anche metterci piu` di un minuto di esecuzione. I job che sarebbero dovuti essere eseguiti in quel minuto
' verranno comunque eseguiti nel prossimo minuto.
' I job possono essere aggiunti al volo, quando lo scheduler sta funzionado
' dato che la tabella e` protetta con una regione critica.
' Per prigrizia non e` possibile rimuovere un job.
Public Class JobScheduler
	Implements IDisposable

	Private Shared _JobScheduler As JobScheduler

	Public Shared ReadOnly Property G() As JobScheduler
		Get
			If _JobScheduler Is Nothing Then
				_JobScheduler = New JobScheduler
			End If
			Return _JobScheduler
		End Get
	End Property

	Private _t As System.Threading.Timer = Nothing
	Private _Jobs As ArrayList = New ArrayList
	Private _lastDateTime As DateTime


	Private Sub New()
		_Jobs = New ArrayList
		_t = Nothing
	End Sub

	Public Sub Start()
		If _t Is Nothing Then
			_Jobs.Sort()
			_lastDateTime = DateTime.Now

			' creo il timer in modo da non farlo partire mai
			_t = New System.Threading.Timer(AddressOf Th, Nothing, System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite)

			' lo faccio partire qui al prossimo minuto
			StartTimer()
		End If
	End Sub

	Public Sub ExecuteJob(ByVal at As TimeSpan, ByVal j As WaitCallback)
		Dim jb As Job = New Job
		jb.ExecutionOnTime = at
		jb.JobToExecute = j
		SyncLock Me
			_Jobs.Add(jb)
			' faccio il sort in modo da avere i job ordinati nella lista secondo l'ora di esecuzione
			_Jobs.Sort()
		End SyncLock
	End Sub

	Public Sub [Stop]()
		If Not (_t Is Nothing) Then
			_t.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite)
		End If
	End Sub

	Public Sub Dispose() Implements System.IDisposable.Dispose
		_t.Dispose()
		_t = Nothing
	End Sub


	Public Class Job
		Implements IComparable
		Public ExecutionOnTime As TimeSpan
		Public JobToExecute As WaitCallback

		Public Overridable Sub Execute()
			JobToExecute(Me.ExecutionOnTime)
		End Sub

		Public Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
			If obj Is Nothing Then
				Return 1
			End If
			Dim a As TimeSpan = Me.ExecutionOnTime
			Dim b As TimeSpan = CType(obj, Job).ExecutionOnTime
			Return TimeSpan.Compare(a, b)
		End Function
	End Class

	Private Sub Th(ByVal state As Object)
		' il DateTime come il TimeStamp sono una brutta bestia.
		' Sembra che siano insensibili alla localizzazione.
		' Il "sembra" e` motivato dal fatto che ToString stampa l'ora facendo conti numerici e non guardando 
		' la localizzazione, ora legale ecc, ecc.
		' In pratica, nel formato interno si usa un contatore che viene incrementato per far passare il tempo.
		' DateTime ha un contatore, TimeSpan ha lo stesso contatore "in modulo".
		' Quando per causa di ore legali orologio torna indietro torna indietro anche il contatore.
		' Le operazioni di < <= > >= vengono fatte confrontando il tick (contatore interno) e dunque 
		' si avra`, solo per l'ultima di ottobre, un tsNow < tsPrevious (cosa alquanto bizzarra).
		' Normalmente anche il TimeSpan ha last < current
		' Ma tra le 23.59.59 e 0.0.0 si avra last > current (sempre come TimeSpan)
		' In maniera analoga alle 2.59.59 sara` seguito da 2.0.0 nell'ultima dom di ottobre: dunque last > current


		' prendo l'ora corrente
		Dim currDateTime As DateTime = DateTime.Now

		' Di solito currDateTime e` > lastDateTime (il tempo scorre sempre in una direzione)
		' Ci sono due eccezioni: 
		' 1) l'ultimo domenica di ottobre tra le 2 e le 3 di notte, quando bisogna
		' portare un'ora indietro l'orologio per il recupero all'ora solare
		' Quando capita vuol dire che lastDateTime indica 2.59.59 e currentDateTime 2.00.00
		' In questo caso lo scheduler ha gia` lanciato gli eventuali job che vanno dalle 2 alle 3
		' Bisogna evitare di lanciare una seconda volta i job quando si riesegue l'ora 2..3
		' 2) aggiornamenti dell'ora da internet, parabole, orologi atomici al cesio ecc.
		' Per evitare che condizioni simili facciano eseguire 2 volte un batch si fa il seguente If
		' Notare che il > si applica sulle DateTime e non sulle ore (TimeSpan)
		If DateTime.op_GreaterThan(currDateTime, _lastDateTime) Then
			' Siamo nel mondo normale... dove il tempo procede sempre in avanti e non indietreggia.

			' metto in je tutti i batch da eseguire
			' nel caso di passaggio per la mezzanotte metto prima i job
			' dell 23 e poi quelli delle 0:00
			Dim je As ArrayList = New ArrayList

			SyncLock Me

				Dim lastTimeSpan As TimeSpan = _lastDateTime.TimeOfDay
				Dim currTimeSpan As TimeSpan = currDateTime.TimeOfDay

				' Qui controllo se sto passando per la mezzanotte.
				If currDateTime.Day = _lastDateTime.Day Then
					Debug.Assert(TimeSpan.op_LessThan(lastTimeSpan, currTimeSpan))

					' currDate e lastDate sono nello stesso giorno
					FindJobs(lastTimeSpan, currTimeSpan, je)
				Else
					' passaggio per la mezzanotte
					Debug.Assert(lastTimeSpan.Hours = 23)
					Debug.Assert(currTimeSpan.Hours = 0)

					FindJobs(lastTimeSpan, tsMax, je)					 ' i job delle ore 23 devono essere posti per primi in je
					FindJobs(tsMin, currTimeSpan, je)					 ' i job delle ore 0:00 devono essere posti per ultimi in je
				End If

			End SyncLock

			' eseguo tutti i batch trovati
			For Each b As Job In je
				Try
					b.Execute()
				Catch
				End Try
				' do respiro al sistema
				Thread.Sleep(1000)
			Next

			' riprendo il giro ricordandomi l'ultimo valore
			' ( a prescindere da quanto ci si mette a fare l'esecuzione dei batch. )
			' NB. questa assegnazione deve essere fatta dentro l'if
			' perche` sto coso presuppone che lastDateTime < currDateTime
			_lastDateTime = currDateTime
		Else
			' Siamo in un mondo particolare che sfida ogni legge della fisica:
			' 1) ultima domenica di ottobre
			' 2) hanno toccato l'orologio di sistema
			' Qui non aggiorno lastDateTime in modo da avere sempre 
			' currDatetime < lastDateTime.
			' L'effetto voluto e`:
			' 1) nell'ultimo dom di ottobre i job sono eseguiti una volta sola tra prima ora [2..3)
			' 2) Se cambiano l'ora indietro non eseguo i job gia` eseguiti.
			Debug.Assert(currDateTime.DayOfWeek = DayOfWeek.Sunday)
			Debug.Assert(currDateTime.Month = 10)
		End If

		' riarmo il timer per il prossimo giro
		StartTimer()
	End Sub

	Private Sub StartTimer()
		If Not (_t Is Nothing) Then
			Dim adesso As DateTime = DateTime.Now
			Dim sleep As Integer = 60 * 1000 - (adesso.Second * 1000 + adesso.Millisecond)
			sleep += 500			 ' lo forzo a svegliarsi a metta' del primo secondo del prossimo minuto
			_t.Change(sleep, -1)
		End If
	End Sub

	Private Sub FindJobs(ByVal lastTimeSpan As TimeSpan, ByVal currTimeSpan As TimeSpan, ByVal je As ArrayList)
		For Each b As Job In Me._Jobs
			If Not (b Is Nothing) Then
				Dim bex As TimeSpan = b.ExecutionOnTime
				' lastTimeSpan < bex <= currTimeSpan
				If TimeSpan.op_LessThan(lastTimeSpan, bex) AndAlso TimeSpan.op_LessThanOrEqual(bex, currTimeSpan) Then
					je.Add(b)
				End If
			End If
		Next
	End Sub

	Private Shared tsMin As TimeSpan = New TimeSpan(0, 0, 0, 0, 0)
	Private Shared tsMax As TimeSpan = New TimeSpan(0, 23, 59, 59, 999)

End Class


'Imports System
'Imports System.Collections
'Imports System.Threading

'' Classe che implementa un semplice schedluer che chiama job a a delle ore fisse nel giorno.
'' La granularita` del timer che controlla se ci sono job da eseguire e` di un minuto; il thread
'' si sveglia sempre all'inizio di ogni minuto (ossia al secondo zero)
'' Dovrebbe essere resistente a
'' 1) cambiamenti dell'ora legale
'' 2) cambiamenti dell'orologio di sistema a fronte di aggiornamenti da internet ecc.
'' Nel caso (1) e` garantito che i job da eseguire dalle 2 alle 3 di notte dell'ultima dom di ottobre
'' siano eseguiti una sola volta e piu` precisamente nella prima ora 2/3
'' Sempre nel capo (1) nell'ultima dom di marzo i job da eseguire dalle 2 alle 3 do notte vengono eseguiti tutti
'' in successione all'istante 3:00:00 (che viene immediatamente in successione delle 1.59.59)
'' Un job puo` anche metterci piu` di un minuto di esecuzione. I job che sarebbero dovuti essere eseguiti in quel minuto
'' verranno comunque eseguiti nel prossimo minuto.
'' I job possono essere aggiunti al volo, quando lo schedure sta funzionado
'' dato che la tabella e` protetta con una regione critica.
'' Per prigrizia non e` possibile rimuovere un job.
'Public Class JobScheduler

'	Private Shared _JobScheduler As JobScheduler

'	Public Shared ReadOnly Property G() As JobScheduler
'		Get
'			If _JobScheduler Is Nothing Then
'				_JobScheduler = New JobScheduler
'			End If
'			Return _JobScheduler
'		End Get
'	End Property

'	Private Sub New()
'		_Jobs = New ArrayList
'		_t = Nothing
'	End Sub

'	Public Sub Start()
'		If _t Is Nothing Then
'			_Jobs.Sort()
'			_t = New Thread(AddressOf Th)
'			_t.IsBackground = True
'			_t.Start()
'		End If
'	End Sub

'	Public Sub ExecuteJob(ByVal at As TimeSpan, ByVal j As WaitCallback)
'		Dim jb As Job = New Job
'		jb.ExecutionOnTime = at
'		jb.JobToExecute = j
'		SyncLock Me
'			_Jobs.Add(jb)
'			_Jobs.Sort()
'		End SyncLock
'	End Sub

'	Public Sub [Stop]()
'		If Not (_t Is Nothing) Then
'			_t.Abort()
'			_t = Nothing
'		End If
'	End Sub
'	Private _t As Thread = Nothing
'	Private _Jobs As ArrayList = New ArrayList

'	Public Class Job
'		Implements IComparable
'		Public ExecutionOnTime As TimeSpan
'		Public JobToExecute As WaitCallback

'		Public Overridable Sub Execute()
'			JobToExecute(Me.ExecutionOnTime)
'		End Sub

'		Public Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
'			If obj Is Nothing Then
'				Return 1
'			End If
'			Dim a As TimeSpan = Me.ExecutionOnTime
'			Dim b As TimeSpan = CType(obj, Job).ExecutionOnTime
'			Return TimeSpan.Compare(a, b)
'		End Function
'	End Class

'	Private Sub Th()
'		Dim last As TimeSpan = DateTime.Now.TimeOfDay
'		While True
'			Dim sleep As Integer = 60 - DateTime.Now.Second
'			Thread.Sleep(1000 * sleep)
'			Dim n As DateTime = DateTime.Now
'			Dim current As TimeSpan = n.TimeOfDay
'			If TimeSpan.op_GreaterThan(current, last) Then
'				Dim je As ArrayList = New ArrayList
'				SyncLock Me
'					For Each b As Job In Me._Jobs
'						If Not (b Is Nothing) Then
'							Dim bex As TimeSpan = b.ExecutionOnTime
'							If TimeSpan.op_LessThan(last, bex) AndAlso TimeSpan.op_LessThanOrEqual(bex, current) Then
'								je.Add(b)
'							End If
'						End If
'					Next
'				End SyncLock
'				For Each b As Job In je
'					Try
'						b.Execute()
'					Catch
'					End Try
'					Thread.Sleep(1000)
'				Next
'				last = current
'			End If
'		End While
'	End Sub
'End Class


