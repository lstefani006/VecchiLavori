Public Class Ruoli
    Inherits Bil.BilBLBase

#Region " Component Designer generated code "

    Public Sub New(Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents daRuoli As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents daFunzioni As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents daRuoliFunzioni As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlSelectCommand3 As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.daRuoli = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.daFunzioni = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand
        Me.daRuoliFunzioni = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlSelectCommand3 = New System.Data.SqlClient.SqlCommand
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=GATTO;packet size=4096;user id=sa;data source=BILSVR1;persist secu" & _
        "rity info=True;initial catalog=Bilaterali_ROMA5;password=bilaterali"
        '
        'daRuoli
        '
        Me.daRuoli.SelectCommand = Me.SqlSelectCommand1
        Me.daRuoli.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Ruoli", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceRuolo", "CodiceRuolo"), New System.Data.Common.DataColumnMapping("DescrizioneRuolo", "DescrizioneRuolo")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT CodiceRuolo, DescrizioneRuolo FROM Ruoli"
        Me.SqlSelectCommand1.Connection = Me.cn
        '
        'daFunzioni
        '
        Me.daFunzioni.SelectCommand = Me.SqlSelectCommand2
        Me.daFunzioni.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Funzioni", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceFunzione", "CodiceFunzione"), New System.Data.Common.DataColumnMapping("DescrizioneFunzione", "DescrizioneFunzione")})})
        '
        'SqlSelectCommand2
        '
        Me.SqlSelectCommand2.CommandText = "SELECT CodiceFunzione, DescrizioneFunzione FROM Funzioni"
        Me.SqlSelectCommand2.Connection = Me.cn
        '
        'daRuoliFunzioni
        '
        Me.daRuoliFunzioni.SelectCommand = Me.SqlSelectCommand3
        Me.daRuoliFunzioni.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "RuoliFunzioni", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceFunzione", "CodiceFunzione"), New System.Data.Common.DataColumnMapping("CodiceRuolo", "CodiceRuolo")})})
        '
        'SqlSelectCommand3
        '
        Me.SqlSelectCommand3.CommandText = "SELECT CodiceFunzione, CodiceRuolo FROM RuoliFunzioni"
        Me.SqlSelectCommand3.Connection = Me.cn

    End Sub

#End Region

    Public Function GetRuoliFunzioni() As DS_Ruoli

        cn.ConnectionString = GetConnectionString()

        Try

            Dim ds As New DS_Ruoli

            cn.Open()

            daRuoli.Fill(ds.Ruoli)
            daFunzioni.Fill(ds.Funzioni)
            daRuoliFunzioni.Fill(ds.RuoliFunzioni)

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try

    End Function

End Class
