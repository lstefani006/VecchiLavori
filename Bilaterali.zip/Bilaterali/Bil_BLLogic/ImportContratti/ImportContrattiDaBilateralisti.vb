Imports System
Imports System.Diagnostics
Imports System.IO
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Xml
Imports System.Xml.Schema
Imports System.Globalization
Imports System.Configuration
Imports CertPInvokeLib
Imports SystemMonitor

Public Class ImportContrattiDaBilateralisti
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents _daXmlFileDaOperatori As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelectXmlFileDaOp As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me._daXmlFileDaOperatori = New System.Data.SqlClient.SqlDataAdapter
        Me.cmdSelectXmlFileDaOp = New System.Data.SqlClient.SqlCommand
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_user;data source=BILSVR1;persis" & _
        "t security info=False;initial catalog=Bilaterali_ROMA5"
        '
        '_daXmlFileDaOperatori
        '
        Me._daXmlFileDaOperatori.SelectCommand = Me.cmdSelectXmlFileDaOp
        Me._daXmlFileDaOperatori.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "XmlFileDaOperatori", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("IdFileXml", "IdFileXml"), New System.Data.Common.DataColumnMapping("FileFirmato", "FileFirmato"), New System.Data.Common.DataColumnMapping("TSInvio", "TSInvio"), New System.Data.Common.DataColumnMapping("Zippato", "Zippato"), New System.Data.Common.DataColumnMapping("NomeFileUtente", "NomeFileUtente"), New System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("IdFileFA", "IdFileFA"), New System.Data.Common.DataColumnMapping("Issuer", "Issuer"), New System.Data.Common.DataColumnMapping("SerialNumber", "SerialNumber")})})
        '
        'cmdSelectXmlFileDaOp
        '
        Me.cmdSelectXmlFileDaOp.CommandText = "SELECT IdFileXml, CodiceTipoFile, FileFirmato, TSInvio, Zippato, NomeFileUtente, " & _
        "CodiceUtenteSDC, CodiceOperatoreSDC, IdFileFA, Issuer, SerialNumber FROM dbo.Xml" & _
        "FileDaOperatori"
        Me.cmdSelectXmlFileDaOp.Connection = Me._cn

    End Sub

#End Region

	Class Contratti
		Public Sub New()
			idElaborazione = Guid.NewGuid
		End Sub

		Public ReadOnly idElaborazione As Guid

		Public Property Errore() As String
			Get
				Return _Errore
			End Get
			Set(ByVal Value As String)
				_Errore = Value
				SmLog.smError(String.Format("Definizione contratti da bilateralista - idElaborazione={0} : {1}", idElaborazione, Value))
			End Set
		End Property
		Private _Errore As String


		Public IdFile As String
		Public CodiceOperatoreSender As String
		Public Contratto As ArrayList = New ArrayList

		'
		' eventuale certificato utilizzato per la firma:
		' messo qui per poterlo passare dalla fase sincrona alla fase asincrona
		'
		Public bInputFirmatoXML As Boolean
		Public bControfirmaXML As Boolean
		Public certificatoFirma As CertX509Ex

	End Class
	Class Contratto

		Public Sub New(ByVal cnti As Contratti, ByVal gestioneTaglioDefault As String)
			_Contratti = cnti
		End Sub

		Private ReadOnly _Contratti As Contratti

		Public CRN As String
		Public CodiceMnemonico As String
		Public CodiceOperatoreTitolare As String
		Public CodiceOperatoreCedente As String
		Public CodiceOperatoreAcquirente As String
		Public DataStipula As DateTime
		Public DataInizioValidita As DateTime
		Public DataFineValidita As DateTime
		Public GestioneTaglio As String = gestioneTaglioDefault
		Public Progressivo As Integer
		Public ProgressivoLetto As Boolean = False


		Public Property Errore() As String
			Get
				Return _Errore
			End Get
			Set(ByVal Value As String)
				_Errore = Value
				If ProgressivoLetto Then
					SmLog.smError(String.Format("Definizione contratti da bilateralista - idElaborazione={0} - Progressivo={1}: {2}", _Contratti.idElaborazione, Progressivo, Value))
				Else
					SmLog.smError(String.Format("Definizione contratti da bilateralista - idElaborazione={0} : {1}", _Contratti.idElaborazione, Value))
				End If
			End Set
		End Property
		Private _Errore As String

	End Class
	Private Sub UpdateFaFile(ByVal cn As SqlClient.SqlConnection, ByVal tr As SqlClient.SqlTransaction, ByVal IdFileXml As Integer, ByVal IdFileFa As String)
		Try
			Dim cmd As String
			cmd = "UPDATE XmlFileDaOperatori "
			cmd += "SET IdFileFA = @IdFileFA "
			cmd += "WHERE IdFileXml = @IdFileXml"

			Dim cmdUpdate As New SqlClient.SqlCommand(cmd.ToString, cn)
			If Not (tr Is Nothing) Then
				cmdUpdate.Transaction = tr
			End If

			'cmdUpdate.Parameters.Add("@IdFileFA", IdFileFa)
			'cmdUpdate.Parameters.Add("@IdFileXml", IdFileXml)

			cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFileXml", System.Data.SqlDbType.Int, 4))
			cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFileFA", System.Data.SqlDbType.VarChar, 32))
			cmdUpdate.Parameters("@IdFileXml").Value = IdFileXml
			cmdUpdate.Parameters("@IdFileFA").Value = IdFileFa

			cmdUpdate.ExecuteNonQuery()

		Catch ex As Exception
			SmLog.smError(ex, "Errore su insert in XmlFileDaOperatori.")
			Throw
		End Try
	End Sub
	Public Function SelectXmlFileOperatori(ByVal outRows As Integer, ByVal dataInizio As DateTime, ByVal dataFine As DateTime, ByVal CodiceOperatoreSDC As String, ByVal CodiceTipoFile As String) As Bil.DS_XmlFileDaOperatori

		Try
			_cn.ConnectionString = GetConnectionString()
			_cn.Open()

			Dim cmd As New SqlCommand
			cmd.Connection = _cn
			cmd.CommandText = "SET ROWCOUNT " + outRows.ToString
			cmd.ExecuteNonQuery()

			Dim ds As New DS_XmlFileDaOperatori

			_daXmlFileDaOperatori.SelectCommand.CommandText += " WHERE  (TSInvio >= COALESCE (@DataInizio, TSInvio)) AND (TSInvio<= COALESCE (@DataFine, TSInvio)) "
			_daXmlFileDaOperatori.SelectCommand.CommandText += " AND  (CodiceOperatoreSDC = COALESCE (@CodiceOperatoreSDC, CodiceOperatoreSDC)) "
			_daXmlFileDaOperatori.SelectCommand.CommandText += " AND  (CodiceTipoFile = COALESCE (@CodiceTipoFile, CodiceTipoFile)) "

			_daXmlFileDaOperatori.SelectCommand.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizio", System.Data.SqlDbType.DateTime, 4))
			_daXmlFileDaOperatori.SelectCommand.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFine", System.Data.SqlDbType.DateTime, 4))
			_daXmlFileDaOperatori.SelectCommand.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16))
			_daXmlFileDaOperatori.SelectCommand.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceTipoFile", System.Data.SqlDbType.VarChar, 16))

			If dataInizio = DateTime.MinValue Then _daXmlFileDaOperatori.SelectCommand.Parameters("@DataInizio").Value = DBNull.Value Else _daXmlFileDaOperatori.SelectCommand.Parameters("@DataInizio").Value = dataInizio
			If dataFine = DateTime.MaxValue Then _daXmlFileDaOperatori.SelectCommand.Parameters("@DataFine").Value = DBNull.Value Else _daXmlFileDaOperatori.SelectCommand.Parameters("@DataFine").Value = dataFine
			If CodiceOperatoreSDC = String.Empty Then _daXmlFileDaOperatori.SelectCommand.Parameters("@CodiceOperatoreSDC").Value = DBNull.Value Else _daXmlFileDaOperatori.SelectCommand.Parameters("@CodiceOperatoreSDC").Value = CodiceOperatoreSDC
			If CodiceTipoFile = String.Empty Then _daXmlFileDaOperatori.SelectCommand.Parameters("@CodiceTipoFile").Value = DBNull.Value Else _daXmlFileDaOperatori.SelectCommand.Parameters("@CodiceTipoFile").Value = CodiceTipoFile

			_daXmlFileDaOperatori.Fill(ds.XmlFileDaOperatori)

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function

	Function GetBlobFile(ByVal IdFileXml As String, ByRef zipped As Boolean, ByRef fileEncoding As String) As Byte()
		Try
			_cn.ConnectionString = GetConnectionString()
			_cn.Open()


			Dim cmd As String
			cmd = "SELECT Zippato, NULL AS Encoding, FileFirmato "
			cmd += "FROM XmlFileDaOperatori "
			cmd += "WHERE IdFileXml = @IdFileXml"

			Dim _cmdExtractFile As New SqlClient.SqlCommand(cmd.ToString, _cn)
			_cmdExtractFile.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFileXml", System.Data.SqlDbType.Int, 4))
			_cmdExtractFile.Parameters("@IdFileXml").Value = IdFileXml

			zipped = True

			Dim rd As SqlDataReader
			Try
				rd = _cmdExtractFile.ExecuteReader(CommandBehavior.SequentialAccess)
				Dim blobSize As Long
				Dim bufferSize As Integer = 100

				While rd.Read()
					zipped = rd.GetBoolean(0)
					If rd.IsDBNull(1) Then fileEncoding = "UTF-8" Else fileEncoding = rd.GetString(1)
					blobSize = rd.GetBytes(2, 0, Nothing, 0, 100)
					If (blobSize > 0) Then
						Dim abyFA(CInt(blobSize) - 1) As Byte
						Dim ret As Long
						ret = rd.GetBytes(2, 0, abyFA, 0, CInt(blobSize))
						Return abyFA
					End If
				End While
			Finally
				If Not rd Is Nothing Then rd.Close() : rd = Nothing
			End Try

			Return Nothing
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function


	Private Shared Function InserisciRigaInXmlFileDaOperatori(ByVal cn As SqlClient.SqlConnection, ByVal codiceUtenteSDC As String, ByVal codiceOperatoreSDC As String, ByVal pathFileXml As String, ByVal fileXml As Byte(), ByVal dateTimeInvio As DateTime, ByVal ce As CertX509Ex) As Integer

		Try
			Dim cmd As String
			cmd = "INSERT INTO XmlFileDaOperatori "
			cmd += "(FileFirmato, TSInvio, Zippato, NomeFileUtente, CodiceUtenteSDC, PathFileFirmato, CodiceOperatoreSDC, TSModifica, Issuer, SerialNumber) "
			cmd += " VALUES "
			cmd += "(@FileFirmato, @TSInvio, @Zippato, @NomeFileUtente, @CodiceUtenteSDC, @PathFileFirmato, @CodiceOperatoreSDC, @TSModifica, @Issuer, @SerialNumber);"
			cmd += "SELECT IdFileXml from XmlFileDaOperatori WHERE IdFileXml=@@IDENTITY"

			Dim nomeFile As String = Path.GetFileName(pathFileXml)
			' Zippo il file xml in input
			Dim abyZippedFile() As Byte = BilZipLib.ZipSingleFile(nomeFile, fileXml, 9)

			Dim cmdInsert As New SqlClient.SqlCommand(cmd.ToString, cn)
			cmdInsert.Parameters.Add("@FileFirmato", abyZippedFile)
			cmdInsert.Parameters.Add("@TSInvio", dateTimeInvio)
			cmdInsert.Parameters.Add("@Zippato", True)
			cmdInsert.Parameters.Add("@NomeFileUtente", nomeFile)
			cmdInsert.Parameters.Add("@CodiceUtenteSDC", codiceUtenteSDC)
			cmdInsert.Parameters.Add("@PathFileFirmato", pathFileXml)
			cmdInsert.Parameters.Add("@CodiceOperatoreSDC", codiceOperatoreSDC)
			cmdInsert.Parameters.Add("@TSModifica", DateTime.Now)

			If (Not ce Is Nothing) Then
				cmdInsert.Parameters.Add("@Issuer", ce.GetIssuerName())
				cmdInsert.Parameters.Add("@SerialNumber", ce.GetSerialNumberString())
			Else
				cmdInsert.Parameters.Add("@Issuer", DBNull.Value)
				cmdInsert.Parameters.Add("@SerialNumber", DBNull.Value)
			End If

			Dim rd As SqlClient.SqlDataReader
			Try
				rd = cmdInsert.ExecuteReader()
				If (rd.Read()) Then
					Dim IdFileXml As Integer = rd.GetInt32(0)
					Return IdFileXml
				Else
					SmLog.smError("Impossibile inserire il contratto in XmlFileDaOperatori")
					Throw New Exception("Impossibile inserire il contratto in XmlFileDaOperatori")
				End If
			Finally
				If (Not rd Is Nothing) Then rd.Close()
			End Try

		Catch ex As Exception
			SmLog.smError(ex, "Errore su insert in XmlFileDaOperatori.")
			Throw
		End Try
	End Function

	'Public Function GetBlobFile(ByVal idFile As Integer, ByRef zipped As Boolean, ByRef fileEncoding As String) As Byte()
	'	Try
	'		_cn.ConnectionString = GetConnectionString()
	'		_cn.Open()

	'		Dim c As StringBuilder = New StringBuilder
	'		c.Append("SELECT Zippato, NULL AS Encoding, FileFirmato WHERE IdFile = @IdFile ")
	'		Dim _cmdExtractFile As New SqlClient.SqlCommand(c.ToString, _cn)
	'		zipped = True

	'		Dim p0 As New SqlParameter("@IdFile", SqlDbType.Int)
	'		p0.Value = idFile
	'		_cmdExtractFile.Parameters.Add(p0)

	'		Dim rd As SqlDataReader
	'		Try
	'			rd = _cmdExtractFile.ExecuteReader(CommandBehavior.SequentialAccess)
	'			Dim blobSize As Long
	'			Dim bufferSize As Integer = 100

	'			While rd.Read()
	'				zipped = rd.GetBoolean(0)
	'				If rd.IsDBNull(1) Then fileEncoding = "UTF-8" Else fileEncoding = rd.GetString(1)
	'				blobSize = rd.GetBytes(2, 0, Nothing, 0, 100)
	'				If (blobSize > 0) Then
	'					Dim abyFA(CInt(blobSize) - 1) As Byte
	'					Dim ret As Long
	'					ret = rd.GetBytes(2, 0, abyFA, 0, CInt(blobSize))
	'					Return abyFA
	'				End If
	'			End While
	'		Finally
	'			If Not rd Is Nothing Then rd.Close() : rd = Nothing
	'		End Try

	'		Return Nothing
	'	Catch ex As Exception
	'		smError(ex)
	'		Throw
	'	Finally
	'		If _cn.State = ConnectionState.Open Then _cn.Close()
	'	End Try
	'End Function

	Public Function RichiediContrattiFirmati() As Boolean
		Dim Input_Firmato As String = ConfigurationSettings.AppSettings("RichiediContrattiFirmati")
		Dim bInputFirmato As Boolean = False

		If (Not Input_Firmato Is Nothing) Then
			Input_Firmato = Input_Firmato.ToLower()
			If (Input_Firmato = "1" OrElse Input_Firmato = "si" OrElse Input_Firmato = "yes" OrElse Input_Firmato = "true") Then
				bInputFirmato = True
			End If
		End If

		Return bInputFirmato
	End Function

	'
	' Verifica ingresso PKCS7 (verifica solo hash per ora
	'
	Private Function VerificaInputPKCS7(ByVal xmlByteArray() As Byte, ByRef errorMsg As String) As Boolean
		Dim result As Boolean = True
		errorMsg = ""

		'Dim cVerify As CryptVerify = Nothing
		'Dim cCert As CertX509Ex = Nothing

		Try
			result = CryptVerify.Verify(xmlByteArray)
			If result = False Then
				errorMsg = "Verifica della firma PKCS7 fallita"
			End If
		Catch cEx As CertException
			SmLog.smError(cEx, "VerificaInputPKCS7")
			errorMsg = "Verifica HASH firma errato: Win32Msg = " + cEx.Win32Msg
			result = False
		Catch ex As Exception
			SmLog.smError(ex, "VerificaInputPKCS7")
			errorMsg = "Errore generico su Verifica HASH firma errato"
			result = False
		Finally
			' If Not cVerify Is Nothing Then
			'     cVerify.Dispose()
			' End If
			' If Not cCert Is Nothing Then
			'     cCert.Dispose()
			' End If
		End Try
		Return result
	End Function

	'
	' Estrae da Input PKCS7 il dato originario
	'
	Private Function EstraiDaInputPKCS7(ByVal xmlByteArray() As Byte, ByRef cert As CertX509Ex) As Byte()
		Dim xmlExtract As Byte() = Nothing
		Dim cVerify As CryptVerify = Nothing
		cert = Nothing
		Try
			cVerify = New CryptVerify(xmlByteArray, False)
			xmlExtract = cVerify.GetData()
			cert = cVerify.GetCertificate()
		Catch cEx As CertException
			' If Not (cVerify Is Nothing) Then
			'   cVerify.Dispose()
			' End If
			SmLog.smError(cEx, "EstraiDaInputPKCS7")
		Catch ex As Exception
			' If Not (cVerify Is Nothing) Then
			'     cVerify.Dispose()
			' End If
			SmLog.smError(ex, "EstraiDaInputPKCS7")
		End Try
		Return xmlExtract
	End Function

	'
	' Esegue controfirma PKCS7
	'
	Private Function ControFirma(ByVal xmlByteArray() As Byte) As Byte()
		Dim xmlControFirmato() As Byte = Nothing

		Dim cs As CertStore = New CertStore
		Dim x As CertX509Ex = Nothing

		Dim CN_Firma As String = ConfigurationSettings.AppSettings("CN_CertificatoControFirma")
		Dim PIN_Firma As String = ConfigurationSettings.AppSettings("PIN_CertificatoControFirma")

		Try
			cs.OpenUserStore()
			x = cs.CertFindCertificateInStore(CN_Firma)
			x.SetPin(PIN_Firma, Nothing, False)
			xmlControFirmato = x.SignWithTimeStamp(xmlByteArray)
		Catch cErr As CertException
			SmLog.smError(cErr, "ControFirma")
		Catch err As Exception
			SmLog.smError(err, "ControFirma")
		Finally
			If Not (x Is Nothing) Then
				' x.Dispose()
			End If
			cs.Close()
		End Try
		Return xmlControFirmato
	End Function

	Public Sub Import(ByVal CodiceOperatoreSDC As String, ByVal CodiceUtenteSDC As String, ByVal nomeFileIn As String, ByVal fileIn() As Byte, ByRef IdFileIn As Integer, ByRef errorsDetected As Boolean, ByRef retMsg As String)

		Dim contratti As New Contratti

		smTrace(String.Format("Definizione Contratto da bilateralisti {0}: inizio elaborazione operatore={1} utente={2}", contratti.idElaborazione, CodiceOperatoreSDC, CodiceUtenteSDC))

		Dim tr As SqlTransaction = Nothing

		'Nuovi parametri per Gestione Emendamenti 168 
		Dim ContrattoDefinibileSoloDa As String
		Dim OperatoreResponsabile As String
		Dim OpzioniGestioneTaglio As String
		Dim OpzioniGestioneTaglioDefault As String
		Try
			Dim cfg As New Bil.Config

			ContrattoDefinibileSoloDa = cfg.ContrattoDefinibileSoloDa()
			OperatoreResponsabile = cfg.OperatoreResponsabile()
			OpzioniGestioneTaglio = cfg.OpzioniGestioneTaglio()
			OpzioniGestioneTaglioDefault = cfg.OpzioniGestioneTaglioDefault()

		Catch ex As Exception
			smError(ex, "Non riesco ad invocare la BL per ottenere le voci di configurazione")
			ContrattoDefinibileSoloDa = "OperatoreCedente"
			OperatoreResponsabile = "OperatoreCedente"
			OpzioniGestioneTaglioDefault = "T"
			OpzioniGestioneTaglio = "TC"
		End Try

		Try

			_cn.ConnectionString = GetConnectionString()
			_cn.Open()

			IdFileIn = CType(DateTime.Now.Ticks Mod (1000 * 1000), Integer)			  ' siamo abbastanza sicuri di non fare collisioni

			Dim xmlControfirma() As Byte = Nothing
			Dim xmlOriginalXML() As Byte = Nothing
			'
			' Se input firmato: verifica firma 
			If RichiediContrattiFirmati() Then

				contratti.bInputFirmatoXML = True
				contratti.bControfirmaXML = False

				Dim XMLOutput_Controfirma_PKCS7 As String = ConfigurationSettings.AppSettings("XMLOutput_Controfirma_PKCS7")
				If (Not XMLOutput_Controfirma_PKCS7 Is Nothing) Then
					XMLOutput_Controfirma_PKCS7 = XMLOutput_Controfirma_PKCS7.ToLower()
					If (XMLOutput_Controfirma_PKCS7 = "1" OrElse XMLOutput_Controfirma_PKCS7 = "si" OrElse XMLOutput_Controfirma_PKCS7 = "yes" OrElse XMLOutput_Controfirma_PKCS7 = "true") Then
						contratti.bControfirmaXML = True
					End If
				End If
				'
				' Lo stream in arrivo e' un bytearray PKCS7 binario
				'
				Dim errMsg As String
				If VerificaInputPKCS7(fileIn, errMsg) = False Then
					contratti.Errore = "Errore: Messaggio = " + errMsg + " durante la fase di verifica della firma. Per rendere operativo il contratto, l'operatore deve ripresentare il contratto firmato PKCS7."
				Else
					xmlOriginalXML = EstraiDaInputPKCS7(fileIn, contratti.certificatoFirma)
					If xmlOriginalXML Is Nothing Then
						contratti.Errore = "Errore durante estrazione dati da PKCS7. Per rendere operativo il contratto, l'operatore deve ripresentare il contratto firmato PKCS7."
					End If
					If contratti.certificatoFirma Is Nothing Then
						contratti.Errore = "Errore durante estrazione certificato firma da PKCS7. Per rendere operativo il contratto, l'operatore deve ripresentare il contratto firmato PKCS7."
					End If
				End If

				' STR 212: verifica che il certificato sia dell'utente che ha sottomesso il file
				If contratti.bInputFirmatoXML Then

					If Not (contratti.certificatoFirma Is Nothing) Then

						'
						' ottengo i dati del certificato utilizzato dal cliente per la firma del programma
						'
						Dim issuer As String = contratti.certificatoFirma.GetIssuerName()
						Dim serialNumber As String = contratti.certificatoFirma.GetSerialNumberString()
						Dim errorString As String
						Dim errorCode As String

						Dim dTarget As DateTime = DateTime.Now

						' controllo se il certficato e` valido.
						' Se il certificato non e` valido segno errore e non continuo l'elaborazione
						Dim certMgr As New Bil_Crypt.CertificateManager
						errorString = certMgr.CheckCertificate(issuer, serialNumber, CodiceUtenteSDC, dTarget, Bil_Crypt.CertificateManager.ControllaScadenzaCertificato.Si)
						If errorString <> String.Empty Then
							errorCode = errorString.Substring(0, 4)
							contratti.Errore = "Errore durante la verifica del certificato (errore=" + errorCode.ToString + ", messaggio=" + errorString + ")"
						End If
					End If

				End If
				' STR 212: fine modifica

				If contratti.bControfirmaXML AndAlso contratti.Errore Is Nothing Then
					xmlControfirma = ControFirma(fileIn)
					If xmlControfirma Is Nothing Then
						contratti.Errore = "Errore durante la controfirma. Verifica configurazione certificati"
						Return						 ' e` un errore di configurazione
					End If
				Else
					xmlControfirma = fileIn
				End If

			Else
				xmlOriginalXML = fileIn
				xmlControfirma = fileIn
			End If

			' si memorizza l'xml in arrivo nel db 
			Dim IdFileXml As Integer
			Dim DataRicezione As DateTime = DateTime.Now
			Try
				IdFileXml = InserisciRigaInXmlFileDaOperatori(_cn, CodiceUtenteSDC, CodiceOperatoreSDC, nomeFileIn, xmlControfirma, DataRicezione, contratti.certificatoFirma)

			Catch ex As Exception
				SmLog.smError(ex)
				' che brutta cosa.... forse e` meglio ritornare subito
				contratti.Errore = "Errore durante la fase di inserimento del file " & nomeFileIn & " che contiene i contratti. Per rendere operativo il contratto, l'operatore deve risottometterlo al sistema in un nuovo file."
			End Try

			tr = _cn.BeginTransaction()

			If Not contratti.Errore Is Nothing Then
				retMsg = contratti.Errore
				errorsDetected = True
			Else
				' gli eventuali errori di  formato XML e di Validazioni sono trappati qui
				' un errore globale va in contratti.Errore
				' un errore di transazione va in contratti.Contratti[xyz].Errore
				Try
					ParseXml(xmlOriginalXML, contratti, OpzioniGestioneTaglio, OpzioniGestioneTaglioDefault)
				Catch ex As Exception
					contratti.Errore = "Errore generale: " + ex.Message
				End Try

				If contratti.Errore Is Nothing AndAlso contratti.CodiceOperatoreSender <> CodiceOperatoreSDC Then
					' chi manda il file non e` il mittente che risulta nel file.
					contratti.Errore = "Errore: il campo ""CodiceOperatore"" non coincide con l'operatore che invia il file"
				End If

				If contratti.Errore Is Nothing Then

					For Each contratto As Contratto In contratti.Contratto
						If contratto.Errore Is Nothing Then
							If ContrattoDefinibileSoloDa = "OperatoreCedente" Then
								If contratto.CodiceOperatoreCedente <> CodiceOperatoreSDC Then
									contratto.Errore = "Errore: il contratto deve essere registrato dall'operatore cedente"
								End If
							ElseIf ContrattoDefinibileSoloDa = "OperatoreAcquirente" Then
								If contratto.CodiceOperatoreAcquirente <> CodiceOperatoreSDC Then
									contratto.Errore = "Errore: il contratto deve essere registrato dall'operatore acquirente"
								End If
							Else
								If contratto.CodiceOperatoreAcquirente <> CodiceOperatoreSDC AndAlso contratto.CodiceOperatoreCedente <> CodiceOperatoreSDC Then
									contratto.Errore = "Errore: il titolare del contratto deve essere o l'operatore cedente o l'operatore acquirente o entrambi"
								End If
							End If
						End If

						' Controllo esistente prima delle modifiche per emendamenti 168
						'If contratto.Errore Is Nothing Then
						'	If contratto.CodiceOperatoreTitolare <> CodiceOperatoreSDC Then
						'		contratto.Errore = "Errore: il titolare del contratto deve coincidere con l'operatore che invia il file"
						'	End If
						'End If

						'If contratto.Errore Is Nothing Then
						'	If contratto.CodiceOperatoreAcquirente <> CodiceOperatoreSDC AndAlso contratto.CodiceOperatoreCedente <> CodiceOperatoreSDC Then
						'		contratto.Errore = "Errore: il titolare del contratto deve essere o l'operatore cedente o l'operatore acquirente o entrambi"
						'	End If
						'End If

						If contratto.Errore Is Nothing Then
							If OperatoreResponsabile = "OperatoreCedente" AndAlso contratto.CodiceOperatoreCedente <> contratto.CodiceOperatoreTitolare Then
								contratto.Errore = "Errore: il titolare del contratto deve essere l'operatore cedente"
							ElseIf OperatoreResponsabile = "OperatoreAcquirente" AndAlso contratto.CodiceOperatoreAcquirente <> contratto.CodiceOperatoreTitolare Then
								contratto.Errore = "Errore: il titolare del contratto deve essere l'operatore acquirente"
							Else
								If contratto.CodiceOperatoreTitolare <> CodiceOperatoreSDC Then
									contratto.Errore = "Errore: il titolare del contratto deve coincidere con l'operatore che invia il file"
								End If
							End If
						End If

						If contratto.Errore Is Nothing Then
							If Not EsisteOperatore(tr, contratto.CodiceOperatoreAcquirente) Then
								contratto.Errore = "Errore: l'operatore acquirente e` sconosciuto"
							End If
						End If

						If contratto.Errore Is Nothing Then
							If Not EsisteOperatore(tr, contratto.CodiceOperatoreCedente) Then
								contratto.Errore = "Errore: l'operatore cedente e` sconosciuto"
							End If
						End If

						If contratto.Errore Is Nothing Then
							If contratto.DataInizioValidita > contratto.DataFineValidita Then
								contratto.Errore = "Errore: la data di inizio validita` deve essere precedente alla data di fine validita` del contratto"
							End If
						End If

						' qui scrivo nel DB
						If contratto.Errore Is Nothing Then
							' qui mi accorgo se esiste o no il contratto: 
							' -1 se non esiste
							' -2 se esiste ma non e` updatabile
							' >= 0 se esiste ed e` updatabile
							Dim CRN As String
							Dim IdContratto As Integer = RicercaContratto(tr, contratto, CRN)
							Debug.Assert(IdContratto = -2 OrElse IdContratto = -1 OrElse IdContratto >= 0)

							If IdContratto >= 0 Then
								contratto.CRN = CRN

							ElseIf IdContratto = -2 Then
								contratto.Errore = "Errore: Non e` possibile aggiornare il contratto in quanto e` stato gia` accettato dalla controparte."
								contratto.CRN = CRN

							Else
								' non esiste il contratto --> creo adesso il CRN
								'contratto.CRN = Bil.NewId30.Generate()
								Dim blc As New Bil.Contratto
								contratto.CRN = blc.GenerateCRN()
							End If

							If contratto.Errore Is Nothing Then
								' qui scrivo nella tabella Contratto.
								WriteContratto(tr, IdContratto, contratto)
							End If

						End If
					Next
				End If
			End If


			smTrace(String.Format("Definizione Contratto da bilateralisti idElaborazione={0} - operatore={1} utente={2}: inizio costruzione FA", contratti.idElaborazione, CodiceOperatoreSDC, CodiceUtenteSDC))


			' Creazione dell'FA
			Dim statoFA As String = Nothing
			If True Then

				Dim nomeFileInNoPath As String = System.IO.Path.GetFileNameWithoutExtension(nomeFileIn)

				Dim nomeFileFA As String = GetFAFileName(nomeFileInNoPath, IdFileIn.ToString)

				Dim ms As MemoryStream = WriteFA(contratti, statoFA)
				Dim IdFileFa As String
				IdFileFa = BilBLBase.MemorizzaFilePerOperatore(_cn, tr, CodiceOperatoreSDC, nomeFileFA, "FACN", "FA contratti", ms.ToArray, DateTime.Now(), "utf-8", DateTime.MaxValue)

				UpdateFaFile(_cn, tr, IdFileXml, IdFileFa)

				smTrace(String.Format("Definizione Contratto da bilateralisti idElaborazione={0} - operatore={1} utente={2}:  FA={3}", contratti.idElaborazione, CodiceOperatoreSDC, CodiceUtenteSDC, IdFileFa))
			End If

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			retMsg = contratti.Errore
			If Not retMsg Is Nothing Then
				errorsDetected = True
			Else
				errorsDetected = False
				retMsg = "L'elaborazione si e` conclusa con esito: " + statoFA
			End If

			smTrace(String.Format("Definizione Contratto da bilateralisti idElaborazione={0} - operatore={1} utente={2}:  elaborazione conclusa", contratti.idElaborazione, CodiceOperatoreSDC, CodiceUtenteSDC))


		Catch ex As Exception
			smError(ex, String.Format("Definizione Contratto da bilateralisti idElaborazione={0} - operatore={1} utente={2}:  errore generale", contratti.idElaborazione, CodiceOperatoreSDC, CodiceUtenteSDC))

			errorsDetected = True
			retMsg = "Errore nell'elaborazione del file: " + ex.Message
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try

	End Sub

	Private Shared Function GetFAFileName(ByVal nomeFileIn As String, ByVal idFile As String) As String
		Dim strFAFileName As New StringBuilder

		strFAFileName.Append("FACN_")
		strFAFileName.Append(nomeFileIn)
		strFAFileName.Append(".")
		strFAFileName.Append(idFile)
		strFAFileName.Append(".out")
		strFAFileName.Append(".xml")

		Return strFAFileName.ToString()
	End Function

	Private Function RicercaContratto(ByVal tr As SqlTransaction, ByVal Contratto As Contratto, ByRef CRN As String) As Integer
		Dim IdContratto As Integer = -1

		Dim cmd As SqlCommand = Nothing
		Dim rd As SqlDataReader = Nothing

		Try
			cmd = New SqlCommand("select IdContratto, StatoContratto, CRN from Contratto where CodiceOperatoreSDC=@Titolare and CodiceContratto=@CodiceContratto")
			cmd.Connection = _cn
			cmd.Transaction = tr
			cmd.Parameters.Add("@Titolare", Contratto.CodiceOperatoreTitolare)
			cmd.Parameters.Add("@CodiceContratto", Contratto.CodiceMnemonico)

			rd = cmd.ExecuteReader()
			If rd.Read Then
				If DirectCast(rd("StatoContratto"), String) <> "DaPerfezionare" Then
					IdContratto = -2
				Else
					IdContratto = CType(rd("IdContratto"), Integer)
				End If
				CRN = DirectCast(rd("CRN"), String)
			End If
		Finally
			If Not rd Is Nothing Then rd.Close()
			If Not cmd Is Nothing Then cmd.Dispose()
		End Try

		Return IdContratto
	End Function

	Private Sub WriteContratto(ByVal tr As SqlTransaction, ByVal IdContratto As Integer, ByVal Contratto As Contratto)

		' -1   significa contratto NON presente
		' >= 0 significa contratto presente da modificare
		' -2   significa contratto presente non modificabile.
		Debug.Assert(IdContratto >= -1)

		If IdContratto >= 0 Then

			Dim s As String = ""
			s += " UPDATE Contratto"
			s += " SET "
			s += " DataStipula = @DataStipula,"
			s += " DataInizioValidita = @DataInizioValidita,"
			s += " DataFineValidita = @DataFineValidita,"
			s += " CodiceOperatoreSDC = @CodiceOperatoreSDC,"
			s += " CodiceOperatoreSDCAcquirente = @CodiceOperatoreSDCAcquirente,"
			s += " CodiceOperatoreSDCCedente = @CodiceOperatoreSDCCedente,"
			s += " GestioneTaglio = @GestioneTaglio"
			s += " WHERE"
			s += " IdContratto=@IdContratto"

			Dim cmd As SqlCommand = New SqlCommand(s)
			cmd.Parameters.Add("@DataStipula", Contratto.DataStipula)
			cmd.Parameters.Add("@DataInizioValidita", Contratto.DataInizioValidita)
			cmd.Parameters.Add("@DataFineValidita", Contratto.DataFineValidita)
			cmd.Parameters.Add("@CodiceOperatoreSDC", Contratto.CodiceOperatoreTitolare)
			cmd.Parameters.Add("@CodiceOperatoreSDCAcquirente", Contratto.CodiceOperatoreAcquirente)
			cmd.Parameters.Add("@CodiceOperatoreSDCCedente", Contratto.CodiceOperatoreCedente)
			cmd.Parameters.Add("@GestioneTaglio", Contratto.GestioneTaglio)
			cmd.Parameters.Add("@IdContratto", IdContratto)

			cmd.Connection = _cn
			cmd.Transaction = tr
			cmd.ExecuteNonQuery()
			cmd.Dispose()

		ElseIf IdContratto = -1 Then
			Dim s As String = ""
			s += " INSERT INTO Contratto"
			s += " ("
			s += " CodiceContratto, "
			s += " DataStipula, "
			s += " DataInizioValidita, "
			s += " DataFineValidita, "
			s += " CRN, "
			s += " StatoContratto, "
			s += " CodiceOperatoreSDC, "
			s += " TSModifica, "
			s += " CodiceOperatoreSDCAcquirente, "
			s += " CodiceOperatoreSDCCedente, "
			s += " ProgrammazionePrivilegiata, "
			s += " GestioneTaglio"
			s += " )"
			s += " VALUES"
			s += " ("
			s += " @CodiceMnemonico, "
			s += " @DataStipula, "
			s += " @DataInizioValidita, "
			s += " @DataFineValidita, "
			s += " @CRN, "

			If Contratto.CodiceOperatoreAcquirente <> Contratto.CodiceOperatoreCedente Then
				s += " 'DaPerfezionare', "
			Else
				s += " 'Abilitato', "
			End If

			s += " @Titolare,"
			s += " getdate(), "
			s += " @CodiceOperatoreSDCAcquirente,"
			s += " @CodiceOperatoreSDCCedente,"
			s += " 0,"
			s += " @GestioneTaglio"
			s += " )"

			Dim cmd As SqlCommand = New SqlCommand(s)
			cmd.Parameters.Add("@CodiceMnemonico", Contratto.CodiceMnemonico)
			cmd.Parameters.Add("@DataStipula", Contratto.DataStipula)
			cmd.Parameters.Add("@DataInizioValidita", Contratto.DataInizioValidita)
			cmd.Parameters.Add("@DataFineValidita", Contratto.DataFineValidita)
			cmd.Parameters.Add("@CRN", Contratto.CRN)
			cmd.Parameters.Add("@Titolare", Contratto.CodiceOperatoreTitolare)
			cmd.Parameters.Add("@CodiceOperatoreSDCAcquirente", Contratto.CodiceOperatoreAcquirente)
			cmd.Parameters.Add("@CodiceOperatoreSDCCedente", Contratto.CodiceOperatoreCedente)
			cmd.Parameters.Add("@GestioneTaglio", Contratto.GestioneTaglio)

			cmd.Connection = _cn
			cmd.Transaction = tr
			cmd.ExecuteNonQuery()
			cmd.Dispose()

		End If

	End Sub

	Private Function EsisteOperatore(ByVal tr As SqlTransaction, ByVal codiceOperatore As String) As Boolean
		Dim s As String = ""
		s += " select count(*)"
		s += " from operatori o"
		s += " inner join sdc_operatori s"
		s += " on s.codiceOperatoreSDC = o.codiceOperatoreSDC"
		s += " and o.StatoBilateraliOperatore=1"
		s += " and s.Abilitato=1"
		s += " where s.codiceOperatoreSdc=@op"

		Dim cmd As SqlCommand
		cmd = New SqlCommand(s)
		cmd.Connection = _cn
		cmd.Transaction = tr
		cmd.Parameters.Add("@op", codiceOperatore)
		Dim r As Integer = CType(cmd.ExecuteScalar(), Int32)
		cmd.Dispose()
		Return r = 1
	End Function

#Region "Parse file XML in ingresso"

	Class ValidationData
		Public contratto As contratto
		Public contratti As contratti
		Sub ValidationEvent(ByVal sender As Object, ByVal e As ValidationEventArgs)
			If Not contratto Is Nothing Then
				If contratto.Errore Is Nothing Then contratto.Errore = "Errore di validazione XML: " + e.Message
			Else
				If contratti.Errore Is Nothing Then contratti.Errore = "Errore di validazione XML: " + e.Message
			End If
		End Sub
	End Class
	Private Sub ParseXml(ByVal fileIn As Byte(), ByRef contratti As Contratti, ByVal OpzioniGestioneTaglio As String, ByVal gestioneTaglioDefault As String)

		Dim xvr As XmlValidatingReader = Nothing
		Dim vd As New ValidationData

		If True Then
			Dim xtr As XmlTextReader = New XmlTextReader(New MemoryStream(fileIn))
			xtr.WhitespaceHandling = WhitespaceHandling.None
			xvr = New XmlValidatingReader(xtr)
			xvr.ValidationType = ValidationType.Schema
			Dim sc As New XmlSchemaCollection

			Dim fileSchema As String = BilBLBase.GetCompleteFileNameFromAppSettings("ImportContrattiDaBilateralisti.xsd")
			sc.Add("urn:xmlns:Bilaterali:ImportContrattiDaBilateralisti", fileSchema)
			xvr.Schemas.Add(sc)
			AddHandler xvr.ValidationEventHandler, AddressOf vd.ValidationEvent
		End If

		vd.contratti = contratti

		xvr.MoveToContent()

		contratti.CodiceOperatoreSender = xvr.GetAttribute("CodiceOperatore")
		contratti.IdFile = xvr.GetAttribute("IdFile")

		xvr.MoveToElement()

		While xvr.Read
			Select Case xvr.NodeType
				Case XmlNodeType.Element
					If xvr.Name = "Contratto" Then
						vd.contratto = New Contratto(contratti, gestioneTaglioDefault)
						contratti.Contratto.Add(vd.contratto)
						ParseContrattoXml(xvr, vd.contratto, OpzioniGestioneTaglio)
						vd.contratto = Nothing
					End If
				Case XmlNodeType.EndElement
					If xvr.Name = "Contratti" Then Exit While
			End Select
		End While

	End Sub

	Private Sub ParseContrattoXml(ByVal xvr As XmlValidatingReader, ByVal contratto As Contratto, ByVal OpzioniGestioneTaglio As String)

		Try
			contratto.Progressivo = XmlConvert.ToInt32(xvr.GetAttribute("Progressivo"))
			contratto.ProgressivoLetto = True
		Catch ex As Exception
			contratto.Errore = "Errore: il campo Progressivo non contiene un valore numerico"
		End Try

		While xvr.Read
			Select Case xvr.NodeType
				Case XmlNodeType.Element
					Dim v As Object = xvr.ReadTypedValue()
					If xvr.Name = "CodiceMnemonico" AndAlso Not v Is Nothing Then
						contratto.CodiceMnemonico = DirectCast(v, String).ToUpper
					ElseIf xvr.Name = "CodiceOperatoreTitolare" AndAlso Not v Is Nothing Then
						contratto.CodiceOperatoreTitolare = DirectCast(v, String).ToUpper()
					ElseIf xvr.Name = "CodiceOperatoreCedente" AndAlso Not v Is Nothing Then
						contratto.CodiceOperatoreCedente = DirectCast(v, String).ToUpper()
					ElseIf xvr.Name = "CodiceOperatoreAcquirente" AndAlso Not v Is Nothing Then
						contratto.CodiceOperatoreAcquirente = DirectCast(v, String).ToUpper()
					ElseIf xvr.Name = "DataStipula" AndAlso Not v Is Nothing Then
						contratto.DataStipula = DirectCast(v, DateTime)
					ElseIf xvr.Name = "DataInizioValidita" AndAlso Not v Is Nothing Then
						contratto.DataInizioValidita = DirectCast(v, DateTime)
					ElseIf xvr.Name = "DataFineValidita" AndAlso Not v Is Nothing Then
						contratto.DataFineValidita = DirectCast(v, DateTime)
					ElseIf xvr.Name = "GestioneTaglio" AndAlso Not v Is Nothing Then
						Dim gt As String = DirectCast(v, String)
						If OpzioniGestioneTaglio.IndexOf(gt) >= 0 Then
							contratto.GestioneTaglio = gt
						Else
							Dim s As String = "Opzione di gestione taglio (" + DirectCast(v, String) + ") non consentita"
							contratto.Errore = s
							smError(s)
						End If
					End If
				Case XmlNodeType.EndElement
					If xvr.Name = "Contratto" Then Return
			End Select
		End While
	End Sub
#End Region

#Region "Scrittura FA"
	Private Function WriteFA(ByVal ccs As Contratti, ByRef stato As String) As MemoryStream

		stato = "Accettato"
		If Not ccs.Errore Is Nothing Then
			stato = "Rifiutato"
		Else
			Dim n As Integer = 0
			For Each cc As Contratto In ccs.Contratto
				If Not cc.Errore Is Nothing Then n += 1
			Next

			If n > 0 AndAlso n = ccs.Contratto.Count Then
				stato = "Rifiutato"

			ElseIf n > 0 AndAlso n < ccs.Contratto.Count Then
				stato = "ParzialmenteAccettato"
			End If
		End If

		Dim idFileFa As String
		Dim ms As New MemoryStream
		Dim w As XmlTextWriter = New XmlTextWriter(ms, Encoding.UTF8)

		w.Formatting = Formatting.Indented
		w.IndentChar = "	"c		  ' e` un tab
		w.Indentation = 1
		w.WriteStartDocument()

		w.WriteStartElement("FAContratti")
		w.WriteAttributeString("xmlns", "xsi", Nothing, "http://www.w3.org/2001/XMLSchema-instance")
		w.WriteAttributeString("xmlns", "urn:xmlns:Bilaterali:ImportContrattiDaBilateralistiFA")
		w.WriteAttributeString("TSElaborazione", XmlConvert.ToString(DateTime.Now))
		If Not ccs.IdFile Is Nothing Then w.WriteAttributeString("RefIdFile", ccs.IdFile)

		w.WriteAttributeString("Stato", stato)

		If Not ccs.Errore Is Nothing Then
			w.WriteElementString("DescrizioneErrore", ccs.Errore)
		Else
			For Each cc As Contratto In ccs.Contratto

				w.WriteStartElement("Contratto")
				If cc.Progressivoletto Then
					w.WriteAttributeString("Progressivo", XmlConvert.ToString(cc.Progressivo))
				End If

				If cc.Errore Is Nothing Then
					w.WriteAttributeString("Stato", "Accettato")
					w.WriteAttributeString("CRN", cc.CRN)
				Else
					w.WriteAttributeString("Stato", "Rifiutato")
					w.WriteElementString("DescrizioneErrore", cc.Errore)
				End If

				w.WriteEndElement()				' Contratto

			Next
		End If
		w.WriteEndElement()		  ' FAContratti

		w.WriteEndDocument()
		w.Flush()
		w.Close()

		Return ms
	End Function
#End Region
End Class
