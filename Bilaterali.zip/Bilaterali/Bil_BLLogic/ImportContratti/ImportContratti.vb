Imports System.Xml
Imports System.IO
Imports System.Globalization
Imports System.Collections
Imports System.Collections.Specialized
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient

Public Class ImportContratti
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        _cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents daContratto As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents daTuttiContratti As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelectAllContracts As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand2 As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me._cn = New System.Data.SqlClient.SqlConnection
		Me.daContratto = New System.Data.SqlClient.SqlDataAdapter
		Me.daTuttiContratti = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSelectAllContracts = New System.Data.SqlClient.SqlCommand
		Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand2 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand2 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand2 = New System.Data.SqlClient.SqlCommand
		'
		'_cn
		'
		Me._cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=True;initial catalog=Bilaterali;password=bilaterali"
		'
		'daContratto
		'
		Me.daContratto.DeleteCommand = Me.SqlDeleteCommand1
		Me.daContratto.InsertCommand = Me.SqlInsertCommand1
		Me.daContratto.SelectCommand = Me.SqlSelectCommand1
		Me.daContratto.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Contratto", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"), New System.Data.Common.DataColumnMapping("CodiceContratto", "CodiceContratto"), New System.Data.Common.DataColumnMapping("DataStipula", "DataStipula"), New System.Data.Common.DataColumnMapping("DataInizioValidita", "DataInizioValidita"), New System.Data.Common.DataColumnMapping("DataFineValidita", "DataFineValidita"), New System.Data.Common.DataColumnMapping("CRN", "CRN"), New System.Data.Common.DataColumnMapping("StatoContratto", "StatoContratto"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDCAcquirente", "CodiceOperatoreSDCAcquirente"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDCCedente", "CodiceOperatoreSDCCedente"), New System.Data.Common.DataColumnMapping("ProgrammazionePrivilegiata", "ProgrammazionePrivilegiata"), New System.Data.Common.DataColumnMapping("GestioneTaglio", "GestioneTaglio")})})
		Me.daContratto.UpdateCommand = Me.SqlUpdateCommand1
		'
		'daTuttiContratti
		'
		Me.daTuttiContratti.DeleteCommand = Me.SqlDeleteCommand2
		Me.daTuttiContratti.InsertCommand = Me.SqlInsertCommand2
		Me.daTuttiContratti.SelectCommand = Me.SqlSelectCommand2
		Me.daTuttiContratti.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Contratto", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"), New System.Data.Common.DataColumnMapping("CodiceContratto", "CodiceContratto"), New System.Data.Common.DataColumnMapping("DataInizioValidita", "DataInizioValidita"), New System.Data.Common.DataColumnMapping("DataFineValidita", "DataFineValidita"), New System.Data.Common.DataColumnMapping("CRN", "CRN"), New System.Data.Common.DataColumnMapping("StatoContratto", "StatoContratto"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDCAcquirente", "CodiceOperatoreSDCAcquirente"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDCCedente", "CodiceOperatoreSDCCedente"), New System.Data.Common.DataColumnMapping("ProgrammazionePrivilegiata", "ProgrammazionePrivilegiata"), New System.Data.Common.DataColumnMapping("TrCN", "TrCN"), New System.Data.Common.DataColumnMapping("DataStipula", "DataStipula"), New System.Data.Common.DataColumnMapping("GestioneTaglio", "GestioneTaglio")})})
		Me.daTuttiContratti.UpdateCommand = Me.SqlUpdateCommand2
		'
		'cmdSelectAllContracts
		'
		Me.cmdSelectAllContracts.CommandText = "SELECT IdContratto, CodiceContratto, DataInizioValidita, DataFineValidita, CRN, S" & _
		"tatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirente, Cod" & _
		"iceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN, DataStipula, GestioneT" & _
		"aglio FROM dbo.Contratto"
		Me.cmdSelectAllContracts.Connection = Me._cn
		'
		'SqlSelectCommand1
		'
		Me.SqlSelectCommand1.CommandText = "SELECT IdContratto, CodiceContratto, DataStipula, DataInizioValidita, DataFineVal" & _
		"idita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAc" & _
		"quirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, GestioneTaglio " & _
		"FROM dbo.Contratto WHERE (CRN = @CRN)"
		Me.SqlSelectCommand1.Connection = Me._cn
		Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"))
		'
		'SqlInsertCommand1
		'
		Me.SqlInsertCommand1.CommandText = "INSERT INTO dbo.Contratto(CodiceContratto, DataStipula, DataInizioValidita, DataF" & _
		"ineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperator" & _
		"eSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, GestioneT" & _
		"aglio) VALUES (@CodiceContratto, @DataStipula, @DataInizioValidita, @DataFineVal" & _
		"idita, @CRN, @StatoContratto, @CodiceOperatoreSDC, @TSModifica, @CodiceOperatore" & _
		"SDCAcquirente, @CodiceOperatoreSDCCedente, @ProgrammazionePrivilegiata, @Gestion" & _
		"eTaglio); SELECT IdContratto, CodiceContratto, DataStipula, DataInizioValidita, " & _
		"DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOpe" & _
		"ratoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, Gest" & _
		"ioneTaglio FROM dbo.Contratto WHERE (IdContratto = @@IDENTITY)"
		Me.SqlInsertCommand1.Connection = Me._cn
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceContratto", System.Data.SqlDbType.VarChar, 50, "CodiceContratto"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataStipula", System.Data.SqlDbType.DateTime, 4, "DataStipula"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoContratto", System.Data.SqlDbType.VarChar, 32, "StatoContratto"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCAcquirente"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCCedente"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, "ProgrammazionePrivilegiata"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"))
		'
		'SqlUpdateCommand1
		'
		Me.SqlUpdateCommand1.CommandText = "UPDATE dbo.Contratto SET CodiceContratto = @CodiceContratto, DataStipula = @DataS" & _
		"tipula, DataInizioValidita = @DataInizioValidita, DataFineValidita = @DataFineVa" & _
		"lidita, CRN = @CRN, StatoContratto = @StatoContratto, CodiceOperatoreSDC = @Codi" & _
		"ceOperatoreSDC, TSModifica = @TSModifica, CodiceOperatoreSDCAcquirente = @Codice" & _
		"OperatoreSDCAcquirente, CodiceOperatoreSDCCedente = @CodiceOperatoreSDCCedente, " & _
		"ProgrammazionePrivilegiata = @ProgrammazionePrivilegiata, GestioneTaglio = @Gest" & _
		"ioneTaglio WHERE (IdContratto = @Original_IdContratto); SELECT IdContratto, Codi" & _
		"ceContratto, DataStipula, DataInizioValidita, DataFineValidita, CRN, StatoContra" & _
		"tto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirente, CodiceOperato" & _
		"reSDCCedente, ProgrammazionePrivilegiata, GestioneTaglio FROM dbo.Contratto WHER" & _
		"E (IdContratto = @IdContratto)"
		Me.SqlUpdateCommand1.Connection = Me._cn
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceContratto", System.Data.SqlDbType.VarChar, 50, "CodiceContratto"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataStipula", System.Data.SqlDbType.DateTime, 4, "DataStipula"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoContratto", System.Data.SqlDbType.VarChar, 32, "StatoContratto"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCAcquirente"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCCedente"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, "ProgrammazionePrivilegiata"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
		'
		'SqlDeleteCommand1
		'
		Me.SqlDeleteCommand1.CommandText = "DELETE FROM dbo.Contratto WHERE (IdContratto = @Original_IdContratto)"
		Me.SqlDeleteCommand1.Connection = Me._cn
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		'
		'SqlSelectCommand2
		'
		Me.SqlSelectCommand2.CommandText = "SELECT IdContratto, CodiceContratto, DataInizioValidita, DataFineValidita, CRN, S" & _
		"tatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirente, Cod" & _
		"iceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN, DataStipula, GestioneT" & _
		"aglio FROM dbo.Contratto"
		Me.SqlSelectCommand2.Connection = Me._cn
		'
		'SqlInsertCommand2
		'
		Me.SqlInsertCommand2.CommandText = "INSERT INTO dbo.Contratto(CodiceContratto, DataInizioValidita, DataFineValidita, " & _
		"CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirent" & _
		"e, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN, DataStipula, Ges" & _
		"tioneTaglio) VALUES (@CodiceContratto, @DataInizioValidita, @DataFineValidita, @" & _
		"CRN, @StatoContratto, @CodiceOperatoreSDC, @TSModifica, @CodiceOperatoreSDCAcqui" & _
		"rente, @CodiceOperatoreSDCCedente, @ProgrammazionePrivilegiata, @TrCN, @DataStip" & _
		"ula, @GestioneTaglio); SELECT IdContratto, CodiceContratto, DataInizioValidita, " & _
		"DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOpe" & _
		"ratoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN" & _
		", DataStipula, GestioneTaglio FROM dbo.Contratto WHERE (IdContratto = @@IDENTITY" & _
		")"
		Me.SqlInsertCommand2.Connection = Me._cn
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceContratto", System.Data.SqlDbType.VarChar, 50, "CodiceContratto"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoContratto", System.Data.SqlDbType.VarChar, 32, "StatoContratto"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCAcquirente"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCCedente"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, "ProgrammazionePrivilegiata"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TrCN", System.Data.SqlDbType.Bit, 1, "TrCN"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataStipula", System.Data.SqlDbType.DateTime, 4, "DataStipula"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"))
		'
		'SqlUpdateCommand2
		'
		Me.SqlUpdateCommand2.CommandText = "UPDATE dbo.Contratto SET CodiceContratto = @CodiceContratto, DataInizioValidita =" & _
		" @DataInizioValidita, DataFineValidita = @DataFineValidita, CRN = @CRN, StatoCon" & _
		"tratto = @StatoContratto, CodiceOperatoreSDC = @CodiceOperatoreSDC, TSModifica =" & _
		" @TSModifica, CodiceOperatoreSDCAcquirente = @CodiceOperatoreSDCAcquirente, Codi" & _
		"ceOperatoreSDCCedente = @CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata =" & _
		" @ProgrammazionePrivilegiata, TrCN = @TrCN, DataStipula = @DataStipula, Gestione" & _
		"Taglio = @GestioneTaglio WHERE (IdContratto = @Original_IdContratto) AND (CRN = " & _
		"@Original_CRN) AND (CodiceContratto = @Original_CodiceContratto) AND (CodiceOper" & _
		"atoreSDC = @Original_CodiceOperatoreSDC) AND (CodiceOperatoreSDCAcquirente = @Or" & _
		"iginal_CodiceOperatoreSDCAcquirente) AND (CodiceOperatoreSDCCedente = @Original_" & _
		"CodiceOperatoreSDCCedente) AND (DataFineValidita = @Original_DataFineValidita) A" & _
		"ND (DataInizioValidita = @Original_DataInizioValidita) AND (DataStipula = @Origi" & _
		"nal_DataStipula) AND (GestioneTaglio = @Original_GestioneTaglio) AND (Programmaz" & _
		"ionePrivilegiata = @Original_ProgrammazionePrivilegiata) AND (StatoContratto = @" & _
		"Original_StatoContratto) AND (TSModifica = @Original_TSModifica) AND (TrCN = @Or" & _
		"iginal_TrCN); SELECT IdContratto, CodiceContratto, DataInizioValidita, DataFineV" & _
		"alidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDC" & _
		"Acquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN, DataSti" & _
		"pula, GestioneTaglio FROM dbo.Contratto WHERE (IdContratto = @IdContratto)"
		Me.SqlUpdateCommand2.Connection = Me._cn
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceContratto", System.Data.SqlDbType.VarChar, 50, "CodiceContratto"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoContratto", System.Data.SqlDbType.VarChar, 32, "StatoContratto"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCAcquirente"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCCedente"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, "ProgrammazionePrivilegiata"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TrCN", System.Data.SqlDbType.Bit, 1, "TrCN"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataStipula", System.Data.SqlDbType.DateTime, 4, "DataStipula"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CRN", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CRN", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceContratto", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDCAcquirente", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDCCedente", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataFineValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataFineValidita", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataInizioValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataInizioValidita", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataStipula", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataStipula", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_GestioneTaglio", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "GestioneTaglio", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProgrammazionePrivilegiata", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StatoContratto", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StatoContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TSModifica", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_TrCN", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TrCN", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
		'
		'SqlDeleteCommand2
		'
		Me.SqlDeleteCommand2.CommandText = "DELETE FROM dbo.Contratto WHERE (IdContratto = @Original_IdContratto) AND (CRN = " & _
		"@Original_CRN) AND (CodiceContratto = @Original_CodiceContratto) AND (CodiceOper" & _
		"atoreSDC = @Original_CodiceOperatoreSDC) AND (CodiceOperatoreSDCAcquirente = @Or" & _
		"iginal_CodiceOperatoreSDCAcquirente) AND (CodiceOperatoreSDCCedente = @Original_" & _
		"CodiceOperatoreSDCCedente) AND (DataFineValidita = @Original_DataFineValidita) A" & _
		"ND (DataInizioValidita = @Original_DataInizioValidita) AND (DataStipula = @Origi" & _
		"nal_DataStipula) AND (GestioneTaglio = @Original_GestioneTaglio) AND (Programmaz" & _
		"ionePrivilegiata = @Original_ProgrammazionePrivilegiata) AND (StatoContratto = @" & _
		"Original_StatoContratto) AND (TSModifica = @Original_TSModifica) AND (TrCN = @Or" & _
		"iginal_TrCN)"
		Me.SqlDeleteCommand2.Connection = Me._cn
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CRN", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CRN", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceContratto", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDCAcquirente", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDCCedente", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataFineValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataFineValidita", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataInizioValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataInizioValidita", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataStipula", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataStipula", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_GestioneTaglio", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "GestioneTaglio", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProgrammazionePrivilegiata", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StatoContratto", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StatoContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TSModifica", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_TrCN", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TrCN", System.Data.DataRowVersion.Original, Nothing))

	End Sub

#End Region

	Class ImportContrattiBatchData
		Public CodiceOperatoreSDC As String
		Public fileNameImportContratti As String
		Public abyFileContent() As Byte
	End Class

    Public Function InserisciContrattiAsync(ByVal blInfoEvt As Bil.FileStore.InfoEvento, ByVal runningOperator As String) As String

        'Dim cd As New ImportContrattiBatchData
        'cd.CodiceOperatoreSDC = blInfoEvt.CodiceOperatoreSDC
        'cd.fileNameImportContratti = blInfoEvt.NomeFile
        'cd.abyFileContent = blInfoEvt.ContenutoFile

        'BatchSerializer.BS.AddBatch(AddressOf ImportContratti.InserisciContrattiAsyncCB, cd, "IMP_CNT", "Import contratti", DateTime.MinValue, runningOperator)
        BatchSerializer.BS.AddBatch(AddressOf ImportContratti.InserisciContrattiAsyncCB, blInfoEvt, blInfoEvt.CodiceTipoFile, blInfoEvt.DescrizioneFile, DateTime.MinValue, runningOperator)

		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Private Shared Sub InserisciContrattiAsyncCB(ByVal o As Object)
        Dim bl As New ImportContratti
        Dim blInfoEvt As Bil.FileStore.InfoEvento = DirectCast(o, Bil.FileStore.InfoEvento)

        bl.Import(blInfoEvt)
    End Sub


    Private Function Import(ByVal blInfoEvt As Bil.FileStore.InfoEvento) As Boolean

        smTrace("Upload contratti: inizio attivita`")

        Dim blConfig As New Bil.Config
        ContractManager.DB_TABLE_CONTRATTO_GESTIONE_TAGLIO_DEFAULT = blConfig.OpzioniGestioneTaglioDefault()

        ' Controlo parametri in ingresso
        Dim fileNameImportContratti As String = blInfoEvt.NomeFile
        If fileNameImportContratti Is Nothing Then fileNameImportContratti = ""
        Dim strErrMsg As String = "Errore contenuto del file """ & _
           fileNameImportContratti & """di import dei contratti uguale a Nothing"
        Debug.Assert(Not fileNameImportContratti Is Nothing, strErrMsg)

        If blInfoEvt.ContenutoFile Is Nothing Then Throw New ArgumentException(strErrMsg)

        Dim abyFileContent() As Byte = blInfoEvt.ContenutoFile
        Dim abyErrorXML() As Byte
        SaveUploadFile("Contratti", abyFileContent)

        Dim blFS As New Bil.FileStore
        Dim TSFile As DateTime
        Dim IdFile As Integer
        Dim byFA() As Byte

        blFS.InsertFile(blInfoEvt, TSFile, IdFile)

        Try
            _cn.Open()

            ' Uso le Transazioni oppure no???? Ho tante operazioni da fare....
            Dim cm As New ContractManager(_cn, fileNameImportContratti, abyFileContent, daContratto)
            Debug.Assert(Not cm Is Nothing, "Errore creazione oggetto ContractManager")
            If (cm Is Nothing) Then Throw New ApplicationException("Errore creazione oggetto ContractManager")

            ' Recupero TUTTI gli Operatori abilitati nel Sistema 
            ' (prendo solo il loro CodiceOperatoreSDC)
            ' cm.OperatoriValidiCollection = GetListaOperatoriValidi()

            ' Parsing file XML import contratti
            Dim ret As Boolean = cm.ParseXML()

            ' Recupero gli Errori (se non ce ne sono restituisco Nothing)
            abyErrorXML = cm.GetErrorsInXML()

#If DEBUG Then
            If Not abyErrorXML Is Nothing Then
                Dim s As String = Encoding.UTF8.GetString(abyErrorXML)
                ' Serve solo per mettere il breakpoint
                Dim i As Integer = 0
            End If
#End If
            If Not abyErrorXML Is Nothing Then

                Dim s As String
                s = Path.GetFileNameWithoutExtension(fileNameImportContratti)
                s = String.Format("FACNT_{0}.out.xml", s)

                BilBLBase.MemorizzaFilePerOperatore(Nothing, Nothing, blInfoEvt.CodiceOperatoreSDC, s, "FACNT", "FACNT import contratti", abyErrorXML, DateTime.Now, "utf-8", DateTime.MaxValue)

                smTrace(String.Format("Upload contratti: terminato con errore: FACNT={0}", s))
                smTrace("Upload contratti: terminato con errori. FACNT generato nell'area di download dell'operatore " + blInfoEvt.CodiceOperatoreSDC)
                BatchSerializer.SetProgressBatch("Upload contratti: terminato con errori. FACNT generato nell'area di download dell'operatore " + blInfoEvt.CodiceOperatoreSDC)
                byFA = (New UnicodeEncoding).GetBytes("Upload contratti: terminato con errori. FACNT generato nell'area di download dell'operatore " + blInfoEvt.CodiceOperatoreSDC)
                blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Else
                smTrace("Upload contratti: terminato con successo. Nessun FACNT generato dato che l'esito e` positivo")
                BatchSerializer.SetProgressBatch("Upload contratti: terminato con successo. Nessun FACNT generato dato che l'esito e` positivo")
                byFA = (New UnicodeEncoding).GetBytes("Upload contratti: terminato con successo. Nessun FACNT generato dato che l'esito e` positivo")
                blFS.UpdateFAFile(TSFile, IdFile, byFA)
            End If

            Return True

        Catch ex As Exception
            smError(ex, "Upload contratti")
            BatchSerializer.SetProgressBatch("Upload contratti: errore durante l'import: " + ex.Message)
            byFA = (New UnicodeEncoding).GetBytes("Upload contratti: errore durante l'import: " + ex.Message)
            blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Throw
        Finally
            If _cn.State = ConnectionState.Open Then _cn.Close()
            smError("Eseguito Import contratti")
        End Try
    End Function

    Public Function Export(ByRef blInfoEvt As Bil.FileStore.InfoEvento) As Boolean
        Dim ret As Boolean = False

        smTrace("Download contratti: inizio attivita'")

        Dim blConfig As New Bil.Config
        ContractManager.DB_TABLE_CONTRATTO_GESTIONE_TAGLIO_DEFAULT = blConfig.OpzioniGestioneTaglioDefault()


        Dim TSFile As DateTime
        Dim IdFile As Integer
        Dim blFS As New Bil.FileStore

        Try
            _cn.Open()

            Dim cm As New ContractManager(_cn, daTuttiContratti)
            Debug.Assert(Not cm Is Nothing, "Errore creazione oggetto ContractManager")
            If (cm Is Nothing) Then Throw New ApplicationException("Errore creazione oggetto ContractManager")

            ' Costruzione Export XML
            ret = cm.ExportXML()
            If ret Then
                blInfoEvt.ContenutoFile = cm.ContenutoFile
                smTrace("Download contratti: prodotto il file Contratti con successo")

                
                blFS.InsertFile(blInfoEvt, TSFile, IdFile)

            End If


        Catch ex As Exception
            smError(ex, "Download contratti")

            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Download contratti " + ex.Message)
            blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Throw
        Finally
            If _cn.State = ConnectionState.Open Then _cn.Close()
            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Download contratti: attivita` conclusa con successo")
            blFS.UpdateFAFile(TSFile, IdFile, byFA)
        End Try


        Return ret
    End Function


    Private Function GetListaOperatoriValidi() As ArrayList
        Try
            Dim bl As New Operatore
            Return bl.GetListaOperatoriAbilitati()
        Catch ex As Exception
            smError(ex)
            Throw
        End Try

    End Function

#Region " Classe per la gestione dell'import dei contratti dal file XML "

    Public Class ContractManager
        ' Costanti utilizzate all'interno della classe
        Const DB_TABLE_CONTRATTO_NAME As String = "Contratto"
        Const DB_TABLE_UNITA_CONTRATTO_NAME As String = "UnitaContratto"
        Public Shared DB_TABLE_CONTRATTO_GESTIONE_TAGLIO_DEFAULT As String

        Enum CONTRACT_TYPE_VERSION
            BILATERALI_VERSION_1_0 = 1
            BILATERALI_VERSION_2_0 = 2
        End Enum

        ' Contenuto del file XML 
        Private contentFile() As Byte
        ' Eventuale Nome file
        Private fileName As String
        ' Connessione al DataBase
        Private dbConn As SqlClient.SqlConnection
        ' Gestione degli ERRORI sia di parsing dei Dati sia dell'import sul Database
        Private iemErrors As ImportErrorManager
        ' Lista Operatori che possono introdurre un contratto (sono cioe' abilitati 
        ' nel mercato dei Bilaterali)
        Private alOperatoriValidi As ArrayList

        Private daContratto As SqlDataAdapter
        'Private daUnitaContratto As SqlDataAdapter

        '
        ' Da usare per import
        '
        '		Public Sub New(ByVal Connection As SqlClient.SqlConnection, ByVal xmlImportFileName As String, ByVal abyContentFile() As Byte, ByVal daContratto As SqlDataAdapter, ByVal daUnitaContratto As SqlDataAdapter)
        Public Sub New(ByVal Connection As SqlClient.SqlConnection, ByVal xmlImportFileName As String, ByVal abyContentFile() As Byte, ByVal daContratto As SqlDataAdapter)
            Me.dbConn = Connection
            Me.contentFile = abyContentFile
            Me.fileName = xmlImportFileName
            Me.iemErrors = New ImportErrorManager
            Me.daContratto = daContratto
            'Me.daUnitaContratto = daUnitaContratto
        End Sub


        '
        ' da usare per Export
        '
        '		Public Sub New(ByVal Connection As SqlClient.SqlConnection, ByVal daContratto As SqlDataAdapter, ByVal daUnitaContratto As SqlDataAdapter)
        Public Sub New(ByVal Connection As SqlClient.SqlConnection, ByVal daContratto As SqlDataAdapter)
            Me.dbConn = Connection
            Me.daContratto = daContratto
            'Me.daUnitaContratto = daUnitaContratto
        End Sub

        '=========================== PROPRIETA' =================================
        Public Property ContenutoFile() As Byte()
            Get
                Return Me.contentFile
            End Get
            Set(ByVal Value As Byte())
                Me.contentFile = Value
            End Set
        End Property

        Public Property NomeFile() As String
            Get
                Return Me.fileName
            End Get
            Set(ByVal Value As String)
                Me.fileName = Value
            End Set
        End Property

        Public Property Connection() As SqlClient.SqlConnection
            Get
                Return Me.dbConn
            End Get
            Set(ByVal Value As SqlClient.SqlConnection)
                Me.dbConn = Value
            End Set
        End Property

        'Public WriteOnly Property OperatoriValidiCollection() As ArrayList
        '	Set(ByVal Value As ArrayList)
        '		Me.alOperatoriValidi = Value
        '	End Set
        'End Property
        '========================== FUNZIONI PRIVATE ==============================
        Private Sub CheckDBConn()
            Debug.Assert(Not Me.dbConn Is Nothing, "Errore oggetto Connection uguale a nothing")
            If Me.dbConn Is Nothing Then Throw New ApplicationException("Errore oggetto Connection uguale a nothing")

            If (Me.dbConn.State = ConnectionState.Closed) Then
                Throw New ApplicationException("Errore connessione al DataBase Closed")
            End If
        End Sub


        Private Sub SaveToDB(ByVal contractInfo As ContractData)
            ' Un po' di controlli
            CheckDBConn()

            Debug.Assert(Not contractInfo Is Nothing, "Errore oggetto contractInfo uguale a Nothing")
            If contractInfo Is Nothing Then Throw New ArgumentException("Errore oggetto contractInfo uguale a Nothing")
            ' Per adesso non uso le Transazioni
            Dim tr As SqlTransaction = Nothing
            'Dim tr As SqlTransaction = Me.dbConn.BeginTransaction()

            Bil.BilBLBase.SetTransaction(daContratto, tr)
            'Bil.BilBLBase.SetTransaction(daUnitaContratto, tr)

            If contractInfo.GestioneTaglio Is Nothing OrElse contractInfo.GestioneTaglio = String.Empty Then
                contractInfo.GestioneTaglio = DB_TABLE_CONTRATTO_GESTIONE_TAGLIO_DEFAULT
            End If

            Try
                ' creo il DS
                Dim dsContrattoUnita As New DS_ImportContratti

                ' lo riempo con i dati del contratto, se ci sono.
                daContratto.SelectCommand.Parameters("@CRN").Value = contractInfo.TransactionreferenceNumber
                daContratto.Fill(dsContrattoUnita.Contratto)

                ' se c'e` il contratto prendo anche le sue unita`
                'If (dsContrattoUnita.Contratto.Rows.Count > 0) Then
                '   contractInfo.DB_IdContratto = dsContrattoUnita.Contratto(0).IdContratto
                '   daUnitaContratto.SelectCommand.Parameters("@IdContratto").Value = contractInfo.DB_IdContratto
                '   daUnitaContratto.Fill(dsContrattoUnita.UnitaContratto)
                'End If

                Dim drContratto As DS_ImportContratti.ContrattoRow

                If (dsContrattoUnita.Contratto.Rows.Count = 0) Then
                    ' non c'e` il contratto --> lo creo
                    drContratto = dsContrattoUnita.Contratto.AddContrattoRow( _
                     contractInfo.MPCrossReferenceNumber, _
                      contractInfo.ContractDate, _
                      contractInfo.StartDate, _
                      contractInfo.EndDate, _
                      contractInfo.TransactionreferenceNumber, _
                      contractInfo.StatusCode, _
                      contractInfo.MPN, _
                      DateTime.Now, _
                      contractInfo.MPNAcq, _
                      contractInfo.MPNCed, _
                      contractInfo.ProgrammazionePrivilegiata, _
                      contractInfo.GestioneTaglio)
                Else
                    ' c'e` il contratto --> lo modifico
                    drContratto = dsContrattoUnita.Contratto(0)

                    drContratto.CodiceContratto = contractInfo.MPCrossReferenceNumber
                    drContratto.DataStipula = contractInfo.ContractDate
                    drContratto.DataInizioValidita = contractInfo.StartDate
                    drContratto.DataFineValidita = contractInfo.EndDate
                    drContratto.CRN = contractInfo.TransactionreferenceNumber
                    drContratto.StatoContratto = contractInfo.StatusCode
                    drContratto.CodiceOperatoreSDC = contractInfo.MPN
                    drContratto.TSModifica = DateTime.Now()
                    drContratto.CodiceOperatoreSDCAcquirente = contractInfo.MPNAcq
                    drContratto.CodiceOperatoreSDCCedente = contractInfo.MPNCed
                    drContratto.ProgrammazionePrivilegiata = contractInfo.ProgrammazionePrivilegiata
                    drContratto.GestioneTaglio = contractInfo.GestioneTaglio

                End If

                Try
                    ' notare che se l'insert/l'update ha successo dsContrattoUnita.Contratto.IdContratto e` valorizzata correttamente
                    daContratto.InsertCommand.CommandTimeout = AppSettingToInt32("ImportContrattiQueryTmo", 120)
                    daContratto.UpdateCommand.CommandTimeout = AppSettingToInt32("ImportContrattiQueryTmo", 120)

                    daContratto.Update(dsContrattoUnita.Contratto)

                    ' qui si legge l'IdContratto ritornato dal DB (nel caso di INSERT qui ho il vero IdContratto assegnato dal DB)
                    contractInfo.DB_IdContratto = drContratto.IdContratto

                Catch sqlEx As SqlException
                    ' Errore L'operatore non e' presente nella tabella Operatori, violato il Constraint
                    If (sqlEx.Number = 547 AndAlso sqlEx.Message.IndexOf("Operatori") >= 0) Then
                        ' Errore Operatore non presente nella tabella Operatori
                        Dim strErr As String = "Errore Operatore """ & contractInfo.MPN & _
                          """ e/o """ & contractInfo.MPNAcq & _
                          """ e/o """ & contractInfo.MPNCed & """ non presente/i nella tabella Operatori"
                        SystemMonitor.SmLog.smError(sqlex, strErr)
                        Me.iemErrors.AddErrorToContract(contractInfo.IdContrattoXML, New RejectInfo(strErr, 0))
                    Else
                        SystemMonitor.SmLog.smError(sqlex, "Errore generico sql numero " & sqlEx.Number.ToString())
                        Me.iemErrors.AddErrorToContract(contractInfo.IdContrattoXML, New RejectInfo("Errore generico sql numero " + sqlEx.Number.ToString() + ": " + sqlEx.Message, 0))
                    End If
                    ' Errore sul contratto => esco dalla funzione 
                    ' (provo il prossimo contratto)
                    Return
                Catch ex As Exception
                    SystemMonitor.SmLog.smError(ex, "Errore inserendo nel DB il contratto """ & contractInfo.IdContrattoXML & """")
                    Throw
                End Try

                ' il contratto e` dentro il DB (modificato o inserito)



            Catch sqlEx As SqlException
                ' Errore sul DataBase...l'eccezione sul DB non dovrebbe mai
                ' arrivare a questo punto in quanto trappate all'interno delle funzioni di Insert
                ' ed Update..... 
                SystemMonitor.SmLog.smError(sqlEx)
                If Not (tr Is Nothing) Then tr.Rollback()
                Throw
            Catch ex As Exception
                SystemMonitor.SmLog.smError(ex)
                If Not (tr Is Nothing) Then tr.Rollback()
                Throw
            End Try

            If (Not tr Is Nothing) Then tr.Commit()
        End Sub


        '====================================== FINE FUNZIONI DI ACCESSO AL DATABASE ================================
        Private Function MoveToNode(ByVal xtr As XmlTextReader, ByVal objElement As Object) As Boolean
            Debug.Assert(Not xtr Is Nothing, "Errore oggetto XmlTextReader uguale a Nothing")
            If (xtr Is Nothing) Then Throw New ArgumentNullException("Errore oggetto XmlTextReader uguale a Nothing")

            If xtr.ReadState = ReadState.Interactive Then
                While (xtr.Read())
                    Dim xrn As Object = xtr.Name
                    Select Case xtr.NodeType
                        Case XmlNodeType.EndElement
                            If xrn Is objElement Then
                                Return True
                            End If
                    End Select
                End While
            Else
                Return False
            End If
        End Function

        Private Sub ManageUnitErrors(ByVal ud As UnitData)
            Debug.Assert(Not ud Is Nothing, "Errore oggetto UnitData uguale a Nothing")
            If (ud Is Nothing) Then Throw New ApplicationException("Errore oggetto UnitData uguale a Nothing")

            Select Case ud.GetLastFieldError()
                Case UnitData.UnitDataError.CategoriaUnitaError
                    SystemMonitor.SmLog.smError("Errore campo ""CategoriaUnitaSDC"" assente per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore campo ""CategoriaUnita"" assente", 0))

                Case UnitData.UnitDataError.CodiceUnitaSDCError
                    SystemMonitor.SmLog.smError("Errore Tag ""UnitInformation"" assente o vuoto per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore Tag ""UnitInformation"" assente o vuoto", 0))

                Case UnitData.UnitDataError.DataFineValiditaError
                    SystemMonitor.SmLog.smError("Errore campo ""DataFineValidita"" assente per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore Tag ""DataFineValidita"" assente", 0))

                Case UnitData.UnitDataError.DataInizioValiditaError
                    SystemMonitor.SmLog.smError("Errore campo ""DataInizioValidita"" assente per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore Tag ""DataInizioValidita"" assente", 0))

                Case UnitData.UnitDataError.PrioritaBilanciamentoForzatoError
                    SystemMonitor.SmLog.smError("Errore campo ""PrioritaBilanciamentoForzato"" assente per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore campo ""PrioritaBilanciamentoForzato"" assente", 0))

                Case UnitData.UnitDataError.TipoUnitaError
                    SystemMonitor.SmLog.smError("Errore Attributo ""TypeCode"" assente o vuoto per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore Attributo ""TypeCode"" assente o vuoto", 0))

                Case UnitData.UnitDataError.TipoUnitaValueError
                    SystemMonitor.SmLog.smError("Errore Attributo ""TypeCode"" contiene un valore non ammesso per l'Unit� """ & ud.CodiceUnita & """ per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore Attributo ""TypeCode"" contiene un valore non ammesso per l'Unit� """ & ud.CodiceUnita & """", 0))

                Case UnitData.UnitDataError.AssignedError
                    SystemMonitor.SmLog.smError("Errore Attributo ""Assigned"" assente per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore Attributo ""Assigned"" assente o vuoto", 0))

                Case UnitData.UnitDataError.AssignedValueError
                    SystemMonitor.SmLog.smError("Errore Attributo ""Assigned"" contiene un valore non ammesso per l'Unit� """ & ud.CodiceUnita & """ per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore Attributo ""Assigned"" contiene un valore non ammesso per l'Unit� """ & ud.CodiceUnita & """", 0))

                Case UnitData.UnitDataError.UnitaAssegnataOpAcquirenteError
                    SystemMonitor.SmLog.smError("Errore campo ""UnitaAssegnataOpAcquirente"" assente per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore campo ""UnitaAssegnataOpAcquirente"" assente", 0))

                Case UnitData.UnitDataError.UnitaAssegnataOpCedenteError
                    SystemMonitor.SmLog.smError("Errore campo ""UnitaAssegnataOpCedente"" assente per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore campo ""UnitaAssegnataOpCedente"" assente", 0))

                Case UnitData.UnitDataError.UnitaContrattoValidataError
                    SystemMonitor.SmLog.smError("Errore campo ""UnitaContrattoValidata"" assente per il contratto """ & ud.IdContrattoXMLParent & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(ud.IdContrattoXMLParent, New RejectInfo("Errore campo ""UnitaContrattoValidata"" assente", 0))

                Case UnitData.UnitDataError.NoError
                    Throw New ApplicationException("Errore interno: oggetto unita' non valido ma non restituisce errore")
            End Select
        End Sub

        Private Sub ManageContractErrors(ByVal cd As ContractData)
            Debug.Assert(Not cd Is Nothing, "Errore oggetto ContractData uguale a Nothing")
            If (cd Is Nothing) Then Throw New ApplicationException("Errore oggetto ContractData uguale a Nothing")

            Select Case cd.GetLastFieldError()
                Case ContractData.ContractDataError.ContractDateError
                    SystemMonitor.SmLog.smError("Errore Tag ""ContractDate"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""ContractDate"" assente", 0))

                Case ContractData.ContractDataError.EndDateError
                    SystemMonitor.SmLog.smError("Errore Tag ""EndDate"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""EndDate"" assente", 0))

                Case ContractData.ContractDataError.MarketParticipantCrossReferenceNumberError
                    SystemMonitor.SmLog.smError("Errore Tag ""MPCrossReferenceNumber"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""MPCrossReferenceNumber"" assente", 0))

                Case ContractData.ContractDataError.MarketParticipantNumberError
                    SystemMonitor.SmLog.smError("Errore Tag ""MarketParticipantNumber"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""MarketParticipantNumber"" assente", 0))

                Case ContractData.ContractDataError.MarketParticipantNumberAcqError
                    SystemMonitor.SmLog.smError("Errore Tag ""MarketParticipantNumberAcq"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""MarketParticipantNumberAcq"" assente", 0))

                Case ContractData.ContractDataError.MarketParticipantNumberCedError
                    SystemMonitor.SmLog.smError("Errore Tag ""MarketParticipantNumberCed"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""MarketParticipantNumberCed"" assente", 0))
                Case ContractData.ContractDataError.StartDateError
                    SystemMonitor.SmLog.smError("Errore Tag ""StartDate"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""StartDate"" assente", 0))

                Case ContractData.ContractDataError.StatusCodeError
                    SystemMonitor.SmLog.smError("Errore Tag ""StatusCode"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""StatusCode"" assente", 0))

                Case ContractData.ContractDataError.StatusCodeErrorWrongCode
                    SystemMonitor.SmLog.smError("Errore Tag ""StatusCode"" deve essere Abilitato NonAbilitato DaPerfezionare """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""StatusCode"" deve essere Abilitato NonAbilitato DaPerfezionare", 0))


                Case ContractData.ContractDataError.StatusDescriptionError
                    SystemMonitor.SmLog.smError("Errore Tag ""StatusDescription"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""StatusDescription"" assente", 0))

                Case ContractData.ContractDataError.SubmittedDateError
                    SystemMonitor.SmLog.smError("Errore Tag ""SubmittedDateTime"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""SubmittedDateTime"" assente", 0))

                Case ContractData.ContractDataError.TransactionReferenceNumberError
                    SystemMonitor.SmLog.smError("Errore Tag ""TransactionReferenceNumber"" assente per il contratto """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                    ' Gestione errore su file XML
                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""TransactionReferenceNumber"" assente", 0))

                Case ContractData.ContractDataError.NoError
                    Throw New ApplicationException("Errore interno: oggetto contratto non valido ma non restituisce errore")
            End Select
        End Sub
        '========================== FUNZIONI PUBBLICHE ==============================
        Public Function ParseXML() As Boolean
            ' Un po' di controlli
            Debug.Assert(Not Me.contentFile Is Nothing, "Errore contenuto del file uguale a Nothing")
            If Me.contentFile Is Nothing Then Throw New ApplicationException("Errore contenuto del file uguale a Nothing")

            Debug.Assert(Not Me.dbConn Is Nothing, "Errore oggetto Connection uguale a nothing")
            If Me.dbConn Is Nothing Then Throw New ApplicationException("Errore oggetto Connection uguale a nothing")

            '============================== PARSING FILE XML =================================
            Dim xtr As XmlTextReader = New XmlTextReader(New MemoryStream(Me.contentFile))
            xtr.WhitespaceHandling = WhitespaceHandling.None

            Try
                ' Per leggere Date e Quantita' in Italiano
                Dim cultureInfoIT As New CultureInfo("it-IT")

                '======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
                Dim elPIPTransactions As Object = xtr.NameTable.Add("PIPTransactions")
                Dim elBilateralContract As Object = xtr.NameTable.Add("BilateralContract")
                Dim elContractDate As Object = xtr.NameTable.Add("ContractDate")
                Dim elStartDate As Object = xtr.NameTable.Add("StartDate")
                Dim elEndDate As Object = xtr.NameTable.Add("EndDate")
                Dim elSubmittedDateTime As Object = xtr.NameTable.Add("SubmittedDateTime")
                Dim elMarketParticipantNumber As Object = xtr.NameTable.Add("MarketParticipantNumber")
                Dim elMarketParticipantNumberAcq As Object = xtr.NameTable.Add("MarketParticipantNumberAcq")
                Dim elMarketParticipantNumberCed As Object = xtr.NameTable.Add("MarketParticipantNumberCed")
                Dim elMPCrossReferenceNumber As Object = xtr.NameTable.Add("MPCrossReferenceNumber")
                Dim elStatusCode As Object = xtr.NameTable.Add("StatusCode")
                Dim elStatusDescription As Object = xtr.NameTable.Add("StatusDescription")
                Dim elTransactionReferenceNumber As Object = xtr.NameTable.Add("TransactionReferenceNumber")
                Dim elProgPrivileged As Object = xtr.NameTable.Add("ProgrammazionePrivilegiata")
                Dim elCutManagement As Object = xtr.NameTable.Add("GestioneTaglio")
                Dim elUnitInformation As Object = xtr.NameTable.Add("UnitInformation")

                ' Inizializzo l'oggetto che conterra' le informazioni del singolo Contratto
                Dim cd As ContractData = Nothing
                ' Di DEFAULT accetto come file XML quelli che contengono definizione di Contartti
                ' nel formato del mercato precedente
                Dim ctBilateraliContractType As CONTRACT_TYPE_VERSION = CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0

                '============================== INIZIO PARSING DEL FILE XML =========================
                While (xtr.Read())
                    Dim xrn As Object = xtr.Name
                    Select Case xtr.NodeType
                        Case XmlNodeType.Element

                            '============= PIPTRANSACTIONS ======================================
                            If (xrn Is elPIPTransactions) Then
                                ' Prelevo l'attributo che determina il formato del 
                                ' file che sto per parserizzare, di DEFAULT la versione e' la 1.0
                                ctBilateraliContractType = CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0
                                ' Verifico che ci siano attributi
                                If xtr.HasAttributes() Then
                                    Dim xmlBilateraliVersion As String = xtr.GetAttribute("BilateraliImportVersion")
                                    If xmlBilateraliVersion.ToLower() = "1.0" Then
                                        ctBilateraliContractType = CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0
                                    ElseIf xmlBilateraliVersion.ToLower() = "2.0" Then
                                        ctBilateraliContractType = CONTRACT_TYPE_VERSION.BILATERALI_VERSION_2_0
                                    End If
                                End If

                                '============= BILATERAL CONTRACT ======================================
                            ElseIf (xrn Is elBilateralContract) Then
                                Dim xmlId As String = xtr.GetAttribute("id")
                                Debug.Assert(Not xmlId Is Nothing AndAlso xmlId <> String.Empty, "Errore Attributo id non presente o vuoto nel file """ & Me.fileName & """")

                                If (xmlId Is Nothing) OrElse (xmlId = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Attributo id non presente o vuoto nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Dovrebbe saltare alla prossimo Bilateral Contract
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                Else
                                    ' L' Id lo genero io come GUID
                                    ' LEO ATTENZIONE cd = New ContractData(xmlId, ImportContratti.CreateNewId())
                                    cd = New ContractData(xmlId, ctBilateraliContractType)
                                End If

                                '=================== CONTRACT DATE ======================================
                            ElseIf (xrn Is elContractDate) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")
                                Try
                                    ' Prendo solo la Data (non dovrebbe contenere l'ora pero' per sicurezza)
                                    cd.ContractDate = Convert.ToDateTime(xtr.ReadString(), cultureInfoIT).Date
                                Catch ex As Exception
                                    SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xrn.ToString() & """ non e' una data per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non e' una data", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is not a date for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                End Try

                                '=================== START DATE ======================================
                            ElseIf (xrn Is elStartDate) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto StartDate uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")
                                Try
                                    ' Prendo solo la Data (non dovrebbe contenere l'ora pero' per sicurezza)
                                    cd.StartDate = Convert.ToDateTime(xtr.ReadString(), cultureInfoIT).Date
                                Catch ex As Exception
                                    SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xrn.ToString() & """ non e' una data per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non e' una data", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is not a date for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                End Try

                                '===================== END DATE ======================================
                            ElseIf (xrn Is elEndDate) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto EndDate uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")
                                Try
                                    ' Prendo solo la Data (non dovrebbe contenere l'ora pero' per sicurezza)
                                    cd.EndDate = Convert.ToDateTime(xtr.ReadString(), cultureInfoIT).Date
                                Catch ex As Exception
                                    SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xrn.ToString() & """ non e' una data per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non e' una data", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is not a date for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                End Try

                                '===================== SUBMITTED DATE ======================================
                            ElseIf (xrn Is elSubmittedDateTime) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto SubmittedDateTime uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")
                                Try
                                    ' Prendo solo la Data (non dovrebbe contenere l'ora pero' per sicurezza)
                                    cd.SubmittedDate = Convert.ToDateTime(xtr.ReadString(), cultureInfoIT)
                                Catch ex As Exception
                                    SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xrn.ToString() & """ non e' una data per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non e' una data", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is not a date for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                End Try

                                '===================== MARKET PARTICIPANT NUMBER ======================================
                            ElseIf (xrn Is elMarketParticipantNumber) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto MarketParticipantNumber uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                Dim xmlMPN As String = xtr.ReadString()
                                Debug.Assert(Not xmlMPN Is Nothing AndAlso xmlMPN <> String.Empty, "Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                                If (xmlMPN Is Nothing OrElse xmlMPN = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non presente o vuoto", 0))
                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id=""" & cd.IdContrattoXML & """")

                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                Else
                                    cd.MPN = xmlMPN
                                    ' Sto parserizzando un fil XML contenente contratti che provengono dalla vecchia
                                    ' piattaforma...inizializzo i TAG nuovi in modo opportuno
                                    Select Case ctBilateraliContractType
                                        Case CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0
                                            cd.MPNAcq = xmlMPN
                                            cd.MPNCed = xmlMPN
                                    End Select
                                End If
                                '===================== MARKET PARTICIPANT NUMBER ACQUIRENTE ======================================
                            ElseIf (xrn Is elMarketParticipantNumberAcq) Then
                                ' Eseguo le operazioni in funzione della versione del file di import in ingresso
                                Select Case ctBilateraliContractType
                                    ' Versione 1.0
                                Case CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0
                                        SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ errato, import proveniente dalla vecchia piattaforma nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                        ' Gestione errore su file XML
                                        iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ errato, import proveniente dalla vecchia piattaforma", 0))

                                        Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                        Debug.Assert(r, "Errore skip to node BilateralContract")
                                        cd = Nothing
                                        ' Versioni successive
                                    Case Else
                                        Debug.Assert(Not cd Is Nothing, "Oggetto MarketParticipantNumberAcq uguale a Nothing TAG """ & xrn.ToString() & """")
                                        If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                        Dim xmlMPNAcq As String = xtr.ReadString()
                                        Debug.Assert(Not xmlMPNAcq Is Nothing AndAlso xmlMPNAcq <> String.Empty, "Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                                        If (xmlMPNAcq Is Nothing OrElse xmlMPNAcq = String.Empty) Then
                                            SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                            ' Gestione errore su file XML
                                            iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non presente o vuoto", 0))
                                            'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id=""" & cd.IdContrattoXML & """")

                                            Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                            Debug.Assert(r, "Errore skip to node BilateralContract")
                                            cd = Nothing
                                        Else
                                            cd.MPNAcq = xmlMPNAcq
                                        End If
                                End Select
                                '===================== MARKET PARTICIPANT NUMBER CEDENTE ======================================
                            ElseIf (xrn Is elMarketParticipantNumberCed) Then
                                Select Case ctBilateraliContractType
                                    Case CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0
                                        ' Vecchia versione del file di import ma contenente un TAG 
                                        ' appartenente alla nuova versione => ERRORE
                                        SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ errato, import proveniente dalla vecchia piattaforma nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                        ' Gestione errore su file XML
                                        iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ errato, import proveniente dalla vecchia piattaforma", 0))

                                        Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                        Debug.Assert(r, "Errore skip to node BilateralContract")
                                        cd = Nothing
                                    Case Else
                                        Debug.Assert(Not cd Is Nothing, "Oggetto MarketParticipantNumberCed uguale a Nothing TAG """ & xrn.ToString() & """")
                                        If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                        Dim xmlMPNCed As String = xtr.ReadString()
                                        Debug.Assert(Not xmlMPNCed Is Nothing AndAlso xmlMPNCed <> String.Empty, "Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                                        If (xmlMPNCed Is Nothing OrElse xmlMPNCed = String.Empty) Then
                                            SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                            ' Gestione errore su file XML
                                            iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non presente o vuoto", 0))
                                            'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id=""" & cd.IdContrattoXML & """")

                                            Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                            Debug.Assert(r, "Errore skip to node BilateralContract")
                                            cd = Nothing
                                        Else
                                            cd.MPNCed = xmlMPNCed
                                        End If
                                End Select

                                '===================== MARKET PARTICIPANT CROSS REFERENCE NUMBER ======================================
                            ElseIf (xrn Is elMPCrossReferenceNumber) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto MPCrossReferenceNumber uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                Dim xmlMPcrn As String = xtr.ReadString()
                                Debug.Assert(Not xmlMPcrn Is Nothing AndAlso xmlMPcrn <> String.Empty, "Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                                If (xmlMPcrn Is Nothing) OrElse (xmlMPcrn = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non presente o vuoto", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                Else
                                    cd.MPCrossReferenceNumber = xmlMPcrn
                                End If

                                '===================== STATUS CODE ======================================
                            ElseIf (xrn Is elStatusCode) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto StatusCode uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                Dim xmlStatusCode As String = xtr.ReadString()
                                Debug.Assert(Not xmlStatusCode Is Nothing AndAlso xmlStatusCode <> String.Empty, "Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                                If (xmlStatusCode Is Nothing) OrElse (xmlStatusCode = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non presente o vuoto", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                Else
                                    cd.StatusCode = xmlStatusCode
                                End If

                                '===================== STATUS DECRIPTION ================================
                            ElseIf (xrn Is elStatusDescription) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto StatusDescription uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                Dim xmlStatusDescription As String = xtr.ReadString()
                                Debug.Assert(Not xmlStatusDescription Is Nothing AndAlso xmlStatusDescription <> String.Empty, "Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id """ & cd.IdContrattoXML & """ in file """ & Me.fileName & """")
                                If (xmlStatusDescription Is Nothing) OrElse (xmlStatusDescription = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non presente o vuoto", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                Else
                                    cd.StatusDescription = xmlStatusDescription
                                End If

                                '===================== TRANSACTION REFERENCE NUMBER ================================
                            ElseIf (xrn Is elTransactionReferenceNumber) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto TransactionReferenceNumber uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                Dim xmlTransactionReferenceNumber As String = xtr.ReadString()
                                Debug.Assert(Not xmlTransactionReferenceNumber Is Nothing AndAlso xmlTransactionReferenceNumber <> String.Empty, "Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id """ & cd.IdContrattoXML & """ in file """ & Me.fileName & """")
                                If (xmlTransactionReferenceNumber Is Nothing) OrElse (xmlTransactionReferenceNumber = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non presente o vuoto", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                Else
                                    cd.TransactionreferenceNumber = xmlTransactionReferenceNumber
                                End If

                                '===================== PROGRAMMAZIONE PRIVILEGIATA =========================
                            ElseIf (xrn Is elProgPrivileged) Then
                                Debug.Assert(Not cd Is Nothing, "Oggetto ProgPrivileged uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                Dim xmlProgPrivileged As String = xtr.ReadString()
                                Debug.Assert(Not xmlProgPrivileged Is Nothing AndAlso xmlProgPrivileged <> String.Empty, "Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id """ & cd.IdContrattoXML & """ in file """ & Me.fileName & """")
                                If (xmlProgPrivileged Is Nothing) OrElse (xmlProgPrivileged = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non presente o vuoto", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ not present or empty for BilateralContract id=""" & cd.IdContrattoXML & """")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    cd = Nothing
                                Else
                                    Try
                                        cd.ProgrammazionePrivilegiata = Boolean.Parse(xmlProgPrivileged)
                                    Catch ex As Exception
                                        SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xrn.ToString() & """ non e' flag priv. valido per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                        ' Gestione errore su file XML
                                        iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non e' flag priv. valido", 0))

                                        'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is not a date for BilateralContract id=""" & cd.IdContrattoXML & """")
                                        Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                        Debug.Assert(r, "Errore skip to node BilateralContract")
                                        cd = Nothing
                                    End Try
                                End If

                                '===================== GESTIONE TAGLIO =========================
                            ElseIf (xrn Is elCutManagement) Then

                                Dim xmlCutManagement As String = xtr.ReadString()

                                If (xmlCutManagement Is Nothing) OrElse (xmlCutManagement = String.Empty) Then
                                    SystemMonitor.SmLog.smTrace("Tag """ & xrn.ToString() & """ non presente o vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    cd.GestioneTaglio = DB_TABLE_CONTRATTO_GESTIONE_TAGLIO_DEFAULT
                                Else
                                    Try
                                        cd.GestioneTaglio = xmlCutManagement
                                    Catch ex As Exception
                                        SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xrn.ToString() & """ non e' flag priv. valido per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                        ' Gestione errore su file XML
                                        iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xrn.ToString() & """ non e' flag priv. valido", 0))

                                        'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is not a date for BilateralContract id=""" & cd.IdContrattoXML & """")
                                        Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                        Debug.Assert(r, "Errore skip to node BilateralContract")
                                        cd = Nothing
                                    End Try
                                End If

                                '===================== UNIT INFORMATION ================================
                            ElseIf (xrn Is elUnitInformation) Then
                                '================= LISTA DELLE UNITA' DEL CONTRATTO ==============================
                                Debug.Assert(Not cd Is Nothing, "Oggetto UnitInformation uguale a Nothing TAG """ & xrn.ToString() & """")
                                If (cd Is Nothing) Then Throw New ApplicationException("Oggetto ContractData uguale a Nothing TAG """ & xrn.ToString() & """")

                                Dim unitError As Boolean = False
                                Dim xmlTipoUnita As String = xtr.GetAttribute("TypeCode")
                                Dim xmlAssigned As String = xtr.GetAttribute("Assigned")
                                Dim xmlCategoria As String = xtr.GetAttribute("Categoria")
                                Dim xmlPrioritaBilanciamentoForzato As String = xtr.GetAttribute("PrioritaBilanciamentoForzato")
                                Dim xmlUnitStartDate As String = xtr.GetAttribute("StartDate")
                                Dim xmlUnitEndDate As String = xtr.GetAttribute("EndDate")

                                Dim unitStartDate As DateTime
                                Dim unitEndDate As DateTime
                                Dim prioritaBilanciamento As Integer

                                Dim xmlCodiceUnita As String = xtr.ReadString()
                                Debug.Assert(Not xmlTipoUnita Is Nothing AndAlso xmlTipoUnita <> String.Empty, "Error Attribute ""TypeCode"" is empty in file """ & Me.fileName & """")
                                If (xmlTipoUnita Is Nothing) OrElse (xmlTipoUnita = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Attributo ""TypeCode"" vuoto per l'Unita' """ & xmlCodiceUnita & """ per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Attributo ""TypeCode"" vuoto per l'Unita' """ & xmlCodiceUnita & """", 0))

                                    'Throw New ApplicationException("Error Attribute ""TypeCode"" is empty")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    unitError = True
                                End If

                                Select Case ctBilateraliContractType
                                    ' Nella versione 2.0 le Unita sono assegnate al Cedente e/o 
                                    ' all'acquirente
                                Case CONTRACT_TYPE_VERSION.BILATERALI_VERSION_2_0
                                        Debug.Assert(Not xmlAssigned Is Nothing AndAlso xmlAssigned <> String.Empty, "Error Attribute ""Assigned"" is empty in file """ & Me.fileName & """")
                                        If (xmlAssigned Is Nothing) OrElse (xmlAssigned = String.Empty) Then
                                            SystemMonitor.SmLog.smError("Errore Attributo ""Assigned"" vuoto per l'Unita' """ & xmlCodiceUnita & """ per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                            ' Gestione errore su file XML
                                            iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Attributo ""Assigned"" vuoto per l'Unita' """ & xmlCodiceUnita & """", 0))

                                            'Throw New ApplicationException("Error Attribute ""TypeCode"" is empty")
                                            Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                            Debug.Assert(r, "Errore skip to node BilateralContract")
                                            unitError = True
                                        End If
                                        If Not ((xmlUnitStartDate Is Nothing) OrElse (xmlUnitStartDate = String.Empty)) Then
                                            Try
                                                ' Prendo solo la Data (non dovrebbe contenere l'ora pero' per sicurezza)
                                                unitStartDate = Convert.ToDateTime(xmlUnitStartDate, cultureInfoIT).Date
                                            Catch ex As Exception
                                                SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xmlUnitStartDate & """ non e' una data per BilateralContract id """ & cd.IdContrattoXML & """ unita """ & xmlCodiceUnita & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                                ' Gestione errore su file XML
                                                iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xmlUnitStartDate & """ non e' una data", 0))

                                                'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is not a date for BilateralContract id=""" & cd.IdContrattoXML & """")
                                                Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                                Debug.Assert(r, "Errore skip to node BilateralContract")
                                                unitError = True
                                            End Try
                                        End If
                                        If Not ((xmlUnitEndDate Is Nothing) OrElse (xmlUnitEndDate = String.Empty)) Then
                                            Try
                                                ' Prendo solo la Data (non dovrebbe contenere l'ora pero' per sicurezza)
                                                unitEndDate = Convert.ToDateTime(xmlUnitEndDate, cultureInfoIT).Date
                                            Catch ex As Exception
                                                SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xmlUnitEndDate & """ non e' una data per BilateralContract id """ & cd.IdContrattoXML & """ unita """ & xmlCodiceUnita & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                                ' Gestione errore su file XML
                                                iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xmlUnitEndDate & """ non e' una data", 0))

                                                'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is not a date for BilateralContract id=""" & cd.IdContrattoXML & """")
                                                Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                                Debug.Assert(r, "Errore skip to node BilateralContract")
                                                unitError = True
                                            End Try
                                        End If

                                        If Not ((xmlPrioritaBilanciamentoForzato Is Nothing) OrElse (xmlPrioritaBilanciamentoForzato = String.Empty)) Then
                                            Try
                                                prioritaBilanciamento = Convert.ToInt32(xmlPrioritaBilanciamentoForzato, cultureInfoIT)
                                            Catch ex As Exception
                                                SystemMonitor.SmLog.smError(ex, "Errore Tag """ & xmlPrioritaBilanciamentoForzato & """ non e' una priorita' bilanciamento forzato valida per BilateralContract id """ & cd.IdContrattoXML & """ unita """ & xmlCodiceUnita & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                                ' Gestione errore su file XML
                                                iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag """ & xmlPrioritaBilanciamentoForzato & """ non e' un numero", 0))

                                                Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                                Debug.Assert(r, "Errore skip to node BilateralContract")
                                                unitError = True
                                            End Try
                                        End If
                                End Select

                                Debug.Assert(Not xmlCodiceUnita Is Nothing AndAlso xmlCodiceUnita <> String.Empty, "Error TAG """ & xrn.ToString() & """ is empty")
                                If (xmlCodiceUnita Is Nothing) OrElse (xmlCodiceUnita = String.Empty) Then
                                    SystemMonitor.SmLog.smError("Errore Tag ""UnitInformation"" vuoto per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """ linea=" & xtr.LineNumber & " posizione=" & xtr.LinePosition)
                                    ' Gestione errore su file XML
                                    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Tag ""UnitInformation"" vuoto", 0))

                                    'Throw New ApplicationException("Error TAG """ & xrn.ToString() & """ is empty")
                                    Dim r As Boolean = MoveToNode(xtr, elBilateralContract)
                                    Debug.Assert(r, "Errore skip to node BilateralContract")
                                    unitError = True
                                End If

                                If Not (unitError) Then
                                    ' Creo un'istanza della classe Unita' e gli assegno i dati
                                    Dim unitInfo As New UnitData(xmlCodiceUnita, xmlTipoUnita, cd.IdContrattoXML, ctBilateraliContractType)
                                    unitInfo.DataInizioValidita = cd.StartDate
                                    unitInfo.DataFineValidita = cd.EndDate
                                    Select Case ctBilateraliContractType
                                        Case CONTRACT_TYPE_VERSION.BILATERALI_VERSION_2_0
                                            unitInfo.Assigned = xmlAssigned
                                            If Not ((xmlCategoria Is Nothing) OrElse (xmlCategoria = String.Empty)) Then
                                                unitInfo.CategoriaUnita = xmlCategoria
                                            End If
                                            If Not ((xmlUnitStartDate Is Nothing) OrElse (xmlUnitStartDate = String.Empty)) Then
                                                unitInfo.DataInizioValidita = unitStartDate
                                            End If
                                            If Not ((xmlUnitEndDate Is Nothing) OrElse (xmlUnitEndDate = String.Empty)) Then
                                                unitInfo.DataFineValidita = unitEndDate
                                            End If
                                            If Not ((xmlPrioritaBilanciamentoForzato Is Nothing) OrElse (xmlPrioritaBilanciamentoForzato = String.Empty)) Then
                                                unitInfo.PrioritaBilanciamentoForzato = prioritaBilanciamento
                                            End If
                                    End Select

                                    ' Verifico che i dati inseriti per l'unita' siano validi
                                    If Not (unitInfo.CheckValues()) Then
                                        ManageUnitErrors(unitInfo)
                                        unitError = True
                                    End If

                                    If Not unitError Then
                                        ' Inserisco l'ID dell'unita' esplicitamente in modo che se voglio
                                        ' utilizzare un ID diverso dal codice unita' lo posso fare
                                        cd.AddUnitToContract(xmlCodiceUnita, unitInfo)
                                    End If
                                Else
                                    cd = Nothing
                                End If
                            End If

                            '===================== END BILATERAL CONTRACT ================================
                        Case XmlNodeType.EndElement
                            If (xrn Is elBilateralContract) Then

                                ' Devo fare il check values del contratto..
                                If (cd.CheckValues()) Then
                                    ' Operazioni sul DataBase
                                    Try
                                        ' Se l'operatore che e' presente nel Contratto e' Abilitato passo...
                                        ' al salvataggio su DB altrimenti non faccio nulla e lo segnalo
                                        'Debug.Assert(Not Me.alOperatoriValidi Is Nothing, "Errore interno: lista operatori validi uguale a Nothing")
                                        'If (Me.alOperatoriValidi Is Nothing) Then Throw New ApplicationException("Errore interno: lista operatori validi uguale a Nothing")

                                        'If (Me.alOperatoriValidi.Contains(cd.MPN)) Then
                                        SaveToDB(cd)
                                        'Else
                                        ' Operatore NON abilitato, non inserisco il contratto
                                        '   SystemMonitor.SmLog.smError("Errore Operatore """ & cd.MPN & """ non Abilitato per BilateralContract id """ & cd.IdContrattoXML & """ nel file """ & Me.fileName & """")
                                        ' Gestione errore su file XML
                                        '    iemErrors.AddErrorToContract(cd.IdContrattoXML, New RejectInfo("Errore Operatore """ & cd.MPN & """ non Abilitato", 0))

                                        'End If
                                    Catch ex As Exception
                                        SystemMonitor.SmLog.smError(ex, "Errore inserendo il contratto """ & cd.IdContrattoXML & """ nel DataBase")
                                        Throw
                                    End Try
                                Else
                                    ManageContractErrors(cd)
                                End If

                                ' Pronto per un nuovo contratto
                                cd = Nothing
                            End If

                    End Select
                End While

            Catch ex As Exception
                SystemMonitor.SmLog.smError(ex)
                Throw
            Finally
                If (Not xtr Is Nothing) Then xtr.Close()
            End Try
        End Function

        Public Function ExportXML() As Boolean

            Dim contractrow As Integer
            Dim DB_IdContratto As Integer

            Dim result As Boolean = False
            Dim e As System.Text.Encoding
            Dim ms As New MemoryStream
            Dim tw As New XmlTextWriter(ms, Encoding.GetEncoding("iso-8859-1"))    ' genero il file di export con l'encoding giusto

            Try
                ' creo il DS
                Dim dsContrattoUnita As New DS_ExportContratti
                daContratto.Fill(dsContrattoUnita.Contratto)

                ' se c'e` il contratto prendo anche le sue unita`
                If (dsContrattoUnita.Contratto.Rows.Count > 0) Then

                    Dim culture As CultureInfo = New CultureInfo("it-IT")
                    tw.Formatting = Formatting.Indented
                    tw.IndentChar = "	"c
                    tw.Indentation = 1
                    tw.WriteStartDocument()
                    tw.WriteStartElement("PIPTransactions")

                    Dim version As Integer
                    Dim strVersion As String
                    version = CONTRACT_TYPE_VERSION.BILATERALI_VERSION_2_0
                    strVersion = version.ToString() & ".0"

                    tw.WriteAttributeString("BilateraliImportVersion", strVersion)

                    For contractrow = 0 To dsContrattoUnita.Contratto.Rows.Count - 1
                        DB_IdContratto = dsContrattoUnita.Contratto(contractrow).IdContratto

                        'dsContrattoUnita.UnitaContrattoExt.Clear()
                        'daUnitaContratto.SelectCommand.Parameters("@IdContratto").Value = DB_IdContratto
                        'daUnitaContratto.Fill(dsContrattoUnita.UnitaContrattoExt)

                        Dim drContratto As DS_ExportContratti.ContrattoRow
                        drContratto = dsContrattoUnita.Contratto(contractrow)

                        tw.WriteStartElement("BilateralContract")
                        tw.WriteAttributeString("id", DB_IdContratto.ToString())

                        Dim myDTFI As DateTimeFormatInfo = culture.DateTimeFormat

                        tw.WriteElementString("ContractDate", drContratto.DataStipula.ToString(myDTFI.ShortDatePattern))
                        tw.WriteElementString("StartDate", drContratto.DataInizioValidita.ToString(myDTFI.ShortDatePattern))
                        tw.WriteElementString("EndDate", drContratto.DataFineValidita.ToString(myDTFI.ShortDatePattern))

                        '
                        ' Forse c'e' un formato apposito per it-IT
                        '
                        tw.WriteElementString("SubmittedDateTime", drContratto.TSModifica.ToString("dd/MM/yyyy HH.mm.ss.d3"))

                        tw.WriteElementString("MarketParticipantNumber", drContratto.CodiceOperatoreSDC.ToUpper(culture))
                        tw.WriteElementString("MarketParticipantNumberAcq", drContratto.CodiceOperatoreSDCAcquirente.ToUpper(culture))
                        tw.WriteElementString("MarketParticipantNumberCed", drContratto.CodiceOperatoreSDCCedente.ToUpper(culture))
                        tw.WriteElementString("MPCrossReferenceNumber", drContratto.CodiceContratto.ToString())
                        tw.WriteElementString("StatusCode", drContratto.StatoContratto.ToString())
                        tw.WriteElementString("StatusDescription", drContratto.StatoContratto.ToString())
                        tw.WriteElementString("TransactionReferenceNumber", drContratto.CRN.ToString())

                        If drContratto.ProgrammazionePrivilegiata Then
                            tw.WriteElementString("ProgrammazionePrivilegiata", Boolean.TrueString)
                        Else
                            tw.WriteElementString("ProgrammazionePrivilegiata", Boolean.FalseString)
                        End If

                        tw.WriteElementString("GestioneTaglio", drContratto.GestioneTaglio)
                        tw.WriteEndElement()
                    Next
                    tw.WriteEndElement()
                    tw.WriteEndDocument()
                    result = True
                End If
            Catch sqlEx As SqlException
                '
                ' Errore sul DataBase...l'eccezione sul DB non dovrebbe mai
                ' arrivare a questo punto in quanto trappate all'interno delle funzioni di Select
                '
                SystemMonitor.SmLog.smError(sqlEx)
                Throw
            Catch ex As Exception
                SystemMonitor.SmLog.smError(ex)
                Throw
            Finally
                tw.Flush()
                tw.Close()
            End Try

            '
            ' In caso di successo memorizza il content
            '
            If result Then
                contentFile = ms.ToArray()
            End If
            Return result
        End Function

        Public Function GetErrorsInXML() As Byte()
            Debug.Assert(Not Me.iemErrors Is Nothing, "Errore oggetto ImportErrorManager uguale a Nothing")
            If Me.iemErrors Is Nothing Then Throw New ApplicationException("Errore oggetto ImportErrorManager uguale a Nothing")

            Return Me.iemErrors.GenerateXML()
        End Function

        '============================ CLASSE DATI DELL'UNITA ====================================
        Public Class UnitData
            ' Errori nel caso uno dei dati dell'unita' sono Nulli
            Public Enum UnitDataError
                NoError = 0
                CodiceUnitaSDCError = -1
                TipoUnitaError = -2
                CategoriaUnitaError = -3
                DataInizioValiditaError = -4
                DataFineValiditaError = -5
                UnitaContrattoValidataError = -6
                UnitaAssegnataOpAcquirenteError = -7
                UnitaAssegnataOpCedenteError = -8
                PrioritaBilanciamentoForzatoError = -9
                AssignedError = -10
                AssignedValueError = -11
                TipoUnitaValueError = -12
            End Enum

            ' COSTANTI
            ' Valori ammessi per l'attributo Assigned
            Const ASSIGNED_ACQ As String = "A"
            Const ASSIGNED_CED As String = "C"
            Const ASSIGNED_ACQ_CED As String = "B"

            ' Valori ammessi per l'attributo UnitType
            Const UNIT_TYPE_PROD As String = "PROD"
            Const UNIT_TYPE_CONS As String = "CONS"
            Const UNIT_TYPE_BOTH As String = "BOTH"

            ' Versione del file di import
            Private _version As CONTRACT_TYPE_VERSION

            ' Codice Unita SDC
            Private _id As String
            ' Tipo Unita'
            Private _tipoUnita As String
            ' Categoria Unita
            Private _catUnita As String
            ' Data Inizio Validita
            Private _startDate As DateTime
            ' Data Fine Validita
            Private _endDate As DateTime
            ' Unita Contratto validata
            Private _unitaContrattoValidata As Boolean
            ' Unita assegnata operatore Acquirente
            Private _unitaAssegnataOpAcquirente As Boolean
            ' Unita assegnata operatore Cedente
            Private _unitaAssegnataOpCedente As Boolean
            ' Priorita' Bilanciamento Forzato (NON USATO)
            Private _prioritaBilanciamentoForzato As Integer
            ' Id del contratto XML al quale apopartiene l'unita
            Private _idContrattoXMLParent As String
            ' Unita assegnata all'Operatore Cedente e/o Acquirente (VERSIONE 2.0)
            Private _assigned As String

            ' Intero contenente l'informazione del primo campo non valido all'interno della classe
            ' Se l'XML di import dei contratti non sara' validato da uno schema questa variabile
            ' conterra' il nome del primo campo non presente nell'XML riferito all'unita'
            Private _wrongNameField As UnitDataError

            ' Array contenente i valori ammissibili per il Flag Assigned
            Private _assignedRangeValues() As String = {ASSIGNED_CED, _
              ASSIGNED_ACQ, _
              ASSIGNED_ACQ_CED}

            ' Array contenente i valori ammissibili per il Flag Assigned
            Private _unitTypeRangeValues() As String = {UNIT_TYPE_PROD, _
              UNIT_TYPE_BOTH, _
              UNIT_TYPE_CONS}


            '======================== COSTRUTTORI =================================
            Public Sub New()
                Me.New(Nothing, Nothing, Nothing, CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0)
            End Sub

            Public Sub New(ByVal CodiceUnitaSDC As String)
                Me.New(CodiceUnitaSDC, Nothing, Nothing, CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0)
            End Sub

            Public Sub New(ByVal CodiceUnitaSDC As String, ByVal TipoUnita As String, ByVal IdContrattoXMLParent As String, ByVal version As CONTRACT_TYPE_VERSION)
                Me._version = version

                Me._idContrattoXMLParent = IdContrattoXMLParent
                Me._id = CodiceUnitaSDC
                Me.TipoUnita = TipoUnita
                Me._wrongNameField = UnitDataError.NoError
                Me._startDate = DateTime.MinValue
                Me._endDate = DateTime.MinValue
                ' Valori comuni a TUTTE le unita'

                ' Valori comuni a TUTTE le unita' importate
                ' La categoria e' uguale per tutte le Unita' in quanto i Contratti "vecchi" non
                ' supportano la categoria
                Me._catUnita = "F"
                ' L'unita se presente nella tabella Unita e' valida
                Me._unitaContrattoValidata = True
                ' Le unita sono solo di Produzione (o Miste ma sempre di SOLA Produzione)....
                ' nella VERSIONE 2.0 del file di import cio' non e' piu' vero
                Select Case Me._version
                    Case CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0
                        Me._unitaAssegnataOpAcquirente = False
                        ' quindi possono essere assegnata ai soli Operatori Cedenti
                        Me._unitaAssegnataOpCedente = True
                    Case CONTRACT_TYPE_VERSION.BILATERALI_VERSION_2_0
                        Me._unitaAssegnataOpAcquirente = False
                        Me._unitaAssegnataOpCedente = False
                End Select

                ' (NON USATO)
                Me._prioritaBilanciamentoForzato = 0

            End Sub
            '======================= PROPRIETA' ============================
            ' ID CONTRATTO XML CHE CONTIENE L'UNITA
            Public Property IdContrattoXMLParent() As String
                Get
                    Return Me._idContrattoXMLParent
                End Get
                Set(ByVal Value As String)
                    Me._idContrattoXMLParent = Value
                End Set
            End Property
            ' CODICE UNITA SDC
            Public Property CodiceUnita() As String
                Get
                    Return Me._id.ToUpper()
                End Get
                Set(ByVal Value As String)
                    Me._id = Value
                End Set
            End Property
            ' TIPO UNITA
            Public Property TipoUnita() As String
                Get
                    Return MapTipoUnita()
                End Get
                Set(ByVal Value As String)
                    Me._tipoUnita = Value
                End Set
            End Property
            ' CATEGORIA UNITA
            Public Property CategoriaUnita() As String
                Get
                    'TODO: Si puo' ritornare il tipo come lo vuole il DB facendo un mapping
                    ' tra quello letto dal file e quello che in realta' si aspetta il DB
                    Return Me._catUnita
                End Get
                Set(ByVal Value As String)
                    Me._catUnita = Value
                End Set
            End Property
            ' DATA INIZIO VALIDITA
            Public Property DataInizioValidita() As DateTime
                Get
                    Return Me._startDate
                End Get
                Set(ByVal Value As DateTime)
                    Me._startDate = Value
                End Set
            End Property
            ' DATA FINE VALIDITA
            Public Property DataFineValidita() As DateTime
                Get
                    Return Me._endDate
                End Get
                Set(ByVal Value As DateTime)
                    Me._endDate = Value
                End Set
            End Property
            ' UNITA DEL CONTRATTO VALIDATA
            Public Property UnitaDelContrattoValidata() As Boolean
                Get
                    Return Me._unitaContrattoValidata
                End Get
                Set(ByVal Value As Boolean)
                    Me._unitaContrattoValidata = Value
                End Set
            End Property
            ' UNITA ASSEGNATA OPERATORE ACQUIRENTE
            Public Property UnitaAssegnataopAcquirente() As Boolean
                Get
                    Return Me._unitaAssegnataOpAcquirente
                End Get
                Set(ByVal Value As Boolean)
                    Me._unitaAssegnataOpAcquirente = Value
                End Set
            End Property
            ' UNITA ASSEGNATA OPERATORE CEDENTE
            Public Property UnitaAssegnataOpCedente() As Boolean
                Get
                    Return Me._unitaAssegnataOpCedente
                End Get
                Set(ByVal Value As Boolean)
                    Me._unitaAssegnataOpCedente = Value
                End Set
            End Property
            ' PRIORITA BILANCIAMENTO FORZATO
            Public Property PrioritaBilanciamentoForzato() As Integer
                Get
                    Return Me._prioritaBilanciamentoForzato
                End Get
                Set(ByVal Value As Integer)
                    Me._prioritaBilanciamentoForzato = Value
                End Set
            End Property
            ' ASSIGNED
            Public Property Assigned() As String
                Get
                    Return Me._assigned.ToUpper()
                End Get
                Set(ByVal Value As String)
                    Me._assigned = Value
                    Select Case Me._assigned.ToUpper()
                        Case ASSIGNED_ACQ
                            Me._unitaAssegnataOpAcquirente = True
                            Me._unitaAssegnataOpCedente = False
                        Case ASSIGNED_CED
                            Me._unitaAssegnataOpCedente = True
                            Me._unitaAssegnataOpAcquirente = False
                        Case ASSIGNED_ACQ_CED
                            Me._unitaAssegnataOpCedente = True
                            Me._unitaAssegnataOpAcquirente = True
                        Case Else
                            'Throw New ApplicationException("Errore valore dell'attributo Assigned sconosciuto")
                    End Select
                End Set
            End Property

            Public ReadOnly Property GetLastFieldError() As UnitDataError
                Get
                    Return Me._wrongNameField
                End Get
            End Property

            '========================== FUNZIONI PRIVATE ==============================
            Private Sub InitClass()

            End Sub
            Private Function MapTipoUnita() As String
                ' File XML              DB
                '   PROD                P   produzione
                '   BOTH                M   miste
                '   CONS                C   consumo
                Dim dbTipoUnita As String
                Select Case Me._tipoUnita.ToUpper()
                    Case UNIT_TYPE_PROD
                        dbTipoUnita = "P"
                    Case UNIT_TYPE_BOTH
                        dbTipoUnita = "M"
                    Case UNIT_TYPE_CONS
                        dbTipoUnita = "C"
                    Case Else
                        dbTipoUnita = String.Empty
                        Throw New ApplicationException("Errore Tipo Unita sconosciuto")
                End Select
                Return dbTipoUnita
            End Function
            '========================== FUNZIONI PUBBLICHE ==============================
            Public Function CheckValues() As Boolean
                Me._wrongNameField = UnitDataError.NoError
                If (Me._id Is Nothing) OrElse (Me._id = String.Empty) Then
                    Me._wrongNameField = UnitDataError.CodiceUnitaSDCError
                    Return False
                End If

                If (Me._tipoUnita Is Nothing) OrElse (Me._tipoUnita = String.Empty) Then
                    Me._wrongNameField = UnitDataError.TipoUnitaError
                    Return False
                Else
                    If (Array.IndexOf(Me._unitTypeRangeValues, Me._tipoUnita) = -1) Then
                        Me._wrongNameField = UnitDataError.TipoUnitaValueError
                        Return False
                    End If
                End If

                If (Me._catUnita Is Nothing) OrElse (Me._catUnita = String.Empty) Then
                    Me._wrongNameField = UnitDataError.CategoriaUnitaError
                    Return False
                End If

                If (Me._startDate = DateTime.MinValue) Then
                    Me._wrongNameField = UnitDataError.DataInizioValiditaError
                    Return False
                End If

                If (Me._endDate = DateTime.MinValue) Then
                    Me._wrongNameField = UnitDataError.DataFineValiditaError
                    Return False
                End If

                Select Case Me._version
                    Case CONTRACT_TYPE_VERSION.BILATERALI_VERSION_2_0
                        If (Me._assigned Is Nothing) OrElse (Me._assigned = String.Empty) Then
                            Me._wrongNameField = UnitDataError.AssignedError
                            Return False
                        Else
                            If (Array.IndexOf(Me._assignedRangeValues, Me._assigned) = -1) Then
                                Me._wrongNameField = UnitDataError.AssignedValueError
                                Return False
                            End If
                        End If

                End Select
                Return True
            End Function
        End Class

        '============================ CLASSE DATI DEL CONTRATTO =================================
        Public Class ContractData
            ' Errori nel caso uno dei dati dell'unita' sono Nulli
            Public Enum ContractDataError
                NoError = 0
                IdContrattoError = -1
                ContractDateError = -2
                StartDateError = -3
                EndDateError = -4
                SubmittedDateError = -5
                MarketParticipantNumberError = -6
                MarketParticipantCrossReferenceNumberError = -7
                StatusCodeError = -8
                StatusDescriptionError = -9
                TransactionReferenceNumberError = -10
                MarketParticipantNumberAcqError = -11
                MarketParticipantNumberCedError = -12

                StatusCodeErrorWrongCode = -13
            End Enum

            ' ID Contratto presente nel file XML e usato SOLO in fase di DEBUG e
            ' LOG degli errori per capire quale contratto ha generato un errore in modo da
            ' permettere all'utente di correggere il file (puo' essere Nothing)
            Private _contractVersion As CONTRACT_TYPE_VERSION
            Private _idContrattoXML As String

            Private _idContratto As Integer
            Private _idContrattoAssegnato As Boolean = False

            Private _contractDate As DateTime
            Private _startDate As DateTime
            Private _endDate As DateTime
            Private _submittedDate As DateTime
            ' MarketParticipantNumber Titolare
            Private _mpn As String
            ' MarketParticipantNumber Acquirente
            Private _mpnAcq As String
            ' MarketParticipantNumber Cedente
            Private _mpnCed As String
            ' MPCrossReferenceNumber
            Private _MPcrn As String
            Private _statusCode As String
            Private _statusDescription As String
            Private _transactionReferenceNumber As String
            Private _programmazionePrivilegiata As Boolean
            Private _gestioneTaglio As String
            ' Lista Unita' coinvolte nel contratto
            Private _htListaUnita As Hashtable

            ' Intero contenente l'informazione del primo campo non valido all'interno della classe
            ' Se l'XML di import dei contratti non sara' validato da uno schema questa variabile
            ' conterra' l'informazione del primo campo non presente nell'XML riferito al contratto
            Private _wrongNameField As ContractDataError

            ' Stringa di errore
            Private errorMessage As String

            '========================== COSTRUTTORI =========================================
            Public Sub New(ByVal idContrattoXML As String)
                Me.New(idContrattoXML, CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0)
            End Sub

            Public Sub New(ByVal idContrattoXML As String, ByVal version As CONTRACT_TYPE_VERSION)
                ' Valori di Default per le Date in modo da capire se durante il parsing
                ' del file XML i TAG sono presenti
                Me._contractDate = DateTime.MinValue
                Me._startDate = DateTime.MinValue
                Me._endDate = DateTime.MinValue
                Me._submittedDate = DateTime.MinValue

                If Not (idContrattoXML Is Nothing) Then
                    Me._idContrattoXML = idContrattoXML
                Else
                    Me._idContrattoXML = String.Empty
                End If
                Me._programmazionePrivilegiata = False
                Me._htListaUnita = New Hashtable
                Me._wrongNameField = ContractDataError.NoError

                Me._contractVersion = version
            End Sub

            '========================= PROPRIETA' ===========================================
            Public ReadOnly Property GetLastFieldError() As ContractDataError
                Get
                    Return Me._wrongNameField
                End Get
            End Property

            Public ReadOnly Property IdContrattoXML() As String
                Get
                    Return Me._idContrattoXML
                End Get
            End Property

            ' ID CONTRATTO
            Public Property DB_IdContratto() As Integer
                Get
                    Return Me._idContratto
                End Get
                Set(ByVal Value As Integer)
                    Me._idContrattoAssegnato = True
                    Me._idContratto = Value
                End Set
            End Property
            ' CONTRACT DATE
            Public Property ContractDate() As DateTime
                Get
                    Return Me._contractDate
                End Get
                Set(ByVal Value As DateTime)
                    Me._contractDate = Value
                End Set
            End Property
            ' START DATE
            Public Property StartDate() As DateTime
                Get
                    Return Me._startDate
                End Get
                Set(ByVal Value As DateTime)
                    Me._startDate = Value
                End Set
            End Property
            ' END DATE
            Public Property EndDate() As DateTime
                Get
                    Return Me._endDate
                End Get
                Set(ByVal Value As DateTime)
                    Me._endDate = Value
                End Set
            End Property
            ' SUBMITTED DATE
            Public Property SubmittedDate() As DateTime
                Get
                    Return Me._submittedDate
                End Get
                Set(ByVal Value As DateTime)
                    Me._submittedDate = Value
                End Set
            End Property
            ' MARKET PARTICIPANT NUMBER (CodiceOperatoreSDC Responsabile)
            Public Property MPN() As String
                Get
                    Return Me._mpn.ToUpper()
                End Get
                Set(ByVal Value As String)
                    Me._mpn = Value
                End Set
            End Property
            ' MARKET PARTICIPANT NUMBER ACQUIRENTE (CodiceOperatoreSDC Acquirente)
            Public Property MPNAcq() As String
                Get
                    Return Me._mpnAcq.ToUpper()
                End Get
                Set(ByVal Value As String)
                    Me._mpnAcq = Value
                End Set
            End Property
            ' MARKET PARTICIPANT NUMBER CEDENTE (CodiceOperatoreSDC Cedente)
            Public Property MPNCed() As String
                Get
                    Return Me._mpnCed.ToUpper()
                End Get
                Set(ByVal Value As String)
                    Me._mpnCed = Value
                End Set
            End Property
            ' MARKET PARTICIPANT CROSS REFERENCE NUMBER (CodiceContratto)
            Public Property MPCrossReferenceNumber() As String
                Get
                    Return Me._MPcrn.ToUpper()
                End Get
                Set(ByVal Value As String)
                    Me._MPcrn = Value
                End Set
            End Property
            ' STATUS CODE
            Public Property StatusDescription() As String
                Get
                    Return Me._statusDescription
                End Get
                Set(ByVal Value As String)
                    Me._statusDescription = Value
                End Set
            End Property
            ' STATUS DESCRIPTION
            Public Property StatusCode() As String
                Get
                    ' La descrizione dello stato che importiamo nella vecchia versione contiene valori che
                    ' non sono compatibili con quelli che usiamo noi nel sistema,
                    ' devo eseguire un mapping
                    If _contractVersion = CONTRACT_TYPE_VERSION.BILATERALI_VERSION_1_0 Then
                        Return MapStatoContratto()
                    Else
                        Return Me._statusCode
                    End If
                End Get
                Set(ByVal Value As String)
                    Me._statusCode = Value
                End Set
            End Property
            ' TRANSACTION REFERENCE NUMBER (CRN)
            Public Property TransactionreferenceNumber() As String
                Get
                    Return Me._transactionReferenceNumber.ToUpper()
                End Get
                Set(ByVal Value As String)
                    Me._transactionReferenceNumber = Value
                End Set
            End Property
            ' PROGRAMMAZIONE PRIVILEGIATA
            Public Property ProgrammazionePrivilegiata() As Boolean
                Get
                    Return Me._programmazionePrivilegiata
                End Get
                Set(ByVal Value As Boolean)
                    Me._programmazionePrivilegiata = Value
                End Set
            End Property
            ' GESTIONE TAGLIO
            Public Property GestioneTaglio() As String
                Get
                    Return Me._gestioneTaglio
                End Get
                Set(ByVal Value As String)
                    Me._gestioneTaglio = Value
                End Set
            End Property
            ' LISTA UNITA 
            Public ReadOnly Property UnitaCollection() As ICollection
                Get
                    Return Me._htListaUnita.Values
                End Get
            End Property

            '========================== FUNZIONI PRIVATE ==============================
            Private Function MapStatoContratto() As String
                If (Me._statusCode.ToUpper() = "APPR") Then
                    Return "Abilitato"
                ElseIf (Me._statusCode.ToUpper() = "NAPP") Then
                    Return "NonAbilitato"
                Else
                    ' Throw New ApplicationException("Errore TAG StatusCode non valido")
                    Return "NonAbilitato"
                End If
            End Function

            '========================== FUNZIONI PUBBLICHE ==============================
            Public Sub AddUnitToContract(ByVal id As String, ByVal Unit As UnitData)
                ' L'ID per adesso e' uguale al CodiceUnitaSDC se volessi cambiare gestione
                ' con questo portotipo posso farlo

                ' Un po' di controlli prima di effettuare l'operazione
                errorMessage = "Errore lista unita uguale a Nothing"
                Debug.Assert(Not Me._htListaUnita Is Nothing, errorMessage)
                If (_htListaUnita Is Nothing) Then Throw New ArgumentNullException(errorMessage)

                errorMessage = "Error Unit uguale a Nothing"
                Debug.Assert(Not Unit Is Nothing, errorMessage)
                If (Unit Is Nothing) Then Throw New ArgumentNullException(errorMessage)

                errorMessage = "Error ID Unita uguale a Nothing"
                Debug.Assert(Not id Is Nothing, errorMessage)
                If (id Is Nothing) Then Throw New ArgumentNullException(errorMessage)

                Me._htListaUnita.Add(id, Unit)
            End Sub

            Public Function CheckValues() As Boolean
                Me._wrongNameField = ContractDataError.NoError

                'If (Me._idContrattoAssegnato = False) Then
                '    Me._wrongNameField = ContractDataError.IdContrattoError
                '    Return False
                'End If

                If (Me._contractDate = DateTime.MinValue) Then
                    Me._wrongNameField = ContractDataError.ContractDateError
                    Return False
                End If

                If (Me._startDate = DateTime.MinValue) Then
                    Me._wrongNameField = ContractDataError.StartDateError
                    Return False
                End If

                If (Me._endDate = DateTime.MinValue) Then
                    Me._wrongNameField = ContractDataError.EndDateError
                    Return False
                End If

                If (Me._submittedDate = DateTime.MinValue) Then
                    Me._wrongNameField = ContractDataError.SubmittedDateError
                    Return False
                End If

                If (Me._mpn Is Nothing) OrElse (Me._mpn = String.Empty) Then
                    Me._wrongNameField = ContractDataError.MarketParticipantNumberError
                    Return False
                End If

                If (Me._mpnAcq Is Nothing) OrElse (Me._mpnAcq = String.Empty) Then
                    Me._wrongNameField = ContractDataError.MarketParticipantNumberAcqError
                    Return False
                End If

                If (Me._mpnCed Is Nothing) OrElse (Me._mpnCed = String.Empty) Then
                    Me._wrongNameField = ContractDataError.MarketParticipantNumberCedError
                    Return False
                End If

                If (Me._MPcrn Is Nothing) OrElse (Me._MPcrn = String.Empty) Then
                    Me._wrongNameField = ContractDataError.MarketParticipantCrossReferenceNumberError
                    Return False
                End If

                If (Me.StatusCode Is Nothing) OrElse (Me._statusCode = String.Empty) Then
                    Me._wrongNameField = ContractDataError.StatusCodeError
                    Return False
                End If

                If (Me._statusDescription Is Nothing) OrElse (Me._statusDescription = String.Empty) Then
                    Me._wrongNameField = ContractDataError.StatusDescriptionError
                    Return False
                End If

                If (Me._transactionReferenceNumber Is Nothing) OrElse (Me._transactionReferenceNumber = String.Empty) Then
                    Me._wrongNameField = ContractDataError.TransactionReferenceNumberError
                    Return False
                End If

                Select Case Me.StatusCode
                    Case "Abilitato", "NonAbilitato", "DaPerfezionare"
                    Case Else
                        Me._wrongNameField = ContractDataError.StatusCodeErrorWrongCode
                        Return False
                End Select

                Return True
            End Function

        End Class

        '============================ CLASSE DI GESTIONE E GENERAZIONE DEL FILE RELATIVA AGLI ERRORI =================================
        Public Class RejectInfo
            Private _text As String
            Private _code As Integer
            Private _lineNumber As Integer
            Private _linePosition As Integer

            'Public Sub New()

            'End Sub

            Public Sub New(ByVal ErrorText As String, ByVal ErrorCode As Integer)
                Me.New(ErrorText, ErrorCode, 0, 0)
            End Sub

            Public Sub New(ByVal ErrorText As String, ByVal ErrorCode As Integer, ByVal LineNumber As Integer, ByVal LinePosition As Integer)
                Me._text = ErrorText
                Me._code = ErrorCode
            End Sub

            Public Property LineNumber() As Integer
                Get
                    Return Me._lineNumber
                End Get
                Set(ByVal Value As Integer)
                    Me._lineNumber = Value
                End Set
            End Property

            Public Property ReasonText() As String
                Get
                    Return Me._text
                End Get
                Set(ByVal Value As String)
                    Me._text = Value
                End Set
            End Property

            Public Property ReasonCode() As Integer
                Get
                    Return Me._code
                End Get
                Set(ByVal Value As Integer)
                    Me._code = Value
                End Set
            End Property
        End Class

        Public Class ImportErrorManager
            Private _xwr As XmlTextWriter
            Private _ms As MemoryStream
            Private _slErrors As SortedList
            ' Lista degli errori ordinati per IdContratto, doce l'id contratto e' quello del file XML
            Private _htErrors As Hashtable
            ' Lista degli errori di tutti quei contratti che sono senza ID
            Private _htErrorsNoId As Hashtable

            Public Sub New()
                Me._ms = New MemoryStream
                Me._xwr = New XmlTextWriter(Me._ms, Encoding.UTF8)
                Me._slErrors = New SortedList
                Me._htErrors = New Hashtable
            End Sub

            'Public ReadOnly Property ListaErroriContrattiConID() As Hashtable
            '	Get
            '		Return Me._htErrors
            '	End Get
            'End Property
            'Public ReadOnly Property ListaErroriContrattiSenzaID() As Hashtable
            '	Get
            '		Return Me._htErrorsNoId
            '	End Get
            'End Property

            Public Sub AddErrorToContract(ByVal IdContrattoXML As String, ByVal Errore As RejectInfo)
                If (IdContrattoXML Is Nothing) OrElse (IdContrattoXML = String.Empty) Then
                    If (_htErrorsNoId.Count = 0) Then
                        ' E' il primo elemento, poiche' l'IdContrattoXml non e' utilizzabile
                        ' uso un progressivo
                        _htErrorsNoId.Add(1, Errore)
                    Else
                        Dim id As Integer = _htErrorsNoId.Count + 1
                        _htErrorsNoId.Add(id, Errore)
                    End If

                    Return
                End If

                Dim slCurrent As ArrayList
                If Not (Me._htErrors.Contains(IdContrattoXML)) Then
                    slCurrent = New ArrayList
                    Me._htErrors.Add(IdContrattoXML, slCurrent)
                Else
                    slCurrent = DirectCast(Me._htErrors.Item(IdContrattoXML), ArrayList)
                End If
                slCurrent.Add(Errore)
            End Sub

            Public Function GenerateXML() As Byte()
                ' Se non ci sono errori restituisco Nothing
                If Me._htErrors.Count = 0 Then Return Nothing

                Try
                    _xwr.Formatting = Formatting.Indented
                    _xwr.IndentChar = "	"c       ' e` un tab
                    _xwr.Indentation = 1
                    _xwr.WriteStartDocument()

                    '==================== INIZIO FILE XML BUS ===================================
                    _xwr.WriteStartElement("PIPTransactionAcknowledgement")
                    If (True) Then
                        _xwr.WriteAttributeString("xmlns", "urn:XML-PIPE")
                        _xwr.WriteAttributeString("xmlns", "xsi", Nothing, "http://www.w3.org/2001/XMLSchema-instance")
                        _xwr.WriteAttributeString("Version", "1.0")
                        For Each idContrattoXml As String In _htErrors.Keys()       ' LEO ATTENZIONE IdContratto
                            _xwr.WriteStartElement("BilateralContract")
                            If True Then
                                _xwr.WriteAttributeString("ID", idContrattoXml)

                                Dim alErrorPerContratto As ArrayList = DirectCast(_htErrors(idContrattoXml), ArrayList)
                                Debug.Assert(Not alErrorPerContratto Is Nothing, "Errore interno SortedList degli errori uguale a Nothing")
                                If Not (alErrorPerContratto Is Nothing) Then
                                    For i As Integer = 0 To alErrorPerContratto.Count - 1
                                        Dim errInfo As RejectInfo = DirectCast(alErrorPerContratto(i), RejectInfo)
                                        If Not (errInfo Is Nothing) Then
                                            _xwr.WriteStartElement("RejectInformation")
                                            _xwr.WriteStartElement("ReasonText")
                                            _xwr.WriteString(errInfo.ReasonText)
                                            _xwr.WriteEndElement()
                                            _xwr.WriteEndElement()
                                        End If

                                    Next
                                Else
                                    Throw New ApplicationException("Errore interno SortedList degli errori uguale a Nothing")
                                End If
                            End If
                            _xwr.WriteEndElement()
                        Next
                    End If
                    _xwr.WriteEndDocument()
                    _xwr.Flush()

                    Return Me._ms.ToArray()
                Catch ex As Exception
                    SystemMonitor.SmLog.smError(ex, "Errore nella produzione del File XML di errore dell'import dei contratti")
                    Throw New ApplicationException("Errore nella produzione del File XML di errore dell'import dei contratti")
                Finally
                    _xwr.Close()
                End Try
            End Function
        End Class
    End Class

#End Region


End Class
