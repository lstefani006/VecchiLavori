Imports System.Text
Imports System.Data
Imports System.Data.SqlClient

Public Class Download
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        _cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents _daDownload As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelectFileDownload As System.Data.SqlClient.SqlCommand
    Friend WithEvents _dsDownloadFile As Bil.DS_DownloadFile
    Friend WithEvents _cmdExtractFile As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdUpdateFileDownload As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdUpdateFlagDownload As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me._daDownload = New System.Data.SqlClient.SqlDataAdapter
        Me._cmdSelectFileDownload = New System.Data.SqlClient.SqlCommand
        Me._cmdUpdateFileDownload = New System.Data.SqlClient.SqlCommand
        Me._dsDownloadFile = New Bil.DS_DownloadFile
        Me._cmdExtractFile = New System.Data.SqlClient.SqlCommand
        Me._cmdUpdateFlagDownload = New System.Data.SqlClient.SqlCommand
        CType(Me._dsDownloadFile, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
        "rsist security info=False;initial catalog=Bilaterali"
        '
        '_daDownload
        '
        Me._daDownload.SelectCommand = Me._cmdSelectFileDownload
        Me._daDownload.UpdateCommand = Me._cmdUpdateFileDownload
        '
        '_cmdSelectFileDownload
        '
		Me._cmdSelectFileDownload.CommandText = "SELECT IdFile, CodiceOperatoreSDC, TSDownload, TSCreazione, DescrizioneFile, Zipp" & _
		"ed, NomeFile, CodiceTipoFile FROM dbo.FileOperatori"
        Me._cmdSelectFileDownload.Connection = Me._cn
        '
        '_cmdUpdateFileDownload
        '
        Me._cmdUpdateFileDownload.CommandText = "UPDATE dbo.FileOperatori SET TSDownload = @TSDownload, CodiceOperatoreSDC = @Codi" & _
        "ceOperatoreSDC, CodiceTipoFile = @CodiceTipoFile, NomeFile = @NomeFile, Descrizi" & _
        "oneFile = @DescrizioneFile, Zipped = @Zipped, TSCreazione = @TSCreazione WHERE (" & _
        "IdFile = @IdFile)"
        Me._cmdUpdateFileDownload.Connection = Me._cn
        Me._cmdUpdateFileDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSDownload", System.Data.SqlDbType.DateTime, 8, "TSDownload"))
        Me._cmdUpdateFileDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
        Me._cmdUpdateFileDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceTipoFile", System.Data.SqlDbType.VarChar, 10, "CodiceTipoFile"))
        Me._cmdUpdateFileDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NomeFile", System.Data.SqlDbType.VarChar, 256, "NomeFile"))
        Me._cmdUpdateFileDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizioneFile", System.Data.SqlDbType.VarChar, 256, "DescrizioneFile"))
        Me._cmdUpdateFileDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Zipped", System.Data.SqlDbType.Bit, 1, "Zipped"))
        Me._cmdUpdateFileDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSCreazione", System.Data.SqlDbType.DateTime, 8, "TSCreazione"))
        Me._cmdUpdateFileDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
        '
        '_dsDownloadFile
        '
        Me._dsDownloadFile.CaseSensitive = True
        Me._dsDownloadFile.DataSetName = "DS_DownloadFile"
        Me._dsDownloadFile.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        '_cmdExtractFile
        '
		Me._cmdExtractFile.CommandText = "SELECT Zipped, Encoding, ContenutoFile FROM dbo.FileOperatori"
        Me._cmdExtractFile.Connection = Me._cn
        '
        '_cmdUpdateFlagDownload
        '
        Me._cmdUpdateFlagDownload.CommandText = "UPDATE dbo.FileOperatori SET TSDownload = @TSDownload WHERE (IdFile = @IdFile)"
        Me._cmdUpdateFlagDownload.Connection = Me._cn
        Me._cmdUpdateFlagDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSDownload", System.Data.SqlDbType.DateTime, 8, "TSDownload"))
        Me._cmdUpdateFlagDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
        CType(Me._dsDownloadFile, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region


	Public Function GetListaFileToDownload(ByVal di As DateTime, ByVal df As DateTime, ByVal maxRecordsToDownload As Integer) As DS_DownloadFile
		Try
			_cn.Open()
			Dim ds As New DS_DownloadFile

			If maxRecordsToDownload > 0 Then
				_daDownload.SelectCommand.CommandText = _daDownload.SelectCommand.CommandText.Replace("SELECT ", String.Format("SELECT TOP {0} ", maxRecordsToDownload))
			End If

			_daDownload.SelectCommand.CommandText += " where 1=1 "

			If di > DateTime.MinValue Then
				_daDownload.SelectCommand.CommandText += " and TSCreazione >= @di "
				_daDownload.SelectCommand.Parameters.Add("@di", di)
			End If

			If df < DateTime.MaxValue Then
				' in df e` stato aggiunto gia` un giorno
				_daDownload.SelectCommand.CommandText += " and TSCreazione < @df "
				_daDownload.SelectCommand.Parameters.Add("@df", df)
			End If

			_daDownload.Fill(ds.DownloadFile)
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function


	Public Function GetListaFileToDownload(ByVal maxRecordsToDownload As Integer, ByVal queryParameters As QueryParameter()) As DS_DownloadFile
		Try
			_cn.Open()
			Dim ds As New DS_DownloadFile

			Dim cmd As SqlCommand = _daDownload.SelectCommand

			If maxRecordsToDownload > 0 Then
				cmd.CommandText = _daDownload.SelectCommand.CommandText.Replace("SELECT ", String.Format("SELECT TOP {0} ", maxRecordsToDownload))
			End If

			cmd.CommandText += " where 1=1 "

			For Each qp As QueryParameter In queryParameters
				Select Case qp.Name
					Case "operatore"

						If qp.Value.ToString.EndsWith("%") Then
							cmd.CommandText += " and CodiceOperatoreSDC LIKE @IdOperatore "
							cmd.Parameters.Add("@IdOperatore", qp.Value)
						Else
							cmd.CommandText += " and CodiceOperatoreSDC = @IdOperatore "
							cmd.Parameters.Add("@IdOperatore", qp.Value)
						End If

					Case "di"
						cmd.CommandText += " and TSCreazione >= @di"
						cmd.Parameters.Add("@di", qp.Value)

					Case "df"
						cmd.CommandText += " and TSCreazione <= @df"
						cmd.Parameters.Add("@df", qp.Value)

					Case "StatoDownload"
						If CType(qp.Value, Boolean) Then
							' non scaricati
							cmd.CommandText += " AND TSDownload IS NULL"
						Else
							' gia` scaricati
							cmd.CommandText += " AND TSDownload IS NOT NULL"
						End If

					Case "TipoFile"
						cmd.CommandText += " AND CodiceTipoFile LIKE '" + qp.Value.ToString + "%' "

					Case Else
						smError("filtro non valido")
				End Select
			Next

			cmd.CommandText += " order by TSCreazione desc"

			_daDownload.Fill(ds.DownloadFile)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cn.Dispose()
		End Try
	End Function

	Public Sub UpdateFlagDownload(ByVal IdFile As String, ByVal dataDownload As DateTime)
		Try
			_cn.Open()
			_cmdUpdateFlagDownload.Parameters("@TSDownload").Value = dataDownload
			_cmdUpdateFlagDownload.Parameters("@IdFile").Value = IdFile
			Dim rowsAffected As Integer = _cmdUpdateFlagDownload.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try

	End Sub
	Public Sub SaveDataSet(ByVal ds As DS_DownloadFile)
		Try
			_cn.Open()

			_daDownload.Update(ds.DownloadFile)
			Return

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Sub
	Public Function GetBlobFile(ByVal idFile As String, ByRef zipped As Boolean, ByRef fileEncoding As String) As Byte()
		Try
			_cn.Open()

			zipped = False
			If Not (idFile Is Nothing) AndAlso (idFile <> String.Empty) Then
				Dim c As StringBuilder = New StringBuilder
				c.Append(" WHERE IdFile = @IdFile ")
				_cmdExtractFile.CommandText &= c.ToString()
				_cmdExtractFile.Parameters.Add("@IdFile", idFile)
			End If

			Dim rd As SqlDataReader
			Try
				rd = _cmdExtractFile.ExecuteReader(CommandBehavior.SequentialAccess)
				Dim blobSize As Long
				Dim bufferSize As Integer = 100

				While rd.Read()
					zipped = rd.GetBoolean(0)
					If rd.IsDBNull(1) Then fileEncoding = "UTF-8" Else fileEncoding = rd.GetString(1)
					blobSize = rd.GetBytes(2, 0, Nothing, 0, 100)
					If (blobSize > 0) Then
						Dim abyFA(CInt(blobSize) - 1) As Byte
						Dim ret As Long
						ret = rd.GetBytes(2, 0, abyFA, 0, CInt(blobSize))
						Return abyFA
					End If
				End While
			Finally
				If Not rd Is Nothing Then rd.Close() : rd = Nothing
			End Try

			Return Nothing
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function
End Class
