Imports System.Data
Imports System.Text
Imports System.Data.SqlClient
Imports System.Xml
Imports System.Xml.Schema
Imports System.Configuration
Imports System.IO
Imports System.Globalization



Public Class ProgrammiOperatori
    Inherits BilBLBase

    Public Function Get_ProgrammiOperatori(ByVal dataRicerca As DateTime, ByVal oraRicerca As Integer, ByVal IdContratto As Integer, _
                                            ByVal OpCedente As Boolean, ByVal OpAcquirente As Boolean) As DS_ProgrammiOperatori
        Dim progressNumber As Integer
        cn.ConnectionString = GetConnectionString()
        Try
            cn.Open()
            Dim ds As New DS_ProgrammiOperatori
           
            Me.cmdSelect.Parameters("@DataRicerca").Value = dataRicerca
            Me.cmdSelect.Parameters("@OraRicerca").Value = oraRicerca
            Me.cmdSelect.Parameters("@IdContratto").Value = IdContratto
            Me.cmdSelect.Parameters("@OpCedente").Value = OpCedente
			Me.cmdSelect.Parameters("@OpAcquirente").Value = OpAcquirente

			Dim s As String = AppSettingToString("ProgrammiOperatori.Get_ProgrammiOperatori.UseSP", "dbo.spGetProgrammiOperatori")
			If s.Length > 0 Then
				cmdSelect.CommandType = CommandType.StoredProcedure
				cmdSelect.CommandText = s
			End If

			Me.daProgrammiOperatori.Fill(ds.ProgrammiOperatori)
			progressNumber = 0
			For Each drProgrammiOperatori As DS_ProgrammiOperatori.ProgrammiOperatoriRow In ds.ProgrammiOperatori
				progressNumber += 1
				drProgrammiOperatori.PrioritaBilanciamento = progressNumber
			Next
			ds.AcceptChanges()
			Return ds

		Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
        End Try
    End Function

    Function GeneraProgrammaOrarioXML(ByVal CompanyName As String, ByVal CompanyIdentifier As String, ByVal dataRicerca As DateTime, ByVal oraRicerca As Integer, _
                                      ByVal dsProgrammiOrari As DS_ProgrammiOperatori, _
                                      ByRef bProgramWithData As Boolean) As Byte()
        ' Questa funzione ritorna il file Xml se tutto e' andato bene
        ' altrimenti il relativo messaggio di errore
        Dim e As System.Text.Encoding
        Dim ms As New MemoryStream
        Dim by() As Byte
        Dim tw As New XmlTextWriter(ms, Encoding.GetEncoding("iso-8859-1"))    ' genero le offerte direttamente con l'encoding giusto.
        bProgramWithData = GeneraProgrammaOrarioWorker(CompanyName, CompanyIdentifier, dataRicerca, oraRicerca, dsProgrammiOrari, tw)
        tw.Flush()
        tw.Close()
        by = ms.ToArray()
        Return by
    End Function

    Private Function GenCreationDate() As String
        Dim t As DateTime
        Dim id As String

        t = DateTime.Now
        id = t.ToString("yyyyMMddHHmmss")
        GenCreationDate = id
    End Function
    Private Function GenReferenceNumber() As String
        Dim t As DateTime
        Dim id As String

        t = DateTime.Now
        id = t.ToString("yyyyMMddHHmmss") + t.Millisecond.ToString("d3")
        GenReferenceNumber = id
    End Function

    Private Function GeneraProgrammaOrarioWorker(ByVal CompanyName As String, ByVal CompanyIdentifier As String, ByVal dataRicerca As DateTime, _
                                    ByVal oraRicerca As Integer, ByVal dsProgrammiOperatori As DS_ProgrammiOperatori, ByVal stream As XmlTextWriter) As Boolean

        Dim bProgramWithData As Boolean
        Dim bFirst As Boolean
        Dim culture As CultureInfo = New CultureInfo("it-IT")
        stream.Formatting = Formatting.Indented
        stream.IndentChar = "	"c
        stream.Indentation = 1
        stream.WriteStartDocument()
        stream.WriteStartElement("PIPEDocument")
        stream.WriteAttributeString("xmlns", "urn:XML-PIPE")
        stream.WriteAttributeString("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
        stream.WriteAttributeString("xsi:schemaLocation", "urn:XML-PIPE PIPEDocument.xsd")
        stream.WriteAttributeString("ReferenceNumber", GenReferenceNumber)
        stream.WriteAttributeString("CreationDate", GenCreationDate)
        stream.WriteAttributeString("Version", "1.0")

        stream.WriteStartElement("TradingPartnerDirectory")
        stream.WriteStartElement("Sender")
        stream.WriteStartElement("TradingPartner")
        stream.WriteAttributeString("PartnerType", "Market Participant")
        stream.WriteElementString("CompanyName", CompanyName)
        stream.WriteElementString("CompanyIdentifier", CompanyIdentifier)
        stream.WriteEndElement()
        stream.WriteEndElement()
        stream.WriteStartElement("Recipient")
        stream.WriteStartElement("TradingPartner")
        stream.WriteAttributeString("PartnerType", "Distributor")
        stream.WriteElementString("CompanyName", "GRTN Bilateralista")
        stream.WriteElementString("CompanyIdentifier", "IDGRTNBI")
        stream.WriteEndElement()
        stream.WriteEndElement()
        stream.WriteEndElement()

        stream.WriteStartElement("PIPTransaction")
        stream.WriteStartElement("BilateralProgram")


        '
        ' Usa MP fittizio con valore sempre 1
        '
        stream.WriteAttributeString("MPN", "1")

        bFirst = True
        bProgramWithData = False

        Dim dvProgrammiOperatori As New DataView
        dvProgrammiOperatori.Table = dsProgrammiOperatori.ProgrammiOperatori
        dvProgrammiOperatori.Sort = "PrioritaBilanciamento"
        Dim progDRV As DataRowView

        For Each progDRV In dvProgrammiOperatori
            If bFirst Then
                stream.WriteElementString("CRN", progDRV.Item("CRN").ToString())
                stream.WriteElementString("Date", dataRicerca.ToString("yyyyMMdd"))
                stream.WriteElementString("Hour", oraRicerca.ToString())
                stream.WriteStartElement("Program")
                bFirst = False
            End If
            If Not (progDRV.Item("QtyMWh").ToString() = "") Then
                bProgramWithData = True
                stream.WriteStartElement("Qty")
                stream.WriteAttributeString("URN", progDRV.Item("CodiceUnitaSDC").ToString())
                ' stream.WriteString(Convert.ToString(progDRV.Item("QtyMWh"), culture))
                Dim qty As Single = DirectCast(progDRV.Item("QtyMWh"), Single)
                stream.WriteString(qty.ToString(culture))
                stream.WriteEndElement()
            End If
        Next

        ' For Each drProgrammiOperatori As DS_ProgrammiOperatori.ProgrammiOperatoriRow In dsProgrammiOperatori.ProgrammiOperatori
        ' If bFirst Then
        ' stream.WriteElementString("CRN", drProgrammiOperatori.CRN)
        ' stream.WriteElementString("Date", dataRicerca.ToString("yyyyMMdd"))
        ' stream.WriteElementString("Hour", oraRicerca.ToString())
        ' stream.WriteStartElement("Program")
        ' bFirst = False
        ' End If
        ' If Not (drProgrammiOperatori.IsQtyMWhNull()) Then
        ' bProgramWithData = True
        ' stream.WriteStartElement("Qty")
        ' stream.WriteAttributeString("URN", drProgrammiOperatori.CodiceUnitaSDC)
        ' stream.WriteString(Convert.ToString(drProgrammiOperatori.QtyMWh, culture))
        ' stream.WriteEndElement()
        ' End If
        ' Next
        stream.WriteEndElement()
        stream.WriteEndElement()
        stream.WriteEndElement()

        Return bProgramWithData
    End Function


#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents daProgrammiOperatori As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.cmdSelect = New System.Data.SqlClient.SqlCommand
        Me.daProgrammiOperatori = New System.Data.SqlClient.SqlDataAdapter
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=BILSVR2;packet size=4096;user id=bil_dbo;data source=BILSVR2;persi" & _
        "st security info=True;initial catalog=Bilaterali;password=bilaterali"
        '
        'cmdSelect
        '



		'Me.cmdSelect.CommandText = "SELECT Contratto.CRN, UnitaContratto.CodiceUnitaSDC, UnitaContratto.CategoriaUnit" & _
		'"aSDC, SDC_Unita.NomeUnita, SDC_Unita.TipoUnita, CASE TipoUnita WHEN 'P' THEN 0 W" & _
		'"HEN 'C' THEN - SDC_Unita.PotenzaMassimaMWh ELSE SDC_Unita.PotenzaMinimaMWh END A" & _
		'"S QtyMin, CASE TipoUnita WHEN 'P' THEN SDC_Unita.PotenzaMassimaMWh WHEN 'C' THEN" & _
		'" 0 ELSE SDC_Unita.PotenzaMassimaMWh END AS QtyMax, ProgrammaOrarioPerUnita.QtyMW" & _
		'"h, 0 AS PrioritaBilanciamento FROM tab_UnitaCOntratto2(@DataRicerca, @IdContratto) Unit" & _
		'"aContratto INNER JOIN Contratto ON Contratto.IdContratto = UnitaContratto.IdCont" & _
		'"ratto INNER JOIN SDC_Unita ON SDC_Unita.CodiceUnitaSDC = UnitaContratto.CodiceUn" & _
		'"itaSDC AND SDC_Unita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC LEFT O" & _
		'"UTER JOIN ProgrammaOrarioPerUnita ON ProgrammaOrarioPerUnita.IdContratto = Unita" & _
		'"Contratto.IdContratto AND ProgrammaOrarioPerUnita.CodiceUnitaSDC = UnitaContratt" & _
		'"o.CodiceUnitaSDC AND ProgrammaOrarioPerUnita.CategoriaUnitaSDC = UnitaContratto." & _
		'"CategoriaUnitaSDC AND ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca AND P" & _
		'"rogrammaOrarioPerUnita.PeriodoRilevante = @OraRicerca WHERE (UnitaContratto.IdCo" & _
		'"ntratto = @IdContratto) AND (UnitaContratto.TrCC = 1) AND (UnitaContratto.TrUC =" & _
		'" 1) AND (UnitaContratto.UnitaDelContrattoValidata = 1) AND (UnitaContratto.DataI" & _
		'"nizioValidita <= @DataRicerca) AND (UnitaContratto.DataFineValidita >= @DataRice" & _
		'"rca) AND (UnitaContratto.UnitaAssegnataOpCedente = @OpCedente) OR (UnitaContratt" & _
		'"o.IdContratto = @IdContratto) AND (UnitaContratto.TrCC = 1) AND (UnitaContratto." & _
		'"TrUC = 1) AND (UnitaContratto.UnitaDelContrattoValidata = 1) AND (UnitaContratto" & _
		'".DataInizioValidita <= @DataRicerca) AND (UnitaContratto.DataFineValidita >= @Da" & _
		'"taRicerca) AND (UnitaContratto.UnitaAssegnataOpAcquirente = @OpAcquirente) ORDER" & _
		'" BY UnitaContratto.CategoriaUnitaSDC, UnitaContratto.CodiceUnitaSDC"


		Dim q As String = ""
		q += " SELECT Contratto.CRN, UnitaContratto.CodiceUnitaSDC, UnitaContratto.CategoriaUnitaSDC, "
		q += " SDC_Unita.NomeUnita, SDC_Unita.TipoUnita, "
		q += " CASE TipoUnita WHEN 'P' THEN 0 WHEN 'C' THEN - SDC_Unita.PotenzaMassimaMWh ELSE SDC_Unita.PotenzaMinimaMWh END AS QtyMin, "
		q += " CASE TipoUnita WHEN 'P' THEN SDC_Unita.PotenzaMassimaMWh WHEN 'C' THEN 0   ELSE SDC_Unita.PotenzaMassimaMWh END AS QtyMax, "
		q += " ProgrammaOrarioPerUnita.QtyMWh, "
		q += " 0 AS PrioritaBilanciamento "
		q += " FROM tab_UnitaCOntratto2(@DataRicerca, @IdContratto) UnitaContratto "
		q += " INNER JOIN Contratto "
		q += " ON Contratto.IdContratto = UnitaContratto.IdContratto "
		q += " INNER JOIN SDC_Unita "
		q += " ON SDC_Unita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC "
		q += " AND SDC_Unita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC "
		q += " LEFT OUTER JOIN ProgrammaOrarioPerUnita "
		q += " ON ProgrammaOrarioPerUnita.IdContratto = UnitaContratto.IdContratto "
		q += " AND ProgrammaOrarioPerUnita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC "
		q += " AND ProgrammaOrarioPerUnita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC "
		q += " AND ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca AND ProgrammaOrarioPerUnita.PeriodoRilevante = @OraRicerca "
		q += " WHERE"
		q += " ("
		q += " (UnitaContratto.IdContratto = @IdContratto) "
		q += " AND (UnitaContratto.TrCC = 1) "
		q += " AND (UnitaContratto.TrUC = 1) "
		q += " AND (UnitaContratto.UnitaDelContrattoValidata = 1) "
		q += " AND (UnitaContratto.DataInizioValidita <= @DataRicerca)"
		q += " AND (UnitaContratto.DataFineValidita >= @DataRicerca) "
		q += " AND (UnitaContratto.UnitaAssegnataOpCedente = @OpCedente) "
		q += " )"
		q += " OR"
		q += " ("
		q += " (UnitaContratto.IdContratto = @IdContratto) "
		q += " AND (UnitaContratto.TrCC = 1) "
		q += " AND (UnitaContratto.TrUC = 1) "
		q += " AND (UnitaContratto.UnitaDelContrattoValidata = 1) "
		q += " AND (UnitaContratto.DataInizioValidita <= @DataRicerca)"
		q += " AND (UnitaContratto.DataFineValidita >= @DataRicerca) "
		q += " AND (UnitaContratto.UnitaAssegnataOpAcquirente = @OpAcquirente) "
		q += " )"
		q += " ORDER BY UnitaContratto.CategoriaUnitaSDC, UnitaContratto.CodiceUnitaSDC"
		Me.cmdSelect.CommandText = q



        Me.cmdSelect.Connection = Me.cn
        Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataRicerca", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
        Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OraRicerca", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
        Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "Expr6"))
        Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OpCedente", System.Data.SqlDbType.Bit, 1, "UnitaAssegnataOpCedente"))
        Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OpAcquirente", System.Data.SqlDbType.Bit, 1, "UnitaAssegnataOpAcquirente"))

        '
        'daProgrammiOperatori
        '
        Me.daProgrammiOperatori.SelectCommand = Me.cmdSelect
        Me.daProgrammiOperatori.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "UnitaContratto", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CRN", "CRN"), New System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"), New System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"), New System.Data.Common.DataColumnMapping("NomeUnita", "NomeUnita"), New System.Data.Common.DataColumnMapping("TipoUnita", "TipoUnita"), New System.Data.Common.DataColumnMapping("QtyMin", "QtyMin"), New System.Data.Common.DataColumnMapping("QtyMax", "QtyMax"), New System.Data.Common.DataColumnMapping("QtyMWh", "QtyMWh"), New System.Data.Common.DataColumnMapping("PrioritaBilanciamento", "PrioritaBilanciamento"), New System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"), New System.Data.Common.DataColumnMapping("Expr1", "Expr1"), New System.Data.Common.DataColumnMapping("Expr2", "Expr2"), New System.Data.Common.DataColumnMapping("DataProgramma", "DataProgramma"), New System.Data.Common.DataColumnMapping("Expr3", "Expr3"), New System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"), New System.Data.Common.DataColumnMapping("Expr4", "Expr4"), New System.Data.Common.DataColumnMapping("Expr5", "Expr5"), New System.Data.Common.DataColumnMapping("Expr6", "Expr6")})})

    End Sub

#End Region

End Class
