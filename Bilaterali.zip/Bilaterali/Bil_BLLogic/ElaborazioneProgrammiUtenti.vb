' Lettura dei programmi dagli operatori.
'
' 1) Inserimento del programma come blob nella tabella XmlProgrammiUtenti
' 2) Verifica del programma
' 2a) sort per CRN
' 2a) lettura di tutte le unita disponibili (per sapere se esiste l'unita` e se abilitata)
' 2b) lettura del record nella tabella Contratto partendo da CRN (esiste un indice in Contratto.CRN)
' 2c) se esiste il Contratto lettura delle UnitaContratto (per IdContratto)
' 2d) 
' 3) Per piptransaction lettura di ProgrammaOrario e ProgrammaOrarioPerUnita con lock su ProgrammaOrario
' 4) modifica o inserimento dei record.


Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema
Imports System.Web
Imports System.Threading
Imports SystemMonitor
Imports CertPInvokeLib



Public Class ElaborazioneProgrammiUtenti
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents daProgrammaOrario As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdInsertProgrammaOrario As System.Data.SqlClient.SqlCommand
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents cmdSelectProgrammaOrario As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdUpdateProgrammaOrario As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdInsertProgrammaOrarioPerUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdUpdateProgrammaOrarioPerUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdSelectProgrammaOrarioPerUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents daProgrammaOrarioPerUnita As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents daContratto As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdSelectContratto As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdSelectUnitaProgrammabili As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents daUnitaProgrammabili As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents spSessioneBilaterali_Fill As System.Data.SqlClient.SqlCommand
	Friend WithEvents spOnProgrammaOperatore As System.Data.SqlClient.SqlCommand
	Friend WithEvents spNuovoProgrammaNonIncrementale As System.Data.SqlClient.SqlCommand
    Friend WithEvents daUnitRelate As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelectUnitRelate As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdDeleteProgrammaOrarioPerUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdDeletePOUE As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.daProgrammaOrario = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdInsertProgrammaOrario = New System.Data.SqlClient.SqlCommand
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.cmdSelectProgrammaOrario = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdateProgrammaOrario = New System.Data.SqlClient.SqlCommand
		Me.cmdInsertProgrammaOrarioPerUnita = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdateProgrammaOrarioPerUnita = New System.Data.SqlClient.SqlCommand
		Me.cmdSelectProgrammaOrarioPerUnita = New System.Data.SqlClient.SqlCommand
		Me.daProgrammaOrarioPerUnita = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdDeleteProgrammaOrarioPerUnita = New System.Data.SqlClient.SqlCommand
		Me.daContratto = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSelectContratto = New System.Data.SqlClient.SqlCommand
		Me.cmdSelectUnitaProgrammabili = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
		Me.daUnitaProgrammabili = New System.Data.SqlClient.SqlDataAdapter
		Me.spSessioneBilaterali_Fill = New System.Data.SqlClient.SqlCommand
		Me.spOnProgrammaOperatore = New System.Data.SqlClient.SqlCommand
		Me.spNuovoProgrammaNonIncrementale = New System.Data.SqlClient.SqlCommand
		Me.daUnitRelate = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSelectUnitRelate = New System.Data.SqlClient.SqlCommand
		Me.cmdDeletePOUE = New System.Data.SqlClient.SqlCommand
		'
		'daProgrammaOrario
		'
		Me.daProgrammaOrario.InsertCommand = Me.cmdInsertProgrammaOrario
		Me.daProgrammaOrario.SelectCommand = Me.cmdSelectProgrammaOrario
		Me.daProgrammaOrario.UpdateCommand = Me.cmdUpdateProgrammaOrario
		'
		'cmdInsertProgrammaOrario
		'
		Me.cmdInsertProgrammaOrario.CommandText = "INSERT INTO dbo.ProgrammaOrario (IdContratto, DataProgramma, PeriodoRilevante, Bi" & _
		"lanciato, TSModifica, ProgrammaOrarioValidato) VALUES (@IdContratto, @DataProgra" & _
		"mma, @PeriodoRilevante, @Bilanciato, @TSModifica, @ProgrammaOrarioValidato)"
		Me.cmdInsertProgrammaOrario.Connection = Me.cn
		Me.cmdInsertProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
		Me.cmdInsertProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.cmdInsertProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		Me.cmdInsertProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Bilanciato", System.Data.SqlDbType.Bit, 1, "Bilanciato"))
		Me.cmdInsertProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdInsertProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammaOrarioValidato", System.Data.SqlDbType.Bit, 1, "ProgrammaOrarioValidato"))
		'
		'cn
		'
		Me.cn.ConnectionString = "packet size=4096;user id=bil_user;password=Bilaterali;data source=BILSVR1;persist" & _
		" security info=False;initial catalog=Bilaterali"
		'
		'cmdSelectProgrammaOrario
		'
		Me.cmdSelectProgrammaOrario.CommandText = "SELECT IdContratto, DataProgramma, Bilanciato, PeriodoRilevante, TSCalcoloBilanci" & _
		"amento, TSModifica, ProgrammaOrarioValidato, SbilanciamentoMWh FROM dbo.Programm" & _
		"aOrario WHERE (IdContratto = @IdContratto) AND (DataProgramma = @DataProgramma) " & _
		"AND (PeriodoRilevante = @PeriodoRilevante)"
		Me.cmdSelectProgrammaOrario.Connection = Me.cn
		Me.cmdSelectProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
		Me.cmdSelectProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.cmdSelectProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		'
		'cmdUpdateProgrammaOrario
		'
		Me.cmdUpdateProgrammaOrario.CommandText = "UPDATE dbo.ProgrammaOrario SET TSModifica = @TSModifica, ProgrammaOrarioValidato " & _
		"= @ProgrammaOrarioValidato WHERE (IdContratto = @IdContratto) AND (DataProgramma" & _
		" = @DataProgramma) AND (PeriodoRilevante = @PeriodoRilevante)"
		Me.cmdUpdateProgrammaOrario.Connection = Me.cn
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammaOrarioValidato", System.Data.SqlDbType.Bit, 1, "ProgrammaOrarioValidato"))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdInsertProgrammaOrarioPerUnita
		'
		Me.cmdInsertProgrammaOrarioPerUnita.CommandText = "INSERT INTO dbo.ProgrammaOrarioPerUnita (IdContratto, DataProgramma, PeriodoRilev" & _
		"ante, CodiceUnitaSDC, QtyMWh, ProgOrarioDellUnitaValidato, IdProgrammaXml, Categ" & _
		"oriaUnitaSDC, ProgressivoNelProgramma, QtyMWhBilanciamento, ProgrammatoDalCedent" & _
		"e) VALUES (@IdContratto, @DataProgramma, @PeriodoRilevante, @CodiceUnitaSDC, @Qt" & _
		"yMWh, @ProgOrarioDellUnitaValidato, @IdProgrammaXml, @CategoriaUnitaSDC, @Progre" & _
		"ssivoNelProgramma, @QtyMWhBilanciamento, @ProgrammatoDalCedente)"
		Me.cmdInsertProgrammaOrarioPerUnita.Connection = Me.cn
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@QtyMWh", System.Data.SqlDbType.Float, 8, "QtyMWh"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgOrarioDellUnitaValidato", System.Data.SqlDbType.Bit, 1, "ProgOrarioDellUnitaValidato"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdProgrammaXml", System.Data.SqlDbType.Int, 4, "IdProgrammaXml"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgressivoNelProgramma", System.Data.SqlDbType.Int, 4, "ProgressivoNelProgramma"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@QtyMWhBilanciamento", System.Data.SqlDbType.Float, 8, "QtyMWhBilanciamento"))
		Me.cmdInsertProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammatoDalCedente", System.Data.SqlDbType.Bit, 1, "ProgrammatoDalCedente"))
		'
		'cmdUpdateProgrammaOrarioPerUnita
		'
		Me.cmdUpdateProgrammaOrarioPerUnita.CommandText = "UPDATE ProgrammaOrarioPerUnita SET QtyMWh = @QtyMWh, ProgOrarioDellUnitaValidato " & _
		"= @ProgOrarioDellUnitaValidato, ProgressivoNelProgramma = @ProgressivoNelProgram" & _
		"ma, QtyMWhBilanciamento = @QtyMWhBilanciamento, ProgrammatoDalCedente = @Program" & _
		"matoDalCedente, IdProgrammaXml = @IdProgrammaXml WHERE (IdContratto = @IdContrat" & _
		"to) AND (DataProgramma = @DataProgramma) AND (PeriodoRilevante = @PeriodoRilevan" & _
		"te) AND (CodiceUnitaSDC = @CodiceUnitaSDC) AND (CategoriaUnitaSDC = @CategoriaUn" & _
		"itaSDC)"
		Me.cmdUpdateProgrammaOrarioPerUnita.Connection = Me.cn
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@QtyMWh", System.Data.SqlDbType.Float, 8, "QtyMWh"))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgOrarioDellUnitaValidato", System.Data.SqlDbType.Bit, 1, "ProgOrarioDellUnitaValidato"))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgressivoNelProgramma", System.Data.SqlDbType.Int, 4, "ProgressivoNelProgramma"))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@QtyMWhBilanciamento", System.Data.SqlDbType.Float, 8, "QtyMWhBilanciamento"))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammatoDalCedente", System.Data.SqlDbType.Bit, 1, "ProgrammatoDalCedente"))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdProgrammaXml", System.Data.SqlDbType.Int, 4, "IdProgrammaXml"))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdSelectProgrammaOrarioPerUnita
		'
		Me.cmdSelectProgrammaOrarioPerUnita.CommandText = "SELECT IdContratto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUni" & _
		"taSDC, QtyMWh, ProgOrarioDellUnitaValidato, IdProgrammaXml, ProgressivoNelProgra" & _
		"mma, QtyMWhBilanciamento, QtyMWhAssegnataMGP, ProgrammatoDalCedente FROM dbo.Pro" & _
		"grammaOrarioPerUnita WHERE (DataProgramma = @DataProgramma) AND (IdContratto = @" & _
		"IdContratto) AND (PeriodoRilevante = @PeriodoRilevante)"
		Me.cmdSelectProgrammaOrarioPerUnita.Connection = Me.cn
		Me.cmdSelectProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.cmdSelectProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
		Me.cmdSelectProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		'
		'daProgrammaOrarioPerUnita
		'
		Me.daProgrammaOrarioPerUnita.DeleteCommand = Me.cmdDeleteProgrammaOrarioPerUnita
		Me.daProgrammaOrarioPerUnita.InsertCommand = Me.cmdInsertProgrammaOrarioPerUnita
		Me.daProgrammaOrarioPerUnita.SelectCommand = Me.cmdSelectProgrammaOrarioPerUnita
		Me.daProgrammaOrarioPerUnita.UpdateCommand = Me.cmdUpdateProgrammaOrarioPerUnita
		'
		'cmdDeleteProgrammaOrarioPerUnita
		'
		Me.cmdDeleteProgrammaOrarioPerUnita.CommandText = "DELETE FROM ProgrammaOrarioPerUnita WHERE (IdContratto = @IdContratto) AND (DataP" & _
		"rogramma = @DataProgramma) AND (PeriodoRilevante = @PeriodoRilevante) AND (Codic" & _
		"eUnitaSDC = @CodiceUnitaSDC) AND (CategoriaUnitaSDC = @CategoriaUnitaSDC)"
		Me.cmdDeleteProgrammaOrarioPerUnita.Connection = Me.cn
		Me.cmdDeleteProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDeleteProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDeleteProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDeleteProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDeleteProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'daContratto
		'
		Me.daContratto.SelectCommand = Me.cmdSelectContratto
		'
		'cmdSelectContratto
		'
		Me.cmdSelectContratto.CommandText = "SELECT IdContratto, DataInizioValidita, DataFineValidita, CRN, CodiceOperatoreSDC" & _
		", CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivile" & _
		"giata, StatoContratto, TrCN FROM dbo.Contratto WHERE (CRN = @CRN)"
		Me.cmdSelectContratto.Connection = Me.cn
		Me.cmdSelectContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"))
		'
		'cmdSelectUnitaProgrammabili
		'
		Me.cmdSelectUnitaProgrammabili.CommandText = "SELECT Unita.CodiceUnitaSDC, Unita.CategoriaUnitaSDC, Unita.StatoBilateraliUnita," & _
		" SDC_Unita.Abilitata FROM Unita INNER JOIN SDC_Unita ON Unita.CodiceUnitaSDC = S" & _
		"DC_Unita.CodiceUnitaSDC AND Unita.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSD" & _
		"C"
		Me.cmdSelectUnitaProgrammabili.Connection = Me.cn
		'
		'daUnitaProgrammabili
		'
		Me.daUnitaProgrammabili.DeleteCommand = Me.SqlDeleteCommand1
		Me.daUnitaProgrammabili.InsertCommand = Me.SqlInsertCommand1
		Me.daUnitaProgrammabili.SelectCommand = Me.cmdSelectUnitaProgrammabili
		Me.daUnitaProgrammabili.UpdateCommand = Me.SqlUpdateCommand1
		'
		'spSessioneBilaterali_Fill
		'
		Me.spSessioneBilaterali_Fill.CommandText = "dbo.[spSessioneBilaterali_Fill]"
		Me.spSessioneBilaterali_Fill.CommandType = System.Data.CommandType.StoredProcedure
		Me.spSessioneBilaterali_Fill.Connection = Me.cn
		Me.spSessioneBilaterali_Fill.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spSessioneBilaterali_Fill.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgrammaMin", System.Data.SqlDbType.DateTime, 8))
		Me.spSessioneBilaterali_Fill.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgrammaMax", System.Data.SqlDbType.DateTime, 8))
		'
		'spOnProgrammaOperatore
		'
		Me.spOnProgrammaOperatore.CommandText = "dbo.[spOnProgrammaOperatore]"
		Me.spOnProgrammaOperatore.CommandType = System.Data.CommandType.StoredProcedure
		Me.spOnProgrammaOperatore.Connection = Me.cn
		Me.spOnProgrammaOperatore.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spOnProgrammaOperatore.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		'
		'spNuovoProgrammaNonIncrementale
		'
		Me.spNuovoProgrammaNonIncrementale.CommandText = "dbo.[spNuovoProgrammaNonIncrementale]"
		Me.spNuovoProgrammaNonIncrementale.CommandType = System.Data.CommandType.StoredProcedure
		Me.spNuovoProgrammaNonIncrementale.Connection = Me.cn
		Me.spNuovoProgrammaNonIncrementale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spNuovoProgrammaNonIncrementale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me.spNuovoProgrammaNonIncrementale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.spNuovoProgrammaNonIncrementale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1))
		Me.spNuovoProgrammaNonIncrementale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IsOpCedente", System.Data.SqlDbType.TinyInt, 1))
		Me.spNuovoProgrammaNonIncrementale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IsOpAcquirente", System.Data.SqlDbType.TinyInt, 1))
		'
		'daUnitRelate
		'
		Me.daUnitRelate.SelectCommand = Me.cmdSelectUnitRelate
		Me.daUnitRelate.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "UnitRelate", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"), New System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"), New System.Data.Common.DataColumnMapping("DataInizioValidita", "DataInizioValidita"), New System.Data.Common.DataColumnMapping("DataFineValidita", "DataFineValidita"), New System.Data.Common.DataColumnMapping("TipoUnita", "TipoUnita"), New System.Data.Common.DataColumnMapping("PotenzaMassimaMWh", "PotenzaMassimaMWh"), New System.Data.Common.DataColumnMapping("PotenzaMinimaMWh", "PotenzaMinimaMWh"), New System.Data.Common.DataColumnMapping("TrUC", "TrUC"), New System.Data.Common.DataColumnMapping("Abilitata", "Abilitata")})})
		'
		'cmdSelectUnitRelate
		'
		Me.cmdSelectUnitRelate.CommandText = "SELECT UnitRelate.CodiceOperatoreSDC, UnitRelate.CodiceUnitaSDC, UnitRelate.Categ" & _
		"oriaUnitaSDC, UnitRelate.DataInizioValidita, UnitRelate.DataFineValidita, SDC_Un" & _
		"ita.TipoUnita, SDC_Unita.PotenzaMassimaMWh, SDC_Unita.PotenzaMinimaMWh, UnitRela" & _
		"te.TrUC, UnitRelate.VUC AS Abilitata FROM UnitRelate INNER JOIN SDC_Unita ON Uni" & _
		"tRelate.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC AND UnitRelate.CategoriaUnitaS" & _
		"DC = SDC_Unita.CategoriaUnitaSDC WHERE (UnitRelate.CodiceOperatoreSDC = @Operato" & _
		"re) AND (UnitRelate.Abilitata = 1)"
		Me.cmdSelectUnitRelate.Connection = Me.cn
		Me.cmdSelectUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Operatore", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		'
		'cmdDeletePOUE
		'
		Me.cmdDeletePOUE.CommandText = "DELETE FROM ProgrammaOrarioPerUnitaErrori WHERE (IdContratto = @IdContratto) AND " & _
		"(DataProgramma = @DataProgramma) AND (PeriodoRilevante = @PeriodoRilevante) "

		Me.cmdDeletePOUE.Connection = Me.cn
		Me.cmdDeletePOUE.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDeletePOUE.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDeletePOUE.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
	End Sub

#End Region

	' Funzione che viene chiamata quando un operatore sottomette un programma
	' la funzione avvia i primi controlli per poi lanciare un thread per l'elaborazione finale.
	Public Function ElaboraFile( _
	 ByVal codOperatoreSDC As String, _
	 ByVal codiceUtenteSDC As String, _
	 ByVal pathFileXml As String, ByVal fileXML As Byte(), ByVal bInputFirmato As Boolean, _
	 ByVal DateTimeInvio As DateTime, _
	 ByRef out_IdProgrammaXML As Integer) As String



		cn.ConnectionString = GetConnectionString()

		' i dati in ingresso sono copiati in ElaboraFileData
		' insieme a tutti i dati che servono per l'elaborazione

		Dim td As New ElaboraFileData
		If True Then

			td.codOperatoreSDC = codOperatoreSDC
			td.codiceUtenteSDC = codiceUtenteSDC
			td.pathFileXml = pathFileXml
			td.fileXML = fileXML
			td.DateTimeInvio = DateTimeInvio
			td.result = ""
			' Flag per la sicurezza
			td.certificatoFirma = Nothing
			td.bInputFirmatoXML = bInputFirmato			 'questo flag indica se il file in ingresso e` firmato o no
			td.bControfirmaXML = AppSettingToBoolean("XMLOutput_Controfirma_PKCS7")			 ' questo flag indica se e` necessario apportare la controfirma

			smTrace(String.Format("Elaborazione PGM {0} : inviato da operatore={1} utente={2}", td.idElaboarazione, codOperatoreSDC, codiceUtenteSDC))


			' la data del mercato e` DOMANI
			If (True) Then
				Dim tDomani As DateTime = DateTime.Now.AddDays(1)
				' tolgo hh:mm:ss
				td.DateMGPPiuUno = New DateTime(tDomani.Year, tDomani.Month, tDomani.Day)
			End If


			' ora di accettazione max dei programmi che si riferiscono a domani
			td.AcceptTimeNormal = New TimeSpan(10, 0, 0)
			Try
				Dim s As String = ConfigurationSettings.AppSettings("ScadenzaAccettazioneProgrammi")
				' TimeSpan.Parse accetta sempre e solo il formato hh:mm:ss
				td.AcceptTimeNormal = TimeSpan.Parse(s)
			Catch ex As Exception
				SmLog.smError(ex, "Elaborazione PGM: file di configurazione campo ScadenzaAccettazioneProgrammi")
			End Try

			' ora di accettazione max dei programmi privilegiati che si riferiscono a domani
			td.AcceptTimePrivilegiato = New TimeSpan(12, 0, 0)
			Try
				Dim s As String = ConfigurationSettings.AppSettings("ScadenzaAccettazioneProgrammiPrivilegiati")
				' TimeSpan.Parse accetta sempre e solo il formato hh:mm:ss
				td.AcceptTimePrivilegiato = TimeSpan.Parse(s)
			Catch ex As Exception
				SmLog.smError(ex, "Elaborazione PGM: file di configurazione campo ScadenzaAccettazioneProgrammiPrivilegiati")
			End Try

		End If


		' ho finito di valorizzare tutti i parametri in ingresso in "td".
		' lancio l'elaborazione vera e propria.
		' prima fase: elaboarazione bloccante.
		' il risultato e` in td.result.
		ElaboraFileFase1(td)

		' qui ho l'id del file del programma inviato dall'operatore.
		' Questo id viene ritornato al chiamante in modo che l'operatore abbia 
		' un id univoco di "ricevuta" del file inviato
		out_IdProgrammaXML = td.pd.IdProgrammaXml

		' se c'e` stato un errore catastrofico ritorno con errore.
		If td.result <> String.Empty Then
			smError(String.Format("Elaborazione PGM {0}: errore grave {1}", td.idElaboarazione, td.result))
			Return td.result
		End If

		If cn.State = ConnectionState.Open Then cn.Close()

		' seconda fase: elaborazione batch.
		BatchSerializer.BS.AddBatch(AddressOf ElaborazioneProgrammiUtenti.ElaboraFileFase2Async, td, "PGMIN", "PGMIN: op " + td.codOperatoreSDC, DateTime.MinValue, "")

		smTrace(String.Format("Elaborazione PGM {0}: idProgrammaXML={1}. Lanciata la fase batch", td.idElaboarazione, out_IdProgrammaXML))
		Return ""

	End Function


	Private Sub ElaboraFileFase1(ByVal td As ElaboraFileData)

		Dim xmlControfirma() As Byte = Nothing
		Dim xmlOriginalXML() As Byte = Nothing

		' STR 258 - se arriva un file vuoto, mi fermo.
		If td.fileXML.Length = 0 Then
			td.pd.SetError("VAL701", "Errore: il file di programma e` vuoto.")
		End If

		If td.pd.Valid Then
			' se il sito e` predisposto per la firma digitale
			If AppSettingToBoolean("RichiediProgrammiFirmati") Then
				' Controllo se il file in ingresso e` firmato
				If td.bInputFirmatoXML = False Then
					td.pd.SetError("VAL700", "Errore: il programma deve essere firmato in PKCS7.")
				End If
			End If
		End If

		If td.pd.Valid Then

			If td.bInputFirmatoXML Then
				' Verifica della firma

				' Lo stream in arrivo e' un bytearray PKCS7 binario
				' Se lo stream e` valido estraggo il file originale.
				Dim errMsg As String
				If VerificaInputPKCS7(td.fileXML, errMsg) = False Then
					td.pd.SetError("VAL500", "Errore: Messaggio = " + errMsg + " durante la fase di verifica della firma. Per rendere operativo il programma, l'operatore deve ripresentare il programma firmato PKCS7.")
				Else
					xmlOriginalXML = EstraiDaInputPKCS7(td.fileXML, td.certificatoFirma)
					If xmlOriginalXML Is Nothing Then
						td.pd.SetError("VAL501", "Errore durante estrazione dati da PKCS7. Per rendere operativo il programma, l'operatore deve ripresentare il programma firmato PKCS7.")

					End If
					If td.certificatoFirma Is Nothing Then
						td.pd.SetError("VAL502", "Errore durante estrazione certificato firma da PKCS7. Per rendere operativo il programma, l'operatore deve ripresentare il programma firmato PKCS7.")
					End If
				End If
			Else
				' lo stream e` in chiaro (non firmato)
				xmlOriginalXML = td.fileXML
			End If

			' Controfirma
			If td.bControfirmaXML AndAlso td.result = String.Empty Then
				xmlControfirma = ControFirma(td.fileXML)
				If xmlControfirma Is Nothing Then
					td.result = "Errore durante la controfirma. Verifica configurazione certificati"
					SmLog.smError(String.Format("Elaborazione PGM {0}: errore nella fase di controfirma", td.idElaboarazione))
					Return					  ' e` un errore di configurazione
				End If
			Else
				xmlControfirma = td.fileXML
			End If
		Else
			xmlOriginalXML = td.fileXML
			xmlControfirma = td.fileXML
		End If

		' In caso di firma digitale
		' ho in xmlOriginalXML il file originale in ingresso,
		' ho in xmlControfirma il file controfirmato
		' Senza firma digitale
		' ho in xmlOriginalXML e in xmlControfirma il file originale in ingresso

		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			' memorizzo l'xml in arrivo nel db
			Try
				' se e` prevista la controfirma memorizzo nel db il file controfirmato
				' altrimenti memorizzo il file cosi` come e` arrivato.
				td.pd.IdProgrammaXml = InserisciRigaInXmlProgrammiUtenti(cn, td.codiceUtenteSDC, td.codOperatoreSDC, td.pathFileXml, xmlControfirma, td.DateTimeInvio, td.certificatoFirma)
				SmLog.smTrace(String.Format("Elaborazione PGM {0}: assegnato IdProgrammaXml={1}", td.idElaboarazione, td.pd.IdProgrammaXml))

			Catch ex As Exception
				SmLog.smError(ex, String.Format("Elaborazione PGM {0}: errore nella fase di memorizzazione del file nel DB", td.idElaboarazione))
				' che brutta cosa.... forse e` meglio ritornare subito
				td.result = "Errore durante la fase di inserimento del programma. Per rendere operativo il programma, l'operatore deve ripresentare il programma."
			End Try

			' ho memorizzato il file nel DB
			' Ora mi dedico alla lettura del file e validazione dello schema.

			If td.pd.Valid Then
				' riporto il file in chiaro per poterlo leggere.
				td.fileXML = xmlOriginalXML
				Try
					' validazione schema
					' qui si popola Me.datiXml con la lista delle PIPTransaction nel file
					' e si fa una validazione sintattica dei campi
					Dim pr As BilateralProgramReader = New BilateralProgramReader(td.pd)
					pr.LeggiXmlEtVerificaSchema(td.codOperatoreSDC, td.codiceUtenteSDC, td.pathFileXml, td.fileXML, td.DateMGPPiuUno, td.AcceptTimeNormal, td.AcceptTimePrivilegiato, td.DateTimeInvio)

					' dato che in seguito la lista delle transazioni verra` sortata
					' creo una lista parallela che non si sortera' mai e che verra` utilizzata
					' per scrivere l'FA
					td.pd.FreezeTansactionList()

				Catch ex As Exception
					' se arriva qui e` un errore catastrofico
					td.pd.SetError("VAL502", "Errore di validazione XML: " + ex.Message)
					smError(ex, String.Format("Elaborazione PGM {0}", td.idElaboarazione))
				End Try
			End If

			If (td.pd.Valid) Then
				If (td.pd.xmlPIPTransaction.Count = 0) Then
					td.pd.SetError("VAL503", "Il file non contiene transazioni.")
				End If
			End If

			' quando si arriva qui il file e` stato letto e vrificato nello schema.
			' In td.pd ho il file letto

		Catch ex As Exception
			SmLog.smError(ex, String.Format("Elaborazione PGM {0}: connessione al db fallita", td.idElaboarazione))
			td.result = "Connessione al DB non disponibile. Per rendere operativo il programma, l'operatore deve ripresentare il programma."
			Return
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Sub

	Private Sub ElaboraFileFase2(ByVal td As ElaboraFileData)

		Try

			SmLog.smTrace(String.Format("Elaborazione PGM {0}: inizio fase batch", td.idElaboarazione))

			cn.ConnectionString = GetConnectionString()
			cn.Open()

			'
			' Store certificato se input firmato PKCS7
			' e verifica completa (compresa CRL)
			'
			If td.pd.Valid Then
				If td.bInputFirmatoXML Then
					If Not (td.certificatoFirma Is Nothing) Then

						'
						' ottengo i dati del certificato utilizzato dal cliente per la firma del programma
						'
						Dim issuer As String = td.certificatoFirma.GetIssuerName()
						Dim serialNumber As String = td.certificatoFirma.GetSerialNumberString()
						Dim errorString As String
						Dim errorCode As String

						Dim dTarget As DateTime = DateTime.Now

						' controllo se il certficato e` valido.
						' Se il certificato non e` valido segno errore e non continuo l'elaborazione
						Dim certMgr As New Bil_Crypt.CertificateManager
						errorString = certMgr.CheckCertificate(issuer, serialNumber, td.codiceUtenteSDC, dTarget, Bil_Crypt.CertificateManager.ControllaScadenzaCertificato.Si)
						If errorString <> String.Empty Then
							errorCode = errorString.Substring(0, 4)
							td.pd.SetError(errorCode, errorString)
						End If
					End If
				End If
			End If

			If td.pd.Valid Then

				' il programma e` valido, in formato corretto e il suo certificato e` valido

				Try
					' validazione del contenuto del file;
					' qui si controllano i contratti, le unita` specificate nel file ecc.
					VerificaDatiXmlNelDB(td.pd, td.DateMGPPiuUno, td.AcceptTimeNormal, td.AcceptTimePrivilegiato, td.DateTimeInvio)
				Catch ex As Exception
					SmLog.smError(ex, String.Format("Elaborazione PGM {0}: e` necessario ripresentare il programma", td.idElaboarazione))
					td.result = "Errore nella fase 2 della validazione . Per rendere operativo il programma, l'operatore deve ripresentare il programma."
					Return
				End Try
			End If


			If td.pd.Valid Then
				Try
					' inserimento del programma nel DB

					Dim AccettazioneIncrementaleProgrammi As Boolean = AppSettingToBoolean("AccettazioneIncrementaleProgrammi", False)
					Me.InsertPrograms(td.pd, AccettazioneIncrementaleProgrammi)

				Catch ex As Exception
					SmLog.smError(ex, String.Format("Elaborazione PGM {0}: Impossibile salvare tutto il programma nel data base. Per rendere operativo il programma, l'operatore deve ripresentare il programma.", td.idElaboarazione))
					td.result = "Impossibile salvare tutto il programma nel data base. Per rendere operativo il programma, l'operatore deve ripresentare il programma."
					Return
				End Try
			End If

			' Elaborazione del file terminata
			' Ora si produce l'FA

			SmLog.smTrace(String.Format("Elaborazione PGM {0}: inizio costruzione FA", td.idElaboarazione))

			' l'FA si ottiene sempre (a meno che non ci siano abbastanza dati nel file)
			Dim ms As New MemoryStream

			Dim bFA As Boolean
			Dim idFileFa As String
			Try
				Dim xw As XmlTextWriter = New XmlTextWriter(ms, Encoding.UTF8)

				bFA = td.pd.WriteFA(xw, idFileFa, td.codOperatoreSDC)
			Catch ex As Exception
				SmLog.smError(ex, String.Format("Elaborazione PGM {0}: errore nella generazione del FA", td.idElaboarazione))
				bFA = False
			End Try

			If (bFA) Then
				' ho prodotto l'FA

				' Nome del file del programma in ingresso
				Dim fileNameProgramma As String = System.IO.Path.GetFileNameWithoutExtension(td.pathFileXml)

				' Costruisco il nome del file FA prodotto (senza .zip)
				Dim strFAFileName As String = GetFAFileName(fileNameProgramma, idFileFa)

				' Inserisco l'FA nella DB
				' questa chiamata fa lo zip del file
				InserisciFAInXmlProgrammiUtenti(cn, td.pd, ms.ToArray(), strFAFileName, td.codOperatoreSDC, "utf-8")

				SmLog.smTrace(String.Format("Elaborazione PGM {0}: FA generato={1}", td.idElaboarazione, strFAFileName))
			End If

			td.result = ""

		Catch ex As Exception
			SmLog.smError(ex, String.Format("Elaborazione PGM {0}: ElaboraFileFase2", td.idElaboarazione))
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Sub


	Private Shared Sub ElaboraFileFase2Async(ByVal obj As Object)
		Dim td As ElaboraFileData = DirectCast(obj, ElaboraFileData)
		Dim bl As New ElaborazioneProgrammiUtenti
		bl.ElaboraFileFase2(td)
		bl.Dispose()
	End Sub

	Public Function RichiediProgrammiFirmati() As Boolean
		Return AppSettingToBoolean("RichiediProgrammiFirmati")
	End Function

#Region "classe che contiene i dati del programma in ingresso"
	Class PIPEDocument

		Public Sub New(ByVal idElaborazione As Guid)
			Me._idElaborazione = idElaborazione
		End Sub

		Public Sub SetError(ByVal code As String, ByVal msg As String)
			Me.mErrorCode = code
			Me.mErrorMessage = msg
			SmLog.smError(String.Format("Elaborazione PGM {0} - IdProgrammaXML={1} {2}: {3}", idElaborazione, IdProgrammaXml, code, msg))
		End Sub

		Private _idElaborazione As Guid
		Public ReadOnly Property idElaborazione() As Guid
			Get
				Return _idElaborazione
			End Get
		End Property

		Public xmlSender_CompanyName As String
		Public xmlSender_CompanyIdentifier As String
		Public xmlSender_PartnerType As String

		Public xmlPIPTransaction As New ArrayList
		Private xmlOriginalPIPTransaction As ArrayList

		Public IdProgrammaXml As Integer = -1
		Public ReferenceNumber As String

		Private mErrorCode As String
		Private mErrorMessage As String

		Public ReadOnly Property Valid() As Boolean
			Get
				Return mErrorCode Is Nothing
			End Get
		End Property

		Public Sub FreezeTansactionList()
			xmlOriginalPIPTransaction = DirectCast(xmlPIPTransaction.Clone(), ArrayList)
		End Sub

		Public Function WriteFA(ByVal w As XmlTextWriter, ByRef idGenerato As String, ByVal codiceOperatoreSDC As String) As Boolean
			Dim operatoreValido As Boolean
			If Me.xmlSender_CompanyIdentifier Is Nothing Then
				operatoreValido = False
			ElseIf codiceOperatoreSDC <> Me.xmlSender_CompanyIdentifier Then
				operatoreValido = False
			Else
				operatoreValido = True
			End If


			w.Formatting = Formatting.Indented
			w.IndentChar = "	"c			 ' e` un tab
			w.Indentation = 1
			w.WriteStartDocument()

			Dim CreationDate As String = String.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now)

			Dim status As String
			If (Me.Valid = False) Then
				status = "Reject"
			Else
				Dim v As Integer = 0
				For Each p As ElaborazioneProgrammiUtenti.PIPTransaction In Me.xmlOriginalPIPTransaction
					If (p.Valid) Then v += 1
				Next
				If (v > 0 AndAlso v = Me.xmlPIPTransaction.Count) Then
					status = "Accept"
				ElseIf (v = 0) Then
					status = "Reject"
				Else
					status = "Partial"
				End If
			End If

			w.WriteStartElement("PIPEFunctionalAcknowledgement")
			If True Then
				idGenerato = NewId30.Generate()
				' non e` detto che si riesca a capire il sender (chi ha mandato il file dei programmi)
				w.WriteAttributeString("xmlns", "urn:XML-PIPE")
				w.WriteAttributeString("xmlns", "xsi", Nothing, "http://www.w3.org/2001/XMLSchema-instance")
				w.WriteAttributeString("xsi", "schemaLocation", Nothing, "urn:XML-PIPE PIPEFunctionalAcknowledgementv1_0.xsd")
				w.WriteAttributeString("ReferenceNumber", idGenerato)				  'generato a caso (35char)
				w.WriteAttributeString("OriginalReferenceNumber", Me.ReferenceNumber)				   ' ReferenceNumber del documento di programmazione dei bilaterali (35char)

				w.WriteAttributeString("Status", status)				  ' Partial=>alcune PIP transaction rifiutate. Accept=>tutto ok. Reject=>tutto non ok
				w.WriteAttributeString("CreationDate", CreationDate)				  'YYYMMDDhhmmss
				w.WriteAttributeString("Version", "1.0")

				w.WriteStartElement("TradingPartnerDirectory")
				If (True) Then
					' da file di configurazione
					w.WriteStartElement("Sender")
					If (True) Then
						w.WriteStartElement("TradingPartner")
						w.WriteAttributeString("PartnerType", "Operator")
						If True Then
							w.WriteStartElement("CompanyName")

							'
							' FA da sistema NAB (GRTN Bilateralista e' controparte) 
							'
							w.WriteString("GRTN Bilateralista")
							w.WriteEndElement()

							w.WriteStartElement("CompanyIdentifier")

							'
							' FA da sistema NAB (IDGRTNBI e' identificativo controparte)
							'
							w.WriteString("IDGRTNBI")
							w.WriteEndElement()
						End If
						w.WriteEndElement()
					End If
					w.WriteEndElement()

					w.WriteStartElement("Recipient")
					If True Then
						w.WriteStartElement("TradingPartner")

						If Not Me.xmlSender_PartnerType Is Nothing Then
							w.WriteAttributeString("PartnerType", Me.xmlSender_PartnerType)							 ' da leggere dal sender
						Else
							w.WriteAttributeString("PartnerType", "")							 ' in caso di errore ci devo pur mettere qualcosa
						End If

						If True Then
							w.WriteStartElement("CompanyName")
							If Not Me.xmlSender_CompanyName Is Nothing Then
								w.WriteString(Me.xmlSender_CompanyName)								   ' da leggere dal sender
							End If
							w.WriteEndElement()

							w.WriteStartElement("CompanyIdentifier")
							w.WriteString(codiceOperatoreSDC)
							w.WriteEndElement()
						End If
						w.WriteEndElement()
					End If
					w.WriteEndElement()
				End If
				w.WriteEndElement()

				If (Me.Valid = False) Then
					' ci sono errori globali al file
					w.WriteStartElement("TransactionAcknowledgement")
					w.WriteAttributeString("Status", "Reject")
					w.WriteAttributeString("PIPTransactionType", "BilateralProgram")
					w.WriteStartElement("RejectInformation")
					If True Then
						w.WriteStartElement("Reason")
						w.WriteString(Me.mErrorCode)						   ' codice di errore
						w.WriteEndElement()

						w.WriteStartElement("ReasonText")
						w.WriteString(Me.mErrorMessage)						   ' potenzialmente multilingua
						w.WriteEndElement()
					End If
					w.WriteEndElement()
				Else
					' do gli errori (o i positivi) delle transazioni
					For Each p As ElaborazioneProgrammiUtenti.PIPTransaction In Me.xmlOriginalPIPTransaction

						If p.Valid Then
							w.WriteStartElement("TransactionAcknowledgement")
							w.WriteAttributeString("Status", "Accept")
							w.WriteAttributeString("PIPTransactionType", "BilateralProgram")
							w.WriteAttributeString("OriginalReferenceNumber", p.ReferenceNumber)							   ' Id assegnato dal sistema alla PIPTransaction
							If Not p.xmlMPN Is Nothing AndAlso p.xmlMPN <> String.Empty Then
								w.WriteAttributeString("MarketParticipantNumber", p.xmlMPN)								 ' MPN che identifica la PIPTransaction del programma in
							End If
							w.WriteEndElement()
						Else
							w.WriteStartElement("TransactionAcknowledgement")
							w.WriteAttributeString("Status", "Reject")
							w.WriteAttributeString("PIPTransactionType", "BilateralProgram")
							w.WriteAttributeString("OriginalReferenceNumber", p.ReferenceNumber)
							If Not p.xmlMPN Is Nothing AndAlso p.xmlMPN <> String.Empty Then
								w.WriteAttributeString("MarketParticipantNumber", p.xmlMPN)								  ' MPN che identifica la PIPTransaction del programma in
							End If

							If True Then
								w.WriteStartElement("RejectInformation")
								w.WriteStartElement("Reason")
								w.WriteString(p.mErrorCode)								 ' codice di errore
								w.WriteEndElement()

								w.WriteStartElement("ReasonText")
								w.WriteString(p.mErrorMessage)								 ' potenzialmente multilingua
								w.WriteEndElement()
								w.WriteEndElement()
							End If
							w.WriteEndElement()
						End If

					Next
				End If
			End If


			w.WriteEndDocument()
			w.Flush()
			w.Close()
			Return True
		End Function

	End Class
#End Region

#Region "classi di appoggio"
	' classe per contenere i dati di una PIPTransaction
	' i dati che iniziano per xml sono letti dal file XML
	' dbIdContratto viene assegnato quanto si verifica che il CRN e` associato ad un contratto
	' Valid e` true quando e` la verifica e` andata a buon fine
	Class PIPTransaction
		Public Sub New(ByVal pd As PIPEDocument)
			Me.pd = pd

			Me.dbIdContratto = Nothing

			Me.ReferenceNumber = NewId30.Generate()
			Me.xmlCRN = Nothing
			Me.xmlData = DateTime.MinValue
			Me.xmlHour = Nothing
			Me.xmlMPN = Nothing
		End Sub

		Private ReadOnly pd As PIPEDocument


		Public Sub SetIdContratto(ByVal idContratto As Integer)
			Me.dbIdContratto = idContratto
		End Sub

		Public Sub SetError(ByVal code As String, ByVal msg As String)
			Me.mErrorCode = code
			Me.mErrorMessage = msg

			If Me.xmlMPN Is Nothing Then
				SmLog.smError(String.Format("Elaborazione PGM {0} IdProgrammaXml={1} - {2}: {3}", Me.pd.idElaborazione, Me.pd.IdProgrammaXml, code, msg))
			Else
				SmLog.smError(String.Format("Elaborazione PGM {0} IdProgrammaXml={1} - MPN='{2}' {3}: {4}", Me.pd.idElaborazione, Me.pd.IdProgrammaXml, xmlMPN, code, msg))
			End If
		End Sub

		Public ReadOnly Property Valid() As Boolean
			Get
				Return mErrorCode Is Nothing
			End Get
		End Property


		Public ReadOnly ReferenceNumber As String
		Public xmlCRN As String
		Public xmlData As DateTime
		Public xmlHour As Byte
		Public xmlMPN As String

		Public mErrorCode As String
		Public mErrorMessage As String

		Public dbIdContratto As Integer = -1

		Public IsOperatoreCedente As Boolean = False
		Public IsOperatoreAcquirente As Boolean = False

		Private URNList As New ArrayList

		Public ReadOnly Property URNListCount() As Integer
			Get
				Return Me.URNList.Count
			End Get
		End Property

		Public ReadOnly Property IdContratto() As Integer
			Get
				Return Me.dbIdContratto
			End Get
		End Property

		Public Sub AddURN(ByVal urn As URNData)
			Me.URNList.Add(urn)
		End Sub

		Public Function URNCount() As Integer
			Return Me.URNList.Count
		End Function


		Public Function GetURN(ByVal i As Integer) As URNData
			Return DirectCast(Me.URNList(i), URNData)
		End Function

	End Class

	Class URNData
		Public Sub New(ByVal urn As String, ByVal cat As String, ByVal qty As Double, ByVal progr As Integer)
			Me.URN = urn
			Me.Cat = cat
			Me.Qty = qty
			Me.progressivoNelProgramma = progr
		End Sub
		Public ReadOnly URN As String
		Public ReadOnly Cat As String
		Public ReadOnly Qty As Double
		Public ReadOnly progressivoNelProgramma As Integer		  'indica un numero progressivo nel file XML

		Public Enum TipoOperatore
			Cedente
			Acquirente
		End Enum

		Public Sub ProgrammatoDal(ByVal top As TipoOperatore)
			_programmatoDal = top
		End Sub

		Public Function ProgrammatoDalCedente() As Boolean
			Return _programmatoDal = TipoOperatore.Cedente
		End Function

		Private _programmatoDal As TipoOperatore

	End Class

    Class ElaboraFileData
        Public Sub New()
            Me._pd = New PIPEDocument(Guid.NewGuid())
        End Sub
       
        Public ReadOnly Property idElaboarazione() As Guid
            Get
                Return _pd.idElaborazione
            End Get
        End Property


        ' dati in ingresso alle funzioni ElaboraFileFase1/ElaboraFileFase2
        Private _pd As PIPEDocument    ' questa classe contiene il file letto

        Public ReadOnly Property pd() As PIPEDocument
            Get
                Return Me._pd
            End Get
        End Property


        Public codOperatoreSDC As String
        Public codiceUtenteSDC As String
        Public pathFileXml As String
        Public fileXML As Byte()
        Public DateMGPPiuUno As DateTime
        Public AcceptTimeNormal As TimeSpan
        Public AcceptTimePrivilegiato As TimeSpan
        Public DateTimeInvio As DateTime

        '
        ' eventuale certificato utilizzato per la firma:
        ' messo qui per poterlo passare dalla fase sincrona alla fase asincrona
        '
        Public bInputFirmatoXML As Boolean
        Public bControfirmaXML As Boolean
        Public certificatoFirma As CertX509Ex

        ' risultato delle funzioni ElaboraFileFase1/ElaboraFileFase2
        Public result As String = ""
    End Class


#End Region

#Region "funzioni per verifica, estrazioni e controfirma"

	' Verifica ingresso PKCS7 (verifica hash)
	Private Function VerificaInputPKCS7(ByVal xmlByteArray() As Byte, ByRef errorMsg As String) As Boolean
		Dim result As Boolean = True
		errorMsg = ""

		Try
			result = CryptVerify.Verify(xmlByteArray)
		Catch cEx As CertException
			SmLog.smError(cEx)
			errorMsg = "Verifica HASH firma errato: Win32Msg = " + cEx.Win32Msg
			result = False
		Catch ex As Exception
			SmLog.smError(ex)
			errorMsg = "Errore generico su Verifica HASH firma errato"
			result = False
		End Try
		Return result
	End Function

	' Estrae da Input PKCS7 il dato originario
	Private Function EstraiDaInputPKCS7(ByVal xmlByteArray() As Byte, ByRef cert As CertX509Ex) As Byte()
		Dim xmlExtract As Byte() = Nothing
		Dim cVerify As CryptVerify = Nothing
		cert = Nothing
		Try
			cVerify = New CryptVerify(xmlByteArray, False)
			xmlExtract = cVerify.GetData()
			cert = cVerify.GetCertificate()
		Catch cEx As CertException
			SmLog.smError(cEx)
		Catch ex As Exception
			SmLog.smError(ex)
		End Try
		Return xmlExtract
	End Function

	' Esegue controfirma PKCS7
	Private Function ControFirma(ByVal xmlByteArray() As Byte) As Byte()
		Dim xmlControFirmato() As Byte = Nothing

		Dim cs As CertStore = New CertStore
		Dim x As CertX509Ex = Nothing

		Dim CN_Firma As String = ConfigurationSettings.AppSettings("CN_CertificatoControFirma")
		Dim PIN_Firma As String = ConfigurationSettings.AppSettings("PIN_CertificatoControFirma")

		Try
			cs.OpenUserStore()
			x = cs.CertFindCertificateInStore(CN_Firma)
			x.SetPin(PIN_Firma, Nothing, False)
			xmlControFirmato = x.SignWithTimeStamp(xmlByteArray)
		Catch cErr As CertException
			SmLog.smError(cErr)
		Catch err As Exception
			SmLog.smError(err)
		Finally
			cs.Close()
		End Try
		Return xmlControFirmato
	End Function

#End Region

#Region "memorizzazione dei programmi nel DB"
	Private Sub InsertPrograms(ByVal pd As ElaborazioneProgrammiUtenti.PIPEDocument, ByVal AccettazioneIncrementaleProgrammi As Boolean)

		Debug.Assert(cn.State = ConnectionState.Open)

		pd.xmlPIPTransaction.Sort(New DbComparer)

		' inserisco i record di SessioneBilaterali in modo da avere sempre tutti i record necessari
		If (True) Then
			Dim dataMin As DateTime = DateTime.MaxValue
			Dim dataMax As DateTime = DateTime.MinValue
			For c As Integer = 0 To pd.xmlPIPTransaction.Count - 1
				Dim px As PIPTransaction = DirectCast(pd.xmlPIPTransaction(c), PIPTransaction)
				If (px.Valid = False) Then Exit For
				If (px.xmlData < dataMin) Then dataMin = px.xmlData
				If (px.xmlData > dataMax) Then dataMax = px.xmlData
			Next

			If (dataMin <> DateTime.MaxValue) Then
				Me.spSessioneBilaterali_Fill.Parameters("@DataProgrammaMin").Value = dataMin
				Me.spSessioneBilaterali_Fill.Parameters("@DataProgrammaMax").Value = dataMax
				Me.spSessioneBilaterali_Fill.ExecuteNonQuery()
			End If
		End If


		Dim checkUnitaConsumoEstere As New CheckUnitaConsumoEstereAndMiste(cn)

		Dim tr As SqlClient.SqlTransaction = Nothing

		For c As Integer = 0 To pd.xmlPIPTransaction.Count - 1

			tr = Nothing

			Dim px As PIPTransaction = DirectCast(pd.xmlPIPTransaction(c), PIPTransaction)
			If (px.Valid = False) Then Exit For

			Try

				If AccettazioneIncrementaleProgrammi = False Then

					tr = cn.BeginTransaction(IsolationLevel.ReadCommitted)

					' le nuove transazioni cancellano quelle eventualemente presenti nel DB
					spNuovoProgrammaNonIncrementale.Transaction = tr

					spNuovoProgrammaNonIncrementale.Parameters("@IdContratto").Value = px.IdContratto
					spNuovoProgrammaNonIncrementale.Parameters("@DataProgramma").Value = px.xmlData
					spNuovoProgrammaNonIncrementale.Parameters("@PeriodoRilevante").Value = px.xmlHour
					spNuovoProgrammaNonIncrementale.Parameters("@IsOpCedente").Value = px.IsOperatoreCedente
					spNuovoProgrammaNonIncrementale.Parameters("@IsOpAcquirente").Value = px.IsOperatoreAcquirente

					Dim numRowsAffected As Integer = spNuovoProgrammaNonIncrementale.ExecuteNonQuery()

					If Not tr Is Nothing Then
						tr.Commit()
						tr = Nothing
					End If
				Else
					' cancello comunque POUE
					cmdDeletePOUE.Parameters("@IdContratto").Value = px.IdContratto
					cmdDeletePOUE.Parameters("@DataProgramma").Value = px.xmlData
					cmdDeletePOUE.Parameters("@PeriodoRilevante").Value = px.xmlHour
					cmdDeletePOUE.ExecuteNonQuery()
				End If


				' le nuove transazioni vanno solo in update a transazioni magari gia` presenti nel DB.
				' Devo leggere quello che c'e` nel DB ed eventualmente modificarlo

				' due clienti che voglio programmare lo stesso ProgrammaOrario si serilizzano
				' in quanto la select su ProgrammaOrario e` fatta con Updlock
				' (notare che comunque questa funzione e` gia` serializzata da BatchSerializer e 
				' dunque non dovrebbe essere necessario fare l'updlock)
				SetTransaction(daProgrammaOrario, tr)
				SetTransaction(daProgrammaOrarioPerUnita, tr)
				Dim ds As New DS_ElaborazioneProgrammiUtenti

				' qui leggo ProgrammaOrario e metto il lock esclusivo nella riga
				cmdSelectProgrammaOrario.Parameters("@IdContratto").Value = px.IdContratto
				cmdSelectProgrammaOrario.Parameters("@DataProgramma").Value = px.xmlData
				cmdSelectProgrammaOrario.Parameters("@PeriodoRilevante").Value = px.xmlHour
				daProgrammaOrario.Fill(ds.ProgrammaOrario)

				Debug.Assert(ds.ProgrammaOrario.Rows.Count <= 1)
				If (ds.ProgrammaOrario.Rows.Count > 0) Then
					cmdSelectProgrammaOrarioPerUnita.Parameters("@IdContratto").Value = px.IdContratto
					cmdSelectProgrammaOrarioPerUnita.Parameters("@DataProgramma").Value = px.xmlData
					cmdSelectProgrammaOrarioPerUnita.Parameters("@PeriodoRilevante").Value = px.xmlHour
					daProgrammaOrarioPerUnita.Fill(ds.ProgrammaOrarioPerUnita)
				End If


				' controllo unita` di export
				checkUnitaConsumoEstere.CheckProgramma(ds.ProgrammaOrarioPerUnita, px)
				If px.Valid Then

					Dim drProgrammaOrario As DS_ElaborazioneProgrammiUtenti.ProgrammaOrarioRow
					drProgrammaOrario = ds.ProgrammaOrario.FindByIdContrattoDataProgrammaPeriodoRilevante(px.IdContratto, px.xmlData, px.xmlHour)
					If Not drProgrammaOrario Is Nothing Then
						' Campi NULL
						drProgrammaOrario.SetBilanciatoNull()
						drProgrammaOrario.SetTSCalcoloBilanciamentoNull()
						drProgrammaOrario.SetSbilanciamentoMWhNull()
					Else
						' INSERT di un nuovo record
						drProgrammaOrario = ds.ProgrammaOrario.NewProgrammaOrarioRow
						drProgrammaOrario.IdContratto = px.IdContratto
						drProgrammaOrario.DataProgramma = px.xmlData
						drProgrammaOrario.PeriodoRilevante = px.xmlHour
						drProgrammaOrario.ProgrammaOrarioValidato = True
						drProgrammaOrario.TSModifica = Date.Now()
						' Campi NULL
						drProgrammaOrario.SetBilanciatoNull()
						drProgrammaOrario.SetTSCalcoloBilanciamentoNull()
						drProgrammaOrario.SetSbilanciamentoMWhNull()
						ds.ProgrammaOrario.AddProgrammaOrarioRow(drProgrammaOrario)
					End If

					For k As Integer = 0 To px.URNListCount - 1
						Dim urnData As URNData = px.GetURN(k)

						Dim dr As DS_ElaborazioneProgrammiUtenti.ProgrammaOrarioPerUnitaRow
						dr = ds.ProgrammaOrarioPerUnita.FindByIdContrattoDataProgrammaPeriodoRilevanteCodiceUnitaSDCCategoriaUnitaSDC(px.IdContratto, px.xmlData, px.xmlHour, urnData.URN, urnData.Cat)

						If Not dr Is Nothing Then
							' STR 251: se il programma e` zero cancello la riga
							If Math.Round(urnData.Qty, 3) = 0 Then
								' cancello la riga perche` le programmazioni a zero non le memorizziamo
								' in ProgrammaOrarioPerUnita
								dr.Delete()
							Else
								' modifico la riga esistente (e` gia` arrivata una programmazione)
								' => UPDATE
								dr.QtyMWh = Math.Round(urnData.Qty, 3)

								'dr.ProgOrarioDellUnitaValidato = False
								dr.IdProgrammaXml = pd.IdProgrammaXml
								dr.ProgressivoNelProgramma = urnData.progressivoNelProgramma
								' Campi  NULL
								dr.SetQtyMWhBilanciamentoNull()
								dr.SetQtyMWhAssegnataMGPNull()
								dr.ProgrammatoDalCedente = urnData.ProgrammatoDalCedente()
							End If
						Else
							' STR 251: se il programma e` zero non inserisco la riga 
							' in ProgrammaOrarioPerUnita
							If Math.Round(urnData.Qty, 3) <> 0 Then
								dr = ds.ProgrammaOrarioPerUnita.NewProgrammaOrarioPerUnitaRow

								' chiave
								dr.IdContratto = px.IdContratto
								dr.DataProgramma = px.xmlData
								dr.PeriodoRilevante = px.xmlHour
								dr.CodiceUnitaSDC = urnData.URN
								dr.CategoriaUnitaSDC = urnData.Cat
								' valori
								dr.QtyMWh = Math.Round(urnData.Qty, 3)

								dr.ProgOrarioDellUnitaValidato = True
								dr.IdProgrammaXml = pd.IdProgrammaXml
								dr.ProgressivoNelProgramma = urnData.progressivoNelProgramma
								' Campi NULL
								Debug.Assert(dr.IsQtyMWhAssegnataMGPNull)
								dr.SetQtyMWhAssegnataMGPNull()
								dr.SetQtyMWhBilanciamentoNull()
								dr.ProgrammatoDalCedente = urnData.ProgrammatoDalCedente()

								ds.ProgrammaOrarioPerUnita.AddProgrammaOrarioPerUnitaRow(dr)
							End If
						End If
					Next

					Dim bElaborazioneProgrammiUtenti_UseTr As Boolean = AppSettingToBoolean("bElaborazioneProgrammiUtenti_UseTr", True)
					If bElaborazioneProgrammiUtenti_UseTr Then
						tr = cn.BeginTransaction(IsolationLevel.ReadCommitted)
					Else
						tr = Nothing
					End If

					SetTransaction(daProgrammaOrario, tr)
					SetTransaction(daProgrammaOrarioPerUnita, tr)

					daProgrammaOrario.Update(ds.ProgrammaOrario)
					daProgrammaOrarioPerUnita.Update(ds.ProgrammaOrarioPerUnita)

					' qui metto 
					' SessioneBilaterali.Taglio = 0
					If True Then
						spOnProgrammaOperatore.Transaction = tr
						spOnProgrammaOperatore.Parameters("@DataProgramma").Value = px.xmlData
						spOnProgrammaOperatore.ExecuteNonQuery()
					End If

					'-------------- calcolo del bilanciamento real-time ----------------
					'---------------------------- begin --------------------------------
					If True Then
						Dim cb As New ControlloBilanciamento
						Dim SogliaSbilMWh As Double = cb.SogliaSbilanciamentoMWh
						cb.EseguiBilanciamentoPerContrattoDataOra(cn, tr, px.IdContratto, px.xmlData, px.xmlHour, SogliaSbilMWh)
						cb = Nothing
					End If
					'----------------------------- end ---------------------------------

					If Not tr Is Nothing Then
						tr.Commit()
						tr = Nothing
					End If

				End If

			Catch ex As Exception
				SmLog.smError(ex)

				If (Not tr Is Nothing) Then
					tr.Rollback()
					tr = Nothing
				End If
			End Try
		Next
	End Sub

	Class DbComparer
		Implements System.Collections.IComparer
		Private Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
			If x Is Nothing AndAlso y Is Nothing Then Return 0
			If (x Is Nothing) Then Return -1
			If (y Is Nothing) Then Return 1

			Dim px As PIPTransaction = DirectCast(x, PIPTransaction)
			Dim py As PIPTransaction = DirectCast(y, PIPTransaction)

			If (px.Valid = True AndAlso py.Valid = False) Then Return -1 ' prima quelle valide
			If (px.Valid = False AndAlso py.Valid = True) Then Return 1

			If (px.URNCount = 0 AndAlso py.URNCount = 0) Then Return 0
			If (px.URNCount > 0 AndAlso py.URNCount = 0) Then Return 1
			If (px.URNCount = 0 AndAlso py.URNCount > 0) Then Return -1

			Dim pgrX As Integer = px.GetURN(0).progressivoNelProgramma
			Dim pgrY As Integer = py.GetURN(0).progressivoNelProgramma
			If (pgrX > pgrY) Then Return 1
			If (pgrX < pgrY) Then Return -1
			Return 0
		End Function
	End Class


	'Class CheckUnitaConsumoEstere

	'	Public Sub CaricaUnitaDiConsumoEstere(ByVal cn As SqlConnection)

	'		' questa query ritorna tutte le unita` di CONSUMO con di fianco un indicazione se l'unita`
	'		' e` estera o no.
	'		Dim cmdUnitaExport As New SqlCommand
	'		cmdUnitaExport.Connection = cn
	'		cmdUnitaExport.CommandText = ""
	'		cmdUnitaExport.CommandText += " select "
	'		cmdUnitaExport.CommandText += " u.CodiceUnitaSDC CodiceUnitaSDC, case z.type when 'VIRT' then 1 else 0 end Export"
	'		cmdUnitaExport.CommandText += " from sdc_unita u "
	'		cmdUnitaExport.CommandText += " inner join SDC_PuntiDiScambioRilevanti ps "
	'		cmdUnitaExport.CommandText += " on ps.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC "
	'		cmdUnitaExport.CommandText += " inner join sdc_zone z "
	'		cmdUnitaExport.CommandText += " on ps.CodiceZonaSDC = z.CodiceZonaSDC "
	'		cmdUnitaExport.CommandText += " where u.TipoUnita='C' "
	'		Dim rdUnitaExport As SqlDataReader
	'		Try
	'			rdUnitaExport = cmdUnitaExport.ExecuteReader()
	'			While rdUnitaExport.Read
	'				Dim u As String = DirectCast(rdUnitaExport(0), String)
	'				Dim e As Boolean = True
	'				If rdUnitaExport(1).ToString = "0" Then e = False

	'				_unitaConsumo.Add(u, e)
	'			End While
	'		Finally
	'			If Not rdUnitaExport Is Nothing Then
	'				rdUnitaExport.Close()
	'			End If
	'		End Try

	'	End Sub

	'	Public Sub CheckProgramma(ByVal dtProgrammaOrarioPerUnita As DS_ElaborazioneProgrammiUtenti.ProgrammaOrarioPerUnitaDataTable, ByVal px As PIPTransaction)

	'		Dim unitaConsumoProgrammate As New Specialized.StringCollection

	'		' prima copio nella unitaExportProgrammate la lista delle unita di export
	'		' attualmente programmate nel DB.
	'		' a fronte di questo for dovremmo avere zero o una entry
	'		' (dato che si presuppone che il programma nel DB sia corretto)
	'		Dim dr As DS_ElaborazioneProgrammiUtenti.ProgrammaOrarioPerUnitaRow
	'		For Each dr In dtProgrammaOrarioPerUnita.Rows
	'			' controllo che tipo di unita e` 
	'			If _unitaConsumo.Contains(dr.CodiceUnitaSDC) Then
	'				' e` una unita` di consumo
	'				If Not unitaConsumoProgrammate.Contains(dr.CodiceUnitaSDC) Then
	'					unitaConsumoProgrammate.Add(dr.CodiceUnitaSDC)
	'				End If
	'			End If
	'		Next

	'		' qui applico le modifiche nel file alla unitaConsumoProgrammate
	'		' come se fossimo nel DB.
	'		For k As Integer = 0 To px.URNListCount - 1
	'			Dim urnData As URNData = px.GetURN(k)
	'			If _unitaConsumo.Contains(urnData.URN) Then
	'				' e` una unita di consumo

	'				If Math.Round(urnData.Qty, 3) = 0 Then
	'					If unitaConsumoProgrammate.Contains(urnData.URN) Then
	'						unitaConsumoProgrammate.Remove(urnData.URN)
	'					End If
	'				Else
	'					If Not unitaConsumoProgrammate.Contains(urnData.URN) Then
	'						unitaConsumoProgrammate.Add(urnData.URN)
	'					End If
	'				End If
	'			End If
	'		Next

	'		' ora ho la lista delle unita di CONSUMO programmate in "unitaConsumoProgrammate"

	'		' guardo quante unita di consumo di export sono programmate
	'		Dim numExport As Integer = 0
	'		Dim numConsumo As Integer = 0
	'		For i As Integer = 0 To unitaConsumoProgrammate.Count - 1
	'			numConsumo += 1

	'			If _unitaConsumo.GetValue(unitaConsumoProgrammate(i)) Then
	'				numExport += 1
	'			End If
	'		Next i

	'		If numExport > 0 Then
	'			' ohh, un contratto che programma unita di export!

	'			If numExport > 1 Then
	'				px.SetError("VAL264", "Numero unita` di consumo di export nel programma risultante maggiore di uno")
	'			ElseIf numExport = 1 AndAlso numConsumo > 1 Then
	'				px.SetError("VAL266", "In un programma non possono coesistere unita` di consumo nazionali e unita` di consumo di export")
	'			End If
	'		End If
	'	End Sub

	'	Class HastString2Bool
	'		Dim _h As New Hashtable

	'		Public Sub Add(ByVal s As String, ByVal b As Boolean)
	'			_h(s) = b
	'		End Sub

	'		Public Function Contains(ByVal s As String) As Boolean
	'			Return _h.ContainsKey(s)
	'		End Function

	'		Public Function GetValue(ByVal s As String) As Boolean
	'			Return CType(_h(s), Boolean)
	'		End Function

	'	End Class

	'	Dim _unitaConsumo As New HastString2Bool
	'End Class


	Class CheckUnitaConsumoEstereAndMiste

		Public Class Unita
			Public CodiceUnita As String
			Public Estera As Boolean
			Public TipoUnita As String
			Public CodiceZona As String
		End Class

		ReadOnly _unitaChePossonoConsumare As New HashString2Unita

		Public Sub New(ByVal cn As SqlConnection)

			Dim s As New StringBuilder
			s.Append(" select ")
			s.Append(" u.CodiceUnitaSDC CodiceUnitaSDC, ")
			s.Append(" case z.type when 'VIRT' then 'S' else 'N' end Estera, ")
			s.Append(" u.TipoUnita, ")
			s.Append(" z.CodiceZonaSDC ")
			s.Append(" from sdc_unita u ")
			s.Append(" inner join SDC_PuntiDiScambioRilevanti ps ")
			s.Append(" on ps.CodicePuntoDiScambioRilevanteSDC = u.CodicePuntoDiScambioRilevanteSDC ")
			s.Append(" inner join sdc_zone z ")
			s.Append(" on ps.CodiceZonaSDC = z.CodiceZonaSDC ")
			s.Append(" where (u.TipoUnita='C' or u.TipoUnita='M' ) ")


			' questa query ritorna tutte le unita` di CONSUMO e le unita` MISTE con di fianco un indicazione se l'unita`
			' e` estera o no + la zona di appartenenza
			Dim cmdUnitaExport As New SqlCommand(s.ToString, cn)
			Dim rdUnitaExport As SqlDataReader
			Try
				rdUnitaExport = cmdUnitaExport.ExecuteReader()
				While rdUnitaExport.Read

					Dim u As String = DirectCast(rdUnitaExport(0), String)
					Dim e As String = DirectCast(rdUnitaExport(1), String)
					Dim t As String = DirectCast(rdUnitaExport(2), String)
					Dim z As String = DirectCast(rdUnitaExport(3), String)

					Dim un As New Unita
					un.CodiceUnita = u
					un.TipoUnita = t
					un.CodiceZona = z
					un.Estera = (e = "S")

					' qui le unita NON possono essere duplicate --> posso
					' usare Add della Hashtable (che aggiunge lamentendandosi
					' se trova duplicati)
					_unitaChePossonoConsumare.Add(un.CodiceUnita, un)
				End While
			Finally
				If Not rdUnitaExport Is Nothing Then
					rdUnitaExport.Close()
				End If
				cmdUnitaExport.Dispose()
			End Try

		End Sub

		Public Sub CheckProgramma(ByVal dtProgrammaOrarioPerUnita As DS_ElaborazioneProgrammiUtenti.ProgrammaOrarioPerUnitaDataTable, ByVal px As PIPTransaction)

			Dim unitaCheConsumanoProgrammate As New StringSet
			If True Then
				' qui si memorizzano TUTTE le unita del programma con associare le produzioni

				Dim dr As DS_ElaborazioneProgrammiUtenti.ProgrammaOrarioPerUnitaRow
				For Each dr In dtProgrammaOrarioPerUnita.Rows
					If dr.QtyMWh < 0 Then unitaCheConsumanoProgrammate.Add(dr.CodiceUnitaSDC)
				Next

				' qui applico le modifiche nel file alla unitaProgrammate
				' come se fossimo nel DB.
				For k As Integer = 0 To px.URNListCount - 1
					Dim urnData As URNData = px.GetURN(k)

					Dim qty As Double = Math.Round(urnData.Qty, 3)

					If qty >= 0 Then
						' cancellazione o produzione --> non consumano --> le tolgo dalla lista
						unitaCheConsumanoProgrammate.Remove(urnData.URN)				   ' se non esiste gia` Remove non va in crisi

					Else
						' unita che consuma  --> la aggiungo se non esiste gia`
						unitaCheConsumanoProgrammate.Add(urnData.URN)				   ' se esiste gia` Add non va in crisi
					End If
				Next

			End If

			' ora ho in unitaCheConsumanoProgrammate la lista delle unita programmate in questo contratto data/ora
			' con associata la quantita` programmata


			Dim zonaUnitaDiConsumoEstere As New StringSet
			Dim zonaUnitaMisteCheConsumano As New StringSet

			Dim unitaConsumoEstere As Integer = 0
			Dim unitaMisteCheConsumano As Integer = 0
			Dim unitaConsumoNazionali As Integer = 0

			For Each codiceUnita As String In unitaCheConsumanoProgrammate
				'Dim qty As Double = DirectCast(de.Value, Double)

				Dim un As Unita = _unitaChePossonoConsumare.GetValue(codiceUnita)
				Debug.Assert(Not (un Is Nothing))


				If un.TipoUnita = "C" AndAlso un.Estera Then

					unitaConsumoEstere += 1
					zonaUnitaDiConsumoEstere.Add(un.CodiceZona)

				ElseIf un.TipoUnita = "C" AndAlso Not un.Estera Then

					unitaConsumoNazionali += 1

				ElseIf un.TipoUnita = "M" Then

					unitaMisteCheConsumano += 1
					zonaUnitaMisteCheConsumano.Add(un.CodiceZona)

				Else
					Debug.Assert(False, "Qui ci devono essere solo unita` che consumano")
				End If

			Next

			If zonaUnitaDiConsumoEstere.Count >= 2 Then
				px.SetError("VAL264", "Il programma contiene unita` di consumo estere non appartenenti tutte alla stessa zona.")
				Return
			End If

			If zonaUnitaMisteCheConsumano.Count >= 2 Then
				px.SetError("VAL265", "Il programma contiene unita` miste che consumano non appartenenti tutte alla stessa zona.")
				Return
			End If

			If zonaUnitaDiConsumoEstere.Count >= 1 AndAlso zonaUnitaMisteCheConsumano.Count >= 1 Then
				If zonaUnitaDiConsumoEstere.Item(0) <> zonaUnitaMisteCheConsumano.Item(0) Then
					px.SetError("VAL266", "Il programma contiene unita` miste che consumano e unita` di consumo estere non appartenenti tutte alla stessa zona.")
					Return
				End If
			End If

			If unitaConsumoEstere > 0 AndAlso unitaConsumoNazionali > 0 Then
				px.SetError("VAL267", "Unita` di consumo estere e unita` di consumo nazionali non possono coesistere nello stesso programma.")
				Return
			End If

			If unitaMisteCheConsumano > 0 AndAlso unitaConsumoNazionali > 0 Then
				px.SetError("VAL268", "Unita` miste che consumano e unita` di consumo nazionali non possono coesistere nello stesso programma.")
				Return
			End If



			'If unitaMisteCheConsumano > 0 AndAlso unitaConsumoEstere > 0 Then
			'	px.SetError("VAL268", "Unita` miste e unita` di consumo estere non possono coesistere nello stesso programma.")
			'	Return
			'End If

		End Sub

		Class HashString2Unita
			' la Hashtable non ammette duplicati della chiave.
			' Add fallisce se si aggiunge una chiave gia` esistente
			' Item (set) rimpiazza il valore presente con il valore corrente
			' Item (get) ritorna nothing se la chiave non e` presente 
			Dim _h As New Hashtable

			Public Sub Add(ByVal s As String, ByVal b As Unita)
				_h.Add(s, b)
			End Sub

			Public Function Contains(ByVal s As String) As Boolean
				Return _h.ContainsKey(s)
			End Function

			Public Function GetValue(ByVal s As String) As Unita
				' ritorna nothing se "s" non e` nella Hashtable
				Return DirectCast(_h(s), Unita)
			End Function

		End Class

		Class StringSet
			' la StringCollection ammette duplicati
			' StringCollection.Add non fallisce sui duplicati (semplicemente li memorizza entrambi)
			Dim _s As New System.Collections.Specialized.StringCollection

			Public Sub Add(ByVal s As String)
				If Not _s.Contains(s) Then _s.Add(s)
			End Sub

			Public Sub Remove(ByVal s As String)
				If _s.Contains(s) Then _s.Remove(s)
			End Sub

			Public Function Contains(ByVal s As String) As Boolean
				Return _s.Contains(s)
			End Function

			Public ReadOnly Property Count() As Integer
				Get
					Return _s.Count
				End Get
			End Property

			Public Function Item(ByVal i As Integer) As String
				Return _s(i)
			End Function

			Public Function GetEnumerator() As System.Collections.Specialized.StringEnumerator
				Return _s.GetEnumerator()
			End Function
		End Class

	End Class

#End Region

#Region "funzioni che salvano nel DB sia il programma che l'FA"
	Private Shared Sub InserisciFAInXmlProgrammiUtenti(ByVal cn As SqlClient.SqlConnection, ByVal pd As PIPEDocument, ByVal by() As Byte, ByVal fileNameFA As String, ByVal CodiceOperatoreSDC As String, ByVal fileEncoding As String)
		Try
			Dim IdFileFa As String
			' una FA non e` associata ad un precisa data di flusso ==> DateTime.MaxValue
			IdFileFa = BilBLBase.MemorizzaFilePerOperatore(cn, Nothing, CodiceOperatoreSDC, fileNameFA, "FA", "FA programmi operatori", by, DateTime.Now(), fileEncoding, DateTime.MaxValue)

			' associo l'FA appena creato con il programma che l'ha "causato"
			Dim cmdUpd As String = "UPDATE XmlProgrammiUtenti SET IdFileFA = @IdFileFa WHERE IdProgrammaXml = @IdProgrammaXml"
			Dim cmdUpdate As New SqlClient.SqlCommand(cmdUpd, cn)
			cmdUpdate.Parameters.Add("@IdFileFa", IdFileFa)
			cmdUpdate.Parameters.Add("@IdProgrammaXml", pd.IdProgrammaXml)
			cmdUpdate.ExecuteNonQuery()

		Catch ex As Exception
			SmLog.smError(ex, "Errore su update in InserisciFAInXmlProgrammiUtenti.")
			Throw
		End Try
	End Sub
	Private Shared Function InserisciRigaInXmlProgrammiUtenti(ByVal cn As SqlClient.SqlConnection, ByVal codiceUtenteSDC As String, ByVal codiceOperatoreSDC As String, ByVal pathFileXml As String, ByVal fileXml As Byte(), ByVal dateTimeInvio As DateTime, ByVal ce As CertX509Ex) As Integer

		Try
			Dim cmd As String
			cmd = "INSERT INTO XmlProgrammiUtenti "
			cmd += "(ProgrammaFirmato, TSInvio, Zippato, NomeFileUtente, CodiceUtenteSDC, PathFileFirmato, CodiceOperatoreSDC, TSModifica, Issuer, SerialNumber) "
			cmd += " VALUES "
			cmd += "(@ProgrammaFirmato, @TSInvio, @Zippato, @NomeFileUtente, @CodiceUtenteSDC, @PathFileFirmato, @CodiceOperatoreSDC, @TSModifica, @Issuer, @SerialNumber);"
			cmd += "SELECT IdProgrammaXml from XmlProgrammiUtenti WHERE IdProgrammaXml=@@IDENTITY"

			Dim nomeFile As String = Path.GetFileName(pathFileXml)
			' Zippo il file xml in input
			Dim abyZippedFile() As Byte = BilZipLib.ZipSingleFile(nomeFile, fileXml, 9)
			' Dim strFileOut As String
			' Dim abyUnzippedFile() As Byte = UnzipSingleFile(abyZippedFile, strFileOut)

			Dim cmdInsert As New SqlClient.SqlCommand(cmd.ToString, cn)
			'cmdInsert.Parameters.Add("@IdProgrammaXml", pd.xmlID)
			cmdInsert.Parameters.Add("@ProgrammaFirmato", abyZippedFile)
			cmdInsert.Parameters.Add("@TSInvio", dateTimeInvio)
			cmdInsert.Parameters.Add("@Zippato", True)
			cmdInsert.Parameters.Add("@NomeFileUtente", nomeFile)
			cmdInsert.Parameters.Add("@CodiceUtenteSDC", codiceUtenteSDC)
			cmdInsert.Parameters.Add("@PathFileFirmato", pathFileXml)
			cmdInsert.Parameters.Add("@CodiceOperatoreSDC", codiceOperatoreSDC)
			cmdInsert.Parameters.Add("@TSModifica", DateTime.Now)

			If (Not ce Is Nothing) Then
				cmdInsert.Parameters.Add("@Issuer", ce.GetIssuerName())
				cmdInsert.Parameters.Add("@SerialNumber", ce.GetSerialNumberString())
			Else
				cmdInsert.Parameters.Add("@Issuer", DBNull.Value)
				cmdInsert.Parameters.Add("@SerialNumber", DBNull.Value)
			End If

			Dim rd As SqlClient.SqlDataReader
			Try
				rd = cmdInsert.ExecuteReader()
				If (rd.Read()) Then
					Dim IdProgrammaXml As Integer = rd.GetInt32(0)
					Return IdProgrammaXml
				Else
					SmLog.smError("Impossibile inserire il programma in XmlProgrammiUtenti")
					Throw New Exception("Impossibile inserire il programma in XmlProgrammiUtenti")
				End If
			Finally
				If (Not rd Is Nothing) Then rd.Close()
			End Try

		Catch ex As Exception
			SmLog.smError(ex, "Errore su insert in XmlProgrammiUtenti.")
			Throw
		End Try
	End Function

	Private Shared Function GetFAFileName(ByVal nomeFileProgrammaIn As String, ByVal idFile As String) As String
		Dim strFAFileName As New StringBuilder

		strFAFileName.Append("FA_")
		strFAFileName.Append(nomeFileProgrammaIn)
		strFAFileName.Append(".")
		strFAFileName.Append(idFile)
		strFAFileName.Append(".out")
		strFAFileName.Append(".xml")

		Return strFAFileName.ToString()
	End Function

#End Region

#Region "sezione di validazione semantica del file"
	' questa funzione, dato un PIPEDocument controlla i dati inseriti nel programma
	' per effettuare una validazione semantica"
	Private Sub VerificaDatiXmlNelDB(ByVal pd As PIPEDocument, ByVal DateMGPPiuUno As DateTime, ByVal AcceptTimeNormal As TimeSpan, ByVal AcceptTimePrivilegiato As TimeSpan, ByVal DateTimeInvio As DateTime)

		' NOTE sulla potenza massima/minima di una unita`:
		' l'anagrafica RUC/RUP e` stata cosi` brillantemente concepita:
		' unita` P: potMax >  0 e potMin >= 0 (sorprendentemente congruente :-) )
		' unita` C: potMax >  0 e potMin >= 0 (non segnato -> RUP/RUC era nato per RUP non per RUC ;-) )
		' unita` M: potMax >= 0 e potMin <= 0 (alla faccia del minimo di produzione e il minimo di consumo --> le unita` M sono nate molto dopo il RUP/RUC :-( )
		' Carino anche che per M la potMin sia la MASSIMA potenza consumata :-]
		Dim kPowerP As Double = 0		 ' soglia da applicare per controllare che una unita` P non superi il max di produzione
		Dim kPowerC As Double = 0		 ' soglia da applicare per controllare che una unita` C non superi il max di consumo
		Dim kPowerMp As Double = 0		 ' soglia da applicare per controllare che una unita` M che produce non superi il max di produzione
		Dim kPowerMc As Double = 0		 ' soglia da applicare per controllare che una unita` M che consuma non superi il max di consumo

		Try
			kPowerP = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerP"))
			kPowerC = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerC"))
			kPowerMp = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerMp"))
			kPowerMc = XmlConvert.ToDouble(ConfigurationSettings.AppSettings("kPowerMc"))
		Catch ex As Exception
			smError("Mancano il coefficienti di soglia delle potenze max/min nel file di configurazione (kPowerP/kPowerC/kPowerMp/kPowerMc): il controllo sulla potenza non verra` effettuato")

			' drastico ma efficace
			kPowerP = 0
			kPowerC = 0
			kPowerMp = 0
			kPowerMc = 0
		End Try


		' Carico tutte le unita. Serve SOLO per vedere se una unita specificata in un programma
		' esiste e non e` sconosciuta all'anagrafica del sistema.
		' Non SERVE per controllare se una unita` puo` essere programmata (eventuale disabilitazione)
		Dim ds As New DS_ElaborazioneProgrammiUtenti
		daUnitaProgrammabili.Fill(ds.UnitaProgrammabili)

		daUnitRelate.SelectCommand.Parameters("@Operatore").Value = pd.xmlSender_CompanyIdentifier
		daUnitRelate.Fill(ds.UnitRelate)

#If DEBUG Then
		ds.WriteXml("c:\UnitaProgrammabili.xml")
#End If


		' ordino per CRN --> per contratto/progressivo della prima urn della PIP
		' prima tutte le valide poi quelle non valide
		' In questo modo carico una volta sola i dati del Contratto/unitaContratto
		pd.xmlPIPTransaction.Sort(New CRNComparer)

		Dim lastCRN As String = String.Empty

		For i As Integer = 0 To pd.xmlPIPTransaction.Count - 1

			Dim px As PIPTransaction = DirectCast(pd.xmlPIPTransaction(i), PIPTransaction)
			If px.Valid = False Then
				Exit For				' sono arrivato al blocco delle non valide
			End If

			' la rottura e` per cambio di CRN
			If lastCRN <> px.xmlCRN Then
				' rottura --> carico i dati di questo CRN
				Try
					ds.Contratto.Clear()
					daContratto.SelectCommand.Parameters("@CRN").Value = px.xmlCRN
					daContratto.Fill(ds.Contratto)

					lastCRN = px.xmlCRN

				Catch ex As Exception
					' questo e` un errore DB! --> triste NON ha molto senso continuare
					SmLog.smError(ex, "Impossibile caricare i dati relativi alla PIPTransaction.")
					pd.SetError("VAL02", "Impossibile caricare i dati dal DB")
					Return
				End Try

			End If

#If DEBUG Then
			Debug.Assert(ds.Contratto.Count <= 1)
			If (ds.Contratto.Count = 1) Then
				Debug.Assert(ds.Contratto(0).CRN = px.xmlCRN)
			End If
#End If

			If (ds.Contratto.Count = 0) Then
				px.SetError("VAL03", "tag ""CRN"" sconosciuto")
			End If

			Dim drContratto As Bil.DS_ElaborazioneProgrammiUtenti.ContrattoRow
			If (px.Valid) Then
				drContratto = ds.Contratto(0)
				px.SetIdContratto(drContratto.IdContratto)
			End If

			' controllo lo stato del contratto
			If (px.Valid) Then
				If (drContratto.StatoContratto <> "Abilitato") Then
					px.SetError("VAL04", "Programma rifiutato perche` il contratto non e` attivo.")
				End If
			End If

			' il flag che indica se gli operatori del contratto sono validi
			' (questo rispecchia sia Operatori che SDC_Operatori)
			If px.Valid Then
				If drContratto.TrCN = False Then
					px.SetError("VAL05", "Programma rifiutato perche` il contratto si riferisce ad operatori disabilitati.")
				End If
			End If

			' controllo della data nel programma
			If (px.Valid) Then

				If (px.xmlData < DateMGPPiuUno) Then
					' troppo tardi (mercato del passato)
					px.SetError("VAL06", "Il tag ""Date"" indica un mercato gia` eseguito.")

				ElseIf (px.xmlData > DateMGPPiuUno) Then
					' mercato futuro --> ok

				ElseIf (px.xmlData = DateMGPPiuUno) Then
					' mercato del giorno --> deve arrivare in tempo
					Dim b As Boolean
					If (drContratto.ProgrammazionePrivilegiata) Then
						b = TimeSpan.Compare(DateTimeInvio.TimeOfDay, AcceptTimePrivilegiato) < 0
					Else
						b = TimeSpan.Compare(DateTimeInvio.TimeOfDay, AcceptTimeNormal) < 0
					End If

					If b = False Then
						px.SetError("VAL07", "Programma non valido in quanto i termini di presentazione sono scaduti.")
					End If
				End If
			End If

			If (px.Valid) Then
				Dim htot As Integer = BilBLBase.GetNumberOfHourOfDay(px.xmlData)
				If px.xmlHour < 1 OrElse px.xmlHour > htot Then
					px.SetError("VAL83", "Programma non valido in quanto specifica un'ora non esistente.")
				End If
			End If

			' se sono arrivato qui la data di programmazione e` compatibile

			' controllo la data di programmazione contro la data di validita` del contratto
			If (px.Valid) Then
				If (px.xmlData < drContratto.DataInizioValidita OrElse px.xmlData > drContratto.DataFineValidita) Then
					px.SetError("VAL08", "La data del programma e' fuori dall'intervallo di validita' del contratto.")
				End If
			End If

			' qui stabilisco se l'operatore che manda il programma e` un cedente o un acquirente
			If (px.Valid) Then
				Dim acquirente As Boolean = False
				Dim cedente As Boolean = False

				If (pd.xmlSender_CompanyIdentifier = drContratto.CodiceOperatoreSDCAcquirente) Then acquirente = True
				If (pd.xmlSender_CompanyIdentifier = drContratto.CodiceOperatoreSDCCedente) Then cedente = True

				If acquirente = False AndAlso cedente = False Then
					px.SetError("VAL09", "L'operatore non risulta essere ne` un acquirente ne` un cedente.")
				End If

				px.IsOperatoreAcquirente = acquirente
				px.IsOperatoreCedente = cedente
			End If

			' fase di validazione delle unita`
			For j As Integer = 0 To px.URNListCount - 1

				Dim urnData As URNData = px.GetURN(j)

				' per prima cosa controllo se l'unita esiste
				Dim drUnitaProgrammabili As DS_ElaborazioneProgrammiUtenti.UnitaProgrammabiliRow
				If (px.Valid) Then
					drUnitaProgrammabili = ds.UnitaProgrammabili.FindByCodiceUnitaSDCCategoriaUnitaSDC(urnData.URN, urnData.Cat)
					If (drUnitaProgrammabili Is Nothing) Then
						px.SetError("VAL10", "Unita` """ & urnData.URN & """ sconosciuta.")
					End If
				End If

				Dim dr0 As DS_ElaborazioneProgrammiUtenti.UnitRelateRow = Nothing
				If (px.Valid) Then
					dr0 = ds.UnitRelate.FindByCodiceOperatoreSDCCodiceUnitaSDCCategoriaUnitaSDC( _
					 pd.xmlSender_CompanyIdentifier, _
					 urnData.URN, urnData.Cat)
					If (dr0 Is Nothing) Then
						px.SetError("VAL11", "Unita` """ & urnData.URN & """ non utilizzabile per l'operatore " & pd.xmlSender_CompanyIdentifier & "!")
					End If
				End If

				If (px.Valid) Then
					If Not (dr0.DataInizioValidita <= px.xmlData AndAlso dr0.DataFineValidita >= px.xmlData) Then
						px.SetError("VAL78", "Unita` """ & urnData.URN & """ non e` piu` utilizzabile per l'operatore " & pd.xmlSender_CompanyIdentifier & " (fuori intervallo validita`)!")
					End If
				End If

				' poi se puo` programmarla secondo il tipo P/C/M
				If (px.Valid) Then
					Select Case dr0.TipoUnita
						Case "P"
							If (px.IsOperatoreCedente = False) Then
								' fa il furbo: non e` cedente e vuole programmare una P
								' il messaggio e` volutamente ambiguo cosi non capisce che l'unita` fa parte del suo contratto
								px.SetError("VAL12", "Unita` """ & urnData.URN & """ sconosciuta.")
							End If

							If (px.Valid AndAlso urnData.Qty < 0) Then
								px.SetError("VAL13", "L'unita` """ & urnData.URN & """ di produzione e` programmata con Qty negativa")
							End If

							If (px.Valid AndAlso kPowerP > 0 AndAlso urnData.Qty <> 0) Then
								If (urnData.Qty >= kPowerP * dr0.PotenzaMassimaMWh) Then
									px.SetError("VAL14", "L'unita` """ & urnData.URN & """ e` programmata con una QtyMWh che supera la capacita` massima di produzione")
								End If
							End If

							If (px.Valid) Then urnData.ProgrammatoDal(urnData.TipoOperatore.Cedente)

						Case "C"
							If (px.IsOperatoreAcquirente = False) Then
								' fa il furbo: non e` acquirente e vuole programmare una C
								' il messaggio e` volutamente ambiguo cosi non capisce che l'unita` fa parte del suo contratto
								px.SetError("VAL15", "Unita` """ & urnData.URN & """ sconosciuta.")
							End If

							If (px.Valid AndAlso urnData.Qty > 0) Then
								px.SetError("VAL16", "L'unita` """ & urnData.URN & """  di consumo  e` programmata con Qty positiva")
							End If

							If (px.Valid AndAlso kPowerC > 0 AndAlso urnData.Qty <> 0) Then
								' attenzione urnData.Qty e` < 0 mentre PotenzaMaxMWh e` > 0
								If (urnData.Qty <= -1 * kPowerC * dr0.PotenzaMassimaMWh) Then
									px.SetError("VAL17", "L'unita` """ & urnData.URN & """ e` programmata con una QtyMWh che supera la capacita` massima di consumo")
								End If
							End If

							If (px.Valid) Then urnData.ProgrammatoDal(urnData.TipoOperatore.Acquirente)

						Case "M"
							If (px.IsOperatoreCedente = True) AndAlso (px.IsOperatoreAcquirente = True) Then
								If (urnData.Qty < 0) Then
									' l'unita` e` programmata per consumare
									' urnData.Qty e` < 0 e PotenzaMinMWh e` < 0 (che e` la pot max di consumo!)
									If (urnData.Qty <= kPowerMc * dr0.PotenzaMinimaMWh) Then
										px.SetError("VAL21", "L'unita` """ & urnData.URN & """ e` programmata con una QtyMWh che supera la capacita` massima di consumo")
									End If
								ElseIf (urnData.Qty > 0) Then
									' l'unita` e` programmata per produrre
									If (urnData.Qty >= kPowerMp * dr0.PotenzaMassimaMWh) Then
										px.SetError("VAL19", "L'unita` """ & urnData.URN & """ e` programmata con una QtyMWh che supera la capacita` massima di produzione")
									End If
								End If

								' qui bisogna stabilire se e` stato programmato dal cedente o dall'acquirente
								' anche se i due signori conincidono.
								' Questa distinzione deve essere fatta per motivi di fatturazione
								' (cosi` poi riusciamo a distinguere sempre chi fa cosa).
								If (px.Valid) Then
									If (urnData.Qty >= 0) Then
										urnData.ProgrammatoDal(urnData.TipoOperatore.Cedente)
									Else
										urnData.ProgrammatoDal(urnData.TipoOperatore.Acquirente)
									End If
								End If


							ElseIf (px.IsOperatoreCedente = True) Then
								' tutto ok
								If (urnData.Qty < 0) Then
									px.SetError("VAL18", "L'unita` """ & urnData.URN & """  di mista assegnata al cedente e` programmata con Qty negativa")
								End If

								If (px.Valid AndAlso kPowerMp > 0 AndAlso urnData.Qty <> 0) Then
									' urnData.Qty e` > 0 e PotenzaMaxMWh e` > 0
									If (urnData.Qty >= kPowerMp * dr0.PotenzaMassimaMWh) Then
										px.SetError("VAL19", "L'unita` """ & urnData.URN & """ e` programmata con una QtyMWh che supera la capacita` massima di produzione")
									End If
								End If

								If (px.Valid) Then urnData.ProgrammatoDal(urnData.TipoOperatore.Cedente)


								'ElseIf (dr0.UnitaAssegnataOpAcquirente = True AndAlso px.IsOperatoreAcquirente = True) Then
							ElseIf (px.IsOperatoreAcquirente = True) Then

								' tutto ok
								If (urnData.Qty > 0) Then
									px.SetError("VAL20", "L'unita` """ & urnData.URN & """  di mista assegnata ad un acquierente e` programmata con Qty positiva")
								End If

								If (px.Valid AndAlso kPowerMc > 0 AndAlso urnData.Qty <> 0) Then
									' urnData.Qty e` < 0 e PotenzaMinMWh e` < 0 (che e` la pot max di consumo!)
									If (urnData.Qty <= kPowerMc * dr0.PotenzaMinimaMWh) Then
										px.SetError("VAL21", "L'unita` """ & urnData.URN & """ e` programmata con una QtyMWh che supera la capacita` massima di consumo")
									End If
								End If

								If (px.Valid) Then urnData.ProgrammatoDal(urnData.TipoOperatore.Acquirente)

							Else
								Debug.Assert(False)
								px.SetError("VAL22", "Unita` """ & urnData.URN & """ sconosciuta.")
							End If

						Case Else
							Debug.Assert(False)
					End Select

				End If

				' poi se l'unita` e` abilitata (abilitata per i Bilaterali (TrUC alias Unita.StatoUnitaBilaterali non SDC_Unita.Abilitata ne` SDC_Unita_MarketInformation.Eligibility)
				If (px.Valid) Then
					If dr0.TrUC = False Then
						px.SetError("VAL23", "L'unita` """ & urnData.URN & """ non e` abilitata per essere utilizzata dai BILATERALI.")
					End If
				End If

				' infine se la data di programmazione cade all'interno dell'intervallo di validita
				If px.Valid = True Then
					If (Not (px.xmlData >= dr0.DataInizioValidita) AndAlso (px.xmlData <= dr0.DataFineValidita)) Then
						px.SetError("VAL24", "La programmazione dell'unita` """ & urnData.URN & """ e` fuori l'intervallo di validita` della stessa nel contratto")
					End If
				End If
			Next
		Next
	End Sub

	Class CRNComparer
		Implements System.Collections.IComparer
		Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
			If x Is Nothing AndAlso y Is Nothing Then Return 0
			If (x Is Nothing) Then Return -1
			If (y Is Nothing) Then Return 1

			Dim px As PIPTransaction = DirectCast(x, PIPTransaction)
			Dim py As PIPTransaction = DirectCast(y, PIPTransaction)

			If (px.Valid = True AndAlso py.Valid = False) Then Return -1
			If (px.Valid = False AndAlso py.Valid = True) Then Return 1

			If (px.xmlCRN Is Nothing AndAlso py.xmlCRN Is Nothing) Then Return 0
			If (px.xmlCRN Is Nothing) Then Return -1
			If (py.xmlCRN Is Nothing) Then Return 1

			Dim r As Integer = String.Compare(px.xmlCRN, py.xmlCRN)
			If (r <> 0) Then Return r

			If (px.URNCount = 0 AndAlso py.URNCount = 0) Then Return 0
			If (px.URNCount > 0 AndAlso py.URNCount = 0) Then Return 1
			If (px.URNCount = 0 AndAlso py.URNCount > 0) Then Return -1

			Dim pgrX As Integer = px.GetURN(0).progressivoNelProgramma
			Dim pgrY As Integer = py.GetURN(0).progressivoNelProgramma
			If (pgrX > pgrY) Then Return 1
			If (pgrX < pgrY) Then Return -1
			Return 0
		End Function
	End Class


#End Region

#Region "sezione lettura e validazione programma in ingresso"
	Class BilateralProgramReader
		'Private fileValido As Boolean = True	' flag che indica se ci sono errori nel file (e NON in una PIPTransaction)
		Private bloccoSender As Boolean = False		 ' flag che indica se sono nel tag "Sender"
		Private bloccoPIP As Boolean = False		  ' flag che indica se sono nel tag "PIPTransaction"

		Private currentPIP As ElaborazioneProgrammiUtenti.PIPTransaction = Nothing
		Private currentPIPEDocument As ElaborazioneProgrammiUtenti.PIPEDocument = Nothing

		Sub New(ByVal p As ElaborazioneProgrammiUtenti.PIPEDocument)
			currentPIPEDocument = p
		End Sub

		Public Sub LeggiXmlEtVerificaSchema(ByVal codOperatoreSDC As String, ByVal codiceUtenteSDC As String, ByVal pathFileXml As String, ByVal fileXML As Byte(), ByVal DateMGPPiuUno As DateTime, ByVal AcceptTimeNormal As TimeSpan, ByVal AcceptTimePrivilegiato As TimeSpan, ByVal DateTimeInvio As DateTime)
			bloccoSender = False			' flag che indica se sono nel tag "Sender"
			bloccoPIP = False			 ' flag che indica se sono nel tag "PIPTransaction"
			currentPIP = Nothing


			Dim xr As XmlValidatingReader

			Try
				Dim fileSchema As String = BilBLBase.GetCompleteFileNameFromAppSettings("ProgrammiOperatori.PIPEDocument.xsd")
				If (fileSchema Is Nothing) Then
					SystemMonitor.SmLog.smError("""PIPEDocument.xsd"" non e` presente nel file di configurazione")
					Me.currentPIPEDocument.SetError("VAL25", "Cannot find schema")
					Return
				End If
				Dim sc As XmlSchemaCollection = New XmlSchemaCollection
				sc.Add(Nothing, fileSchema)

				Dim textReader As XmlTextReader = New XmlTextReader(New MemoryStream(fileXML))
				textReader.WhitespaceHandling = WhitespaceHandling.Significant
				xr = New XmlValidatingReader(textReader)
				xr.ValidationType = ValidationType.Schema
				xr.Schemas.Add(sc)
				AddHandler xr.ValidationEventHandler, AddressOf Me.ValidationEvent

			Catch ex As Exception
				Debug.Assert(False)				' se non trova il file degli schemi
				SmLog.smError(ex)
				Return
			End Try

			Try
				Dim cultureInfoIT As New CultureInfo("it-IT")				  ' per leggere i double in italiano
				Dim progressivoNelProgramma As Integer = 0				' per assegnare un progressivo alle programmazioni per unita


				Dim elPIPEDocument As Object = xr.NameTable.Add("PIPEDocument")
				Dim elSender As Object = xr.NameTable.Add("Sender")
				Dim elTradingPartner As Object = xr.NameTable.Add("TradingPartner")
				Dim elCompanyName As Object = xr.NameTable.Add("CompanyName")
				Dim elCompanyIdentifier As Object = xr.NameTable.Add("CompanyIdentifier")
				Dim elPIPTransaction As Object = xr.NameTable.Add("PIPTransaction")
				Dim elBilateralProgram As Object = xr.NameTable.Add("BilateralProgram")
				Dim elCRN As Object = xr.NameTable.Add("CRN")
				Dim elDate As Object = xr.NameTable.Add("Date")
				Dim elHour As Object = xr.NameTable.Add("Hour")
				Dim elQty As Object = xr.NameTable.Add("Qty")

				' PIPDocument/Sender/(CompanyName|CompanyIdentifier)
				' PIPTransaction/BilateralProgram/(CRN|Date|Hour|Program/Qty)

				While (xr.Read())

					If (currentPIPEDocument.Valid = False) Then
						Exit While						 ' se c'e` un errore nella validazione NON all'interno di un PIPTransaction esco
					End If

					Dim xrn As Object = xr.Name

					Select Case xr.NodeType

						Case XmlNodeType.Element						 ' qui iniziano i tag
							' l'ordine degli if e` inverso all'ordine di lettura
							' la stranezza e` dovuta dal fatto che Qty e` molto piu` frequente di Sender
							If xrn Is elQty Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								Dim xmlURN As String
								Dim xmlURNCat As String
								Dim xmlQty As Double

								If (currentPIP.Valid) Then
									' lo schema richiede la presenza obbligatoria URN 
									xmlURN = xr.GetAttribute("URN")
									' attributo non presente nello schema ma in un futuro si dovra` capire la categoria delle unita`
									If (Not xmlURN Is Nothing AndAlso xmlURN = String.Empty) Then
										currentPIP.SetError("VA14", "Il tag ""URN"" non deve essere vuoto.")


									End If
								End If

								If (currentPIP.Valid) Then
									xmlURNCat = xr.GetAttribute("URNCat")									 ' Sarebbe CategoriaUnitaSDC
									If (xmlURNCat Is Nothing) OrElse (xmlURNCat = String.Empty) Then xmlURNCat = "F"
								End If

								If (currentPIP.Valid) Then
									' lo schema impone xr.ReadInnerXml di lunghezza minima 1 di tipo "string"
									' (fantastica validazione per un double)
									' per cui chiunque puo` scrive schifezze tanto lo schema le passa.
									Try
										xmlQty = Convert.ToDouble(xr.ReadString(), cultureInfoIT)
									Catch ex As Exception
										currentPIP.SetError("VAL26", "la tag ""Qty"" non e` in formato numerico (formato valido es. 3,14).")
									End Try
								End If

								If (currentPIP.Valid) Then
									currentPIP.AddURN(New ElaborazioneProgrammiUtenti.URNData(xmlURN, xmlURNCat, xmlQty, progressivoNelProgramma))
									progressivoNelProgramma += 1
								End If

							ElseIf xrn Is elHour Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								If (currentPIP.Valid) Then
									Try
										currentPIP.xmlHour = CType(xr.ReadString(), Byte)
									Catch ex As Exception
										currentPIP.SetError("VAL27", "Il tag ""Hour"" non e` un campo numerico.")
									End Try
								End If

							ElseIf xrn Is elDate Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								If (currentPIP.Valid) Then
									Try
										Dim s As String = xr.ReadString()
										currentPIP.xmlData = New DateTime(CType(Mid(s, 1, 4), Integer), CType(Mid(s, 5, 2), Integer), CType(Mid(s, 7, 2), Integer))
									Catch ex As Exception
										currentPIP.SetError("VAL28", "Il tag ""Date"" non e` una data non valida.")
									End Try
								End If

							ElseIf xrn Is elCRN Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								If (currentPIP.Valid) Then
									currentPIP.xmlCRN = xr.ReadString()
									If (currentPIP.xmlCRN Is Nothing OrElse currentPIP.xmlCRN = String.Empty) Then
										currentPIP.SetError("VAL29", "Il tag ""CRN"" non e` valorizzato.")
									End If
								End If

							ElseIf xrn Is elBilateralProgram Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								Debug.Assert(bloccoPIP)
								Debug.Assert(Not currentPIP Is Nothing)

								If (currentPIP.Valid) Then
									currentPIP.xmlMPN = xr.GetAttribute("MPN")
									' STR #2
									' codice originale
									'If (currentPIP.xmlMPN Is Nothing OrElse currentPIP.xmlMPN = String.Empty) Then
									'	currentPIP.SetError("VAL20", "Il tag ""MPN"" non e` valorizzato.")
									'end STR #2
								End If

							ElseIf xrn Is elPIPTransaction Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								bloccoPIP = True
								currentPIP = New ElaborazioneProgrammiUtenti.PIPTransaction(currentPIPEDocument)

							ElseIf xrn Is elCompanyIdentifier Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								If (bloccoSender) Then
									currentPIPEDocument.xmlSender_CompanyIdentifier = xr.ReadString()
									If (currentPIPEDocument.xmlSender_CompanyIdentifier Is Nothing OrElse currentPIPEDocument.xmlSender_CompanyIdentifier <> codOperatoreSDC) Then
										currentPIPEDocument.SetError("VAL30", "Il tag ""CompanyIdentifier"" nel programma non e` quello dell'operatore connesso.")
										' ritorno al chiamante perche` se il mittente e` errato devo scartare tutto
										Return
									End If
								End If

							ElseIf xrn Is elCompanyName Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								If (bloccoSender) Then
									currentPIPEDocument.xmlSender_CompanyName = xr.ReadString()
								End If

							ElseIf xrn Is elTradingPartner Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								If (bloccoSender) Then
									currentPIPEDocument.xmlSender_PartnerType = xr.GetAttribute("PartnerType")
								End If

							ElseIf xrn Is elSender Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								bloccoSender = True

							ElseIf xrn Is elPIPEDocument Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								Dim v As String = xr.GetAttribute("Version")
								If (v Is Nothing OrElse v <> "1.0") Then
									currentPIPEDocument.SetError("VAL31", "Versione del file errata.")
									Return
								End If
								currentPIPEDocument.ReferenceNumber = xr.GetAttribute("ReferenceNumber")
							End If

						Case XmlNodeType.EndElement						' qui finiscono i tag

							If xrn Is elPIPTransaction Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								bloccoPIP = False
								Debug.Assert(Not currentPIP Is Nothing)

								' ho finito una pipTransaction
								currentPIPEDocument.xmlPIPTransaction.Add(currentPIP)
								currentPIP = Nothing

							ElseIf xrn Is elSender Then
								'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
								bloccoSender = False
							End If
					End Select
				End While

			Catch ex As XmlException
				currentPIPEDocument.SetError("VAL32", ex.Message)
				SmLog.smError(ex, "Errore su ElaboraFile().")
			Catch ex As Exception
				currentPIPEDocument.SetError("VAL33", ex.Message)
				SmLog.smError(ex, "Errore su ElaboraFile().")
			Finally
				xr.Close()
			End Try
		End Sub

		Private Sub ValidationEvent(ByVal sender As Object, ByVal e As ValidationEventArgs)
            If (bloccoPIP) Then
                Dim ln As Integer
                If (Not e Is Nothing) AndAlso (Not e.Exception Is Nothing) Then
                    ln = e.Exception.LineNumber
                    currentPIP.SetError("VA65", "Errore di validazione alla linea " + ln.ToString())
                Else
                    currentPIP.SetError("VA65", "Errore di validazione")
                End If
            Else
                currentPIPEDocument.SetError("VAL34", e.Message)
            End If
		End Sub
	End Class
#End Region


End Class
