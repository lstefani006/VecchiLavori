Imports System.IO
Imports System.Configuration
Imports System.Globalization
Imports System.Text
Imports System.Xml
Imports System.Xml.Schema
Imports System.Collections
Imports System.Threading
Imports SystemMonitor

Public Class LetturaMercato
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		_cn.ConnectionString = GetConnectionString()
	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents _cmdSelectDatiUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdSelectProgrammaOrarioUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents _ds As Bil.DS_LetturaMercatoProgrammiOrarioUnita
	Friend WithEvents _daProgrammaOrarioUnita As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents _daDatiUnita As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents _dsDatiUnita As Bil.DS_DatiPerditeUnita
	Friend WithEvents _cmdUpdateProgrammaOrarioUnita As System.Data.SqlClient.SqlCommand
	Friend WithEvents spNotificaStatoLetturaMGP As System.Data.SqlClient.SqlCommand
    Friend WithEvents _daProgrammaOrarioUnitaErrori As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelectProgrammaOrarioUnitaErrori As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdInsertProgrammaOrarioUnitaErrori As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdUpdateProgrammaOrarioUnitaErrori As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdDeleteProgrammaOrarioUnitaErrori As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me._cmdSelectDatiUnita = New System.Data.SqlClient.SqlCommand
        Me._cmdSelectProgrammaOrarioUnita = New System.Data.SqlClient.SqlCommand
        Me._daProgrammaOrarioUnita = New System.Data.SqlClient.SqlDataAdapter
        Me._cmdUpdateProgrammaOrarioUnita = New System.Data.SqlClient.SqlCommand
        Me._ds = New Bil.DS_LetturaMercatoProgrammiOrarioUnita
        Me._daDatiUnita = New System.Data.SqlClient.SqlDataAdapter
        Me._dsDatiUnita = New Bil.DS_DatiPerditeUnita
        Me.spNotificaStatoLetturaMGP = New System.Data.SqlClient.SqlCommand
        Me._daProgrammaOrarioUnitaErrori = New System.Data.SqlClient.SqlDataAdapter
        Me._cmdDeleteProgrammaOrarioUnitaErrori = New System.Data.SqlClient.SqlCommand
        Me._cmdInsertProgrammaOrarioUnitaErrori = New System.Data.SqlClient.SqlCommand
        Me._cmdSelectProgrammaOrarioUnitaErrori = New System.Data.SqlClient.SqlCommand
        Me._cmdUpdateProgrammaOrarioUnitaErrori = New System.Data.SqlClient.SqlCommand
        CType(Me._ds, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._dsDatiUnita, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
        "st security info=True;initial catalog=Bilaterali;password=bilaterali"
        '
        '_cmdSelectDatiUnita
        '
        Me._cmdSelectDatiUnita.CommandText = "SELECT dbo.Bil_CoefficientiPerdita.* FROM dbo.Bil_CoefficientiPerdita"
        Me._cmdSelectDatiUnita.Connection = Me._cn
        '
        '_cmdSelectProgrammaOrarioUnita
        '
        Me._cmdSelectProgrammaOrarioUnita.CommandText = "SELECT QtyMWh, QtyMWhBilanciamento, QtyMWhAssegnataMGP, PeriodoRilevante, DataPro" & _
        "gramma, CodiceUnitaSDC, CategoriaUnitaSDC, IdContratto, GMEReferenceNumber FROM " & _
        "dbo.ProgrammaOrarioPerUnita WITH (UPDLOCK)"
        Me._cmdSelectProgrammaOrarioUnita.Connection = Me._cn
        '
        '_daProgrammaOrarioUnita
        '
        Me._daProgrammaOrarioUnita.SelectCommand = Me._cmdSelectProgrammaOrarioUnita
        Me._daProgrammaOrarioUnita.UpdateCommand = Me._cmdUpdateProgrammaOrarioUnita
        '
        '_cmdUpdateProgrammaOrarioUnita
        '
        Me._cmdUpdateProgrammaOrarioUnita.CommandText = "UPDATE dbo.ProgrammaOrarioPerUnita SET QtyMWhAssegnataMGP = @QtyMwhAssegnataMGP, " & _
        "GMEReferenceNumber = @GMEReferenceNumber WHERE (CodiceUnitaSDC = @CodiceUnitaSDC" & _
        ") AND (PeriodoRilevante = @PeriodoRilevante) AND (DataProgramma = @DataProgramma" & _
        ") AND (IdContratto = @IdContratto) AND (CategoriaUnitaSDC = @CategoriaUnitaSDC)"
        Me._cmdUpdateProgrammaOrarioUnita.Connection = Me._cn
        Me._cmdUpdateProgrammaOrarioUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@QtyMwhAssegnataMGP", System.Data.SqlDbType.Float, 8, "QtyMWhAssegnataMGP"))
        Me._cmdUpdateProgrammaOrarioUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GMEReferenceNumber", System.Data.SqlDbType.VarChar, 30, "GMEReferenceNumber"))
        Me._cmdUpdateProgrammaOrarioUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        '_ds
        '
        Me._ds.CaseSensitive = True
        Me._ds.DataSetName = "DS_LetturaMercatoProgrammiOrarioUnita"
        Me._ds.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        '_daDatiUnita
        '
        Me._daDatiUnita.SelectCommand = Me._cmdSelectDatiUnita
        '
        '_dsDatiUnita
        '
        Me._dsDatiUnita.CaseSensitive = True
        Me._dsDatiUnita.DataSetName = "DS_DatiPerditeUnita"
        Me._dsDatiUnita.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        'spNotificaStatoLetturaMGP
        '
        Me.spNotificaStatoLetturaMGP.CommandText = "dbo.[spNotificaStatoLetturaMGP]"
        Me.spNotificaStatoLetturaMGP.CommandType = System.Data.CommandType.StoredProcedure
        Me.spNotificaStatoLetturaMGP.Connection = Me._cn
        Me.spNotificaStatoLetturaMGP.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        Me.spNotificaStatoLetturaMGP.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
        Me.spNotificaStatoLetturaMGP.Parameters.Add(New System.Data.SqlClient.SqlParameter("@eseguito", System.Data.SqlDbType.Bit, 1))
        '
        '_daProgrammaOrarioUnitaErrori
        '
        Me._daProgrammaOrarioUnitaErrori.DeleteCommand = Me._cmdDeleteProgrammaOrarioUnitaErrori
        Me._daProgrammaOrarioUnitaErrori.InsertCommand = Me._cmdInsertProgrammaOrarioUnitaErrori
        Me._daProgrammaOrarioUnitaErrori.SelectCommand = Me._cmdSelectProgrammaOrarioUnitaErrori
        Me._daProgrammaOrarioUnitaErrori.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "ProgrammaOrarioPerUnitaErrori", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"), New System.Data.Common.DataColumnMapping("DataProgramma", "DataProgramma"), New System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"), New System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"), New System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"), New System.Data.Common.DataColumnMapping("Origin", "Origin"), New System.Data.Common.DataColumnMapping("ReasonCode", "ReasonCode"), New System.Data.Common.DataColumnMapping("ReasonText", "ReasonText"), New System.Data.Common.DataColumnMapping("IdFile", "IdFile")})})
        Me._daProgrammaOrarioUnitaErrori.UpdateCommand = Me._cmdUpdateProgrammaOrarioUnitaErrori
        '
        '_cmdDeleteProgrammaOrarioUnitaErrori
        '
        Me._cmdDeleteProgrammaOrarioUnitaErrori.CommandText = "DELETE FROM dbo.ProgrammaOrarioPerUnitaErrori WHERE (CategoriaUnitaSDC = @Origina" & _
        "l_CategoriaUnitaSDC) AND (CodiceUnitaSDC = @Original_CodiceUnitaSDC) AND (DataPr" & _
        "ogramma = @Original_DataProgramma) AND (IdContratto = @Original_IdContratto) AND" & _
        " (PeriodoRilevante = @Original_PeriodoRilevante) AND (IdFile = @Original_IdFile " & _
        "OR @Original_IdFile IS NULL AND IdFile IS NULL) AND (Origin = @Original_Origin) " & _
        "AND (ReasonCode = @Original_ReasonCode) AND (ReasonText = @Original_ReasonText)"
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Connection = Me._cn
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Origin", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Origin", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReasonCode", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReasonCode", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdDeleteProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReasonText", System.Data.SqlDbType.VarChar, 1024, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReasonText", System.Data.DataRowVersion.Original, Nothing))
        '
        '_cmdInsertProgrammaOrarioUnitaErrori
        '
        Me._cmdInsertProgrammaOrarioUnitaErrori.CommandText = "INSERT INTO dbo.ProgrammaOrarioPerUnitaErrori(IdContratto, DataProgramma, Periodo" & _
        "Rilevante, CodiceUnitaSDC, CategoriaUnitaSDC, Origin, ReasonCode, ReasonText, Id" & _
        "File) VALUES (@IdContratto, @DataProgramma, @PeriodoRilevante, @CodiceUnitaSDC, " & _
        "@CategoriaUnitaSDC, @Origin, @ReasonCode, @ReasonText, @IdFile); SELECT IdContra" & _
        "tto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUnitaSDC, Origin," & _
        " ReasonCode, ReasonText, IdFile FROM dbo.ProgrammaOrarioPerUnitaErrori WHERE (Ca" & _
        "tegoriaUnitaSDC = @CategoriaUnitaSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC) AND" & _
        " (DataProgramma = @DataProgramma) AND (IdContratto = @IdContratto) AND (PeriodoR" & _
        "ilevante = @PeriodoRilevante)"
        Me._cmdInsertProgrammaOrarioUnitaErrori.Connection = Me._cn
        Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
        Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
        Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
        Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
        Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
        Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Origin", System.Data.SqlDbType.VarChar, 2, "Origin"))
        Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonCode", System.Data.SqlDbType.VarChar, 15, "ReasonCode"))
		Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonText", System.Data.SqlDbType.VarChar, 1024, "ReasonText"))
        Me._cmdInsertProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, "IdFile"))
        '
        '_cmdSelectProgrammaOrarioUnitaErrori
        '
        Me._cmdSelectProgrammaOrarioUnitaErrori.CommandText = "SELECT IdContratto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUni" & _
        "taSDC, Origin, ReasonCode, ReasonText, IdFile FROM dbo.ProgrammaOrarioPerUnitaEr" & _
        "rori"
        Me._cmdSelectProgrammaOrarioUnitaErrori.Connection = Me._cn
        '
        '_cmdUpdateProgrammaOrarioUnitaErrori
        '
        Me._cmdUpdateProgrammaOrarioUnitaErrori.CommandText = "UPDATE dbo.ProgrammaOrarioPerUnitaErrori SET IdContratto = @IdContratto, DataProg" & _
        "ramma = @DataProgramma, PeriodoRilevante = @PeriodoRilevante, CodiceUnitaSDC = @" & _
        "CodiceUnitaSDC, CategoriaUnitaSDC = @CategoriaUnitaSDC, Origin = @Origin, Reason" & _
        "Code = @ReasonCode, ReasonText = @ReasonText, IdFile = @IdFile WHERE (CategoriaU" & _
        "nitaSDC = @Original_CategoriaUnitaSDC) AND (CodiceUnitaSDC = @Original_CodiceUni" & _
        "taSDC) AND (DataProgramma = @Original_DataProgramma) AND (IdContratto = @Origina" & _
        "l_IdContratto) AND (PeriodoRilevante = @Original_PeriodoRilevante) AND (IdFile =" & _
        " @Original_IdFile OR @Original_IdFile IS NULL AND IdFile IS NULL) AND (Origin = " & _
        "@Original_Origin) AND (ReasonCode = @Original_ReasonCode) AND (ReasonText = @Ori" & _
        "ginal_ReasonText); SELECT IdContratto, DataProgramma, PeriodoRilevante, CodiceUn" & _
        "itaSDC, CategoriaUnitaSDC, Origin, ReasonCode, ReasonText, IdFile FROM dbo.Progr" & _
        "ammaOrarioPerUnitaErrori WHERE (CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (Cod" & _
        "iceUnitaSDC = @CodiceUnitaSDC) AND (DataProgramma = @DataProgramma) AND (IdContr" & _
        "atto = @IdContratto) AND (PeriodoRilevante = @PeriodoRilevante)"
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Connection = Me._cn
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Origin", System.Data.SqlDbType.VarChar, 2, "Origin"))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonCode", System.Data.SqlDbType.VarChar, 15, "ReasonCode"))
		Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonText", System.Data.SqlDbType.VarChar, 1024, "ReasonText"))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, "IdFile"))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Origin", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Origin", System.Data.DataRowVersion.Original, Nothing))
        Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReasonCode", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReasonCode", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdUpdateProgrammaOrarioUnitaErrori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReasonText", System.Data.SqlDbType.VarChar, 1024, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReasonText", System.Data.DataRowVersion.Original, Nothing))
        CType(Me._ds, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._dsDatiUnita, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region

#Region "funzioni utili per generare l'id a 30 char necessario per il ME"
	Public Shared Function CreateIdOffertaMGP(ByVal pouDataProgramma As DateTime, ByVal pouPeriodoRilevante As Byte, ByVal pouIdContratto As Integer, ByVal pouCategoriaUnitaSDC As String, ByVal pouCodiceUnitaSDC As String) As String
		' devo generare in maniera iniettiva una stringa che rappresenti la programmazione per unita

		Dim tsZero As DateTime = New DateTime(2004, 1, 1)
		Dim tsp As TimeSpan = pouDataProgramma.Subtract(tsZero)
		Debug.Assert(tsp.TotalDays >= 0)
		Debug.Assert(pouPeriodoRilevante >= 1 AndAlso pouPeriodoRilevante <= 25)

		' numero di ore dal 1' gennaio 2004
		' attenzione perche` in questo meraviglioso linguaggio il cast tra reali e interi 
		' e` implicitamente fatto dal VB sommando 0.5 (dunque 2.6 ritorna 3)
		Dim hDelta As Int32 = CType(tsp.TotalDays, Int32) * 25 + (pouPeriodoRilevante - 1)
		' hDelta varia tra 0 e 2099,12,31 ore 24 e dunque
		' con un po' di calcoli tra 0 e 876623 ==> hDelta sta comodamente in un Int32
		Debug.Assert(hDelta >= 0 AndAlso hDelta <= 876623)

		' devo ora codificare questo numero in modo da sprecare meno spazio
		' uso un alfabeto di 36 simboli (0-9 e A-Z)
		' 1 36^1         36
		' 2 36^2      1.296
		' 3 36^3     46.656
		' 4 36^4  1.679.616    <== bastano 4 cifre in base 36 per rappresentare un numero tra 0 e 876.623
		' 5 36^5 60.466.176
		' 6 36^6 non sta in un int32
		Dim s4_DataOra As String = ConvertToBase36(4, hDelta)
		Debug.Assert(s4_DataOra.Length = 4)

		' in maniera analoga per IdContratto
		' uso 5 cifre --> max di 60.466.176 contratti (dovremmo stare tranquilli)
		Dim s5_IdContratto As String = ConvertToBase36(5, pouIdContratto)

		' 4 + 5 + 16 + 1 ==> 26
		Dim r As String = s4_DataOra + s5_IdContratto + pouCategoriaUnitaSDC + pouCodiceUnitaSDC
		' 0 / 4 / 9 / 10
		Debug.Assert(r.Length <= 26)
		Return r

	End Function
	Public Shared Sub DecodeIdOffertaMGP(ByVal IdOffertaMGP As String, ByRef out_IdContratto As Integer, ByRef out_DataProgramma As DateTime, ByRef out_PeriodoRilevante As Byte, ByRef out_CategoriaUnitaSDC As String, ByRef out_CodiceUnitaSDC As String)
		Debug.Assert(IdOffertaMGP.Length <= 26)

		' attenzione gli indici usati nella Substring sono allineati alla funzione sopra.
		Dim s4_DataOra As String = IdOffertaMGP.Substring(0, 4)
		Dim s5_IdContratto As String = IdOffertaMGP.Substring(4, 5)
		out_CategoriaUnitaSDC = IdOffertaMGP.Substring(9, 1)
		out_CodiceUnitaSDC = IdOffertaMGP.Substring(10)

		out_IdContratto = ConvertFromBase36(5, s5_IdContratto)

		Dim hDelta As Integer = ConvertFromBase36(4, s4_DataOra)
		Dim deltaGiorni As Integer = hDelta \ 25		  ' divisione senza resto.

		Dim tsZero As DateTime = New DateTime(2004, 1, 1)
		out_DataProgramma = tsZero.AddDays(deltaGiorni)

		out_PeriodoRilevante = CType((hDelta Mod 25) + 1, Byte)
#If DEBUG Then
		Dim r As String
		r = CreateIdOffertaMGP(out_DataProgramma, out_PeriodoRilevante, out_IdContratto, out_CategoriaUnitaSDC, out_CodiceUnitaSDC)
		Debug.Assert(r = IdOffertaMGP)
#End If
	End Sub

	Private Shared Function ConvertToBase36(ByVal numeroMaxCifre As Integer, ByVal h As Integer) As String
		Dim f36(numeroMaxCifre - 1) As Integer
		' per 4 cifre e` cosi`
		'f36(0) = 1
		'f36(1) = 36 
		'f36(2) = 36 * 36
		'f36(3) = 36 * 36 * 36
		f36(0) = 1
		For c As Integer = 1 To numeroMaxCifre - 1
			f36(c) = f36(c - 1) * 36
		Next

		Dim s36 As String = ""
		For c As Integer = numeroMaxCifre - 1 To 0 Step -1
			Dim q As Integer = h \ f36(c)			 ' divisione tra interi alla "C"
			h = h Mod f36(c)
			Debug.Assert(q >= 0 AndAlso q < 36)

			If (q < 10) Then
				' s36 += Chr(q + Asc("O"c))
				s36 += Chr(q + Asc("0"c))
			Else
				s36 += Chr(q - 10 + Asc("A"c))
			End If
		Next
		Return s36
	End Function
	Private Shared Function ConvertFromBase36(ByVal numeroMaxCifre As Integer, ByVal s64 As String) As Integer
		Debug.Assert(s64.Length = numeroMaxCifre)

		Dim f36(numeroMaxCifre - 1) As Integer
		' per 4 cifre e` cosi`
		'f36(0) = 1
		'f36(1) = 36
		'f36(2) = 36 * 36
		'f36(3) = 36 * 36 * 36
		f36(0) = 1
		For c As Integer = 1 To numeroMaxCifre - 1
			f36(c) = f36(c - 1) * 36
		Next


		Dim r As Integer = 0
		For c As Integer = numeroMaxCifre - 1 To 0 Step -1
			Dim ch As Char = s64.Chars(numeroMaxCifre - 1 - c)
			If (Asc(ch) < Asc("A"c)) Then
				r += f36(c) * (Asc(ch) - Asc("0"c))
			Else
				r += f36(c) * (10 + Asc(ch) - Asc("A"c))
			End If
		Next

		Return r
	End Function
#End Region

	Public Sub LeggiMGPBatch(ByVal dataMGP As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf LetturaMercato.LeggiMGPAsync, dataMGP, "RXMGP", "Lettura Mercato MGP", dataMGP, runningOperator)
	End Sub

	Private Shared Sub LeggiMGPAsync(ByVal obj As Object)
		Dim dataMGP As DateTime = CType(obj, DateTime)
		Dim bl As New LetturaMercato
		bl.LeggiMGPWorker(dataMGP)
		bl.Dispose()
	End Sub

	Private Sub ControllaData(ByVal dataRichiesta As String, ByVal nomefile As String, ByVal s As Integer)

		If Not AppSettingToBoolean("ControlloDataNeiFileDellAreaDiDownload", True) Then
			Return
		End If

		Dim dataLetta As String = ""
		Try
			Dim c As Integer = dataRichiesta.Length
			dataLetta = nomefile.Substring(s, c)
		Catch
			dataLetta = ""
		End Try

		If dataLetta = dataRichiesta Then Return

		Dim r As String = String.Format("LetturaMercato: Il file {0} nell'area di download non si riferisce alla data di flusso richiesta ({1})", nomefile, dataRichiesta)
		Throw New ApplicationException(r)
	End Sub


	Private Sub LeggiMGPWorker(ByVal dataMGP As DateTime)

		smWarning("rxMGP: attivita` iniziata, data richiesta {0}", dataMGP)
		smTrace("rxMGP: thread partito")

		Dim dataRichiestaYYYYMMDD As String
		dataRichiestaYYYYMMDD = String.Format("{0:yyyy}{0:MM}{0:dd}", dataMGP)
		Dim dataRichiestaYYMMDD As String
		dataRichiestaYYMMDD = String.Format("{0:yy}{0:MM}{0:dd}", dataMGP)


		' sto iniziando a leggere dal mercato --> lo segnalo nel DB
		Try
			_cn.Open()
			spNotificaStatoLetturaMGP.Parameters("@DataProgramma").Value = dataMGP
			spNotificaStatoLetturaMGP.Parameters("@eseguito").Value = False
			spNotificaStatoLetturaMGP.ExecuteNonQuery()
		Catch ex As Exception
			smError(ex)
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try

		' variabili utilizzate per tirare le somme alla fine della lettura del mercato
		Dim nDayHour As Byte = GetNumberOfHourOfDay(dataMGP)
		' array di booleani, un item per ognuno dei file che dobbiamo leggere da MGP (23/24/25)
		Dim bFileFound(nDayHour) As Boolean
		Dim iDayHour As Integer = 0
		bFileFound(0) = False
		' non si usa l'elemento zero
		For iDayHour = 1 To bFileFound.Length - 1
			bFileFound(iDayHour) = False
		Next
		Dim iCntDayHour As Integer = 0
		' booleano per lettura file MR_MGP
		Dim bFoundMR As Boolean = False

		' contatore per lettura file FA
		Dim cFoundFA As Integer = 0

		Do

			' creo il proxy per il WS del ME (attraverso BilMGPBridge)
			Dim ws As New Bil.gmeBridge.BilMGPBridge
			ws.WSAuthHeaderValue = New Bil.gmeBridge.WSAuthHeader
			Bil_Crypt.WSClient.Setup(ws, ws.WSAuthHeaderValue.Username, ws.WSAuthHeaderValue.Password, "Bil_MGPBridgeWS")

			smTrace(String.Format("rxMGP: richiesta di download file MGP"))

			' scarico il file dal ME
			Dim nomeFileRx As String
			Dim IdFile As String
			Dim by() As Byte
			by = Nothing

			Dim b As Boolean = ws.DownloadMessage(nomeFileRx, by)

			If (Not b) Then
				If iCntDayHour = 0 Then
					smTrace(String.Format("rxMGP: Non ci sono file BN da downloadare."))
				Else
					smTrace(String.Format("rxMGP: Eseguito download di {0} file BN. Non ci sono altri file BN da downloadare. ", iCntDayHour))
				End If
				If bFoundMR = False Then
					smTrace(String.Format("rxMGP: Non c'e` il file MR - Prezzi Zonali e Unitari- da downloadare."))
				End If
				If cFoundFA = 0 Then
					smTrace("rxMGP: Non ci sono file FA da downloadare.")
				Else
					smTrace("rxMGP: Eseguito download di {0} file FA. Non ci sono altri file FA da downloadare.", cFoundFA)
				End If
				Exit Do
			End If
			smWarning(String.Format("rxMGP: downloadato file {0}", nomeFileRx))


			' memorizzo il file appena letto nel DB
			Try
				Dim blFileMGP As New Bil.FileMGP
				IdFile = blFileMGP.InserisciFileMGP(Bil.FileMGP.VersoMGP.MGP_2_Bilaterali, nomeFileRx, by, True, dataMGP)
			Catch ex As Exception
				smError(ex)
			End Try


			Dim Data As DateTime = DateTime.MinValue
			Dim Ora As Byte = 255
			Dim DataOraLetti As Boolean = False

			' 
			' Considera i files:
			' "FA_<nomeFileIn>.<numero>.out.xml            ==> Functional Acknowledgment
			' nomeFileIn e` BIL_OFFERTE_<YYMMDD>_<HH>      es BIL_OFFERTE_050723_1
			' per cui per noi sara` FA_BIL_OFFERTE_050723_1.52030905537947.out.xml

			' "BN_MGPP_<YYYYMMDD>_<HH>.<numero>.out.xml"   ==> BidNotification MGP Provvisorio
			' "BN_MGPD_<YYYYMMDD>_<HH>.<numero>.out.xml"   ==> BidNotification MGP Definitivo 
			' "MR_MGP_<YYYYMMDD>.<numero>.out.xml"         ==> Market Result MGP Definitivo
			'
			If nomeFileRx.StartsWith("BN_MGP") Then

				ControllaData(dataRichiestaYYYYMMDD, nomeFileRx, "BN_MGPP_".Length)

				' file BN_MGPP o BN_MGPD ==> BidNotification MGP Provvisorio, BidNotification MGP Definitivo 
				smTrace(String.Format("rxMGP: lettura del file {0}", nomeFileRx))

				Dim blLettura As New Bil.LetturaMercato
				Dim lm As Boolean = blLettura.LeggiNotificheMercato(by, IdFile, Data, Ora)
				DataOraLetti = True
				smTrace(String.Format("rxMGP: fine lettura del file {0}, giorno:{1:yyyy}{1:MM}{1:dd}, ora:{2} esito:{3}.", nomeFileRx, Data, Ora, lm))
				BatchSerializer.SetProgressBatch(String.Format("rxMGP: Lettura del file {0}, giorno:{1:yyyy}{1:MM}{1:dd}, ora:{2} esito:{3}.", nomeFileRx, Data, Ora, lm))
				If lm = True Then
					bFileFound(Ora) = True
					iCntDayHour += 1
				End If

			ElseIf nomeFileRx.StartsWith("MR_MGP") Then

				ControllaData(dataRichiestaYYYYMMDD, nomeFileRx, "MR_MGP_".Length)

				' file MR_MGP ==> Market Result MGP Definitivo
				smTrace(String.Format("rxMGP: lettura del file {0}", nomeFileRx))
				Dim blPrezzi As New Bil.MarketResult
				Dim lm As Boolean = blPrezzi.LeggiPrezziZonaliUnitari(nomeFileRx, by, Data)
				smTrace(String.Format("rxMGP: Fine lettura del file esito:{0}.", lm))
				If lm Then
					DataOraLetti = True
					BatchSerializer.SetProgressBatch(String.Format("rxMGP: Fine lettura del file MR_MGP {0}, prezzi letti con successo per la data {1:dd}/{1:MM}/{1:yyyy}", nomeFileRx, Data))
				Else
					BatchSerializer.SetProgressBatch(String.Format("rxMGP: Fine lettura del file MR_MGP {0}, lettura prezzi fallita", nomeFileRx))
				End If
				bFoundMR = lm

			ElseIf nomeFileRx.StartsWith("FA_") Then

				ControllaData(dataRichiestaYYMMDD, nomeFileRx, "FA_BIL_OFFERTE_".Length)

				' FA_ ==> Functional Acknowledgment
				smTrace(String.Format("rxFA: lettura del file {0}", nomeFileRx))
				Dim blLettura As New Bil.LetturaMercato
				Dim lm As Boolean = blLettura.LeggiFunctionalAcknowledgementMercato(by, nomeFileRx, IdFile, Data, Ora)
				DataOraLetti = True

				smTrace("rxFA: Fine lettura del file FA {0}, esito:{1}.", nomeFileRx, lm)
				If lm = True Then cFoundFA += 1

			End If


			Try
				If DataOraLetti AndAlso Data <> DateTime.MinValue AndAlso Ora <> 255 Then

					smTrace("rxMGP: Il file appena processato si riferiva alla data/ora {0:yyyy}{0:MM}{0:dd}/{1}.", Data, Ora)

					Dim blFileMGP As New Bil.FileMGP
					blFileMGP.UpdateDataOraFileMGP(IdFile, Data)
				End If
			Catch ex As Exception
				smError(ex)
			End Try

			' ho macinato il file --> ora lo rimuovo
			smTrace("rxMGP: Richiesta di rimozione del file {0}.", nomeFileRx)
			ws.RemoveFirstFile()
			smWarning("rxMGP: Rimozione del file {0} eseguita.", nomeFileRx)

		Loop

		' se ho ricevuto tutte le ore posso indicare nel DB che le offerte sono state lette.
		Dim reasonText As String
		If CheckFileOfferte(bFileFound, iCntDayHour, reasonText) = True And bFoundMR Then
			Try
				_cn.Open()
				spNotificaStatoLetturaMGP.Parameters("@DataProgramma").Value = dataMGP
				spNotificaStatoLetturaMGP.Parameters("@eseguito").Value = True
				spNotificaStatoLetturaMGP.ExecuteNonQuery()
			Catch ex As Exception
				smError(ex)
			Finally
				If _cn.State = ConnectionState.Open Then _cn.Close()
			End Try
		Else
			Dim sEsitoFA As String
			If cFoundFA = 0 Then
				sEsitoFA = String.Format("Non ci sono file FA da leggere.")
			Else
				sEsitoFA = String.Format("Eseguita lettura di {0} file FA. ", cFoundFA)
			End If
			reasonText += "."
			reasonText += sEsitoFA
			BatchSerializer.SetProgressBatch(reasonText)
		End If

		smTrace(String.Format("rxMGP: Attivita` terminata."))

	End Sub


#Region "lettura BN_MGPP o BN_MGPD ==> BidNotification MGP Provvisorio, BidNotification MGP Definitivo "

	Private Function LeggiNotificheMercato(ByVal abyContenutoFileNotifiche() As Byte, ByVal IdFile As String, ByRef Data As DateTime, ByRef ora As Byte) As Boolean

		' Errore parametri di input
		If (abyContenutoFileNotifiche Is Nothing) Then
			smError("Error binary data NULL")
			Throw New ArgumentException("Error binary data NULL")
		End If

		Try
			Dim strDataRiferimento As String
			Dim strOraRiferimento As String
			' Estraggo la data e l'ora di riferimento da utilizzare come confronto con quelle
			' contenute in tutte le BidNotification
			If Not (LeggiDataOraRiferimento(abyContenutoFileNotifiche, strDataRiferimento, strOraRiferimento)) Then
				smError("Error getting Data and Hour TAG in file XML")
				Return False
			End If

			' Converto le stringhe della data e dell'ora in un opportuno formato
			'Dim data As DateTime = ConvertDate(strDataRiferimento)
			Data = ConvertDate(strDataRiferimento)
			'Dim ora As Byte = ConvertHour(strOraRiferimento)
			ora = ConvertHour(strOraRiferimento)

			' Estraggo i record dalla tabella ProgrammaOrarioPerUnita relative alla data ed ora 
			' sopra calcolate
			_cn.Open()

			Dim dsProgrammiOrari As DS_LetturaMercatoProgrammiOrarioUnita = GetDataSetProgrammaOrarioUnita(Data, ora)
			If (dsProgrammiOrari Is Nothing) Then
				smError("Error non esistono ProgrammiOrari per Unita per la data='" & _
				  strDataRiferimento & "' e per l'ora='" & strOraRiferimento & "'")
				Throw New ApplicationException("Error non esistono ProgrammiOrari per Unita per la data='" & _
				  strDataRiferimento & "' e per l'ora='" & strOraRiferimento & "'")
			End If

			' prima di leggere i nuovi valori, resetto quelli vecchi
			' (magari ho letto gia` questo ora... hanno fatto ri-andare il mercato)
			If True Then
				For i As Integer = 0 To dsProgrammiOrari.ProgrammiOrari.Rows.Count - 1
					Dim dr As DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow
					dr = dsProgrammiOrari.ProgrammiOrari(i)
					' dr.SetGMEReferenceNumberNull() questo lo tengo perche` l'ID dell'offerta NON cambia
					dr.SetQtyMWhAssegnataMGPNull()
				Next
			End If

			Dim dsProgrammiOrariErrori As DS_LetturaMercatoProgrammiOrariErrori = GetDataSetProgrammaOrarioUnitaErrori(Data, ora)

			' Recupero i vari coefficienti utili per ogni Unita
			Dim dsDatiUnita As DS_DatiPerditeUnita = GetDataSetDatiUnita()
			If (dsDatiUnita Is Nothing) Then
				smError("Error non esistono Unita valide")
				Throw New ApplicationException("Error non esistono Unita valide nel Sistema")
			End If

			' Lettura delle BidNotification
			Dim bidDealer As New BidNotificationDealer(_cn, abyContenutoFileNotifiche)
			With bidDealer
				.DataRiferimento = strDataRiferimento
				.OraRiferimento = strOraRiferimento
				.ListaDatiUnita = dsDatiUnita
				.ListaProgrammi = dsProgrammiOrari
				.ListaProgrammiErrori = dsProgrammiOrariErrori
				.IdFile = IdFile
			End With

			' Parsing del file XML
			Dim isParsingOK As Boolean = bidDealer.ParseXML()
			If (isParsingOK) Then
				SaveDataSets(dsProgrammiOrari, dsProgrammiOrariErrori)
			End If
			Return True
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function
#End Region

#Region "lettura FA_ ==> Functional Acknowledgment"

	Private Function LeggiFunctionalAcknowledgementMercato(ByVal abyContenutoFileFA() As Byte, ByVal fileNameFA As String, ByVal IdFile As String, ByRef outData As DateTime, ByRef outOra As Byte) As Boolean

		' Errore parametri di input
		If (abyContenutoFileFA Is Nothing) Then
			smError("Error binary data NULL")
			Throw New ArgumentException("Error binary data NULL")
		End If

		Try
			Dim strDataRiferimento As String
			Dim strOraRiferimento As String

			'
			' Provo a estrarre l'ora di riferimento dal content
			'
			If Not (LeggiDataOraRiferimentoFADalContent(abyContenutoFileFA, strDataRiferimento, strOraRiferimento)) Then
				smError("Error getting Data and Hour TAG in file content XML")
				' Estraggo la data e l'ora di riferimento dal nome del file: ipotizzo che dal nome 
				' si possano estrarre data - ora: estrema Ratio perche' il sistema bilaterali
				' nel caso non ci siano offerte per un'ora genera files senza offerte: l'FA corrispondente
				' non contiene dati (MPN) per estrarre Data e Ora di riferimento
				If Not (LeggiDataOraRiferimentoFADalFile(fileNameFA, strDataRiferimento, strOraRiferimento)) Then
					smError("Error getting Data and Hour TAG in FA file name")
					Return False
				End If
			End If


			' Converto le stringhe della data e dell'ora in un opportuno formato
			Dim data As DateTime = ConvertDate(strDataRiferimento)
			Dim ora As Byte = ConvertHour(strOraRiferimento)

			outData = data
			outOra = ora

			' Estraggo i record dalla tabella ProgrammaOrarioPerUnita relative alla data ed ora 
			' sopra calcolate
			_cn.Open()

			Dim dsProgrammiOrari As DS_LetturaMercatoProgrammiOrarioUnita = GetDataSetProgrammaOrarioUnita(data, ora)
			If (dsProgrammiOrari Is Nothing) Then
				smError("Error non esistono ProgrammiOrari per Unita per la data='" & _
				  strDataRiferimento & "' e per l'ora='" & strOraRiferimento & "'")
				Throw New ApplicationException("Error non esistono ProgrammiOrari per Unita per la data='" & _
				  strDataRiferimento & "' e per l'ora='" & strOraRiferimento & "'")
			End If

			Dim dsProgrammiOrariErrori As DS_LetturaMercatoProgrammiOrariErrori = GetDataSetProgrammaOrarioUnitaErrori(data, ora)

			' Lettura delle FunctionalAcknowledgement
			Dim FADealer As New FunctionalAcknowledgmentDealer(_cn, abyContenutoFileFA)
			With FADealer
				.DataRiferimento = strDataRiferimento
				.OraRiferimento = strOraRiferimento
				.ListaProgrammi = dsProgrammiOrari
				.ListaProgrammiErrori = dsProgrammiOrariErrori
				.IdFile = IdFile
			End With

			' Parsing del file XML
			Dim isParsingOK As Boolean = FADealer.ParseXML()
			If (isParsingOK) Then
				SaveDataSets(dsProgrammiOrari, dsProgrammiOrariErrori)
			End If
			Return True
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not (_cn Is Nothing) Then _cn.Close()
		End Try
	End Function
#End Region

#Region " Classe per il parsing del file XML delle BidNotification "

	Class BidNotificationDealer
		Private xmlContentFile() As Byte
		Private dsDatiUnita As DS_DatiPerditeUnita
		Private dsProgOrarioUnita As DS_LetturaMercatoProgrammiOrarioUnita
		Private dsProgOrariErrori As DS_LetturaMercatoProgrammiOrariErrori
		Private db As SqlClient.SqlConnection
		Private htUnita As Hashtable
		Private htMPN As Hashtable
		Private htMPNErr As Hashtable
		Private ora As String
		Private data As String
		Private GeneraOfferteSoloPerProgrammiBilanciati As Boolean
		Private _idfile As String

		Class DatiUnita
			Private CoefficientePerditaUnita As Double
			Private CoefficentePerditaPSR As Double
			Private _KuDivKp As Double = 1
			Private IdUnita As String
			Public Sub New(ByVal id As String, ByVal cpu As Double, ByVal cppsr As Double)
				Me.IdUnita = id
				Me.CoefficentePerditaPSR = cppsr
				Me.CoefficientePerditaUnita = cpu
				Try
					Me._KuDivKp = Me.CoefficientePerditaUnita / Me.CoefficentePerditaPSR
				Catch ex As Exception
					SystemMonitor.SmLog.smError("Error PSR Loss Factor equal zero")
					Me._KuDivKp = 1

				End Try
			End Sub
			Public Function KuDivKp() As Double
				Return Me._KuDivKp
			End Function
		End Class

		Structure XMLTemporaryData
			Public status As String
			Public reasonCode As String
			Public reasonText As String
			Public purpose As String
			Public partialQtyIndicator As String
			Public awardedQty As Double
			Public idUnita As String
			Public GMEReferenceNumber As String
			Public MPN As String
			Public Sub Init()
				status = String.Empty
				purpose = String.Empty
				partialQtyIndicator = String.Empty
				awardedQty = 0.0
				GMEReferenceNumber = String.Empty
				reasonCode = String.Empty
				reasonText = String.Empty
				MPN = String.Empty
			End Sub
		End Structure
		Private Sub BuildHashTableUnita()
			Debug.Assert(Not Me.dsDatiUnita Is Nothing)
			Dim du As DatiUnita

			If Not (Me.dsDatiUnita Is Nothing) Then
				For Each dr As DS_DatiPerditeUnita.DatiUnitaRow In Me.dsDatiUnita.DatiUnita.Rows
					du = New DatiUnita(dr.CodiceUnita, dr.PUNITA, dr.PPDSR)
					Me.htUnita.Add(dr.CodiceUnita, du)
				Next
			End If

		End Sub

		Private Sub BuildHashTableProgrammiOrario()
			Debug.Assert(Not Me.dsProgOrarioUnita Is Nothing)

			If Not (Me.dsProgOrarioUnita Is Nothing) Then
				For Each dr As DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow In Me.dsProgOrarioUnita.ProgrammiOrari.Rows
					Dim MPN As String = CreateIdOffertaMGP(dr.DataProgramma, dr.PeriodoRilevante, dr.IdContratto, dr.CategoriaUnitaSDC, dr.CodiceUnitaSDC)
					Me.htMPN.Add(MPN, dr)
				Next
			End If
		End Sub

		Private Sub BuildHashTableProgrammiOrariErrori()
			Debug.Assert(Not Me.dsProgOrariErrori Is Nothing)

			If Not (Me.dsProgOrariErrori Is Nothing) Then
				For Each dr As DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow In Me.dsProgOrariErrori.ProgrammiOrariErrori.Rows
					Dim MPN As String = CreateIdOffertaMGP(dr.DataProgramma, dr.PeriodoRilevante, dr.IdContratto, dr.CategoriaUnitaSDC, dr.CodiceUnitaSDC)
					Me.htMPNErr.Add(MPN, dr)
				Next
			End If
		End Sub

		Public Sub New(ByVal dbConn As SqlClient.SqlConnection, ByVal contentFile() As Byte)
			Me.xmlContentFile = contentFile
			Me.db = dbConn
			htUnita = New Hashtable
			htMPN = New Hashtable
			htMPNErr = New Hashtable

			Me.GeneraOfferteSoloPerProgrammiBilanciati = False
			If True Then
				Dim s As String = ConfigurationSettings.AppSettings("GeneraOfferteSoloPerProgrammiBilanciati")
				If (Not s Is Nothing) Then
					s = s.ToLower()
					If (s = "1" OrElse s = "si" OrElse s = "yes" OrElse s = "true") Then
						GeneraOfferteSoloPerProgrammiBilanciati = True
					End If
				End If
			End If
		End Sub

		Public WriteOnly Property DataRiferimento() As String
			Set(ByVal Value As String)
				Me.data = Value
			End Set
		End Property

		Public WriteOnly Property OraRiferimento() As String
			Set(ByVal Value As String)
				Me.ora = Value
			End Set
		End Property

		Public WriteOnly Property ListaDatiUnita() As DS_DatiPerditeUnita
			Set(ByVal Value As DS_DatiPerditeUnita)
				Me.dsDatiUnita = Value
				BuildHashTableUnita()
			End Set
		End Property

		Public WriteOnly Property ListaProgrammi() As DS_LetturaMercatoProgrammiOrarioUnita
			Set(ByVal Value As DS_LetturaMercatoProgrammiOrarioUnita)
				Me.dsProgOrarioUnita = Value
				BuildHashTableProgrammiOrario()
			End Set
		End Property

		Public WriteOnly Property ListaProgrammiErrori() As DS_LetturaMercatoProgrammiOrariErrori
			Set(ByVal Value As DS_LetturaMercatoProgrammiOrariErrori)
				Me.dsProgOrariErrori = Value
				BuildHashTableProgrammiOrariErrori()
			End Set
		End Property

		Public WriteOnly Property IdFile() As String
			Set(ByVal Value As String)
				Me._idfile = Value
			End Set
		End Property



		Private Sub SetQtyAssegnata(ByVal dr As DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow, _
		  ByVal drErrors As DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow, _
		 ByVal xmlTemp As XMLTemporaryData)
			' Il controllo sulla validita' dei vari valori (Status, Purpose etc.) viene fatta in fase di parsing
			' dell'XML.
			' Chi chiama questa funzione DEVE passare dei valori consentiti
			Dim qty As Double = 0.0
			Dim bOK As Boolean = True
			Dim outIdContratto As Integer
			Dim outDataProgramma As DateTime
			Dim outPeriodoRilevante As Byte
			Dim outCategoriaSDC As String
			Dim outUnitaSDC As String
			Dim bNewRow As Boolean = False

			' se ho stato accettato la qty la ritrovo nella qty programmata dai bilaterali
			' se ho stato parzialmente accettata in awardedQty ho la Qty al CP --> devo andare verso
			' l'unita ==> Qty * Kp/Ku = Qcp
			' e l'inverso
			' Qty = Qcp * Ku / Kp

			If (xmlTemp.status = "Accept") Then

				'If (xmlTemp.partialQtyIndicator = "No") Then
				'	If Not (dr.IsQtyMWhBilanciamentoNull) Then
				'		qty = dr.QtyMWhBilanciamento
				'	Else
				'		qty = dr.QtyMWh
				'	End If

				'ElseIf (xmlTemp.partialQtyIndicator = "Yes") Then

				'	If (htUnita.ContainsKey(xmlTemp.idUnita)) Then
				'		Dim du As DatiUnita = DirectCast(htUnita.Item(xmlTemp.idUnita), DatiUnita)
				'		Dim sign As Double
				'		If (xmlTemp.purpose = "Sell") Then
				'			sign = 1.0
				'		ElseIf (xmlTemp.purpose = "Buy") Then
				'			sign = -1.0
				'		End If
				'		' la formula dovrebbe essere Qcp = Q * Kp/Ku
				'		' Q = Qcp * Ku / Kp
				'		qty = xmlTemp.awardedQty * du.KuDivKp * sign
				'	End If

				'End If

				If (htUnita.ContainsKey(xmlTemp.idUnita)) Then
					Dim du As DatiUnita = DirectCast(htUnita.Item(xmlTemp.idUnita), DatiUnita)
					Dim sign As Double
					If (xmlTemp.purpose = "Sell") Then
						sign = 1.0
					ElseIf (xmlTemp.purpose = "Buy") Then
						sign = -1.0
					End If
					' la formula dovrebbe essere Qcp = Q * Kp/Ku
					' Q = Qcp * Ku / Kp
					qty = xmlTemp.awardedQty * du.KuDivKp * sign
				End If

			ElseIf (xmlTemp.status = "Reject") Then

				qty = 0
				bOK = False

			End If


			' se la quantita e` gia` assegnata puo` essere per due motivi
			' 1) il mercato e` gia` stato eseguito
			' 2) la MPN e` descritta 2 volte nel file BN_MGP....
			If (dr.IsQtyMWhAssegnataMGPNull = False) Then
				' SmLog.smError(String.Format("MWhAssegnataMGP is not NULL in MPN '{0}' (duplicated in BN_MGP?)", CreateIdOffertaMGP(dr.DataProgramma, dr.PeriodoRilevante, dr.IdContratto, dr.CategoriaUnitaSDC, dr.CodiceUnitaSDC)))
			End If

			dr.GMEReferenceNumber = xmlTemp.GMEReferenceNumber
			'If bOK Then dr.QtyMWhAssegnataMGP = Math.Round(qty, 3)
			If bOK Then dr.QtyMWhAssegnataMGP = qty

			' Qui viene aggiornata la tabella errori
			' 
			If bOK Then
				' BidNotification per offerta accettata o parzialmente accettata:
				' cancella in ogni caso eventuali errori precedenti
				'
				If Not (drErrors Is Nothing) Then
					drErrors.Delete()
				End If
			Else
				' BidNotification per offerta rifiutata:
				' Inserisci nuovo errore oppure aggiorna errore preesistente
				'
				If drErrors Is Nothing Then
					'
					' Aggiungi una nuova riga di errori
					'
					drErrors = DirectCast(dsProgOrariErrori.ProgrammiOrariErrori.NewRow(), DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow)

					'
					' Estrai dati da MPN (questa funzione dovrebbe essere corretta)
					'
					DecodeIdOffertaMGP(xmlTemp.MPN, outIdContratto, outDataProgramma, outPeriodoRilevante, outCategoriaSDC, outUnitaSDC)

					drErrors.IdContratto = outIdContratto
					drErrors.DataProgramma = outDataProgramma
					drErrors.PeriodoRilevante = outPeriodoRilevante
					drErrors.CategoriaUnitaSDC = outCategoriaSDC
					drErrors.CodiceUnitaSDC = outUnitaSDC
					bNewRow = True
				End If
				drErrors.Origin = "BN"
				If (xmlTemp.reasonCode = "") Then
					drErrors.ReasonCode = "UNKCD"
				Else
					drErrors.ReasonCode = xmlTemp.reasonCode
				End If
				If (xmlTemp.reasonText = "") Then
					drErrors.ReasonText = "Descrizione sconosciuta "
				Else
					drErrors.ReasonText = xmlTemp.reasonText
				End If
				drErrors.IdFile = Me._idfile

				If bNewRow Then
					dsProgOrariErrori.ProgrammiOrariErrori.Rows.Add(drErrors)
				End If
			End If
		End Sub

		Private Sub ValidationEvent(ByVal sender As Object, ByVal e As ValidationEventArgs)
			SystemMonitor.SmLog.smError(e.Exception, e.Message)
		End Sub

		Public Function ParseXML() As Boolean
			' Assegno lo schema per la Validazione
			Dim xr As XmlValidatingReader
			'=================== CONTROLLO SCHEMA PER IL FILE XML =============================================
			Try
				Dim fileSchema As String = BilBLBase.GetCompleteFileNameFromAppSettings("BN.BidNotificationDocument.xsd")
				If fileSchema Is Nothing Then
					SystemMonitor.SmLog.smError("""BidNotificationDocument.xsd"" non e` presente nel file di configurazione")
					Return False
				End If

				Dim sc As XmlSchemaCollection = New XmlSchemaCollection
				sc.Add(Nothing, fileSchema)

				Dim textReader As XmlTextReader = New XmlTextReader(New MemoryStream(Me.xmlContentFile))
				textReader.WhitespaceHandling = WhitespaceHandling.None
				xr = New XmlValidatingReader(textReader)
				xr.ValidationType = ValidationType.Schema
				xr.Schemas.Add(sc)
				AddHandler xr.ValidationEventHandler, AddressOf Me.ValidationEvent

			Catch ex As Exception
				Debug.Assert(False)				' se non trova il file degli schemi
				SystemMonitor.SmLog.smError(ex)
				Return False
			End Try
			'=================== PARSING FILE XML =============================================
			Try
				Dim cultureInfoIT As New CultureInfo("it-IT")				  ' per leggere i double in italiano

				'======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
				Dim elPIPTransaction As Object = xr.NameTable.Add("PIPTransaction")
				Dim elBidNotification As Object = xr.NameTable.Add("BidNotification")
				Dim elMarketParticipantNumber As Object = xr.NameTable.Add("MarketParticipantNumber")
				Dim elUnitReferenceNumber As Object = xr.NameTable.Add("UnitReferenceNumber")
				Dim elDate As Object = xr.NameTable.Add("Date")
				Dim elHour As Object = xr.NameTable.Add("Hour")
				Dim elAwardedQuantity As Object = xr.NameTable.Add("AwardedQuantity")
				Dim elGMEReferenceNumber As Object = xr.NameTable.Add("GMEReferenceNumber")
				Dim elReasonText As Object = xr.NameTable.Add("ReasonText")
				Dim elReason As Object = xr.NameTable.Add("Reason")

				' Dati temporanei utilizzati per ogni elemento PIPTransaction
				Dim currentRow As DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow = Nothing
				Dim currentRowErr As DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow = Nothing
				Dim xmlData As New XMLTemporaryData

				'============================== INIZIO PARSING DEL FILE XML =========================
				While (xr.Read())
					Dim xrn As Object = xr.Name

					Select Case xr.NodeType
						Case XmlNodeType.Element

							'=================== MARKET PARTICIPANT NUMBER ======================
							If (xrn Is elMarketParticipantNumber) Then
								Dim xmlMPN As String
								xmlMPN = xr.ReadString()

								If (xmlMPN Is Nothing) OrElse (xmlMPN = String.Empty) Then
									Debug.Assert(False)
									SystemMonitor.SmLog.smError("Error MPN NULL in xml")
								End If
								' Verifico che la stringa contenuta nel TAG MarketParticipantNumber
								' sia contenuta nella HashTable
								Debug.Assert(htMPN.ContainsKey(xmlMPN), "Se succede significa che il GME ha delle offerte VECCHIE che i bilaterali non ha piu`")
								If htMPN.ContainsKey(xmlMPN) Then
									currentRow = DirectCast(htMPN.Item(xmlMPN), DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow)
								Else
									SystemMonitor.SmLog.smError("Error MPN='" & xmlMPN & "' not present in table ProgrammaOrarioPerUnita")
									Throw New ApplicationException("Error MPN='" & xmlMPN & "' not present in table ProgrammaOrarioPerUnita")
								End If

								If htMPNErr.ContainsKey(xmlMPN) Then
									currentRowErr = DirectCast(htMPNErr.Item(xmlMPN), DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow)
								End If
								xmlData.MPN = xmlMPN


								'============== GEM reference number =====================
							ElseIf (xrn Is elGMEReferenceNumber) Then
								xmlData.GMEReferenceNumber = xr.ReadString()

								'============== BID NOTIFICATION =====================
							ElseIf (xrn Is elBidNotification) Then
								Dim xmlStatus As String
								Dim xmlPurpose As String
								Dim xmlPartialQtyIndicator As String
								' Estraggo gli attributi e ne verifico la correttezza....
								' NON Dovrebbe servire dato che uso un XmlValidatorReader pero' se si 
								' passera' poi ad un XmlTextReader potra' diventare utile
								xmlStatus = xr.GetAttribute("Status")
								If (xmlStatus <> "Accept" AndAlso xmlStatus <> "Reject") Then
									SystemMonitor.SmLog.smError("Error Status attribute not valid")
									Throw New ApplicationException("Error Status attribute not valid")
								Else
									xmlData.status = xmlStatus
								End If

								xmlPurpose = xr.GetAttribute("Purpose")
								If (xmlPurpose <> "Sell" AndAlso xmlPurpose <> "Buy") Then
									SystemMonitor.SmLog.smError("Error Purpose attribute not valid")
									Throw New ApplicationException("Error Purpose attribute not valid")
								Else
									xmlData.purpose = xmlPurpose
								End If

								If xmlStatus <> "Reject" Then
									xmlPartialQtyIndicator = xr.GetAttribute("PartialAcceptedQuantityIndicator")
									If Not (xmlPartialQtyIndicator = "No" OrElse xmlPartialQtyIndicator = "Yes") Then
										SystemMonitor.SmLog.smError("Error PartialAcceptedQuantityIndicator attribute not valid")
										Throw New ApplicationException("Error PartialAcceptedQuantityIndicator attribute not valid")
									Else
										xmlData.partialQtyIndicator = xmlPartialQtyIndicator
									End If
								Else
									xmlData.partialQtyIndicator = Nothing
								End If

								'============== REASON CODE =====================
							ElseIf (xrn Is elReason) Then
								If xmlData.status = "Reject" Then xmlData.reasonCode = xr.ReadString()

								'============== REASON TEXT =====================
							ElseIf (xrn Is elReasonText) Then
								If xmlData.status = "Reject" Then xmlData.reasonText = xr.ReadString()

								'============== UNIT REFERENCE NUMBER =====================
							ElseIf (xrn Is elUnitReferenceNumber) Then
								Dim xmlUnitReferenceNumber As String = xr.ReadString()
								xmlData.idUnita = xmlUnitReferenceNumber
								If (currentRow.CodiceUnitaSDC <> xmlData.idUnita) Then
									SystemMonitor.SmLog.smError("Il MarketParticipantNumber si riferisce ad una unita` diversa da quella specificata in UnitReferenceNumber")
									Throw New ApplicationException("Il MarketParticipantNumber si riferisce ad una unita` diversa da quella specificata in UnitReferenceNumber")
								End If

								'============== AWARDED QUANTITY =====================
							ElseIf (xrn Is elAwardedQuantity) Then
								Try
									xmlData.awardedQty = Convert.ToDouble(xr.ReadString(), cultureInfoIT)
								Catch ex As Exception
									SystemMonitor.SmLog.smError(ex, "Error tag AwardedQuantity is not a number")
									Throw New ApplicationException("Error tag AwardedQuantity is not a number")
								End Try
								'============== DATE =====================
							ElseIf (xrn Is elDate) Then
								Dim xmlDate As String = xr.ReadString()
								' Check che la data di TUTTE le Bid Notification siano uguali
								If Not (Me.data Is Nothing) AndAlso (Me.data <> String.Empty) Then
									If (Me.data <> xmlDate) Then
										SystemMonitor.SmLog.smError("Error Bid Notification with wrong Date")
										Throw New ApplicationException("Error Bid Notification with wrong Date")
									End If
								End If

								'============== HOUR =====================
							ElseIf (xrn Is elHour) Then
								Dim xmlHour As String = xr.ReadString()
								' Check che l'ora di TUTTE le Bid Notification siano uguali
								If Not (Me.ora Is Nothing) AndAlso (Me.ora <> String.Empty) Then
									If (Me.ora <> xmlHour) Then
										SystemMonitor.SmLog.smError("Error Bid Notification with wrong Hour")
										Throw New ApplicationException("Error Bid Notification with wrong Hour")
									End If
								End If
							End If

						Case XmlNodeType.EndElement

							'=============== BID NOTIFICATION END =====================
							If (xrn Is elBidNotification) Then
								' Sono sicuro di aver letto TUTTI i dati
								Debug.Assert(Not currentRow Is Nothing)
								If (currentRow Is Nothing) Then
									SystemMonitor.SmLog.smError("Error MarketParticipantNumber TAG not present in xml")
									Throw New ApplicationException("Error MarketParticipantNumber TAG not present in xml")
								End If

								' Assegno la Quantita' al DataRow 
								SetQtyAssegnata(currentRow, _
								 currentRowErr, _
								 xmlData)

								' Inizializzo i dati temporanei
								currentRow = Nothing
								currentRowErr = Nothing
								xmlData.Init()
							End If
					End Select
				End While
				Return True
			Catch ex As Exception
				SystemMonitor.SmLog.smError(ex, "Error parsing xml file")
				Throw
			Finally
				If Not xr Is Nothing Then xr.Close()
			End Try
		End Function
	End Class

#End Region

#Region "Classe per il parsing del file XML delle Functional Acknowledgement"

	Class FunctionalAcknowledgmentDealer
		Private xmlContentFile() As Byte
		Private dsProgOrarioUnita As DS_LetturaMercatoProgrammiOrarioUnita
		Private dsProgOrariErrori As DS_LetturaMercatoProgrammiOrariErrori
		Private db As SqlClient.SqlConnection
		Private htMPN As Hashtable
		Private htMPNErr As Hashtable
		Private ora As String
		Private data As String
		Private _idfile As String

		Structure XMLTemporaryData
			Public status As String
			Public reasonCode As String
			Public reasonText As String
			Public GMEReferenceNumber As String
			Public MPN As String
			Public Sub Init()
				status = String.Empty
				GMEReferenceNumber = String.Empty
				reasonText = String.Empty
				reasonCode = String.Empty
				MPN = String.Empty
			End Sub
		End Structure
		Private Sub BuildHashTableProgrammiOrario()
			Debug.Assert(Not Me.dsProgOrarioUnita Is Nothing)

			If Not (Me.dsProgOrarioUnita Is Nothing) Then
				For Each dr As DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow In Me.dsProgOrarioUnita.ProgrammiOrari.Rows
					Dim MPN As String = CreateIdOffertaMGP(dr.DataProgramma, dr.PeriodoRilevante, dr.IdContratto, dr.CategoriaUnitaSDC, dr.CodiceUnitaSDC)
					Me.htMPN.Add(MPN, dr)
				Next
			End If
		End Sub
		Private Sub BuildHashTableProgrammiOrariErrori()
			Debug.Assert(Not Me.dsProgOrariErrori Is Nothing)

			If Not (Me.dsProgOrariErrori Is Nothing) Then
				For Each dr As DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow In Me.dsProgOrariErrori.ProgrammiOrariErrori.Rows
					Dim MPN As String = CreateIdOffertaMGP(dr.DataProgramma, dr.PeriodoRilevante, dr.IdContratto, dr.CategoriaUnitaSDC, dr.CodiceUnitaSDC)
					Me.htMPNErr.Add(MPN, dr)
				Next
			End If
		End Sub

		Public Sub New(ByVal dbConn As SqlClient.SqlConnection, ByVal contentFile() As Byte)
			Me.xmlContentFile = contentFile
			Me.db = dbConn
			htMPN = New Hashtable
			htMPNErr = New Hashtable
		End Sub

		Public WriteOnly Property DataRiferimento() As String
			Set(ByVal Value As String)
				Me.data = Value
			End Set
		End Property

		Public WriteOnly Property OraRiferimento() As String
			Set(ByVal Value As String)
				Me.ora = Value
			End Set
		End Property

		Public WriteOnly Property IdFile() As String
			Set(ByVal Value As String)
				Me._idfile = Value
			End Set
		End Property


		Public WriteOnly Property ListaProgrammi() As DS_LetturaMercatoProgrammiOrarioUnita
			Set(ByVal Value As DS_LetturaMercatoProgrammiOrarioUnita)
				Me.dsProgOrarioUnita = Value
				BuildHashTableProgrammiOrario()
			End Set
		End Property

		Public WriteOnly Property ListaProgrammiErrori() As DS_LetturaMercatoProgrammiOrariErrori
			Set(ByVal Value As DS_LetturaMercatoProgrammiOrariErrori)
				Me.dsProgOrariErrori = Value
				BuildHashTableProgrammiOrariErrori()
			End Set
		End Property

		Private Sub SetQtyAssegnata(ByVal drProg As DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow, _
		 ByVal drErrors As DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow, _
		 ByVal xmlTemp As XMLTemporaryData)

			' Il controllo sulla validita' dei vari valori (Status, Purpose etc.) viene fatta in fase di parsing
			' dell'XML.
			' Chi chiama questa funzione DEVE passare dei valori consentiti
			Dim bOK As Boolean = True
			Dim outIdContratto As Integer
			Dim outDataProgramma As DateTime
			Dim outPeriodoRilevante As Byte
			Dim outCategoriaSDC As String
			Dim outUnitaSDC As String
			Dim bNewRow As Boolean = False

			If (xmlTemp.status = "Reject") Then
				bOK = False
			End If

			'
			' set GME Reference Number su DataRow Programmi
			'
			drProg.GMEReferenceNumber = xmlTemp.GMEReferenceNumber

			If bOK Then
				' Transazione accettata: 
				' cancella errori precedenti
				'
				If Not (drErrors Is Nothing) Then
					drErrors.Delete()
				End If
			Else
				If drErrors Is Nothing Then
					'
					' Aggiungi una nuova riga di errori
					'
					drErrors = DirectCast(dsProgOrariErrori.ProgrammiOrariErrori.NewRow(), DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow)

					'
					' Estrai chiave da MPN (questa funzione dovrebbe essere corretta)
					'
					DecodeIdOffertaMGP(xmlTemp.MPN, outIdContratto, outDataProgramma, outPeriodoRilevante, outCategoriaSDC, outUnitaSDC)

					drErrors.IdContratto = outIdContratto
					drErrors.DataProgramma = outDataProgramma
					drErrors.PeriodoRilevante = outPeriodoRilevante
					drErrors.CategoriaUnitaSDC = outCategoriaSDC
					drErrors.CodiceUnitaSDC = outUnitaSDC
					bNewRow = True
				End If
				'
				' Esegui un aggiornamento dei valori preesistenti
				'
				drErrors.Origin = "FA"
				If (xmlTemp.reasonCode = "") Then
					drErrors.ReasonCode = "UNKCD"
				Else
					drErrors.ReasonCode = xmlTemp.reasonCode
				End If
				If (xmlTemp.reasonText = "") Then
					drErrors.ReasonText = "Descrizione sconosciuta "
				Else
					drErrors.ReasonText = xmlTemp.reasonText
				End If

				drErrors.IdFile = Me._idfile
				If bNewRow Then
					dsProgOrariErrori.ProgrammiOrariErrori.Rows.Add(drErrors)
				End If
			End If
		End Sub



		Private Sub ValidationEvent(ByVal sender As Object, ByVal e As ValidationEventArgs)
			SystemMonitor.SmLog.smError(e.Exception, e.Message)
		End Sub

		Public Function ParseXML() As Boolean
			' Assegno lo schema per la Validazione
			Dim xr As XmlValidatingReader
			'=================== CONTROLLO SCHEMA PER IL FILE XML =============================================
			Try
				Dim fileSchema As String = BilBLBase.GetCompleteFileNameFromAppSettings("FA.FunctionalAcknowledgementDocument.xsd")
				If fileSchema Is Nothing Then
					SystemMonitor.SmLog.smError("""FA.FunctionalAcknowledgementDocument.xsd"" non e` presente nel file di configurazione")
					Return False
				End If

				Dim sc As XmlSchemaCollection = New XmlSchemaCollection
				sc.Add(Nothing, fileSchema)

				Dim textReader As XmlTextReader = New XmlTextReader(New MemoryStream(Me.xmlContentFile))
				textReader.WhitespaceHandling = WhitespaceHandling.None
				xr = New XmlValidatingReader(textReader)
				xr.ValidationType = ValidationType.Schema
				xr.Schemas.Add(sc)
				AddHandler xr.ValidationEventHandler, AddressOf Me.ValidationEvent

			Catch ex As Exception
				Debug.Assert(False)				' se non trova il file degli schemi
				SystemMonitor.SmLog.smError(ex)
				Return False
			End Try
			'=================== PARSING FILE XML =============================================
			Try
				Dim cultureInfoIT As New CultureInfo("it-IT")				  ' per leggere i double in italiano

				'======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
				Dim elPIPEFunctionalAcknowledgement As Object = xr.NameTable.Add("PIPEFunctionalAcknowledgement")
				Dim elTransactionAcknowledgement As Object = xr.NameTable.Add("TransactionAcknowledgement")
				Dim elRejectInformation As Object = xr.NameTable.Add("RejectInformation")
				Dim elReason As Object = xr.NameTable.Add("Reason")
				Dim elReasonText As Object = xr.NameTable.Add("ReasonText")

				' Dati temporanei utilizzati per ogni elemento PIPTransaction
				Dim currentRow As DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow = Nothing
				Dim currentRowErrors As DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow = Nothing

				Dim xmlData As New XMLTemporaryData

				'============================== INIZIO PARSING DEL FILE XML =========================
				While (xr.Read())
					Dim xrn As Object = xr.Name

					Select Case xr.NodeType
						Case XmlNodeType.Element

							'=================== TRANSACTION ACKNOWLEDGEMENT ======================
							If (xrn Is elTransactionAcknowledgement) Then
								Dim xmlStatus As String
								Dim xmlMPN As String
								Dim xmlGMERefNo As String
								'
								' Stato della singola transazione
								'
								xmlStatus = xr.GetAttribute("Status")
								'
								' GME Reference Number (reference number assegnato da GME
								' alla transazione)
								'
								xmlGMERefNo = xr.GetAttribute("OriginalReferenceNumber")
								'
								' MarketParticipantNumber (reference number assegnato da 
								' sistema bilaterali alla transazione)
								'
								xmlMPN = xr.GetAttribute("MarketParticipantNumber")

								If (xmlMPN Is Nothing) OrElse (xmlMPN = String.Empty) Then
									Debug.Assert(False)
									SystemMonitor.SmLog.smError("Error MPN NULL in xml")
								End If
								' Verifico che la stringa contenuta nel TAG MarketParticipantNumber
								' sia contenuta nella HashTable
								Debug.Assert(htMPN.ContainsKey(xmlMPN), "Se succede significa che il GME ha delle offerte VECCHIE che i bilaterali non ha piu`")
								If htMPN.ContainsKey(xmlMPN) Then
									currentRow = DirectCast(htMPN.Item(xmlMPN), DS_LetturaMercatoProgrammiOrarioUnita.ProgrammiOrariRow)
								Else
									SystemMonitor.SmLog.smError("Error MPN='" & xmlMPN & "' not present in table ProgrammaOrarioPerUnita")
									Throw New ApplicationException("Error MPN='" & xmlMPN & "' not present in table ProgrammaOrarioPerUnita")
								End If

								'
								' Cerca anche eventuali errori
								'
								If htMPNErr.ContainsKey(xmlMPN) Then
									currentRowErrors = DirectCast(htMPNErr.Item(xmlMPN), DS_LetturaMercatoProgrammiOrariErrori.ProgrammiOrariErroriRow)
								End If

								xmlData.MPN = xmlMPN
								xmlData.status = xmlStatus
								xmlData.GMEReferenceNumber = xmlGMERefNo

								If xmlStatus = "Accept" Then
									'
									' Se accettato non ho altro da elaborare
									'
									Debug.Assert(Not currentRow Is Nothing)
									If (currentRow Is Nothing) Then
										SystemMonitor.SmLog.smError("Error MarketParticipantNumber TAG not present in xml")
										Throw New ApplicationException("Error MarketParticipantNumber TAG not present in xml")
									End If
									' Assegno la Quantita' al DataRow 
									SetQtyAssegnata(currentRow, _
									 currentRowErrors, _
									 xmlData)

									' Inizializzo i dati temporanei
									currentRow = Nothing
									currentRowErrors = Nothing
									xmlData.Init()
								End If
								'============== REASON CODE =====================
							ElseIf (xrn Is elReason) Then
								If xmlData.status = "Reject" Then
									xmlData.reasonCode = xr.ReadString()
								End If

								'============== REASON TEXT =====================
							ElseIf (xrn Is elReasonText) Then
								If xmlData.status = "Reject" Then
									xmlData.reasonText = xr.ReadString()
								End If
							End If
						Case XmlNodeType.EndElement

							'=============== Functional Acknowledgment END =====================
							If (xmlData.status <> "Accept") Then
								If (xrn Is elTransactionAcknowledgement) Then
									' Sono sicuro di aver letto TUTTI i dati
									Debug.Assert(Not currentRow Is Nothing)
									If (currentRow Is Nothing) Then
										SystemMonitor.SmLog.smError("Error MarketParticipantNumber TAG not present in xml")
										Throw New ApplicationException("Error MarketParticipantNumber TAG not present in xml")
									End If

									' Assegno la Quantita' al DataRow 
									SetQtyAssegnata(currentRow, _
									 currentRowErrors, _
									 xmlData)

									' Inizializzo i dati temporanei
									currentRow = Nothing
									currentRowErrors = Nothing
									xmlData.Init()
								End If
							End If
					End Select
				End While
				Return True
			Catch ex As Exception
				SystemMonitor.SmLog.smError(ex, "Error parsing xml file")
				Throw
			Finally
				If Not xr Is Nothing Then xr.Close()
			End Try
		End Function
	End Class

#End Region

#Region " Funzioni private "
	Private Function LeggiDataOraRiferimento(ByVal strContenutoFileNotifiche() As Byte, ByRef Data As String, ByRef Ora As String) As Boolean
		Debug.Assert(Not strContenutoFileNotifiche Is Nothing)
		If (strContenutoFileNotifiche Is Nothing) Then
			smError("Error: file body NULL")
			Throw New ArgumentException("Error: file body NULL")
		End If

		Dim xtr As XmlTextReader = New XmlTextReader(New MemoryStream(strContenutoFileNotifiche))

		Try
			xtr.WhitespaceHandling = WhitespaceHandling.None
			Dim elDate As Object = xtr.NameTable.Add("Date")
			Dim elHour As Object = xtr.NameTable.Add("Hour")
			Dim oraEstratta As Boolean = False
			Dim dataEstratta As Boolean = False

			' Devo leggere solo la data e l'ora per poter fare la query sul DB
			' Letti questi due dati termino subito la lettura del file
			While (xtr.Read())
				Dim xrn As Object = xtr.Name
				Select Case xtr.NodeType
					Case XmlNodeType.Element
						If (xrn Is elDate) Then
							Data = xtr.ReadString()
							dataEstratta = True
						ElseIf (xrn Is elHour) Then
							Ora = xtr.ReadString()
							oraEstratta = True
						End If
					Case Else
						If (dataEstratta AndAlso oraEstratta) Then
							Exit While
						End If
				End Select
			End While
			' Ho estratto la data e l'ora => OK
			If (dataEstratta AndAlso oraEstratta) Then
				Return True
			Else
				Return False
			End If

		Catch ex As Exception
			smError(ex)
			Return False
		Finally
			If Not (xtr Is Nothing) Then xtr.Close()
		End Try

	End Function


	'
	' Funzione che estrae dal nome del file FA data e ora di riferimento: presuppone che tutte le transactions
	' abbiano stessa data e ora di riferimento. Questa funzione estrae infatti i dati solo dalla 
	' prima transaction
	'
	Private Function LeggiDataOraRiferimentoFADalFile(ByVal FileNameFA As String, ByRef Data As String, ByRef Ora As String) As Boolean
		Debug.Assert(Not FileNameFA Is Nothing)
		If (FileNameFA Is Nothing) Then
			smError("Error: filename NULL")
			Throw New ArgumentException("Error: file name NULL")
		End If

		Dim strData() As String
		Dim strOra() As String
		Dim separatorUnderscore(1) As Char
		Dim separatorPoint(1) As Char
		Dim result As Boolean = False

		Try
			separatorUnderscore(0) = Chr(Asc("_"))
			strData = FileNameFA.Split(separatorUnderscore, 5)

			separatorPoint(0) = Chr(Asc("."))
			strOra = strData(4).Split(separatorPoint, 5)

			Data = "20" & strData(3)
			Ora = strOra(0)
			result = True
		Catch ex As Exception
			smError("Error: non si possono ottenere data e ora")
			Throw New ArgumentException("Error: non si possono ottenere data e ora")
		End Try
		Return result
	End Function



	'
	' Funzione che estrae dal contenuto del file FA data e ora di riferimento: presuppone che tutte le transactions
	' abbiano stessa data e ora di riferimento. Questa funzione estrae infatti i dati solo dalla 
	' prima transaction
	'
	Private Function LeggiDataOraRiferimentoFADalContent(ByVal strContenutoFileFA() As Byte, ByRef Data As String, ByRef Ora As String) As Boolean

		Dim result As Boolean = True
		Debug.Assert(Not strContenutoFileFA Is Nothing)
		If (strContenutoFileFA Is Nothing) Then
			smError("Error: file body NULL")
			Throw New ArgumentException("Error: file body NULL")
		End If


		Dim xtr As XmlTextReader = New XmlTextReader(New MemoryStream(strContenutoFileFA))

		Try
			xtr.WhitespaceHandling = WhitespaceHandling.None

			Dim elTransactionAcknowledgement As Object = xtr.NameTable.Add("TransactionAcknowledgement")
			Dim oraEstratta As Boolean = False
			Dim dataEstratta As Boolean = False
			Dim xmlMPN As String

			' Devo leggere solo la data e l'ora per poter fare la query sul DB
			' Letti questi due dati termino subito la lettura del file
			While (xtr.Read())
				Dim xrn As Object = xtr.Name
				Select Case xtr.NodeType
					Case XmlNodeType.Element
						If (xrn Is elTransactionAcknowledgement) Then
							'
							' MarketParticipantNumber (reference number assegnato da 
							' sistema bilaterali alla transazione)
							'
							xmlMPN = xtr.GetAttribute("MarketParticipantNumber")
							If (xmlMPN Is Nothing) OrElse (xmlMPN = String.Empty) Then
								Debug.Assert(False)
								SystemMonitor.SmLog.smError("Error MPN NULL in xml")
							Else

								Dim out_IdContratto As Integer
								Dim out_DataProgramma As DateTime
								Dim out_PeriodoRilevante As Byte
								Dim out_CategoriaUnitaSDC As String
								Dim out_CodiceUnitaSDC As String
								DecodeIdOffertaMGP(xmlMPN, out_IdContratto, out_DataProgramma, out_PeriodoRilevante, out_CategoriaUnitaSDC, out_CodiceUnitaSDC)
								Data = out_DataProgramma.ToString("yyyyMMdd")
								dataEstratta = True
								Ora = out_PeriodoRilevante.ToString()
								oraEstratta = True
								result = True
								Exit While
							End If
						End If
					Case Else
						If (dataEstratta AndAlso oraEstratta) Then
							Exit While
						End If
				End Select
			End While
			' Ho estratto la data e l'ora => OK
			If (dataEstratta AndAlso oraEstratta) Then
				Return True
			Else
				Return False
			End If

		Catch ex As Exception
			smError(ex)
			Return False
		Finally
			If Not (xtr Is Nothing) Then xtr.Close()
		End Try
		Return result
	End Function



	Private Function ConvertDate(ByVal dataXML As String) As DateTime
		Dim anno As Integer
		Dim mese As Integer
		Dim giorno As Integer

		Try
			anno = Integer.Parse(dataXML.Substring(0, 4))
			mese = Integer.Parse(dataXML.Substring(4, 2))
			giorno = Integer.Parse(dataXML.Substring(6, 2))
		Catch ex As Exception
			smError("Error turn date '" & dataXML & "' into DateTime class")
			Throw ex
			Return Nothing
		End Try

		Return New DateTime(anno, mese, giorno)
	End Function

	Private Function ConvertHour(ByVal oraXML As String) As Byte
		Dim ora As Byte
		Try
			ora = Byte.Parse(oraXML)
			Return ora
		Catch ex As Exception
			smError(ex, "Error turn Hour='" & oraXML & "' into Integer")
			Return 0
		End Try
	End Function
	Private Function GetDataSetProgrammaOrarioUnita(ByVal data As DateTime, ByVal PeriodoRilevante As Byte) As DS_LetturaMercatoProgrammiOrarioUnita
		Try
			If (_cn.State = ConnectionState.Closed) Then
				_cn.Open()
			End If
			Dim c As StringBuilder = New StringBuilder
			c.Append(" WHERE DataProgramma = @DataProg AND PeriodoRilevante = @Ora ")
			_cmdSelectProgrammaOrarioUnita.CommandText &= c.ToString()
			_cmdSelectProgrammaOrarioUnita.Parameters.Add("@DataProg", data)
			_cmdSelectProgrammaOrarioUnita.Parameters.Add("@Ora", PeriodoRilevante)

			Dim ds As New DS_LetturaMercatoProgrammiOrarioUnita

			_daProgrammaOrarioUnita.Fill(ds.ProgrammiOrari)
			Return ds
		Catch ex As Exception
			smError(ex)
			Return Nothing
		End Try

	End Function

	Private Function GetDataSetProgrammaOrarioUnitaErrori(ByVal data As DateTime, ByVal PeriodoRilevante As Byte) As DS_LetturaMercatoProgrammiOrariErrori
		Try
			If (_cn.State = ConnectionState.Closed) Then
				_cn.Open()
			End If
			Dim c As StringBuilder = New StringBuilder
			c.Append(" WHERE DataProgramma = @DataProg AND PeriodoRilevante = @Ora ")
			_cmdSelectProgrammaOrarioUnitaErrori.CommandText &= c.ToString()
			_cmdSelectProgrammaOrarioUnitaErrori.Parameters.Add("@DataProg", data)
			_cmdSelectProgrammaOrarioUnitaErrori.Parameters.Add("@Ora", PeriodoRilevante)

			Dim ds As New DS_LetturaMercatoProgrammiOrariErrori

			_daProgrammaOrarioUnitaErrori.Fill(ds.ProgrammiOrariErrori)
			Return ds
		Catch ex As Exception
			smError(ex)
			Return Nothing
		End Try
	End Function

	Private Function GetDataSetDatiUnita() As DS_DatiPerditeUnita
		Try
			If (_cn.State = ConnectionState.Closed) Then
				_cn.Open()
			End If
			Dim ds As New DS_DatiPerditeUnita
			_daDatiUnita.Fill(ds.DatiUnita)
			Return ds
		Catch ex As Exception
			smError(ex)
			Return Nothing
		End Try
	End Function

	'Private Sub SaveDataSet(ByVal dsUpdate As DS_LetturaMercatoProgrammiOrarioUnita)
	'	Dim tr As SqlClient.SqlTransaction
	'	Try
	'		If (_cn.State = ConnectionState.Closed) Then
	'			_cn.Open()
	'		End If
	'		tr = _cn.BeginTransaction()
	'		SetTransaction(_daProgrammaOrarioUnita, tr)
	'		_daProgrammaOrarioUnita.Update(dsUpdate.ProgrammiOrari)
	'		tr.Commit()
	'		Return
	'	Catch ex As Exception
	'		smError(ex)
	'		If Not (tr Is Nothing) Then tr.Rollback()
	'		Throw
	'	End Try
	'End Sub

	Private Sub SaveDataSets(ByVal dsUpdateProgrammiOrari As DS_LetturaMercatoProgrammiOrarioUnita, _
	   ByVal dsUpdateProgrammiOrariErrori As DS_LetturaMercatoProgrammiOrariErrori)
		Dim tr As SqlClient.SqlTransaction = Nothing
		Try
			If (_cn.State = ConnectionState.Closed) Then
				_cn.Open()
			End If
			tr = _cn.BeginTransaction(IsolationLevel.ReadCommitted)
			SetTransaction(_daProgrammaOrarioUnita, tr)
			SetTransaction(_daProgrammaOrarioUnitaErrori, tr)

			'
			' set command timeouts
			'
			_daProgrammaOrarioUnita.UpdateCommand.CommandTimeout = AppSettingToInt32("LetturaMercatoQueryTmo", 120)
			_daProgrammaOrarioUnitaErrori.UpdateCommand.CommandTimeout = AppSettingToInt32("LetturaMercatoQueryTmo", 120)
			_daProgrammaOrarioUnitaErrori.InsertCommand.CommandTimeout = AppSettingToInt32("LetturaMercatoQueryTmo", 120)

			_daProgrammaOrarioUnita.Update(dsUpdateProgrammiOrari.ProgrammiOrari)
			_daProgrammaOrarioUnitaErrori.Update(dsUpdateProgrammiOrariErrori.ProgrammiOrariErrori)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
		End Try
	End Sub


	Private Function CheckFileOfferte(ByVal bFlFound() As Boolean, ByVal iCntFile As Integer, ByRef reason As String) As Boolean
		Dim bRet As Boolean = False
		reason = String.Empty
		If iCntFile < bFlFound.Length - 1 Then
			reason = String.Format("Ricevuti {0} file BN, previsti {1}", iCntFile, bFlFound.Length - 1)
			Return False
		End If

		Dim iDayHour As Integer = 0

		' non si usa l'elemento zero
		bRet = True
		For iDayHour = 1 To bFlFound.Length - 1
			bRet = bRet And bFlFound(iDayHour)
			If bRet = False Then
				reason += String.Format("File BN per l'ora {0} non ricevuto. ", iDayHour)
			End If
		Next

		Return bRet

	End Function
#End Region

End Class
