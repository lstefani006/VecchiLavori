Imports System.Text

Public Class UnitRelate
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		_cn.ConnectionString = GetConnectionString()
	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents _daUnita As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents _cmdDeleteUnitRelate As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdUpdateUnitRelate As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdInsertUnitRelate As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdSelectUnitRelate As System.Data.SqlClient.SqlCommand
	Friend WithEvents _daUnitRelate As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents _cmdSelectStarUnita As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me._cmdDeleteUnitRelate = New System.Data.SqlClient.SqlCommand
		Me._cn = New System.Data.SqlClient.SqlConnection
		Me._cmdUpdateUnitRelate = New System.Data.SqlClient.SqlCommand
		Me._cmdInsertUnitRelate = New System.Data.SqlClient.SqlCommand
		Me._cmdSelectUnitRelate = New System.Data.SqlClient.SqlCommand
		Me._daUnitRelate = New System.Data.SqlClient.SqlDataAdapter
		Me._daUnita = New System.Data.SqlClient.SqlDataAdapter
		Me._cmdSelectStarUnita = New System.Data.SqlClient.SqlCommand
		'
		'_cmdDeleteUnitRelate
		'
		Me._cmdDeleteUnitRelate.CommandText = "dbo.[spUnitRelateDelete]"
		Me._cmdDeleteUnitRelate.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdDeleteUnitRelate.Connection = Me._cn
		Me._cmdDeleteUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdDeleteUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdDeleteUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdDeleteUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'_cn
		'
		Me._cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_user;data source=BILSVR1;pers" & _
		"ist security info=True;initial catalog=Bilaterali_ROMA5;password=bilaterali"
		'
		'_cmdUpdateUnitRelate
		'
		Me._cmdUpdateUnitRelate.CommandText = "UPDATE dbo.UnitRelate SET DataInizioValidita = @DataInizioValidita, DataFineValid" & _
		"ita = @DataFineValidita, TSModifica = @TSModifica, Abilitata = @Abilitata WHERE " & _
		"(CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC) " & _
		"AND (CodiceOperatoreSDC = @CodiceOperatoreSDC)"
		Me._cmdUpdateUnitRelate.Connection = Me._cn
		Me._cmdUpdateUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
		Me._cmdUpdateUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
		Me._cmdUpdateUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me._cmdUpdateUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"))
		Me._cmdUpdateUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdUpdateUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me._cmdUpdateUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'_cmdInsertUnitRelate
		'
		Me._cmdInsertUnitRelate.CommandText = "INSERT INTO dbo.UnitRelate (CodiceOperatoreSDC, CodiceUnitaSDC, CategoriaUnitaSDC" & _
		", DataInizioValidita, DataFineValidita, TSModifica) VALUES (@CodiceOperatoreSDC," & _
		" @CodiceUnitaSDC, @CategoriaUnitaSDC, @DataInizioValidita, @DataFineValidita, @T" & _
		"SModifica)"
		Me._cmdInsertUnitRelate.Connection = Me._cn
		Me._cmdInsertUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me._cmdInsertUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
		Me._cmdInsertUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
		Me._cmdInsertUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
		Me._cmdInsertUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
		Me._cmdInsertUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		'
		'_cmdSelectUnitRelate
		'
		Me._cmdSelectUnitRelate.CommandText = "SELECT dbo.UnitRelate.*, dbo.SDC_Unita.CodicePunto" & _
		"DiScambioRilevanteSDC, dbo.SDC_PuntiDiScambioRilevanti.CodiceZonaSDC, dbo.SDC_Un" & _
		"ita.NomeUnita AS Descrizione, dbo.SDC_Unita.CodiceOperatoreDiRiferimentoSDC, isn" & _
		"ull(OpRif.RagioneSociale, '?') RagioneSociale FROM dbo.UnitRelate INNER JOIN dbo.SDC_Unita ON d" & _
		"bo.UnitRelate.CodiceUnitaSDC = dbo.SDC_Unita.CodiceUnitaSDC AND dbo.UnitRelate.C" & _
		"ategoriaUnitaSDC = dbo.SDC_Unita.CategoriaUnitaSDC INNER JOIN dbo.SDC_PuntiDiSca" & _
		"mbioRilevanti ON dbo.SDC_Unita.CodicePuntoDiScambioRilevanteSDC = dbo.SDC_PuntiD" & _
		"iScambioRilevanti.CodicePuntoDiScambioRilevanteSDC INNER JOIN dbo.SDC_Operatori " & _
		"ON dbo.SDC_Operatori.CodiceOperatoreSDC = dbo.UnitRelate.CodiceOperatoreSDC LEFT" & _
		" OUTER JOIN dbo.SDC_Operatori OpRif ON OpRif.CodiceOperatoreSDC = dbo.SDC_Unita." & _
		"CodiceOperatoreDiRiferimentoSDC WHERE (dbo.UnitRelate.CodiceOperatoreSDC = @Codi" & _
		"ceOperatoreSDC) "
		Me._cmdSelectUnitRelate.Connection = Me._cn
		Me._cmdSelectUnitRelate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		'
		'_daUnitRelate
		'
		Me._daUnitRelate.DeleteCommand = Me._cmdDeleteUnitRelate
		Me._daUnitRelate.InsertCommand = Me._cmdInsertUnitRelate
		Me._daUnitRelate.SelectCommand = Me._cmdSelectUnitRelate
		Me._daUnitRelate.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "UnitRelate", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"), New System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"), New System.Data.Common.DataColumnMapping("DataInizioValidita", "DataInizioValidita"), New System.Data.Common.DataColumnMapping("DataFineValidita", "DataFineValidita"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"), New System.Data.Common.DataColumnMapping("Abilitata", "Abilitata"), New System.Data.Common.DataColumnMapping("TrUC", "TrUC"), New System.Data.Common.DataColumnMapping("VUC", "VUC")})})
		Me._daUnitRelate.UpdateCommand = Me._cmdUpdateUnitRelate
		'
		'_daUnita
		'
		Me._daUnita.SelectCommand = Me._cmdSelectStarUnita
		'
		'_cmdSelectStarUnita
		'
		Me._cmdSelectStarUnita.CommandText = "SELECT dbo.Bil_AnaUnita.*, isnull(dbo.sdc_operatori.RagioneSociale, '?') RagioneS" & _
		"ocialeOperatoreDiRiferimentoSDC, 1 AS Visible FROM dbo.Bil_AnaUnita LEFT OUTER J" & _
		"OIN dbo.sdc_operatori ON dbo.sdc_operatori.CodiceOperatoreSDC = dbo.Bil_AnaUnita" & _
		".CodiceOperatoreDiRiferimentoSDC"
		Me._cmdSelectStarUnita.Connection = Me._cn

	End Sub

#End Region


	Public Sub UpdateUnitRelate(ByVal ds As Bil.DsUnitaOperatore)
		Dim tr As System.Data.SqlClient.SqlTransaction

		Try
			_cn.Open()

			tr = _cn.BeginTransaction()
			SetTransaction(_daUnitRelate, tr)
			_daUnitRelate.Update(ds, ds.UnitaOperatore.TableName)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception

			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Sub

	'' funzione che fa l'Update per vedere se il DB lo permette.
	'' Poi COMUNQUE fa Rollback e 
	'' ritorna True se si puo` updatare, false altrimenti.
	'Public Function CanUpdateUnitRelate(ByVal ds As Bil.DsUnitaOperatore) As Boolean
	'	Dim tr As System.Data.SqlClient.SqlTransaction

	'	Try
	'		Me._cn.Open()

	'		tr = Me._cn.BeginTransaction()
	'		SetTransaction(_daUnitaOperatore, tr)
	'		Me._daUnitaOperatore.Update(ds, ds.UnitaOperatore.TableName)
	'		If (Not tr Is Nothing) Then tr.Rollback()
	'		Return True

	'	Catch sex As SqlClient.SqlException
	'		tr.Rollback()
	'		Return False

	'	Catch ex As Exception
	'		If (Not tr Is Nothing) Then tr.Rollback()
	'		smError(ex)
	'		Throw
	'	Finally
	'		Me._cn.Close()
	'	End Try

	'End Function

	Public Function GetUnita(ByVal CodiceOperatoreSDC As String, _
	 ByVal CodiceUR As String, _
	ByVal TipoUR As String, _
	ByVal PSRUR As String, _
	ByVal ZonaUR As String, _
	ByVal DescrizioneUR As String, _
	ByVal OperatoreResponsabileUR As String, _
	ByVal RagioneSocialeUR As String _
	) As DsUnitaOperatore


		'ByVal Codice As String, _
		'ByVal Tipo As String, _
		'ByVal PSR As String, _
		'ByVal Zona As String, _
		'ByVal Descrizione As String, _
		'ByVal OperatoreResponsabile As String, _
		'ByVal RagioneSociale As String _


		Try
			_cn.Open()
			Dim ds As New DsUnitaOperatore

			Dim qry As New StringBuilder

			' OPERATORE A CUI LE UNITA` SONO ASSEGNATE
			If (CodiceOperatoreSDC <> String.Empty) Then
				_cmdSelectUnitRelate.Parameters("@CodiceOperatoreSDC").Value = CodiceOperatoreSDC

				' CODICE UR
				If (CodiceUR <> String.Empty) Then
					qry.Append(" and UnitRelate.CodiceUnitaSDC LIKE @CodiceUnitaSDC")
					_cmdSelectUnitRelate.Parameters.Add("@CodiceUnitaSDC", CodiceUR)
				End If

				' TIPO UNITA' UR
				If (TipoUR <> String.Empty) Then
					qry.Append(" and TipoUnita = @TipoUnita")
					_cmdSelectUnitRelate.Parameters.Add("@TipoUnita", TipoUR)
				End If

				' PUNTO DI SCAMBIO RILEVANTE UR
				If (PSRUR <> String.Empty) Then
					qry.Append(" and SDC_Unita.CodicePuntoDiScambioRilevanteSDC LIKE @PSR")
					_cmdSelectUnitRelate.Parameters.Add("@PSR", PSRUR)
				End If

				' ZONA UR
				If (ZonaUR <> String.Empty) Then
					qry.Append(" and CodiceZonaSDC LIKE @Zona")
					_cmdSelectUnitRelate.Parameters.Add("@Zona", ZonaUR)
				End If

				' NOME UNITA' UR
				If (DescrizioneUR <> String.Empty) Then
					qry.Append(" and NomeUnita LIKE @NomeUnita")
					_cmdSelectUnitRelate.Parameters.Add("@NomeUnita", DescrizioneUR & "%")
				End If

				' OPERATORE RESPONSABILE DELL'UNITA' UR
				If (OperatoreResponsabileUR <> String.Empty) Then
					qry.Append(" and CodiceOperatoreDiRiferimentoSDC LIKE @CodiceOperatoreRif")
					_cmdSelectUnitRelate.Parameters.Add("@CodiceOperatoreRif", OperatoreResponsabileUR & "%")
				End If

				' RAGIONE SOCIALE OPERATORE RESPONSABILE DELL'UNITA' UR
				If (RagioneSocialeUR <> String.Empty) Then
					qry.Append(" and RagioneSociale LIKE @RagioneSociale")
					_cmdSelectUnitRelate.Parameters.Add("@RagioneSociale", RagioneSocialeUR & "%")
				End If

				If (qry.Length > 0) Then
					If (_cmdSelectUnitRelate.CommandText.ToUpper().IndexOf("WHERE") < 0) Then
						Dim s As String = qry.ToString()						 ' la stringa costruita sopra
						If s.StartsWith(" and ") Then
							s = s.Substring(sAnd.Length)							' tolgo " AND " iniziale
						End If

						_cmdSelectUnitRelate.CommandText &= " WHERE " & s
					Else
						_cmdSelectUnitRelate.CommandText &= qry.ToString()
					End If
				End If


				_daUnitRelate.Fill(ds, ds.UnitaOperatore.TableName)


				'==================================================================================


				' PURTROPPO non si puo` filtrare niente

				'_cmdSelectStarUnita.Parameters("@CodiceOperatoreSDC").Value = CodiceOperatoreSDC

				' qry = New StringBuilder
				'' CODICE
				'If (Codice <> String.Empty) Then
				'	qry.Append(" and FilteredUnitRelate.CodiceUnitaSDC LIKE @CodiceUnitaSDC")
				'	_cmdSelectStarUnita.Parameters("@CodiceUnitaSDC").Value = Codice & "%"
				'End If

				'' TIPO UNITA'
				'If (Tipo <> String.Empty) Then
				'	qry.Append(" and TipoUnita = @TipoUnita")
				'	_cmdSelectStarUnita.Parameters.Add("@TipoUnita", Tipo)
				'End If

				'' PUNTO DI SCAMBIO RILEVANTE
				'If (PSR <> String.Empty) Then
				'	qry.Append(" and CodicePuntoDiScambioRilevanteSDC LIKE @PSR")
				'	_cmdSelectStarUnita.Parameters.Add("@PSR", PSR)
				'End If

				'' ZONA
				'If (Zona <> String.Empty) Then
				'	qry.Append(" and CodiceZonaSDC LIKE @Zona")
				'	_cmdSelectStarUnita.Parameters.Add("@Zona", Zona)
				'End If

				'' NOME UNITA'
				'If (Descrizione <> String.Empty) Then
				'	qry.Append(" and NomeUnita LIKE @NomeUnita")
				'	_cmdSelectStarUnita.Parameters.Add("@NomeUnita", Descrizione & "%")
				'End If

				'' OPERATORE RESPONSABILE DELL'UNITA'
				'If (OperatoreResponsabile <> String.Empty) Then
				'	qry.Append(" and CodiceOperatoreDiRiferimentoSDC LIKE @CodiceOperatoreRif")
				'	_cmdSelectStarUnita.Parameters.Add("@CodiceOperatoreRif", OperatoreResponsabile & "%")
				'End If

				'' RAGIONE SOCIALE OPERATORE RESPONSABILE DELL'UNITA'
				'If (RagioneSociale <> String.Empty) Then
				'	qry.Append(" and RagioneSociale LIKE @RagioneSociale")
				'	_cmdSelectStarUnita.Parameters.Add("@RagioneSociale", RagioneSociale & "%")
				'End If

				'If (qry.Length > 0) Then
				'	If (_cmdSelectStarUnita.CommandText.ToUpper().IndexOf("WHERE") < 0) Then
				'		Dim s As String = qry.ToString()						 ' la stringa costruita sopra
				'		If s.StartsWith(" and ") Then
				'			s = s.Substring(sAnd.Length)
				'		End If
				'		_cmdSelectStarUnita.CommandText &= " WHERE " & s
				'	Else
				'		_cmdSelectStarUnita.CommandText &= qry.ToString()
				'	End If
				'End If
				_daUnita.Fill(ds, ds.Unita.TableName)

			End If

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function

	'Public Sub UpdateDataSet(ByVal ds As Bil.DsUnitaOperatore)
	'	Dim myTrans As System.Data.SqlClient.SqlTransaction

	'	Try
	'		_cn.Open()

	'		myTrans = _cn.BeginTransaction()
	'		SetTransaction(_daUnita, myTrans)
	'		_daUnita.Update(ds, ds.Unita.TableName)
	'		myTrans.Commit()

	'	Catch ex As Exception
	'		If (Not myTrans Is Nothing) Then myTrans.Rollback()

	'		smError(ex)
	'		Throw
	'	Finally
	'		_cn.Close()
	'	End Try
	'End Sub

	' funzione che fa l'Update per vedere se il DB lo permette.
	' Poi COMUNQUE fa Rollback e 
	' ritorna True se si puo` updatare, false altrimenti.
	'Public Function CanUpdate(ByVal ds As Bil.DsUnitaOperatore) As Boolean
	'	Dim tr As System.Data.SqlClient.SqlTransaction

	'	Try
	'		Me._cn.Open()

	'		tr = Me._cn.BeginTransaction()
	'		SetTransaction(_daUnita, tr)
	'		Me._daUnita.Update(ds, ds.Unita.TableName)
	'		If (Not tr Is Nothing) Then tr.Rollback()
	'		Return True

	'	Catch sex As SqlClient.SqlException
	'		tr.Rollback()
	'		Return False

	'	Catch ex As Exception
	'		If (Not tr Is Nothing) Then tr.Rollback()
	'		smError(ex)
	'		Throw
	'	Finally
	'		Me._cn.Close()
	'	End Try

	'End Function

End Class
