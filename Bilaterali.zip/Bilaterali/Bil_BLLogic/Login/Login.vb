Public Class Login
	Inherits BilBLBase
#Region " Component Designer generated code "

    Public Sub New(Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents DS_Login As Bil.DS_Login
    Friend WithEvents _daUtenti As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _daOperatori As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _daRelUtOp As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelVwUtenti As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdSelVwOperatori As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdSelVwUtentiOperatori As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdSelRuoli As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdSelRuoliFunzioni As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdSelFunzioni As System.Data.SqlClient.SqlCommand
    Friend WithEvents _daRuoli As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _daRuoliFunzioni As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _daFunzioni As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me._daUtenti = New System.Data.SqlClient.SqlDataAdapter
        Me._cmdSelVwUtenti = New System.Data.SqlClient.SqlCommand
        Me.DS_Login = New Bil.DS_Login
        Me._cmdSelVwOperatori = New System.Data.SqlClient.SqlCommand
        Me._cmdSelVwUtentiOperatori = New System.Data.SqlClient.SqlCommand
        Me._daOperatori = New System.Data.SqlClient.SqlDataAdapter
        Me._daRelUtOp = New System.Data.SqlClient.SqlDataAdapter
        Me._cmdSelRuoli = New System.Data.SqlClient.SqlCommand
        Me._cmdSelRuoliFunzioni = New System.Data.SqlClient.SqlCommand
        Me._cmdSelFunzioni = New System.Data.SqlClient.SqlCommand
        Me._daRuoli = New System.Data.SqlClient.SqlDataAdapter
        Me._daRuoliFunzioni = New System.Data.SqlClient.SqlDataAdapter
        Me._daFunzioni = New System.Data.SqlClient.SqlDataAdapter
        CType(Me.DS_Login, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persist" & _
        " security info=True;initial catalog=Bilaterali;password=bilaterali"
        '
        '_daUtenti
        '
        Me._daUtenti.SelectCommand = Me._cmdSelVwUtenti
        '
        '_cmdSelVwUtenti
        '
        Me._cmdSelVwUtenti.CommandText = "SELECT CodiceUtenteSDC, Nome, Cognome, Telefono, Fax, Email, Abilitato, CodiceFis" & _
        "cale, ResponsabileAggiornamento, DN, Login, Pwd, Lingua, StatoBilateraliUtente, " & _
        "Certificato FROM dbo.Bil_Utenti WHERE (Abilitato = 1) AND (StatoBilateraliUtente" & _
        " = 1)"
        Me._cmdSelVwUtenti.Connection = Me._cn
        '
        'DS_Login
        '
        Me.DS_Login.CaseSensitive = True
        Me.DS_Login.DataSetName = "DS_Login"
        Me.DS_Login.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        '_cmdSelVwOperatori
        '
        Me._cmdSelVwOperatori.CommandText = "SELECT CodiceOperatoreSDC, StatoBilateraliOperatore, Operatori_TSModifica, Ragion" & _
        "eSociale, Indirizzo1, Indirizzo2, Citta, Nazione, CodiceFiscale, PartitaIva, Ema" & _
        "il, Fax, ReferenteAmministrativo, SedeAmministrativa, Abilitato, SDC_TSModifica," & _
        " ResponsabileAggiornamento, Amministratore FROM dbo.Bil_Operatori"
        Me._cmdSelVwOperatori.Connection = Me._cn
        '
        '_cmdSelVwUtentiOperatori
        '
        Me._cmdSelVwUtentiOperatori.CommandText = "SELECT CodiceOperatoreSDC, RagioneSociale, Indirizzo1, Indirizzo2, Citta, Nazione" & _
        ", CodiceFiscale, PartitaIva, Email, Fax, ReferenteAmministrativo, SedeAmministra" & _
        "tiva, SDC_Operatori_Abilitato, SDC_Operatori_TSModifica, ResponsabileAggiornamen" & _
        "to, Abilitato, TSIniValidita, CodiceRuolo, TSModifica, TSEndValidita, CodiceUten" & _
        "teSDC, Amministratore, SDC_Operatori_StatoBilateraliOperatore FROM dbo.Bil_Utent" & _
        "iOperatori WHERE (TSIniValidita <= @DataOdierna) AND (Amministratore = @AdminYes" & _
        "No) AND (TSEndValidita >= @DataOdierna) AND (SDC_Operatori_Abilitato = 1) AND (A" & _
        "bilitato = 1) AND (SDC_Operatori_StatoBilateraliOperatore = 1)"
        Me._cmdSelVwUtentiOperatori.Connection = Me._cn
        Me._cmdSelVwUtentiOperatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataOdierna", System.Data.SqlDbType.DateTime, 8, "TSIniValidita"))
        Me._cmdSelVwUtentiOperatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AdminYesNo", System.Data.SqlDbType.Int, 4, "Amministratore"))
        '
        '_daOperatori
        '
        Me._daOperatori.SelectCommand = Me._cmdSelVwOperatori
        '
        '_daRelUtOp
        '
        Me._daRelUtOp.SelectCommand = Me._cmdSelVwUtentiOperatori
        '
        '_cmdSelRuoli
        '
        Me._cmdSelRuoli.CommandText = "SELECT CodiceRuolo, DescrizioneRuolo, TSModifica FROM dbo.Ruoli"
        Me._cmdSelRuoli.Connection = Me._cn
        '
        '_cmdSelRuoliFunzioni
        '
        Me._cmdSelRuoliFunzioni.CommandText = "SELECT CodiceFunzione, CodiceRuolo, TSModifica FROM dbo.RuoliFunzioni"
        Me._cmdSelRuoliFunzioni.Connection = Me._cn
        '
        '_cmdSelFunzioni
        '
        Me._cmdSelFunzioni.CommandText = "SELECT CodiceFunzione, DescrizioneFunzione, TSModifica FROM dbo.Funzioni"
        Me._cmdSelFunzioni.Connection = Me._cn
        '
        '_daRuoli
        '
        Me._daRuoli.SelectCommand = Me._cmdSelRuoli
        '
        '_daRuoliFunzioni
        '
        Me._daRuoliFunzioni.SelectCommand = Me._cmdSelRuoliFunzioni
        '
        '_daFunzioni
        '
        Me._daFunzioni.SelectCommand = Me._cmdSelFunzioni
        CType(Me.DS_Login, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region
    Public Function GetLoginInfo(ByVal bAdmin As Boolean) As DS_Login
        Dim ds As New DS_Login

        ' File used when the database is off-line.
        'Dim filename As String

        'filename = "LoginInfo.xml" ' place it in bin (not in the site root folder !!!)

        _cn.ConnectionString = GetConnectionString()
        ' Test connection state _cn.State.Open
        Try
            _cn.Open()

			Try
				_daUtenti.Fill(ds.Utenti)
			Catch ex As Exception
				smError(ex, "Error filling Utenti dataset using command: [" & _
				  _daUtenti.SelectCommand.CommandText.ToString + "] - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				_daOperatori.Fill(ds.Operatori)
			Catch ex As Exception
				smError(ex, "Error filling Operatori dataset using command: [" & _
				   _daOperatori.SelectCommand.CommandText.ToString + "] - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				' used to filter rows from RelOpUt (WHERE     (TSIniValidita < @DataOdierna) AND (@DataOdierna < TSEndValidita))
				_daRelUtOp.SelectCommand.Parameters("@DataOdierna").Value = DateTime.Now
				_daRelUtOp.SelectCommand.Parameters("@AdminYesNo").Value = bAdmin
				_daRelUtOp.Fill(ds.RelUtOp)
			Catch ex As Exception
				smError(ex, "Error filling RelUtOp dataset using command: [" & _
				   _daRelUtOp.SelectCommand.CommandText.ToString + "] - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				_daRuoli.Fill(ds.Ruoli)
			Catch ex As Exception
				smError(ex, "Error filling Ruoli dataset using command: [" & _
				  _daRuoli.SelectCommand.CommandText.ToString + "] - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				_daFunzioni.Fill(ds.Funzioni)
			Catch ex As Exception
				smError(ex, "Error filling Funzioni dataset using command: [" & _
				  _daFunzioni.SelectCommand.CommandText.ToString + "] - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				_daRuoliFunzioni.Fill(ds.RuoliFunzioni)
			Catch ex As Exception
				smError(ex, "Error filling RuoliFunzioni dataset using command: [" & _
				  _daRuoliFunzioni.SelectCommand.CommandText.ToString + "] - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			'----------Relationships
			Dim rel_OperatoriRelUtOp As DataRelation
			Try
				rel_OperatoriRelUtOp = New DataRelation("OperatoriRelUtOp", ds.Tables("Operatori").Columns("CodiceOperatoreSDC"), ds.Tables("RelUtOp").Columns("CodiceOperatoreSDC"))
			Catch ex As Exception
				smError(ex, "Error instantiating OperatoriRelUtOp DataRelation - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				ds.Relations.Add(rel_OperatoriRelUtOp)
			Catch ex As Exception
				smError(ex, "Error adding OperatoriRelUtOp DataRelation - Exception is:" & _
				 ex.Message)
				Throw
			End Try

			Dim rel_RuoliRelUtOp As DataRelation
			Try
				rel_RuoliRelUtOp = New DataRelation("RuoliRelUtOp", ds.Tables("Ruoli").Columns("CodiceRuolo"), ds.Tables("RelUtOp").Columns("CodiceRuolo"))
			Catch ex As Exception
				smError(ex, "Error instantiating RuoliRelUtOp DataRelation - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				ds.Relations.Add(rel_RuoliRelUtOp)
			Catch ex As Exception
				smError(ex, "Error adding RuoliRelUtOp DataRelation - Exception is:" & _
				 ex.Message)
				Throw
			End Try

			Dim rel_RuoliRuoliFunzioni As DataRelation
			Try
				rel_RuoliRuoliFunzioni = New DataRelation("RuoliRuoliFunzioni", ds.Tables("Ruoli").Columns("CodiceRuolo"), ds.Tables("RuoliFunzioni").Columns("CodiceRuolo"))
			Catch ex As Exception
				smError(ex, "Error instantiating RuoliRuoliFunzioni DataRelation - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				ds.Relations.Add(rel_RuoliRuoliFunzioni)
			Catch ex As Exception
				smError(ex, "Error adding RuoliRuoliFunzioni DataRelation - Exception is:" & _
				 ex.Message)
				Throw
			End Try


			Dim rel_FunzioniRuoliFunzioni As DataRelation
			Try
				rel_FunzioniRuoliFunzioni = New DataRelation("FunzioniRuoliFunzioni", ds.Tables("Funzioni").Columns("CodiceFunzione"), ds.Tables("RuoliFunzioni").Columns("CodiceFunzione"))
			Catch ex As Exception
				smError(ex, "Error instantiating FunzioniRuoliFunzioni DataRelation - Exception is:" & _
				  ex.Message)
				Throw
			End Try

			Try
				ds.Relations.Add(rel_FunzioniRuoliFunzioni)
			Catch ex As Exception
				smError(ex, "Error adding FunzioniRuoliFunzioni DataRelation - Exception is:" & _
				 ex.Message)
				Throw
			End Try

			Return ds

		Finally
			_cn.Dispose()
		End Try
    End Function
End Class
