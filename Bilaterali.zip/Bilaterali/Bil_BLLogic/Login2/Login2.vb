Imports System.Security.Cryptography.X509Certificates

Public Class Login2
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents daOperatori As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdOperatori As System.Data.SqlClient.SqlCommand
	Friend WithEvents daUtenti As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdUtenti As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdRelOperatoriUtenti As System.Data.SqlClient.SqlCommand
	Friend WithEvents daRelOperatoriUtenti As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdRuoli As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents daRuoli As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdRuoliFunzioni As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand2 As System.Data.SqlClient.SqlCommand
	Friend WithEvents daRuoliFunzioni As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdFunzioni As System.Data.SqlClient.SqlCommand
	Friend WithEvents daFunzioni As System.Data.SqlClient.SqlDataAdapter
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.daOperatori = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdOperatori = New System.Data.SqlClient.SqlCommand
		Me.daUtenti = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdUtenti = New System.Data.SqlClient.SqlCommand
		Me.cmdRelOperatoriUtenti = New System.Data.SqlClient.SqlCommand
		Me.daRelOperatoriUtenti = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdRuoli = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
		Me.daRuoli = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdRuoliFunzioni = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand2 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand2 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand2 = New System.Data.SqlClient.SqlCommand
		Me.daRuoliFunzioni = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdFunzioni = New System.Data.SqlClient.SqlCommand
		Me.daFunzioni = New System.Data.SqlClient.SqlDataAdapter
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=False;initial catalog=Bilaterali"
		'
		'daOperatori
		'
		Me.daOperatori.SelectCommand = Me.cmdOperatori
		Me.daOperatori.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Operatori", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("StatoBilateraliOperatore", "StatoBilateraliOperatore"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"), New System.Data.Common.DataColumnMapping("Amministratore", "Amministratore")})})
		'
		'cmdOperatori
		'
		Me.cmdOperatori.CommandText = "SELECT dbo.Operatori.StatoBilateraliOperatore, dbo.SDC_Operatori.Abilitato, dbo.O" & _
		"peratori.CodiceOperatoreSDC, dbo.Operatori.Amministratore, dbo.SDC_Operatori.Rag" & _
		"ioneSociale FROM dbo.Operatori INNER JOIN dbo.SDC_Operatori ON dbo.Operatori.Cod" & _
		"iceOperatoreSDC = dbo.SDC_Operatori.CodiceOperatoreSDC WHERE (dbo.Operatori.Stat" & _
		"oBilateraliOperatore = 1) AND (dbo.SDC_Operatori.Abilitato = 1)"
		Me.cmdOperatori.Connection = Me.cn
		'
		'daUtenti
		'
		Me.daUtenti.SelectCommand = Me.cmdUtenti
		Me.daUtenti.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Utenti", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"), New System.Data.Common.DataColumnMapping("StatoBilateraliUtente", "StatoBilateraliUtente"), New System.Data.Common.DataColumnMapping("Certificato", "Certificato"), New System.Data.Common.DataColumnMapping("Abilitato", "Abilitato")})})
		'
		'cmdUtenti
		'
		Me.cmdUtenti.CommandText = "SELECT dbo.Utenti.CodiceUtenteSDC, dbo.SDC_Utenti.Certificato, dbo.SDC_Utenti.Log" & _
		"in, dbo.SDC_Utenti.Pwd, dbo.SDC_Utenti.Lingua FROM dbo.Utenti INNER JOIN dbo.SDC" & _
		"_Utenti ON dbo.Utenti.CodiceUtenteSDC = dbo.SDC_Utenti.CodiceUtenteSDC WHERE (db" & _
		"o.Utenti.StatoBilateraliUtente = 1) AND (dbo.SDC_Utenti.Abilitato = 1)"
		Me.cmdUtenti.Connection = Me.cn
		'
		'cmdRelOperatoriUtenti
		'
		Me.cmdRelOperatoriUtenti.CommandText = "SELECT CodiceUtenteSDC, CodiceOperatoreSDC, TSIniValidita, TSEndValidita, CodiceR" & _
		"uolo, TSModifica, Amministratore FROM dbo.RelOperatoriUtenti WHERE (Abilitato = " & _
		"1) AND (TSIniValidita <= @d) AND (TSEndValidita >= @d) AND (Amministratore = @a)" & _
		""
		Me.cmdRelOperatoriUtenti.Connection = Me.cn
		Me.cmdRelOperatoriUtenti.Parameters.Add(New System.Data.SqlClient.SqlParameter("@d", System.Data.SqlDbType.DateTime, 8, "TSIniValidita"))
		Me.cmdRelOperatoriUtenti.Parameters.Add(New System.Data.SqlClient.SqlParameter("@a", System.Data.SqlDbType.Int, 4, "Amministratore"))
		'
		'daRelOperatoriUtenti
		'
		Me.daRelOperatoriUtenti.SelectCommand = Me.cmdRelOperatoriUtenti
		Me.daRelOperatoriUtenti.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "RelOperatoriUtenti", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("Amministratore", "Amministratore"), New System.Data.Common.DataColumnMapping("Abilitato", "Abilitato"), New System.Data.Common.DataColumnMapping("TSIniValidita", "TSIniValidita"), New System.Data.Common.DataColumnMapping("TSEndValidita", "TSEndValidita"), New System.Data.Common.DataColumnMapping("CodiceRuolo", "CodiceRuolo"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica")})})
		'
		'cmdRuoli
		'
		Me.cmdRuoli.CommandText = "SELECT CodiceRuolo, DescrizioneRuolo, TSModifica FROM dbo.Ruoli"
		Me.cmdRuoli.Connection = Me.cn
		'
		'SqlInsertCommand1
		'
		Me.SqlInsertCommand1.CommandText = "INSERT INTO dbo.Ruoli(CodiceRuolo, DescrizioneRuolo, TSModifica) VALUES (@CodiceR" & _
		"uolo, @DescrizioneRuolo, @TSModifica); SELECT CodiceRuolo, DescrizioneRuolo, TSM" & _
		"odifica FROM dbo.Ruoli WHERE (CodiceRuolo = @CodiceRuolo)"
		Me.SqlInsertCommand1.Connection = Me.cn
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceRuolo", System.Data.SqlDbType.VarChar, 32, "CodiceRuolo"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizioneRuolo", System.Data.SqlDbType.VarChar, 256, "DescrizioneRuolo"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		'
		'SqlUpdateCommand1
		'
		Me.SqlUpdateCommand1.CommandText = "UPDATE dbo.Ruoli SET CodiceRuolo = @CodiceRuolo, DescrizioneRuolo = @DescrizioneR" & _
		"uolo, TSModifica = @TSModifica WHERE (CodiceRuolo = @Original_CodiceRuolo) AND (" & _
		"DescrizioneRuolo = @Original_DescrizioneRuolo OR @Original_DescrizioneRuolo IS N" & _
		"ULL AND DescrizioneRuolo IS NULL) AND (TSModifica = @Original_TSModifica); SELEC" & _
		"T CodiceRuolo, DescrizioneRuolo, TSModifica FROM dbo.Ruoli WHERE (CodiceRuolo = " & _
		"@CodiceRuolo)"
		Me.SqlUpdateCommand1.Connection = Me.cn
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceRuolo", System.Data.SqlDbType.VarChar, 32, "CodiceRuolo"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizioneRuolo", System.Data.SqlDbType.VarChar, 256, "DescrizioneRuolo"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceRuolo", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceRuolo", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DescrizioneRuolo", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DescrizioneRuolo", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TSModifica", System.Data.DataRowVersion.Original, Nothing))
		'
		'SqlDeleteCommand1
		'
		Me.SqlDeleteCommand1.CommandText = "DELETE FROM dbo.Ruoli WHERE (CodiceRuolo = @Original_CodiceRuolo) AND (Descrizion" & _
		"eRuolo = @Original_DescrizioneRuolo OR @Original_DescrizioneRuolo IS NULL AND De" & _
		"scrizioneRuolo IS NULL) AND (TSModifica = @Original_TSModifica)"
		Me.SqlDeleteCommand1.Connection = Me.cn
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceRuolo", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceRuolo", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DescrizioneRuolo", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DescrizioneRuolo", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TSModifica", System.Data.DataRowVersion.Original, Nothing))
		'
		'daRuoli
		'
		Me.daRuoli.DeleteCommand = Me.SqlDeleteCommand1
		Me.daRuoli.InsertCommand = Me.SqlInsertCommand1
		Me.daRuoli.SelectCommand = Me.cmdRuoli
		Me.daRuoli.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Ruoli", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceRuolo", "CodiceRuolo"), New System.Data.Common.DataColumnMapping("DescrizioneRuolo", "DescrizioneRuolo"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica")})})
		Me.daRuoli.UpdateCommand = Me.SqlUpdateCommand1
		'
		'cmdRuoliFunzioni
		'
		Me.cmdRuoliFunzioni.CommandText = "SELECT CodiceFunzione, CodiceRuolo, TSModifica FROM dbo.RuoliFunzioni"
		Me.cmdRuoliFunzioni.Connection = Me.cn
		'
		'SqlInsertCommand2
		'
		Me.SqlInsertCommand2.CommandText = "INSERT INTO dbo.RuoliFunzioni(CodiceFunzione, CodiceRuolo, TSModifica) VALUES (@C" & _
		"odiceFunzione, @CodiceRuolo, @TSModifica); SELECT CodiceFunzione, CodiceRuolo, T" & _
		"SModifica FROM dbo.RuoliFunzioni WHERE (CodiceFunzione = @CodiceFunzione) AND (C" & _
		"odiceRuolo = @CodiceRuolo)"
		Me.SqlInsertCommand2.Connection = Me.cn
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceFunzione", System.Data.SqlDbType.VarChar, 32, "CodiceFunzione"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceRuolo", System.Data.SqlDbType.VarChar, 32, "CodiceRuolo"))
		Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		'
		'SqlUpdateCommand2
		'
		Me.SqlUpdateCommand2.CommandText = "UPDATE dbo.RuoliFunzioni SET CodiceFunzione = @CodiceFunzione, CodiceRuolo = @Cod" & _
		"iceRuolo, TSModifica = @TSModifica WHERE (CodiceFunzione = @Original_CodiceFunzi" & _
		"one) AND (CodiceRuolo = @Original_CodiceRuolo) AND (TSModifica = @Original_TSMod" & _
		"ifica); SELECT CodiceFunzione, CodiceRuolo, TSModifica FROM dbo.RuoliFunzioni WH" & _
		"ERE (CodiceFunzione = @CodiceFunzione) AND (CodiceRuolo = @CodiceRuolo)"
		Me.SqlUpdateCommand2.Connection = Me.cn
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceFunzione", System.Data.SqlDbType.VarChar, 32, "CodiceFunzione"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceRuolo", System.Data.SqlDbType.VarChar, 32, "CodiceRuolo"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceFunzione", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceFunzione", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceRuolo", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceRuolo", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TSModifica", System.Data.DataRowVersion.Original, Nothing))
		'
		'SqlDeleteCommand2
		'
		Me.SqlDeleteCommand2.CommandText = "DELETE FROM dbo.RuoliFunzioni WHERE (CodiceFunzione = @Original_CodiceFunzione) A" & _
		"ND (CodiceRuolo = @Original_CodiceRuolo) AND (TSModifica = @Original_TSModifica)" & _
		""
		Me.SqlDeleteCommand2.Connection = Me.cn
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceFunzione", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceFunzione", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceRuolo", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceRuolo", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "TSModifica", System.Data.DataRowVersion.Original, Nothing))
		'
		'daRuoliFunzioni
		'
		Me.daRuoliFunzioni.DeleteCommand = Me.SqlDeleteCommand2
		Me.daRuoliFunzioni.InsertCommand = Me.SqlInsertCommand2
		Me.daRuoliFunzioni.SelectCommand = Me.cmdRuoliFunzioni
		Me.daRuoliFunzioni.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "RuoliFunzioni", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceFunzione", "CodiceFunzione"), New System.Data.Common.DataColumnMapping("CodiceRuolo", "CodiceRuolo"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica")})})
		Me.daRuoliFunzioni.UpdateCommand = Me.SqlUpdateCommand2
		'
		'cmdFunzioni
		'
		Me.cmdFunzioni.CommandText = "SELECT CodiceFunzione, DescrizioneFunzione, TSModifica FROM dbo.Funzioni"
		Me.cmdFunzioni.Connection = Me.cn
		'
		'daFunzioni
		'
		Me.daFunzioni.SelectCommand = Me.cmdFunzioni
		Me.daFunzioni.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Funzioni", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceFunzione", "CodiceFunzione"), New System.Data.Common.DataColumnMapping("DescrizioneFunzione", "DescrizioneFunzione"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica")})})

	End Sub

#End Region

	Public Enum LoginType
		User
		Admin
	End Enum

	Public Function GetUserLoginData(ByVal loginType As LoginType) As DS_Login2

		cn.ConnectionString = GetConnectionString()

		Try

			Dim ds As New DS_Login2

			cn.Open()

			daUtenti.Fill(ds.Utenti)
			daOperatori.Fill(ds.Operatori)
			daRuoli.Fill(ds.Ruoli)
			daFunzioni.Fill(ds.Funzioni)

			daRelOperatoriUtenti.SelectCommand.Parameters("@d").Value = DateTime.Now.Date
			daRelOperatoriUtenti.SelectCommand.Parameters("@a").Value = (loginType = loginType.Admin)
			daRelOperatoriUtenti.Fill(ds.RelOperatoriUtenti)

			daRuoliFunzioni.Fill(ds.RuoliFunzioni)

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	Private Sub Assign(ByVal dr As DataRow, ByVal f As String, ByVal rd As SqlClient.SqlDataReader)
		If (rd.IsDBNull(rd.GetOrdinal(f))) Then

			dr.Item(f) = DBNull.Value

		Else
			Dim o As Object = rd(f)
			dr.Item(f) = Convert.ChangeType(o, dr.Table.Columns(f).DataType)
		End If
	End Sub


	Public Function CheckLoginPwd(ByVal cn As SqlClient.SqlConnection, ByVal loginType As LoginType, ByVal login As String, ByVal pwd As String) As DS_Login2

		Dim ds As New DS_Login2

		Dim cmd As SqlClient.SqlCommand = cn.CreateCommand()

		cmd.CommandType = CommandType.StoredProcedure
		cmd.CommandText = "dbo.CheckLoginPwd"
		cmd.Parameters.Add("@login", login)
		cmd.Parameters.Add("@pwd", pwd)

		If loginType = loginType.Admin Then
			cmd.Parameters.Add("@Admin", SqlDbType.Int).Value = 1
		Else
			cmd.Parameters.Add("@Admin", SqlDbType.Int).Value = 0
		End If


		Dim rd As SqlClient.SqlDataReader
		Try

			rd = cmd.ExecuteReader()

			Dim tb As Integer = 0
			Do
				While rd.Read
					Select Case tb
						Case 0
							Dim dr As Bil.DS_Login2.UtentiRow
							dr = ds.Utenti.NewUtentiRow

							Assign(dr, "CodiceUtenteSDC", rd)
							dr.SetCertificatoNull()

							Assign(dr, "Login", rd)
							Assign(dr, "Pwd", rd)
							Assign(dr, "Lingua", rd)

							ds.Utenti.AddUtentiRow(dr)

						Case 1
							Dim dr As Bil.DS_Login2.RelOperatoriUtentiRow
							dr = ds.RelOperatoriUtenti.NewRelOperatoriUtentiRow

							Assign(dr, "CodiceUtenteSDC", rd)
							Assign(dr, "CodiceOperatoreSDC", rd)
							Assign(dr, "TSIniValidita", rd)
							Assign(dr, "TSEndValidita", rd)
							Assign(dr, "CodiceRuolo", rd)
							Assign(dr, "TSModifica", rd)
							Assign(dr, "Amministratore", rd)

							ds.RelOperatoriUtenti.AddRelOperatoriUtentiRow(dr)

						Case 2
							Dim dr As Bil.DS_Login2.OperatoriRow
							dr = ds.Operatori.NewOperatoriRow

							Assign(dr, "StatoBilateraliOperatore", rd)
							Assign(dr, "Abilitato", rd)
							Assign(dr, "CodiceOperatoreSDC", rd)
							Assign(dr, "Amministratore", rd)
							Assign(dr, "RagioneSociale", rd)

							ds.Operatori.AddOperatoriRow(dr)

						Case 3
							Dim dr As Bil.DS_Login2.RuoliRow
							dr = ds.Ruoli.NewRuoliRow

							Assign(dr, "CodiceRuolo", rd)
							Assign(dr, "DescrizioneRuolo", rd)
							Assign(dr, "TSModifica", rd)

							ds.Ruoli.AddRuoliRow(dr)

						Case 4
							Dim dr As Bil.DS_Login2.FunzioniRow
							dr = ds.Funzioni.NewFunzioniRow

							Assign(dr, "CodiceFunzione", rd)
							Assign(dr, "DescrizioneFunzione", rd)
							Assign(dr, "TSModifica", rd)

							ds.Funzioni.AddFunzioniRow(dr)

						Case 5
							Dim dr As Bil.DS_Login2.RuoliFunzioniRow
							dr = ds.RuoliFunzioni.NewRuoliFunzioniRow

							Assign(dr, "CodiceFunzione", rd)
							Assign(dr, "CodiceRuolo", rd)
							Assign(dr, "TSModifica", rd)

							ds.RuoliFunzioni.AddRuoliFunzioniRow(dr)

					End Select
				End While

				tb += 1
			Loop While rd.NextResult

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not rd Is Nothing Then rd.Close()
		End Try


		ds.AcceptChanges()

		If ds.Utenti.Rows.Count = 0 Then Return Nothing
		If ds.RelOperatoriUtenti.Rows.Count = 0 Then Return Nothing
		If ds.Operatori.Rows.Count = 0 Then Return Nothing

		Return ds

	End Function

	Public Function CheckLogin(ByVal loginType As LoginType, ByVal login As String, ByVal pwd As String, ByVal certificate() As Byte) As DS_Login2

		cn.ConnectionString = GetConnectionString()

		Try


			cn.Open()

			Dim reqSN As String
			Dim reqIssuer As String
			If Not certificate Is Nothing Then
				Dim reqCert As New X509Certificate(certificate)
				reqSN = reqCert.GetSerialNumberString
				reqIssuer = reqCert.GetIssuerName
			End If

			If certificate Is Nothing Then
				Return CheckLoginPwd(cn, loginType, login, pwd)
			End If

			Dim ds As New DS_Login2

			' qui controllo la login
			daUtenti.Fill(ds.Utenti)

			Dim drUtenteFound As Bil.DS_Login2.UtentiRow = Nothing

			For Each drUtente As Bil.DS_Login2.UtentiRow In ds.Utenti
				If certificate Is Nothing Then

					If drUtente.IsLoginNull = False AndAlso drUtente.IsPwdNull = False Then
						If drUtente.Login = login AndAlso drUtente.Pwd = pwd Then
							drUtenteFound = drUtente
							Exit For
						End If
					End If

				Else
					If drUtente.IsCertificatoNull = False Then

						Dim zUCert As X509Certificate = New X509Certificate(drUtente.Certificato)
						Dim zUCertIssuer As String = zUCert.GetIssuerName()
						Dim zUCertSN As String = zUCert.GetSerialNumberString()

						If zUCertIssuer = reqIssuer AndAlso zUCertSN = reqSN Then
							drUtenteFound = drUtente
							Exit For
						End If
					End If
				End If
			Next

			' non esiste quell'utente
			If drUtenteFound Is Nothing Then Return Nothing

			' rimuovo tutti gli utenti eccetto quello logato
			If True Then
				Dim toDelete As New ArrayList
				For Each drUtente As Bil.DS_Login2.UtentiRow In ds.Utenti
					If drUtente.CodiceUtenteSDC <> drUtenteFound.CodiceUtenteSDC Then
						toDelete.Add(drUtente)
					End If
				Next
				For Each drUtente As Bil.DS_Login2.UtentiRow In toDelete
					ds.Utenti.RemoveUtentiRow(drUtente)
				Next
			End If


			' qui controllo il numero di operatori possibili
			' nel frattempo tolgo da RelOperatoriUtenti le accoppiate ut/op con non contengono l'ut
			daRelOperatoriUtenti.SelectCommand.Parameters("@d").Value = DateTime.Now.Date
			daRelOperatoriUtenti.SelectCommand.Parameters("@a").Value = (loginType = loginType.Admin)
			daRelOperatoriUtenti.Fill(ds.RelOperatoriUtenti)

			If True Then
				Dim toDelete As New ArrayList
				For Each drRelOperatoriUtenti As Bil.DS_Login2.RelOperatoriUtentiRow In ds.RelOperatoriUtenti
					If drRelOperatoriUtenti.CodiceUtenteSDC <> drUtenteFound.CodiceUtenteSDC Then
						toDelete.Add(drRelOperatoriUtenti)
					End If
				Next
				For Each drRelOperatoriUtenti As Bil.DS_Login2.RelOperatoriUtentiRow In toDelete
					ds.RelOperatoriUtenti.RemoveRelOperatoriUtentiRow(drRelOperatoriUtenti)
				Next
			End If

			' se non ci sono operatori disponibili e` come se avesse sbagliato la password
			If ds.RelOperatoriUtenti.Count = 0 Then
				Return Nothing
			End If

			' carico tutti gli operatori
			daOperatori.Fill(ds.Operatori)

			' scarto gli operatori che non sono ds.RelOperatoriUtenti
			' per l'utente logato
			If True Then
				Dim toDelete As New ArrayList
				For Each drOperatori As Bil.DS_Login2.OperatoriRow In ds.Operatori
					Dim amministratore As Integer = 0
					If loginType = loginType.Admin Then amministratore = 1
					If ds.RelOperatoriUtenti.FindByCodiceUtenteSDCCodiceOperatoreSDCAmministratore(drUtenteFound.CodiceUtenteSDC, drOperatori.CodiceOperatoreSDC, amministratore) Is Nothing Then
						toDelete.Add(drOperatori)
					End If
				Next
				For Each drOperatori As Bil.DS_Login2.OperatoriRow In toDelete
					ds.Operatori.RemoveOperatoriRow(drOperatori)
				Next
			End If

			If ds.Operatori.Count = 0 Then
				Return Nothing
			End If

			' qui non vado per il sottile: carico tutto
			daRuoli.Fill(ds.Ruoli)
			daFunzioni.Fill(ds.Funzioni)
			daRuoliFunzioni.Fill(ds.RuoliFunzioni)

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	Public Function ChangeOperatore(ByVal loginType As LoginType, ByVal ds As Bil.DS_Login2, ByVal codiceOperatoreSDC As String, ByRef codiceRuolo As String) As String()

		Dim codiceUtenteSDC As String = ds.Utenti(0).CodiceUtenteSDC

		Dim amministratore As Integer = 0
		If loginType = loginType.Admin Then amministratore = 1
		codiceRuolo = ds.RelOperatoriUtenti.FindByCodiceUtenteSDCCodiceOperatoreSDCAmministratore(codiceUtenteSDC, codiceOperatoreSDC, amministratore).CodiceRuolo

		Dim drRF() As DataRow
		drRF = ds.RuoliFunzioni.Select(String.Format("CodiceRuolo = '{0}'", codiceRuolo))
		If drRF.Length = 0 Then
			' non ci sono funzioni associate al Ruolo
			Dim vf() As String
			Return vf
		Else
			Dim drRuoliFunzioni As Bil.DS_Login2.RuoliFunzioniRow
			Dim vf(drRF.Length - 1) As String

			Dim iCnt As Integer = 0
			For Each drRuoliFunzioni In drRF
				vf(iCnt) = drRuoliFunzioni.CodiceFunzione
				iCnt += 1
			Next
			Return vf
		End If

	End Function

	Public Function CheckMPN(ByVal loginType As LoginType, ByVal codiceUtenteSDC As String, ByVal codiceOperatoreSDC As String) As Boolean
		cn.ConnectionString = GetConnectionString()

		Try

			Dim ds As New DS_Login2

			cn.Open()

			' qui controllo la login
			daRelOperatoriUtenti.SelectCommand.Parameters("@d").Value = DateTime.Now.Date
			daRelOperatoriUtenti.SelectCommand.Parameters("@a").Value = (loginType = loginType.Admin)
			daRelOperatoriUtenti.Fill(ds.RelOperatoriUtenti)

			Dim amministratore As Integer = 0
			If loginType = loginType.Admin Then amministratore = 1


			Dim dr As DS_Login2.RelOperatoriUtentiRow
			dr = ds.RelOperatoriUtenti.FindByCodiceUtenteSDCCodiceOperatoreSDCAmministratore(codiceUtenteSDC, codiceOperatoreSDC, amministratore)

			If dr Is Nothing Then Return False
			Return True

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function


End Class
