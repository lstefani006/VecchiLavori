Imports System.IO
Imports System.Configuration

Public Class DBStatComp
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdExecute As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.cmdExecute = New System.Data.SqlClient.SqlCommand
        '
        'cmdExecute
        '
        Me.cmdExecute.Connection = Me.cn

    End Sub

#End Region


    Private OriginalDBName As String
    Private saManagerPassword As String
    Private tmoQuery As Integer
    Private connectionString As String


    Public Event OnExecutionMessage(ByVal Msg As String)

    Class ExecutionResult
        Public Sub New()
            NewDBName = ""
            NewDBDataFileName = ""
            NewDBLogFileName = ""
            ExecutionStatus = False
            ErrorMessage = ""
        End Sub
        Public ExecutionStatus As Boolean
        Public ErrorMessage As String
        Public NewDBName As String
        Public NewDBDataFileName As String
        Public NewDBLogFileName As String
    End Class

    Class SQLParseClass
        '
        ' Costruttore
        '
        Public Sub New()
            bDBVoidAttached = False
            bDBNewDataFileCopied = False
            bDBNewLogFileCopied = False
            bDBNewAttached = False
            DataRicerca = Date.MinValue
            NextQueryTimeOut = 30
            OriginalDB = ""
            DestinationDB = ""
            SQLFileOriginalDB = ""
            SQLFileDestinationDB = ""
            DBNameVoid = ""
            DBDataFileNameVoid = ""
            DBLogFileNameVoid = ""
            NewDBName = ""
            NewDBDataFileName = ""
            NewDBLogFileName = ""
            messageIndicator = "--Message: "
            originalDBIndicator = "--OriginalDB: "
            destinationDBIndicator = "--DestinationDB: "
            dataRicercaIndicator = "--DataRicerca: "
            tmoNextQueryIndicator = "--TmoQuery: "
            commentIndicator = "--"
        End Sub

        Public bDBVoidAttached As Boolean
        Public bDBNewAttached As Boolean
        Public bDBNewDataFileCopied As Boolean
        Public bDBNewLogFileCopied As Boolean
        Public DataRicerca As Date
        Public NextQueryTimeOut As Integer

        Public DBNameVoid As String
        Public DBDataFileNameVoid As String
        Public DBLogFileNameVoid As String

        Public NewDBName As String
        Public NewDBDataFileName As String
        Public NewDBLogFileName As String

        Public OriginalDB As String
        Public DestinationDB As String
        Public SQLFileOriginalDB As String
        Public SQLFileDestinationDB As String
        Public SQLFileDataRicerca As String
        Public messageIndicator As String
        Public originalDBIndicator As String
        Public destinationDBIndicator As String
        Public dataRicercaIndicator As String
        Public commentIndicator As String
        Public tmoNextQueryIndicator As String
    End Class

    ' funzione da chiamare per ottenere la connessione al db di default
    ' Da definirsi nel caso si volesse usare questo modulo in isolamento
    '
    ' Public Shared Function GetConnectionString() As String
    '     Dim s As String = ConfigurationSettings.AppSettings("SqlConnectionString")
    '    Return s
    ' End Function

    Public Sub InitializeConnection()
        '
        ' Password dell'utente sa (da file configurazione)
        '
        saManagerPassword = ConfigurationSettings.AppSettings("saPassword")
        '
        ' Carica DB e parametri per la connessione e la password dell'utente sa
        '
        InitConnectionString()
    End Sub

    '
    ' Costruisce la connection string per la connessione con l'utente privilegiato sa
    ' a nessun DB particolare
    ' Ottiene anche il nome del DB utilizzato per la connessione di default
    '
    Private Sub InitConnectionString()
        Dim sDefaultConnectionString As String = GetConnectionString()
        cn.ConnectionString = sDefaultConnectionString
        Dim sConnectionString As String = "Data Source=" & cn.DataSource & ";" & _
                       "Initial Catalog='';" & _
                       "User ID=sa;" & _
                       "Password=" & saManagerPassword
        OriginalDBName = cn.Database
        connectionString = sConnectionString
    End Sub

    '
    ' ottiene la connection string da utilizzare 
    '
    Private Function LoadConnectionString() As String
        Return connectionString
    End Function

    '
    ' Funzione che utilizzando la stored procedure di sistema sp_attach_db esegue l'attach di un datafile
    ' Esempio:
    ' EXEC sp_attach_db @dbname =N'BilateraliT1102', @filename1 = N'D:\Program Files\Microsoft SQL Server\MSSQL\Data\BilateraliT1102_Data.mdf', @filename2 = N'D:\Program Files\Microsoft SQL Server\MSSQL\Data\BilateraliT1102_Log.ldf'
    Public Sub AttachDB(ByVal DBName As String, ByVal PathDBData As String, ByVal PathDBLog As String)
        Dim cmdText As String = "EXEC sp_attach_db  @dbname=N'" & DBName & "', @filename1=N'" & PathDBData & "', @filename2='" & PathDBLog & "';"
        cn.ConnectionString = LoadConnectionString()
        Try
            cn.Open()
            cmdExecute.CommandText = cmdText
            cmdExecute.CommandTimeout = tmoQuery
            cmdExecute.ExecuteNonQuery()
		Catch ex As Exception
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Sub

    '
    ' Funzione che utilizzando la stored procedure di sistema sp_detach_db esegue il detach dei datafiles 
    '
    Public Sub DetachDB(ByVal DBName As String)
        cn.ConnectionString = LoadConnectionString()
        Try
            cn.Open()
            cmdExecute.CommandText = "EXEC sp_detach_db '" & DBName & "','false';"
            cmdExecute.CommandTimeout = tmoQuery
            cmdExecute.ExecuteNonQuery()
            cmdExecute.Connection.Close()
        Catch ex As Exception
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Sub

    '
    ' Funzione che utilizzando il comando:
    '  ALTER DATABASE BilateraliDev MODIFY FILE (NAME='OldDBFileName', NEWNAME='NewDBFileName')
    ' modifica i nomi logici associati ai datafile di un database
    '
    Public Sub ReNameDBFile(ByVal DBName As String, ByVal OldDBFileName As String, ByVal NewDBFileName As String)
        Dim cmdText As String = "ALTER DATABASE " & DBName & " MODIFY FILE (NAME='" & OldDBFileName & "', NEWNAME='" & NewDBFileName & "')"
        cn.ConnectionString = LoadConnectionString()
        Try
            cn.Open()
            cmdExecute.CommandText = cmdText
            cmdExecute.CommandTimeout = tmoQuery
            cmdExecute.ExecuteNonQuery()
		Catch ex As Exception
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Sub


    ' 
    ' Funzione che esegue lo shrinking (= riduzione in size dei corrispondenti file) 
    ' di un database. Esempio:
    '   DBCC SHRINKDATABASE (BilateraliDev20040910, 25)
    ' Il numero 25 rappresenta la percentuale (25%) dello spazio libero lasciato
    ' nel file del database dopo che lo shrinking e' stato effettuato
    ' 
    Public Sub ShrinkDatabase(ByVal DBName As String, ByVal Percentage As Integer)
        Dim cmdText As String = "DBCC SHRINKDATABASE (" & DBName & "," & Percentage.ToString() & ")"
        cn.ConnectionString = LoadConnectionString()
        Try
            cn.Open()
            cmdExecute.CommandText = cmdText
            cmdExecute.CommandTimeout = tmoQuery
            cmdExecute.ExecuteNonQuery()
		Catch ex As Exception
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Sub


    '
    ' Funzione che utilizzando la stored procedure di sistema xp_cmdshell esegue la copia (sulla macchina del database)
    ' di un datafile in un altro datafile
    '
    Public Sub ExecuteDBFileCopy(ByVal FilenameFrom As String, ByVal FileNameTo As String)
        ' xp_cmdshell 'copy FilenameFrom FileNameTo'
        Dim cmdShell As String = "copy """ & FilenameFrom & """  """ & FileNameTo
        Dim cmdText As String = "EXEC xp_cmdshell '" & cmdShell & "';"
        cn.ConnectionString = LoadConnectionString()
        Try
            cn.Open()
            cmdExecute.CommandText = cmdText
            cmdExecute.CommandTimeout = tmoQuery
            cmdExecute.ExecuteNonQuery()
		Catch ex As Exception
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

    '
    ' Funzione che utilizzando la stored procedure di sistema xp_cmdshell esegue la copia (sulla macchina del database)
    ' di un datafile in un altro datafile
    '
    Public Sub ExecuteDBFileRemove(ByVal Filename As String)
        ' xp_cmdshell 'del Filename'
        Dim cmdShell As String = "del """ & Filename & """"
        Dim cmdText As String = "EXEC xp_cmdshell '" & cmdShell & "';"
        cn.ConnectionString = LoadConnectionString()
        Try
            cn.Open()
            cmdExecute.CommandText = cmdText
            cmdExecute.CommandTimeout = tmoQuery
            cmdExecute.ExecuteNonQuery()
		Catch ex As Exception
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

    '
    ' Funzione che utilizzando la stored procedure di sistema xp_cmdshell 
    ' Esegue la creazione di una Directory sul datafile del DB
    '
    Public Sub ExecuteDBFileCreateDir(ByVal PathNewDir As String)
        ' xp_cmdshell 'mkdir PathNewDir'
        Dim cmdShell As String = "mkdir """ & PathNewDir & """"
        Dim cmdText As String = "EXEC xp_cmdshell '" & cmdShell & "';"
        cn.ConnectionString = LoadConnectionString()
        Try
            cn.Open()
            cmdExecute.CommandText = cmdText
            cmdExecute.CommandTimeout = tmoQuery
            cmdExecute.ExecuteNonQuery()
		Catch ex As Exception
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub


	'
    ' Esegue il singolo comando in forma testuale
    ' devo specificare se il comando e' parametrico con parametro = DataRicerca e inserire il parametro
    '
    Private Sub ExecuteSingleCommand(ByVal cmdText As String, ByVal bIsParametric As Boolean, ByVal parseClass As SQLParseClass)
        Try
            cmdExecute.CommandText = cmdText
            cmdExecute.CommandTimeout = parseClass.NextQueryTimeOut
            If bIsParametric Then
                cmdExecute.Parameters.Add(New System.Data.SqlClient.SqlParameter(parseClass.SQLFileDataRicerca, System.Data.SqlDbType.DateTime, 8))
                cmdExecute.Parameters(parseClass.SQLFileDataRicerca).Value = parseClass.DataRicerca
            End If
            cmdExecute.ExecuteNonQuery()
        Catch ex As Exception
            Throw
        Finally
            ' Fine esecuzione: rimuovi eventuale parametro usato nella query
            If bIsParametric Then
                cmdExecute.Parameters.RemoveAt(parseClass.SQLFileDataRicerca)
            End If
        End Try
    End Sub

    '
    ' Funzione per effettuare il rollback di tutte le modifiche effettuate 
    '
    Private Sub RollbackExecution(ByVal parseClass As SQLParseClass)
        If parseClass.bDBNewAttached Then
            Try
                DetachDB(parseClass.NewDBName)
                parseClass.bDBNewAttached = False
            Catch
            End Try

        End If
        If parseClass.bDBNewDataFileCopied Then
            Try
                ExecuteDBFileRemove(parseClass.NewDBDataFileName)
                parseClass.bDBNewDataFileCopied = False
            Catch
            End Try
        End If
        If parseClass.bDBNewLogFileCopied Then
            Try
                ExecuteDBFileRemove(parseClass.NewDBLogFileName)
                parseClass.bDBNewLogFileCopied = False
            Catch
            End Try
        End If
    End Sub

    '
    ' Esecuzione della singola linea degli scripts di Dump di Stato0/Stato1
    '
    Private Sub ExecuteLineFromDumpScript(ByVal ExecutionLine As String, ByRef parseClass As SQLParseClass)

        Dim messageString As String
        Dim cmdText As String

        '
        ' Messaggio verso User interface: RaiseEvent
        '
        If ExecutionLine.StartsWith(parseClass.messageIndicator) Then
            messageString = ExecutionLine.Substring(parseClass.messageIndicator.Length)
            RaiseEvent OnExecutionMessage(messageString)
            Exit Sub
        End If

        '
        ' Lettura identificatore DataRicerca
        '
        If ExecutionLine.StartsWith(parseClass.dataRicercaIndicator) Then
            parseClass.SQLFileDataRicerca = ExecutionLine.Substring(parseClass.dataRicercaIndicator.Length)
            Exit Sub
        End If

        '
        ' Lettura DB Origine
        '
        If ExecutionLine.StartsWith(parseClass.originalDBIndicator) Then
            parseClass.SQLFileOriginalDB = ExecutionLine.Substring(parseClass.originalDBIndicator.Length)
            Exit Sub
        End If
        '
        ' Lettura DB Destinazione
        '
        If ExecutionLine.StartsWith(parseClass.destinationDBIndicator) Then
            parseClass.SQLFileDestinationDB = ExecutionLine.Substring(parseClass.destinationDBIndicator.Length)
            Exit Sub
        End If

        '
        ' Lettura dell'eventuale Timeout prossima query
        '
        If ExecutionLine.StartsWith(parseClass.tmoNextQueryIndicator) Then
            parseClass.NextQueryTimeOut = tmoQuery
            Try
                parseClass.NextQueryTimeOut = Int32.Parse(ExecutionLine.Substring(parseClass.tmoNextQueryIndicator.Length))
            Catch ex As Exception
                parseClass.NextQueryTimeOut = tmoQuery
            End Try
            Exit Sub
        End If


        '
        ' Commento oppure linea vuota: salta
        '
        If ExecutionLine.StartsWith(parseClass.commentIndicator) Or ExecutionLine.Length = 0 Then
            Exit Sub
        End If


        Dim cmdToExecute As String = ExecutionLine
        Dim bParametricQuery As Boolean = False

        '
        'Sostituisci l'identificatore del DB Originario sul file SQL con quello che si vuole 
        '
        If parseClass.SQLFileOriginalDB <> String.Empty AndAlso parseClass.OriginalDB <> String.Empty Then
            cmdToExecute = cmdToExecute.Replace(parseClass.SQLFileOriginalDB, parseClass.OriginalDB)
        End If
        '
        'Sostituisci l'identificatore del DB Destinazione sul file SQL con quello che si vuole 
        '
        If parseClass.SQLFileDestinationDB <> String.Empty AndAlso parseClass.NewDBName <> String.Empty Then
            cmdToExecute = cmdToExecute.Replace(parseClass.SQLFileDestinationDB, parseClass.NewDBName)
        End If

        '
        ' Controlla se la query e' di tipo parametrico (cioe' se la stringa di comando contiene 
        ' il valore parseClass.SQLFileDataRicerca (solitamente uguale a @DataRicerca)
        '
        If parseClass.SQLFileDataRicerca <> String.Empty Then
            If cmdToExecute.IndexOf(parseClass.SQLFileDataRicerca) >= 0 Then
                bParametricQuery = True
            End If
        End If
        cmdText = cmdToExecute
        ExecuteSingleCommand(cmdText, bParametricQuery, parseClass)

        ' riporta il timeout al valore di default dopo l'esecuzione della query
        parseClass.NextQueryTimeOut = tmoQuery

    End Sub


    '
    ' Esecuzione della singola linea dello script di cancellazione
    '
    Private Sub ExecuteLineFromDeleteScript(ByVal ExecutionLine As String, ByRef parseClass As SQLParseClass)

        Dim messageString As String
        Dim cmdText As String

        '
        ' Messaggio verso User interface: RaiseEvent
        '
        If ExecutionLine.StartsWith(parseClass.messageIndicator) Then
            messageString = ExecutionLine.Substring(parseClass.messageIndicator.Length)
            RaiseEvent OnExecutionMessage(messageString)
            Exit Sub
        End If

        '
        ' Lettura identificatore DataRicerca
        '
        If ExecutionLine.StartsWith(parseClass.dataRicercaIndicator) Then
            parseClass.SQLFileDataRicerca = ExecutionLine.Substring(parseClass.dataRicercaIndicator.Length)
            Exit Sub
        End If

        '
        ' Lettura dell'eventuale Timeout prossima query
        '
        If ExecutionLine.StartsWith(parseClass.tmoNextQueryIndicator) Then
            parseClass.NextQueryTimeOut = tmoQuery
            Try
                parseClass.NextQueryTimeOut = Int32.Parse(ExecutionLine.Substring(parseClass.tmoNextQueryIndicator.Length))
            Catch ex As Exception
                parseClass.NextQueryTimeOut = tmoQuery
            End Try
            Exit Sub
        End If

        '
        ' Lettura DB Originario
        '
        If ExecutionLine.StartsWith(parseClass.originalDBIndicator) Then
            parseClass.SQLFileOriginalDB = ExecutionLine.Substring(parseClass.originalDBIndicator.Length)
            Exit Sub
        End If

        '
        ' Commento oppure linea vuota: salta
        '
        If ExecutionLine.StartsWith(parseClass.commentIndicator) Or ExecutionLine.Length = 0 Then
            Exit Sub
        End If


        Dim cmdToExecute As String = ExecutionLine
        Dim bParametricQuery As Boolean = False

        '
        'Sostituisci l'identificatore del DB Originario sul file SQL con quello che si vuole 
        '
        If parseClass.SQLFileOriginalDB <> String.Empty AndAlso parseClass.OriginalDB <> String.Empty Then
            cmdToExecute = cmdToExecute.Replace(parseClass.SQLFileOriginalDB, parseClass.OriginalDB)
        End If
        '
        ' Controlla se la query e' di tipo parametrico (cioe' se la stringa di comando contiene 
        ' il valore parseClass.SQLFileDataRicerca (solitamente uguale a @DataRicerca)
        '
        If parseClass.SQLFileDataRicerca <> String.Empty Then
            If cmdToExecute.IndexOf(parseClass.SQLFileDataRicerca) >= 0 Then
                bParametricQuery = True
            End If
        End If
        cmdText = cmdToExecute
        ExecuteSingleCommand(cmdText, bParametricQuery, parseClass)

        ' riporta il timeout al valore di default dopo l'esecuzione della query
        parseClass.NextQueryTimeOut = tmoQuery

    End Sub


    '
    ' Funzione utilizzata per eseguire il parse del file di script utilizzato per effettuare il Dump di Stato0/Stato1
    '
    Private Sub ParseAndExecuteDumpSQLScript(ByVal ExecutionPathFileName As String, ByRef parseClass As SQLParseClass)
        If File.Exists(ExecutionPathFileName) = True Then
            Dim sr As StreamReader = Nothing
            Dim currLine As String
            Try
                ' Apri il file
                sr = File.OpenText(ExecutionPathFileName)
				cn.Open()
                '
                ' Scandisci il file dello script fino alla fine per l'esecuzione 
                '
                Do While sr.Peek() >= 0
                    currLine = sr.ReadLine()
                    ExecuteLineFromDumpScript(currLine, parseClass)
                Loop
                sr.Close()
			Catch
				Throw
			Finally
				If cn.State = ConnectionState.Open Then cn.Close()

				If Not sr Is Nothing Then
					sr.Close()
				End If
			End Try
		Else
            Throw New Exception("FileName specificato per l'esecuzione: " & ExecutionPathFileName & " non esistente")
        End If
    End Sub

    '
    ' Funzione utilizzata per eseguire il parse del file di script utilizzato per la cancellazione dei dati piu'
    ' vecchi di una certa data
    '
    Private Sub ParseAndExecuteDeleteSQLScript(ByVal ExecutionPathFileName As String, ByRef parseClass As SQLParseClass)
        If File.Exists(ExecutionPathFileName) = True Then
            Dim sr As StreamReader = Nothing
            Dim currLine As String
            Try
                ' Apri il file
                sr = File.OpenText(ExecutionPathFileName)
				cn.Open()				   '

                ' Scandisci il file dello script fino alla fine per l'esecuzione 
                '
                Do While sr.Peek() >= 0
                    currLine = sr.ReadLine()
                    ExecuteLineFromDeleteScript(currLine, parseClass)
                Loop
                sr.Close()
			Catch
				Throw
			Finally
				If cn.State = ConnectionState.Open Then cn.Close()
				If Not sr Is Nothing Then
					sr.Close()
				End If
			End Try
		Else
            Throw New Exception("FileName specificato per l'esecuzione: " & ExecutionPathFileName & " non esistente")
        End If
    End Sub


    '
    ' Esecuzione vera e propria dello script associato al file
    '
    Private Function ExecuteStateTypeSQLScriptFile(ByVal DumpDate As Date, _
                                                    ByVal StateType As String, _
                                                    ByVal ExecutionPathFileName As String, _
                                                    ByVal DBFilesPathRoot As String, _
                                                    ByVal DBNameRif As String, _
                                                    ByVal DBDataFileNameVoid As String, _
                                                    ByVal DBDataFileIdentifierVoid As String, _
                                                    ByVal DBLogFileNameVoid As String, _
                                                    ByVal DBLogFileIdentifierVoid As String _
                                                    ) As ExecutionResult


        Dim exResult As ExecutionResult = New ExecutionResult

        Dim completePathFileName As String

        completePathFileName = AppDomain.CurrentDomain.SetupInformation.ApplicationBase
        completePathFileName += ExecutionPathFileName

        '
        ' Check che il file esista
        '
        If File.Exists(completePathFileName) = False Then
            Throw New Exception("FileName specificato per l'esecuzione: " & completePathFileName & " non esistente")
        End If
        Dim parseClass As SQLParseClass = New SQLParseClass
        Dim NewDBName As String
        Dim NewDBDataFileName As String
        Dim NewDBDataIdentifier As String
        Dim NewDBLogIdentifier As String
        Dim NewDBFilesPath As String


        Dim DBDataFileNameVoidComplete As String = DBFilesPathRoot & "\" & DBDataFileNameVoid
        Dim DBLogFileNameVoidComplete As String = DBFilesPathRoot & "\" & DBLogFileNameVoid

        Dim NewDBLogFileName As String
        Dim currentDate As DateTime = DateTime.Now
        Dim strDumpAndCurrentDates As String = DumpDate.ToString("yyyyMMdd") & "_" & currentDate.ToString("yyyyMMddHHmmssffff")

        '
        ' Setta il timeout di default delle query SQL
        '
        parseClass.NextQueryTimeOut = tmoQuery


        '
        ' NewDBName: identificato dal nome del vecchio DB + Identificatore stato + stringa di DataFlow/DataCurrent
        '
        NewDBName = DBNameRif & "_" & StateType & "_" & strDumpAndCurrentDates

        '
        ' File Path = FileRoot + "\" + DataFlow (formato YYYYMMDD)
        '
        NewDBFilesPath = DBFilesPathRoot & "\" & DumpDate.ToString("yyyyMMdd")

        '
        ' fileName (Data/Log) = FilePath + NewDBNAME + _Data.MDF/_Log.LDF
        '
        NewDBDataFileName = NewDBFilesPath & "\" & NewDBName & "_Data.MDF"
        NewDBLogFileName = NewDBFilesPath & "\" & NewDBName & "_Log.LDF"
        NewDBDataIdentifier = NewDBName & "_Data"
        NewDBLogIdentifier = NewDBName & "_Log"
        Try
            '
            ' Riporta OriginalDBName e DataRicerca
            '
            parseClass.OriginalDB = OriginalDBName
            parseClass.DataRicerca = DumpDate

            '
            ' Crea (se non esiste) directory sul DB Server dove vengono messi i files  
            '
            ExecuteDBFileCreateDir(NewDBFilesPath)

            '
            ' copia i datafile vuoti in nuovi datafiles
            '
            ExecuteDBFileCopy(DBDataFileNameVoidComplete, NewDBDataFileName)
            parseClass.NewDBDataFileName = NewDBDataFileName
            parseClass.bDBNewDataFileCopied = True
            ExecuteDBFileCopy(DBLogFileNameVoidComplete, NewDBLogFileName)
            parseClass.NewDBLogFileName = NewDBLogFileName
            parseClass.bDBNewLogFileCopied = True

            '
            ' Attach i nuovi datafiles su un nuovo database
            '
            AttachDB(NewDBName, NewDBDataFileName, NewDBLogFileName)
            parseClass.NewDBName = NewDBName
            parseClass.NewDBDataFileName = NewDBDataFileName
            parseClass.NewDBLogFileName = NewDBLogFileName
            parseClass.bDBNewAttached = True

            ' 
            ' Rename degli identificatori associati ai datafiles
            '
            ReNameDBFile(NewDBName, DBDataFileIdentifierVoid, NewDBDataIdentifier)
            ReNameDBFile(NewDBName, DBLogFileIdentifierVoid, NewDBLogIdentifier)

            '
            ' Esecuzione dello script 
            '
            ParseAndExecuteDumpSQLScript(completePathFileName, parseClass)

            '
            ' Detach del nuovo database
            '
            DetachDB(NewDBName)

            '
            ' Riporta il risultato dell'esecuzione
            '
            exResult.ExecutionStatus = True
            exResult.NewDBName = NewDBName
            exResult.NewDBDataFileName = NewDBDataFileName
            exResult.NewDBLogFileName = NewDBLogFileName
            exResult.ErrorMessage = "Esecuzione OK"
        Catch ex As Exception
            RollbackExecution(parseClass)
            exResult.ErrorMessage = ex.Message
            Throw
        Finally
        End Try
        Return exResult
    End Function

    '
    ' Esecuzione vera e propria dello script associato al file
    '
    Private Function ExecuteDeleteScriptFile(ByVal ExecutionPathFileName As String, _
                                             ByVal UntilDate As Date) As ExecutionResult

        Dim exResult As ExecutionResult = New ExecutionResult
        Dim completePathFileName As String

        completePathFileName = AppDomain.CurrentDomain.SetupInformation.ApplicationBase
        completePathFileName += ExecutionPathFileName

        '
        ' Check che il file esista
        '
        If File.Exists(completePathFileName) = False Then
            Throw New Exception("FileName specificato per l'esecuzione: " & completePathFileName & " non esistente")
        End If
        Dim parseClass As SQLParseClass = New SQLParseClass


        '
        ' Timeout di default delle query
        '
        parseClass.NextQueryTimeOut = tmoQuery
        parseClass.OriginalDB = OriginalDBName
        parseClass.DataRicerca = UntilDate
        Try
            '
            ' Esecuzione dello script 
            '
            ParseAndExecuteDeleteSQLScript(completePathFileName, parseClass)
            '
            ' Riporta il risultato dell'esecuzione
            '
            exResult.ExecutionStatus = True
            exResult.ErrorMessage = "Esecuzione OK"
        Catch ex As Exception
            exResult.ErrorMessage = ex.Message
            Throw
        Finally
        End Try
        Return exResult
    End Function



    '
    ' Funzione associata all'esecuzione dello script di Stato0
    '
    Public Function ExecuteStato0Dump(ByVal DumpDate As Date) As ExecutionResult

        '
        ' Inizializza connessione
        '
        InitializeConnection()

        '
        ' Query Timeout in secondi (alcune query possono avere tempi lunghi di esecuzione)
        ' Di default le query hanno tempo di esecuzione 30 secondi
        '
        Dim sQueryTmo As String = ConfigurationSettings.AppSettings("QueryTmo")
        tmoQuery = 30
        Try
            tmoQuery = Int32.Parse(sQueryTmo)
        Catch ex As Exception
            tmoQuery = 30
        End Try

        '
        ' Path dello script da eseguire per effettuare il Dump dello Stato0
        '
        Dim ScriptFileStato0 As String = ConfigurationSettings.AppSettings("Stato0Script")

        '
        ' Nome del DB vuoto di riferimento che viene preso come base per effettuare i dump Stato0/Stato1
        ' Deve essere un DB vuoto con lo stesso schema della connessione principale (e possibilmente "Shrinked")
        '
        Dim DBNameRif As String = ConfigurationSettings.AppSettings("DBNameRif")

        '
        ' Path nel File System associato al DB dove si trova il datafile del DB vuoto di riferimento che viene preso 
        ' come base per effettuare i dump di stato0/stato1
        '
        Dim DBDataFileNameVoid As String = ConfigurationSettings.AppSettings("DBDataFileNameVoid")

        '
        ' Path nel File System associato al DB dove si trova il logfile del DB vuoto di riferimento che viene preso 
        ' come base per effettuare i dump di stato0/stato1
        '
        Dim DBLogFileNameVoid As String = ConfigurationSettings.AppSettings("DBLogFileNameVoid")

        '
        ' Identificatore associato al datafile del DB vuoto di riferimento che viene preso come base per effettuare i dump di stato0/stato1
        '
        Dim DBDataFileIdentifierVoid As String = ConfigurationSettings.AppSettings("DBDataFileIdentifierVoid")
        '
        ' Identificatore associato al logfile del DB vuoto di riferimento che viene preso come base per effettuare i dump di stato0/stato1
        '
        Dim DBLogFileIdentifierVoid As String = ConfigurationSettings.AppSettings("DBLogFileIdentifierVoid")

        '
        ' Base del Path dove deve essere messo il file con i Dump di Stato0/Stato1 (sul filesystem associato al DB)
        ' A questo Path viene aggiunto un ramo contenente la data in formato YYYYMMDD, in modo da raggruppare
        ' tutti i files di stato0/stato1 relativi ad una certa data
        ' e dove vengono messi i db di riferimento per i dump di stato0/stato1
        '
        Dim DBFilePath As String = ConfigurationSettings.AppSettings("DBFilePath")


        Return ExecuteStateTypeSQLScriptFile(DumpDate, "Stato0", ScriptFileStato0, _
                                      DBFilePath, DBNameRif, DBDataFileNameVoid, DBDataFileIdentifierVoid, _
                                      DBLogFileNameVoid, DBLogFileIdentifierVoid)

    End Function

    '
    ' Funzione associata all'esecuzione dello script di Stato1
    '
    Public Function ExecuteStato1Dump(ByVal DumpDate As Date) As ExecutionResult

        '
        ' Inizializza connessione
        '
        InitializeConnection()

        '
        ' Query Timeout in secondi (alcune query possono avere tempi lunghi di esecuzione)
        ' Di default le query hanno tempo di esecuzione 30 secondi
        '
        Dim sQueryTmo As String = ConfigurationSettings.AppSettings("QueryTmo")
        tmoQuery = 30
        Try
            tmoQuery = Int32.Parse(sQueryTmo)
        Catch ex As Exception
            tmoQuery = 30
        End Try

        '
        ' Path dello script da eseguire per effettuare il Dump dello Stato1
        '
        Dim ScriptFileStato1 As String = ConfigurationSettings.AppSettings("Stato1Script")

        '
        ' Nome del DB vuoto di riferimento che viene preso come base per effettuare i dump Stato0/Stato1
        ' Deve essere un DB vuoto con lo stesso schema della connessione principale (e possibilmente "Shrinked")
        '
        Dim DBNameRif As String = ConfigurationSettings.AppSettings("DBNameRif")

        '
        ' Path nel File System associato al DB dove si trova il datafile del DB vuoto di riferimento che viene preso 
        ' come base per effettuare i dump di stato0/stato1
        '
        Dim DBDataFileNameVoid As String = ConfigurationSettings.AppSettings("DBDataFileNameVoid")

        '
        ' Path nel File System associato al DB dove si trova il logfile del DB vuoto di riferimento che viene preso 
        ' come base per effettuare i dump di stato0/stato1
        '
        Dim DBLogFileNameVoid As String = ConfigurationSettings.AppSettings("DBLogFileNameVoid")

        '
        ' Identificatore associato al datafile del DB vuoto di riferimento che viene preso come base per effettuare i dump di stato0/stato1
        '
        Dim DBDataFileIdentifierVoid As String = ConfigurationSettings.AppSettings("DBDataFileIdentifierVoid")
        '
        ' Identificatore associato al logfile del DB vuoto di riferimento che viene preso come base per effettuare i dump di stato0/stato1
        '
        Dim DBLogFileIdentifierVoid As String = ConfigurationSettings.AppSettings("DBLogFileIdentifierVoid")

        '
        ' Base del Path dove deve essere messo il file con i Dump di Stato0/Stato1 (sul filesystem associato al DB)
        ' A questo Path viene aggiunto un ramo contenente la data in formato YYYYMMDD, in modo da raggruppare
        ' tutti i files di stato0/stato1 relativi ad una certa data
        ' e dove vengono messi i db di riferimento per i dump di stato0/stato1
        '
        Dim DBFilePath As String = ConfigurationSettings.AppSettings("DBFilePath")


        Return ExecuteStateTypeSQLScriptFile(DumpDate, "Stato1", ScriptFileStato1, DBFilePath, _
                                      DBNameRif, DBDataFileNameVoid, DBDataFileIdentifierVoid, _
                                      DBLogFileNameVoid, DBLogFileIdentifierVoid)

    End Function

    '
    ' Funzione associata all'esecuzione dello script di cancellazione 
    ' dei dati piu' vecchi di una certa data dal DB
    '
    Public Function PurgeDataFromDBUntil(ByVal UntilDate As Date) As ExecutionResult

        '
        ' Inizializza connessione
        '
        InitializeConnection()
        '
        ' Query Timeout in secondi (alcune query possono avere tempi lunghi di esecuzione)
        ' Di default le query hanno tempo di esecuzione 30 secondi
        '
        Dim sQueryTmo As String = ConfigurationSettings.AppSettings("QueryTmo")
        tmoQuery = 30
        Try
            tmoQuery = Int32.Parse(sQueryTmo)
        Catch ex As Exception
            tmoQuery = 30
        End Try

        '
        ' Path dello script da eseguire per effettuare la cancellazione selettiva
        '
        Dim ScriptDeleteFrom As String = ConfigurationSettings.AppSettings("DeleteFromScript")

        Return ExecuteDeleteScriptFile(ScriptDeleteFrom, UntilDate)
    End Function

    '
    ' Funzinoe di aggancio per il progress dei messaggi
    '
    Public Sub WriteMessage(ByVal Msg As String)
        BatchSerializer.SetProgressBatch(Msg)
    End Sub

    '
    ' Batch di Calcolo DB Stato Zero
    '
	Public Sub CalcolaStatoZeroBatch(ByVal dataProgramma As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf CalcolaStatoZeroAsync, dataProgramma, "CALCSZERO", "Calcolo Stato Zero", dataProgramma, runningOperator)
	End Sub

	Public Sub CalcolaStatoZeroAsync(ByVal dataProgramma As Object)
		Dim bl As New DBStatComp
		AddHandler bl.OnExecutionMessage, AddressOf WriteMessage
		bl.CalcolaStato0(CType(dataProgramma, DateTime).Date)
		bl.Dispose()
	End Sub

	Public Sub CalcolaStato0(ByVal DumpDate As Date)
		Dim exResult As ExecutionResult = New ExecutionResult
		Dim endBatchMessage As String
		Try
			exResult = ExecuteStato0Dump(DumpDate)
		Catch ex As Exception
			exResult.ErrorMessage = ex.Message
			smError(ex)
			Throw
		End Try

		If exResult.ExecutionStatus = True Then
			endBatchMessage = " Esecuzione OK: Nome DB = " + exResult.NewDBName + "  "
			endBatchMessage = endBatchMessage + " Datafile DB = " + exResult.NewDBDataFileName + "  "
			endBatchMessage = endBatchMessage + " LogFile DB = " + exResult.NewDBLogFileName + "  "
		Else
			endBatchMessage = "Esecuzione FALLITA: messaggio: " + exResult.ErrorMessage
		End If
		BatchSerializer.SetProgressBatch(endBatchMessage)
	End Sub

	'
	' Batch di Calcolo DB StatoUno
	'
	Public Sub CalcolaStatoUnoBatch(ByVal dataProgramma As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf CalcolaStatoUnoAsync, dataProgramma, "CALCSUNO", "Calcolo Stato Uno", dataProgramma, runningOperator)
	End Sub

	Public Sub CalcolaStatoUnoAsync(ByVal dataProgramma As Object)
		Dim bl As New DBStatComp
		AddHandler bl.OnExecutionMessage, AddressOf WriteMessage
		bl.CalcolaStato1(CType(dataProgramma, DateTime).Date)
		bl.Dispose()
	End Sub

	Public Sub CalcolaStato1(ByVal DumpDate As Date)
		Dim exResult As ExecutionResult = New ExecutionResult
		Dim endBatchMessage As String



		Try
			exResult = ExecuteStato1Dump(DumpDate)
		Catch ex As Exception
			exResult.ErrorMessage = ex.Message
			smError(ex)
			Throw
		End Try

		If exResult.ExecutionStatus = True Then
			endBatchMessage = " Esecuzione OK: Nome DB = " + exResult.NewDBName + "  "
			endBatchMessage = endBatchMessage + " Datafile DB = " + exResult.NewDBDataFileName + "  "
			endBatchMessage = endBatchMessage + " LogFile DB = " + exResult.NewDBLogFileName + "  "
		Else
			endBatchMessage = "Esecuzione FALLITA: messaggio: " + exResult.ErrorMessage
		End If
		BatchSerializer.SetProgressBatch(endBatchMessage)
	End Sub

	'
	' Funzione Batch di cancellazione dati da DB (< di una certa data)
	'
	Public Sub PurgeDataFromDBBatch(ByVal dataProgramma As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf PurgeDataFromDBAsync, dataProgramma, "PURGEDB", "Cancella dati da DB", dataProgramma, runningOperator)
	End Sub

	Public Sub PurgeDataFromDBAsync(ByVal dataProgramma As Object)
		Dim bl As New DBStatComp
		AddHandler bl.OnExecutionMessage, AddressOf WriteMessage
		bl.PurgeDataFromDB(CType(dataProgramma, DateTime).Date)
		bl.Dispose()
	End Sub

	Public Sub PurgeDataFromDB(ByVal DeleteFromDate As Date)
		Dim exResult As ExecutionResult = New ExecutionResult
		Dim endBatchMessage As String
		Try
			exResult = PurgeDataFromDBUntil(DeleteFromDate)
		Catch ex As Exception
			exResult.ErrorMessage = ex.Message
			smError(ex)
			Throw
		End Try

		If exResult.ExecutionStatus = False Then
			endBatchMessage = " Esecuzione FALLITA: messaggio: " + exResult.ErrorMessage
		Else
			endBatchMessage = " Esecuzione OK"
		End If
		BatchSerializer.SetProgressBatch(endBatchMessage)
	End Sub

End Class
