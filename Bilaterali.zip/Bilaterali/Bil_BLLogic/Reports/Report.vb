Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Type
Imports System.io
Imports System.Collections

Public Class Report
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents da As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents spGetListUnitaDellOperatore As System.Data.SqlClient.SqlCommand
    Friend WithEvents spReportCapacitaTrasporto As System.Data.SqlClient.SqlCommand
    Friend WithEvents spReportStoricoProgrammi As System.Data.SqlClient.SqlCommand
    Friend WithEvents spReportOperatorUnitsList As System.Data.SqlClient.SqlCommand
    Friend WithEvents spReportGetOperatorUnitsType As System.Data.SqlClient.SqlCommand
	Friend WithEvents spGetReportIndicatori As System.Data.SqlClient.SqlCommand
	Friend WithEvents spBilGetEnergiaGiornaliera As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.cmdSelect = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
		Me.da = New System.Data.SqlClient.SqlDataAdapter
		Me.spGetListUnitaDellOperatore = New System.Data.SqlClient.SqlCommand
		Me.spReportCapacitaTrasporto = New System.Data.SqlClient.SqlCommand
		Me.spReportStoricoProgrammi = New System.Data.SqlClient.SqlCommand
		Me.spReportOperatorUnitsList = New System.Data.SqlClient.SqlCommand
		Me.spReportGetOperatorUnitsType = New System.Data.SqlClient.SqlCommand
		Me.spGetReportIndicatori = New System.Data.SqlClient.SqlCommand
		Me.spBilGetEnergiaGiornaliera = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persis" & _
		"t security info=False;initial catalog=Bilaterali"
		'
		'da
		'
		Me.da.DeleteCommand = Me.SqlDeleteCommand1
		Me.da.InsertCommand = Me.SqlInsertCommand1
		Me.da.SelectCommand = Me.cmdSelect
		Me.da.UpdateCommand = Me.SqlUpdateCommand1
		'
		'spGetListUnitaDellOperatore
		'
		Me.spGetListUnitaDellOperatore.CommandText = "dbo.[spGetListUnitaDellOperatore]"
		Me.spGetListUnitaDellOperatore.CommandType = System.Data.CommandType.StoredProcedure
		Me.spGetListUnitaDellOperatore.Connection = Me.cn
		Me.spGetListUnitaDellOperatore.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spGetListUnitaDellOperatore.Parameters.Add(New System.Data.SqlClient.SqlParameter("@op", System.Data.SqlDbType.VarChar, 16))
		Me.spGetListUnitaDellOperatore.Parameters.Add(New System.Data.SqlClient.SqlParameter("@di", System.Data.SqlDbType.DateTime, 8))
		Me.spGetListUnitaDellOperatore.Parameters.Add(New System.Data.SqlClient.SqlParameter("@df", System.Data.SqlDbType.DateTime, 8))
		'
		'spReportCapacitaTrasporto
		'
		Me.spReportCapacitaTrasporto.CommandText = "dbo.[spReportCapacitaTrasporto]"
		Me.spReportCapacitaTrasporto.CommandType = System.Data.CommandType.StoredProcedure
		Me.spReportCapacitaTrasporto.Connection = Me.cn
		Me.spReportCapacitaTrasporto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spReportCapacitaTrasporto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgrammaMin", System.Data.SqlDbType.DateTime, 8))
		Me.spReportCapacitaTrasporto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgrammaMax", System.Data.SqlDbType.DateTime, 8))
		Me.spReportCapacitaTrasporto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Transitorio", System.Data.SqlDbType.Int, 4))
		Me.spReportCapacitaTrasporto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Operatore", System.Data.SqlDbType.VarChar, 16))
		'
		'spReportStoricoProgrammi
		'
		Me.spReportStoricoProgrammi.CommandText = "dbo.[spReportStoricoProgrammi]"
		Me.spReportStoricoProgrammi.CommandType = System.Data.CommandType.StoredProcedure
		Me.spReportStoricoProgrammi.Connection = Me.cn
		Me.spReportStoricoProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spReportStoricoProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.spReportStoricoProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Operatore", System.Data.SqlDbType.VarChar, 16))
		'
		'spReportOperatorUnitsList
		'
		Me.spReportOperatorUnitsList.CommandText = "dbo.[spGetOperatorListUnits]"
		Me.spReportOperatorUnitsList.CommandType = System.Data.CommandType.StoredProcedure
		Me.spReportOperatorUnitsList.Connection = Me.cn
		Me.spReportOperatorUnitsList.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spReportOperatorUnitsList.Parameters.Add(New System.Data.SqlClient.SqlParameter("@dt", System.Data.SqlDbType.DateTime, 8))
		'
		'spReportGetOperatorUnitsType
		'
		Me.spReportGetOperatorUnitsType.CommandText = "dbo.[spGetOperatorUnitsType]"
		Me.spReportGetOperatorUnitsType.CommandType = System.Data.CommandType.StoredProcedure
		Me.spReportGetOperatorUnitsType.Connection = Me.cn
		Me.spReportGetOperatorUnitsType.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spReportGetOperatorUnitsType.Parameters.Add(New System.Data.SqlClient.SqlParameter("@dt", System.Data.SqlDbType.DateTime, 8))
		'
		'spGetReportIndicatori
		'
		Me.spGetReportIndicatori.CommandText = "dbo.[spGetReportIndicatori]"
		Me.spGetReportIndicatori.CommandType = System.Data.CommandType.StoredProcedure
		Me.spGetReportIndicatori.Connection = Me.cn
		Me.spGetReportIndicatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spGetReportIndicatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@dtinizio", System.Data.SqlDbType.DateTime, 8))
		Me.spGetReportIndicatori.Parameters.Add(New System.Data.SqlClient.SqlParameter("@dtfine", System.Data.SqlDbType.DateTime, 8))
		'
		'spBilGetEnergiaGiornaliera
		'
		Me.spBilGetEnergiaGiornaliera.CommandText = "dbo.[spBilGetEnergiaGiornaliera]"
		Me.spBilGetEnergiaGiornaliera.CommandType = System.Data.CommandType.StoredProcedure
		Me.spBilGetEnergiaGiornaliera.Connection = Me.cn
		Me.spBilGetEnergiaGiornaliera.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spBilGetEnergiaGiornaliera.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))

	End Sub

#End Region
	' Report Unita` presenti in Contratti.
    Public Function GetDSReportUnita(ByVal operatore As String, ByVal zona As String, ByVal sottotipo As String, ByVal tipo As String, ByVal dal As DateTime, ByVal al As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction

        Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
			sSql = "SELECT SDC_U.CodiceUnitaSDC, "
			sSql = sSql + "SDC_U.TipoUnita, "
			sSql = sSql + "SDC_U.SottotipoUnita, "
			sSql = sSql + "PSR.CodiceZonaSDC, "
			sSql = sSql + "PSR.CodicePuntoDiScambioRilevanteSDC, "
			sSql = sSql + "SDC_U.CodiceOperatoreDiRiferimentoSDC, "
			sSql = sSql + "SDC_U.CoefficientePerdita, "
			sSql = sSql + "PSR.CoefficienteDiPerdita, "
			sSql = sSql + "U.StatoBilateraliUnita, "
			sSql = sSql + "SDC_U.Abilitata & case(ISNULL(MI.Eligibility, 'Able')) when 'Able' then 1 else 0 end Abilitata "
			sSql = sSql + "FROM   dbo.SDC_Unita AS SDC_U "
			sSql = sSql + "INNER JOIN dbo.SDC_PuntiDiScambioRilevanti AS PSR "
			sSql = sSql + "ON	SDC_U.CodicePuntoDiScambioRilevanteSDC = PSR.CodicePuntoDiScambioRilevanteSDC "
			sSql = sSql + "INNER JOIN dbo.Unita AS U "
			sSql = sSql + "ON	SDC_U.CodiceUnitaSDC = U.CodiceUnitaSDC AND SDC_U.CategoriaUnitaSDC = U.CategoriaUnitaSDC "
			sSql = sSql + "LEFT OUTER JOIN dbo.SDC_Unita_MarketInformation AS MI "
			sSql = sSql + "ON MI.CodiceUnitaSDC = U.CodiceUnitaSDC AND MI.CategoriaUnitaSDC = U.CategoriaUnitaSDC "
			sSql = sSql + " AND MI.MarketCode = 'MGP' "
			sSql = sSql + "WHERE "
			sSql = sSql + "EXISTS ("
			sSql = sSql + "SELECT CodiceUnitaSDC, CategoriaUnitaSDC "
			sSql = sSql + "FROM UnitRelate UR, Contratto C "
			sSql = sSql + "WHERE UR.DataInizioValidita <= @al "
			sSql = sSql + "AND UR.DataFineValidita >= @dal "
			sSql = sSql + "AND UR.CodiceUnitaSDC = U.CodiceUnitaSDC AND UR.CategoriaUnitaSDC = U.CategoriaUnitaSDC "
			sSql = sSql + "AND "
			sSql = sSql + " ( (UR.CodiceOperatoreSDC = C.CodiceOperatoreSDCCedente and UR.TipoUnita in ('P', 'M')) "
			sSql = sSql + "OR "
			sSql = sSql + "	(UR.CodiceOperatoreSDC = C.CodiceOperatoreSDCAcquirente and UR.TipoUnita in ('C', 'M')) ) "
			If operatore <> "" Then
				sSql = sSql + "AND UR.CodiceOperatoreSDC = @operatore"
			End If
			sSql = sSql + ") "
			If sottotipo <> "" Then
				sSql = sSql + "AND SDC_U.SottotipoUnita = @sottotipo "
			End If
			If tipo <> "" Then
				sSql = sSql + "AND UR.TipoUnita = @tipo "
			End If
			If zona <> "" Then
				sSql = sSql + "AND PSR.CodiceZonaSDC = @zona "
			End If
			sSql = sSql + " ORDER BY SDC_U.CodiceUnitaSDC, SDC_U.CategoriaUnitaSDC"
			'---------------------------------------------------------------------------------
			' Versione precedente alla UnitRelate (Fase 2)
			'---------------------------------------------------------------------------------
			'        sSql = "SELECT SDC_U.CodiceUnitaSDC, "
			'        sSql = sSql + "SDC_U.TipoUnita, "
			'        sSql = sSql + "SDC_U.SottotipoUnita, "
			'        sSql = sSql + "PSR.CodiceZonaSDC, "
			'        sSql = sSql + "PSR.CodicePuntoDiScambioRilevanteSDC, "
			'        sSql = sSql + "SDC_U.CodiceOperatoreDiRiferimentoSDC, "
			'        sSql = sSql + "SDC_U.CoefficientePerdita, "
			'        sSql = sSql + "PSR.CoefficienteDiPerdita "
			'        sSql = sSql + "FROM   dbo.SDC_Unita AS SDC_U, "
			'        sSql = sSql + "dbo.SDC_PuntiDiScambioRilevanti AS PSR, "
			'        sSql = sSql + "dbo.Unita AS U "
			'        sSql = sSql + "WHERE SDC_U.CodicePuntoDiScambioRilevanteSDC = PSR.CodicePuntoDiScambioRilevanteSDC "
			'        sSql = sSql + "AND SDC_U.CodiceUnitaSDC = U.CodiceUnitaSDC AND SDC_U.CategoriaUnitaSDC = U.CategoriaUnitaSDC "
			'' @SANDRO : modifica della query come conseguenza della modifica del database
			'' sSql = sSql + "AND SDC_U.Abilitata = 1 AND U.StatoBilateraliUnita = 1 "
			'        If sottotipo <> "" Then
			'            sSql = sSql + "AND SDC_U.SottotipoUnita = @sottotipo "
			'End If
			'        If tipo <> "" Then
			'            sSql = sSql + "AND SDC_U.TipoUnita = @tipo "
			'End If
			'        If zona <> "" Then
			'            sSql = sSql + "AND PSR.CodiceZonaSDC = @zona "
			'End If
			'        If operatore <> "" Then
			'            sSql = sSql + "AND EXISTS ( "
			'            sSql = sSql + "SELECT * "
			'sSql = sSql + "FROM dbo.UnitaContratto AS UC, dbo.Contratto AS C "
			'            sSql = sSql + "WHERE C.IdContratto = UC.IdContratto "
			'            sSql = sSql + "AND UC.CodiceUnitaSDC = SDC_U.CodiceUnitaSDC AND UC.CategoriaUnitaSDC = SDC_U.CategoriaUnitaSDC "
			'            sSql = sSql + "AND C.StatoContratto = 'Abilitato' "
			'            sSql = sSql + "AND UC.DataInizioValidita <= @al "
			'            sSql = sSql + "AND UC.DataFineValidita >= @dal "
			'            sSql = sSql + "AND UC.UnitaDelContrattoValidata = 1 "
			'            sSql = sSql + "AND UC.TrCC = 1 "
			'            sSql = sSql + "AND UC.TrUC = 1 "
			'            sSql = sSql + "AND ( "
			'            sSql = sSql + "(C.CodiceOperatoreSDCCedente = @operatore AND UC.UnitaAssegnataOpCedente = 1) "
			'            sSql = sSql + "OR "
			'            sSql = sSql + "(C.CodiceOperatoreSDCAcquirente = @operatore AND UC.UnitaAssegnataOpAcquirente = 1) "
			'            sSql = sSql + ")"
			'            sSql = sSql + ")"
			'        Else
			'            sSql = sSql + "AND EXISTS ( "
			'            sSql = sSql + "SELECT * "
			'            sSql = sSql + "FROM dbo.UnitaContratto AS UC, dbo.Contratto AS C "
			'            sSql = sSql + "WHERE C.IdContratto = UC.IdContratto "
			'            sSql = sSql + "AND UC.CodiceUnitaSDC = SDC_U.CodiceUnitaSDC AND UC.CategoriaUnitaSDC = SDC_U.CategoriaUnitaSDC "
			'            sSql = sSql + "AND C.StatoContratto = 'Abilitato' "
			'            sSql = sSql + "AND UC.DataInizioValidita <= @al "
			'            sSql = sSql + "AND UC.DataFineValidita >= @dal "
			'            sSql = sSql + "AND UC.UnitaDelContrattoValidata = 1 "
			'            sSql = sSql + "AND UC.TrCC = 1 "
			'            sSql = sSql + "AND UC.TrUC = 1 "
			'            sSql = sSql + ")"
			'End If
			'        sSql = sSql + " ORDER BY SDC_U.CodiceUnitaSDC "
			'---------------------------------------------------------------------------------
			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn

			cmdSelect.Parameters.Clear()
			If sottotipo <> "" Then
				cmdSelect.Parameters.Add("@sottotipo", sottotipo)
			End If
			If tipo <> "" Then
				cmdSelect.Parameters.Add("@tipo", tipo)
			End If
			If zona <> "" Then
				cmdSelect.Parameters.Add("@zona", zona)
			End If
			If operatore <> "" Then
				cmdSelect.Parameters.Add("@operatore", operatore)
			End If
			cmdSelect.Parameters.Add("@dal", dal)
			cmdSelect.Parameters.Add("@al", al)
			cmdSelect.Transaction = tr
			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportUnita_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
    End Function

	Public Function GetDSReportUnitaOperatori(ByVal operatore As String, ByVal unita As String, ByVal d As DateTime) As DataSet
		Dim tr As SqlTransaction

		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
            If unita <> "" Then

                sSql = "SELECT UR.CodiceUnitaSDC AS CodiceUnitaSDC, "
                sSql = sSql + " UR.CodiceOperatoreSDC AS CodiceOperatoreSDC, "
                sSql = sSql + " SDC_U.CodiceOperatoreDiRiferimentoSDC AS CodiceOperatoreDiRiferimentoSDC, "
                sSql = sSql + " Case SDC_U.TipoUnita"
                sSql = sSql + " when 'M' then 'Acq./Ced.' "
                sSql = sSql + " when 'P' then 'Cedente' "
                sSql = sSql + " Else 'Acquirente' end RuoloOp "
                sSql = sSql + " FROM UnitRelate UR "
                sSql = sSql + " INNER JOIN dbo.SDC_Unita SDC_U "
                sSql = sSql + " 	ON UR.CodiceUnitaSDC = SDC_U.CodiceUnitaSDC "
                sSql = sSql + " 	AND UR.CategoriaUnitaSDC = SDC_U.CategoriaUnitaSDC "
                sSql = sSql + " WHERE (UR.CodiceUnitaSDC = @unita) AND "
                sSql = sSql + "       (UR.DataFineValidita >= @d) AND "
                sSql = sSql + "       (@d >= UR.DataInizioValidita) AND "
				sSql = sSql + "       (UR.Abilitata = 1) AND (UR.TrUC = 1) "
				sSql = sSql + " ORDER BY UR.CodiceOperatoreSDC"

                'sSql = "SELECT UC.CodiceUnitaSDC AS CodiceUnitaSDC, "
                'sSql = sSql + "C.CodiceOperatoreSDCAcquirente AS CodiceOperatoreSDC, "
                'sSql = sSql + "SDC_U.CodiceOperatoreDiRiferimentoSDC AS CodiceOperatoreDiRiferimentoSDC, "
                'sSql = sSql + "case UC.UnitaAssegnataOpCedente when 1 then 'Acq./Ced.' else 'Acquirente' end RuoloOp "
                'sSql = sSql + "FROM dbo.tab_UnitaContratto4(@d, @unita, 'F') UC INNER JOIN "
                'sSql = sSql + "dbo.Contratto C ON UC.IdContratto = C.IdContratto INNER JOIN "
                'sSql = sSql + "dbo.SDC_Unita SDC_U ON UC.CodiceUnitaSDC = SDC_U.CodiceUnitaSDC AND UC.CategoriaUnitaSDC = SDC_U.CategoriaUnitaSDC "
                'sSql = sSql + "WHERE (UC.CodiceUnitaSDC = @unita) AND (UC.DataFineValidita >= @d) AND (@d >= UC.DataInizioValidita) AND "
                'sSql = sSql + "(UC.UnitaAssegnataOpAcquirente = 1) "
                'sSql = sSql + "AND C.StatoContratto = 'Abilitato' "
                'sSql = sSql + "AND UC.UnitaDelContrattoValidata = 1 "
                'sSql = sSql + "AND UC.TrCC = 1 "
                'sSql = sSql + "AND UC.TrUC = 1 "
                'sSql = sSql + "UNION "
                'sSql = sSql + "SELECT UC.CodiceUnitaSDC AS CodiceUnitaSDC, "
                'sSql = sSql + "C.CodiceOperatoreSDCCedente AS CodiceOperatoreSDC, "
                'sSql = sSql + "SDC_U.CodiceOperatoreDiRiferimentoSDC AS CodiceOperatoreDiRiferimentoSDC, "
                'sSql = sSql + "case UC.UnitaAssegnataOpAcquirente when 1 then 'Acq./Ced.' else 'Cedente' end RuoloOp "
                'sSql = sSql + "FROM dbo.tab_UnitaContratto4(@d, @unita, 'F') UC INNER JOIN "
                'sSql = sSql + "dbo.Contratto C ON UC.IdContratto = C.IdContratto INNER JOIN "
                'sSql = sSql + "dbo.SDC_Unita SDC_U ON UC.CodiceUnitaSDC = SDC_U.CodiceUnitaSDC AND UC.CategoriaUnitaSDC = SDC_U.CategoriaUnitaSDC "
                'sSql = sSql + "WHERE (UC.CodiceUnitaSDC = @unita) AND (UC.DataFineValidita >= @d) AND (@d >= UC.DataInizioValidita) AND "
                'sSql = sSql + "(UC.UnitaAssegnataOpCedente = 1) "
                'sSql = sSql + "AND C.StatoContratto = 'Abilitato' "
                'sSql = sSql + "AND UC.UnitaDelContrattoValidata = 1 "
                'sSql = sSql + "AND UC.TrCC = 1 "
                'sSql = sSql + "AND UC.TrUC = 1 "
                'sSql = "SELECT DISTINCT UC.CodiceUnitaSDC AS CodiceUnitaSDC, "
                'sSql = sSql + "C.CodiceOperatoreSDCAcquirente AS CodiceOperatoreSDC, "
                'sSql = sSql + "SDC_U.CodiceOperatoreDiRiferimentoSDC AS CodiceOperatoreDiRiferimentoSDC, "
                'sSql = sSql + "case UC.UnitaAssegnataOpCedente when 1 then 'Acq./Ced.' else 'Acquirente' end RuoloOp "
                'sSql = sSql + "FROM dbo.tab_UnitaContratto(@d) UC INNER JOIN "
                'sSql = sSql + "dbo.Contratto C ON UC.IdContratto = C.IdContratto INNER JOIN "
                'sSql = sSql + "dbo.SDC_Unita SDC_U ON UC.CodiceUnitaSDC = SDC_U.CodiceUnitaSDC AND UC.CategoriaUnitaSDC = SDC_U.CategoriaUnitaSDC "
                'sSql = sSql + "WHERE (UC.CodiceUnitaSDC = @unita) AND (UC.DataFineValidita >= @d) AND (@d >= UC.DataInizioValidita) AND "
                'sSql = sSql + "(UC.UnitaAssegnataOpAcquirente = 1) "
                'sSql = sSql + "AND C.StatoContratto = 'Abilitato' "
                'sSql = sSql + "AND UC.UnitaDelContrattoValidata = 1 "
                'sSql = sSql + "AND UC.TrCC = 1 "
                'sSql = sSql + "AND UC.TrUC = 1 "
                'sSql = sSql + "UNION "
                'sSql = sSql + "SELECT DISTINCT UC.CodiceUnitaSDC AS CodiceUnitaSDC, "
                'sSql = sSql + "C.CodiceOperatoreSDCCedente AS CodiceOperatoreSDC, "
                'sSql = sSql + "SDC_U.CodiceOperatoreDiRiferimentoSDC AS CodiceOperatoreDiRiferimentoSDC, "
                'sSql = sSql + "case UC.UnitaAssegnataOpAcquirente when 1 then 'Acq./Ced.' else 'Cedente' end RuoloOp "
                'sSql = sSql + "FROM dbo.tab_UnitaContratto(@d) UC INNER JOIN "
                'sSql = sSql + "dbo.Contratto C ON UC.IdContratto = C.IdContratto INNER JOIN "
                'sSql = sSql + "dbo.SDC_Unita SDC_U ON UC.CodiceUnitaSDC = SDC_U.CodiceUnitaSDC AND UC.CategoriaUnitaSDC = SDC_U.CategoriaUnitaSDC "
                'sSql = sSql + "WHERE (UC.CodiceUnitaSDC = @unita) AND (UC.DataFineValidita >= @d) AND (@d >= UC.DataInizioValidita) AND "
                'sSql = sSql + "(UC.UnitaAssegnataOpCedente = 1) "
                'sSql = sSql + "AND C.StatoContratto = 'Abilitato' "
                'sSql = sSql + "AND UC.UnitaDelContrattoValidata = 1 "
                'sSql = sSql + "AND UC.TrCC = 1 "
                'sSql = sSql + "AND UC.TrUC = 1 "
            Else
                sSql = "SELECT DISTINCT SDC_U.CodiceUnitaSDC AS CodiceUnitaSDC, "
                sSql = sSql + "@operatore AS CodiceOperatoreSDC, "
                sSql = sSql + "SDC_U.CodiceOperatoreDiRiferimentoSDC AS CodiceOperatoreDiRiferimentoSDC, "
                sSql = sSql + "convert(datetime,convert(varchar, UR.DataInizioValidita, 112)) DataInizioValidita, "
                sSql = sSql + "convert(datetime,convert(varchar, UR.DataFineValidita, 112)) DataFineValidita,"
                sSql = sSql + "case UR.Abilitata when 1 then 'Abilitata' else 'Non Abilitata' end Abilitata,"
                sSql = sSql + "case SDC_U.Abilitata when 1 then 'Abilitata' else 'Non Abilitata' end AbilitazioneRUP, "
                sSql = sSql + "ISNULL(MI.Eligibility, 'Able') AS 'AbilitazioneMGP', "
                sSql = sSql + "case U.StatoBilateraliUnita when 1 then 'Abilitata' else 'Non Abilitata' end AbilitazioneBILATERALI "
                sSql = sSql + "FROM UnitRelate UR "
                sSql = sSql + "INNER JOIN dbo.SDC_Unita SDC_U ON UR.CodiceUnitaSDC = SDC_U.CodiceUnitaSDC "
                sSql = sSql + "AND UR.CategoriaUnitaSDC = SDC_U.CategoriaUnitaSDC "
                sSql = sSql + "INNER JOIN dbo.Unita U ON UR.CodiceUnitaSDC = U.CodiceUnitaSDC "
                sSql = sSql + "AND UR.CategoriaUnitaSDC = U.CategoriaUnitaSDC "
                sSql = sSql + "LEFT OUTER JOIN dbo.SDC_Unita_MarketInformation MI "
                sSql = sSql + "ON UR.CodiceUnitaSDC = MI.CodiceUnitaSDC "
                sSql = sSql + "AND UR.CategoriaUnitaSDC = MI.CategoriaUnitaSDC "
                sSql = sSql + "AND MI.MarketCode = 'MGP' "
                sSql = sSql + "WHERE UR.CodiceOperatoreSDC = @operatore "
                sSql = sSql + "AND (convert(datetime,convert(varchar, UR.DataFineValidita, 112)) >= @d) "
                sSql = sSql + "AND (@d >= convert(datetime,convert(varchar, UR.DataInizioValidita,112)))"
                sSql = sSql + "ORDER BY SDC_U.CodiceUnitaSDC"
            End If

			cmdSelect.CommandText = sSql			 ' + " OPTION (FORCE ORDER)"

#If DEBUG Then
            Try
                Dim fs As StreamWriter = File.CreateText("c:\qq.sql")
                fs.WriteLine(sSql)
                fs.Close()
            Catch
            End Try

#End If


            cmdSelect.Connection = cn

            cmdSelect.Parameters.Clear()
            If operatore <> "" Then
                cmdSelect.Parameters.Add("@operatore", operatore)
                cmdSelect.Parameters.Add("@d", d)
            End If
            If unita <> "" Then
                cmdSelect.Parameters.Add("@unita", unita)
                cmdSelect.Parameters.Add("@d", d)
            End If
			cmdSelect.Transaction = tr
			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportUnitaOperatori_QueryTmo", 45)

            Dim ds As New DataSet
            ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReportListaOperatori() As DataSet
		cn.ConnectionString = GetConnectionString()

		Dim tr As SqlTransaction
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
			sSql = "SELECT replace(replace(SDC_O.RagioneSociale, char(10), ''), char(13), '') AS RagioneSociale, "
			sSql = sSql + "replace(replace(SDC_O.Indirizzo1, char(10), ''), char(13), '') AS Indirizzo, "
			sSql = sSql + "case O.StatoBilateraliOperatore when 1 then 'Attivo' else 'Non Attivo' end Stato "
			sSql = sSql + "FROM dbo.SDC_Operatori AS SDC_O, "
			sSql = sSql + "dbo.Operatori AS O "
			sSql = sSql + "WHERE SDC_O.CodiceOperatoreSDC = O.CodiceOperatoreSDC AND "
			sSql = sSql + "SDC_O.Abilitato = 1 "
			'sSql = sSql + "AND O.StatoBilateraliOperatore = 1 "
			sSql += "  order by ragionesociale "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr
			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportListaOperatori_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function


	Private Function CreateReportQuantitaProgrammiQuery( _
	 ByVal codiceUnitaSDC As String, _
	 ByVal codiceZonaSDC As String, _
	 ByVal stato As String, _
	 ByVal ora As String, _
	 ByVal operatore As String, _
	 ByVal idContratto As String, _
	 ByVal dataInizio As DateTime, _
	 ByVal dataFine As DateTime, _
	 ByVal bSelectCount As Boolean _
	 ) As SqlCommand

		Dim s As String
		s = "select "

		If bSelectCount Then
			s += " count(*) "
		Else
			s += "QMGP.CodiceUnitaSDC, "
			s += "QMGP.CodiceZonaSDC, "
			s += "QMGP.DataProgramma, "
			s += "QMGP.Stato, "
			s += "QMGP.DO, "
			s += "QMGP.Ora, "
			s += "QMGP.QuO, "
			s += "QMGP.QuTaglio, "
			s += "QMGP.QuA, "
			s += "QMGP.PrA, "
			s += "QMGP.GMEId, "
			s += "QMGP.Operatore, "
			s += "QMGP.OperatoreTitolare, "
			s += "QMGP.IdContratto, "
			s += "QMGP.ReasonText "
		End If

		s += "from "
		s += "( "
		s += "select "
		s += "ProgrammaOrarioPerUnita.CodiceUnitaSDC, "
		s += "SDC_PuntiDiScambioRilevanti.CodiceZonaSDC, "
		s += "ProgrammaOrarioPerUnita.DataProgramma, "
		s += "case when ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP Is Null Then"
		s += "     case when abs(ProgrammaOrarioPerUnita.QtyMWhBilanciamento) < 1e-4 then 'Tagliata' else"
		s += "         case when ProgrammaOrarioPerUnita.GMEReferenceNumber is  Null then 'NonInviata' else"
		s += "             case ProgrammaOrarioPerUnitaErrori.Origin when 'FA' then 'RifiutataFA' "
		s += "                     when 'BN' then 'RifiutataBN' "
		s += "                     else 'NonElabMGP' "
		s += "             end "
		s += "         end "
		s += "     end "
		s += "     else "
		s += "         case when ProgrammaOrarioPerUnita.QtyMWhBilanciamento Is Null then	"
		s += "             case  when round(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,3)=round(ProgrammaOrarioPerUnita.QtyMWh,3) then 'Accettata' "
		s += "                   when abs(round(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,3))<abs(round(ProgrammaOrarioPerUnita.QtyMWh,3)) then 'Acc. Parz.' "
		s += "             end "
		s += "             else "
		s += "             case    when round(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,3)=round(ProgrammaOrarioPerUnita.QtyMWhBilanciamento,3) then 'Accettata' "
		s += "                     when abs(round(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,3))<abs(round(ProgrammaOrarioPerUnita.QtyMWhBilanciamento,3)) then 'Acc. Parz.' "
		s += "             end "
		s += "     end "
		s += "end Stato, "

		s += "case sign(ProgrammaOrarioPerUnita.QtyMWh) when 1 then 'OFF' when -1 then 'DOM' else '' end DO, "
		s += "ProgrammaOrarioPerUnita.PeriodoRilevante Ora, "
		s += "abs(ProgrammaOrarioPerUnita.QtyMWh) QuO, "
		s += "abs(ProgrammaOrarioPerUnita.QtyMWhBilanciamento) QuTaglio, "
		s += "abs(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP) QuA, "

		's+= "case SDC_Unita.TipoUnita when 'P' then PrezzoZonale.Prezzo when 'M' then PrezzoZonale.Prezzo else PrezzoUnitario.Prezzo end PrA, "
		s += "case when SDC_Unita.TipoUnita = 'C' and SDC_Unita.TipoZona <> 'VIRT' then PrezzoUnitario.Prezzo "
		s += "else PrezzoZonale.Prezzo "
		s += "end PrA,  "

		s += "ProgrammaOrarioPerUnita.GMEReferenceNumber GMEId, "
		s += "case ProgrammaOrarioPerUnita.ProgrammatoDalCedente when 1 then Contratto.CodiceOperatoreSDCCedente else Contratto.CodiceOperatoreSDCAcquirente end Operatore, "
		s += "Contratto.CodiceOperatoreSDC OperatoreTitolare, "
		s += "ProgrammaOrarioPerUnita.IdContratto IdContratto, "

		s += "case when ProgrammaOrarioPerUnitaErrori.Origin is NULL then '' else ProgrammaOrarioPerUnitaErrori.Origin end Origin, "
		s += "case when ProgrammaOrarioPerUnitaErrori.ReasonCode is NULL then '' else ProgrammaOrarioPerUnitaErrori.ReasonCode end ReasonCode, "
		s += "case when ProgrammaOrarioPerUnitaErrori.ReasonText is NULL then '' else ProgrammaOrarioPerUnitaErrori.ReasonText end ReasonText "

		s += "from ProgrammaOrarioPerUnita "

		s += "left outer join ProgrammaOrarioPerUnitaErrori "
		s += "on ProgrammaOrarioPerUnita.IdContratto = ProgrammaOrarioPerUnitaErrori.IdContratto "
		s += "and ProgrammaOrarioPerUnita.DataProgramma = ProgrammaOrarioPerUnitaErrori.DataProgramma "
		s += "and ProgrammaOrarioPerUnita.PeriodoRilevante = ProgrammaOrarioPerUnitaErrori.PeriodoRilevante "
		s += "and ProgrammaOrarioPerUnita.CategoriaUnitaSDC = ProgrammaOrarioPerUnitaErrori.CategoriaUnitaSDC "
		s += "and ProgrammaOrarioPerUnita.CodiceUnitaSDC = ProgrammaOrarioPerUnitaErrori.CodiceUnitaSDC "

		'		s += "inner join SDC_Unita "
		s += "inner join SDC_Unita_TipoZona SDC_Unita "
		s += "on ProgrammaOrarioPerUnita.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC "
		s += "and ProgrammaOrarioPerUnita.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC "

		s += "inner join SDC_PuntiDiScambioRilevanti "
		s += "on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC "
		s += "inner join Contratto "
		s += "on ProgrammaOrarioPerUnita.IdContratto = Contratto.IdContratto "

		s += "left outer join PrezzoUnitario "
		s += "on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma "
		s += "and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "

		s += "left outer join PrezzoZonale "
		s += "on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma "
		s += "and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
		s += "and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC "

		s += "inner join ProgrammaOrario "
		s += "on ProgrammaOrario.IdContratto = ProgrammaOrarioPerUnita.IdContratto "
		s += "And ProgrammaOrario.DataProgramma = ProgrammaOrarioPerUnita.DataProgramma "
		s += "And ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
		s += "where "

		s += "ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 "
		s += "and ProgrammaOrario.ProgrammaOrarioValidato = 1 "
		s += ") "
		s += "QMGP "
		s += "where @DataInizio <= QMGP.DataProgramma and QMGP.DataProgramma <= @DataFine "

		Dim cmd As New SqlClient.SqlCommand
		cmd.Parameters.Clear()
		cmd.Parameters.Add("@DataInizio", dataInizio)
		cmd.Parameters.Add("@DataFine", dataFine)


		If Not stato Is Nothing AndAlso stato <> "" Then
			s += "and QMGP.Stato = @Stato "
			cmd.Parameters.Add("@Stato", stato)
		End If

		If Not codiceZonaSDC Is Nothing AndAlso codiceZonaSDC <> "" Then
			s += "and QMGP.CodiceZonaSDC = @CodiceZonaSDC "
			cmd.Parameters.Add("@CodiceZonaSDC", codiceZonaSDC)
		End If

		If Not codiceUnitaSDC Is Nothing AndAlso codiceUnitaSDC <> "" Then
			s += "and QMGP.CodiceUnitaSDC = @CodiceUnitaSDC "
			cmd.Parameters.Add("@CodiceUnitaSDC", codiceUnitaSDC)
		End If

		If Not ora Is Nothing AndAlso ora <> "" AndAlso CType(ora, Integer) >= 1 AndAlso CType(ora, Integer) <= 25 Then
			s += "and QMGP.Ora = @Ora "
			cmd.Parameters.Add("@Ora", CType(ora, Integer))
		End If

		If Not operatore Is Nothing AndAlso operatore <> "" Then
			s += "and QMGP.Operatore = @Operatore "
			cmd.Parameters.Add("@Operatore", operatore)
		End If

		If Not idContratto Is Nothing AndAlso idContratto <> "" AndAlso CType(idContratto, Integer) >= 0 Then
			s += "and QMGP.IdContratto = @IdContratto "
			cmd.Parameters.Add("@IdContratto", CType(idContratto, Integer))
		End If

		If bSelectCount = False Then
			s += " order by "
			s += " QMGP.CodiceUnitaSDC, "
			s += " QMGP.CodiceZonaSDC, "
			s += " QMGP.DataProgramma, "
			s += " QMGP.Ora "
		End If

		cmd.CommandText = s

		Return cmd

	End Function

	Public Function GetDSReportQuantitaProgrammiCount( _
	 ByVal codiceUnitaSDC As String, _
	 ByVal codiceZonaSDC As String, _
	 ByVal stato As String, _
	 ByVal ora As String, _
	 ByVal operatore As String, _
	 ByVal idContratto As String, _
	 ByVal dataInizio As DateTime, _
	 ByVal dataFine As DateTime, _
	 ByRef bExecuteReport As Boolean, _
	 ByRef nMaxRecord As Integer _
	 ) As Integer

		' devo contare i record, non devo fare la query
		Dim bSelectCount As Boolean = True

		bExecuteReport = False

		cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction
		Try
			nMaxRecord = AppSettingToInt32("ReportQuantitaProgrammi_MaxRecords", 10000)

			Dim cmd As SqlCommand
			cmd = CreateReportQuantitaProgrammiQuery(codiceUnitaSDC, codiceZonaSDC, stato, ora, operatore, idContratto, dataInizio, dataFine, bSelectCount)

			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)
			cmd.Connection = cn
			cmd.Transaction = tr
			cmd.CommandTimeout = AppSettingToInt32("GetDSReportQuantitaProgrammiCount_QueryTmo", 15)

			Dim obj As Object = cmd.ExecuteScalar()

			If obj Is Nothing Then Return 0

			Dim nr As Integer = CType(obj, Integer)

			If nr < nMaxRecord Then
				bExecuteReport = True
			End If

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return nr

		Catch ex As Exception
			smTrace(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function


	Public Function GetDSReportQuantitaProgrammi( _
	 ByVal codiceUnitaSDC As String, _
	 ByVal codiceZonaSDC As String, _
	 ByVal stato As String, _
	 ByVal ora As String, _
	 ByVal operatore As String, _
	 ByVal idContratto As String, _
	 ByVal dataInizio As DateTime, _
	 ByVal dataFine As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction
		Try
			' devo fare la query, non devo contare i record!
			Dim bSelectCount As Boolean = False

			Dim cmd As SqlCommand
			cmd = CreateReportQuantitaProgrammiQuery(codiceUnitaSDC, codiceZonaSDC, stato, ora, operatore, idContratto, dataInizio, dataFine, bSelectCount)

			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			cmd.Connection = cn
			cmd.Transaction = tr
			cmd.CommandTimeout = AppSettingToInt32("GetDSReportQuantitaProgrammi_QueryTmo", 60)

			da.SelectCommand = cmd

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function




	Public Function GetDSReportSituazioneProgrammi(ByVal codGRTN As String, ByVal codMnemonico As String, ByVal operatore As String, ByVal dataInizio As DateTime, ByVal dataFine As DateTime, ByVal inizioProg As DateTime, ByVal fineProg As DateTime) As DataSet
		Dim tr As SqlTransaction
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)


			cmdSelect.CommandType = CommandType.StoredProcedure
			cmdSelect.CommandText = "spReportSituazioneProgrammi"
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr

			cmdSelect.Parameters.Clear()
			cmdSelect.Parameters.Add("@DataInizio", dataInizio)
			cmdSelect.Parameters.Add("@DataFine", dataFine)
			cmdSelect.Parameters.Add("@DataInizioProgramma", inizioProg)
			cmdSelect.Parameters.Add("@DataFineProgramma", fineProg)
			If operatore <> "" Then
				cmdSelect.Parameters.Add("@Operatore", operatore)
			Else
				cmdSelect.Parameters.Add("@Operatore", DBNull.Value)
			End If
			If codGRTN <> "" Then
				cmdSelect.Parameters.Add("@CodGRTN", codGRTN)
			Else
				cmdSelect.Parameters.Add("@CodGRTN", DBNull.Value)
			End If
			If codMnemonico <> "" Then
				cmdSelect.Parameters.Add("@CodiceContratto", codMnemonico)
			Else
				cmdSelect.Parameters.Add("@CodiceContratto", DBNull.Value)
			End If

			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportSituazioneProgrammi_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDS_ReportSinteticoProgrammi(ByVal dataProgramma As DateTime) As DataSet
		Dim bl As New Bil.Programmi
		Try

			Dim ds As DataSet = bl.GetProgrammazioneAdmin(dataProgramma.Date, False)
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		End Try
	End Function

	Public Function GetDSReportOperatori() As DataSet
		Dim tr As SqlTransaction
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String

			sSql = "select "
			sSql = sSql + "SO.*, "
			sSql = sSql + "Case O.StatoBilateraliOperatore "
			sSql = sSql + "when 0 then 'Non abilitato' "
			sSql = sSql + "when 1 then 'Abilitato' "
			sSql = sSql + "else 'Non operativo' "
			sSql = sSql + "end StatoBilaterali, "
			sSql = sSql + "Case O.Amministratore "
			sSql = sSql + "when 1 then 'Amministratore' "
			sSql = sSql + "else '' "
			sSql = sSql + "end Amministratore "
			sSql = sSql + "from SDC_Operatori SO "
			sSql = sSql + "left outer join Operatori O "
			sSql = sSql + "on SO.CodiceOperatoreSDC = O.CodiceOperatoreSDC "
			'sSql = sSql + "WHERE (NOT (O.StatoBilateraliOperatore IS NULL)) "
			sSql = sSql + "order by SO.CodiceOperatoreSDC "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr

			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportOperatori_QueryTmo", 45)


			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))


			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReportUtenti() As DataSet
		Dim tr As SqlTransaction
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
			sSql = "select "
			'sSql = sSql + "SU.*, "
			sSql = sSql + "SU.CodiceUtenteSDC, "
			sSql = sSql + "SU.Nome, "
			sSql = sSql + "SU.Cognome, "
			sSql = sSql + "replace(replace(SU.Telefono, char(10), ''), char(13), '') as Telefono, "
			sSql = sSql + "SU.Fax, "
			sSql = sSql + "SU.Email, "
			sSql = sSql + "SU.DN, "
			sSql = sSql + "SU.Abilitato, "
			sSql = sSql + "SU.Login, "
			sSql = sSql + "SU.Pwd, "
			sSql = sSql + "SU.Lingua, "
			sSql = sSql + "SU.CodiceFiscale, "
			sSql = sSql + "SU.TSModifica, "
			sSql = sSql + "SU.ResponsabileAggiornamento, "
			sSql = sSql + "SU.Certificato, "
			sSql = sSql + "SU.CertificatoFirma, "
			sSql = sSql + "Case U.StatoBilateraliUtente "
			sSql = sSql + "when 0 then 'Non abilitato' "
			sSql = sSql + "when 1 then 'Abilitato' "
			sSql = sSql + "else 'Non operativo' "
			sSql = sSql + "end StatoBilaterali "
			sSql = sSql + "from SDC_Utenti SU "
			sSql = sSql + "left outer join Utenti U "
			sSql = sSql + "on SU.CodiceUtenteSDC = U.CodiceUtenteSDC "
			sSql = sSql + "order by SU.CodiceUtenteSDC "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr
			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportUtenti_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReportUnita2(ByVal codiceOperatoreSDC As String, ByVal dt As DateTime) As DataSet
		Dim tr As SqlTransaction
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
			sSql = "select "
			sSql += "SU.*, "
			sSql += "Case U.StatoBilateraliUnita "
			sSql += "    when 0 then 'Non abilitata' "
			sSql += "    when 1 then 'Abilitata' "
			sSql += "    else 'Non operativa' "
			sSql += "    end StatoBilaterali, "
			sSql += "AU.Eligibility AS Eligibility "
			sSql += "from SDC_Unita SU "
			sSql += "left outer join Unita U "
			sSql += "on SU.CodiceUnitaSDC = U.CodiceUnitaSDC "
			sSql += "And SU.CategoriaUnitaSDC = U.CategoriaUnitaSDC "
			sSql += "left outer join dbo.SDC_Unita_MarketInformation AU "
			sSql += "on AU.CodiceUnitaSDC = U.CodiceUnitaSDC "
			sSql += "And AU.CategoriaUnitaSDC = U.CategoriaUnitaSDC "
			sSql += "WHERE "
			sSql += " (AU.MarketCode = 'MGP' Or AU.MarketCode Is Null) "
			If Not codiceOperatoreSDC Is Nothing And dt > System.DateTime.MinValue Then
				sSql += "and exists "
				sSql += "("
				sSql += "select UR.CodiceUnitaSDC, UR.CategoriaUnitaSDC	"
				sSql += "from UnitRelate UR	"
				sSql += "where UR.CodiceUnitaSDC    = SU.CodiceUnitaSDC and UR.CategoriaUnitaSDC = SU.CategoriaUnitaSDC	"
				sSql += "and (UR.DataInizioValidita <= @df and UR.DataFineValidita >= @di)	"
				sSql += "and UR.CodiceOperatoreSDC = @op"
				sSql += ") "
				'sSql += "	select UnitaContratto.CodiceUnitaSDC, UnitaContratto.CategoriaUnitaSDC"
				'sSql += "	from UnitaContratto"
				'sSql += "	inner join Contratto"
				'sSql += "	on Contratto.IdContratto = UnitaContratto.IdContratto"
				'sSql += "	where"
				'sSql += "	Contratto.StatoContratto = 'Abilitato'"
				'sSql += "	and Contratto.TrCN = 1"
				'sSql += "	and (Contratto.DataInizioValidita <= @df and Contratto.DataFineValidita >= @di)"
				'sSql += "	and UnitaContratto.CodiceUnitaSDC    = SU.CodiceUnitaSDC"
				'sSql += "	and UnitaContratto.CategoriaUnitaSDC = SU.CategoriaUnitaSDC"
				'sSql += "	and (UnitaContratto.DataInizioValidita <= @df and UnitaContratto.DataFineValidita >= @di)"
				'sSql += "	and UnitaContratto.UnitaDelContrattoValidata = 1"
				'sSql += "	and "
				'sSql += "	("
				'sSql += "		(UnitaAssegnataOpCedente = 1 and Contratto.CodiceOperatoreSDCCedente = @op)"
				'sSql += "		or"
				'sSql += "		(UnitaAssegnataOpAcquirente = 1 and Contratto.CodiceOperatoreSDCAcquirente = @op)"
				'sSql += "	)"
				'sSql += ") "
			End If
			sSql += "ORDER BY SU.CodiceUnitaSDC "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Parameters.Clear()
			cmdSelect.Transaction = tr

			If Not codiceOperatoreSDC Is Nothing Then
				cmdSelect.Parameters.Add("@op", codiceOperatoreSDC)
				'cmdSelect.Parameters.Add("@di", DateTime.Now.Date)
				'cmdSelect.Parameters.Add("@df", DateTime.Now.Date)
				cmdSelect.Parameters.Add("@di", dt)
				cmdSelect.Parameters.Add("@df", dt)
			End If

			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportUnita2_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReportUtentiOperatoriAmm() As DataSet
		cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
			sSql = "select "
			sSql = sSql + "O.CodiceOperatoreSDC AS CodiceOperatoreSDC, "
			sSql = sSql + "U.CodiceUtenteSDC AS CodiceUtenteSDC "
			sSql = sSql + "from dbo.Utenti U, dbo.Operatori O, dbo.RelOperatoriUtenti R "
			sSql = sSql + "where R.CodiceOperatoreSDC = O.CodiceOperatoreSDC "
			sSql = sSql + "And R.CodiceUtenteSDC = U.CodiceUtenteSDC "
			sSql = sSql + "And O.Amministratore = 1 And R.Amministratore = 1 "
			sSql = sSql + "order by CodiceOperatoreSDC, CodiceUtenteSDC "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr
			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportUtentiOperatoriAmm_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReportUnita3(ByVal data As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			cmdSelect.CommandType = CommandType.StoredProcedure
			cmdSelect.CommandText = "spReportDettagliUnita"
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr
			cmdSelect.Parameters.Clear()
			cmdSelect.Parameters.Add("@d", data)

			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportUnita3_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReporProgrammi(ByVal data As DateTime, ByVal idcntr As String, ByVal programmatoDalCedente As String) As DataSet
		cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			cmdSelect.CommandType = CommandType.StoredProcedure
			cmdSelect.CommandText = "spReportOffertePerContratto"
			cmdSelect.Connection = cn

			cmdSelect.Parameters.Clear()
			cmdSelect.Parameters.Add("@IdContratto", idcntr)
			cmdSelect.Parameters.Add("@DataProgramma", data)
			If programmatoDalCedente = "0" Then
				cmdSelect.Parameters.Add("@ProgrammatoDalCedente", False)
			ElseIf programmatoDalCedente = "1" Then
				cmdSelect.Parameters.Add("@ProgrammatoDalCedente", True)
			Else
				cmdSelect.Parameters.Add("@ProgrammatoDalCedente", DBNull.Value)
			End If

			cmdSelect.Transaction = tr
			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReporProgrammi_QueryTmo", 45)


			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))


			Dim dsReport As DataSet
			dsReport = DataSetReport()

			'Dim nOre As Integer = Me.GetNumberOfHourOfDay(data)
			Dim r, rNew As DataRow
			Dim i, ora As Integer
			Dim codUnita As String = ""
			For i = 0 To ds.Tables("Report").Rows.Count - 1
				r = ds.Tables("Report").Rows(i)
				If codUnita <> CType(r("CodiceUnitaSDC"), String) Then
					rNew = dsReport.Tables("Report").NewRow()
					codUnita = CType(r("CodiceUnitaSDC"), String)
					rNew("CodiceUnitaSDC") = CType(r("CodiceUnitaSDC"), String)
					rNew("CategoriaUnitaSDC") = CType(r("CategoriaUnitaSDC"), String)
					ora = CType(r("PeriodoRilevante"), Integer)
					Select Case ora
						Case 1
							'If r("QtyMWhAssegnataMGP") Is DBNull.Value Then
							'    rNew("QtyMWhAssegnata01") = 0
							'Else
							'    rNew("QtyMWhAssegnata01") = CType(r("QtyMWhAssegnataMGP"), Double)
							'End If
							rNew("QtyMWhAssegnata01") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh01") = r("QtyMWh")
							rNew("QtyMWhBilanciamento01") = r("QtyMWhBilanciamento")

						Case 2
							rNew("QtyMWhAssegnata02") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh02") = r("QtyMWh")
							rNew("QtyMWhBilanciamento02") = r("QtyMWhBilanciamento")

						Case 3
							rNew("QtyMWhAssegnata03") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh03") = r("QtyMWh")
							rNew("QtyMWhBilanciamento03") = r("QtyMWhBilanciamento")

						Case 4
							rNew("QtyMWhAssegnata04") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh04") = r("QtyMWh")
							rNew("QtyMWhBilanciamento04") = r("QtyMWhBilanciamento")

						Case 5
							rNew("QtyMWhAssegnata05") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh05") = r("QtyMWh")
							rNew("QtyMWhBilanciamento05") = r("QtyMWhBilanciamento")

						Case 6
							rNew("QtyMWhAssegnata06") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh06") = r("QtyMWh")
							rNew("QtyMWhBilanciamento06") = r("QtyMWhBilanciamento")

						Case 7
							rNew("QtyMWhAssegnata07") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh07") = r("QtyMWh")
							rNew("QtyMWhBilanciamento07") = r("QtyMWhBilanciamento")

						Case 8
							rNew("QtyMWhAssegnata08") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh08") = r("QtyMWh")
							rNew("QtyMWhBilanciamento08") = r("QtyMWhBilanciamento")

						Case 9
							rNew("QtyMWhAssegnata09") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh09") = r("QtyMWh")
							rNew("QtyMWhBilanciamento09") = r("QtyMWhBilanciamento")

						Case 10
							rNew("QtyMWhAssegnata10") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh10") = r("QtyMWh")
							rNew("QtyMWhBilanciamento10") = r("QtyMWhBilanciamento")

						Case 11
							rNew("QtyMWhAssegnata11") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh11") = r("QtyMWh")
							rNew("QtyMWhBilanciamento11") = r("QtyMWhBilanciamento")

						Case 12
							rNew("QtyMWhAssegnata12") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh12") = r("QtyMWh")
							rNew("QtyMWhBilanciamento12") = r("QtyMWhBilanciamento")

						Case 13
							rNew("QtyMWhAssegnata13") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh13") = r("QtyMWh")
							rNew("QtyMWhBilanciamento13") = r("QtyMWhBilanciamento")

						Case 14
							rNew("QtyMWhAssegnata14") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh14") = r("QtyMWh")
							rNew("QtyMWhBilanciamento14") = r("QtyMWhBilanciamento")

						Case 15
							rNew("QtyMWhAssegnata15") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh15") = r("QtyMWh")
							rNew("QtyMWhBilanciamento15") = r("QtyMWhBilanciamento")

						Case 16
							rNew("QtyMWhAssegnata16") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh16") = r("QtyMWh")
							rNew("QtyMWhBilanciamento16") = r("QtyMWhBilanciamento")

						Case 17
							rNew("QtyMWhAssegnata17") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh17") = r("QtyMWh")
							rNew("QtyMWhBilanciamento17") = r("QtyMWhBilanciamento")

						Case 18
							rNew("QtyMWhAssegnata18") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh18") = r("QtyMWh")
							rNew("QtyMWhBilanciamento18") = r("QtyMWhBilanciamento")

						Case 19
							rNew("QtyMWhAssegnata19") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh19") = r("QtyMWh")
							rNew("QtyMWhBilanciamento19") = r("QtyMWhBilanciamento")

						Case 20
							rNew("QtyMWhAssegnata20") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh20") = r("QtyMWh")
							rNew("QtyMWhBilanciamento20") = r("QtyMWhBilanciamento")

						Case 21
							rNew("QtyMWhAssegnata21") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh21") = r("QtyMWh")
							rNew("QtyMWhBilanciamento21") = r("QtyMWhBilanciamento")

						Case 22
							rNew("QtyMWhAssegnata22") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh22") = r("QtyMWh")
							rNew("QtyMWhBilanciamento22") = r("QtyMWhBilanciamento")

						Case 23
							rNew("QtyMWhAssegnata23") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh23") = r("QtyMWh")
							rNew("QtyMWhBilanciamento23") = r("QtyMWhBilanciamento")

						Case 24
							rNew("QtyMWhAssegnata24") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh24") = r("QtyMWh")
							rNew("QtyMWhBilanciamento24") = r("QtyMWhBilanciamento")

						Case 25
							rNew("QtyMWhAssegnata25") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh25") = r("QtyMWh")
							rNew("QtyMWhBilanciamento25") = r("QtyMWhBilanciamento")


					End Select

					dsReport.Tables("Report").Rows.Add(rNew)

				Else

					ora = CType(r("PeriodoRilevante"), Integer)
					Select Case ora
						Case 1
							'If r("QtyMWhAssegnataMGP") Is DBNull.Value Then
							'    rNew("QtyMWhAssegnata01") = 0
							'Else
							'    rNew("QtyMWhAssegnata01") = CType(r("QtyMWhAssegnataMGP"), Double)
							'End If
							rNew("QtyMWhAssegnata01") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh01") = r("QtyMWh")
							rNew("QtyMWhBilanciamento01") = r("QtyMWhBilanciamento")

						Case 2
							rNew("QtyMWhAssegnata02") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh02") = r("QtyMWh")
							rNew("QtyMWhBilanciamento02") = r("QtyMWhBilanciamento")

						Case 3
							rNew("QtyMWhAssegnata03") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh03") = r("QtyMWh")
							rNew("QtyMWhBilanciamento03") = r("QtyMWhBilanciamento")

						Case 4
							rNew("QtyMWhAssegnata04") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh04") = r("QtyMWh")
							rNew("QtyMWhBilanciamento04") = r("QtyMWhBilanciamento")

						Case 5
							rNew("QtyMWhAssegnata05") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh05") = r("QtyMWh")
							rNew("QtyMWhBilanciamento05") = r("QtyMWhBilanciamento")

						Case 6
							rNew("QtyMWhAssegnata06") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh06") = r("QtyMWh")
							rNew("QtyMWhBilanciamento06") = r("QtyMWhBilanciamento")

						Case 7
							rNew("QtyMWhAssegnata07") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh07") = r("QtyMWh")
							rNew("QtyMWhBilanciamento07") = r("QtyMWhBilanciamento")

						Case 8
							rNew("QtyMWhAssegnata08") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh08") = r("QtyMWh")
							rNew("QtyMWhBilanciamento08") = r("QtyMWhBilanciamento")

						Case 9
							rNew("QtyMWhAssegnata09") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh09") = r("QtyMWh")
							rNew("QtyMWhBilanciamento09") = r("QtyMWhBilanciamento")

						Case 10
							rNew("QtyMWhAssegnata10") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh10") = r("QtyMWh")
							rNew("QtyMWhBilanciamento10") = r("QtyMWhBilanciamento")

						Case 11
							rNew("QtyMWhAssegnata11") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh11") = r("QtyMWh")
							rNew("QtyMWhBilanciamento11") = r("QtyMWhBilanciamento")

						Case 12
							rNew("QtyMWhAssegnata12") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh12") = r("QtyMWh")
							rNew("QtyMWhBilanciamento12") = r("QtyMWhBilanciamento")

						Case 13
							rNew("QtyMWhAssegnata13") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh13") = r("QtyMWh")
							rNew("QtyMWhBilanciamento13") = r("QtyMWhBilanciamento")

						Case 14
							rNew("QtyMWhAssegnata14") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh14") = r("QtyMWh")
							rNew("QtyMWhBilanciamento14") = r("QtyMWhBilanciamento")

						Case 15
							rNew("QtyMWhAssegnata15") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh15") = r("QtyMWh")
							rNew("QtyMWhBilanciamento15") = r("QtyMWhBilanciamento")

						Case 16
							rNew("QtyMWhAssegnata16") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh16") = r("QtyMWh")
							rNew("QtyMWhBilanciamento16") = r("QtyMWhBilanciamento")

						Case 17
							rNew("QtyMWhAssegnata17") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh17") = r("QtyMWh")
							rNew("QtyMWhBilanciamento17") = r("QtyMWhBilanciamento")

						Case 18
							rNew("QtyMWhAssegnata18") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh18") = r("QtyMWh")
							rNew("QtyMWhBilanciamento18") = r("QtyMWhBilanciamento")

						Case 19
							rNew("QtyMWhAssegnata19") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh19") = r("QtyMWh")
							rNew("QtyMWhBilanciamento19") = r("QtyMWhBilanciamento")

						Case 20
							rNew("QtyMWhAssegnata20") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh20") = r("QtyMWh")
							rNew("QtyMWhBilanciamento20") = r("QtyMWhBilanciamento")

						Case 21
							rNew("QtyMWhAssegnata21") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh21") = r("QtyMWh")
							rNew("QtyMWhBilanciamento21") = r("QtyMWhBilanciamento")

						Case 22
							rNew("QtyMWhAssegnata22") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh22") = r("QtyMWh")
							rNew("QtyMWhBilanciamento22") = r("QtyMWhBilanciamento")

						Case 23
							rNew("QtyMWhAssegnata23") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh23") = r("QtyMWh")
							rNew("QtyMWhBilanciamento23") = r("QtyMWhBilanciamento")

						Case 24
							rNew("QtyMWhAssegnata24") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh24") = r("QtyMWh")
							rNew("QtyMWhBilanciamento24") = r("QtyMWhBilanciamento")

						Case 25
							rNew("QtyMWhAssegnata25") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh25") = r("QtyMWh")
							rNew("QtyMWhBilanciamento25") = r("QtyMWhBilanciamento")


					End Select

				End If
			Next

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing


			Return dsReport

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Private Function DataSetReport() As DataSet
		Dim ds As New DataSet
		Dim dt As DataTable

		dt = ds.Tables.Add("Report")

		Dim c As DataColumn
		c = dt.Columns.Add("CodiceUnitaSDC")
		c.AllowDBNull = False
		'c.MaxLength = 32
		'c.Unique = False

		c = dt.Columns.Add("CategoriaUnitaSDC")
		c.AllowDBNull = False

		c = dt.Columns.Add("QtyMWhAssegnata01")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata02")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata03")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata04")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata05")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata06")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata07")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata08")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata09")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata10")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata11")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata12")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata13")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata14")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata15")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata16")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata17")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata18")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata19")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata20")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata21")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata22")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata23")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata24")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata25")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh01")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh02")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh03")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh04")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh05")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh06")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh07")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh08")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh09")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh10")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh11")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh12")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh13")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh14")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh15")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh16")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh17")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh18")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh19")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh20")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh21")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh22")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh23")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh24")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh25")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento01")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento02")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento03")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento04")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento05")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento06")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento07")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento08")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento09")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento10")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento11")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento12")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento13")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento14")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento15")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento16")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento17")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento18")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento19")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento20")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento21")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento22")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento23")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento24")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento25")
		c.AllowDBNull = True

		dt.PrimaryKey = New DataColumn() {dt.Columns("CodiceUnitaSDC"), dt.Columns("CategoriaUnitaSDC")}
		Return ds

	End Function


	' funzione chiamata da Bil_UserWA per ottenere la lista delle unita` di compentenza
	' all'operatore spcificato in codiceOperatoreSDC
	' Per ora si ritornano tutte le unita`.
	Public Function GetListUnitaDellOperatore(ByVal codiceOperatoreSDC As String, ByVal dtInizio As DateTime, ByVal dtFine As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()

			spGetListUnitaDellOperatore.Parameters("@op").Value = codiceOperatoreSDC
			spGetListUnitaDellOperatore.Parameters("@di").Value = dtInizio
			spGetListUnitaDellOperatore.Parameters("@df").Value = dtFine

			da.SelectCommand = spGetListUnitaDellOperatore

			da.SelectCommand.CommandTimeout = AppSettingToInt32("GetListUnitaDellOperatore_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Unita")
			da.Fill(ds.Tables("Unita"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	Public Function GetDSReportQtyTot(ByVal operatore As String, ByVal data As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			'Dim sSql As String

			'sSql = "select 0 Ord,"
			'sSql = sSql + "Operatore, "
			'sSql = sSql + "round( sum(MWhProd), 3) as MWhProd, "
			'sSql = sSql + "round( sum(MWhCons), 3) as MWhCons, "
			'sSql = sSql + "round( sum(MWhBilProd), 3) as MWhBilProd, "
			'sSql = sSql + "round( sum(MWhOffProd), 3) as MWhOffProd, "
			'sSql = sSql + "round( sum(MWhBilCons), 3) as MWhBilCons, "
			'sSql = sSql + "round( sum(MWhOffCons), 3) as MWhOffCons "
			'sSql = sSql + "from "
			'sSql = sSql + "( "
			'sSql = sSql + "select "
			'sSql = sSql + "Contratto.CodiceOperatoreSDCCedente as Operatore, "
			'sSql = sSql + "sum(ProgrammaOrarioPerUnita.QtyMWh) as MWhProd, "
			'sSql = sSql + "0 as MWhCons, "
			'sSql = sSql + "sum(isnull(ProgrammaOrarioPerUnita.QtyMWhBilanciamento,0)) as MWhBilProd, "
			'sSql = sSql + "Case ProgrammaOrarioPerUnita.QtyMWhBilanciamento "
			'sSql = sSql + "when null then sum(ProgrammaOrarioPerUnita.QtyMWh) "
			'sSql = sSql + "else sum(ProgrammaOrarioPerUnita.QtyMWhBilanciamento) "
			'sSql = sSql + "end MWhOffProd, "
			'sSql = sSql + "0 as MWhBilCons, "
			'sSql = sSql + "0 as MWhOffCons "
			'sSql = sSql + "from "
			'sSql = sSql + " ProgrammaOrarioPerUnita "
			'sSql = sSql + " inner join ProgrammaOrario "
			'sSql = sSql + "on  ProgrammaOrario.IdContratto = ProgrammaOrarioPerUnita.IdContratto "
			'sSql = sSql + "and ProgrammaOrario.DataProgramma = ProgrammaOrarioPerUnita.DataProgramma "
			'sSql = sSql + "and ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
			'sSql = sSql + "inner join Contratto "
			'sSql = sSql + "on  Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto "
			'sSql = sSql + " where "
			'sSql = sSql + "ProgrammaOrarioPerUnita.DataProgramma = @d "

			'sSql = sSql + "and Contratto.StatoContratto = 'Abilitato' "
			'sSql = sSql + "and Contratto.TrCN = 1 "
			'sSql = sSql + "and Contratto.DataInizioValidita <= @d "
			'sSql = sSql + "and Contratto.DataFineValidita >= @d "
			'sSql = sSql + "and ProgrammaOrario.ProgrammaOrarioValidato = 1 "
			'sSql = sSql + "and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 "
			'sSql = sSql + "and ProgrammaOrarioPerUnita.ProgrammatoDalCedente = 1 "
			'sSql = sSql + "group by "
			'sSql = sSql + " Contratto.CodiceOperatoreSDCCedente, ProgrammaOrarioPerUnita.QtyMWhBilanciamento "

			'sSql = sSql + " union "

			'sSql = sSql + "select "
			'sSql = sSql + "Contratto.CodiceOperatoreSDCAcquirente as Operatore, "
			'sSql = sSql + "0 as MWhProd, "
			'sSql = sSql + "sum(ProgrammaOrarioPerUnita.QtyMWh) as MWhCons, "
			'sSql = sSql + "0 as MWhBilProd, "
			'sSql = sSql + "0 as MWhOffProd, "
			'sSql = sSql + "sum(isnull(ProgrammaOrarioPerUnita.QtyMWhBilanciamento,0)) as MWhBilCons, "
			'sSql = sSql + "Case ProgrammaOrarioPerUnita.QtyMWhBilanciamento "
			'sSql = sSql + "when null then sum(isnull(ProgrammaOrarioPerUnita.QtyMWh,0)) "
			'sSql = sSql + "else sum(ProgrammaOrarioPerUnita.QtyMWhBilanciamento) "
			'sSql = sSql + "end MWhOffCons "
			'sSql = sSql + "from "
			'sSql = sSql + "ProgrammaOrarioPerUnita "
			'sSql = sSql + " inner join ProgrammaOrario "
			'sSql = sSql + "on  ProgrammaOrario.IdContratto = ProgrammaOrarioPerUnita.IdContratto "
			'sSql = sSql + "and ProgrammaOrario.DataProgramma = ProgrammaOrarioPerUnita.DataProgramma "
			'sSql = sSql + "and ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
			'sSql = sSql + "inner join Contratto "
			'sSql = sSql + "on  Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto "

			'sSql = sSql + "where "
			'sSql = sSql + "ProgrammaOrarioPerUnita.DataProgramma = @d "

			'sSql = sSql + "and Contratto.StatoContratto = 'Abilitato' "
			'sSql = sSql + "and Contratto.TrCN = 1 "
			'sSql = sSql + "and Contratto.DataInizioValidita <= @d "
			'sSql = sSql + "and Contratto.DataFineValidita >= @d "
			'sSql = sSql + "and ProgrammaOrario.ProgrammaOrarioValidato = 1 "
			'sSql = sSql + "and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 "
			'sSql = sSql + "and ProgrammaOrarioPerUnita.ProgrammatoDalCedente = 0 "
			'sSql = sSql + "group by "
			'sSql = sSql + " Contratto.CodiceOperatoreSDCAcquirente, ProgrammaOrarioPerUnita.QtyMWhBilanciamento "
			'sSql = sSql + ") OpQty "
			'If operatore <> "" Then
			'	sSql = sSql + " 	WHERE Operatore = @Operatore "
			'End If
			'sSql = sSql + "GROUP BY Operatore "
			'sSql = sSql + "union "

			'sSql = sSql + "select 1 Ord, "
			'sSql = sSql + "'Totale: ' as Operatore, "
			'sSql = sSql + "sum(MWhProd) MWhProd,"
			'sSql = sSql + "sum(MWhCons) MWhCons,"
			'sSql = sSql + "sum(MWhBilProd) MWhBilProd, "
			'sSql = sSql + "sum(MWhOffProd) MWhOffProd, "
			'sSql = sSql + "sum(MWhBilCons) MWhBilCons, "
			'sSql = sSql + "sum(MWhOffCons) MWhOffCons "
			'sSql = sSql + "			from "
			'sSql = sSql + "( "
			'sSql = sSql + "select "
			'sSql = sSql + "Operatore, "
			'sSql = sSql + "round( sum(MWhProd), 3) as MWhProd, "
			'sSql = sSql + "round( sum(MWhCons), 3) as MWhCons, "
			'sSql = sSql + "round( sum(MWhBilProd), 3) as MWhBilProd, "
			'sSql = sSql + "round( sum(MWhOffProd), 3) as MWhOffProd, "
			'sSql = sSql + "round( sum(MWhBilCons), 3) as MWhBilCons, "
			'sSql = sSql + "round( sum(MWhOffCons), 3) as MWhOffCons "
			'sSql = sSql + "from "
			'sSql = sSql + "( "
			'sSql = sSql + "select "
			'sSql = sSql + "Contratto.CodiceOperatoreSDCCedente as Operatore, "
			'sSql = sSql + "sum(ProgrammaOrarioPerUnita.QtyMWh) as MWhProd, "
			'sSql = sSql + "0 as MWhCons, "
			'sSql = sSql + "sum(isnull(ProgrammaOrarioPerUnita.QtyMWhBilanciamento,0)) as MWhBilProd, "
			'sSql = sSql + "Case ProgrammaOrarioPerUnita.QtyMWhBilanciamento "
			'sSql = sSql + "when null then sum(ProgrammaOrarioPerUnita.QtyMWh) "
			'sSql = sSql + "else sum(ProgrammaOrarioPerUnita.QtyMWhBilanciamento) "
			'sSql = sSql + "end MWhOffProd, "
			'sSql = sSql + "0 as MWhBilCons, "
			'sSql = sSql + "0 as MWhOffCons "
			'sSql = sSql + "from "
			'sSql = sSql + " ProgrammaOrarioPerUnita "
			'sSql = sSql + " inner join ProgrammaOrario "
			'sSql = sSql + "on  ProgrammaOrario.IdContratto = ProgrammaOrarioPerUnita.IdContratto "
			'sSql = sSql + "and ProgrammaOrario.DataProgramma = ProgrammaOrarioPerUnita.DataProgramma "
			'sSql = sSql + "and ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
			'sSql = sSql + "inner join Contratto "
			'sSql = sSql + "on  Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto "

			'sSql = sSql + "			where "
			'sSql = sSql + "ProgrammaOrarioPerUnita.DataProgramma = @d "

			'sSql = sSql + "and Contratto.StatoContratto = 'Abilitato' "
			'sSql = sSql + "and Contratto.TrCN = 1 "
			'sSql = sSql + "and Contratto.DataInizioValidita <= @d "
			'sSql = sSql + "and Contratto.DataFineValidita >= @d "
			'sSql = sSql + "and ProgrammaOrario.ProgrammaOrarioValidato = 1 "
			'sSql = sSql + "and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 "
			'sSql = sSql + "and ProgrammaOrarioPerUnita.ProgrammatoDalCedente = 1 "
			'sSql = sSql + " group by "
			'sSql = sSql + " Contratto.CodiceOperatoreSDCCedente, ProgrammaOrarioPerUnita.QtyMWhBilanciamento "

			'sSql = sSql + "			union "

			'sSql = sSql + "select "
			'sSql = sSql + "Contratto.CodiceOperatoreSDCAcquirente as Operatore, "
			'sSql = sSql + "0 as MWhProd, "
			'sSql = sSql + "sum(ProgrammaOrarioPerUnita.QtyMWh) as MWhCons, "
			'sSql = sSql + "0 as MWhBilProd, "
			'sSql = sSql + "0 as MWhOffProd, "
			'sSql = sSql + "sum(isnull(ProgrammaOrarioPerUnita.QtyMWhBilanciamento,0)) as MWhBilCons, "
			'sSql = sSql + "Case ProgrammaOrarioPerUnita.QtyMWhBilanciamento "
			'sSql = sSql + "when null then sum(isnull(ProgrammaOrarioPerUnita.QtyMWh,0)) "
			'sSql = sSql + "else sum(ProgrammaOrarioPerUnita.QtyMWhBilanciamento) "
			'sSql = sSql + "end MWhOffCons "
			'sSql = sSql + " from "
			'sSql = sSql + " ProgrammaOrarioPerUnita "
			'sSql = sSql + " inner join ProgrammaOrario "
			'sSql = sSql + "on  ProgrammaOrario.IdContratto = ProgrammaOrarioPerUnita.IdContratto "
			'sSql = sSql + "and ProgrammaOrario.DataProgramma = ProgrammaOrarioPerUnita.DataProgramma "
			'sSql = sSql + "and ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
			'sSql = sSql + "inner join Contratto "
			'sSql = sSql + "on  Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto "

			'sSql = sSql + "			where "
			'sSql = sSql + "ProgrammaOrarioPerUnita.DataProgramma = @d "

			'sSql = sSql + "and Contratto.StatoContratto = 'Abilitato' "
			'sSql = sSql + "and Contratto.TrCN = 1 "
			'sSql = sSql + "and Contratto.DataInizioValidita <= @d "
			'sSql = sSql + "and Contratto.DataFineValidita >= @d "
			'sSql = sSql + "and ProgrammaOrario.ProgrammaOrarioValidato = 1 "
			'sSql = sSql + "and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 "
			'sSql = sSql + "and ProgrammaOrarioPerUnita.ProgrammatoDalCedente = 0 "
			'sSql = sSql + "group by "
			'sSql = sSql + "Contratto.CodiceOperatoreSDCAcquirente, ProgrammaOrarioPerUnita.QtyMWhBilanciamento "
			'sSql = sSql + ") OpQty "
			'If operatore <> "" Then
			'	sSql = sSql + " 	WHERE Operatore = @Operatore "
			'End If
			'sSql = sSql + "GROUP BY Operatore "
			'sSql = sSql + ") t "
			'sSql = sSql + " order by ord asc"


			cmdSelect.CommandType = CommandType.StoredProcedure
			cmdSelect.CommandText = "spReportQtaPgmTotPerOperatore"
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr

			cmdSelect.Parameters.Clear()
			cmdSelect.Parameters.Add("@d", data)
			If operatore <> "" Then
				cmdSelect.Parameters.Add("@op", operatore)
			End If

			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportQtyTot_QueryTmo", 90)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing


			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	Public Function GetDSReportPDSR() As DataSet
		Dim tr As SqlTransaction
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
			sSql = "select * "
			sSql = sSql + "from SDC_PuntiDiScambioRilevanti "
			sSql = sSql + "order by CodicePuntoDiScambioRilevanteSDC "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr
			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportPDSR_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReportZone() As DataSet
		cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
			sSql = "select * "
			sSql = sSql + "from SDC_Zone "
			sSql = sSql + "order by CodiceZonaSDC "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr
			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportZone_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
			cn.Close()
		End Try
	End Function

	Public Function GetDSReportUtentiBilateralisti(ByVal operatore As String) As DataSet
		Dim tr As SqlTransaction
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim sSql As String
			sSql = "select "
			sSql = sSql + "O.CodiceOperatoreSDC AS CodiceOperatoreSDC, "
			sSql = sSql + "U.CodiceUtenteSDC AS CodiceUtenteSDC "
			sSql = sSql + "from dbo.Utenti U, dbo.Operatori O, dbo.RelOperatoriUtenti R "
			sSql = sSql + "where R.CodiceOperatoreSDC = O.CodiceOperatoreSDC "
			sSql = sSql + "And R.CodiceUtenteSDC = U.CodiceUtenteSDC "
			sSql = sSql + "And O.Amministratore = 0 And R.Amministratore = 0 "
			If operatore <> "" Then
				sSql = sSql + "And O.CodiceOperatoreSDC = @Operatore "
			End If
			sSql = sSql + "order by CodiceOperatoreSDC, CodiceUtenteSDC "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr
			cmdSelect.Parameters.Clear()
			If operatore <> "" Then
				cmdSelect.Parameters.Add("@Operatore", operatore)
			End If

			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportUtentiBilateralisti_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReportEnergiaGiornaliera(ByVal data As DateTime, ByVal tipounita As String, ByVal tipodato As String) As DataSet
		Dim tr As SqlTransaction
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()
			tr = cn.BeginTransaction(IsolationLevel.ReadUncommitted)

			Dim bilanciamentoForzatoEffettuato As Boolean = False

			If True Then
				Dim cmd As New SqlCommand("select taglio from sessionebilaterali where DataProgramma = @d")
				cmd.Connection = cn
				cmd.Transaction = tr
				cmd.Parameters.Add("@d", data)
				Dim o As Object = cmd.ExecuteScalar()
				If Not o Is Nothing Then bilanciamentoForzatoEffettuato = CType(o, Boolean)
			End If

			Dim sSql As String
			sSql = "SELECT "
			If tipounita = "P" Then
				sSql = sSql + "C.CodiceOperatoreSDCCedente AS CodiceOperatore, "
			Else
				sSql = sSql + "C.CodiceOperatoreSDCAcquirente AS CodiceOperatore, "
			End If
			sSql = sSql + "POU.PeriodoRilevante AS PeriodoRilevante, "
			sSql = sSql + "ABS(SUM(POU.QtyMWh)) AS QtyMWh, "
			sSql = sSql + "OP.RagioneSociale AS RagioneSociale, "
			If bilanciamentoForzatoEffettuato Then
				sSql = sSql + "ABS(SUM(ISNULL(POU.QtyMWhBilanciamento, POU.QtyMWh))) AS QtyMWhBilanciamento, "
			Else
				sSql = sSql + "NULL AS QtyMWhBilanciamento, "
			End If
			sSql = sSql + "ABS(SUM(POU.QtyMWhAssegnataMGP)) AS QtyMWhAssegnataMGP "
			sSql = sSql + "FROM dbo.ProgrammaOrarioPerUnita AS POU, dbo.Contratto AS C, "
			' 02.12.2004 - non serve la join con tab_UnitaContratto perche` le unita` inserite in  
			' programma orario per unita` sono quelle dei contratti dell'operatore e i loro flag 
			' di validita` sono stati testati al momento dell'accettazione del programma
			'sSql = sSql + " tab_UnitaContratto(@d) AS UC, "
			sSql = sSql + " SDC_Operatori AS OP "
			'sSql = sSql + "WHERE POU.IdContratto = UC.IdContratto AND "
			'sSql = sSql + "UC.IdContratto = C.IdContratto AND "
			'sSql = sSql + "POU.CodiceUnitaSDC = UC.CodiceUnitaSDC AND "
			'sSql = sSql + "POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC AND "
			sSql = sSql + "WHERE POU.IdContratto = C.IdContratto AND "
			If tipounita = "P" Then
				sSql = sSql + "POU.ProgrammatoDalCedente = 1 AND "
			Else
				sSql = sSql + "POU.ProgrammatoDalCedente = 0 AND "
			End If
			sSql = sSql + "POU.ProgOrarioDellUnitaValidato = 1 AND "
			sSql = sSql + "POU.DataProgramma = @d AND "
			'sSql = sSql + "UC.TrUC = 1 AND "
			'sSql = sSql + "UC.TrCC = 1 AND "
			'sSql = sSql + "UC.DataInizioValidita <= @d AND "
			'sSql = sSql + "UC.DataFineValidita >= @d AND "
			'sSql = sSql + "UC.UnitaDelContrattoValidata = 1 AND "
			sSql = sSql + "C.DataInizioValidita <= @d AND "
			sSql = sSql + "C.DataFineValidita >= @d AND "
			sSql = sSql + "C.StatoContratto = 'Abilitato' AND "
			If tipounita = "P" Then
				sSql = sSql + "C.CodiceOperatoreSDCCedente =  OP.CodiceOperatoreSDC "
			Else
				sSql = sSql + "C.CodiceOperatoreSDCAcquirente = OP.CodiceOperatoreSDC "
			End If
			If tipounita = "P" Then
				sSql = sSql + "GROUP BY C.CodiceOperatoreSDCCedente, POU.PeriodoRilevante, OP.RagioneSociale "
			Else
				sSql = sSql + "GROUP BY C.CodiceOperatoreSDCAcquirente, POU.PeriodoRilevante, OP.RagioneSociale "
			End If
			'sSql = sSql + "GROUP BY CodiceOperatore, PeriodoRilevante "
			sSql = sSql + "order by CodiceOperatore, PeriodoRilevante "

			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn
			cmdSelect.Transaction = tr

			cmdSelect.Parameters.Clear()
			cmdSelect.Parameters.Add("@d", data)

			cmdSelect.CommandTimeout = AppSettingToInt32("GetDSReportEnergiaGiornaliera_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))


			Dim dsReport As DataSet
			dsReport = DataSetReport2()

			'Dim nOre As Integer = Me.GetNumberOfHourOfDay(data)
			Dim r, rNew As DataRow
			Dim i, ora As Integer
			Dim codOperatore As String = ""
			Dim ragioneSociale As String = ""
			For i = 0 To ds.Tables("Report").Rows.Count - 1
				r = ds.Tables("Report").Rows(i)
				If codOperatore <> CType(r("CodiceOperatore"), String) Then
					rNew = dsReport.Tables("Report").NewRow()
					codOperatore = CType(r("CodiceOperatore"), String)
					rNew("CodiceOperatore") = CType(r("CodiceOperatore"), String)
					ora = CType(r("PeriodoRilevante"), Integer)

					If ragioneSociale <> CType(r("RagioneSociale"), String) Then
						ragioneSociale = CType(r("RagioneSociale"), String)
						rNew("RagioneSociale") = CType(r("RagioneSociale"), String)
					End If


					Select Case ora
						Case 1
							rNew("QtyMWhAssegnata01") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh01") = r("QtyMWh")
							rNew("QtyMWhBilanciamento01") = r("QtyMWhBilanciamento")

						Case 2
							rNew("QtyMWhAssegnata02") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh02") = r("QtyMWh")
							rNew("QtyMWhBilanciamento02") = r("QtyMWhBilanciamento")

						Case 3
							rNew("QtyMWhAssegnata03") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh03") = r("QtyMWh")
							rNew("QtyMWhBilanciamento03") = r("QtyMWhBilanciamento")

						Case 4
							rNew("QtyMWhAssegnata04") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh04") = r("QtyMWh")
							rNew("QtyMWhBilanciamento04") = r("QtyMWhBilanciamento")

						Case 5
							rNew("QtyMWhAssegnata05") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh05") = r("QtyMWh")
							rNew("QtyMWhBilanciamento05") = r("QtyMWhBilanciamento")

						Case 6
							rNew("QtyMWhAssegnata06") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh06") = r("QtyMWh")
							rNew("QtyMWhBilanciamento06") = r("QtyMWhBilanciamento")

						Case 7
							rNew("QtyMWhAssegnata07") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh07") = r("QtyMWh")
							rNew("QtyMWhBilanciamento07") = r("QtyMWhBilanciamento")

						Case 8
							rNew("QtyMWhAssegnata08") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh08") = r("QtyMWh")
							rNew("QtyMWhBilanciamento08") = r("QtyMWhBilanciamento")

						Case 9
							rNew("QtyMWhAssegnata09") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh09") = r("QtyMWh")
							rNew("QtyMWhBilanciamento09") = r("QtyMWhBilanciamento")

						Case 10
							rNew("QtyMWhAssegnata10") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh10") = r("QtyMWh")
							rNew("QtyMWhBilanciamento10") = r("QtyMWhBilanciamento")

						Case 11
							rNew("QtyMWhAssegnata11") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh11") = r("QtyMWh")
							rNew("QtyMWhBilanciamento11") = r("QtyMWhBilanciamento")

						Case 12
							rNew("QtyMWhAssegnata12") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh12") = r("QtyMWh")
							rNew("QtyMWhBilanciamento12") = r("QtyMWhBilanciamento")

						Case 13
							rNew("QtyMWhAssegnata13") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh13") = r("QtyMWh")
							rNew("QtyMWhBilanciamento13") = r("QtyMWhBilanciamento")

						Case 14
							rNew("QtyMWhAssegnata14") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh14") = r("QtyMWh")
							rNew("QtyMWhBilanciamento14") = r("QtyMWhBilanciamento")

						Case 15
							rNew("QtyMWhAssegnata15") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh15") = r("QtyMWh")
							rNew("QtyMWhBilanciamento15") = r("QtyMWhBilanciamento")

						Case 16
							rNew("QtyMWhAssegnata16") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh16") = r("QtyMWh")
							rNew("QtyMWhBilanciamento16") = r("QtyMWhBilanciamento")

						Case 17
							rNew("QtyMWhAssegnata17") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh17") = r("QtyMWh")
							rNew("QtyMWhBilanciamento17") = r("QtyMWhBilanciamento")

						Case 18
							rNew("QtyMWhAssegnata18") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh18") = r("QtyMWh")
							rNew("QtyMWhBilanciamento18") = r("QtyMWhBilanciamento")

						Case 19
							rNew("QtyMWhAssegnata19") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh19") = r("QtyMWh")
							rNew("QtyMWhBilanciamento19") = r("QtyMWhBilanciamento")

						Case 20
							rNew("QtyMWhAssegnata20") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh20") = r("QtyMWh")
							rNew("QtyMWhBilanciamento20") = r("QtyMWhBilanciamento")

						Case 21
							rNew("QtyMWhAssegnata21") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh21") = r("QtyMWh")
							rNew("QtyMWhBilanciamento21") = r("QtyMWhBilanciamento")

						Case 22
							rNew("QtyMWhAssegnata22") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh22") = r("QtyMWh")
							rNew("QtyMWhBilanciamento22") = r("QtyMWhBilanciamento")

						Case 23
							rNew("QtyMWhAssegnata23") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh23") = r("QtyMWh")
							rNew("QtyMWhBilanciamento23") = r("QtyMWhBilanciamento")

						Case 24
							rNew("QtyMWhAssegnata24") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh24") = r("QtyMWh")
							rNew("QtyMWhBilanciamento24") = r("QtyMWhBilanciamento")

						Case 25
							rNew("QtyMWhAssegnata25") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh25") = r("QtyMWh")
							rNew("QtyMWhBilanciamento25") = r("QtyMWhBilanciamento")


					End Select

					dsReport.Tables("Report").Rows.Add(rNew)

				Else

					ora = CType(r("PeriodoRilevante"), Integer)
					Select Case ora
						Case 1
							rNew("QtyMWhAssegnata01") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh01") = r("QtyMWh")
							rNew("QtyMWhBilanciamento01") = r("QtyMWhBilanciamento")

						Case 2
							rNew("QtyMWhAssegnata02") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh02") = r("QtyMWh")
							rNew("QtyMWhBilanciamento02") = r("QtyMWhBilanciamento")

						Case 3
							rNew("QtyMWhAssegnata03") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh03") = r("QtyMWh")
							rNew("QtyMWhBilanciamento03") = r("QtyMWhBilanciamento")

						Case 4
							rNew("QtyMWhAssegnata04") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh04") = r("QtyMWh")
							rNew("QtyMWhBilanciamento04") = r("QtyMWhBilanciamento")

						Case 5
							rNew("QtyMWhAssegnata05") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh05") = r("QtyMWh")
							rNew("QtyMWhBilanciamento05") = r("QtyMWhBilanciamento")

						Case 6
							rNew("QtyMWhAssegnata06") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh06") = r("QtyMWh")
							rNew("QtyMWhBilanciamento06") = r("QtyMWhBilanciamento")

						Case 7
							rNew("QtyMWhAssegnata07") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh07") = r("QtyMWh")
							rNew("QtyMWhBilanciamento07") = r("QtyMWhBilanciamento")

						Case 8
							rNew("QtyMWhAssegnata08") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh08") = r("QtyMWh")
							rNew("QtyMWhBilanciamento08") = r("QtyMWhBilanciamento")

						Case 9
							rNew("QtyMWhAssegnata09") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh09") = r("QtyMWh")
							rNew("QtyMWhBilanciamento09") = r("QtyMWhBilanciamento")

						Case 10
							rNew("QtyMWhAssegnata10") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh10") = r("QtyMWh")
							rNew("QtyMWhBilanciamento10") = r("QtyMWhBilanciamento")

						Case 11
							rNew("QtyMWhAssegnata11") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh11") = r("QtyMWh")
							rNew("QtyMWhBilanciamento11") = r("QtyMWhBilanciamento")

						Case 12
							rNew("QtyMWhAssegnata12") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh12") = r("QtyMWh")
							rNew("QtyMWhBilanciamento12") = r("QtyMWhBilanciamento")

						Case 13
							rNew("QtyMWhAssegnata13") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh13") = r("QtyMWh")
							rNew("QtyMWhBilanciamento13") = r("QtyMWhBilanciamento")

						Case 14
							rNew("QtyMWhAssegnata14") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh14") = r("QtyMWh")
							rNew("QtyMWhBilanciamento14") = r("QtyMWhBilanciamento")

						Case 15
							rNew("QtyMWhAssegnata15") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh15") = r("QtyMWh")
							rNew("QtyMWhBilanciamento15") = r("QtyMWhBilanciamento")

						Case 16
							rNew("QtyMWhAssegnata16") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh16") = r("QtyMWh")
							rNew("QtyMWhBilanciamento16") = r("QtyMWhBilanciamento")

						Case 17
							rNew("QtyMWhAssegnata17") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh17") = r("QtyMWh")
							rNew("QtyMWhBilanciamento17") = r("QtyMWhBilanciamento")

						Case 18
							rNew("QtyMWhAssegnata18") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh18") = r("QtyMWh")
							rNew("QtyMWhBilanciamento18") = r("QtyMWhBilanciamento")

						Case 19
							rNew("QtyMWhAssegnata19") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh19") = r("QtyMWh")
							rNew("QtyMWhBilanciamento19") = r("QtyMWhBilanciamento")

						Case 20
							rNew("QtyMWhAssegnata20") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh20") = r("QtyMWh")
							rNew("QtyMWhBilanciamento20") = r("QtyMWhBilanciamento")

						Case 21
							rNew("QtyMWhAssegnata21") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh21") = r("QtyMWh")
							rNew("QtyMWhBilanciamento21") = r("QtyMWhBilanciamento")

						Case 22
							rNew("QtyMWhAssegnata22") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh22") = r("QtyMWh")
							rNew("QtyMWhBilanciamento22") = r("QtyMWhBilanciamento")

						Case 23
							rNew("QtyMWhAssegnata23") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh23") = r("QtyMWh")
							rNew("QtyMWhBilanciamento23") = r("QtyMWhBilanciamento")

						Case 24
							rNew("QtyMWhAssegnata24") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh24") = r("QtyMWh")
							rNew("QtyMWhBilanciamento24") = r("QtyMWhBilanciamento")

						Case 25
							rNew("QtyMWhAssegnata25") = r("QtyMWhAssegnataMGP")
							rNew("QtyMWh25") = r("QtyMWh")
							rNew("QtyMWhBilanciamento25") = r("QtyMWhBilanciamento")


					End Select
				End If
			Next

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			Return dsReport

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Private Function DataSetReport2() As DataSet
		Dim ds As New DataSet
		Dim dt As DataTable

		dt = ds.Tables.Add("Report")

		Dim c As DataColumn
		c = dt.Columns.Add("CodiceOperatore")
		c.AllowDBNull = False
		'c.MaxLength = 32
		'c.Unique = False

		c = dt.Columns.Add("RagioneSociale")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata01")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata02")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata03")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata04")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata05")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata06")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata07")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata08")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata09")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata10")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata11")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata12")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata13")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata14")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata15")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata16")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata17")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata18")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata19")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata20")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata21")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata22")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata23")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata24")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhAssegnata25")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh01")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh02")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh03")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh04")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh05")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh06")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh07")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh08")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh09")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh10")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh11")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh12")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh13")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh14")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh15")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh16")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh17")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh18")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh19")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh20")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh21")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh22")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh23")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh24")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWh25")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento01")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento02")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento03")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento04")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento05")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento06")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento07")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento08")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento09")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento10")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento11")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento12")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento13")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento14")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento15")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento16")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento17")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento18")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento19")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento20")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento21")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento22")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento23")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento24")
		c.AllowDBNull = True

		c = dt.Columns.Add("QtyMWhBilanciamento25")
		c.AllowDBNull = True

		Return ds

	End Function

	Public Function GetDSReportCapacitaTrasporto(ByVal operatore As String, ByVal di As DateTime, ByVal df As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()

			spReportCapacitaTrasporto.Parameters("@DataProgrammaMin").Value = di
			spReportCapacitaTrasporto.Parameters("@DataProgrammaMax").Value = df
			spReportCapacitaTrasporto.Parameters("@Transitorio").Value = 0
			spReportCapacitaTrasporto.Parameters("@Operatore").Value = operatore

			da.SelectCommand = spReportCapacitaTrasporto
			da.SelectCommand.CommandTimeout = AppSettingToInt32("GetDSReportCapacitaTrasporto_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	Public Function GetDSReportStoricoProgrammi(ByVal operatore As String, ByVal data As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()

			spReportStoricoProgrammi.Parameters("@DataProgramma").Value = data
			spReportStoricoProgrammi.Parameters("@Operatore").Value = operatore

			da.SelectCommand = spReportStoricoProgrammi
			da.SelectCommand.CommandTimeout = AppSettingToInt32("GetDSReportStoricoProgrammi_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	' funzione chiamata da Bil_AdminWA per ottenere la lista e il numero degli operatori che hanno
	' la facolta' di utilizzare una certa unita'.
	' Il recodset di ritorno e' composto dal nome dell'unita', dal numero degli operatori e da una stringa
	' contenente la lista degli operatori
	Public Function GetDSReportOperatorUnitsList(ByVal dtDate As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()

			spReportOperatorUnitsList.Parameters("@dt").Value = dtDate

			da.SelectCommand = spReportOperatorUnitsList
			da.SelectCommand.CommandTimeout = AppSettingToInt32("GetDSReportOperatorUnitsList_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	' funzione chiamata da Bil_AdminWA per ottenere la lista degli operatore e il numero delle unita' divise per tipo
	' per una certa data di flusso
	' Il recodset di ritorno e' composto dal nome dell'operatore il tipo di unita' e il numero di unita'
	Public Function GetDSReportOperatorUnitsType(ByVal dtDate As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()

			spReportGetOperatorUnitsType.Parameters("@dt").Value = dtDate

			da.SelectCommand = spReportGetOperatorUnitsType
			da.SelectCommand.CommandTimeout = AppSettingToInt32("GetDSReportOperatorUnitsType_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	' funzione chiamata da Bil_AdminWA per ottenere un report che date una data iniziale e una 
	' data finale, contiene per ogni giorno i seguenti indicatori:
	'        -n.ro di contratti tagliati/ n.ro totale di contratti abilitati;
	'        -totale energia tagliata/ totale energia presentata a MGP dai Bilaterali presentato come produzione, 
	'        consumo e totale (come somma dei valori assoluti di produzione e consumo);
	'        -n.ro di contratto con almeno un'ora programmata nel giorno/ n.ro totale di contratti abilitati
	Public Function GetDSReportIndicatori(ByVal dtDateIn As DateTime, ByVal dtDateFn As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()

			spGetReportIndicatori.Parameters("@dtinizio").Value = dtDateIn
			spGetReportIndicatori.Parameters("@dtfine").Value = dtDateFn

			da.SelectCommand = spGetReportIndicatori
			da.SelectCommand.CommandTimeout = AppSettingToInt32("GetDSReportIndicatori_QueryTmo", 120)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	' report giornaliero contenente l�energia dei bilaterali nelle 24 ore suddivisa per zone.
	Public Function GetDSEnergiaGiornalieraPerZone(ByVal dtDataProgramma As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()

			spBilGetEnergiaGiornaliera.Parameters("@DataProgramma").Value = dtDataProgramma

			da.SelectCommand = spBilGetEnergiaGiornaliera
			da.SelectCommand.CommandTimeout = AppSettingToInt32("GetDSEnergiaGiornalieraPerZone_QueryTmo", 45)

			Dim ds As New DataSet
			ds.Tables.Add("Report")
			da.Fill(ds.Tables("Report"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function

	' report unit relate per amministratore.
	Public Function GetDSReportUnitRelateAdmin(ByVal op As String, ByVal un As String, ByVal dtFlusso As DateTime, ByVal dtRicerca As DateTime) As DataSet
		cn.ConnectionString = GetConnectionString()
		Try

			Dim cmd As SqlCommand = cn.CreateCommand()
			cmd.CommandTimeout = AppSettingToInt32("GetDSReportUnitRelateAdmin", 45)
			cmd.CommandType = CommandType.StoredProcedure
			cmd.CommandText = "dbo.spReportUnitRelate"

			If Not op Is Nothing AndAlso op.Length > 0 Then cmd.Parameters.Add("@op", op)
			If Not un Is Nothing AndAlso un.Length > 0 Then cmd.Parameters.Add("@un", un)
			If dtRicerca <> DateTime.MinValue Then cmd.Parameters.Add("@dtRicerca", dtRicerca)
			If dtFlusso <> DateTime.MinValue Then cmd.Parameters.Add("@dtFlusso", dtFlusso)

			Dim da As New SqlDataAdapter(cmd)

			Dim ds As New DataSet
			ds.Tables.Add("Report")

			cn.Open()
			da.Fill(ds.Tables("Report"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function


End Class
