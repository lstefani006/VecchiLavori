Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Collections

Public Class SDCUnita
    Inherits BilBLBase

    Public Function GetSDC_Unita() As DS_SDC_Unita
        cn.ConnectionString = GetConnectionString()
        Try
            cn.Open()

            Dim ds As New DS_SDC_Unita
            daSDC_Unita.Fill(ds.SDC_Unita)

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Function

    Public Function GetSDC_Sottotipounita() As ArrayList
		cn.ConnectionString = GetConnectionString()
		Dim dr As SqlDataReader
        Try
            cn.Open()

            cmdSelect.CommandText = "SELECT DISTINCT SottotipoUnita FROM dbo.SDC_Unita ORDER BY SottotipoUnita "
			dr = cmdSelect.ExecuteReader()
            Dim l As New ArrayList(0)
            While dr.Read
                l.Add(dr.GetString(0))
			End While
			dr.Close()

			Return l

		Catch ex As Exception
            smError(ex)
            Throw
		Finally
			If Not dr Is Nothing Then dr.Close()
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Function

    Public Sub SalvaDataSet(ByVal ds As DS_SDC_Unita)
        cn.ConnectionString = GetConnectionString()
        Dim tr As SqlTransaction = Nothing
        Try
            cn.Open()
            tr = cn.BeginTransaction()
            SetTransaction(daSDC_Unita, tr)

            daSDC_Unita.Update(ds.SDC_Unita)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw ex
        Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdInsert As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdate As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdDelete As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents daSDC_Unita As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.cmdInsert = New System.Data.SqlClient.SqlCommand
        Me.cmdUpdate = New System.Data.SqlClient.SqlCommand
        Me.cmdDelete = New System.Data.SqlClient.SqlCommand
        Me.cmdSelect = New System.Data.SqlClient.SqlCommand
        Me.daSDC_Unita = New System.Data.SqlClient.SqlDataAdapter
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persis" & _
        "t security info=False;initial catalog=Bilaterali"
        '
        'cmdInsert
        '
        Me.cmdInsert.CommandText = "INSERT INTO dbo.SDC_Unita (CodiceUnitaSDC, CategoriaUnitaSDC, NomeUnita, TipoUnit" & _
        "a, CoefficientePerdita, CodicePuntoDiScambioRilevanteSDC, PotenzaMassimaMWh, Pot" & _
        "enzaMinimaMWh, OrdineDiMerito, CodiceOperatoreDiRiferimentoSDC, Abilitata, TSMod" & _
        "ifica, ResponsabileAggiornamento, UnbalancedParticipantNumber, SottotipoUnita) V" & _
        "ALUES (@CodiceUnitaSDC, @CategoriaUnitaSDC, @NomeUnita, @TipoUnita, @Coefficient" & _
        "ePerdita, @CodicePuntoDiScambioRilevanteSDC, @PotenzaMassimaMWh, @PotenzaMinimaM" & _
        "Wh, @OrdineDiMerito, @CodiceOperatoreDiRiferimentoSDC, @Abilitata, @TSModifica, " & _
        "@ResponsabileAggiornamento, @UnbalancedParticipantNumber, @SottotipoUnita)"
        Me.cmdInsert.Connection = Me.cn
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NomeUnita", System.Data.SqlDbType.VarChar, 256, "NomeUnita"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TipoUnita", System.Data.SqlDbType.VarChar, 1, "TipoUnita"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CoefficientePerdita", System.Data.SqlDbType.Float, 8, "CoefficientePerdita"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, "CodicePuntoDiScambioRilevanteSDC"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PotenzaMassimaMWh", System.Data.SqlDbType.Float, 8, "PotenzaMassimaMWh"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PotenzaMinimaMWh", System.Data.SqlDbType.Float, 8, "PotenzaMinimaMWh"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrdineDiMerito", System.Data.SqlDbType.Float, 8, "OrdineDiMerito"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreDiRiferimentoSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreDiRiferimentoSDC"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnbalancedParticipantNumber", System.Data.SqlDbType.VarChar, 60, "UnbalancedParticipantNumber"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SottotipoUnita", System.Data.SqlDbType.VarChar, 100, "SottotipoUnita"))
        '
        'cmdUpdate
        '
        Me.cmdUpdate.CommandText = "UPDATE dbo.SDC_Unita SET NomeUnita = @NomeUnita, TipoUnita = @TipoUnita, Coeffici" & _
        "entePerdita = @CoefficientePerdita, CodicePuntoDiScambioRilevanteSDC = @CodicePu" & _
        "ntoDiScambioRilevanteSDC, PotenzaMassimaMWh = @PotenzaMassimaMWh, PotenzaMinimaM" & _
        "Wh = @PotenzaMinimaMWh, OrdineDiMerito = @OrdineDiMerito, CodiceOperatoreDiRifer" & _
        "imentoSDC = @CodiceOperatoreDiRiferimentoSDC, Abilitata = @Abilitata, TSModifica" & _
        " = GETDATE(), ResponsabileAggiornamento = @ResponsabileAggiornamento, Unbalanced" & _
        "ParticipantNumber = @UnbalancedParticipantNumber, SottotipoUnita = @SottotipoUni" & _
        "ta WHERE (CodiceUnitaSDC = @CodiceUnitaSDC) AND (CategoriaUnitaSDC = @CategoriaU" & _
        "nitaSDC)"
        Me.cmdUpdate.Connection = Me.cn
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NomeUnita", System.Data.SqlDbType.VarChar, 256, "NomeUnita"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TipoUnita", System.Data.SqlDbType.VarChar, 1, "TipoUnita"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CoefficientePerdita", System.Data.SqlDbType.Float, 8, "CoefficientePerdita"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, "CodicePuntoDiScambioRilevanteSDC"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PotenzaMassimaMWh", System.Data.SqlDbType.Float, 8, "PotenzaMassimaMWh"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PotenzaMinimaMWh", System.Data.SqlDbType.Float, 8, "PotenzaMinimaMWh"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrdineDiMerito", System.Data.SqlDbType.Float, 8, "OrdineDiMerito"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreDiRiferimentoSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreDiRiferimentoSDC"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnbalancedParticipantNumber", System.Data.SqlDbType.VarChar, 60, "UnbalancedParticipantNumber"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SottotipoUnita", System.Data.SqlDbType.VarChar, 100, "SottotipoUnita"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmdDelete
        '
        Me.cmdDelete.CommandText = "DELETE FROM dbo.SDC_Unita WHERE (CodiceUnitaSDC = @CodiceUnitaSDC) AND (Categoria" & _
        "UnitaSDC = @CategoriaUnitaSDC)"
        Me.cmdDelete.Connection = Me.cn
        Me.cmdDelete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDelete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmdSelect
        '
        Me.cmdSelect.CommandText = "SELECT dbo.SDC_Unita.* FROM dbo.SDC_Unita WHERE (CategoriaUnitaSDC = 'F')"
        Me.cmdSelect.Connection = Me.cn
        '
        'daSDC_Unita
        '
        Me.daSDC_Unita.DeleteCommand = Me.cmdDelete
        Me.daSDC_Unita.InsertCommand = Me.cmdInsert
        Me.daSDC_Unita.SelectCommand = Me.cmdSelect
        Me.daSDC_Unita.UpdateCommand = Me.cmdUpdate

    End Sub

#End Region

End Class
