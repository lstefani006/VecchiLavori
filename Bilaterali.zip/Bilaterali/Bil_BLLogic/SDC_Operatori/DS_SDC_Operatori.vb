Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Collections

Public Class DS_SDC_Operatori
    Inherits BilBLBase

    Public Function GetSDC_Operatori() As DS_SDC_Op
        cn.ConnectionString = GetConnectionString()
        Try
            cn.Open()
            
            Dim ds As New DS_SDC_Op
            daSDC_Op.Fill(ds.SDC_Operatori)

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Function

    Public Sub SalvaDataSet(ByVal ds As DS_SDC_Op)
        cn.ConnectionString = GetConnectionString()
        Dim tr As SqlTransaction = Nothing
        Try
            cn.Open()
            tr = cn.BeginTransaction()
            SetTransaction(daSDC_Op, tr)

            daSDC_Op.Update(ds.SDC_Operatori)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw ex
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents daSDC_Op As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdate As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdDelete As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdInsert As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.daSDC_Op = New System.Data.SqlClient.SqlDataAdapter
        Me.cmdDelete = New System.Data.SqlClient.SqlCommand
        Me.cmdInsert = New System.Data.SqlClient.SqlCommand
        Me.cmdSelect = New System.Data.SqlClient.SqlCommand
        Me.cmdUpdate = New System.Data.SqlClient.SqlCommand
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persis" & _
        "t security info=False;initial catalog=Bilaterali"
        '
        'daSDC_Op
        '
        Me.daSDC_Op.DeleteCommand = Me.cmdDelete
        Me.daSDC_Op.InsertCommand = Me.cmdInsert
        Me.daSDC_Op.SelectCommand = Me.cmdSelect
        Me.daSDC_Op.UpdateCommand = Me.cmdUpdate
        '
        'cmdDelete
        '
        Me.cmdDelete.CommandText = "DELETE FROM dbo.SDC_Operatori WHERE (CodiceOperatoreSDC = @CodiceOperatoreSDC)"
        Me.cmdDelete.Connection = Me.cn
		Me.cmdDelete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmdInsert
        '
        Me.cmdInsert.CommandText = "INSERT INTO dbo.SDC_Operatori (CodiceOperatoreSDC, RagioneSociale, Indirizzo1, In" & _
        "dirizzo2, Citta, Nazione, CodiceFiscale, PartitaIva, Fax, Email, ReferenteAmmini" & _
        "strativo, SedeAmministrativa, Abilitato, TSModifica, ResponsabileAggiornamento) " & _
        "VALUES (@CodiceOperatoreSDC, @RagioneSociale, @Indirizzo1, @Indirizzo2, @Citta, " & _
        "@Nazione, @CodiceFiscale, @PartitaIva, @Fax, @Email, @ReferenteAmministrativo, @" & _
        "SedeAmministrativa, @Abilitato, @TSModifica, @ResponsabileAggiornamento)"
        Me.cmdInsert.Connection = Me.cn
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RagioneSociale", System.Data.SqlDbType.VarChar, 256, "RagioneSociale"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Indirizzo1", System.Data.SqlDbType.VarChar, 256, "Indirizzo1"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Indirizzo2", System.Data.SqlDbType.VarChar, 256, "Indirizzo2"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Citta", System.Data.SqlDbType.VarChar, 256, "Citta"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Nazione", System.Data.SqlDbType.VarChar, 256, "Nazione"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceFiscale", System.Data.SqlDbType.VarChar, 16, "CodiceFiscale"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PartitaIva", System.Data.SqlDbType.VarChar, 11, "PartitaIva"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.VarChar, 256, "Fax"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.VarChar, 256, "Email"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReferenteAmministrativo", System.Data.SqlDbType.VarChar, 256, "ReferenteAmministrativo"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SedeAmministrativa", System.Data.SqlDbType.VarChar, 256, "SedeAmministrativa"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
        '
        'cmdSelect
        '
        Me.cmdSelect.CommandText = "SELECT dbo.SDC_Operatori.* FROM dbo.SDC_Operatori"
        Me.cmdSelect.Connection = Me.cn
        '
        'cmdUpdate
        '
        Me.cmdUpdate.CommandText = "UPDATE dbo.SDC_Operatori SET RagioneSociale = @RagioneSociale, Indirizzo1 = @Indi" & _
        "rizzo1, Indirizzo2 = @Indirizzo2, Citta = @Citta, Nazione = @Nazione, CodiceFisc" & _
        "ale = @CodiceFiscale, PartitaIva = @PartitaIva, Fax = @Fax, Email = @Email, Refe" & _
        "renteAmministrativo = @ReferenteAmministrativo, SedeAmministrativa = @SedeAmmini" & _
        "strativa, Abilitato = @Abilitato, ResponsabileAggiornamento = @ResponsabileAggio" & _
        "rnamento, TSModifica = GETDATE() WHERE (CodiceOperatoreSDC = @CodiceOperatoreSDC" & _
        ")"
        Me.cmdUpdate.Connection = Me.cn
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RagioneSociale", System.Data.SqlDbType.VarChar, 256, "RagioneSociale"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Indirizzo1", System.Data.SqlDbType.VarChar, 256, "Indirizzo1"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Indirizzo2", System.Data.SqlDbType.VarChar, 256, "Indirizzo2"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Citta", System.Data.SqlDbType.VarChar, 256, "Citta"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Nazione", System.Data.SqlDbType.VarChar, 256, "Nazione"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceFiscale", System.Data.SqlDbType.VarChar, 16, "CodiceFiscale"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PartitaIva", System.Data.SqlDbType.VarChar, 11, "PartitaIva"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.VarChar, 256, "Fax"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.VarChar, 256, "Email"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReferenteAmministrativo", System.Data.SqlDbType.VarChar, 256, "ReferenteAmministrativo"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SedeAmministrativa", System.Data.SqlDbType.VarChar, 256, "SedeAmministrativa"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
		Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, Nothing))

    End Sub

#End Region

End Class
