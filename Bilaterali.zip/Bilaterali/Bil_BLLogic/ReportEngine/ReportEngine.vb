Imports System.Data.SqlClient
Imports System.Globalization


Public Class ReportEngine
	Inherits BilBLBase

	<Serializable()> Public Class ComandiSQL
		Public ComandoSQL As ArrayList = New ArrayList
	End Class
	<Serializable()> Public Class ComandoSQL
		Public TestoSQL As String
		Public TipoSQL As String
		Public Selected As Boolean
	End Class
	<Serializable()> Public Class ReportParams
		Public ReportParam As ArrayList = New ArrayList
	End Class
	<Serializable()> Public Class ReportParam
		Public Nome As String
		Public NomeSql As String
		Public TipoWeb As String
		Public Tipo As String
		Public TipoSql As String
		Public Valore As String
		Public IsBLParam As Boolean
		Public Label As String
	End Class

	Public Function GetReports() As DS_ReportEngine
		cn.ConnectionString = GetConnectionString()
		Try
			cn.Open()

			Dim ds As New DS_ReportEngine
			da.Fill(ds.ReportEngine)

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function

    Public Function ExecuteCommand(ByVal comandiSQL As ComandiSQL, ByVal Params As ReportParams, ByRef exMsg As String, ByVal strCulture As String) As DataSet

        Try
            Dim culture As New CultureInfo(strCulture)
            cn.ConnectionString = GetConnectionString()
			cn.Open()

            Dim da As New SqlDataAdapter
            da.SelectCommand = New SqlCommand
			da.SelectCommand.Connection = cn

			da.SelectCommand.CommandTimeout = AppSettingToInt32("QuickReportQueryTmo", 60)
            Dim cmdSQL As ComandoSQL
            For Each comando As ComandoSQL In comandiSQL.ComandoSQL
                If comando.Selected Then
                    cmdSQL = comando
                End If
			Next

			da.SelectCommand.CommandText = cmdSQL.TestoSQL
			Select Case cmdSQL.TipoSQL
				Case "StoredProcedure"
					da.SelectCommand.CommandType = CommandType.StoredProcedure
				Case "SQLStatement"
					da.SelectCommand.CommandType = CommandType.Text
				Case Else
					da.SelectCommand.CommandType = CommandType.Text
			End Select

			For Each p As Bil.ReportEngine.ReportParam In Params.ReportParam
				If p.IsBLParam = True Then
					If p.Tipo = "DateTime" AndAlso p.TipoSql = "datetime" Then
						Dim prm As New SqlParameter(p.NomeSql, SqlDbType.DateTime)
						prm.Value = DateTime.Parse(p.Valore, culture)
						da.SelectCommand.Parameters.Add(prm)
					ElseIf p.Tipo = "Integer" AndAlso p.TipoSql = "integer" Then
						Dim prm As New SqlParameter(p.NomeSql, SqlDbType.Int)
						prm.Value = Integer.Parse(p.Valore, culture)
						da.SelectCommand.Parameters.Add(prm)
					ElseIf p.Tipo = "double" AndAlso p.TipoSql = "float" Then
						Dim prm As New SqlParameter(p.NomeSql, SqlDbType.Float)
						prm.Value = Double.Parse(p.Valore, culture)
						da.SelectCommand.Parameters.Add(prm)
					ElseIf p.Tipo = "String" AndAlso p.TipoSql.StartsWith("varchar") Then
						Dim prm As New SqlParameter(p.NomeSql, SqlDbType.VarChar)
						prm.Value = p.Valore
						da.SelectCommand.Parameters.Add(prm)
					End If
				End If

			Next

			Dim ds As New DataSet
			da.Fill(ds)
			Return ds

		Catch ex As Exception
            smTrace(ex, "Quick reports: parametro in ingresso errato")
            exMsg = ex.Message
			Return Nothing
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try

    End Function
#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdSelectReport As System.Data.SqlClient.SqlCommand
    Friend WithEvents da As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.cmdSelectReport = New System.Data.SqlClient.SqlCommand
        Me.da = New System.Data.SqlClient.SqlDataAdapter
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persist" & _
        " security info=True;initial catalog=Bilaterali;password=bilaterali"
        '
        'cmdSelectReport
        '
        Me.cmdSelectReport.CommandText = "SELECT CodiceReport, Descrizione, Parametri, Destinatario FROM dbo.ReportQueries"
        Me.cmdSelectReport.Connection = Me.cn
        '
        'da
        '
        Me.da.SelectCommand = Me.cmdSelectReport

    End Sub

#End Region

End Class
