Imports System.Text
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Threading
Imports SystemMonitor

Public Class Programmi
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
        cn.ConnectionString = GetConnectionString()
	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents daProgrammaOrarioPerUnita As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelectProgrammaOrario As System.Data.SqlClient.SqlCommand
	Friend WithEvents daProgrammaOrario As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdUpdateProgrammaOrario As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdUpdateProgrammaOrarioPerUnita As System.Data.SqlClient.SqlCommand
    Friend WithEvents daProgrammazioneContratto As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSPGetProgrammazione As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdateProgrammaOrarioContratto As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdSPGetProgrammazioneOraria As System.Data.SqlClient.SqlCommand
    Friend WithEvents daDettaglioProgOraria As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdUpdateDettaglioPOU As System.Data.SqlClient.SqlCommand
    Friend WithEvents daSessione As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelectSessione As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdSPGetProgrammaOrarioClient As System.Data.SqlClient.SqlCommand
    Friend WithEvents daPOClient As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSPGetProgrammaOrarioPerUnitaClient As System.Data.SqlClient.SqlCommand
    Friend WithEvents daPOUClient As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.daProgrammaOrarioPerUnita = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdUpdateProgrammaOrarioPerUnita = New System.Data.SqlClient.SqlCommand
		Me.cmdSelectProgrammaOrario = New System.Data.SqlClient.SqlCommand
		Me.daProgrammaOrario = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdUpdateProgrammaOrario = New System.Data.SqlClient.SqlCommand
		Me.daProgrammazioneContratto = New System.Data.SqlClient.SqlDataAdapter
		Me._cmdSPGetProgrammazione = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdateProgrammaOrarioContratto = New System.Data.SqlClient.SqlCommand
		Me._cmdSPGetProgrammazioneOraria = New System.Data.SqlClient.SqlCommand
		Me.daDettaglioProgOraria = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdUpdateDettaglioPOU = New System.Data.SqlClient.SqlCommand
		Me.daSessione = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSelectSessione = New System.Data.SqlClient.SqlCommand
		Me.cmdSPGetProgrammaOrarioClient = New System.Data.SqlClient.SqlCommand
		Me.daPOClient = New System.Data.SqlClient.SqlDataAdapter
		Me._cmdSPGetProgrammaOrarioPerUnitaClient = New System.Data.SqlClient.SqlCommand
		Me.daPOUClient = New System.Data.SqlClient.SqlDataAdapter
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
		"rsist security info=False;initial catalog=Bilaterali"
		'
		'daProgrammaOrarioPerUnita
		'
		Me.daProgrammaOrarioPerUnita.UpdateCommand = Me.cmdUpdateProgrammaOrarioPerUnita
		'
		'cmdUpdateProgrammaOrarioPerUnita
		'
		Me.cmdUpdateProgrammaOrarioPerUnita.CommandText = "UPDATE dbo.ProgrammaOrarioPerUnita SET ProgOrarioDellUnitaValidato = @ProgOrarioD" & _
		"ellUnitaValidato WHERE (IdContratto = @IdContratto) AND (DataProgramma = @DataPr" & _
		"ogramma) AND (PeriodoRilevante = @PeriodoRilevante) AND (CodiceUnitaSDC = @Codic" & _
		"eUnitaSDC) AND (CategoriaUnitaSDC = @CategoriaUnitaSDC)"
		Me.cmdUpdateProgrammaOrarioPerUnita.Connection = Me.cn
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgOrarioDellUnitaValidato", System.Data.SqlDbType.Bit, 1, "ProgOrarioDellUnitaValidato"))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrarioPerUnita.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdSelectProgrammaOrario
		'
		Me.cmdSelectProgrammaOrario.CommandText = "SELECT dbo.ProgrammaOrario.IdContratto, dbo.ProgrammaOrario.DataProgramma, dbo.Pr" & _
		"ogrammaOrario.PeriodoRilevante, dbo.ProgrammaOrario.Bilanciato, dbo.ProgrammaOra" & _
		"rio.TSCalcoloBilanciamento, dbo.ProgrammaOrario.TSModifica, dbo.ProgrammaOrario." & _
		"ProgrammaOrarioValidato, dbo.ProgrammaOrario.SbilanciamentoMWh, dbo.Contratto.Co" & _
		"diceContratto, dbo.Contratto.CRN FROM dbo.ProgrammaOrario INNER JOIN dbo.Contrat" & _
		"to ON dbo.ProgrammaOrario.IdContratto = dbo.Contratto.IdContratto WHERE (dbo.Pro" & _
		"grammaOrario.DataProgramma = @DataProgramma)"
		Me.cmdSelectProgrammaOrario.Connection = Me.cn
		Me.cmdSelectProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		'
		'daProgrammaOrario
		'
		Me.daProgrammaOrario.SelectCommand = Me.cmdSelectProgrammaOrario
		Me.daProgrammaOrario.UpdateCommand = Me.cmdUpdateProgrammaOrario
		'
		'cmdUpdateProgrammaOrario
		'
		Me.cmdUpdateProgrammaOrario.CommandText = "UPDATE dbo.ProgrammaOrario SET Bilanciato = @Bilanciato, ProgrammaOrarioValidato " & _
		"= @ProgrammaOrarioValidato, TSModifica = @TSModifica, TSCalcoloBilanciamento = @" & _
		"TSCalcoloBilanciamento, SbilanciamentoMWh = @SbilanciamentoMWh WHERE (IdContratt" & _
		"o = @IdContratto) AND (DataProgramma = @DataProgramma) AND (PeriodoRilevante = @" & _
		"PeriodoRilevante)"
		Me.cmdUpdateProgrammaOrario.Connection = Me.cn
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Bilanciato", System.Data.SqlDbType.Bit, 1, "Bilanciato"))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammaOrarioValidato", System.Data.SqlDbType.Bit, 1, "ProgrammaOrarioValidato"))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSCalcoloBilanciamento", System.Data.SqlDbType.DateTime, 8, "TSCalcoloBilanciamento"))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SbilanciamentoMWh", System.Data.SqlDbType.Float, 8, "SbilanciamentoMWh"))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdateProgrammaOrario.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		'
		'daProgrammazioneContratto
		'
		Me.daProgrammazioneContratto.SelectCommand = Me._cmdSPGetProgrammazione
		Me.daProgrammazioneContratto.UpdateCommand = Me.cmdUpdateProgrammaOrarioContratto
		'
		'_cmdSPGetProgrammazione
		'
		Me._cmdSPGetProgrammazione.CommandText = "dbo.[spBilGetProgrammaOrarioContratto]"
		Me._cmdSPGetProgrammazione.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdSPGetProgrammazione.Connection = Me.cn
		Me._cmdSPGetProgrammazione.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdSPGetProgrammazione.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me._cmdSPGetProgrammazione.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me._cmdSPGetProgrammazione.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OraLimite", System.Data.SqlDbType.TinyInt, 1))
		'
		'cmdUpdateProgrammaOrarioContratto
		'
		Me.cmdUpdateProgrammaOrarioContratto.CommandText = "dbo.[spBilUpdateFlagValidatoPO]"
		Me.cmdUpdateProgrammaOrarioContratto.CommandType = System.Data.CommandType.StoredProcedure
		Me.cmdUpdateProgrammaOrarioContratto.Connection = Me.cn
		Me.cmdUpdateProgrammaOrarioContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.cmdUpdateProgrammaOrarioContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me.cmdUpdateProgrammaOrarioContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.cmdUpdateProgrammaOrarioContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1))
		Me.cmdUpdateProgrammaOrarioContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Validato", System.Data.SqlDbType.Bit, 1))
		'
		'_cmdSPGetProgrammazioneOraria
		'
		Me._cmdSPGetProgrammazioneOraria.CommandText = "dbo.[spBilGetDettagliProgrammazioneOraria]"
		Me._cmdSPGetProgrammazioneOraria.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdSPGetProgrammazioneOraria.Connection = Me.cn
		Me._cmdSPGetProgrammazioneOraria.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdSPGetProgrammazioneOraria.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me._cmdSPGetProgrammazioneOraria.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1))
		Me._cmdSPGetProgrammazioneOraria.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		'
		'daDettaglioProgOraria
		'
		Me.daDettaglioProgOraria.SelectCommand = Me._cmdSPGetProgrammazioneOraria
		'
		'cmdUpdateDettaglioPOU
		'
		Me.cmdUpdateDettaglioPOU.CommandText = "[spBilUpdateFlagValidatoPOU]"
		Me.cmdUpdateDettaglioPOU.CommandType = System.Data.CommandType.StoredProcedure
		Me.cmdUpdateDettaglioPOU.Connection = Me.cn
		Me.cmdUpdateDettaglioPOU.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.cmdUpdateDettaglioPOU.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me.cmdUpdateDettaglioPOU.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.cmdUpdateDettaglioPOU.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1))
		Me.cmdUpdateDettaglioPOU.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16))
		Me.cmdUpdateDettaglioPOU.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1))
		Me.cmdUpdateDettaglioPOU.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Validato", System.Data.SqlDbType.Bit, 1))
		'
		'daSessione
		'
		Me.daSessione.SelectCommand = Me.cmdSelectSessione
		'
		'cmdSelectSessione
		'
		Me.cmdSelectSessione.CommandText = "SELECT Taglio, Offerte, LetturaMGP, Bilanciamento, CASE WHEN DataChiusuraMGP IS N" & _
		"ULL THEN 0 ELSE 1 END AS ChiusuraMGP, DataProgramma FROM dbo.SessioneBilaterali " & _
		"WHERE (DataProgramma = @DataProgramma)"
		Me.cmdSelectSessione.Connection = Me.cn
		Me.cmdSelectSessione.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		'
		'cmdSPGetProgrammaOrarioClient
		'
		Me.cmdSPGetProgrammaOrarioClient.CommandText = "dbo.[spBilGetProgrammaOrarioContrattoClient]"
		Me.cmdSPGetProgrammaOrarioClient.CommandType = System.Data.CommandType.StoredProcedure
		Me.cmdSPGetProgrammaOrarioClient.Connection = Me.cn
		Me.cmdSPGetProgrammaOrarioClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.cmdSPGetProgrammaOrarioClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me.cmdSPGetProgrammaOrarioClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.cmdSPGetProgrammaOrarioClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OraLimite", System.Data.SqlDbType.TinyInt, 1))
		Me.cmdSPGetProgrammaOrarioClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Operatore", System.Data.SqlDbType.VarChar, 16))
		'
		'daPOClient
		'
		Me.daPOClient.SelectCommand = Me.cmdSPGetProgrammaOrarioClient
		'
		'_cmdSPGetProgrammaOrarioPerUnitaClient
		'
		Me._cmdSPGetProgrammaOrarioPerUnitaClient.CommandText = "dbo.[spBilGetDettagliProgrammazioneOrariaClient]"
		Me._cmdSPGetProgrammaOrarioPerUnitaClient.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdSPGetProgrammaOrarioPerUnitaClient.Connection = Me.cn
		Me._cmdSPGetProgrammaOrarioPerUnitaClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdSPGetProgrammaOrarioPerUnitaClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me._cmdSPGetProgrammaOrarioPerUnitaClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1))
		Me._cmdSPGetProgrammaOrarioPerUnitaClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me._cmdSPGetProgrammaOrarioPerUnitaClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Operatore", System.Data.SqlDbType.VarChar, 16))
		'
		'daPOUClient
		'
		Me.daPOUClient.SelectCommand = Me._cmdSPGetProgrammaOrarioPerUnitaClient

	End Sub

#End Region

    Public Enum enOperatore
        toNO_OPERATORE = &H0&
        toACQUIRENTE = &H1&
        toCEDENTE = &H2&
        toRESPONSABILE = &H4&
	End Enum

	Public Function GetDataChiusuraMercato(ByVal dataProgramma As DateTime) As DateTime
		Try
			cn.Open()

			Dim cmd As New SqlClient.SqlCommand("select DataChiusuraMGP from SessioneBilaterali where DataProgramma=@d", cn)
			cmd.Parameters.Add("@d", dataProgramma)

			Dim r As Object = cmd.ExecuteScalar()
			If r Is Nothing Then
				cmd.CommandText = "INSERT INTO SessioneBilaterali (DataProgramma) VALUES (@d)"
				' esiste gia` sopra cmd.Parameters.Add("@d", dataProgramma)
				cmd.ExecuteNonQuery()

				Return DateTime.MaxValue
			End If


			If TypeOf r Is DBNull Then
				Return DateTime.MaxValue
			End If

			Dim t As DateTime = DirectCast(r, DateTime)
			Return t

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function

	Public Sub SetDataChiusuraMercato(ByVal dataProgramma As DateTime, ByVal dataChiusura As DateTime)
		Try


			If AppSettingToBoolean("SetDataChiusuraMercato.VecchiaVersione", False) Then

				cn.Open()

				Dim chiusuraMercato As Boolean

				If dataChiusura = DateTime.MaxValue Then
					chiusuraMercato = False
					Dim cmd As New SqlClient.SqlCommand("update SessioneBilaterali set DataChiusuraMGP=null where DataProgramma=@d", cn)
					cmd.Parameters.Add("@d", dataProgramma)
					cmd.ExecuteNonQuery()
				Else
					chiusuraMercato = True
					Dim cmd As New SqlClient.SqlCommand("update SessioneBilaterali set DataChiusuraMGP=@dc where DataProgramma=@d", cn)
					cmd.Parameters.Add("@d", dataProgramma)
					cmd.Parameters.Add("@dc", dataChiusura)
					cmd.ExecuteNonQuery()
				End If

				cn.Close()

				If chiusuraMercato Then
					' lancio in background l'aggiornamento di PO per il bilanciamento al CP
					ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf spChiusuraMercato), dataProgramma)
				Else
					' qui faccio l'inverso - metto a null lo sbil al CP
					ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf spRiaperturaMercato), dataProgramma)
				End If

			Else

				Dim chiusuraMercato As Boolean

				If dataChiusura = DateTime.MaxValue Then
					chiusuraMercato = False
				Else
					chiusuraMercato = True
				End If

				If chiusuraMercato Then
					BatchSerializer.BS.AddBatch(AddressOf spChiusuraMercatoBatch, dataProgramma, "SS_CLOS", "Chiusura sessione", dataProgramma, "")
				Else
					BatchSerializer.BS.AddBatch(AddressOf spRiaperturaMercatoBatch, dataProgramma, "SS_ROPN", "Riapertura sessione", dataProgramma, "")
				End If

			End If


		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			cn.Dispose()
		End Try
	End Sub

	Private Shared Sub spChiusuraMercatoBatch(ByVal o As Object)
		spChiusuraMercato(o)
		BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")
	End Sub

	Private Shared Sub spRiaperturaMercatoBatch(ByVal o As Object)
		spRiaperturaMercato(o)
		BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")
	End Sub


	Private Shared Sub spChiusuraMercato(ByVal o As Object)

		SmLog.smTraceIf(SmLog.smLogSwitch.TraceInfo, "Chiusura mercato: inizio attivita`")
		Dim dataFlusso As Date = CType(o, DateTime)

		If AppSettingToBoolean("Storico.Genera", False) Then
			Try
				Dim st As New Storico
				st.Cancella()
				st.GeneraStorico(dataFlusso)
			Catch ex As Exception
				SmLog.smError(ex, "LanciaScriptChiusuraMercato")
			End Try
		End If


		Dim cn As New SqlConnection
		Try
			cn.ConnectionString = BilBLBase.GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand("dbo.spChiudiMercato", cn)
			cmd.CommandType = CommandType.StoredProcedure
			cmd.CommandTimeout = AppSettingToInt32("spChiudiMercato.QueryTmo", 120)
			cmd.Parameters.Add("@d", dataFlusso)
			cmd.ExecuteNonQuery()

			cn.Close()

		Catch ex As Exception
			SmLog.smError(ex, "LanciaScriptChiusuraMercato")
			Throw

		Finally
			cn.Dispose()
		End Try

	End Sub

	Private Shared Sub spRiaperturaMercato(ByVal o As Object)

		SmLog.smTraceIf(SmLog.smLogSwitch.TraceInfo, "Riapertura mercato: inizio attivita`")
		Dim dataFlusso As Date = CType(o, DateTime)

		Dim cn As New SqlConnection
		Try
			cn.ConnectionString = BilBLBase.GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand("dbo.spRiapriMercato", cn)
			cmd.CommandType = CommandType.StoredProcedure
			cmd.CommandTimeout = AppSettingToInt32("spRiapriMercato.QueryTmo", 120)
			cmd.Parameters.Add("@d", dataFlusso)
			cmd.ExecuteNonQuery()

			cn.Close()

		Catch ex As Exception
			SmLog.smError(ex, "LanciaScriptChiusuraMercato")
			Throw

		Finally
			cn.Dispose()
		End Try

	End Sub



	Public Function GetSessioneBilaterali(ByVal DataProgramma As DateTime) As DS_SessioneBilaterali
		Try
			cn.Open()
			Debug.Assert(Not cmdSelectSessione.Parameters("@DataProgramma") Is Nothing)
			cmdSelectSessione.Parameters("@DataProgramma").Value = DataProgramma
			Dim ds As New DS_SessioneBilaterali
			daSessione.Fill(ds.SessioneBilaterali)
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function
	Public Sub UpdateFlagValidatoProgrammaOrarioPerUnita(ByVal IdContratto As String, ByVal Ora As Byte, ByVal DataProgramma As DateTime, ByVal CodiceUnitaSDC As String, ByVal CategoriaUnitaSDC As String, ByVal Validato As Boolean)
		'@Validato
		'@CodiceUnitaSDC
		'@CategoriaUnitaSDC
		'@IdContratto
		'@DataProgramma
		'@PeriodoRilevante
		Try
			cn.Open()
			cmdUpdateDettaglioPOU.Parameters("@IdContratto").Value = IdContratto
			cmdUpdateDettaglioPOU.Parameters("@DataProgramma").Value = DataProgramma
			cmdUpdateDettaglioPOU.Parameters("@PeriodoRilevante").Value = Ora
			cmdUpdateDettaglioPOU.Parameters("@CodiceUnitaSDC").Value = CodiceUnitaSDC
			cmdUpdateDettaglioPOU.Parameters("@CategoriaUnitaSDC").Value = CategoriaUnitaSDC
			cmdUpdateDettaglioPOU.Parameters("@Validato").Value = Validato
			Dim rowsAffected As Integer = cmdUpdateDettaglioPOU.ExecuteNonQuery()
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try

	End Sub
	Public Sub UpdateFlagValidatoProgrammaOrario(ByVal IdContratto As String, ByVal Ora As Byte, ByVal DataProgramma As DateTime, ByVal Validato As Boolean)
		Try
			cn.Open()
			' Parametri della Query
			' Chiave della tabella PROGRAMMAORARIO
			' @IdContratto
			' @DataProgramma
			' @PeriodoRilevante
			'
			' Valore del flag di abilitazione
			' @ProgrammaOrarioValidato
			cmdUpdateProgrammaOrarioContratto.Parameters("@IdContratto").Value = IdContratto
			cmdUpdateProgrammaOrarioContratto.Parameters("@DataProgramma").Value = DataProgramma
			cmdUpdateProgrammaOrarioContratto.Parameters("@PeriodoRilevante").Value = Ora
			cmdUpdateProgrammaOrarioContratto.Parameters("@Validato").Value = Validato
			Dim rowsAffected As Integer = cmdUpdateProgrammaOrarioContratto.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Sub
	Public Function GetProgrammaOrarioPerUnita(ByVal IdContratto As String, ByVal PeriodoRilevante As Byte, ByVal DataProgramma As DateTime, ByVal IdOperatore As String) As DS_DettaglioProgOraria
		Try
			cn.Open()
			daPOUClient.SelectCommand.Parameters("@IdContratto").Value = IdContratto
			daPOUClient.SelectCommand.Parameters("@PeriodoRilevante").Value = PeriodoRilevante
			daPOUClient.SelectCommand.Parameters("@DataProgramma").Value = DataProgramma
			daPOUClient.SelectCommand.Parameters("@Operatore").Value = IdOperatore
			Dim ds As New DS_DettaglioProgOraria
			daPOUClient.Fill(ds.ProgrammazioneOraria)
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function
	Public Function GetProgrammazioneOraria(ByVal IdContratto As String, ByVal PeriodoRilevante As Byte, ByVal DataProgramma As DateTime) As DS_DettaglioProgOraria
		Try
			cn.Open()
			' @IdContratto      int
			' @PeriodoRilevante tinyint
			' @DataProgramma    smalldatetime
			daDettaglioProgOraria.SelectCommand.Parameters("@IdContratto").Value = IdContratto
			daDettaglioProgOraria.SelectCommand.Parameters("@PeriodoRilevante").Value = PeriodoRilevante
			daDettaglioProgOraria.SelectCommand.Parameters("@DataProgramma").Value = DataProgramma

			Dim ds As New DS_DettaglioProgOraria
			daDettaglioProgOraria.Fill(ds.ProgrammazioneOraria)
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try

	End Function
	Public Function GetProgrammaOrarioByIdContratto(ByVal IdContratto As String, ByVal dataRicerca As DateTime) As DS_ProgrammazioneContratto
		Try
			Dim numHourDay As Byte = GetNumberOfHourOfDay(dataRicerca)
			cn.Open()
			daProgrammazioneContratto.SelectCommand.Parameters("@IdContratto").Value = IdContratto
			daProgrammazioneContratto.SelectCommand.Parameters("@DataProgramma").Value = dataRicerca
			daProgrammazioneContratto.SelectCommand.Parameters("@OraLimite").Value = numHourDay

			Dim ds As New DS_ProgrammazioneContratto
			daProgrammazioneContratto.Fill(ds.ProgrammazioneContratto)
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function

	Public Function GetProgrammaOrarioByIdContratto(ByVal IdContratto As String, ByVal dataRicerca As DateTime, ByVal IdOperatore As String) As DS_ProgrammazioneContratto
		Try
			Dim numHourDay As Byte = GetNumberOfHourOfDay(dataRicerca)
			cn.Open()
			daPOClient.SelectCommand.Parameters("@IdContratto").Value = IdContratto
			daPOClient.SelectCommand.Parameters("@DataProgramma").Value = dataRicerca
			daPOClient.SelectCommand.Parameters("@OraLimite").Value = numHourDay
			daPOClient.SelectCommand.Parameters("@Operatore").Value = IdOperatore

			Dim ds As New DS_ProgrammazioneContratto
			daPOClient.Fill(ds.ProgrammazioneContratto)
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function

	Public Function GetListOperatori() As DataSet
		Dim tr As SqlClient.SqlTransaction
		Try
			cn.Open()

			Dim cmd As New SqlClient.SqlCommand("spListaOperatori", cn)
			cmd.CommandType = CommandType.StoredProcedure

			Dim da As New SqlClient.SqlDataAdapter(cmd)

			Dim ds As New DataSet
			Dim dt As DataTable = ds.Tables.Add("Operatori")
			da.Fill(dt)
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try

	End Function

	Public Function GetProgrammazioneAdmin(ByVal dataRicerca As DateTime, ByVal rinominaCampi As Boolean, Optional ByVal CodiceOpCed As String = Nothing, Optional ByVal CodiceOpAcq As String = Nothing) As DataSet
		Dim tr As SqlClient.SqlTransaction
		Try
			cn.Open()
			'tr = cn.BeginTransaction()
			Dim numHourDay As Byte = GetNumberOfHourOfDay(dataRicerca)
			Dim strSPName As String
			Select Case numHourDay
				Case 23
					strSPName = "spBilGetProgrammazione23"
				Case 24
					strSPName = "spBilGetProgrammazione24"
				Case 25
					strSPName = "spBilGetProgrammazione25"
				Case Else
					Throw New ApplicationException("Errore funzione GetNumberOfHourOfDay numero ore per giorno errato=" & numHourDay.ToString())
			End Select

			Dim da As New SqlClient.SqlDataAdapter
			Dim cmdSp As New SqlClient.SqlCommand(strSPName, cn)
			cmdSp.CommandType = CommandType.StoredProcedure

			cmdSp.Parameters.Add("@DataProgramma", dataRicerca)

			If Not CodiceOpAcq Is Nothing Then
				cmdSp.Parameters.Add("@CodiceOpAcq", CodiceOpAcq)
			Else
				cmdSp.Parameters.Add("@CodiceOpAcq", DBNull.Value)
			End If

			If Not CodiceOpCed Is Nothing Then
				cmdSp.Parameters.Add("@CodiceOpCed", CodiceOpCed)
			Else
				cmdSp.Parameters.Add("@CodiceOpCed", DBNull.Value)
			End If

			da.SelectCommand = cmdSp

			If rinominaCampi = True Then
				Dim dm As System.Data.Common.DataTableMapping
				dm = da.TableMappings.Add("Programmazione", "Programmazione")
				For i As Integer = 1 To numHourDay
					Dim a As String
					Dim b As String

					a = (i \ 10).ToString()
					b = (i Mod 10).ToString()
					If a = "0" Then a = "-"

					Dim c As String
					c = Environment.NewLine + a + Environment.NewLine + b

					dm.ColumnMappings.Add(String.Format("A{0:D2}", i), "A" + c)
					dm.ColumnMappings.Add(String.Format("C{0:D2}", i), "C" + c)
					dm.ColumnMappings.Add(String.Format("B{0:D2}", i), "B" + c)
				Next
			End If

			Dim ds As New DataSet
			ds.Tables.Add("Programmazione")
			' ATTENZIONE: non cambiare il nome alla tabella, viene utilizzato
			' nella webform frmProgrammazione.aspx....
			'da.Fill(ds, "Programmazione")
			da.Fill(ds.Tables(0))
			'tr.Commit()
			Return ds
		Catch ex As Exception
			smError(ex)
			'If Not tr Is Nothing Then tr.Rollback()
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function

	Public Function GetProgrammazioneUser(ByVal dataRicerca As DateTime, ByVal IdOperatore As String) As DataSet
		Try
			cn.Open()
			Dim numHourDay As Byte = GetNumberOfHourOfDay(dataRicerca)
			Dim strSPName As String
			Select Case numHourDay
				Case 23
					strSPName = "spBilGetProgrammazioneClient23"
				Case 24
					strSPName = "spBilGetProgrammazioneClient24"
				Case 25
					strSPName = "spBilGetProgrammazioneClient25"
				Case Else
					Throw New ApplicationException("Errore funzione GetNumberOfHourOfDay numero ore per giorno errato=" & numHourDay.ToString())
			End Select

			Dim da As New SqlClient.SqlDataAdapter
			Dim cmdSp As New SqlClient.SqlCommand(strSPName, cn)
			cmdSp.CommandType = CommandType.StoredProcedure
			Dim sqlDataProgrammaParam As New SqlClient.SqlParameter("@DataProgramma", SqlDbType.DateTime, 8)
			sqlDataProgrammaParam.Value = dataRicerca
			cmdSp.Parameters.Add(sqlDataProgrammaParam)
			cmdSp.Parameters.Add(New SqlClient.SqlParameter("@Operatore", IdOperatore))

			da.SelectCommand = cmdSp

			Dim dm As System.Data.Common.DataTableMapping
			dm = da.TableMappings.Add("Programmazione", "Programmazione")
			For i As Integer = 1 To numHourDay
				Dim a As String
				Dim b As String

				a = (i \ 10).ToString()
				b = (i Mod 10).ToString()
				If a = "0" Then a = "-"

				Dim c As String
				c = Environment.NewLine + a + Environment.NewLine + b

				dm.ColumnMappings.Add(String.Format("A{0:D2}", i), "A" + c)
				dm.ColumnMappings.Add(String.Format("C{0:D2}", i), "C" + c)
				dm.ColumnMappings.Add(String.Format("B{0:D2}", i), "B" + c)
			Next


			Dim ds As New DataSet
			ds.Tables.Add("Programmazione")
			' ATTENZIONE: non cambiare il nome alla tabella, viene utilizzato
			' nella webform frmProgrammazione.aspx....
			da.Fill(ds.Tables(0))
			Return ds
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If (cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function





	Public Sub SaveProgrammi(ByVal ds As Bil.DS_UnitaProgrammate)
		cn.ConnectionString = GetConnectionString()

		Dim tr As SqlClient.SqlTransaction

		Try
			cn.Open()

			tr = cn.BeginTransaction(IsolationLevel.RepeatableRead)

			Me.SetTransaction(daProgrammaOrario, tr)
			Me.SetTransaction(daProgrammaOrarioPerUnita, tr)

			Dim dr() As DataRow

			'ATTENZIONE qui si salvano SOLO i record modificati!!!
			' E` lecito trovare QUI record inseriti (che NON si

			dr = ds.ProgrammaOrario.Select(Nothing, Nothing, DataViewRowState.ModifiedCurrent)
			daProgrammaOrario.Update(dr)
			Debug.Assert(ds.ProgrammaOrario.Select(Nothing, Nothing, DataViewRowState.Deleted).Length = 0)

			dr = ds.ProgrammaOrarioPerUnita.Select(Nothing, Nothing, DataViewRowState.ModifiedCurrent)
			daProgrammaOrarioPerUnita.Update(dr)
			Debug.Assert(ds.ProgrammaOrarioPerUnita.Select(Nothing, Nothing, DataViewRowState.Deleted).Length = 0)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			cn.Dispose()
		End Try


	End Sub


End Class


