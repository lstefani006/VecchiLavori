Public Class Config
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		components = New System.ComponentModel.Container
	End Sub

#End Region
	Public Function TagliaSempreSeOpAcquirenteNonGME() As Boolean
		Return AppSettingToBoolean("TagliaSempreSeOpAcquirenteNonGME", True)
	End Function
	Public Function ContrattoDefinibileSoloDa() As String
		Return AppSettingToString("ContrattoDefinibileSoloDa", "OperatoreCedente")
	End Function
	Public Function OperatoreResponsabile() As String
		Return AppSettingToString("OperatoreResponsabile", "OperatoreCedente")
	End Function
	Public Function OpzioniGestioneTaglio() As String
		Return AppSettingToString("OpzioniGestioneTaglio", "TC")
	End Function
	Public Function OpzioniGestioneTaglioDefault() As String
		Return AppSettingToString("OpzioniGestioneTaglioDefault", "T")
	End Function
	Public Function SogliaSbilanciamentoMWh() As String
		Return AppSettingToString("SogliaMWhBilanciamento", "0.001")
	End Function
End Class
