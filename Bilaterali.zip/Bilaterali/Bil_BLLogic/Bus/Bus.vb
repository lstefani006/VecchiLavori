Imports System.IO
Imports System.Configuration
Imports System.Globalization
Imports System.Text
Imports System.Xml
Imports System.Xml.Schema
Imports System.Collections
Imports SystemMonitor

Public Class Bus
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        _cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents _daBus As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelectBusQuantity As System.Data.SqlClient.SqlCommand
    Friend WithEvents _dsBus As Bil.DS_BUSQuantity
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me._daBus = New System.Data.SqlClient.SqlDataAdapter
        Me._cmdSelectBusQuantity = New System.Data.SqlClient.SqlCommand
        Me._dsBus = New Bil.DS_BUSQuantity
        CType(Me._dsBus, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
        "rsist security info=False;initial catalog=Bilaterali"
		'
        '_daBus
        '
        Me._daBus.SelectCommand = Me._cmdSelectBusQuantity
        '
        '_cmdSelectBusQuantity
        '
        Me._cmdSelectBusQuantity.CommandText = "SELECT SUM(ISNULL(dbo.ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP, 0)) AS QtyMwpAs" & _
        "segnataMGP, dbo.ProgrammaOrarioPerUnita.PeriodoRilevante, dbo.ProgrammaOrarioPer" & _
        "Unita.CodiceUnitaSDC FROM dbo.ProgrammaOrarioPerUnita INNER JOIN (SELECT IdContr" & _
        "atto, CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente FROM Contratto WHE" & _
        "RE CodiceOperatoreSDCAcquirente = @CodiceOperatoreSDC OR CodiceOperatoreSDCCeden" & _
        "te = @CodiceOperatoreSDC) ContrattiOp ON dbo.ProgrammaOrarioPerUnita.IdContratto" & _
        " = ContrattiOp.IdContratto WHERE (dbo.ProgrammaOrarioPerUnita.DataProgramma = @D" & _
        "ataProgramma) AND (ContrattiOp.CodiceOperatoreSDCAcquirente = @CodiceOperatoreSD" & _
        "C) OR (dbo.ProgrammaOrarioPerUnita.DataProgramma = @DataProgramma) AND (Contratt" & _
        "iOp.CodiceOperatoreSDCCedente = @CodiceOperatoreSDC) GROUP BY dbo.ProgrammaOrari" & _
        "oPerUnita.PeriodoRilevante, dbo.ProgrammaOrarioPerUnita.CodiceUnitaSDC ORDER BY " & _
        "dbo.ProgrammaOrarioPerUnita.CodiceUnitaSDC"
        Me._cmdSelectBusQuantity.Connection = Me._cn
		Me._cmdSelectBusQuantity.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
        Me._cmdSelectBusQuantity.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.Variant))
        '
        '_dsBus
        '
        Me._dsBus.DataSetName = "DS_BUSQuantity"
        Me._dsBus.Locale = New System.Globalization.CultureInfo("it-IT")
        CType(Me._dsBus, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region

	' STR106
	' e` possibile generare i BUS con Prelimirary solo quando ci sono i prezzi per quel giorno
	' altrimenti e` un Prelimirary Provisional
    Public Function CanGenerateBus(ByVal DataProgramma As DateTime) As Boolean
        Dim sBusQueryTmo As String = "BusQueryTmo"
        Try
            _cn.ConnectionString = MyBase.GetConnectionString()
            _cn.Open()

            Dim cmd As New SqlClient.SqlCommand("select count(*) from PrezzoUnitario where Data=@d", _cn)
            cmd.Parameters.Add("@d", DataProgramma)

            '
            ' Query timeout a 45 secondi salvo specificato diversamente
            '
            cmd.CommandTimeout = AppSettingToInt32(sBusQueryTmo, 45)

            Dim r As Integer = CType(cmd.ExecuteScalar(), Integer)
            Return r > 0

        Catch ex As Exception
            smError(ex)
            Return True
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
    End Function

	Public Sub GenerateXmlBusFileBatch(ByVal DataProgramma As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf GenerateXmlBusFileAsync, DataProgramma, "BUS", "Generazione XML BUS", DataProgramma, runningOperator)
	End Sub

	Private Shared Sub GenerateXmlBusFileAsync(ByVal DataProgramma As Object)
		Dim bl As New Bus
		bl.GenerateXmlBusFile(CType(DataProgramma, DateTime))
		bl.Dispose()
	End Sub

#Region " Funzioni private "

	' La generazione dei file BUS inizia qui.
	' Viene letta la lista degli operatori che devono ricevere il BUS
	' e per ogniuno si genera il file corrispondente.
	Private Function GenerateXmlBusFile(ByVal DataProgramma As DateTime) As Boolean
		Try
			smTrace("Inizio Generazione file BUS")

			' Gli operatori che devono ricevere un BUS sono dati dai contratti in validita` nella
			' data "DataProgramma" nelle figure degli operatori acquirenti e cedenti.
			Dim alOperazioniErrate As New ArrayList
			Dim alListaOperatori As ArrayList = GetListaOperatoriBUS(DataProgramma)
			If Not (alListaOperatori Is Nothing) Then

				Debug.Assert(alListaOperatori.Count > 0, "Lista OperatoriBUS vuota per la data """ & DataProgramma.Date.ToString(New CultureInfo("it-IT")) & """")

				' per ogni operatore genero il bus.
				For Each CodiceOperatoreSDC As String In alListaOperatori
					Dim ret As Boolean = GenerateXmlBusFile(CodiceOperatoreSDC, DataProgramma)
					If Not (ret) Then
						' Mi memorizzo se l'operazione e' andata male per l'operatore corrente.
						' Per adesso non mi serve pero' puo' tornare utile....
						alOperazioniErrate.Add(CodiceOperatoreSDC)
					End If
				Next

			Else
				smError("Errore oggetto ListaOperatoriBUS Nothing")
				Throw New ApplicationException("Errore oggetto ListaOperatoriBUS Nothing")
			End If

			smTrace("Fine Generazione file BUS")

			Return (alOperazioniErrate.Count > 0)
		Catch ex As Exception
			smError(ex, "Generazione file BUS")
		End Try

	End Function

	' genera il file bus per operatore/data
	Private Function GenerateXmlBusFile(ByVal CodiceOperatoreSDC As String, ByVal DataProgramma As DateTime) As Boolean
		Dim sBusQueryTmo As String = "BusQueryTmo"
		Try

			smTrace("Generazione BUS - inizio elaborazione per op=" + CodiceOperatoreSDC)
			BatchSerializer.SetProgressBatch("Elaborazione op=" + CodiceOperatoreSDC)

			_cn.ConnectionString = MyBase.GetConnectionString()
			_cn.Open()

			' trovo se esiste il prezzo unitario. Se non esiste sono in PreliminaryProvisional
			Dim cmd As New SqlClient.SqlCommand("select count(*) from PrezzoUnitario where Data=@d", _cn)
			cmd.Parameters.Add("@d", DataProgramma)
			cmd.CommandTimeout = AppSettingToInt32(sBusQueryTmo, 45)
			Dim isPreliminaryProvisional As Boolean = CType(cmd.ExecuteScalar(), Integer) = 0


			' faccio la query per il BUS
			' la query riporta la somma delle quantita` assegnate dal mercato per unita` dell'operatore
			' per ora. In pratica si perde il dettaglio del contratto.
			Dim dsQty As DS_BUSQuantity = GetBusQuantity(_cn, CodiceOperatoreSDC, DataProgramma)

			If (dsQty.BusQuantity.Rows.Count > 0) Then
				' data nel formato YYYYMMDD
				Dim strData As String = GetDataProgrammaFormattata(DataProgramma)

				' chiedo la lista delle unita` ... ????? attenzione fa select su Bil_Unita... che controlla la elegibility.
				Dim dsUnita As DS_Unita = GetListaUnita(_cn)


				Dim bus As New BusXmlGenerator(DataProgramma, CodiceOperatoreSDC, strData, dsQty, dsUnita, isPreliminaryProvisional)
				bus.Connection = _cn
				bus.XMLSenderInfo = GetSenderInformation()
				Dim res As Boolean = bus.GenerateXmlBUS()

				smTrace("Generazione BUS - fine elaborazione per op=" + CodiceOperatoreSDC)

				Return True
			Else
				' Non ci sono record nel dataset => non devo generare il file
				smTrace("Generazione BUS - fine elaborazione per op=" + CodiceOperatoreSDC + " - nessun dato --> non genero il BUS")
				Return False
			End If

		Catch ex As Exception
			smError(ex, "Generazione BUS per operatore " + CodiceOperatoreSDC + " fallita")
			Return False
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try

	End Function



	Private Function GetSenderInformation() As XMLSenderData
		Dim senderInfo As XMLSenderData

		'senderInfo.TradingPartnerType = "Operator"
		'senderInfo.CompanyName = "GRTNBilateralista"
		'senderInfo.CompanyIdentifier = "IDGRTNBI"

		senderInfo.TradingPartnerType = ConfigurationSettings.AppSettings("Sender_TradingPartnerType")
		senderInfo.CompanyName = ConfigurationSettings.AppSettings("Sender_CompanyName")
		senderInfo.CompanyIdentifier = ConfigurationSettings.AppSettings("Sender_CompanyIdentifier")

		Return senderInfo
	End Function
	Private Function GetBusQuantity(ByVal cn As SqlClient.SqlConnection, ByVal CodiceOperatoreSDC As String, ByVal DataProgramma As DateTime) As DS_BUSQuantity
		Dim sBusQueryTmo As String = "BusQueryTmo"
		Try
			If (cn.State = ConnectionState.Closed) Then
				cn.Open()
			End If

			Dim _cmd As New SqlClient.SqlCommand
			_cmd.Connection = cn


			_cmd.CommandText = "dbo.[spBilGeneraBus]"
			_cmd.CommandType = System.Data.CommandType.StoredProcedure
			_cmd.Parameters.Add(New SqlClient.SqlParameter("@CodiceOperatoreSDC", CodiceOperatoreSDC))
			_cmd.Parameters.Add(New SqlClient.SqlParameter("@DataProgramma", DataProgramma))

			'If (False) Then
			'    Dim qb As New QueryBuilder(BilBLBase.GetCompleteFileName(".\Query\Bus_Select_GetBusQuantity.sql"))
			'    qb.Add(_cmd)
			'    _cmd.CommandText = qb.CommandText
			'End If

			_daBus.SelectCommand = _cmd

			'
			' Query Timeout 45 secondi se non specificato diversamente
			'
			_daBus.SelectCommand.CommandTimeout = AppSettingToInt32(sBusQueryTmo, 45)
			Dim ds As New DS_BUSQuantity
			_daBus.Fill(ds.BusQuantity)

			Return ds
		Catch ex As Exception
			smError(ex)
		End Try
	End Function

	Private Function GetListaUnita(ByVal cn As SqlClient.SqlConnection) As DS_Unita
		Try
			Dim blUnita As New Unita

			Dim ds As DS_Unita
			ds = blUnita.GetUnita()
			Return ds
		Catch ex As Exception
			Throw ex
		End Try
	End Function

	Private Function GetDataProgrammaFormattata(ByVal DataProgramma As DateTime) As String
		Return String.Format("{0:yyyy}{0:MM}{0:dd}", DataProgramma)
	End Function

	Private Function GetListaOperatoriBUS(ByVal DataProgramma As DateTime) As ArrayList
		Try
			Dim blOperatoriBUS As New Operatore

			Dim al As ArrayList
			al = blOperatoriBUS.GetOperatoriBUS(DataProgramma)
			Return al
		Catch ex As Exception
			Throw ex
		End Try
	End Function
#End Region

#Region " Classe per la generazione dei file XML BUS "

	Public Structure XMLSenderData
		Public TradingPartnerType As String
		Public CompanyName As String
		Public CompanyIdentifier As String
	End Structure

#Region " Classe contenente le informazioni sulla Quantita' per periodo rilevante di un'unita` "
	Public Class UnitaQuantityData
		Private ora As Byte
		Private qty As Double
		Private idUnita As String
		Public Sub New(ByVal CodiceUnitaSDC As String, ByVal PeriodoRilevante As Byte, ByVal Quantity As Double)
			Me.ora = PeriodoRilevante
			Me.qty = Quantity
			Me.idUnita = CodiceUnitaSDC
		End Sub

		Public Property PeriodoRilevante() As Byte
			Get
				Return Me.ora
			End Get
			Set(ByVal Value As Byte)
				Me.ora = Value
			End Set
		End Property

		Public Property QUantita() As Double
			Get
				Return Me.qty
			End Get
			Set(ByVal Value As Double)
				Me.qty = Value
			End Set
		End Property
	End Class
#End Region

#Region " Classe che implemente la chiave per la SortedList delle Quantita' "
	Public Class UnitaKey
		Implements IComparable

		Private idUnita As String
		Private ora As Byte

		Public Sub New()

		End Sub

		Public Sub New(ByVal CodiceUnitaSDC As String, ByVal PeriodoRilevante As Byte)
			Me.idUnita = CodiceUnitaSDC
			Me.ora = PeriodoRilevante
		End Sub

		Property CodiceUnitaSDC() As String
			Get
				Return Me.idUnita
			End Get
			Set(ByVal Value As String)
				Me.idUnita = Value
			End Set
		End Property

		Property Hour() As Byte
			Get
				Return Me.ora
			End Get
			Set(ByVal Value As Byte)
				Me.ora = Value
			End Set
		End Property

		Public Function CompareTo(ByVal obj As Object) As Integer Implements System.IComparable.CompareTo
			If TypeOf obj Is UnitaKey Then
				Dim temp As UnitaKey = CType(obj, UnitaKey)

				Dim r As Integer = String.Compare(temp.idUnita, Me.idUnita)
				If r <> 0 Then Return r

				' Gli ID Unita sono uguali
				If (Me.ora < temp.ora) Then Return -1
				If (Me.ora > temp.ora) Then Return 1
				Return 0
			End If

			Throw New ArgumentException("Object is not a UnitaKey")

		End Function
	End Class

#End Region

	Public Class BusXmlGenerator
		' Stringhe COSTANTI utilizzate nel file XML
		Const RECIPIENT_PARTNER_TYPE As String = "Market Participant"
		'Const BILATERALI_UNIT_SCHEDULE_TYPE As String = "PreliminaryProvisional"
		Const BILATERALI_UNIT_SCHEDULE_CUMMULATIVE As String = "No"
		Const BILATERALI_UNIT_SCHEDULE_MARKET As String = "MGP"
		Const QUANTITY_UNITA_MISURA As String = "MWh"

		' CodiceOperatore SDC corrente
		Private codOp As String
		' Data Programma formattata (yyyymmdd) per generare i file BUS
		Private dataProg As String
		' Data creazione formattata (yyyymmdd) XML BUS
		Private dataCreazioneYYYYMMdd As String
		' Ora creazione Formattata 
		Private oraCreazioneHHMMSSmmm As String
		' DataSet contenente le Quantita' di Mwh delle varie Unita' di un Operatore
		Private dsQty As DS_BUSQuantity
		' Informazioni Sender
		Private senderInfo As XMLSenderData
		' Elenco informazioni Unita
		Private dsUnita As DS_Unita
		' Hash Table contenente le Unita e relativi dati sulle quantita' per periodo rilevante
		Private htQuantity As Hashtable
		' Connessione al DataBase
		Private cn As SqlClient.SqlConnection
		' Connessione aperta dalla classe
		Private connOpenInside As Boolean
		' Sorted List (non usata)
		'Private slQuantityInfoByUnita As SortedList
		Private dataFlusso As DateTime
		Private isPreliminaryProvisional As Boolean


		' ============== COSTRUTTORI ============================
		Public Sub New(ByVal dataFlusso As DateTime, ByVal CodiceOperatoreSDC As String, ByVal DataProgramma As String, ByVal dsQuantita As DS_BUSQuantity, ByVal dsu As DS_Unita, ByVal isPreliminaryProvisional As Boolean)
			Me.New(dataFlusso, CodiceOperatoreSDC, DataProgramma, dsQuantita, dsu, Nothing, isPreliminaryProvisional)
		End Sub

		Public Sub New(ByVal dataFlusso As DateTime, ByVal CodiceOperatoreSDC As String, ByVal DataProgramma As String, ByVal dsQuantita As DS_BUSQuantity, ByVal dsu As DS_Unita, ByVal _cn As SqlClient.SqlConnection, ByVal isPreliminaryProvisional As Boolean)
			Me.codOp = CodiceOperatoreSDC
			Me.dataProg = DataProgramma
			Me.dsQty = dsQuantita
			Me.dsUnita = dsu
			Me.dataCreazioneYYYYMMdd = GetDataCreazioneFormattataYYYYMMdd(DateTime.Now())
			Me.htQuantity = New Hashtable
			Me.cn = _cn
			Me.connOpenInside = False
			Me.dataFlusso = dataFlusso
			Me.isPreliminaryProvisional = isPreliminaryProvisional
		End Sub

		Protected Overrides Sub Finalize()
			MyBase.Finalize()
			If (Me.connOpenInside) Then
				Me.cn.Close()
			End If
			Me.connOpenInside = False
		End Sub
		' ============== FUNZIONI PRIVATE ============================
		Private Function GetDataCreazioneFormattataYYYYMMdd(ByVal DataCreazione As DateTime) As String
			Return String.Format("{0:yyyy}{0:MM}{0:dd}", DateTime.Now())
		End Function

		Private Function GetOraCreazioneFormattataHHMMSSmmm(ByVal OraCreazione As DateTime) As String
			Return String.Format("{0:HH}{0:mm}{0:ss}{0:fff}", DateTime.Now())
		End Function

		Private Function GetXmlBusFileName(ByVal dataProgrammaFormattata As String, ByVal id14Caratteri As String) As String
			If dataProgrammaFormattata Is Nothing Then Throw New ArgumentException("Errore creazione nome file BUS: stringa della data nulla")
			If id14Caratteri Is Nothing Then Throw New ArgumentException("Errore creazione nome file BUS: stringa stringa ID Univoco nulla")

			Dim sbFileName As New StringBuilder
			sbFileName.Append("BUS_MGP_")
			sbFileName.Append(dataProgrammaFormattata)
			sbFileName.Append("_")
			sbFileName.Append(id14Caratteri)
			sbFileName.Append(".out.xml")
			Return sbFileName.ToString()
		End Function
		Private Function GetCompanyNameFromCodiceOperatoreSDC(ByVal CodiceOperatoreSDC As String) As String
			' Parametri in input non concessi
			If CodiceOperatoreSDC Is Nothing Then Throw New ArgumentException("Errore stringa CodiceOperatore uguale a Nothing")
			If CodiceOperatoreSDC = String.Empty Then Throw New ArgumentException("Errore stringa CodiceOperatore vuota")

			Dim blOperatori As New Bil.Operatore
			Dim dsOp As DS_Operatori

			' Recupero le informazioni caratteristiche dell'operatore
			dsOp = blOperatori.GetListaOperatori(CodiceOperatoreSDC, Nothing)
			If Not (dsOp Is Nothing) Then
				' Deve essere presente SOLO una riga.....
				If (dsOp.Operatori.Rows.Count <= 0) Then
					Dim strErrMsg As String = "Errore CodiceOperatoreSDC=""" & CodiceOperatoreSDC & """ non presente nella tabella Operatori"
					Throw New ApplicationException(strErrMsg)
				Else
					' Assumo che ci sia una riga sola....o cmq prendo la prima
					Dim dr As DS_Operatori.OperatoriRow = DirectCast(dsOp.Operatori.Rows(0), DS_Operatori.OperatoriRow)
					Return dr.RagioneSociale
				End If
			Else
				Dim strErrMsg As String = "Errore recupero DataSet Operatori per CodiceOperatoreSDC=""" & CodiceOperatoreSDC & """"
				Throw New ApplicationException(strErrMsg)
			End If

			Return String.Empty
		End Function

		Private Sub BuildHastTableQuantity()
			Dim currentIdUnita As String
			Dim oldIdUnita As String
			Dim sl As SortedList = Nothing

			Debug.Assert(Not htQuantity Is Nothing)
			If (Me.htQuantity Is Nothing) Then
				Throw New ApplicationException("Errore Hashtable Quantita uguale a Nothing")
			End If

			For Each drQty As DS_BUSQuantity.BusQuantityRow In Me.dsQty.BusQuantity
				currentIdUnita = drQty.CodiceUnitaSDC
				If (currentIdUnita <> oldIdUnita) Then
					oldIdUnita = currentIdUnita
					sl = New SortedList
					sl.Add(drQty.PeriodoRilevante, drQty.QtyMWhAssegnataMGP)
					Me.htQuantity.Add(currentIdUnita, sl)
				Else
					sl.Add(drQty.PeriodoRilevante, drQty.QtyMWhAssegnataMGP)
				End If
			Next

			' STR108
			' se esiste almeno un ora per una unita` allora il bus deve avere 24 righe per quella unita
			Dim hhh As Integer = BilBLBase.GetNumberOfHourOfDay(Me.dataFlusso)

			For Each en As DictionaryEntry In Me.htQuantity
				Dim ss As SortedList = DirectCast(en.Value, SortedList)

				Dim d As Double = 0
				For h As Byte = 1 To CType(hhh, Byte)
					If Not ss.Contains(h) Then ss.Add(h, d)
				Next
			Next
			' end STR108
		End Sub

		'Private Sub WriteQuantityElement(ByVal tw As XmlTextWriter, ByVal Hour As Integer, ByVal Quantity As Double)
		'	' Controllo parametri
		'	Debug.Assert(Not tw Is Nothing)
		'	If (tw Is Nothing) Then Throw New ArgumentException("Errore oggetto XmlTextWriter uguale a Nothing")

		'	' ================== TAG Quantity ==============
		'	tw.WriteStartElement("Quantity")
		'	tw.WriteAttributeString("Hour", Hour.ToString())
		'	tw.WriteAttributeString("UnitOfMeasure", QUANTITY_UNITA_MISURA)
		'	tw.WriteString(Quantity.ToString(New CultureInfo("it-IT")))
		'	tw.WriteEndElement()
		'End Sub

		Private Sub WriteSiglePIPTransactionBUS(ByVal tw As XmlTextWriter, ByVal IdUnita As String, ByVal categoriaUnita As String)
			Dim strErrMsg As String

			' Controllo parametri
			Debug.Assert(Not tw Is Nothing)
			If (tw Is Nothing) Then Throw New ArgumentException("Errore oggetto XmlTextWriter uguale a Nothing")

			Debug.Assert(Not Me.dsUnita Is Nothing)
			If (Me.dsUnita Is Nothing) Then
				Throw New ApplicationException("Errore DataSet Unita uguale a Nothing")
			End If

			Debug.Assert(Not IdUnita Is Nothing AndAlso IdUnita <> String.Empty)
			If (IdUnita Is Nothing) OrElse (IdUnita = String.Empty) Then
				Throw New ArgumentException("Errore stringa IdUnita uguale a Nothing o nullo")
			End If

			Debug.Assert(Not Me.htQuantity Is Nothing)
			If (Me.htQuantity Is Nothing) Then
				Throw New ArgumentException("Errore Hash Table Quantita' uguale a Nothing")
			End If

			' ====================== Reference Number ===================================
			Dim referenceNumber As String = NewId30.Generate()
			' ====================== Orta creazione formattata (hhmmssccc)
			' L'ora di creazione e' la stessa per tutte le PIPTransaction
			'Dim oraCreazione As String = GetOraCreazioneFormattata(DateTime.Now())

			' Recupero la riga (dovrebbe essere una sola) del DataSet....per ora uso solo il
			' CodiceUnitaSDC e non la CategoriaUnita
			Dim selectFilterUnita As String = "CodiceUnitaSDC='" & IdUnita & "'"
			Dim adrUnita() As DataRow = Me.dsUnita.Unita.Select(selectFilterUnita)

			strErrMsg = "Errore recupero dati DataSet Unita per CodiceUnitaSDC=""" & IdUnita & """"
			Debug.Assert(Not adrUnita Is Nothing, strErrMsg)
			If adrUnita Is Nothing Then
				Throw New ApplicationException(strErrMsg)
			End If

			strErrMsg = "Errore CodiceUnitaSDC=""" & IdUnita & """ non presente nella tabella Unita"
			Debug.Assert(Not adrUnita.Length = 0, strErrMsg)
			If (adrUnita.Length = 0) Then
				Throw New ApplicationException(strErrMsg)
			End If

			' Cast al DataRow tipato
			Dim drUnita As DS_Unita.UnitaRow = DirectCast(adrUnita(0), DS_Unita.UnitaRow)

			' ====================== TAG PIPTransaction ===================
			tw.WriteStartElement("PIPTransaction")
			tw.WriteAttributeString("ReferenceNumber", referenceNumber)
			tw.WriteAttributeString("InboundMessageCreationDate", Me.dataCreazioneYYYYMMdd)
			tw.WriteAttributeString("InboundMessageCreationTime", Me.oraCreazioneHHMMSSmmm)
			If (True) Then

				' ====================== TAG BilateralUnitSchedule ===================
				tw.WriteStartElement("BilateralUnitSchedule")

				If Me.isPreliminaryProvisional Then
					tw.WriteAttributeString("Type", "PreliminaryProvisional")
				Else
					tw.WriteAttributeString("Type", "Preliminary")
				End If
				tw.WriteAttributeString("Cummulative", BILATERALI_UNIT_SCHEDULE_CUMMULATIVE)
				tw.WriteAttributeString("MarketParticipantNumber", Me.codOp)
				If (True) Then

					' ====================== TAG Market ===================
					tw.WriteStartElement("Market")
					tw.WriteString(BILATERALI_UNIT_SCHEDULE_MARKET)
					tw.WriteEndElement()

					' ====================== TAG Date ===================
					tw.WriteStartElement("Date")
					tw.WriteString(Me.dataProg)
					tw.WriteEndElement()

					' ====================== TAG UnitReferenceNumber ===================
					tw.WriteStartElement("UnitReferenceNumber")
					tw.WriteString(IdUnita)
					tw.WriteEndElement()

					' ====================== TAG ReferenceMarketParticipantNumber ==============
					tw.WriteStartElement("ReferenceMarketParticipantNumber")
					tw.WriteString(drUnita.CodiceOperatoreDiRiferimentoSDC)
					tw.WriteEndElement()


					' ====================== TAG UnbalancedMarketParticipantNumber ==============
					tw.WriteStartElement("UnbalancedMarketParticipantNumber")
					tw.WriteString(drUnita.UnbalancedParticipantNumber)
					tw.WriteEndElement()

					' Lista quantita' per periodo rilevante
					Dim sl As SortedList = DirectCast(htQuantity.Item(IdUnita), SortedList)
					strErrMsg = "Errore SortedList uguale a Nothing per CodiceUnitaSDC=""" & IdUnita & """"
					Debug.Assert(Not sl Is Nothing, strErrMsg)
					If Not (sl Is Nothing) Then
						For Each hour As Byte In sl.Keys()
							' ================== TAG Quantity ==============
							tw.WriteStartElement("Quantity")
							tw.WriteAttributeString("Hour", hour.ToString())
							tw.WriteAttributeString("UnitOfMeasure", QUANTITY_UNITA_MISURA)
							Dim qty As Double = DirectCast(sl.Item(hour), Double)
							qty = Math.Round(qty, 3)
							tw.WriteString(qty.ToString(New CultureInfo("it-IT")))
							tw.WriteEndElement()
						Next
					Else
						Throw New ApplicationException(strErrMsg)
					End If
				End If
				tw.WriteEndElement()
				' ====================== END TAG BilateralUnitSchedule ===================

			End If
			tw.WriteEndElement()
			' ====================== END TAG PIPTransaction ===================

		End Sub

		' ==================== PROPRIETA' ================================
		Public Property XMLSenderInfo() As XMLSenderData
			Get
				Return Me.senderInfo
			End Get
			Set(ByVal Value As XMLSenderData)
				Me.senderInfo = Value
			End Set
		End Property

		Public Property Connection() As SqlClient.SqlConnection
			Get
				Return Me.cn
			End Get
			Set(ByVal Value As SqlClient.SqlConnection)
				Me.cn = Value
			End Set
		End Property

		' ==================== FUNZIONI PUBBLICHE ==========================
		Public Function GenerateXmlBUS() As Boolean
			Dim e As System.Text.Encoding
			Dim ms As New MemoryStream
			Dim tw As New XmlTextWriter(ms, e.UTF8)

			Try
				' Verifica dei dati prima di generare il file XML
				'========= DataSet Quantita' =================
				Debug.Assert(Not Me.dsQty Is Nothing)
				If Me.dsQty Is Nothing Then
					Throw New ApplicationException("Errore DataSet Quantita' Nothing")
				End If

				'======== Verifico il numero di elementi nel DataSet delle Quantita'
				Debug.Assert(Me.dsQty.BusQuantity.Rows.Count > 0, "DataSet delle Quantita' vuoto")
				If (Me.dsQty.BusQuantity.Rows.Count <= 0) Then
					Throw New ApplicationException("Errore DataSet quantita' vuoto")
				End If

				'========= Data Programma ===================
				Debug.Assert(Not Me.dataProg Is Nothing AndAlso Me.dataProg <> String.Empty)
				If (Me.dataProg Is Nothing OrElse Me.dataProg = String.Empty) Then
					Throw New ApplicationException("Errore DataProgramma Nothing o vuota")
				End If

				' ======= HastTable dati Unita ==============
				Debug.Assert(Not Me.htQuantity Is Nothing)
				If (Me.htQuantity Is Nothing) Then
					Throw New ApplicationException("Errore Hast Table dati Unita uguale a Nothing")
				End If

				' ======= Costruisco l'Hash Table delle Quantita' per periodo rilevante e per Unita
				BuildHastTableQuantity()

				'========= Recipient CompanyName =============
				Dim recipentCompanyName As String
				Try
					recipentCompanyName = GetCompanyNameFromCodiceOperatoreSDC(Me.codOp)
					Debug.Assert(Not recipentCompanyName Is Nothing AndAlso recipentCompanyName <> String.Empty)
				Catch ex As Exception
					SmLog.smError(ex.Message)
					Return False
				End Try

				' ================= Ora di creazione XML File BUS ============================
				Me.oraCreazioneHHMMSSmmm = GetOraCreazioneFormattataHHMMSSmmm(DateTime.Now())

				tw.Formatting = Formatting.Indented
				tw.IndentChar = "	"c				' e` un tab
				tw.Indentation = 1
				tw.WriteStartDocument()

				Dim CreationDateTimeYYYYMMDDHHMMSS As String = String.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now)

				'==================== INIZIO FILE XML BUS ===================================
				tw.WriteStartElement("PIPEDocument")

				If (True) Then
					Dim idGenerato As String = NewId30.Generate()
					tw.WriteAttributeString("xmlns", "urn:XML-PIPE")
					tw.WriteAttributeString("xmlns", "xsi", Nothing, "http://www.w3.org/2001/XMLSchema-instance")
					tw.WriteAttributeString("xsi", "schemaLocation", Nothing, "urn:XML-PIPE PIPEDocument.xsd")
					tw.WriteAttributeString("ReferenceNumber", idGenerato)					 'generato a caso (35char)
					tw.WriteAttributeString("CreationDate", CreationDateTimeYYYYMMDDHHMMSS)					 'YYYMMDDhhmmss
					tw.WriteAttributeString("Version", "1.0")


					' ====================== TAG TradingPartnerDirectory ===================
					tw.WriteStartElement("TradingPartnerDirectory")
					If (True) Then

						'=================== TAG Sender ====================================
						tw.WriteStartElement("Sender")
						If (True) Then

							'=================== TAG TradingPartner ====================================
							tw.WriteStartElement("TradingPartner")
							tw.WriteAttributeString("PartnerType", Me.XMLSenderInfo.TradingPartnerType)
							If True Then
								tw.WriteStartElement("CompanyName")
								tw.WriteString(Me.XMLSenderInfo.CompanyName)
								tw.WriteEndElement()

								tw.WriteStartElement("CompanyIdentifier")
								tw.WriteString(Me.XMLSenderInfo.CompanyIdentifier)
								tw.WriteEndElement()

							End If
							tw.WriteEndElement()

						End If
						tw.WriteEndElement()
						'=================== END TAG Sender ====================================

						'================== TAG Recipient ==================================
						tw.WriteStartElement("Recipient")
						If (True) Then
							'=================== TAG TradingPartner ====================================
							tw.WriteStartElement("TradingPartner")
							tw.WriteAttributeString("PartnerType", RECIPIENT_PARTNER_TYPE)
							If True Then
								tw.WriteStartElement("CompanyName")
								tw.WriteString(recipentCompanyName)
								tw.WriteEndElement()

								tw.WriteStartElement("CompanyIdentifier")
								tw.WriteString(Me.codOp)
								tw.WriteEndElement()

							End If
							tw.WriteEndElement()
							'=================== END TAG TradingPartner ====================================

						End If
						tw.WriteEndElement()
						'================== END TAG Recipient ==================================

					End If
					tw.WriteEndElement()
					'======================= END TAG TradingPartnerDirectory ===============

					'======================= Inizio ciclo PIPTransaction ===================
					For Each idUnitaKey As String In htQuantity.Keys()
						WriteSiglePIPTransactionBUS(tw, idUnitaKey, Nothing)
					Next

				End If

				tw.WriteEndDocument()
				tw.Flush()

				'================== FILE XML CREATO ==================================

				Dim busXmlFileName As String = GetXmlBusFileName(Me.dataProg, NewId14.Generate())
				Try
					BilBLBase.MemorizzaFilePerOperatore(Nothing, Nothing, Me.codOp, busXmlFileName, "BUS", "Risultati MGP", ms.ToArray(), DateTime.Now, "utf-8", Me.dataFlusso)
				Catch ex As Exception
					SmLog.smError(ex)
				End Try

				Return True
			Catch ex As Exception
				SmLog.smError(ex)
				Return False
			Finally
				tw.Close()
			End Try
		End Function

	End Class

#End Region

End Class
