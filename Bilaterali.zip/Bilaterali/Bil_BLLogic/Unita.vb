Imports System.Text
Imports System.Data.SqlClient

Public Class Unita
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents _sqlSelectStarUnita As System.Data.SqlClient.SqlCommand
    Friend WithEvents _daUnita As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _dsUnita As Bil.DS_Unita
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me._sqlSelectStarUnita = New System.Data.SqlClient.SqlCommand
        Me._daUnita = New System.Data.SqlClient.SqlDataAdapter
        Me._dsUnita = New Bil.DS_Unita
        CType(Me._dsUnita, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
        "rsist security info=False;initial catalog=Bilaterali;password=bilaterali;"
        '
        '_sqlSelectStarUnita
        '
        Me._sqlSelectStarUnita.CommandText = "SELECT dbo.Bil_Unita.* FROM dbo.Bil_Unita"
        Me._sqlSelectStarUnita.Connection = Me._cn
        '
        '_daUnita
        '
        Me._daUnita.SelectCommand = Me._sqlSelectStarUnita
        '
        '_dsUnita
        '
        Me._dsUnita.DataSetName = "DS_Unita"
        Me._dsUnita.Locale = New System.Globalization.CultureInfo("it-IT")
        CType(Me._dsUnita, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region

    Public Function GetUnita() As DS_Unita
        Dim ds As New DS_Unita
        _cn.ConnectionString = GetConnectionString()
        Try
            _cn.Open()
            _daUnita.Fill(ds.Unita)
            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try

    End Function
End Class
