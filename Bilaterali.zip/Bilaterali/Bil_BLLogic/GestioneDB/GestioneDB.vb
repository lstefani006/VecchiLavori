Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema

Public Class GestioneDB
    Inherits BilBLBase

	'   Private Sub DeleteFileOperatori(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime)

	'       Dim cmdSql As New SqlClient.SqlCommand

	'       Dim cmdDelete As String

	'       cmdDelete = "DELETE FROM dbo.FileOperatori "
	'       cmdDelete = cmdDelete + " WHERE (TSCreazione <= @data) "

	'       cmdSql.CommandText = cmdDelete
	'       cmdSql.CommandTimeout = 1200
	'       cmdSql.Connection = cn
	'       cmdSql.Transaction = tr

	'       cmdSql.Parameters.Clear()
	'       cmdSql.Parameters.Add("@data", data)

	'       cmdSql.ExecuteNonQuery()

	'   End Sub

	'   Private Sub DeleteUnitaContratto(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime)

	'       Dim cmdSql As New SqlClient.SqlCommand

	'       Dim cmdDelete As String

	'       cmdDelete = "DELETE FROM dbo.UnitaContratto "
	'       cmdDelete = cmdDelete + " WHERE (DataFineValidita <= @data) "

	'       cmdSql.CommandText = cmdDelete
	'       cmdSql.CommandTimeout = 1200
	'       cmdSql.Connection = cn
	'       cmdSql.Transaction = tr

	'       cmdSql.Parameters.Clear()
	'       cmdSql.Parameters.Add("@data", data)

	'       cmdSql.ExecuteNonQuery()

	'   End Sub

	'   Private Sub DeleteContratto(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime)

	'       Dim cmdSql As New SqlClient.SqlCommand

	'       Dim cmdDelete As String

	'       cmdDelete = "DELETE FROM dbo.Contratto "
	'       cmdDelete = cmdDelete + " WHERE (DataFineValidita <= @data) "

	'       cmdSql.CommandText = cmdDelete
	'       cmdSql.CommandTimeout = 1200
	'       cmdSql.Connection = cn
	'       cmdSql.Transaction = tr

	'       cmdSql.Parameters.Clear()
	'       cmdSql.Parameters.Add("@data", data)

	'       cmdSql.ExecuteNonQuery()

	'   End Sub

	'   Private Sub DeletePrezzoZonale(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime)

	'       Dim cmdSql As New SqlClient.SqlCommand

	'       Dim cmdDelete As String

	'       cmdDelete = "DELETE FROM dbo.PrezzoZonale "
	'       cmdDelete = cmdDelete + " WHERE (Data <= @data) "

	'       cmdSql.CommandText = cmdDelete
	'       cmdSql.CommandTimeout = 1200
	'       cmdSql.Connection = cn
	'       cmdSql.Transaction = tr

	'       cmdSql.Parameters.Clear()
	'       cmdSql.Parameters.Add("@data", data)

	'       cmdSql.ExecuteNonQuery()

	'   End Sub

	'   Private Sub DeletePrezzoUnitario(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime)

	'       Dim cmdSql As New SqlClient.SqlCommand

	'       Dim cmdDelete As String

	'       cmdDelete = "DELETE FROM dbo.PrezzoUnitario "
	'       cmdDelete = cmdDelete + " WHERE (Data <= @data) "

	'       cmdSql.CommandText = cmdDelete
	'       cmdSql.CommandTimeout = 1200
	'       cmdSql.Connection = cn
	'       cmdSql.Transaction = tr

	'       cmdSql.Parameters.Clear()
	'       cmdSql.Parameters.Add("@data", data)

	'       cmdSql.ExecuteNonQuery()

	'   End Sub

	'   Private Sub DeleteProgrammaOrario(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime)

	'       Dim cmdSql As New SqlClient.SqlCommand

	'       Dim cmdDelete As String

	'       cmdDelete = "DELETE FROM dbo.ProgrammaOrario "
	'       cmdDelete = cmdDelete + " WHERE (DataProgramma <= @data) "

	'       cmdSql.CommandText = cmdDelete
	'       cmdSql.CommandTimeout = 1200
	'       cmdSql.Connection = cn
	'       cmdSql.Transaction = tr

	'       cmdSql.Parameters.Clear()
	'       cmdSql.Parameters.Add("@data", data)

	'       cmdSql.ExecuteNonQuery()

	'   End Sub

	'   Private Sub DeleteProgrammaOrarioPerUnita(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime)

	'       Dim cmdSql As New SqlClient.SqlCommand

	'       Dim cmdDelete As String

	'       cmdDelete = "DELETE FROM dbo.ProgrammaOrarioPerUnita "
	'       cmdDelete = cmdDelete + " WHERE (DataProgramma <= @data) "

	'       cmdSql.CommandText = cmdDelete
	'       cmdSql.CommandTimeout = 1200
	'       cmdSql.Connection = cn
	'       cmdSql.Transaction = tr

	'       cmdSql.Parameters.Clear()
	'       cmdSql.Parameters.Add("@data", data)

	'       cmdSql.ExecuteNonQuery()

	'   End Sub

	'   Private Sub DeleteXmlProgrammiUtenti(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime)

	'       Dim cmdSql As New SqlClient.SqlCommand

	'       Dim cmdDelete As String

	'       cmdDelete = "DELETE FROM dbo.XmlProgrammiUtenti "
	'       cmdDelete = cmdDelete + " WHERE (TSInvio <= @data) "

	'       cmdSql.CommandText = cmdDelete
	'       cmdSql.CommandTimeout = 1200
	'       cmdSql.Connection = cn
	'       cmdSql.Transaction = tr

	'       cmdSql.Parameters.Clear()
	'       cmdSql.Parameters.Add("@data", data)

	'       cmdSql.ExecuteNonQuery()

	'   End Sub

	'Private Sub DeleteErroriProgrammiUtenti(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal idProgrammaXml As Integer)

	'	Dim cmdSql As New SqlClient.SqlCommand

	'	Dim cmdDelete As String

	'	cmdDelete = "DELETE FROM dbo.ErroriProgrammiUtenti "
	'	cmdDelete = cmdDelete + " WHERE (IdProgrammaXml = @IdProgrammaXml) "

	'	cmdSql.CommandText = cmdDelete
	'	cmdSql.CommandTimeout = 1200
	'	cmdSql.Connection = cn
	'	cmdSql.Transaction = tr

	'	cmdSql.Parameters.Clear()
	'	cmdSql.Parameters.Add("@IdProgrammaXml", idProgrammaXml)

	'	cmdSql.ExecuteNonQuery()

	'End Sub

	'Private Sub DeleteErroriPIPTransactionUtenti(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal idProgrammaXml As Integer)

	'	Dim cmdSql As New SqlClient.SqlCommand

	'	Dim cmdDelete As String

	'	cmdDelete = "DELETE FROM dbo.ErroriPIPTransactionUtenti "
	'	cmdDelete = cmdDelete + " WHERE (IdProgrammaXml = @IdProgrammaXml) "

	'	cmdSql.CommandText = cmdDelete
	'	cmdSql.CommandTimeout = 1200
	'	cmdSql.Connection = cn
	'	cmdSql.Transaction = tr

	'	cmdSql.Parameters.Clear()
	'	cmdSql.Parameters.Add("@IdProgrammaXml", idProgrammaXml)

	'	cmdSql.ExecuteNonQuery()

	'End Sub

	'Private Function GetListaIdProgrammiXml(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal data As DateTime) As ArrayList
	'	Dim list As New ArrayList(0)

	'	Dim cmdSql As New SqlClient.SqlCommand

	'	Dim cmdSelect As String

	'	cmdSelect = "SELECT IdProgrammaXml FROM dbo.XmlProgrammiUtenti "
	'	cmdSelect = cmdSelect + " WHERE (TSInvio <= @data) "

	'	cmdSql.CommandText = cmdSelect
	'	cmdSql.CommandTimeout = 1200
	'	cmdSql.Connection = cn
	'	cmdSql.Transaction = tr

	'	cmdSql.Parameters.Clear()
	'	cmdSql.Parameters.Add("@data", data)

	'	Dim dr As SqlDataReader
	'	Try
	'		dr = cmdSql.ExecuteReader()
	'		Dim colIdProgrammaXml As Integer = dr.GetOrdinal("IdProgrammaXml")

	'		While (dr.Read())
	'			list.Add(dr.GetInt32(colIdProgrammaXml))
	'		End While

	'	Finally
	'		If (Not dr Is Nothing) Then
	'			dr.Close()
	'		End If
	'	End Try


	'	Return list

	'End Function
	'Public Sub PulisciDB(ByVal dataProgramma As DateTime, ByVal dataContratto As DateTime)

	'	Dim cn As New SqlConnection
	'	Dim tr As SqlTransaction = Nothing
	'	Dim listProgrammiXml As ArrayList
	'	Dim i As Integer

	'	Try
	'		' Apro la connessione al DB
	'		cn.ConnectionString = GetConnectionString()
	'		cn.Open()
	'		tr = cn.BeginTransaction()

	'		listProgrammiXml = GetListaIdProgrammiXml(cn, tr, dataProgramma)

	'		DeleteUnitaContratto(cn, tr, dataContratto)

	'		DeleteContratto(cn, tr, dataContratto)

	'		DeletePrezzoUnitario(cn, tr, dataProgramma)

	'		DeletePrezzoZonale(cn, tr, dataProgramma)

	'		DeleteProgrammaOrarioPerUnita(cn, tr, dataProgramma)

	'		DeleteProgrammaOrario(cn, tr, dataProgramma)

	'		For i = 0 To listProgrammiXml.Count - 1
	'			Dim id As Integer = CType(listProgrammiXml(i), Integer)
	'			DeleteErroriProgrammiUtenti(cn, tr, id)
	'			DeleteErroriPIPTransactionUtenti(cn, tr, id)
	'		Next

	'		DeleteXmlProgrammiUtenti(cn, tr, dataProgramma)

	'		DeleteFileOperatori(cn, tr, dataProgramma)

	'		tr.Commit()

	'	Catch ex As Exception
	'		smError(ex)
	'		If (Not tr Is Nothing) Then tr.Rollback()
	'		Throw ex
	'	Finally
	'		cn.Close()
	'	End Try

	'End Sub

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		components = New System.ComponentModel.Container
	End Sub

#End Region

End Class
