Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema

Public Class ImportOperatori
	Inherits BilBLBase
    '"IMP_OPERATORI", "Import Operatori", 

    Public Function InserisciOperatoriAsync(ByVal oby As Bil.FileStore.InfoEvento, ByVal runningOperator As String) As String
        BatchSerializer.BS.AddBatch(AddressOf ImportOperatori.ElaboraAsyncImportOperatori, oby, oby.CodiceTipoFile, oby.DescrizioneFile, DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Public Function AllineaAnagraficaAsync(ByVal runningOperator As String) As String
        BatchSerializer.BS.AddBatch(AddressOf ImportOperatori.ElaboraAsyncAllineaOperatori, Nothing, "ALLGN_OPERATORI", "Allineamento Operatori", DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Private Shared Sub ElaboraAsyncImportOperatori(ByVal o As Object)

        Dim blInfoEvt As Bil.FileStore.InfoEvento = DirectCast(o, Bil.FileStore.InfoEvento)

        Dim bl As New ImportOperatori

        Dim r As String = bl.InserisciOperatori(blInfoEvt)

        If r <> "OK" Then
            BatchSerializer.BS.SetProgressBatch(r)
            SystemMonitor.SmLog.smError("Import operatori: eleaborazione terminata con errore: " + r)
        Else
            BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")
            SystemMonitor.SmLog.smTrace("Import operatori: eleaborazione terminata con successo")
        End If

        bl.Dispose()


    End Sub

    Private Shared Sub ElaboraAsyncAllineaOperatori(ByVal o As Object)
        SystemMonitor.SmLog.smTrace("Allinea operatori: attivita` iniziata")

        Dim bl As New ImportOperatori
        Dim r As String = bl.CopiaSDC_Operatori()

        If r <> "OK" Then
            BatchSerializer.BS.SetProgressBatch(r)
            SystemMonitor.SmLog.smTrace("Allinea operatori: eleaborazione terminata con errore: " + r)
        Else
            BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")
            SystemMonitor.SmLog.smTrace("Allinea operatori: eleaborazione terminata con successo")
        End If

        bl.Dispose()
    End Sub

    Private Function dbv(ByVal s As String) As Object
        If s Is Nothing Then Return ""
        Return s
    End Function


    Private Sub InsertInSDC_Operatori(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal CodiceOperatoreSDC As String, ByVal RagioneSociale As String, ByVal Indirizzo1 As String, ByVal Indirizzo2 As String, ByVal Citta As String, ByVal Nazione As String, ByVal CodiceFiscale As String, ByVal PartitaIva As String, ByVal Fax As String, ByVal Email As String, ByVal ReferenteAmministrativo As String, ByVal SedeAmministrativa As String, ByVal Abilitato As Boolean, ByVal ResponsabileAggiornamento As String)

        Dim cmdSql As New SqlClient.SqlCommand

        Dim cmdUpdate, cmdInsert As String

        cmdUpdate = "UPDATE SDC_Operatori SET "
        cmdUpdate = cmdUpdate + " RagioneSociale = @RagioneSociale, Indirizzo1 = @Indirizzo1, Indirizzo2 = @Indirizzo2, Citta = @Citta, Nazione = @Nazione, "
        cmdUpdate = cmdUpdate + " CodiceFiscale = @CodiceFiscale, PartitaIva = @PartitaIva, Fax = @Fax, Email = @Email, "
        cmdUpdate = cmdUpdate + " ReferenteAmministrativo = @ReferenteAmministrativo, SedeAmministrativa = @SedeAmministrativa, "
        cmdUpdate = cmdUpdate + " Abilitato = @Abilitato, TSModifica = @TSModifica, ResponsabileAggiornamento = @ResponsabileAggiornamento "
        cmdUpdate = cmdUpdate + " WHERE "
        cmdUpdate = cmdUpdate + " (CodiceOperatoreSDC = @CodiceOperatoreSDC) "

        cmdInsert = "INSERT INTO SDC_Operatori "
        cmdInsert = cmdInsert + " (CodiceOperatoreSDC, RagioneSociale, Indirizzo1, Indirizzo2, Citta, Nazione, "
        cmdInsert = cmdInsert + " CodiceFiscale, PartitaIva, Fax, Email, ReferenteAmministrativo, SedeAmministrativa, "
        cmdInsert = cmdInsert + " Abilitato, TSModifica, ResponsabileAggiornamento) "
        cmdInsert = cmdInsert + " VALUES "
        cmdInsert = cmdInsert + " (@CodiceOperatoreSDC, @RagioneSociale, @Indirizzo1, @Indirizzo2, @Citta, @Nazione, "
        cmdInsert = cmdInsert + " @CodiceFiscale, @PartitaIva, @Fax, @Email, @ReferenteAmministrativo, @SedeAmministrativa, "
        cmdInsert = cmdInsert + " @Abilitato, @TSModifica, @ResponsabileAggiornamento) "

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@CodiceOperatoreSDC", CodiceOperatoreSDC.ToUpper)
        cmdSql.Parameters.Add("@RagioneSociale", RagioneSociale)
        cmdSql.Parameters.Add("@Indirizzo1", dbv(Indirizzo1))
        cmdSql.Parameters.Add("@Indirizzo2", dbv(Indirizzo2))
        cmdSql.Parameters.Add("@Citta", dbv(Citta))
        cmdSql.Parameters.Add("@Nazione", dbv(Nazione))
        cmdSql.Parameters.Add("@CodiceFiscale", dbv(CodiceFiscale))
        cmdSql.Parameters.Add("@PartitaIva", dbv(PartitaIva))
        cmdSql.Parameters.Add("@Fax", dbv(Fax))
        cmdSql.Parameters.Add("@Email", dbv(Email))
        cmdSql.Parameters.Add("@ReferenteAmministrativo", dbv(ReferenteAmministrativo))
        cmdSql.Parameters.Add("@SedeAmministrativa", dbv(SedeAmministrativa))
        cmdSql.Parameters.Add("@Abilitato", Abilitato)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)
        cmdSql.Parameters.Add("@ResponsabileAggiornamento", dbv(ResponsabileAggiornamento))

        Dim esiste As Boolean = False
        Try
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            If ex.Message.ToUpper.IndexOf("SDC_OPERATORI_PK") >= 0 Then
                ' Se la riga esiste => faccio un update
                esiste = True
            Else
                ' se ha fallito per qualunque altro motivo => lancio l'eccezione
                Throw
            End If
        End Try

        If esiste = True Then
            cmdSql.CommandText = cmdUpdate

            cmdSql.Parameters.Clear()
            cmdSql.Parameters.Add("@CodiceOperatoreSDC", CodiceOperatoreSDC.ToUpper())
            cmdSql.Parameters.Add("@RagioneSociale", RagioneSociale)
            cmdSql.Parameters.Add("@Indirizzo1", dbv(Indirizzo1))
            cmdSql.Parameters.Add("@Indirizzo2", dbv(Indirizzo2))
            cmdSql.Parameters.Add("@Citta", dbv(Citta))
            cmdSql.Parameters.Add("@Nazione", dbv(Nazione))
            cmdSql.Parameters.Add("@CodiceFiscale", dbv(CodiceFiscale))
            cmdSql.Parameters.Add("@PartitaIva", dbv(PartitaIva))
            cmdSql.Parameters.Add("@Fax", dbv(Fax))
            cmdSql.Parameters.Add("@Email", dbv(Email))
            cmdSql.Parameters.Add("@ReferenteAmministrativo", dbv(ReferenteAmministrativo))
            cmdSql.Parameters.Add("@SedeAmministrativa", dbv(SedeAmministrativa))
            cmdSql.Parameters.Add("@Abilitato", Abilitato)
            cmdSql.Parameters.Add("@TSModifica", TimeStamp)
            cmdSql.Parameters.Add("@ResponsabileAggiornamento", dbv(ResponsabileAggiornamento))

            Dim numrow As Integer = cmdSql.ExecuteNonQuery()
            If numrow = 0 Then
                Throw New Exception("Fallito UPDATE su tabella SDC_Operatori.")
            End If
        End If

    End Sub



    'Public Function InserisciOperatori(ByVal by() As Byte) As String

    '	' Ritornera' "OK" se tutto e' andato bene altrimenti
    '	' il relativo messaggio di errore
    '	InserisciOperatori = "OK"

    '	Dim cn As New SqlConnection
    '	Dim tr As SqlTransaction = Nothing

    '	' Lettura dell'xml e inserimento dati sul DB
    '	Dim _doc As New XmlDocument

    '	Try
    '		Dim ms As New MemoryStream(by)
    '		_doc.Load(ms)

    '		'Dim nsm As New XmlNamespaceManager(_doc.NameTable)
    '		'nsm.AddNamespace("df", "urn:XML-PIPE")

    '		Dim root As XmlElement = _doc.DocumentElement
    '		'Dim nPIPTransaction As XmlNodeList = root.SelectNodes("df:PIPTransaction/df:RelevantExchangePoint", nsm)
    '		Dim nPIPTransaction As XmlNodeList = root.SelectNodes("Operatore")

    '		' Apro la connessione al DB
    '		cn.ConnectionString = GetConnectionString()
    '		cn.Open()
    '		tr = cn.BeginTransaction()

    '		Dim n As XmlNode
    '		For i As Integer = 0 To nPIPTransaction.Count - 1

    '			Dim CodiceOperatoreSDC, RagioneSociale, Indirizzo1, Indirizzo2, Citta, Nazione, CodiceFiscale, PartitaIva, Fax, Email, ReferenteAmministrativo, SedeAmministrativa, ResponsabileAggiornamento As String
    '			Dim Abilitato As Boolean


    '			'n = nPIPTransaction(i).SelectSingleNode("./df:CodiceOperatoreSDC", nsm)
    '			n = nPIPTransaction(i).SelectSingleNode("./CodiceOperatoreSDC")
    '			CodiceOperatoreSDC = n.InnerText

    '			n = nPIPTransaction(i).SelectSingleNode("./RagioneSociale")
    '			RagioneSociale = n.InnerText

    '			n = nPIPTransaction(i).SelectSingleNode("./Indirizzo1")
    '			If (Not n Is Nothing) Then
    '				Indirizzo1 = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./Indirizzo2")
    '			If (Not n Is Nothing) Then
    '				Indirizzo2 = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./Citta")
    '			If (Not n Is Nothing) Then
    '				Citta = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./Nazione")
    '			If (Not n Is Nothing) Then
    '				Nazione = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./CodiceFiscale")
    '			If (Not n Is Nothing) Then
    '				CodiceFiscale = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./PartitaIva")
    '			If (Not n Is Nothing) Then
    '				PartitaIva = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./Fax")
    '			If (Not n Is Nothing) Then
    '				Fax = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./Email")
    '			If (Not n Is Nothing) Then
    '				Email = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./ReferenteAmministrativo")
    '			If (Not n Is Nothing) Then
    '				ReferenteAmministrativo = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./SedeAmministrativa")
    '			If (Not n Is Nothing) Then
    '				SedeAmministrativa = n.InnerText
    '			End If

    '			n = nPIPTransaction(i).SelectSingleNode("./Abilitato")
    '			If (Not n Is Nothing) Then
    '				Abilitato = n.InnerText.ToUpper() = "TRUE"
    '			Else
    '				Abilitato = True
    '			End If

    '               ResponsabileAggiornamento = ""

    '			' Inserimento dati nella tabella SDC_PuntiDiScambioRilevanti
    '			InsertInSDC_Operatori(cn, tr, CodiceOperatoreSDC, RagioneSociale, Indirizzo1, Indirizzo2, Citta, Nazione, CodiceFiscale, PartitaIva, Fax, Email, ReferenteAmministrativo, SedeAmministrativa, Abilitato, ResponsabileAggiornamento)

    '		Next

    '		tr.Commit()

    '	Catch ex As Exception
    '		smError(ex)
    '		If (Not tr Is Nothing) Then tr.Rollback()
    '		Return ex.Message
    '	Finally
    '		cn.Close()
    '	End Try

    '   End Function

    Public Function InserisciOperatori(ByRef blInfoEvt As Bil.FileStore.InfoEvento) As String
        Dim blFS As Bil.FileStore
        Dim TSFile As DateTime
        Dim IdFile As Integer

        Try
            blFS = New Bil.FileStore
            blFS.InsertFile(blInfoEvt, TSFile, IdFile)
        Catch ex As Exception
            smError(ex, "Import Operatori")
            Throw
        End Try

        ' se sono qui ho messo il file nel DB e TSFile/IdFile sono valorizzati
        Try
            Dim xmlContent() As Byte = blInfoEvt.ContenutoFile

            SaveUploadFile("Operatori", xmlContent)

            ParseXML(xmlContent)

            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Import Operatori: terminato con successo")
            blFS = New Bil.FileStore
            blFS.UpdateFAFile(TSFile, IdFile, byFA)

            Return "OK"
        Catch ex As Exception
            smError(ex, "Import Operatori fallito con eccezione")

            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Import Operatori fallito con eccezione." + ex.Message)
            blFS = New Bil.FileStore
            blFS.UpdateFAFile(TSFile, IdFile, byFA)

            Return ex.Message
        End Try

        smError("Eseguito Import Operatori")
    End Function


    Private Sub InsertInOperatori(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal codiceOperatoreSDC As String)
        Dim cmdSql As New SqlClient.SqlCommand

        Dim cmdUpdate, cmdInsert As String

        cmdUpdate = "UPDATE Operatori SET "
        'cmdUpdate = cmdUpdate + " StatoBilateraliOperatore = @StatoBilateraliOperatore, TSModifica = @TSModifica "
        cmdUpdate = cmdUpdate + " TSModifica = @TSModifica "
        cmdUpdate = cmdUpdate + " WHERE "
        cmdUpdate = cmdUpdate + "(CodiceOperatoreSDC = @CodiceOperatoreSDC) "


        cmdInsert = "INSERT INTO Operatori "
        cmdInsert = cmdInsert + "(CodiceOperatoreSDC, StatoBilateraliOperatore, TSModifica) "
        cmdInsert = cmdInsert + " VALUES "
        cmdInsert = cmdInsert + "(@CodiceOperatoreSDC, @StatoBilateraliOperatore, @TSModifica) "

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@CodiceOperatoreSDC", codiceOperatoreSDC.ToUpper())
        cmdSql.Parameters.Add("@StatoBilateraliOperatore", True)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)

        Dim esiste As Boolean = False
        Try
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            If ex.Message.ToUpper.IndexOf("OPERATORI_PK") >= 0 Then
                ' Se la riga esiste => faccio un update
                esiste = True
            Else
                ' se ha fallito per qualunque altro motivo => lancio l'eccezione
                Throw
            End If
        End Try

        If esiste = True Then
            cmdSql.CommandText = cmdUpdate

            cmdSql.Parameters.Clear()
            cmdSql.Parameters.Add("@CodiceOperatoreSDC", codiceOperatoreSDC.ToUpper())
            'cmdSql.Parameters.Add("@StatoBilateraliOperatore", True)
            cmdSql.Parameters.Add("@TSModifica", TimeStamp)

            Dim numrow As Integer = cmdSql.ExecuteNonQuery()
            If numrow = 0 Then
                Throw New Exception("Fallito UPDATE su tabella Operatori.")
            End If
        End If

    End Sub

    Public Function CopiaSDC_Operatori() As String

        smTrace("Allineamento anagrafica operatori: inizio elaborazione")

        ' Ritornera' "OK" se tutto e' andato bene altrimenti
        ' il relativo messaggio di errore
        CopiaSDC_Operatori = "OK"

        Dim cn As New SqlConnection
        Dim tr As SqlTransaction = Nothing

        Try
            ' Apro la connessione al DB
            cn.ConnectionString = GetConnectionString()
            cn.Open()
            tr = cn.BeginTransaction()

            Dim dsSDCOperatori As DS_SDC_Op
            Dim cSDCOperatori As New DS_SDC_Operatori
            dsSDCOperatori = cSDCOperatori.GetSDC_Operatori()

            Dim i As Integer
            For i = 0 To dsSDCOperatori.SDC_Operatori.Count - 1
                InsertInOperatori(cn, tr, dsSDCOperatori.SDC_Operatori(i).CodiceOperatoreSDC)
            Next

            If Not tr Is Nothing Then tr.Commit() : tr = Nothing


            smTrace("Allineamento anagrafica operatori: elaborazione terminata con successo")

        Catch ex As Exception
            smError(ex, "Allineamento anagrafica operatori: esecuzione fallita")
            Return ex.Message
        Finally
            If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try

    End Function

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Private Sub ParseXML(ByVal xmlContent() As Byte)

        '======== Codice per validare l'xml con uno schema (per adesso non lo valido) 
        'Dim xr As XmlValidatingReader

        '=================== CONTROLLO SCHEMA PER IL FILE XML =============================================
        'Try
        '    Dim fileSchema As String = Nome File schema
        '    If fileSchema Is Nothing Then
        '        Thow New ApplicationException
        '    End If

        '    Dim sc As XmlSchemaCollection = New XmlSchemaCollection
        '    sc.Add(Nothing, fileSchema)

        '    Dim textReader As XmlTextReader = New XmlTextReader(New MemoryStream(Me._xmlContent))
        '    textReader.WhitespaceHandling = WhitespaceHandling.None
        '    xr = New XmlValidatingReader(textReader)
        '    xr.ValidationType = ValidationType.Schema
        '    xr.Schemas.Add(sc)
        '    ' Evento che gestisce gli errori di Validazione
        '    AddHandler xr.ValidationEventHandler, AddressOf Me.ValidationEvent

        'Catch ex As Exception
        '    Debug.Assert(False, "File schema non trovato")    ' se non trova il file degli schemi
        '    Throw ex
        'End Try

        Dim xr As New XmlTextReader(New MemoryStream(xmlContent))
        Dim cn As New SqlConnection
        Dim tr As SqlTransaction = Nothing
        Dim fileGiusto As Boolean    ' Varra' True se xmlContent e' un file relativo agli operatori


        smTrace("Import operatori: inizio elaborazione")


        fileGiusto = False
        Try
            ' Apro la connessione al DB
            cn.ConnectionString = GetConnectionString()
            cn.Open()
            tr = cn.BeginTransaction()


            Dim cultureInfoIT As New System.Globalization.CultureInfo("it-IT")      ' per leggere i double in italiano

            '======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
            Dim elOperatori As Object = xr.NameTable.Add("Operatori")
            Dim elOperatore As Object = xr.NameTable.Add("Operatore")
            Dim elCodiceOperatoreSDC As Object = xr.NameTable.Add("CodiceOperatoreSDC")
            Dim elRagioneSociale As Object = xr.NameTable.Add("RagioneSociale")
            Dim elIndirizzo1 As Object = xr.NameTable.Add("Indirizzo1")
            Dim elIndirizzo2 As Object = xr.NameTable.Add("Indirizzo2")
            Dim elCitta As Object = xr.NameTable.Add("Citta")
            Dim elNazione As Object = xr.NameTable.Add("Nazione")
            Dim elCodiceFiscale As Object = xr.NameTable.Add("CodiceFiscale")
            Dim elPartitaIVA As Object = xr.NameTable.Add("PartitaIVA")
            Dim elFax As Object = xr.NameTable.Add("Fax")
            Dim elEmail As Object = xr.NameTable.Add("Email")
            Dim elReferenteAmministrativo As Object = xr.NameTable.Add("ReferenteAmministrativo")
            Dim elSedeAmministrativa As Object = xr.NameTable.Add("SedeAmministrativa")
            Dim elAbilitato As Object = xr.NameTable.Add("Abilitato")
            Dim elTSModifica As Object = xr.NameTable.Add("TSModifica")
            Dim elResponsabileAggiornamento As Object = xr.NameTable.Add("ResponsabileAggiornamento")

            Dim currOperatore As Operatore = Nothing
            '============================== INIZIO PARSING DEL FILE XML =========================
            While (xr.Read())
                Dim xrn As Object = xr.Name

                Select Case xr.NodeType
                    Case XmlNodeType.Element
                        '================== OPERATORE ============================
                        If (xrn Is elOperatore) Then
                            currOperatore = New Operatore
                            fileGiusto = True

                            '================== CODICE OPERATORE SDC ============================
                        ElseIf (xrn Is elCodiceOperatoreSDC) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currOperatore.CodiceOperatoreSDC = xmlData
                            Else
                                Throw New ApplicationException("Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== RAGIONE SOCIALE ============================
                        ElseIf (xrn Is elRagioneSociale) Then
                            Dim xmlData As String = xr.ReadString()
                            'Dim cr As String = Chr(10)
                            'Dim lf As String = Chr(13)
                            Dim i, ca As Integer
                            Dim ch, sRagioneSociale As String
                            sRagioneSociale = ""
                            For i = 0 To xmldata.Length - 1
                                ch = xmldata.Substring(i, 1)
                                ca = Asc(ch)
                                If (ca <> 13) AndAlso (ca <> 10) Then
                                    sRagioneSociale += ch
                                End If
                                If (ca = 10) Then
                                    sRagioneSociale += " "
                                End If
                            Next

                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.RagioneSociale = sRagioneSociale

                            '================== INDIRIZZO 1 ============================
                        ElseIf (xrn Is elIndirizzo1) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.Indirizzo1 = xmlData

                            '================== INDIRIZZO 2 ============================
                        ElseIf (xrn Is elIndirizzo2) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.Indirizzo2 = xmlData

                            '================== CITTA` ============================
                        ElseIf (xrn Is elCitta) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.Citta = xmlData

                            '================== NAZIONE ============================
                        ElseIf (xrn Is elNazione) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.Nazione = xmlData

                            '================== CODICE FISCALE ============================
                        ElseIf (xrn Is elCodiceFiscale) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.CodiceFiscale = xmlData

                            '================== PARTITA IVA ============================
                        ElseIf (xrn Is elPartitaIVA) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.PartitaIVA = xmlData

                            '================== FAX ============================
                        ElseIf (xrn Is elFax) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.Fax = xmlData

                            '================== EMAIL ============================
                        ElseIf (xrn Is elEmail) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.Email = xmlData

                            '================== REFERENTE AMMINISTRATIVO ============================
                        ElseIf (xrn Is elReferenteAmministrativo) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.ReferenteAmministrativo = xmlData

                            '================== SEDE AMMINISTRATIVA ============================
                        ElseIf (xrn Is elSedeAmministrativa) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.SedeAmministrativa = xmlData

                            '================== ABILITATO ============================
                        ElseIf (xrn Is elAbilitato) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.Abilitato = Boolean.Parse(xmlData)

                            '================== TSMODIFICA ============================
                        ElseIf (xrn Is elTSModifica) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.TSModifica = Convert.ToDateTime(xmlData, cultureInfoIT)

                            '================== RESPONSABILE AGGIORNAMENTO ============================
                        ElseIf (xrn Is elResponsabileAggiornamento) Then
                            Dim xmlData As String = xr.ReadString()
                            'Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            currOperatore.ResponsabileAggiornamento = xmlData
                        End If

                    Case XmlNodeType.EndElement
                        '================== END TAG OPERATORE ============================
                        If (xrn Is elOperatore) Then
                            ' Inserisco i dati nel DB
                            SaveToDB(cn, tr, currOperatore)
                            ' Sono pronto per un nuovo inserimento
                            currOperatore = Nothing
                        End If
                End Select

            End While

            If fileGiusto = True Then
                If Not tr Is Nothing Then tr.Commit() : tr = Nothing

                smTrace("Import operatori: elaborazione terminata con successo")
            Else

                Throw New Exception("File errato: il file inviato non contiene informazione sugli operatori!")
            End If

        Catch ex As Exception
            smError(ex, "ImportOperatori.ParseXML")
            Throw

        Finally
            If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
            If Not (xr Is Nothing) Then xr.Close()
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Sub

    Private Sub SaveToDB(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal op As Operatore)
        Try
            InsertInSDC_Operatori(cn, _
               tr, _
               op.CodiceOperatoreSDC, _
               op.RagioneSociale, _
               op.Indirizzo1, _
               op.Indirizzo2, _
               op.Citta, _
               op.Nazione, _
               op.CodiceFiscale, _
               op.PartitaIVA, _
               op.Fax, _
               op.Email, _
               op.ReferenteAmministrativo, _
               op.SedeAmministrativa, _
               op.Abilitato, _
               op.ResponsabileAggiornamento)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Class Operatore
        '===================== VARIABILI PRIVATE ===============================
        Private _codiceOperatoreSDC As String
        Private _ragioneSociale As String
        Private _indirizzo1 As String
        Private _indirizzo2 As String
        Private _citta As String
        Private _nazione As String
        Private _codiceFiscale As String
        Private _partitaIva As String
        Private _fax As String
        Private _email As String
        Private _referenteAmministrativo As String
        Private _sedeAmministrativa As String
        Private _abilitato As Boolean
        Private _tsModifica As DateTime
        Private _responsabileAggiornamento As String

        '===================== COSTRUTTORI ===============================
        Public Sub New()

        End Sub

        Public Sub New(ByVal CodiceOperatoreSDC As String)
            Me._codiceOperatoreSDC = CodiceOperatoreSDC
        End Sub

        '==================== PROPRIETA` ==================================
        ' CODICE OPERATORE SDC
        Public Property CodiceOperatoreSDC() As String
            Get
                Return Me._codiceOperatoreSDC
            End Get
            Set(ByVal Value As String)
                Me._codiceOperatoreSDC = Value
            End Set
        End Property

        ' RAGIONE SOCIALE
        Public Property RagioneSociale() As String
            Get
                Return Me._ragioneSociale
            End Get
            Set(ByVal Value As String)
                Me._ragioneSociale = Value
            End Set
        End Property

        ' INDIRIZZO 1
        Public Property Indirizzo1() As String
            Get
                Return Me._indirizzo1
            End Get
            Set(ByVal Value As String)
                Me._indirizzo1 = Value
            End Set
        End Property

        ' INDIRIZZO 2
        Public Property Indirizzo2() As String
            Get
                Return Me._indirizzo2
            End Get
            Set(ByVal Value As String)
                Me._indirizzo2 = Value
            End Set
        End Property

        ' CITTA`
        Public Property Citta() As String
            Get
                Return Me._citta
            End Get
            Set(ByVal Value As String)
                Me._citta = Value
            End Set
        End Property

        ' NAZIONE
        Public Property Nazione() As String
            Get
                Return Me._nazione
            End Get
            Set(ByVal Value As String)
                Me._nazione = Value
            End Set
        End Property

        ' CODICE FISCALE
        Public Property CodiceFiscale() As String
            Get
                Return Me._codiceFiscale
            End Get
            Set(ByVal Value As String)
                Me._codiceFiscale = Value
            End Set
        End Property

        ' PARTITA IVA
        Public Property PartitaIVA() As String
            Get
                Return Me._partitaIva
            End Get
            Set(ByVal Value As String)
                Me._partitaIva = Value
            End Set
        End Property

        ' FAX
        Public Property Fax() As String
            Get
                Return Me._fax
            End Get
            Set(ByVal Value As String)
                Me._fax = Value
            End Set
        End Property

        ' EMAIL
        Public Property Email() As String
            Get
                Return Me._email
            End Get
            Set(ByVal Value As String)
                Me._email = Value
            End Set
        End Property

        ' REFERENTE AMMINISTRATIVO
        Public Property ReferenteAmministrativo() As String
            Get
                Return Me._referenteAmministrativo
            End Get
            Set(ByVal Value As String)
                Me._referenteAmministrativo = Value
            End Set
        End Property

        ' SEDE AMMINISTRATIVA
        Public Property SedeAmministrativa() As String
            Get
                Return Me._sedeAmministrativa
            End Get
            Set(ByVal Value As String)
                Me._sedeAmministrativa = Value
            End Set
        End Property

        ' ABILITATO
        Public Property Abilitato() As Boolean
            Get
                Return Me._abilitato
            End Get
            Set(ByVal Value As Boolean)
                Me._abilitato = Value
            End Set
        End Property

        ' TSMODIFICA
        Public Property TSModifica() As DateTime
            Get
                Return Me._tsModifica
            End Get
            Set(ByVal Value As DateTime)
                Me._tsModifica = Value
            End Set
        End Property

        ' RESPONSABILE AGGIORNAMENTO
        Public Property ResponsabileAggiornamento() As String
            Get
                Return Me._responsabileAggiornamento
            End Get
            Set(ByVal Value As String)
                Me._responsabileAggiornamento = Value
            End Set
        End Property
    End Class
End Class
