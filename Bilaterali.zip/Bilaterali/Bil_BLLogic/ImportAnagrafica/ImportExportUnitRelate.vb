Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema

Public Class ImportExportUnitRelate
    Inherits BilBLBase

    Public Function InserisciUnitRelateAsync(ByVal oby As Bil.FileStore.InfoEvento, ByVal runningOperator As String) As String
        'Public Function InserisciUnitRelateAsync(ByVal by() As Byte, ByVal runningOperator As String) As String

        BatchSerializer.BS.AddBatch(AddressOf ImportExportUnitRelate.InserisciUnitRelateAsyncCB, oby, oby.CodiceTipoFile, oby.DescrizioneFile, DateTime.MinValue, runningOperator)
        'BatchSerializer.BS.AddBatch(AddressOf ImportExportUnitRelate.InserisciUnitRelateAsyncCB, by, "IMP_UR", "Import unit relate", DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Private Shared Sub InserisciUnitRelateAsyncCB(ByVal o As Object)
        Dim bl As New ImportExportUnitRelate
        bl.InserisciUnitRelate(DirectCast(o, Bil.FileStore.InfoEvento))
        'bl.InserisciUnitRelate(DirectCast(o, Byte()))
    End Sub


    Private Sub InserisciUnitRelate(ByVal blInfoEvt As Bil.FileStore.InfoEvento)
        'Private Sub InserisciUnitRelate(ByVal by() As Byte)
        Dim blFS As Bil.FileStore
        Dim TSFile As DateTime
        Dim IdFile As Integer

        Try
            blFS = New Bil.FileStore
            blFS.InsertFile(blInfoEvt, TSFile, IdFile)
        Catch ex As Exception
            smError(ex, "Import UnitRelate")
            Throw
        End Try

        ' se sono qui ho messo il file nel DB e TSFile/IdFile sono valorizzati
        Try
            Dim by() As Byte = blInfoEvt.ContenutoFile
            SaveUploadFile("UnitRelate", by)

            smTrace("Import UnitRelate: inizio attivita'")

            ParseXML(by)

            smTrace("Import UnitRelate: attivita' completata con successo")

            BatchSerializer.SetProgressBatch("Attivita` terminata con successo")

            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Import UnitRelate: terminato con successo")
            blFS.UpdateFAFile(TSFile, IdFile, byFA)

        Catch ex As Exception
            smError(ex, "Import UnitRelate")
            BatchSerializer.SetProgressBatch("Errore nell'import:" + ex.Message)

            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Import UnitRelate: terminato con successo")
            blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Throw
        End Try
        smError("Eseguito Import UnitRelate")
    End Sub

    Public Function Export(ByRef blInfoEvt As Bil.FileStore.InfoEvento) As Boolean

        Dim TSFile As DateTime
        Dim IdFile As Integer
        Dim byFA() As Byte

        Try
            smTrace("Export UnitRelate: inizio attivita'")

            blInfoEvt.ContenutoFile = GetListaUnitRelate()

            smTrace("Export UnitRelate: attivita' completata con successo")

            byFA = (New UnicodeEncoding).GetBytes("Export UnitRelate: attivita' completata con successo")
            Dim blFS As New Bil.FileStore
            blFS.InsertFile(blInfoEvt, TSFile, IdFile)
            blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Return True
        Catch ex As Exception
            smError(ex, "Export UnitRelate")
            Return False
        End Try
    End Function


    <FlagsAttribute()> Private Enum CampoLetto
        Nessuno = 0
        Letto_CodiceOperatoreSDC = 1
        Letto_CodiceUnitaSDC = 2
        Letto_CategoriaUnitaSDC = 4
        Letto_DataInizioValidita = 8
        Letto_DataFineValidita = 16
        Letto_Abilitata = 32
    End Enum

    Private Sub ParseXML(ByVal xmlContent() As Byte)

        Dim xr As New XmlTextReader(New MemoryStream(xmlContent))
        Dim cn As New SqlConnection
        Dim tr As SqlTransaction = Nothing

        ' Apro la connessione al DB

        Try
            cn.ConnectionString = GetConnectionString()
            cn.Open()
            tr = cn.BeginTransaction()


            Dim cultureInfoIT As New System.Globalization.CultureInfo("it-IT")

            '======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
            Dim elUnitRelates As Object = xr.NameTable.Add("UnitRelates")
            Dim elUnitRelate As Object = xr.NameTable.Add("UnitRelate")
            Dim elCodiceOperatoreSDC As Object = xr.NameTable.Add("CodiceOperatoreSDC")
            Dim elCodiceUnitaSDC As Object = xr.NameTable.Add("CodiceUnitaSDC")
            Dim elCategoriaUnitaSDC As Object = xr.NameTable.Add("CategoriaUnitaSDC")
            Dim elDataInizioValidita As Object = xr.NameTable.Add("DataInizioValidita")
            Dim elDataFineValidita As Object = xr.NameTable.Add("DataFineValidita")
            Dim elAbilitata As Object = xr.NameTable.Add("Abilitata")

            Dim currUnitRelate As UnitRelate = Nothing

            Dim campiLetti As CampoLetto = CampoLetto.Nessuno

            While (xr.Read())
                Dim xrn As Object = xr.Name

                Select Case xr.NodeType
                    Case XmlNodeType.Element
                        '================== UTENTE ============================
                        If (xrn Is elUnitRelate) Then
                            campiLetti = CampoLetto.Nessuno
                            currUnitRelate = New UnitRelate

                            '================== CODICE OPERATORE SDC ============================
                        ElseIf (xrn Is elCodiceOperatoreSDC) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currUnitRelate.CodiceOperatoreSDC = xmlData
                                campiLetti = campiLetti Or CampoLetto.Letto_CodiceOperatoreSDC
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== CODICE UNITA SDC ============================
                        ElseIf (xrn Is elCodiceUnitaSDC) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currUnitRelate.CodiceUnitaSDC = xmlData
                                campiLetti = campiLetti Or CampoLetto.Letto_CodiceUnitaSDC
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== CATEGORIA UNITA SDC ============================
                        ElseIf (xrn Is elCategoriaUnitaSDC) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currUnitRelate.CategoriaUnitaSDC = xmlData
                                campiLetti = campiLetti Or CampoLetto.Letto_CategoriaUnitaSDC
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== DATA INIZIO VALIDITA ============================
                        ElseIf (xrn Is elDataInizioValidita) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                Try
                                    currUnitRelate.DataInizioValidita = DateTime.Parse(xmlData, cultureInfoIT).Date
                                    campiLetti = campiLetti Or CampoLetto.Letto_DataInizioValidita
                                Catch ex As Exception
                                    Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore nel parsing della data di inizio validita'.")
                                End Try
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== DATA FINE VALIDITA ============================
                        ElseIf (xrn Is elDataFineValidita) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                Try
                                    currUnitRelate.DataFineValidita = DateTime.Parse(xmlData, cultureInfoIT).date
                                    campiLetti = campiLetti Or CampoLetto.Letto_DataFineValidita
                                Catch ex As Exception
                                    Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore nel parsing della data di fine validita'.")
                                End Try
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== ABILITATA ============================
                        ElseIf (xrn Is elAbilitata) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                Try
                                    currUnitRelate.Abilitata = Boolean.Parse(xmlData)
                                    campiLetti = campiLetti Or CampoLetto.Letto_Abilitata
                                Catch ex As Exception
                                    Throw New ApplicationException("Errore nel parsing della Tag 'Abilitata'.")
                                End Try
                            Else
                                Throw New ApplicationException("Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                        End If

                    Case XmlNodeType.EndElement
                        If (xrn Is elUnitRelate) Then

                            If (campiLetti And CampoLetto.Letto_CodiceOperatoreSDC) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML CodiceOperatoreSDC mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_CategoriaUnitaSDC) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML CategoriaUnitaSDC mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_CodiceUnitaSDC) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML CodiceUnitaSDC mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_DataInizioValidita) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML DataInizioValidita mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_DataFineValidita) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML DataFineValidita mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_Abilitata) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML Abilitata mancante")
                            End If


                            If currUnitRelate.DataInizioValidita > currUnitRelate.DataFineValidita Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": la Data Inizio Validit� � maggiore della Data Fine Validit�")
                            End If
                            ' Salvo sul DB l'utente 
                            SaveToDB(cn, tr, currUnitRelate, xr.LineNumber)

                            currUnitRelate = Nothing
                            campiLetti = CampoLetto.Nessuno
                        End If
                End Select

            End While

            If Not tr Is Nothing Then tr.Commit() : tr = Nothing

        Catch ex As Exception
            smError(ex)
            Throw

        Finally
            If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
            If Not xr Is Nothing Then xr.Close()
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Sub

    Private Sub SaveToDB(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal unit As UnitRelate, ByVal lineNumber As Integer)
        Try
            InsertInUnitRelate(cn, _
             tr, _
             unit.CodiceOperatoreSDC, _
             unit.CodiceUnitaSDC, _
             unit.CategoriaUnitaSDC, _
             unit.DataInizioValidita, _
             unit.DataFineValidita, _
             unit.Abilitata, _
            lineNumber)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub InsertInUnitRelate(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal CodiceOperatoreSDC As String, ByVal CodiceUnitaSDC As String, ByVal CategoriaUnitaSDC As String, ByVal DataInizioValidita As DateTime, ByVal DataFineValidita As DateTime, ByVal Abilitata As Boolean, ByVal lineNumber As Integer)

        Dim cmdSql As New SqlClient.SqlCommand

        Dim cmdUpdate, cmdInsert As String

        cmdUpdate = "UPDATE UnitRelate SET "
        cmdUpdate = cmdUpdate + " CodiceOperatoreSDC = @CodiceOperatoreSDC, CodiceUnitaSDC = @CodiceUnitaSDC, CategoriaUnitaSDC = @CategoriaUnitaSDC, DataInizioValidita = @DataInizioValidita, DataFineValidita = @DataFineValidita, TSModifica = @TSModifica, Abilitata = @Abilitata "
        cmdUpdate = cmdUpdate + " WHERE "
        cmdUpdate = cmdUpdate + " (CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (CodiceOperatoreSDC = @CodiceOperatoreSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC) "

        cmdInsert = "INSERT INTO UnitRelate(CodiceOperatoreSDC, CodiceUnitaSDC, CategoriaUnitaSDC, DataInizioValidita, DataFineValidita, TSModifica, Abilitata) VALUES (@CodiceOperatoreSDC, @CodiceUnitaSDC, @CategoriaUnitaSDC, @DataInizioValidita, @DataFineValidita, @TSModifica, @Abilitata) "

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@CodiceOperatoreSDC", CodiceOperatoreSDC)
        cmdSql.Parameters.Add("@CodiceUnitaSDC", CodiceUnitaSDC)
        cmdSql.Parameters.Add("@CategoriaUnitaSDC", CategoriaUnitaSDC)
        cmdSql.Parameters.Add("@DataInizioValidita", DataInizioValidita)
        cmdSql.Parameters.Add("@DataFineValidita", DataFineValidita)
        cmdSql.Parameters.Add("@Abilitata", Abilitata)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)

        Dim esiste As Boolean = False
        Try
            cmdSql.CommandTimeout = AppSettingToInt32("ImportUnitRelateQueryTmo", 120)
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            Dim err As String = ex.Message.ToUpper
            If err.IndexOf("PK_UnitRelate".ToUpper) >= 0 Then
                ' Se la riga esiste => faccio un update
                esiste = True
            ElseIf err.IndexOf("FK_UnitRelate_Operatori".ToUpper) >= 0 Then
                Throw New ApplicationException(lineNumber.ToString + ": L'operatore " + CodiceOperatoreSDC + " non esiste")
            ElseIf err.IndexOf("FK_UnitRelate_Unita".ToUpper) >= 0 Then
                Throw New ApplicationException(lineNumber.ToString + ": L'unita` " + CodiceUnitaSDC + " non esiste")
            Else
                ' se ha fallito per qualunque altro motivo => lancio l'eccezione
                Throw
            End If
        End Try

        If esiste = True Then
            cmdSql.CommandText = cmdUpdate

            cmdSql.Parameters.Clear()
            cmdSql.Parameters.Add("@CodiceOperatoreSDC", CodiceOperatoreSDC)
            cmdSql.Parameters.Add("@CodiceUnitaSDC", CodiceUnitaSDC)
            cmdSql.Parameters.Add("@CategoriaUnitaSDC", CategoriaUnitaSDC)
            cmdSql.Parameters.Add("@DataInizioValidita", DataInizioValidita)
            cmdSql.Parameters.Add("@DataFineValidita", DataFineValidita)
            cmdSql.Parameters.Add("@Abilitata", Abilitata)
            cmdSql.Parameters.Add("@TSModifica", TimeStamp)

            Try
                cmdSql.CommandTimeout = AppSettingToInt32("ImportUnitRelateQueryTmo", 120)
                Dim numrow As Integer = cmdSql.ExecuteNonQuery()
                If numrow = 0 Then
                    Throw New ApplicationException("Fallito UPDATE su tabella UnitRelate.")
                End If
            Catch ex As SqlException
                Dim err As String = ex.Message.ToUpper
                If err.IndexOf("FK_UnitRelate_Operatori".ToUpper) >= 0 Then
                    Throw New ApplicationException("Linea " + lineNumber.ToString + ": L'operatore " + CodiceOperatoreSDC + " non esiste")
                ElseIf err.IndexOf("FK_UnitRelate_Unita".ToUpper) >= 0 Then
                    Throw New ApplicationException("Linea " + lineNumber.ToString + ": L'unita` " + CodiceUnitaSDC + " non esiste")
                Else
                    Throw
                End If
            End Try

        End If

    End Sub

    Private Function GetListaUnitRelate() As Byte()

        Dim ds As New DS_UnitRelate
        cn.ConnectionString = GetConnectionString()
        Try
            cn.Open()
            daUnitRelate.Fill(ds.UnitRelate)

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try

        Dim ms As New MemoryStream
        Dim tw As New XmlTextWriter(ms, Encoding.GetEncoding("iso-8859-1"))
        Try
            If (ds Is Nothing) Then
                Throw New ApplicationException("Errore DataSet uguale a Nothing")
            End If

            tw.Formatting = Formatting.Indented
            tw.IndentChar = "	"c    ' e` un tab
            tw.Indentation = 1
            tw.WriteStartDocument()
            tw.WriteStartElement("UnitRelates")

            For Each row As DS_UnitRelate.UnitRelateRow In ds.UnitRelate.Rows

                tw.WriteStartElement("UnitRelate")

                tw.WriteStartElement("CodiceOperatoreSDC")
                tw.WriteString(row.CodiceOperatoreSDC)
                tw.WriteEndElement()

                tw.WriteStartElement("CodiceUnitaSDC")
                tw.WriteString(row.CodiceUnitaSDC)
                tw.WriteEndElement()

                tw.WriteStartElement("CategoriaUnitaSDC")
                tw.WriteString(row.CategoriaUnitaSDC)
                tw.WriteEndElement()

                tw.WriteStartElement("DataInizioValidita")
                tw.WriteString(row.DataInizioValidita.ToString("dd/MM/yyyy"))
                tw.WriteEndElement()

                tw.WriteStartElement("DataFineValidita")
                tw.WriteString(row.DataFineValidita.ToString("dd/MM/yyyy"))
                tw.WriteEndElement()

                tw.WriteStartElement("Abilitata")
                tw.WriteString(row.Abilitata.ToString)
                tw.WriteEndElement()

                tw.WriteEndElement()
            Next

            tw.WriteEndDocument()
            tw.Flush()

#If DEBUG Then
            Dim s As String = Encoding.UTF8.GetString(ms.ToArray())
#End If
            Return ms.ToArray()
        Catch ex As Exception
            Throw
        Finally
            ms.Close()
            tw.Close()
        End Try
    End Function

    Class UnitRelate
        '======================= VARIABILI PRIVATE ==================================
        Private _codiceOperatoreSDC As String
        Private _codiceUnitaSDC As String
        Private _categoriaUnitaSDC As String
        Private _dataInizioValidita As DateTime
        Private _dataFineValidita As DateTime
        Private _abilitata As Boolean

        '======================= COSTRUTTORI ==================================
        Public Sub New()

        End Sub

        '======================= PROPRIETA` ==================================
        ' CODICE OPERATORE SDC
        Public Property CodiceOperatoreSDC() As String
            Get
                Return Me._codiceOperatoreSDC
            End Get
            Set(ByVal Value As String)
                Me._codiceOperatoreSDC = Value
            End Set
        End Property

        ' CODICE UNITA SDC
        Public Property CodiceUnitaSDC() As String
            Get
                Return Me._codiceUnitaSDC
            End Get
            Set(ByVal Value As String)
                Me._codiceUnitaSDC = Value
            End Set
        End Property

        ' CATEGORIA UNITA SDC
        Public Property CategoriaUnitaSDC() As String
            Get
                Return Me._categoriaUnitaSDC
            End Get
            Set(ByVal Value As String)
                Me._categoriaUnitaSDC = Value
            End Set
        End Property

        ' DATA INIZIO VALIDITA
        Public Property DataInizioValidita() As DateTime
            Get
                Return Me._dataInizioValidita
            End Get
            Set(ByVal Value As DateTime)
                Me._dataInizioValidita = Value
            End Set
        End Property

        ' DATA FINE VALIDITA
        Public Property DataFineValidita() As DateTime
            Get
                Return Me._dataFineValidita
            End Get
            Set(ByVal Value As DateTime)
                Me._dataFineValidita = Value
            End Set
        End Property

        ' ABILITATO
        Public Property Abilitata() As Boolean
            Get
                Return Me._abilitata
            End Get
            Set(ByVal Value As Boolean)
                Me._abilitata = Value
            End Set
        End Property

    End Class



#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents daUnitRelate As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.daUnitRelate = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=sa;data source=BILSVR1;persist sec" & _
        "urity info=True;initial catalog=Bilaterali;password=bilaterali"
        '
        'daUnitRelate
        '
        Me.daUnitRelate.SelectCommand = Me.SqlSelectCommand1
        Me.daUnitRelate.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "UnitRelate", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"), New System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"), New System.Data.Common.DataColumnMapping("DataInizioValidita", "DataInizioValidita"), New System.Data.Common.DataColumnMapping("DataFineValidita", "DataFineValidita"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"), New System.Data.Common.DataColumnMapping("Abilitata", "Abilitata"), New System.Data.Common.DataColumnMapping("TrUC", "TrUC"), New System.Data.Common.DataColumnMapping("VUC", "VUC")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT CodiceOperatoreSDC, CodiceUnitaSDC, CategoriaUnitaSDC, DataInizioValidita," & _
        " DataFineValidita, TSModifica, Abilitata, TrUC, VUC FROM UnitRelate"
        Me.SqlSelectCommand1.Connection = Me.cn

    End Sub

#End Region

End Class
