Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema
Public Class ImportExportUtentiOperatori
	Inherits BilBLBase


    Public Function InserisciUtentiOperatoriAsync(ByVal oby As Bil.FileStore.InfoEvento, ByVal runningOperator As String) As String
        'BatchSerializer.BS.AddBatch(AddressOf ImportExportUtentiOperatori.InserisciUtentiOperatoriAsyncCB, by, "IMP_UTOP", "Import utenti/operatori", DateTime.MinValue, runningOperator)
        BatchSerializer.BS.AddBatch(AddressOf ImportExportUtentiOperatori.InserisciUtentiOperatoriAsyncCB, oby, oby.CodiceTipoFile, oby.DescrizioneFile, DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Private Shared Sub InserisciUtentiOperatoriAsyncCB(ByVal o As Object)
        Dim bl As New ImportExportUtentiOperatori
        bl.InserisciOperatoriUtenti(DirectCast(o, Bil.FileStore.InfoEvento))
    End Sub


    Private Sub InserisciOperatoriUtenti(ByVal blInfoEvt As Bil.FileStore.InfoEvento)

        Dim blFS As Bil.FileStore
        Dim TSFile As DateTime
        Dim IdFile As Integer

        smTrace("Import relazione Operatori/utenti: inizio attivita'")

        Try
            blFS = New Bil.FileStore
            blFS.InsertFile(blInfoEvt, TSFile, IdFile)
        Catch ex As Exception
            smError(ex, "Import UnitRelate")
            Throw
        End Try

        ' se sono qui ho messo il file nel DB e TSFile/IdFile sono valorizzati
        Dim message As String

        Dim by() As Byte = blInfoEvt.ContenutoFile
        SaveUploadFile("UtentiOperatori", by)

        Try
            ParseXML(by)
            message = "Import utenti/operatori: attivita` terminata con successo"
            smTrace(message)

            BatchSerializer.SetProgressBatch("Attivita` terminata con successo")
            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes(message)
            blFS.UpdateFAFile(TSFile, IdFile, byFA)


        Catch ex As Exception
            message = "Import relazione utenti/operatori: errore nell'import"
            smError(ex, message)
            BatchSerializer.SetProgressBatch("Errore nell'import utenti/operatori : " + ex.Message)
            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes(message + ex.Message)
            blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Throw
        End Try
    End Sub

    <FlagsAttribute()> Private Enum CampoLetto
        Nessuno = 0
        Letto_CodiceOperatoreSDC = 1
        Letto_CodiceUtenteSDC = 2
        Letto_Amministratore = 4
        Letto_Abilitato = 8
        Letto_TSIniValidita = 16
        Letto_TSEndValidita = 32
        Letto_CodiceRuolo = 64
        Letto_TSModifica = 128
    End Enum

    Private Sub ParseXML(ByVal xmlContent() As Byte)

        Dim xr As New XmlTextReader(New MemoryStream(xmlContent))
        Dim tr As SqlTransaction = Nothing


        Try
            ' Apro la connessione al DB
            cn.ConnectionString = GetConnectionString()
            cn.Open()
            tr = cn.BeginTransaction()


            Dim cultureInfoIT As New System.Globalization.CultureInfo("it-IT")

            '======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
            Dim elOperatorUsers As Object = xr.NameTable.Add("Associazione_UtentiOperatori")
            Dim elOperatorUser As Object = xr.NameTable.Add("UtentiOperatori")
            Dim elCodiceOperatoreSDC As Object = xr.NameTable.Add("CodiceOperatoreSDC")
            Dim elCodiceUtenteSDC As Object = xr.NameTable.Add("CodiceUtenteSDC")
            Dim elAmministratore As Object = xr.NameTable.Add("Amministratore")
            Dim elAbilitato As Object = xr.NameTable.Add("Abilitato")
            Dim elTSIniValidita As Object = xr.NameTable.Add("DataInizioValidita")
            Dim elTSEndValidita As Object = xr.NameTable.Add("DataFineValidita")
            Dim elCodiceRuolo As Object = xr.NameTable.Add("CodiceRuolo")
            Dim elTSModifica As Object = xr.NameTable.Add("DataUltimaModifica")

            Dim currOpUt As OperatoriUtenti = Nothing

            Dim campiLetti As CampoLetto = CampoLetto.Nessuno

            While (xr.Read())
                Dim xrn As Object = xr.Name

                Select Case xr.NodeType
                    Case XmlNodeType.Element
                        '================== UTENTE ============================
                        If (xrn Is elOperatorUser) Then
                            campiLetti = CampoLetto.Nessuno
                            currOpUt = New OperatoriUtenti
                            currOpUt.TSEndValidita = DateTime.MinValue
                            currOpUt.TSIniValidita = DateTime.MinValue

                            '================== CODICE UTENTE SDC ============================
                        ElseIf (xrn Is elCodiceUtenteSDC) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currOpUt.CodiceUtenteSDC = xmlData
                                campiLetti = campiLetti Or CampoLetto.Letto_CodiceUtenteSDC
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== CODICE OPERATORE SDC ============================
                        ElseIf (xrn Is elCodiceOperatoreSDC) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currOpUt.CodiceOperatoreSDC = xmlData
                                campiLetti = campiLetti Or CampoLetto.Letto_CodiceOperatoreSDC
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== AMMINISTRATORE ============================
                        ElseIf (xrn Is elAmministratore) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currOpUt.Amministratore = Integer.Parse(xmlData)
                                campiLetti = campiLetti Or CampoLetto.Letto_Amministratore
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If
                            '================== ABILITATO ============================
                        ElseIf (xrn Is elAbilitato) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currOpUt.Abilitato = Boolean.Parse(xmlData)
                                campiLetti = campiLetti Or CampoLetto.Letto_Abilitato
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== DATA INIZIO VALIDITA` ============================
                        ElseIf (xrn Is elTSIniValidita) Then
                            Dim xmlData As String = xr.ReadString()
                            'Il campo puo` essere vuoto perche` sul database e` nullable.
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                Try
                                    currOpUt.TSIniValidita = DateTime.Parse(xmlData, cultureInfoIT).Date
                                Catch ex As Exception
                                    Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore nel parsing della data di inizio validita'.")
                                End Try
                            End If
                            campiLetti = campiLetti Or CampoLetto.Letto_TSIniValidita

                            '================== DATA FINE VALIDITA` ============================
                        ElseIf (xrn Is elTSEndValidita) Then
                            Dim xmlData As String = xr.ReadString()
                            'Il campo puo` essere vuoto perche` sul database e` nullable.
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                Try
                                    currOpUt.TSEndValidita = DateTime.Parse(xmlData, cultureInfoIT).Date
                                Catch ex As Exception
                                    Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore nel parsing della data di inizio validita'.")
                                End Try
                            End If
                            campiLetti = campiLetti Or CampoLetto.Letto_TSEndValidita

                            '================== CODICE RUOLO ============================
                        ElseIf (xrn Is elCodiceRuolo) Then
                            Dim xmlData As String = xr.ReadString()
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                Try
                                    currOpUt.CodiceRuolo = xmlData
                                    campiLetti = campiLetti Or CampoLetto.Letto_CodiceRuolo
                                Catch ex As Exception
                                    Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore nel parsing della data di fine validita'.")
                                End Try
                            Else
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== DATA ULTIMA MODIFICA ============================
                        ElseIf (xrn Is elTSModifica) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                Try
                                    currOpUt.TSModifica = DateTime.Parse(xmlData, cultureInfoIT).Date
                                Catch ex As Exception
                                    Throw New ApplicationException("Errore nel parsing della Tag 'Abilitata'.")
                                End Try
                            End If
                            campiLetti = campiLetti Or CampoLetto.Letto_TSModifica
                        End If

                    Case XmlNodeType.EndElement
                        If (xrn Is elOperatorUser) Then

                            If (campiLetti And CampoLetto.Letto_CodiceOperatoreSDC) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML CodiceOperatoreSDC mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_CodiceUtenteSDC) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML CodiceUtenteSDC mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_Amministratore) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML Amministratore mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_Abilitato) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML Abilitato mancante")
                            ElseIf (campiLetti And CampoLetto.Letto_TSModifica) = 0 Then
                                Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": Campo XML DataUltimaModifica mancante")
                            End If

                            If Not currOpUt.TSIniValidita = DateTime.MinValue AndAlso Not currOpUt.TSEndValidita = DateTime.MinValue Then
                                If currOpUt.TSIniValidita > currOpUt.TSEndValidita Then
                                    Throw New ApplicationException("Linea " + xr.LineNumber.ToString + ": la Data Inizio Validit� � maggiore della Data Fine Validit�")
                                End If
                            End If
                            ' Salvo sul DB l'utente 
                            SaveToDB(cn, tr, currOpUt, xr.LineNumber)

                            currOpUt = Nothing
                            campiLetti = CampoLetto.Nessuno
                        End If
                End Select

            End While

            If Not tr Is Nothing Then tr.Commit() : tr = Nothing

        Catch ex As Exception
            smError(ex)
            Throw

        Finally
            If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
            If Not xr Is Nothing Then xr.Close()
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Sub

    Private Sub SaveToDB(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal relOpUt As OperatoriUtenti, ByVal lineNumber As Integer)
        Try
            InsertInRelOperatoriUtenti(cn, _
             tr, _
             relOpUt.CodiceOperatoreSDC, _
             relOpUt.CodiceUtenteSDC, _
             relOpUt.Amministratore, _
             relOpUt.Abilitato, _
             relOpUt.TSIniValidita, _
             relOpUt.TSEndValidita, _
             relOpUt.CodiceRuolo, _
             relOpUt.TSModifica, _
            lineNumber)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub InsertInRelOperatoriUtenti(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal CodiceOperatoreSDC As String, ByVal CodiceUtenteSDC As String, ByVal Amministratore As Integer, ByVal Abilitato As Boolean, ByVal TSIniValidita As DateTime, ByVal TSEndValidita As DateTime, ByVal CodiceRuolo As String, ByVal TSModifica As DateTime, ByVal lineNumber As Integer)

        Dim cmdSql As New SqlClient.SqlCommand

        Dim cmdUpdate, cmdInsert As String

        cmdUpdate = "UPDATE RelOperatoriUtenti SET "
        cmdUpdate = cmdUpdate + " CodiceOperatoreSDC = @CodiceOperatoreSDC, CodiceUtenteSDC = @CodiceUtenteSDC, Amministratore = @Amministratore, Abilitato = @Abilitato, TSIniValidita = @TSIniValidita, TSEndValidita = @TSEndValidita, CodiceRuolo = @CodiceRuolo, TSModifica = @TSModifica"
        cmdUpdate = cmdUpdate + " WHERE "
        cmdUpdate = cmdUpdate + " (CodiceOperatoreSDC = @CodiceOperatoreSDC) AND (CodiceUtenteSDC = @CodiceUtenteSDC) AND (Amministratore = @Amministratore) "

        cmdInsert = "INSERT INTO RelOperatoriUtenti(CodiceOperatoreSDC, CodiceUtenteSDC, Amministratore, Abilitato, TSIniValidita, TSEndValidita, CodiceRuolo, TSModifica) VALUES (@CodiceOperatoreSDC, @CodiceUtenteSDC, @Amministratore, @Abilitato, @TSIniValidita, @TSEndValidita, @CodiceRuolo, @TSModifica) "

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@CodiceOperatoreSDC", CodiceOperatoreSDC)
        cmdSql.Parameters.Add("@CodiceUtenteSDC", CodiceUtenteSDC)
        cmdSql.Parameters.Add("@Amministratore", Amministratore)
        cmdSql.Parameters.Add("@Abilitato", Abilitato)
        If TSIniValidita = DateTime.MinValue Then
            cmdSql.Parameters.Add("@TSIniValidita", DBNull.Value)
        Else
            cmdSql.Parameters.Add("@TSIniValidita", TSIniValidita)
        End If
        If TSEndValidita = DateTime.MinValue Then
            cmdSql.Parameters.Add("@TSEndValidita", DBNull.Value)
        Else
            cmdSql.Parameters.Add("@TSEndValidita", TSEndValidita)
        End If
        cmdSql.Parameters.Add("@CodiceRuolo", CodiceRuolo)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)

        Dim esiste As Boolean = False
        Try
            cmdSql.CommandTimeout = AppSettingToInt32("ImportExportUtentiOperatoriQueryTmo", 60)
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            Dim err As String = ex.Message.ToUpper
            If err.IndexOf("RelOperatoriUtenti_PK".ToUpper) >= 0 Then
                ' Se la riga esiste => faccio un update
                esiste = True
            ElseIf err.IndexOf("Operatori_RelOperatoriUtenti_FK1".ToUpper) >= 0 Then
                Throw New ApplicationException("Linea " + lineNumber.ToString + ": L'operatore " + CodiceOperatoreSDC + " non esiste")
            ElseIf err.IndexOf("Utenti_RelOperatoriUtenti_FK1".ToUpper) >= 0 Then
                Throw New ApplicationException("Linea " + lineNumber.ToString + ": L'utente " + CodiceUtenteSDC + " non esiste")
            Else
                ' se ha fallito per qualunque altro motivo => lancio l'eccezione
                Throw
            End If
        End Try

        If esiste = True Then
            cmdSql.CommandText = cmdUpdate

            cmdSql.Parameters.Clear()
            cmdSql.Parameters.Add("@CodiceOperatoreSDC", CodiceOperatoreSDC)
            cmdSql.Parameters.Add("@CodiceUtenteSDC", CodiceUtenteSDC)
            cmdSql.Parameters.Add("@Amministratore", Amministratore)
            cmdSql.Parameters.Add("@Abilitato", Abilitato)
            If TSIniValidita = DateTime.MinValue Then
                cmdSql.Parameters.Add("@TSIniValidita", DBNull.Value)
            Else
                cmdSql.Parameters.Add("@TSIniValidita", TSIniValidita)
            End If
            If TSEndValidita = DateTime.MinValue Then
                cmdSql.Parameters.Add("@TSEndValidita", DBNull.Value)
            Else
                cmdSql.Parameters.Add("@TSEndValidita", TSEndValidita)
            End If
            cmdSql.Parameters.Add("@CodiceRuolo", CodiceRuolo)
            cmdSql.Parameters.Add("@TSModifica", TimeStamp)

            Try
                cmdSql.CommandTimeout = AppSettingToInt32("ImportExportUtentiOperatoriQueryTmo", 60)

                Dim numrow As Integer = cmdSql.ExecuteNonQuery()
                If numrow = 0 Then
                    Throw New ApplicationException("Fallito UPDATE su tabella RelOperatoriUtenti.")
                End If
            Catch ex As SqlException
                Dim err As String = ex.Message.ToUpper
                If err.IndexOf("FK_RelOperatoriUtentie_Operatori".ToUpper) >= 0 Then
                    Throw New ApplicationException(lineNumber.ToString + ": L'operatore " + CodiceOperatoreSDC + " non esiste")
                ElseIf err.IndexOf("FK_RelOperatoriUtenti_Utenti".ToUpper) >= 0 Then
                    Throw New ApplicationException(lineNumber.ToString + ": L'utente " + CodiceUtenteSDC + " non esiste")
                Else
                    Throw
                End If
            End Try

        End If

    End Sub

    Public Function Export(ByRef blInfoEvt As Bil.FileStore.InfoEvento) As Boolean
        Dim blFS As Bil.FileStore
        Dim TSFile As DateTime
        Dim IdFile As Integer
        Dim byFA() As Byte

        Try
            blFS = New Bil.FileStore
        Catch ex As Exception
            smError(ex, "Import UnitRelate")
            Throw
        End Try
        Try
            smTrace("Export operatori/utenti: inizio attivita'")
            blInfoEvt.ContenutoFile = GetListaRelOperatoriUtenti()
            smTrace("Export operatori/utenti: fine attivita'")

            byFA = (New UnicodeEncoding).GetBytes("Export operatori/utenti: fine attivita'")

            blFS.InsertFile(blInfoEvt, TSFile, IdFile)
            blFS.UpdateFAFile(TSFile, IdFile, byFA)

            Return True
        Catch ex As Exception
            smError(ex, "Export operatori/utenti")
            byFA = (New UnicodeEncoding).GetBytes("Export operatori/utenti: attivita' fallita " + ex.Message)

            blFS.InsertFile(blInfoEvt, TSFile, IdFile)
            blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Return False
        End Try
    End Function

    Private Function GetListaRelOperatoriUtenti() As Byte()

        Dim ds As New DS_UtentiOperatori
        Me.cn.ConnectionString = GetConnectionString()
        Try
            cn.Open()
            Me.daUtentiOperatori.Fill(ds.RelOperatoriUtenti)

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try

        Dim ms As New MemoryStream
        Dim tw As New XmlTextWriter(ms, Encoding.GetEncoding("iso-8859-1"))
        Try
            If (ds Is Nothing) Then
                Throw New ApplicationException("Errore DataSet uguale a Nothing")
            End If

            tw.Formatting = Formatting.Indented
            tw.IndentChar = "	"c    ' e` un tab
            tw.Indentation = 1
            tw.WriteStartDocument()
            tw.WriteStartElement("Associazione_UtentiOperatori")

            For Each row As DS_UtentiOperatori.RelOperatoriUtentiRow In ds.RelOperatoriUtenti.Rows

                tw.WriteStartElement("UtentiOperatori")

                tw.WriteStartElement("CodiceUtenteSDC")
                tw.WriteString(row.CodiceUtenteSDC)
                tw.WriteEndElement()

                tw.WriteStartElement("CodiceOperatoreSDC")
                tw.WriteString(row.CodiceOperatoreSDC)
                tw.WriteEndElement()

                tw.WriteStartElement("Amministratore")
                tw.WriteString(row.Amministratore.ToString)
                tw.WriteEndElement()

                tw.WriteStartElement("Abilitato")
                tw.WriteString(row.Abilitato.ToString)
                tw.WriteEndElement()

                tw.WriteStartElement("DataInizioValidita")
                If Not row.IsTSIniValiditaNull Then
                    tw.WriteString(row.TSIniValidita.ToString("dd/MM/yyyy"))
                End If
                tw.WriteEndElement()

                tw.WriteStartElement("DataFineValidita")
                If Not row.IsTSEndValiditaNull Then
                    tw.WriteString(row.TSEndValidita.ToString("dd/MM/yyyy"))
                End If
                tw.WriteEndElement()

                tw.WriteStartElement("CodiceRuolo")
                If Not row.IsCodiceRuoloNull Then
                    tw.WriteString(row.CodiceRuolo)
                End If
                tw.WriteEndElement()

                tw.WriteStartElement("DataUltimaModifica")
                tw.WriteString(row.TSModifica.ToString("dd/MM/yyyy"))
                tw.WriteEndElement()

                tw.WriteEndElement()
            Next

            tw.WriteEndDocument()
            tw.Flush()

#If DEBUG Then
            Dim s As String = Encoding.UTF8.GetString(ms.ToArray())
#End If
            Return ms.ToArray()
        Catch ex As Exception
            Throw
        Finally
            ms.Close()
            tw.Close()
        End Try
    End Function


    Class OperatoriUtenti
        '======================= VARIABILI PRIVATE ==================================
        Private _CodiceOperatoreSDC As String
        Private _CodiceUtenteSDC As String
        Private _Amministratore As Integer
        Private _Abilitato As Boolean
        Private _TSIniValidita As DateTime
        Private _TSEndValidita As DateTime
        Private _CodiceRuolo As String
        Private _TSModifica As DateTime

        '======================= COSTRUTTORI ==================================
        Public Sub New()

        End Sub

        '======================= PROPRIETA` ==================================
        ' CODICE OPERATORE SDC
        Public Property CodiceOperatoreSDC() As String
            Get
                Return Me._CodiceOperatoreSDC
            End Get
            Set(ByVal Value As String)
                Me._CodiceOperatoreSDC = Value
            End Set
        End Property

        ' CODICE UTENTE SDC
        Public Property CodiceUtenteSDC() As String
            Get
                Return Me._CodiceUtenteSDC
            End Get
            Set(ByVal Value As String)
                Me._CodiceUtenteSDC = Value
            End Set
        End Property

        ' AMMINISTRATORE
        Public Property Amministratore() As Integer
            Get
                Return Me._Amministratore
            End Get
            Set(ByVal Value As Integer)
                Me._Amministratore = Value
            End Set
        End Property

        ' ABILITATO
        Public Property Abilitato() As Boolean
            Get
                Return Me._Abilitato
            End Get
            Set(ByVal Value As Boolean)
                Me._Abilitato = Value
            End Set
        End Property

        ' DATA INIZIO VALIDITA
        Public Property TSIniValidita() As DateTime
            Get
                Return Me._TSIniValidita
            End Get
            Set(ByVal Value As DateTime)
                Me._TSIniValidita = Value
            End Set
        End Property

        ' DATA FINE VALIDITA
        Public Property TSEndValidita() As DateTime
            Get
                Return Me._TSEndValidita
            End Get
            Set(ByVal Value As DateTime)
                Me._TSEndValidita = Value
            End Set
        End Property

        ' CODICE RUOLO
        Public Property CodiceRuolo() As String
            Get
                Return Me._CodiceRuolo
            End Get
            Set(ByVal Value As String)
                Me._CodiceRuolo = Value
            End Set
        End Property

        ' DATA DI ULTIMA MODIFICA
        Public Property TSModifica() As DateTime
            Get
                Return Me._TSModifica
            End Get
            Set(ByVal Value As DateTime)
                Me._TSModifica = Value
            End Set
        End Property
    End Class


#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents daUtentiOperatori As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdSelectOperatoriUtenti As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.daUtentiOperatori = New System.Data.SqlClient.SqlDataAdapter
        Me.cmdSelectOperatoriUtenti = New System.Data.SqlClient.SqlCommand
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persist" & _
        " security info=True;initial catalog=Bilaterali;password=bilaterali"
        '
        'daUtentiOperatori
        '
        Me.daUtentiOperatori.SelectCommand = Me.cmdSelectOperatoriUtenti
        Me.daUtentiOperatori.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "RelOperatoriUtenti", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("Amministratore", "Amministratore"), New System.Data.Common.DataColumnMapping("Abilitato", "Abilitato"), New System.Data.Common.DataColumnMapping("TSIniValidita", "TSIniValidita"), New System.Data.Common.DataColumnMapping("CodiceRuolo", "CodiceRuolo"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica")})})
        '
        'cmdSelectOperatoriUtenti
        '
        Me.cmdSelectOperatoriUtenti.CommandText = "SELECT CodiceUtenteSDC, CodiceOperatoreSDC, Amministratore, Abilitato, TSIniValid" & _
        "ita, TSEndValidita, CodiceRuolo, TSModifica FROM dbo.RelOperatoriUtenti"
        Me.cmdSelectOperatoriUtenti.Connection = Me.cn

    End Sub

#End Region

End Class
