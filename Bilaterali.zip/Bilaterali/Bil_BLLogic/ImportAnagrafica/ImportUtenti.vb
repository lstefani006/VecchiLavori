Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema

Public Class ImportUtenti
    Inherits BilBLBase

    Public Function InserisciUtentiAsync(ByVal oby As Bil.FileStore.InfoEvento, ByVal runningOperator As String) As String
        'BatchSerializer.BS.AddBatch(AddressOf ImportUtenti.ElaboraAsyncImportUtenti, by, "IMP_UTENTI", "Import Utenti", DateTime.MinValue, runningOperator)
        BatchSerializer.BS.AddBatch(AddressOf ImportUtenti.ElaboraAsyncImportUtenti, oby, oby.CodiceTipoFile, oby.DescrizioneFile, DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Public Function AllineaAnagraficaAsync(ByVal runningOperator As String) As String
        BatchSerializer.BS.AddBatch(AddressOf ImportUtenti.ElaboraAsyncAllineaUtenti, Nothing, "ALLGN_UTENTI", "Allineamento Utenti", DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Private Shared Sub ElaboraAsyncImportUtenti(ByVal o As Object)

        Dim bl As New ImportUtenti
        Dim r As String = bl.InserisciUtenti(o)

        If r <> "OK" Then
            BatchSerializer.BS.SetProgressBatch(r)
        Else
            BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")
        End If

        bl.Dispose()
    End Sub

    Private Shared Sub ElaboraAsyncAllineaUtenti(ByVal o As Object)
        Dim bl As New ImportUtenti
        Dim r As String = bl.CopiaSDC_Utenti()

        If r <> "OK" Then
            BatchSerializer.BS.SetProgressBatch(r)
        Else
            BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")
        End If

        bl.Dispose()
    End Sub

    Private Sub InsertInSDC_Utenti(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal CodiceUtenteSDC As String, ByVal Nome As String, ByVal Cognome As String, ByVal Telefono As String, ByVal Fax As String, ByVal Email As String, ByVal DN As String, ByVal Login As String, ByVal Pwd As String, ByVal Lingua As String, ByVal CodiceFiscale As String, ByVal Abilitato As Boolean, ByVal ResponsabileAggiornamento As String, ByVal Certificato As String, ByVal CertificatoFirma As String)

        Dim cmdSql As New SqlClient.SqlCommand

        Dim cmdUpdate, cmdInsert As String

        cmdUpdate = "UPDATE SDC_Utenti SET "
        cmdUpdate = cmdUpdate + " Nome = @Nome, Cognome = @Cognome, Telefono = @Telefono, Fax = @Fax, Email = @Email, "
        cmdUpdate = cmdUpdate + " DN = @DN, Login = @Login, Pwd = @Pwd, Lingua = @Lingua, CodiceFiscale = @CodiceFiscale, "
        cmdUpdate = cmdUpdate + " Abilitato = @Abilitato, TSModifica = @TSModifica, ResponsabileAggiornamento = @ResponsabileAggiornamento, "
        cmdUpdate = cmdUpdate + " Certificato = @Certificato, CertificatoFirma = @CertificatoFirma "
        cmdUpdate = cmdUpdate + " WHERE "
        cmdUpdate = cmdUpdate + " (CodiceUtenteSDC = @CodiceUtenteSDC) "

        cmdInsert = "INSERT INTO SDC_Utenti "
        cmdInsert = cmdInsert + " (CodiceUtenteSDC, Nome, Cognome, Telefono, Fax, Email, "
        cmdInsert = cmdInsert + " DN, Login, Pwd, Lingua, CodiceFiscale, "
        cmdInsert = cmdInsert + " Abilitato, TSModifica, ResponsabileAggiornamento, "
        cmdInsert = cmdInsert + " Certificato, CertificatoFirma) "
        cmdInsert = cmdInsert + " VALUES "
        cmdInsert = cmdInsert + " (@CodiceUtenteSDC, @Nome, @Cognome, @Telefono, @Fax, @Email, "
        cmdInsert = cmdInsert + " @DN, @Login, @Pwd, @Lingua, @CodiceFiscale, "
        cmdInsert = cmdInsert + " @Abilitato, @TSModifica, @ResponsabileAggiornamento, "
        cmdInsert = cmdInsert + " @Certificato, @CertificatoFirma) "

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@CodiceUtenteSDC", CodiceUtenteSDC.ToUpper)
        cmdSql.Parameters.Add("@Nome", Nome)
        cmdSql.Parameters.Add("@Cognome", Cognome)
        cmdSql.Parameters.Add("@Telefono", Telefono)
        cmdSql.Parameters.Add("@Fax", Fax)
        cmdSql.Parameters.Add("@Email", Email)
        cmdSql.Parameters.Add("@DN", DN)
        cmdSql.Parameters.Add("@Login", Login)
        cmdSql.Parameters.Add("@Pwd", Pwd)
        cmdSql.Parameters.Add("@Lingua", Lingua)
        cmdSql.Parameters.Add("@CodiceFiscale", CodiceFiscale)
        cmdSql.Parameters.Add("@Abilitato", Abilitato)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)
		cmdSql.Parameters.Add("@ResponsabileAggiornamento", ResponsabileAggiornamento)
		If Certificato Is Nothing Then
			cmdSql.Parameters.Add("@Certificato", SqlDbType.Image).Value = DBNull.Value
		Else
			cmdSql.Parameters.Add("@Certificato", Convert.FromBase64String(Certificato))
		End If
		If CertificatoFirma Is Nothing Then
			cmdSql.Parameters.Add("@CertificatoFirma", SqlDbType.Image).Value = DBNull.Value
		Else
			cmdSql.Parameters.Add("@CertificatoFirma", Convert.FromBase64String(CertificatoFirma))
		End If

		Dim esiste As Boolean = False
		Try
			cmdSql.ExecuteNonQuery()
		Catch ex As Exception
			'If (ex.Message.ToUpper.IndexOf("SDC_UTENTI_PK") >= 0) OrElse (ex.Message.ToUpper.IndexOf("LOGINIX") >= 0) Then
			If (ex.Message.ToUpper.IndexOf("SDC_UTENTI_PK") >= 0) Then
				' Se il CodiceUtenteSDC (PK) esiste gia` => faccio un update
				esiste = True
			ElseIf (ex.Message.ToUpper.IndexOf("LOGINIX") >= 0) Then
				' Se il Login (IX unique) esiste gia` => errore
				Throw
			Else
				' se ha fallito per qualunque altro motivo => lancio l'eccezione
				Throw
			End If
		End Try

		If esiste = True Then
			cmdSql.CommandText = cmdUpdate

			cmdSql.Parameters.Clear()
			cmdSql.Parameters.Add("@CodiceUtenteSDC", CodiceUtenteSDC)
			cmdSql.Parameters.Add("@Nome", Nome)
			cmdSql.Parameters.Add("@Cognome", Cognome)
			cmdSql.Parameters.Add("@Telefono", Telefono)
			cmdSql.Parameters.Add("@Fax", Fax)
			cmdSql.Parameters.Add("@Email", Email)
			cmdSql.Parameters.Add("@DN", DN)
			cmdSql.Parameters.Add("@Login", Login)
			cmdSql.Parameters.Add("@Pwd", Pwd)
			cmdSql.Parameters.Add("@Lingua", Lingua)
			cmdSql.Parameters.Add("@CodiceFiscale", CodiceFiscale)
			cmdSql.Parameters.Add("@Abilitato", Abilitato)
			cmdSql.Parameters.Add("@TSModifica", TimeStamp)
			cmdSql.Parameters.Add("@ResponsabileAggiornamento", ResponsabileAggiornamento)
			If Certificato Is Nothing Then
				cmdSql.Parameters.Add("@Certificato", SqlDbType.Image).Value = DBNull.Value
			Else
				cmdSql.Parameters.Add("@Certificato", Convert.FromBase64String(Certificato))
			End If
			If CertificatoFirma Is Nothing Then
				cmdSql.Parameters.Add("@CertificatoFirma", SqlDbType.Image).Value = DBNull.Value
			Else
				cmdSql.Parameters.Add("@CertificatoFirma", Convert.FromBase64String(CertificatoFirma))
			End If

			Dim numrow As Integer = cmdSql.ExecuteNonQuery()
			If numrow = 0 Then
				Throw New Exception("Fallito UPDATE su tabella SDC_Utenti.")
			End If
		End If

    End Sub

    'Public Function InserisciUtenti(ByVal by() As Byte) As String
    '    Dim contentFileXML As String = Encoding.UTF8.GetString(by)
    '    Return InserisciUtenti(contentFileXML)
    'End Function

    'Public Function InserisciUtenti(ByVal fileXML As String) As String

    '    ' Ritornera' "OK" se tutto e' andato bene altrimenti
    '    ' il relativo messaggio di errore
    '    InserisciUtenti = "OK"

    '    Dim cn As New SqlConnection
    '    Dim tr As SqlTransaction = Nothing

    '    ' Lettura dell'xml e inserimento dati sul DB
    '    Dim _doc As New XmlDocument

    '    Try
    '        _doc.LoadXml(fileXML)

    '        'Dim nsm As New XmlNamespaceManager(_doc.NameTable)
    '        'nsm.AddNamespace("df", "urn:XML-PIPE")

    '        Dim root As XmlElement = _doc.DocumentElement
    '        'Dim nPIPTransaction As XmlNodeList = root.SelectNodes("df:PIPTransaction/df:RelevantExchangePoint", nsm)
    '        Dim nPIPTransaction As XmlNodeList = root.SelectNodes("Utente")

    '        Dim i As Integer
    '        Dim CodiceUtenteSDC, Nome, Cognome, Telefono, Fax, Email, DN, Login, Pwd, Lingua, CodiceFiscale, ResponsabileAggiornamento As String
    '        Dim Abilitato As Boolean

    '        ' Apro la connessione al DB
    '        cn.ConnectionString = GetConnectionString()
    '        cn.Open()
    '        tr = cn.BeginTransaction()

    '        Dim n As XmlNode
    '        For i = 0 To nPIPTransaction.Count - 1

    '            'n = nPIPTransaction(i).SelectSingleNode("./df:CodiceUtenteSDC", nsm)
    '            n = nPIPTransaction(i).SelectSingleNode("./CodiceUtenteSDC")
    '            CodiceUtenteSDC = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./Nome")
    '            Nome = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./Cognome")
    '            Cognome = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./Telefono")
    '            Telefono = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./Fax")
    '            Fax = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./Email")
    '            Email = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./DN")
    '            DN = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./Login")
    '            Login = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./Pwd")
    '            Pwd = n.InnerText

    '            n = nPIPTransaction(i).SelectSingleNode("./Lingua")
    '            Lingua = n.InnerText
    '            If (Lingua <> "IT-it") And (Lingua <> "EN-us") Then
    '                Throw New Exception("Campo 'Lingua' di uno o piu' utenti errato!")
    '            End If

    '            n = nPIPTransaction(i).SelectSingleNode("./CodiceFiscale")
    '            CodiceFiscale = n.InnerText

    '            Dim s As String
    '            n = nPIPTransaction(i).SelectSingleNode("./Abilitato")
    '            s = n.InnerText
    '            If (s.ToUpper() = "TRUE") Then
    '                Abilitato = True
    '            Else
    '                Abilitato = False
    '            End If

    '            ResponsabileAggiornamento = ""

    '            ' Inserimento dati nella tabella SDC_PuntiDiScambioRilevanti
    '            InsertInSDC_Utenti(cn, tr, CodiceUtenteSDC, Nome, Cognome, Telefono, Fax, Email, DN, Login, Pwd, Lingua, CodiceFiscale, Abilitato, ResponsabileAggiornamento)

    '        Next

    '        tr.Commit()

    '    Catch ex As Exception
    '        smError(ex)
    '        If (Not tr Is Nothing) Then tr.Rollback()
    '        Return ex.Message
    '    Finally
    '        cn.Close()
    '    End Try

    'End Function

    Public Function InserisciUtenti(ByVal o As Object) As String
        Dim blFS As Bil.FileStore
        Dim TSFile As DateTime
        Dim IdFile As Integer

        Dim blInfoEvt As Bil.FileStore.InfoEvento
        Dim xmlContent() As Byte

        Try
            blInfoEvt = DirectCast(o, Bil.FileStore.InfoEvento)
            xmlContent = blInfoEvt.ContenutoFile
            blFS = New Bil.FileStore
            blFS.InsertFile(blInfoEvt, TSFile, IdFile)
        Catch ex As Exception
            smError(ex)
            Throw
        End Try

        Dim message As String
        Try
            ParseXML(xmlContent)

            message = "Import Utenti: terminato con successo"
            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes(message)

            blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Return "OK"
        Catch ex As Exception
            message = "Import Utenti fallito con eccezione" + ex.Message
            smError(ex, ex.Message)
			Dim byFA() As Byte = (New UnicodeEncoding).GetBytes(message)

            blFS.UpdateFAFile(TSFile, IdFile, byFA)
            Return ex.Message
        End Try
        smError("Eseguito Import Utenti")
    End Function

    Private Sub InsertInUtenti(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal codiceUtenteSDC As String)
        Dim cmdSql As New SqlClient.SqlCommand

        Dim cmdUpdate, cmdInsert As String

        cmdUpdate = "UPDATE Utenti SET "
        'cmdUpdate = cmdUpdate + " StatoBilateraliUtente = @StatoBilateraliUtente, TSModifica = @TSModifica "
        cmdUpdate = cmdUpdate + " TSModifica = @TSModifica "
        cmdUpdate = cmdUpdate + " WHERE "
        cmdUpdate = cmdUpdate + "(CodiceUtenteSDC = @CodiceUtenteSDC) "


        cmdInsert = "INSERT INTO Utenti "
        cmdInsert = cmdInsert + "(CodiceUtenteSDC, StatoBilateraliUtente, TSModifica) "
        cmdInsert = cmdInsert + " VALUES "
        cmdInsert = cmdInsert + "(@CodiceUtenteSDC, @StatoBilateraliUtente, @TSModifica) "

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@CodiceUtenteSDC", codiceUtenteSDC)
        cmdSql.Parameters.Add("@StatoBilateraliUtente", True)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)

        Dim esiste As Boolean = False
        Try
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            If ex.Message.ToUpper.IndexOf("UTENTI_PK") >= 0 Then
                ' Se la riga esiste => faccio un update
                esiste = True
            Else
                ' se ha fallito per qualunque altro motivo => lancio l'eccezione
                Throw
            End If
        End Try

        If esiste = True Then
            cmdSql.CommandText = cmdUpdate

            cmdSql.Parameters.Clear()
            cmdSql.Parameters.Add("@CodiceUtenteSDC", codiceUtenteSDC)
            'cmdSql.Parameters.Add("@StatoBilateraliUtente", True)
            cmdSql.Parameters.Add("@TSModifica", TimeStamp)

            Dim numrow As Integer = cmdSql.ExecuteNonQuery()
            If numrow = 0 Then
                Throw New Exception("Fallito UPDATE su tabella Utenti.")
            End If
        End If

    End Sub

    Public Function CopiaSDC_Utenti() As String

        smTrace("Allineamento anagrafica utenti: inizio elaborazione")

        ' Ritornera' "OK" se tutto e' andato bene altrimenti
        ' il relativo messaggio di errore
        CopiaSDC_Utenti = "OK"

        Dim cn As New SqlConnection
        Dim tr As SqlTransaction = Nothing

        Try
            ' Apro la connessione al DB
            cn.ConnectionString = GetConnectionString()
            cn.Open()
            tr = cn.BeginTransaction()

            Dim dsSDCUtenti As DS_SDC_Utenti
            Dim cSDCUtenti As New SDCUtenti
            dsSDCUtenti = cSDCUtenti.GetSDC_Utenti()

            Dim i As Integer
            For i = 0 To dsSDCUtenti.SDC_Utenti.Count - 1
                InsertInUtenti(cn, tr, dsSDCUtenti.SDC_Utenti(i).CodiceUtenteSDC)
            Next

            If Not tr Is Nothing Then tr.Commit() : tr = Nothing

            smTrace("Allineamento anagrafica utenti: elaborazione terminata con successo")

        Catch ex As Exception
            smError(ex, "Allineamento anagrafica utenti: esecuzione fallita")
            Return ex.Message

        Finally
            If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try

    End Function

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Private Sub SaveToDB(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal user As Utente)
        Try
            InsertInSDC_Utenti(cn, _
             tr, _
             user.CodiceUtenteSDC, _
             user.Nome, _
             user.Cognome, _
             user.Telefono, _
             user.Fax, _
             user.Email, _
             user.DN, _
             user.Login, _
             user.Password, _
             user.Lingua, _
             user.CodiceFiscale, _
             user.Abilitato, _
             user.ResponsabileAggiornamento, _
             user.Certificato, _
             user.CertificatoFirma)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub ParseXML(ByVal xmlContent() As Byte)
        '======== Codice per validare l'xml con uno schema (per adesso non lo valido) 
        'Dim xr As XmlValidatingReader

        '=================== CONTROLLO SCHEMA PER IL FILE XML =============================================
        'Try
        '    Dim fileSchema As String = Nome File schema
        '    If fileSchema Is Nothing Then
        '        Thow New ApplicationException
        '    End If

        '    Dim sc As XmlSchemaCollection = New XmlSchemaCollection
        '    sc.Add(Nothing, fileSchema)

        '    Dim textReader As XmlTextReader = New XmlTextReader(New MemoryStream(Me._xmlContent))
        '    textReader.WhitespaceHandling = WhitespaceHandling.None
        '    xr = New XmlValidatingReader(textReader)
        '    xr.ValidationType = ValidationType.Schema
        '    xr.Schemas.Add(sc)
        '    ' Evento che gestisce gli errori di Validazione
        '    AddHandler xr.ValidationEventHandler, AddressOf Me.ValidationEvent

        'Catch ex As Exception
        '    Debug.Assert(False, "File schema non trovato")    ' se non trova il file degli schemi
        '    Throw ex
        'End Try

        Dim xr As New XmlTextReader(New MemoryStream(xmlContent))
        Dim cn As New SqlConnection
        Dim tr As SqlTransaction = Nothing
        Dim fileGiusto As Boolean    ' Varra' True se xmlContent e' un file relativo agli utenti

        smTrace("Import utenti: inizio elaborazione")


        fileGiusto = False
        Try
            ' Apro la connessione al DB
            cn.ConnectionString = GetConnectionString()
            cn.Open()
            tr = cn.BeginTransaction()


            Dim cultureInfoIT As New System.Globalization.CultureInfo("it-IT")      ' per leggere i double in italiano

            '======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
            Dim elUtenti As Object = xr.NameTable.Add("Utenti")
            Dim elUtente As Object = xr.NameTable.Add("Utente")
            Dim elCodiceUtenteSDC As Object = xr.NameTable.Add("CodiceUtenteSDC")
            Dim elNome As Object = xr.NameTable.Add("Nome")
            Dim elCognome As Object = xr.NameTable.Add("Cognome")
            Dim elTelefono As Object = xr.NameTable.Add("Telefono")
            Dim elFax As Object = xr.NameTable.Add("Fax")
            Dim elEmail As Object = xr.NameTable.Add("Email")
            Dim elDN As Object = xr.NameTable.Add("DN")
            Dim elLogin As Object = xr.NameTable.Add("Login")
            Dim elPwd As Object = xr.NameTable.Add("Pwd")
            Dim elLingua As Object = xr.NameTable.Add("Lingua")
            Dim elCodiceFiscale As Object = xr.NameTable.Add("CodiceFiscale")
            Dim elAbilitato As Object = xr.NameTable.Add("Abilitato")
            Dim elResponsabileAggiornamento As Object = xr.NameTable.Add("ResponsabileAggiornamento")
            Dim elCertificato As Object = xr.NameTable.Add("Certificato")
            Dim elCertificatoFirma As Object = xr.NameTable.Add("CertificatoFirma")

            Dim currUser As Utente = Nothing

            While (xr.Read())
                Dim xrn As Object = xr.Name

                Select Case xr.NodeType
                    Case XmlNodeType.Element
                        '================== UTENTE ============================
                        If (xrn Is elUtente) Then
                            currUser = New Utente
                            fileGiusto = True

                            '================== CODICE UTENTE SDC ============================
                        ElseIf (xrn Is elCodiceUtenteSDC) Then
                            Dim xmlData As String = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currUser.CodiceUtenteSDC = xmlData
                            Else
                                Throw New ApplicationException("Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If

                            '================== NOME ============================
                        ElseIf (xrn Is elNome) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Nome = xmlData

                            '================== COGNOME ============================
                        ElseIf (xrn Is elCognome) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Cognome = xmlData

                            '================== TELEFONO ============================
                        ElseIf (xrn Is elTelefono) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Telefono = xmlData

                            '================== FAX ============================
                        ElseIf (xrn Is elFax) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Fax = xmlData

                            '================== EMAIL ============================
                        ElseIf (xrn Is elEmail) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Email = xmlData

                            '================== DN ============================
                        ElseIf (xrn Is elDN) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.DN = xmlData

                            '================== LOGIN ============================
                        ElseIf (xrn Is elLogin) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Login = xmlData

                            '================== PASSWORD ============================
                        ElseIf (xrn Is elPwd) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Password = xmlData

                            '================== LINGUA ============================
                        ElseIf (xrn Is elLingua) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Lingua = xmlData

                            '================== CODICE FISCALE ============================
                        ElseIf (xrn Is elCodiceFiscale) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.CodiceFiscale = xmlData

                            '================== ABILITATO ============================
                        ElseIf (xrn Is elAbilitato) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Abilitato = Boolean.Parse(xmlData)

                            '================== RESPONSABILE AGGIORNAMENTO ============================
                        ElseIf (xrn Is elResponsabileAggiornamento) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.ResponsabileAggiornamento = xmlData

                            '================== CERTIFICATO ============================
                        ElseIf (xrn Is elCertificato) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.Certificato = xmlData

                            '================== CERTIFICATO FIRMA ============================
                        ElseIf (xrn Is elCertificatoFirma) Then
                            Dim xmlData As String = xr.ReadString()
                            currUser.CertificatoFirma = xmlData
                        End If

                    Case XmlNodeType.EndElement
                        If (xrn Is elUtente) Then
                            ' Salvo sul DB l'utente 
                            SaveToDB(cn, tr, currUser)

                            currUser = Nothing
                        End If
                End Select

            End While

            If fileGiusto = True Then
                If Not tr Is Nothing Then tr.Commit() : tr = Nothing
                smTrace("Import utenti: elaborazione terminata con successo")
            Else
                Throw New Exception("File errato: il file inviato non contiene informazione sugli utenti!")
            End If

        Catch ex As Exception
            smError(ex, "ImportUtenti.ParseXML")
            Throw ex
        Finally
            If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
            If Not xr Is Nothing Then xr.Close()
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Sub

    Class Utente
        '======================= VARIABILI PRIVATE ==================================
        Private _codiceUtenteSDC As String
        Private _nome As String
        Private _cognome As String
        Private _telefono As String
        Private _fax As String
        Private _email As String
        Private _dn As String
        Private _login As String
        Private _pwd As String
        Private _lingua As String
        Private _codiceFiscale As String
        Private _abilitato As Boolean
        Private _responsabileAggiornamento As String
        Private _certificato As String
        Private _certificatoFirma As String

        '======================= COSTRUTTORI ==================================
        Public Sub New()

        End Sub

        Public Sub New(ByVal CodiceUtenteSDC As String)
            Me._codiceUtenteSDC = CodiceUtenteSDC
        End Sub

        '======================= PROPRIETA` ==================================
        ' CODICE UTENTE SDC
        Public Property CodiceUtenteSDC() As String
            Get
                Return Me._codiceUtenteSDC
            End Get
            Set(ByVal Value As String)
                Me._codiceUtenteSDC = Value
            End Set
        End Property

        ' NOME
        Public Property Nome() As String
            Get
                Return Me._nome
            End Get
            Set(ByVal Value As String)
                Me._nome = Value
            End Set
        End Property

        ' COGNOME
        Public Property Cognome() As String
            Get
                Return Me._cognome
            End Get
            Set(ByVal Value As String)
                Me._cognome = Value
            End Set
        End Property

        ' TELEFONO
        Public Property Telefono() As String
            Get
                Return Me._telefono
            End Get
            Set(ByVal Value As String)
                Me._telefono = Value
            End Set
        End Property

        ' FAX
        Public Property Fax() As String
            Get
                Return Me._fax
            End Get
            Set(ByVal Value As String)
                Me._fax = Value
            End Set
        End Property

        ' EMAIL
        Public Property Email() As String
            Get
                Return Me._email
            End Get
            Set(ByVal Value As String)
                Me._email = Value
            End Set
        End Property

        ' DN
        Public Property DN() As String
            Get
                Return Me._dn
            End Get
            Set(ByVal Value As String)
                Me._dn = Value
            End Set
        End Property

        ' LOGIN
        Public Property Login() As String
            Get
                Return Me._login
            End Get
            Set(ByVal Value As String)
                Me._login = Value
            End Set
        End Property

        ' PASSWORD
        Public Property Password() As String
            Get
                Return Me._pwd
            End Get
            Set(ByVal Value As String)
                Me._pwd = Value
            End Set
        End Property

        ' LINGUA
        Public Property Lingua() As String
            Get
                Return Me._lingua
            End Get
            Set(ByVal Value As String)
                Me._lingua = Value
            End Set
        End Property

        ' CODICE FISCALE
        Public Property CodiceFiscale() As String
            Get
                Return Me._codiceFiscale
            End Get
            Set(ByVal Value As String)
                Me._codiceFiscale = Value
            End Set
        End Property

        ' ABILITATO
        Public Property Abilitato() As Boolean
            Get
                Return Me._abilitato
            End Get
            Set(ByVal Value As Boolean)
                Me._abilitato = Value
            End Set
        End Property

        ' RESPONSABILE AGGIORNAMENTO
        Public Property ResponsabileAggiornamento() As String
            Get
                Return Me._responsabileAggiornamento
            End Get
            Set(ByVal Value As String)
                Me._responsabileAggiornamento = Value
            End Set
        End Property

        ' CERTIFICATO
        Public Property Certificato() As String
            Get
                Return Me._certificato
            End Get
            Set(ByVal Value As String)
                Me._certificato = Value
            End Set
        End Property

        ' CERTIFICATO FIRMA
        Public Property CertificatoFirma() As String
            Get
                Return Me._certificatoFirma
            End Get
            Set(ByVal Value As String)
                Me._certificatoFirma = Value
            End Set
        End Property

    End Class

End Class
