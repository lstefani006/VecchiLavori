Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema

Public Class ImportUnita
	Inherits BilBLBase

    Public Function InserisciUnitaAsync(ByVal oby As Bil.FileStore.InfoEvento, ByVal runningOperator As String) As String
        'BatchSerializer.BS.AddBatch(AddressOf ImportUnita.ElaboraAsyncImportUnita, by, "IMP_UNITA", "Import Unita`", DateTime.MinValue, runningOperator)
        BatchSerializer.BS.AddBatch(AddressOf ImportUnita.ElaboraAsyncImportUnita, oby, oby.CodiceTipoFile, oby.DescrizioneFile, DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Public Function AllineaAnagraficaAsync(ByVal runningOperator As String) As String
        BatchSerializer.BS.AddBatch(AddressOf ImportUnita.ElaboraAsyncAllineaUnita, Nothing, "ALLGN_UNITA", "Allineamento Unita`", DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
    End Function

    Private Shared Sub ElaboraAsyncImportUnita(ByVal o As Object)
        Dim oby As Bil.FileStore.InfoEvento = DirectCast(o, Bil.FileStore.InfoEvento)
        Dim bl As New ImportUnita
        bl.InserisciUnita(oby)

        BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")

        bl.Dispose()
    End Sub

    Private Shared Sub ElaboraAsyncAllineaUnita(ByVal o As Object)
        Dim bl As New ImportUnita
        bl.AllineaAnagrafica()

        BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")

        bl.Dispose()
    End Sub


    Private Function dbv(ByVal s As Object) As Object
        If s Is Nothing Then Return String.Empty 'DBNull.Value
        Return s
    End Function


    Private Sub InserisciUnita(ByVal blInfoEvt As Bil.FileStore.InfoEvento)

        smTrace("Import unita`: inizio elaborazione")
        Dim blFS As Bil.FileStore
        Dim TSFile As DateTime
        Dim IdFile As Integer

        smTrace("Import Unita`: inizio attivita'")

        Try
            blFS = New Bil.FileStore
            blFS.InsertFile(blInfoEvt, TSFile, IdFile)
        Catch ex As Exception
            smError(ex, "Import Unita`")
            Throw
        End Try

        Dim by() As Byte = blInfoEvt.ContenutoFile
        SaveUploadFile("Unita", by)

        Dim message As String
        Try
            ParseXML(by)

            message = "Import Unita`: elaborazione terminata con successo"
            smTrace(message)
            Dim byFA() As Byte = (New UnicodeEncoding).GetBytes(message)
            blFS.UpdateFAFile(TSFile, IdFile, byFA)

        Catch ex As Exception
            message = "Import Unita` fallito con eccezione"
            smTrace(message)

            BatchSerializer.BS.SetProgressBatch("Elaborazione fallita: " + ex.Message)
            Throw
        End Try

        smError("Eseguito Import Unita`")
    End Sub

    Private Sub InsertInSDC_UnitaMarketInformation(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal unitReferenceNumber As String, ByVal categoriaUnita As String, ByVal codiceMercato As String, ByVal eligibility As String)

        Dim cmdSql As New SqlClient.SqlCommand

        Dim cmdUpdate, cmdInsert As String

        cmdUpdate = "UPDATE SDC_Unita_MarketInformation SET "
        cmdUpdate = cmdUpdate + " Eligibility = @Eligibility "
        cmdUpdate = cmdUpdate + " WHERE "
        cmdUpdate = cmdUpdate + "(CodiceUnitaSDC = @CodiceUnitaSDC) And (CategoriaUnitaSDC = @CategoriaUnitaSDC) And (MarketCode = @CodiceMercato) "

        cmdInsert = "INSERT INTO SDC_Unita_MarketInformation "
        cmdInsert = cmdInsert + "(CodiceUnitaSDC, CategoriaUnitaSDC, MarketCode, Eligibility) "
        cmdInsert = cmdInsert + " VALUES "
        cmdInsert = cmdInsert + "(@CodiceUnitaSDC, @CategoriaUnitaSDC, @CodiceMercato, @Eligibility) "

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@CodiceUnitaSDC", unitReferenceNumber.ToUpper())
        cmdSql.Parameters.Add("@CategoriaUnitaSDC", categoriaUnita)
        cmdSql.Parameters.Add("@CodiceMercato", codiceMercato)
        cmdSql.Parameters.Add("@Eligibility", eligibility)

        Dim esiste As Boolean = False
        Try
            cmdSql.CommandTimeout = AppSettingToInt32("ImportUnitaQueryTmo", 120)
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            If ex.Message.ToUpper.IndexOf("PK_SDC_UNITA_MARKETINFORMATION") >= 0 Then
                ' Se la riga esiste => faccio un update
                esiste = True
            Else
                ' se ha fallito per qualunque altro motivo => lancio l'eccezione
                Throw
            End If
        End Try

        If esiste = True Then
            cmdSql.CommandText = cmdUpdate

            cmdSql.Parameters.Clear()
            cmdSql.Parameters.Add("@CodiceUnitaSDC", unitReferenceNumber.ToUpper())
            cmdSql.Parameters.Add("@CategoriaUnitaSDC", categoriaUnita)
            cmdSql.Parameters.Add("@CodiceMercato", codiceMercato)
            cmdSql.Parameters.Add("@Eligibility", eligibility)

            cmdSql.CommandTimeout = AppSettingToInt32("ImportUnitaQueryTmo", 120)
            Dim numrow As Integer = cmdSql.ExecuteNonQuery()
            If numrow = 0 Then
                Throw New Exception("Fallito UPDATE su tabella SDC_Unita_MarketInformation.")
            End If
        End If

    End Sub

    Private Sub InsertInSDC_Unita(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal unitReferenceNumber As String, ByVal category As String, ByVal unitName As String, ByVal unitType As String, ByVal subType As String, ByVal trasmissionLossFactor As Double, ByVal gridSupplyPoint As String, ByVal maxPower As Double, ByVal minPower As Double, ByVal meritOrder As Double, ByVal referenceMarketParticipantNumber As String, ByVal statusCode As String, ByVal unbalancedParticipantNumber As String, ByVal responsabileAggiornamento As String, ByVal mustRun As String, ByVal InjectionOrWithdrawalPointNumber As String)

        Dim cmdSql As New SqlClient.SqlCommand

        Dim tipo As String
        Dim status As Boolean
        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now


        Dim cmdInsert As String
        cmdInsert = "INSERT INTO SDC_Unita "
        cmdInsert += "(CodiceUnitaSDC, CategoriaUnitaSDC, NomeUnita, TipoUnita, SottotipoUnita, CoefficientePerdita, "
        cmdInsert += " CodicePuntoDiScambioRilevanteSDC, PotenzaMassimaMWh, PotenzaMinimaMWh, "
        cmdInsert += " OrdineDiMerito, CodiceOperatoreDiRiferimentoSDC, Abilitata, TSModifica, ResponsabileAggiornamento,"
        cmdInsert += " UnbalancedParticipantNumber, MustRun, InjectionOrWithdrawalPointNumber) "
        cmdInsert += " VALUES "
        cmdInsert += "(@CodiceUnitaSDC, @CategoriaUnitaSDC, @NomeUnita, @TipoUnita, @SottotipoUnita, @CoefficientePerdita, "
        cmdInsert += " @CodicePuntoDiScambioRilevanteSDC, @PotenzaMassimaMWh, @PotenzaMinimaMWh, "
        cmdInsert += " @OrdineDiMerito, @CodiceOperatoreDiRiferimentoSDC, @Abilitata, @TSModifica, @ResponsabileAggiornamento, "
        cmdInsert += " @UnbalancedParticipantNumber, @mustRun, @InjectionOrWithdrawalPointNumber) "


        cmdSql.Parameters.Clear()

        cmdSql.Parameters.Add("@CodiceUnitaSDC", unitReferenceNumber.ToUpper())
        cmdSql.Parameters.Add("@CategoriaUnitaSDC", category)

        cmdSql.Parameters.Add("@NomeUnita", dbv(unitName))
        If (unitType.ToUpper() = "PRODUCTION") Then
            tipo = "P"
        ElseIf (unitType.ToUpper() = "CONSUMPTION") Then
            tipo = "C"
        ElseIf (unitType.ToUpper() = "BOTH") Then
            tipo = "M"
        End If
        cmdSql.Parameters.Add("@TipoUnita", tipo)
        cmdSql.Parameters.Add("@SottotipoUnita", dbv(subType))
        cmdSql.Parameters.Add("@CoefficientePerdita", trasmissionLossFactor)
        cmdSql.Parameters.Add("@CodicePuntoDiScambioRilevanteSDC", gridSupplyPoint)
        cmdSql.Parameters.Add("@PotenzaMassimaMWh", maxPower)
        cmdSql.Parameters.Add("@PotenzaMinimaMWh", minPower)
        cmdSql.Parameters.Add("@OrdineDiMerito", meritOrder)
        cmdSql.Parameters.Add("@CodiceOperatoreDiRiferimentoSDC", referenceMarketParticipantNumber)
        status = False
        If (statusCode.ToUpper() = "ENABLED") Then
            status = True
        End If
        cmdSql.Parameters.Add("@Abilitata", status)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)
        cmdSql.Parameters.Add("@ResponsabileAggiornamento", dbv(responsabileAggiornamento))
        If unbalancedParticipantNumber Is Nothing Then
            cmdSql.Parameters.Add("@UnbalancedParticipantNumber", String.Empty)
        Else
            cmdSql.Parameters.Add("@UnbalancedParticipantNumber", unbalancedParticipantNumber)
        End If

        If mustRun Is Nothing Then
            cmdSql.Parameters.Add("@mustRun", DBNull.Value)
        Else
            cmdSql.Parameters.Add("@mustRun", mustRun)
        End If

        If InjectionOrWithdrawalPointNumber Is Nothing Then
            cmdSql.Parameters.Add("@InjectionOrWithdrawalPointNumber", DBNull.Value)
        Else
            cmdSql.Parameters.Add("@InjectionOrWithdrawalPointNumber", InjectionOrWithdrawalPointNumber)
        End If

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim esisteRecord As Boolean = False
        Try
            cmdSql.CommandTimeout = AppSettingToInt32("ImportUnitaQueryTmo", 120)
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            If ex.Message.ToUpper.IndexOf("FK_SDC_UNITA_SDC_OPERATORI1") >= 0 Then
                Throw New Exception("FK_SDC_UNITA_SDC_OPERATORI1:L'unita' " + unitReferenceNumber + " fa riferimento all'operatore " + referenceMarketParticipantNumber + " il quale non e' presente nella tabella Operatori.")
            ElseIf ex.Message.ToUpper.IndexOf("FK_SDC_UNITA_SDC_PUNTIDISCAMBIORILEVANTI") >= 0 Then
                Throw New Exception("FK_SDC_UNITA_SDC_PUNTIDISCAMBIORILEVANTI:L'unita' " + unitReferenceNumber + " fa riferimento al punto di scambio rilevante " + gridSupplyPoint + " il quale non e' presente nella tabella PuntiDiScambioRilevanti.")
            ElseIf ex.Message.ToUpper.IndexOf("SDC_Unita_PK".ToUpper()) >= 0 Then
                esisteRecord = True    ' continuo facendo update
            Else
                ' e` un altro tipo di eccezione
                Throw
            End If
        End Try

        If esisteRecord = False Then
            Return
        End If

        Dim cmdUpdate As String
        cmdUpdate = "UPDATE SDC_Unita SET "
        cmdUpdate += " NomeUnita = @NomeUnita, "
        cmdUpdate += " TipoUnita = @TipoUnita, "
        cmdUpdate += " SottotipoUnita = @SottotipoUnita, "
        cmdUpdate += " CoefficientePerdita = @CoefficientePerdita, "
        cmdUpdate += " CodicePuntoDiScambioRilevanteSDC = @CodicePuntoDiScambioRilevanteSDC, "
        cmdUpdate += " PotenzaMassimaMWh = @PotenzaMassimaMWh, "
        cmdUpdate += " PotenzaMinimaMWh = @PotenzaMinimaMWh, "
        cmdUpdate += " OrdineDiMerito = @OrdineDiMerito, "
        cmdUpdate += " CodiceOperatoreDiRiferimentoSDC = @CodiceOperatoreDiRiferimentoSDC, "
        cmdUpdate += " Abilitata = @Abilitata, "
        cmdUpdate += " TSModifica = @TSModifica, "
        cmdUpdate += " ResponsabileAggiornamento = @ResponsabileAggiornamento, "
        cmdUpdate += " UnbalancedParticipantNumber = @UnbalancedParticipantNumber, "
        cmdUpdate += " MustRun = @mustRun, "
        cmdUpdate += " InjectionOrWithdrawalPointNumber=@InjectionOrWithdrawalPointNumber "
        cmdUpdate += " WHERE "
        cmdUpdate += "(CodiceUnitaSDC = @CodiceUnitaSDC) And (CategoriaUnitaSDC = @CategoriaUnitaSDC) "

        cmdSql.CommandText = cmdUpdate
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@NomeUnita", dbv(unitName))
        If (unitType.ToUpper() = "PRODUCTION") Then
            tipo = "P"
        ElseIf (unitType.ToUpper() = "CONSUMPTION") Then
            tipo = "C"
        ElseIf (unitType.ToUpper() = "BOTH") Then
            tipo = "M"
        End If
        cmdSql.Parameters.Add("@TipoUnita", tipo)
        cmdSql.Parameters.Add("@SottotipoUnita", dbv(subType))
        cmdSql.Parameters.Add("@CoefficientePerdita", trasmissionLossFactor)
        cmdSql.Parameters.Add("@CodicePuntoDiScambioRilevanteSDC", gridSupplyPoint)
        cmdSql.Parameters.Add("@PotenzaMassimaMWh", maxPower)
        cmdSql.Parameters.Add("@PotenzaMinimaMWh", minPower)
        cmdSql.Parameters.Add("@OrdineDiMerito", meritOrder)
        cmdSql.Parameters.Add("@CodiceOperatoreDiRiferimentoSDC", referenceMarketParticipantNumber)
        status = False
        If (statusCode.ToUpper() = "ENABLED") Then
            status = True
        End If
        cmdSql.Parameters.Add("@Abilitata", status)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)
        cmdSql.Parameters.Add("@ResponsabileAggiornamento", dbv(responsabileAggiornamento))
        If unbalancedParticipantNumber Is Nothing Then
            cmdSql.Parameters.Add("@UnbalancedParticipantNumber", String.Empty)
        Else
            cmdSql.Parameters.Add("@UnbalancedParticipantNumber", unbalancedParticipantNumber)
        End If

        If mustRun Is Nothing Then
            cmdSql.Parameters.Add("@mustRun", DBNull.Value)
        Else
            cmdSql.Parameters.Add("@mustRun", mustRun)
        End If

        If InjectionOrWithdrawalPointNumber Is Nothing Then
            cmdSql.Parameters.Add("@InjectionOrWithdrawalPointNumber", DBNull.Value)
        Else
            cmdSql.Parameters.Add("@InjectionOrWithdrawalPointNumber", InjectionOrWithdrawalPointNumber)
        End If

        cmdSql.Parameters.Add("@CodiceUnitaSDC", unitReferenceNumber.ToUpper())
        cmdSql.Parameters.Add("@CategoriaUnitaSDC", category)

        Try
            cmdSql.CommandTimeout = AppSettingToInt32("ImportUnitaQueryTmo", 120)
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            If ex.Message.ToUpper.IndexOf("FK_SDC_UNITA_SDC_OPERATORI1") >= 0 Then
                Throw New Exception("FK_SDC_UNITA_SDC_OPERATORI1:L'unita' " + unitReferenceNumber + " fa riferimento all'operatore " + referenceMarketParticipantNumber + " il quale non e' presente nella tabella Operatori.")
            ElseIf ex.Message.ToUpper.IndexOf("FK_SDC_UNITA_SDC_PUNTIDISCAMBIORILEVANTI") >= 0 Then
                Throw New Exception("FK_SDC_UNITA_SDC_PUNTIDISCAMBIORILEVANTI:L'unita' " + unitReferenceNumber + " fa riferimento al punto di scambio rilevante " + gridSupplyPoint + " il quale non e' presente nella tabella PuntiDiScambioRilevanti.")
            Else
                ' e` un altro tipo di eccezione
                Throw
            End If
        End Try

    End Sub

    Private Sub InsertInUnita(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal codiceUnitaSDC As String, ByVal categoriaUnitaSDC As String)

        Dim cmdSql As New SqlClient.SqlCommand

        Dim cmdUpdate, cmdInsert As String

        cmdUpdate = "UPDATE Unita SET "
        'cmdUpdate = cmdUpdate + " StatoBilateraliUnita = @StatoBilateraliUnita, TSModifica = @TSModifica "
        cmdUpdate = cmdUpdate + " TSModifica = @TSModifica "
        cmdUpdate = cmdUpdate + " WHERE "
        cmdUpdate = cmdUpdate + "(CodiceUnitaSDC = @CodiceUnitaSDC) And (CategoriaUnitaSDC = @CategoriaUnitaSDC) "


        cmdInsert = "INSERT INTO Unita "
        cmdInsert = cmdInsert + "(CodiceUnitaSDC, CategoriaUnitaSDC, StatoBilateraliUnita, TSModifica) "
        cmdInsert = cmdInsert + " VALUES "
        cmdInsert = cmdInsert + "(@CodiceUnitaSDC, @CategoriaUnitaSDC, @StatoBilateraliUnita, @TSModifica) "

        cmdSql.CommandText = cmdInsert
        cmdSql.Connection = cn
        cmdSql.Transaction = tr

        Dim TimeStamp As DateTime
        TimeStamp = DateTime.Now

        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add("@CodiceUnitaSDC", codiceUnitaSDC.ToUpper())
        cmdSql.Parameters.Add("@CategoriaUnitaSDC", categoriaUnitaSDC)
        cmdSql.Parameters.Add("@StatoBilateraliUnita", True)
        cmdSql.Parameters.Add("@TSModifica", TimeStamp)

        Dim esiste As Boolean = False
        Try
            cmdSql.ExecuteNonQuery()
        Catch ex As Exception
            If ex.Message.ToUpper.IndexOf("UNITA_PK") >= 0 Then
                ' Se la riga esiste => faccio un update
                esiste = True
            Else
                ' se ha fallito per qualunque altro motivo => lancio l'eccezione
                Throw
            End If
        End Try

        If esiste = True Then
            cmdSql.CommandText = cmdUpdate

            cmdSql.Parameters.Clear()
            cmdSql.Parameters.Add("@CodiceUnitaSDC", codiceUnitaSDC.ToUpper())
            cmdSql.Parameters.Add("@CategoriaUnitaSDC", categoriaUnitaSDC)
            'cmdSql.Parameters.Add("@StatoBilateraliUnita", True)
            cmdSql.Parameters.Add("@TSModifica", TimeStamp)

            Dim numrow As Integer = cmdSql.ExecuteNonQuery()
            If numrow = 0 Then
                Throw New Exception("Fallito UPDATE su tabella Unita.")
            End If
        End If

    End Sub

    Private Sub AllineaAnagrafica()

        smTrace("Allineamento anagrafica unita`: inizio elaborazione")


        Dim cn As New SqlConnection
        Dim tr As SqlTransaction = Nothing

        Try
            ' Apro la connessione al DB
            cn.ConnectionString = GetConnectionString()
            cn.Open()
            tr = cn.BeginTransaction()

            Dim dsSDCUnita As DS_SDC_Unita
            Dim cSDCUnita As New SDCUnita
            dsSDCUnita = cSDCUnita.GetSDC_Unita()

            Dim i As Integer
            For i = 0 To dsSDCUnita.SDC_Unita.Count - 1
                InsertInUnita(cn, tr, dsSDCUnita.SDC_Unita(i).CodiceUnitaSDC, dsSDCUnita.SDC_Unita(i).CategoriaUnitaSDC)
            Next

            If Not tr Is Nothing Then tr.Commit() : tr = Nothing

            BatchSerializer.SetProgressBatch("Allineamento anagrafica unita completato con successo")

        Catch ex As Exception

            smError(ex, "Allineamento anagrafica unita`: esecuzione fallita")
            BatchSerializer.SetProgressBatch("Allineamento anagrafica unita` fallito: " + ex.Message)
            Throw

        Finally
            If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try

    End Sub

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Private Sub SaveToDB(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal unit As Unita)
        Try

            InsertInSDC_Unita(cn, _
             tr, _
             unit.CodiceUnitaSDC, _
               unit.CategoriaUnita, _
               unit.Nome, _
               unit.Tipo, _
               unit.SottoTipo, _
               unit.CoefficientePerdita, _
               unit.PuntoScambioRilevante, _
               unit.PotenzaMAX, _
               unit.PotenzaMin, _
               unit.OrdineMerito, _
               unit.ReferenceMarketParticipantNumber, _
               unit.Stato, _
               unit.UnbalancedMarketParticipantNumber, _
               unit.ResponsabileAggiornamento, _
               unit.MustRun, _
             unit.InjectionWithdrawalPointNumber)

            Dim ht As Hashtable = unit.MercatiAbilitatiCollection
            If Not ht Is Nothing Then
                For Each marketName As String In ht.Keys
                    Dim marketInfo As Market = DirectCast(ht(marketName), Market)
                    ' Ora metto Abilitato = True di default, esiste una proprieta' nella classe Market (Abilitato) che...
                    'InsertInSDC_AbilitazioneUnita(cn, tr, unit.CodiceUnitaSDC, unit.CategoriaUnita, marketInfo.Nome, True)
                    ' QUesta chiamata e' sulla tabella SDC_Unita_MarketInformation l'altra sulla tabella SDC_AbilitazioneUnitaPerMercato
                    InsertInSDC_UnitaMarketInformation(cn, tr, unit.CodiceUnitaSDC, unit.CategoriaUnita, marketInfo.Nome, marketInfo.Eligibility)

                    '... mi dice se l'unita' e' abilitata per il mercato di nome "Nome"
                    ' InsertInSDC_AbilitazioneUnita(cn, tr, unit.CodiceUnitaSDC, unit.CategoriaUnita, marketInfo.Nome, marketInfo.Abilitato)
                Next
            End If

        Catch ex As SqlException
            Dim msg As String = ex.Message

            If msg.ToUpper.IndexOf("FK_SDC_UNITA_SDC_OPERATORI") >= 0 Then
                msg = "Errore durante l'elaborazione dell'unita` " + unit.CodiceUnitaSDC + ": operatore di rif. sconosciuto"

            ElseIf msg.ToUpper.IndexOf("FK_SDC_UNITA_SDC_PUNTIDISCAMBIORILEVANTI") >= 0 Then
                msg = "Errore durante l'elaborazione dell'unita` " + unit.CodiceUnitaSDC + ": punto di scambio rilevante sconosciuto"
            Else
                msg = Nothing
            End If

            If msg Is Nothing Then
                Throw
            Else
                ' lancio una nuova eccezione dato che ho capito l'errore
                Throw New Exception(msg, ex)
            End If


        Catch ex As Exception
            smTrace(ex, "Import Unita`: errore durante l'elaborazione dell'unita` " + unit.CodiceUnitaSDC)
            Throw
        End Try
    End Sub

    Private Sub ParseXML(ByVal xmlContent() As Byte)

        Dim xr As New XmlTextReader(New MemoryStream(xmlContent))
        Dim cn As New SqlConnection
        Dim tr As SqlTransaction = Nothing
        Dim fileGiusto As Boolean    ' Varra' True se xmlContent e' un file relativo alle unita'

        smTrace("Import unita`: inizio elaborazione")


        fileGiusto = False
        Try
            ' Apro la connessione al DB
            cn.ConnectionString = GetConnectionString()
            cn.Open()
            tr = cn.BeginTransaction()


            Dim cultureInfoIT As New System.Globalization.CultureInfo("it-IT")

            xr.WhitespaceHandling = WhitespaceHandling.None
            '======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
            Dim elUnitInformation As Object = xr.NameTable.Add("UnitInformation")
            Dim elUnitDetail As Object = xr.NameTable.Add("UnitDetail")
            Dim elUnitName As Object = xr.NameTable.Add("UnitName")
            Dim elUnitReferenceNumber As Object = xr.NameTable.Add("UnitReferenceNumber")
            Dim elUnitType As Object = xr.NameTable.Add("UnitType")
            Dim elTransmissionLossFactor As Object = xr.NameTable.Add("TransmissionLossFactor")
            Dim elGridSupplyPoint As Object = xr.NameTable.Add("GridSupplyPoint")
            Dim elMaximumPower As Object = xr.NameTable.Add("MaximumPower")
            Dim elMinimumPower As Object = xr.NameTable.Add("MinimumPower")
            Dim elInjectionOrWithdrawalPointNumber As Object = xr.NameTable.Add("InjectionOrWithdrawalPointNumber")
            Dim elMeritOrder As Object = xr.NameTable.Add("MeritOrder")
            Dim elStatusCode As Object = xr.NameTable.Add("StatusCode")
            Dim elReferenceMarketParticipantNumber As Object = xr.NameTable.Add("ReferenceMarketParticipantNumber")
            Dim elUnbalancedMarketParticipantNumber As Object = xr.NameTable.Add("UnbalancedMarketParticipantNumber")
            Dim elResponsabileAggiornamento As Object = xr.NameTable.Add("ResponsabileAggiornamento")

            Dim elMarketInformation As Object = xr.NameTable.Add("MarketInformation")
            Dim elMarket As Object = xr.NameTable.Add("Market")

            Dim currUnita As Unita = Nothing
            Dim currMarket As Market = Nothing

            While (xr.Read())
                Dim xrn As Object = xr.Name

                Select Case xr.NodeType
                    Case XmlNodeType.Element
                        '==================== UNIT DETAIL ====================================
                        If (xrn Is elUnitDetail) Then
                            currUnita = New Unita
                            fileGiusto = True

                            '==================== UNIT NAME ==================================
                        ElseIf (xrn Is elUnitName) Then
                            Dim xmlData As String = xr.ReadString()
                            If True Then
                                xmlData = xmlData.Replace(Environment.NewLine, " ")
                                xmlData = xmlData.Replace(ChrW(10), ChrW(32))
                                xmlData = xmlData.Replace(ChrW(13), ChrW(32))
                            End If
                            currUnita.Nome = xmlData

                            '=================== UNIT REFERENCE NUMBER =======================
                        ElseIf (xrn Is elUnitReferenceNumber) Then
                            Dim xmlData As String = xr.GetAttribute("MustRun")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currUnita.MustRun = xmlData
                            End If

                            xmlData = xr.ReadString()
                            Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
                                currUnita.CodiceUnitaSDC = xmlData
                            Else
                                Throw New ApplicationException("Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            End If


                            '================== UNIT TYPE ===================================
                        ElseIf (xrn Is elUnitType) Then
                            Dim xmlSubType As String = xr.GetAttribute("SubType")
                            currUnita.SottoTipo = xmlSubType

                            Dim xmlData As String = xr.ReadString()
                            currUnita.Tipo = xmlData

                            '================= TRANSMISSION LOSS FACTOR ======================
                        ElseIf (xrn Is elTransmissionLossFactor) Then
                            Dim xmlData As String = xr.ReadString()
                            If Not xmlData Is Nothing Then
                                currUnita.CoefficientePerdita = Convert.ToDouble(xmlData, cultureInfoIT)
                            End If


                            '================= GRID SUPPLY POINT ======================
                        ElseIf (xrn Is elGridSupplyPoint) Then
                            Dim xmlData As String = xr.ReadString()
                            currUnita.PuntoScambioRilevante = xmlData

                            '================= MAXIMUM POWER ======================
                        ElseIf (xrn Is elMaximumPower) Then
                            Dim xmlData As String = xr.ReadString()
                            If Not xmlData Is Nothing Then
                                currUnita.PotenzaMAX = Convert.ToDouble(xmlData, cultureInfoIT)
                            End If

                            '================= MINIMUM POWER ======================
                        ElseIf (xrn Is elMinimumPower) Then
                            Dim xmlData As String = xr.ReadString()
                            If Not xmlData Is Nothing Then
                                currUnita.PotenzaMin = Convert.ToDouble(xmlData, cultureInfoIT)
                            End If

                            '================= INJECTION/WITHDRAWAL POINT NUMBER ======================
                        ElseIf (xrn Is elInjectionOrWithdrawalPointNumber) Then
                            Dim xmlData As String = xr.ReadString()
                            currUnita.InjectionWithdrawalPointNumber = xmlData

                            '================= ORDINE DI MERITO ============================
                        ElseIf (xrn Is elMeritOrder) Then
                            Dim xmlData As String = xr.ReadString()
                            If Not xmlData Is Nothing Then
                                currUnita.OrdineMerito = Convert.ToDouble(xmlData, cultureInfoIT)
                            End If

                            '================= STATO ============================
                        ElseIf (xrn Is elStatusCode) Then
                            Dim xmlData As String = xr.ReadString()
                            currUnita.Stato = xmlData

                            '================= REFERENCE MARKET PARTICIPANT NUMBER ============================
                        ElseIf (xrn Is elReferenceMarketParticipantNumber) Then
                            Dim xmlData As String = xr.ReadString()
                            currUnita.ReferenceMarketParticipantNumber = xmlData

                            '================= UNBALANCED MARKET PARTICIPANT NUMBER ============================
                        ElseIf (xrn Is elUnbalancedMarketParticipantNumber) Then
                            Dim xmlData As String = xr.ReadString()
                            currUnita.UnbalancedMarketParticipantNumber = xmlData

                            '================= RESPONSABILE AGGIORNAMENTO ================================
                        ElseIf (xrn Is elResponsabileAggiornamento) Then
                            Dim xmlData As String = xr.ReadString()
                            currUnita.ResponsabileAggiornamento = xmlData

                            '================= MARKET INFORMATION ============================
                            'ElseIf (xrn Is elMarketInformation) Then

                            '================= MARKET =======================================
                        ElseIf (xrn Is elMarket) Then
                            Dim xmlEligibility As String = xr.GetAttribute("Eligibility")
                            Dim xmlNomeMarket As String = xr.ReadString()
                            Debug.Assert(Not xmlNomeMarket Is Nothing, "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
                            If Not (xmlNomeMarket Is Nothing) Then
                                currMarket = New Market(xmlNomeMarket)
                                currMarket.Eligibility = xmlEligibility

                                currUnita.AddMarketInformation(currMarket)
                            End If
                            currMarket = Nothing
                        End If

                    Case XmlNodeType.EndElement
                        '================= END TAG UNIT INFORMATION =======================================
                        If (xrn Is elUnitInformation) Then
                            ' Ho letto tutte le informazioni di un'Unita => salvo tutto su DB
                            ' Salvo le informazioni sul DB
                            SaveToDB(cn, tr, currUnita)
                            currUnita = Nothing

                            '================= END TAG MARKET =======================================
                        ElseIf (xrn Is elMarket) Then
                            ' Ho letto tutte le informazioni di un Market relativo ad un'unita' =>
                            ' inserisco l'oggetto nella lista dei Market di un'unita'
                            ' NOTA: sembra che non legga il TAG di fine se viene letto il TAG di inizio????
                            ' Devo inserire questo codice sopra
                            'currUnita.AddMarketInformation(currMarket)
                            'currMarket = Nothing
                        End If
                End Select
            End While

            If fileGiusto = True Then
                If Not tr Is Nothing Then tr.Commit() : tr = Nothing
                smTrace("Import unita`: elaborazione terminata con successo")
            Else
                Throw New Exception("File errato: il file inviato non contiene informazione sulle unita'!")
            End If

        Catch ex As Exception
            smError(ex, "ImportUnita.ParseXML")
            Throw

        Finally
            If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
            If Not xr Is Nothing Then xr.Close()
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Sub

    Class Market
        '======================= VARIABILI PRIVATE ==================================
        Private _name As String
        Private _eligibility As String

        '======================= COSTRUTTORI ==================================
        Public Sub New()
            Me.New(Nothing)
        End Sub

        Public Sub New(ByVal Nome As String)
            Me._name = Nome
        End Sub

        '======================= PROPRIETA` ==================================
        ' NOME
        Public Property Nome() As String
            Get
                Return Me._name
            End Get
            Set(ByVal Value As String)
                Me._name = Value
            End Set
        End Property

        ' ELIGIBILITY
        Public Property Eligibility() As String
            Get
                Return Me._eligibility
            End Get
            Set(ByVal Value As String)
                Me._eligibility = Value
            End Set
        End Property

    End Class

    Class Unita
        '======================= VARIABILI PRIVATE ==================================
        Private _codiceUnitaSDC As String
        Private _categoriaUnita As String
        Private _tipo As String
        Private _sottoTipo As String
        Private _nome As String
        Private _coefficientePerdita As Double
        Private _psr As String
        Private _potenzaMAX As Double
        Private _potenzaMin As Double
        Private _ordineMerito As Double
        Private _stato As String
        Private _referenceMarketParticipantNumber As String
        Private _injectionOrWithdrawalPointNumber As String
        Private _mustRun As String
        Private _unbalancedMarketParticipantNumber As String
        Private _responsabileAggiornamento As String

        Private _marketInformation As Hashtable

        '======================= COSTRUTTORI ==================================
        Public Sub New()
            Me.New(Nothing)
        End Sub

        Public Sub New(ByVal CodiceUnitaSDC As String)
            Me._codiceUnitaSDC = CodiceUnitaSDC

            ' Per adesso considero solo unita di categoria "F"
            Me._categoriaUnita = "F"

            ' Lista dei mercati
            Me._marketInformation = New Hashtable
        End Sub

        '======================= PROPRIETA` ==================================
        ' CODICE UNITA SDC
        Public Property CodiceUnitaSDC() As String
            Get
                Return Me._codiceUnitaSDC
            End Get
            Set(ByVal Value As String)
                Me._codiceUnitaSDC = Value
            End Set
        End Property

        ' CATEGORIA UNITA
        Public Property CategoriaUnita() As String
            Get
                Return Me._categoriaUnita
            End Get
            Set(ByVal Value As String)
                Me._categoriaUnita = Value
            End Set
        End Property

        ' TIPO
        Public Property Tipo() As String
            Get
                Return Me._tipo
            End Get
            Set(ByVal Value As String)
                Me._tipo = Value
            End Set
        End Property

        ' SOTTOTIPO
        Public Property SottoTipo() As String
            Get
                Return Me._sottoTipo
            End Get
            Set(ByVal Value As String)
                Me._sottoTipo = Value
            End Set
        End Property

        ' NOME
        Public Property Nome() As String
            Get
                Return Me._nome
            End Get
            Set(ByVal Value As String)
                Me._nome = Value
            End Set
        End Property

        ' COEFFICIENTE DI PERDITA
        Public Property CoefficientePerdita() As Double
            Get
                Return Me._coefficientePerdita
            End Get
            Set(ByVal Value As Double)
                Me._coefficientePerdita = Value
            End Set
        End Property

        ' PSR
        Public Property PuntoScambioRilevante() As String
            Get
                Return Me._psr
            End Get
            Set(ByVal Value As String)
                Me._psr = Value
            End Set
        End Property

        ' POTENZA MAX
        Public Property PotenzaMAX() As Double
            Get
                Return Me._potenzaMAX
            End Get
            Set(ByVal Value As Double)
                Me._potenzaMAX = Value
            End Set
        End Property

        ' POTENZA MIN
        Public Property PotenzaMin() As Double
            Get
                Return Me._potenzaMin
            End Get
            Set(ByVal Value As Double)
                Me._potenzaMin = Value
            End Set
        End Property

        ' ORDINE MERITO
        Public Property OrdineMerito() As Double
            Get
                Return Me._ordineMerito
            End Get
            Set(ByVal Value As Double)
                Me._ordineMerito = Value
            End Set
        End Property

        ' STATO
        Public Property Stato() As String
            Get
                Return Me._stato
            End Get
            Set(ByVal Value As String)
                Me._stato = Value
            End Set
        End Property

        ' REFERENCE MARKET PARTICIPANT NUMBER
        Public Property ReferenceMarketParticipantNumber() As String
            Get
                Return Me._referenceMarketParticipantNumber
            End Get
            Set(ByVal Value As String)
                Me._referenceMarketParticipantNumber = Value
            End Set
        End Property

        ' INJECTION/WITHDRAWAL POINT NUMBER
        Public Property InjectionWithdrawalPointNumber() As String
            Get
                Return Me._injectionOrWithdrawalPointNumber
            End Get
            Set(ByVal Value As String)
                Me._injectionOrWithdrawalPointNumber = Value
            End Set
        End Property

        ' MUST RUN 
        Public Property MustRun() As String
            Get
                Return Me._mustRun
            End Get
            Set(ByVal Value As String)
                Me._mustRun = Value
            End Set
        End Property

        ' UNBALANCED MARKET PARTICIPANT NUMBER
        Public Property UnbalancedMarketParticipantNumber() As String
            Get
                Return Me._unbalancedMarketParticipantNumber
            End Get
            Set(ByVal Value As String)
                Me._unbalancedMarketParticipantNumber = Value
            End Set
        End Property

        ' RESPONSABILE AGGIORNAMENTO
        Public Property ResponsabileAggiornamento() As String
            Get
                Return Me._responsabileAggiornamento
            End Get
            Set(ByVal Value As String)
                Me._responsabileAggiornamento = Value
            End Set
        End Property

        ' COLLEZIONE DEI MARKET ABILITATI
        Public ReadOnly Property MercatiAbilitatiCollection() As Hashtable
            Get
                Return Me._marketInformation
            End Get
        End Property


        '========================== METODI PUBBLICI =========================
        Public Sub AddMarketInformation(ByVal marketInfo As Market)
            Me._marketInformation.Add(marketInfo.Nome, marketInfo)
        End Sub

    End Class
End Class
