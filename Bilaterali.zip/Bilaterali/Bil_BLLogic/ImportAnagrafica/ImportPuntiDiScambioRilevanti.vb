Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema

Public Class ImportPuntiDiScambioRilevanti
	Inherits BilBLBase

	Public Function InserisciZoneAsync(ByVal oby As Bil.FileStore.InfoEvento, ByVal runningOperator As String) As String
		BatchSerializer.BS.AddBatch(AddressOf ImportPuntiDiScambioRilevanti.ElaboraAsyncImportZone, oby, oby.CodiceTipoFile, oby.DescrizioneFile, DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
	End Function


	Private Sub InsertInSDC_PuntiDiScambioRilevanti(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal relevantExchangePointID As String, ByVal name As String, ByVal transmissionLossFactor As Double, ByVal zone As String)

		Dim cmdSql As New SqlClient.SqlCommand

		Dim cmdUpdate, cmdInsert As String

		cmdUpdate = "UPDATE SDC_PuntiDiScambioRilevanti SET "
		cmdUpdate = cmdUpdate + " DescrizionePuntoDiScambioRilevante = @DescrizionePuntoDiScambioRilevante, CoefficienteDiPerdita = @CoefficienteDiPerdita, CodiceZonaSDC = @CodiceZonaSDC, TSModifica = @TSModifica, ResponsabileAggiornamento = @ResponsabileAggiornamento "
		cmdUpdate = cmdUpdate + " WHERE "
		cmdUpdate = cmdUpdate + "(CodicePuntoDiScambioRilevanteSDC = @CodicePuntoDiScambioRilevanteSDC) "

		cmdInsert = "INSERT INTO SDC_PuntiDiScambioRilevanti "
		cmdInsert = cmdInsert + "(CodicePuntoDiScambioRilevanteSDC, DescrizionePuntoDiScambioRilevante, CoefficienteDiPerdita, CodiceZonaSDC, TSModifica, ResponsabileAggiornamento) "
		cmdInsert = cmdInsert + " VALUES "
		cmdInsert = cmdInsert + "(@CodicePuntoDiScambioRilevanteSDC, @DescrizionePuntoDiScambioRilevante, @CoefficienteDiPerdita, @CodiceZonaSDC, @TSModifica, @ResponsabileAggiornamento) "

		cmdSql.CommandText = cmdInsert
		cmdSql.Connection = cn
		cmdSql.Transaction = tr

		Dim TimeStamp As DateTime
		TimeStamp = DateTime.Now

		cmdSql.Parameters.Clear()
		cmdSql.Parameters.Add("@CodicePuntoDiScambioRilevanteSDC", relevantExchangePointID.ToUpper())
		cmdSql.Parameters.Add("@DescrizionePuntoDiScambioRilevante", name)
		cmdSql.Parameters.Add("@CoefficienteDiPerdita", transmissionLossFactor)
		cmdSql.Parameters.Add("@CodiceZonaSDC", zone)
		cmdSql.Parameters.Add("@TSModifica", TimeStamp)
		cmdSql.Parameters.Add("@ResponsabileAggiornamento", "")

		Dim esiste As Boolean = False
		Try
			cmdSql.ExecuteNonQuery()
		Catch ex As Exception
			If ex.Message.ToUpper.IndexOf("SDC_ZONE_SDC_PUNTIDISCAMBIORILEVANTI_FK1") >= 0 Then
				Throw New Exception("SDC_ZONE_SDC_PUNTIDISCAMBIORILEVANTI_FK1:Il punto di scambio rilevante " + relevantExchangePointID + " fa riferimento alla zona " + zone + " la quale non e' presente nella tabella delle zone.")
			ElseIf ex.Message.ToUpper.IndexOf("SDC_PUNTIDISCAMBIORILEVANTI_PK") >= 0 Then
				' Se la riga esiste => faccio un update
				esiste = True
			Else
				' se ha fallito per qualunque altro motivo => lancio l'eccezione
				Throw
			End If
		End Try

		If esiste = True Then
			cmdSql.CommandText = cmdUpdate

			cmdSql.Parameters.Clear()
			cmdSql.Parameters.Add("@CodicePuntoDiScambioRilevanteSDC", relevantExchangePointID.ToUpper())
			cmdSql.Parameters.Add("@DescrizionePuntoDiScambioRilevante", name)
			cmdSql.Parameters.Add("@CoefficienteDiPerdita", transmissionLossFactor)
			cmdSql.Parameters.Add("@CodiceZonaSDC", zone)
			cmdSql.Parameters.Add("@TSModifica", TimeStamp)
			cmdSql.Parameters.Add("@ResponsabileAggiornamento", "")

			Dim numrow As Integer
			Try
				numrow = cmdSql.ExecuteNonQuery()
			Catch ex As Exception
				If ex.Message.ToUpper.IndexOf("SDC_ZONE_SDC_PUNTIDISCAMBIORILEVANTI_FK1") >= 0 Then
					Throw New Exception("SDC_ZONE_SDC_PUNTIDISCAMBIORILEVANTI_FK1:Il punto di scambio rilevante " + relevantExchangePointID + " fa riferimento alla zona " + zone + " la quale non e' presente nella tabella delle zone.")
				Else
					' se ha fallito per qualunque altro motivo => lancio l'eccezione
					Throw
				End If
			End Try

			If numrow = 0 Then
				Throw New Exception("Fallito UPDATE su tabella SDC_PuntiDiScambioRilevanti.")
			End If
		End If

	End Sub

	Private Shared Sub ElaboraAsyncImportZone(ByVal o As Object)
		Dim bl As New ImportPuntiDiScambioRilevanti
		
		Try
			Dim blInfoEvt As Bil.FileStore.InfoEvento = DirectCast(o, Bil.FileStore.InfoEvento)

			bl.ImportaDatiInSDC_Zone(blInfoEvt)
			BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")
			SystemMonitor.SmLog.smTrace("Import zone: eleaborazione terminata con successo")

		Catch ex As Exception
			BatchSerializer.BS.SetProgressBatch(ex.Message)
			SystemMonitor.SmLog.smError("Import zone: elaborazione terminata con errore: " + ex.Message)
		Finally
			bl.Dispose()
		End Try


	End Sub
	Public Sub ImportaDatiInSDC_Zone(ByVal blInfoEvt As Bil.FileStore.InfoEvento)
		Dim blFS As Bil.FileStore
		Dim TSFile As DateTime
		Dim IdFile As Integer
		Dim xmlFileContent() As Byte

		Try
			blFS = New Bil.FileStore
			blFS.InsertFile(blInfoEvt, TSFile, IdFile)
			xmlFileContent = blInfoEvt.ContenutoFile
		Catch ex As Exception
			smError(ex, "Import Zone")
			Throw
		End Try

		SaveUploadFile("Zone", xmlFileContent)

		conn.ConnectionString = GetConnectionString()
		Try
			smTrace("Import zone: inizio elaborazione")
			Dim zoneImport As New SDCZoneImport(xmlFileContent)
			With zoneImport
				.Connection = conn
				.DataAdapterZone = daSDC_Zone
			End With
			Dim bRet As Boolean = zoneImport.ImportDataFromFileToDB()
			Debug.Assert(bRet, "Errore import file ZoneSDC")
			smTrace("Import zone: elaborazione terminata con successo")

			Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Import zone: elaborazione terminata con successo")
			blFS.UpdateFAFile(TSFile, IdFile, byFA)

		Catch ex As Exception
			smError(ex, "Import zone: elaborazione terminata con errore")
			Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Import zone: elaborazione terminata con errore " + ex.message)
			blFS.UpdateFAFile(TSFile, IdFile, byFA)
			Throw
		End Try
		'smTrace("Eseguito Import Zone")
	End Sub

	' Non utilizzata.
	Public Function EsportaDatiDaSDC_Zone() As String

		Try
			smTrace("Export zone: inizio elaborazione")

			conn.ConnectionString = GetConnectionString()
			conn.Open()

			Dim ds As New DS_SDC_Zone
			daSDC_Zone.Fill(ds, "SDC_Zone")

			Dim sb As New StringBuilder
			Dim streamdati As New StringWriter(sb)
			ds.WriteXml(streamdati)
			streamdati.Flush()
			streamdati.Close()

			smTrace("Import zone: elaborazione terminata con successo")

			Return sb.ToString()

		Catch ex As Exception
			smError(ex, "Export zone: elaborazione terminata con errore")
			Throw ex
		Finally
			If conn.State = ConnectionState.Open Then conn.Close()
		End Try

	End Function

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents conn As System.Data.SqlClient.SqlConnection
	Friend WithEvents cmdInsert As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdUpdate As System.Data.SqlClient.SqlCommand
	Friend WithEvents daSDC_Zone As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.conn = New System.Data.SqlClient.SqlConnection
		Me.cmdInsert = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdate = New System.Data.SqlClient.SqlCommand
		Me.daSDC_Zone = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSelect = New System.Data.SqlClient.SqlCommand
		'
		'conn
		'
		Me.conn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=bil_user;data source=BILSVR1;persi" & _
		"st security info=False;initial catalog=Bilaterali"
		'
		'cmdInsert
		'
		Me.cmdInsert.CommandText = "INSERT INTO dbo.SDC_Zone (CodiceZonaSDC, DescrizioneZona, TSModifica, Responsabil" & _
		"eAggiornamento, Type) VALUES (@CodiceZonaSDc, @DescrizioneZona, @TSModifica, @Re" & _
		"sponsabileAggiornamento, @Type)"
		Me.cmdInsert.Connection = Me.conn
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDc", System.Data.SqlDbType.VarChar, 10, "CodiceZonaSDC"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizioneZona", System.Data.SqlDbType.VarChar, 256, "DescrizioneZona"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Type", System.Data.SqlDbType.VarChar, 50, "Type"))
		'
		'cmdUpdate
		'
		Me.cmdUpdate.CommandText = "UPDATE dbo.SDC_Zone SET DescrizioneZona = @DescrizioneZona, TSModifica = @TSModif" & _
		"ica, ResponsabileAggiornamento = @ResponsabileAggiornamento, Type = @Type WHERE " & _
		"(CodiceZonaSDC = @CodiceZonaSDC)"
		Me.cmdUpdate.Connection = Me.conn
		Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizioneZona", System.Data.SqlDbType.VarChar, 256, "DescrizioneZona"))
		Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
		Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Type", System.Data.SqlDbType.VarChar, 50, "Type"))
		Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceZonaSDC", System.Data.DataRowVersion.Original, Nothing))
		'
		'daSDC_Zone
		'
		Me.daSDC_Zone.InsertCommand = Me.cmdInsert
		Me.daSDC_Zone.SelectCommand = Me.cmdSelect
		Me.daSDC_Zone.UpdateCommand = Me.cmdUpdate
		'
		'cmdSelect
		'
		Me.cmdSelect.CommandText = "SELECT CodiceZonaSDC, DescrizioneZona, TSModifica, ResponsabileAggiornamento, Typ" & _
		"e FROM dbo.SDC_Zone"
		Me.cmdSelect.Connection = Me.conn

	End Sub

#End Region


	Public Function InserisciPuntiDiScambioRilevantiAsync(ByVal oby As Bil.FileStore.InfoEvento, ByVal runningOperator As String) As String
		BatchSerializer.BS.AddBatch(AddressOf ImportPuntiDiScambioRilevanti.ElaboraAsyncImportPuntiDiScambioRilevanti, oby, oby.CodiceTipoFile, oby.DescrizioneFile, DateTime.MinValue, runningOperator)
		Return "L'elaborazione e` stata lanciata in background. Consultare il pannello di controllo per monitorare il batch."
	End Function
	Private Shared Sub ElaboraAsyncImportPuntiDiScambioRilevanti(ByVal o As Object)
		Dim bl As New ImportPuntiDiScambioRilevanti

		Try
			Dim blInfoEvt As Bil.FileStore.InfoEvento = DirectCast(o, Bil.FileStore.InfoEvento)

			bl.InserisciPuntiDiScambioRilevanti(blInfoEvt)
			BatchSerializer.BS.SetProgressBatch("Elaborazione terminata con successo")
			SystemMonitor.SmLog.smTrace("Import punti di scambio rilevanti: eleaborazione terminata con successo")

		Catch ex As Exception
			BatchSerializer.BS.SetProgressBatch(ex.Message)
			SystemMonitor.SmLog.smError("Import punti di scambio rilevanti: elaborazione terminata con errore: " + ex.Message)
		Finally
			bl.Dispose()
		End Try


	End Sub
	Public Function InserisciPuntiDiScambioRilevanti(ByVal blInfoEvt As Bil.FileStore.InfoEvento) As String
		Dim blFS As Bil.FileStore
		Dim TSFile As DateTime
		Dim IdFile As Integer
		Dim xmlFileContent() As Byte

		smTrace("Import Punti Di Scambio Rilevanti: inizio attivita'")

		Try
			blFS = New Bil.FileStore
			blFS.InsertFile(blInfoEvt, TSFile, IdFile)

			xmlFileContent = blInfoEvt.ContenutoFile
			SaveUploadFile("PuntiDiScambioRilevante", xmlFileContent)

		Catch ex As Exception
			smError(ex, "Punti Di Scambio Rilevanti")
			Throw
		End Try

		Try
			ParseXmlPSR(xmlFileContent)

			Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Import Punti Di Scambio Rilevanti: terminato con successo")
			blFS.UpdateFAFile(TSFile, IdFile, byFA)

			Return "OK"
		Catch ex As Exception

			Dim byFA() As Byte = (New UnicodeEncoding).GetBytes("Import Punti Di Scambio Rilevanti: " + ex.Message)
			blFS.UpdateFAFile(TSFile, IdFile, byFA)

			Return ex.Message()
		End Try
		'smTrace("Eseguito Import Punti Di Scambio Rilevanti")
	End Function

	Private Sub SavePsrToDB(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal puntoScambioRilev As PSR)
		Try
			InsertInSDC_PuntiDiScambioRilevanti(cn, _
			   tr, _
			   puntoScambioRilev.CodicePSRSDC, _
			   puntoScambioRilev.Nome, _
			   puntoScambioRilev.TransmissionLossFactor, _
			   puntoScambioRilev.Zona)
		Catch ex As Exception
			Throw ex
		End Try
	End Sub
	Private Sub ParseXmlPSR(ByVal xmlContent() As Byte)
		Dim xr As New XmlTextReader(New MemoryStream(xmlContent))
		Dim cn As New SqlConnection
		Dim tr As SqlTransaction = Nothing
		Dim fileGiusto As Boolean		  ' Varra' True se xmlContent e' un file relativo ai PSR

		smTrace("Import punti di scambio rilevanti: inizio elaborazione")


		fileGiusto = False
		Try
			' Apro la connessione al DB
			cn.ConnectionString = GetConnectionString()
			cn.Open()
			tr = cn.BeginTransaction()


			Dim cultureInfoIT As New System.Globalization.CultureInfo("it-IT")			   ' per leggere i double in italiano

			'======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
			Dim elRelevantExchangePoint As Object = xr.NameTable.Add("RelevantExchangePoint")
			Dim elRelevantExchangePointID As Object = xr.NameTable.Add("RelevantExchangePointID")
			Dim elName As Object = xr.NameTable.Add("Name")
			Dim elZone As Object = xr.NameTable.Add("Zone")
			Dim elTransmissionLossFactor As Object = xr.NameTable.Add("TransmissionLossFactor")

			' PSR corrente
			Dim currPSR As PSR = Nothing

			While (xr.Read())
				Dim xrn As Object = xr.Name

				Select Case xr.NodeType
					Case XmlNodeType.Element
						'====================== RELEVANT EXCHANGE POINT ====================
						If (xrn Is elRelevantExchangePoint) Then
							currPSR = New PSR
							fileGiusto = True

							'====================== RELEVANT EXCHANGE POINT ID ====================
						ElseIf (xrn Is elRelevantExchangePointID) Then
							Dim xmlData As String = xr.ReadString()
							Debug.Assert(Not xmlData Is Nothing AndAlso Not (xmlData = String.Empty), "Errore Tag """ & xr.Name & """ vuoto o  Nothing")
							If Not (xmlData Is Nothing) AndAlso Not (xmlData = String.Empty) Then
								currPSR.CodicePSRSDC = xmlData
							Else
								Throw New ApplicationException("Errore Tag """ & xr.Name & """ vuoto o  Nothing")
							End If

							'====================== NAME ====================
						ElseIf (xrn Is elName) Then
							Dim xmlData As String = xr.ReadString()
							currPSR.Nome = xmlData

							'====================== ZONE ====================
						ElseIf (xrn Is elZone) Then
							Dim xmlData As String = xr.ReadString()
							currPSR.Zona = xmlData

							'====================== TRANSMISSION LOSS FACTOR ====================
						ElseIf (xrn Is elTransmissionLossFactor) Then
							Dim xmlData As String = xr.ReadString()
							If Not (xmlData Is Nothing) Then
								currPSR.TransmissionLossFactor = Convert.ToDouble(xmlData, cultureInfoIT)
							End If
						End If

					Case XmlNodeType.EndElement
						'====================== END TAG RELEVANT EXCHANGE POINT ====================
						If (xrn Is elRelevantExchangePoint) Then
							' Salvataggio su DataBase
							SavePsrToDB(cn, tr, currPSR)
							currPSR = Nothing
						End If
				End Select

			End While

			If fileGiusto = True Then
				If Not tr Is Nothing Then tr.Commit() : tr = Nothing

				smTrace("Import punti di scambio rilevanti: elaborazione terminata con successo")
			Else
				Throw New Exception("File errato: il file inviato non contiene informazione sui PSR!")
			End If

		Catch ex As Exception
			smError(ex, "ImportPuntiDiScambioRilevanti.ParseXmlPSR")
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If Not xr Is Nothing Then xr.Close()
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Sub

#Region " Classe che contiene i dati per un Punto di Scambio Rilevante "

	Class PSR
		'=================== VARIABILI PRIVATE =========================
		Private _nome As String
		Private _codicePSRSDC As String
		Private _zona As String
		Private _transmissionLossFactor As Double

		'=================== COSTRUTTORI =========================
		Public Sub New()
			Me.New(Nothing)
		End Sub
		Public Sub New(ByVal CodicePSRSDC As String)
			Me._codicePSRSDC = CodicePSRSDC
		End Sub

		'=================== PROPRIETA` =========================
		' NOME
		Public Property Nome() As String
			Get
				Return Me._nome
			End Get
			Set(ByVal Value As String)
				Me._nome = Value
			End Set
		End Property

		' CODICE PUNTO DI SCAMBIO RILEVANTE SDC
		Public Property CodicePSRSDC() As String
			Get
				Return Me._codicePSRSDC
			End Get
			Set(ByVal Value As String)
				Me._codicePSRSDC = Value
			End Set
		End Property

		' ZONA
		Public Property Zona() As String
			Get
				Return Me._zona
			End Get
			Set(ByVal Value As String)
				Me._zona = Value
			End Set
		End Property

		' TRANSMISSION LOSS FACTOR
		Public Property TransmissionLossFactor() As Double
			Get
				Return Me._transmissionLossFactor
			End Get
			Set(ByVal Value As Double)
				Me._transmissionLossFactor = Value
			End Set
		End Property
	End Class

#End Region

	Class SDCZoneImport
		Inherits BilBLBase

		'====================== INIZIO CLASSE ZONASDC ===================================
		Class ZonaSDC
			'=================== VARIABILI PRIVATE =========================
			' CODICE ZONA SDC
			Private _codice As String
			' DESCRIZIONE ZONA
			Private _descrizione As String
			' DATA E ORA
			Private _tsmodifica As DateTime
			' RESPONSABILE AGGIORNAMENTO
			Private _responsabileAggiornamento As String
			' TIPO ZONA
			Private _tipo As String

			'=================== COSTRUTTORI ==========================
			Public Sub New()

			End Sub

			Public Sub New(ByVal CodiceZonaSDC As String)
				Me._codice = CodiceZonaSDC
			End Sub

			'=================== PROPRIETA' ===========================
			' CODICE ZONA SDC
			Public Property CodiceZonaSDC() As String
				Get
					Return Me._codice.ToUpper()
				End Get
				Set(ByVal Value As String)
					Me._codice = Value
				End Set
			End Property

			' DESCRIZIONE ZONA
			Public Property DescrizioneZona() As String
				Get
					Return Me._descrizione
				End Get
				Set(ByVal Value As String)
					Me._descrizione = Value
				End Set
			End Property

			' TSMODIFICA
			Public Property TSModifica() As DateTime
				Get
					Return Me._tsmodifica
				End Get
				Set(ByVal Value As DateTime)
					Me._tsmodifica = Value
				End Set
			End Property

			' RESPONSABILE AGGIORNAMENTO
			Public Property ResponsabileAggiornamento() As String
				Get
					Return Me._responsabileAggiornamento
				End Get
				Set(ByVal Value As String)
					Me._responsabileAggiornamento = Value
				End Set
			End Property

			' TIPO
			Public Property Type() As String
				Get
					Return Me._tipo
				End Get
				Set(ByVal Value As String)
					Me._tipo = Value
				End Set
			End Property
		End Class
		'=============== FINE CLASSE ZONASDC ===================== 


		'=============== VARIABILI PRIVATE ======================
		Private _abyXMLFileContent() As Byte
		Private _cn As SqlClient.SqlConnection
		Private _dsZone As DS_SDC_Zone
		Private _da As SqlDataAdapter

		'================ COSTRUTTORI ===========================
		Public Sub New(ByVal aby() As Byte)
			Me._abyXMLFileContent = aby
			' Creo il DataSet che conterra' le ZoneSDC eventualmente gia' presenti nel DataBase
			' (e' permesso reinserire piu' volte lo stesso file)
			Me._dsZone = New DS_SDC_Zone
		End Sub


		'=============== PROPRIETA' ===========================
		' Connessione al DataBase per effettuare l'inserimento di una Zona
		Public Property Connection() As SqlClient.SqlConnection
			Get
				Return Me._cn
			End Get
			Set(ByVal Value As SqlClient.SqlConnection)
				Me._cn = Value
			End Set
		End Property

		' DataAdapter per poter recuperare e salvare i dati sul DataBase
		Public Property DataAdapterZone() As SqlDataAdapter
			Get
				Return Me._da
			End Get
			Set(ByVal Value As SqlDataAdapter)
				Me._da = Value
			End Set
		End Property
		'=============== METODI PRIVATI ========================
		Private Sub CheckDBConn()
			Debug.Assert(Not Me._cn Is Nothing, "Errore oggetto Connessione al DB uguale a Nothing")
			If Me._cn Is Nothing Then
				Throw New ApplicationException("Errore oggetto Connessione al DB uguale a Nothing")
			End If
		End Sub

		Public Sub CheckDataAdapter()
			Debug.Assert(Not Me._da Is Nothing, "Errore oggetto SqlDataAdapter uguale a Nothing")
			If Me._da Is Nothing Then
				Throw New ApplicationException("Errore oggetto SqlDataAdapter uguale a Nothing")
			End If
		End Sub
		Public Sub CheckDataSet()
			Debug.Assert(Not Me._dsZone Is Nothing, "Errore oggetto DataSet uguale a Nothing")
			If Me._dsZone Is Nothing Then
				Throw New ApplicationException("Errore oggetto DataSet uguale a Nothing")
			End If
		End Sub
		Private Sub FillDataSetZoneSDC()
			Try
				' Controlli vari....che generano eccezione se qualcosa e' andato storto
				CheckDataAdapter()
				CheckDataSet()
			Catch ex As Exception
				Throw ex
			End Try

			' Tutto OK recupero l'elenco delle Zone gia' presenti nel DB
			Try
				Me._da.Fill(Me._dsZone.SDC_Zone)
			Catch ex As Exception
				Throw ex
			End Try
		End Sub
		Private Sub SaveToDB(ByVal curZonaSDC As ZonaSDC)
			Dim tr As SqlTransaction = Nothing
			Try
				CheckDBConn()
				CheckDataAdapter()
				CheckDataSet()

				Dim row As DS_SDC_Zone.SDC_ZoneRow = Me._dsZone.SDC_Zone.FindByCodiceZonaSDC(curZonaSDC.CodiceZonaSDC)
				If Not (row Is Nothing) Then
					' La Zona e' gia' nel DB => aggiorno solo i suoi dati descrittivi
					With row
						.DescrizioneZona = curZonaSDC.DescrizioneZona
						.TSModifica = curZonaSDC.TSModifica
						.Type = curZonaSDC.Type
						.ResponsabileAggiornamento = curZonaSDC.ResponsabileAggiornamento
					End With
				Else
					' La Zona non e' nel DB => la aggiungo
					Dim newRowZona As DS_SDC_Zone.SDC_ZoneRow = Me._dsZone.SDC_Zone.NewSDC_ZoneRow
					With newRowZona
						.CodiceZonaSDC = curZonaSDC.CodiceZonaSDC.ToUpper()
						.DescrizioneZona = curZonaSDC.DescrizioneZona
						.TSModifica = curZonaSDC.TSModifica
						.ResponsabileAggiornamento = curZonaSDC.ResponsabileAggiornamento
						.Type = curZonaSDC.Type
					End With
					Me._dsZone.SDC_Zone.AddSDC_ZoneRow(newRowZona)
				End If

				' Uso le transazioni ????
				'tr = Me._cn.BeginTransaction()
				If Not tr Is Nothing Then
					If Not Me._da.UpdateCommand Is Nothing Then Me._da.UpdateCommand.Transaction = tr
					If Not Me._da.InsertCommand Is Nothing Then Me._da.InsertCommand.Transaction = tr
					If Not Me._da.DeleteCommand Is Nothing Then Me._da.DeleteCommand.Transaction = tr
					If Not Me._da.SelectCommand Is Nothing Then Me._da.SelectCommand.Transaction = tr
				End If

				' Aggiorno il DataBase
				Me._da.Update(Me._dsZone.SDC_Zone)
				If Not tr Is Nothing Then tr.Commit()

			Catch ex As Exception
				If Not tr Is Nothing Then tr.Rollback()
				Throw ex
			End Try
		End Sub


		'=============== METODI PUBBLICI ========================
		Public Function ImportDataFromFileToDB() As Boolean
			Dim fileGiusto As Boolean			 ' Varra' True se xmlContent e' un file relativo alle Zone

			' Controllo che il DataAdapter sia stato settato
			CheckDataAdapter()

			' Carico i dati dal DB per caricare eventuali ZoneSDC gia' inserite
			FillDataSetZoneSDC()

			Dim xr As XmlTextReader = New XmlTextReader(New MemoryStream(Me._abyXMLFileContent))

			smTrace("Import zone: inizio elaborazione")

			fileGiusto = False
			Try
				xr.WhitespaceHandling = WhitespaceHandling.None

				Dim cultureInfoIT As New System.Globalization.CultureInfo("it-IT")				  ' per leggere i double in italiano
				'======== MAPPING XML TRA STRINGHE E PUNTATORI AD OGGETTI ==================
				Dim elSDC_Zone As Object = xr.NameTable.Add("SDC_Zone")
				Dim elCodiceZonaSDC As Object = xr.NameTable.Add("CodiceZonaSDC")
				Dim elDescrizioneZona As Object = xr.NameTable.Add("DescrizioneZona")
				Dim elTSModifica As Object = xr.NameTable.Add("TSModifica")
				Dim elResponsabileAggiornamento As Object = xr.NameTable.Add("ResponsabileAggiornamento")
				Dim elType As Object = xr.NameTable.Add("Type")

				' SDCZona corrente
				Dim currentSDCZone As ZonaSDC = Nothing

				While (xr.Read())
					Dim xrn As Object = xr.Name

					Select Case xr.NodeType
						Case XmlNodeType.Element
							'==================== INIZIO DATI DI UNA ZONA SDC =================
							If (xrn Is elSDC_Zone) Then
								currentSDCZone = New ZonaSDC
								fileGiusto = True

								'================ CODICE ZONA SDC =============================
							ElseIf (xrn Is elCodiceZonaSDC) Then
								Dim xmlCodiceZonaSDC As String = xr.ReadString()
								Debug.Assert(Not xmlCodiceZonaSDC Is Nothing AndAlso xmlCodiceZonaSDC <> String.Empty, "Errore TAG CodiceZonaSDC NULL o vuoto")
								If (Not xmlCodiceZonaSDC Is Nothing AndAlso xmlCodiceZonaSDC <> String.Empty) Then
									Debug.Assert(Not currentSDCZone Is Nothing, "Errore oggetto ZonaSDC uguale a Nothing")
									If Not (currentSDCZone Is Nothing) Then
										currentSDCZone.CodiceZonaSDC = xmlCodiceZonaSDC
									Else
										Throw New ApplicationException("Errore oggetto ZonaSDC uguale a Nothing")
									End If
								End If
								'============== DESCRIZIONE ZONA SDC ============================
							ElseIf (xrn Is elDescrizioneZona) Then
								Dim xmlDescrizioneZona As String = xr.ReadString()
								Debug.Assert(Not xmlDescrizioneZona Is Nothing, "Errore TAG DescrizioneZona")
								If (Not xmlDescrizioneZona Is Nothing) Then
									Debug.Assert(Not currentSDCZone Is Nothing, "Errore oggetto ZonaSDC uguale a Nothing")
									If Not (currentSDCZone Is Nothing) Then
										currentSDCZone.DescrizioneZona = xmlDescrizioneZona
									Else
										Throw New ApplicationException("Errore oggetto ZonaSDC uguale a Nothing")
									End If
								End If
								'=============== TSMODIFICA =====================================
							ElseIf (xrn Is elTSModifica) Then
								Dim xmlTSmodifica As String = xr.ReadString()
								Debug.Assert(Not xmlTSmodifica Is Nothing AndAlso _
								 xmlTSmodifica <> String.Empty, _
								 "Errore TAG TSModifica NULL o vuoto")

								If (Not xmlTSmodifica Is Nothing AndAlso _
								  xmlTSmodifica <> String.Empty) Then
									Debug.Assert(Not currentSDCZone Is Nothing, "Errore oggetto ZonaSDC uguale a Nothing")
									If Not (currentSDCZone Is Nothing) Then
										currentSDCZone.TSModifica = DateTime.Parse(xmlTSmodifica, cultureInfoIT)
									Else
										Throw New ApplicationException("Errore oggetto ZonaSDC uguale a Nothing")
									End If
								End If
								'=============== RESPONSABILE AGGIORNAMENTO =====================
							ElseIf (xrn Is elResponsabileAggiornamento) Then
								Dim xmlResponsabileAggiornamento As String = xr.ReadString()

								'Debug.Assert(Not xmlResponsabileAggiornamento Is Nothing AndAlso _
								'                xmlResponsabileAggiornamento <> String.Empty, _
								'                "Errore TAG ResponsabileAggiornamento NULL o vuoto")


								If (Not xmlResponsabileAggiornamento Is Nothing AndAlso _
								  xmlResponsabileAggiornamento <> String.Empty) Then
									Debug.Assert(Not currentSDCZone Is Nothing, "Errore oggetto ZonaSDC uguale a Nothing")
									If Not (currentSDCZone Is Nothing) Then
										currentSDCZone.ResponsabileAggiornamento = xmlResponsabileAggiornamento
									Else
										Throw New ApplicationException("Errore oggetto ZonaSDC uguale a Nothing")
									End If
								Else
									currentSDCZone.ResponsabileAggiornamento = String.Empty
								End If
								'=============== TYPE ========================
							ElseIf (xrn Is elType) Then
								Dim xmlType As String = xr.ReadString()
								Debug.Assert(Not xmlType Is Nothing AndAlso _
								 xmlType <> String.Empty, _
								 "Errore TAG Type NULL o vuoto")

								If (Not xmlType Is Nothing AndAlso _
								  xmlType <> String.Empty) Then
									Debug.Assert(Not currentSDCZone Is Nothing, "Errore oggetto ZonaSDC uguale a Nothing")
									If Not (currentSDCZone Is Nothing) Then
										currentSDCZone.Type = xmlType
									Else
										Throw New ApplicationException("Errore oggetto ZonaSDC uguale a Nothing")
									End If
								End If

							End If

							'==================== END ELEMENT ==============================
						Case XmlNodeType.EndElement
							If (xrn Is elSDC_Zone) Then
								' Ho finito di leggere i dati relativi ad una Zona....
								' la salvo sul DataBase
								SaveToDB(currentSDCZone)
								' Ritorno alla situazione iniziale
								currentSDCZone = Nothing
							End If
					End Select

				End While

				If fileGiusto = True Then
					smTrace("Import zone: elaborazione terminata con successo")
					Return True
				Else
					Throw New Exception("File errato: il file inviato non contiene informazione sulle zone!")
				End If

			Catch ex As Exception
				Throw
			Finally
				If Not xr Is Nothing Then xr.Close()
			End Try
		End Function
	End Class

End Class
