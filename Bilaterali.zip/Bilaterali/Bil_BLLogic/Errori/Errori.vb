Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Public Class Errori
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        _cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents _daListaFile As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _cmdSelectFileProgrammi As System.Data.SqlClient.SqlCommand
    Friend WithEvents _dsFileProgrammi As Bil.DS_FileProgrammi
    Friend WithEvents _cmdExtractBlobFA As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdUpdateFileProgrammi As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me._cn = New System.Data.SqlClient.SqlConnection
		Me._daListaFile = New System.Data.SqlClient.SqlDataAdapter
		Me._cmdSelectFileProgrammi = New System.Data.SqlClient.SqlCommand
		Me._cmdUpdateFileProgrammi = New System.Data.SqlClient.SqlCommand
		Me._dsFileProgrammi = New Bil.DS_FileProgrammi
		Me._cmdExtractBlobFA = New System.Data.SqlClient.SqlCommand
		CType(Me._dsFileProgrammi, System.ComponentModel.ISupportInitialize).BeginInit()
		'
		'_cn
		'
		Me._cn.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
		"rsist security info=False;initial catalog=Bilaterali"
		'
		'_daListaFile
		'
		Me._daListaFile.SelectCommand = Me._cmdSelectFileProgrammi
		Me._daListaFile.UpdateCommand = Me._cmdUpdateFileProgrammi
		'
		'_cmdSelectFileProgrammi
		'
		Me._cmdSelectFileProgrammi.CommandText = "SELECT dbo.FileOperatori.TSDownload, dbo.XmlProgrammiUtenti.IdProgrammaXml, dbo.X" & _
		"mlProgrammiUtenti.TSInvio, dbo.XmlProgrammiUtenti.Zippato, dbo.XmlProgrammiUtent" & _
		"i.NomeFileUtente, dbo.XmlProgrammiUtenti.CodiceUtenteSDC, dbo.XmlProgrammiUtenti" & _
		".PathFileFirmato, dbo.XmlProgrammiUtenti.CodiceOperatoreSDC, dbo.XmlProgrammiUte" & _
		"nti.TSModifica, dbo.FileOperatori.IdFile, dbo.FileOperatori.Zipped, dbo.FileOper" & _
		"atori.NomeFile, dbo.FileOperatori.TSCreazione FROM dbo.XmlProgrammiUtenti LEFT O" & _
		"UTER JOIN dbo.FileOperatori ON dbo.XmlProgrammiUtenti.IdFileFA = dbo.FileOperato" & _
		"ri.IdFile"
		Me._cmdSelectFileProgrammi.Connection = Me._cn
		'
		'_cmdUpdateFileProgrammi
		'
		Me._cmdUpdateFileProgrammi.CommandText = "UPDATE FileOperatori " & _
		"SET TSDownload = @TSDownload " & _
		"FROM FileOperatori FO " & _
		"INNER JOIN XmlProgrammiUtenti XmlPU " & _
		"ON XmlPU.IdFileFA = FO.IdFile " & _
		"AND XmlPU.IdProgrammaXml = @IdFile "
		Me._cmdUpdateFileProgrammi.Connection = Me._cn
		Me._cmdUpdateFileProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSDownload", System.Data.SqlDbType.DateTime, 8, "TSDownload"))
		Me._cmdUpdateFileProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
		'
		'_dsFileProgrammi
		'
		Me._dsFileProgrammi.CaseSensitive = True
		Me._dsFileProgrammi.DataSetName = "DS_FileProgrammi"
		Me._dsFileProgrammi.Locale = New System.Globalization.CultureInfo("it-IT")
		'
		'_cmdExtractBlobFA
		'
		Me._cmdExtractBlobFA.CommandText = "SELECT dbo.FileOperatori.Zipped, dbo.FileOperatori.Encoding, dbo.FileOperatori.Co" & _
		"ntenutoFile FROM dbo.FileOperatori INNER JOIN dbo.XmlProgrammiUtenti ON dbo.File" & _
		"Operatori.IdFile = dbo.XmlProgrammiUtenti.IdFileFA"
		Me._cmdExtractBlobFA.Connection = Me._cn
		CType(Me._dsFileProgrammi, System.ComponentModel.ISupportInitialize).EndInit()

	End Sub

#End Region

	Public Function GetListaFile(ByVal idOperatore As String, ByVal di As DateTime, ByVal df As DateTime, ByVal TSDownload As String, ByVal idProgrammaXML As String, ByVal maxRecordToLoad As Integer) As DS_FileProgrammi
		Return GetListaFile(idOperatore, di, df, -1, TSDownload, idProgrammaXML, maxRecordToLoad)
	End Function

	Public Function GetListaFile(ByVal idOperatore As String, ByVal di As DateTime, ByVal df As DateTime, ByVal ora As Int32, ByVal TSDownload As String, ByVal idProgrammaXML As String, ByVal maxRecordToLoad As Integer) As DS_FileProgrammi
		Try
			Dim c As StringBuilder = New StringBuilder
			c.Append(" where 1=1 ")


			If maxRecordToLoad > 0 Then
				_cmdSelectFileProgrammi.CommandText = _cmdSelectFileProgrammi.CommandText.Replace("SELECT ", String.Format("SELECT TOP {0} ", maxRecordToLoad))
			End If

			If (idOperatore <> String.Empty) Then
				c.Append(" and dbo.XmlProgrammiUtenti.CodiceOperatoreSDC LIKE @IdOperatore ")
				_cmdSelectFileProgrammi.Parameters.Add("@IdOperatore", idOperatore + "%")
			End If

			If di <> DateTime.MinValue AndAlso di <> DateTime.MaxValue Then
				c.Append(" and TSInvio >= @di ")
				_cmdSelectFileProgrammi.Parameters.Add("@di", di)
			End If

			If df <> DateTime.MinValue AndAlso df <> DateTime.MaxValue Then
				c.Append(" and TSInvio < @df ")
				_cmdSelectFileProgrammi.Parameters.Add("@df", df.AddDays(1))
			End If

			If ora <> -1 Then
				c.Append(" and datepart(hour, TSInvio) = @h ")
				_cmdSelectFileProgrammi.Parameters.Add("@h", ora)
			End If

			If Not TSDownload Is Nothing Then
				c.Append(" and ")
				c.Append(TSDownload)				' qui c'e` scritto TSDownload is [not] null
				c.Append(" ")
			End If

			If Not idProgrammaXML Is Nothing Then
				c.Append(" and IdProgrammaXml = @IdProgrammaXml ")
				_cmdSelectFileProgrammi.Parameters.Add("@IdProgrammaXml", idProgrammaXML)
			End If

			If (c.Length > 0) Then _cmdSelectFileProgrammi.CommandText &= c.ToString()

			_cmdSelectFileProgrammi.CommandText += " order by TSInvio DESC "

			_cn.Open()
			Dim ds As New DS_FileProgrammi
			_daListaFile.Fill(ds.FileProgrammi)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function

	Public Function GetBlobFA(ByVal idXMLProgramma As Integer, ByVal idOperatore As String, ByRef zipped As Boolean, ByRef fileEncoding As String) As Byte()
		Dim rd As SqlDataReader
		Try
			_cn.Open()
			zipped = False

			If idXMLProgramma > 0 Then
				_cmdExtractBlobFA.CommandText += " WHERE IdProgrammaXml = @IdProgrammaXML AND FileOperatori.CodiceOperatoreSDC = @CodiceOperatoreSDC"
				_cmdExtractBlobFA.Parameters.Add("@IdProgrammaXML", idXMLProgramma)
				_cmdExtractBlobFA.Parameters.Add("@CodiceOperatoreSDC", idOperatore)
			End If

			rd = _cmdExtractBlobFA.ExecuteReader(CommandBehavior.SequentialAccess)
			While rd.Read()
				If rd.IsDBNull(0) Then zipped = False Else zipped = rd.GetBoolean(0)
				If rd.IsDBNull(1) Then fileEncoding = Nothing Else fileEncoding = rd.GetString(1)

				Dim blobSize As Long = rd.GetBytes(2, 0, Nothing, 0, 1)
				If blobSize > 0 Then
					Dim abyFA(CInt(blobSize) - 1) As Byte
					rd.GetBytes(2, 0, abyFA, 0, CInt(blobSize))
					Return abyFA
				Else
					Return Nothing
				End If
			End While

			Return Nothing
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not (rd Is Nothing) Then rd.Close()
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function

	Public Function GetBlobProgramma(ByVal idXMLProgramma As Integer, ByVal CodiceOperatoreSDC As String, ByRef zipped As Boolean) As Byte()
		Dim rd As SqlDataReader
		Try
			If idXMLProgramma < 0 Then Throw New ArgumentException("Errore IdFileXML non valido")

			_cn.Open()
			zipped = False
			Dim c As New StringBuilder
			c.Append("SELECT Zippato, ProgrammaFirmato FROM XmlProgrammiUtenti ")
			c.Append(" WHERE IdProgrammaXml = @IdProgrammaXML AND CodiceOperatoreSDC = @CodiceOperatoreSDC")
			Dim _cmdExtractBlobProgramma As New SqlCommand
			_cmdExtractBlobProgramma.Connection = _cn
			_cmdExtractBlobProgramma.CommandText &= c.ToString()
			_cmdExtractBlobProgramma.Parameters.Add("@IdProgrammaXML", idXMLProgramma)
			_cmdExtractBlobProgramma.Parameters.Add("@CodiceOperatoreSDC", CodiceOperatoreSDC)

			rd = _cmdExtractBlobProgramma.ExecuteReader(CommandBehavior.SequentialAccess)
			Dim blobSize As Long
			Dim bufferSize As Integer = 100
			While rd.Read()
				' Il primo campo e' il flag Zippato
				If Not (rd.IsDBNull(0)) Then
					zipped = rd.GetBoolean(0)
				Else
					zipped = False
				End If

				' La prima chiamata serve per recuperare le dimensioni del BLOB
				blobSize = rd.GetBytes(1, 0, Nothing, 0, 100)

				If (blobSize > 0) Then
					Dim abyProgramma(CInt(blobSize) - 1) As Byte
					Dim ret As Long
					ret = rd.GetBytes(1, 0, abyProgramma, 0, CInt(blobSize))
#If DEBUG Then
					Try
						Dim fs As FileStream = File.Create("c:\tmp\" + "PGM.zip")
						fs.Write(abyProgramma, 0, abyProgramma.Length)
						fs.Close()
					Catch
					End Try

#End If

					Return abyProgramma
				Else
					Return Nothing
				End If
			End While

			Return Nothing
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not (rd Is Nothing) Then rd.Close()
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Function

	Public Sub UpdateDataDownload(ByVal ds As DS_FileProgrammi)
		Try
			_cn.Open()
			_daListaFile.Update(ds.FileProgrammi)
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Sub

	Public Sub UpdateFlagDownload(ByVal IdFile As String, ByVal dataDownload As DateTime)
		Dim rowsAffected As Integer
		Try
			_cn.Open()
			_cmdUpdateFileProgrammi.Parameters("@TSDownload").Value = dataDownload
			_cmdUpdateFileProgrammi.Parameters("@IdFile").Value = IdFile
			'Dim rowsAffected As Integer = _cmdUpdateFileProgrammi.ExecuteNonQuery()
			rowsAffected = _cmdUpdateFileProgrammi.ExecuteNonQuery()
		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If _cn.State = ConnectionState.Open Then _cn.Close()
		End Try
	End Sub

End Class
