Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Collections

Public Class Contratto
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents _cmdContrattoUpdate As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents _cmdContrattoDelete As System.Data.SqlClient.SqlCommand
	Friend WithEvents _ds_Contratto As Bil.DS_Contratto
	Friend WithEvents _daContratto As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents _cmdContrattoInsert As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdContrattoSelectStar As System.Data.SqlClient.SqlCommand
	Friend WithEvents _cmdSelectContrattiClient As System.Data.SqlClient.SqlCommand
	Friend WithEvents _daContrattoClient As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents _cmdContrattoSelectStarById As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me._cmdContrattoUpdate = New System.Data.SqlClient.SqlCommand
		Me._cn = New System.Data.SqlClient.SqlConnection
		Me._cmdContrattoDelete = New System.Data.SqlClient.SqlCommand
		Me._ds_Contratto = New Bil.DS_Contratto
		Me._daContratto = New System.Data.SqlClient.SqlDataAdapter
		Me._cmdContrattoInsert = New System.Data.SqlClient.SqlCommand
		Me._cmdContrattoSelectStar = New System.Data.SqlClient.SqlCommand
		Me._cmdSelectContrattiClient = New System.Data.SqlClient.SqlCommand
		Me._daContrattoClient = New System.Data.SqlClient.SqlDataAdapter
		Me._cmdContrattoSelectStarById = New System.Data.SqlClient.SqlCommand
		CType(Me._ds_Contratto, System.ComponentModel.ISupportInitialize).BeginInit()
		'
		'_cmdContrattoUpdate
		'
		Me._cmdContrattoUpdate.CommandText = "UPDATE dbo.Contratto SET DataInizioValidita = @DataInizioValidita, DataFineValidi" & _
		"ta = @DataFineValidita, CRN = @CRN, StatoContratto = @StatoContratto, CodiceOper" & _
		"atoreSDC = @CodiceOperatoreSDC, TSModifica = @TSmodifica, CodiceOperatoreSDCAcqu" & _
		"irente = @CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente = @CodiceOpera" & _
		"toreSDCCedente, CodiceContratto = @CodiceContratto, ProgrammazionePrivilegiata =" & _
		" @ProgrammazionePrivilegiata, DataStipula = @DataStipula, GestioneTaglio = @Gest" & _
		"ioneTaglio WHERE (IdContratto = @IdContratto)"
		Me._cmdContrattoUpdate.Connection = Me._cn
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoContratto", System.Data.SqlDbType.VarChar, 32, "StatoContratto"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSmodifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCAcquirente"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCCedente"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceContratto", System.Data.SqlDbType.VarChar, 50, "CodiceContratto"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, "ProgrammazionePrivilegiata"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataStipula", System.Data.SqlDbType.DateTime, 4, "DataStipula"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"))
		Me._cmdContrattoUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		'
		'_cn
		'
		Me._cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=False;initial catalog=Bilaterali"
		'
		'_cmdContrattoDelete
		'
		Me._cmdContrattoDelete.CommandText = "DELETE FROM dbo.Contratto WHERE (IdContratto = @IdContratto)"
		Me._cmdContrattoDelete.Connection = Me._cn
		Me._cmdContrattoDelete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		'
		'_ds_Contratto
		'
		Me._ds_Contratto.CaseSensitive = True
		Me._ds_Contratto.DataSetName = "DS_Contratto"
		Me._ds_Contratto.Locale = New System.Globalization.CultureInfo("it-IT")
		'
		'_daContratto
		'
		Me._daContratto.DeleteCommand = Me._cmdContrattoDelete
		Me._daContratto.InsertCommand = Me._cmdContrattoInsert
		Me._daContratto.SelectCommand = Me._cmdContrattoSelectStar
		Me._daContratto.UpdateCommand = Me._cmdContrattoUpdate
		'
		'_cmdContrattoInsert
		'
		Me._cmdContrattoInsert.CommandText = "INSERT INTO dbo.Contratto (CodiceContratto, DataStipula, DataInizioValidita, Data" & _
		"FineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperato" & _
		"reSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, Gestione" & _
		"Taglio) VALUES (@CodiceContratto, @DataStipula, @DataInizioValidita, @DataFineVa" & _
		"lidita, @CRN, @StatoContratto, @CodiceOperatoreSDC, @TSModifica, @CodiceOperator" & _
		"eSDCAcquirente, @CodiceOperatoreSDCCedente, @ProgrammazionePrivilegiata, @Gestio" & _
		"neTaglio); SELECT IdContratto FROM dbo.Contratto WHERE IdContratto = @@IDENTITY"
		Me._cmdContrattoInsert.Connection = Me._cn
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceContratto", System.Data.SqlDbType.VarChar, 50, "CodiceContratto"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataStipula", System.Data.SqlDbType.DateTime, 4, "DataStipula"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StatoContratto", System.Data.SqlDbType.VarChar, 32, "StatoContratto"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCAcquirente"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCCedente"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, "ProgrammazionePrivilegiata"))
		Me._cmdContrattoInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"))
		'
		'_cmdContrattoSelectStar
		'
		Me._cmdContrattoSelectStar.CommandText = "dbo.[spBilGetListaContratti]"
		Me._cmdContrattoSelectStar.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdContrattoSelectStar.Connection = Me._cn
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceSDCTitolare", System.Data.SqlDbType.VarChar, 16))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ragioneSocialeTitolare", System.Data.SqlDbType.VarChar, 256))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ricercaValidoDal", System.Data.SqlDbType.Bit, 1))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@validoDal", System.Data.SqlDbType.DateTime, 8))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ricercaValidoAl", System.Data.SqlDbType.Bit, 1))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@validoAl", System.Data.SqlDbType.DateTime, 8))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@statoContratto", System.Data.SqlDbType.VarChar, 32))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceContratto", System.Data.SqlDbType.VarChar, 50))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceContrattoGRTN", System.Data.SqlDbType.VarChar, 30))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceUnitaSDC", System.Data.SqlDbType.VarChar, 16))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceOpRifUnita", System.Data.SqlDbType.VarChar, 16))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceOpCedente", System.Data.SqlDbType.VarChar, 16))
		Me._cmdContrattoSelectStar.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceOpAcquirente", System.Data.SqlDbType.VarChar, 16))
		'
		'_cmdSelectContrattiClient
		'
		Me._cmdSelectContrattiClient.CommandText = "dbo.[spBilGetListaContrattiClient]"
		Me._cmdSelectContrattiClient.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdSelectContrattiClient.Connection = Me._cn
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceSDCTitolare", System.Data.SqlDbType.VarChar, 16))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ragioneSocialeTitolare", System.Data.SqlDbType.VarChar, 256))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ricercaValidoDal", System.Data.SqlDbType.Bit, 1))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@validoDal", System.Data.SqlDbType.DateTime, 8))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ricercaValidoAl", System.Data.SqlDbType.Bit, 1))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@validoAl", System.Data.SqlDbType.DateTime, 8))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@statoContratto", System.Data.SqlDbType.VarChar, 32))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceContratto", System.Data.SqlDbType.VarChar, 50))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceContrattoGRTN", System.Data.SqlDbType.VarChar, 30))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceUnitaSDC", System.Data.SqlDbType.VarChar, 16))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceOpRifUnita", System.Data.SqlDbType.VarChar, 16))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceOpCedente", System.Data.SqlDbType.VarChar, 16))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@codiceOpAcquirente", System.Data.SqlDbType.VarChar, 16))
		Me._cmdSelectContrattiClient.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdOperatoreLoggato", System.Data.SqlDbType.VarChar, 16))
		'
		'_daContrattoClient
		'
		Me._daContrattoClient.SelectCommand = Me._cmdSelectContrattiClient
		'
		'_cmdContrattoSelectStarById
		'
		Me._cmdContrattoSelectStarById.CommandText = "dbo.[spBilGetContrattoByID]"
		Me._cmdContrattoSelectStarById.CommandType = System.Data.CommandType.StoredProcedure
		Me._cmdContrattoSelectStarById.Connection = Me._cn
		Me._cmdContrattoSelectStarById.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me._cmdContrattoSelectStarById.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4))
		CType(Me._ds_Contratto, System.ComponentModel.ISupportInitialize).EndInit()

	End Sub

#End Region


	Public Function GenerateCRN() As String
		If AppSettingToBoolean("SetCRN_String", False) Then
			Return "C" + Bil.NewId30.Generate()
		Else
			Return Bil.NewId30.Generate()
		End If
	End Function

	Public Function GetContrattoInfoByIdContratto(ByVal idContratto As Integer) As DS_Contratto	' IdContratto > 0 --> ricerca
		_cn.ConnectionString = GetConnectionString()
		Try
			Dim sqlOriCmd As SqlCommand = _daContratto.SelectCommand

			_cmdContrattoSelectStarById.Parameters.Item("@Id").Value = idContratto
			'_cmdContrattoSelectStar.Parameters("@di").Value = DBNull.Value
			'_cmdContrattoSelectStar.Parameters("@df").Value = DBNull.Value

			'Dim c As StringBuilder = New StringBuilder
			'If (idContratto > 0) Then
			'	c.Append(sAnd)
			'	c.Append("C.IdContratto")
			'	c.Append(" = @IdContratto ")
			'	_cmdContrattoSelectStar.Parameters.Add("@IdContratto", idContratto)
			'End If

			'If (c.Length > 0) Then _cmdContrattoSelectStar.CommandText &= c.ToString()

			''_cmdContrattoSelectStar.CommandText += " OPTION (force ORDER)"

			_cn.Open()
			Dim ds As New DS_Contratto
			_daContratto.SelectCommand = _cmdContrattoSelectStarById
			_daContratto.Fill(ds.Contratto)

			_daContratto.SelectCommand = sqlOriCmd
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cn.Dispose()
		End Try
	End Function
	Public Function GetListaContratti( _
	 ByVal codiceSDCTitolare As String, _
	 ByVal ragioneSocialeTitolare As String, _
	 ByVal ricercaValidoDal As Boolean, _
	 ByVal validoDal As DateTime, _
	 ByVal ricercaValidoAl As Boolean, _
	 ByVal validoAl As DateTime, _
	 ByVal statoContratto As String, _
	 ByVal codiceContratto As String, _
	 ByVal codiceContrattoGRTN As String, _
	 ByVal codiceUnitaSDC As String, _
	 ByVal codiceOpRifUnita As String, _
	 ByVal codiceOpCedente As String, _
	 ByVal codiceOpAcquirente As String _
	) As DS_Contratto
		_cn.ConnectionString = GetConnectionString()
		Try

			_cmdContrattoSelectStar.Parameters.Item("@ricercaValidoDal").Value = ricercaValidoDal
			_cmdContrattoSelectStar.Parameters.Item("@ricercaValidoAl").Value = ricercaValidoAl

			If ricercaValidoDal = False Then
				_cmdContrattoSelectStar.Parameters.Item("@validoDal").Value = DBNull.Value
			Else
				_cmdContrattoSelectStar.Parameters.Item("@validoDal").Value = validoDal
			End If

			If ricercaValidoAl = False Then
				_cmdContrattoSelectStar.Parameters.Item("@validoAl").Value = DBNull.Value
			Else
				_cmdContrattoSelectStar.Parameters.Item("@validoAl").Value = validoAl
			End If
			' _cmdContrattoSelectStar.Parameters.Item("@validoAl").Value = validoAl


			'If (ricercaValidoDal) Then
			'	_cmdContrattoSelectStar.Parameters("@di").Value = validoDal
			'Else
			'	_cmdContrattoSelectStar.Parameters("@di").Value = DBNull.Value
			'End If

			'If (ricercaValidoAl) Then
			'	_cmdContrattoSelectStar.Parameters("@df").Value = validoAl
			'Else
			'	_cmdContrattoSelectStar.Parameters("@df").Value = DBNull.Value
			'End If

			'Dim c As StringBuilder = New StringBuilder

			If (Not codiceSDCTitolare Is Nothing AndAlso codiceSDCTitolare <> "") Then
				_cmdContrattoSelectStar.Parameters.Item("@codiceSDCTitolare").Value = codiceSDCTitolare + "%"
				'	c.Append(sAnd)
				'	c.Append(_ds_Contratto.Contratto.CodiceOperatoreSDCColumn.ColumnName)
				'	c.Append(" LIKE @CodiceOperatoreSDC ")
				'	_cmdContrattoSelectStar.Parameters.Add("@CodiceOperatoreSDC", codiceSDCTitolare & "%")
			Else
				_cmdContrattoSelectStar.Parameters.Item("@codiceSDCTitolare").Value = DBNull.Value
			End If

			If (Not ragioneSocialeTitolare Is Nothing AndAlso ragioneSocialeTitolare <> "") Then
				_cmdContrattoSelectStar.Parameters.Item("@ragioneSocialeTitolare").Value = ragioneSocialeTitolare + "%"
				'	c.Append(sAnd)
				'	c.Append(_ds_Contratto.Contratto.Titolare_RagioneSocialeColumn.ColumnName)
				'	c.Append(" LIKE @Titolare_RagioneSociale")
				'	_cmdContrattoSelectStar.Parameters.Add("@Titolare_RagioneSociale", ragioneSocialeTitolare & "%")
			Else
				_cmdContrattoSelectStar.Parameters.Item("@ragioneSocialeTitolare").Value = DBNull.Value
			End If

			''If (ricercaValidoDal And ricercaValidoAl) Then
			''	c.Append(" AND (@RicercaDal <= ")
			''	c.Append(_ds_Contratto.Contratto.DataFineValiditaColumn.ColumnName)
			''	c.Append(" AND @RicercaAl >= ")
			''	c.Append(_ds_Contratto.Contratto.DataInizioValiditaColumn.ColumnName)
			''	c.Append(") ")
			''	_cmdContrattoSelectStar.Parameters.Add("@RicercaAl", validoAl)
			''	_cmdContrattoSelectStar.Parameters.Add("@RicercaDal", validoDal)
			''ElseIf (ricercaValidoDal) Then
			''	c.Append(" AND @RicercaDal <= ")
			''	c.Append(_ds_Contratto.Contratto.DataFineValiditaColumn.ColumnName)
			''	_cmdContrattoSelectStar.Parameters.Add("@RicercaDal", validoDal)

			''ElseIf (ricercaValidoAl) Then
			''	c.Append(" AND @RicercaAl >= ")
			''	c.Append(_ds_Contratto.Contratto.DataInizioValiditaColumn.ColumnName)
			''	_cmdContrattoSelectStar.Parameters.Add("@RicercaAl", validoAl)

			''End If

			If (Not statoContratto Is Nothing AndAlso statoContratto <> "") Then
				_cmdContrattoSelectStar.Parameters.Item("@statoContratto").Value = statoContratto
				'	c.Append(sAnd)
				'	c.Append(_ds_Contratto.Contratto.StatoContrattoColumn.ColumnName)
				'	c.Append(" = @StatoContratto")
				'	_cmdContrattoSelectStar.Parameters.Add("@StatoContratto", statoContratto)
			Else
				_cmdContrattoSelectStar.Parameters.Item("@statoContratto").Value = DBNull.Value
			End If

			If (Not codiceContratto Is Nothing AndAlso codiceContratto <> "") Then
				'	c.Append(sAnd)
				'	c.Append(_ds_Contratto.Contratto.CodiceContrattoColumn.ColumnName)
				'	c.Append(" LIKE @CodiceContratto")
				'	_cmdContrattoSelectStar.Parameters.Add("@CodiceContratto", codiceContratto & "%")
				_cmdContrattoSelectStar.Parameters.Item("@codiceContratto").Value = codiceContratto + "%"
			Else
				_cmdContrattoSelectStar.Parameters.Item("@codiceContratto").Value = DBNull.Value
			End If

			If (Not codiceContrattoGRTN Is Nothing AndAlso codiceContrattoGRTN <> "") Then
				'	c.Append(sAnd)
				'	c.Append(_ds_Contratto.Contratto.CRNColumn.ColumnName)
				'	c.Append(" LIKE @CRN")
				'	_cmdContrattoSelectStar.Parameters.Add("@CRN", codiceContrattoGRTN & "%")
				_cmdContrattoSelectStar.Parameters.Item("@codiceContrattoGRTN").Value = codiceContrattoGRTN + "%"
			Else
				_cmdContrattoSelectStar.Parameters.Item("@codiceContrattoGRTN").Value = DBNull.Value
			End If

			'' Le ricerche di contratti che contengono una certa unita` si possono fare
			'' solo su singola data (validoDal = validoAl ovvero @di = @df).
			If validoDal = validoAl Then
				If (Not codiceUnitaSDC Is Nothing AndAlso codiceUnitaSDC <> "") Then
					_cmdContrattoSelectStar.Parameters.Item("@codiceUnitaSDC").Value = codiceUnitaSDC + "%"
					'		'c.Append(sAnd)
					'		'c.Append("EXISTS (")
					'		'c.Append("  SELECT * ")
					'		'c.Append("  FROM  tab_UnitaContratto(@di) UnitaContratto ")
					'		'c.Append("  WHERE UnitaContratto.CodiceUnitaSDC LIKE @codiceUnitaSDC ")
					'		'c.Append("  AND   UnitaContratto.IdContratto=C.IdContratto")
					'		'c.Append("  AND   UnitaContratto.DataInizioValidita <= ISNULL(@df, DataInizioValidita)")
					'		'c.Append("  AND   UnitaContratto.DataFineValidita >=ISNULL(@di, DataFineValidita)")
					'		'c.Append(")")

					'		c.Append(" and EXISTS (")
					'		c.Append(" select ")
					'		c.Append(" * ")
					'		c.Append(" from SDC_Unita U")
					'		c.Append(" inner join UnitRelate UR")
					'		c.Append(" on ")
					'		c.Append(" UR.CodiceUnitaSDC = U.CodiceUnitaSDC")
					'		c.Append(" and UR.Abilitata = 1")
					'		c.Append(" and UR.TrUC = 1")
					'		c.Append(" and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita)")
					'		c.Append(" and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita)")
					'		c.Append(" and UR.CodiceUnitaSDC LIKE @codiceUnitaSDC")
					'		c.Append(" where")
					'		c.Append(" (")
					'		c.Append("  (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> 'P')")
					'		c.Append("  or")
					'		c.Append("  (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> 'C')")
					'		c.Append(" )")
					'		c.Append(" ) ")
					'		_cmdContrattoSelectStar.Parameters.Add("@codiceUnitaSDC", codiceUnitaSDC & "%")
				Else
					_cmdContrattoSelectStar.Parameters.Item("@codiceUnitaSDC").Value = DBNull.Value
				End If

				If (Not codiceOpRifUnita Is Nothing AndAlso codiceOpRifUnita <> "") Then
					'		c.Append(sAnd)
					'		c.Append("EXISTS (")
					'		'c.Append("  SELECT * ")
					'		'c.Append("  FROM  tab_UnitaContratto(@di) UnitaContratto, SDC_Unita ")
					'		'c.Append("  WHERE ")
					'		'c.Append("        UnitaContratto.IdContratto=C.IdContratto")
					'		'c.Append("  AND   SDC_Unita.CodiceUnitaSDC=UnitaContratto.CodiceUnitaSDC")
					'		'c.Append("  AND   SDC_Unita.CategoriaUnitaSDC=UnitaContratto.CategoriaUnitaSDC")
					'		'c.Append("  AND   SDC_Unita.CodiceOperatoreDiRiferimentoSDC LIKE @OpRif")
					'		'c.Append("  AND   UnitaContratto.DataInizioValidita <= ISNULL(@df, DataInizioValidita)")
					'		'c.Append("  AND   UnitaContratto.DataFineValidita >=ISNULL(@di, DataFineValidita)")

					'		c.Append(" select ")
					'		c.Append(" *")
					'		c.Append(" from SDC_Unita U")
					'		c.Append(" inner join UnitRelate UR")
					'		c.Append(" on ")
					'		c.Append(" UR.CodiceUnitaSDC = U.CodiceUnitaSDC")
					'		c.Append(" and UR.Abilitata = 1")
					'		c.Append(" and UR.TrUC = 1")
					'		c.Append(" and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita)")
					'		c.Append(" and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita)")
					'		c.Append(" and U.CodiceOperatoreDiRiferimentoSDC LIKE @OpRif")
					'		c.Append(" where")
					'		c.Append(" (")
					'		c.Append(" (C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> 'P')")
					'		c.Append(" or")
					'		c.Append(" (C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> 'C')")
					'		c.Append(" )")

					'		c.Append(")")

					'		_cmdContrattoSelectStar.Parameters.Add("@OpRif", codiceOpRifUnita & "%")
					'	End If
					_cmdContrattoSelectStar.Parameters.Item("@codiceOpRifUnita").Value = codiceOpRifUnita + "%"
				Else
					_cmdContrattoSelectStar.Parameters.Item("@codiceOpRifUnita").Value = DBNull.Value
				End If
			Else
				If (Not codiceUnitaSDC Is Nothing AndAlso codiceUnitaSDC.Length > 0) Then
					_cmdContrattoSelectStar.Parameters.Item("@codiceUnitaSDC").Value = codiceUnitaSDC
				Else
					_cmdContrattoSelectStar.Parameters.Item("@codiceUnitaSDC").Value = DBNull.Value
				End If
				If (Not codiceOpRifUnita Is Nothing AndAlso codiceOpRifUnita.Length > 0) Then
					_cmdContrattoSelectStar.Parameters.Item("@codiceOpRifUnita").Value = codiceOpRifUnita
				Else
					_cmdContrattoSelectStar.Parameters.Item("@codiceOpRifUnita").Value = DBNull.Value
				End If
			End If
			If (Not codiceOpAcquirente Is Nothing AndAlso codiceOpAcquirente <> "") Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.CodiceOperatoreSDCAcquirenteColumn.ColumnName)
				'c.Append(" LIKE @opAcquirente")
				'_cmdContrattoSelectStar.Parameters.Add("@opAcquirente", codiceOpAcquirente & "%")
				_cmdContrattoSelectStar.Parameters.Item("@codiceOpAcquirente").Value = codiceOpAcquirente + "%"
			Else
				_cmdContrattoSelectStar.Parameters.Item("@codiceOpAcquirente").Value = DBNull.Value
			End If
			If (Not codiceOpCedente Is Nothing AndAlso codiceOpCedente <> "") Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.CodiceOperatoreSDCCedenteColumn.ColumnName)
				'c.Append(" LIKE @opCedente")
				'_cmdContrattoSelectStar.Parameters.Add("@opCedente", codiceOpCedente & "%")
				_cmdContrattoSelectStar.Parameters.Item("@codiceOpCedente").Value = codiceOpCedente + "%"
			Else
				_cmdContrattoSelectStar.Parameters.Item("@codiceOpCedente").Value = DBNull.Value
			End If


			'If (c.Length > 0) Then _cmdContrattoSelectStar.CommandText += c.ToString()
			'_cmdContrattoSelectStar.CommandText += " OPTION (force ORDER)"

			_cn.Open()
			Dim ds As New DS_Contratto
			_daContratto.Fill(ds.Contratto)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cn.Dispose()
		End Try
	End Function

	Public Function GetListaContrattiClient( _
	 ByVal codiceSDCTitolare As String, _
	 ByVal ragioneSocialeTitolare As String, _
	 ByVal ricercaValidoDal As Boolean, _
	 ByVal validoDal As DateTime, _
	 ByVal ricercaValidoAl As Boolean, _
	 ByVal validoAl As DateTime, _
	 ByVal statoContratto As String, _
	 ByVal codiceContratto As String, _
	 ByVal codiceContrattoGRTN As String, _
	 ByVal codiceUnitaSDC As String, _
	 ByVal codiceOpRifUnita As String, _
	 ByVal codiceOpCedente As String, _
	 ByVal codiceOpAcquirente As String, _
	 ByVal IdOperatoreLoggato As String) As DS_Contratto
		_cn.ConnectionString = GetConnectionString()
		Try
			'' Filtro per l'Id dell'Operatore che si e' Loggato
			'_cmdSelectContrattiClient.Parameters.Clear()
			'_cmdSelectContrattiClient.Parameters.Add("@Operatore", IdOperatoreLoggato)
			_cmdSelectContrattiClient.Parameters.Item("@IdOperatoreLoggato").Value = IdOperatoreLoggato

			'se non sono specificate le date alla query arriva un NULL
			'che viene trattato come "ricerca senze controllare l'intervallo"
			_cmdSelectContrattiClient.Parameters.Item("@ricercaValidoDal").Value = ricercaValidoDal
			_cmdSelectContrattiClient.Parameters.Item("@ricercaValidoAl").Value = ricercaValidoAl

			'_cmdSelectContrattiClient.Parameters.Item("@validoDal").Value = validoDal
			'_cmdSelectContrattiClient.Parameters.Item("@validoAl").Value = validoAl
			If ricercaValidoDal = False Then
				_cmdSelectContrattiClient.Parameters.Item("@validoDal").Value = DBNull.Value
			Else
				_cmdSelectContrattiClient.Parameters.Item("@validoDal").Value = validoDal
			End If

			If ricercaValidoAl = False Then
				_cmdSelectContrattiClient.Parameters.Item("@validoAl").Value = DBNull.Value
			Else
				_cmdSelectContrattiClient.Parameters.Item("@validoAl").Value = validoAl
			End If

			'Dim c As StringBuilder = New StringBuilder

			If (Not codiceSDCTitolare Is Nothing AndAlso codiceSDCTitolare.Length > 0) Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.CodiceOperatoreSDCColumn.ColumnName)
				'c.Append(" LIKE @CodiceOperatoreSDC ")
				'_cmdSelectContrattiClient.Parameters.Add("@CodiceOperatoreSDC", codiceSDCTitolare & "%")
				_cmdSelectContrattiClient.Parameters.Item("@codiceSDCTitolare").Value = codiceSDCTitolare + "%"
			Else
				_cmdSelectContrattiClient.Parameters.Item("@codiceSDCTitolare").Value = DBNull.Value
			End If

			If (Not ragioneSocialeTitolare Is Nothing AndAlso ragioneSocialeTitolare.Length > 0) Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.Titolare_RagioneSocialeColumn.ColumnName)
				'c.Append(" LIKE @Titolare_RagioneSociale")
				'_cmdSelectContrattiClient.Parameters.Add("@Titolare_RagioneSociale", ragioneSocialeTitolare & "%")
				_cmdSelectContrattiClient.Parameters.Item("@ragioneSocialeTitolare").Value = ragioneSocialeTitolare + "%"
			Else
				_cmdSelectContrattiClient.Parameters.Item("@ragioneSocialeTitolare").Value = DBNull.Value
			End If

			If (Not statoContratto Is Nothing AndAlso statoContratto.Length > 0) Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.StatoContrattoColumn.ColumnName)
				'c.Append(" = @StatoContratto")
				'_cmdSelectContrattiClient.Parameters.Add("@StatoContratto", statoContratto)
				_cmdSelectContrattiClient.Parameters.Item("@statoContratto").Value = statoContratto
			Else
				_cmdSelectContrattiClient.Parameters.Item("@statoContratto").Value = statoContratto
			End If

			If (Not codiceContratto Is Nothing AndAlso codiceContratto.Length > 0) Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.CodiceContrattoColumn.ColumnName)
				'c.Append(" LIKE @CodiceContratto")
				'_cmdSelectContrattiClient.Parameters.Add("@CodiceContratto", codiceContratto & "%")
				_cmdSelectContrattiClient.Parameters.Item("@codiceContratto").Value = codiceContratto + "%"
			Else
				_cmdSelectContrattiClient.Parameters.Item("@codiceContratto").Value = DBNull.Value
			End If

			If (Not codiceContrattoGRTN Is Nothing AndAlso codiceContrattoGRTN.Length > 0) Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.CRNColumn.ColumnName)
				'c.Append(" LIKE @CRN")
				'_cmdSelectContrattiClient.Parameters.Add("@CRN", codiceContrattoGRTN & "%")
				_cmdSelectContrattiClient.Parameters.Item("@codiceContrattoGRTN").Value = codiceContrattoGRTN + "%"
			Else
				_cmdSelectContrattiClient.Parameters.Item("@codiceContrattoGRTN").Value = DBNull.Value
			End If

			' Le ricerche di contratti che contengono una certa unita` si possono fare
			' solo su singola data (validoDal = validoAl ovvero @di = @df).
			If ricercaValidoDal AndAlso ricercaValidoAl AndAlso validoDal = validoAl Then

				If (Not codiceUnitaSDC Is Nothing AndAlso codiceUnitaSDC.Length > 0) Then
					' dove esiste una unita` appartenente dell'operatore collegato
					'c.Append(" AND EXISTS (")

					''c.Append("  SELECT * ")
					''c.Append("  FROM  tab_UnitaContratto(@di) UnitaContratto, UnitRelate ")
					''c.Append("  WHERE UnitaContratto.CodiceUnitaSDC LIKE @codiceUnitaSDC ")
					''c.Append("  AND   UnitaContratto.IdContratto=C.IdContratto")
					''c.Append("  AND   UnitaContratto.CodiceUnitaSDC=UnitRelate.CodiceUnitaSDC")
					''c.Append("  AND   UnitaContratto.CategoriaUnitaSDC=UnitRelate.CategoriaUnitaSDC")
					''c.Append("  AND   UnitRelate.CodiceOperatoreSDC = @Operatore")

					'c.Append(" select ")
					'c.Append(" * ")
					'c.Append(" from SDC_Unita U")
					'c.Append(" inner join UnitRelate UR")
					'c.Append(" on ")
					'c.Append(" UR.CodiceOperatoreSDC = @Operatore")
					'c.Append(" and UR.CodiceUnitaSDC = U.CodiceUnitaSDC")
					'c.Append(" and UR.Abilitata = 1")
					'c.Append(" and UR.TrUC = 1")
					'c.Append(" and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita)")
					'c.Append(" and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita)")
					'c.Append(" and U.CodiceUnitaSDC LIKE @codiceUnitaSDC ")
					'c.Append(" where")
					'c.Append(" (")
					'c.Append("	(C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> 'P')")
					'c.Append(" or")
					'c.Append("	(C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> 'C')")
					'c.Append(" ) ")


					'c.Append(")")
					'_cmdSelectContrattiClient.Parameters.Add("@codiceUnitaSDC", codiceUnitaSDC & "%")
					_cmdSelectContrattiClient.Parameters.Item("@codiceUnitaSDC").Value = codiceUnitaSDC
				Else
					_cmdSelectContrattiClient.Parameters.Item("@codiceUnitaSDC").Value = DBNull.Value
				End If

				If (Not codiceOpRifUnita Is Nothing AndAlso codiceOpRifUnita.Length > 0) Then
					'' dove esiste una unita` appartenente dell'operatore collegato che ha come operatore
					'' di riferimento la stringa in codiceOpRifUnita
					'c.Append(" AND EXISTS (")

					''c.Append("  SELECT * ")
					''c.Append("  FROM  ")
					''c.Append("      tab_UnitaContratto(@di) UnitaContratto, ")
					''c.Append("      SDC_Unita, ")
					''c.Append("      UnitRelate ")
					''c.Append("  WHERE ")
					''c.Append("        UnitaContratto.IdContratto=C.IdContratto")
					''c.Append("  AND   SDC_Unita.CodiceUnitaSDC=UnitaContratto.CodiceUnitaSDC")
					''c.Append("  AND   SDC_Unita.CategoriaUnitaSDC=UnitaContratto.CategoriaUnitaSDC")
					''c.Append("  AND   SDC_Unita.CodiceUnitaSDC=UnitRelate.CodiceUnitaSDC")
					''c.Append("  AND   SDC_Unita.CategoriaUnitaSDC=UnitRelate.CategoriaUnitaSDC")
					''c.Append("  AND   SDC_Unita.CodiceOperatoreDiRiferimentoSDC LIKE @OpRif")
					''c.Append("  AND   UnitRelate.CodiceOperatoreSDC = @Operatore")

					'c.Append(" select ")
					'c.Append(" * ")
					'c.Append(" from SDC_Unita U")
					'c.Append(" inner join UnitRelate UR")
					'c.Append(" on ")
					'c.Append(" UR.CodiceOperatoreSDC = @Operatore")
					'c.Append(" and UR.CodiceUnitaSDC = U.CodiceUnitaSDC")
					'c.Append(" and UR.Abilitata = 1")
					'c.Append(" and UR.TrUC = 1")
					'c.Append(" and UR.DataInizioValidita <= ISNULL(@di, UR.DataInizioValidita)")
					'c.Append(" and UR.DataFineValidita   >= ISNULL(@df, UR.DataFineValidita)")
					'c.Append(" and U.CodiceOperatoreDiRiferimentoSDC LIKE @OpRif")
					'c.Append(" where")
					'c.Append(" (")
					'c.Append("	(C.CodiceOperatoreSDCAcquirente = UR.CodiceOperatoreSDC and U.TipoUnita <> 'P')")
					'c.Append(" or")
					'c.Append("	(C.CodiceOperatoreSDCCedente    = UR.CodiceOperatoreSDC and U.TipoUnita <> 'C')")
					'c.Append(" ) ")


					'c.Append(")")
					'_cmdSelectContrattiClient.Parameters.Add("@OpRif", codiceOpRifUnita & "%")
					_cmdSelectContrattiClient.Parameters.Item("@codiceOpRifUnita").Value = codiceOpRifUnita
				Else
					_cmdSelectContrattiClient.Parameters.Item("@codiceOpRifUnita").Value = DBNull.Value
				End If
			Else
				If (Not codiceUnitaSDC Is Nothing AndAlso codiceUnitaSDC.Length > 0) Then
					_cmdSelectContrattiClient.Parameters.Item("@codiceUnitaSDC").Value = codiceUnitaSDC
				Else
					_cmdSelectContrattiClient.Parameters.Item("@codiceUnitaSDC").Value = DBNull.Value
				End If
				If (Not codiceOpRifUnita Is Nothing AndAlso codiceOpRifUnita.Length > 0) Then
					_cmdSelectContrattiClient.Parameters.Item("@codiceOpRifUnita").Value = codiceOpRifUnita
				Else
					_cmdSelectContrattiClient.Parameters.Item("@codiceOpRifUnita").Value = DBNull.Value
				End If
			End If

			If (Not codiceOpAcquirente Is Nothing AndAlso codiceOpAcquirente.Length > 0) Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.CodiceOperatoreSDCAcquirenteColumn.ColumnName)
				'c.Append(" LIKE @opAcquirente")
				'_cmdSelectContrattiClient.Parameters.Add("@opAcquirente", codiceOpAcquirente & "%")
				_cmdSelectContrattiClient.Parameters.Item("@codiceOpAcquirente").Value = codiceOpAcquirente
			Else
				_cmdSelectContrattiClient.Parameters.Item("@codiceOpAcquirente").Value = DBNull.Value
			End If

			If (Not codiceOpCedente Is Nothing AndAlso codiceOpCedente.Length > 0) Then
				'c.Append(sAnd)
				'c.Append(_ds_Contratto.Contratto.CodiceOperatoreSDCCedenteColumn.ColumnName)
				'c.Append(" LIKE @opCedente")
				'_cmdSelectContrattiClient.Parameters.Add("@opCedente", codiceOpCedente & "%")
				_cmdSelectContrattiClient.Parameters.Item("@codiceOpCedente").Value = codiceOpCedente
			Else
				_cmdSelectContrattiClient.Parameters.Item("@codiceOpCedente").Value = DBNull.Value
			End If

			'If (c.Length > 0) Then _cmdSelectContrattiClient.CommandText += c.ToString()
			'_cmdSelectContrattiClient.CommandText += " OPTION (force ORDER)"

			_cn.Open()
			Dim ds As New DS_Contratto
			_daContrattoClient.Fill(ds.Contratto)
			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			_cn.Dispose()
		End Try
	End Function


	Public Sub SaveContratti(ByVal ds As Bil.DS_Contratto)
		_cn.ConnectionString = GetConnectionString()
		Dim tr As SqlTransaction = Nothing
		Try
			_cn.Open()
			tr = _cn.BeginTransaction()
			SetTransaction(_daContratto, tr)

			Dim tm As DateTime = DateTime.Now

			For Each dr As DS_Contratto.ContrattoRow In ds.Contratto
				If (dr.RowState = DataRowState.Modified Or dr.RowState = DataRowState.Added) Then
					dr.TSModifica = tm
				End If
			Next
			_daContratto.Update(ds.Contratto)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			_cn.Dispose()
		End Try

	End Sub

	'Public Function GetNumberOfUnitaContratto(ByVal IdContratto As Integer, ByVal DataRicerca As DateTime) As Integer

	'	_cn.ConnectionString = GetConnectionString()
	'	Try
	'		_cn.Open()

	'		Dim cmd As SqlCommand = New SqlCommand("select count(*) from tab_UnitaContratto(@data) UnitaContratto where IdContratto=@IdContratto", _cn)
	'		cmd.Parameters.Add("@data", DataRicerca)
	'		cmd.Parameters.Add("@IdContratto", IdContratto)
	'		GetNumberOfUnitaContratto = CType(cmd.ExecuteScalar(), Integer)

	'	Catch ex As Exception
	'		smError(ex)
	'		Throw ex
	'	Finally
	'		_cn.Dispose()
	'	End Try
	'   End Function


	Public Function CodiceMnemonicoAlreadyExist(ByVal IdOperatoreTit As String, ByVal CodMnemonico As String) As Boolean
		_cn.ConnectionString = GetConnectionString()
		Try
			_cn.Open()

			Dim cmd As SqlCommand = New SqlCommand("select count(*) from Contratto where CodiceOperatoreSDC=@IdOperatoreTit AND CodiceContratto=@CodMnemonico", _cn)
			cmd.Parameters.Add("@IdOperatoreTit", IdOperatoreTit)
			cmd.Parameters.Add("@CodMnemonico", CodMnemonico)

			If (CType(cmd.ExecuteScalar(), Integer) > 0) Then
				CodiceMnemonicoAlreadyExist = True
			Else
				CodiceMnemonicoAlreadyExist = False
			End If

		Catch ex As Exception
			smError(ex)
			Throw ex
		Finally
			_cn.Dispose()
		End Try
	End Function

End Class
