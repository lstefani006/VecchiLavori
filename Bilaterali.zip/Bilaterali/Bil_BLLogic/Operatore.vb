Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Collections

Public Class Operatore
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        _cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents _cmdOperatoreSelectStar As System.Data.SqlClient.SqlCommand
    Friend WithEvents _daOperatore As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents _dsOperatori As Bil.DS_Operatori
    Friend WithEvents _cmdSelectOperatoreBUS As System.Data.SqlClient.SqlCommand
    Friend WithEvents _daOperatoreBUS As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me._cmdOperatoreSelectStar = New System.Data.SqlClient.SqlCommand
        Me._daOperatore = New System.Data.SqlClient.SqlDataAdapter
        Me._dsOperatori = New Bil.DS_Operatori
        Me._cmdSelectOperatoreBUS = New System.Data.SqlClient.SqlCommand
        Me._daOperatoreBUS = New System.Data.SqlClient.SqlDataAdapter
        CType(Me._dsOperatori, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=BARISONEF;packet size=4096;user id=bil_user;data source=BILSVR1;pe" & _
        "rsist security info=False;initial catalog=Bilaterali"
        '
        '_cmdOperatoreSelectStar
        '
        Me._cmdOperatoreSelectStar.CommandText = "SELECT CodiceOperatoreSDC, StatoBilateraliOperatore, Operatori_TSModifica, Ragion" & _
        "eSociale, CodiceFiscale, PartitaIva, ReferenteAmministrativo, Abilitato, SDC_TSM" & _
        "odifica FROM dbo.Bil_Operatori"
        Me._cmdOperatoreSelectStar.Connection = Me._cn
        '
        '_daOperatore
        '
        Me._daOperatore.SelectCommand = Me._cmdOperatoreSelectStar
        '
        '_dsOperatori
        '
        Me._dsOperatori.CaseSensitive = True
        Me._dsOperatori.DataSetName = "_dsOperatori"
        Me._dsOperatori.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        '_cmdSelectOperatoreBUS
        '
        Me._cmdSelectOperatoreBUS.Connection = Me._cn
        '
        '_daOperatoreBUS
        '
        Me._daOperatoreBUS.SelectCommand = Me._cmdSelectOperatoreBUS
        CType(Me._dsOperatori, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region

#Region " Metodi pubblici BL relativa agli Operatori "
    ' Funzione che recupera la lista degli operatori compatibili con il Codice SDC e la Ragione Sociale 
    ' passati in input
    Public Function GetListaOperatori(ByVal CodiceSDC As String, ByVal RagioneSociale As String) As DS_Operatori
        _cn.ConnectionString = GetConnectionString()
        Try
            Const sAnd As String = " AND "
            ' Appendo alla query di select sulla vista relativa agli Operatori le clausole di LIKE
            ' relative al Codice SDC e alla Ragione Sociale
            Dim c As StringBuilder = New StringBuilder
            If (Not CodiceSDC Is Nothing And CodiceSDC <> "") Then
                c.Append(sAnd)
                c.Append(_dsOperatori.Operatori.CodiceOperatoreSDCColumn.ColumnName)
                c.Append(" LIKE @CodiceSDC ")
                _cmdOperatoreSelectStar.Parameters.Add("@CodiceSDC", CodiceSDC & "%")
            End If

            If (Not RagioneSociale Is Nothing And RagioneSociale <> "") Then
                c.Append(sAnd)
                c.Append(_dsOperatori.Operatori.RagioneSocialeColumn.ColumnName)
                c.Append(" LIKE @RagioneSociale")
                _cmdOperatoreSelectStar.Parameters.Add("@RagioneSociale", RagioneSociale & "%")
            End If
            ' Se l'utente ha inserito almeno un carattere nel Codice SDC o nella Ragione Sociale
            ' devo inserire la condizione di WHERE sulla query
            If (c.Length > 0) Then
                If (_cmdOperatoreSelectStar.CommandText.ToUpper().IndexOf("WHERE") < 0) Then
                    Dim s As String = c.ToString()    ' la stringa costruita sopra
                    If s.StartsWith(sAnd) Then
                        s = s.Substring(sAnd.Length) ' tolgo " AND " iniziale
                    End If

                    _cmdOperatoreSelectStar.CommandText &= " WHERE " & s
                Else
                    _cmdOperatoreSelectStar.CommandText &= c.ToString()
                End If
            End If
            ' Apro la connessione al DB (il remoting che utilizziamo e' quello SINGLE CALL => STATELESS)
            _cn.Open()
            ' Creo un DataSet tipato che conterra` l'elenco degli Operatori...
            Dim ds As New DS_Operatori
            _daOperatore.Fill(ds.Operatori)
            Return ds

        Catch ex As Exception
            ' Log dell'errore
            smError(ex)
            Throw ex
        Finally
            ' Chiudo la connessione al DB
			If (_cn.State = ConnectionState.Open) Then _cn.Close()
        End Try
    End Function

    Public Function GetOperatoriBUS(ByVal DataProgramma As DateTime) As ArrayList
        Dim sBusQueryTmo As String = "BusQueryTmo"
        Try
            _cn.Open()

            _cmdSelectOperatoreBUS.CommandText = "SELECT DISTINCT(CodiceOperatoreSDCAcquirente) as OPERATORE FROM CONTRATTO " & _
                                                "WHERE DataInizioValidita <= @DataProgramma " & _
                                                "AND DataFineValidita >= @DataProgramma " & _
                                                "AND StatoContratto='Abilitato' " & _
                                                "UNION " & _
                                                "SELECT DISTINCT(CodiceOperatoreSDCCedente) as OPERATORE FROM CONTRATTO " & _
                                                "WHERE DataInizioValidita <= @DataProgramma " & _
                                                "AND DataFineValidita >= @DataProgramma " & _
                                                "AND StatoContratto='Abilitato' "


            _cmdSelectOperatoreBUS.Parameters.Add(New SqlClient.SqlParameter("@DataProgramma", DataProgramma))
            _daOperatoreBUS.SelectCommand = _cmdSelectOperatoreBUS

            '
            ' query timeout a 45 secondi salvo specificato diversamente
            '
            _daOperatoreBUS.SelectCommand.CommandTimeout = AppSettingToInt32(sBusQueryTmo, 45)

            Dim ds As New DataSet
            Dim alListaOperatori As New ArrayList

            _daOperatoreBUS.Fill(ds)
            For Each dr As DataRow In ds.Tables(0).Rows
                alListaOperatori.Add(dr("OPERATORE").ToString())
            Next

            Return alListaOperatori
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If (_cn.State = ConnectionState.Open) Then _cn.Close()
        End Try
    End Function

    Public Function GetListaOperatoriAbilitati() As ArrayList
        Try

            _cn.Open()
            Dim strQrySelect As String = "SELECT OpValidi.CodiceOperatoreSDC as OPERATORE " & _
                                         "FROM " & _
                                         "( " & _
                                         "SELECT CodiceOperatoreSDC " & _
                                         "FROM Operatori WHERE " & _
                                         "StatoBilateraliOperatore = 1 " & _
                                         ") OpValidi " & _
                                         "INNER JOIN " & _
                                         "( " & _
                                         "SELECT CodiceOperatoreSDC " & _
                                         "FROM SDC_Operatori WHERE " & _
                                         "Abilitato = 1 " & _
                                         ") SDC_OpAbilitati " & _
                                         "ON OpValidi.CodiceOperatoreSDC = SDC_OpAbilitati.CodiceOperatoreSDC "

            Dim _cmdSelectOpAbilitati As New SqlCommand

            With _cmdSelectOpAbilitati
                .Connection = _cn
                .CommandType = CommandType.Text
                .CommandText = strQrySelect
            End With

            ' DATA ADAPTER
            Dim da As New SqlDataAdapter
            da.SelectCommand = _cmdSelectOpAbilitati

            ' Riempio il DataSet
            Dim ds As New DataSet
            da.Fill(ds, "OperatoriAbilitati")

            ' Costruisco l'array contenente 
            Dim alOp As New ArrayList

            For Each dr As DataRow In ds.Tables("OperatoriAbilitati").Rows
                Dim op As String = dr("OPERATORE").ToString()
                ' Evito che ci siano due codici operatore uguali all'interno dell'arraylist
                If Not (alOp.Contains(op)) Then
                    alOp.Add(op)
                End If
            Next

            Return alOp
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If (_cn.State = ConnectionState.Open) Then _cn.Close()
        End Try
    End Function
#End Region
End Class
