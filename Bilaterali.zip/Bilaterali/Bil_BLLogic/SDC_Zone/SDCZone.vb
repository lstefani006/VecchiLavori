Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Collections

Public Class SDCZone
    Inherits BilBLBase

    Public Function GetSDC_Zone() As DS_SDCZone
        cn.ConnectionString = GetConnectionString()
        Try
            cn.Open()

            Dim ds As New DS_SDCZone
            daSDC_Zone.Fill(ds.SDC_Zone)

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Function

    Public Sub SalvaDataSet(ByVal ds As DS_SDCZone)
        cn.ConnectionString = GetConnectionString()
        Dim tr As SqlTransaction = Nothing
        Try
            cn.Open()
            tr = cn.BeginTransaction()
            SetTransaction(daSDC_Zone, tr)

            daSDC_Zone.Update(ds.SDC_Zone)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw ex
        Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdInsert As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdate As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdDelete As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents daSDC_Zone As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.cmdInsert = New System.Data.SqlClient.SqlCommand
        Me.cmdUpdate = New System.Data.SqlClient.SqlCommand
        Me.cmdDelete = New System.Data.SqlClient.SqlCommand
        Me.cmdSelect = New System.Data.SqlClient.SqlCommand
        Me.daSDC_Zone = New System.Data.SqlClient.SqlDataAdapter
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persis" & _
        "t security info=False;initial catalog=Bilaterali"
        '
        'cmdInsert
        '
        Me.cmdInsert.CommandText = "INSERT INTO dbo.SDC_Zone (CodiceZonaSDC, DescrizioneZona, TSModifica, Responsabil" & _
        "eAggiornamento, Type) VALUES (@CodiceZonaSDC, @DescrizioneZona, @TSModifica, @Re" & _
        "sponsabileAggiornamento, @Type)"
        Me.cmdInsert.Connection = Me.cn
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, "CodiceZonaSDC"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizioneZona", System.Data.SqlDbType.VarChar, 256, "DescrizioneZona"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Type", System.Data.SqlDbType.VarChar, 50, "Type"))
        '
        'cmdUpdate
        '
        Me.cmdUpdate.CommandText = "UPDATE dbo.SDC_Zone SET DescrizioneZona = @DescrizioneZona, TSModifica = GETDATE(" & _
        "), Type = @Type, ResponsabileAggiornamento = @ResponsabileAggiornamento WHERE (C" & _
        "odiceZonaSDC = @CodiceZonaSDC)"
        Me.cmdUpdate.Connection = Me.cn
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizioneZona", System.Data.SqlDbType.VarChar, 256, "DescrizioneZona"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Type", System.Data.SqlDbType.VarChar, 50, "Type"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceZonaSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmdDelete
        '
        Me.cmdDelete.CommandText = "DELETE FROM dbo.SDC_Zone WHERE (CodiceZonaSDC = @CodiceZonaSDC)"
        Me.cmdDelete.Connection = Me.cn
        Me.cmdDelete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceZonaSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmdSelect
        '
        Me.cmdSelect.CommandText = "SELECT dbo.SDC_Zone.* FROM dbo.SDC_Zone"
        Me.cmdSelect.Connection = Me.cn
        '
        'daSDC_Zone
        '
        Me.daSDC_Zone.DeleteCommand = Me.cmdDelete
        Me.daSDC_Zone.InsertCommand = Me.cmdInsert
        Me.daSDC_Zone.SelectCommand = Me.cmdSelect
        Me.daSDC_Zone.UpdateCommand = Me.cmdUpdate

    End Sub

#End Region

End Class
