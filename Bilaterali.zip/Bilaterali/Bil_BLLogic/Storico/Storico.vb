Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Type
Imports System.io
Imports System.Collections
Imports System.Collections.Specialized
Imports System.Xml

Public Class Storico
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		components = New System.ComponentModel.Container
	End Sub

#End Region

	Private Function GetWebServerList() As StringCollection

		Dim cs As New System.Collections.Specialized.StringCollection

		Dim ws As New WSStorico.Storico
		ws.WSAuthHeaderValue = New WSStorico.WSAuthHeader
		Bil_Crypt.WSClient.Setup(ws, ws.WSAuthHeaderValue.Username, ws.WSAuthHeaderValue.Password, "WSStorico")

		cs.Add(ws.Url)

		Dim i As Integer = 0
		While i < AppSettingToInt32("WSStorico_UrlAlternateAddrCount", 0)
			Dim k As String = String.Format("WSStorico_UrlAlternateAddr{0}", i)
			Dim v As String = AppSettingToString(k)
			If v Is Nothing OrElse v.Length = 0 Then Exit While
			cs.Add(v)
			i += 1
		End While

		Return cs

	End Function

	Public Sub Cancella()

		smTrace("Storico cancellazione - inizio elaborazione")


		For Each u As String In GetWebServerList()
			Try
				Dim ws As New WSStorico.Storico
				ws.WSAuthHeaderValue = New WSStorico.WSAuthHeader
				Bil_Crypt.WSClient.Setup(ws, ws.WSAuthHeaderValue.Username, ws.WSAuthHeaderValue.Password, "WSStorico")

				ws.Url = u
				ws.Cancella()
			Catch ex As Exception
				smError(ex, "Storico cancellazione")
			End Try
		Next
		smTrace("Storico cancellazione - fine elaborazione")

	End Sub

	Public Sub GeneraStorico(ByVal dataFlusso As DateTime)
		smTrace(String.Format("Storico genera - inizio elaborazione data={0}", dataFlusso))

		GetStoricoQuantitaProgrammi(dataFlusso)

		smTrace("Storico genera - fine elaborazione")
	End Sub


	Private Sub GetStoricoQuantitaProgrammi(ByVal dataFlusso As DateTime)

		Dim cn As New SqlConnection
		cn.ConnectionString = GetConnectionString()

		Try
			cn.Open()

			Dim sqlCmd As New SqlCommand
			sqlCmd.Connection = cn
			sqlCmd.CommandText = ""
			sqlCmd.CommandText += " select distinct CodiceOperatoreSDCCedente    Operatore from Contratto where DataInizioValidita <= @d and DataFineValidita >= @d "
			sqlCmd.CommandText += " union "
			sqlCmd.CommandText += " select distinct CodiceOperatoreSDCAcquirente Operatore from Contratto where DataInizioValidita <= @d and DataFineValidita >= @d "

			sqlCmd.Parameters.Add("@d", dataFlusso.Date)

			Dim opList As New ArrayList

			Dim rd As SqlDataReader
			Try
				'
				' set query timeout
				'
				sqlCmd.CommandTimeout = AppSettingToInt32("StoricoQueryTmo", 60)
				rd = sqlCmd.ExecuteReader()
				While rd.Read()
					opList.Add(DirectCast(rd("Operatore"), String))
				End While
			Finally
				If Not rd Is Nothing Then rd.Close()
			End Try


			Dim nop As Integer = 0
			For Each op As String In opList

				smTrace("Genera storico - operatore " + op)

				nop += 1
				Dim ds As DataSet = GetStoricoQuantitaProgrammiPerOperatore(cn, op, dataFlusso)

				Dim fileName As String
				Dim contenutoFile As Byte()
				Dim tipoFile As String
				Dim descrizioneFile As String
				Dim dataCreazione As DateTime
				Dim dataCancellazione As DateTime

				tipoFile = "QTYPGM"
				descrizioneFile = "Storico quantita` programmi"
				dataCreazione = DateTime.Now
				dataCancellazione = DateTime.Now.Date.AddYears(1)
				fileName = String.Format("{0}_{1}_{2:yyyy}{2:MM}{2:dd}.xml", tipoFile, op, dataFlusso)

				Dim ms As New MemoryStream
				Dim tw As New XmlTextWriter(ms, Encoding.GetEncoding("iso-8859-1"))

				tw.Formatting = Formatting.Indented
				tw.IndentChar = "	"c
				tw.Indentation = 1

				tw.WriteStartDocument()

				ds.WriteXml(tw)

				tw.WriteEndDocument()

				tw.Flush()
				tw.Close()

				contenutoFile = ms.ToArray

				For Each u As String In GetWebServerList()
					Try
						Dim ws As New WSStorico.Storico
						ws.WSAuthHeaderValue = New WSStorico.WSAuthHeader
						Bil_Crypt.WSClient.Setup(ws, ws.WSAuthHeaderValue.Username, ws.WSAuthHeaderValue.Password, "WSStorico")

						ws.Url = u
						ws.Pubblica(op, fileName, contenutoFile, tipoFile, descrizioneFile, dataCreazione, dataFlusso, dataCancellazione)

					Catch ex As Exception
						smError(ex, "Storico pubblicazione")
					End Try
				Next


				Dim msg As String = String.Format("Storico quantita` programmi per operatore {0}, ({1}/{2})", op, nop, opList.Count)
				BatchSerializer.SetProgressBatch(msg)

				smTrace("Genera storico - fine elaborazione per op=" + op)
			Next

		Catch ex As Exception
			smError(ex, "Genera storico")
			Throw

		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Sub

	Private Function GetStoricoQuantitaProgrammiPerOperatore(ByVal cn As SqlConnection, ByVal operatore As String, ByVal dataFlusso As DateTime) As DataSet

		Try
			Dim codiceUnitaSDC As String = String.Empty
			Dim codiceZonaSDC As String = String.Empty
			Dim stato As String = String.Empty
			Dim ora As String = String.Empty

			Dim idContratto As String = String.Empty
			Dim dataInizio As DateTime = dataFlusso
			Dim dataFine As DateTime = dataFlusso

			Dim sSql As String
			sSql = "select "
			sSql = sSql + "QMGP.CodiceUnitaSDC, "
			sSql = sSql + "QMGP.CodiceZonaSDC, "
			sSql = sSql + "QMGP.DataProgramma, "
			sSql = sSql + "QMGP.Stato, "
			sSql = sSql + "QMGP.DO, "
			sSql = sSql + "QMGP.Ora, "
			sSql = sSql + "QMGP.QuO, "
			sSql = sSql + "QMGP.QuTaglio, "
			sSql = sSql + "QMGP.QuA, "
			sSql = sSql + "QMGP.PrA, "
			sSql = sSql + "QMGP.GMEId, "
			sSql = sSql + "QMGP.Operatore, "
			sSql = sSql + "QMGP.OperatoreTitolare, "
			sSql = sSql + "QMGP.IdContratto, "
			sSql = sSql + "QMGP.ReasonText "

			sSql = sSql + "from "
			sSql = sSql + "( "
			sSql = sSql + "select "
			sSql = sSql + "ProgrammaOrarioPerUnita.CodiceUnitaSDC, "
			sSql = sSql + "SDC_PuntiDiScambioRilevanti.CodiceZonaSDC, "
			sSql = sSql + "ProgrammaOrarioPerUnita.DataProgramma, "

			sSql = sSql + "case when ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP Is Null Then"
			sSql = sSql + "     case ProgrammaOrarioPerUnita.QtyMWhBilanciamento when 0 then 'Tagliata' else"
			sSql = sSql + "         case when ProgrammaOrarioPerUnita.GMEReferenceNumber is  Null then 'NonInviata' else"
			sSql = sSql + "             case ProgrammaOrarioPerUnitaErrori.Origin when 'FA' then 'RifiutataFA' "
			sSql = sSql + "                     when 'BN' then 'RifiutataBN' "
			sSql = sSql + "                     else 'NonElabMGP' "
			sSql = sSql + "             end "
			sSql = sSql + "         end "
			sSql = sSql + "     end "
			sSql = sSql + "     else "
			sSql = sSql + "         case when ProgrammaOrarioPerUnita.QtyMWhBilanciamento Is Null then	"
			sSql = sSql + "             case  when round(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,3)=round(ProgrammaOrarioPerUnita.QtyMWh,3) then 'Accettata' "
			sSql = sSql + "                   when abs(round(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,3))<abs(round(ProgrammaOrarioPerUnita.QtyMWh,3)) then 'Acc. Parz.' "
			sSql = sSql + "             end "
			sSql = sSql + "             else "
			sSql = sSql + "             case    when round(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,3)=round(ProgrammaOrarioPerUnita.QtyMWhBilanciamento,3) then 'Accettata' "
			sSql = sSql + "                     when abs(round(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP,3))<abs(round(ProgrammaOrarioPerUnita.QtyMWhBilanciamento,3)) then 'Acc. Parz.' "
			sSql = sSql + "             end "
			sSql = sSql + "     end "
			sSql = sSql + "end Stato, "

			sSql = sSql + "case sign(ProgrammaOrarioPerUnita.QtyMWh) when 1 then 'OFF' when -1 then 'DOM' else '' end DO, "
			sSql = sSql + "ProgrammaOrarioPerUnita.PeriodoRilevante Ora, "
			sSql = sSql + "abs(ProgrammaOrarioPerUnita.QtyMWh) QuO, "
			sSql = sSql + "abs(ProgrammaOrarioPerUnita.QtyMWhBilanciamento) QuTaglio, "
			sSql = sSql + "abs(ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP) QuA, "
			sSql = sSql + "case SDC_Unita.TipoUnita when 'P' then PrezzoZonale.Prezzo when 'M' then PrezzoZonale.Prezzo else PrezzoUnitario.Prezzo end PrA, "
			sSql = sSql + "ProgrammaOrarioPerUnita.GMEReferenceNumber GMEId, "
			sSql = sSql + "case ProgrammaOrarioPerUnita.ProgrammatoDalCedente when 1 then Contratto.CodiceOperatoreSDCCedente else Contratto.CodiceOperatoreSDCAcquirente end Operatore, "
			sSql = sSql + "Contratto.CodiceOperatoreSDC OperatoreTitolare, "
			sSql = sSql + "ProgrammaOrarioPerUnita.IdContratto IdContratto, "

			'
			' Da mostrare se non null: non riportati sulla query originaria
			'
			sSql = sSql + "case when ProgrammaOrarioPerUnitaErrori.Origin is NULL then '' else ProgrammaOrarioPerUnitaErrori.Origin end Origin, "
			sSql = sSql + "case when ProgrammaOrarioPerUnitaErrori.ReasonCode is NULL then '' else ProgrammaOrarioPerUnitaErrori.ReasonCode end ReasonCode, "
			sSql = sSql + "case when ProgrammaOrarioPerUnitaErrori.ReasonText is NULL then '' else ProgrammaOrarioPerUnitaErrori.ReasonText end ReasonText "

			sSql = sSql + "from ProgrammaOrarioPerUnita "

			'
			' JOIN per recuperare eventuali errori (su FA o BN)
			'
			sSql = sSql + "left outer join ProgrammaOrarioPerUnitaErrori "
			sSql = sSql + "on ProgrammaOrarioPerUnita.IdContratto = ProgrammaOrarioPerUnitaErrori.IdContratto "
			sSql = sSql + "and ProgrammaOrarioPerUnita.DataProgramma = ProgrammaOrarioPerUnitaErrori.DataProgramma "
			sSql = sSql + "and ProgrammaOrarioPerUnita.PeriodoRilevante = ProgrammaOrarioPerUnitaErrori.PeriodoRilevante "
			sSql = sSql + "and ProgrammaOrarioPerUnita.CategoriaUnitaSDC = ProgrammaOrarioPerUnitaErrori.CategoriaUnitaSDC "
			sSql = sSql + "and ProgrammaOrarioPerUnita.CodiceUnitaSDC = ProgrammaOrarioPerUnitaErrori.CodiceUnitaSDC "

			sSql = sSql + "inner join SDC_Unita "
			sSql = sSql + "on ProgrammaOrarioPerUnita.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC "
			sSql = sSql + "and ProgrammaOrarioPerUnita.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC "
			sSql = sSql + "inner join SDC_PuntiDiScambioRilevanti "
			sSql = sSql + "on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC "
			sSql = sSql + "inner join Contratto "
			sSql = sSql + "on ProgrammaOrarioPerUnita.IdContratto = Contratto.IdContratto "
			'sSql = sSql + "inner join PrezzoUnitario "
			sSql = sSql + "left outer join PrezzoUnitario "
			sSql = sSql + "on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma "
			sSql = sSql + "and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
			'sSql = sSql + "inner join PrezzoZonale "
			sSql = sSql + "left outer join PrezzoZonale "
			sSql = sSql + "on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma "
			sSql = sSql + "and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
			sSql = sSql + "and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC "


			sSql = sSql + "inner join ProgrammaOrario "
			sSql = sSql + "on ProgrammaOrario.IdContratto = ProgrammaOrarioPerUnita.IdContratto "
			sSql = sSql + "And ProgrammaOrario.DataProgramma = ProgrammaOrarioPerUnita.DataProgramma "
			sSql = sSql + "And ProgrammaOrario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante "
			sSql = sSql + "where "

			sSql = sSql + "ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato = 1 "
			sSql = sSql + "and ProgrammaOrario.ProgrammaOrarioValidato = 1 "
			sSql = sSql + ") "
			sSql = sSql + "QMGP "
			sSql = sSql + "where @DataInizio <= QMGP.DataProgramma and QMGP.DataProgramma <= @DataFine "
			If stato <> "" Then
				sSql = sSql + "and QMGP.Stato = @Stato "
			End If
			If codiceZonaSDC <> "" Then
				sSql = sSql + "and QMGP.CodiceZonaSDC = @CodiceZonaSDC "
			End If
			If codiceUnitaSDC <> "" Then
				sSql = sSql + "and QMGP.CodiceUnitaSDC = @CodiceUnitaSDC "
			End If
			If ora <> "" Then
				sSql = sSql + "and QMGP.Ora = @Ora "
			End If
			If operatore <> "" Then
				sSql = sSql + "and QMGP.Operatore = @Operatore "
			End If
			If idContratto <> "" Then
				sSql = sSql + "and QMGP.IdContratto = @IdContratto "
			End If

			sSql = sSql + "order by "
			sSql = sSql + "QMGP.CodiceUnitaSDC, "
			sSql = sSql + "QMGP.CodiceZonaSDC, "
			sSql = sSql + "QMGP.DataProgramma, "
			sSql = sSql + "QMGP.Ora "

			Dim cmdSelect As New SqlCommand
			cmdSelect.CommandText = sSql
			cmdSelect.Connection = cn

			cmdSelect.Parameters.Clear()
			cmdSelect.Parameters.Add("@DataInizio", dataInizio)
			cmdSelect.Parameters.Add("@DataFine", dataFine)
			If operatore <> "" Then
				cmdSelect.Parameters.Add("@Operatore", operatore)
			End If
			If codiceUnitaSDC <> "" Then
				cmdSelect.Parameters.Add("@CodiceUnitaSDC", codiceUnitaSDC)
			End If
			If codiceZonaSDC <> "" Then
				cmdSelect.Parameters.Add("@CodiceZonaSDC", codiceZonaSDC)
			End If
			If stato <> "" Then
				cmdSelect.Parameters.Add("@Stato", stato)
			End If
			If ora <> "" Then
				cmdSelect.Parameters.Add("@Ora", CType(ora, Integer))
			End If
			If idContratto <> "" Then
				cmdSelect.Parameters.Add("@IdContratto", idContratto)
			End If

			Dim ds As New DataSet
			ds.Tables.Add("QtyPgm")

			Dim da As New SqlDataAdapter
			da.SelectCommand = cmdSelect

			ds.DataSetName = "StoricoQtyProgrammi"

			'
			' Set command timeout (default 60 secondi)
			'
			da.SelectCommand.CommandTimeout = AppSettingToInt32("StoricoQueryTmo", 60)
			da.Fill(ds.Tables("QtyPgm"))

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		End Try
	End Function


End Class
