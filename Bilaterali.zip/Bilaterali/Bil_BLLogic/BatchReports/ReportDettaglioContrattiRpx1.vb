Imports System
Imports DataDynamics.ActiveReports
Imports DataDynamics.ActiveReports.Document
Imports System.Data
Imports System.Configuration

Public Class ReportDettaglioContrattiRpx
    Inherits ActiveReport

    Private _SubReport As SubReportDettagliocontratti = Nothing
    Private cString As String

    Public Sub New()
        MyBase.New()
        InitializeReport()
    End Sub
#Region "ActiveReports Designer generated code"
    Private WithEvents ReportHeader As DataDynamics.ActiveReports.ReportHeader = Nothing
    Private WithEvents PageHeader As DataDynamics.ActiveReports.PageHeader = Nothing
    Private WithEvents Detail As DataDynamics.ActiveReports.Detail = Nothing
    Private WithEvents PageFooter As DataDynamics.ActiveReports.PageFooter = Nothing
    Private WithEvents ReportFooter As DataDynamics.ActiveReports.ReportFooter = Nothing
	Private Label4 As DataDynamics.ActiveReports.Label = Nothing
	Private Shape1 As DataDynamics.ActiveReports.Shape = Nothing
	Private Label5 As DataDynamics.ActiveReports.Label = Nothing
	Public lbData As DataDynamics.ActiveReports.Label = Nothing
	Private Label1 As DataDynamics.ActiveReports.Label = Nothing
	Private Label2 As DataDynamics.ActiveReports.Label = Nothing
	Private Label3 As DataDynamics.ActiveReports.Label = Nothing
	Private Line1 As DataDynamics.ActiveReports.Line = Nothing
	Private Label6 As DataDynamics.ActiveReports.Label = Nothing
	Private Label7 As DataDynamics.ActiveReports.Label = Nothing
	Private Label8 As DataDynamics.ActiveReports.Label = Nothing
	Private CRN As DataDynamics.ActiveReports.TextBox = Nothing
	Private CodiceContratto As DataDynamics.ActiveReports.TextBox = Nothing
	Private Bilanciato As DataDynamics.ActiveReports.TextBox = Nothing
	Private SubReport1 As DataDynamics.ActiveReports.SubReport = Nothing
	Public Sub InitializeReport()
		Me.LoadLayout(Me.GetType, "Bil.ReportDettaglioContrattiRpx.rpx")
		Me.ReportHeader = CType(Me.Sections("ReportHeader"),DataDynamics.ActiveReports.ReportHeader)
		Me.PageHeader = CType(Me.Sections("PageHeader"),DataDynamics.ActiveReports.PageHeader)
		Me.Detail = CType(Me.Sections("Detail"),DataDynamics.ActiveReports.Detail)
		Me.PageFooter = CType(Me.Sections("PageFooter"),DataDynamics.ActiveReports.PageFooter)
		Me.ReportFooter = CType(Me.Sections("ReportFooter"),DataDynamics.ActiveReports.ReportFooter)
		Me.Label4 = CType(Me.ReportHeader.Controls(0),DataDynamics.ActiveReports.Label)
		Me.Shape1 = CType(Me.ReportHeader.Controls(1),DataDynamics.ActiveReports.Shape)
		Me.Label5 = CType(Me.ReportHeader.Controls(2),DataDynamics.ActiveReports.Label)
		Me.lbData = CType(Me.ReportHeader.Controls(3),DataDynamics.ActiveReports.Label)
		Me.Label1 = CType(Me.PageHeader.Controls(0),DataDynamics.ActiveReports.Label)
		Me.Label2 = CType(Me.PageHeader.Controls(1),DataDynamics.ActiveReports.Label)
		Me.Label3 = CType(Me.PageHeader.Controls(2),DataDynamics.ActiveReports.Label)
		Me.Line1 = CType(Me.PageHeader.Controls(3),DataDynamics.ActiveReports.Line)
		Me.Label6 = CType(Me.PageHeader.Controls(4),DataDynamics.ActiveReports.Label)
		Me.Label7 = CType(Me.PageHeader.Controls(5),DataDynamics.ActiveReports.Label)
		Me.Label8 = CType(Me.PageHeader.Controls(6),DataDynamics.ActiveReports.Label)
		Me.CRN = CType(Me.Detail.Controls(0),DataDynamics.ActiveReports.TextBox)
		Me.CodiceContratto = CType(Me.Detail.Controls(1),DataDynamics.ActiveReports.TextBox)
		Me.Bilanciato = CType(Me.Detail.Controls(2),DataDynamics.ActiveReports.TextBox)
		Me.SubReport1 = CType(Me.Detail.Controls(3),DataDynamics.ActiveReports.SubReport)
	End Sub

#End Region

    'DataInitialize Event
    'ActiveReports event that is called during the report initalization
    'procedure. (after .Run is called on your report object)  Normally used
    'with unbound reporting to establish an active connection to your data
    'to be used with the FetchData event, or to setup a bound report with a
    'dynamic database connection at runtime.
	Private Sub ReportDettaglioContrattiRpx_DataInitialize(ByVal sender As Object, ByVal eArgs As System.EventArgs) Handles MyBase.DataInitialize
	End Sub

	'Report Event
	'ActiveReports event that is called before report finishes running.
	'Normally used to clean up after any objects used in the report -
	'(Subreport objects, custom data objects, etc)
	Private Sub ReportDettaglioContrattiRpx_ReportEnd(ByVal sender As Object, ByVal eArgs As System.EventArgs) Handles MyBase.ReportEnd
		'clean up existing subreport document object
		_SubReport.Document.Dispose()
		'clean up existing subreport object
		_SubReport.Dispose()
		'Reset subreport to null, so if this report is called again it will reinit inside the section format event
		_SubReport = Nothing
	End Sub	'ReportDettaglioContrattiRpx_ReportEnd

	Private Sub Detail_Format(ByVal sender As Object, ByVal e As System.EventArgs) Handles Detail.Format

		Dim ds As DataDynamics.ActiveReports.DataSources.SqlDBDataSource
		If _SubReport Is Nothing Then
			_SubReport = New SubReportDettagliocontratti
			Me.SubReport1.Report = _SubReport

			ds = New DataDynamics.ActiveReports.DataSources.SqlDBDataSource
			Me.SubReport1.Report.DataSource = ds
		Else
			ds = CType(Me.SubReport1.Report.DataSource, DataDynamics.ActiveReports.DataSources.SqlDBDataSource)
		End If

		ds.ConnectionString = ConfigurationSettings.AppSettings("SqlConnectionString")

		Dim crn As String = ""
		If Not Me.Fields("CRN").Value Is Nothing Then
			crn = Me.Fields("CRN").Value.ToString()
		End If

		If Me.Fields("Bilanciato").Value Is Nothing OrElse Me.Fields("Bilanciato").Value.ToString.ToUpper = "Bilanciato".ToUpper Then
			crn = ""
		End If

		ds.SQL = "Select "
		ds.SQL += "PeriodoRilevante, "
		ds.SQL += "case Bilanciato when 1 then 'Bilanciato' when 0 then 'Non bilanciato' else '' end Bilanciato, "
		ds.SQL += "SbilanciamentoMWhReale "
		ds.SQL += "FROM ProgrammaOrario PO "
		ds.SQL += "INNER JOIN Contratto CO "
		ds.SQL += " ON CO.IdContratto = PO.IdContratto "
		'		ds.SQL += " AND PO.DataProgramma = '" + Me.lbData.Text + "'"
		ds.SQL += " WHERE PO.DataProgramma = '" + Me.lbData.Text + "' "
		ds.SQL += " AND CRN = '" + crn + "' ORDER BY PeriodoRilevante "

	End Sub
End Class