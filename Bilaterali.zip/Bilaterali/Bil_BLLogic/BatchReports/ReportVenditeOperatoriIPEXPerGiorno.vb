Imports System
Imports DataDynamics.ActiveReports
Imports DataDynamics.ActiveReports.Document

Public Class ReportVenditeOperatoriIPEXPerGiorno
Inherits ActiveReport
	Public Sub New()
	MyBase.New()
		InitializeReport()
	End Sub
	#Region "ActiveReports Designer generated code"
    Private WithEvents ReportHeader As DataDynamics.ActiveReports.ReportHeader = Nothing
    Private WithEvents PageHeader As DataDynamics.ActiveReports.PageHeader = Nothing
    Private WithEvents Detail As DataDynamics.ActiveReports.Detail = Nothing
    Private WithEvents PageFooter As DataDynamics.ActiveReports.PageFooter = Nothing
    Private WithEvents ReportFooter As DataDynamics.ActiveReports.ReportFooter = Nothing
	Private Label7 As DataDynamics.ActiveReports.Label = Nothing
	Private Label10 As DataDynamics.ActiveReports.Label = Nothing
	Private Label11 As DataDynamics.ActiveReports.Label = Nothing
	Private Label12 As DataDynamics.ActiveReports.Label = Nothing
	Private Label13 As DataDynamics.ActiveReports.Label = Nothing
	Private Label14 As DataDynamics.ActiveReports.Label = Nothing
	Private Label15 As DataDynamics.ActiveReports.Label = Nothing
	Public txtPeriodo As DataDynamics.ActiveReports.TextBox = Nothing
	Private Label16 As DataDynamics.ActiveReports.Label = Nothing
	Private NomeOperatore As DataDynamics.ActiveReports.TextBox = Nothing
	Private CodiceOperatore As DataDynamics.ActiveReports.TextBox = Nothing
	Private QuantitaVenduteMWh As DataDynamics.ActiveReports.TextBox = Nothing
	Private ControvaloreEuro As DataDynamics.ActiveReports.TextBox = Nothing
	Private IvaEuro As DataDynamics.ActiveReports.TextBox = Nothing
	Private TotaleVenditeEuro As DataDynamics.ActiveReports.TextBox = Nothing
	Private txtData As DataDynamics.ActiveReports.TextBox = Nothing
	Public Sub InitializeReport()
		Me.LoadLayout(Me.GetType, "Bil.ReportVenditeOperatoriIPEXPerGiorno.rpx")
		Me.ReportHeader = CType(Me.Sections("ReportHeader"),DataDynamics.ActiveReports.ReportHeader)
		Me.PageHeader = CType(Me.Sections("PageHeader"),DataDynamics.ActiveReports.PageHeader)
		Me.Detail = CType(Me.Sections("Detail"),DataDynamics.ActiveReports.Detail)
		Me.PageFooter = CType(Me.Sections("PageFooter"),DataDynamics.ActiveReports.PageFooter)
		Me.ReportFooter = CType(Me.Sections("ReportFooter"),DataDynamics.ActiveReports.ReportFooter)
		Me.Label7 = CType(Me.ReportHeader.Controls(0),DataDynamics.ActiveReports.Label)
		Me.Label10 = CType(Me.ReportHeader.Controls(1),DataDynamics.ActiveReports.Label)
		Me.Label11 = CType(Me.ReportHeader.Controls(2),DataDynamics.ActiveReports.Label)
		Me.Label12 = CType(Me.ReportHeader.Controls(3),DataDynamics.ActiveReports.Label)
		Me.Label13 = CType(Me.ReportHeader.Controls(4),DataDynamics.ActiveReports.Label)
		Me.Label14 = CType(Me.ReportHeader.Controls(5),DataDynamics.ActiveReports.Label)
		Me.Label15 = CType(Me.ReportHeader.Controls(6),DataDynamics.ActiveReports.Label)
		Me.txtPeriodo = CType(Me.ReportHeader.Controls(7),DataDynamics.ActiveReports.TextBox)
		Me.Label16 = CType(Me.ReportHeader.Controls(8),DataDynamics.ActiveReports.Label)
		Me.NomeOperatore = CType(Me.Detail.Controls(0),DataDynamics.ActiveReports.TextBox)
		Me.CodiceOperatore = CType(Me.Detail.Controls(1),DataDynamics.ActiveReports.TextBox)
		Me.QuantitaVenduteMWh = CType(Me.Detail.Controls(2),DataDynamics.ActiveReports.TextBox)
		Me.ControvaloreEuro = CType(Me.Detail.Controls(3),DataDynamics.ActiveReports.TextBox)
		Me.IvaEuro = CType(Me.Detail.Controls(4),DataDynamics.ActiveReports.TextBox)
		Me.TotaleVenditeEuro = CType(Me.Detail.Controls(5),DataDynamics.ActiveReports.TextBox)
		Me.txtData = CType(Me.Detail.Controls(6),DataDynamics.ActiveReports.TextBox)
	End Sub

	#End Region
End Class
