Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema
Imports SystemMonitor
Imports System.Threading
Imports System.Collections.Specialized
Imports DataDynamics.ActiveReports
Imports DataDynamics.ActiveReports.Export.Pdf
Imports DataDynamics.ActiveReports.Export.Xls
Imports DataDynamics.SpreadBuilder
Imports DataDynamics.SpreadBuilder.Style


Public Class BatchReports
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		components = New System.ComponentModel.Container
	End Sub

#End Region


#Region "ReportVenditeOperatoriIPEX"
	Class ReportVenditeOperatori_Data
		Public di As DateTime
		Public df As DateTime
		Public opDestinatarioReport As String
		Public nomeFile As String
		Public tipoFile As String
		Public descrizioneFile As String
		Public dettaglioPerGiorno As Boolean
	End Class

	Public Function ReportVenditeOperatoriIPEX(ByVal opDestinatarioReport As String, ByVal di As DateTime, ByVal df As DateTime, ByVal dettaglioPerGiorno As Boolean, ByVal runningOperator As String) As String

		Dim data As New ReportVenditeOperatori_Data
		data.di = di
		data.df = df
		data.opDestinatarioReport = opDestinatarioReport

		If dettaglioPerGiorno Then
			data.nomeFile = String.Format("RPRVOPIPEXD_{0:yyyy}{0:MM}{0:dd}_{1:yyyy}{1:MM}{1:dd}.xls", data.di, data.df)
			data.tipoFile = "RVOPIPEXD"
			data.descrizioneFile = String.Format("Report vendite operatori IPEX con P>C dal:{0:d} al:{1:d} - dettaglio per giorno", data.di, data.df)
		Else
			data.nomeFile = String.Format("RPRVOPIPEX_{0:yyyy}{0:MM}{0:dd}_{1:yyyy}{1:MM}{1:dd}.xls", data.di, data.df)
			data.tipoFile = "RVOPIPEX"
			data.descrizioneFile = String.Format("Report vendite operatori IPEX con P>C dal:{0:d} al:{1:d}", data.di, data.df)
		End If
		data.dettaglioPerGiorno = dettaglioPerGiorno

		If AppSettingToBoolean("ReportVEnditeOeratoriIPEX.BatchSerializer", False) Then
			BatchSerializer.BS.AddBatch(AddressOf ReportVenditeOperatoriIPEXAsync, data, "RPRVOPIPEX", "Report vendite operatori IPEX", DateTime.MinValue, runningOperator)
		Else
			ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf ReportVenditeOperatoriIPEXAsync), data)
		End If

		Return data.nomeFile

	End Function

	Private Shared Sub ReportVenditeOperatoriIPEXAsync(ByVal po As Object)

		Dim data As ReportVenditeOperatori_Data = DirectCast(po, ReportVenditeOperatori_Data)

		Dim dataCreazione As DateTime = DateTime.Now

		Dim cn As New SqlConnection
		Dim ci As New SetCultureItaliano
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			If data.dettaglioPerGiorno = False Then

				Dim cmd As New SqlCommand("dbo.spReportVenditeOpAcqIpex", cn)
				cmd.CommandType = CommandType.StoredProcedure
				cmd.Parameters.Add("@di", data.di)
				cmd.Parameters.Add("@df", data.df)
				cmd.CommandTimeout = AppSettingToInt32("ReportVenditeOperatoriIPEX.QueryTmo", 60)

				Dim da As New SqlDataAdapter(cmd)

				Dim ds As New DataSet
				ds.Tables.Add("R1")
				da.Fill(ds, "R1")

				Dim rpt As New ReportVenditeOperatoriIPEX
				rpt.DataSource = ds
				rpt.DataMember = "R1"
				rpt.txtPeriodo.Value = "Periodo dal " + data.di.ToShortDateString() + " al " + data.df.ToShortDateString()
				rpt.Run()

				Dim ms As New MemoryStream
				Dim xrpt As New DataDynamics.ActiveReports.Export.Xls.XlsExport
				'xrpt.UseCellMerging = True
				'xrpt.MultiSheet = False
				'xrpt.AutoRowHeight = True
				xrpt.Export(rpt.Document, ms)

				MemorizzaFilePerOperatore(Nothing, Nothing, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, ms.ToArray, dataCreazione, "", DateTime.MaxValue)
			Else

				Dim cmd As New SqlCommand("dbo.spReportVenditeOpAcqIpexPerGiorno", cn)
				cmd.CommandType = CommandType.StoredProcedure
				cmd.Parameters.Add("@di", data.di)
				cmd.Parameters.Add("@df", data.df)
				cmd.CommandTimeout = AppSettingToInt32("ReportVenditeOperatoriIPEX.QueryTmo", 60)

				Dim ms As New MemoryStream


				Dim sl As New SortedList
				Dim dateNonChiuse As New SortedList
				ReportVenditeOpIpexDettExcel.LeggDati(cmd, data.di, data.df, sl, dateNonChiuse)

				Dim wb As Workbook
				wb = ReportVenditeOpIpexDettExcel.CreateExcel(data.di, data.df, sl, dateNonChiuse)

				wb.Save(ms)
				MemorizzaFilePerOperatore(Nothing, Nothing, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, ms.ToArray, dataCreazione, "", DateTime.MaxValue)

				'Dim rpt As New ReportVenditeOperatoriIPEXPerGiorno
				'rpt.DataSource = ds
				'rpt.DataMember = "R1"
				'rpt.txtPeriodo.Value = "Periodo dal " + data.di.ToShortDateString() + " al " + data.df.ToShortDateString()
				'rpt.Run()
				'Dim ms As New MemoryStream
				'Dim xrpt As New DataDynamics.ActiveReports.Export.Xls.XlsExport
				''xrpt.UseCellMerging = True
				''xrpt.MultiSheet = False
				''xrpt.AutoRowHeight = True
				'xrpt.Export(rpt.Document, ms)
				'MemorizzaFilePerOperatore(Nothing, Nothing, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, ms.ToArray, dataCreazione, "", DateTime.MaxValue)
			End If




		Catch ex As Exception

			WriteErrorFile(ex, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, dataCreazione)

			SmLog.smError(ex, "ReportVEnditeOeratoriIPEXAsync")
			Throw

		Finally
			cn.Dispose()
			ci.Dispose()
		End Try

	End Sub

#End Region

#Region "ReportTotaleSbilanciDaProgrammiBilaterali"
	Class ReportTotaleSbilanciDaProgrammiBilaterali_Data
		Public di As DateTime
		Public df As DateTime
		Public opDestinatarioReport As String
		Public nomeFile As String
		Public tipoFile As String
		Public descrizioneFile As String
	End Class

	Public Function ReportTotaleSbilanciDaProgrammiBilaterali(ByVal opDestinatarioReport As String, ByVal di As DateTime, ByVal df As DateTime, ByVal runningOperator As String) As String

		Dim data As New ReportTotaleSbilanciDaProgrammiBilaterali_Data
		data.di = di
		data.df = df
		data.opDestinatarioReport = opDestinatarioReport
		data.nomeFile = String.Format("RPTTOTSBIL_{0:yyyy}{0:MM}{0:dd}_{1:yyyy}{1:MM}{1:dd}.xls", data.di, data.df)
		data.tipoFile = "RPTTOTSBIL"
		data.descrizioneFile = String.Format("Report totali sbilanci da programmi bilaterali dal:{0:d} al:{1:d}", data.di, data.df)

		If AppSettingToBoolean("ReportTotaleSbilanciDaProgrammiBilateraliAsync.BatchSerializer", False) Then
			BatchSerializer.BS.AddBatch(AddressOf ReportTotaleSbilanciDaProgrammiBilateraliAsync, data, "RPTTOTSBIL", "Report totali sbilanci da programmi bilaterali", DateTime.MinValue, runningOperator)
		Else
			ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf ReportTotaleSbilanciDaProgrammiBilateraliAsync), data)
		End If

		Return data.nomeFile

	End Function

	Private Shared Sub ReportTotaleSbilanciDaProgrammiBilateraliAsync(ByVal po As Object)

		Dim data As ReportTotaleSbilanciDaProgrammiBilaterali_Data = DirectCast(po, ReportTotaleSbilanciDaProgrammiBilaterali_Data)

		Dim dataCreazione As DateTime = DateTime.Now

		Dim cn As New SqlConnection
		Dim ci As New SetCultureItaliano
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand("dbo.spReportTotaliSbilanciDaProgrammiBilaterali", cn)
			cmd.CommandType = CommandType.StoredProcedure
			cmd.Parameters.Add("@di", data.di)
			cmd.Parameters.Add("@df", data.df)
			cmd.CommandTimeout = AppSettingToInt32("ReportTotaleSbilanciDaProgrammiBilaterali.QueryTmo", 60)

			Dim da As New SqlDataAdapter(cmd)

			Dim ds As New DataSet
			ds.Tables.Add("R1")
			da.Fill(ds, "R1")

			Dim rpt As New ReportTotaleSbilanciDaProgrammiBilaterali
			rpt.DataSource = ds
			rpt.DataMember = "R1"
			rpt.txtPeriodo.Value = "Periodo dal " + data.di.ToShortDateString() + " al " + data.df.ToShortDateString()

			rpt.Run()

			Dim ms As New MemoryStream
			Dim xrpt As New DataDynamics.ActiveReports.Export.Xls.XlsExport
			'xrpt.UseCellMerging = True
			'xrpt.AutoRowHeight = True
			'xrpt.MultiSheet = False
			xrpt.Export(rpt.Document, ms)

			MemorizzaFilePerOperatore(Nothing, Nothing, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, ms.ToArray, dataCreazione, "", DateTime.MaxValue)

		Catch ex As Exception

			WriteErrorFile(ex, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, dataCreazione)

			SmLog.smError(ex, "ReportTotaleSbilanciDaProgrammiBilateraliAsync")
			Throw

		Finally
			cn.Dispose()
			ci.Dispose()
		End Try

	End Sub

#End Region

#Region "ReportDettagliSbilanciDaProgrammiBilaterali"
	Class ReportDettagliSbilanciDaProgrammiBilaterali_Data
		Public di As DateTime
		Public df As DateTime
		Public partitaDettagliata As String
		Public opDestinatarioReport As String
		Public nomeFile As String
		Public tipoFile As String
		Public descrizioneFile As String
	End Class

	Public Function ReportDettaglioSbilanciDaProgrammiBilaterali(ByVal opDestinatarioReport As String, ByVal di As DateTime, ByVal df As DateTime, ByVal partitaDettagliata As String, ByVal runningOperator As String) As String

		Dim data As New ReportDettagliSbilanciDaProgrammiBilaterali_Data
		data.di = di
		data.df = df
		data.partitaDettagliata = partitaDettagliata
		data.opDestinatarioReport = opDestinatarioReport
		data.nomeFile = String.Format("RPTDETSBIL_{0}_{1:yyyy}{1:MM}{1:dd}_{2:yyyy}{2:MM}{2:dd}.xls", data.partitaDettagliata, data.di, data.df)
		data.tipoFile = "RPTDETSBIL"
		data.descrizioneFile = String.Format("Report dettagli sbilanci da programmi bilaterali dal:{0:d} al:{1:d}", data.di, data.df)

		If AppSettingToBoolean("ReportDettaglioSbilanciDaProgrammiBilaterali.BatchSerializer", False) Then
			BatchSerializer.BS.AddBatch(AddressOf ReportDettagliSbilanciDaProgrammiBilateraliAsync, data, "RPTDETSBIL", "Report dettagli sbilanci da programmi bilaterali", DateTime.MinValue, runningOperator)
		Else
			ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf ReportDettagliSbilanciDaProgrammiBilateraliAsync), data)
		End If

		Return data.nomeFile

	End Function

	Private Shared Sub ReportDettagliSbilanciDaProgrammiBilateraliAsync(ByVal po As Object)

		Dim data As ReportDettagliSbilanciDaProgrammiBilaterali_Data = DirectCast(po, ReportDettagliSbilanciDaProgrammiBilaterali_Data)

		Dim dataCreazione As DateTime = DateTime.Now

		Dim cn As New SqlConnection
		Dim ci As New SetCultureItaliano
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand("dbo.spReportDettaglioSbilanciDaProgrammiBilaterali", cn)
			cmd.CommandType = CommandType.StoredProcedure
			cmd.Parameters.Add("@PartitaDettagliata", data.partitaDettagliata)
			cmd.Parameters.Add("@di", data.di)
			cmd.Parameters.Add("@df", data.df)
			cmd.CommandTimeout = AppSettingToInt32("ReportDettaglioSbilanciDaProgrammiBilaterali.QueryTmo", 60)

			Dim da As New SqlDataAdapter(cmd)

			Dim ds As New DataSet
			ds.Tables.Add("R1")
			da.Fill(ds, "R1")

			'#If DEBUG Then
			'			ds.WriteXml("c:\prova.xml", XmlWriteMode.WriteSchema)
			'#End If

			'#If DEBUG Then
			'ds.Clear()
			'ds.ReadXml("C:\Bilaterali\DbMonitor\bin\Debug\ReportDettaglioPerTotVenditeOp.xml")
			'#End If

			Dim rpt As New ReportDettaglioDaProgrammiBilaterali
			rpt.DataSource = ds
			rpt.DataMember = "R1"
			rpt.txtPeriodo.Value = "Periodo dal " + data.di.ToShortDateString() + " al " + data.df.ToShortDateString()
			rpt.txtPartitaDettagliata.Value = "Dettaglio sbilanci da programmi bilaterali:  " + data.partitaDettagliata
			rpt.Run()

			Dim ms As New MemoryStream
			Dim xrpt As New DataDynamics.ActiveReports.Export.Xls.XlsExport
			'xrpt.UseCellMerging = True
			'xrpt.AutoRowHeight = True
			'xrpt.MultiSheet = False
			xrpt.Export(rpt.Document, ms)

			MemorizzaFilePerOperatore(Nothing, Nothing, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, ms.ToArray, dataCreazione, "", DateTime.MaxValue)


			'#If DEBUG Then
			'			Dim f As FileStream = File.Create("c:\prova.pdf")
			'			Dim pdf As New DataDynamics.ActiveReports.Export.Pdf.PdfExport
			'			pdf.Export(rpt.Document, f)
			'			f.Close()
			'#End If

		Catch ex As Exception

			WriteErrorFile(ex, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, dataCreazione)

			SmLog.smError(ex, "ReportDettaglioSbilanciDaProgrammiBilateraliAsync")
			Throw

		Finally
			cn.Dispose()
			ci.Dispose()
		End Try

	End Sub

#End Region


#Region "ReportEnergiaBilateraliSuddivisaPerZona"

	Class ReportEnergiaBilateraliSuddivisaPerZona_Data
		Public di As DateTime
		Public df As DateTime
		Public opDestinatarioReport As String
		Public nomeFile As String
		Public tipoFile As String
		Public descrizioneFile As String
		Public listaOperatori As System.Collections.Specialized.StringCollection
	End Class

	Public Function ReportEnergiaBilateraliSuddivisaPerZona_ListaOperatori() As DataSet

		Dim cn As New SqlConnection
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand
			cmd.Connection = cn
			cmd.CommandType = CommandType.Text
			cmd.CommandText = "select "
			cmd.CommandText += "S.CodiceOperatoreSDC CodiceOperatore "
			cmd.CommandText += "from sdc_operatori S "
			cmd.CommandText += "inner join operatori O "
			cmd.CommandText += "on S.codiceOperatoreSDC = O.codiceOperatoreSDC "
			cmd.CommandText += "where  O.statobilateraliOperatore = 1 "
			cmd.CommandText += "and S.CodiceOperatoreSDC <> 'root' "
			cmd.CommandText += "order by S.CodiceOperatoreSDC "



			cmd.CommandTimeout = AppSettingToInt32("ReportEnergiaBilateraliSuddivisaPerZona_ListaOperatori.QueryTmo", 45)

			Dim da As New SqlDataAdapter(cmd)

			Dim ds As New DataSet
			ds.Tables.Add("Operatori")
			ds.Tables.Add("OperatoriSelezionati")
			da.Fill(ds, "Operatori")

			Return ds

		Catch ex As Exception
			SmLog.smError(ex, "ReportEnergiaBilateraliSuddivisaPerZonaAsync")
			Throw

		Finally
			cn.Dispose()
		End Try
	End Function


	Public Function ReportEnergiaBilateraliSuddivisaPerZona(ByVal opDestinatarioReport As String, ByVal di As DateTime, ByVal df As DateTime, ByVal listaOperatori As StringCollection, ByVal runningOperator As String) As String

		Dim data As New ReportEnergiaBilateraliSuddivisaPerZona_Data
		data.di = di
		data.df = df
		'data.partitaDettagliata = partitaDettagliata
		data.opDestinatarioReport = opDestinatarioReport
		data.listaOperatori = listaOperatori
		If data.di = data.df Then
			data.nomeFile = String.Format("RPTENZONE_{0:yyyy}{0:MM}{0:dd}.xls", data.di)
			data.descrizioneFile = String.Format("Report energia bilaterali suddivisa per zone; data flusso: {0:d}", data.di)
		Else
			data.nomeFile = String.Format("RPTENZONE_{0:yyyy}{0:MM}{0:dd}_{1:yyyy}{1:MM}{1:dd}.xls", data.di, data.df)
			data.descrizioneFile = String.Format("Report energia bilaterali suddivisa per zone; periodo dal:{0:d} al:{1:d}", data.di, data.df)
		End If
		data.tipoFile = "RPTENZONE"

		If AppSettingToBoolean("ReportEnergiaBilateraliSuddivisaPerZona.BatchSerializer", False) Then
			BatchSerializer.BS.AddBatch(AddressOf ReportEnergiaBilateraliSuddivisaPerZonaAsync, data, "RPTENZONE", "Report Energia Bilaterali Suddivisa Per Zona", DateTime.MinValue, runningOperator)
		Else
			ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf ReportEnergiaBilateraliSuddivisaPerZonaAsync), data)
		End If

		Return data.nomeFile

	End Function

	Private Shared Sub ReportEnergiaBilateraliSuddivisaPerZonaAsync(ByVal po As Object)

		Dim data As ReportEnergiaBilateraliSuddivisaPerZona_Data = DirectCast(po, ReportEnergiaBilateraliSuddivisaPerZona_Data)

		Dim dataCreazione As DateTime = DateTime.Now

		Dim cn As New SqlConnection
		Dim ci As New SetCultureItaliano
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand
			cmd.CommandType = CommandType.StoredProcedure
			cmd.Connection = cn

			cmd.Parameters.Add("@di", data.di)
			cmd.Parameters.Add("@df", data.df)

			If data.listaOperatori.Count = 0 Then
				cmd.CommandText = "dbo.spReportEnergiaPerZone"
			Else
				cmd.CommandText = "dbo.spReportEnergiaPerZonePerOperatori"

				Dim opList As String = ""
				For Each s As String In data.listaOperatori
					If opList.Length > 0 Then opList += ","
					opList += s
				Next
				cmd.Parameters.Add("@op", opList)
			End If

			cmd.CommandTimeout = AppSettingToInt32("ReportEnergiaBilateraliSuddivisaPerZona.QueryTmo", 60 * 5)

			Dim da As New SqlDataAdapter(cmd)

			Dim ds As New DataSet
			ds.Tables.Add("R1")
			da.Fill(ds, "R1")

			Dim rpt As New ReportEnergiaBilateraliSuddivisaPerZone
			rpt.DataSource = ds
			rpt.DataMember = "R1"
			If data.di = data.df Then
				rpt.txtPeriodo.Value = "Data flusso :" + data.di.ToShortDateString()
			Else
				rpt.txtPeriodo.Value = "Data flusso dal " + data.di.ToShortDateString() + " al " + data.df.ToShortDateString()
			End If

			rpt.Run()

			Dim ms As New MemoryStream
			Dim xrpt As New DataDynamics.ActiveReports.Export.Xls.XlsExport
			'xrpt.UseCellMerging = True
			'xrpt.AutoRowHeight = True
			'xrpt.MultiSheet = False
			xrpt.Export(rpt.Document, ms)



			MemorizzaFilePerOperatore(Nothing, Nothing, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, ms.ToArray, dataCreazione, "", DateTime.MaxValue)

		Catch ex As Exception

			WriteErrorFile(ex, data.opDestinatarioReport, data.nomeFile, data.tipoFile, data.descrizioneFile, dataCreazione)

			SmLog.smError(ex, "ReportEnergiaBilateraliSuddivisaPerZonaAsync")
			Throw

		Finally
			cn.Dispose()
			ci.Dispose()
		End Try

	End Sub

#End Region


	Public Function GetListaSessioniNonChiuse(ByVal di As DateTime, ByVal df As DateTime) As DateTime()
		Dim cn As New SqlConnection
		Dim r As New ArrayList
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand("spGetListaSessioniNonChiuse")
			cmd.CommandType = CommandType.StoredProcedure
			cmd.Parameters.Add("@di", di)
			cmd.Parameters.Add("@df", df)
			cmd.Connection = cn

			Dim rd As SqlDataReader
			Try
				rd = cmd.ExecuteReader()
				While rd.Read()
					r.Add(rd(0))
				End While
			Finally
				rd.Close()
			End Try

			cn.Close()

		Catch ex As Exception
			SmLog.smError(ex)
		Finally
			If cn.State = ConnectionState.Open Then
				cn.Close()
			End If

		End Try

		Dim ar As Array = r.ToArray(GetType(DateTime))
		Return DirectCast(ar, DateTime())

	End Function

	Private Shared Sub WriteErrorFile(ByVal ex As Exception, ByVal opDestinatarioReport As String, ByVal nomeFile As String, ByVal tipoFile As String, ByVal descrizioneFile As String, ByVal dataCreazione As DateTime)

		Dim ms As New MemoryStream
		Dim tw As New System.IO.StreamWriter(ms, System.Text.Encoding.UTF8)
		tw.WriteLine("L'elaborazione del report e` fallita:")
		tw.WriteLine("Il messaggio riportato dal sistema e`:")
		tw.WriteLine(ex.Message)
		tw.Flush()

		nomeFile = Path.ChangeExtension(".xls", ".err")

		MemorizzaFilePerOperatore(Nothing, Nothing, opDestinatarioReport, nomeFile, tipoFile, descrizioneFile, ms.ToArray, dataCreazione, "", DateTime.MaxValue)
	End Sub

	Class SetCultureItaliano
		Implements IDisposable
		Public Sub New()
			oldCultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture
			System.Threading.Thread.CurrentThread.CurrentCulture = New CultureInfo("it-it")
			System.Threading.Thread.CurrentThread.CurrentUICulture = New CultureInfo("it-it")
		End Sub

		Private oldCultureInfo As CultureInfo


		Public Sub Dispose() Implements System.IDisposable.Dispose
			System.Threading.Thread.CurrentThread.CurrentCulture = oldCultureInfo
		End Sub
	End Class

	Public Function CreaReport_SbilanciamentoProgrammiPDF(ByVal operatore As String, ByVal dataFlusso As String) As Byte()

		Dim rpt As New ReportDettaglioContrattiRpx
		rpt.lbData.Text = dataFlusso
		Dim sSql As String
		Dim ds As New DataDynamics.ActiveReports.DataSources.SqlDBDataSource

		Dim bl As New Bil.Programmi
		Dim dataF As DateTime = DateTime.Parse(dataFlusso)
		Dim nOre As Integer = bl.GetNumberOfHourOfDay(dataF)

		rpt.DataSource = ds
		ds.ConnectionString = ConfigurationSettings.AppSettings("SqlConnectionString")
		ds.SQL = "  Select CO.CRN, CO.CodiceContratto, "
		ds.SQL += " case sum(cast(PO.Bilanciato AS Integer)) when " + nOre.ToString().Trim() + " then 'Bilanciato' else 'Non Bilanciato' end Bilanciato "
		ds.SQL += " FROM ProgrammaOrario PO "
		ds.SQL += " INNER JOIN Contratto CO ON CO.IdContratto = PO.IdContratto "
		ds.SQL += " Where PO.DataProgramma = '" + dataFlusso + "'"

		If operatore.Length > 0 Then
			ds.SQL += " and (co.codiceOperatoreSDCAcquirente = '" + operatore + "'"
			ds.SQL += "      or co.codiceOperatoreSDCCedente = '" + operatore + "' )"
		End If

		ds.SQL += " GROUP BY CO.CRN, CO.CodiceContratto ORDER BY CO.CRN "

		Try
			rpt.Run(False)
		Catch eRunReport As Exception
			Throw eRunReport
			Exit Function
		End Try

		' Create the PDF export object
		Dim pdf As PdfExport = New PdfExport

		' Create a new memory stream that will hold the pdf output
		Dim memStream As System.IO.MemoryStream = New System.IO.MemoryStream

		' Export the report to PDF:
		pdf.Export(rpt.Document, memStream)

		' Return the PDF stream out
		Return memStream.ToArray()

	End Function

	Public Function CreaReport_SbilanciamentoProgrammiXLS(ByVal operatore As String, ByVal dataFlusso As String) As Byte()

		Dim cn As New SqlConnection
		cn.ConnectionString = ConfigurationSettings.AppSettings("SqlConnectionString")

		Dim dataF As DateTime = DateTime.Parse(dataFlusso)
		Dim bl As New Bil.Programmi
		Dim nOre As Integer = bl.GetNumberOfHourOfDay(dataF)


		Dim cmd As SqlCommand = cn.CreateCommand()
		cmd.CommandText = ""
		cmd.CommandText += "Select CO.IdContratto IdContratto, CO.CRN CRN, CO.CodiceContratto CodiceContratto, "
		cmd.CommandText += " case when sum(cast(PO.Bilanciato AS Integer)) = @nh then 1 else 0 end Bilanciato "
		cmd.CommandText += " FROM ProgrammaOrario PO "
		cmd.CommandText += " INNER JOIN Contratto CO ON CO.IdContratto = PO.IdContratto "
		cmd.CommandText += " Where PO.DataProgramma = @d"
		cmd.Parameters.Add("@d", dataF)
		cmd.Parameters.Add("@nh", nOre)

		If operatore.Length > 0 Then
			cmd.CommandText += " and (co.codiceOperatoreSDCAcquirente = @op or "
			cmd.CommandText += "      co.codiceOperatoreSDCCedente    = @op) "
			cmd.Parameters.Add("@op", operatore)
		End If

		cmd.CommandText += " GROUP BY CO.CRN, CO.CodiceContratto, CO.IdContratto ORDER BY CO.CRN "

		Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)

		Dim ds As New DataSet
		da.Fill(ds)


		Dim sb As Workbook = New Workbook
		Dim sh As DDSheet = sb.Sheets.AddNew
		Dim ci As CultureInfo = New CultureInfo("it-it")
		sh.Name = String.Format("Sbil. programmi {0}", dataF.ToString("dd-MM-yyyy", ci))

		Dim row As Short = 0
		Dim col As Short = 0

		Dim colCRN As Short = 0
		Dim colCodiceContratto As Short = 1
		Dim colStatoBilanciamento As Short = 2
		Dim colOra As Short = 3
		Dim colBilanciato As Short = 4


		' dimensione colonne
		If True Then
			sh.Columns(colCRN).Width = 1440 * 3
			sh.Columns(colCodiceContratto).Width = 1440 * 3
			sh.Columns(colStatoBilanciamento).Width = 1440 * 1
			sh.Columns(colOra).Width = 1440 * 1
			sh.Columns(colBilanciato).Width = 1440 * 1
		End If

		With sh.Cell(0, 0)
			.Merge(0, 5)
			.SetValue("Report sbilanciamento programmi")
			.FontSize = 14
			.FontBold = True
			.Alignment = HorzAlignments.Center
		End With

		With sh.Cell(1, 0)
			.SetValue("Data:")
			.FontBold = True
			.Alignment = HorzAlignments.Right
			.Alignment = HorzAlignments.Left
		End With
		With sh.Cell(1, 1)
			.SetValue(dataF.ToString("d", ci))
		End With


		If operatore.Length > 0 Then
			sh.Cell(1, 2).SetValue("Operatore:")
			sh.Cell(1, 2).Alignment = HorzAlignments.Right
			sh.Cell(1, 2).FontBold = True
			sh.Cell(1, 3).SetValue(operatore)
		End If



		sh.Cell(2, 0).SetValueBlank()

		sh.Cell(3, colCRN).SetValue("CRN")
		sh.Cell(3, colCRN).FontBold = True

		sh.Cell(3, colCodiceContratto).SetValue("Codice Contratto")
		sh.Cell(3, colCodiceContratto).FontBold = True

		sh.Cell(3, colStatoBilanciamento).SetValue("Stato bilanciamento")
		sh.Cell(3, colStatoBilanciamento).FontBold = True

		sh.Cell(4, colOra).SetValue("Ora")
		sh.Cell(4, colOra).FontBold = True
		sh.Cell(4, colBilanciato).SetValue("Bilanciato")
		sh.Cell(4, colBilanciato).FontBold = True

		row = 5
		For Each dr As DataRow In ds.Tables(0).Rows
			Dim crn As String = DirectCast(dr("CRN"), String)
			Dim codiceContratto As String = DirectCast(dr("CodiceContratto"), String)
			Dim bilanciato As Integer = DirectCast(dr("Bilanciato"), Integer)
			Dim IdContratto As Integer = DirectCast(dr("IdContratto"), Integer)

			sh.Cell(row, colCRN).SetValue(crn)
			sh.Cell(row, colCodiceContratto).SetValue(codiceContratto)

			If bilanciato > 0 Then
				sh.Cell(row, colStatoBilanciamento).SetValue("Bilanciato")
			Else
				sh.Cell(row, colStatoBilanciamento).SetValue("Non bilanciato")
			End If
			row += 1S

			If bilanciato = 0 Then

				Dim s As String = ""
				s += "Select "
				s += " PeriodoRilevante, "
				s += " case Bilanciato when 1 then 'Bilanciato' when 0 then 'Non bilanciato' else '' end Bilanciato "
				s += " FROM ProgrammaOrario PO "
				s += " INNER JOIN Contratto CO "
				s += " ON CO.IdContratto = PO.IdContratto "
				s += " WHERE PO.DataProgramma = @d "
				s += " AND CO.IdContratto = @IdContratto "
				s += " ORDER BY PeriodoRilevante "

				Dim cmdDett As SqlCommand = cn.CreateCommand()
				cmdDett.CommandText = s
				cmdDett.Parameters.Add("@d", dataF)
				cmdDett.Parameters.Add("@IdContratto", IdContratto)

				Dim dataReader As SqlDataReader
				Try
					cn.Open()
					dataReader = cmdDett.ExecuteReader()
					While dataReader.Read()

						Dim dettOra As Integer = Convert.ToInt32(dataReader(0))
						Dim dettBilanciato As String = Convert.ToString(dataReader(1))

						sh.Cell(row, colOra).SetValue(dettOra)
						sh.Cell(row, colBilanciato).SetValue(dettBilanciato)
						sh.Cell(row, colBilanciato).Alignment = HorzAlignments.Right

						row += 1S
					End While
				Finally
					If cn.State = ConnectionState.Open Then
						cn.Close()
					End If
					If Not dataReader Is Nothing Then
						dataReader.Close()
					End If

				End Try
			End If
		Next

		Dim ms As New MemoryStream
		sb.Save(ms)
		Return ms.ToArray()

	End Function



	Class ReportVenditeOpIpexDettExcel
		Private Shared Function Str(ByVal d As DateTime, ByVal ci As CultureInfo) As String
			Return d.ToString("dd-MM-yyyy", ci)
		End Function

		Public Shared Sub LeggDati(ByVal cmd As SqlCommand, ByVal di As DateTime, ByVal df As DateTime, ByVal sl As SortedList, ByVal htDateNonChiuse As SortedList)

			Dim numeroGiorni As Integer = 0

			Dim slDate As New SortedList
			Dim d As DateTime = di
			While d <= df
				slDate(d) = numeroGiorni
				numeroGiorni += 1
				d = d.AddDays(1)
			End While

			Dim rd As SqlDataReader = Nothing
			Try

				rd = cmd.ExecuteReader()

				While rd.Read
					Dim nc As DateTime = DirectCast(rd("DataProgramma"), DateTime)
					htDateNonChiuse(nc) = 1
				End While

				rd.NextResult()

				While rd.Read
					Dim CodiceOperatore As String = DirectCast(rd("CodiceOperatore"), String)
					Dim RagioneSociale As String = DirectCast(rd("RagioneSociale"), String)
					Dim dt As DateTime = DirectCast(rd("Data"), DateTime)
					Dim QuantitaVendute As Double = DirectCast(rd("QuantitaVendute"), Double)

					Dim dtOp As DatiOperatore

					If Not sl.ContainsKey(RagioneSociale) Then
						dtOp = New DatiOperatore
						dtOp.Codice = CodiceOperatore
						dtOp.NomeOperatore = RagioneSociale
						dtOp.Qty = New Double(numeroGiorni) {}
						sl(RagioneSociale) = dtOp

					Else
						dtOp = DirectCast(sl(RagioneSociale), DatiOperatore)
					End If

					Dim idx As Integer = DirectCast(slDate(dt), Integer)
					dtOp.Qty(idx) = QuantitaVendute

				End While

			Finally
				If Not rd Is Nothing Then
					rd.Close()

				End If
			End Try



		End Sub


		Private Class DatiOperatore
			Implements IComparable
			Private Shared ci As CultureInfo = New CultureInfo("it-it")
			Public NomeOperatore As String
			Public Codice As String
			Public MercatoChiuso As Boolean
			Public Qty As Double()

			Public Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
				If obj Is Nothing Then
					Return 1
				End If
				Return String.Compare(NomeOperatore, CType(obj, DatiOperatore).NomeOperatore, True, ci)
			End Function
		End Class

		Private Shared Function CreaMatrice(ByVal di As DateTime, ByVal df As DateTime, ByVal dt As DataTable) As SortedList
			Dim htDate As Hashtable = New Hashtable

			Dim numeroGiorni As Integer = 0
			Dim d As DateTime = di
			While d <= df
				htDate(d) = numeroGiorni
				numeroGiorni += 1
				d = d.AddDays(1)
			End While

			Dim htOperatori As SortedList = New SortedList

			For Each dr As DataRow In dt.Rows
				Dim NomeOperatore As String = DirectCast(dr("RagioneSociale"), String)
				Dim Codice As String = DirectCast(dr("CodiceOperatore"), String)
				Dim data As DateTime = DirectCast(dr("Data"), DateTime)
				Dim qty As Double = DirectCast(dr("QuantitaVendute"), Double)

				Dim dtOp As DatiOperatore
				If Not htOperatori.ContainsKey(NomeOperatore) Then
					dtOp = New DatiOperatore
					dtOp.Codice = Codice
					dtOp.NomeOperatore = NomeOperatore
					dtOp.Qty = New Double(numeroGiorni) {}
					htOperatori(NomeOperatore) = dtOp
				Else
					dtOp = DirectCast(htOperatori(NomeOperatore), DatiOperatore)
				End If

				Dim colIndex As Integer = DirectCast(htDate(data), Integer)
				dtOp.Qty(colIndex) = qty
			Next
			Return htOperatori
		End Function

		Public Shared Function CreateExcel(ByVal di As DateTime, ByVal df As DateTime, ByVal sl As SortedList, ByVal dateNonChiuse As SortedList) As Workbook


			Dim sb As Workbook = New Workbook
			Dim sh As DDSheet = sb.Sheets.AddNew
			Dim ci As CultureInfo = New CultureInfo("it-it")
			sh.Name = String.Format("Ve.op.IPEX P>C {0} {1}", Str(di, ci), Str(df, ci))

			Dim row As Short = 0
			Dim col As Short = 0

			If True Then
				col = 0
				sh.Columns(col).Width = 3 * 1440
				col += 1S

				sh.Columns(col).Width = 1440
				col += 1S

				Dim d As DateTime = di
				While d <= df
					sh.Columns(col).Width = 2200
					col += 1S

					d = d.AddDays(1)
				End While

				sh.Columns(col).Width = 2200
				col += 1S
			End If

			If True Then
				row = 0
				col = 0
				sh.Rows(row).Height = 360
				sh.Cell(row, col).SetValue("Report vendite operatori acquirenti IPEX")
				sh.Cell(row, col).FontSize = 14
				sh.Cell(row, col).FontBold = True
			End If
			row += 1S

			If True Then
				col = 0
				sh.Rows(row).Height = 360
				Dim h2 As String = String.Format("Periodo dal {0} al {1}", Str(di, ci), Str(df, ci))
				sh.Cell(row, col).SetValue(h2)
				sh.Cell(row, col).FontBold = True
				col += 1S
				col += 1S
				Dim d As DateTime = di
				While d <= df
					sh.Cell(row, col).FontBold = True
					sh.Cell(row, col).Alignment = HorzAlignments.Center
					sh.Cell(row, col).SetValue(d.ToString("d-MMM", ci))

					If dateNonChiuse.ContainsKey(d) Then
						sh.Cell(row, col).ForeColor = System.Drawing.Color.Red
					End If

					col += 1S
					d = d.AddDays(1)
				End While
			End If
			row += 1S

			If True Then
				col = 0
				sh.Cell(row, col).Alignment = HorzAlignments.Center
				sh.Cell(row, col).SetValue("Nome operatore")
				sh.Cell(row, col).FontBold = True
				col += 1S

				sh.Cell(row, col).Alignment = HorzAlignments.Center
				sh.Cell(row, col).SetValue("Codice")
				sh.Cell(row, col).FontBold = True
				col += 1S

				Dim d As DateTime = di
				While d <= df
					sh.Cell(row, col).FontBold = True
					sh.Cell(row, col).Alignment = HorzAlignments.Center
					sh.Cell(row, col).SetValue("Quantit� vendute MWh")

					If dateNonChiuse.ContainsKey(d) Then
						sh.Cell(row, col).ForeColor = System.Drawing.Color.Red
					End If

					col += 1S

					d = d.AddDays(1)
				End While
				sh.Cell(row, col).FontBold = True
				sh.Cell(row, col).Alignment = HorzAlignments.Center
				sh.Cell(row, col).SetValue("Totale operatore")
				col += 1S

			End If
			row += 1S

			For i As Integer = 0 To sl.Count - 1
				If True Then
					Dim dtOp As DatiOperatore = CType(sl.GetByIndex(i), DatiOperatore)
					col = 0

					sh.Cell(row, col).SetValue(dtOp.NomeOperatore)
					col += 1S

					sh.Cell(row, col).SetValue(dtOp.Codice)
					col += 1S

					Dim qtyIndex As Integer = 0
					Dim totale As Double = 0
					Dim d As DateTime = di
					While d <= df

						If dateNonChiuse.ContainsKey(d) Then
							sh.Cell(row, col).ForeColor = System.Drawing.Color.Red
							sh.Cell(row, col).Alignment = HorzAlignments.Center
							sh.Cell(row, col).SetValue("Mercato NON chiuso")
						Else
							sh.Cell(row, col).NumberFormat = "#,##0.00"
							sh.Cell(row, col).Alignment = HorzAlignments.Right
							sh.Cell(row, col).SetValue(dtOp.Qty(qtyIndex))
							totale += dtOp.Qty(qtyIndex)
						End If

						col += 1S
						qtyIndex += 1
						d = d.AddDays(1)
					End While

					sh.Cell(row, col).NumberFormat = "#,##0.00"
					sh.Cell(row, col).Alignment = HorzAlignments.Right
					sh.Cell(row, col).FontBold = True
					sh.Cell(row, col).SetValue(totale)
					col += 1S

				End If
				row += 1S
			Next

			If True Then
				col = 0
				sh.Cell(row, col).Alignment = HorzAlignments.Left
				sh.Cell(row, col).FontBold = True
				sh.Cell(row, col).SetValue("Totale giornaliero")
				col += 1S

				col += 1S

				Dim dIndex As Integer = 0
				Dim d As DateTime = di
				While d <= df
					sh.Cell(row, col).FontBold = True

					If Not dateNonChiuse.ContainsKey(d) Then

						Dim t As Double = 0
						For i As Integer = 0 To sl.Count - 1
							Dim dtOp As DatiOperatore = CType(sl.GetByIndex(i), DatiOperatore)
							t += dtOp.Qty(dIndex)
						Next

						sh.Cell(row, col).NumberFormat = "#,##0.00"
						sh.Cell(row, col).Alignment = HorzAlignments.Right
						sh.Cell(row, col).SetValue(t)

					Else
						sh.Cell(row, col).ForeColor = System.Drawing.Color.Red
						sh.Cell(row, col).Alignment = HorzAlignments.Center
						sh.Cell(row, col).SetValue("Mercato NON chiuso")
					End If

					col += 1S
					dIndex += 1
					d = d.AddDays(1)
				End While
			End If
			row += 1S
			Return sb
		End Function

	End Class

End Class
