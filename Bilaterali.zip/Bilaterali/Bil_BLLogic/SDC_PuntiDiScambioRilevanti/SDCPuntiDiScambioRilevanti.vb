Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Collections

Public Class SDCPuntiDiScambioRilevanti
    Inherits BilBLBase

    Public Function GetSDC_PuntiDiScambioRilevanti() As DS_SDC_PuntiDiScambioRilevanti
        cn.ConnectionString = GetConnectionString()
        Try
            cn.Open()

            Dim ds As New DS_SDC_PuntiDiScambioRilevanti
            daSDC_PuntiDiScambioRilevanti.Fill(ds.SDC_PuntiDiScambioRilevanti)

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Function

    Public Sub SalvaDataSet(ByVal ds As DS_SDC_PuntiDiScambioRilevanti)
        cn.ConnectionString = GetConnectionString()
        Dim tr As SqlTransaction = Nothing
        Try
            cn.Open()
            tr = cn.BeginTransaction()
            SetTransaction(daSDC_PuntiDiScambioRilevanti, tr)

            daSDC_PuntiDiScambioRilevanti.Update(ds.SDC_PuntiDiScambioRilevanti)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw
        Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdInsert As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdate As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdDelete As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents daSDC_PuntiDiScambioRilevanti As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.cmdInsert = New System.Data.SqlClient.SqlCommand
        Me.cmdUpdate = New System.Data.SqlClient.SqlCommand
        Me.cmdDelete = New System.Data.SqlClient.SqlCommand
        Me.cmdSelect = New System.Data.SqlClient.SqlCommand
        Me.daSDC_PuntiDiScambioRilevanti = New System.Data.SqlClient.SqlDataAdapter
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persis" & _
        "t security info=False;initial catalog=Bilaterali"
        '
        'cmdInsert
        '
        Me.cmdInsert.CommandText = "INSERT INTO dbo.SDC_PuntiDiScambioRilevanti (CodicePuntoDiScambioRilevanteSDC, De" & _
        "scrizionePuntoDiScambioRilevante, CoefficienteDiPerdita, CodiceZonaSDC, TSModifi" & _
        "ca, ResponsabileAggiornamento) VALUES (@CodicePuntoDiScambioRilevanteSDC, @Descr" & _
        "izionePuntoDiScambioRilevante, @CoefficienteDiPerdita, @CodiceZonaSDC, @TSModifi" & _
        "ca, @ResponsabileAggiornamento)"
        Me.cmdInsert.Connection = Me.cn
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, "CodicePuntoDiScambioRilevanteSDC"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizionePuntoDiScambioRilevante", System.Data.SqlDbType.VarChar, 256, "DescrizionePuntoDiScambioRilevante"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CoefficienteDiPerdita", System.Data.SqlDbType.Float, 8, "CoefficienteDiPerdita"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, "CodiceZonaSDC"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
        '
        'cmdUpdate
        '
        Me.cmdUpdate.CommandText = "UPDATE dbo.SDC_PuntiDiScambioRilevanti SET DescrizionePuntoDiScambioRilevante = @" & _
        "DescrizionePuntoDiScambioRilevante, CoefficienteDiPerdita = @CoefficienteDiPerdi" & _
        "ta, CodiceZonaSDC = @CodiceZonaSDC, TSModifica = GETDATE(), ResponsabileAggiorna" & _
        "mento = @ResponsabileAggiornamento WHERE (CodicePuntoDiScambioRilevanteSDC = @Co" & _
        "dicePuntoDiScambioRilevanteSDC)"
        Me.cmdUpdate.Connection = Me.cn
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizionePuntoDiScambioRilevante", System.Data.SqlDbType.VarChar, 256, "DescrizionePuntoDiScambioRilevante"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CoefficienteDiPerdita", System.Data.SqlDbType.Float, 8, "CoefficienteDiPerdita"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceZonaSDC", System.Data.SqlDbType.VarChar, 10, "CodiceZonaSDC"))
        Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
		Me.cmdUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodicePuntoDiScambioRilevanteSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmdDelete
        '
        Me.cmdDelete.CommandText = "DELETE FROM dbo.SDC_PuntiDiScambioRilevanti WHERE (CodicePuntoDiScambioRilevanteS" & _
        "DC = @CodicePuntoDiScambioRilevanteSDC)"
        Me.cmdDelete.Connection = Me.cn
		Me.cmdDelete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodicePuntoDiScambioRilevanteSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmdSelect
        '
        Me.cmdSelect.CommandText = "SELECT dbo.SDC_PuntiDiScambioRilevanti.* FROM dbo.SDC_PuntiDiScambioRilevanti"
        Me.cmdSelect.Connection = Me.cn
        '
        'daSDC_PuntiDiScambioRilevanti
        '
        Me.daSDC_PuntiDiScambioRilevanti.DeleteCommand = Me.cmdDelete
        Me.daSDC_PuntiDiScambioRilevanti.InsertCommand = Me.cmdInsert
        Me.daSDC_PuntiDiScambioRilevanti.SelectCommand = Me.cmdSelect
        Me.daSDC_PuntiDiScambioRilevanti.UpdateCommand = Me.cmdUpdate

    End Sub

#End Region

End Class
