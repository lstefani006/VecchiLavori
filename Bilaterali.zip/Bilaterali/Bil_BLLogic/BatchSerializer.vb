Imports System.Threading
Imports System
Imports System.Text

Public Class BatchInfo

	Public Sub New(ByVal ws As WaitCallback, ByVal state As Object, ByVal code As String, ByVal description As String, ByVal tsFlowDate As DateTime, ByVal starterOperator As String)
		Me._ws = ws
		Me._st = state
		Me._descr = description
		Me._code = code
		Me._starterOperator = starterOperator

		If tsFlowDate = DateTime.MaxValue OrElse tsFlowDate = DateTime.MinValue Then
			Me._flowdt = DateTime.MinValue
		Else
			Me._flowdt = tsFlowDate
		End If

		Me._Status = Status.N
	End Sub

	Public Function Msg(ByVal m As String) As String
		Dim sb As New StringBuilder

		If Not Me.BatchId Is Nothing Then
			sb.AppendFormat("BatchId={0} ", Me.BatchId)
		Else
			sb.AppendFormat("BatchId=<null> ")
		End If

		If Me._flowdt <> DateTime.MinValue AndAlso Me._flowdt <> DateTime.MaxValue Then
			sb.AppendFormat("FlowDate={0:ddMMyyyy} ", Me._flowdt)
		End If

		sb.AppendFormat("Code {0} ", Me._code)
		sb.AppendFormat("Status {0} ", Me._Status)

		If Not m Is Nothing Then
			sb.Append(m)
		End If

		Return sb.ToString()
	End Function

	Public Enum Status
		N		 ' non ancora nel db
		Q		 ' queued
		R		 ' running
		E		 ' finito con successo
		A		 ' finito con eccezione/abort
	End Enum


	Private _flowdt As DateTime
	Private _code As String
	Private _ws As WaitCallback
	Private _st As Object
	Private _descr As String
	Private _ev As AutoResetEvent
	Private _evException As AutoResetEvent
	Public _Status As Status
	Public _starterOperator As String

	Public BatchId As String	' identificatore del batch a livello di DB

	Public ReadOnly Property BatchCode() As String
		Get
			Return Me._code
		End Get
	End Property

	Public ReadOnly Property Description() As String
		Get
			Return Me._descr
		End Get
	End Property

	Public ReadOnly Property FlowDate() As DateTime
		Get
			Return Me._flowdt
		End Get
	End Property

	' non chiamare
	Public Sub z__SetEndWorkEvent(ByVal ev As AutoResetEvent, ByVal evException As AutoResetEvent)
		_ev = ev
		_evException = evException
	End Sub
	' non chiamare
	Public Sub z__Run()
		Try
			BatchInfo.BatchInfo = Me
			_ws(_st)			 ' lancio il batch
			_ev.Set()			   ' setto l'evento di fine batch
		Catch ex As Exception
			BatchSerializer.SetProgressBatch(ex)
			_evException.Set()			 ' setto l'evento di fine batch con eccezione
		End Try
	End Sub
	' non chiamare
	Public Sub z__Abort()
		If Not _ev Is Nothing Then
			_ev.Set()
		End If
	End Sub

	<ThreadStatic()> Public Shared BatchInfo As BatchInfo
End Class

' classe per accodare dei batch da eseguire sequenzialmente
' Per accodare un batch usare AddBatch

Public Class BatchSerializer

    Public Shared BS As New BatchSerializer

    Public Shared Sub InitBatchSerializer()
        BS = New BatchSerializer
    End Sub
    Public Shared Sub DestroyBatchSerializer()
        If Not BS Is Nothing Then BS.Close()
        BS = Nothing
    End Sub


    Private queueBI As New System.Collections.Queue
    Private th As Thread
    Private MaxCount As Integer = 100    ' numero di item massimo nella coda.


    Private _ev(2) As AutoResetEvent    ' 3 eventi (0) indica la fine del thread di lavoro (1) indica Abort (2) indica una eccezione

    Sub New()
        _ev(0) = Nothing
        _ev(1) = Nothing
        _ev(2) = Nothing
        th = New Thread(AddressOf Me.WaitAndDoNextWork)
        th.IsBackground = True
        th.Start()
    End Sub

    Public Sub Close()
        If Not th Is Nothing Then
            th.Abort()
            th.Join()
            th = Nothing
        End If
    End Sub

    Public Function PendingBatches() As Integer
        SyncLock Me
            Return Me.queueBI.Count
        End SyncLock
    End Function

    Public Sub Clear()
        SyncLock Me
            Me.queueBI.Clear()
        End SyncLock
    End Sub

	Public Function AddBatch(ByVal ws As WaitCallback, ByVal st As Object, ByVal code As String, ByVal descr As String, ByVal dtFlowDate As DateTime, ByVal starterOperator As String) As BatchInfo
		Dim r As BatchInfo = New BatchInfo(ws, st, code, descr, dtFlowDate, starterOperator)
		AddBatch(r)
		Return r
	End Function


	Private Sub AddBatch(ByVal bi As BatchInfo)

		Dim nq As Integer
		SyncLock Me
			' se ci sono troppi elementi in coda aspetto
			While Me.queueBI.Count >= MaxCount
				Monitor.Wait(Me)
			End While

			Try
				QueueBatch(bi, nq)
			Catch
			End Try


			' accodo il batch
			Me.queueBI.Enqueue(bi)
			nq = Me.queueBI.Count

			' se il batch accodato e` il primo sveglio il thread che consuma gli eventi
			If Me.queueBI.Count = 1 Then
				Monitor.PulseAll(Me)
			End If
		End SyncLock

	End Sub

	Public Sub WaitAndDoNextWork()
		Do
			Dim bi As BatchInfo
			Dim nq As Integer

			SyncLock Me
				' se la coda e` vuota aspetta un evento
				While Me.queueBI.Count = 0
					' rilascio il lock e aspetto un Pulse
					Monitor.Wait(Me)
					' ripreso il lock su Me... ricontrollo se c'e` qualcosa in coda
				End While

				' consumo l'evento in coda
				nq = Me.queueBI.Count
				bi = DirectCast(Me.queueBI.Dequeue(), BatchInfo)

				' se la coda era piena sveglio i produttori
				If Me.queueBI.Count = MaxCount - 1 Then
					Monitor.PulseAll(Me)
				End If
			End SyncLock

			' notifico l'inizio attivita`
			Try
				Me.StartBatch(bi, nq)
			Catch
			End Try

			' eseguo il batch
			Dim aborted As Boolean = False
			Try
				' uso altri eventi ad ogni giro .... per avere sempre eventi non segnalati all'inizio
				SyncLock Me
					_ev(0) = New AutoResetEvent(False)
					_ev(1) = New AutoResetEvent(False)
					_ev(2) = New AutoResetEvent(False)
				End SyncLock
				bi.z__SetEndWorkEvent(_ev(1), _ev(2))				   ' questo e` l'evento segnalato dal thread quando finisce

				Dim twh As Thread
				twh = New Thread(AddressOf bi.z__Run)
				twh.IsBackground = True
				twh.Start()

				Dim nEv As Integer = AutoResetEvent.WaitAny(_ev)
				If nEv = 0 Then
					' sono uscito a causa di un AbortBatch
					If twh.IsAlive Then
						twh.Abort()
						twh.Join()
						aborted = True
					End If
				ElseIf nEv = 2 Then
					aborted = True
					'Else evento (1): fine per morte naturale - non devo fare niente.
				End If
			Catch Ex As Exception
				Debug.WriteLine(Ex.Message)
			End Try

			SyncLock Me
				nq = Me.queueBI.Count
			End SyncLock

			' notifico la fine attivita`
			Try
				Me.EndBatch(bi, nq, aborted, "")
			Catch
			End Try

			' qui faccio pulizia della memoria.
			' si potrebbe affinare il processo invece di chiamare sempre la collect
			bi = Nothing
			If GC.GetTotalMemory(False) > 100 * 1024 * 1024 Then			 ' 100Mb
				If BilBLBase.AppSettingToBoolean("GG_Collect", False) Then
					GC.Collect()

					If BilBLBase.AppSettingToBoolean("GG_WaitForPendingFinalizers", False) Then
						GC.WaitForPendingFinalizers()
					End If
				End If
			End If
		Loop
	End Sub

	Public Sub AbortBatch(ByVal bi As BatchInfo)
		Dim nq As Integer = -1
		SyncLock Me
			If Me.queueBI.Contains(bi) Then
				' il batch e` in coda
				Dim nbi As New Queue

				' non esiste Remove in Queue.....
				While Me.queueBI.Count > 0
					Dim b As BatchInfo = DirectCast(Me.queueBI.Dequeue, BatchInfo)
					If Not b Is bi Then nbi.Enqueue(b)
				End While
				Me.queueBI = nbi
				nq = Me.queueBI.Count				' usato per dire anche se ho trovato bi in coda
			Else
				' il batch e` in running
				bi.z__Abort()

				' e` il thread abortito che segnalera` EndBatch
			End If
		End SyncLock

		Try
			If nq >= 0 Then Me.EndBatch(bi, nq, True, "")
		Catch
		End Try
	End Sub

	Private Shared Sub QueueBatch(ByVal bi As BatchInfo, ByVal nq As Integer)
		' qui creo un BatchStatus perche` potrei essere in un qualsiasi thread
		Dim s As New BatchStatus

		Dim d As String = String.Empty
		If Not bi._starterOperator Is Nothing Then
			d = bi._starterOperator + ": "
		End If
		d += bi.Description

		bi.BatchId = s.NewBatch(bi.BatchCode, d, bi.FlowDate)
		bi._Status = BatchInfo.Status.Q


		SystemMonitor.SmLog.smTrace(bi.Msg(Nothing))
	End Sub

	Private Sub StartBatch(ByVal bi As BatchInfo, ByVal nq As Integer)
		Dim s As New BatchStatus
		s.StartBatch(bi.BatchId)
		bi._Status = BatchInfo.Status.R

		SystemMonitor.SmLog.smTrace(String.Format("BatchId={0}: started", bi.BatchId))
	End Sub
	Private Sub EndBatch(ByVal bi As BatchInfo, ByVal nq As Integer, ByVal aborted As Boolean, ByVal message As String)
		Dim s As New BatchStatus
		s.EndBatch(bi.BatchId, aborted)
		If aborted Then
			bi._Status = BatchInfo.Status.A
		Else
			bi._Status = BatchInfo.Status.E
		End If

		If aborted Then
			SystemMonitor.SmLog.smError(bi.Msg(message))
		Else
			SystemMonitor.SmLog.smTrace(bi.Msg(message))
		End If

	End Sub

	' funzione da chiamare dalle funzioni eseguite in coda.
	' Serve per scrivere nel DB le info relative del batch in esecuzione: tipo progress bar o simili
	Public Shared Sub SetProgressBatch(ByVal progressMsg As String)

		Dim bi As BatchInfo = BatchInfo.BatchInfo

		If Not (bi Is Nothing OrElse bi.BatchId Is Nothing) Then
			SystemMonitor.SmLog.smTrace(bi.Msg(progressMsg))
		Else
			SystemMonitor.SmLog.smTrace(progressMsg)
		End If

		If Not BatchInfo.BatchInfo Is Nothing Then
			If Not BatchInfo.BatchInfo.BatchId Is Nothing Then
				Dim s As New BatchStatus
				s.UpdateProgress(BatchInfo.BatchInfo.BatchId, progressMsg)
			End If
		End If
	End Sub

	' funzione da chiamare dalle funzioni eseguite in coda.
	' Serve per scrivere nel DB le info relative del batch in esecuzione: tipo progress bar o simili
	Public Shared Sub SetProgressBatch(ByVal ex As Exception)

		If Not BatchInfo.BatchInfo Is Nothing Then
			If Not BatchInfo.BatchInfo.BatchId Is Nothing Then
				Dim s As New BatchStatus
				s.UpdateProgress(BatchInfo.BatchInfo.BatchId, ex.Message)
			End If
		End If

		Dim bi As BatchInfo = BatchInfo.BatchInfo
		If Not (bi Is Nothing OrElse bi.BatchId Is Nothing) Then
			SystemMonitor.SmLog.smTrace(ex, bi.Msg(Nothing))
		Else
			SystemMonitor.SmLog.smTrace(ex, Nothing)
		End If

	End Sub

End Class

