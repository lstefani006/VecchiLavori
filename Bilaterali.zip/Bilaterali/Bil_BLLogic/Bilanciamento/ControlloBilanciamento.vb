Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema
Imports SystemMonitor

Public Class ControlloBilanciamento
	Inherits BilBLBase

	Public Shared Function SogliaSbilanciamentoMWh() As Double
		Try
			Return XmlConvert.ToDouble(ConfigurationSettings.AppSettings("SogliaMWhBilanciamento"))
		Catch ex As Exception
			SmLog.smError("SogliaMWhBilanciamento non definita nel file di configurazione")
			Throw New ApplicationException("SogliaMWhBilanciamento non definita nel file di configurazione")
		End Try
	End Function

	Public Sub CalcolaBilanciamentoBatch(ByVal dataProgramma As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf CalcolaBilanciamentoAsync, dataProgramma, "CTRLBIL", "Controllo bilanciamento", dataProgramma, runningOperator)
	End Sub

	Public Sub CalcolaBilanciamentoAsync(ByVal dataProgramma As Object)
		Dim bl As New ControlloBilanciamento

		Dim perOra As Boolean = AppSettingToBoolean("CalcolaBilanciamento_PerOra", False)

		If perOra = False Then
			bl.CalcolaBilanciamento(CType(dataProgramma, DateTime))
		Else
			bl.CalcolaBilanciamentoOraPerOra(CType(dataProgramma, DateTime))
		End If
		bl.Dispose()
	End Sub


	Public Shared Sub StartTimer()

		Dim ora As String = AppSettingToString("Batch.CalcoloBilanciamento", "")
		If ora.Length = 0 Then Return

		Dim tsToStart As TimeSpan = TimeSpan.Parse(ora)

		JobScheduler.G.ExecuteJob(tsToStart, AddressOf CalcolabilanciamentoOnTimer)
		JobScheduler.G.Start()
	End Sub


	Private Shared G_TimerRunning As Boolean = False
	Private Shared Sub CalcolabilanciamentoOnTimer(ByVal o As Object)

		If G_TimerRunning = True Then
			SmLog.smError("CalcolabilanciamentoOnTimer: timer chiamato mentre un altro timer sta lavorando!")
			Return
		End If

		Try
			G_TimerRunning = True

			Dim dayStep As Integer = AppSettingToInt32("CalcolabilanciamentoOnTimer_DayStep", 1)
			Dim tsFlusso As DateTime = DateTime.Now.Date.AddDays(dayStep)

			If True Then
				Dim bl As New ControlloBilanciamento
				bl.CalcolaBilanciamentoBatch(tsFlusso, "Batch")
			End If

			' aspetto 1 secondo per evitare di avere un bacth in coda potenzialmente contemporanei
			' (la granularita` del DateTime di SQL server e` 3.33mSec....)
			System.Threading.Thread.Sleep(1000)

			If True Then
				Dim bl2 As New ReportXmlBilanciamento
				bl2.CreaReportSbilanciamentoBatch(tsFlusso, "Batch")
			End If

		Catch ex As Exception
			SmLog.smError(ex, "CalcolabilanciamentoOnTimer. Timer disabilitato")

		Finally
			G_TimerRunning = False
		End Try

	End Sub


	Private Sub CalcolaBilanciamento(ByVal dataProgramma As DateTime)
		Try
			Dim sBilCalcQueryTmo As String = "CalcolaBilanciamentoQueryTmo"
			smTrace("CalcolaBilanciamento: inizio attivita` DataFlusso={0:dd/MM/yyy}", dataProgramma)

			cn.ConnectionString = GetConnectionString()
			cn.Open()

			spCalcolaBilanciamento.Parameters("@DataProgramma").Value = dataProgramma
			spCalcolaBilanciamento.Parameters("@SogliaSbilMWh").Value = SogliaSbilanciamentoMWh()
			'
			' Setta query timeout (default 45 secondi)
			'
			spCalcolaBilanciamento.CommandTimeout = AppSettingToInt32(sBilCalcQueryTmo, 45)
			spCalcolaBilanciamento.ExecuteNonQuery()

			smTrace("CalcolaBilanciamento: fine attivita` DataFlusso={0:dd/MM/yyy}", dataProgramma)

		Catch ex As Exception
			smError(ex, "CalcolaBilanciamento")
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Sub


	Private Sub CalcolaBilanciamentoOraPerOra(ByVal dataProgramma As DateTime)
		Try
			Dim sBilCalcQueryTmo As String = "CalcolaBilanciamentoQueryTmo"

			smTrace("CalcolaBilanciamentoOraPerOra: inizio attivita`")

			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim maxora As Byte = GetNumberOfHourOfDay(dataProgramma)

			For ora As Byte = 1 To maxora
				Dim cmd As New SqlCommand("spCalcolaBilanciamentoPerOra", cn)
				cmd.CommandType = CommandType.StoredProcedure

				cmd.Parameters.Add("@DataProgramma", dataProgramma)
				cmd.Parameters.Add("@SogliaSbilMWh", SogliaSbilanciamentoMWh())
				cmd.Parameters.Add("@Ora", ora)

				If ora = maxora Then
					cmd.Parameters.Add("@UltimoBilanciamento", True)
				Else
					cmd.Parameters.Add("@UltimoBilanciamento", False)
				End If

				cmd.CommandTimeout = AppSettingToInt32(sBilCalcQueryTmo, 45)
				cmd.ExecuteNonQuery()

				smTrace(String.Format("CalcolaBilanciamentoOraPerOra: terminato per ora={0}", ora))
			Next

			smTrace("CalcolaBilanciamentoOraPerOra: fine attivita`")

		Catch ex As Exception
			smError(ex, "CalcolaBilanciamentoOraPerOra")
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Sub




	Public Function CalcolaBilanciamento(ByVal dataProgramma As DateTime, ByVal PeriodoRilevante As Byte, ByVal IdContratto As Integer) As Object
		Try
			Dim sBilCalcQueryTmo As String = "CalcolaBilanciamentoQueryTmo"
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			spCalcolaBilanciamentoPerContratto.Parameters("@IdContratto").Value = IdContratto
			spCalcolaBilanciamentoPerContratto.Parameters("@DataProgramma").Value = dataProgramma
			spCalcolaBilanciamentoPerContratto.Parameters("@PeriodoRilevante").Value = PeriodoRilevante
			spCalcolaBilanciamentoPerContratto.Parameters("@SogliaSbilMWh").Value = SogliaSbilanciamentoMWh()
			'
			' setta query timeout a 45 secondi salvo non specificato diversamente
			'
			spCalcolaBilanciamentoPerContratto.CommandTimeout = AppSettingToInt32(sBilCalcQueryTmo, 45)
			Dim rd As SqlDataReader
			Try
				rd = spCalcolaBilanciamentoPerContratto.ExecuteReader()

				CalcolaBilanciamento = Nothing
				If rd.Read() Then
					If Not rd.IsDBNull(0) Then
						CalcolaBilanciamento = rd.GetDouble(0)
					End If
				End If
			Finally
				If Not rd Is Nothing Then rd.Close()
			End Try

			Return CalcolaBilanciamento

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Function


	Public Sub EseguiBilanciamentoPerContrattoDataOra(ByRef cn As SqlConnection, ByRef tr As SqlClient.SqlTransaction, ByVal IdContratto As Integer, ByVal dt As DateTime, ByVal hour As Byte, ByVal soglia As Double)
		Dim bCnOpened As Boolean = False
		Dim sBilCalcQueryTmo As String = "CalcolaBilanciamentoQueryTmo"
		Try
			If cn Is Nothing Or _
			 cn.State = ConnectionState.Closed Or _
			 cn.State = ConnectionState.Broken Then
				cn.ConnectionString = GetConnectionString()
				cn.Open()
				bCnOpened = True
			Else
				spEseguiBilPerContrattoDataOra.Transaction = tr
			End If
			spEseguiBilPerContrattoDataOra.Connection = cn
			spEseguiBilPerContrattoDataOra.Parameters("@IdContratto").Value = IdContratto
			spEseguiBilPerContrattoDataOra.Parameters("@DataProgramma").Value = dt
			spEseguiBilPerContrattoDataOra.Parameters("@PeriodoRilevante").Value = hour
			spEseguiBilPerContrattoDataOra.Parameters("@SogliaSbilMWh").Value = soglia

			Dim numRowsAffected As Integer

			'
			' Setta query timeout (default 45 secondi)
			'
			spEseguiBilPerContrattoDataOra.CommandTimeout = AppSettingToInt32(sBilCalcQueryTmo, 45)

			numRowsAffected = spEseguiBilPerContrattoDataOra.ExecuteNonQuery()

		Catch ex As Exception
			SmLog.smError(String.Format("Calcolo del bilanciamento run-rime per il contratto {0}, data {1}, ora {2} fallito - Exception message is [{3}])", _
			   IdContratto.ToString, dt.ToShortDateString, hour.ToString, ex.Message))
			Throw
		Finally
			If bCnOpened Then
				If cn.State = ConnectionState.Open Then cn.Close()
			End If
		End Try
	End Sub

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents spCalcolaBilanciamento As System.Data.SqlClient.SqlCommand
	Friend WithEvents spCalcolaBilanciamentoPerContratto As System.Data.SqlClient.SqlCommand
	Friend WithEvents spEseguiBilPerContrattoDataOra As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.spCalcolaBilanciamento = New System.Data.SqlClient.SqlCommand
		Me.spCalcolaBilanciamentoPerContratto = New System.Data.SqlClient.SqlCommand
		Me.spEseguiBilPerContrattoDataOra = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=True;initial catalog=BilateraliBig2;password=bilaterali"
		'
		'spCalcolaBilanciamento
		'
		Me.spCalcolaBilanciamento.CommandText = "dbo.[spCalcolaBilanciamento]"
		Me.spCalcolaBilanciamento.CommandType = System.Data.CommandType.StoredProcedure
		Me.spCalcolaBilanciamento.Connection = Me.cn
		Me.spCalcolaBilanciamento.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spCalcolaBilanciamento.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.spCalcolaBilanciamento.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SogliaSbilMWh", System.Data.SqlDbType.Float, 8))
		'
		'spCalcolaBilanciamentoPerContratto
		'
		Me.spCalcolaBilanciamentoPerContratto.CommandText = "dbo.[spCalcolaBilanciamentoPerContratto]"
		Me.spCalcolaBilanciamentoPerContratto.CommandType = System.Data.CommandType.StoredProcedure
		Me.spCalcolaBilanciamentoPerContratto.Connection = Me.cn
		Me.spCalcolaBilanciamentoPerContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spCalcolaBilanciamentoPerContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me.spCalcolaBilanciamentoPerContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.spCalcolaBilanciamentoPerContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1))
		Me.spCalcolaBilanciamentoPerContratto.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SogliaSbilMWh", System.Data.SqlDbType.Float, 8))
		'
		'spEseguiBilPerContrattoDataOra
		'
		Me.spEseguiBilPerContrattoDataOra.CommandText = "[spEseguiBilanciamentoPerContratto]"
		Me.spEseguiBilPerContrattoDataOra.CommandType = System.Data.CommandType.StoredProcedure
		Me.spEseguiBilPerContrattoDataOra.Connection = Me.cn
		Me.spEseguiBilPerContrattoDataOra.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spEseguiBilPerContrattoDataOra.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4))
		Me.spEseguiBilPerContrattoDataOra.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.spEseguiBilPerContrattoDataOra.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1))
		Me.spEseguiBilPerContrattoDataOra.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SogliaSbilMWh", System.Data.SqlDbType.Float, 8))

	End Sub

#End Region

End Class
