Imports System.IO
Imports System.Text
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema
Imports SystemMonitor


Public Class BilanciamentoForzato
	Inherits BilBLBase

	Private Shared Function SogliaSbilanciamentoMWh() As Double
		Try
			Return XmlConvert.ToDouble(ConfigurationSettings.AppSettings("SogliaMWhBilanciamento"))
		Catch ex As Exception
			SmLog.smError("SogliaMWhBilanciamento non definita nel file di configurazione")
			Throw New ApplicationException("SogliaMWhBilanciamento non definita nel file di configurazione")
		End Try
	End Function


	Public Sub ForzaBilanciamentoBatch(ByVal data As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf ForzaBilanciamentoAsync, data, "BILFORZ", "Bilanciamento forzato", data, runningOperator)
	End Sub

	Private Shared Sub ForzaBilanciamentoAsync(ByVal data As Object)
		Dim bl As New BilanciamentoForzato

		Dim perOra As Boolean = AppSettingToBoolean("BilanciamentoForzato_PerOra", False)

		If perOra = False Then
			bl.ForzaBilanciamento(CType(data, DateTime))
		Else
			bl.ForzaBilanciamentoOraPerOra(CType(data, DateTime))
		End If

		bl.Dispose()
	End Sub

	Private Sub ForzaBilanciamento(ByVal data As DateTime)
		Try
			Dim sBilForcedQueryTmo As String = "BilanciamentoForzatoQueryTmo"
			smTrace(String.Format("Bilanciamento forzato inizio attivita' data={0}", data))

			cn.ConnectionString = GetConnectionString()
			cn.Open()

			spBilanciamentoForzato.Parameters("@DataProgramma").Value = data
			spBilanciamentoForzato.Parameters("@SogliaSbilMWh").Value = ControlloBilanciamento.SogliaSbilanciamentoMWh()

			'
			' Setta query timeout (default 45 secondi)
			'
			spBilanciamentoForzato.CommandTimeout = AppSettingToInt32(sBilForcedQueryTmo, 45)
			spBilanciamentoForzato.ExecuteNonQuery()

			smTrace("Bilanciamento forzato attivita' terminata")

		Catch ex As Exception
			smError(ex, "Bilanciamento forzato")
			Throw
		Finally
			cn.Dispose()
		End Try
	End Sub


	Private Sub ForzaBilanciamentoOraPerOra(ByVal data As DateTime)
		Try
			Dim sBilForcedQueryTmo As String = "BilanciamentoForzatoQueryTmo"

			smTrace(String.Format("Bilanciamento forzato inizio attivita' data={0}", data))

			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim maxora As Byte = GetNumberOfHourOfDay(data)

			For ora As Byte = 1 To maxora
				Dim cmd As New SqlCommand("spBilanciamentoForzatoPerOra", cn)
				cmd.CommandType = CommandType.StoredProcedure

				cmd.Parameters.Add("@DataProgramma", data)
				cmd.Parameters.Add("@SogliaSbilMWh", SogliaSbilanciamentoMWh())
				cmd.Parameters.Add("@Ora", ora)

				If ora = maxora Then
					cmd.Parameters.Add("@UltimoBilanciamento", True)
				Else
					cmd.Parameters.Add("@UltimoBilanciamento", False)
				End If

				cmd.CommandTimeout = AppSettingToInt32(sBilForcedQueryTmo, 45)
				cmd.ExecuteNonQuery()

				smTrace(String.Format("ForzaBilanciamentoOraPerOra: terminato per ora={0}", ora))
			Next

			smTrace("Bilanciamento forzato attivita' terminata")

		Catch ex As Exception
			smError(ex, "ForzaBilanciamentoOraPerOra")
			Throw
		Finally
			cn.Dispose()
		End Try
	End Sub






#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents spBilanciamentoForzato As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.spBilanciamentoForzato = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=True;initial catalog=BilateraliBig2;password=bilaterali"
		'
		'spBilanciamentoForzato
		'
		Me.spBilanciamentoForzato.CommandText = "dbo.[spBilanciamentoForzato]"
		Me.spBilanciamentoForzato.CommandType = System.Data.CommandType.StoredProcedure
		Me.spBilanciamentoForzato.Connection = Me.cn
		Me.spBilanciamentoForzato.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spBilanciamentoForzato.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.spBilanciamentoForzato.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SogliaSbilMWh", System.Data.SqlDbType.Float, 8))
		Me.spBilanciamentoForzato.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AzzeraSbilanciamento", System.Data.SqlDbType.Bit, 1))
		Me.spBilanciamentoForzato.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RicalcolaBilanciamento", System.Data.SqlDbType.Bit, 1))

	End Sub

#End Region

End Class
