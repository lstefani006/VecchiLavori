Imports System.Configuration
Imports System.Random

Public Class NewId30
    Private Shared nNewId As Int64 = 0
    Private Shared sNewId As String = Nothing
    Private Shared sAppId As String = Nothing

    Public Shared Function Generate() As String
        Dim r As String
        SyncLock GetType(NewId30)
            If (sNewId Is Nothing) Then
                sNewId = String.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now)
            End If

            ' per prima cosa simulo un id dell'applicativo
            If (sAppId Is Nothing) Then
                ' se non lo trovo nel file di configurazione
                sAppId = Configuration.ConfigurationSettings.AppSettings("NewId30.AddId")
                If (sAppId Is Nothing) Then    ' se non c'e` mi affido al caso
                    ' il seed e' time dependent
                    sAppId = New Random().Next(100).ToString("d2")       ' 2 cifre casuali
                End If
            End If

            ' sono 14
            Dim s As String = String.Format("{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}", DateTime.Now)
            If (s <> sNewId) Then
                sNewId = s
                nNewId = 0
            End If

            ' qui ne aggiungo praticamente all'inifinito
            r = sNewId + nNewId.ToString("D9") + sAppId     ' 14 + 9 + 2 = 25
            nNewId += 1
        End SyncLock
        Return r
    End Function

End Class
