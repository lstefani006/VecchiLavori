Imports CertPInvokeLib


Public Class CRL
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		components = New System.ComponentModel.Container
	End Sub

#End Region


	Public Sub DownloadAsync(ByVal tsCheckCertificate As DateTime, ByVal dataFlusso As DateTime, ByVal runningOperator As String)
		smTrace("CRL: inizio download")
		If (True) Then
			BatchSerializer.BS.AddBatch(AddressOf CRL.DownloadWorkerAsync, tsCheckCertificate, "CRL/CHK", "Download CRL/Check certificati", dataFlusso, runningOperator)
		Else
			CRL.DownloadWorkerAsync(Nothing)
		End If
	End Sub

	Private Shared Sub DownloadWorkerAsync(ByVal obj As Object)
		Dim c As New CRL
		c.Download(CType(obj, DateTime))
		c.Dispose()
	End Sub


	Private Sub Download(ByVal tsCheckCertificate As DateTime)
		smTrace("CRL - inizio download")
		Dim c As New Bil_Crypt.CertificateManager
		c.UpdadeCRL()
		c.CheckCertificate(tsCheckCertificate)
		smTrace("CRL - fine download")
	End Sub

	'////////////////////////////////////////////////////////////////////
	Public Sub CheckCertificatesAsync(ByVal tsCheckCertificate As DateTime, ByVal dataFlusso As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf CRL.CheckCertificatesWorkerAsync, tsCheckCertificate, "CHK", "Check certificati", dataFlusso, runningOperator)
	End Sub

	Private Shared Sub CheckCertificatesWorkerAsync(ByVal obj As Object)
		Dim c As New CRL
		c.CheckCertificates(CType(obj, DateTime))
		c.Dispose()
	End Sub

	Private Sub CheckCertificates(ByVal tsCheckCertificate As DateTime)
		smTrace("CRL: inizio check")
		Dim c As New Bil_Crypt.CertificateManager
		c.CheckCertificate(tsCheckCertificate)
		smTrace("CRL: fine check")
	End Sub

	'////////////////////////////////////////////////////////////////////
	Public Function StoreCertificate(ByVal doc() As Byte, ByVal codiceUtenteSDC As String, ByVal bAbilitaCertificato As Boolean) As String
		Try
			Dim msg As String
			If (VerificaInputPKCS7(doc, msg) = False) Then
				Return msg
			End If

			Dim c As CertX509Ex
			c = EstraiCertificatoPKCS7(doc, msg)
			If c Is Nothing Then
				Return msg
			End If

			Dim startDate As DateTime = c.EffectiveDate
			Dim endDate As DateTime = c.ExpirationDate
			Dim actualDate As DateTime = DateTime.Now

			If (actualDate < startDate) Then
				msg = "Certificato non ancora attivo"
				Return msg
			End If

			If (actualDate > endDate) Then
				msg = "Certificato scaduto"
				Return msg
			End If

			Dim cm As New Bil_Crypt.CertificateManager
			cm.StoreCertificate(c, codiceUtenteSDC, bAbilitaCertificato)
			Return String.Empty

		Catch ex As Exception
			smError(ex, "StoreCertificate")
			Return "Memorizzazione certificato fallita: " + ex.Message
		End Try
	End Function

	Public Function GetOrignalDocument(ByVal doc() As Byte) As Byte()
		Return EstraiDocumentoOriginale(doc)
	End Function

#Region "funzioni di utilita`"
	Private Function VerificaInputPKCS7(ByVal by() As Byte, ByRef errorMsg As String) As Boolean
		Dim result As Boolean = True
		errorMsg = ""

		Try
			result = CryptVerify.Verify(by)
		Catch cEx As CertException
			smError(cEx)
			errorMsg = "Verifica HASH firma errato"
			result = False
		Catch ex As Exception
			smError(ex)
			errorMsg = "Errore generico su Verifica HASH firma errato"
			result = False
		Finally
		End Try
		Return result
	End Function


	'
	' Estrae da Input PKCS7 il dato originario
	'
	Private Function EstraiCertificatoPKCS7(ByVal by() As Byte, ByRef errorMsg As String) As CertX509Ex
		errorMsg = ""

		Dim cVerify As CryptVerify = Nothing
		Dim cert As CertX509Ex = Nothing
		Try
			cVerify = New CryptVerify(by, False)

			'
			' Unused
			'
			' cVerify.GetData()
			cert = cVerify.GetCertificate()
			Return cert

		Catch ex As Exception
			errorMsg = "Estrazione certificato fallita: " + ex.Message
			smError(ex)
			Return Nothing

		Finally
		End Try

	End Function


	'
	' bLogExceptions = false ==> NON effettua log delle eccezioni (usata in modo iterativo per determinare il messaggio originario)
	' bLogExceptions = true  ==> effettua log delle eccezioni
	Private Function EstraiDaInputPKCS7(ByVal xmlByteArray() As Byte, ByVal bLogExceptions As Boolean, ByRef cert As CertX509Ex) As Byte()
		Dim xmlExtract As Byte() = Nothing
		Dim cVerify As CryptVerify = Nothing
		cert = Nothing
		Try
			cVerify = New CryptVerify(xmlByteArray, False)
			xmlExtract = cVerify.GetData()
			cert = cVerify.GetCertificate()
		Catch cEx As CertException
			If bLogExceptions Then
				smError(cEx)
			End If
		Catch ex As Exception
			If bLogExceptions Then
				smError(ex)
			End If
		End Try
		Return xmlExtract
	End Function


	Private Function EstraiDocumentoOriginale(ByVal by() As Byte) As Byte()
		Dim bLogExceptions As Boolean = False
		Try
			Do
				Dim msg As String
				Dim c As CertX509Ex
				'
				' Viene usata in modo iterativo per estrarre i dati dal buffer firmato (oppure no)
				'
				Dim r() As Byte = EstraiDaInputPKCS7(by, bLogExceptions, c)
				If r Is Nothing Then
					Return by
				End If
				by = r
			Loop
		Catch ex As Exception
			Return by
		End Try
	End Function
#End Region

End Class
