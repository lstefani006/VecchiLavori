
Public Class ForceAction
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        _cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents daForceAction As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents dsForceAction As Bil.DS_ForceAction
    Friend WithEvents daCA As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlInsertCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlUpdateCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlDeleteCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlSelectCommand3 As System.Data.SqlClient.SqlCommand
    Friend WithEvents spGetProgrammiConCertificatoNonValido As System.Data.SqlClient.SqlCommand
    Friend WithEvents daGetProgrammiConCertificatoNonValido As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._cn = New System.Data.SqlClient.SqlConnection
        Me.daForceAction = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.dsForceAction = New Bil.DS_ForceAction
        Me.daCA = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand2 = New System.Data.SqlClient.SqlCommand
        Me.SqlInsertCommand2 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand2 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand3 = New System.Data.SqlClient.SqlCommand
        Me.spGetProgrammiConCertificatoNonValido = New System.Data.SqlClient.SqlCommand
        Me.daGetProgrammiConCertificatoNonValido = New System.Data.SqlClient.SqlDataAdapter
        CType(Me.dsForceAction, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        '_cn
        '
        Me._cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
        "st security info=False;initial catalog=Bilaterali"
        '
        'daForceAction
        '
        Me.daForceAction.DeleteCommand = Me.SqlDeleteCommand1
        Me.daForceAction.InsertCommand = Me.SqlInsertCommand1
        Me.daForceAction.SelectCommand = Me.SqlSelectCommand1
        Me.daForceAction.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Certificate_List", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Issuer", "Issuer"), New System.Data.Common.DataColumnMapping("SerialNumber", "SerialNumber"), New System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"), New System.Data.Common.DataColumnMapping("TSScadenza", "TSScadenza"), New System.Data.Common.DataColumnMapping("ForceAction", "ForceAction"), New System.Data.Common.DataColumnMapping("Subject", "Subject"), New System.Data.Common.DataColumnMapping("Abilitato", "Abilitato"), New System.Data.Common.DataColumnMapping("LastError", "LastError")})})
        Me.daForceAction.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM dbo.Certificate_List WHERE (CodiceUtenteSDC = @Original_CodiceUtenteS" & _
        "DC) AND (Issuer = @Original_Issuer) AND (SerialNumber = @Original_SerialNumber)"
        Me.SqlDeleteCommand1.Connection = Me._cn
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Issuer", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SerialNumber", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO dbo.Certificate_List(Issuer, SerialNumber, CodiceUtenteSDC, TSScadenz" & _
        "a, ForceAction, Subject, Abilitato, LastError) VALUES (@Issuer, @SerialNumber, @" & _
        "CodiceUtenteSDC, @TSScadenza, @ForceAction, @Subject, @Abilitato, @LastError)"
        Me.SqlInsertCommand1.Connection = Me._cn
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 64, "ForceAction"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 512, "Subject"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LastError", System.Data.SqlDbType.VarChar, 256, "LastError"))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT Issuer, SerialNumber, CodiceUtenteSDC, TSScadenza, ForceAction, Subject, A" & _
        "bilitato, LastError FROM dbo.Certificate_List"
        Me.SqlSelectCommand1.Connection = Me._cn
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE dbo.Certificate_List SET Issuer = @Issuer, SerialNumber = @SerialNumber, C" & _
        "odiceUtenteSDC = @CodiceUtenteSDC, TSScadenza = @TSScadenza, ForceAction = @Forc" & _
        "eAction, Subject = @Subject, Abilitato = @Abilitato, LastError = @LastError WHER" & _
        "E (CodiceUtenteSDC = @Original_CodiceUtenteSDC) AND (Issuer = @Original_Issuer) " & _
        "AND (SerialNumber = @Original_SerialNumber)"
        Me.SqlUpdateCommand1.Connection = Me._cn
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64, "SerialNumber"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ForceAction", System.Data.SqlDbType.VarChar, 64, "ForceAction"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Subject", System.Data.SqlDbType.VarChar, 512, "Subject"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LastError", System.Data.SqlDbType.VarChar, 256, "LastError"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Issuer", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_SerialNumber", System.Data.SqlDbType.VarChar, 64, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SerialNumber", System.Data.DataRowVersion.Original, Nothing))
        '
        'dsForceAction
        '
        Me.dsForceAction.DataSetName = "dsForceAction"
        Me.dsForceAction.Locale = New System.Globalization.CultureInfo("it-IT")
        '
        'daCA
        '
        Me.daCA.DeleteCommand = Me.SqlDeleteCommand2
        Me.daCA.InsertCommand = Me.SqlInsertCommand2
        Me.daCA.SelectCommand = Me.SqlSelectCommand2
        Me.daCA.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Certificate_CA", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Issuer", "Issuer"), New System.Data.Common.DataColumnMapping("Abilitata", "Abilitata"), New System.Data.Common.DataColumnMapping("ChildOf", "ChildOf"), New System.Data.Common.DataColumnMapping("TSDownloadEffettivo", "TSDownloadEffettivo"), New System.Data.Common.DataColumnMapping("TSScadenza", "TSScadenza"), New System.Data.Common.DataColumnMapping("TSUltimoDownload", "TSUltimoDownload")})})
        Me.daCA.UpdateCommand = Me.SqlUpdateCommand2
        '
        'SqlDeleteCommand2
        '
        Me.SqlDeleteCommand2.CommandText = "DELETE FROM dbo.Certificate_CA WHERE (Issuer = @Original_Issuer)"
        Me.SqlDeleteCommand2.Connection = Me._cn
        Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Issuer", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlInsertCommand2
        '
        Me.SqlInsertCommand2.CommandText = "INSERT INTO dbo.Certificate_CA (Issuer, Abilitata, ChildOf, TSDownloadEffettivo, " & _
        "TSScadenza, TSUltimoDownload) VALUES (@Issuer, @Abilitata, @ChildOf, @TSDownload" & _
        "Effettivo, @TSScadenza, @TSUltimoDownload)"
        Me.SqlInsertCommand2.Connection = Me._cn
        Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"))
        Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"))
        Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ChildOf", System.Data.SqlDbType.VarChar, 256, "ChildOf"))
        Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSDownloadEffettivo", System.Data.SqlDbType.DateTime, 4, "TSDownloadEffettivo"))
        Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"))
        Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSUltimoDownload", System.Data.SqlDbType.DateTime, 4, "TSUltimoDownload"))
        '
        'SqlSelectCommand2
        '
        Me.SqlSelectCommand2.CommandText = "SELECT CA.Issuer, CA.Abilitata, CA.ChildOf, CA.TSDownloadEffettivo, CA.TSScadenza" & _
        ", CA.TSUltimoDownload, ISNULL(CDL.NoDP, 0) AS NoDP FROM dbo.Certificate_CA CA LE" & _
        "FT OUTER JOIN (SELECT Issuer, COUNT(isnull(url, 0)) NoDP FROM dbo.Certificate_Di" & _
        "stributionPoints GROUP BY Issuer) CDL ON CA.Issuer = CDL.Issuer"
        Me.SqlSelectCommand2.Connection = Me._cn
        '
        'SqlUpdateCommand2
        '
        Me.SqlUpdateCommand2.CommandText = "UPDATE dbo.Certificate_CA SET Issuer = @Issuer, Abilitata = @Abilitata, ChildOf =" & _
        " @ChildOf, TSDownloadEffettivo = @TSDownloadEffettivo, TSScadenza = @TSScadenza," & _
        " TSUltimoDownload = @TSUltimoDownload WHERE (Issuer = @Original_Issuer)"
        Me.SqlUpdateCommand2.Connection = Me._cn
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256, "Issuer"))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ChildOf", System.Data.SqlDbType.VarChar, 256, "ChildOf"))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSDownloadEffettivo", System.Data.SqlDbType.DateTime, 4, "TSDownloadEffettivo"))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSScadenza", System.Data.SqlDbType.DateTime, 4, "TSScadenza"))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSUltimoDownload", System.Data.SqlDbType.DateTime, 4, "TSUltimoDownload"))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Issuer", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Issuer", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlSelectCommand3
        '
        Me.SqlSelectCommand3.CommandText = "dbo.[spGetProgrammiConCertificatoNonValido]"
        Me.SqlSelectCommand3.CommandType = System.Data.CommandType.StoredProcedure
        Me.SqlSelectCommand3.Connection = Me._cn
        Me.SqlSelectCommand3.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        Me.SqlSelectCommand3.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16))
        Me.SqlSelectCommand3.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256))
        Me.SqlSelectCommand3.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64))
        Me.SqlSelectCommand3.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataRicerca", System.Data.SqlDbType.DateTime, 8))
        '
        'spGetProgrammiConCertificatoNonValido
        '
        Me.spGetProgrammiConCertificatoNonValido.CommandText = "dbo.[spGetProgrammiConCertificatoNonValido]"
        Me.spGetProgrammiConCertificatoNonValido.CommandType = System.Data.CommandType.StoredProcedure
        Me.spGetProgrammiConCertificatoNonValido.Connection = Me._cn
        Me.spGetProgrammiConCertificatoNonValido.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        Me.spGetProgrammiConCertificatoNonValido.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16))
        Me.spGetProgrammiConCertificatoNonValido.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Issuer", System.Data.SqlDbType.VarChar, 256))
        Me.spGetProgrammiConCertificatoNonValido.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SerialNumber", System.Data.SqlDbType.VarChar, 64))
        Me.spGetProgrammiConCertificatoNonValido.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataRicerca", System.Data.SqlDbType.DateTime, 8))
        '
        'daGetProgrammiConCertificatoNonValido
        '
        Me.daGetProgrammiConCertificatoNonValido.SelectCommand = Me.spGetProgrammiConCertificatoNonValido
        CType(Me.dsForceAction, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Public Function GetForceAction() As DS_ForceAction
        Try
            _cn.Open()
            daForceAction.Fill(Me.dsForceAction.Certificate_List)
            daCA.Fill(Me.dsForceAction.Certificate_CA)

            Return Me.dsForceAction
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If _cn.State = ConnectionState.Open Then _cn.Close()
        End Try
    End Function

    Public Function GetForceAction(ByVal CodiceUtenteSDC As String, ByVal Issuer As String, ByVal SerialNumber As String, ByVal DataRicerca As DateTime) As DS_ForceAction

        Try
            _cn.Open()
            'daForceAction.Fill(Me.dsForceAction.Certificate_List)
			'daCA.Fill(Me.dsForceAction.Certificate_CA)

			daGetProgrammiConCertificatoNonValido.SelectCommand.CommandTimeout = AppSettingToInt32("ForceActionQueryTmo", 60)
			daGetProgrammiConCertificatoNonValido.SelectCommand.Parameters("@CodiceUtenteSDC").Value = CodiceUtenteSDC
            daGetProgrammiConCertificatoNonValido.SelectCommand.Parameters("@Issuer").Value = Issuer
            daGetProgrammiConCertificatoNonValido.SelectCommand.Parameters("@SerialNumber").Value = SerialNumber
            daGetProgrammiConCertificatoNonValido.SelectCommand.Parameters("@DataRicerca").Value = DataRicerca

            daGetProgrammiConCertificatoNonValido.Fill(Me.dsForceAction.ProgrammiConCertificatoNonValido)

            Return Me.dsForceAction
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If _cn.State = ConnectionState.Open Then _cn.Close()
        End Try

    End Function


    Public Sub SaveForceAction(ByVal ds As DS_ForceAction)
        Try
            _cn.Open()

            If ds.HasChanges Then
                daForceAction.Update(ds.Certificate_List)
                daCA.Update(ds.Certificate_CA)
            End If
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If _cn.State = ConnectionState.Open Then _cn.Close()
        End Try
    End Sub


#End Region

End Class
