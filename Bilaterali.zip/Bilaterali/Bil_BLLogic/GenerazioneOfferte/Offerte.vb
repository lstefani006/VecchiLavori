Imports System.IO
Imports System.Text
Imports System.Threading
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Xml
Imports System.Xml.Schema
Imports SystemMonitor

Public Class Offerte
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents spGeneraOfferte_PgmBilanciati As System.Data.SqlClient.SqlCommand
	Friend WithEvents spGeneraOfferte_PgmNonBilanciati As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents daPOUE As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents spGeneraOfferte As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.spGeneraOfferte_PgmBilanciati = New System.Data.SqlClient.SqlCommand
		Me.spGeneraOfferte_PgmNonBilanciati = New System.Data.SqlClient.SqlCommand
		Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
		Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
		Me.daPOUE = New System.Data.SqlClient.SqlDataAdapter
		Me.spGeneraOfferte = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=sa;data source=BILSVR1;persist se" & _
		"curity info=True;initial catalog=Bilaterali;password=bilaterali"
		'
		'spGeneraOfferte_PgmBilanciati
		'
		Me.spGeneraOfferte_PgmBilanciati.CommandText = "dbo.[spGeneraOfferte_PgmBilanciati]"
		Me.spGeneraOfferte_PgmBilanciati.CommandType = System.Data.CommandType.StoredProcedure
		Me.spGeneraOfferte_PgmBilanciati.Connection = Me.cn
		Me.spGeneraOfferte_PgmBilanciati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spGeneraOfferte_PgmBilanciati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataRicerca", System.Data.SqlDbType.DateTime, 8))
		Me.spGeneraOfferte_PgmBilanciati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OraRicerca", System.Data.SqlDbType.TinyInt, 1))
		'
		'spGeneraOfferte_PgmNonBilanciati
		'
		Me.spGeneraOfferte_PgmNonBilanciati.CommandText = "dbo.[spGeneraOfferte_PgmNonBilanciati]"
		Me.spGeneraOfferte_PgmNonBilanciati.CommandType = System.Data.CommandType.StoredProcedure
		Me.spGeneraOfferte_PgmNonBilanciati.Connection = Me.cn
		Me.spGeneraOfferte_PgmNonBilanciati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spGeneraOfferte_PgmNonBilanciati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataRicerca", System.Data.SqlDbType.DateTime, 8))
		Me.spGeneraOfferte_PgmNonBilanciati.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OraRicerca", System.Data.SqlDbType.TinyInt, 1))
		'
		'SqlSelectCommand1
		'
		Me.SqlSelectCommand1.CommandText = "SELECT IdContratto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUni" & _
		"taSDC, Origin, ReasonCode, ReasonText, IdFile FROM ProgrammaOrarioPerUnitaErrori" & _
		" WHERE (DataProgramma = @DataProgramma) AND (PeriodoRilevante = @PeriodoRilevant" & _
		"e)"
		Me.SqlSelectCommand1.Connection = Me.cn
		Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		'
		'SqlInsertCommand1
		'
		Me.SqlInsertCommand1.CommandText = "INSERT INTO dbo.ProgrammaOrarioPerUnitaErrori(IdContratto, DataProgramma, Periodo" & _
		"Rilevante, CodiceUnitaSDC, CategoriaUnitaSDC, Origin, ReasonCode, ReasonText, Id" & _
		"File) VALUES (@IdContratto, @DataProgramma, @PeriodoRilevante, @CodiceUnitaSDC, " & _
		"@CategoriaUnitaSDC, @Origin, @ReasonCode, @ReasonText, @IdFile); SELECT IdContra" & _
		"tto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUnitaSDC, Origin," & _
		" ReasonCode, ReasonText, IdFile FROM dbo.ProgrammaOrarioPerUnitaErrori WHERE (Ca" & _
		"tegoriaUnitaSDC = @CategoriaUnitaSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC) AND" & _
		" (DataProgramma = @DataProgramma) AND (IdContratto = @IdContratto) AND (PeriodoR" & _
		"ilevante = @PeriodoRilevante)"
		Me.SqlInsertCommand1.Connection = Me.cn
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Origin", System.Data.SqlDbType.VarChar, 2, "Origin"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonCode", System.Data.SqlDbType.VarChar, 15, "ReasonCode"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonText", System.Data.SqlDbType.VarChar, 1024, "ReasonText"))
		Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, "IdFile"))
		'
		'SqlUpdateCommand1
		'
		Me.SqlUpdateCommand1.CommandText = "UPDATE dbo.ProgrammaOrarioPerUnitaErrori SET IdContratto = @IdContratto, DataProg" & _
		"ramma = @DataProgramma, PeriodoRilevante = @PeriodoRilevante, CodiceUnitaSDC = @" & _
		"CodiceUnitaSDC, CategoriaUnitaSDC = @CategoriaUnitaSDC, Origin = @Origin, Reason" & _
		"Code = @ReasonCode, ReasonText = @ReasonText, IdFile = @IdFile WHERE (CategoriaU" & _
		"nitaSDC = @Original_CategoriaUnitaSDC) AND (CodiceUnitaSDC = @Original_CodiceUni" & _
		"taSDC) AND (DataProgramma = @Original_DataProgramma) AND (IdContratto = @Origina" & _
		"l_IdContratto) AND (PeriodoRilevante = @Original_PeriodoRilevante) AND (IdFile =" & _
		" @Original_IdFile OR @Original_IdFile IS NULL AND IdFile IS NULL) AND (Origin = " & _
		"@Original_Origin) AND (ReasonCode = @Original_ReasonCode) AND (ReasonText = @Ori" & _
		"ginal_ReasonText); SELECT IdContratto, DataProgramma, PeriodoRilevante, CodiceUn" & _
		"itaSDC, CategoriaUnitaSDC, Origin, ReasonCode, ReasonText, IdFile FROM dbo.Progr" & _
		"ammaOrarioPerUnitaErrori WHERE (CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (Cod" & _
		"iceUnitaSDC = @CodiceUnitaSDC) AND (DataProgramma = @DataProgramma) AND (IdContr" & _
		"atto = @IdContratto) AND (PeriodoRilevante = @PeriodoRilevante)"
		Me.SqlUpdateCommand1.Connection = Me.cn
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Origin", System.Data.SqlDbType.VarChar, 2, "Origin"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonCode", System.Data.SqlDbType.VarChar, 15, "ReasonCode"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonText", System.Data.SqlDbType.VarChar, 1024, "ReasonText"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, "IdFile"))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Origin", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Origin", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReasonCode", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReasonCode", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReasonText", System.Data.SqlDbType.VarChar, 1024, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReasonText", System.Data.DataRowVersion.Original, Nothing))
		'
		'SqlDeleteCommand1
		'
		Me.SqlDeleteCommand1.CommandText = "DELETE FROM dbo.ProgrammaOrarioPerUnitaErrori WHERE (CategoriaUnitaSDC = @Origina" & _
		"l_CategoriaUnitaSDC) AND (CodiceUnitaSDC = @Original_CodiceUnitaSDC) AND (DataPr" & _
		"ogramma = @Original_DataProgramma) AND (IdContratto = @Original_IdContratto) AND" & _
		" (PeriodoRilevante = @Original_PeriodoRilevante) AND (IdFile = @Original_IdFile " & _
		"OR @Original_IdFile IS NULL AND IdFile IS NULL) AND (Origin = @Original_Origin) " & _
		"AND (ReasonCode = @Original_ReasonCode) AND (ReasonText = @Original_ReasonText)"
		Me.SqlDeleteCommand1.Connection = Me.cn
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataProgramma", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdContratto", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PeriodoRilevante", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Origin", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Origin", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReasonCode", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReasonCode", System.Data.DataRowVersion.Original, Nothing))
		Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReasonText", System.Data.SqlDbType.VarChar, 1024, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReasonText", System.Data.DataRowVersion.Original, Nothing))
		'
		'daPOUE
		'
		Me.daPOUE.DeleteCommand = Me.SqlDeleteCommand1
		Me.daPOUE.InsertCommand = Me.SqlInsertCommand1
		Me.daPOUE.SelectCommand = Me.SqlSelectCommand1
		Me.daPOUE.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "ProgrammaOrarioPerUnitaErrori", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"), New System.Data.Common.DataColumnMapping("DataProgramma", "DataProgramma"), New System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"), New System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"), New System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"), New System.Data.Common.DataColumnMapping("Origin", "Origin"), New System.Data.Common.DataColumnMapping("ReasonCode", "ReasonCode"), New System.Data.Common.DataColumnMapping("ReasonText", "ReasonText"), New System.Data.Common.DataColumnMapping("IdFile", "IdFile")})})
		Me.daPOUE.UpdateCommand = Me.SqlUpdateCommand1
		'
		'spGeneraOfferte
		'
		Me.spGeneraOfferte.CommandText = "dbo.[spGeneraOfferte]"
		Me.spGeneraOfferte.CommandType = System.Data.CommandType.StoredProcedure
		Me.spGeneraOfferte.Connection = Me.cn
		Me.spGeneraOfferte.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spGeneraOfferte.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataRicerca", System.Data.SqlDbType.DateTime, 8))
		Me.spGeneraOfferte.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OraRicerca", System.Data.SqlDbType.TinyInt, 1))

	End Sub

#End Region

	Class DataOra
		Public data As DateTime
		Public ora As Integer = -1
	End Class

	Public Sub GeneraEtInviaOfferteAsync(ByVal data As DateTime, ByVal runningOperator As String)
		smTrace(String.Format("genMGP: inizio generazione offerte del {0}", data))

		Dim dt As New DataOra
		dt.data = data
		dt.ora = -1		  ' tutte le ore

		BatchSerializer.BS.AddBatch(AddressOf Offerte.GeneraEtInviaOfferteWorkerAsync, dt, "OFF", "Generazione Offerte", data, runningOperator)

	End Sub

	Public Sub GeneraEtInviaOfferteAsync(ByVal data As DateTime, ByVal ora As Byte, ByVal runningOperator As String)
		smTrace(String.Format("genMGP: inizio generazione offerte del {0}", data))

		Dim dt As New DataOra
		dt.data = data
		dt.ora = ora

		BatchSerializer.BS.AddBatch(AddressOf Offerte.GeneraEtInviaOfferteWorkerAsync, dt, "OFF", "Generazione Offerte", data, runningOperator)

	End Sub

	' funzione chiamata quando si deve eseguire il batch
	Private Shared Sub GeneraEtInviaOfferteWorkerAsync(ByVal obj As Object)
		Dim data As DataOra = DirectCast(obj, DataOra)
		Dim offAsync As Offerte = New Offerte
		offAsync.GeneraEtInviaOfferteWorker(data)
		offAsync.Dispose()
	End Sub


#Region "Codice che legge le offerte dal DB e le spedisce al mercato"

	Private Sub GeneraEtInviaOfferteWorker(ByVal dt As DataOra)

		' NB. Lavoro senza transazioni --> con l'isolation level di default
		' ossia Read Committed
		' In questo modo:
		' 1) posso updatare subito SessioneBilaterali con Offerte=1
		' 2) la query per le offerte e` una select sola --> transazione implicita --> coerente al momento in cui si fa
		' 3) se va male qualche cosa metto SessioneBilaterali.Offerte=0
		'
		' Si suppone che SessioniBilaterali per quella data esista.

		Dim sGeneraOfferte As String = "GeneraOfferteQueryTmo"
		Dim generazioneOfferteFallita As Boolean = True

		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Try

				' dico a tutti che il sistema sta generando le offerte e che dovra` rileggere il mercato
				' (solo per la versione a 24 ore)
				If dt.ora = -1 Then
					Dim cmd As New SqlCommand("UPDATE SessioneBilaterali SET Offerte=1, LetturaMGP=0  WHERE DataProgramma = @d", cn)
					cmd.Parameters.Add("@d", dt.data)
					'
					' Query timeout 45 secondi (salvo non specificato diversamente)
					'
					cmd.CommandTimeout = AppSettingToInt32(sGeneraOfferte, 45)
					cmd.ExecuteNonQuery()
				End If

				' determino la prima e l'ultina ora da generare:
				' ci sono 2 problemi:
				' 1) questa funzione puo` essere chiamata per generare le offerte solo di un ora
				' 2) questa funzione puo` essere chiamata per generare le offerte di tutta la giornata
				'    e dunque devo determinare quante ore ha la giornata.
				Dim minh As Byte
				Dim maxh As Byte

				If dt.ora = -1 Then
					minh = 1
					maxh = MyBase.GetNumberOfHourOfDay(dt.data)
				Else
					minh = CType(dt.ora, Byte)
					maxh = CType(dt.ora, Byte)
				End If

				Dim firstException As Exception = Nothing

				For h As Byte = minh To maxh

					smTrace(String.Format("genMGP: inizio generazione offerte ora {0}", h))

					' genero le offerte per l'ora 'h'
					Dim nomeFileOut As String
					Dim by() As Byte = GeneraOfferteWorker(dt.data, h, nomeFileOut)
					If by Is Nothing Then
						smTrace(String.Format("genMGP: file XML ora {0} generato: nessuna offerta disponibile", h))
					Else
						smTrace(String.Format("genMGP: file XML ora {0} generato", h))

						If firstException Is Nothing Then
							smTrace("genMGP: upload del file delle offerte ora {0} al MGP", h)
							SmLog.smTrace("genMGP: GeneraEtInviaOfferte calling GME web server")
							Try
								' spedisco le offerte per l'ora 'h' al mercato
								Dim ws As New Bil.gmeBridge.BilMGPBridge
								ws.WSAuthHeaderValue = New Bil.gmeBridge.WSAuthHeader
								Bil_Crypt.WSClient.Setup(ws, ws.WSAuthHeaderValue.Username, ws.WSAuthHeaderValue.Password, "Bil_MGPBridgeWS")
								ws.UploadMessage(nomeFileOut, by)
								smTrace(String.Format("genMGP: upload ora {0} completato", h))
							Catch ex As Exception
								firstException = ex
							End Try
						End If

						' memorizzo le offerte appena spedite nel DB
						Try
							Dim blFileMGP As New Bil.FileMGP
							blFileMGP.InserisciFileMGP(Bil.FileMGP.VersoMGP.BilateraliAl_2_MGP, nomeFileOut, by, True, dt.data)
						Catch ex As Exception
							SmLog.smError(ex)
						End Try

						If firstException Is Nothing Then
							' aggiorno la situazione per questo batch
							smTrace("genMGP: fine generazione offerte ora {0}", h)
							BatchSerializer.SetProgressBatch(String.Format("genMGP: fine generazione offerte ora {0}", h))
						End If
					End If
				Next

				If firstException Is Nothing Then
					generazioneOfferteFallita = False
					smTrace("genMGP: attivita` completata")
				Else
					Throw firstException
				End If

			Catch ex As Exception
				ResettaSessioneBilaterali(cn, generazioneOfferteFallita, dt.ora, dt.data)
				smError(ex)
				smTrace("genMGP: attivita` generazione offerte fallita")
				Throw
			End Try

		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Sub

	Private Sub ResettaSessioneBilaterali(ByVal cn As SqlConnection, ByVal generazioneOfferteFallita As Boolean, ByVal ora As Integer, ByVal dt As DateTime)
		Try
			If (cn.State = ConnectionState.Open) Then
				If generazioneOfferteFallita AndAlso ora = -1 Then
					Dim cmd As New SqlCommand("UPDATE SessioneBilaterali SET Offerte=0, LetturaMGP=0 WHERE DataProgramma = @d", cn)
					cmd.Parameters.Add("@d", dt)
					cmd.ExecuteNonQuery()
				End If
			End If
		Catch ex As Exception
			smError(ex)
		End Try
	End Sub

	Private Function GeneraOfferteWorker(ByVal data As DateTime, ByVal ora As Byte, ByRef nomeFileOut As String) As Byte()
		' Questa funzione ritorna il file Xml se tutto e' andato bene
		' altrimenti il relativo messaggio di errore

		Dim e As System.Text.Encoding
		Dim ms As New MemoryStream
		Dim tw As New XmlTextWriter(ms, Encoding.GetEncoding("iso-8859-1"))		  ' genero le offerte direttamente con l'encoding giusto.

		Dim numeroOfferte As Integer = 0

		GeneraOfferteWorker(data, ora, tw, numeroOfferte)

		tw.Flush()
		tw.Close()

		' zippo il file delle offerte
		If numeroOfferte > 0 Then

			Dim by() As Byte = ms.ToArray()
			nomeFileOut = String.Format("BIL_OFFERTE_{0:yy}{0:MM}{0:dd}_{1}.in.xml", data, ora)
			Return BilZipLib.ZipSingleFile(nomeFileOut, by, 9)
		Else
			Return Nothing
		End If

	End Function

	Private Sub GeneraOfferteWorker(ByVal DataProgramma As DateTime, ByVal PeriodoRilevante As Byte, ByVal stream As XmlTextWriter, ByRef numeroOfferte As Integer)

		smTrace(String.Format("genMGP: ricerca nel DB delle offerte da generare"))
		Dim sGeneraOfferte As String = "GeneraOfferteQueryTmo"
		Dim ds As New DS_Offerte

		' Questa funzione ritorna "OK" se tutto e' andato bene 
		' altrimenti il relativo messaggio di errore
		Dim drOfferte As SqlDataReader

		Try
			Dim cmd As SqlCommand

			'' Le offerte sono lette ordinate per Data di programmazione/Posizione nel file
			'' Queste stored procedure fanno
			'' 1) cancellano tutte le righe di ProgrammaOrarioPerUnitaErrori della data/ora
			'' 2) mettono a null la QtyAssegnata e il GMEReferenceNumber
			'' 3) fanno la query
			'If GeneraOfferteSoloPerProgrammiBilanciati() Then
			'	cmd = Me.spGeneraOfferte_PgmBilanciati
			'	smTrace(String.Format("genMGP: offerte generate solo per i programmi bilanciati"))
			'Else
			'	cmd = Me.spGeneraOfferte_PgmNonBilanciati
			'	smTrace(String.Format("genMGP: offerte generate anche i programmi sbilanciati"))
			'End If

			cmd = Me.spGeneraOfferte


			' eseguo la query per ottenere le offerte dell'ora
			' Le offerte sono ordinate in modo che le prime sono quelle piu` vecchie a livello di
			' presentazione programmi
			cmd.Parameters("@DataRicerca").Value = DataProgramma
			cmd.Parameters("@OraRicerca").Value = PeriodoRilevante


			'
			' Setta query timeout 45 secondi (salvo non specificato diversamente)
			'
			cmd.CommandTimeout = AppSettingToInt32(sGeneraOfferte, 45)
			drOfferte = cmd.ExecuteReader()

			Dim listaUnitaTrattate As New System.Collections.Specialized.StringDictionary


			stream.Formatting = Formatting.Indented
			stream.IndentChar = "	"c
			stream.Indentation = 1
			stream.WriteStartDocument()

			stream.WriteStartElement("PIPEDocument")
			stream.WriteAttributeString("xmlns", "urn:XML-PIPE")
			stream.WriteAttributeString("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
			stream.WriteAttributeString("xsi:schemaLocation", "urn:XML-PIPE PIPEDocument.xsd")
			stream.WriteAttributeString("ReferenceNumber", GenReferenceNumber)
			stream.WriteAttributeString("CreationDate", GenCreationDate)
			stream.WriteAttributeString("Version", "1.0")

			stream.WriteStartElement("TradingPartnerDirectory")
			stream.WriteStartElement("Sender")
			stream.WriteStartElement("TradingPartner")
			stream.WriteAttributeString("PartnerType", "Market Participant")
			stream.WriteElementString("CompanyName", "GRTN Bilateralista")
			stream.WriteElementString("CompanyIdentifier", "IDGRTNBI")
			stream.WriteEndElement()
			stream.WriteEndElement()
			stream.WriteStartElement("Recipient")
			stream.WriteStartElement("TradingPartner")
			stream.WriteAttributeString("PartnerType", "Distributor")
			stream.WriteElementString("CompanyName", "GME")
			stream.WriteElementString("CompanyIdentifier", "IDGME")
			stream.WriteEndElement()
			stream.WriteEndElement()
			stream.WriteEndElement()

			Dim culture As CultureInfo = New CultureInfo("it-IT")
			' Lettura dei dati e relativa generazione del file Xml

			Dim colIdContratto As Integer = drOfferte.GetOrdinal("IdContratto")
			Dim colCodiceUnitaSDC As Integer = drOfferte.GetOrdinal("CodiceUnitaSDC")
			Dim colCategoriaUnitaSDC As Integer = drOfferte.GetOrdinal("CategoriaUnitaSDC")
			Dim colQtyMWh As Integer = drOfferte.GetOrdinal("QtyMWh")
			Dim colQtyMWhBilanciamento As Integer = drOfferte.GetOrdinal("QtyMWhBilanciamento")
			Dim colLastError As Integer = drOfferte.GetOrdinal("LastError")

			smTrace(String.Format("genMGP: lettura programmazioni dal DB"))

			numeroOfferte = 0

			While (drOfferte.Read())
				Dim IdContratto As Integer = drOfferte.GetInt32(colIdContratto)
				Dim CategoriaUnitaSDC As String = drOfferte.GetString(colCategoriaUnitaSDC)
				Dim CodiceUnitaSDC As String = drOfferte.GetString(colCodiceUnitaSDC)

				If (drOfferte.IsDBNull(colLastError) = False) Then
					' errore di validazione dell'offerta a causa di un certificato!!!!
					' inserisco l'errore in ProgrammaOrarioPerUnitaErrori
					Dim dr As DS_Offerte.ProgrammaOrarioPerUnitaErroriRow
					dr = ds.ProgrammaOrarioPerUnitaErrori.NewProgrammaOrarioPerUnitaErroriRow()

					dr.IdContratto = IdContratto
					dr.DataProgramma = DataProgramma
					dr.PeriodoRilevante = PeriodoRilevante
					dr.CodiceUnitaSDC = CodiceUnitaSDC
					dr.CategoriaUnitaSDC = CategoriaUnitaSDC
					dr.Origin = "CE"
					dr.SetIdFileNull()
					dr.ReasonCode = drOfferte.GetString(colLastError).Substring(0, 4)
					dr.ReasonText = drOfferte.GetString(colLastError).Substring(5)

					ds.ProgrammaOrarioPerUnitaErrori.AddProgrammaOrarioPerUnitaErroriRow(dr)
				Else
					' offerta valida

					' determino la quantita` da mandare a mercato
					Dim QtyMWh As Double
					If (drOfferte.IsDBNull(colQtyMWhBilanciamento)) Then
						QtyMWh = drOfferte.GetDouble(colQtyMWh)
					Else
						QtyMWh = drOfferte.GetDouble(colQtyMWhBilanciamento)
					End If

					' non genero le offerte con QtyMWh quasi ZERO
					' le offertre a quasi ZERO sono dovute al bilanciamento forzato.
					If Math.Abs(QtyMWh) > 0.00050000000000000001 Then

						numeroOfferte += 1

						stream.WriteStartElement("PIPTransaction")
						stream.WriteStartElement("BidSubmittal")

						If QtyMWh > 0 Then
							stream.WriteAttributeString("Purpose", "Sell")
						Else
							stream.WriteAttributeString("Purpose", "Buy")
						End If

						QtyMWh = Math.Abs(QtyMWh)

						Dim IdOffertaMGP As String = LetturaMercato.CreateIdOffertaMGP(DataProgramma, PeriodoRilevante, IdContratto, CategoriaUnitaSDC, CodiceUnitaSDC)

						stream.WriteAttributeString("MarketParticipantNumber", IdOffertaMGP)
						stream.WriteAttributeString("PredefinedOffer", "No")

						' ora la query ordina le offerte per "vecchiaia" --> devo gestire il ReplacementIndicator con una lista
						If Not listaUnitaTrattate.ContainsKey(CodiceUnitaSDC + CategoriaUnitaSDC) Then
							stream.WriteAttributeString("ReplacementIndicator", "Yes")
							listaUnitaTrattate.Add(CodiceUnitaSDC + CategoriaUnitaSDC, String.Empty)
						Else
							stream.WriteAttributeString("ReplacementIndicator", "No")
						End If


						stream.WriteElementString("Market", "MGP")
						stream.WriteElementString("Date", DataProgramma.ToString("yyyyMMdd"))
						stream.WriteElementString("Hour", PeriodoRilevante.ToString())
						stream.WriteElementString("UnitReferenceNumber", CodiceUnitaSDC)
						stream.WriteStartElement("BidQuantity")
						stream.WriteAttributeString("UnitOfMeasure", "MWh")
						stream.WriteString(Convert.ToString(QtyMWh, culture))
						stream.WriteEndElement()
						stream.WriteElementString("EnergyPrice", "0")
						stream.WriteEndElement()

						stream.WriteEndElement()
					End If
				End If

			End While

			If Not drOfferte Is Nothing Then
				drOfferte.Close()
				drOfferte = Nothing
			End If


			daPOUE.Update(ds.ProgrammaOrarioPerUnitaErrori)

			smTrace(String.Format("genMGP: lettura programmazioni dal DB completata"))

			stream.WriteEndDocument()
			stream.Flush()
		Catch ex As Exception
			smError(ex, "Errore su GeneraOfferte().")
			Throw
		Finally
			If (Not drOfferte Is Nothing) Then drOfferte.Close()
		End Try
	End Sub
#End Region

#Region "funzioni di utilita`"
	Private Function GenCreationDate() As String
		Dim t As DateTime
		Dim id As String

		t = DateTime.Now
		id = t.ToString("yyyyMMddHHmmss")

		GenCreationDate = id

	End Function
	Private Function GenReferenceNumber() As String
		Dim t As DateTime
		Dim id As String

		t = DateTime.Now
		id = t.ToString("yyyyMMddHHmmss") + t.Millisecond.ToString("d3")

		GenReferenceNumber = id

	End Function

	Public Function GeneraOfferteSoloPerIlGiornoDiDomani() As Boolean
		Return AppSettingToBoolean("GeneraOfferteSoloPerIlGiornoDiDomani")
	End Function
	Public Function GeneraOfferteSoloPerProgrammiBilanciati() As Boolean
		Return AppSettingToBoolean("GeneraOfferteSoloPerProgrammiBilanciati")
	End Function
#End Region



#Region "lista delle offerte NAB - usato da Bil_AdminWS "
	Public Function ListaOfferte(ByVal dataFlusso As DateTime, ByVal ora As Byte) As DataSet
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand("spListaOfferte", cn)
			cmd.CommandType = CommandType.StoredProcedure
			cmd.CommandTimeout = AppSettingToInt32("Offerte_ListaOfferte_QueryTmo", 60)
			cmd.Parameters.Add("@dataFlusso", dataFlusso)
			cmd.Parameters.Add("@ora", ora)

			Dim da As New SqlDataAdapter
			da.SelectCommand = cmd

			Dim ds As New DataSet("ListaOfferte")
			ds.Tables.Add(New DataTable("Offerta"))
			Dim dt As DataTable = ds.Tables(0)
			dt.Columns.Add(New DataColumn("IdOffertaNAB", GetType(String)))

			da.Fill(ds.Tables(0))

			For Each dr As DataRow In dt.Rows

				Dim idContratto As Integer
				Dim codiceUnitaSDC As String

				idContratto = DirectCast(dr("IdContratto"), Integer)
				codiceUnitaSDC = DirectCast(dr("CodiceUnitaSDC"), String)

				Dim idOfferta As String
				idOfferta = LetturaMercato.CreateIdOffertaMGP(dataFlusso, ora, idContratto, "F", codiceUnitaSDC)

				dr("IdOffertaNAB") = idOfferta
			Next

			dt.Columns.Remove("IdContratto")
			dt.Columns.Remove("CodiceUnitaSDC")

			Return ds

		Catch ex As Exception
			smError(ex)
			Throw
		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function
#End Region

End Class
