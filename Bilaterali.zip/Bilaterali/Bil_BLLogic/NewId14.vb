Imports System.Configuration
Imports System.Random
Imports System.Threading

Public Class NewId14
    Private Shared sNewId As String = Nothing

    Public Shared Function Generate() As String
        Dim newId As String
        SyncLock GetType(NewId14)
            If (sNewId Is Nothing) Then
                newId = String.Format("{0:yy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}{0:ff}", DateTime.Now)
            Else
                newId = String.Format("{0:yy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}{0:ff}", DateTime.Now)
                While (newId = sNewId)
                    Thread.Sleep(10)
                    newId = String.Format("{0:yy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}{0:ff}", DateTime.Now)
                End While
            End If
            sNewId = newId
        End SyncLock
        Return newId
    End Function

End Class
