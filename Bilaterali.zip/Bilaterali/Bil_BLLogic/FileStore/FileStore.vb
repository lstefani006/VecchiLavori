Imports System.Text
Imports System.Data.SqlClient

Public Class FileStore
    Inherits BilBLBase

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        cn.ConnectionString = GetConnectionString()
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents daFileIO As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdDelete As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdInsert As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdSelect As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdate_FA As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdUpdate_TSDownload As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdExtractFile As System.Data.SqlClient.SqlCommand

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.cmdDelete = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdate_FA = New System.Data.SqlClient.SqlCommand
		Me.cmdUpdate_TSDownload = New System.Data.SqlClient.SqlCommand
		Me.cmdInsert = New System.Data.SqlClient.SqlCommand
		Me.daFileIO = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSelect = New System.Data.SqlClient.SqlCommand
		Me._cmdExtractFile = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=BORDO;packet size=4096;user id=bil_user;data source=BILSVR1;persis" & _
		"t security info=False;initial catalog=Bilaterali_ROMA5"
		'
		'cmdDelete
		'
		Me.cmdDelete.CommandText = "DELETE FROM dbo.FileIO WHERE (DataCreazione = @DataCreazione) AND (IdFile = @IdFi" & _
		"le)"
		Me.cmdDelete.Connection = Me.cn
		Me.cmdDelete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataCreazione", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataCreazione", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdDelete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdUpdate_FA
		'
		Me.cmdUpdate_FA.CommandText = "UPDATE dbo.FileIO SET ContenutoFA = @ContenutoFA, ZippedFA = @ZippedFA WHERE (Dat" & _
		"aCreazione = @DataCreazione) AND (IdFile = @IdFile)"
		Me.cmdUpdate_FA.Connection = Me.cn
		Me.cmdUpdate_FA.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContenutoFA", System.Data.SqlDbType.VarBinary, 2147483647, "ContenutoFA"))
		Me.cmdUpdate_FA.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ZippedFA", System.Data.SqlDbType.Bit, 1, "ZippedFA"))
		Me.cmdUpdate_FA.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataCreazione", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataCreazione", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdate_FA.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdUpdate_TSDownload
		'
		Me.cmdUpdate_TSDownload.CommandText = "UPDATE dbo.FileIO SET TSDownload = COALESCE (@TSDownload, GETDATE()) WHERE (DataC" & _
		"reazione = @DataCreazione) AND (IdFile = @IdFile)"
		Me.cmdUpdate_TSDownload.Connection = Me.cn
		Me.cmdUpdate_TSDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSDownload", System.Data.SqlDbType.DateTime, 8, "TSDownload"))
		Me.cmdUpdate_TSDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataCreazione", System.Data.SqlDbType.SmallDateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DataCreazione", System.Data.DataRowVersion.Original, Nothing))
		Me.cmdUpdate_TSDownload.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
		'
		'cmdInsert
		'
		Me.cmdInsert.CommandText = "INSERT INTO FileIO (DataCreazione, TSInvio, InOut, CodiceOperatoreSDC, CodiceUten" & _
		"teSDC, CodiceTipoFile, NomeFile, DescrizioneFile, ContenutoFile, Zipped) VALUES " & _
		"(@DataCreazione, @TSInvio, @InOut, @CodiceOperatoreSDC, @CodiceUtenteSDC, @Codic" & _
		"eTipoFile, @NomeFile, @DescrizioneFile, @ContenutoFile, @Zipped); SELECT IdFile " & _
		"FROM FileIO WHERE DataCreazione = @DataCreazione AND IdFile = @@Identity"
		Me.cmdInsert.Connection = Me.cn
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataCreazione", System.Data.SqlDbType.DateTime, 4, "DataCreazione"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSInvio", System.Data.SqlDbType.DateTime, 8, "TSInvio"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@InOut", System.Data.SqlDbType.Bit, 1, "InOut"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceTipoFile", System.Data.SqlDbType.VarChar, 16, "CodiceTipoFile"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NomeFile", System.Data.SqlDbType.VarChar, 256, "NomeFile"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DescrizioneFile", System.Data.SqlDbType.VarChar, 256, "DescrizioneFile"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContenutoFile", System.Data.SqlDbType.VarBinary, 2147483647, "ContenutoFile"))
		Me.cmdInsert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Zipped", System.Data.SqlDbType.Bit, 1, "Zipped"))
		'
		'daFileIO
		'
		Me.daFileIO.DeleteCommand = Me.cmdDelete
		Me.daFileIO.InsertCommand = Me.cmdInsert
		Me.daFileIO.SelectCommand = Me.cmdSelect
		Me.daFileIO.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "dbo_spFileIO_Select", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("DataCreazione", "DataCreazione"), New System.Data.Common.DataColumnMapping("TSCreazione", "TSCreazione"), New System.Data.Common.DataColumnMapping("IdFile", "IdFile"), New System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"), New System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"), New System.Data.Common.DataColumnMapping("CodiceTipoFile", "CodiceTipoFile"), New System.Data.Common.DataColumnMapping("NomeFile", "NomeFile"), New System.Data.Common.DataColumnMapping("DescrizioneFile", "DescrizioneFile"), New System.Data.Common.DataColumnMapping("TSDownload", "TSDownload"), New System.Data.Common.DataColumnMapping("ContenutoFile", "ContenutoFile"), New System.Data.Common.DataColumnMapping("Zipped", "Zipped"), New System.Data.Common.DataColumnMapping("Encoding", "Encoding"), New System.Data.Common.DataColumnMapping("TSFlusso", "TSFlusso"), New System.Data.Common.DataColumnMapping("ContenutoFA", "ContenutoFA")})})
		'
		'cmdSelect
		'
		Me.cmdSelect.CommandText = "SELECT DataCreazione, IdFile, TSInvio, InOut, CodiceOperatoreSDC, CodiceUtenteSDC" & _
		", CodiceTipoFile, NomeFile, DescrizioneFile, TSDownload, Zipped, ContenutoFA, NU" & _
		"LL AS EsitoFA, ZippedFA FROM dbo.FileIO WHERE (InOut = COALESCE (@InOut, InOut))" & _
		" AND (CodiceOperatoreSDC = COALESCE (@CodiceOperatoreSDC, CodiceOperatoreSDC)) A" & _
		"ND (CodiceUtenteSDC = COALESCE (@CodiceUtenteSDC, CodiceUtenteSDC)) AND (CodiceT" & _
		"ipoFile = COALESCE (@CodiceTipoFile, CodiceTipoFile)) AND (NomeFile = COALESCE (" & _
		"@NomeFile, NomeFile)) AND (TSInvio >= COALESCE (@DataInizio, TSInvio)) AND (TSIn" & _
		"vio <= COALESCE (@DataFine, TSInvio))"
		Me.cmdSelect.Connection = Me.cn
		Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizio", System.Data.SqlDbType.DateTime, 4, "DataCreazione"))
		Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFine", System.Data.SqlDbType.DateTime, 4, "DataCreazione"))
		Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@InOut", System.Data.SqlDbType.Bit, 1, "InOut"))
		Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"))
		Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
		Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceTipoFile", System.Data.SqlDbType.VarChar, 16, "CodiceTipoFile"))
		Me.cmdSelect.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NomeFile", System.Data.SqlDbType.VarChar, 256, "NomeFile"))
		'
		'_cmdExtractFile
		'
		Me._cmdExtractFile.CommandText = "SELECT Zipped, Encoding, ContenutoFile FROM dbo.FileIO"
		Me._cmdExtractFile.Connection = Me.cn

	End Sub

#End Region
    <Serializable()> _
    Class InfoEvento
        'Public DataImport As DateTime      ' TSCreazione: data/ora di ricezione
        ' viene settata dal DB
        Public InOut As Boolean             ' True se Import/False se Export
        'Public DataCreazione As DateTime   ' data di ricezione del file da parte del sistema
        Public CodiceOperatoreSDC As String
        Public CodiceUtenteSDC As String
        Public CodiceTipoFile As String
        Public NomeFile As String
        Public DescrizioneFile As String
        Public Zipped As Boolean
        Public Encoding As String
        Public DataFlusso As DateTime
        Public ContenutoFile() As Byte
    End Class

    Public Function SelectFileIO(ByVal OutRows As Integer, ByVal DataInizio As DateTime, ByVal DataFine As DateTime, ByVal Stato As String, ByVal CodiceOperatoreSDC As String, ByVal CodiceUtenteSDC As String, ByVal CodiceTipoFile As String, ByVal NomeFile As String) As DS_FileStore

        Try


            cn.Open()

            Dim ds As New Bil.DS_FileStore
            Dim cmd As New SqlCommand
            cmd.Connection = cn
            cmd.CommandText = "SET ROWCOUNT " + OutRows.ToString
            cmd.ExecuteNonQuery()

            If DataInizio = DateTime.MinValue Then daFileIO.SelectCommand.Parameters("@DataInizio").Value = DBNull.Value Else daFileIO.SelectCommand.Parameters("@DataInizio").Value = DataInizio
            If DataFine = DateTime.MaxValue Then daFileIO.SelectCommand.Parameters("@DataFine").Value = DBNull.Value Else daFileIO.SelectCommand.Parameters("@DataFine").Value = DataFine
            daFileIO.SelectCommand.Parameters("@InOut").Value = DBNull.Value
            If CodiceOperatoreSDC = String.Empty Then daFileIO.SelectCommand.Parameters("@CodiceOperatoreSDC").Value = DBNull.Value Else daFileIO.SelectCommand.Parameters("@CodiceOperatoreSDC").Value = CodiceOperatoreSDC
            If CodiceUtenteSDC = String.Empty Then daFileIO.SelectCommand.Parameters("@CodiceUtenteSDC").Value = DBNull.Value Else daFileIO.SelectCommand.Parameters("@CodiceUtenteSDC").Value = CodiceUtenteSDC
            If CodiceTipoFile = String.Empty Then daFileIO.SelectCommand.Parameters("@CodiceTipoFile").Value = DBNull.Value Else daFileIO.SelectCommand.Parameters("@CodiceTipoFile").Value = CodiceTipoFile
            If NomeFile = String.Empty Then daFileIO.SelectCommand.Parameters("@NomeFile").Value = DBNull.Value Else daFileIO.SelectCommand.Parameters("@NomeFile").Value = NomeFile

            If Stato <> String.Empty Then
                If Stato = "0" Then
                    daFileIO.SelectCommand.CommandText += " AND TSDownload IS NULL"
                Else
                    daFileIO.SelectCommand.CommandText += " AND NOT TSDownload IS NULL"
                End If
            End If

			daFileIO.Fill(ds.FileStore)
			For Each dr As Bil.DS_FileStore.FileStoreRow In ds.FileStore
				If Not dr.IsContenutoFANull Then
					Dim Enc As New System.Text.UnicodeEncoding
					dr.Esito = Enc.GetString(dr.ContenutoFA)
					If dr.Esito.Length > 256 Then dr.Esito = dr.Esito.Substring(0, 256)
					dr.SetContenutoFANull()
				End If
			Next

			Return ds

		Catch ex As Exception
            smError(ex)
            Throw

        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try


    End Function

    Public Sub InsertFile(ByVal bInfoEvt As FileStore.InfoEvento, ByRef DataCreazione As DateTime, ByRef IdFile As Integer)

        Try

            cn.Open()

			cmdInsert.Connection = cn
			Dim TSCreazione As DateTime = DateTime.Now
			DataCreazione = DateTime.Now.Date
			cmdInsert.Parameters("@DataCreazione").Value = DataCreazione
			cmdInsert.Parameters("@TSInvio").Value = TSCreazione
            cmdInsert.Parameters("@InOut").Value = bInfoEvt.InOut
            cmdInsert.Parameters("@CodiceOperatoreSDC").Value = bInfoEvt.CodiceOperatoreSDC
            cmdInsert.Parameters("@CodiceUtenteSDC").Value = bInfoEvt.CodiceUtenteSDC
            cmdInsert.Parameters("@CodiceTipoFile").Value = bInfoEvt.CodiceTipoFile
            cmdInsert.Parameters("@NomeFile").Value = bInfoEvt.NomeFile
            cmdInsert.Parameters("@DescrizioneFile").Value = bInfoEvt.DescrizioneFile
            cmdInsert.Parameters("@Zipped").Value = bInfoEvt.Zipped
            Dim byz() As Byte
            If bInfoEvt.Zipped Then
                byz = BilZipLib.ZipSingleFile(bInfoEvt.NomeFile, bInfoEvt.ContenutoFile, 9)
            Else
                byz = bInfoEvt.ContenutoFile
            End If
            cmdInsert.Parameters("@ContenutoFile").Value = byz

            Dim rd As SqlClient.SqlDataReader
            Try
                rd = cmdInsert.ExecuteReader()
                If (rd.Read()) Then
                    IdFile = rd.GetInt32(0)
                Else
					smError("Impossibile inserire il contratto in FileIO")
                    Throw New Exception("Impossibile inserire il file in FileIO")
                End If
            Finally
                If (Not rd Is Nothing) Then rd.Close()
            End Try

        Catch ex As Exception
            smError(ex)
            Throw

        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try

    End Sub

    Public Sub UpdateTSDownloadFileIO(ByVal DataCreazione As DateTime, ByVal IdFile As String)

        Try

            cn.Open()
            cmdUpdate_TSDownload.Connection = cn
            cmdUpdate_TSDownload.Parameters("@DataCreazione").Value = DataCreazione
            cmdUpdate_TSDownload.Parameters("@IdFile").Value = IdFile
            cmdUpdate_TSDownload.Parameters("@TSDownload").Value = DBNull.Value

            cmdUpdate_TSDownload.ExecuteNonQuery()


        Catch ex As Exception
            smError(ex)
            Throw

        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Sub

    Public Sub UpdateFAFile(ByVal DataCreazione As DateTime, ByVal IdFile As Integer, ByVal ContenutoFA() As Byte)

        Try

            cn.Open()
            cmdUpdate_FA.Connection = cn
            cmdUpdate_FA.Parameters("@DataCreazione").Value = DataCreazione
            cmdUpdate_FA.Parameters("@IdFile").Value = IdFile
            cmdUpdate_FA.Parameters("@ZippedFA").Value = False

            Dim byz() As Byte
            If False Then
                byz = BilZipLib.ZipSingleFile("FA-" & IdFile.ToString, ContenutoFA, 9)
            Else
                byz = ContenutoFA
            End If

            cmdUpdate_FA.Parameters("@ContenutoFA").Value = byz


            cmdUpdate_FA.ExecuteNonQuery()


        Catch ex As Exception
            smError(ex)
            Throw

        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Sub
    Public Function GetBlobFile(ByVal dtFile As String, ByVal idFile As String, ByRef zipped As Boolean, ByRef fileEncoding As String) As Byte()
        Try

            cn.Open()

            zipped = True
            If Not (dtFile Is Nothing) AndAlso (dtFile <> String.Empty) Then
                Dim dt As DateTime = DateTime.ParseExact(dtFile, "yyyyMMddHHmm", Nothing)

                Dim c As StringBuilder = New StringBuilder
                c.Append(" WHERE DataCreazione = @DataCreazione ")

                If Not (idFile Is Nothing) AndAlso (idFile <> String.Empty) Then
                    c.Append(" AND IdFile = @IdFile ")
                    _cmdExtractFile.CommandText &= c.ToString()
                    Dim p0 As New SqlParameter("@DataCreazione", SqlDbType.SmallDateTime)
                    Dim p1 As New SqlParameter("@IdFile", SqlDbType.Int)
                    p0.Value = dt
                    p1.Value = Integer.Parse(idFile)
                    _cmdExtractFile.Parameters.Add(p0)
                    _cmdExtractFile.Parameters.Add(p1)
                End If
            End If

            Dim rd As SqlDataReader
            Try
                rd = _cmdExtractFile.ExecuteReader(CommandBehavior.SequentialAccess)
                Dim blobSize As Long
                Dim bufferSize As Integer = 100

                While rd.Read()
                    zipped = rd.GetBoolean(0)
                    If rd.IsDBNull(1) Then fileEncoding = "UTF-8" Else fileEncoding = rd.GetString(1)
                    blobSize = rd.GetBytes(2, 0, Nothing, 0, 100)
                    If (blobSize > 0) Then
                        Dim abyFA(CInt(blobSize) - 1) As Byte
                        Dim ret As Long
                        ret = rd.GetBytes(2, 0, abyFA, 0, CInt(blobSize))
                        Return abyFA
                    End If
                End While
            Finally
                If Not rd Is Nothing Then rd.Close() : rd = Nothing
            End Try

            Return Nothing
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Function
End Class
