Imports System
Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.Text
Imports System.Collections

Public Class SDCUtenti
    Inherits BilBLBase

    Public Function GetSDC_Utenti() As DS_SDC_Utenti
        cn.ConnectionString = GetConnectionString()
        Try
            cn.Open()

            Dim ds As New DS_SDC_Utenti
            daSDC_Utenti.Fill(ds.SDC_Utenti)

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw
        Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
    End Function

    Public Sub SalvaDataSet(ByVal ds As DS_SDC_Utenti)
        cn.ConnectionString = GetConnectionString()
        Dim tr As SqlTransaction = Nothing
        Try
            cn.Open()
            tr = cn.BeginTransaction()
            SetTransaction(daSDC_Utenti, tr)

            daSDC_Utenti.Update(ds.SDC_Utenti)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex)
			Throw
        Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents daSDC_Utenti As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.daSDC_Utenti = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=DAVINO;packet size=4096;user id=bil_dbo;data source=BILSVR1;persis" & _
        "t security info=False;initial catalog=Bilaterali"
        '
        'daSDC_Utenti
        '
        Me.daSDC_Utenti.DeleteCommand = Me.SqlDeleteCommand1
        Me.daSDC_Utenti.InsertCommand = Me.SqlInsertCommand1
        Me.daSDC_Utenti.SelectCommand = Me.SqlSelectCommand1
        Me.daSDC_Utenti.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "SDC_Utenti", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CodiceUtenteSDC", "CodiceUtenteSDC"), New System.Data.Common.DataColumnMapping("Nome", "Nome"), New System.Data.Common.DataColumnMapping("Cognome", "Cognome"), New System.Data.Common.DataColumnMapping("Telefono", "Telefono"), New System.Data.Common.DataColumnMapping("Fax", "Fax"), New System.Data.Common.DataColumnMapping("Email", "Email"), New System.Data.Common.DataColumnMapping("DN", "DN"), New System.Data.Common.DataColumnMapping("Abilitato", "Abilitato"), New System.Data.Common.DataColumnMapping("Login", "Login"), New System.Data.Common.DataColumnMapping("Pwd", "Pwd"), New System.Data.Common.DataColumnMapping("Lingua", "Lingua"), New System.Data.Common.DataColumnMapping("CodiceFiscale", "CodiceFiscale"), New System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"), New System.Data.Common.DataColumnMapping("ResponsabileAggiornamento", "ResponsabileAggiornamento"), New System.Data.Common.DataColumnMapping("Certificato", "Certificato"), New System.Data.Common.DataColumnMapping("CertificatoFirma", "CertificatoFirma")})})
        Me.daSDC_Utenti.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT CodiceUtenteSDC, Nome, Cognome, Telefono, Fax, Email, DN, Abilitato, Login" & _
        ", Pwd, Lingua, CodiceFiscale, TSModifica, ResponsabileAggiornamento, Certificato" & _
        ", CertificatoFirma FROM dbo.SDC_Utenti"
        Me.SqlSelectCommand1.Connection = Me.cn
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO dbo.SDC_Utenti(CodiceUtenteSDC, Nome, Cognome, Telefono, Fax, Email, " & _
        "DN, Abilitato, Login, Pwd, Lingua, CodiceFiscale, TSModifica, ResponsabileAggior" & _
        "namento, Certificato, CertificatoFirma) VALUES (@CodiceUtenteSDC, @Nome, @Cognom" & _
        "e, @Telefono, @Fax, @Email, @DN, @Abilitato, @Login, @Pwd, @Lingua, @CodiceFisca" & _
        "le, @TSModifica, @ResponsabileAggiornamento, @Certificato, @CertificatoFirma)"
        Me.SqlInsertCommand1.Connection = Me.cn
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Nome", System.Data.SqlDbType.VarChar, 256, "Nome"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Cognome", System.Data.SqlDbType.VarChar, 256, "Cognome"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Telefono", System.Data.SqlDbType.VarChar, 50, "Telefono"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.VarChar, 256, "Fax"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.VarChar, 256, "Email"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DN", System.Data.SqlDbType.VarChar, 1024, "DN"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Login", System.Data.SqlDbType.VarChar, 20, "Login"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Pwd", System.Data.SqlDbType.VarChar, 20, "Pwd"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Lingua", System.Data.SqlDbType.VarChar, 10, "Lingua"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceFiscale", System.Data.SqlDbType.VarChar, 16, "CodiceFiscale"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Certificato", System.Data.SqlDbType.VarBinary, 2147483647, "Certificato"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CertificatoFirma", System.Data.SqlDbType.VarBinary, 2147483647, "CertificatoFirma"))
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE dbo.SDC_Utenti SET CodiceUtenteSDC = @CodiceUtenteSDC, Nome = @Nome, Cogno" & _
        "me = @Cognome, Telefono = @Telefono, Fax = @Fax, Email = @Email, DN = @DN, Abili" & _
        "tato = @Abilitato, Login = @Login, Pwd = @Pwd, Lingua = @Lingua, CodiceFiscale =" & _
        " @CodiceFiscale, TSModifica = @TSModifica, ResponsabileAggiornamento = @Responsa" & _
        "bileAggiornamento, Certificato = @Certificato, CertificatoFirma = @CertificatoFi" & _
        "rma WHERE (CodiceUtenteSDC = @Original_CodiceUtenteSDC)"
        Me.SqlUpdateCommand1.Connection = Me.cn
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUtenteSDC"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Nome", System.Data.SqlDbType.VarChar, 256, "Nome"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Cognome", System.Data.SqlDbType.VarChar, 256, "Cognome"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Telefono", System.Data.SqlDbType.VarChar, 50, "Telefono"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.VarChar, 256, "Fax"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.VarChar, 256, "Email"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DN", System.Data.SqlDbType.VarChar, 1024, "DN"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Abilitato", System.Data.SqlDbType.Bit, 1, "Abilitato"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Login", System.Data.SqlDbType.VarChar, 20, "Login"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Pwd", System.Data.SqlDbType.VarChar, 20, "Pwd"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Lingua", System.Data.SqlDbType.VarChar, 10, "Lingua"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CodiceFiscale", System.Data.SqlDbType.VarChar, 16, "CodiceFiscale"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Certificato", System.Data.SqlDbType.VarBinary, 2147483647, "Certificato"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CertificatoFirma", System.Data.SqlDbType.VarBinary, 2147483647, "CertificatoFirma"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM dbo.SDC_Utenti WHERE (CodiceUtenteSDC = @Original_CodiceUtenteSDC)"
        Me.SqlDeleteCommand1.Connection = Me.cn
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CodiceUtenteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CodiceUtenteSDC", System.Data.DataRowVersion.Original, Nothing))

    End Sub

#End Region

End Class
