Imports System.Text
Imports System.Data.SqlClient

Public Class FileMGP
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents daFileMGP As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
	Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents daExtractFile As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents cmdExctractFile As System.Data.SqlClient.SqlCommand
    Friend WithEvents _cmdExtractFile As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.daFileMGP = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.daExtractFile = New System.Data.SqlClient.SqlDataAdapter
        Me.cmdExctractFile = New System.Data.SqlClient.SqlCommand
        Me._cmdExtractFile = New System.Data.SqlClient.SqlCommand
        '
        'cn
        '
        Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
        "st security info=False;initial catalog=Bilaterali"
        '
        'daFileMGP
        '
        Me.daFileMGP.DeleteCommand = Me.SqlDeleteCommand1
        Me.daFileMGP.InsertCommand = Me.SqlInsertCommand1
        Me.daFileMGP.SelectCommand = Me.SqlSelectCommand1
        Me.daFileMGP.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "FileMGP", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("IdFile", "IdFile"), New System.Data.Common.DataColumnMapping("TSCreazione", "TSCreazione"), New System.Data.Common.DataColumnMapping("ContenutoFile", "ContenutoFile"), New System.Data.Common.DataColumnMapping("VersoMGP", "VersoMGP"), New System.Data.Common.DataColumnMapping("Zippato", "Zippato"), New System.Data.Common.DataColumnMapping("TSFlusso", "TSFlusso")})})
        Me.daFileMGP.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM dbo.FileMGP WHERE (IdFile = @Original_IdFile)"
        Me.SqlDeleteCommand1.Connection = Me.cn
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO dbo.FileMGP(IdFile, TSCreazione, ContenutoFile, VersoMGP, Zippato, TS" & _
        "Flusso) VALUES (@IdFile, @TSCreazione, @ContenutoFile, @VersoMGP, @Zippato, @TSF" & _
        "lusso)"
        Me.SqlInsertCommand1.Connection = Me.cn
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, "IdFile"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSCreazione", System.Data.SqlDbType.DateTime, 8, "TSCreazione"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContenutoFile", System.Data.SqlDbType.VarBinary, 2147483647, "ContenutoFile"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@VersoMGP", System.Data.SqlDbType.Bit, 1, "VersoMGP"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Zippato", System.Data.SqlDbType.Bit, 1, "Zippato"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSFlusso", System.Data.SqlDbType.DateTime, 8, "TSFlusso"))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT IdFile, TSCreazione, ContenutoFile, VersoMGP, Zippato, TSFlusso FROM dbo.F" & _
        "ileMGP"
        Me.SqlSelectCommand1.Connection = Me.cn
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE dbo.FileMGP SET IdFile = @IdFile, TSCreazione = @TSCreazione, ContenutoFil" & _
        "e = @ContenutoFile, VersoMGP = @VersoMGP, Zippato = @Zippato, TSFlusso = @TSFlus" & _
        "so WHERE (IdFile = @Original_IdFile)"
        Me.SqlUpdateCommand1.Connection = Me.cn
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdFile", System.Data.SqlDbType.VarChar, 32, "IdFile"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSCreazione", System.Data.SqlDbType.DateTime, 8, "TSCreazione"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContenutoFile", System.Data.SqlDbType.VarBinary, 2147483647, "ContenutoFile"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@VersoMGP", System.Data.SqlDbType.Bit, 1, "VersoMGP"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Zippato", System.Data.SqlDbType.Bit, 1, "Zippato"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSFlusso", System.Data.SqlDbType.DateTime, 8, "TSFlusso"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_IdFile", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "IdFile", System.Data.DataRowVersion.Original, Nothing))
        '
        'daExtractFile
        '
        Me.daExtractFile.SelectCommand = Me.cmdExctractFile
        Me.daExtractFile.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "FileMGP", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("IdFile", "IdFile"), New System.Data.Common.DataColumnMapping("TSCreazione", "TSCreazione"), New System.Data.Common.DataColumnMapping("ContenutoFile", "ContenutoFile"), New System.Data.Common.DataColumnMapping("VersoMGP", "VersoMGP"), New System.Data.Common.DataColumnMapping("Zippato", "Zippato"), New System.Data.Common.DataColumnMapping("TSFlusso", "TSFlusso")})})
        '
        'cmdExctractFile
        '
        Me.cmdExctractFile.CommandText = "SELECT IdFile, TSCreazione, ContenutoFile, VersoMGP, Zippato, TSFlusso, NULL AS N" & _
        "omeFile FROM dbo.FileMGP"
        Me.cmdExctractFile.Connection = Me.cn
        '
        '_cmdExtractFile
        '
        Me._cmdExtractFile.CommandText = "SELECT Zippato, NULL AS Encoding, ContenutoFile FROM dbo.FileMGP"
        Me._cmdExtractFile.Connection = Me.cn

    End Sub

#End Region

	Public Enum VersoMGP
		BilateraliAl_2_MGP
		MGP_2_Bilaterali
	End Enum


	Public Function InserisciFileMGP(ByVal versoMGP As VersoMGP, ByVal nomeFile As String, ByVal by() As Byte, ByVal zippaIlFile As Boolean, ByVal dataFlusso As DateTime) As String

		Dim IdFileRet As String = ""
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim ds As New Bil.DS_FileMGP

			Dim dr As Bil.DS_FileMGP.FileMGPRow = ds.FileMGP.NewFileMGPRow

			dr.IdFile = CreateNewId()
			IdFileRet = dr.IdFile
			dr.TSCreazione = DateTime.Now()
			dr.VersoMGP = versoMGP = versoMGP.BilateraliAl_2_MGP
			dr.Zippato = True
			If dataFlusso = DateTime.MaxValue OrElse dataFlusso = DateTime.MinValue Then
				dr.SetTSFlussoNull()
			Else
				dr.TSFlusso = dataFlusso
			End If


			Dim byz() As Byte
			If zippaIlFile Then
				byz = BilZipLib.ZipSingleFile(nomeFile, by, 9)
			Else
				byz = by
			End If

			dr.ContenutoFile = byz

			ds.FileMGP.AddFileMGPRow(dr)

			daFileMGP.Update(ds.FileMGP)

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
		Return IdFileRet
	End Function


	Public Sub UpdateDataOraFileMGP(ByVal idFile As String, ByVal dataFlusso As DateTime)

		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			Dim cmd As New SqlCommand("update FileMGP set TSFlusso=@d where IdFile=@i", cn)
			cmd.Parameters.Add("@d", dataFlusso)
			cmd.Parameters.Add("@i", idFile)
			cmd.ExecuteNonQuery()

		Catch ex As Exception
			smError(ex)
			Throw

		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try
	End Sub

    Public Function SelectFileMGP(ByVal outRows As Integer, ByVal dataInizio As DateTime, ByVal dataFine As DateTime, ByVal VersoMGP As String, ByVal dataFlusso As DateTime) As Bil.DS_ExtractFile

        Try
            cn.ConnectionString = GetConnectionString()
            cn.Open()

            Dim cmd As New SqlCommand
            cmd.Connection = cn
            cmd.CommandText = "SET ROWCOUNT " + outRows.ToString
            cmd.ExecuteNonQuery()

            Dim ds As New DS_ExtractFile

            daExtractFile.SelectCommand.CommandText += " WHERE  (TSCreazione>= COALESCE (@DataInizio, TSCreazione)) AND (TSCreazione<= COALESCE (@DataFine, TSCreazione)) "
            daExtractFile.SelectCommand.CommandText += " AND (VersoMGP= COALESCE (@VersoMGP, VersoMGP)) AND (TSFlusso= COALESCE (@TSFlusso, TSFlusso)) "

            daExtractFile.SelectCommand.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataInizio", System.Data.SqlDbType.DateTime, 4))
            daExtractFile.SelectCommand.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFine", System.Data.SqlDbType.DateTime, 4))
            daExtractFile.SelectCommand.Parameters.Add(New System.Data.SqlClient.SqlParameter("@VersoMGP", System.Data.SqlDbType.Bit, 1))
            daExtractFile.SelectCommand.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TSFlusso", System.Data.SqlDbType.DateTime, 16))

            If dataInizio = DateTime.MinValue Then daExtractFile.SelectCommand.Parameters("@DataInizio").Value = DBNull.Value Else daExtractFile.SelectCommand.Parameters("@DataInizio").Value = dataInizio
            If dataFine = DateTime.MaxValue Then daExtractFile.SelectCommand.Parameters("@DataFine").Value = DBNull.Value Else daExtractFile.SelectCommand.Parameters("@DataFine").Value = dataFine

            Dim TipoFile As String = String.Empty
            If VersoMGP = String.Empty Then
                daExtractFile.SelectCommand.Parameters("@VersoMGP").Value = DBNull.Value
            Else
                If VersoMGP = "0" Then
                    daExtractFile.SelectCommand.Parameters("@VersoMGP").Value = False   ' da MGP a Bilaterali
                Else
                    If VersoMGP = "1" Then
                        daExtractFile.SelectCommand.Parameters("@VersoMGP").Value = True    ' da Bilaterali a MGP
                    Else
                        If VersoMGP.StartsWith("0_") Then
                            daExtractFile.SelectCommand.Parameters("@VersoMGP").Value = False   ' da MGP a Bilaterali
                            TipoFile = VersoMGP.Substring(2)
                        Else
                            ' VersoMGP.StartsWith("1_") = true
                            daExtractFile.SelectCommand.Parameters("@VersoMGP").Value = True   ' da Bilaterali a MGP
                            TipoFile = VersoMGP.Substring(2)
                        End If
                    End If
                End If
            End If

            If dataFlusso = DateTime.MinValue Then daExtractFile.SelectCommand.Parameters("@TSFlusso").Value = DBNull.Value Else daExtractFile.SelectCommand.Parameters("@TSFlusso").Value = dataFlusso

            daExtractFile.Fill(ds.FileMGP)

            Dim Unzipped() As Byte
            Dim path As String

            For Each dr As DS_ExtractFile.FileMGPRow In ds.FileMGP
                Unzipped = BilZipLib.UnzipSingleFile(dr.ContenutoFile, path)
                Dim i As Integer = path.LastIndexOf("\")
                If (i > 0) Then
                    dr.NomeFile = path.Substring(i + 1)
                Else
                    dr.NomeFile = path
                End If
                dr.SetContenutoFileNull()
                If TipoFile <> String.Empty Then
                    If Not dr.NomeFile.StartsWith(TipoFile) Then
                        dr.Delete()
                    End If
                End If
            Next

            Return ds

        Catch ex As Exception
            smError(ex)
            Throw

        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Function

    Public Function GetBlobFile(ByVal idFile As String, ByRef zipped As Boolean, ByRef fileEncoding As String) As Byte()
        Try
            cn.ConnectionString = GetConnectionString()
            cn.Open()

            zipped = True
            If Not (idFile Is Nothing) Then
                Dim c As StringBuilder = New StringBuilder
                c.Append(" WHERE IdFile = @IdFile ")

                _cmdExtractFile.CommandText &= c.ToString()

                Dim p0 As New SqlParameter("@IdFile", SqlDbType.VarChar)
                p0.Value = idFile
                _cmdExtractFile.Parameters.Add(p0)

            End If

            Dim rd As SqlDataReader
            Try
                rd = _cmdExtractFile.ExecuteReader(CommandBehavior.SequentialAccess)
                Dim blobSize As Long
                Dim bufferSize As Integer = 100

                While rd.Read()
                    zipped = rd.GetBoolean(0)
                    If rd.IsDBNull(1) Then fileEncoding = "UTF-8" Else fileEncoding = rd.GetString(1)
                    blobSize = rd.GetBytes(2, 0, Nothing, 0, 100)
                    If (blobSize > 0) Then
                        Dim abyFA(CInt(blobSize) - 1) As Byte
                        Dim ret As Long
                        ret = rd.GetBytes(2, 0, abyFA, 0, CInt(blobSize))
                        Return abyFA
                    End If
                End While
            Finally
                If Not rd Is Nothing Then rd.Close() : rd = Nothing
            End Try

            Return Nothing
        Catch ex As Exception
            smError(ex)
            Throw
        Finally
            If cn.State = ConnectionState.Open Then cn.Close()
        End Try
    End Function

End Class
