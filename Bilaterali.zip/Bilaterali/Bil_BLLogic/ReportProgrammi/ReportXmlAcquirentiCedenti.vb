Imports System.Data
Imports System.Text
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Xml
Imports System.Xml.Schema
Imports System.Configuration
Imports System.IO


Public Class ReportXmlAcquirentiCedenti
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents spReportXmlProgrammi As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdPrezzoZonale As System.Data.SqlClient.SqlCommand
	Friend WithEvents daPrezzoZonale As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdPrezzoUnico As System.Data.SqlClient.SqlCommand
	Friend WithEvents daPrezzoUnico As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents dsPrezzi As System.Data.DataSet
	Friend WithEvents PrezzoUnitario As System.Data.DataTable
	Friend WithEvents PrezzoZonale As System.Data.DataTable
	Friend WithEvents daSessioneBilaterali As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdSelectSessioneBilaterali As System.Data.SqlClient.SqlCommand
	Friend WithEvents spGetContrattiPerReportXmlProgrammi As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.spReportXmlProgrammi = New System.Data.SqlClient.SqlCommand
		Me.cmdPrezzoZonale = New System.Data.SqlClient.SqlCommand
		Me.daPrezzoZonale = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdPrezzoUnico = New System.Data.SqlClient.SqlCommand
		Me.daPrezzoUnico = New System.Data.SqlClient.SqlDataAdapter
		Me.dsPrezzi = New System.Data.DataSet
		Me.PrezzoUnitario = New System.Data.DataTable
		Me.PrezzoZonale = New System.Data.DataTable
		Me.daSessioneBilaterali = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSelectSessioneBilaterali = New System.Data.SqlClient.SqlCommand
		Me.spGetContrattiPerReportXmlProgrammi = New System.Data.SqlClient.SqlCommand
		CType(Me.dsPrezzi, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PrezzoUnitario, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PrezzoZonale, System.ComponentModel.ISupportInitialize).BeginInit()
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=True;initial catalog=BilateraliBig2;password=bilaterali"
		'
		'spReportXmlProgrammi
		'
		Me.spReportXmlProgrammi.CommandText = "dbo.[spReportXmlProgrammi]"
		Me.spReportXmlProgrammi.CommandType = System.Data.CommandType.StoredProcedure
		Me.spReportXmlProgrammi.Connection = Me.cn
		Me.spReportXmlProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spReportXmlProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		Me.spReportXmlProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int))
		'
		'cmdPrezzoZonale
		'
		Me.cmdPrezzoZonale.CommandText = "SELECT Data, CodiceZonaSDC, PeriodoRilevante, Prezzo FROM dbo.PrezzoZonale WHERE " & _
		"(Data = @DataProgramma)"
		Me.cmdPrezzoZonale.Connection = Me.cn
		Me.cmdPrezzoZonale.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8, "Data"))
		'
		'daPrezzoZonale
		'
		Me.daPrezzoZonale.SelectCommand = Me.cmdPrezzoZonale
		Me.daPrezzoZonale.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "PrezzoZonale", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Data", "Data"), New System.Data.Common.DataColumnMapping("CodiceZonaSDC", "CodiceZonaSDC"), New System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"), New System.Data.Common.DataColumnMapping("Prezzo", "Prezzo")})})
		'
		'cmdPrezzoUnico
		'
		Me.cmdPrezzoUnico.CommandText = "SELECT Data, PeriodoRilevante, Prezzo FROM dbo.PrezzoUnitario WHERE (Data = @Data" & _
		"Programma)"
		Me.cmdPrezzoUnico.Connection = Me.cn
		Me.cmdPrezzoUnico.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8, "Data"))
		'
		'daPrezzoUnico
		'
		Me.daPrezzoUnico.SelectCommand = Me.cmdPrezzoUnico
		Me.daPrezzoUnico.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "PrezzoUnitario", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Data", "Data"), New System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"), New System.Data.Common.DataColumnMapping("Prezzo", "Prezzo")})})
		'
		'dsPrezzi
		'
		Me.dsPrezzi.CaseSensitive = True
		Me.dsPrezzi.DataSetName = "NewDataSet"
		Me.dsPrezzi.Locale = New System.Globalization.CultureInfo("it-IT")
		Me.dsPrezzi.Tables.AddRange(New System.Data.DataTable() {Me.PrezzoUnitario, Me.PrezzoZonale})
		'
		'PrezzoUnitario
		'
		Me.PrezzoUnitario.TableName = "PrezzoUnitario"
		'
		'PrezzoZonale
		'
		Me.PrezzoZonale.TableName = "PrezzoZonale"
		'
		'daSessioneBilaterali
		'
		Me.daSessioneBilaterali.SelectCommand = Me.cmdSelectSessioneBilaterali
		Me.daSessioneBilaterali.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "SessioneBilaterali", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Bilanciamento", "Bilanciamento"), New System.Data.Common.DataColumnMapping("Taglio", "Taglio"), New System.Data.Common.DataColumnMapping("Offerte", "Offerte"), New System.Data.Common.DataColumnMapping("LetturaMGP", "LetturaMGP"), New System.Data.Common.DataColumnMapping("DataProgramma", "DataProgramma")})})
		'
		'cmdSelectSessioneBilaterali
		'
		Me.cmdSelectSessioneBilaterali.CommandText = "SELECT Bilanciamento, Taglio, Offerte, LetturaMGP, CASE WHEN DataChiusuraMGP IS N" & _
		"ULL THEN 0 ELSE 1 END AS ChiusuraMGP, DataProgramma FROM dbo.SessioneBilaterali " & _
		"WHERE (DataProgramma = @DataProgramma)"
		Me.cmdSelectSessioneBilaterali.Connection = Me.cn
		Me.cmdSelectSessioneBilaterali.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"))
		'
		'spGetContrattiPerReportXmlProgrammi
		'
		Me.spGetContrattiPerReportXmlProgrammi.CommandText = "dbo.[spGetContrattiPerReportXmlProgrammi]"
		Me.spGetContrattiPerReportXmlProgrammi.CommandType = System.Data.CommandType.StoredProcedure
		Me.spGetContrattiPerReportXmlProgrammi.Connection = Me.cn
		Me.spGetContrattiPerReportXmlProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spGetContrattiPerReportXmlProgrammi.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 8))
		CType(Me.dsPrezzi, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PrezzoUnitario, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PrezzoZonale, System.ComponentModel.ISupportInitialize).EndInit()

	End Sub

#End Region

	Private dsSessioneBilaterali As DS_SessioneBilaterali

	Private _unitaConsumoEstere As New Specialized.StringCollection

	Class RawDataFactory
		Public col_PeriodoRilevante As Integer
		Public col_IdContratto As Integer
		Public col_CRN As Integer
		Public col_CodiceOperatoreSDCAcquirente As Integer
		Public col_CodiceOperatoreSDCCedente As Integer
		Public col_CodiceUnitaSDC As Integer
		Public col_CategoriaUnitaSDC As Integer
		Public col_TipoUnita As Integer
		Public col_UnitaAssegnataOpAcquirente As Integer
		Public col_UnitaAssegnataOpCedente As Integer
		Public col_CodicePuntoDiScambioRilevanteSDC As Integer
		Public col_CodiceZonaSDC As Integer
		Public col_POIdContratto As Integer
		Public col_Bilanciato As Integer
		Public col_ProgrammaOrarioValidato As Integer
		Public col_SbilanciamentoMWh As Integer
		Public col_SbilanciamentoMWhReale As Integer
		Public col_POUIdContratto As Integer
		Public col_QtyMWh As Integer
		Public col_QtyMWhBilanciamento As Integer
		Public col_QtyMWhAssegnataMGP As Integer
		Public col_ProgOrarioDellUnitaValidato As Integer
		Public col_ProgrammatoDalCedente As Integer
		Public col_IdProgrammaXml As Integer
		Public col_Origin As Integer
		Public col_ReasonCode As Integer
		Public col_ReasonText As Integer
		Public col_KU As Integer
		Public col_KP As Integer

		Public Sub StoreCol(ByVal dr As SqlDataReader)
			col_PeriodoRilevante = dr.GetOrdinal("PeriodoRilevante")
			col_IdContratto = dr.GetOrdinal("IdContratto")
			col_CRN = dr.GetOrdinal("CRN")
			col_CodiceOperatoreSDCAcquirente = dr.GetOrdinal("CodiceOperatoreSDCAcquirente")
			col_CodiceOperatoreSDCCedente = dr.GetOrdinal("CodiceOperatoreSDCCedente")
			col_CodiceUnitaSDC = dr.GetOrdinal("CodiceUnitaSDC")
			col_CategoriaUnitaSDC = dr.GetOrdinal("CategoriaUnitaSDC")
			col_TipoUnita = dr.GetOrdinal("TipoUnita")
			col_UnitaAssegnataOpAcquirente = dr.GetOrdinal("UnitaAssegnataOpAcquirente")
			col_UnitaAssegnataOpCedente = dr.GetOrdinal("UnitaAssegnataOpCedente")
			col_CodicePuntoDiScambioRilevanteSDC = dr.GetOrdinal("CodicePuntoDiScambioRilevanteSDC")
			col_CodiceZonaSDC = dr.GetOrdinal("CodiceZonaSDC")
			col_POIdContratto = dr.GetOrdinal("POIdContratto")
			col_Bilanciato = dr.GetOrdinal("Bilanciato")
			col_ProgrammaOrarioValidato = dr.GetOrdinal("ProgrammaOrarioValidato")
			col_SbilanciamentoMWh = dr.GetOrdinal("SbilanciamentoMWh")
			col_SbilanciamentoMWhReale = dr.GetOrdinal("SbilanciamentoMWhReale")
			col_POUIdContratto = dr.GetOrdinal("POUIdContratto")
			col_QtyMWh = dr.GetOrdinal("QtyMWh")
			col_QtyMWhBilanciamento = dr.GetOrdinal("QtyMWhBilanciamento")
			col_QtyMWhAssegnataMGP = dr.GetOrdinal("QtyMWhAssegnataMGP")
			col_ProgOrarioDellUnitaValidato = dr.GetOrdinal("ProgOrarioDellUnitaValidato")
			col_ProgrammatoDalCedente = dr.GetOrdinal("ProgrammatoDalCedente")
			col_IdProgrammaXml = dr.GetOrdinal("IdProgrammaXml")
			col_Origin = dr.GetOrdinal("Origin")
			col_ReasonCode = dr.GetOrdinal("ReasonCode")
			col_ReasonText = dr.GetOrdinal("ReasonText")
			col_KU = dr.GetOrdinal("KU")
			col_KP = dr.GetOrdinal("KP")
		End Sub

		Public Function Create() As RawData
			Dim r As RawData
			If f.Count > 0 Then
				r = DirectCast(f.Dequeue(), RawData)
				r.EOF = True
			Else
				r = New RawData
			End If

			Return r
		End Function


		Public Sub Release(ByVal r As RawData)
			f.Enqueue(r)
		End Sub

		Public Sub Release(ByVal c As ICollection)
			For Each r As RawData In c
				f.Enqueue(r)
			Next
		End Sub

		Public Function ReadData(ByVal dr As SqlDataReader) As RawData
			Dim r As RawData = Create()

			r.EOF = Not dr.Read()
			If r.EOF Then Return r

			r.PeriodoRilevante = dr.GetSqlByte(col_PeriodoRilevante)

			r.IdContratto = dr.GetSqlInt32(col_IdContratto)
			r.CRN = dr.GetSqlString(col_CRN)
			r.CodiceOperatoreSDCAcquirente = dr.GetSqlString(col_CodiceOperatoreSDCAcquirente)
			r.CodiceOperatoreSDCCedente = dr.GetSqlString(col_CodiceOperatoreSDCCedente)
			r.CodiceUnitaSDC = dr.GetSqlString(col_CodiceUnitaSDC)
			r.CategoriaUnitaSDC = dr.GetSqlString(col_CategoriaUnitaSDC)
			r.TipoUnita = dr.GetSqlString(col_TipoUnita)
			r.UnitaAssegnataOpAcquirente = dr.GetSqlBoolean(col_UnitaAssegnataOpAcquirente)
			r.UnitaAssegnataOpCedente = dr.GetSqlBoolean(col_UnitaAssegnataOpCedente)
			r.CodicePuntoDiScambioRilevanteSDC = dr.GetSqlString(col_CodicePuntoDiScambioRilevanteSDC)
			r.CodiceZonaSDC = dr.GetSqlString(col_CodiceZonaSDC)

			r.POIdContratto = dr.GetSqlInt32(col_POIdContratto)
			r.Bilanciato = dr.GetSqlBoolean(col_Bilanciato)
			r.ProgrammaOrarioValidato = dr.GetSqlBoolean(col_ProgrammaOrarioValidato)
			r.SbilanciamentoMWh = dr.GetSqlDouble(col_SbilanciamentoMWh)
			r.SbilanciamentoMWhReale = dr.GetSqlDouble(col_SbilanciamentoMWhReale)

			r.POUIdContratto = dr.GetSqlInt32(col_POUIdContratto)
			r.QtyMWh = dr.GetSqlDouble(col_QtyMWh)
			r.QtyMWhBilanciamento = dr.GetSqlDouble(col_QtyMWhBilanciamento)
			r.QtyMWhAssegnataMGP = dr.GetSqlDouble(col_QtyMWhAssegnataMGP)
			r.ProgOrarioDellUnitaValidato = dr.GetSqlBoolean(col_ProgOrarioDellUnitaValidato)
			r.ProgrammatoDalCedente = dr.GetSqlBoolean(col_ProgrammatoDalCedente)
			r.IdProgrammaXml = dr.GetSqlInt32(col_IdProgrammaXml)

			r.Origin = dr.GetSqlString(col_Origin)
			r.ReasonCode = dr.GetSqlString(col_ReasonCode)
			r.ReasonText = dr.GetSqlString(col_ReasonText)

			r.KU = dr.GetSqlDouble(col_KU)
			r.KP = dr.GetSqlDouble(col_KP)

			Return r
		End Function

		Private f As Queue = New Queue

	End Class

	Class RawData
		Public EOF As Boolean = True

		Public PeriodoRilevante As SqlByte
		Public IdContratto As SqlInt32
		Public CRN As SqlString
		Public CodiceOperatoreSDCAcquirente As SqlString
		Public CodiceOperatoreSDCCedente As SqlString
		Public CodiceUnitaSDC As SqlString
		Public CategoriaUnitaSDC As SqlString
		Public TipoUnita As SqlString
		Public UnitaAssegnataOpAcquirente As SqlBoolean
		Public UnitaAssegnataOpCedente As SqlBoolean
		Public CodicePuntoDiScambioRilevanteSDC As SqlString
		Public CodiceZonaSDC As SqlString
		Public POIdContratto As SqlInt32
		Public Bilanciato As SqlBoolean
		Public ProgrammaOrarioValidato As SqlBoolean
		Public SbilanciamentoMWh As SqlDouble
		Public SbilanciamentoMWhReale As SqlDouble
		Public POUIdContratto As SqlInt32
		Public QtyMWh As SqlDouble
		Public QtyMWhBilanciamento As SqlDouble
		Public QtyMWhAssegnataMGP As SqlDouble
		Public ProgOrarioDellUnitaValidato As SqlBoolean
		Public ProgrammatoDalCedente As SqlBoolean
		Public IdProgrammaXml As SqlInt32
		Public Origin As SqlString
		Public ReasonCode As SqlString
		Public ReasonText As SqlString
		Public KU As SqlDouble
		Public KP As SqlDouble
	End Class


	Public Sub CreaReportOperatoriAcqCedBatch(ByVal dataProgramma As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf CreaReportOperatoriAcqCedAsync, dataProgramma, "PGM", "Creazione file XML Programmi", dataProgramma, runningOperator)

	End Sub

	Private Shared Sub CreaReportOperatoriAcqCedAsync(ByVal dataProgramma As Object)
		Dim bl As New ReportXmlAcquirentiCedenti
		bl.CreaReportOperatoriAcqCed(CType(dataProgramma, DateTime))
		bl.Dispose()
	End Sub


	Private Sub CreaReportOperatoriAcqCed(ByVal dataProgramma As DateTime)

		Dim sReportXmlAcquirentiCedentiQueryTmo As String = "ReportXmlAcquirentiCedentiQueryTmo"
		smTrace(String.Format("Generazione report PGM: inizio elaborazione - data={0:dd/MM/yyy}", dataProgramma))

		Dim tr As SqlTransaction = Nothing
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()


			' e` da decidere se usare la transazione
			' tr = cn.BeginTransaction(IsolationLevel.ReadCommitted)

			dsSessioneBilaterali = New DS_SessioneBilaterali
			daSessioneBilaterali.SelectCommand.Parameters("@DataProgramma").Value = dataProgramma
			daSessioneBilaterali.SelectCommand.Transaction = tr
			'
			' set query timeout a 45 secondi salvo non specificato diversamente
			'
			daSessioneBilaterali.SelectCommand.CommandTimeout = AppSettingToInt32(sReportXmlAcquirentiCedentiQueryTmo, 45)

			daSessioneBilaterali.Fill(dsSessioneBilaterali.SessioneBilaterali)

			daPrezzoUnico.SelectCommand.Parameters("@DataProgramma").Value = dataProgramma
			daPrezzoZonale.SelectCommand.Parameters("@DataProgramma").Value = dataProgramma
			daPrezzoUnico.SelectCommand.Transaction = tr
			daPrezzoZonale.SelectCommand.Transaction = tr
			'
			' set query timeout a 45 secondi salvo non specificato diversamente
			'
			daPrezzoUnico.SelectCommand.CommandTimeout = AppSettingToInt32(sReportXmlAcquirentiCedentiQueryTmo, 45)
			'
			' set query timeout a 45 secondi salvo non specificato diversamente
			'
			daPrezzoZonale.SelectCommand.CommandTimeout = AppSettingToInt32(sReportXmlAcquirentiCedentiQueryTmo, 45)

			daPrezzoUnico.Fill(dsPrezzi, "PrezzoUnitario")
			daPrezzoZonale.Fill(dsPrezzi, "PrezzoZonale")

			CaricaUnitaConsumoEstere(cn)

			CreaReportOperatoriAcqCed(cn, tr, dataProgramma)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			smTrace(String.Format("Generazione report PGM: elaborazione terminata con successo - data={0:dd/MM/yyy}", dataProgramma))

		Catch ex As Exception
			smError(ex, "Generazione report PGM")
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Sub

	Private Function GetListaContratti(ByVal dataFlusso As DateTime, ByVal tr As SqlTransaction) As ArrayList

		spGetContrattiPerReportXmlProgrammi.Parameters("@DataProgramma").Value = dataFlusso
		spGetContrattiPerReportXmlProgrammi.Connection = Me.cn
		spGetContrattiPerReportXmlProgrammi.Transaction = tr

		Dim rd As SqlDataReader = Nothing

		Try
			rd = spGetContrattiPerReportXmlProgrammi.ExecuteReader()

			Dim r As New ArrayList

			While rd.Read()
				r.Add(rd.GetSqlInt32(0).Value)
			End While

			Return r

		Catch ex As Exception
			smError(ex, "PGM - GetListaContratti")
			Throw
		Finally
			If Not rd Is Nothing Then
				rd.Close()
			End If
		End Try

	End Function

	Private Sub CreaReportOperatoriAcqCed(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal dataProgramma As DateTime)

		Dim listaIdContratto As ArrayList = GetListaContratti(dataProgramma, tr)

		For Each IdContratto As Integer In listaIdContratto
			CreaReportOperatoriAcqCed(cn, tr, dataProgramma, IdContratto)
		Next

	End Sub

	Private Sub CreaReportOperatoriAcqCed(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal dataProgramma As DateTime, ByVal IdContratto As Int32)

		spReportXmlProgrammi.Parameters("@DataProgramma").Value = dataProgramma
		spReportXmlProgrammi.Parameters("@IdContratto").Value = IdContratto
		spReportXmlProgrammi.Connection = cn
		spReportXmlProgrammi.Transaction = tr

		'
		' set query timeout a 45 secondi salvo non specificato diversamente
		'
		Dim sReportXmlAcquirentiCedentiQueryTmo As String = "ReportXmlAcquirentiCedentiQueryTmo"
		spReportXmlProgrammi.CommandTimeout = AppSettingToInt32(sReportXmlAcquirentiCedentiQueryTmo, 45)
		Dim dr As SqlDataReader = Nothing
		dr = spReportXmlProgrammi.ExecuteReader()

		' questa si occupa di
		' 1) creare i RawData cercando di riclicare le vecchie istanzie non piu` utilizzate
		' 2) memorizzare la posizione delle col_XYZ della query
		' 3) valorizzare i RawData con il prossimo record del DB
		Dim rf As New RawDataFactory

		Try
			rf.StoreCol(dr)


			Dim msAcq As MemoryStream
			Dim msCed As MemoryStream
			Dim xwAcq As XmlTextWriter
			Dim xwCed As XmlTextWriter

			Dim tsCreazione As DateTime = DateTime.Now()

			' lettura del dato corrente
			Dim rCurr As RawData
			Dim rNext As RawData

			' lettura corrente e lettura anticipata
			rCurr = rf.ReadData(dr)
			If rCurr.EOF Then Return
			rNext = rf.ReadData(dr)


			' qui ho sicuramente un rCurr valido (prima di eseguire il loop)
			Dim recordStessoCRN As New ArrayList


			' accorpo i record che hanno stesso CRN,Data.
			' poi, quando mi accorgo della rottura sul prossimo record,
			' elaboro i gruppo per generare i report.
			Do
				' qui ho il rCurr sicuramente valido (che punta ad un record valorizzato)
				' rNext puo` invece puntare a EOF o ad un record valido.
				recordStessoCRN.Add(rCurr)


				Dim raggruppamentoFinito As Boolean = False

				If rNext.EOF Then
					raggruppamentoFinito = True

				ElseIf rNext.CRN.Value <> rCurr.CRN.Value Then
					raggruppamentoFinito = True

				End If

				If raggruppamentoFinito Then
					' qui si elabora l'accorpamento
					ElaboraAccorpamento(tr, dataProgramma, tsCreazione, recordStessoCRN, msAcq, msCed, xwAcq, xwCed)

					rf.Release(recordStessoCRN)					  ' qui tutto quello che ho allocato lo rimando alla factory.
					recordStessoCRN.Clear()					  ' svuoto la collezione del raggruppamento
				End If

				If rNext.EOF Then
					Exit Do
				End If

				' porto avanti il cursore.
				rCurr = rNext
				rNext = rf.ReadData(dr)

			Loop

		Finally
			If Not dr Is Nothing Then dr.Close()
		End Try

	End Sub


	Private Sub ElaboraAccorpamento( _
	ByVal tr As SqlTransaction, _
	ByVal dataProgramma As DateTime, _
	ByVal tsCreazione As DateTime, _
	ByVal recordStessoCRN As ArrayList, _
	ByVal msAcq As MemoryStream, _
	ByVal msCed As MemoryStream, _
	ByVal xwAcq As XmlTextWriter, _
	ByVal xwCed As XmlTextWriter)


		Dim SbilAlClearingPoint(25) As Double		  ' per calcolare lo sbilancio a valle dell'MGP
		Dim SbilAlClearingPointDisponibile(25) As Boolean		  ' indica se lo sbilancio per quell'ora e` disponibile.
		Dim CedOraCreata(25) As Boolean		 ' indica se per il cedente l'ora e` stata gia` descritta nel report
		Dim AcqOraCreata(25) As Boolean		 ' indica se per l'acquirente l'ora e` stata gia` descritta nel report

		For i As Integer = 1 To 25
			SbilAlClearingPoint(i) = 0
			SbilAlClearingPointDisponibile(i) = False

			CedOraCreata(i) = False			 ' non ho scritto ancora nessun tag CRNDataOra ossia BilProgram
			AcqOraCreata(i) = False
		Next

		' calcolo lo sbilanciamento per tutte le ore
		For Each r As RawData In recordStessoCRN
			' qui calcolo lo sbilanciamento al clearing point 
			' nel caso sia girato il mercato.
			If Not r.QtyMWhAssegnataMGP.IsNull Then
				SbilAlClearingPointDisponibile(r.PeriodoRilevante.Value) = True
				SbilAlClearingPoint(r.PeriodoRilevante.Value) += Math.Round(r.QtyMWhAssegnataMGP.Value * r.KP.Value / r.KU.Value, 3)
			End If
		Next



		Dim rCurr As RawData
		Dim rNext As RawData

		' consumo  recordStessoCRNDataOra
		If recordStessoCRN.Count >= 1 Then
			rCurr = DirectCast(recordStessoCRN(0), RawData)
			rNext = Nothing
			If recordStessoCRN.Count >= 2 Then rNext = DirectCast(recordStessoCRN(1), RawData)
		End If


		' se sono qui rCurr punta ad un record valido
		' dunque posso creare i report.
		Dim bAcqCedCoincidenti As Boolean = True

		CreaReport(msAcq, xwAcq, tsCreazione, rCurr, dataProgramma)
		If (rCurr.CodiceOperatoreSDCAcquirente.Value <> rCurr.CodiceOperatoreSDCCedente.Value) Then
			bAcqCedCoincidenti = False
			CreaReport(msCed, xwCed, tsCreazione, rCurr, dataProgramma)
		End If

		' guardo leggendo la configurazione, a chi e` destinata la quantita` di sbilancio al clearing point dopo l'MGP
		Dim generaSbilCed As Boolean
		Dim generaSbilAcq As Boolean
		If True Then
			Dim generaSbilMGPPer As String = AppSettingToString("Pgm_ScriviSbilancioMGP_Per", "OperatoreAcquirente")
			If generaSbilMGPPer = "OperatoreCedente" Then
				generaSbilCed = True
				generaSbilAcq = False
			ElseIf generaSbilMGPPer = "OperatoreAcquirente" Then
				generaSbilCed = False
				generaSbilAcq = True
			ElseIf generaSbilMGPPer = "Entrambi" Then
				generaSbilCed = True
				generaSbilAcq = True
			End If
		End If


		Dim iCurr As Integer = 0
		Do
			' qui per comodita` uso sempre il concetto di lettura anticipata (anche se sono dentro un normale array)

			If Not rCurr.UnitaAssegnataOpAcquirente.IsNull Then
				' se passo di qui significa che o l'acq o il ced o entrambi hanno programmato almeno
				' una volta il contratto per questa data / ora.
				' E` possibile che esistano record solo per l'acquirente o solo per il cedente o per entrambi.
				If bAcqCedCoincidenti = False Then
					If rCurr.UnitaAssegnataOpAcquirente.Value Then WriteItem(AcqOraCreata, xwAcq, rCurr, dataProgramma, SbilAlClearingPointDisponibile(rCurr.PeriodoRilevante.Value), SbilAlClearingPoint(rCurr.PeriodoRilevante.Value), generaSbilAcq)
					If rCurr.UnitaAssegnataOpCedente.Value Then WriteItem(CedOraCreata, xwCed, rCurr, dataProgramma, SbilAlClearingPointDisponibile(rCurr.PeriodoRilevante.Value), SbilAlClearingPoint(rCurr.PeriodoRilevante.Value), generaSbilCed)
				Else
					WriteItem(AcqOraCreata, xwAcq, rCurr, dataProgramma, SbilAlClearingPointDisponibile(rCurr.PeriodoRilevante.Value), SbilAlClearingPoint(rCurr.PeriodoRilevante.Value), generaSbilAcq)
				End If

			End If


			If rNext Is Nothing Then
				' ho finito il CRN (e dunque l'ultima ora)
				' e' possibile che per questa ultima ora o il ced o l'acq o entrambi non abbiano
				' fatto programmazione: guardo nell'array xyzdOraCreata per caprire se devo creare 
				' un'ora vuota
				If CedOraCreata(rCurr.PeriodoRilevante.Value) = False Then
					CreaCRNDataOraVuoto(xwCed, rCurr.CRN.Value, dataProgramma, rCurr.PeriodoRilevante.Value)
					CedOraCreata(rCurr.PeriodoRilevante.Value) = True
				End If
				If AcqOraCreata(rCurr.PeriodoRilevante.Value) = False Then
					CreaCRNDataOraVuoto(xwAcq, rCurr.CRN.Value, dataProgramma, rCurr.PeriodoRilevante.Value)
					AcqOraCreata(rCurr.PeriodoRilevante.Value) = True
				End If

				' non c'e` il prossimo record --> chiudo ed esco
				ChiudiCRNDataOra(AcqOraCreata, xwAcq, rCurr)
				ChiudiCRNDataOra(CedOraCreata, xwCed, rCurr)

				ChiudiReport(msAcq, xwAcq, tr, rCurr.CodiceOperatoreSDCAcquirente.Value, rCurr, dataProgramma, tsCreazione)
				ChiudiReport(msCed, xwCed, tr, rCurr.CodiceOperatoreSDCCedente.Value, rCurr, dataProgramma, tsCreazione)

				Exit Do

			ElseIf rNext.CRN.Value <> rCurr.CRN.Value Then
				Debug.Assert(False)

			ElseIf rNext.PeriodoRilevante.Value <> rCurr.PeriodoRilevante.Value Then
				' al prossimo si cambia il periodo rilevante --> chiudo il tag e ne creo un altro

				' al prossimo si cambia ora 
				' e' possibile che per questa ora o il ced o l'acq o entrambi non abbiano
				' fatto programmazione: guardo nell'array xyzdOraCreata per caprire se devo creare 
				' un'ora vuota

				If CedOraCreata(rCurr.PeriodoRilevante.Value) = False Then
					CreaCRNDataOraVuoto(xwCed, rCurr.CRN.Value, dataProgramma, rCurr.PeriodoRilevante.Value)
					CedOraCreata(rCurr.PeriodoRilevante.Value) = True
				End If
				If AcqOraCreata(rCurr.PeriodoRilevante.Value) = False Then
					CreaCRNDataOraVuoto(xwAcq, rCurr.CRN.Value, dataProgramma, rCurr.PeriodoRilevante.Value)
					AcqOraCreata(rCurr.PeriodoRilevante.Value) = True
				End If

				' qui chiudo il tag solo se e` il caso
				ChiudiCRNDataOra(AcqOraCreata, xwAcq, rCurr)
				ChiudiCRNDataOra(CedOraCreata, xwCed, rCurr)

			End If



			rCurr = rNext
			iCurr += 1
			Dim iNext As Integer = iCurr + 1

			If iNext < recordStessoCRN.Count Then
				rNext = DirectCast(recordStessoCRN(iNext), RawData)
			Else
				rNext = Nothing
			End If

		Loop

		' qui potrebbe succedere che 



	End Sub


	Private Sub CreaReport(ByRef ms As MemoryStream, ByRef xw As XmlTextWriter, ByVal tsCreazioneReport As DateTime, ByVal r As RawData, ByVal DataProgramma As DateTime)
		ms = New MemoryStream
		xw = New XmlTextWriter(ms, Encoding.UTF8)

		xw.Formatting = Formatting.Indented
		xw.IndentChar = "	"c
		xw.Indentation = 1

		xw.WriteStartDocument()

		xw.WriteStartElement("BilPrograms")
		xw.WriteAttributeString("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")

		' cambio lo schema per gli xml in italiano ;-)
		If BilBLBase.XmlITA Then
			xw.WriteAttributeString("xsi:noNamespaceSchemaLocation", "BilDailyProgramsC.xsd")
		Else
			xw.WriteAttributeString("xsi:noNamespaceSchemaLocation", "BilDailyPrograms.xsd")
		End If
		xw.WriteAttributeString("CreationDate", XmlDateTime(tsCreazioneReport, BilBLBase.XmlDateTimeInfo))
		xw.WriteAttributeString("Version", "1.0")

	End Sub

	Private Sub CreaCRNDataOra(ByVal xw As XmlTextWriter, ByVal r As RawData, ByVal DataProgramma As DateTime, ByVal SbilAlClearingPointDisponibile As Boolean, ByVal SbilAlClearingPoint As Double, ByVal generaSbil As Boolean)

		If xw Is Nothing Then Return

		xw.WriteStartElement("BilProgram")

		xw.WriteAttributeString("CRN", r.CRN.Value)
		xw.WriteAttributeString("Date", XmlDate(DataProgramma, BilBLBase.XmlDateTimeInfo))		   ' xw.WriteAttributeString("Date", XmlConvert.ToString(DataProgramma, "yyyy-MM-dd"))
		xw.WriteAttributeString("Hour", XmlConvert.ToString(r.PeriodoRilevante.Value))

		If r Is Nothing OrElse r.POIdContratto.IsNull Then
			xw.WriteAttributeString("Status", "ProgramNotSent")

		ElseIf (r.ProgrammaOrarioValidato.Value) Then
			xw.WriteAttributeString("Status", "ProgramAccepted")

			If SbilAlClearingPointDisponibile AndAlso generaSbil Then
				xw.WriteAttributeString("QtyMWhSbilMGP", XmlQtyMWh(SbilAlClearingPoint, BilBLBase.XmlNumberInfo))
			End If

		Else
			xw.WriteAttributeString("Status", "ProgramRefused")
		End If


	End Sub

	Private Sub CreaCRNDataOraVuoto(ByVal xw As XmlTextWriter, ByVal CRN As String, ByVal DataProgramma As DateTime, ByVal periodoRilevante As Integer)

		If xw Is Nothing Then Return

		xw.WriteStartElement("BilProgram")

		xw.WriteAttributeString("CRN", CRN)
		xw.WriteAttributeString("Date", XmlDate(DataProgramma, BilBLBase.XmlDateTimeInfo))		   ' xw.WriteAttributeString("Date", XmlConvert.ToString(DataProgramma, "yyyy-MM-dd"))
		xw.WriteAttributeString("Hour", XmlConvert.ToString(periodoRilevante))

		xw.WriteAttributeString("Status", "ProgramNotSent")

	End Sub



	Private Sub WriteItem(ByRef OraCreata() As Boolean, ByVal xw As XmlTextWriter, ByVal r As RawData, ByVal DataProgramma As DateTime, ByVal SbilAlClearingPointDisponibile As Boolean, ByVal SbilAlClearingPoint As Double, ByVal generaSbil As Boolean)

		If (xw Is Nothing) Then Return ' dipende dal CRN





		If OraCreata(r.PeriodoRilevante.Value) = False Then
			CreaCRNDataOra(xw, r, DataProgramma, SbilAlClearingPointDisponibile, SbilAlClearingPoint, generaSbil)
			OraCreata(r.PeriodoRilevante.Value) = True
		End If

		If (Not r.POUIdContratto.IsNull) Then		  'LEO fatto per ovviare al problemino dei report vuoti!!

			xw.WriteStartElement("Unit")
			xw.WriteAttributeString("URN", r.CodiceUnitaSDC.Value)
			xw.WriteAttributeString("Type", r.TipoUnita.Value)
			xw.WriteAttributeString("CodeZone", r.CodiceZonaSDC.Value)

			If (r.POUIdContratto.IsNull) Then
				xw.WriteAttributeString("Status", "ProgramNotSent")
			ElseIf (r.ProgOrarioDellUnitaValidato.Value) Then
				xw.WriteAttributeString("Status", "ProgramAccepted")
			Else
				xw.WriteAttributeString("Status", "ProgramRefused")
			End If

			If (Not r.POUIdContratto.IsNull) Then
				' se sono qui significa che c'e` stata programmazione
				' per questa unita`
				xw.WriteAttributeString("IdProgrammaXml", XmlConvert.ToString(r.IdProgrammaXml.Value))

				xw.WriteAttributeString("QtyMWh", XmlQtyMWh(r.QtyMWh.Value, BilBLBase.XmlNumberInfo))

				' qui controllo se e` stato eseguito il bilanciamento forzato
				Dim bTaglio As Boolean = False
				If (dsSessioneBilaterali.SessioneBilaterali.Count = 1) Then
					bTaglio = dsSessioneBilaterali.SessioneBilaterali(0).Taglio
				End If

				' controllo se questo programma e` bilanciato
				' questo e` valorizzato se e` stato effettuato il controllo di bil, o il bil forzato.
				' 
				If Not r.Bilanciato.IsNull Then
					' qui puo` essere 0 non bilanciato 1 bilanciato. --> 
					' pero` il bilanciamento e` stato effettuato (controllo o forzamento del bilanciamento)
					'
					' un contratto prima del calcolo del bilanciamento ha PO.Bilanciato=NULL e PO.SbilanciamentoMWh=NULL
					' un contratto dopo il calcolo del bilanciamento se bilanciato in origine ha PO.Bilanciato=1 e PO.SbilanciamentoMWh=0
					' un contratto non bilanciato in origine e prima dell'operazione di taglio ha PO.Bilanciato=0 e PO.SbilanciamentoMWh<>0
					' un contratto non bilanciato in origine e dopo l'operazione di taglio ha PO.Bilanciato=1 e PO.SbilanciamentoMWh<>0

					' se e` stato effettuato il bilanciamento forzato lo so solo andando in SessioneBilaterali
					If bTaglio Then
						' e` stato effettuato un bilanciamento forzato.
						' Questo contratto o era bilanciato in origine o e` stato bilanciato in maniera forzata

						If (Not r.QtyMWhBilanciamento.IsNull) Then
							' l'unita` corrente e` stata bilanciata in modo forzato
							xw.WriteAttributeString("QtyBalancedMWh", XmlQtyMWh(r.QtyMWhBilanciamento.Value, BilBLBase.XmlNumberInfo))
						Else
							' non c'e` QtyMWhBilanciamento 
							' il bilanciamento forzato e` stato fatto ma NON ha "colpito" questa unita
							' prendo la quantita` originale
							xw.WriteAttributeString("QtyBalancedMWh", XmlQtyMWh(r.QtyMWh.Value, BilBLBase.XmlNumberInfo))
						End If

					End If
				End If
			End If

			If (Not r.Origin.IsNull) Then
				Debug.Assert(Not r.POUIdContratto.IsNull)
				xw.WriteAttributeString("ErrorOrigin", r.Origin.Value)
				xw.WriteAttributeString("ErrorCode", r.ReasonCode.Value)
				xw.WriteAttributeString("ErrorText", r.ReasonText.Value)
			End If


			If (Not r.QtyMWhAssegnataMGP.IsNull) Then

				xw.WriteAttributeString("QtyMGPMWh", XmlQtyMWh(r.QtyMWhAssegnataMGP.Value, BilBLBase.XmlNumberInfo))

				' LEO TODO ATTENZIONE WARNING PERICOLO
				' LE UNITA` ESTERE di CONSUMO pagano SEMPRE al prezzo ZONALE.
				' QUI e` sbagliato.

				Dim prezzo As Decimal = 0

				Select Case r.TipoUnita.Value
					Case "C"
						' chi consuma paga il prezzo unico
						' o il prezzo zonale se unita di consumo estere
						Debug.Assert(r.QtyMWhAssegnataMGP.Value <= 0)


						If _unitaConsumoEstere.Contains(r.CodiceUnitaSDC.Value) Then

							prezzo = Me.GetPrezzoZonale(r.CodiceZonaSDC.Value, r.PeriodoRilevante.Value)

							'xw.WriteAttributeString("PriceMWh", XmlPrezzoZonale(prezzo, BilBLBase.XmlNumberInfo))

							'For i As Integer = 0 To dsPrezzi.Tables("PrezzoZonale").Rows.Count - 1
							'	Dim drPrezzoZonale As DataRow = dsPrezzi.Tables("PrezzoZonale").Rows(i)
							'	If (CType(drPrezzoZonale("CodiceZonaSDC"), String) = r.CodiceZonaSDC.Value AndAlso CType(drPrezzoZonale("PeriodoRilevante"), Byte) = r.PeriodoRilevante.Value) Then
							'		xw.WriteAttributeString("PriceMWh", XmlPrezzoZonale(CType(drPrezzoZonale("Prezzo"), Decimal), BilBLBase.XmlNumberInfo))
							'	End If
							'Next

						Else
							prezzo = Me.GetPrezzoUnico(r.PeriodoRilevante.Value)

							'For i As Integer = 0 To dsPrezzi.Tables("PrezzoUnitario").Rows.Count - 1
							'	Dim drPrezzoUnico As DataRow = dsPrezzi.Tables("PrezzoUnitario").Rows(i)
							'	If (CType(drPrezzoUnico("PeriodoRilevante"), Byte) = r.PeriodoRilevante.Value) Then
							'		xw.WriteAttributeString("PriceMWh", XmlPrezzoUnico(CType(drPrezzoUnico("Prezzo"), Decimal), BilBLBase.XmlNumberInfo))
							'	End If
							'Next

						End If

					Case "P", "M"

						prezzo = Me.GetPrezzoZonale(r.CodiceZonaSDC.Value, r.PeriodoRilevante.Value)
						'' chi produce guadagna il prezzo zonale
						'' nelle unita` miste si paga/guadagna il prezzo zonale
						'For i As Integer = 0 To dsPrezzi.Tables("PrezzoZonale").Rows.Count - 1
						'	Dim drPrezzoZonale As DataRow = dsPrezzi.Tables("PrezzoZonale").Rows(i)
						'	If (CType(drPrezzoZonale("CodiceZonaSDC"), String) = r.CodiceZonaSDC.Value AndAlso CType(drPrezzoZonale("PeriodoRilevante"), Byte) = r.PeriodoRilevante.Value) Then
						'		xw.WriteAttributeString("PriceMWh", XmlPrezzoZonale(CType(drPrezzoZonale("Prezzo"), Decimal), BilBLBase.XmlNumberInfo))
						'	End If
						'Next

					Case Else
						Debug.Assert(False)
				End Select
				xw.WriteAttributeString("PriceMWh", XmlPrezzoZonale(prezzo, BilBLBase.XmlNumberInfo))

			End If

			xw.WriteEndElement()			 ' Unit
		End If

	End Sub

	Private Function GetPrezzoZonale(ByVal CodiceZonaSDC As String, ByVal PeriodoRilevante As Byte) As Decimal
		For i As Integer = 0 To dsPrezzi.Tables("PrezzoZonale").Rows.Count - 1

			Dim drPrezzoZonale As DataRow = dsPrezzi.Tables("PrezzoZonale").Rows(i)

			If (CType(drPrezzoZonale("CodiceZonaSDC"), String) = CodiceZonaSDC AndAlso _
			 CType(drPrezzoZonale("PeriodoRilevante"), Byte) = PeriodoRilevante) Then
				Return CType(drPrezzoZonale("Prezzo"), Decimal)
			End If
		Next
		Return 0
	End Function
	Private Function GetPrezzoUnico(ByVal PeriodoRilevante As Byte) As Decimal
		For i As Integer = 0 To dsPrezzi.Tables("PrezzoUnitario").Rows.Count - 1
			Dim drPrezzoUnico As DataRow = dsPrezzi.Tables("PrezzoUnitario").Rows(i)
			If CType(drPrezzoUnico("PeriodoRilevante"), Byte) = PeriodoRilevante Then
				Return CType(drPrezzoUnico("Prezzo"), Decimal)
			End If
		Next
		Return 0
	End Function


	Private Sub ChiudiCRNDataOra(ByRef CRNDatOraCreato() As Boolean, ByVal xw As XmlTextWriter, ByVal r As RawData)
		If xw Is Nothing Then Return

		If CRNDatOraCreato(r.PeriodoRilevante.Value) = True Then
			xw.WriteEndElement()			 ' BilProgram
		End If
	End Sub

	Private Sub ChiudiReport(ByRef ms As MemoryStream, ByRef xw As XmlTextWriter, ByVal tr As SqlTransaction, ByVal codiceOperatore As String, ByVal r As RawData, ByVal dataProgramma As DateTime, ByVal dataCreazione As DateTime)
		If xw Is Nothing Then Return

		xw.WriteEndElement()		  ' BilPrograms
		xw.WriteEndDocument()
		xw.Flush()
		xw.Close()

		Dim descrizioneFile As String
		descrizioneFile = String.Format("Report programmi del contratto '{0}' del {1:d}", r.CRN.Value, dataProgramma)

		Dim tipoFile As String = "PGM"

		Dim nomefile As String
		nomefile = String.Format("{0}_{1:yy}{1:MM}{1:dd}{1:HH}{1:mm}{1:ss}", tipoFile, dataCreazione)
		nomefile += String.Format("_{0:yy}{0:MM}{0:dd}_{1}.xml", dataProgramma, r.CRN.Value)

		BilBLBase.MemorizzaFilePerOperatore(Nothing, Nothing, codiceOperatore, nomefile, tipoFile, descrizioneFile, ms.ToArray(), DateTime.Now(), "utf-8", dataProgramma)

		xw = Nothing
		ms = Nothing
	End Sub


	Private Sub CaricaUnitaConsumoEstere(ByVal cn As SqlConnection)

		Dim cmd As SqlCommand = cn.CreateCommand
		cmd.CommandType = CommandType.StoredProcedure
		cmd.CommandText = "[dbo].[spUnitaConsumoEstere]"

		' _unitaConsumoEstere e` una StringCollection
		' La StringCollection ammette duplicati
		' ma la query NON deve ritornate duplicati


		Dim rd As SqlDataReader
		Try
			rd = cmd.ExecuteReader

			While rd.Read
				Dim u As String = rd.GetString(0)
				Debug.Assert(_unitaConsumoEstere.Contains(u) = False)
				_unitaConsumoEstere.Add(u)
			End While
		Finally
			If Not rd Is Nothing Then
				rd.Close()
				rd = Nothing
			End If
			cmd.Dispose()
		End Try

	End Sub


End Class
