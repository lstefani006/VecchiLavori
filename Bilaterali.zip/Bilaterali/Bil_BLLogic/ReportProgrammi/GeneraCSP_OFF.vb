Imports System.Data
Imports System.Text
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Xml
Imports System.Xml.Schema
Imports System.Configuration
Imports System.IO
Imports System.Xml.Serialization
Imports System.Globalization
Imports System.Threading

Public Class GeneraCSP_OFF
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=False;initial catalog=Bilaterali;password=bilaterali"

	End Sub

#End Region

	' questa classe genera il file OFF verso la fatturazione
	' per creare fatture per l'importo dovuto agli operatori acquirente ipex quando
	' c'e` uno sbilancio di P>C
	' l'importo e` Pun*DeltaQ

	Public Function CreateCSP_OFFAsync(ByVal dataRicercaMin As DateTime, ByVal dataRicercaMax As DateTime) As String
		Dim bd As New BatchData
		bd.dataRicercaMin = dataRicercaMin
		bd.dataRicercaMax = dataRicercaMax

		' BatchSerializer.BS.AddBatch(AddressOf Me.CreateCSP_OFFAsync, bd, "CSP_OFF", String.Format("Generazione file XML corrispettivi dal {0:d} al {1:d}", dataRicercaMin, dataRicercaMax), DateTime.MinValue)
		ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf CreateCSP_OFFAsync), bd)

		Dim nomefile As String
		Dim tipoFile As String = "CSP_OFF"
		nomefile = String.Format("{0}_{1:yyyy}{1:MM}{1:dd}_{2:yyyy}{2:MM}{2:dd}_<operatore>.xml", tipoFile, dataRicercaMin, dataRicercaMax)
		Return tipoFile

	End Function

	Class BatchData
		Public dataRicercaMin As DateTime
		Public dataRicercaMax As DateTime
	End Class


	Private Shared Sub CreateCSP_OFFAsync(ByVal o As Object)
		Dim bl As New GeneraCSP_OFF
		Dim bd As BatchData = DirectCast(o, BatchData)
		bl.CreateCSP_OFF(bd.dataRicercaMin, bd.dataRicercaMax)
	End Sub

	Public Sub CreateCSP_OFF(ByVal dataRicercaMin As DateTime, ByVal dataRicercaMax As DateTime)
		Try
			cn.ConnectionString = Me.GetConnectionString()
			cn.Open()

			CreaReportCSP(dataRicercaMin, dataRicercaMax, cn)

		Catch ex As Exception
			smTrace(ex, String.Format("Generazione Corrispettivi: elaborazione fallita"))
			Throw

		Finally
			cn.Dispose()
		End Try

	End Sub



#Region "Classi per l'accesso ai dati"
	Class RowColData
		Public ReadOnly col_OpAcqIpex As Integer
		Public ReadOnly col_CRN As Integer
		Public ReadOnly col_DataProgramma As Integer
		Public ReadOnly col_PeriodoRilevante As Integer
		Public ReadOnly col_QuantitaVendute As Integer
		Public ReadOnly col_ControvaloreEuro As Integer
		Public ReadOnly col_PrezzoUnico As Integer


		Public Sub New(ByVal dr As SqlDataReader)
			col_OpAcqIpex = dr.GetOrdinal("OpAcqIpex")
			col_CRN = dr.GetOrdinal("CRN")
			col_DataProgramma = dr.GetOrdinal("DataProgramma")
			col_PeriodoRilevante = dr.GetOrdinal("PeriodoRilevante")
			col_QuantitaVendute = dr.GetOrdinal("QuantitaVendute")
			col_ControvaloreEuro = dr.GetOrdinal("ControvaloreEuro")
			col_PrezzoUnico = dr.GetOrdinal("PrezzoUnico")
		End Sub
	End Class
	Class RowData

		Public Sub New()
			EOF = True
		End Sub


		Public Sub New(ByVal c As RowColData)
			Me.c = c
			EOF = True
		End Sub


		Private ReadOnly c As RowColData

		Public EOF As Boolean = True

		Public OpAcqIpex As SqlString
		Public CRN As SqlString
		Public DataProgramma As SqlDateTime
		Public PeriodoRilevante As SqlByte
		Public QuantitaVendute As SqlDecimal
		Public ControvaloreEuro As SqlDecimal
		Public PrezzoUnico As SqlDecimal


		Public Sub ReadData(ByVal dr As SqlDataReader)
			If dr.Read() = False Then
				EOF = True
				Return
			End If

			EOF = False

			OpAcqIpex = dr.GetSqlString(c.col_OpAcqIpex)
			CRN = dr.GetSqlString(c.col_CRN)
			DataProgramma = dr.GetSqlDateTime(c.col_DataProgramma)
			PeriodoRilevante = dr.GetSqlByte(c.col_PeriodoRilevante)
			QuantitaVendute = dr.GetSqlDecimal(c.col_QuantitaVendute)
			ControvaloreEuro = dr.GetSqlDecimal(c.col_ControvaloreEuro)
			PrezzoUnico = dr.GetSqlDecimal(c.col_PrezzoUnico)

		End Sub

	End Class
#End Region

	Class CSP

		Private f As Fattura
		Private fla As ArrayList
		Private g As CultureInfo = New CultureInfo("IT-it")
		Private TotaleCorr As Decimal = 0
		Private TotaleQuantity As Decimal = 0

		Public ReadOnly Property Fattura() As Fattura
			Get
				Return f
			End Get
		End Property

		Public Sub New(ByVal codeOpFrom As String, ByVal codeOpTo As String, ByVal taxCode As String, ByVal dataMin As DateTime, ByVal dataMax As DateTime, ByVal idGme As String)
			f = New Fattura

			If codeOpFrom = idGme Then
				f.DOCUMENT = "F"
			Else
				f.DOCUMENT = "C"
			End If

			f.DOCUMENT_ID = (DateTime.Now.Ticks Mod (1000 * 1000 * 1000)).ToString("000000000000000")

			' abbiamo sempre un solo header fattura
			f.HeaderFattura = New FatturaHeaderFattura
			f.HeaderFattura.ABP_ID = f.DOCUMENT_ID
			f.HeaderFattura.ACCOUNT_NUMBER = (DateTime.Now.Ticks Mod (1000 * 1000)).ToString("000000")
			f.HeaderFattura.DOCUMENT_DATE = dataMax.ToString("yyyyMMdd")
			f.HeaderFattura.DOCUMENT_TYPE = "BE"			 ' FB obolo

			If codeOpFrom = idGme Then
				f.HeaderFattura.TRX_TYPE = "BID"				  ' GME --> Op --> op paga --> GME e` attivo --> BID
			Else
				f.HeaderFattura.TRX_TYPE = "OFF"				  ' Op --> GME --> GME paga --> GME e` passivo --> OFF
			End If

			' decisione storica: si prende l'ultima data
			f.HeaderFattura.PERIOD = dataMax.ToString("MMyyyy")

			f.HeaderFattura.TAX_REFERENCE_FROM = ""
			f.HeaderFattura.OP_NAME_FROM = ""
			f.HeaderFattura.SDC_CODE_FROM = codeOpFrom
			f.HeaderFattura.STREET_FROM = ""
			f.HeaderFattura.CITY_FROM = ""
			f.HeaderFattura.PROVINCE_FROM = ""
			f.HeaderFattura.ZIPCODE_FROM = ""
			f.HeaderFattura.COUNTRY_FROM = ""
			f.HeaderFattura.LEGAL_NOTES_FROM = ""
			f.HeaderFattura.PHONE_FROM = ""
			f.HeaderFattura.EMAIL_FROM = ""
			f.HeaderFattura.DOCUMENT_OBJECT = "Operazioni svolte per il sistema dei contratti bilaterali nel periodo indicato"
			f.HeaderFattura.TAX_INFO = ""
			f.HeaderFattura.PAYMENT_INFO = ""
			f.HeaderFattura.INVOICE_NOTE1 = ""
			f.HeaderFattura.TAX_REFERENCE_TO = ""
			f.HeaderFattura.OP_NAME_TO = ""
			f.HeaderFattura.SDC_CODE_TO = codeOpTo
			f.HeaderFattura.STREET_TO = ""
			f.HeaderFattura.CITY_TO = ""
			f.HeaderFattura.PROVINCE_TO = ""
			f.HeaderFattura.ZIPCODE_TO = ""
			f.HeaderFattura.COUNTRY_TO = ""
			f.HeaderFattura.STREET_TO_2 = ""
			f.HeaderFattura.CITY_TO_2 = ""
			f.HeaderFattura.PROVINCE_TO_2 = ""
			f.HeaderFattura.ZIPCODE_TO_2 = ""
			f.HeaderFattura.COUNTRY_TO_2 = ""
			f.HeaderFattura.FAX_FROM = ""


			'f.HeaderFattura.AMOUNT = "10.000,00"			 ' totale mensile corr. senza IVA
			'f.HeaderFattura.TAX_AMOUNT = "2.000,00"			 ' IVA calcolata con percentuale da configurazione
			'f.HeaderFattura.TOTAL_AMOUNT = "12.000,00"			 ' totale con IVA
			'f.HeaderFattura.QUANTITY = "500,000"			 ' somma delle QUANTITY nelle righe fattura"
			f.HeaderFattura.INVOICE_NUMBER = ""
			f.HeaderFattura.INVOICE_DATE = ""
			f.HeaderFattura.INVOICE_DUE_DATE = ""


			' il Summary1 e` un aggregato di tutte le righe fattura per codice iva
			' siccome per semplicita noi abbiamo un solo codice IVA
			' avremo solo un solo Summary1
			Dim fs1(0) As FatturaSummary1
			f.Summary1 = fs1
			f.Summary1(0) = New FatturaSummary1

			'f.Summary1(0).AMOUNT = "10.000,00"			 ' Somm(LineAmount)
			f.Summary1(0).TAX_CODE = taxCode			 ' da configurazione
			'f.Summary1(0).TAX_AMOUNT = "2.000,00"			' iva calcolata con perc da config sull'amount
			'f.Summary1(0).TOTAL_AMOUNT = "12.000,00"			' somma dei due sopra
			'f.Summary1(0).QUANTITY = "500,000"			' numero di <linea>



			' il Summary2 e` un aggregato di tutte le righe fattura per codice iva / mercato
			' siccome per semplicita noi abbiamo un solo codice IVA
			' e abbiamo comunque un solo mercato
			' avremo solo un solo Summary2
			Dim fs2(0) As FatturaSummary2
			f.Summary2 = fs2
			f.Summary2(0) = New FatturaSummary2

			f.Summary2(0).TAX_CODE = taxCode			 ' da configurazione
			f.Summary2(0).MARKET = "MGP"			 ' fisso
			'f.Summary2(0).AMOUNT = "10.000,00"			 ' Somm(LineAmount)
			'f.Summary2(0).QUANTITY = "500,00"			 ' numero di <Linea>


			' esiste un solo <ElencoLinee> per file
			' che contine tante <Linea> tante quante sono
			' data/ora/contratto
			' 
			' fla verra` alla fine convertita in array per f.ElencoLinee
			fla = New ArrayList

		End Sub

		Public Sub WriteLine(ByVal taxCode As String, ByVal crn As String, ByVal dataFlusso As DateTime, ByVal periodoRilevante As Integer, ByVal corr As Decimal, ByVal SommQ As Decimal, ByVal PrezzoUnico As Decimal)

			Dim fl As New FatturaLinea

			fl.UNIT_TYPE = "NONE"			 ' fissato
			fl.UNIT_CODE = "NONE"			 ' fissato
			fl.MARKET = "MGP"			' fissato
			fl.SUPPLY_CODE = crn			' codice CRN
			fl.TAX_CODE = taxCode			' da configurazione
			fl.FLOW_DATE = dataFlusso.ToString("yyyyMMdd")			' data flusso "20040518
			fl.FLOW_HOUR = periodoRilevante.ToString()			' periodo ril.
			fl.UNIT_OF_MEASURE = "MWH"			' fisso

			fl.QUANTITY = SommQ.ToString("#,###0.000", g)
			Me.TotaleQuantity += SommQ

			fl.UNIT_SELLING_PRICE = PrezzoUnico.ToString("#,###0.000000", g)			 '"20,000000" tot CSP (senza segno) (per obolo una percentuale da configurazione calcalato sulla quantita)

			fl.LINE_AMOUNT = corr.ToString("#,###0.00", g)			 ' "10.000,00" 'tot CSP (qty =1)
			Me.TotaleCorr += corr

			fla.Add(fl)

		End Sub


		Public Function WriteFattura(ByVal iva As Decimal) As Byte()

			If fla.Count = 0 Then Return Nothing

			' qui convertiamo l'ArrayList in array di FatturaLine da mettere in f.ElencoLinee
			f.ElencoLinee = DirectCast(fla.ToArray(GetType(FatturaLinea)), FatturaLinea())

            Dim TotCorrRounded As Decimal = Math.Round(Me.TotaleCorr, 2)
            Dim TaxCorrRounded As Decimal = Math.Round(TotCorrRounded * iva / 100, 2)
            Dim TotaleCorr As Decimal = Math.Round(TotCorrRounded + TaxCorrRounded, 2)

            Dim quantity As String = Me.TotaleQuantity.ToString("#,###0.000", g)
            ' Dim amount As String = Me.TotaleCorr.ToString("#,###0.00", g)
            ' Dim tax_amount As String = Math.Round((Math.Round(Me.TotaleCorr, 2) * iva / 100)).ToString("#,###0.00", g)
            ' Dim total_amount As String = (Math.Round(Me.TotaleCorr, 2) + Math.Round(Math.Round(Me.TotaleCorr, 2) * iva / 100, 2)).ToString("#,###0.00", g)

            Dim amount As String = TotCorrRounded.ToString("#,###0.00", g)
            Dim tax_amount As String = TaxCorrRounded.ToString("#,###0.00", g)
            Dim total_amount As String = TotaleCorr.ToString("#,###0.00", g)


			f.HeaderFattura.AMOUNT = amount			 ' "10.000,00"			 ' totale mensile corr. senza IVA
			f.HeaderFattura.TAX_AMOUNT = tax_amount			 ' "2.000,00"			 ' IVA calcolata con percentuale da configurazione
			f.HeaderFattura.TOTAL_AMOUNT = total_amount			 ' totale con IVA

			' LEO nuove modifiche
			' totale della fattura
			f.HeaderFattura.QUANTITY = quantity			 ' "500,000"			 ' somma delle QUANTITY nelle righe fattura"


			f.Summary1(0).AMOUNT = amount			 ' "10.000,00"			 ' Somm(LineAmount)
			f.Summary1(0).TAX_AMOUNT = tax_amount			 ' "2.000,00"			' iva calcolata con perc da config sull'amount
			f.Summary1(0).TOTAL_AMOUNT = total_amount			 ' "12.000,00"			' somma dei due sopra
			' LEO nuove modifiche
			' aggregato per mercato
			f.Summary1(0).QUANTITY = quantity			 ' "500,000"			

			f.Summary2(0).AMOUNT = amount			 ' "10.000,00"			 ' Somm(LineAmount)
			' LEO nuove modifiche
			' aggregato per mercato, codice iva
			f.Summary2(0).QUANTITY = quantity			 '"500,00"		


			Dim xs As XmlSerializer = New XmlSerializer(GetType(Fattura))

			Dim ms As MemoryStream
			Dim xw As XmlTextWriter

			ms = New MemoryStream
			xw = New XmlTextWriter(ms, Encoding.GetEncoding("iso-8859-1"))
			xw.Formatting = Formatting.Indented
			xw.IndentChar = "	"c
			xw.Indentation = 1

			xs.Serialize(xw, Me.f)

			xw.Flush()
			xw.Close()

			Dim b() As Byte = ms.ToArray()
			Return b

		End Function

	End Class


	Private Sub CreaReportCSP(ByVal di As DateTime, ByVal df As DateTime, ByVal cn As SqlConnection)

		Dim dr As SqlDataReader = Nothing

		Try

			Dim sp As New SqlCommand
			sp.CommandType = CommandType.StoredProcedure
			sp.CommandText = "spGeneraCSP_OFF"
			sp.CommandTimeout = AppSettingToInt32("CSP_OFF_PgtC_OPIPEX.QueryTmo", 60)
			sp.Connection = cn
			sp.Parameters.Add("@di", di)
			sp.Parameters.Add("@df", df)

			dr = sp.ExecuteReader()

			Dim rowColData As New RowColData(dr)

			Dim rCurr As New RowData(rowColData)
			Dim rNext As New RowData(rowColData)

			' qui faccio la lettura corrente e anticipata
			rCurr.ReadData(dr)
			If rCurr.EOF Then Return
			rNext.ReadData(dr)


			Dim taxCode As String = AppSettingToString("CSP_OFF_PgtC_OPIPEX.TAXCODE", "A2")
			Dim idGme As String = AppSettingToString("CSP_OFF_PgtC_OPIPEX.codeOpFrom", "IDGME")
			Dim iva As Decimal = AppSettingToDecimal("CSP_OFF_PgtC_OPIPEX.IVA", 10)
			Dim opDestCSP As String = AppSettingToString("CSP_OFF_PgtC_OPIPEX.Destinatario", "IDGRTN")

			' se sono arrivato qui ho almeno un record da trattare

			' mi preparo con le due fatture per l'operatore
			' poi se una o emtrambi non conterrano righe non inviero il file al GME
			Dim cspRptOFF As CSP
			cspRptOFF = New CSP(rCurr.OpAcqIpex.Value, idGme, taxCode, di, df, idGme)


			Do
				cspRptOFF.WriteLine(taxCode, _
				 rCurr.CRN.Value, _
				 rCurr.DataProgramma.Value, _
				 rCurr.PeriodoRilevante.Value, _
				 rCurr.ControvaloreEuro.Value, _
				 rCurr.QuantitaVendute.Value, _
				 rCurr.PrezzoUnico.Value)


				Dim finito As Boolean = False

				If rNext.EOF Then
					finito = True
				ElseIf rCurr.OpAcqIpex.Value <> rNext.OpAcqIpex.Value Then
					finito = True
				End If

				If finito Then
					Dim b As Byte() = cspRptOFF.WriteFattura(iva)
					If Not b Is Nothing Then

						Dim mm As String = String.Format("Corrispettivi CSP - {0:dd/MM/yyy} - {1:dd/MM/yyy}", di, df)
						SaveFileCSP(opDestCSP, "CSP_OFF", mm, b, di, df, rCurr.OpAcqIpex.Value)

						Dim ws As New Bil.gmeBridge.BilMGPBridge
						ws.WSAuthHeaderValue = New Bil.gmeBridge.WSAuthHeader
						Bil_Crypt.WSClient.Setup(ws, ws.WSAuthHeaderValue.Username, ws.WSAuthHeaderValue.Password, "Bil_MGPBridgeWS")
						ws.UploadFatturaPassivaGME(False, rCurr.OpAcqIpex.Value, cspRptOFF.Fattura.HeaderFattura.ACCOUNT_NUMBER, cspRptOFF.Fattura.DOCUMENT_ID, df, b)

						smTrace(String.Format("Generazione corrispettivi: inviata al GME fattura passiva per il GME, relativa al CSP operatore={0}", rCurr.OpAcqIpex.Value))
					Else
						smTrace(String.Format("Generazione corrispettivi: non e` necessario inviare la fattura passiva all'operatore={0} in quanto vuota", rCurr.OpAcqIpex.Value))
					End If
				End If

				If rNext.EOF Then
					Exit Do
				End If

				If finito Then
					' ho finito la fattura corrente, ma ci sono altri record --> devo fare un'altra fattura
					cspRptOFF = New CSP(rNext.OpAcqIpex.Value, idGme, taxCode, di, df, idGme)
				End If


				rCurr = rNext
				rNext = New RowData(rowColData)
				rNext.ReadData(dr)
			Loop

		Finally
			If Not dr Is Nothing Then
				dr.Close()
			End If
		End Try

	End Sub

	Public Sub SaveFileCSP(ByVal codiceOperatore As String, ByVal tipoFile As String, ByVal descrizioneFile As String, ByVal b() As Byte, ByVal dataMin As DateTime, ByVal dataMax As DateTime, byval opCsp as String)
		Dim nomefile As String
		nomefile = String.Format("{0}_{1:yyyy}{1:MM}{1:dd}_{2:yyyy}{2:MM}{2:dd}_{3}.xml", tipoFile, dataMin, dataMax, opCsp)
		BilBLBase.MemorizzaFilePerOperatore(Nothing, Nothing, codiceOperatore, nomefile, tipoFile, descrizioneFile, b, DateTime.Now(), "iso-8859-1", DateTime.MaxValue)
	End Sub


End Class
