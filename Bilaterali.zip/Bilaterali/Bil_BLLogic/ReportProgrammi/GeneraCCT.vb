Imports System.Data
Imports System.Text
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Xml
Imports System.Xml.Schema
Imports System.Configuration
Imports System.IO
Imports System.Xml.Serialization
Imports System.Globalization
Imports System.Threading


Public Class GeneraCCT
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=False;initial catalog=Bilaterali;password=bilaterali"

	End Sub

#End Region


	Public Function CreaReportCCTBatch(ByVal op As String, ByVal dataRicercaMin As DateTime, ByVal dataRicercaMax As DateTime) As String
		Dim bd As New BatchData
		bd.dataRicercaMin = dataRicercaMin
		bd.dataRicercaMax = dataRicercaMax
		bd.operatoreDestinatario = op

		'BatchSerializer.BS.AddBatch(AddressOf Me.CreaReportCCTAsync, bd, "CORR", String.Format("Generazione file XML corrispettivi dal {0:d} al {1:d}", dataRicercaMin, dataRicercaMax), DateTime.MinValue)

		ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf CreaReportCCTAsync), bd)

		Return "Program_<data creazione>_<progressivo>.xml"

	End Function

	Class BatchData
		Public operatoreDestinatario As String
		Public dataRicercaMin As DateTime
		Public dataRicercaMax As DateTime
	End Class


	Private Shared Sub CreaReportCCTAsync(ByVal o As Object)
		Dim bl As New GeneraCCT
		Dim bd As BatchData = DirectCast(o, BatchData)
		bl.CreaReportCCT(bd.operatoreDestinatario, bd.dataRicercaMin, bd.dataRicercaMax)
	End Sub

	Public Enum CCTType
		Acquirente
		Cedente
	End Enum

	Public Sub CreaReportCCT(ByVal operatoreDestinatarioCCT As String, ByVal dataRicercaMin As DateTime, ByVal dataRicercaMax As DateTime)
		Try

			smTrace(String.Format("Generazione Corrispettivi: inizio elaborazione - date={0:dd/MM/yyy} - {1:dd/MM/yyy}", dataRicercaMin, dataRicercaMax))

			Dim tsCreazione As DateTime = DateTime.Now


			Dim dataFlusso As DateTime = dataRicercaMin
			Dim progressivoFileCCT As Integer = 1
			Do
				smTrace(String.Format("Generazione Corrispettivi: inizio elaborazione CCT - data={0:dd/MM/yyy}", dataFlusso))

				' qui genero i CCT da inviare al GRTN.
				' Un file per data
				' il file si chiama 'CORR'
				CreaReportCCT(operatoreDestinatarioCCT, dataFlusso, tsCreazione, progressivoFileCCT, CCTType.Cedente)

				If AppSettingToBoolean("CCT.GeneraAcquirente", False) Then
					CreaReportCCT(operatoreDestinatarioCCT, dataFlusso, tsCreazione, progressivoFileCCT, CCTType.Acquirente)
				End If

				dataFlusso = dataFlusso.AddDays(1)
				progressivoFileCCT += 1

				smTrace(String.Format("Generazione Corrispettivi: elaborazione CCT terminata con successo - data={0:dd/MM/yyy}", dataFlusso))


			Loop While (dataFlusso <= dataRicercaMax)

			smTrace(String.Format("Generazione Corrispettivi CCT: elaborazione terminata con successo - date={0:dd/MM/yyy} - {1:dd/MM/yyy}", dataRicercaMin, dataRicercaMax))

		Catch ex As Exception
			smTrace(ex, String.Format("Generazione Corrispettivi: elaborazione fallita"))
			Throw
		End Try

	End Sub

	Private Sub CreaReportCCT(ByVal operatoreDestinatarioCCT As String, ByVal dataFlusso As DateTime, ByVal tsCreazione As DateTime, ByVal progressivoFileCCT As Integer, ByVal tipoCTT As CCTType)

		Dim CodiceOperatoreSDCDestinatario As String = AppSettingToString("CCT.OperatoreDestinatario", "")
		If CodiceOperatoreSDCDestinatario.Length = 0 Then
			CodiceOperatoreSDCDestinatario = operatoreDestinatarioCCT
		End If



		Dim tr As SqlTransaction = Nothing
		Try
			Me.cn.ConnectionString = Me.GetConnectionString()
			Me.cn.Open()

			tr = Nothing

			CreaReportCCT(dataFlusso, cn, tr, CodiceOperatoreSDCDestinatario, progressivoFileCCT, tsCreazione, tipoCTT)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

		Catch ex As Exception
			smError(ex, String.Format("Generazione corrispettivi: errore generazioe CCT={0}", dataFlusso))
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			cn.Dispose()
		End Try
	End Sub


	Private Sub CreaReportCCT(ByVal dataFlusso As DateTime, ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal OperatoreDestinatarioCCT As String, ByVal progressivoFileCCT As Integer, ByVal tsCreazione As DateTime, ByVal tipoCTT As CCTType)

		Dim spReportXmlCCT As New SqlCommand
		spReportXmlCCT.CommandType = CommandType.StoredProcedure
		If tipoCTT = CCTType.Cedente Then
			spReportXmlCCT.CommandText = "spReportXmlCCT_C"
		Else
			spReportXmlCCT.CommandText = "spReportXmlCCT_A"
		End If
		spReportXmlCCT.Connection = cn
		spReportXmlCCT.Transaction = tr
		spReportXmlCCT.Parameters.Add("@DataFlusso", dataFlusso)
		spReportXmlCCT.CommandTimeout = AppSettingToInt32("CCT.QueryTmo", 60)

		Dim dr As SqlDataReader = Nothing
		Try
			dr = spReportXmlCCT.ExecuteReader()

			Dim rcd As New RowColData(dr)

			Dim rCurr As New RowData(rcd)
			Dim rNext As New RowData(rcd)

			' qui faccio la lettura corrente e anticipata
			rCurr.ReadData(dr)
			If (rCurr.EOF) Then Return
			rNext.ReadData(dr)

			' dati ordinati per op, crn, unita, pr
			' questo e` il totale del corrispettivo per contratto.

			Dim rpt As CCT = New CCT(dataFlusso)
			Dim rDelContratto As New ArrayList
			Dim totCCTperContratto As Decimal = 0

			rpt.CreaReportCCT(dataFlusso)

			Do
				' Corrispettivi:
				' CCT = Som(Round(Qp(Pu-Pz), 2))

				' aggiorno i totali per contratto/ora
				' le qty nelle formule sono trattate in valore assoluto

				' accumulo i record di uno stesso contratto
				' in modo da calcolare il totale del corrispettivo per contratto
				totCCTperContratto += rCurr.CCTOfferta.Value
				rDelContratto.Add(rCurr)

				Dim finito As Boolean = False

				If rNext.EOF Then
					finito = True
				ElseIf rCurr.CRN.Value <> rNext.CRN.Value Then
					finito = True
				End If

				If finito Then

					' qui si scrive nel xml la sezione
					' <CDetails>
					'	<IOP>Operatore</IOP>
					'	<CRN>29298283</CRN>
					'	<MNEM>AABBCC</MNEM>
					'	<TOTCORR>410</TOTCORR>
					'	<QDetails>
					'		<URN>U1</URN>
					'		<QTY Hour='1' CORR="200">100</QTY>
					'		<URN>U1</URN>
					'		<QTY Hour='2' CORR="210">100</QTY>
					'	</QDetails>
					' </CDetails>
					CreaSezioneReportCCT(rpt, rDelContratto, totCCTperContratto)

					totCCTperContratto = 0
					rDelContratto.Clear()

				End If

				If rNext.EOF Then
					Exit Do
				End If

				rCurr = rNext
				rNext = New RowData(rcd)
				rNext.ReadData(dr)
			Loop

			rpt.ChiudiReportCCT(tsCreazione, rCurr, OperatoreDestinatarioCCT, progressivoFileCCT, tipoCTT)

		Finally
			If Not dr Is Nothing Then
				dr.Close()
			End If
			dr = Nothing
		End Try

	End Sub

	Private Sub CreaSezioneReportCCT(ByVal rpt As CCT, ByVal rDelContratto As ArrayList, ByVal totCCTperContratto As Decimal)
		' CCT un file per data.
		' CCT primo livello Operatore di riferimento / CRN (ordinati per op/crn) (CDetail)
		' CCT secondo livello Unita (QDetail)
		' CCT terzo livello ora/corrispettivo e quantita` (QTY)
		' 
		' <CDetails>
		'	<IOP></IOP>
		'	<CRN></CRN>
		'	<MNEM></MNEM>
		'	<TOTCORR></TOTCORR>
		'	<QDetails>
		'		<URN></URN>                         <-- per ogni unita`
		'		<QTY Hour='1' CORR="">100</QTY>		<-- per tutte le ore
		'	</QDetails>
		' </CDetails>

		Dim rCurr As RowData
		Dim rNext As RowData

		If rDelContratto.Count = 0 Then Return

		If rDelContratto.Count = 1 Then
			rCurr = DirectCast(rDelContratto(0), RowData)
			rNext = New RowData
		Else
			rCurr = DirectCast(rDelContratto(0), RowData)
			rNext = DirectCast(rDelContratto(1), RowData)
		End If

		rpt.ApriCDetailsCCT(rCurr, totCCTperContratto)
		rpt.ApriQDetailsCCT(rCurr)

		Dim iCurr As Integer = 0
		Do
			rpt.ScriviQTYCCT(rCurr)

			If rNext.EOF Then

				rpt.ChiudiQDetailsCCT()
				rpt.ChiudiCDetailsCCT()
				Exit Do

			ElseIf rNext.CRN.Value <> rCurr.CRN.Value Then
				Debug.Assert(False)

				rpt.ChiudiQDetailsCCT()
				rpt.ChiudiCDetailsCCT()

				rpt.ApriCDetailsCCT(rNext, totCCTperContratto)
				rpt.ApriQDetailsCCT(rNext)

			ElseIf rNext.CodiceUnitaSDC.Value <> rCurr.CodiceUnitaSDC.Value Then

				rpt.ChiudiQDetailsCCT()
				rpt.ApriQDetailsCCT(rNext)

			End If


			iCurr += 1
			rCurr = rNext
			Dim iNext As Integer = iCurr + 1
			If iNext < rDelContratto.Count Then
				rNext = DirectCast(rDelContratto(iNext), RowData)
			Else
				rNext = New RowData
			End If
		Loop

	End Sub


#Region "Classi per l'accesso ai dati"
	Class RowColData
		Public ReadOnly col_Op As Integer
		Public ReadOnly col_CRN As Integer
		Public ReadOnly col_CodiceContratto As Integer
		Public ReadOnly col_PeriodoRilevante As Integer
		Public ReadOnly col_CodiceUnitaSDC As Integer
		Public ReadOnly col_CategoriaUnitaSDC As Integer
		Public ReadOnly col_QtyMWh As Integer
		Public ReadOnly col_CCTOfferta As Integer

		Public Sub New(ByVal dr As SqlDataReader)
			col_Op = dr.GetOrdinal("Op")
			col_CRN = dr.GetOrdinal("CRN")
			col_CodiceContratto = dr.GetOrdinal("CodiceContratto")
			col_PeriodoRilevante = dr.GetOrdinal("PeriodoRilevante")
			col_CodiceUnitaSDC = dr.GetOrdinal("CodiceUnitaSDC")
			col_CategoriaUnitaSDC = dr.GetOrdinal("CategoriaUnitaSDC")
			col_QtyMWh = dr.GetOrdinal("QtyMWh")
			col_CCTOfferta = dr.GetOrdinal("CCTOfferta")
		End Sub
	End Class
	Class RowData

		Public Sub New()
			EOF = True
		End Sub


		Public Sub New(ByVal c As RowColData)
			Me.c = c
			EOF = True
		End Sub


		Private ReadOnly c As RowColData

		Public EOF As Boolean = True

		Public Op As SqlString
		Public CRN As SqlString
		Public CodiceContratto As SqlString
		Public PeriodoRilevante As SqlByte
		Public CodiceUnitaSDC As SqlString
		Public CategoriaUnitaSDC As SqlString
		Public QtyMWh As SqlDecimal
		Public CCTOfferta As SqlDecimal


		Public Sub ReadData(ByVal dr As SqlDataReader)
			If (dr.Read() = False) Then
				EOF = True
				Return
			End If

			EOF = False

			Op = dr.GetSqlString(c.col_Op)
			CRN = dr.GetSqlString(c.col_CRN)
			CodiceContratto = dr.GetSqlString(c.col_CodiceContratto)
			PeriodoRilevante = dr.GetSqlByte(c.col_PeriodoRilevante)
			CodiceUnitaSDC = dr.GetSqlString(c.col_CodiceUnitaSDC)
			CategoriaUnitaSDC = dr.GetSqlString(c.col_CategoriaUnitaSDC)
			CategoriaUnitaSDC = dr.GetSqlString(c.col_CategoriaUnitaSDC)
			QtyMWh = dr.GetSqlDecimal(c.col_QtyMWh)
			CCTOfferta = dr.GetSqlDecimal(c.col_CCTOfferta)
		End Sub

	End Class
#End Region

	Class CCT
		Public Sub New(ByVal dataFlusso As DateTime)
			Me.dataFlusso = dataFlusso
		End Sub

		Private dataFlusso As DateTime

		Dim ms As MemoryStream = Nothing
		Dim xw As XmlTextWriter = Nothing


		Public Sub CreaReportCCT(ByVal dataProgramma As DateTime)
			Me.ms = New MemoryStream
			Me.xw = New XmlTextWriter(ms, Encoding.GetEncoding("iso-8859-1"))

			xw.Formatting = Formatting.Indented
			xw.IndentChar = "	"c
			xw.Indentation = 1

			xw.WriteStartDocument()
			xw.WriteProcessingInstruction("xml-stylesheet", "type=""text/xsl"" href=""ProgrammiBilateraliAccettati.xsl""")

			xw.WriteStartElement("Program")
			xw.WriteAttributeString("xmlns", "urn:XML-BIL")
			xw.WriteAttributeString("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")

			' questo XML aveva gia` un schema.... ==> siamo costretti a seguirlo.
			xw.WriteAttributeString("xsi:schemaLocation", "urn:XML-BIL ContractProgram.xsd")
			xw.WriteAttributeString("Version", "1.0")
			' data in formato Excelergy
			xw.WriteElementString("Date", String.Format("{0:yyyy}{0:MM}{0:dd}", dataProgramma))			 ' STR105 OK (nello schema e` cosi`)
		End Sub

		Public Sub ApriCDetailsCCT(ByVal rCurr As RowData, ByVal totCCTperContratto As Decimal)

			xw.WriteStartElement("CDetails")

			xw.WriteElementString("IDOP", rCurr.Op.Value)
			xw.WriteElementString("CRN", rCurr.CRN.Value)
			xw.WriteElementString("MNEM", rCurr.CodiceContratto.Value)

			xw.WriteElementString("TOTCORR", XmlEuro(totCCTperContratto, Globalization.CultureInfo.InvariantCulture.NumberFormat))			 ' OK STR105
		End Sub

		Public Sub ScriviQTYCCT(ByVal rCurr As RowData)

			Dim h As Byte = rCurr.PeriodoRilevante.Value
			Dim corr As Decimal = rCurr.CCTOfferta.Value
			Dim qty As Decimal = rCurr.QtyMWh.Value


			xw.WriteStartElement("QTY")
			xw.WriteAttributeString("Hour", XmlConvert.ToString(h))

			xw.WriteAttributeString("CORR", XmlEuro(corr, Globalization.CultureInfo.InvariantCulture.NumberFormat))			 ' OK STR105
			xw.WriteString(XmlQtyMWh(qty, Globalization.CultureInfo.InvariantCulture.NumberFormat))			 ' OK STR105

			xw.WriteEndElement()			 ' QTY
		End Sub

		Public Sub ApriQDetailsCCT(ByVal r As RowData)
			xw.WriteStartElement("QDetails")
			xw.WriteStartElement("URN")
			xw.WriteString(r.CodiceUnitaSDC.Value)
			xw.WriteEndElement()			 ' URN
		End Sub
		Public Sub ChiudiQDetailsCCT()
			xw.WriteEndElement()			 ' QDetails
		End Sub

		Public Sub ChiudiCDetailsCCT()
			xw.WriteEndElement()			 ' CDetails
		End Sub

		Public Sub ChiudiReportCCT(ByVal tsCreazione As DateTime, ByVal r As RowData, ByVal CodiceOperatoreSDCDestinatario As String, ByVal progressivoFile As Integer, ByVal tipoCCT As CCTType)
			xw.WriteEndDocument()
			xw.Flush()
			xw.Close()

			Dim b() As Byte = ms.ToArray()

			Dim nomefile As String
			Dim descrizioneFile As String
			Dim tipoFile As String

			If tipoCCT = CCTType.Cedente Then
				Dim fmt As String
				fmt = BilBLBase.AppSettingToString("CCT.DescriptionP", "XML Corrispettivi CCT programmi del {0:d}")
				descrizioneFile = String.Format(fmt, Me.dataFlusso)
				fmt = BilBLBase.AppSettingToString("CCT.FileNameP", "Program_{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}_{1}.xml")
				nomefile = String.Format(fmt, tsCreazione, progressivoFile)
				tipoFile = BilBLBase.AppSettingToString("CCT.FileTypeP", "CORR")
			Else
				Dim fmt As String
				fmt = BilBLBase.AppSettingToString("CCT.DescriptionA", "XML Corrispettivi CCT programmi acquirenti del {0:d}")
				descrizioneFile = String.Format(fmt, Me.dataFlusso)
				fmt = BilBLBase.AppSettingToString("CCT.FileNameA", "ProgramA_{0:yyyy}{0:MM}{0:dd}{0:HH}{0:mm}{0:ss}_{1}.xml")
				nomefile = String.Format(fmt, tsCreazione, progressivoFile)
				tipoFile = BilBLBase.AppSettingToString("CCT.FileTypeA", "CORRA")
			End If

			BilBLBase.MemorizzaFilePerOperatore(Nothing, Nothing, CodiceOperatoreSDCDestinatario, nomefile, "CORR", descrizioneFile, b, DateTime.Now(), "iso-8859-1", DateTime.MaxValue)

			ms = Nothing
			xw = Nothing
		End Sub

	End Class

End Class
