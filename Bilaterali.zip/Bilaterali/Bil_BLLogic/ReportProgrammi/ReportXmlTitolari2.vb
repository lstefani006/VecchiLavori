Imports System.Data
Imports System.Text
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Xml
Imports System.Xml.Schema
Imports System.Configuration
Imports System.IO


Public Class ReportXmlTitolari2
	Inherits BilBLBase

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents spReportXmlTitolari2 As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.spReportXmlTitolari2 = New System.Data.SqlClient.SqlCommand
		'
		'cn
		'
		Me.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" & _
		"st security info=False;initial catalog=Bilaterali"
		'
		'spReportXmlTitolari2
		'
		Me.spReportXmlTitolari2.CommandText = "dbo.[spReportXmlTitolari2]"
		Me.spReportXmlTitolari2.CommandType = System.Data.CommandType.StoredProcedure
		Me.spReportXmlTitolari2.Connection = Me.cn
		Me.spReportXmlTitolari2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
		Me.spReportXmlTitolari2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DataFlusso", System.Data.SqlDbType.DateTime, 8))

	End Sub

#End Region


	Class RawData

		Sub New(ByVal DataProgramma As DateTime, ByVal TsCreazioneReport As DateTime)
			Me.DataProgramma = DataProgramma
			Me.TsCreazioneReport = TsCreazioneReport
		End Sub

		Public EOF As Boolean = True

		Public DataProgramma As DateTime
		Public TsCreazioneReport As DateTime

		Public CRN As SqlString
		Public CodiceOperatoreSDCTitolare As SqlString
		Public PeriodoRilevante As SqlByte
		Public CodiceZonaSDC As SqlString
		Public PrezzoZonale As SqlDecimal
		Public PrezzoUnico As SqlDecimal
		Public Status As SqlString
		Public QtyP As SqlDouble
		Public QtyC As SqlDouble
		Public QtyMP As SqlDouble
		Public QtyMC As SqlDouble

		Private col_CRN As Integer
		Private col_CodiceOperatoreSDCTitolare As Integer
		Private col_PeriodoRilevante As Integer
		Private col_CodiceZonaSDC As Integer
		Private col_PrezzoZonale As Integer
		Private col_PrezzoUnico As Integer
		Private col_Status As Integer
		Private col_QtyP As Integer
		Private col_QtyC As Integer
		Private col_QtyMP As Integer
		Private col_QtyMC As Integer

		Public Sub StoreCol(ByVal dr As SqlDataReader)
			col_CRN = dr.GetOrdinal("CRN")
			col_CodiceOperatoreSDCTitolare = dr.GetOrdinal("CodiceOperatoreSDCTitolare")
			col_PeriodoRilevante = dr.GetOrdinal("PeriodoRilevante")
			col_CodiceZonaSDC = dr.GetOrdinal("CodiceZonaSDC")
			col_PrezzoZonale = dr.GetOrdinal("PrezzoZonale")
			col_PrezzoUnico = dr.GetOrdinal("PrezzoUnico")
			col_Status = dr.GetOrdinal("Status")
			col_QtyP = dr.GetOrdinal("QtyP")
			col_QtyC = dr.GetOrdinal("QtyC")
			col_QtyMP = dr.GetOrdinal("QtyMP")
			col_QtyMC = dr.GetOrdinal("QtyMC")
		End Sub

		Public Function ReadData(ByVal dr As SqlDataReader) As Boolean
			If (dr.Read() = False) Then
				EOF = True
			Else
				EOF = False

				CRN = dr.GetSqlString(col_CRN)
				CodiceOperatoreSDCTitolare = dr.GetSqlString(col_CodiceOperatoreSDCTitolare)
				PeriodoRilevante = dr.GetSqlByte(col_PeriodoRilevante)
				CodiceZonaSDC = dr.GetSqlString(col_CodiceZonaSDC)
				PrezzoZonale = dr.GetSqlDecimal(col_PrezzoZonale)
				PrezzoUnico = dr.GetSqlDecimal(col_PrezzoUnico)
				Status = dr.GetSqlString(col_Status)
				QtyP = dr.GetSqlDouble(col_QtyP)
				QtyC = dr.GetSqlDouble(col_QtyC)
				QtyMP = dr.GetSqlDouble(col_QtyMP)
				QtyMC = dr.GetSqlDouble(col_QtyMC)
			End If

			Return Not EOF
		End Function

	End Class


	Public Sub CreaReportOperatoriTitolariBatch(ByVal dataProgramma As DateTime, ByVal runningOperator As String)
		BatchSerializer.BS.AddBatch(AddressOf CreaReportOperatoriTitolariAsync, dataProgramma, "RESP", "Generazione XML Report Responsabili", dataProgramma, runningOperator)
	End Sub

	Private Shared Sub CreaReportOperatoriTitolariAsync(ByVal dataProgramma As Object)
		Dim bl As New ReportXmlTitolari2
		bl.CreaReportOperatoriTitolari(CType(dataProgramma, DateTime))
		bl.Dispose()
	End Sub

	Private Function CreaReportOperatoriTitolari(ByVal dataProgramma As DateTime) As Boolean

		smTrace(String.Format("Generazione report RESP: inizio elaborazione - data={0:dd/MM/yyy}", dataProgramma))

		Dim tr As SqlTransaction = Nothing
		Try
			cn.ConnectionString = GetConnectionString()
			cn.Open()

			' e` da decidere se usare la transazione
			' tr = cn.BeginTransaction(IsolationLevel.ReadCommitted)

			CreaReportOperatoriTitolari = CreaReportOperatoriTitolari(cn, tr, dataProgramma)

			If Not tr Is Nothing Then tr.Commit() : tr = Nothing

			smTrace(String.Format("Generazione report RESP: elaborazione terminata con successo - data={0:dd/MM/yyy}", dataProgramma))


		Catch ex As Exception
			smError(ex, "Generazione report RESP: errore generale")
			Throw
		Finally
			If Not tr Is Nothing Then tr.Rollback() : tr = Nothing
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

	End Function

	Private Function CreaReportOperatoriTitolari(ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal dataProgramma As DateTime) As Boolean

		Dim sReportXmlTitolari As String = "ReportXmlTitolari"
		spReportXmlTitolari2.Parameters("@DataFlusso").Value = dataProgramma
		spReportXmlTitolari2.Connection = cn
		spReportXmlTitolari2.Transaction = tr
		'
		' set query timeout (default 45 secondi)
		'
		spReportXmlTitolari2.CommandTimeout = AppSettingToInt32(sReportXmlTitolari, 45)

		' uso la lettura anticipata per capire 
		' 1) quando e` cambiato il contratto devo creare un nuovo file xml
		' 2) quando e` cambiato un periodo rilevante devo creare un nuovo tag BilProgram

		Dim dr As SqlDataReader = spReportXmlTitolari2.ExecuteReader()

		Try
			Dim tsCreazioneReport As DateTime = DateTime.Now()

			Dim rCurr As New RawData(dataProgramma, tsCreazioneReport)			  ' questi tengono la riga corrente e la prossima riga
			Dim rNext As New RawData(dataProgramma, tsCreazioneReport)

			rCurr.StoreCol(dr)
			rNext.StoreCol(dr)

			rCurr.ReadData(dr)
			If rCurr.EOF Then Return False ' non c'e` neanche una riga --> non produco alcun record

			rNext.ReadData(dr)			 ' la riga corrente c'e` --> leggo la prossima riga

			' ho letto rCurr e forse rNext

			Dim ms As MemoryStream
			Dim xw As XmlTextWriter

			CreaReport(ms, xw, rCurr)
			CreaProgram(xw, rCurr)

			Do
				ScriviZona(xw, rCurr)

				If rNext.EOF Then
					ChiudiProgram(xw)
					ChiudiReport(ms, xw, cn, tr, rCurr)
					Exit Do
				End If

				If rNext.CRN.Value <> rCurr.CRN.Value Then

					ChiudiProgram(xw)
					ChiudiReport(ms, xw, cn, tr, rCurr)

					CreaReport(ms, xw, rNext)
					CreaProgram(xw, rNext)

				ElseIf rNext.PeriodoRilevante.Value <> rCurr.PeriodoRilevante.Value Then

					ChiudiProgram(xw)
					CreaProgram(xw, rNext)

				End If

				Dim rTemp As RawData = rCurr
				rCurr = rNext
				rNext = rTemp
				rNext.ReadData(dr)
			Loop


		Finally
			If Not dr Is Nothing Then dr.Close()
		End Try

		Return True

	End Function

	Private Shared Sub CreaReport(ByRef ms As MemoryStream, ByRef xw As XmlTextWriter, ByVal r As RawData)
		ms = New MemoryStream
		xw = New XmlTextWriter(ms, Encoding.UTF8)

		xw.Formatting = Formatting.Indented
		xw.IndentChar = "	"c
		xw.Indentation = 1

		xw.WriteStartDocument()

		xw.WriteStartElement("BilPrograms")
		xw.WriteAttributeString("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
		If BilBLBase.XmlITA Then
			xw.WriteAttributeString("xsi:noNamespaceSchemaLocation", "BilDailySummaryProgramsC.xsd")
		Else
			xw.WriteAttributeString("xsi:noNamespaceSchemaLocation", "BilDailySummaryPrograms.xsd")
		End If
		xw.WriteAttributeString("CreationDate", XmlDateTime(r.TsCreazioneReport, BilBLBase.XmlDateTimeInfo))		  'xw.WriteAttributeString("CreationDate", XmlConvert.ToString(r.TsCreazioneReport))
		xw.WriteAttributeString("Version", "1.0")

	End Sub

	Private Sub CreaProgram(ByVal xw As XmlTextWriter, ByVal r As RawData)
		xw.WriteStartElement("BilProgram")
		xw.WriteAttributeString("CRN", r.CRN.Value)

		xw.WriteAttributeString("Date", XmlDate(r.DataProgramma, BilBLBase.XmlDateTimeInfo))		  'xw.WriteAttributeString("Date", XmlConvert.ToString(r.DataProgramma, "yyyy-MM-dd"))
		xw.WriteAttributeString("Hour", XmlConvert.ToString(r.PeriodoRilevante.Value))


		xw.WriteAttributeString("Status", r.Status.Value)

	End Sub

	Private Sub ScriviZona(ByVal xw As XmlTextWriter, ByVal r As RawData)

		If r.Status.Value = "ProgramAccepted" Then

			xw.WriteStartElement("Zone")
			xw.WriteAttributeString("CodeZone", r.CodiceZonaSDC.Value)

			' Nota 7/Sett/2005
			' Nel caso di unita` estere di consumo la Qty di energia viene
			' accumulata in MWhC --> e l'attento lettore capira dal CodeZone
			' che deve usare il PriceZ e non il PrizeU
			' sia per il calcolo del CCT = Somm(Qimm * (P`-Pz))
			' che per il calcolo del corrispettivo totale Somm(Q*P)
			' Tutto questo senza parlare del CSP = DeltaQ * Pun

			xw.WriteAttributeString("MWhP", XmlQtyMWh(r.QtyP.Value, BilBLBase.XmlNumberInfo))
			xw.WriteAttributeString("MWhC", XmlQtyMWh(r.QtyC.Value, BilBLBase.XmlNumberInfo))
			xw.WriteAttributeString("MWhMP", XmlQtyMWh(r.QtyMP.Value, BilBLBase.XmlNumberInfo))
			xw.WriteAttributeString("MWhMC", XmlQtyMWh(r.QtyMC.Value, BilBLBase.XmlNumberInfo))

			xw.WriteAttributeString("PriceU", XmlPrezzoUnico(r.PrezzoUnico.Value, BilBLBase.XmlNumberInfo))
			xw.WriteAttributeString("PriceZ", XmlPrezzoZonale(r.PrezzoZonale.Value, BilBLBase.XmlNumberInfo))
			xw.WriteEndElement()			' Zone
		End If

	End Sub

	Private Shared Sub ChiudiProgram(ByVal xw As XmlTextWriter)
		xw.WriteEndElement()		  ' BilProgram
	End Sub

	Private Shared Sub ChiudiReport(ByRef ms As MemoryStream, ByRef xw As XmlTextWriter, ByVal cn As SqlConnection, ByVal tr As SqlTransaction, ByVal r As RawData)

		xw.WriteEndElement()		  ' BilPrograms
		xw.WriteEndDocument()
		xw.Flush()
		xw.Close()

		Dim descrizioneFile As String
		descrizioneFile = String.Format("Report titolari del contratto '{0}' del {1:d}", r.CRN.Value, r.DataProgramma)

		Dim tipoFile As String = "PGMRESP"

		Dim nomefile As String
		nomefile = String.Format("{0}_{1:yy}{1:MM}{1:dd}{1:HH}{1:mm}{1:ss}", tipoFile, r.TsCreazioneReport)
		nomefile += String.Format("_{0:yy}{0:MM}{0:dd}_{1}.xml", r.DataProgramma, r.CRN.Value)


		BilBLBase.MemorizzaFilePerOperatore(Nothing, Nothing, r.CodiceOperatoreSDCTitolare.Value, nomefile, tipoFile, descrizioneFile, ms.ToArray(), DateTime.Now(), "iso-8859-1", r.DataProgramma)

		xw = Nothing
		ms = Nothing
	End Sub

End Class
