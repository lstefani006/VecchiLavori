Imports System.io
Imports System.Runtime.Remoting
Imports System.Runtime.Remoting.Channels
Imports System.Runtime.Remoting.Channels.Tcp

Imports System.AppDomain
Imports SystemMonitor

Module Bil

	<MTAThread()> _
 Sub Main()
		' abilitazione del tracing in remoto
		System.Diagnostics.Trace.Listeners.Add(New SmTraceListener)

		If (True) Then
			RemotingConfiguration.Configure(CurrentDomain.SetupInformation.ConfigurationFile)
		Else
			Dim ch As TcpChannel = New TcpChannel(5698)
			ChannelServices.RegisterChannel(ch)
			RemotingConfiguration.RegisterWellKnownServiceType(GetType(Contratto), "Bil_Contratto", WellKnownObjectMode.SingleCall)
		End If

		SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "Bil_BLServer partito")
		Console.WriteLine("Bil_BLServer: server host della businness logic da usare per testare la solution.")


		BatchSerializer.InitBatchSerializer()

		Bil_Crypt.WSClient.SetCertificatePolicy(AddressOf SystemMonitor.SmLog.smError)


		ControlloBilanciamento.StartTimer()

		'Dim tfa As String = Configuration.ConfigurationSettings.AppSettings("TestFA")
		'If (Not tfa Is Nothing AndAlso tfa <> "") Then
		'    Dim fs As StreamReader = New StreamReader("C:\Bilaterali New\Bilaterali\Programmi XML\programma.xml")
		'    Dim bl As New ElaborazioneProgrammiUtenti
		'    Dim idxml As String
		'    bl.ElaboraFile("CODOPERATORESDC3", "CODUTENTESDC1", "C:\Bilaterali New\Bilaterali\Programmi XML\programma.xml", fs.ReadToEnd(), DateTime.Now, New TimeSpan(10, 0, 0), New TimeSpan(11, 0, 0), DateTime.Now, idxml)
		'    fs.Close()
		'End If

		' TEST LETTURA FILE XML DELLE BID NOTIFICATION
		'Dim tfa As String = Configuration.ConfigurationSettings.AppSettings("TestFA")
		'If (Not tfa Is Nothing AndAlso tfa <> "") Then
		'    Dim fs As StreamReader = New StreamReader("C:\Bilaterali\Programmi XML\BN\BN_MGPP_20040228_41.40540899212690.out.xml")
		'    Dim bl As New LetturaMercato
		'    Dim b As Boolean = bl.LeggiNotificheMercato(fs.ReadToEnd())
		'    fs.Close()
		'End If

		' TEST BUS UNIT
		'Dim bl As New Bus
		'Dim d As New DateTime(2004, 3, 5)
		'Dim flag As Boolean = bl.GenerateXmlBusFile(d)

		' TEST IMPORT CONTRATTI

		'Dim fs As FileStream = New FileStream("C:\Bilaterali\Programmi XML\Produzione\Contratti Produzione.xml", FileMode.Open, FileAccess.Read)
		'Dim fs As FileStream = New FileStream("C:\Bilaterali\Programmi XML\Produzione\Contratti Produzione - short.xml", FileMode.Open, FileAccess.Read)
		' Dim fs As FileStream = New FileStream("C:\Bilaterali\Test\1\c_100_50.xml", FileMode.Open, FileAccess.Read)

		'If False Then

		'	Dim fs As FileStream = New FileStream("C:\Bilaterali\Test\1\c.xml", FileMode.Open, FileAccess.Read)

		'	Dim r As New BinaryReader(fs)

		'	Dim bl As New ImportContratti
		'	Dim aby() As Byte = r.ReadBytes(CInt(fs.Length))
		'	Dim abyErrorsXML() As Byte
		'	Dim b As Boolean = bl.Import("Nome_Cablato.xml", aby, abyErrorsXML)
		'	fs.Close()

		'	If Not abyErrorsXML Is Nothing Then
		'		Dim fsXml As FileStream = New FileStream("C:\output_import_Programmi.xml", FileMode.Append)
		'		fsXml.Write(abyErrorsXML, 0, abyErrorsXML.Length)
		'		fsXml.Flush()
		'		fsXml.Close()
		'	End If
		'End If

		'Try
		'	Dim blProg As New Programmi
		'	Dim ds As New Data.DataSet
		'	ds = blProg.GetProgrammazione(New DateTime(2004, 5, 9))
		'Catch ex As Exception
		'	SmLog.smError(ex)
		'End Try



		' TEST MARKET RESULT
		'Dim fs As FileStream = New FileStream("C:\Bilaterali\Programmi XML\MarketResult\MR_MGPD_20040319.40650899215416.out.xml", FileMode.Open, FileAccess.Read)
		'Dim r As New BinaryReader(fs)

		'Dim bl As New MarketResult
		'Dim aby() As Byte = r.ReadBytes(CInt(fs.Length))
		'Dim abyErrorsXML() As Byte
		'Dim b As Boolean = bl.LeggiPrezziZonaliUnitari(fs.Name, aby)
		'fs.Close()


		' Per Test
		'Dim c As New ImportUnita
		'Dim c1 As New ImportPuntiDiScambioRilevanti
		'Dim c2 As New ImportOperatori
		'Dim c3 As New ImportUtenti
		'Dim d As New Xml.XmlDocument
		'Dim sb As New System.Text.StringBuilder
		'Dim tw As New System.IO.StringWriter(sb)
		'Dim ris As String = ""
		'd.Load("C:\REPTxn.xml")
		'd.Save(tw)
		'tw.Flush()
		'ris = c1.InserisciPuntiDiScambioRilevanti(sb.ToString)

		'ris = c.CopiaSDC_Unita()
		'ris = c2.CopiaSDC_Operatori()
		'ris = c3.CopiaSDC_Utenti()

		'Dim c4 As New ControlloBilanciamento
		'Dim d As New DateTime(2004, 2, 13)
		'Dim ris As Double
		'ris = c4.Bilanciamento(d, 1, "12345678901234567890123456789012", 1.1)
		'c4.Bilanciamento(d, 1, 1.1)

		'Dim c5 As New ReportProgrammi
		'Dim d As New DateTime(2004, 2, 13)
		'Dim ris As String
		'ris = c5.CreaReportProgrammi("12345678901234567890123456789012", d, 1, "CODOPERATORESDC1")

		' Scrittura dati
		'ris = c1.EsportaDatiDaSDC_Zone()
		'd.LoadXml(ris)
		'd.Save("C:\DS_SDC_ZoneDati.xml")
		' lettura dati
		'sb.Remove(0, sb.Length)
		'd.Load("C:\DS_SDC_ZoneDati.xml")
		'd.Save(tw)
		'tw.Flush()
		'c1.ImportaDatiInSDC_Zone(sb.ToString)

		'sb.Remove(0, sb.Length)
		'd.Load("C:\Operatori.xml")
		'd.Save(tw)
		'tw.Flush()
		'ris = c2.InserisciOperatori(sb.ToString)

		'sb.Remove(0, sb.Length)
		'd.Load("C:\Utenti.xml")
		'd.Save(tw)
		'tw.Flush()
		'ris = c3.InserisciUtenti(sb.ToString)

		'sb.Remove(0, sb.Length)
		'd.Load("C:\Unita.xml")
		'd.Save(tw)
		'tw.Flush()
		'ris = c.InserisciUnita(sb.ToString)
		' Fine Test

		Do
			Console.Write("Scrivi 'q' per terminare il server > ")
			Dim s As String = Console.ReadLine()
			If s = "q" Or s = "Q" Then
				SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "Bil_BLServer terminato da tastiera")
				Exit Do
			End If
		Loop


		BatchSerializer.DestroyBatchSerializer()

	End Sub
End Module
