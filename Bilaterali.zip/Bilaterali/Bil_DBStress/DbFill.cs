using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.Diagnostics;
using System.Data.SqlClient;

namespace Bil_DBStress
{
	/// <summary>
	/// Summary description for DbFill.
	/// </summary>
	public class DbFill : System.Windows.Forms.Form
	{
		private System.Data.SqlClient.SqlConnection cn;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		private System.Data.SqlClient.SqlDataAdapter daUnitRelate;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand2;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand2;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand2;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand2;
		private System.Data.SqlClient.SqlDataAdapter daContratto;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand3;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand3;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand3;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand3;
		private System.Data.SqlClient.SqlDataAdapter daProgrammaOrario;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand4;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand4;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand4;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand4;
		private System.Data.SqlClient.SqlDataAdapter daProgrammaOrarioPerUnita;
		private System.Data.SqlClient.SqlCommand sqlSelectCommand5;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand5;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand5;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand5;
		private System.Data.SqlClient.SqlDataAdapter daSDC_Unita;
		private Bil_DBStress.DS ds;
		private System.Windows.Forms.Button btnCaricaDati;
		private System.Windows.Forms.TextBox tbStress;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DbFill()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cn = new System.Data.SqlClient.SqlConnection();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.daUnitRelate = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			this.daContratto = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			this.daProgrammaOrario = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand4 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand4 = new System.Data.SqlClient.SqlCommand();
			this.daProgrammaOrarioPerUnita = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand5 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand5 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand5 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand5 = new System.Data.SqlClient.SqlCommand();
			this.daSDC_Unita = new System.Data.SqlClient.SqlDataAdapter();
			this.ds = new Bil_DBStress.DS();
			this.btnCaricaDati = new System.Windows.Forms.Button();
			this.tbStress = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.ds)).BeginInit();
			this.SuspendLayout();
			// 
			// cn
			// 
			this.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" +
				"st security info=False;initial catalog=Bilaterali";
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT CodiceOperatoreSDC, CodiceUnitaSDC, CategoriaUnitaSDC, DataInizioValidita," +
				" DataFineValidita, TSModifica, Abilitata, TrUC, VUC FROM dbo.UnitRelate";
			this.sqlSelectCommand1.Connection = this.cn;
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO dbo.UnitRelate(CodiceOperatoreSDC, CodiceUnitaSDC, CategoriaUnitaSDC, DataInizioValidita, DataFineValidita, TSModifica, Abilitata, TrUC, VUC) VALUES (@CodiceOperatoreSDC, @CodiceUnitaSDC, @CategoriaUnitaSDC, @DataInizioValidita, @DataFineValidita, @TSModifica, @Abilitata, @TrUC, @VUC); SELECT CodiceOperatoreSDC, CodiceUnitaSDC, CategoriaUnitaSDC, DataInizioValidita, DataFineValidita, TSModifica, Abilitata, TrUC, VUC FROM dbo.UnitRelate WHERE (CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (CodiceOperatoreSDC = @CodiceOperatoreSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC)";
			this.sqlInsertCommand1.Connection = this.cn;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TrUC", System.Data.SqlDbType.Bit, 1, "TrUC"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@VUC", System.Data.SqlDbType.Bit, 1, "VUC"));
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = @"UPDATE dbo.UnitRelate SET CodiceOperatoreSDC = @CodiceOperatoreSDC, CodiceUnitaSDC = @CodiceUnitaSDC, CategoriaUnitaSDC = @CategoriaUnitaSDC, DataInizioValidita = @DataInizioValidita, DataFineValidita = @DataFineValidita, TSModifica = @TSModifica, Abilitata = @Abilitata, TrUC = @TrUC, VUC = @VUC WHERE (CategoriaUnitaSDC = @Original_CategoriaUnitaSDC) AND (CodiceOperatoreSDC = @Original_CodiceOperatoreSDC) AND (CodiceUnitaSDC = @Original_CodiceUnitaSDC) AND (Abilitata = @Original_Abilitata) AND (DataFineValidita = @Original_DataFineValidita) AND (DataInizioValidita = @Original_DataInizioValidita) AND (TSModifica = @Original_TSModifica) AND (TrUC = @Original_TrUC) AND (VUC = @Original_VUC); SELECT CodiceOperatoreSDC, CodiceUnitaSDC, CategoriaUnitaSDC, DataInizioValidita, DataFineValidita, TSModifica, Abilitata, TrUC, VUC FROM dbo.UnitRelate WHERE (CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (CodiceOperatoreSDC = @CodiceOperatoreSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC)";
			this.sqlUpdateCommand1.Connection = this.cn;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TrUC", System.Data.SqlDbType.Bit, 1, "TrUC"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@VUC", System.Data.SqlDbType.Bit, 1, "VUC"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Abilitata", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Abilitata", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataFineValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataFineValidita", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataInizioValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataInizioValidita", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSModifica", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TrUC", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TrUC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_VUC", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "VUC", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = @"DELETE FROM dbo.UnitRelate WHERE (CategoriaUnitaSDC = @Original_CategoriaUnitaSDC) AND (CodiceOperatoreSDC = @Original_CodiceOperatoreSDC) AND (CodiceUnitaSDC = @Original_CodiceUnitaSDC) AND (Abilitata = @Original_Abilitata) AND (DataFineValidita = @Original_DataFineValidita) AND (DataInizioValidita = @Original_DataInizioValidita) AND (TSModifica = @Original_TSModifica) AND (TrUC = @Original_TrUC) AND (VUC = @Original_VUC)";
			this.sqlDeleteCommand1.Connection = this.cn;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Abilitata", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Abilitata", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataFineValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataFineValidita", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataInizioValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataInizioValidita", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSModifica", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TrUC", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TrUC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_VUC", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "VUC", System.Data.DataRowVersion.Original, null));
			// 
			// daUnitRelate
			// 
			this.daUnitRelate.DeleteCommand = this.sqlDeleteCommand1;
			this.daUnitRelate.InsertCommand = this.sqlInsertCommand1;
			this.daUnitRelate.SelectCommand = this.sqlSelectCommand1;
			this.daUnitRelate.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																								   new System.Data.Common.DataTableMapping("Table", "UnitRelate", new System.Data.Common.DataColumnMapping[] {
																																																				 new System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"),
																																																				 new System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"),
																																																				 new System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"),
																																																				 new System.Data.Common.DataColumnMapping("DataInizioValidita", "DataInizioValidita"),
																																																				 new System.Data.Common.DataColumnMapping("DataFineValidita", "DataFineValidita"),
																																																				 new System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"),
																																																				 new System.Data.Common.DataColumnMapping("Abilitata", "Abilitata"),
																																																				 new System.Data.Common.DataColumnMapping("TrUC", "TrUC"),
																																																				 new System.Data.Common.DataColumnMapping("VUC", "VUC")})});
			this.daUnitRelate.UpdateCommand = this.sqlUpdateCommand1;
			// 
			// sqlSelectCommand2
			// 
			this.sqlSelectCommand2.CommandText = @"SELECT IdContratto, CodiceContratto, DataStipula, DataInizioValidita, DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN, GestioneTaglio FROM dbo.Contratto";
			this.sqlSelectCommand2.Connection = this.cn;
			// 
			// sqlInsertCommand2
			// 
			this.sqlInsertCommand2.CommandText = @"INSERT INTO dbo.Contratto(CodiceContratto, DataStipula, DataInizioValidita, DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN, GestioneTaglio) VALUES (@CodiceContratto, @DataStipula, @DataInizioValidita, @DataFineValidita, @CRN, @StatoContratto, @CodiceOperatoreSDC, @TSModifica, @CodiceOperatoreSDCAcquirente, @CodiceOperatoreSDCCedente, @ProgrammazionePrivilegiata, @TrCN, @GestioneTaglio); SELECT IdContratto, CodiceContratto, DataStipula, DataInizioValidita, DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN, GestioneTaglio FROM dbo.Contratto WHERE (IdContratto = @@IDENTITY)";
			this.sqlInsertCommand2.Connection = this.cn;
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceContratto", System.Data.SqlDbType.VarChar, 50, "CodiceContratto"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataStipula", System.Data.SqlDbType.DateTime, 4, "DataStipula"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@StatoContratto", System.Data.SqlDbType.VarChar, 32, "StatoContratto"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCAcquirente"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCCedente"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, "ProgrammazionePrivilegiata"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TrCN", System.Data.SqlDbType.Bit, 1, "TrCN"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"));
			// 
			// sqlUpdateCommand2
			// 
			this.sqlUpdateCommand2.CommandText = "UPDATE dbo.Contratto SET CodiceContratto = @CodiceContratto, DataStipula = @DataS" +
				"tipula, DataInizioValidita = @DataInizioValidita, DataFineValidita = @DataFineVa" +
				"lidita, CRN = @CRN, StatoContratto = @StatoContratto, CodiceOperatoreSDC = @Codi" +
				"ceOperatoreSDC, TSModifica = @TSModifica, CodiceOperatoreSDCAcquirente = @Codice" +
				"OperatoreSDCAcquirente, CodiceOperatoreSDCCedente = @CodiceOperatoreSDCCedente, " +
				"ProgrammazionePrivilegiata = @ProgrammazionePrivilegiata, TrCN = @TrCN, Gestione" +
				"Taglio = @GestioneTaglio WHERE (IdContratto = @Original_IdContratto) AND (CRN = " +
				"@Original_CRN) AND (CodiceContratto = @Original_CodiceContratto) AND (CodiceOper" +
				"atoreSDC = @Original_CodiceOperatoreSDC) AND (CodiceOperatoreSDCAcquirente = @Or" +
				"iginal_CodiceOperatoreSDCAcquirente) AND (CodiceOperatoreSDCCedente = @Original_" +
				"CodiceOperatoreSDCCedente) AND (DataFineValidita = @Original_DataFineValidita) A" +
				"ND (DataInizioValidita = @Original_DataInizioValidita) AND (DataStipula = @Origi" +
				"nal_DataStipula) AND (GestioneTaglio = @Original_GestioneTaglio) AND (Programmaz" +
				"ionePrivilegiata = @Original_ProgrammazionePrivilegiata) AND (StatoContratto = @" +
				"Original_StatoContratto) AND (TSModifica = @Original_TSModifica) AND (TrCN = @Or" +
				"iginal_TrCN); SELECT IdContratto, CodiceContratto, DataStipula, DataInizioValidi" +
				"ta, DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, Codic" +
				"eOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, " +
				"TrCN, GestioneTaglio FROM dbo.Contratto WHERE (IdContratto = @IdContratto)";
			this.sqlUpdateCommand2.Connection = this.cn;
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceContratto", System.Data.SqlDbType.VarChar, 50, "CodiceContratto"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataStipula", System.Data.SqlDbType.DateTime, 4, "DataStipula"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataInizioValidita", System.Data.SqlDbType.DateTime, 4, "DataInizioValidita"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataFineValidita", System.Data.SqlDbType.DateTime, 4, "DataFineValidita"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CRN", System.Data.SqlDbType.VarChar, 30, "CRN"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@StatoContratto", System.Data.SqlDbType.VarChar, 32, "StatoContratto"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDC"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCAcquirente"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreSDCCedente"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, "ProgrammazionePrivilegiata"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TrCN", System.Data.SqlDbType.Bit, 1, "TrCN"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IdContratto", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CRN", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CRN", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceContratto", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceContratto", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreSDCAcquirente", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreSDCCedente", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataFineValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataFineValidita", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataInizioValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataInizioValidita", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataStipula", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataStipula", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GestioneTaglio", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GestioneTaglio", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgrammazionePrivilegiata", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_StatoContratto", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "StatoContratto", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSModifica", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TrCN", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TrCN", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"));
			// 
			// sqlDeleteCommand2
			// 
			this.sqlDeleteCommand2.CommandText = @"DELETE FROM dbo.Contratto WHERE (IdContratto = @Original_IdContratto) AND (CRN = @Original_CRN) AND (CodiceContratto = @Original_CodiceContratto) AND (CodiceOperatoreSDC = @Original_CodiceOperatoreSDC) AND (CodiceOperatoreSDCAcquirente = @Original_CodiceOperatoreSDCAcquirente) AND (CodiceOperatoreSDCCedente = @Original_CodiceOperatoreSDCCedente) AND (DataFineValidita = @Original_DataFineValidita) AND (DataInizioValidita = @Original_DataInizioValidita) AND (DataStipula = @Original_DataStipula) AND (GestioneTaglio = @Original_GestioneTaglio) AND (ProgrammazionePrivilegiata = @Original_ProgrammazionePrivilegiata) AND (StatoContratto = @Original_StatoContratto) AND (TSModifica = @Original_TSModifica) AND (TrCN = @Original_TrCN)";
			this.sqlDeleteCommand2.Connection = this.cn;
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IdContratto", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CRN", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CRN", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceContratto", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceContratto", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDCAcquirente", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreSDCAcquirente", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreSDCCedente", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreSDCCedente", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataFineValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataFineValidita", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataInizioValidita", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataInizioValidita", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataStipula", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataStipula", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GestioneTaglio", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GestioneTaglio", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgrammazionePrivilegiata", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgrammazionePrivilegiata", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_StatoContratto", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "StatoContratto", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSModifica", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TrCN", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TrCN", System.Data.DataRowVersion.Original, null));
			// 
			// daContratto
			// 
			this.daContratto.DeleteCommand = this.sqlDeleteCommand2;
			this.daContratto.InsertCommand = this.sqlInsertCommand2;
			this.daContratto.SelectCommand = this.sqlSelectCommand2;
			this.daContratto.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																								  new System.Data.Common.DataTableMapping("Table", "Contratto", new System.Data.Common.DataColumnMapping[] {
																																																			   new System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"),
																																																			   new System.Data.Common.DataColumnMapping("CodiceContratto", "CodiceContratto"),
																																																			   new System.Data.Common.DataColumnMapping("DataStipula", "DataStipula"),
																																																			   new System.Data.Common.DataColumnMapping("DataInizioValidita", "DataInizioValidita"),
																																																			   new System.Data.Common.DataColumnMapping("DataFineValidita", "DataFineValidita"),
																																																			   new System.Data.Common.DataColumnMapping("CRN", "CRN"),
																																																			   new System.Data.Common.DataColumnMapping("StatoContratto", "StatoContratto"),
																																																			   new System.Data.Common.DataColumnMapping("CodiceOperatoreSDC", "CodiceOperatoreSDC"),
																																																			   new System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"),
																																																			   new System.Data.Common.DataColumnMapping("CodiceOperatoreSDCAcquirente", "CodiceOperatoreSDCAcquirente"),
																																																			   new System.Data.Common.DataColumnMapping("CodiceOperatoreSDCCedente", "CodiceOperatoreSDCCedente"),
																																																			   new System.Data.Common.DataColumnMapping("ProgrammazionePrivilegiata", "ProgrammazionePrivilegiata"),
																																																			   new System.Data.Common.DataColumnMapping("TrCN", "TrCN"),
																																																			   new System.Data.Common.DataColumnMapping("GestioneTaglio", "GestioneTaglio")})});
			this.daContratto.UpdateCommand = this.sqlUpdateCommand2;
			// 
			// sqlSelectCommand3
			// 
			this.sqlSelectCommand3.CommandText = "SELECT IdContratto, DataProgramma, PeriodoRilevante, Bilanciato, TSCalcoloBilanci" +
				"amento, TSModifica, ProgrammaOrarioValidato, SbilanciamentoMWh, GestioneTaglio, " +
				"IsGMEOp, SbilanciamentoMWhReale FROM dbo.ProgrammaOrario";
			this.sqlSelectCommand3.Connection = this.cn;
			// 
			// sqlInsertCommand3
			// 
			this.sqlInsertCommand3.CommandText = @"INSERT INTO dbo.ProgrammaOrario(IdContratto, DataProgramma, PeriodoRilevante, Bilanciato, TSCalcoloBilanciamento, TSModifica, ProgrammaOrarioValidato, SbilanciamentoMWh, GestioneTaglio, IsGMEOp, SbilanciamentoMWhReale) VALUES (@IdContratto, @DataProgramma, @PeriodoRilevante, @Bilanciato, @TSCalcoloBilanciamento, @TSModifica, @ProgrammaOrarioValidato, @SbilanciamentoMWh, @GestioneTaglio, @IsGMEOp, @SbilanciamentoMWhReale); SELECT IdContratto, DataProgramma, PeriodoRilevante, Bilanciato, TSCalcoloBilanciamento, TSModifica, ProgrammaOrarioValidato, SbilanciamentoMWh, GestioneTaglio, IsGMEOp, SbilanciamentoMWhReale FROM dbo.ProgrammaOrario WHERE (DataProgramma = @DataProgramma) AND (IdContratto = @IdContratto) AND (PeriodoRilevante = @PeriodoRilevante)";
			this.sqlInsertCommand3.Connection = this.cn;
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Bilanciato", System.Data.SqlDbType.Bit, 1, "Bilanciato"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCalcoloBilanciamento", System.Data.SqlDbType.DateTime, 8, "TSCalcoloBilanciamento"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgrammaOrarioValidato", System.Data.SqlDbType.Bit, 1, "ProgrammaOrarioValidato"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SbilanciamentoMWh", System.Data.SqlDbType.Float, 8, "SbilanciamentoMWh"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IsGMEOp", System.Data.SqlDbType.Bit, 1, "IsGMEOp"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SbilanciamentoMWhReale", System.Data.SqlDbType.Float, 8, "SbilanciamentoMWhReale"));
			// 
			// sqlUpdateCommand3
			// 
			this.sqlUpdateCommand3.CommandText = "UPDATE dbo.ProgrammaOrario SET IdContratto = @IdContratto, DataProgramma = @DataP" +
				"rogramma, PeriodoRilevante = @PeriodoRilevante, Bilanciato = @Bilanciato, TSCalc" +
				"oloBilanciamento = @TSCalcoloBilanciamento, TSModifica = @TSModifica, ProgrammaO" +
				"rarioValidato = @ProgrammaOrarioValidato, SbilanciamentoMWh = @SbilanciamentoMWh" +
				", GestioneTaglio = @GestioneTaglio, IsGMEOp = @IsGMEOp, SbilanciamentoMWhReale =" +
				" @SbilanciamentoMWhReale WHERE (DataProgramma = @Original_DataProgramma) AND (Id" +
				"Contratto = @Original_IdContratto) AND (PeriodoRilevante = @Original_PeriodoRile" +
				"vante) AND (Bilanciato = @Original_Bilanciato OR @Original_Bilanciato IS NULL AN" +
				"D Bilanciato IS NULL) AND (GestioneTaglio = @Original_GestioneTaglio OR @Origina" +
				"l_GestioneTaglio IS NULL AND GestioneTaglio IS NULL) AND (IsGMEOp = @Original_Is" +
				"GMEOp OR @Original_IsGMEOp IS NULL AND IsGMEOp IS NULL) AND (ProgrammaOrarioVali" +
				"dato = @Original_ProgrammaOrarioValidato) AND (SbilanciamentoMWh = @Original_Sbi" +
				"lanciamentoMWh OR @Original_SbilanciamentoMWh IS NULL AND SbilanciamentoMWh IS N" +
				"ULL) AND (SbilanciamentoMWhReale = @Original_SbilanciamentoMWhReale OR @Original" +
				"_SbilanciamentoMWhReale IS NULL AND SbilanciamentoMWhReale IS NULL) AND (TSCalco" +
				"loBilanciamento = @Original_TSCalcoloBilanciamento OR @Original_TSCalcoloBilanci" +
				"amento IS NULL AND TSCalcoloBilanciamento IS NULL) AND (TSModifica = @Original_T" +
				"SModifica); SELECT IdContratto, DataProgramma, PeriodoRilevante, Bilanciato, TSC" +
				"alcoloBilanciamento, TSModifica, ProgrammaOrarioValidato, SbilanciamentoMWh, Ges" +
				"tioneTaglio, IsGMEOp, SbilanciamentoMWhReale FROM dbo.ProgrammaOrario WHERE (Dat" +
				"aProgramma = @DataProgramma) AND (IdContratto = @IdContratto) AND (PeriodoRileva" +
				"nte = @PeriodoRilevante)";
			this.sqlUpdateCommand3.Connection = this.cn;
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Bilanciato", System.Data.SqlDbType.Bit, 1, "Bilanciato"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSCalcoloBilanciamento", System.Data.SqlDbType.DateTime, 8, "TSCalcoloBilanciamento"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgrammaOrarioValidato", System.Data.SqlDbType.Bit, 1, "ProgrammaOrarioValidato"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SbilanciamentoMWh", System.Data.SqlDbType.Float, 8, "SbilanciamentoMWh"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@GestioneTaglio", System.Data.SqlDbType.VarChar, 1, "GestioneTaglio"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IsGMEOp", System.Data.SqlDbType.Bit, 1, "IsGMEOp"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SbilanciamentoMWhReale", System.Data.SqlDbType.Float, 8, "SbilanciamentoMWhReale"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataProgramma", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IdContratto", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PeriodoRilevante", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Bilanciato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Bilanciato", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GestioneTaglio", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GestioneTaglio", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IsGMEOp", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IsGMEOp", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgrammaOrarioValidato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgrammaOrarioValidato", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SbilanciamentoMWh", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SbilanciamentoMWh", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SbilanciamentoMWhReale", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SbilanciamentoMWhReale", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSCalcoloBilanciamento", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSCalcoloBilanciamento", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSModifica", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand3
			// 
			this.sqlDeleteCommand3.CommandText = @"DELETE FROM dbo.ProgrammaOrario WHERE (DataProgramma = @Original_DataProgramma) AND (IdContratto = @Original_IdContratto) AND (PeriodoRilevante = @Original_PeriodoRilevante) AND (Bilanciato = @Original_Bilanciato OR @Original_Bilanciato IS NULL AND Bilanciato IS NULL) AND (GestioneTaglio = @Original_GestioneTaglio OR @Original_GestioneTaglio IS NULL AND GestioneTaglio IS NULL) AND (IsGMEOp = @Original_IsGMEOp OR @Original_IsGMEOp IS NULL AND IsGMEOp IS NULL) AND (ProgrammaOrarioValidato = @Original_ProgrammaOrarioValidato) AND (SbilanciamentoMWh = @Original_SbilanciamentoMWh OR @Original_SbilanciamentoMWh IS NULL AND SbilanciamentoMWh IS NULL) AND (SbilanciamentoMWhReale = @Original_SbilanciamentoMWhReale OR @Original_SbilanciamentoMWhReale IS NULL AND SbilanciamentoMWhReale IS NULL) AND (TSCalcoloBilanciamento = @Original_TSCalcoloBilanciamento OR @Original_TSCalcoloBilanciamento IS NULL AND TSCalcoloBilanciamento IS NULL) AND (TSModifica = @Original_TSModifica)";
			this.sqlDeleteCommand3.Connection = this.cn;
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataProgramma", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IdContratto", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PeriodoRilevante", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Bilanciato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Bilanciato", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GestioneTaglio", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GestioneTaglio", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IsGMEOp", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IsGMEOp", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgrammaOrarioValidato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgrammaOrarioValidato", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SbilanciamentoMWh", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SbilanciamentoMWh", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SbilanciamentoMWhReale", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SbilanciamentoMWhReale", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSCalcoloBilanciamento", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSCalcoloBilanciamento", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSModifica", System.Data.DataRowVersion.Original, null));
			// 
			// daProgrammaOrario
			// 
			this.daProgrammaOrario.DeleteCommand = this.sqlDeleteCommand3;
			this.daProgrammaOrario.InsertCommand = this.sqlInsertCommand3;
			this.daProgrammaOrario.SelectCommand = this.sqlSelectCommand3;
			this.daProgrammaOrario.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										new System.Data.Common.DataTableMapping("Table", "ProgrammaOrario", new System.Data.Common.DataColumnMapping[] {
																																																						   new System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"),
																																																						   new System.Data.Common.DataColumnMapping("DataProgramma", "DataProgramma"),
																																																						   new System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"),
																																																						   new System.Data.Common.DataColumnMapping("Bilanciato", "Bilanciato"),
																																																						   new System.Data.Common.DataColumnMapping("TSCalcoloBilanciamento", "TSCalcoloBilanciamento"),
																																																						   new System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"),
																																																						   new System.Data.Common.DataColumnMapping("ProgrammaOrarioValidato", "ProgrammaOrarioValidato"),
																																																						   new System.Data.Common.DataColumnMapping("SbilanciamentoMWh", "SbilanciamentoMWh"),
																																																						   new System.Data.Common.DataColumnMapping("GestioneTaglio", "GestioneTaglio"),
																																																						   new System.Data.Common.DataColumnMapping("IsGMEOp", "IsGMEOp"),
																																																						   new System.Data.Common.DataColumnMapping("SbilanciamentoMWhReale", "SbilanciamentoMWhReale")})});
			this.daProgrammaOrario.UpdateCommand = this.sqlUpdateCommand3;
			// 
			// sqlSelectCommand4
			// 
			this.sqlSelectCommand4.CommandText = @"SELECT IdContratto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUnitaSDC, QtyMWh, ProgOrarioDellUnitaValidato, QtyMWhBilanciamento, QtyMWhAssegnataMGP, IdProgrammaXml, ProgressivoNelProgramma, ProgrammatoDalCedente, GMEReferenceNumber FROM dbo.ProgrammaOrarioPerUnita";
			this.sqlSelectCommand4.Connection = this.cn;
			// 
			// sqlInsertCommand4
			// 
			this.sqlInsertCommand4.CommandText = @"INSERT INTO dbo.ProgrammaOrarioPerUnita(IdContratto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUnitaSDC, QtyMWh, ProgOrarioDellUnitaValidato, QtyMWhBilanciamento, QtyMWhAssegnataMGP, IdProgrammaXml, ProgressivoNelProgramma, ProgrammatoDalCedente, GMEReferenceNumber) VALUES (@IdContratto, @DataProgramma, @PeriodoRilevante, @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @ProgOrarioDellUnitaValidato, @QtyMWhBilanciamento, @QtyMWhAssegnataMGP, @IdProgrammaXml, @ProgressivoNelProgramma, @ProgrammatoDalCedente, @GMEReferenceNumber); SELECT IdContratto, DataProgramma, PeriodoRilevante, CodiceUnitaSDC, CategoriaUnitaSDC, QtyMWh, ProgOrarioDellUnitaValidato, QtyMWhBilanciamento, QtyMWhAssegnataMGP, IdProgrammaXml, ProgressivoNelProgramma, ProgrammatoDalCedente, GMEReferenceNumber FROM dbo.ProgrammaOrarioPerUnita WHERE (CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC) AND (DataProgramma = @DataProgramma) AND (IdContratto = @IdContratto) AND (PeriodoRilevante = @PeriodoRilevante)";
			this.sqlInsertCommand4.Connection = this.cn;
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@QtyMWh", System.Data.SqlDbType.Float, 8, "QtyMWh"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgOrarioDellUnitaValidato", System.Data.SqlDbType.Bit, 1, "ProgOrarioDellUnitaValidato"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@QtyMWhBilanciamento", System.Data.SqlDbType.Float, 8, "QtyMWhBilanciamento"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@QtyMWhAssegnataMGP", System.Data.SqlDbType.Float, 8, "QtyMWhAssegnataMGP"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IdProgrammaXml", System.Data.SqlDbType.Int, 4, "IdProgrammaXml"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgressivoNelProgramma", System.Data.SqlDbType.Int, 4, "ProgressivoNelProgramma"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgrammatoDalCedente", System.Data.SqlDbType.Bit, 1, "ProgrammatoDalCedente"));
			this.sqlInsertCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@GMEReferenceNumber", System.Data.SqlDbType.VarChar, 30, "GMEReferenceNumber"));
			// 
			// sqlUpdateCommand4
			// 
			this.sqlUpdateCommand4.CommandText = "UPDATE dbo.ProgrammaOrarioPerUnita SET IdContratto = @IdContratto, DataProgramma " +
				"= @DataProgramma, PeriodoRilevante = @PeriodoRilevante, CodiceUnitaSDC = @Codice" +
				"UnitaSDC, CategoriaUnitaSDC = @CategoriaUnitaSDC, QtyMWh = @QtyMWh, ProgOrarioDe" +
				"llUnitaValidato = @ProgOrarioDellUnitaValidato, QtyMWhBilanciamento = @QtyMWhBil" +
				"anciamento, QtyMWhAssegnataMGP = @QtyMWhAssegnataMGP, IdProgrammaXml = @IdProgra" +
				"mmaXml, ProgressivoNelProgramma = @ProgressivoNelProgramma, ProgrammatoDalCedent" +
				"e = @ProgrammatoDalCedente, GMEReferenceNumber = @GMEReferenceNumber WHERE (Cate" +
				"goriaUnitaSDC = @Original_CategoriaUnitaSDC) AND (CodiceUnitaSDC = @Original_Cod" +
				"iceUnitaSDC) AND (DataProgramma = @Original_DataProgramma) AND (IdContratto = @O" +
				"riginal_IdContratto) AND (PeriodoRilevante = @Original_PeriodoRilevante) AND (GM" +
				"EReferenceNumber = @Original_GMEReferenceNumber OR @Original_GMEReferenceNumber " +
				"IS NULL AND GMEReferenceNumber IS NULL) AND (IdProgrammaXml = @Original_IdProgra" +
				"mmaXml) AND (ProgOrarioDellUnitaValidato = @Original_ProgOrarioDellUnitaValidato" +
				") AND (ProgrammatoDalCedente = @Original_ProgrammatoDalCedente) AND (Progressivo" +
				"NelProgramma = @Original_ProgressivoNelProgramma) AND (QtyMWh = @Original_QtyMWh" +
				") AND (QtyMWhAssegnataMGP = @Original_QtyMWhAssegnataMGP OR @Original_QtyMWhAsse" +
				"gnataMGP IS NULL AND QtyMWhAssegnataMGP IS NULL) AND (QtyMWhBilanciamento = @Ori" +
				"ginal_QtyMWhBilanciamento OR @Original_QtyMWhBilanciamento IS NULL AND QtyMWhBil" +
				"anciamento IS NULL); SELECT IdContratto, DataProgramma, PeriodoRilevante, Codice" +
				"UnitaSDC, CategoriaUnitaSDC, QtyMWh, ProgOrarioDellUnitaValidato, QtyMWhBilancia" +
				"mento, QtyMWhAssegnataMGP, IdProgrammaXml, ProgressivoNelProgramma, ProgrammatoD" +
				"alCedente, GMEReferenceNumber FROM dbo.ProgrammaOrarioPerUnita WHERE (CategoriaU" +
				"nitaSDC = @CategoriaUnitaSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC) AND (DataPr" +
				"ogramma = @DataProgramma) AND (IdContratto = @IdContratto) AND (PeriodoRilevante" +
				" = @PeriodoRilevante)";
			this.sqlUpdateCommand4.Connection = this.cn;
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IdContratto", System.Data.SqlDbType.Int, 4, "IdContratto"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DataProgramma", System.Data.SqlDbType.DateTime, 4, "DataProgramma"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, "PeriodoRilevante"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@QtyMWh", System.Data.SqlDbType.Float, 8, "QtyMWh"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgOrarioDellUnitaValidato", System.Data.SqlDbType.Bit, 1, "ProgOrarioDellUnitaValidato"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@QtyMWhBilanciamento", System.Data.SqlDbType.Float, 8, "QtyMWhBilanciamento"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@QtyMWhAssegnataMGP", System.Data.SqlDbType.Float, 8, "QtyMWhAssegnataMGP"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@IdProgrammaXml", System.Data.SqlDbType.Int, 4, "IdProgrammaXml"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgressivoNelProgramma", System.Data.SqlDbType.Int, 4, "ProgressivoNelProgramma"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgrammatoDalCedente", System.Data.SqlDbType.Bit, 1, "ProgrammatoDalCedente"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@GMEReferenceNumber", System.Data.SqlDbType.VarChar, 30, "GMEReferenceNumber"));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataProgramma", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IdContratto", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PeriodoRilevante", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GMEReferenceNumber", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GMEReferenceNumber", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IdProgrammaXml", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IdProgrammaXml", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgOrarioDellUnitaValidato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgOrarioDellUnitaValidato", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgrammatoDalCedente", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgrammatoDalCedente", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgressivoNelProgramma", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgressivoNelProgramma", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_QtyMWh", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "QtyMWh", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_QtyMWhAssegnataMGP", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "QtyMWhAssegnataMGP", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_QtyMWhBilanciamento", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "QtyMWhBilanciamento", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand4
			// 
			this.sqlDeleteCommand4.CommandText = @"DELETE FROM dbo.ProgrammaOrarioPerUnita WHERE (CategoriaUnitaSDC = @Original_CategoriaUnitaSDC) AND (CodiceUnitaSDC = @Original_CodiceUnitaSDC) AND (DataProgramma = @Original_DataProgramma) AND (IdContratto = @Original_IdContratto) AND (PeriodoRilevante = @Original_PeriodoRilevante) AND (GMEReferenceNumber = @Original_GMEReferenceNumber OR @Original_GMEReferenceNumber IS NULL AND GMEReferenceNumber IS NULL) AND (IdProgrammaXml = @Original_IdProgrammaXml) AND (ProgOrarioDellUnitaValidato = @Original_ProgOrarioDellUnitaValidato) AND (ProgrammatoDalCedente = @Original_ProgrammatoDalCedente) AND (ProgressivoNelProgramma = @Original_ProgressivoNelProgramma) AND (QtyMWh = @Original_QtyMWh) AND (QtyMWhAssegnataMGP = @Original_QtyMWhAssegnataMGP OR @Original_QtyMWhAssegnataMGP IS NULL AND QtyMWhAssegnataMGP IS NULL) AND (QtyMWhBilanciamento = @Original_QtyMWhBilanciamento OR @Original_QtyMWhBilanciamento IS NULL AND QtyMWhBilanciamento IS NULL)";
			this.sqlDeleteCommand4.Connection = this.cn;
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DataProgramma", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DataProgramma", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IdContratto", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IdContratto", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PeriodoRilevante", System.Data.SqlDbType.TinyInt, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PeriodoRilevante", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GMEReferenceNumber", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GMEReferenceNumber", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_IdProgrammaXml", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "IdProgrammaXml", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgOrarioDellUnitaValidato", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgOrarioDellUnitaValidato", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgrammatoDalCedente", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgrammatoDalCedente", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgressivoNelProgramma", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgressivoNelProgramma", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_QtyMWh", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "QtyMWh", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_QtyMWhAssegnataMGP", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "QtyMWhAssegnataMGP", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand4.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_QtyMWhBilanciamento", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "QtyMWhBilanciamento", System.Data.DataRowVersion.Original, null));
			// 
			// daProgrammaOrarioPerUnita
			// 
			this.daProgrammaOrarioPerUnita.DeleteCommand = this.sqlDeleteCommand4;
			this.daProgrammaOrarioPerUnita.InsertCommand = this.sqlInsertCommand4;
			this.daProgrammaOrarioPerUnita.SelectCommand = this.sqlSelectCommand4;
			this.daProgrammaOrarioPerUnita.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																												new System.Data.Common.DataTableMapping("Table", "ProgrammaOrarioPerUnita", new System.Data.Common.DataColumnMapping[] {
																																																										   new System.Data.Common.DataColumnMapping("IdContratto", "IdContratto"),
																																																										   new System.Data.Common.DataColumnMapping("DataProgramma", "DataProgramma"),
																																																										   new System.Data.Common.DataColumnMapping("PeriodoRilevante", "PeriodoRilevante"),
																																																										   new System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"),
																																																										   new System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"),
																																																										   new System.Data.Common.DataColumnMapping("QtyMWh", "QtyMWh"),
																																																										   new System.Data.Common.DataColumnMapping("ProgOrarioDellUnitaValidato", "ProgOrarioDellUnitaValidato"),
																																																										   new System.Data.Common.DataColumnMapping("QtyMWhBilanciamento", "QtyMWhBilanciamento"),
																																																										   new System.Data.Common.DataColumnMapping("QtyMWhAssegnataMGP", "QtyMWhAssegnataMGP"),
																																																										   new System.Data.Common.DataColumnMapping("IdProgrammaXml", "IdProgrammaXml"),
																																																										   new System.Data.Common.DataColumnMapping("ProgressivoNelProgramma", "ProgressivoNelProgramma"),
																																																										   new System.Data.Common.DataColumnMapping("ProgrammatoDalCedente", "ProgrammatoDalCedente"),
																																																										   new System.Data.Common.DataColumnMapping("GMEReferenceNumber", "GMEReferenceNumber")})});
			this.daProgrammaOrarioPerUnita.UpdateCommand = this.sqlUpdateCommand4;
			// 
			// sqlSelectCommand5
			// 
			this.sqlSelectCommand5.CommandText = @"SELECT CodiceUnitaSDC, CategoriaUnitaSDC, NomeUnita, TipoUnita, CoefficientePerdita, CodicePuntoDiScambioRilevanteSDC, PotenzaMassimaMWh, PotenzaMinimaMWh, OrdineDiMerito, CodiceOperatoreDiRiferimentoSDC, Abilitata, TSModifica, ResponsabileAggiornamento, UnbalancedParticipantNumber, SottotipoUnita, InjectionOrWithdrawalPointNumber, MustRun FROM dbo.SDC_Unita";
			this.sqlSelectCommand5.Connection = this.cn;
			// 
			// sqlInsertCommand5
			// 
			this.sqlInsertCommand5.CommandText = @"INSERT INTO dbo.SDC_Unita(CodiceUnitaSDC, CategoriaUnitaSDC, NomeUnita, TipoUnita, CoefficientePerdita, CodicePuntoDiScambioRilevanteSDC, PotenzaMassimaMWh, PotenzaMinimaMWh, OrdineDiMerito, CodiceOperatoreDiRiferimentoSDC, Abilitata, TSModifica, ResponsabileAggiornamento, UnbalancedParticipantNumber, SottotipoUnita, InjectionOrWithdrawalPointNumber, MustRun) VALUES (@CodiceUnitaSDC, @CategoriaUnitaSDC, @NomeUnita, @TipoUnita, @CoefficientePerdita, @CodicePuntoDiScambioRilevanteSDC, @PotenzaMassimaMWh, @PotenzaMinimaMWh, @OrdineDiMerito, @CodiceOperatoreDiRiferimentoSDC, @Abilitata, @TSModifica, @ResponsabileAggiornamento, @UnbalancedParticipantNumber, @SottotipoUnita, @InjectionOrWithdrawalPointNumber, @MustRun); SELECT CodiceUnitaSDC, CategoriaUnitaSDC, NomeUnita, TipoUnita, CoefficientePerdita, CodicePuntoDiScambioRilevanteSDC, PotenzaMassimaMWh, PotenzaMinimaMWh, OrdineDiMerito, CodiceOperatoreDiRiferimentoSDC, Abilitata, TSModifica, ResponsabileAggiornamento, UnbalancedParticipantNumber, SottotipoUnita, InjectionOrWithdrawalPointNumber, MustRun FROM dbo.SDC_Unita WHERE (CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (CodiceUnitaSDC = @CodiceUnitaSDC)";
			this.sqlInsertCommand5.Connection = this.cn;
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@NomeUnita", System.Data.SqlDbType.VarChar, 256, "NomeUnita"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TipoUnita", System.Data.SqlDbType.VarChar, 1, "TipoUnita"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CoefficientePerdita", System.Data.SqlDbType.Float, 8, "CoefficientePerdita"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, "CodicePuntoDiScambioRilevanteSDC"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PotenzaMassimaMWh", System.Data.SqlDbType.Float, 8, "PotenzaMassimaMWh"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PotenzaMinimaMWh", System.Data.SqlDbType.Float, 8, "PotenzaMinimaMWh"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OrdineDiMerito", System.Data.SqlDbType.Float, 8, "OrdineDiMerito"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreDiRiferimentoSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreDiRiferimentoSDC"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UnbalancedParticipantNumber", System.Data.SqlDbType.VarChar, 60, "UnbalancedParticipantNumber"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SottotipoUnita", System.Data.SqlDbType.VarChar, 100, "SottotipoUnita"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@InjectionOrWithdrawalPointNumber", System.Data.SqlDbType.VarChar, 16, "InjectionOrWithdrawalPointNumber"));
			this.sqlInsertCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@MustRun", System.Data.SqlDbType.VarChar, 256, "MustRun"));
			// 
			// sqlUpdateCommand5
			// 
			this.sqlUpdateCommand5.CommandText = "UPDATE dbo.SDC_Unita SET CodiceUnitaSDC = @CodiceUnitaSDC, CategoriaUnitaSDC = @C" +
				"ategoriaUnitaSDC, NomeUnita = @NomeUnita, TipoUnita = @TipoUnita, CoefficientePe" +
				"rdita = @CoefficientePerdita, CodicePuntoDiScambioRilevanteSDC = @CodicePuntoDiS" +
				"cambioRilevanteSDC, PotenzaMassimaMWh = @PotenzaMassimaMWh, PotenzaMinimaMWh = @" +
				"PotenzaMinimaMWh, OrdineDiMerito = @OrdineDiMerito, CodiceOperatoreDiRiferimento" +
				"SDC = @CodiceOperatoreDiRiferimentoSDC, Abilitata = @Abilitata, TSModifica = @TS" +
				"Modifica, ResponsabileAggiornamento = @ResponsabileAggiornamento, UnbalancedPart" +
				"icipantNumber = @UnbalancedParticipantNumber, SottotipoUnita = @SottotipoUnita, " +
				"InjectionOrWithdrawalPointNumber = @InjectionOrWithdrawalPointNumber, MustRun = " +
				"@MustRun WHERE (CategoriaUnitaSDC = @Original_CategoriaUnitaSDC) AND (CodiceUnit" +
				"aSDC = @Original_CodiceUnitaSDC) AND (Abilitata = @Original_Abilitata) AND (Codi" +
				"ceOperatoreDiRiferimentoSDC = @Original_CodiceOperatoreDiRiferimentoSDC) AND (Co" +
				"dicePuntoDiScambioRilevanteSDC = @Original_CodicePuntoDiScambioRilevanteSDC) AND" +
				" (CoefficientePerdita = @Original_CoefficientePerdita) AND (InjectionOrWithdrawa" +
				"lPointNumber = @Original_InjectionOrWithdrawalPointNumber OR @Original_Injection" +
				"OrWithdrawalPointNumber IS NULL AND InjectionOrWithdrawalPointNumber IS NULL) AN" +
				"D (MustRun = @Original_MustRun OR @Original_MustRun IS NULL AND MustRun IS NULL)" +
				" AND (NomeUnita = @Original_NomeUnita) AND (OrdineDiMerito = @Original_OrdineDiM" +
				"erito) AND (PotenzaMassimaMWh = @Original_PotenzaMassimaMWh) AND (PotenzaMinimaM" +
				"Wh = @Original_PotenzaMinimaMWh) AND (ResponsabileAggiornamento = @Original_Resp" +
				"onsabileAggiornamento) AND (SottotipoUnita = @Original_SottotipoUnita) AND (TSMo" +
				"difica = @Original_TSModifica) AND (TipoUnita = @Original_TipoUnita) AND (Unbala" +
				"ncedParticipantNumber = @Original_UnbalancedParticipantNumber); SELECT CodiceUni" +
				"taSDC, CategoriaUnitaSDC, NomeUnita, TipoUnita, CoefficientePerdita, CodicePunto" +
				"DiScambioRilevanteSDC, PotenzaMassimaMWh, PotenzaMinimaMWh, OrdineDiMerito, Codi" +
				"ceOperatoreDiRiferimentoSDC, Abilitata, TSModifica, ResponsabileAggiornamento, U" +
				"nbalancedParticipantNumber, SottotipoUnita, InjectionOrWithdrawalPointNumber, Mu" +
				"stRun FROM dbo.SDC_Unita WHERE (CategoriaUnitaSDC = @CategoriaUnitaSDC) AND (Cod" +
				"iceUnitaSDC = @CodiceUnitaSDC)";
			this.sqlUpdateCommand5.Connection = this.cn;
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, "CodiceUnitaSDC"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, "CategoriaUnitaSDC"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@NomeUnita", System.Data.SqlDbType.VarChar, 256, "NomeUnita"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TipoUnita", System.Data.SqlDbType.VarChar, 1, "TipoUnita"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CoefficientePerdita", System.Data.SqlDbType.Float, 8, "CoefficientePerdita"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, "CodicePuntoDiScambioRilevanteSDC"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PotenzaMassimaMWh", System.Data.SqlDbType.Float, 8, "PotenzaMassimaMWh"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PotenzaMinimaMWh", System.Data.SqlDbType.Float, 8, "PotenzaMinimaMWh"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OrdineDiMerito", System.Data.SqlDbType.Float, 8, "OrdineDiMerito"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CodiceOperatoreDiRiferimentoSDC", System.Data.SqlDbType.VarChar, 16, "CodiceOperatoreDiRiferimentoSDC"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Abilitata", System.Data.SqlDbType.Bit, 1, "Abilitata"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TSModifica", System.Data.SqlDbType.DateTime, 8, "TSModifica"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, "ResponsabileAggiornamento"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UnbalancedParticipantNumber", System.Data.SqlDbType.VarChar, 60, "UnbalancedParticipantNumber"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SottotipoUnita", System.Data.SqlDbType.VarChar, 100, "SottotipoUnita"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@InjectionOrWithdrawalPointNumber", System.Data.SqlDbType.VarChar, 16, "InjectionOrWithdrawalPointNumber"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@MustRun", System.Data.SqlDbType.VarChar, 256, "MustRun"));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Abilitata", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Abilitata", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreDiRiferimentoSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreDiRiferimentoSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodicePuntoDiScambioRilevanteSDC", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CoefficientePerdita", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CoefficientePerdita", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_InjectionOrWithdrawalPointNumber", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "InjectionOrWithdrawalPointNumber", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_MustRun", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "MustRun", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_NomeUnita", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "NomeUnita", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OrdineDiMerito", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OrdineDiMerito", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PotenzaMassimaMWh", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PotenzaMassimaMWh", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PotenzaMinimaMWh", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PotenzaMinimaMWh", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ResponsabileAggiornamento", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SottotipoUnita", System.Data.SqlDbType.VarChar, 100, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SottotipoUnita", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSModifica", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TipoUnita", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TipoUnita", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_UnbalancedParticipantNumber", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "UnbalancedParticipantNumber", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand5
			// 
			this.sqlDeleteCommand5.CommandText = @"DELETE FROM dbo.SDC_Unita WHERE (CategoriaUnitaSDC = @Original_CategoriaUnitaSDC) AND (CodiceUnitaSDC = @Original_CodiceUnitaSDC) AND (Abilitata = @Original_Abilitata) AND (CodiceOperatoreDiRiferimentoSDC = @Original_CodiceOperatoreDiRiferimentoSDC) AND (CodicePuntoDiScambioRilevanteSDC = @Original_CodicePuntoDiScambioRilevanteSDC) AND (CoefficientePerdita = @Original_CoefficientePerdita) AND (InjectionOrWithdrawalPointNumber = @Original_InjectionOrWithdrawalPointNumber OR @Original_InjectionOrWithdrawalPointNumber IS NULL AND InjectionOrWithdrawalPointNumber IS NULL) AND (MustRun = @Original_MustRun OR @Original_MustRun IS NULL AND MustRun IS NULL) AND (NomeUnita = @Original_NomeUnita) AND (OrdineDiMerito = @Original_OrdineDiMerito) AND (PotenzaMassimaMWh = @Original_PotenzaMassimaMWh) AND (PotenzaMinimaMWh = @Original_PotenzaMinimaMWh) AND (ResponsabileAggiornamento = @Original_ResponsabileAggiornamento) AND (SottotipoUnita = @Original_SottotipoUnita) AND (TSModifica = @Original_TSModifica) AND (TipoUnita = @Original_TipoUnita) AND (UnbalancedParticipantNumber = @Original_UnbalancedParticipantNumber)";
			this.sqlDeleteCommand5.Connection = this.cn;
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CategoriaUnitaSDC", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CategoriaUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceUnitaSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceUnitaSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Abilitata", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Abilitata", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodiceOperatoreDiRiferimentoSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodiceOperatoreDiRiferimentoSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CodicePuntoDiScambioRilevanteSDC", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CodicePuntoDiScambioRilevanteSDC", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CoefficientePerdita", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CoefficientePerdita", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_InjectionOrWithdrawalPointNumber", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "InjectionOrWithdrawalPointNumber", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_MustRun", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "MustRun", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_NomeUnita", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "NomeUnita", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OrdineDiMerito", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OrdineDiMerito", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PotenzaMassimaMWh", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PotenzaMassimaMWh", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PotenzaMinimaMWh", System.Data.SqlDbType.Float, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PotenzaMinimaMWh", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ResponsabileAggiornamento", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ResponsabileAggiornamento", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SottotipoUnita", System.Data.SqlDbType.VarChar, 100, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SottotipoUnita", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TSModifica", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TSModifica", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_TipoUnita", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "TipoUnita", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand5.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_UnbalancedParticipantNumber", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "UnbalancedParticipantNumber", System.Data.DataRowVersion.Original, null));
			// 
			// daSDC_Unita
			// 
			this.daSDC_Unita.DeleteCommand = this.sqlDeleteCommand5;
			this.daSDC_Unita.InsertCommand = this.sqlInsertCommand5;
			this.daSDC_Unita.SelectCommand = this.sqlSelectCommand5;
			this.daSDC_Unita.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																								  new System.Data.Common.DataTableMapping("Table", "SDC_Unita", new System.Data.Common.DataColumnMapping[] {
																																																			   new System.Data.Common.DataColumnMapping("CodiceUnitaSDC", "CodiceUnitaSDC"),
																																																			   new System.Data.Common.DataColumnMapping("CategoriaUnitaSDC", "CategoriaUnitaSDC"),
																																																			   new System.Data.Common.DataColumnMapping("NomeUnita", "NomeUnita"),
																																																			   new System.Data.Common.DataColumnMapping("TipoUnita", "TipoUnita"),
																																																			   new System.Data.Common.DataColumnMapping("CoefficientePerdita", "CoefficientePerdita"),
																																																			   new System.Data.Common.DataColumnMapping("CodicePuntoDiScambioRilevanteSDC", "CodicePuntoDiScambioRilevanteSDC"),
																																																			   new System.Data.Common.DataColumnMapping("PotenzaMassimaMWh", "PotenzaMassimaMWh"),
																																																			   new System.Data.Common.DataColumnMapping("PotenzaMinimaMWh", "PotenzaMinimaMWh"),
																																																			   new System.Data.Common.DataColumnMapping("OrdineDiMerito", "OrdineDiMerito"),
																																																			   new System.Data.Common.DataColumnMapping("CodiceOperatoreDiRiferimentoSDC", "CodiceOperatoreDiRiferimentoSDC"),
																																																			   new System.Data.Common.DataColumnMapping("Abilitata", "Abilitata"),
																																																			   new System.Data.Common.DataColumnMapping("TSModifica", "TSModifica"),
																																																			   new System.Data.Common.DataColumnMapping("ResponsabileAggiornamento", "ResponsabileAggiornamento"),
																																																			   new System.Data.Common.DataColumnMapping("UnbalancedParticipantNumber", "UnbalancedParticipantNumber"),
																																																			   new System.Data.Common.DataColumnMapping("SottotipoUnita", "SottotipoUnita"),
																																																			   new System.Data.Common.DataColumnMapping("InjectionOrWithdrawalPointNumber", "InjectionOrWithdrawalPointNumber"),
																																																			   new System.Data.Common.DataColumnMapping("MustRun", "MustRun")})});
			this.daSDC_Unita.UpdateCommand = this.sqlUpdateCommand5;
			// 
			// ds
			// 
			this.ds.DataSetName = "DS";
			this.ds.Locale = new System.Globalization.CultureInfo("it-IT");
			// 
			// btnCaricaDati
			// 
			this.btnCaricaDati.Location = new System.Drawing.Point(16, 16);
			this.btnCaricaDati.Name = "btnCaricaDati";
			this.btnCaricaDati.TabIndex = 0;
			this.btnCaricaDati.Text = "Carica dati dal DB";
			this.btnCaricaDati.Click += new System.EventHandler(this.btnCaricaDati_Click);
			// 
			// tbStress
			// 
			this.tbStress.Location = new System.Drawing.Point(16, 48);
			this.tbStress.Multiline = true;
			this.tbStress.Name = "tbStress";
			this.tbStress.Size = new System.Drawing.Size(760, 280);
			this.tbStress.TabIndex = 1;
			this.tbStress.Text = "";
			// 
			// DbFill
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(800, 413);
			this.Controls.Add(this.tbStress);
			this.Controls.Add(this.btnCaricaDati);
			this.Name = "DbFill";
			this.Text = "DbFill";
			((System.ComponentModel.ISupportInitialize)(this.ds)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion


		/*
		private void CreaContratti()
		{
			try
			{
				cn.ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["SqlConnectionString"];
				cn.Open();

				daContratto.Fill(ds.Contratto);


			}
			finally
			{
				if (cn.State == ConnectionState.Open)
					cn.Close();
			}
		}
		*/

		public delegate void pmsg(string s);
		private pmsg ddd;

		private void Msg(string s)
		{
			Debug.WriteLine(s);

//			if (this.InvokeRequired)
//			{
//				this.Invoke(ddd, new object[] {s} );
//			}
//			else
//			{
//				if (this.tbStress.Lines.Length > 1000)
//				{
//					this.tbStress.Text = "";
//					this.tbStress.Invalidate();
//					this.tbStress.Update();
//				}
//
//				this.tbStress.AppendText(s + "\r\n");
//			}
		}



		private void btnCaricaDati_Click(object sender, System.EventArgs e)
		{
			ddd = new pmsg(Msg);
			ThreadPool.QueueUserWorkItem(new WaitCallback(FillDb));
		}

		void FillDb(object tt)
		{
			try
			{
				cn.ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["SqlConnectionString"];
				cn.Open();

				daContratto.Fill(ds.Contratto);
				daSDC_Unita.Fill(ds.SDC_Unita);
				daUnitRelate.Fill(ds.UnitRelate);

				daProgrammaOrario.Fill(ds.ProgrammaOrario);

				daProgrammaOrarioPerUnita.SelectCommand.CommandText += " where dataProgramma=@d";
				daProgrammaOrarioPerUnita.SelectCommand.Parameters.Add("@d", new DateTime(2004,12,16));

				daProgrammaOrarioPerUnita.Fill(ds.ProgrammaOrarioPerUnita);


				for (int c = 0; c < ds.Contratto.Rows.Count; c++)
				{
					DS.ContrattoRow drC = ds.Contratto[c];
					if (drC.TrCN == false) continue;
					if (drC.StatoContratto != "Abilitato") continue;
					
					DateTime di = drC.DataInizioValidita.Date;
					DateTime df = drC.DataFineValidita.Date;

					string acq = drC.CodiceOperatoreSDCAcquirente;
					string ced = drC.CodiceOperatoreSDCCedente;

					DataRow [] uacq = ds.UnitRelate.Select(string.Format("CodiceOperatoreSDC = '{0}'", acq));
					DataRow [] uced = ds.UnitRelate.Select(string.Format("CodiceOperatoreSDC = '{0}'", ced));

					Random r = new Random((int)DateTime.Now.Ticks);


					int n = 0;
					for (DateTime d = di; d <= df; d = d.AddDays(1))
					{
						// solo programmazioni di 2 mesi: tutto novembre e tutto dicembre.
						if (d < new DateTime(2004, 11,  1)) continue;
						if (d > new DateTime(2004, 12, 31)) continue;

						if (d != new DateTime(2004, 12, 16)) continue;

						//n++;
						//if (n % r.Next(5, 10) == 0) continue; // salto i giorni ogni 5...10 giorni


						for (byte h = 1; h <= 24; h++)
						{
							CreaProgramma(drC, d, h, uacq, true);
							CreaProgramma(drC, d, h, uced, false);
						}
					}

				}
			}
			finally
			{
				if (cn.State == ConnectionState.Open)
					cn.Close();
			}
		}

		void CreaProgramma(DS.ContrattoRow drC, DateTime d, byte h, DataRow [] ur, bool acquirente)
		{
			if (ur.Length == 0) return;

			// indica che per questa data/ora e' stato inserita una programmazione
			bool bpoDone = false;

			foreach (DS.UnitRelateRow drUR in ur)
			{
				if (d > drUR.DataFineValidita) continue;
				if (d < drUR.DataInizioValidita) continue;

				// questi 2 sono discutibili
				if (drUR.TrUC == false) continue;
				if (drUR.Abilitata == false) continue;


				DS.SDC_UnitaRow drUnita = ds.SDC_Unita.FindByCodiceUnitaSDCCategoriaUnitaSDC(drUR.CodiceUnitaSDC, drUR.CategoriaUnitaSDC);

				// qui salto le unita` non programmabili
				if (acquirente == true  && drUnita.TipoUnita == "P") continue;
				if (acquirente == false && drUnita.TipoUnita == "C") continue;

				double pmin = drUnita.PotenzaMinimaMWh;
				double pmax = drUnita.PotenzaMassimaMWh;


				if (bpoDone == false)
				{
					bpoDone = true;

					DS.ProgrammaOrarioRow drPO = ds.ProgrammaOrario.FindByIdContrattoDataProgrammaPeriodoRilevante(drC.IdContratto, d, h);
					bool bpo = false;
					if (drPO == null)
					{
						bpo = true;
						drPO = ds.ProgrammaOrario.NewProgrammaOrarioRow();
					}

					drPO.IdContratto = drC.IdContratto;
					drPO.DataProgramma = d;
					drPO.PeriodoRilevante = h;
					drPO.SetBilanciatoNull();
					drPO.TSCalcoloBilanciamento = DateTime.Now;
					drPO.TSModifica = DateTime.Now;
					drPO.ProgrammaOrarioValidato = true;
					drPO.SetSbilanciamentoMWhNull();
					drPO.GestioneTaglio = drC.GestioneTaglio;
					drPO.IsGMEOp = true;
					drPO.SetSbilanciamentoMWhRealeNull();

					if (bpo == true)
						ds.ProgrammaOrario.AddProgrammaOrarioRow(drPO);
				}


				bool bpou = false;
				DS.ProgrammaOrarioPerUnitaRow drPOU = ds.ProgrammaOrarioPerUnita.FindByIdContrattoDataProgrammaPeriodoRilevanteCodiceUnitaSDCCategoriaUnitaSDC(drC.IdContratto, d, h, drUR.CodiceUnitaSDC, drUR.CategoriaUnitaSDC);
				if (drPOU == null)
				{
					bpou = true;
					drPOU = ds.ProgrammaOrarioPerUnita.NewProgrammaOrarioPerUnitaRow();
				}

				drPOU.IdContratto = drC.IdContratto;
				drPOU.DataProgramma = d;
				drPOU.PeriodoRilevante = h;
				drPOU.CodiceUnitaSDC = drUR.CodiceUnitaSDC;
				drPOU.CategoriaUnitaSDC = drUR.CategoriaUnitaSDC;

				switch (drUnita.TipoUnita[0])
				{
					case 'C':
						drPOU.QtyMWh = -pmax / 2;
						break;
					case 'P':
						drPOU.QtyMWh = pmax / 2;
						break;
					case 'M':
						if (acquirente)
							drPOU.QtyMWh = -pmin / 2;
						else
							drPOU.QtyMWh = pmax / 2;
						break;
				}

				drPOU.ProgOrarioDellUnitaValidato = true;
				drPOU.SetQtyMWhBilanciamentoNull();
				drPOU.SetQtyMWhAssegnataMGPNull();
				drPOU.IdProgrammaXml = 1;
				drPOU.ProgressivoNelProgramma = 1;
				drPOU.ProgrammatoDalCedente = acquirente == false;
				drPOU.GMEReferenceNumber = "STRESS" + DateTime.Now.Ticks.ToString();

				if (bpou)
					ds.ProgrammaOrarioPerUnita.AddProgrammaOrarioPerUnitaRow(drPOU);

				Msg(string.Format("IdContratto={0} Data={1} PR={2} UN={3}", drC.IdContratto, d, h, drPOU.CodiceUnitaSDC));

			}

			if (bpoDone)
			{
				SqlTransaction tr = null;
				//tr = cn.BeginTransaction();
				try
				{
					daProgrammaOrario.UpdateCommand.Transaction = tr;
					daProgrammaOrario.InsertCommand.Transaction = tr;

					daProgrammaOrarioPerUnita.UpdateCommand.Transaction = tr;
					daProgrammaOrarioPerUnita.InsertCommand.Transaction = tr;


					daProgrammaOrario.Update(ds.ProgrammaOrario);
					daProgrammaOrarioPerUnita.Update(ds.ProgrammaOrarioPerUnita);

					if (tr != null)
						tr.Commit();
					tr = null;
				}
				catch (Exception ex)
				{
					Debug.WriteLine(ex.Message);
				}
				finally
				{
					if (tr != null)
						tr.Rollback();
				}
			}

		}

	}
}
