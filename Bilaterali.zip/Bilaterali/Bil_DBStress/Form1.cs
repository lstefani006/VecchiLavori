using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.Data.SqlClient;

namespace Bil_DBStress
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnStartStress;
		private System.Data.SqlClient.SqlConnection cn;
		private System.Windows.Forms.TextBox tbStress;
		private System.Windows.Forms.Button btnCaricaDb;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnStartStress = new System.Windows.Forms.Button();
			this.cn = new System.Data.SqlClient.SqlConnection();
			this.tbStress = new System.Windows.Forms.TextBox();
			this.btnCaricaDb = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnStartStress
			// 
			this.btnStartStress.Location = new System.Drawing.Point(8, 8);
			this.btnStartStress.Name = "btnStartStress";
			this.btnStartStress.Size = new System.Drawing.Size(176, 23);
			this.btnStartStress.TabIndex = 0;
			this.btnStartStress.Text = "Start Stress";
			this.btnStartStress.Click += new System.EventHandler(this.btnStartStress_Click);
			// 
			// cn
			// 
			this.cn.ConnectionString = "workstation id=STEFANI;packet size=4096;user id=bil_dbo;data source=BILSVR1;persi" +
				"st security info=False;initial catalog=Bilaterali";
			// 
			// tbStress
			// 
			this.tbStress.Location = new System.Drawing.Point(8, 40);
			this.tbStress.Multiline = true;
			this.tbStress.Name = "tbStress";
			this.tbStress.Size = new System.Drawing.Size(776, 360);
			this.tbStress.TabIndex = 1;
			this.tbStress.Text = "";
			// 
			// btnCaricaDb
			// 
			this.btnCaricaDb.Location = new System.Drawing.Point(224, 8);
			this.btnCaricaDb.Name = "btnCaricaDb";
			this.btnCaricaDb.TabIndex = 2;
			this.btnCaricaDb.Text = "Carica il DB";
			this.btnCaricaDb.Click += new System.EventHandler(this.btnCaricaDb_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(792, 405);
			this.Controls.Add(this.btnCaricaDb);
			this.Controls.Add(this.tbStress);
			this.Controls.Add(this.btnStartStress);
			this.Name = "Form1";
			this.Text = "Bil DB Stress";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		volatile bool stress = false;

		private void btnStartStress_Click(object sender, System.EventArgs e)
		{
			cn.ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["SqlConnectionString"];

			ddd = new pmsg(Msg);

			if (stress == false)
			{
				btnStartStress.Text = "Stop Stress";
				stress = true;

				ThreadPool.QueueUserWorkItem(new WaitCallback(spBilGeneraBus));
				ThreadPool.QueueUserWorkItem(new WaitCallback(spBilGetProgrammazione24));
				ThreadPool.QueueUserWorkItem(new WaitCallback(spReportXmlProgrammi));
			}
			else
			{
				btnStartStress.Text = "Start Stress";
				stress = false;
			}
		}

		public delegate void pmsg(string s);

		private void Msg(string s)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(ddd, new object[] {s} );

			}
			else
			{
				this.tbStress.AppendText(s + "\r\n");
			}
		}

		private pmsg ddd;

		private void spBilGeneraBus(object o)
		{
			SqlConnection c = new SqlConnection(cn.ConnectionString);
			c.Open();

			for (int i = 0; i < 100000; i++)
			{
				if (stress == false)
					break;

				Msg("spBilGeneraBus start ");

				SqlCommand cmd = new SqlCommand("spBilGeneraBus", c);
				cmd.CommandType = CommandType.StoredProcedure;

				cmd.Parameters.Add("@DataProgramma", new DateTime(2004,11,24));
				cmd.Parameters.Add("@CodiceOperatoreSDC", "IDAU");

				SqlDataReader dr = cmd.ExecuteReader();

				int n = 0;

				while (dr.Read())
				{
					n++;
				}

				dr.Close();

				Msg("spBilGeneraBus end " + n.ToString());

			}
			c.Close();
		}


		private void spBilGetProgrammazione24(object o)
		{
			SqlConnection c = new SqlConnection(cn.ConnectionString);
			c.Open();

			for (int i = 0; i < 100000; i++)
			{

				if (stress == false)
					break;

				Msg("spBilGetProgrammazione24 start ");

				SqlCommand cmd = new SqlCommand("spBilGetProgrammazione24", c);
				cmd.CommandType = CommandType.StoredProcedure;

				cmd.Parameters.Add("@DataProgramma", new DateTime(2004,11,24));

				SqlDataReader dr = cmd.ExecuteReader();

				int n = 0;
				while (dr.Read())
				{
					n++;
				}

				dr.Close();

				Msg("spBilGetProgrammazione24 end " + n.ToString());

			}
			c.Close();
		}


		private void spReportXmlProgrammi(object o)
		{
			SqlConnection c = new SqlConnection(cn.ConnectionString);
			c.Open();

			for (int i = 0; i < 100000; i++)
			{
				if (stress == false)
					break;

				Msg("spReportXmlProgrammi start ");

				SqlCommand cmd = new SqlCommand("spReportXmlProgrammi", c);
				cmd.CommandType = CommandType.StoredProcedure;

				cmd.Parameters.Add("@DataProgramma", new DateTime(2004,12,6));
				cmd.Parameters.Add("@IdContratto",   212);

				SqlDataReader dr = cmd.ExecuteReader();

				int n = 0;
				while (dr.Read())
				{
					n++;
				}

				dr.Close();

				Msg("spReportXmlProgrammi end " + n.ToString());

			}
			c.Close();
		}

		private void btnCaricaDb_Click(object sender, System.EventArgs e)
		{
			DbFill s = new DbFill();
			s.ShowDialog(this);
		}


	}
}
