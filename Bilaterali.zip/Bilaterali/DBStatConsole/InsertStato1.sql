-- DECLARE @DataRicerca smalldatetime
-- DECLARE @tmpIdentValue int

--
-- 30 Luglio 2004 = '7/30/4'
-- 31 Luglio 2004 = '7/31/4'
-- 1 Agosto 2004 = '8/1/4'
-- 4 Settembre 2004 = '9/4/4'
-- 10 Settembre 2004 = '9/10/4'
-- 11 Settembre 2004 = '9/11/4'
-- 12 Settembre 2004 = '9/12/4'
-- 13 Settembre 2004 = '9/13/4'
-- Set @DataRicerca  = '9/11/4'

--DataRicerca: @DataRicerca
--OriginalDB: BilateraliDevToExtract
--DestinationDB: BilateraliDev20040911


--Message: Drop indice IX_ProgrammaOrarioPerUnita_DataProgramma_PeriodoRilevante_IdContratto
USE BilateraliDev20040911;DROP INDEX dbo.ProgrammaOrarioPerUnita.IX_ProgrammaOrarioPerUnita_DataProgramma_PeriodoRilevante_IdContratto;


--Message: Drop indice IX_Contratto_CRN
USE BilateraliDev20040911;DROP INDEX dbo.Contratto.IX_Contratto_CRN;

--Message: Drop indice LoginIX
USE BilateraliDev20040911;DROP INDEX dbo.SDC_Utenti.LoginIX;


--Message: cancellazione tabella temporanea 
-- DROP TABLE #tmpValue;

--Message: creazione tabella temporanea per uso generale
CREATE TABLE #tmpValue (IdProgrammaXml INT NOT NULL);

--Message: Inserimento valori tabella temporanea
INSERT INTO #tmpValue SELECT DISTINCT BilateraliDevToExtract.dbo.ProgrammaOrarioPerUnita.IdProgrammaXml FROM BilateraliDevToExtract.dbo.ProgrammaOrarioPerUnita WHERE BilateraliDevToExtract.dbo.ProgrammaOrarioPerUnita.DataProgramma = @DataRicerca;


--Message: Inserimento tabella PrezzoUnitario (Stato1 Data = @DataRicerca)
INSERT BilateraliDev20040911.dbo.PrezzoUnitario SELECT * FROM BilateraliDevToExtract.dbo.PrezzoUnitario WHERE Data=@DataRicerca;

--Message: Inserimento tabella RichiestaCancellazione
INSERT BilateraliDev20040911.dbo.RichiestaCancellazione SELECT * FROM BilateraliDevToExtract.dbo.RichiestaCancellazione;

--Message: Inserimento tabella BatchStatus (Questo dovrebbe far parte dello Stato1, e solo i dati con TSDataFlusso=null oppure = data prescelta
INSERT BilateraliDev20040911.dbo.BatchStatus SELECT * FROM BilateraliDevToExtract.dbo.BatchStatus WHERE TSDataFlusso is NULL;
INSERT BilateraliDev20040911.dbo.BatchStatus SELECT * FROM BilateraliDevToExtract.dbo.BatchStatus WHERE TSDataFlusso is NOT NULL AND TSDataFlusso=@DataRicerca;


--Message: Inserimento tabella Certificate_DistributionPoints
INSERT BilateraliDev20040911.dbo.Certificate_DistributionPoints SELECT * FROM BilateraliDevToExtract.dbo.Certificate_DistributionPoints;

--Message: Inserimento tabella Certificate_List
INSERT BilateraliDev20040911.dbo.Certificate_List SELECT * FROM BilateraliDevToExtract.dbo.Certificate_List;

--Message: Inserimento tabella Certificate_RevocationList
INSERT BilateraliDev20040911.dbo.Certificate_RevocationList SELECT * FROM BilateraliDevToExtract.dbo.Certificate_RevocationList;

--Message: Inserimento tabella Certificate_CA
INSERT BilateraliDev20040911.dbo.Certificate_CA SELECT * FROM BilateraliDevToExtract.dbo.Certificate_CA;

--Message: Inserimento tabella SessioneBilaterali (Stato1, DataProgramma = @DataRicerca)
INSERT BilateraliDev20040911.dbo.SessioneBilaterali SELECT * FROM BilateraliDevToExtract.dbo.SessioneBilaterali WHERE BilateraliDevToExtract.dbo.SessioneBilaterali.DataProgramma=@DataRicerca;

--Message: Inserimento tabella SmLog: puo' avere dimensioni elevate: per ora query commentata
-- INSERT BilateraliDev20040911.dbo.SmLog SELECT * FROM BilateraliDevToExtract.dbo.SmLog;

--Message: Inserimento tabella Ore
INSERT BilateraliDev20040911.dbo.Ore SELECT * FROM BilateraliDevToExtract.dbo.Ore;



--Message: Inserimento tabella FileMGP con TSFlusso determinata o senza TSFlusso (per compatibilita pregressa)
INSERT BilateraliDev20040911.dbo.FileMGP SELECT BilateraliDevToExtract.dbo.FileMGP.* FROM BilateraliDevToExtract.dbo.FileMGP WHERE TSFlusso IS NULL;
INSERT BilateraliDev20040911.dbo.FileMGP SELECT BilateraliDevToExtract.dbo.FileMGP.* FROM BilateraliDevToExtract.dbo.FileMGP WHERE (TSFlusso IS NOT NULL) AND (TSFlusso = @DataRicerca);


--Message: Inserimento tabella ErroriProgrammiUtenti
INSERT INTO BilateraliDev20040911.dbo.ErroriProgrammiUtenti SELECT BilateraliDevToExtract.dbo.ErroriProgrammiUtenti.* FROM BilateraliDevToExtract.dbo.ErroriProgrammiUtenti INNER JOIN #tmpValue ON  BilateraliDevToExtract.dbo.ErroriProgrammiUtenti.IdProgrammaXml = #tmpValue.IdProgrammaXml;

--Message: Inserimento tabella ErroriPIPTransactionUtenti
INSERT INTO BilateraliDev20040911.dbo.ErroriPIPTransactionUtenti SELECT BilateraliDevToExtract.dbo.ErroriPIPTransactionUtenti.* FROM BilateraliDevToExtract.dbo.ErroriPIPTransactionUtenti INNER JOIN #tmpValue ON BilateraliDevToExtract.dbo.ErroriPIPTransactionUtenti.IdProgrammaXml = #tmpValue.IdProgrammaXml;


--Message: Inserimento tabella Ruoli
INSERT BilateraliDev20040911.dbo.Ruoli SELECT * FROM BilateraliDevToExtract.dbo.Ruoli;


--Message: Inserimento tabella SDC_Zone 
INSERT BilateraliDev20040911.dbo.SDC_Zone SELECT * FROM BilateraliDevToExtract.dbo.SDC_Zone;

--Message: Inserimento PrezzoZonale (stato1) data = @DataRicerca
INSERT BilateraliDev20040911.dbo.PrezzoZonale SELECT * FROM BilateraliDevToExtract.dbo.PrezzoZonale WHERE BilateraliDevToExtract.dbo.PrezzoZonale.Data = @DataRicerca;


--Message: Inserimento tabella SDC_Utenti
INSERT BilateraliDev20040911.dbo.SDC_Utenti SELECT * FROM BilateraliDevToExtract.dbo.SDC_Utenti;


--Message: Inserimento tabella Utenti
INSERT BilateraliDev20040911.dbo.Utenti SELECT * FROM BilateraliDevToExtract.dbo.Utenti;


--Message: Inserimento tabella SDC_PuntiDiScambioRilevanti
INSERT BilateraliDev20040911.dbo.SDC_PuntiDiScambioRilevanti SELECT * FROM BilateraliDevToExtract.dbo.SDC_PuntiDiScambioRilevanti;

--Message: Inserimento tabella SDC_Operatori
INSERT BilateraliDev20040911.dbo.SDC_Operatori SELECT * FROM BilateraliDevToExtract.dbo.SDC_Operatori;

--Message: Inserimento tabella Operatori
INSERT BilateraliDev20040911.dbo.Operatori SELECT * FROM BilateraliDevToExtract.dbo.Operatori;


--Message: Inserimento tabella FileOperatori di tipo FA
INSERT INTO BilateraliDev20040911.dbo.FileOperatori SELECT BilateraliDevToExtract.dbo.FileOperatori.* FROM BilateraliDevToExtract.dbo.FileOperatori INNER JOIN BilateraliDevToExtract.dbo.XmlProgrammiUtenti ON BilateraliDevToExtract.dbo.FileOperatori.IdFile = BilateraliDevToExtract.dbo.XmlProgrammiUtenti.IdFileFA AND BilateraliDevToExtract.dbo.FileOperatori.CodiceTipoFile = 'FA' INNER JOIN #tmpValue ON BilateraliDevToExtract.dbo.XmlProgrammiUtenti.IdProgrammaXml = #tmpValue.IdProgrammaXml;


--Message: Inserimento tabella FileOperatori di tipo non FA con dataflusso determinata o senza dataflusso
INSERT INTO BilateraliDev20040911.dbo.FileOperatori SELECT BilateraliDevToExtract.dbo.FileOperatori.* FROM BilateraliDevToExtract.dbo.FileOperatori WHERE (CodiceTipoFile <> 'FA') AND (TSFlusso IS NULL);
INSERT INTO BilateraliDev20040911.dbo.FileOperatori SELECT BilateraliDevToExtract.dbo.FileOperatori.* FROM BilateraliDevToExtract.dbo.FileOperatori WHERE (CodiceTipoFile <> 'FA') AND (TSFlusso IS NOT NULL) AND (TSFlusso = @DataRicerca);


--Message: Inserimento tabella RelOperatoriUtenti
INSERT BilateraliDev20040911.dbo.RelOperatoriUtenti SELECT * FROM BilateraliDevToExtract.dbo.RelOperatoriUtenti;


--Message: Inserimento tabella XmlProgrammiUtenti
SET IDENTITY_INSERT BilateraliDev20040911.dbo.XmlProgrammiUtenti ON; INSERT BilateraliDev20040911.dbo.XmlProgrammiUtenti (IdProgrammaXml, ProgrammaFirmato, TSInvio, Zippato, NomeFileUtente, CodiceUtenteSDC, PathFileFirmato, CodiceOperatoreSDC, TSModifica, IdFileFA, Issuer, SerialNumber) SELECT p.IdProgrammaXml,p.ProgrammaFirmato,p.TSInvio,p.Zippato,p.NomeFileUtente,p.CodiceUtenteSDC,p.PathFileFirmato,p.CodiceOperatoreSDC,p.TSModifica,p.IdFileFA,p.Issuer,p.SerialNumber FROM BilateraliDevToExtract.dbo.XmlProgrammiUtenti p INNER JOIN #tmpValue ON p.IdProgrammaXml = #tmpValue.IdProgrammaXml;SET IDENTITY_INSERT BilateraliDev20040911.dbo.XmlProgrammiUtenti OFF;


--Message: Inserimento tabella Contratto
SET IDENTITY_INSERT BilateraliDev20040911.dbo.Contratto ON; INSERT BilateraliDev20040911.dbo.Contratto (IdContratto, CodiceContratto, DataStipula, DataInizioValidita, DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC, TSModifica, CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN) SELECT IdContratto, CodiceContratto, DataStipula, DataInizioValidita, DataFineValidita, CRN, StatoContratto, CodiceOperatoreSDC,  TSModifica, CodiceOperatoreSDCAcquirente, CodiceOperatoreSDCCedente, ProgrammazionePrivilegiata, TrCN FROM BilateraliDevToExtract.dbo.Contratto; SET IDENTITY_INSERT BilateraliDev20040911.dbo.Contratto OFF;


--Message: Inserimento tabella SDC_Unita
INSERT BilateraliDev20040911.dbo.SDC_Unita SELECT * FROM BilateraliDevToExtract.dbo.SDC_Unita;

--Message: Inserimento tabella Unita
INSERT BilateraliDev20040911.dbo.Unita SELECT * FROM BilateraliDevToExtract.dbo.Unita;


--Message: Inserimento tabella UnitRelate
INSERT BilateraliDev20040911.dbo.UnitRelate SELECT * FROM BilateraliDevToExtract.dbo.UnitRelate;

--Message: Inserimento tabella SDC_Unita_MarketInformation
INSERT BilateraliDev20040911.dbo.SDC_Unita_MarketInformation SELECT * FROM BilateraliDevToExtract.dbo.SDC_Unita_MarketInformation;



--Message: Inserimento tabella ProgrammaOrario
INSERT BilateraliDev20040911.dbo.ProgrammaOrario SELECT * FROM BilateraliDevToExtract.dbo.ProgrammaOrario WHERE BilateraliDevToExtract.dbo.ProgrammaOrario.DataProgramma=@DataRicerca;

--Message: Inserimento tabella ProgrammaOrarioPerUnita
INSERT BilateraliDev20040911.dbo.ProgrammaOrarioPerUnita SELECT * FROM BilateraliDevToExtract.dbo.ProgrammaOrarioPerUnita  WHERE BilateraliDevToExtract.dbo.ProgrammaOrarioPerUnita.DataProgramma=@DataRicerca;

--Message: Inserimento tabella ProgrammaOrarioPerUnitaErrori (Stato1)
INSERT BilateraliDev20040911.dbo.ProgrammaOrarioPerUnitaErrori SELECT * FROM BilateraliDevToExtract.dbo.ProgrammaOrarioPerUnitaErrori  WHERE BilateraliDevToExtract.dbo.ProgrammaOrarioPerUnitaErrori.DataProgramma=@DataRicerca;


--Message: Inserimento tabella RichiestaCancellazione
INSERT BilateraliDev20040911.dbo.RichiestaCancellazione SELECT * FROM BilateraliDevToExtract.dbo.RichiestaCancellazione;

--Message: Inserimento tabella Funzioni
INSERT BilateraliDev20040911.dbo.Funzioni SELECT * FROM BilateraliDevToExtract.dbo.Funzioni;

--Message: Inserimento tabella RuoliFunzioni
INSERT BilateraliDev20040911.dbo.RuoliFunzioni SELECT * FROM BilateraliDevToExtract.dbo.RuoliFunzioni;


--Message: cancellazione tabella temporanea 
DROP TABLE #tmpValue;


--Message: Calcola valore SEED corrente su tabella Contratto original DB
DECLARE @tmpIdentValue INT; SET @tmpIdentValue = IDENT_CURRENT('BilateraliDevToExtract.dbo.Contratto'); DBCC CHECKIDENT("BilateraliDev20040911.dbo.Contratto", RESEED, @tmpIdentValue);


--Message: Calcola valore SEED corrente su tabella XmlProgrammiUtenti original DB
DECLARE @tmpIdentValue INT; SET @tmpIdentValue = IDENT_CURRENT('BilateraliDevToExtract.dbo.XmlProgrammiUtenti');DBCC CHECKIDENT("BilateraliDev20040911.dbo.XmlProgrammiUtenti", RESEED, @tmpIdentValue);


--Message: Creazione indice IX_ProgrammaOrarioPerUnita_DataProgramma_PeriodoRilevante_IdContratto
USE BilateraliDev20040911; CREATE  CLUSTERED  INDEX [IX_ProgrammaOrarioPerUnita_DataProgramma_PeriodoRilevante_IdContratto] ON [dbo].[ProgrammaOrarioPerUnita]([DataProgramma], [PeriodoRilevante], [IdContratto]) ON [PRIMARY];

--Message: Creazione indice IX_Contratto_CRN
USE BilateraliDev20040911; CREATE  UNIQUE  INDEX [IX_Contratto_CRN] ON [dbo].[Contratto]([CRN]) ON [PRIMARY];

--Message: Creazione indice LoginIX
USE BilateraliDev20040911; CREATE  UNIQUE  INDEX [LoginIX] ON [dbo].[SDC_Utenti]([Login]) ON [PRIMARY];



--Message: SHRINK del Database per ridurre le dimensioni del file, lasciando 25% di spazio libero
USE BilateraliDev20040911; DBCC SHRINKDATABASE ("BilateraliDev20040911", 25);
