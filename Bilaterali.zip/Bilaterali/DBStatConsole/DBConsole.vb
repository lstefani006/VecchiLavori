Imports Bil
Imports System.Configuration

Module ConsoleApp

    Sub WriteMessage(ByVal msg As String)
        Console.WriteLine(msg)
    End Sub

    Sub ConsoleMain()

        '
        ' Data di cui fare il Dump
        ' 
        Dim DumpDate As Date = New Date(2004, 9, 13)

        '
        ' Data fino al tempo di cui fare il Delete
        ' 
        Dim DeleteFromDate As Date = New Date(2004, 9, 10)

        '
        ' Risultato dell'esecuzione
        '
        Dim exResult As DBStatComp.ExecutionResult = New DBStatComp.ExecutionResult
        Dim DBStat As New DBStatComp


        '
        ' setta l'handler associato al print di un messaggio di feedback
        '
        AddHandler DBStat.OnExecutionMessage, AddressOf WriteMessage


        Console.WriteLine("Purge DB dalla data " & DeleteFromDate.ToString("yyyyMMdd"))
        '
        ' Esecuzione del DeleteFrom
        '
        Try
            exResult = DBStat.PurgeDataFromDBUntil(DeleteFromDate)
        Catch ex As Exception
            exResult.ErrorMessage = ex.Message
            Console.WriteLine(ex.Message)
        End Try

        If exResult.ExecutionStatus = False Then
            Console.WriteLine("Errore di esecuzione = " & exResult.ErrorMessage)
        Else
            Console.WriteLine("Esecuzione OK")
        End If

        '
        ' Esecuzione del Dump di Stato0
        '
        Console.WriteLine("Dump Stato0 dal DB dalla data " & DumpDate.ToString("yyyyMMdd"))

        Try
            exResult = DBStat.ExecuteStato0Dump(DumpDate)
        Catch ex As Exception
            exResult.ErrorMessage = ex.Message
            Console.WriteLine(ex.Message)
        End Try

        If exResult.ExecutionStatus = True Then
            Console.WriteLine("DB Name = " & exResult.NewDBName)
            Console.WriteLine("DBDatafile Name = " & exResult.NewDBDataFileName)
            Console.WriteLine("DBLogFile Name = " & exResult.NewDBLogFileName)

            '
            ' Attach del nuovo DB (per comodita' di analisi successiva)
            '
            DBStat.AttachDB(exResult.NewDBName, exResult.NewDBDataFileName, exResult.NewDBLogFileName)
        End If


        '
        ' Esecuzione del Dump di Stato1
        '
        Console.WriteLine("Dump Stato1 dal DB dalla data " & DumpDate.ToString("yyyyMMdd"))
        Try
            exResult = DBStat.ExecuteStato1Dump(DumpDate)
        Catch ex As Exception
            exResult.ErrorMessage = ex.Message
            Console.WriteLine(ex.Message)
        End Try

        If exResult.ExecutionStatus = True Then
            Console.WriteLine("DB Name = " & exResult.NewDBName)
            Console.WriteLine("DBDatafile Name = " & exResult.NewDBDataFileName)
            Console.WriteLine("DBLogFile Name = " & exResult.NewDBLogFileName)
            '
            ' Attach del nuovo DB (per comodita' di analisi successiva)
            '
            DBStat.AttachDB(exResult.NewDBName, exResult.NewDBDataFileName, exResult.NewDBLogFileName)
        End If

    End Sub
End Module
