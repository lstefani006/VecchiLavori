-- DECLARE @DataRicerca smalldatetime
-- DECLARE @tmpIdentValue int

--
-- 30 Luglio 2004 = '7/30/4'
-- 31 Luglio 2004 = '7/31/4'
-- 1 Agosto 2004 = '8/1/4'
-- 4 Settembre 2004 = '9/4/4'
-- 10 Settembre 2004 = '9/10/4'
-- Set @DataRicerca  = '9/1/4'


--DataRicerca: @DataRicerca
--OriginalDB: BilateraliDev

--Message: cancellazione tabella temporanea 
-- DROP TABLE #tmpValue;

--Message: creazione tabella temporanea IdProgrammaXml
CREATE TABLE #tmpValue (IdProgrammaXml INT NOT NULL);

--Message: Inserimento valori tabella temporanea IdProgrammaXML
INSERT INTO #tmpValue SELECT DISTINCT BilateraliDev.dbo.ProgrammaOrarioPerUnita.IdProgrammaXml FROM BilateraliDev.dbo.ProgrammaOrarioPerUnita WHERE BilateraliDev.dbo.ProgrammaOrarioPerUnita.DataProgramma <= @DataRicerca;


--Message: cancellazione tabella temporanea 
-- DROP TABLE #tmpValueIdFileFA;

--Message: creazione tabella temporanea IdFile (FA)
CREATE TABLE #tmpValueIdFileFA (IdFile varchar(32) COLLATE SQL_Latin1_General_CP1_CS_AS NOT NULL);

--Message: Inserimento valori tabella temporanea IdFileFA
INSERT INTO #tmpValueIdFileFA SELECT DISTINCT IdFile FROM BilateraliDev.dbo.FileOperatori INNER JOIN BilateraliDev.dbo.XmlProgrammiUtenti ON BilateraliDev.dbo.FileOperatori.IdFile = BilateraliDev.dbo.XmlProgrammiUtenti.IdFileFA AND BilateraliDev.dbo.FileOperatori.CodiceTipoFile = 'FA' INNER JOIN #tmpValue ON BilateraliDev.dbo.XmlProgrammiUtenti.IdProgrammaXml = #tmpValue.IdProgrammaXml;

--Message: Cancellazione dati tabella PrezzoUnitario (Data <= @DataRicerca)
DELETE FROM BilateraliDev.dbo.PrezzoUnitario WHERE Data<=@DataRicerca;


--Message: Cancellazione dati tabella SessioneBilaterali (DataProgramma <= @DataRicerca)
DELETE FROM BilateraliDev.dbo.SessioneBilaterali WHERE BilateraliDev.dbo.SessioneBilaterali.DataProgramma<=@DataRicerca;

--Message: Cancellazione dati tabella BatchStatus (TSDataFlusso <= @DataRicerca)
DELETE FROM BilateraliDev.dbo.BatchStatus WHERE (BilateraliDev.dbo.BatchStatus.TSDataFlusso IS NOT NULL) AND (BilateraliDev.dbo.BatchStatus.TSDataFlusso<=@DataRicerca);

--Message: Cancellazione dati tabella ProgrammaOrarioPerUnitaErrori con data <= @DataRicerca
DELETE FROM BilateraliDev.dbo.ProgrammaOrarioPerUnitaErrori WHERE BilateraliDev.dbo.ProgrammaOrarioPerUnitaErrori.DataProgramma<=@DataRicerca;

--Message: Cancellazione dati tabella ProgrammaOrarioPerUnita con data <= @DataRicerca
DELETE FROM BilateraliDev.dbo.ProgrammaOrarioPerUnita WHERE BilateraliDev.dbo.ProgrammaOrarioPerUnita.DataProgramma<=@DataRicerca;

--Message: Cancellazione dati tabella ProgrammaOrario con data <= @DataRicerca
DELETE FROM BilateraliDev.dbo.ProgrammaOrario WHERE BilateraliDev.dbo.ProgrammaOrario.DataProgramma<=@DataRicerca;


--Message: Cancellazione dati tabella XmlProgrammiUtenti con data <= @DataRicerca
DELETE FROM BilateraliDev.dbo.XmlProgrammiUtenti WHERE IdProgrammaXml IN (SELECT p.IdProgrammaXml FROM BilateraliDev.dbo.XmlProgrammiUtenti p INNER JOIN #tmpValue ON p.IdProgrammaXml = #tmpValue.IdProgrammaXml);


--Message: Cancellazione dati tabella FileOperatori di tipo FA (con Timeout query 45 sec)
--TmoQuery: 45
DELETE FROM BilateraliDev.dbo.FileOperatori WHERE IdFile IN (SELECT IdFile FROM #tmpValueIdFileFA);

--Message: Cancellazione dati tabella FileOperatori di tipo non FA con dataflusso <= @DataRicerca (timeout query 45 sec)
--TmoQuery: 45
DELETE FROM BilateraliDev.dbo.FileOperatori WHERE TSFlusso = @DataRicerca and CodiceTipoFile<>'FA'; 


--Message: Cancellazione dati PrezzoZonale data <= @DataRicerca
DELETE FROM BilateraliDev.dbo.PrezzoZonale WHERE BilateraliDev.dbo.PrezzoZonale.Data <= @DataRicerca;

--Message: Cancellazione dati tabella ErroriPIPTransactionUtenti con data <= @DataRicerca
DELETE FROM BilateraliDev.dbo.ErroriPIPTransactionUtenti WHERE BilateraliDev.dbo.ErroriPIPTransactionUtenti.IdProgrammaXml IN (SELECT IdProgrammaXml FROM #tmpValue);

--Message: Cancellazione dati tabella ErroriProgrammiUtenti con data <= @DataRicerca
DELETE FROM BilateraliDev.dbo.ErroriProgrammiUtenti WHERE BilateraliDev.dbo.ErroriProgrammiUtenti.IdProgrammaXml IN (SELECT IdProgrammaXml FROM #tmpValue);
	
--Message: Cancellazione dati tabella FileMGP con dataflusso <= @DataRicerca  (timeout query 45 sec)
--TmoQuery: 45
DELETE FROM BilateraliDev.dbo.FileMGP WHERE TSFlusso <= @DataRicerca;


--Message: cancellazione tabella temporanea IdProgrammaXML
DROP TABLE #tmpValue;
--Message: cancellazione tabella temporanea IdFile (FA)
DROP TABLE #tmpValueIdFileFA


--Message: SHRINK del Database per ridurre le dimensioni del file, lasciando 25% di spazio libero
USE BilateraliDev; DBCC SHRINKDATABASE ("BilateraliDev", 25);
