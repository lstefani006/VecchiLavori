Imports Bil
Public Class Panel
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

   
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtResult As System.Windows.Forms.RichTextBox
    Friend WithEvents DumpStato0 As System.Windows.Forms.Button
    Friend WithEvents DumpStato1 As System.Windows.Forms.Button
    Friend WithEvents PurgeData As System.Windows.Forms.Button
    Friend WithEvents DBName As System.Windows.Forms.TextBox
    Friend WithEvents DBDataPath As System.Windows.Forms.TextBox
    Friend WithEvents DBLogPath As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents AttachDB As System.Windows.Forms.Button
    Friend WithEvents DetachDB As System.Windows.Forms.Button
    Friend WithEvents DataFiltro As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DumpStato0 = New System.Windows.Forms.Button
        Me.DumpStato1 = New System.Windows.Forms.Button
        Me.PurgeData = New System.Windows.Forms.Button
        Me.txtResult = New System.Windows.Forms.RichTextBox
        Me.DBName = New System.Windows.Forms.TextBox
        Me.DBDataPath = New System.Windows.Forms.TextBox
        Me.DBLogPath = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.AttachDB = New System.Windows.Forms.Button
        Me.DetachDB = New System.Windows.Forms.Button
        Me.DataFiltro = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'DumpStato0
        '
        Me.DumpStato0.Location = New System.Drawing.Point(48, 192)
        Me.DumpStato0.Name = "DumpStato0"
        Me.DumpStato0.Size = New System.Drawing.Size(96, 32)
        Me.DumpStato0.TabIndex = 7
        Me.DumpStato0.Text = "DumpStato0"
        '
        'DumpStato1
        '
        Me.DumpStato1.Location = New System.Drawing.Point(160, 192)
        Me.DumpStato1.Name = "DumpStato1"
        Me.DumpStato1.Size = New System.Drawing.Size(96, 32)
        Me.DumpStato1.TabIndex = 8
        Me.DumpStato1.Text = "DumpStato1"
        '
        'PurgeData
        '
        Me.PurgeData.Location = New System.Drawing.Point(272, 192)
        Me.PurgeData.Name = "PurgeData"
        Me.PurgeData.Size = New System.Drawing.Size(128, 32)
        Me.PurgeData.TabIndex = 9
        Me.PurgeData.Text = "PurgeData"
        '
        'txtResult
        '
        Me.txtResult.Location = New System.Drawing.Point(56, 256)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.Size = New System.Drawing.Size(568, 168)
        Me.txtResult.TabIndex = 11
        Me.txtResult.Text = ""
        '
        'DBName
        '
        Me.DBName.Location = New System.Drawing.Point(160, 24)
        Me.DBName.Name = "DBName"
        Me.DBName.Size = New System.Drawing.Size(504, 20)
        Me.DBName.TabIndex = 12
        Me.DBName.Text = ""
        '
        'DBDataPath
        '
        Me.DBDataPath.Location = New System.Drawing.Point(160, 64)
        Me.DBDataPath.Name = "DBDataPath"
        Me.DBDataPath.Size = New System.Drawing.Size(504, 20)
        Me.DBDataPath.TabIndex = 13
        Me.DBDataPath.Text = ""
        '
        'DBLogPath
        '
        Me.DBLogPath.Location = New System.Drawing.Point(160, 104)
        Me.DBLogPath.Name = "DBLogPath"
        Me.DBLogPath.Size = New System.Drawing.Size(504, 20)
        Me.DBLogPath.TabIndex = 14
        Me.DBLogPath.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(72, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 16)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "DBName"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(72, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 16)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "DataPath"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(72, 104)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 16)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "LogPath"
        '
        'AttachDB
        '
        Me.AttachDB.Location = New System.Drawing.Point(416, 192)
        Me.AttachDB.Name = "AttachDB"
        Me.AttachDB.Size = New System.Drawing.Size(112, 32)
        Me.AttachDB.TabIndex = 18
        Me.AttachDB.Text = "AttachDB"
        '
        'DetachDB
        '
        Me.DetachDB.Location = New System.Drawing.Point(544, 192)
        Me.DetachDB.Name = "DetachDB"
        Me.DetachDB.Size = New System.Drawing.Size(104, 32)
        Me.DetachDB.TabIndex = 19
        Me.DetachDB.Text = "DetachDB"
        '
        'DataFiltro
        '
        Me.DataFiltro.Location = New System.Drawing.Point(264, 144)
        Me.DataFiltro.Name = "DataFiltro"
        Me.DataFiltro.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(184, 144)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Data Filtro"
        '
        'Panel
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(704, 461)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataFiltro)
        Me.Controls.Add(Me.DetachDB)
        Me.Controls.Add(Me.AttachDB)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.DBLogPath)
        Me.Controls.Add(Me.DBDataPath)
        Me.Controls.Add(Me.DBName)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.PurgeData)
        Me.Controls.Add(Me.DumpStato1)
        Me.Controls.Add(Me.DumpStato0)
        Me.Name = "Panel"
        Me.Text = "Pannello Controllo DB"
        Me.ResumeLayout(False)

    End Sub

#End Region


    Sub WriteMessage(ByVal msg As String)
        txtResult.AppendText(msg + ControlChars.Cr)
        txtResult.Refresh()
    End Sub

    Private Sub EnableButtons()
        DumpStato0.Enabled = True
        DumpStato1.Enabled = True
        PurgeData.Enabled = True
        AttachDB.Enabled = True
        DetachDB.Enabled = True
    End Sub

    Private Sub DisableButtons()
        DumpStato0.Enabled = False
        DumpStato1.Enabled = False
        PurgeData.Enabled = False
        AttachDB.Enabled = False
        DetachDB.Enabled = False
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DumpStato0.Click
        DisableButtons()
        '
        ' Data di cui fare il Dump
        ' 
        Dim DumpDate As Date = New Date(DataFiltro.Value.Year, DataFiltro.Value.Month, DataFiltro.Value.Day)


        '
        ' Risultato dell'esecuzione
        '
        Dim exResult As DBStatComp.ExecutionResult = New DBStatComp.ExecutionResult
        Dim DBStat As New DBStatComp


        '
        ' setta l'handler associato al print di un messaggio di feedback
        '
        AddHandler DBStat.OnExecutionMessage, AddressOf WriteMessage

        '
        ' Esecuzione del Dump di Stato0
        '
        txtResult.Text = "Dump Stato0 dal DB dalla data " + DumpDate.ToString("yyyyMMdd") + ControlChars.Cr
        txtResult.Refresh()

        Try
            exResult = DBStat.ExecuteStato0Dump(DumpDate)
        Catch ex As Exception
            exResult.ErrorMessage = ex.Message
            ' Console.WriteLine(ex.Message)
        End Try

        If exResult.ExecutionStatus = True Then
            txtResult.AppendText("DB Name = " + exResult.NewDBName + ControlChars.Cr)
            DBName.Text = exResult.NewDBName
            txtResult.AppendText("DBDatafile Name = " + exResult.NewDBDataFileName + ControlChars.Cr)
            DBDataPath.Text = exResult.NewDBDataFileName
            txtResult.AppendText("DBLogFile Name = " + exResult.NewDBLogFileName + ControlChars.Cr)
            DBLogPath.Text = exResult.NewDBLogFileName
            txtResult.Refresh()

            '
            ' Attach del nuovo DB (per comodita' di analisi successiva)
            '
            ' DBStat.AttachDB(exResult.NewDBName, exResult.NewDBDataFileName, exResult.NewDBLogFileName)
        Else
            txtResult.AppendText("Error on execution: " + exResult.ErrorMessage + ControlChars.Cr)
            txtResult.Refresh()
        End If
        EnableButtons()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DumpStato1.Click
        DisableButtons()
        
        '
        ' Data di cui fare il Dump
        ' 
        Dim DumpDate As Date = New Date(DataFiltro.Value.Year, DataFiltro.Value.Month, DataFiltro.Value.Day)

        '
        ' Risultato dell'esecuzione
        '
        Dim exResult As DBStatComp.ExecutionResult = New DBStatComp.ExecutionResult
        Dim DBStat As New DBStatComp


        '
        ' setta l'handler associato al print di un messaggio di feedback
        '
        AddHandler DBStat.OnExecutionMessage, AddressOf WriteMessage

        '
        ' Esecuzione del Dump di Stato0
        '
        txtResult.Text = "Dump Stato1 dal DB dalla data " + DumpDate.ToString("yyyyMMdd") + ControlChars.Cr
        txtResult.Refresh()
        Try
            exResult = DBStat.ExecuteStato1Dump(DumpDate)
        Catch ex As Exception
            exResult.ErrorMessage = ex.Message
        End Try

        If exResult.ExecutionStatus = True Then
            txtResult.AppendText("DB Name = " + exResult.NewDBName + ControlChars.Cr)
            DBName.Text = exResult.NewDBName
            txtResult.AppendText("DBDatafile Name = " + exResult.NewDBDataFileName + ControlChars.Cr)
            DBDataPath.Text = exResult.NewDBDataFileName
            txtResult.AppendText("DBLogFile Name = " + exResult.NewDBLogFileName + ControlChars.Cr)
            DBLogPath.Text = exResult.NewDBLogFileName
            '
            ' Attach del nuovo DB (per comodita' di analisi successiva)
            '
            ' DBStat.AttachDB(exResult.NewDBName, exResult.NewDBDataFileName, exResult.NewDBLogFileName)
            txtResult.Refresh()
        Else
            txtResult.AppendText("Error on execution: " + exResult.ErrorMessage + ControlChars.Cr)
            txtResult.Refresh()
        End If

        EnableButtons()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PurgeData.Click
        DisableButtons()

        '
        ' Data fino al tempo di cui fare il Delete
        ' 
        Dim DeleteFromDate As Date = New Date(DataFiltro.Value.Year, DataFiltro.Value.Month, DataFiltro.Value.Day)

        '
        ' Risultato dell'esecuzione
        '
        Dim exResult As DBStatComp.ExecutionResult = New DBStatComp.ExecutionResult
        Dim DBStat As New DBStatComp


        '
        ' setta l'handler associato al print di un messaggio di feedback
        '
        AddHandler DBStat.OnExecutionMessage, AddressOf WriteMessage
        txtResult.Text = "Purge DB dalla data " + DeleteFromDate.ToString("yyyyMMdd") + ControlChars.Cr
        txtResult.Refresh()
        '
        ' Esecuzione del DeleteFrom
        '
        Try
            exResult = DBStat.PurgeDataFromDBUntil(DeleteFromDate)
        Catch ex As Exception
            exResult.ErrorMessage = ex.Message
        End Try

        If exResult.ExecutionStatus = False Then
            txtResult.AppendText("Errore di esecuzione = " + exResult.ErrorMessage + ControlChars.Cr)
        Else
            txtResult.AppendText("Esecuzione OK" + ControlChars.Cr)
        End If
        txtResult.Refresh()
        EnableButtons()
    End Sub

    Private Sub AttachDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AttachDB.Click


        If (DBName.Text = String.Empty) Or (DBDataPath.Text = String.Empty) Or (DBLogPath.Text = String.Empty) Then
            MsgBox("Valori invalidi su DBName, DataPath o LogPath")
            Exit Sub
        End If
        DisableButtons()
        Dim DBStat As New DBStatComp
        Dim bResult As Boolean = False



        '
        ' Esecuzione del DeleteFrom
        '
        txtResult.Text = "Attaching DB ..."
        txtResult.Refresh()
        Try
            ' Inizializza connessione
            DBStat.InitializeConnection()
            DBStat.AttachDB(DBName.Text, DBDataPath.Text, DBLogPath.Text)
            bResult = True
        Catch ex As Exception
            txtResult.AppendText(ex.Message + ControlChars.Cr)
        End Try

        If (bResult) Then
            txtResult.AppendText("Attach DB OK" + ControlChars.Cr)
        End If
        txtResult.Refresh()
        EnableButtons()
    End Sub

    Private Sub DetachDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DetachDB.Click
        If (DBName.Text = String.Empty) Then
            MsgBox("Valore invalido su DBName")
            Exit Sub
        End If
        DisableButtons()
        Dim DBStat As New DBStatComp
        Dim bResult As Boolean = False
        '
        ' Esecuzione del DeleteFrom
        '
        txtResult.Text = "Detach DB running ..."
        txtResult.Refresh()
        Try
            ' Inizializza connessione
            DBStat.InitializeConnection()
            DBStat.DetachDB(DBName.Text)
            bResult = True
        Catch ex As Exception
            txtResult.AppendText("Errore detaching db: " + ex.Message + ControlChars.Cr)
        End Try

        If (bResult) Then
            txtResult.AppendText("Detach DB OK" + ControlChars.Cr)
        End If
        txtResult.Refresh()
        EnableButtons()
    End Sub

   
    Private Sub Panel_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Add any initialization after the InitializeComponent() call
        Dim actualDate As Date = DateTime.Now.Date
        DataFiltro.Value = actualDate
    End Sub
End Class
