using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net;
using System.Configuration;

namespace DbMonitor
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class DbMonitor : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dg;
		private System.Windows.Forms.TextBox txtSQL;
		private System.Windows.Forms.MainMenu mm;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DbMonitor()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dg = new System.Windows.Forms.DataGrid();
			this.txtSQL = new System.Windows.Forms.TextBox();
			this.mm = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
			this.SuspendLayout();
			// 
			// dg
			// 
			this.dg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dg.DataMember = "";
			this.dg.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dg.Location = new System.Drawing.Point(8, 128);
			this.dg.Name = "dg";
			this.dg.Size = new System.Drawing.Size(808, 256);
			this.dg.TabIndex = 1;
			// 
			// txtSQL
			// 
			this.txtSQL.AcceptsReturn = true;
			this.txtSQL.AcceptsTab = true;
			this.txtSQL.AllowDrop = true;
			this.txtSQL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtSQL.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtSQL.Location = new System.Drawing.Point(8, 8);
			this.txtSQL.Multiline = true;
			this.txtSQL.Name = "txtSQL";
			this.txtSQL.Size = new System.Drawing.Size(808, 112);
			this.txtSQL.TabIndex = 2;
			this.txtSQL.Text = "";
			// 
			// mm
			// 
			this.mm.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																			   this.menuItem1,
																			   this.menuItem3});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2});
			this.menuItem1.Text = "File";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "Open";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem4});
			this.menuItem3.Text = "Sql";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 0;
			this.menuItem4.Shortcut = System.Windows.Forms.Shortcut.F5;
			this.menuItem4.Text = "Run";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// DbMonitor
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(824, 389);
			this.Controls.Add(this.txtSQL);
			this.Controls.Add(this.dg);
			this.Menu = this.mm;
			this.Name = "DbMonitor";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
			this.Text = "DbMonitor";
			((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new DbMonitor());
		}

		private void btnExecute_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			try
			{
				string ppk;
				ppk = "<RSAKeyValue><Modulus>yZbzNEswudCo+DE15V9c8GBsSnrhnlL2E4FZikFQB4gYXhayvD7Daa6b4Wyd2+kkk13uoUf8gJv5WPP//ehYcoaZhYedNnmwji/LUivxOSWzcf6/bn/eAg5ZkSpgWgdswQBBimNLUSH+6KyAFJiF8DueLRrZOE183Y7tVeHB/68=</Modulus><Exponent>AQAB</Exponent><P>+R9TE989qf6m2WgJd13uUODzUEyPdPH3jO86mPC46pLnI6rRy2pB1toFSRk7EPsvhP8LaNu7DS53vvwS85upPw==</P><Q>zyev++yAY0rbkzgO5VCZkawnsLsOL+1j9pPrAsO6UgITqdLXCQyXWqwZeoVvcwxM8fRceZ9he2kt1BKKzdUdkQ==</Q><DP>ncRYuJ0IUEAVKlnYpN+3rUDI1nGl6EnUnExkr7bDZMrj1pK3ijsgtxAbiM+RuI9a6L8cWqvNKevjqe+5kM1jwQ==</DP><DQ>b6omC/d1UZClgdsi9GuZDFQvZO2//QfK7bzYXrog8lnaPZ3AeklGQQMqDMhmxi5oP7iILKtEQeD1ai7AkamCcQ==</DQ><InverseQ>KdX7jtzoKO4hZoF/L7r7YQv0fbrmIUiUnE48Uvzxmox0e5sCXqtuyRj5rIWe6qI32UEm7vVM+LxZHlZviLNhDg==</InverseQ><D>khY/FuVqYS3yVTIsUZXDHztxHqRgPkD2rPnu7n8YROz+Y6jlS//b0wlDU6BH4abZ56WJmf014emmUC06lUE8Xi++UWgNN8yu/FoqSBGHzjfQX/grrkIVipFQg893iZ/zsGD3jMzZ8jUlA4UtXZeOb8zUyGlp4YvVZLW1GA/rbGE=</D></RSAKeyValue>";


				byte [] cCmd;
				byte [] hCmd;

				byte []pin = null;
	
				Hashtable ht = new Hashtable();
				/*
				if (false)
				{
					ht.Add("@op", "IDAU");
					MemoryStream ms = new MemoryStream();
					BinaryFormatter bf = new BinaryFormatter();
					bf.Serialize(ms, ht);
					pin = ms.ToArray();
				}
				*/

				StringBuilder cmd = new StringBuilder();

				foreach (string s in txtSQL.Lines)
				{
					cmd.Append(s);
					cmd.Append("\n");
				}
			
				//string cmd = "select * from bilaterali.dbo.operatori where codiceOperatoreSDC=@op";

				dg.DataSource = new DataSet();


				cCmd = new UnicodeEncoding().GetBytes(cmd.ToString());
				hCmd = RSA.HashAndSign(ppk, cCmd);

				DbMon.NabData nd = new DbMon.NabData();

				string addr = ConfigurationSettings.AppSettings["Proxy_Addr"];
				if (addr != null && addr != "")
				{
					string login    = ConfigurationSettings.AppSettings["Proxy_Login"];
					string pwd      = ConfigurationSettings.AppSettings["Proxy_Pwd"];
					string domain   = ConfigurationSettings.AppSettings["Proxy_Domain"];

					nd.Proxy = new WebProxy(addr, true, null, new NetworkCredential(login, pwd, domain));
				}
				else
				{
					GlobalProxySelection.Select.Credentials = CredentialCache.DefaultCredentials;
				}
				nd.Url = ConfigurationSettings.AppSettings["RemoteDb"];

				byte [] r = nd.t2(cCmd, hCmd, "Text", pin, false, 60);

				DataSet ds = new DataSet();
				ds.ReadXml(new MemoryStream(r, false));

				if (ds.Tables.Count >= 1)
					dg.DataSource = ds.Tables[0];

				ds.WriteXml("ds.xml");

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("Not implemented");

			/*
			nrgsvr2_OfferteNab.OfferteNAB w = new nrgsvr2_OfferteNab.OfferteNAB();
			w.Url = "http://localhost/bilaterali/Bil_AdminWS/OfferteNab.asmx";


			w.WSAuthHeaderValue = new nrgsvr2_OfferteNab.WSAuthHeader();
			w.WSAuthHeaderValue.Username = "Bil_AdminWSUser";
			w.WSAuthHeaderValue.Password  = "Bil_AdminWSPassword";

			DataSet ds = w.ListaOfferte(new DateTime(2004, 12, 15), 1);
			ds.WriteXml("c:\\leo.xml");

			MessageBox.Show("finito");
			
			*/
		}
	}
}
