using System;
using DimeSoapExtension;
using Bil_GMEWebClient.localhost;

namespace Bil_GMEWebClient {
    /// <summary>
    /// Summary description for Service1Proxy.
    /// </summary>
    public class GMEWebServiceProxy : GMEWebService, IDimeAttachmentContainer {
        public GMEWebServiceProxy() : base() {
        }

        DimeAttachmentCollection requestAttachments;
        DimeAttachmentCollection responseAttachments;

        // IDimeAttachmentContainer.RequestAttachments
        public DimeAttachmentCollection RequestAttachments { 
            get {
                if (requestAttachments == null) 
                    requestAttachments = new DimeAttachmentCollection();
                return requestAttachments;
            }
        }

        // IDimeAttachmentContainer.ResponseAttachments
        public DimeAttachmentCollection ResponseAttachments { 
            get {
                if (responseAttachments == null) 
                    responseAttachments = new DimeAttachmentCollection();
                return responseAttachments;
            }
        }
    }
}
