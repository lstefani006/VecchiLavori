using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Web.Services.Protocols;
using Dime;
using DimeSoapExtension;
using System.Text;
using System.IO;
using Bil_Crypt;


namespace Bil_GMEWebClient 
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
	public class Form1 : System.Windows.Forms.Form 
	{
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox User;
		private System.Windows.Forms.TextBox Password;
		private System.Windows.Forms.TextBox MsgFileName;
		private System.Windows.Forms.TextBox Uploadfile;
		private System.Windows.Forms.Label UsrLabel;
		private System.Windows.Forms.Label PwdLabel;
		private System.Windows.Forms.Label FileNameLabel;
		private System.Windows.Forms.Label UpldFileLabel;
		private System.Windows.Forms.Label DwnlLabel;
		private System.Windows.Forms.TextBox DownloadDir;
		private System.Windows.Forms.Button RemoveFirstFile;
		private System.Windows.Forms.Button UploadAtt;
		private System.Windows.Forms.Button DownloadAtt;
		private System.Windows.Forms.Button GetNextFilesToDownload;
		private System.Windows.Forms.TextBox urlText;
		private System.Windows.Forms.Label UrlLabel;
		private System.Windows.Forms.Button DownloadZip;
		private System.Windows.Forms.Button Upload;
		private System.Windows.Forms.Button Download;
		private System.Windows.Forms.Button UploadNotZip;
		private System.Windows.Forms.DateTimePicker dataInizioRicerca;
		private System.Windows.Forms.DateTimePicker dataFineRicerca;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnOperatoriPerData;
		private System.Windows.Forms.Button btnOperatoriAbilitatiPerIntervallo;
		private System.Windows.Forms.Button btnOperatoriMEAttivi;
		private System.Windows.Forms.Button btnUploadFatturaAtt;
		private System.Windows.Forms.Button btnFatturaPassiva;
		private System.Windows.Forms.Button btnFatturaOboloGME;
		private System.Windows.Forms.TextBox txtCodiceOperatoreSDC;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtDOCID;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.DateTimePicker dtDataFattura;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtFileFattura;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.CheckBox chkZipped;
		private System.Windows.Forms.TextBox txtABPID;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1() 
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) 
		{
			if( disposing ) 
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() 
		{
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.UploadNotZip = new System.Windows.Forms.Button();
			this.DownloadZip = new System.Windows.Forms.Button();
			this.User = new System.Windows.Forms.TextBox();
			this.Password = new System.Windows.Forms.TextBox();
			this.MsgFileName = new System.Windows.Forms.TextBox();
			this.Uploadfile = new System.Windows.Forms.TextBox();
			this.DownloadDir = new System.Windows.Forms.TextBox();
			this.UsrLabel = new System.Windows.Forms.Label();
			this.PwdLabel = new System.Windows.Forms.Label();
			this.FileNameLabel = new System.Windows.Forms.Label();
			this.UpldFileLabel = new System.Windows.Forms.Label();
			this.DwnlLabel = new System.Windows.Forms.Label();
			this.RemoveFirstFile = new System.Windows.Forms.Button();
			this.UploadAtt = new System.Windows.Forms.Button();
			this.DownloadAtt = new System.Windows.Forms.Button();
			this.GetNextFilesToDownload = new System.Windows.Forms.Button();
			this.urlText = new System.Windows.Forms.TextBox();
			this.UrlLabel = new System.Windows.Forms.Label();
			this.Upload = new System.Windows.Forms.Button();
			this.Download = new System.Windows.Forms.Button();
			this.dataInizioRicerca = new System.Windows.Forms.DateTimePicker();
			this.dataFineRicerca = new System.Windows.Forms.DateTimePicker();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btnOperatoriPerData = new System.Windows.Forms.Button();
			this.btnOperatoriAbilitatiPerIntervallo = new System.Windows.Forms.Button();
			this.btnOperatoriMEAttivi = new System.Windows.Forms.Button();
			this.btnUploadFatturaAtt = new System.Windows.Forms.Button();
			this.btnFatturaPassiva = new System.Windows.Forms.Button();
			this.btnFatturaOboloGME = new System.Windows.Forms.Button();
			this.txtCodiceOperatoreSDC = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtDOCID = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.txtABPID = new System.Windows.Forms.TextBox();
			this.dtDataFattura = new System.Windows.Forms.DateTimePicker();
			this.label7 = new System.Windows.Forms.Label();
			this.txtFileFattura = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.chkZipped = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(32, 472);
			this.textBox2.Multiline = true;
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(824, 128);
			this.textBox2.TabIndex = 2;
			this.textBox2.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(40, 184);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 24);
			this.label1.TabIndex = 3;
			this.label1.Text = "Results:";
			// 
			// UploadNotZip
			// 
			this.UploadNotZip.Location = new System.Drawing.Point(240, 24);
			this.UploadNotZip.Name = "UploadNotZip";
			this.UploadNotZip.Size = new System.Drawing.Size(96, 40);
			this.UploadNotZip.TabIndex = 5;
			this.UploadNotZip.Text = "UploadNotZip";
			this.UploadNotZip.Click += new System.EventHandler(this.UploadNotZip_Click);
			// 
			// DownloadZip
			// 
			this.DownloadZip.Location = new System.Drawing.Point(240, 136);
			this.DownloadZip.Name = "DownloadZip";
			this.DownloadZip.Size = new System.Drawing.Size(96, 40);
			this.DownloadZip.TabIndex = 6;
			this.DownloadZip.Text = "DownloadZip";
			this.DownloadZip.Click += new System.EventHandler(this.DownloadZip_Click);
			// 
			// User
			// 
			this.User.Location = new System.Drawing.Point(80, 24);
			this.User.Name = "User";
			this.User.Size = new System.Drawing.Size(144, 20);
			this.User.TabIndex = 7;
			this.User.Text = "GRTN";
			// 
			// Password
			// 
			this.Password.Location = new System.Drawing.Point(80, 64);
			this.Password.Name = "Password";
			this.Password.Size = new System.Drawing.Size(144, 20);
			this.Password.TabIndex = 8;
			this.Password.Text = "user";
			// 
			// MsgFileName
			// 
			this.MsgFileName.Location = new System.Drawing.Point(24, 128);
			this.MsgFileName.Name = "MsgFileName";
			this.MsgFileName.Size = new System.Drawing.Size(208, 20);
			this.MsgFileName.TabIndex = 9;
			this.MsgFileName.Text = "MGPOffers_IDGRTNBI.in.xml";
			// 
			// Uploadfile
			// 
			this.Uploadfile.Location = new System.Drawing.Point(448, 40);
			this.Uploadfile.Name = "Uploadfile";
			this.Uploadfile.Size = new System.Drawing.Size(448, 20);
			this.Uploadfile.TabIndex = 10;
			this.Uploadfile.Text = "E:\\Bilaterali\\Bil_GMEWebClient\\UploadDir\\MGPOffers_IDGRTNBI.in.xml";
			// 
			// DownloadDir
			// 
			this.DownloadDir.Location = new System.Drawing.Point(440, 104);
			this.DownloadDir.Name = "DownloadDir";
			this.DownloadDir.Size = new System.Drawing.Size(448, 20);
			this.DownloadDir.TabIndex = 11;
			this.DownloadDir.Text = "E:\\Bilaterali\\Bil_GMEWebClient\\DownloadDir";
			// 
			// UsrLabel
			// 
			this.UsrLabel.Location = new System.Drawing.Point(8, 24);
			this.UsrLabel.Name = "UsrLabel";
			this.UsrLabel.Size = new System.Drawing.Size(40, 16);
			this.UsrLabel.TabIndex = 12;
			this.UsrLabel.Text = "User";
			// 
			// PwdLabel
			// 
			this.PwdLabel.Location = new System.Drawing.Point(8, 64);
			this.PwdLabel.Name = "PwdLabel";
			this.PwdLabel.Size = new System.Drawing.Size(56, 16);
			this.PwdLabel.TabIndex = 13;
			this.PwdLabel.Text = "Password";
			// 
			// FileNameLabel
			// 
			this.FileNameLabel.Location = new System.Drawing.Point(80, 104);
			this.FileNameLabel.Name = "FileNameLabel";
			this.FileNameLabel.Size = new System.Drawing.Size(56, 16);
			this.FileNameLabel.TabIndex = 14;
			this.FileNameLabel.Text = "FileName";
			// 
			// UpldFileLabel
			// 
			this.UpldFileLabel.Location = new System.Drawing.Point(448, 24);
			this.UpldFileLabel.Name = "UpldFileLabel";
			this.UpldFileLabel.Size = new System.Drawing.Size(192, 16);
			this.UpldFileLabel.TabIndex = 15;
			this.UpldFileLabel.Text = "Upload File";
			// 
			// DwnlLabel
			// 
			this.DwnlLabel.Location = new System.Drawing.Point(440, 80);
			this.DwnlLabel.Name = "DwnlLabel";
			this.DwnlLabel.Size = new System.Drawing.Size(192, 16);
			this.DwnlLabel.TabIndex = 16;
			this.DwnlLabel.Text = "Download Directory";
			// 
			// RemoveFirstFile
			// 
			this.RemoveFirstFile.Location = new System.Drawing.Point(240, 240);
			this.RemoveFirstFile.Name = "RemoveFirstFile";
			this.RemoveFirstFile.Size = new System.Drawing.Size(96, 40);
			this.RemoveFirstFile.TabIndex = 19;
			this.RemoveFirstFile.Text = "RemoveFirstFile";
			this.RemoveFirstFile.Click += new System.EventHandler(this.RemoveFirstFile_Click);
			// 
			// UploadAtt
			// 
			this.UploadAtt.Location = new System.Drawing.Point(352, 24);
			this.UploadAtt.Name = "UploadAtt";
			this.UploadAtt.Size = new System.Drawing.Size(80, 40);
			this.UploadAtt.TabIndex = 20;
			this.UploadAtt.Text = "UploadAtt";
			this.UploadAtt.Click += new System.EventHandler(this.UploadAtt_Click_1);
			// 
			// DownloadAtt
			// 
			this.DownloadAtt.Location = new System.Drawing.Point(352, 88);
			this.DownloadAtt.Name = "DownloadAtt";
			this.DownloadAtt.Size = new System.Drawing.Size(80, 40);
			this.DownloadAtt.TabIndex = 21;
			this.DownloadAtt.Text = "DownloadAtt";
			this.DownloadAtt.Click += new System.EventHandler(this.DownloadAtt_Click_1);
			// 
			// GetNextFilesToDownload
			// 
			this.GetNextFilesToDownload.Location = new System.Drawing.Point(352, 144);
			this.GetNextFilesToDownload.Name = "GetNextFilesToDownload";
			this.GetNextFilesToDownload.Size = new System.Drawing.Size(80, 40);
			this.GetNextFilesToDownload.TabIndex = 22;
			this.GetNextFilesToDownload.Text = "GetNextFilesToDownload";
			this.GetNextFilesToDownload.Click += new System.EventHandler(this.GetNextFilesToDownload_Click);
			// 
			// urlText
			// 
			this.urlText.Location = new System.Drawing.Point(440, 160);
			this.urlText.Name = "urlText";
			this.urlText.Size = new System.Drawing.Size(400, 20);
			this.urlText.TabIndex = 23;
			this.urlText.Text = "http://localhost/Bilaterali/Bil_GMEWebService/GMEWebService.asmx";
			// 
			// UrlLabel
			// 
			this.UrlLabel.Location = new System.Drawing.Point(440, 136);
			this.UrlLabel.Name = "UrlLabel";
			this.UrlLabel.Size = new System.Drawing.Size(144, 16);
			this.UrlLabel.TabIndex = 24;
			this.UrlLabel.Text = "URL";
			// 
			// Upload
			// 
			this.Upload.Location = new System.Drawing.Point(240, 80);
			this.Upload.Name = "Upload";
			this.Upload.Size = new System.Drawing.Size(96, 40);
			this.Upload.TabIndex = 25;
			this.Upload.Text = "Upload";
			this.Upload.Click += new System.EventHandler(this.Upload_Click);
			// 
			// Download
			// 
			this.Download.Location = new System.Drawing.Point(240, 184);
			this.Download.Name = "Download";
			this.Download.Size = new System.Drawing.Size(96, 40);
			this.Download.TabIndex = 26;
			this.Download.Text = "Download";
			this.Download.Click += new System.EventHandler(this.Download_Click);
			// 
			// dataInizioRicerca
			// 
			this.dataInizioRicerca.Location = new System.Drawing.Point(440, 232);
			this.dataInizioRicerca.Name = "dataInizioRicerca";
			this.dataInizioRicerca.TabIndex = 27;
			// 
			// dataFineRicerca
			// 
			this.dataFineRicerca.Location = new System.Drawing.Point(656, 232);
			this.dataFineRicerca.Name = "dataFineRicerca";
			this.dataFineRicerca.TabIndex = 28;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(448, 208);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(160, 16);
			this.label2.TabIndex = 29;
			this.label2.Text = "Data Inizio Ricerca";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(664, 208);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(184, 16);
			this.label3.TabIndex = 30;
			this.label3.Text = "Data Fine Ricerca";
			// 
			// btnOperatoriPerData
			// 
			this.btnOperatoriPerData.Location = new System.Drawing.Point(512, 264);
			this.btnOperatoriPerData.Name = "btnOperatoriPerData";
			this.btnOperatoriPerData.Size = new System.Drawing.Size(168, 32);
			this.btnOperatoriPerData.TabIndex = 31;
			this.btnOperatoriPerData.Text = "OperatoriAbilitatiMGPPerData";
			this.btnOperatoriPerData.Click += new System.EventHandler(this.btnOperatoriPerData_Click);
			// 
			// btnOperatoriAbilitatiPerIntervallo
			// 
			this.btnOperatoriAbilitatiPerIntervallo.Location = new System.Drawing.Point(688, 264);
			this.btnOperatoriAbilitatiPerIntervallo.Name = "btnOperatoriAbilitatiPerIntervallo";
			this.btnOperatoriAbilitatiPerIntervallo.Size = new System.Drawing.Size(192, 32);
			this.btnOperatoriAbilitatiPerIntervallo.TabIndex = 32;
			this.btnOperatoriAbilitatiPerIntervallo.Text = "OperatoriAbilitatiMGPPerIntervallo";
			this.btnOperatoriAbilitatiPerIntervallo.Click += new System.EventHandler(this.btnOperatoriAbilitatiPerIntervallo_Click);
			// 
			// btnOperatoriMEAttivi
			// 
			this.btnOperatoriMEAttivi.Location = new System.Drawing.Point(384, 264);
			this.btnOperatoriMEAttivi.Name = "btnOperatoriMEAttivi";
			this.btnOperatoriMEAttivi.Size = new System.Drawing.Size(120, 32);
			this.btnOperatoriMEAttivi.TabIndex = 33;
			this.btnOperatoriMEAttivi.Text = "OperatoriMEAttivi";
			this.btnOperatoriMEAttivi.Click += new System.EventHandler(this.btnOperatoriMEAttivi_Click);
			// 
			// btnUploadFatturaAtt
			// 
			this.btnUploadFatturaAtt.Location = new System.Drawing.Point(144, 304);
			this.btnUploadFatturaAtt.Name = "btnUploadFatturaAtt";
			this.btnUploadFatturaAtt.Size = new System.Drawing.Size(152, 40);
			this.btnUploadFatturaAtt.TabIndex = 34;
			this.btnUploadFatturaAtt.Text = "UploadFatturaAttivaGME";
			this.btnUploadFatturaAtt.Click += new System.EventHandler(this.btnUploadFatturaAtt_Click);
			// 
			// btnFatturaPassiva
			// 
			this.btnFatturaPassiva.Location = new System.Drawing.Point(144, 352);
			this.btnFatturaPassiva.Name = "btnFatturaPassiva";
			this.btnFatturaPassiva.Size = new System.Drawing.Size(152, 40);
			this.btnFatturaPassiva.TabIndex = 35;
			this.btnFatturaPassiva.Text = "UploadFatturaPassivaGME";
			this.btnFatturaPassiva.Click += new System.EventHandler(this.btnFatturaPassiva_Click);
			// 
			// btnFatturaOboloGME
			// 
			this.btnFatturaOboloGME.Location = new System.Drawing.Point(144, 408);
			this.btnFatturaOboloGME.Name = "btnFatturaOboloGME";
			this.btnFatturaOboloGME.Size = new System.Drawing.Size(152, 40);
			this.btnFatturaOboloGME.TabIndex = 36;
			this.btnFatturaOboloGME.Text = "UploadFatturaOboloGME";
			this.btnFatturaOboloGME.Click += new System.EventHandler(this.btnFatturaOboloGME_Click);
			// 
			// txtCodiceOperatoreSDC
			// 
			this.txtCodiceOperatoreSDC.Location = new System.Drawing.Point(440, 328);
			this.txtCodiceOperatoreSDC.Name = "txtCodiceOperatoreSDC";
			this.txtCodiceOperatoreSDC.Size = new System.Drawing.Size(192, 20);
			this.txtCodiceOperatoreSDC.TabIndex = 37;
			this.txtCodiceOperatoreSDC.Text = "OEEPSNL";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(312, 328);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(128, 16);
			this.label4.TabIndex = 38;
			this.label4.Text = "CodiceOperatoreSDC";
			// 
			// txtDOCID
			// 
			this.txtDOCID.Location = new System.Drawing.Point(440, 360);
			this.txtDOCID.Name = "txtDOCID";
			this.txtDOCID.Size = new System.Drawing.Size(192, 20);
			this.txtDOCID.TabIndex = 39;
			this.txtDOCID.Text = "11223344";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(320, 360);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(120, 16);
			this.label5.TabIndex = 40;
			this.label5.Text = "DocumentID";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(320, 392);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(96, 16);
			this.label6.TabIndex = 41;
			this.label6.Text = "ACCT_NUM";
			// 
			// txtABPID
			// 
			this.txtABPID.Location = new System.Drawing.Point(440, 392);
			this.txtABPID.Name = "txtABPID";
			this.txtABPID.Size = new System.Drawing.Size(192, 20);
			this.txtABPID.TabIndex = 42;
			this.txtABPID.Text = "112233";
			// 
			// dtDataFattura
			// 
			this.dtDataFattura.Location = new System.Drawing.Point(440, 424);
			this.dtDataFattura.Name = "dtDataFattura";
			this.dtDataFattura.TabIndex = 43;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(320, 424);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(112, 24);
			this.label7.TabIndex = 44;
			this.label7.Text = "Data Fattura";
			// 
			// txtFileFattura
			// 
			this.txtFileFattura.Location = new System.Drawing.Point(672, 392);
			this.txtFileFattura.Name = "txtFileFattura";
			this.txtFileFattura.Size = new System.Drawing.Size(192, 20);
			this.txtFileFattura.TabIndex = 45;
			this.txtFileFattura.Text = "Fattura.xml";
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(672, 368);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(184, 16);
			this.label8.TabIndex = 46;
			this.label8.Text = "File Fattura";
			// 
			// chkZipped
			// 
			this.chkZipped.Location = new System.Drawing.Point(672, 336);
			this.chkZipped.Name = "chkZipped";
			this.chkZipped.TabIndex = 47;
			this.chkZipped.Text = "Zippato";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(928, 621);
			this.Controls.Add(this.chkZipped);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.txtFileFattura);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.dtDataFattura);
			this.Controls.Add(this.txtABPID);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtDOCID);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtCodiceOperatoreSDC);
			this.Controls.Add(this.btnFatturaOboloGME);
			this.Controls.Add(this.btnFatturaPassiva);
			this.Controls.Add(this.btnUploadFatturaAtt);
			this.Controls.Add(this.btnOperatoriMEAttivi);
			this.Controls.Add(this.btnOperatoriAbilitatiPerIntervallo);
			this.Controls.Add(this.btnOperatoriPerData);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.dataFineRicerca);
			this.Controls.Add(this.dataInizioRicerca);
			this.Controls.Add(this.Download);
			this.Controls.Add(this.Upload);
			this.Controls.Add(this.UrlLabel);
			this.Controls.Add(this.urlText);
			this.Controls.Add(this.GetNextFilesToDownload);
			this.Controls.Add(this.DownloadAtt);
			this.Controls.Add(this.UploadAtt);
			this.Controls.Add(this.RemoveFirstFile);
			this.Controls.Add(this.DwnlLabel);
			this.Controls.Add(this.UpldFileLabel);
			this.Controls.Add(this.FileNameLabel);
			this.Controls.Add(this.PwdLabel);
			this.Controls.Add(this.UsrLabel);
			this.Controls.Add(this.DownloadDir);
			this.Controls.Add(this.Uploadfile);
			this.Controls.Add(this.MsgFileName);
			this.Controls.Add(this.Password);
			this.Controls.Add(this.User);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.DownloadZip);
			this.Controls.Add(this.UploadNotZip);
			this.Controls.Add(this.label1);
			this.Name = "Form1";
			this.Text = "GMEWebService Consumer";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void UploadNotZip_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;

			string password = Password.Text;
			string MsgName = MsgFileName.Text;
			string fileNameVal = Uploadfile.Text;
			
			FileInfo f = new FileInfo(fileNameVal);
			byte[] byteArray = new byte[f.Length];
			FileStream fStream = f.OpenRead();
			int length = (int) f.Length;
			fStream.Read(byteArray,0, length);
			fStream.Close();

			bool result; 

			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.UploadMessageNotZipped(MsgName,byteArray); 
				if (result)
					textBox2.Text = "Upload Result = OK";
				else
					textBox2.Text = "Upload Result = FAIL";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;
		}


		private void DownloadZip_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			string MsgName = MsgFileName.Text;
			string DownloadDirNameVal = DownloadDir.Text;
			byte[] byteArray = new byte[1];
			
			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			bool result;

			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.DownloadMessageZipped(ref MsgName, ref byteArray); 
			
				if (result)
				{
					string fileNameVal = DownloadDirNameVal + "\\" + MsgName;
					int length = byteArray.Length;
					FileInfo f = new FileInfo(fileNameVal);
					FileStream fStream = f.OpenWrite();
					fStream.Write(byteArray,0, length);
					fStream.Close();
				}
				if (result)
					textBox2.Text = "Download Result = OK";
				else
					textBox2.Text = "Download Result = FAIL or NO FILE";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;
		}


		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void RemoveFirstFile_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			bool result=false;
			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.RemoveFirstFile(); 
				if (result)
					textBox2.Text = "RemoveFirstFile Result = OK";
				else
					textBox2.Text = "RemoveFirstFile Result = FAIL or NO FILE";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally
			{
				this.Cursor = savedCursor;
			}
		}

		private void UploadAtt_Click_1(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			string MsgName = MsgFileName.Text;
			string fileNameVal = Uploadfile.Text;
			
			FileInfo f = new FileInfo(fileNameVal);
			byte[] byteArray = new byte[f.Length];
			FileStream fStream = f.OpenRead();
			int length = (int) f.Length;
			fStream.Read(byteArray,0, length);
			fStream.Close();

			DimeAttachment attachment;
			MemoryStream stream = new MemoryStream(byteArray);
			string typeName = "plain/text; charset=utf-8";
			TypeFormatEnum typeFormat = TypeFormatEnum.MediaType;

			string uriName = "file://" + MsgName;
			attachment = new DimeAttachment(uriName, typeName, typeFormat, stream);

			bool result;

			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.RequestAttachments.Add(attachment);
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				
				result = proxy.UploadMessageAttachment(MsgName); 
				if (result)
					textBox2.Text = "Upload Attachment Result = OK";
				else
					textBox2.Text = "Upload Attachment Result = FAIL";
				proxy.RequestAttachments.Remove(attachment);
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;
		
		}

		private void DownloadAtt_Click_1(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			string MsgName = MsgFileName.Text;
			string DownloadDirNameVal = DownloadDir.Text;
			
			DimeAttachment attachment;
			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			bool result;

			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				
				result = proxy.DownloadMessageAttachment(ref MsgName); 
			
				if (result)
				{
					if (proxy.ResponseAttachments.Count > 0)
					{
						attachment = proxy.ResponseAttachments[0];

						//
						// Ottieni message stream e scrivi su file
						//
						int length = (int) attachment.Stream.Length;

						//
						// 
						//
						Uri  attrUri = new Uri(attachment.Id);
						string remoteFileName = attrUri.Host;
						string fileNameVal = DownloadDirNameVal + "\\" + remoteFileName;
						
						byte[] byteArray = new byte[length];
						attachment.Stream.Read(byteArray, 0, length);
						FileInfo f = new FileInfo(fileNameVal);
						FileStream fStream = f.OpenWrite();
						fStream.Write(byteArray,0, length);
						fStream.Close();
						proxy.ResponseAttachments.Remove(attachment);
					}
				}

				if (result)
					textBox2.Text = "Download Attachment Result = OK";
				else
					textBox2.Text = "Download Attachment Result = FAIL or NO FILE";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;
		}

		private void GetNextFilesToDownload_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			bool result=false;
			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			string[] filenameArray = new string[1];
			int numberOfFiles =0;

			
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.GetNextFilesToDownload(ref filenameArray, ref numberOfFiles);
				if (result)
				{
					StringBuilder strToWrite = new StringBuilder();
					strToWrite.Append("GetNextFilesToDownload Result = OK");
					strToWrite.Append("\n");
					int fileCount = 0;
					for (fileCount=0; fileCount<numberOfFiles; fileCount++)
					{
						strToWrite.Append("File [");
						strToWrite.Append(fileCount.ToString());
						strToWrite.Append("] ==> ");
						strToWrite.Append(filenameArray[fileCount]);	
						strToWrite.Append("\n");
					}
					textBox2.Text = strToWrite.ToString();
				}
				else
					textBox2.Text = "GetNextFilesToDownload Result = FAIL or NO FILE";
	
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally
			{
				this.Cursor = savedCursor;
			}
		}

		private void Upload_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;

			string password = Password.Text;
			string MsgName = MsgFileName.Text;
			string fileNameVal = Uploadfile.Text;
			
			FileInfo f = new FileInfo(fileNameVal);
			byte[] byteArray = new byte[f.Length];
			FileStream fStream = f.OpenRead();
			int length = (int) f.Length;
			fStream.Read(byteArray,0, length);
			fStream.Close();

			byte[] byteArrayZipped = Bil.BilZipLib.ZipSingleFile(fileNameVal, byteArray, 9);

			bool result; 

			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				
				result = proxy.UploadMessage(MsgName,byteArrayZipped); 
				if (result)
					textBox2.Text = "UploadZip Result = OK";
				else
					textBox2.Text = "UploadZip Result = FAIL";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;
		}

		private void Download_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			string MsgName = MsgFileName.Text;
			string DownloadDirNameVal = DownloadDir.Text;
			byte[] byteArray = new byte[1];
			
			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			bool result;

			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				
				result = proxy.DownloadMessage(ref MsgName, ref byteArray); 
			
				if (result)
				{
					string fileNameVal = DownloadDirNameVal + "\\" + MsgName;
					int length = byteArray.Length;
					FileInfo f = new FileInfo(fileNameVal);
					FileStream fStream = f.OpenWrite();
					fStream.Write(byteArray,0, length);
					fStream.Close();
				}
				if (result)
					textBox2.Text = "Download Result = OK";
				else
					textBox2.Text = "Download Result = FAIL or NO FILE";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;
		}

		private void btnOperatoriPerData_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			bool result=false;
			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			DateTime dataRicerca = dataInizioRicerca.Value;
			string[] OperatoriAbilitatiMGP = null;

			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.OperatoriAbilitatiMGPPerData(dataRicerca, ref OperatoriAbilitatiMGP); 
				if (result)
				{
					if (OperatoriAbilitatiMGP != null)
					{
						string Operatori = "";
						for (int i=0; i<OperatoriAbilitatiMGP.Length; i++)
						{
							Operatori += "Operatore[" + i.ToString() + "] ==>" + OperatoriAbilitatiMGP[i] + "\r\n";
						}
						textBox2.Text = Operatori;
					}
				}
				else
					textBox2.Text = "OperatoriAbilitatiMGPPerData fallito o nessun operatore";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally
			{
				this.Cursor = savedCursor;
			}
		}

		private void btnOperatoriAbilitatiPerIntervallo_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			bool result=false;
			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			DateTime inizioRicerca = dataInizioRicerca.Value;
			DateTime fineRicerca = dataFineRicerca.Value;
			string[] OperatoriAbilitatiMGP = null;
			DateTime[] DataInizioValidita = null;
			DateTime[] DataFineValidita = null;
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.OperatoriAbilitatiMGPPerIntervalloDate(inizioRicerca, fineRicerca,
					ref OperatoriAbilitatiMGP, ref DataInizioValidita, ref DataFineValidita); 
				if (result)
				{
					if (OperatoriAbilitatiMGP != null)
					{
						string Operatori = "";
						for (int i=0; i<OperatoriAbilitatiMGP.Length; i++)
						{
							Operatori += "Operatore[" + i.ToString() + "] ==>" + OperatoriAbilitatiMGP[i] +  " InizioVal=" + DataInizioValidita[i].ToShortDateString() + " FineVal=" + DataFineValidita[i].ToShortDateString()+"\r\n";
						}
						textBox2.Text = Operatori;
					}
				}
				else
					textBox2.Text = "OperatoriAbilitatiMGPPerData fallito o nessun operatore";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally
			{
				this.Cursor = savedCursor;
			}
		}

		private void btnOperatoriMEAttivi_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			bool result=false;
			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			string[] OperatoriAbilitatiME = null;

			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();            
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.OperatoriMEAbilitati(ref OperatoriAbilitatiME); 
				if (result)
				{
					if (OperatoriAbilitatiME != null)
					{
						string Operatori = "";
						for (int i=0; i<OperatoriAbilitatiME.Length; i++)
						{
							Operatori += "Operatore[" + i.ToString() + "] ==>" + OperatoriAbilitatiME[i] + "\r\n";
						}
						textBox2.Text = Operatori;
					}
				}
				else
					textBox2.Text = "OperatoriAbilitatiME fallito o nessun operatore";
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally
			{
				this.Cursor = savedCursor;
			}
		}

		private void btnUploadFatturaAtt_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			string fileNameVal = txtFileFattura.Text;
			
			FileInfo f = new FileInfo(fileNameVal);
			byte[] byteArray = new byte[f.Length];
			FileStream fStream = f.OpenRead();
			int length = (int) f.Length;
			fStream.Read(byteArray,0, length);
			fStream.Close();

			byte[] byteArrayZipped;

			if (chkZipped.Checked)
				byteArrayZipped = Bil.BilZipLib.ZipSingleFile(fileNameVal, byteArray, 9);
			else
				byteArrayZipped = byteArray;

			bool result; 

			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				
				result = proxy.UploadFatturaAttivaGME(chkZipped.Checked, txtCodiceOperatoreSDC.Text,
					txtABPID.Text, txtDOCID.Text, dtDataFattura.Value, byteArrayZipped);
				if (result)
				{
					if (chkZipped.Checked)
						textBox2.Text = "Upload Fattura Attiva ZIPPATO = OK";
					else
						textBox2.Text = "Upload Fattura Attiva NON ZIPPATO = OK";
				}
				else
				{
					if (chkZipped.Checked)
						textBox2.Text = "Upload Fattura Attiva ZIPPATO = FAILED";
					else
						textBox2.Text = "Upload Fattura Attiva NON ZIPPATO = FAILED";
				}
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;		
		}

		private void btnFatturaPassiva_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			string fileNameVal = txtFileFattura.Text;
			
			FileInfo f = new FileInfo(fileNameVal);
			byte[] byteArray = new byte[f.Length];
			FileStream fStream = f.OpenRead();
			int length = (int) f.Length;
			fStream.Read(byteArray,0, length);
			fStream.Close();

			byte[] byteArrayZipped;

			if (chkZipped.Checked)
				byteArrayZipped = Bil.BilZipLib.ZipSingleFile(fileNameVal, byteArray, 9);
			else
				byteArrayZipped = byteArray;

			bool result; 

			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.UploadFatturaPassivaGME(chkZipped.Checked, txtCodiceOperatoreSDC.Text,
					txtABPID.Text, txtDOCID.Text, dtDataFattura.Value, byteArrayZipped);
				if (result)
				{
					if (chkZipped.Checked)
						textBox2.Text = "Upload Fattura Passiva ZIPPATO = OK";
					else
						textBox2.Text = "Upload Fattura Passiva NON ZIPPATO = OK";
				}
				else
				{
					if (chkZipped.Checked)
						textBox2.Text = "Upload Fattura Passiva ZIPPATO = FAILED";
					else
						textBox2.Text = "Upload Fattura Passiva NON ZIPPATO = FAILED";
				}
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;		
		}

		private void btnFatturaOboloGME_Click(object sender, System.EventArgs e)
		{
			string user = User.Text;
			string password = Password.Text;
			string fileNameVal = txtFileFattura.Text;
			
			FileInfo f = new FileInfo(fileNameVal);
			byte[] byteArray = new byte[f.Length];
			FileStream fStream = f.OpenRead();
			int length = (int) f.Length;
			fStream.Read(byteArray,0, length);
			fStream.Close();

			byte[] byteArrayZipped;

			if (chkZipped.Checked)
				byteArrayZipped = Bil.BilZipLib.ZipSingleFile(fileNameVal, byteArray, 9);
			else
				byteArrayZipped = byteArray;

			bool result; 

			Cursor savedCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			try 
			{
				GMEWebServiceProxy proxy = new GMEWebServiceProxy();
				proxy.WSAuthHeaderValue = new Bil_GMEWebClient.localhost.WSAuthHeader();
				WSClient.SetupNoAuthHeader(proxy,"ME");
				proxy.WSAuthHeaderValue.Username = user;
				proxy.WSAuthHeaderValue.Password = password;
				proxy.Url = urlText.Text;
				result = proxy.UploadFatturaOboloGME(chkZipped.Checked, txtCodiceOperatoreSDC.Text,
					txtABPID.Text, txtDOCID.Text, dtDataFattura.Value, byteArrayZipped);
				if (result)
				{
					if (chkZipped.Checked)
						textBox2.Text = "Upload Fattura Obolo ZIPPATO = OK";
					else
						textBox2.Text = "Upload Fattura Obolo NON ZIPPATO = OK";
				}
				else
				{
					if (chkZipped.Checked)
						textBox2.Text = "Upload Fattura Obolo ZIPPATO = FAILED";
					else
						textBox2.Text = "Upload Fattura Obolo NON ZIPPATO = FAILED";
				}
			}
			catch(SoapException err)
			{
				textBox2.Text = err.Message;
				this.Cursor = savedCursor;
			}
			finally 
			{
				this.Cursor = savedCursor;
			}
			return;		
		}
	}
}
