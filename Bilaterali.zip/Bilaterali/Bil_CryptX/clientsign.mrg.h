// Created by Microsoft (R) C/C++ Compiler Version 13.10.3077
//
// c:\bilaterali\bil_cryptx\clientsign.mrg.h
// compiler-generated file created 01/02/06 at 10:07:13
//
// This C++ source file is intended to be a representation of the
// source code injected by the compiler.  It may not compile or
// run exactly as the original source file.
//


//+++ Start Injected Code
[no_injected_text(true)];      // Suppress injected text, it has already been injected
#pragma warning(disable: 4543) // Suppress warnings about skipping injected text
#pragma warning(disable: 4199) // Suppress warnings from attribute providers

// M00PRAGMA("\n\nNOTE: This merged source file should be visually inspected for correctness.\n\n")
//--- End Injected Code

// ClientSign.h : Declaration of the CClientSign

#pragma once
#include "resource.h"       // main symbols
#include "GMECryptClass.h"


// IClientSign
[
	object,
	uuid("AD05D448-F5CE-4783-9853-17C8D19759CD"),
	dual,	helpstring("IClientSign Interface"),
	pointer_default(unique)
]
__interface IClientSign : IDispatch
{
	[id(1), helpstring("method FindAvailableCertificate")] HRESULT FindAvailableCertificate(VARIANT_BOOL LocalMachine);
	[propget, id(2), helpstring("property CertificateCount")] HRESULT CertificateCount([out, retval] LONG* pVal);
	[id(3), helpstring("method GetSubject")] HRESULT GetSubject([in] LONG nIndex, [out,retval] BSTR* Subject);
	[id(4), helpstring("method GetIssuer")] HRESULT GetIssuer([in] LONG nIndex, [out,retval] BSTR* Issuer);
	[id(5), helpstring("method SignFile")] HRESULT SignFile([in] BSTR CertificateSubject, [in] BSTR FileName, [out,retval] BSTR * SignedDocument);
	[id(6), helpstring("method SignBuffer")] HRESULT SignBuffer([in] BSTR certName, [in] BSTR InData, [out,retval] BSTR* OutData);
	[id(7), helpstring("method SignBufferById")] HRESULT SignBufferById([in] LONG index, [in] BSTR InData, [out,retval] BSTR* OutData);
	[id(8), helpstring("method SignFileById")] HRESULT SignFileById([in] LONG index, [in] BSTR FileName, [out,retval] BSTR* OutData);
};



// CClientSign

[
	coclass,
	threading("apartment"),
	support_error_info("IClientSign"),
	vi_progid("Bil_CryptX.ClientSign"),
	progid("Bil_CryptX.ClientSign.1"),
	version(1.0),
	uuid("5CF632EC-49E4-4E24-B164-258A76A90284"),
	helpstring("ClientSign Class")
]
class ATL_NO_VTABLE CClientSign : 
	public IClientSign,
	public IObjectSafetyImpl<CClientSign, INTERFACESAFE_FOR_UNTRUSTED_CALLER>
,
    /*+++ Added Baseclass */ public CComCoClass<CClientSign, &__uuidof(CClientSign)>,
    /*+++ Added Baseclass */ public CComObjectRootEx<CComSingleThreadModel>,
    /*+++ Added Baseclass */ public IProvideClassInfoImpl<&__uuidof(CClientSign)>,
    /*+++ Added Baseclass */ public ISupportErrorInfo
{
public:
	CClientSign()
	{
	}

	CGMECryptClass c;


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(FindAvailableCertificate)(VARIANT_BOOL LocalMachine);
	STDMETHOD(get_CertificateCount)(LONG* pVal);
	STDMETHOD(GetSubject)(LONG nIndex, BSTR* Subject);
	STDMETHOD(GetIssuer)(LONG nIndex, BSTR* Issuer);
	STDMETHOD(SignFile)(BSTR CertificateSubject, BSTR FileName, BSTR * SignedDocument);
	STDMETHOD(SignBuffer)(BSTR InData, BSTR certName, BSTR* OutData);
	STDMETHOD(SignBufferById)(LONG index, BSTR InData, BSTR* OutData);
	STDMETHOD(SignFileById)(LONG index, BSTR FileName, BSTR* OutData);

	//+++ Start Injected Code For Attribute 'support_error_info'
#injected_line 39 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    virtual HRESULT STDMETHODCALLTYPE IClientSign::Invoke(
                /* [in] */ DISPID dispIdMember,
                /* [in] */ REFIID riid,
                /* [in] */ LCID lcid,
                /* [in] */ WORD wFlags,
                /* [out][in] */ DISPPARAMS *pDispParams,
                /* [out] */ VARIANT *pVarResult,
                /* [out] */ EXCEPINFO *pExcepInfo,
                /* [out] */ UINT *puArgErr) 
    {
        (void) riid;
        (void) dispIdMember;
        (void) lcid;
        (void) wFlags;
        (void) pExcepInfo;
        (void) puArgErr;
        HRESULT hr = S_OK;
        if (pDispParams == 0) {
            return DISP_E_BADVARTYPE;
        }
        if (pDispParams->cArgs > 3) {
            return DISP_E_BADPARAMCOUNT;
        }
        if (pVarResult != 0) {
            ::VariantInit(pVarResult);
        }
        VARIANT* rgpVars[3];
        UINT index = 0;
        if (pDispParams->cNamedArgs > 0) {
            if (pDispParams->rgdispidNamedArgs[0] == DISPID_PROPERTYPUT) {
                rgpVars[0] = &pDispParams->rgvarg[0];
                index = 1;
            }
            for (; index < pDispParams->cNamedArgs; ++index) {
                if (pDispParams->rgdispidNamedArgs[index] >= (int) pDispParams->cArgs || pDispParams->rgdispidNamedArgs[index] < 0) {
                    if (puArgErr != 0) {
                        *puArgErr = index;
                    }
                    return DISP_E_PARAMNOTFOUND;
                }
                rgpVars[pDispParams->cArgs - pDispParams->rgdispidNamedArgs[index] - 1] = &pDispParams->rgvarg[index];
            }
        }
        for (; index < pDispParams->cArgs; ++index) {
            rgpVars[index] = &pDispParams->rgvarg[index];
        }
        VARIANT v0;
        VARIANT* v;
        switch (dispIdMember) {
        case 1:
            {
                if (pDispParams->cArgs != 1) {
                    return DISP_E_BADPARAMCOUNT;
                }
                v = rgpVars[0];
                if (v->vt != VT_BOOL && FAILED(__VariantChangeType(v, &v0, VT_BOOL))) {
                    if (puArgErr != 0) {
                        *puArgErr = 0;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                VARIANT_BOOL i1 = (VARIANT_BOOL) V_BOOL(v);
                hr = ((::IClientSign*) this)->FindAvailableCertificate(i1);
                break;
            }
        case 2:
            {
                if (pDispParams->cArgs != 0) {
                    return DISP_E_BADPARAMCOUNT;
                }
                long i1;
                hr = ((::IClientSign*) this)->get_CertificateCount(&i1);
                if (pVarResult != 0) {
                    V_VT(pVarResult) = VT_I4;
                    V_I4(pVarResult) = i1;
                }
                break;
            }
        case 3:
            {
                if (pDispParams->cArgs != 1) {
                    return DISP_E_BADPARAMCOUNT;
                }
                v = rgpVars[0];
                if (v->vt != VT_I4 && FAILED(__VariantChangeType(v, &v0, VT_I4))) {
                    if (puArgErr != 0) {
                        *puArgErr = 0;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                long i1 = V_I4(v);
                BSTR i2;
                hr = ((::IClientSign*) this)->GetSubject(i1, &i2);
                if (pVarResult != 0) {
                    V_VT(pVarResult) = VT_BSTR;
                    V_BSTR(pVarResult) = (BSTR) i2;
                }
                break;
            }
        case 4:
            {
                if (pDispParams->cArgs != 1) {
                    return DISP_E_BADPARAMCOUNT;
                }
                v = rgpVars[0];
                if (v->vt != VT_I4 && FAILED(__VariantChangeType(v, &v0, VT_I4))) {
                    if (puArgErr != 0) {
                        *puArgErr = 0;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                long i1 = V_I4(v);
                BSTR i2;
                hr = ((::IClientSign*) this)->GetIssuer(i1, &i2);
                if (pVarResult != 0) {
                    V_VT(pVarResult) = VT_BSTR;
                    V_BSTR(pVarResult) = (BSTR) i2;
                }
                break;
            }
        case 5:
            {
                if (pDispParams->cArgs != 2) {
                    return DISP_E_BADPARAMCOUNT;
                }
                v = rgpVars[1];
                if (v->vt != VT_BSTR && FAILED(__VariantChangeType(v, &v0, VT_BSTR))) {
                    if (puArgErr != 0) {
                        *puArgErr = 1;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                BSTR i1 = (BSTR) V_BSTR(v);
                v = rgpVars[0];
                if (v->vt != VT_BSTR && FAILED(__VariantChangeType(v, &v0, VT_BSTR))) {
                    if (puArgErr != 0) {
                        *puArgErr = 0;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                BSTR i2 = (BSTR) V_BSTR(v);
                BSTR i3;
                hr = ((::IClientSign*) this)->SignFile(i1, i2, &i3);
                if (pVarResult != 0) {
                    V_VT(pVarResult) = VT_BSTR;
                    V_BSTR(pVarResult) = (BSTR) i3;
                }
                break;
            }
        case 6:
            {
                if (pDispParams->cArgs != 2) {
                    return DISP_E_BADPARAMCOUNT;
                }
                v = rgpVars[1];
                if (v->vt != VT_BSTR && FAILED(__VariantChangeType(v, &v0, VT_BSTR))) {
                    if (puArgErr != 0) {
                        *puArgErr = 1;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                BSTR i1 = (BSTR) V_BSTR(v);
                v = rgpVars[0];
                if (v->vt != VT_BSTR && FAILED(__VariantChangeType(v, &v0, VT_BSTR))) {
                    if (puArgErr != 0) {
                        *puArgErr = 0;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                BSTR i2 = (BSTR) V_BSTR(v);
                BSTR i3;
                hr = ((::IClientSign*) this)->SignBuffer(i1, i2, &i3);
                if (pVarResult != 0) {
                    V_VT(pVarResult) = VT_BSTR;
                    V_BSTR(pVarResult) = (BSTR) i3;
                }
                break;
            }
        case 7:
            {
                if (pDispParams->cArgs != 2) {
                    return DISP_E_BADPARAMCOUNT;
                }
                v = rgpVars[1];
                if (v->vt != VT_I4 && FAILED(__VariantChangeType(v, &v0, VT_I4))) {
                    if (puArgErr != 0) {
                        *puArgErr = 1;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                long i1 = V_I4(v);
                v = rgpVars[0];
                if (v->vt != VT_BSTR && FAILED(__VariantChangeType(v, &v0, VT_BSTR))) {
                    if (puArgErr != 0) {
                        *puArgErr = 0;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                BSTR i2 = (BSTR) V_BSTR(v);
                BSTR i3;
                hr = ((::IClientSign*) this)->SignBufferById(i1, i2, &i3);
                if (pVarResult != 0) {
                    V_VT(pVarResult) = VT_BSTR;
                    V_BSTR(pVarResult) = (BSTR) i3;
                }
                break;
            }
        case 8:
            {
                if (pDispParams->cArgs != 2) {
                    return DISP_E_BADPARAMCOUNT;
                }
                v = rgpVars[1];
                if (v->vt != VT_I4 && FAILED(__VariantChangeType(v, &v0, VT_I4))) {
                    if (puArgErr != 0) {
                        *puArgErr = 1;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                long i1 = V_I4(v);
                v = rgpVars[0];
                if (v->vt != VT_BSTR && FAILED(__VariantChangeType(v, &v0, VT_BSTR))) {
                    if (puArgErr != 0) {
                        *puArgErr = 0;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                BSTR i2 = (BSTR) V_BSTR(v);
                BSTR i3;
                hr = ((::IClientSign*) this)->SignFileById(i1, i2, &i3);
                if (pVarResult != 0) {
                    V_VT(pVarResult) = VT_BSTR;
                    V_BSTR(pVarResult) = (BSTR) i3;
                }
                break;
            }
        default:
            return DISP_E_MEMBERNOTFOUND;
        }
        return hr;
    }
    virtual HRESULT STDMETHODCALLTYPE IClientSign::GetIDsOfNames(
                /* [in] */ REFIID riid,
                /* [size_is][in] */ LPOLESTR *rgszNames,
                /* [in] */ UINT cNames,
                /* [in] */ LCID lcid,
                /* [size_is][out] */ DISPID *rgDispId) 
    {
        (void) riid;
        (void) rgszNames;
        (void) cNames;
        (void) lcid;
        (void) rgDispId;
        static LPOLESTR names[] = { L"LocalMachine", L"FindAvailableCertificate", L"CertificateCount", L"pVal", L"get_CertificateCount", L"nIndex", L"Subject", L"GetSubject", L"Issuer", L"GetIssuer", L"CertificateSubject", L"FileName", L"SignedDocument", L"SignFile", L"certName", L"InData", L"OutData", L"SignBuffer", L"index", L"SignBufferById", L"SignFileById" };
        static DISPID dids[] = { 0, 1, 2, 0, 2, 0, 1, 3, 1, 4, 0, 1, 2, 5, 0, 1, 2, 6, 0, 7, 8 };
        for (unsigned int i = 0; i < cNames; ++i) {
            int fFoundIt = 0;
            for (unsigned int j = 0; j < sizeof(names)/sizeof(LPOLESTR); ++j) {
                if (_wcsicmp(rgszNames[i], names[j]) == 0) {
                    fFoundIt = 1;
                    rgDispId[i] = dids[j];
                    break;
                }
            }
            if (fFoundIt == 0) {
                return DISP_E_UNKNOWNNAME;
            }
        }
        return S_OK;
    }
    HRESULT TypeInfoHelper(REFIID iidDisp, LCID /*lcid*/, ITypeInfo** ppTypeInfo) 
    {
        if (ppTypeInfo == NULL) {
            return E_POINTER;
        }
        *ppTypeInfo = NULL;
        TCHAR szModule1[_MAX_PATH];
        int nLen = ::GetModuleFileName(_AtlBaseModule.GetModuleInstance(), szModule1, _MAX_PATH);
        if (nLen == 0 || nLen == _MAX_PATH) {
            return E_FAIL;
        }
        USES_CONVERSION_EX;
        LPOLESTR pszModule = T2OLE_EX(szModule1, _ATL_SAFE_ALLOCA_DEF_THRESHOLD);
#ifndef _UNICODE
        if (pszModule == NULL) {
            return E_OUTOFMEMORY;
        }
#endif
        CComPtr<ITypeLib> spTypeLib;
        HRESULT hr = LoadTypeLib(pszModule, &spTypeLib);
        if (SUCCEEDED(hr)) {
            CComPtr<ITypeInfo> spTypeInfo;
            hr = spTypeLib->GetTypeInfoOfGuid(iidDisp, &spTypeInfo);
            if (SUCCEEDED(hr)) {
                *ppTypeInfo = spTypeInfo.Detach();
            }
        }
        return hr;
    }
    virtual HRESULT STDMETHODCALLTYPE IClientSign::GetTypeInfoCount(unsigned int*  pctinfo) 
    {
        if (pctinfo == NULL) {
            return E_POINTER;
        }
        CComPtr<ITypeInfo> spTypeInfo;
        *pctinfo = 
                       (SUCCEEDED(TypeInfoHelper(__uuidof(IClientSign), 0, &spTypeInfo))) ? 1 : 0;
        return S_OK;
    }
    virtual HRESULT STDMETHODCALLTYPE IClientSign::GetTypeInfo(unsigned int iTInfo, LCID lcid, ITypeInfo** ppTInfo) 
    {
        if (iTInfo != 0) {
            return DISP_E_BADINDEX;
        }
        return TypeInfoHelper(__uuidof(IClientSign), lcid, ppTInfo);
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    static DWORD* GetOpCodes() 
    {
        static DWORD rgOps[] = 
            					{
            						0x70000000,
            0x30004000,
            0x80000002,
            0x50000000,
            0x3000c000,
            0x80000004,
            0x60000000,
            0x30014000,
            0x80000002,
            0x50000000,
            0x3000c000,
            0x80000004,
            0x30018000,
            0x80000001,
            0x60000000,
            0x1000c000,
            0x3000c000,
            0x50000000,
            0x20010000,
            0x30010000,
            0x80000002,
            0x50000000,
            0x3001c000,
            0x80000001,
            0x30020000,
            0x80000005,
            0x20024000,
            0x30024000,
            0x30028000,
            0x8000000b,
            0x50000000,
            0x8003000d,
            0x60000000,
            0x8003800f,
            0x30040000,
            0x80000011,
            0x60000000,
            0x60000000,
            0x60000000,
            0
            					};
        return rgOps;
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    static RGSDWORD* GetOpcodeDWORDVals() 
    {
        static RGSDWORD rgDWORDS[] = 
            					{
            						{0, 0}
            					};
        return rgDWORDS;
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    static RGSBinary* GetOpcodeBinaryVals() 
    {

        static RGSBinary rgBinary[] = 
            					{
            						{0, 0}
            					};
        return rgBinary;
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    static RGSStrings* GetOpcodeStringVals() 
    {
        static RGSStrings rgStrings[] = 
            					{
            						{_T(""),0 }, 
            {_T("Bil_CryptX.ClientSign.1"),0 }, 
            {_T("%FriendlyName%"),1 }, 
            {_T("CLSID"),0 }, 
            {_T("{5CF632EC-49E4-4E24-B164-258A76A90284}"),0 }, 
            {_T("Bil_CryptX.ClientSign"),0 }, 
            {_T("CurVer"),0 }, 
            {_T("ProgID"),0 }, 
            {_T("VersionIndependentProgID"),0 }, 
            {_T("Programmable"),0 }, 
            {_T("%MODULETYPE%"),1 }, 
            {_T("%MODULE%"),1 }, 
            {_T("ThreadingModel"),0 }, 
            {_T("apartment"),0 }, 
            {_T("AppID"),0 }, 
            {_T("%APPID%"),1 }, 
            {_T("TypeLib"),0 }, 
            {_T("%MODULEGUID%"),1 }, 
            {NULL, 0}
            					};
        return rgStrings;
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    static HRESULT WINAPI UpdateRegistry(BOOL bRegister) 
    {
        CRegistryVirtualMachine rvm;
        HRESULT hr;
        if (FAILED(hr = rvm.AddStandardReplacements()))
            return hr;
        rvm.AddReplacement(_T("FriendlyName"), GetObjectFriendlyName());
        return rvm.VMUpdateRegistry(GetOpCodes(), GetOpcodeStringVals(), GetOpcodeDWORDVals(), GetOpcodeBinaryVals(), bRegister);
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    static const TCHAR* GetObjectFriendlyName() 
    {
        return _T("CClientSign Object");
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    static const TCHAR* GetProgID() 
    {
        return _T("Bil_CryptX.ClientSign.1");
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    static const TCHAR* GetVersionIndependentProgID() 
    {
        return _T("Bil_CryptX.ClientSign");
    }
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"
    BEGIN_COM_MAP(CClientSign)
        COM_INTERFACE_ENTRY(IClientSign)
        COM_INTERFACE_ENTRY(IDispatch)
        COM_INTERFACE_ENTRY(IObjectSafety)
        COM_INTERFACE_ENTRY(IProvideClassInfo)
        COM_INTERFACE_ENTRY(ISupportErrorInfo)
    END_COM_MAP()
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"

    STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid) 
        					
    {
        static const IID* rgErrorGuids[] = 
            						{
            							&__uuidof(IClientSign)
            						};
        for (int i=0; i < sizeof(rgErrorGuids) / sizeof(rgErrorGuids[0]); i++)
						{
            if (InlineIsEqualGUID(*rgErrorGuids[i],riid))
                return S_OK;
        }
        return S_FALSE;
    } 

	//--- End Injected Code For Attribute 'support_error_info'
};

//+++ Start Injected Code For Attribute 'support_error_info'
#injected_line 34 "c:\\bilaterali\\bil_cryptx\\clientsign.h"

				OBJECT_ENTRY_AUTO(__uuidof(CClientSign), CClientSign)
			
//--- End Injected Code For Attribute 'support_error_info'


