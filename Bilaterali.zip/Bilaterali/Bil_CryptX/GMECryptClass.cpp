//******************************************************************************
// Lazzarini Andrea: preso "liberamente" spunto da analogo codice gruppo Tacchella
//
//******************************************************************************
//---------------------------------------------------------------------------

#include "stdafx.h"


const char *COMMON_NAME_OID = "2.5.4.3=";
/*
Sostitutivi di malloc e free
*/
/*

void *MALLOC(int len) 
{ 
HGLOBAL hGlob;
hGlob = GlobalAlloc(GPTR,len); 
if (((hGlob) != NULL) && ((hGlob) != INVALID_HANDLE_VALUE))
return (void *)GlobalLock(hGlob);
else
return NULL;
}




void Free(void *d) 
{ 
HGLOBAL hGlob;
if (d!= NULL)
{
hGlob = GlobalHandle(d);
}
if (hGlob != NULL && hGlob != INVALID_HANDLE_VALUE)
{
GlobalUnlock(hGlob);
GlobalFree(hGlob); 
}
}
*/






//int strncmp(const char *string1, const char *string2, size_t n)
//{
//	return strncmp((char *)string1, (char *) string2, n);
//}


int strncmp(char *string1, const char *string2, size_t n)
{
	return strncmp(string1, (char *) string2, n);
}


//
// sostitutivo di strncmp (implementazione veramente de legno)
//
int strncmp(char *string1, char *string2, size_t n)
{
	//
	// stringhe nulle sono uguali
	if ((string1 == NULL) && (string2==NULL))
		return 1;

	if (string1 == NULL)
		return -1;

	if (string2 == NULL)
		return 1;

	char *p_string1 = (char *)string1;
	char *p_string2 = (char *)string2;

	size_t counter = 0;
	for ( ; (*p_string1)!=0 && (*p_string2)!=0 && counter < n; )  
	{
		if ((*p_string1) > (*p_string2))
			return 1;
		if ((*p_string1) < (*p_string2))
			return -1;
		p_string1++;
		p_string2++;
		counter++;
	}

	if (counter == n)
	{
		//
		// sono uguali
		//
		return 0;
	}
	else
	{
		if ((*p_string1)==0)
			return -1;
		if ((*p_string2)==0)
			return 1;
		return 0;
	}
}


CGMECryptClass::CGMECryptClass()
{

	AvailableCert = Malloc<CertItem>(MAX_CERT);
	ZeroMemory(AvailableCert, sizeof(CertItem) * MAX_CERT);
	AvailableCertCount= 0;
	CertIndex = 0;
	certChoosed = -1;


	hCryptProv=NULL;      // Handle for the cryptographic provider context.
	hCryptKey=NULL;       // Public/private key handle.
	hStoreHandle=NULL;    // Handle for the certificate store
	pCertContext=NULL;    // Pointer for the certificate context


	SignMessagePara;      // Struct for signature
	gvContextState=0;     
	gvFindCertState=0;
	gvHoldCertState=0;
	gvChooseCertState=0;
}

CGMECryptClass::~CGMECryptClass()
{

	if (AvailableCert != NULL)
	{
		Free(AvailableCert); 
		AvailableCert = NULL;
	}

	if(hStoreHandle)
	{
		CertCloseStore(hStoreHandle, CERT_CLOSE_STORE_CHECK_FLAG);
		hStoreHandle = NULL;
	}

	AvailableCertCount= 0;
	CertIndex = 0;
	certChoosed = -1;
	hCryptProv=NULL;      // Handle for the cryptographic provider context.
	hCryptKey=NULL;       // Public/private key handle.
	pCertContext=NULL;    // Pointer for the certificate context

	SignMessagePara;       // Struct for signature
	gvContextState=0;     
	gvFindCertState=0;
	gvHoldCertState=0;
	gvChooseCertState=0;
}




//------------------------------------------------------------------------------
//   int ChooseCertificate(void) --> int ChooseCertificate(char *InCertName)
//
//   Form to choose the sign certificate from the IE CSP.
//------------------------------------------------------------------------------
int CGMECryptClass::ChooseCertificate(char *certName)
{
	int i=0;

	// ottengo l'indice del certificato dal nome fornitomi (certName)
	for (i=0;i < AvailableCertCount;i++) {
		if (lstrcmp(AvailableCert[i].SubjectName,certName) == 0) {
			certChoosed = i;
			CertIndex = i;
			break;
		}
	}

	if (certChoosed == -1) {
		return (GME_CHOOSE_CERTIFICATE_ERROR);
	}

	return(GME_INTERNAL_OK);
}



//------------------------------------------------------------------------------
//   int ChooseCertificate(int) --> int ChooseCertificate(int index)
//
//   Selection of the certificate  among the available certificates using index
//------------------------------------------------------------------------------
int CGMECryptClass::ChooseCertificate(int index)
{
	if ((index<0) || (index>=AvailableCertCount))
		return (GME_CHOOSE_CERTIFICATE_ERROR);

	certChoosed = index;
	CertIndex = index;
	return(GME_INTERNAL_OK);
}


//------------------------------------------------------------------------------
//   int FindAvailableCertificate(void)
//
//   Finds the available signature certificates from the CertificateStorePersonal and fills
//   a temporary array.
//------------------------------------------------------------------------------
int CGMECryptClass::FindAvailableCertificate(bool bLocalMachine)
{
	int                 rc,i,k;
	int					j;
	DWORD               KeyProvInfoLen;
	CRYPT_KEY_PROV_INFO *KeyProvInfo=NULL;
	PCCERT_CONTEXT      pCertContextFind;
	char                SubjectNameBuff[MAX_CERT_SUBJECT_NAME+1];
	int counter = 0;
	//int size = 0;
	int kUsageExtFound = 0;
	int certificateForSign = 0;
	int keyUsage = 0;  
	DWORD cbDecoded;			// Variable to hold the length of the decoded buffer.
	BYTE *pbDecoded = NULL;		// Variable to hold a pointer to the decoded buffer.
	int resFind = GME_INTERNAL_OK;


	AvailableCertCount=0;
	ZeroMemory(AvailableCert,sizeof(CertItem) * MAX_CERT);


	if(hStoreHandle)
	{
		CertCloseStore(hStoreHandle, CERT_CLOSE_STORE_CHECK_FLAG);
		hStoreHandle = NULL;
	}

	// opens a certificate store
	if (bLocalMachine)
	{
		hStoreHandle = CertOpenStore(CERT_STORE_PROV_SYSTEM,
			MY_ENCODING_TYPE,
			0,
			CERT_SYSTEM_STORE_LOCAL_MACHINE,
			L"MY");
	}
	else
	{
		hStoreHandle = CertOpenStore(CERT_STORE_PROV_SYSTEM,
			MY_ENCODING_TYPE,
			0,
			CERT_SYSTEM_STORE_CURRENT_USER,
			L"MY");
	}


	if(!hStoreHandle)
	{
		rc=GetLastError();
		return(GME_CERT_OPEN_STORE_ERROR);
	}

	pCertContextFind=NULL;

	for (i=0;;i++)
	{
		// retrieves the first or next certificate
		pCertContextFind=CertEnumCertificatesInStore(hStoreHandle,
			pCertContextFind);
		if (pCertContextFind == NULL)
		{
			break;
		}

		if (AvailableCertCount == MAX_CERT)
		{
			resFind = GME_TOO_MANY_CERT_ERROR;
			break;
		}


		kUsageExtFound = 0;
		// faccio una scansione sulle estensioni del certificato per trovare il key usage
		for (counter=0; counter < (int)(pCertContextFind->pCertInfo->cExtension); counter++)
		{
			if (!lstrcmp(pCertContextFind->pCertInfo->rgExtension[counter].pszObjId, szOID_KEY_USAGE)) 
			{
				kUsageExtFound = 1;
				break;
			}
		}

		certificateForSign = 0;
		if (kUsageExtFound == 1) {
			//  Get the length needed for the decoded buffer.
			if (!(CryptDecodeObject(pCertContextFind->dwCertEncodingType,
				szOID_KEY_USAGE,
				pCertContextFind->pCertInfo->rgExtension[counter].Value.pbData,
				pCertContextFind->pCertInfo->rgExtension[counter].Value.cbData,
				0,
				NULL,
				&cbDecoded)))
			{
				resFind = GME_CERTIFICATE_EXTENSION_DECODE_ERROR;
				break;
			}

			// Allocate memory for the decoded information
			if(!(pbDecoded = Malloc<BYTE>(cbDecoded)))
			{
				resFind = GME_FILE_MALLOC_ERROR;
				break;
			}

			// Decode the encoded buffer.
			if(CryptDecodeObject(pCertContextFind->dwCertEncodingType,
				szOID_KEY_USAGE,
				pCertContextFind->pCertInfo->rgExtension[counter].Value.pbData,
				pCertContextFind->pCertInfo->rgExtension[counter].Value.cbData,
				0,
				pbDecoded,
				&cbDecoded))
			{
				if (((CRYPT_BIT_BLOB *)pbDecoded)->cbData != 1 )
				{
					if (pbDecoded) {
						Free(pbDecoded);
						pbDecoded = NULL;
					}
					resFind = GME_CERTIFICATE_EXTENSION_DECODE_ERROR;
					break;
				}

				keyUsage = ((CRYPT_BIT_BLOB *)pbDecoded)->pbData[0];  

				//	The digitalSignature bit is asserted when the subject public key
				//  is used with a digital signature mechanism to support security
				//  services. Digital signature mechanisms are often used for entity
				//   authentication and data origin authentication with integrity.
				if (((CRYPT_BIT_BLOB *)pbDecoded)->pbData[0] & CERT_DIGITAL_SIGNATURE_KEY_USAGE) 
				{
					certificateForSign = 1;
				}

				//  The nonRepudiation bit is asserted when the subject public key is
				//  used to verify digital signatures used to provide a non-repudiation
				//	service.  This service protects against the certificate subject
				//  falsely denying signing the data, excluding certificate or CRL
				//  signing. In the case of later conflict, a reliable third party may
				//  determine the authenticity of the signed data.
				if (((CRYPT_BIT_BLOB *)pbDecoded)->pbData[0] & CERT_NON_REPUDIATION_KEY_USAGE) {
					certificateForSign = 1;
				}

				//  The keyEncipherment bit is asserted when the subject public key is
				//  used for key transport.  For example, when an RSA key is to be
				//  used for key management, then this bit shall asserted.
				if (((CRYPT_BIT_BLOB *)pbDecoded)->pbData[0] & CERT_KEY_ENCIPHERMENT_KEY_USAGE) {
					//certificateForSign = 0;
				}

				//  The dataEncipherment bit is asserted when the subject public key
				//  is used for enciphering user data, other than cryptographic keys.
				if (((CRYPT_BIT_BLOB *)pbDecoded)->pbData[0] & CERT_DATA_ENCIPHERMENT_KEY_USAGE) {
					//certificateForSign = 0;
				}

				// The keyAgreement bit is asserted when the subject public key is
				// used for key agreement.  For example, when a Diffie-Hellman key is
				// to be used for key management, then this bit shall asserted.
				if (((CRYPT_BIT_BLOB *)pbDecoded)->pbData[0] & CERT_KEY_AGREEMENT_KEY_USAGE) {
					//certificateForSign = 0;
				}

				// The keyCertSign bit is asserted when the subject public key is
				// used for verifying a signature on certificates.  This bit may only
				// be asserted in CA certificates.  If the keyCertSign bit is
				// asserted, then the cA bit in the basic constraints extension (see
				// 4.2.1.10) MUST also be asserted. If the keyCertSign bit is not
				// asserted, then the cA bit in the basic constraints extension MUST
				// NOT be asserted.
				if (((CRYPT_BIT_BLOB *)pbDecoded)->pbData[0] & CERT_KEY_CERT_SIGN_KEY_USAGE) {
					//certificateForSign = 0;
				}

				// The cRLSign bit is asserted when the subject public key is used
				// for verifying a signature on revocation information (e.g., a CRL).
				if (((CRYPT_BIT_BLOB *)pbDecoded)->pbData[0] & CERT_OFFLINE_CRL_SIGN_KEY_USAGE) 
				{
					//certificateForSign = 0;
				}
			}
			else
			{
				resFind = GME_CERTIFICATE_EXTENSION_DECODE_ERROR;
				break;
			}
			if (pbDecoded) 
			{
				Free(pbDecoded);
				pbDecoded = NULL;
			}
		}
		KeyProvInfoLen=0;
		// retrieves the information contained in an extended property of a certificate context
		rc=CertGetCertificateContextProperty(pCertContextFind,
			CERT_KEY_PROV_INFO_PROP_ID,
			NULL,
			&KeyProvInfoLen);
		if(rc==CRYPT_ERROR)
		{
			continue;
		}

		KeyProvInfo = Malloc<CRYPT_KEY_PROV_INFO>(KeyProvInfoLen);
		if(KeyProvInfo==NULL)
		{
			resFind = GME_GET_CERT_PROP_MALLOC_ERROR;
			break;
		}

		// retrieves the information contained in an extended property of a certificate context
		rc=CertGetCertificateContextProperty(pCertContextFind,
			CERT_KEY_PROV_INFO_PROP_ID,
			KeyProvInfo,
			&KeyProvInfoLen);
		if(rc==CRYPT_ERROR)
		{
			resFind = GME_GET_CERT_PROP_II_ERROR;
			break;
		}
		/* 
		dwKeySpec : the specification of the private key to retrieve.
		the following dwKeySpec values are defined for the default provider.
		AT_KEYEXCHANGE Keys used to encrypt/decrypt session keys.
		AT_SIGNATURE Keys used to create and verify digital signatures.
		use AT_SIGNATURE for signing certificates
		*/
		// non ho trovato il key usage ma le chiavi sono comunque di firma

		if ((certificateForSign == 1) ||
			((KeyProvInfo->dwKeySpec==AT_SIGNATURE) && (kUsageExtFound == 0)))  
		{
			AvailableCert[AvailableCertCount].CertID=i;

			AvailableCert[AvailableCertCount].KeyUsage = keyUsage;

			//
			//
			// AvailableCert[AvailableCertCount].KeySpec = KeyProvInfo->dwKeySpec;
			AvailableCert[AvailableCertCount].KeySpec = AT_SIGNATURE;


			// maps a wide-character string to a new character string
			// the new character string is not necessarily from a multibyte character set
			rc=WideCharToMultiByte(CP_ACP,                                                      // ANSI code page
				0,                                                           // performance and mapping flags
				KeyProvInfo->pwszContainerName,                              // wide-character string
				-1,                                                          // number of chars in string
				AvailableCert[AvailableCertCount].KeyContainerName,          // buffer for new string
				sizeof(AvailableCert[AvailableCertCount].KeyContainerName),  // size of buffer
				NULL,    // default for unmappable chars
				NULL);   // set when default char used
			if(rc==0)
			{
				resFind = GME_MULTIBYTE_ERROR;
				break;
			}

			// maps a wide-character string to a new character string
			// the new character string is not necessarily from a multibyte character set
			rc=WideCharToMultiByte(CP_ACP,
				0,
				KeyProvInfo->pwszProvName,
				-1,
				AvailableCert[AvailableCertCount].CSPName,
				sizeof(AvailableCert[AvailableCertCount].CSPName),
				NULL,
				NULL);
			if(rc==0)
			{
				resFind = GME_MULTIBYTE_ERROR;
				break;
			}
			CopyMemory(AvailableCert[AvailableCertCount].SerialNumber,
				pCertContextFind->pCertInfo->SerialNumber.pbData,
				pCertContextFind->pCertInfo->SerialNumber.cbData);

			CopyMemory(AvailableCert[AvailableCertCount].Issuer,
				pCertContextFind->pCertInfo->Issuer.pbData,
				pCertContextFind->pCertInfo->Issuer.cbData);

			// converts the name in a CERT_NAME_BLOB to a NULL-terminated character string.
			CertNameToStr(
				X509_ASN_ENCODING,                      //the encoding type used
				&pCertContextFind->pCertInfo->Subject,  //pointer to the CERT_NAME_BLOB to be converted.
				CERT_OID_NAME_STR |                     //the desired returned string type.
				CERT_NAME_STR_CRLF_FLAG,
				SubjectNameBuff,                        //pointer to a buffer to receive the returned string.
				sizeof(SubjectNameBuff));               //size, in characters, allocated for the returned string.

			k=0;
			for (j=0; j<(lstrlen(SubjectNameBuff)+lstrlen(COMMON_NAME_OID)); j++)
			{
				if (!strncmp(&(SubjectNameBuff[j]),COMMON_NAME_OID,lstrlen(COMMON_NAME_OID)))
					break;
			}

			if(j < (lstrlen(SubjectNameBuff)+lstrlen(COMMON_NAME_OID)))
			{
				j=j+lstrlen(COMMON_NAME_OID);
				while(  ( j < lstrlen(SubjectNameBuff) )
					&& ( !((SubjectNameBuff[j]=='\r')&&(SubjectNameBuff[j+1]=='\n')) )
					&& ( !SubjectNameBuff[j]=='\0')  )
				{
					AvailableCert[AvailableCertCount].SubjectName[k]=SubjectNameBuff[j];
					k++;
					j++;
				}
				AvailableCert[AvailableCertCount].SubjectName[k]='\0';
			}

			// converts the name in a CERT_NAME_BLOB to a NULL-terminated character string.
			CertNameToStr(
				X509_ASN_ENCODING,
				&pCertContextFind->pCertInfo->Issuer,
				/*CERT_OID_NAME_STR |
				CERT_NAME_STR_CRLF_FLAG,
				*/
				CERT_X500_NAME_STR,
				SubjectNameBuff,
				sizeof(SubjectNameBuff));

			/*
			k=0;
			for(j=0;j<(lstrlen(SubjectNameBuff)+lstrlen(COMMON_NAME_OID));j++)
			{
			if (!strncmp(&(SubjectNameBuff[j]),COMMON_NAME_OID,lstrlen(COMMON_NAME_OID)))
			break;
			}

			if(j<(lstrlen(SubjectNameBuff)+lstrlen(COMMON_NAME_OID)))
			{
			j=j+lstrlen(COMMON_NAME_OID);
			while(  ( j < lstrlen(SubjectNameBuff) )
			&& ( !((SubjectNameBuff[j]=='\r')&&(SubjectNameBuff[j+1]=='\n')) )
			&& ( !SubjectNameBuff[j]=='\0')  )
			{
			AvailableCert[AvailableCertCount].IssuerName[k]=SubjectNameBuff[j];
			k++;
			j++;
			}
			AvailableCert[AvailableCertCount].IssuerName[k]='\0';
			}
			*/

			lstrcpy(AvailableCert[AvailableCertCount].IssuerName, SubjectNameBuff);

			AvailableCertCount++;
		}
		if(KeyProvInfo)
		{
			Free(KeyProvInfo);
			KeyProvInfo=NULL;
		}
	}
	if(KeyProvInfo)
	{
		Free(KeyProvInfo);
		KeyProvInfo=NULL;
	}
	if (pbDecoded) 
	{
		Free(pbDecoded);
		pbDecoded = NULL;
	}
	if(pCertContextFind)
	{
		CertFreeCertificateContext(pCertContextFind);
		pCertContextFind = NULL;
	}
	if (resFind != GME_INTERNAL_OK)
	{
		return resFind;
	}

	if(AvailableCertCount==0)
	{
		return(GME_NO_CERTIFICATE_ERROR);
	}

	return resFind;
}






//------------------------------------------------------------------------------
//   int OpenCSP(void) --> int OpenCSP(char *InPIN)
//
//
//------------------------------------------------------------------------------
//int OpenCSP(void)
int CGMECryptClass::OpenCSP(char *InPIN)
{
	int rc;
	int retOpenCSP = GME_INTERNAL_OK;
	bool bNotExit = false;
	char *CSPName = NULL;
	char *KeyContainerName = NULL;
	DWORD dwFlag = 0;

	CSPName = AvailableCert[CertIndex].CSPName;
	KeyContainerName = AvailableCert[CertIndex].KeyContainerName;
	dwFlag = 0;


	if(gvContextState==1)           
	{
		return(GME_INTERNAL_OK);
	}

	// is used to acquire a handle to a particular key container
	// within a particular cryptographic service provider (CSP).
	// This returned handle is used in calls to CryptoAPI
	// functions that use the selected CSP.

	rc=CryptAcquireContext(&hCryptProv,                             // Handle to the CSP
		KeyContainerName,   // Provider name
		CSPName,										// Provider name
		PROV_RSA_FULL,                               // Provider type
		dwFlag);                                        		// Flag values


	if(rc==CRYPT_ERROR)
	{
		rc=GetLastError();
		retOpenCSP = GME_CSP_ACQUIRE_ERROR;
	}


	do
	{
		if (retOpenCSP == GME_INTERNAL_OK)
		{
			//
			// Se il certificato selezionato e' per la firma ... 
			//
			if (AvailableCert[CertIndex].KeySpec == AT_SIGNATURE)
			{
				//
				// Se il certificato selezionato e' per la firma ... 
				// apre user key con AT_SIGNATURE
				//
				rc=CryptGetUserKey(hCryptProv,                 // Handle to the CSP
					AT_SIGNATURE,               // Key Type
					&hCryptKey);                // Handle to the Key

				//
				// se errore  apertura user key con AT_SIGNATURE
				// 
				if (rc == CRYPT_ERROR)
				{
					DWORD dwError;
					dwError = GetLastError();

					//
					// se errore di codice 0x8009000d e certificato per la firma, prova ad aprire con 
					// AT_KEYEXCHANGE (workaround per problemi con alcuni tipi di certificati)
					//
					if ((dwError == (DWORD)0x8009000d) && (AvailableCert[CertIndex].KeyUsage == KEY_USAGE_TO_SIGN))
					{ 
						rc=CryptGetUserKey(hCryptProv,                   // Handle to the CSP
							AT_KEYEXCHANGE,               // Key Type
							&hCryptKey);                // Handle to the Key

						//
						// se ancora errore ritorna, altrimenti prosegui (va tutto bene)
						//
						if(rc==CRYPT_ERROR)
						{
							retOpenCSP = GME_GET_USERKEY_ERROR;
							break;
						}
					}
					else
					{
						/*
						** in ogni altro caso di errore  su apertura UserKey con AT_SIGNATURE ritorna l'errore
						*/
						retOpenCSP = GME_GET_USERKEY_ERROR;
						break;
					}
				}
			}
			else
			{
				//
				// certificato selezionato per autenticazione
				//
				rc=CryptGetUserKey(hCryptProv,        // Handle to the CSP
					AT_KEYEXCHANGE,        // Key Type
					&hCryptKey);           // Handle to the Key

				if(rc==CRYPT_ERROR) 
				{
					retOpenCSP = GME_GET_USERKEY_ERROR;
					break;
				}

			}
		}
	} while (bNotExit);

	if (retOpenCSP == GME_INTERNAL_OK)
	{
		if ((InPIN!= NULL) && lstrlen(InPIN)>0)
		{
			unsigned char pinToSet[20];
			ZeroMemory(pinToSet,sizeof(pinToSet));
			lstrcpy((char *)pinToSet,InPIN);
			rc = CryptSetProvParam(hCryptProv, PP_SIGNATURE_PIN , pinToSet, 0);
			if(rc==CRYPT_ERROR) 
			{
				retOpenCSP = GME_GET_USERKEY_ERROR;
			}
		}
	}

	if (hCryptKey)
	{
		CryptDestroyKey(hCryptKey);
		hCryptKey  = NULL;
	}


	if (retOpenCSP == GME_INTERNAL_OK)
	{
		gvContextState=1;                   
	}

	return retOpenCSP;
}


//------------------------------------------------------------------------------
//   int HoldCertificate(void)
//
//
//------------------------------------------------------------------------------
int CGMECryptClass::HoldCertificate(void)
{
	int         i;

	pCertContext=NULL;

	for (i=0; ; i++)
	{
		// retrieves the first or next certificate
		pCertContext=CertEnumCertificatesInStore(hStoreHandle,
			pCertContext);
		if(pCertContext==NULL)
			break;
		if(!memcmp(AvailableCert[CertIndex].SerialNumber,
			pCertContext->pCertInfo->SerialNumber.pbData,
			pCertContext->pCertInfo->SerialNumber.cbData)
			&&
			!memcmp(AvailableCert[CertIndex].Issuer,
			pCertContext->pCertInfo->Issuer.pbData,
			pCertContext->pCertInfo->Issuer.cbData))

			return(GME_INTERNAL_OK);
	}  //end for

	return(GME_CERTIFICATE_INTERNAL_ERROR);
}


//------------------------------------------------------------------------------
//   int DoSign(char *InData, int InDataLen, char **OutData, int *OutDataLen)
//
//   Sign data from a buffer into a buffer.
//   input:
//              BYTE*   InData           buffer to sign
//              int     InDataLen        buffer to sign length
//   output:
//              BYTE**  OutData          buffer signed
//              int*    OutDataLen       buffer signed length
//------------------------------------------------------------------------------
int CGMECryptClass::DoSign(BYTE *InData, int InDataLen, BYTE **OutData, int *OutDataLen)
{
	int         rc;
	DWORD       OutDataLenSign=0;
	const BYTE *rgpbToBeSigned[1];
	DWORD       rgcbToBeSigned[1];


	// the CRYPT_SIGN_MESSAGE_PARA structure contains information
	//  for signing messages using a specified signing certificate context.
	ZeroMemory(&SignMessagePara, sizeof(CRYPT_SIGN_MESSAGE_PARA));
	SignMessagePara.cbSize = sizeof(CRYPT_SIGN_MESSAGE_PARA);
	SignMessagePara.HashAlgorithm.pszObjId = SIGN_ALGORITHM;
	SignMessagePara.pSigningCert = pCertContext;
	SignMessagePara.dwMsgEncodingType = MY_ENCODING_TYPE;
	SignMessagePara.cMsgCert = 1;
	SignMessagePara.rgpMsgCert = &pCertContext;

	rgcbToBeSigned[0] = InDataLen;
	rgpbToBeSigned[0] = (BYTE *)InData;


	/*  Per velocizzare la firma elimino una delle chiamate e firmo dentro un buffer temporaneo,
	successivamente copio la firma dentro l'output
	*/

	// creates a hash of the specified content, signs the hash,
	// and then encodes both the original message content and
	// the signed hash.

	rc=CryptSignMessage(&SignMessagePara,
		FALSE,            // undetached signature
		1,
		rgpbToBeSigned,
		rgcbToBeSigned,
		NULL,
		&OutDataLenSign);
	if(rc==CRYPT_ERROR)
	{
		rc=GetLastError();
		return(GME_SIGN_MESSAGE_I_ERROR);
	}

	*OutData = Malloc<BYTE>(OutDataLenSign);
	if(*OutData==NULL)
	{
		return(GME_SIGN_MESSAGE_MALLOC_ERROR);
	}
	rc=CryptSignMessage(&SignMessagePara,
		FALSE,
		1,
		rgpbToBeSigned,
		rgcbToBeSigned,
		(BYTE *)(*OutData),
		&OutDataLenSign);



	if(rc==CRYPT_ERROR)
	{
		rc=GetLastError();
		return(GME_SIGN_MESSAGE_II_ERROR);
	}

	*OutDataLen=OutDataLenSign;
	/* N.B. Il chiamante DEVE rilasciare le memoria per il buffer *OutData  */
	return(GME_INTERNAL_OK);
}


//------------------------------------------------------------------------------
//   int ReleaseAll(void)
//
//
//------------------------------------------------------------------------------
int CGMECryptClass::ReleaseAll(void)
{
	int rc;
	// Release the certificate context.
	if(pCertContext)
	{
		rc=CertFreeCertificateContext(pCertContext);
		if(rc==CRYPT_ERROR)
		{
			rc=GetLastError();
			return(GME_RELEASE_CERT_CTX_ERROR);
		}
		pCertContext = NULL;
	}



	//
	//  Close the certificate store.
	//  chiude lo store ma c'e' sicuramente on keystore aperto (viene chiuso solo in ultima istanza) 
	//  per cui probabilmente da' un errore ma e' da trattarsi come warning (CRYPT_E_PENDING_CLOSE, 0x8009200F)
	//  http://msdn.microsoft.com/library/default.asp?url=/library/en-us/security/security/certopenstore.asp
	//

	/*
	if(hStoreHandle)
	{
		rc=CertCloseStore(hStoreHandle, CERT_CLOSE_STORE_CHECK_FLAG);
		if(rc==CRYPT_ERROR)
		{
			rc=GetLastError();
		}
		hStoreHandle = NULL;
	}
	*/

	// Destroy the signature key handle.
	if(hCryptKey)
	{
		rc=CryptDestroyKey(hCryptKey);
		if(rc==CRYPT_ERROR)
		{
			rc=GetLastError();
			return(GME_DESTROY_KEY_ERROR);
		}
		hCryptKey = NULL;
	}
	// Release the provider handle.
	if(hCryptProv)
	{
		rc=CryptReleaseContext(hCryptProv, 0);
		if(rc==CRYPT_ERROR)
		{
			rc=GetLastError();
			return(GME_RELEASE_CRYPT_CTX_ERROR);
		}
		hCryptProv = NULL;
	}

	//
	// reset del context in modo che riesca a riaprire il 
	//
	gvContextState = 0;
	return(GME_INTERNAL_OK);
}



//------------------------------------------------------------------------------
//   int ReadInputFile(char *FileName, char **InData, int *InDataLen)
//
//   Reads data from a file into a buffer.
//   input:
//              char*   FileName        the file name to read
//   output:
//              char**  InData          the buffer read
//              int*    InDataLen       the buffer read length
//------------------------------------------------------------------------------
int CGMECryptClass::ReadInputFile(char *FileName, BYTE **InData, int *InDataLen)
{
	int     InDataLenRead=0;
	HANDLE  hFile = INVALID_HANDLE_VALUE;
	DWORD	dwFileSizeLow, dwFileSizeHigh, dwFileToRead;
	BOOL	result;


	*InDataLen=0;

	if(!lstrcmp(FileName,""))
	{
		return(GME_FILE_OPEN_ERROR);
	}


	hFile=CreateFile(FileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,NULL,NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return(GME_FILE_OPEN_ERROR);
	}

	dwFileSizeLow = GetFileSize(hFile, &dwFileSizeHigh);

	if (dwFileSizeLow == 0)
	{
		return(GME_EMPTY_FILE_ERROR);
	}


	*InData = Malloc<BYTE>(dwFileSizeLow);
	if	(*InData==NULL)
	{
		CloseHandle(hFile);
		return(GME_FILE_MALLOC_ERROR);
	}

	BYTE *ptRead = *InData;
	DWORD nToRead = dwFileSizeLow;

	for (;;)
	{
		result = ReadFile(hFile, ptRead, nToRead, &dwFileToRead, NULL);
		if (result != TRUE)
		{
			Free(*InData);
			*InData = NULL;
			CloseHandle(hFile);
			*InDataLen= 0;
			return(GME_FILE_READ_ERROR);
		}

		ptRead += dwFileToRead;
		nToRead -= dwFileToRead;

		if (nToRead == 0)
		{
			*InDataLen = dwFileSizeLow;
			CloseHandle(hFile);
			break;
		}
	}

	return(GME_INTERNAL_OK);
}



//------------------------------------------------------------------------------
//   int InternalSignFile(char *InCertName, char *FileName, char **OutData)
//
//   Input:
//     char *InCertName: Common Name del certificato selezionato
//     char *FileName : nome del file da firmare
//
//	 Output:
//	   char **OutData : buffer di caratteri (il chiamante DEVE liberare con Free) 
//						contenente contenente il BASE64 della firma	
//
//------------------------------------------------------------------------------

int CGMECryptClass::InternalSignFile(char *InCertName, char *FileName, char **OutData, int *OutDataLen)
{
	int     rc;
	BYTE   *InData=NULL;
	int     InDataLen,OutDataSignLen;
	BYTE   *OutDataSign;
	bool	bNotExit = false;

	*OutData=NULL;
	OutDataSign=NULL;
	OutDataSignLen=0;

	hCryptKey=NULL;
	hCryptProv=NULL;
	//hStoreHandle=NULL;
	pCertContext=NULL;


	// Lettura Input File
	rc=ReadInputFile(FileName,&InData,&InDataLen);
	if(rc!=GME_INTERNAL_OK)
	{
		return(rc);
	}


	// Ricerca Certificati disponibili
	//rc=FindAvailableCertificate();
	//if(rc!=GME_INTERNAL_OK)
	//{
	//	return(rc);
	//}

	do
	{
		// Scelta Certificato
		rc=ChooseCertificate(InCertName);
		if(rc!=GME_INTERNAL_OK)
		{
			break;
		}

		// Aperura CSP
		rc=OpenCSP();
		if(rc!=GME_INTERNAL_OK)
		{
			break;
		}

		// Lettura/Attivazione certificato
		rc=HoldCertificate();
		if(rc!=GME_INTERNAL_OK)
		{
			break;
		}

		// Firma
		rc=DoSign(InData,InDataLen,&OutDataSign,&OutDataSignLen);
		if(rc!=GME_INTERNAL_OK)
		{
			break;
		}


//		DWORD dwFlags = ATL_BASE64_FLAG_NOPAD | ATL_BASE64_FLAG_NOCRLF;
		DWORD dwFlags = ATL_BASE64_FLAG_NONE;

		int dwRequiredLen = Base64EncodeGetRequiredLength(OutDataSignLen, dwFlags);

		*OutData = Malloc<char>(dwRequiredLen + 1);
		if(*OutData==NULL)
		{
			rc = GME_BASE64_MALLOC_ERROR;
			break;
		}

		// Codifica MIME base64 (RFC 1341)
		*OutDataLen = dwRequiredLen;
		Base64Encode(OutDataSign,OutDataSignLen,*OutData, OutDataLen, dwFlags);

		(*OutData)[*OutDataLen] = 0;

		/* N.B. Il chiamante DEVE rilasciare le memoria per il buffer *OutData  */
	}
	while (bNotExit);


	if (OutDataSign)
	{
		Free(OutDataSign);
	}


	ReleaseAll();
	return(rc);
}


//------------------------------------------------------------------------------
//   int InternalSignFile(int index, char *FileName, char **OutData)
//
//   Input:
//     int index: indice dei certificati da selezionare
//     char *FileName : nome del file da firmare
//
//	 Output:
//	   char **OutData : buffer di caratteri (il chiamante DEVE liberare con Free) 
//						contenente contenente il BASE64 della firma	
//
//------------------------------------------------------------------------------

int CGMECryptClass::InternalSignFile(int index, char *FileName, char **OutData, int *OutDataLen)
{
	int     rc;
	BYTE   *InData=NULL;
	int     InDataLen,OutDataSignLen;
	BYTE   *OutDataSign;
	const bool	bNotExit = false;

	*OutData=NULL;
	OutDataSign=NULL;
	OutDataSignLen=0;

	hCryptKey=NULL;
	hCryptProv=NULL;
	//hStoreHandle=NULL;
	pCertContext=NULL;


	// Lettura Input File
	rc=ReadInputFile(FileName,&InData,&InDataLen);
	if(rc!=GME_INTERNAL_OK)
	{
		return(rc);
	}


	// Ricerca Certificati disponibili
	//rc=FindAvailableCertificate();
	//if(rc!=GME_INTERNAL_OK)
	//{
	//	return(rc);
	//}

	do
	{
		// Scelta Certificato
		rc=ChooseCertificate(index);
		if(rc!=GME_INTERNAL_OK)
		{
			break;
		}

		// Aperura CSP
		rc=OpenCSP();
		if(rc!=GME_INTERNAL_OK)
		{
			break;
		}

		// Lettura/Attivazione certificato
		rc=HoldCertificate();
		if(rc!=GME_INTERNAL_OK)
		{
			break;
		}

		// Firma
		rc=DoSign(InData,InDataLen,&OutDataSign,&OutDataSignLen);
		if(rc!=GME_INTERNAL_OK)
		{
			break;
		}


//		DWORD dwFlags = ATL_BASE64_FLAG_NOPAD | ATL_BASE64_FLAG_NOCRLF;
		DWORD dwFlags = ATL_BASE64_FLAG_NONE;

		int dwRequiredLen = Base64EncodeGetRequiredLength(OutDataSignLen, dwFlags);

		*OutData = Malloc<char>(dwRequiredLen + 1);
		if(*OutData==NULL)
		{
			rc = GME_BASE64_MALLOC_ERROR;
			break;
		}

		// Codifica MIME base64 (RFC 1341)
		*OutDataLen = dwRequiredLen;
		Base64Encode(OutDataSign,OutDataSignLen,*OutData, OutDataLen, dwFlags);

		(*OutData)[*OutDataLen] = 0;

		/* N.B. Il chiamante DEVE rilasciare le memoria per il buffer *OutData  */
	}
	while (bNotExit);


	if (OutDataSign)
	{
		Free(OutDataSign);
	}


	ReleaseAll();
	return(rc);
}




//------------------------------------------------------------------------------
//   int InternalSignBuffer(BYTE *InData, char *InCertName, char *InPIN, char **OutData)
//
//
//------------------------------------------------------------------------------
int CGMECryptClass::InternalSignBuffer(BYTE *InData, 
									   int InDataLen,
									   char *InCertName,
									   char **OutData,
									   int *OutDataLen)
{
	int     rc;
	int     OutDataSignLen;
	BYTE  *OutDataSign=NULL;
	bool  bNotExit = false;

	*OutData=NULL;
	OutDataSign=NULL;
	OutDataSignLen=0;

	rc=GME_INTERNAL_OK;

	if (InData==NULL)
	{
		return(GME_EMPTY_BUFFER_ERROR);
	}

	do
	{
		rc=ChooseCertificate(InCertName);
		if(rc!=GME_INTERNAL_OK)
		{
			break; 
		}

		// Aperura CSP
		rc=OpenCSP();
		if(rc!=GME_INTERNAL_OK)
		{
			break; 
		}

		rc=HoldCertificate();
		if(rc!=GME_INTERNAL_OK)
		{
			break; 
		}

		// Firma
		rc=DoSign(InData,InDataLen,&OutDataSign,&OutDataSignLen);
		if(rc!=GME_INTERNAL_OK)
		{
			break; 
		}


		// DWORD dwFlags = ATL_BASE64_FLAG_NOPAD | ATL_BASE64_FLAG_NOCRLF;
		DWORD dwFlags = ATL_BASE64_FLAG_NONE;

		int dwRequiredLen = Base64EncodeGetRequiredLength(OutDataSignLen, dwFlags);

		*OutData = Malloc<char>(dwRequiredLen + 1);
		if(*OutData==NULL)
		{
			rc = GME_BASE64_MALLOC_ERROR;
			break;
		}

		// Codifica MIME base64 (RFC 1341)
		*OutDataLen = dwRequiredLen;
		Base64Encode(OutDataSign,OutDataSignLen,*OutData, OutDataLen, dwFlags);

		(*OutData)[*OutDataLen] = 0;
		/* N.B. Il chiamante DEVE rilasciare le memoria per il buffer *OutData  */
	
	}
	while (bNotExit);

	// Rilascio risorse
	if (OutDataSign)
	{
		Free(OutDataSign);
		OutDataSign = NULL;
	}
	ReleaseAll();
	return(rc);
}

//------------------------------------------------------------------------------
//   int InternalSignBuffer(BYTE *InData, int index, char *InPIN, char **OutData)
//
//
//------------------------------------------------------------------------------
int CGMECryptClass::InternalSignBuffer(BYTE *InData, 
									   int InDataLen,
									   int index,
									   char **OutData,
									   int *OutDataLen)
{
	int     rc;
	int     OutDataSignLen;
	BYTE  *OutDataSign=NULL;
	bool  bNotExit = false;

	*OutData=NULL;
	OutDataSign=NULL;
	OutDataSignLen=0;

	rc=GME_INTERNAL_OK;

	if (InData==NULL)
	{
		return(GME_EMPTY_BUFFER_ERROR);
	}

	do
	{
		rc=ChooseCertificate(index);
		if(rc!=GME_INTERNAL_OK)
		{
			break; 
		}

		// Aperura CSP
		rc=OpenCSP();
		if(rc!=GME_INTERNAL_OK)
		{
			break; 
		}

		rc=HoldCertificate();
		if(rc!=GME_INTERNAL_OK)
		{
			break; 
		}

		// Firma
		rc=DoSign(InData,InDataLen,&OutDataSign,&OutDataSignLen);
		if(rc!=GME_INTERNAL_OK)
		{
			break; 
		}


		// DWORD dwFlags = ATL_BASE64_FLAG_NOPAD | ATL_BASE64_FLAG_NOCRLF;
		DWORD dwFlags = ATL_BASE64_FLAG_NONE;

		int dwRequiredLen = Base64EncodeGetRequiredLength(OutDataSignLen, dwFlags);

		*OutData = Malloc<char>(dwRequiredLen + 1);
		if(*OutData==NULL)
		{
			rc = GME_BASE64_MALLOC_ERROR;
			break;
		}

		// Codifica MIME base64 (RFC 1341)
		*OutDataLen = dwRequiredLen;
		Base64Encode(OutDataSign,OutDataSignLen,*OutData, OutDataLen, dwFlags);

		(*OutData)[*OutDataLen] = 0;
		/* N.B. Il chiamante DEVE rilasciare le memoria per il buffer *OutData  */
	
	}
	while (bNotExit);

	// Rilascio risorse
	if (OutDataSign)
	{
		Free(OutDataSign);
		OutDataSign = NULL;
	}
	ReleaseAll();
	return(rc);
}




//
// Questi metodi dovrebbe servire per la verifica della firma
// E' necessario specificare il nome del container e della 
//
CGMEVerifyCryptClass::CGMEVerifyCryptClass()
{
	m_UhCryptProv = NULL;
}

CGMEVerifyCryptClass::~CGMEVerifyCryptClass()
{
	if (m_UhCryptProv)
	{
		CryptReleaseContext(m_UhCryptProv, 0);
		m_UhCryptProv = NULL;
	}
}





//
// Genera Key Container
//
int CGMEVerifyCryptClass::GenerateKeyContainer(char *CSPName, char *KeyName, bool bMachineKeySet)
{
	int rc;
	HCRYPTKEY hKey = NULL;
	int retGenerateKeyContainer = GME_RC_OK;
	bool bNotExit =false;

	do
	{
		if (bMachineKeySet)
			rc=CryptAcquireContext(
			&m_UhCryptProv,         // Handle to the CSP
			KeyName,				// Container name
			CSPName,                // Provider name
			PROV_RSA_FULL,          // Provider type
			CRYPT_MACHINE_KEYSET);  // Flag values
		else
			rc=CryptAcquireContext(
			&m_UhCryptProv,         // Handle to the CSP
			KeyName,				// Container name
			CSPName,                // Provider name
			PROV_RSA_FULL,          // Provider type
			0);						// Flag values

		if (rc == CRYPT_ERROR)
		{
			rc=GetLastError();

			if (bMachineKeySet)
				rc=CryptAcquireContext(
				&m_UhCryptProv,
				KeyName,          // Container name
				CSPName,                   // Provider name
				PROV_RSA_FULL,             // Provider type
				CRYPT_MACHINE_KEYSET|CRYPT_NEWKEYSET);
			else
				rc=CryptAcquireContext(
				&m_UhCryptProv,
				KeyName,          // Container name
				CSPName,                   // Provider name
				PROV_RSA_FULL,             // Provider type
				CRYPT_NEWKEYSET);


			if(rc==CRYPT_ERROR)
			{
				rc=GetLastError();
				retGenerateKeyContainer = GME_RC_CRYPT_ACQUIRE_ERROR;
				break;
			}

			// 0x02000000      512 bit
			// 0x04000000     1024 bit
			// 0x08000000     2048 bit
			rc=CryptGenKey(m_UhCryptProv, AT_SIGNATURE, 0x04000000 | CRYPT_EXPORTABLE, &hKey);
			if(rc==CRYPT_ERROR)
			{
				rc=GetLastError();
				retGenerateKeyContainer = GME_RC_KEY_GENERATION_ERROR;
				break;
			}
			// BISOGNA DISTRUGGERE HANDLE DELLA CHIAVE ?
			//if(hKey)
			//     CryptDestroyKey(hKey);
		}
		else
			//
			// keycontainer gia' esistente
			//
			retGenerateKeyContainer = GME_RC_KEY_ALREADY_EXISTING;

	}
	while (bNotExit);


	// BISOGNA DISTRUGGERE HANDLE DELLA CHIAVE ? suppongo di si
	if (hKey)
	{
		CryptDestroyKey(hKey);
		hKey = NULL;
	}

	if(m_UhCryptProv)
	{
		CryptReleaseContext(m_UhCryptProv, 0);
		m_UhCryptProv = NULL;
	}
	return retGenerateKeyContainer;
}



//
// Distruggi Key Container
//
int CGMEVerifyCryptClass::DestroyKeyContainer(char *CSPName, char *KeyName, bool bMachineKeySet)
{
	int rc;
	int retDestroyKeyContainer = GME_RC_OK;
	bool bNotExit =false;

	if (bMachineKeySet)
		rc=CryptAcquireContext(
		&m_UhCryptProv,
		KeyName,          // Container name
		CSPName,                   // Provider name
		PROV_RSA_FULL,             // Provider type
		CRYPT_MACHINE_KEYSET|CRYPT_DELETEKEYSET);
	else
		rc=CryptAcquireContext(
		&m_UhCryptProv,
		KeyName,          // Container name
		CSPName,                   // Provider name
		PROV_RSA_FULL,             // Provider type
		CRYPT_DELETEKEYSET);

	if(rc==CRYPT_ERROR)
	{
		rc=GetLastError();
		retDestroyKeyContainer = GME_RC_KEY_REMOVE_ERROR;
	}
	if(m_UhCryptProv)
	{
		CryptReleaseContext(m_UhCryptProv, 0);
		m_UhCryptProv = NULL;
	}
	return retDestroyKeyContainer;
}


//
// Inizializza contesto crittografico
//
int CGMEVerifyCryptClass::Init(char *CSPName, char *KEYName, char *InPIN, bool bMachineKeySet)
{
	int rc;
	int retInit = GME_RC_OK;
	bool bNotExit =false;

	// is used to acquire a handle to a particular key container
	// within a particular cryptographic service provider (CSP).
	// This returned handle is used in calls to CryptoAPI
	// functions that use the selected CSP.

	if (bMachineKeySet)
		rc=CryptAcquireContext(
		&m_UhCryptProv,               // Handle to the CSP
		KEYName,           // Container name
		CSPName,                    // Provider name
		PROV_RSA_FULL,              // Provider type
		CRYPT_MACHINE_KEYSET);      // Flag values
	else
	{
		rc=CryptAcquireContext(
			&m_UhCryptProv,       // Handle to the CSP
			KEYName,				// Container name
			CSPName,              // Provider name
			PROV_RSA_FULL,        // Provider type
			0);					// Flag values


		//
		// Setta PIN eventuale
		//
		if (rc != CRYPT_ERROR)
		{
			unsigned char pinToSet[20];
			ZeroMemory(pinToSet,sizeof(pinToSet));
			lstrcpy((char *)pinToSet,InPIN);
			rc = CryptSetProvParam(m_UhCryptProv, PP_SIGNATURE_PIN , pinToSet, 0);
			if(rc==CRYPT_ERROR) 
			{
				retInit = GME_GET_USERKEY_ERROR;
			}
		}
	}
	if(rc==CRYPT_ERROR)
	{
		rc=GetLastError();
		retInit = GME_RC_CRYPT_ACQUIRE_ERROR;
	}
	return retInit;
}


//
// Carica il PKCS7
//
int CGMEVerifyCryptClass::PkcsLoad(HCRYPTMSG *hMsg, BYTE *PKCS7Data, int PKCS7DataLen)
{
	BOOL        brc;
	int         rc;

	*hMsg=CryptMsgOpenToDecode(
		MY_ENCODING_TYPE,      // Encoding type.
		0,                     // Flags.
		0,                     // Use the default message type.
		// The message type is listed in the message header.
		m_UhCryptProv,			 // Cryptographic provider. Use NULL
		// for the default provider.
		NULL,                  // Recipient information.
		NULL);                 // Stream information.
	if(*hMsg==NULL)
	{
		rc=GetLastError();
		return(GME_RC_MSG_OPEN_TO_DEC_ERROR);
	}

	brc=CryptMsgUpdate(
		*hMsg,                 // Handle to the message
		PKCS7Data,             // Pointer to the encoded BLOB
		PKCS7DataLen,          // Size of the encoded BLOB
		TRUE);                 // Last call
	if(brc==CRYPT_ERROR)
	{
		rc=GetLastError();
		if(*hMsg!=NULL)
		{
			CryptMsgClose(*hMsg);
			*hMsg=NULL;
		}
		return(GME_RC_MSG_UPDATE_ERROR);
	}
	return(GME_RC_OK);
}



// -----------------------------------------------------------------------------
//  GetCertificate(char *PKCS7Data, int PKCS7DataLen, char **Certificate, int *OutDataLen)
//
//  Retrievs content data from a pkcs7 buffer.
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
//  output
//             BYTE**  Certificate     certificate content data (da rilasciare)
//             int*    CertificateLen  certificate content data length
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::GetCertificate(BYTE *PKCS7Data, int PKCS7DataLen, 
										 BYTE **Certificate, int *CertificateLen, int index)
{
	BOOL        brc;
	int         rc;
	HCRYPTMSG   hMsg=NULL;
	bool		  bNotExit = false;
	int		  retGetCertificate = GME_RC_OK;

	rc=PkcsLoad(&hMsg, PKCS7Data, PKCS7DataLen);
	if(rc!=GME_RC_OK)
	{
		return(GME_RC_PKCSLOAD_ERROR);
	}

	do
	{
		*CertificateLen=0;
		brc=CryptMsgGetParam(
			hMsg,                     // Handle to the message
			CMSG_CERT_PARAM,          // Parameter type
			index,                    // Index
			NULL,
			(DWORD *)CertificateLen); // Size of the returned information.
		if(brc==FALSE)
		{
			rc=GetLastError();
			retGetCertificate = GME_RC_MESSAGE_GET_ERROR_I;
			break;
		}

		*Certificate=NULL;
		*Certificate=Malloc<BYTE>(*CertificateLen);
		if(*Certificate==NULL)
		{
			rc=GetLastError();
			retGetCertificate = GME_RC_INT_ALLOC_ERROR;
			break;
		}

		brc=CryptMsgGetParam(
			hMsg,                      // Handle to the message
			CMSG_CERT_PARAM,           // Parameter type
			0,                         // Index
			*Certificate,              // Address for returned information.
			(DWORD *)CertificateLen);  // Size of the returned information.
		if(brc==FALSE)
		{
			rc=GetLastError();
			retGetCertificate = GME_RC_MESSAGE_GET_ERROR_II;
			break;
		}
	}
	while (bNotExit);

	if (retGetCertificate != GME_RC_OK)
	{
		if (*Certificate!=NULL)
		{
			Free(*Certificate);
			*Certificate=NULL;
		}
	}
	if(hMsg)
	{
		CryptMsgClose(hMsg);
		hMsg = NULL;
	}

	return retGetCertificate;
}



// -----------------------------------------------------------------------------
//  GetCertificatesCount(char *PKCS7Data, int PKCS7DataLen, char **Certificate, int *OutDataLen)
//
//  Retrievs content data from a pkcs7 buffer.
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
//  output
//             DWORD*  count     numero di certificati che hanno firmato il messaggio
//
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::GetCertificatesCount(BYTE *PKCS7Data, int PKCS7DataLen, 
											   DWORD *count)
{
	BOOL        brc;
	int         rc;
	HCRYPTMSG   hMsg=NULL;
	bool		  bNotExit = false;
	int		  retGetCertificate = GME_RC_OK;
	DWORD		  CertificateLen = sizeof(DWORD);

	rc=PkcsLoad(&hMsg, PKCS7Data, PKCS7DataLen);
	if(rc!=GME_RC_OK)
	{
		return(GME_RC_PKCSLOAD_ERROR);
	}

	do
	{
		brc=CryptMsgGetParam(
			hMsg,                       // Handle to the message
			CMSG_CERT_COUNT_PARAM,      // Parameter type
			0,                          // Index
			count,
			(DWORD *)&CertificateLen); // Size of the returned information.
		if(brc==FALSE)
		{
			rc=GetLastError();
			retGetCertificate = GME_RC_MESSAGE_GET_ERROR_I;
			break;
		}
	}
	while (bNotExit);

	if(hMsg)
	{
		CryptMsgClose(hMsg);
		hMsg = NULL;
	}
	return retGetCertificate;
}



// -----------------------------------------------------------------------------
//  GetSignersCount(char *PKCS7Data, int PKCS7DataLen, char **Certificate, int *OutDataLen)
//
//  Retrievs content data from a pkcs7 buffer.
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
//  output
//             DWORD*  count     numero di certificati che hanno firmato il messaggio
//
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::GetSignersCount(BYTE *PKCS7Data, int PKCS7DataLen, 
										  DWORD *count)
{
	BOOL        brc;
	int         rc;
	HCRYPTMSG   hMsg=NULL;
	bool		  bNotExit = false;
	int		  retGetCertificate = GME_RC_OK;
	DWORD		  CertificateLen = sizeof(DWORD);

	rc=PkcsLoad(&hMsg, PKCS7Data, PKCS7DataLen);
	if(rc!=GME_RC_OK)
	{
		return(GME_RC_PKCSLOAD_ERROR);
	}

	do
	{
		brc=CryptMsgGetParam(
			hMsg,                       // Handle to the message
			CMSG_SIGNER_COUNT_PARAM,      // Parameter type
			0,                          // Index
			count,
			(DWORD *)&CertificateLen); // Size of the returned information.
		if(brc==FALSE)
		{
			rc=GetLastError();
			retGetCertificate = GME_RC_MESSAGE_GET_ERROR_I;
			break;
		}
	}
	while (bNotExit);

	if(hMsg)
	{
		CryptMsgClose(hMsg);
		hMsg = NULL;
	}
	return retGetCertificate;
}







// -----------------------------------------------------------------------------
//  GetData(char *PKCS7Data, int PKCS7DataLen, char **OutData, int *OutDataLen)
//
//  Retrievs content data from a pkcs7 buffer.
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
//  output
//              char**  OutData         content data
//              int*    OutDataLen      content data length
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::GetData(BYTE *PKCS7Data, int PKCS7DataLen, BYTE **OutData, int *OutDataLen)
{

	int           rc;
	BOOL          brc;
	HCRYPTMSG     hMsg=NULL;
	int			retGetData = GME_RC_OK;
	bool		  bNotExit = false;


	rc=PkcsLoad(&hMsg, PKCS7Data, PKCS7DataLen);
	if(rc!=CRYPT_ERROR)
	{
		return(GME_RC_PKCSLOAD_ERROR);
	}

	do
	{
		*OutDataLen=0;
		brc=CryptMsgGetParam(
			hMsg,                  // Handle to the message
			CMSG_CONTENT_PARAM,    // Parameter type
			0,                     // Index
			NULL,
			(DWORD *)OutDataLen);  // Size of the returned information.
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retGetData = GME_RC_MESSAGE_GET_ERROR_I;
			break;
		}

		*OutData=NULL;
		*OutData=Malloc<BYTE>(*OutDataLen);
		if(*OutData==NULL)
		{
			rc=GetLastError();
			retGetData = GME_RC_INT_ALLOC_ERROR;
			break;
		}

		brc=CryptMsgGetParam(
			hMsg,                 // Handle to the message
			CMSG_CONTENT_PARAM,   // Parameter type
			0,                    // Index
			*OutData,             // Address for returned information.
			(DWORD *)OutDataLen); // Size of the returned information.
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retGetData = GME_RC_MESSAGE_GET_ERROR_II;
			break;
		}
	}
	while (bNotExit);

	if (retGetData != GME_RC_OK)
	{
		if (*OutData!=NULL)
		{
			Free(*OutData);
			*OutData=NULL;
		}
	}
	if(hMsg)
	{
		CryptMsgClose(hMsg);
		hMsg = NULL;
	}
	return retGetData;
}

// -----------------------------------------------------------------------------
//  GetSigningTime(char *PKCS7Data, int PKCS7DataLen, char *SigningTime)
//
//  Estrae il tempo di ControFirma come SYSTEMTIME + Bias
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
//  output
//              SYSTEMTIME  *stSigningTime      signing time
//				LONG		*Bias				bias
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::GetSigningTime(BYTE *PKCS7Data, int PKCS7DataLen, 
										 SYSTEMTIME   *stSigningTime,
										 LONG *Bias)
{
	int                 rc,ret;
	BOOL                brc;
	DWORD               i;
	BOOL                flag;
	HCRYPTMSG           hMsg=NULL;
	PCRYPT_ATTRIBUTES   EncSignTime;
	DWORD               EncSignTimeLen;
	FILETIME            FileTime,FileTimeLoc,FileTimeBias;
	DWORD               cbft;
	TIME_ZONE_INFORMATION        TimeZoneInformation;
	SYSTEMTIME          stActTime;
	ULARGE_INTEGER      UlFileTime, UlFileTimeLoc, UlFileTimeBias;
	__int64             i64UlFileTime, i64UlFileTimeLoc, i64UlFileTimeBias;
	int		retGetSigningTime = GME_RC_OK;
	bool		bNotExit = false;




	rc=PkcsLoad(&hMsg, PKCS7Data, PKCS7DataLen);
	if(rc!=CRYPT_ERROR)
	{
		return(GME_RC_PKCSLOAD_ERROR);
	}

	do
	{
		EncSignTimeLen=0;

		brc=CryptMsgGetParam(
			hMsg,                        // Handle to the message
			CMSG_SIGNER_AUTH_ATTR_PARAM, // Parameter type
			0,                           // Index
			NULL,
			&EncSignTimeLen);            // Size of the returned information.
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retGetSigningTime = GME_RC_MESSAGE_GET_ERROR_I;
			break;
		}

		EncSignTime=NULL;
		EncSignTime=Malloc<CRYPT_ATTRIBUTES>(EncSignTimeLen);
		if(EncSignTime==NULL)
		{
			rc=GetLastError();
			retGetSigningTime = GME_RC_MESSAGE_GET_ERROR_I;
			break;
		}

		brc=CryptMsgGetParam(
			hMsg,                        // Handle to the message
			CMSG_SIGNER_AUTH_ATTR_PARAM, // Parameter type
			0,                           // Index
			EncSignTime,                 // Address for returned information.
			&EncSignTimeLen);            // Size of the returned information.
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retGetSigningTime = GME_RC_MESSAGE_GET_ERROR_II;
			break;
		}

		for (i=0; i<EncSignTime->cAttr; i++)
		{
			if (lstrcmp(EncSignTime->rgAttr[i].pszObjId,szOID_RSA_signingTime) == 0)
			{
				cbft=sizeof(FILETIME);

				// decodes a structure of the type indicated by the lpszStructType parameter.
				brc=CryptDecodeObject(MY_ENCODING_TYPE,
					szOID_RSA_signingTime,
					EncSignTime->rgAttr[i].rgValue->pbData,
					EncSignTime->rgAttr[i].rgValue->cbData,
					0,
					(LPVOID)&FileTimeLoc,
					&cbft);
				if(brc==CRYPT_ERROR)
				{
					rc=GetLastError();
					retGetSigningTime = GME_RC_DECODE_ERROR;
				}
				break;
			}
		}

		//
		// propaga eventuale errore al blocco superiore
		//
		if (retGetSigningTime != GME_RC_OK)
			break;

		ret=GetTimeZoneInformation(&TimeZoneInformation);

		if (ret==TIME_ZONE_ID_STANDARD)
			*Bias=-(TimeZoneInformation.Bias+TimeZoneInformation.StandardBias)/60;
		else if (ret==TIME_ZONE_ID_DAYLIGHT)
			*Bias=-(TimeZoneInformation.Bias+TimeZoneInformation.DaylightBias)/60;
		else if (ret==TIME_ZONE_ID_INVALID)
		{
			retGetSigningTime = GME_RC_INTERNAL_ERROR;
			break;
		}

		//memset(&stActTime,0,sizeof(SYSTEMTIME));
		ZeroMemory(&stActTime, sizeof(SYSTEMTIME));

		stActTime.wMonth=1;
		stActTime.wDay=1;
		stActTime.wYear=1601;
		stActTime.wHour=(WORD)(*Bias);
		stActTime.wMinute=0L;
		stActTime.wSecond=0;
		stActTime.wDayOfWeek=0;
		stActTime.wMilliseconds=0;
		SystemTimeToFileTime(&stActTime, &FileTimeBias);

		UlFileTimeLoc.HighPart=FileTimeLoc.dwHighDateTime;
		UlFileTimeLoc.LowPart=FileTimeLoc.dwLowDateTime;

		UlFileTimeBias.HighPart=FileTimeBias.dwHighDateTime;
		UlFileTimeBias.LowPart=FileTimeBias.dwLowDateTime;

		i64UlFileTimeLoc    = *(__int64 *)&UlFileTimeLoc;
		i64UlFileTimeBias   = *(__int64 *)&UlFileTimeBias;

		if (*Bias>=0)
			i64UlFileTime=i64UlFileTimeLoc+i64UlFileTimeBias;
		else
			i64UlFileTime=i64UlFileTimeLoc-i64UlFileTimeBias;

		UlFileTime=*(ULARGE_INTEGER *)&i64UlFileTime;

		FileTime.dwHighDateTime=UlFileTime.HighPart;
		FileTime.dwLowDateTime=UlFileTime.LowPart;

		flag=FileTimeToSystemTime(&FileTime, stSigningTime);
		if(flag==FALSE)
		{
			rc=GetLastError();
		}
	}
	while (bNotExit);

	if(hMsg)
	{
		CryptMsgClose(hMsg);
		hMsg = NULL;
	}
	if(EncSignTime)
	{
		Free(EncSignTime);
		EncSignTime = NULL;	
	}

	return retGetSigningTime;
}




// -----------------------------------------------------------------------------
//  GetSigningTimeCoSign(char *PKCS7Data, int PKCS7DataLen, char *SigningTime)
//
//  Estrae il tempo di ControFirma come SYSTEMTIME + Bias
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
//  output
//              SYSTEMTIME  *stSigningTime      signing time
//				LONG		*Bias				bias
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::GetSigningTimeCoSign(BYTE *PKCS7Data, int PKCS7DataLen, 
											   SYSTEMTIME   *stSigningTime,
											   LONG *Bias)
{
	int                 rc,ret;
	BOOL                brc;
	DWORD               i;
	BOOL                flag;
	HCRYPTMSG           hMsg=NULL;
	FILETIME            FileTime,FileTimeLoc,FileTimeBias;
	DWORD               cbft;
	TIME_ZONE_INFORMATION        TimeZoneInformation;
	SYSTEMTIME          stActTime;
	ULARGE_INTEGER      UlFileTime, UlFileTimeLoc, UlFileTimeBias;
	__int64             i64UlFileTime, i64UlFileTimeLoc, i64UlFileTimeBias;
	int		retGetSigningTime = GME_RC_OK;
	bool		bNotExit = false;

	CRYPT_ATTRIBUTES		*pCountersignerInfo = NULL;
	DWORD					cbCountersignerInfo = 0;
	CMSG_CMS_SIGNER_INFO  *pSignerInfo = NULL;
	DWORD					cbSignerInfo;


	rc=PkcsLoad(&hMsg, PKCS7Data, PKCS7DataLen);
	if(rc!=CRYPT_ERROR)
	{
		return(GME_RC_PKCSLOAD_ERROR);
	}

	do
	{
		brc = CryptMsgGetParam(
			hMsg,                          // Handle to the message
			CMSG_SIGNER_UNAUTH_ATTR_PARAM, // Parameter type
			0,                       // Index
			NULL,                          // Address for returned 
			// information
			&cbCountersignerInfo);         // Size of returned 
		// information
		if (brc == FALSE)
		{
			retGetSigningTime = GME_RC_DECODE64_ERROR;
			break;
		}

		//--------------------------------------------------------------------
		// Allocate memory.
		pCountersignerInfo = Malloc<CRYPT_ATTRIBUTES>(cbCountersignerInfo);

		if (pCountersignerInfo == NULL)
		{
			retGetSigningTime = GME_RC_DECODE64_ERROR;
			break;
		}


		//--------------------------------------------------------------------
		// Get the message counter signer info.
		brc = CryptMsgGetParam(
			hMsg,                           // Handle to the message
			CMSG_SIGNER_UNAUTH_ATTR_PARAM,  // Parameter type
			0,                              // Index
			pCountersignerInfo,             // Address for returned 
			// information
			&cbCountersignerInfo);         // Size of the returned 
		// information
		if (brc == FALSE)
		{
			retGetSigningTime = GME_RC_DECODE64_ERROR;
			break;
		}



		brc = CryptDecodeObject(MY_ENCODING_TYPE,
			CMS_SIGNER_INFO,
			pCountersignerInfo->rgAttr->rgValue->pbData,
			pCountersignerInfo->rgAttr->rgValue->cbData,
			0,
			NULL,
			&cbSignerInfo);

		if (brc == FALSE)
		{
			retGetSigningTime = GME_RC_DECODE64_ERROR;
			break;
		}

		pSignerInfo = Malloc<CMSG_CMS_SIGNER_INFO>(cbSignerInfo);
		if (pSignerInfo == NULL)
		{
			retGetSigningTime = GME_RC_DECODE64_ERROR;
			break;
		}


		brc = CryptDecodeObject(MY_ENCODING_TYPE,
			CMS_SIGNER_INFO,
			pCountersignerInfo->rgAttr->rgValue->pbData,
			pCountersignerInfo->rgAttr->rgValue->cbData,
			0,
			pSignerInfo,
			&cbSignerInfo);

		if (brc == FALSE)
		{
			retGetSigningTime = GME_RC_DECODE64_ERROR;
			break;
		}

		for (i=0; i<pSignerInfo->AuthAttrs.cAttr; i++)
		{
			if (lstrcmp(pSignerInfo->AuthAttrs.rgAttr[i].pszObjId,szOID_RSA_signingTime) == 0)
			{
				cbft=sizeof(FILETIME);

				// decodes a structure of the type indicated by the lpszStructType parameter.
				brc=CryptDecodeObject(MY_ENCODING_TYPE,
					szOID_RSA_signingTime,
					pSignerInfo->AuthAttrs.rgAttr[i].rgValue->pbData,
					pSignerInfo->AuthAttrs.rgAttr[i].rgValue->cbData,
					0,
					(LPVOID)&FileTimeLoc,
					&cbft);
				if(brc==CRYPT_ERROR)
				{
					rc=GetLastError();
					retGetSigningTime = GME_RC_DECODE_ERROR;
				}
				break;
			}
		}

		//
		// propaga eventuale errore al blocco superiore
		//
		if (retGetSigningTime != GME_RC_OK)
			break;

		ret=GetTimeZoneInformation(&TimeZoneInformation);

		if (ret==TIME_ZONE_ID_STANDARD)
			*Bias=-(TimeZoneInformation.Bias+TimeZoneInformation.StandardBias)/60;
		else if (ret==TIME_ZONE_ID_DAYLIGHT)
			*Bias=-(TimeZoneInformation.Bias+TimeZoneInformation.DaylightBias)/60;
		else if (ret==TIME_ZONE_ID_INVALID)
		{
			retGetSigningTime = GME_RC_INTERNAL_ERROR;
			break;
		}

		//memset(&stActTime,0,sizeof(SYSTEMTIME));
		ZeroMemory(&stActTime, sizeof(SYSTEMTIME));

		stActTime.wMonth=1;
		stActTime.wDay=1;
		stActTime.wYear=1601;
		stActTime.wHour=(WORD)(*Bias);
		stActTime.wMinute=0L;
		stActTime.wSecond=0;
		stActTime.wDayOfWeek=0;
		stActTime.wMilliseconds=0;
		SystemTimeToFileTime(&stActTime, &FileTimeBias);

		UlFileTimeLoc.HighPart=FileTimeLoc.dwHighDateTime;
		UlFileTimeLoc.LowPart=FileTimeLoc.dwLowDateTime;

		UlFileTimeBias.HighPart=FileTimeBias.dwHighDateTime;
		UlFileTimeBias.LowPart=FileTimeBias.dwLowDateTime;

		i64UlFileTimeLoc    = *(__int64 *)&UlFileTimeLoc;
		i64UlFileTimeBias   = *(__int64 *)&UlFileTimeBias;

		if (*Bias>=0)
			i64UlFileTime=i64UlFileTimeLoc+i64UlFileTimeBias;
		else
			i64UlFileTime=i64UlFileTimeLoc-i64UlFileTimeBias;

		UlFileTime=*(ULARGE_INTEGER *)&i64UlFileTime;

		FileTime.dwHighDateTime=UlFileTime.HighPart;
		FileTime.dwLowDateTime=UlFileTime.LowPart;

		flag=FileTimeToSystemTime(&FileTime, stSigningTime);
		if(flag==FALSE)
		{
			rc=GetLastError();
		}
	}
	while (bNotExit);

	if(hMsg)
	{
		CryptMsgClose(hMsg);
		hMsg = NULL;
	}
	if (pCountersignerInfo)
	{
		Free(pCountersignerInfo);
		pCountersignerInfo = NULL;
	}

	if (pSignerInfo)
	{
		Free(pSignerInfo);
		pSignerInfo = NULL;
	}


	return retGetSigningTime;
}




// -----------------------------------------------------------------------------
//  GetTime(char **ActTime)
//
//  Ottiene il tempo attuale in formato SYSTEMTIME con Bias
//  output
//              SYSTEMTIME*  stActTime      Actual time
//				LONG*		 Bias			Bias
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::GetTime(SYSTEMTIME *stActTime, LONG *Bias)
{
	DWORD                  ret;
	TIME_ZONE_INFORMATION  TimeZoneInformation;
	GetLocalTime(stActTime);
	ret=GetTimeZoneInformation(&TimeZoneInformation);

	if (ret==TIME_ZONE_ID_STANDARD)
		*Bias=-(TimeZoneInformation.Bias+TimeZoneInformation.StandardBias)/60;
	else if (ret==TIME_ZONE_ID_DAYLIGHT)
		*Bias=-(TimeZoneInformation.Bias+TimeZoneInformation.DaylightBias)/60;
	else if (ret==TIME_ZONE_ID_INVALID)
		return(GME_RC_INTERNAL_ERROR);
	return(GME_RC_OK);
}




// -----------------------------------------------------------------------------
//  CoSign(BYTE *InData, int InDataLen,
//			char *CertParamType, void *CertParam, int CertParamLen,
//			char *ActTime, BYTE	**PKCS7Data, int *PKCS7DataLen)
//
//  Effettua la co-firma di un buffer di input con un certo certificato di co-firma
//  e applicando un certo timestamp\
//
//  input
//              BYTE*  InData			Buffer da Co-Firmare
//              int    InDataLen		Lunghezza del Buffer da Co-Firmare
//				char   *CertParam		file contenente il certificato 
//				SYSTEMTIME stActTime	timestamp locale (GetLocalTime)
//				LONG Bias				Bias rispetto a Daylight ... (GetTimeZoneInformation)
//
//  output
//              BYTE	**PKCS7Data		
//				int		*PKCS7DataLen
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::CoSignFromFile(BYTE *InData, int InDataLen,
										 char *CertParam,
										 SYSTEMTIME stActTime, LONG Bias,
										 BYTE	**PKCS7Data, int *PKCS7DataLen)
{
	int                  rc,CertFound=0;
	unsigned int         i = 0;
	BOOL                 brc;
	HCERTSTORE           hCertStore=NULL;
	PCCERT_CONTEXT       pCertContext=NULL;
	CERT_KEY_CONTEXT     CertKeyCTx;
	PCERT_KEY_CONTEXT    pCertKeyCTx;
	CRYPT_SIGN_MESSAGE_PARA   SignMessagePara;
	FILETIME             FileTime,FileTimeLoc,FileTimeBias;
	LPBYTE               pbAuth=NULL;
	DWORD                cbAuth=0;
	CRYPT_ATTR_BLOB      cablob[1];
	CRYPT_ATTRIBUTE      ca[1];
	const BYTE           *rgpbToBeSigned[1];
	DWORD                rgcbToBeSigned[1];
	ULARGE_INTEGER       UlFileTime, UlFileTimeLoc, UlFileTimeBias;
	__int64              i64UlFileTime, i64UlFileTimeLoc, i64UlFileTimeBias;
	int				retCoSignFromFile = GME_RC_OK;
	bool				bNotExit = false;

	// opens a certificate store using a specified store provider type
	hCertStore=CertOpenStore(CERT_STORE_PROV_FILENAME_A,
		MY_ENCODING_TYPE,
		NULL,
		CERT_STORE_READONLY_FLAG,      //any attempt to change the contents of the store results in an error
		(char *)CertParam);
	if(hCertStore==NULL)
	{
		rc=GetLastError();
		retCoSignFromFile = GME_RC_CERT_FILE_OPEN_ERROR;
	}

	if (retCoSignFromFile == GME_RC_OK) 
	{
		// retrieves the first or next certificate in a certificate store
		pCertContext=CertEnumCertificatesInStore(hCertStore, pCertContext);
		if(pCertContext==NULL)
		{
			rc=GetLastError();
			retCoSignFromFile = GME_RC_CERT_ENUM_ERROR;
		}
		else
			CertFound=1;

		if (CertFound==0)
		{
			retCoSignFromFile = GME_RC_CERT_NOT_FOUND_ERROR;
		}
	}

	//
	//
	if (retCoSignFromFile == GME_RC_OK) 
	{
		CertKeyCTx.cbSize=sizeof(CERT_KEY_CONTEXT);
		CertKeyCTx.hCryptProv=m_UhCryptProv;
		CertKeyCTx.dwKeySpec=AT_SIGNATURE;
		pCertKeyCTx=&CertKeyCTx;

		brc=CertSetCertificateContextProperty(pCertContext,
			CERT_KEY_CONTEXT_PROP_ID,
			0,
			pCertKeyCTx);
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retCoSignFromFile =GME_RC_SET_CERT_PROP_ERROR;
		}
	}

	//
	if (retCoSignFromFile == GME_RC_OK) 
	{
		SystemTimeToFileTime(&stActTime, &FileTimeLoc);
		FillMemory(&stActTime, sizeof(SYSTEMTIME), 0);

		stActTime.wMonth=1;
		stActTime.wDay=1;
		stActTime.wYear=1601;
		stActTime.wHour=(WORD)Bias;
		stActTime.wMinute=0;
		stActTime.wSecond=0;
		stActTime.wDayOfWeek=0;
		stActTime.wMilliseconds=0;
		SystemTimeToFileTime(&stActTime, &FileTimeBias);
		UlFileTimeLoc.HighPart=FileTimeLoc.dwHighDateTime;
		UlFileTimeLoc.LowPart=FileTimeLoc.dwLowDateTime;
		UlFileTimeBias.HighPart=FileTimeBias.dwHighDateTime;
		UlFileTimeBias.LowPart=FileTimeBias.dwLowDateTime;

		i64UlFileTimeLoc    = *(__int64 *)&UlFileTimeLoc;
		i64UlFileTimeBias   = *(__int64 *)&UlFileTimeBias;

		if (Bias>=0)
			i64UlFileTime=i64UlFileTimeLoc-i64UlFileTimeBias;
		else 
			i64UlFileTime=i64UlFileTimeLoc+i64UlFileTimeBias;
		UlFileTime=*(ULARGE_INTEGER *)&i64UlFileTime;
		FileTime.dwHighDateTime=UlFileTime.HighPart;
		FileTime.dwLowDateTime=UlFileTime.LowPart;

		brc=CryptEncodeObject(
			MY_ENCODING_TYPE,
			szOID_RSA_signingTime,
			(LPVOID)&FileTime,
			NULL,
			&cbAuth);

		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retCoSignFromFile = GME_RC_ENCODE_I_ERROR;
		}
	}

	if (retCoSignFromFile == GME_RC_OK) 
	{
		pbAuth = Malloc<BYTE>(cbAuth);
		if(pbAuth==NULL)
		{
			rc=GetLastError();
			retCoSignFromFile = GME_RC_INT_ALLOC_ERROR;
		}
	}

	if (retCoSignFromFile == GME_RC_OK) 
	{
		do
		{
			brc=CryptEncodeObject(
				MY_ENCODING_TYPE,
				szOID_RSA_signingTime,
				(LPVOID)&FileTime,
				pbAuth,
				&cbAuth);
			if(brc==CRYPT_ERROR)
			{
				rc=GetLastError();
				retCoSignFromFile = GME_RC_ENCODE_II_ERROR;
				break;
			}

			cablob[0].cbData = cbAuth;
			cablob[0].pbData = pbAuth;
			ca[0].pszObjId = szOID_RSA_signingTime;
			ca[0].cValue = 1;
			ca[0].rgValue = cablob;

			ZeroMemory(&SignMessagePara, sizeof(CRYPT_SIGN_MESSAGE_PARA));
			SignMessagePara.cbSize = sizeof(CRYPT_SIGN_MESSAGE_PARA);
			SignMessagePara.HashAlgorithm.pszObjId = SIGN_ALGORITHM;
			SignMessagePara.pSigningCert = pCertContext;
			SignMessagePara.dwMsgEncodingType = MY_ENCODING_TYPE;
			SignMessagePara.cMsgCert = 1;
			SignMessagePara.rgpMsgCert = &pCertContext;

			SignMessagePara.cAuthAttr = 1;
			SignMessagePara.rgAuthAttr = ca;

			rgpbToBeSigned[0] = InData;
			rgcbToBeSigned[0] = InDataLen;

			brc=CryptSignMessage(
				&SignMessagePara,
				FALSE,
				1,
				rgpbToBeSigned,
				rgcbToBeSigned,
				NULL,
				(DWORD*)PKCS7DataLen);
			if(brc==CRYPT_ERROR)
			{
				rc=GetLastError();
				retCoSignFromFile = GME_RC_SIGN_MESSAGE_I_ERROR;
				break;
			}

			*PKCS7Data = Malloc<BYTE>(*PKCS7DataLen);
			if(*PKCS7Data==NULL)
			{
				rc=GetLastError();
				*PKCS7DataLen=0;
				retCoSignFromFile = GME_RC_INT_ALLOC_ERROR;
				break;
			}
			brc=CryptSignMessage(
				&SignMessagePara,
				FALSE,
				1,
				rgpbToBeSigned,
				rgcbToBeSigned,
				*PKCS7Data,
				(DWORD*)PKCS7DataLen);
			if(brc==CRYPT_ERROR)
			{
				*PKCS7DataLen=0;
				rc=GetLastError();
				retCoSignFromFile = GME_RC_SIGN_MESSAGE_II_ERROR;
				break;
			}
		}
		while (bNotExit);
	}

	if (retCoSignFromFile == GME_RC_OK)
	{
		if(*PKCS7Data)
		{
			Free(*PKCS7Data);
			*PKCS7Data = NULL;
		}
	}
	if(pCertContext)
	{
		CertFreeCertificateContext(pCertContext);
	}

	if (hCertStore)
	{
		rc=CertCloseStore(hCertStore, CERT_CLOSE_STORE_CHECK_FLAG);
		hCertStore = NULL;
	}
	if(pbAuth)
	{
		Free(pbAuth);
		pbAuth = NULL;
	}
	return  retCoSignFromFile;
}





// -----------------------------------------------------------------------------
//  CoSignFromStoreOverSign(BYTE *InData, int InDataLen,
//			char *CertParamType, void *CertParam, int CertParamLen,
//			char *ActTime, BYTE	**PKCS7Data, int *PKCS7DataLen)
//
//  Effettua una firma ulteriore PKCS#7 
//   del buffer di input con un certo certificato di co-firma
//  applicando anche il timestamp passato in ingresso
//
//  input
//              BYTE*  InData			Buffer da Co-Firmare
//              int    InDataLen		Lunghezza del Buffer da Co-Firmare
//				char   *snToFind		Subject Name del certificato da trovare
//				SYSTEMTIME stActTime	timestamp locale (GetLocalTime)
//				LONG Bias				Bias rispetto a Daylight ... (GetTimeZoneInformation)
//
//  output
//              BYTE	**PKCS7Data		
//				int		*PKCS7DataLen
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::CoSignFromStoreOverSign(BYTE *InData, int InDataLen,
												  LPWSTR snToFind,
												  bool bLocalMachine,
												  SYSTEMTIME stActTime, LONG Bias,
												  BYTE	**PKCS7Data, int *PKCS7DataLen)
{
	int                  rc,CertFound=0;
	unsigned int         i = 0;
	BOOL                 brc;
	HCERTSTORE           hCertStore=NULL;
	PCCERT_CONTEXT       pCertContext=NULL;
	CERT_KEY_CONTEXT     CertKeyCTx;
	PCERT_KEY_CONTEXT    pCertKeyCTx;
	CRYPT_SIGN_MESSAGE_PARA   SignMessagePara;
	FILETIME             FileTime,FileTimeLoc,FileTimeBias;
	LPBYTE               pbAuth=NULL;
	DWORD                cbAuth=0;
	CRYPT_ATTR_BLOB      cablob[1];
	CRYPT_ATTRIBUTE      ca[1];
	const BYTE           *rgpbToBeSigned[1];
	DWORD                rgcbToBeSigned[1];
	ULARGE_INTEGER       UlFileTime, UlFileTimeLoc, UlFileTimeBias;
	__int64              i64UlFileTime, i64UlFileTimeLoc, i64UlFileTimeBias;
	int				retCoSignFromStore = GME_RC_OK;
	bool				bNotExit = false;



	if (bLocalMachine)
		hCertStore = CertOpenStore(CERT_STORE_PROV_SYSTEM,
		MY_ENCODING_TYPE,
		0,
		CERT_SYSTEM_STORE_LOCAL_MACHINE,
		L"MY");
	else
		hCertStore = CertOpenStore(CERT_STORE_PROV_SYSTEM,
		MY_ENCODING_TYPE,
		0,
		CERT_SYSTEM_STORE_CURRENT_USER,
		L"MY");


	if (hCertStore == NULL)
	{
		rc=GetLastError();
		retCoSignFromStore =GME_RC_CERT_FILE_OPEN_ERROR;
	}

	pCertContext = CertFindCertificateInStore(
		hCertStore,
		MY_ENCODING_TYPE,  
		0,                    
		CERT_FIND_SUBJECT_STR, 
		snToFind,
		NULL);       

	if (pCertContext == NULL)
	{
		rc=GetLastError();
		retCoSignFromStore = GME_RC_INT_GET_CERTIFICATE_ERROR;
	}

	//
	//
	if (retCoSignFromStore == GME_RC_OK) 
	{
		CertKeyCTx.cbSize=sizeof(CERT_KEY_CONTEXT);
		CertKeyCTx.hCryptProv=m_UhCryptProv;
		CertKeyCTx.dwKeySpec=AT_SIGNATURE;
		pCertKeyCTx=&CertKeyCTx;

		brc=CertSetCertificateContextProperty(pCertContext,
			CERT_KEY_CONTEXT_PROP_ID,
			0,
			pCertKeyCTx);
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retCoSignFromStore =GME_RC_SET_CERT_PROP_ERROR;
		}
	}

	//
	if (retCoSignFromStore == GME_RC_OK) 
	{
		SystemTimeToFileTime(&stActTime, &FileTimeLoc);
		FillMemory(&stActTime, sizeof(SYSTEMTIME), 0);

		stActTime.wMonth=1;
		stActTime.wDay=1;
		stActTime.wYear=1601;
		stActTime.wHour=(WORD)Bias;
		stActTime.wMinute=0;
		stActTime.wSecond=0;
		stActTime.wDayOfWeek=0;
		stActTime.wMilliseconds=0;
		SystemTimeToFileTime(&stActTime, &FileTimeBias);
		UlFileTimeLoc.HighPart=FileTimeLoc.dwHighDateTime;
		UlFileTimeLoc.LowPart=FileTimeLoc.dwLowDateTime;
		UlFileTimeBias.HighPart=FileTimeBias.dwHighDateTime;
		UlFileTimeBias.LowPart=FileTimeBias.dwLowDateTime;

		i64UlFileTimeLoc    = *(__int64 *)&UlFileTimeLoc;
		i64UlFileTimeBias   = *(__int64 *)&UlFileTimeBias;

		if (Bias>=0)
			i64UlFileTime=i64UlFileTimeLoc-i64UlFileTimeBias;
		else 
			i64UlFileTime=i64UlFileTimeLoc+i64UlFileTimeBias;
		UlFileTime=*(ULARGE_INTEGER *)&i64UlFileTime;
		FileTime.dwHighDateTime=UlFileTime.HighPart;
		FileTime.dwLowDateTime=UlFileTime.LowPart;

		brc=CryptEncodeObject(
			MY_ENCODING_TYPE,
			szOID_RSA_signingTime,
			(LPVOID)&FileTime,
			NULL,
			&cbAuth);

		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retCoSignFromStore = GME_RC_ENCODE_I_ERROR;
		}
	}

	if (retCoSignFromStore == GME_RC_OK) 
	{
		pbAuth = Malloc<BYTE>(cbAuth);
		if(pbAuth==NULL)
		{
			rc=GetLastError();
			retCoSignFromStore = GME_RC_INT_ALLOC_ERROR;
		}
	}

	if (retCoSignFromStore == GME_RC_OK) 
	{
		do
		{
			brc=CryptEncodeObject(
				MY_ENCODING_TYPE,
				szOID_RSA_signingTime,
				(LPVOID)&FileTime,
				pbAuth,
				&cbAuth);
			if(brc==CRYPT_ERROR)
			{
				rc=GetLastError();
				retCoSignFromStore = GME_RC_ENCODE_II_ERROR;
				break;
			}

			cablob[0].cbData = cbAuth;
			cablob[0].pbData = pbAuth;
			ca[0].pszObjId = szOID_RSA_signingTime;
			ca[0].cValue = 1;
			ca[0].rgValue = cablob;

			ZeroMemory(&SignMessagePara, sizeof(CRYPT_SIGN_MESSAGE_PARA));
			SignMessagePara.cbSize = sizeof(CRYPT_SIGN_MESSAGE_PARA);
			SignMessagePara.HashAlgorithm.pszObjId = SIGN_ALGORITHM;
			SignMessagePara.pSigningCert = pCertContext;
			SignMessagePara.dwMsgEncodingType = MY_ENCODING_TYPE;
			SignMessagePara.cMsgCert = 1;
			SignMessagePara.rgpMsgCert = &pCertContext;

			SignMessagePara.cAuthAttr = 1;
			SignMessagePara.rgAuthAttr = ca;

			rgpbToBeSigned[0] = InData;
			rgcbToBeSigned[0] = InDataLen;

			brc=CryptSignMessage(
				&SignMessagePara,
				FALSE,
				1,
				rgpbToBeSigned,
				rgcbToBeSigned,
				NULL,
				(DWORD*)PKCS7DataLen);
			if(brc==CRYPT_ERROR)
			{
				rc=GetLastError();
				retCoSignFromStore = GME_RC_SIGN_MESSAGE_I_ERROR;
				break;
			}

			*PKCS7Data = Malloc<BYTE>(*PKCS7DataLen);
			if(*PKCS7Data==NULL)
			{
				rc=GetLastError();
				*PKCS7DataLen=0;
				retCoSignFromStore = GME_RC_INT_ALLOC_ERROR;
				break;
			}
			brc=CryptSignMessage(
				&SignMessagePara,
				FALSE,
				1,
				rgpbToBeSigned,
				rgcbToBeSigned,
				*PKCS7Data,
				(DWORD*)PKCS7DataLen);
			if(brc==CRYPT_ERROR)
			{
				*PKCS7DataLen=0;
				rc=GetLastError();
				retCoSignFromStore = GME_RC_SIGN_MESSAGE_II_ERROR;
				break;
			}
		}
		while (bNotExit);
	}

	if (retCoSignFromStore != GME_RC_OK)
	{
		if(*PKCS7Data)
		{
			Free(*PKCS7Data);
			*PKCS7Data = NULL;
		}
	}
	if(pCertContext)
	{
		CertFreeCertificateContext(pCertContext);
	}

	if (hCertStore)
	{
		rc=CertCloseStore(hCertStore, CERT_CLOSE_STORE_CHECK_FLAG);
		hCertStore = NULL;
	}
	if(pbAuth)
	{
		Free(pbAuth);
		pbAuth = NULL;
	}
	return  retCoSignFromStore;
}





// -----------------------------------------------------------------------------
//  CoSignFromStoreOldVersion(BYTE *InData, int InDataLen,
//			char *CertParamType, void *CertParam, int CertParamLen,
//			char *ActTime, BYTE	**PKCS7Data, int *PKCS7DataLen)
//
//  Effettua la co-firma di un buffer di input con un certo certificato di co-firma
//  e applicando un certo timestamp\
//
//  input
//              BYTE*  InData			Buffer da Co-Firmare
//              int    InDataLen		Lunghezza del Buffer da Co-Firmare
//				char   *snToFind		Subject Name del certificato da trovare
//				SYSTEMTIME stActTime	timestamp locale (GetLocalTime)
//				LONG Bias				Bias rispetto a Daylight ... (GetTimeZoneInformation)
//
//  output
//              BYTE	**PKCS7Data		
//				int		*PKCS7DataLen
// -----------------------------------------------------------------------------
int CGMEVerifyCryptClass::CoSignFromStore(BYTE *InData, int InDataLen,
										  LPWSTR snToFind,
										  bool bLocalMachine,
										  SYSTEMTIME stActTime, LONG Bias,
										  BYTE	**PKCS7Data, int *PKCS7DataLen)
{
	int                  rc,CertFound=0;
	unsigned int         i = 0;
	BOOL                 brc;
	HCERTSTORE           hCertStore=NULL;
	PCCERT_CONTEXT       pCertContext=NULL;
	CERT_KEY_CONTEXT     CertKeyCTx;
	PCERT_KEY_CONTEXT    pCertKeyCTx;
	FILETIME             FileTime,FileTimeLoc,FileTimeBias;
	LPBYTE               pbAuth=NULL;
	DWORD                cbAuth=0;
	CRYPT_ATTR_BLOB      cablob[1];
	CRYPT_ATTRIBUTE      ca[1];
	ULARGE_INTEGER       UlFileTime, UlFileTimeLoc, UlFileTimeBias;
	__int64              i64UlFileTime, i64UlFileTimeLoc, i64UlFileTimeBias;
	int				retCoSignFromStore = GME_RC_OK;
	bool				bNotExit = false;
	HCRYPTMSG		    hMsg = NULL;



	if (bLocalMachine)
		hCertStore = CertOpenStore(CERT_STORE_PROV_SYSTEM,
		MY_ENCODING_TYPE,
		0,
		CERT_SYSTEM_STORE_LOCAL_MACHINE,
		L"MY");
	else
		hCertStore = CertOpenStore(CERT_STORE_PROV_SYSTEM,
		MY_ENCODING_TYPE,
		0,
		CERT_SYSTEM_STORE_CURRENT_USER,
		L"MY");


	if (hCertStore == NULL)
	{
		rc=GetLastError();
		retCoSignFromStore =GME_RC_CERT_FILE_OPEN_ERROR;
	}

	pCertContext = CertFindCertificateInStore(
		hCertStore,
		MY_ENCODING_TYPE,  
		0,                    
		CERT_FIND_SUBJECT_STR, 
		snToFind,
		NULL);       

	if (pCertContext == NULL)
	{
		rc=GetLastError();
		retCoSignFromStore = GME_RC_INT_GET_CERTIFICATE_ERROR;
	}

	//
	//
	if (retCoSignFromStore == GME_RC_OK) 
	{
		CertKeyCTx.cbSize=sizeof(CERT_KEY_CONTEXT);
		CertKeyCTx.hCryptProv=m_UhCryptProv;
		CertKeyCTx.dwKeySpec=AT_SIGNATURE;
		pCertKeyCTx=&CertKeyCTx;

		brc=CertSetCertificateContextProperty(pCertContext,
			CERT_KEY_CONTEXT_PROP_ID,
			0,
			pCertKeyCTx);
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retCoSignFromStore =GME_RC_SET_CERT_PROP_ERROR;
		}
	}

	//
	if (retCoSignFromStore == GME_RC_OK) 
	{
		SystemTimeToFileTime(&stActTime, &FileTimeLoc);
		FillMemory(&stActTime, sizeof(SYSTEMTIME), 0);

		stActTime.wMonth=1;
		stActTime.wDay=1;
		stActTime.wYear=1601;
		stActTime.wHour=(WORD)Bias;
		stActTime.wMinute=0;
		stActTime.wSecond=0;
		stActTime.wDayOfWeek=0;
		stActTime.wMilliseconds=0;
		SystemTimeToFileTime(&stActTime, &FileTimeBias);
		UlFileTimeLoc.HighPart=FileTimeLoc.dwHighDateTime;
		UlFileTimeLoc.LowPart=FileTimeLoc.dwLowDateTime;
		UlFileTimeBias.HighPart=FileTimeBias.dwHighDateTime;
		UlFileTimeBias.LowPart=FileTimeBias.dwLowDateTime;

		i64UlFileTimeLoc    = *(__int64 *)&UlFileTimeLoc;
		i64UlFileTimeBias   = *(__int64 *)&UlFileTimeBias;

		if (Bias>=0)
			i64UlFileTime=i64UlFileTimeLoc-i64UlFileTimeBias;
		else 
			i64UlFileTime=i64UlFileTimeLoc+i64UlFileTimeBias;
		UlFileTime=*(ULARGE_INTEGER *)&i64UlFileTime;
		FileTime.dwHighDateTime=UlFileTime.HighPart;
		FileTime.dwLowDateTime=UlFileTime.LowPart;

		brc=CryptEncodeObject(
			MY_ENCODING_TYPE,
			szOID_RSA_signingTime,
			(LPVOID)&FileTime,
			NULL,
			&cbAuth);

		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retCoSignFromStore = GME_RC_ENCODE_I_ERROR;
		}
	}

	if (retCoSignFromStore == GME_RC_OK) 
	{
		pbAuth = Malloc<BYTE>(cbAuth);
		if(pbAuth==NULL)
		{
			rc=GetLastError();
			retCoSignFromStore = GME_RC_INT_ALLOC_ERROR;
		}
	}

	if (retCoSignFromStore == GME_RC_OK) 
	{
		do
		{
			brc=CryptEncodeObject(
				MY_ENCODING_TYPE,
				szOID_RSA_signingTime,
				(LPVOID)&FileTime,
				pbAuth,
				&cbAuth);
			if(brc==CRYPT_ERROR)
			{
				rc=GetLastError();
				retCoSignFromStore = GME_RC_ENCODE_II_ERROR;
				break;
			}


			//
			// Carica il messaggio
			//
			retCoSignFromStore = PkcsLoad(&hMsg, InData, InDataLen);
			if (retCoSignFromStore != GME_RC_OK)
			{
				break;
			}

			cablob[0].cbData = cbAuth;
			cablob[0].pbData = pbAuth;
			ca[0].pszObjId = szOID_RSA_signingTime;
			ca[0].cValue = 1;
			ca[0].rgValue = cablob;


			CMSG_SIGNER_ENCODE_INFO CountersignerInfo;
			CMSG_SIGNER_ENCODE_INFO CntrSignArray[1];
			//--------------------------------------------------------------------
			// Inizializza la struttura per la controfirma
			//
			memset(&CountersignerInfo, 0, sizeof(CMSG_SIGNER_ENCODE_INFO));
			CountersignerInfo.cbSize = sizeof(CMSG_SIGNER_ENCODE_INFO);
			CountersignerInfo.pCertInfo = pCertContext->pCertInfo;
			CountersignerInfo.hCryptProv = m_UhCryptProv;
			CountersignerInfo.dwKeySpec = AT_SIGNATURE;
			CountersignerInfo.HashAlgorithm.pszObjId = SIGN_ALGORITHM;
			CountersignerInfo.cAuthAttr = 1;
			CountersignerInfo.rgAuthAttr = ca;

			CntrSignArray[0] = CountersignerInfo;


			//--------------------------------------------------------------------
			// Controfirma il messaggio
			//
			brc = CryptMsgCountersign(hMsg, 0, 1, CntrSignArray);
			if(brc==CRYPT_ERROR)
			{
				*PKCS7DataLen=0;
				rc=GetLastError();
				retCoSignFromStore = GME_RC_SIGN_MESSAGE_II_ERROR;
				break;
			}

			//--------------------------------------------------------------------
			// 
			// Ri-estrai il messaggio controfirmato 
			//
			//
			brc = CryptMsgGetParam(
				hMsg,                  // Handle to the message
				CMSG_ENCODED_MESSAGE,  // Parameter type
				0,                     // Index
				NULL,				   // Address for returned information
				(DWORD *)PKCS7DataLen);       // Size of the returned information

			if(brc==CRYPT_ERROR)
			{
				*PKCS7DataLen=0;
				rc=GetLastError();
				retCoSignFromStore = GME_RC_SIGN_MESSAGE_II_ERROR;
				break;
			}


			//--------------------------------------------------------------------
			// Allocate memory.
			*PKCS7Data = Malloc<BYTE>(*PKCS7DataLen);

			brc = CryptMsgGetParam(
				hMsg,                   // Handle to the message
				CMSG_ENCODED_MESSAGE,   // Parameter type
				0,                      // Index
				*PKCS7Data,          // Address for returned information
				(DWORD *)PKCS7DataLen);        // Size of the returned information
			if(brc==CRYPT_ERROR)
			{
				*PKCS7DataLen=0;
				rc=GetLastError();
				retCoSignFromStore = GME_RC_SIGN_MESSAGE_II_ERROR;
				break;
			}
		}
		while (bNotExit);
	}

	if (retCoSignFromStore != GME_RC_OK)
	{
		if(*PKCS7Data)
		{
			Free(*PKCS7Data);
			*PKCS7Data = NULL;
		}
	}
	if(pCertContext)
	{
		CertFreeCertificateContext(pCertContext);
	}

	if (hCertStore)
	{
		rc=CertCloseStore(hCertStore, CERT_CLOSE_STORE_CHECK_FLAG);
		hCertStore = NULL;
	}
	if(pbAuth)
	{
		Free(pbAuth);
		pbAuth = NULL;
	}
	if(hMsg)
	{
		CryptMsgClose(hMsg);
		hMsg = NULL;
	}
	return  retCoSignFromStore;
}


// -----------------------------------------------------------------------------
//  Verify(char *PKCS7Data, int PKCS7DataLen)
//
//  Verifica la firma del buffer PKCS7
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
// -----------------------------------------------------------------------------
//
int CGMEVerifyCryptClass::Verify(BYTE *PKCS7Data, int PKCS7DataLen)
{
	int                     rc;
	unsigned int              temp_flag=0; 
	BOOL                      brc;
	int                       CertificateLen;
	BYTE                      *Certificate = NULL;
	PCCERT_CONTEXT            pCertContext=NULL;
	PCCERT_CHAIN_CONTEXT      pChainContext=NULL;
	CERT_CHAIN_PARA           ChainPara;
	CERT_ENHKEY_USAGE         EnhkeyUsage;

	/* provides parameters for finding issuer certificates used
	to build a certificate chain.
	*/
	CERT_USAGE_MATCH          CertUsage;
	DWORD                     dwFlags;
	/* contains information needed to verify signed messages.
	*/
	CRYPT_VERIFY_MESSAGE_PARA VerifyParams;
	BYTE                      *pbDecodedMessageBlob;
	DWORD                     cbDecodedMessageBlob=0;
	DWORD                     CertErrorStatus;
	int				retVerify = GME_RC_OK;
	bool				bNotExit = false;


	do
	{
		rc=GetCertificate(PKCS7Data, PKCS7DataLen, &Certificate, &CertificateLen);
		if(rc!=GME_RC_OK)
		{
			if(Certificate)
			{
				Free(Certificate);
				Certificate = NULL;
			}
			retVerify = GME_RC_INT_GET_CERTIFICATE_ERROR;
			break;
		}

		pCertContext=CertCreateCertificateContext(
			MY_ENCODING_TYPE,      // The encoding type
			Certificate,           // The encoded data from the certificate retrieved
			CertificateLen);       // The length of the encoded data
		if(pCertContext==NULL)
		{
			rc=GetLastError();
			retVerify = GME_RC_CREATE_CERT_CTX_ERROR;
			break;
		}

		EnhkeyUsage.cUsageIdentifier = 0;
		EnhkeyUsage.rgpszUsageIdentifier=NULL;
		CertUsage.dwType = USAGE_MATCH_TYPE_AND;        // AND logic
		CertUsage.Usage  = EnhkeyUsage;
		ChainPara.cbSize = sizeof(CERT_CHAIN_PARA);
		ChainPara.RequestedUsage=CertUsage; 
		dwFlags=0;

		// builds a certificate chain context starting from an end certificate and going back
		brc=CertGetCertificateChain(
			HCCE_LOCAL_MACHINE,    // Use the Local Machine chain engine.
			pCertContext,          // Pointer to the end certificate.
			NULL,                  // Use the default time.
			NULL,                  // Search no additional stores.
			&ChainPara,            // Use AND logic, and enhanced key usage
			// as indicated in the ChainPara
			// data structure.
			dwFlags,
			NULL,                  // Currently reserved.
			&pChainContext);       // Return a pointer to the chain created.
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retVerify = GME_RC_GET_CERT_CHAIN_ERROR;
			break;
		}

		//
		// BISOGNEREBBE marcare in qualche modo l'errore 
		//
		CertErrorStatus=pChainContext->TrustStatus.dwErrorStatus;
		switch(CertErrorStatus)
		{
		case CERT_TRUST_NO_ERROR :
			break;
		case CERT_TRUST_IS_NOT_TIME_VALID:
			break;
		case CERT_TRUST_IS_NOT_TIME_NESTED:
			break;
		case CERT_TRUST_IS_REVOKED:
			break;
		case CERT_TRUST_IS_NOT_SIGNATURE_VALID:
			break;
		case CERT_TRUST_IS_NOT_VALID_FOR_USAGE:
			break;
		case CERT_TRUST_IS_UNTRUSTED_ROOT:
			break;
		case CERT_TRUST_REVOCATION_STATUS_UNKNOWN:
			break;
		case CERT_TRUST_IS_CYCLIC :
			break;
		case CERT_TRUST_IS_PARTIAL_CHAIN:
			break;
		case CERT_TRUST_CTL_IS_NOT_TIME_VALID:
			break;
		case CERT_TRUST_CTL_IS_NOT_SIGNATURE_VALID:
			break;
		case CERT_TRUST_CTL_IS_NOT_VALID_FOR_USAGE:
			break;
		default:
			break;
		} // End switch
		if(pChainContext)
		{
			CertFreeCertificateChain(pChainContext);
			pChainContext = NULL;	
		}
		if(pCertContext)
		{
			CertFreeCertificateContext(pCertContext);
			pCertContext = NULL;
		}
	}
	while (bNotExit);

	if(Certificate)
	{
		Free(Certificate);
		Certificate = NULL;
	}

	if(pChainContext)
	{
		CertFreeCertificateChain(pChainContext);
		pChainContext = NULL;	
	}
	if(pCertContext)
	{
		CertFreeCertificateContext(pCertContext);
		pCertContext = NULL;
	}

	//
	// se verifica certificato errata ritorna
	//
	if (retVerify != GME_RC_OK)
	{
		return retVerify;
	}

	//
	// Per ora ignoriamo gli errori di trust del certificato
	//
	/*
	if(CertErrorStatus!=CERT_TRUST_NO_ERROR)
	{
	return(CertErrorStatus);
	}
	*/
	// fine verifica del certificato


	if (retVerify == GME_RC_OK)
	{
		VerifyParams.cbSize = sizeof(CRYPT_VERIFY_MESSAGE_PARA);
		VerifyParams.dwMsgAndCertEncodingType = MY_ENCODING_TYPE;
		VerifyParams.hCryptProv = 0;
		VerifyParams.pfnGetSignerCertificate = NULL;
		VerifyParams.pvGetArg = NULL;


		brc=CryptVerifyMessageSignature(
			&VerifyParams,          // Verify parameters.
			0,                      // Signer index.
			PKCS7Data,              // Pointer to the signed BLOB
			PKCS7DataLen,           // Size of the signed BLOB
			NULL,                   // Buffer for decoded message.
			&cbDecodedMessageBlob,  // Size of buffer.
			NULL);                  // Pointer to signer certificate.
		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retVerify = GME_RC_VERIFY_MESSAGE_I_ERROR;
		}
	}

	if (retVerify == GME_RC_OK)
	{
		pbDecodedMessageBlob=NULL;
		pbDecodedMessageBlob=Malloc<BYTE>(cbDecodedMessageBlob);
		if(pbDecodedMessageBlob==NULL)
		{
			rc=GetLastError();
			retVerify = GME_RC_INT_ALLOC_ERROR;
		}
	}

	if (retVerify == GME_RC_OK)
	{
		brc=CryptVerifyMessageSignature(
			&VerifyParams,           // Verify parameters.
			0,                       // Signer index.
			PKCS7Data,               // Pointer to the signed BLOB
			PKCS7DataLen,            // Size of the signed BLOB
			pbDecodedMessageBlob,    // Buffer for decoded message.
			&cbDecodedMessageBlob,   // Size of buffer.
			NULL);                   // Pointer to signer certificate.

		if(brc==CRYPT_ERROR)
		{
			rc=GetLastError();
			retVerify = GME_RC_VERIFY_MESSAGE_II_ERROR;
		}
	}
	if(pbDecodedMessageBlob)
	{
		Free(pbDecodedMessageBlob);
		pbDecodedMessageBlob = NULL;
	}
	return retVerify;
}





// -----------------------------------------------------------------------------
//  GetCertificateAttribute(char *PKCS7Data, int PKCS7DataLen, 
//							char *AttrType, int AttrTypeLen,
//							char **OutAttrData, int *OutAttrDataLen)
//
//  Estrae un attributo del certificato contenuto nel buffer PKCS7
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
//				char*	AttrType		attributo richiesto
//				int		AttrTypeLen		lunghezza attributo richiesto
//
//
//  output
//              char**	OutAttrData		buffer contenente il valore dell'attributo (da rilasciare con Free)
//			    int*	OutAttrDataLen	lunghezza del buffer di uscita 	
// -----------------------------------------------------------------------------

int CGMEVerifyCryptClass::GetCertificateAttribute(BYTE *PKCS7Data, int PKCS7DataLen,
												  char *AttrType, int AttrTypeLen,
												  BYTE **OutAttrData, int *OutAttrDataLen)
{
	int                  rc;
	PCCERT_CONTEXT       pCertContext=NULL;
	char                 *OutAttrDataBuf = NULL;
	char				   OutAttrDataByte[4];
	BYTE	  			   *Certificate=NULL;
	int                  CertificateLen;
	int				   retGetCertificateAttribute = GME_RC_OK;
	bool				   bNotExit = false;


	OutAttrDataBuf = Malloc<char>(ATTRIBUTE_BUFFER_LEN);
	ZeroMemory( OutAttrDataBuf, ATTRIBUTE_BUFFER_LEN );
	do
	{	
		if ( !lstrcmp(AttrType,"SN") || !lstrcmp(AttrType,"SU") || !lstrcmp(AttrType,"IS") || 
			!lstrcmp(AttrType,"SD")  || !lstrcmp(AttrType,"ED"))		// Aggiunti (StartDate, EndDate)
		{
			rc=GetCertificate(PKCS7Data, PKCS7DataLen, &Certificate, &CertificateLen);
			if(rc!=GME_RC_OK)
			{
				retGetCertificateAttribute = GME_RC_INT_GET_CERTIFICATE_ERROR;
				break;
			}

			pCertContext=CertCreateCertificateContext(
				MY_ENCODING_TYPE,      // The encoding type
				Certificate,           // The encoded data from the certificate retrieved
				CertificateLen);       // The length of the encoded data
			if(pCertContext==NULL)
			{
				rc=GetLastError();
				retGetCertificateAttribute = GME_RC_CREATE_CERT_CTX_ERROR;
				break;
			}
		}
		else 
			if ( !lstrcmp(AttrType,"CERSN") || !lstrcmp(AttrType,"CERSU") || !lstrcmp(AttrType,"CERIS") )
			{
				pCertContext=CertCreateCertificateContext(
					MY_ENCODING_TYPE,     // The encoding type
					PKCS7Data,           // The encoded data from the certificate retrieved
					PKCS7DataLen);       // The length of the encoded data
				if(pCertContext==NULL)
				{
					rc=GetLastError();
					retGetCertificateAttribute = GME_RC_CREATE_CERT_CTX_ERROR;
					break;
				}
			}
			else
			{
				retGetCertificateAttribute = GME_RC_CERT_ATTRIBUTE_PARAM_ERROR;
			}

			if ( !lstrcmp(AttrType,"SN") || !lstrcmp(AttrType,"CERSN") )
			{

				for( long i=pCertContext->pCertInfo->SerialNumber.cbData-1; i>=0; i--)
				{
					//sprintf( OutAttrDataByte, "%02X", pCertContext->pCertInfo->SerialNumber.pbData[i] );
					//
					// quanto sotto e' un po' piu' di legno ... ma dovrebbe fare la stessa cosa
					int hex2 = pCertContext->pCertInfo->SerialNumber.pbData[i] / 16;
					int hex1 = pCertContext->pCertInfo->SerialNumber.pbData[i] - hex2 * 16;

					if (hex2 < 10)
						OutAttrDataByte[0] = hex2 + '0';
					else
						OutAttrDataByte[0] = hex2 - 10 + 'A';
					if (hex1 < 10)
						OutAttrDataByte[1] = hex1 + '0';
					else
						OutAttrDataByte[1] = hex1 - 10 + 'A';
					OutAttrDataByte[2] = 0;
					OutAttrDataByte[3] = 0;

					lstrcat( OutAttrDataBuf, OutAttrDataByte );
				}
			}
			//
			// Aggiunti (StartDate, EndDate) passati come FILETIME
			// 
			if (!lstrcmp(AttrType,"ED"))
			{
				FILETIME ftEndDateTime = pCertContext->pCertInfo->NotAfter;
				*OutAttrDataLen = sizeof(FILETIME);
				*OutAttrData = Malloc<BYTE>(*OutAttrDataLen);
				CopyMemory(*OutAttrData, &ftEndDateTime, sizeof(FILETIME));
				break;
			}
			if (!lstrcmp(AttrType,"SD"))
			{

				FILETIME ftStartDateTime = pCertContext->pCertInfo->NotBefore;
				*OutAttrDataLen = sizeof(FILETIME);
				*OutAttrData = Malloc<BYTE>(*OutAttrDataLen);
				CopyMemory(*OutAttrData, &ftStartDateTime, sizeof(FILETIME));
				break;
			}


			if ( !lstrcmp(AttrType,"SU") || !lstrcmp(AttrType,"CERSU") )
			{
				// converts the name in a CERT_NAME_BLOB to a NULL-terminated character string
				CertNameToStr(
					X509_ASN_ENCODING,
					&pCertContext->pCertInfo->Subject,
					CERT_X500_NAME_STR | CERT_NAME_STR_REVERSE_FLAG,
					OutAttrDataBuf,
					ATTRIBUTE_BUFFER_LEN);
			}

			if ( !lstrcmp(AttrType,"IS") || !lstrcmp(AttrType,"CERIS") )
			{
				CertNameToStr(
					X509_ASN_ENCODING,
					&pCertContext->pCertInfo->Issuer,
					CERT_X500_NAME_STR | CERT_NAME_STR_REVERSE_FLAG,
					OutAttrDataBuf,
					ATTRIBUTE_BUFFER_LEN);
			}

			*OutAttrDataLen=lstrlen(OutAttrDataBuf)+1;
			*OutAttrData = Malloc<BYTE>(*OutAttrDataLen);
			if(*OutAttrData==NULL)
			{
				rc=GetLastError();
				retGetCertificateAttribute = GME_RC_INT_ALLOC_ERROR;
				break;
			}
			ZeroMemory( *OutAttrData, *OutAttrDataLen );
			CopyMemory(*OutAttrData, OutAttrDataBuf, lstrlen(OutAttrDataBuf)+1);
			//lstrcpy(*OutAttrData, OutAttrDataBuf);
	}
	while (bNotExit);

	if (retGetCertificateAttribute != GME_RC_OK)
	{
		if ((*OutAttrData) != NULL)	
		{
			Free((*OutAttrData));
			(*OutAttrData) = NULL;
		}
	}
	if(pCertContext)
	{
		CertFreeCertificateContext(pCertContext);
		pCertContext = NULL;
	}
	if(Certificate)
	{
		Free(Certificate);
		Certificate = NULL;
	}
	if (OutAttrDataBuf)
	{
		Free(OutAttrDataBuf);
		OutAttrDataBuf = NULL;
	}
	return retGetCertificateAttribute;
}




// -----------------------------------------------------------------------------
//  CoSignVerify(char *PKCS7Data, int PKCS7DataLen)
//
//  Verifica complessivamente la co-firma del buffer PKCS7
//  input
//              char*   PKCS7Data       pkcs7 buffer
//              int     PKCS7DataLen    pkcs7 buffer length
// -----------------------------------------------------------------------------
//
int CGMEVerifyCryptClass::CoSignVerify(BYTE *PKCS7Data, int PKCS7DataLen, bool bLocalMachine)
{
	HCRYPTMSG hMsg = NULL;
	int ret;
	BOOL bRes;
	DWORD cbSignerInfo;
	PBYTE pbSignerInfo;
	DWORD cbCountersignerInfo;
	CRYPT_ATTRIBUTES *pCountersignerInfo;
	DWORD	numOfSigners = 0;
	DWORD count =0 ;

	CMSG_CMS_SIGNER_INFO  *pMsgSignerInfo = NULL;
	DWORD				cbMsgSignerInfo;

	PCERT_CONTEXT pCertContext = NULL;
	HCERTSTORE	hStoreHandle = NULL;


	ret = PkcsLoad(&hMsg, PKCS7Data, PKCS7DataLen);

	if (ret == GME_RC_OK)
	{

		//--------------------------------------------------------------
		// Retrieve the signer information from the message.
		// Get the size of memory required.

		bRes = CryptMsgGetParam(
			hMsg,                  // Handle to the message
			CMSG_ENCODED_SIGNER,   // Parameter type
			0,                     // Index
			NULL,                  // Address for returned information
			&cbSignerInfo);        // Size of the returned information

		if (bRes == FALSE)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}

	if (ret == GME_RC_OK)
	{
		//--------------------------------------------------------------------
		// Allocate memory.
		pbSignerInfo = Malloc<BYTE>(cbSignerInfo);

		if (pbSignerInfo == NULL)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}


	if (ret == GME_RC_OK)
	{

		//--------------------------------------------------------------------
		// Get the message signer information.

		bRes = CryptMsgGetParam(
			hMsg,                 // Handle to the message
			CMSG_ENCODED_SIGNER,  // Parameter type
			0,                    // Index
			pbSignerInfo,         // Address for returned information
			&cbSignerInfo);      // Size of the returned information

		if (bRes == FALSE)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}

	//--------------------------------------------------------------------
	// Retrieve the countersigner information from the message.
	// Get the size of memory required.

	if (ret == GME_RC_OK)
	{

		bRes = CryptMsgGetParam(
			hMsg,                          // Handle to the message
			CMSG_SIGNER_UNAUTH_ATTR_PARAM, // Parameter type
			0,                       // Index
			NULL,                          // Address for returned 
			// information
			&cbCountersignerInfo);         // Size of returned 
		// information
		if (bRes == FALSE)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}

	if (ret == GME_RC_OK)
	{

		//--------------------------------------------------------------------
		// Allocate memory.
		pCountersignerInfo = Malloc<CRYPT_ATTRIBUTES>(cbCountersignerInfo);

		if (pCountersignerInfo == NULL)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}


	if (ret == GME_RC_OK)
	{

		//--------------------------------------------------------------------
		// Get the message counter signer info.
		bRes = CryptMsgGetParam(
			hMsg,                           // Handle to the message
			CMSG_SIGNER_UNAUTH_ATTR_PARAM,  // Parameter type
			0,                              // Index
			pCountersignerInfo,             // Address for returned 
			// information
			&cbCountersignerInfo);         // Size of the returned 
		// information
		if (bRes == FALSE)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}



	if (ret == GME_RC_OK)
	{

		bRes = CryptDecodeObject(MY_ENCODING_TYPE,
			CMS_SIGNER_INFO,
			pCountersignerInfo->rgAttr->rgValue->pbData,
			pCountersignerInfo->rgAttr->rgValue->cbData,
			0,
			NULL,
			&cbMsgSignerInfo);

		if (bRes == FALSE)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}

	if (ret == GME_RC_OK)
	{
		pMsgSignerInfo = Malloc<CMSG_CMS_SIGNER_INFO>(cbMsgSignerInfo);
		if (pMsgSignerInfo == NULL)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}

	if (ret == GME_RC_OK)
	{
		bRes = CryptDecodeObject(MY_ENCODING_TYPE,
			CMS_SIGNER_INFO,
			pCountersignerInfo->rgAttr->rgValue->pbData,
			pCountersignerInfo->rgAttr->rgValue->cbData,
			0,
			pMsgSignerInfo,
			&cbMsgSignerInfo);

		if (bRes == FALSE)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}

	if (ret == GME_RC_OK)
	{
		if (bLocalMachine)
		{
			hStoreHandle = CertOpenStore(CERT_STORE_PROV_SYSTEM,
				MY_ENCODING_TYPE,
				0,
				CERT_SYSTEM_STORE_LOCAL_MACHINE,
				L"MY");
		}
		else
		{
			hStoreHandle = CertOpenStore(CERT_STORE_PROV_SYSTEM,
				MY_ENCODING_TYPE,
				0,
				CERT_SYSTEM_STORE_CURRENT_USER,
				L"MY");
		}
		if(!hStoreHandle)
		{
			ret = GME_CERT_OPEN_STORE_ERROR;
		}
	}

	if (ret == GME_RC_OK)
	{
		pCertContext = (PCERT_CONTEXT) CertFindCertificateInStore(hStoreHandle,
			MY_ENCODING_TYPE,
			0,
			CERT_FIND_CERT_ID,
			&pMsgSignerInfo->SignerId,
			NULL);

		if (pCertContext == NULL)
		{
			ret = GME_RC_DECODE64_ERROR;
		}
	}


	if (ret == GME_RC_OK)
	{

		bRes = FALSE;

		//--------------------------------------------------------------------
		//  Verify the countersignature.
		/*
		** E' necessario estrarre le informazioni del certificato (CERT_INFO)
		** e metterlo sull'ultimo parametro
		**/
		bRes = CryptMsgVerifyCountersignatureEncoded(
			0,
			MY_ENCODING_TYPE,
			pbSignerInfo,
			cbSignerInfo,
			pCountersignerInfo->rgAttr->rgValue->pbData,
			pCountersignerInfo->rgAttr->rgValue->cbData,
			pCertContext->pCertInfo);

		if (bRes == FALSE)
		{
			DWORD dwError = GetLastError(); 

			if (dwError == NTE_BAD_SIGNATURE)
			{
				ret  = GME_RC_COSIGNATURE_ERROR;
			}
			ret  = GME_RC_COSIGNATURE_ERROR;
		}
	}

	//--------------------------------------------------------------------
	// Clean up.
	if (pbSignerInfo)
	{
		Free(pbSignerInfo);
		pbSignerInfo = NULL;
	}

	if (pCountersignerInfo)
	{
		Free(pCountersignerInfo);
		pCountersignerInfo = NULL;
	}

	if(hMsg)
	{
		CryptMsgClose(hMsg);
		hMsg = NULL;
	}

	if (pCertContext)
	{
		CertFreeCertificateContext(pCertContext);
		pCertContext = NULL;
	}
	if (hStoreHandle)
	{
		CertCloseStore(hStoreHandle, 0);
		hStoreHandle = NULL;
	}

	return ret;
}