//---------------------------------------------------------------------------

#ifndef GME_CryptClass_H
#define GME_CryptClass_H


extern int strncmp(char *string1, char *string2, size_t n);
//extern void *MALLOC(int len);
//extern void FREE(void *d);

template <typename T>
T * Malloc(int sz)
{
	HGLOBAL hGlob = GlobalAlloc(GPTR, sz * sizeof(T)); 
	if (hGlob != NULL && hGlob != INVALID_HANDLE_VALUE)
		return (T *)GlobalLock(hGlob);
	else
		return NULL;

}

template <typename T>
void Free(T *p)
{
	HGLOBAL hGlob;
	if (p!= NULL)
	{
		hGlob = GlobalHandle(p);
	}
	if (((hGlob) != NULL) && ((hGlob) != INVALID_HANDLE_VALUE))
	{
		GlobalUnlock(hGlob);
		GlobalFree(hGlob); 
	}
}


//----------------------------------------------------------------------------




//#define B64_ENC(Ch) (char) (base64table[(char)(Ch) & 0x3f])

/*
struct buffer_st {
  char *data;
  int length;
  char *ptr;
  int offset;
};
*/


//---------------------------------------------------------------------------
#define CRYPT_ERROR         FALSE



#define MAX_CERT                        512
#define MAX_CSP_NAME                    MAX_PATH
#define MAX_KEYCONT_NAME                MAX_PATH
#define MAX_CERT_SUBJECT_NAME           2048
#define MAX_CERT_ISSUER_BUFFER          2048
#define MAX_SERIAL_NUMBER_BUFFER        2048
#define MAX_FILE_LEN_READ               1024


#define SIGN_ALGORITHM              szOID_OIWSEC_sha1


// #define COMMON_NAME_OID                 "2.5.4.3="
extern const char *COMMON_NAME_OID;

#define MY_ENCODING_TYPE  (PKCS_7_ASN_ENCODING | X509_ASN_ENCODING)

#define CSP_SW              1
#define CSP_HW_SW           2
#define CSP_HW              3

#define KEY_USAGE_TO_SIGN       (CERT_DIGITAL_SIGNATURE_KEY_USAGE | CERT_NON_REPUDIATION_KEY_USAGE)  

#define KEY_REG_PROVIDER TEXT("software\\Microsoft\\Cryptography\\Defaults\\Provider")




/*******************CODICI DI ERRORE PER CLASSE CGMECryptClass ************************************/

#define GME_INTERNAL_OK                                         0

#define GME_CERT_OPEN_STORE_ERROR                               100
#define GME_TOO_MANY_CERT_ERROR                                 101
#define GME_NO_CERTIFICATE_ERROR                                102
#define GME_CHOOSE_CERTIFICATE_ERROR                            103
#define GME_CSP_ACQUIRE_ERROR                                   104
#define GME_GET_USERKEY_ERROR                                   105
#define GME_GET_CERT_PROP_I_ERROR                               106
#define GME_GET_CERT_PROP_II_ERROR                              107
#define GME_GET_CERT_PROP_MALLOC_ERROR                          108
#define GME_GET_CERT_NAME_ERROR                                 109
#define GME_MULTIBYTE_ERROR                                     110
#define GME_CERTIFICATE_INTERNAL_ERROR                          111
#define GME_SIGN_MESSAGE_I_ERROR                                112
#define GME_SIGN_MESSAGE_II_ERROR                               113
#define GME_SIGN_MESSAGE_MALLOC_ERROR                           114
#define GME_RELEASE_CERT_CTX_ERROR                              115
#define GME_CLOSE_CERT_STORE_ERROR                              116
#define GME_RELEASE_CRYPT_CTX_ERROR                             117
#define GME_BASE64_MALLOC_ERROR                                 118
#define GME_FILE_OPEN_ERROR                                     119
#define GME_FILE_SEEK_ERROR                                     120
#define GME_FILE_TELL_ERROR                                     121
#define GME_FILE_MALLOC_ERROR                                   122
#define GME_FILE_READ_ERROR                                     123
#define GME_GET_PROVTYPE_ERROR                                  124
#define GME_PROV_TYPE_HW_ERROR                                  125
#define GME_EMPTY_FILE_ERROR                                    126
#define GME_EMPTY_BUFFER_ERROR                                  127
#define GME_CERTIFICATE_EXTENSION_DECODE_ERROR                  128
#define	GME_DESTROY_KEY_ERROR					129



//---------------------------------------------------------------------------
//
//      CODICI DI ERRORE e definizioni PER CLASSE CGMEVerifyClass
//
//---------------------------------------------------------------------------

#define ATTRIBUTE_BUFFER_LEN    4096


#define GME_RC_OK                                  0
#define GME_RC_GENERIC_ERROR                      -1 // Errore generico
#define GME_RC_MEMORY_ERROR                      -10 // Errore dovuto alla memoria
#define GME_RC_SYSTEM_ERROR                      -11 // Fallita chiamata a sistema
#define GME_RC_INTERNAL_ERROR                    -12 // Errore interno dovuto a evento inaspettato
#define GME_RC_INVALID_OPERATION                 -13 // Funzione invocata fuori contesto

#define GME_RC_INVALID_PARAMETER                 -20 // Errore : Parametri non corretti
#define GME_MIME64TOPKCS7_IMPL_ERROR             -25 // Errore : Formato BASE64 input errato

#define GME_RC_ENCODE64_ERROR                    -30 // Errore : Codifica BASE64 fallita
#define GME_RC_DECODE64_ERROR                    -31 // Errore : Decodifica BASE64 fallita

#define GME_RC_INIT_PARAM_ERROR                  -49 // Errore : Procedura inizializzazione fallita
#define GME_RC_CRYPT_ACQUIRE_ERROR               -50 // Errore : Apertura KeyContainer fallita
#define GME_RC_CRYPT_RELEASE_ERROR               -51 // Errore : Chiusura KeyContainer fallita
#define GME_RC_PKCSLOAD_ERROR                    -52 // Errore : Lettura dato PKCS7 fallita
#define GME_RC_MESSAGE_GET_ERROR_I               -53 // Errore : Decodifica ASN.1 messaggio fallita
#define GME_RC_MESSAGE_GET_ERROR_II              -54 // Errore : Decodifica ASN.1 messaggio fallita
#define GME_RC_INT_ALLOC_ERROR                   -55 // Errore : Allocazione memoria fallita
#define GME_RC_MESSAGE_GET_PARAM_ERROR_I         -56 // Errore : Lettura parametri da messaggio fallita
#define GME_RC_MESSAGE_GET_PARAM_ERROR_II        -57 // Errore : Lettura parametri da messaggio fallita
#define GME_RC_INT_GET_CERTIFICATE_ERROR         -58 // Errore : Lettura certificato fallita
#define GME_RC_CREATE_CERT_CTX_ERROR             -59 // Errore : Creazione struttura dati per certificato fallita
#define GME_RC_GET_CERT_CHAIN_ERROR              -60 // Errore : Acquisizione catena di certificazione fallita
#define GME_RC_VERIFY_MESSAGE_I_ERROR            -61 // Errore : Verifica firma fallita per errore interno
#define GME_RC_VERIFY_MESSAGE_II_ERROR           -62 // Errore : Verifica firma fallita per errore interno
#define GME_RC_CERT_FILE_OPEN_ERROR              -63 // Errore : Apertura file contenente il certificato falllita
#define GME_RC_CERT_ENUM_ERROR                   -64 // Errore : Lettura del certificato fallita
#define GME_RC_SET_CERT_PROP_ERROR               -65 // Errore : Scrittura parametro del certificato fallita 
#define GME_RC_CERT_SYSTEM_OPEN_ERROR            -66 // Errore : Apertura Certificate Store falllita
#define GME_RC_MULTIBYTE_ERROR                   -67 // Errore : Conversione multibyte fallita
#define GME_RC_GET_CERT_CTX_I_ERROR              -68 // Errore : Lettura attributo chiave privata da certificato fallita 
#define GME_RC_GET_CERT_CTX_II_ERROR             -69 // Errore : Lettura attributo chiave privata da certificato fallita 
#define GME_RC_CERT_TYPE_PARAM_ERROR             -70 // Errore : Parametro tipo Certificate Store errato (F o S)
#define GME_RC_CERT_NOT_FOUND_ERROR              -71 // Errore : Certificato non trovato
#define GME_RC_DECODE_ERROR                      -72 // Errore : Decodifica ASN.1 fallita
#define GME_RC_ENCODE_I_ERROR                    -73 // Errore : Codifica ASN.1 attributo Signing Time fallita
#define GME_RC_ENCODE_II_ERROR                   -74 // Errore : Codifica ASN.1 attributo Signing Time fallita
#define GME_RC_SIGN_MESSAGE_I_ERROR              -75 // Errore : Firma lato server fallita
#define GME_RC_SIGN_MESSAGE_II_ERROR             -76 // Errore : Firma lato server fallita
#define GME_RC_CERT_ATTRIBUTE_PARAM_ERROR        -78 // Errore : Lettura attributo certificato fallita
#define GME_RC_OUT_TYPE_PARAM_ERROR              -79 // Errore : Parametro tipo output GME_GetData errato
#define GME_RC_KEY_GENERATION_ERROR              -80 // Errore : Generazione chiave fallita
#define GME_RC_MSG_OPEN_TO_DEC_ERROR             -81 // Errore : Apertura messsaggio per decodifica fallita
#define GME_RC_MSG_UPDATE_ERROR                  -82 // Errore : Inserimento messagggio per decodifica fallita
#define GME_RC_CLOSE_STORE_ERROR                 -83 // Errore : Chiusura Certificate Store fallita
#define GME_RC_SIGN_CLOSE_STORE_ERROR            -84 // Errore : Chiusura Certificate Store in GME_Sign fallita
#define GME_RC_SIGN_CRYPT_ACQUIRE_ERROR          -85 // Errore : Apertura Key Container in GME_Sign fallita
#define GME_RC_SIGN_ATTRIBUTE_PARAM_ERROR        -86 // Errore : Lettura attributo firma fallita
#define GME_RC_SIGN_TIME_ERROR                   -87 // Errore : Parametro attributo temporale errato
#define GME_RC_SIGN_FILETIME_ERROR               -88 // Errore : Conversione FileTime fallita
#define GME_RC_KEY_REMOVE_ERROR                  -89 // Errore : Cancellazione chiave fallita

#define GME_RC_GET_CURR_THREAD_ERROR             -90 // Errore : Acquisizione dati thread corrente fallita



#define GME_BYNARY_INTO_VAR_ERROR               -100 // Errore : Conversione binario-variant fallita
#define GME_BYNARY_FROM_VAR_ERROR               -101 // Errore : Conversione variant-binario fallita

#define GME_RC_LOADING_COMPLETED                -200 // Caricamento certificato concluso correttamente
#define GME_RC_KEY_ALREADY_EXISTING             -201 // Errore (Warning) : chiave gia' esistente

#define GME_RC_COSIGNATURE_ERROR				-201 // Errore Co-signature



//---------------------------------------------------------------------------
//
// The following are error status bits
//
// These can be applied to certificates and chains
//#define CERT_TRUST_NO_ERROR                   0x00000000          0
//          No error found for this certificate or chain
#define GME_VERIFY_TRUST_NO_ERROR             CERT_TRUST_NO_ERROR
//#define CERT_TRUST_IS_NOT_TIME_VALID          0x00000001          1
//              This certificate or one of the certificates in the certificate chain is not time-valid.
#define GME_VERIFY_TRUST_IS_NOT_TIME_VALID    CERT_TRUST_IS_NOT_TIME_VALID
//#define CERT_TRUST_IS_NOT_TIME_NESTED         0x00000002          2
//          Certificates in the chain are not properly time-nested.
#define GME_VERIFY_TRUST_IS_NOT_TIME_NESTED   CERT_TRUST_IS_NOT_TIME_NESTED
//#define CERT_TRUST_IS_REVOKED                 0x00000004          4
//          Trust for this certificate or one of the certificates in the certificate chain has been revoked.
#define GME_VERIFY_TRUST_IS_REVOKED           CERT_TRUST_IS_REVOKED
//#define CERT_TRUST_IS_NOT_SIGNATURE_VALID     0x00000008          8
//          The certificate or one of the certificates in the certificate chain does not have a valid signature.
#define GME_VERIFY_TRUST_IS_NOT_SIGNATURE_VALID CERT_TRUST_IS_NOT_SIGNATURE_VALID
//#define CERT_TRUST_IS_NOT_VALID_FOR_USAGE     0x00000010         16
//          The certificate or certificate chain is not valid in its proposed usage.
#define GME_VERIFY_TRUST_IS_NOT_VALID_FOR_USAGE CERT_TRUST_IS_NOT_VALID_FOR_USAGE
//#define CERT_TRUST_IS_UNTRUSTED_ROOT          0x00000020         32
//          The certificate or certificate chain is based on an untrusted root.
#define GME_VERIFY_TRUST_IS_UNTRUSTED_ROOT    CERT_TRUST_IS_UNTRUSTED_ROOT
//#define CERT_TRUST_REVOCATION_STATUS_UNKNOWN  0x00000040         64
//          The revocation status of the certificate or one of the certificates in the certificate chain is unknown.
#define GME_VERIFY_TRUST_REVOCATION_STATUS_UNKNOWN CERT_TRUST_REVOCATION_STATUS_UNKNOWN
//#define CERT_TRUST_IS_CYCLIC                  0x00000080        128
//          One of the certificates in the chain was issued by a certification authority that the original certificate had certified.
#define GME_VERIFY_TRUST_IS_CYCLIC            CERT_TRUST_IS_CYCLIC
//
//
// These can be applied to chains only
//
//#define CERT_TRUST_IS_PARTIAL_CHAIN           0x00010000      65536
//          The certificate chain is not complete.
#define GME_VERIFY_TRUST_IS_PARTIAL_CHAIN     CERT_TRUST_IS_PARTIAL_CHAIN
//#define CERT_TRUST_CTL_IS_NOT_TIME_VALID      0x00020000     131072
//          A CTL used to create this chain was not time-valid.
#define GME_VERIFY_TRUST_CTL_IS_NOT_TIME_VALID CERT_TRUST_CTL_IS_NOT_TIME_VALID
//#define CERT_TRUST_CTL_IS_NOT_SIGNATURE_VALID 0x00040000     262144
//          A CTL used to create this chain did not have a valid signature.
#define GME_VERIFY_TRUST_CTL_IS_NOT_SIGNATURE_VALID CERT_TRUST_CTL_IS_NOT_SIGNATURE_VALID
//#define CERT_TRUST_CTL_IS_NOT_VALID_FOR_USAGE 0x00080000     524288
//          A CTL used to create this chain is not valid for this usage.
#define GME_VERIFY_TRUST_CTL_IS_NOT_VALID_FOR_USAGE CERT_TRUST_CTL_IS_NOT_VALID_FOR_USAGE
//





class CGMECryptClass {
public:
	CGMECryptClass();
	~CGMECryptClass();

	int FindAvailableCertificate(bool bLocalMachine = true);

	int ChooseCertificate(char *certName);
	int ChooseCertificate(int index);

	int OpenCSP(char *InPIN = NULL);
	bool IsCSPOpened() {if (hCryptProv == NULL) return false; else return true; }
	int HoldCertificate(void);
	int DoSign(BYTE *InData, int InDataLen, BYTE **OutData, int *OutDataLen);
	int ReleaseAll(void);

	typedef struct
	{
		int       CertID;
		int       KeyUsage; 
		int       KeySpec; 
		char      CSPName[MAX_CSP_NAME+1];
		char      KeyContainerName[MAX_KEYCONT_NAME+1];
		char      SubjectName[MAX_CERT_SUBJECT_NAME+1];
		char      Issuer[MAX_CERT_ISSUER_BUFFER+1];
		char      IssuerName[MAX_CERT_ISSUER_BUFFER+1];
		char      SerialNumber[MAX_SERIAL_NUMBER_BUFFER+1];

	} CertItem;


	int CertificateAvailableCount() {return AvailableCertCount;}
	int CertificateCertIDAvailable(int item) { return AvailableCert[item].CertID;}
	int CertificateKeyUsageAvailable(int item) { return AvailableCert[item].KeyUsage;}
	char *CertificateSubjectNameAvailable(int item) { return AvailableCert[item].SubjectName;}
	char *CertificateCSPNameAvailable(int item) { return AvailableCert[item].CSPName;}
	char *CertificateKeyContainerNameAvailable(int item) { return AvailableCert[item].KeyContainerName;}
	char *CertificateIssuerAvailable(int item) { return AvailableCert[item].Issuer;}
	char *CertificateIssuerNameAvailable(int item) { return AvailableCert[item].IssuerName;}
	char *CertificateSerialNumberAvailable(int item) { return AvailableCert[item].SerialNumber;}

	int CertificateCertIDChosed() { return AvailableCert[certChoosed].CertID;}
	int CertificateKeyUsageChosed() { return AvailableCert[certChoosed].KeyUsage;}
	char *CertificateSubjectNameChosed() { return AvailableCert[certChoosed].SubjectName;}
	char *CertificateCSPNameChosed() { return AvailableCert[certChoosed].CSPName;}
	char *CertificateKeyContainerNameChosed() { return AvailableCert[certChoosed].KeyContainerName;}
	char *CertificateIssuerChosed() { return AvailableCert[certChoosed].Issuer;}
	char *CertificateIssuerNameChosed() { return AvailableCert[certChoosed].IssuerName;}
	char *CertificateSerialNumberChosed() { return AvailableCert[certChoosed].SerialNumber;}

	int InternalSignFile(char *InCertName, char *FileName, char **OutData, int *OutDataLen);
	int InternalSignFile(int index, char *FileName, char **OutData, int *OutDataLen);



	int InternalSignBuffer(BYTE *InData, int InDataLen, char *InCertName, 
							char **OutData, int *OutDataLen);
	int InternalSignBuffer(BYTE *InData, int InDataLen, int index, 
							char **OutData, int *OutDataLen);


private:
	int ReadInputFile(char *FileName, BYTE **InData, int *InDataLen);


	
private:
	//------------------------------------------------------------------------------
	CertItem *AvailableCert;
	int      AvailableCertCount,CertIndex;
	int  certChoosed;

	//
	// Handles usati per la firma
	//
	HCRYPTPROV	hCryptProv;      // Handle for the cryptographic provider context.
	HCRYPTKEY       hCryptKey;       // Public/private key handle.
	HCERTSTORE      hStoreHandle;    // Handle for the certificate store
	PCCERT_CONTEXT  pCertContext;    // Pointer for the certificate context
 	CRYPT_SIGN_MESSAGE_PARA SignMessagePara; // Struct for signature

	int gvContextState;     
	int gvFindCertState;
	int gvHoldCertState;
	int gvChooseCertState;
};


//
// classe per la verifica della firma
//
class CGMEVerifyCryptClass {
public:
	CGMEVerifyCryptClass();
	~CGMEVerifyCryptClass();

	int Init(char *CSPName, char *KEYName, char *InPIN, bool bMachineKeySet = true);
	int GenerateKeyContainer(char *CSPName, char *KEYName, bool bMachineKeySet = true);
	int DestroyKeyContainer(char *CSPName, char *KEYName, bool bMachineKeySet = true);


	int GetCertificate(BYTE *PKCS7Data, int PKCS7DataLen,
                                 BYTE **Certificate, int *CertificateLen, int index=0);
	int GetData(BYTE *PKCS7Data, int PKCS7DataLen, BYTE **OutData, int *OutDataLen);
	int GetSigningTime(BYTE *PKCS7Data, int PKCS7DataLen,
						SYSTEMTIME   *stSigningTime,
						LONG *Bias);
	int GetSigningTimeCoSign(BYTE *PKCS7Data, int PKCS7DataLen, 
										 SYSTEMTIME   *stSigningTime,
										 LONG *Bias);

	int GetTime(SYSTEMTIME *stActTime, LONG *Bias);

	int GetCertificateAttribute(BYTE *PKCS7Data, int PKCS7DataLen,
								char *AttrType, int AttrTypeLen,
								BYTE **OutAttrData, int *OutAttrDataLen);

	int Verify(BYTE *PKCS7Data, int PKCS7DataLen);

	int CoSignFromFile(BYTE *InData, int InDataLen,
						char *CertFileName,
						SYSTEMTIME stActTime, LONG Bias,
						BYTE	**PKCS7Data, int *PKCS7DataLen);

	int CoSignFromStoreOverSign(BYTE *InData, int InDataLen,
						LPWSTR snToFind,
						bool bLocalMachine,
						SYSTEMTIME stActTime, LONG Bias,
						BYTE	**PKCS7Data, int *PKCS7DataLen);

	int CoSignFromStore(BYTE *InData, int InDataLen,
						LPWSTR snToFind,
						bool bLocalMachine,
						SYSTEMTIME stActTime, LONG Bias,
						BYTE	**PKCS7Data, int *PKCS7DataLen);

	int CoSignVerify(BYTE *PKCS7Data, int PKCS7DataLen, bool bLocalMachine);
	int GetCertificatesCount(BYTE *PKCS7Data, int PKCS7DataLen, 
											  DWORD *count);
	int GetSignersCount(BYTE *PKCS7Data, int PKCS7DataLen, 
											  DWORD *count);

	
private:
	int PkcsLoad(HCRYPTMSG *hMsg, BYTE *PKCS7Data, int PKCS7DataLen);

	//
	// Handles usati per la verifica del
	//
	HCRYPTPROV	m_UhCryptProv;
};


//---------------------------------------------------------------------------
#endif /* GME_CryptClass_H */
