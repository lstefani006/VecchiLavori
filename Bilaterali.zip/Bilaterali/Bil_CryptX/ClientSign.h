// ClientSign.h : Declaration of the CClientSign

#pragma once
#include "resource.h"       // main symbols
#include "GMECryptClass.h"


// IClientSign
[
	object,
	uuid("AD05D448-F5CE-4783-9853-17C8D19759CD"),
	dual,	helpstring("IClientSign Interface"),
	pointer_default(unique)
]
__interface IClientSign : IDispatch
{
	[id(1), helpstring("method FindAvailableCertificate")] HRESULT FindAvailableCertificate(VARIANT_BOOL LocalMachine);
	[propget, id(2), helpstring("property CertificateCount")] HRESULT CertificateCount([out, retval] LONG* pVal);
	[id(3), helpstring("method GetSubject")] HRESULT GetSubject([in] LONG nIndex, [out,retval] BSTR* Subject);
	[id(4), helpstring("method GetIssuer")] HRESULT GetIssuer([in] LONG nIndex, [out,retval] BSTR* Issuer);
	[id(5), helpstring("method SignFile")] HRESULT SignFile([in] BSTR CertificateSubject, [in] BSTR FileName, [out,retval] BSTR * SignedDocument);
	[id(6), helpstring("method SignBuffer")] HRESULT SignBuffer([in] BSTR certName, [in] BSTR InData, [out,retval] BSTR* OutData);
	[id(7), helpstring("method SignBufferById")] HRESULT SignBufferById([in] LONG index, [in] BSTR InData, [out,retval] BSTR* OutData);
	[id(8), helpstring("method SignFileById")] HRESULT SignFileById([in] LONG index, [in] BSTR FileName, [out,retval] BSTR* OutData);
};



// CClientSign

[
	coclass,
	threading("apartment"),
	support_error_info("IClientSign"),
	vi_progid("Bil_CryptX.ClientSign"),
	progid("Bil_CryptX.ClientSign.1"),
	version(1.0),
	uuid("5CF632EC-49E4-4E24-B164-258A76A90284"),
	helpstring("ClientSign Class")
]
class ATL_NO_VTABLE CClientSign : 
	public IClientSign,
	public IObjectSafetyImpl<CClientSign, INTERFACESAFE_FOR_UNTRUSTED_CALLER>
{
public:
	CClientSign()
	{
	}

	CGMECryptClass c;


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(FindAvailableCertificate)(VARIANT_BOOL LocalMachine);
	STDMETHOD(get_CertificateCount)(LONG* pVal);
	STDMETHOD(GetSubject)(LONG nIndex, BSTR* Subject);
	STDMETHOD(GetIssuer)(LONG nIndex, BSTR* Issuer);
	STDMETHOD(SignFile)(BSTR CertificateSubject, BSTR FileName, BSTR * SignedDocument);
	STDMETHOD(SignBuffer)(BSTR InData, BSTR certName, BSTR* OutData);
	STDMETHOD(SignBufferById)(LONG index, BSTR InData, BSTR* OutData);
	STDMETHOD(SignFileById)(LONG index, BSTR FileName, BSTR* OutData);
};

