// Bil_CryptX.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{21EF466E-F055-4D98-8669-2451CD0DC143}", 
		 name = "Bil_CryptX", 
		 helpstring = "Bil_CryptX 1.0 Type Library",
		 resource_name = "IDR_BIL_CRYPTX") ]
class CBil_CryptXModule
{
public:
// Override CAtlDllModuleT members
};
		 
