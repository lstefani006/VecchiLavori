// ClientSign.cpp : Implementation of CClientSign

#include "stdafx.h"
#include "ClientSign.h"
#include ".\clientsign.h"


// CClientSign


STDMETHODIMP CClientSign::FindAvailableCertificate(VARIANT_BOOL LocalMachine)
{
	int r = c.FindAvailableCertificate(LocalMachine == VARIANT_TRUE);
	if (r == GME_INTERNAL_OK)
		return S_OK;

	TCHAR str[256];
	wsprintf(str, "FindAvailableCertificate returns %d", r);
	Error(str);
	return E_FAIL;
}

STDMETHODIMP CClientSign::get_CertificateCount(LONG* pVal)
{
	*pVal = c.CertificateAvailableCount();
	return S_OK;
}


STDMETHODIMP CClientSign::GetSubject(LONG nIndex, BSTR* Subject)
{
	if (nIndex < 0 || nIndex >= c.CertificateAvailableCount())
	{
		CComBSTR r("");
		*Subject = r.Detach();
		Error("GetSubject index out of range");
		return E_INVALIDARG;
	}

	const char *s = c.CertificateSubjectNameAvailable(nIndex);
	CComBSTR r(s);
	*Subject = r.Detach();
	return S_OK;
}

STDMETHODIMP CClientSign::GetIssuer(LONG nIndex, BSTR* Issuer)
{
	if (nIndex < 0 || nIndex >= c.CertificateAvailableCount())
	{
		CComBSTR r("");
		*Issuer = r.Detach();
		Error("GetIssuer index out of range");
		return E_INVALIDARG;
	}

	const char *s = c.CertificateIssuerNameAvailable(nIndex);
	CComBSTR r(s);
	*Issuer = r.Detach();
	return S_OK;
}

STDMETHODIMP CClientSign::SignFile(BSTR CertificateSubject, BSTR FileName, BSTR * SignedDocument)
{
	CW2A asciiCertificateSubject(CertificateSubject);
	CW2A asciiFileName(FileName);


	int OutDataLen;
	char *OutData;
	int rc = c.InternalSignFile(asciiCertificateSubject, asciiFileName, &OutData, &OutDataLen);
	if (rc != GME_INTERNAL_OK)
	{
		CComBSTR r("");
		*SignedDocument = r.Detach();
		static TCHAR str[256];
		wsprintf(str, _T("SignFile returns %d"), rc);
		Error(str, __uuidof(IClientSign), E_FAIL);
		return E_FAIL;
	}

	CComBSTR r(OutData);

	Free(OutData);

	*SignedDocument = r.Detach();
	return S_OK;
}

STDMETHODIMP CClientSign::SignBuffer(BSTR CertificateSubject, BSTR InData, BSTR* SignedDocument)
{
	CW2A asciiCertificateSubject(CertificateSubject);
	CW2A asciiInData(InData);

	CComBSTR bstrInData(InData);

	int len = bstrInData.Length();
	
	int OutDataLen;
	char *OutData;
	int rc = c.InternalSignBuffer((BYTE *)asciiInData.m_psz, len, asciiCertificateSubject, &OutData, &OutDataLen);
	if (rc != GME_INTERNAL_OK)
	{
		CComBSTR r("");
		*SignedDocument = r.Detach();

		static TCHAR str[256];
		wsprintf(str, _T("SignBuffer returns %d"), rc);
		Error(str,__uuidof(IClientSign));
		return E_FAIL;
	}

	CComBSTR r(OutData);

	Free(OutData);

	*SignedDocument = r.Detach();
	return S_OK;
}

STDMETHODIMP CClientSign::SignBufferById(LONG index, BSTR InData, BSTR* SignedDocument)
{
	// TODO: Add your implementation code here
	CW2A asciiInData(InData);

	CComBSTR bstrInData(InData);

	int len = bstrInData.Length();
	
	int OutDataLen;
	char *OutData;
	int rc = c.InternalSignBuffer((BYTE *)asciiInData.m_psz, len, index, &OutData, &OutDataLen);
	if (rc != GME_INTERNAL_OK)
	{
		CComBSTR r("");
		*SignedDocument = r.Detach();

		static TCHAR str[256];
		wsprintf(str, _T("SignBufferById returns %d"), rc);
		Error(str,__uuidof(IClientSign));
		return E_FAIL;
	}

	CComBSTR r(OutData);

	Free(OutData);

	*SignedDocument = r.Detach();
	return S_OK;
}

STDMETHODIMP CClientSign::SignFileById(LONG index, BSTR FileName, BSTR* SignedDocument)
{
	// TODO: Add your implementation code here
	CW2A asciiFileName(FileName);


	int OutDataLen;
	char *OutData;
	int rc = c.InternalSignFile(index, asciiFileName, &OutData, &OutDataLen);
	if (rc != GME_INTERNAL_OK)
	{
		CComBSTR r("");
		*SignedDocument = r.Detach();
		static TCHAR str[256];
		wsprintf(str, _T("SignFileById returns %d"), rc);
		Error(str, __uuidof(IClientSign), E_FAIL);
		return E_FAIL;
	}

	CComBSTR r(OutData);

	Free(OutData);

	*SignedDocument = r.Detach();
	return S_OK;
}
