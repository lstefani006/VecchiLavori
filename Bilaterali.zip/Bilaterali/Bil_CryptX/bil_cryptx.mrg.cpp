// Created by Microsoft (R) C/C++ Compiler Version 13.10.3077
//
// c:\bilaterali\bil_cryptx\bil_cryptx.mrg.cpp
// compiler-generated file created 01/02/06 at 10:07:16
//
// This C++ source file is intended to be a representation of the
// source code injected by the compiler.  It may not compile or
// run exactly as the original source file.
//


//+++ Start Injected Code
[no_injected_text(true)];      // Suppress injected text, it has already been injected
#pragma warning(disable: 4543) // Suppress warnings about skipping injected text
#pragma warning(disable: 4199) // Suppress warnings from attribute providers

// M00PRAGMA("\n\nNOTE: This merged source file should be visually inspected for correctness.\n\n")
//--- End Injected Code



//+++ Start Injected Code For Attribute 'module'
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"

#ifndef GUID_DEFINED
#define GUID_DEFINED
typedef struct _GUID 
{
    unsigned long  Data1;
    unsigned short Data2;
    unsigned short Data3;
    unsigned char  Data4[ 8 ];
} 
GUID;
#endif

extern "C" const __declspec(selectany) GUID __LIBID_ = {0x21ef466e,0xf055,0x4d98,{0x86,0x69,0x24,0x51,0xcd,0x0d,0xc1,0x43}};
struct __declspec(uuid("21ef466e-f055-4d98-8669-2451cd0dc143")) Bil_CryptX;

//--- End Injected Code For Attribute 'module'
// Bil_CryptX.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{21EF466E-F055-4D98-8669-2451CD0DC143}", 
		 name = "Bil_CryptX", 
		 helpstring = "Bil_CryptX 1.0 Type Library",
		 resource_name = "IDR_BIL_CRYPTX") ]
class CBil_CryptXModule
 :
    /*+++ Added Baseclass */ public CAtlDllModuleT<CBil_CryptXModule>
{
public:
// Override CAtlDllModuleT members

	//+++ Start Injected Code For Attribute 'module'
    #injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"

						DECLARE_LIBID(__uuidof(Bil_CryptX))
					
	//--- End Injected Code For Attribute 'module'
};

//+++ Start Injected Code For Attribute 'module'
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"

extern CBil_CryptXModule _AtlModule;

//--- End Injected Code For Attribute 'module'


//+++ Start Injected Code For Attribute 'module'
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
extern "C" STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, void** ppv);

//--- End Injected Code For Attribute 'module'


//+++ Start Injected Code For Attribute 'module'
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
extern "C" STDAPI DllRegisterServer(void);

//--- End Injected Code For Attribute 'module'


//+++ Start Injected Code For Attribute 'module'
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
extern "C" STDAPI DllUnregisterServer(void);

//--- End Injected Code For Attribute 'module'


//+++ Start Injected Code For Attribute 'module'
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
extern "C" STDAPI DllCanUnloadNow(void);

//--- End Injected Code For Attribute 'module'


//+++ Start Injected Code For Attribute 'module'
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved);

//--- End Injected Code For Attribute 'module'


//+++ Start Injected Code For Attribute 'module'
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"

CBil_CryptXModule _AtlModule;

#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
extern "C" STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, void** ppv) 
{
    return _AtlModule.DllGetClassObject(rclsid, riid, ppv);
}
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
extern "C" STDAPI DllRegisterServer(void) 
{
    return _AtlModule.DllRegisterServer();
}
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
extern "C" STDAPI DllUnregisterServer(void) 
{
    return _AtlModule.DllUnregisterServer();
}
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
extern "C" STDAPI DllCanUnloadNow(void) 
{
    return _AtlModule.DllCanUnloadNow();
}
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved) 
{
    hInstance;
    return _AtlModule.DllMain(dwReason, lpReserved);
}
#injected_line 7 "c:\\bilaterali\\bil_cryptx\\bil_cryptx.cpp"

#if defined(_M_IX86)
#pragma comment(linker, "/EXPORT:DllMain=_DllMain@12,PRIVATE")
#pragma comment(linker, "/EXPORT:DllRegisterServer=_DllRegisterServer@0,PRIVATE")
#pragma comment(linker, "/EXPORT:DllUnregisterServer=_DllUnregisterServer@0,PRIVATE")
#pragma comment(linker, "/EXPORT:DllGetClassObject=_DllGetClassObject@12,PRIVATE")
#pragma comment(linker, "/EXPORT:DllCanUnloadNow=_DllCanUnloadNow@0,PRIVATE")
#elif defined(_M_IA64)
#pragma comment(linker, "/EXPORT:DllMain,PRIVATE")
#pragma comment(linker, "/EXPORT:DllRegisterServer,PRIVATE")
#pragma comment(linker, "/EXPORT:DllUnregisterServer,PRIVATE")
#pragma comment(linker, "/EXPORT:DllGetClassObject,PRIVATE")
#pragma comment(linker, "/EXPORT:DllCanUnloadNow,PRIVATE")
#endif	

//--- End Injected Code For Attribute 'module'

		 
