

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Mon Jan 02 10:07:19 2006
 */
/* Compiler settings for _Bil_CryptX.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef ___Bil_CryptX_h__
#define ___Bil_CryptX_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IClientSign_FWD_DEFINED__
#define __IClientSign_FWD_DEFINED__
typedef interface IClientSign IClientSign;
#endif 	/* __IClientSign_FWD_DEFINED__ */


#ifndef __CClientSign_FWD_DEFINED__
#define __CClientSign_FWD_DEFINED__

#ifdef __cplusplus
typedef class CClientSign CClientSign;
#else
typedef struct CClientSign CClientSign;
#endif /* __cplusplus */

#endif 	/* __CClientSign_FWD_DEFINED__ */


/* header files for imported files */
#include "prsht.h"
#include "mshtml.h"
#include "mshtmhst.h"
#include "exdisp.h"
#include "objsafe.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __IClientSign_INTERFACE_DEFINED__
#define __IClientSign_INTERFACE_DEFINED__

/* interface IClientSign */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IClientSign;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AD05D448-F5CE-4783-9853-17C8D19759CD")
    IClientSign : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindAvailableCertificate( 
            /* [in] */ VARIANT_BOOL LocalMachine) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CertificateCount( 
            /* [retval][out] */ LONG *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetSubject( 
            /* [in] */ LONG nIndex,
            /* [retval][out] */ BSTR *Subject) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetIssuer( 
            /* [in] */ LONG nIndex,
            /* [retval][out] */ BSTR *Issuer) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SignFile( 
            /* [in] */ BSTR CertificateSubject,
            /* [in] */ BSTR FileName,
            /* [retval][out] */ BSTR *SignedDocument) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SignBuffer( 
            /* [in] */ BSTR certName,
            /* [in] */ BSTR InData,
            /* [retval][out] */ BSTR *OutData) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SignBufferById( 
            /* [in] */ LONG index,
            /* [in] */ BSTR InData,
            /* [retval][out] */ BSTR *OutData) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SignFileById( 
            /* [in] */ LONG index,
            /* [in] */ BSTR FileName,
            /* [retval][out] */ BSTR *OutData) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IClientSignVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IClientSign * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IClientSign * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IClientSign * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IClientSign * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IClientSign * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IClientSign * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IClientSign * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *FindAvailableCertificate )( 
            IClientSign * This,
            /* [in] */ VARIANT_BOOL LocalMachine);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_CertificateCount )( 
            IClientSign * This,
            /* [retval][out] */ LONG *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetSubject )( 
            IClientSign * This,
            /* [in] */ LONG nIndex,
            /* [retval][out] */ BSTR *Subject);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetIssuer )( 
            IClientSign * This,
            /* [in] */ LONG nIndex,
            /* [retval][out] */ BSTR *Issuer);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SignFile )( 
            IClientSign * This,
            /* [in] */ BSTR CertificateSubject,
            /* [in] */ BSTR FileName,
            /* [retval][out] */ BSTR *SignedDocument);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SignBuffer )( 
            IClientSign * This,
            /* [in] */ BSTR certName,
            /* [in] */ BSTR InData,
            /* [retval][out] */ BSTR *OutData);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SignBufferById )( 
            IClientSign * This,
            /* [in] */ LONG index,
            /* [in] */ BSTR InData,
            /* [retval][out] */ BSTR *OutData);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SignFileById )( 
            IClientSign * This,
            /* [in] */ LONG index,
            /* [in] */ BSTR FileName,
            /* [retval][out] */ BSTR *OutData);
        
        END_INTERFACE
    } IClientSignVtbl;

    interface IClientSign
    {
        CONST_VTBL struct IClientSignVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IClientSign_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IClientSign_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IClientSign_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IClientSign_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IClientSign_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IClientSign_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IClientSign_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IClientSign_FindAvailableCertificate(This,LocalMachine)	\
    (This)->lpVtbl -> FindAvailableCertificate(This,LocalMachine)

#define IClientSign_get_CertificateCount(This,pVal)	\
    (This)->lpVtbl -> get_CertificateCount(This,pVal)

#define IClientSign_GetSubject(This,nIndex,Subject)	\
    (This)->lpVtbl -> GetSubject(This,nIndex,Subject)

#define IClientSign_GetIssuer(This,nIndex,Issuer)	\
    (This)->lpVtbl -> GetIssuer(This,nIndex,Issuer)

#define IClientSign_SignFile(This,CertificateSubject,FileName,SignedDocument)	\
    (This)->lpVtbl -> SignFile(This,CertificateSubject,FileName,SignedDocument)

#define IClientSign_SignBuffer(This,certName,InData,OutData)	\
    (This)->lpVtbl -> SignBuffer(This,certName,InData,OutData)

#define IClientSign_SignBufferById(This,index,InData,OutData)	\
    (This)->lpVtbl -> SignBufferById(This,index,InData,OutData)

#define IClientSign_SignFileById(This,index,FileName,OutData)	\
    (This)->lpVtbl -> SignFileById(This,index,FileName,OutData)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IClientSign_FindAvailableCertificate_Proxy( 
    IClientSign * This,
    /* [in] */ VARIANT_BOOL LocalMachine);


void __RPC_STUB IClientSign_FindAvailableCertificate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IClientSign_get_CertificateCount_Proxy( 
    IClientSign * This,
    /* [retval][out] */ LONG *pVal);


void __RPC_STUB IClientSign_get_CertificateCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IClientSign_GetSubject_Proxy( 
    IClientSign * This,
    /* [in] */ LONG nIndex,
    /* [retval][out] */ BSTR *Subject);


void __RPC_STUB IClientSign_GetSubject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IClientSign_GetIssuer_Proxy( 
    IClientSign * This,
    /* [in] */ LONG nIndex,
    /* [retval][out] */ BSTR *Issuer);


void __RPC_STUB IClientSign_GetIssuer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IClientSign_SignFile_Proxy( 
    IClientSign * This,
    /* [in] */ BSTR CertificateSubject,
    /* [in] */ BSTR FileName,
    /* [retval][out] */ BSTR *SignedDocument);


void __RPC_STUB IClientSign_SignFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IClientSign_SignBuffer_Proxy( 
    IClientSign * This,
    /* [in] */ BSTR certName,
    /* [in] */ BSTR InData,
    /* [retval][out] */ BSTR *OutData);


void __RPC_STUB IClientSign_SignBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IClientSign_SignBufferById_Proxy( 
    IClientSign * This,
    /* [in] */ LONG index,
    /* [in] */ BSTR InData,
    /* [retval][out] */ BSTR *OutData);


void __RPC_STUB IClientSign_SignBufferById_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IClientSign_SignFileById_Proxy( 
    IClientSign * This,
    /* [in] */ LONG index,
    /* [in] */ BSTR FileName,
    /* [retval][out] */ BSTR *OutData);


void __RPC_STUB IClientSign_SignFileById_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IClientSign_INTERFACE_DEFINED__ */



#ifndef __Bil_CryptX_LIBRARY_DEFINED__
#define __Bil_CryptX_LIBRARY_DEFINED__

/* library Bil_CryptX */
/* [helpstring][uuid][version] */ 


EXTERN_C const IID LIBID_Bil_CryptX;

EXTERN_C const CLSID CLSID_CClientSign;

#ifdef __cplusplus

class DECLSPEC_UUID("5CF632EC-49E4-4E24-B164-258A76A90284")
CClientSign;
#endif
#endif /* __Bil_CryptX_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


