declare @DataProgrammaMin as smalldatetime
set @dataProgrammaMin = '26/4/04'
declare @DataProgrammaMax as smalldatetime
set @dataProgrammaMax = '27/4/04'

-- @Transitorio = 1 finche` ci saranno programmi bilaterali sbilanciati a sola produzione
-- @Transitorio = 0 quando ci saranno programmi bilanciati con produzione/consumo
declare @Transitorio as int
set @Transitorio = 0




select
POU.DataProgramma,
POU.CodiceOperatoreSDC,
POU.CRN,
POU.CodiceContratto,
POU.CodiceUnitaSDC,
POU.CategoriaUnitaSDC,
POU.PeriodoRilevante,
POU.TipoUnita,
POU.PrezzoUnico,
POU.PrezzoZonale,

-- qui si ha:
-- QtyMGP>0 per P
-- QtyMGP<0 per C
-- QtyMGP>0 per M che producono
-- QtyMGP<0 per M che consumano

case @Transitorio 
	when 1 then case TipoUnita 
	when 'P' then  -1 * QtyMGP * (PrezzoZonale - PrezzoUnico) 
	when 'C' then  -1 * QtyMGP * (PrezzoZonale - PrezzoUnico) 
	when 'M' then  -1 * QtyMGP * (PrezzoZonale - PrezzoUnico) 
	end
else case TipoUnita 
	when 'P' then  -1 * QtyMGP * PrezzoZonale
	when 'C' then  -1 * QtyMGP * PrezzoUnico 
	when 'M' then  -1 * QtyMGP * PrezzoZonale
	end 
end Corr,

QtyMGP Qty


from 
(
select 
ProgrammaOrarioPerUnita.DataProgramma,
Contratto.CodiceOperatoreSDC,
Contratto.CRN,
Contratto.CodiceContratto,
ProgrammaOrarioPerUnita.PeriodoRilevante,
ProgrammaOrarioPerUnita.CodiceUnitaSDC,
ProgrammaOrarioPerUnita.CategoriaUnitaSDC,

ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP * SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita / SDC_Unita.CoefficientePerdita QtyMGP,
SDC_Unita.TipoUnita,
SDC_Unita.CoefficientePerdita KU, 
SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP,
SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,

PrezzoUnitario.Prezzo PrezzoUnico,
PrezzoZonale.Prezzo PrezzoZonale

from 
ProgrammaOrarioPerUnita

inner join Contratto
on Contratto.IdContratto = ProgrammaOrarioPerUnita.IdContratto 

inner join SDC_Unita
on SDC_Unita.CodiceUnitaSDC = ProgrammaOrarioPerUnita.CodiceUnitaSDC
and SDC_Unita.CategoriaUnitaSDC = ProgrammaOrarioPerUnita.CategoriaUnitaSDC

inner join SDC_PuntiDiScambioRilevanti
on SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC = SDC_Unita.CodicePuntoDiScambioRilevanteSDC 

inner join PrezzoUnitario
on PrezzoUnitario.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoUnitario.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante

inner join PrezzoZonale
on PrezzoZonale.Data = ProgrammaOrarioPerUnita.DataProgramma
and PrezzoZonale.PeriodoRilevante = ProgrammaOrarioPerUnita.PeriodoRilevante
and PrezzoZonale.CodiceZonaSDC = SDC_PuntiDiScambioRilevanti.CodiceZonaSDC

where 
not ProgrammaOrarioPerUnita.QtyMWhAssegnataMGP is null
and ProgrammaOrarioPerUnita.DataProgramma >= @DataProgrammaMin
and ProgrammaOrarioPerUnita.DataProgramma <= @DataProgrammaMax
and ProgrammaOrarioPerUnita.IdContratto = Contratto.IdContratto
) POU
order by 
POU.DataProgramma,
POU.CodiceOperatoreSDC,
POU.CRN,
POU.CodiceUnitaSDC,
POU.PeriodoRilevante
COMPUTE SUM(
case @Transitorio 
	when 1 then case TipoUnita 
	when 'P' then  -1 * QtyMGP * (PrezzoZonale - PrezzoUnico) 
	when 'C' then  -1 * QtyMGP * (PrezzoZonale - PrezzoUnico) 
	when 'M' then  -1 * QtyMGP * (PrezzoZonale - PrezzoUnico) 
	end
else case TipoUnita 
	when 'P' then  -1 * QtyMGP * PrezzoZonale
	when 'C' then  -1 * QtyMGP * PrezzoUnico 
	when 'M' then  -1 * QtyMGP * PrezzoZonale
	end 
end
) BY POU.DataProgramma, POU.CodiceOperatoreSDC, POU.CRN




