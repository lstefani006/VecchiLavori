Imports System.IO
Imports ICSharpCode.SharpZipLib.Zip
Public Class BilZipLib
    Public Shared Function UnzipSingleFile(ByVal bz() As Byte, ByRef fileNameout As String) As Byte()
        Dim strmMemIn As MemoryStream = New MemoryStream(bz)
        Dim strmZipIn As ZipInputStream = New ZipInputStream(strmMemIn)
        Dim strmMemOut As New MemoryStream
        Dim objEntry As ZipEntry = strmZipIn.GetNextEntry()

        If Not (objEntry Is Nothing) Then
            fileNameout = objEntry.Name
            Dim i As Integer
            Dim b(4096 - 1) As Byte
            Do
                i = strmZipIn.Read(b, 0, b.Length)
                If (i > 0) Then strmMemOut.Write(b, 0, i)
            Loop While (i > 0)
            strmMemOut.Flush()
			Dim abyUnz() As Byte = strmMemOut.ToArray()
            strmMemOut.Close()
            Return abyUnz
        Else
            Return Nothing
        End If

    End Function
    Public Shared Function ZipSingleFile(ByVal nomefileXML As String, ByVal abyFileToZip() As Byte, ByVal nCompressionLevel As Integer) As Byte()

        Dim strmZipOutFileMem As New System.IO.MemoryStream
        If (True) Then

            Dim strmZipStream As ZipOutputStream = New ZipOutputStream(strmZipOutFileMem)
            Dim myZipEntry As ZipEntry = New ZipEntry(nomefileXML)
            strmZipStream.PutNextEntry(myZipEntry)
            strmZipStream.SetLevel(nCompressionLevel)

            strmZipStream.Write(abyFileToZip, 0, abyFileToZip.Length)
            strmZipStream.CloseEntry()

            strmZipStream.Finish()
            strmZipStream.Flush()

            strmZipStream.Close()
        End If

		Dim bz() As Byte = strmZipOutFileMem.ToArray()
		Return bz

    End Function
End Class
