Imports System.IO
Imports System.Text
Imports System.Collections
Imports System.Collections.Specialized
Imports System.Data.SqlClient
Imports System.Configuration

Public Class QueryBuilder
	Sub New(ByVal s As String)
		Me.s = s
	End Sub

	Public Sub Add(ByVal p As String)
		Me.dbVariables(p) = Nothing
	End Sub

	Public Sub Add(ByVal cmd As SqlCommand)
		Me.cmd = cmd
	End Sub

	Public ReadOnly Property CommandText() As String
		Get
			Dim sql As New StringBuilder

			Dim sr As StreamReader = File.OpenText(Me.s)
			'			Dim onif As Boolean = False
			Dim expr As New Stack
			Do
				Dim r As String = sr.ReadLine()
				If (r Is Nothing) Then Exit Do

				Dim rp As String = r.TrimStart(" "c, "	"c)
				If (rp.StartsWith("#if")) Then
					expr.Push(ParseExpression(rp.Substring("#if".Length + 1)))

				ElseIf (rp.StartsWith("#else")) Then
					' nego l'espressione cosi` entro nell'else
					expr.Push(CType(expr.Pop(), Boolean) = False)

				ElseIf (rp.StartsWith("#elsif")) Then
					expr.Pop()					  ' tolgo l'expr
					expr.Push(ParseExpression(rp.Substring("#elsif".Length + 1)))

				ElseIf (rp.StartsWith("#elseif")) Then
					expr.Pop()					  ' tolgo l'expr
					expr.Push(ParseExpression(rp.Substring("#elseif".Length + 1)))

				ElseIf (rp.StartsWith("#end") OrElse rp.StartsWith("#endif")) Then
					expr.Pop()

				ElseIf (expr.Count = 0 OrElse IfExpr(expr)) Then
					' qui entro 1) se non c'e` un blocco di if o se c'e` con una espressione true
					' o meglio tutti gli if che mi hanno portato qui sono true
					sql.Append(r)
					sql.Append(Environment.NewLine)
				End If
			Loop

			sr.Close()
			Return sql.ToString()
		End Get
	End Property

	Private s As String
	Private dbVariables As New SortedList
	Private cmd As SqlCommand

	Private Function ParseExpression(ByVal e As String) As Boolean
		Dim tks() As String = e.Split(" "c, "	"c)

		For Each tk As String In tks
			If (dbVariables.ContainsKey(tk)) Then Return True
		Next
		If (Not cmd Is Nothing) Then
			For Each tk As String In tks
				For Each p As SqlParameter In cmd.Parameters
					If p.ParameterName = tk Then Return True
				Next
			Next
		End If
		Return False
	End Function

	Private Function IfExpr(ByVal stk As Stack) As Boolean
		For Each b As Boolean In stk
			If b = False Then Return False
		Next
		Return True
	End Function
End Class
