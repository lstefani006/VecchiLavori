Imports System
Imports System.Data.SqlClient
Imports System.Text
Imports System.IO
Imports System.Diagnostics
Imports System.Globalization
Imports System.Configuration
Imports System.Runtime.Remoting
Imports System.Xml
Imports SystemMonitor

' classe base per tutte le classi di businness logic
Public Class BilBLBase
	Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		components = New System.ComponentModel.Container
	End Sub

#End Region


	Public Shared Function AppSettingToBoolean(ByVal s As String) As Boolean
		Return AppSettingToBoolean(s, False)
	End Function
	Public Shared Function AppSettingToBoolean(ByVal s As String, ByVal bDefaultValue As Boolean) As Boolean
		Dim sv As String = ConfigurationSettings.AppSettings(s)
		Dim r As Boolean = bDefaultValue

		If Not sv Is Nothing Then
			sv = sv.ToLower().Trim()
			If sv = "1" OrElse sv = "si" OrElse sv = "yes" OrElse sv = "true" Then
				r = True
			ElseIf sv = "0" OrElse sv = "no" OrElse sv = "false" Then
				r = False
			End If
		End If

		Return r
	End Function

	Public Shared Function AppSettingToDecimal(ByVal s As String, ByVal defaultValue As Decimal) As Decimal
		Dim sv As String = ConfigurationSettings.AppSettings(s)

		If Not sv Is Nothing Then
			Try
				Return Decimal.Parse(sv, CultureInfo.InvariantCulture)
			Catch ex As Exception
				Return defaultValue
			End Try
		End If
		Return defaultValue
	End Function
	Public Shared Function AppSettingToInt32(ByVal s As String, ByVal defaultValue As Int32) As Int32
		Dim sv As String = ConfigurationSettings.AppSettings(s)

		If Not sv Is Nothing Then
			Try
				Return Int32.Parse(sv, CultureInfo.InvariantCulture)
			Catch ex As Exception
				Return defaultValue
			End Try
		End If
		Return defaultValue
	End Function

	Public Shared Function AppSettingToString(ByVal s As String) As String
		Dim sv As String = ConfigurationSettings.AppSettings(s)
		Return sv
	End Function
	Public Shared Function AppSettingToString(ByVal s As String, ByVal sDefaultValue As String) As String
		Dim sv As String = ConfigurationSettings.AppSettings(s)
		If sv Is Nothing OrElse sv = String.Empty Then
			Return sDefaultValue
		Else
			Return sv
		End If
	End Function

	' funzione da chiamare per ottenere la connessione al db
	Public Shared Function GetConnectionString() As String
		Dim s As String = ConfigurationSettings.AppSettings("SqlConnectionString")
		If s Is Nothing Then
			SmLog.smError("La businnes logic e` stata istanziata nel cliente e non nel server.\n" + _
			 "Probabilmente il file app.config del server o il file BL.config del client sono errati")
			Throw New ApplicationException("File di configurazione del Remoting ERRATO!")
		End If
		Return s
	End Function

	Public Shared Function CreateNewId() As String
		Return Guid.NewGuid.ToString("N").ToUpper()
	End Function

	Public Const sAnd As String = " AND "

	Public Shared Sub SetTransaction(ByVal da As SqlDataAdapter, ByVal tr As SqlTransaction)
		If (Not da.SelectCommand Is Nothing) Then da.SelectCommand.Transaction = tr
		If (Not da.InsertCommand Is Nothing) Then da.InsertCommand.Transaction = tr
		If (Not da.DeleteCommand Is Nothing) Then da.DeleteCommand.Transaction = tr
		If (Not da.UpdateCommand Is Nothing) Then da.UpdateCommand.Transaction = tr
	End Sub

	Public Shared Function GetCompleteFileNameFromAppSettings(ByVal key As String) As String
		Dim fileName As String = ConfigurationSettings.AppSettings(key)
		If fileName Is Nothing Then Return Nothing
		Return GetCompleteFileName(fileName)
	End Function

	Public Shared Function GetCompleteFileName(ByVal fileName As String) As String
		Try
			If File.Exists(fileName) Then
				Return fileName
			End If
		Catch
		End Try

		Try
			Dim s As String = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + fileName
			If File.Exists(s) Then
				Return s
			End If
		Catch
		End Try

		Try
			Dim s As String = "c:\" + fileName
			If File.Exists(s) Then
				Return s
			End If
		Catch
		End Try

		Return fileName
	End Function


#Region "Logging methods"
	' Milioni di dichiarazioni per fare logging in remoto dalle pagine .aspx
	Protected Sub smError(ByVal message As String)
		SystemMonitor.SmLog.smError(message)
	End Sub

	Protected Sub smError(ByVal ex As Exception)
		SystemMonitor.SmLog.smError(ex)
	End Sub

	Protected Sub smError(ByVal ex As Exception, ByVal message As String)
		SystemMonitor.SmLog.smError(ex, message)
	End Sub

	Protected Sub smErrorIf(ByVal condition As Boolean, ByVal message As String)
		SystemMonitor.SmLog.smErrorIf(condition, message)
	End Sub

	Protected Sub smErrorIf(ByVal condition As Boolean, ByVal ex As Exception)
		SystemMonitor.SmLog.smErrorIf(condition, ex)
	End Sub

	Protected Sub smErrorIf(ByVal condition As Boolean, ByVal ex As Exception, ByVal message As String)
		SystemMonitor.SmLog.smErrorIf(condition, ex, message)
	End Sub

	Protected Sub smTrace(ByVal message As String)
		SystemMonitor.SmLog.smTrace(message)
	End Sub

	Protected Sub smTrace(ByVal ex As Exception)
		SystemMonitor.SmLog.smTrace(ex)
	End Sub

	Protected Sub smTrace(ByVal ex As Exception, ByVal message As String)
		SystemMonitor.SmLog.smTrace(ex, message)
	End Sub

	Protected Sub smTraceIf(ByVal condition As Boolean, ByVal message As String)
		SystemMonitor.SmLog.smTraceIf(condition, message)
	End Sub

	Protected Sub smTraceIf(ByVal condition As Boolean, ByVal ex As Exception)
		SystemMonitor.SmLog.smTraceIf(condition, ex)
	End Sub

	Protected Sub smTraceIf(ByVal condition As Boolean, ByVal ex As Exception, ByVal message As String)
		SystemMonitor.SmLog.smTraceIf(condition, ex, message)
	End Sub

	Protected Sub smWarning(ByVal message As String)
		smTraceIf(smLogSwitch.TraceWarning, message)
	End Sub

	Protected Sub smTrace(ByVal format As String, ByVal ParamArray args() As Object)
		Dim s As String = String.Format(format, args)
		smTrace(s)
	End Sub
	Protected Sub smWarning(ByVal format As String, ByVal ParamArray args() As Object)
		Dim s As String = String.Format(format, args)
		smTraceIf(smLogSwitch.TraceWarning, s)
	End Sub


	Protected ReadOnly Property smLogSwitch() As System.Diagnostics.TraceSwitch
		Get
			Return SystemMonitor.SmLog.smLogSwitch
		End Get
	End Property
#End Region


	' fantastica funzione che ritorna il numero di ore che vi sono nel giorno passato come parametro
	Public Shared Function GetNumberOfHourOfDay(ByVal dt As DateTime) As Byte
		' l'ora legale capita di Domenica l'ultima di marzo e l'ultima di ottobre

		' 25 26 27 27 29 30 31   <-- marzo e ottobre hanno 31 giorni
		' D  L  M  M  G  V  S
		'    D  L  M  M  G  V
		'       D  L  M  M  G    ecc
		If dt.Day < 25 Then
			Return 24			' dato che siamo prima del 25 non cado nei possibili giorni dell'ora legale
		End If

		Dim m As Integer = dt.Month
		If (Not (m = 3 OrElse m = 10)) Then Return 24 ' non siamo a marzo/ottobre

		' siamo in marzo o in ottobre

		If dt.DayOfWeek <> DayOfWeek.Sunday Then Return 24 ' ma non e` domenica --> 24h

		' e` domenica ed e` l'ultima del mese di marzo o ottobre

		If m = 3 Then Return 23 ' di marzo
		Return 25		  ' di ottobre

	End Function


	Public Shared Function MemorizzaFilePerOperatore( _
	 ByVal cn As SqlConnection, _
	 ByVal tr As SqlTransaction, _
	 ByVal codiceOperatore As String, _
	 ByVal nomeFile As String, _
	 ByVal tipoFile As String, _
	 ByVal descrizioneFile As String, _
	 ByVal contenutoFile() As Byte, _
	 ByVal dataCreazione As DateTime, _
	 ByVal fileEncoding As String, _
	 ByVal dataFlusso As DateTime) As String
		Dim cmd As New SqlCommand

		Dim bPrivateConnection As Boolean = False

		Try
			Dim byz() As Byte = BilZipLib.ZipSingleFile(nomeFile, contenutoFile, 9)

			'#If DEBUG Then
			'			If (True) Then
			'				Dim f As FileStream = New FileStream("c:\tmp\" + nomeFile + ".zip", FileMode.Create)
			'				f.Write(byz, 0, byz.Length)
			'				f.Close()
			'			End If
			'#End If

			If (cn Is Nothing) Then
				tr = Nothing
				cn = New SqlClient.SqlConnection
				cn.ConnectionString = GetConnectionString()
				cn.Open()

				bPrivateConnection = True
			End If

			cmd.Connection = cn
			cmd.Transaction = tr
			cmd.CommandText = "INSERT INTO FileOperatori ("
			cmd.CommandText += "IdFile, CodiceOperatoreSDC, CodiceTipoFile, NomeFile, DescrizioneFile, TSDownload, TSCreazione, ContenutoFile, Zipped, Encoding, TSFlusso"
			cmd.CommandText += ") VALUES ("
			cmd.CommandText += "@IdFile, @CodiceOperatoreSDC, @CodiceTipoFile, @NomeFile, @DescrizioneFile, @TSDownload, @TSCreazione, @ContenutoFile, @Zipped, @Encoding, @TSFlusso)"

			MemorizzaFilePerOperatore = BilBLBase.CreateNewId()

			cmd.Parameters.Add("@IdFile", MemorizzaFilePerOperatore)
			cmd.Parameters.Add("@CodiceOperatoreSDC", codiceOperatore)
			cmd.Parameters.Add("@CodiceTipoFile", tipoFile)
			cmd.Parameters.Add("@NomeFile", nomeFile)			 ' non si mette il .zip in fondo al file!!
			cmd.Parameters.Add("@DescrizioneFile", descrizioneFile)
			cmd.Parameters.Add("@TSDownload", DBNull.Value)
			cmd.Parameters.Add("@TSCreazione", dataCreazione)
			cmd.Parameters.Add("@ContenutoFile", byz)
			cmd.Parameters.Add("@Zipped", True)
			cmd.Parameters.Add("@Encoding", fileEncoding)

			If dataFlusso = DateTime.MaxValue OrElse dataFlusso = DateTime.MinValue Then
				cmd.Parameters.Add("@TSFlusso", DBNull.Value)
			Else
				cmd.Parameters.Add("@TSFlusso", dataFlusso)
			End If

			cmd.ExecuteNonQuery()

		Finally
			If (bPrivateConnection AndAlso cn.State = ConnectionState.Open) Then cn.Close()
		End Try
	End Function

	' funzione che salva il file passato in ingresso.
	Public Shared Sub SaveUploadFile(ByVal prefissoFile As String, ByVal by As Byte())
		Try
			Dim dir As String = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "Import"
			If Not Directory.Exists(dir) Then
				Directory.CreateDirectory(dir)
			End If

			Dim nf As String = String.Format("{0}\{1}_{2:yyyy}{2:MM}{2:dd}{2:HH}{2:mm}{2:ss}.xml", dir, prefissoFile, DateTime.Now)
			Dim f As FileStream = File.Create(nf)
			f.Write(by, 0, by.Length)
			f.Close()
		Catch ex As Exception
		End Try
	End Sub


#Region "Funzioni usate per scrivere i dati nei file xml"

	' funzioni da usare per scrivere i MWh e i prezzi negli XML
	Public Shared Function XmlQtyMWh(ByVal d As Double, ByVal cu As Globalization.NumberFormatInfo) As String
		Return d.ToString("0.000", cu)
	End Function
	Public Shared Function XmlPrezzoZonale(ByVal d As Decimal, ByVal cu As Globalization.NumberFormatInfo) As String
		Return d.ToString("0.000000", cu)
	End Function
	Public Shared Function XmlPrezzoUnico(ByVal d As Decimal, ByVal cu As Globalization.NumberFormatInfo) As String
		Return d.ToString("0.000000", cu)
	End Function
	Public Shared Function XmlEuro(ByVal d As Decimal, ByVal cu As Globalization.NumberFormatInfo) As String
		Return d.ToString("0.00", cu)
	End Function
	Public Shared Function XmlDate(ByVal d As DateTime, ByVal cu As Globalization.DateTimeFormatInfo) As String
		If cu Is Globalization.DateTimeFormatInfo.InvariantInfo Then
			Return XmlConvert.ToString(d, "yyyy-MM-dd")
		Else
			Return d.ToString("yyyyMMdd")
		End If
	End Function
	Public Shared Function XmlDateTime(ByVal d As DateTime, ByVal cu As Globalization.DateTimeFormatInfo) As String
		If cu Is Globalization.DateTimeFormatInfo.InvariantInfo Then
			Return XmlConvert.ToString(d)
		Else
			Return d.ToString("yyyyMMddHHmmss")
		End If
	End Function
	Public Shared Function XmlITA() As Boolean
		Return Not _NumberInfoForXml Is Globalization.NumberFormatInfo.InvariantInfo
	End Function

	' questa sezione si occupa di leggere in quale lingua si devono stampare i dati
	' nel file xml.
	' Esiste naturalmente uno standard (XmlConvert.ToString) ma per 
	' discutibili motivi di compatibilita` con il passato si preferisce 
	' uscire con numeri con la , come separatore tra parte intera e parte decimale
	' date in formato yyyyMMdd ecc.
	' Addio standard e soprattutto addio a tool xsd.exe ecc per la generazione automatica
	' del codice.
	' NB: i nuovi XML dei bilaterali uscivano secondo lo standard w3c
	' poi con l'STR105 si e` fatto 
	Private Shared _NumberInfoForXml As Globalization.NumberFormatInfo = Nothing
	Public Shared ReadOnly Property XmlNumberInfo() As Globalization.NumberFormatInfo
		Get
			If _NumberInfoForXml Is Nothing Then
				Dim sn As String = ConfigurationSettings.AppSettings("XMLCulture")
				If sn Is Nothing OrElse sn = String.Empty Then sn = "InvariantCulture"

				_NumberInfoForXml = Globalization.NumberFormatInfo.InvariantInfo
				Try
					If sn <> "InvariantCulture" Then
						_NumberInfoForXml = New Globalization.CultureInfo(sn, False).NumberFormat
					End If
				Catch ex As Exception
					SmLog.smError(ex)
				End Try

			End If
			Return _NumberInfoForXml
		End Get
	End Property

	Private Shared _DateTimeInfoForXml As Globalization.DateTimeFormatInfo = Nothing
	Public Shared ReadOnly Property XmlDateTimeInfo() As Globalization.DateTimeFormatInfo
		Get
			If _DateTimeInfoForXml Is Nothing Then
				Dim sd As String = ConfigurationSettings.AppSettings("XMLCulture")
				If sd Is Nothing OrElse sd = String.Empty Then sd = "InvariantCulture"

				_DateTimeInfoForXml = Globalization.DateTimeFormatInfo.InvariantInfo
				Try
					If sd <> "InvariantCulture" Then
						_DateTimeInfoForXml = New Globalization.CultureInfo(sd, False).DateTimeFormat
					End If
				Catch ex As Exception
					SmLog.smError(ex)
				End Try
			End If
			Return _DateTimeInfoForXml
		End Get
	End Property


	Private Shared _ITNumberInfoForXml As Globalization.NumberFormatInfo = Nothing
	Public Shared ReadOnly Property XmlITNumberInfo() As Globalization.NumberFormatInfo
		Get
			If _ITNumberInfoForXml Is Nothing Then
				_ITNumberInfoForXml = New Globalization.CultureInfo("IT-it", False).NumberFormat
			End If
			Return _ITNumberInfoForXml
		End Get
	End Property

	Private Shared _ITDateTimeInfoForXml As Globalization.DateTimeFormatInfo = Nothing
	Public Shared ReadOnly Property XmlITDateTimeInfo() As Globalization.DateTimeFormatInfo
		Get
			If _ITDateTimeInfoForXml Is Nothing Then
				_ITDateTimeInfoForXml = New Globalization.CultureInfo("IT-it", False).DateTimeFormat
			End If
			Return _ITDateTimeInfoForXml
		End Get
	End Property


#End Region


	<Serializable()> _
	 Public Class QueryParameter
		Public Sub New()
		End Sub
		Public Sub New(ByVal name As String, ByVal value As Object)
			Me.Name = name
			Me.Value = value
		End Sub

		Public Name As String = Nothing
		Public Value As Object = Nothing
	End Class

End Class

