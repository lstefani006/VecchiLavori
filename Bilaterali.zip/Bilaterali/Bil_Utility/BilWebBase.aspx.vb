Imports System.Collections.Specialized
Imports System.Reflection
Imports System.Diagnostics
Imports System.Globalization
Imports System.IO
Imports System.Text
Imports System.Xml
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Configuration.ConfigurationSettings
Imports System.Threading

Public Class BilWebBase
	Inherits System.Web.UI.Page


#Region " Web Form Designer Generated Code "

	'This call is required by the Web Form Designer.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

	'NOTE: The following placeholder declaration is required by the Web Form Designer.
	'Do not delete or move it.
	Private designerPlaceholderDeclaration As System.Object

    ' 25.02.2004 - Variabile utilizzata dalle pagine per evitare il controllo sulla Session, fa parte
    ' della logica implementata per la Login.
    Protected bCheckSession As Boolean

	Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
		'CODEGEN: This method call is required by the Web Form Designer
		'Do not modify it using the code editor.
        InitializeComponent()

        ' 25.02.2004 - If TRUE checks our session variables, if FALSE skips.
        bCheckSession = True
	End Sub

#End Region

    Protected Overrides Sub OnLoad(ByVal e As EventArgs)
        
        If bCheckSession Then
            ' 25.02.2004 - Controllo se la sessione e` ancora viva: tutte le pagine 
            ' ad esclusione del Login  hanno le seguenti variabili.
            If (Session("IdUtente") Is Nothing OrElse Session("IdOperatore") Is Nothing OrElse Session("IdLingua") Is Nothing OrElse Session("IdRuolo") Is Nothing) Then
                ' Sessione e` scaduta o pagina non chiamata da Login.
                Dim path As String
                ' Begin SCR Id7
                If Page.Request.HttpMethod.ToString = "POST" And Page.Request.Form("__EVENTARGUMENT") = "frmLogin2.aspx" Then
                    ' se ha cliccato Logoff (che manda alla frmLogin2.aspx) ... ce lo mando direttamente
                    path = "~/Login/frmLogin2.aspx"
                Else
                    ' End SCR Id7
                    path = "~/Login/SessioneScaduta.aspx"
                End If
                'Server.Transfer(path)
                Response.Redirect(path)
                Return
            End If
            ' 23.03.2004
            Session("LastUpdate") = DateTime.Now
        End If


        ' se sono in postback leggo le variabili dalla sessione e valorizzo
        ' le variabili membro della classe 
        '
        ' se non sono in postback cancello le variabili di sessione che sono
        ' state utilizzate dalla pagina precedente
        Me.PageStateLoad()

        MyBase.OnLoad(e)
	End Sub



	Protected Overrides Sub OnUnload(ByVal e As EventArgs)
		' sto per abbondonare la pagina;
		' salvo le variabili membro della classe nella sessione.
		Me.PageStateSave()

		MyBase.OnUnload(e)
	End Sub

	Private Sub PageStateLoad()
		' per prima cosa mi carico i dati della reflection
		Me.GetStateFields()

		If Not IsPostBack Then

			' devo cancellare le variabili di sessione della pagina "chiamante"
			' variabili da cancellare iniziano per "pageData"
			Dim sk As New StringCollection

			' cerco nella sessione un var che inizia per "pageData"
			' quando la trovo la memorizzo in sk
			For Each s As String In Session
				If s.StartsWith("pageData") Then
					sk.Add(s)
				End If
			Next

			' rimuovo le variabili trovate dalla sessione
			For Each s As String In sk
				Session.Remove(s)
			Next
		Else
			' sono in una postback.
			' devo associare le variabili di sessione alle variaibli di pagina marcate con l'attributo PageStateAttribute
			' questo codice utilizza l'array _StateField che viene inizializzata con Me.GetStateFields()
			' trovo tutti i membri della classe (cosi` trovo anche le var membro della classe derivata)
			For Each f As FieldInfo In _StateField
				Me.LoadFieldFromSession(f)
			Next
		End If
	End Sub

	Private Sub PageStateSave()
		' sto per abbandonare la pagina... devo salvare i dati della sessione

		' invoco come in PageStateLoad la reflection per ottenere il valore
		' delle variabili marcate con l'attributo PageStateAttribute.
		' Ottenuto il valore lo associo alla sessione
		If Not (_StateField Is Nothing) Then
			For Each f As FieldInfo In _StateField
				Me.SaveFieldIntoSession(f)
			Next
		End If
	End Sub

	' metodo per caricare dalla sessione una variabile membro di una classe
	' E' possibile customizzare il caricamento della variabile ridefiendo il metodo.
	Protected Overridable Sub LoadFieldFromSession(ByVal f As FieldInfo)
		' il DataSet ha un trattamento speciale...
		Dim bIsDataSet As Boolean = False
		Try
            Dim o As Object = f.GetValue(Me)
            If (TypeOf o Is DataSet) Then
                If Not (DirectCast(o, DataSet) Is Nothing) Then
                    bIsDataSet = True
                End If
            End If
        Catch ex As Exception
		End Try

		If bIsDataSet = False Then
			' non e' un DataSet
			' ottengo il dato dalla sessione e lo associo alla variabile
			Dim o As Object = GetPageData(f.Name)
			f.SetValue(Me, o)
		Else
			' e' un DataSet
			Dim ds As DataSet = CType(f.GetValue(Me), DataSet)
            ds.Clear()
            Dim o As Object = GetPageData(f.Name)
            'ds.Merge(CType(GetPageData(f.Name), DataSet), True)
            If Not o Is Nothing Then
                ds.Merge(CType(o, DataSet), True)
            End If
        End If
	End Sub

	' metodo per salvare una variabile membro nella sessione;
	' e` possibile ridefinire il metodo per customizzare il salvataggio
	' di una variabile
	Protected Overridable Sub SaveFieldIntoSession(ByVal f As FieldInfo)
		Dim v As Object = f.GetValue(Me)
		SetPageData(f.Name, v)
	End Sub

    Private Function GetPageData(ByVal v As String) As Object
        If Session("pageData_" & v) Is Nothing Then
            Dim o As Object = Nothing
            Return o
        End If
        Return Session("pageData_" & v)
    End Function

    Private Sub SetPageData(ByVal v As String, ByVal o As Object)
        Session("pageData_" & v) = o
    End Sub

    ' array che contiene le descrizioni delle variabili che devono essere
    ' salvate nella sessione
    Private _StateField As ArrayList = Nothing

    Private Sub GetStateFields()
        If _StateField Is Nothing Then
            _StateField = New ArrayList
            ' uso la reflection per trovare le variabili membro marcate con <PageStateAttribute()> 
            ' delle(classi) derivate
            Dim ma() As MemberInfo = Me.GetType().GetMembers(BindingFlags.Instance Or BindingFlags.Public Or BindingFlags.NonPublic)
            For Each m As MemberInfo In ma
                If m.GetCustomAttributes(GetType(PageStateAttribute), True).Length > 0 Then
                    If Not (DirectCast(m, FieldInfo) Is Nothing) Then
                        Dim f As FieldInfo = CType(m, FieldInfo)
                        _StateField.Add(f)
                    End If
                End If
            Next
        End If
    End Sub

    Protected Overridable Sub AddPageStateFields(ByVal ar As ArrayList)

    End Sub

#Region "Logging methods"

	Private Function msg(ByVal str As String) As String
		Dim s As New StringBuilder

		If Not Session("IdUtente") Is Nothing Then
			s.AppendFormat("Utente={0} ", DirectCast(Session("IdUtente"), String))
		End If

		If Not Session("IdOperatore") Is Nothing Then
			s.AppendFormat("Operatore={0} ", DirectCast(Session("IdOperatore"), String))
		End If

		If Not str Is Nothing Then
			s.Append(str)
		End If

		Return s.ToString()
	End Function

	' Milioni di dichiarazioni per fare logging in remoto dalle pagine .aspx
	Protected Sub smError(ByVal message As String)
		SystemMonitor.SmLog.smError(msg(message))
	End Sub

	Protected Sub smError(ByVal ex As Exception)
		SystemMonitor.SmLog.smError(ex, msg(Nothing))
	End Sub

	Protected Sub smError(ByVal ex As Exception, ByVal message As String)
		SystemMonitor.SmLog.smError(ex, msg(message))
	End Sub

	Protected Sub smErrorIf(ByVal condition As Boolean, ByVal message As String)
		SystemMonitor.SmLog.smErrorIf(condition, msg(message))
	End Sub

	Protected Sub smErrorIf(ByVal condition As Boolean, ByVal ex As Exception)
		SystemMonitor.SmLog.smErrorIf(condition, ex, msg(Nothing))
	End Sub

	Protected Sub smErrorIf(ByVal condition As Boolean, ByVal ex As Exception, ByVal message As String)
		SystemMonitor.SmLog.smErrorIf(condition, ex, msg(message))
	End Sub

	Protected Sub smTrace(ByVal message As String)
		SystemMonitor.SmLog.smTrace(msg(message))
	End Sub

	Protected Sub smTrace(ByVal ex As Exception)
		SystemMonitor.SmLog.smTrace(ex, msg(Nothing))
	End Sub

	Protected Sub smTrace(ByVal ex As Exception, ByVal message As String)
		SystemMonitor.SmLog.smTrace(ex, msg(message))
	End Sub

	Protected Sub smTraceIf(ByVal condition As Boolean, ByVal message As String)
		SystemMonitor.SmLog.smTraceIf(condition, msg(message))
	End Sub

	Protected Sub smTraceIf(ByVal condition As Boolean, ByVal ex As Exception)
		SystemMonitor.SmLog.smTraceIf(condition, ex, msg(Nothing))
	End Sub

	Protected Sub smTraceIf(ByVal condition As Boolean, ByVal ex As Exception, ByVal message As String)
		SystemMonitor.SmLog.smTraceIf(condition, ex, msg(message))
	End Sub

	Protected ReadOnly Property smLogSwitch() As System.Diagnostics.TraceSwitch
		Get
			Return SystemMonitor.SmLog.smLogSwitch
		End Get
	End Property
#End Region

	Public ReadOnly Property CallingStack() As ArrayList
		Get
			Dim o As Object = Session("CallingPage")
			If (Not o Is Nothing) Then
				Return DirectCast(o, ArrayList)
			Else
				Dim sc As New ArrayList
				Session("CallingPage") = sc
				Return sc
			End If
		End Get
	End Property

	Public ReadOnly Property IsReturnToCallerAvailable() As Boolean
		Get
			Return CallingStack.Count > 0
		End Get
	End Property

	Public Sub CallPage(ByVal callingPage As String, ByVal page As String)
		CallingStack.Add(callingPage)
		Server.Transfer(page, False)
	End Sub

	Public Sub ReturnToCaller()
		If (IsReturnToCallerAvailable) Then
			Dim sc As ArrayList = CallingStack
			Dim r As String = DirectCast(sc(sc.Count - 1), String)
			sc.RemoveAt(sc.Count - 1)
			Server.Transfer(r, False)
		End If
	End Sub

	Private Function IsSameType(ByVal o As Object, ByVal tq As Type) As Boolean
		If (o Is Nothing) Then Return False
		Dim tp As Type = o.GetType()
		If (tp Is tq) Then Return True
		Return tp.IsSubclassOf(tq)
	End Function

	Protected queryControls As New ArrayList
	Protected Function GetReloadQueryString() As String
		Dim s As New StringBuilder

		For Each c As System.Web.UI.Control In queryControls
			Dim value As String
			If (IsSameType(c, GetType(System.Web.UI.WebControls.TextBox))) Then
				value = DirectCast(c, System.Web.UI.WebControls.TextBox).Text
			ElseIf (IsSameType(c, GetType(System.Web.UI.WebControls.CheckBox))) Then
				value = DirectCast(c, System.Web.UI.WebControls.CheckBox).Checked.ToString()
			ElseIf (IsSameType(c, GetType(System.Web.UI.WebControls.DropDownList))) Then
				value = DirectCast(c, System.Web.UI.WebControls.DropDownList).SelectedIndex.ToString()
			ElseIf (IsSameType(c, GetType(System.Web.UI.WebControls.ListBox))) Then
				value = DirectCast(c, System.Web.UI.WebControls.ListBox).SelectedIndex.ToString()
			Else
				System.Diagnostics.Debug.Assert(False)
			End If

			If (Not value Is Nothing AndAlso value <> "") Then
				s.Append(c.ID)
				s.Append("=")
				s.Append(Server.UrlEncode(value))
				s.Append("&")
			End If
		Next
		Return s.ToString()
	End Function

	Protected Function ReadQueryString() As Boolean
		For Each c As System.Web.UI.Control In queryControls
			Dim value As String = Request(c.ID)
			If Not value Is Nothing Then
				If (IsSameType(c, GetType(System.Web.UI.WebControls.TextBox))) Then
					DirectCast(c, System.Web.UI.WebControls.TextBox).Text = value
				ElseIf (IsSameType(c, GetType(System.Web.UI.WebControls.CheckBox))) Then
					DirectCast(c, System.Web.UI.WebControls.CheckBox).Checked = Boolean.Parse(value)
				ElseIf (IsSameType(c, GetType(System.Web.UI.WebControls.DropDownList))) Then
					DirectCast(c, System.Web.UI.WebControls.DropDownList).SelectedIndex = Integer.Parse(value)
				ElseIf (IsSameType(c, GetType(System.Web.UI.WebControls.ListBox))) Then
					DirectCast(c, System.Web.UI.WebControls.ListBox).SelectedIndex = Integer.Parse(value)
				Else
					System.Diagnostics.Debug.Assert(False)
				End If
			End If
		Next

		Dim r As String = Request("Ricerca")
		If (Not r Is Nothing AndAlso r = "1") Then Return True
		Return False
	End Function

	Protected Sub SelectRowInDataGrid(ByVal dg As DataGrid, ByVal key As String)
		If (key Is Nothing) Then Return
		For Each s As DataGridItem In dg.Items
			If (dg.DataKeys(s.ItemIndex).ToString() = key) Then dg.SelectedIndex = s.ItemIndex
		Next
	End Sub


	Public Shared Function GetDateCancelletto(ByVal d As Date) As String
		Return String.Format("#{0:MM}/{0:dd}/{0:yyyy}#", d)
	End Function


#Region "Libreria per gestire le dg senza viewstate o con viewstate"
	' da chiamare nel Page_Load sezione IsPostBack
	Protected Sub DataGrid_RestoreState(ByVal dg As DataGrid, ByVal dv As DataView)

		dg.DataSource = dv
		dv.Sort = ViewState(dg.UniqueID + ".Sort").ToString()
		dv.RowFilter = ViewState(dg.UniqueID + ".RowFilter").ToString()
		dg.SelectedIndex = Integer.Parse(ViewState(dg.UniqueID + ".SelectedIndex").ToString())

		If dg.EnableViewState = False Then



			If dg.AllowPaging Then
				dg.CurrentPageIndex = Integer.Parse(viewState(dg.UniqueID + ".CurrentPageIndex").ToString())
			End If

			dg.DataBind()
		End If
	End Sub

	' da chiamare per riempire la DG
	Protected Sub DataGrid_Bind(ByVal dg As DataGrid, ByVal dv As DataView)
		dg.DataSource = dv
		dg.DataBind()

		ViewState(dg.UniqueID + ".Sort") = dv.Sort
		ViewState(dg.UniqueID + ".RowFilter") = dv.RowFilter
		ViewState(dg.UniqueID + ".SelectedIndex") = dg.SelectedIndex.ToString()



		If dg.EnableViewState = False Then
			If dg.AllowPaging Then
				ViewState(dg.UniqueID + ".CurrentPageIndex") = dg.CurrentPageIndex.ToString()
			End If

		End If








	End Sub











	Protected Sub DataGrid_Sort(ByVal dg As DataGrid, ByVal dv As DataView, ByVal eSortExpression As String)
		dg.SelectedIndex = -1		  ' tolgo la selezione quando fa sort

		If dv.Sort = eSortExpression Then
			eSortExpression += " DESC"
		End If

		dv.Sort = eSortExpression
	End Sub

	Protected Sub DataGrid_SetRowFilter(ByVal dg As DataGrid, ByVal dv As DataView, ByVal rowFilter As String)
		dv.RowFilter = rowFilter
		ViewState(dg.UniqueID + ".RowFilter") = dv.RowFilter
	End Sub

	Protected Sub DataGrid_PageIndexChanged(ByVal dg As DataGrid, ByVal eNewPageIndex As Integer)
		dg.CurrentPageIndex = eNewPageIndex
	End Sub

	Protected Sub DataGrid_SelectedIndexChanged(ByVal dg As DataGrid)
		Dim oldSelection As Integer = Integer.Parse(ViewState(dg.UniqueID + ".SelectedIndex").ToString())
		If dg.SelectedIndex = oldSelection Then dg.SelectedIndex = -1
	End Sub

	Protected Sub DataGrid_PopulateKey(ByVal dg As DataGrid, ByVal dsTable As DataTable, ByVal pks() As String)
		If Not dsTable.Columns.Contains("pk_id") Then
			Dim cl As DataColumn = New DataColumn("pk_id", GetType(String))
			cl.AllowDBNull = True
			cl.DefaultValue = ""
			dsTable.Columns.Add(cl)
		End If

		If dg.DataKeyField <> "pk_id" Then dg.DataKeyField = "pk_id"

		For Each dr As DataRow In dsTable.Rows

			Dim xd As New XmlDocument
			xd.LoadXml("<pk_id></pk_id>")
			For Each c As String In pks
				Dim pk As XmlElement = xd.CreateElement(c)
				pk.InnerText = dr(c).ToString
				xd.DocumentElement.AppendChild(pk)
			Next

			dr("pk_id") = xd.OuterXml
		Next

		dsTable.AcceptChanges()

	End Sub

	Protected Function DataGrid_GetKey(ByVal dg As DataGrid, ByVal eItemIndex As Integer, ByVal pk As String) As String
		Dim pk_id As String = dg.DataKeys(eItemIndex).ToString
		Dim xd As New XmlDocument
		xd.LoadXml(pk_id)
		Return xd.SelectSingleNode("/pk_id/" + pk).InnerText
	End Function

	Protected Function DataGrid_GetKey(ByVal dg As DataGrid, ByVal dgi As DataGridItem, ByVal pk As String) As String
		Return DataGrid_GetKey(dg, dgi.ItemIndex, pk)
	End Function
#End Region

	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

	Protected Sub DataGridNoViewState_Init(ByVal dg As DataGrid, ByVal dv As DataView, ByVal sort As String, ByVal rowFilter As String)

		dg.DataSource = dv

		dv.Sort = sort
		dv.RowFilter = rowFilter
		dg.SelectedIndex = -1
		dg.EditItemIndex = -1

		If dg.AllowPaging Then
			dg.CurrentPageIndex = 0
		End If


		ViewState(dg.UniqueID + ".Sort") = dv.Sort
		ViewState(dg.UniqueID + ".RowFilter") = dv.RowFilter
		ViewState(dg.UniqueID + ".SelectedIndex") = "-1"
		ViewState(dg.UniqueID + ".EditItemIndex") = "-1"

		If dg.AllowPaging Then
			ViewState(dg.UniqueID + ".CurrentPageIndex") = dg.CurrentPageIndex.ToString()
		End If

	End Sub

	' da chiamare nel Page_Load sezione IsPostBack
	Protected Sub DataGridNoViewState_RestoreState(ByVal dg As DataGrid, ByVal dv As DataView)

		dg.DataSource = dv

		dv.Sort = ViewState(dg.UniqueID + ".Sort").ToString()
		dv.RowFilter = ViewState(dg.UniqueID + ".RowFilter").ToString()
		dg.SelectedIndex = Integer.Parse(ViewState(dg.UniqueID + ".SelectedIndex").ToString())
		dg.EditItemIndex = Integer.Parse(ViewState(dg.UniqueID + ".EditItemIndex").ToString())

		If dg.AllowPaging Then
			dg.CurrentPageIndex = Integer.Parse(viewState(dg.UniqueID + ".CurrentPageIndex").ToString())
		End If

		dg.DataBind()
	End Sub

	' da chiamare per riempire la DG
	Protected Sub DataGridNoViewState_Bind(ByVal dg As DataGrid, ByVal dv As DataView)
		dg.DataSource = dv

		ViewState(dg.UniqueID + ".Sort") = dv.Sort
		ViewState(dg.UniqueID + ".RowFilter") = dv.RowFilter
		ViewState(dg.UniqueID + ".SelectedIndex") = dg.SelectedIndex.ToString()
		ViewState(dg.UniqueID + ".EditItemIndex") = dg.EditItemIndex.ToString()

		If dg.AllowPaging Then
			ViewState(dg.UniqueID + ".CurrentPageIndex") = dg.CurrentPageIndex.ToString()
		End If

		dg.DataBind()
	End Sub

	Protected Sub DataGridNoViewState_PreRender(ByVal dg As DataGrid, ByVal dv As DataView)

		ViewState(dg.UniqueID + ".Sort") = dv.Sort
		ViewState(dg.UniqueID + ".RowFilter") = dv.RowFilter
		ViewState(dg.UniqueID + ".SelectedIndex") = dg.SelectedIndex.ToString()
		ViewState(dg.UniqueID + ".EditItemIndex") = dg.EditItemIndex.ToString()

		If dg.AllowPaging Then
			ViewState(dg.UniqueID + ".CurrentPageIndex") = dg.CurrentPageIndex.ToString()
		End If

	End Sub


	Protected Sub DataGridNoViewState_SetRowFilter(ByVal dg As DataGrid, ByVal dv As DataView, ByVal rowFilter As String)
		dg.EditItemIndex = -1
		dg.SelectedIndex = -1
		If dg.AllowPaging Then
			dg.CurrentPageIndex = 0
		End If

		dv.RowFilter = rowFilter
	End Sub


	Protected Sub DataGridNoViewState_ResetPageIndex(ByVal dg As DataGrid)
		dg.SelectedIndex = -1		  ' tolgo la selezione quando fa sort
		dg.EditItemIndex = -1
		dg.CurrentPageIndex = 0
	End Sub

	Protected Sub DataGridNoViewState_ResetCurrentSelection(ByVal dg As DataGrid)
		dg.SelectedIndex = -1
	End Sub

	Protected Sub DataGridNoViewState_ResetEditItemIndex(ByVal dg As DataGrid)
		dg.EditItemIndex = -1
	End Sub

	Protected Sub DataGridNoViewState_Sort(ByVal dg As DataGrid, ByVal dv As DataView, ByVal eSortExpression As String)
		dg.SelectedIndex = -1		  ' tolgo la selezione quando fa sort
		dg.EditItemIndex = -1

		If dg.AllowPaging Then
			dg.CurrentPageIndex = 0
		End If

		If dv.Sort = eSortExpression Then
			eSortExpression += " DESC"
		End If

		dv.Sort = eSortExpression

	End Sub


	Protected Sub DataGridNoViewState_PageIndexChanged(ByVal dg As DataGrid, ByVal eNewPageIndex As Integer)
		dg.EditItemIndex = -1
		dg.SelectedIndex = -1

		dg.CurrentPageIndex = eNewPageIndex
	End Sub

	Protected Sub DataGridNoViewState_SelectedIndexChanged(ByVal dg As DataGrid)
		dg.EditItemIndex = -1
		Dim oldSelection As Integer = Integer.Parse(ViewState(dg.UniqueID + ".SelectedIndex").ToString())
		If dg.SelectedIndex = oldSelection Then dg.SelectedIndex = -1
	End Sub


	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Public ReadOnly Property UtenteOperatore() As String
		Get
			Dim u As Object = Session("IdUtente")
			Dim o As Object = Session("IdOperatore")

			If u Is Nothing Then
				u = String.Empty
			End If
			If o Is Nothing Then
				o = String.Empty
			End If

			Return u.ToString + "/" + o.ToString

		End Get
	End Property


	Protected Overridable Function UseServerViewState() As Boolean
		Return True
	End Function


	Private Const ViewStateHiddenFieldName As String = "__VSLS"


	Protected Overloads Overrides Sub SavePageStateToPersistenceMedium(ByVal viewState As Object)

		If Not UseServerViewState() Then
			MyBase.SavePageStateToPersistenceMedium(viewState)
			Return
		End If

		Dim ViewStatePath As String = CType(Session("ViewStatePath"), String)
		If ViewStatePath Is Nothing OrElse ViewStatePath.Length = 0 Then
			Return
		End If
		Dim idViewState As String = DateTime.Now.ToString("yyMMddHHmmssfffffff")
		Page.RegisterHiddenField(ViewStateHiddenFieldName, idViewState)
		Dim ViewStateFile As String = ViewStatePath + "\" + idViewState + ".vs"
		Dim los As LosFormatter = New LosFormatter
		Dim sw As StreamWriter
		Try
			If Not Directory.Exists(ViewStatePath) Then
				Directory.CreateDirectory(ViewStatePath)
			End If
			sw = File.CreateText(ViewStateFile)
			los.Serialize(sw, viewState)
		Finally
			If Not sw Is Nothing Then sw.Close()
		End Try
	End Sub


	Public Shared Sub CreateEmptyViewStateFile(ByVal pg As Page)
		Try
			Dim ViewStatePath As String = CType(pg.Session("ViewStatePath"), String)
			If ViewStatePath Is Nothing OrElse ViewStatePath.Length = 0 Then
				Return
			End If

			Dim idViewState As String = DateTime.Now.ToString("yyMMddHHmmssfffffff")
			Dim ViewStateFile As String = ViewStatePath + "\" + idViewState + ".vs"
			Dim sw As StreamWriter
			Try
				sw = File.CreateText(ViewStateFile)
			Finally
				If Not sw Is Nothing Then sw.Close()
			End Try
		Catch
		End Try
	End Sub

	Protected Overloads Overrides Function LoadPageStateFromPersistenceMedium() As Object

		If Not UseServerViewState() Then
			Return MyBase.LoadPageStateFromPersistenceMedium()
		End If


		Dim idViewState As String = Request.Form(ViewStateHiddenFieldName)
		If idViewState Is Nothing OrElse idViewState.Length = 0 Then
			Return Nothing
		End If
		Dim ViewStatePath As String = CType(Session("ViewStatePath"), String)
		If ViewStatePath Is Nothing OrElse ViewStatePath.Length = 0 Then
			Return Nothing
		End If
		If Not Directory.Exists(ViewStatePath) Then
			Throw New HttpException(3, "ViewState directory mancante.")
		End If

		Dim ViewStateFile As String = ViewStatePath + "\" + idViewState + ".vs"
		If Not File.Exists(ViewStateFile) Then
			' Throw New HttpException(3, "ViewState file mancante.")
			Return Nothing
		End If

		Try
			Dim sr As StreamReader
			Try
				sr = File.OpenText(ViewStateFile)
				Dim los As LosFormatter = New LosFormatter
				Try
					Return los.Deserialize(sr)
				Catch ex As Exception
					Throw New HttpException(3, "ViewState corrotto.", ex)
				End Try
			Finally
				If Not sr Is Nothing Then sr.Close()
			End Try
		Catch ex As Exception
			Throw New HttpException(3, "ViewState non disponibile.", ex)
		End Try
	End Function

End Class

Public Class ViewStateCleaner
	Private ReadOnly _ViewStateRootPath As String
	Private ReadOnly _ViewStateCleanPeriod As Integer
	Private ReadOnly _SessionTimeout As Integer
	Private ReadOnly _ViewStateFileTimeout As Integer

	Public Sub New(ByVal viewStateRootPath As String, ByVal viewStateCleanPeriod As Integer, ByVal sessionTimeout As Integer, ByVal viewStateFileTimeout As Integer)
		_ViewStateRootPath = viewStateRootPath
		_ViewStateCleanPeriod = viewStateCleanPeriod
		_SessionTimeout = sessionTimeout
		_ViewStateFileTimeout = ViewStateFileTimeout
	End Sub

	Private Shared _vsc As ViewStateCleaner
	Private Shared _th As Thread

	Public Shared Sub Start(ByVal path As String, ByVal viewStateCleanPeriod As Integer, ByVal sessionTimeout As Integer, ByVal viewStateFileTimeout As Integer)
		_vsc = New Bil.ViewStateCleaner(path, viewStateCleanPeriod, sessionTimeout, viewStateFileTimeout)
		_th = New Thread(New ThreadStart(AddressOf _vsc.DoWork))
		_th.IsBackground = True
		_th.Start()
	End Sub


	Public Sub DoWork()
		While True
			Try
				Dim tsNow As DateTime = DateTime.Now

				Dim dirList As String() = Directory.GetDirectories(_ViewStateRootPath)
				For Each ViewStateDir As String In dirList

					Dim fileList As String() = Directory.GetFiles(ViewStateDir, "*.vs")
					Dim fileListSorted As ArrayList = New ArrayList(fileList.Length)
					For Each fn As String In fileList
						fileListSorted.Add(Path.GetFileNameWithoutExtension(fn))
					Next
                    fileListSorted.Sort()

                    Dim done As Boolean = False

                    If fileListSorted.Count >= 1 Then
                        ' Sessioni orfane.
                        ' prendo il file piu` recente e controllo se e` abbastanza vecchio
                        ' per poter asserire che la sessione e` scaduta
                        Dim lastFileName As String = CType(fileListSorted(fileListSorted.Count - 1), String)
                        Dim fileDate As DateTime = GetFileTime(lastFileName)
                        Dim ts As TimeSpan = tsNow.Subtract(fileDate)
						If ts.TotalMinutes > _SessionTimeout Then
							Directory.Delete(ViewStateDir, True)
							done = True
						End If

					End If

                    If Not done Then
                        ' Sessioni aperte. Per evitare l'accumulo di tanti file
                        ' cancello quelli molto vecchi che probabilmente non saranno usati
                        Dim deleted As Integer = 0
                        For Each fileName As String In fileListSorted
                            Dim fileDate As DateTime = GetFileTime(fileName)
                            Dim ts As TimeSpan = tsNow.Subtract(fileDate)
							If ts.TotalMinutes > _ViewStateFileTimeout Then
								File.Delete(ViewStateDir + "\" + fileName + ".vs")
								deleted += 1
							Else
								Exit For
							End If
						Next
                        If deleted > 0 AndAlso deleted = fileListSorted.Count Then
							Directory.Delete(ViewStateDir, False)

						ElseIf deleted = 0 AndAlso fileListSorted.Count = 0 Then
							Dim dirDate As DateTime = Directory.GetCreationTime(ViewStateDir)
							Dim ts As TimeSpan = tsNow.Subtract(dirDate)
							If ts.TotalMinutes > _ViewStateFileTimeout Then
								Directory.Delete(ViewStateDir, False)
							End If
						End If

					End If
                Next
            Catch ex As Exception
				Dim gg As String = ex.Message
				gg = gg.ToUpper
			End Try
			Thread.Sleep(1000 * 60 * _ViewStateCleanPeriod)
		End While
	End Sub

	Private Shared Function GetFileTime(ByVal fileName As String) As DateTime
		Dim yy As Integer = Integer.Parse(fileName.Substring(0, 2))
		Dim Mesi As Integer = Integer.Parse(fileName.Substring(2, 2))
		Dim dd As Integer = Integer.Parse(fileName.Substring(4, 2))
		Dim HH As Integer = Integer.Parse(fileName.Substring(6, 2))
		Dim mm As Integer = Integer.Parse(fileName.Substring(8, 2))
		Dim ss As Integer = Integer.Parse(fileName.Substring(10, 2))
		Dim fileDate As DateTime = New DateTime(2000 + yy, Mesi, dd, HH, mm, ss)
		Return fileDate
	End Function


End Class


<AttributeUsage(AttributeTargets.Field)> _
Public Class PageStateAttribute
	Inherits System.Attribute
End Class