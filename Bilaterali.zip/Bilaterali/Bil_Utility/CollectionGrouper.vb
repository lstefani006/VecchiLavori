Imports System
Imports System.Collections

Public MustInherit Class CollectionGrouper
	Implements IComparer

	Protected _ar As ArrayList
	Protected _i As Integer
	Private _doSort As Boolean = True

	Public Sub New(ByVal ar As ArrayList)
		Me._ar = ar
	End Sub

	Public Sub Sort()
		Me._ar.Sort(Me)
		_doSort = False
	End Sub

	'Public Property Sort() As Boolean
	'	Get
	'		Return _doSort
	'	End Get
	'	Set(ByVal Value As Boolean)
	'		_doSort = Value
	'	End Set
	'End Property

	Public MustOverride Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
	Public MustOverride Function CheckBreak(ByVal prev_item As Object, ByVal current_item As Object) As Boolean
	Public MustOverride Sub OnStartLoop()
	Public MustOverride Sub OnFirstItem(ByVal item As Object)
	Public MustOverride Sub OnItem(ByVal item As Object)
	Public MustOverride Sub OnLastItem(ByVal item As Object)
	Public MustOverride Sub OnEndLoop()


	Public Sub DoLoop()
		If Me._doSort Then
			Me._ar.Sort(Me)			'dato che questa classe e` un Comparer --> sorto con Compare
		End If

		OnStartLoop()

		Dim prev_item As Object = Nothing

		For Me._i = 0 To _ar.Count - 1
			Dim current_item As Object = _ar(Me._i)

			If (Not prev_item Is Nothing AndAlso CheckBreak(prev_item, current_item)) Then
				OnLastItem(prev_item)
				OnFirstItem(current_item)
			ElseIf (prev_item Is Nothing) Then
				OnFirstItem(current_item)
			End If

			OnItem(current_item)

			prev_item = current_item
		Next

		If (Not prev_item Is Nothing) Then
			OnLastItem(prev_item)
		End If

		OnEndLoop()
	End Sub

End Class
