declare @DataProgramma as smalldatetime
set @DataProgramma = '20/4/04'

-- codice per capire quante ore fa il giorno in ingresso: 23/24/25
declare @NextDateMonth as integer
declare @Ore as integer
set @NextDateMonth= DATEPART(month,@DataProgramma + 7)
set @Ore = 24
if (month(@DataProgramma) = 3  and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 4)
	set @Ore = 23
if (month(@DataProgramma) = 10 and DATEPART(weekday,@DataProgramma) = 8-@@datefirst and @NextDateMonth = 11)
	set @Ore = 25


-- questa semplice select
-- ritorna per PeriodoRilevante/Contratto/Zona la somma dell'energia delle unita` (applicando i coeff. di perdita)
-- di tipo C P ed M.
-- Inoltra ritorna 
-- Il codice del titolare (resp. partite economiche del contratto)
-- Il/i prezzi unico/zonali
-- Il periodo rilevante
-- l'IdContratto che si trova in PO.
--
-- Performance: agisce nell'ordine corretto aggregando solo alla fine e tramite indice
-- le tabelle PO e POU... meglio di cosi` non si puo`.
--

select
Z.CRN,                        -- varia per contratto
Z.CodiceOperatoreSDCTitolare, -- varia per contratto
Z.PeriodoRilevante,           -- varia per contratto/periodo rilevante
Z.CodiceZonaSDC,              -- varia per contratto/periodo rilevante/zona
Z.POIdContratto,              -- non varia per Contratto/Data/PR/Zona/TipoUnita --> posso usarla nel group by
Z.ProgrammaOrarioValidato,    -- come sopra
Z.PrezzoZonale,               -- varia per zona/periodo rilevante
Z.PrezzoUnico,                -- varia per periodo rilevante

sum(case Z.TipoUnita when 'P' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyP,
sum(case Z.TipoUnita when 'C' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyC,
sum(case Z.TipoUnita when 'M' then Z.QtyMWhPerZonaTipoUnita else 0 end) QtyM

from
(
	-- questa select produce record distinti
	-- per contratto/PeridoRilevante/Zona/TipoUnita
	-- se POIdContratto e` NULL significa che il contratto per quel PR non ha programmazione
	-- se POIdContratto <> NULL e ProgrammaOrarioValidato e` 1 significa che il contratto ha generato offerte
	-- se POIdContratto <> NULL e ProgrammaOrarioValidato e` 0 significa che il contratto e` stato disabilitato per generare offerte
	select
	UC.CRN,
	UC.CodiceOperatoreSDCTitolare,
	PR.PeriodoRilevante,
	UC.CodiceZonaSDC,
	UC.TipoUnita,
	PO.IdContratto POIdContratto,  -- non varia per Contratto/Data/PR/Zona/TipoUnita --> posso usarla nel group by
	PO.ProgrammaOrarioValidato,
	sum(IsNull(POU.QtyMWhAssegnataMGP,0) * UC.KP / UC.KU) QtyMWhPerZonaTipoUnita, -- QtyMWh dopo i coeff di perdita
	PrezzoZonale.Prezzo   PrezzoZonale,
	PrezzoUnitario.Prezzo PrezzoUnico
	from 
	(
		-- ottengo quante ore ci sono nella data in ingresso (@DataProgramma)
		select 
		Ora PeriodoRilevante 
		from Ore
		where Ora <= @Ore
	) PR
	cross join -- prodotto cartesiano
	(
		-- questa select trova tutte i contratti/unita da programmare in un dato giorno
		-- Poi con un po' di join ritorna anche il TipoUnita, coeff/ perdita ecc.
		-- Incrociando poi i dati di questa select con la tabella PR
		-- si ottiene la lista dei contratti/unita/periodi_rilevanti da programmare
		select 
		Contratto.IdContratto,
		Contratto.CRN,
		Contratto.CodiceOperatoreSDC CodiceOperatoreSDCTitolare,
		UnitaContratto.CodiceUnitaSDC,
		UnitaContratto.CategoriaUnitaSDC,
		UnitaContratto.UnitaAssegnataOpAcquirente,
		UnitaContratto.UnitaAssegnataOpCedente,
		SDC_Unita.TipoUnita,
		SDC_Unita.CoefficientePerdita KU,
		SDC_PuntiDiScambioRilevanti.CodiceZonaSDC,
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP
		from Contratto
		inner join UnitaContratto on 
			Contratto.StatoContratto='Abilitato'
			and Contratto.DataInizioValidita <= @DataProgramma
			and Contratto.DataFineValidita >= @DataProgramma
			and Contratto.TrCN = 1
			and Contratto.IdContratto = UnitaContratto.IdContratto
			and UnitaContratto.UnitaDelContrattoValidata = 1
			and UnitaContratto.TrCC = 1
			and UnitaContratto.TrUC = 1
			and UnitaContratto.DataInizioValidita <= @DataProgramma
			and UnitaContratto.DataFineValidita >= @DataProgramma
		inner join SDC_Unita on 
			SDC_Unita.CodiceUnitaSDC = UnitaContratto.CodiceUnitaSDC
			and SDC_Unita.CategoriaUnitaSDC = UnitaContratto.CategoriaUnitaSDC
		inner join SDC_PuntiDiScambioRilevanti on
			SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
	) UC
	inner join PrezzoZonale	on -- il prezzo zonale dipende dal PeriodoRilevante (non posso mettere questa join dentro UC)
		PrezzoZonale.Data = @DataProgramma
		and PrezzoZonale.PeriodoRilevante=PR.PeriodoRilevante
		and PrezzoZonale.CodiceZonaSDC = UC.CodiceZonaSDC
	inner join PrezzoUnitario on -- il prezzo unico dipende dal PeriodoRilevante (non posso mettere questa join dentro UC)
		PrezzoUnitario.Data = @DataProgramma
		and PrezzoUnitario.PeriodoRilevante=PR.PeriodoRilevante
	left outer join -- se non esistono i record in PO per il contratto/data/ora ritorna NULL
	(
		-- qui trovo tutti i PO a prescindere se sono o no validati.
		-- in questo modo se non esiste programmazione per un contratto/data/pr
		-- PO.IdContratto (dopo la left join) sara` NULL
		-- se invece esiste avro` PO.IdContratto<>NULL con PO.ProgrammaOrarioValidato 
		-- a 1 se il programma ha generato offerte o 0 altrimenti
		select
		IdContratto,
		PeriodoRilevante,
		ProgrammaOrarioValidato
		from
		ProgrammaOrario
		where 
		DataProgramma=@DataProgramma
	) PO
	on -- metto in relazione la chiave di PO con UC/PR (escludo DataProgramma dato che e` gia` filtrata)
		PO.IdContratto = UC.IdContratto
		and PO.PeriodoRilevante = PR.PeriodoRilevante
	left outer join -- se non esistono i record in POU per il contratto/data/ora/Unita ritorna NULL
	(
		-- qui trovo tutti i POU ma solo quelli validati
		-- e non QtyMWhAssegnataMGP valorizzata della data in ingresso.
		-- Se il record del un Contratto/Data/PR/Unita non esiste (perche` o non c'e` o non e` validato o non e` valorizzato)
		-- la left join produrra` tutti valori NULL
		select
		IdContratto,
		QtyMWhAssegnataMGP,
		ProgrammatoDalCedente,
		PeriodoRilevante,
		CodiceUnitaSDC,
		CategoriaUnitaSDC
		from 
		ProgrammaOrarioPerUnita
		where 
		DataProgramma=@DataProgramma
		and ProgOrarioDellUnitaValidato=1
		and not QtyMWhAssegnataMGP is null
	) POU
	on  -- metto in relazione la chiave di POU con UC/PR (escludo DataProgramma dato che e` gia` filtrata)
		POU.IdContratto = UC.IdContratto
		and POU.PeriodoRilevante = PR.PeriodoRilevante
		and POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
		and POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
	group by  -- aggrego per sommare le Qty per tipo unita / zona di un contratto/periodo_rilevante
	UC.CRN,                        -- varia per contratto
	UC.CodiceOperatoreSDCTitolare, -- varia per contratto
	PR.PeriodoRilevante,           -- varia per contratto/periodo rilevante
	UC.CodiceZonaSDC,              -- varia per contratto/periodo rilevante/zona
	UC.TipoUnita,                  -- varia per contratto/periodo rilevante/zona/tipounita
	PrezzoZonale.Prezzo,           -- varia per periodo rilevante/zona
	PrezzoUnitario.Prezzo,         -- varia per zona
	PO.IdContratto,                -- varia per contratto/periodo rilevante
	PO.ProgrammaOrarioValidato     -- varia per contratto/periodo rilevante
)Z
group by 
Z.CRN,                             -- varia per contratto
Z.CodiceOperatoreSDCTitolare,      -- varia per contratto
Z.PeriodoRilevante,                -- varia per contratto/periodo rilevante
Z.CodiceZonaSDC,                   -- varia per contratto/periodo rilevante/zona
Z.PrezzoZonale,                    -- varia per periodo rilevante/zona
Z.PrezzoUnico,                     -- varia per periodo rilevante
Z.POIdContratto,                   -- varia per contratto/periodo rilevante
Z.ProgrammaOrarioValidato          -- varia per contratto/periodo rilevante
order by
Z.CRN,
Z.PeriodoRilevante,
Z.CodiceZonaSDC

