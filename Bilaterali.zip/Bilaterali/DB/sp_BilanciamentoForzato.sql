CREATE PROCEDURE [dbo].[spBilanciamentoForzato]
 	@DataProgramma smalldatetime,
 	@SogliaSbilMWh float,
	@AzzeraSbilanciamento bit = 1,
	@RicalcolaBilanciamento bit = 1
AS

-- declare @DataProgramma          smalldatetime
-- declare @SogliaSbilMWh          float
-- declare @AzzeraSbilanciamento   bit
-- declare @RicalcolaBilanciamento bit
-- set @DataProgramma = cast('2004-04-05 00:00:00' as datetime, 105)
-- set @SogliaSbilMWh = 1149
-- set @AzzeraSbilanciamento = 1
-- set @RicalcolaBilanciamento = 1


-- stored procedure che calcola e memorizza il bilanciamento
-- dei programmi di un dato giorno
declare @IdContratto Int
declare @PeriodoRilevante TinyInt
declare @CodiceUnitaSDC varchar(16)
declare @CategoriaUnitaSDC varchar(1)
declare @SbilanciamentoMWh float
declare @QtyMWh float
declare @KU float
declare @KP float
declare @QTogliere float

if @RicalcolaBilanciamento = 1
	exec spCalcolaBilanciamento @DataProgramma, @SogliaSbilMWh

declare po_cursor cursor local for
	select 
	IdContratto, 
	PeriodoRilevante, 
	SbilanciamentoMWh 
	from 
	ProgrammaOrario
	where 
	Dataprogramma = @DataProgramma 
	and Bilanciato = 0

open po_cursor
fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
while @@fetch_status = 0 
begin
	-- print 'IdContratto:' + cast(@IdContratto as varchar) + ' PeriodoRil.:' + str(@PeriodoRilevante)  + ' SbilMWh=' + str(@SbilanciamentoMWh)

	if @AzzeraSbilanciamento = 0
	begin
		-- ATTENZIONE: decurto lo SbilanciamentoMWh della soglia 
		-- (per Produzione tolgo, per Consumo aggiungo)
		-- in modo da ottenere un contratto bilanciato con sbilancio uguale a @SogliaSbilMWh
		-- E` OPINABILE
		if @SbilanciamentoMWh > 0
			set	@SbilanciamentoMWh = @SbilanciamentoMWh - @SogliaSbilMWh
		else
			set	@SbilanciamentoMWh = @SbilanciamentoMWh + @SogliaSbilMWh
	end

	-- print ' SbilMWh(new)=' + str(@SbilanciamentoMWh)
	-- qui trovo la lista delle unita` da decurtare.
	-- L'ordine della select indica di decortare partendo dall'invio
	-- di programma piu` recente e, a parita` di file, del progressivo piu` grande
 	declare pou_cursor cursor local keyset for
 		select 
		POU.CodiceUnitaSDC, 
		POU.CategoriaUnitaSDC, 
		POU.QtyMWh,
		SDC_Unita.CoefficientePerdita KU,  -- coefficiente di perdita dell'unita`
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP -- coefficiente di perdita del punto di scambio rilevante
		from 
		ProgrammaOrarioPerUnita POU, 
		SDC_Unita, 
		SDC_PuntiDiScambioRilevanti
		where 
		POU.DataProgramma = @DataProgramma 
		and POU.IdContratto = @IdContratto
		and POU.PeriodoRilevante = @PeriodoRilevante
		and POU.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
		and POU.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
		and sign(POU.QtyMWh) = sign(@SbilanciamentoMWh) -- le unita che causano lo sbilanciamento
		order by 
		POU.IdProgrammaXml desc,
		POU.ProgressivoNelProgramma desc

 	open pou_cursor
 	fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP

 	while @@fetch_status = 0
 	begin
		set @Qtogliere = @SbilanciamentoMWh * @KU / @KP

		-- ora questa quantita` puo` essere superiore in valore assoluto alla quantita'
		-- dell'unita --> posso azzerare l'unita corrente
		-- per poi riprovarci alla prossima
		If Abs(@Qtogliere) > Abs(@QtyMWh)
		begin
			-- posso togliere solo in parte lo sbilanciamento
			-- togliendo tutta la produzione dell'unita
			set @Qtogliere = @QtyMWh				   -- tolgo tutta la quantita disponibile
			set @SbilanciamentoMWh = @SbilanciamentoMWh - @Qtogliere * @KP / @KU
		end
 		else
		begin
 			-- qui ho tolto tutto lo sbilanciamento (per definizione)
 			set @SbilanciamentoMWh = 0
 		end 

		-- print 'Nuova Qty = ' + str(@QtyMWh - @Qtogliere)

		update 
		ProgrammaOrarioPerUnita
		set QtyMWhBilanciamento = @QtyMWh - @Qtogliere
		where current of pou_cursor

		-- esco se ho raggiunto la soglia di sbilanciamento max

		-- notare che:
		-- un contratto prima del calcolo del bialnciamento ha Bilanciato=NULL e SbilanciamentoMWh=NULL
		-- un contratto dopo il calcolo del bilanciamento se bilanciato in origine ha Bilanciato=1 e SbilanciamentoMWh=0
		-- un contratto non bilanciato in origine e prima dell'operazione di taglio ha Bilanciato=0 e SbilanciamentoMWh<>0
		-- un contratto non bilanciato in origine e dopo l'operazione di taglio ha Bilanciato=1 e SbilanciamentoMWh<>0
		If Abs(@SbilanciamentoMWh) <= @SogliaSbilMWh
		begin
			-- print 'Esco'
 			update ProgrammaOrario
 			set bilanciato = 1
 			where IdContratto = @IdContratto
 				and DataProgramma = @DataProgramma
				and PeriodoRilevante = @PeriodoRilevante
			break
		end

 		fetch next from pou_cursor into @CodiceUnitaSDC, @CategoriaUnitaSDC, @QtyMWh, @KU, @KP
 	end
 	
 	close pou_cursor
 	deallocate pou_cursor

	fetch next from po_cursor into @IdContratto, @PeriodoRilevante, @SbilanciamentoMWh
end

close po_cursor
deallocate po_cursor
