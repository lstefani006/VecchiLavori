declare @DataProgramma smalldatetime
set @DataProgramma = '5/4/04'

declare @SogliaSbilMWh float
set @SogliaSbilMWh = 2000


-- update ProgrammaOrario
-- set 
-- Bilanciato=NULL,
-- SbilanciamentoMWh=NULL



update ProgrammaOrario
set 
Bilanciato=Q.Bilanciato,
SbilanciamentoMWh=Q.BilMWh
from ProgrammaOrario PO
join 
(
	select 
	POU.IdContratto, 
	@DataProgramma DataProgramma, 
	POU.PeriodoRilevante, 
--	Sum(POU.QtyMWh * UC.KP / UC.KU) BilMWh,
--	case when Abs(Sum(POU.QtyMWh * UC.KP / UC.KU)) > @SogliaSbilMWh then 1 else 0 end Bilanciato
	case when Abs(Sum(POU.QtyMWh * UC.KP / UC.KU)) > @SogliaSbilMWh then 0 else 1 end Bilanciato,
	case when Abs(Sum(POU.QtyMWh * UC.KP / UC.KU)) > @SogliaSbilMWh then Sum(POU.QtyMWh * UC.KP / UC.KU) else 0 end BilMWh

	from 
	(
		select 
		UnitaContratto.IdContratto, 
		UnitaContratto.CodiceUnitaSDC, 
		UnitaContratto.CategoriaUnitaSDC,
		SDC_Unita.CoefficientePerdita                     KU,
		SDC_PuntiDiScambioRilevanti.CoefficienteDiPerdita KP
		from UnitaContratto, SDC_Unita, SDC_PuntiDiScambioRilevanti
		where 
		UnitaContratto.TrCC=1 
		and UnitaContratto.TrUC=1
		and UnitaContratto.UnitaDelContrattoValidata=1
		and UnitaContratto.DataInizioValidita <= @DataProgramma
		and UnitaContratto.DataFineValidita >= @DataProgramma
		and UnitaContratto.CodiceUnitaSDC = SDC_Unita.CodiceUnitaSDC
		and UnitaContratto.CategoriaUnitaSDC = SDC_Unita.CategoriaUnitaSDC
		and SDC_Unita.CodicePuntoDiScambioRilevanteSDC = SDC_PuntiDiScambioRilevanti.CodicePuntoDiScambioRilevanteSDC
	) UC
	inner join
	(
		SELECT 
		ProgrammaOrarioPerUnita.IdContratto, 
		ProgrammaOrarioPerUnita.DataProgramma, 
		ProgrammaOrarioPerUnita.PeriodoRilevante, 
		ProgrammaOrarioPerUnita.CodiceUnitaSDC, 
		ProgrammaOrarioPerUnita.CategoriaUnitaSDC, 
		ProgrammaOrarioPerUnita.QtyMWh
		FROM 
		ProgrammaOrarioPerUnita, ProgrammaOrario
		where 
		ProgrammaOrarioPerUnita.DataProgramma=@DataProgramma
		and ProgrammaOrario.DataProgramma=@DataProgramma
		and ProgrammaOrario.ProgrammaOrarioValidato=1
		and ProgrammaOrarioPerUnita.ProgOrarioDellUnitaValidato=1
		and ProgrammaOrarioPerUnita.IdContratto=ProgrammaOrario.IdContratto
		and ProgrammaOrarioPerUnita.DataProgramma=ProgrammaOrario.DataProgramma
		and ProgrammaOrarioPerUnita.PeriodoRilevante=ProgrammaOrario.PeriodoRilevante
	) POU
	ON  POU.IdContratto = UC.IdContratto
	AND POU.CodiceUnitaSDC = UC.CodiceUnitaSDC
	AND POU.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
	GROUP BY POU.IdContratto, POU.DataProgramma, POU.PeriodoRilevante
) Q
on 
PO.IdContratto = Q.IdContratto
and PO.DataProgramma = Q.DataProgramma
and PO.PeriodoRilevante = Q.PeriodoRilevante
