declare @DataProgramma smalldatetime
declare @IdContratto int

select @DataProgramma = '15/04/2004'
select @IdContratto = 30

SELECT UC.IdContratto,
	UC.PeriodoRilevante,

	SUM(CASE(UC.UnitaAssegnataOpAcquirente) WHEN 1 THEN 1 ELSE 0 END) TotUnitaDaProgrammareAcq,
	SUM(CASE(UC.UnitaAssegnataOpCedente) WHEN 1 THEN 1 ELSE 0 END)    TotUnitaDaProgrammareCed,


	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 0)) WHEN 1 THEN 1 ELSE 0 END) TotUnitaProgrammateDalCed,
	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 1)) WHEN 0 THEN 1 ELSE 0 END) TotUnitaProgrammateDalAcq,
	
	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 0)) WHEN 1 THEN 1 ELSE 0 END) +
		SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 1)) WHEN 0 THEN 1 ELSE 0 END) TotaleUnitaProgrammate,
	SUM(CASE(isnull(POU2.ProgOrarioDellUnitaValidato, 0)) WHEN 1 THEN 1 ELSE 0 END) TotUnitaProgrammateEtValidate,
	POU2.ProgrammaOrarioValidato,
	POU2.Bilanciato,
	POU2.SbilanciamentoMWh
FROM
	(
	SELECT 
	UC1.IdContratto, 
	Ore.PR PeriodoRilevante,
	UC1.UnitaAssegnataOpAcquirente,
	UC1.UnitaAssegnataOpCedente,
	UC1.CodiceUnitaSDC,
	UC1.CategoriaUnitaSDC
	FROM UnitaContratto UC1,
		(
		      select 1 as PR
		union select 2 as PR
		union select 3 as PR
		union select 4 as PR
		union select 5 as PR
		union select 6 as PR
		union select 7 as PR
		union select 8 as PR
		union select 9 as PR
		union select 10 as PR
		union select 11 as PR
		union select 12 as PR
		union select 13 as PR
		union select 14 as PR
		union select 15 as PR
		union select 16 as PR
		union select 17 as PR
		union select 18 as PR
		union select 19 as PR
		union select 20 as PR
		union select 21 as PR
		union select 22 as PR
		union select 23 as PR
		union select 24 as PR
		) Ore
	WHERE 	UC1.IdContratto = @IdContratto 
		AND UC1.UnitaDelContrattoValidata = 1
		AND UC1.TrCC = 1
		AND UC1.TrUC = 1
		AND UC1.DataInizioValidita <= @DataProgramma
		AND UC1.DataFineValidita >= @DataProgramma
	) UC
LEFT OUTER JOIN
	(
		SELECT PO.IdContratto,
			PO.DataProgramma,
			PO.PeriodoRilevante,
			PO.ProgrammaOrarioValidato,
			PO.Bilanciato,
			PO.SbilanciamentoMWh, 
			POU.CodiceUnitaSDC,
			POU.CategoriaUnitaSDC,
			POU.ProgrammatoDalCedente,
			POU.ProgOrarioDellUnitaValidato
		FROM
		(SELECT
		IdContratto,
		DataProgramma,
		PeriodoRilevante,
		CodiceUnitaSDC,
		CategoriaUnitaSDC,
		ProgrammatoDalCedente,
		ProgOrarioDellUnitaValidato
		FROM ProgrammaOrarioPerUnita
		WHERE IdContratto = @IdContratto AND
			DataProgramma = @DataProgramma
		)POU
		INNER JOIN 
		(
		SELECT IdContratto,
			DataProgramma,
			PeriodoRilevante,
			ProgrammaOrarioValidato,
			Bilanciato,
			SbilanciamentoMWh
		FROM ProgrammaOrario 
		WHERE IdCOntratto = @IdContratto AND
			DataProgramma = @DataProgramma
		) PO
		ON PO.IdContratto = POU.IdContratto AND
			PO.DataProgramma = POU.DataProgramma AND
			PO.PeriodoRilevante = POU.PeriodoRilevante
	)
	 POU2
ON POU2.IdContratto = UC.IdContratto
AND POU2.CodiceUnitaSDC = UC.CodiceUnitaSDC
AND POU2.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
AND POU2.PeriodoRilevante = UC.PeriodoRilevante
GROUP BY UC.IdContratto, 
	UC.PeriodoRilevante, 
	POU2.ProgrammaOrarioValidato,
	POU2.Bilanciato,
	POU2.SbilanciamentoMWh

