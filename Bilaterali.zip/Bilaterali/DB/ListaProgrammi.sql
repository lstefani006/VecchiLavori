declare @DataProgramma smalldatetime
Select @DataProgramma = '15/04/2004'

-- update ProgrammaOrario
-- set Bilanciato=1
-- where IdContratto=20
-- and DataProgramma=@DataProgramma
-- and PeriodoRilevante=6

-- update ProgrammaOrario
-- set ProgrammaOrarioValidato=0
-- where IdContratto=20
-- and DataProgramma=@DataProgramma
-- and PeriodoRilevante=6

 
select
PU.IdContratto,
PU.CRN,
PU.CodiceContratto,
 
sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end)   C1,
sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP1,
sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end)   A1,
sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP1,
case (sum(case PU.PeriodoRilevante when 1 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 else 1 end  B1Bis,
case (sum(case PU.PeriodoRilevante when 2 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 else 1 end  B2Bis,
case (sum(case PU.PeriodoRilevante when 3 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 else 1 end  B3Bis,
case (sum(case PU.PeriodoRilevante when 4 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 else 1 end  B4Bis,
case (sum(case PU.PeriodoRilevante when 5 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 else 1 end  B5Bis,
case (sum(case PU.PeriodoRilevante when 6 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 else 1 end  B6Bis,

 
sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end)    C2,
sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP2,
sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end)    A2,
sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP2,
 
sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end)    C3,
sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP3,
sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end)    A3,
sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP3,
 
sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end)    C4,
sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP4,
sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end)    A4,
sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP4,
 
sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end)    C5,
sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP5,
sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end)    A5,
sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP5,
 
sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end)    C6,
sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP6,
sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end)    A6,
sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP6,
 
sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end)    C7,
sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP7,
sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end)    A7,
sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP7,
 
sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end)    C8,
sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP8,
sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end)    A8,
sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP8,
 
sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end)    C9,
sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP9,
sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end)    A9,
sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP9,
 
sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end)    C10,
sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP10,
sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end)    A10,
sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP10,
 
sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end)    C11,
sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP11,
sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end)    A11,
sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP11,
 
sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end)    C12,
sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP12,
sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end)    A12,
sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP12,
 
sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end)    C13,
sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP13,
sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end)    A13,
sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP13,
 
sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end)    C14,
sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP14,
sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end)    A14,
sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP14,
 
sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end)    C15,
sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP15,
sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end)    A15,
sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP15,
 
sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end)    C16,
sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP16,
sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end)    A16,
sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP16,
 
sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end)    C17,
sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP17,
sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end)    A17,
sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP17,
 
sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end)    C18,
sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP18,
sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end)    A18,
sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP18,
 
sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end)    C19,
sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP19,
sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end)    A19,
sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP19,
 
sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end)    C20,
sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP20,
sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end)    A20,
sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP20,
 
sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end)    C21,
sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP21,
sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end)    A21,
sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP21,
 
sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end)    C22,
sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP22,
sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end)    A22,
sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP22,
 
sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end)    C23,
sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP23,
sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end)    A23,
sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP23,
 
sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end)    C24,
sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP24,
sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end)    A24,
sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP24
 
--  sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end)    C25,
--  sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaDaProgrammareCed else 0 end)  CDP25,
--  sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end)    A25,
--  sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaDaProgrammareAcq else 0 end)  ADP25
 
FROM
(
	SELECT 
	UC.IdContratto, 
	UC.CRN,
	UC.CodiceContratto,
	UC.PeriodoRilevante,
	POU2.Bilanciato,
	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 0)) WHEN 1 THEN 1 ELSE 0 END) TotUnitaAssCed,
	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 1)) WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq,
	SUM(CASE(UC.UnitaAssegnataOpAcquirente) WHEN 1 THEN 1 ELSE 0 END) TotUnitaDaProgrammareAcq,
	SUM(CASE(UC.UnitaAssegnataOpCedente) WHEN 1 THEN 1 ELSE 0 END) TotUnitaDaProgrammareCed
	FROM
	(
		SELECT 
		UC1.IdContratto, 
		Ore.PR PeriodoRilevante,
		UC1.UnitaAssegnataOpAcquirente,
		UC1.UnitaAssegnataOpCedente,
		UC1.CodiceUnitaSDC,
		UC1.CategoriaUnitaSDC,
		CC.CRN,
		CC.CodiceContratto
		FROM UnitaContratto UC1, Contratto CC,
		(
				  select 1 as PR
			union select 2 as PR
			union select 3 as PR
			union select 4 as PR
			union select 5 as PR
			union select 6 as PR
			union select 7 as PR
			union select 8 as PR
			union select 9 as PR
			union select 10 as PR
			union select 11 as PR
			union select 12 as PR
			union select 13 as PR
			union select 14 as PR
			union select 15 as PR
			union select 16 as PR
			union select 17 as PR
			union select 18 as PR
			union select 19 as PR
			union select 20 as PR
			union select 21 as PR
			union select 22 as PR
			union select 23 as PR
			union select 24 as PR
			union select 25 as PR
		) Ore
		WHERE UC1.UnitaDelContrattoValidata = 1
		AND UC1.TrCC = 1
		AND UC1.TrUC = 1
		AND UC1.DataInizioValidita <= @DataProgramma
		AND UC1.DataFineValidita >= @DataProgramma
		AND CC.IdContratto = UC1.IdContratto
	) UC
	LEFT OUTER JOIN
	(
		SELECT 
		POU.IdContratto,
		POU.DataProgramma,
		POU.PeriodoRilevante,
		POU.CodiceUnitaSDC,
		POU.CategoriaUnitaSDC,
		POU.ProgrammatoDalCedente, 
		PO.Bilanciato
		FROM
		(
			SELECT
			IdContratto,
			DataProgramma,
			PeriodoRilevante,
			CodiceUnitaSDC,
			CategoriaUnitaSDC,
			ProgrammatoDalCedente
			FROM ProgrammaOrarioPerUnita
			WHERE
			DataProgramma = @DataProgramma 
		) POU
		INNER JOIN 
		(
			SELECT
			IdContratto,
			DataProgramma,
			PeriodoRilevante,
			Bilanciato
			FROM
			ProgrammaOrario
			WHERE 
			DataProgramma = @DataProgramma 
		) PO
		ON PO.IdContratto = POU.IdContratto
		AND PO.DataProgramma = POU.DataProgramma
		AND PO.PeriodoRilevante = POU.PeriodoRilevante
	)
	POU2
	ON POU2.IdContratto = UC.IdContratto
	AND POU2.CodiceUnitaSDC = UC.CodiceUnitaSDC
	AND POU2.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
	AND POU2.PeriodoRilevante = UC.PeriodoRilevante
	GROUP BY UC.IdContratto, UC.PeriodoRilevante, UC.CRN, UC.CodiceContratto, POU2.Bilanciato
) PU
GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto

