SELECT 
	PIC.IdContratto,	
	case PIC.CDP1  when 0 then null else FLOOR(PIC.C1*100/PIC.CDP1)   end 'C - 1',
	case PIC.CDP2  when 0 then null else FLOOR(PIC.C2*100/PIC.CDP2)   end 'C - 2',
	case PIC.CDP3  when 0 then null else FLOOR(PIC.C3*100/PIC.CDP3)   end 'C - 3',
	case PIC.CDP4  when 0 then null else FLOOR(PIC.C4*100/PIC.CDP4)   end 'C - 4',
	case PIC.CDP5  when 0 then null else FLOOR(PIC.C5*100/PIC.CDP5)   end 'C - 5',
	case PIC.CDP6  when 0 then null else FLOOR(PIC.C6*100/PIC.CDP6)   end 'C - 6',
	case PIC.CDP7  when 0 then null else FLOOR(PIC.C7*100/PIC.CDP7)   end 'C - 7',
	case PIC.CDP8  when 0 then null else FLOOR(PIC.C8*100/PIC.CDP8)   end 'C - 8',
	case PIC.CDP9  when 0 then null else FLOOR(PIC.C9*100/PIC.CDP9)   end 'C - 9',
	case PIC.CDP10 when 0 then null else FLOOR(PIC.C10*100/PIC.CDP10) end 'C 1 0',
	case PIC.CDP11 when 0 then null else FLOOR(PIC.C11*100/PIC.CDP11) end 'C 1 1',
	case PIC.CDP12 when 0 then null else FLOOR(PIC.C12*100/PIC.CDP12) end 'C 1 2',
	case PIC.CDP13 when 0 then null else FLOOR(PIC.C13*100/PIC.CDP13) end 'C 1 3',
	case PIC.CDP14 when 0 then null else FLOOR(PIC.C14*100/PIC.CDP14) end 'C 1 4',
	case PIC.CDP15 when 0 then null else FLOOR(PIC.C15*100/PIC.CDP15) end 'C 1 5',
	case PIC.CDP16 when 0 then null else FLOOR(PIC.C16*100/PIC.CDP16) end 'C 1 6',
	case PIC.CDP17 when 0 then null else FLOOR(PIC.C17*100/PIC.CDP17) end 'C 1 7',
	case PIC.CDP18 when 0 then null else FLOOR(PIC.C18*100/PIC.CDP18) end 'C 1 8',
	case PIC.CDP19 when 0 then null else FLOOR(PIC.C19*100/PIC.CDP19) end 'C 1 9',
	case PIC.CDP20 when 0 then null else FLOOR(PIC.C20*100/PIC.CDP20) end 'C 2 0',
	case PIC.CDP21 when 0 then null else FLOOR(PIC.C21*100/PIC.CDP21) end 'C 2 1',
	case PIC.CDP22 when 0 then null else FLOOR(PIC.C22*100/PIC.CDP22) end 'C 2 2',
	case PIC.CDP23 when 0 then null else FLOOR(PIC.C23*100/PIC.CDP23) end 'C 2 3',
	case PIC.CDP24 when 0 then null else FLOOR(PIC.C24*100/PIC.CDP24) end 'C 2 4',
--	case PIC.CDP25 when 0 then null else FLOOR(PIC.C25*100/PIC.CDP25) end 'C 2 5',
	
	case PIC.ADP1  when 0 then null else FLOOR(PIC.A1*100/PIC.ADP1)   end 'A - 1',
	case PIC.ADP2  when 0 then null else FLOOR(PIC.A2*100/PIC.ADP2)   end 'A - 2',
	case PIC.ADP3  when 0 then null else FLOOR(PIC.A3*100/PIC.ADP3)   end 'A - 3',
	case PIC.ADP4  when 0 then null else FLOOR(PIC.A4*100/PIC.ADP4)   end 'A - 4',
	case PIC.ADP5  when 0 then null else FLOOR(PIC.A5*100/PIC.ADP5)   end 'A - 5',
	case PIC.ADP6  when 0 then null else FLOOR(PIC.A6*100/PIC.ADP6)   end 'A - 6',
	case PIC.ADP7  when 0 then null else FLOOR(PIC.A7*100/PIC.ADP7)   end 'A - 7',
	case PIC.ADP8  when 0 then null else FLOOR(PIC.A8*100/PIC.ADP8)   end 'A - 8',
	case PIC.ADP9  when 0 then null else FLOOR(PIC.A9*100/PIC.ADP9)   end 'A - 9',
	case PIC.ADP10 when 0 then null else FLOOR(PIC.A10*100/PIC.ADP10) end 'A 1 0',
	case PIC.ADP11 when 0 then null else FLOOR(PIC.A11*100/PIC.ADP11) end 'A 1 1',
	case PIC.ADP12 when 0 then null else FLOOR(PIC.A12*100/PIC.ADP12) end 'A 1 2', 
	case PIC.ADP13 when 0 then null else FLOOR(PIC.A13*100/PIC.ADP13) end 'A 1 3',
	case PIC.ADP14 when 0 then null else FLOOR(PIC.A14*100/PIC.ADP14) end 'A 1 4',
	case PIC.ADP15 when 0 then null else FLOOR(PIC.A15*100/PIC.ADP15) end 'A 1 5',
	case PIC.ADP16 when 0 then null else FLOOR(PIC.A16*100/PIC.ADP16) end 'A 1 6',
	case PIC.ADP17 when 0 then null else FLOOR(PIC.A17*100/PIC.ADP17) end 'A 1 7',
	case PIC.ADP18 when 0 then null else FLOOR(PIC.A18*100/PIC.ADP18) end 'A 1 8',
	case PIC.ADP19 when 0 then null else FLOOR(PIC.A19*100/PIC.ADP19) end 'A 1 9',
	case PIC.ADP20 when 0 then null else FLOOR(PIC.A20*100/PIC.ADP20) end 'A 2 0',
	case PIC.ADP21 when 0 then null else FLOOR(PIC.A21*100/PIC.ADP21) end 'A 2 1',
	case PIC.ADP22 when 0 then null else FLOOR(PIC.A22*100/PIC.ADP22) end 'A 2 2',
	case PIC.ADP23 when 0 then null else FLOOR(PIC.A23*100/PIC.ADP23) end 'A 2 3',
	case PIC.ADP24 when 0 then null else FLOOR(PIC.A24*100/PIC.ADP24) end 'A 2 4',
--	case PIC.ADP25 when 0 then null else FLOOR(PIC.A25*100/PIC.ADP25) end 'A 2 5',
	
	PIC.B1  'B - 1',
	PIC.B2  'B - 2',
	PIC.B3  'B - 3',
	PIC.B4  'B - 4',
	PIC.B5  'B - 5',
	PIC.B6  'B - 6',
	PIC.B7  'B - 7',
	PIC.B8  'B - 8',
	PIC.B9  'B - 9',
	PIC.B10 'B 1 0',
	PIC.B11 'B 1 1',
	PIC.B12 'B 1 2',
	PIC.B13 'B 1 3',
	PIC.B14 'B 1 4',
	PIC.B15 'B 1 5',
	PIC.B16 'B 1 6',
	PIC.B17 'B 1 7',
	PIC.B18 'B 1 8',
	PIC.B19 'B 1 9',
	PIC.B20 'B 2 0',
	PIC.B21 'B 2 1',
	PIC.B22 'B 2 2',
	PIC.B23 'B 2 3',
	PIC.B24 'B 2 4',
--	PIC.B25 'B 2 5',

	PIC.CRN 'Codice contratto GRTN',
	PIC.CodiceContratto AS 'Codice CN'

FROM
(
select
	PU.IdContratto,
	PU.CRN,
	PU.CodiceContratto,

 	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssCed else 0 end) 			C1,
 	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP1,
 	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaAssAcq else 0 end) 			A1,
 	sum(case PU.PeriodoRilevante when  1 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP1,
 	
 	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssCed else 0 end) 			C2,
 	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP2,
 	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaAssAcq else 0 end) 			A2,
 	sum(case PU.PeriodoRilevante when  2 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP2,

 	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssCed else 0 end) 			C3,
 	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP3,
 	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaAssAcq else 0 end) 			A3,
 	sum(case PU.PeriodoRilevante when  3 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP3,

 	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssCed else 0 end) 			C4,
 	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP4,
 	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaAssAcq else 0 end) 			A4,
 	sum(case PU.PeriodoRilevante when  4 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP4,

 	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssCed else 0 end) 			C5,
 	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP5,
 	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaAssAcq else 0 end) 			A5,
 	sum(case PU.PeriodoRilevante when  5 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP5,

 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssCed else 0 end) 			C6,
 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP6,
 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaAssAcq else 0 end) 			A6,
 	sum(case PU.PeriodoRilevante when  6 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP6,

 	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssCed else 0 end) 			C7,
 	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP7,
 	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaAssAcq else 0 end) 			A7,
 	sum(case PU.PeriodoRilevante when  7 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP7,

 	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssCed else 0 end) 			C8,
 	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP8,
 	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaAssAcq else 0 end) 			A8,
 	sum(case PU.PeriodoRilevante when  8 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP8,

 	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssCed else 0 end) 			C9,
 	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP9,
 	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaAssAcq else 0 end) 			A9,
 	sum(case PU.PeriodoRilevante when  9 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP9,

 	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssCed else 0 end) 			C10,
 	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP10,
 	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaAssAcq else 0 end) 			A10,
 	sum(case PU.PeriodoRilevante when  10 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP10,

 	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssCed else 0 end) 			C11,
 	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP11,
 	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaAssAcq else 0 end) 			A11,
 	sum(case PU.PeriodoRilevante when  11 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP11,

 	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssCed else 0 end) 			C12,
 	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP12,
 	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaAssAcq else 0 end) 			A12,
 	sum(case PU.PeriodoRilevante when  12 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP12,

 	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssCed else 0 end) 			C13,
 	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP13,
 	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaAssAcq else 0 end) 			A13,
 	sum(case PU.PeriodoRilevante when  13 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP13,

 	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssCed else 0 end) 			C14,
 	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP14,
 	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaAssAcq else 0 end) 			A14,
 	sum(case PU.PeriodoRilevante when  14 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP14,

 	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssCed else 0 end) 			C15,
 	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP15,
 	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaAssAcq else 0 end) 			A15,
 	sum(case PU.PeriodoRilevante when  15 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP15,

 	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssCed else 0 end) 			C16,
 	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP16,
 	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaAssAcq else 0 end) 			A16,
 	sum(case PU.PeriodoRilevante when  16 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP16,

 	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssCed else 0 end) 			C17,
 	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP17,
 	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaAssAcq else 0 end) 			A17,
 	sum(case PU.PeriodoRilevante when  17 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP17,

 	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssCed else 0 end) 			C18,
 	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP18,
 	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaAssAcq else 0 end) 			A18,
 	sum(case PU.PeriodoRilevante when  18 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP18,

 	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssCed else 0 end) 			C19,
 	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP19,
 	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaAssAcq else 0 end) 			A19,
 	sum(case PU.PeriodoRilevante when  19 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP19,

 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssCed else 0 end) 			C20,
 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP20,
 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaAssAcq else 0 end) 			A20,
 	sum(case PU.PeriodoRilevante when  20 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP20,

 	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssCed else 0 end) 			C21,
 	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP21,
 	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaAssAcq else 0 end) 			A21,
 	sum(case PU.PeriodoRilevante when  21 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP21,

 	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssCed else 0 end) 			C22,
 	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP22,
 	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaAssAcq else 0 end) 			A22,
 	sum(case PU.PeriodoRilevante when  22 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP22,

 	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssCed else 0 end) 			C23,
 	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP23,
 	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaAssAcq else 0 end) 			A23,
 	sum(case PU.PeriodoRilevante when  23 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP23,

 	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssCed else 0 end) 			C24,
 	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP24,
 	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaAssAcq else 0 end) 			A24,
 	sum(case PU.PeriodoRilevante when  24 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP24,

-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssCed else 0 end) 			C25,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaDaProgrammareCed else 0 end) 	CDP25,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaAssAcq else 0 end) 			A25,
-- 	sum(case PU.PeriodoRilevante when  25 then PU.TotUnitaDaProgrammareAcq else 0 end) 	ADP25

	case (sum(case PU.PeriodoRilevante when  1 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  1 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B1,
	case (sum(case PU.PeriodoRilevante when  2 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  2 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B2,
	case (sum(case PU.PeriodoRilevante when  3 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  3 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B3,
	case (sum(case PU.PeriodoRilevante when  4 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  4 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B4,
	case (sum(case PU.PeriodoRilevante when  5 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  5 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B5,
	case (sum(case PU.PeriodoRilevante when  6 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  6 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B6,
	case (sum(case PU.PeriodoRilevante when  7 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  7 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B7,
	case (sum(case PU.PeriodoRilevante when  8 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  8 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B8,
	case (sum(case PU.PeriodoRilevante when  9 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when  9 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B9,
	case (sum(case PU.PeriodoRilevante when 10 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 10 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B10,
	case (sum(case PU.PeriodoRilevante when 11 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 11 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B11,
	case (sum(case PU.PeriodoRilevante when 12 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 12 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B12,
	case (sum(case PU.PeriodoRilevante when 13 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 13 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B13,
	case (sum(case PU.PeriodoRilevante when 14 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 14 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B14,
	case (sum(case PU.PeriodoRilevante when 15 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 15 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B15,
	case (sum(case PU.PeriodoRilevante when 16 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 16 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B16,
	case (sum(case PU.PeriodoRilevante when 17 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 17 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B17,
	case (sum(case PU.PeriodoRilevante when 18 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 18 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B18,
	case (sum(case PU.PeriodoRilevante when 19 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 19 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B19,
	case (sum(case PU.PeriodoRilevante when 20 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 20 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B20,
	case (sum(case PU.PeriodoRilevante when 21 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 21 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B21,
	case (sum(case PU.PeriodoRilevante when 22 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 22 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B22,
	case (sum(case PU.PeriodoRilevante when 23 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 23 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B23,
	case (sum(case PU.PeriodoRilevante when 24 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 24 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B24
--	case (sum(case PU.PeriodoRilevante when 25 then 1+IsNull(cast(PU.Bilanciato as integer),-1) else 0 end)) when 0 then Null when 1 then 0 when 2 then (case (sum(case PU.PeriodoRilevante when 25 then 1+IsNull(cast(PU.Sbilanciamento as integer),-1) else 0 end)) when 0 then 1 else 2 end) else 1 end  B25
	
FROM
(
SELECT 
	UC.IdContratto, 
	UC.CRN,
	UC.CodiceContratto,
	UC.PeriodoRilevante,
	POU2.Bilanciato,
	case WHEN POU2.SbilanciamentoMWh IS NULL Then NULL else 1 end Sbilanciamento,
--	COUNT(UC.CodiceUnitaSDC) TotUnitaProgr,
	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 0)) WHEN 1 THEN 1 ELSE 0 END) TotUnitaAssCed,
	SUM(CASE(isnull(POU2.ProgrammatoDalCedente, 1)) WHEN 0 THEN 1 ELSE 0 END) TotUnitaAssAcq,
	SUM(CASE(UC.UnitaAssegnataOpAcquirente) WHEN 1 THEN 1 ELSE 0 END) TotUnitaDaProgrammareAcq,
	SUM(CASE(UC.UnitaAssegnataOpCedente) WHEN 1 THEN 1 ELSE 0 END) TotUnitaDaProgrammareCed
FROM
	(
	SELECT 
	UC1.IdContratto, 
	Ore.Ora PeriodoRilevante,
	UC1.UnitaAssegnataOpAcquirente,
	UC1.UnitaAssegnataOpCedente,
	UC1.CodiceUnitaSDC,
	UC1.CategoriaUnitaSDC,
	CC.CRN,
	CC.CodiceContratto
	FROM UnitaContratto UC1, Contratto CC, Ore
	WHERE 
	UC1.UnitaDelContrattoValidata = 1
	AND UC1.TrCC = 1
	AND UC1.TrUC = 1
	AND UC1.DataInizioValidita <= @DataProgramma
	AND UC1.DataFineValidita >= @DataProgramma
	AND CC.IdContratto = UC1.IdContratto
	AND Ore.Ora <= 24
	) UC
LEFT OUTER JOIN
	(
		SELECT 
		POU.IdContratto,
		POU.DataProgramma,
		POU.PeriodoRilevante,
		POU.CodiceUnitaSDC,
		POU.CategoriaUnitaSDC,
		POU.ProgrammatoDalCedente, 
		PO.Bilanciato,
		PO.SbilanciamentoMWh
		FROM
		(
			SELECT
			IdContratto,
			DataProgramma,
			PeriodoRilevante,
			CodiceUnitaSDC,
			CategoriaUnitaSDC,
			ProgrammatoDalCedente
			FROM ProgrammaOrarioPerUnita
			WHERE
			DataProgramma = @DataProgramma 
		) POU
		INNER JOIN 
		(
			SELECT
			IdContratto,
			DataProgramma,
			PeriodoRilevante,
			Bilanciato,
			SbilanciamentoMWh
			FROM
			ProgrammaOrario
			WHERE 
			DataProgramma = @DataProgramma 
		) PO
		ON PO.IdContratto = POU.IdContratto
		AND PO.DataProgramma = POU.DataProgramma
		AND PO.PeriodoRilevante = POU.PeriodoRilevante
	)
	 POU2
ON POU2.IdContratto = UC.IdContratto
AND POU2.CodiceUnitaSDC = UC.CodiceUnitaSDC
AND POU2.CategoriaUnitaSDC = UC.CategoriaUnitaSDC
AND POU2.PeriodoRilevante = UC.PeriodoRilevante
GROUP BY UC.IdContratto, UC.PeriodoRilevante, UC.CRN, UC.CodiceContratto, POU2.Bilanciato, POU2.SbilanciamentoMWh
) PU
GROUP BY PU.IdContratto, PU.CRN, PU.CodiceContratto
) PIC
ORDER BY PIC.CRN

