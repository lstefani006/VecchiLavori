// server
var s = "BILSVR1"

// login
var u = "bil_dbo"

// password
var p = "bilaterali"

// table owner
var o = "Bilaterali.dbo"

var tb = new Array();
tb[0] = "ProgrammaOrario";
tb[1] = ""
tb[2] = "ProgrammaOrarioPerUnita";
tb[3] = "";

// se esiste gia` pace.
EseguiComando("md tmp", true);
EseguiComando("del tmp\\*.bcp", true);

for (var ti = 0; ti < tb.length; ti+= 2)
{
	WScript.echo(tb[ti]);
	var t = tb[ti];

	if (tb[ti+1] != "")
	{
	}
	else
	{
	}

	// il comando bcp da lanciare
	var cmd = "bcp " + o + "." + t + " out " + "tmp\\"+ t + ".bcp -S" + s + " -U" + u + " -P" + p + " -N";
	WScript.Echo(cmd);

	// qui lo eseguo (aspettando che finisca)
	// in ec ho l'exit code del programma
	var ec = EseguiComando(cmd, false);
	WScript.Echo(ec);
}

var ee = EseguiComando("zip S0.zip tmp\\*.bcp", true);
WScript.Echo(ee);


function EseguiComando(cmd, useComspec)
{
	var WshShell = new ActiveXObject("WScript.Shell");
	var oExec;
	
	if (useComspec)
		oExec = WshShell.Exec("%comspec% /c " + cmd);
	else
		oExec = WshShell.Exec(cmd);

	// aspetto che completi (magari con successo)
	// status ritorna 0 quando e` in running 1 quando e` finito
	while (oExec.Status == 0)
		WScript.Sleep(500);

	return oExec.ExitCode;
}


// directory dove si fa il dump
//md tmp

/*
   rem table to copy
   set t=ProgrammaOrarioPerUnita

   for %%t in (ProgrammaOrario, ProgrammaOrarioPerUnita) do echo %t%

   rem bcp %o%.%t% out %t%.bcp -S%s% -U%u% -P%p% -n
 */
