INSERT INTO SDC_Operatori
(
CodiceOperatoreSDC, 
RagioneSociale, 
Indirizzo1, 
Indirizzo2, 
Citta, 
Nazione, 
CodiceFiscale, 
PartitaIva, 
Fax, 
Email, 
ReferenteAmministrativo, 
SedeAmministrativa, 
Abilitato, 
TSModifica, 
ResponsabileAggiornamento
)
VALUES
('root', 'root', '', '', '', '', '', '', '', '', '', '', 1, getdate(), '')

INSERT INTO Operatori
(
CodiceOperatoreSDC, 
StatoBilateraliOperatore, 
TSModifica
)
VALUES
('root', 1, getdate())

INSERT INTO SDC_Utenti
(
CodiceUtenteSDC, 
Nome, 
Cognome, 
Telefono, 
Fax, 
Email, 
DN, 
Abilitato, 
Login, 
Pwd, 
Lingua, 
CodiceFiscale, 
TSModifica, 
ResponsabileAggiornamento)
VALUES
('root', 'root', 'root', '', '', '', '', 1, 'root', 'root', 'IT-it', '', getdate(), '')

INSERT INTO Utenti
(
CodiceUtenteSDC, 
StatoBilateraliUtente, 
TSModifica
)
VALUES('root', 1, getdate())

INSERT INTO Funzioni
(
[CodiceFunzione], 
[DescrizioneFunzione], 
[TSModifica]
)
VALUES('root', 'root', getdate())


INSERT INTO [Bilaterali].[dbo].[Ruoli]
(
[CodiceRuolo], 
[DescrizioneRuolo], 
[TSModifica])
VALUES('root', 'root', getdate())


INSERT INTO RelOperatoriUtenti
(
[CodiceUtenteSDC], 
[CodiceOperatoreSDC], 
[Amministratore], 
[Abilitato], 
[TSIniValidita], 
[TSEndValidita], 
[CodiceRuolo], 
[TSModifica]
)
VALUES (
'root', 
'root', 
1, 
1, 
getdate(), 
getdate() + 1000, -- in pratica non scade.
'root', 
getdate())