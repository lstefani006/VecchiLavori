declare @DataInizioProgramma as smalldatetime
set @DataInizioProgramma = '1/4/04'
declare @DataFineProgramma as smalldatetime
set @DataFineProgramma = '30/4/04'

declare @DataInizio as smalldatetime
set @DataInizio = '1/1/04'
declare @DataFine as smalldatetime
set @DataFine = '31/12/04'



SELECT 
C.CodiceContratto AS CodiceMnemonico,
C.DataInizioValidita AS DataInizioValidita, 
C.DataFineValidita AS DataFineValidita,
C.CRN AS CodiceGRTN, 
C.StatoContratto AS Abilitato, 
C.CodiceOperatoreSDCAcquirente AS IdOperatoreAcq, 
C.CodiceOperatoreSDCCedente AS IdOperatoreCed,

NULL DataProgramma,
'Non presente' Presenza,
NULL Bilanciato 

FROM dbo.Contratto C
WHERE 
C.DataInizioValidita >= @DataInizio And 
C.DataFineValidita <= @DataFine And 
not exists 
(
	select * 
	from dbo.ProgrammaOrario PO 
	where 
	PO.DataProgramma >= @DataInizioProgramma And PO.DataProgramma <= @DataFineProgramma
	and C.IdContratto = PO.IdContratto 
)

union

SELECT  
CE.CodiceContratto AS CodiceMnemonico,
CE.DataInizioValidita AS DataInizioValidita, 
CE.DataFineValidita AS DataFineValidita,
CE.CRN AS CodiceGRTN, 
CE.StatoContratto AS Abilitato, 
CE.CodiceOperatoreSDCAcquirente AS IdOperatoreAcq, 
CE.CodiceOperatoreSDCCedente AS IdOperatoreCed, 
POE.DataProgramma AS DataProgramma, 
'Presente' AS Presenza, 
min (isnull(cast(POE.Bilanciato as int),0)) Bilanciato
FROM dbo.Contratto CE
inner JOIN dbo.ProgrammaOrario POE
on CE.IdContratto = POE.IdContratto 
WHERE 
CE.DataInizioValidita >= @DataInizio And 
CE.DataFineValidita <= @DataFine And 
POE.DataProgramma >= @DataInizioProgramma And POE.DataProgramma <= @DataFineProgramma 
group by CE.CRN, 
POE.DataProgramma, 
CE.CodiceContratto,
CE.DataInizioValidita,
CE.DataFineValidita,
CE.StatoContratto,
CE.CodiceOperatoreSDCAcquirente,
CE.CodiceOperatoreSDCCedente


