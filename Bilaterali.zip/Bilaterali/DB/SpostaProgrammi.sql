-- select * from programmaorario where dataprogramma='8/5/04'
--delete from programmaorarioPerUnita where dataprogramma='9/5/04'
--delete from programmaorario where dataprogramma='9/5/04'

update programmaorario
set dataprogramma='9/5/04'
where dataprogramma='8/5/04'

alter table programmaorarioperunita
check constraint FK_ProgrammaOrarioPerUnita_ProgrammaOrario
go