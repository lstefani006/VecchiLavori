using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net;
using System.Configuration;
using DbMonitor.DbMon;

namespace DbMonitor
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class DbMonitor
	{
		public static DataSet ExecuteSQL(string sql)
		{
			try
			{
				string ppk;
				ppk = "<RSAKeyValue><Modulus>yZbzNEswudCo+DE15V9c8GBsSnrhnlL2E4FZikFQB4gYXhayvD7Daa6b4Wyd2+kkk13uoUf8gJv5WPP//ehYcoaZhYedNnmwji/LUivxOSWzcf6/bn/eAg5ZkSpgWgdswQBBimNLUSH+6KyAFJiF8DueLRrZOE183Y7tVeHB/68=</Modulus><Exponent>AQAB</Exponent><P>+R9TE989qf6m2WgJd13uUODzUEyPdPH3jO86mPC46pLnI6rRy2pB1toFSRk7EPsvhP8LaNu7DS53vvwS85upPw==</P><Q>zyev++yAY0rbkzgO5VCZkawnsLsOL+1j9pPrAsO6UgITqdLXCQyXWqwZeoVvcwxM8fRceZ9he2kt1BKKzdUdkQ==</Q><DP>ncRYuJ0IUEAVKlnYpN+3rUDI1nGl6EnUnExkr7bDZMrj1pK3ijsgtxAbiM+RuI9a6L8cWqvNKevjqe+5kM1jwQ==</DP><DQ>b6omC/d1UZClgdsi9GuZDFQvZO2//QfK7bzYXrog8lnaPZ3AeklGQQMqDMhmxi5oP7iILKtEQeD1ai7AkamCcQ==</DQ><InverseQ>KdX7jtzoKO4hZoF/L7r7YQv0fbrmIUiUnE48Uvzxmox0e5sCXqtuyRj5rIWe6qI32UEm7vVM+LxZHlZviLNhDg==</InverseQ><D>khY/FuVqYS3yVTIsUZXDHztxHqRgPkD2rPnu7n8YROz+Y6jlS//b0wlDU6BH4abZ56WJmf014emmUC06lUE8Xi++UWgNN8yu/FoqSBGHzjfQX/grrkIVipFQg893iZ/zsGD3jMzZ8jUlA4UtXZeOb8zUyGlp4YvVZLW1GA/rbGE=</D></RSAKeyValue>";


				byte [] cCmd;
				byte [] hCmd;

				byte []pin = null;
	
				Hashtable ht = new Hashtable();
				/*
				if (false)
				{
					ht.Add("@op", "IDAU");
					MemoryStream ms = new MemoryStream();
					BinaryFormatter bf = new BinaryFormatter();
					bf.Serialize(ms, ht);
					pin = ms.ToArray();
				}
				*/

			
				//string cmd = "select * from bilaterali.dbo.operatori where codiceOperatoreSDC=@op";



				cCmd = new UnicodeEncoding().GetBytes(sql);
				hCmd = RSA.HashAndSign(ppk, cCmd);

				DbMon.NabData nd = new DbMon.NabData();

				string addr = ConfigurationSettings.AppSettings["Proxy_Addr"];
				if (addr != null && addr != "")
				{
					string login    = ConfigurationSettings.AppSettings["Proxy_Login"];
					string pwd      = ConfigurationSettings.AppSettings["Proxy_Pwd"];
					string domain   = ConfigurationSettings.AppSettings["Proxy_Domain"];

					nd.Proxy = new WebProxy(addr, true, null, new NetworkCredential(login, pwd, domain));
				}
				else
				{
					GlobalProxySelection.Select.Credentials = CredentialCache.DefaultCredentials;
				}
				nd.Url = ConfigurationSettings.AppSettings["RemoteDb"];

				byte [] r = nd.t2(cCmd, hCmd, "Text", pin, false, 60);

				DataSet ds = new DataSet();
				ds.ReadXml(new MemoryStream(r, false));

				ds.WriteXml("ds.xml");

				return ds;

			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				throw;
			}
		}

	}
}
