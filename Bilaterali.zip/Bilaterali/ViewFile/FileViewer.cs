using System;
using System.Data;
using System.IO;
using Bil;

namespace ViewFile
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class FileViewer
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			string data = "20060417";

			string [] idFileList;

			if (false)
			{
				DataSet ds = new DataSet();
				ds.ReadXml("dsSz.xml");

				DataTable dtIdFile = ds.Tables[0];

				foreach (DataRow dr in dtIdFile.Rows)
				{
					string idFile= (string)dr[0];

					Console.WriteLine("delete from fileMgp where IdFile ='{0}'", idFile);
				}

				return;
				
			}


			if (true)
			{
				// string sql = String.Format(@"select top 10 IdFile from fileMgp where convert(varchar(20), TSCreazione, 112) = '{0}'", data);

				string sql = string.Format("select IdFile from fileMgp where convert(varchar(20), TSCreazione, 112) > '{0}' and DATALENGTH(ContenutoFile) in (241170, 358840)", data);
				DataSet dsIdFile = DbMonitor.DbMonitor.ExecuteSQL(sql);
				dsIdFile.WriteXml("dsSz.xml");

				DataTable dtIdFile = dsIdFile.Tables[0];

				idFileList = new string[dtIdFile.Rows.Count];
				int i = 0;
				foreach (DataRow dr in dtIdFile.Rows)
				{
					idFileList[i++]  = (string)dr[0];
					
					Console.WriteLine("delete from fileMgp where IdFile ='{0}'", dr[0]);
				}

			}

		
			Directory.CreateDirectory(data);

			int n = 0;
			foreach (string idFile in idFileList)
			{
				try
				{
					string sql = string.Format("select idFile, tsCreazione, ContenutoFile, VersoMgp, Zippato, TSFlusso from fileMgp where IdFile = '{0}'", idFile);
					DataSet ds = DbMonitor.DbMonitor.ExecuteSQL(sql);

					for (int i=0; i< ds.Tables[0].Rows.Count; i++)
					{
						DataRow dr = ds.Tables[0].Rows[i];

						string IdFile = dr.ItemArray[0].ToString();
						DateTime TSCreazione = DateTime.Parse(dr.ItemArray[1].ToString());
						byte[] ContenutoFile = Convert.FromBase64String(dr.ItemArray[2].ToString());
						bool VersoMGP = bool.Parse(dr.ItemArray[3].ToString());
						bool Zippato = bool.Parse(dr.ItemArray[4].ToString());
						DateTime TSFlusso = DateTime.Parse(dr.ItemArray[5].ToString());

						string path = null;
						byte[] Unzipped = BilZipLib.UnzipSingleFile(ContenutoFile, ref path);

						path = data + "\\" + path;

						Console.WriteLine("path={0}", path);

						if (File.Exists((path)))
						{
							using (FileStream fs = new FileStream(path + n++.ToString(), FileMode.Create, FileAccess.Write))
							{
								fs.Write(Unzipped, 0, Unzipped.Length);
							}
								
						}
						else
						{
							using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write))
							{
								fs.Write(Unzipped, 0, Unzipped.Length);
							}
						}
					}
				
				}
				catch(Exception ex)
				{
					string s = ex.Message;
					Console.Write(s);
				}
			
			}
			
		}
	}
}
