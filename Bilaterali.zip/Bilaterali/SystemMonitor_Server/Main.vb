Imports System.Runtime.Remoting
Imports System.AppDomain
Imports SystemMonitor


Module SystemMonitor

	<MTAThread()> _
	Sub Main()
		' qui si caricano le impostazioni di remoting (se l'argomento e` true)
		' e si aggancia al TraceListenerCollection il listener per fare il trace.
		' (anche se il servizio di Trace e` proprio questo!!)
		RemotingConfiguration.Configure(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile)
		'		SmLog.Init()
		'		SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "SystemMonitor_Server started")

		' Inizializzazione del thread di Purge
		SmPurge.Init()

		Console.WriteLine("SystemMonitor_Server: server host dei servizi utilizzati dalla nuova architettura.")

		Do
			Console.Write("Scrivi 'q' per terminare il server > ")
			Dim s As String = Console.ReadLine()
			If s = "q" Or s = "Q" Then
				Exit Do
			End If
		Loop
	End Sub

End Module
