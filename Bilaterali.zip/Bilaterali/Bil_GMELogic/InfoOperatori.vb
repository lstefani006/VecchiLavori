Imports System.Configuration

Namespace Bil_GMELogic

    Public Class InfoOperatori
        Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

        Public Sub New(ByVal Container As System.ComponentModel.IContainer)
            MyClass.New()

            'Required for Windows.Forms Class Composition Designer support
            Container.Add(Me)
        End Sub

        Public Sub New()
            MyBase.New()

            'This call is required by the Component Designer.
            InitializeComponent()

            'Add any initialization after the InitializeComponent() call

        End Sub

        'Component overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Component Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Component Designer
        'It can be modified using the Component Designer.
        'Do not modify it using the code editor.
        Friend WithEvents oraOleDbConn As System.Data.OleDb.OleDbConnection
        Friend WithEvents daOperatoriPerData As System.Data.OleDb.OleDbDataAdapter
        Friend WithEvents daOperatoriPerIntervallo As System.Data.OleDb.OleDbDataAdapter
        Friend WithEvents cmdSelectOperatoriPerData As System.Data.OleDb.OleDbCommand
        Friend WithEvents dsOperatoriPerData As DS_OperatoriPerData
        Friend WithEvents dsOperatoriPerIntervallo As DS_OperatoriPerIntervallo
        Friend WithEvents cmdSelectOperatoriPerIntervallo As System.Data.OleDb.OleDbCommand
        Friend WithEvents daOperatoriAttivi As System.Data.OleDb.OleDbDataAdapter
        Friend WithEvents cmdSelectOperatoriAttivi As System.Data.OleDb.OleDbCommand
        Friend WithEvents dsOperatoriAttivi As DS_OperatoriAttivi
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
			Me.oraOleDbConn = New System.Data.OleDb.OleDbConnection
			Me.daOperatoriPerData = New System.Data.OleDb.OleDbDataAdapter
			Me.cmdSelectOperatoriPerData = New System.Data.OleDb.OleDbCommand
			Me.daOperatoriPerIntervallo = New System.Data.OleDb.OleDbDataAdapter
			Me.cmdSelectOperatoriPerIntervallo = New System.Data.OleDb.OleDbCommand
			Me.dsOperatoriPerData = New DS_OperatoriPerData
			Me.dsOperatoriPerIntervallo = New DS_OperatoriPerIntervallo
			Me.daOperatoriAttivi = New System.Data.OleDb.OleDbDataAdapter
			Me.cmdSelectOperatoriAttivi = New System.Data.OleDb.OleDbCommand
			Me.dsOperatoriAttivi = New DS_OperatoriAttivi
			CType(Me.dsOperatoriPerData, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.dsOperatoriPerIntervallo, System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.dsOperatoriAttivi, System.ComponentModel.ISupportInitialize).BeginInit()
			'
			'oraOleDbConn
			'
			Me.oraOleDbConn.ConnectionString = "Provider=""MSDAORA.1"";User ID=esystem;Data Source=exactpt;Password=manager"
			'
			'daOperatoriPerData
			'
			Me.daOperatoriPerData.SelectCommand = Me.cmdSelectOperatoriPerData
			Me.daOperatoriPerData.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "COMMUNICATION_PARTNER", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("COMMUNICATION_PARTNER_DB_NO", "COMMUNICATION_PARTNER_DB_NO")})})
			'
			'cmdSelectOperatoriPerData
			'
			Me.cmdSelectOperatoriPerData.CommandText = "SELECT DISTINCT C.COMMUNICATION_PARTNER_DB_NO FROM USER_FIELD_DATA UDATA, COMMUNI" & _
			"CATION_PARTNER C, USER_FIELD_DEFINITION UDEF WHERE UDATA.RELATED_ID = C.COMMUNIC" & _
			"ATION_PARTNER_ID AND UDATA.FIELD_DEF_ID = UDEF.FIELD_DEF_ID AND (C.STATUS_CD = '" & _
			"ACT') AND (UDEF.FIELD_NM = 'Market Eligibility') AND (UDEF.RELATED_CLASS_NM = 'c" & _
			"CommunicationPartner') AND (UDATA.VALUE_TX = 'ALL') AND (UDATA.START_DT = 0 OR U" & _
			"DATA.START_DT <= ?) AND (UDATA.END_DT = 0 OR UDATA.END_DT >= ?) ORDER BY C.COMMU" & _
			"NICATION_PARTNER_DB_NO"
			Me.cmdSelectOperatoriPerData.Connection = Me.oraOleDbConn
			Me.cmdSelectOperatoriPerData.Parameters.Add(New System.Data.OleDb.OleDbParameter("START_DT", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(8, Byte), CType(0, Byte), "START_DT", System.Data.DataRowVersion.Current, Nothing))
			Me.cmdSelectOperatoriPerData.Parameters.Add(New System.Data.OleDb.OleDbParameter("END_DT", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(8, Byte), CType(0, Byte), "END_DT", System.Data.DataRowVersion.Current, Nothing))
			'
			'daOperatoriPerIntervallo
			'
			Me.daOperatoriPerIntervallo.SelectCommand = Me.cmdSelectOperatoriPerIntervallo
			Me.daOperatoriPerIntervallo.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "USER_FIELD_DATA", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("COMMUNICATION_PARTNER_DB_NO", "COMMUNICATION_PARTNER_DB_NO"), New System.Data.Common.DataColumnMapping("START_DT", "START_DT"), New System.Data.Common.DataColumnMapping("END_DT", "END_DT")})})
			'
			'cmdSelectOperatoriPerIntervallo
			'
			Me.cmdSelectOperatoriPerIntervallo.CommandText = "SELECT DISTINCT C.COMMUNICATION_PARTNER_DB_NO, UDATA.START_DT, UDATA.END_DT FROM " & _
			"USER_FIELD_DATA UDATA, COMMUNICATION_PARTNER C, USER_FIELD_DEFINITION UDEF WHERE" & _
			" UDATA.RELATED_ID = C.COMMUNICATION_PARTNER_ID AND UDATA.FIELD_DEF_ID = UDEF.FIE" & _
			"LD_DEF_ID AND ((C.STATUS_CD = 'ACT') AND (UDEF.FIELD_NM = 'Market Eligibility') " & _
			"AND (UDEF.RELATED_CLASS_NM = 'cCommunicationPartner') AND (UDATA.VALUE_TX = 'ALL" & _
			"') AND (UDATA.START_DT = 0) AND (UDATA.END_DT = 0) OR (C.STATUS_CD = 'ACT') AND " & _
			"(UDEF.FIELD_NM = 'Market Eligibility') AND (UDEF.RELATED_CLASS_NM = 'cCommunicat" & _
			"ionPartner') AND (UDATA.VALUE_TX = 'ALL') AND (UDATA.START_DT = 0) AND (UDATA.EN" & _
			"D_DT >= ?) OR (C.STATUS_CD = 'ACT') AND (UDEF.FIELD_NM = 'Market Eligibility') A" & _
			"ND (UDEF.RELATED_CLASS_NM = 'cCommunicationPartner') AND (UDATA.VALUE_TX = 'ALL'" & _
			") AND (UDATA.START_DT <= ?) AND (UDATA.END_DT = 0) OR (C.STATUS_CD = 'ACT') AND " & _
			"(UDEF.FIELD_NM = 'Market Eligibility') AND (UDEF.RELATED_CLASS_NM = 'cCommunicat" & _
			"ionPartner') AND (UDATA.VALUE_TX = 'ALL') AND (UDATA.START_DT <> 0) AND (UDATA.E" & _
			"ND_DT <> 0) AND (UDATA.START_DT <= ?) AND (UDATA.END_DT >= ?)) ORDER BY C.COMMUN" & _
			"ICATION_PARTNER_DB_NO"
			Me.cmdSelectOperatoriPerIntervallo.Connection = Me.oraOleDbConn
			Me.cmdSelectOperatoriPerIntervallo.Parameters.Add(New System.Data.OleDb.OleDbParameter("END_DT", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(8, Byte), CType(0, Byte), "END_DT", System.Data.DataRowVersion.Current, Nothing))
			Me.cmdSelectOperatoriPerIntervallo.Parameters.Add(New System.Data.OleDb.OleDbParameter("START_DT", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(8, Byte), CType(0, Byte), "START_DT", System.Data.DataRowVersion.Current, Nothing))
			Me.cmdSelectOperatoriPerIntervallo.Parameters.Add(New System.Data.OleDb.OleDbParameter("START_DT1", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(8, Byte), CType(0, Byte), "START_DT", System.Data.DataRowVersion.Current, Nothing))
			Me.cmdSelectOperatoriPerIntervallo.Parameters.Add(New System.Data.OleDb.OleDbParameter("END_DT1", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(8, Byte), CType(0, Byte), "END_DT", System.Data.DataRowVersion.Current, Nothing))
			'
			'dsOperatoriPerData
			'
			Me.dsOperatoriPerData.DataSetName = "DS_OperatoriPerData"
			Me.dsOperatoriPerData.Locale = New System.Globalization.CultureInfo("en-US")
			'
			'dsOperatoriPerIntervallo
			'
			Me.dsOperatoriPerIntervallo.DataSetName = "DS_OperatoriPerIntervallo"
			Me.dsOperatoriPerIntervallo.Locale = New System.Globalization.CultureInfo("en-US")
			'
			'daOperatoriAttivi
			'
			Me.daOperatoriAttivi.SelectCommand = Me.cmdSelectOperatoriAttivi
			Me.daOperatoriAttivi.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "COMMUNICATION_PARTNER", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("COMMUNICATION_PARTNER_DB_NO", "COMMUNICATION_PARTNER_DB_NO")})})
			'
			'cmdSelectOperatoriAttivi
			'
			Me.cmdSelectOperatoriAttivi.CommandText = "SELECT DISTINCT COMMUNICATION_PARTNER_DB_NO FROM COMMUNICATION_PARTNER WHERE (STA" & _
			"TUS_CD = 'ACT') AND (NOT (COMMUNICATION_PARTNER_NM LIKE 'XX%' OR COMMUNICATION_P" & _
			"ARTNER_NM LIKE 'ZZ%')) ORDER BY COMMUNICATION_PARTNER_DB_NO"
			Me.cmdSelectOperatoriAttivi.Connection = Me.oraOleDbConn
			'
			'dsOperatoriAttivi
			'
			Me.dsOperatoriAttivi.DataSetName = "DS_OperatoriAttivi"
			Me.dsOperatoriAttivi.Locale = New System.Globalization.CultureInfo("en-US")
			CType(Me.dsOperatoriPerData, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.dsOperatoriPerIntervallo, System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.dsOperatoriAttivi, System.ComponentModel.ISupportInitialize).EndInit()

		End Sub

#End Region


        Private Function GetConnectionString() As String
            Dim connString As String = ConfigurationSettings.AppSettings("OraConnectionString")
            If connString Is Nothing Then
                Throw New ApplicationException("File di configurazione connessione ERRATO!")
            End If
            Return connString
        End Function


        '
        ' Funzione di conversione da data  in formato DateTime a data in formato
        ' YYYYMMDD
        '
        Private Function ConvertDateTimeToYYYYMMDD(ByVal DataToConv As DateTime) As Integer
            Dim dateConv As Integer
            dateConv = DataToConv.Year * 10000 + DataToConv.Month * 100 + DataToConv.Day
            Return dateConv
        End Function


        '
        ' Funzione di conversione da data  in formato DateTime a data in formato
        ' YYYYMMDD: se non ci riesce setta il valore al valore di default 
        ' specificato
        '
        Private Function ConvertYYYYMMDDToDateTime(ByVal DataToConv As Integer, ByVal defaultValue As DateTime) As DateTime
            Dim dateConv As DateTime = New DateTime
            dateConv = defaultValue
            Dim year As Integer
            Dim month As Integer
            Dim day As Integer
            If DataToConv <> 0 Then
                year = DataToConv / 10000
                month = (DataToConv - year * 10000) / 100
                day = DataToConv - year * 10000 - month * 100
                Try
                    dateConv = New DateTime(year, month, day)
                Catch ex As Exception
                    dateConv = defaultValue
                End Try
            End If
            Return dateConv
        End Function

        '
        ' Ritorna gli operatori del mercato elettrico attivi
        '
        ' La query SQL e' la seguente:
        '
        ' SELECT
        '   DISTINCT C.COMMUNICATION_PARTNER_DB_NO
        ' FROM
        '  COMMUNICATION_PARTNER C
        ' WHERE 
        '  C.STATUS_CD='ACT'
        ' ORDER BY C.COMMUNICATION_PARTNER_DB_NO ASC
        '
        Public Sub OperatoriMEAttivi(ByRef OperatoriAbilitatiMGP() As String)
            Dim countRows As Integer
            Dim commRow As DS_OperatoriAttivi.COMMUNICATION_PARTNERRow
            
            Try
                oraOleDbConn.ConnectionString = GetConnectionString()
                oraOleDbConn.Open()
                daOperatoriAttivi.Fill(dsOperatoriAttivi)
                ReDim OperatoriAbilitatiMGP(dsOperatoriAttivi.COMMUNICATION_PARTNER.Count - 1)
                countRows = 0
                For Each commRow In dsOperatoriAttivi.COMMUNICATION_PARTNER.Rows
                    OperatoriAbilitatiMGP(countRows) = commRow.COMMUNICATION_PARTNER_DB_NO
                    countRows = countRows + 1
                Next
            Catch ex As Exception
                'Console.WriteLine("Exception ==>" + ex.Message)
                Throw
            Finally
				If oraOleDbConn.State = ConnectionState.Open Then oraOleDbConn.Close()
			End Try
        End Sub



        '
        ' Ritorna gli operatori del mercato elettrico abilitati 
        ' che possono fare offerte su MGP in una certa data
        '
        ' La query eseguita (un po' complessa invero, perche'
        '   START_DT = 0 significa in realta START_DT = DateTime.MinValue (-infinito)
        '   END_DT = 0 significa in realta END_DT = DateTime.MaxValue (+infinito)
        ' ) e' data da:
        '
        ' SELECT
        '   DISTINCT C.COMMUNICATION_PARTNER_DB_NO
        ' FROM
        '   USER_FIELD_DATA UDATA,COMMUNICATION_PARTNER C,USER_FIELD_DEFINITION UDEF 
        ' WHERE
        ' UDATA.RELATED_ID = C.COMMUNICATION_PARTNER_ID AND UDATA.FIELD_DEF_ID = 
        ' UDEF.FIELD_DEF_ID AND((C.STATUS_CD = 'ACT')AND(UDEF.FIELD_NM = 'Market Eligibility')
        ' AND(UDEF.RELATED_CLASS_NM = 'cCommunicationPartner')AND(UDATA.VALUE_TX = 'ALL')
        ' AND (UDATA.VALUE_TX = 'ALL') AND (UDATA.START_DT = 0 OR UDATA.START_DT <= DataRicercaYYYYMMDD) AND 
        '  (UDATA.END_DT = 0 OR UDATA.END_DT >= DataRicercaYYYYMMDD) ORDER BY C.COMMUNICATION_PARTNER_DB_NO ASC
        '
        Public Sub OperatoriAbilitatiMGPPerData(ByVal DataRicerca As DateTime, ByRef OperatoriAbilitatiMGP() As String)
            Dim DataRicercaYYYYMMDD As Integer = ConvertDateTimeToYYYYMMDD(DataRicerca)
            Dim countRows As Integer
            Dim commRow As DS_OperatoriPerData.COMMUNICATION_PARTNERRow

            Try
                oraOleDbConn.ConnectionString = GetConnectionString()
                oraOleDbConn.Open()
                cmdSelectOperatoriPerData.Parameters("START_DT").Value = DataRicercaYYYYMMDD
                cmdSelectOperatoriPerData.Parameters("END_DT").Value = DataRicercaYYYYMMDD
                daOperatoriPerData.Fill(dsOperatoriPerData)
                ReDim OperatoriAbilitatiMGP(dsOperatoriPerData.COMMUNICATION_PARTNER.Count - 1)
                countRows = 0
                For Each commRow In dsOperatoriPerData.COMMUNICATION_PARTNER.Rows
                    OperatoriAbilitatiMGP(countRows) = commRow.COMMUNICATION_PARTNER_DB_NO
                    countRows = countRows + 1
                Next
            Catch ex As Exception
                'Console.WriteLine("Exception ==>" + ex.Message)
                Throw
            Finally
				If oraOleDbConn.State = ConnectionState.Open Then oraOleDbConn.Close()
			End Try
        End Sub

        '
        ' Ritorna i codici degli operatori del mercato elettrico abilitati 
        ' che possono fare offerte su MGP in un certo intervallo di date
        ' Visto che viene specificato un intervallo di date di ricerca, vengono restituiti
        ' anche DataInizioValidita e DataFineValidita effettivi (potrebbero essere diversi
        ' dalle date di ricerca)
        '
        ' La query eseguita (un po' complessa invero, perche'
        '   START_DT = 0 significa in realta START_DT = DateTime.MinValue (-infinito)
        '   END_DT = 0 significa in realta END_DT = DateTime.MaxValue (+infinito)
        ' ) e' data da:
        '
        ' SELECT
        '   DISTINCT C.COMMUNICATION_PARTNER_DB_NO,UDATA.START_DT,UDATA.END_DT 
        ' FROM
        '   USER_FIELD_DATA UDATA,COMMUNICATION_PARTNER C,USER_FIELD_DEFINITION UDEF 
        ' WHERE
        ' UDATA.RELATED_ID = C.COMMUNICATION_PARTNER_ID AND UDATA.FIELD_DEF_ID = 
        ' UDEF.FIELD_DEF_ID AND((C.STATUS_CD = 'ACT')AND(UDEF.FIELD_NM = 'Market Eligibility')
        ' AND(UDEF.RELATED_CLASS_NM = 'cCommunicationPartner')AND(UDATA.VALUE_TX = 'ALL')
        ' AND(UDATA.START_DT = 0)AND(UDATA.END_DT = 0)
        ' OR
        ' (C.STATUS_CD = 'ACT')
        ' AND(UDEF.FIELD_NM = 'Market Eligibility')AND(UDEF.RELATED_CLASS_NM = 'cCommunicationPartner')
        ' AND(UDATA.VALUE_TX = 'ALL')AND(UDATA.START_DT = 0)AND(UDATA.END_DT>=DataInizioRicercaYYYYMMDD)
        ' OR
        ' (C.STATUS_CD = 'ACT')AND(UDEF.FIELD_NM = 'Market Eligibility')
        ' AND(UDEF.RELATED_CLASS_NM = 'cCommunicationPartner')AND(UDATA.VALUE_TX = 'ALL')
        ' AND(UDATA.START_DT<= DataFineRicercaYYYYMMDD)AND(UDATA.END_DT = 0)
        ' OR
        ' (C.STATUS_CD = 'ACT')
        ' AND(UDEF.FIELD_NM = 'Market Eligibility')AND(UDEF.RELATED_CLASS_NM = 'cCommunicationPartner')
        ' AND(UDATA.VALUE_TX = 'ALL')AND(UDATA.START_DT<>0)AND(UDATA.END_DT<>0)
        ' AND(UDATA.START_DT<= DataFineRicercaYYYYMMDD)AND(UDATA.END_DT>= DataInizioRicercaYYYYMMDD))
        ' ORDER BY
        ' C.COMMUNICATION_PARTNER_DB_NO ASC
        '
        Public Sub OperatoriAbilitatiMGPPerIntervalloDate(ByVal DataInizio As DateTime, ByVal DataFine As DateTime, ByRef OperatoriAbilitatiMGP() As String, _
                                      ByRef DataInizioValidita() As DateTime, ByRef DataFineValidita() As DateTime)
            Dim DataInizioRicercaYYYYMMDD As Integer = ConvertDateTimeToYYYYMMDD(DataInizio)
            Dim DataFineRicercaYYYYMMDD As Integer = ConvertDateTimeToYYYYMMDD(DataFine)
            Dim countRows As Integer
            Dim udataRow As DS_OperatoriPerIntervallo.USER_FIELD_DATARow

            Try
                oraOleDbConn.ConnectionString = GetConnectionString()
                oraOleDbConn.Open()
                cmdSelectOperatoriPerIntervallo.Parameters("END_DT").Value = DataInizioRicercaYYYYMMDD
                cmdSelectOperatoriPerIntervallo.Parameters("START_DT").Value = DataFineRicercaYYYYMMDD
                cmdSelectOperatoriPerIntervallo.Parameters("START_DT1").Value = DataFineRicercaYYYYMMDD
                cmdSelectOperatoriPerIntervallo.Parameters("END_DT1").Value = DataInizioRicercaYYYYMMDD
                daOperatoriPerIntervallo.Fill(dsOperatoriPerIntervallo)

                ReDim OperatoriAbilitatiMGP(dsOperatoriPerIntervallo.USER_FIELD_DATA.Count - 1)
                ReDim DataInizioValidita(dsOperatoriPerIntervallo.USER_FIELD_DATA.Count - 1)
                ReDim DataFineValidita(dsOperatoriPerIntervallo.USER_FIELD_DATA.Count - 1)
                countRows = 0
                For Each udataRow In dsOperatoriPerIntervallo.USER_FIELD_DATA.Rows
                    OperatoriAbilitatiMGP(countRows) = udataRow.COMMUNICATION_PARTNER_DB_NO
                    DataInizioValidita(countRows) = ConvertYYYYMMDDToDateTime(udataRow.START_DT, DateTime.MinValue)
                    DataFineValidita(countRows) = ConvertYYYYMMDDToDateTime(udataRow.END_DT, DateTime.MaxValue)
                    countRows = countRows + 1
                Next

            Catch ex As Exception
                'Console.WriteLine("Exception ==>" + ex.Message)
                Throw
            Finally
				If oraOleDbConn.State = ConnectionState.Open Then oraOleDbConn.Close()
			End Try
        End Sub
    End Class

End Namespace
