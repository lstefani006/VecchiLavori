Imports System.Runtime.Serialization.Formatters.Binary
Imports System.IO
Imports System.Text
Imports System.Configuration

Namespace Bil_GMELogic

    Class FileInfoWithComparer
        Public m_FileInfo As FileInfo

        Public Class FileLastWriteComparer
            Implements IComparer
            Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
                ' due oggetti nulli sono uguali
                If (x Is Nothing) And (y Is Nothing) Then Return 0
                ' Ogni oggetto nullo e' piu' piccolo di un oggetto non nullo
                If (x Is Nothing) Then Return 1
                If (y Is Nothing) Then Return -1

                '
                ' Stessi check sull'oggetto contenuto
                '
                If (CType(x, FileInfoWithComparer).m_FileInfo Is Nothing) And (CType(y, FileInfoWithComparer).m_FileInfo Is Nothing) Then
                    Return 0
                End If
                If (CType(x, FileInfoWithComparer).m_FileInfo Is Nothing) Then
                    Return 1
                End If
                If (CType(y, FileInfoWithComparer).m_FileInfo Is Nothing) Then
                    Return -1
                End If

                '
                ' check finale
                '
                If CType(x, FileInfoWithComparer).m_FileInfo.LastWriteTime = CType(y, FileInfoWithComparer).m_FileInfo.LastWriteTime Then
                    Return 0
                Else
                    If CType(x, FileInfoWithComparer).m_FileInfo.LastWriteTime > CType(y, FileInfoWithComparer).m_FileInfo.LastWriteTime Then
                        Return 1
                    Else
                        Return -1
                    End If
                End If
            End Function
        End Class

        Public Class FileCreationComparer
            Implements IComparer
            Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
                ' due oggetti nulli sono uguali
                If (x Is Nothing) And (y Is Nothing) Then Return 0
                ' Ogni oggetto nullo e' piu' piccolo di un oggetto non nullo
                If (x Is Nothing) Then Return 1
                If (y Is Nothing) Then Return -1

                '
                ' Stessi check sull'oggetto contenuto
                '
                If (CType(x, FileInfoWithComparer).m_FileInfo Is Nothing) And (CType(y, FileInfoWithComparer).m_FileInfo Is Nothing) Then
                    Return 0
                End If
                If (CType(x, FileInfoWithComparer).m_FileInfo Is Nothing) Then
                    Return 1
                End If
                If (CType(y, FileInfoWithComparer).m_FileInfo Is Nothing) Then
                    Return -1
                End If

                If CType(x, FileInfoWithComparer).m_FileInfo.CreationTime = CType(y, FileInfoWithComparer).m_FileInfo.CreationTime Then
                    Return 0
                Else
                    If CType(x, FileInfoWithComparer).m_FileInfo.CreationTime > CType(y, FileInfoWithComparer).m_FileInfo.CreationTime Then
                        Return 1
                    Else
                        Return -1
                    End If
                End If
            End Function
        End Class
    End Class



    Public Class FileLoadSave
        Inherits MarshalByRefObject

        Private Function FormatNomeFile(ByVal CodiceOperatoreSDC As String, _
                                       ByVal ACCT_NUM As String, _
                                       ByVal DOCUMENT_ID As String, _
                                       ByVal dataFattura As DateTime, _
                                       ByVal tipoFattura As String, _
                                       ByVal nomeRegistro As String _
                                       ) As String
            Dim fileName As StringBuilder = New StringBuilder
            Dim dataYYYYMMDD As String
            dataYYYYMMDD = dataFattura.ToString("yyyyMMdd")
            fileName.Append(CodiceOperatoreSDC)
            fileName.Append("_")
            fileName.Append(ACCT_NUM)
            fileName.Append("_")
            fileName.Append(tipoFattura)
            fileName.Append("_")
            fileName.Append("IDGME")
            fileName.Append("_")
            fileName.Append(nomeRegistro)
            fileName.Append("_Chunk_1_")
            fileName.Append(dataYYYYMMDD)
            fileName.Append("_")
            fileName.Append(DOCUMENT_ID)
            fileName.Append(".xml")
            Return fileName.ToString()
        End Function

        Public Function UploadFatturaAttivaGME(ByVal bIsZipped As Boolean, _
                                       ByVal CodiceOperatoreSDC As String, _
                                       ByVal ACCT_NUM As String, _
                                       ByVal DOCUMENT_ID As String, _
                                       ByVal dataFattura As DateTime, _
                                       ByVal byteStream() As Byte) As Boolean
            Dim directoryToWrite As String = ConfigurationSettings.AppSettings("UploadDirectoryFatturaAttivaGME")
            Dim tipoFattura As String = ConfigurationSettings.AppSettings("TipoFatturaCSPAttivoGME")
            Dim nomeRegistro As String = ConfigurationSettings.AppSettings("RegistroCSPAttivoGME")
            Dim fileName As String = FormatNomeFile(CodiceOperatoreSDC, ACCT_NUM, DOCUMENT_ID, dataFattura, tipoFattura, nomeRegistro)
            UploadFatturaAttivaGME = UploadFatture(directoryToWrite, bIsZipped, _
                                fileName, byteStream)
        End Function

        Public Function UploadFatturaPassivaGME(ByVal bIsZipped As Boolean, _
                                       ByVal CodiceOperatoreSDC As String, _
                                       ByVal ACCT_NUM As String, _
                                       ByVal DOCUMENT_ID As String, _
                                       ByVal dataFattura As DateTime, _
                                       ByVal byteStream() As Byte) As Boolean
            Dim directoryToWrite As String = ConfigurationSettings.AppSettings("UploadDirectoryFatturaPassivaGME")
            Dim tipoFattura As String = ConfigurationSettings.AppSettings("TipoFatturaCSPPassivoGME")
            Dim nomeRegistro As String = ConfigurationSettings.AppSettings("RegistroCSPPassivoGME")
            Dim fileName As String = FormatNomeFile(CodiceOperatoreSDC, ACCT_NUM, DOCUMENT_ID, dataFattura, tipoFattura, nomeRegistro)
            UploadFatturaPassivaGME = UploadFatture(directoryToWrite, bIsZipped, _
                                fileName, byteStream)
        End Function


        Public Function UploadFatturaOboloGME(ByVal bIsZipped As Boolean, _
                                       ByVal CodiceOperatoreSDC As String, _
                                       ByVal ACCT_NUM As String, _
                                       ByVal DOCUMENT_ID As String, _
                                       ByVal dataFattura As DateTime, _
                                       ByVal byteStream() As Byte) As Boolean

            Dim directoryToWrite As String = ConfigurationSettings.AppSettings("UploadDirectoryFatturaOboloGME")
            Dim tipoFattura As String = ConfigurationSettings.AppSettings("TipoFatturaCSPOboloGME")
            Dim nomeRegistro As String = ConfigurationSettings.AppSettings("RegistroCSPOboloGME")
            Dim fileName As String = FormatNomeFile(CodiceOperatoreSDC, ACCT_NUM, DOCUMENT_ID, dataFattura, tipoFattura, nomeRegistro)
            UploadFatturaOboloGME = UploadFatture(directoryToWrite, bIsZipped, _
                                fileName, byteStream)
        End Function

        Private Function UploadFatture(ByVal directoryToWrite As String, ByVal bIsZipped As Boolean, _
                                ByVal FileName As String, ByVal byteStream() As Byte) As Boolean
            Dim Directory As String = directoryToWrite
            Dim DirLength As Int32 = Directory.Length
            Dim FileNameLength As Int32 = FileName.Length

            Dim FileWrite As StringBuilder = New StringBuilder(DirLength + FileNameLength + 2)
            Dim f As FileInfo
            Dim fStream As FileStream

            Dim dummy As String
            Dim unzippedby() As Byte

            UploadFatture = False
            FileWrite.Append(Directory)
            FileWrite.Append("\\")
            FileWrite.Append(FileName)
            Try
                If (bIsZipped) Then
                    unzippedby = Bil.BilZipLib.UnzipSingleFile(byteStream, dummy)
                Else
                    unzippedby = byteStream
                End If

                f = New FileInfo(FileWrite.ToString())
                fStream = f.OpenWrite()
                fStream.Write(unzippedby, 0, unzippedby.Length)
                fStream.Close()
                UploadFatture = True
            Catch ex As Exception
                UploadFatture = False
            End Try
        End Function


        '
        ' Upload di un byteStream zipped su una directory determinata: prima di copiare il
        ' file deve fare Unzip
        '
        Public Function UploadFile(ByVal FileName As String, _
                                   ByVal byteStream() As Byte, _
                                   ByVal streamLength As Int32) As Boolean


            Dim dummy As String
            UploadFile = False
            Try
                Dim unzippedby() As Byte = Bil.BilZipLib.UnzipSingleFile(byteStream, dummy)
                UploadFile = UploadFileNotZipped(FileName, unzippedby, unzippedby.Length())
            Catch ex As Exception
                UploadFile = False
            End Try
        End Function

        '
        ' Upload di un byteStream non zipped  su una directory determinata: copia
        ' semplicemente il byteStream sulla directory
        '
        Public Function UploadFileNotZipped(ByVal FileName As String, _
                                           ByVal byteStream() As Byte, _
                                           ByVal streamLength As Int32) As Boolean

            Dim Directory As String = ConfigurationSettings.AppSettings("UploadDirectory")
            Dim DirLength As Int32 = Directory.Length
            Dim FileNameLength As Int32 = FileName.Length


            Dim FileWrite As StringBuilder = New StringBuilder(DirLength + FileNameLength + 2)
            Dim f As FileInfo
            Dim fStream As FileStream
            UploadFileNotZipped = False
            FileWrite.Append(Directory)
            FileWrite.Append("\\")
            FileWrite.Append(FileName)
            Try
                f = New FileInfo(FileWrite.ToString())
                fStream = f.OpenWrite()
                fStream.Write(byteStream, 0, streamLength)
                fStream.Close()
                UploadFileNotZipped = True
            Catch ex As Exception
                UploadFileNotZipped = False
            End Try
        End Function



        '
        ' Download di un byteStream su una directory determinata: prima carica il file
        ' e poi esegue lo zip
        '
        Public Function DownloadFileZipped(ByRef FileName As String, _
                                   ByRef byteStream() As Byte, _
                                   ByRef streamLength As Int32) As Boolean

            Dim bResult As Boolean = False
            Dim byNotZipped() As Byte
            Dim strNotZippedLength As Int32

            Try
                bResult = DownloadFile(FileName, byNotZipped, strNotZippedLength)
                If bResult Then
                    byteStream = Bil.BilZipLib.ZipSingleFile(FileName, byNotZipped, 9)
                    streamLength = byteStream.Length()
                    DownloadFileZipped = True
                Else
                    DownloadFileZipped = False
                End If
            Catch ex As Exception
                DownloadFileZipped = False
            End Try
        End Function


        '
        ' Download di un byteStream su una directory determinata (non zipped)
        '
        Public Function DownloadFile(ByRef FileName As String, _
                                   ByRef byteStream() As Byte, _
                                   ByRef streamLength As Int32) As Boolean

            Dim Directory As String = ConfigurationSettings.AppSettings("DownloadDirectory")
            Dim Extension As String = ConfigurationSettings.AppSettings("DownloadFilterExtension")
            Dim DirLength As Int32 = Directory.Length
            Dim f As FileInfo
            Dim fStream As FileStream
            DownloadFile = False
            Dim FilesInDirectory As StringBuilder = New StringBuilder(DirLength)
            Dim dirInfo As DirectoryInfo
            FilesInDirectory.Append(Directory)

            Try
                dirInfo = New DirectoryInfo(FilesInDirectory.ToString())
                ' Get a reference to each file in that directory.
                Dim fileArray As FileInfo() = dirInfo.GetFiles(Extension)
                If fileArray.Length > 0 Then
                    '
                    ' Ordina i files per LastWriteTime crescente
                    '
                    Dim fileArrayWithComparer() As FileInfoWithComparer
                    Dim i As Integer
                    ReDim fileArrayWithComparer(fileArray.Length - 1)
                    For i = 0 To fileArray.Length - 1
                        fileArrayWithComparer(i) = New FileInfoWithComparer
                        fileArrayWithComparer(i).m_FileInfo = fileArray(i)
                    Next
                    Array.Sort(fileArrayWithComparer, New FileInfoWithComparer.FileLastWriteComparer)

                    '
                    ' Prendi il primo
                    '
                    FileName = fileArrayWithComparer(0).m_FileInfo.Name

                    '
                    ' Leggi lo stream
                    '
                    streamLength = fileArrayWithComparer(0).m_FileInfo.Length

                    '
                    ' Dimensiona a length-1 perche' se re-dimensionati a K
                    ' l'array in VB.NET va da 0 a K (K+1 elementi)  
                    '
                    ReDim byteStream(streamLength - 1)
                    fStream = fileArrayWithComparer(0).m_FileInfo.OpenRead()
                    fStream.Read(byteStream, 0, streamLength)
                    fStream.Close()
                    DownloadFile = True
                Else
                    FileName = ""
                    streamLength = 0
                    DownloadFile = False
                End If
            Catch ex As Exception
                DownloadFile = False
            End Try
        End Function

        '
        ' RemoveFirstFile di un byteStream su una directory determinata
        '
        Public Function RemoveFirstFile() As Boolean
            Dim Directory As String = ConfigurationSettings.AppSettings("DownloadDirectory")
            Dim Extension As String = ConfigurationSettings.AppSettings("DownloadFilterExtension")
            Dim DirLength As Int32 = Directory.Length
            Dim f As FileInfo
            Dim fStream As FileStream
            RemoveFirstFile = False
            Dim FilesInDirectory As StringBuilder = New StringBuilder(DirLength)
            Dim dirInfo As DirectoryInfo
            FilesInDirectory.Append(Directory)

            Try
                dirInfo = New DirectoryInfo(FilesInDirectory.ToString())
                ' Get a reference to each file in that directory.
                Dim fileArray As FileInfo() = dirInfo.GetFiles(Extension)
                If fileArray.Length > 0 Then
                    '
                    ' Ordina i files per LastWriteTime crescente
                    '
                    Dim fileArrayWithComparer() As FileInfoWithComparer
                    Dim i As Integer
                    ReDim fileArrayWithComparer(fileArray.Length - 1)
                    For i = 0 To fileArray.Length - 1
                        fileArrayWithComparer(i) = New FileInfoWithComparer
                        fileArrayWithComparer(i).m_FileInfo = fileArray(i)
                    Next
                    Array.Sort(fileArrayWithComparer, New FileInfoWithComparer.FileLastWriteComparer)
                    '
                    ' Cancella il primo
                    '
                    fileArrayWithComparer(0).m_FileInfo.Delete()
                    RemoveFirstFile = True
                Else
                    RemoveFirstFile = False
                End If
            Catch ex As Exception
                RemoveFirstFile = False
            End Try
        End Function


        Public Function GetNextFilesToDownload(ByRef fileNameArray() As String, _
                                                ByRef numberOfFile As Int32) As Boolean
            Dim Directory As String = ConfigurationSettings.AppSettings("DownloadDirectory")
            Dim Extension As String = ConfigurationSettings.AppSettings("DownloadFilterExtension")
            Dim DirLength As Int32 = Directory.Length
            Dim fileCount As Int32
            Dim f As FileInfo
            Dim fStream As FileStream
            GetNextFilesToDownload = False
            Dim FilesInDirectory As StringBuilder = New StringBuilder(DirLength)
            Dim dirInfo As DirectoryInfo
            FilesInDirectory.Append(Directory)

            Try
                dirInfo = New DirectoryInfo(FilesInDirectory.ToString())
                ' Get a reference to each file in that directory.
                Dim fileArray As FileInfo() = dirInfo.GetFiles(Extension)
                If fileArray.Length > 0 Then
                    '
                    ' Ordina i files per LastWriteTime crescente
                    '
                    Dim fileArrayWithComparer() As FileInfoWithComparer
                    Dim i As Integer
                    ReDim fileArrayWithComparer(fileArray.Length - 1)
                    For i = 0 To fileArray.Length - 1
                        fileArrayWithComparer(i) = New FileInfoWithComparer
                        fileArrayWithComparer(i).m_FileInfo = fileArray(i)
                    Next
                    Array.Sort(fileArrayWithComparer, New FileInfoWithComparer.FileLastWriteComparer)

                    '
                    ' Copia i nomi dei files
                    '
                    ReDim fileNameArray(fileArrayWithComparer.Length - 1)
                    numberOfFile = fileArrayWithComparer.Length
                    For fileCount = 0 To fileArrayWithComparer.Length - 1
                        fileNameArray(fileCount) = fileArrayWithComparer(fileCount).m_FileInfo.Name
                    Next
                    GetNextFilesToDownload = True
                Else
                    numberOfFile = 0
                    GetNextFilesToDownload = False
                End If
            Catch ex As Exception
                GetNextFilesToDownload = False
            End Try
        End Function

    End Class
End Namespace
