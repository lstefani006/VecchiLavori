using System;
using System.Text;
using System.Configuration;


namespace Bil_TestDownloadCRL
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			Bil_Crypt.WSClient.SetCertificatePolicy(null);

			string useWS = ConfigurationSettings.AppSettings["CRLDownload_useWS"];
			bool bUseWS = false;
			if ((useWS != null) && (useWS != string.Empty))
			{
				useWS = useWS.ToLower();
				if ((useWS == "1") || (useWS == "si") || (useWS=="yes") || (useWS=="true"))
					bUseWS = true;
			}
        
			int timeOut = 30;
			if (true)
			{
				string s = ConfigurationSettings.AppSettings["Certificate_CRLDownloadTimeout"];
				try { timeOut = int.Parse(s); } 
				catch {}
			}


			bool bOk  = false;
			//
			// Actalis LDAP
			//
			// string urlToDownload = @"ldap://ldap.actalis.it/cn%3DActalis%20Qualified%20Certificates%20CA%2Cou%3DCertification%20Service%20Provider%2Co%3DActalis%20S.p.A.%2Cc%3DIT?certificateRevocationList;binary";

			//
			// GRTN LDAP
			//
			string urlToDownload =@"ldap://ldap.grtn.it/ou=CA%20GRTN,o=GRTN,c=it?certificateRevocationList;binary";


			CertPInvokeLib.CryptCRL.CRLEntry [] crlEntries = null;
			DateTime currentTime = DateTime.MinValue;
			DateTime nextTime = DateTime.MinValue;

			try
			{
				if (bUseWS) 
				{
					WebReference.CRL w = new WebReference.CRL();
					w.WSAuthHeaderValue = new WebReference.WSAuthHeader();
					Bil_Crypt.WSClient.Setup(w, ref w.WSAuthHeaderValue.Username, ref w.WSAuthHeaderValue.Password, "Bil_MGPBridgeWS_CRL");

					WebReference.CRLEntry[] r = w.Download(urlToDownload, timeOut, ref currentTime, ref nextTime);
					crlEntries = new CertPInvokeLib.CryptCRL.CRLEntry[r.Length];
					for (int i = 0; i < r.Length; ++i)
					{

						crlEntries[i] = new CertPInvokeLib.CryptCRL.CRLEntry();
						if (Enum.IsDefined(typeof(CertPInvokeLib.CryptCRL.CrlReasonCode), r[i].reason))
							crlEntries[i].reason = (CertPInvokeLib.CryptCRL.CrlReasonCode)r[i].reason;
						else
							crlEntries[i].reason = CertPInvokeLib.CryptCRL.CrlReasonCode.unspecified;
						crlEntries[i].revocationDate = r[i].revocationDate;
						crlEntries[i].serialNumber = r[i].serialNumber;
					}
					bOk = true;
				}
				else
				{
					CertPInvokeLib.CryptCRL d = new CertPInvokeLib.CryptCRL(urlToDownload, CertPInvokeLib.CryptCRL.CrlDownloadType.NetworkCrlDownloadOnly, timeOut);
					d.GetAllCRLData(true, out currentTime, out nextTime, out crlEntries);
					bOk = true;
				}
			}
			catch (CertPInvokeLib.CertException cErr)
			{
				Console.WriteLine("CertException: msg = " + cErr.Message + " Codice = " + cErr.Win32Error);
			}
			catch (Exception err)
			{
				Console.WriteLine (err.Message);
			}
			if (bOk) 
			{
				Console.WriteLine("currentDate = " + currentTime.ToShortDateString());
				Console.WriteLine("currentTime = " + currentTime.ToLongTimeString());
				Console.WriteLine("nextDate = " + nextTime.ToShortDateString());
				Console.WriteLine("nextTime = " + nextTime.ToLongTimeString());
				for (int i=0; i< crlEntries.Length; i++)
				{
					StringBuilder szSerialNumber = new StringBuilder();
					for (int j=0; j<crlEntries[i].serialNumber.Length; j++)
					{
						szSerialNumber.Append(crlEntries[i].serialNumber[j].ToString("X2"));
					}
					Console.WriteLine ("Serial Number = "  + szSerialNumber.ToString() + "  Revoc Date = " +crlEntries[i].revocationDate.ToShortDateString()+ " Reason = " + Enum.GetName(typeof(CertPInvokeLib.CryptCRL.CrlReasonCode), crlEntries[i].reason));
				}
			}



		}
	}
}
