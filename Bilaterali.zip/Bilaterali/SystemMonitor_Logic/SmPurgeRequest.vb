Public Class SmPurgeRequest
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New(Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cn As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdInsert As System.Data.SqlClient.SqlCommand
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cn = New System.Data.SqlClient.SqlConnection
        Me.cmdInsert = New System.Data.SqlClient.SqlCommand
        '
        'cmdInsert
        '
        Me.cmdInsert.Connection = Me.cn

    End Sub

#End Region

    Public Sub RicevutaRichiestaPermessoCancellazioneFile(ByVal nomeFile As String, ByVal descrizione As String, ByVal tcpIpAddr As String)
        ' Questa procedura verra' chiamata solo se il computer su cui
        ' gira il processo e' configurato per essere il server e se un computer
		' client ha eseguito la procedura "RichiestaPermessoCancellazioneFile"


        Dim SqlConnectionString As String
		SqlConnectionString = System.Configuration.ConfigurationSettings.AppSettings("SqlConnectionString")

		Try
			cn.ConnectionString = SqlConnectionString
			cn.Open()

			Dim cmd As String
			cmd = "INSERT INTO RichiestaCancellazione "
			cmd = cmd + "(IdRichiestaCancellazione, AddrSender, PathFile, Descrizione, TSRichiesta) "
			cmd = cmd + " VALUES "
			cmd = cmd + "(@IdRic, @Addr, @Path, @Descr, @TS)"

			cmdInsert.CommandText = cmd

			Dim Id As String
			Id = Guid.NewGuid().ToString("N").ToUpper()

			Dim TimeStamp As DateTime
			TimeStamp = DateTime.Now

			cmdInsert.Parameters.Add("@IdRic", Id)
			cmdInsert.Parameters.Add("@Addr", tcpIpAddr)
			cmdInsert.Parameters.Add("@Path", nomeFile)
			cmdInsert.Parameters.Add("@Descr", descrizione)
			cmdInsert.Parameters.Add("@TS", TimeStamp)

			Try
				cmdInsert.ExecuteNonQuery()
			Catch ex As Exception
				SystemMonitor.SmLog.smError(ex, "Errore su insert della richiesta di cancellazione file.")
				Throw New System.Exception("Errore su insert della richiesta di cancellazione file.")
			End Try

		Finally
			If cn.State = ConnectionState.Open Then cn.Close()
		End Try

    End Sub

    Public Sub RichiestaPermessoCancellazioneFile(ByVal nomeFile As String, ByVal descrizione As String, ByVal tcpIpAddr As String)
        ' La richiesta del permesso di cancellare un determinato file
        ' viene inoltrata al server effettuando una chiamata remota al
        ' metodo "RicevutaRichiestaPermessoCancellazioneFile"
        
        Dim url As String
        url = System.Configuration.ConfigurationSettings.AppSettings("SmPurgeRequest")
        Try
            Dim c As Object
            c = Activator.GetObject(GetType(SmPurgeRequest), url)
            Dim p As SmPurgeRequest
            p = CType(c, SmPurgeRequest)
            p.RicevutaRichiestaPermessoCancellazioneFile(nomeFile, descrizione, tcpIpAddr)
            SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceInfo, "Inoltrata richiesta cancellazione file: " + nomeFile + " !")
        Catch ex As Exception
            SystemMonitor.SmLog.smError(ex, "Errore su RichiestaPermessoCancellazioneFile().")
            Throw New System.Exception("Errore su RichiestaPermessoCancellazioneFile().")
        End Try

    End Sub

End Class
