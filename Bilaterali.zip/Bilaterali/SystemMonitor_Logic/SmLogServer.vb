Imports System.Xml
Imports System.Text
Imports System.Data.SqlClient
Imports System.Collections.Specialized

Public Class SmLogServer
	Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

	Public Sub New(ByVal Container As System.ComponentModel.IContainer)
		MyClass.New()

		'Required for Windows.Forms Class Composition Designer support
		Container.Add(Me)
	End Sub

	Public Sub New()
		MyBase.New()

		'This call is required by the Component Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call
		cn.ConnectionString = System.Configuration.ConfigurationSettings.AppSettings("SqlConnectionString")
	End Sub

	'Component overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Component Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Component Designer
	'It can be modified using the Component Designer.
	'Do not modify it using the code editor.
	Friend WithEvents cn As System.Data.SqlClient.SqlConnection
	Friend WithEvents daSmLog As System.Data.SqlClient.SqlDataAdapter
	Friend WithEvents cmdSmLog_Select As System.Data.SqlClient.SqlCommand
	Friend WithEvents cmdSmLog_Insert As System.Data.SqlClient.SqlCommand
	Friend WithEvents dsSmLog As SystemMonitor.DsSmLog
	Friend WithEvents cmdSmLog_Delete As System.Data.SqlClient.SqlCommand
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.cn = New System.Data.SqlClient.SqlConnection
		Me.daSmLog = New System.Data.SqlClient.SqlDataAdapter
		Me.cmdSmLog_Insert = New System.Data.SqlClient.SqlCommand
		Me.cmdSmLog_Select = New System.Data.SqlClient.SqlCommand
		Me.dsSmLog = New SystemMonitor.DsSmLog
		Me.cmdSmLog_Delete = New System.Data.SqlClient.SqlCommand
		CType(Me.dsSmLog, System.ComponentModel.ISupportInitialize).BeginInit()
		'
		'cn
		'
        Me.cn.ConnectionString = "user id=bil_user;data source=.;persist security info=True;initial catalog=B" & _
        "ilaterali;password=bilaterali"
		'
		'daSmLog
		'
		Me.daSmLog.DeleteCommand = Me.cmdSmLog_Delete
		Me.daSmLog.InsertCommand = Me.cmdSmLog_Insert
		Me.daSmLog.SelectCommand = Me.cmdSmLog_Select
		'
		'cmdSmLog_Insert
		'
		Me.cmdSmLog_Insert.CommandText = "INSERT INTO dbo.SmLog (Id, SmCategory, SmMessage, SmApplication, SmTS, SmExMessag" & _
		"e, SmXmlMessage) VALUES (@Id, @SmCategory, @SmMessage, @SmApplication, @SmTS, @S" & _
		"mExMessage, @SmXmlMessage)"
		Me.cmdSmLog_Insert.Connection = Me.cn
		Me.cmdSmLog_Insert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.VarChar, 32, "Id"))
		Me.cmdSmLog_Insert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SmCategory", System.Data.SqlDbType.VarChar, 32, "SmCategory"))
		Me.cmdSmLog_Insert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SmMessage", System.Data.SqlDbType.VarChar, 256, "SmMessage"))
		Me.cmdSmLog_Insert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SmApplication", System.Data.SqlDbType.VarChar, 256, "SmApplication"))
		Me.cmdSmLog_Insert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SmTS", System.Data.SqlDbType.DateTime, 8, "SmTS"))
		Me.cmdSmLog_Insert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SmExMessage", System.Data.SqlDbType.VarChar, 256, "SmExMessage"))
		Me.cmdSmLog_Insert.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SmXmlMessage", System.Data.SqlDbType.VarBinary, 2147483647, "SmXmlMessage"))
		'
		'cmdSmLog_Select
		'
		Me.cmdSmLog_Select.CommandText = "SELECT Id, SmCategory, SmMessage, SmApplication, SmTS, SmExMessage, SmXmlMessage " & _
		"FROM SmLog"
		Me.cmdSmLog_Select.Connection = Me.cn
		'
		'dsSmLog
		'
		Me.dsSmLog.CaseSensitive = True
		Me.dsSmLog.DataSetName = "DsSmLog"
		Me.dsSmLog.Locale = New System.Globalization.CultureInfo("it-IT")
		'
		'cmdSmLog_Delete
		'
		Me.cmdSmLog_Delete.CommandText = "DELETE FROM dbo.SmLog WHERE (Id = @Id)"
		Me.cmdSmLog_Delete.Connection = Me.cn
		Me.cmdSmLog_Delete.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.VarChar, 32, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
		CType(Me.dsSmLog, System.ComponentModel.ISupportInitialize).EndInit()

	End Sub

#End Region

	' Funzione chiamata da clienti remoti che spediscono un messaggio di log.
	' Se il messaggio e` un XML formattato opportunamente (formato cablato in SmLog.vb)
	' vengono letti i campi e riempita la tabella SmLog con tutte le informazioni
	' Se il messaggio non e` XML si riempono solo i campi SmMessage e SmTS
	Public Sub Send(ByVal message As String)
		' Il messaggio puo` essere un documento Xml.
		' Ci sono molti modi per vedere se e` l'XML che fa per noi.
		' Per ora il piu` facile --> carico l'xml e controllo i campi

		Dim xmlMessage As Boolean = False
        Dim updateDb As Boolean = False

        Dim msgDaSaltare As New StringCollection
        Try
            For nmsg As Integer = 0 To 20
                Dim sn As String = System.Configuration.ConfigurationSettings.AppSettings("SkipMsg_" + nmsg.ToString)
                If sn Is Nothing Then Exit For
                msgDaSaltare.Add(sn)
            Next
        Catch ex As Exception
        End Try

        Dim dr As DsSmLog.SmLogRow = dsSmLog.SmLog.NewSmLogRow
        Try
            Dim x As New XmlDocument
            x.LoadXml(message)

            For Each xn As XmlNode In x.SelectNodes("Log")
                dr.Id = Guid.NewGuid().ToString("N").ToUpper()

                dr.SmCategory = xn.SelectSingleNode("./Category").InnerText
                dr.SmMessage = xn.SelectSingleNode("./Message").InnerText

                Dim salvaMessaggio As Boolean = True
                If dr.SmMessage.ToUpper.StartsWith("Elaborazione PGM".ToUpper) Then
                    salvaMessaggio = False
                End If

                Try
                    For Each sss As String In msgDaSaltare
                        If dr.SmMessage.IndexOf(sss) >= 0 Then
                            salvaMessaggio = False
                            Exit For
                        End If
                    Next
                Catch ex As Exception
                End Try

                dr.SmApplication = xn.SelectSingleNode("./Application").InnerText
                dr.SmTS = XmlConvert.ToDateTime(xn.SelectSingleNode("./TS").InnerText)

                ' le eccezioni sono annidate.... compongo un testo
                ' con tutte le eccezioni
                Dim ne As XmlNode = xn.SelectSingleNode("./Exception")
                Dim exMessage As New StringBuilder
                Do
                    If (ne Is Nothing) Then Exit Do
                    exMessage.Append(ne.SelectSingleNode("./Message").InnerText())
                    exMessage.Append(Environment.NewLine())

                    ne = ne.SelectSingleNode("./Exception")
                Loop
                If (exMessage.Length > 0) Then
                    If (exMessage.Length > 1024) Then
                        dr.SmExMessage = exMessage.ToString(0, 1024)
                    Else
                        dr.SmExMessage = exMessage.ToString()
                    End If
                Else
                    dr.SetSmExMessageNull()
                End If

                dr.SmXmlMessage = Encoding.UTF8.GetBytes(message)

                If salvaMessaggio Then
                    dsSmLog.SmLog.AddSmLogRow(dr)
                End If


#If DEBUG Then
                Console.WriteLine("{0}", "#####################################################")
                Console.WriteLine("{0}", message)
                Console.WriteLine("{0}", "#####################################################")
#End If
                xmlMessage = True
                updateDb = True
                Exit For

                ' non faccio un secondo loop perche` un XML contiene un solo messaggio
            Next
        Catch ex As Exception
            ' se sono qui non era un XML.... memorizzo il messaggio in chiaro
        End Try

        ' se sono qui il messaggio non era un XML.
        If (xmlMessage = False) Then
            Try
                ' lo memorizzo come messaggio semplice nella tabella
                dr.Id = Guid.NewGuid().ToString("N").ToUpper()
                dr.SmCategory = "Trace"
                dr.SmMessage = message
                dr.SetSmApplicationNull()
                dr.SmTS = DateTime.Now()
                dr.SetSmExMessageNull()
                dr.SetSmXmlMessageNull()
                dsSmLog.SmLog.AddSmLogRow(dr)
                updateDb = True
            Catch ex As Exception
                ' se sono qui e` un vero peccato
            End Try
        End If

        If (updateDb) Then
            Try
                daSmLog.Update(dsSmLog.SmLog)
            Catch ex As Exception
                ' se sono qui e` un vero peccato
            End Try
        End If
    End Sub

	Private Function AppSettingToBoolean(ByVal s As String, ByVal b As Boolean) As Boolean
		Dim v As String = System.Configuration.ConfigurationSettings.AppSettings(s)
		If v Is Nothing Then Return b

		v = v.ToLower.Trim
		If v = "si" OrElse v = "yes" OrElse v = "true" OrElse v = "1" Then
			Return True
		ElseIf v = "no" OrElse v = "false" OrElse v = "0" Then
			Return False
		End If

		Return b
	End Function


	Public Function GetLog(ByVal dataMin As DateTime, ByVal smCategory As String) As SystemMonitor.DsSmLog

		If AppSettingToBoolean("GG_Collect", False) Then
			GC.Collect()
			If AppSettingToBoolean("GG_WaitForPendingFinalizers", False) Then
				GC.WaitForPendingFinalizers()
			End If
		End If


		Try
			Dim s As String
			s = "SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED "
			s += "SELECT top 1000 Id, SmCategory, SmMessage, SmApplication, SmTS, SmExMessage, SmXmlMessage "
			s += "FROM SmLog "
			s += "WHERE SmTS >= @ts and SmTS < @tf "

			If Not smCategory Is Nothing Then
				s += " and SmCategory = @smCategory "
			End If

			s += " ORDER BY SmTS DESC"
			daSmLog.SelectCommand.CommandText = s
			daSmLog.SelectCommand.Parameters.Add("@ts", dataMin.Date)
			daSmLog.SelectCommand.Parameters.Add("@tf", dataMin.Date.AddDays(1))

			If Not smCategory Is Nothing Then
				daSmLog.SelectCommand.Parameters.Add("@smCategory", smCategory)
			End If

			daSmLog.Fill(dsSmLog.SmLog)
			Return dsSmLog

		Catch ex As Exception
			Return Nothing
		End Try


	End Function

	'Public Sub DeleteLog()
	'	Try
	'		GetLog(New DateTime(2000, 1, 1))
	'		For i As Integer = 0 To dsSmLog.SmLog.Count - 1
	'			dsSmLog.SmLog(i).Delete()
	'		Next
	'		daSmLog.Update(dsSmLog.SmLog)

	'	Catch ex As Exception

	'	End Try


	'End Sub

End Class
