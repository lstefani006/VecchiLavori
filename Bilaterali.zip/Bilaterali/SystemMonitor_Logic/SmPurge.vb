Imports System.Diagnostics
Imports System.Globalization
Imports System.IO
Imports System.Text
Imports System.Xml
Imports System.Net
Imports System.Net.Sockets
Imports System.Runtime.Remoting

Public Class SmPurge

    Shared _c As SmPurge

    Dim XmlFilePathConfig As String
    Dim ListaCartelle As New ArrayList(0)
    Dim myTimer As New System.Timers.Timer

    Private Sub SettaTimer(ByVal millisecondi As Double)
        myTimer.Interval = millisecondi
    End Sub
    Private Sub Elabora(ByVal f As FileInfo)

        Dim sFile As String
        Dim pr As AlternateFileStream
        Dim FileEsistente As Boolean

        FileEsistente = True
        Try
            pr = New AlternateFileStream(f.FullName + ":2", FileAccess.Read)
        Catch ex As Exception
            FileEsistente = False
        End Try

        If (FileEsistente = True) Then
            sFile = pr.Read()
            pr.Close()

            Dim _doc As New XmlDocument
            Try
                _doc.LoadXml(sFile)

                Dim Descrizione As XmlNode
                Descrizione = _doc.SelectSingleNode("/FileInfo/Descrizione")
                Dim TestoDescrizione As String
                TestoDescrizione = Descrizione.InnerText

                Dim Politica As XmlNode
                Politica = _doc.SelectSingleNode("/FileInfo/PoliticaCancellazione/Modalita")
                If Not (Politica Is Nothing) Then
                    Dim Cancellabile As String
                    Cancellabile = Politica.Attributes.GetNamedItem("Cancellabile").Value.ToUpper()
                    Dim Dopogiorni As Integer
                    Dopogiorni = Convert.ToInt16(Politica.Attributes.GetNamedItem("DopoGiorni").Value)
                    Dim RichiedereAutorizzazione As String
                    RichiedereAutorizzazione = Politica.Attributes.GetNamedItem("RichiedereAutorizzazione").Value.ToUpper()
                    Dim Eliminare As Boolean
                    Eliminare = False
                    If Not (Politica.Attributes.GetNamedItem("Eliminare") Is Nothing) Then
                        Eliminare = True
                    End If
                    If (Eliminare = True) Then
                        File.Delete(f.FullName)
                        SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceInfo, "Cancellato file " + f.FullName + " !")
                    Else
                        If (Cancellabile = "SI") Then
                            Dim ts As New TimeSpan(Dopogiorni, 0, 0, 0)
                            Dim DataCreazione As DateTime
                            Dim DataOdierna As DateTime
                            DataCreazione = DataCreazione.Add(ts)
                            DataOdierna = DateTime.Now
                            If (DataCreazione < DataOdierna) Then
                                If (RichiedereAutorizzazione = "NO") Then
                                    File.Delete(f.FullName)
                                    SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceInfo, "Cancellato file " + f.FullName + " !")
                                Else
                                    If (Politica.Attributes.GetNamedItem("RichiestaCancellazioneInviata") Is Nothing) Then
                                        Dim request As New SmPurgeRequest
                                        Try
                                            Dim IPAddress As String
                                            Dim HostName As String
                                            HostName = System.Net.Dns.GetHostName
                                            IPAddress = System.Net.Dns.GetHostByName(HostName).AddressList(0).ToString()
                                            request.RichiestaPermessoCancellazioneFile(f.FullName, TestoDescrizione, IPAddress)
                                            Politica.Attributes.Append(_doc.CreateAttribute("RichiestaCancellazioneInviata"))
                                            Try
                                                Dim p As New AlternateFileStream(f.FullName + ":2", FileAccess.Write)
                                                Dim sw As New StringWriter
                                                _doc.Save(sw)
                                                sw.Flush()
                                                Dim xml As String
                                                xml = sw.GetStringBuilder().ToString()

                                                p.Write(xml)
                                                p.Close()
                                            Catch ex As Exception
                                                SystemMonitor.SmLog.smError(ex)
                                            End Try
                                        Catch ex As Exception
                                            SystemMonitor.SmLog.smError(ex)
                                        End Try
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            Catch ex As Exception
                SystemMonitor.SmLog.smError(ex)
            End Try
        Else
            SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "File " + f.FullName + ":2" + " inesistente!")
        End If

    End Sub

    Private Sub PulisciDirectory()
        Dim i As Integer
        For i = 0 To ListaCartelle.Count - 1
            Dim theFolder As New DirectoryInfo(Convert.ToString(ListaCartelle(i)))
            If Not (theFolder.Exists) Then
                SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceError, "Directory " + Convert.ToString(ListaCartelle(i)) + " inesistente!")
            Else
                Dim file As FileInfo
                For Each file In theFolder.GetFiles()
                    Elabora(file)
                Next
            End If
        Next

        SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "PulisciDirectory() eseguita!")

    End Sub

    Private Function DeterminaProssimaEsecuzione(ByVal XmlFilePath As String) As Double
        Dim Intervallo As Double
        Dim _doc As New XmlDocument
        Dim dt As DateTime

        Intervallo = 0
        dt = DateTime.Now

        Try
            _doc.Load(XmlFilePath)

            Dim Cartelle As XmlNodeList
            Cartelle = _doc.SelectNodes("/Politica/CartellaDaControllare")
            If Not (Cartelle Is Nothing) Then
                Dim path As String
                ListaCartelle.Clear()
                Dim n As XmlNode
                For Each n In Cartelle
                    path = n.Attributes.GetNamedItem("Path").Value
                    ListaCartelle.Add(path)
                Next
            End If

            Dim nodelist As XmlNodeList
            nodelist = _doc.SelectNodes("/Politica")
            Dim node As XmlNode
            For Each node In nodelist
                Dim ogniMese As XmlNode
                ogniMese = node.SelectSingleNode("./OgniMese")
                If Not (ogniMese Is Nothing) Then
                    Dim Abilitato As String
                    Abilitato = ogniMese.Attributes.GetNamedItem("Abilitato").Value
                    If (Abilitato.ToUpper() = "SI") Then
                        Dim giorno As String
                        giorno = ogniMese.Attributes.GetNamedItem("IlGiorno").Value
                        Dim ora As String
                        ora = ogniMese.Attributes.GetNamedItem("AlleOre").Value
                        SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "Politica: ogni mese il giorno " + giorno + " alle ore " + ora)

                        Dim gg As Integer
                        Dim hh As Integer
                        gg = Convert.ToInt16(giorno)
                        hh = Convert.ToInt16(ora)
                        If (gg = dt.Day) Then
                            If (hh > dt.Hour) Then
                                Intervallo = (hh - dt.Hour) * 3600000
                            Else
                                If (hh = dt.Hour) Then
                                    PulisciDirectory()
                                    If (dt.Month < 12) Then
                                        Dim dt2 As New DateTime(dt.Year, dt.Month + 1, gg, hh, 0, 0, 0)
                                        Dim ts As TimeSpan
                                        ts = dt2.Subtract(dt)
                                        Intervallo = ts.TotalMilliseconds
                                    Else
                                        Dim dt2 As New DateTime(dt.Year + 1, 1, gg, hh, 0, 0, 0)
                                        Dim ts As TimeSpan
                                        ts = dt2.Subtract(dt)
                                        Intervallo = ts.TotalMilliseconds
                                    End If
                                Else
                                    If (dt.Month < 12) Then
                                        Dim dt2 As New DateTime(dt.Year, dt.Month + 1, gg, hh, 0, 0, 0)
                                        Dim ts As TimeSpan
                                        ts = dt2.Subtract(dt)
                                        Intervallo = ts.TotalMilliseconds
                                    Else
                                        Dim dt2 As New DateTime(dt.Year + 1, 1, gg, hh, 0, 0, 0)
                                        Dim ts As TimeSpan
                                        ts = dt2.Subtract(dt)
                                        Intervallo = ts.TotalMilliseconds
                                    End If
                                End If
                            End If
                        End If
                        If (gg > dt.Day) Then
                            If (hh > dt.Hour) Then
                                Intervallo = (gg - dt.Day) * 3600000 * 24
                                Intervallo = Intervallo + ((hh - dt.Hour) * 3600000)
                            Else
                                If (hh = dt.Hour) Then
                                    Intervallo = (gg - dt.Day) * 3600000 * 24
                                Else
                                    Intervallo = (gg - dt.Day - 1) * 3600000 * 24
                                    Intervallo = Intervallo + ((24 - (dt.Hour - hh)) * 3600000)
                                End If
                            End If
                        End If
                        If (gg < dt.Day) Then
                            If (dt.Month < 12) Then
                                Dim dt2 As New DateTime(dt.Year, dt.Month + 1, gg, hh, 0, 0, 0)
                                Dim ts As TimeSpan
                                ts = dt2.Subtract(dt)
                                Intervallo = ts.TotalMilliseconds
                            Else
                                Dim dt2 As New DateTime(dt.Year + 1, 1, gg, hh, 0, 0, 0)
                                Dim ts As TimeSpan
                                ts = dt2.Subtract(dt)
                                Intervallo = ts.TotalMilliseconds
                            End If
                        End If
                    End If
                End If

                Dim ogniSettimana As XmlNode
                ogniSettimana = node.SelectSingleNode("./OgniSettimana")
                If Not (ogniSettimana Is Nothing) Then
                    Dim Abilitato As String
                    Abilitato = ogniSettimana.Attributes.GetNamedItem("Abilitato").Value
                    If (Abilitato.ToUpper() = "SI") Then
                        Dim giorno As String
                        Dim ora As String
                        giorno = ogniSettimana.Attributes.GetNamedItem("Il").Value
                        ora = ogniSettimana.Attributes.GetNamedItem("AlleOre").Value
                        SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "Politica: ogni settimana il " + giorno + " alle ore " + ora)

                        Dim gg As Integer
                        If (giorno.ToUpper() = "LUN") Then
                            gg = 1
                        End If
                        If (giorno.ToUpper() = "MAR") Then
                            gg = 2
                        End If
                        If (giorno.ToUpper() = "MER") Then
                            gg = 3
                        End If
                        If (giorno.ToUpper() = "GIO") Then
                            gg = 4
                        End If
                        If (giorno.ToUpper() = "VEN") Then
                            gg = 5
                        End If
                        If (giorno.ToUpper() = "SAB") Then
                            gg = 6
                        End If
                        If (giorno.ToUpper() = "DOM") Then
                            gg = 7
                        End If
                        Dim hh As Integer
                        hh = Convert.ToInt16(ora)
                        Dim dw As DayOfWeek
                        dw = dt.DayOfWeek
                        Dim ggOfWeek As Integer
                        ggOfWeek = Convert.ToInt16(dw.ToString("D", New CultureInfo("it-IT")))

                        If (gg = ggOfWeek) Then
                            If (hh > dt.Hour) Then
                                Intervallo = (hh - dt.Hour) * 3600000
                            Else
                                If (hh = dt.Hour) Then
                                    PulisciDirectory()
                                    Intervallo = (7 * 3600000 * 24)
                                Else
                                    Intervallo = (6 * 3600000 * 24)
                                    Intervallo = Intervallo + ((24 - (dt.Hour - hh)) * 3600000)
                                End If
                            End If
                        End If
                        If (gg < ggOfWeek) Then
                            If (hh > dt.Hour) Then
                                Intervallo = ((7 - (ggOfWeek - gg)) * 3600000 * 24)
                                Intervallo = Intervallo + ((hh - dt.Hour) * 3600000)
                            Else
                                If (hh = dt.Hour) Then
                                    Intervallo = ((7 - (ggOfWeek - gg)) * 3600000 * 24)
                                Else
                                    Intervallo = ((7 - (ggOfWeek - gg) - 1) * 3600000 * 24)
                                    Intervallo = Intervallo + ((24 - (dt.Hour - hh)) * 3600000)
                                End If
                            End If
                        End If
                        If (gg > ggOfWeek) Then
                            If (hh > dt.Hour) Then
                                Intervallo = ((gg - ggOfWeek) * 3600000 * 24)
                                Intervallo = Intervallo + ((hh - dt.Hour) * 3600000)
                            Else
                                If (hh = dt.Hour) Then
                                    Intervallo = ((gg - ggOfWeek) * 3600000 * 24)
                                Else
                                    Intervallo = ((gg - ggOfWeek - 1) * 3600000 * 24)
                                    Intervallo = Intervallo + ((24 - (dt.Hour - hh)) * 3600000)
                                End If
                            End If
                        End If
                    End If
                End If

                Dim ogniGiorno As XmlNode
                ogniGiorno = node.SelectSingleNode("./OgniGiorno")
                If Not (ogniGiorno Is Nothing) Then
                    Dim Abilitato As String
                    Abilitato = ogniGiorno.Attributes.GetNamedItem("Abilitato").Value
                    If (Abilitato.ToUpper() = "SI") Then
                        Dim ora As String
                        ora = ogniGiorno.Attributes.GetNamedItem("AlleOre").Value
                        SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "Politica: ogni giorno alle ore " + ora)

                        Dim hh As Integer
                        hh = Convert.ToInt16(ora)
                        If (hh > dt.Hour) Then
                            Intervallo = ((hh - dt.Hour) * 3600000)
                        Else
                            If (hh = dt.Hour) Then
                                PulisciDirectory()
                                Intervallo = (3600000 * 24)
                            Else
                                Intervallo = ((24 - (dt.Hour - hh)) * 3600000)
                            End If
                        End If
                    End If
                End If
            Next

        Catch ex As Exception
            SystemMonitor.SmLog.smError(ex)
        End Try

        SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceVerbose, "Prossima esecuzione di SmPurge fra " + Intervallo.ToString() + " millisecondi.")

        DeterminaProssimaEsecuzione = Intervallo
    End Function
    Private Sub myTimer_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs)
        myTimer.Stop()

        PulisciDirectory()

        SettaTimer(DeterminaProssimaEsecuzione(XmlFilePathConfig))
        myTimer.Start()
    End Sub

    Public Sub New()

        AddHandler myTimer.Elapsed, AddressOf myTimer_Elapsed

		XmlFilePathConfig = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "\Politica.xml"

        SettaTimer(DeterminaProssimaEsecuzione(XmlFilePathConfig))

        myTimer.Start()

    End Sub

    Public Shared Sub Init()
        _c = New SmPurge
    End Sub

End Class
