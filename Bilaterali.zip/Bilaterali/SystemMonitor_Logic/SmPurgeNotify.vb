Imports System.IO
Imports System.Xml

Public Class SmPurgeNotify
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Public Sub NotificaEliminazioneFile(ByVal nomeFile As String)
        Dim _FileXml As String
        _FileXml = nomeFile + ":2"

        Dim sFile As String
        Dim FileEsistente As Boolean

        FileEsistente = True
        Dim pr As AlternateFileStream
        Try
            pr = New AlternateFileStream(_FileXml, FileAccess.Read)
        Catch ex As Exception
            FileEsistente = False
            SystemMonitor.SmLog.smError(ex, "Errore su file: " + _FileXml + ". File inesistente.")
        End Try
        If (FileEsistente = True) Then
            sFile = pr.Read()
            pr.Close()

            Dim _doc As New XmlDocument
            Try
                _doc.LoadXml(sFile)

                Dim Politica As XmlNode
                Politica = _doc.SelectSingleNode("/FileInfo/PoliticaCancellazione/Modalita")
                If (Politica.Attributes.GetNamedItem("Eliminare") Is Nothing) Then
                    Politica.Attributes.Append(_doc.CreateAttribute("Eliminare"))
                    Try
                        Dim p As New AlternateFileStream(_FileXml, FileAccess.Write)
                        Dim sw As New StringWriter
                        _doc.Save(sw)
                        sw.Flush()
                        Dim xml As String
                        xml = sw.GetStringBuilder().ToString()

                        p.Write(xml)
                        p.Close()
                    Catch ex As Exception
                        SystemMonitor.SmLog.smError(ex)
                        Throw New System.Exception("Errore: non posso marcare come da 'Eliminare' il file " + _FileXml)
                    End Try
                End If
            Catch ex As Exception
                SystemMonitor.SmLog.smError(ex)
                Throw New System.Exception("Errore: non riesco a caricare il file XML " + _FileXml)
            End Try
        End If

        SystemMonitor.SmLog.smTraceIf(SmLog.smLogSwitch.TraceInfo, "Ricevuta autorizzazione a cancellare il file: " + nomeFile)
    End Sub

End Class
