Imports System.Diagnostics
Imports System.Configuration
Imports System.Runtime.Remoting
Imports System.Text
Imports System.IO
Imports System.Windows.Forms
Imports System.Net.Sockets

' classe che dirotta i Trace al server di trace SmLogServer
' i Trace possono essere sia in formato XML (ottenuti cioe` da SmTrace)
' che in formato testo (ottenuti scrivendo direttamente in System.Diagnostics.Trace.Write*() );
' sara` il server di trace che ricevera` il messaggio e capira` se e` il XML o meno.
' La classe bufferizza al max 1Kbyte di testo, poi lo spedisce d'ufficio al server.
' Se message e' piu` grande di 1K viene spedita immediatamente.
' Se message e' piu` piccola di 1K viene memorizzata fino al prossimo Flush
Public Class SmTraceListener
	Inherits TraceListener

	Public Overloads Overrides Sub Write(ByVal message As String)
		If (_closed) Then Return
		_sw.Write(message)
		If (_sw.GetStringBuilder().Length > 1024) Then Flush()
	End Sub

	Public Overloads Overrides Sub WriteLine(ByVal message As String)
		If (_closed) Then Return
		_sw.WriteLine(message)
		If (_sw.GetStringBuilder().Length > 1024) Then Flush()
	End Sub

	Public Overrides Sub Flush()
		If (_closed) Then Return
		Dim message As String = Nothing
		Try
			_sw.Flush()
			message = _sw.GetStringBuilder.ToString()
			_sw.GetStringBuilder().Length = 0			 ' spedisco il messaggio --> resetto il buffer

			If (message.Length = 0) Then Return ' e` inutile spedire un messaggio vuoto

			' questa classe e` remota
			Dim sm As New SystemMonitor.SmLogServer
			Dim dic As IDictionary = System.Runtime.Remoting.Channels.ChannelServices.GetChannelSinkProperties(sm)
			If (dic Is Nothing) Then Throw New Exception("SystemMonitor.SmLogServer non e` registata come classe remota!")
			sm.Send(message)

		Catch sex As SocketException
#If DEBUG Then
			' in DEBUG e se c'e` il debugger attaccato mi fermo.
			If (System.Diagnostics.Debugger.IsAttached) Then
				System.Diagnostics.Debugger.Log(10, "Error", sex.Message)
				'System.Diagnostics.Debugger.Break()
			End If
#End If

		Catch ex As Exception
			' ignoro gli errori di trasmissione.
			' Per esempio il server puo` essere giu`.
			' Non posso certo piantare il programma che fa trace se il server non c'e`.
#If DEBUG Then
			' in DEBUG e se c'e` il debugger attaccato mi fermo.
			If (System.Diagnostics.Debugger.IsAttached) Then
				System.Diagnostics.Debugger.Log(10, "Error", ex.Message)
				System.Diagnostics.Debugger.Break()
			End If
#End If
		End Try
	End Sub

	Public Overloads Sub Close()
		Flush()
		_closed = True
	End Sub

	Private _sw As New StringWriter
	Private _closed As Boolean = False
End Class

