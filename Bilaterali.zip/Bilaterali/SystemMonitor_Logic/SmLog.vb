Imports System.Collections.Specialized
Imports System.Reflection
Imports System.Diagnostics
Imports System.Globalization
Imports System.IO
Imports System.Text
Imports System.Xml
Imports System.Runtime.Remoting

' Classe che contiene solo membri statici.
' Serve per scrivere messaggi utilizzando System.Diagnostics.Trace
' formattando il messaggio in formato XML in modo che contenga
' il nome dell'applicazione, il TS, ecc.
' Inoltre e` supportato il Trace delle eccezioni (salvando anche le InnerException)
' Se il System.Diagnostics.Trace e` dirottato con un opportuno TraceListener
' si puo` anche fare tracing spedendo i messaggi ad un server remoto.
' Notare che in un programma si puo` chiamare sia smTrace che System.Diagnostics.Trace.Write(Line)(If)
' in quanto e` chi legge il trace (programma o umano) che deve interpretare correttmente i messaggi.
Public Class SmLog
	Public Shared smLogSwitch As New CustomTraceSwitch("SystemMonitorLogSwitch", "switch per abilitare il log remoto")

	'	Public Shared Sub Init(ByVal configureRemoting As Boolean)
	'		If (configureRemoting) Then
	'			RemotingConfiguration.Configure(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile)
	'		End If
	'		System.Diagnostics.Trace.Listeners.Add(New SystemMonitor.SmTraceListener)
	'	End Sub
	Public Shared Sub Init()
		System.Diagnostics.Trace.Listeners.Add(New SystemMonitor.SmTraceListener)
	End Sub

#Region "Error methods"
	Public Shared Sub smError(ByVal message As String)
		smWrite("Error", message)
	End Sub
	Public Shared Sub smError(ByVal ex As Exception)
		smWrite("Error", ex)
	End Sub
	Public Shared Sub smError(ByVal ex As Exception, ByVal message As String)
		smWrite("Error", ex, message)
	End Sub
	Public Shared Sub smErrorIf(ByVal condition As Boolean, ByVal message As String)
		smWriteIf(condition, "Error", message)
	End Sub
	Public Shared Sub smErrorIf(ByVal condition As Boolean, ByVal ex As Exception)
		smWriteIf(condition, "Error", ex)
	End Sub
	Public Shared Sub smErrorIf(ByVal condition As Boolean, ByVal ex As Exception, ByVal message As String)
		smWriteIf(condition, "Error", ex, message)
	End Sub
#End Region

#Region "Trace methods"
	Public Shared Sub smTrace(ByVal message As String)
		smWriteIf(SmLog.smLogSwitch.TraceVerbose, "Trace", message)
	End Sub
	Public Shared Sub smTrace(ByVal ex As Exception)
		smWriteIf(SmLog.smLogSwitch.TraceVerbose, "Trace", ex)
	End Sub
	Public Shared Sub smTrace(ByVal ex As Exception, ByVal message As String)
		smWriteIf(SmLog.smLogSwitch.TraceVerbose, "Trace", ex, message)
	End Sub
	Public Shared Sub smTraceIf(ByVal condition As Boolean, ByVal message As String)
		smWriteIf(condition, "Trace", message)
	End Sub
	Public Shared Sub smTraceIf(ByVal condition As Boolean, ByVal ex As Exception)
		smWriteIf(condition, "Trace", ex)
	End Sub
	Public Shared Sub smTraceIf(ByVal condition As Boolean, ByVal ex As Exception, ByVal message As String)
		smWriteIf(condition, "Trace", ex, message)
	End Sub
#End Region

#Region "Write methods"
	Public Shared Sub smWriteIf(ByVal condition As Boolean, ByVal category As String, ByVal message As String)
		If (condition) Then smWrite(category, message)
	End Sub
	Public Shared Sub smWriteIf(ByVal condition As Boolean, ByVal category As String, ByVal ex As Exception)
		If (condition) Then smWrite(category, ex, Nothing)
	End Sub
	Public Shared Sub smWriteIf(ByVal condition As Boolean, ByVal category As String, ByVal ex As Exception, ByVal message As String)
		If (condition) Then smWrite(category, ex, message)
	End Sub

	' funzione da chiamare per fare trace di un evento
	Public Shared Sub smWrite(ByVal category As String, ByVal message As String)
		Dim ss As New StringWriter
		Dim xw As New XmlTextWriter(ss)

		xw.Formatting = Formatting.Indented
		xw.Indentation = 1
		xw.IndentChar = Chr(9)
		xw.WriteStartDocument()
		xw.WriteStartElement("Log")

		xw.WriteStartElement("Category")
		xw.WriteString(category)
		xw.WriteEndElement()

		xw.WriteStartElement("Message")
		xw.WriteString(message)
		xw.WriteEndElement()

		xw.WriteStartElement("Application")
		xw.WriteString(AppDomain.CurrentDomain.FriendlyName)
		xw.WriteEndElement()

		xw.WriteStartElement("TS")
		xw.WriteString(XmlConvert.ToString(DateTime.Now))
		xw.WriteEndElement()

		xw.WriteStartElement("StackTrace")
		xw.WriteString(Environment.StackTrace)
		xw.WriteEndElement()

		xw.WriteEndElement()
		xw.WriteEndDocument()

		xw.Flush()


		System.Diagnostics.Trace.Flush()		  ' per spedire evenduali messaggi pendenti
		System.Diagnostics.Trace.WriteLine(ss.ToString())
		System.Diagnostics.Trace.Flush()		 ' per spedire questo messaggio
	End Sub

	Public Shared Sub smWrite(ByVal category As String, ByVal ex As Exception)
		smWrite(category, ex, Nothing)
	End Sub

	' funzione da chiamare a fronte di una eccezione
	Public Shared Sub smWrite(ByVal category As String, ByVal ex As Exception, ByVal message As String)
		Dim ss As New StringWriter
		Dim xw As New XmlTextWriter(ss)

		xw.Formatting = Formatting.Indented
		xw.Indentation = 1
		xw.IndentChar = Chr(9)
		xw.WriteStartDocument()
		xw.WriteStartElement("Log")

		xw.WriteStartElement("Category")
		xw.WriteString(category)
		xw.WriteEndElement()

		xw.WriteStartElement("Message")
		If (Not message Is Nothing) Then xw.WriteString(message)
		xw.WriteEndElement()

		xw.WriteStartElement("Application")
		xw.WriteString(AppDomain.CurrentDomain.FriendlyName)
		xw.WriteEndElement()

		xw.WriteStartElement("TS")
		xw.WriteString(XmlConvert.ToString(DateTime.Now))
		xw.WriteEndElement()

		WriteElementeException(xw, ex)

		xw.WriteStartElement("StackTrace")
		xw.WriteString(Environment.StackTrace)
		xw.WriteEndElement()

		xw.WriteEndElement()
		xw.WriteEndDocument()

		xw.Flush()

		System.Diagnostics.Trace.Flush()		  ' per spedire evenduali messaggi pendenti
		System.Diagnostics.Trace.WriteLine(ss.ToString())
		System.Diagnostics.Trace.Flush()		 ' per spedire questo messaggio
	End Sub
#End Region

#Region "Helper"
	Private Shared Sub WriteElementeException(ByVal xw As XmlTextWriter, ByVal ex As Exception)
		xw.WriteStartElement("Exception")

		xw.WriteStartElement("Message")
		xw.WriteString(ex.Message)
		xw.WriteEndElement()

		xw.WriteStartElement("Source")
		xw.WriteString(ex.Source)
		xw.WriteEndElement()

		xw.WriteStartElement("StackTrace")
		xw.WriteString(ex.StackTrace)
		xw.WriteEndElement()

		If (Not ex.InnerException Is Nothing) Then WriteElementeException(xw, ex.InnerException)

		xw.WriteEndElement()
	End Sub
#End Region

	Public Class CustomTraceSwitch
		Inherits TraceSwitch

		Public Sub New(ByVal s As String, ByVal d As String)
			MyBase.New(s, d)
			Me.s = s
			Me.d = d
		End Sub

		Dim s, d As String

		Protected Overrides Sub OnSwitchSettingChanged()
			SmLog.smLogSwitch = New CustomTraceSwitch(s, d)
		End Sub
	End Class

End Class
