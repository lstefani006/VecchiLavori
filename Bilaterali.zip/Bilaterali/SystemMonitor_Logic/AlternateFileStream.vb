Imports System.Diagnostics
Imports System.Globalization
Imports System.IO
Imports System.Text
Imports System.Xml

Public Class AlternateFileStream
    Private f As FileStream

    Public Sub New(ByVal Nomefile As String, ByVal fa As FileAccess)
        f = Nothing
        If (fa = FileAccess.Read) Then
            Try
                f = CreateAlternateFile(Nomefile, FileMode.Open, FileAccess.Read)
            Catch ex As Exception
                Throw New System.Exception("File non trovato.")
            End Try
        End If
        If (fa = FileAccess.Write) Then
            f = CreateAlternateFile(Nomefile, FileMode.Create, FileAccess.Write)
        End If
    End Sub

    Public Function Read() As String
        If (f Is Nothing) Then
            Throw New System.Exception("File non aperto.")
        End If

        Dim sr As New StreamReader(f)
        Dim sFile As String
        sFile = sr.ReadToEnd()
        If (sFile Is Nothing) Then
            Throw New System.Exception("Non riesco a leggere il file.")
        End If
        Read = sFile
    End Function

    Public Sub Write(ByVal s As String)
        If (f Is Nothing) Then
            Throw New System.Exception("File non aperto.")
        End If

        Dim sw As New StreamWriter(f)
        sw.Write(s)
    End Sub

    Public Sub Close()
        f.Close()
    End Sub

    'HANDLE CreateFile(
    '  LPCTSTR lpFileName,
    '  DWORD dwDesiredAccess,
    '  DWORD dwShareMode,
    '  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    '  DWORD dwCreationDisposition,
    '  DWORD dwFlagsAndAttributes,
    '  HANDLE hTemplateFile
    ');
    <System.Runtime.InteropServices.DllImport("Kernel32.dll", SetLastError:=True)> _
    Private Shared Function CreateFile( _
     ByVal lpFileName As String, _
     ByVal dwDesiredAccess As Int32, _
     ByVal dwShareMode As Int32, _
     ByVal lpSecurityAttributes As Int32, _
     ByVal dwCreationDisposition As Int32, _
     ByVal dwFlagsAndAttributes As Int32, _
     ByVal hTemplateFile As Int32 _
     ) As Int32
    End Function

    Public Shared Function CreateAlternateFile(ByVal nomeFile As String, ByVal fileMode As FileMode, ByVal fileAccess As FileAccess) As System.IO.FileStream
        Dim dwDesiredAccess As Int32
        Dim dwShareMode As Int32 = 0    ' nessun share sui file
        Dim dwCreationDisposition As Int32 = fileMode

        If True Then
            Const GENERIC_READ As Int32 = &H80000000
            Const GENERIC_WRITE As Int32 = &H40000000

            Select Case fileAccess
                Case fileAccess.Read
                    dwDesiredAccess = GENERIC_READ
                Case fileAccess.Write
                    dwDesiredAccess = GENERIC_WRITE
            End Select
        End If

        If True Then
            Const CREATE_NEW As Int32 = 1
            Const CREATE_ALWAYS As Int32 = 2
            Const OPEN_EXISTING As Int32 = 3
            Const OPEN_ALWAYS As Int32 = 4
            Const TRUNCATE_EXISTING As Int32 = 5
            Select Case fileMode
                Case fileMode.Create
                    dwCreationDisposition = CREATE_ALWAYS
                Case fileMode.Append
                    dwCreationDisposition = OPEN_ALWAYS
                Case fileMode.Open
                    dwCreationDisposition = OPEN_EXISTING
                Case fileMode.Truncate
                    dwCreationDisposition = TRUNCATE_EXISTING
                Case fileMode.OpenOrCreate
                    dwCreationDisposition = OPEN_ALWAYS
            End Select
        End If


        Const FILE_ATTRIBUTE_NORMAL As Int32 = &H80
        Dim dwFlagsAndAttributes As Int32 = FILE_ATTRIBUTE_NORMAL

        Dim h As Int32 = CreateFile(nomeFile, dwDesiredAccess, dwShareMode, 0, dwCreationDisposition, dwFlagsAndAttributes, 0)
        If (h < 0) Then
            Throw New Exception("CreateAlternateFile error: CreateFile returns win32 error code" & System.Runtime.InteropServices.Marshal.GetLastWin32Error().ToString())
        End If

        Return New FileStream(New IntPtr(h), fileAccess, True)
    End Function

End Class
