using System;

namespace Dime {
    /// <summary>
    /// Specifies possible Type formats as defined in the DIME specification. For example,
    /// if the type format is TypeFormatEnum.MediaType then a valid Type would be
    /// "plain/text; charset=utf-8" or "image/jpeg".
    /// </summary>
    public enum TypeFormatEnum {
        Unchanged = 0x0,
        MediaType = 0x1,
        AbsoluteUri = 0x2,
        Unknown = 0x3,
        None = 0x4
    }
}
