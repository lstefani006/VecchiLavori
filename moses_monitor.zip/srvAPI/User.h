#include <st_dbnew.h>
#ifndef __User_h__
#define __User_h__

#include <moses.h>

GenericMsg * User_Add              (class c_Moses_User_Add       *q, int nClient);
GenericMsg * User_Delete           (class c_Moses_User_Delete    *q, int nClient);
GenericMsg * User_Modify           (class c_Moses_User_Modify    *q, int nClient);
GenericMsg * User_List             (class c_Moses_User_List      *q, int nClient);
GenericMsg * User_ChangePassword   (class c_Moses_User_ChangePassword *q, int nClient);

STRING Notify_DeleteMailBox(const STRING &MailBoxName, int nClient);


/*
 * Funzioni di utilita`
 */
int User_Exists(const STRING &UserName);
int UserInternal_Exists(const STRING &UserName);
int UserExternal_Exists(const STRING &UserName);

int User_GetCFG(STRING &Login, STRING &Pwd);

#endif
