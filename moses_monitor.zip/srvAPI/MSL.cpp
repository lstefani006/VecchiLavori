#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "MSL.h"
#include "Notify.h"

#include <m_Moses_MSL_Add.h>
#include <m_Moses_MSL_Delete.h>
#include <m_Moses_MSL_List.h>
#include <m_Moses_MSL_Modify.h>


GenericMsg * MSL_Add(c_Moses_MSL_Add *q, int nClient)
{
	a_Moses_MSL_Add *m = STNew a_Moses_MSL_Add;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> d = TB_MSL->GetEmptyRow();
		d[ F_MSL_Name ] = q->MSLName;
		d[ F_MSL_Descr] = q->MSLDescr;
		int r = TB_MSL->Insert(d);
		if (r == 0)
			m->Error = GetError("MSL001, nClient"); // Moses Script Name already present .
	}
	return m;
}

GenericMsg * MSL_Delete(c_Moses_MSL_Delete *q, int nClient)
{
	a_Moses_MSL_Delete *m = STNew a_Moses_MSL_Delete;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		int r = TB_MSL->Delete(F_MSL_Name, q->MSLName);
		if (r == 0)
			m->Error = GetError("MSL002, nClient"); // Unknown Moses Script Name.

		TB_MSL->Delete(F_MSL_Name, q->MSLName);
	}
	return m;
}

GenericMsg * MSL_List(c_Moses_MSL_List *q, int nClient)
{
	a_Moses_MSL_List *m = STNew a_Moses_MSL_List;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> out_Name_Pwd_Descr;

		long l = 0;
		while ((l = TB_MSL->Select(out_Name_Pwd_Descr, l)) != -1)
		{
			m->MSLNameList.Append  (out_Name_Pwd_Descr[F_MSL_Name]);
			m->MSLDescrList.Append (out_Name_Pwd_Descr[F_MSL_Descr]);
		}

		// non c'e` mai errore
	}

	return m;
}

GenericMsg * MSL_Modify(c_Moses_MSL_Modify *q, int nClient)
{
	a_Moses_MSL_Modify *m = STNew a_Moses_MSL_Modify;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> i = TB_MSL->GetEmptyRow();
		i[ F_MSL_Descr ] = q->MSLDescr;

		int r = TB_MSL->Update(F_MSL_Name, q->MSLName, 
				TbFile::M(F_MSL_Descr), i);

		if (r == 0 || r == -1)
			m->Error = GetError("MSL003, nClient"); // Moses Script name not found.
	}
	return m;
}


////////////////////////////////////////////////////////////////////////

#endif
