#include <st_dbnew.h>
#ifdef MOSES_SERVER

#ifdef _WIN32
	#include <time.h>
#else
	#include <sys/time.h>
#endif

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "Event.h"
#include "Notify.h"
#include "MB.h"

#include <m_Moses_Event_NewMsgInFolder.h>
#include <m_Moses_Event_Alert_NewMsgInFolder.h>
#include <m_Moses_Event_NewMsgForMTD.h>
#include <m_Moses_Event_Alert_NewMsgForMTD.h>
#include <m_Moses_Event_Delete.h>
#include <m_Moses_Event_GetEvent.h>



int operator == (const EventAppened &a, const EventAppened &b)
{
	return 
		a.nClient == b.nClient &&
		a.EventId == b.EventId &&
		a.MsgId   == b.MsgId   &&
		a.Folder  == b.Folder ;
}



static VECT<EventReq>     S_TbEventReq;
static VECT<EventAppened> S_TbEventAppened;

static INT32              S_EventId = 1;


/////////////////////////////////////////////////////////////////////////////////

STRING Event_NewMsgInFolder(int nClient, const STRING &MailboxName, 
		const STRING &Folder, INT32 &out_EventId)
{
	for (int i = 0; i < S_TbEventReq.Size(); i++)
		if (S_TbEventReq[i].nClient == nClient &&
				S_TbEventReq[i].Mailbox == MailboxName &&
				(S_TbEventReq[i].Folder == "" ||
				 S_TbEventReq[i].Folder == Folder))
		{
			out_EventId = S_TbEventReq[i].EventId;
			return GetError("EV001", nClient); // Event already registered.
		}

	S_TbEventReq.Append(EventReq(nClient, S_EventId, MailboxName, Folder));

	out_EventId = S_EventId++;

	return "";
}


GenericMsg * Event_NewMsgInFolder(c_Moses_Event_NewMsgInFolder *q, int nClient)
{
	a_Moses_Event_NewMsgInFolder *m = STNew a_Moses_Event_NewMsgInFolder;
	m->Error = Event_NewMsgInFolder(nClient, q->MailboxName, 
			q->Folder, m->EventId);
	return m;
}


/////////////////////////////////////////////////////////////////////////////////

STRING Event_Delete(int nClient, INT32 EventId)
{
	for (int i = 0; i < S_TbEventReq.Size(); i++)
		if (S_TbEventReq[i].EventId == EventId)
		{
			S_TbEventReq.Delete(i);
			break;
		}

	int bFound = 0;
	do
	{
		bFound = 0;
		for (int i = 0; i < S_TbEventAppened.Size(); i++)
			if (S_TbEventAppened[i].EventId == EventId)
			{
				S_TbEventAppened.Delete(i);
				bFound = 1;
				break;
			}
	}
	while (bFound);

	return GetError("EV005", nClient); // Event not registred
}

GenericMsg * Event_Delete(c_Moses_Event_Delete *q, int nClient)
{
	a_Moses_Event_Delete *m = STNew a_Moses_Event_Delete;
	m->Error = Event_Delete(nClient, q->EventId);
	return m;
}

STRING Event_GetEvent(int nClient, int mSec, INT32 &out_EventId)
{
	for (int i = 0; i < S_TbEventAppened.Size(); i++)
		if (S_TbEventAppened[i].nClient == nClient)
		{
			out_EventId = S_TbEventAppened[i].EventId;
			return "";
		}

	return GetError("EV006", nClient);
}

GenericMsg * Event_GetEvent(c_Moses_Event_GetEvent *q, int nClient)
{
	a_Moses_Event_GetEvent *m = STNew a_Moses_Event_GetEvent;
	m->Error = Event_GetEvent(nClient, q->mSec, m->EventId);
	return m;
}


////////////////////////////////////////////////////////////////////////////////

//
// Un evento MTD utilizza comunque la struttura MsgInFolder e il vettore S_tbMsgInFolder
//

STRING Event_NewMsgForMTD(
		int nClient, 
		const STRING &MailType,
		INT32 &out_EventId)
{
	for (int i = 0; i < S_TbEventReq.Size(); i++)
		if ( S_TbEventReq[i].Mt == MailType )
		{
			out_EventId = S_TbEventReq[i].EventId;
			InitMTD();
			return GetError("EV002", nClient); // MTD Event already registered.
		}

	S_TbEventReq.Append(EventReq(nClient, S_EventId, MailType));

	out_EventId = S_EventId++;

	InitMTD();

	return "";
}


GenericMsg * Event_NewMsgForMTD(c_Moses_Event_NewMsgForMTD *q, int nClient)
{
	a_Moses_Event_NewMsgForMTD *m = STNew a_Moses_Event_NewMsgForMTD;
	m->Error = Event_NewMsgForMTD(nClient, q->MailType, m->EventId );
	return m;
}


/////////////////////////////////////////////////////////////////////////////////


static STRING Do_Notify_MB_MSG_WRITE(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";
	Notify_MB_MSG_WRITE *p_MSG_WRITE = (Notify_MB_MSG_WRITE *)p;

	/*
	 * ricevo la notifica di un nuovo messaggio
	 * --> scandisco la tabella degli eventi richiesti e se l'evento
	 * e' trovato  faccio l'append nella tabella degli eventi accaduti
	 */

	for (int i = 0; i < S_TbEventReq.Size(); i++)
	{
		if (S_TbEventReq[i].Mailbox == p_MSG_WRITE->Mailbox &&
				S_TbEventReq[i].Folder == p_MSG_WRITE->Folder)
		{
			S_TbEventAppened.Append(
					EventAppened(
							S_TbEventReq[i].nClient,
							S_TbEventReq[i].EventId,
							p_MSG_WRITE->MsgId,
							p_MSG_WRITE->Folder));
			clog << "Notify MSG WRITE -> MsgID:" << p_MSG_WRITE->MsgId 
				<< " - Mailbox :" << p_MSG_WRITE->Mailbox
				<< " - Folder :" << p_MSG_WRITE->Folder
				<< endl;		
		}
	}

	return "";
}

static Notify Notify_MB_MSG_WRITE(Notify_MB_MSG_WRITE::Id, Do_Notify_MB_MSG_WRITE);

/////////////////////////////////////////////////////////////////////////////////

static STRING Do_Notify_MB_MSG_FOR_MTD(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";
	Notify_MB_MSG_FOR_MTD *p_MSG_MTD = (Notify_MB_MSG_FOR_MTD *)p;

	/*
	 * ricevo la notifica di un nuovo messaggio
	 * --> scandisco la tabella degli eventi richiesti e se l'evento
	 * e' trovato  faccio l'append nella tabella degli eventi accaduti
	 */


	/* Vecchia versione
	   if (!(p_MSG_MTD->MsgId == 0 && G_pServerData->IsServerClosed()))
	   {
	   for (int i = 0; i < S_TbEventReq.Size(); i++)
	   {
	   if (S_TbEventReq[i].Mt == p_MSG_MTD->MailType)
	   {
	   if (S_TbEventReq[i].EventId == 0)
	   {
	// scandisco la tabella degli eventi accaduti per vedere
	// se esiste gia' l'evento leggi la posta sul server

	EventAppened New(
	S_TbEventReq[i].nClient,
	S_TbEventReq[i].EventId,
	p_MSG_MTD->MsgId);

	for (int j = 0; j < S_TbEventAppened.Size(); j++)
	if (S_TbEventAppened[j] == New)
	break;

	if (j == S_TbEventAppened.Size())
	S_TbEventAppened.Append(New);
	}
	else
	S_TbEventAppened.Append(
	EventAppened(
	S_TbEventReq[i].nClient,
	S_TbEventReq[i].EventId,
	p_MSG_MTD->MsgId));
	}
	}
	}
	*/

	
	/*
	 * Le notifiche di poll o di messaggio da spedire non vengono duplicate
	 * Se il server e' chiuso, alla riapertura verranno notificati 1 evento
	 * di poll e gli eventi di messaggi in partenza.
	 */
	for (int i = 0; i < S_TbEventReq.Size(); i++)
	{
		if (S_TbEventReq[i].Mt == p_MSG_MTD->MailType)
		{
			// esiste un MTD interessato all'evento

			EventAppened New(
					S_TbEventReq[i].nClient,
					S_TbEventReq[i].EventId,
					p_MSG_MTD->MsgId);

			// controllo se l'evento e' gia' registrato
			for (int j = 0; j < S_TbEventAppened.Size(); j++)
				if (S_TbEventAppened[j] == New)
					break;

			// se l'evento non e' registrato lo registro
			if (j == S_TbEventAppened.Size())
			{
				clog << "Notify MTD -> MsgID:" 
					<< p_MSG_MTD->MsgId 
					<< " - Mailbox Type:" 
					<< p_MSG_MTD->MailType << endl;		
				S_TbEventAppened.Append(New);
			}

			break;
		}
	}

	return "";
}

static Notify Notify_MB_MSG_FOR_MTD(Notify_MB_MSG_FOR_MTD::Id, Do_Notify_MB_MSG_FOR_MTD);

/////////////////////////////////////////////////////////////////////////////////


STRING Event_Alert_NewMsgInFolder(
		int nClient, 
		INT32 EventId, 
		INT32 &out_MsgId, 
		STRING &out_Folder)
{
	if (!G_pServerData->IsServerClosed())
		for (int i = 0; i < S_TbEventAppened.Size(); i++)
			if (S_TbEventAppened[i].EventId == EventId)
			{
				out_MsgId  = S_TbEventAppened[i].MsgId;
				out_Folder = S_TbEventAppened[i].Folder;

				S_TbEventAppened.Delete(i);

				return "";
			}

	return GetError("EV003", nClient); // No event happened.
}

GenericMsg * Event_Alert_NewMsgInFolder(c_Moses_Event_Alert_NewMsgInFolder *q, int nClient)
{
	a_Moses_Event_Alert_NewMsgInFolder *m = STNew a_Moses_Event_Alert_NewMsgInFolder;
	m->Error = Event_Alert_NewMsgInFolder(nClient, q->EventId, m->MsgId, m->Folder);
	return m;
}

/////////////////////////////////////////////////////////////////////////////////

STRING Event_Alert_NewMsgForMTD(int nClient, INT32 EventId, INT32 &out_MsgId)
{
	if (!G_pServerData->IsServerClosed())
		for (int i = 0; i < S_TbEventAppened.Size(); i++)
			if (S_TbEventAppened[i].EventId == EventId)
			{
				out_MsgId  = S_TbEventAppened[i].MsgId;

				S_TbEventAppened.Delete(i);

				return "";
			}

	return GetError("EV004", nClient); // No MTD event happened.
}

GenericMsg * Event_Alert_NewMsgForMTD(c_Moses_Event_Alert_NewMsgForMTD *q, int nClient)
{
	a_Moses_Event_Alert_NewMsgForMTD *m = STNew a_Moses_Event_Alert_NewMsgForMTD;
	m->Error = Event_Alert_NewMsgForMTD(nClient, q->EventId, m->MsgId);
	return m;
}

/////////////////////////////////////////////////////////////////////////////////


static STRING Do_Notify_DISCONNECT_CLIENT(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";
	Notify_DISCONNECT_CLIENT *p_DISCONNECT_CLIENT = (Notify_DISCONNECT_CLIENT *)p;
	int nClient = p_DISCONNECT_CLIENT->nClient;

	/*
	 * ricevo la notifica della sconnessione di un cliente
	 * --> scandisco la tabella degli eventi richiesti e se l'evento
	 * e avvenuti e tolgo il cliente
	 */

	for (int i = 0; i < S_TbEventReq.Size(); i++)
		if (S_TbEventReq[i].nClient == nClient)
		{
			S_TbEventReq.Delete(i);
			break;
		}

	int bFound = 0;
	do
	{
		bFound = 0;
		for (int i = 0; i < S_TbEventAppened.Size(); i++)
			if (S_TbEventAppened[i].nClient == nClient)
			{
				S_TbEventAppened.Delete(i);
				bFound = 1;
				break;
			}
	}
	while (bFound);

	return "";
}

static Notify Notify_DISCONNECT_CLIENT(Notify_DISCONNECT_CLIENT::Id, Do_Notify_DISCONNECT_CLIENT);

#endif
