#include <st_dbnew.h>
#ifndef __ART_h__
#define __ART_h__

#include <moses.h>

GenericMsg * ART_Add(class c_Moses_ART_Add                     *, int nClient);
GenericMsg * ART_Delete(class c_Moses_ART_Delete               *, int nClient);
GenericMsg * ART_Modify(class c_Moses_ART_Modify               *, int nClient);
GenericMsg * ART_InAddress(class c_Moses_ART_InAddress         *, int nClient);
GenericMsg * ART_List(class c_Moses_ART_List                   *, int nClient);
GenericMsg * ART_ListAddresses(class c_Moses_ART_ListAddresses *, int nClient);
GenericMsg * ART_ListUsers(class c_Moses_ART_ListUsers         *, int nClient);
GenericMsg * ART_OutAddress(class c_Moses_ART_OutAddress       *, int nClient);


STRING ART_OutAddress(
		int nClient, 
		STRING User,
		STRING MailBoxType, 
		STRING &out_MailBoxType, 
		STRING &out_MailBoxAddress, 
		STRING &out_Subject);

#endif
