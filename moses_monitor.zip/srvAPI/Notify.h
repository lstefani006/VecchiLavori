#ifndef __Notify_h__
#define __Notify_h__

#include <st_dbnew.h>

#include "serlzer.h"

class NotifyData
{
public:
	NotifyData(int nc) { nClient = nc; }
	virtual ~NotifyData() {}
	typedef char *ID;
	virtual ID GetType() const = 0;
	int nClient;
};

class Notify
{
public:
	typedef STRING (*fNotify)(NotifyData *, STRING &out_rmks);

	Notify(NotifyData::ID Type, fNotify f);

	static VECT<STRING> DoNotify(NotifyData *p);

private:
	struct Table
	{
		NotifyData::ID m_Type;      // tipo di notifica es MB
		fNotify        m_f;
	};

	static Table tb[];
	static int   top;
};

////////////////////////////////////////////////////////////////////////

/*
 * cancellazione fisica di una mb con tutti i messaggi i folder
 */
class Notify_MB_PHI_DEL : public NotifyData
{
public:
	Notify_MB_PHI_DEL(int nc, const STRING &mb) : NotifyData(nc), MailboxName(mb) {}
	STRING MailboxName;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * cancellazione fisica dei folder/messaggi cancellati logicamente
 */
class Notify_MB_PHI_PURGE : public NotifyData
{
public:
	Notify_MB_PHI_PURGE(int nc, const STRING &mb) : NotifyData(nc), MailboxName(mb) {}
	STRING MailboxName;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica cancellazione fisica di un folder
 */
class Notify_MB_FOLDER_PHI_DEL : public NotifyData
{
public:
	Notify_MB_FOLDER_PHI_DEL(int nc, const STRING &mb, const STRING &folder)
		: NotifyData(nc), MailboxName(mb), Folder(folder) {}
	STRING MailboxName;
	STRING Folder;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica fisica di un folder e messaggi di un folder cancellati logicamente
 */
class Notify_MB_FOLDER_PHI_PURGE : public NotifyData
{
public:
	Notify_MB_FOLDER_PHI_PURGE(int nc, const STRING &mb, const STRING &folder)
		: NotifyData(nc), MailboxName(mb), Folder(folder) {}
	STRING MailboxName;
	STRING Folder;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * cancellazione logica di un folder
 */
class Notify_MB_FOLDER_LOG_DEL : public NotifyData
{
public:
	Notify_MB_FOLDER_LOG_DEL(int nc, const STRING &mb, const STRING &folder)
		: NotifyData(nc), MailboxName(mb), Folder(folder) {}
	STRING MailboxName;
	STRING Folder;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * undelete logica di un folder
 */
class Notify_MB_FOLDER_LOG_UNDEL : public NotifyData
{
public:
	Notify_MB_FOLDER_LOG_UNDEL(int nc, const STRING &mb, const STRING &folder)
		: NotifyData(nc), MailboxName(mb), Folder(folder) {}
	STRING MailboxName;
	STRING Folder;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica nuovo utente
 */
class Notify_USER_ADD : public NotifyData
{
public:
	Notify_USER_ADD(int nc, const STRING &u, const STRING &defMBox) : NotifyData(nc), User(u), DefaultMBox(defMBox) {}
	STRING User;
	STRING DefaultMBox;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica cancellazione utente
 */
class Notify_USER_PHI_DEL : public NotifyData
{
public:
	Notify_USER_PHI_DEL(int nc, const STRING &u) : NotifyData(nc), User(u) {}
	STRING User;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica nuova lista di distribuzione
 */
class Notify_DL_ADD : public NotifyData
{
public:
	Notify_DL_ADD(int nc, const STRING &u, const STRING &pwd, const STRING &descr) : NotifyData(nc), DLName(u), DLPwd(pwd), DLDescr(descr) {}
	STRING DLName;
	STRING DLPwd;
	STRING DLDescr;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica cancellazione lista di distribuzione
 */
class Notify_DL_PHI_DEL : public NotifyData
{
public:
	Notify_DL_PHI_DEL(int nc, const STRING &u) : NotifyData(nc), DLName(u) {}
	STRING DLName;
	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica di un messaggio in in/out/error
 */
class Notify_MB_MSG_WRITE : public NotifyData
{
public:
	Notify_MB_MSG_WRITE(int nc, const STRING &mb, const STRING &f, INT32 id,
			const STRING &sender, const STRING &dest, const STRING &subj)
		: NotifyData(nc), Mailbox(mb), Folder(f), MsgId(id),
		  Sender(sender), Destination(dest), Subject(subj) {}

	STRING Mailbox;
	STRING Folder;
	INT32  MsgId;
	STRING Sender;
	STRING Destination;
	STRING Subject;

	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica di un messaggio in system/out per MTD
 */
class Notify_MB_MSG_FOR_MTD : public NotifyData
{
public:
	Notify_MB_MSG_FOR_MTD(int nc, const STRING &mt, INT32 id,
			const STRING &sender, const STRING &dest, const STRING &subj)
		: NotifyData(nc), MailType(mt), MsgId(id),
		  Sender(sender), Destination(dest), Subject(subj) {}

	STRING MailType;
	INT32  MsgId;
	STRING Sender;
	STRING Destination;
	STRING Subject;

	static char Id[];
	virtual ID GetType() const { return Id; }
};

/*
 * notifica di una sconnessione di un cliente
 */
class Notify_DISCONNECT_CLIENT : public NotifyData
{
public:
	Notify_DISCONNECT_CLIENT(int nc) : NotifyData(nc) {}

	static char Id[];
	virtual ID GetType() const { return Id; }
};


/*
 * notifica di una connessione di un cliente
 */
class Notify_CONNECT_CLIENT : public NotifyData
{
public:
	Notify_CONNECT_CLIENT(int nc) : NotifyData(nc) {}

	static char Id[];
	virtual ID GetType() const { return Id; }
};


#endif
