#include <st_dbnew.h>
#ifndef __OL_h__
#define __OL_h__

#include <moses.h>

GenericMsg * OL_Set   (class c_Moses_OL_Set *q, int nClient);
GenericMsg * OL_Get   (class c_Moses_OL_Get *q, int nClient);

#endif
