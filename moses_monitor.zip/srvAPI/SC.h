#include <st_dbnew.h>
#ifndef __SC_h__
#define __SC_h__

#include <moses.h>


GenericMsg * Scheduler_Add    (class c_Moses_Scheduler_Add    *q, int nClient);
GenericMsg * Scheduler_Delete (class c_Moses_Scheduler_Delete *q, int nClient);
GenericMsg * Scheduler_List   (class c_Moses_Scheduler_List   *q, int nClient);

// Metodo che esegue il match fra la currentTime e i dati di F_SC_TIME 
// della tabella SC. questo restituisce 0 se non trova nulla altrimenti 1.
int MatchCurrentTime(STRING currentTime,
					 STRING currentWeekDay);

// Metodo che esegue lo Script Iniziale.
int LanciaScriptIniziale();

// Metodo che controlla il formato del campo When dello Svheduler.
int IsOkWhenFormat(STRING fieldWhen);

// Metodo che esegue un'azione oppure Notifica un MTD.
int RunOrNotify(STRING action);

// funzione per inizializzare l'MTD
void Init_EventForMTD(const STRING &When, const STRING &MtdType);

// funzione per settare uno script da lanciare di default
void Init_StartUpScript(const STRING &Action);
#endif
