#include <st_dbnew.h>
#ifndef __tbFile_h__
#define __tbFile_h__

#include <stdio.h>
#include "serlzer.h"

#define LEN_NAME_USER               8
#define LEN_NAME_PWD                8
#define LEN_NAME_MB                 8
#define LEN_NAME_MBTYPE             8
#define LEN_NAME_FOLDER             8
#define LEN_FIELD_SC_WHEN          13
#define LEN_FIELD_DATE_LICENCE     20
#define LEN_FIELD_ACTION          256

class TbFile
{
public:
	/*
	 * costruisce un file sequenziale organizzato in campi; i campi sono a dimensione
	 * massima dichiarata e i valori inseriti vengono espansi con dei blank fino alla dimensione
	 * di ciascun campo. I campi in lettura vengono ritorna senza i blank in coda
	 * Il file viene aperto solo ad ogni operazione di accesso di lettura o scrittura.
	 * Se il file non e` presente file creato al primo accesso
	 * In pPath viene specificato il path necessario per il file.
	 * In pFileName il nome del file.
	 * In dimFields sono specificate le dimensioni dei campi del file
	 * In pkField vengono specificati i campi chive della tabella; i campi chiave settano
	 * ad 1 il bit corrispondente. Usare le funzioni M per settare i bit
	 *
	 * I files sono in chiaro e sono leggibili con un editor
	 * in unix (senza problemi) e in windows con qualche cautela dato che i
	 * record sono separati da un \n e non dall'accoppiata \r\n (apertura in binario)
	 * I record cancellati sono marcati con un asterisco nel primo carattere
	 */
	TbFile(const char *pPath, const char *pFileName, VECT<INT32> &dimFields, int pkField);

	/*
	 * dealloca le risorse 
	 */
	~TbFile();

	/*
	 * Inserisce il record nel file.
	 * Ritorna 1 se ha insersito la riga
	 * 0 se ha trovato un elemento duplicato
	 */
	int  Insert (VECT<STRING> &);

	/*
	 * Update di record.
	 * I record da updatare vengono individuati specificando
	 * o il campo (f da 0 a n-1) e la stringa da cercare
	 * o dai campo (fMask con i bit settati) e le stringhe da cercare inserite nel vettore con
	 * lo stesso ordine dei campi
	 * Il campo inRow contiene tutti i valore del record da updatare.
	 * Ritorna il numero di righe trattate oppure -1 su chiave duplicata
	 */
	int  Update (int f, const STRING &toSearch,     int fMaskOut, VECT<STRING> &inRow);
	int  Update (int fMask, VECT<STRING> &toSearch, int fMaskOut, VECT<STRING> &inRow);

	/*
	 * Delete di record.
	 * I record da cancellare vengono individuati specificando
	 * o il campo (f da 0 a n-1) e la stringa da cercare
	 * o dai campo (fMask con i bit settati) e le stringhe da cercare inserite nel vettore con
	 * lo stesso ordine dei campi
	 * Ritorna il numero di righe cancellate
	 */
	int  Delete (int f, const STRING &toDelete);
	int  Delete (int fMask, VECT<STRING> &toDelete);
	
	/*
	 * Seleziona un record nella tabella
	 * I record viene cercato in base
	 *    il campo e la stringa specificata
	 *    i campi e le stringhe specificate (le strighe devono essere nello stesso
	 *    ordine dei campi)
	 *    tutti i record
	 * il campo offset indica la posizione all'interno del file per iniziare la ricerca
	 * Select ritorna -1 se non ha trovato il record 
	 * o != -1 se il record e` stato letto e memorizzato in outRow
	 */
	long Select(int f, const STRING &toSearch, VECT<STRING> &outRow, long offset);
	long Select(int fMask, VECT<STRING> &toSearch, VECT<STRING> &outRow, long offset);
	long Select(VECT<STRING> &outRow, long offset);
	long Select(int fMask, VECT<STRING> &toSearch, VECT<STRING> &outRow, long offset, int fMaskOrderBy);

	/*
	 * ritorna una riga con tanti campi quanti campi della tabella
	 */
	VECT<STRING> GetEmptyRow() const;

	/*
	 * funzioni per ottenere la maschera di bit partendo dai campi
	 */
	static int M(int a)                              { return 1 << a; }
	static int M(int a, int b)                       { return (1 << a) | (1 << b); }
	static int M(int a, int b, int c)                { return (1 << a) | (1 << b) | (1 << c); }
	static int M(int a, int b, int c, int d)         { return (1 << a) | (1 << b) | (1 << c) | (1 << d); }
	static int M(int a, int b, int c, int d, int e)  { return (1 << a) | (1 << b) | (1 << c) | (1 << d) | (1 << e); }


protected:

	FILE        *m_f;
	char         m_FileName[256];
	VECT<INT32>  m_dimFields;
	int          m_pkField;
	int          m_SzRecord;

	/*
	 * Apre il file
	 */
	void LockFile();

	/*
	 * Chiude il file
	 */
	void UnlockFile();

	/*
	 * ritorna la lunghezza del record
	 */
	int GetRecordSize() { return m_SzRecord; }

	/*
	 * ritorna l'offeset nel record del campo specificato
	 */
	int GetOffset(int f);

	/*
	 * funzioni per riempire i campi di spazi bianchi alla fine
	 * in inserimento (eventualmente la stringa viene troncata)
	 * e per togliere gli spazi bianchi presenti in coda in lettura
	 */
	STRING AddBlanks(int f, const STRING &r);
	static STRING KillBlanks(STRING r);

	/*
	 * Scrive nel file alla posizione corrente il record
	 */
	int OutRow(VECT<STRING> &r);
	int OutRow(VECT<STRING> &r, int fMask, char *);

	/*
	 * funzioni di ricerca a basso livello nel file
	 */
	long SearchRecord(int f, const STRING &toSearch, long start, char *p = NULL);
	long SearchRecord(int fMask, VECT<STRING> &toSearch, long start, char *p = NULL);
	long SearchRecord(long start, char *p = NULL);

	/*
	 * Ricerca del primo record cancellato
	 */
	long SearchRecord();
};


// inizializza le tabelle del DB
void TB_Init(const char *pPath);

extern TbFile *TB_MOSES;
	extern int F_MOSES_Name;  // nome univoco dell'installazione
	extern int F_MOSES_IdMsg;
	extern int F_MOSES_ClientPid;
	extern int F_MOSES_DateLicence;

extern TbFile *TB_MS;
	extern int F_MS_MailBoxType;
	extern int F_MS_MailBoxTypeDescr;

extern TbFile *TB_DL;
	extern int F_DL_DLName;
	extern int F_DL_DLPwd;
	extern int F_DL_DLDescr;

extern TbFile *TB_DLM;
	extern int F_DLM_DLName;
	extern int F_DLM_User;

extern TbFile *TB_USER;
	extern int F_USER_Name;
	extern int F_USER_Pwd;
	extern int F_USER_Type;
	extern int F_USER_Descr;
	extern int F_USER_Rights;
	extern int F_USER_DefaultMBox;
	extern int F_USER_KeyId;

extern TbFile *TB_ITG;
	extern int F_ITG_MailboxName;		// Key
	extern int F_ITG_Folder;		    // Key
	extern int F_ITG_Index;		        // Key
	extern int F_ITG_DelFlag;           // "D" se cancellato "" se Ok
	extern int F_ITG_Message_Dest;
	extern int F_ITG_Message_Source;
	extern int F_ITG_Message_Type;		// Subject
	extern int F_ITG_Message_MSP;		// Action

extern TbFile *TB_ART;
	extern int F_ART_User;				// Key
	extern int F_ART_MailBoxType;		// Key
	extern int F_ART_bInternal;			// Key  "1" se di Internal "0" se external
	extern int F_ART_MailBoxAddress;
	extern int F_ART_Subject;

extern TbFile *TB_MB;
	extern int F_MB_Name;
	extern int F_MB_Descr;
	extern int F_MB_Pwd;
	extern int F_MB_Owner;
	extern int F_MB_Directory;

extern TbFile *TB_MM;
	extern int F_MM_MailboxName;
	extern int F_MM_Type;
	extern int F_MM_Folder;
	extern int F_MM_Name;
	extern int F_MM_Id;
	extern int F_MM_Created;
	extern int F_MM_DelFlag;           // "D" se cancellato "" se Ok
	extern int F_MM_Sender;
	extern int F_MM_Receiver;
	extern int F_MM_Subject;
	extern int F_MM_InOut;
	extern int F_MM_SzBody;
	extern int F_MM_UserField;
	extern int F_MM_Accessed;
	extern int F_MM_Sent;
	extern int F_MM_Dispatched;
	extern int F_MM_Delivered;
	extern int F_MM_Read;

extern TbFile *TB_MSL;
	extern int F_MSL_Name;
	extern int F_MSL_Descr;
	
extern TbFile *TB_Client;
	extern int F_Client_Name;
	extern int F_Client_Descr;
	extern int F_Client_Type;
	extern int F_Client_Active;
	extern int F_Client_Pid;

extern TbFile *TB_SC;
	extern int F_SC_Index;			// Key
	extern int F_SC_Time;
	extern int F_SC_Action;
	
extern TbFile *TB_OL;
	extern int F_OL_DaysAccessed;		
	extern int F_OL_DaysSent;
	extern int F_OL_DaysDispatched;

extern TbFile *TB_ERROR;
	extern int F_ERROR_CodError;	// Key
	extern int F_ERROR_DesError;
	extern int F_ERROR_Language;    // Key

extern TbFile *TB_LANG;
	extern int F_LANG_Cod;			//Key
	extern int F_LANG_Descr;
	
#endif
