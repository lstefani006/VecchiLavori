#include <st_dbnew.h>
#ifndef __MB_h__
#define __MB_h__

#include <moses.h>

// la granularita' dei nuovi messaggi
#define NewId_Step 1


GenericMsg * MB_CheckMailbox   (class c_Moses_MB_CheckMailbox   *, int nClient);
GenericMsg * MB_ChangePassword (class c_Moses_MB_ChangePassword *, int nClient);
GenericMsg * MB_ChangeOwner    (class c_Moses_MB_ChangeOwner    *, int nClient);
GenericMsg * MB_ChangeDescr    (class c_Moses_MB_ChangeDescr    *, int nClient);
GenericMsg * MB_CreateMailbox  (class c_Moses_MB_CreateMailbox  *, int nClient);
STRING MB_CreateMailbox(
		int nClient,
		STRING MailBoxName,
		STRING Owner,
		STRING Pwd,
		STRING Descr);
GenericMsg * MB_ListMailbox    (class c_Moses_MB_ListMailbox    *, int nClient);
GenericMsg * MB_DeleteMailbox  (const STRING &MailBoxName,         int nClient);
GenericMsg * MB_DeleteMailbox  (class c_Moses_MB_DeleteMailbox  *, int nClient);

GenericMsg * MB_CreateFolder   (class c_Moses_MB_CreateFolder   *, int nClient);
GenericMsg * MB_DeleteFolder   (class c_Moses_MB_DeleteFolder   *, int nClient);
GenericMsg * MB_ListFolder     (class c_Moses_MB_ListFolder     *, int nClient);
GenericMsg * MB_UndeleteFolder (class c_Moses_MB_UndeleteFolder *, int nClient);
GenericMsg * MB_WriteInFolder  (class c_Moses_MB_WriteInFolder  *, int nClient);
GenericMsg * MB_ListMsg        (class c_Moses_MB_ListMsg        *, int nClient);
GenericMsg * MB_GetInfo        (class c_Moses_MB_GetInfo        *, int nClient);
GenericMsg * MB_SetInfo        (class c_Moses_MB_SetInfo        *, int nClient);
GenericMsg * MB_SetInfoEx      (class c_Moses_MB_SetInfoEx      *, int nClient);
GenericMsg * MB_MsgRead        (class c_Moses_MB_MsgRead        *, int nClient);
GenericMsg * MB_MsgFile        (class c_Moses_MB_MsgFile        *, int nClient);
GenericMsg * MB_Msg_Delete     (class c_Moses_MB_Msg_Delete     *, int nClient);
GenericMsg * MB_MoveMsg        (class c_Moses_MB_MoveMsg        *, int nClient);
GenericMsg * MB_MoveMsg2       (class c_Moses_MB_MoveMsg2       *, int nClient);
GenericMsg * MB_Set_Userfield  (class c_Moses_MB_Set_Userfield  *, int nClient);
GenericMsg * MB_Get_Userfield  (class c_Moses_MB_Get_Userfield  *, int nClient);
GenericMsg * MB_ListAllMsg     (class c_Moses_MB_ListAllMsg     *, int nClient);
GenericMsg * MB_UndeleteMsg    (class c_Moses_MB_UndeleteMsg    *, int nClient);
GenericMsg * MB_Purge          (class c_Moses_MB_Purge          *, int nClient);
GenericMsg * MB_GetNewMsgId    (class c_Moses_MB_GetNewId       *, int nClient);
GenericMsg * Log_NewMsgId      (class c_Moses_Log_NewMsgId      *, int nClient);

int InitMTD();

#endif
