#include <st_dbnew.h>
#ifndef __DL_h__
#define __DL_h__

#include <moses.h>


GenericMsg * DL_Add    (class c_Moses_DL_Add    *q, int nClient);
GenericMsg * DL_Delete (class c_Moses_DL_Delete *q, int nClient);
GenericMsg * DL_List   (class c_Moses_DL_List   *q, int nClient);
GenericMsg * DL_Modify (class c_Moses_DL_Modify *q, int nClient);

GenericMsg * DL_Member_Add    (class c_Moses_DL_Member_Add    *q, int nClient);
GenericMsg * DL_Member_Delete (class c_Moses_DL_Member_Delete *q, int nClient);
GenericMsg * DL_Member_List   (class c_Moses_DL_Member_List   *q, int nClient);

#endif
