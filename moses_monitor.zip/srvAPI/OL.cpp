#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "OL.h"

#include <m_Moses_OL_Set.h>
#include <m_Moses_OL_Get.h>


GenericMsg * OL_Set(c_Moses_OL_Set *q, int nClient)
{
	a_Moses_OL_Set *m = STNew a_Moses_OL_Set;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> outRow = TB_OL->GetEmptyRow();
		int rr = TB_OL->Select(outRow, 0L);
		if ( rr != -1)
		{
			// Esiste un elemento nella tabella => eseguo una delete
			cerr<<"Esiste un elemento nella tabella => eseguo una delete"<<endl;
			cerr<<"GG.: "<<outRow[F_OL_DaysAccessed]<<endl;
			int r = TB_OL->Delete(TbFile::M(F_OL_DaysAccessed, F_OL_DaysSent, F_OL_DaysDispatched),
					outRow);
			if (r == 0)
				m->Error = GetError("OL001", nClient); // Unknown OL.
		}
		else
			cerr<<"Primo Inserimento"<<endl;
		
		VECT<STRING> inRow = TB_OL->GetEmptyRow();
		inRow[ F_OL_DaysAccessed   ] = q->DaysAccessed;
		inRow[ F_OL_DaysSent       ] = q->DaysSent;
		inRow[ F_OL_DaysDispatched ] = q->DaysDispatched;
		
		int r = TB_OL->Insert(inRow);
		if (r == 0)
		{
			m->Error = GetError("OL002", nClient); // OL already present.
		}
	}

	return m;
}

///////////////////////////////////////////////////////////////////////////////
GenericMsg * OL_Get(c_Moses_OL_Get *q, int nClient)
{
	a_Moses_OL_Get *m = STNew a_Moses_OL_Get;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> outVect = TB_OL->GetEmptyRow();

		int r = TB_OL->Select(outVect, 0L);
		
		if ( r == -1 )
			m->Error = GetError("OL003", nClient); // OL Table is Empty.
		else
		{
			m->DaysAccessed    = outVect[ F_OL_DaysAccessed ];
			m->DaysSent        = outVect[ F_OL_DaysSent ];
			m->DaysDispatched  = outVect[ F_OL_DaysDispatched ];
		}
	}
	return m;
}

#endif
