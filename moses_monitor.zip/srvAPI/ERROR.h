#include <st_dbnew.h>
#ifndef __ERROR_h__
#define __ERROR_h__

STRING GetError(STRING codError, int nClient = -1);

void InitTableLANG();

void InitTableERROR();

#endif
