#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include "server.h"
#include "ERROR.h"

STRING GetError(STRING codError, int nClient)
{
	STRING language, err;

	if (nClient == -1)
		language = LINGUA_DEFAULT;
	else
		language = G_pServerData->GetClientLanguage(nClient);

	VECT<STRING> s  = TB_ERROR->GetEmptyRow();
	s[ F_ERROR_CodError ] = codError;
	s[ F_ERROR_Language ] = language;

	long l = TB_ERROR->Select(TbFile::M(F_ERROR_CodError, F_ERROR_Language), s, s, 0L);

	if (l == -1L)
	{
		// Restituisco la des. dell'errore nella lingua di default 
		// altrimenti codice errore sconosciuto.

		VECT<STRING> ss  = TB_ERROR->GetEmptyRow();
		ss[ F_ERROR_CodError ] = codError;
		ss[ F_ERROR_Language ] = LINGUA_DEFAULT;
							
		long ll = TB_ERROR->Select(TbFile::M(F_ERROR_CodError, F_ERROR_Language), ss, ss, 0L);

		if (ll == -1L)
			err = codError & " - Unknown Error Code" ;
		else 
			err = codError & " - " & ss[ F_ERROR_DesError ];
	}
	else
		err = codError & " - " & s[ F_ERROR_DesError ];
	
	return err;
}

//////////////////////////////////////////////////////////////////////////////
void InitTableLANG()
{
	VECT<STRING> codLang;
	VECT<STRING> desLang;

	codLang.Append("UK");
	desLang.Append("Inglese");

	codLang.Append("IT");
	desLang.Append("Italiano");

	codLang.Append("SP");
	desLang.Append("Spagnolo");

	for (int count = 0; count < codLang.Size(); count++)
	{
		VECT<STRING> v = TB_LANG->GetEmptyRow();
		
		v[ F_LANG_Cod  ] = codLang[count];
		v[ F_LANG_Descr] = desLang[count];
			
		TB_LANG->Insert(v);
	}
}

//////////////////////////////////////////////////////////////////////////////
void InitTableERROR()
{
	VECT<STRING> codLang;
	VECT<STRING> codError;
	VECT<STRING> desError;


	/////////////////////////////////////////////////////////////////
	// ART Error Section.
	///////////////////////
	
	codLang.Append ("UK");
	codError.Append("ART001");
	desError.Append("User already present in ART table");

	codLang.Append ("UK");
	codError.Append("ART002");
	desError.Append("User Name not present in USER table");

	codLang.Append ("UK");
	codError.Append("ART003");
	desError.Append("Mail Box Type not present in MS table");

	codLang.Append ("UK");
	codError.Append("ART004");
	desError.Append("Row Not present in ART table");

	codLang.Append ("UK");
	codError.Append("ART005");
	desError.Append("Key duplicate in ART table");

	codLang.Append ("UK");
	codError.Append("ART006");
	desError.Append("User Not present in ART table");

	codLang.Append ("UK");
	codError.Append("ART007");
	desError.Append("User and MailBoxType Not present in ART table");

	codLang.Append ("UK");
	codError.Append("ART008");
	desError.Append("MailBoxType and MailBoxAddress Not present in ART table");

	codLang.Append ("UK");
	codError.Append("ART009");
	desError.Append("Unknown Mail System type");

	codLang.Append ("UK");
	codError.Append("ART010");
	desError.Append("No Users in ART table for the given Mailbox type");

	codLang.Append ("UK");
	codError.Append("ART011");
	desError.Append("Unknown Mail System type");

	codLang.Append ("UK");
	codError.Append("ART012");
	desError.Append("No Mail Addresses in ART table for the given Mailbox Type");

	codLang.Append ("UK");
	codError.Append("ART013");
	desError.Append("Key not  present in ART table for deleting");

	codLang.Append ("UK");
	codError.Append("ART014");
	desError.Append("User Name not present in USER table");

	codLang.Append ("UK");
	codError.Append("ART015");
	desError.Append("User Name not present in USER table");

	/////////////////////////////////////////////////////////////////
	// CLI Error Section.
	///////////////////////
	
	codLang.Append ("UK");
	codError.Append("CLI001");
	desError.Append("Client Name already present");

	codLang.Append ("UK");
	codError.Append("CLI002");
	desError.Append("Unknown Client Name");

	codLang.Append ("UK");
	codError.Append("CLI003");
	desError.Append("Client name not found");

	codLang.Append ("UK");
	codError.Append("CLI004");
	desError.Append("Unknown Client Name");

	codLang.Append ("UK");
	codError.Append("CLI005");
	desError.Append("Cannot run Client");

	codLang.Append ("UK");
	codError.Append("CLI006");
	desError.Append("Cannot Set ClientPid");

	codLang.Append ("UK");
	codError.Append("CLI007");
	desError.Append("Unknown Client Name");

	codLang.Append ("UK");
	codError.Append("CLI008");
	desError.Append("Cannot kill Client");

	codLang.Append ("UK");
	codError.Append("CLI009");
	desError.Append("Cannot Reset ClientPid");

	/////////////////////////////////////////////////////////////////
	// DL Error Section.
	//////////////////////
	
	codLang.Append ("UK");
	codError.Append("DL001");
	desError.Append("Invalid user/password while adding user to distribution list");

	codLang.Append ("UK");
	codError.Append("DL002");
	desError.Append("Distribution list already present");

	codLang.Append ("UK");
	codError.Append("DL003");
	desError.Append("Unknown distribution list");

	codLang.Append ("UK");
	codError.Append("DL004");
	desError.Append("Distribuition list not found");

	codLang.Append ("UK");
	codError.Append("DL005");
	desError.Append("The user not present in the Users list");

	codLang.Append ("UK");
	codError.Append("DL006");
	desError.Append("The user already present in the distribution list");

	codLang.Append ("UK");
	codError.Append("DL007");
	desError.Append("The user is not present in the distribution list");

	codLang.Append ("UK");
	codError.Append("DL008");
	desError.Append("DLName not present in DLM table");

	codLang.Append ("UK");
	codError.Append("DL009");
	desError.Append("The user is not present in the distribution list member");

	/////////////////////////////////////////////////////////////////
	// ITG Error Section.
	////////////////////////
	
	codLang.Append ("UK");
	codError.Append("ITG001");
	desError.Append("Record not found in ITG table");

	codLang.Append ("UK");
	codError.Append("ITG002");
	desError.Append("User already present in ITG table");

	codLang.Append ("UK");
	codError.Append("ITG003");
	desError.Append("The MailBoxName is not present in the ITG Table");

	codLang.Append ("UK");
	codError.Append("ITG004");
	desError.Append("Record not found in ITG table");

	codLang.Append ("UK");
	codError.Append("ITG005");
	desError.Append("Cannot run program on event handler");

	codLang.Append ("UK");
	codError.Append("ITG006");
	desError.Append("The MailBoxName not present in the ITG Table");

	codLang.Append ("UK");
	codError.Append("ITG007");
	desError.Append("The MailBoxName/Folder not present in the ITG Table");

	codLang.Append ("UK");
	codError.Append("ITG008");
	desError.Append("The User of Source not present in the ITG Table");

	codLang.Append ("UK");
	codError.Append("ITG009");
	desError.Append("The User of Destination not present in the ITG Table");

	codLang.Append ("UK");
	codError.Append("ITG010");
	desError.Append("The MailBoxName/Folder logical deleted not present in the ITG Table");

	codLang.Append ("UK");
	codError.Append("ITG011");
	desError.Append("The MailBoxName not present in the ITG Table");

	/////////////////////////////////////////////////////////////////
	// EV Error Section.
	//////////////////////
	
	codLang.Append ("UK");
	codError.Append("EV001");
	desError.Append("Event already registered");

	codLang.Append ("UK");
	codError.Append("EV002");
	desError.Append("MTD Event already registered");

	codLang.Append ("UK");
	codError.Append("EV003");
	desError.Append("No Event happened");

	codLang.Append ("UK");
	codError.Append("EV004");
	desError.Append("No MTD Event happened");

	codLang.Append ("UK");
	codError.Append("EV005");
	desError.Append("Event not registred");

	codLang.Append ("UK");
	codError.Append("EV006");
	desError.Append("Event not appened");

	/////////////////////////////////////////////////////////////////
	// MB Error Section.
	/////////////////////////
	
	codLang.Append ("UK");
	codError.Append("MB001");
	desError.Append("Wrong mailbox / password");

	codLang.Append ("UK");
	codError.Append("MB002");
	desError.Append("Wrong mail box / password");

	codLang.Append ("UK");
	codError.Append("MB003");
	desError.Append("Wrong mail box / password");

	codLang.Append ("UK");
	codError.Append("MB004");
	desError.Append("Mailbox already present");

	codLang.Append ("UK");
	codError.Append("MB005");
	desError.Append("Cannot create mail box directory");

	codLang.Append ("UK");
	codError.Append("MB006");
	desError.Append("Cannot create mail box directory");

	codLang.Append ("UK");
	codError.Append("MB007");
	desError.Append("Cannot delete mail box directory");

	codLang.Append ("UK");
	codError.Append("MB008");
	desError.Append("Cannot delete mailbox");

	codLang.Append ("UK");
	codError.Append("MB009");
	desError.Append("Cannot delete mailbox entries");

	codLang.Append ("UK");
	codError.Append("MB010");
	desError.Append("Wrong mailbox / password");

	codLang.Append ("UK");
	codError.Append("MB011");
	desError.Append("Cannot create folder directory");

	codLang.Append ("UK");
	codError.Append("MB012");
	desError.Append("Cannot create folder");

	codLang.Append ("UK");
	codError.Append("MB013");
	desError.Append("Folder already deleted");

	codLang.Append ("UK");
	codError.Append("MB014");
	desError.Append("Only configuration tool can deleted this folder");

	codLang.Append ("UK");
	codError.Append("MB015");
	desError.Append("Cannot delete folder");

	codLang.Append ("UK");
	codError.Append("MB016");
	desError.Append("Cannot undelete folder");

	codLang.Append ("UK");
	codError.Append("MB017");
	desError.Append("Unknow mailbox/folder");

	codLang.Append ("UK");
	codError.Append("MB018");
	desError.Append("Unknow Folder");

	codLang.Append ("UK");
	codError.Append("MB019");
	desError.Append("Error in File::Write:");

	codLang.Append ("UK");
	codError.Append("MB020");
	desError.Append("Cannot insert message data in MM table");

	codLang.Append ("UK");
	codError.Append("MB021");
	desError.Append("Cannot find a MailType in ART table for this User: MTD not notified");

	codLang.Append ("UK");
	codError.Append("MB022");
	desError.Append("Unknow mailbox/folder");

	codLang.Append ("UK");
	codError.Append("MB023");
	desError.Append("Wrong message identifier");

	codLang.Append ("UK");
	codError.Append("MB024");
	desError.Append("Getting info of a deleted message");

	codLang.Append ("UK");
	codError.Append("MB025");
	desError.Append("Wrong message status");

	codLang.Append ("UK");
	codError.Append("MB026");
	desError.Append("Wrong message identifier");

	codLang.Append ("UK");
	codError.Append("MB027");
	desError.Append("Wrong message identifier");

	codLang.Append ("UK");
	codError.Append("MB028");
	desError.Append("Reading a deleted message");

	codLang.Append ("UK");
	codError.Append("MB029");
	desError.Append("Error in File::Read:");

	codLang.Append ("UK");
	codError.Append("MB030");
	desError.Append("Cannot update access time");

	codLang.Append ("UK");
	codError.Append("MB031");
	desError.Append("Wrong message identifier / deleted message");

	codLang.Append ("UK");
	codError.Append("MB032");
	desError.Append("Wrong message identifier");

	codLang.Append ("UK");
	codError.Append("MB033");
	desError.Append("Trying to move a deleted message");

	codLang.Append ("UK");
	codError.Append("MB034");
	desError.Append("Trying to move a message to a deleted folder");

	codLang.Append ("UK");
	codError.Append("MB035");
	desError.Append("Error in File::Move:");

	codLang.Append ("UK");
	codError.Append("MB036");
	desError.Append("Wrong message identifier");

	codLang.Append ("UK");
	codError.Append("MB037");
	desError.Append("Cannot find a MailType in ART table for this Message: MTD not notified");

	codLang.Append ("UK");
	codError.Append("MB038");
	desError.Append("Wrong message identifier");

	codLang.Append ("UK");
	codError.Append("MB039");
	desError.Append("Wrong message identifier");

	codLang.Append ("UK");
	codError.Append("MB040");
	desError.Append("Wrong message identifier");

	codLang.Append ("UK");
	codError.Append("MB041");
	desError.Append("Mailbox not found");

	codLang.Append ("UK");
	codError.Append("MB042");
	desError.Append("Cannot delete folder");

	codLang.Append ("UK");
	codError.Append("MB043");
	desError.Append("Cannot create mail box directory");

	codLang.Append ("UK");
	codError.Append("MB044");
	desError.Append("Cannot find a MailType");

	codLang.Append ("UK");
	codError.Append("MB045");
	desError.Append("Unknown user");
	////////////////////////////////////////////////////////////////////////
	// MS Error Section.
	///////////////////////
	
	codLang.Append ("UK");
	codError.Append("MS001");
	desError.Append("Mail System Type already present");

	codLang.Append ("UK");
	codError.Append("MS002");
	desError.Append("Unknown Mail System Type");

	/////////////////////////////////////////////////////////////////
	// MSL Error Section.
	////////////////////////
	
	codLang.Append ("UK");
	codError.Append("MSL001");
	desError.Append("Moses Script Name already present");

	codLang.Append ("UK");
	codError.Append("MSL002");
	desError.Append("Unknown Moses Script Name");

	codLang.Append ("UK");
	codError.Append("MSL003");
	desError.Append("Moses Script name not found");

	/////////////////////////////////////////////////////////////////
	// OL Error Section.
	//////////////////////
	
	codLang.Append ("UK");
	codError.Append("OL001");
	desError.Append("Unknown OL");

	codLang.Append ("UK");
	codError.Append("OL002");
	desError.Append("OL already present");

	codLang.Append ("UK");
	codError.Append("OL003");
	desError.Append("OL Table is Empty");

	/////////////////////////////////////////////////////////////////
	// SC Error Section.
	///////////////////// 
	
	codLang.Append ("UK");
	codError.Append("SC001");
	desError.Append("Scheduler already present");

	codLang.Append ("UK");
	codError.Append("SC002");
	desError.Append("Unknown Scheduler");

	codLang.Append ("UK");
	codError.Append("SC003");
	desError.Append("Error in Run of mProcess");

	codLang.Append ("UK");
	codError.Append("SC004");
	desError.Append("Invalid Format for String Describing the Time of Schedulation");

	codLang.Append ("UK");
	codError.Append("SC005");			        // Errore usato solo dal server.
	desError.Append("Error in sscanf for Current Time");

	codLang.Append ("UK");
	codError.Append("SC006");                   // Errore usato solo dal server.
	desError.Append("Error in sscanf for Schedular Time");

	/////////////////////////////////////////////////////////////////
	// US Error Section.
	//////////////////////// 
	
	codLang.Append ("UK");
	codError.Append("US001");
	desError.Append("User already present in user table");

	codLang.Append ("UK");
	codError.Append("US002");
	desError.Append("The user is not present in the user list");

	codLang.Append ("UK");
	codError.Append("US003");
	desError.Append("UserName not found for User_Modify");

	codLang.Append ("UK");
	codError.Append("US004");
	desError.Append("Mailbox not found in User table");

	/////////////////////////////////////////////////////////////////
	// G section.
	//////////////// 
	
	codLang.Append ("UK");
	codError.Append("G001");
	desError.Append("Only configuration tool can run this API");

	codLang.Append ("UK");
	codError.Append("G002");
	desError.Append("Invalid user/password");

	codLang.Append ("UK");
	codError.Append("G003");
	desError.Append("Invalid User Name");

	codLang.Append ("UK");
	codError.Append("G004");
	desError.Append("Invalid Password");

	codLang.Append ("UK");
	codError.Append("G005");
	desError.Append("Invalid Mailbox Name");

	codLang.Append ("UK");
	codError.Append("G006");
	desError.Append("Invalid Mailbox Type");

	codLang.Append ("UK");
	codError.Append("G007");
	desError.Append("Invalid Folder");

	codLang.Append ("UK");
	codError.Append("G008");
	desError.Append("Index out of range");

	/////////////////////////////////////////////////////////////////
	// MON (Monitor) section. 
	////////////////////////// 
	
	codLang.Append ("UK");
	codError.Append("MON001");					// Errore usato solo dal server.
	desError.Append("Run Process Failed");

	/////////////////////////////////////////////////////////////////
	// LIC (Licence) section. 
	////////////////////////// 
	
	codLang.Append ("UK");
	codError.Append("LIC001");
	desError.Append("Update Date of Licence Failed");

	codLang.Append ("UK");
	codError.Append("LIC002");
	desError.Append("Moses Table is Empty");

	codLang.Append ("UK");					
	codError.Append("LIC003");					// Errore usato solo dal server.
	desError.Append("Moses Table is Empty");

	codLang.Append ("UK");
	codError.Append("LIC004");					// Errore usato solo dal server.
	desError.Append("Exipered Licence");


	for (int count = 0; count < codError.Size(); count++)
	{
		VECT<STRING> v = TB_ERROR->GetEmptyRow();
		v[ F_ERROR_Language ] = codLang [count];
		v[ F_ERROR_CodError ] = codError[count];
		v[ F_ERROR_DesError ] = desError[count];

		TB_ERROR->Insert(v);
	}
}


#endif
