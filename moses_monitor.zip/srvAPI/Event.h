#include <st_dbnew.h>
#ifndef __Event_h__
#define __Event_h__

#include <moses.h>
// STRING Event_NewMsgInFolder(int nClient, const STRING &MailboxName, const STRING &Folder, INT32 &out_EventId);
GenericMsg * Event_NewMsgInFolder(class c_Moses_Event_NewMsgInFolder *q, int nClient);
GenericMsg * Event_Alert_NewMsgInFolder(class c_Moses_Event_Alert_NewMsgInFolder *q, int nClient);
GenericMsg * Event_NewMsgForMTD(class c_Moses_Event_NewMsgForMTD *q, int nClient);
GenericMsg * Event_Alert_NewMsgForMTD(class c_Moses_Event_Alert_NewMsgForMTD *q, int nClient);
GenericMsg * Event_Delete(class c_Moses_Event_Delete *q, int nClient);
GenericMsg * Event_GetEvent(class c_Moses_Event_GetEvent *q, int nClient);


/*
 * Struttura che memorizza il tipo di evento impostato da un client
 */

struct EventReq
{
	int nClient;
	int EventId;

	STRING Mailbox, Folder;   // un tipo di evento
	STRING Mt;                // altro tipo di evento

	EventReq()
	{
		nClient = 0;
		EventId = 0;
	}

	EventReq(int nc, int ev, const STRING &mb, const STRING &fd)
	{
		nClient = nc;
		EventId = ev;
		Mailbox = mb;
		Folder = fd;
	}
	EventReq(int nc, int ev, const STRING &mt)
	{
		nClient = nc;
		EventId = ev;
		Mt      = mt;
	}
};



/*
 * Struttura che memorizza gli eventi in attesa di essere consegnati al
 * client che ne fa richiesta
 */
struct EventAppened
{
	int    nClient;
	int    EventId;
	INT32  MsgId;
	STRING Folder;

	EventAppened()
	{
		nClient = 0;
		EventId = 0;
		MsgId   = 0;
	}

	EventAppened(int nc, int ev, INT32 mi, STRING fd)
	{
		nClient = nc;
		EventId = ev;
		MsgId   = mi;
		Folder  = fd;
	}

	EventAppened(int nc, int ev, INT32 mi)
	{
		nClient = nc;
		EventId = ev;
		MsgId   = mi;
		Folder  = "";
	}
};



#endif
