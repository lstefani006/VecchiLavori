#include <st_dbnew.h>
#ifndef __FM_h__
#define __FM_h__

#include <moses.h>

GenericMsg * FM_ListFile (class c_Moses_FM_ListFile  *, int nClient);
GenericMsg * FM_GetFile  (class c_Moses_FM_GetFile   *, int nClient);
GenericMsg * FM_PutFile  (class c_Moses_FM_PutFile   *, int nClient);

#endif
