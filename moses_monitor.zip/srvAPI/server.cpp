#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <string.h>
#include <stdio.h>

#include "tcp_net.h"
#include "server.h"
#include <ERROR.h>
#include <Notify.h>
#include <User.h>

#include <ctype.h>

int StrEq(const char *a, const char *b)
{
        for (;;)
        {
                char ca = tolower(*a);
                char cb = tolower(*b);

                if (ca != cb)
                        return 0;

                if (ca == '\0')
                        return 1;

                a++;
                b++;
        }
}



ServerData *G_pServerData = NULL;

STRING ServerData::CfgClient("CFG");
STRING ServerData::MTDClient("MTD");
STRING ServerData::AppClient("APP");

void ServerData::NewConnection(int nClient)
{
	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == -1)
		{
			m_ListConnected[i] = Connection(nClient, "", LINGUA_DEFAULT, STRING(m_pTcpServer->GetAddr(nClient)));
			break;
		}

	if (i == m_ListConnected.Size())
		m_ListConnected.Append(Connection(nClient, "", LINGUA_DEFAULT, STRING(m_pTcpServer->GetAddr(nClient))));


	/*
	 * Notifico la connessione
	 */
	Notify::DoNotify(STNew Notify_CONNECT_CLIENT(nClient));
}

void ServerData::CloseConnection(int nClient)
{
	/*
	 * Notifico la sconnessione prima di pulire l'entry relativo
	 * al client in sconnessione: in questo modo i dati del cliente
	 * sono ancora rintracciabili
	 */
	Notify::DoNotify(STNew Notify_DISCONNECT_CLIENT(nClient));

	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == nClient)
		{
			m_ListConnected[i].m_nClient = -1;
			break;
		}
}


/*
 * Il cliente -1 (in pratica il cliente non connesso --> il monitor stesso)
 */
STRING ServerData::GetClientType(int nClient)
{
	if (nClient == -1)
		return CfgClient;

	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == nClient)
		{
			return m_ListConnected[i].m_ClientType;
			break;
		}

	return "";
}

STRING ServerData::GetClientLanguage(int nClient)
{
	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == nClient)
		{
			return m_ListConnected[i].m_Language;
			break;
		}

	return LINGUA_DEFAULT;
}

STRING ServerData::GetClientUserName(int nClient)
{
	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == nClient)
		{
			return m_ListConnected[i].m_User;
			break;
		}

	return "#";
}

void ServerData::SetClientType(int nClient, const STRING &t)
{
	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == nClient)
		{
			m_ListConnected[i].m_ClientType = t;
			break;
		}
}
void ServerData::SetClientUserName(int nClient, const STRING &u)
{
	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == nClient)
		{
			m_ListConnected[i].m_User = u;
			break;
		}
}

void ServerData::SetClientLanguage(int nClient, const STRING &lang)
{
	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == nClient)
		{
			m_ListConnected[i].m_Language = lang;
			break;
		}
}


STRING ServerData::GetTcpAddr(int nClient)
{
	STRING r;

	for (int i = 0; i < m_ListConnected.Size(); i++)
		if (m_ListConnected[i].m_nClient == nClient)
			r = m_ListConnected[i].m_TcpAddr;

	return r;
}

int ServerData::Check_R(int nClient, STRING &Error)
{
	if (!IsCfgClient(nClient))
	{
		Error = GetError("G001", nClient); // Only configuration tool can run this API.
		return 0;
	}
	return 1;
}


int ServerData::IsCfgClient(int nClient)
{
	return GetClientType(nClient) == CfgClient ||
			GetClientType(nClient) == MTDClient;
}

int ServerData::IsMTDClient(int nClient)
{
	return GetClientType(nClient) == MTDClient;
}

int ServerData::IsAppClient(int nClient)
{
	return GetClientType(nClient) == AppClient;
}


STRING ServerData::GetFilledAction(const STRING &Action)
{
	char b[512];
	char out[512];

	strcpy(b, Action.Str());
	out[0] = 0;

	char *seps = " \t";

	const char *token = strtok(b, seps);
	while (token)
	{
		if (StrEq(token, "$msl"))
		{
			strcat(out, m_Msl.Str());
		}
		else
		if (StrEq(token, "$Login_CFG"))
		{
			STRING Login, Pwd;
			User_GetCFG(Login, Pwd);
			strcat(out, Login.Str());
		}
		else
		if (StrEq(token, "$Pwd_CFG"))
		{
			STRING Login, Pwd;
			User_GetCFG(Login, Pwd);
			strcat(out, Pwd.Str());
		}
		else
		if (StrEq(token, "$LocalHost"))
		{
			strcat(out, m_LocalHost.Str());
		}
		else
		if (StrEq(token, "$Port"))
		{
			char b[20];
			sprintf(b, "%d", m_nPort);
			strcat(out, b);
		}
		else
		{
			strcat(out, token);
		}

		strcat(out, " ");

		token = strtok(NULL, seps);
	}

	return out;

}


#endif
