#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "User.h"
#include "MB.h"
#include "Notify.h"

#include <m_Moses_MB_DeleteMailbox.h>
#include <m_Moses_User_Add.h>
#include <m_Moses_User_Delete.h>
#include <m_Moses_User_List.h>
#include <m_Moses_User_Modify.h>
#include <m_Moses_User_ChangePassword.h>

int User_Exists (const STRING &UserName)
{
	VECT<STRING> o;	
	long l = 0L;

	l = TB_USER->Select(F_USER_Name, UserName, o, l);
	return l != -1 ;
}


int UserExternal_Exists (const STRING &UserName)
{
	VECT<STRING> o = TB_USER->GetEmptyRow();	
	o[ F_USER_Name        ] = UserName;
	o[ F_USER_DefaultMBox ] = "";

	long l = TB_USER->Select(TbFile::M(F_USER_Name, F_USER_DefaultMBox), o, o, 0L);
	return l != -1 ;
}


/*
 * Ricerca di un utente interno --> con DefaultMBox != ""
 * Le routine del DB non consentono di fare una ricerca su un campo != ""
 * --> controllo se esiste un utente e se non e' esterno
 * */
int UserInternal_Exists (const STRING &UserName)
{
	if (!User_Exists(UserName))
		return 0;

	if (UserExternal_Exists(UserName))
		return 0;

	return 1;
}

int User_GetCFG (STRING &Login, STRING &Pwd)
{
	VECT<STRING> o = TB_USER->GetEmptyRow();	
	o[ F_USER_Type        ] = "CFG";

	long l = TB_USER->Select(TbFile::M(F_USER_Type), o, o, 0L);

	Login = o[F_USER_Name];
	Pwd   = o[F_USER_Pwd];
	return l != -1 ;
}


GenericMsg * User_Add(c_Moses_User_Add *q, int nClient)
{
	a_Moses_User_Add *m = STNew a_Moses_User_Add;

	// Eseguo il controllo di validita' sul Name, Password e della Defailt Mailbox dell'User.
	if ( ! q->UserName.IsIdentifier(LEN_NAME_USER) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User.
		return m;
	}

	if ( ! q->UserPwd.IsIdentifier(LEN_NAME_PWD), 0 )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	if ( ! q->UserDefaultMBox.IsIdentifier(LEN_NAME_MB, 0 /* bNotNull */ ) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if (G_pServerData->Check_R(nClient, m->Error))
	{	
		VECT<STRING> i = TB_USER->GetEmptyRow();
		i[ F_USER_Name        ] = q->UserName;
		i[ F_USER_Pwd         ] = q->UserPwd;
		i[ F_USER_Type        ] = q->UserClientType;
		i[ F_USER_Descr       ] = q->UserDescr;
		i[ F_USER_Rights      ] = q->UserRights;
		i[ F_USER_DefaultMBox ] = q->UserDefaultMBox;
		i[ F_USER_KeyId       ] = q->UserKeyId;

		int r = TB_USER->Insert(i);
		if (r == 0)
			m->Error = GetError("US001", nClient); // User already present in user table.

		if (r == 1)
			Notify::DoNotify(STNew Notify_USER_ADD(nClient, q->UserName, q->UserDefaultMBox));
	}
	return m;
}


GenericMsg * User_Delete(c_Moses_User_Delete *q, int nClient)
{
	a_Moses_User_Delete * m = STNew a_Moses_User_Delete;

	// Eseguo il controllo di validita' sul Name dell'User.
	if ( ! q->UserName.IsIdentifier(LEN_NAME_USER) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User.
		return m;
	}

	if (G_pServerData->Check_R(nClient, m->Error))
	{	
		VECT<STRING> d = TB_USER->GetEmptyRow();
		d[ F_USER_Name ] = q->UserName;
		int r = TB_USER->Delete(TbFile::M(F_USER_Name), d);
		if (r == 0)
			m->Error = GetError("US002", nClient); // The user is not present in the user list.

		if (r != 0 && q->bCascade)
			Notify::DoNotify(STNew Notify_USER_PHI_DEL(nClient, q->UserName));
	}
	return m;
}


GenericMsg * User_List(c_Moses_User_List *q, int nClient)
{
	a_Moses_User_List *m = STNew a_Moses_User_List;

	// Nessun controllo di validita'.


	int bCfg = G_pServerData->Check_R(nClient, m->Error);
	m->Error = "";

	{	
		VECT<STRING> o;	

		long l = 0L;
		int nFound = 0;
		while ((l = TB_USER->Select(o, l)) != -1)
		{
			if (nFound == q->Index)
			{
				          m->Valid = 1;
				          m->UserName        = o[ F_USER_Name        ];
				if (bCfg) m->UserPwd         = o[ F_USER_Pwd         ]; 
				if (bCfg) m->UserClientType  = o[ F_USER_Type        ];
				          m->UserDescr       = o[ F_USER_Descr       ];
				if (bCfg) m->UserRights      = o[ F_USER_Rights      ];
				          m->UserDefaultMBox = o[ F_USER_DefaultMBox ]; 
				if (bCfg) m->UserKeyId       = o[ F_USER_KeyId       ];

				return m;
			}
			nFound++;
		}

		m->Valid = 0;
	}
	return m;
}



GenericMsg * User_Modify(c_Moses_User_Modify *q, int nClient)
{
	a_Moses_User_Modify * m = STNew a_Moses_User_Modify;

	// Eseguo il controllo di validita' sul Name, Password e della Defailt Mailbox dell'User.
	if ( ! q->UserName.IsIdentifier(LEN_NAME_USER) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User.
		return m;
	}

	if ( ! q->UserPwd.IsIdentifier(LEN_NAME_PWD), 0 /* bNotNull */)
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	if ( ! q->UserDefaultMBox.IsIdentifier(LEN_NAME_MB), 0 /* bNotNull */ )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> i = TB_USER->GetEmptyRow();
		i[ F_USER_Pwd         ] = q->UserPwd;
		i[ F_USER_Descr       ] = q->UserDescr;
		i[ F_USER_Rights      ] = q->UserRights;
		i[ F_USER_DefaultMBox ] = q->UserDefaultMBox;
		i[ F_USER_KeyId       ] = q->UserKeyId;


		int r = TB_USER->Update(F_USER_Name, 
				q->UserName, 
				TbFile::M(F_USER_Pwd, F_USER_Descr, F_USER_Rights, F_USER_DefaultMBox, F_USER_KeyId), 
				i);

		if (r == 0 || r == -1)
			m->Error = GetError("US003", nClient); // UserName not found for User_Modify.

		if (r == 1)
			Notify::DoNotify(STNew Notify_USER_ADD(nClient, q->UserName, q->UserDefaultMBox));
	}
	return m;
}

////////////////////////////////////////////////////////////////////////////////

GenericMsg * User_ChangePassword(c_Moses_User_ChangePassword *q, int nClient)
{
	a_Moses_User_ChangePassword * m = STNew a_Moses_User_ChangePassword;

	// Eseguo il controllo di validita' sul Name, Password e della Defailt Mailbox dell'User.
	if ( ! q->User.IsIdentifier(LEN_NAME_USER) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User.
		return m;
	}

	if ( ! q->PwdOld.IsIdentifier(LEN_NAME_PWD), 0 /* bNotNull */)
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	if ( ! q->PwdNew.IsIdentifier(LEN_NAME_PWD), 0 /* bNotNull */)
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	int bCfg = G_pServerData->Check_R(nClient, m->Error);
	m->Error = "";

	{
		VECT<STRING> i = TB_USER->GetEmptyRow();
		i[ F_USER_Name        ] = q->User;
		i[ F_USER_Pwd         ] = q->PwdOld;

		VECT<STRING> o = TB_USER->GetEmptyRow();
		o[ F_USER_Name        ] = q->User;
		o[ F_USER_Pwd         ] = q->PwdNew;

		int r = TB_USER->Update(
			TbFile::M(F_USER_Name, (bCfg ? 0 : F_USER_Pwd )),
				i,
				TbFile::M(F_USER_Pwd), 
				o);

		if (r == 0 || r == -1)
			m->Error = GetError("G003", nClient);    // Invalid User.
	}
	return m;
}

////////////////////////////////////////////////////////////////////////////////

/*
 * Quando viene cancellata una mail box la tabella degli
 * users viene aggiornata cancellando dal campo DefaultMBox 
 * la mail box
 */
static STRING Do_Notify_MB_PHI_DEL(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "USER :-";

	Notify_MB_PHI_DEL *p_MB_PHI_DEL = (Notify_MB_PHI_DEL *)p;

	STRING Error;

	if (G_pServerData->Check_R(p_MB_PHI_DEL->nClient, Error))
	{
		VECT<STRING> i = TB_USER->GetEmptyRow();
		i[ F_USER_DefaultMBox ] = p_MB_PHI_DEL->MailboxName;

		VECT<STRING> o = TB_USER->GetEmptyRow();
		o[ F_USER_DefaultMBox ] = "";

		int r = TB_USER->Update(
				TbFile::M(F_USER_DefaultMBox), i,
				TbFile::M(F_USER_DefaultMBox), o);

		if (r == -1)
			Error = GetError("US004", p_MB_PHI_DEL->nClient); // Mailbox not found in User table.
	}
	return Error;
}

static Notify Notify_DeleteMailbox(Notify_MB_PHI_DEL::Id, Do_Notify_MB_PHI_DEL);


#endif
