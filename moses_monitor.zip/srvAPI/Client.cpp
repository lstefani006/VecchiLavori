#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "Client.h"
#include "Notify.h"
#include "mprocess.h"

#include <m_Moses_Client_Add.h>
#include <m_Moses_Client_Delete.h>
#include <m_Moses_Client_List.h>
#include <m_Moses_Client_Modify.h>
#include <m_Moses_Client_Run.h>
#include <m_Moses_Client_Kill.h>
#include <m_Moses_Client_RunningList.h>


GenericMsg * Client_Add(c_Moses_Client_Add *q, int nClient)
{
	a_Moses_Client_Add *m = STNew a_Moses_Client_Add;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> d = TB_Client->GetEmptyRow();
		d[ F_Client_Name ] 	= q->ClientName;
		d[ F_Client_Descr] 	= q->ClientDescr;
		d[ F_Client_Type ] 	= q->ClientType;

		STRING act;
		if (q->Active == 1)
			act = "A";   // 1 => Active.
		else
	        act = " ";   // 0 => Inactive.
	    d[ F_Client_Active] = act;
								
		int r = TB_Client->Insert(d);
		if (r == 0)
			m->Error = GetError("CLI001", nClient); // Client Name already present.
	}
	return m;
}

GenericMsg * Client_Delete(c_Moses_Client_Delete *q, int nClient)
{
	a_Moses_Client_Delete *m = STNew a_Moses_Client_Delete;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		int r = TB_Client->Delete(F_Client_Name, q->ClientName);
		if (r == 0)
			m->Error = GetError("CLI002"), nClient; // Unknown Client Name.
	}
	return m;
}

GenericMsg * Client_List(c_Moses_Client_List *q, int nClient)
{
	a_Moses_Client_List *m = STNew a_Moses_Client_List;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> out_Name_Pwd_Descr;

		long l = 0;
		while ((l = TB_Client->Select(out_Name_Pwd_Descr, l)) != -1)
		{
			STRING ClientName = G_pServerData->GetFilledAction(out_Name_Pwd_Descr[F_Client_Name]);
			m->ClientNameList.Append  (ClientName);
			m->ClientDescrList.Append (out_Name_Pwd_Descr[F_Client_Descr]);
			m->ClientTypeList.Append  (out_Name_Pwd_Descr[F_Client_Type]);

			INT16 act;
			if (out_Name_Pwd_Descr[F_Client_Active] == "A")
				act = 1;   // 1 => Active.
			else
	    	    act = 0;   // 0 => Inactive.

			m->ActiveList.Append 	(act);
		}

		// non c'e` mai errore
	}

	return m;
}

GenericMsg * Client_RunningList(c_Moses_Client_RunningList *q, int nClient)
{
	a_Moses_Client_RunningList *m = STNew a_Moses_Client_RunningList;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> out_Name_Pwd_Descr;

		long l = 0;
		while ((l = TB_Client->Select(out_Name_Pwd_Descr, l)) != -1)
		{

			if (out_Name_Pwd_Descr[F_Client_Pid].GetINT32() != 0)
				m->ClientNameList.Append  (out_Name_Pwd_Descr[F_Client_Name]);
		}

		// non c'e` mai errore
	}

	return m;
}

GenericMsg * Client_Modify(c_Moses_Client_Modify *q, int nClient)
{
	a_Moses_Client_Modify *m = STNew a_Moses_Client_Modify;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> i = TB_Client->GetEmptyRow();
		i[ F_Client_Descr ] = q->ClientDescr;
		i[ F_Client_Type ] 	= q->ClientType;
		
		STRING act;
		if (q->Active == 1)
			act = "A";   // 1 => Active.
		else
	        act = " ";   // 0 => Inactive.
	    i[ F_Client_Active      ] = act;

		int r = TB_Client->Update(F_Client_Name, q->ClientName, 
				TbFile::M(F_Client_Descr,F_Client_Type,F_Client_Active), i);

		if (r == 0 || r == -1)
			m->Error = GetError("CLI003"), nClient; // Client name not found.
	}
	return m;
}

GenericMsg * Client_Run(c_Moses_Client_Run *q, int nClient)
{
	a_Moses_Client_Run *m = STNew a_Moses_Client_Run;
	mProcess Proc;

	VECT<STRING> out;
	VECT<STRING> InValue = TB_Client->GetEmptyRow();

	int r = TB_Client->Select(F_Client_Name, q->ClientName, out, 0L);

	if (r == -1)
		m->Error = GetError("CLI004", nClient); // Unknown Client Name.
	else
	{
		STRING Action = G_pServerData->GetFilledAction(q->ClientName);
		int r = Proc.Run(Action.Str() /* OK con GetFilledAction */);
		if (!r)
			m->Error = GetError("CLI005"), nClient; // Cannot run Client.
		else
		{
			InValue[F_Client_Pid] = STRING::Set(Proc.GetPid());
			int r = TB_Client->Update(F_Client_Name, q->ClientName,
					TbFile::M(F_Client_Pid), InValue);
			if ((r==0) || (r==-1))
				m->Error = GetError("CLI006", nClient); // Cannot Set ClientPid.
		}
	}
	return m;
}

GenericMsg * Client_Kill(c_Moses_Client_Kill *q, int nClient)
{
	a_Moses_Client_Kill *m = STNew a_Moses_Client_Kill;
	mProcess Proc;

	VECT<STRING> out;
	VECT<STRING> InValue = TB_Client->GetEmptyRow();

	int r = TB_Client->Select(F_Client_Name, q->ClientName, out, 0L);

	if (r == -1)
		m->Error = GetError("CLI007", nClient); // Unknown Client Name.
	else
	{
		Proc.SetPid(q->ClientPid);
		int r = Proc.Kill();
		if (!r)
			m->Error = GetError("CLI008", nClient); // Cannot kill Client.
		else
		{
			InValue[F_Client_Pid] = "0";
			int r = TB_Client->Update(F_Client_Name, q->ClientName,
					TbFile::M(F_Client_Pid), InValue);
			if ((r==0) || (r==-1))
				m->Error = GetError("CLI009", nClient); // Cannot Reset ClientPid.
		}
	}
	return m;
}


////////////////////////////////////////////////////////////////////////

#endif
