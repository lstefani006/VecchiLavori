#include <st_dbnew.h>
#ifndef __server_h__
#define __server_h__

#include "serlzer.h"

#define LINGUA_DEFAULT "UK"

struct ServerData
{
	STRING m_MosesName;     // stringa usata in TB_MOSES
	STRING m_MB_RootPath;
	STRING m_CfgPath;
	STRING m_LocalHost;
	int    m_nPort;
	STRING m_Msl;           // path completo di msl
	int    m_bSessionClosed;  // flag che indica sessioni chiuse
	class TcpServer *m_pTcpServer;

	struct Connection
	{
		Connection() { m_nClient = -1; }
		Connection(int nClient, const STRING &t, const STRING &lng, STRING &tcpaddr)
		{
			m_nClient = nClient;
			m_ClientType = t;
			m_Language = lng;
			m_User = "#"; // utente che non esiste
			m_TcpAddr = tcpaddr;
		}

		int    m_nClient;
		STRING m_ClientType;
		STRING m_Language;
		STRING m_User;
		STRING m_TcpAddr;
	};

	VECT<Connection> m_ListConnected;


	ServerData() { m_pTcpServer = NULL; m_bSessionClosed=0; }

	int IsServerClosed() const { return m_bSessionClosed; }
	void SetSession(int f) { m_bSessionClosed=f; }
	
	void SetTcpServer(TcpServer *p) { m_pTcpServer = p; }

	void   NewConnection(int nClient);
	void   CloseConnection(int nClient);

	STRING GetClientType(int nClient);
	STRING GetClientLanguage(int nClient);
	STRING GetClientUserName(int nClient);
	STRING GetTcpAddr(int nClient);

	/*
	 * Se il cliente e' -1 --> typo == CFG
	 */
	void   SetClientType(int nClient, const STRING &type);
	void   SetClientLanguage(int nClient, const STRING &lang);
	void   SetClientUserName(int nClient, const STRING &UserName);

	int Check_R(int nClient, STRING &Error);

	int IsCfgClient(int nClient);
	int IsMTDClient(int nClient);
	int IsAppClient(int nClient);


	static STRING CfgClient;
	static STRING MTDClient;
	static STRING AppClient;


	STRING GetFilledAction(const STRING &Action);
};

extern ServerData *G_pServerData;

#endif
