#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <string.h>

#include <tbFile.h>
#include <server.h>
#include <mtime.h>
#include <ERROR.h>

#include "Licence.h"

#include <m_Moses_Licence_Set.h>
#include <m_Moses_Licence_Get.h>


GenericMsg * Licence_Set(c_Moses_Licence_Set *q, int nClient)
{
	a_Moses_Licence_Set *m = STNew a_Moses_Licence_Set;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		if (q->Pwd == "SetLicence")
		{
			VECT<STRING> moses     = TB_MOSES->GetEmptyRow();
			VECT<STRING> new_moses = TB_MOSES->GetEmptyRow();

			moses     [ F_MOSES_Name        ] = G_pServerData->m_MosesName;
			new_moses [ F_MOSES_DateLicence ] = q->DateLicence;

			int r = TB_MOSES->Update(TbFile::M(F_MOSES_Name),  
					moses,
					TbFile::M(F_MOSES_DateLicence), 
					new_moses);	
			if (r != 1)
				m->Error = GetError("LIC001", nClient); // Update Date of Licence Failed
		}
		else
			m->Error = GetError("LIC001", nClient); // Update Date of Licence Failed
	}
	return m;
}

///////////////////////////////////////////////////////////////////////////////
GenericMsg * Licence_Get(c_Moses_Licence_Get *q, int nClient)
{
	a_Moses_Licence_Get *m = STNew a_Moses_Licence_Get;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> moses = TB_MOSES->GetEmptyRow();

		long r = TB_MOSES->Select(moses, 0L);
		
		if ( r == -1L )
			m->Error = GetError("LIC002", nClient); // Moses Table is Empty.
		else
		{
			m->DateLicence = moses[ F_MOSES_DateLicence ];
		}
	}

	return m;
}

///////////////////////////////////////////////////////////////////////////////
int Licence_OK()
{
	STRING currentTime = mGetCurrentTime();
	STRING dateOfScadence;

	// Determino la data di scadenza della licenza.
	VECT<STRING> moses = TB_MOSES->GetEmptyRow();

	moses [ F_MOSES_Name ] = G_pServerData->m_MosesName;

	long r = TB_MOSES->Select(moses, 0L);

	if (r == -1L) 
	{
		clog<<GetError("LIC003")<<endl; // Moses Table is Empty.
		return 0;
	}
	else
		 dateOfScadence = moses[ F_MOSES_DateLicence ];

	int res = strcmp(dateOfScadence.Str(), currentTime.Str());

	if (res >= 0)
		return 1;
	else
	{
		clog<<GetError("LIC004")<<endl; // Exipered Licence. 
		return 0;
	}

	return 1;
}

#endif
