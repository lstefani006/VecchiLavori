#include <srvAPI/server.h>
#include <srvAPI/tbFile.h>

#include "MsgLog.h"
#include <stdio.h>
#include "Notify.h"



static void StampaHeader(FILE *f)
{
	static int bFirst = 1;  // non e' mai stato eseguito un log

	if (!bFirst) return;

	bFirst = 0;


	fprintf(f, "\n");
	fprintf(f, "\n");
	fprintf(f, "%6s ",  "IdMsg");
	fprintf(f, "%-8s ", "Login");
	fprintf(f, "%-7s",  "Clnt");

	fprintf(f, "%-8s " ,  "Sender");
	fprintf(f, "%-8s " ,  "Receiver");
	fprintf(f, "%-32s ",  "Subject");
	fprintf(f, "%-11s ",  "SzBody");

	fprintf(f, "%-20s ", "Azione");
	fprintf(f, "%-14s ", "Time");
	fprintf(f, "%-200s", "Rmks");
	fprintf(f, "\n");
	fprintf(f, "\n");
}


void Msg_Log(
	INT32 IdMsg,
	int   nClient,
	const char *azione, // WriteInFolder.....
	const char *rmks)   // MB=.... folder=.....
{
	FILE *f = fopen("msg.log", "a+");

	if (f == NULL)
		f = fopen("msg.log", "w");


	StampaHeader(f);


	fprintf(f, "%6d ",  int(IdMsg));
	fprintf(f, "%-8s ", G_pServerData->m_ListConnected[nClient].m_User.Str());
	fprintf(f, "%-7d",  nClient);

	// Determino Sender, Reciver e Subject dalla tabella MM.dat 
	// mediante l'IdMsg.

	VECT<STRING> s = TB_MM->GetEmptyRow();
	s[ F_MM_Id ] = STRING::Set(IdMsg);
	long l = TB_MM->Select(TbFile::M(F_MM_Id), s, s, 0L);

	fprintf(f, "%-8s " ,  s[F_MM_Sender].Str());
	fprintf(f, "%-8s " ,  s[F_MM_Receiver].Str());
	fprintf(f, "%-32s ",  s[F_MM_Subject].Str());
	fprintf(f, "%-11s ",  s[F_MM_SzBody].Str());

	fprintf(f, "%-20s ", azione);
	fprintf(f, "%-14s ", mGetCurrentTime().Str());
	fprintf(f, "%-200s", rmks);
	fprintf(f, "\n");

	fclose(f);
}


void Msg_Log(
	int   nClient,
	const char *azione, // DeleteFolder.....
	const char *rmks)   // MB=.... folder=.....
{
	FILE *f = fopen("msg.log", "a+");

	if (f == NULL)
		f = fopen("msg.log", "w");


	StampaHeader(f);

	char *strnull = " ";

	fprintf(f, "%6s ",  strnull);
	fprintf(f, "%-8s ", G_pServerData->m_ListConnected[nClient].m_User.Str());
	fprintf(f, "%-7d",  nClient);

	// Non avendo l'MsgId non si puo'
	// Sender, Reciver e Subject dalla tabella MM.dat .

	fprintf(f, "%-8s " ,  strnull);
	fprintf(f, "%-8s " ,  strnull);
	fprintf(f, "%-32s ",  strnull);
	fprintf(f, "%-11s",   strnull);

	fprintf(f, "%-20s ", azione);
	fprintf(f, "%-14s ", mGetCurrentTime().Str());
	fprintf(f, "%-200s", rmks);
	fprintf(f, "\n");

	fclose(f);
}


////////////////////////////////////////////////////////////////////////////////

static STRING Do_Notify_DISCONNECT_CLIENT(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";
	Notify_DISCONNECT_CLIENT *p_DISCONNECT_CLIENT = (Notify_DISCONNECT_CLIENT *)p;
	int nClient = p_DISCONNECT_CLIENT->nClient;

	/*
	 * ricevo la notifica della sconnessione di un cliente
	 */

	STRING rmks = STRING("TcpAddr=") & G_pServerData->GetTcpAddr(nClient);

	Msg_Log(
			nClient,
			"Client disconnect",
			rmks.Str());

	return "";
}

static Notify Notify_DISCONNECT_CLIENT(Notify_DISCONNECT_CLIENT::Id, Do_Notify_DISCONNECT_CLIENT);

////////////////////////////////////////////////////////////////////////////////

static STRING Do_Notify_CONNECT_CLIENT(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";
	Notify_CONNECT_CLIENT *p_CONNECT_CLIENT = (Notify_CONNECT_CLIENT *)p;
	int nClient = p_CONNECT_CLIENT->nClient;

	/*
	 * ricevo la notifica della sconnessione di un cliente
	 */

	STRING rmks = STRING("TcpAddr=") & G_pServerData->GetTcpAddr(nClient);

	Msg_Log(
			nClient,
			"Client connect",
			rmks.Str());

	return "";
}

static Notify Notify_CONNECT_CLIENT(Notify_CONNECT_CLIENT::Id, Do_Notify_CONNECT_CLIENT);
