#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>	// x usare la funzione stat()

#include "tbFile.h"
#include "ERROR.h"


static void Fseek(FILE *f, long l, int t)
{
	if (f == NULL)
	{
		cerr << "Fseek: f == NULL\n";
		return;
	}

	int r = fseek(f, l, t);
	if (r != 0)
		cerr << "Errore nella fseek\n";
}

static void Fwrite(const void *p, size_t sz, size_t n, FILE *f)
{
	if (f == NULL)
	{
		cerr << "Fwrite: f == NULL\n";
		return;
	}
	
	int r = fflush(f);
	if (r != 0)
		cerr << "Errore nella fflush\n";
	r = fwrite(p, sz, n, f);
	if (r == 0)
		cerr << "Errore nella fwrite\n";
	r = fflush(f);
	if (r != 0)
		cerr << "Errore nella fflush\n";
}


static int Fread(void *p, size_t sz, size_t n, FILE *f)
{
	if (f == NULL)
	{
		cerr << "Fread: f == NULL\n";
		return 0;
	}

	int r = fread(p, sz, n, f);

	if (r == 0)
		if (ferror(f))
			cerr << "Fread: errore nella fread\n";
	
	return r;
}

static long Ftell(FILE *f)
{
	if (f == NULL)
	{
		cerr << "Ftell: f == NULL\n";
		return 0;
	}

	long l = ftell(f);

	if (l == -1)
		cerr << "Ftell: errore nella ftell\n";

	return l;
}

static FILE *Fopen(const char *p)
{
#ifdef _WIN32

	FILE *f = fopen(p, "rb");
	if (f == NULL)
	{
		f = fopen(p, "wb");
		if (f)
			fclose(f);
	}
	else
		fclose(f);

	f = fopen(p, "r+b");

	return f;

#else
	int r = open(p, O_CREAT | O_RDWR | O_NSHARE | O_DELAY);
	if (r == -1)
		return NULL;

	FILE *f = fdopen(r, "r+");
	return f;
#endif
}

static void Fclose(FILE *f)
{
	if (f == NULL)
	{
		cerr << "Fclose: f == NULL\n";
		return;
	}
	int r = fclose(f);
	if (r != 0)
		cerr << "Fclose: Cannot close file\n";
}

/////////////////////////////////////////////////////////////////////////////


TbFile::TbFile(const char *pPath, const char *pFileName, VECT<INT32> &dimFields, int pkField)
{
	m_f         = NULL;
	m_dimFields = dimFields;
	m_pkField   = pkField;
	strcpy(m_FileName, pPath);
	strcat(m_FileName, "/");
	strcat(m_FileName, pFileName);
	
	m_SzRecord  = 1; // il carattere V valido D cancellato
	for (int i = 0; i < dimFields.Size(); i++)
		m_SzRecord += dimFields[i];
	m_SzRecord += 1; // il return

	// controllo della lunghezza del file
	{
		struct stat s;

		int r = ::stat(m_FileName, &s);
		if ( r == 0 && s.st_size > 0 && (s.st_size % m_SzRecord) != 0)
		{
			cerr<<"Path File:  "<<m_FileName<<endl;
			cerr<<"lung. file errata -> resto:"<<s.st_size % m_SzRecord<<endl<<endl;

			FILE *f = Fopen(m_FileName);
			if (f)
			{
				char b[1024];
				memset(b, ' ', sizeof(b));
				b[ m_SzRecord - ((s.st_size % m_SzRecord)) - 1 ] = '\n';

				Fseek(f, 0L, SEEK_END);
				Fwrite(b, 1, m_SzRecord - ((s.st_size % m_SzRecord)), f);
				Fclose(f);
			}
		}
	}
}

TbFile::~TbFile()
{
	if (m_f) UnlockFile();
}

void TbFile::LockFile()
{
	if (m_f)
	{
		cerr << "LockFile called with an open file " << m_FileName << endl;
		exit(1);
	}

	m_f = Fopen(m_FileName);

	if (m_f == NULL)
	{
		cerr << "Cannot open file " << m_FileName << endl;
		perror(m_FileName);

		exit(1);
	}
}

void TbFile::UnlockFile()
{
	if (m_f)
		Fclose(m_f);
	m_f = NULL;
}

int TbFile::GetOffset(int f)
{
	if (f == 0)
		return 1;

	int r = 1;
	for (int i = 0; i < f; i++)
		r += m_dimFields[i];
	return r;
}

STRING TbFile::AddBlanks(int f, const STRING &r)
{
	int sz = m_dimFields[f];

	STRING out(' ', sz);
	memcpy(out.Str(), r.Str(), sz < r.Len() ? sz : r.Len());
	return out;
}

STRING TbFile::KillBlanks(STRING r)
{
	if (r.Len() == 0)
		return STRING();


	char *p = r.Str() + r.Len() - 1;

	while (p >= r.Str() && *p == ' ')
		*p-- = '\0';

	STRING out('\0', strlen(r.Str()));
	memcpy(out.Str(), r.Str(), strlen(r.Str()));
	return out;
}

long TbFile::SearchRecord(int f, const STRING &toSearch, long start, char *p)
{
	VECT<STRING> r;

	for (int i = 0; i < f; i++)
		r.Append("");
	r.Append(toSearch);

	return  SearchRecord(M(f), r, start, p);
}

long TbFile::SearchRecord(int fMask, VECT<STRING> &toSearch, long start, char *p)
{
	long l = Ftell(m_f);

	int bDelete = 0;
	if (p == NULL)
	{
		p = STNew char [m_SzRecord];
		bDelete = 1;
	}

	Fseek(m_f, start, SEEK_SET);

	int bFound = 0;

	while (Fread(p, m_SzRecord, 1, m_f))
	{
		if (p[0] != '*')
		{
			int bEqual = 1;
			for (int f = 0; f < m_dimFields.Size(); f++)
			{
				if (fMask & (1 << f))
				{
					STRING ss = AddBlanks(f, toSearch[f]);
					bEqual = memcmp(p + GetOffset(f), ss.Str(), m_dimFields[f]) == 0;
					if (bEqual == 0)
						break;
				}
			}

			if (bEqual)
			{
				start = Ftell(m_f) - m_SzRecord;
				bFound = 1;
				break;
			}
		}
	}

	Fseek(m_f, l, SEEK_SET);

	if (bDelete)
		STDelete p;

	if (bFound)
		return start;
	else
		return -1;
}

long TbFile::SearchRecord()
{
	char *p = STNew char [m_SzRecord];

	Fseek(m_f, 0L, SEEK_SET);

	int bFound = 0;

	while (Fread(p, m_SzRecord, 1, m_f))
		if (p[0] == '*')
		{
			bFound = 1;
			break;
		}

	STDelete [] p;

	if (bFound)
	{
		long l = Ftell(m_f) - m_SzRecord;
		Fseek(m_f, l, SEEK_SET);
		return l;
	}
	else
		return -1L;
}

long TbFile::SearchRecord(long start, char *p)
{
	VECT<STRING> o;
	return SearchRecord(0, o, start, p);
}

long TbFile::Select (int f, const STRING &toSearch, VECT<STRING> &outRow, long start)
{
	VECT<STRING> r;

	for (int i = 0; i < f; i++)
		r.Append("");
	r.Append(toSearch);

	return  Select(M(f), r, outRow, start);
}

long TbFile::Select (int fMask, VECT<STRING> &toSearch, VECT<STRING> &outRow, long start)
{
	LockFile();

	char *p = STNew char [m_SzRecord];
	long l = SearchRecord(fMask, toSearch, start, p);
	if (l != -1)
	{
		outRow.Reset();
		for (int i = 0; i < m_dimFields.Size(); i++)
		{
			STRING r(p + GetOffset(i), m_dimFields[i]);
			STRING s = KillBlanks(r);
			outRow.Append(s);
		}
	}

	STDelete p;

	UnlockFile();

	if (l == -1)
		return -1;
	else
		return l + m_SzRecord;
}


long TbFile::Select (VECT<STRING> &outRow, long start)
{
	VECT<STRING> o;
	return Select(0, o, outRow, start);
}

static int cmp(const VECT<STRING> &a, const VECT<STRING> &b, int fMask)
{
	for (int f = 0; f < 32; f++)
		if (fMask & (1 << f))
		{
			int r = memcmp(a[f].Str(), b[f].Str(), a[f].Len());
			if (r > 0)
				return 1;
			if (r < 0)
				return -1;
		}
	return 0;
}

long TbFile::Select (int fMask, VECT<STRING> &toSearch, VECT<STRING> &outRow, long start, int fMaskOrderBy)
{
	VECT< VECT<STRING> > toSort;

	// leggo tutte le righe che fanno match
	{
		long l = 0L;
		VECT<STRING> row;
		while ((l = Select(fMask, toSearch, row, l)) != -1L)
			toSort.Append(row);
	}

	// sorto la tabella
	{
		int i, j;
		int N = toSort.Size();

		for (i = N; i >= 1; i--)
			for (j = 2; j <= i; j++)
				if (cmp(toSort[j-1], toSort[j], fMaskOrderBy) > 0)
				{
					VECT<STRING> rr = toSort[j-1];
					toSort[j-1] = toSort[j];
					toSort[j] = rr;
				}
	}

	// ora faccio finta di leggere il file e gestisco tutto con start

	if (start >= toSort.Size())
		return -1L;
	else
	{
		outRow = toSort[start];
		return start + 1;
	}
}




int TbFile::Delete (int f, const STRING &toDelete)
{
	VECT<STRING> r;

	for (int i = 0; i < f; i++)
		r.Append("");
	r.Append(toDelete);

	return Delete(M(f), r);
}


int TbFile::Delete (int fMask, VECT<STRING> &toDelete)
{
	LockFile();

	long start = 0;
	int  found = 0;

	for (;;)
	{
		long l = SearchRecord(fMask, toDelete, start);
		if (l == -1)
			break;

		found++;

		Fseek(m_f, l, SEEK_SET);

		char c = '*';
		Fwrite(&c, 1, 1, m_f);

		start = l + m_SzRecord;
	}

	UnlockFile();

	return found;
}

int TbFile::OutRow(VECT<STRING> &r)
{
	char c = ' ';
	Fwrite(&c, 1, 1, m_f);

	for (int i = 0; i < r.Size(); i++)
		Fwrite(AddBlanks(i, r[i]).Str(), m_dimFields[i], 1, m_f);

	c = '\n';
	Fwrite(&c, 1, 1, m_f);

	return 1;
}

int TbFile::OutRow(VECT<STRING> &r, int fMask, char *p)
{
	VECT<STRING> v;
	for (int i = 0; i < r.Size(); i++)
		v.Append(STRING(p + GetOffset(i), m_dimFields[i]));

	for (i = 0; i < r.Size(); i++)
		if (fMask & (1 << i))
			v[i] = r[i];

	OutRow(v);

	return 1;
}

int TbFile::Update (int f, const STRING &toSearch, int fMaskOut, VECT<STRING> &inRow)
{
	VECT<STRING> r;

	for (int i = 0; i < f; i++)
		r.Append("");
	r.Append(toSearch);

	return Update(M(f), r, fMaskOut, inRow);
}

int TbFile::Update (int fMask, VECT<STRING> &toSearch, int fMaskOut, VECT<STRING> &inRow)
{
	LockFile();

	int  found = 0;

	/*
	 * ricerco il record da updatare solo se si sta cambiando la chiave del record
	 */

	if (fMaskOut & m_pkField)
	{
		// si sta cercando di cambiare la chiave (o parte di essa)
		int bDuplKey = SearchRecord(fMaskOut, inRow, 0L) != -1;
		if (bDuplKey)
			found = -1;
	}

	if (found == 0)
	{
		long start = 0;

		STRING p(' ', m_SzRecord);

		for (;;)
		{
			long l = SearchRecord(fMask, toSearch, start, p.Str());
			if (l == -1)
				break;

			found += 1;
			Fseek(m_f, l, SEEK_SET);

			OutRow(inRow, fMaskOut, p.Str());

			start = l + m_SzRecord;
		}
	}

	UnlockFile();

	return found;
}

int TbFile::Insert(VECT<STRING> &r)
{
	LockFile();

	int bOk = 0;

	if (SearchRecord(m_pkField, r, 0) == -1)
	{
		long l = SearchRecord();
		if (l == -1L)
			Fseek(m_f, 0L, SEEK_END);
		else
			Fseek(m_f, l, SEEK_SET);
		OutRow(r);
		bOk = 1;
	}

	UnlockFile();

	return bOk;
}

VECT<STRING> TbFile::GetEmptyRow() const
{
	VECT<STRING> r(m_dimFields.Size());

	for (int i = 0; i < m_dimFields.Size(); i++)
		r.Append("");

	return r;
}


//////////////////////////////////////////////////////////////////////////////////////

TbFile *TB_MOSES = NULL;
	int F_MOSES_Name;
	int F_MOSES_IdMsg;
	int F_MOSES_ClientPid;
	int F_MOSES_DateLicence;

TbFile *TB_DL    = NULL;
	int F_DL_DLName;
	int F_DL_DLPwd;
	int F_DL_DLDescr;

TbFile *TB_MS    = NULL;
	int F_MS_MailBoxType;
	int F_MS_MailBoxTypeDescr;

TbFile *TB_DLM   = NULL;
	int F_DLM_DLName;
	int F_DLM_User;

TbFile *TB_USER = NULL;
	int F_USER_Name;
	int F_USER_Pwd;
	int F_USER_Type;
	int F_USER_Descr;
	int F_USER_Rights;
	int F_USER_DefaultMBox;
	int F_USER_KeyId;

TbFile *TB_ITG = NULL;
	int F_ITG_MailboxName;
	int F_ITG_Folder;
	int F_ITG_Index;
	int F_ITG_DelFlag;
	int F_ITG_Message_Dest;
	int F_ITG_Message_Source;
	int F_ITG_Message_Type;
	int F_ITG_Message_MSP;

TbFile *TB_ART = NULL;
	int F_ART_User;
	int F_ART_MailBoxType;
	int F_ART_bInternal;
	int F_ART_MailBoxAddress;
	int F_ART_Subject;

TbFile *TB_MB = NULL;
	int F_MB_Name;
	int F_MB_Descr;
	int F_MB_Pwd;
	int F_MB_Owner;
	int F_MB_Directory;


TbFile *TB_MM = NULL;
	int F_MM_MailboxName;
	int F_MM_Type;
	int F_MM_Folder;
	int F_MM_Name;
	int F_MM_Id;
	int F_MM_Created;
	int F_MM_DelFlag;
	int F_MM_Sender;
	int F_MM_Receiver;
	int F_MM_Subject;
	int F_MM_InOut;
	int F_MM_SzBody;
	int F_MM_UserField;
	int F_MM_Accessed;
	int F_MM_Sent;
	int F_MM_Dispatched;
	int F_MM_Delivered;
	int F_MM_Read;

TbFile *TB_MSL    = NULL;
	int F_MSL_Name;
	int F_MSL_Descr;

TbFile *TB_Client  = NULL;
	int F_Client_Name;
	int F_Client_Descr;
	int F_Client_Type;
	int F_Client_Active;
	int F_Client_Pid;

TbFile *TB_OL      = NULL;
	int F_OL_DaysAccessed;
	int F_OL_DaysSent;
	int F_OL_DaysDispatched;

TbFile *TB_SC      = NULL;
	int F_SC_Index;
	int F_SC_Time;
	int F_SC_Action;

TbFile *TB_ERROR      = NULL;
	int F_ERROR_CodError;
	int F_ERROR_DesError;
	int F_ERROR_Language;

TbFile *TB_LANG    = NULL;
	int F_LANG_Cod;
	int F_LANG_Descr;

void TB_Init(const char *path)
{
	{
		VECT<INT32> dimFields;
		dimFields.Append(8);                        F_MOSES_Name         = 0;
		dimFields.Append(12);                       F_MOSES_IdMsg        = 1;
		dimFields.Append(12);                       F_MOSES_ClientPid    = 2;
		dimFields.Append(LEN_FIELD_DATE_LICENCE);   F_MOSES_DateLicence  = 3;
		TB_MOSES = STNew TbFile(path, "MOSES.dat", dimFields, TbFile::M(F_MOSES_Name));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_NAME_USER);   F_DL_DLName  = 0;
		dimFields.Append(LEN_NAME_PWD);    F_DL_DLPwd   = 1;
		dimFields.Append(30);              F_DL_DLDescr = 2;
		TB_DL = STNew TbFile(path, "DL.dat", dimFields, TbFile::M(F_DL_DLName));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_NAME_USER);   F_DLM_DLName = 0;
		dimFields.Append(LEN_NAME_USER);   F_DLM_User   = 1;
		TB_DLM = STNew TbFile(path, "DLM.dat", dimFields, TbFile::M(F_DLM_DLName, F_DLM_User));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_NAME_USER);   F_USER_Name        = 0;
		dimFields.Append(LEN_NAME_PWD );   F_USER_Pwd         = 1;
		dimFields.Append(3);               F_USER_Type        = 2;
		dimFields.Append(24);              F_USER_Descr       = 3;
		dimFields.Append(8);               F_USER_Rights      = 4;
		dimFields.Append(LEN_NAME_MB);     F_USER_DefaultMBox = 5;
		dimFields.Append(16);              F_USER_KeyId       = 6;
		TB_USER = STNew TbFile(path, "USER.dat", dimFields, TbFile::M(F_USER_Name));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_NAME_MB);     F_ITG_MailboxName    = 0;
		dimFields.Append(256);             F_ITG_Folder         = 1;
		dimFields.Append(1);               F_ITG_DelFlag        = 2;
		dimFields.Append(4);               F_ITG_Index          = 3;
		dimFields.Append(LEN_NAME_USER);   F_ITG_Message_Dest   = 4;
		dimFields.Append(LEN_NAME_USER);   F_ITG_Message_Source = 5;
		dimFields.Append(50);              F_ITG_Message_Type   = 6;
		dimFields.Append(256);             F_ITG_Message_MSP    = 7;
		TB_ITG = STNew TbFile(path, "ITG.dat", dimFields, TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_Index));
	}	
	
	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_NAME_USER);     F_ART_User           = 0;
		dimFields.Append(LEN_NAME_MBTYPE);   F_ART_MailBoxType    = 1;
		dimFields.Append(1);                 F_ART_bInternal      = 2;
		dimFields.Append(256);               F_ART_MailBoxAddress = 3;
		dimFields.Append(128);               F_ART_Subject        = 4;
		TB_ART = STNew TbFile(path, "ART.dat", dimFields, TbFile::M(F_ART_User, F_ART_MailBoxType, F_ART_bInternal));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_NAME_MB);    F_MB_Name      = 0;    // nome mb e nome della directory nel file system
		dimFields.Append(30);             F_MB_Descr     = 1;    // descrizione
		dimFields.Append(LEN_NAME_PWD);   F_MB_Pwd       = 2;    // password di accesso
		dimFields.Append(LEN_NAME_USER);  F_MB_Owner     = 3;    // utente di riferimento per la mailbox
		dimFields.Append(30);             F_MB_Directory = 4;    // non usato 
		TB_MB = STNew TbFile(path, "MB.dat", dimFields, TbFile::M(F_MB_Name));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_NAME_MB);      F_MM_MailboxName = 0; 
		dimFields.Append(1);                F_MM_Type       = 1;  // tipo F folder M msg
		dimFields.Append(256);              F_MM_Folder     = 2;  // path del folder (relativo alla mailbox)
		dimFields.Append(LEN_NAME_FOLDER);  F_MM_Name       = 3;  // nome del folder o del messaggio
		dimFields.Append(12);               F_MM_Id         = 4;  // identficatore univoco msg/folder
		dimFields.Append(14);               F_MM_Created    = 5;  // data YYYYMMDDhhmmss di creazione
		dimFields.Append(1);                F_MM_DelFlag    = 6;  // ' ' valido 'D' cancellato
		dimFields.Append(LEN_NAME_USER);    F_MM_Sender     = 7;
		dimFields.Append(LEN_NAME_USER);    F_MM_Receiver   = 8;
		dimFields.Append(32);               F_MM_Subject    = 9;
		dimFields.Append(1);                F_MM_InOut      = 10; // campo che dice se il messaggio e` in oppure out (I/O)
		dimFields.Append(10);               F_MM_SzBody     = 11; // dimensione del messaggio
		dimFields.Append(32);               F_MM_UserField  = 12; // campo libero per l'applicativo utente
		dimFields.Append(14);               F_MM_Accessed   = 13; // data di ultimo accesso
		dimFields.Append(14);               F_MM_Sent       = 14; // data della spedizione all'MTD
		dimFields.Append(14);               F_MM_Dispatched = 15; // data di inoltro nel sistema di posta elettronica
		dimFields.Append(14);               F_MM_Delivered  = 16; // data di consegna alla macchina remota
		dimFields.Append(14);               F_MM_Read       = 17; // data di lettura del messaggio alla macchina remota

		TB_MM = STNew TbFile(path, "MM.dat", dimFields, TbFile::M(F_MM_Id));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_FIELD_ACTION);  F_MSL_Name  	= 0;
		dimFields.Append(256); 	             F_MSL_Descr  	= 1;
		TB_MSL = STNew TbFile(path, "MSL.dat", dimFields, TbFile::M(F_MSL_Name));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_FIELD_ACTION);	F_Client_Name  	= 0;
		dimFields.Append(64);	            F_Client_Descr 	= 1;
		dimFields.Append(3); 	            F_Client_Type 	= 2;
		dimFields.Append(1); 	            F_Client_Active	= 3;
		dimFields.Append(8); 	            F_Client_Pid	= 4;
		TB_Client = STNew TbFile(path, "Client.dat", dimFields, TbFile::M(F_Client_Name));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(LEN_NAME_MBTYPE);  	F_MS_MailBoxType  		= 0;
		dimFields.Append(32); 	                F_MS_MailBoxTypeDescr  	= 1;
		TB_MS = STNew TbFile(path, "MS.dat", dimFields, TbFile::M(F_MS_MailBoxType));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(5);  	                F_SC_Index  	= 0;
		dimFields.Append(LEN_FIELD_SC_WHEN); 	F_SC_Time  	    = 1;	// YYYYMMWDDHHMM
		dimFields.Append(LEN_FIELD_ACTION); 	F_SC_Action  	= 2;
		TB_SC = STNew TbFile(path, "SC.dat", dimFields, TbFile::M(F_SC_Index));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(3);  	F_OL_DaysAccessed  	= 0;
		dimFields.Append(3); 	F_OL_DaysSent  	    = 1;
		dimFields.Append(3); 	F_OL_DaysDispatched = 2;
		TB_OL = STNew TbFile(path, "OL.dat", dimFields, TbFile::M(F_OL_DaysAccessed, F_OL_DaysSent, F_OL_DaysDispatched));
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(3); 	F_ERROR_Language  	= 0;
		dimFields.Append(8);  	F_ERROR_CodError  	= 1;
		dimFields.Append(100); 	F_ERROR_DesError  	= 2;
		TB_ERROR = STNew TbFile(path, "ERROR.dat", dimFields, TbFile::M(F_ERROR_CodError, F_ERROR_Language));

		//Inizializzazione della tabella degli errori con i valori predefiniti.
		InitTableERROR();
	}

	{
		VECT<INT32> dimFields;
		dimFields.Append(3);  	F_LANG_Cod      = 0;
		dimFields.Append(20); 	F_LANG_Descr  	= 1;
		TB_LANG = STNew TbFile(path, "LANG.dat", dimFields, TbFile::M(F_LANG_Cod));

		//Inizializzazione della tabella delle lingue con i valori predefiniti.
		InitTableLANG();
	}

}

#endif
