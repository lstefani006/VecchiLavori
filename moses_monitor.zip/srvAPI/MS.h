#include <st_dbnew.h>
#ifndef __MS_h__
#define __MS_h__

#include <moses.h>


GenericMsg * MS_Add    (class c_Moses_MS_Add    *q, int nClient);
GenericMsg * MS_Delete (class c_Moses_MS_Delete *q, int nClient);
GenericMsg * MS_List   (class c_Moses_MS_List   *q, int nClient);

int MS_Exists (const STRING& MSType);

#endif
