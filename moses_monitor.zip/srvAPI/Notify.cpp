#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include "Notify.h"

#include <iostream.h>


/////////////////////////////////////////////////////////////////////////

char Notify_MB_PHI_DEL::Id[1];
char Notify_MB_PHI_PURGE::Id[1];
char Notify_USER_ADD::Id[1];
char Notify_USER_PHI_DEL::Id[1];
char Notify_DL_ADD::Id[1];
char Notify_DL_PHI_DEL::Id[1];
char Notify_MB_MSG_WRITE::Id[1];
char Notify_MB_FOLDER_PHI_DEL::Id[1];
char Notify_MB_FOLDER_LOG_DEL::Id[1];
char Notify_MB_FOLDER_PHI_PURGE::Id[1];
char Notify_MB_FOLDER_LOG_UNDEL::Id[1];
char Notify_MB_MSG_FOR_MTD::Id[1];
char Notify_DISCONNECT_CLIENT::Id[1];
char Notify_CONNECT_CLIENT::Id[1];


/////////////////////////////////////////////////////////////////////////

Notify::Table Notify::tb[50] = { NULL, NULL, };
int   Notify::top = 0;


Notify::Notify(NotifyData::ID Type, fNotify f)
{
	if (top >= sizeof(tb) / sizeof(tb[0]))
	{
		cerr << "Notify tabella troppo piccola\n";
		abort();
	}
	tb[top].m_f = f;
	tb[top].m_Type = Type;
	top++;
}

VECT<STRING> Notify::DoNotify(NotifyData *p)
{
	VECT<STRING> r;

	for (int i = 0; i < top; i++)
		if (tb[i].m_Type == p->GetType())
		{
			STRING rmks;
			STRING e = tb[i].m_f(p, rmks);

			if ((rmks & e).Len() > 0)
				r.Append(rmks & e);
		}

	STDelete p;

	return r;
}

#endif
