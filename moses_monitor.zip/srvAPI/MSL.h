#include <st_dbnew.h>
#ifndef __MSL_h__
#define __MSL_h__

#include <moses.h>


GenericMsg * MSL_Add    (class c_Moses_MSL_Add    *q, int nClient);
GenericMsg * MSL_Delete (class c_Moses_MSL_Delete *q, int nClient);
GenericMsg * MSL_List   (class c_Moses_MSL_List   *q, int nClient);
GenericMsg * MSL_Modify (class c_Moses_MSL_Modify *q, int nClient);


#endif
