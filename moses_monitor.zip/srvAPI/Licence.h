#include <st_dbnew.h>
#ifndef __Licence_h__
#define __Licence_h__

#include <moses.h>

GenericMsg * Licence_Set   (class c_Moses_Licence_Set *q, int nClient);
GenericMsg * Licence_Get   (class c_Moses_Licence_Get *q, int nClient);

// Metodo che controlla che la licenza sia valida.
int Licence_OK();

#endif
