#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "DL.h"
#include "User.h"
#include "Notify.h"

#include <m_Moses_DL_Add.h>
#include <m_Moses_DL_Delete.h>
#include <m_Moses_DL_List.h>
#include <m_Moses_DL_Modify.h>

#include <m_Moses_DL_Member_Add.h>
#include <m_Moses_DL_Member_Delete.h>
#include <m_Moses_DL_Member_List.h>


static int Check_R_Or_Pwd(const STRING &DLName, const STRING &DLPwd, STRING &Error,
		int nClient)
{
	if (G_pServerData->Check_R(nClient, Error))
		return 1;

	VECT<STRING> d = TB_DL->GetEmptyRow();
	d[ F_DL_DLName ] = DLName;
	d[ F_DL_DLPwd  ] = DLPwd;

	VECT<STRING> o;
	long l = TB_DL->Select(TbFile::M(F_DL_DLName, F_DL_DLPwd), d, o, 0L);

	if (l == -1L)
	{
		Error = GetError("DL001", nClient); // Invalid user/password while adding user to distribution list.
		return 0;
	}
	return 1;
}


GenericMsg * DL_Add(c_Moses_DL_Add *q, int nClient)
{
	a_Moses_DL_Add *m = STNew a_Moses_DL_Add;

	// Controllo la validita' dell'User e della Password.
	if ( ! q->DLName.IsIdentifier(LEN_NAME_USER) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User Name.
		return m;
	}
	
	if ( ! q->DLPwd.IsIdentifier(LEN_NAME_PWD) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}
	
	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> d = TB_DL->GetEmptyRow();
		d[ F_DL_DLName ] = q->DLName;
		d[ F_DL_DLPwd  ] = q->DLPwd;
		d[ F_DL_DLDescr] = q->DLDescr;
		int r = TB_DL->Insert(d);
		if (r == 0)
			m->Error = GetError("DL002", nClient); // Distribution list already present.

		if (r == 1)
			Notify::DoNotify(STNew Notify_DL_ADD(nClient, q->DLName, q->DLPwd, q->DLDescr));
	}
	return m;
}

GenericMsg * DL_Delete(c_Moses_DL_Delete *q, int nClient)
{
	a_Moses_DL_Delete *m = STNew a_Moses_DL_Delete;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' dell'User e della Password.
		if ( ! q->DLName.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}
	
		int r = TB_DL->Delete(F_DL_DLName, q->DLName);
		if (r == 0)
		{
			m->Error = GetError("DL003", nClient); // Unknown distribution list.
			return m;
		}

		if (r == 1)
			Notify::DoNotify(STNew Notify_DL_PHI_DEL(nClient, q->DLName));

		// e' possibile che esistano liste di distribuzioni vuote
		TB_DLM->Delete(F_DLM_DLName, q->DLName);
	}
	return m;
}

GenericMsg * DL_List(c_Moses_DL_List *q, int nClient)
{
	a_Moses_DL_List *m = STNew a_Moses_DL_List;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> out_Name_Pwd_Descr;

		long l = 0;
		while ((l = TB_DL->Select(out_Name_Pwd_Descr, l)) != -1)
		{
			m->DLNameList.Append  (out_Name_Pwd_Descr[F_DL_DLName]);
			m->DLPwdList.Append   (out_Name_Pwd_Descr[F_DL_DLPwd]);
			m->DLDescrList.Append (out_Name_Pwd_Descr[F_DL_DLDescr]);
		}

		// non c'e` mai errore
	}

	return m;
}

GenericMsg * DL_Modify(c_Moses_DL_Modify *q, int nClient)
{
	a_Moses_DL_Modify *m = STNew a_Moses_DL_Modify;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' dell'User e della Password.
		if ( ! q->DLName.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}
	
		if ( ! q->DLPwd.IsIdentifier(LEN_NAME_PWD) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}
	
		VECT<STRING> i = TB_DL->GetEmptyRow();
		i[ F_DL_DLPwd   ] = q->DLPwd;
		i[ F_DL_DLDescr ] = q->DLDescr;

		int r = TB_DL->Update(F_DL_DLName, q->DLName, 
				TbFile::M(F_DL_DLPwd, F_DL_DLDescr), i);

		if (r == 0 || r == -1)
			m->Error = GetError("DL004", nClient); // Distribuition list not found.
	}
	return m;
}

GenericMsg * DL_Member_Add(c_Moses_DL_Member_Add *q, int nClient)
{
	a_Moses_DL_Member_Add *m = STNew a_Moses_DL_Member_Add;

	if (Check_R_Or_Pwd(q->DLName, q->Pwd, m->Error, nClient))
	{
		if (!User_Exists(q->User))
			m->Error = GetError("DL005", nClient); // The user not present in the Users list.
		else
		{
			// Controllo la validita' dell'User, della Password e della DLName.
			if ( ! q->User.IsIdentifier(LEN_NAME_USER) )
			{
				m->Error = GetError("G003", nClient);    // Invalid User Name.
				return m;
			}
		
			if ( ! q->Pwd.IsIdentifier(LEN_NAME_USER) )
			{
				m->Error = GetError("G004", nClient);    // Invalid Password.
				return m;
			}
		
			if ( ! q->DLName.IsIdentifier(LEN_NAME_USER) )
			{
				m->Error = GetError("G003", nClient);    // Invalid User Name.
				return m;
			}
		
			VECT<STRING> d = TB_DLM->GetEmptyRow();
			d[ F_DLM_DLName ] = q->DLName;
			d[ F_DLM_User   ] = q->User;

			int r = TB_DLM->Insert(d);

			if (r == 0)
				m->Error = GetError("DL006", nClient); // The user already present in the distribution list.
		}
	}

	return m;
}

GenericMsg * DL_Member_Delete(c_Moses_DL_Member_Delete *q, int nClient)
{
	a_Moses_DL_Member_Delete *m = STNew a_Moses_DL_Member_Delete;

	if (Check_R_Or_Pwd(q->DLName, q->Pwd, m->Error, nClient))
	{
		// Controllo la validita' dell'User, della Password e della DLName.
		if ( ! q->User.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}

		if ( ! q->Pwd.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G004", nClient);    // Invalid Password.
			return m;
		}

		if ( ! q->DLName.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}

		VECT<STRING> d = TB_DLM->GetEmptyRow();
		d[ F_DLM_DLName ] = q->DLName;
		d[ F_DLM_User   ] = q->User;
		int r = TB_DLM->Delete(TbFile::M(F_DLM_DLName, F_DLM_User), d);

		if (r == 0)
			m->Error = GetError("DL007", nClient); // The user is not present in the distribution list.
	}

	return m;
}

void DL_Member_List(
		int nClient, 
		const STRING &DLName, 
		const STRING &Pwd, 
		VECT<STRING> &UserList, 
		STRING &Error)
{
	if (Check_R_Or_Pwd(DLName, Pwd, Error, nClient))
	{
		long l = 0L;
		VECT<STRING> o;

		while ((l = TB_DLM->Select(F_DLM_DLName, DLName, o, l)) != -1L)
			UserList.Append(o[ F_DLM_User ]);
	}
}

GenericMsg * DL_Member_List(c_Moses_DL_Member_List *q, int nClient)
{
	a_Moses_DL_Member_List *m = STNew a_Moses_DL_Member_List;

	/*
	if (Check_R_Or_Pwd(q->DLName, q->Pwd, m->Error, nClient))
	{
		long l = 0L;
		VECT<STRING> o;

		while ((l = TB_DLM->Select(F_DLM_DLName, q->DLName, o, l)) != -1L)
		{
			m->UserList.Append(o[ F_DLM_User ]);
		}
	}
	*/

	DL_Member_List(nClient, q->DLName, q->Pwd, m->UserList, m->Error);

	return m;
}



/*
 * cancello l'utente da tutte le liste di distribuzione
 */
STRING DL_Member_Delete(int nClient, const STRING &User)
{
	STRING Error;

	if (G_pServerData->Check_R(nClient, Error))
	{
		VECT<STRING> d = TB_DLM->GetEmptyRow();
		d[ F_DLM_User   ] = User;
		int r = TB_DLM->Delete(TbFile::M(F_DLM_User), d);
		if (r == 0)
			Error = GetError("DL009", nClient); // The user is not present in the distribution list member.

	}

	return Error;
}


////////////////////////////////////////////////////////////////////////

/*
 * cancello ogni entry nella distribution list concernente
 * l'utente cancellato
 */
static STRING Do_Notify_USER_PHI_DEL(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";
	Notify_USER_PHI_DEL *p_USER_PHI_DEL = (Notify_USER_PHI_DEL *)p;
	return DL_Member_Delete(p_USER_PHI_DEL->nClient, p_USER_PHI_DEL->User);
}

static Notify Notify_UserDel(Notify_USER_PHI_DEL::Id, Do_Notify_USER_PHI_DEL);

#endif
