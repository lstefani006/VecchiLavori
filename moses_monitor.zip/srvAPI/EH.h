#include <st_dbnew.h>
#ifndef __EH_h__
#define __EH_h__

#include <moses.h>

GenericMsg * EH_Add    (class c_Moses_EH_Add    *q, int nClient);
GenericMsg * EH_Count  (class c_Moses_EH_Count  *q, int nClient);
GenericMsg * EH_Delete (class c_Moses_EH_Delete *q, int nClient);
GenericMsg * EH_List   (class c_Moses_EH_List   *q, int nClient);

/*
 * Cancellazione fisica di tutte le entry relative alla mailbox
 */
STRING EH_RemoveMailbox(int nClient, const STRING &MailBoxName);

/*
 * Cancellazione fisica di tutte le entry cancellate logicamente
 * nel mailbox e folder specificati
 */
STRING EH_Purge(int nClient, const STRING &MailBoxName, const STRING &Folder);

/*
 * Recovery dei campi cancellati logicamente
 */
STRING EH_Undelete(int nClient, const STRING &MailBoxName, const STRING &Folder);

STRING EH_Match_Msg (const STRING &MailBoxName,
		             const STRING &Folder,
					 const STRING &Source,
					 const STRING &Subject,
					 const STRING &Destination);

#endif
