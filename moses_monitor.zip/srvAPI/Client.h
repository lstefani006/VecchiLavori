#include <st_dbnew.h>
#ifndef __Client_h__
#define __Client_h__

#include <moses.h>


GenericMsg * Client_Add		(class c_Moses_Client_Add    *q, int nClient);
GenericMsg * Client_Delete	(class c_Moses_Client_Delete *q, int nClient);
GenericMsg * Client_List	(class c_Moses_Client_List   *q, int nClient);
GenericMsg * Client_Modify	(class c_Moses_Client_Modify *q, int nClient);
GenericMsg * Client_Kill 	(class c_Moses_Client_Kill *q, int nClient);
GenericMsg * Client_Run 	(class c_Moses_Client_Run *q, int nClient);
GenericMsg * Client_RunningList	(class c_Moses_Client_RunningList *q, int nClient);


#endif
