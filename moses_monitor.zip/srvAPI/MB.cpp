#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <string.h>

#ifdef _WIN32
    #include <strstrea.h>
#else
    #include <strstream.h>
#endif


#include <tbFile.h>
#include <server.h>
#include <mdir.h>
#include <mtime.h>
#include <ERROR.h>
#include <MsgLog.h>

#include "m_Moses_Log_NewMsgId.h"
#include "m_Moses_MB_CheckMailbox.h"
#include "m_Moses_MB_ChangePassword.h"
#include "m_Moses_MB_ChangeOwner.h"
#include "m_Moses_MB_ChangeDescr.h"
#include "m_Moses_MB_CreateMailbox.h"
#include "m_Moses_MB_ListMailbox.h"
#include "m_Moses_MB_DeleteMailbox.h"

#include "m_Moses_MB_CreateFolder.h"
#include "m_Moses_MB_DeleteFolder.h"
#include "m_Moses_MB_UndeleteFolder.h"
#include "m_Moses_MB_ListFolder.h"
#include "m_Moses_MB_GetNewId.h"
#include "m_Moses_MB_WriteInFolder.h"
#include "m_Moses_MB_ListMsg.h"
#include "m_Moses_MB_GetInfo.h"
#include "m_Moses_MB_SetInfo.h"
#include "m_Moses_MB_SetInfoEx.h"
#include "m_Moses_MB_MsgRead.h"
#include "m_Moses_MB_MsgFile.h"
#include "m_Moses_MB_Msg_Delete.h"
#include "m_Moses_MB_MoveMsg.h"
#include "m_Moses_MB_MoveMsg2.h"
#include "m_Moses_MB_Set_Userfield.h"
#include "m_Moses_MB_Get_Userfield.h"
#include "m_Moses_MB_ListAllMsg.h"
#include "m_Moses_MB_UndeleteMsg.h"
#include "m_Moses_MB_Purge.h"

#include "MB.h"
#include "Notify.h"
#include "User.h"
#include "ART.h"


static STRING GetMsgPath(const STRING &mbox, const STRING &folder, INT32 idMsg)
{
	return G_pServerData->m_MB_RootPath & "/" & mbox & "/" & folder & "/" & STRING::Set(idMsg) & ".msg";
}

static STRING GetFolderPath(const STRING &mbox, const STRING &folder)
{
	return G_pServerData->m_MB_RootPath & "/" & mbox & "/" & folder;
}

static STRING GetMailboxPath(const STRING &mbox)
{
	return G_pServerData->m_MB_RootPath & "/" & mbox;
}

static int Is_InOutError_Folder(const STRING &folder)
{
	STRING f = GetFileName(folder);
	if (f == "in" || f == "out" || f == "error")
		return 1;
	else
		return 0;
}

static int Is_Out_System_Folder(const STRING &MailBoxName, const STRING &folder)
{
	STRING f = GetFileName(folder);
	STRING m = GetFileName(MailBoxName);
	if (f == "out" && m == "system")
		return 1;
	else
		return 0;
}

static STRING MB_GetNewIdMsg(int Step = NewId_Step);
static STRING Msg_InFolder(
		int           nClient,
		INT32         MsgId,
		const STRING &MailBoxName,
		const STRING &DestFolder);

/*
 * Controllo la password della mail box
 */
static int Check_MB_Pwd(const STRING &MailboxName, const STRING &MailboxPwd,
		STRING &Error, int nClient)
{
	VECT<STRING> d = TB_MB->GetEmptyRow();
	d[ F_MB_Name ] = MailboxName;
	d[ F_MB_Pwd  ] = MailboxPwd;

	cerr << "Controllo " << MailboxName.Str() << " " << MailboxPwd.Str() << endl;

	long l = TB_MB->Select(TbFile::M(F_MB_Name, F_MB_Pwd), d, d, 0L);

	if (l == -1L)
	{
		Error = GetError("MB001", nClient); // Wrong mailbox / password.
		return 0;
	}
	return 1;
}

/*
 * Controllo l'esistenza della mail-box
 */
static int Check_MB_Name(const STRING &MailboxName)
{
	VECT<STRING> d = TB_MB->GetEmptyRow();
	d[ F_MB_Name ] = MailboxName;

	long l = TB_MB->Select(TbFile::M(F_MB_Name), d, d, 0L);

	return l == -1L ? 0 : 1;
}

/*
 * Controllo se il messaggio e' nella mailbox specificata
 */
static int Check_MsgId_In_MB(INT32 MsgId, const STRING &Mb)
{
	VECT<STRING> mm = TB_MM->GetEmptyRow();
	mm[ F_MM_MailboxName ]  = Mb;
	mm[ F_MM_Type    ]      = "M";
	mm[ F_MM_Id      ]      = STRING::Set(MsgId);
	mm[ F_MM_DelFlag ]      = "";

	int fMask = TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Id, F_MM_DelFlag);

	long l = TB_MM->Select(fMask, mm, mm, 0L);
	if (l == -1)
		return 0;

	return 1;
}

/*
 * API per il controllo della mail box con password
 * Anche il cliente di Cfg deve esplitare la password
 */
GenericMsg * MB_CheckMailbox(c_Moses_MB_CheckMailbox *q, int nClient)
{
	a_Moses_MB_CheckMailbox * m = STNew a_Moses_MB_CheckMailbox;

	// Eseguo il controllo di validita' sul Name e Password della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient);
	return m;
}

/*
 * API per il cambio della password di una mail box
 * Cfg non e` obbligato a specificare la vecchia password
 */
GenericMsg * MB_ChangePassword(c_Moses_MB_ChangePassword *q, int nClient)
{
	a_Moses_MB_ChangePassword * m = STNew a_Moses_MB_ChangePassword;

	// Eseguo il controllo di validita' sul Name e Password Nuova e Vecchia della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if ( ! q->PwdCurrent.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	if ( ! q->PwdNew.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	int bCfg = G_pServerData->IsCfgClient(nClient);

	VECT<STRING> d = TB_MB->GetEmptyRow();
	d[ F_MB_Name ] = q->MailBoxName;
	d[ F_MB_Pwd  ] = q->PwdCurrent;

	VECT<STRING> n = TB_MB->GetEmptyRow();
	n[ F_MB_Pwd  ] = q->PwdNew;

	int r = TB_MB->Update(
			TbFile::M(F_MB_Name) | (!bCfg ? TbFile::M(F_MB_Pwd) : 0), d,
			TbFile::M(F_MB_Pwd), n);

	if (r == 0 || r == -1)
		m->Error = GetError("MB002", nClient); // Wrong mail box / password.

	return m;
}


/*
 * API (R)
 * API per il cambio dell'owner di una mail box
 * Solo Cfg (R) puo` cambiare l'owner di una mail box
 */
GenericMsg * MB_ChangeOwner(c_Moses_MB_ChangeOwner *q, int nClient)
{
	a_Moses_MB_ChangeOwner * m = STNew a_Moses_MB_ChangeOwner;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		if (! User_Exists( q->Owner ))
			m->Error = GetError("MB045", nClient); // Unknown user

		VECT<STRING> d = TB_MB->GetEmptyRow();
		d[ F_MB_Name  ] = q->MailBoxName;
		d[ F_MB_Owner ] = q->Owner;

		VECT<STRING> o;
		int r = TB_MB->Update(
				TbFile::M(F_MB_Name),  d,
				TbFile::M(F_MB_Owner), d);

		if (r == 0 || r == -1)
			m->Error = GetError("MB003", nClient); // Wrong mail box / password.
	}
	return m;
}

STRING MB_CreateFolder(
		const STRING &MailBoxName,
		const STRING &Pwd,
		const STRING &Folder,
		int nClient);

STRING MB_DeleteFolder(
		const STRING &MailBoxName,
		const STRING &Pwd,
		const STRING &Folder,
		int nClient);

STRING MB_PurgeFolder(
		int nClient,
		const STRING &MailBoxName,
		const STRING &Pwd,
		const STRING &Folder);

/*
 * API (R)
 * API per la creazione di una mail-box. Viene creata la directory della
 * mail-box e i folder In/Out/Error
 */
STRING MB_CreateMailbox(
		int nClient,
		STRING MailBoxName,
		STRING Owner,
		STRING Pwd,
		STRING Descr)
{
	STRING Error;

	if (G_pServerData->Check_R(nClient, Error))
	{
		if (Owner != "" && ! User_Exists(Owner))
			return GetError("MB045", nClient); // Unknown user

		VECT<STRING> mb = TB_MB->GetEmptyRow();
		mb[ F_MB_Name ]   = MailBoxName;
		mb[ F_MB_Owner ]  = Owner;
		mb[ F_MB_Pwd ]    = Pwd;
		mb[ F_MB_Descr ]  = Descr;

		int r = TB_MB->Insert(mb);
		if (r == 0)
		{
			Error = GetError("MB004", nClient); // Mailbox already present.
			return Error;
		}

		r = MkDir(GetMailboxPath(MailBoxName));
		if (r == 0)
		{
			RmDir(GetMailboxPath(MailBoxName), 1 /* ricorsiva */);
			Error = GetError("MB005", nClient); // Cannot create mail box directory.
			return Error;
		}

		Error = MB_CreateFolder(MailBoxName, Pwd, "in",    nClient);
		if (Error.Len() != 0) { r = 0; }

		if (r == 1) Error = MB_CreateFolder(MailBoxName, Pwd, "out",   nClient);
		if (Error.Len() != 0) { r = 0; }

		if (r == 1) Error = MB_CreateFolder(MailBoxName, Pwd, "error", nClient);
		if (Error.Len() != 0) { r = 0; }

		if (r == 0)
		{
			VECT<STRING> mb = TB_MB->GetEmptyRow();
			mb[ F_MB_Name ] = MailBoxName;
			TB_MB->Delete(TbFile::M(F_MB_Name), mb);

			MB_DeleteFolder(MailBoxName, Pwd, "in",    nClient);
			MB_DeleteFolder(MailBoxName, Pwd, "out",   nClient);
			MB_DeleteFolder(MailBoxName, Pwd, "error", nClient);

			RmDir(GetMailboxPath(MailBoxName), 1 /* ricorsiva */);
			Error = GetError("MB006", nClient); // Cannot create mail box directory.	
			return Error;
		}
	}
	return Error;
}

GenericMsg * MB_CreateMailbox(c_Moses_MB_CreateMailbox *q, int nClient)
{
	a_Moses_MB_CreateMailbox * m = STNew a_Moses_MB_CreateMailbox;

	// Eseguo il controllo di validita' sul Name, sulla Password e sull'Owner della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password Name.
		return m;
	}

	if ( ! q->Owner.IsIdentifier(LEN_NAME_USER) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User Name.
		return m;
	}

	m->Error = MB_CreateMailbox(
			nClient,
			q->MailBoxName,
			q->Owner,
			q->Pwd,
			q->Descr);

	return m;
}

/*
 * API
 * Lista di tutte le mail-box
 */
GenericMsg * MB_ListMailbox(c_Moses_MB_ListMailbox *q, int nClient)
{
	a_Moses_MB_ListMailbox *m = STNew a_Moses_MB_ListMailbox;

	// Nessun controllo sulla validita' dei Nomi relativi alla mailbox.

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		//
		// l'utente di configurazione puo' vedere tutte le mail box
		// del sistema
		//
		VECT<STRING> o;

		long l = 0L;
		int nFound = 0;
		while ((l = TB_MB->Select(o, l)) != -1)
		{
			if (nFound == q->Index)
			{
				m->Valid = 1;
				m->MailboxName = o[ F_MB_Name  ];
				m->Owner       = o[ F_MB_Owner ];
				m->Pwd         = o[ F_MB_Pwd   ];
				m->Descr       = o[ F_MB_Descr ];

				return m;
			}
			nFound++;
		}

		m->Valid = 0;
	}
	else
	if (G_pServerData->GetClientType(nClient) != "")   // cliente che ha fatto la work
	{
		//
		// l'utente normale puo' chiedere solo quali sono le
		// proprie mailbox e vedere la mailbox "system"
		//
		
		m->Error = "";  // perche' Check_R "sporca" m->Error

		VECT<STRING> s = TB_MB->GetEmptyRow();

		long l = 0L;
		int nFound = 0;
		while ((l = TB_MB->Select(s, l)) != -1L)
		{
			if (s[ F_MB_Owner ] == G_pServerData->GetClientUserName(nClient)
					|| s[ F_MB_Name ] == "system")
			{
				if (nFound == q->Index)
				{
					m->Valid       = 1;
					m->MailboxName = s[ F_MB_Name  ];
					m->Owner       = ""; // no pwd o owner per gli utenti semplici
					m->Pwd         = "";
					m->Descr       = s[ F_MB_Descr ];

					return m;
				}
				nFound++;
			}
		}

		m->Valid = 0;
	}
	return m;
}

/*
 * API (R)
 * Cancellazione fisica di una mailbox TBD
 */
GenericMsg * MB_DeleteMailbox(const STRING &MailBoxName, int nClient)
{
	a_Moses_MB_DeleteMailbox * m = STNew a_Moses_MB_DeleteMailbox;

	// Eseguo il controllo di validita' sul Name della Mailbox.
	STRING tmpMailBoxName = MailBoxName;
	if ( ! tmpMailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		int r = RmDir(GetMailboxPath(MailBoxName), 1 /* ricorsivo */);
		if (r == 0)
		{
			m->Error = GetError("MB043", nClient); // Cannot delete mail box directory
			return m;
		}

		VECT<STRING> mb = TB_MB->GetEmptyRow();
		mb[ F_MB_Name ] = MailBoxName;

		r = TB_MB->Delete(TbFile::M(F_MB_Name), mb);
		if (r == 0)
		{
			m->Error = GetError("MB008", nClient); // Cannot delete mailbox.
			return m;
		}

		VECT<STRING> mm = TB_MM->GetEmptyRow();
		mm[ F_MM_MailboxName ] = MailBoxName;
		r = TB_MM->Delete(TbFile::M(F_MM_MailboxName), mm);
		if (r == 0)
		{
			m->Error = GetError("MB009", nClient); // Cannot delete mailbox entries.
			return m;
		}
	
		Notify::DoNotify(STNew Notify_MB_PHI_DEL(nClient, MailBoxName));
	}
	return m;
}

GenericMsg * MB_DeleteMailbox(c_Moses_MB_DeleteMailbox *q, int nClient)
{
	return MB_DeleteMailbox(q->MailBoxName, nClient);
}

/*
 * API per cambiare la descrizione di una mail-box
 * Cfg puo` cambiarla anche senza sapere la password
 */
GenericMsg * MB_ChangeDescr(c_Moses_MB_ChangeDescr *q, int nClient)
{
	a_Moses_MB_ChangeDescr * m = STNew a_Moses_MB_ChangeDescr;

	int bCfg = G_pServerData->IsCfgClient(nClient);

	VECT<STRING> mb = TB_MB->GetEmptyRow();
	mb[ F_MB_Name  ] = q->MailBoxName;
	mb[ F_MB_Pwd   ] = q->Pwd;
	mb[ F_MB_Descr ] = q->Descr;

	int r = TB_MB->Update(
			TbFile::M(F_MB_Name) | (!bCfg ? TbFile::M(F_MB_Pwd) : 0), mb,
			TbFile::M(F_MB_Descr), mb);

	if (r == 0 || r == -1)
		m->Error = GetError("MB010", nClient); // Wrong mailbox / password.

	return m;
}


/////////////////////////////////////////////////////////////////////////////


/*
 * funzione per controllare se eiste un folder
 */
int MB_CheckFolder(
		int bCfg,
		const STRING &MailBoxName,
		const STRING &Folder)
{
	VECT<STRING> mm = TB_MM->GetEmptyRow();
	mm[ F_MM_MailboxName ]  = MailBoxName;
	mm[ F_MM_Type ]         = "F";
	mm[ F_MM_Folder ]       = GetPathName(Folder);
	mm[ F_MM_Name ]         = GetFileName(Folder);
	mm[ F_MM_DelFlag ]      = "";

	int fMask = TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder);

	if (bCfg)
		fMask |= TbFile::M(F_MM_DelFlag);

	if (Folder != "")
		fMask |= TbFile::M(F_MM_Name);

	long l = TB_MM->Select(fMask, mm, mm, 0L);
	if (l == -1)
		return 0;
	return 1;
}


static STRING MB_GetNewIdMsg(int nStep)
{
	VECT<STRING> moses = TB_MOSES->GetEmptyRow();

	moses[ F_MOSES_Name ]  = G_pServerData->m_MosesName;
	moses[ F_MOSES_IdMsg ] = "0";

	TB_MOSES->Select(moses, 0L);

	INT32 n = moses[ F_MOSES_IdMsg ].GetINT32() + nStep;
	moses[ F_MOSES_IdMsg ] = STRING::Set(n);

	TB_MOSES->Update(
			TbFile::M(F_MOSES_Name),  moses,
			TbFile::M(F_MOSES_IdMsg), moses);

	return moses[ F_MOSES_IdMsg ];
}

/*
 * API per creare un folder
 * Cfg non deve specificare la password
 *     Folder       - il path relativo alla mail-box del folder + il nome del folder
 */
STRING MB_CreateFolder(
		const STRING &MailBoxName,
		const STRING &Pwd,
		const STRING &Folder, // completo di path e nome
		int nClient)
{
	STRING Error;

	int bCfg = G_pServerData->IsCfgClient(nClient);

	if (bCfg || Check_MB_Pwd(MailBoxName, Pwd, Error, nClient))
	{
		/*
		 * controllo prima se esiste gia` cancellato logicamente
		 */
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = GetPathName(Folder);
			mm[ F_MM_Name ]         = GetFileName(Folder);
			mm[ F_MM_DelFlag ]      = "D";

			VECT<STRING> mo = TB_MM->GetEmptyRow();
			mo[ F_MM_DelFlag ]      = "";

			int r = TB_MM->Update(
					TbFile::M( F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_Name, F_MM_DelFlag), mm,
					TbFile::M( F_MM_DelFlag), mo);

			if (r == 1)
				return Error;  // il folder esiste gia`
		}

		/*
		 * Lo creo fisicamente
		 */
		{
			int r = MkDir(GetFolderPath(MailBoxName, Folder));
			if (r == 0)
			{
				Error = GetError("MB011", nClient); // Cannot create folder directory.
				return Error;
			}

			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = GetPathName(Folder);
			mm[ F_MM_Name ]         = GetFileName(Folder);
			mm[ F_MM_Id   ]         = MB_GetNewIdMsg();
			mm[ F_MM_Created ]      = mGetCurrentTime();
			mm[ F_MM_DelFlag ]      = "";

			r = TB_MM->Insert(mm);
			if (r == 0)
			{
				Error = GetError("MB012", nClient); // Cannot create folder.
				RmDir(GetFolderPath(MailBoxName, Folder), 0 /* ricorsiva */);
				return Error;
			}
		}
	}
	return Error;
}

/*
 * API per creare un folder
 * Cfg non deve specificare la password
 */
GenericMsg * MB_CreateFolder(c_Moses_MB_CreateFolder *q, int nClient)
{
	a_Moses_MB_CreateFolder * m = STNew a_Moses_MB_CreateFolder;

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	int bCfg = G_pServerData->IsCfgClient(nClient);
	if ( !bCfg && ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	// Il Folder NON va testato in quanto comprende il path completo.

	m->Error = MB_CreateFolder(q->MailBoxName, q->Pwd, q->Folder, nClient);
	return m;
}

/*
 * API per cancellare un folder (cancellazione logica)
 */
STRING MB_DeleteFolder(
		const STRING &MailBoxName,
		const STRING &Pwd,
		const STRING &Folder,
		int           nClient)
{
	STRING Error;

	int bCfg = G_pServerData->IsCfgClient(nClient);

	if (bCfg || Check_MB_Pwd(MailBoxName, Pwd, Error, nClient))
	{
		/*
		 * Controllo  che il Folder in questione sia gia' cancellato.
		 */
		 {
			 VECT<STRING> i = TB_MM->GetEmptyRow();
			i[ F_MM_MailboxName ]  = MailBoxName;
			i[ F_MM_Type ]         = "F";
			i[ F_MM_Folder ]       = Folder;
			i[ F_MM_DelFlag ]      = "D";
				
			VECT<STRING> o = TB_MM->GetEmptyRow();
			
			if (TB_MM->Select(TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_DelFlag), i, o, 0L) != -1)
			{	
				Error = GetError("MB013", nClient); // Folder already deleted.
				return Error;
			}
		 }
		
		/*
		 * Se l'utente NON e' CFG controllo che i folder da cancellare non
		 * siano in/out/error.
		 */
		 if (!bCfg)
		 {
			 if ( (Folder == "in") || (Folder == "out") || (Folder == "error") )
			 {
				 Error = GetError("MB014", nClient); // Only configuration tool can deleted this folder.
				 return Error;
			 }
		 }
		
		/*
		 * Trovo i subfolders e cancello logicamente tutto quello che sta sotto in maniera ricorsiva
		 */
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = Folder;
			mm[ F_MM_DelFlag ]      = " ";

			VECT<STRING> o = TB_MM->GetEmptyRow();
			long l = 0L;

			while ((l = TB_MM->Select(TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_DelFlag), mm, o, l)) != -1)
			{
				Error = MB_DeleteFolder(
						MailBoxName,
						Pwd,
						o[ F_MM_Folder ] & "/" & o[ F_MM_Name ],
						nClient);

				if (Error.Len())
					return Error;
			}
		}

		/*
		 * Cancello logicamente i messaggi nel folder
		 */
		{
			VECT<STRING> msg = TB_MM->GetEmptyRow();
			msg[ F_MM_MailboxName ]  = MailBoxName;
			msg[ F_MM_Type ]         = "M";
			msg[ F_MM_Folder ]       = Folder;
			msg[ F_MM_DelFlag ]      = "D";

			TB_MM->Update(
					TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder), msg,
					TbFile::M(F_MM_DelFlag), msg);
		}

		/*
		 * cancello logicamente il folder vero e proprio
		 */
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = GetPathName(Folder);
			mm[ F_MM_Name ]         = GetFileName(Folder);
			mm[ F_MM_DelFlag ]      = "D";

			int r = TB_MM->Update(
					TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_Name), mm,
					TbFile::M(F_MM_DelFlag), mm);
			if (r == 0 || r == -1)
				Error = GetError("MB015", nClient); // Cannot delete folder.
		}

		/*
		 * Notifico la cancellazione del folder
		 */
		Notify::DoNotify(STNew Notify_MB_FOLDER_LOG_DEL(nClient, MailBoxName, Folder));
	}

	return Error;
}

GenericMsg * MB_DeleteFolder(c_Moses_MB_DeleteFolder *q, int nClient)
{
	a_Moses_MB_DeleteFolder * m = STNew a_Moses_MB_DeleteFolder;
	
	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
			& " Error = " & m->Error;

		Msg_Log(nClient,
				"DeleteFolder",
				rmks.Str());

		return m;
	}

	if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
			& " Error = " & m->Error;

		Msg_Log(nClient,
				"DeleteFolder",
				rmks.Str());

		return m;
	}

	// Il Folder NON va testato in quanto comprende il path completo.

	m->Error =  MB_DeleteFolder(q->MailBoxName, q->Pwd, q->Folder, nClient);

	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
		& " Error = " & m->Error;

	Msg_Log(nClient,
			"DeleteFolder",
			rmks.Str());

	return m;
}


/*
 * API per ripristinare un folder cancellato logicamente
 */
STRING MB_UndeleteFolder( /*R*/
		const STRING &MailBoxName,
		const STRING &Pwd,
		const STRING &Folder,
		int           nClient,
		int           bOnRecurse = 0)
{
	STRING Error;

	int bCfg = G_pServerData->IsCfgClient(nClient);

	// if (bCfg || Check_MB_Pwd(MailBoxName, Pwd, Error, nClient))
	if (G_pServerData->Check_R(nClient, Error))
	{
		/*
		 * Ripristino il folder corrente
		 */
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = GetPathName(Folder);
			mm[ F_MM_Name ]         = GetFileName(Folder);
			mm[ F_MM_DelFlag ]      = "D";

			VECT<STRING> mo = TB_MM->GetEmptyRow();
			mo[ F_MM_DelFlag ]      = " ";

			int fMask = TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_Name);
			if (bOnRecurse == 0)
				fMask |= TbFile::M(F_MM_DelFlag);

			int r = TB_MM->Update(
					fMask, mm,
					TbFile::M(F_MM_DelFlag), mo);
			if (r == 0 || r == -1)
			{
				Error = GetError("MB016", nClient); // Cannot undelete folder.
				return Error;
			}
		}


		/*
		 * Ripristino logicamente i messaggi nel folder
		 */
		{
			VECT<STRING> msg = TB_MM->GetEmptyRow();
			msg[ F_MM_MailboxName ]  = MailBoxName;
			msg[ F_MM_Type ]         = "M";
			msg[ F_MM_Folder ]       = Folder;
			msg[ F_MM_DelFlag ]      = "";

			TB_MM->Update(
					TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder), msg,
					TbFile::M(F_MM_DelFlag), msg);
		}

		/*
		 * Trovo i subfolders e ripristino logicamente tutto quello che sta sotto in maniera ricorsiva
		 */
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = Folder;

			VECT<STRING> o = TB_MM->GetEmptyRow();
			long l = 0L;

			while ((l = TB_MM->Select(TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder), mm, o, l)) != -1)
			{
				MB_UndeleteFolder(MailBoxName, Pwd, o[ F_MM_Folder ] & "/" & o[ F_MM_Name ], nClient, 1 /* bOnRecurse */);
			}
		}

		Notify::DoNotify(STNew Notify_MB_FOLDER_LOG_UNDEL(nClient, MailBoxName, Folder));
	}
	return Error;
}


GenericMsg * MB_UndeleteFolder(c_Moses_MB_UndeleteFolder *q, int nClient)
{
	a_Moses_MB_UndeleteFolder * m = STNew a_Moses_MB_UndeleteFolder;
	
	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	// Il Folder NON va testato in quanto comprende il path completo.

	m->Error = MB_UndeleteFolder(q->MailBoxName, q->Pwd, q->Folder, nClient);
	return m;
}



/*
 * API per listare i folder nel folder specificato
 *   CFG ottiene anche i folder cancellati logicamente
 */
GenericMsg * MB_ListFolder(c_Moses_MB_ListFolder *q, int nClient)
{
	a_Moses_MB_ListFolder * m = STNew a_Moses_MB_ListFolder;

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if ( !q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	// Il Folder NON va testato in quanto comprende il path completo.

	int bCfg    = G_pServerData->IsCfgClient(nClient);
	int bPwd    = 0;
	int bSystem = 0;
	
	if (!bCfg)
		bSystem = (q->MailBoxName == "system" && q->Folder == "");

	if (!bCfg && !bSystem)
		bPwd = Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient);

	if (bCfg || bPwd || bSystem)
	{
		if (MB_CheckFolder(bCfg, q->MailBoxName, q->Folder) == 0)
		{
			m->Error = GetError("MB017", nClient); // Unknow mailbox/folder.
		}
		else
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = q->MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = q->Folder;
			mm[ F_MM_DelFlag ]      = "";

			int fMask = TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder);
			if (bCfg == 0)
				fMask |= TbFile::M(F_MM_DelFlag);

			long l = 0L;
			while ((l = TB_MM->Select(fMask, mm, mm, l)) != -1)
			{
				if (bCfg ||
						bPwd ||
						(mm[ F_MM_Name ] == "in" ||
						 mm[ F_MM_Name ] == "out" ||
						 mm[ F_MM_Name ] == "error"))
				{
					m->FolderList.Append( mm[ F_MM_Name ] );
					m->DeletedList.Append( mm[ F_MM_DelFlag ] == "D" );
				}
			}
		}
	}

	return m;
}


/*
 * API per ottenere un nuovo identificatore di messaggio o di folder
 */
GenericMsg * MB_GetNewMsgId(c_Moses_MB_GetNewId *q, int nClient)
{
	a_Moses_MB_GetNewId *m = STNew a_Moses_MB_GetNewId;
	STRING n = MB_GetNewIdMsg();
	m->MsgId = n.GetINT32();
	return m;
}


/*
 * API per cambiare Id ad un Msg e segnalazione della modifica nel file di log
 */

GenericMsg * Log_NewMsgId(c_Moses_Log_NewMsgId *q, int nClient)
{
	a_Moses_Log_NewMsgId * m = STNew a_Moses_Log_NewMsgId;

	int bCfg = G_pServerData->IsCfgClient(nClient);

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if (!bCfg)
	{
		if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & 
				" NewMsgId = " & STRING::Set(q->NewMsgId) & " Error = " & m->Error;
			
			Msg_Log(q->OldMsgId,
					nClient,
					"NewMsgId",
					rmks.Str());
			
			return m;
		}
		if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
		{
			m->Error = GetError("G004", nClient);    // Invalid Password.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & 
				" NewMsgId = " & STRING::Set(q->NewMsgId) & " Error = " & m->Error;
			
			Msg_Log(q->OldMsgId,
					nClient,
					"NewMsgId",
					rmks.Str());
			
			return m;
		}
	}


	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id      ] = STRING::Set(q->OldMsgId);

		long l = TB_MM->Select(TbFile::M(F_MM_Id), v, v, 0L);
		if (l == -1L)
		{
			m->Error = GetError("MB027", nClient); // Wrong message identifier.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & 
				" NewMsgId = " & STRING::Set(q->NewMsgId) & " Error = " & m->Error;
			
			Msg_Log(q->OldMsgId,
					nClient,
					"NewMsgId",
					rmks.Str());
			
			return m;
		}
		else
		if (bCfg == 0 && v[ F_MM_DelFlag ] == "D")
		{
			m->Error = GetError("MB028", nClient); // Reading a deleted message.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & 
				" NewMsgId = " & STRING::Set(q->NewMsgId) & " Error = " & m->Error;
			
			Msg_Log(q->OldMsgId,
					nClient,
					"NewMsgId",
					rmks.Str());
			
			return m;
		}

		if (!bCfg && q->MailBoxName != v[ F_MM_MailboxName ])
		{
			m->Error = GetError("MB001", nClient); // Wrong mailbox / password.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & 
				" NewMsgId = " & STRING::Set(q->NewMsgId) & " Error = " & m->Error;
			
			Msg_Log(q->OldMsgId,
					nClient,
					"NewMsgId",
					rmks.Str());
			
			return m;
		}
	}

	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName & 
		" NewMsgId = " & STRING::Set(q->NewMsgId) & " Error = " & m->Error;
	
	Msg_Log(q->OldMsgId,
			nClient,
			"NewMsgId",
			rmks.Str());
	
	return m;
}



/*
 * API per scrivere un messaggio in un folder.
 *  - deve aggiornare la tabella MM
 *  - creare un file nel folder opportuno di nome <IdMsg>.msg
 *  - lanciare l'event-handler se sono in un folder in/out/error o system/out
 */
GenericMsg * MB_WriteInFolder(c_Moses_MB_WriteInFolder *q, int nClient)
{
	a_Moses_MB_WriteInFolder * m = STNew a_Moses_MB_WriteInFolder;

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
			& " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"WriteInFolder",
				rmks.Str());

		return m;
	}

	if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
			& " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"WriteInFolder",
				rmks.Str());

		return m;
	}

	// Il Folder NON va testato in quanto comprende il path completo.
	
	// Eseguo il controllo di validita' su Sender e sul Reciver del MM.
	if ( ! q->Sender.IsIdentifier(LEN_NAME_USER) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
			& " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"WriteInFolder",
				rmks.Str());

		return m;
	}

	if ( ! q->Destination.IsIdentifier(LEN_NAME_USER) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
			& " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"WriteInFolder",
				rmks.Str());

		return m;
	}

	if (! User_Exists(q->Sender) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
			& " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"WriteInFolder",
				rmks.Str());

		return m;
	}
	if (! User_Exists(q->Destination) )
	{
		m->Error = GetError("G003", nClient);    // Invalid User Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
			& " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"WriteInFolder",
				rmks.Str());

		return m;
	}

	int bCfg = G_pServerData->IsCfgClient(nClient);

	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		// controllo l'esistenza del folder
		if (MB_CheckFolder(bCfg, q->MailBoxName, q->Folder) == 0)
		{
			m->Error = GetError("MB018", nClient); // Unknow Folder.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
				& " Error = " & m->Error;

			Msg_Log(q->MsgId,
					nClient,
					"WriteInFolder",
					rmks.Str());

			return m;
		}

		// copio il messaggio nel folder
		{
			// compongo il nome del file con il path completo
			STRING fileName = GetMsgPath(q->MailBoxName, q->Folder, q->MsgId);

			STRING ee = File::Write(fileName, q->Body);
			if (ee.Len())
			{
				m->Error = GetError("MB019", nClient)  &  ee; // Error in File::Write: "ee".

				// Scrivo sul file di log componendo prima il commento relativo.
				STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
					& " Error = " & m->Error;

				Msg_Log(q->MsgId,
						nClient,
						"WriteInFolder",
						rmks.Str());

				return m;
			}
		}

		// aggiorno la tabella MM
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = q->MailBoxName;
			mm[ F_MM_Type    ]      = "M";
			mm[ F_MM_Folder  ]      = q->Folder;
			mm[ F_MM_Id      ]      = STRING::Set(q->MsgId);
			mm[ F_MM_Created ]      = mGetCurrentTime();
			mm[ F_MM_DelFlag ]      = "";

			mm[ F_MM_Sender   ]     = q->Sender;
			mm[ F_MM_Receiver ]     = q->Destination;
			mm[ F_MM_Subject  ]     = q->Subject;
			mm[ F_MM_InOut    ]     = q->bIncoming == 1 ? "I" : "O";
			mm[ F_MM_SzBody   ]     = STRING::Set((INT32)q->Body.Len());

			int r = TB_MM->Insert(mm);
			if (r == 0)
			{
				m->Error = GetError("MB020", nClient); // Cannot insert message data in MM table

				// Scrivo sul file di log componendo prima il commento relativo.
				STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
					& " Error = " & m->Error;

				Msg_Log(q->MsgId,
						nClient,
						"WriteInFolder",
						rmks.Str());

				return m;
			}
		}

		m->Error = Msg_InFolder(
				nClient,
				q->MsgId,
				q->MailBoxName,
				q->Folder);

	}
	
	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName  & " Folder = " & q->Folder 
		& " Error = " & m->Error;

	Msg_Log(q->MsgId,
			nClient,
			"WriteInFolder",
			rmks.Str());

	return m;
}

/*
 * API per listare tutti i messaggi in un folder
 *    CFG ottiene anche i messaggi cancellati logicamente
 */
GenericMsg * MB_ListMsg(c_Moses_MB_ListMsg *q, int nClient)
{
	a_Moses_MB_ListMsg * m = STNew a_Moses_MB_ListMsg;

	int bCfg    = G_pServerData->IsCfgClient(nClient);
	int bSystem = 0;

	if (!bCfg)
		bSystem = q->MailBoxName == "system" &&
			(q->Folder == "in" || q->Folder == "out" || q->Folder == "error");

	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if (!bCfg && !bSystem && !q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */))
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	if (q->Cond_Sender.Len())
		if ( ! q->Cond_Sender.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}

	if (q->Cond_Receiver.Len())
		if ( ! q->Cond_Receiver.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}


	if (!bSystem && (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient)))
	{
		if (MB_CheckFolder(bCfg, q->MailBoxName, q->Folder) == 0)
		{
			m->Error = GetError("MB022", nClient); // Unknow mailbox/folder.
		}
		else
		{
			VECT<STRING> s = TB_MM->GetEmptyRow();
			s[ F_MM_MailboxName ] = q->MailBoxName;
			s[ F_MM_Folder ]      = q->Folder;
			s[ F_MM_Type   ]      = "M";
			s[ F_MM_DelFlag ]     = "";

			int ffCond = 0;
			s[ F_MM_UserField ]   = q->Cond_UserField; if (q->Cond_UserField.Len()) ffCond |= F_MM_UserField;
			s[ F_MM_Sender    ]   = q->Cond_Sender;    if (q->Cond_Sender   .Len()) ffCond |= F_MM_Sender;
			s[ F_MM_Receiver  ]   = q->Cond_Receiver;  if (q->Cond_Receiver .Len()) ffCond |= F_MM_Receiver;

			long l = 0L;
			while ((l = TB_MM->Select(ffCond | TbFile::M(F_MM_MailboxName, F_MM_Folder, F_MM_Type) | (!bCfg ? TbFile::M(F_MM_DelFlag) : 0), s, s, l)) != -1L)
			{
				if (q->Cond_Accessed.Len() == 0 ||
						q->Cond_Accessed == "Y" && s[ F_MM_Accessed ].Len() != 0 ||
						q->Cond_Accessed == "N" && s[ F_MM_Accessed ].Len() == 0)
					m->MsgIdList.Append( s[ F_MM_Id ].GetINT32() );
			}
		}
	}
	else
		if (bSystem)
		{
			m->Error = "";

			VECT<STRING> s = TB_MM->GetEmptyRow();
			s[ F_MM_MailboxName ] = q->MailBoxName;
			s[ F_MM_Folder ]      = q->Folder;
			s[ F_MM_Type   ]      = "M";
			s[ F_MM_DelFlag ]     = "";

			int ffCond = 0;
			s[ F_MM_UserField ]   = q->Cond_UserField; if (q->Cond_UserField.Len()) ffCond |= F_MM_UserField;
			s[ F_MM_Sender    ]   = q->Cond_Sender;    if (q->Cond_Sender   .Len()) ffCond |= F_MM_Sender;
			s[ F_MM_Receiver  ]   = q->Cond_Receiver;  if (q->Cond_Receiver .Len()) ffCond |= F_MM_Receiver;

			long l = 0L;
			while ((l = TB_MM->Select(ffCond | TbFile::M(F_MM_MailboxName, F_MM_Folder, F_MM_Type) | (!bCfg ? TbFile::M(F_MM_DelFlag) : 0), s, s, l)) != -1L)
			{
				if (s[ F_MM_Sender   ] != G_pServerData->GetClientUserName(nClient) &&
						s[ F_MM_Receiver ] != G_pServerData->GetClientUserName(nClient))
					continue;

				if (q->Cond_Accessed.Len() == 0 ||
						q->Cond_Accessed == "Y" && s[ F_MM_Accessed ].Len() != 0 ||
						q->Cond_Accessed == "N" && s[ F_MM_Accessed ].Len() == 0)
					m->MsgIdList.Append( s[ F_MM_Id ].GetINT32() );
			}
		}


	return m;
}

GenericMsg * MB_GetInfo(c_Moses_MB_GetInfo *q, int nClient)
{
	a_Moses_MB_GetInfo * m = STNew a_Moses_MB_GetInfo;

	int bCfg = G_pServerData->IsCfgClient(nClient);

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if (!bCfg && ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if (!bCfg && ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}


	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id      ] = STRING::Set(q->MsgId);

		long l = TB_MM->Select(TbFile::M(F_MM_Id), v, v, 0L);
		if (l == -1L)
			m->Error = GetError("MB023", nClient); // Wrong message identifier.
		else
		if (bCfg == 0 && v[ F_MM_DelFlag ] == "D")
			m->Error = GetError("MB024", nClient); // Getting info of a deleted message.
		else
		{
			if (!bCfg && v [ F_MM_MailboxName ] != q->MailBoxName )
				m->Error = GetError("MB001", nClient); // Wrong mailbox / password.
			else
			{
				m->Status.Append("CREATED    " & v[ F_MM_Created ]);
				m->Status.Append("ACCESSED   " & v[ F_MM_Accessed ]);
				m->Status.Append("SENT       " & v[ F_MM_Sent ]);
				m->Status.Append("DISPATCHED " & v[ F_MM_Dispatched ]);
				m->Status.Append("DELIVERED  " & v[ F_MM_Delivered ]);
				m->Status.Append("READ       " & v[ F_MM_Read ]);
				if (v[ F_MM_DelFlag ] == "D")
					m->Status.Append("DELETED");
				else
					m->Status.Append("");

				m->Sender       = v[ F_MM_Sender   ];
				m->Destination  = v[ F_MM_Receiver ];
				m->Subject      = v[ F_MM_Subject  ];
				m->BodySize     = v[ F_MM_SzBody   ].GetINT32();
				m->bIncoming    = v[ F_MM_InOut    ] == "I";
			}
		}
	}

	return m;
}

GenericMsg * MB_SetInfo(c_Moses_MB_SetInfo *q, int nClient)
{
	a_Moses_MB_SetInfo * m = STNew a_Moses_MB_SetInfo;

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB, 0 /* bNotNull */ ) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"SetInfo",
				rmks.Str());

		return m;
	}

	if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"SetInfo",
				rmks.Str());

		return m;
	}

	int bCfg = G_pServerData->IsCfgClient(nClient);
	int bSystem = 0;

	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		if (!bCfg && !Check_MsgId_In_MB(q->MsgId, q->MailBoxName))
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;

			Msg_Log(q->MsgId,
					nClient,
					"SetInfo",
					rmks.Str());

			return m;
		}

		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id      ] = STRING::Set(q->MsgId);


		int fMask = 0;
		for (int i = 0; i < q->Status.Size(); i++)
		{
			char t[100], ts[100];
			ts[0] = '\0';
			istrstream ss(q->Status[i].Str());
			ss >> t >> ts;

			     if (STRING(t) == "CREATED")    { v[ F_MM_Created    ] = ts; fMask |= TbFile::M( F_MM_Created    ); }
			else if (STRING(t) == "ACCESSED")   { v[ F_MM_Accessed   ] = ts; fMask |= TbFile::M( F_MM_Accessed   ); }
			else if (STRING(t) == "SENT")       { v[ F_MM_Sent       ] = ts; fMask |= TbFile::M( F_MM_Sent       ); }
			else if (STRING(t) == "DISPATCHED") { v[ F_MM_Dispatched ] = ts; fMask |= TbFile::M( F_MM_Dispatched ); }
			else if (STRING(t) == "DELIVERED")  { v[ F_MM_Delivered  ] = ts; fMask |= TbFile::M( F_MM_Delivered  ); }
			else if (STRING(t) == "READ")       { v[ F_MM_Read       ] = ts; fMask |= TbFile::M( F_MM_Read       ); }
			else                                { m->Error = GetError("MB025", nClient); /* Wrong message status */ return m; }
		}

		int r = TB_MM->Update(
				TbFile::M( F_MM_Id), v,
				fMask, v);

		if (r != 1)
			m->Error = GetError("MB026", nClient); // Wrong message identifier.
	}


	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;

	Msg_Log(q->MsgId,
			nClient,
			"SetInfo",
			rmks.Str());

	return m;
}

GenericMsg * MB_SetInfoEx(c_Moses_MB_SetInfoEx *q, int nClient)
{
	a_Moses_MB_SetInfoEx * m = STNew a_Moses_MB_SetInfoEx;

	int bCfg = G_pServerData->IsCfgClient(nClient);
	int bSystem = 0;

	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		if (!bCfg && !Check_MsgId_In_MB(q->MsgId, q->MailBoxName))
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = "  & m->Error;

			Msg_Log(q->MsgId,
					nClient,
					"SetInfoEx",
					rmks.Str());

			return m;
		}

		if (! User_Exists(q->Sender) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = "  & m->Error;

			Msg_Log(q->MsgId,
					nClient,
					"SetInfoEx",
					rmks.Str());

			return m;
		}
		if (! User_Exists(q->Destination) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = "  & m->Error;

			Msg_Log(q->MsgId,
					nClient,
					"SetInfoEx",
					rmks.Str());

			return m;
		}

		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id      ] = STRING::Set(q->MsgId);

		int fMask = 0;
		for (int i = 0; i < q->Status.Size(); i++)
		{
			char t[100], ts[100];
			ts[0] = '\0';
			istrstream ss(q->Status[i].Str());
			ss >> t >> ts;

			if (STRING(t) == "CREATED")    { v[ F_MM_Created    ] = ts; fMask |= TbFile::M( F_MM_Created    ); }
			else if (STRING(t) == "ACCESSED")   { v[ F_MM_Accessed   ] = ts; fMask |= TbFile::M( F_MM_Accessed   ); }
			else if (STRING(t) == "SENT")       { v[ F_MM_Sent       ] = ts; fMask |= TbFile::M( F_MM_Sent       ); }
			else if (STRING(t) == "DISPATCHED") { v[ F_MM_Dispatched ] = ts; fMask |= TbFile::M( F_MM_Dispatched ); }
			else if (STRING(t) == "DELIVERED")  { v[ F_MM_Delivered  ] = ts; fMask |= TbFile::M( F_MM_Delivered  ); }
			else if (STRING(t) == "READ")       { v[ F_MM_Read       ] = ts; fMask |= TbFile::M( F_MM_Read       ); }
			else                                { m->Error = GetError("MB025", nClient); /* Wrong message status */ return m; }


		}

		fMask |= TbFile::M( F_MM_Sender);
		fMask |= TbFile::M( F_MM_Receiver);
		fMask |= TbFile::M( F_MM_Subject);
		fMask |= TbFile::M( F_MM_InOut);

		v[ F_MM_Sender   ] = q->Sender;
		v[ F_MM_Receiver ] = q->Destination;
		v[ F_MM_Subject  ] = q->Subject;
		v[ F_MM_InOut    ] = q->bIncoming ? "I" : "O";

		int r = TB_MM->Update(
				TbFile::M( F_MM_Id), v,
				fMask, v);

		if (r != 1)
			m->Error = GetError("MB026", nClient); // Wrong message identifier.
	}


	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName & " Error = "  & m->Error;

	Msg_Log(q->MsgId,
			nClient,
			"SetInfoEx",
			rmks.Str());

	return m;
}


GenericMsg * MB_MsgRead(c_Moses_MB_MsgRead *q, int nClient)
{	
	a_Moses_MB_MsgRead * m = STNew a_Moses_MB_MsgRead;

	int bCfg = G_pServerData->IsCfgClient(nClient);

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if (!bCfg)
	{
		if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgRead",
					rmks.Str());
			
			return m;
		}
		if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
		{
			m->Error = GetError("G004", nClient);    // Invalid Password.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgRead",
					rmks.Str());
			
			return m;
		}
	}


	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id      ] = STRING::Set(q->MsgId);

		long l = TB_MM->Select(TbFile::M(F_MM_Id), v, v, 0L);
		if (l == -1L)
		{
			m->Error = GetError("MB027", nClient); // Wrong message identifier.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgRead",
					rmks.Str());
			
			return m;
		}
		else
		if (bCfg == 0 && v[ F_MM_DelFlag ] == "D")
		{
			m->Error = GetError("MB028", nClient); // Reading a deleted message.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgRead",
					rmks.Str());
			
			return m;
		}

		if (!bCfg && q->MailBoxName != v[ F_MM_MailboxName ])
		{
			m->Error = GetError("MB001", nClient); // Wrong mailbox / password.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgRead",
					rmks.Str());
			
			return m;
		}

		STRING fileName = GetMsgPath(q->MailBoxName, v[ F_MM_Folder ], q->MsgId);
		STRING ee = File::Read(fileName, m->Body);
		if (ee.Len())
		{
			m->Error = GetError("MB029", nClient) & ee; // Error in File::Read:  & "ee".

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgRead",
					rmks.Str());
			
			return m;
		}

		// aggiorno la riga di TB_MM per dire che il messaggio e' stato letto
		// l'aggiornamento avviene solo se il cliente e' di tipo APP
		if (G_pServerData->IsAppClient(nClient))
		{
			VECT<STRING> v = TB_MM->GetEmptyRow();
			v[ F_MM_Id       ] = STRING::Set(q->MsgId);
			v[ F_MM_Accessed ] = mGetCurrentTime();

			int r = TB_MM->Update(
					TbFile::M(F_MM_Id), v,
					TbFile::M(F_MM_Accessed), v);
			if (r != 1)
			{
				m->Error = GetError("MB030", nClient); // Cannot update access time.

				// Scrivo sul file di log componendo prima il commento relativo.
				STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
				
				Msg_Log(q->MsgId,
						nClient,
						"MsgRead",
						rmks.Str());
				
				return m;
			}
		}
	}


	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
	
	Msg_Log(q->MsgId,
			nClient,
			"MsgRead",
			rmks.Str());
	
	return m;
}

GenericMsg * MB_MsgFile(c_Moses_MB_MsgFile *q, int nClient)
{	
	a_Moses_MB_MsgFile * m = STNew a_Moses_MB_MsgFile;

	int bCfg = G_pServerData->IsCfgClient(nClient);

	if (bCfg)
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id ] = STRING::Set(q->MsgId);

		long l = TB_MM->Select(TbFile::M(F_MM_Id), v, v, 0L);
		if (l == -1L)
		{
			m->Error = GetError("MB027", nClient); // Wrong message identifier.
			return m;
		}

		m->MsgFile = GetMsgPath(v[ F_MM_MailboxName ], v[ F_MM_Folder ], q->MsgId);

#ifdef _WIN32
		// giro tutti gli "/" in "\"

		char *p = m->MsgFile.Str();

		while (p = strchr(p, '/'))
			*p = '\\';
#endif
	}
	else
		m->Error = GetError("MB027", nClient); // Wrong message identifier.

	return m;
}

GenericMsg * MB_Msg_Delete(c_Moses_MB_Msg_Delete *q, int nClient)
{
	a_Moses_MB_Msg_Delete * m = STNew a_Moses_MB_Msg_Delete;


	int bCfg = G_pServerData->IsCfgClient(nClient);

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if (!bCfg)
	{
		if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgDelete",
					rmks.Str());
			
			return m;
		}

		if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
		{
			m->Error = GetError("G004", nClient);    // Invalid Password.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgDelete",
					rmks.Str());
			
			return m;
		}
	}


	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		if (!bCfg && !Check_MsgId_In_MB(q->MsgId, q->MailBoxName))
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MsgDelete",
					rmks.Str());
			
			return m;
		}

		VECT<STRING> i = TB_MM->GetEmptyRow();
		VECT<STRING> o = TB_MM->GetEmptyRow();
		i[ F_MM_Id      ] = STRING::Set(q->MsgId);
		i[ F_MM_DelFlag ] = " ";
		o[ F_MM_Id      ] = STRING::Set(q->MsgId);
		o[ F_MM_DelFlag ] = "D";

		int r = TB_MM->Update(
				TbFile::M(F_MM_Id, F_MM_DelFlag), i,
				TbFile::M(F_MM_Id, F_MM_DelFlag), o);

		if ((r == 0) || (r == -1))
			m->Error = GetError("MB031", nClient); // Wrong message identifier / deleted message.

	}

	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;
	
	Msg_Log(q->MsgId,
			nClient,
			"MsgDelete",
			rmks.Str());
	
	return m;
}


STRING MB_MoveMsg(
		int           nClient,
		const STRING &MailBoxName,
		const STRING &Pwd,
		INT32         MsgId,
		const STRING &DestFolder)
{
	STRING e;

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! MailBoxName.IsIdentifier(LEN_NAME_MB) )
		return GetError("G005", nClient);    // Invalid Mailbox Name.

	if ( ! Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
		return GetError("G004", nClient);    // Invalid Password.

	// Il DestFolder NON va testato in quanto comprende il path completo.

	int bCfg = G_pServerData->IsCfgClient(nClient);
	if (bCfg || Check_MB_Pwd(MailBoxName, Pwd, e, nClient))
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id ] = STRING::Set(MsgId);

		long l = TB_MM->Select(TbFile::M(F_MM_Id), v, v, 0L);
		if (l == -1L)
			return GetError("MB032", nClient); // Wrong message identifier.

		if (!bCfg && v[ F_MM_DelFlag ] == "D")
			return GetError("MB033", nClient); // Trying to move a deleted message.

		if (v[F_MM_MailboxName] != MailBoxName)
			return GetError("MB001", nClient); // Wrong mailbox / password.

		STRING from = GetMsgPath(MailBoxName, v[ F_MM_Folder ], MsgId);
		STRING to   = GetMsgPath(MailBoxName, DestFolder,       MsgId);

		if (MB_CheckFolder(bCfg, MailBoxName, DestFolder) == 0)
			return GetError("MB034", nClient); // Trying to move a message to a deleted folder.

		STRING ee = File::Move(from, to);
		if (ee.Len() != 0)
			return GetError("MB035", nClient) & ee; // Error in File::Move: " & "ee".

		v[ F_MM_Folder ] = DestFolder;
		int r = TB_MM->Update(
				TbFile::M(F_MM_Id), v,
				TbFile::M(F_MM_Folder), v);

		if (r == 0)
			return GetError("MB036", nClient); // Wrong message identifier.

		e = Msg_InFolder(
				nClient,
				MsgId,
				MailBoxName,
				DestFolder);

		return e;
	}
	return e;
}

GenericMsg * MB_MoveMsg(c_Moses_MB_MoveMsg *q, int nClient)
{
	a_Moses_MB_MoveMsg * m = STNew a_Moses_MB_MoveMsg;
	m->Error = MB_MoveMsg(
			nClient,
			q->MailBoxName,
			q->Pwd,
			q->MsgId,
			q->DestFolder);

	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName & " DestFolder = " & q->DestFolder 
		& " Error = " & m->Error;
	
	Msg_Log(q->MsgId,
			nClient,
			"MoveMsg",
			rmks.Str());
	
	return m;

}

GenericMsg * MB_MoveMsg2(c_Moses_MB_MoveMsg2 *q, int nClient)
{
	a_Moses_MB_MoveMsg2 * m = STNew a_Moses_MB_MoveMsg2;

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! q->MailBoxNameSource.IsIdentifier(LEN_NAME_MB) ||
	     ! q->MailBoxNameDest.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
			" MB_Dest = " & q->MailBoxNameSource & 
			" F_Dest = " & q->DestFolder & " Error = " & m->Error;
		
		Msg_Log(q->MsgId,
				nClient,
				"MoveMsg2",
				rmks.Str());
		
		return m;
	}

	if ( ! q->PwdSource.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) ||
	     ! q->PwdDest.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
			" MB_Dest = " & q->MailBoxNameSource & 
			" F_Dest = " & q->DestFolder & " Error = " & m->Error;
		
		Msg_Log(q->MsgId,
				nClient,
				"MoveMsg2",
				rmks.Str());
		
		return m;
	}

	// Il DestFolder NON va testato in quanto comprende il path completo.

	int bCfg = G_pServerData->IsCfgClient(nClient);
	int bPwd = 0;

	if (!bCfg)
	{
		bPwd = bPwd || Check_MB_Pwd(q->MailBoxNameSource, q->PwdSource, m->Error, nClient);
		bPwd = bPwd || Check_MB_Pwd(q->MailBoxNameDest,   q->PwdDest,   m->Error, nClient);

		if (!bPwd)
		{
			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
				" MB_Dest = " & q->MailBoxNameSource & 
				" F_Dest = " & q->DestFolder & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MoveMsg2",
					rmks.Str());
			
			return m;
		}
	}

	if (bCfg || bPwd)
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id ] = STRING::Set(q->MsgId);

		long l = TB_MM->Select(TbFile::M(F_MM_Id), v, v, 0L);
		if (l == -1L)
		{
			m->Error = GetError("MB032", nClient); // Wrong message identifier.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
				" MB_Dest = " & q->MailBoxNameSource & 
				" F_Dest = " & q->DestFolder & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MoveMsg2",
					rmks.Str());
			
			return m;
		}

		if (!bCfg && v[ F_MM_DelFlag ] == "D")
		{
			m->Error = GetError("MB033", nClient); // Trying to move a deleted message.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
				" MB_Dest = " & q->MailBoxNameSource & 
				" F_Dest = " & q->DestFolder & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MoveMsg2",
					rmks.Str());
			
			return m;
		}

		if (v[F_MM_MailboxName] != q->MailBoxNameSource)
		{
			m->Error = GetError("MB001", nClient); // Wrong mailbox / password.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
				" MB_Dest = " & q->MailBoxNameSource & 
				" F_Dest = " & q->DestFolder & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MoveMsg2",
					rmks.Str());
			
			return m;
		}

		STRING from = GetMsgPath(q->MailBoxNameSource, v[ F_MM_Folder ], q->MsgId);
		STRING to   = GetMsgPath(q->MailBoxNameDest,   q->DestFolder,    q->MsgId);

		if (MB_CheckFolder(bCfg, q->MailBoxNameDest, q->DestFolder) == 0)
		{
			m->Error = GetError("MB034", nClient); // Trying to move a message to a deleted folder.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
				" MB_Dest = " & q->MailBoxNameSource & 
				" F_Dest = " & q->DestFolder & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MoveMsg2",
					rmks.Str());
			
			return m;
		}

		STRING ee = File::Move(from, to);
		if (ee.Len() != 0)
		{
			m->Error = GetError("MB035", nClient) & ee; // Error in File::Move: " & "ee".
			m->Error = "MB016 - Error in File::Move: " & ee;

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
				" MB_Dest = " & q->MailBoxNameSource & 
				" F_Dest = " & q->DestFolder & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MoveMsg2",
					rmks.Str());
			
			return m;
		}

		v[ F_MM_MailboxName ] = q->MailBoxNameDest;
		v[ F_MM_Folder ]      = q->DestFolder;
		int r = TB_MM->Update(
				TbFile::M(F_MM_Id), v,
				TbFile::M(F_MM_Folder, F_MM_MailboxName), v);

		if (r == 0)
		{
			m->Error = GetError("MB036", nClient); // Wrong message identifier.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
				" MB_Dest = " & q->MailBoxNameSource & 
				" F_Dest = " & q->DestFolder & " Error = " & m->Error;
			
			Msg_Log(q->MsgId,
					nClient,
					"MoveMsg2",
					rmks.Str());
			
			return m;
		}

		m->Error = Msg_InFolder(
				nClient,
				q->MsgId,
				q->MailBoxNameDest,
				q->DestFolder);


		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB_Source = " & q->MailBoxNameSource & 
			" MB_Dest = " & q->MailBoxNameSource & 
			" F_Dest = " & q->DestFolder & " Error = " & m->Error;
		
		Msg_Log(q->MsgId,
				nClient,
				"MoveMsg2",
				rmks.Str());
		
	}
	return m;
}

STRING Msg_InFolder(
		int           nClient,
		INT32         MsgId,
		const STRING &MailBoxName,
		const STRING &DestFolder)
{
	// controllo se esiste il messaggio e ricavo i dati
	VECT<STRING> v = TB_MM->GetEmptyRow();
	v[ F_MM_Id ] = STRING::Set(MsgId);
	long l = TB_MM->Select(TbFile::M(F_MM_Id), v, v, 0L);
	if (l == -1L)
		return GetError("MB036", nClient); // Wrong message identifier.



	// lancio l'event handler se il folder e' system/out/in/error
	if (Is_InOutError_Folder(DestFolder))
	{
		Notify::DoNotify(STNew Notify_MB_MSG_WRITE(
				nClient,
				MailBoxName,
				DestFolder,
				MsgId,
				v[ F_MM_Sender ],
				v[ F_MM_Receiver ],
				v[ F_MM_Subject ]));
	}


	// lancio l'event handler se il folder e' system/out (MTD)
	if (Is_Out_System_Folder(MailBoxName, DestFolder))
	{
		if (UserExternal_Exists(v[F_MM_Receiver]))
		{
			// cerco il tipo di mailbox per svegliare l'MTD opportuno
			STRING out_MailBoxType, out_MailBoxAddress, out_Subject;
			STRING e = ART_OutAddress(
					nClient,              // nClient
					v[ F_MM_Receiver ],   // User
					"",                   // MailBoxType richiesta
					out_MailBoxType,      // MailBoxType trovata
					out_MailBoxAddress,   // Indirizzo (non usato)
					out_Subject);         // Soggetto (non usato)

			if (e.Len())
				return e;

			Notify::DoNotify(STNew Notify_MB_MSG_FOR_MTD(
					nClient,
					out_MailBoxType,
					MsgId,
					v[ F_MM_Sender ],
					v[ F_MM_Receiver ],
					v[ F_MM_Subject ]));
		}
		else
		if (UserInternal_Exists(v[F_MM_Receiver]))
		{
			// devo solo spostare il messaggio da system/out a system/in
			return MB_MoveMsg(
					-1,                // nClient
					"system",          // MailBoxName
					"",                // Pwd
					MsgId,             // MsgId
					"in");             // DestFolder
		}
	}

	return "";
}

GenericMsg * MB_Set_Userfield(c_Moses_MB_Set_Userfield *q, int nClient)
{
	a_Moses_MB_Set_Userfield * m = STNew a_Moses_MB_Set_Userfield;

	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"Set_Userfield",
				rmks.Str());

		return m;
	}

	if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.

		// Scrivo sul file di log componendo prima il commento relativo.
		STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;

		Msg_Log(q->MsgId,
				nClient,
				"Set_Userfield",
				rmks.Str());

		return m;
	}

	int bCfg = G_pServerData->IsCfgClient(nClient);

	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		if (!bCfg && !Check_MsgId_In_MB(q->MsgId, q->MailBoxName))
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.

			// Scrivo sul file di log componendo prima il commento relativo.
			STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;

			Msg_Log(q->MsgId,
					nClient,
					"Set_Userfield",
					rmks.Str());

			return m;
		}

		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id        ] = STRING::Set(q->MsgId);
		v[ F_MM_UserField ] = q->Value;

		int r = TB_MM->Update(
				TbFile::M(F_MM_Id), v,
				TbFile::M(F_MM_UserField), v);

		if (r == 0)
			m->Error = GetError("MB038", nClient); // Wrong message identifier.

	}


	// Scrivo sul file di log componendo prima il commento relativo.
	STRING rmks = "MB = " & q->MailBoxName & " Error = " & m->Error;

	Msg_Log(q->MsgId,
			nClient,
			"Set_Userfield",
			rmks.Str());

	return m;
}

GenericMsg * MB_Get_Userfield(c_Moses_MB_Get_Userfield *q, int nClient)
{
	a_Moses_MB_Get_Userfield * m = STNew a_Moses_MB_Get_Userfield;

	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	if ( ! q->Pwd.IsIdentifier(LEN_NAME_PWD, 0 /* bNotNull */) )
	{
		m->Error = GetError("G004", nClient);    // Invalid Password.
		return m;
	}

	int bCfg = G_pServerData->IsCfgClient(nClient);

	if (bCfg || Check_MB_Pwd(q->MailBoxName, q->Pwd, m->Error, nClient))
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_Id ] = STRING::Set(q->MsgId);

		long l = TB_MM->Select(TbFile::M(F_MM_Id), v, v, 0L);

		if (l == -1)
			m->Error = GetError("MB039", nClient); // Wrong message identifier.

		m->Value = v[ F_MM_UserField ];
	}

	return m;
}

GenericMsg * MB_ListAllMsg(c_Moses_MB_ListAllMsg *q, int nClient)
{
	a_Moses_MB_ListAllMsg * m = STNew a_Moses_MB_ListAllMsg;

	// Eseguo il controllo di validita' sul Name della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	// Il Folder NON va testato in quanto comprende il path completo.

	// Eseguo il controllo di validita' su Sender e sul Reciver del MM se NON sono nulli.
	if (q->Cond_Sender.Len())
	{
		if ( ! q->Cond_Sender.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}
	}

	if (q->Cond_Receiver.Len())
	{
		if ( ! q->Cond_Receiver.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}
	}

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_MailboxName ] = q->MailBoxName;
		v[ F_MM_Folder      ] = q->Folder;

		int ffCond = 0;
		v[ F_MM_UserField ] = q->Cond_UserField; if (q->Cond_UserField.Len()) ffCond |= F_MM_UserField;
		v[ F_MM_Sender    ] = q->Cond_Sender;    if (q->Cond_Sender  .Len())  ffCond |= F_MM_Sender;
		v[ F_MM_Receiver  ] = q->Cond_Receiver;  if (q->Cond_Receiver.Len())  ffCond |= F_MM_Receiver;


		long l = 0L;
		
		while ((l = TB_MM->Select(ffCond | TbFile::M(F_MM_MailboxName, F_MM_Folder), v, v, l)) == -1)
		{
			if (q->Cond_Accessed.Len() == 0 ||
					q->Cond_Accessed == "Y" && v[ F_MM_Accessed ].Len() != 0 ||
					q->Cond_Accessed == "N" && v[ F_MM_Accessed ].Len() == 0)
			{
				m->MsgIdList.Append(v[ F_MM_Id ].GetINT32());
				m->DeleteList.Append(v[ F_MM_DelFlag ] == "D");
			}
		}
	}

	return m;
}


GenericMsg * MB_UndeleteMsg(c_Moses_MB_UndeleteMsg *q, int nClient)
{
	a_Moses_MB_UndeleteMsg * m = STNew a_Moses_MB_UndeleteMsg;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> v = TB_MM->GetEmptyRow();
		v[ F_MM_DelFlag ] = "";
		v[ F_MM_Id      ] = STRING::Set(q->MsgId);

		int r = TB_MM->Update(TbFile::M(F_MM_Id), v, TbFile::M(F_MM_DelFlag), v);
		if (r != 1)
			m->Error = GetError("MB040", nClient); // Wrong message identifier.

		m->Recovered = r == 1;
	}

	return m;
}

/*
 * cancella fisicamente tutti i messaggi e i folder della maibox specificata
 * che sono stati cancellati logicamente
 */
STRING MB_Purge(int nClient, const STRING &MailboxName)
{
	STRING Error;

	if (G_pServerData->Check_R(nClient, Error))
	{
		VECT<STRING> mb = TB_MB->GetEmptyRow();
		mb[ F_MB_Name ] = MailboxName;

		/*
		 * Ottengo la password della mail-box
		 */
		long l = TB_MB->Select(TbFile::M(F_MB_Name), mb, mb, 0L);
		if (l == -1)
		{
			Error = GetError("MB041", nClient); // Mailbox not found.
			return Error;
		}

		/*
		 * Cerco tuitti i folder cancellati logicamente e non
		 */
		VECT<STRING> mm = TB_MM->GetEmptyRow();
		mm[ F_MM_Name   ] = MailboxName;
		mm[ F_MM_Folder ] = "";
		mm[ F_MM_Type ]   = "F";

		l = 0L;
		while ((l = TB_MM->Select(TbFile::M(F_MM_Name, F_MM_Folder, F_MM_Type), mm, mm, l)) != -1)
		{
			MB_PurgeFolder(
					nClient,
					MailboxName,
					mb[ F_MB_Pwd ],
					mm[ F_MM_Folder ] & "/" & mm[ F_MM_Name ]);
		}

		Notify::DoNotify(STNew Notify_MB_PHI_PURGE(nClient, MailboxName));
	}

	return Error;
}

GenericMsg * MB_Purge(c_Moses_MB_Purge *q, int nClient)
{
	a_Moses_MB_Purge * m = STNew a_Moses_MB_Purge;

	// Eseguo il controllo di validita' sul Name e sulla Password della Mailbox.
	if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
	{
		m->Error = GetError("G005", nClient);    // Invalid Mailbox Name.
		return m;
	}

	m->Error = MB_Purge(nClient, q->MailBoxName);
	return m;
}


STRING MB_PurgeFolder(int nClient, const STRING &MailBoxName, const STRING &Pwd, const STRING &Folder)
{
	STRING Error;

	int bCfg = G_pServerData->IsCfgClient(nClient);
	if (bCfg || Check_MB_Pwd(MailBoxName, Pwd, Error, nClient))
	{
		/*
		 * Trovo i subfolders e cancello fisicamente tutto quello che sta sotto in maniera ricorsiva
		 */
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = Folder;

			VECT<STRING> o = TB_MM->GetEmptyRow();
			long l = 0L;

			while ((l = TB_MM->Select(TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder), mm, o, l)) != -1)
			{
				Error = MB_PurgeFolder(
						nClient,
						MailBoxName,
						Pwd,
						o[ F_MM_Folder ] & "/" & o[ F_MM_Name ] );
			}
		}

		/*
		 * Cancello fisicamente i messaggi nel folder
		 */
		{
			/*
			 * cancello prima i files
			 */
			{
				VECT<STRING> msg = TB_MM->GetEmptyRow();
				msg[ F_MM_MailboxName ]  = MailBoxName;
				msg[ F_MM_Type ]         = "M";
				msg[ F_MM_Folder ]       = Folder;
				msg[ F_MM_DelFlag ]      = "D";

				long l = 0L;
				while ((l = TB_MM->Select(TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_DelFlag), msg, msg, l)) != -1)
				{
					STRING fileName = GetMsgPath(msg[ F_MM_MailboxName ], msg[ F_MM_Folder ], msg[ F_MM_Id ].GetINT32());
					File::Remove(fileName);
				}
			}


			/*
			 * Cancello le entry in MM
			 */
			{
				VECT<STRING> msg = TB_MM->GetEmptyRow();
				msg[ F_MM_MailboxName ]  = MailBoxName;
				msg[ F_MM_Type ]         = "M";
				msg[ F_MM_Folder ]       = Folder;
				msg[ F_MM_DelFlag ]      = "D";

				TB_MM->Delete(TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_DelFlag), msg);
			}
		}

		/*
		 * cancello fisicamente il folder vero e proprio
		 */
		{
			VECT<STRING> mm = TB_MM->GetEmptyRow();
			mm[ F_MM_MailboxName ]  = MailBoxName;
			mm[ F_MM_Type ]         = "F";
			mm[ F_MM_Folder ]       = GetPathName(Folder);
			mm[ F_MM_Name ]         = GetFileName(Folder);
			mm[ F_MM_DelFlag ]      = "D";

			int r = TB_MM->Delete(TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_Name, F_MM_DelFlag), mm);
			if (r == 0 || r == -1)
				Error = GetError("MB042", nClient); // Cannot delete folder

			STRING FolderPath = GetFolderPath(MailBoxName, Folder);

			/*
			 * La cancellazione del Folder puo` anche andare male
			 * in quanto e` possibile che ci siano
			 * messaggi o altri subfolder non cancellati (siamo nella purge!!)
			 * ossia non in stato "D"
			 */
			RmDir(FolderPath, 0 /* Non ricorsivo */);
		}

		/*
		 * Notifico la cancellazione fisica del folder
		 */
		Notify::DoNotify(STNew Notify_MB_FOLDER_PHI_DEL(nClient, MailBoxName, Folder));
	}

	return Error;
}

////////////////////////////////////////////////////////////////////////


/*
 * aggiungo la mailbox del nuovo utente se viene specificata in DefaultMBox
 * e se questa non esiste gia`
 */
static STRING Do_Notify_USER_ADD(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";

	Notify_USER_ADD *p_USER_ADD = (Notify_USER_ADD *)p;

	STRING Error;

	if (p_USER_ADD->DefaultMBox.Len() > 0)
	{
		if (Check_MB_Name(p_USER_ADD->DefaultMBox) == 0)
		{
			if (G_pServerData->Check_R(p_USER_ADD->nClient, Error))
				Error = MB_CreateMailbox(
						p_USER_ADD->nClient,
						p_USER_ADD->DefaultMBox,
						p_USER_ADD->User,          // Owner
						p_USER_ADD->User,          // Pwd
						"");                       // Descr
		}
	}
	return Error;
}

static Notify Notify_UserAdd(Notify_USER_ADD::Id, Do_Notify_USER_ADD);


////////////////////////////////////////////////////////////////////////
int InitMTD()
{
	// Cerco tutti i msg sotto system/out con il campo Dispatched NON valorizzato.
	
	VECT<STRING> s = TB_MM->GetEmptyRow();

	s[ F_MM_MailboxName ] = "system";
	s[ F_MM_Type        ] = "M";
	s[ F_MM_Folder      ] = "out";
	s[ F_MM_Dispatched  ] = "";

	int fMask = TbFile::M(F_MM_MailboxName, F_MM_Type, F_MM_Folder, F_MM_Dispatched);

	long l = 0L;
	while ((l = TB_MM->Select(fMask,s, s, l)) != -1L)
	{
		cerr << "ID      :" << s [ F_MM_Id       ] << endl;
		cerr << "Sender  :" << s [ F_MM_Sender   ] << endl;
		cerr << "Receiver:" << s [ F_MM_Receiver ] << endl;
		cerr << "Subject :" << s [ F_MM_Subject  ] << endl;
		
		STRING out_MailBoxType, out_MailBoxAddress, out_Subject;
		STRING e = ART_OutAddress(
				-1,                   // nClient
				s[ F_MM_Receiver ],   // User
				"",                   // MailBoxType richiesta
				out_MailBoxType,      // MailBoxType trovata
				out_MailBoxAddress,   // Indirizzo (non usato)
				out_Subject);         // Soggetto (non usato)

		if (e.Len())
			clog << GetError("MB044") << endl;   // Cannot find a MailType.
		else
		{
			Notify::DoNotify(STNew Notify_MB_MSG_FOR_MTD(
					-1,	
					out_MailBoxType,
					s [ F_MM_Id       ].GetINT32(),
					s [ F_MM_Sender   ],
					s [ F_MM_Receiver ],
					s [ F_MM_Subject  ]));
		}
	}
	
	return 1;
}

#endif
