#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include <server.h>
#include <User.h>
#include <MS.h>
#include <ERROR.h>

#include "m_Moses_ART_Add.h"
#include "m_Moses_ART_Delete.h"
#include "m_Moses_ART_Modify.h"
#include "m_Moses_ART_InAddress.h"
#include "m_Moses_ART_List.h"
#include "m_Moses_ART_ListAddresses.h"
#include "m_Moses_ART_ListUsers.h"
#include "m_Moses_ART_OutAddress.h"

#include "Notify.h"
 
STRING ART_Add(int nClient, STRING User, INT16 bInternal,
		       STRING MailBoxType, STRING MailBoxAddress, STRING Subject)
{
	a_Moses_ART_Add * m = STNew a_Moses_ART_Add;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' dell'User e del Tipo di Mailbox.
		if ( ! User.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);	// Invalid User Name.
			return m->Error;
		}

		if ( ! MailBoxType.IsIdentifier(LEN_NAME_MBTYPE) )
		{
			m->Error = GetError("G006", nClient);	// Invalid Mailbox Type.
			return m->Error;
		}

		if (!User_Exists(User))
		{
			m->Error = GetError("ART002", nClient); // User Name not present in USER table.
			return m->Error;
		}

		if (!MS_Exists(MailBoxType))
		{
			m->Error = GetError("ART003", nClient); // Mail Box Type not present in MS table.
			return m->Error;
		}

		VECT<STRING> i = TB_ART->GetEmptyRow();
		i[ F_ART_User           ] = User;
		i[ F_ART_MailBoxType    ] = MailBoxType;
		i[ F_ART_MailBoxAddress ] = MailBoxAddress;
		i[ F_ART_Subject        ] = Subject;
		i[ F_ART_bInternal      ] = bInternal ? "1" : "0";

		int r = TB_ART->Insert(i);
		if (r == 0)
			m->Error = GetError("ART001", nClient); // User already present in ART table.
	}

	return m->Error;
}


GenericMsg * ART_Add(c_Moses_ART_Add *q, int nClient)
{
	a_Moses_ART_Add * m = STNew a_Moses_ART_Add;
	m->Error = ART_Add(
			nClient,
			q->User,
			q->bInternal,
			q->MailBoxType,
			q->MailBoxAddress,
			q->Subject);
	return m;
}


//////////////////////////////////////////////////////////////////////////////
STRING ART_Modify(int nClient, STRING User, INT16 bInternal,
		          STRING MailBoxType, STRING MailBoxAddress, STRING Subject)
{
	a_Moses_ART_Modify * m = STNew a_Moses_ART_Modify;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' dell'User e del Tipo di Mailbox.
		if ( ! User.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);	// Invalid User Name.
			return m->Error;
		}

		if ( ! MailBoxType.IsIdentifier(LEN_NAME_MBTYPE) )
		{
			m->Error = GetError("G006", nClient);	// Invalid Mailbox Type.
			return m->Error;
		}
		
		VECT<STRING> search = TB_ART->GetEmptyRow();
		VECT<STRING> inRow  = TB_ART->GetEmptyRow();
		search[ F_ART_User           ] = User;
		search[ F_ART_MailBoxType    ] = MailBoxType;
		STRING io;
		if (bInternal) io = "1"; else io = "0";
		search[ F_ART_bInternal     ] = io;

		inRow[ F_ART_User           ] = User;
		inRow[ F_ART_bInternal      ] = io;
		inRow[ F_ART_MailBoxType    ] = MailBoxType;
		inRow[ F_ART_MailBoxAddress ] = MailBoxAddress;
		inRow[ F_ART_Subject        ] = Subject;	

		int r = TB_ART->Update(TbFile::M(F_ART_User, F_ART_bInternal, F_ART_MailBoxType),
							   search,
							   TbFile::M(F_ART_User, F_ART_bInternal, F_ART_MailBoxType, F_ART_MailBoxAddress, F_ART_Subject),
							   inRow);
		if (r == 0)
			m->Error = GetError("ART004", nClient); // Row Not present in ART table.

		if (r == -1)
			m->Error = GetError("ART005", nClient); // Key duplicate in ART table.

	}

	return m->Error;
}


GenericMsg * ART_Modify(c_Moses_ART_Modify *q, int nClient)
{
	a_Moses_ART_Modify * m = STNew a_Moses_ART_Modify;

	m->Error = ART_Modify(nClient,
						  q->User,
						  q->bInternal,
						  q->MailBoxType,
						  q->MailBoxAddress,
						  q->Subject);

	return m;
}



//////////////////////////////////////////////////////////////////////////////
STRING ART_OutAddress(int nClient, 
		STRING User,
		STRING MailBoxType, 
		STRING &out_MailBoxType, 
		STRING &out_MailBoxAddress, 
		STRING &out_Subject)
{
	a_Moses_ART_OutAddress * m = STNew a_Moses_ART_OutAddress;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' dell'User. 
		if ( ! User.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);	// Invalid User Name.
			return m->Error;
		}

		if (MailBoxType.Len() == 0)
		{
			VECT<STRING> search = TB_ART->GetEmptyRow();
			VECT<STRING> out    = TB_ART->GetEmptyRow();
			search[ F_ART_User ] = User;

			// #ALE# #TBD# Per ora NON e' gestito l'Index.
			// restituisce il primo record che trova con User definito.

			long r = TB_ART->Select(TbFile::M(F_ART_User),
								   search,
								   out,
								   0L);

			out_MailBoxType		= out[ F_ART_MailBoxType ];
			out_MailBoxAddress	= out[ F_ART_MailBoxAddress];
			out_Subject			= out[ F_ART_Subject];

			if (r == -1L)
				m->Error = GetError("ART006", nClient); // User Not present in ART table.
		}
		else
		{
			// Controllo la validita' della MailboxType.
			if ( ! MailBoxType.IsIdentifier(LEN_NAME_MBTYPE) )
			{
				m->Error = GetError("G006", nClient);	// Invalid Mailbox Type.
				return m->Error;
			}

			VECT<STRING> search = TB_ART->GetEmptyRow();
			VECT<STRING> out    = TB_ART->GetEmptyRow();
			search[ F_ART_User        ] = User;
			search[ F_ART_MailBoxType ] = MailBoxType;

			// #ALE# #TBD# Per ora NON e' gestito l'Index.
			// restituisce il primo record che trova con User definito.

			long r = TB_ART->Select(TbFile::M(F_ART_User, F_ART_MailBoxType),
								   search,
								   out,
								   0L);

			out_MailBoxType		= out[ F_ART_MailBoxType ];
			out_MailBoxAddress	= out[ F_ART_MailBoxAddress];
			out_Subject			= out[ F_ART_Subject];

			if (r == -1L)
				m->Error = GetError("ART007", nClient); // User and MailBoxType Not present in ART table.
				
		}
	}			

	return m->Error;
}


GenericMsg * ART_OutAddress(c_Moses_ART_OutAddress *q, int nClient)
{
	a_Moses_ART_OutAddress * m = STNew a_Moses_ART_OutAddress;

	m->Error = ART_OutAddress(nClient,
							  q->User,
							  q->MailBoxType,
							  m->MailBoxType,
							  m->MailBoxAddress,
							  m->Subject);

	return m;
}


//////////////////////////////////////////////////////////////////////////////
STRING ART_InAddress (int nClient, 
					  STRING MailBoxType, 
		              STRING MailBoxAddress, 
		              STRING Subject, 
					  STRING &out_User)
{
	a_Moses_ART_InAddress * m = STNew a_Moses_ART_InAddress;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' della MailboxType.
		if ( ! MailBoxType.IsIdentifier(LEN_NAME_MBTYPE) )
		{
			m->Error = GetError("G006", nClient);	// Invalid Mailbox Type.
			return m->Error;
		}

		VECT<STRING> search = TB_ART->GetEmptyRow();
		VECT<STRING> out    = TB_ART->GetEmptyRow();

		search[ F_ART_MailBoxType    ] = MailBoxType;
		search[ F_ART_MailBoxAddress ] = MailBoxAddress;

		/*  #ALE# #TBD# Per il momento NON e' stato inserito nella select.
		 search[ F_ART_Subject       ] = Subject;
		 */

		long r = TB_ART->Select(TbFile::M(F_ART_MailBoxType, F_ART_MailBoxAddress),
								search,
								out,
								0L);

		out_User		= out[ F_ART_User ];

		if (r == -1)
			m->Error = GetError("ART008", nClient); // MailBoxType and MailBoxAddress Not present in ART table.

	}			

	return m->Error;
}


GenericMsg * ART_InAddress(c_Moses_ART_InAddress *q, int nClient)
{
	a_Moses_ART_InAddress * m = STNew a_Moses_ART_InAddress;

	m->Error = ART_InAddress (nClient,
							  q->MailBoxType,
							  q->MailBoxAddress,
							  q->Subject,
							  m->User);

	return m;
}



//////////////////////////////////////////////////////////////////////////////
STRING ART_List(int     nClient, 
				int     Index,
				STRING &out_UserName,
				INT16  &out_bInternal,
				STRING &out_MailBoxType,
				STRING &out_MailBoxAddress,
				STRING &out_SubjectAdd,
				INT16  &out_Valid)
{
	a_Moses_ART_List * m = STNew a_Moses_ART_List;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		long l = 0L;
		int i = 0;

		VECT<STRING> out = TB_ART->GetEmptyRow();

		while ((l = TB_ART->Select(out, l)) != -1L)
		{
			if (i == Index)
			{
				out_UserName       = out[ F_ART_User ];
				out_MailBoxType    = out[ F_ART_MailBoxType ];
				out_MailBoxAddress = out[ F_ART_MailBoxAddress ];
				out_SubjectAdd     = out[ F_ART_Subject ];
				out_bInternal      = (out[ F_ART_bInternal ] == "1");
				out_Valid          = 1;
				return m->Error;
			}
			i++;
		}
		out_Valid = 0;

	}			
	return m->Error;
}


GenericMsg * ART_List(c_Moses_ART_List *q, int nClient)
{
	a_Moses_ART_List * m = STNew a_Moses_ART_List;

	m->Error = ART_List (nClient,
						 q->Index,
						 m->User,
						 m->bInternal,
						 m->MailBoxType,
						 m->MailBoxAddress,
						 m->Subject,
						 m->Valid);

	return m;
}

//////////////////////////////////////////////////////////////////////////////
STRING ART_ListUsers(int     nClient, 
					 STRING  MailBoxType,
					 INT16   bInternal,
					 VECT<STRING> &out_UsersList)
{
	a_Moses_ART_ListUsers * m = STNew a_Moses_ART_ListUsers;

	if (G_pServerData->Check_R(nClient, m->Error))
	{

			VECT<STRING> search = TB_ART->GetEmptyRow();
			VECT<STRING> out    = TB_ART->GetEmptyRow();
			long l = 0L;
			if (bInternal)
				search[ F_ART_bInternal ] = "1";
			else
				search[ F_ART_bInternal ] = "0";

			search[ F_ART_MailBoxType ] = MailBoxType;

			if (MailBoxType != "")
			{
				// Controllo la validita' della MailboxType.
				if ( ! MailBoxType.IsIdentifier(LEN_NAME_MBTYPE) )
				{
					m->Error = GetError("G006", nClient);	// Invalid Mailbox Type.
					return m->Error;
				}
				
				if (!MS_Exists(MailBoxType))
					m->Error = GetError("ART009", nClient); // Unknown Mail System type.
				else
				{
					while ((l = TB_ART->Select(TbFile::M(F_ART_MailBoxType, F_ART_bInternal), search, out, l))  != -1 )
						out_UsersList.Append(out[F_ART_User]);
				}
			}
			else
			{
				while ((l = TB_ART->Select(TbFile::M(F_ART_bInternal), search, out, l))  != -1 )
					out_UsersList.Append(out[F_ART_User]);
			}

			// if (out_UsersList.Size() == 0)
			// m->Error = GetError("ART010", nClient); // No Users in ART table for the given Mailbox type.
	}			

	return m->Error;
}


GenericMsg * ART_ListUsers(c_Moses_ART_ListUsers *q, int nClient)
{
	a_Moses_ART_ListUsers * m = STNew a_Moses_ART_ListUsers;

	m->Error = ART_ListUsers(nClient,
							 q->MailBoxType,
							 q->bInternal,
							 m->UsersList);

	return m;
}


//////////////////////////////////////////////////////////////////////////////
STRING ART_ListAddresses(int     nClient, 
						 STRING  MailBoxType,
						 INT16   bInternal,
						 VECT<STRING> &out_ListAddresses)
{
// #TBD dovrebbe ritornare una lista di indirizzi distinti

	a_Moses_ART_ListAddresses * m = STNew a_Moses_ART_ListAddresses;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
			VECT<STRING> search = TB_ART->GetEmptyRow();
			VECT<STRING> out    = TB_ART->GetEmptyRow();
			long l = 0L;
			search[ F_ART_MailBoxType ] = MailBoxType;
			if (bInternal)
				search[ F_ART_bInternal ] = "1";
			else
				search[ F_ART_bInternal ] = "0";

			if (MailBoxType != "")
			{
				// Controllo la validita' della MailboxType.
				if ( ! MailBoxType.IsIdentifier(LEN_NAME_MBTYPE) )
				{
					m->Error = GetError("G006", nClient);	// Invalid Mailbox Type.
					return m->Error;
				}
				
				if (!MS_Exists(MailBoxType))
					m->Error = GetError("ART011", nClient); // Unknown Mail System type.
				else
				while ((l = TB_ART->Select(TbFile::M(F_ART_MailBoxType, F_ART_bInternal), search, out, l))  != -1 )
					out_ListAddresses.Append(out[F_ART_MailBoxAddress]);
			}
			else
			{
				while ((l = TB_ART->Select(TbFile::M(F_ART_bInternal), search, out, l))  != -1 )
					out_ListAddresses.Append(out[F_ART_MailBoxAddress]);
			}

			// if (out_ListAddresses.Size() == 0)
			// m->Error = GetError("ART012", nClient); // No Mail Addresses in ART table for the given Mailbox Type.
	}			

	return m->Error;
}


GenericMsg * ART_ListAddresses(c_Moses_ART_ListAddresses *q, int nClient)
{
	a_Moses_ART_ListAddresses * m = STNew a_Moses_ART_ListAddresses;

	m->Error = ART_ListAddresses(nClient,
								 q->MailBoxType,
								 q->bInternal,
								 m->MailAddresses);

	return m;
}

///////////////////////////////////////////////////////////////////////////
STRING ART_Delete(int nClient, STRING User, INT16 bInternal,
		          STRING MailBoxType)
{
	a_Moses_ART_Delete * m = STNew a_Moses_ART_Delete;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' dell'User e del Tipo di Mailbox.
		if ( ! User.IsIdentifier(LEN_NAME_USER) )
		{
			m->Error = GetError("G003", nClient);	// Invalid User Name.
			return m->Error;
		}

		if ( ! MailBoxType.IsIdentifier(LEN_NAME_MBTYPE) )
		{
			m->Error = GetError("G006", nClient);	// Invalid Mailbox Type.
			return m->Error;
		}
		
		VECT<STRING> d = TB_ART->GetEmptyRow();
		d[ F_ART_User           ] = User;
		d[ F_ART_MailBoxType    ] = MailBoxType;
		STRING io;
		if (bInternal) io = "1"; else io = "0";
		d[ F_ART_bInternal          ] = io;

		int r = TB_ART->Delete(TbFile::M(F_ART_MailBoxType, F_ART_MailBoxType, F_ART_bInternal),
							    d);
		if (r == 0)
			m->Error = GetError("ART013", nClient); // Key not  present in ART table for deleting.

	}

	return m->Error;
}


GenericMsg * ART_Delete(c_Moses_ART_Delete *q, int nClient)
{
	a_Moses_ART_Delete * m = STNew a_Moses_ART_Delete;

	m->Error = ART_Delete(nClient,
						  q->User,
						  q->bInternal,
						  q->MailBoxType);

	return m;
}


//////////////////////////////////////////////////////////////////////////////

/* 
 * Gestione delle Notifiche
 */

static STRING Do_Notify_USER_PHI_DEL(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";

	Notify_USER_PHI_DEL *p_USER_PHI_DEL = (Notify_USER_PHI_DEL *)p;

	STRING Error;

	if (G_pServerData->Check_R(p_USER_PHI_DEL->nClient, Error))
	{
		VECT<STRING> d = TB_ART->GetEmptyRow();
		d[ F_ART_User   ] = p_USER_PHI_DEL->User;
		int r = TB_ART->Delete(TbFile::M(F_ART_User), d);
		if (r == 0)
			Error = GetError("ART014", p_USER_PHI_DEL->nClient); // User Name not present in USER table.
	}

	return Error;
}

static Notify Notify_UserDel(Notify_USER_PHI_DEL::Id, Do_Notify_USER_PHI_DEL);

///////////////////////////////////////////////////////////////////////////////
static STRING Do_Notify_DL_PHI_DEL(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";

	Notify_DL_PHI_DEL *p_DL_PHI_DEL = (Notify_DL_PHI_DEL *)p;

	STRING Error;

	if (G_pServerData->Check_R(p_DL_PHI_DEL->nClient, Error))
	{
		VECT<STRING> d = TB_ART->GetEmptyRow();
		d[ F_ART_User   ] = p_DL_PHI_DEL->DLName;
		int r = TB_ART->Delete(TbFile::M(F_ART_User), d);
		if (r == 0)
			Error = GetError("ART015", p_DL_PHI_DEL->nClient); // User Name not present in USER table.
	}

	return Error;
}

static Notify Notify_DL_PHI_DEL(Notify_DL_PHI_DEL::Id, Do_Notify_DL_PHI_DEL);


#endif
