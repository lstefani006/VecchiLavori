#ifndef __Work_h__
#define __Work_h__

#include <st_dbnew.h>

#include <moses.h>


GenericMsg * Work_Begin        (class c_Moses_Work_Begin        *q, int nClient);
GenericMsg * Work_End          (class c_Moses_Work_End          *q, int nClient);
GenericMsg * Work_ListLanguage (class c_Moses_Work_ListLanguage *q, int nClient);
GenericMsg * Work_SetLanguage  (class c_Moses_Work_SetLanguage  *q, int nClient);
GenericMsg * Work_GetLanguage  (class c_Moses_Work_GetLanguage  *q, int nClient);
GenericMsg * Work_ListClient   (class c_Moses_Work_ListClient   *q, int nClient);
GenericMsg * Work_SetSession   (class c_Moses_Work_SetSession   *q, int nClient);


#endif
