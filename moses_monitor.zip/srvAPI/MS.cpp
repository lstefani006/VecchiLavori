#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "MS.h"
#include "Notify.h"

#include <m_Moses_MS_Add.h>
#include <m_Moses_MS_Delete.h>
#include <m_Moses_MS_List.h>

int MS_Exists (const STRING &MSType)
{
	VECT<STRING> o;	
	long l = 0L;

	l = TB_MS->Select(F_MS_MailBoxType, MSType, o, l);
	return l != -1 ;
}

GenericMsg * MS_Add(c_Moses_MS_Add *q, int nClient)
{
	a_Moses_MS_Add *m = STNew a_Moses_MS_Add;

	// Controllo la validita' del Tipo di Mailbox.
	if ( ! q->MSType.IsIdentifier(LEN_NAME_MBTYPE) )
	{
		m->Error = GetError("G006", nClient);    // Invalid Mailbox Type.
		return m;
	}

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> d = TB_MS->GetEmptyRow();
		d[ F_MS_MailBoxType ] 		= q->MSType;
		d[ F_MS_MailBoxTypeDescr]	= q->MSDescr;
		int r = TB_MS->Insert(d);
		if (r == 0)
			m->Error = GetError("MS001", nClient); // Mail System Type already present.
	}
	return m;
}

GenericMsg * MS_Delete(c_Moses_MS_Delete *q, int nClient)
{
	a_Moses_MS_Delete *m = STNew a_Moses_MS_Delete;

	// Controllo la validita' del Tipo di Mailbox.
	if ( ! q->MSType.IsIdentifier(LEN_NAME_MBTYPE) )
	{
		m->Error = GetError("G006", nClient);    // Invalid Mailbox Type.
		return m;
	}

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		int r = TB_MS->Delete(F_MS_MailBoxType, q->MSType);
		if (r == 0)
			m->Error = GetError("MS002", nClient); // Unknown Mail System Type.
	}
	return m;
}

GenericMsg * MS_List(c_Moses_MS_List *q, int nClient)
{
	a_Moses_MS_List *m = STNew a_Moses_MS_List;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> out_Name_Pwd_Descr;

		long l = 0;
		while ((l = TB_MS->Select(out_Name_Pwd_Descr, l)) != -1)
		{
			m->MSTypeList.Append (out_Name_Pwd_Descr[F_MS_MailBoxType]);
			m->MSDescrList.Append(out_Name_Pwd_Descr[F_MS_MailBoxTypeDescr]);
		}

		// non c'e` mai errore
	}

	return m;
}


////////////////////////////////////////////////////////////////////////

#endif
