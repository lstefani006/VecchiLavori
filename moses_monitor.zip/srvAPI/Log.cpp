#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <string.h>
#include <tbFile.h>
#include <m_Moses_Log.h>
#include <server.h>
#include <ERROR.h>
#include <MB.h>
#include <MsgLog.h>

#include "Log.h"

GenericMsg * Log(c_Moses_Log *q, int nClient)
{
	a_Moses_Log *l = STNew a_Moses_Log;
	char *filename = STNew char[strlen(G_pServerData->m_CfgPath.Str()) + 32];
	sprintf(filename, "%s/%s", G_pServerData->m_CfgPath.Str(), "Log");

	FILE *f = fopen(filename, "a+");	
	fprintf(f, "%s\n", q->LogMsg.Str());
	fclose(f);
		
	STDelete []filename;
	return l;
}

#endif
