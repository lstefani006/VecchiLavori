#include <st_dbnew.h>

#ifndef __MSGLOG_h__
#define __MSGLOG_h__

#include <moses.h>


void Msg_Log(INT32       IdMsg,
		     int         nClient,
			 const char *azione,
			 const char *rmks);

void Msg_Log(int         nClient,
			 const char *azione,
			 const char *rmks);

#endif
