#include <st_dbnew.h>
#ifdef MOSES_SERVER

#ifdef _WIN32
	#include <strstrea.h>
#else
	#include <strstream.h>
#endif

#include <server.h>
#include <mdir.h>
#include <mtime.h>
#include <ERROR.h>

#include "FM.h"

#include "m_Moses_FM_ListFile.h"
#include "m_Moses_FM_GetFile.h"
#include "m_Moses_FM_PutFile.h"


GenericMsg * FM_ListFile(c_Moses_FM_ListFile *q, int nClient)
{
	a_Moses_FM_ListFile * m = STNew a_Moses_FM_ListFile;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		mDirectory dd;
		m->Error = dd.Open(q->PathDir.Str());
		if (m->Error.Len())
			return m;

		for (;;)
		{
			STRING FileName;
			INT32  Size;
			STRING Date;
			INT16  bDirectory;

			int r = dd.GetNext(FileName, Size, Date, bDirectory);

			if (r == 0)
				break;

			m->NameFileList.Append(FileName);
			m->TypeFileList.Append(bDirectory ? "D" : "F");
			m->DateFileList.Append(Date);
			m->DimFileList.Append(Size);
		}
	}

	return m;
}

GenericMsg * FM_GetFile(c_Moses_FM_GetFile *q, int nClient)
{
	a_Moses_FM_GetFile * m = STNew a_Moses_FM_GetFile;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		STRING e = File::Read(q->StartPathNameFile, m->BodyFile);

		if (e.Len())
			m->Error = GetError("FM001", nClient) & e;
	}

	return m;
}

GenericMsg * FM_PutFile(c_Moses_FM_PutFile *q, int nClient)
{
	a_Moses_FM_PutFile * m = STNew a_Moses_FM_PutFile;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		STRING e = File::Write(q->FinalPathNameFile, q->BodyFile);

		if (e.Len())
			m->Error = GetError("FM002", nClient) & e;
	}

	return m;
}

#endif
