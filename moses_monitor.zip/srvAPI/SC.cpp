#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <string.h>

#include <tbFile.h>
#include <server.h>
#include <mprocess.h>

#include "SC.h"
#include "ERROR.h"
#include "Notify.h"

#include <m_Moses_Scheduler_Add.h>
#include <m_Moses_Scheduler_Delete.h>
#include <m_Moses_Scheduler_List.h>

GenericMsg * Scheduler_Add(c_Moses_Scheduler_Add *q, int nClient)
{
	a_Moses_Scheduler_Add *m = STNew a_Moses_Scheduler_Add;

	// Eseguo un controllo di validita' sulla stringa che descrive il tempo di
	// schedulazione che puo' essere composta di solo numeri o da asterischi.
	if ( ! IsOkWhenFormat(q->When) )
	{
		m->Error = GetError("SC004", nClient); // Invalid Format for String Describing the Time of Schedulation.
		return m;
	}

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Determino il Nuovo Index.
		INT16 aCurrIndex = -1;
		VECT<STRING> outRow = TB_SC->GetEmptyRow();
		
		long l = 0;
		while ((l = TB_SC->Select(outRow, l)) != -1)
		{
			aCurrIndex = outRow[F_SC_Index].GetINT16();
		}

		++aCurrIndex;

		VECT<STRING> d = TB_SC->GetEmptyRow();
		d[ F_SC_Index ] = STRING::Set(aCurrIndex);
		d[ F_SC_Time  ] = q->When;
		d[ F_SC_Action]	= q->Action;

		int r = TB_SC->Insert(d);
		if (r == 0)
			m->Error = GetError("SC001", nClient); // Scheduler already present.
	}
	return m;
}

///////////////////////////////////////////////////////////////////////////////
GenericMsg * Scheduler_Delete(c_Moses_Scheduler_Delete *q, int nClient)
{
	a_Moses_Scheduler_Delete *m = STNew a_Moses_Scheduler_Delete;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> d = TB_SC->GetEmptyRow();
		d[ F_SC_Index ] = STRING::Set(q->Index);

		// cerr<<"INDEX:"<<d[ F_SC_Index ]<<endl;

		int r = TB_SC->Delete(TbFile::M(F_SC_Index), d);
		if (r == 0)
			m->Error = GetError("SC002", nClient); // Unknown Scheduler.
	}

	return m;
}

///////////////////////////////////////////////////////////////////////////////
GenericMsg * Scheduler_List(c_Moses_Scheduler_List *q, int nClient)
{
	a_Moses_Scheduler_List *m = STNew a_Moses_Scheduler_List;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		VECT<STRING> out;

		long l = 0;
		while ((l = TB_SC->Select(out, l)) != -1)
		{
			INT16 aIndex = out[ F_SC_Index ].GetINT16();
			m->IndexList.Append (aIndex);
			m->WhenList.Append  (out[ F_SC_Time   ]);
			m->ActionList.Append(out[ F_SC_Action ]);
		}
	}

	return m;
}

///////////////////////////////////////////////////////////////////////////////
int MatchCurrentTime(STRING currentTime,
					 STRING currentWeekDay)
{
	char * currYear    = STNew char[30];
	char * currMonth   = STNew char[30];
	char * currDay     = STNew char[30];
	char * currWeekDay = STNew char[30];
	char * currHour    = STNew char[30];
	char * currMin     = STNew char[30];
	char * currSec     = STNew char[30];

	int i = sscanf (currentTime.Str(), 
			"%4[ -z]%2[ -z]%2[ -z]%2[ -z]%2[ -z]%2[ -z]", 
			currYear, currMonth, currDay, currHour, currMin, currSec);

	if (i != 6)
	{
		clog<<GetError("SC005")<<endl;	// Error in sscanf for Current Time.
		return 0;
	}
		
	STRING S_currYear  (currYear);
	STRING S_currMonth (currMonth);
	STRING S_currDay   (currDay);
	STRING S_currHour  (currHour);
	STRING S_currMin   (currMin);
	STRING S_currSec   (currSec);
	
	STDelete currYear;
	STDelete currMonth;
	STDelete currDay;
	STDelete currWeekDay;
	STDelete currHour;
	STDelete currMin;
	STDelete currSec;

	VECT<STRING> out;

	long l = 0;
	while ((l = TB_SC->Select(out, l)) != -1)
	{
		STRING timeSC = out[F_SC_Time];

		char * schedYear    = STNew char[30];
		char * schedMonth   = STNew char[30];
		char * schedWeekDay = STNew char[30];
		char * schedDay     = STNew char[30];
		char * schedHour    = STNew char[30];
		char * schedMin     = STNew char[30];

		int i = sscanf (timeSC.Str(), "%s%s%s%s%s%s", 
			schedHour, schedMin, schedWeekDay, schedDay, schedMonth, schedYear);

		if (i != 6)
		{
		    clog<<GetError("SC006")<<endl;	// Error in sscanf for Schedular Time.
			return 0;
		}

		int check = 0;

		STRING S_YearDefault    ("*");
		STRING S_MonthDefault   ("*");
		STRING S_WeekDayDefault ("*");
		STRING S_DayDefault     ("*");
		STRING S_HourDefault    ("*");
		STRING S_MinDefault     ("*");
		
		STRING S_schedYear      (schedYear);
		STRING S_schedMonth     (schedMonth);
		STRING S_schedWeekDay   (schedWeekDay);
		STRING S_schedDay       (schedDay);
		STRING S_schedHour      (schedHour);
		STRING S_schedMin       (schedMin);
		
		// Controllo sull'Anno.
		if (S_schedYear != S_YearDefault)
		{
			if (S_schedYear != S_currYear)
				check++;
		}
		
		// Controllo sul Mese.
		if ( (check == 0) && (S_schedMonth != S_MonthDefault) )
		{
			if ( S_schedMonth != S_currMonth )
				check++;
		}
			
		// Controllo sul Giorno della Settimana.
		if ( (check == 0) && (S_schedWeekDay != S_WeekDayDefault) )
		{
	
			if ( S_schedWeekDay != currentWeekDay)
				check++;
		}
		
		// Controllo sul Numero del Giorno del Mese.
		if ( (check == 0) && (S_schedDay != S_DayDefault) )
		{
			if ( S_schedDay != S_currDay )
				check++;
		}
			
		// Controllo sull'Ora.
		if ( (check == 0) && (S_schedHour != S_HourDefault) )
		{
			if ( S_schedHour != S_currHour )
				check++;
		}
			
		// Controllo sui Minuti.
		if ( (check == 0) && ( S_schedMin != S_MinDefault) )
		{
			if ( S_schedMin != S_currMin )
				check++;
		}

		STDelete schedYear;
		STDelete schedMonth;
		STDelete schedWeekDay;
		STDelete schedDay;
		STDelete schedHour;
		STDelete schedMin;

		if (check == 0)
		{
			if ( RunOrNotify(out[F_SC_Action] ) )
				return 1;
			else
				return 0;
		}
	}

	return 1;
}

/////////////////////////////////////////////////////////////////////////////////
int LanciaScriptIniziale()
{
	STRING initialTime = "0 0 0 0 0 0";
	
	VECT<STRING> search = TB_SC->GetEmptyRow();
	VECT<STRING> out    = TB_SC->GetEmptyRow();

	search[ F_SC_Time ] = initialTime;

	int r = TB_SC->Select(TbFile::M(F_SC_Time),
						  search,
						  out,
						  0L);

	if (r != -1)
	{
		if (RunOrNotify(out[F_SC_Action])) 
			return 1;
		else
			return 0;
	}
	else
		clog<<"Nessun Script Iniziale"<<endl;
	
	return 1;
}
/////////////////////////////////////////////////////////////////////////////////
int IsOkWhenFormat(STRING fieldWhen)
{
	if (fieldWhen.Len() > LEN_FIELD_SC_WHEN)
		return 0;

	char *ch = fieldWhen.Str();

	for (int i=0; i<fieldWhen.Len(); i++)
	{
		if ( (ch[i] >= '0') && (ch[i] <= '9') ||      // 0...9
			 (ch[i] == '*')                   ||      // '*'
			 (ch[i] == '-')                   ||      // '-'
			 (ch[i] == ',')                   ||      // ','
			 (ch[i] == ' '))						  // ' '
		{
		}
		else
			return 0;
	}

	return 1;
}

////////////////////////////////////////////////////////////////////////////////

static char S_MTDKey[] = "##MTD";

int RunOrNotify(STRING action)
{
	// Testo se l'Action e' del tipo "##MTD<tipo MTD>" in caso affermativo
	// invece di lanciare l'azione scateno l'evento MTD mediante
	// una notifica.

	char *actionMTD = action.Str();

	if (strncmp(actionMTD, S_MTDKey, strlen(S_MTDKey)) == 0)
	{

		// devo eseguire una notifica MTD.
		STRING actionMTDstr(&actionMTD[strlen(S_MTDKey)]);

		Notify::DoNotify(STNew Notify_MB_MSG_FOR_MTD(
				-1,              // bClient
				actionMTDstr,    // MailBoxType
				0,               // MsgId
				"",              // Sender
				"",              // Destination
				""));            // Subject

		return 1;
	}
	else
	{
		action = G_pServerData->GetFilledAction(action);
		mProcess aProcess;
		int err = aProcess.Run(action.Str() /* Ok con GetFilledAction */);

		if (err != 1)
		{
			clog<< GetError("MON001")
				<< " " << action.Str()
				<< endl; // Run Process Failed.
			return 0;
		}
		else
			return 1;
	}
}

void Init_EventForMTD(const STRING &When, const STRING &MtdType)
{
	c_Moses_Scheduler_Add q;
	q.When   = When;
	q.Action = STRING(S_MTDKey) & MtdType;

	VECT<STRING> d = TB_SC->GetEmptyRow();
	d[ F_SC_Action ] = q.Action;

	long l = TB_SC->Select(TbFile::M(F_SC_Action), d, d, 0L);
	if (l != -1L)
		return;

	GenericMsg * a = Scheduler_Add(&q, -1);
	STDelete a;
}

void Init_StartUpScript(const STRING &Action)
{
	c_Moses_Scheduler_Add q;
	q.When   = "0 0 0 0 0 0";
	q.Action = Action;

	VECT<STRING> d = TB_SC->GetEmptyRow();
	d[ F_SC_Time ] = q.When;

	long l = TB_SC->Select(TbFile::M(F_SC_Time), d, d, 0L);
	if (l != -1L)
		return;

	GenericMsg * a = Scheduler_Add(&q, -1);
	STDelete a;
}



#endif
