#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <stdlib.h>

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "EH.h"
#include "Notify.h"

#include <m_Moses_EH_Add.h>
#include <m_Moses_EH_Count.h>
#include <m_Moses_EH_Delete.h>
#include <m_Moses_EH_List.h>

#include "mprocess.h"

/*
 * Gestione della tabella ITG
 *
 * La tabella ha delle entry con chiave Mailbox,Folder,Index
 *
 * Per lo stesso Mailbox/Folder se esistono dei record questi devono essere
 * ordinati per Index, senza buchi, con Index >= 1
 *
 * E' gestita la cancellazione logica MA SOLO per quando viene cancellato
 * logicamente una Mailbox/Folder o un utente.
 *
 * Quando invece si chiama EH_Add la lista viene cancellata in maniera fisica
 *
 * EH_Add inserisce alla posizione Index un nuovo record e scala gli altri
 * record di una posizione.
 *
 * EH_Delete cancella il record e "compatta" in giu' tutti gli altri record
 *
 */


//////////////////////////////////////////////////////////////////////////////////////
// L'indice deve essere 
// >= 1  per inserire al centro della lista
// <=    il numero di record
// == -1 per mettere in coda
//
GenericMsg * EH_Add(c_Moses_EH_Add *q, int nClient)
{
	a_Moses_EH_Add *m = STNew a_Moses_EH_Add;

	if (q->Index >= 0) q->Index += 1;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' della MailboxName, Source e Destination. 
		if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox.
			return m;
		}
		
		if ( ! q->Source.IsIdentifier(LEN_NAME_USER, 0 /* bNotNull */) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}
		
		if ( ! q->Destination.IsIdentifier(LEN_NAME_USER, 0 /* bNotNull */) )
		{
			m->Error = GetError("G003", nClient);    // Invalid User Name.
			return m;
		}


		// per prima cosa cancello tutti i record cancellati logicamente
		STRING e = EH_Purge(nClient, q->MailBoxName, q->Folder);


		
		// Conto i record presenti nella tabella.

		VECT<STRING> s = TB_ITG->GetEmptyRow();
		VECT<STRING> output;
		s[ F_ITG_MailboxName ] = q->MailBoxName;
		s[ F_ITG_Folder      ] = q->Folder;
		s[ F_ITG_DelFlag     ] = "";
		long l     = 0L;
		int aCount = 0;
		while ((l = TB_ITG->Select(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_DelFlag), s, output, l)) != -1)
			aCount++;

		// l'inserimento in coda corisponde alla posizione nRecord+1
		if (q->Index == -1)
			q->Index = aCount + 1;

		// l'indice deve essere >= 1
		if (q->Index <= 0)
		{
			m->Error = GetError("G008", nClient);    // Index out of range
			return m;
		}

		// se ci sono record l'indice deve essere >= 1 e <= nRecord+1
		if (aCount > 0 && q->Index > aCount + 1)
		{
			m->Error = GetError("G008", nClient);    // Index out of range
			return m;
		}

		// se non ci sono record l'indice deve essere 1
		if (aCount == 0 && q->Index != 1)
		{
			m->Error = GetError("G008", nClient);    // Index out of range
			return m;
		}

		if (aCount > 0)
		{
			// controllo se esite un record nella posizione q->Index.
			VECT<STRING> o;
			VECT<STRING> s = TB_ITG->GetEmptyRow();
			s[ F_ITG_MailboxName ] = q->MailBoxName;
			s[ F_ITG_Folder      ] = q->Folder;
			s[ F_ITG_Index       ] = STRING::Set(q->Index);
			s[ F_ITG_DelFlag     ] = "";
			if (TB_ITG->Select(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_Index, F_ITG_DelFlag), s, o , 0L) != -1)
			{
				// esiste un record in quella posizione => bisogna
				// scalare gli indici dei record sucessi.
				for (INT32 i = aCount; i >= q->Index ; i--)
				{
					VECT<STRING> search = TB_ITG->GetEmptyRow();
					VECT<STRING> in     = TB_ITG->GetEmptyRow();
					search[ F_ITG_MailboxName ] = q->MailBoxName;
					search[ F_ITG_Folder      ] = q->Folder;
					search[ F_ITG_Index       ] = STRING::Set(i);
					search[ F_ITG_DelFlag     ] = "";
					in    [ F_ITG_Index       ] = STRING::Set(i+1);
					int ii = TB_ITG->Update(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_Index, F_ITG_DelFlag),
							search, TbFile::M(F_ITG_Index), in);
					if (ii != 1)
					{
						// errore! deve esserci sempre un record da updatare a qs. punto.
						m->Error = GetError("ITG001", nClient); // Record not found in ITG table. 
					}
				}
			}
			else
			{
				// non esiste un record in quella posizione => posso inserire.
			}
		}

		VECT<STRING> i = TB_ITG->GetEmptyRow();
		i[ F_ITG_Index          ] = STRING::Set(q->Index);
		i[ F_ITG_MailboxName    ] = q->MailBoxName;
		i[ F_ITG_Folder         ] = q->Folder;
		i[ F_ITG_DelFlag        ] = "";
		i[ F_ITG_Message_Dest   ] = q->Destination;
		i[ F_ITG_Message_Source ] = q->Source;
		i[ F_ITG_Message_Type   ] = q->Subject;
		i[ F_ITG_Message_MSP    ] = q->Action;

		int r = TB_ITG->Insert(i);
		if (r == 0)
		{
			// devo eseguire a ritroso gli eventuali update fatti.
			// N.B. NON puo' esserci chiave duplicata!
			// m->Error = GetError("ITG002", nClient); // User already present in ITG table.
		}
	}
	return m;
}

//////////////////////////////////////////////////////////////////////////////////////
/*
 * Esegue una cancellazione Logica del record settando
 * a "D" il flag F_ITG_DelFlag.
 */
GenericMsg * EH_Delete(c_Moses_EH_Delete *q, int nClient)
{
	if (q->Index >= 0) q->Index += 1;

	a_Moses_EH_Delete *m = STNew a_Moses_EH_Delete;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' della MailboxName. 
		if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox.
			return m;
		}

		// per prima cosa cancello tutti i record cancellati logicamente
		STRING e = EH_Purge(nClient, q->MailBoxName, q->Folder);



		VECT<STRING> d = TB_ITG->GetEmptyRow();
		d [ F_ITG_MailboxName ] = q->MailBoxName;
		d [ F_ITG_Folder      ] = q->Folder;
		d [ F_ITG_DelFlag     ] = "";
		d [ F_ITG_Index       ] = STRING::Set(q->Index);

		int r = TB_ITG->Delete(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_DelFlag, F_ITG_Index),
			 d);
		
		if ( r == 0 )
		{
			m->Error = GetError("ITG003", nClient); // The MailBoxName is not present in the ITG Table.
			m->Valid = 0;
		}
		else
		{
			// devo riaggiornare gli indici contando prima
			// gli elementi della tabella.
			VECT<STRING> s = TB_ITG->GetEmptyRow();
			s[ F_ITG_MailboxName ] = q->MailBoxName;
			s[ F_ITG_Folder      ] = q->Folder;
			s[ F_ITG_DelFlag     ] = "";
			VECT<STRING> output;
			long l     = 0L;
			int aCount = 0;
			while ((l = TB_ITG->Select(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_DelFlag), s, output, l)) != -1)
				aCount++;

			for (INT32 i = q->Index+1; i <= aCount + 1; i++)
			{
				VECT<STRING> search = TB_ITG->GetEmptyRow();
				VECT<STRING> in     = TB_ITG->GetEmptyRow();
				search[ F_ITG_MailboxName ] = q->MailBoxName;
				search[ F_ITG_Folder      ] = q->Folder;
				search[ F_ITG_DelFlag     ] = "";
				search[ F_ITG_Index       ] = STRING::Set(i);
				in    [ F_ITG_Index       ] = STRING::Set(i-1);
				int ii = TB_ITG->Update(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_DelFlag, F_ITG_Index),
						search, TbFile::M(F_ITG_Index), in);
				if (ii != 1)
				{
					// errore! deve esserci sempre un record da updatare a qs. punto.
					m->Error = GetError("ITG004", nClient); // Record not found in ITG table.
					m->Valid = 0;
				}
			}

			m->Valid = 1;
		}
	}
	return m;
}

//////////////////////////////////////////////////////////////////////////////////////
GenericMsg * EH_List(c_Moses_EH_List *q, int nClient)
{
	a_Moses_EH_List *m = STNew a_Moses_EH_List;

	if (q->Index >= 0) q->Index += 1;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' della MailboxName. 
		if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox.
			return m;
		}
		
		VECT<STRING> search = TB_ITG->GetEmptyRow();
		VECT<STRING> output;
		search[ F_ITG_MailboxName ] = q->MailBoxName;
		search[ F_ITG_Folder      ] = q->Folder;
		search[ F_ITG_DelFlag     ] = "";
		search[ F_ITG_Index       ] = STRING::Set(q->Index);
		long l  = 0L;

		l = TB_ITG->Select(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_DelFlag, F_ITG_Index),
				search,  output,  l);
		if ( l == -1L)
		{
			m->Valid = 0;
		}
		else
		{
			m->Source      = output[F_ITG_Message_Source];
			m->Destination = output[F_ITG_Message_Dest];
			m->Subject     = output[F_ITG_Message_Type];
			m->Action      = output[F_ITG_Message_MSP];
			m->Valid       = 1;
		}
	}
	return m;
}

//////////////////////////////////////////////////////////////////////////////////////
GenericMsg * EH_Count(c_Moses_EH_Count *q, int nClient)
{
	a_Moses_EH_Count *m = STNew a_Moses_EH_Count;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		// Controllo la validita' della MailboxName. 
		if ( ! q->MailBoxName.IsIdentifier(LEN_NAME_MB) )
		{
			m->Error = GetError("G005", nClient);    // Invalid Mailbox.
			return m;
		}
		
		// Conto i record presenti nella tabella.

		VECT<STRING> s = TB_ITG->GetEmptyRow();
		VECT<STRING> output;
		s[ F_ITG_MailboxName ] = q->MailBoxName;
		s[ F_ITG_Folder      ] = q->Folder;
		s[ F_ITG_DelFlag     ] = "";
		long l     = 0L;
		int aCount = 0;
		while ((l = TB_ITG->Select(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_DelFlag), s, output, l)) != -1)
			aCount++;

		m->Count = aCount;

	}

	return m;
}


//////////////////////////////////////////////////////////////////////////////////////
/*
 * Esegue la cancellazione fisica della MailBoxName.
 */
STRING EH_RemoveMailbox(int nClient, const STRING &MailBoxName)
{
	STRING error;
	if (G_pServerData->Check_R(nClient, error))
	{
		VECT<STRING> i = TB_ITG->GetEmptyRow();
		i[ F_ITG_MailboxName ] = MailBoxName;
		int r = TB_ITG->Delete(TbFile::M(F_ITG_MailboxName), i);
		if (r == 0)
			error = GetError("ITG011", nClient);  // The MailBoxName not present in the ITG Table.
	}
	return error;
}

/*
 * Esegue la cancellazione fisica delle entry MailBoxName / Folder cancellate logicamente
 */
STRING EH_Purge(int nClient, const STRING &MailBoxName, const STRING &Folder)
{
	STRING error;
	if (G_pServerData->Check_R(nClient, error))
	{
		VECT<STRING> i = TB_ITG->GetEmptyRow();
		i[ F_ITG_MailboxName ] = MailBoxName;
		i[ F_ITG_Folder      ] = Folder;
		i[ F_ITG_DelFlag     ] = "D";

		int r = TB_ITG->Delete(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_DelFlag), i);
		if (r == 0)
			error = GetError("ITG010", nClient);  // The MailBoxName/Folder logical deleted not present in the ITG Table.
	}
	return error;
}

//////////////////////////////////////////////////////////////////////////////////////
STRING EH_Match_Msg (const STRING &MailBoxName,
		const STRING &Folder,
		const STRING &Source,
		const STRING &Subject,
		const STRING &Destination)
{
	STRING Action;

	VECT<STRING> search = TB_ITG->GetEmptyRow();
	VECT<STRING> output;
	search[ F_ITG_MailboxName ] = MailBoxName;
	search[ F_ITG_Folder      ] = Folder;
	search[ F_ITG_DelFlag     ] = "";
	long l     = 0L;

	VECT < VECT<STRING> > aTmpTable;
	while ((l = TB_ITG->Select(TbFile::M(F_ITG_MailboxName, F_ITG_Folder, F_ITG_DelFlag), search, output, l)) != -1)
	{
		aTmpTable.Append(output);
	}

	INT16  Index     = 9999;
	for (int i = 0; i < aTmpTable.Size(); i++)
	{
		STRING tbSource      = aTmpTable[i][F_ITG_Message_Source];
		STRING tbDestination = aTmpTable[i][F_ITG_Message_Dest];
		STRING tbSubject     = aTmpTable[i][F_ITG_Message_Type];

		if ( (tbSource == Source || tbSource.Len() == 0) &&
				(tbSubject == Subject || tbSubject.Len() == 0) &&
				(tbDestination == Destination || tbDestination.Len() == 0))
		{

			if ( aTmpTable[i][F_ITG_Index].GetINT16() < Index)
			{
				Index = aTmpTable[i][F_ITG_Index].GetINT16();
				Action = aTmpTable[i][F_ITG_Message_MSP];
			}
		}
	}

	return Action;
}


//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

static STRING Do_Notify_MB_MSG_WRITE(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";

	Notify_MB_MSG_WRITE *p_MB_MSG_WRITE = (Notify_MB_MSG_WRITE *)p;

	STRING Error;

	STRING Action = EH_Match_Msg(
			p_MB_MSG_WRITE->Mailbox,
			p_MB_MSG_WRITE->Folder,
			p_MB_MSG_WRITE->Sender,
			p_MB_MSG_WRITE->Subject,
			p_MB_MSG_WRITE->Destination);

	if (Action.Len() > 0)
	{
		if (Action.Str()[0] != '#')
			Action = STRING("$msl ") & Action & " Main $LocalHost $Port $Login_Cfg $Pwd_Cfg " & STRING::Set(p_MB_MSG_WRITE->MsgId);
		Action = G_pServerData->GetFilledAction(Action);

		mProcess aaa;
		int r = aaa.Run(Action.Str() /* Ok con GetFilledAction */);

		if (!r)
			Error = GetError("ITG005", p_MB_MSG_WRITE->nClient); // Cannot run program on event handler.
	}

	return Error;
}

static Notify _Notify_MB_MSG_WRITE(Notify_MB_MSG_WRITE::Id, Do_Notify_MB_MSG_WRITE);

//////////////////////////////////////////////////////////////////////////////////////

/*
 * Quando viene cancellata (cancellazione fisica) una mail box e` necessario cancellare
 * tutte le entry relative a quella mailbox
 */
static STRING Do_Notify_MB_PHI_DEL(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";

	Notify_MB_PHI_DEL *p_MB_PHI_DEL = (Notify_MB_PHI_DEL *)p;

	STRING Error;

	if (G_pServerData->Check_R(p_MB_PHI_DEL->nClient, Error))
	{
		VECT<STRING> i = TB_ITG->GetEmptyRow();
		i[ F_ITG_MailboxName ] = p_MB_PHI_DEL->MailboxName;
		TB_ITG->Delete(TbFile::M(F_ITG_MailboxName), i);
	}

	return Error;
}

static Notify _Notify_MB_PHI_DEL(Notify_MB_PHI_DEL::Id, Do_Notify_MB_PHI_DEL);


//////////////////////////////////////////////////////////////////////////////////////
/*
 * Quando viene cancellato (cancellazione fisica) un User e` necessario cancellare
 * tutte le entry relative all'User di Source e Destiantion.
 */
static STRING Do_Notify_USER_PHI_DEL(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";

	Notify_USER_PHI_DEL *p_USER_PHI_DEL = (Notify_USER_PHI_DEL *)p;

	STRING Error;

	if (G_pServerData->Check_R(p_USER_PHI_DEL->nClient, Error))
	{
		VECT<STRING> i = TB_ITG->GetEmptyRow();
		i[ F_ITG_Message_Source ] = p_USER_PHI_DEL->User;
		i[ F_ITG_Message_Dest   ] = p_USER_PHI_DEL->User;
		TB_ITG->Delete(TbFile::M(F_ITG_Message_Source), i);
		TB_ITG->Delete(TbFile::M(F_ITG_Message_Dest), i);
	}
	return Error;
}

static Notify _Notify_USER_PHI_DEL(Notify_USER_PHI_DEL::Id, Do_Notify_USER_PHI_DEL);

//////////////////////////////////////////////////////////////////////////////////////
/*
 * Quando viene cancellato (cancellazione fisica) una Folder e` necessario cancellare
 * tutte le entry relative al folder stesso e alla Mailbox.
 */
static STRING Do_Notify_MB_FOLDER_PHI_DEL(NotifyData *p, STRING &out_rmks)
{
	out_rmks = "";

	Notify_MB_FOLDER_PHI_DEL *p_MB_FOLDER_PHI_DEL = (Notify_MB_FOLDER_PHI_DEL *)p;

	STRING Error;

	if (G_pServerData->Check_R(p_MB_FOLDER_PHI_DEL->nClient, Error))
	{
		VECT<STRING> i = TB_ITG->GetEmptyRow();
		i[ F_ITG_MailboxName ] = p_MB_FOLDER_PHI_DEL->MailboxName;
		i[ F_ITG_Folder      ] = p_MB_FOLDER_PHI_DEL->Folder;
		TB_ITG->Delete(TbFile::M(F_ITG_MailboxName, F_ITG_Folder), i);
	}
	return Error;
}

static Notify _Notify_MB_FOLDER_PHI_DEL(Notify_MB_FOLDER_PHI_DEL::Id, Do_Notify_MB_FOLDER_PHI_DEL);

#endif
