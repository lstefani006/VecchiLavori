#include <st_dbnew.h>
#ifdef MOSES_SERVER

#include <tbFile.h>
#include <server.h>
#include <ERROR.h>

#include "Work.h"

#include "MsgLog.h"

#include <m_Moses_Work_Begin.h>
#include <m_Moses_Work_End.h>
#include <m_Moses_Work_SetLanguage.h>
#include <m_Moses_Work_GetLanguage.h>
#include <m_Moses_Work_ListLanguage.h>
#include <m_Moses_Work_ListClient.h>
#include <m_Moses_Work_SetSession.h>


GenericMsg * Work_Begin(c_Moses_Work_Begin *q, int nClient)
{
	a_Moses_Work_Begin *m = STNew a_Moses_Work_Begin;

	// controllo password nella tabella USER
	{
		VECT<STRING> d = TB_USER->GetEmptyRow();
		d[ F_USER_Name ] = q->Login;
		d[ F_USER_Pwd  ] = q->Pwd;
		d[ F_USER_Type ] = q->ClientType;

		long l = TB_USER->Select(TbFile::M(F_USER_Name, F_USER_Pwd), d, d, 0L);
		if (l == -1L)
		{
			m->Error = GetError("G002", nClient); // Invalid user/password.

			Msg_Log(nClient,
					"Moses_Work_Begin",
					(STRING("TcpAddr=") & G_pServerData->GetTcpAddr(nClient) & STRING(" Error=") & m->Error).Str());
			return m;
		}

		G_pServerData->SetClientType(nClient, d[ F_USER_Type ]);
		G_pServerData->SetClientUserName(nClient, d[ F_USER_Name ]);
	}


	{
		VECT<STRING> moses = TB_MOSES->GetEmptyRow();

		moses[ F_MOSES_Name      ]  = G_pServerData->m_MosesName;
		moses[ F_MOSES_ClientPid ] = "0";

		TB_MOSES->Select(moses, 0L);

		m->Pid = moses[ F_MOSES_ClientPid ].GetINT32() + 1;
		moses[ F_MOSES_ClientPid ] = STRING::Set(m->Pid);

		TB_MOSES->Update(
				TbFile::M(F_MOSES_Name),      moses,
				TbFile::M(F_MOSES_ClientPid), moses);
	}

	Msg_Log(nClient,
			"Moses_Work_Begin",
			(STRING("TcpAddr=") & G_pServerData->GetTcpAddr(nClient) & STRING(" Error=") & m->Error).Str());

	return m;
}

GenericMsg * Work_End(c_Moses_Work_End *q, int nClient)
{
	a_Moses_Work_Begin *m = STNew a_Moses_Work_Begin;

	G_pServerData->SetClientType(nClient, "");
	G_pServerData->SetClientUserName(nClient, "#");

	Msg_Log(nClient,
			"Moses_Work_End",
			(STRING("Error=") & m->Error).Str());

	return m;
}

GenericMsg * Work_SetLanguage(c_Moses_Work_SetLanguage *q, int nClient)
{
	a_Moses_Work_SetLanguage *m = STNew a_Moses_Work_SetLanguage;

	STRING codLanguage;
	G_pServerData->SetClientLanguage(nClient, codLanguage);

	// Ricerco nella TB_LANG se esiste il codice.
	VECT<STRING> s = TB_LANG->GetEmptyRow();

	s[ F_LANG_Cod ] = codLanguage;

	int r = TB_LANG->Select(TbFile::M(F_LANG_Cod), s, s, 0L);

	if (r == -1)
	{
		// NON ho trovato il codice della lingua.
		m->Error = "LAN000 - Unknown Language Code";
		return m;
	}
	 
	return m;
}

GenericMsg * Work_GetLanguage(c_Moses_Work_GetLanguage *q, int nClient)
{
	a_Moses_Work_GetLanguage *m = STNew a_Moses_Work_GetLanguage;

	STRING codLanguage = G_pServerData->GetClientLanguage(nClient);

	m->Language = codLanguage;

	return m;
}

GenericMsg * Work_ListLanguage (class c_Moses_Work_ListLanguage *q, int nClient)
{
	a_Moses_Work_ListLanguage *m = STNew a_Moses_Work_ListLanguage;

	VECT<STRING> vect = TB_LANG->GetEmptyRow();

	long l = 0;
	while ((l = TB_LANG->Select(vect, l)) != -1)
	{
		m->ListCodLang.Append (vect[F_LANG_Cod]);
		m->ListDesLang.Append (vect[F_LANG_Descr]);
	}

	return m;
}



GenericMsg * Work_ListClient (class c_Moses_Work_ListClient *q, int nClient)
{
	a_Moses_Work_ListClient *m = STNew a_Moses_Work_ListClient;

	if (G_pServerData->Check_R(nClient, m->Error))
	{
		for (int i = 0; i < G_pServerData->m_ListConnected.Size(); i++)
		{
			m->ListClient.Append(G_pServerData->GetClientUserName(i));
			m->ListTypeClient.Append(G_pServerData->GetClientType(i));
			m->ListTcpAddr.Append(G_pServerData->GetTcpAddr(i));
		}
	}

	return m;
}

GenericMsg * Work_SetSession(c_Moses_Work_SetSession *q, int nClient)
{
	a_Moses_Work_SetSession *m = STNew a_Moses_Work_SetSession;

	if (G_pServerData->Check_R(nClient, m->Error))
	{

		G_pServerData->SetSession(q->bClosed);

	}


	return m;
}

#endif
