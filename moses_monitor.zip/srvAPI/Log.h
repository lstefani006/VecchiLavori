#include <st_dbnew.h>
#ifndef __Log_h__
#define __Log_h__

#include <moses.h>


GenericMsg * Log		(class c_Moses_Log          *q, int nClient);

#endif
