#include <st_dbnew.h>

#ifndef __mras_h__
#define __mras_h__

int Ras_Connect(const char *ProviderName);
int Ras_IsConnected(const char *ProviderName);
int Ras_Disconnect(const char *ProviderName);

#endif
