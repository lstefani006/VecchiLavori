#include <st_dbnew.h>
#include "mtime.h"

#include <time.h>
#include <stdio.h>
#include <string.h>

STRING mGetCurrentTime()
{
	STRING r('\0', strlen("YYYYMMDDhhmmss"));

	time_t t;
	time(&t);

	tm *ts = localtime(&t);

	sprintf(r.Str(), "%04d%02d%02d%02d%02d%02d",
		ts->tm_year + 1900,
		ts->tm_mon + 1,
		ts->tm_mday,
		ts->tm_hour,
		ts->tm_min,
		ts->tm_sec);

	return r;
}


int mGetCurrentWeekDay()
{
	time_t t;
	time(&t);

	tm *ts = localtime(&t);

	return ts->tm_wday;
}
