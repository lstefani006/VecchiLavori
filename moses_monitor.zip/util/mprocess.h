#include <st_dbnew.h>
#ifndef __mprocess_h__
#define __mprocess_h__

class mProcess
{
public:

	mProcess() { m_Pid = 0; m_bValid = 0; }
	~mProcess();


	/*
	 * Lancia un processo e ritorna 1 se tutto Ok 0 fallito
	 * in pid viene ritornato il pid
	 */
	int  Run(const char *pCommand);

	/*
	 * restituisce il pid del processo
	 */
	long  GetPid();

	/*
	 * setta il pid del processo
	 */
	void  SetPid(long p);

	/*
	 * Termina il processo. Ritorna 1 su Ok 0 altrimenti
	 */
	int Kill();

	/*
	 * Attende il processo. Ritorna 1 su Ok 0 altrimenti
	 * In Unix ExitCode e` -1 se non e` uscito con exit
	 */
	int Wait(int &ExitCode);

	/*
	 *
	 */
	int IsRunning();

protected:
	long m_Pid;
	int  m_bValid;
};

#endif
