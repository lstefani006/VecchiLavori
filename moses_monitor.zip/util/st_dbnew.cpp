#include <st_dbnew.h>
#include <new.h>
#include <iostream.h>

#ifdef _WIN32
	#include <strstrea.h>
#else
	#include <strstream.h>
#endif

#include <stdlib.h>
#include <string.h>

#ifndef ST_DEBUG_NEW

	const char *         G_DeleteFile  = NULL;
	int                  G_DeleteLine  = 0;
	void * operator new (size_t sz, const char *file, int line)
	{
		return operator new(sz);
	}

	__STMemTrace::__STMemTrace(const char *f, int l)
	{
	}

	__STMemTrace::~__STMemTrace()
	{
	}
	
#else


// deve essere un numero primo
#ifdef MSDOS
	#define N   10007
#else
//	#define N   64007
	#define N  250007
//	#define N  500009
//	#define N  750019
//	#define N 1000007
#endif

#ifndef MSDOS
	#define far
#endif

static void *        far G_Tb  [N] = { NULL, };
static size_t        far G_Sz  [N] = { 0, };
static int           far G_Nu  [N] = { 0, };
static const char *  far G_File[N] = { NULL, };
static int           far G_Line[N] = { 0, };
static char          far G_Used[N] = { 0, };

static int           NewCounter = 0;		// numero di allocazioni fatte finora
int                  G_NewCounterDebug = -1;// sentinella per fermare il pgm alla allocazione

#ifdef MSDOS
int                  G_DeferDelete = 1;
#else
int                  G_DeferDelete = 0;
#endif

const char *         G_DeleteFile  = NULL;
int                  G_DeleteLine  = 0;
long                 G_NumNew      = 0;        // numero di puntatori attualmente allocati
long                 G_TotMemAlloc = 0;        // quantita` totale di memoria allocata

#define ALLIGN 16

int NewCounterDebug()
{
	if (getenv("ST_DBNEW_COUNTER"))
		abort();
	return 1;
}

static void ReportError(ostream &s, const char *pMotivo, int i, const char *pFile = NULL, int nLine = 0)
{
	s << "\a\a\a\a\a\a";
	s << "MEMORY REPORT - ";
	s << "Problem on pointer " << G_Tb[i] << " (new counter " << G_Nu[i] << ")" << endl;
	s << pMotivo << endl;
	if (G_File[i])
		s << "Allocated in " << G_File[i] << "(" << G_Line[i] << ")" << endl;
	if (pFile)
		s << "Deallocated in " << pFile << "(" << nLine << ")" << endl;
	s << endl;
}

static int Ok(unsigned char *p, int sz)
{
	for (int i = 0; i < sz; i++)
		if (*p++ != 0xff)
			return 0;
	return 1;
}


void MemReport(ostream &s)
{
	s << "\n\nMEMORY REPORT BEGIN\n\n";

	for (int i = 0; i < N; i++)
	{
		void *v = G_Tb[i];
		if (v == NULL)
			continue;

		unsigned char *p = ((unsigned char *)v) - ALLIGN;

		size_t sz = G_Sz[i];


		if (G_Used[i] == 0)
		{
			if (Ok(p, ALLIGN + sz + ALLIGN) == 0)
				ReportError(s, "pointer used after delete operator", i);
		}
		else
		{
			if (Ok(p, ALLIGN) == 0)
				ReportError(s, "write before pointer assigned space", i);

			if (Ok(p + ALLIGN + sz, ALLIGN) == 0)
				ReportError(s, "write after pointer assigned space", i);
		}


		if (G_Used[i] == 1)
		{
			if (G_File[i])
				s << "pointer not deleted on " << G_File[i]
				     << "(" << G_Line[i] << ", G_NewCounterDebug = " << G_Nu[i] << ")" << endl;
			else
				s << "pointer not deleted (no source information) "
				     << "(G_NewCounterDebug = " << G_Nu[i] << ")" << endl;
		}
	}
	s << "\nEND MEMORY REPORT\n\n";
}



struct Sem
{
	Sem()
	{
		if (Sem::G_Sem)
		{
			cerr << "\a\a\a\n\nRECURSIVE CALL TO NEW/DELETE !!!!!\n\n\n\n" << endl;
			abort();
		}
		G_Sem = 1;
	}
	~Sem() { G_Sem = 0; }

	static int G_Sem;
};

int Sem::G_Sem = 0;


void * operator new (size_t sz, const char *file, int line)
{
	Sem ss;

	{
		static int bFirst = 1;
		if (bFirst == 1)
		{
			bFirst = 0;
			if (getenv("ST_DBNEW_COUNTER"))
				G_NewCounterDebug = atoi(getenv("ST_DBNEW_COUNTER"));
		}
	}

	if (sz == 0)
		sz = 1;

	G_NumNew++;
	unsigned char *p = (unsigned char *)malloc(ALLIGN + sz + ALLIGN);
	if (p == NULL)
		return NULL;

	memset(p,               0xff, ALLIGN);
	memset(p + ALLIGN,      '\0', sz);
	memset(p + ALLIGN + sz, 0xff, ALLIGN);

	unsigned nHash = (unsigned)(((unsigned long)p) % N);
	unsigned i = nHash;

	for (;;)
	{
		if (G_Tb[i] == NULL)
		{
			G_Tb  [i] = p + ALLIGN;
			G_Sz  [i] = sz;
			G_Nu  [i] = ++NewCounter;
			G_Used[i] = 1;
			G_File[i] = file;
			G_Line[i] = line;

			G_TotMemAlloc += sz;

			if (G_Nu[i] == G_NewCounterDebug)
				NewCounterDebug();

			return p + ALLIGN;
		}

		i++;

		if (i == N)
			i = 0;
		else
		if (i == nHash)
		{
			cerr << "\n\nTABELLA PIENA\n\n" << endl;
			abort();
		}
	}

	return NULL;
}


void * operator new (size_t sz)
{
	return operator new(sz, NULL, 0);
}




void operator delete (void *v)
{
	Sem ss;

	if (v == NULL)
	{
		G_DeleteFile = NULL;
		G_DeleteLine = 0;
		return;
	}

	unsigned char *p = ((unsigned char *)v) - ALLIGN;

	unsigned nHash = (unsigned)(((unsigned long)p) % N);
	unsigned i = nHash;

	for (;;)
	{
		if (G_Tb[i] == v)
		{
			if (G_Nu[i] == G_NewCounterDebug)
				NewCounterDebug();

			size_t sz = G_Sz[i];
			G_TotMemAlloc -= sz;

			if (Ok(p, ALLIGN) == 0)
				ReportError(cerr, "write before pointer assigned space", i, G_DeleteFile, G_DeleteLine);

			if (Ok(p + ALLIGN + sz, ALLIGN) == 0)
				ReportError(cerr, "write after pointer assigned space", i, G_DeleteFile, G_DeleteLine);

			memset(p, 0x00, ALLIGN + sz + ALLIGN);

			G_DeleteFile = NULL;
			G_DeleteLine = 0;
			G_NumNew--;

			if (G_DeferDelete)
			{
				G_Used[i] = 0;
				memset(p, 0xff, ALLIGN + sz + ALLIGN);
			}
			else
			{
				G_Tb  [i] = NULL;
				G_Sz  [i] = 0;
				G_Nu  [i] = 0;
				G_Used[i] = 0;
				G_File[i] = NULL;
				G_Line[i] = 0;
				free(p);
			}


			return;
		}

		i++;
		if (i == N)
			i = 0;
		else
		if (i == nHash)
		{
			cerr << "MEMORY REPORT - operator delete: trying to delete pointer "
				 << "not allocated with new ";

			if (G_DeleteFile)
				 cerr << G_DeleteFile << "(" << G_DeleteLine << ")" << endl;
			else
				 cerr << " (no source information)" << endl;
			cerr << endl;
			
			G_DeleteFile = NULL;
			G_DeleteLine = 0;
			return;
		}
	}
}


//////////////////////////////////////////////////////////////////////////

__STMemTrace::__STMemTrace(const char *f, int l)
{
	m_File = f;
	m_Line = l;
	m_NewCounter = NewCounter;
	m_TotMemAlloc = G_TotMemAlloc;
	m_NumPtAlloc =  G_NumNew;

	cerr << "START Mem trace started on " << m_File << " " << m_Line << endl;
	cerr << "\tTot mem allocated = " << m_TotMemAlloc << endl;
	cerr << "\tn. of allocated pointers " << m_NumPtAlloc << endl;
}

__STMemTrace::~__STMemTrace()
{
	cerr << "Mem trace started on " << m_File << " " << m_Line << endl;
	cerr << "\tTot mem allocated = " << G_TotMemAlloc << "    difference = " << m_TotMemAlloc - G_TotMemAlloc << endl;
	cerr << "\tn. of allocated pointers " << G_NumNew << "    difference = " << m_NumPtAlloc  - G_NumNew      << endl;

	for (int i = 0; i < N; i++)
	{
		if (G_Tb[i] != NULL && G_Nu[i] >= m_NewCounter && G_Used[i] == 1)
		{
			cerr << "\t";

			if (G_File[i])
				cerr << "pointer not deleted allocated on " << G_File[i]
					<< "(" << G_Line[i] << ", G_NewCounterDebug = " << G_Nu[i] << ") Size = " << G_Sz[i] << endl;
			else
				cerr << "pointer not deleted (no source information) "
					<< "(G_NewCounterDebug = " << G_Nu[i] << ") Size = " << G_Sz[i] << endl;
		}
	}

	cerr << "END Mem trace started on " << m_File << " " << m_Line << endl;
}



#if 0

int major_primo(int n)
{
	register i, j;

	for (j = n ; ; j++)
		for (i = 2; i <= j; i++)
		{
			if (j % i)
				continue;
			if (j == i)
				return j;
			break;
		}
}

void main()
{
	int n;
	cout << "dammi un numero ";
	cin >> n;

	char *p = New char;
	p[1] = 1;

	//Delete p;
	Delete (void *)3;

	p[0] = 3;

	cout << "il prossimo numero primo e` " <<
		major_primo(n) << endl;


	MemReport(cerr);
}


#endif

#endif // ST_DEBUG_NEW
