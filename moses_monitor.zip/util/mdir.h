#include <st_dbnew.h>
#ifndef __mdir_h__
#define __mdir_h__

#include "serlzer.h"

int MkDir(const STRING &pPath);  // 1 Ok 0 Errore
int RmDir(const STRING &pPath, int bRecursive);  // 1 Ok 0 Errore

/*
 * ritorna il solo file di una stringa path/file
 */
STRING GetFileName(const STRING &PathFile);

/*
 * ritorna il path di un path/file
 * se in ingresso ho solo file ritorna "."
 */
STRING GetPathName(const STRING &PathFile);



class File
{
public:
	static STRING Write(const STRING &file, const STRING &body);
	static STRING Read (const STRING &file,       STRING &body); 

	static STRING Move (const STRING &from, const STRING &to);
	static STRING Remove (const STRING &file);
};

class mDirectory
{
public:
	mDirectory();

	STRING Open(const char *);

	~mDirectory();

	int GetNext(
			STRING &FileName,
			INT32  &Size,
			STRING &DateLastChange,
			INT16  &bDirectory
			);

	static int Exist(const char *FileName, int &bDirectory);

private:
	void *m_p;
	STRING m_Path;
};

#endif
