#include <st_dbnew.h>
#include "mdir.h"

#include <stdio.h>

#ifdef _WIN32
	#include <windows.h>
	#include <direct.h>
	#include <string.h>
	#include <sys/types.h>
	#include <sys/stat.h>
#else
	#include <sys/mode.h>
	#include <sys/stat.h>
	#include <unistd.h>
#endif


int MkDir(const STRING &pPath)
{
#ifdef _WIN32
	return _mkdir(pPath.Str()) == 0;
#else
	return mkdir(pPath.Str(), S_IRWXU) == 0;
#endif
}

int RmDir(const STRING &pPath, int bRecurse)
{
	if (bRecurse)
	{
#ifdef _WIN32
	return system(("deltree /y " & pPath).Str()) == 0;
#else
	return system(("rm -r " & pPath).Str()) == 0;
#endif
	}
	else
	{
#ifdef _WIN32
	return system(("rmdir " & pPath).Str()) == 0;
#else
	return system(("rmdir " & pPath).Str()) == 0;
#endif
	}
}



STRING GetFileName(const STRING &PathFile)
{
	const char *p = strrchr(PathFile.Str(), '/'); 
	if (p)
		return STRING(p + 1);
	else
		return PathFile;
}

STRING GetPathName(const STRING &PathFile)
{
	const char *p = strrchr(PathFile.Str(), '/'); 
	if (p)
	{
		STRING path(PathFile.Str(), p - PathFile.Str());

		// tolgo l'eventuale ./ 

		if (path.Str()[0] == '.' && path.Str()[1] == '/')
		{
			STRING r(path.Str() + 2);
			path = r;
		}

		return path;
	}
	else
		return STRING("");
}

/////////////////////////////////////////////////////////////////////

STRING File::Write(const STRING &fileName, const STRING &body)
{
	FILE *f = fopen(fileName.Str(), "wb");
	if (f == NULL)
		return STRING("cannot create file") & fileName;

	int r;

	if (body.Len() > 0)
	{
		r = fwrite(body.Str(), body.Len(), 1, f);
		if (r != 1)
		{
			fclose(f);
			return STRING("cannot close file") & fileName;
		}
	}

	r = fclose(f);
	if (r != 0)
		return STRING("cannot close file") & fileName;

	return "";
}

STRING File::Read(const STRING &fileName, STRING &body)
{
	FILE *f = fopen(fileName.Str(), "rb");
	if (f == NULL)
		return STRING("open read file ") & fileName;

	size_t n = 0;

	char *b = STNew char [1024 * 1024];

	body = STRING();
	while ( (n = fread(b, 1, 1024*1024, f)) != 0 )
		body = body & STRING(b, n);

	STDelete [] b;

	int r = fclose(f);
	if (r != 0)
		return STRING("cannot close file ") & fileName;

	return "";
}

STRING File::Move(const STRING &from, const STRING &to)
{
#ifdef _WIN32
	BOOL b = MoveFile(from.Str(), to.Str());
	if (b == FALSE)
		return "cannot move file";
	else
		return "";
#else
	int r = system(("mv -f " & from & " " & to).Str());
	if (r != 0)
		return "cannot move file";
	else
		return "";
#endif
}

STRING File::Remove(const STRING &file)
{
#ifdef _WIN32
	int b = _unlink(file.Str());
	if (b == -1)
		return "cannot remove file";
	else
		return "";
#else
	int r = system(("rm -f " & file).Str());
	if (r != 0)
		return "cannot remove file";
	else
		return "";
#endif
}


////////////////////////////////////////////////////////////////////////////


#ifndef _WIN32

// unix
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>

mDirectory::mDirectory()
{
	m_p = NULL;
}

mDirectory::~mDirectory()
{
	DIR *p = (DIR *)m_p;
	if (p)
		closedir(p);
}

STRING mDirectory::Open(const char *path)
{
	DIR *p = ::opendir(path);
	if (p == NULL)
		return STRING("Cannot access to ") & path;

	m_p = p;
	m_Path = path;
	return "";
}

int mDirectory::GetNext(
		STRING &FileName,
		INT32  &Size,
		STRING &Date,
		INT16  &bDirectory
					  )
{
	dirent *p = readdir((DIR *)m_p);

	if (p == NULL)
		return 0;

	FileName = p->d_name;

	struct stat s;
	int r = ::stat((m_Path & "/" & FileName).Str(), &s);

	Size = s.st_size;
	Date = STRING('\0', strlen("YYYYMMDDhhmmss"));

	tm *ts = ::localtime(&s.st_mtime);

	sprintf(Date.Str(), "%04d%02d%02d%02d%02d%02d",
			ts->tm_year + 1900,
			ts->tm_mon + 1,
			ts->tm_mday,
			ts->tm_hour,
			ts->tm_min,
			ts->tm_sec);

	bDirectory = (s.st_mode & S_IFDIR) ? 1 : 0;

	return 1;
}


int mDirectory::Exist(const char *FileName, int &bDirectory)
{
	struct stat s;
	int r = ::stat(FileName, &s);
	if (r)
		return 0;

	bDirectory = (s.st_mode & S_IFDIR) ? 1 : 0;
	return 1;
}


#else

#include <windows.h>
#include <windowsx.h>

struct W32DIR
{
	HANDLE          h;
	WIN32_FIND_DATA f;
	int             bFirst;
};

mDirectory::mDirectory()
{
	m_p = NULL;
}

mDirectory::~mDirectory()
{
	W32DIR *p = (W32DIR *)m_p;
	if (p != NULL)
	{
		if (p->h != INVALID_HANDLE_VALUE)
			::FindClose(p->h);
		STDelete p;
	}
}

STRING mDirectory::Open(const char *path)
{
	m_p = STNew W32DIR;
	W32DIR *p = (W32DIR *)m_p;
	p->bFirst = 1;

    p->h = ::FindFirstFile((STRING(path) & "/*").Str(), &p->f);
	if (p->h == INVALID_HANDLE_VALUE)
		return STRING("Cannot access to ") & path;

	m_Path = path;
	return "";
}

int mDirectory::GetNext(
		STRING &FileName,
		INT32  &Size,
		STRING &Date,
		INT16  &bDirectory
					  )
{
	W32DIR *p = (W32DIR *)m_p;
	if (p == NULL)
		return 0;

	if (p->bFirst == 0)
	{
		BOOL b = ::FindNextFile(p->h, &p->f);
		if (b == FALSE)
			return 0;
	}

	p->bFirst = 0;

	FileName = p->f.cFileName;
	Size     = (p->f.nFileSizeHigh * MAXDWORD) + p->f.nFileSizeLow;
	Date     = STRING('\0', strlen("YYYYMMDDhhmmss"));

	FILETIME t;
	::FileTimeToLocalFileTime(&p->f.ftLastWriteTime, &t);

	SYSTEMTIME st;
	::FileTimeToSystemTime(&t, &st);

	sprintf(Date.Str(), "%04d%02d%02d%02d%02d%02d",
			(int) st.wYear,
			(int) st.wMonth,
			(int) st.wDay,
			(int) st.wHour,
			(int) st.wMinute,
			(int) st.wSecond);

	bDirectory = (p->f.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ? 1 : 0;

	return 1;
}

int mDirectory::Exist(const char *FileName, int &bDirectory)
{
	struct stat s;
	int r = ::stat(FileName, &s);
	if (r)
		return 0;

	bDirectory = (s.st_mode & S_IFDIR) ? 1 : 0;
	return 1;
}


#endif
