#ifndef __ST_DB_NEW_H__
#define __ST_DB_NEW_H__


#ifndef _WIN32
#include <new.h>
#endif

// Questa classe viene ignorata se il programma viene linkato
// in modilita' senza il controllo delle memoria anche se qualche
// modulo e' stato compilato con il controllo della memoria
class __STMemTrace
{
public:
	__STMemTrace(const char *f, int l);
	~__STMemTrace();

private:
	const char *m_File;
	int         m_Line;
	int         m_NewCounter;
	int         m_TotMemAlloc;   // memoria totale allocata
	int         m_NumPtAlloc;    // numero di pt allocati
};


#if defined(ST_DEBUG_NEW)

	#define STNew    new(__FILE__, __LINE__)
	#define STDelete G_DeleteFile = __FILE__, G_DeleteLine = __LINE__, delete

	extern const char *G_DeleteFile;
	extern int         G_DeleteLine;
	extern int         G_DeferDelete;
	extern int         G_NewCounterDebug;
	extern long        G_NumNew;

	class ostream;
	void MemReport(ostream &);

	int NewCounterDebug();

	// per i moduli compilati ancora con il controllo della memoria
	void * operator new (size_t, const char *, int);

	#define STMemTrace __STMemTrace __a__(__FILE__, __LINE__)

#else

	void * operator new (size_t sz, const char *, int);

	#define STNew      new
	#define STDelete   delete
	#define STMemTrace ((void)0)

#endif

#endif // __ST_DB_NEW_H__
