#include <st_dbnew.h>
#include "mprocess.h"

#ifndef _WIN32

#include <unistd.h>
#include <sys/wait.h>
#include <sys/signal.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

mProcess::~mProcess()
{
}

int mProcess::Run(const char *pCommand)
{
	char b[1024];
	strcpy(b, pCommand);

	char *av[50];
	int  ac = 0;

	char *sep = " \t";
	char *p = b;
	p = strtok(p, sep);
	while (p)
	{
		av[ac++] = p;
		p = strtok(NULL, sep);
	}
	av[ac] = NULL;

	
	pid_t Pid = fork();

	if (Pid == 0)
	{
		execvp(av[0], av);
		exit(-1);
	}

	m_Pid = (long) Pid;
	m_bValid = 1;

	return 1;
}

int mProcess::Wait(int &ExitCode)
{
	int status;
	pid_t pid = m_Pid;

	pid_t r = waitpid(pid, &status, 0);

	ExitCode = WEXITSTATUS(status);

	return r == m_Pid;
}

int mProcess::IsRunning()
{
	int status;
	pid_t pid = m_Pid;

	pid_t r = waitpid(pid, &status, WNOHANG);
	return r != -1;
}

long mProcess::GetPid()
{
	return m_Pid;
}

void mProcess::SetPid(long p)
{
	m_Pid = p;
}


int mProcess::Kill()
{
	pid_t pid = (pid_t)m_Pid;

	return 0 == ::kill(pid, SIGKILL);
}


#else

#include <stdio.h>
#include <windows.h>
#include <process.h>

mProcess::~mProcess()
{
	if (m_bValid)
	{
		// cancello la risorsa non il processo
		HANDLE hProcess = (HANDLE) m_Pid;
		::CloseHandle(hProcess);
	}
}


long mProcess::GetPid()
{
	return m_Pid;
}

void mProcess::SetPid(long p)
{
	m_Pid = p;
}

int mProcess::Run(const char *pCommand)
{
	STARTUPINFO si;
	::ZeroMemory(&si, sizeof(si));

	GetStartupInfo(&si);
	// si.cb = sizeof(si);

	PROCESS_INFORMATION pi;
	::ZeroMemory(&pi, sizeof(pi));


	LPCTSTR                lpApplicationName    = NULL;     // pointer to name of executable module 
	LPTSTR                 lpCommandLine        = (char *)pCommand; // pointer to command line string
	LPSECURITY_ATTRIBUTES  lpProcessAttributes  = NULL;     // pointer to process security attributes 
	LPSECURITY_ATTRIBUTES  lpThreadAttributes   = NULL;     // pointer to thread security attributes 
	BOOL                   bInheritHandles      = TRUE;     // handle inheritance flag 
	DWORD                  dwCreationFlags      = NULL;     // creation flags 
	LPVOID                 lpEnvironment        = NULL;     // pointer to new environment block 
	LPCTSTR                lpCurrentDirectory   = NULL;     // pointer to current directory name 
	LPSTARTUPINFO          lpStartupInfo        = &si;      // pointer to STARTUPINFO 
	LPPROCESS_INFORMATION  lpProcessInformation = &pi;      // pointer to PROCESS_INFORMATION  

	BOOL r = ::CreateProcess(
			lpApplicationName,
			lpCommandLine,
			lpProcessAttributes,
			lpThreadAttributes,
			bInheritHandles,
			dwCreationFlags,
			lpEnvironment,
			lpCurrentDirectory,
			lpStartupInfo,
			lpProcessInformation);
	if (r)
	{
		::CloseHandle(pi.hThread);
		m_Pid = (long) pi.hProcess;
	}
	else
		::CloseHandle(pi.hProcess);

	return r == TRUE;
}

int mProcess::Kill()
{
	HANDLE hProcess = (HANDLE) m_Pid;
	BOOL r = ::TerminateProcess(hProcess, (UINT)-1);
	return r == TRUE;
}

int mProcess::Wait(int &ExitCode)
{
	HANDLE hProcess = (HANDLE) m_Pid;

	DWORD dw = ::WaitForSingleObject(hProcess, INFINITE);
	if (dw != WAIT_FAILED)
	{
		DWORD dwExitCode;
		BOOL r = ::GetExitCodeProcess(hProcess, &dwExitCode);

		ExitCode = dwExitCode;

		return 1;
	}

	return 0;
}

int mProcess::IsRunning()
{
	HANDLE hProcess = (HANDLE) m_Pid;

	DWORD dw;
	BOOL r = ::GetExitCodeProcess(hProcess, &dw);

	if (r == TRUE && dw == STILL_ACTIVE)
		return 1;

	return 0;
}



#endif


/*
void main()
{
	mProcess aa;

	aa.Run("eeee 22");

	int k2 = aa.IsRunning();

	int e;
	int r = aa.Wait(e);
	printf("WaitProcess %d exit=%d\n", r, e);

	printf("IsRunning ritorna %d\n", k2);

	int k = aa.IsRunning();
	printf("IsRunning ritorna %d\n", k);
}
*/
