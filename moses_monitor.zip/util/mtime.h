#include <st_dbnew.h>
#ifndef __mtime_h__
#define __mtime_h__

#include "serlzer.h"

STRING mGetCurrentTime();

int mGetCurrentWeekDay();

#endif
