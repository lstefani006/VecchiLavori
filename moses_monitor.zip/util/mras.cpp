#include <st_dbnew.h>
#include <mras.h>


#ifdef _WIN32

#include <iostream.h>
#include <windows.h>
#include <windowsx.h>
#include <ras.h>
#include <raserror.h>


#define arraySize(a) ((sizeof(a))/(sizeof(a[0])))


static int Ras_IsConnected(const char *ProviderName, HRASCONN &h)
{
	#define MAX_CONN 20
	RASCONN tb[MAX_CONN];   // si spera che non ci siano piu' di 20 connessioni
	                        // in contemporanea

	h = NULL;
	DWORD i;
	for (i = 0; i < arraySize(tb); i++)
	{
		memset(tb, sizeof(tb), '\0');
		tb[i].dwSize = sizeof(RASCONN);
	}

	DWORD cb = sizeof(tb);
	DWORD cConnections;

	DWORD e = ::RasEnumConnections(
		tb,
		&cb,
		&cConnections);

	if (e)
	{
		clog << "RAS001: - Error in RasEnumConnections" << endl;
		return 0;
	}

	for (i = 0; i < cConnections; i++)
	{
		if (strcmp(ProviderName, tb[i].szEntryName) == 0)
		{
			h = tb[i].hrasconn;
			return 1;
		}
	}

	return 0;
}

int Ras_IsConnected(const char *ProviderName)
{
	HRASCONN h;
	return Ras_IsConnected(ProviderName, h);
}


int Ras_Connect(const char *ProviderName)
{
	int r = Ras_IsConnected(ProviderName);
	if (r)
		return 1;

	RASDIALPARAMS rdParams;

	rdParams.dwSize = sizeof(RASDIALPARAMS);
	strcpy(rdParams.szEntryName, ProviderName);

	rdParams.szPhoneNumber   [0] = '\0';
	rdParams.szCallbackNumber[0] = '*';
	rdParams.szCallbackNumber[0] = '\0';

	rdParams.szUserName      [0] = '\0';
	rdParams.szPassword      [0] = '\0';
	rdParams.szDomain        [0] = '*';
	rdParams.szDomain        [1] = '\0';

	/*
	 * Specificando dwNotifierType = 0 e lpvNotifier = NULL
	 * ottengo una connect sincrona (senza funzione di notifica)
	 */

	HRASCONN h;

	DWORD e = ::RasDial(
			/* lprRasdialExtensions */ NULL,
			/* lpzPhonebook         */ NULL,
			/* lpRasDialParam       */ &rdParams,
			/* dwNotifierType       */ 0L,
			/* lpvNotifier          */ NULL,
			/* lphRasConn           */ &h);

	if (e != 0)
	{
		if (h)
			::RasHangUp(h);
	}

	return e == 0;
}

int Ras_Disconnect(const char *ProviderName)
{
	HRASCONN h;
	int r = Ras_IsConnected(ProviderName, h);
	if (!r)
		return 1;

	DWORD e = ::RasHangUp(h);

	return e == 0;
}


#else

#include <iostream.h>

int Ras_IsConnected(const char *ProviderName)
{
	clog << "RAS002 - Ras functions are not implemented in Unix environment" << endl;
	return 1;
}

int Ras_Connect(const char *ProviderName)
{
	clog << "RAS003 - Ras functions are not implemented in Unix environment" << endl;
	return 1;
}

int Ras_Disconnect(const char *ProviderName)
{
	clog << "RAS004 - Ras functions are not implemented in Unix environment" << endl;
	return 1;
}

#endif
