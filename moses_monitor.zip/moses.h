#include <st_dbnew.h>
#ifndef __moses_h__
#define __moses_h__


/******************************************************************************/
/*                        MOSES CORE API                                      */
/******************************************************************************/

#include "gnricmsg.h"

/******************************************************************************/
/*
 * Connection section
 * Theese APIs allow to the MOSES clients to establish a connection on MOSES
 * server.
 */

/*
 * Moses_Connection_Dial
 * Allows Clients to be connected with remote Internet providers
 * Input
 * 	Provider    - Name of the provider
 *
 * Notes: this API actually works only in Windows envirnment
 */
STRING Moses_Connection_Dial(const char *Provider);

/*
 * Moses_Connection_HungUp
 * Disconect remote connection opened with Moses_Connection_Dial
 */
STRING Moses_Connection_HungUp(const char *Provider);

/*
 * Moses_Connection_IsRemote
 * Returns 1 in out_Remote if the connection to moses is remote 0 for
 * direct link
 */
STRING Moses_Connection_IsRemote(const char *Provider, INT16 &out_Remote);

/*
   Moses_Connection_Open starts a connection on a MOSES server
   Return CODES
   "" connection established
   else a string allocated on free store explaining what's wrong

   if nPort is -1 the port is obtained from "services" configuration file
 */
STRING Moses_Connection_Open(const char *TcpServerName, int Port = -1);

/*
   Moses_Connection_Close closes connection on MOSES
 */
STRING Moses_Connection_Close();

/******************************************************************************/
/*
 * Session control - starts and ends a work session in MOSES.
 * MOSES gives to a client all the privileges associated with that login and
 * client type.
 * A work session end instructs MOSES to clean up temporary resources
 * allocated for that client
 */

/*
   Moses_Work_Begin initializes a work session on MOSES with the
   privileges associated with the Login name.
   Input parameters:
   Login specifies the login name (zero terminate string)
   Pwd specified the password associated with the login name
   ClientType the client type e.g. IDT MTD APP SCR CFG
   Output parameters:
   out_Pit client identifier assigned by MOSES
 */
STRING Moses_Work_Begin(
		const char *Login,
		const char *Pwd,
		const char *ClientType,
		INT32 &out_Pid);

/*
   Moses_Work_End finalize a work session.
   MOSES deletes all the temporary files that have been
   read from this client a manages other cleaning features only if bOk is 1.
   Input parameters:
   bOk if 1 indicates that this work session is succesfully, 0 otherwise
 */
STRING Moses_Work_End(int Pid, int bOk);


/*
 * Set/Get/List the language of the messages
 */
STRING Moses_Work_SetLanguage(const char *Language);
STRING Moses_Work_GetLanguage(STRING &out_Language);
STRING Moses_Work_ListLanguage(
		VECT<STRING> &out_CodLang, 
		VECT<STRING> &out_DesLang);
/*
 * opens/closes non system moses access
 */
STRING Moses_Work_SetSession(int bClosed);

/*
 * Lists all the clients connected to Moses
 */
STRING Moses_Work_ListClient( /*R*/
		VECT<STRING> &out_LoginList,
		VECT<STRING> &out_ClientTypeList,
		VECT<STRING> &out_TcpAddrList);


/******************************************************************************/
/*
 * User section
 * MOSES users are the subjects that can send or receive mail.
 * MOSES register all users in the USER table UT.
 * The UT lists all the MOSES users and a description associated
 */


/*
   Moses_User_Add - add a new user to the User table.
   UserName cannot be duplicated.
   Users can be internal (i.e. MOSES users) or external (i.e. belonging
   to an another mailing system). This API creates an external user
   only if UserDefaultMB is blank; otherwise an internal user is created
   with its new mailbox.
   An external user must have an entry in the ART table (in order to received
   mail from him). An internal user can or cannot have an entry in the ART:
   if yes that user will be able to receive mail from outside moses, otherwise
   it will receive mail only from its local environment
   Input parameters:
     UserName         name of the new user
     UserPwd          connection password
     ClientType       the client type e.g. IDT MTD APP SCR CFG
     UserDescr        remarks on the new user
     UserRights       ignored field
     UserDefaultMBox  default mail-box. If not "" this call create the 
                      specified mailbox with blank password no description
     UserKeyId        ignored field
 */
STRING Moses_User_Add( /*R*/
		const char *UserName, 
		const char *UserPwd, 
		const char *UserClientType, 
		const char *UserDescr, 
		const char *UserRights, 
		const char *UserDefaultMBox, 
		const char *UserKeyId);

/*
   Moses_User_ChangePassword - change the password to an existing user
   CFG user do not need to specify old password
   Input parameters:
     UserName         name of the new user
     UserOldPwd       connection old password
     UserNewPwd       connection new password
 */
STRING Moses_User_ChangePassword(
		const char *UserName, 
		const char *UserOldPwd, 
		const char *UserNewPwd);

/*
   Moses_User_List return the user name, description and key saved
   in the Index position on the table
   Input parameters
      Index index entry on the User table
   Output parameters
    * out_UserName        name required
      out_UserClientType  client type
    * out_UserDescr       description required
      out_UserRights      ignore this field
    * out_UserDefaultMBox default mailbox; if "" the user is an external user
      out_UserKeyId       key id requred
    * out_Valid  if 1 Index is valid else 0 index is not valid
    
    Output parameters with '*' are available only if client is a CFG client
 */
STRING Moses_User_List(
		INT32  Index, 
		STRING &out_UserName, 
		STRING &out_UserPwd, 
		STRING &out_UserClientType, 
		STRING &out_UserDescr,
		STRING &out_UserRights,
		STRING &out_UserDefaultMBox,
		STRING &out_UserKeyId, 
		INT16  &out_Valid);

/*
   Moses_User_Delete deletes the specified user; if cascade option is set
   the moses deletes all the entries relative to that user
   (mail-box, ART entry, ITG)
   Input parameters :
   User to be deleted
   Cascade if 1 MOSES deletes all the entries relative to that user
   else MOSES deletes only the entry in the User table
 */
STRING Moses_User_Delete( /*R*/
		const char *UserName,
		int Cascade);

/*
	Moses_User_Modify - modifies the fields in the UserName entry
*/
STRING Moses_User_Modify( /*R*/
		const char *UserName,
		const char *UserPwd, 
		const char *UserClientType, 
		const char *UserDescr, 
		const char *UserRights, 
		const char *UserDefaultMBox, 
		const char *UserKeyId);

/******************************************************************************/
/*
	Distribution List - DL
	This section allows outgoing mail to be distributed to a list of users
	specifing olny one outgoing address.
*/

STRING Moses_DL_Add    /*R*/ (
		const char *DLName, 
		const char *Pwd, 
		const char *Descr);

STRING Moses_DL_Modify /*R*/ (
		const char *DLName, 
		const char *Pwd, 
		const char *Descr);

STRING Moses_DL_List   /*R*/ (
		VECT<STRING> &out_DLNameList, 
		VECT<STRING> &out_PwdList, 
		VECT<STRING> &out_DescrList);

STRING Moses_DL_Delete /*R*/ (
		const char *DLName);

STRING Moses_DL_Member_Add(
		const char *DLName, 
		const char *Pwd, 
		const char *User);

STRING Moses_DL_Member_Delete(
		const char *DLName, 
		const char *Pwd, 
		const char *User);

STRING Moses_DL_Member_List(
		const char *DLName, 
		const char *Pwd, 
		VECT<STRING> &out_UserList);

/******************************************************************************/
/*
 * Mail box section
 * MOSES Mail boxes contain MOSES messages. 
 * Mail box can have more folder
 */


/*
   Moses_MB_Check - check the mail-box existence and access privileges 
 */
STRING Moses_MB_CheckMailbox(
		const char *MailBoxName,
		const char *Pwd);

/*
   Moses_MB_ChangePassword - change the password in PwdNew of the
   MailBox password in PwdCurrent
   CFG clients need not to specify PwdCurrent

   Input parameters
      MailBoxName        mail-box
	  PwdCurrent         actual mail box password.
	  PwdNew             new password
 */
STRING Moses_MB_ChangePassword(
		const char *MailBoxName,
		const char *PwdCurrent,
		const char *PwdNew);

/*
   Moses_MB_ListMailbox
   CFG users can obtain all mailboxes with full information
   Other user can obtain only its own mailboxes and the system mailbox; in
   this case out_Owner and out_Pwd are always ""

   Input  parameters
     Index   a number starting by 0
   Output parameters
     out_MailboxName    name of the mailbox
     out_Owner          owner of the mail box
     out_Pwd            password of the mail box (CFG) or "" for other clients
     out_Descr          description of the mail box
     out_Valid          1 if Index is valid 0 if not
 */
STRING Moses_MB_ListMailbox(
		int Index,
		STRING &out_MailboxName,
		STRING &out_Owner,
		STRING &out_Pwd,
		STRING &out_Descr,
		INT16  &out_Valid);

/*
   Moses_MB_CreateMailbox - create the mailbox with in/out/error folders
 */
STRING Moses_MB_CreateMailbox( /*R*/
		const char *MailBoxName,
		const char *Owner,
		const char *Pwd,
		const char *Descr);

/*
   Moses_MB_DeleteMailbox - delete the mailbox
 */
STRING Moses_MB_DeleteMailbox( /*R*/
		const char *MailBoxName);

/*
   Moses_MB_ChangeOwner - change the mailbox owner
 */
STRING Moses_MB_ChangeOwner( /*R*/
		const char *MailBoxName,
		const char *Owner);

/*
   Moses_MB_ChangeDescr - change the mail box description
   CFG clients do not need to specify Pwd
   Input parameters
      MailBoxName       mail box name
	  Pwd               mail box password
	  Descr             mail box new description
 */
STRING Moses_MB_ChangeDescr(
		const char *MailBoxName,
		const char *Pwd,
		const char *Descr);




/*
   Moses_MB_CreateFolder - create a folder on the mailbox
   CFG user need not to specify the password
   Input param
      MailBox         mailbox name
	  Pwd             mailbox password
	  Folder          folder to be created. "name" for folder on mailbox or
	                  name/name/name ... for subfolders

   The field CREATED is set to the current time
 */
STRING Moses_MB_CreateFolder(
		const char *MailBox, 
		const char *Pwd, 
		const char *Folder);


/*
   Moses_MB_DeleteFolder - delete logically a folder on the mailbox
 */
STRING Moses_MB_DeleteFolder(
		const char *MailBox, 
		const char *Pwd, 
		const char *Folder);

/*
   Moses_MB_ListFolder - list the folders on the specified folder
   out_Deleted is alway a vector of 0 (zero) if the client is not CFG
   otherwise the CFG gets even all the folder logically delete
   If the mailbox is "system" no password is required for no CFG users

   Input parameters
      Mailbox          mailbox name
	  Pwd              mailbox password
	  Folder           folder path
   
   Output parameters
      out_FolderList   list of folders
	  out_Deleted      flag indicating if the folder is logically deleted

 */
STRING Moses_MB_ListFolder(
		const char *MailBox,
		const char *Pwd,
		const char *Folder,
		VECT<STRING> &out_FolderList,
		VECT<INT16>  &out_Deleted);

/*
   Moses_MB_UndeleteFolder - undelete folder on the mailbox
 */
STRING Moses_MB_UndeleteFolder( /*R*/
		const char *MailBox, 
		const char *Pwd, 
		const char *Folder);


/*
   Moses_MB_GetNewId realease a new message identifier
 */
STRING Moses_MB_GetNewId(
		INT32 &out_MsgId);

/*
   Moses_MB_WriteInFolder - put a new message on the specified
   folder; if the folder is "in", "out" or "error" MOSES
   will trap the event handler

   The field CREATED of the message is set with the current time
 */
STRING Moses_MB_WriteInFolder(
		const char *MailboxName,
		const char *Pwd,
		const char *Folder,
		int         MsgId, 
		const char *Sender,
		const char *Destination,
		const char *Subject,
		int         bIncoming,
		int         szBody,
		const char *Body);


/*
   Moses_MB_ListMsg - list all the message that match the given condition.
   CFG users can access all the folders without specifying password
   Other users must match the password for full access or
   the mailbox must be "system" folder "in" "out" "error": in that case 
   this API returns only the file belonging to the connected user.
   In parameters
      MailBox         name of the mailbox
	  Pwd             password
	  Folder          folder inside the mailbox
	  Cond_UserField  "" no condition,  otherwise returns the msgs that have the specified user field
	  Cond_Accessed   "" no condition "Y" only accessed msg "N" not accessed msg
	  Cond_Sender     "" no condition, otherwise only msg with that sender
	  Cond_Receiver   "" no condition, otherwise only msg with that reciver
   Out parameters
      out_MsgIdList   list of message identifier matching the above conditions   

 */
STRING Moses_MB_ListMsg(
		const char *MailBox,
		const char *Pwd,
		const char *Folder,
		const char *Cond_UserField,
		const char *Cond_Accessed,   // "Y" for accessed "N" for not "" both
		const char *Cond_Sender,
		const char *Cond_Receiver,
		VECT<INT32> &out_MsgIdList);

/*
   Message attributes:
   Moses store for every msg a set of attributes with the following meaning

   	"CREATED    YYYYMMDDHHMMSS"   -- ts of creation of the message
   	"ACCESSED   YYYYMMDDHHMMSS"   -- ts of the last read of and APP client
   	"SENT       YYYYMMDDHHMMSS"   -- ts when the msg was sent to the MTD
	"DISPATCHED YYYYMMDDHHMMSS"   -- ts when the msg was sent across the MTD to the mailing system
   	"DELIVERED  YYYYMMDDHHMMSS"   -- ts when the remote computer receive the msg
   	"READ       YYYYMMDDHHMMSS"   -- ts when the remote user reads the msg
	"DELETED"

	The CREATED and the ACCESSED fields are set by monitor upon creation
	and read of the message itself

	SENT DISPATCHED DELIVERED READ are set by the MTD. If MTD has no way to
	retreive from mailing system deliver and remote read this field will be 
	blank.

	DELETED is a flag set by monitor upon a logical delete of a message
*/


/*
   Moses_Msg_GetInfo - retrive msg information
   out_Status is formatted this way
   	"CREATED    YYYYMMDDHHMMSS"   -- ts of creation of the message
   	"ACCESSED   YYYYMMDDHHMMSS"   -- ts of the last read of and APP client
   	"SENT       YYYYMMDDHHMMSS"   -- ts when the msg was tx to the MTD
	"DISPATCHED YYYYMMDDHHMMSS"   -- ts when the msg was sent across the MTD to the mailing system
   	"DELIVERED  YYYYMMDDHHMMSS"   -- ts when the remote computer receive the msg
   	"READ       YYYYMMDDHHMMSS"   -- ts when the remote user reads the msg
	"DELETED"
 */
STRING Moses_MB_GetInfo(
		const char  *MailboxName,
		const char  *Pwd,
		INT32        MsgId,
		VECT<STRING> &out_Status,
		STRING       &out_Sender,
		STRING       &out_Destination,
		STRING       &out_Subject,
		INT16        &out_bIncoming,
		INT32        &out_BodySize);


/*
   Moses_Msg_SetInfo - set msg information
   Status is formatted this way
   	"CREATED    YYYYMMDDHHMMSS"
   	"ACCESSED   YYYYMMDDHHMMSS"
   	"SENT       YYYYMMDDHHMMSS"
	"DISPATCHED YYYYMMDDHHMMSS"
   	"DELIVERED  YYYYMMDDHHMMSS"
   	"READ       YYYYMMDDHHMMSS"
	got with Moses_MB_GetInfo the status 
 */
STRING Moses_MB_SetInfo(
		const char   *MailboxName,
		const char   *Pwd,
		INT32         MsgId,
		VECT<STRING> &Status);


/*
   Moses_Msg_SetInfoEx - set msg information. CFG user do not need to specifiy
   Mailbox name and Pwd
   Input parameters:
     MailboxName    mail box containing message
	 Pwd            mail box password
	 MsgId          message identifier stored in MailboxName
	 Sender         specifies new message sender
	 Destination    specifies new message receiver
	 Subject        new subject
	 bIncoming      1 for incoming msg 0 for outcoming
	 Status         message status

   Status is formatted this way
   	"CREATED    YYYYMMDDHHMMSS"
   	"ACCESSED   YYYYMMDDHHMMSS"
   	"SENT       YYYYMMDDHHMMSS"
	"DISPATCHED YYYYMMDDHHMMSS"
   	"DELIVERED  YYYYMMDDHHMMSS"
   	"READ       YYYYMMDDHHMMSS"
	got with Moses_MB_GetInfo the status 
 */
STRING Moses_MB_SetInfoEx(
		const char   *MailboxName,
		const char   *Pwd,
		INT32         MsgId,
		STRING        Sender,
		STRING        Destination,
		STRING        Subject,
		INT16         bIncoming,
		VECT<STRING> &Status);


/*
   Moses_MB_MsgRead - read the boby msg

   If the Client is an APP client the field ACCESSED is set with the current
   time. Other client types doesn't affect that field
 */
STRING Moses_MB_MsgRead(
		const char *MailboxName,
		const char *Pwd,
		int         MsgId,
		STRING     &out_Body);

/*
 *	Moses_Log_NewMsgId.
*/

STRING Moses_Log_NewMsgId(
		const char *MailboxName,
		const char *Pwd,
		INT32       OldMsgId,
		INT32       NewMsgId);

/*
   Moses_MB_MsgFile - return complite path and file name relative to the MsgId
   Input params
      MsgId       message identifier
   Output params
      MsgFile     path name + file name
 */
STRING Moses_MB_MsgFile( /*R*/
		INT32   MsgId,
		STRING &MsgFile);

/*
   Moses_Msg_Delete - put in the delete state the specified
   message. The message will be deleted by MOSES when a programmable
   timeout will expire.
 */
STRING Moses_MB_Msg_Delete(
		const char *MailboxName,
		const char *Pwd,
		int MsgId);

/*
   Moses_MB_MoveMsg - move a msg identified from MsgId to a folder on the 
   same mailbox
   Input parameters
      MailboxName     mail box (source)
	  Pwd             mail box password (source)
	  MsgId           message to be moved
	  DestFolder      destination folder inside the mailbox
 */
STRING Moses_MB_MoveMsg(
		const char *MailboxName,
		const char *Pwd,
		int MsgId,
		const char *DestFolder);

/*
   Moses_MB_MoveMsg - move a msg identified from MsgId from a source folder
   to the another mailbox/folder
   Input parameters
      MailboxNameSource     mail box (source)
	  PwdSource             mail box password (source)
      MailboxNameDest       mail box (destination)
	  PwdDest               mail box password (destination)
	  MsgId                 message to be moved
	  DestFolder            destination folder inside the MailBoxNameDest
*/
STRING Moses_MB_MoveMsg2(
		const char *MailboxNameSource,
		const char *PwdSource,
		const char *MailboxNameDest,
		const char *PwdDest,
		int         MsgId,
		const char *DestFolder);

/*
   Moses_MB_Set_Userfield
 */
STRING Moses_MB_Set_Userfield(
		const char *Mailbox,
		const char *Pwd,
		int MsgId,
		const char *Value);

/*
   Moses_MB_Get_Userfield
 */
STRING Moses_MB_Get_Userfield(
		const char *Mailbox,
		const char *Pwd,
		int MsgId,
		STRING &out_Value);

/*
   Moses_MB_ListAllMsg - list all the message that match the given condition
   even the messages deleted
 */
STRING Moses_MB_ListAllMsg( /*R*/
		const char *MailBox,
		const char *Pwd,
		const char *Folder,
		const char *Cond_UserField,
		const char *Cond_Accessed,   // "Y" for accessed "N" for not "" both
		const char *Cond_Sender,
		const char *Cond_Receiver,
		VECT<INT32> &out_MsgIdList,
		VECT<INT16> &out_DeleteList);

/*
   Moses_MB_UndeleteMsg - try to undelete a previously deleted msg.
 */
STRING Moses_MB_UndeleteMsg( /*R*/
		int MsgId,
		INT16 &out_Recovered);

/*
   Moses_MB_Purge - purge the messages/folders deleted from the specified mail-box
 */
STRING Moses_MB_Purge( /*R*/
		const char *MailboxName,
		INT16 &out_Deleted);


/******************************************************************************/
/*
   File Managment Section - FM
*/

/*
    Moses_FM_ListFile - Displays the contents of a directory.
*/ 

STRING Moses_FM_ListFile ( /*R*/
		const char   *PathDir,
		VECT<STRING> &out_NameFile,
		VECT<STRING> &out_TypeFile,
		VECT<STRING> &out_DateFile,
		VECT<INT32>  &out_DimFile);

/*
 	Moses_FM_GetFile - Save in out_BodyFile the Body of File: StartPathNameFile. 
*/ 

STRING Moses_FM_GetFile ( /*R*/
		const char   *StartPathNameFile,
		STRING       &out_BodyFile);

/*
 	Moses_FM_PutFile - Put File.
*/ 

STRING Moses_FM_PutFile ( /*R*/
		const char   *FinalPathNameFile,
		const STRING &BodyFile);

/******************************************************************************/
/*
   Event Handling agreements - EH
   Every folder in a mail box has its own interchange profile table.
   The interchange profile specifies the action to be taken when a message
   is put on the a folder.
 */

/*
   Moses_EH_Add - insert a new entry on the EH.
   Input Parameters
   Folder folder path 
   Source MOSES source address
   Destination MOSES destination address
   MsgType message type field
   Action script to be invoked
   Index 1 if insert at top, -1 at botton, <n> insert at n-position
 */
STRING Moses_EH_Add( /*R*/
		const char *MailboxName,
		const char *Folder,
		const char *Source,
		const char *Destination,
		const char *Subject,
		const char *Action,
		int Index);

/*
   Moses_EH_List - lists all the entries on EH
   Input parameters
   Index index on EH, starting from 1
   Output parameters
   out_Folder
   out_Source
   out_Destination
   out_Action
   out_Valid
 */
STRING Moses_EH_List( /*R*/
		int Index,
		const char *MailboxName,
		const char *Folder,
		STRING &out_Source,
		STRING &out_Destination,
		STRING &out_Subject,
		STRING &out_Action,
		INT16 &out_Valid);


/*
   Moses_EH_Delete - remove entry relative to Index
   Input parameters:
   Index index in EH
   Output parameters:
   out_Valid 1 if valid 0 elsewhere

Remarks: its better to remove starting from last entry.
*/
STRING Moses_EH_Delete( /*R*/
		const char *MailboxName,
		const char *Folder,
		int Index,
		INT16 &out_Valid);

/*
   Moses_EH_Count - count entries relative
Remarks: its better to remove starting from last entry.
 */
STRING Moses_EH_Count( /*R*/
		const char *MailboxName,
		const char *Folder,
		INT16 &out_Count);

// /*
//    Moses_EH_ListFolder - lists all the entries relative to that folder
//    Input  parameters:
//    Folder folder to be listed
//    Output parameters:
//    out_sz number of matching entires
//    out_Index list of indexes of matching entries
//  */
// STRING Moses_EH_ListFolder(
// 		const char *Folder,
// 		INT16 &out_sz,
// 		INT16 *&out_Index);
// 
// /*
//   Moses_EH_ListFolderDestination - lists all the entries to the Folder
//   and Destination
//   Input  parameters:
//   Folder folder to be listed
//   Destination
//   Output parameters:
//   out_sz number of matching entires
//   out_Index list of indexes of matching entries
// */
// STRING Moses_EH_ListFolderDestination(
//		const char *Folder, 
//		const char *Destination,
//		INT16 &out_sz,
//		INT16 *&out_Index);
//
// /*
//   Moses_EH_ListFolderSource 
//   Input  parameters:
//   Folder folder to be listed
//   Source Moses source address to be listed
//   Output parameters:
//   out_sz number of matching entires
//   out_Index list of indexes of matching entries
// */
// STRING Moses_EH_ListFolderSource(
//		const char *Folder, 
//		const char *Source, 
//		INT16 &out_sz, 
//		INT16 *&out_Index);

/***********************************************************************************/
/*
	Moses Scripting language section - MSL
	MSL deals with the actual MSL programs installed on the Moses system

	MSLName is an unique name in the moses system. That entry is used on ITG
	Descr   is the description that should be given on the configuration tool
*/
STRING Moses_MSL_Add    /*R*/ (
		const char *MSLName,
		const char *Descr);

STRING Moses_MSL_Modify /*R*/ (
		const char *MSLName, 
		const char *Descr);

STRING Moses_MSL_Delete /*R*/ (const char *MSLName);

STRING Moses_MSL_List   /*R*/ (
		VECT<STRING> &out_MSLNameList, 
		VECT<STRING> &out_DescrList);

/***********************************************************************************/

/*
   Mail system types MS
   MOSES records all mail box system types in this table
 */

/*
   Moses_MS_Add - add a new mail box type to the Mailbox system types
   Mail box types cannot be duplicated.
   Input parameters:
   MailBoxId mail box identifier inside MOSES
   MailTypeDescr remarks on the mail box type
 */
STRING Moses_MS_Add( /*R*/
		const char *MailBoxType, 
		const char *MailBoxTypeDescr);

/*
   Moses_MS_List return the mailbox type name in the Index position
   on the table
   Input parameters
   Index index entry on the User table
   Output parameters
   out_MailBoxId mail box type identifier
   out_MailTypeDescr mailbox type required
   out_Valid  if 1 Index is valid else 0 index is not valid
 */
STRING Moses_MS_List( /*R*/
		VECT<STRING> &out_MailBoxTypeList, 
		VECT<STRING> &out_MailBoxTypeDescrList);

/*
   Moses_MS_Delete deletes the specified mailbox type; if cascade 
   option is set the moses deletes all the entries relative to that 
   mailbox type (ART, ITG)
 */
STRING Moses_MS_Delete( /*R*/
		const char *MailBoxType);

/*
	Moses_MS_GetConfFile
	Retreive the configuration file on the selected MailBoxType and OS
	version. The caller must put in the pPathToStore the path of the writing 
	file.
	On return out_FileName point to the filename received (on file name not path)
*/

/* 
 *	NON Implementato
 *
STRING Moses_MS_GetConfFile(
		const char *MailBoxType,
		const char *OSType,
		const char *pPathToStore,
		STRING &out_FileName);
*/

		
/******************************************************************************/
/*
   Address resolution table - ART
   The address resolution table is used by MOSES for translating MOSES 
   addresses in/for other mail system addressing schemas.
   Every MOSES user can have other mail system addressing schemas.
   Every MOSES user can have more ingoing address
   as more outgoing addresses systems.
 */

/*
   Moses_ART_Add - add a new field in the ART
   Input parameters:
   UserName        user name in MOSES
   bInternal       1 for internal users 0 for external
   MailBoxType     mail box type identifier in MOSES
   MailBoxAddress  mail box address on the external mail box system
   SubjectAdd      is the subject to insert into the message in order to manager
                   unique mail box addressing for multiple users
 */
STRING Moses_ART_Add( /*R*/
		const char *UserName, 
		int         bInternal,
		const char *MailBoxType, 
		const char *MailBoxAddress,
		const char *SubjectAdd);

/*
   Moses_ART_Modify - modify matching field in the ART; it is possible to 
                      modify only MailBoxAddress and SubjectAdd

   Input parameters:
   UserName       moses user name
   bInternal      1 for iternal user 0 for external
   MailBoxType    mail box type identifier in MOSES
   MailBoxAddress mail box address on the external mail box system
   SubjectAdd     is the subject to insert into the message in order to manager
                  unique mail box addressing for multiple users
 */
STRING Moses_ART_Modify( /*R*/
		const char *UserName, 
		int         bInternal,
		const char *MailBoxType, 
		const char *MailBoxAddress,
		const char *SubjectAdd);

/*
   Moses_ART_OutAddress - Retrive the external address of type MailBoxType
   specified, associated to the selected user. Note that the user can be
   iternal or external
   If the MailType is "" MOSES returns the first address in the ART


 */
STRING Moses_ART_OutAddress( /*R*/
		const char *UserName,
		const char *MailBoxType,
		STRING &out_MailBoxType,
		STRING &out_MailAddress,
		STRING &out_SubjectAdd);

/*
   Moses_ART_InAddress - Retrive the MOSES user name relative
   to the specified address. The address can be associated to an internal or
   external MOSES user.
   Input params:
		MailBoxType      mail box
		MailAddress      external mail address
		SubjectAdd       message subject
   Output params
        out_UserName     moses user name
 */
STRING Moses_ART_InAddress( /*R*/
		const char *MailBoxType,
		const char *MailAddress,
		const char *SubjectAdd,
		STRING &out_UserName);

/*
   Moses_ART_List
   Input parameters
   Index index entry on the ART
   Output parameters
   out_UserName user name
   out_bInternal    1 for internal user 0 for external
   out_MailTypeId mail box type id
   out_MailBoxAddress address related to  the mail box
   out_Valid  if 1 Index is valid else 0 index is not valid
 */
STRING Moses_ART_List( /*R*/
		int Index,
		STRING &out_UserName, 
		INT16  &out_bInternal,
		STRING &out_MailBoxType,
		STRING &out_MailBoxAddress,
		STRING &out_SubjectAdd,
		INT16  &out_Valid);

/*
   Moses_ART_ListUsers list all the users (internal or external) of a given
   mailbox type.
   Input parameters
   MailBoxType    mail box type or empty string for all the mailing systems
   bInternal      1 for internal users 0 for external
   Output parameters
   out_UsersList  users list
 */
STRING Moses_ART_ListUsers( /*R*/
		const char   *MailBoxType,
		INT16        bInternal,
		VECT<STRING> &out_UsersList);

/*
   Moses_ART_ListAddresses - retreive the list of distinct addresses of internal
   or external moses users
   Input parameters
   MailBoxType      mail box type 
   bInternal        1 for internal users, 0 external
   Output parameters
   out_UsersList    addresses list
 */
STRING Moses_ART_ListAddresses( /*R*/
		const char *MailBoxType,
		INT16         bInternal,
		VECT<STRING>  &out_MailAddresses);

/*
   Moses_ART_Delete - deletes the entry relative to UserName
   If the MailBoxType is empty delete the first entry relative to that user
   Input parameters:
   UserName      user name in MOSES
   bInternal     1 for internal 0 for external user
   MailBoxType   mail box type identifier in MOSES
 */
STRING Moses_ART_Delete( /*R*/
		const char *UserName, 
		int         bInternal,
		const char *MailBoxType);


/******************************************************************************/
/*
 * Alert section
 * This section is used by the MOSES clients to setup an event handler
 * on message receive
 */

/*
   Moses_Event_NewMsgInFolder - with this call MOSES will trap a callback to
   client when a MOSES msg is stored in a folder
   Input parameters:
   MailBoxName 
   Folder	    folder path name. Folder "" means every the folder in the mail box

   Output       par
   out_EventId  the token to obtain when the event occurs
 */
STRING Moses_Event_NewMsgInFolder(
		const char *MailBoxName,
		const char *Pwd,
		const char *Folder,
		INT32 &out_EventId);

/*
   Moses_Event_Handler_NewMsgInFolder - on the event specified retrive
   the event data
 */
STRING Moses_Event_Alert_NewMsgInFolder(
		int EventId,
		INT32 &out_MsgId,
		STRING &out_Folder);

// Funzioni non implementate --> dubito che siano giuste
// /*
//    Moses_Event_NewMsgForUser - with this call MOSES will trap a callback to
//    a client when MOSES receive a msg on a folder owned by the user
//  */
// STRING Moses_Event_NewMsgForUser(
// 		const char *User,
// 		INT32 &out_EventId);
// 
// /*
//    Moses_Event_Alert_NewMsgInFolder - on the event specified retrive
//    the event data
//  */
// STRING Moses_Event_Alert_NewMsgForUser(
// 		int EventId,
// 		INT32 &out_MsgId,
// 		STRING &out_User);

/*
   Moses_Event_NewMsgForMTD - with this call MOSES will trap a callback to
   a MTD client when MOSES receive a msg on system.out MB on the specified MS
 */
STRING Moses_Event_NewMsgForMTD(
		const char *MailType,
		INT32 &out_EventId);

/*
   Moses_Event_Alert_NewMsgForMTD - on the event specified retrive
   the event data
 */
STRING Moses_Event_Alert_NewMsgForMTD(
		int EventId,
		INT32 &out_MsgId);

/*
   Moses_Event_GetEvent - This function retrives an EventId from MOSES
   Input Parameters:
   mSec	milliseconds to wait. If time expires out_EventId is set to 0
   Output Parametes:
   out_EventId	the event id
 */
STRING Moses_Event_GetEvent(int mSec, INT32 &out_EventId);

/*
   Moses_Event_Delete - reset an event handler
   Input parameters:
   EventID	the event id
 */
STRING Moses_Event_Delete(
		int EventID);


/*
   Moses_Event_GetMsg - This function retrives a msg-API from the network.
   From the client side a Moses_Connection_GetMsg can return an event handler
   message. On the server side can be every msg-API described in this file.
   Input Parameters:
   mSec	milliseconds to wait. If time expires out_sz is set to 0
   Output Parametes:
   out_Msg	the message body
 */
STRING Moses_Event_GetMsg(int mSec, STRING &out_Msg);












/******************************************************************************/
/*
 * Client section
 * The client list on MOSES is the list of all the MOSES clients to be run 
 * on MOSES start up or reload.
 * The type of clients can be IDT MTD APP SRC.
 * MOSES can start a new client, kill a running client or list, add,
 * delete an entry on the client list.
 */

/*
   Moses_Client_Add adds a client to the CLI
   list of all clients to be run at startup on MOSES.
   The clients can be MTD IDT APP SCR. 
   Input parameters:
   ClientName the complete path/command arguments
   ClientDescr client description
   ClientType client type
   Active  if 1 the client must be run on MOSES startup
 */
STRING Moses_Client_Add(
		const char *ClientName,
		const char *ClientDescr,
		const char *ClientType,
		int Active);

/*
	Moses_Client_Modify - modifies the fields in the Client entry
	Input parameters:
	ClientName the complete path/command arguments
	ClientDescr client description
	ClientType client type
	Active
*/
STRING Moses_Client_Modify(
		const char *ClientName,
		const char *ClientDescr,
		const char *ClientType,
		int Active);

/*
   Moses_Client_List lists all the clients on MOSES
   Input Parameters.
   Output Parameters:
   out_ClientNameList client name
   out_ClientDescrList client description
   out_ActiveList if 1 MOSES at startup run the client, 0 otherwise
 */
STRING Moses_Client_List(
		VECT<STRING> &out_ClientNameList,
		VECT<STRING> &out_ClientDescrList,
		VECT<STRING> &out_ClientTypeList,
		VECT<INT16>  &out_ActiveList);

/*
   Moses_Client_Delete
   Input parameters:
   ClientName deletes the specified client on the client list
 */
STRING Moses_Client_Delete(
		const char *ClientName);

/*
   Moses_Client_Run start the Index entry on the client list.
   The specified client cannot yet run when this command is issued
   Input parameters
   ClientName of the program to run
 */
STRING Moses_Client_Run(
		const char *ClientName);

/*
   Moses_Client_Kill  ends the specified client running on MOSES
   Input parameters
   Name of the client to kill
 */
STRING Moses_Client_Kill(
		const char *ClientName);

/*
   Moses_Client_RunningList list all the clients currently running
   on the MOSES system.
   Output parameters
   out_ClientNameList list of all the clients currently running
 */
STRING Moses_Client_RunningList(
		VECT<STRING> &out_ClientNameList);

/******************************************************************************/
/*
 * Scheduler section
 * MOSES can run MSL script on time basis
 */

/*
   Moses_Scheduler_Add	add scheduler even on MOSES
   When	string describing the time basis
   format HH MM WD GG MM YYYY
   where WD if 0-7 0=Sunday
   every field can be a
   <number> or <number>-<number> or <number>[,<number>]*
   0 0 0 0 0 0 format means at start up.
   default value *
   eg 12 0 * * * * run every day at 12:00
   eg *  0 * * * * run every hour
   eg *  * 0 * * * run every Sunday
   eg *  0,10,20,30,40,50 * * * * * run every 10 minutes

   N.B. <number>-<number> and <number>[,<number>]* is not currently implemented

   if Action format is "##MTD<type MTD>" run MTD event.

   What string describing the MSL program to run
 */
STRING Moses_Scheduler_Add    /*R*/ (const char *When, const char *Action);
STRING Moses_Scheduler_List   /*R*/ (
		VECT<INT16> &Index_out, 
		VECT<STRING> &When_out, 
		VECT<STRING> &What_out);

STRING Moses_Scheduler_Delete /*R*/ (INT16 Index);

/******************************************************************************/
/*
 * Log section
 * MOSES can log messages from clients MOSES
 * these messages are usefull for debugging MSL programs
 * and for log the activities of all client in a unique log file
 */

/*
   Moses_Log	log a string to the main log file
 */
STRING Moses_Log(int clientId, const char *LogMsg);

/******************************************************************************/
/*
 *  OL Section
 */

STRING Moses_OL_Set	/*R*/ (
		const char *DaysAccessed, 
		const char *DaysSent, 
		const char *DaysDispatched);

STRING Moses_OL_Get	/*R*/ (
		STRING &out_DaysAccessed, 
		STRING &out_DaysSent, 
		STRING &out_DaysDispatched);


/******************************************************************************/
/*
 *  Licence Section
 */

STRING Moses_Licence_Set	/*R*/ (const char *Pwd, const char *Date);
STRING Moses_Licence_Get	/*R*/ (STRING     &out_Date);

/******************************************************************************/
STRING mGetCurrentTime();

#endif
