#include <st_dbnew.h>
#ifndef __Moses_MB_SetInfoEx_h__
#define __Moses_MB_SetInfoEx_h__

#include "gnricmsg.h"

class c_Moses_MB_SetInfoEx : public GenericMsg
{
public:

	STRING       MailBoxName;
	STRING       Pwd;
	INT32        MsgId;
	STRING       Sender;
	STRING       Destination;
	STRING       Subject;
	INT16        bIncoming;
	VECT<STRING> Status;

	c_Moses_MB_SetInfoEx();
	c_Moses_MB_SetInfoEx(const c_Moses_MB_SetInfoEx &r);
	~c_Moses_MB_SetInfoEx();

	Declare_Class(c_Moses_MB_SetInfoEx);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_SetInfoEx : public GenericMsg
{
public:

	STRING Error;
	
	a_Moses_MB_SetInfoEx(const char *pErr);
	a_Moses_MB_SetInfoEx();

	a_Moses_MB_SetInfoEx(const a_Moses_MB_SetInfoEx &r);

	~a_Moses_MB_SetInfoEx();

	Declare_Class(a_Moses_MB_SetInfoEx);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
