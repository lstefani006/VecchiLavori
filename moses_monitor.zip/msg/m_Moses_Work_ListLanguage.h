#include <st_dbnew.h>
#ifndef __Moses_Work_ListLanguage_h__
#define __Moses_Work_ListLanguage_h__

#include "gnricmsg.h"


class c_Moses_Work_ListLanguage : public GenericMsg
{
public:
	c_Moses_Work_ListLanguage();
	c_Moses_Work_ListLanguage(const c_Moses_Work_ListLanguage &r);
	~c_Moses_Work_ListLanguage();
	Declare_Class(c_Moses_Work_ListLanguage);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Work_ListLanguage : public GenericMsg
{
public:
	STRING Error;

	VECT<STRING> ListCodLang;
	VECT<STRING> ListDesLang;

	a_Moses_Work_ListLanguage(const char *pErr);
	a_Moses_Work_ListLanguage();
	a_Moses_Work_ListLanguage(const a_Moses_Work_ListLanguage &r);
	~a_Moses_Work_ListLanguage();
	Declare_Class(a_Moses_Work_ListLanguage);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
