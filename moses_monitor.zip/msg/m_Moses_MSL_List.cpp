#include <st_dbnew.h>
#include "m_Moses_MSL_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MSL.h"
#endif


c_Moses_MSL_List::c_Moses_MSL_List()
{
}

c_Moses_MSL_List::c_Moses_MSL_List(const c_Moses_MSL_List &r)
{
}

c_Moses_MSL_List::~c_Moses_MSL_List() {}


void c_Moses_MSL_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_MSL_List::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_MSL_List);

GenericMsg * c_Moses_MSL_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MSL_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MSL_List::a_Moses_MSL_List(const char *pErr) { Error = pErr; }
a_Moses_MSL_List::a_Moses_MSL_List()
{
}

a_Moses_MSL_List::a_Moses_MSL_List(const a_Moses_MSL_List &r)
{
	Error	    = r.Error;
	MSLNameList  = r.MSLNameList;
	MSLDescrList = r.MSLDescrList;
}

a_Moses_MSL_List::~a_Moses_MSL_List()
{
}

void a_Moses_MSL_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(MSLNameList, b, d);
	pSer->Serialize(MSLDescrList, b, d);
}

void a_Moses_MSL_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error        " << Error        << endl;
	s << "MSLNameList  " << MSLNameList  << endl;
	s << "MSLDescrList " << MSLDescrList << endl;
}

Implement_Class(a_Moses_MSL_List);

GenericMsg * a_Moses_MSL_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_MSL_List(
		VECT<STRING> &out_MSLNameList,
		VECT<STRING> &out_MSLDescrList)
{
	c_Moses_MSL_List m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MSL_List::IdMsg)
	{
		a_Moses_MSL_List *answ = (a_Moses_MSL_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_MSLNameList  = answ->MSLNameList;
			out_MSLDescrList = answ->MSLDescrList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

///////////////////////////////////////////////////////////////////////////////
