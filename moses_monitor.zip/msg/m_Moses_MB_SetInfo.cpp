#include <st_dbnew.h>
#include "m_Moses_MB_SetInfo.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_SetInfo::c_Moses_MB_SetInfo()
{
}

c_Moses_MB_SetInfo::c_Moses_MB_SetInfo(const c_Moses_MB_SetInfo &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
	MsgId    		= r.MsgId;
	Status          = r.Status;
}

c_Moses_MB_SetInfo::~c_Moses_MB_SetInfo() {}


void c_Moses_MB_SetInfo::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(MsgId, b, d);
	pSer->Serialize(Status, b, d);
}

void c_Moses_MB_SetInfo::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName " << MailBoxName << endl;
	s << "\tPwd         " << Pwd         << endl;
	s << "\tMsgId       " << MsgId       << endl;
	s << "\tStatus      " << Status      << endl;
}

Implement_Class(c_Moses_MB_SetInfo);



GenericMsg * c_Moses_MB_SetInfo::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_SetInfo(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_SetInfo::a_Moses_MB_SetInfo(const char *pErr) { Error = pErr; }
a_Moses_MB_SetInfo::a_Moses_MB_SetInfo() {}

a_Moses_MB_SetInfo::a_Moses_MB_SetInfo(const a_Moses_MB_SetInfo &r)
{
	Error		= r.Error;
}

a_Moses_MB_SetInfo::~a_Moses_MB_SetInfo() {}

void a_Moses_MB_SetInfo::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_SetInfo::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError " << Error << endl;
}

Implement_Class(a_Moses_MB_SetInfo);

GenericMsg * a_Moses_MB_SetInfo::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_SetInfo(const char   *MailBoxName, 
					    const char   *Pwd,
					    INT32        MsgId,
					    VECT<STRING> &Status)
{
	c_Moses_MB_SetInfo m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.MsgId   	    = MsgId;
	m.Status   	    = Status;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_SetInfo::IdMsg)
	{
		a_Moses_MB_SetInfo *answ = (a_Moses_MB_SetInfo *)pMsg;

		if (answ->Error.Len() == 0)
		{
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

