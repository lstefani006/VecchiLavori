#include <st_dbnew.h>
#ifndef __Moses_Log_NewMsgId_h__
#define __Moses_Log_NewMsgId_h__

#include "gnricmsg.h"

class c_Moses_Log_NewMsgId : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Pwd;
	INT32  OldMsgId;
	INT32  NewMsgId;

	c_Moses_Log_NewMsgId();
	c_Moses_Log_NewMsgId(const c_Moses_Log_NewMsgId &r);
	~c_Moses_Log_NewMsgId();

	Declare_Class(c_Moses_Log_NewMsgId);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_Log_NewMsgId : public GenericMsg
{
public:

	STRING Error;
	
	a_Moses_Log_NewMsgId(const char *pErr);
	a_Moses_Log_NewMsgId();

	a_Moses_Log_NewMsgId(const a_Moses_Log_NewMsgId &r);

	~a_Moses_Log_NewMsgId();

	Declare_Class(a_Moses_Log_NewMsgId);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
