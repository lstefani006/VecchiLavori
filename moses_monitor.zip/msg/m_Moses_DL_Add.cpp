#include <st_dbnew.h>
#include "m_Moses_DL_Add.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "DL.h"
#endif

c_Moses_DL_Add::c_Moses_DL_Add()
{
}

c_Moses_DL_Add::c_Moses_DL_Add(const c_Moses_DL_Add &r)
{
	DLName      = r.DLName;
	DLPwd       = r.DLPwd;
	DLDescr     = r.DLDescr;
}

c_Moses_DL_Add::~c_Moses_DL_Add() {}


void c_Moses_DL_Add::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(DLName, b, d);
	pSer->Serialize(DLPwd,  b, d);
	pSer->Serialize(DLDescr,b, d);
}

void c_Moses_DL_Add::Print(ostream &s) const
{
	BASE::Print(s);
	s << "DLName     " << DLName      << endl;
	s << "DLPwd      " << DLPwd       << endl;
	s << "DLDescr    " << DLDescr     << endl;
}

Implement_Class(c_Moses_DL_Add);


GenericMsg * c_Moses_DL_Add::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return DL_Add(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_DL_Add::a_Moses_DL_Add(const char *pErr) { Error = pErr; }
a_Moses_DL_Add::a_Moses_DL_Add() {}

a_Moses_DL_Add::a_Moses_DL_Add(const a_Moses_DL_Add &r)
{
	Error	= r.Error;
}

a_Moses_DL_Add::~a_Moses_DL_Add() {}

void a_Moses_DL_Add::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_DL_Add::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_DL_Add);



GenericMsg * a_Moses_DL_Add::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_DL_Add(const char *DLName, const char *DLPwd, const char *DLDescr)
{
	c_Moses_DL_Add m;

	m.DLName 		= DLName;
	m.DLDescr   	= DLDescr;
	m.DLPwd     	= DLPwd;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_DL_Add::IdMsg)
	{
		a_Moses_DL_Add *answ = (a_Moses_DL_Add *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


