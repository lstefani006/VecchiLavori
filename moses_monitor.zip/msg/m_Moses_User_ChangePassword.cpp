#include <st_dbnew.h>
#include "m_Moses_User_ChangePassword.h"
#include "m_Error.h"


#ifdef MOSES_SERVER
	#include "User.h"
#endif

c_Moses_User_ChangePassword::c_Moses_User_ChangePassword()
{
}

c_Moses_User_ChangePassword::c_Moses_User_ChangePassword(const c_Moses_User_ChangePassword &r)
{
	User            = r.User;
	PwdOld      	= r.PwdOld;
	PwdNew    		= r.PwdNew;
}

c_Moses_User_ChangePassword::~c_Moses_User_ChangePassword() {}


void c_Moses_User_ChangePassword::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(User,   b, d);
	pSer->Serialize(PwdOld, b, d);
	pSer->Serialize(PwdNew, b, d);
}

void c_Moses_User_ChangePassword::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tUser       " << User        << endl;
	s << "\tPwdOld     " << PwdOld      << endl;
	s << "\tPwdNew     " << PwdNew      << endl;
}

Implement_Class(c_Moses_User_ChangePassword);



GenericMsg * c_Moses_User_ChangePassword::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return User_ChangePassword(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_User_ChangePassword::a_Moses_User_ChangePassword(const char *pErr) { Error = pErr; }
a_Moses_User_ChangePassword::a_Moses_User_ChangePassword() {}

a_Moses_User_ChangePassword::a_Moses_User_ChangePassword(const a_Moses_User_ChangePassword &r)
{
	Error	= r.Error;
}

a_Moses_User_ChangePassword::~a_Moses_User_ChangePassword() {}

void a_Moses_User_ChangePassword::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_User_ChangePassword::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError " << Error  << endl;
}

Implement_Class(a_Moses_User_ChangePassword);

GenericMsg * a_Moses_User_ChangePassword::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_User_ChangePassword(const char *User, 
							   const char *PwdOld,
							   const char *PwdNew)
{
	c_Moses_User_ChangePassword m;

	m.User 	        = User;
	m.PwdOld     	= PwdOld;
	m.PwdNew   	    = PwdNew;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_User_ChangePassword::IdMsg)
	{
		a_Moses_User_ChangePassword *answ = (a_Moses_User_ChangePassword *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

