#include <st_dbnew.h>
#include "m_Moses_MB_Set_Userfield.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif

c_Moses_MB_Set_Userfield::c_Moses_MB_Set_Userfield()
{
}

c_Moses_MB_Set_Userfield::c_Moses_MB_Set_Userfield(const c_Moses_MB_Set_Userfield &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
	MsgId    		= r.MsgId;
	Value    		= r.Value;
}

c_Moses_MB_Set_Userfield::~c_Moses_MB_Set_Userfield() {}


void c_Moses_MB_Set_Userfield::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(MsgId, b, d);
	pSer->Serialize(Value, b, d);
}

void c_Moses_MB_Set_Userfield::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName " << MailBoxName << endl;
	s << "\tPwd         " << Pwd         << endl;
	s << "\tMsgId       " << MsgId       << endl;
	s << "\tValue       " << Value       << endl;
}

Implement_Class(c_Moses_MB_Set_Userfield);



GenericMsg * c_Moses_MB_Set_Userfield::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_Set_Userfield(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_Set_Userfield::a_Moses_MB_Set_Userfield(const char *pErr) { Error = pErr; }
a_Moses_MB_Set_Userfield::a_Moses_MB_Set_Userfield() {}

a_Moses_MB_Set_Userfield::a_Moses_MB_Set_Userfield(const a_Moses_MB_Set_Userfield &r)
{
	Error	= r.Error;
}

a_Moses_MB_Set_Userfield::~a_Moses_MB_Set_Userfield() {}

void a_Moses_MB_Set_Userfield::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_Set_Userfield::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError  " << Error << endl;
}

Implement_Class(a_Moses_MB_Set_Userfield);

GenericMsg * a_Moses_MB_Set_Userfield::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_Set_Userfield (const char   *MailBoxName, 
						       const char   *Pwd,
						   	   int           MsgId,
						       const char   *Value)
{
	c_Moses_MB_Set_Userfield m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.MsgId         = MsgId;
	m.Value         = Value;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_Set_Userfield::IdMsg)
	{
		a_Moses_MB_Set_Userfield *answ = (a_Moses_MB_Set_Userfield *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

