#include <st_dbnew.h>
#include "m_Moses_MB_GetInfo.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_GetInfo::c_Moses_MB_GetInfo()
{
}

c_Moses_MB_GetInfo::c_Moses_MB_GetInfo(const c_Moses_MB_GetInfo &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
	MsgId    		= r.MsgId;
}

c_Moses_MB_GetInfo::~c_Moses_MB_GetInfo() {}


void c_Moses_MB_GetInfo::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(MsgId, b, d);
}

void c_Moses_MB_GetInfo::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName  " << MailBoxName  << endl;
	s << "\tPwd          " << Pwd          << endl;
	s << "\tMsgId        " << MsgId        << endl;
}

Implement_Class(c_Moses_MB_GetInfo);



GenericMsg * c_Moses_MB_GetInfo::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_GetInfo(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_GetInfo::a_Moses_MB_GetInfo(const char *pErr) { Error = pErr; }
a_Moses_MB_GetInfo::a_Moses_MB_GetInfo() {}

a_Moses_MB_GetInfo::a_Moses_MB_GetInfo(const a_Moses_MB_GetInfo &r)
{
	Error		= r.Error;
	Status		= r.Status;
	Sender		= r.Sender;
	Destination	= r.Destination;
	Subject		= r.Subject;
	BodySize	= r.BodySize;
	bIncoming   = r.bIncoming;
}

a_Moses_MB_GetInfo::~a_Moses_MB_GetInfo() {}

void a_Moses_MB_GetInfo::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(Status, b, d);
	pSer->Serialize(Sender, b, d);
	pSer->Serialize(Destination, b, d);
	pSer->Serialize(Subject, b, d);
	pSer->Serialize(BodySize, b, d);
	pSer->Serialize(bIncoming, b, d);
}

void a_Moses_MB_GetInfo::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError       " << Error       << endl;
	s << "\tStatus      " << Status      << endl;
	s << "\tSender      " << Sender      << endl;
	s << "\tDestination " << Destination << endl;
	s << "\tSubject     " << Subject     << endl;
	s << "\tBodySize    " << BodySize    << endl;
	s << "\tbIncoming   " << bIncoming   << endl;
}

Implement_Class(a_Moses_MB_GetInfo);

GenericMsg * a_Moses_MB_GetInfo::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_GetInfo(const char   *MailBoxName, 
					    const char   *Pwd,
					    INT32        MsgId,
					    VECT<STRING> &out_Status,
					    STRING       &out_Sender,
					    STRING       &out_Destination,
					    STRING       &out_Subject,
						INT16        &out_bIncoming,
						INT32        &out_BodySize)
{
	c_Moses_MB_GetInfo m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.MsgId   	    = MsgId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_GetInfo::IdMsg)
	{
		a_Moses_MB_GetInfo *answ = (a_Moses_MB_GetInfo *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_Status      = answ->Status;
				out_Sender      = answ->Sender;
				out_Destination = answ->Destination;
				out_Subject     = answ->Subject;
				out_bIncoming   = answ->bIncoming;
				out_BodySize    = answ->BodySize;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_GetInfo(const char   *MailBoxName, 
					    const char   *Pwd,
					    INT32        MsgId,
					    VECT<STRING> &out_Status)
{
	c_Moses_MB_GetInfo m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.MsgId   	    = MsgId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_GetInfo::IdMsg)
	{
		a_Moses_MB_GetInfo *answ = (a_Moses_MB_GetInfo *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_Status      = answ->Status;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

