#include <st_dbnew.h>
#include "m_Moses_User_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
    #include "User.h"
	#include "server.h"
#endif


c_Moses_User_List::c_Moses_User_List()
{
}

c_Moses_User_List::c_Moses_User_List(const c_Moses_User_List &r)
{
	Index = r.Index;
}

c_Moses_User_List::~c_Moses_User_List() {}


void c_Moses_User_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Index, b, d);
}

void c_Moses_User_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Index     " << Index      << endl;
}

Implement_Class(c_Moses_User_List);


GenericMsg * c_Moses_User_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return User_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_User_List::a_Moses_User_List(const char *pErr) { Error = pErr; }
a_Moses_User_List::a_Moses_User_List() {}

a_Moses_User_List::a_Moses_User_List(const a_Moses_User_List &r)
{
	Error            = r.Error;
	UserName         = r.UserName;
	UserPwd          = r.UserPwd;
	UserClientType   = r.UserClientType;
	UserDescr        = r.UserDescr;
	UserRights       = r.UserRights;
	UserDefaultMBox  = r.UserDefaultMBox;
	UserKeyId        = r.UserKeyId;
	Valid            = r.Valid;
}

a_Moses_User_List::~a_Moses_User_List() {}

void a_Moses_User_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error,     b, d);
	pSer->Serialize(UserName,  b, d);
	pSer->Serialize(UserPwd, b, d);
	pSer->Serialize(UserClientType, b, d);
	pSer->Serialize(UserDescr, b, d);
	pSer->Serialize(UserRights, b, d);
	pSer->Serialize(UserDefaultMBox, b, d);
	pSer->Serialize(UserKeyId, b, d);
	pSer->Serialize(Valid,     b, d);
}

void a_Moses_User_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error           " << Error            << endl;
	s << "UserName        " << UserName         << endl;
	s << "UserPwd         " << UserPwd          << endl;
	s << "UserClientType  " << UserClientType   << endl;
	s << "UserDescr       " << UserDescr        << endl;
	s << "UserRights      " << UserRights       << endl;
	s << "UserDefaultMBox " << UserDefaultMBox  << endl;
	s << "UserKeyId       " << UserKeyId        << endl;
	s << "Valid           " << Valid            << endl;
}

Implement_Class(a_Moses_User_List);


GenericMsg * a_Moses_User_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_User_List(INT32 Index,
					   STRING &out_UserName, 
					   STRING &out_UserPwd, 
					   STRING &out_UserClientType, 
					   STRING &out_UserDescr, 
					   STRING &out_UserRights, 
					   STRING &out_UserDefaultMBox, 
					   STRING &out_UserKeyId, 
					   INT16  &out_Valid)
{
	c_Moses_User_List m;

	m.Index = Index;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_User_List::IdMsg)
	{
		a_Moses_User_List *answ = (a_Moses_User_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_UserName 	    = answ->UserName;
			out_UserPwd 	    = answ->UserPwd;
			out_UserClientType 	= answ->UserClientType;
			out_UserDescr 	    = answ->UserDescr;
			out_UserRights 	    = answ->UserRights;
			out_UserDefaultMBox = answ->UserDefaultMBox;
			out_UserKeyId 	    = answ->UserKeyId;
			out_Valid 		    = answ->Valid;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

