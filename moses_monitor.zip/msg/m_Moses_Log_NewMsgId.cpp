#include <st_dbnew.h>
#include "m_Moses_Log_NewMsgId.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_Log_NewMsgId::c_Moses_Log_NewMsgId()
{
}

c_Moses_Log_NewMsgId::c_Moses_Log_NewMsgId(const c_Moses_Log_NewMsgId &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
	OldMsgId    	= r.OldMsgId;
	NewMsgId	    = r.NewMsgId;
}

c_Moses_Log_NewMsgId::~c_Moses_Log_NewMsgId() {}


void c_Moses_Log_NewMsgId::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(OldMsgId, b, d);
	pSer->Serialize(NewMsgId, b, d);
}

void c_Moses_Log_NewMsgId::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName " << MailBoxName << endl;
	s << "\tPwd         " << Pwd         << endl;
	s << "\tOldMsgId    " << OldMsgId    << endl;
	s << "\tNewMsgId    " << NewMsgId    << endl;
}

Implement_Class(c_Moses_Log_NewMsgId);



GenericMsg * c_Moses_Log_NewMsgId::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Log_NewMsgId(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Log_NewMsgId::a_Moses_Log_NewMsgId(const char *pErr) { Error = pErr; }
a_Moses_Log_NewMsgId::a_Moses_Log_NewMsgId() {}

a_Moses_Log_NewMsgId::a_Moses_Log_NewMsgId(const a_Moses_Log_NewMsgId &r)
{
	Error	    = r.Error;
}

a_Moses_Log_NewMsgId::~a_Moses_Log_NewMsgId() {}

void a_Moses_Log_NewMsgId::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Log_NewMsgId::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError      " << Error << endl;
}

Implement_Class(a_Moses_Log_NewMsgId);

GenericMsg * a_Moses_Log_NewMsgId::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_Log_NewMsgId(const char   *MailBoxName, 
					      const char   *Pwd,
					      INT32         OldMsgId,
					      INT32         NewMsgId)
{
	c_Moses_Log_NewMsgId m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.OldMsgId      = OldMsgId;
	m.NewMsgId      = NewMsgId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Log_NewMsgId::IdMsg)
	{
		a_Moses_Log_NewMsgId *answ = (a_Moses_Log_NewMsgId *)pMsg;

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

