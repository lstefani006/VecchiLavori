#include <st_dbnew.h>
#include "m_Moses_MB_ListFolder.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_ListFolder::c_Moses_MB_ListFolder()
{
}

c_Moses_MB_ListFolder::c_Moses_MB_ListFolder(const c_Moses_MB_ListFolder &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd      		= r.Pwd  ;
	Folder    		= r.Folder;
}

c_Moses_MB_ListFolder::~c_Moses_MB_ListFolder() {}


void c_Moses_MB_ListFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(Folder, b, d);
}

void c_Moses_MB_ListFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName  " << MailBoxName  << endl;
	s << "\tPwd          " << Pwd          << endl;
	s << "\tFolder       " << Folder       << endl;
}

Implement_Class(c_Moses_MB_ListFolder);



GenericMsg * c_Moses_MB_ListFolder::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_ListFolder(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_ListFolder::a_Moses_MB_ListFolder(const char *pErr) { Error = pErr; }
a_Moses_MB_ListFolder::a_Moses_MB_ListFolder() {}

a_Moses_MB_ListFolder::a_Moses_MB_ListFolder(const a_Moses_MB_ListFolder &r)
{
	Error		= r.Error;
	FolderList	= r.FolderList;
	DeletedList	= r.DeletedList;
}

a_Moses_MB_ListFolder::~a_Moses_MB_ListFolder() {}

void a_Moses_MB_ListFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(FolderList, b, d);
	pSer->Serialize(DeletedList, b, d);
}

void a_Moses_MB_ListFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError       " << Error       << endl;
	s << "\tFolderList  " << FolderList  << endl;
	s << "\tDeletedList " << DeletedList << endl;
}

Implement_Class(a_Moses_MB_ListFolder);

GenericMsg * a_Moses_MB_ListFolder::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_ListFolder(const char   *MailBoxName, 
						   const char   *Pwd  ,
						   const char   *Folder,
						   VECT<STRING> &out_FolderList,
						   VECT<INT16>  &out_DeletedList)
{
	c_Moses_MB_ListFolder m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd     	    = Pwd;
	m.Folder   	    = Folder;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_ListFolder::IdMsg)
	{
		a_Moses_MB_ListFolder *answ = (a_Moses_MB_ListFolder *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_FolderList = answ->FolderList;
				out_DeletedList = answ->DeletedList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

