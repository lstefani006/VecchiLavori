#include <st_dbnew.h>
#ifndef __Moses_EH_Count_h__
#define __Moses_EH_Count_h__

#include "gnricmsg.h"

class c_Moses_EH_Count : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Folder;

	c_Moses_EH_Count();
	c_Moses_EH_Count(const c_Moses_EH_Count &r);
	~c_Moses_EH_Count();

	Declare_Class(c_Moses_EH_Count);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_EH_Count : public GenericMsg
{
public:

	STRING Error;
	INT32  Count;

	a_Moses_EH_Count(const char *pErr);
	a_Moses_EH_Count();

	a_Moses_EH_Count(const a_Moses_EH_Count &r);

	~a_Moses_EH_Count();

	Declare_Class(a_Moses_EH_Count);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
