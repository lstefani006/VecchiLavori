#include <st_dbnew.h>
#include "m_Moses_DL_Delete.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "DL.h"
#endif


c_Moses_DL_Delete::c_Moses_DL_Delete()
{
}

c_Moses_DL_Delete::c_Moses_DL_Delete(const c_Moses_DL_Delete &r)
{
	DLName      = r.DLName;
}

c_Moses_DL_Delete::~c_Moses_DL_Delete() {}


void c_Moses_DL_Delete::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(DLName, b, d);
}

void c_Moses_DL_Delete::Print(ostream &s) const
{
	BASE::Print(s);
	s << "DLName     " << DLName      << endl;
}

Implement_Class(c_Moses_DL_Delete);


GenericMsg * c_Moses_DL_Delete::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return DL_Delete(this, nClient);
#else
	return NULL;
#endif
}


///////////////////////////////////////////////////////////////////////////////


a_Moses_DL_Delete::a_Moses_DL_Delete(const char *pErr) { Error = pErr; }
a_Moses_DL_Delete::a_Moses_DL_Delete() {}

a_Moses_DL_Delete::a_Moses_DL_Delete(const a_Moses_DL_Delete &r)
{
	Error	= r.Error;
}

a_Moses_DL_Delete::~a_Moses_DL_Delete() {}

void a_Moses_DL_Delete::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_DL_Delete::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_DL_Delete);


GenericMsg * a_Moses_DL_Delete::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_DL_Delete(const char *DLName)
{
	c_Moses_DL_Delete m;

	m.DLName 		= DLName;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_DL_Delete::IdMsg)
	{
		a_Moses_DL_Delete *answ = (a_Moses_DL_Delete *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}
