#include <st_dbnew.h>
#ifndef __Moses_MSL_List_h__
#define __Moses_MSL_List_h__

#include "gnricmsg.h"


class c_Moses_MSL_List : public GenericMsg
{
public:
	c_Moses_MSL_List();
	c_Moses_MSL_List(const c_Moses_MSL_List &r);
	~c_Moses_MSL_List();
	Declare_Class(c_Moses_MSL_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_MSL_List : public GenericMsg
{
public:
	STRING Error;

	VECT<STRING> MSLNameList;
	VECT<STRING> MSLDescrList;

	a_Moses_MSL_List(const char *pErr);
	a_Moses_MSL_List();
	a_Moses_MSL_List(const a_Moses_MSL_List &r);
	~a_Moses_MSL_List();
	Declare_Class(a_Moses_MSL_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
