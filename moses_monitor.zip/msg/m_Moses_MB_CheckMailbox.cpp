#include <st_dbnew.h>
#include "m_Moses_MB_CheckMailbox.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif

c_Moses_MB_CheckMailbox::c_Moses_MB_CheckMailbox()
{
}

c_Moses_MB_CheckMailbox::c_Moses_MB_CheckMailbox(const c_Moses_MB_CheckMailbox &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
}

c_Moses_MB_CheckMailbox::~c_Moses_MB_CheckMailbox() {}


void c_Moses_MB_CheckMailbox::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
}

void c_Moses_MB_CheckMailbox::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName " << MailBoxName   << endl;
	s << "\tPwd     	  " << Pwd     	   << endl;
}

Implement_Class(c_Moses_MB_CheckMailbox);



GenericMsg * c_Moses_MB_CheckMailbox::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_CheckMailbox(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_CheckMailbox::a_Moses_MB_CheckMailbox(const char *pErr) { Error = pErr; }
a_Moses_MB_CheckMailbox::a_Moses_MB_CheckMailbox() {}

a_Moses_MB_CheckMailbox::a_Moses_MB_CheckMailbox(const a_Moses_MB_CheckMailbox &r)
{
	Error	= r.Error;
}

a_Moses_MB_CheckMailbox::~a_Moses_MB_CheckMailbox() {}

void a_Moses_MB_CheckMailbox::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_CheckMailbox::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError " << Error  << endl;
}

Implement_Class(a_Moses_MB_CheckMailbox);

GenericMsg * a_Moses_MB_CheckMailbox::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_CheckMailbox(const char *MailBoxName, 
							 const char *Pwd)
{
	c_Moses_MB_CheckMailbox m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_CheckMailbox::IdMsg)
	{
		a_Moses_MB_CheckMailbox *answ = (a_Moses_MB_CheckMailbox *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

