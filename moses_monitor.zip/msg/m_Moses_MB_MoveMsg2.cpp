#include <st_dbnew.h>
#include "m_Moses_MB_MoveMsg2.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_MoveMsg2::c_Moses_MB_MoveMsg2()
{
}

c_Moses_MB_MoveMsg2::c_Moses_MB_MoveMsg2(const c_Moses_MB_MoveMsg2 &r)
{
	MailBoxNameSource    = r.MailBoxNameSource;
	PwdSource            = r.PwdSource;
	MailBoxNameDest      = r.MailBoxNameDest;
	PwdDest              = r.PwdDest;
	MsgId                = r.MsgId;
	DestFolder           = r.DestFolder;
}

c_Moses_MB_MoveMsg2::~c_Moses_MB_MoveMsg2() {}


void c_Moses_MB_MoveMsg2::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxNameSource, b, d);
	pSer->Serialize(MailBoxNameDest, b, d);
	pSer->Serialize(PwdSource, b, d);
	pSer->Serialize(PwdDest, b, d);
	pSer->Serialize(MsgId, b, d);
	pSer->Serialize(DestFolder, b, d);
}

void c_Moses_MB_MoveMsg2::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxNameSource  " << MailBoxNameSource  << endl;
	s << "\tPwdSource          " << PwdSource          << endl;
	s << "\tMailBoxNameDest    " << MailBoxNameDest    << endl;
	s << "\tPwdDest            " << PwdDest            << endl;
	s << "\tMsgId        " << MsgId        << endl;
	s << "\tDestFolder   " << DestFolder   << endl;
}

Implement_Class(c_Moses_MB_MoveMsg2);



GenericMsg * c_Moses_MB_MoveMsg2::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_MoveMsg2(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_MoveMsg2::a_Moses_MB_MoveMsg2(const char *pErr) { Error = pErr; }
a_Moses_MB_MoveMsg2::a_Moses_MB_MoveMsg2() {}

a_Moses_MB_MoveMsg2::a_Moses_MB_MoveMsg2(const a_Moses_MB_MoveMsg2 &r)
{
	Error	= r.Error;
}

a_Moses_MB_MoveMsg2::~a_Moses_MB_MoveMsg2() {}

void a_Moses_MB_MoveMsg2::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_MoveMsg2::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError  " << Error   << endl;
}

Implement_Class(a_Moses_MB_MoveMsg2);

GenericMsg * a_Moses_MB_MoveMsg2::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_MoveMsg2(
		const char   *MailBoxNameSource, 
		const char   *PwdSource,
		const char   *MailBoxNameDest, 
		const char   *PwdDest,
		int           MsgId,
		const char   *DestFolder)
{
	c_Moses_MB_MoveMsg2 m;

	m.MailBoxNameSource  = MailBoxNameSource;
	m.MailBoxNameDest    = MailBoxNameDest;
	m.PwdSource          = PwdSource;
	m.PwdDest            = PwdDest;
	m.MsgId              = MsgId;
	m.DestFolder         = DestFolder;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_MoveMsg2::IdMsg)
	{
		a_Moses_MB_MoveMsg2 *answ = (a_Moses_MB_MoveMsg2 *)pMsg;

		if (answ->Error.Len() == 0)
		{
			// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

