#include <st_dbnew.h>
#include "m_Moses_ART_ListUsers.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "ART.h"
#endif

c_Moses_ART_ListUsers::c_Moses_ART_ListUsers()
{
}

c_Moses_ART_ListUsers::c_Moses_ART_ListUsers(const c_Moses_ART_ListUsers &r)
{
	bInternal      = r.bInternal;
	MailBoxType    = r.MailBoxType;
}

c_Moses_ART_ListUsers::~c_Moses_ART_ListUsers() {}


void c_Moses_ART_ListUsers::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxType,  b, d);
	pSer->Serialize(bInternal, b, d);
}

void c_Moses_ART_ListUsers::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MailBoxType   " << MailBoxType    << endl;
	s << "bInternal     " << bInternal      << endl;
}

Implement_Class(c_Moses_ART_ListUsers);


GenericMsg * c_Moses_ART_ListUsers::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return ART_ListUsers(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_ART_ListUsers::a_Moses_ART_ListUsers(const char *pErr) { Error = pErr; }
a_Moses_ART_ListUsers::a_Moses_ART_ListUsers() {}

a_Moses_ART_ListUsers::a_Moses_ART_ListUsers(const a_Moses_ART_ListUsers &r)
{
	Error	    = r.Error;
	UsersList	= r.UsersList;
}

a_Moses_ART_ListUsers::~a_Moses_ART_ListUsers() {}

void a_Moses_ART_ListUsers::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(UsersList, b, d);
}

void a_Moses_ART_ListUsers::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error     " << Error      << endl;
	s << "UsersList " << UsersList  << endl;
}

Implement_Class(a_Moses_ART_ListUsers);



GenericMsg * a_Moses_ART_ListUsers::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////

STRING Moses_ART_ListUsers (const char *MailBoxType, 
							INT16 		bInternal, 
							VECT<STRING> &out_UsersList) 
{
	c_Moses_ART_ListUsers m;

	m.MailBoxType 	 = MailBoxType;
	m.bInternal 	 = bInternal;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_ART_ListUsers::IdMsg)
	{
		a_Moses_ART_ListUsers *answ = (a_Moses_ART_ListUsers *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_UsersList = answ->UsersList;				
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


