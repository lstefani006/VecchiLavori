#include <st_dbnew.h>
#include "m_Moses_Client_Modify.h"
#include "m_Error.h"


#ifdef MOSES_SERVER
	#include "Client.h"
#endif

c_Moses_Client_Modify::c_Moses_Client_Modify()
{
}

c_Moses_Client_Modify::c_Moses_Client_Modify(const c_Moses_Client_Modify &r)
{
	ClientName	= r.ClientName;
	ClientDescr	= r.ClientDescr;
	ClientType	= r.ClientType;
	Active		= r.Active;
}

c_Moses_Client_Modify::~c_Moses_Client_Modify() {}


void c_Moses_Client_Modify::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(ClientName, b, d);
	pSer->Serialize(ClientDescr,b, d);
	pSer->Serialize(ClientType,b, d);
	pSer->Serialize(Active,b, d);
}

void c_Moses_Client_Modify::Print(ostream &s) const
{
	BASE::Print(s);
	s << "ClientName    " << ClientName     << endl;
	s << "ClientDescr   " << ClientDescr    << endl;
	s << "ClientType    " << ClientType     << endl;
	s << "Active        " << Active      	<< endl;
}

Implement_Class(c_Moses_Client_Modify);


GenericMsg * c_Moses_Client_Modify::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Client_Modify(this, nClient);
#else
	return NULL;
#endif
}


///////////////////////////////////////////////////////////////////////////////


a_Moses_Client_Modify::a_Moses_Client_Modify(const char *pErr) { Error = pErr; }
a_Moses_Client_Modify::a_Moses_Client_Modify() {}

a_Moses_Client_Modify::a_Moses_Client_Modify(const a_Moses_Client_Modify &r)
{
	Error	= r.Error;
}

a_Moses_Client_Modify::~a_Moses_Client_Modify() {}

void a_Moses_Client_Modify::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Client_Modify::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_Client_Modify);



GenericMsg * a_Moses_Client_Modify::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Client_Modify(const char *ClientName, const char *ClientDescr, const char *ClientType, int Active)
{
	c_Moses_Client_Modify m;

	m.ClientName 	= ClientName;
	m.ClientDescr 	= ClientDescr;
	m.ClientType   	= ClientType;
	m.Active   		= Active;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Client_Modify::IdMsg)
	{
		a_Moses_Client_Modify *answ = (a_Moses_Client_Modify *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


