#include <st_dbnew.h>
#include "m_Moses_MB_UndeleteMsg.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_UndeleteMsg::c_Moses_MB_UndeleteMsg()
{
}

c_Moses_MB_UndeleteMsg::c_Moses_MB_UndeleteMsg(const c_Moses_MB_UndeleteMsg &r)
{
	MsgId    		= r.MsgId;
}

c_Moses_MB_UndeleteMsg::~c_Moses_MB_UndeleteMsg() {}


void c_Moses_MB_UndeleteMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MsgId, b, d);
}

void c_Moses_MB_UndeleteMsg::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMsgId        " << MsgId         << endl;
}

Implement_Class(c_Moses_MB_UndeleteMsg);



GenericMsg * c_Moses_MB_UndeleteMsg::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_UndeleteMsg(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_UndeleteMsg::a_Moses_MB_UndeleteMsg(const char *pErr) { Error = pErr; }
a_Moses_MB_UndeleteMsg::a_Moses_MB_UndeleteMsg() {}

a_Moses_MB_UndeleteMsg::a_Moses_MB_UndeleteMsg(const a_Moses_MB_UndeleteMsg &r)
{
	Error		= r.Error;
	Recovered	= r.Recovered;
}

a_Moses_MB_UndeleteMsg::~a_Moses_MB_UndeleteMsg() {}

void a_Moses_MB_UndeleteMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(Recovered, b, d);
}

void a_Moses_MB_UndeleteMsg::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError     " << Error     << endl;
	s << "\tRecovered " << Recovered << endl;
}

Implement_Class(a_Moses_MB_UndeleteMsg);

GenericMsg * a_Moses_MB_UndeleteMsg::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_UndeleteMsg(int MsgId,
							INT16 &out_Recovered)
{
	c_Moses_MB_UndeleteMsg m;

	m.MsgId         = MsgId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_UndeleteMsg::IdMsg)
	{
		a_Moses_MB_UndeleteMsg *answ = (a_Moses_MB_UndeleteMsg *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_Recovered = answ->Recovered;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}
