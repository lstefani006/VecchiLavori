#include <st_dbnew.h>
#ifndef __Moses_MB_Set_Userfield_h__
#define __Moses_MB_Set_Userfield_h__

#include "gnricmsg.h"

class c_Moses_MB_Set_Userfield : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Pwd;
	INT32  MsgId;
	STRING Value;

	c_Moses_MB_Set_Userfield();
	c_Moses_MB_Set_Userfield(const c_Moses_MB_Set_Userfield &r);
	~c_Moses_MB_Set_Userfield();

	Declare_Class(c_Moses_MB_Set_Userfield);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_Set_Userfield : public GenericMsg
{
public:

	STRING Error;
	
	a_Moses_MB_Set_Userfield(const char *pErr);
	a_Moses_MB_Set_Userfield();

	a_Moses_MB_Set_Userfield(const a_Moses_MB_Set_Userfield &r);

	~a_Moses_MB_Set_Userfield();

	Declare_Class(a_Moses_MB_Set_Userfield);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
