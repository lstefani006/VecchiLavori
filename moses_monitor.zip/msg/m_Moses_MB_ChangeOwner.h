#include <st_dbnew.h>
#ifndef __Moses_MB_ChangeOwner_h__
#define __Moses_MB_ChangeOwner_h__

#include "gnricmsg.h"

class c_Moses_MB_ChangeOwner : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Owner;

	c_Moses_MB_ChangeOwner();
	c_Moses_MB_ChangeOwner(const c_Moses_MB_ChangeOwner &r);
	~c_Moses_MB_ChangeOwner();

	Declare_Class(c_Moses_MB_ChangeOwner);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_ChangeOwner : public GenericMsg
{
public:

	STRING Error;

	a_Moses_MB_ChangeOwner(const char *pErr);
	a_Moses_MB_ChangeOwner();

	a_Moses_MB_ChangeOwner(const a_Moses_MB_ChangeOwner &r);

	~a_Moses_MB_ChangeOwner();

	Declare_Class(a_Moses_MB_ChangeOwner);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
