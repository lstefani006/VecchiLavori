#include <st_dbnew.h>
#ifndef __Moses_FM_ListFile_h__
#define __Moses_FM_ListFile_h__

#include "gnricmsg.h"

class c_Moses_FM_ListFile : public GenericMsg
{
public:

	STRING PathDir;

	c_Moses_FM_ListFile();
	c_Moses_FM_ListFile(const c_Moses_FM_ListFile &r);
	~c_Moses_FM_ListFile();

	Declare_Class(c_Moses_FM_ListFile);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_FM_ListFile : public GenericMsg
{
public:

	STRING Error;
	
	VECT<STRING> NameFileList; 
	VECT<STRING> TypeFileList; 
	VECT<STRING> DateFileList; 
	VECT<INT32>  DimFileList; 

	a_Moses_FM_ListFile(const char *pErr);
	a_Moses_FM_ListFile();

	a_Moses_FM_ListFile(const a_Moses_FM_ListFile &r);

	~a_Moses_FM_ListFile();

	Declare_Class(a_Moses_FM_ListFile);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
