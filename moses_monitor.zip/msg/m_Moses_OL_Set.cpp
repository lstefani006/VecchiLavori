#include <st_dbnew.h>
#include "m_Moses_OL_Set.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "OL.h"
#endif

c_Moses_OL_Set::c_Moses_OL_Set()
{
}

c_Moses_OL_Set::c_Moses_OL_Set(const c_Moses_OL_Set &r)
{
	DaysAccessed	= r.DaysAccessed;
	DaysSent	    = r.DaysSent;
	DaysDispatched	= r.DaysDispatched;
}

c_Moses_OL_Set::~c_Moses_OL_Set() {}


void c_Moses_OL_Set::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(DaysAccessed, b, d);
	pSer->Serialize(DaysSent,b, d);
	pSer->Serialize(DaysDispatched,b, d);
}

void c_Moses_OL_Set::Print(ostream &s) const
{
	BASE::Print(s);
	s << "DaysAccessed     " << DaysAccessed      << endl;
	s << "DaysSent         " << DaysSent          << endl;
	s << "DaysDispatched   " << DaysDispatched    << endl;
}

Implement_Class(c_Moses_OL_Set);


GenericMsg * c_Moses_OL_Set::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return OL_Set(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_OL_Set::a_Moses_OL_Set(const char *pErr) { Error = pErr; }
a_Moses_OL_Set::a_Moses_OL_Set() {}

a_Moses_OL_Set::a_Moses_OL_Set(const a_Moses_OL_Set &r)
{
	Error	= r.Error;
}

a_Moses_OL_Set::~a_Moses_OL_Set() {}

void a_Moses_OL_Set::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_OL_Set::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_OL_Set);



GenericMsg * a_Moses_OL_Set::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_OL_Set(const char *DaysAccessed, const char *DaysSent, 
		const char *DaysDispatched)
{
	c_Moses_OL_Set m;

	m.DaysAccessed	  = DaysAccessed;
	m.DaysSent  	  = DaysSent;
	m.DaysDispatched  = DaysDispatched;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_OL_Set::IdMsg)
	{
		a_Moses_OL_Set *answ = (a_Moses_OL_Set *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


