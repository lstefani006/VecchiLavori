#include <st_dbnew.h>
#include "m_Moses_Event_NewMsgInFolder.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Event.h"
#endif

c_Moses_Event_NewMsgInFolder::c_Moses_Event_NewMsgInFolder()
{
}

c_Moses_Event_NewMsgInFolder::c_Moses_Event_NewMsgInFolder(const c_Moses_Event_NewMsgInFolder &r)
{
	MailboxName     = r.MailboxName;
	Pwd     		= r.Pwd;
	Folder    		= r.Folder;
}

c_Moses_Event_NewMsgInFolder::~c_Moses_Event_NewMsgInFolder() {}


void c_Moses_Event_NewMsgInFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailboxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(Folder, b, d);
}

void c_Moses_Event_NewMsgInFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MailboxName  " << MailboxName   << endl;
	s << "Pwd      	   " << Pwd           << endl;
	s << "Folder       " << Folder        << endl;
}

Implement_Class(c_Moses_Event_NewMsgInFolder);



GenericMsg * c_Moses_Event_NewMsgInFolder::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Event_NewMsgInFolder(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Event_NewMsgInFolder::a_Moses_Event_NewMsgInFolder(const char *pErr) { Error = pErr; }
a_Moses_Event_NewMsgInFolder::a_Moses_Event_NewMsgInFolder() {}

a_Moses_Event_NewMsgInFolder::a_Moses_Event_NewMsgInFolder(const a_Moses_Event_NewMsgInFolder &r)
{
	Error	= r.Error;
	EventId = r.EventId;
}

a_Moses_Event_NewMsgInFolder::~a_Moses_Event_NewMsgInFolder() {}

void a_Moses_Event_NewMsgInFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b,       pSer, d);
	pSer->Serialize(Error,   b,    d);
	pSer->Serialize(EventId, b,    d);
}

void a_Moses_Event_NewMsgInFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error   " << Error    << endl;
	s << "EventId " << EventId  << endl;
}

Implement_Class(a_Moses_Event_NewMsgInFolder);

GenericMsg * a_Moses_Event_NewMsgInFolder::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_Event_NewMsgInFolder(
		const char *MailboxName, 
		const char *Pwd,
		const char *Folder,
		INT32 &out_EventId)
{
	c_Moses_Event_NewMsgInFolder m;

	m.MailboxName 	= MailboxName;
	m.Pwd    	    = Pwd;
	m.Folder   	    = Folder;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Event_NewMsgInFolder::IdMsg)
	{
		a_Moses_Event_NewMsgInFolder *answ = (a_Moses_Event_NewMsgInFolder *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_EventId = answ->EventId;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


