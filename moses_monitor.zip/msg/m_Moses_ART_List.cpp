#include <st_dbnew.h>
#include "m_Moses_ART_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "ART.h"
#endif

c_Moses_ART_List::c_Moses_ART_List()
{
}

c_Moses_ART_List::c_Moses_ART_List(const c_Moses_ART_List &r)
{
	Index      = r.Index;
}

c_Moses_ART_List::~c_Moses_ART_List() {}


void c_Moses_ART_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Index, b, d);
}

void c_Moses_ART_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Index          " << Index           << endl;
}

Implement_Class(c_Moses_ART_List);


GenericMsg * c_Moses_ART_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return ART_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_ART_List::a_Moses_ART_List(const char *pErr) { Error = pErr; }
a_Moses_ART_List::a_Moses_ART_List() {}

a_Moses_ART_List::a_Moses_ART_List(const a_Moses_ART_List &r)
{
	Error	       = r.Error;
	User           = r.User;
	bInternal      = r.bInternal;
	MailBoxType    = r.MailBoxType;
	MailBoxAddress = r.MailBoxAddress;
	Subject        = r.Subject;
	Valid          = r.Valid;
}

a_Moses_ART_List::~a_Moses_ART_List() {}

void a_Moses_ART_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(User, b, d);
	pSer->Serialize(MailBoxType,  b, d);
	pSer->Serialize(bInternal, b, d);
	pSer->Serialize(MailBoxAddress, b, d);
	pSer->Serialize(Subject, b, d);
	pSer->Serialize(Valid,  b, d);
}

void a_Moses_ART_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error         " << Error          << endl;
	s << "User          " << User           << endl;
	s << "MailBoxType   " << MailBoxType    << endl;
	s << "bInternal     " << bInternal      << endl;
	s << "MailBoxAddress" << MailBoxAddress << endl;
	s << "Subject       " << Subject        << endl;
	s << "Valid         " << Valid          << endl;
}

Implement_Class(a_Moses_ART_List);



GenericMsg * a_Moses_ART_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_ART_List(int     Index, 
				      STRING &out_UserName, 
					  INT16  &out_bInternal,
					  STRING &out_MailBoxType,
					  STRING &out_MailBoxAddress,
					  STRING &out_SubjectAdd,
					  INT16  &out_Valid)
{
	c_Moses_ART_List m;

	m.Index = Index;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_ART_List::IdMsg)
	{
		a_Moses_ART_List *answ = (a_Moses_ART_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_UserName 		 = answ->User;
			out_bInternal 		 = answ->bInternal;
			out_MailBoxType 	 = answ->MailBoxType;
			out_MailBoxAddress   = answ->MailBoxAddress;
			out_SubjectAdd     	 = answ->Subject;
			out_Valid        	 = answ->Valid;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


