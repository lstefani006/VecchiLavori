#include <st_dbnew.h>
#ifndef __Moses_MB_ListMsg_h__
#define __Moses_MB_ListMsg_h__

#include "gnricmsg.h"

class c_Moses_MB_ListMsg : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Pwd;
	STRING Folder;
	STRING Cond_UserField;
	STRING Cond_Accessed;
	STRING Cond_Sender;
	STRING Cond_Receiver;

	c_Moses_MB_ListMsg();
	c_Moses_MB_ListMsg(const c_Moses_MB_ListMsg &r);
	~c_Moses_MB_ListMsg();

	Declare_Class(c_Moses_MB_ListMsg);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_ListMsg : public GenericMsg
{
public:

	STRING Error;
	
	VECT<INT32> MsgIdList; 

	a_Moses_MB_ListMsg(const char *pErr);
	a_Moses_MB_ListMsg();

	a_Moses_MB_ListMsg(const a_Moses_MB_ListMsg &r);

	~a_Moses_MB_ListMsg();

	Declare_Class(a_Moses_MB_ListMsg);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
