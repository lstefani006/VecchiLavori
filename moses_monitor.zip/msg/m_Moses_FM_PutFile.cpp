#include <st_dbnew.h>
#include "m_Moses_FM_PutFile.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "FM.h"
#endif


c_Moses_FM_PutFile::c_Moses_FM_PutFile()
{
}

c_Moses_FM_PutFile::c_Moses_FM_PutFile(const c_Moses_FM_PutFile &r)
{
	FinalPathNameFile = r.FinalPathNameFile;
}

c_Moses_FM_PutFile::~c_Moses_FM_PutFile() {}


void c_Moses_FM_PutFile::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(FinalPathNameFile, b, d);
	pSer->Serialize(BodyFile, b, d);
}

void c_Moses_FM_PutFile::Print(ostream &s) const
{
	BASE::Print(s);
	s << "FinalPathNameFile   " << FinalPathNameFile    << endl;
	s << "BodyFile            " << BodyFile             << endl;
}

Implement_Class(c_Moses_FM_PutFile);



GenericMsg * c_Moses_FM_PutFile::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER 
	return FM_PutFile(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_FM_PutFile::a_Moses_FM_PutFile(const char *pErr) { Error = pErr; }
a_Moses_FM_PutFile::a_Moses_FM_PutFile() {}

a_Moses_FM_PutFile::a_Moses_FM_PutFile(const a_Moses_FM_PutFile &r)
{
	Error		    = r.Error;
}

a_Moses_FM_PutFile::~a_Moses_FM_PutFile() {}

void a_Moses_FM_PutFile::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_FM_PutFile::Print(ostream &s) const
{
	BASE::Print(s);
	s << Error         << endl;
}

Implement_Class(a_Moses_FM_PutFile);

GenericMsg * a_Moses_FM_PutFile::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_FM_PutFile(const char *FinalPathNameFile, const STRING &BodyFile)
{
	c_Moses_FM_PutFile m;

	m.FinalPathNameFile = FinalPathNameFile;
	m.BodyFile          = BodyFile;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_FM_PutFile::IdMsg)
	{
		a_Moses_FM_PutFile *answ = (a_Moses_FM_PutFile *)pMsg;

		if (answ->Error.Len() == 0)
		{
			// NON ci sono parametri di output
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

