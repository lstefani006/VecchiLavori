#include <st_dbnew.h>
#ifndef __Moses_User_Add_h__
#define __Moses_User_Add_h__

#include "gnricmsg.h"

class c_Moses_User_Add : public GenericMsg
{
public:

	STRING UserName;
	STRING UserPwd;
	STRING UserClientType;
	STRING UserDescr;
	STRING UserRights;
	STRING UserDefaultMBox;
	STRING UserKeyId;

	c_Moses_User_Add();
	c_Moses_User_Add(const c_Moses_User_Add &r);
	~c_Moses_User_Add();

	Declare_Class(c_Moses_User_Add);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_User_Add : public GenericMsg
{
public:

	STRING Error;

	a_Moses_User_Add(const char *pErr);
	a_Moses_User_Add();

	a_Moses_User_Add(const a_Moses_User_Add &r);

	~a_Moses_User_Add();

	Declare_Class(a_Moses_User_Add);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
