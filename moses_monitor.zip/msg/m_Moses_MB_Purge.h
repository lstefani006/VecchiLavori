#include <st_dbnew.h>
#ifndef __Moses_MB_Purge_h__
#define __Moses_MB_Purge_h__

#include "gnricmsg.h"

class c_Moses_MB_Purge : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Folder;
	STRING Pwd;

	c_Moses_MB_Purge();
	c_Moses_MB_Purge(const c_Moses_MB_Purge &r);
	~c_Moses_MB_Purge();

	Declare_Class(c_Moses_MB_Purge);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_Purge : public GenericMsg
{
public:

	STRING Error;
	INT32  Deleted;
	
	a_Moses_MB_Purge(const char *pErr);
	a_Moses_MB_Purge();

	a_Moses_MB_Purge(const a_Moses_MB_Purge &r);

	~a_Moses_MB_Purge();

	Declare_Class(a_Moses_MB_Purge);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
