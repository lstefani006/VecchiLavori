#include <st_dbnew.h>
#ifndef __Moses_Work_SetLanguage_h__
#define __Moses_Work_SetLanguage_h__

#include "gnricmsg.h"


class c_Moses_Work_SetLanguage : public GenericMsg
{
public:
	STRING Language;
	
	c_Moses_Work_SetLanguage();
	c_Moses_Work_SetLanguage(const c_Moses_Work_SetLanguage &r);
	~c_Moses_Work_SetLanguage();
	Declare_Class(c_Moses_Work_SetLanguage);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Work_SetLanguage : public GenericMsg
{
public:
	STRING Error;

	a_Moses_Work_SetLanguage(const char *pErr);
	a_Moses_Work_SetLanguage();
	a_Moses_Work_SetLanguage(const a_Moses_Work_SetLanguage &r);
	~a_Moses_Work_SetLanguage();
	Declare_Class(a_Moses_Work_SetLanguage);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
