#include <st_dbnew.h>
#include "m_Moses_Licence_Get.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Licence.h"
#endif

c_Moses_Licence_Get::c_Moses_Licence_Get()
{
}

c_Moses_Licence_Get::c_Moses_Licence_Get(const c_Moses_Licence_Get &r)
{
}

c_Moses_Licence_Get::~c_Moses_Licence_Get() {}


void c_Moses_Licence_Get::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_Licence_Get::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_Licence_Get);


GenericMsg * c_Moses_Licence_Get::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Licence_Get(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Licence_Get::a_Moses_Licence_Get(const char *pErr) { Error = pErr; }
a_Moses_Licence_Get::a_Moses_Licence_Get() {}

a_Moses_Licence_Get::a_Moses_Licence_Get(const a_Moses_Licence_Get &r)
{
	Error	= r.Error;
	DateLicence	= r.DateLicence;
}

a_Moses_Licence_Get::~a_Moses_Licence_Get() {}

void a_Moses_Licence_Get::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(DateLicence, b, d);
}

void a_Moses_Licence_Get::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error        " << Error       << endl;
	s << "DateLicence  " << DateLicence << endl;
}

Implement_Class(a_Moses_Licence_Get);



GenericMsg * a_Moses_Licence_Get::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Licence_Get(STRING &out_DateLicence) 
{
	c_Moses_Licence_Get m;


	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Licence_Get::IdMsg)
	{
		a_Moses_Licence_Get *answ = (a_Moses_Licence_Get *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_DateLicence	= answ->DateLicence;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


