#include <st_dbnew.h>
#ifndef __Moses_FM_GetFile_h__
#define __Moses_FM_GetFile_h__

#include "gnricmsg.h"

class c_Moses_FM_GetFile : public GenericMsg
{
public:

	STRING StartPathNameFile;

	c_Moses_FM_GetFile();
	c_Moses_FM_GetFile(const c_Moses_FM_GetFile &r);
	~c_Moses_FM_GetFile();

	Declare_Class(c_Moses_FM_GetFile);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_FM_GetFile : public GenericMsg
{
public:

	STRING Error;
	
	STRING BodyFile; 

	a_Moses_FM_GetFile(const char *pErr);
	a_Moses_FM_GetFile();

	a_Moses_FM_GetFile(const a_Moses_FM_GetFile &r);

	~a_Moses_FM_GetFile();

	Declare_Class(a_Moses_FM_GetFile);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
