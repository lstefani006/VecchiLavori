#include <st_dbnew.h>
#include "m_Moses_EH_Add.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
    #include "EH.h"
	#include "server.h"
#endif



c_Moses_EH_Add::c_Moses_EH_Add()
{
}

c_Moses_EH_Add::c_Moses_EH_Add(const c_Moses_EH_Add &r)
{
	MailBoxName  = r.MailBoxName;
	Folder       = r.Folder;
	Source       = r.Source;
	Destination  = r.Destination;
	Subject      = r.Subject;
	Action       = r.Action;
	Index        = r.Index;
}

c_Moses_EH_Add::~c_Moses_EH_Add() {}


void c_Moses_EH_Add::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Folder, b, d);
	pSer->Serialize(Source, b, d);
	pSer->Serialize(Destination, b, d);
	pSer->Serialize(Subject, b, d);
	pSer->Serialize(Action, b, d);
	pSer->Serialize(Index, b, d);
}

void c_Moses_EH_Add::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MailBoxName " << MailBoxName << endl;
	s << "Folder      " << Folder      << endl;
	s << "Source      " << Source      << endl;
	s << "Destination " << Destination << endl;
	s << "Subject     " << Subject     << endl;
	s << "Action      " << Action      << endl;
	s << "Index       " << Index       << endl;
}

Implement_Class(c_Moses_EH_Add);


GenericMsg * c_Moses_EH_Add::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return EH_Add(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_EH_Add::a_Moses_EH_Add(const char *pErr) { Error = pErr; }
a_Moses_EH_Add::a_Moses_EH_Add() {}

a_Moses_EH_Add::a_Moses_EH_Add(const a_Moses_EH_Add &r)
{
	Error	= r.Error;
}

a_Moses_EH_Add::~a_Moses_EH_Add() {}

void a_Moses_EH_Add::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_EH_Add::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_EH_Add);

GenericMsg * a_Moses_EH_Add::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_EH_Add(const char *MailBoxName,
					const char *Folder, 
					const char *Source, 
					const char *Destination, 
					const char *Subject, 
					const char *Action, 
					int         Index)
{
	c_Moses_EH_Add m;
	
	m.MailBoxName  = MailBoxName;
	m.Folder       = Folder;
	m.Source       = Source;
	m.Destination  = Destination;
	m.Subject      = Subject;
	m.Action       = Action;
	m.Index        = Index;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_EH_Add::IdMsg)
	{
		a_Moses_EH_Add *answ = (a_Moses_EH_Add *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

