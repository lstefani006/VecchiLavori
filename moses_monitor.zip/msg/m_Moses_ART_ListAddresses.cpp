#include <st_dbnew.h>
#include "m_Moses_ART_ListAddresses.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "ART.h"
#endif

c_Moses_ART_ListAddresses::c_Moses_ART_ListAddresses()
{
}

c_Moses_ART_ListAddresses::c_Moses_ART_ListAddresses(const c_Moses_ART_ListAddresses &r)
{
	bInternal      = r.bInternal;
	MailBoxType    = r.MailBoxType;
}

c_Moses_ART_ListAddresses::~c_Moses_ART_ListAddresses() {}


void c_Moses_ART_ListAddresses::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxType,  b, d);
	pSer->Serialize(bInternal, b, d);
}

void c_Moses_ART_ListAddresses::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MailBoxType   " << MailBoxType    << endl;
	s << "bInternal     " << bInternal      << endl;
}

Implement_Class(c_Moses_ART_ListAddresses);


GenericMsg * c_Moses_ART_ListAddresses::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return ART_ListAddresses(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_ART_ListAddresses::a_Moses_ART_ListAddresses(const char *pErr) { Error = pErr; }
a_Moses_ART_ListAddresses::a_Moses_ART_ListAddresses() {}

a_Moses_ART_ListAddresses::a_Moses_ART_ListAddresses(const a_Moses_ART_ListAddresses &r)
{
	Error	        = r.Error;
	MailAddresses	= r.MailAddresses;
}

a_Moses_ART_ListAddresses::~a_Moses_ART_ListAddresses() {}

void a_Moses_ART_ListAddresses::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(MailAddresses, b, d);
}

void a_Moses_ART_ListAddresses::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error         " << Error          << endl;
	s << "MailAddresses " << MailAddresses  << endl;
}

Implement_Class(a_Moses_ART_ListAddresses);



GenericMsg * a_Moses_ART_ListAddresses::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////

STRING Moses_ART_ListAddresses (const char   *MailBoxType, 
								INT16        bInternal, 
								VECT<STRING> &out_MailAddresses) 
{
	c_Moses_ART_ListAddresses m;

	m.MailBoxType 	 = MailBoxType;
	m.bInternal 	 = bInternal;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_ART_ListAddresses::IdMsg)
	{
		a_Moses_ART_ListAddresses *answ = (a_Moses_ART_ListAddresses *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_MailAddresses = answ->MailAddresses;				
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


