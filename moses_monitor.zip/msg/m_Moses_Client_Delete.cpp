#include <st_dbnew.h>
#include "m_Moses_Client_Delete.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Client.h"
#endif


c_Moses_Client_Delete::c_Moses_Client_Delete()
{
}

c_Moses_Client_Delete::c_Moses_Client_Delete(const c_Moses_Client_Delete &r)
{
	ClientName      = r.ClientName;
}

c_Moses_Client_Delete::~c_Moses_Client_Delete() {}


void c_Moses_Client_Delete::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(ClientName, b, d);
}

void c_Moses_Client_Delete::Print(ostream &s) const
{
	BASE::Print(s);
	s << "ClientName     " << ClientName      << endl;
}

Implement_Class(c_Moses_Client_Delete);


GenericMsg * c_Moses_Client_Delete::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Client_Delete(this, nClient);
#else
	return NULL;
#endif
}


///////////////////////////////////////////////////////////////////////////////


a_Moses_Client_Delete::a_Moses_Client_Delete(const char *pErr) { Error = pErr; }
a_Moses_Client_Delete::a_Moses_Client_Delete() {}

a_Moses_Client_Delete::a_Moses_Client_Delete(const a_Moses_Client_Delete &r)
{
	Error	= r.Error;
}

a_Moses_Client_Delete::~a_Moses_Client_Delete() {}

void a_Moses_Client_Delete::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Client_Delete::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_Client_Delete);


GenericMsg * a_Moses_Client_Delete::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Client_Delete(const char *ClientName)
{
	c_Moses_Client_Delete m;

	m.ClientName 		= ClientName;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Client_Delete::IdMsg)
	{
		a_Moses_Client_Delete *answ = (a_Moses_Client_Delete *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}
