#include <st_dbnew.h>
#ifndef __Moses_Work_GetLanguage_h__
#define __Moses_Work_GetLanguage_h__

#include "gnricmsg.h"


class c_Moses_Work_GetLanguage : public GenericMsg
{
public:
	c_Moses_Work_GetLanguage();
	c_Moses_Work_GetLanguage(const c_Moses_Work_GetLanguage &r);
	~c_Moses_Work_GetLanguage();
	Declare_Class(c_Moses_Work_GetLanguage);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Work_GetLanguage : public GenericMsg
{
public:
	STRING Error;

	STRING Language;

	a_Moses_Work_GetLanguage(const char *pErr);
	a_Moses_Work_GetLanguage();
	a_Moses_Work_GetLanguage(const a_Moses_Work_GetLanguage &r);
	~a_Moses_Work_GetLanguage();
	Declare_Class(a_Moses_Work_GetLanguage);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
