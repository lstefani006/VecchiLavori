#include <st_dbnew.h>
#include "m_Moses_MB_DeleteMailbox.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_DeleteMailbox::c_Moses_MB_DeleteMailbox()
{
}

c_Moses_MB_DeleteMailbox::c_Moses_MB_DeleteMailbox(const c_Moses_MB_DeleteMailbox &r)
{
	MailBoxName     = r.MailBoxName;
}

c_Moses_MB_DeleteMailbox::~c_Moses_MB_DeleteMailbox() {}


void c_Moses_MB_DeleteMailbox::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
}

void c_Moses_MB_DeleteMailbox::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName  " << MailBoxName   << endl;
}

Implement_Class(c_Moses_MB_DeleteMailbox);



GenericMsg * c_Moses_MB_DeleteMailbox::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_DeleteMailbox(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_DeleteMailbox::a_Moses_MB_DeleteMailbox(const char *pErr) { Error = pErr; }
a_Moses_MB_DeleteMailbox::a_Moses_MB_DeleteMailbox() {}

a_Moses_MB_DeleteMailbox::a_Moses_MB_DeleteMailbox(const a_Moses_MB_DeleteMailbox &r)
{
	Error	= r.Error;
}

a_Moses_MB_DeleteMailbox::~a_Moses_MB_DeleteMailbox() {}

void a_Moses_MB_DeleteMailbox::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_DeleteMailbox::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError " << Error  << endl;
}

Implement_Class(a_Moses_MB_DeleteMailbox);

GenericMsg * a_Moses_MB_DeleteMailbox::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_DeleteMailbox(const char *MailBoxName) 
{
	c_Moses_MB_DeleteMailbox m;

	m.MailBoxName 	= MailBoxName;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_DeleteMailbox::IdMsg)
	{
		a_Moses_MB_DeleteMailbox *answ = (a_Moses_MB_DeleteMailbox *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

