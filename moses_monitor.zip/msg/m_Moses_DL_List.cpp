#include <st_dbnew.h>
#include "m_Moses_DL_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "DL.h"
#endif


c_Moses_DL_List::c_Moses_DL_List()
{
}

c_Moses_DL_List::c_Moses_DL_List(const c_Moses_DL_List &r)
{
}

c_Moses_DL_List::~c_Moses_DL_List() {}


void c_Moses_DL_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_DL_List::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_DL_List);

GenericMsg * c_Moses_DL_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return DL_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_DL_List::a_Moses_DL_List(const char *pErr) { Error = pErr; }
a_Moses_DL_List::a_Moses_DL_List()
{
}

a_Moses_DL_List::a_Moses_DL_List(const a_Moses_DL_List &r)
{
	Error	    = r.Error;
	DLNameList  = r.DLNameList;
	DLPwdList   = r.DLPwdList;
	DLDescrList = r.DLDescrList;
}

a_Moses_DL_List::~a_Moses_DL_List()
{
}

void a_Moses_DL_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(DLNameList, b, d);
	pSer->Serialize(DLPwdList, b, d);
	pSer->Serialize(DLDescrList, b, d);
}

void a_Moses_DL_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error       " << Error       << endl;
	s << "DLNameList  " << DLNameList  << endl;
	s << "DLPwdList   " << DLPwdList   << endl;
	s << "DLDescrList " << DLDescrList << endl;
}

Implement_Class(a_Moses_DL_List);

GenericMsg * a_Moses_DL_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_DL_List(
		VECT<STRING> &out_DLNameList,
		VECT<STRING> &out_DLPwdList,
		VECT<STRING> &out_DLDescrList)
{
	c_Moses_DL_List m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_DL_List::IdMsg)
	{
		a_Moses_DL_List *answ = (a_Moses_DL_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_DLNameList  = answ->DLNameList;
			out_DLPwdList   = answ->DLPwdList;
			out_DLDescrList = answ->DLDescrList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

///////////////////////////////////////////////////////////////////////////////
