#include <st_dbnew.h>
#ifndef __Moses_Work_Begin_h__
#define __Moses_Work_Begin_h__

#include "gnricmsg.h"

class c_Moses_Work_Begin : public GenericMsg
{
public:

	STRING Login;
	STRING Pwd;
	STRING ClientType;

	c_Moses_Work_Begin();
	c_Moses_Work_Begin(const c_Moses_Work_Begin &r);
	~c_Moses_Work_Begin();

	Declare_Class(c_Moses_Work_Begin);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_Work_Begin : public GenericMsg
{
public:

	STRING Error;
	INT32  Pid;


	a_Moses_Work_Begin(const char *pErr);
	a_Moses_Work_Begin();

	a_Moses_Work_Begin(const a_Moses_Work_Begin &r);

	~a_Moses_Work_Begin();

	Declare_Class(a_Moses_Work_Begin);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
