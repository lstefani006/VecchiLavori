#include <st_dbnew.h>
#include "m_Moses_MB_ChangePassword.h"
#include "m_Error.h"


#ifdef MOSES_SERVER
	#include "MB.h"
#endif

c_Moses_MB_ChangePassword::c_Moses_MB_ChangePassword()
{
}

c_Moses_MB_ChangePassword::c_Moses_MB_ChangePassword(const c_Moses_MB_ChangePassword &r)
{
	MailBoxName     = r.MailBoxName;
	PwdCurrent    	= r.PwdCurrent;
	PwdNew    		= r.PwdNew;
}

c_Moses_MB_ChangePassword::~c_Moses_MB_ChangePassword() {}


void c_Moses_MB_ChangePassword::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(PwdCurrent, b, d);
	pSer->Serialize(PwdNew, b, d);
}

void c_Moses_MB_ChangePassword::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName" << MailBoxName << endl;
	s << "\tPwdCurrent " << PwdCurrent  << endl;
	s << "\tPwdNew     " << PwdNew      << endl;
}

Implement_Class(c_Moses_MB_ChangePassword);



GenericMsg * c_Moses_MB_ChangePassword::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_ChangePassword(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_ChangePassword::a_Moses_MB_ChangePassword(const char *pErr) { Error = pErr; }
a_Moses_MB_ChangePassword::a_Moses_MB_ChangePassword() {}

a_Moses_MB_ChangePassword::a_Moses_MB_ChangePassword(const a_Moses_MB_ChangePassword &r)
{
	Error	= r.Error;
}

a_Moses_MB_ChangePassword::~a_Moses_MB_ChangePassword() {}

void a_Moses_MB_ChangePassword::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_ChangePassword::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError " << Error  << endl;
}

Implement_Class(a_Moses_MB_ChangePassword);

GenericMsg * a_Moses_MB_ChangePassword::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_ChangePassword(const char *MailBoxName, 
							   const char *PwdCurrent,
							   const char *PwdNew)
{
	c_Moses_MB_ChangePassword m;

	m.MailBoxName 	= MailBoxName;
	m.PwdCurrent   	= PwdCurrent;
	m.PwdNew   	    = PwdNew;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_ChangePassword::IdMsg)
	{
		a_Moses_MB_ChangePassword *answ = (a_Moses_MB_ChangePassword *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

