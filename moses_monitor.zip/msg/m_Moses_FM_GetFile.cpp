#include <st_dbnew.h>
#include "m_Moses_FM_GetFile.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "FM.h"
#endif


c_Moses_FM_GetFile::c_Moses_FM_GetFile()
{
}

c_Moses_FM_GetFile::c_Moses_FM_GetFile(const c_Moses_FM_GetFile &r)
{
	StartPathNameFile = r.StartPathNameFile;
}

c_Moses_FM_GetFile::~c_Moses_FM_GetFile() {}


void c_Moses_FM_GetFile::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(StartPathNameFile, b, d);
}

void c_Moses_FM_GetFile::Print(ostream &s) const
{
	BASE::Print(s);
	s << "StartPathNameFile   " << StartPathNameFile    << endl;
}

Implement_Class(c_Moses_FM_GetFile);



GenericMsg * c_Moses_FM_GetFile::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER 
	return FM_GetFile(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_FM_GetFile::a_Moses_FM_GetFile(const char *pErr) { Error = pErr; }
a_Moses_FM_GetFile::a_Moses_FM_GetFile() {}

a_Moses_FM_GetFile::a_Moses_FM_GetFile(const a_Moses_FM_GetFile &r)
{
	Error    = r.Error;
	BodyFile = r.BodyFile;
}

a_Moses_FM_GetFile::~a_Moses_FM_GetFile() {}

void a_Moses_FM_GetFile::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(BodyFile, b, d);
}

void a_Moses_FM_GetFile::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error        " << Error         << endl;
	s << "BodyFile     " << BodyFile      << endl;
}

Implement_Class(a_Moses_FM_GetFile);

GenericMsg * a_Moses_FM_GetFile::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_FM_GetFile(const char    *StartPathNameFile, 
						STRING        &out_BodyFile)
{
	c_Moses_FM_GetFile m;

	m.StartPathNameFile 	= StartPathNameFile;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_FM_GetFile::IdMsg)
	{
		a_Moses_FM_GetFile *answ = (a_Moses_FM_GetFile *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_BodyFile  = answ->BodyFile;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

