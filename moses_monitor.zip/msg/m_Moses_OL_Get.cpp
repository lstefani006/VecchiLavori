#include <st_dbnew.h>
#include "m_Moses_OL_Get.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "OL.h"
#endif

c_Moses_OL_Get::c_Moses_OL_Get()
{
}

c_Moses_OL_Get::c_Moses_OL_Get(const c_Moses_OL_Get &r)
{
}

c_Moses_OL_Get::~c_Moses_OL_Get() {}


void c_Moses_OL_Get::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_OL_Get::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_OL_Get);


GenericMsg * c_Moses_OL_Get::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return OL_Get(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_OL_Get::a_Moses_OL_Get(const char *pErr) { Error = pErr; }
a_Moses_OL_Get::a_Moses_OL_Get() {}

a_Moses_OL_Get::a_Moses_OL_Get(const a_Moses_OL_Get &r)
{
	Error	= r.Error;
	DaysAccessed	= r.DaysAccessed;
	DaysSent	    = r.DaysSent;
	DaysDispatched	= r.DaysDispatched;
}

a_Moses_OL_Get::~a_Moses_OL_Get() {}

void a_Moses_OL_Get::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(DaysAccessed, b, d);
	pSer->Serialize(DaysSent,b, d);
	pSer->Serialize(DaysDispatched,b, d);
}

void a_Moses_OL_Get::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error          " << Error           << endl;
	s << "DaysAccessed   " << DaysAccessed    << endl;
	s << "DaysSent       " << DaysSent        << endl;
	s << "DaysDispatched " << DaysDispatched  << endl;
}

Implement_Class(a_Moses_OL_Get);



GenericMsg * a_Moses_OL_Get::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_OL_Get(STRING &out_DaysAccessed, 
		            STRING &out_DaysSent, 
		            STRING &out_DaysDispatched)
{
	c_Moses_OL_Get m;


	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_OL_Get::IdMsg)
	{
		a_Moses_OL_Get *answ = (a_Moses_OL_Get *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_DaysAccessed	= answ->DaysAccessed;
			out_DaysSent  	    = answ->DaysSent;
			out_DaysDispatched  = answ->DaysDispatched;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


