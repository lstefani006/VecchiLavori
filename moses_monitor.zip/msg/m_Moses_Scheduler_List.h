#include <st_dbnew.h>
#ifndef __Moses_Scheduler_List_h__
#define __Moses_Scheduler_List_h__

#include "gnricmsg.h"


class c_Moses_Scheduler_List : public GenericMsg
{
public:
	c_Moses_Scheduler_List();
	c_Moses_Scheduler_List(const c_Moses_Scheduler_List &r);
	~c_Moses_Scheduler_List();
	Declare_Class(c_Moses_Scheduler_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Scheduler_List : public GenericMsg
{
public:
	STRING Error;

	VECT<INT16>  IndexList;
	VECT<STRING> WhenList;
	VECT<STRING> ActionList;

	a_Moses_Scheduler_List(const char *pErr);
	a_Moses_Scheduler_List();
	a_Moses_Scheduler_List(const a_Moses_Scheduler_List &r);
	~a_Moses_Scheduler_List();
	Declare_Class(a_Moses_Scheduler_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
