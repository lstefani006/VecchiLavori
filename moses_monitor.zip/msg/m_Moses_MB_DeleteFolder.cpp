#include <st_dbnew.h>
#include "m_Moses_MB_DeleteFolder.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_DeleteFolder::c_Moses_MB_DeleteFolder()
{
}

c_Moses_MB_DeleteFolder::c_Moses_MB_DeleteFolder(const c_Moses_MB_DeleteFolder &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd      		= r.Pwd;
	Folder    		= r.Folder;
}

c_Moses_MB_DeleteFolder::~c_Moses_MB_DeleteFolder() {}


void c_Moses_MB_DeleteFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(Folder, b, d);
}

void c_Moses_MB_DeleteFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName = " << MailBoxName   << endl;
	s << "\tPwd         = " << Pwd           << endl;
	s << "\tFolder      = " << Folder        << endl;
}

Implement_Class(c_Moses_MB_DeleteFolder);



GenericMsg * c_Moses_MB_DeleteFolder::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_DeleteFolder(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_DeleteFolder::a_Moses_MB_DeleteFolder(const char *pErr) { Error = pErr; }
a_Moses_MB_DeleteFolder::a_Moses_MB_DeleteFolder() {}

a_Moses_MB_DeleteFolder::a_Moses_MB_DeleteFolder(const a_Moses_MB_DeleteFolder &r)
{
	Error	= r.Error;
}

a_Moses_MB_DeleteFolder::~a_Moses_MB_DeleteFolder() {}

void a_Moses_MB_DeleteFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_DeleteFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError = " << Error  << endl;
}

Implement_Class(a_Moses_MB_DeleteFolder);

GenericMsg * a_Moses_MB_DeleteFolder::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_DeleteFolder(const char *MailBoxName, 
							 const char *Pwd,
							 const char *Folder)
{
	c_Moses_MB_DeleteFolder m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.Folder   	    = Folder;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_DeleteFolder::IdMsg)
	{
		a_Moses_MB_DeleteFolder *answ = (a_Moses_MB_DeleteFolder *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

