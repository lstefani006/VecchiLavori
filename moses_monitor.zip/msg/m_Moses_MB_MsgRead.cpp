#include <st_dbnew.h>
#include "m_Moses_MB_MsgRead.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_MsgRead::c_Moses_MB_MsgRead()
{
}

c_Moses_MB_MsgRead::c_Moses_MB_MsgRead(const c_Moses_MB_MsgRead &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
	MsgId    		= r.MsgId;
}

c_Moses_MB_MsgRead::~c_Moses_MB_MsgRead() {}


void c_Moses_MB_MsgRead::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(MsgId, b, d);
}

void c_Moses_MB_MsgRead::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName " << MailBoxName << endl;
	s << "\tPwd         " << Pwd         << endl;
	s << "\tMsgId       " << MsgId       << endl;
}

Implement_Class(c_Moses_MB_MsgRead);



GenericMsg * c_Moses_MB_MsgRead::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_MsgRead(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_MsgRead::a_Moses_MB_MsgRead(const char *pErr) { Error = pErr; }
a_Moses_MB_MsgRead::a_Moses_MB_MsgRead() {}

a_Moses_MB_MsgRead::a_Moses_MB_MsgRead(const a_Moses_MB_MsgRead &r)
{
	Error	= r.Error;
	Body	= r.Body;
}

a_Moses_MB_MsgRead::~a_Moses_MB_MsgRead() {}

void a_Moses_MB_MsgRead::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(Body, b, d);
}

void a_Moses_MB_MsgRead::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError  " << Error << endl;
	s << "\tBody   " << Body  << endl;
}

Implement_Class(a_Moses_MB_MsgRead);

GenericMsg * a_Moses_MB_MsgRead::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_MsgRead(const char   *MailBoxName, 
					    const char   *Pwd,
					    int           MsgId,
					    STRING       &out_Body)
{
	c_Moses_MB_MsgRead m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.MsgId         = MsgId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_MsgRead::IdMsg)
	{
		a_Moses_MB_MsgRead *answ = (a_Moses_MB_MsgRead *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_Body = answ->Body;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

