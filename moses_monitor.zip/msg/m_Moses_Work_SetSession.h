#include <st_dbnew.h>
#ifndef __Moses_Work_SetSession_h__
#define __Moses_Work_SetSession_h__

#include "gnricmsg.h"


class c_Moses_Work_SetSession : public GenericMsg
{
public:
	INT16 bClosed;
	
	c_Moses_Work_SetSession();
	c_Moses_Work_SetSession(const c_Moses_Work_SetSession &r);
	~c_Moses_Work_SetSession();
	Declare_Class(c_Moses_Work_SetSession);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Work_SetSession : public GenericMsg
{
public:
	STRING Error;

	a_Moses_Work_SetSession(const char *pErr);
	a_Moses_Work_SetSession();
	a_Moses_Work_SetSession(const a_Moses_Work_SetSession &r);
	~a_Moses_Work_SetSession();
	Declare_Class(a_Moses_Work_SetSession);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
