#include <st_dbnew.h>
#ifndef __Moses_Event_NewMsgForMTD_h__
#define __Moses_Event_NewMsgForMTD_h__

#include "gnricmsg.h"

class c_Moses_Event_NewMsgForMTD : public GenericMsg
{
public:

	STRING MailType;

	c_Moses_Event_NewMsgForMTD();
	c_Moses_Event_NewMsgForMTD(const c_Moses_Event_NewMsgForMTD &r);
	~c_Moses_Event_NewMsgForMTD();

	Declare_Class(c_Moses_Event_NewMsgForMTD);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_Event_NewMsgForMTD : public GenericMsg
{
public:

	STRING Error;
	INT32  EventId;

	a_Moses_Event_NewMsgForMTD(const char *pErr);
	a_Moses_Event_NewMsgForMTD();

	a_Moses_Event_NewMsgForMTD(const a_Moses_Event_NewMsgForMTD &r);

	~a_Moses_Event_NewMsgForMTD();

	Declare_Class(a_Moses_Event_NewMsgForMTD);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
