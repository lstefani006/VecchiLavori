#include <st_dbnew.h>
#include "m_Moses_ART_InAddress.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "ART.h"
#endif

c_Moses_ART_InAddress::c_Moses_ART_InAddress()
{
}

c_Moses_ART_InAddress::c_Moses_ART_InAddress(const c_Moses_ART_InAddress &r)
{
	MailBoxType    = r.MailBoxType;
	MailBoxAddress = r.MailBoxAddress;
	Subject        = r.Subject;
}

c_Moses_ART_InAddress::~c_Moses_ART_InAddress() {}


void c_Moses_ART_InAddress::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxType,  b, d);
	pSer->Serialize(MailBoxAddress, b, d);
	pSer->Serialize(Subject, b, d);
}

void c_Moses_ART_InAddress::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MailBoxType   " << MailBoxType    << endl;
	s << "MailBoxAddress" << MailBoxAddress << endl;
	s << "Subject       " << Subject        << endl;
}

Implement_Class(c_Moses_ART_InAddress);


GenericMsg * c_Moses_ART_InAddress::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return ART_InAddress(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_ART_InAddress::a_Moses_ART_InAddress(const char *pErr) { Error = pErr; }
a_Moses_ART_InAddress::a_Moses_ART_InAddress() {}

a_Moses_ART_InAddress::a_Moses_ART_InAddress(const a_Moses_ART_InAddress &r)
{
	Error	       = r.Error;
	User           = r.User;
}

a_Moses_ART_InAddress::~a_Moses_ART_InAddress() {}

void a_Moses_ART_InAddress::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(User, b, d);
}

void a_Moses_ART_InAddress::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error         " << Error          << endl;
	s << "User          " << User           << endl;
}

Implement_Class(a_Moses_ART_InAddress);



GenericMsg * a_Moses_ART_InAddress::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////

STRING Moses_ART_InAddress  (const char *MailBoxType,
						     const char *MailAddress, 
						     const char *SubjectAdd, 
							 STRING &out_User)
{
	c_Moses_ART_InAddress m;

	m.MailBoxType 	  = MailBoxType;
	m.MailBoxAddress  = MailAddress;
	m.Subject 	      = SubjectAdd;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_ART_InAddress::IdMsg)
	{
		a_Moses_ART_InAddress *answ = (a_Moses_ART_InAddress *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_User  = answ->User;     	 
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


