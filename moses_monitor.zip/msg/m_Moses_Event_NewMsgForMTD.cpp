#include <st_dbnew.h>
#include "m_Moses_Event_NewMsgForMTD.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Event.h"
#endif

c_Moses_Event_NewMsgForMTD::c_Moses_Event_NewMsgForMTD()
{
}

c_Moses_Event_NewMsgForMTD::c_Moses_Event_NewMsgForMTD(const c_Moses_Event_NewMsgForMTD &r)
{
	MailType	= r.MailType;
}

c_Moses_Event_NewMsgForMTD::~c_Moses_Event_NewMsgForMTD() {}


void c_Moses_Event_NewMsgForMTD::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailType, b, d);
}

void c_Moses_Event_NewMsgForMTD::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MailType  " << MailType   << endl;
}

Implement_Class(c_Moses_Event_NewMsgForMTD);



GenericMsg * c_Moses_Event_NewMsgForMTD::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Event_NewMsgForMTD(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Event_NewMsgForMTD::a_Moses_Event_NewMsgForMTD(const char *pErr) { Error = pErr; }
a_Moses_Event_NewMsgForMTD::a_Moses_Event_NewMsgForMTD() {}

a_Moses_Event_NewMsgForMTD::a_Moses_Event_NewMsgForMTD(const a_Moses_Event_NewMsgForMTD &r)
{
	Error	= r.Error;
	EventId = r.EventId;
}

a_Moses_Event_NewMsgForMTD::~a_Moses_Event_NewMsgForMTD() {}

void a_Moses_Event_NewMsgForMTD::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b,       pSer, d);
	pSer->Serialize(Error,   b,    d);
	pSer->Serialize(EventId, b,    d);
}

void a_Moses_Event_NewMsgForMTD::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error   " << Error    << endl;
	s << "EventId " << EventId  << endl;
}

Implement_Class(a_Moses_Event_NewMsgForMTD);

GenericMsg * a_Moses_Event_NewMsgForMTD::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_Event_NewMsgForMTD(
		const char *MailType,
		INT32 &out_EventId)
{
	c_Moses_Event_NewMsgForMTD m;

	m.MailType 	= MailType;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Event_NewMsgForMTD::IdMsg)
	{
		a_Moses_Event_NewMsgForMTD *answ = (a_Moses_Event_NewMsgForMTD *)pMsg;

                out_EventId = answ->EventId;

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

