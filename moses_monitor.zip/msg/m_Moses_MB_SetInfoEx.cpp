#include <st_dbnew.h>
#include "m_Moses_MB_SetInfoEx.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_SetInfoEx::c_Moses_MB_SetInfoEx()
{
}

c_Moses_MB_SetInfoEx::c_Moses_MB_SetInfoEx(const c_Moses_MB_SetInfoEx &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
	MsgId    		= r.MsgId;
	Sender          = r.Sender;
	Destination     = r.Destination;
	Subject         = r.Subject;
	bIncoming       = r.bIncoming;
	Status          = r.Status;
}

c_Moses_MB_SetInfoEx::~c_Moses_MB_SetInfoEx() {}


void c_Moses_MB_SetInfoEx::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd        , b, d);
	pSer->Serialize(MsgId      , b, d);
	pSer->Serialize(Sender     , b, d);
	pSer->Serialize(Destination, b, d);
	pSer->Serialize(Subject    , b, d);
	pSer->Serialize(bIncoming  , b, d);
	pSer->Serialize(Status     , b, d);
}

void c_Moses_MB_SetInfoEx::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName " << MailBoxName << endl;
	s << "\tPwd         " << Pwd         << endl;
	s << "\tMsgId       " << MsgId       << endl;
	s << "\tSender      " << Sender      << endl;
	s << "\tDestination " << Destination << endl;
	s << "\tSubject     " << Subject     << endl;
	s << "\tbIncoming   " << bIncoming   << endl;
	s << "\tStatus      " << Status      << endl;
}

Implement_Class(c_Moses_MB_SetInfoEx);



GenericMsg * c_Moses_MB_SetInfoEx::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_SetInfoEx(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_SetInfoEx::a_Moses_MB_SetInfoEx(const char *pErr) { Error = pErr; }
a_Moses_MB_SetInfoEx::a_Moses_MB_SetInfoEx() {}

a_Moses_MB_SetInfoEx::a_Moses_MB_SetInfoEx(const a_Moses_MB_SetInfoEx &r)
{
	Error		= r.Error;
}

a_Moses_MB_SetInfoEx::~a_Moses_MB_SetInfoEx() {}

void a_Moses_MB_SetInfoEx::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_SetInfoEx::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError " << Error << endl;
}

Implement_Class(a_Moses_MB_SetInfoEx);

GenericMsg * a_Moses_MB_SetInfoEx::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_SetInfoEx(
		const char   *MailBoxName, 
		const char   *Pwd,
		INT32         MsgId,
		STRING        Sender,
		STRING        Receiver,
		STRING        Subject,
		INT16         bIncoming,
		VECT<STRING> &Status)
{
	c_Moses_MB_SetInfoEx m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.MsgId   	    = MsgId;
	m.Sender        = Sender;
	m.Destination   = Receiver;
	m.Subject       = Subject;
	m.bIncoming     = bIncoming;
	m.Status   	    = Status;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_SetInfoEx::IdMsg)
	{
		a_Moses_MB_SetInfoEx *answ = (a_Moses_MB_SetInfoEx *)pMsg;

		if (answ->Error.Len() == 0)
		{
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

