#include <st_dbnew.h>
#ifndef __Moses_EH_Delete_h__
#define __Moses_EH_Delete_h__

#include "gnricmsg.h"

class c_Moses_EH_Delete : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Folder;
	INT32  Index;

	c_Moses_EH_Delete();
	c_Moses_EH_Delete(const c_Moses_EH_Delete &r);
	~c_Moses_EH_Delete();

	Declare_Class(c_Moses_EH_Delete);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_EH_Delete : public GenericMsg
{
public:

	STRING Error;
	INT32  Valid;

	a_Moses_EH_Delete(const char *pErr);
	a_Moses_EH_Delete();

	a_Moses_EH_Delete(const a_Moses_EH_Delete &r);

	~a_Moses_EH_Delete();

	Declare_Class(a_Moses_EH_Delete);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
