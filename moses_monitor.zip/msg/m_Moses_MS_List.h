#include <st_dbnew.h>
#ifndef __Moses_MS_List_h__
#define __Moses_MS_List_h__

#include "gnricmsg.h"


class c_Moses_MS_List : public GenericMsg
{
public:
	c_Moses_MS_List();
	c_Moses_MS_List(const c_Moses_MS_List &r);
	~c_Moses_MS_List();
	Declare_Class(c_Moses_MS_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_MS_List : public GenericMsg
{
public:
	STRING Error;

	VECT<STRING> MSTypeList;
	VECT<STRING> MSDescrList;

	a_Moses_MS_List(const char *pErr);
	a_Moses_MS_List();
	a_Moses_MS_List(const a_Moses_MS_List &r);
	~a_Moses_MS_List();
	Declare_Class(a_Moses_MS_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
