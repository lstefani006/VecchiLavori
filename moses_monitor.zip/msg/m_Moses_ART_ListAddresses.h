#include <st_dbnew.h>
#ifndef __Moses_ART_ListAddresses_h__
#define __Moses_ART_ListAddresses_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_ART_ListAddresses : public GenericMsg
{
public:

	INT16  bInternal;
	STRING MailBoxType;

	c_Moses_ART_ListAddresses();
	c_Moses_ART_ListAddresses(const c_Moses_ART_ListAddresses &r);
	~c_Moses_ART_ListAddresses();
	Declare_Class(c_Moses_ART_ListAddresses);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_ART_ListAddresses : public GenericMsg
{
public:
	
	STRING Error;
	VECT<STRING> MailAddresses;

	a_Moses_ART_ListAddresses(const char *pErr);
	a_Moses_ART_ListAddresses();
	a_Moses_ART_ListAddresses(const a_Moses_ART_ListAddresses &r);
	~a_Moses_ART_ListAddresses();
	Declare_Class(a_Moses_ART_ListAddresses);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
