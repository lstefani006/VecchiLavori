#include <st_dbnew.h>
#include "m_Moses_User_Modify.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
    #include "User.h"
	#include "server.h"
#endif


c_Moses_User_Modify::c_Moses_User_Modify()
{
}

c_Moses_User_Modify::c_Moses_User_Modify(const c_Moses_User_Modify &r)
{
	UserName         = r.UserName;
	UserPwd          = r.UserPwd;
	UserClientType   = r.UserClientType;
	UserDescr        = r.UserDescr;
	UserRights       = r.UserRights;
	UserDefaultMBox  = r.UserDefaultMBox;
	UserKeyId        = r.UserKeyId;
}

c_Moses_User_Modify::~c_Moses_User_Modify() {}


void c_Moses_User_Modify::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(UserName, b, d);
	pSer->Serialize(UserPwd, b, d);
	pSer->Serialize(UserClientType, b, d);
	pSer->Serialize(UserDescr, b, d);
	pSer->Serialize(UserRights, b, d);
	pSer->Serialize(UserDefaultMBox, b, d);
	pSer->Serialize(UserKeyId, b, d);
}

void c_Moses_User_Modify::Print(ostream &s) const
{
	BASE::Print(s);
	s << "UserName       " << UserName        << endl;
	s << "UserPwd        " << UserPwd         << endl;
	s << "UserClientType " << UserClientType  << endl;
	s << "UserDescr      " << UserDescr       << endl;
	s << "UserRights     " << UserRights      << endl;
	s << "UserDefaultMBox" << UserDefaultMBox << endl;
	s << "UserKeyId      " << UserKeyId       << endl;
}

Implement_Class(c_Moses_User_Modify);



GenericMsg * c_Moses_User_Modify::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return User_Modify(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_User_Modify::a_Moses_User_Modify(const char *pErr) { Error = pErr; }
a_Moses_User_Modify::a_Moses_User_Modify() {}

a_Moses_User_Modify::a_Moses_User_Modify(const a_Moses_User_Modify &r)
{
	Error	= r.Error;
}

a_Moses_User_Modify::~a_Moses_User_Modify() {}

void a_Moses_User_Modify::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_User_Modify::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_User_Modify);

GenericMsg * a_Moses_User_Modify::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_User_Modify(const char *UserName, 
					     const char *UserPwd,
					     const char *UserClientType,
					     const char *UserDescr,
					     const char *UserRights,
					     const char *UserDefaultMBox,
						 const char *UserKeyId)
{
	c_Moses_User_Modify m;

	m.UserName 	 	  = UserName;
	m.UserPwd   	  = UserPwd;
	m.UserClientType  = UserClientType;
	m.UserDescr   	  = UserDescr;
	m.UserRights   	  = UserRights;
	m.UserDefaultMBox = UserDefaultMBox;
	m.UserKeyId   	  = UserKeyId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_User_Modify::IdMsg)
	{
		a_Moses_User_Modify *answ = (a_Moses_User_Modify *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

