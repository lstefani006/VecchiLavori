#include <st_dbnew.h>
#ifndef __Moses_ART_List_h__
#define __Moses_ART_List_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_ART_List : public GenericMsg
{
public:

	INT32  Index;

	c_Moses_ART_List();
	c_Moses_ART_List(const c_Moses_ART_List &r);
	~c_Moses_ART_List();
	Declare_Class(c_Moses_ART_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_ART_List : public GenericMsg
{
public:

	STRING Error;
	STRING User;
	INT16  bInternal;
	STRING MailBoxType;
	STRING MailBoxAddress;
	STRING Subject;
	INT16  Valid;
	
	a_Moses_ART_List(const char *pErr);
	a_Moses_ART_List();
	a_Moses_ART_List(const a_Moses_ART_List &r);
	~a_Moses_ART_List();
	Declare_Class(a_Moses_ART_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
