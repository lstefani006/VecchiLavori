#include <st_dbnew.h>
#include "m_Moses_Work_ListLanguage.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Work.h"
#endif


c_Moses_Work_ListLanguage::c_Moses_Work_ListLanguage()
{
}

c_Moses_Work_ListLanguage::c_Moses_Work_ListLanguage(const c_Moses_Work_ListLanguage &r)
{
}

c_Moses_Work_ListLanguage::~c_Moses_Work_ListLanguage() {}


void c_Moses_Work_ListLanguage::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_Work_ListLanguage::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_Work_ListLanguage);

GenericMsg * c_Moses_Work_ListLanguage::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Work_ListLanguage(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Work_ListLanguage::a_Moses_Work_ListLanguage(const char *pErr) { Error = pErr; }
a_Moses_Work_ListLanguage::a_Moses_Work_ListLanguage()
{
}

a_Moses_Work_ListLanguage::a_Moses_Work_ListLanguage(const a_Moses_Work_ListLanguage &r)
{
	Error	     = r.Error;
	ListCodLang  = r.ListCodLang;
	ListDesLang  = r.ListDesLang;
}

a_Moses_Work_ListLanguage::~a_Moses_Work_ListLanguage()
{
}

void a_Moses_Work_ListLanguage::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(ListCodLang, b, d);
	pSer->Serialize(ListDesLang, b, d);
}

void a_Moses_Work_ListLanguage::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError       " << Error        << endl;
	s << "\tListCodLang " << ListCodLang  << endl;
	s << "\tListDesLang " << ListDesLang  << endl;
}

Implement_Class(a_Moses_Work_ListLanguage);

GenericMsg * a_Moses_Work_ListLanguage::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Work_ListLanguage(VECT<STRING> &out_ListCodLang,
		VECT<STRING> &out_ListDesLang)
{
	c_Moses_Work_ListLanguage m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Work_ListLanguage::IdMsg)
	{
		a_Moses_Work_ListLanguage *answ = (a_Moses_Work_ListLanguage *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_ListCodLang  = answ->ListCodLang;
			out_ListDesLang  = answ->ListDesLang;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

