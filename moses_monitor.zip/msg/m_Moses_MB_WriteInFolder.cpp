#include <st_dbnew.h>
#include "m_Moses_MB_WriteInFolder.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif

c_Moses_MB_WriteInFolder::c_Moses_MB_WriteInFolder()
{
}

c_Moses_MB_WriteInFolder::c_Moses_MB_WriteInFolder(const c_Moses_MB_WriteInFolder &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd      		= r.Pwd;
	Folder    		= r.Folder;
	MsgId    		= r.MsgId;
	Sender    		= r.Sender;
	Destination    	= r.Destination;
	Subject    		= r.Subject;
	bIncoming  		= r.bIncoming;
	Body    		= r.Body;
}

c_Moses_MB_WriteInFolder::~c_Moses_MB_WriteInFolder() {}


void c_Moses_MB_WriteInFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(Folder, b, d);
	pSer->Serialize(MsgId, b, d);
	pSer->Serialize(Sender, b, d);
	pSer->Serialize(Destination, b, d);
	pSer->Serialize(Subject, b, d);
	pSer->Serialize(bIncoming, b, d);
	pSer->Serialize(Body, b, d);
}

void c_Moses_MB_WriteInFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName " << MailBoxName << endl;
	s << "\tPwd         " << Pwd         << endl;
	s << "\tFolder      " << Folder      << endl;
	s << "\tMsgId       " << MsgId       << endl;
	s << "\tSender      " << Sender      << endl;
	s << "\tDestination " << Destination << endl;
	s << "\tSubject     " << Subject     << endl;
	s << "\tbIncoming   " << bIncoming   << endl;
	s << "\tBody        " << Body        << endl;
}

Implement_Class(c_Moses_MB_WriteInFolder);



GenericMsg * c_Moses_MB_WriteInFolder::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_WriteInFolder(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_WriteInFolder::a_Moses_MB_WriteInFolder(const char *pErr) { Error = pErr; }
a_Moses_MB_WriteInFolder::a_Moses_MB_WriteInFolder() {}

a_Moses_MB_WriteInFolder::a_Moses_MB_WriteInFolder(const a_Moses_MB_WriteInFolder &r)
{
	Error		= r.Error;
}

a_Moses_MB_WriteInFolder::~a_Moses_MB_WriteInFolder() {}

void a_Moses_MB_WriteInFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_WriteInFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError  " << Error << endl;
}

Implement_Class(a_Moses_MB_WriteInFolder);

GenericMsg * a_Moses_MB_WriteInFolder::P_ServerExecute(int)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_WriteInFolder (const char   *MailBoxName, 
							   const char   *Pwd,
							   const char   *Folder,
							   int           MsgId,
							   const char   *Sender,
							   const char   *Destination,
							   const char   *Subject,
							   int           bIncoming,
							   int           szBody,
							   const char   *Body)
{
	c_Moses_MB_WriteInFolder m;

	m.MailBoxName   = MailBoxName;
	m.Pwd    		= Pwd;
	m.Folder    	= Folder;
	m.MsgId    		= MsgId;
	m.Sender    	= Sender;
	m.Destination   = Destination;
	m.Subject    	= Subject;
	m.bIncoming     = bIncoming;
	m.Body    		= STRING(Body, szBody);
	
	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_WriteInFolder::IdMsg)
	{
		a_Moses_MB_WriteInFolder *answ = (a_Moses_MB_WriteInFolder *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

