#include <st_dbnew.h>
#include "m_Moses_Client_Kill.h"
#include "m_Error.h"


#ifdef MOSES_SERVER
	#include "Client.h"
#endif

c_Moses_Client_Kill::c_Moses_Client_Kill()
{
}

c_Moses_Client_Kill::c_Moses_Client_Kill(const c_Moses_Client_Kill &r)
{
	ClientName	= r.ClientName;
}

c_Moses_Client_Kill::~c_Moses_Client_Kill() {}


void c_Moses_Client_Kill::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(ClientName, b, d);
}

void c_Moses_Client_Kill::Print(ostream &s) const
{
	BASE::Print(s);
	s << "ClientName" << ClientName << endl;
}

Implement_Class(c_Moses_Client_Kill);


GenericMsg * c_Moses_Client_Kill::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Client_Kill(this, nClient);
#else
	return NULL;
#endif
}


///////////////////////////////////////////////////////////////////////////////


a_Moses_Client_Kill::a_Moses_Client_Kill(const char *pErr) { Error = pErr; }
a_Moses_Client_Kill::a_Moses_Client_Kill() {}

a_Moses_Client_Kill::a_Moses_Client_Kill(const a_Moses_Client_Kill &r)
{
	Error	= r.Error;
}

a_Moses_Client_Kill::~a_Moses_Client_Kill() {}

void a_Moses_Client_Kill::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Client_Kill::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_Client_Kill);



GenericMsg * a_Moses_Client_Kill::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Client_Kill(const char *ClientName)
{
	c_Moses_Client_Kill m;

	m.ClientName	= ClientName;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Client_Kill::IdMsg)
	{
		a_Moses_Client_Kill *answ = (a_Moses_Client_Kill *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


