#include <st_dbnew.h>
#ifndef __Moses_Client_Add_h__
#define __Moses_Client_Add_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_Client_Add : public GenericMsg
{
public:
	STRING ClientName;
	STRING ClientDescr;
	STRING ClientType;
	INT16  Active;

	c_Moses_Client_Add();
	c_Moses_Client_Add(const c_Moses_Client_Add &r);
	~c_Moses_Client_Add();
	Declare_Class(c_Moses_Client_Add);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Client_Add : public GenericMsg
{
public:
	STRING Error;

	a_Moses_Client_Add(const char *pErr);
	a_Moses_Client_Add();
	a_Moses_Client_Add(const a_Moses_Client_Add &r);
	~a_Moses_Client_Add();
	Declare_Class(a_Moses_Client_Add);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
