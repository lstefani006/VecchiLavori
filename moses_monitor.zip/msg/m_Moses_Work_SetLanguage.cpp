#include <st_dbnew.h>
#include "m_Moses_Work_SetLanguage.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Work.h"
#endif


c_Moses_Work_SetLanguage::c_Moses_Work_SetLanguage()
{
}

c_Moses_Work_SetLanguage::c_Moses_Work_SetLanguage(const c_Moses_Work_SetLanguage &r)
{
	Language = r.Language;
}

c_Moses_Work_SetLanguage::~c_Moses_Work_SetLanguage() {}


void c_Moses_Work_SetLanguage::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Language, b, d);
}

void c_Moses_Work_SetLanguage::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\t\tLanguage" << Language << endl;
}

Implement_Class(c_Moses_Work_SetLanguage);

GenericMsg * c_Moses_Work_SetLanguage::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Work_SetLanguage(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Work_SetLanguage::a_Moses_Work_SetLanguage(const char *pErr) { Error = pErr; }
a_Moses_Work_SetLanguage::a_Moses_Work_SetLanguage()
{
}

a_Moses_Work_SetLanguage::a_Moses_Work_SetLanguage(const a_Moses_Work_SetLanguage &r)
{
	Error	     = r.Error;
}

a_Moses_Work_SetLanguage::~a_Moses_Work_SetLanguage()
{
}

void a_Moses_Work_SetLanguage::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Work_SetLanguage::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError       " << Error        << endl;
}

Implement_Class(a_Moses_Work_SetLanguage);

GenericMsg * a_Moses_Work_SetLanguage::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Work_SetLanguage(VECT<STRING> &out_ListCodLang,
		VECT<STRING> &out_ListDesLang)
{
	c_Moses_Work_SetLanguage m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Work_SetLanguage::IdMsg)
	{
		a_Moses_Work_SetLanguage *answ = (a_Moses_Work_SetLanguage *)pMsg;

		if (answ->Error.Len() == 0)
		{
			// NON ci sono parametri di output.	
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

