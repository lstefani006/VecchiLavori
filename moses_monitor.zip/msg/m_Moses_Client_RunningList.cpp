#include <st_dbnew.h>
#include "m_Moses_Client_RunningList.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Client.h"
#endif


c_Moses_Client_RunningList::c_Moses_Client_RunningList()
{
}

c_Moses_Client_RunningList::c_Moses_Client_RunningList(const c_Moses_Client_RunningList &r)
{
}

c_Moses_Client_RunningList::~c_Moses_Client_RunningList() {}


void c_Moses_Client_RunningList::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_Client_RunningList::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_Client_RunningList);

GenericMsg * c_Moses_Client_RunningList::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Client_RunningList(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Client_RunningList::a_Moses_Client_RunningList(const char *pErr) { Error = pErr; }
a_Moses_Client_RunningList::a_Moses_Client_RunningList()
{
}

a_Moses_Client_RunningList::a_Moses_Client_RunningList(const a_Moses_Client_RunningList &r)
{
	Error	    	= r.Error;
	ClientNameList  = r.ClientNameList;
}

a_Moses_Client_RunningList::~a_Moses_Client_RunningList()
{
}

void a_Moses_Client_RunningList::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(ClientNameList, b, d);
}

void a_Moses_Client_RunningList::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error          " << Error       << endl;
	s << "ClientNameList " << ClientNameList  << endl;
}

Implement_Class(a_Moses_Client_RunningList);

GenericMsg * a_Moses_Client_RunningList::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Client_RunningList(VECT<STRING> &out_ClientNameList)
{
	c_Moses_Client_RunningList m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Client_RunningList::IdMsg)
	{
		a_Moses_Client_RunningList *answ = (a_Moses_Client_RunningList *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_ClientNameList  = answ->ClientNameList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

///////////////////////////////////////////////////////////////////////////////
