#include <st_dbnew.h>
#include "m_Moses_Work_SetSession.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Work.h"
#endif


c_Moses_Work_SetSession::c_Moses_Work_SetSession()
{
}

c_Moses_Work_SetSession::c_Moses_Work_SetSession(const c_Moses_Work_SetSession &r)
{
	bClosed = r.bClosed;
}

c_Moses_Work_SetSession::~c_Moses_Work_SetSession() {}


void c_Moses_Work_SetSession::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(bClosed, b, d);
}

void c_Moses_Work_SetSession::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\t\tbClosed" << bClosed << endl;
}

Implement_Class(c_Moses_Work_SetSession);

GenericMsg * c_Moses_Work_SetSession::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Work_SetSession(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Work_SetSession::a_Moses_Work_SetSession(const char *pErr) { Error = pErr; }
a_Moses_Work_SetSession::a_Moses_Work_SetSession()
{
}

a_Moses_Work_SetSession::a_Moses_Work_SetSession(const a_Moses_Work_SetSession &r)
{
	Error	     = r.Error;
}

a_Moses_Work_SetSession::~a_Moses_Work_SetSession()
{
}

void a_Moses_Work_SetSession::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Work_SetSession::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError       " << Error        << endl;
}

Implement_Class(a_Moses_Work_SetSession);

GenericMsg * a_Moses_Work_SetSession::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Work_SetSession(int bClosed)
{
	c_Moses_Work_SetSession m;

	m.bClosed = bClosed;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Work_SetSession::IdMsg)
	{
		a_Moses_Work_SetSession *answ = (a_Moses_Work_SetSession *)pMsg;

		if (answ->Error.Len() == 0)
		{
			// NON ci sono parametri di output.	
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

