#include <st_dbnew.h>
#include "m_Moses_MB_MsgFile.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_MsgFile::c_Moses_MB_MsgFile()
{
}

c_Moses_MB_MsgFile::c_Moses_MB_MsgFile(const c_Moses_MB_MsgFile &r)
{
	MsgId    		= r.MsgId;
}

c_Moses_MB_MsgFile::~c_Moses_MB_MsgFile() {}


void c_Moses_MB_MsgFile::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MsgId, b, d);
}

void c_Moses_MB_MsgFile::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMsgId       " << MsgId       << endl;
}

Implement_Class(c_Moses_MB_MsgFile);



GenericMsg * c_Moses_MB_MsgFile::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_MsgFile(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_MsgFile::a_Moses_MB_MsgFile(const char *pErr) { Error = pErr; }
a_Moses_MB_MsgFile::a_Moses_MB_MsgFile() {}

a_Moses_MB_MsgFile::a_Moses_MB_MsgFile(const a_Moses_MB_MsgFile &r)
{
	Error	= r.Error;
	MsgFile	= r.MsgFile;
}

a_Moses_MB_MsgFile::~a_Moses_MB_MsgFile() {}

void a_Moses_MB_MsgFile::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(MsgFile, b, d);
}

void a_Moses_MB_MsgFile::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError   " << Error    << endl;
	s << "\tMsgFile " << MsgFile  << endl;
}

Implement_Class(a_Moses_MB_MsgFile);

GenericMsg * a_Moses_MB_MsgFile::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_MsgFile(INT32         MsgId,
					    STRING       &out_MsgFile)
{
	c_Moses_MB_MsgFile m;

	m.MsgId         = MsgId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_MsgFile::IdMsg)
	{
		a_Moses_MB_MsgFile *answ = (a_Moses_MB_MsgFile *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_MsgFile = answ->MsgFile;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

