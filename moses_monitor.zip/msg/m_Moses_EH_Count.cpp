#include <st_dbnew.h>
#include "m_Moses_EH_Count.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
    #include "EH.h"
	#include "server.h"
#endif

c_Moses_EH_Count::c_Moses_EH_Count()
{
}

c_Moses_EH_Count::c_Moses_EH_Count(const c_Moses_EH_Count &r)
{
	MailBoxName  = r.MailBoxName;
	Folder       = r.Folder;
}

c_Moses_EH_Count::~c_Moses_EH_Count() {}


void c_Moses_EH_Count::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Folder, b, d);
}

void c_Moses_EH_Count::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MailBoxName " << MailBoxName << endl;
	s << "Folder      " << Folder      << endl;
}

Implement_Class(c_Moses_EH_Count);


GenericMsg * c_Moses_EH_Count::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return EH_Count(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_EH_Count::a_Moses_EH_Count(const char *pErr) { Error = pErr; }
a_Moses_EH_Count::a_Moses_EH_Count() {}

a_Moses_EH_Count::a_Moses_EH_Count(const a_Moses_EH_Count &r)
{
	Error	= r.Error;
	Count	= r.Count;
}

a_Moses_EH_Count::~a_Moses_EH_Count() {}

void a_Moses_EH_Count::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(Count, b, d);
}

void a_Moses_EH_Count::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
	s << "Count " << Count  << endl;
}

Implement_Class(a_Moses_EH_Count);

GenericMsg * a_Moses_EH_Count::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_EH_Count (const char *MailBoxName,
					   const char *Folder, 
					   INT16 &outCount)
{
	c_Moses_EH_Count m;
	
	m.MailBoxName  = MailBoxName;
	m.Folder       = Folder;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_EH_Count::IdMsg)
	{
		a_Moses_EH_Count *answ = (a_Moses_EH_Count *)pMsg;

		if (answ->Error.Len() == 0)
		{
			outCount  = answ->Count;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

