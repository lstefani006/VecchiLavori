#include <st_dbnew.h>
#include <moses.h>
#include <tcp_net.h>

extern TcpClient *G_pTcpClient;

STRING Moses_Connection_Close()
{
	STDelete G_pTcpClient;
	G_pTcpClient = NULL;

	return "";
}
