#include <st_dbnew.h>
#ifndef __Moses_FM_PutFile_h__
#define __Moses_FM_PutFile_h__

#include "gnricmsg.h"

class c_Moses_FM_PutFile : public GenericMsg
{
public:

	STRING FinalPathNameFile;
	STRING BodyFile;

	c_Moses_FM_PutFile();
	c_Moses_FM_PutFile(const c_Moses_FM_PutFile &r);
	~c_Moses_FM_PutFile();

	Declare_Class(c_Moses_FM_PutFile);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_FM_PutFile : public GenericMsg
{
public:

	STRING Error;
	
	a_Moses_FM_PutFile(const char *pErr);
	a_Moses_FM_PutFile();

	a_Moses_FM_PutFile(const a_Moses_FM_PutFile &r);

	~a_Moses_FM_PutFile();

	Declare_Class(a_Moses_FM_PutFile);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
