#include <st_dbnew.h>
#include "m_Moses_ART_Modify.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "ART.h"
#endif

c_Moses_ART_Modify::c_Moses_ART_Modify()
{
}

c_Moses_ART_Modify::c_Moses_ART_Modify(const c_Moses_ART_Modify &r)
{
	User           = r.User;
	bInternal      = r.bInternal;
	MailBoxType    = r.MailBoxType;
	MailBoxAddress = r.MailBoxAddress;
	Subject        = r.Subject;
}

c_Moses_ART_Modify::~c_Moses_ART_Modify() {}


void c_Moses_ART_Modify::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(User, b, d);
	pSer->Serialize(MailBoxType,  b, d);
	pSer->Serialize(bInternal, b, d);
	pSer->Serialize(MailBoxAddress, b, d);
	pSer->Serialize(Subject, b, d);
}

void c_Moses_ART_Modify::Print(ostream &s) const
{
	BASE::Print(s);
	s << "User          " << User           << endl;
	s << "MailBoxType   " << MailBoxType    << endl;
	s << "bInternal     " << bInternal      << endl;
	s << "MailBoxAddress" << MailBoxAddress << endl;
	s << "Subject       " << Subject        << endl;
}

Implement_Class(c_Moses_ART_Modify);


GenericMsg * c_Moses_ART_Modify::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return ART_Modify(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_ART_Modify::a_Moses_ART_Modify(const char *pErr) { Error = pErr; }
a_Moses_ART_Modify::a_Moses_ART_Modify() {}

a_Moses_ART_Modify::a_Moses_ART_Modify(const a_Moses_ART_Modify &r)
{
	Error	= r.Error;
}

a_Moses_ART_Modify::~a_Moses_ART_Modify() {}

void a_Moses_ART_Modify::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_ART_Modify::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_ART_Modify);



GenericMsg * a_Moses_ART_Modify::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_ART_Modify(const char *User, int bInternal, const char *MailBoxType, 
		             const char *MailBoxAddress, const char *Subject)
{
	c_Moses_ART_Modify m;

	m.User 		     = User;
	m.bInternal 	 = bInternal;
	m.MailBoxType 	 = MailBoxType;
	m.MailBoxAddress = MailBoxAddress;
	m.Subject     	 = Subject;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_ART_Modify::IdMsg)
	{
		a_Moses_ART_Modify *answ = (a_Moses_ART_Modify *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


