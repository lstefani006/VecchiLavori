#include <st_dbnew.h>
#ifndef __Moses_MS_Delete_h__
#define __Moses_MS_Delete_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_MS_Delete : public GenericMsg
{
public:
	STRING MSType;

	c_Moses_MS_Delete();
	c_Moses_MS_Delete(const c_Moses_MS_Delete &r);
	~c_Moses_MS_Delete();
	Declare_Class(c_Moses_MS_Delete);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MS_Delete : public GenericMsg
{
public:
	STRING Error;

	a_Moses_MS_Delete(const char *pErr);
	a_Moses_MS_Delete();
	a_Moses_MS_Delete(const a_Moses_MS_Delete &r);
	~a_Moses_MS_Delete();
	Declare_Class(a_Moses_MS_Delete);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
