#include <st_dbnew.h>
#ifndef __Moses_Event_NewMsgInFolder_h__
#define __Moses_Event_NewMsgInFolder_h__

#include "gnricmsg.h"

class c_Moses_Event_NewMsgInFolder : public GenericMsg
{
public:

	STRING MailboxName;
	STRING Pwd;
	STRING Folder;

	c_Moses_Event_NewMsgInFolder();
	c_Moses_Event_NewMsgInFolder(const c_Moses_Event_NewMsgInFolder &r);
	~c_Moses_Event_NewMsgInFolder();

	Declare_Class(c_Moses_Event_NewMsgInFolder);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_Event_NewMsgInFolder : public GenericMsg
{
public:

	STRING Error;
	INT32  EventId;

	a_Moses_Event_NewMsgInFolder(const char *pErr);
	a_Moses_Event_NewMsgInFolder();

	a_Moses_Event_NewMsgInFolder(const a_Moses_Event_NewMsgInFolder &r);

	~a_Moses_Event_NewMsgInFolder();

	Declare_Class(a_Moses_Event_NewMsgInFolder);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
