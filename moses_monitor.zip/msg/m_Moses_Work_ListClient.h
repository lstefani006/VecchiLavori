#include <st_dbnew.h>
#ifndef __Moses_Work_ListClient_h__
#define __Moses_Work_ListClient_h__

#include "gnricmsg.h"


class c_Moses_Work_ListClient : public GenericMsg
{
public:
	c_Moses_Work_ListClient();
	c_Moses_Work_ListClient(const c_Moses_Work_ListClient &r);
	~c_Moses_Work_ListClient();
	Declare_Class(c_Moses_Work_ListClient);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_Work_ListClient : public GenericMsg
{
public:
	STRING Error;

	VECT<STRING> ListClient;
	VECT<STRING> ListTypeClient;
	VECT<STRING> ListTcpAddr;

	a_Moses_Work_ListClient(const char *pErr);
	a_Moses_Work_ListClient();
	a_Moses_Work_ListClient(const a_Moses_Work_ListClient &r);
	~a_Moses_Work_ListClient();
	Declare_Class(a_Moses_Work_ListClient);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
