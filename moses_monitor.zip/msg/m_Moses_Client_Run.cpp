#include <st_dbnew.h>
#include "m_Moses_Client_Run.h"
#include "m_Error.h"


#ifdef MOSES_SERVER
	#include "Client.h"
#endif

c_Moses_Client_Run::c_Moses_Client_Run()
{
}

c_Moses_Client_Run::c_Moses_Client_Run(const c_Moses_Client_Run &r)
{
	ClientName	= r.ClientName;
}

c_Moses_Client_Run::~c_Moses_Client_Run() {}


void c_Moses_Client_Run::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(ClientName, b, d);
}

void c_Moses_Client_Run::Print(ostream &s) const
{
	BASE::Print(s);
	s << "ClientName   " << ClientName    << endl;
}

Implement_Class(c_Moses_Client_Run);


GenericMsg * c_Moses_Client_Run::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Client_Run(this, nClient);
#else
	return NULL;
#endif
}


///////////////////////////////////////////////////////////////////////////////


a_Moses_Client_Run::a_Moses_Client_Run(const char *pErr) { Error = pErr; }
a_Moses_Client_Run::a_Moses_Client_Run() {}

a_Moses_Client_Run::a_Moses_Client_Run(const a_Moses_Client_Run &r)
{
	Error	= r.Error;
}

a_Moses_Client_Run::~a_Moses_Client_Run() {}

void a_Moses_Client_Run::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Client_Run::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_Client_Run);



GenericMsg * a_Moses_Client_Run::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Client_Run(const char *ClientName)
{
	c_Moses_Client_Run m;

	m.ClientName 	= ClientName;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Client_Run::IdMsg)
	{
		a_Moses_Client_Run *answ = (a_Moses_Client_Run *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


