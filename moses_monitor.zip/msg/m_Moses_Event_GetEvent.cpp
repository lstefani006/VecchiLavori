#include <st_dbnew.h>
#include "m_Moses_Event_GetEvent.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Event.h"
#endif

c_Moses_Event_GetEvent::c_Moses_Event_GetEvent()
{
}

c_Moses_Event_GetEvent::c_Moses_Event_GetEvent(const c_Moses_Event_GetEvent &r)
{
	mSec	= r.mSec;
}

c_Moses_Event_GetEvent::~c_Moses_Event_GetEvent() {}


void c_Moses_Event_GetEvent::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(mSec, b, d);
}

void c_Moses_Event_GetEvent::Print(ostream &s) const
{
	BASE::Print(s);
	s << "mSec " << mSec << endl;
}

Implement_Class(c_Moses_Event_GetEvent);



GenericMsg * c_Moses_Event_GetEvent::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Event_GetEvent(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Event_GetEvent::a_Moses_Event_GetEvent(const char *pErr) { Error = pErr; }
a_Moses_Event_GetEvent::a_Moses_Event_GetEvent() {}

a_Moses_Event_GetEvent::a_Moses_Event_GetEvent(const a_Moses_Event_GetEvent &r)
{
	Error	= r.Error;
	EventId = r.EventId;
}

a_Moses_Event_GetEvent::~a_Moses_Event_GetEvent() {}

void a_Moses_Event_GetEvent::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b,       pSer, d);
	pSer->Serialize(Error,   b,    d);
	pSer->Serialize(EventId,   b,    d);
}

void a_Moses_Event_GetEvent::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error     " << Error    << endl;
	s << "EventId   " << EventId  << endl;
}

Implement_Class(a_Moses_Event_GetEvent);

GenericMsg * a_Moses_Event_GetEvent::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_Event_GetEvent( int mSec, INT32 &out_EventId )
{
	c_Moses_Event_GetEvent m;

	m.mSec = mSec;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Event_GetEvent::IdMsg)
	{
		a_Moses_Event_GetEvent *answ = (a_Moses_Event_GetEvent *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_EventId = answ->EventId; 
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


