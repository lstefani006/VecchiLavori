#include <st_dbnew.h>
#include "m_Moses_ART_OutAddress.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "ART.h"
#endif

c_Moses_ART_OutAddress::c_Moses_ART_OutAddress()
{
}

c_Moses_ART_OutAddress::c_Moses_ART_OutAddress(const c_Moses_ART_OutAddress &r)
{
	User           = r.User;
	MailBoxType    = r.MailBoxType;
}

c_Moses_ART_OutAddress::~c_Moses_ART_OutAddress() {}


void c_Moses_ART_OutAddress::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(User, b, d);
	pSer->Serialize(MailBoxType,  b, d);
}

void c_Moses_ART_OutAddress::Print(ostream &s) const
{
	BASE::Print(s);
	s << "User          " << User           << endl;
	s << "MailBoxType   " << MailBoxType    << endl;
}

Implement_Class(c_Moses_ART_OutAddress);


GenericMsg * c_Moses_ART_OutAddress::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return ART_OutAddress(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_ART_OutAddress::a_Moses_ART_OutAddress(const char *pErr) { Error = pErr; }
a_Moses_ART_OutAddress::a_Moses_ART_OutAddress() {}

a_Moses_ART_OutAddress::a_Moses_ART_OutAddress(const a_Moses_ART_OutAddress &r)
{
	Error	       = r.Error;

	MailBoxType    = r.MailBoxType;
	MailBoxAddress = r.MailBoxAddress;
	Subject        = r.Subject;
}

a_Moses_ART_OutAddress::~a_Moses_ART_OutAddress() {}

void a_Moses_ART_OutAddress::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(MailBoxType,  b, d);
	pSer->Serialize(MailBoxAddress, b, d);
	pSer->Serialize(Subject, b, d);
}

void a_Moses_ART_OutAddress::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error         " << Error          << endl;
	s << "MailBoxType   " << MailBoxType    << endl;
	s << "MailBoxAddress" << MailBoxAddress << endl;
	s << "Subject       " << Subject        << endl;
}

Implement_Class(a_Moses_ART_OutAddress);



GenericMsg * a_Moses_ART_OutAddress::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_ART_OutAddress (const char *User,const char *MailBoxType, 
							 STRING &out_MailBoxType, 
							 STRING &out_MailBoxAddress, 
							 STRING &out_Subject)
{
	c_Moses_ART_OutAddress m;

	m.User 		     = User;
	m.MailBoxType 	 = MailBoxType;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_ART_OutAddress::IdMsg)
	{
		a_Moses_ART_OutAddress *answ = (a_Moses_ART_OutAddress *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_MailBoxType    = answ->MailBoxType; 	 
			out_MailBoxAddress = answ->MailBoxAddress;  
			out_Subject        = answ->Subject;     	 
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


