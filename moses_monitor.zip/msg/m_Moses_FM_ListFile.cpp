#include <st_dbnew.h>
#include "m_Moses_FM_ListFile.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "FM.h"
#endif


c_Moses_FM_ListFile::c_Moses_FM_ListFile()
{
}

c_Moses_FM_ListFile::c_Moses_FM_ListFile(const c_Moses_FM_ListFile &r)
{
	PathDir     = r.PathDir;
}

c_Moses_FM_ListFile::~c_Moses_FM_ListFile() {}


void c_Moses_FM_ListFile::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(PathDir, b, d);
}

void c_Moses_FM_ListFile::Print(ostream &s) const
{
	BASE::Print(s);
	s << "PathDir   " << PathDir    << endl;
}

Implement_Class(c_Moses_FM_ListFile);



GenericMsg * c_Moses_FM_ListFile::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER 
	return FM_ListFile(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_FM_ListFile::a_Moses_FM_ListFile(const char *pErr) { Error = pErr; }
a_Moses_FM_ListFile::a_Moses_FM_ListFile() {}

a_Moses_FM_ListFile::a_Moses_FM_ListFile(const a_Moses_FM_ListFile &r)
{
	Error		    = r.Error;
	NameFileList	= r.NameFileList;
	TypeFileList	= r.TypeFileList;
	DateFileList	= r.DateFileList;
	DimFileList	    = r.DimFileList;
}

a_Moses_FM_ListFile::~a_Moses_FM_ListFile() {}

void a_Moses_FM_ListFile::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(NameFileList, b, d);
	pSer->Serialize(TypeFileList, b, d);
	pSer->Serialize(DateFileList, b, d);
	pSer->Serialize(DimFileList, b, d);
}

void a_Moses_FM_ListFile::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error        " << Error         << endl;
	s << "NameFileList " << NameFileList  << endl;
	s << "TypeFileList " << TypeFileList  << endl;
	s << "DateFileList " << DateFileList  << endl;
	s << "DimFileList  " << DimFileList   << endl;
}

Implement_Class(a_Moses_FM_ListFile);

GenericMsg * a_Moses_FM_ListFile::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_FM_ListFile(const char    *PathDir, 
					     VECT<STRING>  &out_NameFile,
					     VECT<STRING>  &out_TypeFile,
						 VECT<STRING>  &out_DateFile,
						 VECT<INT32>   &out_DimFile)
{
	c_Moses_FM_ListFile m;

	m.PathDir 	= PathDir;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_FM_ListFile::IdMsg)
	{
		a_Moses_FM_ListFile *answ = (a_Moses_FM_ListFile *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_NameFile = answ->NameFileList;
				out_TypeFile = answ->TypeFileList;
				out_DateFile = answ->DateFileList;
				out_DimFile  = answ->DimFileList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

