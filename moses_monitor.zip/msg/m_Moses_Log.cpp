#include <st_dbnew.h>
#include "m_Moses_Log.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Log.h"
#endif

c_Moses_Log::c_Moses_Log()
{
}

c_Moses_Log::c_Moses_Log(const c_Moses_Log &r)
{
	ClientId	= r.ClientId;
	LogMsg  	= r.LogMsg;
}

c_Moses_Log::~c_Moses_Log() {}


void c_Moses_Log::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(ClientId, b, d);
	pSer->Serialize(LogMsg,b, d);
}

void c_Moses_Log::Print(ostream &s) const
{
	BASE::Print(s);
	s << "ClientId " << ClientId  << endl;
	s << "LogMsg   " << LogMsg    << endl;
}

Implement_Class(c_Moses_Log);


GenericMsg * c_Moses_Log::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Log(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Log::a_Moses_Log(const char *pErr) { Error = pErr; }
a_Moses_Log::a_Moses_Log() {}

a_Moses_Log::a_Moses_Log(const a_Moses_Log &r)
{
	Error	= r.Error;
}

a_Moses_Log::~a_Moses_Log() {}

void a_Moses_Log::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Log::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_Log);



GenericMsg * a_Moses_Log::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Log(int ClientId, const char *LogMsg)
{
	c_Moses_Log m;

	m.ClientId	= ClientId;
	m.LogMsg   	= LogMsg;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Log::IdMsg)
	{
		a_Moses_Log *answ = (a_Moses_Log *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


