#include <st_dbnew.h>
#include "m_Moses_Work_Begin.h"
#include "m_Error.h"


#ifdef MOSES_SERVER
	#include "Work.h"
#endif

c_Moses_Work_Begin::c_Moses_Work_Begin()
{
}

c_Moses_Work_Begin::c_Moses_Work_Begin(const c_Moses_Work_Begin &r)
{
	Login      = r.Login;
	Pwd        = r.Pwd;
	ClientType = r.ClientType;
}

c_Moses_Work_Begin::~c_Moses_Work_Begin() {}


void c_Moses_Work_Begin::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Login,      b, d);
	pSer->Serialize(Pwd,        b, d);
	pSer->Serialize(ClientType, b, d);
}

void c_Moses_Work_Begin::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tLogin      " << Login      << endl;
	s << "\tPwd        " << Pwd        << endl;
	s << "\tClientType " << ClientType << endl;
}

Implement_Class(c_Moses_Work_Begin);


GenericMsg * c_Moses_Work_Begin::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Work_Begin(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Work_Begin::a_Moses_Work_Begin(const char *pErr) { Error = pErr; }
a_Moses_Work_Begin::a_Moses_Work_Begin() {}

a_Moses_Work_Begin::a_Moses_Work_Begin(const a_Moses_Work_Begin &r)
{
	Error      = r.Error;
	Pid        = r.Pid;
}

a_Moses_Work_Begin::~a_Moses_Work_Begin() {}

void a_Moses_Work_Begin::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error,      b, d);
	pSer->Serialize(Pid,        b, d);
}

void a_Moses_Work_Begin::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError     " << Error      << endl;
	s << "\tPid       " << Pid        << endl;
}

Implement_Class(a_Moses_Work_Begin);


GenericMsg * a_Moses_Work_Begin::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Work_Begin(const char *Login, const char *Pwd, const char *ClientType, INT32 &out_Pid)
{
	c_Moses_Work_Begin m;

	m.Login = Login;
	m.Pwd   = Pwd;
	m.ClientType = ClientType;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Work_Begin::IdMsg)
	{
		a_Moses_Work_Begin *answ = (a_Moses_Work_Begin *)pMsg;

		if (answ->Error.Len() == 0)
			out_Pid = answ->Pid;

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

