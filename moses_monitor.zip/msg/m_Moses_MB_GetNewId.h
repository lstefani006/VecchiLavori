#include <st_dbnew.h>
#ifndef __Moses_MB_GetNewId_h__
#define __Moses_MB_GetNewId_h__

#include "gnricmsg.h"

class c_Moses_MB_GetNewId : public GenericMsg
{
public:

	c_Moses_MB_GetNewId();
	c_Moses_MB_GetNewId(const c_Moses_MB_GetNewId &r);
	~c_Moses_MB_GetNewId();

	Declare_Class(c_Moses_MB_GetNewId);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_GetNewId : public GenericMsg
{
public:

	STRING Error;
	
	INT32  MsgId;

	a_Moses_MB_GetNewId(const char *pErr);
	a_Moses_MB_GetNewId();

	a_Moses_MB_GetNewId(const a_Moses_MB_GetNewId &r);

	~a_Moses_MB_GetNewId();

	Declare_Class(a_Moses_MB_GetNewId);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
