#include <st_dbnew.h>
#ifndef __Moses_MB_MsgFile_h__
#define __Moses_MB_MsgFile_h__

#include "gnricmsg.h"

class c_Moses_MB_MsgFile : public GenericMsg
{
public:

	INT32  MsgId;

	c_Moses_MB_MsgFile();
	c_Moses_MB_MsgFile(const c_Moses_MB_MsgFile &r);
	~c_Moses_MB_MsgFile();

	Declare_Class(c_Moses_MB_MsgFile);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_MsgFile : public GenericMsg
{
public:

	STRING Error;
	
	STRING MsgFile;

	a_Moses_MB_MsgFile(const char *pErr);
	a_Moses_MB_MsgFile();

	a_Moses_MB_MsgFile(const a_Moses_MB_MsgFile &r);

	~a_Moses_MB_MsgFile();

	Declare_Class(a_Moses_MB_MsgFile);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
