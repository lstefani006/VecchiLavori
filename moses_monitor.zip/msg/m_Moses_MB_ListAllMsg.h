#include <st_dbnew.h>
#ifndef __Moses_MB_ListAllMsg_h__
#define __Moses_MB_ListAllMsg_h__

#include "gnricmsg.h"

class c_Moses_MB_ListAllMsg : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Folder;
	STRING Cond_UserField;
	STRING Cond_Accessed;
	STRING Cond_Sender;
	STRING Cond_Receiver;

	c_Moses_MB_ListAllMsg();
	c_Moses_MB_ListAllMsg(const c_Moses_MB_ListAllMsg &r);
	~c_Moses_MB_ListAllMsg();

	Declare_Class(c_Moses_MB_ListAllMsg);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_ListAllMsg : public GenericMsg
{
public:

	STRING Error;
	
	VECT<INT32> MsgIdList; 
	VECT<INT16> DeleteList; 

	a_Moses_MB_ListAllMsg(const char *pErr);
	a_Moses_MB_ListAllMsg();

	a_Moses_MB_ListAllMsg(const a_Moses_MB_ListAllMsg &r);

	~a_Moses_MB_ListAllMsg();

	Declare_Class(a_Moses_MB_ListAllMsg);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
