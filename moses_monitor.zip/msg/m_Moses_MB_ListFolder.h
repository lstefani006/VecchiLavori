#include <st_dbnew.h>
#ifndef __Moses_MB_ListFolder_h__
#define __Moses_MB_ListFolder_h__

#include "gnricmsg.h"

class c_Moses_MB_ListFolder : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Pwd;
	STRING Folder;

	c_Moses_MB_ListFolder();
	c_Moses_MB_ListFolder(const c_Moses_MB_ListFolder &r);
	~c_Moses_MB_ListFolder();

	Declare_Class(c_Moses_MB_ListFolder);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_ListFolder : public GenericMsg
{
public:

	STRING Error;
	
	VECT<STRING> FolderList; 
	VECT<INT16>  DeletedList; 

	a_Moses_MB_ListFolder(const char *pErr);
	a_Moses_MB_ListFolder();

	a_Moses_MB_ListFolder(const a_Moses_MB_ListFolder &r);

	~a_Moses_MB_ListFolder();

	Declare_Class(a_Moses_MB_ListFolder);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
