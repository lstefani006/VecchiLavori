#include <st_dbnew.h>
#ifndef __Moses_Client_List_h__
#define __Moses_Client_List_h__

#include "gnricmsg.h"


class c_Moses_Client_List : public GenericMsg
{
public:
	c_Moses_Client_List();
	c_Moses_Client_List(const c_Moses_Client_List &r);
	~c_Moses_Client_List();
	Declare_Class(c_Moses_Client_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Client_List : public GenericMsg
{
public:
	STRING Error;

	VECT<STRING> ClientNameList;
	VECT<STRING> ClientDescrList;
	VECT<STRING> ClientTypeList;
	VECT<INT16>  ActiveList;

	a_Moses_Client_List(const char *pErr);
	a_Moses_Client_List();
	a_Moses_Client_List(const a_Moses_Client_List &r);
	~a_Moses_Client_List();
	Declare_Class(a_Moses_Client_List);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
