#include <st_dbnew.h>
#include "m_Moses_MSL_Add.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MSL.h"
#endif

c_Moses_MSL_Add::c_Moses_MSL_Add()
{
}

c_Moses_MSL_Add::c_Moses_MSL_Add(const c_Moses_MSL_Add &r)
{
	MSLName      = r.MSLName;
	MSLDescr     = r.MSLDescr;
}

c_Moses_MSL_Add::~c_Moses_MSL_Add() {}


void c_Moses_MSL_Add::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MSLName, b, d);
	pSer->Serialize(MSLDescr,b, d);
}

void c_Moses_MSL_Add::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MSLName     " << MSLName      << endl;
	s << "MSLDescr    " << MSLDescr     << endl;
}

Implement_Class(c_Moses_MSL_Add);


GenericMsg * c_Moses_MSL_Add::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MSL_Add(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MSL_Add::a_Moses_MSL_Add(const char *pErr) { Error = pErr; }
a_Moses_MSL_Add::a_Moses_MSL_Add() {}

a_Moses_MSL_Add::a_Moses_MSL_Add(const a_Moses_MSL_Add &r)
{
	Error	= r.Error;
}

a_Moses_MSL_Add::~a_Moses_MSL_Add() {}

void a_Moses_MSL_Add::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MSL_Add::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_MSL_Add);



GenericMsg * a_Moses_MSL_Add::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_MSL_Add(const char *MSLName, const char *Descr)
{
	c_Moses_MSL_Add m;

	m.MSLName 		= MSLName;
	m.MSLDescr   	= Descr;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MSL_Add::IdMsg)
	{
		a_Moses_MSL_Add *answ = (a_Moses_MSL_Add *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}


