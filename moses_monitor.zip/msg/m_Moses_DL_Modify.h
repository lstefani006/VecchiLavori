#include <st_dbnew.h>
#ifndef __Moses_DL_Modify_h__
#define __Moses_DL_Modify_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_DL_Modify : public GenericMsg
{
public:
	STRING DLName;
	STRING DLPwd;
	STRING DLDescr;

	c_Moses_DL_Modify();
	c_Moses_DL_Modify(const c_Moses_DL_Modify &r);
	~c_Moses_DL_Modify();
	Declare_Class(c_Moses_DL_Modify);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_DL_Modify : public GenericMsg
{
public:
	STRING Error;

	a_Moses_DL_Modify(const char *pErr);
	a_Moses_DL_Modify();
	a_Moses_DL_Modify(const a_Moses_DL_Modify &r);
	~a_Moses_DL_Modify();
	Declare_Class(a_Moses_DL_Modify);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
