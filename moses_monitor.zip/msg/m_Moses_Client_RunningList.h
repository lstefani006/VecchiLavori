#include <st_dbnew.h>
#ifndef __Moses_Client_RunningList_h__
#define __Moses_Client_RunningList_h__

#include "gnricmsg.h"


class c_Moses_Client_RunningList : public GenericMsg
{
public:
	c_Moses_Client_RunningList();
	c_Moses_Client_RunningList(const c_Moses_Client_RunningList &r);
	~c_Moses_Client_RunningList();
	Declare_Class(c_Moses_Client_RunningList);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Client_RunningList : public GenericMsg
{
public:
	STRING Error;

	VECT<STRING> ClientNameList;

	a_Moses_Client_RunningList(const char *pErr);
	a_Moses_Client_RunningList();
	a_Moses_Client_RunningList(const a_Moses_Client_RunningList &r);
	~a_Moses_Client_RunningList();
	Declare_Class(a_Moses_Client_RunningList);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
