#include <st_dbnew.h>
#include "m_Moses_Work_End.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Work.h"
#endif


c_Moses_Work_End::c_Moses_Work_End()
{
}

c_Moses_Work_End::c_Moses_Work_End(const c_Moses_Work_End &r)
{
	Pid      = r.Pid;
	bOk      = r.bOk;
}

c_Moses_Work_End::~c_Moses_Work_End() {}


void c_Moses_Work_End::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Pid,      b, d);
	pSer->Serialize(bOk,      b, d);
}

void c_Moses_Work_End::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tbOk     " << bOk      << endl;
}

Implement_Class(c_Moses_Work_End);


GenericMsg * c_Moses_Work_End::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Work_End(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Work_End::a_Moses_Work_End(const char *pErr) { Error = pErr; }
a_Moses_Work_End::a_Moses_Work_End() {}

a_Moses_Work_End::a_Moses_Work_End(const a_Moses_Work_End &r)
{
	Error      = r.Error;
}

a_Moses_Work_End::~a_Moses_Work_End() {}

void a_Moses_Work_End::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error,      b, d);
}

void a_Moses_Work_End::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError     " << Error      << endl;
}

Implement_Class(a_Moses_Work_End);



GenericMsg * a_Moses_Work_End::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Work_End(int Pid, int bOk)
{
	c_Moses_Work_End m;

	m.Pid = Pid;
	m.bOk = bOk;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Work_End::IdMsg)
	{
		a_Moses_Work_End *answ = (a_Moses_Work_End *)pMsg;

		if (answ->Error.Len() == 0)
		{
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

