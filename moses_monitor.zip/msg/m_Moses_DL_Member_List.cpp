#include <st_dbnew.h>
#include "m_Moses_DL_Member_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "DL.h"
#endif

c_Moses_DL_Member_List::c_Moses_DL_Member_List()
{
}

c_Moses_DL_Member_List::c_Moses_DL_Member_List(const c_Moses_DL_Member_List &r)
{
	DLName = r.DLName;
	Pwd    = r.Pwd;
}

c_Moses_DL_Member_List::~c_Moses_DL_Member_List() {}


void c_Moses_DL_Member_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(DLName, b, d);
	pSer->Serialize(Pwd, b, d);
}

void c_Moses_DL_Member_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "DLName  " << DLName   << endl;
	s << "Pwd     " << Pwd      << endl;
}

Implement_Class(c_Moses_DL_Member_List);



GenericMsg * c_Moses_DL_Member_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return DL_Member_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_DL_Member_List::a_Moses_DL_Member_List(const char *pErr) { Error = pErr; }
a_Moses_DL_Member_List::a_Moses_DL_Member_List()
{
}

a_Moses_DL_Member_List::a_Moses_DL_Member_List(const a_Moses_DL_Member_List &r)
{
	Error	  = r.Error;
	UserList  = r.UserList;
}

a_Moses_DL_Member_List::~a_Moses_DL_Member_List()
{
}

void a_Moses_DL_Member_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(UserList, b, d);
}

void a_Moses_DL_Member_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error      " << Error       << endl;
	s << "UserList   " << UserList    << endl;
}

Implement_Class(a_Moses_DL_Member_List);

GenericMsg * a_Moses_DL_Member_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_DL_Member_List(const char *DLName, const char *Pwd, VECT<STRING> &out_UserList)
{
	c_Moses_DL_Member_List m;

	m.DLName 		= DLName;
	m.Pwd           = Pwd;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_DL_Member_List::IdMsg)
	{
		a_Moses_DL_Member_List *answ = (a_Moses_DL_Member_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_UserList  = answ->UserList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

