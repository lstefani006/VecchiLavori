#include <st_dbnew.h>
#ifndef __Moses_MB_WriteInFolder_h__
#define __Moses_MB_WriteInFolder_h__

#include "gnricmsg.h"

class c_Moses_MB_WriteInFolder : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Pwd;
	STRING Folder;
	INT32  MsgId;
	STRING Sender;
	STRING Destination;
	STRING Subject;
	INT16  bIncoming;
	STRING Body;

	c_Moses_MB_WriteInFolder();
	c_Moses_MB_WriteInFolder(const c_Moses_MB_WriteInFolder &r);
	~c_Moses_MB_WriteInFolder();

	Declare_Class(c_Moses_MB_WriteInFolder);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_WriteInFolder : public GenericMsg
{
public:

	STRING Error;
	
	a_Moses_MB_WriteInFolder(const char *pErr);
	a_Moses_MB_WriteInFolder();

	a_Moses_MB_WriteInFolder(const a_Moses_MB_WriteInFolder &r);

	~a_Moses_MB_WriteInFolder();

	Declare_Class(a_Moses_MB_WriteInFolder);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
