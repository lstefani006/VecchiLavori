#include <st_dbnew.h>
#ifndef __Moses_Client_Kill_h__
#define __Moses_Client_Kill_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_Client_Kill : public GenericMsg
{
public:
	STRING 	ClientName;
	INT32	ClientPid;

	c_Moses_Client_Kill();
	c_Moses_Client_Kill(const c_Moses_Client_Kill &r);
	~c_Moses_Client_Kill();
	Declare_Class(c_Moses_Client_Kill);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Client_Kill : public GenericMsg
{
public:
	STRING Error;

	a_Moses_Client_Kill(const char *pErr);
	a_Moses_Client_Kill();
	a_Moses_Client_Kill(const a_Moses_Client_Kill &r);
	~a_Moses_Client_Kill();
	Declare_Class(a_Moses_Client_Kill);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
