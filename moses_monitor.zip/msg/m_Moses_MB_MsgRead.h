#include <st_dbnew.h>
#ifndef __Moses_MB_MsgRead_h__
#define __Moses_MB_MsgRead_h__

#include "gnricmsg.h"

class c_Moses_MB_MsgRead : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Pwd;
	INT32  MsgId;

	c_Moses_MB_MsgRead();
	c_Moses_MB_MsgRead(const c_Moses_MB_MsgRead &r);
	~c_Moses_MB_MsgRead();

	Declare_Class(c_Moses_MB_MsgRead);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_MsgRead : public GenericMsg
{
public:

	STRING Error;
	
	STRING Body;

	a_Moses_MB_MsgRead(const char *pErr);
	a_Moses_MB_MsgRead();

	a_Moses_MB_MsgRead(const a_Moses_MB_MsgRead &r);

	~a_Moses_MB_MsgRead();

	Declare_Class(a_Moses_MB_MsgRead);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
