#include <st_dbnew.h>
#include "m_Moses_Work_ListClient.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Work.h"
#endif


c_Moses_Work_ListClient::c_Moses_Work_ListClient()
{
}

c_Moses_Work_ListClient::c_Moses_Work_ListClient(const c_Moses_Work_ListClient &r)
{
}

c_Moses_Work_ListClient::~c_Moses_Work_ListClient() {}


void c_Moses_Work_ListClient::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_Work_ListClient::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_Work_ListClient);

GenericMsg * c_Moses_Work_ListClient::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Work_ListClient(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Work_ListClient::a_Moses_Work_ListClient(const char *pErr) { Error = pErr; }
a_Moses_Work_ListClient::a_Moses_Work_ListClient()
{
}

a_Moses_Work_ListClient::a_Moses_Work_ListClient(const a_Moses_Work_ListClient &r)
{
	Error	        = r.Error;
	ListClient      = r.ListClient;
	ListTypeClient  = r.ListTypeClient;
	ListTcpAddr     = r.ListTcpAddr;
}

a_Moses_Work_ListClient::~a_Moses_Work_ListClient()
{
}

void a_Moses_Work_ListClient::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(ListClient, b, d);
	pSer->Serialize(ListTypeClient, b, d);
	pSer->Serialize(ListTcpAddr, b, d);
}

void a_Moses_Work_ListClient::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError          " << Error           << endl;
	s << "\tListClient     " << ListClient      << endl;
	s << "\tListTypeClient " << ListTypeClient  << endl;
	s << "\tListTcpAddr    " << ListTcpAddr     << endl;
}

Implement_Class(a_Moses_Work_ListClient);

GenericMsg * a_Moses_Work_ListClient::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Work_ListClient(
		VECT<STRING> &out_ListClient,
		VECT<STRING> &out_ListTypeClient,
		VECT<STRING> &out_ListTcpAddr)
{
	c_Moses_Work_ListClient m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Work_ListClient::IdMsg)
	{
		a_Moses_Work_ListClient *answ = (a_Moses_Work_ListClient *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_ListClient     = answ->ListClient;
			out_ListTypeClient = answ->ListTypeClient;
			out_ListTcpAddr    = answ->ListTcpAddr;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

