#include <st_dbnew.h>
#include "m_Moses_EH_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
    #include "EH.h"
	#include "server.h"
#endif


c_Moses_EH_List::c_Moses_EH_List()
{
}

c_Moses_EH_List::c_Moses_EH_List(const c_Moses_EH_List &r)
{
	MailBoxName  = r.MailBoxName;
	Folder       = r.Folder;
	Index        = r.Index;
}

c_Moses_EH_List::~c_Moses_EH_List() {}


void c_Moses_EH_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Folder, b, d);
	pSer->Serialize(Index, b, d);
}

void c_Moses_EH_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "MailBoxName " << MailBoxName << endl;
	s << "Folder      " << Folder      << endl;
	s << "Index       " << Index       << endl;
}

Implement_Class(c_Moses_EH_List);


GenericMsg * c_Moses_EH_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return EH_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_EH_List::a_Moses_EH_List(const char *pErr) { Error = pErr; }
a_Moses_EH_List::a_Moses_EH_List() {}

a_Moses_EH_List::a_Moses_EH_List(const a_Moses_EH_List &r)
{
	Error	     = r.Error;
	
	Source       = r.Source;
	Destination  = r.Destination;
	Subject      = r.Subject;
	Action       = r.Action;
	Valid        = r.Valid;
}

a_Moses_EH_List::~a_Moses_EH_List() {}

void a_Moses_EH_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	
	pSer->Serialize(Source, b, d);
	pSer->Serialize(Destination, b, d);
	pSer->Serialize(Subject, b, d);
	pSer->Serialize(Action, b, d);
	pSer->Serialize(Valid, b, d);
}

void a_Moses_EH_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error       " << Error       << endl;
	s << "Source      " << Source      << endl;
	s << "Destination " << Destination << endl;
	s << "Subject     " << Subject     << endl;
	s << "Action      " << Action      << endl;
	s << "Valid       " << Valid       << endl;
}

Implement_Class(a_Moses_EH_List);

GenericMsg * a_Moses_EH_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_EH_List(int         Index,
		             const char *MailBoxName,
					 const char *Folder, 
					 STRING     &Source, 
					 STRING     &Destination, 
					 STRING     &Subject, 
					 STRING     &Action, 
					 INT16      &out_Valid)
					 
{
	c_Moses_EH_List m;
	
	m.MailBoxName  = MailBoxName;
	m.Folder       = Folder;
	m.Index        = Index;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_EH_List::IdMsg)
	{
		a_Moses_EH_List *answ = (a_Moses_EH_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			Source       = answ->Source;
			Destination  = answ->Destination;
			Subject      = answ->Subject;
			Action       = answ->Action;
			out_Valid    = answ->Valid;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

