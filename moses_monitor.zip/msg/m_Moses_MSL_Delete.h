#include <st_dbnew.h>
#ifndef __Moses_MSL_Delete_h__
#define __Moses_MSL_Delete_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_MSL_Delete : public GenericMsg
{
public:
	STRING MSLName;

	c_Moses_MSL_Delete();
	c_Moses_MSL_Delete(const c_Moses_MSL_Delete &r);
	~c_Moses_MSL_Delete();
	Declare_Class(c_Moses_MSL_Delete);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MSL_Delete : public GenericMsg
{
public:
	STRING Error;

	a_Moses_MSL_Delete(const char *pErr);
	a_Moses_MSL_Delete();
	a_Moses_MSL_Delete(const a_Moses_MSL_Delete &r);
	~a_Moses_MSL_Delete();
	Declare_Class(a_Moses_MSL_Delete);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
