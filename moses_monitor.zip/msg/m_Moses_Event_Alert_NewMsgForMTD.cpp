#include <st_dbnew.h>
#include "m_Moses_Event_Alert_NewMsgForMTD.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Event.h"
#endif

c_Moses_Event_Alert_NewMsgForMTD::c_Moses_Event_Alert_NewMsgForMTD()
{
}

c_Moses_Event_Alert_NewMsgForMTD::c_Moses_Event_Alert_NewMsgForMTD(const c_Moses_Event_Alert_NewMsgForMTD &r)
{
	EventId         = r.EventId;
}

c_Moses_Event_Alert_NewMsgForMTD::~c_Moses_Event_Alert_NewMsgForMTD() {}


void c_Moses_Event_Alert_NewMsgForMTD::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(EventId, b, d);
}

void c_Moses_Event_Alert_NewMsgForMTD::Print(ostream &s) const
{
	BASE::Print(s);
	s << "EventId " << EventId << endl;
}

Implement_Class(c_Moses_Event_Alert_NewMsgForMTD);



GenericMsg * c_Moses_Event_Alert_NewMsgForMTD::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Event_Alert_NewMsgForMTD(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Event_Alert_NewMsgForMTD::a_Moses_Event_Alert_NewMsgForMTD(const char *pErr) { Error = pErr; }
a_Moses_Event_Alert_NewMsgForMTD::a_Moses_Event_Alert_NewMsgForMTD() {}

a_Moses_Event_Alert_NewMsgForMTD::a_Moses_Event_Alert_NewMsgForMTD(const a_Moses_Event_Alert_NewMsgForMTD &r)
{
	Error	= r.Error;
	MsgId	= r.MsgId;
}

a_Moses_Event_Alert_NewMsgForMTD::~a_Moses_Event_Alert_NewMsgForMTD() {}

void a_Moses_Event_Alert_NewMsgForMTD::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b,      pSer, d);
	pSer->Serialize(Error,  b,    d);
	pSer->Serialize(MsgId, 	b,    d);
}

void a_Moses_Event_Alert_NewMsgForMTD::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error   " << Error    << endl;
	s << "MsgId   " << MsgId    << endl;
}

Implement_Class(a_Moses_Event_Alert_NewMsgForMTD);

GenericMsg * a_Moses_Event_Alert_NewMsgForMTD::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_Event_Alert_NewMsgForMTD(
		int   EventId,
		INT32 &out_MsgId)
{
	c_Moses_Event_Alert_NewMsgForMTD m;

	m.EventId 	= EventId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Event_Alert_NewMsgForMTD::IdMsg)
	{
		a_Moses_Event_Alert_NewMsgForMTD *answ = (a_Moses_Event_Alert_NewMsgForMTD *)pMsg;

		// copio in ogni caso l'evento: in questo modo un MTD puo' lavorare
		// anche se caduto e riconnesso.
		out_MsgId  = answ->MsgId;

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

