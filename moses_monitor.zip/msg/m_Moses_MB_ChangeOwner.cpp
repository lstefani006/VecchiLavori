#include <st_dbnew.h>
#include "m_Moses_MB_ChangeOwner.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_ChangeOwner::c_Moses_MB_ChangeOwner()
{
}

c_Moses_MB_ChangeOwner::c_Moses_MB_ChangeOwner(const c_Moses_MB_ChangeOwner &r)
{
	MailBoxName     = r.MailBoxName;
	Owner    		= r.Owner;
}

c_Moses_MB_ChangeOwner::~c_Moses_MB_ChangeOwner() {}


void c_Moses_MB_ChangeOwner::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Owner, b, d);
}

void c_Moses_MB_ChangeOwner::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName  " << MailBoxName   << endl;
	s << "\tOwner        " << Owner     	   << endl;
}

Implement_Class(c_Moses_MB_ChangeOwner);



GenericMsg * c_Moses_MB_ChangeOwner::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_ChangeOwner(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_ChangeOwner::a_Moses_MB_ChangeOwner(const char *pErr) { Error = pErr; }
a_Moses_MB_ChangeOwner::a_Moses_MB_ChangeOwner() {}

a_Moses_MB_ChangeOwner::a_Moses_MB_ChangeOwner(const a_Moses_MB_ChangeOwner &r)
{
	Error	= r.Error;
}

a_Moses_MB_ChangeOwner::~a_Moses_MB_ChangeOwner() {}

void a_Moses_MB_ChangeOwner::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_ChangeOwner::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError " << Error  << endl;
}

Implement_Class(a_Moses_MB_ChangeOwner);

GenericMsg * a_Moses_MB_ChangeOwner::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_ChangeOwner(const char *MailBoxName, 
						    const char *Owner)
{
	c_Moses_MB_ChangeOwner m;

	m.MailBoxName 	= MailBoxName;
	m.Owner   	    = Owner;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_ChangeOwner::IdMsg)
	{
		a_Moses_MB_ChangeOwner *answ = (a_Moses_MB_ChangeOwner *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

