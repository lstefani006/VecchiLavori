#include <st_dbnew.h>
#ifndef __Moses_MB_ChangeDescr_h__
#define __Moses_MB_ChangeDescr_h__

#include "gnricmsg.h"

class c_Moses_MB_ChangeDescr : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Pwd;
	STRING Descr;

	c_Moses_MB_ChangeDescr();
	c_Moses_MB_ChangeDescr(const c_Moses_MB_ChangeDescr &r);
	~c_Moses_MB_ChangeDescr();

	Declare_Class(c_Moses_MB_ChangeDescr);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_ChangeDescr : public GenericMsg
{
public:

	STRING Error;

	a_Moses_MB_ChangeDescr(const char *pErr);
	a_Moses_MB_ChangeDescr();

	a_Moses_MB_ChangeDescr(const a_Moses_MB_ChangeDescr &r);

	~a_Moses_MB_ChangeDescr();

	Declare_Class(a_Moses_MB_ChangeDescr);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
