#include <st_dbnew.h>
#ifndef __Moses_MB_GetInfo_h__
#define __Moses_MB_GetInfo_h__

#include "gnricmsg.h"

class c_Moses_MB_GetInfo : public GenericMsg
{
public:

	STRING MailBoxName;
	STRING Pwd;
	INT32  MsgId;

	c_Moses_MB_GetInfo();
	c_Moses_MB_GetInfo(const c_Moses_MB_GetInfo &r);
	~c_Moses_MB_GetInfo();

	Declare_Class(c_Moses_MB_GetInfo);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_GetInfo : public GenericMsg
{
public:

	STRING Error;
	
	VECT<STRING> Status; 
	STRING       Sender; 
	STRING       Destination; 
	STRING       Subject; 
	INT32  		 BodySize; 
	INT16        bIncoming;

	a_Moses_MB_GetInfo(const char *pErr);
	a_Moses_MB_GetInfo();

	a_Moses_MB_GetInfo(const a_Moses_MB_GetInfo &r);

	~a_Moses_MB_GetInfo();

	Declare_Class(a_Moses_MB_GetInfo);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
