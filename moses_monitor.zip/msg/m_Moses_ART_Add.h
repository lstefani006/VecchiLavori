#include <st_dbnew.h>
#ifndef __Moses_ART_Add_h__
#define __Moses_ART_Add_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_ART_Add : public GenericMsg
{
public:
	STRING User;
	INT16  bInternal;
	STRING MailBoxType;
	STRING MailBoxAddress;
	STRING Subject;

	c_Moses_ART_Add();
	c_Moses_ART_Add(const c_Moses_ART_Add &r);
	~c_Moses_ART_Add();
	Declare_Class(c_Moses_ART_Add);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_ART_Add : public GenericMsg
{
public:
	STRING Error;

	a_Moses_ART_Add(const char *pErr);
	a_Moses_ART_Add();
	a_Moses_ART_Add(const a_Moses_ART_Add &r);
	~a_Moses_ART_Add();
	Declare_Class(a_Moses_ART_Add);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
