#include <st_dbnew.h>
#include "m_Moses_Event_Alert_NewMsgInFolder.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Event.h"
#endif

c_Moses_Event_Alert_NewMsgInFolder::c_Moses_Event_Alert_NewMsgInFolder()
{
}

c_Moses_Event_Alert_NewMsgInFolder::c_Moses_Event_Alert_NewMsgInFolder(const c_Moses_Event_Alert_NewMsgInFolder &r)
{
	EventId         = r.EventId;
}

c_Moses_Event_Alert_NewMsgInFolder::~c_Moses_Event_Alert_NewMsgInFolder() {}


void c_Moses_Event_Alert_NewMsgInFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(EventId, b, d);
}

void c_Moses_Event_Alert_NewMsgInFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "EventId " << EventId << endl;
}

Implement_Class(c_Moses_Event_Alert_NewMsgInFolder);



GenericMsg * c_Moses_Event_Alert_NewMsgInFolder::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Event_Alert_NewMsgInFolder(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Event_Alert_NewMsgInFolder::a_Moses_Event_Alert_NewMsgInFolder(const char *pErr) { Error = pErr; }
a_Moses_Event_Alert_NewMsgInFolder::a_Moses_Event_Alert_NewMsgInFolder() {}

a_Moses_Event_Alert_NewMsgInFolder::a_Moses_Event_Alert_NewMsgInFolder(const a_Moses_Event_Alert_NewMsgInFolder &r)
{
	Error	= r.Error;
	MsgId   = r.MsgId;
	Folder  = r.Folder;
}

a_Moses_Event_Alert_NewMsgInFolder::~a_Moses_Event_Alert_NewMsgInFolder() {}

void a_Moses_Event_Alert_NewMsgInFolder::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b,       pSer, d);
	pSer->Serialize(Error,   b,    d);
	pSer->Serialize(MsgId,   b,    d);
	pSer->Serialize(Folder,  b,    d);
}

void a_Moses_Event_Alert_NewMsgInFolder::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error   " << Error    << endl;
	s << "MsgId   " << MsgId    << endl;
	s << "Folder  " << Folder   << endl;
}

Implement_Class(a_Moses_Event_Alert_NewMsgInFolder);

GenericMsg * a_Moses_Event_Alert_NewMsgInFolder::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_Event_Alert_NewMsgInFolder(
		int	   EventId,
		INT32  &out_MsgId,
		STRING &out_Folder)
{
	c_Moses_Event_Alert_NewMsgInFolder m;

	m.EventId 	= EventId;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Event_Alert_NewMsgInFolder::IdMsg)
	{
		a_Moses_Event_Alert_NewMsgInFolder *answ = (a_Moses_Event_Alert_NewMsgInFolder *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_MsgId  = answ->MsgId;
			out_Folder = answ->Folder;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

