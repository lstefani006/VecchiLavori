#include <st_dbnew.h>
#ifndef __Moses_Event_Alert_NewMsgInFolder_h__
#define __Moses_Event_Alert_NewMsgInFolder_h__

#include "gnricmsg.h"

class c_Moses_Event_Alert_NewMsgInFolder : public GenericMsg
{
public:

	INT32  EventId;

	c_Moses_Event_Alert_NewMsgInFolder();
	c_Moses_Event_Alert_NewMsgInFolder(const c_Moses_Event_Alert_NewMsgInFolder &r);
	~c_Moses_Event_Alert_NewMsgInFolder();

	Declare_Class(c_Moses_Event_Alert_NewMsgInFolder);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_Event_Alert_NewMsgInFolder : public GenericMsg
{
public:

	STRING Error;
	STRING Folder;
	INT32  MsgId;

	a_Moses_Event_Alert_NewMsgInFolder(const char *pErr);
	a_Moses_Event_Alert_NewMsgInFolder();

	a_Moses_Event_Alert_NewMsgInFolder(const a_Moses_Event_Alert_NewMsgInFolder &r);

	~a_Moses_Event_Alert_NewMsgInFolder();

	Declare_Class(a_Moses_Event_Alert_NewMsgInFolder);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
