#include <st_dbnew.h>
#include "m_Moses_Work_GetLanguage.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Work.h"
#endif


c_Moses_Work_GetLanguage::c_Moses_Work_GetLanguage()
{
}

c_Moses_Work_GetLanguage::c_Moses_Work_GetLanguage(const c_Moses_Work_GetLanguage &r)
{
}

c_Moses_Work_GetLanguage::~c_Moses_Work_GetLanguage() {}


void c_Moses_Work_GetLanguage::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_Work_GetLanguage::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_Work_GetLanguage);

GenericMsg * c_Moses_Work_GetLanguage::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Work_GetLanguage(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Work_GetLanguage::a_Moses_Work_GetLanguage(const char *pErr) { Error = pErr; }
a_Moses_Work_GetLanguage::a_Moses_Work_GetLanguage()
{
}

a_Moses_Work_GetLanguage::a_Moses_Work_GetLanguage(const a_Moses_Work_GetLanguage &r)
{
	Error	  = r.Error;
	Language  = r.Language;
}

a_Moses_Work_GetLanguage::~a_Moses_Work_GetLanguage()
{
}

void a_Moses_Work_GetLanguage::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(Language, b, d);
}

void a_Moses_Work_GetLanguage::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError    " << Error     << endl;
	s << "\tLanguage " << Language  << endl;
}

Implement_Class(a_Moses_Work_GetLanguage);

GenericMsg * a_Moses_Work_GetLanguage::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Work_GetLanguage(STRING &out_Language)
{
	c_Moses_Work_GetLanguage m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Work_GetLanguage::IdMsg)
	{
		a_Moses_Work_GetLanguage *answ = (a_Moses_Work_GetLanguage *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_Language  = answ->Language;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

