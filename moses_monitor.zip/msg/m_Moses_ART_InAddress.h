#include <st_dbnew.h>
#ifndef __Moses_ART_InAddress_h__
#define __Moses_ART_InAddress_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_ART_InAddress : public GenericMsg
{
public:
	STRING MailBoxType;
	STRING MailBoxAddress;
	STRING Subject;

	c_Moses_ART_InAddress();
	c_Moses_ART_InAddress(const c_Moses_ART_InAddress &r);
	~c_Moses_ART_InAddress();
	Declare_Class(c_Moses_ART_InAddress);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_ART_InAddress : public GenericMsg
{
public:
	STRING Error;

	STRING User;

	a_Moses_ART_InAddress(const char *pErr);
	a_Moses_ART_InAddress();
	a_Moses_ART_InAddress(const a_Moses_ART_InAddress &r);
	~a_Moses_ART_InAddress();
	Declare_Class(a_Moses_ART_InAddress);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
