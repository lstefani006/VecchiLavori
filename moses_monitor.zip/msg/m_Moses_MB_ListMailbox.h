#include <st_dbnew.h>
#ifndef __Moses_MB_ListMailbox_h__
#define __Moses_MB_ListMailbox_h__

#include "gnricmsg.h"

class c_Moses_MB_ListMailbox : public GenericMsg
{
public:

	INT32 Index;

	c_Moses_MB_ListMailbox();
	c_Moses_MB_ListMailbox(const c_Moses_MB_ListMailbox &r);
	~c_Moses_MB_ListMailbox();

	Declare_Class(c_Moses_MB_ListMailbox);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_ListMailbox : public GenericMsg
{
public:

	STRING Error;
	STRING MailboxName;
	STRING Owner;
	STRING Pwd;
	STRING Descr;
	INT16  Valid;

	a_Moses_MB_ListMailbox(const char *pErr);
	a_Moses_MB_ListMailbox();

	a_Moses_MB_ListMailbox(const a_Moses_MB_ListMailbox &r);

	~a_Moses_MB_ListMailbox();

	Declare_Class(a_Moses_MB_ListMailbox);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
