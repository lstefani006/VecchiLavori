#include <st_dbnew.h>
#include "m_Moses_MB_CreateMailbox.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_CreateMailbox::c_Moses_MB_CreateMailbox()
{
}

c_Moses_MB_CreateMailbox::c_Moses_MB_CreateMailbox(const c_Moses_MB_CreateMailbox &r)
{
	MailBoxName     = r.MailBoxName;
	Owner    		= r.Owner;
	Pwd    			= r.Pwd;
	Descr    		= r.Descr;
}

c_Moses_MB_CreateMailbox::~c_Moses_MB_CreateMailbox() {}


void c_Moses_MB_CreateMailbox::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Owner, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(Descr, b, d);
}

void c_Moses_MB_CreateMailbox::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName  " << MailBoxName << endl;
	s << "\tOwner        " << Owner       << endl;
	s << "\tPwd          " << Pwd         << endl;
	s << "\tDescr        " << Descr       << endl;
}

Implement_Class(c_Moses_MB_CreateMailbox);



GenericMsg * c_Moses_MB_CreateMailbox::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_CreateMailbox(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_CreateMailbox::a_Moses_MB_CreateMailbox(const char *pErr) { Error = pErr; }
a_Moses_MB_CreateMailbox::a_Moses_MB_CreateMailbox() {}

a_Moses_MB_CreateMailbox::a_Moses_MB_CreateMailbox(const a_Moses_MB_CreateMailbox &r)
{
	Error	= r.Error;
}

a_Moses_MB_CreateMailbox::~a_Moses_MB_CreateMailbox() {}

void a_Moses_MB_CreateMailbox::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_CreateMailbox::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError " << Error  << endl;
}

Implement_Class(a_Moses_MB_CreateMailbox);

GenericMsg * a_Moses_MB_CreateMailbox::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_CreateMailbox(const char *MailBoxName, 
							  const char *Owner,
							  const char *Pwd,
							  const char *Descr)
{
	c_Moses_MB_CreateMailbox m;

	m.MailBoxName 	= MailBoxName;
	m.Owner   	    = Owner;
	m.Pwd   	    = Pwd;
	m.Descr   	    = Descr;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_CreateMailbox::IdMsg)
	{
		a_Moses_MB_CreateMailbox *answ = (a_Moses_MB_CreateMailbox *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

