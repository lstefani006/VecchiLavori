#include <st_dbnew.h>
#include "m_Moses_Scheduler_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "SC.h"
#endif


c_Moses_Scheduler_List::c_Moses_Scheduler_List()
{
}

c_Moses_Scheduler_List::c_Moses_Scheduler_List(const c_Moses_Scheduler_List &r)
{
}

c_Moses_Scheduler_List::~c_Moses_Scheduler_List() {}


void c_Moses_Scheduler_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_Scheduler_List::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_Scheduler_List);

GenericMsg * c_Moses_Scheduler_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Scheduler_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Scheduler_List::a_Moses_Scheduler_List(const char *pErr) { Error = pErr; }
a_Moses_Scheduler_List::a_Moses_Scheduler_List()
{
}

a_Moses_Scheduler_List::a_Moses_Scheduler_List(const a_Moses_Scheduler_List &r)
{
	Error	    = r.Error;
	IndexList   = r.IndexList;
	WhenList    = r.WhenList;
	ActionList  = r.ActionList;
}

a_Moses_Scheduler_List::~a_Moses_Scheduler_List()
{
}

void a_Moses_Scheduler_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(IndexList, b, d);
	pSer->Serialize(WhenList, b, d);
	pSer->Serialize(ActionList, b, d);
}

void a_Moses_Scheduler_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error      " << Error       << endl;
	s << "IndexList  " << IndexList   << endl;
	s << "WhenList   " << WhenList    << endl;
	s << "ActionList " << ActionList  << endl;
}

Implement_Class(a_Moses_Scheduler_List);

GenericMsg * a_Moses_Scheduler_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Scheduler_List(
		VECT<INT16>  &IndexList,
		VECT<STRING> &WhenList,
		VECT<STRING> &ActionList)
{
	c_Moses_Scheduler_List m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Scheduler_List::IdMsg)
	{
		a_Moses_Scheduler_List *answ = (a_Moses_Scheduler_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			IndexList   = answ->IndexList;
			WhenList    = answ->WhenList;
			ActionList  = answ->ActionList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

///////////////////////////////////////////////////////////////////////////////
