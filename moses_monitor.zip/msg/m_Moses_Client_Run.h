#include <st_dbnew.h>
#ifndef __Moses_Client_Run_h__
#define __Moses_Client_Run_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_Client_Run : public GenericMsg
{
public:
	STRING 	ClientName;

	c_Moses_Client_Run();
	c_Moses_Client_Run(const c_Moses_Client_Run &r);
	~c_Moses_Client_Run();
	Declare_Class(c_Moses_Client_Run);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Client_Run : public GenericMsg
{
public:
	STRING Error;

	a_Moses_Client_Run(const char *pErr);
	a_Moses_Client_Run();
	a_Moses_Client_Run(const a_Moses_Client_Run &r);
	~a_Moses_Client_Run();
	Declare_Class(a_Moses_Client_Run);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
