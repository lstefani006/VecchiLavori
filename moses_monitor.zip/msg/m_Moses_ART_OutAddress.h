#include <st_dbnew.h>
#ifndef __Moses_ART_OutAddress_h__
#define __Moses_ART_OutAddress_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_ART_OutAddress : public GenericMsg
{
public:
	STRING User;
	STRING MailBoxType;

	c_Moses_ART_OutAddress();
	c_Moses_ART_OutAddress(const c_Moses_ART_OutAddress &r);
	~c_Moses_ART_OutAddress();
	Declare_Class(c_Moses_ART_OutAddress);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_ART_OutAddress : public GenericMsg
{
public:
	STRING Error;

	STRING MailBoxType;
	STRING MailBoxAddress;
	STRING Subject;

	a_Moses_ART_OutAddress(const char *pErr);
	a_Moses_ART_OutAddress();
	a_Moses_ART_OutAddress(const a_Moses_ART_OutAddress &r);
	~a_Moses_ART_OutAddress();
	Declare_Class(a_Moses_ART_OutAddress);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
