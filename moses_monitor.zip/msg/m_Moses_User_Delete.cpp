#include <st_dbnew.h>
#include "m_Moses_User_Delete.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
    #include "User.h"
	#include "server.h"
#endif



c_Moses_User_Delete::c_Moses_User_Delete()
{
}

c_Moses_User_Delete::c_Moses_User_Delete(const c_Moses_User_Delete &r)
{
	UserName     = r.UserName;
	bCascade     = r.bCascade;
}

c_Moses_User_Delete::~c_Moses_User_Delete() {}


void c_Moses_User_Delete::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(UserName, b, d);
	pSer->Serialize(bCascade, b, d);
}

void c_Moses_User_Delete::Print(ostream &s) const
{
	BASE::Print(s);
	s << "UserName     " << UserName      << endl;
	s << "bCascade     " << bCascade      << endl;
}

Implement_Class(c_Moses_User_Delete);



GenericMsg * c_Moses_User_Delete::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return User_Delete(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_User_Delete::a_Moses_User_Delete(const char *pErr) { Error = pErr; }
a_Moses_User_Delete::a_Moses_User_Delete() {}

a_Moses_User_Delete::a_Moses_User_Delete(const a_Moses_User_Delete &r)
{
	Error	= r.Error;
}

a_Moses_User_Delete::~a_Moses_User_Delete() {}

void a_Moses_User_Delete::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_User_Delete::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_User_Delete);

GenericMsg * a_Moses_User_Delete::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_User_Delete(const char *UserName, int bCascade)
{
	c_Moses_User_Delete m;

	m.UserName 		= UserName;
	m.bCascade   	= bCascade;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_User_Delete::IdMsg)
	{
		a_Moses_User_Delete *answ = (a_Moses_User_Delete *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

