#include <st_dbnew.h>
#include <moses.h>
#include <mras.h>


STRING Moses_Connection_Dial(const char *Provider)
{
	int b = Ras_Connect(Provider);

	if (b)
		return "";
	else
		return "CN0010 - cannot dial to remote host";
}

STRING Moses_Connection_HungUp(const char *Provider)
{
	int b = Ras_Disconnect(Provider);

	if (b)
		return "";
	else
		return "CN0011 - cannot hung up";
}

STRING Moses_Connection_IsRemote(const char *ProviderName, INT16 &out_bRemote)
{
	out_bRemote = Ras_IsConnected(ProviderName);
	return "";
}
