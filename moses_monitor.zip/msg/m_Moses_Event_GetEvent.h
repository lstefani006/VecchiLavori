#include <st_dbnew.h>
#ifndef __Moses_Event_GetEvent_h__
#define __Moses_Event_GetEvent_h__

#include "gnricmsg.h"

class c_Moses_Event_GetEvent : public GenericMsg
{
public:

	INT32	mSec;

	c_Moses_Event_GetEvent();
	c_Moses_Event_GetEvent(const c_Moses_Event_GetEvent &r);
	~c_Moses_Event_GetEvent();

	Declare_Class(c_Moses_Event_GetEvent);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_Event_GetEvent : public GenericMsg
{
public:

	STRING Error;
	INT32  EventId;

	a_Moses_Event_GetEvent(const char *pErr);
	a_Moses_Event_GetEvent();

	a_Moses_Event_GetEvent(const a_Moses_Event_GetEvent &r);

	~a_Moses_Event_GetEvent();

	Declare_Class(a_Moses_Event_GetEvent);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
