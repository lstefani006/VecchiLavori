#include <st_dbnew.h>
#include "m_Moses_Scheduler_Delete.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "SC.h"
#endif


c_Moses_Scheduler_Delete::c_Moses_Scheduler_Delete()
{
}

c_Moses_Scheduler_Delete::c_Moses_Scheduler_Delete(const c_Moses_Scheduler_Delete &r)
{
	Index      = r.Index;
}

c_Moses_Scheduler_Delete::~c_Moses_Scheduler_Delete() {}


void c_Moses_Scheduler_Delete::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Index, b, d);
}

void c_Moses_Scheduler_Delete::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Index     " << Index      << endl;
}

Implement_Class(c_Moses_Scheduler_Delete);


GenericMsg * c_Moses_Scheduler_Delete::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Scheduler_Delete(this, nClient);
#else
	return NULL;
#endif
}


///////////////////////////////////////////////////////////////////////////////


a_Moses_Scheduler_Delete::a_Moses_Scheduler_Delete(const char *pErr) { Error = pErr; }
a_Moses_Scheduler_Delete::a_Moses_Scheduler_Delete() {}

a_Moses_Scheduler_Delete::a_Moses_Scheduler_Delete(const a_Moses_Scheduler_Delete &r)
{
	Error	= r.Error;
}

a_Moses_Scheduler_Delete::~a_Moses_Scheduler_Delete() {}

void a_Moses_Scheduler_Delete::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_Scheduler_Delete::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error " << Error  << endl;
}

Implement_Class(a_Moses_Scheduler_Delete);


GenericMsg * a_Moses_Scheduler_Delete::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Scheduler_Delete(INT16 Index)
{
	c_Moses_Scheduler_Delete m;

	m.Index	= Index;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Scheduler_Delete::IdMsg)
	{
		a_Moses_Scheduler_Delete *answ = (a_Moses_Scheduler_Delete *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}
