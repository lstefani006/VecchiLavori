#include <st_dbnew.h>
#ifndef __Moses_Licence_Set_h__
#define __Moses_Licence_Set_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_Licence_Set : public GenericMsg
{
public:
	STRING Pwd;
	STRING DateLicence;

	c_Moses_Licence_Set();
	c_Moses_Licence_Set(const c_Moses_Licence_Set &r);
	~c_Moses_Licence_Set();
	Declare_Class(c_Moses_Licence_Set);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_Licence_Set : public GenericMsg
{
public:
	STRING Error;

	a_Moses_Licence_Set(const char *pErr);
	a_Moses_Licence_Set();
	a_Moses_Licence_Set(const a_Moses_Licence_Set &r);
	~a_Moses_Licence_Set();
	Declare_Class(a_Moses_Licence_Set);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
