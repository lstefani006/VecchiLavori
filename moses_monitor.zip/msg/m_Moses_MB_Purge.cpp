#include <st_dbnew.h>
#include "m_Moses_MB_Purge.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_Purge::c_Moses_MB_Purge()
{
}

c_Moses_MB_Purge::c_Moses_MB_Purge(const c_Moses_MB_Purge &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
}

c_Moses_MB_Purge::~c_Moses_MB_Purge() {}


void c_Moses_MB_Purge::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
}

void c_Moses_MB_Purge::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName " << MailBoxName << endl;
	s << "\tPwd         " << Pwd         << endl;
}

Implement_Class(c_Moses_MB_Purge);



GenericMsg * c_Moses_MB_Purge::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_Purge(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_Purge::a_Moses_MB_Purge(const char *pErr) { Error = pErr; }
a_Moses_MB_Purge::a_Moses_MB_Purge() {}

a_Moses_MB_Purge::a_Moses_MB_Purge(const a_Moses_MB_Purge &r)
{
	Error	= r.Error;
	Deleted = r.Deleted;
}

a_Moses_MB_Purge::~a_Moses_MB_Purge() {}

void a_Moses_MB_Purge::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(Deleted, b, d);
}

void a_Moses_MB_Purge::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError   " << Error   << endl;
	s << "\tDeleted " << Deleted << endl;
}

Implement_Class(a_Moses_MB_Purge);

GenericMsg * a_Moses_MB_Purge::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_Purge (const char   *MailBoxName, 
					   INT16          &out_Deleted)
{
	c_Moses_MB_Purge m;

	m.MailBoxName 	= MailBoxName;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_Purge::IdMsg)
	{
		a_Moses_MB_Purge *answ = (a_Moses_MB_Purge *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_Deleted = answ->Deleted;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

