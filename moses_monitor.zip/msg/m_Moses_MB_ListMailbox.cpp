#include <st_dbnew.h>
#include "m_Moses_MB_ListMailbox.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_ListMailbox::c_Moses_MB_ListMailbox()
{
}

c_Moses_MB_ListMailbox::c_Moses_MB_ListMailbox(const c_Moses_MB_ListMailbox &r)
{
	Index = r.Index;
}

c_Moses_MB_ListMailbox::~c_Moses_MB_ListMailbox() {}


void c_Moses_MB_ListMailbox::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Index, b, d);
}

void c_Moses_MB_ListMailbox::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tIndex     " << Index      << endl;
}

Implement_Class(c_Moses_MB_ListMailbox);


GenericMsg * c_Moses_MB_ListMailbox::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_ListMailbox(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_ListMailbox::a_Moses_MB_ListMailbox(const char *pErr) { Error = pErr; }
a_Moses_MB_ListMailbox::a_Moses_MB_ListMailbox() {}

a_Moses_MB_ListMailbox::a_Moses_MB_ListMailbox(const a_Moses_MB_ListMailbox &r)
{
	Error      		= r.Error;
	MailboxName     = r.MailboxName;
	Owner  			= r.Owner;
	Pwd  			= r.Pwd;
	Descr  			= r.Descr;

	Valid      		= r.Valid;
}

a_Moses_MB_ListMailbox::~a_Moses_MB_ListMailbox() {}

void a_Moses_MB_ListMailbox::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error,        b, d);
	pSer->Serialize(MailboxName,  b, d);
	pSer->Serialize(Owner,        b, d);
	pSer->Serialize(Pwd,          b, d);
	pSer->Serialize(Descr,        b, d);
	pSer->Serialize(Valid,        b, d);
}

void a_Moses_MB_ListMailbox::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError        " << Error       << endl;
	s << "\tMailboxName  " << MailboxName << endl;
	s << "\tOwner        " << Owner       << endl;
	s << "\tPwd          " << Pwd         << endl;
	s << "\tDescr        " << Descr       << endl;
	s << "\tValid        " << Valid       << endl;
}

Implement_Class(a_Moses_MB_ListMailbox);


GenericMsg * a_Moses_MB_ListMailbox::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_ListMailbox   (int     Index,
							   STRING &out_MailboxName, 
							   STRING &out_Owner, 
							   STRING &out_Pwd, 
							   STRING &out_Descr, 
							   INT16  &out_Valid)
{
	c_Moses_MB_ListMailbox m;

	m.Index = Index;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_ListMailbox::IdMsg)
	{
		a_Moses_MB_ListMailbox *answ = (a_Moses_MB_ListMailbox *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_MailboxName = answ->MailboxName;
			out_Owner 		= answ->Owner;
			out_Pwd 		= answ->Pwd;
			out_Descr 		= answ->Descr;
			out_Valid 		= answ->Valid;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

