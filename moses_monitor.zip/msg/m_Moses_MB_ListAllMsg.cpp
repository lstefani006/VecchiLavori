#include <st_dbnew.h>
#include "m_Moses_MB_ListAllMsg.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_ListAllMsg::c_Moses_MB_ListAllMsg()
{
}

c_Moses_MB_ListAllMsg::c_Moses_MB_ListAllMsg(const c_Moses_MB_ListAllMsg &r)
{
	MailBoxName     = r.MailBoxName;
	Folder    		= r.Folder;
	Cond_UserField  = r.Cond_UserField;
	Cond_Accessed   = r.Cond_Accessed;
	Cond_Sender     = r.Cond_Sender;
	Cond_Receiver   = r.Cond_Receiver;
}

c_Moses_MB_ListAllMsg::~c_Moses_MB_ListAllMsg() {}


void c_Moses_MB_ListAllMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Folder, b, d);
	pSer->Serialize(Cond_UserField, b, d);
	pSer->Serialize(Cond_Accessed, b, d);
	pSer->Serialize(Cond_Sender, b, d);
	pSer->Serialize(Cond_Receiver, b, d);
}

void c_Moses_MB_ListAllMsg::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName    " << MailBoxName    << endl;
	s << "\tFolder         " << Folder         << endl;
	s << "\tCond_UserField " << Cond_UserField << endl;
	s << "\tCond_Accessed  " << Cond_Accessed  << endl;
	s << "\tCond_Sender    " << Cond_Sender    << endl;
	s << "\tCond_Receiver  " << Cond_Receiver  << endl;
}

Implement_Class(c_Moses_MB_ListAllMsg);



GenericMsg * c_Moses_MB_ListAllMsg::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER 
	return MB_ListAllMsg(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_ListAllMsg::a_Moses_MB_ListAllMsg(const char *pErr) { Error = pErr; }
a_Moses_MB_ListAllMsg::a_Moses_MB_ListAllMsg() {}

a_Moses_MB_ListAllMsg::a_Moses_MB_ListAllMsg(const a_Moses_MB_ListAllMsg &r)
{
	Error		= r.Error;
	MsgIdList	= r.MsgIdList;
	DeleteList	= r.DeleteList;
}

a_Moses_MB_ListAllMsg::~a_Moses_MB_ListAllMsg() {}

void a_Moses_MB_ListAllMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(MsgIdList, b, d);
	pSer->Serialize(DeleteList, b, d);
}

void a_Moses_MB_ListAllMsg::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError      " << Error      << endl;
	s << "\tMsgIdList  " << MsgIdList  << endl;
	s << "\tDeleteList " << DeleteList << endl;
}

Implement_Class(a_Moses_MB_ListAllMsg);

GenericMsg * a_Moses_MB_ListAllMsg::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_ListAllMsg(const char   *MailBoxName, 
					    const char   *Folder,
					    const char   *Cond_UserField,
					    const char   *Cond_Accessed,
					    const char   *Cond_Sender,
					    const char   *Cond_Receiver,
					    VECT<INT32>  &out_MsgIdList,
					    VECT<INT16>  &out_DeleteList)
{
	c_Moses_MB_ListAllMsg m;

	m.MailBoxName 	= MailBoxName;
	m.Folder   	    = Folder;
	m.Cond_UserField = Cond_UserField;
	m.Cond_Accessed  = Cond_Accessed;
	m.Cond_Sender    = Cond_Sender;
	m.Cond_Receiver  = Cond_Receiver;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_ListAllMsg::IdMsg)
	{
		a_Moses_MB_ListAllMsg *answ = (a_Moses_MB_ListAllMsg *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_MsgIdList  = answ->MsgIdList;
				out_DeleteList = answ->DeleteList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

