#include <st_dbnew.h>
#ifndef __Moses_MB_UndeleteMsg_h__
#define __Moses_MB_UndeleteMsg_h__

#include "gnricmsg.h"

class c_Moses_MB_UndeleteMsg : public GenericMsg
{
public:

	INT32  MsgId;

	c_Moses_MB_UndeleteMsg();
	c_Moses_MB_UndeleteMsg(const c_Moses_MB_UndeleteMsg &r);
	~c_Moses_MB_UndeleteMsg();

	Declare_Class(c_Moses_MB_UndeleteMsg);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_MB_UndeleteMsg : public GenericMsg
{
public:

	STRING Error;
	
	INT32 Recovered;

	a_Moses_MB_UndeleteMsg(const char *pErr);
	a_Moses_MB_UndeleteMsg();

	a_Moses_MB_UndeleteMsg(const a_Moses_MB_UndeleteMsg &r);

	~a_Moses_MB_UndeleteMsg();

	Declare_Class(a_Moses_MB_UndeleteMsg);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);

	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
