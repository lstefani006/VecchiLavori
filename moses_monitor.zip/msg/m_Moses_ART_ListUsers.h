#include <st_dbnew.h>
#ifndef __Moses_ART_ListUsers_h__
#define __Moses_ART_ListUsers_h__

#include "gnricmsg.h"

/////////////////////////////////////////////////////////////////////

class c_Moses_ART_ListUsers : public GenericMsg
{
public:

	INT16  bInternal;
	STRING MailBoxType;

	c_Moses_ART_ListUsers();
	c_Moses_ART_ListUsers(const c_Moses_ART_ListUsers &r);
	~c_Moses_ART_ListUsers();
	Declare_Class(c_Moses_ART_ListUsers);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);

};


class a_Moses_ART_ListUsers : public GenericMsg
{
public:
	
	STRING Error;
	VECT<STRING> UsersList;

	a_Moses_ART_ListUsers(const char *pErr);
	a_Moses_ART_ListUsers();
	a_Moses_ART_ListUsers(const a_Moses_ART_ListUsers &r);
	~a_Moses_ART_ListUsers();
	Declare_Class(a_Moses_ART_ListUsers);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


#endif
