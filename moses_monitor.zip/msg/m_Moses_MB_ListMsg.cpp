#include <st_dbnew.h>
#include "m_Moses_MB_ListMsg.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif

c_Moses_MB_ListMsg::c_Moses_MB_ListMsg()
{
}

c_Moses_MB_ListMsg::c_Moses_MB_ListMsg(const c_Moses_MB_ListMsg &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
	Folder    		= r.Folder;
	Cond_UserField  = r.Cond_UserField;
	Cond_Accessed   = r.Cond_Accessed;
	Cond_Sender     = r.Cond_Sender;
	Cond_Receiver   = r.Cond_Receiver;
}

c_Moses_MB_ListMsg::~c_Moses_MB_ListMsg() {}


void c_Moses_MB_ListMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(Folder, b, d);
	pSer->Serialize(Cond_UserField, b, d);
	pSer->Serialize(Cond_Accessed, b, d);
	pSer->Serialize(Cond_Sender, b, d);
	pSer->Serialize(Cond_Receiver, b, d);
}

void c_Moses_MB_ListMsg::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName    " << MailBoxName    << endl;
	s << "\tPwd            " << Pwd            << endl;
	s << "\tFolder         " << Folder         << endl;
	s << "\tCond_UserField " << Cond_UserField << endl;
	s << "\tCond_Accessed  " << Cond_Accessed  << endl;
	s << "\tCond_Sender    " << Cond_Sender    << endl;
	s << "\tCond_Receiver  " << Cond_Receiver  << endl;
}

Implement_Class(c_Moses_MB_ListMsg);



GenericMsg * c_Moses_MB_ListMsg::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_ListMsg(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_ListMsg::a_Moses_MB_ListMsg(const char *pErr) { Error = pErr; }
a_Moses_MB_ListMsg::a_Moses_MB_ListMsg() {}

a_Moses_MB_ListMsg::a_Moses_MB_ListMsg(const a_Moses_MB_ListMsg &r)
{
	Error		= r.Error;
	MsgIdList	= r.MsgIdList;
}

a_Moses_MB_ListMsg::~a_Moses_MB_ListMsg() {}

void a_Moses_MB_ListMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(MsgIdList, b, d);
}

void a_Moses_MB_ListMsg::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError     " << Error      << endl;
	s << "\tMsgIdList " << MsgIdList  << endl;
}

Implement_Class(a_Moses_MB_ListMsg);

GenericMsg * a_Moses_MB_ListMsg::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_ListMsg(const char   *MailBoxName, 
					    const char   *Pwd,
					    const char   *Folder,
					    const char   *Cond_UserField,
					    const char   *Cond_Accessed,
					    const char   *Cond_Sender,
					    const char   *Cond_Receiver,
					    VECT<INT32>  &out_MsgIdList)
{
	c_Moses_MB_ListMsg m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.Folder   	    = Folder;
	m.Cond_UserField = Cond_UserField;
	m.Cond_Accessed  = Cond_Accessed;
	m.Cond_Sender    = Cond_Sender;
	m.Cond_Receiver  = Cond_Receiver;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_ListMsg::IdMsg)
	{
		a_Moses_MB_ListMsg *answ = (a_Moses_MB_ListMsg *)pMsg;

		if (answ->Error.Len() == 0)
		{
				out_MsgIdList = answ->MsgIdList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

