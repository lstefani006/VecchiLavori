#include <st_dbnew.h>
#include "m_Moses_Client_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "Client.h"
#endif


c_Moses_Client_List::c_Moses_Client_List()
{
}

c_Moses_Client_List::c_Moses_Client_List(const c_Moses_Client_List &r)
{
}

c_Moses_Client_List::~c_Moses_Client_List() {}


void c_Moses_Client_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_Client_List::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_Client_List);

GenericMsg * c_Moses_Client_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return Client_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_Client_List::a_Moses_Client_List(const char *pErr) { Error = pErr; }
a_Moses_Client_List::a_Moses_Client_List()
{
}

a_Moses_Client_List::a_Moses_Client_List(const a_Moses_Client_List &r)
{
	Error	    	= r.Error;
	ClientNameList  = r.ClientNameList;
	ClientDescrList = r.ClientDescrList;
	ClientTypeList 	= r.ClientTypeList;
	ActiveList 		= r.ActiveList;
}

a_Moses_Client_List::~a_Moses_Client_List()
{
}

void a_Moses_Client_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(ClientNameList, b, d);
	pSer->Serialize(ClientDescrList, b, d);
	pSer->Serialize(ClientTypeList, b, d);
	pSer->Serialize(ActiveList, b, d);
}

void a_Moses_Client_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error           " << Error       << endl;
	s << "ClientNameList  " << ClientNameList  << endl;
	s << "ClientDescrList " << ClientDescrList << endl;
	s << "ClientTypeList  " << ClientTypeList << endl;
	s << "ActiveList      " << ActiveList << endl;
}

Implement_Class(a_Moses_Client_List);

GenericMsg * a_Moses_Client_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_Client_List(
		VECT<STRING> &out_ClientNameList,
		VECT<STRING> &out_ClientDescrList,
		VECT<STRING> &out_ClientTypeList,
		VECT<INT16> &out_ActiveList)
{
	c_Moses_Client_List m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_Client_List::IdMsg)
	{
		a_Moses_Client_List *answ = (a_Moses_Client_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_ClientNameList  = answ->ClientNameList;
			out_ClientDescrList = answ->ClientDescrList;
			out_ClientTypeList 	= answ->ClientTypeList;
			out_ActiveList 		= answ->ActiveList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

///////////////////////////////////////////////////////////////////////////////
