#include <st_dbnew.h>
#include <moses.h>
#include <tcp_net.h>

extern TcpClient *G_pTcpClient;

STRING Moses_Connection_Open(const char *pServerName, int nPort)
{
	if (G_pTcpClient == NULL)
	{
		try
		{
			if (nPort == -1)
				nPort = TcpClient::GetServicePort("moses");
			if (nPort == -1)
				nPort = 4309;

			G_pTcpClient = STNew TcpClient;
			G_pTcpClient->Connect(pServerName, nPort);
			return "";
		}
		catch (Tcp_ConnectionError /*e*/)
		{
			STDelete G_pTcpClient;
			G_pTcpClient = NULL;

			return "Moses_Connection_Open: error opening connection";
		}
	}

	return "Moses_Connection_Open: invoked with an open connection";
}
