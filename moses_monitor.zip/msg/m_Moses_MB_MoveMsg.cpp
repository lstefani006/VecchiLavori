#include <st_dbnew.h>
#include "m_Moses_MB_MoveMsg.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MB.h"
#endif


c_Moses_MB_MoveMsg::c_Moses_MB_MoveMsg()
{
}

c_Moses_MB_MoveMsg::c_Moses_MB_MoveMsg(const c_Moses_MB_MoveMsg &r)
{
	MailBoxName     = r.MailBoxName;
	Pwd    			= r.Pwd;
	MsgId    		= r.MsgId;
	DestFolder    	= r.DestFolder;
}

c_Moses_MB_MoveMsg::~c_Moses_MB_MoveMsg() {}


void c_Moses_MB_MoveMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(MailBoxName, b, d);
	pSer->Serialize(Pwd, b, d);
	pSer->Serialize(MsgId, b, d);
	pSer->Serialize(DestFolder, b, d);
}

void c_Moses_MB_MoveMsg::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tMailBoxName  " << MailBoxName  << endl;
	s << "\tPwd          " << Pwd          << endl;
	s << "\tMsgId        " << MsgId        << endl;
	s << "\tDestFolder   " << DestFolder   << endl;
}

Implement_Class(c_Moses_MB_MoveMsg);



GenericMsg * c_Moses_MB_MoveMsg::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MB_MoveMsg(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MB_MoveMsg::a_Moses_MB_MoveMsg(const char *pErr) { Error = pErr; }
a_Moses_MB_MoveMsg::a_Moses_MB_MoveMsg() {}

a_Moses_MB_MoveMsg::a_Moses_MB_MoveMsg(const a_Moses_MB_MoveMsg &r)
{
	Error	= r.Error;
}

a_Moses_MB_MoveMsg::~a_Moses_MB_MoveMsg() {}

void a_Moses_MB_MoveMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Moses_MB_MoveMsg::Print(ostream &s) const
{
	BASE::Print(s);
	s << "\tError  " << Error   << endl;
}

Implement_Class(a_Moses_MB_MoveMsg);

GenericMsg * a_Moses_MB_MoveMsg::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
STRING Moses_MB_MoveMsg (const char   *MailBoxName, 
						   const char   *Pwd,
						   int           MsgId,
						   const char   *DestFolder)
{
	c_Moses_MB_MoveMsg m;

	m.MailBoxName 	= MailBoxName;
	m.Pwd   	    = Pwd;
	m.MsgId         = MsgId;
	m.DestFolder    = DestFolder;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MB_MoveMsg::IdMsg)
	{
		a_Moses_MB_MoveMsg *answ = (a_Moses_MB_MoveMsg *)pMsg;

		if (answ->Error.Len() == 0)
		{
				// NON ci sono parametri di output.
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

