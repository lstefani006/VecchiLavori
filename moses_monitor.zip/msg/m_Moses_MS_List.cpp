#include <st_dbnew.h>
#include "m_Moses_MS_List.h"
#include "m_Error.h"

#ifdef MOSES_SERVER
	#include "MS.h"
#endif


c_Moses_MS_List::c_Moses_MS_List()
{
}

c_Moses_MS_List::c_Moses_MS_List(const c_Moses_MS_List &r)
{
}

c_Moses_MS_List::~c_Moses_MS_List() {}


void c_Moses_MS_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
}

void c_Moses_MS_List::Print(ostream &s) const
{
	BASE::Print(s);
}

Implement_Class(c_Moses_MS_List);

GenericMsg * c_Moses_MS_List::P_ServerExecute(int nClient)
{
#ifdef MOSES_SERVER
	return MS_List(this, nClient);
#else
	return NULL;
#endif
}

///////////////////////////////////////////////////////////////////////////////


a_Moses_MS_List::a_Moses_MS_List(const char *pErr) { Error = pErr; }
a_Moses_MS_List::a_Moses_MS_List()
{
}

a_Moses_MS_List::a_Moses_MS_List(const a_Moses_MS_List &r)
{
	Error	    = r.Error;
	MSTypeList  = r.MSTypeList;
	MSDescrList = r.MSDescrList;
}

a_Moses_MS_List::~a_Moses_MS_List()
{
}

void a_Moses_MS_List::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
	pSer->Serialize(MSTypeList, b, d);
	pSer->Serialize(MSDescrList, b, d);
}

void a_Moses_MS_List::Print(ostream &s) const
{
	BASE::Print(s);
	s << "Error       " << Error       << endl;
	s << "MSTypeList  " << MSTypeList  << endl;
	s << "MSDescrList " << MSDescrList << endl;
}

Implement_Class(a_Moses_MS_List);

GenericMsg * a_Moses_MS_List::P_ServerExecute(int nClient)
{
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////


STRING Moses_MS_List(
		VECT<STRING> &out_MSTypeList,
		VECT<STRING> &out_MSDescrList)
{
	c_Moses_MS_List m;

	GenericMsg *pMsg = P_TxRx(&m);

	CheckError(pMsg);

	if (pMsg->GetIdMsg() == a_Moses_MS_List::IdMsg)
	{
		a_Moses_MS_List *answ = (a_Moses_MS_List *)pMsg;

		if (answ->Error.Len() == 0)
		{
			out_MSTypeList  = answ->MSTypeList;
			out_MSDescrList = answ->MSDescrList;
		}

		STRING e = answ->Error;
		STDelete answ;
		return e;
	}

	return "";
}

///////////////////////////////////////////////////////////////////////////////
