#include <st_dbnew.h>
#ifndef __Work_End_h__
#define __Work_End_h__

#include "gnricmsg.h"

class c_Moses_Work_End : public GenericMsg
{
public:

	INT32 Pid;
	INT16 bOk;

	c_Moses_Work_End();
	c_Moses_Work_End(const c_Moses_Work_End &r);
	~c_Moses_Work_End();

	Declare_Class(c_Moses_Work_End);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


class a_Moses_Work_End : public GenericMsg
{
public:

	STRING Error;

	a_Moses_Work_End(const char *pErr);
	a_Moses_Work_End();
	a_Moses_Work_End(const a_Moses_Work_End &r);
	~a_Moses_Work_End();

	Declare_Class(a_Moses_Work_End);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};

#endif
