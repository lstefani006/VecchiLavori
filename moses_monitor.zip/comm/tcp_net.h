#ifndef __TCP_NET_H__
#define __TCP_NET_H__


#if defined(MSDOS) || defined(_WIN32)
	#define TCP_WINSOCK
#endif


#ifdef TCP_WINSOCK
	#include <winsock.h>
#else // TCP_WINSOCK
	#include <unistd.h>
	#include <sys/errno.h>
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <sys/select.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <netdb.h>

	#define SOCKET         int
	#define INVALID_SOCKET -1
	#define SOCKET_ERROR   -1
#endif // TCP_WINSOCK


class TcpServer
{
public:
	/*
	 * istanzia un server alla porta specificata.
	 * Il costruttore esce con abort se non e` possibile far partire il server
	 */
	TcpServer(u_short nPortNumber);

	/*
	 * distrugge il server chiudendo i socket
	 */
	~TcpServer();

	/*
	 * Polla il server in attesa di eventi. Ritorna un identificatore cliente
	 * Se nClient != -1 viene pollato solo il canale specificato
	 * Ritorna se un cliente sta spedendo dei dati oppure se si e` sconnesso dal socket
	 * >= 0 se e` un cliente
	 * == -1 se e` andato in timeout
	 * se viene specificato nClient Poll controlla solo il socket <nClient>
	 * se avviene una nuova connessione Poll non ritorna
	 */
	int Poll(int mSec, int nClient = -1);

	/*
	 * Polla il server in attesa di eventi.
	 * Se nClient != -1 viene pollato solo il canale specificato
	 * Ritorna se un cliente sta spedendo dei dati o si e` sconnesso
	 * >= 0 se e` un cliente
	 * == -1 se e` andato in timeout
	 * se viene specificato nClient Poll controlla solo il socket <nClient>
	 * se avviene una nuova connessione Poll non ritorna
	 * 
	 * bAccept e` 1 se ho una nuova connessione --> posso spedire dei dati o chiudere il canale con CloseSocket
	 * bAccept e` 0 se e` richiesta una lettura (oppure una sconnessione) da un socket gia aperto
	 */
	int PollAndAccept(int &bAccept, int mSec, int nClient = -1);


	/*
	 * Riceve szMaxSize (al massimo) caratteri o zero
	 * se il cliente si sconnette
	 * Da chiamare DOPO la Poll o PollAndAccept se si vuole evitare che la chiamata si appenda
	 * in attesa che il client spedisca un pacchetto
	 */
	int  Rx(int nClient, void *pData, int szMaxSize);


	/*
	 * Riceve tutti i caratteri specificati in szSize con un timeout di mSec millisecondi
	 * Ritorna szSize (tutti) se sono stati ricevuti tutti i caratteri richiesti
	 * Ritorna 0 se il cliente si sconnette o se e` andato in timeout
	 * Da chiamare DOPO la Poll o PollAndAccept se non si desidera che la chiamata si appenda
	 * in attesa di comunicazioni del client
	 * Se invece RxAll viene chiamata non preceduta da una Poll o PollAndAccept, RxAll aspetta
	 * indefinitivamente la comunicazione del client e poi attende al max mSec millisecondi
	 * per la comunicazione 
	 */
	int  RxAll(int nClient, void *pData, int szSize, int mSec);


	/*
	 * Trasmette al cliente <nClient> i dati
	 */
	void Tx(int nClient, const void *pData, int szSizeToSend);


	/*
	 * ritorna l'indirizzo del cliente <nClient>
	 */
	const char * GetAddr(int nClient);

	/*
	 * ritorna l'indirizzo nel server
	 */
	static const char * GetLocalHost();


	/*
	 * Ritornano il socket del cliente <nClient> o di listen
	 */
	SOCKET GetSocket(int nClient) { return m_nClients[nClient]; }
	SOCKET GetSocket()      { return m_nServerId; }

	/*
	 * Chiudono il socket del cliente <nClient> o di listen
	 */
	void CloseSocket(int nClient) { CloseSocket2(m_nClients[nClient]); }
	void CloseSocket()      { CloseSocket2(m_nServerId); }

	/*
	 * Ritorna il numero di connessioni stabilite
	 */
	int NumConnections() const;


	/*
	 * Ritorna la porta assegnata per il servizio passato come parametro.
	 * Il file che contiene le informazioni della porta e' services in
	 * \windows (win95) o /etc (unix)
	 *
	 * Se il servizio non e' registrato o c'e' un errore la chiamata ritorna
	 * -1
	 */
	static int GetServicePort(const char *pServiceName);

private:
	SOCKET m_nServerId;
	SOCKET m_nClients[20];

	int  Error(SOCKET s);            // ritorna sempre 1
	void CloseSocket2(SOCKET s);
	int IsValidSocket(SOCKET s) const;
	int  GetLastErrorCode() const;

	void CloseAllSocket();
};

/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////

class Tcp_ConnectionError
{
public:
	Tcp_ConnectionError(const char *p);
	const char *Msg() const;

protected:
	const char *m_pMsg;
	int         m_Error;
};

class Tcp_IOError
{
public:
	Tcp_IOError(const char *p);
	const char *Msg() const;

protected:
	const char *m_pMsg;
	int         m_Error;
};

class TcpClient
{
public:
	/*
	 * Istanzia i dati per una connessione client
	 * sotto W32 puo` lanciare Tcp_ConnectionError se non riesce a lanciare WinSokck32.dll
	 */
	TcpClient(); // throw(Tcp_ConnectionError)

	/*
	 * Connette al server specificato.
	 * Se la connessione non e` possibile viene chiuso il socket e viene lanciata una Tcp_ConnectionError
	 */
	virtual void Connect(const char *pcRemoteHost, u_short nRemotePort); // throw(Tcp_ConnectionError);

	/*
	 * dealloca il canale e chiude il socket se questo e` ancora aperto
	 */
	virtual ~TcpClient();

	/*
	 * riceve al massimo i caratteri specificati
	 * ritorna 0     se non e` connesso
	 *         0     se va in timeout
	 *         0     se il cliente e` sconnesso
	 *         <num> il numero di bytes letti
	 * In caso di errore di rete viene chiuso il socket e viene lanciata una eccezione Tcp_IOError
	 */
	int Rx(void *pData, int szMaxSize, int mSec = -1); // throw(Tcp_IOError)

	/*
	 * riceve tutti i caratteri specificati
	 * ritorna 0            se non e` connesso
	 *         0            se va in timeout
	 *         0            se il cliente e` sconnesso (anche se prima ha letto dei dati)
	 *         <szMaxSize>  se ha letto tutti i dati
	 * In caso di errore di rete viene chiuso il socket e viene lanciata una eccezione Tcp_IOError
	 */
	int RxAll(void *pData, int szSize, int mSec = -1); // throw(Tcp_IOError)

	/*
	 * trasmette tutti i caratteri specificati
	 * In caso di errore di rete viene chiuso il socket e viene lanciata una eccezione Tcp_IOError
	 */
	void  Tx(const void *pData, int szSizeToSend); // throw(Tcp_IOError)

	/*
	 * ritorna 1 se e` connesso, 0 altrimenti
	 */
	virtual int Connected() const;

	/*
	 * Ritorna la porta assegnata per il servizio passato come parametro.
	 * Il file che contiene le informazioni della porta e' services in
	 * \windows (win95) o /etc (unix)
	 *
	 * Se il servizio non e' registrato o c'e' un errore la chiamata ritorna
	 * -1
	 */
	static int GetServicePort(const char *pServiceName);

	/*
	 * ritorna l'indirizzo del cliente
	 */
	static const char * GetLocalHost();

private:
	SOCKET m_nClientId;
	
	/*
	 * funzione usata per lanciare l'eccezione Tcp_IOError.
	 * Chiude il socket
	 */
	virtual void Error(const char *pMsg); // throw(Tcp_IOError)

	/*
	 * Chiuse il socket. Non lancia una eccezione anche se si e` verificato
	 * un errore nella close
	 */
	void CloseSocket();
};                                


#endif // __TCP_NET_H__
