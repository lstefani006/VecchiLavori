#include <st_dbnew.h>
#include "m_Error.h"

a_Error::a_Error(const char *pMsg)
{
	Error = pMsg;
}

a_Error::a_Error()
{
}

a_Error::a_Error(const a_Error &r)
{
	Error = r.Error;
}

a_Error::~a_Error()
{
}

void a_Error::Serialize(char *&b, Serializer *pSer, Serializer::Type d)
{
	BASE::Serialize(b, pSer, d);
	pSer->Serialize(Error, b, d);
}

void a_Error::Print(ostream &s) const
{
	BASE::Print(s);
	s << Error << endl;
}

Implement_Class(a_Error);

GenericMsg * a_Error::P_ServerExecute(int)
{
	return NULL;
}

