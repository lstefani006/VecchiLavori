#include <st_dbnew.h>
#include <iostream.h>
#include <tcp_net.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <iostream.h>

#ifdef _WIN32
#include <strstrea.h>
#else
#include <strstream.h>

void bzero(char *p, int n) { memset(p, 0, n); }

#endif


#ifndef TCP_WINSOCK
#include <signal.h>
#endif

int TcpServer::GetLastErrorCode() const
{
#ifdef TCP_WINSOCK
	return WSAGetLastError();
#else
	return errno;
#endif
}

TcpServer::TcpServer(u_short nPortNumber)
{
	m_nServerId = INVALID_SOCKET;
	for (int i = 0; i < sizeof(m_nClients) / sizeof(m_nClients[0]); i++)
		m_nClients[i] = INVALID_SOCKET;

	int er = 0;

	do
	{

#ifdef TCP_WINSOCK
		WSADATA wsaData;
		int err = WSAStartup(0x0101, &wsaData);
		if (err != 0)
		{
			er = Error(INVALID_SOCKET);
			break;;
		}
#endif

		char hostname[40];
		int n = ::gethostname(hostname, sizeof(hostname));
		if (n != 0)
		{
			er = Error(INVALID_SOCKET);
			break;
		}

		/*
		 * provo 2 volte con la chiamata gethostname perch� se
		 * un PC con W95 non e' connesso in rete con scheda o PPP
		 * l'hostname non ha indirizzo IP mentre "localhost" si
		 */
		struct hostent *server = ::gethostbyname(hostname);
#ifdef TCP_WINSOCK
		if (server == NULL)
			server = ::gethostbyname("localhost");
#endif
		if (server == NULL)
		{
			er = Error(INVALID_SOCKET);
			break;
		}

		struct in_addr server_addr;
		memset(&server_addr, '\0', sizeof(server_addr));
		memcpy(&server_addr, server->h_addr, server->h_length);

		struct protoent *pp = ::getprotobyname("tcp");
		if (pp == NULL)
		{
			er = Error(INVALID_SOCKET);
			break;
		}

		m_nServerId = ::socket(AF_INET, SOCK_STREAM, pp->p_proto);
		if (m_nServerId == INVALID_SOCKET)
		{
			er = Error(m_nServerId);
			break;
		}

		struct sockaddr_in server_sock;
		memset(&server_sock, '\0', sizeof(server_sock));
		server_sock.sin_family = AF_INET;
		server_sock.sin_addr = server_addr;
		server_sock.sin_port = htons(nPortNumber);
		n = ::bind(m_nServerId, (sockaddr *)&server_sock, sizeof(server_sock));
		if (n != 0)
		{
			er = Error(m_nServerId);
			break;
		}

		n = ::listen(m_nServerId, 5);
		if (n == -1)
		{
			er = Error(m_nServerId);
			break;
		}
	}
	while (0);

	if (er)
	{
		CloseAllSocket();

		cerr << "Errore nell'inizializzazione del server\n" << flush;
		abort();
	}
}

int TcpServer::PollAndAccept(int &bAccept, int mSec, int s)
{
	bAccept = 0;

	for (;;)
	{
		timeval t;
		t.tv_sec  = mSec / 1000;
		t.tv_usec = (mSec % 1000) * 1000;

		timeval *pt = &t;
		if (mSec == -1)
			pt = NULL;

		fd_set rx;
		FD_ZERO(&rx);

		if (s == -1 && m_nServerId != INVALID_SOCKET)
			FD_SET(m_nServerId, &rx);

		for (int i = 0; i < sizeof(m_nClients) / sizeof(m_nClients[0]); i++)
			if (m_nClients[i] != INVALID_SOCKET)
			{
				if ((s != -1 && i == s) || (s == -1))
					FD_SET(m_nClients[i], &rx);
			}

		int r = ::select(FD_SETSIZE, &rx, (fd_set *)NULL, (fd_set *)NULL, pt);
		if (r == -1)
		{
			Error(INVALID_SOCKET);
			continue;
		}

		if (r == 0)
			return -1;

		if (m_nServerId != INVALID_SOCKET && FD_ISSET(m_nServerId, &rx))
		{
			/* accetto una nuova connessione */

			for (int i = 0; i < sizeof(m_nClients) / sizeof(m_nClients[0]); i++)
				if (m_nClients[i] == INVALID_SOCKET)
				{
					struct sockaddr_in server_sock;
					int sz = sizeof(server_sock);
#ifdef _WIN32
					m_nClients[i] = ::accept(m_nServerId, (sockaddr *)&server_sock, &sz);
#else
					m_nClients[i] = ::accept(m_nServerId, (sockaddr *)&server_sock, (size_t *)&sz);
#endif
					if (m_nClients[i] == INVALID_SOCKET)
						Error(INVALID_SOCKET);

					bAccept = 1;
					return i;
				}
		}
		else
		for (int i = 0; i < sizeof(m_nClients) / sizeof(m_nClients[0]); i++)
		{
			if (m_nClients[i] != INVALID_SOCKET && FD_ISSET(m_nClients[i], &rx))
					return i;
		}
	}
	
	return -1;
}

int TcpServer::Poll(int mSec, int s)
{
	int bAccept;

	for (;;)
	{
		int i = PollAndAccept(bAccept, mSec, s);

		if (bAccept == 0)
			return i;
	}
}

int TcpServer::Rx(int s, void *pData, int szMaxSize)
{
	if (IsValidSocket(m_nClients[s]) == 0)
		return 0;

	sockaddr_in rxAddr;
	int length = sizeof(rxAddr);

#ifdef _WIN32
	int n = recvfrom(m_nClients[s], (char *)pData, szMaxSize, 0, (sockaddr *)&rxAddr, &length);
#else
	int n = recvfrom(m_nClients[s], (char *)pData, szMaxSize, 0, (sockaddr *)&rxAddr, (size_t *)&length);
#endif

	if (n == 0)
	{
		CloseSocket2(m_nClients[s]);
		return 0;
	}

#ifdef TCP_WINSOCK
	if (n == SOCKET_ERROR && GetLastErrorCode() == WSAECONNRESET)
	{
		CloseSocket2(m_nClients[s]);
		return 0;
	}
#endif

	if (n == SOCKET_ERROR)
	{
		Error(m_nClients[s]);
		n = 0;
	}

	return n;
}

int TcpServer::RxAll(int s, void *pData, int szSize, int mSec)
{
	if (IsValidSocket(m_nClients[s]) == 0)
		return 0;

	char *p = (char *)pData;
	int sz = szSize;

	while (sz > 0)
	{
		int r = Rx(s, p, sz);
		if (r == 0)
			return 0;
		sz -= r;
		p += r;
		if (sz > 0)
		{
			int ev = Poll(mSec, s);
			if (ev != s)
				return 0;
		}
	}
	return szSize;
}


static void OnPipeServer(int)
{
}

void TcpServer::Tx(int s, const void *pData, int szSizeToSend)
{
	if (IsValidSocket(m_nClients[s]) == 0)
		return;

#ifndef TCP_WINSOCK
	struct sigaction Action;
	struct sigaction OAction;

	Action.sa_handler = OnPipeServer;
	Action.sa_mask.losigs = 0;
	Action.sa_mask.hisigs = 0;
	Action.sa_flags = 0;

	sigaction(SIGPIPE, &Action, &OAction);
#endif


	const char *p = (const char *)pData;
	while (szSizeToSend > 0)
	{
		int n = send(m_nClients[s], p, szSizeToSend, 0);
		if (n == SOCKET_ERROR)
		{
			/*
			 * se il server scrive e il client non consuma ritorna un EPIPE
			 * per es. il client ha  chiuso la comunicazione
			 */

			cerr << "Tx ritorna " << GetLastErrorCode() << endl;

//#ifndef TCP_WINSOCK
//			if (errno != EPIPE)
//				Error(m_nClients[s]);
//#else
//			Error(m_nClients[s]);
//#endif
			
			Error(m_nClients[s]);
			break;
		}

		szSizeToSend -= n;
		p += n;
	}

#ifndef TCP_WINSOCK
	sigaction(SIGPIPE, &OAction, NULL);
#endif
}


const char * TcpServer::GetAddr(int s)
{
	if (IsValidSocket(m_nClients[s]) == 0)
		return NULL;

	sockaddr_in a;
	memset(&a, '\0', sizeof(a));

	int sz = sizeof(a);

#ifdef _WIN32
	int r = getpeername(m_nClients[s], (sockaddr *)&a, &sz);
#else
	int r = getpeername(m_nClients[s], (sockaddr *)&a, (size_t *)&sz);
#endif
	if (r)
	{
		Error(m_nClients[s]);
		return NULL;
	}
	return inet_ntoa(a.sin_addr);
}

const char * TcpServer::GetLocalHost()
{
	const char *r = NULL;

#ifdef TCP_WINSOCK
		WSADATA wsaData;
		int err = WSAStartup(0x0101, &wsaData);
		if (err != 0)
			return r;
#endif

	for (;;)
	{
		static char hostname[40];
		int n = ::gethostname(hostname, sizeof(hostname));
		if (n != 0)
			break;

		struct hostent *server = ::gethostbyname(hostname);
#ifdef TCP_WINSOCK
		if (server == NULL)
			strcpy(hostname, "localhost");
#endif
		r = hostname;
		break;
	}

#ifdef TCP_WINSOCK
	WSACleanup();
#endif

	return r;
}
	

void TcpServer::CloseSocket2(SOCKET s)
{
	if (m_nServerId == s)
	{
#ifdef TCP_WINSOCK
		int r = ::closesocket(s);
#else
		int r = ::close(s);
#endif
		m_nServerId = INVALID_SOCKET;
	}
	else
	{
		for (int i = 0; i < sizeof(m_nClients) / sizeof(m_nClients[0]); i++)
			if (m_nClients[i] == s)
			{
#ifdef TCP_WINSOCK
				int r = ::closesocket(s);
#else
				int r = ::close(s);
#endif
				m_nClients[i] = INVALID_SOCKET;
				break;
			}
		if (i == sizeof(m_nClients) / sizeof(m_nClients[0]))
		{
			cerr << "TcpServer: non riesco a trovare il socket da chiudere\n" << flush;
			abort();
		}
	}
}

void TcpServer::CloseAllSocket()
{
	for (int i = 0; i < sizeof(m_nClients) / sizeof(m_nClients[0]); i++)
		if (m_nClients[i] != INVALID_SOCKET)
			CloseSocket2(m_nClients[i]);

	if (m_nServerId != INVALID_SOCKET)
		CloseSocket2(m_nServerId);
}

TcpServer::~TcpServer()
{
	CloseAllSocket();

#ifdef TCP_WINSOCK
	WSACleanup();
#endif
}

int TcpServer::Error(SOCKET s)
{
#ifdef TCP_WINSOCK
	cerr << "TcpServer: " << WSAGetLastError() << endl;
#else
	perror("TcpServer");
#endif

	if (IsValidSocket(s))
		CloseSocket2(s);

	return 1;
}

int TcpServer::IsValidSocket(SOCKET s) const
{
	if (s == INVALID_SOCKET)
		return 0;

	for (int i = 0; i < sizeof(m_nClients) / sizeof(m_nClients[0]); i++)
		if (m_nClients[i] == s)
			return 1;
	return 0;
}

int TcpServer::NumConnections() const
{
	int n = 0;

	for (int i = 0; i < sizeof(m_nClients) / sizeof(m_nClients[0]); i++)
		if (m_nClients[i] != INVALID_SOCKET)
			n++;

	return n;
}


int TcpServer::GetServicePort(const char *pServiceName)
{
#ifdef TCP_WINSOCK
	WSADATA wsaData;
	WSAStartup(0x0101, &wsaData);
#endif


	int nPort = -1;
	servent *p = getservbyname(pServiceName, "tcp");
	if (p)
		nPort =  ntohs(p->s_port);

#ifdef TCP_WINSOCK
	WSACleanup();
#endif

	return nPort;
}




////////////////////////////////////////////////////////////////////////////////


Tcp_ConnectionError::Tcp_ConnectionError(const char *p)
{
#ifdef TCP_WINSOCK
	m_Error = WSAGetLastError();
#else
	m_Error = errno;
#endif

	m_pMsg = p;
}

const char * Tcp_ConnectionError::Msg() const
{
	static char b[100];

	ostrstream s(b, sizeof(b));
	s << m_pMsg << " errno=" << m_Error << ends;

	return b;
}

Tcp_IOError::Tcp_IOError(const char *p)
{
#ifdef TCP_WINSOCK
	m_Error = WSAGetLastError();
#else
	m_Error = errno;
#endif

	m_pMsg = p;
}

const char * Tcp_IOError::Msg() const
{
	static char b[100];

	ostrstream s(b, sizeof(b));
	s << m_pMsg << " errno=" << m_Error << ends;

	return b;
}


TcpClient::TcpClient()
{
	m_nClientId = INVALID_SOCKET;

#ifdef TCP_WINSOCK
	WSADATA wsaData;
	int err = WSAStartup(0x0101, &wsaData);
	if (err != 0)
		Error("WSAStartup");
#endif

}


void TcpClient::Connect(const char *pcRemoteHost, u_short nRemotePort)
{
	struct protoent *pp = ::getprotobyname("tcp");
	if (pp == NULL)
		throw Tcp_ConnectionError("getprotobyname");
	
	m_nClientId = ::socket(AF_INET, SOCK_STREAM, pp->p_proto);
	if (m_nClientId == INVALID_SOCKET)
		throw Tcp_ConnectionError("socket");

	struct hostent *server = ::gethostbyname(pcRemoteHost);
	if (server == NULL)
	{
		CloseSocket();
		throw Tcp_ConnectionError("gethostbyname");
	}

	struct in_addr server_addr;
	::memset(&server_addr, '\0', sizeof(server_addr));
	::memcpy(&server_addr, server->h_addr, server->h_length);

	struct sockaddr_in ServerSock;
	::memset(&ServerSock, '\0', sizeof(ServerSock));
	ServerSock.sin_family = AF_INET;
	ServerSock.sin_addr = server_addr;
	ServerSock.sin_port = htons(nRemotePort);

	int r = ::connect(m_nClientId, (sockaddr *)&ServerSock, sizeof(ServerSock));
	if (r == SOCKET_ERROR)
	{
		CloseSocket();
		throw Tcp_ConnectionError("connect");
	}
}

TcpClient::~TcpClient()
{
	CloseSocket();
#ifdef TCP_WINSOCK
	WSACleanup();
#endif
}

int TcpClient::Connected() const
{
	return m_nClientId != INVALID_SOCKET;
}

static void OnPipeClient(int)
{
}

void TcpClient::Tx(const void *pData, int szDataToSend)
{
#ifndef TCP_WINSOCK
	struct sigaction Action;
	struct sigaction OAction;

	Action.sa_handler = OnPipeClient;
	Action.sa_mask.losigs = 0;
	Action.sa_mask.hisigs = 0;
	Action.sa_flags = 0;

	sigaction(SIGPIPE, &Action, &OAction);
#endif

	const char *p = (const char *)pData;

	while (szDataToSend > 0)
	{
		int n = ::send(m_nClientId, p, szDataToSend, 0);
		if (n == SOCKET_ERROR)
		{
#ifndef TCP_WINSOCK
			sigaction(SIGPIPE, &OAction, NULL);
#endif
			Error("send");
		}

		p += n;
		szDataToSend -= n;
	}

#ifndef TCP_WINSOCK
	sigaction(SIGPIPE, &OAction, NULL);
#endif
}

int TcpClient::Rx(void *pData, int szMaxDataToReceive, int mSec)
{
	if (!Connected())
		return 0;

	if (mSec != -1)
	{
		timeval t;
		t.tv_sec  = mSec / 1000;
		t.tv_usec = (mSec % 1000) * 1000;

		fd_set rx;
		FD_ZERO(&rx);
		FD_SET(m_nClientId, &rx);

		int r = ::select(FD_SETSIZE, &rx, (fd_set *)NULL, (fd_set *)NULL, &t);
		if (r == -1)
			Error("select");

		if (r == 0)
			return 0;  // timeout
	}

	int n = ::recv(m_nClientId, (char *)pData, szMaxDataToReceive, 0);
	if (n == SOCKET_ERROR)
		Error("recv");

	if (n == 0)  // connection closed
		CloseSocket();

	return n;
}

int TcpClient::RxAll(void *pData, int szDataToReceive, int mSec)
{
	if (!Connected())
		return 0;

	char *p = (char *)pData;
	int sz = szDataToReceive;

	while (sz > 0)
	{
		int r = Rx(p, sz, mSec);

		if (r == 0)
			return 0;

		sz -= r;
		p += r;
	}

	return szDataToReceive;
}

void TcpClient::Error(const char *pMsg)
{
#ifdef TCP_WINSOCK
	cerr << "TcpClient: " << WSAGetLastError() << endl;
#else
	perror("TcpClient");
#endif

	CloseSocket();

	throw Tcp_IOError(pMsg);
}

void TcpClient::CloseSocket()
{
	if (m_nClientId != INVALID_SOCKET)
	{
#ifdef TCP_WINSOCK
		closesocket(m_nClientId);
#else
		close(m_nClientId);
#endif
	}
	m_nClientId = INVALID_SOCKET;
}


int TcpClient::GetServicePort(const char *pServiceName)
{
#ifdef TCP_WINSOCK
	WSADATA wsaData;
	WSAStartup(0x0101, &wsaData);
#endif


	int nPort = -1;
	servent *p = getservbyname(pServiceName, "tcp");
	if (p)
		nPort =  ntohs(p->s_port);

#ifdef TCP_WINSOCK
	WSACleanup();
#endif

	return nPort;
}

const char * TcpClient::GetLocalHost()
{
	const char *r = NULL;

#ifdef TCP_WINSOCK
		WSADATA wsaData;
		int err = WSAStartup(0x0101, &wsaData);
		if (err != 0)
			return r;
#endif

	for (;;)
	{
		static char hostname[40];
		int n = ::gethostname(hostname, sizeof(hostname));
		if (n != 0)
			break;

		struct hostent *server = ::gethostbyname(hostname);
#ifdef TCP_WINSOCK
		if (server == NULL)
			strcpy(hostname, "localhost");
#endif
		r = hostname;
		break;
	}

#ifdef TCP_WINSOCK
	WSACleanup();
#endif

	return r;
}
	
