#ifndef __GENERICMSG_H__
#define __GENERICMSG_H__

#include "serlzer.h"


class GenericMsg
{
protected:
	static const STRING IdMsg;

private:
	struct TbMsg
	{
		GenericMsg *(*m_pfCreateMsg)();
		const char * m_IdMsg;
	};
	static TbMsg s_TbMsg[];

public:

	GenericMsg();
	GenericMsg(const GenericMsg &);
	virtual ~GenericMsg();

	virtual GenericMsg * Clone() const = 0;

	static const char *  RegisterMsg(const char *IdMsg, GenericMsg * (*)());

	static GenericMsg * CreateAndRead(Serializer *, char *, int);
	static GenericMsg * CreateMsg(const STRING &);

	virtual void Serialize(char *&, Serializer *, Serializer::Type) = 0;

	virtual const STRING & GetIdMsg() const = 0;

	virtual void Print(ostream &s) const = 0;

	static	void BufferError();

	virtual GenericMsg * P_ServerExecute(int nClientNumber) = 0;
};


#define Declare_Class(a)                                           \
	typedef GenericMsg BASE;                                       \
	static STRING IdMsg;                                           \
	GenericMsg *        Clone() const    { return STNew a(*this); }  \
	static GenericMsg * Create()         { return STNew a; }         \
	const STRING &      GetIdMsg() const { return IdMsg; }

#define Implement_Class(a)                                         \
	STRING a::IdMsg = GenericMsg::RegisterMsg(#a, a::Create)


#endif
