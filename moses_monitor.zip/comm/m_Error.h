#ifndef __M_ERROR_H__
#define __M_ERROR_H__

#include "gnricmsg.h"

class a_Error : public GenericMsg
{
public:

	STRING Error;

	a_Error(const char *pMsg);
	a_Error();
	a_Error(const a_Error &r);
	~a_Error();

	Declare_Class(a_Error);

	void Serialize(char *&b, Serializer *pSer, Serializer::Type d);
	void Print(ostream &s) const;

	GenericMsg * P_ServerExecute(int nClient);
};


/*
 * Spedisce il messaggio al server e aspetta la risposta che
 * viene ritornata allocata con new come return code.
 *
 */
GenericMsg * P_TxRx(GenericMsg *pIn);

#define CheckError(a)                    \
	if (a->GetIdMsg() == a_Error::IdMsg) \
	{                                    \
		a_Error *answ = (a_Error *)a;    \
                                         \
		STRING e = answ->Error;          \
		STDelete answ;                     \
		return e;                        \
	} 


#endif
