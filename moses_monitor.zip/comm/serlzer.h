#ifndef __serlzer_h__
#define __serlzer_h__

#include <stdlib.h>
#include <iostream.h>

typedef char                   INT8;
typedef unsigned char          UINT8;
typedef short                  INT16;
typedef unsigned short         UINT16;
#ifdef __ALPHA
	typedef int                INT32;
	typedef unsigned int       UINT32;
#elif defined(__AIX)
	typedef long               INT32;
	typedef unsigned long      UINT32;
#elif defined(MSDOS)
	typedef long               INT32;
	typedef unsigned long      UINT32;
#elif defined(_WIN32)
	typedef int                INT32;
	typedef unsigned int       UINT32;
#endif

typedef char                   CHAR;
typedef unsigned char          UCHAR;

typedef float                  FLOAT32;
typedef double                 FLOAT64;


class mString
{
public:
	mString();
	mString(const char *p);
	mString(const char *p, int sz);
	mString(char c, int sz);
	mString(const mString &r);
	~mString();
	void operator = (const mString &);

	void SetSize(int sz);

	int Len()    const { return m_sz; }
	int length() const { return m_sz; }

	int IsIdentifier(int maxlen, int bNotNull = 1) const;

	char * Str() const { return m_p; }

	friend int operator == (const mString &, const mString &);
	friend int operator != (const mString &, const mString &);

	void operator &= (const mString &);

	static mString Set(INT16);
	static mString Set(INT32);

	INT16 GetINT16() const;
	INT32 GetINT32() const;

protected:                                       
	char *m_p;
	int   m_sz;
};

typedef mString STRING;

mString operator & (const mString &, const mString &);
ostream & operator << (ostream &s, const mString &);


template <class T>
class VECT
{
public:
	VECT(int sz = 10);
	VECT(const VECT<T> &);
	~VECT();
	void operator = (const VECT<T> &);

	void Reset() { m_nTop = 0; }
	void Append(T a);
	void Append(const VECT<T> &s);
	void Delete(int pos);

	void Resize(int sz);
//	int  Find(T a) const;
	int  Size() const { return m_nTop; }

	T& operator [] (int i);
	T  operator [] (int i) const;

protected:
	int m_nTop;
	int m_nMaxSize;
	T  *m_pT;
};

#ifndef __AIX
#include "serlzer.c"
#endif

class Serializer
{
public:
	enum Type { In, Out, Count };

	Serializer();
	virtual ~Serializer();

	void Serialize(CHAR &,    char *&, Type);
	void Serialize(UCHAR &,   char *&, Type);
	void Serialize(INT16 &,   char *&, Type);
	void Serialize(UINT16 &,  char *&, Type);
	void Serialize(INT32 &,   char *&, Type);
	void Serialize(UINT32 &,  char *&, Type);
	void Serialize(FLOAT32 &, char *&, Type);
	void Serialize(FLOAT64 &, char *&, Type);
	void Serialize(STRING &,  char *&, Type);           // zero terminata
	void Serialize(STRING &,  int sz, char *&, Type);   // buffer


	void Serialize(VECT<STRING> &, char *&, Type);
	void Serialize(VECT<INT32> &, char *&, Type);
	void Serialize(VECT<INT16> &, char *&, Type);
};


template <class T> ostream & operator << (ostream &s, const VECT<T> &v);


#endif
