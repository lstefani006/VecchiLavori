#include <st_dbnew.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef _WIN32
#include <strstrea.h>
#else
#include <strstream.h>
#endif


#include "serlzer.h"

mString::mString()
{
	m_sz = 0;
	m_p = STNew char [m_sz + 1];
	memset(m_p, '\0', m_sz + 1);
}

mString::mString(const char *p)
{
	m_sz = strlen(p);
	m_p = STNew char [m_sz + 1];
	memcpy(m_p, p, m_sz + 1);
}

mString::mString(const char *p, int sz)
{
	m_sz = sz;
	m_p = STNew char [m_sz + 1];
	memcpy(m_p, p, m_sz);
	m_p[m_sz] = 0;
}

mString::mString(char c, int sz)
{
	m_sz = sz;
	m_p = STNew char [m_sz + 1];
	memset(m_p, c, m_sz);
	m_p[m_sz] = 0;
}

mString::mString(const mString &r)
{
	m_sz = r.m_sz;
	m_p = STNew char [m_sz + 1];
	memcpy(m_p, r.m_p, m_sz + 1);
}

void mString::operator = (const mString &r)
{
	if (this == &r)
		return;

	STDelete m_p;

	m_sz = r.m_sz;
	m_p = STNew char [m_sz + 1];
	memcpy(m_p, r.m_p, m_sz + 1);
}

void mString::SetSize(int sz)
{
	STDelete m_p;

	m_sz = sz;
	m_p = STNew char [m_sz + 1];
	memset(m_p, '\0', m_sz + 1);
}

int mString::IsIdentifier(int maxlen, int bNotNull) const
{
	if ( (!bNotNull) && (m_sz == 0) )	// e' consentira la lung. nulla
		return 1;						// in quanto (size = 0)

	if ( bNotNull && (m_sz == 0) )  // NON e' consentira la lung. nulla  
		return 0;					   // in quanto (size = 1)

	if (m_sz > maxlen)
		return 0;

	for (int i=0; i<m_sz; i++)
	{
		if ( (m_p[i] >= '0') && (m_p[i] <= '9') ||		// 0...9
			 (m_p[i] >= 'A') && (m_p[i] <= 'Z') ||		// A...Z
			 (m_p[i] >= 'a') && (m_p[i] <= 'z') ||		// a...z
			 (m_p[i] == '_'))							// '_'
		{
		}
		else
			return 0;
	}

	return 1;
}

mString::~mString()
{
	STDelete [] m_p;
}

int operator == (const mString &a, const mString &b)
{
	if (a.m_sz != b.m_sz) return 0;
	return memcmp(a.m_p, b.m_p, a.m_sz) == 0;
}

int operator != (const mString &a, const mString &b)
{
	if (a.m_sz != b.m_sz) return 1;
	return memcmp(a.m_p, b.m_p, a.m_sz) != 0;
}


ostream & operator << (ostream &s, const mString &str)
{
	s << str.Str();
	return s;
}

mString operator & (const mString &a, const mString &b)
{
	mString r('\0', a.Len() + b.Len());
	memcpy(r.Str(), a.Str(), a.Len());
	memcpy(r.Str() + a.Len(), b.Str(), b.Len());
	return r;
}


void mString::operator &= (const mString &r)
{
	*this = *this & r;
}


mString mString::Set(INT16 n)
{
	char b[20];
	ostrstream s(b, sizeof(b));
	s << n << ends;

	return mString(b);
}


mString mString::Set(INT32 n)
{
	char b[20];
	ostrstream s(b, sizeof(b));
	s << n << ends;

	return mString(b);
}



INT16 mString::GetINT16() const
{
	INT16 r;

	istrstream s(m_p);
	s >> r;

	return r;
}


INT32 mString::GetINT32() const
{
	INT32 r;

	istrstream s(m_p);
	s >> r;

	return r;
}


static UINT32 atoui(char *str)
{
	UINT32 retval = 0;
	int i = 0;
	while(str[i] != '\0')
	{
		retval = retval*10 + (str[i] - '0');
		i++;
	}
	return retval;
}


Serializer::Serializer()
{
}


Serializer::~Serializer()
{
}


void Serializer::Serialize(CHAR &val, char *&str, Type d)
{
	if (d == Out)
	{
		sprintf(str,"%+04d", val);
		str += 5;
	}
	else
		if (d == Out)
		{
			str += 5;
		}
		else
		{
			val = atoi(str);
			str += strlen(str)+1;
		}
}



void Serializer::Serialize(UCHAR &val, char *&str, Type d)
{
	if (d == Out)
	{
		sprintf(str,"%+04u",val);
		str += 5;
	}
	else
		if (d == Count)
		{
			str += 5;
		}
		else
		{
			val = atoi(str);
			str += strlen(str)+1;
		}
}



void Serializer::Serialize(INT16 &val, char *&str, Type d)
{
	if (d == Out)
	{
		sprintf(str, "%+07d", val);
		str += 8;
	}
	else
		if (d == Count)
		{
			str += 8;
		}
		else
		{
			val = atoi(str);
			str += 8;
		}
}



void Serializer::Serialize(UINT16 &val, char *&str, Type d)
{
	if (d == Out)
	{
		sprintf(str, "%+07u", val);
		str += 8;
	}
	else
		if (d == Count)
		{
			str += 8;
		}
		else
		{
			val = atoui(str);
			str += 8;
		}
}




void Serializer::Serialize(INT32 &val, char *&str, Type d)
{
	if (d == Out)
	{
		sprintf(str, "%+012d", val);
		str += 13;
	}
	else
		if (d == Count)
		{
			str += 13;
		}
		else
		{
			val = atoi(str);
			str += 13;
		}
}




void Serializer::Serialize(UINT32 &val, char *&str, Type d)
{
	if (d == Out)
	{
		sprintf(str, "%+012u", val);
		str += 13;
	}
	else
		if (d == Count)
		{
			str += 13;
		}
		else
		{
			val = atoui(str);
			str += 13;
		}
}

void Serializer::Serialize(FLOAT32 &val, char *&str, Type d)
{
	if (d == Out)
	{
		sprintf(str, "%+024.15f", val);
		str += 25;
	}
	else
		if (d == Count)
		{
			str += 25;
		}
		else
		{
			val = (FLOAT32) atof(str);
			str += 25;
		}
}



void Serializer::Serialize(FLOAT64 &val, char *&str, Type d)
{
	if (d == Out)
	{
		sprintf(str, "%+024.15lf", val);
		str += 25;
	}
	else
		if (d == Count)
		{
			str += 25;
		}
		else
		{
			val = atof(str);
			str += 25;
		}
}



void Serializer::Serialize(STRING &val, char *&str, Type d)
{
	/*
	   if (d == Out)
	   {
	   strcpy(str, val.Str());
	   str += val.length() + 1;
	   }
	   else
	   {
	   val = str;
	   str += val.length() + 1;
	   }
	 */

	Serialize(val, val.Len(), str, d);
}

void Serializer::Serialize(STRING &val, int sszz, char *&str, Type d)
{
	INT32 sz = sszz;

	Serialize(sz, str, d);

	if (d == Out)
	{
		memcpy(str, val.Str(), sz);
		str += sz;
	}
	else
		if (d == Count)
		{
			str += sz;
		}
		else
		{
			val.SetSize(sz);
			memcpy(val.Str(), str, sz);
			str += sz;
		}
}

	template <class T>
void Serialize_T(Serializer *pSer, VECT<T> &val, char *&str, Serializer::Type d)
{
	INT32 sz = val.Size();

	pSer->Serialize(sz, str, d);

	if (d == Serializer::In)
		val.Reset();

	for (int i = 0; i < sz; i++)
	{
		if (d == Serializer::Out)
			pSer->Serialize(val[i], str, d);
		else
		if (d == Serializer::Count)
			pSer->Serialize(val[i], str, d);
		else
		{
			T a;
			pSer->Serialize(a, str, d);
			val.Append(a);
		}
	}

}

void Serializer::Serialize(VECT<STRING> &val, char *&str, Type d)
{
	Serialize_T(this, val, str, d);
}

void Serializer::Serialize(VECT<INT32> &val, char *&str, Type d)
{
	Serialize_T(this, val, str, d);
}

void Serializer::Serialize(VECT<INT16> &val, char *&str, Type d)
{
	Serialize_T(this, val, str, d);
}
