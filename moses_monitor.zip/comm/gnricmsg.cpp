#include <st_dbnew.h>
#include <stdlib.h>
#include <iostream.h>

#include "gnricmsg.h"

#define MSGTABLESIZE 200

GenericMsg::TbMsg GenericMsg::s_TbMsg[MSGTABLESIZE] = { NULL, NULL, };

const STRING GenericMsg::IdMsg = "GenericMsg";


GenericMsg::GenericMsg()
{
}

GenericMsg::GenericMsg(const GenericMsg &r)
{
}

GenericMsg::~GenericMsg()
{
}

GenericMsg * GenericMsg::Clone() const
{
	return NULL;
}


GenericMsg *GenericMsg::CreateAndRead(Serializer *pSer, char *buf, int len)
{
	char *pInizio = buf;

	STRING Id;
	pSer->Serialize(Id, buf, Serializer::In);

	GenericMsg *pMsg = GenericMsg::CreateMsg(Id);

	if (pMsg == NULL)
	{
		cerr << "FATAL ERROR: Cannot create object for ID " << Id << "\n";

		for (int i = 0; i < len; i++)
			if (pInizio[i] >= 32 && pInizio[i] < 127)
				cerr << (char)pInizio[i] << " ";
			else
				cerr << "'" << (int) pInizio[i] << "' ";
		cerr << "\n";
		return NULL;
	}

	pMsg->Serialize(buf, pSer, Serializer::In);

	if (buf - pInizio > len)
		BufferError();

	return pMsg;
}


const char * GenericMsg::RegisterMsg(const char *id, GenericMsg * (*pfCreateMsg)())
{
	for (int i = 0; i < MSGTABLESIZE; i++)
	{
		if (s_TbMsg[i].m_pfCreateMsg == NULL)
			break;

		if(s_TbMsg[i].m_IdMsg == id)
		{
			cerr << "FATAL ERROR\nMessage ID " << id << " is duplicated!!\n";
			abort();
		}
	}

	if (i == MSGTABLESIZE)
		return NULL;

	s_TbMsg[i].m_IdMsg       = id;
	s_TbMsg[i].m_pfCreateMsg = pfCreateMsg;

	return id;
}

/******************************************************************************/

GenericMsg * GenericMsg::CreateMsg(const STRING &id)
{
	for (int i = 0; i < MSGTABLESIZE; i++)
	{
		if (s_TbMsg[i].m_IdMsg == NULL)
			break;

		if (s_TbMsg[i].m_IdMsg == id)
			return (*s_TbMsg[i].m_pfCreateMsg)();
	}

	return NULL;
}

void GenericMsg::Serialize(char *&b, Serializer *pSer, Serializer::Type t)
{
	if (t == Serializer::Out)
	{
		STRING m = GetIdMsg();
		pSer->Serialize(m, b, t);
	}
	else
	if (t == Serializer::Count)
	{
		STRING m = GetIdMsg();
		pSer->Serialize(m, b, t);
	}
}


const STRING & GenericMsg::GetIdMsg() const
{
	return IdMsg;
}


void GenericMsg::BufferError()
{
	cerr << "Write/Read: buffer too small" << endl;
	abort();
}

void GenericMsg::Print(ostream &s) const
{
	s << GetIdMsg() << ":" << endl;
}
