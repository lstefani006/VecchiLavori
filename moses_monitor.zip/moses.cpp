#include <st_dbnew.h>

#ifdef _WIN32
#include <strstrea.h>
#include <direct.h>
#else
#include <strstream.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <moses.h>
#include <gnricmsg.h>

#ifndef TCP_WINSOCK
#include <signal.h>
#endif

#include <tcp_net.h>

#ifdef MOSES_SERVER
	#include <tbFile.h>
	#include <server.h>
	#include <mtime.h>
	#include <mdir.h>
	#include "srvAPI/Licence.h"
	#include "srvAPI/MB.h"
	#include "srvAPI/SC.h"
	#include "srvAPI/ERROR.h"
	#include "m_Moses_Work_Begin.h"
	#include "m_Moses_Licence_Set.h"
	#include "m_Moses_Licence_Get.h"
	#include "m_Moses_Work_Begin.h"
	#include "m_Moses_Work_End.h"
	#include "m_Moses_Licence_Get.h"
	#include "m_Moses_Licence_Set.h"
#endif


#include <m_Error.h>

////////////////////////////////////////////////////////////////////////////////////////////////

Serializer *G_pSerializer = NULL;
TcpClient  *G_pTcpClient = NULL;

struct Header
{
#ifndef LONG_HEADER
	Header(int sz = 0)
	{
		memset(s, '\0', sizeof(s));
		ostrstream s_out(s, sizeof(s));
		s_out << sz << ends;
	}

	int GetSZ()
	{
		istrstream s_in(s, sizeof(s));
		int sz;
		s_in >> sz;
		return sz;
	}

	char s[10];

#endif


#ifdef LONG_HEADER
	Header()  // per ricevere i messaggi
	{
		memset(s, '\0', sizeof(s));
	}

	Header(int sz, const char *p)  // per trasmettere i messaggi
	{
		const unsigned char *up = (const unsigned char *)p;
		unsigned char c = 0;
		for (int i = 0; i < sz; i++)
			c ^= *up++;

		sprintf(s, "** %12d %03d **", sz, int(c));
	}

	int ErrorInHeader(int &sz, int &ck)
	{
		sz = 0;
		ck = 0;

		if (s[sizeof(s) - 1] != '\0') return 1;

		char c1, c2, c3, c4;
		int r = sscanf(s, "%c%c %d %d %c%c", &c1, &c2, &sz, &ck, &c3, &c4);

		return r != 6 || c1 != '*' || c2 != '*' || c3 != '*' || c4 != '*';
	}

	int ErrorInHeader()
	{
		int sz, ck;
		return ErrorInHeader(sz, ck);
	}

	int ErrorInMsg(const char *p)
	{
		int sz, ck;
		if (ErrorInHeader(sz, ck))
			return 1;

		unsigned char c;
		const unsigned char *up = (const unsigned char *)p;
		for (int i = 0; i < sz; i++)
			c ^= *up++;

		return ((unsigned char)ck) != c;
	}

	int GetSZ()
	{
		int sz, ck;
		if (ErrorInHeader(sz, ck))
			return 0;

		return sz;
	}

	char s[25];

#endif
};


/*
 * Funzione invocata dal client
 */
static int S_MaxSecRisposta = 120;

GenericMsg * P_TxRx(GenericMsg *pIn)
{
	// STMemTrace;


	if (G_pTcpClient == NULL)
		return STNew a_Error("CN001 : Connect to MOSES first!");

	try
	{
		// trasmetto il pacchetto al server
		{
			char *b = NULL;

			{
				// conto i byte necessari per la trasmissione
				char *p = NULL;
				pIn->Serialize(p, G_pSerializer, Serializer::Count);

				STDelete [] b;
				b = STNew char [p - (char * )NULL];
			}

			char *p = b;

			// compongo la domanda al server
			pIn->Serialize(p, G_pSerializer, Serializer::Out);

			// compongo l'header
#ifndef LONG_HEADER
			Header s(p - b);
#else
			Header s(p - b, b);
#endif

			// spedisco header + messaggio
			{
				STRING e('\0', sizeof(s) + (p - b));
				memcpy(e.Str(), &s, sizeof(s));
				memcpy(e.Str() + sizeof(s), b, p - b);

				// se fallisce lancia un'eccezione
				G_pTcpClient->Tx(e.Str(), sizeof(s) + (p - b));
			}

			STDelete b;
		}

		// aspetto l'header
		{
			// RxAll mi da la ragionevole certezza di ricevere il pacchetto
			// in formato corretto
			Header s;
			int bOk = sizeof(s) == G_pTcpClient->RxAll(&s, sizeof(s), S_MaxSecRisposta * 1000);
			if (!bOk)
			{
				STDelete G_pTcpClient;
				G_pTcpClient = NULL;
				return STNew a_Error("CN002 : Error reading header");
			}

#ifdef LONG_HEADER
			if (s.ErrorInHeader())
			{
				STDelete G_pTcpClient;
				G_pTcpClient = NULL;
				return STNew a_Error("CN009 : Error in header format");
			}
#endif

			// leggo la lunghezza
			int sz = s.GetSZ();
			char *pp = STNew char [sz];

			// leggo il messaggio
			bOk = sz == G_pTcpClient->RxAll(pp, sz, 40 * 1000);
			if (!bOk)
			{
				STDelete [] pp;
				STDelete G_pTcpClient;
				G_pTcpClient = NULL;
				return STNew a_Error("CN003 : Error reading body");
			}

#ifdef LONG_HEADER
			if (s.ErrorInMsg(pp))
			{
				STDelete [] pp;
				STDelete G_pTcpClient;
				G_pTcpClient = NULL;
				return STNew a_Error("CN008 : Checksum error in body");
			}
#endif

			// creo la classe con la risposta
			GenericMsg *pMsg = GenericMsg::CreateAndRead(G_pSerializer, pp, sz);

			STDelete [] pp;

			if (pMsg == NULL)
			{
				STDelete G_pTcpClient;
				G_pTcpClient = NULL;
				return STNew a_Error("CN004 : Error serializing message body");
			}

			return pMsg;
		}
	}
	catch (Tcp_IOError /*e*/)
	{
		STDelete G_pTcpClient;
		G_pTcpClient = NULL;

		return STNew a_Error("CN005 : Error in TCP/IP connection");
	}

	return NULL;
}


#ifdef MOSES_SERVER

void Moses_Server()
{
	int bDebug = 1;

	{
		const char *p;

		G_pServerData = STNew ServerData;

		G_pServerData->m_MosesName = "moses";


		if (p = getenv("MOSES_MB_DIR"))
			G_pServerData->m_MB_RootPath = p;
		else
		{
			char b[256];
			getcwd(b, sizeof(b));
			strcat(b, "/MB");
			G_pServerData->m_MB_RootPath = b;
		}

		if (p = getenv("MOSES_CFG_DIR"))
			G_pServerData->m_CfgPath = p;
		else
		{
			char b[256];
			getcwd(b, sizeof(b));
			strcat(b, "/cfg");
			G_pServerData->m_CfgPath = b;
		}

		G_pServerData->m_LocalHost = TcpServer::GetLocalHost();

		if (p = getenv("MOSES_TCP_PORT"))
			G_pServerData->m_nPort = atoi(p);
		else
		{
			// G_pServerData->m_nPort = 4309;

			G_pServerData->m_nPort = TcpServer::GetServicePort("moses");
			if (G_pServerData->m_nPort == -1)
				G_pServerData->m_nPort = 4309;

		}

		if (p = getenv("MOSES_MSL_EXE"))
			G_pServerData->m_Msl = p;
		else
		{
			char b[256];
			getcwd(b, sizeof(b));
			strcat(b, "/../msl/msl");
			G_pServerData->m_Msl = b;

#ifdef WIN32
			if (strchr(G_pServerData->m_Msl.Str(), ' '))
			{
				G_pServerData->m_Msl = "\"" & G_pServerData->m_Msl & "\"";
			}
#endif
		}

		if (getenv("MOSES_DEBUG_MSG"))
			bDebug = 1;
	}

	// test esistenza delle directory
	{
		int bDirectory;

		if (!mDirectory::Exist(G_pServerData->m_MB_RootPath.Str(), bDirectory))
			MkDir(G_pServerData->m_MB_RootPath.Str());

		if (!mDirectory::Exist(G_pServerData->m_CfgPath.Str(), bDirectory))
			MkDir(G_pServerData->m_CfgPath.Str());
	}


	TB_Init(G_pServerData->m_CfgPath.Str());

	// nella tabella tegli user deve esserci l'utente system
	// TBD forse e' meglio chiamare la funzione appropriata
	{
		VECT<STRING> u = TB_USER->GetEmptyRow();
		u[ F_USER_Name        ] = "system";
		u[ F_USER_Pwd         ] = "moses";
		u[ F_USER_Type        ] = "CFG";
		u[ F_USER_Descr       ] = "System ADM";
		u[ F_USER_Rights      ] = "XXXXXXXX";
		u[ F_USER_DefaultMBox ] = "system";

		TB_USER->Insert(u);

		u[ F_USER_Name        ] = "mtd";
		u[ F_USER_Pwd         ] = "moses";
		u[ F_USER_Type        ] = "MTD";
		u[ F_USER_Descr       ] = "Login MTD";
		u[ F_USER_Rights      ] = "XXXXXXXX";
		u[ F_USER_DefaultMBox ] = "system";

		TB_USER->Insert(u);
	}

	// tabella MOSES
	{
		VECT<STRING> u = TB_MOSES->GetEmptyRow();
		u[ F_MOSES_Name        ] = G_pServerData->m_MosesName;
		u[ F_MOSES_IdMsg       ] = "100";
		u[ F_MOSES_ClientPid   ] = "0";
		u[ F_MOSES_DateLicence ] = "20000101000000";
		TB_MOSES->Insert(u);
	}

	// creo (se non esiste) la mailbox di default
	// TDB e' meglio delegare alla creazione dell'utente la 
	// TDB creazione della mailbox
	{
		MB_CreateMailbox(
				-1,			// nClient
				"system",	// mail box name
				"system",	// owner
				"moses",	// password
				"");		// descrizione
	}

	// inizializzo lo scheduler per gestire gli eventi di lettura POP3
	Init_EventForMTD("* * * * * *", "email");

	// inizializzo lo scheduler lanciare lo script di startup
	Init_StartUpScript("$MSL StartUp.msl StartUp $LOCALHOST $PORT $LOGIN_CFG $PWD_CFG");

	TcpServer Server(G_pServerData->m_nPort);

	G_pServerData->SetTcpServer(&Server);

#ifndef TCP_WINSOCK
	// per evitare i figli morti <defunct>
	struct sigaction Action;
	struct sigaction OAction;

	Action.sa_handler = SIG_IGN;
	Action.sa_mask.losigs = 0;
	Action.sa_mask.hisigs = 0;
	Action.sa_flags = 0;

	sigaction(SIGCHLD, &Action, &OAction);
#endif

	// Eventuale Lancio dello Script iniziale.
	LanciaScriptIniziale();

	const int Timeout = 60;
	int SecRimasti = Timeout;


	for (;;)
	{
		// STMemTrace;

		int bAccept = 0;

		time_t t = time(NULL);
		int nClient = Server.PollAndAccept(bAccept, SecRimasti * 1000);
		if (nClient == -1)
		{
			STRING currentTime    = mGetCurrentTime();
			INT16 nDayInWeek      = (INT16) mGetCurrentWeekDay();
			STRING currentWeekDay = STRING::Set(nDayInWeek);

			int err = MatchCurrentTime(currentTime , currentWeekDay);

			if (err == 0)
				cerr<<GetError("SC003")<<endl;

			SecRimasti = Timeout;

			continue;
		}

		int SecTrascorsi = time(NULL) - t;
		SecRimasti -= SecTrascorsi;
		if (SecRimasti < 0)
			SecRimasti = 0;


		if (bAccept)
		{
			if (bDebug) cout << "nuovo utente connesso " << nClient << endl;

			G_pServerData->NewConnection(nClient);

#if !defined(TCP_WINSOCK) && defined(DO_FORK)
			if (fork() == 0)
			{
				// sono il figlio
				Server.CloseSocket();
			}
			else
			{
				// sono il padre
				Server.CloseSocket(nClient);
			}
#endif

			continue;
		}

		Header h;
		int c = Server.RxAll(nClient, &h, sizeof(h), 40*1000);
		if (c == 0)
		{
			cout << "utente sconnesso " << nClient << endl;
			G_pServerData->CloseConnection(nClient);

#if !defined(TCP_WINSOCK) && defined(DO_FORK)
			exit(0);
#endif

			continue;
		}

#ifdef LONG_HEADER
		if (h.ErrorInHeader())
		{
			cout << "error in header --> utente sconnesso " << nClient << endl;
			G_pServerData->CloseConnection(nClient);

#if !defined(TCP_WINSOCK) && defined(DO_FORK)
			exit(0);
#endif
			continue;
		}
#endif

		int sz = h.GetSZ();
		STRING p('\0', sz);
		c = Server.RxAll(nClient, p.Str(), sz, 60 * 1000);
		if (c == 0)
		{
			if (bDebug) cout << "utente sconnesso" << nClient << endl;
			G_pServerData->CloseConnection(nClient);

#if !defined(TCP_WINSOCK) && defined(DO_FORK)
			exit(0);
#endif

			continue;
		}


#ifdef LONG_HEADER
		if (h.ErrorInMsg(p.Str()))
		{
			cout << "checksum error --> utente sconnesso " << nClient << endl;
			G_pServerData->CloseConnection(nClient);

#if !defined(TCP_WINSOCK) && defined(DO_FORK)
			exit(0);
#endif
			continue;
		}
#endif

		GenericMsg *pMsg = GenericMsg::CreateAndRead(G_pSerializer, p.Str(), sz);

		if (bDebug)
		{
			cout << "Ricevo il messaggio\n";
			if (pMsg)
				pMsg->Print(cout);
			else
				cout << "CreateAndRead ritorna NULL";
			cout << "\n";
		}



		GenericMsg *pAnswer = NULL;

		// Controllo della licenza
		// Se il cliente e' un MTD non controllo la licenza
		// Se i messaggi che arrivano sono di connessione/sconnessione/login
		// consento l'accesso.
		// Altrimenti spedisco come risposta solo un messaggio di licenza 
		// scaduta
		if ( !G_pServerData->IsMTDClient(nClient) )
		{
			if (!Licence_OK())
			{
				// Licenza scaduta
				if (!
						(pMsg->GetIdMsg() == c_Moses_Work_Begin::IdMsg ||
						 pMsg->GetIdMsg() == c_Moses_Work_End::IdMsg ||
						 pMsg->GetIdMsg() == c_Moses_Licence_Get::IdMsg ||
						 pMsg->GetIdMsg() == c_Moses_Licence_Set::IdMsg))
				{
					clog << "Outdated licence from " << Server.GetAddr(nClient) << endl;
					pAnswer = STNew a_Error("CN006 : Outdated licence");
				}
			}
		}

		// gestione server chiuso
		// tutti i clienti di tipo APP (application) non possono piu'
		// effettuare operazioni
		// I clienti di tipo CFG possono continuare ad usareil sistema
		// - dunque SetADM e script MSL possono lavorare
		// I clienti di tipo MTD non sono disabilitati. Il server moses
		// non dispaccia piu' eventi verso i clienti MTD; in questo modo
		// gli MTD possono completare il loro lavoro e poi rimangono idle
		// per mancanza di eventi

		if (G_pServerData->IsServerClosed())
		{
			if (G_pServerData->IsAppClient(nClient))
			{
				pAnswer = STNew a_Error("CN007 : System closed");
			}
		}


		if (pAnswer == NULL)
			pAnswer = pMsg->P_ServerExecute(nClient);

		if (pAnswer == NULL)
			cerr << "Il server non da` la risposta\n";

		// spedisco la risposta

		if (pAnswer)
		{
			if (bDebug) cout << "Trasmetto la risposta\n";
			if (bDebug) pAnswer->Print(cout);
			if (bDebug) cout << "\n";


			{
				int sz;
				{
					char *p = NULL;
					pAnswer->Serialize(p, G_pSerializer, Serializer::Count);
					sz = (p - (char *)NULL);
				}

				STRING b('\0', sz);
				{
					char *p = b.Str();
					pAnswer->Serialize(p, G_pSerializer, Serializer::Out);
				}

#ifndef LONG_HEADER
				Header h(sz);
#else
				Header h(sz, b.Str());
#endif

				{
					STRING e('\0', sizeof(h) + sz);
					memcpy(e.Str(), &h, sizeof(h));
					memcpy(e.Str() + sizeof(h), b.Str(), sz);

					// se fallisce chiude il canale e ritorna
					//N.B. nClient in caso di errore non e' significativo
					Server.Tx(nClient, e.Str(), sizeof(h) + sz);
				}
			}

			/*
			 * if (pAnswer->GetIdMsg() == a_Moses_Work_Begin::IdMsg)
			 * {
			 * 	a_Moses_Work_Begin *p = (a_Moses_Work_Begin*)pAnswer;
			 * 	if (strncmp(p->Error.Str(), "G0002", 5) == 0)
			 * 	{
			 * 		// #TDB#	Server.CloseSocket(nClient);
			 * 	}
			 * }
			 */
		}
		else
			clog << "ERROR: molto strano non ho risposta da ritornare\n";

		STDelete pMsg; pMsg = NULL;

		STDelete pAnswer; pAnswer = NULL;
	}
}





void main(int ac, char **av)
{
	G_pSerializer = STNew Serializer;

	Moses_Server();
}

#endif
