using System;
using System.IO;
using System.Reflection;
using System.Runtime.Remoting;
using MeRT_IBL;

namespace MeTest
{
	internal class _
	{
		[STAThread]
		private static void Main(string[] args)
		{
			try
			{
				string configFile = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
				RemotingConfiguration.Configure(configFile);

				string f = GME.Utility.AppSettings.ToString("RemOpChannel_DefaultServer");
				RemConfig.ClientConfig(f);

				string testDir = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "Test");
				if (!Directory.Exists(testDir))
					Directory.CreateDirectory(testDir);

				Test_Login.Test_1();
				Test_Login.Test_2();

				Test_BLWS.Test_1();

				Test_AlgoClient.Test_1(testDir);

				Test_AlgoRunner.Test_1();
				Test_ZoneInformationReader.Test_1(testDir);

			}
			catch (Exception ex)
			{
				Console.Error.WriteLine(ex.ToString());	
			}

			Console.ReadLine();
		}
	}

}