using System;
using GME.Remoting;
using GME.Web;
using MeRT_IBL;

internal class Test_BLWS
{
	// funzione che spara le richieste di remoting al WS
	private static byte[] SendRemotingMessage(byte[] ar, string outputPath, string config)
	{
		MeTest.BL.BLRemotingSink ws = new MeTest.BL.BLRemotingSink();
		WSClient.Setup(ws, config);
		ws.Url = outputPath;
		return ws.ProcessMessage(ar);
	}

	public static void Test_1()
	{
		Console.WriteLine();
		Console.WriteLine();
		Console.Write("Test_BLWS.Test_1: ");
		Console.ReadLine();


		DateTime di = DateTime.Now;
		for (int n = 0; n < 100; ++n)
		{
			IEcho e = (IEcho) RemotingHelper.GetObject(typeof (IEcho));
			string s = e.DoEcho(false);
			Console.WriteLine("Echo.DoEcho returns {0}", s);
		}
		DateTime df = DateTime.Now;
		Console.WriteLine("Tempo esecuzione {0}", df.Subtract(di));
	}
}
