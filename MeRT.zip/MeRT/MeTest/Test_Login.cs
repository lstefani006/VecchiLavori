using System;
using System.Xml;
using System.Xml.Serialization;
using GME.Remoting;
using MeRT_IBL;

internal class Test_Login
{
	public static void Test_1()
	{
		Console.WriteLine();
		Console.WriteLine();
		Console.Write("Test_Login.Test_1: ");
		Console.ReadLine();

		ILogin login = (ILogin) RemotingHelper.GetObject(typeof(ILogin));

		LoginData ld = login.CheckAccessUsernamePassword("leo", "pwd");

		XmlSerializer x = new XmlSerializer(typeof(LoginData));
		XmlTextWriter xw = new XmlTextWriter(Console.Out);
		xw.Formatting = Formatting.Indented;
		xw.IndentChar = '\t';
		xw.Indentation = 1;
		x.Serialize(xw, ld);
		xw.Close();
	}

	public static void Test_2()
	{
		Console.WriteLine();
		Console.WriteLine();
		Console.Write("Test_Login.Test_2: ");
		Console.ReadLine();

		ILogin login = (ILogin) RemotingHelper.GetObject(typeof(ILogin));

		LoginData ld = login.CheckAccessUsernamePassword("LoginCheNonEsiste", "PasswordInventata");

		XmlSerializer x = new XmlSerializer(typeof(LoginData));
		XmlTextWriter xw = new XmlTextWriter(Console.Out);
		xw.Formatting = Formatting.Indented;
		xw.IndentChar = '\t';
		xw.Indentation = 1;
		x.Serialize(xw, ld);
		xw.Close();
	}

		
}
